from . import resource_api_18168 as _suv_resource
# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

import json
import os
import re
import sys
from pathlib import Path

import bpy

from .icon_aliases import canonical_icon_path
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

PACKAGE_ID = 'smart_uv_suite'
ADDON_NAME = 'Smart UV Suite'
TOOL_LABEL_EN = 'Smart UV'
TOOL_LABEL_JA = 'Smart UV'
PANEL_CATEGORY = 'Smart UV'
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ表示',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggles'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): '設定保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Save every setting currently shown in the N-panel to Blender config/Smart_UV_Suite/Smart_UV_Suite.json and write Blender preferences. These values are restored when Blender starts or when another scene is opened.'): '現在Nパネルに表示されている全設定を Blender 設定フォルダの Smart_UV_Suite/Smart_UV_Suite.json に保存し、Blenderのプリファレンス保存も実行します。Blender起動時や別シーンを開いた時に復元されます。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated UV Suite files are always routed below Blender CONFIG. The
    # installed Extension package is immutable; explicit operator export paths
    # remain user-controlled and are not handled by this helper.
    try:
        from . import storage as _smart_uv_storage
        return _smart_uv_storage.user_data_dir(create=create)
    except Exception:
        pass
    try:
        version_info = getattr(getattr(bpy, 'app', None), 'version', (5, 1, 0)) or (5, 1, 0)
        version = f"{int(version_info[0])}.{int(version_info[1])}"
    except Exception:
        version = '5.1'
    if os.name == 'nt':
        base = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        root = Path(base) / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_UV_Suite' / _STORAGE_DIRNAME
    else:
        root = Path.home() / '.config' / 'blender' / version / 'config' / 'Smart_UV_Suite' / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def legacy_settings_path():
    # Read-only legacy location; the settings are now kept in Smart_UV_Suite.json.
    return storage_path('settings', 'n_panel_settings.json', create_parent=False)


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        from . import ownership_runtime_18168 as _ownership
        pcoll = _ownership.register_preview_collection(bpy.utils.previews)
        for name in ('header', 'help', 'clock'):
            path = canonical_icon_path(name)
            if path is not None:
                try:
                    pcoll.load(name, str(path), 'IMAGE')
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    # Draw-safe: preview creation and file loading happen only in register().
    pcoll = _PREVIEW_COLLECTION
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        from . import ownership_runtime_18168 as _ownership
        _ownership.unregister_preview_collection(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    load_extra = True
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        # Avoid loading the large extended Japanese tooltip table during English
        # startup. It is still loaded when Blender's active UI locale is Japanese.
        load_extra = (not locale) or locale.lower().startswith('ja')
    except Exception:
        load_extra = True
    if load_extra:
        try:
            from . import language_extra
            extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
            if isinstance(extra, dict):
                data.update(extra)
        except Exception:
            pass
    return {'ja_JP': data}


OPEN_HELP_POPUP_WIDTH = 680
# Popup margins, box borders and label padding reserved inside the popup body.
_OPEN_HELP_CONTENT_PADDING_PX = 72


def _wrap_lines(value, width_px, context=None):
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Measure each line with BLF (the same measurement the help popup uses) so a
    # label is split only when its drawn width would exceed the popup body.
    try:
        from . import help as _help
        limit = int(max(180, int(width_px or 0)) * float(_help._ui_scale(context)))
        lines = []
        for para in text_value.split('\n'):
            raw = para.strip()
            if not raw:
                lines.append('')
                continue
            lines.extend(_help._wrap_pixel_line(raw, limit, context) or [raw])
        return lines
    except Exception:
        pass
    import textwrap
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    # context.region is the region the popup was opened from (sidebar or the
    # whole viewport), not the popup itself, so wrap against the popup width.
    width = OPEN_HELP_POPUP_WIDTH - _OPEN_HELP_CONTENT_PADDING_PX
    if icon != 'NONE':
        width -= 28
    first = True
    for line in _wrap_lines(value, width, context):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_UV_OT_open_help(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'

    topic: StringProperty(default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_popup(self, width=OPEN_HELP_POPUP_WIDTH)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        try:
            from . import guide
            group = guide.get_group(topic)
        except Exception as exc:
            group = {
                'title_en': TOOL_LABEL_EN + ' Help',
                'title_ja': TOOL_LABEL_JA + ' ヘルプ',
                'overview_en': ['The help catalog could not be loaded: ' + str(exc)],
                'overview_ja': ['ヘルプカタログを読み込めませんでした: ' + str(exc)],
                'usage_en': [],
                'usage_ja': [],
                'settings': [],
                'operators': [],
            }
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定項目', context), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
                context,
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_UV_OT_set_always_on(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.set_always_on'
    bl_label = 'Always-on Toggles'
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'

    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, str(exc))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, str(exc))
        try:
            flush_all_persistent_state(context)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_UV_OT_save_preferences(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save every setting currently shown in the N-panel to Blender config/Smart_UV_Suite/Smart_UV_Suite.json and write Blender preferences. These values are restored when Blender starts or when another scene is opened.'

    def execute(self, context):
        flush_all_persistent_state(context)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        flush_all_persistent_state(context)
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}


class UVSUITE_PT_ALWAYS_ON_TOGGLE(bpy.types.Panel):
    bl_idname = 'UVSUITE_PT_ALWAYS_ON_TOGGLE'
    bl_label = 'Always-on Toggles'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_options = {'HIDE_HEADER'}

    @classmethod
    def poll(cls, context):
        # This former standalone panel is intentionally suppressed. The only
        # visible Always-on UI is the top group inside the main UV Suite panel.
        del cls, context
        return False

    def draw_header(self, context):
        del context
        return None

    def draw(self, context):
        del context
        return None


def _unregister_standalone_always_on_panel() -> None:
    # Exact identity only.  The legacy class is never found or modified by name.
    try:
        from . import ownership_runtime_18168 as _ownership
        if UVSUITE_PT_ALWAYS_ON_TOGGLE in _ownership.registered_classes():
            _suv_resource.unregister_class(UVSUITE_PT_ALWAYS_ON_TOGGLE)
    except Exception:
        pass


def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator('smart_uv_suite.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator('smart_uv_suite.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator('smart_uv_suite.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator('smart_uv_suite.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


def _is_main_smart_uv_root_panel(cls):
    try:
        name = str(getattr(cls, '__name__', '') or '')
        bl_idname = str(getattr(cls, 'bl_idname', '') or '')
    except Exception:
        return False
    return name in {'UVSUITE_PT_UV_MAIN_SMARTUVSUITE_PT_NPANEL_BOOTSTRAP', 'UVSUITE_PT_UV_MAIN_SMARTUVSUITE_PT_VIEW3D_NPANEL', 'UVSUITE_PT_UV_MAIN_SMARTUVSUITE_PT_UV_EDITOR_NPANEL'} or bl_idname in {'UVSUITE_PT_UV_MAIN_SMARTUVSUITE_PT_NPANEL_BOOTSTRAP', 'SMARTUVSUITE_PT_view3d_npanel', 'SMARTUVSUITE_PT_uv_editor_npanel', 'UVSUITE_PT_UV_MAIN_SMARTUVSUITE_PT_UV_EDITOR_NPANEL'}


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = getattr(bpy.props, prop_name)
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Legacy compatibility properties must be explicitly opted in.
        # Injecting generic fields such as mode/action/topic into every
        # operator makes Blender auto-draw unrelated controls in popups and
        # can change the RNA schema of otherwise display-only operators.
        legacy_props = tuple(getattr(cls, '_sms_legacy_operator_props', ()) or ())
        for prop_name in legacy_props:
            if prop_name not in {'mode', 'action', 'topic'} or prop_name in annotations:
                continue
            try:
                annotations[prop_name] = bpy.props.StringProperty(
                    default='',
                    options={'SKIP_SAVE'},
                    description='Compatibility-only operator parameter explicitly requested by this operator.',
                )
                changed = True
            except Exception:
                pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls




def _is_addon_preferences_class(cls):
    try:
        return isinstance(cls, type) and issubclass(cls, bpy.types.AddonPreferences)
    except Exception:
        return False


def _capture_addon_preferences_class(cls) -> bool:
    if not _is_addon_preferences_class(cls):
        return False
    # UV Suite exposes all settings in the N-panel.  Legacy integrated
    # AddonPreferences classes are captured as proxy settings so their RNA
    # properties can still be read/written without opening Blender's Add-ons
    # preferences UI.
    try:
        from . import preferences_proxy as _preferences_proxy
        register = getattr(_preferences_proxy, 'register_preferences_class', None)
        if callable(register):
            register(cls)
    except Exception:
        pass
    return True

def _safe_unregister_class(cls):
    try:
        from . import ownership_runtime_18168 as _ownership
        return bool(_ownership.unregister_class(cls))
    except Exception:
        return False


def _register_class_wrapper(cls):
    """Compatibility helper: register only the explicit class through the ledger."""
    _materialize_annotations(cls)
    if _capture_addon_preferences_class(cls):
        return None
    from . import ownership_runtime_18168 as _ownership
    if not _ownership.register_class(cls):
        raise RuntimeError(f"Smart UV class registration failed: {getattr(cls, '__name__', cls)!s}")
    return None


def begin_register():
    """Compatibility no-op; Blender registration APIs are never replaced."""
    return None


def end_register():
    """Compatibility no-op; Blender registration APIs are never replaced."""
    return None


def _iter_relevant_panels():
    """Legacy broad panel discovery is disabled; roots are explicit in npanel_body_1881."""
    return iter(())


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    return None


def _unpatch_panel_headers():
    return None


def _iter_relevant_addon_preferences():
    prefix = _module_prefix()
    values = []
    try:
        for name in ():# disabled explicit legacy iteration
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _patch_addon_preferences():
    return None


def _unpatch_addon_preferences():
    return None


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    prefixes = ('smart_', 'ui_', 'enable_', 'show_', 'use_', 'auto_', 'sfs_', 'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'sms_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_', 'uv_', 'sw_', 'st_', 'sk_', 'sss_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            # preferences.py owns this group in the canonical
            # Smart_UV_Suite.json. Keeping a second copy in the legacy common
            # snapshot allowed its load_post handler to overwrite canonical
            # foldout/toggle values with stale defaults.
            if identifier == 'uv_suite_tool_runtime_settings_v520':
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        try:
            # ``Scene.suv_workspace`` is owned by npanel_persistence and the
            # canonical Smart_UV_Suite.json.  Older broad snapshots contain a
            # second, stale copy that otherwise runs after the canonical load
            # handler and resets a newly selected scene back to old defaults.
            if str(key) in {'suv_workspace', 'uv_suite_tool_runtime_settings_v520'}:
                continue
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _LOADED_SETTINGS or load_settings_file()
    for root_name, root in _iter_setting_roots(ctx):
        if root_name in data:
            _apply_group(root, data[root_name], 0)


def load_settings_file():
    global _LOADED_SETTINGS
    # The N-panel settings live in Smart_UV_Suite.json (store "n_panel_settings").  The old
    # n_panel_settings.json is read once to carry its content over and is never written again.
    try:
        from . import npanel_persistence as _store
        raw = _store.get_store('n_panel_settings')
        if raw is None:
            legacy_path = legacy_settings_path()
            if legacy_path.exists():
                legacy = json.loads(legacy_path.read_text(encoding='utf-8'))
                if isinstance(legacy, dict):
                    _store.set_store('n_panel_settings', legacy)
                    raw = legacy
        if isinstance(raw, dict):
            _LOADED_SETTINGS = raw
            return raw
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    _AUTOSAVE_FINGERPRINT = raw
    try:
        from . import npanel_persistence as _store
        _store.set_store('n_panel_settings', data)
    except Exception:
        pass


def flush_all_persistent_state(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    try:
        save_persistent_settings(ctx, force=True)
    except Exception:
        pass
    for module_name, function_names in (
        ('preferences', ('flush_settings', 'save_settings')),
        ('npanel_persistence', ('flush_all', 'save_state')),
        ('preferences_proxy', ('save_all_proxy_values', 'save_proxy_values')),
    ):
        try:
            module = __import__(f'{__package__}.{module_name}', fromlist=['*']) if __package__ else None
        except Exception:
            module = None
        if module is None:
            continue
        for function_name in function_names:
            fn = getattr(module, function_name, None)
            if not callable(fn):
                continue
            try:
                try:
                    fn(ctx)
                except TypeError:
                    fn()
            except Exception:
                pass
            break


def _autosave_timer():
    # Legacy compatibility target only.  Continuous persistence is centralized
    # in npanel_persistence and controlled by N-panel State Save.
    return None


@persistent
def _load_post_handler(dummy=None):
    try:
        # The legacy common store restores only WindowManager/Scene UI values.
        # It does not assign Object transforms, so a scene-wide transform guard
        # would add pure load-time overhead.
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    # 1.8.169: Smart UV registers no persistent lifecycle handlers from common.py.
    return None


def _remove_handler(collection, handler):
    return None


def register():
    """Register only Smart UV-owned common RNA and exact lifecycle resources."""
    from . import ownership_runtime_18168 as _ownership
    _ownership.register_translation(PACKAGE_ID, _translation_payload())
    _load_previews()
    try:
        _ownership.register_property(
            bpy.types.WindowManager,
            _ALWAYS_ON_PROP,
            BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this Smart UV feature.',
                default=False,
            ),
        )
    except Exception:
        pass
    for cls in (SMART_UV_OT_open_help, SMART_UV_OT_set_always_on, SMART_UV_OT_save_preferences):
        _materialize_annotations(cls)
        if _ownership.register_class(cls) and cls not in _REGISTERED_CLASSES:
            _REGISTERED_CLASSES.append(cls)
    try:
        load_settings_file()
        apply_persistent_settings(getattr(bpy, 'context', None))
    except Exception:
        pass



def unregister():
    """Unregister only identities recorded by this package generation."""
    from . import ownership_runtime_18168 as _ownership
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        try:
            _ownership.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    _remove_previews()
    _ownership.unregister_translation(PACKAGE_ID)

