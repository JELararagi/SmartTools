# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.118: exact UV/mesh selection preservation for UV Align.

UV alignment must use the UV Editor selection as its operation scope, but it
must not rewrite the user's 3D View mesh selection.  This layer snapshots UV
loop-selection flags and mesh selection flags separately, uses the UV snapshot
for align scope while the operator runs, and restores both domains exactly after
the operator returns.  It is intentionally UI-neutral: no labels, layout, or
text are changed here.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple
from functools import lru_cache

import bpy

_VERSION = (1, 8, 118)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_MARK = "_suv_18118_exact_selection_preserve"
_SELECTION_CONTEXT_MARK = "_suv_18118_exact_selection_context"
_EXACT_SCOPE_DEPTH = 0
_EXACT_SNAPSHOT_STACK: List[List[Dict[str, Any]]] = []

_DIRECT_CLASS_NAMES: Set[str] = {
    "SMARTUVSUITE_OT_vertex_align_action",
    "SMARTUVSUITE_OT_island_direction_align",
    "SMARTUVSUITE_OT_uv_layout_action",
    "SMARTUVSUITE_OT_direction_align",
    "SMARTUVSUITE_OT_direction_align_action",
    "SMARTUVSUITE_OT_direction_align_mode",
}
_FLOW_ALIGN_CLASS_NAMES: Set[str] = {
    "SUV_OT_align_islands",
    "SUV_OT_centralize_islands",
    "SUV_OT_distribute_islands",
    "SUV_OT_rotate_islands",
    "SUV_OT_flip_islands",
    "SUV_OT_uv_straight_line",
    "SUV_OT_uv_set_flow",
    "SUV_OT_hs_gridify",
    "SUV_OT_hs_rectify_fit",
    "SUV_OT_hs_rectify_constrained",
    "SUV_OT_hs_quad_flow",
    "SUV_OT_apply_line_flow_preset",
}
_NATIVE_ALIGN_ACTIONS: Set[str] = {
    "FIT", "FILL", "CROP", "ALIGN_CENTER", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM",
    "ROTATE_90", "ROTATE_CCW", "ROTATE_CW", "FLIP_U", "FLIP_V", "STRAIGHTEN", "GRIDIFY", "CIRCLE",
    "RELAX", "RANDOMIZE", "SNAP_GRID", "SNAP_PIXEL", "SNAP_VERTEX",
}
_LAYOUT_ALIGN_ACTIONS: Set[str] = {
    "ALIGN_TL", "ALIGN_TOP", "ALIGN_TR", "ALIGN_LEFT", "ALIGN_CENTER", "ALIGN_RIGHT",
    "ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR", "ALIGN_H", "ALIGN_V",
    "DISTRIBUTE_H", "DISTRIBUTE_V", "ALIGN_H_GROUP", "ALIGN_V_GROUP",
    "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP", "ROTATE_CCW", "ROTATE_CW",
    "MIRROR_H", "MIRROR_V", "FLIP_H", "FLIP_V", "ORIENT_BBOX", "ORIENT_EDGE",
    "STRAIGHT", "RECTIFY", "GRIDIFY", "SQUAREIFY", "CROP", "FILL", "FIT", "RELAX",
}
_STAGE_LAYOUT_MODES: Set[str] = {
    "FIT", "FILL", "CROP", "CENTER", "ALIGN_CENTER", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM",
    "DISTRIBUTE_H", "DISTRIBUTE_V", "ROTATE_90", "FLIP_U", "FLIP_V", "GRIDIFY", "RECTIFY", "STRAIGHTEN",
}
_STAGE_WORKFLOW_MODES: Set[str] = {
    "ALIGN", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM", "ALIGN_CENTER",
    "STRAIGHTEN", "RECTIFY", "GRIDIFY", "RELAX", "DISTRIBUTE_H", "DISTRIBUTE_V",
}
_REGISTERED_ALIGN_TOKENS = (
    ".align", "_align", "align_", "straight", "rectify", "gridify", "circle",
    "centralize", "distribute", "orient", "rotate_islands", "flip_islands",
    "set_flow", "line_flow_preset",
)
_REGISTERED_EXCLUDE_TOKENS = ("select_", ".select", "_select", "selection", "sync_mode_toggle")
_REGISTERED_DIRECT_CLASS_NAMES_LOWER = frozenset(
    name.lower() for name in (_DIRECT_CLASS_NAMES | _FLOW_ALIGN_CLASS_NAMES)
)



def _tool_settings(context: Any = None) -> Any:
    ctx = context or getattr(bpy, "context", None)
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _snapshot_tool_state(context: Any = None) -> Dict[str, Any]:
    ts = _tool_settings(context)
    state: Dict[str, Any] = {}
    if ts is None:
        return state
    for name in ("use_uv_select_sync", "mesh_select_mode", "uv_select_mode", "uv_sticky_select_mode"):
        try:
            value = getattr(ts, name)
            if name == "mesh_select_mode":
                try:
                    value = tuple(bool(v) for v in value)
                except Exception:
                    pass
            state[name] = value
        except Exception:
            pass
    return state


def _restore_tool_state(context: Any = None, state: Optional[Dict[str, Any]] = None) -> None:
    if not state:
        return
    ts = _tool_settings(context)
    if ts is None:
        return
    for name in ("mesh_select_mode", "uv_select_mode", "uv_sticky_select_mode", "use_uv_select_sync"):
        if name not in state:
            continue
        try:
            value = state[name]
            current = getattr(ts, name)
            if name == "mesh_select_mode":
                try:
                    current = tuple(bool(v) for v in current)
                except Exception:
                    pass
            if current != value:
                setattr(ts, name, value)
        except Exception:
            pass


def _edit_objects(context: Any = None) -> List[Any]:
    ctx = context or getattr(bpy, "context", None)
    objs: List[Any] = []
    try:
        objs = [o for o in (getattr(ctx, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
    except Exception:
        objs = []
    if not objs:
        try:
            obj = getattr(ctx, "edit_object", None) or getattr(ctx, "active_object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
                objs = [obj]
        except Exception:
            pass
    out: List[Any] = []
    seen: Set[int] = set()
    for obj in objs:
        try:
            mesh = getattr(obj, "data", None)
            key = int(mesh.as_pointer()) if mesh is not None and hasattr(mesh, "as_pointer") else id(mesh or obj)
        except Exception:
            key = id(obj)
        if key in seen:
            continue
        seen.add(key)
        out.append(obj)
    return out


def _idx(elem: Any) -> int:
    try:
        return int(getattr(elem, "index", -1))
    except Exception:
        return -1


def _ensure_lookup(bm: Any) -> None:
    for seq in (getattr(bm, "verts", None), getattr(bm, "edges", None), getattr(bm, "faces", None)):
        try:
            seq.ensure_lookup_table()
        except Exception:
            pass
        try:
            seq.index_update()
        except Exception:
            pass


def _uv_layer_for_bmesh(bm: Any) -> Any:
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _mesh_pointer(obj: Any) -> int:
    try:
        mesh = getattr(obj, "data", None)
        if mesh is not None and hasattr(mesh, "as_pointer"):
            return int(mesh.as_pointer())
    except Exception:
        pass
    return id(getattr(obj, "data", obj))


def _get_loop_flag(loop: Any, name: str) -> bool:
    try:
        return bool(getattr(loop, name, False))
    except Exception:
        return False


def _get_luv_flag(loop: Any, uv_layer: Any, name: str) -> bool:
    try:
        return bool(getattr(loop[uv_layer], name, False))
    except Exception:
        return False


def _set_loop_flag(loop: Any, uv_layer: Any, name: str, value: bool) -> None:
    value = bool(value)
    if name == "uv_select_vert":
        try:
            loop.uv_select_vert_set(value)
        except Exception:
            try:
                setattr(loop, "uv_select_vert", value)
            except Exception:
                pass
        try:
            setattr(loop[uv_layer], "select", value)
        except Exception:
            pass
        return
    if name == "uv_select_edge":
        try:
            loop.uv_select_edge_set(value)
        except Exception:
            try:
                setattr(loop, "uv_select_edge", value)
            except Exception:
                pass
        try:
            setattr(loop[uv_layer], "select_edge", value)
        except Exception:
            pass


def _set_face_uv(face: Any, value: bool) -> None:
    value = bool(value)
    try:
        fn = getattr(face, "uv_select_set", None)
        if callable(fn):
            fn(value)
            return
    except Exception:
        pass
    try:
        setattr(face, "uv_select", value)
    except Exception:
        pass


def _select_elem(elem: Any, value: bool) -> None:
    try:
        elem.select_set(bool(value))
    except Exception:
        try:
            setattr(elem, "select", bool(value))
        except Exception:
            pass


def _face_uv_selected_from_loops(loop_states: Dict[int, Dict[str, Any]], face: Any) -> bool:
    try:
        loops = list(face.loops)
    except Exception:
        loops = []
    if not loops:
        return False
    all_vert = True
    all_edge = True
    for loop in loops:
        state = loop_states.get(_idx(loop), {})
        all_vert = all_vert and bool(state.get("uv_vert", False) or state.get("luv_select", False))
        all_edge = all_edge and bool(state.get("uv_edge", False) or state.get("luv_select_edge", False))
    return bool(all_vert or all_edge)


def _sync_uv_flags_from_mesh(context: Any, bm: Any) -> None:
    """With UV Sync on and stale UV flags, the mesh selection is the selection: copy it to the UV flags."""
    settings = getattr(context, "tool_settings", None)
    if settings is None or not bool(getattr(settings, "use_uv_select_sync", False)):
        return
    if bool(getattr(bm, "uv_select_sync_valid", True)):
        return
    bm.uv_select_sync_from_mesh(sticky_select_mode=str(getattr(settings, "uv_sticky_select_mode", "SHARED_LOCATION")))


def snapshot_exact_selection(context: Any = None) -> List[Dict[str, Any]]:
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return []
    try:
        import bmesh
    except Exception:
        return []
    tool_state = _snapshot_tool_state(ctx)
    out: List[Dict[str, Any]] = []
    for obj in _edit_objects(ctx):
        try:
            mesh = getattr(obj, "data", None)
            if mesh is None:
                continue
            bm = bmesh.from_edit_mesh(mesh)
            _ensure_lookup(bm)
            _sync_uv_flags_from_mesh(ctx, bm)
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
            item: Dict[str, Any] = {
                "obj": obj,
                "mesh": mesh,
                "mesh_ptr": _mesh_pointer(obj),
                "tool_state": dict(tool_state),
                "verts": {},
                "edges": {},
                "faces": {},
                "loops": {},
            }
            for vert in bm.verts:
                item["verts"][_idx(vert)] = bool(getattr(vert, "select", False))
            for edge in bm.edges:
                item["edges"][_idx(edge)] = bool(getattr(edge, "select", False))
            for face in bm.faces:
                try:
                    face_uv = bool(getattr(face, "uv_select", False))
                except Exception:
                    face_uv = False
                item["faces"][_idx(face)] = {"mesh": bool(getattr(face, "select", False)), "uv": face_uv}
                try:
                    loops = list(face.loops)
                except Exception:
                    loops = []
                for loop in loops:
                    li = _idx(loop)
                    state = {
                        "uv_vert": _get_loop_flag(loop, "uv_select_vert"),
                        "uv_edge": _get_loop_flag(loop, "uv_select_edge"),
                        "luv_select": _get_luv_flag(loop, uv_layer, "select"),
                        "luv_select_edge": _get_luv_flag(loop, uv_layer, "select_edge"),
                        "face": _idx(face),
                        "vert": _idx(getattr(loop, "vert", None)),
                        "edge": _idx(getattr(loop, "edge", None)),
                        "next_loop": _idx(getattr(loop, "link_loop_next", None)),
                    }
                    item["loops"][li] = state
            out.append(item)
        except Exception:
            continue
    return out


def _restore_item_exact(item: Dict[str, Any], context: Any = None) -> None:
    try:
        import bmesh
    except Exception:
        return
    obj = item.get("obj")
    mesh = item.get("mesh") or getattr(obj, "data", None)
    if obj is None or mesh is None or getattr(obj, "mode", "") != "EDIT":
        return
    try:
        bm = bmesh.from_edit_mesh(mesh)
        _ensure_lookup(bm)
        uv_layer = _uv_layer_for_bmesh(bm)
        if uv_layer is None:
            return
        loop_states: Dict[int, Dict[str, Any]] = dict(item.get("loops") or {})
        face_states: Dict[int, Dict[str, Any]] = dict(item.get("faces") or {})
        vert_states: Dict[int, bool] = dict(item.get("verts") or {})
        edge_states: Dict[int, bool] = dict(item.get("edges") or {})
        face_mode = _mode_from_value(context, None, item) == "FACE"

        # Clear both domains first, then rebuild the exact snapshot.  UV flags are
        # written with Sync temporarily disabled by the caller so the mesh selection
        # is not derived from the UV Editor selection.
        for face in bm.faces:
            _set_face_uv(face, False)
            for loop in list(face.loops):
                _set_loop_flag(loop, uv_layer, "uv_select_edge", False)
                _set_loop_flag(loop, uv_layer, "uv_select_vert", False)
        for face in bm.faces:
            _select_elem(face, False)
        for edge in bm.edges:
            _select_elem(edge, False)
        for vert in bm.verts:
            _select_elem(vert, False)

        for face in bm.faces:
            if bool((face_states.get(_idx(face)) or {}).get("mesh", False)):
                _select_elem(face, True)
        for edge in bm.edges:
            if bool(edge_states.get(_idx(edge), False)):
                _select_elem(edge, True)
        for vert in bm.verts:
            if bool(vert_states.get(_idx(vert), False)):
                _select_elem(vert, True)

        for face in bm.faces:
            fstate = face_states.get(_idx(face)) or {}
            # The face setter selects every corner. In vertex and edge modes
            # the face flag can remain set while only some corners are selected.
            if face_mode and bool(fstate.get("uv", False)):
                _set_face_uv(face, True)
            for loop in list(face.loops):
                state = loop_states.get(_idx(loop), {})
                # False flags were already applied in the clear pass above.  Do
                # not write False again here: Blender 5.1 can propagate a later
                # false write on another loop and clear UV vertices that were
                # just restored on the same face.
                if bool(state.get("uv_edge", False) or state.get("luv_select_edge", False)):
                    _set_loop_flag(loop, uv_layer, "uv_select_edge", True)
                if bool(state.get("uv_vert", False) or state.get("luv_select", False)):
                    _set_loop_flag(loop, uv_layer, "uv_select_vert", True)

        try:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        except TypeError:
            bmesh.update_edit_mesh(mesh)
        except Exception:
            pass
    except Exception:
        return


def restore_exact_selection(snapshot: Sequence[Dict[str, Any]], context: Any = None) -> None:
    if not snapshot:
        return
    ctx = context or getattr(bpy, "context", None)
    ts = _tool_settings(ctx)
    final_state: Dict[str, Any] = {}
    try:
        for item in list(snapshot or []):
            if isinstance(item, dict) and isinstance(item.get("tool_state"), dict):
                final_state = dict(item.get("tool_state") or {})
                break
    except Exception:
        final_state = {}
    old_sync: Optional[bool] = None
    if ts is not None:
        try:
            old_sync = bool(getattr(ts, "use_uv_select_sync", False))
            setattr(ts, "use_uv_select_sync", False)
        except Exception:
            old_sync = None
    try:
        for item in list(snapshot or []):
            if isinstance(item, dict):
                _restore_item_exact(item, ctx)
    finally:
        if ts is not None:
            try:
                if old_sync is not None and bool(getattr(ts, "use_uv_select_sync", False)) != bool(old_sync):
                    setattr(ts, "use_uv_select_sync", old_sync)
            except Exception:
                pass
        if final_state:
            _restore_tool_state(ctx, final_state)


def schedule_exact_selection_restore(snapshot: Sequence[Dict[str, Any]]) -> None:
    if not snapshot:
        return
    try:
        snap = list(snapshot)
    except Exception:
        return
    try:
        state = {"count": 0}

        def _restore_late() -> Optional[float]:
            try:
                restore_exact_selection(snap, bpy.context)
            except Exception:
                pass
            state["count"] = int(state.get("count", 0)) + 1
            if state["count"] < 5:
                return 0.03
            return None

        _suv_resource.timer_register(_restore_late, first_interval=0.0)
    except Exception:
        pass


def _scope_push(snapshot: Sequence[Dict[str, Any]]) -> None:
    global _EXACT_SCOPE_DEPTH
    _EXACT_SCOPE_DEPTH += 1
    try:
        _EXACT_SNAPSHOT_STACK.append(list(snapshot or []))
    except Exception:
        _EXACT_SNAPSHOT_STACK.append([])


def _scope_pop() -> None:
    global _EXACT_SCOPE_DEPTH
    try:
        if _EXACT_SNAPSHOT_STACK:
            _EXACT_SNAPSHOT_STACK.pop()
    except Exception:
        pass
    _EXACT_SCOPE_DEPTH = max(0, int(_EXACT_SCOPE_DEPTH) - 1)


def _scope_active() -> bool:
    try:
        return int(_EXACT_SCOPE_DEPTH) > 0
    except Exception:
        return False


def _snapshot_item_for_mesh(obj: Any, mesh: Any = None) -> Optional[Dict[str, Any]]:
    mesh = mesh or getattr(obj, "data", None)
    try:
        ptr = int(mesh.as_pointer()) if mesh is not None and hasattr(mesh, "as_pointer") else id(mesh)
    except Exception:
        ptr = id(mesh)
    for snapshot in reversed(_EXACT_SNAPSHOT_STACK):
        for item in reversed(list(snapshot or [])):
            try:
                if item.get("obj") is obj or item.get("mesh") is mesh or int(item.get("mesh_ptr", -1)) == ptr:
                    return item
            except Exception:
                continue
    return None


def _mode_from_value(context: Any = None, supplied: Optional[str] = None, item: Optional[Dict[str, Any]] = None) -> str:
    raw = supplied
    if raw is None:
        try:
            state = item.get("tool_state") if isinstance(item, dict) else None
            if isinstance(state, dict):
                if bool(state.get("use_uv_select_sync", False)):
                    mm = tuple(bool(v) for v in state.get("mesh_select_mode", (True, False, False)))
                    if len(mm) >= 3:
                        if mm[2]:
                            return "FACE"
                        if mm[1]:
                            return "EDGE"
                        return "VERTEX"
                raw = state.get("uv_select_mode", None)
        except Exception:
            raw = None
    if raw is None:
        try:
            ts = _tool_settings(context)
            raw = getattr(ts, "uv_select_mode", "VERTEX") if ts is not None else "VERTEX"
        except Exception:
            raw = "VERTEX"
    try:
        if isinstance(raw, (set, list, tuple)):
            vals = {str(v).upper() for v in raw}
            if "FACE" in vals or "ISLAND" in vals:
                return "FACE"
            if "EDGE" in vals:
                return "EDGE"
            return "VERTEX"
        text = str(raw or "VERTEX").upper()
    except Exception:
        text = "VERTEX"
    if "ISLAND" in text or "FACE" in text:
        return "FACE"
    if "EDGE" in text:
        return "EDGE"
    return "VERTEX"


def _selected_sets_from_snapshot_item(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: Optional[str], item: Dict[str, Any]) -> Tuple[Set[Any], Set[Any], Set[Any]]:
    eff_mode = _mode_from_value(context, mode, item)
    loops: Set[Any] = set()
    edge_loops: Set[Any] = set()
    faces: Set[Any] = set()
    loop_states: Dict[int, Dict[str, Any]] = dict(item.get("loops") or {})
    face_states: Dict[int, Dict[str, Any]] = dict(item.get("faces") or {})
    settings = _tool_settings(context)
    uv_sync = bool(getattr(settings, "use_uv_select_sync", False))
    for face in bm.faces:
        # Without UV Sync the mesh selection says which faces the UV editor shows, and
        # Blender keeps UV flags on the faces it hides.
        if not uv_sync and not (face_states.get(_idx(face)) or {}).get("mesh", False):
            continue
        try:
            face_loops = list(face.loops)
        except Exception:
            face_loops = []
        if not face_loops:
            continue
        face_uv = bool((face_states.get(_idx(face)) or {}).get("uv", False)) or _face_uv_selected_from_loops(loop_states, face)
        if eff_mode == "FACE" and face_uv:
            faces.add(face)
            for loop in face_loops:
                loops.add(loop)
                edge_loops.add(loop)
            continue
        for loop in face_loops:
            state = loop_states.get(_idx(loop), {})
            vsel = bool(state.get("uv_vert", False) or state.get("luv_select", False))
            esel = bool(state.get("uv_edge", False) or state.get("luv_select_edge", False))
            if eff_mode == "EDGE":
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try:
                        loops.add(loop.link_loop_next)
                    except Exception:
                        pass
                elif vsel:
                    loops.add(loop)
            elif eff_mode == "FACE":
                if vsel or esel:
                    loops.add(loop)
                    faces.add(face)
                if esel:
                    edge_loops.add(loop)
            else:
                if vsel:
                    loops.add(loop)
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try:
                        loops.add(loop.link_loop_next)
                    except Exception:
                        pass
    return loops, edge_loops, faces


def _selection_context_from_snapshot(context: Any, obj: Any, bm: Any, uv_layer: Any) -> Tuple[List[Any], List[Any], Any, str]:
    item = _snapshot_item_for_mesh(obj, getattr(obj, "data", None))
    if isinstance(item, dict):
        mode = _mode_from_value(context, None, item)
        loops, edge_loops, faces = _selected_sets_from_snapshot_item(context, obj, bm, uv_layer, mode, item)
        if bool(getattr(_tool_settings(context), "use_uv_select_sync", False)):
            # With UV Sync the mesh face selection decides, as in core._selection_from_context.
            # The neighbours of a selected face also carry flags on their shared corners.
            face_states = item.get("faces") or {}
            sel_list = [f for f in bm.faces if (face_states.get(_idx(f)) or {}).get("mesh", False)]
            active_face = getattr(getattr(bm, "faces", None), "active", None)
            if active_face not in sel_list:
                active_face = sel_list[0] if sel_list else None
            return sel_list, [l for f in sel_list for l in f.loops], active_face, "UV_EDITOR_EXACT_SNAPSHOT"
        sel_faces: Set[Any] = set(faces or set())
        for loop in list(loops or set()) + list(edge_loops or set()):
            try:
                sel_faces.add(loop.face)
            except Exception:
                pass
        active_face = getattr(getattr(bm, "faces", None), "active", None)
        if active_face not in sel_faces:
            active_face = next(iter(sel_faces), None)
        return list(sel_faces), list(loops or set()), active_face, "UV_EDITOR_EXACT_SNAPSHOT"
    return [], [], None, "UV_EDITOR_EXACT_EMPTY"


def _patch_room_integrity_selection_sets() -> None:
    try:
        from . import uv_room_integrity_18103 as ri
    except Exception:
        return
    try:
        cur = getattr(ri, "_selected_sets", None)
        if getattr(cur, _SELECTION_CONTEXT_MARK, False):
            return
        _PREV.setdefault("ri._selected_sets.18118", cur)

        def selected_sets_exact(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: Optional[str] = None):
            if _scope_active():
                item = _snapshot_item_for_mesh(obj, getattr(obj, "data", None))
                if isinstance(item, dict):
                    return _selected_sets_from_snapshot_item(context, obj, bm, uv_layer, mode, item)
            old = _PREV.get("ri._selected_sets.18118")
            if callable(old):
                return old(context, obj, bm, uv_layer, mode)
            return set(), set(), set()

        setattr(selected_sets_exact, _SELECTION_CONTEXT_MARK, True)
        ri._selected_sets = selected_sets_exact
    except Exception:
        pass


def _patch_selection_from_context(ns: Optional[Dict[str, Any]] = None) -> None:
    modules: List[Any] = []
    for mod_name in ("core", "ui", "flow"):
        try:
            modules.append(__import__(f"{__package__}.{mod_name}", fromlist=[mod_name]))
        except Exception:
            pass
    if isinstance(ns, dict):
        modules.append(type("_NSProxy", (), {"__dict__": ns})())
    for mod in modules:
        try:
            cur = getattr(mod, "_selection_from_context", None)
            if not callable(cur) or getattr(cur, _SELECTION_CONTEXT_MARK, False):
                continue
            key = f"{getattr(mod, '__name__', 'ns')}._selection_from_context.18118"
            _PREV.setdefault(key, cur)

            def selection_from_context_exact(context: Any, obj: Any, bm: Any, uv_layer: Any, _old: Callable = cur):
                if _scope_active():
                    item = _snapshot_item_for_mesh(obj, getattr(obj, "data", None))
                    if isinstance(item, dict):
                        return _selection_context_from_snapshot(context, obj, bm, uv_layer)
                return _old(context, obj, bm, uv_layer)

            setattr(selection_from_context_exact, _SELECTION_CONTEXT_MARK, True)
            try:
                setattr(mod, "_selection_from_context", selection_from_context_exact)
            except Exception:
                pass
        except Exception:
            pass
    if isinstance(ns, dict):
        try:
            cur = ns.get("_selection_from_context")
            if callable(cur) and not getattr(cur, _SELECTION_CONTEXT_MARK, False):
                _PREV.setdefault("ns._selection_from_context.18118", cur)

                def ns_selection_from_context_exact(context: Any, obj: Any, bm: Any, uv_layer: Any, _old: Callable = cur):
                    if _scope_active():
                        item = _snapshot_item_for_mesh(obj, getattr(obj, "data", None))
                        if isinstance(item, dict):
                            return _selection_context_from_snapshot(context, obj, bm, uv_layer)
                    return _old(context, obj, bm, uv_layer)

                setattr(ns_selection_from_context_exact, _SELECTION_CONTEXT_MARK, True)
                ns["_selection_from_context"] = ns_selection_from_context_exact
        except Exception:
            pass


def _patch_18117_mesh_restore() -> None:
    try:
        from . import uv_sync_selection_preserve_18117 as sp
    except Exception:
        return
    try:
        cur = getattr(sp, "_restore_mesh_support_from_uv", None)
        if getattr(cur, "_suv_18118_exact_mesh_restore", False):
            return
        _PREV.setdefault("18117._restore_mesh_support_from_uv", cur)

        def restore_original_mesh_flags(bm: Any, item: Dict[str, Any]) -> None:
            verts = item.get("verts") or {}
            edges = item.get("edges") or {}
            faces = item.get("faces") or {}
            for face in bm.faces:
                try:
                    face.select_set(bool((faces.get(_idx(face)) or {}).get("mesh", False)))
                except Exception:
                    pass
            for edge in bm.edges:
                try:
                    edge.select_set(bool(edges.get(_idx(edge), False)))
                except Exception:
                    pass
            for vert in bm.verts:
                try:
                    vert.select_set(bool(verts.get(_idx(vert), False)))
                except Exception:
                    pass

        setattr(restore_original_mesh_flags, "_suv_18118_exact_mesh_restore", True)
        sp._restore_mesh_support_from_uv = restore_original_mesh_flags
    except Exception:
        pass


def _patch_direction_align_direct(ns: Optional[Dict[str, Any]] = None) -> None:
    try:
        from . import uv_direction_align_unified_18111 as uni
    except Exception:
        return

    def _direct_execute(self: Any, context: Any):
        action = str(getattr(self, "action", "ALIGN_CENTER") or "ALIGN_CENTER").upper()
        try:
            return uni._execute_direction_align_backend(self, context, action)
        except Exception as exc:
            try:
                self.report({"WARNING"}, f"方向整列に失敗しました。 {exc}")
            except Exception:
                pass
            return {"CANCELLED"}

    try:
        setattr(_direct_execute, "_suv_18118_direct_direction_backend", True)
    except Exception:
        pass
    for name in ("SMARTUVSUITE_OT_direction_align", "SMARTUVSUITE_OT_direction_align_action"):
        for cls in (getattr(uni, name, None), (ns or {}).get(name) if isinstance(ns, dict) else None):
            try:
                if isinstance(cls, type):
                    cur = getattr(cls, "execute", None)
                    if not getattr(cur, "_suv_18118_direct_direction_backend", False):
                        _PREV.setdefault(f"direction_direct.{name}", cur)
                        cls.execute = _direct_execute
            except Exception:
                pass


def _should_preserve(self_obj: Any, filter_kind: Optional[str]) -> bool:
    if filter_kind == "native_action":
        try:
            action = str(getattr(self_obj, "action", getattr(self_obj, "mode", "")) or "").upper()
            return action in _NATIVE_ALIGN_ACTIONS or action.startswith("ALIGN_")
        except Exception:
            return False
    if filter_kind == "layout_action":
        try:
            action = str(getattr(self_obj, "action", "") or "").upper()
            return action in _LAYOUT_ALIGN_ACTIONS or action.startswith("ALIGN_") or action.startswith("DISTRIBUTE_")
        except Exception:
            return False
    if filter_kind == "stage_layout":
        try:
            mode = str(getattr(self_obj, "mode", "") or "").upper()
            return mode in _STAGE_LAYOUT_MODES or mode.startswith("ALIGN_")
        except Exception:
            return False
    if filter_kind == "stage_workflow":
        try:
            mode = str(getattr(self_obj, "mode", "") or "").upper()
            return mode in _STAGE_WORKFLOW_MODES or mode.startswith("ALIGN_")
        except Exception:
            return False
    return True


def _wrap_execute_exact(cls: Any, key: str, filter_kind: Optional[str] = None) -> None:
    try:
        if not isinstance(cls, type):
            return
        cur = getattr(cls, "execute", None)
        if not callable(cur) or getattr(cur, _MARK, False):
            return
        _PREV.setdefault(key, cur)

        def execute_exact_preserve(self: Any, context: Any, *args: Any, _old: Callable = cur, _filter: Optional[str] = filter_kind, **kwargs: Any):
            if not _should_preserve(self, _filter):
                return _old(self, context, *args, **kwargs)
            snapshot = snapshot_exact_selection(context)
            _scope_push(snapshot)
            try:
                return _old(self, context, *args, **kwargs)
            finally:
                _scope_pop()
                restore_exact_selection(snapshot, context)
                schedule_exact_selection_restore(snapshot)

        setattr(execute_exact_preserve, _MARK, True)
        setattr(execute_exact_preserve, "_suv_18118_previous_execute", cur)
        cls.execute = execute_exact_preserve
    except Exception:
        pass


def _patch_direct_classes(ns: Dict[str, Any]) -> None:
    for name in _DIRECT_CLASS_NAMES:
        try:
            _wrap_execute_exact(ns.get(name), f"ns.{name}.execute", "layout_action" if name == "SMARTUVSUITE_OT_uv_layout_action" else None)
        except Exception:
            pass


def _patch_direction_module(ns: Dict[str, Any]) -> None:
    try:
        from . import uv_direction_align_unified_18111 as uni
    except Exception:
        return
    for name in ("SMARTUVSUITE_OT_direction_align", "SMARTUVSUITE_OT_direction_align_action", "SMARTUVSUITE_OT_direction_align_mode"):
        try:
            _wrap_execute_exact(getattr(uni, name, None), f"direction.{name}.execute")
        except Exception:
            pass
        try:
            _wrap_execute_exact(ns.get(name), f"nsdirection.{name}.execute")
        except Exception:
            pass


def _patch_flow_classes(ns: Dict[str, Any]) -> None:
    modules: List[Any] = []
    try:
        from . import flow as flow_mod
        modules.append(flow_mod)
    except Exception:
        pass
    for name in _FLOW_ALIGN_CLASS_NAMES:
        try:
            _wrap_execute_exact(ns.get(name), f"ns.{name}.execute")
        except Exception:
            pass
        for mod in modules:
            try:
                _wrap_execute_exact(getattr(mod, name, None), f"{getattr(mod, '__name__', 'flow')}.{name}.execute")
            except Exception:
                pass


def _patch_native_classes(ns: Dict[str, Any]) -> None:
    try:
        from . import native_unified_tools as nut
    except Exception:
        nut = None
    if nut is not None:
        for name in ("SMARTUVSUITE_OT_native_align_action", "SMARTUVSUITE_OT_native_hub_action"):
            try:
                _wrap_execute_exact(getattr(nut, name, None), f"native.{name}.execute", "native_action")
            except Exception:
                pass
            try:
                _wrap_execute_exact(ns.get(name), f"ns.{name}.execute", "native_action")
            except Exception:
                pass
    try:
        from . import native_stage as stage
    except Exception:
        stage = None
    if stage is not None:
        try:
            _wrap_execute_exact(getattr(stage, "SUV_OT_native_stage_layout", None), "stage.layout.execute", "stage_layout")
        except Exception:
            pass
        try:
            _wrap_execute_exact(getattr(stage, "SUV_OT_native_stage_workflow", None), "stage.workflow.execute", "stage_workflow")
        except Exception:
            pass


@lru_cache(maxsize=2048)
def _registered_operator_tokens_are_align(blid: str, name: str) -> bool:
    """Classify stable RNA identifiers once per loaded operator class."""
    if not blid.startswith(("smart_uv_suite.", "uv.suv_")):
        return False
    if any(token in blid or token in name for token in _REGISTERED_EXCLUDE_TOKENS):
        return False
    if name in _REGISTERED_DIRECT_CLASS_NAMES_LOWER:
        return True
    if blid.startswith("smart_uv_suite.align"):
        return True
    if blid in {
        "smart_uv_suite.seam_rectify",
        "smart_uv_suite.inspect_orient_world",
        "smart_uv_suite.inspect_circle",
        "smart_uv_suite.inspect_straight",
        "smart_uv_suite.inspect_orient",
        "smart_uv_suite.inspect_apply_line_flow_preset",
    }:
        return True
    if blid.startswith("smart_uv_suite."):
        return False
    if blid.startswith(("uv.suv_texel", "uv.suv_density", "uv.suv_group_normalize_layout", "uv.suv_constraint_relax_preserve")):
        return False
    text = name + " " + blid
    return any(token in text for token in _REGISTERED_ALIGN_TOKENS)


def _registered_operator_is_align(cls: Any) -> bool:
    try:
        blid = str(getattr(cls, "bl_idname", "") or "").lower()
        name = str(getattr(cls, "__name__", "") or "").lower()
    except Exception:
        return False
    return _registered_operator_tokens_are_align(blid, name)


def _filter_for_registered_operator(cls: Any) -> Optional[str]:
    try:
        blid = str(getattr(cls, "bl_idname", "") or "").lower()
    except Exception:
        blid = ""
    if "native_hub_action" in blid or "native_align_action" in blid:
        return "native_action"
    if "native_stage_layout" in blid:
        return "stage_layout"
    if "native_stage_workflow" in blid:
        return "stage_workflow"
    try:
        if str(getattr(cls, "__name__", "") or "") == "SMARTUVSUITE_OT_uv_layout_action":
            return "layout_action"
    except Exception:
        pass
    return None


def _patch_registered_align_classes() -> None:
    try:
        classes = list(())
    except Exception:
        classes = []
    for cls in classes:
        try:
            if _registered_operator_is_align(cls):
                _wrap_execute_exact(cls, f"registered.{getattr(cls, 'bl_idname', '')}.execute", _filter_for_registered_operator(cls))
        except Exception:
            pass


def _mark_version(ns: Optional[Dict[str, Any]] = None) -> None:
    source = ns if isinstance(ns, dict) else _NS
    try:
        if isinstance(source, dict):
            source["__version__"] = '1.0.0'
            info = source.get("bl_info")
            if isinstance(info, dict):
                info["version"] = (1, 0, 0)
                info["author"] = "JELararagi"
                source["_SUS_BL_INFO_FALLBACK"] = dict(info)
    except Exception:
        pass


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    source = ns if isinstance(ns, dict) else _NS
    if not isinstance(source, dict):
        return
    _patch_18117_mesh_restore()
    _patch_room_integrity_selection_sets()
    _patch_selection_from_context(source)
    _patch_direction_align_direct(source)
    _patch_direct_classes(source)
    _patch_direction_module(source)
    _patch_flow_classes(source)
    _patch_native_classes(source)
    _patch_registered_align_classes()
    _mark_version(source)


apply_all = install


def register() -> None:
    install(_NS, bpy.context)


def unregister() -> None:
    return None


def diagnostics(context: Any = None) -> Dict[str, Any]:
    return {
        "version": _VERSION,
        "exact_uv_selection_restore": True,
        "exact_mesh_selection_restore": True,
        "uv_editor_snapshot_scope": True,
    }
