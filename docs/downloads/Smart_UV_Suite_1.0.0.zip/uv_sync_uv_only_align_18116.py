# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Smart UV Suite 1.8.116: UV-sync ON alignment uses UV Editor selection only.

The UV Align tools must behave like UV Select Sync is OFF when deciding the
operation target: only UV Editor-selected loops/edges/faces are alignment
records.  Mesh vertex/edge/face selection created by the 3D View or by Sync is
not accepted as an alignment target.
"""
from __future__ import annotations
from . import resource_api_18168 as _suv_resource

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple
import math

import bpy
from mathutils import Vector

from . import uv_room_integrity_18103 as ri
from . import uv_multi_object_18104 as mo
from . import uv_loop_group_integrity_18109 as lgi
from . import uv_sync_group_snap_18113 as sgs

_VERSION = (1, 8, 116)
_NS: Dict[str, Any] = {}
_PREV: Dict[str, Any] = {}
_EPS = 1.0e-12
_DIGITS = 7
_VERTEX_ACTIONS = {
    "ALIGN_TL", "ALIGN_TOP", "ALIGN_TR", "ALIGN_LEFT", "ALIGN_CENTER", "ALIGN_RIGHT",
    "ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR", "ALIGN_H", "ALIGN_V",
    "ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H", "DISTRIBUTE_V",
    "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP", "FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW",
}
_GROUP_ACTIONS = {"ALIGN_H_GROUP", "ALIGN_V_GROUP", "DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_GROUP_DISTRIBUTE_ACTIONS = {"DISTRIBUTE_H_GROUP", "DISTRIBUTE_V_GROUP"}
_ISLAND_ACTIONS = {
    "ALIGN_TL", "ALIGN_TOP", "ALIGN_TR", "ALIGN_LEFT", "ALIGN_CENTER", "ALIGN_RIGHT",
    "ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR", "ALIGN_H", "ALIGN_V",
    "DISTRIBUTE_H", "DISTRIBUTE_V", "MIRROR_H", "MIRROR_V", "FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW",
}


def _s(value: Any) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _tr(context: Any, en: str, ja: str) -> str:
    try:
        return ri._tr(context, en, ja)
    except Exception:
        try:
            fn = _NS.get("_sus_text") if isinstance(_NS, dict) else None
            if callable(fn):
                return str(fn(en, ja, context))
        except Exception:
            pass
        try:
            lang = str(getattr(getattr(context, "preferences", None).view, "language", "") or "")
            return ja if lang.startswith("ja") else en
        except Exception:
            return ja or en


def _report(op: Any, level: str, message: str) -> None:
    try:
        op.report({level}, message)
    except Exception:
        pass


def _tool_settings(context: Any = None) -> Any:
    ctx = context or getattr(bpy, "context", None)
    try:
        ts = getattr(ctx, "tool_settings", None)
        if ts is not None:
            return ts
    except Exception:
        pass
    try:
        return getattr(getattr(ctx, "scene", None), "tool_settings", None)
    except Exception:
        return None


def _sync_on(context: Any = None) -> bool:
    try:
        return bool(getattr(_tool_settings(context), "use_uv_select_sync", False))
    except Exception:
        return False


def _effective_uv_mode(context: Any = None) -> str:
    """Return the UI selection mode, but never use mesh selection as a target."""
    ts = _tool_settings(context)
    if ts is not None and _sync_on(context):
        try:
            mesh_mode = tuple(bool(v) for v in getattr(ts, "mesh_select_mode", (True, False, False)))
            if len(mesh_mode) >= 3:
                if mesh_mode[2]:
                    return "FACE"
                if mesh_mode[1]:
                    return "EDGE"
                return "VERTEX"
        except Exception:
            pass
    try:
        raw = getattr(ts, "uv_select_mode", "VERTEX") if ts is not None else "VERTEX"
        if isinstance(raw, (set, list, tuple)):
            vals = {str(v).upper() for v in raw}
            if "FACE" in vals or "ISLAND" in vals:
                return "FACE"
            if "EDGE" in vals:
                return "EDGE"
            return "VERTEX"
        text = str(raw or "VERTEX").upper()
        if "ISLAND" in text or "FACE" in text:
            return "FACE"
        if "EDGE" in text:
            return "EDGE"
    except Exception:
        pass
    return "VERTEX"


def _sticky(context: Any = None) -> str:
    try:
        fn = _NS.get("_sus_uv_sticky_select_mode") if isinstance(_NS, dict) else None
        if callable(fn):
            value = str(fn(context or bpy.context) or "DISABLED").upper()
        else:
            value = str(getattr(_tool_settings(context), "uv_sticky_select_mode", "DISABLED") or "DISABLED").upper()
    except Exception:
        value = "DISABLED"
    aliases = {
        "SAME_LOCATION": "SHARED_LOCATION",
        "SAME_POSITION": "SHARED_LOCATION",
        "LOCATION": "SHARED_LOCATION",
        "SHARED_POSITION": "SHARED_LOCATION",
        "VERTEX": "SHARED_VERTEX",
        "SHARED_VERT": "SHARED_VERTEX",
        "COMMON_VERTEX": "SHARED_VERTEX",
    }
    return aliases.get(value, value)


def _edit_objects(context: Any) -> List[Any]:
    try:
        objs = [o for o in (getattr(context, "objects_in_mode_unique_data", None) or []) if getattr(o, "type", "") == "MESH" and getattr(o, "mode", "") == "EDIT"]
    except Exception:
        objs = []
    if not objs:
        try:
            obj = getattr(context, "edit_object", None) or getattr(context, "active_object", None)
            if obj is not None and getattr(obj, "type", "") == "MESH" and getattr(obj, "mode", "") == "EDIT":
                objs = [obj]
        except Exception:
            pass
    clean: List[Any] = []
    seen: Set[int] = set()
    for obj in list(objs or []):
        try:
            key = int(obj.data.as_pointer()) if hasattr(obj.data, "as_pointer") else id(obj.data)
        except Exception:
            key = id(getattr(obj, "data", obj))
        if key in seen:
            continue
        seen.add(key)
        clean.append(obj)
    return clean


def _enter_edit_context(context: Any) -> Tuple[Any, str, List[Any], bool]:
    old_active = None
    old_mode = "OBJECT"
    changed = False
    try:
        old_active = getattr(getattr(context, "view_layer", None), "objects", None).active
    except Exception:
        old_active = None
    objs = _edit_objects(context)
    if objs:
        return old_active, "EDIT", objs, False
    obj = None
    try:
        obj = getattr(context, "active_object", None)
    except Exception:
        obj = None
    if obj is None or getattr(obj, "type", "") != "MESH":
        return old_active, old_mode, [], False
    try:
        old_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    except Exception:
        old_mode = "OBJECT"
    try:
        context.view_layer.objects.active = obj
        obj.select_set(True)
    except Exception:
        pass
    if old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode="EDIT")
            changed = True
        except Exception:
            pass
    return old_active, old_mode, _edit_objects(context), changed


def _restore_edit_context(context: Any, old_active: Any, old_mode: str, changed: bool) -> None:
    if changed and old_mode and old_mode != "EDIT":
        try:
            bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass
    try:
        if old_active is not None:
            context.view_layer.objects.active = old_active
    except Exception:
        pass


def _ensure_unwrap_target(context: Any, obj: Any = None) -> None:
    try:
        from . import uv_map_channels as uvc
        ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
        uvc.ensure_unwrap_map_channel(context, ws, obj)
    except Exception:
        pass


def _uv_layer_for_bmesh(bm: Any) -> Any:
    try:
        layer = bm.loops.layers.uv.active
        if layer is not None:
            return layer
    except Exception:
        pass
    try:
        return bm.loops.layers.uv.verify()
    except Exception:
        return None


def _mesh_key(obj: Any) -> int:
    try:
        data = getattr(obj, "data", None)
        if data is not None and hasattr(data, "as_pointer"):
            return int(data.as_pointer())
    except Exception:
        pass
    try:
        return id(getattr(obj, "data", obj))
    except Exception:
        return id(obj)


def _face_index(face: Any) -> int:
    try:
        return int(getattr(face, "index", -1))
    except Exception:
        return -1


def _loop_index(loop: Any) -> int:
    try:
        return int(getattr(loop, "index", -1))
    except Exception:
        return -1


def _hidden(elem: Any) -> bool:
    try:
        return bool(getattr(elem, "hide", False))
    except Exception:
        return False


def _loop_record_key(obj: Any, loop: Any) -> Tuple[int, int, int]:
    try:
        return (_mesh_key(obj), _face_index(loop.face), _loop_index(loop))
    except Exception:
        return (_mesh_key(obj), -1, id(loop))


def _uv_xy(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    try:
        uv = loop[uv_layer].uv
        return float(uv.x), float(uv.y)
    except Exception:
        return 0.0, 0.0


def _uv_key(loop: Any, uv_layer: Any) -> Tuple[float, float]:
    u, v = _uv_xy(loop, uv_layer)
    return (round(u, _DIGITS), round(v, _DIGITS))


def _endpoint_key(obj: Any, loop: Any, uv_layer: Any) -> Tuple[int, int, Tuple[float, float]]:
    try:
        vi = int(getattr(loop.vert, "index", -1))
    except Exception:
        vi = -1
    return (_mesh_key(obj), vi, _uv_key(loop, uv_layer))


def _live_v_uv_only(loop: Any, uv_layer: Any) -> bool:
    # Intentionally do not read loop.vert.select. UV Sync mirrors UV selection to
    # mesh selection, and mesh selection can reference UV copies that are not
    # selected in the UV Editor.
    for getter in (
        lambda: getattr(loop, "uv_select_vert", False),
        lambda: getattr(loop[uv_layer], "select", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    return False


def _live_e_uv_only(loop: Any, uv_layer: Any) -> bool:
    for getter in (
        lambda: getattr(loop, "uv_select_edge", False),
        lambda: getattr(loop[uv_layer], "select_edge", False),
    ):
        try:
            if bool(getter()):
                return True
        except Exception:
            pass
    return False


def _live_face_uv_only(face: Any, uv_layer: Any, mode: str = "FACE") -> bool:
    # Without UV Sync the mesh selection says which faces the UV editor shows, and
    # Blender keeps UV flags on the faces it hides.
    if not _sync_on() and not bool(getattr(face, "select", False)):
        return False
    try:
        if bool(getattr(face, "uv_select", False)):
            return True
    except Exception:
        pass
    try:
        loops = list(face.loops)
    except Exception:
        loops = []
    if not loops:
        return False
    mode = str(mode or "FACE").upper()
    if mode == "EDGE":
        return all(_live_e_uv_only(loop, uv_layer) for loop in loops)
    return all(_live_v_uv_only(loop, uv_layer) for loop in loops) or all(_live_e_uv_only(loop, uv_layer) for loop in loops)


def _make_record(obj: Any, loop: Any, uv_layer: Any) -> Dict[str, Any]:
    u, v = _uv_xy(loop, uv_layer)
    return {
        "obj": obj,
        "mesh": getattr(obj, "data", None),
        "loop": loop,
        "face": getattr(loop, "face", None),
        "uv_layer": uv_layer,
        "u": u,
        "v": v,
        "record_id": _loop_record_key(obj, loop),
        "endpoint_key": _endpoint_key(obj, loop, uv_layer),
    }


def _unique_records(records: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen: Set[Tuple[int, int, int]] = set()
    for rec in list(records or []):
        try:
            obj = rec.get("obj")
            loop = rec.get("loop")
            if obj is None or loop is None or _hidden(loop) or _hidden(getattr(loop, "face", None)):
                continue
            key = _loop_record_key(obj, loop)
            if key in seen:
                continue
            seen.add(key)
            out.append(rec)
        except Exception:
            pass
    return out


def _point_key(rec: Dict[str, Any], sticky: str, fallback: int) -> Any:
    sticky = str(sticky or "DISABLED").upper()
    if sticky == "SHARED_LOCATION":
        return ("uv", _mesh_key(rec.get("obj")), rec.get("endpoint_key", (None, None, rec.get("record_id")))[2])
    if sticky == "SHARED_VERTEX":
        try:
            return ("vert", _mesh_key(rec.get("obj")), int(getattr(rec.get("loop").vert, "index", -1)))
        except Exception:
            return ("record", rec.get("record_id", fallback))
    return ("record", rec.get("record_id", fallback))


def _points_from_records(records: Sequence[Dict[str, Any]], sticky: str) -> Tuple[List[Dict[str, Any]], Dict[Any, int], Dict[int, Any]]:
    buckets: Dict[Any, List[Dict[str, Any]]] = {}
    order: List[Any] = []
    rec_to_pkey: Dict[int, Any] = {}
    for idx, rec in enumerate(_unique_records(records)):
        key = _point_key(rec, sticky, idx)
        rec_to_pkey[id(rec)] = key
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(rec)
    points: List[Dict[str, Any]] = []
    pindex: Dict[Any, int] = {}
    for key in order:
        recs = buckets.get(key) or []
        if not recs:
            continue
        us = []
        vs = []
        for rec in recs:
            u, v = _uv_xy(rec.get("loop"), rec.get("uv_layer"))
            rec["u"] = u
            rec["v"] = v
            us.append(u)
            vs.append(v)
        pindex[key] = len(points)
        points.append({"key": key, "records": recs, "u": sum(us) / max(1, len(us)), "v": sum(vs) / max(1, len(vs))})
    return points, pindex, rec_to_pkey


def _find(parent: List[int], i: int) -> int:
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i


def _union(parent: List[int], a: int, b: int) -> None:
    if a < 0 or b < 0 or a >= len(parent) or b >= len(parent):
        return
    ra, rb = _find(parent, a), _find(parent, b)
    if ra != rb:
        parent[rb] = ra


def _collect_vertex_domain(context: Any, scope: str = "SELECTED") -> Dict[str, Any]:
    import bmesh

    mode = _effective_uv_mode(context)
    sticky = _sticky(context)
    scope_all = str(scope or "SELECTED").upper() == "ALL"
    records: List[Dict[str, Any]] = []
    pair_records: List[Tuple[Dict[str, Any], Dict[str, Any]]] = []
    meshes: List[Any] = []
    targets: List[Tuple[Any, Any, Any]] = []

    for obj in _edit_objects(context):
        try:
            _ensure_unwrap_target(context, obj)
            mesh = getattr(obj, "data", None)
            bm = bmesh.from_edit_mesh(mesh)
            ri._ensure_lookup(bm)
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue
        meshes.append(mesh)
        targets.append((obj, bm, uv_layer))
        rec_by_loop: Dict[Tuple[int, int, int], Dict[str, Any]] = {}

        def add(loop: Any) -> Optional[Dict[str, Any]]:
            try:
                if loop is None or _hidden(loop) or _hidden(getattr(loop, "face", None)):
                    return None
                key = _loop_record_key(obj, loop)
                old = rec_by_loop.get(key)
                if old is not None:
                    return old
                rec = _make_record(obj, loop, uv_layer)
                records.append(rec)
                rec_by_loop[key] = rec
                return rec
            except Exception:
                return None

        for face in bm.faces:
            try:
                if _hidden(face):
                    continue
                loops = list(face.loops)
            except Exception:
                continue
            if not loops:
                continue
            face_selected = bool(scope_all)
            if not face_selected and mode in {"FACE", "ISLAND"}:
                face_selected = _live_face_uv_only(face, uv_layer, mode)
            if mode in {"FACE", "ISLAND"} and face_selected:
                prev_rec: Optional[Dict[str, Any]] = None
                first_rec: Optional[Dict[str, Any]] = None
                for loop in loops:
                    rec = add(loop)
                    if rec is None:
                        continue
                    if first_rec is None:
                        first_rec = rec
                    if prev_rec is not None:
                        pair_records.append((prev_rec, rec))
                    prev_rec = rec
                if first_rec is not None and prev_rec is not None and first_rec is not prev_rec:
                    pair_records.append((prev_rec, first_rec))
                continue
            for loop in loops:
                selected = bool(scope_all)
                if not selected:
                    if mode == "EDGE":
                        selected = _live_e_uv_only(loop, uv_layer)
                    elif mode in {"FACE", "ISLAND"}:
                        selected = False
                    else:
                        selected = _live_v_uv_only(loop, uv_layer)
                if selected:
                    rec = add(loop)
                    if mode == "EDGE":
                        nrec = add(loop.link_loop_next)
                        if rec is not None and nrec is not None:
                            pair_records.append((rec, nrec))
                if mode not in {"EDGE", "FACE", "ISLAND"}:
                    try:
                        nloop = loop.link_loop_next
                        if selected and (_live_v_uv_only(nloop, uv_layer) or bool(scope_all)):
                            r0 = add(loop)
                            r1 = add(nloop)
                            if r0 is not None and r1 is not None:
                                pair_records.append((r0, r1))
                    except Exception:
                        pass
    points, pindex, rec_to_pkey = _points_from_records(records, sticky)
    pairs: List[Tuple[int, int]] = []
    for a, b in pair_records:
        ia = pindex.get(rec_to_pkey.get(id(a)))
        ib = pindex.get(rec_to_pkey.get(id(b)))
        if ia is not None and ib is not None and ia != ib:
            pairs.append((ia, ib))
    return {"mode": mode, "sticky": sticky, "points": points, "pairs": pairs, "meshes": meshes, "targets": targets}


def _write_point(point: Dict[str, Any], u: Optional[float] = None, v: Optional[float] = None) -> int:
    changed = 0
    for rec in _unique_records(point.get("records") or []):
        try:
            loop = rec.get("loop")
            uv_layer = rec.get("uv_layer")
            uv = loop[uv_layer].uv
            if u is not None:
                uv.x = float(u)
                rec["u"] = float(u)
            if v is not None:
                uv.y = float(v)
                rec["v"] = float(v)
            changed += 1
        except Exception:
            pass
    if u is not None:
        point["u"] = float(u)
    if v is not None:
        point["v"] = float(v)
    return changed


def _apply_vertex_action(points: Sequence[Dict[str, Any]], action: str) -> int:
    pts = [p for p in list(points or []) if p]
    action = _s(action).upper()
    if not pts:
        return 0
    if action in {"DISTRIBUTE_H", "DISTRIBUTE_V"}:
        axis_u = action == "DISTRIBUTE_H"
        key = (lambda p: float(p.get("u", 0.0))) if axis_u else (lambda p: float(p.get("v", 0.0)))
        ordered = sorted(pts, key=key)
        if len(ordered) < 2:
            return 0
        start = key(ordered[0]); end = key(ordered[-1])
        if abs(end - start) <= _EPS:
            return 0
        step = (end - start) / float(max(1, len(ordered) - 1))
        changed = 0
        for i, pt in enumerate(ordered):
            val = start + step * i
            changed += _write_point(pt, u=val) if axis_u else _write_point(pt, v=val)
        return changed
    us = [float(p.get("u", 0.0)) for p in pts]
    vs = [float(p.get("v", 0.0)) for p in pts]
    min_u, max_u = min(us), max(us)
    min_v, max_v = min(vs), max(vs)
    cu, cv = (min_u + max_u) * 0.5, (min_v + max_v) * 0.5
    if action in {"FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW"}:
        changed = 0
        for pt in pts:
            u0 = float(pt.get("u", 0.0)); v0 = float(pt.get("v", 0.0))
            nu, nv = u0, v0
            if action == "FLIP_H":
                nu = cu - (u0 - cu)
            elif action == "FLIP_V":
                nv = cv - (v0 - cv)
            elif action == "ROTATE_CCW":
                du, dv = u0 - cu, v0 - cv
                nu, nv = cu - dv, cv + du
            elif action == "ROTATE_CW":
                du, dv = u0 - cu, v0 - cv
                nu, nv = cu + dv, cv - du
            changed += _write_point(pt, u=nu, v=nv)
        return changed
    set_u: Optional[float] = None
    set_v: Optional[float] = None
    if action in {"ALIGN_TL", "ALIGN_LEFT", "ALIGN_BL"}:
        set_u = min_u
    elif action in {"ALIGN_TR", "ALIGN_RIGHT", "ALIGN_BR"}:
        set_u = max_u
    elif action in {"ALIGN_CENTER", "ALIGN_V"}:
        set_u = cu
    if action in {"ALIGN_TL", "ALIGN_TOP", "ALIGN_TR"}:
        set_v = max_v
    elif action in {"ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR"}:
        set_v = min_v
    elif action in {"ALIGN_CENTER", "ALIGN_H"}:
        set_v = cv
    if set_u is None and set_v is None:
        return 0
    changed = 0
    for pt in pts:
        changed += _write_point(pt, u=set_u, v=set_v)
    return changed


def _point_groups(domain: Dict[str, Any], by_group: bool) -> List[List[Dict[str, Any]]]:
    points = list(domain.get("points") or [])
    if not by_group:
        return [points] if points else []
    parent = list(range(len(points)))
    for a, b in list(domain.get("pairs") or []):
        _union(parent, int(a), int(b))
    grouped: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    order: List[int] = []
    for i, point in enumerate(points):
        root = _find(parent, i)
        if root not in grouped:
            order.append(root)
        grouped[root].append(point)
    return [grouped[root] for root in order if grouped.get(root)]


def _face_island_map_for_targets(targets: Sequence[Tuple[Any, Any, Any]]) -> Dict[Tuple[int, int], Tuple[int, int]]:
    """Map (mesh_key, face_index) to a UV-island key."""
    out: Dict[Tuple[int, int], Tuple[int, int]] = {}
    for obj, bm, uv_layer in list(targets or []):
        try:
            face_roots = sgs._face_island_map(bm, uv_layer)
        except Exception:
            face_roots = {}
        mesh_key = _mesh_key(obj)
        for face, root in face_roots.items():
            try:
                out[(mesh_key, _face_index(face))] = (mesh_key, int(root))
            except Exception:
                pass
    return out


def _point_island_key(point: Dict[str, Any], island_map: Dict[Tuple[int, int], Tuple[int, int]]) -> Tuple[int, int]:
    for rec in list(point.get("records") or []):
        try:
            obj = rec.get("obj")
            face = getattr(rec.get("loop"), "face", None)
            key = island_map.get((_mesh_key(obj), _face_index(face)))
            if key is not None:
                return key
            return (_mesh_key(obj), _face_index(face))
        except Exception:
            pass
    return (-1, id(point))


def _group_center(points: Sequence[Dict[str, Any]], axis_u: bool) -> Optional[float]:
    vals = [float(p.get("u" if axis_u else "v", 0.0)) for p in list(points or [])]
    if not vals:
        return None
    return (min(vals) + max(vals)) * 0.5


def _clone_point_for_records(point: Dict[str, Any], records: Sequence[Dict[str, Any]], island_key: Tuple[int, int]) -> Dict[str, Any]:
    recs = [rec for rec in list(records or []) if rec]
    us: List[float] = []
    vs: List[float] = []
    for rec in recs:
        try:
            u, v = _uv_xy(rec.get("loop"), rec.get("uv_layer"))
            rec["u"] = u
            rec["v"] = v
            us.append(float(u))
            vs.append(float(v))
        except Exception:
            pass
    clone = dict(point or {})
    clone["records"] = recs
    clone["key"] = (clone.get("key"), "island", island_key)
    if us:
        clone["u"] = sum(us) / float(len(us))
    if vs:
        clone["v"] = sum(vs) / float(len(vs))
    return clone


def _split_point_group_by_island(points: Sequence[Dict[str, Any]], island_map: Dict[Tuple[int, int], Tuple[int, int]]) -> List[List[Dict[str, Any]]]:
    """Split one selected G-group into UV-island-local subgroups.

    Sticky/shared-vertex selection can legitimately make one selected visual
    point contain loop records from several UV islands.  The G… / G┆ buttons
    must never let another island's group center influence the current island,
    so both groups and multi-record points are partitioned by UV island before
    align/distribute is applied.
    """
    buckets: Dict[Tuple[int, int], List[Dict[str, Any]]] = defaultdict(list)
    order: List[Tuple[int, int]] = []
    for point in list(points or []):
        rec_buckets: Dict[Tuple[int, int], List[Dict[str, Any]]] = defaultdict(list)
        rec_order: List[Tuple[int, int]] = []
        for rec in list((point or {}).get("records") or []):
            try:
                obj = rec.get("obj")
                face = getattr(rec.get("loop"), "face", None)
                key = island_map.get((_mesh_key(obj), _face_index(face)))
                if key is None:
                    key = (_mesh_key(obj), _face_index(face))
            except Exception:
                key = (-1, id(point))
            if key not in rec_buckets:
                rec_order.append(key)
            rec_buckets[key].append(rec)
        if not rec_order:
            key = _point_island_key(point, island_map)
            if key not in buckets:
                order.append(key)
            buckets[key].append(point)
            continue
        for key in rec_order:
            if key not in buckets:
                order.append(key)
            buckets[key].append(_clone_point_for_records(point, rec_buckets.get(key) or [], key))
    return [buckets[key] for key in order if buckets.get(key)]


def _shift_group(points: Sequence[Dict[str, Any]], axis_u: bool, delta: float) -> int:
    if abs(float(delta)) <= _EPS:
        return 0
    changed = 0
    for point in list(points or []):
        if axis_u:
            changed += _write_point(point, u=float(point.get("u", 0.0)) + float(delta))
        else:
            changed += _write_point(point, v=float(point.get("v", 0.0)) + float(delta))
    return changed


def _execute_vertex_align_uv_only(self: Any, context: Any) -> set:
    raw = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    if raw not in _VERTEX_ACTIONS:
        raw = "ALIGN_CENTER"
    scope = _s(getattr(self, "scope", "SELECTED")).upper() or "SELECTED"
    old_active, old_mode, objs, changed_mode = _enter_edit_context(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        _ensure_unwrap_target(context, None)
        domain = _collect_vertex_domain(context, scope=scope)
        points = domain.get("points") or []
        if not points:
            _report(self, "WARNING", _tr(context, "No UV Editor element is selected.", "UVエディターで選択されたエレメントがありません。"))
            return {"CANCELLED"}
        by_group = raw.endswith("_GROUP")
        action = raw[:-6] if by_group else raw
        groups = _point_groups(domain, by_group)
        island_map: Dict[Tuple[int, int], Tuple[int, int]] = {}
        if by_group:
            island_map = _face_island_map_for_targets(domain.get("targets") or [])
            island_local_groups: List[List[Dict[str, Any]]] = []
            for group in groups:
                island_local_groups.extend(_split_point_group_by_island(group, island_map))
            groups = island_local_groups
        changed = 0
        if raw in _GROUP_DISTRIBUTE_ACTIONS:
            axis_u = raw == "DISTRIBUTE_H_GROUP"
            buckets: Dict[Tuple[int, int], List[List[Dict[str, Any]]]] = defaultdict(list)
            for group in groups:
                if not group:
                    continue
                key = _point_island_key(group[0], island_map)
                buckets[key].append(group)
            for island_groups in buckets.values():
                prepared: List[Dict[str, Any]] = []
                for group in island_groups:
                    center = _group_center(group, axis_u)
                    if center is not None:
                        prepared.append({"points": group, "center": float(center)})
                if len(prepared) < 2:
                    continue
                ordered = sorted(prepared, key=lambda item: float(item.get("center", 0.0)))
                start = float(ordered[0]["center"]); end = float(ordered[-1]["center"])
                if abs(end - start) <= _EPS:
                    continue
                step = (end - start) / float(max(1, len(ordered) - 1))
                for idx, item in enumerate(ordered):
                    changed += _shift_group(item.get("points") or [], axis_u, start + step * idx - float(item.get("center", 0.0)))
        else:
            for group in groups:
                changed += _apply_vertex_action(group, action)
        # Already aligned is still a successful, stable final state.
        try:
            mo._update_meshes(domain.get("targets") or [])
        except Exception:
            _update_meshes(domain.get("meshes") or [])
        return {"FINISHED"} if changed >= 0 else {"CANCELLED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Vertex alignment failed.", "頂点方向整列に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        _restore_edit_context(context, old_active, old_mode, changed_mode)


def _update_meshes(meshes: Iterable[Any]) -> None:
    try:
        import bmesh
    except Exception:
        return
    seen: Set[int] = set()
    for mesh in list(meshes or []):
        try:
            key = int(mesh.as_pointer()) if hasattr(mesh, "as_pointer") else id(mesh)
            if key in seen:
                continue
            seen.add(key)
            try:
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            except TypeError:
                bmesh.update_edit_mesh(mesh)
            except Exception:
                pass
        except Exception:
            pass


def _edge_uv_pair(loop: Any, uv_layer: Any) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    try:
        return _uv_key(loop, uv_layer), _uv_key(loop.link_loop_next, uv_layer)
    except Exception:
        return (0.0, 0.0), (0.0, 0.0)


def _same_edge_uv(a0: Any, a1: Any, b0: Any, b1: Any) -> bool:
    return (a0 == b0 and a1 == b1) or (a0 == b1 and a1 == b0)


def _collect_islands_uv_only(context: Any) -> Tuple[List[Dict[str, Any]], List[Any]]:
    import bmesh

    islands: List[Dict[str, Any]] = []
    meshes: List[Any] = []
    mode = _effective_uv_mode(context)
    for obj in _edit_objects(context):
        try:
            _ensure_unwrap_target(context, obj)
            mesh = getattr(obj, "data", None)
            bm = bmesh.from_edit_mesh(mesh)
            ri._ensure_lookup(bm)
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
        except Exception:
            continue
        meshes.append(mesh)
        selected_faces: Set[Any] = set()
        for face in bm.faces:
            try:
                if _hidden(face):
                    continue
                if _live_face_uv_only(face, uv_layer, mode):
                    selected_faces.add(face)
            except Exception:
                pass
        if not selected_faces:
            continue
        face_list = [f for f in bm.faces if f in selected_faces]
        fpos = {face: i for i, face in enumerate(face_list)}
        parent = list(range(len(face_list)))
        for edge in bm.edges:
            try:
                linked = [f for f in edge.link_faces if f in fpos]
            except Exception:
                linked = []
            if len(linked) < 2:
                continue
            for i in range(len(linked)):
                for j in range(i + 1, len(linked)):
                    fa, fb = linked[i], linked[j]
                    la = next((l for l in fa.loops if l.edge is edge), None)
                    lb = next((l for l in fb.loops if l.edge is edge), None)
                    if la is None or lb is None:
                        continue
                    a0, a1 = _edge_uv_pair(la, uv_layer)
                    b0, b1 = _edge_uv_pair(lb, uv_layer)
                    if _same_edge_uv(a0, a1, b0, b1):
                        _union(parent, fpos[fa], fpos[fb])
        grouped: Dict[int, List[Any]] = defaultdict(list)
        order: List[int] = []
        for face in face_list:
            root = _find(parent, fpos[face])
            if root not in grouped:
                order.append(root)
            grouped[root].append(face)
        for root in order:
            faces = grouped.get(root) or []
            loops: List[Any] = []
            for face in faces:
                try:
                    loops.extend(list(face.loops))
                except Exception:
                    pass
            if not loops:
                continue
            us = [float(loop[uv_layer].uv.x) for loop in loops]
            vs = [float(loop[uv_layer].uv.y) for loop in loops]
            islands.append({
                "obj": obj,
                "mesh": mesh,
                "bm": bm,
                "uv_layer": uv_layer,
                "faces": faces,
                "loops": loops,
                "min_u": min(us), "max_u": max(us), "min_v": min(vs), "max_v": max(vs),
                "center_u": (min(us) + max(us)) * 0.5,
                "center_v": (min(vs) + max(vs)) * 0.5,
                "width": max(us) - min(us),
                "height": max(vs) - min(vs),
            })
    return islands, meshes


def _move_island(island: Dict[str, Any], du: float = 0.0, dv: float = 0.0) -> int:
    changed = 0
    uv_layer = island.get("uv_layer")
    for loop in list(island.get("loops") or []):
        try:
            uv = loop[uv_layer].uv
            uv.x = float(uv.x) + float(du)
            uv.y = float(uv.y) + float(dv)
            changed += 1
        except Exception:
            pass
    return changed


def _transform_island(island: Dict[str, Any], action: str) -> int:
    changed = 0
    uv_layer = island.get("uv_layer")
    cu = float(island.get("center_u", 0.0)); cv = float(island.get("center_v", 0.0))
    for loop in list(island.get("loops") or []):
        try:
            uv = loop[uv_layer].uv
            du = float(uv.x) - cu; dv = float(uv.y) - cv
            if action in {"MIRROR_H", "FLIP_H"}:
                uv.x = cu - du
            elif action in {"MIRROR_V", "FLIP_V"}:
                uv.y = cv - dv
            elif action == "ROTATE_CCW":
                uv.x = cu - dv; uv.y = cv + du
            elif action == "ROTATE_CW":
                uv.x = cu + dv; uv.y = cv - du
            changed += 1
        except Exception:
            pass
    return changed


def _execute_island_align_uv_only(self: Any, context: Any) -> set:
    action = _s(getattr(self, "action", "ALIGN_CENTER")).upper() or "ALIGN_CENTER"
    if action not in _ISLAND_ACTIONS:
        action = "ALIGN_CENTER"
    old_active, old_mode, objs, changed_mode = _enter_edit_context(context)
    if not objs:
        _report(self, "WARNING", _tr(context, "No mesh object is active.", "アクティブなメッシュオブジェクトがありません。"))
        return {"CANCELLED"}
    try:
        _ensure_unwrap_target(context, None)
        islands, meshes = _collect_islands_uv_only(context)
        if not islands:
            _report(self, "WARNING", _tr(context, "No fully selected UV Editor face is available for island alignment.", "アイランド方向整列に使用できる、UVエディター上で完全選択された面がありません。"))
            return {"CANCELLED"}
        min_u = min(float(i["min_u"]) for i in islands); max_u = max(float(i["max_u"]) for i in islands)
        min_v = min(float(i["min_v"]) for i in islands); max_v = max(float(i["max_v"]) for i in islands)
        center_u = (min_u + max_u) * 0.5; center_v = (min_v + max_v) * 0.5
        changed = 0
        if action in {"MIRROR_H", "MIRROR_V", "FLIP_H", "FLIP_V", "ROTATE_CCW", "ROTATE_CW"}:
            for island in islands:
                changed += _transform_island(island, action)
        elif action in {"DISTRIBUTE_H", "DISTRIBUTE_V"}:
            axis_u = action == "DISTRIBUTE_H"
            key = (lambda i: float(i.get("center_u", 0.0))) if axis_u else (lambda i: float(i.get("center_v", 0.0)))
            ordered = sorted(islands, key=key)
            if len(ordered) >= 2:
                start = key(ordered[0]); end = key(ordered[-1])
                if abs(end - start) > _EPS:
                    step = (end - start) / float(max(1, len(ordered) - 1))
                    for idx, island in enumerate(ordered):
                        target = start + step * idx
                        changed += _move_island(island, du=(target - float(island.get("center_u", 0.0))) if axis_u else 0.0, dv=(target - float(island.get("center_v", 0.0))) if not axis_u else 0.0)
        else:
            for island in islands:
                target_u: Optional[float] = None
                target_v: Optional[float] = None
                if action in {"ALIGN_TL", "ALIGN_LEFT", "ALIGN_BL"}:
                    target_u = min_u + float(island.get("width", 0.0)) * 0.5
                elif action in {"ALIGN_TR", "ALIGN_RIGHT", "ALIGN_BR"}:
                    target_u = max_u - float(island.get("width", 0.0)) * 0.5
                elif action in {"ALIGN_CENTER", "ALIGN_V"}:
                    target_u = center_u
                if action in {"ALIGN_TL", "ALIGN_TOP", "ALIGN_TR"}:
                    target_v = max_v - float(island.get("height", 0.0)) * 0.5
                elif action in {"ALIGN_BL", "ALIGN_BOTTOM", "ALIGN_BR"}:
                    target_v = min_v + float(island.get("height", 0.0)) * 0.5
                elif action in {"ALIGN_CENTER", "ALIGN_H"}:
                    target_v = center_v
                du = 0.0 if target_u is None else float(target_u) - float(island.get("center_u", 0.0))
                dv = 0.0 if target_v is None else float(target_v) - float(island.get("center_v", 0.0))
                if abs(du) > _EPS or abs(dv) > _EPS:
                    changed += _move_island(island, du=du, dv=dv)
        _update_meshes(meshes)
        return {"FINISHED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "Island direction alignment failed.", "アイランド方向整列に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        _restore_edit_context(context, old_active, old_mode, changed_mode)


def _collect_selected_loops_uv_only(context: Any) -> Tuple[List[Dict[str, Any]], List[Tuple[Any, Any, Any]], Any]:
    objs, state = mo._ensure_multi_edit(context)
    if not objs:
        return [], [], state
    try:
        mo._prepare_unwrap_channel(context)
    except Exception:
        pass
    targets = mo._target_data(context)
    mode = _effective_uv_mode(context)
    points: List[Dict[str, Any]] = []
    buckets: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for obj, bm, uv_layer in list(targets or []):
        try:
            ri._ensure_lookup(bm)
        except Exception:
            pass
        selected_loops: Set[Any] = set()
        sync_on = bool(context.tool_settings.use_uv_select_sync)
        if sync_on and not getattr(bm, "uv_select_sync_valid", True):
            # The UV flags are stale after a selection made on the mesh; the mesh selection is the selection.
            pass
        elif mode == "EDGE":
            for face in bm.faces:
                if _hidden(face):
                    continue
                for loop in face.loops:
                    if _live_e_uv_only(loop, uv_layer):
                        selected_loops.add(loop)
                        try:
                            selected_loops.add(loop.link_loop_next)
                        except Exception:
                            pass
        elif mode in {"FACE", "ISLAND"}:
            for face in bm.faces:
                if _hidden(face):
                    continue
                if _live_face_uv_only(face, uv_layer, mode):
                    for loop in face.loops:
                        selected_loops.add(loop)
        else:
            for face in bm.faces:
                if _hidden(face):
                    continue
                for loop in face.loops:
                    if _live_v_uv_only(loop, uv_layer):
                        selected_loops.add(loop)
        if not selected_loops and sync_on:
            # With UV Sync on and no UV flags written yet, the mesh selection is the selection.
            for face in bm.faces:
                if _hidden(face):
                    continue
                for loop in face.loops:
                    if loop.vert.select:
                        selected_loops.add(loop)
        for loop in list(selected_loops):
            try:
                uv = loop[uv_layer].uv
                key = (_mesh_key(obj), int(getattr(loop.vert, "index", -1)), round(float(uv.x), _DIGITS), round(float(uv.y), _DIGITS))
                point = buckets.get(key)
                if point is None:
                    point = {"records": [], "u": float(uv.x), "v": float(uv.y)}
                    buckets[key] = point
                    points.append(point)
                point["records"].append((loop, uv_layer))
            except Exception:
                pass
    return points, targets, state


def _snap_execute_uv_only(self: Any, context: Any) -> set:
    points, targets, state = _collect_selected_loops_uv_only(context)
    try:
        if not points:
            _report(self, "WARNING", _tr(context, "No selected UV Editor element was found.", "UVエディターで選択されたエレメントがありません。"))
            return {"CANCELLED"}
        mode = _s(getattr(self, "mode", "GRID")).upper() or "GRID"
        axis = _s(getattr(self, "axis", "BOTH")).upper() or "BOTH"
        if mode == "PIXEL":
            texture_size = max(1, int(getattr(self, "texture_size", 1024) or 1024))
            changed = sgs._snap_grid(points, Vector((1.0 / float(texture_size), 1.0 / float(texture_size))), axis)
        elif mode == "VERTEX":
            # The panel button leaves vertex_distance unset and uses the scene value; an explicit value wins.
            if self.properties.is_property_set("vertex_distance"):
                distance = max(0.0, float(self.vertex_distance))
            else:
                distance = sgs._scene_vertex_distance(context, getattr(self, "vertex_distance", getattr(self, "distance", 0.001)))
            changed = sgs._snap_vertex(points, distance)
        else:
            fallback = float(getattr(self, "grid_size", 0.125) or 0.125)
            changed = sgs._snap_grid(points, sgs._visible_grid_step(context, fallback), axis)
        mo._update_meshes(targets)
        return {"FINISHED"} if changed >= 0 else {"CANCELLED"}
    except Exception as exc:
        _report(self, "WARNING", _tr(context, "UV snap failed.", "UV吸着に失敗しました。") + f" {exc}")
        return {"CANCELLED"}
    finally:
        try:
            mo._restore_multi_edit(context, state)
        except Exception:
            pass


def _patch_class_execute(ns: Dict[str, Any], class_name: str, fn: Any, key: str) -> None:
    try:
        cls = ns.get(class_name) if isinstance(ns, dict) else None
        if isinstance(cls, type):
            cur = getattr(cls, "execute", None)
            if callable(cur) and cur is not fn:
                _PREV.setdefault(key, cur)
            cls.execute = fn
    except Exception:
        pass


def _patch_snap(ns: Dict[str, Any]) -> None:
    classes: List[type] = []
    try:
        from . import consolidated_uv_tools as cut
        cls = getattr(cut, "SMARTUVSUITE_OT_consolidated_snap_uv", None)
        if isinstance(cls, type):
            classes.append(cls)
    except Exception:
        pass
    try:
        cls = ns.get("SMARTUVSUITE_OT_consolidated_snap_uv") if isinstance(ns, dict) else None
        if isinstance(cls, type):
            classes.append(cls)
    except Exception:
        pass
    seen: Set[int] = set()
    for cls in classes:
        if id(cls) in seen:
            continue
        seen.add(id(cls))
        cur = getattr(cls, "execute", None)
        if callable(cur) and cur is not _snap_execute_uv_only:
            _PREV.setdefault("snap_execute", cur)
        cls.execute = _snap_execute_uv_only


def _patch_mode_helpers(ns: Dict[str, Any]) -> None:
    """Keep align helper mode detection in sync with the visible UV/mesh mode."""
    try:
        if isinstance(ns, dict):
            ns["_sus_1810_uv_mode"] = _effective_uv_mode
    except Exception:
        pass
    # Do not override ri._selected_sets here. Selection tools still need their
    # own sync-safe overlay behavior. Alignment uses private UV-only collectors.


def _mark_version(ns: Dict[str, Any]) -> None:
    try:
        if isinstance(ns, dict):
            ns["__version__"] = '1.0.0'
            info = ns.get("bl_info")
            if isinstance(info, dict):
                info["version"] = (1, 0, 0)
                info["author"] = "JELararagi"
                ns["_SUS_BL_INFO_FALLBACK"] = dict(info)
    except Exception:
        pass


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    source = ns if isinstance(ns, dict) else _NS
    if not isinstance(source, dict):
        return
    _patch_mode_helpers(source)
    _patch_class_execute(source, "SMARTUVSUITE_OT_vertex_align_action", _execute_vertex_align_uv_only, "vertex_execute")
    _patch_class_execute(source, "SMARTUVSUITE_OT_island_direction_align", _execute_island_align_uv_only, "island_execute")
    _patch_snap(source)
    _mark_version(source)


apply_all = install


def _suv_stage_001_register() -> None:
    install(_NS, bpy.context)


def unregister() -> None:
    return None


def diagnostics(context: Any = None) -> Dict[str, Any]:
    return {
        "version": _VERSION,
        "effective_mode": _effective_uv_mode(context or bpy.context),
        "vertex_align_uv_editor_only": True,
        "island_align_uv_editor_only": True,
        "snap_uv_editor_only": True,
    }

# Direction Align unified operators live in a module that uses postponed annotations.
# On Blender 5.1 this can leave the UI-facing action/target RNA properties absent
# after dynamic registration.  Restore those RNA definitions so the existing
# Direction Align buttons can pass their action while this module controls scope.
def _ensure_unified_direction_align_rna(ns: Dict[str, Any]) -> None:
    try:
        from . import uv_direction_align_unified_18111 as uni
    except Exception:
        return
    specs = []
    try:
        specs.append((
            getattr(uni, "SMARTUVSUITE_OT_direction_align_mode", None),
            "target",
            bpy.props.EnumProperty(
                name="対象",
                description="Choose whether Direction Align edits selected UV elements directly or moves selected UV islands while preserving island shapes.",
                items=getattr(uni, "_MODE_ITEMS", ()),
                default="VERTEX",
                options={"SKIP_SAVE"},
            ),
        ))
        action_prop = bpy.props.EnumProperty(
            name="操作",
            description="Choose the exact Direction Align operation assigned to this button.",
            items=getattr(uni, "_ACTION_ITEMS", ()),
            default="ALIGN_CENTER",
            options={"SKIP_SAVE"},
        )
        specs.append((getattr(uni, "SMARTUVSUITE_OT_direction_align", None), "action", action_prop))
        specs.append((getattr(uni, "SMARTUVSUITE_OT_direction_align_action", None), "action", action_prop))
    except Exception:
        return

    registered = list(getattr(uni, "_REGISTERED", []) or [])
    changed = False
    for cls, prop_name, prop_def in specs:
        if not isinstance(cls, type):
            continue
        needs = True
        try:
            op = getattr(bpy.ops.smart_uv_suite, str(getattr(cls, "bl_idname", "")).split(".", 1)[1])
            props = {str(getattr(p, "identifier", "")) for p in op.get_rna_type().properties}
            needs = prop_name not in props
        except Exception:
            needs = True
        if not needs:
            continue
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
        try:
            anns = dict(getattr(cls, "__annotations__", {}) or {})
            anns[prop_name] = prop_def
            cls.__annotations__ = anns
        except Exception:
            pass
        try:
            _suv_resource.register_class(cls)
            changed = True
            if cls not in registered:
                registered.append(cls)
        except Exception:
            pass
    try:
        uni._REGISTERED = registered
    except Exception:
        pass
    if changed and isinstance(ns, dict):
        for name in ("SMARTUVSUITE_OT_direction_align", "SMARTUVSUITE_OT_direction_align_mode", "SMARTUVSUITE_OT_direction_align_action"):
            cls = getattr(uni, name, None)
            if isinstance(cls, type):
                ns[name] = cls


# Override install to include the UI-facing Direction Align RNA repair.
def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:  # type: ignore[override]
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    source = ns if isinstance(ns, dict) else _NS
    if not isinstance(source, dict):
        return
    _ensure_unified_direction_align_rna(source)
    _patch_mode_helpers(source)
    _patch_class_execute(source, "SMARTUVSUITE_OT_vertex_align_action", _execute_vertex_align_uv_only, "vertex_execute")
    _patch_class_execute(source, "SMARTUVSUITE_OT_island_direction_align", _execute_island_align_uv_only, "island_execute")
    _patch_snap(source)
    _mark_version(source)


apply_all = install

# -----------------------------------------------------------------------------
# 1.8.116 final supplement: cover legacy/Native align routes without changing
# non-align selection tools.
# -----------------------------------------------------------------------------
_ALIGN_SCOPE_DEPTH = 0
_SUPPLEMENT_INSTALLED = False
_PENDING_SELECTION_RESTORE: Optional[list] = None
_PENDING_SELECTION_RESTORE_TOKEN = 0
_NATIVE_ALIGN_ACTIONS = {
    "FIT", "FILL", "CROP", "ALIGN_CENTER", "ALIGN_LEFT", "ALIGN_RIGHT", "ALIGN_TOP", "ALIGN_BOTTOM",
    "ROTATE_90", "FLIP_U", "FLIP_V", "STRAIGHTEN", "GRIDIFY", "CIRCLE", "RELAX", "RANDOMIZE",
    "SNAP_GRID", "SNAP_PIXEL", "SNAP_VERTEX",
}
_FLOW_ALIGN_CLASS_NAMES = {
    "SUV_OT_align_islands", "SUV_OT_centralize_islands", "SUV_OT_distribute_islands",
    "SUV_OT_rotate_islands", "SUV_OT_flip_islands", "SUV_OT_uv_straight_line",
    "SUV_OT_uv_set_flow", "SUV_OT_hs_gridify", "SUV_OT_hs_rectify_fit",
    "SUV_OT_hs_rectify_constrained", "SUV_OT_hs_quad_flow", "SUV_OT_apply_line_flow_preset",
}


def _align_depth_inc() -> None:
    global _ALIGN_SCOPE_DEPTH
    try:
        _ALIGN_SCOPE_DEPTH += 1
    except Exception:
        _ALIGN_SCOPE_DEPTH = 1


def _align_depth_dec() -> None:
    global _ALIGN_SCOPE_DEPTH
    try:
        _ALIGN_SCOPE_DEPTH = max(0, int(_ALIGN_SCOPE_DEPTH) - 1)
    except Exception:
        _ALIGN_SCOPE_DEPTH = 0


def _align_active() -> bool:
    try:
        return int(_ALIGN_SCOPE_DEPTH) > 0
    except Exception:
        return False


def _queue_selection_restore(snapshot: Optional[list], *, schedule: bool = True) -> None:
    global _PENDING_SELECTION_RESTORE, _PENDING_SELECTION_RESTORE_TOKEN
    if not snapshot:
        return
    try:
        _PENDING_SELECTION_RESTORE = list(snapshot)
        _PENDING_SELECTION_RESTORE_TOKEN += 1
        token = int(_PENDING_SELECTION_RESTORE_TOKEN)
    except Exception:
        return
    if not schedule:
        return
    try:
        def _deferred_restore() -> None:
            global _PENDING_SELECTION_RESTORE
            try:
                if int(_PENDING_SELECTION_RESTORE_TOKEN) == token and _PENDING_SELECTION_RESTORE:
                    snap = _PENDING_SELECTION_RESTORE
                    _PENDING_SELECTION_RESTORE = None
                    _restore_edit_selection(snap)
            except Exception:
                _PENDING_SELECTION_RESTORE = None
            return None
        _suv_resource.timer_register(_deferred_restore, first_interval=0.0)
    except Exception:
        pass


def _consume_pending_selection_restore() -> Optional[list]:
    global _PENDING_SELECTION_RESTORE
    try:
        snap = _PENDING_SELECTION_RESTORE
        _PENDING_SELECTION_RESTORE = None
        return snap
    except Exception:
        _PENDING_SELECTION_RESTORE = None
        return None


def _patch_runtime_cleanup_selection_restore() -> None:
    try:
        from . import uv_runtime_cleanup_1899 as rtc
    except Exception:
        return
    try:
        cur = getattr(rtc, "restore_selection_state", None)
        if not callable(cur) or getattr(cur, "_suv_18117_selection_restore", False):
            return

        def restore_selection_state_then_selection(context: Any = None, state: Optional[Dict[str, Any]] = None, _old=cur) -> None:
            try:
                _old(context, state)
            finally:
                snap = _consume_pending_selection_restore()
                if snap:
                    try:
                        _restore_edit_selection(snap)
                    except Exception:
                        pass
            return None

        restore_selection_state_then_selection._suv_18117_selection_restore = True  # type: ignore[attr-defined]
        rtc.restore_selection_state = restore_selection_state_then_selection
    except Exception:
        pass


def _nonstale_attr(values: Sequence[Any], index: int) -> bool:
    try:
        vals = list(values or [])
        if index < 0 or index >= len(vals):
            return False
        if vals and all(bool(v) for v in vals):
            return False
        return bool(vals[index])
    except Exception:
        return False


def _mesh_attr_values(mesh: Any, name: str) -> List[bool]:
    try:
        attr = getattr(getattr(mesh, "attributes", None), "get", lambda _n: None)(name)
        if attr is None:
            return []
        return [bool(getattr(item, "value", False)) for item in getattr(attr, "data", [])]
    except Exception:
        return []


def _mode_from_value(context: Any = None, supplied: Optional[str] = None) -> str:
    raw = supplied if supplied is not None else _effective_uv_mode(context)
    try:
        text = str(raw or "VERTEX").upper()
    except Exception:
        text = "VERTEX"
    if "ISLAND" in text or "FACE" in text:
        return "FACE"
    if "EDGE" in text:
        return "EDGE"
    return "VERTEX"


def _selected_sets_for_align_uv_only(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: Optional[str] = None) -> Tuple[Set[Any], Set[Any], Set[Any]]:
    eff_mode = _mode_from_value(context, mode)
    loops: Set[Any] = set()
    edge_loops: Set[Any] = set()
    faces: Set[Any] = set()
    try:
        face_list = [f for f in bm.faces if not _hidden(f)]
    except Exception:
        face_list = []
    for face in face_list:
        try:
            face_loops = list(face.loops)
        except Exception:
            face_loops = []
        if not face_loops:
            continue
        face_selected = _live_face_uv_only(face, uv_layer, eff_mode)
        if eff_mode == "FACE" and face_selected:
            faces.add(face)
            for loop in face_loops:
                loops.add(loop)
                edge_loops.add(loop)
            continue
        for loop in face_loops:
            vsel = _live_v_uv_only(loop, uv_layer)
            esel = _live_e_uv_only(loop, uv_layer)
            if eff_mode == "EDGE":
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try:
                        loops.add(loop.link_loop_next)
                    except Exception:
                        pass
                elif vsel:
                    loops.add(loop)
            elif eff_mode == "FACE":
                if vsel:
                    loops.add(loop)
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try:
                        loops.add(loop.link_loop_next)
                    except Exception:
                        pass
            else:
                if vsel:
                    loops.add(loop)
                if esel:
                    edge_loops.add(loop)
                    loops.add(loop)
                    try:
                        loops.add(loop.link_loop_next)
                    except Exception:
                        pass
    return loops, edge_loops, faces


def _patch_room_integrity_conditional() -> None:
    try:
        prev = getattr(ri, "_selected_sets", None)
        if getattr(prev, "_suv_18116_conditional_uv_only", False):
            return
        _PREV.setdefault("ri._selected_sets", prev)

        def selected_sets_conditional(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: Optional[str] = None):
            if _align_active():
                return _selected_sets_for_align_uv_only(context, obj, bm, uv_layer, mode)
            old = _PREV.get("ri._selected_sets")
            if callable(old):
                return old(context, obj, bm, uv_layer, mode)
            return _selected_sets_for_align_uv_only(context, obj, bm, uv_layer, mode)

        selected_sets_conditional._suv_18116_conditional_uv_only = True  # type: ignore[attr-defined]
        ri._selected_sets = selected_sets_conditional
    except Exception:
        pass


def _collect_selected_points_1810_uv_only(context: Any, *, include_edge_endpoints: bool = True):
    import bmesh
    objs = []
    try:
        fn = _NS.get("_sus_1810_edit_mesh_objects") if isinstance(_NS, dict) else None
        if callable(fn):
            objs = list(fn(context) or [])
    except Exception:
        objs = []
    if not objs:
        objs = _edit_objects(context)
    mode = _mode_from_value(context, None)
    points: List[Dict[str, Any]] = []
    mesh_infos: List[Tuple[Any, Any, Any]] = []
    seen: Set[Tuple[Any, ...]] = set()

    for obj in list(objs or []):
        try:
            if getattr(obj, "mode", "") != "EDIT":
                continue
            mesh = obj.data
            bm = bmesh.from_edit_mesh(mesh)
            ri._ensure_lookup(bm)
            # BMLoop.index is left at -1 after topology edits.
            for index, loop in enumerate(l for f in bm.faces for l in f.loops):
                loop.index = index
            uv_layer = _uv_layer_for_bmesh(bm)
            if uv_layer is None:
                continue
            obj_key = str(getattr(obj, "name_full", None) or getattr(obj, "name", None) or _mesh_key(obj))
            mesh_infos.append((mesh, bm, uv_layer))
            # With UV Sync on and no per-UV selection synchronized yet, the mesh
            # selection is what the UV Editor shows as selected.
            from_mesh = _sync_on(context) and not bool(getattr(bm, "uv_select_sync_valid", False))
            vattr = _mesh_attr_values(mesh, ".uv_select_vert")
            eattr = _mesh_attr_values(mesh, ".uv_select_edge")
            fattr = _mesh_attr_values(mesh, ".uv_select_face")

            def add_loop(loop: Any, selected_edge_key: Any = None) -> None:
                try:
                    li = _loop_index(loop)
                    if li < 0:
                        return
                    dedupe_key = (obj_key, li, selected_edge_key if mode == "EDGE" else None)
                    if dedupe_key in seen:
                        return
                    seen.add(dedupe_key)
                    u, v = _uv_xy(loop, uv_layer)
                    points.append({
                        "obj": obj, "obj_key": obj_key, "mesh": mesh, "bm": bm, "uv_layer": uv_layer,
                        "loop": loop, "luv": loop[uv_layer], "face": loop.face,
                        "loop_index": li, "face_index": _face_index(loop.face),
                        "vertex_index": int(getattr(loop.vert, "index", -1)),
                        "edge_index": int(getattr(loop.edge, "index", -1)),
                        "selected_edge_key": selected_edge_key,
                        "u": u, "v": v,
                    })
                except Exception:
                    pass

            for face in bm.faces:
                if _hidden(face):
                    continue
                try:
                    loops_seq = list(face.loops)
                except Exception:
                    loops_seq = []
                if not loops_seq:
                    continue
                fi = _face_index(face)
                face_sel = False
                if mode == "FACE":
                    if from_mesh:
                        face_sel = bool(face.select)
                    else:
                        face_sel = _live_face_uv_only(face, uv_layer, mode) or _nonstale_attr(fattr, fi)
                for loop in loops_seq:
                    li = _loop_index(loop)
                    if mode == "FACE":
                        if face_sel:
                            add_loop(loop, None)
                        continue
                    if mode == "EDGE":
                        if from_mesh:
                            selected = bool(loop.edge.select)
                        else:
                            selected = _live_e_uv_only(loop, uv_layer) or _nonstale_attr(eattr, li)
                        if selected:
                            try:
                                a = _uv_xy(loop, uv_layer)
                                b = _uv_xy(loop.link_loop_next, uv_layer)
                                ekey = tuple(sorted(((round(a[0], _DIGITS), round(a[1], _DIGITS)), (round(b[0], _DIGITS), round(b[1], _DIGITS)))))
                            except Exception:
                                ekey = None
                            add_loop(loop, ekey)
                            if include_edge_endpoints:
                                try:
                                    add_loop(loop.link_loop_next, ekey)
                                except Exception:
                                    pass
                        continue
                    if from_mesh:
                        selected = bool(loop.vert.select)
                    else:
                        selected = _live_v_uv_only(loop, uv_layer) or _nonstale_attr(vattr, li)
                    if selected:
                        add_loop(loop, None)
        except Exception:
            continue
    return points, mesh_infos, mode


def _patch_1810_collectors(ns: Dict[str, Any]) -> None:
    try:
        if isinstance(ns, dict):
            old = ns.get("_sus_1810_collect_selected_points")
            if callable(old) and old is not _collect_selected_points_1810_uv_only:
                _PREV.setdefault("ns._sus_1810_collect_selected_points", old)
            ns["_sus_1810_collect_selected_points"] = _collect_selected_points_1810_uv_only
    except Exception:
        pass


def _wrap_execute_with_align_scope(cls: Any, key: str, *, native_filter: bool = False) -> None:
    try:
        if not isinstance(cls, type):
            return
        cur = getattr(cls, "execute", None)
        if not callable(cur) or getattr(cur, "_suv_18116_align_scope_wrapper", False):
            return
        _PREV.setdefault(key, cur)

        def wrapped(self: Any, context: Any, *args: Any, _old=cur, **kwargs: Any):
            action = _s(getattr(self, "action", "")).upper()
            should_scope = True
            need_snapshot = False
            if native_filter:
                should_scope = action in _NATIVE_ALIGN_ACTIONS
                need_snapshot = action == "RELAX"
            if not should_scope:
                return _old(self, context, *args, **kwargs)
            snapshot = _snapshot_edit_selection(context) if need_snapshot else None
            _align_depth_inc()
            try:
                return _old(self, context, *args, **kwargs)
            finally:
                _align_depth_dec()
                if snapshot is not None:
                    _restore_edit_selection(snapshot)

        wrapped._suv_18116_align_scope_wrapper = True  # type: ignore[attr-defined]
        cls.execute = wrapped
    except Exception:
        pass


def _snapshot_edit_selection(context: Any) -> list:
    out: list = []
    try:
        import bmesh
    except Exception:
        return out
    for obj in _edit_objects(context):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            ri._ensure_lookup(bm)
            uv_layer = _uv_layer_for_bmesh(bm)
            item = {"obj": obj, "faces": {}, "edges": {}, "verts": {}, "loops": {}}
            for v in bm.verts:
                item["verts"][_loop_index(v)] = bool(getattr(v, "select", False))
            for e in bm.edges:
                item["edges"][int(getattr(e, "index", -1))] = bool(getattr(e, "select", False))
            for f in bm.faces:
                item["faces"][_face_index(f)] = bool(getattr(f, "select", False))
                for l in f.loops:
                    li = _loop_index(l)
                    item["loops"][li] = (
                        bool(getattr(l, "uv_select_vert", False)),
                        bool(getattr(l, "uv_select_edge", False)),
                    )
            out.append((obj, item, uv_layer))
        except Exception:
            pass
    return out


def _restore_edit_selection(snapshot: list) -> None:
    try:
        import bmesh
    except Exception:
        return
    for obj, item, uv_layer_hint in list(snapshot or []):
        try:
            if getattr(obj, "mode", "") != "EDIT":
                continue
            bm = bmesh.from_edit_mesh(obj.data)
            ri._ensure_lookup(bm)
            uv_layer = _uv_layer_for_bmesh(bm) or uv_layer_hint
            for v in bm.verts:
                try:
                    v.select_set(bool(item.get("verts", {}).get(int(getattr(v, "index", -1)), False)))
                except Exception:
                    pass
            for e in bm.edges:
                try:
                    e.select_set(bool(item.get("edges", {}).get(int(getattr(e, "index", -1)), False)))
                except Exception:
                    pass
            for f in bm.faces:
                try:
                    f.select_set(bool(item.get("faces", {}).get(_face_index(f), False)))
                except Exception:
                    pass
                for l in f.loops:
                    vsel, esel = item.get("loops", {}).get(_loop_index(l), (False, False))
                    try:
                        l.uv_select_vert_set(bool(vsel))
                    except Exception:
                        pass
                    try:
                        l.uv_select_edge_set(bool(esel))
                    except Exception:
                        pass
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except TypeError:
            try:
                bmesh.update_edit_mesh(obj.data)
            except Exception:
                pass
        except Exception:
            pass


def _patch_flow_align_classes(ns: Dict[str, Any]) -> None:
    modules = []
    try:
        from . import flow as flow_mod
        modules.append(flow_mod)
    except Exception:
        pass
    for name in _FLOW_ALIGN_CLASS_NAMES:
        try:
            cls = ns.get(name) if isinstance(ns, dict) else None
            _wrap_execute_with_align_scope(cls, f"ns.{name}.execute")
        except Exception:
            pass
        for mod in modules:
            try:
                _wrap_execute_with_align_scope(getattr(mod, name, None), f"{getattr(mod, '__name__', 'flow')}.{name}.execute")
            except Exception:
                pass


def _native_state_uv_only(nut: Any, context: Any = None):
    try:
        ctx = context or bpy.context
        obj = nut._active_mesh(ctx)
        if obj is None:
            return None
        previous_mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
        nut._set_active(ctx, obj)
        if previous_mode != "EDIT" and not nut._mode_set("EDIT"):
            return None
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = _uv_layer_for_bmesh(bm)
        if uv_layer is None:
            return None
        ri._ensure_lookup(bm)
        mode = _mode_from_value(ctx, None)
        loops: List[Any] = []
        faces: List[Any] = []
        seen: Set[int] = set()
        for face in bm.faces:
            if _hidden(face):
                continue
            face_loops = list(face.loops)
            selected_loops: List[Any] = []
            face_sel = _live_face_uv_only(face, uv_layer, mode)
            for loop in face_loops:
                sel = False
                if mode == "FACE":
                    sel = face_sel
                elif mode == "EDGE":
                    sel = _live_e_uv_only(loop, uv_layer)
                    if sel:
                        for lp in (loop, getattr(loop, "link_loop_next", None)):
                            if lp is not None and id(lp) not in seen:
                                seen.add(id(lp)); selected_loops.append(lp)
                        continue
                else:
                    sel = _live_v_uv_only(loop, uv_layer)
                if sel and id(loop) not in seen:
                    seen.add(id(loop)); selected_loops.append(loop)
            if selected_loops:
                faces.append(face)
                loops.extend(selected_loops)
        return nut._UVState(obj=obj, bm=bm, uv_layer=uv_layer, loops=loops, faces=faces, previous_mode=previous_mode)
    except Exception:
        return None


def _patch_native_align_scope() -> None:
    try:
        from . import native_unified_tools as nut
    except Exception:
        return
    try:
        prev = getattr(nut, "_ensure_edit_state", None)
        if not getattr(prev, "_suv_18116_native_scope", False):
            _PREV.setdefault("native._ensure_edit_state", prev)

            def ensure_edit_state_conditional(context: Any = None, *, all_if_empty: bool = True, select_all_if_empty: bool = True):
                if _align_active():
                    return _native_state_uv_only(nut, context)
                old = _PREV.get("native._ensure_edit_state")
                if callable(old):
                    return old(context, all_if_empty=all_if_empty, select_all_if_empty=select_all_if_empty)
                return None

            ensure_edit_state_conditional._suv_18116_native_scope = True  # type: ignore[attr-defined]
            nut._ensure_edit_state = ensure_edit_state_conditional
    except Exception:
        pass
    try:
        prev_select = getattr(nut, "_select_all_edit_faces", None)
        if not getattr(prev_select, "_suv_18116_native_scope", False):
            _PREV.setdefault("native._select_all_edit_faces", prev_select)

            def select_uv_scope_only(context: Any) -> bool:
                if not _align_active():
                    old = _PREV.get("native._select_all_edit_faces")
                    return bool(old(context)) if callable(old) else False
                state = _native_state_uv_only(nut, context)
                if state is None:
                    return False
                try:
                    selected_faces = set(state.faces or [])
                    selected_loops = set(state.loops or [])
                    for face in state.bm.faces:
                        try:
                            face.select_set(face in selected_faces)
                        except Exception:
                            pass
                        for loop in face.loops:
                            try:
                                loop.vert.select_set(loop in selected_loops)
                            except Exception:
                                pass
                            try:
                                loop.edge.select_set(loop in selected_loops)
                            except Exception:
                                pass
                    nut._finish_state(state)
                    return True
                except Exception:
                    return False

            select_uv_scope_only._suv_18116_native_scope = True  # type: ignore[attr-defined]
            nut._select_all_edit_faces = select_uv_scope_only
    except Exception:
        pass
    try:
        _wrap_execute_with_align_scope(getattr(nut, "SMARTUVSUITE_OT_native_align_action", None), "native.align.execute", native_filter=True)
        _wrap_execute_with_align_scope(getattr(nut, "SMARTUVSUITE_OT_native_hub_action", None), "native.hub.execute", native_filter=True)
    except Exception:
        pass


_PREV_INSTALL_18116 = install


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:  # type: ignore[override]
    global _NS, _SUPPLEMENT_INSTALLED
    if isinstance(ns, dict):
        _NS = ns
    try:
        if callable(_PREV_INSTALL_18116):
            _PREV_INSTALL_18116(ns, context)
    except Exception:
        pass
    source = ns if isinstance(ns, dict) else _NS
    if not isinstance(source, dict):
        return
    _patch_room_integrity_conditional()
    _patch_1810_collectors(source)
    _patch_flow_align_classes(source)
    _patch_native_align_scope()
    _mark_version(source)
    _SUPPLEMENT_INSTALLED = True


apply_all = install


def _suv_stage_002_register() -> None:  # type: ignore[override]
    install(_NS, bpy.context)


def diagnostics(context: Any = None) -> Dict[str, Any]:  # type: ignore[override]
    return {
        "version": _VERSION,
        "effective_mode": _effective_uv_mode(context or bpy.context),
        "vertex_align_uv_editor_only": True,
        "island_align_uv_editor_only": True,
        "legacy_align_scope_guard": True,
        "native_align_scope_guard": True,
        "snap_uv_editor_only": True,
    }

# -----------------------------------------------------------------------------
# 1.8.116 UV-selection backend supplement: alignment and UV-editor selection
# readers must never promote 3D View mesh selection to UV targets under Sync.
# -----------------------------------------------------------------------------
def _patch_global_uv_selection_backends() -> None:
    try:
        cur = getattr(ri, "_selected_sets", None)
        if not getattr(cur, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("ri._selected_sets.global", cur)

            def selected_sets_global_uv_only(context: Any, obj: Any, bm: Any, uv_layer: Any, mode: Optional[str] = None):
                return _selected_sets_for_align_uv_only(context, obj, bm, uv_layer, mode)

            selected_sets_global_uv_only._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            ri._selected_sets = selected_sets_global_uv_only
    except Exception:
        pass

    try:
        cur_v = getattr(lgi, "_live_v", None)
        if not getattr(cur_v, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("lgi._live_v.global", cur_v)

            def lgi_live_v(loop: Any, uv_layer: Any) -> bool:
                return _live_v_uv_only(loop, uv_layer)

            lgi_live_v._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            lgi._live_v = lgi_live_v
        cur_e = getattr(lgi, "_live_e", None)
        if not getattr(cur_e, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("lgi._live_e.global", cur_e)

            def lgi_live_e(loop: Any, uv_layer: Any) -> bool:
                return _live_e_uv_only(loop, uv_layer)

            lgi_live_e._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            lgi._live_e = lgi_live_e
        cur_edges = getattr(lgi, "_live_edge_loops", None)
        if not getattr(cur_edges, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("lgi._live_edge_loops.global", cur_edges)

            def lgi_live_edge_loops(bm: Any, uv_layer: Any) -> Set[Any]:
                try:
                    _loops, edge_loops, _faces = _selected_sets_for_align_uv_only(bpy.context, None, bm, uv_layer, "EDGE")
                    return set(edge_loops or set())
                except Exception:
                    return set()

            lgi_live_edge_loops._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            lgi._live_edge_loops = lgi_live_edge_loops
    except Exception:
        pass

    try:
        from . import uv_sync_group_snap_18113 as _sgs_mod
        for name, fn in (("_live_v_sync", _live_v_uv_only), ("_live_e_sync", _live_e_uv_only)):
            cur = getattr(_sgs_mod, name, None)
            if not getattr(cur, "_suv_18116_global_uv_only", False):
                _PREV.setdefault(f"sgs.{name}.global", cur)
                setattr(fn, "_suv_18116_global_uv_only", True)
                setattr(_sgs_mod, name, fn)
    except Exception:
        pass

    try:
        from . import uv_direction_align_1892 as _uda
        cur_v = getattr(_uda, "_live_vert_selected", None)
        if not getattr(cur_v, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("uda._live_vert_selected.global", cur_v)

            def uda_live_vert(loop: Any, uv_layer: Any, sync: bool = False) -> bool:
                return _live_v_uv_only(loop, uv_layer)

            uda_live_vert._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            _uda._live_vert_selected = uda_live_vert
        cur_e = getattr(_uda, "_live_edge_selected", None)
        if not getattr(cur_e, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("uda._live_edge_selected.global", cur_e)

            def uda_live_edge(loop: Any, uv_layer: Any, sync: bool = False) -> bool:
                return _live_e_uv_only(loop, uv_layer)

            uda_live_edge._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            _uda._live_edge_selected = uda_live_edge
        cur_f = getattr(_uda, "_live_face_selected", None)
        if not getattr(cur_f, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("uda._live_face_selected.global", cur_f)

            def uda_live_face(face: Any, sync: bool = False) -> bool:
                try:
                    return bool(getattr(face, "uv_select", False))
                except Exception:
                    return False

            uda_live_face._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            _uda._live_face_selected = uda_live_face
    except Exception:
        pass

    try:
        from . import consolidated_uv_tools as _cut
        cur = getattr(_cut, "_loop_uv_selected", None)
        if not getattr(cur, "_suv_18116_global_uv_only", False):
            _PREV.setdefault("cut._loop_uv_selected.global", cur)

            def cut_loop_uv_selected(context: Any, loop: Any, uv_layer: Any) -> bool:
                try:
                    return _live_v_uv_only(loop, uv_layer) or _live_e_uv_only(loop, uv_layer) or _live_face_uv_only(loop.face, uv_layer, _mode_from_value(context, None))
                except Exception:
                    return False

            cut_loop_uv_selected._suv_18116_global_uv_only = True  # type: ignore[attr-defined]
            _cut._loop_uv_selected = cut_loop_uv_selected
    except Exception:
        pass


_PREV_INSTALL_18116_GLOBAL_UV_ONLY = install


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:  # type: ignore[override]
    global _NS
    if isinstance(ns, dict):
        _NS = ns
    try:
        if callable(_PREV_INSTALL_18116_GLOBAL_UV_ONLY):
            _PREV_INSTALL_18116_GLOBAL_UV_ONLY(ns, context)
    except Exception:
        pass
    _patch_global_uv_selection_backends()
    source = ns if isinstance(ns, dict) else _NS
    if isinstance(source, dict):
        _mark_version(source)


apply_all = install


def _suv_stage_003_register() -> None:  # type: ignore[override]
    install(_NS, bpy.context)

# -----------------------------------------------------------------------------
# 1.8.116 supplement B: multi-object island helpers also ignore mesh selection
# while an alignment operator is executing.
# -----------------------------------------------------------------------------

def _patch_multi_object_island_scope() -> None:
    try:
        prev = getattr(mo, "_face_selected_for_island", None)
        if getattr(prev, "_suv_18116_mo_uv_only", False):
            return
        _PREV.setdefault("mo._face_selected_for_island", prev)

        def face_selected_for_island_conditional(context: Any, face: Any, uv_layer: Any, mode: str) -> bool:
            if _align_active():
                return _live_face_uv_only(face, uv_layer, _mode_from_value(context, mode))
            old = _PREV.get("mo._face_selected_for_island")
            if callable(old):
                return bool(old(context, face, uv_layer, mode))
            return _live_face_uv_only(face, uv_layer, _mode_from_value(context, mode))

        face_selected_for_island_conditional._suv_18116_mo_uv_only = True  # type: ignore[attr-defined]
        mo._face_selected_for_island = face_selected_for_island_conditional
    except Exception:
        pass


_PREV_INSTALL_18116_SUPP_B = install


def install(ns: Optional[Dict[str, Any]] = None, context: Any = None) -> None:  # type: ignore[override]
    if callable(_PREV_INSTALL_18116_SUPP_B):
        try:
            _PREV_INSTALL_18116_SUPP_B(ns, context)
        except Exception:
            pass
    source = ns if isinstance(ns, dict) else _NS
    if isinstance(source, dict):
        _patch_multi_object_island_scope()
        _mark_version(source)


apply_all = install


def register() -> None:  # type: ignore[override]
    install(_NS, bpy.context)
