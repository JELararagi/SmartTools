# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary

"""Machine-readable SmartTools N-panel and persistence contract."""

CONTRACT_VERSION = 6
EXTENSION_ID = "smart_tools_manager"
EXTENSION_VERSION = "1.5.67"
CONFIG_FOLDER = "Smart_Tools_Manager"
CONFIG_FILE = "Smart_Tools_Manager.json"
SETTINGS_SCHEMA = "jelararagi.smart_tools_manager.matrix"
SETTINGS_SCHEMA_VERSION = 4
MATRIX_DIMENSIONS = (16, 17, 21)
MATRIX_CELL_COUNT = 5712
SUITE_COUNT = 21
FUNCTIONAL_SUITE_COUNT = 21
PHYSICAL_ROOT_COUNT = 0
LOGICAL_EDITOR_COUNT = 17
MATRIX_AUTHORITY = "matrix"
PLACEMENT_STATUS_VALUES = ("READY", "NOT_READY")
PLACEMENT_NOT_READY_POLICY = "USE_LAST_KNOWN_AUTHORITATIVE_ELSE_FAIL_OPEN"
PLACEMENT_INVALID_KEY_POLICY = "FAIL_CLOSED"
PLACEMENT_EDITOR_MISMATCH_POLICY = "FAIL_CLOSED"
PLACEMENT_TRUSTED_CACHE_EXCEPTION_POLICY = "FAIL_CLOSED"
WORKSPACE_OWNER_FILTER_CONTRACT = "ANY_EDITOR_ON_RETAINS_SUITE_OWNER_ONLY"
PANEL_VISIBILITY_CONTRACT = "SUITE_ROOT_PANEL_USES_CURRENT_LOGICAL_EDITOR_CELL"
PUBLIC_DECISION_SNAPSHOT_IO = "PURE_CACHED_READ_ONLY"
LIFECYCLE_CONTRACT = "GENERATION_TOKEN_EXACT_TRANSACTIONAL_OWNERSHIP"
RULE_MATRIX_WRITE_API_REVISION = 1
MANAGER_SELF_RULE_POLICY = "NOT_CATALOGUED_NO_N_PANEL"
IDLE_RUNTIME_RESOURCES = "NO_TIMER_NO_WATCHDOG_NO_WORKER_NO_PROXY_NO_ANCHOR"
PURE_DECISION_SNAPSHOT_API = (
    "placement_allowed",
    "_panel_allowed_for_context",
    "panel_rule_allows_context",
    "workspace_tool_allowed",
    "get_placement_state",
    "get_rule_matrix_snapshot",
    "get_rule_matrix_state",
    "get_catalog_snapshot",
    "get_placement_contract",
    "logical_editor_key_from_context",
)
COMPATIBILITY_ACTION_API = ("notify_panel_sources_changed",)
RULE_MATRIX_WRITE_API = (
    "get_current_cell_rule",
    "apply_rule_matrix",
    "subscribe_rule_matrix_commits",
    "unsubscribe_rule_matrix_commits",
)
STATE_SAVE_PATH = "window_manager.smart_tools_manager.n_panel_state_save"
SECTION_OPEN_PATH = "window_manager.smart_tools_manager.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.smart_tools_manager.runtime_automatic_context_sync",
    "window_manager.smart_tools_manager.runtime_source_panel_filters",
    "window_manager.smart_tools_manager.runtime_panel_proxies",
    "window_manager.smart_tools_manager.runtime_category_anchors",
    "window_manager.smart_tools_manager.runtime_ui_callback_repair",
    "window_manager.smart_tools_manager.runtime_transform_guard",
    "window_manager.smart_tools_manager.runtime_stale_proxy_cleanup",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PLACEMENT_API = (
    "placement_allowed",
    "_panel_allowed_for_context",
    "panel_rule_allows_context",
    "workspace_tool_allowed",
    "get_placement_state",
    "get_rule_matrix_snapshot",
    "get_rule_matrix_state",
    "get_catalog_snapshot",
    "get_placement_contract",
    "logical_editor_key_from_context",
    "notify_panel_sources_changed",
    "get_current_cell_rule",
    "apply_rule_matrix",
    "subscribe_rule_matrix_commits",
    "unsubscribe_rule_matrix_commits",
)
ROOT_PANEL_IDS = ()
PERSISTENCE_ROOTS = ("window_manager.smart_tools_manager",)
EXCLUDED_TRANSIENT_PATHS = (
    "window_manager.smart_tools_manager.name",
    "window_manager.smart_tools_manager.runtime_message_lines",
    "window_manager.smart_tools_manager.runtime_message_index",
    "window_manager.smart_tools_manager.runtime_message_text",
)
