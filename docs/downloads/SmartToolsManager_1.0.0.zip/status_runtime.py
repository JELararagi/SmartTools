# Copyright (C) 2026 JELararagi
# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary

"""Resource-neutral compatibility surface for prior SmartTools status calls.

Smart Tools Manager 1.5.67 does not install callback wrappers or background
services. The functions below retain the prior import surface and keep only a
small bounded in-memory message table.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Optional
import uuid

_MAX_ENTRIES = 128
_entries: dict[str, dict[str, Any]] = {}


def _trim() -> None:
    while len(_entries) > _MAX_ENTRIES:
        _entries.pop(next(iter(_entries)), None)


def _upsert(key: str, owner: str, text: str, *, priority: int, duration: Optional[float], kind: str, context=None):
    del context
    _entries[str(key)] = {
        "owner": str(owner),
        "text": str(text),
        "priority": int(priority),
        "duration": duration,
        "kind": str(kind),
    }
    _trim()
    return str(key)


def set_transient(owner: str, text: str, duration: float = 1.5, *, context=None):
    return _upsert(f"transient:{owner}", owner, text, priority=10, duration=duration, kind="transient", context=context)


def set_service(owner: str, text: str, *, context=None):
    return _upsert(f"service:{owner}", owner, text, priority=20, duration=None, kind="service", context=context)


def begin_task(owner: str, text: str, *, context=None):
    token = f"task:{owner}:{uuid.uuid4().hex}"
    return _upsert(token, owner, text, priority=30, duration=None, kind="task", context=context)


def update_task(token: str, text: str, *, context=None):
    del context
    record = _entries.get(str(token))
    if record is not None:
        record["text"] = str(text)
    return token


def finish_task(token: str, final_text: Optional[str] = None, duration: float = 0.12, *, context=None):
    del duration, context
    record = _entries.get(str(token))
    if record is not None and final_text is not None:
        record["text"] = str(final_text)
    _entries.pop(str(token), None)
    return None


def clear(owner_or_token: str, *, context=None):
    del context
    key = str(owner_or_token)
    _entries.pop(key, None)
    for entry_key, record in tuple(_entries.items()):
        if record.get("owner") == key:
            _entries.pop(entry_key, None)


def clear_prefix(prefix: str, *, context=None):
    del context
    prefix = str(prefix)
    for entry_key, record in tuple(_entries.items()):
        if entry_key.startswith(prefix) or str(record.get("owner", "")).startswith(prefix):
            _entries.pop(entry_key, None)


def clear_all(*, context=None):
    del context
    _entries.clear()


def snapshot():
    entries = [dict(value, key=key) for key, value in _entries.items()]
    visible = entries[-1]["text"] if entries else None
    return {
        "version": 5,
        "entry_count": len(entries),
        "entries": entries,
        "visible_text": visible,
        "timer_registered": False,
        "captured_timer_count": 0,
        "captured_draw_count": 0,
        "resource_capture_depth": 0,
        "resource_monitor_registered": False,
        "stats": {},
    }


@contextmanager
def task_scope(owner: str, text: str, *, context=None, completed_text: Optional[str] = None, error_prefix: Optional[str] = None):
    token = begin_task(owner, text, context=context)
    try:
        yield token
    except Exception:
        finish_task(token, error_prefix, context=context)
        raise
    else:
        finish_task(token, completed_text, context=context)


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    del suite_id, suite_label
    return cls


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str):
    del package_marker, suite_id, suite_label
    return 0


def instrument_loaded_package_handlers(package_marker: str, suite_id: str, suite_label: str):
    del package_marker, suite_id, suite_label
    return 0


def restore_package_handlers(suite_id: str):
    del suite_id
    return 0


def prune_orphan_persistent_handler_markers(suite_id: Optional[str] = None):
    del suite_id
    return 0


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


class _HandlerStatusProxy:
    def __init__(self, callback=None, *args, **kwargs):
        del args, kwargs
        self.callback = callback

    def __call__(self, *args, **kwargs):
        if callable(self.callback):
            return self.callback(*args, **kwargs)
        return None
