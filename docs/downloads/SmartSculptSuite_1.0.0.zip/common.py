import importlib
import json
import os
import re
import sys
from pathlib import Path
import bpy
from . import rna_safety as _rna_safety
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, IntProperty, StringProperty

from .popup_text import PopupText, draw_popup_text, popup_page_property, popup_text_property, store_popup_text
from . import _sss_lifecycle as _lifecycle
from . import _sss_json_store as _json_store
from . import guide as _guide
PACKAGE_ID = 'smart_sculpt_suite'
_TRANSLATION_OWNER = PACKAGE_ID + '.common'
ADDON_NAME = 'Smart_Sculpt_Suite'
TOOL_LABEL_EN = 'Smart Sculpt'
TOOL_LABEL_JA = 'スマートスカルプト'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'
_PREVIEW_COLLECTION = None
_PREVIEWS_MODULE = None
_REGISTERED_CLASSES = []
_REGISTERED = False
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}
_COMMON_SETTINGS_KEY = 'persistent_roots'
_ICON_RENAME_ALIASES = {}
_TRANSLATIONS = {('*', 'Help'): 'ヘルプ', ('*', 'Open Help'): 'ヘルプを開く', ('*', 'Feature Overview'): '機能概要', ('*', 'Usage'): '使用方法', ('*', 'Settings'): '設定項目', ('*', 'Commands'): 'コマンド', ('*', 'Always-on Toggle'): '常時機能切り替え', ('*', 'Enabled'): '有効', ('*', 'Disabled'): '無効', ('*', 'Save Preferences'): 'プリファレンスを保存', ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。', ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。', ('*', TOOL_LABEL_EN): TOOL_LABEL_JA}

def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and (not bool(getattr(view, 'use_translate_interface', True))):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False

def text(en, ja=None, context=None):
    return str(ja if ja is not None and _ui_is_japanese(context) else en)

def _smart_exception_text(exc):
    try:
        from . import translation as _smart_locale
        return _smart_locale.exception_ui_text(exc)
    except Exception:
        return str(exc)

def _help_button_row(layout):
    try:
        layout.separator(factor=0.35)
    except TypeError:
        try:
            layout.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.alignment = 'RIGHT'
    except Exception:
        pass
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    return row

def _draw_help_operator(layout, topic: str):
    op = _help_button_row(layout).operator(PACKAGE_ID + '.open_help', text='', icon='QUESTION')
    op.topic = str(topic or '')
    return op

def package_root():
    return Path(__file__).resolve().parent

def _normalized_icon_key(value):
    text = str(value or '').strip().replace('\\', '/').split('/')[-1]
    if text.lower().endswith('.png'):
        text = text[:-4]
    return ''.join((ch.lower() if ch.isalnum() else '_' for ch in text)).strip('_')

def _canonical_icon_key(value):
    key = _normalized_icon_key(value)
    return _ICON_RENAME_ALIASES.get(key, key)

def _icon_asset_path(name):
    root = package_root()
    key = _normalized_icon_key(name)
    canonical = _canonical_icon_key(name)
    stems = []
    for stem in (canonical, key):
        if stem and stem not in stems:
            stems.append(stem)
    folders = (root / 'icons', root / 'icon', root / 'icon' / 'assets')
    for folder in folders:
        for stem in stems:
            path = folder / (stem + '.png')
            if path.exists():
                return path
    return root / 'icons' / (canonical + '.png')

def storage_root(create=True):
    try:
        from . import storage as _smart_storage
        return _smart_storage.user_data_dir(create=bool(create))
    except Exception:
        version = '5.1'
        if os.name == 'nt':
            base = Path(os.environ.get('APPDATA') or Path.home() / 'AppData' / 'Roaming')
            root = base / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_Sculpt_Suite' / 'sidecars' / 'user_data'
        else:
            base = Path(os.environ.get('XDG_CONFIG_HOME') or Path.home() / '.config')
            root = base / 'blender' / version / 'config' / 'Smart_Sculpt_Suite' / 'sidecars' / 'user_data'
        if create:
            try:
                root.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
        return root

def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path

def settings_path():
    try:
        from . import storage as _smart_storage
        return _smart_storage.workspace_settings_path(create=True)
    except Exception:
        pass
    return storage_path('Smart_Sculpt_Suite', 'Smart_Sculpt_Suite.json')

def _preview_module():
    global _PREVIEWS_MODULE
    if _PREVIEWS_MODULE is not None:
        return _PREVIEWS_MODULE
    module = None
    try:
        module = importlib.import_module('bpy.utils.previews')
    except Exception:
        module = None
    if module is None:
        try:
            from bpy.utils import previews as module
        except Exception:
            module = None
    if module is None:
        try:
            module = getattr(getattr(bpy, 'utils', None), 'previews', None)
        except Exception:
            module = None
    _PREVIEWS_MODULE = module
    return module

def _load_previews(force=False):
    global _PREVIEW_COLLECTION
    previews = _preview_module()
    if previews is None:
        _PREVIEW_COLLECTION = None
        return None
    if force and _PREVIEW_COLLECTION is not None:
        try:
            previews.remove(_PREVIEW_COLLECTION)
        except Exception:
            pass
        _PREVIEW_COLLECTION = None
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        pcoll = previews.new()
    except Exception:
        _PREVIEW_COLLECTION = None
        return None
    for name in ():
        path = _icon_asset_path(name)
        if not path.exists():
            continue
        try:
            pcoll.load(name, str(path), 'IMAGE')
        except Exception:
            pass
    _PREVIEW_COLLECTION = pcoll
    return _PREVIEW_COLLECTION

def icon_value(name, fallback=0):
    key = str(name or '').strip()
    pcoll = _PREVIEW_COLLECTION
    item = None
    if pcoll is not None:
        try:
            item = pcoll.get(key)
        except Exception:
            try:
                item = pcoll[key]
            except Exception:
                item = None
    try:
        value = int(getattr(item, 'icon_id', 0) or 0)
    except Exception:
        value = 0
    return value or fallback

def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        previews = _preview_module()
        if previews is not None:
            previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None

def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}

def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []

class SMART_SCULPT_OT_open_help(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this Smart Sculpt tool group.'
    bl_options = set()
    topic: StringProperty(default='overview', options={'SKIP_SAVE'})
    page: popup_page_property()
    page_text: popup_text_property()
    page_size: IntProperty(default=16, options={'HIDDEN', 'SKIP_SAVE'})
    page_count: IntProperty(default=1, options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, event):
        try:
            content = PopupText(680)
            self._draw_topic(content, context)
            store_popup_text(self, context, content)
            return context.window_manager.invoke_popup(self, width=680)
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        draw_popup_text(self, self.layout, text('Page', 'ページ', context))

    def _draw_topic(self, layout, context):
        topic = str(getattr(self, 'topic', '') or 'overview')
        try:
            group = _guide.get_group(topic)
        except Exception as exc:
            group = {'title_en': TOOL_LABEL_EN + ' Help', 'title_ja': TOOL_LABEL_JA + ' ヘルプ', 'overview_en': ['The help catalog could not be loaded: ' + _smart_exception_text(exc)], 'overview_ja': ['ヘルプカタログを読み込めませんでした: ' + _smart_exception_text(exc)], 'usage_en': [], 'usage_ja': [], 'settings': [], 'operators': []}
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context), icon='NONE')
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            box.label(text=item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            box.label(text=item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定項目', context), icon='PREFERENCES')
        if not settings and (not ops):
            box.label(text=text('No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.', 'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。', context))
        for item in settings:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            box.label(text='• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                cmd_box.label(text='• ' + str(name) + ': ' + str(desc))

class SMART_SCULPT_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_description = 'Set an always-on feature to enabled or disabled. Saving follows N-panel State Save.'
    bl_options = {'UNDO'}
    alias: StringProperty(default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, _smart_exception_text(exc))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, _smart_exception_text(exc))
        try:
            import importlib
            root_name = str(__package__ or '').strip() or PACKAGE_ID
            settings_mod = importlib.import_module(f'{root_name}.core.settings')
            request_save = getattr(settings_mod, 'request_immediate_save', None)
            if callable(request_save):
                request_save(getattr(context, 'scene', None), context, force=False)
            else:
                save_persistent_settings(context, force=False)
        except Exception:
            pass
        return {'FINISHED'}

class SMART_SCULPT_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save all Smart Sculpt N-panel settings to Smart_Sculpt_Suite/Smart_Sculpt_Suite.json in the Blender config folder, mirror them to Blender Preferences, and request Blender Save Preferences.'
    bl_options = set()
    _sms_no_undo = True

    def execute(self, context):
        save_persistent_settings(context, force=True)
        try:
            import importlib
            root_name = str(__package__ or '').strip() or PACKAGE_ID
            settings_mod = importlib.import_module(f'{root_name}.core.settings')
            save_scene = getattr(settings_mod, 'save_scene_settings', None)
            save_prefs = getattr(settings_mod, 'save_preferences', None)
            if callable(save_scene):
                save_scene(getattr(context, 'scene', None), force=True)
            if callable(save_prefs):
                save_prefs(context, force=True)
        except Exception:
            pass
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}

class SMART_SCULPT_PT_always_on(bpy.types.Panel):
    bl_idname = 'SMART_SCULPT_PT_always_on'
    bl_label = 'Always-on Toggle'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        try:
            area = getattr(context, 'area', None)
            if area is not None:
                area_type = str(getattr(area, 'type', '') or '')
                supported = {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR', 'FILE_BROWSER', 'SPREADSHEET'}
                if area_type not in supported:
                    return False
            return getattr(context, 'scene', None) is not None
        except Exception:
            return False

    def draw_header(self, context):
        try:
            self.layout.label(text='', icon='TIME')
        except Exception:
            pass

    def draw(self, context):
        try:
            draw_always_on_panel(self.layout, context)
        except Exception as exc:
            try:
                self.layout.label(text=f"{text('Always-on panel draw failed', '常時起動パネル描画に失敗しました', context)}: {_smart_exception_text(exc)}", icon='ERROR')
            except Exception:
                pass

def _compact_npanel_layout(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout

def _feature_entries():
    try:
        feature_toggle = sys.modules.get(f"{__package__}.feature_toggle")
        if feature_toggle is None:
            return []
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []

def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()

def _draw_always_on_switch_row(layout, context, label, enabled, alias='', feature_key=''):
    row = _compact_npanel_layout(layout.row(align=True))
    try:
        row.scale_y = 0.95
    except Exception:
        pass
    split = row.split(factor=0.72, align=True)
    left = _compact_npanel_layout(split.row(align=True))
    left.label(text=str(label or TOOL_LABEL_EN))
    right = _compact_npanel_layout(split.row(align=True))
    button_text = text('On', '有効', context) if enabled else text('Off', '無効', context)
    icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
    try:
        op = right.operator(PACKAGE_ID + '.set_always_on', text=button_text, icon=icon, depress=bool(enabled))
    except TypeError:
        op = right.operator(PACKAGE_ID + '.set_always_on', text=button_text, depress=bool(enabled))
    op.alias = str(alias or '')
    op.feature_key = str(feature_key or '')
    op.enabled = not bool(enabled)

def draw_always_on_panel(layout, context):
    col = _compact_npanel_layout(layout.column(align=True))
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            _draw_always_on_switch_row(col, context, label, enabled, alias, feature_key)
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    _draw_always_on_switch_row(col, context, TOOL_LABEL_EN, enabled)

def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID

def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))

def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw

def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return '_SUITE_OT_OPEN_HELP' in upper or '_SUITE_OT_SET_ALWAYS_ON' in upper or '_SUITE_PT_ROOT' in upper or ('_SUITE_PT_ALWAYS_ON' in upper)

def _materialize_annotations(cls):
    """Static RNA classes require no runtime annotation reconstruction."""
    return cls

def _safe_unregister_class(cls):
    try:
        return bool(_rna_safety.unregister_class(cls))
    except Exception:
        return False

def begin_register():
    """Compatibility no-op; registration is owned by the generation journal."""
    return None


def end_register():
    """Compatibility no-op paired with :func:`begin_register`."""
    return None


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None

def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots

_OWN_SETTING_ROOT_NAMES = frozenset({
    'core',
    'smart_sculpt_npanel_settings',
    'smart_sculpt_suite_preferences',
    'strict_edit_mode_sculpt_settings',
    'sculptnav',
    'sculptnav_ignored_collections',
    'sculptnav_ignored_collections_index',
})
_OWN_SETTING_PREFIXES = (
    'smart_sculpt_suite_',
    'smart_sculpt_',
    'sss_',
    'sculptnav_',
    'strict_edit_mode_sculpt_',
)


def _prop_relevant(name, value, owner=None):
    """Return True only for Smart Sculpt-owned persistence fields.

    Historic builds used broad prefixes such as ``smart_``, ``sps_`` and
    ``suv_``.  That could serialize and later assign properties belonging to
    another installed Suite.  Persistence now accepts only this package's
    explicit root names, its unambiguous prefixes, or a nested RNA value whose
    Python type is defined by this exact package namespace.
    """
    lower = str(name or '').strip().lower()
    if not lower:
        return False
    if lower == _ALWAYS_ON_PROP.lower() or lower in _OWN_SETTING_ROOT_NAMES:
        return True
    if any(lower.startswith(prefix) for prefix in _OWN_SETTING_PREFIXES):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and (module_name == prefix or module_name.startswith(prefix + '.')):
            return True
    except Exception:
        pass
    return False

def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data

def collect_persistent_settings(context=None):
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload

def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict) or obj is None:
        return
    for key, value in data.items():
        try:
            current = getattr(obj, key, None)
            if not _prop_relevant(key, current, obj):
                # Old shared JSON may contain fields captured from other
                # SmartTools.  Never assign those values back into foreign RNA.
                continue
            if isinstance(value, dict):
                if current is not None:
                    _apply_group(current, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass

def _capture_transform_guard_for_context(context=None):
    """Return a compatibility guard without scanning scene objects.

    Smart Sculpt persistence only reads/writes RNA settings and never changes
    object transforms.  Capturing every object transform at startup, file load,
    save, undo, or scene switch is therefore unnecessary and scales linearly
    with scene size.  Keep the return shape for older callers while making the
    normal settings path constant-time.
    """
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    return (scene, {})

def _restore_transform_guard_for_context(scene, state):
    if not state:
        return
    try:
        from .core import utils as _core_utils
        _core_utils.restore_scene_object_transforms(state, scene)
    except Exception:
        pass

def apply_persistent_settings(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    scene, transform_guard = _capture_transform_guard_for_context(ctx)
    try:
        data = _LOADED_SETTINGS or load_settings_file()
        for root_name, root in _iter_setting_roots(ctx):
            if root_name in data:
                _apply_group(root, data[root_name], 0)
    finally:
        _restore_transform_guard_for_context(scene, transform_guard)

def _extract_common_settings(data):
    if not isinstance(data, dict):
        return {}
    nested = data.get(_COMMON_SETTINGS_KEY)
    if isinstance(nested, dict):
        return nested
    legacy = {}
    for key in ('window_manager', 'scene'):
        value = data.get(key)
        if isinstance(value, dict):
            legacy[key] = value
    return legacy

def _shared_settings_validator(payload):
    return isinstance(payload, dict) and str(payload.get('addon_id', PACKAGE_ID) or PACKAGE_ID) == PACKAGE_ID

def _read_shared_settings_file():
    path = settings_path()
    try:
        document = _json_store.read_with_backup(
            path, validator=_shared_settings_validator, allow_legacy=True, repair=True
        )
        return _json_store.payload_only(document) if isinstance(document, dict) else {}
    except Exception:
        return {}

def _write_shared_settings_file(data):
    value = dict(data) if isinstance(data, dict) else {}
    value.setdefault('version', 1)
    value.setdefault('addon_id', PACKAGE_ID)
    value.setdefault('storage_folder', 'Smart_Sculpt_Suite')
    value.setdefault('storage_file', 'Smart_Sculpt_Suite.json')
    try:
        from . import storage as _smart_storage
        _smart_storage.write_workspace_settings(value)
        return True
    except Exception:
        pass
    try:
        path = settings_path()
        _json_store.atomic_write(path, value, validator=_shared_settings_validator)
        verified = _json_store.read_with_backup(
            path, validator=_shared_settings_validator, allow_legacy=False, repair=False
        )
        return isinstance(verified, dict) and _json_store.payload_only(verified) == value
    except Exception:
        return False

def load_settings_file():
    global _LOADED_SETTINGS
    raw = _read_shared_settings_file()
    data = _extract_common_settings(raw)
    _LOADED_SETTINGS = data
    return data

def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    data = collect_persistent_settings(context)
    try:
        raw = json.dumps(data, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return False
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return True
    shared = _read_shared_settings_file()
    shared[_COMMON_SETTINGS_KEY] = data
    shared['version'] = 1
    shared['addon_id'] = PACKAGE_ID
    shared['storage_folder'] = 'Smart_Sculpt_Suite'
    shared['storage_file'] = 'Smart_Sculpt_Suite.json'
    if not _write_shared_settings_file(shared):
        return False
    # The in-memory fingerprint advances only after validated readback succeeds.
    _AUTOSAVE_FINGERPRINT = raw
    return True

def _autosave_timer():
    """Disabled: persistent polling is prohibited; saves are event/property driven."""
    return None

@persistent
def _load_post_handler(dummy=None, *args, **kwargs):
    try:
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass

def _append_handler_once(collection, handler):
    return _lifecycle.append_handler(collection, handler)

def _remove_handler(collection, handler):
    return _lifecycle.remove_handler(collection, handler)

def register():
    global _REGISTERED
    if _REGISTERED:
        return
    registered_now = []
    property_registered = False
    translation_registered = False
    try:
        _lifecycle.register_translation(_TRANSLATION_OWNER, _translation_payload())
        translation_registered = True
        _rna_safety.register_property(
            bpy.types.WindowManager,
            _ALWAYS_ON_PROP,
            BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this tool. Enable it only when persistent helper behavior is required.',
                default=False,
            ),
        )
        property_registered = True
        for cls in (SMART_SCULPT_OT_open_help, SMART_SCULPT_OT_set_always_on, SMART_SCULPT_OT_save_preferences):
            _materialize_annotations(cls)
            if not _rna_safety.register_class(cls):
                raise RuntimeError(f'Common class registration failed: {cls.__name__}')
            registered_now.append(cls)
        _REGISTERED_CLASSES[:] = registered_now
        try:
            load_settings_file()
        except Exception as exc:
            from . import _sss_runtime_errors as _runtime_errors
            _runtime_errors.record('common_settings_load', exc)
        _REGISTERED = True
    except Exception:
        for cls in reversed(registered_now):
            try:
                _rna_safety.unregister_class(cls)
            except Exception:
                pass
        if property_registered:
            try:
                _rna_safety.unregister_property(bpy.types.WindowManager, _ALWAYS_ON_PROP)
            except Exception:
                pass
        if translation_registered:
            try:
                _lifecycle.unregister_translation(_TRANSLATION_OWNER)
            except Exception:
                pass
        _REGISTERED_CLASSES.clear()
        _REGISTERED = False
        raise

def rollback_registration():
    global _REGISTERED, _PREVIEWS_MODULE, _LOADED_SETTINGS, _AUTOSAVE_FINGERPRINT
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        try:
            _rna_safety.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    try:
        _rna_safety.unregister_property(bpy.types.WindowManager, _ALWAYS_ON_PROP)
    except Exception:
        pass
    try:
        _remove_previews()
    except Exception:
        pass
    try:
        _lifecycle.unregister_translation(_TRANSLATION_OWNER)
    except Exception:
        pass
    _PREVIEWS_MODULE = None
    _LOADED_SETTINGS = {}
    _AUTOSAVE_FINGERPRINT = ''
    _REGISTERED = False

def unregister():
    global _REGISTERED
    if _REGISTERED:
        try:
            save_persistent_settings(bpy.context, force=True)
        except Exception:
            pass
    rollback_registration()
