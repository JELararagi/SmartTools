# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import math
import random
import re

import bmesh
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator
from mathutils import Matrix, Vector

from . import icon_assets, properties, utils, utils as _smart_utils


REPORT_TEXT_NAME = "SSS_Smart_Supreme_Report"


def _smart_ops():
    return getattr(bpy.ops, 'smart_sculpt', None)


def _call_smart_operator(name: str, variants: Iterable[dict] | None = None):
    smart_ops = _smart_ops()
    operator = getattr(smart_ops, name, None) if smart_ops is not None else None
    if operator is None:
        raise RuntimeError(f"Smart Sculpt operator not registered: {name}")
    return utils.safe_operator_call(operator, list(variants or [{}]))


def _settings(context):
    return utils.settings_from_context(context)


def _call_fix_common_issues_without_scale_apply(context):
    settings = _settings(context)
    had_attr = False
    original_value = False
    try:
        if settings is not None and hasattr(settings, 'apply_scale_on_fix'):
            had_attr = True
            original_value = bool(getattr(settings, 'apply_scale_on_fix', False))
            settings.apply_scale_on_fix = False
        return _call_smart_operator('fix_common_issues')
    finally:
        if had_attr and settings is not None:
            try:
                settings.apply_scale_on_fix = original_value
            except Exception:
                pass


def _active_mesh_or_cancel(op: Operator, context):
    obj = utils.active_mesh_object(context)
    if obj is None:
        op.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
        return None
    return obj


def _snapshot_if_enabled(context, obj, reason: str) -> None:
    settings = _settings(context)
    try:
        if settings is not None and bool(getattr(settings, 'smart_upgrade_make_snapshot', True)):
            _call_smart_operator('save_snapshot')
    except Exception:
        pass
    try:
        utils.make_recovery_backup(context, obj, reason, force=False)
    except Exception:
        pass


def _quality_profile(settings) -> dict[str, Any]:
    quality = str(getattr(settings, 'smart_upgrade_quality', 'HIGH') if settings is not None else 'HIGH') or 'HIGH'
    profiles: dict[str, dict[str, Any]] = {
        'APEX': {
            'name': 'APEX', 'count_mul': 3.6, 'segment_mul': 4.0, 'target_face_mul': 5.5,
            'cloth_quality': 20, 'bevel_segments': 9, 'normal_weight': 100, 'report_detail': 5,
        },
        'FRONTIER': {
            'name': 'FRONTIER', 'count_mul': 2.8, 'segment_mul': 3.0, 'target_face_mul': 4.0,
            'cloth_quality': 16, 'bevel_segments': 7, 'normal_weight': 95, 'report_detail': 4,
        },
        'SAFE': {
            'name': 'SAFE', 'count_mul': 0.65, 'segment_mul': 0.7, 'target_face_mul': 0.55,
            'cloth_quality': 4, 'bevel_segments': 1, 'normal_weight': 35, 'report_detail': 1,
        },
        'BALANCED': {
            'name': 'BALANCED', 'count_mul': 1.0, 'segment_mul': 1.0, 'target_face_mul': 1.0,
            'cloth_quality': 6, 'bevel_segments': 2, 'normal_weight': 50, 'report_detail': 1,
        },
        'HIGH': {
            'name': 'HIGH', 'count_mul': 1.35, 'segment_mul': 1.5, 'target_face_mul': 1.75,
            'cloth_quality': 9, 'bevel_segments': 3, 'normal_weight': 65, 'report_detail': 2,
        },
        'ULTRA': {
            'name': 'ULTRA', 'count_mul': 2.0, 'segment_mul': 2.25, 'target_face_mul': 3.0,
            'cloth_quality': 12, 'bevel_segments': 5, 'normal_weight': 80, 'report_detail': 3,
        },
    }
    return dict(profiles.get(quality, profiles['HIGH']))


def _clamp_int(value: Any, minimum: int, maximum: int, fallback: int) -> int:
    try:
        ivalue = int(round(float(value)))
    except Exception:
        ivalue = int(fallback)
    return max(minimum, min(maximum, ivalue))


def _clamp_float(value: Any, minimum: float, maximum: float, fallback: float) -> float:
    try:
        fvalue = float(value)
    except Exception:
        fvalue = float(fallback)
    return max(minimum, min(maximum, fvalue))


def _bounds_points(obj) -> list[Vector]:
    try:
        return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    except Exception:
        loc = getattr(obj, 'location', Vector((0.0, 0.0, 0.0))).copy()
        return [loc + Vector((x, y, z)) for x in (-0.5, 0.5) for y in (-0.5, 0.5) for z in (-0.5, 0.5)]


def _bounds_center_radius(obj) -> tuple[Vector, float]:
    points = _bounds_points(obj)
    if not points:
        return Vector((0.0, 0.0, 0.0)), 1.0
    center = Vector((0.0, 0.0, 0.0))
    for point in points:
        center += point
    center /= len(points)
    radius = max((point - center).length for point in points) if points else 1.0
    return center, max(radius, 0.05)



def _precision_score(stats: dict[str, Any]) -> int:
    if not stats:
        return 0
    score = 100.0
    faces = max(int(stats.get('faces', 0) or 0), 1)
    edges = max(int(stats.get('edges', 0) or 0), 1)
    score -= min(30.0, (int(stats.get('loose_vertices', 0) or 0) / max(int(stats.get('vertices', 1) or 1), 1)) * 100.0)
    score -= min(30.0, (int(stats.get('zero_area_faces', 0) or 0) / faces) * 120.0)
    score -= min(35.0, (int(stats.get('non_manifold_edges', 0) or 0) / edges) * 80.0)
    score -= min(18.0, float(stats.get('ngon_ratio', 0.0) or 0.0) * 35.0)
    score -= min(12.0, max(0.0, float(stats.get('edge_length_cv', 0.0) or 0.0) - 0.75) * 10.0)
    score -= min(8.0, max(0.0, float(stats.get('bbox_aspect', 1.0) or 1.0) - 12.0) * 0.35)
    if int(stats.get('faces', 0) or 0) <= 0:
        score = 0.0
    return max(0, min(100, int(round(score))))


def _stats_float(stats: dict[str, Any], key: str, fallback: float = 0.0) -> float:
    try:
        value = float(stats.get(key, fallback))
    except Exception:
        value = float(fallback)
    if math.isnan(value) or math.isinf(value):
        return float(fallback)
    return value


def _recommended_detail_scale(stats: dict[str, Any], density: float) -> float:
    bbox_diag = max(_stats_float(stats, 'bbox_diag', 0.0), 0.0)
    avg_edge = max(_stats_float(stats, 'avg_edge_length', 0.0), 0.0)
    pitch = max(_stats_float(stats, 'detail_pitch_estimate', 0.0), 0.0)
    candidates = [value for value in (avg_edge, pitch, bbox_diag * 0.006, float(density)) if value > 1e-8]
    if not candidates:
        return max(float(density), 0.001)
    candidates.sort()
    return max(0.0001, candidates[min(len(candidates) - 1, max(0, len(candidates) // 2))])


def _adapt_runtime_to_mesh(stats: dict[str, Any], quality: dict[str, Any], strength: float, density: float, count: int, segments: int, target_faces: int, steps: list[str]) -> tuple[float, float, int, int, int]:
    if not stats:
        return strength, density, count, segments, target_faces
    qname = str(quality.get('name', 'HIGH'))
    detail = _recommended_detail_scale(stats, density)
    bbox_diag = max(_stats_float(stats, 'bbox_diag', 0.0), 0.001)
    faces = max(int(stats.get('faces', 0) or 0), 1)
    score = int(stats.get('precision_score', 0) or 0)
    risk_mul = 1.0 if score >= 80 else 0.78 if score >= 55 else 0.55
    density_mix = 0.72 if qname in {'HIGH', 'ULTRA', 'FRONTIER', 'APEX'} else 0.45
    tuned_density = max(0.0001, density * (1.0 - density_mix) + detail * density_mix)
    tuned_strength = max(0.0, min(5.0, strength * (0.85 + min(0.45, bbox_diag * 0.015)) * risk_mul))
    complexity = max(0.6, min(2.0, math.sqrt(faces / 12000.0)))
    tuned_count = _clamp_int(count * (0.8 + complexity * 0.35) * risk_mul, 1, 5000, count)
    tuned_segments = _clamp_int(segments * (0.85 + min(1.0, complexity * 0.25)), 2, 256, segments)
    desired_faces = max(target_faces, int(faces * (1.1 if qname in {'SAFE', 'BALANCED'} else 1.35 if qname == 'HIGH' else 1.8 if qname == 'ULTRA' else 2.05)))
    tuned_target = _clamp_int(desired_faces * risk_mul, 100, 2000000, target_faces)
    steps.append(
        f"Mesh-adaptive precision scale: score={score}, density={density:.6f}->{tuned_density:.6f}, strength={strength:.4f}->{tuned_strength:.4f}, target_faces={target_faces}->{tuned_target}"
    )
    return tuned_strength, tuned_density, tuned_count, tuned_segments, tuned_target

def _mesh_stats(obj, *, allow_mesh_update: bool = True) -> dict[str, Any]:
    mesh = getattr(obj, 'data', None)
    if obj is None or getattr(obj, 'type', None) != 'MESH' or mesh is None:
        return {}
    if allow_mesh_update and str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') == 'OBJECT':
        try:
            mesh.update(calc_edges=True)
        except Exception:
            pass
    vertices = list(getattr(mesh, 'vertices', []) or [])
    edges = list(getattr(mesh, 'edges', []) or [])
    polygons = list(getattr(mesh, 'polygons', []) or [])
    edge_face_count: dict[tuple[int, int], int] = {}
    for poly in polygons:
        try:
            keys = tuple(getattr(poly, 'edge_keys', ()) or ())
        except Exception:
            keys = ()
        if not keys:
            verts = list(getattr(poly, 'vertices', []) or [])
            keys = tuple(tuple(sorted((verts[i], verts[(i + 1) % len(verts)]))) for i in range(len(verts))) if len(verts) > 1 else ()
        for key in keys:
            try:
                normalized = tuple(sorted((int(key[0]), int(key[1]))))
            except Exception:
                continue
            edge_face_count[normalized] = edge_face_count.get(normalized, 0) + 1
    linked_vertex_counts = {int(getattr(vertex, 'index', idx)): 0 for idx, vertex in enumerate(vertices)}
    edge_lengths: list[float] = []
    try:
        world_coords = [obj.matrix_world @ vertex.co for vertex in vertices]
    except Exception:
        world_coords = [getattr(vertex, 'co', Vector((0.0, 0.0, 0.0))).copy() for vertex in vertices]
    for edge in edges:
        try:
            v0, v1 = edge.vertices[:]
        except Exception:
            continue
        linked_vertex_counts[int(v0)] = linked_vertex_counts.get(int(v0), 0) + 1
        linked_vertex_counts[int(v1)] = linked_vertex_counts.get(int(v1), 0) + 1
        try:
            edge_lengths.append(float((world_coords[int(v0)] - world_coords[int(v1)]).length))
        except Exception:
            pass
    zero_area_faces = 0
    tris = 0
    quads = 0
    ngons = 0
    surface_area = 0.0
    max_face_area = 0.0
    min_face_area = None
    for poly in polygons:
        try:
            sides = len(poly.vertices)
        except Exception:
            sides = 0
        if sides == 3:
            tris += 1
        elif sides == 4:
            quads += 1
        elif sides > 4:
            ngons += 1
        try:
            area = float(poly.area)
            surface_area += max(area, 0.0)
            max_face_area = max(max_face_area, area)
            min_face_area = area if min_face_area is None else min(min_face_area, area)
            if area <= 1e-12:
                zero_area_faces += 1
        except Exception:
            pass
    non_manifold_edges = sum(1 for edge in edges if edge_face_count.get(tuple(sorted((int(edge.vertices[0]), int(edge.vertices[1])))), 0) != 2)
    boundary_edges = sum(1 for count in edge_face_count.values() if count == 1)
    over_connected_edges = sum(1 for count in edge_face_count.values() if count > 2)
    loose_vertices = sum(1 for count in linked_vertex_counts.values() if count <= 0)
    avg_valence = (sum(linked_vertex_counts.values()) / max(len(linked_vertex_counts), 1)) if linked_vertex_counts else 0.0
    avg_edge = (sum(edge_lengths) / len(edge_lengths)) if edge_lengths else 0.0
    min_edge = min(edge_lengths) if edge_lengths else 0.0
    max_edge = max(edge_lengths) if edge_lengths else 0.0
    center, radius = _bounds_center_radius(obj)
    points = _bounds_points(obj)
    if points:
        xs = [p.x for p in points]
        ys = [p.y for p in points]
        zs = [p.z for p in points]
        bbox_x = max(xs) - min(xs)
        bbox_y = max(ys) - min(ys)
        bbox_z = max(zs) - min(zs)
    else:
        bbox_x = bbox_y = bbox_z = radius * 2.0
    dims = [max(float(v), 1e-9) for v in (bbox_x, bbox_y, bbox_z)]
    bbox_diag = math.sqrt(bbox_x * bbox_x + bbox_y * bbox_y + bbox_z * bbox_z)
    bbox_aspect = max(dims) / max(min(dims), 1e-9)
    face_count = max(len(polygons), 1)
    quad_ratio = quads / face_count
    ngon_ratio = ngons / face_count
    tri_ratio = tris / face_count
    nonmanifold_ratio = non_manifold_edges / max(len(edges), 1)
    zero_area_ratio = zero_area_faces / face_count
    edge_variance = 0.0
    if len(edge_lengths) > 1 and avg_edge > 1e-12:
        edge_variance = sum((length - avg_edge) ** 2 for length in edge_lengths) / len(edge_lengths)
        edge_variance = math.sqrt(edge_variance) / max(avg_edge, 1e-12)
    symmetry_scores: dict[str, float] = {}
    try:
        locs = [co - center for co in world_coords]
        threshold = max(avg_edge * 0.25, bbox_diag * 0.001)
        for axis_name, axis_index in (('x', 0), ('y', 1), ('z', 2)):
            pos = sum(1 for co in locs if co[axis_index] > threshold)
            neg = sum(1 for co in locs if co[axis_index] < -threshold)
            total = max(pos + neg, 1)
            symmetry_scores[f'symmetry_{axis_name}'] = round(1.0 - abs(pos - neg) / total, 4)
    except Exception:
        symmetry_scores = {'symmetry_x': 0.0, 'symmetry_y': 0.0, 'symmetry_z': 0.0}
    detail_pitch = bbox_diag / max(math.sqrt(float(face_count)), 1.0) if bbox_diag > 0.0 else avg_edge
    stats = {
        'object': getattr(obj, 'name', ''),
        'vertices': len(vertices),
        'edges': len(edges),
        'faces': len(polygons),
        'triangles': tris,
        'quads': quads,
        'ngons': ngons,
        'loose_vertices': loose_vertices,
        'non_manifold_edges': non_manifold_edges,
        'boundary_edges': boundary_edges,
        'over_connected_edges': over_connected_edges,
        'zero_area_faces': zero_area_faces,
        'uv_layers': len(getattr(mesh, 'uv_layers', []) or []),
        'materials': len(getattr(obj, 'material_slots', []) or []),
        'modifiers': len(getattr(obj, 'modifiers', []) or []),
        'shape_keys': len(getattr(getattr(mesh, 'shape_keys', None), 'key_blocks', []) or []),
        'surface_area': round(surface_area, 6),
        'avg_edge_length': round(avg_edge, 6),
        'min_edge_length': round(min_edge, 6),
        'max_edge_length': round(max_edge, 6),
        'edge_length_cv': round(edge_variance, 4),
        'avg_valence': round(avg_valence, 3),
        'bbox_x': round(bbox_x, 6),
        'bbox_y': round(bbox_y, 6),
        'bbox_z': round(bbox_z, 6),
        'bbox_diag': round(bbox_diag, 6),
        'bbox_aspect': round(bbox_aspect, 4),
        'detail_pitch_estimate': round(detail_pitch, 6),
        'quad_ratio': round(quad_ratio, 4),
        'tri_ratio': round(tri_ratio, 4),
        'ngon_ratio': round(ngon_ratio, 4),
        'nonmanifold_ratio': round(nonmanifold_ratio, 4),
        'zero_area_ratio': round(zero_area_ratio, 4),
    }
    stats.update(symmetry_scores)
    stats['precision_score'] = _precision_score(stats)
    return stats

def _mesh_risk_notes(stats: dict[str, Any]) -> list[str]:
    notes: list[str] = []
    if not stats:
        return notes
    t = _smart_utils.ui_text
    if int(stats.get('faces', 0) or 0) <= 0:
        notes.append(t('no polygon faces', '面がありません'))
    if int(stats.get('loose_vertices', 0) or 0) > 0:
        notes.append(f"{t('loose vertices', '孤立頂点')}: {stats.get('loose_vertices')}")
    if int(stats.get('zero_area_faces', 0) or 0) > 0:
        notes.append(f"{t('zero-area faces', '面積ゼロの面')}: {stats.get('zero_area_faces')}")
    if int(stats.get('non_manifold_edges', 0) or 0) > 0:
        notes.append(f"{t('non-manifold/boundary edges', '非多様体辺・境界辺')}: {stats.get('non_manifold_edges')}")
    if int(stats.get('over_connected_edges', 0) or 0) > 0:
        notes.append(f"{t('over-connected edges', '3 面以上がつながる辺')}: {stats.get('over_connected_edges')}")
    if int(stats.get('ngons', 0) or 0) > 0:
        notes.append(f"{t('ngons', 'N ゴン')}: {stats.get('ngons')}")
    if float(stats.get('edge_length_cv', 0.0) or 0.0) > 1.2:
        notes.append(f"{t('irregular edge lengths', '辺の長さのばらつきが大きい')}: {stats.get('edge_length_cv')}")
    if float(stats.get('bbox_aspect', 1.0) or 1.0) > 18.0:
        notes.append(f"{t('extreme bounding-box aspect', '外形の縦横比が極端')}: {stats.get('bbox_aspect')}")
    if float(stats.get('quad_ratio', 1.0) or 0.0) < 0.35 and int(stats.get('faces', 0) or 0) > 100:
        notes.append(f"{t('low quad ratio', '四角面の割合が低い')}: {stats.get('quad_ratio')}")
    if int(stats.get('precision_score', 100) or 100) < 70:
        notes.append(f"{t('precision score below production target', '精度スコアが制作の目安より低い')}: {stats.get('precision_score')}/100")
    return notes


def recommend_smart_action(stats: dict[str, Any] | None, obj=None, settings=None) -> str:
    """Choose a high-impact Smart route from measurable production-readiness signals.

    This recommender is intentionally conservative: it routes risky meshes to repair
    or retopo first, and only routes clean meshes to the strongest precision passes.
    """
    stats = stats or {}
    faces = int(stats.get('faces', 0) or 0)
    score = int(stats.get('precision_score', 0) or 0)
    quad_ratio = float(stats.get('quad_ratio', 0.0) or 0.0)
    uv_layers = int(stats.get('uv_layers', 0) or 0)
    shape_keys = int(stats.get('shape_keys', 0) or 0)
    non_manifold = int(stats.get('non_manifold_edges', 0) or 0)
    zero_area = int(stats.get('zero_area_faces', 0) or 0)
    loose = int(stats.get('loose_vertices', 0) or 0)
    ngons = int(stats.get('ngons', 0) or 0)
    bbox_aspect = float(stats.get('bbox_aspect', 1.0) or 1.0)
    edge_cv = float(stats.get('edge_length_cv', 0.0) or 0.0)
    qname = str(getattr(settings, 'smart_upgrade_quality', '') if settings is not None else '').upper()

    if faces <= 0:
        return 'BSPHERE_ARMATURE_BLOCKOUT'
    if loose > 0 or zero_area > 0 or non_manifold > max(4, faces * 0.025) or score < 50:
        return 'MESH_DOCTOR_PRO'
    if quad_ratio < 0.32 and faces > 250:
        return 'WRAP_RETOPO_UV'
    if uv_layers <= 0 and faces > 500 and quad_ratio >= 0.35:
        return 'WRAP_RETOPO_UV'
    if bbox_aspect > 22.0 or edge_cv > 1.65 or ngons > max(12, faces * 0.05):
        return 'MESH_CLEANER_PRO'
    if shape_keys <= 1 and score >= 70 and qname in {'HIGH', 'ULTRA', 'FRONTIER', 'APEX'}:
        return 'SCULPT_LAYER_STACK_PRO'
    if score >= 86 and quad_ratio >= 0.55 and uv_layers > 0 and shape_keys > 1:
        return 'SUPREME_STUDIO_PIPELINE'
    if score >= 72:
        return 'PRECISION_FRONTIER_PASS'
    return 'ADAPTIVE_MASTER_PASS'

def _safe_validate_mesh(obj, steps: list[str]) -> bool:
    mesh = getattr(obj, 'data', None)
    if mesh is None or getattr(obj, 'type', None) != 'MESH':
        return False
    changed = False
    try:
        changed = bool(mesh.validate(verbose=False, clean_customdata=False))
    except TypeError:
        try:
            changed = bool(mesh.validate(verbose=False))
        except Exception:
            changed = False
    except Exception:
        changed = False
    try:
        mesh.update(calc_edges=True)
    except Exception:
        pass
    steps.append(f"Mesh validate: {'changed data' if changed else 'no structural change reported'}")
    return changed



def _bmesh_precision_cleanup(obj, steps: list[str], *, merge_distance: float, remove_loose: bool = True) -> dict[str, int]:
    result = {'removed_loose_vertices': 0, 'removed_degenerate': 0, 'merged_vertices': 0}
    mesh = getattr(obj, 'data', None)
    if mesh is None or getattr(obj, 'type', None) != 'MESH':
        return result
    try:
        utils.ensure_object_mode(bpy.context, obj)
    except Exception:
        pass
    bm = None
    try:
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        before_verts = len(bm.verts)
        before_edges = len(bm.edges)
        if remove_loose:
            loose = [vert for vert in bm.verts if not vert.link_edges]
            if loose:
                result['removed_loose_vertices'] = len(loose)
                bmesh.ops.delete(bm, geom=loose, context='VERTS')
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
        if bm.edges:
            before_edges_for_degenerate = len(bm.edges)
            try:
                bmesh.ops.dissolve_degenerate(bm, edges=list(bm.edges), dist=max(float(merge_distance), 0.0))
            except TypeError:
                bmesh.ops.dissolve_degenerate(bm, edges=list(bm.edges))
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            result['removed_degenerate'] = max(0, before_edges_for_degenerate - len(bm.edges))
        if bm.verts and merge_distance > 0.0:
            before_merge = len(bm.verts)
            bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=max(float(merge_distance), 0.0))
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            result['merged_vertices'] = max(0, before_merge - len(bm.verts))
        if bm.faces:
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        bm.to_mesh(mesh)
        mesh.update(calc_edges=True)
        steps.append(
            "BMesh precision cleanup: "
            f"loose={result['removed_loose_vertices']}, degenerate_edges={result['removed_degenerate']}, merged={result['merged_vertices']}, "
            f"verts {before_verts}->{len(mesh.vertices)}, edges {before_edges}->{len(mesh.edges)}"
        )
    except Exception as exc:
        steps.append(f"BMesh precision cleanup skipped/failed: {_smart_utils.exception_ui_text(exc)}")
    finally:
        try:
            if bm is not None:
                bm.free()
        except Exception:
            pass
    return result


def _create_precision_face_attributes(obj, steps: list[str], *, label: str = 'SSS_SemanticZone') -> int:
    mesh = getattr(obj, 'data', None)
    if mesh is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    try:
        mesh.update(calc_edges=True)
    except Exception:
        pass
    attrs = getattr(mesh, 'attributes', None)
    if attrs is None:
        return 0
    try:
        attr = attrs.get(label)
        if attr is None:
            attr = attrs.new(name=label, type='INT', domain='FACE')
    except Exception:
        return 0
    try:
        points = _bounds_points(obj)
        if points:
            min_z = min(point.z for point in points)
            max_z = max(point.z for point in points)
        else:
            min_z, max_z = 0.0, 1.0
        z_span = max(max_z - min_z, 1e-8)
        assigned = 0
        for poly in getattr(mesh, 'polygons', []) or []:
            normal = getattr(poly, 'normal', Vector((0.0, 0.0, 1.0))).copy()
            try:
                center = obj.matrix_world @ poly.center
            except Exception:
                center = getattr(poly, 'center', Vector((0.0, 0.0, 0.0))).copy()
            height_band = int(max(0, min(2, math.floor(((center.z - min_z) / z_span) * 3.0))))
            axis = max(range(3), key=lambda idx: abs(float(normal[idx]))) if normal.length_squared > 1e-12 else 2
            zone = height_band * 3 + axis
            try:
                attr.data[poly.index].value = int(zone)
                assigned += 1
            except Exception:
                pass
        if assigned:
            mesh.update()
            steps.append(f"Precision semantic face attribute written: {label} ({assigned} faces)")
        return assigned
    except Exception as exc:
        steps.append(f"Precision semantic face attribute skipped/failed: {_smart_utils.exception_ui_text(exc)}")
        return 0


def _create_curvature_proxy_groups(obj, steps: list[str]) -> int:
    mesh = getattr(obj, 'data', None)
    if mesh is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    try:
        coords = [obj.matrix_world @ vertex.co for vertex in mesh.vertices]
    except Exception:
        coords = [getattr(vertex, 'co', Vector((0.0, 0.0, 0.0))).copy() for vertex in getattr(mesh, 'vertices', [])]
    if not coords:
        return 0
    center = sum(coords, Vector((0.0, 0.0, 0.0))) / len(coords)
    distances = [(co - center).length for co in coords]
    max_distance = max(max(distances), 1e-8)
    try:
        outer = obj.vertex_groups.new(name=utils.unique_name('SSS_OuterMassProxy'))
        inner = obj.vertex_groups.new(name=utils.unique_name('SSS_InnerCoreProxy'))
    except Exception:
        return 0
    assigned = 0
    for vertex, dist in zip(getattr(mesh, 'vertices', []) or [], distances):
        ratio = max(0.0, min(1.0, dist / max_distance))
        try:
            outer.add([vertex.index], ratio, 'REPLACE')
            inner.add([vertex.index], 1.0 - ratio, 'REPLACE')
            assigned += 1
        except Exception:
            pass
    if assigned:
        steps.append(f"Curvature/mass proxy vertex groups created: {assigned} vertices")
    return assigned



def _create_topology_quality_groups(obj, steps: list[str]) -> int:
    """Create production-oriented vertex groups that make topology risks visible.

    These groups are non-destructive and help artists decide where to run cleanup,
    retopo, relax, cloth pinning, or local microdetail actions.
    """
    mesh = getattr(obj, 'data', None)
    if mesh is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    vertices = list(getattr(mesh, 'vertices', []) or [])
    edges = list(getattr(mesh, 'edges', []) or [])
    polygons = list(getattr(mesh, 'polygons', []) or [])
    if not vertices:
        return 0
    try:
        mesh.update(calc_edges=True)
    except Exception:
        pass
    edge_face_count: dict[tuple[int, int], int] = {}
    for poly in polygons:
        try:
            keys = tuple(getattr(poly, 'edge_keys', ()) or ())
        except Exception:
            keys = ()
        if not keys:
            verts = list(getattr(poly, 'vertices', []) or [])
            keys = tuple(tuple(sorted((verts[i], verts[(i + 1) % len(verts)]))) for i in range(len(verts))) if len(verts) > 1 else ()
        for key in keys:
            try:
                normalized = tuple(sorted((int(key[0]), int(key[1]))))
            except Exception:
                continue
            edge_face_count[normalized] = edge_face_count.get(normalized, 0) + 1
    valence = {int(getattr(v, 'index', idx)): 0 for idx, v in enumerate(vertices)}
    boundary_risk = {idx: 0.0 for idx in valence}
    edge_lengths: list[float] = []
    try:
        coords = [obj.matrix_world @ vertex.co for vertex in vertices]
    except Exception:
        coords = [getattr(vertex, 'co', Vector((0.0, 0.0, 0.0))).copy() for vertex in vertices]
    edge_length_by_key: dict[tuple[int, int], float] = {}
    for edge in edges:
        try:
            v0, v1 = int(edge.vertices[0]), int(edge.vertices[1])
        except Exception:
            continue
        key = tuple(sorted((v0, v1)))
        valence[v0] = valence.get(v0, 0) + 1
        valence[v1] = valence.get(v1, 0) + 1
        count = edge_face_count.get(key, 0)
        if count != 2:
            risk = 1.0 if count == 0 or count > 2 else 0.68
            boundary_risk[v0] = max(boundary_risk.get(v0, 0.0), risk)
            boundary_risk[v1] = max(boundary_risk.get(v1, 0.0), risk)
        try:
            length = float((coords[v0] - coords[v1]).length)
            edge_lengths.append(length)
            edge_length_by_key[key] = length
        except Exception:
            pass
    avg_edge = (sum(edge_lengths) / len(edge_lengths)) if edge_lengths else 0.0
    length_risk = {idx: 0.0 for idx in valence}
    if avg_edge > 1e-12:
        for key, length in edge_length_by_key.items():
            ratio = length / avg_edge
            risk = max(0.0, min(1.0, abs(ratio - 1.0) / 2.5))
            if risk <= 0.03:
                continue
            v0, v1 = key
            length_risk[v0] = max(length_risk.get(v0, 0.0), risk)
            length_risk[v1] = max(length_risk.get(v1, 0.0), risk)
    try:
        valence_group = obj.vertex_groups.new(name=utils.unique_name('SSS_ValenceRisk'))
        boundary_group = obj.vertex_groups.new(name=utils.unique_name('SSS_OpenBoundaryRisk'))
        length_group = obj.vertex_groups.new(name=utils.unique_name('SSS_EdgeLengthRisk'))
        detail_group = obj.vertex_groups.new(name=utils.unique_name('SSS_DetailPriority'))
    except Exception as exc:
        steps.append(f"Topology quality groups skipped/failed: {_smart_utils.exception_ui_text(exc)}")
        return 0
    assigned = 0
    for vertex in vertices:
        idx = int(getattr(vertex, 'index', 0))
        val = max(0.0, min(1.0, abs(float(valence.get(idx, 0)) - 4.0) / 6.0))
        boundary = max(0.0, min(1.0, boundary_risk.get(idx, 0.0)))
        length = max(0.0, min(1.0, length_risk.get(idx, 0.0)))
        detail = max(val, boundary, length * 0.75)
        try:
            if val > 0.001:
                valence_group.add([idx], val, 'REPLACE')
            if boundary > 0.001:
                boundary_group.add([idx], boundary, 'REPLACE')
            if length > 0.001:
                length_group.add([idx], length, 'REPLACE')
            if detail > 0.001:
                detail_group.add([idx], detail, 'REPLACE')
            assigned += 1
        except Exception:
            pass
    if assigned:
        steps.append(f"Topology quality/risk vertex groups created: {assigned} vertices")
    return assigned


def _create_apex_intelligence_groups(obj, steps: list[str]) -> int:
    """Create additional vertex groups that expose sculpt-readiness signals.

    The groups are diagnostic only and are designed to make precision decisions
    visible: normal variance, area priority, symmetry deviation, and apex focus.
    """
    mesh = getattr(obj, 'data', None)
    if obj is None or getattr(obj, 'type', None) != 'MESH' or mesh is None:
        return 0
    vertices = list(getattr(mesh, 'vertices', []) or [])
    polygons = list(getattr(mesh, 'polygons', []) or [])
    if not vertices:
        return 0
    try:
        mesh.update(calc_edges=True)
    except Exception:
        pass
    try:
        coords = [obj.matrix_world @ vertex.co for vertex in vertices]
    except Exception:
        coords = [getattr(vertex, 'co', Vector((0.0, 0.0, 0.0))).copy() for vertex in vertices]
    center, radius = _bounds_center_radius(obj)
    max_radius = max(radius, 1e-8)
    linked_faces: dict[int, list[Any]] = {int(getattr(v, 'index', idx)): [] for idx, v in enumerate(vertices)}
    for poly in polygons:
        for vid in getattr(poly, 'vertices', []) or []:
            try:
                linked_faces.setdefault(int(vid), []).append(poly)
            except Exception:
                pass
    # Determine the most balanced symmetry axis. The lower the score, the more deviation to expose.
    stats = _mesh_stats(obj)
    axis_scores = {
        0: float(stats.get('symmetry_x', 0.0) or 0.0),
        1: float(stats.get('symmetry_y', 0.0) or 0.0),
        2: float(stats.get('symmetry_z', 0.0) or 0.0),
    }
    symmetry_axis = max(axis_scores, key=lambda axis_index: axis_scores.get(axis_index, 0.0))
    try:
        groups = {
            'normal': obj.vertex_groups.new(name=utils.unique_name('SSS_NormalVariance')),
            'area': obj.vertex_groups.new(name=utils.unique_name('SSS_SurfaceAreaPriority')),
            'symmetry': obj.vertex_groups.new(name=utils.unique_name('SSS_SymmetryDeviation')),
            'focus': obj.vertex_groups.new(name=utils.unique_name('SSS_ApexFocusPriority')),
        }
    except Exception as exc:
        steps.append(f"Apex intelligence groups skipped/failed: {_smart_utils.exception_ui_text(exc)}")
        return 0
    assigned = 0
    max_face_area = max([float(getattr(poly, 'area', 0.0) or 0.0) for poly in polygons] or [1.0])
    max_face_area = max(max_face_area, 1e-12)
    for vertex, co in zip(vertices, coords):
        vid = int(getattr(vertex, 'index', 0))
        faces = linked_faces.get(vid, [])
        if faces:
            avg_normal = Vector((0.0, 0.0, 0.0))
            avg_area = 0.0
            for poly in faces:
                try:
                    avg_normal += getattr(poly, 'normal', Vector((0.0, 0.0, 1.0))).copy()
                    avg_area += max(float(getattr(poly, 'area', 0.0) or 0.0), 0.0)
                except Exception:
                    pass
            if avg_normal.length_squared > 1e-12:
                avg_normal.normalize()
            else:
                avg_normal = Vector((0.0, 0.0, 1.0))
            variance = 0.0
            for poly in faces:
                try:
                    normal = getattr(poly, 'normal', Vector((0.0, 0.0, 1.0))).copy()
                    if normal.length_squared > 1e-12:
                        normal.normalize()
                    variance = max(variance, max(0.0, 1.0 - avg_normal.dot(normal)))
                except Exception:
                    pass
            normal_weight = max(0.0, min(1.0, variance * 1.35))
            area_weight = max(0.0, min(1.0, (avg_area / max(len(faces), 1)) / max_face_area))
        else:
            normal_weight = 1.0
            area_weight = 0.0
        axis_span = max(float(stats.get(('bbox_x', 'bbox_y', 'bbox_z')[symmetry_axis], 0.0) or 0.0), 1e-8)
        symmetry_distance = abs(float((co - center)[symmetry_axis])) / axis_span
        symmetry_weight = max(0.0, min(1.0, symmetry_distance * (1.0 - axis_scores.get(symmetry_axis, 0.0) + 0.35) * 2.2))
        radial = max(0.0, min(1.0, (co - center).length / max_radius))
        focus_weight = max(normal_weight, symmetry_weight * 0.8, radial * 0.35, area_weight * 0.6)
        try:
            if normal_weight > 0.001:
                groups['normal'].add([vid], normal_weight, 'REPLACE')
            if area_weight > 0.001:
                groups['area'].add([vid], area_weight, 'REPLACE')
            if symmetry_weight > 0.001:
                groups['symmetry'].add([vid], symmetry_weight, 'REPLACE')
            if focus_weight > 0.001:
                groups['focus'].add([vid], focus_weight, 'REPLACE')
            assigned += 1
        except Exception:
            pass
    if assigned:
        steps.append(f"Apex intelligence vertex groups created: {assigned} vertices")
    return assigned


def _create_cloth_pin_group(obj, steps: list[str], *, name: str = 'SSS_ClothPinGradient'):
    mesh = getattr(obj, 'data', None)
    if mesh is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        coords = [obj.matrix_world @ vertex.co for vertex in mesh.vertices]
    except Exception:
        coords = [getattr(vertex, 'co', Vector((0.0, 0.0, 0.0))).copy() for vertex in getattr(mesh, 'vertices', [])]
    if not coords:
        return None
    min_z = min(co.z for co in coords)
    max_z = max(co.z for co in coords)
    span = max(max_z - min_z, 1e-8)
    try:
        group = obj.vertex_groups.new(name=utils.unique_name(name))
    except Exception:
        return None
    assigned = 0
    for vertex, co in zip(getattr(mesh, 'vertices', []) or [], coords):
        height = (co.z - min_z) / span
        weight = max(0.0, min(1.0, (height - 0.45) / 0.55))
        try:
            group.add([vertex.index], weight, 'REPLACE')
            assigned += 1
        except Exception:
            pass
    if assigned:
        steps.append(f"Cloth pin gradient group created: {getattr(group, 'name', name)} ({assigned} vertices)")
    return group


def _create_surface_guide_curves(context, obj, steps: list[str], *, count: int, segments: int, density: float, quality: dict[str, Any], kind: str = 'precision_surface_guides') -> int:
    samples = _surface_growth_samples(context, obj, max(2, count), random.Random(count * 1777 + segments * 31))
    if not samples:
        return 0
    center, extent = _bounds_center_radius(obj)
    created = 0
    limit = max(1, min(int(count), 48))
    for idx, (start, normal) in enumerate(samples[:limit]):
        tangent = normal.cross(Vector((0.0, 0.0, 1.0)))
        if tangent.length_squared < 1e-10:
            tangent = normal.cross(Vector((1.0, 0.0, 0.0)))
        tangent.normalize()
        length = max(extent * 0.12, density * 2.0)
        points = []
        for step in range(max(2, min(int(segments), 64))):
            t = (step / max(segments - 1, 1)) - 0.5
            points.append(start + tangent * (length * t) + normal * (math.sin(t * math.pi) * density * 0.12))
        helper = _link_curve_helper(context, f"SSS_SurfaceGuide_{idx+1:02d}", points, max(density * 0.018, 0.0005), kind)
        try:
            helper['sss_guide_target'] = obj.name
            helper['sss_smart_quality'] = str(quality.get('name', 'HIGH'))
        except Exception:
            pass
        created += 1
    if created:
        steps.append(f"Surface guide curves created: {created}")
    return created

def _link_curve_helper(context, name: str, points: list[Vector], bevel_depth: float, kind: str):
    curve = bpy.data.curves.new(utils.unique_name(name), type='CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 2
    curve.bevel_depth = max(float(bevel_depth), 0.0001)
    curve.bevel_resolution = 2
    spline = curve.splines.new('POLY')
    spline.points.add(max(0, len(points) - 1))
    for p, co in zip(spline.points, points):
        p.co = (float(co.x), float(co.y), float(co.z), 1.0)
    obj = bpy.data.objects.new(utils.unique_name(name), curve)
    try:
        collection = utils.helper_collection(getattr(context, 'scene', None))
        collection.objects.link(obj)
    except Exception:
        collection = getattr(context, 'collection', None) or getattr(getattr(context, 'scene', None), 'collection', None)
        if collection is None:
            try:
                collection = getattr(getattr(bpy, 'context', None), 'scene', None).collection
            except Exception:
                collection = None
        if collection is not None:
            try:
                collection.objects.link(obj)
            except Exception:
                pass
    utils.mark_generated(obj, kind)
    return obj


def _surface_growth_samples(context, target, count: int, rng: random.Random) -> list[tuple[Vector, Vector]]:
    if target is None or getattr(target, 'type', None) != 'MESH' or count <= 0:
        return []
    samples: list[tuple[Vector, Vector]] = []
    depsgraph = None
    eval_obj = None
    mesh = None
    try:
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = target.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        try:
            mesh.calc_loop_triangles()
        except Exception:
            pass
        vertices = getattr(mesh, 'vertices', []) or []
        loop_tris = list(getattr(mesh, 'loop_triangles', []) or [])
        if not loop_tris:
            polygons = [poly for poly in getattr(mesh, 'polygons', []) if getattr(poly, 'area', 0.0) > 1e-12]
            if not polygons:
                return []
            weights = [max(float(poly.area), 1e-12) for poly in polygons]
            total = sum(weights)
            cumulative: list[float] = []
            running = 0.0
            for weight in weights:
                running += weight
                cumulative.append(running)
            normal_matrix = target.matrix_world.to_3x3().inverted().transposed()
            for _idx in range(min(max(int(count), 1), 1200)):
                pick = rng.random() * total
                lo, hi = 0, len(cumulative) - 1
                while lo < hi:
                    mid = (lo + hi) // 2
                    if cumulative[mid] < pick:
                        lo = mid + 1
                    else:
                        hi = mid
                poly = polygons[lo]
                center = target.matrix_world @ poly.center
                normal = normal_matrix @ poly.normal
                if normal.length_squared < 1e-10:
                    normal = Vector((0.0, 0.0, 1.0))
                normal.normalize()
                samples.append((center, normal))
            return samples
        weights = []
        for tri in loop_tris:
            try:
                weights.append(max(float(tri.area), 1e-12))
            except Exception:
                weights.append(1e-12)
        total = sum(weights)
        if total <= 0.0:
            return []
        cumulative: list[float] = []
        running = 0.0
        for weight in weights:
            running += weight
            cumulative.append(running)
        normal_matrix = target.matrix_world.to_3x3().inverted().transposed()
        matrix = target.matrix_world
        for _idx in range(min(max(int(count), 1), 1200)):
            pick = rng.random() * total
            lo, hi = 0, len(cumulative) - 1
            while lo < hi:
                mid = (lo + hi) // 2
                if cumulative[mid] < pick:
                    lo = mid + 1
                else:
                    hi = mid
            tri = loop_tris[lo]
            try:
                indices = list(tri.vertices[:])
                v0, v1, v2 = [vertices[int(index)].co for index in indices[:3]]
                r1 = math.sqrt(rng.random())
                r2 = rng.random()
                local = (1.0 - r1) * v0 + (r1 * (1.0 - r2)) * v1 + (r1 * r2) * v2
                point = matrix @ local
                normal = normal_matrix @ tri.normal
            except Exception:
                point = matrix @ tri.center
                normal = normal_matrix @ tri.normal
            if normal.length_squared < 1e-10:
                normal = Vector((0.0, 0.0, 1.0))
            normal.normalize()
            samples.append((point, normal))
    except Exception:
        samples = []
    finally:
        try:
            if eval_obj is not None and mesh is not None:
                eval_obj.to_mesh_clear()
        except Exception:
            pass
    return samples

def _create_environment_growth(context, target, *, count: int, segments: int, radius: float, strength: float, quality: dict[str, Any]) -> int:
    center, extent = _bounds_center_radius(target)
    rng = random.Random(int(count * 92821 + segments * 37 + int(float(strength) * 1000)))
    created = 0
    count = max(1, min(int(count), 500))
    segments = max(2, min(int(segments), 192))
    bevel = max(float(radius) * 0.08, 0.001)
    curvature_mul = 1.0 + 0.12 * int(quality.get('report_detail', 1) or 1)
    samples = _surface_growth_samples(context, target, count, rng)
    for idx in range(count):
        angle = (idx / max(count, 1)) * math.tau + rng.uniform(-0.25, 0.25)
        if samples:
            start, normalish = samples[idx % len(samples)]
            tangent = normalish.cross(Vector((0.0, 0.0, 1.0)))
            if tangent.length_squared < 1e-10:
                tangent = normalish.cross(Vector((1.0, 0.0, 0.0)))
            tangent.normalize()
            tangent.rotate(Matrix.Rotation(rng.uniform(-math.pi, math.pi), 4, normalish))
        else:
            height = rng.uniform(-0.35, 0.55) * extent
            start = center + Vector((math.cos(angle) * extent * rng.uniform(0.25, 0.95), math.sin(angle) * extent * rng.uniform(0.25, 0.95), height))
            tangent = Vector((-math.sin(angle), math.cos(angle), rng.uniform(-0.25, 0.55))).normalized()
            normalish = (start - center)
            if normalish.length_squared < 1e-10:
                normalish = Vector((0.0, 0.0, 1.0))
            normalish.normalize()
        length = extent * rng.uniform(0.25, 0.8) * max(0.25, min(3.0, 1.0 + float(strength)))
        points: list[Vector] = []
        for step in range(segments):
            t = step / max(segments - 1, 1)
            wave = math.sin(t * math.pi * rng.uniform(1.0, 3.0) + rng.random() * math.tau) * extent * 0.06 * curvature_mul
            cling = normalish * (wave + t * extent * 0.025)
            co = start + tangent * (length * t) + cling
            points.append(co)
        helper = _link_curve_helper(context, f"SSS_Growth_{idx+1:02d}", points, bevel * rng.uniform(0.6, 1.4), 'environment_growth')
        try:
            helper["sss_growth_target"] = target.name
            helper["sss_growth_style"] = "precision_surface_sampled_vine_crack_moss" if samples else "precision_bound_vine_crack_moss"
            helper["sss_smart_quality"] = str(quality.get('name', 'HIGH'))
        except Exception:
            pass
        created += 1
    return created


def _add_weighted_normal(obj, *, weight: int = 50) -> bool:
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    try:
        for modifier in getattr(obj, 'modifiers', []):
            if modifier.type == 'WEIGHTED_NORMAL' and modifier.name.startswith('SSS_PrecisionWeightedNormal'):
                return False
        normal = obj.modifiers.new(name=utils.unique_name("SSS_PrecisionWeightedNormal"), type='WEIGHTED_NORMAL')
        utils.set_attr_if_exists(normal, 'keep_sharp', True)
        utils.set_attr_if_exists(normal, 'weight', max(1, min(int(weight), 100)))
        utils.set_attr_if_exists(normal, 'mode', 'FACE_AREA_WITH_ANGLE')
        return True
    except Exception:
        return False


def _add_precision_bevel(obj, *, width: float, segments: int) -> bool:
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    try:
        bevel = obj.modifiers.new(name=utils.unique_name("SSS_PrecisionBevel"), type='BEVEL')
        bevel.width = max(float(width), 0.0001)
        bevel.segments = max(1, min(int(segments), 12))
        utils.set_attr_if_exists(bevel, 'limit_method', 'ANGLE')
        utils.set_attr_if_exists(bevel, 'harden_normals', True)
        return True
    except Exception:
        return False


def _add_corrective_layer_modifiers(obj, strength: float) -> int:
    added = 0
    try:
        smooth = obj.modifiers.new(name=utils.unique_name("SSS_MuscleCorrectiveSmooth"), type='CORRECTIVE_SMOOTH')
        utils.set_attr_if_exists(smooth, 'factor', max(0.0, min(float(strength), 1.0)))
        utils.set_attr_if_exists(smooth, 'iterations', 4)
        added += 1
    except Exception:
        try:
            smooth = obj.modifiers.new(name=utils.unique_name("SSS_MuscleSmooth"), type='SMOOTH')
            utils.set_attr_if_exists(smooth, 'factor', max(0.0, min(float(strength), 1.0)))
            utils.set_attr_if_exists(smooth, 'iterations', 4)
            added += 1
        except Exception:
            pass
    try:
        obj['sss_muscle_layer_driver'] = 'Smart Sculpt Supreme'
    except Exception:
        pass
    return added


def _create_photo_reference_plane(context, source_path: str, *, size: float):
    image = None
    safe_path = str(source_path or '').strip()
    if not safe_path:
        try:
            fallback_path = Path(icon_assets.reference_image_path())
            if fallback_path.exists():
                safe_path = str(fallback_path)
        except Exception:
            safe_path = ''
    if safe_path:
        try:
            path = Path(bpy.path.abspath(safe_path)).expanduser()
            if path.exists() and path.is_file():
                image = bpy.data.images.load(str(path), check_existing=True)
        except Exception:
            image = None
    long_side = max(float(size), 0.05)
    aspect = 1.0
    if image is not None:
        try:
            width, height = image.size[:2]
            if int(width) > 0 and int(height) > 0:
                aspect = max(0.01, min(100.0, float(width) / float(height)))
        except Exception:
            aspect = 1.0
    if aspect >= 1.0:
        half_w = long_side * 0.5
        half_h = (long_side / aspect) * 0.5
    else:
        half_h = long_side * 0.5
        half_w = (long_side * aspect) * 0.5
    mesh = bpy.data.meshes.new(utils.unique_name('SSS_PhotoReferenceMesh'))
    mesh.from_pydata([(-half_w, -half_h, 0.0), (half_w, -half_h, 0.0), (half_w, half_h, 0.0), (-half_w, half_h, 0.0)], [], [(0, 1, 2, 3)])
    mesh.update()
    try:
        uv = mesh.uv_layers.new(name='UVMap')
        coords = ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0))
        for loop, coord in zip(uv.data, coords):
            loop.uv = coord
    except Exception:
        pass
    obj = bpy.data.objects.new(utils.unique_name('SSS_PhotoReference'), mesh)
    try:
        collection = utils.helper_collection(getattr(context, 'scene', None))
        collection.objects.link(obj)
    except Exception:
        collection = getattr(context, 'collection', None) or getattr(getattr(context, 'scene', None), 'collection', None)
        if collection is None:
            try:
                collection = getattr(getattr(bpy, 'context', None), 'scene', None).collection
            except Exception:
                collection = None
        if collection is not None:
            try:
                collection.objects.link(obj)
            except Exception:
                pass
    utils.mark_generated(obj, 'photo_reference')
    try:
        obj.show_in_front = True
        obj.display_type = 'TEXTURED'
        obj.lock_rotation[0] = True
        obj.lock_rotation[1] = True
        obj.lock_scale[0] = True
        obj.lock_scale[1] = True
        obj.lock_scale[2] = True
        obj['sss_photo_reference_aspect'] = aspect
    except Exception:
        pass
    if image is not None:
        try:
            mat = bpy.data.materials.new(utils.unique_name('SSS_PhotoReferenceMaterial'))
            mat.use_nodes = True
            utils.mark_generated(mat, 'material')
            nodes = mat.node_tree.nodes
            links = mat.node_tree.links
            bsdf = nodes.get('Principled BSDF')
            tex = nodes.new(type='ShaderNodeTexImage')
            tex.image = image
            if bsdf is not None:
                color = tex.outputs.get('Color')
                base = bsdf.inputs.get('Base Color')
                if color is not None and base is not None:
                    links.new(color, base)
                alpha_out = tex.outputs.get('Alpha')
                alpha_in = bsdf.inputs.get('Alpha')
                if alpha_out is not None and alpha_in is not None:
                    links.new(alpha_out, alpha_in)
            utils.set_attr_if_exists(mat, 'blend_method', 'BLEND')
            mesh.materials.append(mat)
            obj['sss_photo_reference_file'] = safe_path
        except Exception:
            pass
    else:
        try:
            obj['sss_photo_reference_file'] = safe_path
            obj['sss_photo_reference_note'] = 'Set Smart Photo Reference File to load a custom image on the next run. Blank input uses the packaged Smart Sculpt reference board.'
        except Exception:
            pass
    return obj


def _add_cloth_drape_modifiers(obj, strength: float, density: float, quality: dict[str, Any], pin_group=None) -> int:
    added = 0
    try:
        cloth = obj.modifiers.new(name=utils.unique_name("SSS_VellumClothApprox"), type='CLOTH')
        settings = getattr(cloth, 'settings', None)
        if settings is not None:
            utils.set_attr_if_exists(settings, 'quality', int(quality.get('cloth_quality', 8)))
            utils.set_attr_if_exists(settings, 'mass', max(0.02, min(5.0, 0.3 + float(strength))))
            utils.set_attr_if_exists(settings, 'tension_stiffness', 12.0)
            utils.set_attr_if_exists(settings, 'compression_stiffness', 12.0)
            utils.set_attr_if_exists(settings, 'shear_stiffness', 5.0)
            utils.set_attr_if_exists(settings, 'bending_stiffness', max(0.1, min(50.0, float(density) * 20.0)))
            if pin_group is not None:
                utils.set_attr_if_exists(settings, 'vertex_group_mass', getattr(pin_group, 'name', ''))
                utils.set_attr_if_exists(settings, 'pin_stiffness', max(0.1, min(50.0, float(density) * 30.0)))
        added += 1
    except Exception:
        pass
    try:
        tex = bpy.data.textures.new(utils.unique_name("SSS_ClothWrinkle"), type='VORONOI')
        utils.mark_generated(tex, 'texture')
        utils.set_attr_if_exists(tex, 'noise_scale', max(float(density), 0.001))
        disp = obj.modifiers.new(name=utils.unique_name("SSS_ClothWrinkle"), type='DISPLACE')
        disp.texture = tex
        disp.strength = max(float(strength), 0.0) * 0.25
        utils.set_attr_if_exists(disp, 'direction', 'NORMAL')
        added += 1
    except Exception:
        pass
    try:
        smooth = obj.modifiers.new(name=utils.unique_name("SSS_ClothPrecisionSmooth"), type='SMOOTH')
        smooth.factor = 0.04
        smooth.iterations = max(1, min(4, int(quality.get('report_detail', 1))))
        added += 1
    except Exception:
        pass
    return added


def _object_names() -> set[str]:
    try:
        return {obj.name for obj in bpy.data.objects}
    except Exception:
        return set()


def _generated_since(before_names: set[str]) -> list[str]:
    after = _object_names()
    return sorted(name for name in after.difference(before_names) if name)


_REPORT_STAT_LABELS = {
    'object': ('Object', 'オブジェクト'), 'vertices': ('Vertices', '頂点'), 'edges': ('Edges', '辺'), 'faces': ('Faces', '面'),
    'triangles': ('Triangles', '三角面'), 'quads': ('Quads', '四角面'), 'ngons': ('N-gons', 'N ゴン'),
    'loose_vertices': ('Loose vertices', '孤立頂点'), 'non_manifold_edges': ('Non-manifold edges', '非多様体辺'),
    'boundary_edges': ('Boundary edges', '境界辺'), 'over_connected_edges': ('Over-connected edges', '3 面以上がつながる辺'),
    'zero_area_faces': ('Zero-area faces', '面積ゼロの面'), 'uv_layers': ('UV maps', 'UV マップ'), 'materials': ('Materials', 'マテリアル'),
    'modifiers': ('Modifiers', 'モディファイア'), 'shape_keys': ('Shape keys', 'シェイプキー'), 'surface_area': ('Surface area', '表面積'),
    'avg_edge_length': ('Average edge length', '辺の平均の長さ'), 'min_edge_length': ('Shortest edge', '最短の辺'),
    'max_edge_length': ('Longest edge', '最長の辺'), 'edge_length_cv': ('Edge-length variation', '辺の長さのばらつき'),
    'avg_valence': ('Average valence', '頂点あたりの平均の辺数'), 'bbox_x': ('Size X', '大きさ X'), 'bbox_y': ('Size Y', '大きさ Y'),
    'bbox_z': ('Size Z', '大きさ Z'), 'bbox_diag': ('Diagonal size', '対角の大きさ'), 'bbox_aspect': ('Aspect ratio', '縦横比'),
    'detail_pitch_estimate': ('Estimated detail pitch', '推定のディテール間隔'), 'quad_ratio': ('Quad ratio', '四角面の割合'),
    'tri_ratio': ('Triangle ratio', '三角面の割合'), 'ngon_ratio': ('N-gon ratio', 'N ゴンの割合'),
    'nonmanifold_ratio': ('Non-manifold ratio', '非多様体の割合'), 'zero_area_ratio': ('Zero-area ratio', '面積ゼロの割合'),
    'precision_score': ('Precision score', '精度スコア'), 'symmetry_x': ('Symmetry X', '対称性 X'), 'symmetry_y': ('Symmetry Y', '対称性 Y'),
    'symmetry_z': ('Symmetry Z', '対称性 Z'),
}

_REPORT_STEP_PREFIXES = (('Supreme Studio ', '最上位スタジオ処理: '), ('Precision Frontier ', '高精度仕上げパス: '))
_REPORT_STEP_PARTS = {
    'BMesh precision cleanup': 'BMesh の精密な整理', 'Precision semantic face attribute': '意味別フェース属性',
    'Topology quality groups': 'トポロジー品質グループ', 'Apex intelligence groups': '最上位知能グループ',
    'Dyntopo readiness': 'ダイナミックトポロジーの準備', 'Shape layer checkpoint': 'シェイプレイヤーのチェックポイント',
    'Analysis refresh': '解析の更新', 'face grouping': 'フェイスセットの分割', 'Multires': 'マルチレゾ',
    'procedural stack': 'プロシージャルスタック', 'retopo helper': 'リトポ補助', 'Voxel remesh': 'ボクセルリメッシュ',
    'Multires step': 'マルチレゾの段階', 'Auto UV': '自動 UV', 'Cloth filter': 'クロスフィルター', 'Driver link': 'ドライバーの接続',
    'Curve tube': 'カーブチューブ', 'Rail cutter': 'レールカッター', 'Procedural stack': 'プロシージャルスタック',
    'Selected scatter': '選択物の散布', 'DLA stack': '成長スタック', 'Common issue repair': '共通の修正', 'Analysis': '解析',
    'Diagnostic report': '診断レポート',
}
_REPORT_STEP_EXACT = {
    'Preflight warnings: none': '事前検査の警告: なし', 'Precision weighted normal added': 'ウェイト付き法線を追加しました',
    'Active brush stored to Tool Pipe slot 1': '現在のブラシをツールパイプのスロット 1 に保存しました',
    'BSphere/ZSphere-style sphere chain generated': 'BSphere/ZSphere 風の球の列を作成しました',
    'Safety snapshot/recovery backup requested': '安全スナップショットと回復バックアップを実行しました',
    'profile/view prepared': 'プロファイルと表示を準備しました', 'Adaptive master profile/view prepared': '適応マスターのプロファイルと表示を準備しました',
    'Multires staging requested': 'マルチレゾの段階化を実行しました',
    'Destructive BMesh cleanup skipped by non-destructive preference or sufficient precision score': '非破壊の設定または十分なスコアのため、破壊的な BMesh の整理を省略しました',
    'Dyntopo readiness configured from N-panel settings': 'N パネルの設定でダイナミックトポロジーを準備しました',
    'Non-destructive sculpt layer checkpoint created': '非破壊のスカルプトレイヤーのチェックポイントを作成しました',
    'Common mesh issue repair operator executed': '共通のメッシュ修正を実行しました',
    'Common mesh issue repair operator unavailable; validation-only pass used': '共通のメッシュ修正を使えないため、検証だけを行いました',
    'Post-clean analysis refreshed': '整理後の解析を更新しました', 'Native Smart Sculpt shape layer operator executed': 'シェイプレイヤーの操作を実行しました',
    'Single-object multi workflow preparation used': '1 つのオブジェクトで複数作業の準備を行いました', 'Dyntopo configured': 'ダイナミックトポロジーを設定しました',
    'Hybrid surface procedural stack added': 'ハイブリッド表面のプロシージャルスタックを追加しました', 'Shape layer safety created': '安全用のシェイプレイヤーを作成しました',
    'Voxel remesh completed': 'ボクセルリメッシュを実行しました', 'Multires step added': 'マルチレゾの段階を追加しました', 'Hybrid surface stack added': 'ハイブリッド表面のスタックを追加しました',
    'Exact boolean rail cutter created': '厳密ブーリアンのレールカッターを作成しました', 'Automatic UV projection completed': '自動 UV 投影を実行しました', 'Cloth filter applied': 'クロスフィルターを適用しました',
    'Shape layer created': 'シェイプレイヤーを作成しました', 'Fallback shape key created': '代わりのシェイプキーを作成しました', 'Shape layer driver linked': 'シェイプレイヤーのドライバーを接続しました',
    'Curve sweep tube created': 'カーブスイープのチューブを作成しました', 'ziRail-style cutter guide created': 'ziRail 風のカッターガイドを作成しました',
    'DLA-style procedural growth stack added': '成長風のプロシージャルスタックを追加しました', 'Photo/reference handoff board created': '写真・参照の受け渡しボードを作成しました',
    'Exchange export completed with USD preference': 'USD を優先して受け渡しの書き出しを行いました', 'Common issue repair operator completed': '共通の修正を実行しました',
    'Snapshot saved': 'スナップショットを保存しました', 'Forced recovery backup created': '回復バックアップを作成しました', 'Active mesh analysis completed': '対象メッシュの解析を実行しました',
    'Diagnostic report exported to internal text': '診断レポートをテキストブロックへ書き出しました', 'Mesh validate: changed data': 'メッシュの検証: データを直しました',
    'Mesh validate: no structural change reported': 'メッシュの検証: 構造の変更なし',
}
_REPORT_STEP_PATTERNS = (
    (r'Mesh-adaptive precision scale: score=(.*), density=(.*), strength=(.*), target_faces=(.*)', r'メッシュに合わせて調整: スコア \1、密度 \2、強さ \3、目標面数 \4'),
    (r'BMesh precision cleanup: loose=(\d+), degenerate_edges=(\d+), merged=(\d+), verts (.*), edges (.*)', r'BMesh の精密な整理: 孤立頂点 \1、縮退辺 \2、結合 \3、頂点 \4、辺 \5'),
    (r'Precision semantic face attribute written: (.*) \((\d+) faces\)', r'意味別フェース属性を書き込みました: \1（\2 面）'),
    (r'Curvature/mass proxy vertex groups created: (\d+) vertices', r'曲率・質量の代理頂点グループを作成しました: \1 頂点'),
    (r'Topology quality/risk vertex groups created: (\d+) vertices', r'トポロジー品質・リスクの頂点グループを作成しました: \1 頂点'),
    (r'Apex intelligence vertex groups created: (\d+) vertices', r'最上位知能の頂点グループを作成しました: \1 頂点'),
    (r'Cloth pin gradient group created: (.*) \((\d+) vertices\)', r'クロスのピン留めグラデーションのグループを作成しました: \1（\2 頂点）'),
    (r'Surface guide curves created: (.*)', r'表面ガイドカーブを作成しました: \1'),
    (r'Preflight warnings: (.*)', r'事前検査の警告: \1'),
    (r'Precision bevel added: width=(.*)', r'精密ベベルを追加しました: 幅 \1'),
    (r'Symmetry pose guard groups created on (\w+) axis: (\d+) vertices sampled', r'\1 軸の対称・ポーズ保護グループを作成しました: \2 頂点'),
    (r'Sculpt layer stack shape keys created: (.*)', r'スカルプトレイヤーのシェイプキーを作成しました: \1'),
    (r'Smart precision route: (.*) -> (.*)', r'スマート精度の経路: \1 → \2'),
    (r'Apex Autopilot route selected: (.*) \(score=(\d+), faces=(\d+), quad_ratio=(.*), uv_layers=(\d+)\)', r'自動最適パスの経路: \1（スコア \2、面 \3、四角面の割合 \4、UV \5）'),
    (r'Tool availability checked: (.*)', r'ツールを確認しました: \1'),
    (r'Conservative cleanup noted but not applied because non-destructive preference is enabled \(score=(\d+)\)', r'非破壊の設定のため、保守的な整理は行いませんでした（スコア \1）'),
    (r'face grouping: (.*)', r'フェイスセットの分割: \1'),
    (r'procedural stack added: (.*)', r'プロシージャルスタックを追加しました: \1'),
    (r'retopo helper generated with target_faces=(.*)', r'リトポ補助を作成しました: 目標面数 \1'),
    (r'environment/detail growth guides created: (.*)', r'環境・ディテールの成長ガイドを作成しました: \1'),
    (r'Adaptive semantic grouping: (.*)', r'適応の意味別グループ: \1'),
    (r'Adaptive procedural stack added: (.*)', r'適応のプロシージャルスタックを追加しました: \1'),
    (r'Retopology helper generated with target_faces=(.*)', r'リトポ補助を作成しました: 目標面数 \1'),
    (r'Surface Detail Synth preset added: (.*)', r'表面ディテール合成のプリセットを追加しました: \1'),
    (r'Corrective layer modifiers added: (.*)', r'補正レイヤーのモディファイアを追加しました: \1'),
    (r'Pose guard anchor bend helper created on (\w+) axis', r'\1 軸のポーズ保護アンカーベンド補助を作成しました'),
    (r'Sculpt session created from (\d+) selected mesh objects', r'選択した \1 個のメッシュからスカルプトセッションを作成しました'),
    (r'Multi-object sculpt preparation used for (\d+) selected mesh objects', r'選択した \1 個のメッシュで複数オブジェクトの準備を行いました'),
    (r'Face Set action: (.*)', r'フェイスセットの操作: \1'),
    (r'Anchor bend setup created on axis (.*)', r'\1 軸のアンカーベンドを作成しました'),
    (r'Retopo setup created with target faces (.*)', r'リトポの準備を作成しました: 目標面数 \1'),
    (r'Cloth approximation modifiers added: (.*)', r'クロス近似のモディファイアを追加しました: \1'),
    (r'Corrective helper modifiers added: (.*)', r'補正用のモディファイアを追加しました: \1'),
    (r'Procedural stack added: (.*)', r'プロシージャルスタックを追加しました: \1'),
    (r'Selected detail scatter generated from (\d+) source object\(s\)', r'\1 個の元オブジェクトから選択物の散布を作成しました'),
    (r'Environment growth curves created: (.*)', r'環境の成長カーブを作成しました: \1'),
    (r'(.+) completed', r'\1を実行しました'),
)


def _report_id_label(token: object) -> str:
    """Show an internal action / preset id by the name the panel uses."""
    value = str(token or '').strip()
    extra = {'RANDOMIZE': ('Randomize Colors', '色のランダム化')}
    if value in extra:
        return _smart_utils.ui_text(*extra[value])
    for list_name in ('SMART_ACTION_ITEMS', 'SMART_QUALITY_ITEMS', 'PROCEDURAL_PRESET_ITEMS', 'COMPACT_FACE_SET_ACTION_ITEMS', 'QUICK_TOOL_ITEMS'):
        for item in getattr(properties, list_name, ()) or ():
            try:
                if str(item[0]) == value:
                    return str(bpy.app.translations.pgettext_iface(str(item[1])))
            except Exception:
                continue
    return value.replace('_', ' ').title()


def _report_step_text(step: object) -> str:
    """Return one step-log line in the active interface language."""
    text = str(step or '')
    if not utils.locale_is_japanese():
        return text
    prefix = ''
    for english, japanese in _REPORT_STEP_PREFIXES:
        if text.startswith(english):
            prefix = japanese
            text = text[len(english):]
            break
    if text in _REPORT_STEP_EXACT:
        return prefix + _REPORT_STEP_EXACT[text]
    match = re.fullmatch(r'(.+?) skipped/failed(?: \((.+)\))?: (.*)', text, re.S)
    if match:
        part, detail, reason = match.groups()
        name = _REPORT_STEP_PARTS.get(part, part)
        if detail:
            name = f'{name}（{detail}）'
        return f'{prefix}{name}を省略しました: {reason}'
    for pattern, replacement in _REPORT_STEP_PATTERNS:
        match = re.fullmatch(pattern, text, re.S)
        if match:
            result = match.expand(replacement)
            for english, japanese in _REPORT_STEP_PARTS.items():
                if result.startswith(english + 'を'):
                    result = japanese + result[len(english):]
                    break
            return prefix + result
    return prefix + text


def _report_stat_lines(stats: dict[str, Any]) -> list[str]:
    lines = []
    for key, value in sorted(stats.items()):
        english, japanese = _REPORT_STAT_LABELS.get(key, (key.replace('_', ' ').capitalize(), key.replace('_', ' ').capitalize()))
        lines.append(f"  {_smart_utils.ui_text(english, japanese)}: {value}")
    return lines


def _write_smart_report(context, *, action: str, settings, quality: dict[str, Any], obj, before: dict[str, Any], after: dict[str, Any], steps: list[str], generated: list[str]) -> None:
    if settings is not None and not bool(getattr(settings, 'smart_upgrade_write_report', True)):
        return
    notes_before = _mesh_risk_notes(before)
    notes_after = _mesh_risk_notes(after)
    lines = [
        _smart_utils.ui_text("Smart Sculpt Supreme Precision Report", "スマートスカルプト精度レポート"),
        f"{_smart_utils.ui_text('Timestamp', '日時')}: {datetime.now().isoformat(timespec='seconds')}",
        f"{_smart_utils.ui_text('Action', '操作')}: {_report_id_label(action)}",
        f"{_smart_utils.ui_text('Quality', '品質')}: {_report_id_label(quality.get('name', 'HIGH'))}",
        f"{_smart_utils.ui_text('Active Object', '対象オブジェクト')}: {getattr(obj, 'name', '') if obj is not None else _smart_utils.ui_text('(none)', '（なし）')}",
        "",
        _smart_utils.ui_text("Before:", "処理前:"),
    ]
    if before:
        lines.extend(_report_stat_lines(before))
        if notes_before:
            lines.append("  " + _smart_utils.ui_text("Risks", "リスク") + ": " + _smart_utils.ui_text("; ", "、").join(notes_before))
    else:
        lines.append("  " + _smart_utils.ui_text("no active mesh statistics", "対象メッシュの情報なし"))
    lines.extend(["", _smart_utils.ui_text("After:", "処理後:")])
    if after:
        lines.extend(_report_stat_lines(after))
        if notes_after:
            lines.append("  " + _smart_utils.ui_text("Risks", "リスク") + ": " + _smart_utils.ui_text("; ", "、").join(notes_after))
    else:
        lines.append("  " + _smart_utils.ui_text("no active mesh statistics", "対象メッシュの情報なし"))
    lines.extend(["", _smart_utils.ui_text("Steps:", "処理の記録:")])
    if steps:
        lines.extend(f"  - {_report_step_text(step)}" for step in steps)
    else:
        lines.append("  - " + _smart_utils.ui_text("no step log", "記録なし"))
    lines.extend(["", _smart_utils.ui_text("Generated Objects:", "作成された物:")])
    if generated:
        lines.extend(f"  - {name}" for name in generated)
    else:
        lines.append("  - " + _smart_utils.ui_text("none detected", "なし"))
    score_before = int(before.get('precision_score', 0) or 0) if before else 0
    score_after = int(after.get('precision_score', 0) or 0) if after else 0
    score_delta = score_after - score_before
    t = _smart_utils.ui_text
    guidance = [
        t("Precision guidance:", "精度の目安:"),
        f"  - {t('Precision score', '精度スコア')}: {score_before} -> {score_after} ({t('change', '変化')} {score_delta:+d})",
    ]
    if after and score_after < 70:
        guidance.append("  - " + t("Run Mesh Doctor Pro or Mesh Cleaner Pro before high-density remesh or baking.", "高密度のリメッシュやベイクの前に、メッシュ診断プロかメッシュクリーナープロを実行します。"))
    if after and float(after.get('quad_ratio', 1.0) or 0.0) < 0.45:
        guidance.append("  - " + t("Use Wrap Retopo + UV before rigging, animation, or displacement baking.", "リギング、アニメーション、ディスプレイスのベイクの前に、ラップリトポ + UV を使います。"))
    if after and int(after.get('uv_layers', 0) or 0) <= 0:
        guidance.append("  - " + t("Run Auto UV or Wrap Retopo + UV before texture baking.", "テクスチャのベイクの前に、自動 UV かラップリトポ + UV を実行します。"))
    if after and int(after.get('shape_keys', 0) or 0) <= 1:
        guidance.append("  - " + t("Use Sculpt Layer Stack Pro for non-destructive detail variants.", "ディテールの違いを非破壊で試すには、スカルプトレイヤースタックプロを使います。"))
    lines.extend([""] + guidance)
    lines.extend([
        "",
        t("Recommended next checks:", "次に確かめること:"),
        "  - " + t("Inspect the modifier stack before applying destructive changes.", "破壊的な変更を適用する前に、モディファイアの並びを確かめます。"),
        "  - " + t("Use Safe > Snapshot or Recovery before remesh, boolean apply, UV rewrite, or mesh cleanup.", "リメッシュ、ブーリアンの適用、UV の書き換え、メッシュの整理の前に、スナップショットか回復バックアップを取ります。"),
        "  - " + t("If non-manifold/boundary edges are intentional, treat the report as a warning rather than an error.", "非多様体辺や境界辺が意図どおりなら、この内容はエラーではなく注意として扱います。"),
    ])
    try:
        utils.write_text_block(REPORT_TEXT_NAME, "\n".join(lines) + "\n")
    except Exception:
        try:
            text = bpy.data.texts.get(REPORT_TEXT_NAME) or bpy.data.texts.new(REPORT_TEXT_NAME)
            text.clear()
            text.write("\n".join(lines) + "\n")
        except Exception:
            pass


def _set_if_present(target, name: str, value: Any) -> None:
    try:
        if target is not None and hasattr(target, name):
            setattr(target, name, value)
    except Exception:
        pass


def _run_preflight_if_enabled(context, obj, settings, steps: list[str]) -> dict[str, Any]:
    before = _mesh_stats(obj) if obj is not None else {}
    if obj is None or settings is None or not bool(getattr(settings, 'smart_upgrade_auto_preflight', True)):
        return before
    try:
        utils.ensure_object_mode(context, obj)
    except Exception:
        pass
    _safe_validate_mesh(obj, steps)
    try:
        obj['sss_smart_preflight'] = datetime.now().isoformat(timespec='seconds')
    except Exception:
        pass
    notes = _mesh_risk_notes(before)
    if notes:
        steps.append('Preflight warnings: ' + '; '.join(notes))
    else:
        steps.append('Preflight warnings: none')
    return before


def _apply_precision_polish(obj, quality: dict[str, Any], steps: list[str], *, bevel_width: float = 0.0) -> None:
    if bevel_width > 0 and _add_precision_bevel(obj, width=bevel_width, segments=int(quality.get('bevel_segments', 2))):
        steps.append(f"Precision bevel added: width={bevel_width:.6f}")
    if _add_weighted_normal(obj, weight=int(quality.get('normal_weight', 50))):
        steps.append('Precision weighted normal added')


def _create_symmetry_pose_groups(obj, axis: str, steps: list[str]) -> int:
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return 0
    axis = str(axis or 'X').upper()
    axis_index = {'X': 0, 'Y': 1, 'Z': 2}.get(axis, 0)
    try:
        coords = [obj.matrix_world @ vertex.co for vertex in mesh.vertices]
    except Exception:
        coords = [getattr(vertex, 'co', Vector((0.0, 0.0, 0.0))) for vertex in getattr(mesh, 'vertices', [])]
    if not coords:
        return 0
    values = [float(co[axis_index]) for co in coords]
    center = (min(values) + max(values)) * 0.5
    span = max(max(values) - min(values), 1e-6)
    try:
        left = obj.vertex_groups.new(name=utils.unique_name(f"SSS_{axis}_NegativePoseGuard"))
        right = obj.vertex_groups.new(name=utils.unique_name(f"SSS_{axis}_PositivePoseGuard"))
        center_group = obj.vertex_groups.new(name=utils.unique_name(f"SSS_{axis}_CenterSymmetryGuard"))
    except Exception:
        return 0
    assigned = 0
    for vertex, value in zip(getattr(mesh, 'vertices', []), values):
        distance = (value - center) / span
        center_weight = max(0.0, 1.0 - abs(distance) * 4.0)
        try:
            if value < center:
                left.add([vertex.index], min(1.0, max(0.05, abs(distance) * 2.0)), 'REPLACE')
            elif value > center:
                right.add([vertex.index], min(1.0, max(0.05, abs(distance) * 2.0)), 'REPLACE')
            if center_weight > 0.0:
                center_group.add([vertex.index], center_weight, 'REPLACE')
            assigned += 1
        except Exception:
            pass
    try:
        obj['sss_symmetry_pose_guard_axis'] = axis
        obj['sss_symmetry_pose_guard_center'] = center
    except Exception:
        pass
    if assigned:
        steps.append(f"Symmetry pose guard groups created on {axis} axis: {assigned} vertices sampled")
    return assigned


def _ensure_sculpt_layer_stack(obj, steps: list[str], *, label: str = 'SSS_SculptLayerStack') -> int:
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    created = 0
    try:
        if getattr(obj.data, 'shape_keys', None) is None:
            obj.shape_key_add(name='Basis', from_mix=False)
        for suffix in ('Primary', 'Secondary', 'PoseCorrective'):
            obj.shape_key_add(name=utils.unique_name(f"{label}_{suffix}"), from_mix=False)
            created += 1
    except Exception:
        pass
    try:
        obj['sss_sculpt_layer_stack'] = datetime.now().isoformat(timespec='seconds')
    except Exception:
        pass
    if created:
        steps.append(f"Sculpt layer stack shape keys created: {created}")
    return created


def _set_precision_metadata(obj, action: str, quality: dict[str, Any], stats: dict[str, Any]) -> None:
    if obj is None:
        return
    try:
        obj['sss_smart_supreme_action'] = str(action)
        obj['sss_smart_supreme_quality'] = str(quality.get('name', 'HIGH'))
        obj['sss_smart_supreme_faces_before'] = int(stats.get('faces', 0) or 0)
        obj['sss_smart_supreme_report'] = REPORT_TEXT_NAME
    except Exception:
        pass


class SSS_OT_run_smart_upgrade_tool(Operator):
    bl_idname = "smart_sculpt.run_smart_upgrade_tool"
    bl_label = "Run Smart Upgrade Tool"
    bl_description = _smart_utils.localize_bilingual_text((
        'Run a Blender-native upper-compatible Smart Sculpt Supreme tool mapped from the attached sculpt-support list. The tools do not copy third-party code; they recreate comparable or safer workflows with Blender operators, modifiers, Face Sets, Shape Keys, exchange files, generated helpers, and internal precision reports. / 添付スカルプト支援機能リストからBlenderネイティブの上位互換系スマートスカルプト最上位ツールを実行します。サードパーティコードは複製せず、Blenderのオペレーター、モディファイア、フェイスセット、シェイプキー、受け渡しファイル、生成ヘルパー、内部精度レポートで近い、または安全寄りのワークフローを再構築します。'
    ))
    bl_options = {'UNDO'}

    action: EnumProperty(
        name="Action",
        description=_smart_utils.localize_bilingual_text("Upper-compatible Smart helper to run / 実行する上位互換系スマート補助です"),
        items=properties.SMART_ACTION_ITEMS,
        default='QUICK_POLYGROUP_PLUS',
    )
    strength: FloatProperty(
        name="Strength",
        description=_smart_utils.localize_bilingual_text("Override strength used by this run. Set to 0 to let the N-panel value be used. / この実行で使う強度の上書き値です。0の場合はNパネル値を使います"),
        default=0.0,
        min=0.0,
        max=5.0,
    )
    density: FloatProperty(
        name="Density",
        description=_smart_utils.localize_bilingual_text("Override density used by this run. Set to 0 to let the N-panel value be used. / この実行で使う密度の上書き値です。0の場合はNパネル値を使います"),
        default=0.0,
        min=0.0,
        soft_max=10.0,
    )
    count: IntProperty(
        name="Count",
        description=_smart_utils.localize_bilingual_text("Override count used by generated helper tools. Set to 0 to use the N-panel value. / 生成ヘルパー系で使う個数の上書き値です。0の場合はNパネル値を使います"),
        default=0,
        min=0,
        max=5000,
    )
    segments: IntProperty(
        name="Segments",
        description=_smart_utils.localize_bilingual_text("Override segment count for curve-like helpers. Set to 0 to use the N-panel value. / カーブ系ヘルパーの分割数上書き値です。0の場合はNパネル値を使います"),
        default=0,
        min=0,
        max=256,
    )
    use_voxel: BoolProperty(
        name="Use Voxel Step",
        description=_smart_utils.localize_bilingual_text("Use the voxel-style step for actions that support it / 対応アクションでボクセル風ステップを使います"),
        default=True,
    )
    use_multires: BoolProperty(
        name="Use Multires Step",
        description=_smart_utils.localize_bilingual_text("Use the Multires step for actions that support it / 対応アクションでマルチレゾステップを使います"),
        default=True,
    )

    def _runtime_values(self, context):
        settings = _settings(context)
        quality = _quality_profile(settings)
        strength = _clamp_float(self.strength or getattr(settings, 'smart_upgrade_strength', 0.08) or 0.08, 0.0, 5.0, 0.08)
        density = _clamp_float(self.density or getattr(settings, 'smart_upgrade_density', 0.08) or 0.08, 0.001, 10.0, 0.08)
        base_count = int(self.count or getattr(settings, 'smart_upgrade_count', 12) or 12)
        base_segments = int(self.segments or getattr(settings, 'smart_upgrade_segments', 8) or 8)
        count = _clamp_int(base_count * float(quality.get('count_mul', 1.0)), 1, 5000, base_count)
        segments = _clamp_int(base_segments * float(quality.get('segment_mul', 1.0)), 2, 256, base_segments)
        use_voxel = bool(self.use_voxel and getattr(settings, 'smart_upgrade_use_voxel', True))
        use_multires = bool(self.use_multires and getattr(settings, 'smart_upgrade_use_multires', True))
        target_faces = _clamp_int(
            float(getattr(settings, 'smart_upgrade_target_faces', 12000) or 12000) * float(quality.get('target_face_mul', 1.0)),
            100,
            2000000,
            12000,
        )
        non_destructive = bool(getattr(settings, 'smart_upgrade_non_destructive', True) if settings is not None else True)
        return settings, quality, strength, density, count, segments, use_voxel, use_multires, target_faces, non_destructive

    def _apply_profile_and_view(self, context, profile='BLOCKOUT', viewport='CLAY'):
        try:
            _call_smart_operator('prepare_workspace')
        except Exception:
            pass
        try:
            _call_smart_operator('apply_profile', [{'profile': profile}, {}])
        except Exception:
            pass
        try:
            _call_smart_operator('set_viewport_preset', [{'preset': viewport}, {}])
        except Exception:
            pass

    def _finish(self, context, *, action: str, settings, quality: dict[str, Any], obj, before: dict[str, Any], steps: list[str], generated_before: set[str], report_level='INFO', message='Smart upgrade action finished.'):
        active = utils.active_mesh_object(context) or obj
        original_mode = str(getattr(self, '_smart_original_mode', '') or '')
        if original_mode in {'EDIT', 'EDIT_MESH'} and active is not None:
            utils.restore_mode_after_smart_operation(context, active, 'EDIT')
        after = _mesh_stats(active) if active is not None else {}
        try:
            from . import ui as _ui_runtime
            _ui_runtime.cache_ui_mesh_stats(active, after)
        except Exception:
            pass
        generated = _generated_since(generated_before)
        _write_smart_report(context, action=action, settings=settings, quality=quality, obj=active, before=before, after=after, steps=steps, generated=generated)
        self.report({report_level}, message)
        return {'FINISHED'}

    def execute(self, context):
        settings, quality, strength, density, count, segments, use_voxel, use_multires, target_faces, non_destructive = self._runtime_values(context)
        action = str(self.action or getattr(settings, 'smart_upgrade_action', 'QUICK_POLYGROUP_PLUS') or 'QUICK_POLYGROUP_PLUS')
        requested_action = action
        no_active_required = {'APEX_AUTOPILOT_PASS', 'SCULPT_TRANSFER_PROFILE', 'BSPHERE_ARMATURE_BLOCKOUT', 'PHOTO_REFERENCE_HANDOFF'}
        obj = utils.active_mesh_object(context) if action in no_active_required else _active_mesh_or_cancel(self, context)
        self._smart_original_mode = getattr(obj, 'mode', 'OBJECT') if obj is not None else str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        steps: list[str] = []
        if requested_action != action:
            steps.append(f"Smart precision route: {_report_id_label(requested_action)} -> {_report_id_label(action)}")
        generated_before = _object_names()
        before = _run_preflight_if_enabled(context, obj, settings, steps) if obj is not None else {}
        if action == 'APEX_AUTOPILOT_PASS':
            stats_for_route = before or (_mesh_stats(obj) if obj is not None else {})
            selected_route = recommend_smart_action(stats_for_route, obj, settings)
            steps.append(
                f"Apex Autopilot route selected: {_report_id_label(selected_route)} "
                f"(score={int(stats_for_route.get('precision_score', 0) or 0)}, "
                f"faces={int(stats_for_route.get('faces', 0) or 0)}, "
                f"quad_ratio={float(stats_for_route.get('quad_ratio', 0.0) or 0.0):.4f}, "
                f"uv_layers={int(stats_for_route.get('uv_layers', 0) or 0)})"
            )
            try:
                if obj is not None:
                    obj['sss_apex_autopilot_route'] = selected_route
                    obj['sss_apex_autopilot_score'] = int(stats_for_route.get('precision_score', 0) or 0)
            except Exception:
                pass
            action = selected_route
        if obj is not None and bool(getattr(settings, 'smart_upgrade_adaptive_scale', True) if settings is not None else True):
            strength, density, count, segments, target_faces = _adapt_runtime_to_mesh(before or _mesh_stats(obj), quality, strength, density, count, segments, target_faces, steps)

        try:
            if action == 'SCULPT_TRANSFER_PROFILE':
                self._apply_profile_and_view(context, 'BLOCKOUT', 'CLAY')
                for tool_id in ('CLAY_STRIPS', 'GRAB', 'CREASE'):
                    try:
                        _call_smart_operator('set_sculpt_tool', [{'tool': tool_id}, {}])
                        steps.append(f"Tool availability checked: {_report_id_label(tool_id)}")
                    except Exception:
                        pass
                try:
                    _call_smart_operator('store_active_brush_slot', [{'slot': 1}, {}])
                    steps.append('Active brush stored to Tool Pipe slot 1')
                except Exception:
                    pass
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Sculpt transfer profile prepared. / スカルプト移行プロファイルを準備しました。"))

            if action == 'BSPHERE_ARMATURE_BLOCKOUT':
                if obj is not None:
                    utils.ensure_object_mode(context, obj)
                try:
                    _call_smart_operator('add_sphere_chain', [{
                        'count': max(2, min(count, 64)),
                        'radius': max(density * 1.2, 0.01),
                        'spacing': max(density * 2.2, 0.02),
                        'taper': 0.38,
                        'convert_to_mesh': not non_destructive,
                    }, {}])
                    steps.append('BSphere/ZSphere-style sphere chain generated')
                except Exception as exc:
                    raise RuntimeError(f"sphere chain generation failed: {exc}")
                active = utils.active_mesh_object(context)
                _apply_precision_polish(active, quality, steps, bevel_width=0.0)
                return self._finish(context, action=action, settings=settings, quality=quality, obj=active or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("BSphere Armature Blockout generated. / 球体アーマチュア下地作りを生成しました。"))

            if obj is None and action != 'PHOTO_REFERENCE_HANDOFF':
                return {'CANCELLED'}

            if action in {
                'SUPREME_STUDIO_PIPELINE', 'PRECISION_FRONTIER_PASS', 'ADAPTIVE_MASTER_PASS', 'MESH_DOCTOR_PRO', 'SURFACE_DETAIL_SYNTH', 'SCULPT_LAYER_STACK_PRO',
                'SYMMETRY_POSE_GUARD', 'MULTI_OBJECT_HARMONIZER', 'SPEED_BLOCKOUT', 'ANCHOR_BEND_PRO',
                'VOXEL_HYBRID_SURFACE', 'HARD_SURFACE_CUTKIT', 'WRAP_RETOPO_UV', 'VELLUM_CLOTH_DRAPE',
                'MUSCLE_LAYER_DRIVER', 'PROCEDURAL_MICRODETAIL_BRUSH', 'MESH_CLEANER_PRO', 'FULL_SAFE_SETUP'
            }:
                _snapshot_if_enabled(context, obj, action.lower())
                steps.append('Safety snapshot/recovery backup requested')

            if action == 'SUPREME_STUDIO_PIPELINE':
                stats = before or _mesh_stats(obj)
                _set_precision_metadata(obj, action, quality, stats)
                utils.ensure_object_mode(context, obj)
                _safe_validate_mesh(obj, steps)
                self._apply_profile_and_view(context, 'DETAIL', 'TECHNICAL')
                steps.append('Supreme Studio profile/view prepared')
                _create_precision_face_attributes(obj, steps, label='SSS_StudioSemanticZone')
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                _create_curvature_proxy_groups(obj, steps)
                _create_symmetry_pose_groups(obj, str(getattr(settings, 'smart_upgrade_axis', 'Y') if settings is not None else 'Y'), steps)
                score = int(stats.get('precision_score', 100) or 100)
                if score < 84:
                    if non_destructive:
                        steps.append(f'Conservative cleanup noted but not applied because non-destructive preference is enabled (score={score})')
                    else:
                        _bmesh_precision_cleanup(obj, steps, merge_distance=max(_recommended_detail_scale(stats, density) * 0.016, 1e-7))
                        stats = _mesh_stats(obj)
                try:
                    _set_if_present(settings, 'quad_target_faces', target_faces)
                    _set_if_present(settings, 'voxel_size', max(density, 0.001))
                    _set_if_present(settings, 'procedural_strength', max(strength, 0.01))
                    _set_if_present(settings, 'procedural_scale', max(density * 8.5, 0.01))
                except Exception:
                    pass
                for call_name, label in (
                    ('configure_dyntopo', 'Dyntopo readiness'),
                    ('create_shape_layer', 'Shape layer checkpoint'),
                    ('analyze_active_mesh', 'Analysis refresh'),
                ):
                    try:
                        _call_smart_operator(call_name)
                        steps.append(f'Supreme Studio {label} completed')
                    except Exception as exc:
                        steps.append(f'Supreme Studio {label} skipped/failed: {_smart_utils.exception_ui_text(exc)}')
                for face_action in ('QUICK_POLYGROUP', 'RANDOMIZE'):
                    try:
                        _call_smart_operator('face_set_action', [{'action': face_action}, {}])
                        steps.append(f'Supreme Studio face grouping: {_report_id_label(face_action)}')
                    except Exception as exc:
                        steps.append(f'Supreme Studio face grouping skipped/failed ({_report_id_label(face_action)}): {_smart_utils.exception_ui_text(exc)}')
                if use_multires:
                    try:
                        _call_smart_operator('multires_action', [{'action': 'ADD'}, {}])
                        steps.append('Supreme Studio Multires staging requested')
                    except Exception as exc:
                        steps.append(f'Supreme Studio Multires skipped/failed: {_smart_utils.exception_ui_text(exc)}')
                for preset in ('HYBRID_SURFACE', 'MICRO_BREAKUP', 'SURFACE_NOISE', 'WRINKLE', 'DLA_GROWTH'):
                    try:
                        _call_smart_operator('add_procedural_stack', [{'preset': preset}, {}])
                        steps.append(f'Supreme Studio procedural stack added: {_report_id_label(preset)}')
                    except Exception as exc:
                        steps.append(f'Supreme Studio procedural stack skipped/failed ({_report_id_label(preset)}): {_smart_utils.exception_ui_text(exc)}')
                try:
                    _call_smart_operator('create_retopo_setup', [{'use_quadriflow': False, 'enter_edit_mode': False}, {'use_quadriflow': False}, {}])
                    steps.append(f'Supreme Studio retopo helper generated with target_faces={target_faces}')
                except Exception as exc:
                    steps.append(f'Supreme Studio retopo helper skipped/failed: {_smart_utils.exception_ui_text(exc)}')
                _create_surface_guide_curves(context, obj, steps, count=max(4, min(count, 24)), segments=max(segments, 12), density=density, quality=quality, kind='supreme_studio_surface_guides')
                if str(quality.get('name', '')).upper() in {'HIGH', 'ULTRA', 'FRONTIER'}:
                    created_growth = _create_environment_growth(context, obj, count=max(2, min(count // 2 if count > 3 else count, 16)), segments=max(segments, 8), radius=density, strength=strength, quality=quality)
                    steps.append(f'Supreme Studio environment/detail growth guides created: {created_growth}')
                _ensure_sculpt_layer_stack(obj, steps, label='SSS_SupremeStudioLayer')
                _apply_precision_polish(obj, quality, steps, bevel_width=max(density * 0.01, 0.0001))
                try:
                    obj['sss_smart_ui_icons'] = 'Large borderless custom icon board enabled'
                    obj['sss_smart_reference_board'] = icon_assets.reference_image_path()
                except Exception:
                    pass
                return self._finish(context, action=action, settings=settings, quality=quality, obj=utils.active_mesh_object(context) or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Supreme Studio Pipeline finished. / 最上位スタジオ処理が完了しました。"))

            if action == 'PRECISION_FRONTIER_PASS':
                stats = before or _mesh_stats(obj)
                _set_precision_metadata(obj, action, quality, stats)
                utils.ensure_object_mode(context, obj)
                _safe_validate_mesh(obj, steps)
                self._apply_profile_and_view(context, 'DETAIL', 'TECHNICAL')
                steps.append('Precision Frontier profile/view prepared')
                _create_precision_face_attributes(obj, steps, label='SSS_FrontierSemanticZone')
                _create_curvature_proxy_groups(obj, steps)
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                _create_symmetry_pose_groups(obj, str(getattr(settings, 'smart_upgrade_axis', 'Y') if settings is not None else 'Y'), steps)
                if not non_destructive and int(stats.get('precision_score', 100) or 100) < 78:
                    _bmesh_precision_cleanup(obj, steps, merge_distance=max(_recommended_detail_scale(stats, density) * 0.018, 1e-7))
                else:
                    steps.append('Destructive BMesh cleanup skipped by non-destructive preference or sufficient precision score')
                try:
                    _set_if_present(settings, 'quad_target_faces', target_faces)
                    _set_if_present(settings, 'voxel_size', max(density, 0.001))
                    _set_if_present(settings, 'procedural_strength', max(strength, 0.012))
                    _set_if_present(settings, 'procedural_scale', max(density * 7.5, 0.01))
                except Exception:
                    pass
                for call_name, label in (('configure_dyntopo', 'Dyntopo readiness'), ('create_shape_layer', 'Shape layer checkpoint')):
                    try:
                        _call_smart_operator(call_name)
                        steps.append(f'Precision Frontier {label} completed')
                    except Exception as exc:
                        steps.append(f'Precision Frontier {label} skipped/failed: {_smart_utils.exception_ui_text(exc)}')
                for face_action in ('QUICK_POLYGROUP', 'RANDOMIZE'):
                    try:
                        _call_smart_operator('face_set_action', [{'action': face_action}, {}])
                        steps.append(f'Precision Frontier face grouping: {_report_id_label(face_action)}')
                    except Exception as exc:
                        steps.append(f'Precision Frontier face grouping skipped/failed ({_report_id_label(face_action)}): {_smart_utils.exception_ui_text(exc)}')
                if use_multires:
                    try:
                        _call_smart_operator('multires_action', [{'action': 'ADD'}, {}])
                        steps.append('Precision Frontier Multires staging requested')
                    except Exception as exc:
                        steps.append(f'Precision Frontier Multires skipped/failed: {_smart_utils.exception_ui_text(exc)}')
                for preset in ('HYBRID_SURFACE', 'MICRO_BREAKUP', 'WRINKLE', 'DLA_GROWTH'):
                    try:
                        _call_smart_operator('add_procedural_stack', [{'preset': preset}, {}])
                        steps.append(f'Precision Frontier procedural stack added: {_report_id_label(preset)}')
                    except Exception as exc:
                        steps.append(f'Precision Frontier procedural stack skipped/failed ({_report_id_label(preset)}): {_smart_utils.exception_ui_text(exc)}')
                try:
                    _call_smart_operator('create_retopo_setup', [{'use_quadriflow': False, 'enter_edit_mode': False}, {'use_quadriflow': False}, {}])
                    steps.append(f'Precision Frontier retopo helper generated with target_faces={target_faces}')
                except Exception as exc:
                    steps.append(f'Precision Frontier retopo helper skipped/failed: {_smart_utils.exception_ui_text(exc)}')
                _create_surface_guide_curves(context, obj, steps, count=max(3, min(count, 18)), segments=max(segments, 10), density=density, quality=quality, kind='frontier_surface_guides')
                _apply_precision_polish(obj, quality, steps, bevel_width=max(density * 0.012, 0.0001))
                return self._finish(context, action=action, settings=settings, quality=quality, obj=utils.active_mesh_object(context) or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Precision Frontier Pass finished. / 高精度仕上げパスが完了しました。"))

            if action == 'ADAPTIVE_MASTER_PASS':
                stats = before or _mesh_stats(obj)
                _set_precision_metadata(obj, action, quality, stats)
                _safe_validate_mesh(obj, steps)
                self._apply_profile_and_view(context, 'BLOCKOUT', 'TECHNICAL')
                steps.append('Adaptive master profile/view prepared')
                _create_precision_face_attributes(obj, steps)
                _create_curvature_proxy_groups(obj, steps)
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                if int(stats.get('precision_score', 100) or 100) < 62 and not non_destructive:
                    _bmesh_precision_cleanup(obj, steps, merge_distance=max(_recommended_detail_scale(stats, density) * 0.025, 1e-7))
                try:
                    _set_if_present(settings, 'quad_target_faces', target_faces)
                    _set_if_present(settings, 'voxel_size', max(density, 0.001))
                    _set_if_present(settings, 'procedural_strength', max(strength, 0.015))
                    _set_if_present(settings, 'procedural_scale', max(density * 6.0, 0.01))
                except Exception:
                    pass
                try:
                    _call_smart_operator('configure_dyntopo')
                    steps.append('Dyntopo readiness configured from N-panel settings')
                except Exception:
                    pass
                _create_precision_face_attributes(obj, steps, label='SSS_QuickPolygroupZone')
                for face_action in ('QUICK_POLYGROUP', 'RANDOMIZE'):
                    try:
                        _call_smart_operator('face_set_action', [{'action': face_action}, {}])
                        steps.append(f'Adaptive semantic grouping: {_report_id_label(face_action)}')
                    except Exception:
                        pass
                if non_destructive:
                    try:
                        _call_smart_operator('create_shape_layer')
                        steps.append('Non-destructive sculpt layer checkpoint created')
                    except Exception:
                        pass
                if use_multires:
                    try:
                        _call_smart_operator('multires_action', [{'action': 'ADD'}, {}])
                        steps.append('Multires staging requested')
                    except Exception:
                        pass
                for preset in ('HYBRID_SURFACE', 'MICRO_BREAKUP'):
                    try:
                        _call_smart_operator('add_procedural_stack', [{'preset': preset}, {}])
                        steps.append(f'Adaptive procedural stack added: {_report_id_label(preset)}')
                    except Exception:
                        pass
                try:
                    _call_smart_operator('create_retopo_setup', [{'use_quadriflow': False, 'enter_edit_mode': False}, {'use_quadriflow': False}, {}])
                    steps.append(f'Retopology helper generated with target_faces={target_faces}')
                except Exception:
                    pass
                _create_surface_guide_curves(context, obj, steps, count=max(2, min(count, 12)), segments=max(segments, 8), density=density, quality=quality)
                _apply_precision_polish(obj, quality, steps, bevel_width=max(density * 0.015, 0.0001))
                return self._finish(context, action=requested_action, settings=settings, quality=quality, obj=utils.active_mesh_object(context) or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Adaptive Master Pass finished. / 適応マスターパスが完了しました。"))

            if action == 'MESH_DOCTOR_PRO':
                utils.ensure_object_mode(context, obj)
                _set_precision_metadata(obj, action, quality, before or _mesh_stats(obj))
                _safe_validate_mesh(obj, steps)
                _bmesh_precision_cleanup(obj, steps, merge_distance=max(_recommended_detail_scale(before or _mesh_stats(obj), density) * 0.02, 1e-7))
                try:
                    _call_fix_common_issues_without_scale_apply(context)
                    steps.append('Common mesh issue repair operator executed')
                except Exception:
                    steps.append('Common mesh issue repair operator unavailable; validation-only pass used')
                _safe_validate_mesh(obj, steps)
                _apply_precision_polish(obj, quality, steps, bevel_width=0.0)
                try:
                    _call_smart_operator('analyze_active_mesh')
                    steps.append('Post-clean analysis refreshed')
                except Exception:
                    pass
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Mesh Doctor Pro finished. / メッシュ診断プロが完了しました。"))

            if action == 'SURFACE_DETAIL_SYNTH':
                utils.ensure_object_mode(context, obj)
                _set_precision_metadata(obj, action, quality, before or _mesh_stats(obj))
                _set_if_present(settings, 'procedural_strength', max(0.001, min(strength, 2.0)))
                _set_if_present(settings, 'procedural_scale', max(0.001, density * (8.0 + float(quality.get('report_detail', 1)) * 2.0)))
                _create_precision_face_attributes(obj, steps, label='SSS_DetailSynthZone')
                for preset in ('SURFACE_NOISE', 'MICRO_BREAKUP', 'WRINKLE', 'DLA_GROWTH'):
                    try:
                        _call_smart_operator('add_procedural_stack', [{'preset': preset}, {}])
                        steps.append(f'Surface Detail Synth preset added: {_report_id_label(preset)}')
                    except Exception:
                        pass
                _apply_precision_polish(obj, quality, steps, bevel_width=max(strength * 0.002, 0.0))
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Surface Detail Synth added. / 表面ディテール合成を追加しました。"))

            if action == 'SCULPT_LAYER_STACK_PRO':
                utils.ensure_object_mode(context, obj)
                _set_precision_metadata(obj, action, quality, before or _mesh_stats(obj))
                _ensure_sculpt_layer_stack(obj, steps, label='SSS_LayerStackPro')
                _create_curvature_proxy_groups(obj, steps)
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                try:
                    _call_smart_operator('create_shape_layer')
                    steps.append('Native Smart Sculpt shape layer operator executed')
                except Exception:
                    pass
                added = _add_corrective_layer_modifiers(obj, strength)
                if added:
                    steps.append(f'Corrective layer modifiers added: {added}')
                _apply_precision_polish(obj, quality, steps, bevel_width=0.0)
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Sculpt Layer Stack Pro created. / スカルプトレイヤー重ねプロを作成しました。"))

            if action == 'SYMMETRY_POSE_GUARD':
                utils.ensure_object_mode(context, obj)
                axis = str(getattr(settings, 'smart_upgrade_axis', 'X') if settings is not None else 'X')
                _set_precision_metadata(obj, action, quality, before or _mesh_stats(obj))
                _create_symmetry_pose_groups(obj, axis, steps)
                _create_precision_face_attributes(obj, steps, label='SSS_SymmetryPoseZone')
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                _ensure_sculpt_layer_stack(obj, steps, label='SSS_PoseGuardLayer')
                try:
                    _call_smart_operator('create_anchor_bend_setup', [{'axis': axis, 'angle': float(strength) * 0.5}, {'axis': axis}, {}])
                    steps.append(f'Pose guard anchor bend helper created on {axis} axis')
                except Exception:
                    pass
                _apply_precision_polish(obj, quality, steps, bevel_width=0.0)
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Symmetry Pose Guard prepared. / 対称ポーズ保護を準備しました。"))

            if action == 'MULTI_OBJECT_HARMONIZER':
                meshes = utils.selected_mesh_objects(context, editable_only=True)
                if len(meshes) > 1:
                    try:
                        _call_smart_operator('create_proxy_session')
                        steps.append(f"Sculpt session created from {len(meshes)} selected mesh objects")
                    except Exception:
                        _call_smart_operator('prepare_multi_object_sculpt')
                        steps.append(f"Multi-object sculpt preparation used for {len(meshes)} selected mesh objects")
                else:
                    _call_smart_operator('prepare_multi_object_sculpt')
                    steps.append('Single-object multi workflow preparation used')
                try:
                    _call_smart_operator('set_viewport_preset', [{'preset': 'FACESETS'}, {}])
                except Exception:
                    pass
                return self._finish(context, action=action, settings=settings, quality=quality, obj=utils.active_mesh_object(context) or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Multi-Object Harmonizer finished. / 複数オブジェクト調整が完了しました。"))

            if action == 'SPEED_BLOCKOUT':
                self._apply_profile_and_view(context, 'BLOCKOUT', 'CLAY')
                try:
                    _call_smart_operator('configure_dyntopo')
                    steps.append('Dyntopo configured')
                except Exception:
                    pass
                _set_if_present(settings, 'procedural_strength', max(strength, 0.01))
                _set_if_present(settings, 'procedural_scale', max(density * 8.0, 0.01))
                try:
                    _call_smart_operator('add_procedural_stack', [{'preset': 'HYBRID_SURFACE'}, {}])
                    steps.append('Hybrid surface procedural stack added')
                except Exception:
                    pass
                _apply_precision_polish(obj, quality, steps, bevel_width=max(strength * 0.01, 0.0))
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Speed Blockout Supreme applied. / 高速下地作り最上位を適用しました。"))

            if action == 'QUICK_POLYGROUP_PLUS':
                utils.ensure_object_mode(context, obj)
                _create_precision_face_attributes(obj, steps, label='SSS_QuickPolygroupZone')
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                utils.ensure_sculpt_mode(context, obj)
                for face_action in ('QUICK_POLYGROUP', 'RANDOMIZE'):
                    try:
                        _call_smart_operator('face_set_action', [{'action': face_action}, {}])
                        steps.append(f"Face Set action: {_report_id_label(face_action)}")
                    except Exception:
                        pass
                try:
                    _call_smart_operator('set_viewport_preset', [{'preset': 'FACESETS'}])
                except Exception:
                    pass
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Quick Polygroup++ finished. / クイックポリグループ++が完了しました。"))

            if action == 'ANCHOR_BEND_PRO':
                utils.ensure_object_mode(context, obj)
                axis = str(getattr(settings, 'smart_upgrade_axis', 'Y') if settings is not None else 'Y')
                _create_symmetry_pose_groups(obj, axis, steps)
                _call_smart_operator('create_anchor_bend_setup', [{'axis': axis, 'angle': float(strength)}, {'axis': axis}, {}])
                steps.append(f"Anchor bend setup created on axis {axis}")
                try:
                    _call_smart_operator('create_shape_layer')
                    steps.append('Shape layer safety created')
                except Exception:
                    pass
                _apply_precision_polish(obj, quality, steps, bevel_width=0.0)
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Anchor Bend Supreme setup created. / アンカー曲げ最上位構成を作成しました。"))

            if action == 'VOXEL_HYBRID_SURFACE':
                utils.ensure_object_mode(context, obj)
                _set_if_present(settings, 'voxel_size', max(0.001, min(float(density), 10.0)))
                _set_if_present(settings, 'procedural_strength', max(0.0, float(strength)))
                _set_if_present(settings, 'procedural_scale', max(0.001, float(density) * 10.0))
                if use_voxel:
                    try:
                        _call_smart_operator('voxel_remesh')
                        obj = utils.active_mesh_object(context) or obj
                        steps.append('Voxel remesh completed')
                    except Exception as exc:
                        steps.append(f"Voxel remesh skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                if use_multires:
                    try:
                        _call_smart_operator('multires_action', [{'action': 'ADD'}, {}])
                        steps.append('Multires step added')
                    except Exception as exc:
                        steps.append(f"Multires step skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                _create_precision_face_attributes(obj, steps, label='SSS_VoxelHybridZone')
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                _call_smart_operator('add_procedural_stack', [{'preset': 'HYBRID_SURFACE'}, {}])
                steps.append('Hybrid surface stack added')
                _apply_precision_polish(obj, quality, steps, bevel_width=max(strength * 0.01, 0.0))
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Voxel Hybrid Surface++ applied. / ボクセルハイブリッド表面++を適用しました。"))

            if action == 'HARD_SURFACE_CUTKIT':
                utils.ensure_object_mode(context, obj)
                axis = str(getattr(settings, 'smart_upgrade_axis', 'Y') if settings else 'Y')
                try:
                    _call_smart_operator('add_rail_cutter', [{
                        'axis': axis,
                        'length': max(density * segments, 0.25),
                        'width': max(density * 0.35, 0.005),
                        'depth': max(strength, 0.02),
                        'apply_to_target': True,
                        'apply_boolean': not non_destructive,
                        'remove_cutter': False,
                        'add_bevel': True,
                    }, {}])
                    steps.append('Exact boolean rail cutter created')
                except Exception as exc:
                    raise RuntimeError(f"hard-surface cutter setup failed: {exc}")
                obj = utils.active_mesh_object(context) or obj
                _create_precision_face_attributes(obj, steps, label='SSS_HardSurfaceCutZone')
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                _apply_precision_polish(obj, quality, steps, bevel_width=max(density * 0.05, 0.0005))
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Hard Surface CutKit created. / ハードサーフェスカットキットを作成しました。"))

            if action == 'WRAP_RETOPO_UV':
                utils.ensure_object_mode(context, obj)
                previous_quad_faces = getattr(settings, 'quad_target_faces', None) if settings is not None else None
                _set_if_present(settings, 'quad_target_faces', target_faces)
                try:
                    _call_smart_operator('create_retopo_setup', [{'use_quadriflow': True, 'enter_edit_mode': False}, {'enter_edit_mode': False}, {}])
                    steps.append(f"Retopo setup created with target faces {target_faces}")
                finally:
                    if previous_quad_faces is not None:
                        _set_if_present(settings, 'quad_target_faces', previous_quad_faces)
                retopo_obj = utils.active_mesh_object(context)
                if retopo_obj is not None:
                    _create_precision_face_attributes(retopo_obj, steps, label='SSS_RetopoZone')
                    _create_topology_quality_groups(retopo_obj, steps)
                    _create_surface_guide_curves(context, obj, steps, count=max(2, min(count, 8)), segments=max(segments, 8), density=density, quality=quality, kind='retopo_surface_guides')
                _apply_precision_polish(retopo_obj, quality, steps, bevel_width=0.0)
                try:
                    _call_smart_operator('auto_uv_project')
                    steps.append('Automatic UV projection completed')
                except Exception as exc:
                    steps.append(f"Auto UV skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                return self._finish(context, action=action, settings=settings, quality=quality, obj=retopo_obj or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Wrap Retopo + UV Supreme setup created. / ラップリトポ + UV 最上位構成を作成しました。"))

            if action == 'VELLUM_CLOTH_DRAPE':
                utils.ensure_sculpt_mode(context, obj)
                try:
                    _call_smart_operator('apply_cloth_filter', [{'filter_type': 'GRAVITY', 'strength': max(0.01, strength)}, {'filter_type': 'GRAVITY'}, {}])
                    steps.append('Cloth filter applied')
                except Exception as exc:
                    steps.append(f"Cloth filter skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                utils.ensure_object_mode(context, obj)
                pin_group = _create_cloth_pin_group(obj, steps)
                added = _add_cloth_drape_modifiers(obj, strength, density, quality, pin_group=pin_group)
                if added <= 0:
                    raise RuntimeError(_smart_utils.localize_bilingual_text("Could not create cloth approximation modifiers. / クロス近似モディファイアを作成できませんでした。"))
                steps.append(f"Cloth approximation modifiers added: {added}")
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_format('Vellum Cloth Drape++ created ({v0} modifier(s)). / クロスドレープ++を作成しました（{v1}モディファイア）。', v0=added, v1=added))

            if action == 'MUSCLE_LAYER_DRIVER':
                utils.ensure_object_mode(context, obj)
                try:
                    _call_smart_operator('create_shape_layer')
                    steps.append('Shape layer created')
                except Exception:
                    if getattr(obj.data, 'shape_keys', None) is None:
                        obj.shape_key_add(name='Basis')
                    key = obj.shape_key_add(name=utils.unique_name('SSS_MuscleLayer'))
                    key.value = 0.0
                    steps.append('Fallback shape key created')
                _create_curvature_proxy_groups(obj, steps)
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                added = _add_corrective_layer_modifiers(obj, strength)
                steps.append(f"Corrective helper modifiers added: {added}")
                try:
                    if settings is not None and str(getattr(settings, 'driver_bone', '') or '').strip():
                        _call_smart_operator('drive_active_shape_layer')
                        steps.append('Shape layer driver linked')
                except Exception as exc:
                    steps.append(f"Driver link skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_format('Muscle Layer Driver++ setup created ({v0} helper modifier(s)). / 筋肉レイヤードライバー++構成を作成しました（補助モディファイア {v1} 個）。', v0=added, v1=added))

            if action == 'CURVE_SWEEP_RAIL_CUT':
                utils.ensure_object_mode(context, obj)
                axis = str(getattr(settings, 'smart_upgrade_axis', 'Y') if settings else 'Y')
                try:
                    _call_smart_operator('add_curve_tube', [{'radius': max(density * 0.35, 0.005), 'length': max(density * segments, 0.05), 'convert_to_mesh': not non_destructive}, {}])
                    steps.append('Curve sweep tube created')
                except Exception as exc:
                    steps.append(f"Curve tube skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                try:
                    _call_smart_operator('add_rail_cutter', [{'axis': axis, 'length': max(density * segments, 0.1), 'width': max(density, 0.01), 'depth': max(strength, 0.01), 'apply_to_target': False, 'apply_boolean': False}, {}])
                    steps.append('ziRail-style cutter guide created')
                except Exception as exc:
                    steps.append(f"Rail cutter skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                return self._finish(context, action=action, settings=settings, quality=quality, obj=utils.active_mesh_object(context) or obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Curve Sweep / ziRail++ helpers created. / カーブスイープ / ziRail++ ヘルパーを作成しました。"))

            if action == 'PROCEDURAL_MICRODETAIL_BRUSH':
                utils.ensure_object_mode(context, obj)
                _set_if_present(settings, 'procedural_strength', max(0.001, strength))
                _set_if_present(settings, 'procedural_scale', max(0.001, density * 12.0))
                for preset in ('MICRO_BREAKUP', 'SURFACE_NOISE'):
                    try:
                        _call_smart_operator('add_procedural_stack', [{'preset': preset}, {}])
                        steps.append(f"Procedural stack added: {_report_id_label(preset)}")
                    except Exception as exc:
                        steps.append(f"Procedural stack skipped/failed ({_report_id_label(preset)}): {_smart_utils.exception_ui_text(exc)}")
                _create_precision_face_attributes(obj, steps, label='SSS_MicroDetailZone')
                _create_topology_quality_groups(obj, steps)
                _create_apex_intelligence_groups(obj, steps)
                _create_surface_guide_curves(context, obj, steps, count=max(2, min(count, 10)), segments=max(segments, 8), density=density, quality=quality, kind='microdetail_surface_guides')
                _apply_precision_polish(obj, quality, steps, bevel_width=0.0)
                try:
                    obj['sss_procedural_microdetail_quality'] = str(quality.get('name', 'HIGH'))
                except Exception:
                    pass
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Procedural Microdetail Brush stack added. / プロシージャル微細ブラシスタックを追加しました。"))

            if action == 'ENVIRONMENT_GROWTH':
                selected_meshes = utils.selected_mesh_objects(context)
                detail_sources = [candidate for candidate in selected_meshes if candidate != obj]
                if detail_sources:
                    try:
                        _call_smart_operator('add_detail_scatter', [{'count': max(1, count), 'min_scale': 0.6, 'max_scale': 1.4, 'align_to_normal': True, 'normal_offset': max(density, 0.001), 'seed': count + segments}, {}])
                        steps.append(f"Selected detail scatter generated from {len(detail_sources)} source object(s)")
                        return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Selected detail scatter generated. / 選択ディテール散布を生成しました。"))
                    except Exception as exc:
                        steps.append(f"Selected scatter skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                utils.ensure_object_mode(context, obj)
                created = _create_environment_growth(context, obj, count=count, segments=segments, radius=density, strength=strength, quality=quality)
                steps.append(f"Environment growth curves created: {created}")
                try:
                    _call_smart_operator('add_procedural_stack', [{'preset': 'DLA_GROWTH'}, {}])
                    steps.append('DLA-style procedural growth stack added')
                except Exception as exc:
                    steps.append(f"DLA stack skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_format('Environment Growth++ helpers created: {v0}. / 環境の成長++ヘルパーを {v1} 個作成しました。', v0=created, v1=created))

            if action == 'PHOTO_REFERENCE_HANDOFF':
                source_path = str(getattr(settings, 'smart_photo_reference_path', '') if settings is not None else '')
                ref_obj = _create_photo_reference_plane(context, source_path, size=max(density * 12.0, 1.0))
                if obj is not None:
                    try:
                        ref_obj.location = obj.location.copy()
                        ref_obj.location.z += max(0.05, density)
                    except Exception:
                        pass
                try:
                    utils.make_active(context, ref_obj)
                except Exception:
                    pass
                steps.append('Photo/reference handoff board created')
                return self._finish(context, action=action, settings=settings, quality=quality, obj=ref_obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Photo Reference Handoff++ created. / 写真リファレンス連携++を作成しました。"))

            if action == 'INTEROP_ROUNDTRIP':
                if settings is not None:
                    try:
                        settings.exchange_format = 'USD'
                    except Exception:
                        pass
                _call_smart_operator('export_exchange')
                steps.append('Exchange export completed with USD preference')
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Interop Roundtrip++ package exported. / 往復受け渡し++パッケージを書き出しました。"))

            if action == 'MESH_CLEANER_PRO':
                utils.ensure_object_mode(context, obj)
                _safe_validate_mesh(obj, steps)
                _bmesh_precision_cleanup(obj, steps, merge_distance=max(_recommended_detail_scale(before or _mesh_stats(obj), density) * 0.02, 1e-7))
                try:
                    _call_fix_common_issues_without_scale_apply(context)
                    steps.append('Common issue repair operator completed')
                except Exception as exc:
                    steps.append(f"Common issue repair skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                obj = utils.active_mesh_object(context) or obj
                _safe_validate_mesh(obj, steps)
                _apply_precision_polish(obj, quality, steps, bevel_width=0.0)
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Mesh Cleaner Pro finished. / メッシュクリーナープロが完了しました。"))

            if action == 'FULL_SAFE_SETUP':
                try:
                    _call_smart_operator('save_snapshot')
                    steps.append('Snapshot saved')
                except Exception:
                    pass
                try:
                    utils.make_recovery_backup(context, obj, 'full_safe_setup', force=True)
                    steps.append('Forced recovery backup created')
                except Exception:
                    pass
                try:
                    _call_smart_operator('analyze_active_mesh')
                    steps.append('Active mesh analysis completed')
                except Exception as exc:
                    steps.append(f"Analysis skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                try:
                    _call_smart_operator('export_diagnostic_report')
                    steps.append('Diagnostic report exported to internal text')
                except Exception as exc:
                    steps.append(f"Diagnostic report skipped/failed: {_smart_utils.exception_ui_text(exc)}")
                return self._finish(context, action=action, settings=settings, quality=quality, obj=obj, before=before, steps=steps, generated_before=generated_before, message=_smart_utils.localize_bilingual_text("Full Safe Setup Supreme finished. / 全安全セットアップ最上位が完了しました。"))

        except Exception as exc:
            try:
                _write_smart_report(context, action=action, settings=settings, quality=quality, obj=obj, before=before, after=_mesh_stats(utils.active_mesh_object(context) or obj), steps=steps + [f"FAILED: {exc}"], generated=_generated_since(generated_before))
            except Exception:
                pass
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Smart upgrade action failed: {v0} / スマートアップグレード処理に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Unknown Smart upgrade action: {v0} / 不明なスマートアップグレードアクションです: {v1}', v0=action, v1=action))
        return {'CANCELLED'}


classes = (
    SSS_OT_run_smart_upgrade_tool,
)
