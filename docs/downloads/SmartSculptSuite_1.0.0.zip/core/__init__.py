# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Smart Sculpt Suite core registration transaction."""
from __future__ import annotations
import bpy
from .. import rna_safety as _rna_safety
from .. import _sss_lifecycle as _lifecycle
from .. import _sss_runtime_errors as _runtime_errors
from . import (
    translation as i18n,
    preferences,
    properties,
    utils,
    icon_assets,
    navigation_properties,
    analyze_operators as ops_analyze,
    workflow_operators as ops_workflow,
    topology_operators as ops_topology,
    non_destructive_operators as ops_non_destructive,
    generate_operators as ops_generate,
    exchange_operators as ops_exchange,
    smart_upgrade_operators as ops_smart_upgrade,
    zbrush_gap_operators as ops_zbrush_gap,
    settings as persistent_settings,
    controls as persistent_controls,
    help as help_runtime,
    popup_operators,
    ui,
)
from .. import edit_mode_sculpt

bl_info = {
    "name": "Smart Sculpt Suite",
    "author": "JELararagi",
    "version": (1, 9, 55),
    "blender": (5, 1, 0),
    "location": "Sidebar > Smart Sculpt",
    "description": "Smart Sculpt workflow suite for Blender 5.1.",
    "category": "Sculpt",
}

MODULES = (
    preferences, properties, ops_analyze, ops_workflow, ops_topology,
    ops_non_destructive, ops_generate, ops_exchange, ops_smart_upgrade,
    ops_zbrush_gap, persistent_controls, help_runtime, popup_operators, ui,
)
CLASSES = tuple(cls for module in MODULES for cls in tuple(getattr(module, "classes", ()) or ()))
_RUNTIME_REGISTERED = False
addon_keymaps: list[tuple[object, object]] = []


def register_keymaps() -> None:
    """Automatic shortcut registration is intentionally disabled."""
    addon_keymaps.clear()


def unregister_keymaps() -> None:
    """No Blender keymap resource is owned by this module."""
    addon_keymaps.clear()


def _is_panel(cls: type) -> bool:
    try:
        return issubclass(cls, bpy.types.Panel)
    except Exception:
        return False


def register() -> None:
    global _RUNTIME_REGISTERED
    if _RUNTIME_REGISTERED:
        return
    journal = _lifecycle.current_journal()
    if journal is None:
        raise RuntimeError("Smart Sculpt core requires an active generation journal")
    checkpoint = journal.checkpoint()
    try:
        utils.initialize_ui_icon_cache()
        # Text normalization runs before RNA registration only.  It never
        # rewrites an already registered class.
        try:
            utils.normalize_class_texts(CLASSES)
            utils.enhance_operator_descriptions(CLASSES)
        except Exception as exc:
            _runtime_errors.record("core_text_normalization", exc)
        for cls in CLASSES:
            # The Suite's 11 fixed roots own all N-panel surfaces.  Legacy
            # source Panels stay defined for compatibility but are not live.
            if not _is_panel(cls):
                _rna_safety.register_class(cls)
        properties.register_properties()
        edit_mode_sculpt.register(register_panel=False)
        persistent_settings.register()
        _lifecycle.register_translation(__name__, i18n.translations_dict)
        try:
            utils.register_runtime_translations()
        except Exception as exc:
            _runtime_errors.record("core_runtime_translation", exc)
        try:
            icon_assets.register()
        except Exception as exc:
            _runtime_errors.record("core_icons", exc)
        register_keymaps()
        _RUNTIME_REGISTERED = True
    except Exception:
        rollback_registration()
        journal.rollback_to(checkpoint, "core_register_failure")
        raise


def rollback_registration() -> None:
    global _RUNTIME_REGISTERED
    _RUNTIME_REGISTERED = False
    unregister_keymaps()
    for callback, label in (
        (icon_assets.unregister, "core_icons_rollback"),
        (persistent_settings.rollback_registration, "core_settings_rollback"),
        (persistent_controls.clear_session_cache, "core_controls_cache_rollback"),
        (utils.clear_ui_icon_cache, "core_icon_enum_cache_rollback"),
        (ui.clear_ui_caches, "core_ui_cache_rollback"),
        (edit_mode_sculpt.unregister, "edit_mode_rollback"),
        (properties.unregister_properties, "core_properties_rollback"),
    ):
        try:
            callback()
        except Exception as exc:
            _runtime_errors.record(label, exc)
    for cls in reversed(CLASSES):
        if not _is_panel(cls):
            try:
                _rna_safety.unregister_class(cls)
            except Exception as exc:
                _runtime_errors.record("core_class_rollback", exc)
    try:
        _lifecycle.unregister_translation(__name__)
    except Exception as exc:
        _runtime_errors.record("core_translation_rollback", exc)


def unregister() -> None:
    was_registered=bool(_RUNTIME_REGISTERED)
    if was_registered:
        try:
            persistent_settings.unregister()
        except Exception as exc:
            _runtime_errors.record("core_settings_unregister", exc)
    # The remaining cleanup is exact-identity and safe for a partial generation.
    rollback_registration()


if __name__ == "__main__":
    register()
