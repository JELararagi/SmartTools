# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Compatibility no-op: production never wraps bpy.props or registered RNA classes."""
def begin_runtime_audit(): return None
def finish_runtime_audit(): return None
def clear_runtime_audit(): return None
def abort_runtime_audit(): return None
