# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


from . import utils, utils as _smart_utils
import bpy
from bpy.types import Operator



def _report_yes_no(value) -> str:
    if value:
        return _smart_utils.ui_text("Yes", "あり")
    return _smart_utils.ui_text("No", "なし")


def _report_severity(severity) -> str:
    labels = {'INFO': ('Info', '情報'), 'WARNING': ('Warning', '警告'), 'ERROR': ('Error', 'エラー')}
    english, japanese = labels.get(str(severity or ''), (str(severity or ''), str(severity or '')))
    return _smart_utils.ui_text(english, japanese)


class SSS_OT_prepare_workspace(Operator):
    bl_idname = "smart_sculpt.prepare_workspace"
    bl_label = "Prepare Workspace"
    bl_description = _smart_utils.localize_bilingual_text((
        "Configure a sculpt-friendly viewport, optionally enter Sculpt mode, and reveal the most useful overlays. "
        "/ スカルプト向けのビューポート設定を行い、必要に応じてスカルプトモードへ入り、重要なオーバーレイを表示します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh object. / アクティブなメッシュオブジェクトがありません。"))
            return {'CANCELLED'}

        if settings and settings.auto_enter_sculpt:
            if utils.strict_edit_mode_sculpt_active(context):
                utils.ensure_edit_mode(context, obj)
            else:
                utils.ensure_sculpt_mode(context, obj)

        override, space = utils.find_view3d_context(context)
        if space and getattr(space, "type", None) == 'VIEW_3D':
            shading = space.shading
            overlay = space.overlay
            utils.set_attr_if_exists(shading, "type", 'SOLID')
            utils.set_attr_if_exists(shading, "light", 'MATCAP')
            utils.set_attr_if_exists(shading, "show_cavity", True)
            utils.set_attr_if_exists(shading, "cavity_type", 'BOTH')
            utils.set_attr_if_exists(shading, "show_object_outline", False)
            utils.set_attr_if_exists(shading, "show_specular_highlight", True)
            utils.set_attr_if_exists(overlay, "show_overlays", True)
            utils.set_attr_if_exists(overlay, "show_wireframes", False)
            for attr in ("show_sculpt_face_sets", "show_face_sets"):
                utils.set_attr_if_exists(overlay, attr, True)
            utils.set_attr_if_exists(overlay, "show_sculpt_mask", True)
            utils.tag_redraw_area(override.get("area") if isinstance(override, dict) else None)

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Workspace prepared. / ワークスペースを準備しました。"))
        return {'FINISHED'}


class SSS_OT_toggle_silhouette(Operator):
    bl_idname = "smart_sculpt.toggle_silhouette"
    bl_label = "Silhouette"
    bl_description = _smart_utils.localize_bilingual_text((
        "Toggle a flat silhouette preview for checking the big read of the sculpt. "
        "/ スカルプト全体の読みや大きなシルエット確認に便利なフラット表示へ切り替えます。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        override, space = utils.find_view3d_context(context)
        if space is None or getattr(space, "type", None) != 'VIEW_3D':
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Open a 3D Viewport and run this again. / 3Dビューポートを開いてから再実行してください。"))
            return {'CANCELLED'}

        scene = context.scene
        shading = space.shading
        previous_state = utils.pop_view3d_state(scene, space, key="_sss_silhouette_states")
        enabled = previous_state is not None
        if not enabled:
            utils.store_view3d_state(scene, space, utils.capture_view3d_state(space), key="_sss_silhouette_states")
            utils.set_attr_if_exists(shading, "type", 'SOLID')
            utils.set_attr_if_exists(shading, "light", 'FLAT')
            utils.set_attr_if_exists(shading, "color_type", 'SINGLE')
            try:
                shading.single_color = (0.08, 0.08, 0.08)
            except Exception:
                pass
            utils.set_attr_if_exists(shading, "show_cavity", False)
            utils.set_attr_if_exists(shading, "show_shadows", False)
            overlay = getattr(space, "overlay", None)
            utils.set_attr_if_exists(overlay, "show_wireframes", False)
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Silhouette view enabled. / シルエット表示を有効化しました。"))
        else:
            restored = utils.restore_view3d_state(space, previous_state)
            if restored:
                self.report({'INFO'}, _smart_utils.localize_bilingual_text("Silhouette view disabled and previous viewport settings restored. / シルエット表示を無効化し、元のビューポート設定を復元しました。"))
            else:
                self.report({'INFO'}, _smart_utils.localize_bilingual_text("Silhouette view disabled. / シルエット表示を無効化しました。"))
        utils.tag_redraw_area(override.get("area") if isinstance(override, dict) else None)
        return {'FINISHED'}


class SSS_OT_set_viewport_preset(Operator):
    bl_idname = "smart_sculpt.set_viewport_preset"
    bl_label = "Set Viewport Preset"
    bl_description = _smart_utils.localize_bilingual_text((
        'Apply a compact sculpt viewport preset for quick visual review. Clay focuses on readable forms, Technical emphasizes edges and wire data, Face Sets highlights sculpt groups, and Wireframe favors structure inspection. / 素早い視覚確認のためにコンパクトなスカルプト用ビューポートプリセットを適用します。クレイは形の読みやすさ、テクニカルはエッジとワイヤ、面セットはグループ確認、ワイヤーフレームは構造確認を重視します。'
    ))
    bl_options = set()
    _sms_no_undo = True

    preset: bpy.props.EnumProperty(
        name="Preset",
        items=[
            ('CLAY', "Clay", _smart_utils.localize_bilingual_text("Readable clay-like sculpt view / 形の把握に向いたクレイ風表示")),
            ('TECHNICAL', "Technical", _smart_utils.localize_bilingual_text("Show more structure and wire data / 構造とワイヤを見やすくする表示")),
            ('FACESETS', "Face Sets", _smart_utils.localize_bilingual_text("Emphasize sculpt face-set readability / フェイスセットの読みやすさを強調")),
            ('WIREFRAME', "Wireframe", _smart_utils.localize_bilingual_text("Inspect mesh flow and density / メッシュの流れと密度を確認")),
        ],
        default='CLAY',
    )

    def execute(self, context):
        override, space = utils.find_view3d_context(context)
        if space is None or getattr(space, "type", None) != 'VIEW_3D':
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Open a 3D Viewport and run this again. / 3Dビューポートを開いてから再実行してください。"))
            return {'CANCELLED'}

        shading = space.shading
        overlay = getattr(space, "overlay", None)
        utils.set_attr_if_exists(shading, "type", 'SOLID')
        utils.set_attr_if_exists(overlay, "show_overlays", True)

        if self.preset == 'CLAY':
            utils.set_attr_if_exists(shading, "light", 'MATCAP')
            utils.set_attr_if_exists(shading, "show_cavity", True)
            utils.set_attr_if_exists(shading, "show_shadows", True)
            utils.set_attr_if_exists(shading, "color_type", 'MATERIAL')
            utils.set_attr_if_exists(overlay, "show_wireframes", False)
            utils.set_attr_if_exists(overlay, "show_sculpt_mask", True)
            for attr in ("show_sculpt_face_sets", "show_face_sets"):
                utils.set_attr_if_exists(overlay, attr, False)
        elif self.preset == 'TECHNICAL':
            utils.set_attr_if_exists(shading, "light", 'STUDIO')
            utils.set_attr_if_exists(shading, "show_cavity", True)
            utils.set_attr_if_exists(shading, "show_shadows", False)
            utils.set_attr_if_exists(overlay, "show_wireframes", True)
            utils.set_attr_if_exists(overlay, "show_sculpt_mask", True)
            for attr in ("show_sculpt_face_sets", "show_face_sets"):
                utils.set_attr_if_exists(overlay, attr, True)
        elif self.preset == 'FACESETS':
            utils.set_attr_if_exists(shading, "light", 'MATCAP')
            utils.set_attr_if_exists(shading, "show_cavity", True)
            utils.set_attr_if_exists(shading, "show_shadows", False)
            utils.set_attr_if_exists(overlay, "show_wireframes", False)
            utils.set_attr_if_exists(overlay, "show_sculpt_mask", True)
            for attr in ("show_sculpt_face_sets", "show_face_sets"):
                utils.set_attr_if_exists(overlay, attr, True)
        elif self.preset == 'WIREFRAME':
            utils.set_attr_if_exists(shading, "light", 'MATCAP')
            utils.set_attr_if_exists(shading, "show_cavity", False)
            utils.set_attr_if_exists(shading, "show_shadows", False)
            utils.set_attr_if_exists(overlay, "show_wireframes", True)
            utils.set_attr_if_exists(overlay, "show_sculpt_mask", False)
            for attr in ("show_sculpt_face_sets", "show_face_sets"):
                utils.set_attr_if_exists(overlay, attr, False)

        utils.tag_redraw_area(override.get("area") if isinstance(override, dict) else None)
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Viewport preset applied: {v0} / ビューポートプリセットを適用しました: {v1}', v0=self.preset, v1=self.preset))
        return {'FINISHED'}


class SSS_OT_prepare_multi_object_sculpt(Operator):
    bl_idname = "smart_sculpt.prepare_multi_object_sculpt"
    bl_label = "Prepare Multi-Object Workflow"
    bl_description = _smart_utils.localize_bilingual_text((
        'Prepare the current multi-object sculpt workflow conservatively: keep the selection organized, optionally make shared meshes single-user, and enter Sculpt mode on the active object. This does not claim native live multi-object sculpt editing, which Blender\'s manual does not describe. / 現在の複数オブジェクト造形ワークフローを保守的に準備します。選択を整理し、必要なら共有メッシュをシングルユーザー化し、アクティブオブジェクトでスカルプトモードへ入ります。Blender 標準のライブ同時編集を前提にはしません。'
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        meshes = utils.selected_mesh_objects(context, editable_only=True)
        if not meshes:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select one or more editable mesh objects. / 編集可能なメッシュオブジェクトを1つ以上選択してください。"))
            return {'CANCELLED'}

        active = utils.active_mesh_object(context) or meshes[0]
        duplicated = 0
        if settings and settings.multi_object_make_single_user:
            for obj in meshes:
                if obj.data and obj.data.users > 1:
                    obj.data = obj.data.copy()
                    duplicated += 1

        utils.select_only(context, meshes, active=active)
        if utils.strict_edit_mode_sculpt_active(context):
            if not utils.ensure_edit_mode(context, active):
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Mesh Edit Mode. / メッシュ編集モードへ入れませんでした。"))
                return {'CANCELLED'}
        elif not utils.ensure_sculpt_mode(context, active):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt mode. / スカルプトモードへ入れませんでした。"))
            return {'CANCELLED'}

        for obj in meshes:
            obj.select_set(True)

        if duplicated:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Prepared {v0} objects; duplicated {v1} shared mesh datablock(s). Use Sculpt Session for one-mesh cross-part sculpting. / {v2} 個を準備し、{v3} 個の共有メッシュを複製しました。パーツをまたいで一体として造形したい場合はスカルプトセッションを使ってください。', v0=len(meshes), v1=duplicated, v2=len(meshes), v3=duplicated))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Prepared {v0} objects for quick switching and safe workflow setup. Use Sculpt Session for joined/proxy sculpting. / {v1} 個を安全な複数オブジェクトワークフロー向けに準備しました。結合またはプロキシ造形にはスカルプトセッションを使ってください。', v0=len(meshes), v1=len(meshes)))
        return {'FINISHED'}




class SSS_OT_cycle_selected_mesh(Operator):
    bl_idname = "smart_sculpt.cycle_selected_mesh"
    bl_label = "Cycle Selected Mesh"
    bl_description = _smart_utils.localize_bilingual_text((
        'Make the previous or next selected mesh active so you can keep a part-based sculpt workflow moving without rebuilding the selection. If you were already sculpting, Sculpt mode is preserved on the new active mesh. / 前後の選択メッシュをアクティブに切り替え、選択を組み直さずにパーツ分割スカルプトを続けられるようにします。すでにスカルプトモード中なら、新しいアクティブメッシュでもスカルプトモードを維持します。'
    ))
    bl_options = {'UNDO'}

    direction: bpy.props.EnumProperty(
        name="Direction",
        items=[
            ('PREV', "Previous", _smart_utils.localize_bilingual_text("Activate the previous selected mesh / ひとつ前の選択メッシュをアクティブ化")),
            ('NEXT', "Next", _smart_utils.localize_bilingual_text("Activate the next selected mesh / ひとつ次の選択メッシュをアクティブ化")),
        ],
        default='NEXT',
    )

    @classmethod
    def poll(cls, context):
        return len(utils.selected_mesh_objects(context, editable_only=True)) >= 2

    def execute(self, context):
        meshes = utils.selected_mesh_objects(context, editable_only=True)
        if len(meshes) < 2:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select at least two editable mesh objects. / 編集可能なメッシュオブジェクトを2つ以上選択してください。"))
            return {'CANCELLED'}

        current_active = utils.active_mesh_object(context) or context.view_layer.objects.active or meshes[0]
        if current_active not in meshes:
            current_active = meshes[0]
        current_index = meshes.index(current_active)
        step = -1 if self.direction == 'PREV' else 1
        target = meshes[(current_index + step) % len(meshes)]

        previous_mode = getattr(current_active, 'mode', 'OBJECT') if current_active else 'OBJECT'
        utils.select_only(context, meshes, active=target)
        settings = utils.settings_from_context(context)
        if previous_mode == 'SCULPT' or (settings and settings.auto_enter_sculpt):
            if not utils.ensure_sculpt_mode(context, target):
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt mode on the target mesh. / 切り替え先メッシュでスカルプトモードへ入れませんでした。"))
                return {'CANCELLED'}

        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Active part: {v0} / アクティブパーツ: {v1}', v0=target.name, v1=target.name))
        return {'FINISHED'}


class SSS_OT_analyze_active_mesh(Operator):
    bl_idname = "smart_sculpt.analyze_active_mesh"
    bl_label = "Analyze Active Mesh"
    bl_description = _smart_utils.localize_bilingual_text(
        "Run a conservative diagnostic pass to find common sculpt problems such as scale issues, invalid mesh data, dyntopo conflicts, linked meshes, or topology dirt. / スケール問題、無効なメッシュデータ、ダイナミックトポロジーの競合、リンクメッシュ、トポロジーの汚れなど、よくあるスカルプト障害を保守的に診断します。"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        utils.clear_diagnostics(settings)

        obj = utils.active_mesh_object(context)
        if obj is None:
            utils.add_diagnostic(settings, 'ERROR', _smart_utils.ui_text("No active mesh.", "対象のメッシュがありません。"), _smart_utils.localize_bilingual_text("Select a mesh object first. / 最初にメッシュオブジェクトを選択してください。"))
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        dyn_enabled = bool(getattr(obj, "use_dynamic_topology_sculpting", False))
        multires = utils.find_multires_modifier(obj)
        topo_sig = utils.topology_signature(obj)

        if obj.library or obj.data.library:
            utils.add_diagnostic(
                settings,
                'ERROR',
                _smart_utils.ui_text("Linked library data.", "リンクされたライブラリのデータです。"),
                _smart_utils.localize_bilingual_text("Linked objects or meshes are usually not editable for sculpt fixes. Make a local copy first. / ライブラリリンクされたデータは通常そのままでは修正できません。ローカル化してから作業してください。"),
            )

        if obj.data.users > 1:
            utils.add_diagnostic(
                settings,
                'WARNING',
                _smart_utils.ui_text("Shared mesh data-block.", "メッシュデータが共有されています。"),
                _smart_utils.localize_bilingual_text("Sculpting will affect every object using the same mesh. Make the mesh single-user before destructive edits. / 同じメッシュを共有する全オブジェクトへ影響します。破壊的編集前にシングルユーザー化してください。"),
            )

        if utils.has_unapplied_scale(obj):
            detail = _smart_utils.localize_bilingual_text("Scale is not applied. Brush radius, remeshing, and symmetry can feel inconsistent. / スケール未適用です。ブラシ半径やリメッシュ、対称処理が不安定になることがあります。")
            if utils.has_non_uniform_scale(obj):
                detail = _smart_utils.localize_bilingual_text("Scale is non-uniform. This is a high-risk source of brush and remesh inconsistency. / スケールが非等方です。ブラシやリメッシュの不整合が起きやすい高リスク状態です。")
            utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Scale mismatch.", "スケールが揃っていません。"), detail)

        if utils.has_negative_scale(obj):
            utils.add_diagnostic(
                settings,
                'WARNING',
                _smart_utils.ui_text("Negative scale detected.", "負のスケールがあります。"),
                _smart_utils.localize_bilingual_text("Negative object scale can invert normals, mirror extracted shells, and make boolean or remesh results harder to predict. Apply scale before destructive operations when possible. / 負のスケールは法線反転、抽出シェルの反転、ブーリアンやリメッシュ結果の不安定化を招くことがあります。可能なら破壊的処理前にスケール適用を推奨します。"),
            )

        if dyn_enabled and multires is not None:
            utils.add_diagnostic(
                settings,
                'ERROR',
                _smart_utils.ui_text("Dyntopo and Multires are both present.", "ダイナミックトポロジーとマルチレゾが同時にあります。"),
                _smart_utils.localize_bilingual_text("These workflows fight each other. Use Dyntopo for freeform blocking, or Multires for topology-preserving detail. / ダイナミックトポロジーとマルチレゾは相性が悪いです。自由造形にはダイナミックトポロジー、トポロジー維持にはマルチレゾを使い分けてください。"),
            )

        if dyn_enabled and obj.data.shape_keys and len(obj.data.shape_keys.key_blocks) > 1:
            utils.add_diagnostic(
                settings,
                'ERROR',
                _smart_utils.ui_text("Dyntopo with shape keys.", "ダイナミックトポロジーとシェイプキーが同時にあります。"),
                _smart_utils.localize_bilingual_text("Dynamic topology is not compatible with live shape-key layering. Use snapshots instead. / ダイナミックトポロジーはシェイプキーによるライブレイヤーと相性がありません。代わりにスナップショットを使ってください。"),
            )

        if multires is not None:
            later_mods = [mod for mod in obj.modifiers[obj.modifiers.find(multires.name) + 1:] if mod.show_viewport]
            if later_mods:
                utils.add_diagnostic(
                    settings,
                    'WARNING',
                    _smart_utils.ui_text("Modifiers after Multires.", "マルチレゾの後にモディファイアがあります。"),
                    _smart_utils.localize_bilingual_text("Viewport modifiers after Multires can change what you sculpt against. / マルチレゾの後段モディファイアはスカルプト対象を変えてしまうことがあります。"),
                )

        if topo_sig[2] > 2_000_000:
            utils.add_diagnostic(
                settings,
                'WARNING',
                _smart_utils.ui_text("Very dense mesh.", "非常に高密度なメッシュです。"),
                _smart_utils.localize_bilingual_format('Faces: {v0:,}. Consider proxy sculpting, voxel cleanup, or Multires staging. / 面数 {v1:,}。プロキシスカルプト、ボクセル整理、マルチレゾ段階運用を検討してください。', v0=topo_sig[2], v1=topo_sig[2]),
            )
        elif topo_sig[2] > 500_000:
            utils.add_diagnostic(
                settings,
                'INFO',
                _smart_utils.ui_text("Heavy mesh.", "重いメッシュです。"),
                _smart_utils.localize_bilingual_format('Faces: {v0:,}. Performance may vary by hardware. / 面数 {v1:,}。環境によって操作感が重くなる場合があります。', v0=topo_sig[2], v1=topo_sig[2]),
            )

        if utils.validate_mesh_copy(obj):
            utils.add_diagnostic(
                settings,
                'WARNING',
                _smart_utils.ui_text("Mesh validate reports issues.", "メッシュの検証で問題が見つかりました。"),
                _smart_utils.localize_bilingual_text("The mesh copy required cleanup. Running Fix Common Issues can safely rebuild some internal data. / メッシュのコピーで修正が必要と判断されました。共通問題修正で一部の内部データを安全に再構築できます。"),
            )

        layer_info = utils.mesh_data_layer_info(obj.data)
        uv_layer_count = layer_info["uv_count"]
        color_attribute_count = layer_info["color_count"]
        material_slot_count = len(getattr(obj, 'material_slots', []) or [])
        selected_mesh_count = len(utils.selected_mesh_objects(context, editable_only=True))

        if dyn_enabled and (uv_layer_count > 0 or color_attribute_count > 0 or layer_info["has_face_sets"]):
            details = []
            if uv_layer_count > 0:
                details.append(f"UV:{uv_layer_count}")
            if color_attribute_count > 0:
                details.append(f"{_smart_utils.ui_text('Color', 'カラー')}:{color_attribute_count}")
            if layer_info["has_face_sets"]:
                details.append(_smart_utils.ui_text("Face Sets", "フェイスセット"))
            detail_text = _smart_utils.ui_text(", ", "、").join(details) if details else _smart_utils.ui_text("custom attributes", "独自の属性")
            utils.add_diagnostic(
                settings,
                'WARNING',
                _smart_utils.ui_text("Dyntopo may destroy custom sculpt data.", "ダイナミックトポロジーでスカルプト用のデータが失われるおそれがあります。"),
                _smart_utils.localize_bilingual_format("Dyntopo is active while {v0} is present. Blender's sculpt documentation warns that UV maps, color attributes, and face sets can be lost or corrupted by Dyntopo. / {v1} がある状態でダイナミックトポロジーが有効です。Blender のスカルプト文書では、ダイナミックトポロジーにより UV、カラー属性、フェイスセットが失われたり壊れたりする可能性があるとされています。", v0=detail_text, v1=detail_text),
            )

        if uv_layer_count == 0:
            utils.add_diagnostic(
                settings,
                'INFO',
                _smart_utils.ui_text("No UV map present.", "UV マップがありません。"),
                _smart_utils.localize_bilingual_text("This is not a sculpting error, but Auto UV Project or a manual unwrap will be needed before texture-centric handoff. / これはスカルプトの失敗ではありませんが、テクスチャ前提の受け渡し前には 自動UV投影か手動 UV 展開が必要です。"),
            )

        if material_slot_count == 0:
            utils.add_diagnostic(
                settings,
                'INFO',
                _smart_utils.ui_text("No material slots.", "マテリアルスロットがありません。"),
                _smart_utils.localize_bilingual_text("Material-based face-set initialization will not split anything until at least one material slot exists. / マテリアルベースのフェイスセット初期化は、最低1つのマテリアルスロットがないと分割できません。"),
            )

        if selected_mesh_count > 1:
            utils.add_diagnostic(
                settings,
                'INFO',
                _smart_utils.ui_text("Multiple mesh parts are selected.", "複数のメッシュを選択しています。"),
                _smart_utils.localize_bilingual_text("Use Prev/Next Part for quick part switching, or create a Sculpt Session when you need a unified or proxy sculpt object. / パーツ切り替えには前後のパーツへの移動、統合または軽量化した造形にはスカルプトセッションを使ってください。"),
            )

        topo_issues = utils.analyze_bmesh_issues(obj)
        if topo_issues["loose_verts"] is not None:
            if topo_issues["loose_verts"]:
                utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Loose vertices detected.", "孤立頂点があります。"), _smart_utils.localize_bilingual_format('Loose vertices: {v0:,}. / 孤立頂点数: {v1:,}', v0=topo_issues['loose_verts'], v1=topo_issues['loose_verts']))
            if topo_issues["loose_edges"]:
                utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Loose edges detected.", "孤立辺があります。"), _smart_utils.localize_bilingual_format('Loose edges: {v0:,}. / 孤立辺数: {v1:,}', v0=topo_issues['loose_edges'], v1=topo_issues['loose_edges']))
            if topo_issues.get("loose_faces"):
                utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Isolated faces detected.", "孤立面があります。"), _smart_utils.localize_bilingual_format('Isolated faces: {v0:,}. Delete Loose Geometry can now remove these as well. / 孤立面数: {v1:,}。孤立ジオメトリの削除でこれらも削除できます。', v0=topo_issues['loose_faces'], v1=topo_issues['loose_faces']))
            if topo_issues["non_manifold_edges"]:
                utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Non-manifold edges detected.", "非多様体辺があります。"), _smart_utils.localize_bilingual_format('Non-manifold edges: {v0:,}. / 非多様体辺数: {v1:,}', v0=topo_issues['non_manifold_edges'], v1=topo_issues['non_manifold_edges']))
            if topo_issues.get("zero_length_edges"):
                utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Zero-length edges detected.", "長さゼロの辺があります。"), _smart_utils.localize_bilingual_format('Zero-length edges: {v0:,}. Dissolve Degenerate Geometry may help. / 長さゼロの辺数: {v1:,}。縮退ジオメトリの溶解が有効な場合があります。', v0=topo_issues['zero_length_edges'], v1=topo_issues['zero_length_edges']))
            if topo_issues.get("zero_area_faces"):
                utils.add_diagnostic(settings, 'WARNING', _smart_utils.ui_text("Zero-area faces detected.", "面積ゼロの面があります。"), _smart_utils.localize_bilingual_format('Zero-area faces: {v0:,}. Degenerate cleanup may help. / 面積ゼロ面数: {v1:,}。縮退整理が有効な場合があります。', v0=topo_issues['zero_area_faces'], v1=topo_issues['zero_area_faces']))
            if topo_issues["ngons"]:
                utils.add_diagnostic(settings, 'INFO', _smart_utils.ui_text("N-gons found.", "N ゴンがあります。"), _smart_utils.localize_bilingual_format('N-gons: {v0:,}. Fine for sculpting, but worth fixing before final retopo or export. / Nゴン数: {v1:,}。スカルプト中は問題ありませんが、最終リトポや書き出し前に確認を推奨します。', v0=topo_issues['ngons'], v1=topo_issues['ngons']))
            if topo_issues.get("non_manifold_edges") or topo_issues.get("loose_faces"):
                utils.add_diagnostic(
                    settings,
                    'WARNING',
                    _smart_utils.ui_text("Open or non-manifold topology may break destructive tools.", "開いた形状や非多様体では、破壊的な処理が失敗しやすくなります。"),
                    _smart_utils.localize_bilingual_text("Voxel remesh, mask extract, mask slice, boolean cleanup, and some proxy-session steps become more failure-prone on open or non-manifold meshes. Clean the mesh first when results look unstable. / 開いた形状や非多様体メッシュでは、ボクセルリメッシュ、マスク抽出、マスクスライス、ブーリアン整理、プロキシセッション処理の失敗率が上がります。結果が不安定なら先にメッシュ整理を行ってください。"),
                )
        else:
            utils.add_diagnostic(settings, 'INFO', _smart_utils.ui_text("Deep topology scan skipped.", "詳しいトポロジー検査を省略しました。"), _smart_utils.localize_bilingual_text("Mesh is too dense for a fast BMesh scan. / 高密度メッシュのため高速スキャンを省略しました。"))

        if not settings.diagnostics:
            utils.add_diagnostic(settings, 'INFO', _smart_utils.ui_text("No obvious problems found.", "大きな問題は見つかりませんでした。"), _smart_utils.localize_bilingual_text("The mesh passed the conservative checks. / 保守的なチェックでは大きな問題は見つかりませんでした。"))

        try:
            from . import smart_upgrade_operators as _upgrade_ops, ui as _ui_module
            _ui_module.cache_ui_mesh_stats(obj, _upgrade_ops._mesh_stats(obj))
        except Exception:
            pass

        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Analysis complete: {v0} item(s). / 解析完了: {v1} 件', v0=len(settings.diagnostics), v1=len(settings.diagnostics)))
        return {'FINISHED'}


class SSS_OT_fix_common_issues(Operator):
    bl_idname = "smart_sculpt.fix_common_issues"
    bl_label = "Fix Common Issues"
    bl_description = _smart_utils.localize_bilingual_text(
        "Safely fix a conservative set of common sculpt blockers: internal mesh validation, optional scale apply, normal recalculation, degenerate dissolve, and optional merge-by-distance cleanup. / 内部メッシュ検証、任意のスケール適用、法線再計算、縮退ジオメトリ溶解、任意の距離マージなど、安全寄りの一般的な障害を修正します。"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh object. / アクティブなメッシュオブジェクトがありません。"))
            return {'CANCELLED'}

        original_mode = getattr(obj, "mode", 'OBJECT')
        if obj.library or obj.data.library:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_text("Linked data cannot be fixed in-place. / リンクデータはその場で修正できません。"))
            return {'CANCELLED'}

        with utils.preserved_selection_and_mode(context, obj, 'OBJECT'):
            utils.make_recovery_backup(context, obj, 'fix_common_issues')
            utils.ensure_single_user_mesh(obj)

            try:
                obj.data.validate(verbose=False, clean_customdata=True)
            except Exception:
                pass

            if settings and settings.apply_scale_on_fix and utils.has_unapplied_scale(obj):
                try:
                    utils.safe_operator_call(
                        bpy.ops.object.transform_apply,
                        [{'location': False, 'rotation': False, 'scale': True}],
                    )
                except Exception:
                    self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Scale apply skipped. / スケール適用をスキップしました。"))

            if settings and settings.recalc_normals_on_fix:
                if utils.ensure_edit_mode(context, obj):
                    try:
                        utils.safe_operator_call(
                            bpy.ops.mesh.select_all,
                            [{'action': 'SELECT'}],
                        )
                        utils.safe_operator_call(
                            bpy.ops.mesh.normals_make_consistent,
                            [{'inside': False}],
                        )
                    except Exception:
                        self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Normal recalculation skipped. / 法線再計算をスキップしました。"))
                    finally:
                        utils.ensure_object_mode(context, obj)

            if settings and settings.delete_loose_on_fix:
                if obj.data.shape_keys or utils.find_multires_modifier(obj):
                    self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Delete loose skipped to protect shape keys or Multires. / シェイプキーやマルチレゾを保護するため孤立ジオメトリ削除をスキップしました。"))
                elif utils.ensure_edit_mode(context, obj):
                    try:
                        utils.safe_operator_call(
                            bpy.ops.mesh.select_all,
                            [{'action': 'SELECT'}],
                        )
                        utils.safe_operator_call(
                            bpy.ops.mesh.delete_loose,
                            [
                                {'use_verts': True, 'use_edges': True, 'use_faces': True},
                                {'use_verts': True, 'use_edges': True, 'use_faces': False},
                                {'use_verts': True, 'use_edges': True},
                                {},
                            ],
                        )
                    except Exception:
                        self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Delete loose skipped. / 孤立ジオメトリ削除をスキップしました。"))
                    finally:
                        utils.ensure_object_mode(context, obj)

            if settings and settings.dissolve_degenerate_on_fix:
                if obj.data.shape_keys or utils.find_multires_modifier(obj):
                    self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Dissolve degenerate skipped to protect shape keys or Multires. / シェイプキーやマルチレゾを保護するため縮退溶解をスキップしました。"))
                elif utils.ensure_edit_mode(context, obj):
                    try:
                        utils.safe_operator_call(
                            bpy.ops.mesh.select_all,
                            [{'action': 'SELECT'}],
                        )
                        threshold = max(getattr(settings, 'degenerate_threshold_on_fix', 0.0), 0.0)
                        utils.safe_operator_call(
                            bpy.ops.mesh.dissolve_degenerate,
                            [
                                {'threshold': threshold},
                                {'dist': threshold},
                                {},
                            ],
                        )
                    except Exception:
                        self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Dissolve degenerate skipped. / 縮退ジオメトリ溶解をスキップしました。"))
                    finally:
                        utils.ensure_object_mode(context, obj)

            merge_distance = settings.merge_distance_on_fix if settings else 0.0
            if merge_distance > 0.0:
                if obj.data.shape_keys or utils.find_multires_modifier(obj):
                    self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Merge by distance skipped to protect shape keys or Multires. / シェイプキーやマルチレゾを保護するため距離マージをスキップしました。"))
                elif utils.ensure_edit_mode(context, obj):
                    try:
                        utils.safe_operator_call(
                            bpy.ops.mesh.select_all,
                            [{'action': 'SELECT'}],
                        )
                        utils.call_operator_by_paths(
                            ("mesh.merge_by_distance", "mesh.remove_doubles"),
                            [
                                {'distance': merge_distance},
                                {'threshold': merge_distance},
                            ],
                        )
                    except Exception:
                        self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Merge by distance skipped. / 距離マージをスキップしました。"))
                    finally:
                        utils.ensure_object_mode(context, obj)

            if original_mode == 'SCULPT':
                utils.ensure_sculpt_mode(context, obj)
            elif original_mode == 'EDIT':
                utils.ensure_edit_mode(context, obj)

        restored, reason, counts = utils.restore_recovery_if_invalid_topology(context, obj)
        if restored:
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Fix Common Issues produced invalid topology and was rolled back ({v0} verts / {v1} faces, reason={v2}). / 共通修正の結果が不正トポロジーだったためロールバックしました（{v3} 頂点 / {v4} 面, 理由={v5}）。', v0=counts[0], v1=counts[2], v2=reason or 'fix_common_issues', v3=counts[0], v4=counts[2], v5=reason or 'fix_common_issues'))
            return {'CANCELLED'}
        if not utils.mesh_has_meaningful_topology(obj):
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Fix Common Issues produced invalid topology ({v0} verts / {v1} faces). / 共通修正の結果のトポロジーが不正です（{v2} 頂点 / {v3} 面）。', v0=counts[0], v1=counts[2], v2=counts[0], v3=counts[2]))
            return {'CANCELLED'}

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Common fixes applied. / 共通修正を適用しました。"))
        return {'FINISHED'}


class SSS_OT_export_diagnostic_report(Operator):
    bl_idname = "smart_sculpt.export_diagnostic_report"
    bl_label = "Export Diagnostic Report"
    bl_description = _smart_utils.localize_bilingual_text((
        "Write the current diagnostic results into a Blender Text datablock so the analysis can be reviewed, saved, or shared. "
        "/ 現在の診断結果を Blender のテキストデータへ書き出し、解析内容をレビュー・保存・共有しやすくします。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if settings is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Settings unavailable. / 設定が見つかりません。"))
            return {'CANCELLED'}

        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        counts = utils.topology_signature(obj)
        multires = utils.find_multires_modifier(obj)
        shape_keys = getattr(obj.data, "shape_keys", None)
        shape_key_count = len(shape_keys.key_blocks) if shape_keys else 0
        recommendations = []
        layer_info = utils.mesh_data_layer_info(obj.data)
        uv_layer_count = layer_info["uv_count"]
        color_attribute_count = layer_info["color_count"]
        material_slot_count = len(getattr(obj, 'material_slots', []) or [])
        selected_mesh_count = len(utils.selected_mesh_objects(context, editable_only=True))

        if utils.has_unapplied_scale(obj):
            recommendations.append(_smart_utils.localize_bilingual_text("- Apply Fix Common Issues with scale apply when brush radius, remesh size, or symmetry feels unstable. / ブラシ半径、リメッシュサイズ、対称が不安定なら スケール適用付きで共通問題の修正を使ってください。"))
        if utils.has_negative_scale(obj):
            recommendations.append(_smart_utils.localize_bilingual_text("- Negative scale is present. Apply scale before heavy booleans, extracts, or remesh steps to reduce mirrored or inverted results. / 負のスケールがあります。大きなブーリアン、抽出、リメッシュ前にスケール適用すると反転や予期しない結果を減らせます。"))
        if getattr(obj, "use_dynamic_topology_sculpting", False):
            recommendations.append(_smart_utils.localize_bilingual_text("- Dyntopo is active. Prefer snapshots over shape-key layers, and retopo after heavy topology changes. / ダイナミックトポロジー有効中はシェイプレイヤーよりスナップショットを優先し、大きく形を変えた後はリトポを推奨します。"))
            if uv_layer_count or color_attribute_count or layer_info["has_face_sets"]:
                recommendations.append(_smart_utils.localize_bilingual_text("- Dyntopo can damage UV maps, color attributes, or face sets. Save a snapshot before continuing if those data layers matter. / ダイナミックトポロジーは UV、カラー属性、フェイスセットを壊す可能性があります。これらが重要なら続行前にスナップショットを保存してください。"))
        if multires is not None:
            recommendations.append(_smart_utils.localize_bilingual_text("- Multires is present. Prefer topology-preserving edits and avoid mixing it with Dyntopo. / マルチレゾ使用中はトポロジー維持型の編集を優先し、ダイナミックトポロジーとの併用は避けてください。"))
        if counts[2] > 500_000:
            recommendations.append(_smart_utils.localize_bilingual_text("- Heavy mesh detected. Consider Proxy Session, Voxel cleanup, or staged Multires work. / 高密度メッシュです。プロキシセッション、ボクセル整理、段階的なマルチレゾ運用を検討してください。"))
        if obj.data.users > 1:
            recommendations.append(_smart_utils.localize_bilingual_text("- Shared mesh datablock detected. Make it single-user before destructive edits. / 共有メッシュです。破壊的編集前にシングルユーザー化してください。"))
        if uv_layer_count == 0:
            recommendations.append(_smart_utils.localize_bilingual_text("- No UV map is present. Run Auto UV Project or unwrap manually before texture-oriented exchange, baking, or texturing. / UV マップがありません。テクスチャ用途の受け渡し・ベイク・テクスチャ作業前に 自動UV投影か手動 UV 展開を実行してください。"))
        if material_slot_count == 0:
            recommendations.append(_smart_utils.localize_bilingual_text("- No material slots are assigned. Material-based face-set splitting will only become useful after at least one material slot exists. / マテリアルスロットがありません。マテリアル基準のフェイスセット分割は、最低1つのスロットを用意してから使うと有効です。"))
        if selected_mesh_count > 1:
            recommendations.append(_smart_utils.localize_bilingual_text("- Multiple mesh parts are selected. For fast part switching use Prev/Next Part; for one sculptable aggregate use Sculpt Session. / 複数パーツが選択されています。素早い切り替えには前後のパーツへの移動、ひとつの造形対象にまとめたい場合はスカルプトセッションを使ってください。"))
        if not recommendations:
            recommendations.append(_smart_utils.localize_bilingual_text("- No urgent blocker was detected. Continue sculpting and re-run analysis before remesh, retopo, or export milestones. / 緊急の阻害要因は見つかりませんでした。リメッシュ・リトポ・書き出し前に再解析してください。"))

        lines = [
            _smart_utils.ui_text("Smart Sculpt - Diagnostic Report", "スマートスカルプト 診断レポート"),
            "=====================================",
            f"{_smart_utils.ui_text('Object', 'オブジェクト')}: {obj.name}",
            f"{_smart_utils.ui_text('Vertices', '頂点')}: {counts[0]:,}",
            f"{_smart_utils.ui_text('Edges', '辺')}: {counts[1]:,}",
            f"{_smart_utils.ui_text('Faces', '面')}: {counts[2]:,}",
            f"{_smart_utils.ui_text('Shared Mesh Users', 'メッシュの共有数')}: {getattr(obj.data, 'users', 0)}",
            f"{_smart_utils.ui_text('Dyntopo Enabled', 'ダイナミックトポロジー')}: {_report_yes_no(getattr(obj, 'use_dynamic_topology_sculpting', False))}",
            f"{_smart_utils.ui_text('Multires Present', 'マルチレゾ')}: {_report_yes_no(multires)}",
            f"{_smart_utils.ui_text('Shape Keys', 'シェイプキー')}: {shape_key_count}",
            f"{_smart_utils.ui_text('UV Maps', 'UV マップ')}: {uv_layer_count}",
            f"{_smart_utils.ui_text('Color Attributes', 'カラー属性')}: {color_attribute_count}",
            f"{_smart_utils.ui_text('Face Sets Present', 'フェイスセット')}: {_report_yes_no(layer_info['has_face_sets'])}",
            "",
            _smart_utils.localize_bilingual_text("Diagnostics / 診断"),
            "-------------------",
        ]

        if settings.diagnostics:
            for index, item in enumerate(settings.diagnostics, start=1):
                lines.append(f"{index}. [{_report_severity(item.severity)}] {item.title}")
                if item.detail:
                    lines.append(f"   {item.detail}")
        else:
            lines.append(_smart_utils.localize_bilingual_text("No diagnostics stored. Run Analyze Active Mesh first. / 診断がありません。先にアクティブメッシュの解析を実行してください。"))

        lines += ["", _smart_utils.localize_bilingual_text("Recommendations / 推奨アクション"), "------------------------------"]
        lines.extend(recommendations)
        lines += ["", _smart_utils.ui_text("Generated by Smart Sculpt.", "スマートスカルプトで作成しました。")]

        text_block = utils.write_text_block("SSS_DiagnosticReport", "\n".join(lines) + "\n")
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Diagnostic report written: {v0} / 診断レポートを書き出しました: {v1}', v0=text_block.name, v1=text_block.name))
        return {'FINISHED'}


classes = (
    SSS_OT_prepare_workspace,
    SSS_OT_toggle_silhouette,
    SSS_OT_set_viewport_preset,
    SSS_OT_prepare_multi_object_sculpt,
    SSS_OT_cycle_selected_mesh,
    SSS_OT_analyze_active_mesh,
    SSS_OT_fix_common_issues,
    SSS_OT_export_diagnostic_report,
)
