# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package


from . import loader as loader, registry as registry, navigation_properties, utils as _smart_utils
import hashlib
import importlib
import textwrap
from typing import Any

import bpy
from .. import rna_safety as _rna_safety


_REGISTERED_CLASSES: list[type] = []
_RECORDS_BY_ALIAS: dict[str, dict[str, Any]] = {}
_SUITE_RECORDS: dict[str, list[dict[str, Any]]] = {}
_NAV_MODULE_CACHE: dict[str, object] = {}

_ALWAYS_ON_OPERATOR_IDS = {'sculptnav.toggle'}
_ALWAYS_ON_PREF_PROP_IDS = {
    'canvas_navigation_enabled',
    'canvas_rmb_enabled',
    'double_click_focus_enabled',
    'show_border_overlay',
}


def _is_always_on_pref_prop(data, identifier: str) -> bool:
    identifier = str(identifier or '')
    if identifier not in _ALWAYS_ON_PREF_PROP_IDS:
        return False
    type_name = str(getattr(type(data), '__name__', '') or '').upper()
    return 'SCULPTNAV' in type_name or 'SCULPT_NAV' in type_name or 'SCULPT_NAVIGATION' in type_name


class _IdFactory:
    @staticmethod
    def token(*parts: object, size: int = 10) -> str:
        source = '||'.join(str(part or '') for part in parts)
        return hashlib.md5(source.encode('utf-8')).hexdigest()[: max(6, int(size))].upper()


ID_FACTORY = _IdFactory()




def _compact_npanel_layout(layout):
    """Keep integrated controls inside the N-panel width."""
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


def _help_button_row(layout):
    try:
        layout.separator(factor=0.35)
    except TypeError:
        try:
            layout.separator()
        except Exception:
            pass
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.alignment = 'RIGHT'
    except Exception:
        pass
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    return row


def _draw_help_button(layout, topic_id: str) -> bool:
    topic_id = str(topic_id or '').strip()
    if not topic_id:
        return False
    try:
        help_op = _help_button_row(layout).operator('smart_sculpt.open_help_popup', text='', icon='QUESTION')
        help_op.topic_id = topic_id
        return True
    except Exception:
        return False


def _localized_text(english: str, japanese: str) -> str:
    return _smart_utils.ui_text(english, japanese)


def _localized_format(english: str, japanese: str, **kwargs) -> str:
    template = _localized_text(english, japanese)
    try:
        return template.format(**kwargs)
    except Exception:
        return template


def _translated_iface(text: object) -> str:
    value = str(text or '')
    if not value:
        return ''
    try:
        translated = bpy.app.translations.pgettext_iface(value)
        return str(translated or value)
    except Exception:
        return value




def _rna_prop_label(data, prop_name: str) -> str:
    prop_name = str(prop_name or '').strip()
    if not prop_name:
        return ''
    try:
        props = getattr(getattr(data, 'bl_rna', None), 'properties', None)
        prop = None
        if props is not None:
            if hasattr(props, 'get'):
                prop = props.get(prop_name)
            else:
                try:
                    prop = props[prop_name]
                except Exception:
                    prop = None
        label = str(getattr(prop, 'name', '') or '').strip() if prop is not None else ''
        if label:
            return _translated_iface(label)
    except Exception:
        pass
    return prop_name.replace('_', ' ').strip().title()


def _draw_npanel_prop(layout, data, prop_name: str, *, text: str | None = None, **kwargs) -> bool:
    layout = _compact_npanel_layout(layout)
    prop_name = str(prop_name or '').strip()
    if data is None or not prop_name or not hasattr(data, prop_name):
        return False
    label = str(text if text is not None else _rna_prop_label(data, prop_name) or '').strip()
    control_kwargs = dict(kwargs or {})
    control_kwargs.pop('expand', None)
    col = _compact_npanel_layout(layout.column(align=True))
    if label:
        try:
            col.label(text=label)
        except Exception:
            pass
    try:
        row = _compact_npanel_layout(col.row(align=True))
        row.prop(data, prop_name, text='', **control_kwargs)
        return True
    except Exception as exc:
        try:
            col.label(text=_smart_utils.exception_ui_text(exc), icon='ERROR')
        except Exception:
            pass
        return False

def _draw_inline_feature_toggles(layout, context, alias: str) -> bool:
    try:
        draw_fn = getattr(navigation_properties, '_draw_inline_feature_toggles', None)
        if callable(draw_fn):
            return bool(draw_fn(layout, context, str(alias or '')))
    except Exception:
        pass
    return False


def _addon_help(spec: dict) -> str:
    return _localized_text(_addon_help_en(spec), _addon_help_ja(spec))


def _target_help(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    return _localized_text(
        _target_help_en(kind, label, desc, is_pie=is_pie),
        _target_help_ja(kind, label, desc, is_pie=is_pie),
    )


def _safe_register_class(cls: type) -> None:
    try:
        if _rna_safety.register_class(cls) and cls not in _REGISTERED_CLASSES:
            _REGISTERED_CLASSES.append(cls)
    except Exception:
        pass


def _safe_unregister_registered_classes() -> None:
    if _rna_safety.is_blender_exit_unregister_in_progress():
        _REGISTERED_CLASSES.clear()
        _RECORDS_BY_ALIAS.clear()
        _SUITE_RECORDS.clear()
        _NAV_MODULE_CACHE.clear()
        return
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            _rna_safety.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    _NAV_MODULE_CACHE.clear()


def _import_nav_module(module_name: str):
    cached = _NAV_MODULE_CACHE.get(module_name)
    if cached is not None:
        return cached
    mod = importlib.import_module(f'..{module_name}', __package__)
    _NAV_MODULE_CACHE[module_name] = mod
    return mod


def suite_is_active(context, suite_key: str) -> bool:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return False
    try:
        nav = _import_nav_module(module_name)
        fn = getattr(nav, 'is_active', None)
        if callable(fn):
            return bool(fn(context, suite_key))
    except Exception:
        pass
    return False


def suite_panel_context(suite_key: str) -> str:
    suite_key = str(suite_key or '').strip()
    module_name = registry.SUITE_META.get(suite_key, ('', ''))[1]
    if not module_name:
        return 'render'
    try:
        nav = _import_nav_module(module_name)
        value = getattr(nav, '_SMART_TOOLS_CONTEXT', 'RENDER')
        return str(value or 'RENDER').lower()
    except Exception:
        return 'render'


def refresh_all_suites(context=None) -> None:
    if context is None:
        context = getattr(bpy, 'context', None)
    for suite_key, (_suite_name, module_name) in registry.SUITE_META.items():
        try:
            nav = _import_nav_module(module_name)
            force_fn = getattr(nav, 'force_runtime_refresh', None)
            if callable(force_fn):
                force_fn()
        except Exception:
            pass
        try:
            nav = _import_nav_module(module_name)
            refresh_fn = getattr(nav, 'refresh_ui_runtime', None)
            if callable(refresh_fn):
                refresh_fn(context=context, addon_key=suite_key, activate_if_properties=False)
        except Exception:
            pass


def _wrap_lines(layout, text: str, width: int = 78, icon: str = 'NONE') -> None:
    text = str(text or '').strip()
    if not text:
        return
    lines = textwrap.wrap(text, width=max(24, int(width))) or [text]
    first = True
    for line in lines:
        if first:
            layout.label(text=line, icon=_smart_utils.safe_icon(icon))
            first = False
        else:
            layout.label(text=line)


def _status_text(record: dict) -> str:
    status = str(record.get('status') or '')
    if status == 'loaded':
        return _localized_text('Loaded', '読み込み済み')
    if status == 'ready':
        return _localized_text('Ready to load', '読み込み可能')
    if status == 'unsupported_platform':
        return _localized_text('Unsupported platform', '現在の OS・CPU では無効')
    if status == 'failed':
        return _localized_text('Load failed', '読み込み失敗')
    if status == 'disabled':
        return _localized_text('Superseded or deduplicated', '上位互換または重複のため統合対象外')
    if status == 'disabled_by_preference':
        return _localized_text('Disabled in N-panel Settings', 'Nパネル設定で無効')
    return status or _localized_text('Unknown', '不明')


def _addon_help_en(spec: dict) -> str:
    desc = str(spec.get('description') or spec.get('display_name') or '').strip()
    if desc:
        return (
            f'Function: {desc}. How to use: open the migrated child panels or use the quick buttons below. '
            f'Legacy side panels are hidden and the entry point is now inside Smart Sculpt.'
        )
    return (
        'Function: This add-on has been migrated into Smart Sculpt. How to use: open the migrated child panels or use '
        'the quick buttons below. Legacy side panels are hidden.'
    )


def _addon_help_ja(spec: dict) -> str:
    name = str(spec.get('display_name') or 'Integrated Add-on').strip()
    desc = str(spec.get('description') or '').strip()
    if desc:
        return (
            f'機能: {name} の元機能をスマートスカルプト内へ統合しています。内容: {desc}。使い方: 下のクイックボタン、'
            f'または子パネルを開いて必要な機能を使ってください。旧サイドバーや元パネルは非表示化されています。'
        )
    return (
        f'機能: {name} の元機能をスマートスカルプト内へ統合しています。使い方: 下のクイックボタン、または子パネルを開いて'
        f'必要な機能を使ってください。旧サイドバーや元パネルは非表示化されています。'
    )


def _target_help_en(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or 'Integrated Tool'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'pie menu' if is_pie else 'menu'
        return (
            f'Function: opens the migrated {label} {menu_kind} inside Smart Sculpt. '
            f'How to use: click this button, then choose a command from the opened menu.'
        )
    body = desc or label
    return (
        f'Function: {body}. How to use: click this button to run the migrated command inside Smart Sculpt. '
        f'Some tools may open additional dialogs or require a valid selection or mode.'
    )


def _target_help_ja(kind: str, label: str, desc: str, *, is_pie: bool = False) -> str:
    label = str(label or '').strip() or '統合ツール'
    desc = str(desc or '').strip()
    if kind == 'menu':
        menu_kind = 'パイメニュー' if is_pie else 'メニュー'
        return (
            f'機能: スマートスカルプト内で移植済みの {label} {menu_kind} を開きます。'
            f'使い方: このボタンを押して、表示されたメニューから目的の機能を選んでください。'
        )
    body = desc or label
    return (
        f'機能: {body}。使い方: このボタンを押すとスマートスカルプト内の移植コマンドを実行します。'
        f'機能によっては追加ダイアログが開く場合や、選択状態・モードが必要な場合があります。'
    )


def _trace_excerpt(text: str) -> str:
    for line in reversed(str(text or '').splitlines()):
        line = line.strip()
        if line:
            return line[:240]
    return ''


def _call_draw(draw_fn, panel_cls, layout, context) -> None:
    """Compatibility stub for older callers.

    The migrated UI no longer replays arbitrary Panel.draw methods through a
    fake panel instance.  Re-entering original panel draw code from another
    Panel.draw callback can produce access violations in Blender 5.x, so
    migrated tools are exposed through safe operator/menu buttons and explicit
    RNA property drawing instead.
    """
    del draw_fn, panel_cls, layout, context
    raise RuntimeError('Direct embedded Panel.draw execution is disabled for native N-panel safety.')


def _menu_entries(record: dict) -> list[tuple[str, str, bool]]:
    items = []
    seen = set()
    for cls in record.get('menus', ()) or ():
        menu_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not menu_id or menu_id in seen:
            continue
        seen.add(menu_id)
        label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or menu_id).strip()
        upper = f'{menu_id} {label} {getattr(cls, "__name__", "")}'.upper()
        is_pie = 'PIE' in upper
        items.append((menu_id, label or menu_id, is_pie))
    items.sort(key=lambda item: item[1].lower())
    return items


def _operator_entries(record: dict) -> list[tuple[str, str, str]]:
    items = []
    seen = set()
    for cls in record.get('operators', ()) or ():
        if bool(getattr(cls, '_smart_sculpt_internal_operator', False)):
            continue
        op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        if not op_id or op_id in seen or op_id in _ALWAYS_ON_OPERATOR_IDS:
            continue
        seen.add(op_id)
        label = str(getattr(cls, 'bl_label', '') or '').strip() or op_id
        desc = str(getattr(cls, 'bl_description', '') or '').strip()
        items.append((op_id, label, desc))
    items.sort(key=lambda item: (item[1].lower(), item[0].lower()))
    return items


def _quick_entries(record: dict, limit: int = 6) -> list[tuple[str, str, str, str, bool]]:
    quick: list[tuple[str, str, str, str, bool]] = []
    menu_limit = max(1, int(limit) // 2) if limit else 0
    for menu_id, label, is_pie in _menu_entries(record)[:menu_limit]:
        quick.append(('menu', menu_id, label, '', is_pie))
    remaining = max(0, int(limit) - len(quick))
    for op_id, label, desc in _operator_entries(record)[:remaining]:
        quick.append(('operator', op_id, label, desc, False))
    return quick


def _invoke_operator(layout, *, addon_alias: str, target_kind: str, target_id: str, label: str, desc: str = '', is_pie: bool = False) -> None:
    icon = 'PRESET' if target_kind == 'menu' and is_pie else ('DOWNARROW_HLT' if target_kind == 'menu' else 'TOOL_SETTINGS')
    display_label = _translated_iface(label)
    try:
        op = layout.operator(SMART_SCULPT_SUITE_211263_SMARTTOOLS_OT_integrated_invoke.bl_idname, text=display_label, icon=_smart_utils.safe_icon(icon))
        op.addon_alias = addon_alias
        op.target_kind = target_kind
        op.target_id = target_id
        op.target_label = label
        op.target_desc = desc
        op.is_pie_menu = bool(is_pie)
    except Exception:
        layout.label(text=display_label or label)


def _draw_tool_list(layout, record: dict, compact: bool = False) -> None:
    alias = str(record.get('spec', {}).get('alias') or '')
    menus = _menu_entries(record)
    operators = _operator_entries(record)
    if not menus and not operators:
        layout.label(
            text=_localized_text('No direct operator or menu entry was found.', '直接呼び出せるオペレーターやメニューが見つかりませんでした。'),
            icon='DOT',
        )
        return

    if menus:
        layout.label(text=_localized_text('Menus', 'メニュー'), icon='MENU_PANEL')
        col = _compact_npanel_layout(layout.column(align=True))
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)

    if operators:
        layout.label(text=_localized_text('Operators', 'オペレーター'), icon='TOOL_SETTINGS')
        flow = _compact_npanel_layout(layout.column(align=True))
        for op_id, label, desc in operators:
            _invoke_operator(flow, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)



_CATEGORY_KEYS = {'SCULPT', 'SURFACE', 'BUILD', 'SAFE', 'SETTINGS'}


def _normalize_category(category_key: object) -> str:
    category = str(category_key or '').strip().upper()
    return category if category in _CATEGORY_KEYS else 'SCULPT'


def _record_alias(record: dict) -> str:
    return str((record.get('spec') or {}).get('alias') or '').strip()


def _record_display_name(record: dict) -> str:
    spec = record.get('spec') or {}
    return _translated_iface(str(spec.get('display_name') or spec.get('alias') or ''))


def _record_icon(record: dict) -> str:
    alias = _record_alias(record)
    if alias == 'navigation':
        return 'ORIENTATION_VIEW'
    if alias == 'mask_facesets_tools':
        return 'MOD_MASK'
    return 'TOOL_SETTINGS'


def _text_blob(*parts: object) -> str:
    return ' '.join(str(part or '') for part in parts).lower()


def _generic_categories_from_text(text: str) -> set[str]:
    text = str(text or '').lower()
    categories: set[str] = set()
    if any(token in text for token in (
        'preference', 'preferences', 'setting', 'settings', 'shortcut', 'keymap', 'key binding',
        'language', 'capture key', 'hotkey', 'config', 'configuration', '設定', 'ショートカット', 'キー', '言語',
    )):
        categories.add('SETTINGS')
    if any(token in text for token in (
        'safe', 'safety', 'snapshot', 'backup', 'recover', 'recovery', 'restore', 'cleanup', 'clean up',
        'ignore', 'ignored', 'collection', 'visibility', 'hide', 'show', 'delete', '安全', '回復', '復元',
        '整理', '無視', 'コレクション', '表示', '非表示', '削除',
    )):
        categories.add('SAFE')
    if any(token in text for token in (
        'mask', 'face set', 'faceset', 'face-set', 'filter', 'mesh filter', 'cloth filter', 'surface',
        'remesh', 'multires', 'retopo', 'topology', 'uv', 'trim', 'slice', 'extract', 'smooth',
        'マスク', 'フェイスセット', 'フィルター', '表面', 'リメッシュ', 'リトポ', 'トポロジー', 'uv', '抽出', 'スライス',
    )):
        categories.add('SURFACE')
    if any(token in text for token in (
        'build', 'primitive', 'boolean', 'cutter', 'rail', 'tube', 'chain', 'scatter', 'bend', 'procedural',
        'generate', 'add ', 'create ', '造形', 'プリミティブ', 'ブーリアン', 'カッター', 'レール', 'チューブ',
        '散布', 'ベンド', 'プロシージャル', '作成',
    )):
        categories.add('BUILD')
    if not categories:
        categories.add('SCULPT')
    return categories


def _entry_categories(record: dict, *, kind: str, item_id: str, label: str, desc: str = '', is_pie: bool = False) -> set[str]:
    del kind, is_pie
    alias = _record_alias(record)
    text = _text_blob(alias, item_id, label, desc)
    if alias == 'navigation':
        if 'ignored_collection' in text or 'ignore' in text or 'focus_hud' in text:
            return {'SAFE'}
        return {'SCULPT'}
    if alias == 'mask_facesets_tools':
        if 'capture_key' in text or 'shortcut' in text or 'key' in text:
            return {'SETTINGS'}
        return {'SURFACE'}
    return _generic_categories_from_text(text)


def _panel_categories(record: dict, panel_cls: type | None = None, label: str = '') -> set[str]:
    alias = _record_alias(record)
    text = _text_blob(
        alias,
        label,
        getattr(panel_cls, 'bl_label', '') if panel_cls is not None else '',
        getattr(panel_cls, 'bl_idname', '') if panel_cls is not None else '',
        getattr(panel_cls, '__name__', '') if panel_cls is not None else '',
    )
    if alias == 'navigation' and ('ignored' in text or 'collection' in text):
        return {'SAFE'}
    if 'preference' in text or 'setting' in text:
        return {'SETTINGS'}
    return _generic_categories_from_text(text)


def _draw_record_header(layout, context, record: dict, *, icon: str | None = None) -> None:
    layout = _compact_npanel_layout(layout)
    display_name = _record_display_name(record)
    row = layout.row(align=True)
    _compact_npanel_layout(row)
    row.label(text=display_name, icon=_smart_utils.safe_icon(icon or _record_icon(record)))
    alias = _record_alias(record)
    _draw_help_button(row, f'integrated:{alias}')
    status = str(record.get('status') or '')
    if status and status != 'loaded':
        try:
            layout.label(text=_status_text(record), icon=_smart_utils.safe_icon('ERROR' if status == 'failed' else 'DOT'))
        except Exception:
            pass


def _draw_category_tools(layout, context, record: dict, category: str) -> bool:
    alias = _record_alias(record)
    menus = [
        item for item in _menu_entries(record)
        if category in _entry_categories(record, kind='menu', item_id=item[0], label=item[1], is_pie=item[2])
    ]
    operators = [
        item for item in _operator_entries(record)
        if category in _entry_categories(record, kind='operator', item_id=item[0], label=item[1], desc=item[2])
    ]
    if not menus and not operators:
        return False

    box = _compact_npanel_layout(layout.box())
    _draw_record_header(box, context, record)
    if menus:
        box.label(text=_localized_text('Menus', 'メニュー'), icon='MENU_PANEL')
        col = _compact_npanel_layout(box.column(align=True))
        for menu_id, label, is_pie in menus:
            _invoke_operator(col, addon_alias=alias, target_kind='menu', target_id=menu_id, label=label, is_pie=is_pie)

    if operators:
        box.label(text=_localized_text('Operators', 'オペレーター'), icon='TOOL_SETTINGS')
        col = _compact_npanel_layout(box.column(align=True))
        for op_id, label, desc in operators:
            _invoke_operator(col, addon_alias=alias, target_kind='operator', target_id=op_id, label=label, desc=desc)
    return True


def _custom_panel_specs(record: dict) -> list[tuple[str, object]]:
    alias = str((record.get('spec') or {}).get('alias') or '')
    if alias == 'navigation':
        return [(_localized_text('Ignored Collections', '無視コレクション'), _draw_navigation_ignored_collections_panel)]
    return []


def _draw_navigation_ignored_collections_panel(layout, context) -> None:
    layout = _smart_utils.localized_layout(layout)
    scene = getattr(context, 'scene', None)
    if scene is None or not hasattr(scene, 'sculptnav_ignored_collections'):
        layout.label(text=_localized_text('SculptNavigation data is not available.', 'スカルプトナビゲーションのデータが利用できません。'), icon='DOT')
        return

    row = layout.row()
    try:
        row.template_list(
            'SCULPTNAV_UL_ignored_collections', '',
            scene, 'sculptnav_ignored_collections',
            scene, 'sculptnav_ignored_collections_index',
            rows=3,
        )
    except Exception as exc:
        layout.label(text=f"{_localized_text('Ignored collection list draw failed', '無視コレクション一覧の描画に失敗しました')}: {_smart_utils.exception_ui_text(exc)}", icon='ERROR')
        return

    col = row.column(align=True)
    try:
        col.operator('sculptnav.ignored_collection_add', icon='ADD', text='')
        col.operator('sculptnav.ignored_collection_remove', icon='REMOVE', text='')
    except Exception:
        pass

    collections = getattr(scene, 'sculptnav_ignored_collections', None)
    if collections:
        try:
            idx = int(getattr(scene, 'sculptnav_ignored_collections_index', 0) or 0)
            if 0 <= idx < len(collections):
                item = collections[idx]
                _draw_npanel_prop(layout, item, 'collection')
        except Exception:
            pass


def _draw_category_panels(layout, context, record: dict, category: str) -> bool:
    """Draw only Smart Sculpt-owned safe custom panels.

    Captured panels from migrated add-ons are still hidden from their original
    locations, but their draw methods are not executed inside the Smart Sculpt
    N-panel.  The actual callable functionality remains available through
    _draw_category_tools(), and settings are shown through RNA property lists.
    """
    drawn = False
    for offset, (label, draw_callback) in enumerate(_custom_panel_specs(record), start=1):
        del offset
        if category not in _panel_categories(record, label=label):
            continue
        box = layout.box()
        _draw_record_header(box, context, record)
        sub = box.box()
        sub.label(text=_translated_iface(label), icon='OUTLINER_COLLECTION')
        try:
            draw_callback(sub, context)
        except Exception as exc:
            sub.label(text=f"{_localized_text('Custom panel draw failed', 'カスタムパネル描画に失敗しました')}: {_smart_utils.exception_ui_text(exc)}", icon='ERROR')
        drawn = True
    return drawn


def _draw_category_settings(layout, context, record: dict, category: str) -> bool:
    if category != 'SETTINGS':
        return False
    drawn = False
    if _draw_category_tools(layout, context, record, category):
        drawn = True
    prefs_available = False
    try:
        prefs_available = _find_record_preferences(record, context) is not None
    except Exception:
        prefs_available = False
    if prefs_available:
        box = layout.box()
        _draw_record_header(box, context, record, icon='PREFERENCES')
        _draw_preference_proxy(box, context, record)
        drawn = True
    return drawn




def _record_default_categories(record: dict) -> set[str]:
    spec = record.get('spec') or {}
    alias = str(spec.get('alias') or spec.get('package_name') or '').lower()
    name_blob = ' '.join(str(spec.get(key) or '') for key in ('display_name', 'alias', 'package_name', 'description')).lower()
    if alias == 'navigation' or 'navigation' in name_blob:
        return {'SCULPT', 'SAFE', 'SETTINGS'}
    if alias == 'mask_facesets_tools' or 'mask' in name_blob or 'faceset' in name_blob or 'face set' in name_blob:
        return {'SURFACE', 'SETTINGS'}
    if any(word in name_blob for word in ('build', 'primitive', 'boolean', 'mesh')):
        return {'BUILD', 'SETTINGS'}
    if any(word in name_blob for word in ('safe', 'backup', 'ignore', 'collection')):
        return {'SAFE', 'SETTINGS'}
    return {'SCULPT', 'SETTINGS'}


def _draw_lazy_record(layout, context, record: dict, category: str) -> bool:
    if category not in _record_default_categories(record):
        return False
    spec = record.get('spec') or {}
    status = str(record.get('status') or '')
    box = _compact_npanel_layout(layout.box())
    _draw_record_header(box, context, record, icon='PLUGIN')
    row = box.column(align=True)
    _compact_npanel_layout(row)
    if status in {'ready', 'failed'}:
        text = _localized_text('Load', '読み込み') if status == 'ready' else _localized_text('Retry Load', '再読み込み')
        try:
            op = row.operator('core.load_integrated_tool', text=text, icon='FILE_REFRESH')
            op.addon_alias = str(spec.get('alias') or spec.get('package_name') or '')
            op.force_reload = status == 'failed'
        except Exception:
            row.label(text=text, icon='FILE_REFRESH')
        row.label(text=_localized_text('UI only. Runtime is not loaded yet.', 'UIのみ表示中。ランタイムは未読み込みです。'), icon='DOT')
    elif status == 'unsupported_platform':
        row.enabled = False
        row.label(text=_localized_text('Unsupported on this platform.', 'このプラットフォームでは未対応です。'), icon='ERROR')
    elif status == 'disabled':
        row.enabled = False
        row.label(text=_localized_text('This integrated tool is disabled.', 'この統合ツールは無効です。'), icon='DOT')
    else:
        row.enabled = False
        row.label(text=f"{_localized_text('Status', '状態')}: {_status_text(record)}", icon='DOT')
    if status == 'failed':
        err = str(record.get('error') or '').strip().splitlines()[0:1]
        if err:
            box.label(text=_smart_utils.exception_ui_text(err[0])[:240], icon='ERROR')
    return True

def draw_category_contents(layout, context, category_key: object) -> bool:
    """Draw migrated add-on controls inside the main five Smart Sculpt categories."""
    layout = _compact_npanel_layout(_smart_utils.localized_layout(layout))
    category = _normalize_category(category_key)
    try:
        if not _RECORDS_BY_ALIAS and loader.get_records():
            _collect_records()
    except Exception:
        pass
    drawn = False
    for record in loader.get_records():
        status = str(record.get('status') or '')
        if status == 'disabled_by_preference':
            continue
        if status in {'ready', 'failed', 'unsupported_platform', 'disabled'}:
            if _draw_lazy_record(layout, context, record, category):
                drawn = True
            if category == 'SETTINGS' and status in {'ready', 'failed'}:
                if _draw_category_settings(layout, context, record, category):
                    drawn = True
            continue
        if category == 'SETTINGS':
            if _draw_category_settings(layout, context, record, category):
                drawn = True
            continue
        if _draw_category_panels(layout, context, record, category):
            drawn = True
        if _draw_category_tools(layout, context, record, category):
            drawn = True
    return drawn


def _resolve_operator_callable(op_id: str):
    op_id = str(op_id or '').strip()
    if '.' not in op_id:
        return None
    head, tail = op_id.split('.', 1)
    group = getattr(bpy.ops, head, None)
    if group is None:
        return None
    return getattr(group, tail, None)


def _find_record_preferences(record: dict, context=None):
    context = context or getattr(bpy, 'context', None)
    spec = record.get('spec') or {}
    alias = str(spec.get('alias') or '').strip()
    if not alias:
        return None
    try:
        prefs_module = importlib.import_module(f'{loader._root_module_prefix()}.preferences')
    except Exception:
        return None
    try:
        finder = getattr(prefs_module, 'find_tool_settings', None)
        settings = finder(alias, context=context) if callable(finder) else None
    except Exception:
        settings = None
    return settings


_LAYOUT_ATTR_MISSING = object()


class _InjectedLayoutDescriptor:
    def __init__(self, layout):
        self._layout = layout

    def __get__(self, _obj, _objtype=None):
        return self._layout


def _call_preferences_draw(draw_fn, prefs_instance, layout, context) -> None:
    """Compatibility stub; direct AddonPreferences.draw replay is disabled."""
    del draw_fn, prefs_instance, layout, context
    raise RuntimeError('Direct preference draw execution is disabled for native N-panel safety.')


def _iter_drawable_rna_properties(data):
    if data is None:
        return
    try:
        props = tuple(getattr(getattr(data, 'bl_rna', None), 'properties', ()) or ())
    except Exception:
        props = ()
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
        except Exception:
            continue
        if not identifier or identifier == 'rna_type' or identifier.startswith('_'):
            continue
        if _is_always_on_pref_prop(data, identifier):
            continue
        try:
            if bool(getattr(prop, 'is_hidden', False)) or bool(getattr(prop, 'is_readonly', False)):
                continue
        except Exception:
            pass
        if hasattr(data, identifier):
            yield identifier, prop


def _draw_rna_settings(layout, data, *, columns: int = 1) -> bool:
    del columns
    layout = _compact_npanel_layout(layout)
    props = list(_iter_drawable_rna_properties(data) or ())
    if not props:
        return False
    flow = _compact_npanel_layout(layout.column(align=True))
    drawn = False
    for identifier, prop in props:
        try:
            _draw_npanel_prop(flow, data, identifier)
            drawn = True
        except Exception:
            try:
                label = str(getattr(prop, 'name', '') or identifier)
                row = flow.row(align=True)
                row.enabled = False
                row.label(
                    text=_localized_text(
                        f'{label}: managed internally',
                        f'{label}: 内部管理項目です',
                    ),
                    icon='DOT',
                )
            except Exception:
                pass
    return drawn


def _preference_drawables(record: dict) -> list[type]:
    items: list[type] = []
    seen = set()
    for cls in record.get('preferences', ()) or ():
        if not isinstance(cls, type) or cls in seen:
            continue
        seen.add(cls)
        items.append(cls)
    return items


def _draw_preference_proxy(layout, context, record: dict) -> None:
    prefs_instance = _find_record_preferences(record, context)
    if prefs_instance is None:
        layout.label(text=_localized_text('Preferences data is not available for this integrated add-on.', 'この統合アドオンの設定データを取得できません。'), icon='DOT')
        return
    try:
        if _draw_rna_settings(layout, prefs_instance, columns=1):
            return
    except Exception as exc:
        layout.label(text=f"{_localized_text('Preferences draw failed', '設定描画に失敗しました')}: {_smart_utils.exception_ui_text(exc)}", icon='ERROR')
        return
    layout.label(text=_localized_text('This integrated add-on does not expose additional editable preferences.', 'この統合アドオンには追加で編集できる設定がありません。'), icon='DOT')


class SMART_SCULPT_SUITE_211263_SMARTTOOLS_OT_integrated_addon_info(bpy.types.Operator):
    bl_idname = 'core.integrated_addon_info'
    bl_label = 'Integrated Add-on Info'
    bl_options = {'UNDO', 'INTERNAL'}

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        alias = str(getattr(properties, 'addon_alias', '') or '')
        record = loader.get_record(alias) or {}
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record) if isinstance(record, dict) else _localized_text('Unknown', '不明')
        note = str(spec.get('note') or '').strip()
        lines = [
            f"{spec.get('display_name', alias)}",
            _addon_help(spec),
            _localized_format('Status: {status}', '状態: {status}', status=status),
        ]
        if note:
            lines.append(_localized_format('Note: {note}', '注記: {note}', note=note))
        return ' '.join(str(line) for line in lines if line)

    def execute(self, _context):
        alias = str(self.addon_alias or '')
        record = loader.get_record(alias) or {}
        spec = record.get('spec', {}) if isinstance(record, dict) else {}
        status = _status_text(record) if isinstance(record, dict) else _localized_text('Unknown', '不明')
        self.report({'INFO'}, f"{_translated_iface(spec.get('display_name', alias))} - {status}")
        return {'FINISHED'}


class SMART_SCULPT_SUITE_211263_SMARTTOOLS_OT_integrated_invoke(bpy.types.Operator):
    bl_idname = 'core.integrated_invoke'
    bl_label = 'Integrated Tool'
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    addon_alias: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_kind: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_id: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_label: bpy.props.StringProperty(options={'SKIP_SAVE'})
    target_desc: bpy.props.StringProperty(options={'SKIP_SAVE'})
    is_pie_menu: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, _context, properties):
        kind = str(getattr(properties, 'target_kind', '') or '')
        label = str(getattr(properties, 'target_label', '') or '')
        desc = str(getattr(properties, 'target_desc', '') or '')
        is_pie = bool(getattr(properties, 'is_pie_menu', False))
        return _target_help(kind, label, desc, is_pie=is_pie)

    def execute(self, _context):
        kind = str(self.target_kind or '').strip()
        target_id = str(self.target_id or '').strip()
        if not target_id:
            self.report({'WARNING'}, _localized_text(
                'No integrated tool command was selected.',
                '統合ツールのコマンドが選択されていません。',
            ))
            return {'CANCELLED'}
        if kind == 'menu':
            label = str(self.target_label or target_id or '')
            try:
                if self.is_pie_menu:
                    proxy_id = str(navigation_properties.popup_menu_pie_proxy_operator_id() or '')
                    proxy_callable = _resolve_operator_callable(proxy_id)
                    if callable(proxy_callable):
                        result = proxy_callable('INVOKE_DEFAULT', menu_idname=target_id, popup_label=label)
                        if isinstance(result, set):
                            return result
                        return {'FINISHED'}
                    return bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name=target_id)
                proxy_id = str(navigation_properties.popup_menu_operator_id() or '')
                proxy_callable = _resolve_operator_callable(proxy_id)
                if callable(proxy_callable):
                    result = proxy_callable('INVOKE_DEFAULT', menu_idname=target_id, popup_label=label)
                    if isinstance(result, set):
                        return result
                    return {'FINISHED'}
                return bpy.ops.wm.call_menu('INVOKE_DEFAULT', name=target_id)
            except Exception as exc:
                self.report({'ERROR'}, _localized_format('Menu invoke failed ({error})', 'メニュー呼び出しに失敗しました ({error})', error=_smart_utils.exception_ui_text(exc)))
                return {'CANCELLED'}

        op_callable = _resolve_operator_callable(target_id)
        if not callable(op_callable):
            self.report({'ERROR'}, _localized_text('This command is not available.', 'このコマンドを利用できません。'))
            return {'CANCELLED'}

        last_error = None
        for args in (('INVOKE_DEFAULT',), tuple()):
            try:
                result = op_callable(*args)
                if isinstance(result, set):
                    return result
                return {'FINISHED'}
            except Exception as exc:
                last_error = exc
        self.report({'ERROR'}, _localized_format('The command failed ({error})', 'コマンドを実行できませんでした ({error})', error=_smart_utils.exception_ui_text(last_error)))
        return {'CANCELLED'}




class SMART_SCULPT_SUITE_OT_load_integrated_tool(bpy.types.Operator):
    bl_idname = 'core.load_integrated_tool'
    bl_label = 'Load Integrated Tool'
    bl_description = 'Load this integrated tool only when needed, then display its available operations and settings in the Smart Sculpt N-panel.'
    bl_options = {'UNDO'}

    addon_alias: bpy.props.StringProperty(default='', options={'SKIP_SAVE'})
    force_reload: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        del cls, context, properties
        return _localized_text(
            'Load this integrated tool only when needed. This keeps Blender startup light while preserving access to the tool from the Smart Sculpt N-panel.',
            'この統合ツールを必要な時だけ読み込みます。Blender 起動を軽く保ちながら、スマートスカルプト Nパネルからツールを使用できます。',
        )

    def execute(self, context):
        alias = str(getattr(self, 'addon_alias', '') or '').strip()
        if not alias:
            self.report({'WARNING'}, _localized_text('No integrated tool was selected.', '統合ツールが選択されていません。'))
            return {'CANCELLED'}
        try:
            record = loader.load_alias(alias, force=bool(getattr(self, 'force_reload', False)))
            _collect_records()
        except Exception as exc:
            self.report({'ERROR'}, f"{_localized_text('Integrated tool load failed', '統合ツールの読み込みに失敗しました')}: {_smart_utils.exception_ui_text(exc)}")
            return {'CANCELLED'}
        if not record or str(record.get('status') or '') != 'loaded':
            error = str((record or {}).get('error') or '').strip()
            self.report({'WARNING'}, _smart_utils.exception_ui_text(error) if error else _localized_text('The integrated tool is not available.', '統合ツールを利用できません。'))
            return {'CANCELLED'}
        try:
            for area in getattr(getattr(context, 'screen', None), 'areas', ()):
                area.tag_redraw()
        except Exception:
            pass
        self.report({'INFO'}, _localized_text('Integrated tool loaded.', '統合ツールを読み込みました。'))
        return {'FINISHED'}

# Integrated controls are drawn inline by Smart Sculpt's native N-panel categories.
# No auxiliary N-panel classes are generated here.

def _collect_records() -> None:
    _RECORDS_BY_ALIAS.clear()
    _SUITE_RECORDS.clear()
    for record in loader.get_records():
        if str(record.get('status') or '') == 'disabled_by_preference':
            continue
        spec = record.get('spec') or {}
        alias = str(spec.get('alias') or '')
        suite_key = str(spec.get('suite') or '')
        if alias:
            _RECORDS_BY_ALIAS[alias] = record
        if suite_key:
            _SUITE_RECORDS.setdefault(suite_key, []).append(record)


def register() -> None:
    _safe_unregister_registered_classes()
    _collect_records()
    for cls in (
        SMART_SCULPT_SUITE_211263_SMARTTOOLS_OT_integrated_addon_info,
        SMART_SCULPT_SUITE_211263_SMARTTOOLS_OT_integrated_invoke,
        SMART_SCULPT_SUITE_OT_load_integrated_tool,
    ):
        if _rna_safety.register_class(cls):
            _REGISTERED_CLASSES.append(cls)
    # Migrated controls are drawn by Smart Sculpt's main
    # Sculpt / Surface / Build / Safe / Settings categories via draw_category_contents().
    try:
        refresh_all_suites(getattr(bpy, 'context', None))
    except Exception:
        pass


def unregister() -> None:
    _safe_unregister_registered_classes()
    _NAV_MODULE_CACHE.clear()
