# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


from __future__ import annotations

from . import utils, utils as _smart_utils
import bpy
from bpy.types import Operator



def _active_non_basis_key(obj: bpy.types.Object | None):
    if obj is None or obj.type != 'MESH' or obj.data.shape_keys is None:
        return None
    index = getattr(obj, 'active_shape_key_index', 0)
    if index <= 0 or index >= len(obj.data.shape_keys.key_blocks):
        return None
    return obj.data.shape_keys.key_blocks[index]


def _preview_object_name(obj: bpy.types.Object | None) -> str:
    if obj is None:
        return ""
    try:
        return str(obj.get("sss_snapshot_preview", "") or "")
    except Exception:
        return ""


def _preview_object(obj: bpy.types.Object | None):
    name = _preview_object_name(obj)
    return bpy.data.objects.get(name) if name else None


def _clear_snapshot_preview(obj: bpy.types.Object | None) -> bool:
    preview = _preview_object(obj)
    removed = False
    if preview is not None and utils.generated_is_owned(preview, 'snapshot_preview'):
        removed = utils.safe_delete_object(preview, require_owned=True)
    # Never erase a user/foreign reference merely because it resembles Suite data.
    if obj is not None and (removed or preview is None):
        try:
            if "sss_snapshot_preview" in obj:
                del obj["sss_snapshot_preview"]
        except Exception:
            pass
    return removed


def _restore_session_sources_from_object(obj: bpy.types.Object | None) -> tuple[list[str], int, int]:
    return utils.restore_session_sources_from_object(obj)


def _session_source_objects(names: list[str]) -> list[bpy.types.Object]:
    result: list[bpy.types.Object] = []
    for name in names:
        source = bpy.data.objects.get(name)
        if source is not None:
            result.append(source)
    return result


def _select_session_sources(context, names: list[str]) -> int:
    objects = _session_source_objects(names)
    if not objects:
        return 0
    utils.select_only(context, objects, active=objects[0])
    return len(objects)



def _cleanup_failed_session(context, session_obj: bpy.types.Object | None, source_names: list[str]) -> int:
    if session_obj is not None:
        try:
            utils.ensure_object_mode(context, session_obj)
        except Exception:
            pass
        utils.safe_delete_object(session_obj, require_owned=True)
    return _select_session_sources(context, source_names) if source_names else 0


class SSS_OT_save_snapshot(Operator):
    bl_idname = "smart_sculpt.save_snapshot"
    bl_label = "Save Snapshot"
    bl_description = _smart_utils.localize_bilingual_text((
        "Store a hidden topology-safe snapshot of the current mesh so you can restore it later, even when shape keys are not usable. "
        "/ シェイプキーが使えない状況でも後から戻せるよう、現在のメッシュをトポロジー安全な隠しスナップショットとして保存します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        collection = utils.snapshot_collection(context.scene)
        snapshot_obj = utils.duplicate_object_data(obj, collection, name=f"{obj.name}_snapshot", kind='snapshot')
        snapshot_obj.hide_set(True)
        snapshot_obj.hide_render = True
        try:
            snapshot_obj["sss_snapshot_source"] = obj.name
        except Exception:
            pass

        item = obj.smart_sculpt_snapshots.add()
        item.name = snapshot_obj.name
        item.object_name = snapshot_obj.name
        item.vertex_count = len(snapshot_obj.data.vertices)
        item.edge_count = len(snapshot_obj.data.edges)
        item.polygon_count = len(snapshot_obj.data.polygons)
        item.modifier_count = len(snapshot_obj.modifiers)
        shape_keys = getattr(snapshot_obj.data, "shape_keys", None)
        item.shape_key_count = len(shape_keys.key_blocks) if shape_keys else 0
        obj.smart_sculpt_snapshot_index = len(obj.smart_sculpt_snapshots) - 1

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Snapshot saved. / スナップショットを保存しました。"))
        return {'FINISHED'}


class SSS_OT_restore_snapshot(Operator):
    bl_idname = "smart_sculpt.restore_snapshot"
    bl_label = "Restore Snapshot"
    bl_description = _smart_utils.localize_bilingual_text((
        "Replace the active mesh data with the selected hidden snapshot. This is safer than a destructive undo chain for long sculpt sessions. "
        "/ 選択中の隠しスナップショットでアクティブメッシュを置き換えます。長いスカルプト作業で破壊的な元に戻す操作に頼り切るより安全です。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None or not obj.smart_sculpt_snapshots:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No snapshot available. / 利用可能なスナップショットがありません。"))
            return {'CANCELLED'}

        index = max(0, min(obj.smart_sculpt_snapshot_index, len(obj.smart_sculpt_snapshots) - 1))
        item = obj.smart_sculpt_snapshots[index]
        snapshot_obj = bpy.data.objects.get(item.object_name)
        if snapshot_obj is None or snapshot_obj.type != 'MESH':
            try:
                obj.smart_sculpt_snapshots.remove(index)
                obj.smart_sculpt_snapshot_index = max(0, min(index, len(obj.smart_sculpt_snapshots) - 1))
            except Exception:
                pass
            _clear_snapshot_preview(obj)
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Snapshot object is missing and was removed from the list. / スナップショットオブジェクトが見つからなかったため、一覧からも除去しました。"))
            return {'CANCELLED'}

        original_mode = getattr(obj, 'mode', 'OBJECT')
        original_visibility = utils.capture_object_visibility_state(obj)
        utils.ensure_object_mode(context, obj)
        old_mesh = obj.data
        obj.data = snapshot_obj.data.copy()
        utils.remove_orphan_data(old_mesh)
        try:
            utils.restore_vertex_groups_from_object(obj, snapshot_obj)
            utils.restore_modifiers_from_object(obj, snapshot_obj)
            utils.restore_object_display_settings(obj, snapshot_obj)
        except Exception:
            pass
        _clear_snapshot_preview(obj)
        utils.restore_object_visibility_state(obj, original_visibility)
        if original_mode == 'SCULPT':
            utils.ensure_sculpt_mode(context, obj)
        elif original_mode == 'EDIT':
            utils.ensure_edit_mode(context, obj)

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Snapshot restored. / スナップショットを復元しました。"))
        return {'FINISHED'}


class SSS_OT_preview_snapshot(Operator):
    bl_idname = "smart_sculpt.preview_snapshot"
    bl_label = "Preview Snapshot"
    bl_description = _smart_utils.localize_bilingual_text((
        "Create a visible wireframe compare object from the selected hidden snapshot so you can inspect differences before restoring it. "
        "This approximates non-destructive before/after comparison workflows from layer-driven sculpt tools. "
        "/ 選択中の隠しスナップショットから可視ワイヤーフレーム比較オブジェクトを作成し、復元前に差分を確認できるようにします。"
        "レイヤー駆動型スカルプトツールの非破壊の前後比較ワークフローを近似します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None or not obj.smart_sculpt_snapshots:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No snapshot available. / 利用可能なスナップショットがありません。"))
            return {'CANCELLED'}

        index = max(0, min(obj.smart_sculpt_snapshot_index, len(obj.smart_sculpt_snapshots) - 1))
        item = obj.smart_sculpt_snapshots[index]
        snapshot_obj = bpy.data.objects.get(item.object_name)
        if snapshot_obj is None or snapshot_obj.type != 'MESH':
            _clear_snapshot_preview(obj)
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Selected snapshot could not be found. / 選択中のスナップショットが見つかりません。"))
            return {'CANCELLED'}

        _clear_snapshot_preview(obj)
        collection = utils.helper_collection(context.scene)
        preview_mesh = snapshot_obj.data.copy()
        preview = bpy.data.objects.new(utils.unique_name(f"{obj.name}_snapshot_preview"), preview_mesh)
        collection.objects.link(preview)
        utils.mark_generated(preview, 'snapshot_preview')
        try:
            preview.matrix_world = snapshot_obj.matrix_world.copy()
        except Exception:
            preview.matrix_world = obj.matrix_world.copy()
        preview.display_type = 'WIRE'
        preview.show_in_front = True
        preview.hide_render = True
        preview.hide_select = True
        try:
            preview.color = (1.0, 0.6, 0.1, 1.0)
        except Exception:
            pass
        try:
            preview["sss_snapshot_preview_of"] = obj.name
            preview["sss_snapshot_object"] = snapshot_obj.name
        except Exception:
            pass
        try:
            obj["sss_snapshot_preview"] = preview.name
        except Exception:
            pass

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Snapshot preview created. / スナップショット比較プレビューを作成しました。"))
        return {'FINISHED'}


class SSS_OT_clear_snapshot_preview(Operator):
    bl_idname = "smart_sculpt.clear_snapshot_preview"
    bl_label = "Clear Snapshot Preview"
    bl_description = _smart_utils.localize_bilingual_text((
        "Remove the current visible snapshot compare object and return to the normal sculpt view. "
        "/ 現在表示されているスナップショット比較オブジェクトを削除し、通常のスカルプト表示へ戻します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context) or context.view_layer.objects.active
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active object. / アクティブオブジェクトがありません。"))
            return {'CANCELLED'}

        owner = obj
        if utils.generated_is_owned(obj, 'snapshot_preview'):
            owner_name = str(obj.get("sss_snapshot_preview_of", "") or "")
            owner = bpy.data.objects.get(owner_name) or obj

        removed = _clear_snapshot_preview(owner)
        if not removed:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("No snapshot preview was active. / 有効なスナップショットプレビューはありませんでした。"))
            return {'FINISHED'}
        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Snapshot preview cleared. / スナップショット比較プレビューを解除しました。"))
        return {'FINISHED'}


class SSS_OT_delete_snapshot(Operator):
    bl_idname = "smart_sculpt.delete_snapshot"
    bl_label = "Delete Snapshot"
    bl_description = _smart_utils.localize_bilingual_text((
        "Delete the selected hidden snapshot to keep the file clean and lightweight. "
        "/ 選択中の隠しスナップショットを削除し、ファイルを整理して軽量に保ちます。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None or not obj.smart_sculpt_snapshots:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No snapshot available. / 利用可能なスナップショットがありません。"))
            return {'CANCELLED'}

        index = max(0, min(obj.smart_sculpt_snapshot_index, len(obj.smart_sculpt_snapshots) - 1))
        item = obj.smart_sculpt_snapshots[index]
        preview = _preview_object(obj)
        if preview is not None and preview.get("sss_snapshot_object") == item.object_name:
            _clear_snapshot_preview(obj)
        snapshot_obj = bpy.data.objects.get(item.object_name)
        if snapshot_obj is not None:
            utils.safe_delete_object(snapshot_obj)
        obj.smart_sculpt_snapshots.remove(index)
        obj.smart_sculpt_snapshot_index = max(0, min(index, len(obj.smart_sculpt_snapshots) - 1))

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Snapshot deleted. / スナップショットを削除しました。"))
        return {'FINISHED'}



class SSS_OT_restore_recovery_backup(Operator):
    bl_idname = "smart_sculpt.restore_recovery_backup"
    bl_label = "Restore Recovery Backup"
    bl_description = _smart_utils.localize_bilingual_text((
        "Restore the latest hidden recovery backup for the active object. These backups are created automatically before destructive remesh, boolean, fix, UV overwrite, and slice operations when the recovery option is enabled. "
        "/ アクティブオブジェクト用の最新の隠し回復バックアップを復元します。回復オプションが有効な場合、破壊的なリメッシュ、ブーリアン、修復、UV 上書き、スライス処理の前に自動作成されます。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context) or context.view_layer.objects.active
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh object. / アクティブなメッシュオブジェクトがありません。"))
            return {'CANCELLED'}

        restored, reason = utils.restore_recovery_backup_into_object(context, obj)
        if not restored:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No valid recovery backup was found. / 有効な回復バックアップが見つかりませんでした。"))
            return {'CANCELLED'}

        if reason:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Recovery backup restored ({v0}). / 回復バックアップを復元しました ({v1})。', v0=reason, v1=reason))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Recovery backup restored. / 回復バックアップを復元しました。"))
        return {'FINISHED'}


class SSS_OT_clear_recovery_backup(Operator):
    bl_idname = "smart_sculpt.clear_recovery_backup"
    bl_label = "Clear Recovery Backup"
    bl_description = _smart_utils.localize_bilingual_text((
        "Delete the hidden recovery backup stored for the active object to keep the file lighter once you are happy with the current result. "
        "/ 現在の結果で問題ない場合に、アクティブオブジェクト用の隠し回復バックアップを削除してファイルを軽く保ちます。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context) or context.view_layer.objects.active
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh object. / アクティブなメッシュオブジェクトがありません。"))
            return {'CANCELLED'}

        removed = utils.delete_recovery_backup_object(obj)
        if not removed:
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("No recovery backup needed clearing. / 削除が必要な回復バックアップはありませんでした。"))
            return {'FINISHED'}
        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Recovery backup cleared. / 回復バックアップを削除しました。"))
        return {'FINISHED'}


class SSS_OT_create_shape_layer(Operator):
    bl_idname = "smart_sculpt.create_shape_layer"
    bl_label = "Create Shape Layer"
    bl_description = _smart_utils.localize_bilingual_text((
        'Create a shape-key based sculpt layer from the current result. If Dyntopo is active, the operator safely falls back to snapshot storage. / 現在の結果からシェイプキー型スカルプレイヤーを作成します。ダイナミックトポロジーが有効な場合は安全のためスナップショット保存へフォールバックします。'
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}

        if getattr(obj, 'use_dynamic_topology_sculpting', False):
            try:
                utils.safe_operator_call(bpy.ops.smart_sculpt.save_snapshot)
            except Exception as exc:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not save a fallback snapshot: {v0} / フォールバック用スナップショットを保存できませんでした: {v1}', v0=exc, v1=exc))
                return {'CANCELLED'}
            self.report({'INFO'}, _smart_utils.localize_bilingual_text("Dyntopo is active, so a snapshot was saved instead of a shape layer. / ダイナミックトポロジーが有効なため、シェイプレイヤーの代わりにスナップショットを保存しました。"))
            return {'FINISHED'}

        original_mode = getattr(obj, 'mode', 'OBJECT')
        utils.ensure_object_mode(context, obj)
        utils.ensure_single_user_mesh(obj)
        try:
            if obj.data.shape_keys is None:
                obj.shape_key_add(name="Basis", from_mix=False)
            layer_name = utils.unique_name("SSS_Layer")
            key = obj.shape_key_add(name=layer_name, from_mix=True)
            key.value = 1.0
            if obj.data.shape_keys:
                obj.active_shape_key_index = len(obj.data.shape_keys.key_blocks) - 1
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not create shape layer: {v0} / シェイプレイヤーを作成できませんでした: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        finally:
            if original_mode == 'SCULPT':
                utils.ensure_sculpt_mode(context, obj)
            elif original_mode == 'EDIT':
                utils.ensure_edit_mode(context, obj)

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Shape layer created. / シェイプレイヤーを作成しました。"))
        return {'FINISHED'}


class SSS_OT_duplicate_active_shape_layer(Operator):
    bl_idname = "smart_sculpt.duplicate_active_shape_layer"
    bl_label = "Duplicate Active Shape Layer"
    bl_description = _smart_utils.localize_bilingual_text((
        "Duplicate the active non-basis sculpt layer while preserving the current visible result. "
        "/ 現在の見た目を壊さずに、アクティブな基準キー以外のスカルプレイヤーを複製します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        key = _active_non_basis_key(obj)
        if obj is None or key is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select a non-basis shape layer first. / 先に基準キー以外のシェイプレイヤーを選択してください。"))
            return {'CANCELLED'}

        original_mode = getattr(obj, 'mode', 'OBJECT')
        utils.ensure_object_mode(context, obj)
        keys = obj.data.shape_keys.key_blocks
        stored_values = [k.value for k in keys]
        try:
            for k in keys:
                k.value = 1.0 if k == key else 0.0
            obj.shape_key_add(name=utils.unique_name(f"{key.name}_copy"), from_mix=True)
            obj.active_shape_key_index = len(keys) - 1
            keys[-1].value = 0.0
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not duplicate shape layer: {v0} / シェイプレイヤーを複製できませんでした: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        finally:
            for idx, value in enumerate(stored_values):
                try:
                    keys[idx].value = value
                except Exception:
                    pass
            if original_mode == 'SCULPT':
                utils.ensure_sculpt_mode(context, obj)
            elif original_mode == 'EDIT':
                utils.ensure_edit_mode(context, obj)

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Shape layer duplicated. / シェイプレイヤーを複製しました。"))
        return {'FINISHED'}


class SSS_OT_delete_active_shape_layer(Operator):
    bl_idname = "smart_sculpt.delete_active_shape_layer"
    bl_label = "Delete Active Shape Layer"
    bl_description = _smart_utils.localize_bilingual_text((
        "Delete the active non-basis sculpt layer. Use snapshots if you need topology-safe backups before deleting. "
        "/ アクティブな基準キー以外のスカルプレイヤーを削除します。削除前にトポロジー安全な退避が必要ならスナップショットを使ってください。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        key = _active_non_basis_key(obj)
        if obj is None or key is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select a non-basis shape layer first. / 先に基準キー以外のシェイプレイヤーを選択してください。"))
            return {'CANCELLED'}

        original_mode = getattr(obj, 'mode', 'OBJECT')
        utils.ensure_object_mode(context, obj)
        try:
            obj.shape_key_remove(key)
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not delete shape layer: {v0} / シェイプレイヤーを削除できませんでした: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        finally:
            if original_mode == 'SCULPT':
                utils.ensure_sculpt_mode(context, obj)
            elif original_mode == 'EDIT':
                utils.ensure_edit_mode(context, obj)

        self.report({'INFO'}, _smart_utils.localize_bilingual_text("Shape layer deleted. / シェイプレイヤーを削除しました。"))
        return {'FINISHED'}


class SSS_OT_drive_active_shape_layer(Operator):
    bl_idname = "smart_sculpt.drive_active_shape_layer"
    bl_label = "Drive Active Shape Layer"
    bl_description = _smart_utils.localize_bilingual_text((
        "Add a driver so the active non-basis sculpt layer is controlled by a bone transform. "
        "This approximates animation-linked sculpt workflows seen in tools with corrective sculpt layers. "
        "/ アクティブな基準キー以外のスカルプレイヤーをボーン変形で駆動するドライバーを追加します。補正スカルプトレイヤー系のアニメーション連動ワークフローを近似します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        key = _active_non_basis_key(obj)
        if obj is None or key is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select a non-basis shape layer first. / 先に基準キー以外のシェイプレイヤーを選択してください。"))
            return {'CANCELLED'}
        if obj.data.shape_keys is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Object has no shape keys. / オブジェクトにシェイプキーがありません。"))
            return {'CANCELLED'}

        arm = utils.related_armature(obj)
        if arm is None and getattr(context, 'object', None) and context.object.type == 'ARMATURE':
            arm = context.object
        bone_name = settings.driver_bone if settings else ""
        if not bone_name:
            active_pose_bone = getattr(context, 'active_pose_bone', None)
            bone_name = active_pose_bone.name if active_pose_bone else ""
        if arm is None or not bone_name:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Need an armature modifier and a bone name (or active pose bone). / アーマチュアモディファイアとボーン名（またはアクティブポーズボーン）が必要です。"))
            return {'CANCELLED'}
        if bone_name not in arm.data.bones:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Bone not found: {v0} / ボーンが見つかりません: {v1}', v0=bone_name, v1=bone_name))
            return {'CANCELLED'}

        shape_keys = obj.data.shape_keys
        key_path = f'key_blocks["{key.name}"].value'
        try:
            if shape_keys.animation_data is None:
                shape_keys.animation_data_create()
            try:
                for fcurve in list(shape_keys.animation_data.drivers):
                    if fcurve.data_path == key_path:
                        shape_keys.driver_remove(key_path)
                        break
            except Exception:
                pass
            fcurve = shape_keys.driver_add(key_path)
            driver = fcurve.driver
            driver.type = 'SCRIPTED'
            variable = driver.variables.new()
            variable.name = 'v'
            variable.type = 'TRANSFORMS'
            target = variable.targets[0]
            target.id = arm
            target.bone_target = bone_name
            target.transform_type = settings.driver_channel if settings else 'ROT_X'
            target.transform_space = 'LOCAL_SPACE'
            min_value = settings.driver_min if settings else 0.0
            max_value = settings.driver_max if settings else 1.0
            span = max(max_value - min_value, 1e-6)
            driver.expression = f"max(0.0, min(1.0, (v - ({min_value})) / ({span})))"
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not create driver: {v0} / ドライバーを作成できませんでした: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        self.report({'INFO'}, _smart_utils.localize_bilingual_format("Layer '{v0}' now follows bone '{v1}'. / レイヤー '{v2}' をボーン '{v3}' で駆動するよう設定しました。", v0=key.name, v1=bone_name, v2=key.name, v3=bone_name))
        return {'FINISHED'}


class SSS_OT_create_proxy_session(Operator):
    bl_idname = "smart_sculpt.create_proxy_session"
    bl_label = "Create Sculpt Session"
    bl_description = _smart_utils.localize_bilingual_text((
        'Create a unified sculpt session from the selected mesh objects. In UNIFIED mode the evaluated meshes are joined and kept as-is; in PROXY mode the joined result is voxel-remeshed for lighter sculpting. This is the Smart Sculpt superset of multi-part sculpt workflows. / 選択中メッシュから統合スカルプトセッションを作成します。統合は評価後メッシュを結合したまま保持し、プロキシは結合後にボクセルリメッシュして軽量化します。スマートスカルプトにおける複数パーツ造形ワークフローの上位統合機能です。'
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = utils.settings_from_context(context)
        sources = utils.selected_mesh_objects(context, editable_only=True)
        active = utils.active_mesh_object(context) or (sources[0] if sources else None)
        if active is not None and active in sources:
            sources = [active] + [obj for obj in sources if obj != active]
        if not sources:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Select at least one mesh object. / 少なくとも1つのメッシュオブジェクトを選択してください。"))
            return {'CANCELLED'}

        session_mode = settings.session_mode if settings else 'UNIFIED'
        if active is not None and not utils.ensure_object_mode(context, active):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not switch to Object Mode before creating the sculpt session. / スカルプトセッション作成前にオブジェクトモード へ切り替えられませんでした。"))
            return {'CANCELLED'}
        collection = utils.proxy_collection(context.scene)
        session_parts = []
        try:
            for obj in sources:
                session_parts.append(utils.evaluated_mesh_copy(context, obj, collection, name=f"{obj.name}_session", kind='session_part'))
        except Exception as exc:
            for part in session_parts:
                utils.safe_delete_object(part, require_owned=True)
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Could not create one or more session parts: {v0} / セッション用パーツの作成に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        if not session_parts:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No session parts were created. / セッション用パーツを作成できませんでした。"))
            return {'CANCELLED'}

        if len(session_parts) == 1:
            session_obj = session_parts[0]
            utils.make_active(context, session_obj, keep_existing_selection=False)
        else:
            utils.select_only(context, session_parts, active=session_parts[0])
            try:
                utils.safe_operator_call(bpy.ops.object.join)
            except Exception as exc:
                for part in session_parts:
                    utils.safe_delete_object(part, require_owned=True)
                self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Session join failed: {v0} / セッションの結合に失敗しました: {v1}', v0=exc, v1=exc))
                return {'CANCELLED'}
            session_obj = context.view_layer.objects.active

        if not utils.mesh_has_meaningful_topology(session_obj):
            counts = utils.topology_signature(session_obj)
            restored = _cleanup_failed_session(context, session_obj, [item.name for item in sources])
            self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Session creation produced invalid topology ({v0} verts / {v1} faces); restored {v2} source object(s). / セッション作成結果のトポロジーが不正でした（{v3} 頂点 / {v4} 面）。{v5} 個の元オブジェクトを再選択しました。', v0=counts[0], v1=counts[2], v2=restored, v3=counts[0], v4=counts[2], v5=restored))
            return {'CANCELLED'}
        session_obj.name = utils.unique_name("SSS_Proxy" if session_mode == 'PROXY' else "SSS_Session")
        session_obj["sss_proxy_sources"] = utils.serialize_name_list(sources)
        session_obj["sss_source_visibility"] = utils.capture_visibility_map(sources)
        session_obj["sss_session_mode"] = session_mode
        utils.mark_generated(session_obj, 'proxy' if session_mode == 'PROXY' else 'session')

        if settings and session_mode == 'PROXY':
            mesh = session_obj.data
            utils.set_attr_if_exists(mesh, 'remesh_voxel_size', settings.voxel_size)
            utils.set_attr_if_exists(mesh, 'remesh_voxel_adaptivity', settings.voxel_adaptivity)
            try:
                utils.safe_operator_call(bpy.ops.object.voxel_remesh)
                session_obj = context.view_layer.objects.active or session_obj
            except Exception:
                restored = _cleanup_failed_session(context, session_obj, [item.name for item in sources])
                self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Proxy voxel remesh failed and restored {v0} source object(s). / プロキシのボクセルリメッシュに失敗したため、{v1} 個の元オブジェクトを再選択しました。', v0=restored, v1=restored))
                return {'CANCELLED'}
            if not utils.mesh_has_meaningful_topology(session_obj):
                counts = utils.topology_signature(session_obj)
                restored = _cleanup_failed_session(context, session_obj, [item.name for item in sources])
                self.report({'ERROR'}, _smart_utils.localize_bilingual_format('Proxy session became invalid after voxel remesh ({v0} verts / {v1} faces); restored {v2} source object(s). / プロキシセッションがボクセルリメッシュ後に不正になったため、{v3} 個の元オブジェクトを再選択しました。', v0=counts[0], v1=counts[2], v2=restored, v3=restored))
                return {'CANCELLED'}

        if settings and settings.hide_originals_on_proxy:
            for source in sources:
                try:
                    source.hide_set(True)
                except Exception:
                    pass

        initialized_face_sets = False
        face_set_mode = 'NONE'
        allow_interactive_sculpt = not bool(getattr(bpy.app, 'background', False))
        if settings:
            face_set_mode = getattr(settings, 'session_face_set_mode', 'NONE') or 'NONE'
            if face_set_mode == 'NONE' and getattr(settings, 'session_initialize_face_sets', False):
                face_set_mode = 'LOOSE_PARTS'
        original_mode = getattr(session_obj, 'mode', 'OBJECT')
        if settings and face_set_mode != 'NONE' and allow_interactive_sculpt:
            if utils.ensure_sculpt_mode(context, session_obj):
                try:
                    variants = [{'mode': face_set_mode}]
                    if face_set_mode != 'LOOSE_PARTS':
                        variants.append({'mode': 'LOOSE_PARTS'})
                    utils.safe_operator_call(bpy.ops.sculpt.face_sets_init, variants)
                    initialized_face_sets = True
                except Exception:
                    pass
                if not settings.auto_enter_sculpt:
                    utils.ensure_object_mode(context, session_obj)
        elif settings and settings.auto_enter_sculpt and allow_interactive_sculpt:
            utils.ensure_sculpt_mode(context, session_obj)

        if initialized_face_sets:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Sculpt session created ({v0}) with face sets: {v1}. / フェイスセット初期化付きでスカルプトセッション ({v2}) を作成しました: {v3}', v0=session_mode, v1=face_set_mode, v2=session_mode, v3=face_set_mode))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Sculpt session created ({v0}). / スカルプトセッション ({v1}) を作成しました。', v0=session_mode, v1=session_mode))
        return {'FINISHED'}


class SSS_OT_restore_proxy_sources(Operator):
    bl_idname = "smart_sculpt.restore_proxy_sources"
    bl_label = "Restore Session Sources"
    bl_description = _smart_utils.localize_bilingual_text((
        "Unhide the original source objects stored on the active sculpt session. "
        "/ アクティブなスカルプトセッションに保存されている元オブジェクトの表示を戻します。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.view_layer.objects.active
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active object. / アクティブオブジェクトがありません。"))
            return {'CANCELLED'}

        names, restored, missing = _restore_session_sources_from_object(obj)
        if not names:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Active object is not a Smart Sculpt session. / アクティブオブジェクトはスマートスカルプトのセッションではありません。"))
            return {'CANCELLED'}

        selected = _select_session_sources(context, names)
        if missing:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Restored {v0} source object(s), reselected {v1}, and {v2} source(s) were missing. / {v3} 個の元オブジェクトを再表示し、{v4} 個を再選択しました。{v5} 個の元オブジェクトは見つかりませんでした。', v0=restored, v1=selected, v2=missing, v3=restored, v4=selected, v5=missing))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Restored {v0} source object(s) and reselected {v1}. / {v2} 個の元オブジェクトを再表示し、{v3} 個を再選択しました。', v0=restored, v1=selected, v2=restored, v3=selected))
        return {'FINISHED'}


class SSS_OT_close_sculpt_session(Operator):
    bl_idname = "smart_sculpt.close_sculpt_session"
    bl_label = "Close Sculpt Session"
    bl_description = _smart_utils.localize_bilingual_text((
        "Restore the original source objects stored on the active sculpt session and delete the generated session object itself. "
        "Use this after baking, exporting, or snapshotting the sculpt result so your scene goes back to a clean multi-object state. "
        "/ アクティブなスカルプトセッションに保存されている元オブジェクトを復元し、生成されたセッション本体を削除します。"
        "スカルプト結果のベイク、書き出し、スナップショット保存後に、シーンをクリーンな複数オブジェクト状態へ戻すために使います。"
    ))
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = context.view_layer.objects.active
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active object. / アクティブオブジェクトがありません。"))
            return {'CANCELLED'}

        names, restored, missing = _restore_session_sources_from_object(obj)
        if not names:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Active object is not a Smart Sculpt session. / アクティブオブジェクトはスマートスカルプトのセッションではありません。"))
            return {'CANCELLED'}

        source_names = list(names)
        utils.ensure_object_mode(context, obj)
        session_name = obj.name
        if not utils.safe_delete_object(obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not delete the generated sculpt session object. / 生成されたスカルプトセッションを削除できませんでした。"))
            return {'CANCELLED'}

        selected = _select_session_sources(context, source_names)
        if missing:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format("Closed sculpt session '{v0}', restored {v1} source object(s), reselected {v2}, and {v3} source(s) were missing. / スカルプトセッション '{v4}' を終了し、{v5} 個の元オブジェクトを復元、{v6} 個を再選択しました。{v7} 個の元オブジェクトは見つかりませんでした。", v0=session_name, v1=restored, v2=selected, v3=missing, v4=session_name, v5=restored, v6=selected, v7=missing))
        else:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format("Closed sculpt session '{v0}', restored {v1} source object(s), and reselected {v2}. / スカルプトセッション '{v3}' を終了し、{v4} 個の元オブジェクトを復元、{v5} 個を再選択しました。", v0=session_name, v1=restored, v2=selected, v3=session_name, v4=restored, v5=selected))
        return {'FINISHED'}


classes = (
    SSS_OT_save_snapshot,
    SSS_OT_restore_snapshot,
    SSS_OT_preview_snapshot,
    SSS_OT_clear_snapshot_preview,
    SSS_OT_delete_snapshot,
    SSS_OT_restore_recovery_backup,
    SSS_OT_clear_recovery_backup,
    SSS_OT_create_shape_layer,
    SSS_OT_duplicate_active_shape_layer,
    SSS_OT_delete_active_shape_layer,
    SSS_OT_drive_active_shape_layer,
    SSS_OT_create_proxy_session,
    SSS_OT_restore_proxy_sources,
    SSS_OT_close_sculpt_session,
)
