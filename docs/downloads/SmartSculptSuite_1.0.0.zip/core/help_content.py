# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import ast
import sys
import unicodedata
from pathlib import Path
from typing import Any
try:
    import blf as _blf  # type: ignore
except Exception:
    _blf = None

import bpy

from . import utils


SCULPT_PROPS = (
    'core_action', 'multi_object_make_single_user', 'apply_scale_on_fix', 'recalc_normals_on_fix',
    'delete_loose_on_fix', 'dissolve_degenerate_on_fix', 'degenerate_threshold_on_fix',
    'merge_distance_on_fix', 'auto_enter_sculpt', 'compact_viewport_preset', 'profile', 'quick_tool',
    'tool_pipe_slot_index', 'tool_pipe_slot_1', 'tool_pipe_slot_2', 'tool_pipe_slot_3',
)
SMART_PROPS = (
    'smart_upgrade_action', 'smart_upgrade_quality', 'smart_upgrade_show_icon_board', 'smart_upgrade_show_metrics', 'smart_upgrade_icon_scale', 'smart_upgrade_auto_preflight',
    'smart_upgrade_adaptive_scale', 'smart_upgrade_non_destructive', 'smart_upgrade_write_report', 'smart_upgrade_target_faces',
    'smart_upgrade_strength', 'smart_upgrade_density', 'smart_upgrade_count',
    'smart_upgrade_segments', 'smart_upgrade_axis', 'smart_upgrade_use_voxel',
    'smart_upgrade_use_multires', 'smart_upgrade_make_snapshot', 'smart_photo_reference_path', 'exchange_format', 'exchange_scope',
    'exchange_dir', 'driver_bone', 'driver_channel',
)

SURFACE_PROPS = (
    'surface_action', 'dyntopo_mode', 'dyntopo_detail', 'compact_remesh_mode', 'voxel_size',
    'voxel_adaptivity', 'quad_target_faces', 'compact_multires_action', 'multires_levels',
    'compact_mask_action', 'extract_thickness', 'mask_extract_smooth_iterations',
    'mask_extract_add_boundary_loop', 'mask_extract_apply_shrinkwrap', 'mask_slice_fill_holes',
    'compact_face_set_action', 'compact_filter_domain', 'filter_strength', 'mesh_filter_type',
    'cloth_filter_type', 'retopo_offset', 'retopo_use_mirror', 'unwrap_margin',
)
BUILD_PROPS = (
    'build_action', 'compact_primitive_type', 'primitive_radius', 'primitive_operation',
    'compact_boolean_operation', 'boolean_cleanup_voxel', 'compact_axis', 'rail_length', 'rail_width',
    'rail_depth', 'rail_apply_to_target', 'rail_apply_boolean', 'rail_remove_cutter', 'rail_add_bevel',
    'compact_chain_count', 'compact_curve_length', 'scatter_count', 'scatter_min_scale',
    'scatter_max_scale', 'scatter_align_to_normal', 'scatter_normal_offset', 'scatter_seed',
    'scatter_avoid_overlap', 'scatter_min_gap', 'scatter_tilt_degrees', 'compact_procedural_preset',
    'procedural_strength', 'procedural_scale',
)
SAFE_PROPS = (
    'snapshot_action', 'recovery_action', 'enable_recovery_backups', 'layer_action', 'driver_bone',
    'driver_channel', 'driver_min', 'driver_max', 'session_action', 'session_mode',
    'session_face_set_mode', 'session_initialize_face_sets', 'hide_originals_on_proxy',
    'transfer_action', 'exchange_dir', 'exchange_format', 'exchange_scope',
    'exchange_timestamped_export', 'cleanup_include_snapshots',
)
SETTINGS_PROPS = (
    'show_always_on_toggles', 'always_on_npanel_autosave_restore', 'navigation_enabled', 'navigation_canvas_enabled', 'navigation_rmb_enabled', 'navigation_double_click_focus_enabled', 'always_on_navigation_border_overlay', 'smart_upgrade_action', 'smart_upgrade_quality', 'smart_upgrade_show_icon_board', 'smart_upgrade_show_metrics', 'smart_upgrade_icon_scale', 'smart_upgrade_auto_preflight', 'smart_upgrade_adaptive_scale', 'smart_upgrade_non_destructive', 'smart_upgrade_write_report', 'smart_upgrade_target_faces', 'smart_upgrade_strength', 'smart_upgrade_density', 'smart_upgrade_count', 'smart_upgrade_segments', 'smart_upgrade_axis', 'smart_upgrade_use_voxel', 'smart_upgrade_use_multires', 'smart_upgrade_make_snapshot', 'smart_photo_reference_path', 'core_action', 'compact_viewport_preset', 'quick_tool',
    'tool_pipe_slot_index', 'surface_action', 'compact_remesh_mode', 'compact_multires_action',
    'compact_mask_action', 'compact_face_set_action', 'compact_filter_domain', 'build_action',
    'compact_primitive_type', 'compact_boolean_operation', 'compact_axis', 'compact_procedural_preset',
    'compact_chain_count', 'compact_curve_length', 'snapshot_action', 'recovery_action', 'layer_action',
    'session_action', 'transfer_action', 'profile', 'dyntopo_mode', 'dyntopo_detail', 'voxel_size',
    'voxel_adaptivity', 'extract_thickness', 'mask_extract_smooth_iterations',
    'mask_extract_add_boundary_loop', 'mask_extract_apply_shrinkwrap', 'mask_slice_fill_holes',
    'multires_levels', 'quad_target_faces', 'primitive_radius', 'primitive_operation',
    'boolean_cleanup_voxel', 'procedural_strength', 'procedural_scale', 'rail_length', 'rail_width',
    'rail_depth', 'rail_apply_to_target', 'rail_apply_boolean', 'rail_remove_cutter', 'rail_add_bevel',
    'scatter_count', 'scatter_min_scale', 'scatter_max_scale', 'scatter_align_to_normal',
    'scatter_normal_offset', 'scatter_seed', 'scatter_avoid_overlap', 'scatter_min_gap',
    'scatter_tilt_degrees', 'mesh_filter_type', 'cloth_filter_type', 'filter_strength',
    'retopo_offset', 'retopo_use_mirror', 'unwrap_margin', 'auto_enter_sculpt',
    'enable_recovery_backups', 'hide_originals_on_proxy', 'session_mode',
    'session_initialize_face_sets', 'session_face_set_mode', 'multi_object_make_single_user',
    'apply_scale_on_fix', 'recalc_normals_on_fix', 'delete_loose_on_fix',
    'dissolve_degenerate_on_fix', 'degenerate_threshold_on_fix', 'merge_distance_on_fix',
    'exchange_dir', 'exchange_format', 'exchange_scope', 'exchange_timestamped_export',
    'driver_bone', 'driver_channel', 'driver_min', 'driver_max', 'tool_pipe_slot_1',
    'tool_pipe_slot_2', 'tool_pipe_slot_3', 'tool_pipe_slot_1_tool', 'tool_pipe_slot_2_tool',
    'tool_pipe_slot_3_tool', 'cleanup_include_snapshots', 'diagnostics',
)


# Blender popups do not automatically wrap label text.  The help popup uses
# the pixel width passed by the popup operator and wraps only when a label would
# exceed that width, instead of forcing fixed-column line breaks.
_HELP_POPUP_DEFAULT_WIDTH_PX = 760
_HELP_POPUP_MIN_TEXT_PX = 160
_HELP_POPUP_HORIZONTAL_PADDING_PX = 82
_HELP_POPUP_ICON_TEXT_PADDING_PX = 28
_CURRENT_HELP_POPUP_WIDTH_PX = _HELP_POPUP_DEFAULT_WIDTH_PX


def _t(en: str, ja: str) -> str:
    return utils.ui_text(en, ja)


def _one_language(text: object) -> str:
    raw = str(text or '').strip()
    if not raw:
        return ''
    try:
        english, japanese = utils.split_bilingual_text(raw)
        if english and japanese:
            return utils.ui_text(english, japanese)
    except Exception:
        pass
    try:
        return utils.translate_registered_text(raw)
    except Exception:
        return raw


def _ui_scale() -> float:
    try:
        value = float(getattr(getattr(bpy.context.preferences, 'system', None), 'ui_scale', 1.0) or 1.0)
    except Exception:
        value = 1.0
    return max(0.5, min(value, 4.0))


def _visual_width(text: str) -> int:
    width = 0
    for char in str(text or ''):
        if char == '\t':
            width += 4
        else:
            east_width = unicodedata.east_asian_width(char)
            if east_width in {'F', 'W'} or (east_width == 'A' and utils.locale_is_japanese()):
                width += 2
            else:
                width += 1
    return width


def _fallback_text_pixels(text: str) -> float:
    # A conservative half-width UI glyph estimate. Full-width CJK characters
    # are counted as two units by _visual_width(), so Japanese text is not
    # allowed to overrun the popup when Blender's font API is unavailable.
    return float(_visual_width(text)) * 7.2 * _ui_scale()


def _measure_text_pixels(text: object) -> float:
    raw = str(text or '')
    if not raw:
        return 0.0
    try:
        if _blf is None:
            raise RuntimeError("BLF unavailable")
        font_id = 0
        font_size = max(8, int(round(11 * _ui_scale())))
        try:
            _blf.size(font_id, font_size)
        except TypeError:
            try:
                _blf.size(font_id, font_size, 72)
            except Exception:
                pass
        except Exception:
            pass
        dims = _blf.dimensions(font_id, raw)
        measured = float(dims[0]) if dims else 0.0
        if measured > 0.0:
            return measured
    except Exception:
        pass
    return _fallback_text_pixels(raw)


def _set_help_popup_width(width: object | None) -> None:
    global _CURRENT_HELP_POPUP_WIDTH_PX
    try:
        resolved = int(float(width))
    except Exception:
        resolved = _HELP_POPUP_DEFAULT_WIDTH_PX
    _CURRENT_HELP_POPUP_WIDTH_PX = max(240, resolved)


def _available_text_pixels(*, icon: str = 'NONE', reserved_prefix: str = '') -> float:
    icon_text = str(icon or 'NONE')
    padding = float(_HELP_POPUP_HORIZONTAL_PADDING_PX) * _ui_scale()
    if icon_text != 'NONE':
        padding += float(_HELP_POPUP_ICON_TEXT_PADDING_PX) * _ui_scale()
    if reserved_prefix:
        padding += _measure_text_pixels(reserved_prefix)
    available = float(_CURRENT_HELP_POPUP_WIDTH_PX) * _ui_scale() - padding
    return max(float(_HELP_POPUP_MIN_TEXT_PX), available)


_LINE_START_FORBIDDEN = frozenset('。、，．）」』】！？：')


def _split_long_token_to_pixels(token: str, max_pixels: float) -> list[str]:
    parts: list[str] = []
    current = ''
    for char in str(token or ''):
        candidate = current + char
        # 句読点や閉じかっこを行頭に送らない。
        if current and char not in _LINE_START_FORBIDDEN and _measure_text_pixels(candidate) > max_pixels:
            parts.append(current)
            current = char
        else:
            current = candidate
    if current:
        parts.append(current)
    return parts or ['']


def _pixel_wrap_lines(text: object, *, max_pixels: float, min_pixels: float | None = None) -> list[str]:
    raw = _one_language(text)
    if not raw:
        return []
    try:
        limit = float(max_pixels)
    except Exception:
        limit = _available_text_pixels()
    limit = max(float(_HELP_POPUP_MIN_TEXT_PX if min_pixels is None else min_pixels), limit)

    lines: list[str] = []
    paragraphs = str(raw).replace('\r\n', '\n').replace('\r', '\n').split('\n')
    for paragraph in paragraphs:
        paragraph = paragraph.strip()
        if not paragraph:
            if lines and lines[-1] != '':
                lines.append('')
            continue
        if _measure_text_pixels(paragraph) <= limit:
            lines.append(paragraph)
            continue
        words = paragraph.split()
        if len(words) <= 1:
            lines.extend(_split_long_token_to_pixels(paragraph, limit))
            continue
        current = ''
        for word in words:
            if _measure_text_pixels(word) > limit:
                if current:
                    lines.append(current)
                    current = ''
                pieces = _split_long_token_to_pixels(word, limit)
                lines.extend(pieces[:-1])
                current = pieces[-1] if pieces else ''
                continue
            candidate = f'{current} {word}'.strip() if current else word
            if _measure_text_pixels(candidate) <= limit:
                current = candidate
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
    while lines and lines[-1] == '':
        lines.pop()
    return lines


def _visual_wrap_lines(text: object, *, width: int = 78, max_pixels: float | None = None) -> list[str]:
    # width is retained only for compatibility with older internal calls. Help
    # popup wrapping is now driven by max_pixels / popup width, not by a fixed
    # number of visual columns.
    if max_pixels is None:
        max_pixels = _available_text_pixels()
    return _pixel_wrap_lines(text, max_pixels=max_pixels)


def _wrap(layout, text: object, *, width: int = 78, icon: str = 'NONE') -> None:
    del width  # The popup width, not a fixed column count, controls wrapping.
    icon_text = str(icon or 'NONE')
    max_pixels = _available_text_pixels(icon=icon_text)
    lines = _pixel_wrap_lines(text, max_pixels=max_pixels)
    if not lines:
        return
    first = True
    for line in lines:
        if line:
            layout.label(text=line, icon=utils.safe_icon(icon if first else 'NONE'))
        else:
            layout.separator(factor=0.25)
        first = False


def _bullets(layout, lines: tuple[str, ...] | list[str], *, width: int = 74) -> None:
    del width  # Compatibility parameter; wrapping follows the popup width.
    first_prefix = '• '
    continuation_prefix = '  '
    reserved = first_prefix if _measure_text_pixels(first_prefix) >= _measure_text_pixels(continuation_prefix) else continuation_prefix
    body_pixels = _available_text_pixels(reserved_prefix=reserved)
    for item in lines:
        wrapped = _pixel_wrap_lines(item, max_pixels=body_pixels)
        if not wrapped:
            continue
        first = True
        for line in wrapped:
            prefix = first_prefix if first else continuation_prefix
            layout.label(text=prefix + line)
            first = False


def _section(layout, title_en: str, title_ja: str, icon: str = 'INFO'):
    box = layout.box()
    box.label(text=_t(title_en, title_ja), icon=utils.safe_icon(icon))
    return box


def _scene_settings(context):
    try:
        return getattr(getattr(context, 'scene', None), 'core', None)
    except Exception:
        return None


def _rna_properties(data) -> dict[str, Any]:
    result: dict[str, Any] = {}
    if data is None:
        return result
    try:
        props = tuple(getattr(getattr(data, 'bl_rna', None), 'properties', ()) or ())
    except Exception:
        props = ()
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
        except Exception:
            continue
        if not identifier or identifier in {'rna_type', 'bl_idname', 'name'}:
            continue
        result[identifier] = prop
    return result


def _draw_property_details(layout, data, prop_names: tuple[str, ...] | list[str] | None = None, *, include_hidden: bool = False, max_items: int | None = None) -> int:
    props = _rna_properties(data)
    if not props:
        _wrap(layout, _t('No registered settings were found.', '登録済み設定項目は見つかりませんでした。'), width=74, icon='NONE')
        return 0
    if prop_names is None:
        ordered = list(props.keys())
    else:
        ordered = [name for name in prop_names if name in props]
    count = 0
    for identifier in ordered:
        prop = props.get(identifier)
        if prop is None:
            continue
        try:
            if not include_hidden and bool(getattr(prop, 'is_hidden', False)):
                continue
        except Exception:
            pass
        try:
            if bool(getattr(prop, 'is_readonly', False)) and identifier != 'diagnostics':
                continue
        except Exception:
            pass
        name = _one_language(getattr(prop, 'name', '') or identifier) or identifier
        desc = _one_language(getattr(prop, 'description', '') or '')
        row = layout.column(align=True)
        _wrap(row, name, width=74, icon='DOT')
        if desc:
            _wrap(row, desc, width=78)
        count += 1
        if max_items is not None and count >= int(max_items):
            break
    if count == 0:
        _wrap(layout, _t('No editable settings are used by this topic.', 'この項目で使用する編集可能な設定はありません。'), width=74, icon='NONE')
    return count


_ADDON_ROOT_DIR = Path(__file__).resolve().parent.parent
_UI_SOURCE_PATH = _ADDON_ROOT_DIR / 'core' / 'ui.py'
_SOURCE_OPERATOR_META_CACHE: dict[str, dict[str, str]] | None = None
_TOPIC_UI_FUNCTION_CACHE: dict[str, list[tuple[str, str, str, str]]] | None = None


_TOPIC_FUNCTION_PROP_OVERRIDES: dict[str, tuple[str, ...]] = {
    'tab_sculpt': ('core_action', 'compact_viewport_preset', 'quick_tool'),
    'core_workflow': ('core_action',),
    'view_profile': ('compact_viewport_preset', 'profile'),
    'brush_access': ('quick_tool',),
    'tab_smart': ('smart_upgrade_action', 'smart_upgrade_quality'),
    'smart_compatibility_map': ('smart_upgrade_action',),
    'surface_actions': ('surface_action',),
    'build_actions': ('build_action',),
    'snapshots': ('snapshot_action',),
    'recovery': ('recovery_action',),
    'shape_layers': ('layer_action',),
    'sculpt_session': ('session_action',),
    'transfer_cleanup': ('transfer_action',),
    'quick_tools': ('quick_tool',),
    'dyntopo': ('dyntopo_mode',),
    'voxel_remesh': ('compact_remesh_mode',),
    'multires': ('compact_multires_action',),
    'mask_facesets': ('compact_mask_action', 'compact_face_set_action'),
    'filters': ('compact_filter_domain', 'mesh_filter_type', 'cloth_filter_type'),
    'primitive_boolean': ('compact_primitive_type', 'primitive_operation', 'compact_boolean_operation'),
    'procedural_stack': ('compact_procedural_preset',),
    'exchange': ('exchange_format', 'exchange_scope'),
}


def _ast_call_name(call: ast.Call | None) -> str:
    if call is None:
        return ''
    func = getattr(call, 'func', None)
    if isinstance(func, ast.Name):
        return str(func.id or '')
    if isinstance(func, ast.Attribute):
        return str(func.attr or '')
    return ''


def _ast_keyword_value(call: ast.Call | None, keyword_name: str) -> ast.AST | None:
    if call is None:
        return None
    for keyword in getattr(call, 'keywords', ()) or ():
        if str(getattr(keyword, 'arg', '') or '') == keyword_name:
            return keyword.value
    return None


def _ast_string_pair(node: ast.AST | None) -> tuple[str, str]:
    if node is None:
        return '', ''
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        value = str(node.value).strip()
        return value, value
    if isinstance(node, ast.JoinedStr):
        value = _literal_string(node)
        return value, value
    if isinstance(node, (ast.Tuple, ast.List)) and len(node.elts) >= 2:
        first = _literal_string(node.elts[0])
        second = _literal_string(node.elts[1])
        if first or second:
            return first or second, second or first
    if isinstance(node, ast.Call):
        call_name = _ast_call_name(node)
        if call_name in {'t', '_t', 'ui_text', 'localize_bilingual_text', 'localize_bilingual_format'}:
            first = _literal_string(node.args[0]) if len(node.args) >= 1 else ''
            second = _literal_string(node.args[1]) if len(node.args) >= 2 else ''
            if first or second:
                return first or second, second or first
        if node.args:
            value = _literal_string(node.args[0])
            return value, value
    value = _literal_string(node)
    return value, value


def _dedupe_lines(lines: list[str] | tuple[str, ...]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for line in lines:
        text = str(line or '').strip()
        if not text or text in seen:
            continue
        seen.add(text)
        result.append(text)
    return result


def _source_operator_meta() -> dict[str, dict[str, str]]:
    global _SOURCE_OPERATOR_META_CACHE
    if isinstance(_SOURCE_OPERATOR_META_CACHE, dict):
        return _SOURCE_OPERATOR_META_CACHE
    result: dict[str, dict[str, str]] = {}
    for py_path in sorted(_ADDON_ROOT_DIR.rglob('*.py'), key=lambda item: str(item).lower()):
        if '__pycache__' in py_path.parts:
            continue
        try:
            tree = ast.parse(py_path.read_text(encoding='utf-8', errors='ignore'))
        except Exception:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            attrs = _class_assignment_strings(node)
            item_id = str(attrs.get('bl_idname', '') or '').strip()
            label = str(attrs.get('bl_label', '') or node.name).strip()
            desc = str(attrs.get('bl_description', '') or '').strip()
            if not item_id:
                continue
            result[item_id] = {'label': label, 'desc': desc}
    _SOURCE_OPERATOR_META_CACHE = result
    return result


_SECTION_HEADER_TOPIC_ARG = {'_box_header': 4, '_section_box': 7, '_section_box_or_empty': 7, '_section': 7, '_draw_smart_action_group': 8}


def _box_header_topic_from_stmt(statement: ast.stmt) -> str:
    call = None
    if isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Call):
        call = statement.value
    elif isinstance(statement, ast.Assign) and isinstance(statement.value, ast.Call):
        call = statement.value
    elif isinstance(statement, ast.AnnAssign) and isinstance(statement.value, ast.Call):
        call = statement.value
    if call is None:
        return ''
    index = _SECTION_HEADER_TOPIC_ARG.get(_ast_call_name(call))
    if index is None:
        return ''
    args = tuple(getattr(call, 'args', ()) or ())
    if len(args) <= index:
        return ''
    return _literal_string(args[index])


def _call_label_pair(call: ast.Call, *, op_id: str = '') -> tuple[str, str]:
    label_en, label_ja = _ast_string_pair(_ast_keyword_value(call, 'text'))
    if label_en or label_ja:
        return label_en, label_ja
    meta = _source_operator_meta().get(op_id or '', {})
    label = str(meta.get('label') or op_id.replace('.', ' ').replace('_', ' ').title()).strip()
    return label, label


def _collect_ui_function_entries(node: ast.AST, bucket: list[tuple[str, str, str, str]]) -> None:
    seen = {(str(item[0] or ''), str(item[1] or ''), str(item[2] or '')) for item in bucket}
    operator_meta = _source_operator_meta()
    for call in ast.walk(node):
        if not isinstance(call, ast.Call):
            continue
        func_name = _ast_call_name(call)
        op_id = ''
        if func_name == '_draw_smart_action_group':
            actions = call.args[7] if len(call.args) > 7 else None
            for element in (getattr(actions, 'elts', ()) or ()):
                action = _literal_string(element)
                key = (f'smart_action:{action}', '', '')
                if action and key not in seen:
                    seen.add(key)
                    bucket.append((key[0], '', '', ''))
            continue
        if func_name == '_op':
            if len(call.args) >= 2:
                op_id = _literal_string(call.args[1])
        elif func_name == '_popup_op':
            op_id = _literal_string(_ast_keyword_value(call, 'operator_idname')) or _literal_string(_ast_keyword_value(call, 'menu_idname'))
            if not op_id and len(call.args) >= 2:
                op_id = _literal_string(call.args[1])
        elif func_name == 'operator':
            if call.args:
                op_id = _literal_string(call.args[0])
        else:
            continue
        text_node = _ast_keyword_value(call, 'text')
        if isinstance(text_node, ast.Call) and _ast_call_name(text_node) == '_smart_action_label':
            action = _literal_string(text_node.args[0]) if text_node.args else ''
            key = (f'smart_action:{action}', '', '')
            if action and key not in seen:
                seen.add(key)
                bucket.append((key[0], '', '', ''))
            continue
        label_en, label_ja = _call_label_pair(call, op_id=op_id)
        if not label_en and not label_ja and not op_id:
            continue
        # 文字が変数のボタン（項目ごとに同じ操作を呼ぶもの）は、項目の一覧で別に出す。
        if op_id == 'smart_sculpt.run_smart_upgrade_tool' and not _ast_string_pair(_ast_keyword_value(call, 'text'))[0]:
            continue
        meta = operator_meta.get(op_id or '', {})
        desc = str(meta.get('desc') or '').strip()
        key = (op_id, label_en, label_ja)
        if key in seen:
            continue
        seen.add(key)
        bucket.append((op_id, label_en, label_ja, desc))


def _topic_ui_function_entries() -> dict[str, list[tuple[str, str, str, str]]]:
    global _TOPIC_UI_FUNCTION_CACHE
    if isinstance(_TOPIC_UI_FUNCTION_CACHE, dict):
        return _TOPIC_UI_FUNCTION_CACHE
    result: dict[str, list[tuple[str, str, str, str]]] = {}
    if not _UI_SOURCE_PATH.exists():
        _TOPIC_UI_FUNCTION_CACHE = result
        return result
    try:
        tree = ast.parse(_UI_SOURCE_PATH.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        _TOPIC_UI_FUNCTION_CACHE = result
        return result
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for item in node.body:
            if not isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            current_topic = ''
            segment: list[ast.stmt] = []

            def flush_segment() -> None:
                if not current_topic or not segment:
                    return
                module = ast.Module(body=list(segment), type_ignores=[])
                bucket = result.setdefault(current_topic, [])
                _collect_ui_function_entries(module, bucket)

            for statement in item.body:
                next_topic = _box_header_topic_from_stmt(statement)
                if next_topic:
                    flush_segment()
                    current_topic = next_topic
                    segment = []
                    continue
                if current_topic:
                    segment.append(statement)
            flush_segment()
        # 最上位の枠は、呼び出す描画の中のボタンまで全部をその枠の機能として数える。
        methods = {item.name: item for item in node.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))}

        def collect_method(name: str, bucket: list[tuple[str, str, str, str]], visited: set[str]) -> None:
            method = methods.get(name)
            if method is None or name in visited:
                return
            visited.add(name)
            _collect_ui_function_entries(method, bucket)
            for call in ast.walk(method):
                if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and isinstance(call.func.value, ast.Name) and call.func.value.id == 'self':
                    collect_method(call.func.attr, bucket, visited)

        for name in methods:
            topic = name[len('_draw_'):] if name.startswith('_draw_top_') else 'tab_' + name[len('_draw_compact_'):] if name.startswith('_draw_compact_') else ''
            if topic:
                bucket = result.setdefault(topic, [])
                collect_method(name, bucket, {'_op', '_popup_op', '_section', '_section_box', '_section_box_or_empty', '_help_button', '_box_header', '_draw_smart_action_group'})
    _TOPIC_UI_FUNCTION_CACHE = result
    return result


def _function_entry_line(label_en: str, label_ja: str, desc: str = '') -> str:
    label = _t(str(label_en or ''), str(label_ja or label_en or ''))
    label = _one_language(label) or str(label_en or label_ja or '').strip()
    localized_desc = _one_language(desc)
    if utils.locale_is_japanese():
        if not localized_desc or not utils.contains_japanese_text(localized_desc):
            localized_desc = f'{label}をこのグループの現在設定で実行します。' if label else 'このグループの現在設定で実行します。'
    else:
        if not localized_desc:
            localized_desc = f'Run {label} with the current settings for this group.' if label else 'Run this function with the current settings for this group.'
    return f'{label} — {localized_desc}' if label and localized_desc else (label or localized_desc)


def _strip_how_to(text: object) -> str:
    """項目ごとに同じ「使い方」の定型文は、ヘルプの一覧では繰り返さない。"""
    lines = [line for line in str(text or '').split('\n') if line.strip() and not line.startswith(('使い方:', 'How to use:'))]
    return '\n'.join(lines).strip()


def _enum_function_lines(context, topic_id: str) -> list[str]:
    prop_names = tuple(_TOPIC_FUNCTION_PROP_OVERRIDES.get(topic_id, ()))
    if not prop_names:
        return []
    data = _scene_settings(context)
    props = _rna_properties(data)
    result: list[str] = []
    include_group_prefix = len(prop_names) > 1
    for prop_name in prop_names:
        prop = props.get(prop_name)
        if prop is None:
            continue
        group_name = _one_language(getattr(prop, 'name', '') or prop_name) or prop_name
        items = []
        try:
            items = list(getattr(prop, 'enum_items', ()) or ())
        except Exception:
            items = []
        for item in items:
            try:
                identifier = str(getattr(item, 'identifier', '') or '')
            except Exception:
                identifier = ''
            if not identifier:
                continue
            item_name = _one_language(getattr(item, 'name', '') or identifier) or identifier
            item_desc = _strip_how_to(_one_language(getattr(item, 'description', '') or ''))
            line = item_name
            if item_desc:
                line = f'{item_name} — {item_desc}'
            if include_group_prefix:
                line = f'{group_name}: {line}'
            result.append(line)
    return _dedupe_lines(result)


def _always_on_function_lines() -> list[str]:
    try:
        from . import controls
    except Exception:
        return []
    result: list[str] = []
    for spec in tuple(getattr(controls, '_KNOWN_CONTROLS', ()) or ()):
        label_en = str(spec.get('label_en') or '')
        label_ja = str(spec.get('label_ja') or label_en or '')
        desc_en = str(spec.get('description_en') or '')
        desc_ja = str(spec.get('description_ja') or desc_en or '')
        result.append(_function_entry_line(label_en, label_ja, _t(desc_en, desc_ja)))
    return _dedupe_lines(result)


def _manual_function_lines(topic_id: str) -> list[str]:
    manual: list[str] = []
    if topic_id == 'settings_all':
        manual = [
            _t('Always-on Toggles — startup/background features and their saved on/off state.', '常時機能切り替え — 起動時・背景動作が必要な機能と、その保存済み有効/無効状態。'),
            _t('Workspace Defaults — compact tab choice, viewport presets, quick tools, profiles, and Tool Pipe slots.', 'ワークスペース既定値 — コンパクトタブ、表示プリセット、クイックツール、プロファイル、ツールパイプスロット。'),
            _t('Surface / Build / Safe Settings — every persistent option used by the Surface, Build, Safe, and Smart tool groups.', '表面 / 造形 / 安全の設定 — 表面、造形、安全、スマートの各ツールで使う、保存される設定のすべて。'),
            _t('Exchange and Driver Settings — roundtrip folder/format scope plus layer-driver support values.', '受け渡しとドライバー設定 — 往復用フォルダ/形式/対象と、レイヤードライバー支援値。'),
        ]
    elif topic_id == 'smart_precision_ui':
        manual = [
            _t('Live Mesh Readiness — shows production score, face count, quad ratio, risk edges, UV count, and shape-layer count for the active mesh. The score appears after Analyze or a Smart action.', 'ライブメッシュ準備度 — アクティブメッシュの制作スコア、面数、四角面率、リスク辺、UV数、シェイプレイヤー数を表示します。スコアは「解析」かスマートアクションの実行後に出ます。'),
            _t('Selected Action Card — shows the current Smart action and runs it directly.', '選択アクションカード — 現在のスマートアクションを表示し、そのまま実行します。'),
            _t('Apex Command Deck — shows every Smart action as a button with its icon and name.', '最上位コマンドデッキ — すべてのスマートアクションを、アイコンと名前付きのボタンで表示します。'),
            _t('Reference Board Fallback — uses the packaged Smart Sculpt reference image when no manual reference file is set.', '参照ボードフォールバック — 手動参照ファイルが未設定の場合、同梱のスマートスカルプト参照画像を使います。'),
        ]
    elif topic_id == 'tool_pipe':
        manual = [
            _t('Store — save the active sculpt brush into the selected Tool Pipe slot.', '保存 — 現在のスカルプトブラシを選択中のツールパイプスロットへ保存します。'),
            _t('Recall — restore the stored brush from the selected slot to the active sculpt session.', '呼び出し — 選択スロットに保存されたブラシを現在のスカルプトセッションへ呼び出します。'),
            _t('Clear — remove the stored brush reference from the selected slot.', 'クリア — 選択スロットに保存されたブラシ参照を削除します。'),
        ]
    elif topic_id == 'brush_access':
        manual = [
            _t('Quick Tool — activate a commonly used sculpt brush directly from the N-panel.', 'クイックツール — よく使うスカルプトブラシをNパネルから直接有効化します。'),
            _t('Favorite Slot — choose which Tool Pipe slot you want to recall, store, or clear.', 'お気に入りスロット — 呼び出し、保存、クリアを行うツールパイプスロットを選びます。'),
        ]
    elif topic_id == 'tab_all':
        manual = [
            _t('Quick Pie — open the Smart Sculpt quick pie menu from the N-panel.', 'クイックパイ — スマートスカルプトのクイックパイメニューをNパネルから開きます。'),
            _t('Viewport Preset Popup — open the preset chooser without leaving the current panel.', '表示プリセットポップアップ — 現在のパネルを離れずに表示プリセット一覧を開きます。'),
            _t('Profile Popup — open the profile chooser for the active sculpt workflow.', 'プロファイルポップアップ — 現在のスカルプト作業向けプロファイル一覧を開きます。'),
            _t('Full Access — exposes every implemented Smart Sculpt section from one place.', 'フルアクセス — 実装されているスマートスカルプト全セクションへ1か所からアクセスします。'),
        ]
    elif topic_id == 'top_viewport':
        manual = [
            _t('Focus: Ignore Modifiers — choose which modifiers are ignored while focusing the view.', 'フォーカス：無視するモディファイア — 視点を合わせる時に無視するモディファイアを選びます。'),
            _t('Ignored Collections — collections listed here are left out of the navigation focus.', '無視コレクション — ここに入れたコレクションを、ナビゲーションのフォーカスの対象から外します。'),
        ]
    elif topic_id in {'top_brush', 'top_remesh_retopo'}:
        manual = [_t('Mask / Face Set Pie — open the pie menu in Sculpt Mode.', 'マスク/フェイスセットのパイ — スカルプトモードでパイメニューを開きます。')]
        if topic_id == 'top_remesh_retopo':
            manual.append(_t('Selection to Mask — turn the selected vertices into the sculpt mask.', '選択をスカルプトマスクへ — 選択した頂点をスカルプトマスクにします。'))
    elif topic_id == 'analysis_repair':
        manual = [
            _t('Analyze Active Mesh — inspect the current mesh state before large sculpt changes.', 'アクティブメッシュ解析 — 大きなスカルプト変更前に現在のメッシュ状態を検査します。'),
            _t('Run Common Fix — apply the enabled safe cleanup steps to the active mesh.', '共通修正を実行 — 有効化された安全な整理手順をアクティブメッシュへ適用します。'),
            _t('Export Diagnostic Report — write the current inspection result into a reusable text report.', '診断レポートを書き出し — 現在の検査結果を再利用できるテキストレポートへ書き出します。'),
        ]
    return _dedupe_lines(manual)


def _smart_action_function_line(action: str) -> str:
    try:
        from . import properties
        for item in getattr(properties, 'SMART_ACTION_ITEMS', ()) or ():
            if str(item[0]) == action:
                label = str(bpy.app.translations.pgettext_iface(str(item[1])))
                desc = _strip_how_to(_one_language(item[2] if len(item) > 2 else ''))
                return f'{label} — {desc}' if desc else label
    except Exception:
        pass
    return ''


def _edit_mode_module():
    package = str(__package__ or '').strip()
    root = package.rsplit('.core', 1)[0] if '.core' in package else package.rsplit('.', 1)[0]
    return sys.modules.get(f'{root}.edit_mode_sculpt') if root else None


_EDIT_MODE_UI_CACHE: list[tuple[str, list[str], list[str]]] | None = None


def _edit_mode_ui_sections() -> list[tuple[str, list[str], list[str]]]:
    """編集モードの枠を描く関数を読み、節ごとのボタンと設定の項目を返す。"""
    global _EDIT_MODE_UI_CACHE
    if isinstance(_EDIT_MODE_UI_CACHE, list):
        return _EDIT_MODE_UI_CACHE
    sections: list[tuple[str, list[str], list[str]]] = []
    try:
        path = _ADDON_ROOT_DIR / 'edit_mode_sculpt' / '__init__.py'
        tree = ast.parse(path.read_text(encoding='utf-8-sig', errors='ignore'))
        draw = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == 'draw_integrated_ui')
        nodes = sorted((node for node in ast.walk(draw) if isinstance(node, (ast.Call, ast.For))), key=lambda node: (node.lineno, node.col_offset))
        for node in nodes:
            if isinstance(node, ast.For):
                if sections:
                    items = getattr(node.iter, 'elts', None)
                    if items is None and _ast_call_name(node.iter) == '_filter_items':
                        filter_items = getattr(_edit_mode_module(), '_filter_items', None)
                        keys = [str(item[1]) for item in filter_items()] if callable(filter_items) else []
                    else:
                        keys = [_literal_string(item.elts[1]) for item in (items or ()) if isinstance(item, ast.Tuple) and len(item.elts) > 1]
                    sections[-1][1].extend(key for key in keys if key and key not in sections[-1][1])
                continue
            call = node
            name = _ast_call_name(call)
            if name == '_draw_section' and len(call.args) >= 2:
                sections.append((_literal_string(call.args[1]), [], []))
            elif not sections:
                continue
            elif name == '_button' and len(call.args) >= 3:
                key = _literal_string(call.args[2]) if isinstance(call.args[2], ast.Constant) else ''
                if key and key not in sections[-1][1]:
                    sections[-1][1].append(key)
            elif name == 'operator':
                text = _ast_keyword_value(call, 'text')
                key = _literal_string(text) if isinstance(text, ast.Call) and _ast_call_name(text) == 'tr' else ''
                if key and key not in sections[-1][1]:
                    sections[-1][1].append(key)
            elif name == 'prop' and len(call.args) >= 2:
                prop = _literal_string(call.args[1])
                if prop and prop not in sections[-1][2]:
                    sections[-1][2].append(prop)
    except Exception:
        sections = []
    _EDIT_MODE_UI_CACHE = sections
    return sections


def _edit_mode_function_lines() -> list[str]:
    module = _edit_mode_module()
    translate = getattr(module, 'tr', None)
    if not callable(translate):
        return []
    result: list[str] = []
    for section_key, button_keys, _props in _edit_mode_ui_sections():
        names = [str(translate(key)) for key in button_keys]
        if names:
            result.append(f"{translate(section_key)} — {_t(', ', '、').join(names)}")
    return result


def _ui_function_lines(topic_id: str) -> list[str]:
    entries = list(_topic_ui_function_entries().get(topic_id, ()) or ())
    result: list[str] = []
    for op_id, label_en, label_ja, desc in entries:
        if str(op_id or '').strip() in {'smart_sculpt.open_help_popup'}:
            continue
        if str(op_id or '').startswith('smart_action:'):
            line = _smart_action_function_line(str(op_id).split(':', 1)[1])
            if line:
                result.append(line)
            continue
        line = _function_entry_line(label_en, label_ja, desc)
        if line:
            result.append(line)
    return _dedupe_lines(result)


def _topic_function_lines(topic_id: str, context, spec: dict[str, Any]) -> list[str]:
    del spec
    if topic_id == 'always_on':
        return _always_on_function_lines()
    if topic_id == 'edit_mode_sculpt':
        return _edit_mode_function_lines()
    result: list[str] = []
    result.extend(_manual_function_lines(topic_id))
    result.extend(_enum_function_lines(context, topic_id))
    result.extend(_ui_function_lines(topic_id))
    return _dedupe_lines(result)


_TOPIC_DEFS: dict[str, dict[str, Any]] = {
    'always_on': {
        'title_en': 'Always-on Toggles',
        'title_ja': '常時機能切り替え',
        'icon': 'TIME',
        'overview_en': 'This top N-panel group contains only functions that actually need persistent startup or background behavior: N-panel setting synchronization and the Sculpt Navigation runtime/input/draw paths. Ordinary tools stay as UI-only commands until executed.',
        'overview_ja': 'Nパネル最上部のこのグループには、常時起動や背景動作が実際に必要な機能だけを集約しています。対象はNパネル設定同期とスカルプトナビゲーションのランタイム・入力・描画経路で、通常ツールは実行されるまでUI表示だけの軽い状態を維持します。',
        'usage_en': (
            'Use the right-side Enabled/Disabled checkbox buttons. They are direct saved BoolProperties, so Blender consistently draws the blue active overlay when enabled.',
            'Keep N-panel State Save enabled when you want every setting change written immediately to Smart_Sculpt_Suite/Smart_Sculpt_Suite.json; disable it only when you want writes deferred until scene close or Save Preferences.',
            'Enable Sculpt Navigation and its sub-features only when you need those input or overlay behaviors.',
            'Recovery Backups are not a persistent runtime feature, so they are controlled from the Safe/Recovery settings instead of this group.',
        ),
        'usage_ja': (
            '右側の有効/無効チェックボックスボタンで切り替えます。保存済みの設定を直接描画するため、有効時の青いアクティブ表示が安定します。',
            '全設定変更を Smart_Sculpt_Suite/Smart_Sculpt_Suite.json へ即時保存したい場合は、Nパネル状態保存を有効にします。保存を現在のシーンを閉じるタイミングまたはプリファレンス保存時まで遅らせたい場合だけ無効にします。',
            'スカルプトナビゲーションとそのサブ機能は、該当する入力操作やオーバーレイ表示が必要な場合だけ有効にします。',
            '回復バックアップは常時起動ランタイムではないため、このグループではなくセーフ/リカバリー設定から制御します。',
        ),
        'props': ('show_always_on_toggles', 'always_on_npanel_autosave_restore', 'navigation_enabled', 'navigation_canvas_enabled', 'navigation_rmb_enabled', 'navigation_double_click_focus_enabled', 'always_on_navigation_border_overlay'),
    },
    'edit_mode_sculpt': {
        'title_en': 'Edit Mode Sculpt Only',
        'title_ja': '編集モード専用スカルプト',
        'icon': 'EDITMODE_HLT',
        'overview_en': 'This section embeds the Strict Edit Mode Sculpt toolset directly inside Smart Sculpt Suite. Brush-style deformation, mesh filters, masks, Face Sets, vertex color operations, and topology helpers are executed while the active mesh stays in Mesh Edit Mode whenever the operation can safely run there.',
        'overview_ja': 'このセクションは厳密編集モードスカルプトのツールセットをスマートスカルプトスイート内へ直接組み込んだものです。ブラシ風変形、メッシュフィルター、マスク、フェイスセット、頂点カラー操作、トポロジー補助を、可能な限りアクティブメッシュをメッシュ編集モードのまま実行します。',
        'usage_en': (
            'Direct Brush keys: LMB stroke | Ctrl invert | Shift smooth | F radius | Shift+F strength | [ ] radius | -/+ or Shift+[ ] strength | Ctrl+Wheel strength | E falloff pie | Shift+E cycle falloff | V/S/P/I/G/Shift+T/C/Shift+C/K/M switch brush | Esc/RMB finish',
            'Selection tool keys: LMB drag/click: define area | Ctrl: erase/invert where supported | Esc/RMB: cancel',
            'Recommended keymap location: Preferences > Keymap > 3D View > Mesh > Mesh Edit Mode',
            'Native sculpt operators are checked in the current Edit Mode context. No mode change is performed.',
            'Only the Sculpt Mode toggle can poll true here; it is intentionally not used by this add-on.',
            'Select a mesh object and enter Mesh Edit Mode before using this section.',
            'Keep Enable on when you want the embedded edit-mode sculpt operators to affect the selected or visible edit mesh vertices.',
            'Choose a brush/tool, then use Direct Brush, filter buttons, mask operations, Face Set operations, color operations, or topology operations from this section.',
            'Smart Sculpt brush/profile/filter buttons route to compatible edit-mode sculpt settings while this section is active in Mesh Edit Mode.',
        ),
        'usage_ja': (
            '直接ブラシのキー：LMB: ストローク | Ctrl: 反転 | Shift: スムーズ | F: 半径 | Shift+F: 強さ | [ ]: 半径 | -/+ または Shift+[ ]: 強さ | Ctrl+ホイール: 強さ | E: フォールオフパイ | Shift+E: フォールオフ循環 | V/S/P/I/G/Shift+T/C/Shift+C/K/M: ブラシ切替 | Esc/RMB: 終了',
            '範囲指定ツールのキー：LMBドラッグ/クリック: 範囲指定 | Ctrl: 対応処理の消去・反転 | Esc/RMB: キャンセル',
            '推奨登録場所: プリファレンス > キーマップ > 3Dビュー > メッシュ > メッシュ編集モード',
            '現在の編集モードコンテキストで標準のスカルプト機能を検査します。モード切り替えは行いません。',
            'ここで有効になり得るのはスカルプトモード切替のみです。このアドオンでは意図的に使用しません。',
            'メッシュオブジェクトを選択し、メッシュ編集モードに入ってからこのセクションを使用します。',
            '選択中または表示中の編集メッシュ頂点へ組み込み編集モードスカルプト処理を適用したい場合は、有効をオンにします。',
            'ブラシまたはツールを選択し、このセクション内の直接ブラシ、フィルターボタン、マスク操作、フェイスセット操作、カラー操作、トポロジー操作を使用します。',
            'メッシュ編集モードでこのセクションが有効な場合、スマートスカルプト側のブラシ、プロファイル、フィルターボタンは互換する編集モードスカルプト設定へ送られます。',
        ),
        'props': (),
    },
    'tab_sculpt': {
        'title_en': 'Sculpt Tab',
        'title_ja': 'スカルプトタブ',
        'icon': 'SCULPTMODE_HLT',
        'overview_en': 'The Sculpt tab collects workspace preparation, active mesh analysis, common fixes, viewport presets, brush activation, and personal brush slots for day-to-day sculpting.',
        'overview_ja': 'スカルプトタブは、作業空間準備、アクティブメッシュ解析、共通修正、表示プリセット、ブラシ有効化、個人用ブラシスロットを日常的なスカルプト作業向けにまとめたタブです。',
        'usage_en': ('Start with workspace preparation or analysis.', 'Apply a viewport preset and profile.', 'Activate a brush directly or recall one of your stored Tool Pipe slots.'),
        'usage_ja': ('まず作業空間準備または解析を実行します。', '表示プリセットとプロファイルを適用します。', 'ブラシを直接有効化するか、ツールパイプに保存したスロットを呼び出します。'),
        'props': SCULPT_PROPS,
    },
    'tab_smart': {
        'title_en': 'Smart Upgrade Tab',
        'title_ja': 'スマートアップグレードタブ',
        'icon': 'AUTO',
        'overview_en': 'The Smart Upgrade tab converts the attached sculpt-support feature list into Blender-native upper-compatible tools and now adds Supreme sculpt precision controls with Apex Autopilot Pass, Supreme Studio Pipeline, Precision Frontier Pass, adaptive mesh scaling, semantic face attributes, curvature proxy groups, Apex intelligence groups, and score-guided reports. It includes Adaptive Master Pass, Mesh Doctor Pro, Surface Detail Synth, Sculpt Layer Stack Pro, and Symmetry Pose Guard as higher-level orchestration actions, then covers ZBrush-style quick groups and anchor workflows, Multisculpt-style multi-object sessions, BSpheres/ZSpheres base forms, Hard Ops/Box Cutter/Modlt hard-surface cutting, 3D-Coat-like voxel hybrid surfaces, Houdini/PolyCloth cloth shaping, Modo/Maya layer-driver workflows, WrapIt/Quad Remesher/Unwrella-style retopo and UV, Geometry Nodes/Node Room-style procedural microdetail, ziRail/Curve Sweep construction, Forest Pack/ZENV/Zoo Tools-style growth helpers, photo-reference handoff, GoZ/USD-style exchange, and Mesh Cleaner-style repair.',
        'overview_ja': 'スマートアップグレードタブは、添付スカルプト支援機能リストをBlenderネイティブの上位互換系ツールへ変換し、自動最適パス、最上位スタジオ処理、高精度仕上げパス、メッシュ適応スケール、意味別フェース属性、曲率代理グループ、最上位知能グループ、スコア誘導レポートを持つ最上位スカルプト精度制御を追加したものです。上位統合アクションとして適応マスターパス、メッシュ診断プロ、表面ディテール合成、スカルプトレイヤー重ねプロ、対称ポーズ保護を含み、さらにZBrush風クイックグループとアンカー系、Multisculpt風複数オブジェクトセッション、BSpheres/ZSpheres風ベース形状、Hard Ops/Box Cutter/Modlt風ハードサーフェスカット、3D-Coat風ボクセルハイブリッド表面、Houdini/PolyCloth風クロス形成、Modo/Maya風レイヤードライバー、WrapIt/Quad Remesher/Unwrella風リトポとUV、Geometry Nodes/Node Room風プロシージャル微細ディテール、ziRail/カーブスイープ系構築、Forest Pack/ZENV/Zoo Tools風成長ヘルパー、画像参照受け渡し、GoZ/USD風受け渡し、Mesh Cleaner風修復を扱います。',
        'usage_en': ('Choose the Smart Upgrade Action that matches the workflow you want to approximate.', 'The available actions are listed in "2. Functions".' , 'Set Smart Quality first; High is the recommended default, Ultra and Frontier are for heavier production assets after saving; Apex is the maximum diagnostic and helper-density mode.', 'Keep Auto Preflight, Safety Snapshot, Prefer Non-Destructive, and Write Precision Report enabled when comparing or replacing other sculpt tools.', 'Inspect the generated SSS_Smart_Supreme_Report text block after complex actions.', 'Generated files use the Smart_Sculpt_Suite folder in the Blender config folder unless you manually set an exchange folder.'),
        'usage_ja': ('近似したいワークフローに対応するスマートアップグレードアクションを選びます。', '選べるアクションは「2. 機能一覧」に並んでいます。', 'まずスマート品質を設定します。通常は「高」を推奨で、ウルトラと先端は保存後の重い制作アセット向けで、最上位は最大診断・最大ヘルパー密度モードです。', '他のスカルプトツールを置き換えたり比較したりする場合は、事前検査、安全スナップショット、非破壊優先、精度レポートを有効にしておきます。', '複雑な処理後は、生成されるSSS_Smart_Supreme_Reportテキストブロックを確認します。', '手動で受け渡しフォルダを指定しない限り、生成ファイルは Blender の設定フォルダー内の Smart_Sculpt_Suite に保存します。'),
        'props': SMART_PROPS,
    },
    'smart_precision_ui': {
        'title_en': 'Smart Precision UI',
        'title_ja': 'スマート精度UI',
        'icon': 'SEQ_STRIP_META',
        'overview_en': 'The Smart Precision UI adds a live mesh-readiness panel, a selected-action card, and Smart Action button frames under each heading. Each button shows the icon and name of its action.',
        'overview_ja': 'スマート精度UIは、ライブメッシュ準備度パネル、選択アクションカード、各見出しの中のスマートアクションのボタンの枠を追加します。各ボタンにはアクションのアイコンと名前が出ます。',
        'usage_en': ('Smart Action Buttons shows or hides the Smart Action button frames under each heading (Workflow Smart Actions, Brush Smart Actions and so on).', 'Enable Live Metrics to check score, face count, quad ratio, risk edges, UV count, and shape-layer count before running heavy operations.', 'Use Icon Size to scale the button height.', 'When Photo Reference Handoff has no user image path, Smart Sculpt uses its packaged reference board instead of generating files outside the extension folder.'),
        'usage_ja': ('「スマートアクションボタン」は、各見出しの中のスマートアクションのボタンの枠（「ワークフロースマート実行」「ブラシスマート実行」など）を出すか隠すかを決めます。', '「メッシュの現在の指標を表示」を有効にすると、重い処理前にスコア、面数、四角面比率、リスク辺、UV数、形状レイヤー数を確認できます。', '「スマート操作のアイコンの大きさ」でボタンの高さを調整します。', '写真リファレンス連携でユーザー画像パスが空の場合、拡張機能フォルダ内の同梱リファレンスボードを使い、外部へ自動生成しません。'),
        'props': ('smart_upgrade_show_icon_board', 'smart_upgrade_show_metrics', 'smart_upgrade_icon_scale', 'smart_upgrade_action', 'smart_upgrade_quality'),
    },
    'smart_compatibility_map': {
        'title_en': 'Smart Compatibility Map',
        'title_ja': 'スマート互換マップ',
        'icon': 'INFO',
        'overview_en': 'The compatibility map explains which external sculpt workflow each Smart action approximates and what Blender-native mechanism is used instead. The Apex precision UI upgrade adds Apex Autopilot Pass, Supreme Studio Pipeline, Precision Frontier Pass, explicit high-level orchestration actions, mesh-measured adaptive scaling, semantic face attributes, curvature proxy vertex groups, Apex intelligence vertex groups, surface-sampled guides and growth helpers, edge-packed borderless custom icon buttons drawn as full-width one-column command buttons, live mesh readiness metrics, aspect-preserving photo reference boards, and a shared quality preset, auto preflight, non-destructive preference, target-face scaling, and internal precision reports so every action can be inspected and iterated. It is an implementation map, not a bundled copy of third-party tools.',
        'overview_ja': '互換マップは、各スマートアクションがどの外部スカルプトワークフローを近似し、代わりにどのBlenderネイティブ機構を使うかを説明します。最上位精度UIアップグレードでは、自動最適パス、最上位スタジオ処理、高精度仕上げパス、明示的な上位統合アクション、メッシュ測定に基づく適応スケーリング、意味別フェース属性、曲率代理頂点グループ、最上位知能頂点グループ、表面サンプリング型ガイドと成長ヘルパー、アイコン付きのボタンを全幅1列のコマンドとして表示するUI、ライブメッシュ準備度、画像比率保持の参照ボード、共通品質プリセット、事前検査、非破壊優先、目標面数スケーリング、内部精度レポートを追加し、すべてのアクションを検査・反復しやすくしています。これは実装マップであり、サードパーティツールの同梱コピーではありません。',
        'usage_en': ('Read the active action description before running unfamiliar tools.', 'Use High quality for normal production; use Ultra, Frontier, or Apex only when the increased helper density is intentional and the file is saved.', 'Prefer non-destructive actions first, then apply modifiers only after review.', 'Use the Safe tab snapshots and recovery backups before destructive remesh, boolean, UV, or slicing actions.', 'Open the precision report text block after complex conversions or cleanup.'),
        'usage_ja': ('不慣れなツールを実行する前に、現在のアクション説明を確認します。', '通常制作では「高」の品質を使い、ヘルパー密度増加を意図しファイル保存済みの時だけウルトラ、先端、最上位を使います。', 'まず非破壊アクションを優先し、確認後にだけモディファイアを適用します。', '破壊的なリメッシュ、ブーリアン、UV、スライス前には安全タブのスナップショットと回復バックアップを使います。', '複雑な変換や整理後は精度レポートのテキストブロックを開いて確認します。'),
        'props': SMART_PROPS,
    },
    'tab_surface': {
        'title_en': 'Surface Tab',
        'title_ja': 'サーフェイスタブ',
        'icon': 'MOD_REMESH',
        'overview_en': 'The Surface tab contains topology and surface-editing operations: Dyntopo, voxel and QuadriFlow remesh, Multires, masks, Face Sets, filters, retopo helpers, and UV projection.',
        'overview_ja': 'サーフェイスタブは、ダイナミックトポロジー、ボクセル/クアッドリメッシュ、マルチレゾ、マスク、フェイスセット、フィルター、リトポ補助、UV展開など、トポロジと表面編集操作をまとめています。',
        'usage_en': ('Choose the Surface Action selector first.', 'Adjust only the parameters shown for that action.', 'Run the action after confirming the active mesh and mode.'),
        'usage_ja': ('最初にサーフェイスアクションを選びます。', 'そのアクションに表示される必要なパラメータだけを調整します。', 'アクティブメッシュとモードを確認してから実行します。'),
        'props': SURFACE_PROPS,
    },
    'tab_build': {
        'title_en': 'Build Tab',
        'title_ja': 'ビルドタブ',
        'icon': 'MESH_CUBE',
        'overview_en': 'The Build tab creates sculpt-friendly construction geometry: primitives, selection booleans, rail cutters, sphere chains, curve tubes, scattered details, bend anchors, and procedural stacks.',
        'overview_ja': 'ビルドタブは、プリミティブ、選択ブーリアン、レールカッター、スフィアチェーン、カーブチューブ、ディテール散布、ベンドアンカー、プロシージャルスタックなど、造形用の構築ジオメトリを作成します。',
        'usage_en': ('Choose the Build Action selector.', 'Set size, axis, boolean, or scatter options as needed.', 'Run the create action and inspect the generated helper or result before destructive follow-up steps.'),
        'usage_ja': ('ビルドアクションを選びます。', '必要に応じてサイズ、軸、ブーリアン、散布設定を調整します。', '作成後は生成されたヘルパーや結果を確認してから破壊的な次工程へ進みます。'),
        'props': BUILD_PROPS,
    },
    'tab_safe': {
        'title_en': 'Safe Tab',
        'title_ja': '安全タブ',
        'icon': 'RECOVER_LAST',
        'overview_en': 'The Safe tab handles checkpoints, recovery backups, shape layers, sculpt sessions, transfer/export workflows, and generated-data cleanup.',
        'overview_ja': '安全タブは、チェックポイント、回復バックアップ、シェイプレイヤー、スカルプトセッション、受け渡し/書き出し、生成データ整理を扱います。',
        'usage_en': ('Save a snapshot before risky operations.', 'Use recovery only for the active object backup created by Smart Sculpt.', 'Use sessions and transfer tools when working across multiple objects or external tools.'),
        'usage_ja': ('危険な操作の前にスナップショットを保存します。', '回復機能はスマートスカルプトが作成したアクティブオブジェクト用バックアップに対して使います。', '複数オブジェクトや外部ツールをまたぐ作業では、セッションと受け渡し機能を使います。'),
        'props': SAFE_PROPS,
    },
    'tab_settings': {
        'title_en': 'Settings Tab',
        'title_ja': '設定タブ',
        'icon': 'PREFERENCES',
        'overview_en': 'The Settings tab exposes the editable scene and tool settings used by Smart Sculpt and integrated tools. The N-panel is the only settings UI; native add-on preference properties are not used. Values are saved to Smart_Sculpt_Suite.json in the Blender 5.1 config directory. When N-panel State Save is enabled, changes are written immediately; when it is disabled, changes are written only when the current scene closes or Save Preferences is run.',
        'overview_ja': '設定タブは、スマートスカルプト本体と統合ツールが使用する編集可能なシーン設定・ツール設定を表示します。設定UIはNパネルのみで、通常のアドオンプリファレンスのプロパティは使用しません。値は Blender 5.1 の設定フォルダーにある Smart_Sculpt_Suite.json へ保存します。Nパネル状態保存が有効な場合は即時保存し、無効な場合は現在のシーンを閉じる時またはプリファレンス保存時だけ保存します。',
        'usage_en': ('Change values here when you want a persistent default or workflow-wide behavior.', 'Use per-tool Help buttons for explanations before changing unfamiliar options.', 'Open another scene or restart Blender to reuse the same N-panel state. When N-panel State Save is enabled, each change is written immediately; when disabled, the write occurs on scene close or Save Preferences.', 'On Windows, N-panel settings are stored in C:/Users/<user name>/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Sculpt_Suite/Smart_Sculpt_Suite.json. Automatically generated exchange files also use the Smart_Sculpt_Suite folder in the Blender config folder unless you manually choose another directory.'),
        'usage_ja': ('永続的な既定値やワークフロー全体の挙動を変えたい時にここで設定します。', '不明な項目は各ツールのヘルプボタンで意味を確認してから変更します。', '別シーンを開いた時や Blender 再起動後も同じNパネル状態を再利用できます。Nパネル状態保存が有効な場合は各変更を即時保存し、無効な場合はシーン終了時またはプリファレンス保存時に書き込みます。', 'Windowsでは、Nパネル設定を C:/Users/ユーザー名/AppData/Roaming/Blender Foundation/Blender/5.1/config/Smart_Sculpt_Suite/Smart_Sculpt_Suite.json へ保存します。自動生成される受け渡しファイルも、手動で別フォルダを選んだ場合を除き、Blender の設定フォルダー内の Smart_Sculpt_Suite 配下に収めます。'),
        'props': SETTINGS_PROPS,
        'include_preferences': True,
    },
    'tab_all': {
        'title_en': 'All Tools Tab',
        'title_ja': '全ツールタブ',
        'icon': 'TOOL_SETTINGS',
        'overview_en': 'The All Tools tab exposes the full Smart Sculpt command surface for users who need direct access to every implemented section in one view.',
        'overview_ja': '全ツールタブは、実装済みの全セクションへ1画面から直接アクセスしたいユーザー向けに、スマートスカルプトの操作面をまとめて表示します。',
        'usage_en': ('Use this tab for inspection, troubleshooting, or direct access.', 'For regular work, the compact Sculpt, Surface, Build, Safe, and Settings tabs are lighter and easier to navigate.'),
        'usage_ja': ('確認、トラブルシュート、直接アクセスが必要な時に使います。', '通常作業では、スカルプト、サーフェイス、ビルド、安全、設定のコンパクトタブを使う方が軽く見通しも良くなります。'),
        'props': SETTINGS_PROPS,
    },
    'core_workflow': {
        'title_en': 'Core Workflow',
        'title_ja': 'コアワークフロー',
        'icon': 'TOOL_SETTINGS',
        'overview_en': 'Core Workflow prepares the scene and active mesh, cycles sculpt parts, runs analysis, fixes common mesh issues, and exports diagnostics.',
        'overview_ja': 'コアワークフローは、シーンとアクティブメッシュの準備、スカルプトパーツの切り替え、解析、一般的なメッシュ問題の修正、診断書き出しを行います。',
        'usage_en': ('Select the Core Workflow action.', 'Review any action-specific options.', 'Run the action button and read diagnostics before moving to destructive steps.'),
        'usage_ja': ('コアワークフローの操作を選びます。', '操作ごとの追加オプションを確認します。', '実行後は診断内容を確認してから破壊的な工程へ進みます。'),
        'props': ('core_action', 'multi_object_make_single_user', 'apply_scale_on_fix', 'recalc_normals_on_fix', 'delete_loose_on_fix', 'dissolve_degenerate_on_fix', 'degenerate_threshold_on_fix', 'merge_distance_on_fix', 'auto_enter_sculpt'),
    },
    'analysis_repair': {
        'title_en': 'Analysis and Repair',
        'title_ja': '解析と修復',
        'icon': 'CHECKMARK',
        'overview_en': 'Analysis and Repair checks the active mesh, reports detected issues, and applies the selected safe repair options such as scale application, normal recalculation, loose geometry removal, degenerate cleanup, and vertex merging.',
        'overview_ja': '解析と修復は、アクティブメッシュを確認して検出結果を表示し、スケール適用、法線再計算、孤立ジオメトリ削除、縮退整理、頂点マージなど、選択した修復項目を実行します。',
        'usage_en': ('Run Analyze first to see the current findings.', 'Enable only the repair steps you actually want to apply.', 'Run Fix, then review Current Findings or export a report when you need a text record.'),
        'usage_ja': ('まず解析を実行して現在の検出結果を確認します。', '実際に適用したい修復項目だけを有効にします。', '修正を実行した後、現在の検出結果を確認し、記録が必要な場合はレポートを書き出します。'),
        'props': ('core_action', 'apply_scale_on_fix', 'recalc_normals_on_fix', 'delete_loose_on_fix', 'dissolve_degenerate_on_fix', 'degenerate_threshold_on_fix', 'merge_distance_on_fix', 'diagnostics'),
    },
    'view_profile': {
        'title_en': 'View and Profile',
        'title_ja': '表示とプロファイル',
        'icon': 'SHADING_SOLID',
        'overview_en': 'View and Profile applies viewport presets and workflow profiles so the sculpting view and default behavior can be switched quickly.',
        'overview_ja': '表示とプロファイルは、表示プリセットとワークフロープロファイルを適用し、スカルプト表示と既定挙動を素早く切り替えます。',
        'usage_en': ('Select a viewport preset such as clay, technical, Face Sets, or wireframe.', 'Apply the preset, then choose and apply a workflow profile if needed.'),
        'usage_ja': ('クレイ、テクニカル、フェイスセット、ワイヤーフレームなどの表示プリセットを選びます。', '表示を適用し、必要ならワークフロープロファイルも選んで適用します。'),
        'props': ('compact_viewport_preset', 'profile'),
    },
    'brush_access': {
        'title_en': 'Brush Access',
        'title_ja': 'ブラシアクセス',
        'icon': 'BRUSH_DATA',
        'overview_en': 'Brush Access activates sculpt brushes and manages three personal Tool Pipe slots for one-click recall.',
        'overview_ja': 'ブラシアクセスは、スカルプトブラシの有効化と、ワンクリック呼び出し用の個人用ツールパイプスロット3本を管理します。',
        'usage_en': ('Choose a brush from Quick Tool and activate it.', 'Store the current brush into a slot, then recall it later from the same slot.'),
        'usage_ja': ('クイックツールからブラシを選んで有効化します。', '現在のブラシをスロットへ保存し、後で同じスロットから呼び出します。'),
        'props': ('quick_tool', 'tool_pipe_slot_index', 'tool_pipe_slot_1', 'tool_pipe_slot_2', 'tool_pipe_slot_3', 'tool_pipe_slot_1_tool', 'tool_pipe_slot_2_tool', 'tool_pipe_slot_3_tool'),
    },
    'surface_actions': {'title_en': 'Surface Actions', 'title_ja': 'サーフェイスアクション', 'icon': 'MOD_REMESH', 'overview_en': 'Surface Actions run topology, mask, Face Set, filter, retopo, and UV operations from a compact selector.', 'overview_ja': 'サーフェイスアクションは、トポロジ、マスク、フェイスセット、フィルター、リトポ、UV操作をコンパクトな選択式UIから実行します。', 'usage_en': ('Pick the action type first.', 'Set the displayed parameters only for that action.', 'Run the action on the active sculpt mesh.'), 'usage_ja': ('最初に操作タイプを選びます。', 'その操作に表示されるパラメータだけ調整します。', 'アクティブなスカルプトメッシュに対して実行します。'), 'props': SURFACE_PROPS},
    'build_actions': {'title_en': 'Build Actions', 'title_ja': '造形アクション', 'icon': 'MESH_CUBE', 'overview_en': 'Build Actions create helper geometry and construction forms for sculpt blockouts, hard-surface cuts, repeated details, and procedural texture bases.', 'overview_ja': '造形アクションは、スカルプトのブロックアウト、ハードサーフェスカット、繰り返しディテール、プロシージャル質感ベース用のヘルパー形状を作成します。', 'usage_en': ('Select the build type.', 'Set dimensions, axis, boolean behavior, or randomization.', 'Create the helper and inspect the result before applying destructive steps.'), 'usage_ja': ('作成タイプを選びます。', '寸法、軸、ブーリアン挙動、ランダム化を設定します。', 'ヘルパーを作成し、破壊的処理の前に結果を確認します。'), 'props': BUILD_PROPS},
    'snapshots': {'title_en': 'Snapshots', 'title_ja': 'スナップショット', 'icon': 'RECOVER_LAST', 'overview_en': 'Snapshots store mesh checkpoints on the active object so you can preview, restore, or delete saved states during sculpting.', 'overview_ja': 'スナップショットは、アクティブオブジェクト上にメッシュのチェックポイントを保存し、スカルプト中に比較表示、復元、削除できるようにします。', 'usage_en': ('Save before risky edits.', 'Preview to compare the stored state.', 'Restore only when you intentionally want to replace the current mesh with the snapshot.'), 'usage_ja': ('危険な編集の前に保存します。', '比較表示で保存状態を確認します。', '現在のメッシュを保存状態で置き換えたい時だけ復元します。'), 'props': ('snapshot_action', 'cleanup_include_snapshots')},
    'recovery': {'title_en': 'Recovery', 'title_ja': '回復', 'icon': 'RECOVER_LAST', 'overview_en': 'Recovery uses hidden per-object backups created before destructive Smart Sculpt operations.', 'overview_ja': '回復は、スマートスカルプトの破壊的操作前に作成されるオブジェクト単位の隠しバックアップを使用します。', 'usage_en': ('Keep Recovery Backups enabled for safer destructive work.', 'Restore only when the current mesh result is invalid or unwanted.', 'Clear backups after confirming the final result.'), 'usage_ja': ('安全な破壊的作業のため、通常は回復バックアップを有効にします。', '現在のメッシュ結果が壊れた、または不要な場合だけ復元します。', '最終結果を確認した後に不要なバックアップを削除します。'), 'props': ('recovery_action', 'enable_recovery_backups')},
    'shape_layers': {'title_en': 'Shape Layers', 'title_ja': 'シェイプレイヤー', 'icon': 'SHAPEKEY_DATA', 'overview_en': 'Shape Layers create, duplicate, delete, and drive shape keys used as sculpt layers.', 'overview_ja': 'シェイプレイヤーは、スカルプトレイヤーとして使うシェイプキーの作成、複製、削除、ドライバー設定を行います。', 'usage_en': ('Use Create to add a sculpt layer.', 'Use Duplicate or Delete on the active layer.', 'Use Drive when a bone transform should control the layer value.'), 'usage_ja': ('「作成」でスカルプトレイヤーを追加します。', '「複製」や「削除」はアクティブレイヤーに対して使います。', 'ボーン変形でレイヤー値を制御したい場合は「駆動」を使います。'), 'props': ('layer_action', 'driver_bone', 'driver_channel', 'driver_min', 'driver_max')},
    'sculpt_session': {'title_en': 'Sculpt Session', 'title_ja': 'スカルプトセッション', 'icon': 'DUPLICATE', 'overview_en': 'Sculpt Session builds unified or proxy work objects from multiple source meshes for cross-part sculpting.', 'overview_ja': 'スカルプトセッションは、複数ソースメッシュから統合またはプロキシ作業用オブジェクトを作り、パーツをまたいだスカルプトを行いやすくします。', 'usage_en': ('Choose Unified for preserving separated parts.', 'Choose Proxy when a lighter voxelized work object is preferred.', 'Restore or Close the session after checking the generated result.'), 'usage_ja': ('分離パーツを保ちたい場合は「統合」を選びます。', '軽いボクセル化作業オブジェクトが欲しい場合は「プロキシ」を選びます。', '生成結果を確認した後、復元または終了を実行します。'), 'props': ('session_action', 'session_mode', 'session_face_set_mode', 'session_initialize_face_sets', 'hide_originals_on_proxy')},
    'transfer_cleanup': {'title_en': 'Transfer and Cleanup', 'title_ja': '受け渡しと整理', 'icon': 'IMPORT', 'overview_en': 'Transfer and Cleanup exports or imports handoff files and removes generated helper data when it is no longer needed. Leaving the folder blank keeps automatic handoff files inside the Smart_Sculpt_Suite folder in the Blender config folder; only a manually chosen folder is allowed to write elsewhere.', 'overview_ja': '受け渡しと整理は、外部連携用ファイルの書き出し/読み込みと、不要になった生成ヘルパーデータの削除を行います。フォルダ未指定時の自動受け渡しファイルは Blender の設定フォルダー内の Smart_Sculpt_Suite に保存し、別の場所へ書き出すのは手動でフォルダを選んだ場合だけです。', 'usage_en': ('Set folder, format, and scope before exporting; leave the folder blank to use the add-on controlled CONFIG exchange folder.', 'Use Import Latest to bring back the newest handoff file.', 'Run cleanup only after confirming helper data is no longer needed.'), 'usage_ja': ('書き出し前にフォルダ、形式、対象範囲を設定します。フォルダーを空欄にすると Blender の設定フォルダー内の受け渡しフォルダを使います。', '「最新版を読み込み」で最新受け渡しファイルを戻します。', 'ヘルパーデータが不要になったことを確認してから整理を実行します。'), 'props': ('transfer_action', 'exchange_dir', 'exchange_format', 'exchange_scope', 'exchange_timestamped_export', 'cleanup_include_snapshots')},
    'settings_all': {'title_en': 'All Settings', 'title_ja': '全設定', 'icon': 'PREFERENCES', 'overview_en': 'This help page lists every Smart Sculpt scene setting and available tool setting registered in the N-panel settings area.', 'overview_ja': 'このヘルプは、Nパネル設定領域に登録されているスマートスカルプトのシーン設定と利用可能なツール設定を一覧化します。', 'usage_en': ('Use this page as a reference before changing unfamiliar values.', 'N-panel settings are saved immediately to the Smart_Sculpt_Suite folder in the Blender config folder, mirrored to Blender Preferences, and restored after Blender restarts or another scene is opened.', 'Blender Save Preferences and the N-panel Save Preferences command preserve the mirrored N-panel state; the add-on preferences editor is not used for editing these values.', 'The only intentional write-location exception is an exchange directory that you choose manually.'), 'usage_ja': ('不明な値を変更する前のリファレンスとして使います。', 'Nパネル設定は Blender の設定フォルダー内の Smart_Sculpt_Suite へ即時保存され、Blenderプリファレンスにも反映され、Blender再起動後や別シーンを開いた後も復元されます。', 'Blender の「プリファレンスの保存」とNパネルの保存コマンドは、ミラー保存されたNパネル状態を維持します。これらの値の編集にアドオンプリファレンス画面は使いません。', '書き込み先の例外は、ユーザーが手動で指定した受け渡しディレクトリだけです。'), 'props': SETTINGS_PROPS, 'include_preferences': True},
    'quick_tools': {'title_en': 'Quick Tools', 'title_ja': 'クイックツール', 'icon': 'BRUSH_DATA', 'overview_en': 'Quick Tools directly activates common Blender sculpt brushes from the Smart Sculpt N-panel.', 'overview_ja': 'クイックツールは、Blenderの主要スカルプトブラシをスマートスカルプト Nパネルから直接有効化します。', 'usage_en': ('Click a brush button to switch the active sculpt tool.', 'If a Blender build renames a tool ID, Smart Sculpt tries safe fallbacks instead of sending empty tool names.'), 'usage_ja': ('ブラシボタンをクリックすると、アクティブなスカルプトツールを切り替えます。', 'BlenderのバージョンでツールIDが変わった場合も、スマートスカルプトは空のツール名を送らず安全なフォールバックを試します。'), 'props': ('quick_tool',)},
    'tool_pipe': {'title_en': 'Tool Pipe', 'title_ja': 'ツールパイプ', 'icon': 'BRUSH_DATA', 'overview_en': 'Tool Pipe stores three personal brush slots for fast recall.', 'overview_ja': 'ツールパイプは、素早く呼び出すための個人用ブラシスロットを3つ保存します。', 'usage_en': ('Store the current brush into a slot.', 'Use the slot to restore the brush later.', 'Clear a slot when you no longer need it.'), 'usage_ja': ('現在のブラシをスロットへ保存します。', '後でそのスロットからブラシを呼び出します。', '不要になったスロットはクリアします。'), 'props': ('tool_pipe_slot_1', 'tool_pipe_slot_2', 'tool_pipe_slot_3', 'tool_pipe_slot_1_tool', 'tool_pipe_slot_2_tool', 'tool_pipe_slot_3_tool')},
    'exchange': {'title_en': 'Exchange', 'title_ja': '受け渡し', 'icon': 'IMPORT', 'overview_en': 'Exchange handles quick round-trip export and import for external sculpt, modeling, or pipeline tools. When the folder is blank, Smart Sculpt uses its own exchange folder under the Smart_Sculpt_Suite folder in the Blender config folder; a different location is used only when you manually set one.', 'overview_ja': '受け渡しは、外部スカルプト、モデリング、パイプラインツールとの簡易往復用の書き出し・読み込みを行います。フォルダが空欄の場合は Blender の設定フォルダー内の Smart_Sculpt_Suite にあるスマートスカルプト専用受け渡しフォルダを使い、別の場所は手動指定した場合だけ使います。', 'usage_en': ('Leave the folder blank to keep generated exchange files inside the Smart_Sculpt_Suite folder in the Blender config folder.', 'Choose the format and scope before exporting.', 'Use Import Latest when the external result should return to Blender.'), 'usage_ja': ('生成される受け渡しファイルを Blender の設定フォルダー内の Smart_Sculpt_Suite に収めたい場合はフォルダを空欄にします。', '書き出し前に形式と対象範囲を選びます。', '外部結果を Blender へ戻す時は最新受け渡しを読み込みます。'), 'props': ('exchange_dir', 'exchange_format', 'exchange_scope', 'exchange_timestamped_export')},
    'dyntopo': {'title_en': 'Dyntopo', 'title_ja': 'ダイナミックトポロジー', 'icon': 'SCULPTMODE_HLT', 'overview_en': 'Dyntopo configures and applies Blender Dynamic Topology support for sculpting with local tessellation.', 'overview_ja': 'ダイナミックトポロジーは、局所的な細分化を使うスカルプト向けにBlenderのダイナミックトポロジーを設定・適用します。', 'usage_en': ('Choose the detail measurement mode.', 'Set the detail amount.', 'Configure Dyntopo or run detail flood fill as needed.'), 'usage_ja': ('ディテール計測方式を選びます。', '細かさを設定します。', '必要に応じてダイナミックトポロジー設定またはディテール均一化を実行します。'), 'props': ('dyntopo_mode', 'dyntopo_detail')},
    'voxel_remesh': {'title_en': 'Voxel and Remesh', 'title_ja': 'ボクセルとリメッシュ', 'icon': 'MOD_REMESH', 'overview_en': 'Voxel and Remesh rebuilds surface topology using voxel remesh or QuadriFlow.', 'overview_ja': 'ボクセルとリメッシュは、ボクセルリメッシュまたはクアッドリメッシュを使って表面トポロジを再構築します。', 'usage_en': ('Use voxel remesh for robust sculpt cleanup.', 'Use QuadriFlow when quad-like topology is preferred.', 'Check target size before running destructive remesh operations.'), 'usage_ja': ('安定したスカルプト整理にはボクセルリメッシュを使います。', '四角面寄りのトポロジが欲しい場合はクアッドリメッシュを使います。', '破壊的リメッシュの前に目標サイズを確認します。'), 'props': ('compact_remesh_mode', 'voxel_size', 'voxel_adaptivity', 'quad_target_faces')},
    'multires': {'title_en': 'Multires', 'title_ja': 'マルチレゾ', 'icon': 'MOD_MULTIRES', 'overview_en': 'Multires creates or manages Blender Multiresolution levels for sculpt workflows.', 'overview_ja': 'マルチレゾは、スカルプトワークフロー用のBlenderのマルチレゾレベルを作成・管理します。', 'usage_en': ('Add a Multires setup when the object needs subdividable sculpt levels.', 'Use level up or down for display control.', 'Apply Base only when you intentionally want to commit base changes.'), 'usage_ja': ('細分化レベルを持つスカルプトが必要な時にマルチレゾを追加します。', '表示制御にはレベル上下を使います。', '「ベースに適用」はベース変更を確定したい時だけ使います。'), 'props': ('compact_multires_action', 'multires_levels')},
    'mask_facesets': {'title_en': 'Mask and Face Sets', 'title_ja': 'マスクとフェイスセット', 'icon': 'MOD_MASK', 'overview_en': 'Mask and Face Sets provides mask edits, mask extraction, mask slicing, Face Set generation, visibility, color randomization, and Face Set extraction.', 'overview_ja': 'マスクとフェイスセットは、マスク編集、マスク抽出、マスクスライス、フェイスセット生成、表示制御、色ランダム化、フェイスセット抽出を扱います。', 'usage_en': ('Use mask actions for current sculpt mask cleanup.', 'Use Face Set actions to group visible or semantic regions.', 'Use Extract or Slice when a selected region should become a new object.'), 'usage_ja': ('現在のスカルプトマスク整理にはマスク操作を使います。', '表示領域や意味のある領域をまとめるにはフェイスセット操作を使います。', '選択領域を新規オブジェクト化したい時は抽出またはスライスを使います。'), 'props': ('compact_mask_action', 'compact_face_set_action', 'extract_thickness', 'mask_extract_smooth_iterations', 'mask_extract_add_boundary_loop', 'mask_extract_apply_shrinkwrap', 'mask_slice_fill_holes')},
    'filters': {'title_en': 'Mesh and Cloth Filters', 'title_ja': 'メッシュとクロスフィルター', 'icon': 'MOD_CLOTH', 'overview_en': 'Filters apply broad mesh or cloth-style transformations for smoothing, sharpening, relaxing, inflating, or fold-like shaping.', 'overview_ja': 'フィルターは、スムーズ、シャープ化、リラックス、膨張、布の折り目風変形など、広範囲のメッシュ/クロス風変形を適用します。', 'usage_en': ('In Filter Domain, choose Mesh or Cloth. The panel shows the filter type and Apply button for the chosen one.', 'Set strength conservatively.', 'Apply to the active sculpt mesh and inspect the result.', 'The cloth filter keeps masked and hidden vertices in place. With no mask, Gravity holds the top of the mesh; mask the part to pin it instead.'), 'usage_ja': ('「フィルター対象」でメッシュかクロスを選びます。選んだ方のフィルターの種類と適用ボタンがパネルに出ます。', '強度は控えめに設定します。', 'アクティブなスカルプトメッシュへ適用し、結果を確認します。', 'クロスフィルターは、マスクした頂点と非表示の頂点を動かしません。マスクが無い時の重力はメッシュの上端を固定します。別の所を固定したい時はそこをマスクします。'), 'props': ('compact_filter_domain', 'mesh_filter_type', 'cloth_filter_type', 'filter_strength')},
    'primitive_boolean': {'title_en': 'Primitives and Boolean', 'title_ja': 'プリミティブとブーリアン', 'icon': 'MESH_UVSPHERE', 'overview_en': 'Primitives and Boolean creates simple base forms and applies boolean interaction with the active mesh.', 'overview_ja': 'プリミティブとブーリアンは、シンプルなベース形状を作成し、アクティブメッシュとのブーリアン関係を適用します。', 'usage_en': ('Choose a primitive and size.', 'Choose whether it remains separate or is booleaned into the active mesh.', 'Use selection booleans when existing selected objects should act as cutters.'), 'usage_ja': ('プリミティブとサイズを選びます。', '別オブジェクトのままにするか、アクティブメッシュへブーリアン適用するか選びます。', '既存の選択オブジェクトをカッターにする場合は選択ブーリアンを使います。'), 'props': ('compact_primitive_type', 'primitive_radius', 'primitive_operation', 'compact_boolean_operation', 'boolean_cleanup_voxel')},
    'sphere_tube': {'title_en': 'Sphere Chain and Tube', 'title_ja': 'スフィアチェーンとチューブ', 'icon': 'CURVE_DATA', 'overview_en': 'Sphere Chain and Tube creates repeated spheres or curve-based tube helpers for organic blockout and connecting forms.', 'overview_ja': 'スフィアチェーンとチューブは、有機的なブロックアウトや接続形状用に、連続球やカーブベースのチューブヘルパーを作成します。', 'usage_en': ('Set count, radius, and length.', 'Create the chain or tube.', 'Use the generated object as a sculpt base or construction helper.'), 'usage_ja': ('個数、半径、長さを設定します。', 'チェーンまたはチューブを作成します。', '生成オブジェクトをスカルプトベースや構築ヘルパーとして使います。'), 'props': ('compact_chain_count', 'compact_curve_length', 'primitive_radius')},
    'rail_scatter': {'title_en': 'Rail Cutter and Scatter', 'title_ja': 'レールカッターと散布', 'icon': 'MOD_BOOLEAN', 'overview_en': 'Rail Cutter and Scatter creates panel-line cutters and distributes selected detail helpers over the active surface.', 'overview_ja': 'レールカッターと散布は、パネルライン用カッターを作成し、選択ディテールヘルパーをアクティブ表面へ分布させます。', 'usage_en': ('Use Rail Cutter for groove or slice guides.', 'Use Scatter for bolts, rocks, scales, leaves, or surface greebles.', 'Enable overlap avoidance when spacing matters more than speed.'), 'usage_ja': ('溝やスライスガイドにはレールカッターを使います。', 'ボルト、岩、鱗、葉、表面ディテールには散布を使います。', '速度より間隔が重要な場合は重なり回避を有効にします。'), 'props': ('rail_length', 'rail_width', 'rail_depth', 'rail_apply_to_target', 'rail_apply_boolean', 'rail_remove_cutter', 'rail_add_bevel', 'scatter_count', 'scatter_min_scale', 'scatter_max_scale', 'scatter_align_to_normal', 'scatter_normal_offset', 'scatter_seed', 'scatter_avoid_overlap', 'scatter_min_gap', 'scatter_tilt_degrees')},
    'anchor_bend': {'title_en': 'Anchor Bend', 'title_ja': 'アンカーベンド', 'icon': 'EMPTY_DATA', 'overview_en': 'Anchor Bend creates bend helper setups for shaping or testing deformation around a chosen axis.', 'overview_ja': 'アンカーベンドは、指定軸まわりの変形を作る、または確認するためのベンドヘルパー構成を作成します。', 'usage_en': ('Choose the axis.', 'Create the bend setup.', 'Inspect the helper before committing downstream deformation.'), 'usage_ja': ('軸を選びます。', 'ベンド構成を作成します。', '後工程の変形へ進む前にヘルパーを確認します。'), 'props': ('compact_axis',)},
    'procedural_stack': {'title_en': 'Procedural Stack', 'title_ja': 'プロシージャルスタック', 'icon': 'MODIFIER', 'overview_en': 'Procedural Stack adds modifier-based surface detail presets such as noise, micro breakup, shell, wrinkle, aggregate, and hybrid surface patterns.', 'overview_ja': 'プロシージャルスタックは、ノイズ、マイクロ分解、シェル、しわ、集合体、ハイブリッド表面模様などのモディファイアベースの表面ディテールを追加します。', 'usage_en': ('Choose a preset.', 'Set strength and scale.', 'Add the stack and adjust modifiers afterward if needed.'), 'usage_ja': ('プリセットを選びます。', '強度とスケールを設定します。', 'スタックを追加し、必要に応じて後からモディファイアを調整します。'), 'props': ('compact_procedural_preset', 'procedural_strength', 'procedural_scale')},
    'retopo_setup': {'title_en': 'Retopo Setup', 'title_ja': 'リトポセットアップ', 'icon': 'SNAP_FACE', 'overview_en': 'Retopo Setup creates retopology helpers and QuadriFlow-based rebuilding options.', 'overview_ja': 'リトポセットアップは、リトポロジ補助とクアッドリメッシュベースの再構築オプションを作成します。', 'usage_en': ('Set target face count, offset, and mirror behavior.', 'Run QuadriFlow or create a helper setup.', 'Review the result before replacing production mesh data.'), 'usage_ja': ('目標面数、オフセット、ミラー挙動を設定します。', 'クアッドリメッシュまたは補助セットアップを実行します。', '本番メッシュデータを置き換える前に結果を確認します。'), 'props': ('quad_target_faces', 'retopo_offset', 'retopo_use_mirror')},
    'auto_uv': {'title_en': 'Auto UV', 'title_ja': '自動UV', 'icon': 'GROUP_UVS', 'overview_en': 'Auto UV runs a Smart UV style projection for the active mesh with a controllable island margin.', 'overview_ja': '自動UVは、アイランド間隔を指定して、アクティブメッシュにスマートUV系の展開を実行します。', 'usage_en': ('Set the UV margin.', 'Run Auto UV Project.', 'Inspect seams and islands before final export.'), 'usage_ja': ('UVマージンを設定します。', '自動UV展開を実行します。', '最終書き出し前にシームとアイランドを確認します。'), 'props': ('unwrap_margin',)},
    'cleanup': {'title_en': 'Cleanup', 'title_ja': '整理', 'icon': 'TRASH', 'overview_en': 'Cleanup removes generated Smart Sculpt helper data and can optionally include snapshot backups.', 'overview_ja': '整理は、スマートスカルプトが生成したヘルパーデータを削除し、必要に応じてスナップショットバックアップも対象にします。', 'usage_en': ('Use cleanup after confirming generated helpers are no longer needed.', 'Enable snapshot cleanup only when saved checkpoints can also be deleted.'), 'usage_ja': ('生成ヘルパーが不要になったことを確認してから整理します。', '保存済みチェックポイントも削除してよい場合だけスナップショット整理を有効にします。'), 'props': ('cleanup_include_snapshots',)},

    'top_viewport': {'title_en': 'Viewport', 'title_ja': 'ビューポート', 'icon': 'SHADING_SOLID', 'overview_en': 'Viewport consolidates all visibility-related Smart Sculpt controls such as shading presets, technical view, Face Set view, wireframe view, silhouette checks, and viewport preset popups.', 'overview_ja': 'ビューポートは、シェーディングプリセット、テクニカル表示、フェイスセット表示、ワイヤーフレーム表示、シルエット確認、表示プリセットポップアップなど、視認性に関わる操作を集約します。', 'usage_en': ('Choose a viewport preset and apply it.', 'Use silhouette to check the readability of the sculpt form.', 'Use the popup entry when you need a compact preset selector.'), 'usage_ja': ('表示プリセットを選び、適用します。', '形状の読みやすさを確認する時はシルエットを使います。', 'コンパクトなプリセット選択にはポップアップを使います。'), 'props': ('compact_viewport_preset',)},
    'top_efficiency': {'title_en': 'Efficiency', 'title_ja': '効率化', 'icon': 'PLAY', 'overview_en': 'Efficiency consolidates workflow acceleration, active target inspection, core setup, multi-object preparation, part cycling, quick access menus, Smart workflow launchers, and sculpt session management.', 'overview_ja': '効率化は、作業フロー高速化、アクティブ対象確認、コア設定、複数オブジェクト準備、パーツ切替、クイックアクセス、スマートワークフロー実行、スカルプトセッション管理を集約します。', 'usage_en': ('Use Workflow Launcher for the main sculpt workflow operation.', 'Use Smart Workflow for higher-level one-tap assistance.', 'Use Sculpt Session Management for proxy or unified multi-object sessions.'), 'usage_ja': ('主な作業操作はワークフロー実行を使います。', '上位のワンタップ補助はスマートワークフローを使います。', 'プロキシまたは統合複数オブジェクト作業にはスカルプトセッション管理を使います。'), 'props': ('core_action', 'auto_enter_sculpt', 'smart_upgrade_action', 'session_action')},
    'top_brush': {'title_en': 'Brush', 'title_ja': 'ブラシ', 'icon': 'BRUSH_DATA', 'overview_en': 'Brush consolidates sculpt brush activation, workflow profiles, Tool Pipe favorite slots, quick brush buttons, brush-like filters, and brush-related Smart actions.', 'overview_ja': 'ブラシは、スカルプトブラシ有効化、ワークフロープロファイル、ツールパイプお気に入りスロット、クイックブラシ、ブラシ系フィルター、ブラシ関連スマートアクションを集約します。', 'usage_en': ('Activate a quick brush or apply a workflow profile.', 'Store and recall favorite brush slots.', 'Use mesh or cloth filters as broad brush-like surface operations.'), 'usage_ja': ('クイックブラシを有効化するか、ワークフロープロファイルを適用します。', 'お気に入りブラシスロットを保存・呼び出しします。', '広範囲のブラシ風表面操作にはメッシュ/クロスフィルターを使います。'), 'props': ('quick_tool', 'profile', 'tool_pipe_slot_index', 'compact_filter_domain', 'mesh_filter_type', 'cloth_filter_type', 'filter_strength')},
    'top_remesh_retopo': {'title_en': 'Remesh / Retopo', 'title_ja': 'リメッシュ/リトポ', 'icon': 'MOD_REMESH', 'overview_en': 'Remesh / Retopo consolidates Dynamic Topology, detail flood fill, voxel remesh, QuadriFlow, Multires, masks, Face Sets, retopo helpers, Auto UV, and topology-related Smart actions.', 'overview_ja': 'リメッシュ/リトポは、ダイナミックトポロジー、ディテール均一化、ボクセルリメッシュ、クアッドリメッシュ、マルチレゾ、マスク、フェイスセット、リトポ補助、自動UV、トポロジー関連スマートアクションを集約します。', 'usage_en': ('Use Dyntopo or remesh for topology changes.', 'Use masks and Face Sets to isolate regions.', 'Use Retopo / UV for rebuilding and unwrap preparation.'), 'usage_ja': ('トポロジー変更にはダイナミックトポロジーまたはリメッシュを使います。', '領域分離にはマスクとフェイスセットを使います。', '再構築と展開準備にはリトポ/UVを使います。'), 'props': ('surface_action', 'compact_remesh_mode', 'compact_multires_action', 'compact_mask_action', 'compact_face_set_action', 'quad_target_faces', 'unwrap_margin')},
    'top_generate_deform': {'title_en': 'Generate / Deform', 'title_ja': '生成/変形', 'icon': 'MESH_CUBE', 'overview_en': 'Generate / Deform consolidates primitive creation, booleans, cutter rails, sphere chains, curve tubes, anchor bend, scatter, procedural detail, and deformation or generation Smart actions.', 'overview_ja': '生成/変形は、プリミティブ作成、ブーリアン、カッターレール、スフィアチェーン、カーブチューブ、アンカーベンド、散布、プロシージャルディテール、生成/変形系スマートアクションを集約します。', 'usage_en': ('Use the build launcher as the single entry for current build action.', 'Use primitives and booleans for base forms and cuts.', 'Use scatter/procedural tools and deformation Smart actions for detail and shape changes.'), 'usage_ja': ('現在の造形操作は造形実行を入口にします。', 'ベース形状とカットにはプリミティブ/ブーリアンを使います。', 'ディテールと形状変化には散布/プロシージャルと変形系スマートアクションを使います。'), 'props': ('build_action', 'compact_primitive_type', 'compact_boolean_operation', 'compact_axis', 'compact_procedural_preset')},
    'top_analysis_repair': {'title_en': 'Analyze / Repair', 'title_ja': '解析/修復', 'icon': 'VIEWZOOM', 'overview_en': 'Analyze / Repair consolidates mesh information, diagnostics, common fixes, repair settings, live readiness, Smart quality controls, and repair-related Smart actions.', 'overview_ja': '解析/修復は、メッシュ情報、診断、共通修正、修復設定、ライブ準備度、スマート品質設定、修復関連スマートアクションを集約します。', 'usage_en': ('Review mesh information and live readiness.', 'Run Analyze before Fix for production assets.', 'Use Mesh Doctor, Mesh Cleaner, Full Safe Setup, or symmetry guard actions for deeper repair workflows.'), 'usage_ja': ('メッシュ情報とライブ準備度を確認します。', '制作用アセットでは修正の前に解析を実行します。', 'より深い修復にはメッシュ診断プロ、メッシュクリーナープロ、全安全セットアップ、対称保護アクションを使います。'), 'props': ('smart_upgrade_action', 'smart_upgrade_quality', 'apply_scale_on_fix', 'recalc_normals_on_fix', 'delete_loose_on_fix', 'merge_distance_on_fix')},
    'top_save_io': {'title_en': 'Save / I/O', 'title_ja': '保存/入出力', 'icon': 'EXPORT', 'overview_en': 'Save / I/O consolidates snapshots, recovery backups, sculpt layers, import/export exchange, cleanup, N-panel state persistence, and embedded settings.', 'overview_ja': '保存/入出力は、スナップショット、回復バックアップ、スカルプレイヤー、入出力受け渡し、整理、Nパネル状態保存、埋め込み設定を集約します。', 'usage_en': ('Use snapshots and recovery before large changes.', 'Use exchange operations for external handoff.', 'Use persistence settings to maintain N-panel state through scene changes and Blender restarts.'), 'usage_ja': ('大きな変更前にスナップショットと回復を使います。', '外部受け渡しには入出力操作を使います。', 'シーン切り替えやBlender再起動後もNパネル状態を維持するには永続化設定を使います。'), 'props': ('snapshot_action', 'recovery_action', 'layer_action', 'transfer_action', 'exchange_format', 'exchange_scope', 'always_on_npanel_autosave_restore')},
}


_TOPIC_ALIASES: dict[str, str] = {

    'section_main': 'edit_mode_sculpt',
    'section_sculpt_brush_assets': 'edit_mode_sculpt',
    'section_sculpt_toolbar': 'edit_mode_sculpt',
    'section_filter': 'edit_mode_sculpt',
    'section_mask': 'edit_mode_sculpt',
    'section_faceset': 'edit_mode_sculpt',
    'section_color': 'edit_mode_sculpt',
    'section_topology': 'edit_mode_sculpt',

    'viewport_visibility_tools': 'top_viewport',
    'viewport_popup_access': 'top_viewport',
    'integrated_viewport_tools': 'top_viewport',
    'efficiency_active_target': 'top_efficiency',
    'efficiency_workflow': 'top_efficiency',
    'efficiency_direct_access': 'top_efficiency',
    'efficiency_smart_launcher': 'top_efficiency',
    'efficiency_smart_actions': 'top_efficiency',
    'efficiency_sculpt_session': 'top_efficiency',
    'brush_consolidated_tools': 'top_brush',
    'brush_quick_buttons': 'top_brush',
    'brush_filter_tools': 'top_brush',
    'brush_smart_actions': 'top_brush',
    'integrated_brush_tools': 'top_brush',
    'remesh_retopo_launcher': 'top_remesh_retopo',
    'remesh_retopo_smart_actions': 'top_remesh_retopo',
    'generate_deform_smart_actions': 'top_generate_deform',
    'analysis_active_target': 'top_analysis_repair',
    'analysis_repair_smart_actions': 'top_analysis_repair',
    'integrated_analysis_tools': 'top_analysis_repair',
    'save_io_smart_actions': 'top_save_io',

    'surface_action_launcher': 'surface_actions',
    'dyntopo_tools': 'dyntopo',
    'remesh_tools': 'voxel_remesh',
    'multires_tools': 'multires',
    'mask_tools': 'mask_facesets',
    'face_sets': 'mask_facesets',
    'face_set_tools': 'mask_facesets',
    'filter_tools': 'filters',
    'retopo_uv': 'retopo_setup',
    'retopo_uv_tools': 'retopo_setup',
    'smart_safety_options': 'smart_precision_ui',
    'smart_action_parameters': 'smart_precision_ui',
    'smart_group_pipeline': 'tab_smart',
    'smart_group_diagnosis': 'analysis_repair',
    'smart_group_layers_pose': 'shape_layers',
    'smart_group_surface_retopo': 'surface_actions',
    'smart_group_blockout_build': 'build_actions',
    'smart_group_scene_exchange': 'exchange',
    'primitive_tools': 'primitive_boolean',
    'boolean_cutters': 'primitive_boolean',
    'blockout_forms': 'sphere_tube',
    'scatter_procedural': 'rail_scatter',
}


def _root_package_name() -> str:
    package = str(__package__ or '').strip()
    if '.core' in package:
        return package.rsplit('.core', 1)[0]
    return package.rsplit('.', 1)[0] if '.' in package else 'core'


def _preferences_module():
    return sys.modules.get(f'{_root_package_name()}.preferences')


def _draw_preference_group(layout, context, alias: str, title: str | None = None) -> int:
    prefs_module = _preferences_module()
    if prefs_module is None:
        return 0
    try:
        finder = getattr(prefs_module, 'find_tool_settings', None)
        data = finder(alias, context=context) if callable(finder) else None
    except Exception:
        data = None
    if data is None:
        return 0
    box = layout.box()
    _wrap(box, title or _one_language(str(alias).replace('_', ' ').title()), width=74, icon='PREFERENCES')
    return _draw_property_details(box, data, None, include_hidden=False)


def _draw_root_preferences(layout, context) -> None:
    prefs_module = _preferences_module()
    if prefs_module is None:
        return
    try:
        root = getattr(prefs_module, 'root_preferences', lambda context=None: None)(context)
    except Exception:
        root = None
    if root is None:
        return
    box = layout.box()
    box.label(text=_t('Root Tool Settings', 'ルートツール設定'), icon=utils.safe_icon('PREFERENCES'))
    _draw_property_details(box, root, None, include_hidden=False)
    for alias in ('core', 'navigation', 'mask_facesets_tools'):
        meta = {}
        try:
            meta = dict(getattr(prefs_module, 'tool_meta', lambda _alias: {})(alias) or {})
        except Exception:
            meta = {}
        title = _t(str(meta.get('display_en') or alias), str(meta.get('display_ja') or meta.get('display_en') or alias))
        _draw_preference_group(layout, context, alias, title)


def _draw_standard_topic(layout, context, topic_id: str, spec: dict[str, Any]) -> None:
    title = _t(str(spec.get('title_en') or 'Help'), str(spec.get('title_ja') or spec.get('title_en') or 'ヘルプ'))
    _wrap(layout, title, width=78, icon=str(spec.get('icon') or 'HELP'))

    overview_box = _section(layout, 'Overview', '1. 機能概要', 'INFO')
    _wrap(overview_box, _t(str(spec.get('overview_en') or ''), str(spec.get('overview_ja') or spec.get('overview_en') or '')), width=86)

    functions_box = _section(layout, '2. Functions', '2. 機能一覧', 'TOOL_SETTINGS')
    function_lines = _topic_function_lines(topic_id, context, spec)
    if function_lines:
        _bullets(functions_box, function_lines, width=82)
    else:
        _wrap(functions_box, _t('This topic has no buttons of its own. Use the settings below.', 'この項目に専用のボタンはありません。下の設定項目を使います。'), width=74, icon='NONE')

    usage_box = _section(layout, '3. Usage', '3. 使用方法', 'QUESTION')
    usage = spec.get('usage_ja') if utils.locale_is_japanese() else spec.get('usage_en')
    if isinstance(usage, str):
        usage = (usage,)
    _bullets(usage_box, list(usage or ()), width=82)

    settings_box = _section(layout, '4. Settings', '4. 設定項目', 'PREFERENCES')
    prop_names = tuple(spec.get('props') or ())
    if topic_id == 'edit_mode_sculpt':
        module = _edit_mode_module()
        names = tuple(prop for _key, _buttons, props in _edit_mode_ui_sections() for prop in props)
        try:
            _draw_property_details(settings_box, module._settings(context), names, include_hidden=False)
        except Exception:
            pass
    else:
        _draw_property_details(settings_box, _scene_settings(context), prop_names, include_hidden=topic_id in {'settings_all', 'tab_settings'})
    if bool(spec.get('include_preferences')):
        _draw_root_preferences(settings_box, context)


def _literal_string(node: ast.AST | None) -> str:
    if node is None:
        return ''
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value.strip()
    if isinstance(node, ast.JoinedStr):
        return ''.join(part.value for part in node.values if isinstance(part, ast.Constant) and isinstance(part.value, str)).strip()
    if isinstance(node, ast.Call):
        if node.args:
            return _literal_string(node.args[0])
    if isinstance(node, (ast.Tuple, ast.List)):
        parts = [_literal_string(item) for item in node.elts]
        return ' '.join(part for part in parts if part).strip()
    return ''


def _class_assignment_strings(cls_node: ast.ClassDef) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in cls_node.body:
        if isinstance(item, ast.Assign):
            for target in item.targets:
                if isinstance(target, ast.Name) and target.id in {'bl_idname', 'bl_label', 'bl_description'}:
                    result[target.id] = _literal_string(item.value)
        elif isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
            if item.target.id in {'bl_idname', 'bl_label', 'bl_description'}:
                result[item.target.id] = _literal_string(item.value)
    return result


def _static_entries(module_dir: str | Path) -> dict[str, list[tuple[str, str, str]]]:
    base = Path(str(module_dir or ''))
    result = {'operators': [], 'menus': [], 'panels': []}
    if not base.exists():
        return result
    seen = set()
    for py_path in sorted(base.rglob('*.py'), key=lambda item: str(item).lower()):
        if '__pycache__' in py_path.parts:
            continue
        try:
            tree = ast.parse(py_path.read_text(encoding='utf-8', errors='ignore'))
        except Exception:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ClassDef):
                continue
            attrs = _class_assignment_strings(node)
            item_id = attrs.get('bl_idname', '').strip()
            label = attrs.get('bl_label', '').strip() or node.name
            desc = attrs.get('bl_description', '').strip()
            if not item_id and not label:
                continue
            key = (node.name, item_id, label)
            if key in seen:
                continue
            seen.add(key)
            class_name = node.name.upper()
            target = 'operators'
            if 'MENU' in class_name or '_MT_' in class_name or (item_id and item_id.isupper()):
                target = 'menus'
            elif 'PANEL' in class_name or '_PT_' in class_name:
                target = 'panels'
            elif '_OT_' not in class_name:
                continue
            result[target].append((item_id or node.name, label, desc))
    return result


def _loaded_record(alias: str) -> dict[str, Any] | None:
    try:
        from . import loader
        record = loader.get_record(alias)
        if record is not None:
            return record
        for item in loader.get_records():
            spec = item.get('spec') or {}
            if str(spec.get('alias') or spec.get('package_name') or '') == alias:
                return item
    except Exception:
        return None
    return None


def _integrated_record_spec(alias: str) -> dict[str, Any]:
    record = _loaded_record(alias)
    if isinstance(record, dict):
        return dict(record.get('spec') or {})
    try:
        from . import registry
        for spec in registry.build_specs(force=False):
            if str(spec.get('alias') or spec.get('package_name') or '') == alias:
                return dict(spec)
    except Exception:
        pass
    return {'alias': alias, 'display_name': alias.replace('_', ' ').title(), 'description': ''}


def _record_runtime_entries(record: dict[str, Any] | None) -> dict[str, list[tuple[str, str, str]]]:
    result = {'operators': [], 'menus': [], 'panels': []}
    if not isinstance(record, dict):
        return result
    for key, source_key in (('operators', 'operators'), ('menus', 'menus'), ('panels', 'panels')):
        seen = set()
        for cls in tuple(record.get(source_key) or ()):  # classes if loaded
            try:
                item_id = str(getattr(cls, 'bl_idname', '') or '').strip()
                label = str(getattr(cls, 'bl_label', '') or getattr(cls, '__name__', '') or item_id).strip()
                desc = str(getattr(cls, 'bl_description', '') or '').strip()
            except Exception:
                continue
            if bool(getattr(cls, '_smart_sculpt_internal_operator', False)):
                continue
            if not item_id and not label:
                continue
            if item_id in {'sculptnav.toggle'}:
                continue
            dedupe = (item_id, label)
            if dedupe in seen:
                continue
            seen.add(dedupe)
            result[key].append((item_id or label, label or item_id, desc))
    return result


def _draw_entry_list(layout, title_en: str, title_ja: str, entries: list[tuple[str, str, str]], icon: str) -> None:
    if not entries:
        return
    box = layout.box()
    box.label(text=_t(title_en, title_ja), icon=utils.safe_icon(icon))
    for item_id, label, desc in entries:
        label_text = _one_language(label) or item_id
        _wrap(box, label_text, width=74, icon='DOT')
        if desc:
            _wrap(box, _one_language(desc), width=78)


def _merge_entries(primary: list[tuple[str, str, str]], fallback: list[tuple[str, str, str]]) -> list[tuple[str, str, str]]:
    seen = set()
    merged: list[tuple[str, str, str]] = []
    for item in list(primary or ()) + list(fallback or ()):
        key = (str(item[0] or ''), str(item[1] or ''))
        if key in seen:
            continue
        seen.add(key)
        merged.append(item)
    merged.sort(key=lambda item: (str(item[1] or item[0]).lower(), str(item[0]).lower()))
    return merged


_INTEGRATED_BUTTON_PLACES = {
    'navigation': (
        'Its buttons are in the Integrated section of the Viewport group. Nothing needs to be loaded first.',
        'ボタンは「ビューポート」の中の統合の枠にあります。先に読み込む必要はありません。',
    ),
    'mask_facesets_tools': (
        'Its buttons are in the Integrated sections of the Brush and Remesh / Retopo groups. Nothing needs to be loaded first.',
        'ボタンは「ブラシ」「リメッシュ/リトポ」の中の統合の枠にあります。先に読み込む必要はありません。',
    ),
}


def _draw_integrated_help(layout, context, alias: str) -> None:
    alias = str(alias or '').strip()
    record = _loaded_record(alias)
    spec = _integrated_record_spec(alias)
    meta = {}
    try:
        meta = dict(getattr(_preferences_module(), 'tool_meta', lambda _alias: {})(alias) or {})
    except Exception:
        meta = {}
    if meta.get('display_en'):
        display = _t(str(meta.get('display_en')), str(meta.get('display_ja') or meta.get('display_en')))
    else:
        display = _one_language(spec.get('display_name') or alias.replace('_', ' ').title())
    module_dir = spec.get('module_dir') or ''
    description = _t(str(meta.get('summary_en') or ''), str(meta.get('summary_ja') or meta.get('summary_en') or '')) or _one_language(spec.get('description') or '')
    if description == alias:
        description = ''

    _wrap(layout, display, width=78, icon='PLUGIN')
    overview = description or _t(
        'This integrated tool is available inside Smart Sculpt.',
        'この統合ツールはスマートスカルプト内で利用できます。',
    )
    box = _section(layout, 'Overview', '1. 機能概要', 'INFO')
    _wrap(box, overview, width=86)

    usage_box = _section(layout, '2. Usage', '2. 使用方法', 'QUESTION')
    _bullets(usage_box, (
        _t(*_INTEGRATED_BUTTON_PLACES.get(alias, _INTEGRATED_BUTTON_PLACES['navigation'])),
        _t('Background or always-on functions are controlled only from the Always-on Toggles group at the top of the N-panel.', '背景動作や常時起動機能は、Nパネル最上部の常時機能切り替えグループだけで管理します。'),
    ))

    runtime_entries = _record_runtime_entries(record)
    static_entries = _static_entries(module_dir)
    operators = _merge_entries(runtime_entries.get('operators', []), static_entries.get('operators', []))
    menus = _merge_entries(runtime_entries.get('menus', []), static_entries.get('menus', []))
    panels = _merge_entries(runtime_entries.get('panels', []), static_entries.get('panels', []))
    _draw_entry_list(layout, 'Menus', 'メニュー', menus, 'MENU_PANEL')
    _draw_entry_list(layout, 'Operators', 'オペレーター', operators, 'TOOL_SETTINGS')
    if panels:
        _draw_entry_list(layout, 'Original Panels', '元パネル', panels, 'PREFERENCES')

    settings_box = _section(layout, '3. Settings', '3. 設定項目', 'PREFERENCES')
    count = _draw_preference_group(settings_box, context, alias, display)
    if count == 0:
        _wrap(settings_box, _t('No editable settings storage was detected for this integrated tool.', 'この統合ツール用の編集可能な設定保存先は検出されませんでした。'), width=74, icon='NONE')


def draw_help_popup(layout, context, topic_id: str, *, popup_width: int | None = None) -> None:
    _set_help_popup_width(popup_width)
    topic_id = str(topic_id or '').strip() or 'tab_sculpt'
    topic_id = _TOPIC_ALIASES.get(topic_id, topic_id)
    if topic_id.startswith('integrated:'):
        _draw_integrated_help(layout, context, topic_id.split(':', 1)[1])
        return
    spec = _TOPIC_DEFS.get(topic_id) or _TOPIC_DEFS.get('tab_sculpt')
    _draw_standard_topic(layout, context, topic_id, spec or {})
