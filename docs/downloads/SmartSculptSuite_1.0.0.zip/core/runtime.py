# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from . import loader, ui_runtime


def register() -> None:
    loader.register_all()
    ui_runtime.register()


def unregister() -> None:
    ui_runtime.unregister()
    loader.unregister_all()
