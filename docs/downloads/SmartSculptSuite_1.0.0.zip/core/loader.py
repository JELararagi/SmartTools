# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Finite generation-owned lazy loader for Smart Sculpt bundled modules.

The loader imports only package-local modules named by the static registry.  It
never scans ``sys.modules``, never rewrites registered classes or Panels, and
never claims a third-party Suite resource.  Native resources created by a
module are journaled by the root lifecycle transaction.
"""
from __future__ import annotations

import importlib
import platform
import sys
from typing import Any

from .. import _sss_lifecycle as _lifecycle
from .. import _sss_runtime_errors as _errors
from .. import feature_toggle as _feature_toggle
from . import registry

_RECORDS: list[dict[str, Any]] = []
_BY_ALIAS: dict[str, dict[str, Any]] = {}


def clear_records() -> None:
    _RECORDS.clear()
    _BY_ALIAS.clear()


def get_records() -> list[dict[str, Any]]:
    return [_sync_eager_record(record) for record in _RECORDS]


def get_record(alias: object) -> dict[str, Any] | None:
    record = _BY_ALIAS.get(str(alias or "").strip())
    return _sync_eager_record(record) if record is not None else None


def _sync_eager_record(record: dict[str, Any]) -> dict[str, Any]:
    # Core, navigation and mask tools can be registered by normal suite startup.
    # Keep that registration visible without taking ownership of its teardown.
    if record["mode"] in {"", "eager"} and record["status"] in {"ready", "loaded"}:
        module = sys.modules.get(record["module_name"])
        registered = bool(getattr(module, "_REGISTERED", False))
        record.update(status="loaded" if registered else "ready", mode="eager" if registered else "")
    return record


def _root_module_prefix() -> str:
    package = str(__package__ or "").strip()
    return package.rsplit(".core", 1)[0] if ".core" in package else package


def _platform_supported(name: object) -> bool:
    text = str(name or "").lower()
    system = platform.system().lower()
    machine = platform.machine().lower()
    if "windows-x64" in text:
        return system == "windows" and machine in {"amd64", "x86_64"}
    if "linux-x64" in text:
        return system == "linux" and machine in {"amd64", "x86_64"}
    if "macos-arm64" in text:
        return system == "darwin" and machine in {"arm64", "aarch64"}
    if "macos-x64" in text:
        return system == "darwin" and machine in {"amd64", "x86_64"}
    return True


def _module_name_for_spec(spec: dict[str, Any]) -> str:
    alias = str(spec.get("package_name") or spec.get("alias") or "addon").strip()
    prefix = _root_module_prefix()
    return f"{prefix}.{alias}" if prefix else alias


def _base(spec: dict[str, Any], module_name: str) -> dict[str, Any]:
    return {
        "spec": spec,
        "status": "disabled",
        "mode": "",
        "module_name": module_name,
        "module": None,
        "module_identity": 0,
        "generation_uuid": "",
        "registered_classes": [],
        "proxy_panels": [],
        "panels": [],
        "operators": [],
        "menus": [],
        "preferences": [],
        "error": "",
    }


def _remember(record: dict[str, Any]) -> None:
    _RECORDS.append(record)
    alias = str((record.get("spec") or {}).get("alias") or "").strip()
    if alias:
        _BY_ALIAS[alias] = record


def _validate_local_module(module: Any, module_name: str) -> None:
    root = _root_module_prefix()
    if root and not module_name.startswith(root + "."):
        raise RuntimeError("Smart Sculpt loader refuses to own an external Suite module")
    actual = str(getattr(module, "__name__", "") or "")
    if actual != module_name:
        raise RuntimeError("Smart Sculpt lazy module identity mismatch")
    module_file = str(getattr(module, "__file__", "") or "")
    if not module_file:
        raise RuntimeError("Smart Sculpt lazy module has no package file identity")


def _manual_register(record: dict[str, Any]) -> None:
    module_name = str(record["module_name"])
    module = importlib.import_module(module_name)
    _validate_local_module(module, module_name)
    alias = str((record.get("spec") or {}).get("alias") or module_name)
    label = str((record.get("spec") or {}).get("display_name") or alias)
    with _feature_toggle.capture_runtime(alias, label):
        _lifecycle.register_module(module)
    record.update(
        status="loaded",
        mode="manual",
        module=module,
        module_identity=id(module),
        generation_uuid=_lifecycle.active_generation(),
        error="",
    )


def _manual_unregister(record: dict[str, Any]) -> None:
    module = record.get("module")
    if module is None:
        return
    if id(module) != int(record.get("module_identity") or 0):
        raise RuntimeError("Smart Sculpt lazy module identity changed before unregister")
    if str(record.get("generation_uuid") or "") != _lifecycle.active_generation():
        raise RuntimeError("Smart Sculpt refuses to unregister a foreign generation")
    _lifecycle.unregister_module(module)
    record.update(status="ready", mode="", module=None, module_identity=0, generation_uuid="")


def load_alias(alias: object, *, force: bool = False) -> dict[str, Any] | None:
    record = get_record(alias)
    if record is None:
        register_all()
        record = get_record(alias)
    if record is None or record["status"] not in {"ready", "failed"}:
        return record
    try:
        _manual_register(record)
    except Exception as exc:
        record.update(status="failed", error=str(exc)[:1024])
        _errors.record(f"loader:{alias}", exc)
    return record


def register_all() -> list[dict[str, Any]]:
    _feature_toggle.register_ui(
        suite_key="smart_sculpt_suite",
        suite_label="Smart Sculpt Suite",
        category="Smart Sculpt",
    )
    clear_records()
    for spec in registry.build_specs(force=False):
        record = _base(spec, _module_name_for_spec(spec))
        if not bool(spec.get("load", True)):
            record["status"] = "disabled"
        elif not _platform_supported(spec.get("outer_zip")):
            record["status"] = "unsupported_platform"
        else:
            record["status"] = "ready"
        _remember(record)
    return get_records()


def unregister_all() -> None:
    for record in reversed(_RECORDS):
        if record["mode"] != "manual":
            continue
        try:
            _manual_unregister(record)
        except Exception as exc:
            _errors.record("loader:unregister", exc)
    _feature_toggle.unregister_all()
    clear_records()
    registry.clear_cache()
