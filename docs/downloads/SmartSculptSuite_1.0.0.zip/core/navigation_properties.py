from __future__ import annotations
import importlib
from typing import Iterable
import bpy
from . import utils as _utils
from .. import rna_safety as _rna_safety
_CATEGORY_OVERRIDES = {'core': 'Smart Sculpt'}
_LEGACY_OPEN_OPERATOR_IDS = {'core': ()}
_REGISTRY = {'nav_entries': {}, 'panel_sources': {}, 'legacy_operators': {}, 'launcher_draw_callbacks': {}, 'preferred_owner': None, 'active_owner': None, 'shutdown': False, 'legacy_cleanup_signature': None}

def _registry() -> dict:
    return _REGISTRY

def _safe_name(value: object, fallback: str='smart_tools') -> str:
    text = str(value or fallback).strip().lower()
    out = ''.join((ch if ch.isalnum() else '_' for ch in text))
    out = '_'.join((part for part in out.split('_') if part))
    return out or fallback

def _operator_safe_name(op_idname: str) -> str:
    return _safe_name(str(op_idname or '').replace('.', '_'), 'smart_tools_operator')

def _is_japanese_locale(context=None) -> bool:
    prefs = getattr(context, 'preferences', None) if context is not None else None
    if prefs is None:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
    try:
        language = str(getattr(getattr(prefs, 'view', None), 'language', '') or '').lower()
        if language and language != 'default':
            return language.startswith('ja')
    except Exception:
        pass
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
        return locale.startswith('ja')
    except Exception:
        return False

def _text(en: str, ja: str, context=None) -> str:
    return str(ja if _is_japanese_locale(context) else en)

def _localized_layout(layout):
    try:
        from . import utils as _utils
        return _utils.localized_layout(layout)
    except Exception:
        return layout

def _feature_toggle_module():
    package = str(__package__ or __name__ or '').strip('.')
    candidates = []
    if package:
        candidates.append(package)
        if '.' in package:
            candidates.append(package.rsplit('.', 1)[0])
        parts = [part for part in package.split('.') if part]
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                candidates.append('.'.join(parts[:idx + 2]))
        elif parts:
            candidates.append(parts[0])
    for base in candidates:
        try:
            return importlib.import_module(f'{base}.feature_toggle')
        except Exception:
            continue
    return None

def _draw_inline_feature_toggles(layout, context, addon_key: str) -> bool:
    module = _feature_toggle_module()
    draw = getattr(module, 'draw_inline_toggles', None) if module is not None else None
    if not callable(draw):
        return False
    try:
        return bool(draw(layout, context, str(addon_key or ''), compact=True))
    except Exception:
        return False

def _normalize_owner(addon_key: object) -> str:
    return str(addon_key or '').strip()

def _clean_label(value: object) -> str:
    text = str(value or '').replace('_', ' ').strip()
    while '  ' in text:
        text = text.replace('  ', ' ')
    for suffix in (' Toolset', ' suite', '_Toolset', '_suite'):
        if text.endswith(suffix):
            text = text[:-len(suffix)].strip()
    return text

def _category_for(addon_key: str, label: object='') -> str:
    addon_key = _normalize_owner(addon_key)
    if addon_key in _CATEGORY_OVERRIDES:
        return _CATEGORY_OVERRIDES[addon_key]
    label_text = _clean_label(label)
    if label_text:
        return label_text
    if addon_key:
        return _clean_label(addon_key)
    return 'Smart Sculpt'

def _label_for(addon_key: str, label: object='') -> str:
    return _category_for(addon_key, label)

def _safe_register_class(cls: type) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        return bool(_rna_safety.register_class(cls))
    except Exception:
        return False

def _safe_unregister_class(cls: type) -> None:
    if not isinstance(cls, type):
        return
    try:
        _rna_safety.unregister_class(cls)
    except Exception:
        pass

def _unregister_registered_operator_group(group_key: str) -> None:
    registry = _REGISTRY.get(group_key)
    if not isinstance(registry, dict):
        return
    for cls in list(registry.values()):
        _safe_unregister_class(cls)
    registry.clear()

def _unregister_legacy_open_operators() -> None:
    _unregister_registered_operator_group('legacy_operators')

def _iter_valid_panel_classes(panel_classes: Iterable[type] | None) -> tuple[type, ...]:
    if not panel_classes:
        return ()
    base = getattr(getattr(bpy, 'types', None), 'Panel', None)
    panels = []
    seen = set()
    for cls in tuple(panel_classes):
        if not isinstance(cls, type) or cls in seen:
            continue
        if base is not None:
            try:
                if not issubclass(cls, base):
                    continue
            except Exception:
                continue
        seen.add(cls)
        panels.append(cls)
    return tuple(panels)

def _normalized_panel_owner(value: object) -> str:
    return str(value or '').strip().lower().replace('-', '_').replace(' ', '_')

def _panel_is_owned_by_smart_sculpt(cls: type) -> bool:
    """Return True only for legacy/current panels owned by Smart Sculpt.

    Older cleanup code treated the generic Smart Tools host/proxy markers as
    proof of Smart Sculpt ownership.  Those markers are shared by every Suite,
    so enabling Smart Sculpt could unregister complete native N-panel roots from
    Smart Overlay and other add-ons.  Cleanup is now strictly ownership-scoped.
    """
    if not isinstance(cls, type):
        return False
    try:
        module = str(getattr(cls, '__module__', '') or '').strip().lower()
    except Exception:
        module = ''
    if 'smart_sculpt_suite' in module or 'strict_edit_mode_sculpt' in module:
        return True
    for attr in ('_smart_suite_clone_owner', '_smart_suite_owner', '_smart_tools_manager_tool_key', '_smart_tools_manager_owner'):
        try:
            owner = _normalized_panel_owner(getattr(cls, attr, ''))
        except Exception:
            owner = ''
        if owner in {'core', 'smart_sculpt', 'smart_sculpt_suite', 'strict_edit_mode_sculpt'}:
            return True
    try:
        if bool(getattr(cls, '_smart_sculpt_suite_legacy_proxy', False)):
            return True
    except Exception:
        pass
    identifiers = []
    for attr in ('__name__', 'bl_idname'):
        try:
            identifiers.append(str(getattr(cls, attr, '') or '').strip().lower())
        except Exception:
            identifiers.append('')
    return any(('smart_sculpt' in identifier or 'strict_edit_mode_sculpt' in identifier or identifier.startswith('smarttools_npanel_pt_core') for identifier in identifiers if identifier))

def prepare_panel_classes(panel_classes, addon_key=None):
    del addon_key
    return _iter_valid_panel_classes(panel_classes)

def _iter_registered_panel_subclasses():
    return ()

def _legacy_panel_candidates():
    return ()

def _legacy_cleanup_signature(candidates):
    return ()

def cleanup_legacy_proxy_panels(*, force=False):
    del force
    return None

def install(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int=0, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _REGISTRY.setdefault('panel_sources', {})[addon_key] = prepare_panel_classes(panel_classes, addon_key)
    _REGISTRY.setdefault('nav_entries', {})[addon_key] = {'label': _label_for(addon_key, label), 'icon': str(icon or ''), 'operator_id': str(operator_id or ''), 'order': int(order or 0), 'category': _category_for(addon_key, label)}
    _REGISTRY['preferred_owner'] = addon_key
    _REGISTRY['active_owner'] = addon_key
    _REGISTRY['shutdown'] = False
    cleanup_legacy_proxy_panels()
    ensure_shared_nav_button_operators()
    _tag_redraw_all_npanel_areas()
    return True

def refresh_runtime(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int=0, reopen_window: bool=False, **kwargs) -> bool:
    del reopen_window
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)

def refresh_entry(addon_key: str, label: str, icon: str, operator_id: str, panel_classes, order: int=0, **kwargs) -> bool:
    return install(addon_key, label, icon, operator_id, panel_classes, order=order, **kwargs)

def uninstall(addon_key: str, **_kwargs) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    _REGISTRY.get('nav_entries', {}).pop(addon_key, None)
    _REGISTRY.get('panel_sources', {}).pop(addon_key, None)
    _REGISTRY.get('launcher_draw_callbacks', {}).pop(addon_key, None)
    if _REGISTRY.get('preferred_owner') == addon_key:
        _REGISTRY['preferred_owner'] = None
    if _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = None
    if not _REGISTRY.get('nav_entries'):
        _unregister_legacy_open_operators()
    cleanup_legacy_proxy_panels()
    _tag_redraw_all_npanel_areas()
    return True

def set_launcher_draw_callback(addon_key: str, callback) -> bool:
    addon_key = _normalize_owner(addon_key)
    if not addon_key:
        return False
    if callable(callback):
        _REGISTRY.setdefault('launcher_draw_callbacks', {})[addon_key] = callback
    else:
        _REGISTRY.setdefault('launcher_draw_callbacks', {}).pop(addon_key, None)
    return True

def clear_launcher_draw_callback(addon_key: str) -> bool:
    return set_launcher_draw_callback(addon_key, None)

def is_active(context=None, addon_key: str='') -> bool:
    del context, addon_key
    return True

def set_active_owner(context=None, addon_key: str | None=None) -> None:
    del context
    addon_key = _normalize_owner(addon_key)
    _REGISTRY['active_owner'] = addon_key or None
    if addon_key:
        _REGISTRY['preferred_owner'] = addon_key
    _tag_redraw_all_npanel_areas()

def clear_active_owner(addon_key: str='') -> None:
    addon_key = _normalize_owner(addon_key)
    if not addon_key or _REGISTRY.get('active_owner') == addon_key:
        _REGISTRY['active_owner'] = None
    if addon_key and _REGISTRY.get('preferred_owner') == addon_key:
        _REGISTRY['preferred_owner'] = None
    _tag_redraw_all_npanel_areas()

def toggle_active(context=None, addon_key: str='') -> None:
    set_active_owner(context, addon_key)

def runtime_needs_refresh(addon_key: str='') -> bool:
    del addon_key
    return False

def runtime_has_existing_host_candidates(addon_key: str='') -> bool:
    del addon_key
    return False

def force_runtime_refresh(preferred_owner: str | None=None, **_kwargs) -> bool:
    if preferred_owner:
        set_active_owner(getattr(bpy, 'context', None), preferred_owner)
    cleanup_legacy_proxy_panels()
    _tag_redraw_all_npanel_areas()
    return True

def refresh_ui_runtime(context=None, addon_key: str | None=None, activate_if_properties: bool=False, **_kwargs) -> bool:
    del activate_if_properties
    if addon_key:
        set_active_owner(context, addon_key)
    return force_runtime_refresh(addon_key)

def sync_live_runtime_from_prefs(context=None) -> bool:
    del context
    return force_runtime_refresh()

def begin_addon_shutdown(*_args, **_kwargs) -> None:
    _REGISTRY['shutdown'] = True

def finish_addon_shutdown(*_args, **_kwargs) -> None:
    _REGISTRY['shutdown'] = False

def shutdown_runtime() -> None:
    _REGISTRY['shutdown'] = True
    _REGISTRY['legacy_cleanup_signature'] = None
    _unregister_legacy_open_operators()
    cleanup_legacy_proxy_panels()

def is_shutting_down(*_args, **_kwargs) -> bool:
    return bool(_REGISTRY.get('shutdown'))

def runtime_is_shutdown() -> bool:
    return bool(_REGISTRY.get('shutdown'))

def _set_runtime_teardown(value: bool=True) -> None:
    _REGISTRY['shutdown'] = bool(value)

def is_smart_tools_context(context=None) -> bool:
    return _is_smart_tools_context(context)

def _is_smart_tools_context(context=None) -> bool:
    context = context or getattr(bpy, 'context', None)
    area = getattr(context, 'area', None)
    return area is None or str(getattr(area, 'type', '') or '') == 'VIEW_3D'

def _tag_redraw_all_npanel_areas() -> None:
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    for window in getattr(wm, 'windows', ()) if wm is not None else ():
        screen = getattr(window, 'screen', None)
        for area in getattr(screen, 'areas', ()) if screen is not None else ():
            try:
                if str(getattr(area, 'type', '') or '') == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass

def flush_redraws() -> None:
    _tag_redraw_all_npanel_areas()

def repair_live_hosts_and_menu(context=None, *, reopen_window: bool=False) -> bool:
    del context, reopen_window
    return force_runtime_refresh()

def _smart_tools_light_activate_runtime(context=None):
    del context
    return force_runtime_refresh()

def invoke_props_dialog_preferred_window(operator, context, width: int=420):
    try:
        return context.window_manager.invoke_props_dialog(operator, width=int(width or 420))
    except Exception:
        return {'CANCELLED'}

def invoke_props_dialog_outside_smart_tools(operator, context, width: int=420):
    return invoke_props_dialog_preferred_window(operator, context, width=width)

def invoke_popup_outside_smart_tools(operator, context, width: int=280):
    try:
        return context.window_manager.invoke_popup(operator, width=int(width or 280))
    except Exception:
        return {'CANCELLED'}

def _operator_callable(operator_idname: str):
    text = str(operator_idname or '').strip()
    if '.' not in text:
        return None
    group, name = text.split('.', 1)
    try:
        return getattr(getattr(bpy.ops, group), name)
    except Exception:
        return None

def _operator_enum_items(operator_idname: str, property_idname: str):
    op_fn = _operator_callable(operator_idname)
    if op_fn is None:
        return []
    try:
        rna = op_fn.get_rna_type()
    except Exception:
        rna = None
    prop = rna.properties.get(property_idname) if rna is not None else None
    enum_items = getattr(prop, 'enum_items', None)
    if not enum_items:
        return []
    items = []
    for item in enum_items:
        try:
            identifier = str(getattr(item, 'identifier', '') or '')
            if not identifier:
                continue
            name = str(getattr(item, 'name', '') or identifier)
            description = str(getattr(item, 'description', '') or '')
            items.append({'identifier': identifier, 'name': name, 'description': description})
        except Exception:
            continue
    return items

def _module_operator_prefix() -> str:
    package = str(__package__ or __name__ or 'smart_tools').strip('.')
    parts = [part for part in package.split('.') if part]
    if len(parts) >= 3 and parts[-2] == 'core':
        return _safe_name(parts[-2])
    if len(parts) >= 2:
        return _safe_name(parts[-1])
    if parts:
        return _safe_name(parts[0])
    return 'smart_tools'

def _registered_operator_id(type_name: str, operator_id: str) -> str:
    return operator_id if hasattr(bpy.types, type_name) else ''


def popup_menu_operator_id() -> str:
    return _registered_operator_id('WM_OT_core_npanel_popup_menu', 'wm.core_npanel_popup_menu')

def popup_operator_enum_operator_id() -> str:
    return _registered_operator_id('WM_OT_core_npanel_operator_enum_popup', 'wm.core_npanel_operator_enum_popup')

def popup_menu_pie_proxy_operator_id() -> str:
    return _registered_operator_id('WM_OT_core_npanel_call_menu_pie', 'wm.core_npanel_call_menu_pie')

def _ensure_legacy_open_operators(addon_key: str) -> None:
    # No legacy open IDs are owned by Smart Sculpt 1.9.44. Registered third-party
    # operators are never generated, searched, or removed.
    del addon_key
    return None


def ensure_shared_nav_button_operators() -> bool:
    _ensure_legacy_open_operators('core')
    return True

def is_startup_safe_stub() -> bool:
    return True

def describe_startup_behavior() -> str:
    return 'Smart Sculpt is registered as a standard 3D View Sidebar N-panel.'
install_window_menu_entry = lambda *args, **kwargs: ()
remove_window_menu_entry = lambda *args, **kwargs: None
remove_window_menu_entry_if_unused = lambda *args, **kwargs: None
schedule_window_menu_refresh = lambda *args, **kwargs: None
schedule_shared_window_menu_button_refresh = lambda *args, **kwargs: None
mark_suite_presence = lambda *args, **kwargs: True
_smart_tools_v440_canonicalize_existing_nav = lambda *args, **kwargs: True
_smart_tools_v430_canonicalize_nav_entries = lambda *args, **kwargs: True
_tag_redraw_window_menu_areas = flush_redraws
_ensure_host_watch_timer = lambda *args, **kwargs: False
_ensure_runtime_hooks = lambda *args, **kwargs: True
__all__ = ('_draw_inline_feature_toggles', '_registry', 'begin_addon_shutdown', 'cleanup_legacy_proxy_panels', 'clear_active_owner', 'clear_launcher_draw_callback', 'describe_startup_behavior', 'ensure_shared_nav_button_operators', 'finish_addon_shutdown', 'flush_redraws', 'force_runtime_refresh', 'install', 'invoke_popup_outside_smart_tools', 'invoke_props_dialog_outside_smart_tools', 'invoke_props_dialog_preferred_window', 'is_active', 'is_shutting_down', 'is_smart_tools_context', 'is_startup_safe_stub', 'popup_menu_operator_id', 'popup_menu_pie_proxy_operator_id', 'popup_operator_enum_operator_id', 'prepare_panel_classes', 'refresh_entry', 'refresh_runtime', 'refresh_ui_runtime', 'repair_live_hosts_and_menu', 'runtime_has_existing_host_candidates', 'runtime_is_shutdown', 'runtime_needs_refresh', 'set_active_owner', 'set_launcher_draw_callback', 'shutdown_runtime', 'sync_live_runtime_from_prefs', 'toggle_active', 'uninstall')
