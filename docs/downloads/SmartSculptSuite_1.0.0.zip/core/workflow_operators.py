# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


from . import utils, utils as _smart_utils
from .. import _sss_transactions as _transactions
import bpy
import numpy as np
from bpy.props import EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator
from mathutils import Vector



TOOL_ITEMS = [
    ('DRAW', "Draw", _smart_utils.localize_bilingual_text("General purpose build-up brush / 汎用的な盛り上げブラシ")),
    ('CLAY', "Clay", _smart_utils.localize_bilingual_text("Soft volume build-up brush / 柔らかなボリューム形成ブラシ")),
    ('CLAY_STRIPS', "Clay Strips", _smart_utils.localize_bilingual_text("Planar blockout brush / プレーン意識のブロックアウトブラシ")),
    ('GRAB', "Grab", _smart_utils.localize_bilingual_text("Move large forms quickly / 大きな形を素早く動かすブラシ")),
    ('SMOOTH', "Smooth", _smart_utils.localize_bilingual_text("Relax and average the surface / 表面をならして平均化します")),
    ('SCRAPE', "Scrape", _smart_utils.localize_bilingual_text("Plane and flatten surfaces / 面を削って整えます")),
    ('DRAW_SHARP', "Draw Sharp", _smart_utils.localize_bilingual_text("Crease-like sharp detail / シャープな溝や段差向け")),
    ('CLOTH', "Cloth", _smart_utils.localize_bilingual_text("Fold and wrinkle oriented brush / 布の折り目やしわ向け")),
    ('POSE', "Pose", _smart_utils.localize_bilingual_text("Anchor-like pose adjustments / アンカー風のポーズ調整向け")),
    ('CREASE', "Crease", _smart_utils.localize_bilingual_text("Pinch and carve details / しぼり込みや溝向け")),
]


class SSS_OT_set_sculpt_tool(Operator):
    bl_idname = "smart_sculpt.set_sculpt_tool"
    bl_label = "Set Sculpt Tool"
    bl_description = _smart_utils.localize_bilingual_text((
        "Select a sculpt brush/tool and apply a small matching preset so beginners get useful defaults immediately. "
        "/ スカルプトブラシを選択し、初心者でもすぐ使えるよう軽い相性プリセットを一緒に適用します。"
    ))
    bl_options = {'UNDO'}

    tool: EnumProperty(
        name="Tool",
        description=_smart_utils.localize_bilingual_text("Sculpt tool to activate from the quick-access workflow set / クイックアクセス用ワークフローセットから有効化するスカルプトツールです"),
        items=TOOL_ITEMS,
    )

    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            if utils.set_strict_edit_mode_brush(context, self.tool):
                self.report({'INFO'}, _smart_utils.localize_bilingual_format('Edit Mode Sculpt brush set to {v0}. / 編集モード専用スカルプトブラシを {v1} に設定しました。', v0=self.tool, v1=self.tool))
                return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        if not utils.select_sculpt_tool(context, self.tool):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not switch to {v0}. / {v1} へ切り替えられませんでした。', v0=self.tool, v1=self.tool))
            return {'CANCELLED'}

        brush = utils.get_active_brush(context)
        if brush:
            presets = {
                'DRAW': (80, 0.5, 0.0),
                'CLAY': (100, 0.5, 0.1),
                'CLAY_STRIPS': (120, 0.45, 0.1),
                'GRAB': (140, 0.8, 0.0),
                'SMOOTH': (100, 0.55, 0.0),
                'SCRAPE': (80, 0.35, 0.15),
                'DRAW_SHARP': (35, 0.25, 0.25),
                'CLOTH': (120, 0.35, 0.05),
                'POSE': (110, 0.7, 0.0),
                'CREASE': (40, 0.45, 0.1),
            }
            size, strength, auto_smooth = presets.get(self.tool, (80, 0.5, 0.0))
            utils.set_attr_if_exists(brush, "size", size)
            utils.set_attr_if_exists(brush, "strength", strength)
            utils.set_attr_if_exists(brush, "auto_smooth_factor", auto_smooth)
            if self.tool in {'SCRAPE', 'DRAW_SHARP', 'CREASE'}:
                utils.set_attr_if_exists(brush, "use_frontface", True)
            if self.tool == 'POSE':
                utils.set_attr_if_exists(brush, "pose_origin_type", 'TOPOLOGY')
                utils.set_attr_if_exists(brush, "use_automasking_topology", True)
                utils.set_attr_if_exists(brush, "use_automasking_face_sets", True)
            if self.tool == 'CLOTH':
                utils.set_attr_if_exists(brush, "use_automasking_boundary_edges", True)

        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Tool set to {v0}. / ツールを {v1} に設定しました。', v0=self.tool, v1=self.tool))
        return {'FINISHED'}



class SSS_OT_store_active_brush_slot(Operator):
    bl_idname = "smart_sculpt.store_active_brush_slot"
    bl_label = "Store Active Brush Slot"
    bl_description = _smart_utils.localize_bilingual_text((
        'Store the current active sculpt brush into one of three compact Tool Pipe slots so you can recall your own preferred brush set with one click. / 現在のアクティブスカルプトブラシを 3 つのコンパクトなツールパイプスロットのいずれかへ保存し、自分用の常用ブラシセットをワンクリックで呼び出せるようにします。'
    ))
    bl_options = {'UNDO'}

    slot: IntProperty(
        name="Slot",
        description=_smart_utils.localize_bilingual_text("Tool Pipe slot index used to store the current active brush / 現在のアクティブブラシを保存するツールパイプスロット番号です"),
        default=1,
        min=1,
        max=3,
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        if utils.strict_edit_mode_sculpt_active(context):
            brush_name = ""
            sculpt_tool = utils.strict_edit_mode_sculpt_settings(context).brush_tool
        else:
            brush_name = utils.active_brush_name(context)
            sculpt_tool = utils.active_sculpt_tool_id(context)
        if settings is None or (not brush_name and not sculpt_tool):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active sculpt brush to store. / 保存できるアクティブスカルプトブラシがありません。"))
            return {'CANCELLED'}
        if not utils.store_tool_pipe_slot(settings, self.slot, brush_name, sculpt_tool):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not store the Tool Pipe slot. / ツールパイプスロットへ保存できませんでした。"))
            return {'CANCELLED'}
        label = brush_name or sculpt_tool
        self.report({'INFO'}, _smart_utils.localize_bilingual_format("Stored brush '{v0}' in slot {v1}. / ブラシ '{v2}' をスロット {v3} に保存しました。", v0=label, v1=self.slot, v2=label, v3=self.slot))
        return {'FINISHED'}


class SSS_OT_use_brush_slot(Operator):
    bl_idname = "smart_sculpt.use_brush_slot"
    bl_label = "Use Brush Slot"
    bl_description = _smart_utils.localize_bilingual_text((
        'Recall a previously stored Tool Pipe brush slot. The operator first tries to activate the stored brush datablock directly, then falls back to the brush\'s sculpt tool if needed. / 保存済みのツールパイプブラシスロットを呼び出します。まず保存されたブラシデータブロックを直接有効化し、必要ならそのブラシのスカルプトツールへフォールバックします。'
    ))
    bl_options = {'UNDO'}

    slot: IntProperty(
        name="Slot",
        description=_smart_utils.localize_bilingual_text("Tool Pipe slot index to recall / 呼び出すツールパイプスロット番号です"),
        default=1,
        min=1,
        max=3,
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if settings is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Settings unavailable. / 設定を取得できません。"))
            return {'CANCELLED'}
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        brush_name = utils.tool_pipe_slot_name(settings, self.slot)
        sculpt_tool = utils.tool_pipe_slot_tool(settings, self.slot)
        if not brush_name and not sculpt_tool:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Tool Pipe slot {v0} is empty. / ツールパイプスロット {v1} は空です。', v0=self.slot, v1=self.slot))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context) and sculpt_tool:
            if utils.set_strict_edit_mode_brush(context, sculpt_tool):
                self.report({'INFO'}, _smart_utils.localize_bilingual_format('Edit Mode Sculpt brush slot {v0}: {v1} / 編集モード専用スカルプトブラシスロット {v2}: {v3}', v0=self.slot, v1=sculpt_tool, v2=self.slot, v3=sculpt_tool))
                return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        used_label = brush_name or sculpt_tool
        if brush_name and utils.activate_sculpt_brush_by_name(context, brush_name):
            utils.store_tool_pipe_slot(settings, self.slot, utils.active_brush_name(context) or brush_name, utils.active_sculpt_tool_id(context) or sculpt_tool)
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Tool Pipe slot {v0}: {v1} / ツールパイプスロット {v2}: {v3}', v0=self.slot, v1=used_label, v2=self.slot, v3=used_label))
            return {'FINISHED'}
        if sculpt_tool and utils.select_sculpt_tool(context, sculpt_tool):
            fallback_brush_name = utils.active_brush_name(context)
            utils.store_tool_pipe_slot(settings, self.slot, fallback_brush_name or brush_name, sculpt_tool)
            fallback_label = fallback_brush_name or sculpt_tool
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Tool Pipe slot {v0}: fallback tool {v1} / ツールパイプスロット {v2}: フォールバックツール {v3}', v0=self.slot, v1=fallback_label, v2=self.slot, v3=fallback_label))
            return {'FINISHED'}
        self.report({'WARNING'}, _smart_utils.localize_bilingual_format("Stored brush '{v0}' could not be activated. / 保存ブラシ '{v1}' を有効化できませんでした。", v0=used_label, v1=used_label))
        return {'CANCELLED'}


class SSS_OT_clear_brush_slot(Operator):
    bl_idname = "smart_sculpt.clear_brush_slot"
    bl_label = "Clear Brush Slot"
    bl_description = _smart_utils.localize_bilingual_text((
        'Clear one Tool Pipe slot so outdated personal brush shortcuts do not linger in the file. / ツールパイプスロットを1つ空にして、古い自分用ブラシショートカットがファイル内に残り続けないようにします。'
    ))
    bl_options = {'UNDO'}

    slot: IntProperty(
        name="Slot",
        description=_smart_utils.localize_bilingual_text("Tool Pipe slot index to clear / 空にするツールパイプスロット番号です"),
        default=1,
        min=1,
        max=3,
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        if settings is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Settings unavailable. / 設定を取得できません。"))
            return {'CANCELLED'}
        brush_name = utils.tool_pipe_slot_name(settings, self.slot)
        sculpt_tool = utils.tool_pipe_slot_tool(settings, self.slot)
        label = brush_name or sculpt_tool
        if not label:
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Tool Pipe slot {v0} was already empty. / ツールパイプスロット {v1} はすでに空です。', v0=self.slot, v1=self.slot))
            return {'FINISHED'}
        if not utils.clear_tool_pipe_slot(settings, self.slot):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Could not clear Tool Pipe slot {v0}. / ツールパイプスロット {v1} を空にできませんでした。', v0=self.slot, v1=self.slot))
            return {'CANCELLED'}
        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Cleared Tool Pipe slot {v0} ({v1}). / ツールパイプスロット {v2} を空にしました（{v3}）。', v0=self.slot, v1=label, v2=self.slot, v3=label))
        return {'FINISHED'}


class SSS_OT_apply_profile(Operator):
    bl_idname = "smart_sculpt.apply_profile"
    bl_label = "Apply Profile"
    bl_description = _smart_utils.localize_bilingual_text((
        "Apply a ready-made sculpt profile tuned for blockout, surface work, hybrid hard/organic shaping, detailing, cloth, posing, or cleanup. "
        "/ ブロックアウト、面出し、ハイブリッドな有機+ハード表現、ディテール、布、ポーズ、修正に向いた設定済みスカルプトプロファイルを適用します。"
    ))
    bl_options = {'UNDO'}

    profile: EnumProperty(
        name="Profile",
        description=_smart_utils.localize_bilingual_text("Workflow profile to apply to the current sculpt brush and settings / 現在のスカルプトブラシと設定へ適用するワークフロープロファイルです"),
        items=[
            ('BLOCKOUT', "Blockout", _smart_utils.localize_bilingual_text("Primary forms / 一次形状")),
            ('SURFACE', "Surface", _smart_utils.localize_bilingual_text("Planes and cleanup / 面出しと整形")),
            ('HYBRID_SURFACE', "Hybrid Surface", _smart_utils.localize_bilingual_text("Blend smooth forms with restrained hard-surface breakup / 滑らかな形状に控えめなハードサーフェス風の荒れを加える")),
            ('DETAIL', "Detail", _smart_utils.localize_bilingual_text("Secondary/tertiary details / 二次・三次ディテール")),
            ('CLOTH', "Cloth", _smart_utils.localize_bilingual_text("Wrinkle work / 布じわ向け")),
            ('POSE', "Pose", _smart_utils.localize_bilingual_text("Anchor-like pose prep / アンカー風ポーズ準備")),
            ('CLEANUP', "Cleanup", _smart_utils.localize_bilingual_text("Relax and polish / ならしと仕上げ")),
        ],
        default='BLOCKOUT',
    )

    def execute(self, context):
        settings = utils.settings_from_context(context)
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        profile = self.profile or (settings.profile if settings else 'BLOCKOUT')
        if utils.strict_edit_mode_sculpt_active(context):
            strict_settings = utils.strict_edit_mode_sculpt_settings(context)
            profile_map = {
                'BLOCKOUT': ('CLAY_STRIPS', 0.45, 0.10),
                'SURFACE': ('SCRAPE', 0.35, 0.08),
                'HYBRID_SURFACE': ('CLAY_STRIPS', 0.28, 0.08),
                'DETAIL': ('DRAW_SHARP', 0.25, 0.04),
                'CLOTH': ('CLOTH', 0.35, 0.08),
                'POSE': ('POSE', 0.65, 0.10),
                'CLEANUP': ('SMOOTH', 0.55, 0.05),
            }
            tool, strength, amount = profile_map.get(profile, profile_map['BLOCKOUT'])
            if strict_settings is not None:
                try:
                    strict_settings.brush_tool = tool
                    strict_settings.brush_strength = strength
                    strict_settings.strength = strength
                    strict_settings.brush_amount = amount
                    strict_settings.amount = amount
                except Exception:
                    pass
            self.report({'INFO'}, _smart_utils.localize_bilingual_format('Edit Mode Sculpt profile applied: {v0}. / 編集モード専用スカルプトプロファイル適用: {v1}', v0=profile, v1=profile))
            return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}

        profile = self.profile or (settings.profile if settings else 'BLOCKOUT')
        sculpt = utils.get_sculpt_settings(context)

        if profile == 'BLOCKOUT':
            utils.select_sculpt_tool(context, 'CLAY_STRIPS') or utils.select_sculpt_tool(context, 'CLAY')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 120)
                utils.set_attr_if_exists(brush, 'strength', 0.45)
                utils.set_attr_if_exists(brush, 'auto_smooth_factor', 0.05)
                utils.set_attr_if_exists(brush, 'use_automasking_face_sets', False)
                utils.set_attr_if_exists(brush, 'use_automasking_topology', False)
            if sculpt:
                utils.set_attr_if_exists(sculpt, 'detail_type_method', 'CONSTANT')
                utils.set_attr_if_exists(sculpt, 'constant_detail_resolution', 12.0)
        elif profile == 'SURFACE':
            utils.select_sculpt_tool(context, 'SCRAPE')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 90)
                utils.set_attr_if_exists(brush, 'strength', 0.35)
                utils.set_attr_if_exists(brush, 'auto_smooth_factor', 0.2)
                utils.set_attr_if_exists(brush, 'use_frontface', True)
        elif profile == 'HYBRID_SURFACE':
            utils.select_sculpt_tool(context, 'CLAY_STRIPS') or utils.select_sculpt_tool(context, 'SCRAPE') or utils.select_sculpt_tool(context, 'CLAY')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 78)
                utils.set_attr_if_exists(brush, 'strength', 0.28)
                utils.set_attr_if_exists(brush, 'auto_smooth_factor', 0.18)
                utils.set_attr_if_exists(brush, 'use_frontface', True)
                utils.set_attr_if_exists(brush, 'use_automasking_face_sets', False)
                utils.set_attr_if_exists(brush, 'use_automasking_topology', False)
            if sculpt:
                utils.set_attr_if_exists(sculpt, 'detail_type_method', 'CONSTANT')
                utils.set_attr_if_exists(sculpt, 'constant_detail_resolution', 18.0)
        elif profile == 'DETAIL':
            utils.select_sculpt_tool(context, 'DRAW_SHARP') or utils.select_sculpt_tool(context, 'CREASE')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 35)
                utils.set_attr_if_exists(brush, 'strength', 0.25)
                utils.set_attr_if_exists(brush, 'auto_smooth_factor', 0.35)
                utils.set_attr_if_exists(brush, 'use_frontface', True)
                utils.set_attr_if_exists(brush, 'use_automasking_face_sets', True)
        elif profile == 'CLOTH':
            utils.select_sculpt_tool(context, 'CLOTH')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 120)
                utils.set_attr_if_exists(brush, 'strength', 0.35)
                utils.set_attr_if_exists(brush, 'use_automasking_boundary_edges', True)
        elif profile == 'POSE':
            utils.select_sculpt_tool(context, 'POSE')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 100)
                utils.set_attr_if_exists(brush, 'strength', 0.65)
                utils.set_attr_if_exists(brush, 'pose_origin_type', 'TOPOLOGY')
                utils.set_attr_if_exists(brush, 'use_automasking_topology', True)
                utils.set_attr_if_exists(brush, 'use_automasking_face_sets', True)
        elif profile == 'CLEANUP':
            utils.select_sculpt_tool(context, 'SMOOTH')
            brush = utils.get_active_brush(context)
            if brush:
                utils.set_attr_if_exists(brush, 'size', 120)
                utils.set_attr_if_exists(brush, 'strength', 0.55)
                utils.set_attr_if_exists(brush, 'auto_smooth_factor', 0.0)

        if sculpt:
            utils.set_attr_if_exists(sculpt, 'use_symmetry_x', True)

        self.report({'INFO'}, _smart_utils.localize_bilingual_format('Profile applied: {v0}. / プロファイル適用: {v1}', v0=profile, v1=profile))
        return {'FINISHED'}


class SSS_OT_mask_action(Operator):
    bl_idname = "smart_sculpt.mask_action"
    bl_label = "Mask Action"
    bl_description = _smart_utils.localize_bilingual_text((
        "Apply a common mask operation like smooth, sharpen, grow, shrink, invert, or cavity masking. "
        "/ スムーズ、シャープ、拡張、縮小、反転、キャビティマスクなど、よく使うマスク処理を適用します。"
    ))
    bl_options = {'UNDO'}

    action: EnumProperty(
        name="Action",
        description=_smart_utils.localize_bilingual_text("Mask operation to run on the current sculpt mask / 現在のスカルプトマスクへ実行する処理です"),
        items=[
            ('SMOOTH', "Smooth", _smart_utils.localize_bilingual_text("Blur the mask / マスクをぼかす")),
            ('SHARPEN', "Sharpen", _smart_utils.localize_bilingual_text("Sharpen the mask / マスクをシャープ化")),
            ('GROW', "Grow", _smart_utils.localize_bilingual_text("Grow the mask / マスクを広げる")),
            ('SHRINK', "Shrink", _smart_utils.localize_bilingual_text("Shrink the mask / マスクを縮める")),
            ('INVERT', "Invert", _smart_utils.localize_bilingual_text("Invert the mask / マスク反転")),
            ('CLEAR', "Clear", _smart_utils.localize_bilingual_text("Remove the mask / マスク解除")),
            ('CAVITY', "Cavity", _smart_utils.localize_bilingual_text("Generate a cavity mask / キャビティからマスク生成")),
        ],
    )
    iterations: IntProperty(
        name="Iterations",
        description=_smart_utils.localize_bilingual_text("How many times to repeat the chosen mask grow/shrink/smooth operation / 選んだマスクの拡張・縮小・スムーズ処理を何回繰り返すかです"),
        default=1,
        min=1,
        max=100,
    )

    @_transactions.transactional_execute
    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            action_map = {
                'SMOOTH': 'SMOOTH',
                'SHARPEN': 'SHARPEN',
                'GROW': 'GROW',
                'SHRINK': 'SHRINK',
                'INVERT': 'INVERT',
                'CLEAR': 'CLEAR',
                'CAVITY': 'CAVITY',
            }
            mapped = action_map.get(self.action, 'SET')
            strict_args = {'operation': mapped}
            if self.action in {'SHARPEN', 'GROW', 'SHRINK'} or self.properties.is_property_set('iterations'):
                strict_args['iterations'] = self.iterations
            result = utils.run_strict_edit_mode_operator(context, 'mask_operation', **strict_args)
            if 'CANCELLED' in result:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text('Edit Mode mask action failed. / 編集モードマスク処理に失敗しました。'))
                return {'CANCELLED'}
            return {'FINISHED'}
        # Blender's native sculpt mask operators can terminate the process
        # when invoked without an interactive 3D View (for example during
        # command-line validation).  The normal GUI path remains unchanged;
        # headless callers get a clean, reportable cancellation instead of a
        # native crash that Python exception handling cannot intercept.
        if bool(getattr(bpy.app, 'background', False)):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text(
                'Sculpt mask actions require an interactive 3D View. / スカルプトマスク操作には対話可能な3Dビューが必要です。'
            ))
            return {'CANCELLED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}

        try:
            if self.action in {'SMOOTH', 'SHARPEN', 'GROW', 'SHRINK'}:
                utils.safe_operator_call(
                    bpy.ops.sculpt.mask_filter,
                    # Blender ignores iterations while auto_iteration_count is on, so
                    # the automatic density-based count is kept only when no explicit
                    # count was given.
                    [{
                        'filter_type': self.action,
                        'iterations': self.iterations,
                        'auto_iteration_count': not self.properties.is_property_set('iterations'),
                    }],
                )
            elif self.action == 'INVERT':
                utils.safe_operator_call(
                    bpy.ops.paint.mask_flood_fill,
                    [{'mode': 'INVERT'}],
                )
            elif self.action == 'CLEAR':
                utils.safe_operator_call(
                    bpy.ops.paint.mask_flood_fill,
                    [{'mode': 'VALUE', 'value': 0.0}],
                )
            elif self.action == 'CAVITY':
                utils.safe_operator_call(bpy.ops.sculpt.mask_from_cavity)
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Mask action failed: {v0} / マスク処理に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        return {'FINISHED'}


class SSS_OT_face_set_action(Operator):
    bl_idname = "smart_sculpt.face_set_action"
    bl_label = "Face Set Action"
    bl_description = _smart_utils.localize_bilingual_text((
        "Create or manage face sets using safe wrappers around the built-in sculpt operators. "
        "/ 内蔵スカルプトオペレーターを安全に包んだラッパーでフェイスセットを作成・管理します。"
    ))
    bl_options = {'UNDO'}

    action: EnumProperty(
        name="Action",
        description=_smart_utils.localize_bilingual_text("Face-set creation or visibility command to run / 実行するフェイスセット作成または表示制御コマンドです"),
        items=[
            ('INIT_LOOSE', "Loose Parts", _smart_utils.localize_bilingual_text("Initialize face sets from loose parts / ルーズパーツごとに初期化")),
            ('INIT_MATERIALS', "Materials", _smart_utils.localize_bilingual_text("Initialize face sets from material slots / マテリアルスロットから初期化")),
            ('INIT_NORMALS', "Normals", _smart_utils.localize_bilingual_text("Initialize face sets from normals / 法線から初期化")),
            ('INIT_UV_SEAMS', "UV Seams", _smart_utils.localize_bilingual_text("Initialize face sets from UV seams / UV シームから初期化")),
            ('INIT_SHARP_EDGES', "Sharp Edges", _smart_utils.localize_bilingual_text("Initialize face sets from sharp edges / シャープエッジから初期化")),
            ('INIT_CREASES', "Creases", _smart_utils.localize_bilingual_text("Initialize face sets from crease edges / クリース辺から初期化")),
            ('INIT_BEVEL_WEIGHT', "Bevel Weight", _smart_utils.localize_bilingual_text("Initialize face sets from bevel weights / ベベルウェイトから初期化")),
            ('QUICK_POLYGROUP', "Quick Polygroup", _smart_utils.localize_bilingual_text("Approximate a fast polygroup split using normals first, then seam or edge boundaries, and finally safer structural fallbacks / まず法線、次にシームやエッジ境界、最後に安全な構造フォールバックで素早いポリグループ分割を近似")),
            ('MASKED', "From Mask", _smart_utils.localize_bilingual_text("Create a face set from the current mask / 現在のマスクから作成")),
            ('VISIBLE', "From Visible", _smart_utils.localize_bilingual_text("Create a face set from visible areas / 可視部分から作成")),
            ('RANDOMIZE', "Randomize Colors", _smart_utils.localize_bilingual_text("Randomize face-set display colors / 表示色をランダム化")),
            ('TOGGLE_VIS', "Toggle Visibility", _smart_utils.localize_bilingual_text("Show only the active face set / アクティブフェイスセットのみ表示")),
            ('SHOW_ACTIVE', "Show Active", _smart_utils.localize_bilingual_text("Show the active face set / アクティブフェイスセットを表示")),
            ('HIDE_ACTIVE', "Hide Active", _smart_utils.localize_bilingual_text("Hide the active face set / アクティブフェイスセットを非表示")),
            ('SHOW_ALL', "Show All", _smart_utils.localize_bilingual_text("Reveal all hidden geometry / 非表示をすべて解除")),
        ],
    )

    @_transactions.transactional_execute
    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            action_map = {
                'SHOW_ALL': 'REVEAL',
                'SHOW_ACTIVE': 'SELECT',
                'TOGGLE_VIS': 'SELECT',
                'HIDE_ACTIVE': 'HIDE',
                'RANDOMIZE': 'ASSIGN',
            }
            mapped = action_map.get(self.action, 'ASSIGN')
            result = utils.run_strict_edit_mode_operator(context, 'face_set_operation', operation=mapped)
            if 'CANCELLED' in result:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text('Edit Mode face-set action failed. / 編集モードフェイスセット処理に失敗しました。'))
                return {'CANCELLED'}
            return {'FINISHED'}
        # Native face-set initialization also has an unrecoverable headless
        # execution path in Blender 5.1.  Keep command-line validation safe;
        # interactive 3D View behavior is unaffected.
        if bool(getattr(bpy.app, 'background', False)):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text(
                'Face-set actions require an interactive 3D View. / フェイスセット操作には対話可能な3Dビューが必要です。'
            ))
            return {'CANCELLED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}

        try:
            if self.action == 'INIT_LOOSE':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'LOOSE_PARTS'}],
                )
            elif self.action == 'INIT_MATERIALS':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'MATERIALS'}],
                )
            elif self.action == 'INIT_NORMALS':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'NORMALS', 'threshold': 0.5}],
                )
            elif self.action == 'INIT_UV_SEAMS':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'UV_SEAMS'}],
                )
            elif self.action == 'INIT_SHARP_EDGES':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'SHARP_EDGES'}],
                )
            elif self.action == 'INIT_CREASES':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'CREASES'}],
                )
            elif self.action == 'INIT_BEVEL_WEIGHT':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [{'mode': 'BEVEL_WEIGHT'}],
                )
            elif self.action == 'QUICK_POLYGROUP':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_init,
                    [
                        {'mode': 'NORMALS', 'threshold': 0.5},
                        {'mode': 'NORMALS'},
                        {'mode': 'UV_SEAMS'},
                        {'mode': 'SHARP_EDGES'},
                        {'mode': 'CREASES'},
                        {'mode': 'BEVEL_WEIGHT'},
                        {'mode': 'MATERIALS'},
                        {'mode': 'LOOSE_PARTS'},
                    ],
                )
            elif self.action == 'MASKED':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_create,
                    [{'mode': 'MASKED'}],
                )
            elif self.action == 'VISIBLE':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_sets_create,
                    [{'mode': 'VISIBLE'}],
                )
            elif self.action == 'RANDOMIZE':
                utils.safe_operator_call(bpy.ops.sculpt.face_sets_randomize_colors)
            elif self.action == 'TOGGLE_VIS':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_set_change_visibility,
                    [{'mode': 'TOGGLE'}],
                )
            elif self.action == 'SHOW_ACTIVE':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_set_change_visibility,
                    [{'mode': 'SHOW_ACTIVE'}],
                )
            elif self.action == 'HIDE_ACTIVE':
                utils.safe_operator_call(
                    bpy.ops.sculpt.face_set_change_visibility,
                    [{'mode': 'HIDE_ACTIVE'}],
                )
            elif self.action == 'SHOW_ALL':
                utils.safe_operator_call(
                    bpy.ops.paint.hide_show_all,
                    [{'action': 'SHOW'}],
                )
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Face-set action failed: {v0} / フェイスセット処理に失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}

        return {'FINISHED'}


class SSS_OT_apply_mesh_filter(Operator):
    bl_idname = "smart_sculpt.apply_mesh_filter"
    bl_label = "Apply Mesh Filter"
    bl_description = _smart_utils.localize_bilingual_text((
        "Run Blender's built-in mesh filter with safe argument fallbacks. This is useful for quick surface cleanup, sharpening, inflation, or relaxation. "
        "/ Blender 内蔵メッシュフィルターを安全な引数フォールバック付きで実行します。表面の整理、シャープ化、膨張、リラックスに便利です。"
    ))
    bl_options = {'UNDO'}

    filter_type: EnumProperty(
        name="Filter Type",
        description=_smart_utils.localize_bilingual_text("Built-in mesh filter preset to apply / 適用する内蔵メッシュフィルタープリセットです"),
        items=[
            ('SMOOTH', "Smooth", _smart_utils.localize_bilingual_text("Smooth / スムーズ")),
            ('RELAX', "Relax", _smart_utils.localize_bilingual_text("Relax / リラックス")),
            ('SURFACE_SMOOTH', "Surface Smooth", _smart_utils.localize_bilingual_text("Surface Smooth / サーフェススムーズ")),
            ('SHARPEN', "Sharpen", _smart_utils.localize_bilingual_text("Sharpen / シャープ")),
            ('INFLATE', "Inflate", _smart_utils.localize_bilingual_text("Inflate / 膨張")),
        ],
        default='SURFACE_SMOOTH',
    )
    strength: FloatProperty(
        name="Strength",
        description=_smart_utils.localize_bilingual_text("Strength of the selected filter operation / 選択したフィルター処理の強さです"),
        default=0.4,
        min=0.0,
        max=5.0,
    )

    @_transactions.transactional_execute
    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            filter_map = {
                'SMOOTH': 'FILTER_SMOOTH',
                'RELAX': 'FILTER_RELAX',
                'SURFACE_SMOOTH': 'FILTER_RELAX',
                'SHARPEN': 'FILTER_SHARPEN',
                'INFLATE': 'INFLATE',
            }
            strict_settings = utils.strict_edit_mode_sculpt_settings(context)
            if strict_settings is not None:
                try:
                    strict_settings.strength = float(self.strength)
                except Exception:
                    pass
            result = utils.run_strict_edit_mode_operator(context, 'vertex_operation', operation=filter_map.get(self.filter_type, 'FILTER_SMOOTH'))
            if 'CANCELLED' in result:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text('Edit Mode mesh filter failed. / 編集モードメッシュフィルターに失敗しました。'))
                return {'CANCELLED'}
            return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        try:
            utils.safe_operator_call(
                bpy.ops.sculpt.mesh_filter,
                [
                    {'type': self.filter_type, 'strength': self.strength},
                    {'type': self.filter_type},
                    {},
                ],
            )
        except Exception as exc:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_format('Mesh filter failed: {v0} / メッシュフィルターに失敗しました: {v1}', v0=exc, v1=exc))
            return {'CANCELLED'}
        return {'FINISHED'}


def _mesh_float_attribute(mesh, name: str, count: int):
    values = np.zeros(count, dtype=np.float32)
    attribute = mesh.attributes.get(name)
    if attribute is not None and len(attribute.data) == count:
        attribute.data.foreach_get('value', values)
    return values


def _mesh_bool_attribute(mesh, name: str, count: int):
    values = np.zeros(count, dtype=bool)
    attribute = mesh.attributes.get(name)
    if attribute is not None and len(attribute.data) == count:
        attribute.data.foreach_get('value', values)
    return values


def _apply_cloth_filter_to_mesh(obj, filter_type: str, strength: float) -> bool:
    """Non-interactive cloth filter: sculpt.cloth_filter can only run as a mouse-driven modal."""
    mesh = obj.data
    count = len(mesh.vertices)
    if count == 0:
        return False
    key = obj.active_shape_key
    source = key.data if key is not None else mesh.vertices
    rest = np.empty(count * 3, dtype=np.float64)
    source.foreach_get('co', rest)
    rest = rest.reshape(-1, 3)

    masked = _mesh_float_attribute(mesh, '.sculpt_mask', count)
    weights = np.clip(1.0 - masked, 0.0, 1.0)
    weights[_mesh_bool_attribute(mesh, '.hide_vert', count)] = 0.0
    if not np.any(weights > 0.0):
        return False

    edges = np.empty(len(mesh.edges) * 2, dtype=np.int32)
    mesh.edges.foreach_get('vertices', edges)
    edges = edges.reshape(-1, 2)
    first, second = edges[:, 0], edges[:, 1]
    lengths = np.linalg.norm(rest[second] - rest[first], axis=1)
    size = max(float(np.linalg.norm(rest.max(axis=0) - rest.min(axis=0))), 1e-6)
    step_length = size * 0.01 * float(strength)
    amount = min(float(strength), 1.0)

    normals = np.empty(count * 3, dtype=np.float64)
    mesh.vertex_normals.foreach_get('vector', normals)
    normals = normals.reshape(-1, 3)
    if filter_type == 'GRAVITY':
        down = np.array(obj.matrix_world.to_3x3().inverted_safe() @ Vector((0.0, 0.0, -1.0)), dtype=np.float64)
        down /= max(float(np.linalg.norm(down)), 1e-9)
        if not np.any(masked > 0.0):
            depth = rest @ down
            depth = (depth - depth.min()) / max(float(depth.max() - depth.min()), 1e-9)
            weights = weights * np.clip((depth - 0.1) / 0.9, 0.0, 1.0)
    elif filter_type == 'INFLATE':
        lengths = lengths * (1.0 + 0.5 * amount)
    elif filter_type == 'EXPAND':
        lengths = lengths * (1.0 + 0.3 * amount)

    two_sided = filter_type == 'EXPAND'
    center = np.average(rest, axis=0, weights=np.maximum(weights, 1e-6))
    position = rest.copy()
    for _step in range(12):
        if filter_type == 'GRAVITY':
            position += down * step_length * weights[:, None]
        elif filter_type == 'INFLATE':
            position += normals * step_length * weights[:, None]
        elif filter_type == 'EXPAND':
            position += normals * step_length * 0.1 * weights[:, None]
        else:
            toward = center - position
            toward /= np.maximum(np.linalg.norm(toward, axis=1, keepdims=True), 1e-9)
            position += toward * step_length * weights[:, None]
        for _iteration in range(4):
            delta = position[second] - position[first]
            current = np.maximum(np.linalg.norm(delta, axis=1), 1e-9)
            error = (current - lengths) / current
            if not two_sided:
                error = np.maximum(error, 0.0)
            correction = delta * (error * 0.5)[:, None]
            for axis in range(3):
                position[:, axis] += (
                    np.bincount(first, correction[:, axis], minlength=count)
                    - np.bincount(second, correction[:, axis], minlength=count)
                ) * 0.25 * weights
    # A vertex that may not move stays exactly where it was.
    position[weights <= 0.0] = rest[weights <= 0.0]

    flat = position.ravel()
    source.foreach_set('co', flat)
    if key is not None and key == getattr(mesh.shape_keys, 'reference_key', None):
        mesh.vertices.foreach_set('co', flat)
    mesh.update()
    return True


class SSS_OT_apply_cloth_filter(Operator):
    bl_idname = "smart_sculpt.apply_cloth_filter"
    bl_label = "Apply Cloth Filter"
    bl_description = _smart_utils.localize_bilingual_text((
        "Deform the whole mesh like cloth at once, keeping edges from stretching: Gravity, Inflate, Expand, or Pinch. Masked and hidden vertices do not move. With no mask, Gravity holds the top of the mesh in place. "
        "/ 辺が伸びないように保ちながら、メッシュ全体を布のように一度に変形します（重力・膨張・拡張・つまみ）。マスクした頂点と非表示の頂点は動きません。マスクが無い時の重力は、メッシュの上端を固定して垂らします。"
    ))
    bl_options = {'UNDO'}

    filter_type: EnumProperty(
        name="Filter Type",
        description=_smart_utils.localize_bilingual_text("Cloth filter preset to apply / 適用するクロスフィルタープリセットです"),
        items=[
            ('GRAVITY', "Gravity", _smart_utils.localize_bilingual_text("Gravity / 重力")),
            ('INFLATE', "Inflate", _smart_utils.localize_bilingual_text("Inflate / 膨張")),
            ('EXPAND', "Expand", _smart_utils.localize_bilingual_text("Expand / 拡張")),
            ('PINCH', "Pinch", _smart_utils.localize_bilingual_text("Pinch / つまみ")),
        ],
        default='GRAVITY',
    )
    strength: FloatProperty(
        name="Strength",
        description=_smart_utils.localize_bilingual_text("Strength of the selected cloth-style filter / 選択したクロス風フィルターの強さです"),
        default=0.4,
        min=0.0,
        max=5.0,
    )

    @_transactions.transactional_execute
    def execute(self, context):
        obj = utils.active_mesh_object(context)
        if obj is None:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No active mesh. / アクティブなメッシュがありません。"))
            return {'CANCELLED'}
        if utils.strict_edit_mode_sculpt_active(context):
            filter_map = {
                'GRAVITY': 'GRAB',
                'INFLATE': 'INFLATE',
                'EXPAND': 'FILTER_SCALE',
                'PINCH': 'PINCH',
            }
            strict_settings = utils.strict_edit_mode_sculpt_settings(context)
            if strict_settings is not None:
                try:
                    strict_settings.strength = float(self.strength)
                    strict_settings.brush_strength = float(self.strength)
                except Exception:
                    pass
            result = utils.run_strict_edit_mode_operator(context, 'vertex_operation', operation=filter_map.get(self.filter_type, 'FILTER_RELAX'))
            if 'CANCELLED' in result:
                self.report({'WARNING'}, _smart_utils.localize_bilingual_text('Edit Mode cloth-style filter failed. / 編集モードクロス風フィルターに失敗しました。'))
                return {'CANCELLED'}
            return {'FINISHED'}
        if not utils.ensure_sculpt_mode(context, obj):
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("Could not enter Sculpt Mode. / スカルプトモードへ切り替えられませんでした。"))
            return {'CANCELLED'}
        utils.ensure_object_mode(context, obj)
        moved = _apply_cloth_filter_to_mesh(obj, self.filter_type, self.strength)
        utils.ensure_sculpt_mode(context, obj)
        if not moved:
            self.report({'WARNING'}, _smart_utils.localize_bilingual_text("No vertices can move: everything is masked or hidden. / 動かせる頂点がありません（すべてマスク済みか非表示です）。"))
            return {'CANCELLED'}
        return {'FINISHED'}


classes = (
    SSS_OT_set_sculpt_tool,
    SSS_OT_store_active_brush_slot,
    SSS_OT_use_brush_slot,
    SSS_OT_clear_brush_slot,
    SSS_OT_apply_profile,
    SSS_OT_mask_action,
    SSS_OT_face_set_action,
    SSS_OT_apply_mesh_filter,
    SSS_OT_apply_cloth_filter,
)
