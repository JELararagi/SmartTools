# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
import bpy

from . import utils as _utils
from .navigation_properties import _localized_layout, _operator_enum_items, _text

class CORE_OT_npanel_popup_menu(bpy.types.Operator):
    bl_idname = "wm.core_npanel_popup_menu"
    bl_label = "N Panel Menu"
    bl_description = "Open this menu from the Smart Sculpt N-panel."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    menu_idname: bpy.props.StringProperty(options={'HIDDEN'})
    popup_label: bpy.props.StringProperty(options={'HIDDEN'})
    popup_width: bpy.props.IntProperty(default=440, min=220, max=2000, options={'HIDDEN'})
    popup_rows: bpy.props.IntProperty(default=18, min=4, max=64, options={'HIDDEN'})

    def execute(self, context):
        del context
        return {'FINISHED'}

    def invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_popup(self, width=max(220, int(self.popup_width or 440)))
        except Exception:
            return {'CANCELLED'}

    def draw(self, context):
        layout = _localized_layout(self.layout)
        menu_idname = str(self.menu_idname or '')
        if not menu_idname:
            layout.label(text=_text('Menu', 'メニュー', context))
            return
        menu_contents = getattr(layout, 'menu_contents', None)
        if callable(menu_contents):
            try:
                menu_contents(menu_idname)
                return
            except Exception:
                pass
        op = layout.operator('wm.call_menu', text=str(self.popup_label or menu_idname), icon='DOWNARROW_HLT')
        op.name = menu_idname


class CORE_OT_npanel_operator_enum_popup(bpy.types.Operator):
    bl_idname = "wm.core_npanel_operator_enum_popup"
    bl_label = "N Panel List"
    bl_description = "Open operator choices from the Smart Sculpt N-panel."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    operator_idname: bpy.props.StringProperty(options={'HIDDEN'})
    property_idname: bpy.props.StringProperty(options={'HIDDEN'})
    popup_label: bpy.props.StringProperty(options={'HIDDEN'})
    popup_width: bpy.props.IntProperty(default=440, min=220, max=2000, options={'HIDDEN'})
    popup_rows: bpy.props.IntProperty(default=0, min=0, max=64, options={'HIDDEN'})

    def execute(self, context):
        del context
        return {'FINISHED'}

    def invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_popup(self, width=max(220, int(self.popup_width or 440)))
        except Exception:
            return {'CANCELLED'}

    def draw(self, context):
        layout = _localized_layout(self.layout)
        op_id = str(self.operator_idname or '')
        prop_id = str(self.property_idname or '')
        items = _operator_enum_items(op_id, prop_id)
        if not items:
            layout.label(text=str(self.popup_label or _text('Items', '項目', context)))
            return
        col = layout.column(align=True)
        for item in items:
            try:
                icon_id = str(item.get('icon') or 'DOT')
                try:
                    icon_id = _utils.safe_icon(icon_id, 'DOT')
                except Exception:
                    pass
                op = col.operator(op_id, text=str(item.get('name') or item.get('identifier') or 'Item'), icon=icon_id)
                setattr(op, prop_id, str(item.get('identifier') or ''))
            except Exception:
                col.label(text=str(item.get('name') or item.get('identifier') or 'Item'))


class CORE_OT_npanel_call_menu_pie(bpy.types.Operator):
    bl_idname = "wm.core_npanel_call_menu_pie"
    bl_label = "N Panel Pie Menu"
    bl_description = "Open this pie menu from the Smart Sculpt N-panel."
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    menu_idname: bpy.props.StringProperty(options={'HIDDEN'})
    popup_label: bpy.props.StringProperty(options={'HIDDEN'})
    popup_width: bpy.props.IntProperty(default=640, min=220, max=2000, options={'HIDDEN'})
    popup_rows: bpy.props.IntProperty(default=18, min=4, max=64, options={'HIDDEN'})

    def execute(self, context):
        del context
        menu_idname = str(self.menu_idname or '')
        if not menu_idname:
            return {'CANCELLED'}
        try:
            return bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name=menu_idname)
        except Exception:
            return {'CANCELLED'}


classes = (
    CORE_OT_npanel_popup_menu,
    CORE_OT_npanel_operator_enum_popup,
    CORE_OT_npanel_call_menu_pie,
)


