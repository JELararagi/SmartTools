# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
import bpy
from bpy.props import BoolProperty, StringProperty
from bpy.types import PropertyGroup

from . import utils


class SSS_Preferences(PropertyGroup):
    bl_idname = __package__
    default_exchange_dir: StringProperty(
        name="Default Exchange Folder",
        description=utils.beginner_property_description(
            "Fallback folder used by export/import exchange tools when the scene override is empty. Leave blank to keep generated exchange files below the Smart_Sculpt_Suite folder in the Blender config folder. "
            "/ シーン側の設定が空の場合に、受け渡し書き出し・読み込みで使う既定フォルダです。空欄なら生成される受け渡しファイルを Blender の設定フォルダー内の Smart_Sculpt_Suite 配下へ保存します。",
            how_to_en="Set this only when you intentionally want every scene to use the same manual handoff folder outside the default exchange area. Leave it empty for the safer default config folder.",
            how_to_ja="全シーンで同じ手動受け渡し先を既定の受け渡し領域外に置きたい時だけ指定します。通常は空欄のままにすると、より安全な設定フォルダーの保存先が使われます。",
        ),
        subtype='DIR_PATH',
        default="",
    )
    auto_duplicate_destructive: BoolProperty(
        name="Auto Duplicate Before Destructive Ops",
        description=utils.beginner_property_description(
            "When a destructive operation is risky because of shape keys, shared mesh data, or other constraints, "
            "make a safe duplicate first whenever possible. / シェイプキーや共有メッシュなどの理由で破壊的処理が危険な場合、可能なら先に安全な複製を作成します。",
            how_to_en="Keep this enabled unless you intentionally want faster but riskier destructive edits on the original object.",
            how_to_ja="元オブジェクトへ直接かつ高速に破壊的編集したい明確な理由がない限り、通常はオンのままにしておくのが安全です。",
        ),
        default=True,
    )
    remove_cutters_after_boolean: BoolProperty(
        name="Remove Cutters After Applied Boolean",
        description=utils.beginner_property_description(
            "Delete temporary cutter objects after a boolean modifier has been successfully applied. "
            "/ ブーリアン適用成功後に一時カッターオブジェクトを削除します。",
            how_to_en="Enable this when you want a cleaner scene after finishing booleans. Disable it when you may want to reuse or edit the cutters again.",
            how_to_ja="ブーリアン後のシーンをすっきり保ちたい時はオン、後でカッターを再利用・再調整したい時はオフにします。",
        ),
        default=False,
    )
    def draw(self, context):
        try:
            view = getattr(getattr(context, "preferences", None), "view", None)
            use_translate = getattr(view, "use_translate_interface", True) if view else True
            language = str(getattr(view, "language", "DEFAULT") or "DEFAULT") if view else "DEFAULT"
            locale_ja = bool(use_translate) and (language.upper().startswith("JA") or (language.upper() in {"DEFAULT", "DEFAULT_LANGUAGE"} and str(getattr(bpy.app.translations, "locale", "") or "").lower().startswith("ja")))
        except Exception:
            locale_ja = False
        en = lambda a, b: b if locale_ja else a
        layout = self.layout
        layout.label(text="Smart Sculpt", icon='SCULPTMODE_HLT')
        layout.label(text=en("Blender Extension compatible package", "Blender 拡張機能互換パッケージ"), icon='NONE')
        layout.label(text=en("Language follows Blender automatically.", "言語は Blender の設定に自動追従します。"), icon='WORLD')
        col = layout.column(align=True)
        col.prop(self, "default_exchange_dir", text=en("Default Exchange Folder", "既定の受け渡しフォルダ"))
        col.prop(self, "auto_duplicate_destructive", text=en("Auto Duplicate Before Destructive Ops", "破壊的処理前に自動複製"))
        col.prop(self, "remove_cutters_after_boolean", text=en("Remove Cutters After Applied Boolean", "適用後にカッター削除"))
        layout.separator()
        layout.label(text=en("Installation Notes", "インストールメモ"), icon='NONE')
        layout.label(text=en("Install the ZIP with Install from Disk, then enable the add-on.", "ZIP を「ディスクからインストール」で導入し、その後アドオンを有効化してください。"))
        layout.label(text=en("Use the Smart Sculpt N-panel after enabling the add-on.", "有効化後は専用のスマートスカルプト Nパネルから使用します。"))


# Schema class only; native AddonPreferences UI is intentionally not registered.
# Smart Sculpt uses the centralized root preferences container in
# preferences.py so Blender's Preferences panel stays hidden.
classes = ()
