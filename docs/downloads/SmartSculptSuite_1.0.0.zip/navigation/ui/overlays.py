# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Event-driven immutable navigation border overlay."""
from __future__ import annotations
import bpy
from ... import _sss_lifecycle as _lifecycle
from ... import _sss_gpu_state as _gpu_state
from ..properties import get_addon_preferences, get_wm_props

_draw_handler = None
_draw_state = {"alive": False, "packet": _gpu_state.EMPTY_PACKET}


def _safe_getattr(obj, name, default=None):
    try: return getattr(obj, name, default)
    except Exception: return default


def _viewport(region):
    try: return (int(region.x), int(region.y), int(region.width), int(region.height))
    except Exception: return None


def refresh(context=None) -> None:
    """Rebuild the finished GPU packet outside the draw callback."""
    global _draw_state
    context = context or getattr(bpy, "context", None)
    try:
        prefs = get_addon_preferences(context)
        wm_props = get_wm_props(context)
        region = getattr(context, "region", None)
        enabled = bool(_safe_getattr(wm_props, "enabled", False) and _safe_getattr(prefs, "show_border_overlay", False))
        width = int(_safe_getattr(region, "width", 0) or 0)
        height = int(_safe_getattr(region, "height", 0) or 0)
        bw = max(0, min(int(_safe_getattr(prefs, "border_width", 75) or 75), max(0, width // 2)))
        bh = max(0, min(int(_safe_getattr(prefs, "border_height", 75) or 75), max(0, height // 2)))
        color = tuple(float(v) for v in tuple(_safe_getattr(prefs, "border_color", (0.3, 0.6, 1.0, 0.6)))[:4])
        line_width = max(1.0, float(_safe_getattr(prefs, "border_line_width", 1.0) or 1.0))
    except Exception:
        enabled = False; width = height = bw = bh = 0
        color = (0.3, 0.6, 1.0, 0.6); line_width = 1.0; region = None
    primitives = ()
    if enabled and width > 0 and height > 0 and width - bw > bw and height - bh > bh:
        coords = ((bw, bh), (width - bw, bh), (width - bw, height - bh), (bw, height - bh))
        primitives = ({"mode": "LINE_LOOP", "coords": coords, "color": color,
                       "blend": "ALPHA", "line_width": line_width},)
    _draw_state = {"alive": bool(enabled), "packet": _gpu_state.build_packet(
        primitives=primitives, expected_viewport=_viewport(region))}


def draw_border_overlay():
    """Draw callback: immutable packet replay only."""
    _gpu_state.replay_state_packet(_draw_state)


def register():
    global _draw_handler
    refresh(getattr(bpy, "context", None))
    if _draw_handler is None and _draw_state.get("alive", False):
        _draw_handler, _wrapped = _lifecycle.add_draw_handler(
            bpy.types.SpaceView3D, draw_border_overlay, (), "WINDOW", "POST_PIXEL")


def unregister():
    global _draw_handler, _draw_state
    if _draw_handler is not None:
        _lifecycle.remove_draw_handler(bpy.types.SpaceView3D, _draw_handler, "WINDOW")
        _draw_handler = None
    _draw_state = {"alive": False, "packet": _gpu_state.EMPTY_PACKET}
