# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
from __future__ import annotations

def is_over_scrubber_bar(*_args, **_kwargs) -> bool:
    """Fallback stub used when the optional undo scrubber module is not bundled."""
    return False
