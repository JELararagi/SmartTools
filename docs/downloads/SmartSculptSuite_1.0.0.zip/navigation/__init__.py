"""
SculptNavigation - ZBrush/3D-Coat style viewport navigation for Blender.
Navigate on empty space, sculpt on mesh, with a safety border zone.
"""
import bpy
from . import properties
from . import keymaps
from . import translation
from .operators import navigation
from .operators import brush_adjust
from .operators import canvas_navigation
from .ui import overlays
from .ui import panels

_REGISTERED = False
_COMPLETED_MODULES = []

def _registration_modules():
    return (translation, properties, panels, navigation, brush_adjust, canvas_navigation, keymaps)

def register():
    global _REGISTERED
    if _REGISTERED:
        return
    completed=[]
    try:
        for module in _registration_modules():
            module.register()
            completed.append(module)
        _COMPLETED_MODULES[:] = completed
        _REGISTERED=True
    except Exception:
        for module in reversed(completed):
            try: module.unregister()
            except Exception: pass
        _COMPLETED_MODULES.clear()
        _REGISTERED=False
        raise

def rollback_registration():
    global _REGISTERED
    modules=tuple(_COMPLETED_MODULES) or _registration_modules()
    for module in reversed(modules):
        try: module.unregister()
        except Exception: pass
    try: overlays.unregister()
    except Exception: pass
    _COMPLETED_MODULES.clear()
    _REGISTERED=False

def unregister():
    rollback_registration()
if __name__ == '__main__':
    register()
