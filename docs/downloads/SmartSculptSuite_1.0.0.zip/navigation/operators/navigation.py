# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""
Navigation utilities for SculptNavigation.
Contains the toggle operator for enabling/disabling navigation.
"""

import bpy
from ... import rna_safety as _rna_safety

from ...core import utils as _smart_utils

from ..properties import get_wm_props


def _tr(text: str) -> str:
    try:
        return str(bpy.app.translations.pgettext_iface(text) or text)
    except Exception:
        return text


class SCULPTNAV_OT_toggle(bpy.types.Operator):
    """Toggle SculptNavigation on/off"""

    bl_idname = "sculptnav.toggle"
    bl_label = "Toggle SculptNavigation"
    bl_options = {'INTERNAL'}
    _sms_no_undo = True

    def execute(self, context):
        wm_props = get_wm_props(context)
        wm_props.enabled = not wm_props.enabled
        message = "SculptNavigation enabled" if wm_props.enabled else "SculptNavigation disabled"
        self.report({'INFO'}, _tr(message))
        return {'FINISHED'}


classes = (
    SCULPTNAV_OT_toggle,
)



def _safe_register_class(cls):
    return _rna_safety.register_class(cls)


def _safe_unregister_class(cls):
    try:
        return _rna_safety.unregister_class(cls)
    except Exception:
        return False

def register():
    try:
        _smart_utils.normalize_class_texts(classes)
        _smart_utils.register_runtime_translations()
    except Exception:
        pass
    for cls in classes:
        _safe_register_class(cls)


def unregister():
    for cls in reversed(classes):
        _safe_unregister_class(cls)
