# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""
Crash-safe hit testing system for SculptNavigation.

Blender 5.1 can crash in native UI/event handlers when an add-on mutates
viewport overlay state, registers one-shot draw handlers, or forces redraws
while panels and modes are being rebuilt.  This module intentionally avoids
POST_PIXEL depth-buffer probes, GPUOffScreen redraws, and overlay/gizmo mutation.
It uses only conservative context checks and standard scene/object ray casts.
"""

from __future__ import annotations

from collections import OrderedDict
from math import cos, pi, sin
from typing import Any

import bpy
from bpy_extras import view3d_utils
from mathutils import Vector

_RADIAL_OFFSETS_CACHE_LIMIT = 64
_RADIAL_OFFSETS_CACHE: OrderedDict[tuple[int, int], tuple[tuple[int, int], ...]] = OrderedDict()


class HitTestResult:
    """Structured result from hit testing."""

    __slots__ = ('hit_type', 'hit_object', 'hit_location', 'hit_normal',
                 'hit_face_index', 'distance', 'in_border_zone')

    def __init__(self):
        self.hit_type = 'EMPTY'  # 'EMPTY', 'MESH', 'GIZMO', 'UI'
        self.hit_object = None
        self.hit_location = None
        self.hit_normal = None
        self.hit_face_index = -1
        self.distance = float('inf')
        self.in_border_zone = False

    def to_dict(self):
        return {
            'hit_type': self.hit_type,
            'hit_object': self.hit_object,
            'hit_location': self.hit_location,
            'hit_normal': self.hit_normal,
            'hit_face_index': self.hit_face_index,
            'distance': self.distance,
            'in_border_zone': self.in_border_zone,
        }


def _rna_pointer_is_valid(value: Any) -> bool:
    if value is None:
        return False
    try:
        _ = value.name
    except ReferenceError:
        return False
    except Exception:
        pass
    try:
        _ = value.as_pointer()
    except ReferenceError:
        return False
    except Exception:
        return False
    return True


def _safe_getattr(obj: Any, name: str, default=None):
    try:
        return getattr(obj, name, default)
    except ReferenceError:
        return default
    except Exception:
        return default


def _safe_active_object(context):
    obj = _safe_getattr(context, 'active_object', None)
    if _rna_pointer_is_valid(obj):
        return obj
    obj = _safe_getattr(context, 'object', None)
    if _rna_pointer_is_valid(obj):
        return obj
    try:
        obj = context.view_layer.objects.active
    except Exception:
        obj = None
    return obj if _rna_pointer_is_valid(obj) else None


def _safe_visible_objects(context):
    try:
        return [obj for obj in context.visible_objects if _rna_pointer_is_valid(obj)]
    except Exception:
        return []


def _safe_region_event(context, event):
    region = _safe_getattr(context, 'region', None)
    rv3d = _safe_getattr(context, 'region_data', None)
    try:
        x = int(getattr(event, 'mouse_region_x'))
        y = int(getattr(event, 'mouse_region_y'))
    except Exception:
        return None, None, 0, 0
    if region is None or rv3d is None:
        return None, None, x, y
    return region, rv3d, x, y


def check_border_zone(context, event, border_width=75, border_height=75):
    result = {'in_zone': False, 'edges': []}
    region, _rv3d, x, y = _safe_region_event(context, event)
    if region is None:
        return result
    try:
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
        bw = max(0, int(border_width or 0))
        bh = max(0, int(border_height or 0))
    except Exception:
        return result
    if width <= 0 or height <= 0:
        return result
    if x < bw:
        result['edges'].append('LEFT')
    if x > width - bw:
        result['edges'].append('RIGHT')
    if y < bh:
        result['edges'].append('BOTTOM')
    if y > height - bh:
        result['edges'].append('TOP')
    result['in_zone'] = bool(result['edges'])
    return result


def _get_radial_offsets(max_radius=20, step=4):
    radius_value = max(0, int(max_radius))
    step_value = max(1, int(step))
    cache_key = (radius_value, step_value)
    cached = _RADIAL_OFFSETS_CACHE.get(cache_key)
    if cached is not None:
        _RADIAL_OFFSETS_CACHE.move_to_end(cache_key)
        return cached
    offsets = []
    seen = set()
    for radius in range(step_value, radius_value + 1, step_value):
        num_points = max(8, int((2 * pi * radius) / 4))
        for i in range(num_points):
            angle = (2 * pi * i) / num_points
            x = int(radius * cos(angle))
            y = int(radius * sin(angle))
            key = (x, y)
            if key == (0, 0) or key in seen:
                continue
            seen.add(key)
            offsets.append((x, y, (x * x) + (y * y)))
    offsets.sort(key=lambda item: item[2])
    result = tuple((x, y) for x, y, _dist in offsets)
    _RADIAL_OFFSETS_CACHE[cache_key] = result
    _RADIAL_OFFSETS_CACHE.move_to_end(cache_key)
    while len(_RADIAL_OFFSETS_CACHE) > _RADIAL_OFFSETS_CACHE_LIMIT:
        _RADIAL_OFFSETS_CACHE.popitem(last=False)
    return result


def _ray_from_event(context, event, offset_x=0, offset_y=0):
    region, rv3d, x, y = _safe_region_event(context, event)
    if region is None or rv3d is None:
        return None, None, None
    try:
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
        sx = max(0, min(int(x + offset_x), max(0, width - 1)))
        sy = max(0, min(int(y + offset_y), max(0, height - 1)))
        coord = (sx, sy)
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        if view_vector is None or ray_origin is None:
            return None, None, None
        return region, ray_origin, view_vector
    except Exception:
        return None, None, None


def _raycast_scene_at_position(context, event, offset_x=0, offset_y=0, max_distance=10000.0):
    _region, ray_origin, view_vector = _ray_from_event(context, event, offset_x, offset_y)
    if ray_origin is None or view_vector is None:
        return {'hit': False}
    scene = _safe_getattr(context, 'scene', None)
    if scene is None:
        return {'hit': False}
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        return {'hit': False}
    try:
        hit, location, normal, index, obj, matrix = scene.ray_cast(
            depsgraph, ray_origin, view_vector, distance=float(max_distance)
        )
    except TypeError:
        try:
            hit, location, normal, index, obj, matrix = scene.ray_cast(
                depsgraph, ray_origin, view_vector
            )
        except Exception:
            return {'hit': False}
    except Exception:
        return {'hit': False}
    if not hit or not _rna_pointer_is_valid(obj):
        return {'hit': False}
    try:
        distance = (location - ray_origin).length
    except Exception:
        distance = float('inf')
    return {
        'hit': True,
        'object': obj,
        'location': location,
        'normal': normal,
        'face_index': index,
        'matrix': matrix,
        'distance': distance,
    }


def raycast_scene(context, event, max_distance=10000.0, *, use_radial: bool = False):
    result = _raycast_scene_at_position(context, event, 0, 0, max_distance)
    if result.get('hit') or not use_radial:
        return result
    for offset_x, offset_y in _get_radial_offsets(max_radius=12, step=6):
        result = _raycast_scene_at_position(context, event, offset_x, offset_y, max_distance)
        if result.get('hit'):
            return result
    return {'hit': False}


def raycast_active_object(context, event):
    obj = _safe_active_object(context)
    if obj is None or _safe_getattr(obj, 'type', None) != 'MESH':
        return {'hit': False}
    _region, ray_origin, view_vector = _ray_from_event(context, event, 0, 0)
    if ray_origin is None or view_vector is None:
        return {'hit': False}
    try:
        depsgraph = context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        matrix_world = obj.matrix_world.copy()
        matrix_inv = matrix_world.inverted()
    except Exception:
        return {'hit': False}
    try:
        ray_origin_local = matrix_inv @ ray_origin
        ray_dir_local = (matrix_inv.to_3x3() @ view_vector).normalized()
    except Exception:
        return {'hit': False}
    try:
        hit, location, normal, face_index = obj_eval.ray_cast(ray_origin_local, ray_dir_local)
    except Exception:
        return {'hit': False}
    if not hit:
        return {'hit': False}
    try:
        world_loc = matrix_world @ location
        world_normal = (matrix_world.to_3x3() @ normal).normalized()
        distance = (world_loc - ray_origin).length
    except Exception:
        return {'hit': False}
    return {
        'hit': True,
        'object': obj,
        'location': world_loc,
        'normal': world_normal,
        'face_index': face_index,
        'distance': distance,
    }


def check_gizmo_hover(context, event, gizmo_radius=80):
    space = _safe_getattr(context, 'space_data', None)
    if space is None or not _safe_getattr(space, 'show_gizmo', False):
        return False
    if not any((
        _safe_getattr(space, 'show_gizmo_object_translate', False),
        _safe_getattr(space, 'show_gizmo_object_rotate', False),
        _safe_getattr(space, 'show_gizmo_object_scale', False),
    )):
        return False
    obj = _safe_active_object(context)
    if obj is None:
        return False
    region, rv3d, x, y = _safe_region_event(context, event)
    if region is None or rv3d is None:
        return False
    try:
        origin = obj.matrix_world.translation
        origin_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, origin)
        if origin_2d is None:
            return False
        return (Vector((x, y)) - origin_2d).length < max(0, float(gizmo_radius or 0))
    except Exception:
        return False


def is_valid_hit_object(obj, prefs=None, context=None):
    if not _rna_pointer_is_valid(obj):
        return False
    try:
        if obj.hide_get() or obj.hide_select:
            return False
    except Exception:
        return False
    if context is not None:
        space = _safe_getattr(context, 'space_data', None)
        try:
            if space is not None and hasattr(space, 'local_view') and space.local_view:
                if not obj.local_view_get(space):
                    return False
        except Exception:
            return False
    return True


_NON_RAYCASTABLE_TYPES = {'EMPTY', 'LIGHT', 'CAMERA', 'SPEAKER', 'LIGHT_PROBE', 'ARMATURE', 'LATTICE', 'GPENCIL', 'GREASEPENCIL'}
_MODE_TO_IGNORE_PREFIX = {
    'OBJECT': 'object', 'EDIT_MESH': 'edit', 'EDIT_CURVE': 'edit', 'EDIT_SURFACE': 'edit',
    'EDIT_TEXT': 'edit', 'EDIT_ARMATURE': 'edit', 'EDIT_METABALL': 'edit', 'EDIT_LATTICE': 'edit',
    'EDIT_GPENCIL': 'edit', 'SCULPT': 'sculpt', 'PAINT_VERTEX': 'vertex_paint',
    'PAINT_WEIGHT': 'weight_paint', 'PAINT_TEXTURE': 'texture_paint', 'POSE': 'pose',
}
_IGNORE_TYPE_SUFFIXES = {
    'EMPTY': 'empty', 'LIGHT': 'light', 'CAMERA': 'camera', 'SPEAKER': 'speaker',
    'LIGHT_PROBE': 'light_probe', 'ARMATURE': 'armature', 'LATTICE': 'lattice',
    'GPENCIL': 'grease_pencil', 'GREASEPENCIL': 'grease_pencil',
}


def _get_ignored_types(prefs, mode='OBJECT'):
    if prefs is None:
        return set()
    prefix = _MODE_TO_IGNORE_PREFIX.get(str(mode or 'OBJECT'), 'object')
    ignored = set()
    for obj_type, suffix in _IGNORE_TYPE_SUFFIXES.items():
        try:
            if getattr(prefs, f'ignore_{prefix}_{suffix}', False):
                ignored.add(obj_type)
        except Exception:
            pass
    return ignored


def _get_ignored_collection_objects(context):
    scene = _safe_getattr(context, 'scene', None)
    if scene is None or not hasattr(scene, 'sculptnav_ignored_collections'):
        return set()
    ignored = set()
    try:
        for item in scene.sculptnav_ignored_collections:
            collection = _safe_getattr(item, 'collection', None)
            if collection:
                for obj in collection.all_objects:
                    if _rna_pointer_is_valid(obj):
                        ignored.add(obj.name)
    except Exception:
        pass
    return ignored


def check_non_mesh_object_at_cursor(context, event, click_radius=50, ignored_types=None, ignored_objects=None):
    region, rv3d, x, y = _safe_region_event(context, event)
    if region is None or rv3d is None:
        return {'hit': False, 'distance': -1}
    cursor = Vector((x, y))
    closest_distance = float('inf')
    found_hit = False
    visible = _safe_visible_objects(context)
    # Avoid O(N) viewport-navigation stalls in very large scenes.  Non-mesh
    # screen-proximity blocking is a convenience fallback only; mesh/object ray
    # casts above remain the primary hit test.
    if len(visible) > 256:
        return {'hit': False, 'distance': -1}
    for obj in visible:
        obj_type = _safe_getattr(obj, 'type', None)
        obj_name = _safe_getattr(obj, 'name', '')
        if obj_type not in _NON_RAYCASTABLE_TYPES:
            continue
        if ignored_types and obj_type in ignored_types:
            continue
        if ignored_objects and obj_name in ignored_objects:
            continue
        if not is_valid_hit_object(obj, None, context):
            continue
        try:
            screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world.translation)
            if screen_pos is None:
                continue
            screen_distance = (cursor - screen_pos).length
            if screen_distance < float(click_radius or 0) and screen_distance < closest_distance:
                closest_distance = screen_distance
                found_hit = True
        except Exception:
            continue
    return {'hit': found_hit, 'distance': closest_distance if found_hit else -1}


def _check_depth_offscreen(context, event, search_radius=5, ignored_types=None, ignored_objects=None):
    """Disabled for Blender 5.1 stability; retained for API compatibility."""
    return False


def hit_test_context(context, event, border_width=75, border_height=75, prefs=None):
    result = HitTestResult()
    area = _safe_getattr(context, 'area', None)
    region, _rv3d, x, y = _safe_region_event(context, event)
    if area is None or _safe_getattr(area, 'type', None) != 'VIEW_3D' or region is None:
        result.hit_type = 'UI'
        return result

    result.in_border_zone = bool(check_border_zone(context, event, border_width, border_height).get('in_zone'))
    try:
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
    except Exception:
        result.hit_type = 'UI'
        return result
    if not (0 <= x <= width and 0 <= y <= height):
        result.hit_type = 'UI'
        return result

    if not result.in_border_zone and check_gizmo_hover(context, event):
        result.hit_type = 'GIZMO'
        return result

    mode = str(_safe_getattr(context, 'mode', '') or '')
    ignored_types = _get_ignored_types(prefs, mode)
    ignored_objects = _get_ignored_collection_objects(context)

    if is_paint_mode(context):
        raycast_result = raycast_active_object(context, event)
    else:
        use_radial = bool(getattr(prefs, 'navigation_precise_hit_sampling', False)) if prefs is not None else False
        raycast_result = raycast_scene(context, event, use_radial=use_radial)

    if raycast_result.get('hit'):
        hit_obj = raycast_result.get('object')
        hit_name = _safe_getattr(hit_obj, 'name', '')
        hit_type = _safe_getattr(hit_obj, 'type', None)
        if hit_type in ignored_types or hit_name in ignored_objects or not is_valid_hit_object(hit_obj, prefs, context):
            result.hit_type = 'EMPTY'
            return result
        result.hit_type = 'MESH'
        result.hit_object = hit_obj
        result.hit_location = raycast_result.get('location')
        result.hit_normal = raycast_result.get('normal')
        result.hit_face_index = int(raycast_result.get('face_index', -1) or -1)
        try:
            result.distance = float(raycast_result.get('distance', float('inf')))
        except Exception:
            result.distance = float('inf')
        return result

    non_mesh = check_non_mesh_object_at_cursor(context, event, 50, ignored_types, ignored_objects)
    result.hit_type = 'MESH' if non_mesh.get('hit') else 'EMPTY'
    return result


def is_paint_mode(context):
    return str(_safe_getattr(context, 'mode', '') or '') in {'SCULPT', 'PAINT_VERTEX', 'PAINT_WEIGHT', 'PAINT_TEXTURE'}


def is_navigation_enabled(context, prefs=None):
    if prefs is None:
        try:
            from ..properties import get_addon_preferences
            prefs = get_addon_preferences(context)
        except Exception:
            prefs = None
    if prefs is None:
        return False
    mode = str(_safe_getattr(context, 'mode', '') or 'OBJECT')
    mode_settings = {
        'OBJECT': 'nav_mode_object',
        'EDIT_MESH': 'nav_mode_edit',
        'EDIT_CURVE': 'nav_mode_edit',
        'EDIT_SURFACE': 'nav_mode_edit',
        'EDIT_TEXT': 'nav_mode_edit',
        'EDIT_ARMATURE': 'nav_mode_edit',
        'EDIT_METABALL': 'nav_mode_edit',
        'EDIT_LATTICE': 'nav_mode_edit',
        'EDIT_GPENCIL': 'nav_mode_edit',
        'SCULPT': 'nav_mode_sculpt',
        'PAINT_VERTEX': 'nav_mode_vertex_paint',
        'PAINT_WEIGHT': 'nav_mode_weight_paint',
        'PAINT_TEXTURE': 'nav_mode_texture_paint',
        'POSE': 'nav_mode_pose',
    }
    pref_name = mode_settings.get(mode)
    if pref_name:
        try:
            return bool(getattr(prefs, pref_name, True))
        except Exception:
            return False
    return True


def get_active_brush(context):
    tool_settings = _safe_getattr(context, 'tool_settings', None)
    if tool_settings is None:
        return None
    mode = str(_safe_getattr(context, 'mode', '') or '')
    try:
        if mode == 'SCULPT':
            sculpt = _safe_getattr(tool_settings, 'sculpt', None)
            return _safe_getattr(sculpt, 'brush', None) if sculpt else None
        if mode == 'PAINT_VERTEX':
            vp = _safe_getattr(tool_settings, 'vertex_paint', None)
            return _safe_getattr(vp, 'brush', None) if vp else None
        if mode == 'PAINT_WEIGHT':
            wp = _safe_getattr(tool_settings, 'weight_paint', None)
            return _safe_getattr(wp, 'brush', None) if wp else None
        if mode == 'PAINT_TEXTURE':
            ip = _safe_getattr(tool_settings, 'image_paint', None)
            return _safe_getattr(ip, 'brush', None) if ip else None
    except Exception:
        return None
    return None
