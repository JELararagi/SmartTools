from ..core import utils as _smart_utils
import sys
from .. import rna_safety as _rna_safety
from .. import _sss_lifecycle as _lifecycle
import bpy
from bpy.props import BoolProperty, IntProperty, FloatProperty, FloatVectorProperty, EnumProperty, PointerProperty, CollectionProperty

try:
    import rna_keymap_ui as _rna_keymap_ui
except Exception:
    _rna_keymap_ui = None

# Exact module references captured only after this generation registers.
# Unregister never imports a replacement package while retiring an old live generation.
_PERSISTENT_SETTINGS_MODULE = None
_PERSISTENT_CONTROLS_MODULE = None

def _request_navigation_settings_save(context=None) -> None:
    try:
        from ..core import settings as _persistent_settings
        _persistent_settings.request_immediate_save(getattr(context or bpy.context, 'scene', None), context=context or bpy.context, force=False)
    except Exception:
        pass

def _ignored_collection_update(self, context) -> None:
    _request_navigation_settings_save(context)

def _find_addon_preferences(context=None):
    return _root_tool_preferences(context)

def _root_tool_preferences(context=None):
    """Read already-loaded root preferences without import or draw-time mutation."""
    try:
        package_name = str(__package__ or __name__ or '').strip()
        root_name = package_name.rsplit('.navigation', 1)[0] if '.navigation' in package_name else package_name.rsplit('.', 1)[0]
        if not root_name:
            return None
        prefs_module = sys.modules.get(f'{root_name}.preferences')
        find_fn = getattr(prefs_module, 'find_tool_settings', None) if prefs_module is not None else None
        if callable(find_fn):
            return find_fn('navigation', context=context)
    except Exception:
        pass
    return None

class SCULPTNAV_WindowManagerProperties(bpy.types.PropertyGroup):
    """Per-session properties stored on WindowManager (not persistent across restarts)."""
    enabled: BoolProperty(name='Enable SculptNavigation', description='Enable SculptNavigation navigation system', default=False, update=lambda self, context: _request_navigation_settings_save(context))

class SCULPTNAV_AddonPreferences(bpy.types.PropertyGroup):
    """N-panel settings schema that persists through root Preferences storage."""
    bl_idname = __package__
    canvas_navigation_enabled: BoolProperty(name='Enable Canvas Navigation', description='ZBrush-style: Left-click on empty space orbits the view (like MMB). Left-click on mesh sculpts normally', default=True)
    canvas_rmb_enabled: BoolProperty(name='Enable RMB Navigation', description='RMB drag: vertical = dolly, horizontal = roll. RMB on mesh = brush adjust. RMB click = context menu', default=True)
    lmb_orbit_enabled: BoolProperty(name='Orbit', description='Enable orbit gesture (LMB on empty space)', default=True)
    lmb_pan_enabled: BoolProperty(name='Pan', description='Enable pan gesture (Shift+LMB)', default=True)
    lmb_zoom_enabled: BoolProperty(name='Zoom', description='Enable zoom gesture (Ctrl+LMB)', default=True)
    rmb_empty_horizontal: EnumProperty(name='Horizontal', description='Action for horizontal RMB drag on empty space', items=[('ROLL', 'Roll', 'Rotate the viewport around the view axis'), ('DOLLY', 'Dolly', 'Move the camera closer or further'), ('PAN', 'Pan', 'Pan the viewport horizontally'), ('ZOOM', 'Zoom', 'Zoom the viewport'), ('NONE', 'None', 'No action on this axis')], default='ROLL')
    rmb_empty_vertical: EnumProperty(name='Vertical', description='Action for vertical RMB drag on empty space', items=[('DOLLY', 'Dolly', 'Move the camera closer or further'), ('ROLL', 'Roll', 'Rotate the viewport around the view axis'), ('PAN', 'Pan', 'Pan the viewport vertically'), ('ZOOM', 'Zoom', 'Zoom the viewport'), ('NONE', 'None', 'No action on this axis')], default='DOLLY')
    rmb_mesh_horizontal: EnumProperty(name='Horizontal', description='Action for horizontal RMB drag on mesh', items=[('BRUSH_SIZE', 'Brush Size', 'Adjust the active brush size'), ('BRUSH_STRENGTH', 'Brush Strength', 'Adjust the active brush strength'), ('ROLL', 'Roll', 'Rotate the viewport around the view axis'), ('DOLLY', 'Dolly', 'Move the camera closer or further'), ('PAN', 'Pan', 'Pan the viewport horizontally'), ('NONE', 'None', 'No action on this axis')], default='BRUSH_SIZE')
    rmb_mesh_vertical: EnumProperty(name='Vertical', description='Action for vertical RMB drag on mesh', items=[('BRUSH_STRENGTH', 'Brush Strength', 'Adjust the active brush strength'), ('BRUSH_SIZE', 'Brush Size', 'Adjust the active brush size'), ('ROLL', 'Roll', 'Rotate the viewport around the view axis'), ('DOLLY', 'Dolly', 'Move the camera closer or further'), ('PAN', 'Pan', 'Pan the viewport vertically'), ('NONE', 'None', 'No action on this axis')], default='BRUSH_STRENGTH')
    rmb_empty_direction_lock: BoolProperty(name='Direction Lock (Empty)', description='Lock to one axis on drag start when on empty space. When off, both axes apply simultaneously', default=True)
    rmb_mesh_direction_lock: BoolProperty(name='Direction Lock (Mesh)', description='Lock to one axis on drag start when on mesh. When off, both axes apply simultaneously', default=False)
    rmb_zoom_enabled: BoolProperty(name='Zoom', description='Enable zoom gesture (Shift+RMB)', default=True)
    nav_mode_object: BoolProperty(name='Object Mode', description='Enable canvas navigation in Object Mode', default=True)
    nav_mode_edit: BoolProperty(name='Edit Mode', description='Enable canvas navigation in Edit Mode', default=True)
    nav_mode_sculpt: BoolProperty(name='Sculpt Mode', description='Enable canvas navigation in Sculpt Mode', default=True)
    nav_mode_vertex_paint: BoolProperty(name='Vertex Paint', description='Enable canvas navigation in Vertex Paint Mode', default=True)
    nav_mode_weight_paint: BoolProperty(name='Weight Paint', description='Enable canvas navigation in Weight Paint Mode', default=True)
    nav_mode_texture_paint: BoolProperty(name='Texture Paint', description='Enable canvas navigation in Texture Paint Mode', default=True)
    nav_mode_pose: BoolProperty(name='Pose Mode', description='Enable canvas navigation in Pose Mode', default=True)
    double_click_focus_enabled: BoolProperty(name='Enable Double-click Focus', description='Double-click on empty space to focus on selected objects (like Numpad .)', default=True)
    double_click_threshold: IntProperty(name='Double-click Speed', description='Maximum time between clicks to register as double-click (milliseconds)', default=300, min=100, max=800, subtype='TIME_ABSOLUTE')
    double_click_outside_border_only: BoolProperty(name='Border Zone Only', description='Double-click focus only works inside the border zone (empty canvas navigates without focus)', default=False)
    double_click_select_and_focus: BoolProperty(name='Click Object to Select & Focus', description='Double-click on an object to select it and focus on it', default=True)
    focus_ignore_mirror: BoolProperty(name='Ignore Mirror Modifiers', description='Focus on original geometry only, ignoring mirrored copies', default=True)
    focus_ignore_array: BoolProperty(name='Ignore Array Modifiers', description='Focus on original geometry only, ignoring array copies', default=True)
    focus_ignore_solidify: BoolProperty(name='Ignore Solidify Modifiers', description='Focus on original geometry only, ignoring solidify thickness', default=False)
    focus_show_hud: BoolProperty(name='Show Focus HUD', description='Show popup with modifier ignore toggles after focusing', default=True)
    focus_hud_position: EnumProperty(name='HUD Position', description='Where to display the focus HUD popup', items=[('CURSOR', 'At Cursor', 'Show popup at mouse cursor position'), ('BOTTOM_LEFT', 'Bottom Left', 'Show panel at bottom-left corner'), ('BOTTOM_RIGHT', 'Bottom Right', 'Show panel at bottom-right corner'), ('TOP_LEFT', 'Top Left', 'Show panel at top-left corner'), ('TOP_RIGHT', 'Top Right', 'Show panel at top-right corner')], default='CURSOR')
    focus_hud_offset_x: IntProperty(name='Offset X', description='Horizontal offset from the selected corner (pixels)', default=0, min=-500, max=500, subtype='PIXEL')
    focus_hud_offset_y: IntProperty(name='Offset Y', description='Vertical offset from the selected corner (pixels)', default=0, min=-500, max=500, subtype='PIXEL')
    border_width: IntProperty(name='Border Width', description='Horizontal border zone size (left/right edges) in pixels', default=75, min=10, max=300, subtype='PIXEL')
    border_height: IntProperty(name='Border Height', description='Vertical border zone size (top/bottom edges) in pixels', default=75, min=10, max=300, subtype='PIXEL')
    show_border_overlay: BoolProperty(name='Show Border Overlay', description='Display visual line indicator for navigation border zone', default=True)
    border_color: FloatVectorProperty(name='Border Color', description='Color of border overlay line', subtype='COLOR', size=4, default=(0.682, 0.682, 0.682, 0.6), min=0.0, max=1.0)
    border_line_width: FloatProperty(name='Line Width', description='Width of the border indicator line in pixels', default=1.5, min=1.0, max=5.0, step=10)
    orbit_origin: EnumProperty(name='Orbit Origin', description='What point to orbit around when navigating', items=[('BLENDER', 'Blender Default', "Use Blender's native orbit behavior (Preferences > Navigation)"), ('SURFACE', 'Surface Point', 'Orbit around the surface point under cursor (raycast on click)'), ('ACTIVE', 'Active Object', "Orbit around the active object's origin"), ('SELECTION', 'Selection Center', 'Orbit around the center of selected objects'), ('CURSOR', '3D Cursor', 'Orbit around the 3D cursor position')], default='BLENDER')
    orbit_sensitivity: FloatProperty(name='Orbit Sensitivity', description='Mouse sensitivity for orbit navigation', default=1.0, min=0.1, max=5.0, step=10)
    orbit_invert_x: BoolProperty(name='Invert Orbit X', description='Invert horizontal orbit direction', default=False)
    orbit_invert_y: BoolProperty(name='Invert Orbit Y', description='Invert vertical orbit direction', default=False)
    dolly_sensitivity: FloatProperty(name='Dolly Sensitivity', description='Mouse sensitivity for dolly zoom', default=1.0, min=0.1, max=5.0, step=10)
    dolly_invert: BoolProperty(name='Invert Dolly', description='Invert dolly zoom direction', default=False)
    pan_sensitivity: FloatProperty(name='Pan Sensitivity', description='Mouse sensitivity for viewport pan', default=1.0, min=0.1, max=5.0, step=10)
    pan_invert_x: BoolProperty(name='Invert Pan X', description='Invert horizontal pan direction', default=False)
    pan_invert_y: BoolProperty(name='Invert Pan Y', description='Invert vertical pan direction', default=False)
    zoom_sensitivity: FloatProperty(name='Zoom Sensitivity', description='Mouse sensitivity for zoom', default=1.0, min=0.1, max=5.0, step=10)
    zoom_invert: BoolProperty(name='Invert Zoom', description='Invert zoom direction', default=False)
    roll_sensitivity: FloatProperty(name='Roll Sensitivity', description='Sensitivity for view roll (horizontal RMB drag)', default=0.3, min=0.01, max=2.0, step=1)
    roll_invert: BoolProperty(name='Invert Roll', description='Invert roll direction', default=False)
    roll_axis: EnumProperty(name='Roll Axis', description='Axis to roll around', items=[('WORLD_Z', 'World Z', 'Roll around the world Z axis (turntable-style)'), ('VIEW', 'View (Screen Z)', 'Roll around the view direction (barrel roll / head tilt)'), ('WORLD_X', 'World X', 'Roll around the world X axis'), ('WORLD_Y', 'World Y', 'Roll around the world Y axis')], default='WORLD_Z')
    brush_size_sensitivity: FloatProperty(name='Brush Size Sensitivity', description='Pixels of mouse movement per brush size unit', default=2.0, min=0.5, max=10.0, step=10)
    brush_strength_sensitivity: FloatProperty(name='Brush Strength Sensitivity', description='Pixels of mouse movement for full strength range (0 to 1)', default=200.0, min=50.0, max=500.0)
    brush_invert_size: BoolProperty(name='Invert Size Direction', description='Invert horizontal direction for brush size adjustment', default=False)
    brush_invert_strength: BoolProperty(name='Invert Strength Direction', description='Invert vertical direction for brush strength adjustment', default=False)
    brush_show_visual_ring: BoolProperty(name='Show Visual Ring', description='Show a visual ring preview during brush size adjustment', default=True)
    brush_ring_color: FloatVectorProperty(name='Ring Color', description='Color of the brush size preview ring', subtype='COLOR', size=4, default=(1.0, 1.0, 1.0, 0.6), min=0.0, max=1.0)
    brush_strength_color: FloatVectorProperty(name='Strength Color', description='Color of the brush strength arc indicator', subtype='COLOR', size=4, default=(0.2, 0.6, 1.0, 0.4), min=0.0, max=1.0)
    brush_text_margin: IntProperty(name='Text Margin', description='Vertical offset (in pixels) for brush info text above the cursor', default=50, min=10, max=200, subtype='PIXEL')
    brush_falloff_curve: EnumProperty(name='Falloff Curve', description='Falloff curve shape to display in brush ring', items=[('FROM_BRUSH', 'From Brush (Auto)', "Sample the brush's actual falloff curve dynamically"), ('SMOOTH', 'Smooth', 'Smooth S-curve falloff'), ('SPHERE', 'Sphere', 'Spherical/hemisphere falloff'), ('ROOT', 'Root', 'Square root falloff - stays strong longer'), ('SHARP', 'Sharp', 'Sharp falloff - drops quickly'), ('LIN', 'Linear', 'Linear/triangle falloff'), ('POW4', 'Sharper', 'Very sharp falloff (power of 4)'), ('INVSQUARE', 'Inverse Square', 'Inverse square falloff'), ('CONSTANT', 'Constant', 'No falloff - flat')], default='FROM_BRUSH')
    brush_ring_scale: FloatProperty(name='Ring Scale', description="Scale factor for the visual ring to match Blender's brush cursor (0.5 = matches default cursor)", default=0.5, min=0.1, max=2.0, step=1, precision=2)
    ignore_types_mode: EnumProperty(name='Mode', description="Select which mode's ignore settings to view", items=[('OBJECT', 'Object', 'Object Mode ignore settings'), ('EDIT', 'Edit', 'Edit Mode ignore settings'), ('SCULPT', 'Sculpt', 'Sculpt Mode ignore settings'), ('VERTEX_PAINT', 'Vertex Paint', 'Vertex Paint Mode ignore settings'), ('WEIGHT_PAINT', 'Weight Paint', 'Weight Paint Mode ignore settings'), ('TEXTURE_PAINT', 'Texture Paint', 'Texture Paint Mode ignore settings'), ('POSE', 'Pose', 'Pose Mode ignore settings')], default='OBJECT')
    ignore_object_empty: BoolProperty(name='Empties', default=False)
    ignore_object_light: BoolProperty(name='Lights', default=False)
    ignore_object_camera: BoolProperty(name='Cameras', default=False)
    ignore_object_speaker: BoolProperty(name='Speakers', default=False)
    ignore_object_light_probe: BoolProperty(name='Light Probes', default=False)
    ignore_object_armature: BoolProperty(name='Armatures', default=False)
    ignore_object_lattice: BoolProperty(name='Lattices', default=False)
    ignore_object_grease_pencil: BoolProperty(name='Grease Pencil', default=False)
    ignore_edit_empty: BoolProperty(name='Empties', default=False)
    ignore_edit_light: BoolProperty(name='Lights', default=False)
    ignore_edit_camera: BoolProperty(name='Cameras', default=False)
    ignore_edit_speaker: BoolProperty(name='Speakers', default=False)
    ignore_edit_light_probe: BoolProperty(name='Light Probes', default=False)
    ignore_edit_armature: BoolProperty(name='Armatures', default=False)
    ignore_edit_lattice: BoolProperty(name='Lattices', default=False)
    ignore_edit_grease_pencil: BoolProperty(name='Grease Pencil', default=False)
    ignore_sculpt_empty: BoolProperty(name='Empties', default=True)
    ignore_sculpt_light: BoolProperty(name='Lights', default=True)
    ignore_sculpt_camera: BoolProperty(name='Cameras', default=True)
    ignore_sculpt_speaker: BoolProperty(name='Speakers', default=True)
    ignore_sculpt_light_probe: BoolProperty(name='Light Probes', default=True)
    ignore_sculpt_armature: BoolProperty(name='Armatures', default=True)
    ignore_sculpt_lattice: BoolProperty(name='Lattices', default=True)
    ignore_sculpt_grease_pencil: BoolProperty(name='Grease Pencil', default=True)
    ignore_vertex_paint_empty: BoolProperty(name='Empties', default=True)
    ignore_vertex_paint_light: BoolProperty(name='Lights', default=True)
    ignore_vertex_paint_camera: BoolProperty(name='Cameras', default=True)
    ignore_vertex_paint_speaker: BoolProperty(name='Speakers', default=True)
    ignore_vertex_paint_light_probe: BoolProperty(name='Light Probes', default=True)
    ignore_vertex_paint_armature: BoolProperty(name='Armatures', default=True)
    ignore_vertex_paint_lattice: BoolProperty(name='Lattices', default=True)
    ignore_vertex_paint_grease_pencil: BoolProperty(name='Grease Pencil', default=True)
    ignore_weight_paint_empty: BoolProperty(name='Empties', default=True)
    ignore_weight_paint_light: BoolProperty(name='Lights', default=True)
    ignore_weight_paint_camera: BoolProperty(name='Cameras', default=True)
    ignore_weight_paint_speaker: BoolProperty(name='Speakers', default=True)
    ignore_weight_paint_light_probe: BoolProperty(name='Light Probes', default=True)
    ignore_weight_paint_armature: BoolProperty(name='Armatures', default=True)
    ignore_weight_paint_lattice: BoolProperty(name='Lattices', default=True)
    ignore_weight_paint_grease_pencil: BoolProperty(name='Grease Pencil', default=True)
    ignore_texture_paint_empty: BoolProperty(name='Empties', default=True)
    ignore_texture_paint_light: BoolProperty(name='Lights', default=True)
    ignore_texture_paint_camera: BoolProperty(name='Cameras', default=True)
    ignore_texture_paint_speaker: BoolProperty(name='Speakers', default=True)
    ignore_texture_paint_light_probe: BoolProperty(name='Light Probes', default=True)
    ignore_texture_paint_armature: BoolProperty(name='Armatures', default=True)
    ignore_texture_paint_lattice: BoolProperty(name='Lattices', default=True)
    ignore_texture_paint_grease_pencil: BoolProperty(name='Grease Pencil', default=True)
    ignore_pose_empty: BoolProperty(name='Empties', default=True)
    ignore_pose_light: BoolProperty(name='Lights', default=True)
    ignore_pose_camera: BoolProperty(name='Cameras', default=True)
    ignore_pose_speaker: BoolProperty(name='Speakers', default=True)
    ignore_pose_light_probe: BoolProperty(name='Light Probes', default=True)
    ignore_pose_armature: BoolProperty(name='Armatures', default=True)
    ignore_pose_lattice: BoolProperty(name='Lattices', default=True)
    ignore_pose_grease_pencil: BoolProperty(name='Grease Pencil', default=True)
    drag_threshold: IntProperty(name='Drag Threshold', description='Pixels of movement before input is considered a drag (vs a click)', default=4, min=1, max=20, subtype='PIXEL')
    tablet_drag_threshold: IntProperty(name='Tablet Drag Threshold', description='Drag threshold for tablet/pen input (higher helps prevent accidental drags)', default=8, min=2, max=30, subtype='PIXEL')

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text='Canvas Navigation (3D Coat-style)', icon='VIEW_PAN')
        col = box.column(align=True)
        col.prop(self, 'canvas_navigation_enabled')
        col.prop(self, 'canvas_rmb_enabled')
        col.separator()
        col.label(text='Keybindings:', icon='KEYINGSET')
        wm = context.window_manager
        kc = wm.keyconfigs.user
        if kc and _rna_keymap_ui is not None:
            km = kc.keymaps.get('Sculpt')
            if km:
                for kmi in km.keymap_items:
                    if kmi.idname == 'sculptnav.canvas_navigation':
                        _rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
                        break
                for kmi in km.keymap_items:
                    if kmi.idname == 'sculptnav.canvas_pan':
                        _rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
                        break
                for kmi in km.keymap_items:
                    if kmi.idname == 'sculptnav.canvas_rmb_navigation':
                        _rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
                        break
                for kmi in km.keymap_items:
                    if kmi.idname == 'sculptnav.canvas_rmb_zoom':
                        _rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
                        break
            else:
                col.label(text='Keymap not found', icon='NONE')
        else:
            col.label(text='Keymap not available', icon='NONE')
        col.separator()
        col.label(text='Edit in: Preferences > Keymap > Sculpt', icon='NONE')
        box = layout.box()
        box.label(text='LMB Gesture Controls', icon='MOUSE_LMB')
        col = box.column(align=True)
        if self.canvas_navigation_enabled:
            row = col.row(align=True)
            row.prop(self, 'lmb_orbit_enabled', toggle=True)
            row.prop(self, 'lmb_pan_enabled', toggle=True)
            row.prop(self, 'lmb_zoom_enabled', toggle=True)
            col.separator()
            col.label(text='LMB = Orbit | Shift+LMB = Pan | Ctrl+LMB = Tool', icon='NONE')
        else:
            col.label(text='Enable Canvas Navigation to configure', icon='NONE')
        box = layout.box()
        box.label(text='RMB Gesture Controls', icon='MOUSE_RMB')
        col = box.column(align=True)
        if self.canvas_rmb_enabled:
            col.label(text='Empty Space Gestures:')
            row = col.row(align=True)
            row.prop(self, 'rmb_empty_horizontal')
            row.prop(self, 'rmb_empty_vertical')
            col.prop(self, 'rmb_empty_direction_lock', toggle=True)
            col.separator()
            col.label(text='On Mesh Gestures:')
            row = col.row(align=True)
            row.prop(self, 'rmb_mesh_horizontal')
            row.prop(self, 'rmb_mesh_vertical')
            col.prop(self, 'rmb_mesh_direction_lock', toggle=True)
            col.separator()
            row = col.row(align=True)
            row.prop(self, 'rmb_zoom_enabled', toggle=True, text='Shift+RMB = Zoom')
            col.separator()
            col.label(text='RMB click = Context Menu', icon='NONE')
        else:
            col.label(text='Enable RMB Navigation to configure', icon='NONE')
        box = layout.box()
        box.label(text='Enabled Modes', icon='OUTLINER_OB_MESH')
        col = box.column(align=True)
        col.label(text='Navigation active in these modes:')
        row = col.row(align=True)
        row.prop(self, 'nav_mode_object', toggle=True)
        row.prop(self, 'nav_mode_edit', toggle=True)
        row = col.row(align=True)
        row.prop(self, 'nav_mode_sculpt', toggle=True)
        row.prop(self, 'nav_mode_vertex_paint', toggle=True)
        row = col.row(align=True)
        row.prop(self, 'nav_mode_weight_paint', toggle=True)
        row.prop(self, 'nav_mode_texture_paint', toggle=True)
        row = col.row(align=True)
        row.prop(self, 'nav_mode_pose', toggle=True)
        box = layout.box()
        box.label(text='Ignore Object Types', icon='OBJECT_HIDDEN')
        col = box.column(align=True)
        col.label(text='Navigate through these types instead of selecting:')
        col.separator()
        col.prop(self, 'ignore_types_mode', text='Mode')
        mode_prefix = self.ignore_types_mode.lower()
        row = col.row(align=True)
        row.prop(self, f'ignore_{mode_prefix}_empty', toggle=True)
        row.prop(self, f'ignore_{mode_prefix}_light', toggle=True)
        row.prop(self, f'ignore_{mode_prefix}_camera', toggle=True)
        row.prop(self, f'ignore_{mode_prefix}_speaker', toggle=True)
        row = col.row(align=True)
        row.prop(self, f'ignore_{mode_prefix}_light_probe', toggle=True)
        row.prop(self, f'ignore_{mode_prefix}_armature', toggle=True)
        row.prop(self, f'ignore_{mode_prefix}_lattice', toggle=True)
        row.prop(self, f'ignore_{mode_prefix}_grease_pencil', toggle=True)
        box = layout.box()
        box.label(text='Double-click Focus', icon='PIVOT_CURSOR')
        col = box.column(align=True)
        col.prop(self, 'double_click_focus_enabled')
        if self.double_click_focus_enabled:
            col.prop(self, 'double_click_threshold')
            col.separator()
            col.prop(self, 'double_click_outside_border_only')
            col.prop(self, 'double_click_select_and_focus')
            col.separator()
            col.label(text='Ignore Modifiers (focus on original geometry):')
            row = col.row(align=True)
            row.prop(self, 'focus_ignore_mirror', toggle=True)
            row.prop(self, 'focus_ignore_array', toggle=True)
            row.prop(self, 'focus_ignore_solidify', toggle=True)
            col.separator()
            col.prop(self, 'focus_show_hud')
            if self.focus_show_hud:
                col.prop(self, 'focus_hud_position')
                if self.focus_hud_position != 'CURSOR':
                    row = col.row(align=True)
                    row.prop(self, 'focus_hud_offset_x')
                    row.prop(self, 'focus_hud_offset_y')
            col.separator()
            col.label(text='Double-click empty = Focus selected (Numpad .)', icon='NONE')
            if self.double_click_select_and_focus:
                col.label(text='Double-click object = Select & Focus it', icon='NONE')
        box = layout.box()
        box.label(text='Navigation Border', icon='BORDERMOVE')
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(self, 'border_width')
        row.prop(self, 'border_height')
        col.separator()
        col.prop(self, 'show_border_overlay')
        if self.show_border_overlay:
            row = col.row(align=True)
            row.prop(self, 'border_color', text='')
            row.prop(self, 'border_line_width')
        box = layout.box()
        box.label(text='Orbit', icon='ORIENTATION_GIMBAL')
        col = box.column(align=True)
        col.prop(self, 'orbit_origin')
        col.prop(self, 'orbit_sensitivity')
        row = col.row(align=True)
        row.prop(self, 'orbit_invert_x', text='Invert X')
        row.prop(self, 'orbit_invert_y', text='Invert Y')
        box = layout.box()
        box.label(text='Dolly', icon='ZOOM_IN')
        col = box.column(align=True)
        col.prop(self, 'dolly_sensitivity')
        col.prop(self, 'dolly_invert')
        box = layout.box()
        box.label(text='Pan', icon='VIEW_PAN')
        col = box.column(align=True)
        col.prop(self, 'pan_sensitivity')
        row = col.row(align=True)
        row.prop(self, 'pan_invert_x', text='Invert X')
        row.prop(self, 'pan_invert_y', text='Invert Y')
        box = layout.box()
        box.label(text='Zoom', icon='ZOOM_ALL')
        col = box.column(align=True)
        col.prop(self, 'zoom_sensitivity')
        col.prop(self, 'zoom_invert')
        box = layout.box()
        box.label(text='Roll Settings', icon='ORIENTATION_VIEW')
        col = box.column(align=True)
        col.prop(self, 'roll_axis')
        col.prop(self, 'roll_sensitivity')
        col.prop(self, 'roll_invert')
        col.separator()
        col.label(text='Roll Keybinding:')
        wm = context.window_manager
        kc = wm.keyconfigs.user
        if kc and _rna_keymap_ui is not None:
            km = kc.keymaps.get('Sculpt')
            if km:
                for kmi in km.keymap_items:
                    if kmi.idname == 'sculptnav.roll':
                        _rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
                        break
                else:
                    col.label(text='No roll keybinding set', icon='NONE')
            else:
                col.label(text='Keymap not found', icon='NONE')
        else:
            col.label(text='Keymap not available', icon='NONE')
        col.separator()
        col.label(text='Edit in: Preferences > Keymap > Sculpt', icon='NONE')
        box = layout.box()
        box.label(text='Brush Adjustment', icon='BRUSH_DATA')
        col = box.column(align=True)
        col.prop(self, 'brush_size_sensitivity')
        col.prop(self, 'brush_strength_sensitivity')
        col.separator()
        row = col.row(align=True)
        row.prop(self, 'brush_invert_size', text='Invert Size')
        row.prop(self, 'brush_invert_strength', text='Invert Strength')
        col.separator()
        col.prop(self, 'brush_show_visual_ring')
        if self.brush_show_visual_ring:
            row = col.row(align=True)
            row.prop(self, 'brush_ring_color', text='Ring')
            row.prop(self, 'brush_strength_color', text='Strength')
            col.prop(self, 'brush_falloff_curve')
            col.prop(self, 'brush_ring_scale')
        col.separator()
        col.prop(self, 'brush_text_margin')
        box = layout.box()
        box.label(text='Advanced', icon='PREFERENCES')
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(self, 'drag_threshold')
        row.prop(self, 'tablet_drag_threshold')

class SCULPTNAV_IgnoredCollectionItem(bpy.types.PropertyGroup):
    """Single entry in the ignored collections list."""
    collection: PointerProperty(name=_smart_utils.localize_bilingual_text('Collection / コレクション'), description=_smart_utils.localize_bilingual_text('Choose a collection whose objects should be ignored during SculptNavigation hit testing and empty-space navigation. / スカルプトナビゲーションのヒット判定や空きスペース移動で無視したいオブジェクトを含むコレクションを指定します。'), type=bpy.types.Collection, update=_ignored_collection_update)

class SCULPTNAV_OT_ignored_collection_add(bpy.types.Operator):
    """Add a collection to the ignore list"""
    bl_idname = 'sculptnav.ignored_collection_add'
    bl_label = 'Add Ignored Collection'
    bl_description = _smart_utils.localize_bilingual_text('Add a new slot to the ignored collection list, then choose which collection should be skipped during SculptNavigation. / 無視コレクション一覧に新しいスロットを追加し、スカルプトナビゲーションで判定対象から外したいコレクションを指定します。')
    bl_options = {'UNDO'}

    def execute(self, context):
        context.scene.sculptnav_ignored_collections.add()
        context.scene.sculptnav_ignored_collections_index = len(context.scene.sculptnav_ignored_collections) - 1
        _request_navigation_settings_save(context)
        return {'FINISHED'}

class SCULPTNAV_OT_ignored_collection_remove(bpy.types.Operator):
    """Remove the selected collection from the ignore list"""
    bl_idname = 'sculptnav.ignored_collection_remove'
    bl_label = 'Remove Ignored Collection'
    bl_description = _smart_utils.localize_bilingual_text('Remove the selected ignored collection slot from SculptNavigation. Objects in that collection will be checked normally again. / 選択中の無視コレクションスロットをスカルプトナビゲーションから削除します。そのコレクション内のオブジェクトは再び通常どおり判定されます。')
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(context.scene.sculptnav_ignored_collections) > 0

    def execute(self, context):
        idx = context.scene.sculptnav_ignored_collections_index
        context.scene.sculptnav_ignored_collections.remove(idx)
        context.scene.sculptnav_ignored_collections_index = max(0, idx - 1)
        _request_navigation_settings_save(context)
        return {'FINISHED'}

def get_addon_preferences(context=None):
    """Get add-on preferences from context or bpy.context."""
    prefs = _find_addon_preferences(context)
    if prefs is not None:
        return prefs
    raise KeyError(f'Addon preferences were not found for {__package__}')

def get_wm_props(context=None):
    """Get window manager properties from context or bpy.context."""
    if context is None:
        context = bpy.context
    return context.window_manager.sculptnav
classes = (SCULPTNAV_IgnoredCollectionItem, SCULPTNAV_WindowManagerProperties, SCULPTNAV_OT_ignored_collection_add, SCULPTNAV_OT_ignored_collection_remove)

def _safe_register_class(cls):
    _rna_safety.register_class(cls)

def _safe_unregister_class(cls):
    _rna_safety.unregister_class(cls)

def _delete_type_property(owner, name: str) -> None:
    if owner is not None:
        _rna_safety.unregister_property(owner, str(name or ''))

def register():
    global _PERSISTENT_SETTINGS_MODULE, _PERSISTENT_CONTROLS_MODULE
    try:
        _smart_utils.normalize_class_texts(classes)
        _smart_utils.register_runtime_translations()
    except Exception:
        pass
    for cls in classes:
        _safe_register_class(cls)
    _rna_safety.register_property(bpy.types.WindowManager, 'sculptnav', PointerProperty(type=SCULPTNAV_WindowManagerProperties))
    _rna_safety.register_property(bpy.types.Scene, 'sculptnav_ignored_collections', CollectionProperty(type=SCULPTNAV_IgnoredCollectionItem))
    _rna_safety.register_property(bpy.types.Scene, 'sculptnav_ignored_collections_index', IntProperty(name='Active Index', default=0, update=lambda self, context: _request_navigation_settings_save(context)))
    try:
        from ..core import settings as _persistent_settings
        _PERSISTENT_SETTINGS_MODULE = _persistent_settings
        _persistent_settings.apply_navigation_settings(getattr(getattr(bpy, 'context', None), 'scene', None), getattr(bpy, 'context', None))
        try:
            from ..core import controls as _persistent_controls
            _PERSISTENT_CONTROLS_MODULE = _persistent_controls
            scene = getattr(getattr(bpy, 'context', None), 'scene', None)
            core_settings = getattr(scene, 'core', None) if scene is not None else None
            sync_navigation = getattr(_persistent_controls, 'apply_navigation_preference_settings', None)
            if callable(sync_navigation):
                sync_navigation(core_settings, getattr(bpy, 'context', None), request_save=False)
        except Exception:
            _PERSISTENT_CONTROLS_MODULE = None
        _persistent_settings.refresh_dynamic_change_subscriptions(getattr(bpy, 'context', None))
    except Exception:
        _PERSISTENT_SETTINGS_MODULE = None
        _PERSISTENT_CONTROLS_MODULE = None

def unregister():
    global _PERSISTENT_SETTINGS_MODULE, _PERSISTENT_CONTROLS_MODULE
    _persistent_settings = _PERSISTENT_SETTINGS_MODULE
    if _persistent_settings is not None:
        try:
            if not _lifecycle.live_replacement_rollback_active():
                _persistent_settings.request_immediate_save(getattr(getattr(bpy, 'context', None), 'scene', None), context=getattr(bpy, 'context', None), force=True)
            _persistent_settings.clear_dynamic_change_subscriptions()
        except Exception:
            pass
    _rna_safety.unregister_property(bpy.types.Scene, 'sculptnav_ignored_collections_index')
    _rna_safety.unregister_property(bpy.types.Scene, 'sculptnav_ignored_collections')
    _rna_safety.unregister_property(bpy.types.WindowManager, 'sculptnav')
    for cls in reversed(classes):
        _safe_unregister_class(cls)
    _PERSISTENT_SETTINGS_MODULE = None
    _PERSISTENT_CONTROLS_MODULE = None
