# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

import json
import math

from bpy.props import IntProperty, StringProperty


class PopupText:
    """Collect the rows of a text-only popup before choosing the visible page."""

    def __init__(self, width=None):
        self.rows = []
        self.width = width

    def box(self):
        return self

    def row(self, *, align=False):
        return self

    def column(self, *, align=False):
        return self

    def label(self, *, text, icon='NONE'):
        if self.width is None:
            self.rows.append((text, icon))
            return
        from .core.help_content import _pixel_wrap_lines, _ui_scale

        # Reserve space for popup margins, icon columns and font rounding.
        limit = (self.width - 85) * _ui_scale()
        for index, line in enumerate(_pixel_wrap_lines(text, max_pixels=limit)):
            self.rows.append((line, icon if index == 0 else 'NONE'))

    def separator(self, *, factor=1.0):
        self.rows.append(('', None))


def _rows_per_page(context):
    # Leave space for the selector and popup chrome at the current UI scale.
    scale = context.preferences.system.ui_scale
    return max(4, min(16, int((context.window.height / scale - 140) / 24)))


def _get_page(operator):
    return min(operator.page_count, operator.get('page_number', 1))


def _set_page(operator, page):
    operator['page_number'] = max(1, min(operator.page_count, page))


def store_popup_text(operator, context, text):
    operator.page_text = json.dumps(text.rows, ensure_ascii=False)
    operator.page_size = _rows_per_page(context)
    operator.page_count = max(1, math.ceil(len(text.rows) / operator.page_size))
    operator.page = 1


def draw_popup_text(operator, layout, page_label):
    if operator.page_count > 1:
        row = layout.row(align=True)
        row.prop(operator, 'page', text=f'{page_label} (1–{operator.page_count})')
    start = (operator.page - 1) * operator.page_size
    for text, icon in json.loads(operator.page_text or '[]')[start:start + operator.page_size]:
        if icon is None:
            layout.separator(factor=0.25)
        else:
            layout.label(text=text, icon=icon)


def popup_page_property():
    return IntProperty(min=1, get=_get_page, set=_set_page, options={'SKIP_SAVE'})


def popup_text_property():
    return StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
