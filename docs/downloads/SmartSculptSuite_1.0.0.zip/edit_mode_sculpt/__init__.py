bl_info = {'name': 'Strict Edit Mode Sculpt', 'author': 'JELararagi', 'version': (1, 4, 8), 'blender': (5, 1, 0), 'location': 'View3D > Sidebar > Strict Edit Sculpt', 'description': 'Edit Mode sculpt-like mesh tools that never enter Sculpt Mode.', 'category': 'Mesh'}
import math
import os
import json
from collections import OrderedDict
import bmesh
import bpy
from bpy.app.handlers import persistent
try:
    from .. import rna_safety as _rna_safety
except Exception:
    _rna_safety = None
from .. import status_runtime as _status_runtime
from .. import _sss_lifecycle as _lifecycle
from .. import _sss_gpu_state as _gpu_state
from .. import _sss_transactions as _transactions
from .. import _sss_runtime_errors as _runtime_errors
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from bpy_extras import view3d_utils
from bpy.types import Operator, Panel, PropertyGroup, Menu
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty, PointerProperty, StringProperty

from ..popup_text import PopupText, draw_popup_text, popup_page_property, popup_text_property, store_popup_text
ADDON_ID = __name__
PANEL_CATEGORY = 'Smart Sculpt'
MASK_LAYER_NAME = 'sse_edit_mask'
FACE_SET_LAYER_NAME = 'sse_face_set'
COLOR_LAYER_NAME = 'sse_edit_color'
I18N = {'en_US': {'panel_title': '編集モード専用スカルプト', 'section_main': 'Strict Edit Mode Tools', 'section_brush': 'Brush-like Selection Tools', 'section_filter': 'Mesh Filters', 'section_mask': 'Edit Mask', 'section_faceset': 'Edit Face Sets', 'section_color': 'Edit Color', 'section_topology': 'Topology / Symmetry', 'section_native': 'Native Sculpt Compatibility', 'enabled': 'Enabled', 'strength': 'Strength', 'amount': 'Amount', 'iterations': 'Iterations', 'affect_all': 'Visible if none selected', 'use_mask': 'Use Edit Mask', 'grab_offset': 'Move Offset', 'pose_axis': 'Pose Axis', 'pose_angle': 'Pose Angle', 'face_set_id': 'Face Set ID', 'color': 'Color', 'sym_dir': 'Symmetry Direction', 'native_report': 'Show native Sculpt report', 'mode_ok': 'Edit Mode preserved.', 'mode_error': 'This tool only runs in Mesh Edit Mode.', 'no_selection': 'Select vertices, edges, or faces first, or enable the visible-vertices fallback.', 'not_enabled': 'The add-on is disabled in this panel.', 'done': 'Operation completed in Edit Mode.', 'native_intro': 'Native sculpt operators are checked in the current Edit Mode context. No mode change is performed.', 'native_blocked': 'Unavailable in Edit Mode', 'native_available': 'Available', 'native_toggle_only': 'Only the Sculpt Mode toggle can poll true here; it is intentionally not used by this add-on.', 'diagnostic_title': 'Native Sculpt Direct-Call Report', 'diagnostic_note': 'Result: standard Sculpt operators cannot be used directly in Mesh Edit Mode through the Python operator API, except the mode toggle. This add-on therefore implements Edit Mode-only replacements and diagnostics without switching modes.', 'op_draw': 'Draw', 'op_draw_sharp': 'Draw Sharp', 'op_clay': 'Clay', 'op_clay_strips': 'Clay Strips', 'op_blob': 'Blob', 'op_crease': 'Crease', 'op_smooth': 'Smooth', 'op_relax': 'Relax', 'op_flatten': 'Flatten', 'op_fill': 'Fill', 'op_scrape': 'Scrape', 'op_inflate': 'Inflate', 'op_deflate': 'Deflate', 'op_pinch': 'Pinch', 'op_grab': 'Grab', 'op_snake_hook': 'Snake Hook', 'op_elastic': 'Elastic Deform', 'op_pose': 'Pose', 'op_filter_smooth': 'Smooth Filter', 'op_filter_relax': 'Relax Filter', 'op_filter_sharpen': 'Sharpen Filter', 'op_filter_scale': 'Scale Filter', 'op_mask_set': 'Mask Selected', 'op_mask_clear': 'Clear Mask', 'op_mask_invert': 'Invert Mask', 'op_mask_smooth': 'Smooth Mask', 'op_mask_boundary': 'Mask Border', 'op_mask_cavity': 'Mask Cavity', 'op_faceset_assign': 'Assign Set', 'op_faceset_select': 'Select Set', 'op_faceset_hide': 'Hide Set', 'op_faceset_reveal': 'Reveal All', 'op_faceset_clear': 'Clear Set', 'op_color_set': 'Set Color', 'op_color_lighten': 'Lighten Color', 'op_color_darken': 'Darken Color', 'op_color_smooth': 'Smooth Color', 'op_trim_selected': 'Trim Faces', 'op_subdivide': 'Subdivide', 'op_symmetrize': 'Symmetrize', 'op_report': 'Native Sculpt Report', 'axis_x': 'X Axis', 'axis_y': 'Y Axis', 'axis_z': 'Z Axis', 'sym_neg_x': '-X to +X', 'sym_pos_x': '+X to -X', 'sym_neg_y': '-Y to +Y', 'sym_pos_y': '+Y to -Y', 'sym_neg_z': '-Z to +Z', 'sym_pos_z': '+Z to -Z', 'prop_enabled_desc': 'Turns the Edit Mode-only sculpt replacement panel on or off. Disabling it prevents the buttons from modifying the mesh while keeping the UI visible for inspection.', 'prop_strength_desc': 'Controls how strongly each operation moves selected vertices. Low values make subtle changes; high values move vertices closer to the full target in one execution.', 'prop_amount_desc': 'Sets the movement distance for normal-based and offset-based tools. For Draw, Inflate, Deflate, Grab, Snake Hook, and similar tools, this is the base displacement amount.', 'prop_iterations_desc': 'Repeats smoothing, relaxing, mask, and color filters multiple times. More iterations produce broader, softer results but can reduce sharp detail.', 'prop_affect_all_desc': 'When nothing is selected, uses every visible editable vertex as the target. Leave this off when you want to avoid accidental full-mesh edits.', 'prop_use_mask_desc': "Uses the add-on's Edit Mask layer to reduce deformation. Mask value 1 protects a vertex; value 0 allows full influence. This is an Edit Mode data layer, not Blender's native Sculpt mask.", 'prop_grab_offset_desc': 'Local-space X, Y, and Z offset used by Grab and Snake Hook. Enter small values for controlled translation of the selected area.', 'prop_pose_axis_desc': 'Axis used by the Pose tool. The selected area is rotated around its center on this local object axis.', 'prop_pose_angle_desc': 'Rotation angle in degrees used by the Pose tool. Positive and negative values rotate in opposite directions around the selected axis.', 'prop_face_set_id_desc': "Integer ID used by the add-on's Edit Face Set layer. Assign selected faces to this ID, select it again, or hide matching faces without entering Sculpt Mode.", 'prop_color_desc': 'RGBA color used by the Edit Color tools. The color is written to an Edit Mode color layer on selected faces.', 'prop_sym_dir_desc': "Direction for Edit Mode symmetrize. This calls Blender's mesh symmetrize operator, not the Sculpt symmetrize operator, and it does not enter Sculpt Mode.", 'tip_draw': 'Moves selected vertices along their averaged edit normals to build form, similar to a simple Draw brush pass. Use low Strength and Amount for gradual sculpting.', 'tip_draw_sharp': 'Adds a normal push and a small inward pinch so the selected area forms a sharper ridge or groove. Select a narrow loop or strip for best results.', 'tip_clay': 'Raises the selected surface and lightly relaxes it, imitating a clay buildup pass on the current edit selection without changing modes.', 'tip_clay_strips': 'Raises the selected area in a flatter strip-like way by combining normal displacement and plane flattening. It is useful for broad planar buildup.', 'tip_blob': 'Inflates the selected vertices away from their center and along normals to create a rounder bulge. Increase Amount for stronger volume.', 'tip_crease': 'Pulls selected vertices toward the selection center while pushing inward along normals, creating a crease-like contraction on the selection.', 'tip_smooth': 'Laplacian-smooths selected vertices using neighboring vertex positions. It reduces bumps and uneven spacing while keeping the operation in Edit Mode.', 'tip_relax': 'Moves selected vertices toward neighbor averages while removing most normal-direction shrinkage. Use this to even out topology without flattening the surface as much as Smooth.', 'tip_flatten': 'Projects selected vertices toward a best-fit plane computed from the selection center and average normal. It is the Edit Mode replacement for simple Flatten behavior.', 'tip_fill': 'Moves vertices below the selection plane upward toward the plane, helping fill depressions in the selected region.', 'tip_scrape': 'Moves vertices above the selection plane downward toward the plane, shaving high spots from the selected region.', 'tip_inflate': 'Pushes selected vertices outward along their normals. This increases volume without entering Sculpt Mode.', 'tip_deflate': 'Pulls selected vertices inward along their normals. This decreases volume or deepens the selected area.', 'tip_pinch': 'Moves selected vertices toward the selection center. It is useful for tightening forms, narrowing openings, or making ridges sharper.', 'tip_grab': 'Translates selected vertices by the Move Offset vector in object local space. This is a selection-based Edit Mode replacement for Grab.', 'tip_snake_hook': 'Moves the selected region by the Move Offset while adding a center-weighted pull, approximating a Snake Hook stretch on the edit selection.', 'tip_elastic': 'Scales selected vertices around their center with a soft elastic-style expansion or contraction. Positive Strength expands; lower Amount gives subtler motion.', 'tip_pose': 'Rotates selected vertices around their center using Pose Axis and Pose Angle. Use this for selection-based bending or posing inside Edit Mode.', 'tip_filter_smooth': 'Applies repeated smoothing over the target vertices. This is best for broad cleanup after several brush-like operations.', 'tip_filter_relax': 'Applies repeated tangent relaxation to improve vertex distribution while retaining more surface volume than normal smoothing.', 'tip_filter_sharpen': 'Moves selected vertices away from their neighbor average to enhance local contrast. Use carefully; high values can create spikes.', 'tip_filter_scale': 'Scales the selected region around its center. Strength controls the factor and Amount controls the scale range.', 'tip_mask_set': "Creates or updates the add-on's Edit Mask layer by assigning mask value 1 to selected vertices. Masked vertices are protected when Use Edit Mask is enabled.", 'tip_mask_clear': "Resets the add-on's Edit Mask values to 0 on all editable vertices. This does not affect Blender's native Sculpt mask.", 'tip_mask_invert': "Inverts the add-on's Edit Mask values so protected areas become editable and editable areas become protected.", 'tip_mask_smooth': "Blurs the add-on's Edit Mask values through connected vertices. Use it to create softer protection falloff around selected areas.", 'tip_mask_boundary': 'Sets mask value 1 on boundary vertices and open edges, which helps protect mesh borders during Edit Mode deformation.', 'tip_mask_cavity': 'Estimates surface cavity from the distance to neighboring vertex averages and writes stronger mask values to high-curvature areas.', 'tip_faceset_assign': "Stores the selected faces in the add-on's integer Edit Face Set layer using Face Set ID. This is an Edit Mode substitute, not a native Sculpt Face Set.", 'tip_faceset_select': 'Selects faces whose Edit Face Set value matches Face Set ID. Use it to quickly recall a stored face region in Edit Mode.', 'tip_faceset_hide': 'Hides faces whose Edit Face Set value matches Face Set ID. Use Reveal All to show them again.', 'tip_faceset_reveal': 'Unhides all vertices, edges, and faces in the current Edit Mesh.', 'tip_faceset_clear': "Clears the add-on's Edit Face Set values from all faces by setting them to 0.", 'tip_color_set': 'Creates or uses an Edit Mode color layer and writes the chosen Color to selected faces. This supports color-based region marking in Edit Mode.', 'tip_color_lighten': 'Raises RGB values on selected face corners in the add-on color layer. Alpha is preserved.', 'tip_color_darken': 'Lowers RGB values on selected face corners in the add-on color layer. Alpha is preserved.', 'tip_color_smooth': 'Averages color values across adjacent selected faces to soften hard color transitions in the add-on color layer.', 'tip_trim_selected': 'Deletes selected faces or selected vertices directly from the Edit Mesh. This is a selection-based replacement for simple trim workflows.', 'tip_subdivide': 'Subdivides selected edges in Edit Mode. Use this to add local resolution before applying brush-like operations.', 'tip_symmetrize': "Runs Blender's Mesh Symmetrize operator in Edit Mode using Symmetry Direction. It does not call Sculpt Mode or Sculpt symmetrize.", 'tip_report': 'Checks every native sculpt operator in the current Edit Mode context and shows whether Blender allows direct execution. The check itself never changes modes.'}, 'ja_JP': {'panel_title': '編集モード専用スカルプト', 'section_main': '編集モード専用ツール', 'section_brush': 'ブラシ風選択ツール', 'section_filter': 'メッシュフィルター', 'section_mask': '編集マスク', 'section_faceset': '編集フェイスセット', 'section_color': '編集カラー', 'section_topology': 'トポロジー・対称', 'section_native': '標準スカルプト互換性', 'enabled': '有効', 'strength': '強さ', 'amount': '量', 'iterations': '反復回数', 'affect_all': '未選択時は表示頂点を対象にする', 'use_mask': '編集マスクを使用', 'grab_offset': '移動オフセット', 'pose_axis': 'ポーズ軸', 'pose_angle': 'ポーズ角度', 'face_set_id': 'フェイスセットID', 'color': 'カラー', 'sym_dir': '対称方向', 'native_report': '標準スカルプト診断を表示', 'mode_ok': '編集モードを維持しました。', 'mode_error': 'このツールはメッシュの編集モードでのみ実行できます。', 'no_selection': '先に頂点・辺・面を選択するか、未選択時の表示頂点対象化を有効にしてください。', 'not_enabled': 'このパネルの機能が無効です。', 'done': '編集モードのまま処理を完了しました。', 'native_intro': '現在の編集モードコンテキストで標準のスカルプト機能を検査します。モード切り替えは行いません。', 'native_blocked': '編集モードでは使用不可', 'native_available': '使用可能', 'native_toggle_only': 'ここで有効になり得るのはスカルプトモード切替のみです。このアドオンでは意図的に使用しません。', 'diagnostic_title': '標準スカルプト直接呼び出し診断', 'diagnostic_note': '結果: 標準スカルプト演算子は、モード切替以外はPython演算子APIからメッシュ編集モードで直接使用できません。そのため、このアドオンはスカルプトモードへ切り替えず、編集モード専用の代替処理と診断だけを実装しています。', 'op_draw': 'Draw', 'op_draw_sharp': 'Draw Sharp', 'op_clay': 'Clay', 'op_clay_strips': 'Clay Strips', 'op_blob': 'Blob', 'op_crease': 'Crease', 'op_smooth': 'Smooth', 'op_relax': 'Relax', 'op_flatten': 'Flatten', 'op_fill': 'Fill', 'op_scrape': 'Scrape', 'op_inflate': 'Inflate', 'op_deflate': 'Deflate', 'op_pinch': 'Pinch', 'op_grab': 'Grab', 'op_snake_hook': 'Snake Hook', 'op_elastic': 'Elastic Deform', 'op_pose': 'Pose', 'op_filter_smooth': 'Smooth Filter', 'op_filter_relax': 'Relax Filter', 'op_filter_sharpen': 'Sharpen Filter', 'op_filter_scale': 'Scale Filter', 'op_mask_set': '選択をマスク', 'op_mask_clear': 'マスク解除', 'op_mask_invert': 'マスク反転', 'op_mask_smooth': 'マスクをぼかす', 'op_mask_boundary': '境界をマスク', 'op_mask_cavity': '凹凸をマスク', 'op_faceset_assign': 'セットを割当', 'op_faceset_select': 'セットを選択', 'op_faceset_hide': 'セットを隠す', 'op_faceset_reveal': '全て再表示', 'op_faceset_clear': 'セットを消去', 'op_color_set': 'カラー設定', 'op_color_lighten': 'カラーを明るく', 'op_color_darken': 'カラーを暗く', 'op_color_smooth': 'カラーをぼかす', 'op_trim_selected': '選択面をトリム', 'op_subdivide': '選択辺を細分化', 'op_symmetrize': '対称化', 'op_report': '標準スカルプト診断', 'axis_x': 'X軸', 'axis_y': 'Y軸', 'axis_z': 'Z軸', 'sym_neg_x': '-Xから+Xへ', 'sym_pos_x': '+Xから-Xへ', 'sym_neg_y': '-Yから+Yへ', 'sym_pos_y': '+Yから-Yへ', 'sym_neg_z': '-Zから+Zへ', 'sym_pos_z': '+Zから-Zへ', 'prop_enabled_desc': '編集モード専用のスカルプト代替パネルを有効・無効にします。無効にすると、UIを確認できる状態のまま各ボタンによるメッシュ変更を停止します。', 'prop_strength_desc': '各処理が選択頂点を動かす強さです。小さい値では控えめに変形し、大きい値では1回の実行で目標形状へ強く近づけます。', 'prop_amount_desc': '法線方向移動やオフセット移動に使う距離です。ドロー、膨張、収縮、移動、スネークフックなどの基本変位量になります。', 'prop_iterations_desc': 'スムーズ、リラックス、マスク、カラーのフィルター処理を繰り返す回数です。回数を増やすほど広く滑らかになりますが、細部は弱くなります。', 'prop_affect_all_desc': '何も選択されていない場合に、表示されている編集可能な全頂点を対象にします。誤って全体を変形したくない場合はオフのままにしてください。', 'prop_use_mask_desc': 'このアドオン独自の編集マスクレイヤーを使って変形を弱めます。マスク値1の頂点は保護され、0の頂点は完全に影響を受けます。Blender標準のスカルプトマスクではありません。', 'prop_grab_offset_desc': '移動とスネークフックで使うローカル座標のX・Y・Z移動量です。小さい値を入力すると、選択範囲を制御しやすくなります。', 'prop_pose_axis_desc': 'ポーズツールで使う軸です。選択範囲の中心を基準に、このオブジェクトローカル軸で回転させます。', 'prop_pose_angle_desc': 'ポーズツールで使う回転角度です。正負の値で、選択軸まわりの回転方向が変わります。', 'prop_face_set_id_desc': 'このアドオン独自の編集フェイスセットレイヤーで使う整数IDです。選択面をこのIDに割り当て、再選択や非表示に利用できます。', 'prop_color_desc': '編集カラー機能で使うRGBAカラーです。選択面に対して、編集モード用カラー属性へ書き込みます。', 'prop_sym_dir_desc': '編集モードの対称化方向です。スカルプトの対称化ではなくBlenderのメッシュの対称化演算子を使い、スカルプトモードには入りません。', 'tip_draw': '選択頂点を編集メッシュの平均法線方向へ動かし、形状を盛り上げます。少しずつ造形したい場合は、強さと量を低めに設定してください。', 'tip_draw_sharp': '法線方向の押し出しに軽いピンチを加え、選択範囲に鋭い稜線や溝を作ります。細いループや帯状の選択で効果が出やすいです。', 'tip_clay': '選択面を盛り上げたあと軽くリラックスし、粘土を重ねるような変形に近づけます。スカルプトモードへ切り替えず現在の編集選択だけに作用します。', 'tip_clay_strips': '法線方向の盛り上げと平面化を組み合わせ、帯状でやや平らな盛り付けを作ります。広い面を段階的に作る用途に向いています。', 'tip_blob': '選択頂点を中心から外側へ広げつつ法線方向にも押し出し、丸い膨らみを作ります。量を上げるとボリュームが強くなります。', 'tip_crease': '選択頂点を中心へ寄せながら法線内側へ動かし、折り目のような収縮を作ります。溝や締まったエッジを作る用途に使えます。', 'tip_smooth': '隣接頂点の位置を使って選択頂点をラプラシアンスムーズします。凹凸や頂点間隔の乱れを、編集モードのまま軽減します。', 'tip_relax': '隣接平均へ寄せる移動から法線方向の縮みをできるだけ除き、表面の体積を保ちながらトポロジーの流れを整えます。', 'tip_flatten': '選択中心と平均法線から求めた平面へ、選択頂点を近づけます。編集モード内で使えるシンプルなフラット化の代替処理です。', 'tip_fill': '選択範囲の基準平面より下にある頂点を平面へ近づけ、くぼみを埋める方向に変形します。', 'tip_scrape': '選択範囲の基準平面より上にある頂点を平面へ近づけ、出っ張りを削る方向に変形します。', 'tip_inflate': '選択頂点を各頂点の法線方向へ押し出します。スカルプトモードを使わず、選択範囲のボリュームを増やします。', 'tip_deflate': '選択頂点を各頂点の法線内側へ引き込みます。選択範囲のボリュームを減らしたり、くぼませたりできます。', 'tip_pinch': '選択頂点を選択中心へ寄せます。形状を締める、穴を狭める、稜線を鋭くするなどの用途に使えます。', 'tip_grab': '移動オフセットの値だけ、選択頂点をオブジェクトのローカル座標で移動します。選択ベースの移動の代替機能です。', 'tip_snake_hook': '移動オフセットで選択範囲を動かし、中心へ引く変形を少し加えてスネークフック風に引き伸ばします。', 'tip_elastic': '選択中心を基準に、選択頂点を弾性変形風に拡大・縮小します。量を低めにすると控えめな変形になります。', 'tip_pose': '選択中心を基準に、ポーズ軸とポーズ角度で選択頂点を回転します。編集モード内で曲げやポーズ変形を行う用途に使えます。', 'tip_filter_smooth': '対象頂点に反復スムーズを適用します。複数のブラシ風処理後に、広い範囲を整える用途に向いています。', 'tip_filter_relax': '対象頂点に反復リラックスを適用し、通常のスムーズより表面体積を保ちながら頂点分布を整えます。', 'tip_filter_sharpen': '選択頂点を隣接平均から離す方向へ動かし、局所的なコントラストを強めます。高い値では尖りが出やすいため注意してください。', 'tip_filter_scale': '選択範囲を中心から拡大・縮小します。強さで係数を調整し、量でスケール幅を制御します。', 'tip_mask_set': 'このアドオン独自の編集マスクレイヤーを作成または更新し、選択頂点にマスク値1を設定します。編集マスク使用時、その頂点は保護されます。', 'tip_mask_clear': '全ての編集可能頂点の編集マスク値を0に戻します。Blender標準のスカルプトマスクには影響しません。', 'tip_mask_invert': '編集マスク値を反転します。保護されていた場所は編集可能になり、編集可能だった場所は保護されます。', 'tip_mask_smooth': '接続頂点を通して編集マスク値をぼかします。選択範囲の周辺に柔らかい保護の減衰を作る用途に使えます。', 'tip_mask_boundary': '境界頂点や開いた辺にマスク値1を設定し、編集モード変形中にメッシュ境界を保護しやすくします。', 'tip_mask_cavity': '隣接頂点平均との差から凹凸を簡易推定し、曲率が高い場所に強めのマスク値を書き込みます。', 'tip_faceset_assign': '選択面を、このアドオン独自の整数編集フェイスセットレイヤーにフェイスセットIDとして保存します。標準スカルプトフェイスセットではありません。', 'tip_faceset_select': '編集フェイスセット値がフェイスセットIDと一致する面を選択します。保存した編集モード領域を素早く呼び出せます。', 'tip_faceset_hide': '編集フェイスセット値がフェイスセットIDと一致する面を非表示にします。再表示するには全て再表示を使います。', 'tip_faceset_reveal': '現在の編集メッシュ内の頂点・辺・面を全て再表示します。非表示にした編集フェイスセットの確認を戻す用途に使います。', 'tip_faceset_clear': '全ての面の編集フェイスセット値を0に戻し、このアドオン独自のフェイスセット割り当てを解除します。', 'tip_color_set': '編集モード用カラー属性を作成または使用し、選択面へ指定カラーを書き込みます。領域の色分けに使用できます。', 'tip_color_lighten': 'このアドオンのカラー属性で、選択面コーナーのRGB値を明るくします。アルファ値は保持します。', 'tip_color_darken': 'このアドオンのカラー属性で、選択面コーナーのRGB値を暗くします。アルファ値は保持します。', 'tip_color_smooth': '隣接する選択面のカラーを平均し、カラー境界を柔らかくします。編集モード用カラー属性に作用します。', 'tip_trim_selected': '選択面または選択頂点を編集メッシュから直接削除します。単純なトリム作業を選択ベースで置き換える機能です。', 'tip_subdivide': '選択辺を編集モードのまま細分化します。ブラシ風変形を行う前に、局所的な解像度を増やす用途に使えます。', 'tip_symmetrize': '対称方向の設定でBlenderのメッシュの対称化演算子を編集モード内実行します。スカルプトモードやスカルプトの対称化は呼び出しません。', 'tip_report': '現在の編集モードコンテキストで、全ての標準スカルプト機能が直接実行可能か検査します。検査中にモードは切り替えません。'}}
I18N['en_US']['panel_title'] = 'Strict Edit Mode Sculpt'
I18N['en_US'].update({'section_brush': 'Direct 3D Surface Brush', 'section_batch': 'Selection Batch Operations', 'brush_tool': 'Brush', 'brush_radius': 'Radius', 'brush_strength': 'Brush Strength', 'brush_amount': 'Brush Amount', 'brush_spacing': 'Spacing', 'brush_falloff': 'Falloff', 'brush_front_faces_only': 'Front faces only', 'brush_start': 'Start Direct Brush', 'brush_active_status': 'Edit Mode Direct Brush', 'brush_keys': 'LMB stroke | Ctrl invert | Shift smooth | F radius | Shift+F strength | [ ] radius | -/+ or Shift+[ ] strength | Ctrl+Wheel strength | E falloff pie | Shift+E cycle falloff | V/S/P/I/G/Shift+T/C/Shift+C/K/M switch brush | Esc/RMB finish', 'brush_no_view': 'Start this brush from a 3D View area.', 'brush_no_hit': 'Move the cursor over the editable mesh surface and drag with LMB.', 'brush_finished': 'Direct brush finished. Edit Mode was preserved.', 'falloff_smooth': 'Smooth', 'falloff_linear': 'Linear', 'falloff_round': 'Round', 'falloff_sharp': 'Sharp', 'falloff_constant': 'Constant', 'op_paint_select': 'Paint Select', 'op_mask_paint': 'Paint Mask', 'op_faceset_paint': 'Paint Face Set', 'op_color_paint': 'Paint Color', 'prop_brush_tool_desc': 'Chooses the Edit Mode direct brush used by the modal 3D View painting tool. Pick a brush, then press Start Direct Brush or one of the brush buttons and paint directly on the mesh surface with LMB.', 'prop_brush_radius_desc': 'Screen-space brush radius in pixels. The circular overlay uses this value, and affected mesh vertices are chosen from the visible surface inside the circle. Press F while the direct brush is active to adjust it interactively.', 'prop_brush_strength_desc': 'Strength of each direct brush stroke. Lower values build changes gradually; higher values apply stronger deformation, selection, mask, face set, or color influence. Press Shift+F or -/+ while the direct brush is active to adjust it.', 'prop_brush_amount_desc': 'Base movement distance used by deformation brushes such as Draw, Clay, Inflate, Deflate, Crease, Flatten, and Scrape. It is multiplied by Brush Strength and falloff for each stroke sample.', 'prop_brush_spacing_desc': 'Distance between repeated stroke samples as a fraction of the brush radius. Lower values make denser strokes and smoother painting, while higher values are lighter and faster.', 'prop_brush_falloff_desc': 'Controls how brush influence fades from the center of the circle toward the edge. Smooth is closest to a general sculpt falloff; Constant affects all vertices inside the radius evenly.', 'prop_brush_front_faces_only_desc': 'When enabled, the direct brush ignores back-facing vertices so strokes are limited to the visible side of the mesh surface. Disable it only when you intentionally want through-surface editing.', 'tip_direct_brush': 'Starts a modal Edit Mode brush in the 3D View. It does not enter Sculpt Mode and does not install a global keymap; LMB, F, Shift+F, Ctrl, Shift, brackets, -/+, and E are handled only while this brush is running. Sidebar mouse input is passed through so N-panel controls can be used without stopping the brush.', 'tip_paint_select': 'Paints the Edit Mode selection directly on the mesh surface. LMB selects vertices under the brush; Ctrl+LMB deselects them. The operation stays in Mesh Edit Mode.', 'tip_mask_paint': "Paints the add-on's Edit Mask layer directly on the mesh surface. LMB increases protection and Ctrl+LMB erases it. Enable Use Edit Mask to make deformation brushes respect the mask.", 'tip_faceset_paint': "Paints the add-on's Edit Face Set ID onto faces touched by the brush. Ctrl+LMB clears touched faces to ID 0. This is an Edit Mode substitute for Sculpt Face Sets.", 'tip_color_paint': 'Paints the chosen Edit Color onto touched face corners using the brush falloff. Ctrl+LMB softly removes the color toward black while staying in Edit Mode.'})
I18N['ja_JP'].update({'section_brush': '3Dビュー直接ブラシ', 'section_batch': '選択範囲への一括適用', 'brush_tool': 'ブラシ', 'brush_radius': '半径', 'brush_strength': 'ブラシ強さ', 'brush_amount': 'ブラシ量', 'brush_spacing': '間隔', 'brush_falloff': 'フォールオフ', 'brush_front_faces_only': '前面のみ', 'brush_start': '直接ブラシ開始', 'brush_active_status': '編集モード直接ブラシ', 'brush_keys': 'LMB: ストローク | Ctrl: 反転 | Shift: スムーズ | F: 半径 | Shift+F: 強さ | [ ]: 半径 | -/+ または Shift+[ ]: 強さ | Ctrl+ホイール: 強さ | E: フォールオフパイ | Shift+E: フォールオフ循環 | V/S/P/I/G/Shift+T/C/Shift+C/K/M: ブラシ切替 | Esc/RMB: 終了', 'brush_no_view': '3Dビュー領域からこのブラシを開始してください。', 'brush_no_hit': '編集可能なメッシュ表面にカーソルを置き、LMBでドラッグしてください。', 'brush_finished': '直接ブラシを終了しました。編集モードは維持されています。', 'falloff_smooth': 'スムーズ', 'falloff_linear': 'リニア', 'falloff_round': 'ラウンド', 'falloff_sharp': 'シャープ', 'falloff_constant': '一定', 'op_paint_select': '選択をペイント', 'op_mask_paint': 'マスクをペイント', 'op_faceset_paint': 'フェイスセットをペイント', 'op_color_paint': 'カラーをペイント', 'prop_brush_tool_desc': '3Dビュー上で直接塗るモーダルブラシの種類を選びます。ブラシを選択してから、直接ブラシ開始またはいずれかのブラシボタンを押し、メッシュ表面をLMBで直接なぞって使用します。', 'prop_brush_radius_desc': '画面上のピクセル単位のブラシ半径です。円形オーバーレイもこの値で表示され、円内の見えているメッシュ頂点が対象になります。直接ブラシ使用中はFキーで対話的に変更できます。', 'prop_brush_strength_desc': '直接ブラシストロークの強さです。低い値では少しずつ変化し、高い値では変形・選択・マスク・フェイスセット・カラーの影響が強くなります。直接ブラシ使用中はShift+Fまたは-/+で変更できます。', 'prop_brush_amount_desc': 'ドロー、クレイ、膨張、収縮、クリース、フラット化、スクレイプなどの変形ブラシで使う基本移動距離です。各ストロークサンプルでブラシ強さとフォールオフが掛け合わされます。', 'prop_brush_spacing_desc': 'ストローク中に連続配置するブラシサンプルの間隔です。ブラシ半径に対する割合で指定し、低い値ほど密で滑らか、高い値ほど軽く高速になります。', 'prop_brush_falloff_desc': 'ブラシ中心から外周へ向かう影響の減衰方法です。スムーズは一般的なスカルプト減衰に近く、一定は半径内の頂点へ均一に作用します。', 'prop_brush_front_faces_only_desc': '有効にすると裏向きの頂点を無視し、表示されている側のメッシュ表面だけにストロークを限定します。表面を貫通して編集したい場合だけ無効にしてください。', 'tip_direct_brush': '3Dビューで編集モード専用のモーダルブラシを開始します。スカルプトモードへは入らず、グローバルキーマップも登録しません。LMB、F、Shift+F、Ctrl、Shift、[ ]、-/+、Eは、このブラシ実行中だけ処理されます。Nパネル上のマウス入力は通過させるため、ブラシを止めずにパネル操作できます。', 'tip_paint_select': 'メッシュ表面を直接なぞって編集モードの選択をペイントします。LMBでブラシ下の頂点を選択し、Ctrl+LMBで選択解除します。処理中もメッシュ編集モードを維持します。', 'tip_mask_paint': 'このアドオン独自の編集マスクレイヤーを、メッシュ表面へ直接ペイントします。LMBで保護を強め、Ctrl+LMBで消します。変形ブラシに反映するには編集マスクを使用を有効にします。', 'tip_faceset_paint': 'ブラシが触れた面へ、このアドオン独自の編集フェイスセットIDをペイントします。Ctrl+LMBで触れた面をID 0へ戻します。標準スカルプトフェイスセットの編集モード代替です。', 'tip_color_paint': '選択した編集カラーを、フォールオフ付きで触れた面コーナーへペイントします。Ctrl+LMBでは黒方向へ柔らかく消し、編集モードのまま処理します。'})
_TRANSLATION_TABLE = {'ja_JP': {('*', 'Strict Edit Sculpt'): '編集モード専用スカルプト', ('*', 'Enabled'): I18N['ja_JP']['enabled'], ('*', 'Strength'): I18N['ja_JP']['strength'], ('*', 'Amount'): I18N['ja_JP']['amount'], ('*', 'Iterations'): I18N['ja_JP']['iterations'], ('*', 'Use visible vertices when nothing is selected'): I18N['ja_JP']['affect_all'], ('*', 'Use Edit Mask'): I18N['ja_JP']['use_mask'], ('*', 'Move Offset'): I18N['ja_JP']['grab_offset'], ('*', 'Pose Axis'): I18N['ja_JP']['pose_axis'], ('*', 'Pose Angle'): I18N['ja_JP']['pose_angle'], ('*', 'Face Set ID'): I18N['ja_JP']['face_set_id'], ('*', 'Color'): I18N['ja_JP']['color'], ('*', 'Symmetry Direction'): I18N['ja_JP']['sym_dir'], ('*', I18N['en_US']['prop_enabled_desc']): I18N['ja_JP']['prop_enabled_desc'], ('*', I18N['en_US']['prop_strength_desc']): I18N['ja_JP']['prop_strength_desc'], ('*', I18N['en_US']['prop_amount_desc']): I18N['ja_JP']['prop_amount_desc'], ('*', I18N['en_US']['prop_iterations_desc']): I18N['ja_JP']['prop_iterations_desc'], ('*', I18N['en_US']['prop_affect_all_desc']): I18N['ja_JP']['prop_affect_all_desc'], ('*', I18N['en_US']['prop_use_mask_desc']): I18N['ja_JP']['prop_use_mask_desc'], ('*', I18N['en_US']['prop_grab_offset_desc']): I18N['ja_JP']['prop_grab_offset_desc'], ('*', I18N['en_US']['prop_pose_axis_desc']): I18N['ja_JP']['prop_pose_axis_desc'], ('*', I18N['en_US']['prop_pose_angle_desc']): I18N['ja_JP']['prop_pose_angle_desc'], ('*', I18N['en_US']['prop_face_set_id_desc']): I18N['ja_JP']['prop_face_set_id_desc'], ('*', I18N['en_US']['prop_color_desc']): I18N['ja_JP']['prop_color_desc'], ('*', I18N['en_US']['prop_sym_dir_desc']): I18N['ja_JP']['prop_sym_dir_desc'], ('*', 'X Axis'): I18N['ja_JP']['axis_x'], ('*', 'Y Axis'): I18N['ja_JP']['axis_y'], ('*', 'Z Axis'): I18N['ja_JP']['axis_z'], ('*', '-X to +X'): I18N['ja_JP']['sym_neg_x'], ('*', '+X to -X'): I18N['ja_JP']['sym_pos_x'], ('*', '-Y to +Y'): I18N['ja_JP']['sym_neg_y'], ('*', '+Y to -Y'): I18N['ja_JP']['sym_pos_y'], ('*', '-Z to +Z'): I18N['ja_JP']['sym_neg_z'], ('*', '+Z to -Z'): I18N['ja_JP']['sym_pos_z']}}
_TRANSLATION_TABLE['ja_JP'].update({('*', 'Direct Edit Brush'): I18N['ja_JP']['brush_start'], ('*', 'Brush'): I18N['ja_JP']['brush_tool'], ('*', 'Radius'): I18N['ja_JP']['brush_radius'], ('*', 'Brush Strength'): I18N['ja_JP']['brush_strength'], ('*', 'Brush Amount'): I18N['ja_JP']['brush_amount'], ('*', 'Spacing'): I18N['ja_JP']['brush_spacing'], ('*', 'Falloff'): I18N['ja_JP']['brush_falloff'], ('*', 'Front faces only'): I18N['ja_JP']['brush_front_faces_only'], ('*', 'Smooth'): I18N['ja_JP']['falloff_smooth'], ('*', 'Linear'): I18N['ja_JP']['falloff_linear'], ('*', 'Round'): I18N['ja_JP']['falloff_round'], ('*', 'Sharp'): I18N['ja_JP']['falloff_sharp'], ('*', 'Constant'): I18N['ja_JP']['falloff_constant'], ('*', 'Paint Select'): I18N['ja_JP']['op_paint_select'], ('*', 'Paint Mask'): I18N['ja_JP']['op_mask_paint'], ('*', 'Paint Face Set'): I18N['ja_JP']['op_faceset_paint'], ('*', 'Paint Color'): I18N['ja_JP']['op_color_paint'], ('*', I18N['en_US']['tip_direct_brush']): I18N['ja_JP']['tip_direct_brush'], ('*', I18N['en_US']['tip_paint_select']): I18N['ja_JP']['tip_paint_select'], ('*', I18N['en_US']['tip_mask_paint']): I18N['ja_JP']['tip_mask_paint'], ('*', I18N['en_US']['tip_faceset_paint']): I18N['ja_JP']['tip_faceset_paint'], ('*', I18N['en_US']['tip_color_paint']): I18N['ja_JP']['tip_color_paint'], ('*', I18N['en_US']['prop_brush_tool_desc']): I18N['ja_JP']['prop_brush_tool_desc'], ('*', I18N['en_US']['prop_brush_radius_desc']): I18N['ja_JP']['prop_brush_radius_desc'], ('*', I18N['en_US']['prop_brush_strength_desc']): I18N['ja_JP']['prop_brush_strength_desc'], ('*', I18N['en_US']['prop_brush_amount_desc']): I18N['ja_JP']['prop_brush_amount_desc'], ('*', I18N['en_US']['prop_brush_spacing_desc']): I18N['ja_JP']['prop_brush_spacing_desc'], ('*', I18N['en_US']['prop_brush_falloff_desc']): I18N['ja_JP']['prop_brush_falloff_desc'], ('*', I18N['en_US']['prop_brush_front_faces_only_desc']): I18N['ja_JP']['prop_brush_front_faces_only_desc']})
I18N['en_US'].update({'op_draw': 'Draw', 'op_draw_sharp': 'Draw Sharp', 'op_clay': 'Clay', 'op_clay_strips': 'Clay Strips', 'op_blob': 'Blob', 'op_crease': 'Crease', 'op_smooth': 'Smooth', 'op_relax': 'Relax', 'op_flatten': 'Flatten', 'op_fill': 'Fill', 'op_scrape': 'Scrape', 'op_inflate': 'Inflate', 'op_deflate': 'Deflate', 'op_pinch': 'Pinch', 'op_grab': 'Grab', 'op_snake_hook': 'Snake Hook', 'op_elastic': 'Elastic Deform', 'op_pose': 'Pose', 'op_filter_smooth': 'Smooth Filter', 'op_filter_relax': 'Relax Filter', 'op_filter_sharpen': 'Sharpen Filter', 'op_filter_scale': 'Scale Filter', 'op_plane': 'Plane', 'op_multiplane_scrape': 'Multiplane Scrape', 'op_rotate': 'Rotate', 'op_topology': 'Topology', 'op_cloth': 'Cloth', 'op_simplify': 'Simplify', 'op_draw_face_sets': 'Draw Face Sets', 'op_displacement_eraser': 'Displacement Eraser', 'op_displacement_smear': 'Displacement Smear', 'op_paint': 'Paint'})
I18N['ja_JP'].update({'op_draw': 'ドロー', 'op_draw_sharp': 'ドローシャープ', 'op_clay': 'クレイ', 'op_clay_strips': 'クレイストリップ', 'op_blob': 'ブロブ', 'op_crease': 'クリース', 'op_smooth': 'スムーズ', 'op_relax': 'リラックス', 'op_flatten': 'フラット化', 'op_fill': 'フィル', 'op_scrape': 'スクレイプ', 'op_inflate': 'インフレート', 'op_deflate': 'デフレート', 'op_pinch': 'ピンチ', 'op_grab': 'グラブ', 'op_snake_hook': 'スネークフック', 'op_elastic': '弾性変形', 'op_pose': 'ポーズ', 'op_filter_smooth': 'スムーズ', 'op_filter_relax': 'リラックス', 'op_filter_sharpen': 'シャープ', 'op_filter_scale': 'スケール', 'op_plane': 'プレーン', 'op_multiplane_scrape': 'マルチプレーンスクレイプ', 'op_rotate': '回転', 'op_topology': 'トポロジー', 'op_cloth': 'クロス', 'op_simplify': 'シンプル化', 'op_draw_face_sets': 'フェイスセット描画', 'op_displacement_eraser': '変位消去', 'op_displacement_smear': '変位スメア', 'op_paint': 'ペイント'})
I18N['en_US'].update({'tip_plane': 'Flattens or raises the surface toward a working plane under the brush.', 'tip_multiplane_scrape': 'Scrapes the surface against two angled planes to carve hard creases.', 'tip_rotate': 'Rotates the surface under the brush around the brush center.', 'tip_topology': 'Evens out the vertices under the brush without changing the overall form.', 'tip_cloth': 'Stretches the surface under the brush with a soft, cloth-like drag.', 'tip_simplify': 'Smooths fine detail under the brush to simplify the surface.', 'tip_draw_face_sets': "Paints the add-on's Edit Face Set ID onto faces touched by the brush.", 'tip_displacement_eraser': 'Reduces displacement under the brush and returns the surface toward a smooth form.', 'tip_displacement_smear': 'Drags displacement under the brush along the stroke.', 'tip_paint': 'Paints the chosen Edit Color onto the surface under the brush.'})
I18N['ja_JP'].update({'tip_plane': 'ブラシの下の作業平面へ、表面を平らにしたり盛り上げたりします。', 'tip_multiplane_scrape': '角度のある 2 つの平面で表面を削り、硬い折れ目を作ります。', 'tip_rotate': 'ブラシの下の表面を、ブラシの中心のまわりに回転します。', 'tip_topology': '全体の形を変えずに、ブラシの下の頂点の並びを整えます。', 'tip_cloth': 'ブラシの下の表面を、布のように柔らかく引き伸ばします。', 'tip_simplify': 'ブラシの下の細部をならして、表面を単純にします。', 'tip_draw_face_sets': 'ブラシが触れた面へ、このアドオン独自の編集フェイスセットIDを塗ります。', 'tip_displacement_eraser': 'ブラシの下の変位を減らし、表面をなめらかな形へ戻します。', 'tip_displacement_smear': 'ブラシの下の変位を、ストロークの向きへ引きずります。', 'tip_paint': 'ブラシの下の表面へ、選んだ編集カラーを塗ります。'})
I18N['en_US'].update({'unknown_operation': 'Unknown operation', 'mode_changed_unexpectedly': 'Mode changed unexpectedly'})
I18N['ja_JP'].update({'unknown_operation': '不明な操作です。', 'mode_changed_unexpectedly': 'モードが予期せず変更されました。'})
_TRANSLATION_TABLE['ja_JP'].update({
    ('*', 'Starts an Edit Mode surface brush without entering Sculpt Mode or registering global hotkeys.'): 'スカルプトモードへ入らず、グローバルホットキーも登録せずに編集モードのサーフェスブラシを開始します。',
    ('*', 'Starts the Edit Mode direct brush from UI controls after the button event has completed.'): 'ボタンイベント完了後にUI操作から編集モード直接ブラシを開始します。',
    ('*', 'Adjust Edit Sculpt Brush'): '編集スカルプトブラシを調整',
    ('*', 'Adjusts the active Edit Mode sculpt brush radius or strength with a short cursor-grab modal session.'): '短いカーソルグラブのモーダル操作で、アクティブな編集モードスカルプトブラシの半径または強さを調整します。',
    ('*', 'Adjust the active Edit Mode brush radius.'): 'アクティブな編集モードブラシの半径を調整します。',
    ('*', 'Adjust the active Edit Mode brush strength.'): 'アクティブな編集モードブラシの強さを調整します。',
    ('*', 'Sets the Edit Mode direct brush falloff type.'): '編集モード直接ブラシの減衰タイプを設定します。',
    ('*', 'Opens the falloff type pie menu for the Edit Mode direct brush.'): '編集モード直接ブラシの減衰タイプ用パイメニューを開きます。',
    ('*', 'Sculpt Toolbar Replacement'): 'スカルプトツールバー代替',
    ('*', 'Selects or starts an Edit Mode replacement for a Blender Sculpt toolbar tool without switching to Sculpt Mode.'): 'スカルプトモードへ切り替えずに、Blenderスカルプトツールバーツールの編集モード代替を選択または開始します。',
    ('*', 'Edit Sculpt Toolbar Command'): '編集スカルプトツールバーコマンド',
    ('*', 'Runs a Sculpt-toolbar-style command replacement in Mesh Edit Mode without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、メッシュ編集モードでスカルプトツールバー系コマンドの代替を実行します。',
    ('*', 'Edit Sculpt Operation'): '編集スカルプト操作',
    ('*', 'Runs an Edit Mode-only sculpt-like vertex operation without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、編集モード専用のスカルプト風頂点操作を実行します。',
    ('*', 'Edit Mask Operation'): '編集マスク操作',
    ('*', 'Edits the add-on mask layer in Mesh Edit Mode without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、メッシュ編集モードでアドオンのマスクレイヤーを編集します。',
    ('*', 'Edit Face Set Operation'): '編集フェイスセット操作',
    ('*', 'Edits the add-on face-set layer in Mesh Edit Mode without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、メッシュ編集モードでアドオンのフェイスセットレイヤーを編集します。',
    ('*', 'Edit Color Operation'): '編集カラー操作',
    ('*', 'Edits the add-on color layer in Mesh Edit Mode without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、メッシュ編集モードでアドオンのカラーレイヤーを編集します。',
    ('*', 'Edit Topology Operation'): '編集トポロジー操作',
    ('*', 'Runs Edit Mode topology operations without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、編集モードのトポロジー操作を実行します。',
    ('*', 'Edit Sculpt Toolbar Gesture'): '編集スカルプトツールバージェスチャー',
    ('*', 'Runs an Edit Mode replacement for a Blender Sculpt toolbar gesture tool without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、Blenderスカルプトツールバーのジェスチャーツールの編集モード代替を実行します。',
    ('*', 'Edit Sculpt Toolbar Operation'): '編集スカルプトツールバー操作',
    ('*', 'Runs an Edit Mode replacement for a Blender Sculpt toolbar operation without entering Sculpt Mode.'): 'スカルプトモードへ入らずに、Blenderスカルプトツールバー操作の編集モード代替を実行します。',
    ('*', 'Select Brush Asset'): 'ブラシアセットを選択',
    ('*', 'Selects a standard Sculpt brush asset replacement as the active Edit Mode direct brush.'): '標準スカルプトブラシアセットの代替をアクティブな編集モード直接ブラシとして選択します。',
    ('*', 'Select Sculpt Toolbar Tool'): 'スカルプトツールバーツールを選択',
    ('*', 'Selects a standard Sculpt toolbar replacement as the active toolbar tool.'): '標準スカルプトツールバーの代替をアクティブなツールバーツールとして選択します。',
    ('*', 'Opens the full icon grid for the standard Sculpt brush asset replacements.'): '標準スカルプトブラシアセット代替の全アイコングリッドを開きます。',
    ('*', 'Opens the full icon button list for the standard Sculpt toolbar replacements.'): '標準スカルプトツールバー代替の全アイコンボタンリストを開きます。',
    ('*', 'Runs the selected standard Sculpt toolbar replacement in Mesh Edit Mode.'): '選択中の標準スカルプトツールバー代替をメッシュ編集モードで実行します。',
    ('*', 'Copies a Strict Edit Mode Sculpt keymap registration operator ID to the clipboard.'): '厳密編集モードスカルプトのキーマップ登録用オペレーターIDをクリップボードへコピーします。',
    ('*', 'Native Sculpt Report'): 'ネイティブスカルプトレポート',
    ('*', 'Shows whether native sculpt operators can run directly in the current Edit Mode context without changing modes.'): 'モードを変更せずに、標準のスカルプト機能が現在の編集モードコンテキストで直接実行できるかを表示します。',
    ('*', 'Unknown operation'): '不明な操作です。',
    ('*', 'Mode changed unexpectedly'): 'モードが予期せず変更されました。',
})
STANDARD_SCULPT_BRUSH_DATA = (('AIRBRUSH', 'Airbrush', 'エアブラシ', 'PAINT', 'COLOR_PAINT', 'airbrush'), ('DRAW','Draw', 'ドロー', 'DRAW', 'DRAW', 'draw'), ('DRAW_SHARP', 'Draw Sharp', 'ドローシャープ', 'DRAW_SHARP', 'DRAW_SHARP', 'draw_sharp'), ('CLAY', 'Clay', 'クレイ', 'CLAY', 'CLAY', 'clay'), ('CLAY_STRIPS', 'Clay Strips', 'クレイストリップ', 'CLAY_STRIPS', 'CLAY_STRIPS', 'clay_strips'), ('CLAY_THUMB', 'Clay Thumb', 'クレイサム', 'CLAY_THUMB', 'CLAY', 'clay_thumb'), ('LAYER', 'Layer', 'レイヤー', 'LAYER', 'DRAW', 'layer'), ('BLOB', 'Blob', 'ブロブ', 'BLOB', 'BLOB', 'blob'), ('CREASE_SHARP', 'Crease Sharp', 'クリースシャープ', 'CREASE', 'CREASE', 'crease_sharp'), ('CREASE_POLISH', 'Crease Polish', 'クリースポリッシュ', 'CREASE', 'CREASE', 'crease_polish'), ('SMOOTH', 'Smooth', 'スムーズ', 'SMOOTH', 'SMOOTH', 'smooth'), ('BLUR', 'Blur', 'ブラー', 'BLUR', 'SMOOTH', 'blur'), ('FLATTEN_CONTRAST', 'Flatten/Contrast', 'フラット化・コントラスト', 'PLANE', 'FLATTEN', 'flatten_contrast'), ('FILL_DEEPEN', 'Fill/Deepen', 'フィル・深化', 'PLANE', 'FILL', 'fill_deepen'), ('SCRAPE_FILL', 'Scrape/Fill', 'スクレイプ・フィル', 'PLANE', 'SCRAPE', 'scrape_fill'), ('SCRAPE_MULTIPLANE', 'Scrape Multiplane', 'マルチプレーンスクレイプ', 'MULTIPLANE_SCRAPE', 'SCRAPE', 'scrape_multiplane'), ('TRIM', 'Trim', 'トリム', 'PLANE', 'SCRAPE', 'trim'), ('PLATEAU', 'Plateau', 'プラトー', 'PLANE', 'FLATTEN', 'plateau'), ('INFLATE_DEFLATE', 'Inflate/Deflate', '膨張・収縮', 'INFLATE', 'INFLATE', 'inflate_deflate'), ('PINCH_MAGNIFY', 'Pinch/Magnify', 'ピンチ・拡大', 'PINCH', 'PINCH', 'pinch_magnify'), ('GRAB', 'Grab', 'グラブ', 'GRAB', 'GRAB', 'grab'), ('GRAB_2D', 'Grab 2D', '2Dグラブ', 'GRAB', 'GRAB', 'grab_2d'), ('GRAB_SILHOUETTE', 'Grab Silhouette', 'シルエットグラブ', 'GRAB', 'GRAB', 'grab_silhouette'), ('ELASTIC_GRAB', 'Elastic Grab', 'エラスティックグラブ', 'ELASTIC_DEFORM', 'ELASTIC', 'elastic_grab'), ('SNAKE_HOOK', 'Snake Hook', 'スネークフック', 'SNAKE_HOOK', 'SNAKE_HOOK', 'snake_hook'), ('ELASTIC_SNAKE_HOOK', 'Elastic Snake Hook', 'エラスティックスネークフック', 'SNAKE_HOOK', 'SNAKE_HOOK', 'elastic_snake_hook'), ('PULL', 'Pull', 'プル', 'SNAKE_HOOK', 'SNAKE_HOOK', 'pull'), ('THUMB', 'Thumb', 'サム', 'THUMB', 'GRAB', 'thumb'), ('NUDGE', 'Nudge', 'ナッジ', 'NUDGE', 'GRAB', 'nudge'), ('SMEAR', 'Smear', 'スメア', 'SMEAR', 'GRAB', 'smear'), ('SHARPEN', 'Sharpen', 'シャープ化', 'SMEAR', 'FILTER_SHARPEN', 'sharpen'), ('POSE', 'Pose', 'ポーズ', 'POSE', 'POSE', 'pose'), ('BOUNDARY', 'Boundary', '境界', 'BOUNDARY', 'BOUNDARY', 'boundary'), ('BEND_BOUNDARY_CLOTH', 'Bend Boundary Cloth', '境界クロス曲げ', 'BOUNDARY', 'BOUNDARY', 'bend_boundary_cloth'), ('TWIST_BOUNDARY_CLOTH', 'Twist Boundary Cloth', '境界クロスねじり', 'BOUNDARY', 'TWIST', 'twist_boundary_cloth'), ('TWIST', 'Twist', 'ツイスト', 'ROTATE', 'TWIST', 'twist'), ('STRETCH_MOVE_CLOTH', 'Stretch/Move Cloth', 'クロス伸縮・移動', 'POSE', 'POSE', 'stretch_move_cloth'), ('BEND_TWIST_CLOTH', 'Bend/Twist Cloth', 'クロス曲げ・ねじり', 'POSE', 'POSE', 'bend_twist_cloth'), ('DENSITY', 'Density', '密度', 'SIMPLIFY', 'DENSITY', 'density'), ('RELAX_SLIDE', 'Relax Slide', 'リラックススライド', 'TOPOLOGY', 'RELAX', 'relax_slide'), ('RELAX_PINCH', 'Relax Pinch', 'リラックスピンチ', 'TOPOLOGY', 'RELAX', 'relax_pinch'), ('MASK_PAINT', 'Mask', 'マスク', 'MASK', 'MASK_PAINT', 'mask'), ('FACE_SET_PAINT', 'Face Set Paint', 'フェイスセットペイント', 'DRAW_FACE_SETS', 'FACE_SET_PAINT', 'face_set_paint'), ('PAINT_HARD', 'Paint Hard', 'ペイントハード', 'PAINT', 'COLOR_PAINT', 'paint_hard'), ('PAINT_HARD_PRESSURE', 'Paint Hard Pressure', 'ペイントハード筆圧', 'PAINT', 'COLOR_PAINT', 'paint_hard_pressure'), ('PAINT_SOFT', 'Paint Soft', 'ペイントソフト', 'PAINT', 'COLOR_PAINT', 'paint_soft'), ('PAINT_SOFT_PRESSURE', 'Paint Soft Pressure', 'ペイントソフト筆圧', 'PAINT', 'COLOR_PAINT', 'paint_soft_pressure'), ('PAINT_SQUARE', 'Paint Square', 'ペイントスクエア', 'PAINT', 'COLOR_PAINT', 'paint_square'), ('PAINT_BLEND', 'Paint Blend', 'ペイントブレンド', 'PAINT', 'COLOR_PAINT', 'paint_blend'), ('BLEND_HARD', 'Blend Hard', 'ブレンドハード', 'PAINT', 'COLOR_PAINT', 'blend_hard'), ('BLEND_SOFT', 'Blend Soft', 'ブレンドソフト', 'PAINT', 'COLOR_PAINT', 'blend_soft'), ('BLEND_SQUARE', 'Blend Square', 'ブレンドスクエア', 'PAINT', 'COLOR_PAINT', 'blend_square'), ('DRAG_CLOTH', 'Drag Cloth', 'クロスドラッグ', 'CLOTH', 'GRAB', 'drag_cloth'), ('GRAB_CLOTH', 'Grab Cloth', 'クロスグラブ', 'CLOTH', 'GRAB', 'grab_cloth'), ('GRAB_PLANAR_CLOTH', 'Grab Planar Cloth', '平面クロスグラブ', 'CLOTH', 'GRAB', 'grab_planar_cloth'), ('GRAB_RANDOM_CLOTH', 'Grab Random Cloth', 'ランダムクロスグラブ', 'CLOTH', 'GRAB', 'grab_random_cloth'), ('PUSH_CLOTH', 'Push Cloth', 'クロスプッシュ', 'CLOTH', 'DRAW', 'push_cloth'), ('INFLATE_CLOTH', 'Inflate Cloth', 'クロス膨張', 'CLOTH', 'INFLATE', 'inflate_cloth'), ('EXPAND_CONTRACT_CLOTH', 'Expand/Contract Cloth', 'クロス拡張・収縮', 'CLOTH', 'ELASTIC', 'expand_contract_cloth'), ('PINCH_FOLDS_CLOTH', 'Pinch Folds Cloth', 'クロス折り目ピンチ', 'CLOTH', 'PINCH', 'pinch_folds_cloth'), ('PINCH_POINT_CLOTH', 'Pinch Point Cloth', 'クロス点ピンチ', 'CLOTH', 'PINCH', 'pinch_point_cloth'), ('ERASE_MULTIRES_DISPLACEMENT', 'Erase Multires Displacement', 'マルチレゾ変位消去', 'DISPLACEMENT_ERASER', 'DEFLATE', 'erase_multires_displacement'), ('SMEAR_MULTIRES_DISPLACEMENT', 'Smear Multires Displacement', 'マルチレゾ変位スメア', 'DISPLACEMENT_SMEAR', 'GRAB', 'smear_multires_displacement'))
STANDARD_SCULPT_TOOLBAR_DATA = (('BOX_MASK', 'Box Mask', 'ボックスマスク', 'ops.sculpt.border_mask', 'GESTURE_MASK', 'BOX'), ('LASSO_MASK', 'Lasso Mask', '投げ縄マスク', 'ops.sculpt.lasso_mask', 'GESTURE_MASK', 'LASSO'), ('LINE_MASK', 'Line Mask', 'ラインマスク', 'ops.sculpt.line_mask', 'GESTURE_MASK', 'LINE'), ('POLYLINE_MASK', 'Polyline Mask', 'ポリラインマスク', 'ops.sculpt.polyline_mask', 'GESTURE_MASK', 'POLYLINE'), ('BOX_HIDE', 'Box Hide', 'ボックス非表示', 'ops.sculpt.border_hide', 'GESTURE_HIDE', 'BOX'), ('LASSO_HIDE', 'Lasso Hide', '投げ縄非表示', 'ops.sculpt.lasso_hide', 'GESTURE_HIDE', 'LASSO'), ('LINE_HIDE', 'Line Hide', 'ライン非表示', 'ops.sculpt.line_hide', 'GESTURE_HIDE', 'LINE'), ('POLYLINE_HIDE', 'Polyline Hide', 'ポリライン非表示', 'ops.sculpt.polyline_hide', 'GESTURE_HIDE', 'POLYLINE'), ('BOX_FACE_SET', 'Box Face Set', 'ボックスフェイスセット', 'ops.sculpt.border_face_set', 'GESTURE_FACE_SET', 'BOX'), ('LASSO_FACE_SET', 'Lasso Face Set', '投げ縄フェイスセット', 'ops.sculpt.lasso_face_set', 'GESTURE_FACE_SET', 'LASSO'), ('LINE_FACE_SET', 'Line Face Set', 'ラインフェイスセット', 'ops.sculpt.line_face_set', 'GESTURE_FACE_SET', 'LINE'), ('POLYLINE_FACE_SET', 'Polyline Face Set', 'ポリラインフェイスセット', 'ops.sculpt.polyline_face_set', 'GESTURE_FACE_SET', 'POLYLINE'), ('BOX_TRIM', 'Box Trim', 'ボックストリム', 'ops.sculpt.box_trim', 'GESTURE_TRIM', 'BOX'), ('LASSO_TRIM', 'Lasso Trim', '投げ縄トリム', 'ops.sculpt.lasso_trim', 'GESTURE_TRIM', 'LASSO'), ('LINE_TRIM', 'Line Trim', 'ライントリム', 'ops.sculpt.line_trim', 'GESTURE_TRIM', 'LINE'), ('POLYLINE_TRIM', 'Polyline Trim', 'ポリライントリム', 'ops.sculpt.polyline_trim', 'GESTURE_TRIM', 'POLYLINE'), ('LINE_PROJECT', 'Line Project', 'ライン投影', 'ops.sculpt.line_project', 'GESTURE_PROJECT', 'LINE'), ('MESH_FILTER', 'Mesh Filter', 'メッシュフィルター', 'ops.sculpt.mesh_filter', 'TOOLBAR_MESH_FILTER', 'NONE'), ('CLOTH_FILTER', 'Cloth Filter', 'クロスフィルター', 'ops.sculpt.cloth_filter', 'TOOLBAR_CLOTH_FILTER', 'NONE'), ('COLOR_FILTER', 'Color Filter', 'カラーフィルター', 'ops.sculpt.color_filter', 'TOOLBAR_COLOR_FILTER', 'NONE'), ('FACE_SET_EDIT', 'Edit Face Set', 'フェイスセット編集', 'ops.sculpt.face_set_edit', 'TOOLBAR_FACE_SET_EDIT', 'NONE'), ('MASK_BY_COLOR', 'Mask by Color', 'カラーからマスク', 'ops.sculpt.mask_by_color', 'TOOLBAR_MASK_BY_COLOR', 'NONE'), ('MOVE', 'Move', '移動', 'ops.transform.translate', 'TRANSFORM_MOVE', 'NONE'), ('ROTATE', 'Rotate', '回転', 'ops.transform.rotate', 'TRANSFORM_ROTATE', 'NONE'), ('SCALE', 'Scale', 'スケール', 'ops.transform.resize', 'TRANSFORM_SCALE', 'NONE'), ('TRANSFORM', 'Transform', 'トランスフォーム', 'ops.transform.transform', 'TRANSFORM_ALL', 'NONE'))
_LEGACY_FILTER_TARGETS = {'TOOLBAR_MESH_FILTER': 'FILTER_SMOOTH', 'TOOLBAR_CLOTH_FILTER': 'CLOTH', 'TOOLBAR_COLOR_FILTER': 'COLOR_SMOOTH', 'TOOLBAR_FACE_SET_EDIT': 'FACE_SET_EDIT', 'TOOLBAR_MASK_BY_COLOR': 'MASK_BY_COLOR'}
_LEGACY_COMMAND_PAYLOADS = {'TOOLBAR_MESH_FILTER': 'FILTER_SMOOTH', 'TOOLBAR_CLOTH_FILTER': 'CLOTH_FILTER', 'TOOLBAR_COLOR_FILTER': 'COLOR_FILTER', 'TOOLBAR_FACE_SET_EDIT': 'FACE_SET_EDIT', 'TOOLBAR_MASK_BY_COLOR': 'MASK_BY_COLOR'}
_LEGACY_TRANSFORM_TARGETS = {'TRANSFORM_MOVE': 'TRANSLATE', 'TRANSFORM_ROTATE': 'ROTATE', 'TRANSFORM_SCALE': 'RESIZE', 'TRANSFORM_ALL': 'TRANSFORM'}
_LEGACY_TRANSFORM_PAYLOADS = {'TRANSFORM_MOVE': 'TRANSLATE', 'TRANSFORM_ROTATE': 'ROTATE', 'TRANSFORM_SCALE': 'SCALE', 'TRANSFORM_ALL': 'TRANSFORM'}


def _sculpt_toolbar_defs():
    """Legacy (ident, label_key, icon, action, target) view of STANDARD_SCULPT_TOOLBAR_DATA.

    SES_OT_ToolbarTool referenced this name while no revision of this module bound it, so
    every use raised NameError. This binding derives the legacy shape from the modern
    toolbar table; it adds no data of its own.
    """
    defs = []
    for tool_id, _name_en, _name_ja, icon_handle, action, _shape in STANDARD_SCULPT_TOOLBAR_DATA:
        label_key = 'toolbar_' + tool_id.lower()
        if action.startswith('GESTURE_'):
            legacy_action, target = 'GESTURE', tool_id
        elif action.startswith('TRANSFORM_'):
            legacy_action, target = 'TRANSFORM', _LEGACY_TRANSFORM_TARGETS.get(action, 'TRANSFORM')
        else:
            legacy_action, target = 'FILTER', _LEGACY_FILTER_TARGETS.get(action, 'FILTER_SMOOTH')
        defs.append((tool_id, label_key, icon_handle, legacy_action, target))
    return tuple(defs)


def _build_legacy_toolbar_items():
    """Legacy (item_id, label_key, tip_key, icon, kind, payload) table for SES_OT_ToolCommand."""
    items = []
    for tool_id, _name_en, _name_ja, icon_handle, action, _shape in STANDARD_SCULPT_TOOLBAR_DATA:
        label_key = 'toolbar_' + tool_id.lower()
        tip_key = 'toolbar_tip_' + tool_id.lower()
        if action.startswith('GESTURE_'):
            kind, payload = 'GESTURE', action[len('GESTURE_'):]
        elif action.startswith('TRANSFORM_'):
            kind, payload = 'TRANSFORM', _LEGACY_TRANSFORM_PAYLOADS.get(action, 'TRANSFORM')
        else:
            kind, payload = 'COMMAND', _LEGACY_COMMAND_PAYLOADS.get(action, 'FILTER_SMOOTH')
        items.append((tool_id, label_key, tip_key, icon_handle, kind, payload))
    return tuple(items)


_SCULPT_TOOLBAR_ITEMS = _build_legacy_toolbar_items()


def _view3d_overlay_bounds(area, region):
    """Drawable overlay rectangle of a 3D View window region, as (x, y, width, height).

    The popup overlay builders called this name while no revision bound it, so opening
    either advertised popup operator raised NameError. Region-local full bounds keep the
    popup centered in the region, which is what the callers' centering math expects.
    """
    width = float(getattr(region, 'width', 800) or 800)
    height = float(getattr(region, 'height', 600) or 600)
    return 0.0, 0.0, width, height


_PREVIEW_COLLECTION = None
_TOOL_ICON_CACHE_LIMIT = 512
_BRUSH_ASSET_ICON_CACHE_LIMIT = 512
_BRUSH_ASSET_OBJECT_CACHE_LIMIT = 256
_POPUP_OVERLAY_TEXTURE_CACHE_LIMIT = 640
_TOOL_ICON_CACHE = OrderedDict()
_BRUSH_ASSET_ICON_CACHE = OrderedDict()
_BRUSH_ASSET_OBJECT_CACHE = OrderedDict()
_ACTIVE_DRAW_HANDLERS = []
_DRAW_HANDLER_NAMESPACE_KEY = 'strict_edit_mode_sculpt.active_draw_handlers'
_GESTURE_UNDO_BASELINED_MESHES = set()
_GESTURE_UNDO_LOAD_HANDLER = None

def _bounded_cache_get(cache, key, default=None):
    value = cache.get(key, default)
    if key in cache:
        try:
            cache.move_to_end(key)
        except Exception:
            pass
    return value

def _bounded_cache_store(cache, key, value, limit):
    cache[key] = value
    try:
        cache.move_to_end(key)
    except Exception:
        pass
    max_items = max(1, int(limit))
    while len(cache) > max_items:
        try:
            cache.popitem(last=False)
        except TypeError:
            try:
                cache.pop(next(iter(cache)), None)
            except Exception:
                break
        except Exception:
            break
    return value

def _draw_handler_store():
    return _ACTIVE_DRAW_HANDLERS

def _track_draw_handler(handle, state):
    if handle is None:
        return
    region_type = 'WINDOW'
    if isinstance(state, dict):
        region_type = str(state.get('_region_type', 'WINDOW') or 'WINDOW')
    _ACTIVE_DRAW_HANDLERS.append((handle, state, region_type))

def _untrack_draw_handler(handle):
    global _ACTIVE_DRAW_HANDLERS
    _ACTIVE_DRAW_HANDLERS = [item for item in _ACTIVE_DRAW_HANDLERS if item[0] is not handle]

def _remove_tracked_draw_handler(handle, state=None):
    if isinstance(state, dict):
        state['alive'] = False
    region_type = str(state.get('_region_type', 'WINDOW') or 'WINDOW') if isinstance(state, dict) else 'WINDOW'
    if handle is not None:
        _lifecycle.remove_draw_handler(bpy.types.SpaceView3D, handle, region_type)
        _untrack_draw_handler(handle)

def _cleanup_draw_handlers():
    seen = set()
    for item in tuple(_ACTIVE_DRAW_HANDLERS):
        handle = item[0]
        state = item[1] if len(item) > 1 else None
        marker = id(handle)
        if marker in seen:
            continue
        seen.add(marker)
        _remove_tracked_draw_handler(handle, state)
    _ACTIVE_DRAW_HANDLERS.clear()

def _add_tracked_draw_handler(callback, state, region_type='WINDOW', draw_type='POST_PIXEL'):
    if isinstance(state, dict):
        state['_region_type'] = str(region_type)
        state['_generation_uuid'] = _lifecycle.active_generation()
    handle, wrapped = _lifecycle.add_draw_handler(bpy.types.SpaceView3D, callback, (state,), str(region_type), str(draw_type))
    if isinstance(state, dict):
        state['_wrapped_callback'] = wrapped
    _track_draw_handler(handle, state)
    return handle

def _state_region_pointer(region):
    try:
        return int(region.as_pointer())
    except Exception:
        return 0

def _state_area_pointer(area):
    try:
        return int(area.as_pointer())
    except Exception:
        return 0

def _draw_state_matches_active_view(state):
    """Restrict custom draw callbacks to the View3D area that launched them."""
    if not isinstance(state, dict) or not state.get('alive', False):
        return False
    expected_area = int(state.get('area_pointer', 0) or 0)
    expected_region = int(state.get('region_pointer', 0) or 0)
    try:
        area = getattr(bpy.context, 'area', None)
        region = getattr(bpy.context, 'region', None)
    except Exception:
        area = None
        region = None
    try:
        if expected_area and area is not None and (_state_area_pointer(area) != expected_area):
            return False
        if state.get('area_overlay', False):
            return True
        if expected_region and region is not None and (_state_region_pointer(region) != expected_region):
            return False
    except Exception:
        return False
    return True

def _region_viewport_snapshot(region):
    try:
        return (int(region.x), int(region.y), int(region.width), int(region.height))
    except Exception:
        return None


def _rect_primitive(x, y, width, height, color):
    coords = ((float(x), float(y)), (float(x + width), float(y)),
              (float(x + width), float(y + height)), (float(x), float(y + height)))
    return {'mode': 'TRIS', 'coords': coords, 'indices': ((0, 1, 2), (2, 3, 0)),
            'color': tuple(color), 'blend': 'ALPHA'}


def _outline_primitives(x, y, width, height, color, line_width=1.0):
    coords = ((float(x), float(y)), (float(x + width), float(y)),
              (float(x + width), float(y + height)), (float(x), float(y + height)))
    return ({'mode': 'LINE_LOOP', 'coords': coords, 'color': tuple(color),
             'blend': 'ALPHA', 'line_width': float(line_width)},)


def _build_direct_brush_packet(state):
    if not isinstance(state, dict):
        return
    x, y = tuple(state.get('mouse_xy', (0.0, 0.0)))
    radius = max(1.0, float(state.get('radius', 80.0)))
    segments = 96
    circle = tuple((x + math.cos(math.tau * i / segments) * radius,
                    y + math.sin(math.tau * i / segments) * radius)
                   for i in range(segments))
    shadow = tuple((px + 1.0, py - 1.0) for px, py in circle)
    cross = ((x - 6.0, y), (x + 6.0, y), (x, y - 6.0), (x, y + 6.0))
    color = tuple(state.get('cursor_color', (1.0, 1.0, 1.0, 0.92)))
    if state.get('last_ctrl', False):
        color = (1.0, 0.32, 0.22, 0.94)
    elif state.get('last_shift', False):
        color = (0.35, 0.58, 1.0, 0.94)
    strength = float(state.get('strength', 0.35))
    label = f"{_tool_label(state.get('active_tool', 'DRAW'))}  R:{radius:.0f}  S:{strength:.2f}"
    if state.get('adjust_mode', '') == 'RADIUS':
        label = f"{tr('brush_radius')}: {radius:.0f}"
    elif state.get('adjust_mode', '') == 'STRENGTH':
        label = f"{tr('brush_strength')}: {strength:.2f}"
    state['packet'] = _gpu_state.build_packet(
        primitives=(
            {'mode': 'LINE_LOOP', 'coords': shadow, 'color': (0.0, 0.0, 0.0, 0.45), 'line_width': 2.0},
            {'mode': 'LINE_LOOP', 'coords': circle, 'color': color, 'line_width': 2.0},
            {'mode': 'LINES', 'coords': cross, 'color': (color[0], color[1], color[2], 0.72), 'line_width': 2.0},
        ),
        texts=({'text': label, 'x': x + 12.0, 'y': y + radius + 12.0,
                'size': 12, 'color': (1.0, 1.0, 1.0, 1.0)},),
        expected_viewport=state.get('viewport'),
    )


def _build_gesture_packet(state):
    if not isinstance(state, dict):
        return
    points = tuple(tuple(float(v) for v in point[:2]) for point in state.get('points_xy', ()))
    if not points:
        state['packet'] = _gpu_state.build_packet(expected_viewport=state.get('viewport'))
        return
    shape = str(state.get('shape', 'BOX'))
    draw_points = points
    if shape == 'BOX' and len(points) >= 2:
        a, b = points[0], points[-1]
        draw_points = ((a[0], a[1]), (b[0], a[1]), (b[0], b[1]), (a[0], b[1]))
    primitive = 'LINE_LOOP' if shape in {'BOX', 'LASSO', 'POLYLINE'} and len(draw_points) > 2 else 'LINE_STRIP'
    state['packet'] = _gpu_state.build_packet(
        primitives=({'mode': primitive, 'coords': draw_points,
                     'color': (1.0, 1.0, 1.0, 0.9), 'line_width': 2.0},),
        expected_viewport=state.get('viewport'),
    )


def _rebuild_mask_overlay_packet(settings=None):
    state = _MASK_OVERLAY_STATE
    if not isinstance(state, dict):
        return
    coords = tuple(_MASK_OVERLAY_CACHE.get('coords', ()))
    if not coords or not state.get('alive', False):
        state['packet'] = _gpu_state.build_packet(expected_viewport=state.get('viewport'))
        return
    settings = settings or _settings_for_mask_runtime()
    try:
        color = tuple(float(x) for x in getattr(settings, 'mask_overlay_color', (1.0, 0.12, 0.04, 0.88)))
    except Exception:
        color = (1.0, 0.12, 0.04, 0.88)
    color = tuple((color + (1.0, 0.12, 0.04, 0.88))[:4])
    try:
        size = max(1.0, float(getattr(settings, 'mask_overlay_size', 8.0)))
    except Exception:
        size = 8.0
    state['packet'] = _gpu_state.build_packet(
        primitives=({'mode': 'POINTS', 'coords': coords, 'color': color,
                     'blend': 'ALPHA', 'depth_test': 'LESS_EQUAL', 'point_size': size},),
        expected_viewport=state.get('viewport'),
    )

def _draw_direct_brush_overlay(state):
    """Replay a completed immutable Direct Brush packet only."""
    _gpu_state.replay_state_packet(state)

def _draw_toolbar_gesture_overlay(state):
    """Replay a completed immutable gesture packet only."""
    _gpu_state.replay_state_packet(state)

def _brush_asset_blend_path():
    try:
        return os.path.join(bpy.utils.system_resource('DATAFILES', path='assets/brushes'), 'essentials_brushes-mesh_sculpt.blend')
    except Exception:
        return ''

def _brush_asset_name_from_slug(slug):
    for _tool_id, name_en, _name_ja, _sculpt_type, _operation, row_slug in STANDARD_SCULPT_BRUSH_DATA:
        if row_slug == slug:
            return name_en
    return ''

def _brush_asset_icon_value(slug):
    """Return the actual Blender bundled sculpt brush asset preview icon when available."""
    slug = (slug or '').strip()
    if not slug:
        return 0
    cached = _bounded_cache_get(_BRUSH_ASSET_ICON_CACHE, slug)
    if cached is not None:
        return cached
    name = _brush_asset_name_from_slug(slug)
    if not name:
        _bounded_cache_store(_BRUSH_ASSET_ICON_CACHE, slug, 0, _BRUSH_ASSET_ICON_CACHE_LIMIT)
        return 0
    brushes = getattr(bpy.data, 'brushes', None)
    if brushes is None:
        _bounded_cache_store(_BRUSH_ASSET_ICON_CACHE, slug, 0, _BRUSH_ASSET_ICON_CACHE_LIMIT)
        return 0
    brush = brushes.get(name)
    if brush is None:
        filepath = _brush_asset_blend_path()
        libraries = getattr(bpy.data, 'libraries', None)
        if filepath and os.path.exists(filepath) and (libraries is not None):
            try:
                with libraries.load(filepath, assets_only=True) as (data_from, data_to):
                    data_to.brushes = [name] if name in set(data_from.brushes) else []
                brush = brushes.get(name)
            except Exception:
                brush = None
    if brush is not None:
        try:
            value = int(bpy.types.UILayout.icon(brush) or 0)
        except Exception:
            value = 0
        if value:
            _bounded_cache_store(_BRUSH_ASSET_ICON_CACHE, slug, value, _BRUSH_ASSET_ICON_CACHE_LIMIT)
            return value
    _bounded_cache_store(_BRUSH_ASSET_ICON_CACHE, slug, 0, _BRUSH_ASSET_ICON_CACHE_LIMIT)
    return 0

def _icon_slug(name):
    value = (name or '').strip().lower()
    value = re.sub('[^a-z0-9]+', '_', value)
    value = re.sub('_+', '_', value).strip('_')
    return value or 'brush'
try:
    import re
except Exception:
    re = None

def _brush_label_key(tool_id):
    return 'brush_asset_' + tool_id.lower() + '_label'

def _brush_tip_key(tool_id):
    return 'brush_asset_' + tool_id.lower() + '_tip'
for _tool_id, _name_en, _name_ja, _sculpt_type, _operation, _slug in STANDARD_SCULPT_BRUSH_DATA:
    I18N['en_US'][_brush_label_key(_tool_id)] = _name_en
    I18N['ja_JP'][_brush_label_key(_tool_id)] = _name_ja
    I18N['en_US'][_brush_tip_key(_tool_id)] = _name_en + "\nStarts the Edit Mode direct brush that approximates Blender's standard Sculpt brush asset: " + _name_en + '. Paint on the mesh surface with LMB. Ctrl reverses when the operation supports it, and Shift temporarily smooths.'
    I18N['ja_JP'][_brush_tip_key(_tool_id)] = _name_ja + '\nBlender標準スカルプトブラシアセット「' + _name_ja + '」に相当する編集モード直接ブラシを開始します。メッシュ表面をLMBでなぞって使用します。対応する処理ではCtrlで反転し、Shiftで一時スムーズになります。'
    _TRANSLATION_TABLE['ja_JP']['*', _name_en] = _name_ja
    _TRANSLATION_TABLE['ja_JP']['*', I18N['en_US'][_brush_tip_key(_tool_id)]] = I18N['ja_JP'][_brush_tip_key(_tool_id)]
I18N['en_US'].update({'section_sculpt_toolbar': 'Standard Sculpt Toolbar Tools', 'section_sculpt_brush_assets': 'Standard Sculpt Brush Assets', 'active_brush': 'Active Brush', 'gesture_keys': 'LMB drag/click: define area | Ctrl: erase/invert where supported | Esc/RMB: cancel', 'gesture_finished': 'Toolbar gesture completed in Edit Mode.', 'undo_stroke': 'Undo Stroke', 'redo_stroke': 'Redo Stroke', 'tip_undo_stroke': 'One Direct Brush session creates at most one Undo step when it finishes successfully. Esc or RMB cancels the entire session and restores its starting state; Ctrl+Z and Ctrl+Y end the session safely before invoking Blender history.', 'undo_session': 'Direct Brush Session', 'undo_begin_stroke': 'Before Direct Brush Stroke', 'undo_failed': 'Undo/Redo failed.', 'popup_brush_assets': 'Open Brush Asset Popup', 'popup_sculpt_toolbar': 'Open Sculpt Toolbar Popup', 'toolbar_tool': 'Toolbar Tool', 'run_selected_toolbar_tool': 'Use Selected Toolbar Tool', 'section_shortcut_launchers': 'Keymap Registration IDs', 'shortcut_recommended_place': 'Recommended keymap location: Preferences > Keymap > 3D View > Mesh > Mesh Edit Mode', 'direct_brush_id': 'Start Direct Brush Operator ID', 'brush_popup_id': 'Brush Popup Operator ID', 'toolbar_popup_id': 'Toolbar Popup Operator ID', 'copy_operator_id': 'Copy Operator ID', 'copied_operator_id': 'Operator ID copied to clipboard.', 'popup_open_failed': 'Popup can only be opened from an interactive 3D View window.', 'menu_brush_assets': 'Brush Assets', 'menu_sculpt_toolbar': 'Sculpt Toolbar', 'brush_selected': 'Brush asset selected.', 'toolbar_selected': 'Toolbar tool selected.', 'tip_select_brush_asset': 'Select Brush Asset\nSelects the clicked standard Sculpt brush asset replacement as the active Edit Mode direct brush. If Direct Edit Brush is already running, it stays running and changes to the clicked brush instead of starting a second modal brush. If it is not running, Direct Edit Brush starts in the active 3D View.', 'tip_select_toolbar_tool': 'Select Sculpt Toolbar Tool\nSelects the clicked standard Sculpt toolbar replacement as the active toolbar tool and immediately runs Use Selected Toolbar Tool. Gesture tools start their temporary modal key handling at once; non-gesture tools execute on the current Edit Mode mesh.', 'tip_popup_brush_assets': 'Open Brush Asset Popup\nShows all standard Sculpt brush asset replacement icons immediately. The popup and icon-button backgrounds are opaque. The popup and tooltip are drawn only in the active 3D View. Hovering an icon shows a tooltip whose title starts with the function name and whose body explains the function overview. Click an icon to select it as the active Edit Mode direct brush. While Direct Edit Brush is already running, it remains active and changes to the clicked brush without restarting.', 'overlay_tooltip_overview': 'Function overview', 'overlay_tooltip_function_name': 'Function name', 'tip_popup_sculpt_toolbar': 'Open Sculpt Toolbar Popup\nShows all standard Sculpt toolbar replacement icons immediately with opaque square icon buttons in four columns. The popup and tooltip are drawn only in the active 3D View. Click an icon to select it as the active toolbar replacement and immediately run Use Selected Toolbar Tool without entering Sculpt Mode.', 'tip_toolbar_tool_prop': 'Toolbar Tool\nSelects which standard Sculpt toolbar replacement will be executed by the Use Selected Toolbar Tool button. Gesture tools start a temporary modal area selector; filter and transform tools run their Edit Mode replacement.', 'tip_run_selected_toolbar_tool': 'Use Selected Toolbar Tool\nStarts or executes the currently selected toolbar replacement. Gesture tools use LMB drag/click in the 3D View; non-gesture tools run immediately on the current Edit Mode mesh.', 'tip_copy_operator_id': "Copy Operator ID\nCopies the exact operator identifier to the clipboard so it can be pasted into Blender's keymap search or a Python keymap script.", 'section_brush_settings': 'Brush Settings', 'brush_direction': 'Direction', 'brush_hardness': 'Hardness', 'brush_normal_radius': 'Normal Radius', 'brush_auto_smooth': 'Auto Smooth', 'brush_accumulate': 'Accumulate', 'brush_plane_offset': 'Plane Offset', 'brush_stabilize_stroke': 'Stabilize Stroke', 'brush_stabilize_radius': 'Stabilize Radius', 'brush_input_samples': 'Input Samples', 'brush_use_pressure_size': 'Pen Radius', 'brush_use_pressure_strength': 'Pen Strength', 'brush_strength_hotkeys': 'Strength Hotkeys', 'brush_strength_step': 'Strength Step', 'open_falloff_pie': 'Falloff Pie', 'falloff_pie_title': 'Falloff Type', 'falloff_selected': 'Falloff type changed.', 'mask_mesh_edit_lock': 'Apply Edit Mask to Mesh Editing', 'mask_lock_threshold': 'Lock Threshold', 'mask_overlay_enabled': 'Locked Vertex Overlay', 'mask_overlay_color': 'Locked Vertex Color', 'mask_overlay_size': 'Locked Vertex Size', 'prop_brush_direction_desc': 'Direction of deformation brushes. Add pushes or applies the normal brush effect; Subtract reverses it. Ctrl while painting still temporarily inverts the chosen direction.', 'prop_brush_hardness_desc': 'Controls how much of the brush circle keeps full strength before falloff begins. Higher values make a harder center; lower values start fading near the center.', 'prop_brush_normal_radius_desc': 'Blends the hit surface normal with the averaged normals of vertices inside the brush. Increase it for broader, smoother sculpt normals; keep it low for sharper local strokes.', 'prop_brush_auto_smooth_desc': 'Applies a light tangent smoothing pass after deformation brush samples. Use this to reduce lumpy strokes while staying in Edit Mode.', 'prop_brush_accumulate_desc': 'When enabled, repeated samples build on the current stroke result. When disabled, vertices touched again in the same stroke are recalculated from their stroke-start position, closer to a non-accumulating Sculpt brush.', 'prop_brush_plane_offset_desc': 'Offsets the working plane used by flatten, fill, scrape, plane, and multiplane scrape brushes. Positive values move the plane outward along the surface normal; negative values move it inward.', 'prop_brush_stabilize_stroke_desc': 'Adds a small lazy-mouse style stabilizer while the direct brush is active. This affects only the add-on modal brush and does not install global keymaps.', 'prop_brush_stabilize_radius_desc': 'Distance in screen pixels the cursor can move before the stabilized stroke point follows. Higher values create smoother but slower strokes.', 'prop_brush_input_samples_desc': 'Multiplies the number of internal samples placed between two mouse positions. Higher values make fast strokes more continuous but cost more processing.', 'prop_brush_use_pressure_size_desc': 'Uses tablet pressure, when Blender provides it on the event, to scale the brush radius. Mouse input keeps full radius.', 'prop_brush_use_pressure_strength_desc': 'Uses tablet pressure, when Blender provides it on the event, to scale brush strength. Mouse input keeps full strength.', 'prop_brush_strength_hotkeys_desc': 'Enables the temporary strength shortcuts while Direct Brush is running. These shortcuts are handled only inside the modal brush, so normal Blender keymaps are not changed outside the brush session.', 'prop_brush_strength_step_desc': 'Amount added to or subtracted from Brush Strength by the temporary modal shortcuts such as -/+, Shift+[ ], and Ctrl+mouse wheel.', 'tip_open_falloff_pie': 'Falloff Pie\nOpens a pie menu for changing the Direct Brush falloff type while the Edit Mode direct brush is running. Press E during Direct Brush, or use this button from the panel.', 'prop_mask_mesh_edit_lock_desc': 'When enabled together with Use Edit Mask, vertices whose mask value is at or above the threshold are restored to their locked coordinates during ordinary Mesh Edit Mode operations such as gizmo transforms and proportional editing. This affects only the active edit mesh and can be turned off at any time.', 'prop_mask_lock_threshold_desc': 'Minimum Edit Mask value treated as locked for ordinary mesh editing and for the locked-vertex overlay. A value of 1.0 locks only fully masked vertices; lower values also lock softly masked vertices.', 'prop_mask_overlay_enabled_desc': 'Shows a colored 3D View overlay on vertices currently treated as locked by Edit Mask. It is an overlay only and does not change materials or saved vertex colors.', 'prop_mask_overlay_color_desc': 'Color chip used for the locked-vertex overlay. Choose a clear warning color so protected vertices are visible during editing.', 'prop_mask_overlay_size_desc': 'Screen size of the locked-vertex overlay points in the 3D View.'})
I18N['ja_JP'].update({'section_sculpt_toolbar': '標準スカルプトツールバー', 'section_sculpt_brush_assets': '標準スカルプトブラシアセット', 'active_brush': 'アクティブブラシ', 'gesture_keys': 'LMBドラッグ/クリック: 範囲指定 | Ctrl: 対応処理の消去・反転 | Esc/RMB: キャンセル', 'gesture_finished': 'ツールバー相当ジェスチャーを編集モードのまま完了しました。', 'undo_stroke': 'ストロークを取り消し', 'redo_stroke': 'ストロークをやり直し', 'tip_undo_stroke': '直接ブラシの1セッションは正常終了時に最大1つの取り消しステップだけを作成します。Escまたは右クリックではセッション全体をキャンセルして開始時の状態へ完全復元し、Ctrl+Z/Ctrl+Yはセッションを安全に終了してからBlenderの履歴を実行します。', 'undo_session': '直接ブラシセッション', 'undo_begin_stroke': '直接ブラシストローク前', 'undo_failed': '元に戻す/やり直しに失敗しました。', 'popup_brush_assets': 'ブラシアセットポップアップを開く', 'popup_sculpt_toolbar': 'ツールバーを開く', 'toolbar_tool': 'ツールバーツール', 'run_selected_toolbar_tool': '選択中のツールを使用', 'section_shortcut_launchers': 'キーマップ登録ID', 'shortcut_recommended_place': '推奨登録場所: プリファレンス > キーマップ > 3Dビュー > メッシュ > メッシュ編集モード', 'direct_brush_id': '直接ブラシ開始演算子ID', 'brush_popup_id': 'ブラシポップアップ演算子ID', 'toolbar_popup_id': 'ツールバーポップアップ演算子ID', 'copy_operator_id': '演算子IDをコピー', 'copied_operator_id': '演算子IDをクリップボードへコピーしました。', 'popup_open_failed': 'ポップアップは対話式の3Dビューウィンドウからのみ開けます。', 'menu_brush_assets': 'ブラシアセット', 'menu_sculpt_toolbar': 'スカルプトツールバー', 'brush_selected': 'ブラシアセットを選択しました。', 'toolbar_selected': 'ツールバーツールを選択しました。', 'tip_select_brush_asset': 'ブラシアセットを選択\nクリックした標準スカルプトブラシアセット相当ツールを、編集モード直接ブラシのアクティブブラシとして選択します。直接ブラシが既に起動中の場合は、二重起動せず、そのまま起動状態を維持してクリックしたブラシへ切り替えます。未起動の場合はアクティブな3Dビューで直接ブラシを開始します。', 'tip_select_toolbar_tool': 'スカルプトツールバーツールを選択\nクリックした標準スカルプトツールバー相当ツールを、アクティブなツールバーツールとして選択し、選択中のツールを即時実行します。ジェスチャーツールは一時独自キーマップをすぐ開始し、非ジェスチャーツールは現在の編集メッシュへ実行します。', 'tip_popup_brush_assets': 'ブラシアセットポップアップ\n標準スカルプトブラシアセット相当の全アイコンを不透明な背景と不透明なアイコンボタン背景で、アクティブ3Dビューにのみポップアップ表示します。各アイコンへカーソルを合わせると、機能名をタイトル、機能概要を本文にしたツールチップをアクティブ3Dビュー内の手前に表示します。アイコンをクリックすると編集モード直接ブラシとして選択します。直接ブラシが既に起動中の場合は、使用状態を維持したままクリックしたブラシへ切り替えます。未起動の場合はスカルプトモードへ切り替えずに直接ブラシを開始します。', 'overlay_tooltip_overview': '機能概要', 'overlay_tooltip_function_name': '機能名', 'tip_popup_sculpt_toolbar': 'スカルプトツールバーポップアップ\n標準スカルプトツールバー相当の全アイコンを、不透明な正方形アイコンボタン4列でアクティブ3Dビューにのみポップアップ表示します。各アイコンへカーソルを合わせるとツールチップを手前に表示し、アイコンをクリックするとスカルプトモードへ切り替えずにアクティブなツールバー相当ツールとして選択し、選択中のツールを即時実行します。', 'tip_toolbar_tool_prop': 'ツールバーツール\n「選択中のツールを使用」ボタンで実行する標準スカルプトツールバー相当ツールを選びます。ジェスチャーツールは一時的な範囲指定を開始し、フィルターや変形系は現在の編集メッシュへ実行します。', 'tip_run_selected_toolbar_tool': '選択中のツールを使用\n現在選択しているツールバー代替ツールを開始または実行します。ジェスチャーツールは3Dビュー上でLMBドラッグ/クリックを使い、非ジェスチャーツールは現在の編集メッシュへ即時実行します。', 'tip_copy_operator_id': '演算子IDをコピー\nBlenderのキーマップ検索やPythonキーマップスクリプトへ貼り付けられるよう、正確な演算子IDをクリップボードへコピーします。', 'section_brush_settings': 'ブラシ設定', 'brush_direction': '方向', 'brush_hardness': '硬さ', 'brush_normal_radius': '法線半径', 'brush_auto_smooth': '自動スムーズ', 'brush_accumulate': '蓄積', 'brush_plane_offset': '平面オフセット', 'brush_stabilize_stroke': 'ストローク安定化', 'brush_stabilize_radius': '安定化半径', 'brush_input_samples': '入力サンプル', 'brush_use_pressure_size': '筆圧半径', 'brush_use_pressure_strength': '筆圧強さ', 'brush_strength_hotkeys': '強さキー操作', 'brush_strength_step': '強さ変更量', 'open_falloff_pie': 'フォールオフパイ', 'falloff_pie_title': 'フォールオフタイプ', 'falloff_selected': 'フォールオフタイプを変更しました。', 'mask_mesh_edit_lock': '編集マスクを通常編集にも適用', 'mask_lock_threshold': 'ロックしきい値', 'mask_overlay_enabled': 'ロック頂点オーバーレイ', 'mask_overlay_color': 'ロック頂点カラー', 'mask_overlay_size': 'ロック頂点サイズ', 'prop_brush_direction_desc': '変形ブラシの方向を指定します。追加は通常のブラシ効果で押し出し・適用し、減算は効果を反転します。ストローク中にCtrlを押すと、選択中の方向を一時的に反転できます。', 'prop_brush_hardness_desc': 'ブラシ円の内側で最大強度を保つ範囲を調整します。値を高くすると中心が硬いブラシになり、低くすると中心付近からなだらかに減衰します。', 'prop_brush_normal_radius_desc': 'ヒットした面の法線と、ブラシ内頂点の平均法線をどの程度混ぜるかを設定します。大きくすると広い面に沿った滑らかな法線で変形し、小さくすると局所的でシャープなストロークになります。', 'prop_brush_auto_smooth_desc': '変形ブラシのサンプル後に軽い接線方向スムーズを追加します。編集モードのまま、ストロークの凹凸を抑えたい場合に使います。', 'prop_brush_accumulate_desc': '有効にすると同じストローク内の連続サンプルが現在の結果へ積み重なります。無効にすると、同じ頂点に再度触れたときストローク開始時の位置から再計算し、非蓄積ブラシに近い挙動になります。', 'prop_brush_plane_offset_desc': 'フラット化、フィル、スクレイプ、プレーン、マルチプレーンスクレイプ系ブラシが使う作業平面をずらします。正の値は表面法線方向の外側へ、負の値は内側へ平面を移動します。', 'prop_brush_stabilize_stroke_desc': '直接ブラシ実行中だけ、レイジーマウス風のストローク安定化を追加します。アドオンのモーダルブラシ内だけで働き、グローバルキーマップは変更しません。', 'prop_brush_stabilize_radius_desc': '安定化されたストローク点が追従し始めるまでの画面ピクセル距離です。大きいほど滑らかになりますが、追従は遅くなります。', 'prop_brush_input_samples_desc': 'マウス位置の間に配置する内部サンプル数を増やします。値を高くすると高速ストロークが途切れにくくなりますが、処理負荷は増えます。', 'prop_brush_use_pressure_size_desc': 'Blenderがイベントに筆圧を渡している場合、筆圧でブラシ半径を拡縮します。マウス入力では通常の半径のままです。', 'prop_brush_use_pressure_strength_desc': 'Blenderがイベントに筆圧を渡している場合、筆圧でブラシ強さを拡縮します。マウス入力では通常の強さのままです。', 'prop_brush_strength_hotkeys_desc': '直接ブラシ実行中だけ一時的な強さ変更ショートカットを有効化します。この処理はモーダルブラシ内だけで処理されるため、ブラシを終了すると通常のBlenderキーマップには影響しません。', 'prop_brush_strength_step_desc': '-/+、Shift+[ ]、Ctrl+マウスホイールなどの一時ショートカットで、ブラシ強さを一回あたり増減する量です。', 'tip_open_falloff_pie': 'フォールオフパイ\n編集モード直接ブラシの実行中に、フォールオフタイプを変更するパイメニューを開きます。直接ブラシ中はEキー、このパネルからはボタンで開けます。', 'prop_mask_mesh_edit_lock_desc': '編集マスクを使用と併用すると、マスク値がしきい値以上の頂点を通常のメッシュ編集でもロック座標へ戻します。ギズモ移動、回転、拡縮、プロポーショナル編集などで保護したい頂点に使います。対象はアクティブな編集メッシュだけで、いつでも無効化できます。', 'prop_mask_lock_threshold_desc': '通常編集のロックとロック頂点オーバーレイに使う編集マスク値の下限です。1.0では完全にマスクされた頂点だけをロックし、低い値では柔らかくマスクされた頂点もロック対象になります。', 'prop_mask_overlay_enabled_desc': '編集マスクでロック扱いになっている頂点に、3Dビュー上で色付きオーバーレイを表示します。表示専用で、マテリアルや保存される頂点カラーは変更しません。', 'prop_mask_overlay_color_desc': 'ロック頂点オーバーレイに使うカラーチップです。保護中の頂点が見分けやすい警告色を指定してください。', 'prop_mask_overlay_size_desc': '3Dビュー上に表示するロック頂点オーバーレイ点の画面サイズです。'})
_TRANSLATION_TABLE['ja_JP'].update({('*', 'Standard Sculpt Toolbar Tools'): I18N['ja_JP']['section_sculpt_toolbar'], ('*', 'Standard Sculpt Brush Assets'): I18N['ja_JP']['section_sculpt_brush_assets'], ('*', 'Active Brush'): I18N['ja_JP']['active_brush'], ('*', 'Open Brush Asset Popup'): I18N['ja_JP']['popup_brush_assets'], ('*', 'Open Sculpt Toolbar Popup'): I18N['ja_JP']['popup_sculpt_toolbar'], ('*', 'Toolbar Tool'): I18N['ja_JP']['toolbar_tool'], ('*', 'Use Selected Toolbar Tool'): I18N['ja_JP']['run_selected_toolbar_tool'], ('*', 'Keymap Registration IDs'): I18N['ja_JP']['section_shortcut_launchers'], ('*', 'Start Direct Brush Operator ID'): I18N['ja_JP']['direct_brush_id'], ('*', 'Brush Popup Operator ID'): I18N['ja_JP']['brush_popup_id'], ('*', 'Toolbar Popup Operator ID'): I18N['ja_JP']['toolbar_popup_id'], ('*', 'Copy Operator ID'): I18N['ja_JP']['copy_operator_id'], ('*', 'Brush Asset Popup'): I18N['ja_JP']['menu_brush_assets'], ('*', 'Sculpt Toolbar Popup'): I18N['ja_JP']['menu_sculpt_toolbar'], ('*', I18N['en_US']['tip_undo_stroke']): I18N['ja_JP']['tip_undo_stroke'], ('*', I18N['en_US']['tip_popup_brush_assets']): I18N['ja_JP']['tip_popup_brush_assets'], ('*', I18N['en_US']['tip_popup_sculpt_toolbar']): I18N['ja_JP']['tip_popup_sculpt_toolbar'], ('*', I18N['en_US']['tip_toolbar_tool_prop']): I18N['ja_JP']['tip_toolbar_tool_prop'], ('*', I18N['en_US']['tip_run_selected_toolbar_tool']): I18N['ja_JP']['tip_run_selected_toolbar_tool'], ('*', 'Brush Assets'): I18N['ja_JP']['menu_brush_assets'], ('*', 'Sculpt Toolbar'): I18N['ja_JP']['menu_sculpt_toolbar'], ('*', I18N['en_US']['tip_copy_operator_id']): I18N['ja_JP']['tip_copy_operator_id'], ('*', I18N['en_US']['tip_select_brush_asset']): I18N['ja_JP']['tip_select_brush_asset'], ('*', I18N['en_US']['tip_select_toolbar_tool']): I18N['ja_JP']['tip_select_toolbar_tool'], ('*', 'Brush Settings'): I18N['ja_JP']['section_brush_settings'], ('*', 'Direction'): I18N['ja_JP']['brush_direction'], ('*', 'Add'): '追加', ('*', 'Subtract'): '減算', ('*', 'Hardness'): I18N['ja_JP']['brush_hardness'], ('*', 'Normal Radius'): I18N['ja_JP']['brush_normal_radius'], ('*', 'Auto Smooth'): I18N['ja_JP']['brush_auto_smooth'], ('*', 'Accumulate'): I18N['ja_JP']['brush_accumulate'], ('*', 'Plane Offset'): I18N['ja_JP']['brush_plane_offset'], ('*', 'Stabilize Stroke'): I18N['ja_JP']['brush_stabilize_stroke'], ('*', 'Stabilize Radius'): I18N['ja_JP']['brush_stabilize_radius'], ('*', 'Input Samples'): I18N['ja_JP']['brush_input_samples'], ('*', 'Pressure Radius'): I18N['ja_JP']['brush_use_pressure_size'], ('*', 'Pressure Strength'): I18N['ja_JP']['brush_use_pressure_strength'], ('*', 'Strength Hotkeys'): I18N['ja_JP']['brush_strength_hotkeys'], ('*', 'Strength Step'): I18N['ja_JP']['brush_strength_step'], ('*', 'Falloff Pie'): I18N['ja_JP']['open_falloff_pie'], ('*', 'Falloff Type'): I18N['ja_JP']['falloff_pie_title'], ('*', 'Apply Edit Mask to Mesh Editing'): I18N['ja_JP']['mask_mesh_edit_lock'], ('*', 'Lock Threshold'): I18N['ja_JP']['mask_lock_threshold'], ('*', 'Locked Vertex Overlay'): I18N['ja_JP']['mask_overlay_enabled'], ('*', 'Locked Vertex Color'): I18N['ja_JP']['mask_overlay_color'], ('*', 'Locked Vertex Size'): I18N['ja_JP']['mask_overlay_size'], ('*', I18N['en_US']['prop_brush_direction_desc']): I18N['ja_JP']['prop_brush_direction_desc'], ('*', I18N['en_US']['prop_brush_hardness_desc']): I18N['ja_JP']['prop_brush_hardness_desc'], ('*', I18N['en_US']['prop_brush_normal_radius_desc']): I18N['ja_JP']['prop_brush_normal_radius_desc'], ('*', I18N['en_US']['prop_brush_auto_smooth_desc']): I18N['ja_JP']['prop_brush_auto_smooth_desc'], ('*', I18N['en_US']['prop_brush_accumulate_desc']): I18N['ja_JP']['prop_brush_accumulate_desc'], ('*', I18N['en_US']['prop_brush_plane_offset_desc']): I18N['ja_JP']['prop_brush_plane_offset_desc'], ('*', I18N['en_US']['prop_brush_stabilize_stroke_desc']): I18N['ja_JP']['prop_brush_stabilize_stroke_desc'], ('*', I18N['en_US']['prop_brush_stabilize_radius_desc']): I18N['ja_JP']['prop_brush_stabilize_radius_desc'], ('*', I18N['en_US']['prop_brush_input_samples_desc']): I18N['ja_JP']['prop_brush_input_samples_desc'], ('*', I18N['en_US']['prop_brush_use_pressure_size_desc']): I18N['ja_JP']['prop_brush_use_pressure_size_desc'], ('*', I18N['en_US']['prop_brush_use_pressure_strength_desc']): I18N['ja_JP']['prop_brush_use_pressure_strength_desc'], ('*', I18N['en_US']['prop_brush_strength_hotkeys_desc']): I18N['ja_JP']['prop_brush_strength_hotkeys_desc'], ('*', I18N['en_US']['prop_brush_strength_step_desc']): I18N['ja_JP']['prop_brush_strength_step_desc'], ('*', I18N['en_US']['tip_open_falloff_pie']): I18N['ja_JP']['tip_open_falloff_pie'], ('*', I18N['en_US']['prop_mask_mesh_edit_lock_desc']): I18N['ja_JP']['prop_mask_mesh_edit_lock_desc'], ('*', I18N['en_US']['prop_mask_lock_threshold_desc']): I18N['ja_JP']['prop_mask_lock_threshold_desc'], ('*', I18N['en_US']['prop_mask_overlay_enabled_desc']): I18N['ja_JP']['prop_mask_overlay_enabled_desc'], ('*', I18N['en_US']['prop_mask_overlay_color_desc']): I18N['ja_JP']['prop_mask_overlay_color_desc'], ('*', I18N['en_US']['prop_mask_overlay_size_desc']): I18N['ja_JP']['prop_mask_overlay_size_desc']})
for _tool_id, _name_en, _name_ja, _icon_handle, _action, _shape in STANDARD_SCULPT_TOOLBAR_DATA:
    I18N['en_US']['toolbar_' + _tool_id.lower()] = _name_en
    I18N['ja_JP']['toolbar_' + _tool_id.lower()] = _name_ja
    I18N['en_US']['toolbar_tip_' + _tool_id.lower()] = _name_en + "\nEdit Mode replacement for Blender's Sculpt toolbar tool: " + _name_en + ". The tool uses the same bundled toolbar icon and runs only while this add-on's modal operator is active."
    I18N['ja_JP']['toolbar_tip_' + _tool_id.lower()] = _name_ja + '\nBlender標準スカルプトツールバーの「' + _name_ja + '」に相当する編集モード代替ツールです。標準搭載の同系統アイコンを使用し、このアドオンのモーダル処理中だけ動作します。'
    _TRANSLATION_TABLE['ja_JP']['*', _name_en] = _name_ja
    _TRANSLATION_TABLE['ja_JP']['*', I18N['en_US']['toolbar_tip_' + _tool_id.lower()]] = I18N['ja_JP']['toolbar_tip_' + _tool_id.lower()]

def _preview_collection():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        try:
            from bpy.utils import previews as _previews
            collection = _previews.new()

            def _remove_preview(value):
                _previews.remove(value)
            _lifecycle.acquire_resource('preview_collection', collection, _remove_preview, native_remover=_previews.remove)
            _PREVIEW_COLLECTION = collection
        except Exception as exc:
            _runtime_errors.record('preview_collection', exc)
            _PREVIEW_COLLECTION = False
    return _PREVIEW_COLLECTION if _PREVIEW_COLLECTION is not False else None

def _resolve_brush_preview_icon_value(slug):
    pcoll = _preview_collection()
    if pcoll is None:
        return 0
    slug = (slug or 'generic').strip()
    key = 'brush_' + slug
    item = pcoll.get(key)
    if item is not None:
        return item.icon_id
    icon_dir = os.path.join(os.path.dirname(__file__), 'icons')
    candidates = [os.path.join(icon_dir, key + '.png'), os.path.join(icon_dir, slug + '.png')]
    filepath = next((candidate for candidate in candidates if os.path.exists(candidate)), '')
    if not filepath:
        return 0
    try:
        item = pcoll.load(key, filepath, 'IMAGE')
        return item.icon_id
    except Exception:
        return 0

def _resolve_popup_preview_icon_value(slug, variant='brush'):
    """Return a popup thumbnail icon sized for the requested launcher."""
    pcoll = _preview_collection()
    if pcoll is None:
        return 0
    slug = (slug or 'generic').strip()
    variant = 'toolbar' if variant == 'toolbar' else 'brush'
    key = 'popup_%s_%s_v137' % (variant, slug)
    item = pcoll.get(key)
    if item is not None:
        return item.icon_id
    base_dir = os.path.dirname(__file__)
    primary_dir = 'icons_popup_toolbar' if variant == 'toolbar' else 'icons_popup_brush'
    search_dirs = [os.path.join(base_dir, primary_dir), os.path.join(base_dir, 'icons')]
    candidates = []
    for icon_dir in search_dirs:
        candidates.append(os.path.join(icon_dir, slug + '.png'))
        candidates.append(os.path.join(icon_dir, 'brush_' + slug + '.png'))
    filepath = next((candidate for candidate in candidates if os.path.exists(candidate)), '')
    if not filepath:
        return 0
    try:
        item = pcoll.load(key, filepath, 'IMAGE')
        return item.icon_id
    except Exception:
        return 0

def _brush_preview_icon_value(slug):
    """Hot-path lookup only; preview loading is performed by _warm_preview_icons()."""
    pcoll = _PREVIEW_COLLECTION if _PREVIEW_COLLECTION not in (None, False) else None
    if pcoll is None:
        return 0
    key = 'brush_' + str(slug or 'generic').strip()
    try:
        item = pcoll.get(key)
        return int(getattr(item, 'icon_id', 0) or 0) if item is not None else 0
    except Exception:
        return 0

def _popup_preview_icon_value(slug, variant='brush'):
    """Hot-path lookup only; never performs filesystem or preview collection I/O."""
    pcoll = _PREVIEW_COLLECTION if _PREVIEW_COLLECTION not in (None, False) else None
    if pcoll is None:
        return 0
    variant = 'toolbar' if variant == 'toolbar' else 'brush'
    key = 'popup_%s_%s_v137' % (variant, str(slug or 'generic').strip())
    try:
        item = pcoll.get(key)
        return int(getattr(item, 'icon_id', 0) or 0) if item is not None else 0
    except Exception:
        return 0

def _tool_icon_value(icon_handle):
    """Hot-path lookup only; tool-system icon resolution is prewarmed outside draw."""
    if not icon_handle:
        return 0
    cached = _bounded_cache_get(_TOOL_ICON_CACHE, icon_handle)
    return int(cached or 0) if cached is not None else 0

def _popup_icon_value(icon_spec, variant='brush'):
    """Return an icon value suitable for popup icon-only selector buttons."""
    if not icon_spec or not isinstance(icon_spec, str):
        return 0
    if icon_spec.startswith('preview:'):
        slug = icon_spec.split(':', 1)[1]
        return _popup_preview_icon_value(slug, variant) or _brush_preview_icon_value(slug)
    if icon_spec.startswith('popup:'):
        slug = icon_spec.split(':', 1)[1]
        return _popup_preview_icon_value(slug, variant) or _brush_preview_icon_value(slug)
    if '.' in icon_spec:
        return _tool_icon_value(icon_spec)
    return 0

def _warm_preview_icons():
    slugs = set()
    for _tool_id, _name_en, _name_ja, _sculpt_type, _operation, slug in STANDARD_SCULPT_BRUSH_DATA:
        slugs.add(slug)
    for _op_id, _label_key, _tip_key, icon in _operation_items() + _filter_items():
        if isinstance(icon, str) and icon.startswith('preview:'):
            slugs.add(icon.split(':', 1)[1])
    slugs.update({'paint_select', 'mask', 'face_set_paint', 'paint'})
    for slug in sorted(slugs):
        try:
            _resolve_brush_preview_icon_value(slug)
            _resolve_popup_preview_icon_value(slug, 'brush')
            _resolve_popup_preview_icon_value(slug, 'toolbar')
        except Exception:
            pass
    for _tool_id, _name_en, _name_ja, icon_handle, _action, _shape in STANDARD_SCULPT_TOOLBAR_DATA:
        try:
            _resolve_tool_icon_value(icon_handle)
        except Exception:
            pass

def _resolve_tool_icon_value(icon_handle):
    if not icon_handle:
        return 0
    cached = _bounded_cache_get(_TOOL_ICON_CACHE, icon_handle)
    if cached is not None:
        return cached
    value = 0
    try:
        from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
        value = ToolSelectPanelHelper._icon_value_from_icon_handle(icon_handle)
    except Exception:
        value = 0
    _bounded_cache_store(_TOOL_ICON_CACHE, icon_handle, value, _TOOL_ICON_CACHE_LIMIT)
    return value

def _ui_icon_value(icon_spec):
    if not icon_spec or not isinstance(icon_spec, str):
        return 0
    if icon_spec.startswith('preview:'):
        slug = icon_spec.split(':', 1)[1]
        return _brush_preview_icon_value(slug)
    if '.' in icon_spec:
        return _tool_icon_value(icon_spec)
    return 0

def _brush_operation(tool_id):
    for _tid, _name_en, _name_ja, _sculpt_type, _operation, _slug in STANDARD_SCULPT_BRUSH_DATA:
        if _tid == tool_id:
            return _operation
    return tool_id

def _brush_slug(tool_id):
    for _tid, _name_en, _name_ja, _sculpt_type, _operation, _slug in STANDARD_SCULPT_BRUSH_DATA:
        if _tid == tool_id:
            return _slug
    return 'generic'

def _brush_is_boundary_limited(tool_id):
    return tool_id in {'BOUNDARY', 'BEND_BOUNDARY_CLOTH', 'TWIST_BOUNDARY_CLOTH'}

def _toolbar_item(tool_id):
    for item in STANDARD_SCULPT_TOOLBAR_DATA:
        if item[0] == tool_id:
            return item
    return None

def _toolbar_display_items():
    """Return toolbar items with brush-asset duplicates removed.

    Brush-like sculpt tools live in the Standard Sculpt Brush Assets section.
    The toolbar section keeps gesture, filter and transform tools only, while
    still removing exact duplicate identifiers defensively.
    """
    brush_ids = {item[0] for item in _direct_brush_items()}
    shown = set()
    result = []
    for item in STANDARD_SCULPT_TOOLBAR_DATA:
        tool_id = item[0]
        if tool_id in shown or tool_id in brush_ids:
            continue
        shown.add(tool_id)
        result.append(item)
    return result

def _locale():
    loc = getattr(bpy.app.translations, 'locale', 'en_US') or 'en_US'
    return 'ja_JP' if loc.startswith('ja') else 'en_US'

def tr(key):
    return I18N.get(_locale(), I18N['en_US']).get(key, I18N['en_US'].get(key, key))

def _enum_text(key):
    """Static EnumProperty text: always the English source, translated by Blender at draw time."""
    return I18N['en_US'].get(key, I18N['ja_JP'].get(key, key))

def _register_enum_text_pair(key):
    english = I18N['en_US'].get(key)
    japanese = I18N['ja_JP'].get(key)
    if english and japanese and english != japanese:
        _TRANSLATION_TABLE['ja_JP'].setdefault(('*', english), japanese)

def _ensure_edit_mesh(context):
    obj = getattr(context, 'edit_object', None) or context.view_layer.objects.active
    if obj and obj.type == 'MESH' and (obj.mode == 'EDIT'):
        return obj
    return None

def _push_undo_checkpoint(message):
    """Compatibility no-op: Blender owns the single Operator Undo step."""
    return True

def _gesture_undo_mesh_data_key(mesh):
    return None

def _gesture_undo_mesh_key(obj):
    return None

def _prune_gesture_undo_baselines():
    _GESTURE_UNDO_BASELINED_MESHES.clear()

def _ensure_gesture_undo_baseline(obj, message):
    return True

def _reset_gesture_undo_baselines_on_load(_filepath=None, *_args):
    _GESTURE_UNDO_BASELINED_MESHES.clear()

def _register_gesture_undo_load_handler():
    return None

def _unregister_gesture_undo_load_handler():
    global _GESTURE_UNDO_LOAD_HANDLER
    _GESTURE_UNDO_LOAD_HANDLER = None
    _GESTURE_UNDO_BASELINED_MESHES.clear()

def _settings(context):
    return context.scene.strict_edit_mode_sculpt_settings

def _selected_verts(bm, settings):
    verts = [v for v in bm.verts if v.select and (not v.hide)]
    if not verts and settings.affect_visible_when_none:
        verts = [v for v in bm.verts if not v.hide]
    return verts

def _selected_faces(bm, settings):
    faces = [f for f in bm.faces if f.select and (not f.hide)]
    if not faces and settings.affect_visible_when_none:
        faces = [f for f in bm.faces if not f.hide]
    return faces

def _selected_edges(bm, settings):
    edges = [e for e in bm.edges if e.select and (not e.hide)]
    if not edges and settings.affect_visible_when_none:
        edges = [e for e in bm.edges if not e.hide]
    return edges

def _center(verts):
    if not verts:
        return Vector((0.0, 0.0, 0.0))
    c = Vector((0.0, 0.0, 0.0))
    for v in verts:
        c += v.co
    return c / len(verts)

def _average_normal(verts):
    n = Vector((0.0, 0.0, 0.0))
    for v in verts:
        n += v.normal
    if n.length_squared < 1e-12:
        return Vector((0.0, 0.0, 1.0))
    n.normalize()
    return n

def _mask_layer(bm, create=False):
    layer = bm.verts.layers.float.get(MASK_LAYER_NAME)
    if layer is None and create:
        layer = bm.verts.layers.float.new(MASK_LAYER_NAME)
    return layer

def _face_set_layer(bm, create=False):
    layer = bm.faces.layers.int.get(FACE_SET_LAYER_NAME)
    if layer is None and create:
        layer = bm.faces.layers.int.new(FACE_SET_LAYER_NAME)
    return layer

def _color_layer(bm, create=False):
    layer = bm.loops.layers.float_color.get(COLOR_LAYER_NAME)
    if layer is None and create:
        layer = bm.loops.layers.float_color.new(COLOR_LAYER_NAME)
    return layer

def _influence(v, settings, mask_layer):
    if settings.use_mask and mask_layer is not None:
        try:
            return max(0.0, min(1.0, 1.0 - float(v[mask_layer])))
        except Exception:
            return 1.0
    return 1.0
_MIRROR_IDENTITY_SIGN = (1.0, 1.0, 1.0)

def _mesh_mirror_axes(obj):
    """Return the active Blender Mesh mirror flags used by the 3D View header.

    Mesh.use_mirror_x/y/z are the standard Edit Mode mirror toggles exposed in
    Blender's top-right 3D View mesh options.  The add-on's bmesh based sculpt
    replacements bypass native transform operators, so the enabled axes are
    applied explicitly in local object space.
    """
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return (False, False, False)
    return (bool(getattr(mesh, 'use_mirror_x', False)), bool(getattr(mesh, 'use_mirror_y', False)), bool(getattr(mesh, 'use_mirror_z', False)))

def _mesh_mirror_enabled(obj):
    return any(_mesh_mirror_axes(obj))

def _mirror_sign_combinations(obj, include_identity=False):
    axes = _mesh_mirror_axes(obj)
    signs = [_MIRROR_IDENTITY_SIGN]
    for axis_index, enabled in enumerate(axes):
        if not enabled:
            continue
        next_signs = []
        for sign in signs:
            next_signs.append(sign)
            mirrored = list(sign)
            mirrored[axis_index] *= -1.0
            next_signs.append(tuple(mirrored))
        signs = next_signs
    result = []
    seen = set()
    for sign in signs:
        key = (int(sign[0]), int(sign[1]), int(sign[2]))
        if key in seen:
            continue
        seen.add(key)
        if include_identity or key != (1, 1, 1):
            result.append((float(key[0]), float(key[1]), float(key[2])))
    return result

def _mirror_vector(value, sign):
    return Vector((float(value.x) * sign[0], float(value.y) * sign[1], float(value.z) * sign[2]))

def _mirror_determinant(sign):
    return float(sign[0] * sign[1] * sign[2])

def _mirror_rotation_axis(axis, sign):
    mirrored = _mirror_vector(axis, sign)
    if _mirror_determinant(sign) < 0.0:
        mirrored.negate()
    return mirrored

def _mirror_coords_from_bmesh(bm):
    bm.verts.ensure_lookup_table()
    bm.verts.index_update()
    return {v.index: v.co.copy() for v in bm.verts if not v.hide and v.index >= 0}

def _mirror_tolerance_from_coords(coords):
    values = list(coords.values()) if isinstance(coords, dict) else []
    if not values:
        return 1e-05
    min_v = Vector((min((v.x for v in values)), min((v.y for v in values)), min((v.z for v in values))))
    max_v = Vector((max((v.x for v in values)), max((v.y for v in values)), max((v.z for v in values))))
    diagonal = (max_v - min_v).length
    return min(max(1e-05, diagonal * 1e-05), 0.01)

def _mirror_lookup_from_coords(coords):
    if not coords:
        return (None, 0.0)
    try:
        kd = KDTree(len(coords))
        for index, co in coords.items():
            kd.insert(co, int(index))
        kd.balance()
        return (kd, _mirror_tolerance_from_coords(coords))
    except Exception:
        return (None, 0.0)

def _mirror_find_index(kd, coords, target_co, tolerance):
    if kd is None:
        return None
    try:
        _loc, index, distance = kd.find(target_co)
    except Exception:
        return None
    try:
        index = int(index)
    except Exception:
        return None
    if index not in coords:
        return None
    if float(distance) <= max(float(tolerance), 1e-08):
        return index
    return None

def _mirror_direct_target_groups(obj, bm, source_targets, before_coords=None, skip_source=True):
    """Build target groups for mirrored direct-brush samples.

    Each group contains the bmesh vertices that correspond to the source targets
    mirrored across one active X/Y/Z combination, while preserving the original
    brush weights.  Mapping is based on pre-stroke local coordinates so the
    lookup remains stable after the original side is modified.
    """
    signs = _mirror_sign_combinations(obj)
    if not signs or not source_targets:
        return []
    coords = before_coords if isinstance(before_coords, dict) else _mirror_coords_from_bmesh(bm)
    kd, tolerance = _mirror_lookup_from_coords(coords)
    if kd is None:
        return []
    source_indices = {v.index for v, _w in source_targets if getattr(v, 'index', -1) >= 0}
    groups = []
    bm.verts.ensure_lookup_table()
    for sign in signs:
        mapped = {}
        for v, weight in source_targets:
            index = getattr(v, 'index', -1)
            if index < 0 or index not in coords:
                continue
            mirrored_index = _mirror_find_index(kd, coords, _mirror_vector(coords[index], sign), tolerance)
            if mirrored_index is None:
                continue
            if skip_source and mirrored_index in source_indices:
                continue
            if mirrored_index < 0 or mirrored_index >= len(bm.verts):
                continue
            mv = bm.verts[mirrored_index]
            if mv.hide:
                continue
            mapped[mv] = max(float(weight), mapped.get(mv, 0.0))
        if mapped:
            groups.append((sign, list(mapped.items())))
    return groups

def _mirror_drag_target_groups(obj, bm, source_targets, before_coords=None):
    groups = []
    for sign, targets in _mirror_direct_target_groups(obj, bm, source_targets, before_coords=before_coords, skip_source=True):
        drag_targets = []
        for v, weight in targets:
            co = None
            try:
                co = before_coords.get(v.index) if isinstance(before_coords, dict) else None
            except Exception:
                co = None
            drag_targets.append((v, weight, co.copy() if co is not None else v.co.copy()))
        if drag_targets:
            groups.append((sign, drag_targets))
    return groups

def _mirror_expand_verts(obj, bm, verts):
    verts = list(verts or [])
    if not _mesh_mirror_enabled(obj) or not verts:
        return verts
    coords = _mirror_coords_from_bmesh(bm)
    kd, tolerance = _mirror_lookup_from_coords(coords)
    if kd is None:
        return verts
    result = list(verts)
    seen = {v.index for v in result if getattr(v, 'index', -1) >= 0}
    bm.verts.ensure_lookup_table()
    for sign in _mirror_sign_combinations(obj):
        for v in verts:
            index = getattr(v, 'index', -1)
            if index < 0 or index not in coords:
                continue
            mirrored_index = _mirror_find_index(kd, coords, _mirror_vector(coords[index], sign), tolerance)
            if mirrored_index is None or mirrored_index in seen:
                continue
            if 0 <= mirrored_index < len(bm.verts):
                mv = bm.verts[mirrored_index]
                if not mv.hide:
                    result.append(mv)
                    seen.add(mirrored_index)
    return result

def _mirror_expand_faces(obj, bm, faces):
    faces = list(faces or [])
    if not _mesh_mirror_enabled(obj) or not faces:
        return faces
    source_verts = []
    for f in faces:
        if not f.hide:
            source_verts.extend([v for v in f.verts if not v.hide])
    mirrored_verts = set(_mirror_expand_verts(obj, bm, source_verts))
    bm.faces.ensure_lookup_table()
    bm.faces.index_update()
    result = list(faces)
    seen = {f.index for f in result if getattr(f, 'index', -1) >= 0}
    for f in bm.faces:
        if f.hide or f.index in seen:
            continue
        if any((v in mirrored_verts for v in f.verts)):
            result.append(f)
            seen.add(f.index)
    return result

def _mirror_expand_verts_faces(obj, bm, verts, faces):
    expanded_verts = _mirror_expand_verts(obj, bm, verts)
    expanded_faces = _mirror_expand_faces(obj, bm, faces)
    if expanded_verts and (not expanded_faces):
        vset = set(expanded_verts)
        expanded_faces = [f for f in bm.faces if not f.hide and any((v in vset for v in f.verts))]
    return (expanded_verts, expanded_faces)

def _mirror_changed_vertex_coordinates(obj, bm, before_coords, source_verts=None, lookup=None):
    """Copy coordinate results to Blender standard mirror counterparts.

    This is used for selection based bmesh sculpt operations whose output is a
    final vertex coordinate set.  It mirrors the result from the operated side
    instead of re-running the algorithm, matching the Edit Mode mirror behavior
    expected from Blender's standard X/Y/Z toggles.
    """
    signs = _mirror_sign_combinations(obj)
    if not signs or not isinstance(before_coords, dict) or (not before_coords):
        return 0
    kd, tolerance = lookup if lookup is not None else _mirror_lookup_from_coords(before_coords)
    if kd is None:
        return 0
    bm.verts.ensure_lookup_table()
    if source_verts:
        source_indices = [v.index for v in source_verts if getattr(v, 'index', -1) in before_coords]
    else:
        source_indices = []
        for index, old in before_coords.items():
            if 0 <= index < len(bm.verts) and (bm.verts[index].co - old).length_squared > 1e-18:
                source_indices.append(index)
    proposals = {}
    for index in source_indices:
        if index not in before_coords or index < 0 or index >= len(bm.verts):
            continue
        old = before_coords[index]
        new = bm.verts[index].co.copy()
        if (new - old).length_squared <= 1e-18:
            continue
        for sign in signs:
            mirrored_index = _mirror_find_index(kd, before_coords, _mirror_vector(old, sign), tolerance)
            # A vertex on the mirror plane maps to itself: averaging it with its own
            # mirrored result keeps it on the plane.
            if mirrored_index is None:
                continue
            if 0 <= mirrored_index < len(bm.verts) and (not bm.verts[mirrored_index].hide):
                proposals.setdefault(mirrored_index, []).append(_mirror_vector(new, sign))
    # A vertex whose counterpart is also a source keeps its own result in the
    # average; replacing it with the counterpart alone swaps the two sides and
    # leaves them asymmetric when a stroke crosses the mirror plane.
    source_set = set(source_indices)
    for index, values in proposals.items():
        if index in source_set and index in before_coords and (bm.verts[index].co - before_coords[index]).length_squared > 1e-18:
            values.append(bm.verts[index].co.copy())
    changed = 0
    for index, values in proposals.items():
        if not values or index < 0 or index >= len(bm.verts):
            continue
        target = Vector((0.0, 0.0, 0.0))
        for value in values:
            target += value
        target /= len(values)
        if (bm.verts[index].co - target).length_squared > 1e-18:
            bm.verts[index].co = target
            changed += 1
    if changed:
        bm.normal_update()
    return changed
_MASK_LOCK_ANCHORS = {}
_MASK_LOCK_TIMER_REGISTERED = False
_MASK_RUNTIME_HANDLER_REGISTERED = False
_MASK_RUNTIME_HANDLER = None
_MASK_RUNTIME_DIRTY = False
_MASK_RUNTIME_PROCESSING = False
_MASK_RUNTIME_ACTIVE_KEY = None
_MASK_OVERLAY_HANDLE = None
_MASK_OVERLAY_STATE = {'alive': True}
_MASK_OVERLAY_SHADER = None
_MASK_OVERLAY_POINT_LIMIT = 500000
_MASK_LOCK_ANCHOR_LIMIT = 1000000
_MASK_OVERLAY_CACHE = {'object_key': None, 'coords': (), 'revision': 0, 'batch_revision': -1, 'batch': None, 'source_count': 0, 'truncated': False}

def _mask_lock_key(obj):
    try:
        return (int(obj.as_pointer()), int(obj.data.as_pointer()))
    except Exception:
        return None

def _masked_vertex_value(v, layer):
    if layer is None:
        return 0.0
    try:
        return _clamp(float(v[layer]))
    except Exception:
        return 0.0

def _mask_lock_settings_enabled(settings=None):
    settings = settings or _settings_for_mask_runtime()
    if settings is None:
        return False
    return bool(getattr(settings, 'use_mask', False)) and bool(getattr(settings, 'use_mask_for_mesh_editing', False))

def _mask_overlay_settings_enabled(settings=None):
    settings = settings or _settings_for_mask_runtime()
    if settings is None:
        return False
    return bool(getattr(settings, 'use_mask', False)) and bool(getattr(settings, 'mask_overlay_enabled', False))

def _mask_runtime_settings_enabled(settings=None):
    settings = settings or _settings_for_mask_runtime()
    return _mask_lock_settings_enabled(settings) or _mask_overlay_settings_enabled(settings)

def _clear_mask_overlay_cache():
    cache = _MASK_OVERLAY_CACHE
    had_data = bool(cache.get('coords')) or cache.get('object_key') is not None
    cache['object_key'] = None
    cache['coords'] = ()
    cache['batch'] = None
    cache['batch_revision'] = -1
    cache['source_count'] = 0
    cache['truncated'] = False
    if had_data:
        cache['revision'] = int(cache.get('revision', 0)) + 1
    if isinstance(_MASK_OVERLAY_STATE, dict):
        _MASK_OVERLAY_STATE['packet'] = _gpu_state.build_packet(expected_viewport=_MASK_OVERLAY_STATE.get('viewport'))

def _set_mask_overlay_coords(object_key, coords, source_count=None):
    cache = _MASK_OVERLAY_CACHE
    bounded_coords = tuple(coords[:_MASK_OVERLAY_POINT_LIMIT])
    total = max(len(bounded_coords), int(source_count if source_count is not None else len(bounded_coords)))
    cache['object_key'] = object_key
    cache['coords'] = bounded_coords
    cache['revision'] = int(cache.get('revision', 0)) + 1
    cache['batch'] = None
    cache['batch_revision'] = -1
    cache['source_count'] = total
    cache['truncated'] = total > len(bounded_coords)
    _rebuild_mask_overlay_packet()

def _reset_mask_lock_anchors(obj=None):
    if obj is None:
        _MASK_LOCK_ANCHORS.clear()
        return
    key = _mask_lock_key(obj)
    if key in _MASK_LOCK_ANCHORS:
        _MASK_LOCK_ANCHORS.pop(key, None)

def _refresh_mask_lock_anchors(obj=None):
    _reset_mask_lock_anchors(obj)
    if not _mask_runtime_settings_enabled():
        _clear_mask_overlay_cache()
        return
    try:
        _edit_mask_lock_tick()
    except Exception:
        _schedule_mask_runtime_update()

def _sync_mask_runtime(context=None):
    if _mask_overlay_settings_enabled():
        _ensure_mask_overlay_handler()
    else:
        _remove_mask_overlay_handler()
    if _mask_runtime_settings_enabled():
        _ensure_mask_lock_timer()
    else:
        _remove_mask_lock_timer()
    try:
        area = getattr(context, 'area', None) if context is not None else None
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass

def _mask_lock_settings_update(self, context):
    try:
        _sync_mask_runtime(context)
    except Exception:
        pass
    try:
        _refresh_mask_lock_anchors(_active_edit_mesh_object())
    except Exception:
        pass

def _mask_overlay_settings_update(self, context):
    try:
        _sync_mask_runtime(context)
    except Exception:
        pass
    if _mask_overlay_settings_enabled(self):
        try:
            _edit_mask_lock_tick()
        except Exception:
            _schedule_mask_runtime_update()
    else:
        _clear_mask_overlay_cache()

def _mask_overlay_style_update(self, context):
    try:
        if _mask_overlay_settings_enabled(self):
            _ensure_mask_overlay_handler()
            _rebuild_mask_overlay_packet(self)
        else:
            _remove_mask_overlay_handler()
    except Exception as exc:
        _runtime_errors.record('mask_overlay_style_update', exc)
    try:
        area = getattr(context, 'area', None)
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass

def _settings_for_mask_runtime():
    try:
        scene = getattr(bpy.context, 'scene', None)
        return getattr(scene, 'strict_edit_mode_sculpt_settings', None)
    except Exception:
        return None

def _active_edit_mesh_object():
    try:
        obj = getattr(bpy.context, 'edit_object', None) or getattr(bpy.context, 'object', None)
    except Exception:
        obj = None
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', '') != 'EDIT':
        return None
    return obj

def _edit_mask_lock_tick():
    global _MASK_RUNTIME_ACTIVE_KEY, _MASK_RUNTIME_DIRTY
    _MASK_RUNTIME_DIRTY = False
    settings = _settings_for_mask_runtime()
    obj = _active_edit_mesh_object()
    lock_enabled = _mask_lock_settings_enabled(settings)
    overlay_enabled = _mask_overlay_settings_enabled(settings)
    if obj is None or settings is None or (not (lock_enabled or overlay_enabled)):
        _MASK_RUNTIME_ACTIVE_KEY = None
        _MASK_LOCK_ANCHORS.clear()
        _clear_mask_overlay_cache()
        return
    key = _mask_lock_key(obj)
    if key is None:
        _MASK_RUNTIME_ACTIVE_KEY = None
        _MASK_LOCK_ANCHORS.clear()
        _clear_mask_overlay_cache()
        return
    _MASK_RUNTIME_ACTIVE_KEY = key
    for stale_key in tuple(_MASK_LOCK_ANCHORS.keys()):
        if stale_key != key:
            _MASK_LOCK_ANCHORS.pop(stale_key, None)
    if not lock_enabled:
        _MASK_LOCK_ANCHORS.clear()
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.verts.index_update()
    except Exception:
        _clear_mask_overlay_cache()
        return
    layer = _mask_layer(bm, False)
    if layer is None:
        _MASK_LOCK_ANCHORS.pop(key, None)
        _clear_mask_overlay_cache()
        return
    threshold = _clamp(float(getattr(settings, 'mask_lock_threshold', 0.99)))
    anchors = _MASK_LOCK_ANCHORS.setdefault(key, {}) if lock_enabled else None
    locked_indices = set()
    overlay_coords = []
    overlay_source_count = 0
    changed = False
    try:
        matrix_world = obj.matrix_world.copy()
    except Exception:
        matrix_world = obj.matrix_world
    for v in bm.verts:
        if v.hide:
            continue
        locked = _masked_vertex_value(v, layer) >= threshold
        if not locked:
            if anchors is not None:
                anchors.pop(v.index, None)
            continue
        if anchors is not None:
            locked_indices.add(v.index)
            anchor = anchors.get(v.index)
            if anchor is None:
                # Deterministic hard cap prevents an unbounded snapshot on pathological meshes.
                if len(anchors) < _MASK_LOCK_ANCHOR_LIMIT:
                    anchors[v.index] = v.co.copy()
            elif (v.co - anchor).length_squared > 1e-16:
                v.co = anchor.copy()
                changed = True
        if overlay_enabled:
            try:
                point = tuple(matrix_world @ v.co)
                overlay_source_count += 1
                if len(overlay_coords) < _MASK_OVERLAY_POINT_LIMIT:
                    overlay_coords.append(point)
                else:
                    slot = (overlay_source_count * 1103515245 + 12345 & 2147483647) % overlay_source_count
                    if slot < _MASK_OVERLAY_POINT_LIMIT:
                        overlay_coords[slot] = point
            except Exception:
                pass
    if anchors is not None:
        for index in tuple(anchors.keys()):
            if index not in locked_indices:
                anchors.pop(index, None)
    if changed:
        try:
            bm.normal_update()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
    if overlay_enabled:
        _set_mask_overlay_coords(key, overlay_coords, source_count=overlay_source_count)
    else:
        _clear_mask_overlay_cache()

def _mask_runtime_handler_matches(callback):
    return callback is _MASK_RUNTIME_HANDLER

@persistent
def _mask_runtime_depsgraph_update(_scene=None, depsgraph=None, *_args):
    if not _mask_runtime_settings_enabled():
        return
    obj = _active_edit_mesh_object()
    if obj is None:
        if _MASK_RUNTIME_ACTIVE_KEY is not None or _MASK_OVERLAY_CACHE.get('object_key') is not None:
            _schedule_mask_runtime_update()
        return
    key = _mask_lock_key(obj)
    if key != _MASK_RUNTIME_ACTIVE_KEY:
        _schedule_mask_runtime_update()
        return
    relevant = depsgraph is None
    if depsgraph is not None:
        try:
            obj_data = getattr(obj, 'data', None)
            for update in (getattr(depsgraph, 'updates', ()) or ()):
                updated_id = getattr(update, 'id', None)
                if updated_id is obj or updated_id is obj_data:
                    relevant = True
                    break
        except Exception:
            relevant = True
    if relevant:
        _schedule_mask_runtime_update()

def _ensure_mask_runtime_handler():
    global _MASK_RUNTIME_HANDLER_REGISTERED, _MASK_RUNTIME_HANDLER
    if _MASK_RUNTIME_HANDLER is None and _mask_runtime_settings_enabled():
        _MASK_RUNTIME_HANDLER = _lifecycle.append_handler(bpy.app.handlers.depsgraph_update_post, _mask_runtime_depsgraph_update)
    _MASK_RUNTIME_HANDLER_REGISTERED = _MASK_RUNTIME_HANDLER is not None

def _remove_mask_runtime_handler():
    global _MASK_RUNTIME_HANDLER_REGISTERED, _MASK_RUNTIME_HANDLER
    if _MASK_RUNTIME_HANDLER is not None:
        _lifecycle.remove_handler(bpy.app.handlers.depsgraph_update_post, _MASK_RUNTIME_HANDLER)
    _MASK_RUNTIME_HANDLER = None
    _MASK_RUNTIME_HANDLER_REGISTERED = False

def _schedule_mask_runtime_update():
    global _MASK_LOCK_TIMER_REGISTERED, _MASK_RUNTIME_DIRTY, _MASK_RUNTIME_PROCESSING
    if not _mask_runtime_settings_enabled() or _MASK_RUNTIME_PROCESSING:
        return
    _MASK_RUNTIME_DIRTY = True
    _MASK_RUNTIME_PROCESSING = True
    try:
        _edit_mask_lock_tick()
    except Exception as exc:
        _runtime_errors.record('mask_runtime_update', exc)
    finally:
        _MASK_RUNTIME_DIRTY = False
        _MASK_RUNTIME_PROCESSING = False
        _MASK_LOCK_TIMER_REGISTERED = False

def _edit_mask_lock_timer():
    _schedule_mask_runtime_update()
    return None

def _ensure_mask_lock_timer():
    if not _mask_runtime_settings_enabled():
        _remove_mask_lock_timer()
        return
    _ensure_mask_runtime_handler()
    _schedule_mask_runtime_update()

def _remove_mask_lock_timer():
    global _MASK_LOCK_TIMER_REGISTERED, _MASK_RUNTIME_DIRTY, _MASK_RUNTIME_PROCESSING, _MASK_RUNTIME_ACTIVE_KEY
    _remove_mask_runtime_handler()
    _MASK_LOCK_TIMER_REGISTERED = False
    _MASK_RUNTIME_DIRTY = False
    _MASK_RUNTIME_PROCESSING = False
    _MASK_RUNTIME_ACTIVE_KEY = None
    _MASK_LOCK_ANCHORS.clear()
    _clear_mask_overlay_cache()

def _draw_edit_mask_lock_overlay(state):
    """Replay a completed immutable mask-overlay packet only."""
    _gpu_state.replay_state_packet(state)

def _ensure_mask_overlay_handler():
    global _MASK_OVERLAY_HANDLE, _MASK_OVERLAY_STATE
    if not _mask_overlay_settings_enabled():
        _remove_mask_overlay_handler()
        return
    if _MASK_OVERLAY_HANDLE is not None:
        _ensure_mask_runtime_handler()
        _rebuild_mask_overlay_packet()
        return
    try:
        context = getattr(bpy, 'context', None)
        region = getattr(context, 'region', None)
        _MASK_OVERLAY_STATE = {'alive': True, 'viewport': _region_viewport_snapshot(region)}
        _rebuild_mask_overlay_packet()
        _MASK_OVERLAY_HANDLE = _add_tracked_draw_handler(_draw_edit_mask_lock_overlay, _MASK_OVERLAY_STATE, 'WINDOW', 'POST_VIEW')
        _ensure_mask_lock_timer()
    except Exception as exc:
        _runtime_errors.record('mask_overlay_handler', exc)
        _MASK_OVERLAY_HANDLE = None

def _remove_mask_overlay_handler():
    global _MASK_OVERLAY_HANDLE, _MASK_OVERLAY_STATE, _MASK_OVERLAY_SHADER
    try:
        if isinstance(_MASK_OVERLAY_STATE, dict):
            _MASK_OVERLAY_STATE['alive'] = False
    except Exception:
        pass
    if _MASK_OVERLAY_HANDLE is not None:
        _remove_tracked_draw_handler(_MASK_OVERLAY_HANDLE, _MASK_OVERLAY_STATE)
        _MASK_OVERLAY_HANDLE = None
    _MASK_OVERLAY_STATE = {'alive': False}
    _MASK_OVERLAY_SHADER = None
    _clear_mask_overlay_cache()

def _neighbor_average(v, coords):
    linked = [e.other_vert(v) for e in v.link_edges if not e.other_vert(v).hide]
    if not linked:
        return coords.get(v, v.co.copy())
    acc = Vector((0.0, 0.0, 0.0))
    for n in linked:
        acc += coords.get(n, n.co)
    return acc / len(linked)

def _apply_smooth(bm, verts, settings, tangent=False, sharpen=False):
    mask = _mask_layer(bm, False)
    bm.normal_update()
    factor = max(0.0, min(1.0, settings.strength))
    for _i in range(max(1, settings.iterations)):
        coords = {v: v.co.copy() for v in bm.verts if not v.hide}
        updates = {}
        for v in verts:
            avg = _neighbor_average(v, coords)
            delta = avg - coords[v]
            if tangent:
                n = v.normal.copy()
                if n.length_squared > 1e-12:
                    n.normalize()
                    delta = delta - n * delta.dot(n)
            if sharpen:
                delta = -delta
            updates[v] = coords[v] + delta * factor * _influence(v, settings, mask)
        for v, co in updates.items():
            v.co = co
        bm.normal_update()

def _apply_plane(bm, verts, settings, mode):
    mask = _mask_layer(bm, False)
    bm.normal_update()
    center = _center(verts)
    normal = _average_normal(verts)
    factor = max(0.0, min(1.0, settings.strength))
    for v in verts:
        dist = (v.co - center).dot(normal)
        if mode == 'FILL' and dist >= 0.0:
            continue
        if mode == 'SCRAPE' and dist <= 0.0:
            continue
        v.co -= normal * dist * factor * _influence(v, settings, mask)

def _apply_normal_offset(bm, verts, settings, signed_amount):
    mask = _mask_layer(bm, False)
    bm.normal_update()
    factor = settings.amount * settings.strength * signed_amount
    for v in verts:
        v.co += v.normal * factor * _influence(v, settings, mask)

def _apply_pinch(bm, verts, settings, strength_scale=1.0):
    mask = _mask_layer(bm, False)
    center = _center(verts)
    factor = max(0.0, min(1.0, settings.strength * strength_scale))
    for v in verts:
        v.co = v.co.lerp(center, factor * _influence(v, settings, mask))

def _apply_scale(bm, verts, settings, scale_factor=None):
    mask = _mask_layer(bm, False)
    center = _center(verts)
    if scale_factor is None:
        scale_factor = 1.0 + settings.amount * settings.strength
    for v in verts:
        infl = _influence(v, settings, mask)
        target = center + (v.co - center) * scale_factor
        v.co = v.co.lerp(target, infl)

def _apply_grab(bm, verts, settings, snake=False):
    mask = _mask_layer(bm, False)
    center = _center(verts)
    offset = Vector(settings.grab_offset) * settings.amount * settings.strength
    for v in verts:
        infl = _influence(v, settings, mask)
        delta = offset.copy()
        if snake:
            dist = (v.co - center).length
            delta += (v.co - center).normalized() * settings.amount * settings.strength * 0.15 if dist > 1e-08 else Vector((0, 0, 0))
        v.co += delta * infl

def _apply_pose(bm, verts, settings):
    mask = _mask_layer(bm, False)
    center = _center(verts)
    axis_map = {'X': Vector((1.0, 0.0, 0.0)), 'Y': Vector((0.0, 1.0, 0.0)), 'Z': Vector((0.0, 0.0, 1.0))}
    axis = axis_map.get(settings.pose_axis, Vector((0.0, 0.0, 1.0)))
    angle = math.radians(settings.pose_angle) * settings.strength
    mat = Matrix.Rotation(angle, 3, axis)
    for v in verts:
        infl = _influence(v, settings, mask)
        target = center + mat @ (v.co - center)
        v.co = v.co.lerp(target, infl)
_ICON_IDS = {}

def _icon_dirs():
    seen = set()
    for kind in ('LOCAL', 'SYSTEM', 'USER'):
        try:
            base = bpy.utils.resource_path(kind)
        except Exception:
            base = ''
        if not base:
            continue
        path = os.path.join(base, 'datafiles', 'icons')
        if path not in seen and os.path.isdir(path):
            seen.add(path)
            yield path

def _icon_value(icon_name):
    """Return Blender's built-in toolbar icon value for a datafiles/icons/*.dat name."""
    if not icon_name or '.' not in icon_name:
        return 0
    if icon_name in _ICON_IDS:
        return _ICON_IDS[icon_name]
    filename = f'{icon_name}.dat'
    for directory in _icon_dirs():
        filepath = os.path.join(directory, filename)
        if not os.path.exists(filepath):
            continue
        try:
            icon_id = bpy.app.icons.new_triangles_from_file(filepath)
        except Exception:
            icon_id = 0
        _ICON_IDS[icon_name] = icon_id
        return icon_id
    _ICON_IDS[icon_name] = 0
    return 0

def _release_icon_values():
    for icon_id in list(_ICON_IDS.values()):
        if icon_id:
            try:
                bpy.app.icons.release(icon_id)
            except Exception:
                pass
    _ICON_IDS.clear()

def _operator_with_icon(layout, op_name, text, icon_name):
    icon_value = _icon_value(icon_name)
    if icon_value:
        return layout.operator(op_name, text=text, icon_value=icon_value)
    return layout.operator(op_name, text=text, icon=icon_name if icon_name and '.' not in icon_name else 'BRUSH_DATA')

def _operation_items():
    return [('DRAW', 'op_draw', 'tip_draw', 'brush.generic'), ('DRAW_SHARP', 'op_draw_sharp', 'tip_draw_sharp', 'brush.generic'), ('CLAY', 'op_clay', 'tip_clay', 'brush.generic'), ('CLAY_STRIPS', 'op_clay_strips', 'tip_clay_strips', 'brush.generic'), ('CLAY_THUMB', 'op_clay_thumb', 'tip_clay_thumb', 'brush.generic'), ('LAYER', 'op_layer', 'tip_layer', 'brush.generic'), ('INFLATE', 'op_inflate', 'tip_inflate', 'brush.generic'), ('BLOB', 'op_blob', 'tip_blob', 'brush.generic'), ('CREASE', 'op_crease', 'tip_crease', 'brush.generic'), ('SMOOTH', 'op_smooth', 'tip_smooth', 'brush.generic'), ('PLANE', 'op_plane', 'tip_plane', 'brush.generic'), ('MULTIPLANE_SCRAPE', 'op_multiplane_scrape', 'tip_multiplane_scrape', 'brush.generic'), ('PINCH', 'op_pinch', 'tip_pinch', 'brush.generic'), ('GRAB', 'op_grab', 'tip_grab', 'brush.generic'), ('ELASTIC_DEFORM', 'op_elastic', 'tip_elastic', 'brush.generic'), ('SNAKE_HOOK', 'op_snake_hook', 'tip_snake_hook', 'brush.generic'), ('THUMB', 'op_thumb', 'tip_thumb', 'brush.generic'), ('POSE', 'op_pose', 'tip_pose', 'brush.generic'), ('NUDGE', 'op_nudge', 'tip_nudge', 'brush.generic'), ('ROTATE', 'op_rotate', 'tip_rotate', 'brush.generic'), ('TOPOLOGY', 'op_topology', 'tip_topology', 'brush.generic'), ('BOUNDARY', 'op_boundary', 'tip_boundary', 'brush.generic'), ('CLOTH', 'op_cloth', 'tip_cloth', 'brush.generic'), ('SIMPLIFY', 'op_simplify', 'tip_simplify', 'brush.sculpt.simplify'), ('MASK', 'op_mask_paint', 'tip_mask_paint', 'brush.sculpt.mask'), ('DRAW_FACE_SETS', 'op_draw_face_sets', 'tip_draw_face_sets', 'brush.sculpt.draw_face_sets'), ('DISPLACEMENT_ERASER', 'op_displacement_eraser', 'tip_displacement_eraser', 'brush.sculpt.displacement_eraser'), ('DISPLACEMENT_SMEAR', 'op_displacement_smear', 'tip_displacement_smear', 'brush.sculpt.displacement_smear'), ('PAINT', 'op_paint', 'tip_paint', 'brush.sculpt.paint'), ('SMEAR', 'op_smear', 'tip_smear', 'brush.generic'), ('BLUR', 'op_blur', 'tip_blur', 'brush.generic')]

def _filter_items():
    return [('FILTER_SMOOTH', 'op_filter_smooth', 'tip_filter_smooth', 'preview:filter_smooth'), ('FILTER_RELAX', 'op_filter_relax', 'tip_filter_relax', 'preview:filter_relax'), ('FILTER_SHARPEN', 'op_filter_sharpen', 'tip_filter_sharpen', 'preview:filter_sharpen'), ('FILTER_SCALE', 'op_filter_scale', 'tip_filter_scale', 'preview:filter_scale')]

def _op_tip(operation):
    for op_id, _label_key, tip_key, _icon in _operation_items() + _filter_items():
        if op_id == operation:
            return tr(tip_key)
    return tr('mode_error')

def _native_sculpt_ops():
    names = []
    try:
        for name in dir(bpy.ops.sculpt):
            if name.startswith('_'):
                continue
            op = getattr(bpy.ops.sculpt, name, None)
            if callable(op):
                names.append(name)
    except Exception:
        pass
    return sorted(set(names))

def _toolbar_tool_items():
    return [('BRUSH', 'tool_brush', 'tip_toolbar_brush', 'brush.generic', 'BRUSH', ''), ('PAINT', 'tool_paint', 'tip_toolbar_paint', 'brush.sculpt.paint', 'BRUSH', 'PAINT'), ('MASK', 'tool_mask', 'tip_toolbar_mask', 'brush.sculpt.mask', 'BRUSH', 'MASK'), ('DRAW_FACE_SETS', 'tool_draw_face_sets', 'tip_toolbar_draw_face_sets', 'brush.sculpt.draw_face_sets', 'BRUSH', 'DRAW_FACE_SETS'), ('DENSITY', 'tool_density', 'tip_toolbar_density', 'brush.sculpt.simplify', 'BRUSH', 'SIMPLIFY'), ('MULTIRES_ERASER', 'tool_multires_eraser', 'tip_toolbar_multires_eraser', 'brush.sculpt.displacement_eraser', 'BRUSH', 'DISPLACEMENT_ERASER'), ('MULTIRES_SMEAR', 'tool_multires_smear', 'tip_toolbar_multires_smear', 'brush.sculpt.displacement_smear', 'BRUSH', 'DISPLACEMENT_SMEAR'), ('BOX_MASK', 'tool_box_mask', 'tip_toolbar_mask_gesture', 'ops.sculpt.border_mask', 'GESTURE', 'MASK:BOX'), ('LASSO_MASK', 'tool_lasso_mask', 'tip_toolbar_mask_gesture', 'ops.sculpt.lasso_mask', 'GESTURE', 'MASK:LASSO'), ('LINE_MASK', 'tool_line_mask', 'tip_toolbar_mask_gesture', 'ops.sculpt.line_mask', 'GESTURE', 'MASK:LINE'), ('POLYLINE_MASK', 'tool_polyline_mask', 'tip_toolbar_mask_gesture', 'ops.sculpt.polyline_mask', 'GESTURE', 'MASK:POLYLINE'), ('BOX_HIDE', 'tool_box_hide', 'tip_toolbar_hide_gesture', 'ops.sculpt.border_hide', 'GESTURE', 'HIDE:BOX'), ('LASSO_HIDE', 'tool_lasso_hide', 'tip_toolbar_hide_gesture', 'ops.sculpt.lasso_hide', 'GESTURE', 'HIDE:LASSO'), ('LINE_HIDE', 'tool_line_hide', 'tip_toolbar_hide_gesture', 'ops.sculpt.line_hide', 'GESTURE', 'HIDE:LINE'), ('POLYLINE_HIDE', 'tool_polyline_hide', 'tip_toolbar_hide_gesture', 'ops.sculpt.polyline_hide', 'GESTURE', 'HIDE:POLYLINE'), ('BOX_FACE_SET', 'tool_box_face_set', 'tip_toolbar_face_set_gesture', 'ops.sculpt.border_face_set', 'GESTURE', 'FACE_SET:BOX'), ('LASSO_FACE_SET', 'tool_lasso_face_set', 'tip_toolbar_face_set_gesture', 'ops.sculpt.lasso_face_set', 'GESTURE', 'FACE_SET:LASSO'), ('LINE_FACE_SET', 'tool_line_face_set', 'tip_toolbar_face_set_gesture', 'ops.sculpt.line_face_set', 'GESTURE', 'FACE_SET:LINE'), ('POLYLINE_FACE_SET', 'tool_polyline_face_set', 'tip_toolbar_face_set_gesture', 'ops.sculpt.polyline_face_set', 'GESTURE', 'FACE_SET:POLYLINE'), ('BOX_TRIM', 'tool_box_trim', 'tip_toolbar_trim_gesture', 'ops.sculpt.box_trim', 'GESTURE', 'TRIM:BOX'), ('LASSO_TRIM', 'tool_lasso_trim', 'tip_toolbar_trim_gesture', 'ops.sculpt.lasso_trim', 'GESTURE', 'TRIM:LASSO'), ('LINE_TRIM', 'tool_line_trim', 'tip_toolbar_trim_gesture', 'ops.sculpt.line_trim', 'GESTURE', 'TRIM:LINE'), ('POLYLINE_TRIM', 'tool_polyline_trim', 'tip_toolbar_trim_gesture', 'ops.sculpt.polyline_trim', 'GESTURE', 'TRIM:POLYLINE'), ('LINE_PROJECT', 'tool_line_project', 'tip_toolbar_project_line', 'ops.sculpt.line_project', 'GESTURE', 'PROJECT:LINE'), ('MESH_FILTER', 'tool_mesh_filter', 'tip_toolbar_mesh_filter', 'ops.sculpt.mesh_filter', 'ACTION', 'FILTER_SMOOTH'), ('CLOTH_FILTER', 'tool_cloth_filter', 'tip_toolbar_cloth_filter', 'ops.sculpt.cloth_filter', 'ACTION', 'CLOTH_FILTER'), ('COLOR_FILTER', 'tool_color_filter', 'tip_toolbar_color_filter', 'ops.sculpt.color_filter', 'ACTION', 'COLOR_FILTER'), ('FACE_SET_EDIT', 'tool_face_set_edit', 'tip_toolbar_face_set_edit', 'ops.sculpt.face_set_edit', 'ACTION', 'FACE_SET_EDIT'), ('MASK_BY_COLOR', 'tool_mask_by_color', 'tip_toolbar_mask_by_color', 'ops.sculpt.mask_by_color', 'ACTION', 'MASK_BY_COLOR'), ('TRANSLATE', 'tool_translate', 'tip_toolbar_transform', 'ops.transform.translate', 'BRUSH', 'GRAB'), ('ROTATE', 'tool_rotate', 'tip_toolbar_transform', 'ops.transform.rotate', 'BRUSH', 'ROTATE'), ('SCALE', 'tool_scale', 'tip_toolbar_transform', 'ops.transform.resize', 'BRUSH', 'ELASTIC_DEFORM'), ('TRANSFORM', 'tool_transform', 'tip_toolbar_transform', 'ops.transform.transform', 'BRUSH', 'POSE'), ('ANNOTATE', 'tool_annotate', 'tip_toolbar_annotate', 'ops.gpencil.draw', 'ANNOTATE', 'builtin.annotate'), ('ANNOTATE_LINE', 'tool_annotate_line', 'tip_toolbar_annotate', 'ops.gpencil.draw.line', 'ANNOTATE', 'builtin.annotate_line'), ('ANNOTATE_POLY', 'tool_annotate_poly', 'tip_toolbar_annotate', 'ops.gpencil.draw.poly', 'ANNOTATE', 'builtin.annotate_polygon'), ('ANNOTATE_ERASER', 'tool_annotate_eraser', 'tip_toolbar_annotate', 'ops.gpencil.draw.eraser', 'ANNOTATE', 'builtin.annotate_eraser')]
_DIRECT_DRAG_TOOLS = {'GRAB', 'SNAKE_HOOK', 'ELASTIC', 'ELASTIC_DEFORM', 'POSE', 'THUMB', 'NUDGE', 'ROTATE', 'CLOTH', 'BOUNDARY'}

def _direct_brush_items():
    items = []
    seen = set()
    for tool_id, _name_en, _name_ja, _sculpt_type, _operation, slug in STANDARD_SCULPT_BRUSH_DATA:
        items.append((tool_id, _brush_label_key(tool_id), _brush_tip_key(tool_id), 'preview:' + slug))
        seen.add(tool_id)
    for op_id, label_key, tip_key, icon in _operation_items() + [('PAINT_SELECT', 'op_paint_select', 'tip_paint_select', 'preview:paint_select'), ('MASK_PAINT', 'op_mask_paint', 'tip_mask_paint', 'preview:mask'), ('FACE_SET_PAINT', 'op_faceset_paint', 'tip_faceset_paint', 'preview:face_set_paint'), ('COLOR_PAINT', 'op_color_paint', 'tip_color_paint', 'preview:paint')]:
        if op_id in seen:
            continue
        items.append((op_id, label_key, tip_key, icon))
        seen.add(op_id)
    return items

def _is_direct_drag_tool(tool):
    operation = _brush_operation(tool or 'DRAW')
    operation = _BRUSH_TOOL_ALIASES.get(operation, operation)
    return operation in _DIRECT_DRAG_TOOLS

def _falloff_items():
    return [('SMOOTH', 'falloff_smooth', 'prop_brush_falloff_desc'), ('LINEAR', 'falloff_linear', 'prop_brush_falloff_desc'), ('ROUND', 'falloff_round', 'prop_brush_falloff_desc'), ('SHARP', 'falloff_sharp', 'prop_brush_falloff_desc'), ('CONSTANT', 'falloff_constant', 'prop_brush_falloff_desc')]

def _enum_icon_tuple(identifier, label, description, icon_spec, number):
    icon_value = _ui_icon_value(icon_spec)
    if icon_value:
        return (identifier, label, description, int(icon_value), int(number))
    safe_icon = _safe_builtin_icon(icon_spec) if '_safe_builtin_icon' in globals() else 'NONE'
    return (identifier, label, description, safe_icon, int(number))

def _brush_tool_enum_items(_self=None, _context=None):
    items = []
    for index, (op_id, label_key, tip_key, icon) in enumerate(_direct_brush_items()):
        _register_enum_text_pair(label_key)
        _register_enum_text_pair(tip_key)
        items.append(_enum_icon_tuple(op_id, _enum_text(label_key), _enum_text(tip_key), icon, index))
    return items

def _toolbar_enum_compact_icon(icon_handle, tool_id=''):
    """Return a compact built-in fallback for text-bearing toolbar enum rows."""
    icon = str(icon_handle or '')
    tid = str(tool_id or '')
    source = (icon + ' ' + tid).lower()
    if 'mask' in source:
        return 'MOD_MASK'
    if 'face_set' in source:
        return 'FACESEL'
    if 'hide' in source or 'trim' in source:
        return 'SELECT_SUBTRACT'
    if 'mesh_filter' in source or 'cloth_filter' in source or 'color_filter' in source:
        return 'FILTER'
    if 'line_project' in source:
        return 'OUTLINER_OB_CURVE'
    if 'translate' in source:
        return 'EMPTY_ARROWS'
    if 'rotate' in source:
        return 'DRIVER_ROTATIONAL_DIFFERENCE'
    if 'resize' in source or 'scale' in source or 'transform' in source:
        return 'TRANSFORM_ORIGINS'
    if 'paint' in source or 'brush' in source or 'draw' in source or ('displacement' in source):
        return 'BRUSH_DATA'
    return 'SCULPTMODE_HLT'

def _toolbar_enum_icon_value(tool_id, icon_handle=None):
    """Return a 16 px standard Sculpt toolbar icon for enum rows/dropdowns.

    The popup overlay keeps the larger standard-toolbar PNGs. The N-panel
    Toolbar Tool property and its dropdown use these smaller images so the same
    icon designs cannot cover the text label on Blender 5.1.
    """
    pcoll = _preview_collection()
    if pcoll is None:
        return 0
    tool_id = (tool_id or '').strip()
    handle = (icon_handle or _toolbar_icon_spec(tool_id) or '').strip()
    key = 'toolbar_enum_%s_v148' % (tool_id.lower() or handle.replace('.', '_'))
    item = pcoll.get(key)
    if item is not None:
        return item.icon_id
    base = os.path.dirname(__file__)
    icon_dir = os.path.join(base, 'icons_toolbar_enum')
    candidates = []
    if tool_id:
        candidates.append(os.path.join(icon_dir, tool_id.lower() + '.png'))
    if handle:
        candidates.append(os.path.join(icon_dir, handle + '.png'))
        candidates.append(os.path.join(icon_dir, handle.replace('.', '_') + '.png'))
    filepath = next((candidate for candidate in candidates if os.path.exists(candidate)), '')
    if not filepath:
        return 0
    try:
        item = pcoll.load(key, filepath, 'IMAGE')
        return item.icon_id
    except Exception:
        return 0

def _toolbar_tool_enum_items(_self=None, _context=None):
    items = []
    for index, (tool_id, _name_en, _name_ja, icon_handle, _action, _shape) in enumerate(_toolbar_display_items()):
        label_key = 'toolbar_' + tool_id.lower()
        tip_key = 'toolbar_tip_' + tool_id.lower()
        icon_value = _toolbar_enum_icon_value(tool_id, icon_handle)
        _register_enum_text_pair(label_key)
        _register_enum_text_pair(tip_key)
        if icon_value:
            items.append((tool_id, _enum_text(label_key), _enum_text(tip_key), int(icon_value), int(index)))
        else:
            items.append((tool_id, _enum_text(label_key), _enum_text(tip_key), _toolbar_enum_compact_icon(icon_handle, tool_id), int(index)))
    return items

def _toolbar_tool_label(tool_id):
    key = 'toolbar_' + (tool_id or '').lower()
    return tr(key) if key in I18N.get(_locale(), {}) or key in I18N.get('en_US', {}) else tr('toolbar_tool')

def _toolbar_icon_spec(tool_id):
    item = _toolbar_item(tool_id)
    return item[3] if item else 'SCULPTMODE_HLT'

def _toolbar_popup_icon_spec(tool_id, icon_handle=None):
    """Return Blender's standard toolbar icon handle for toolbar icon-only buttons.

    Earlier preview-image fallbacks made several toolbar entries look like brush
    thumbnails. The popup now follows Blender's Sculpt toolbar definitions and
    uses the native tool-system icon handles such as ops.sculpt.mesh_filter.
    """
    return icon_handle or _toolbar_icon_spec(tool_id) or 'SCULPTMODE_HLT'

def _toolbar_safe_icon_spec(tool_id):
    """Return a clipped-safe icon spec for compact toolbar UI."""
    return _toolbar_popup_icon_spec(tool_id, _toolbar_icon_spec(tool_id))

def _run_toolbar_tool_by_id(context, tool_id):
    item = _toolbar_item(tool_id)
    if item is None:
        return {'CANCELLED'}
    try:
        _settings(context).toolbar_tool = tool_id
    except Exception:
        pass
    action = item[4]
    if action.startswith('GESTURE_'):
        return bpy.ops.strict_edit_sculpt.gesture_tool('INVOKE_DEFAULT', tool=tool_id)
    return bpy.ops.strict_edit_sculpt.toolbar_operation('INVOKE_DEFAULT', tool=tool_id)

def _falloff_enum_items(_self=None, _context=None):
    result = []
    for op_id, label_key, tip_key in _falloff_items():
        _register_enum_text_pair(label_key)
        _register_enum_text_pair(tip_key)
        result.append((op_id, _enum_text(label_key), _enum_text(tip_key)))
    return result

def _tool_label(tool):
    for op_id, label_key, _tip_key, _icon in _direct_brush_items():
        if op_id == tool:
            return tr(label_key)
    return tr('brush_tool')

def _direct_op_tip(tool):
    for op_id, _label_key, tip_key, _icon in _direct_brush_items():
        if op_id == tool:
            return tr(tip_key)
    return tr('tip_direct_brush')

def _clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))

class _SettingsProxy:
    """Read-through settings proxy used for per-stroke pressure/runtime overrides."""

    def __init__(self, base, **overrides):
        object.__setattr__(self, '_base', base)
        object.__setattr__(self, '_overrides', dict(overrides))

    def __getattr__(self, name):
        overrides = object.__getattribute__(self, '_overrides')
        if name in overrides:
            return overrides[name]
        return getattr(object.__getattribute__(self, '_base'), name)

    def __setattr__(self, name, value):
        object.__getattribute__(self, '_overrides')[name] = value

def _settings_proxy(base, **overrides):
    return _SettingsProxy(base, **overrides)
_ACTIVE_DIRECT_BRUSH = None
_POPUP_MODAL_DEPTH = 0
_PENDING_DIRECT_BRUSH_HISTORY_ACTION = None
_DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
_DIRECT_BRUSH_HISTORY_TIMER = None
_DIRECT_BRUSH_RESTART_BASELINE_READY = False
_VIEW3D_UI_PRIORITY_REGION_TYPES = {'UI', 'TOOLS', 'TOOL_PROPS', 'HEADER', 'TOOL_HEADER', 'FOOTER', 'HUD', 'NAVIGATION_BAR', 'ASSET_SHELF', 'ASSET_SHELF_HEADER'}
_BRUSH_RADIUS_DRAG_SCALE = 0.1
_BRUSH_STRENGTH_DRAG_SCALE = 1.0 / 3000.0
_POPUP_SHORTCUT_OPERATOR_IDS = {'strict_edit_sculpt.popup_brush_assets', 'strict_edit_sculpt.popup_sculpt_toolbar'}

def _popup_modal_active():
    try:
        return int(_POPUP_MODAL_DEPTH) > 0
    except Exception:
        return False

def _event_has_window_xy(event):
    try:
        float(event.mouse_x)
        float(event.mouse_y)
        return True
    except Exception:
        return False

def _event_inside_region_bounds(event, region, margin=0.0):
    if region is None or not _event_has_window_xy(event):
        return False
    try:
        width = float(getattr(region, 'width', 0.0) or 0.0)
        height = float(getattr(region, 'height', 0.0) or 0.0)
        if width <= 0.0 or height <= 0.0:
            return False
        x = float(event.mouse_x)
        y = float(event.mouse_y)
        rx = float(getattr(region, 'x', 0.0) or 0.0) - float(margin)
        ry = float(getattr(region, 'y', 0.0) or 0.0) - float(margin)
        rw = width + float(margin) * 2.0
        rh = height + float(margin) * 2.0
        return rx <= x <= rx + rw and ry <= y <= ry + rh
    except Exception:
        return False

def _event_inside_region_bounds(event, region, margin=0.0, default=True):
    if region is None or not _event_has_window_xy(event):
        return bool(default)
    try:
        width = float(getattr(region, 'width', 0.0) or 0.0)
        height = float(getattr(region, 'height', 0.0) or 0.0)
        if width <= 1.0 or height <= 1.0:
            return False
        x = float(event.mouse_x)
        y = float(event.mouse_y)
        rx = float(getattr(region, 'x', 0.0) or 0.0) - float(margin)
        ry = float(getattr(region, 'y', 0.0) or 0.0) - float(margin)
        rw = width + float(margin) * 2.0
        rh = height + float(margin) * 2.0
        return rx <= x <= rx + rw and ry <= y <= ry + rh
    except Exception:
        return bool(default)

def _event_inside_window_region(event, region, margin=0.0):
    return _event_inside_region_bounds(event, region, margin=margin, default=True)

def _event_inside_view3d_area(event, area, margin=0.0):
    if area is None or not _event_has_window_xy(event):
        return True
    try:
        x = float(event.mouse_x)
        y = float(event.mouse_y)
        ax = float(getattr(area, 'x', 0.0) or 0.0) - float(margin)
        ay = float(getattr(area, 'y', 0.0) or 0.0) - float(margin)
        aw = float(getattr(area, 'width', 0.0) or 0.0) + float(margin) * 2.0
        ah = float(getattr(area, 'height', 0.0) or 0.0) + float(margin) * 2.0
        return aw > 1.0 and ah > 1.0 and (ax <= x <= ax + aw) and (ay <= y <= ay + ah)
    except Exception:
        return True

def _event_inside_view3d_priority_ui_region(event, area, window_region=None):
    if area is None or not _event_has_window_xy(event):
        return False
    try:
        if getattr(area, 'type', '') != 'VIEW_3D':
            return False
        for candidate in getattr(area, 'regions', []) or []:
            if candidate is None or candidate == window_region:
                continue
            if getattr(candidate, 'type', '') not in _VIEW3D_UI_PRIORITY_REGION_TYPES:
                continue
            if _event_inside_region_bounds(event, candidate, margin=0.0, default=False):
                return True
    except Exception:
        return False
    return False

def _event_context_is_view3d_ui(context, area):
    try:
        if context is None:
            return False
        ctx_area = getattr(context, 'area', None)
        if area is not None and ctx_area is not None and (ctx_area != area):
            return False
        ctx_region = getattr(context, 'region', None)
        if ctx_region is None:
            return False
        return getattr(ctx_region, 'type', '') in _VIEW3D_UI_PRIORITY_REGION_TYPES
    except Exception:
        return False

def _event_inside_viewport_content(event, area, region):
    if not _event_has_window_xy(event):
        return True
    if area is not None and (not _event_inside_view3d_area(event, area, margin=0.0)):
        return False
    if not _event_inside_window_region(event, region, margin=0.0):
        return False
    if _event_inside_view3d_priority_ui_region(event, area, window_region=region):
        return False
    return True

def _event_should_pass_to_sidebar_or_popup(event, area, region, context=None):
    if _popup_modal_active():
        return True
    if event is None:
        return False
    if _event_has_window_xy(event):
        return not _event_inside_viewport_content(event, area, region)
    return _event_context_is_view3d_ui(context, area)

def _shortcut_modifier_matches(kmi_value, event_value):
    try:
        ivalue = int(kmi_value)
    except Exception:
        try:
            ivalue = 1 if bool(kmi_value) else 0
        except Exception:
            ivalue = 0
    if ivalue < 0:
        return True
    return bool(ivalue) == bool(event_value)

def _shortcut_key_modifier_matches(kmi, event):
    try:
        key_modifier = str(getattr(kmi, 'key_modifier', 'NONE') or 'NONE')
    except Exception:
        key_modifier = 'NONE'
    if key_modifier in {'', 'NONE'}:
        return True
    ctrl_keys = {'LEFT_CTRL', 'RIGHT_CTRL', 'CTRL', 'OSKEY', 'LEFT_OSKEY', 'RIGHT_OSKEY'}
    shift_keys = {'LEFT_SHIFT', 'RIGHT_SHIFT', 'SHIFT'}
    alt_keys = {'LEFT_ALT', 'RIGHT_ALT', 'ALT'}
    if key_modifier in ctrl_keys:
        return bool(getattr(event, 'ctrl', False)) or bool(getattr(event, 'oskey', False))
    if key_modifier in shift_keys:
        return bool(getattr(event, 'shift', False))
    if key_modifier in alt_keys:
        return bool(getattr(event, 'alt', False))
    try:
        return str(getattr(event, 'type', '')) == key_modifier
    except Exception:
        return False

def _shortcut_value_matches(kmi_value, event_value):
    try:
        kvalue = str(kmi_value or '')
        evalue = str(event_value or '')
    except Exception:
        return False
    if kvalue in {'ANY', 'NOTHING'}:
        return True
    if kvalue == evalue:
        return True
    if kvalue == 'CLICK' and evalue == 'PRESS':
        return True
    return False

def _event_matches_keymap_item(event, kmi):
    if event is None or kmi is None:
        return False
    try:
        if not bool(getattr(kmi, 'active', True)):
            return False
        if str(getattr(kmi, 'type', '')) != str(getattr(event, 'type', '')):
            return False
        if not _shortcut_value_matches(getattr(kmi, 'value', ''), getattr(event, 'value', '')):
            return False
        if bool(getattr(kmi, 'any', False)):
            return _shortcut_key_modifier_matches(kmi, event)
        if not _shortcut_modifier_matches(getattr(kmi, 'shift', 0), getattr(event, 'shift', False)):
            return False
        if not _shortcut_modifier_matches(getattr(kmi, 'ctrl', 0), getattr(event, 'ctrl', False)):
            return False
        if not _shortcut_modifier_matches(getattr(kmi, 'alt', 0), getattr(event, 'alt', False)):
            return False
        if not _shortcut_modifier_matches(getattr(kmi, 'oskey', 0), getattr(event, 'oskey', False)):
            return False
        return _shortcut_key_modifier_matches(kmi, event)
    except ReferenceError:
        return False
    except Exception:
        return False

def _iter_popup_shortcut_keymap_items(context):
    try:
        wm = getattr(context, 'window_manager', None) or bpy.context.window_manager
        keyconfigs = getattr(wm, 'keyconfigs', None)
    except Exception:
        keyconfigs = None
    if keyconfigs is None:
        return
    seen_cfg = set()
    for cfg_name in ('user', 'addon', 'active', 'default'):
        try:
            kc = getattr(keyconfigs, cfg_name, None)
        except Exception:
            kc = None
        if kc is None:
            continue
        try:
            ptr = kc.as_pointer()
        except Exception:
            ptr = id(kc)
        if ptr in seen_cfg:
            continue
        seen_cfg.add(ptr)
        try:
            keymaps = tuple(getattr(kc, 'keymaps', ()) or ())
        except Exception:
            keymaps = ()
        for km in keymaps:
            try:
                items = tuple(getattr(km, 'keymap_items', ()) or ())
            except Exception:
                continue
            for kmi in items:
                try:
                    if str(getattr(kmi, 'idname', '')) in _POPUP_SHORTCUT_OPERATOR_IDS:
                        yield kmi
                except Exception:
                    continue

def _popup_shortcut_id_from_event(context, event):
    if event is None:
        return ''
    try:
        if str(getattr(event, 'value', '')) not in {'PRESS', 'CLICK', 'DOUBLE_CLICK'}:
            return ''
    except Exception:
        return ''
    for kmi in _iter_popup_shortcut_keymap_items(context):
        try:
            if _event_matches_keymap_item(event, kmi):
                return str(getattr(kmi, 'idname', '') or '')
        except Exception:
            continue
    return ''

def _direct_brush_should_release_popup_shortcut(context, event):
    """Return True when a user keymap for a popup launcher should run now.

    Direct Brush intentionally owns most edit-mode keys while it is running so
    mesh-edit shortcuts do not fire mid-stroke.  User-assigned popup launchers
    are the exception: these IDs must open even while the modal brush is active.
    """
    return bool(_popup_shortcut_id_from_event(context, event))

def _popup_operator_override_from_direct_brush(context, brush_instance=None, event=None):
    override = {}
    try:
        target = None
        if event is not None and _event_has_window_xy(event):
            target = _view3d_event_target(context, event, prefer_area=getattr(brush_instance, '_area', None))
        if isinstance(target, dict) and target.get('viewport', False):
            area = target.get('area')
            region = target.get('region')
            rv3d = target.get('rv3d')
        else:
            area = getattr(brush_instance, '_area', None) if brush_instance is not None else None
            region = getattr(brush_instance, '_region', None) if brush_instance is not None else None
            rv3d = getattr(brush_instance, '_rv3d', None) if brush_instance is not None else None
            if area is None or region is None or rv3d is None:
                area, region, rv3d = _view3d_window_region(context)
        if area is not None and region is not None and (rv3d is not None):
            override['area'] = area
            override['region'] = region
            override['region_data'] = rv3d
            space = _view3d_space_for_area(area)
            if space is not None:
                override['space_data'] = space
    except Exception:
        override = {}
    try:
        window = getattr(context, 'window', None)
        screen = getattr(context, 'screen', None)
        if window is not None:
            override['window'] = window
        if screen is not None:
            override['screen'] = screen
    except Exception:
        pass
    try:
        obj = getattr(brush_instance, '_obj', None) if brush_instance is not None else None
        if obj is None:
            obj = _ensure_edit_mesh(context)
        if obj is not None:
            override['object'] = obj
            override['active_object'] = obj
    except Exception:
        pass
    return override

def _invoke_popup_operator_from_direct_brush(context, operator_id, brush_instance=None, event=None):
    if operator_id not in _POPUP_SHORTCUT_OPERATOR_IDS:
        return False
    if _popup_modal_active():
        return True
    override = _popup_operator_override_from_direct_brush(context, brush_instance=brush_instance, event=event)

    def _call():
        if operator_id == 'strict_edit_sculpt.popup_brush_assets':
            return bpy.ops.strict_edit_sculpt.popup_brush_assets('INVOKE_DEFAULT')
        if operator_id == 'strict_edit_sculpt.popup_sculpt_toolbar':
            return bpy.ops.strict_edit_sculpt.popup_sculpt_toolbar('INVOKE_DEFAULT')
        return {'CANCELLED'}
    try:
        if override:
            with context.temp_override(**override):
                result = _call()
        else:
            result = _call()
        return _operator_result_started(result) or (isinstance(result, set) and 'RUNNING_MODAL' in result)
    except Exception:
        return False

def _initial_direct_brush_mouse(event, area, region):
    if region is None:
        return Vector((0.0, 0.0))
    try:
        if event is not None and _event_has_window_xy(event) and _event_inside_viewport_content(event, area, region):
            return _event_region_mouse(event, region)
    except Exception:
        pass
    try:
        return Vector((max(0.0, float(getattr(region, 'width', 0.0) or 0.0) * 0.5), max(0.0, float(getattr(region, 'height', 0.0) or 0.0) * 0.5)))
    except Exception:
        return Vector((0.0, 0.0))

def _peek_active_direct_brush_instance():
    """Read-only active modal lookup for Panel.draw and Operator.poll."""
    inst = globals().get('_ACTIVE_DIRECT_BRUSH', None)
    if inst is None:
        return None
    try:
        alive = bool(getattr(inst, '_modal_alive', False))
        handler_registered = bool(getattr(inst, '_modal_handler_registered', False))
        obj = getattr(inst, '_obj', None)
        valid_object = obj is not None and getattr(obj, 'mode', '') == 'EDIT'
        return inst if alive and handler_registered and valid_object else None
    except Exception:
        return None

def _active_direct_brush_instance():
    inst = globals().get('_ACTIVE_DIRECT_BRUSH', None)
    if inst is None:
        return None
    try:
        alive = bool(getattr(inst, '_modal_alive', False))
        handler_registered = bool(getattr(inst, '_modal_handler_registered', False))
        obj = getattr(inst, '_obj', None)
        valid_object = obj is not None and getattr(obj, 'mode', '') == 'EDIT'
        if alive and handler_registered and valid_object:
            return inst
    except ReferenceError:
        pass
    except Exception:
        pass
    try:
        _clear_active_direct_brush(inst)
    except Exception:
        pass
    return None

def _set_active_direct_brush(inst):
    global _ACTIVE_DIRECT_BRUSH
    _ACTIVE_DIRECT_BRUSH = inst

def _clear_active_direct_brush(inst):
    global _ACTIVE_DIRECT_BRUSH
    if globals().get('_ACTIVE_DIRECT_BRUSH', None) is inst:
        _ACTIVE_DIRECT_BRUSH = None


def _cancel_active_direct_brush_for_reload():
    """Cancel the exact live modal instance before current-generation teardown."""
    inst = globals().get('_ACTIVE_DIRECT_BRUSH', None)
    if inst is None:
        return
    try:
        inst._cancel_session(getattr(bpy, 'context', None), 'reload')
    except Exception as exc:
        _runtime_errors.record('direct_brush_reload_cancel', exc)
        _clear_active_direct_brush(inst)

def _rna_pointer(value):
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0

def _object_session_uid(value):
    try:
        return int(getattr(value, 'session_uid', 0) or 0)
    except Exception:
        return 0

def _resolve_object_identity(name, session_uid=0):
    session_uid = int(session_uid or 0)
    if session_uid:
        try:
            for candidate in bpy.data.objects:
                if _object_session_uid(candidate) == session_uid:
                    return candidate
        except Exception:
            pass
    try:
        return bpy.data.objects.get(str(name or ''))
    except Exception:
        return None

def _resolve_direct_brush_history_context(pending):
    """Resolve a stable 3D View context after an undo/redo data reload."""
    wm = getattr(bpy.context, 'window_manager', None)
    windows = tuple(getattr(wm, 'windows', ()) or ()) if wm is not None else ()
    window_ptr = int(pending.get('window_pointer', 0) or 0)
    area_ptr = int(pending.get('area_pointer', 0) or 0)
    region_ptr = int(pending.get('region_pointer', 0) or 0)
    window = next((item for item in windows if _rna_pointer(item) == window_ptr), None)
    if window is None:
        window = getattr(bpy.context, 'window', None) or (windows[0] if windows else None)
    screen = getattr(window, 'screen', None) if window is not None else getattr(bpy.context, 'screen', None)
    areas = tuple(getattr(screen, 'areas', ()) or ()) if screen is not None else ()
    area = next((item for item in areas if _rna_pointer(item) == area_ptr and getattr(item, 'type', '') == 'VIEW_3D'), None)
    if area is None:
        area = next((item for item in areas if getattr(item, 'type', '') == 'VIEW_3D'), None)
    regions = tuple(getattr(area, 'regions', ()) or ()) if area is not None else ()
    region = next((item for item in regions if _rna_pointer(item) == region_ptr and getattr(item, 'type', '') == 'WINDOW'), None)
    if region is None:
        region = next((item for item in regions if getattr(item, 'type', '') == 'WINDOW'), None)
    space = None
    rv3d = None
    try:
        space = area.spaces.active if area is not None else None
        rv3d = getattr(space, 'region_3d', None)
    except Exception:
        space = None
        rv3d = None
    obj = _resolve_object_identity(pending.get('object_name', ''), pending.get('object_session_uid', 0))
    override = {}
    for key, value in (('window', window), ('screen', screen), ('area', area), ('region', region), ('space_data', space), ('region_data', rv3d)):
        if value is not None:
            override[key] = value
    if obj is not None:
        override['object'] = obj
        override['active_object'] = obj
        if getattr(obj, 'mode', '') == 'EDIT':
            override['edit_object'] = obj
    return (override, obj)

def _direct_brush_history_action_timer():
    """Run undo/redo outside the modal brush, then restore the brush safely."""
    global _PENDING_DIRECT_BRUSH_HISTORY_ACTION, _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE
    global _DIRECT_BRUSH_RESTART_BASELINE_READY, _DIRECT_BRUSH_HISTORY_TIMER
    pending = _PENDING_DIRECT_BRUSH_HISTORY_ACTION
    if not isinstance(pending, dict):
        _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
        _DIRECT_BRUSH_HISTORY_TIMER = None
        return None
    phase = str(pending.get('phase', 'HISTORY'))
    attempts = int(pending.get('attempts', 0) or 0)
    override, obj = _resolve_direct_brush_history_context(pending)
    try:
        if phase == 'HISTORY':
            operation = bpy.ops.ed.redo if bool(pending.get('redo', False)) else bpy.ops.ed.undo
            if override:
                with bpy.context.temp_override(**override):
                    if operation.poll():
                        operation()
            elif operation.poll():
                operation()
            pending['phase'] = 'RESTART'
            pending['attempts'] = 0
            _PENDING_DIRECT_BRUSH_HISTORY_ACTION = pending
            return 0.02
        override, obj = _resolve_direct_brush_history_context(pending)
        if obj is not None and getattr(obj, 'mode', '') == 'EDIT':
            try:
                view_layer = getattr(bpy.context, 'view_layer', None)
                if view_layer is not None and obj.name in view_layer.objects:
                    view_layer.objects.active = obj
            except Exception:
                pass
            _DIRECT_BRUSH_RESTART_BASELINE_READY = True
            if override:
                with bpy.context.temp_override(**override):
                    if _start_direct_brush_now(bpy.context, str(pending.get('tool') or 'DRAW')):
                        _PENDING_DIRECT_BRUSH_HISTORY_ACTION = None
                        _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
                        _DIRECT_BRUSH_HISTORY_TIMER = None
                        return None
            elif _start_direct_brush_now(bpy.context, str(pending.get('tool') or 'DRAW')):
                _PENDING_DIRECT_BRUSH_HISTORY_ACTION = None
                _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
                _DIRECT_BRUSH_HISTORY_TIMER = None
                return None
            _DIRECT_BRUSH_RESTART_BASELINE_READY = False
    except Exception:
        _DIRECT_BRUSH_RESTART_BASELINE_READY = False
    attempts += 1
    pending['attempts'] = attempts
    _PENDING_DIRECT_BRUSH_HISTORY_ACTION = pending
    if attempts < 20:
        return 0.05
    _PENDING_DIRECT_BRUSH_HISTORY_ACTION = None
    _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
    _DIRECT_BRUSH_RESTART_BASELINE_READY = False
    _DIRECT_BRUSH_HISTORY_TIMER = None
    return None

def _schedule_direct_brush_history_action(context, brush_instance, redo=False):
    global _PENDING_DIRECT_BRUSH_HISTORY_ACTION, _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE, _DIRECT_BRUSH_HISTORY_TIMER
    obj = getattr(brush_instance, '_obj', None)
    _PENDING_DIRECT_BRUSH_HISTORY_ACTION = {'redo': bool(redo), 'phase': 'HISTORY', 'attempts': 0, 'tool': str(getattr(brush_instance, '_active_tool', 'DRAW') or 'DRAW'), 'object_name': str(getattr(obj, 'name', '') or ''), 'object_session_uid': _object_session_uid(obj), 'window_pointer': _rna_pointer(getattr(context, 'window', None)), 'area_pointer': _rna_pointer(getattr(brush_instance, '_area', None)), 'region_pointer': _rna_pointer(getattr(brush_instance, '_region', None))}
    try:
        if _DIRECT_BRUSH_HISTORY_TIMER is None:
            _DIRECT_BRUSH_HISTORY_TIMER = _lifecycle.register_timer(_direct_brush_history_action_timer, first_interval=0.0)
        _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = True
        return True
    except Exception as exc:
        _runtime_errors.record('direct_brush_history_schedule', exc)
        _PENDING_DIRECT_BRUSH_HISTORY_ACTION = None
        _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
        _DIRECT_BRUSH_HISTORY_TIMER = None
        return False

def _cancel_direct_brush_history_action():
    global _PENDING_DIRECT_BRUSH_HISTORY_ACTION, _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE, _DIRECT_BRUSH_RESTART_BASELINE_READY, _DIRECT_BRUSH_HISTORY_TIMER
    _PENDING_DIRECT_BRUSH_HISTORY_ACTION = None
    _DIRECT_BRUSH_HISTORY_TIMER_ACTIVE = False
    _DIRECT_BRUSH_RESTART_BASELINE_READY = False
    if _DIRECT_BRUSH_HISTORY_TIMER is not None:
        _lifecycle.unregister_timer(_DIRECT_BRUSH_HISTORY_TIMER)
    _DIRECT_BRUSH_HISTORY_TIMER = None

def _sync_active_direct_brush_runtime_tool(context, tool):
    inst = _active_direct_brush_instance()
    if inst is None or not tool:
        return False
    try:
        tool = str(tool)
        inst._active_tool = tool
        if not bool(getattr(inst, '_is_stroking', False)):
            inst._stroke_tool = tool
        try:
            inst._set_status(context)
        except Exception:
            pass
        try:
            inst._tag_redraw()
        except Exception:
            pass
        return True
    except Exception:
        return False

def _update_active_direct_brush_tool(context, tool, *, sync_settings=True):
    inst = _active_direct_brush_instance()
    if inst is None or not tool:
        return False
    try:
        if sync_settings and hasattr(inst, '_set_active_tool'):
            inst._set_active_tool(context, tool)
            return True
        return _sync_active_direct_brush_runtime_tool(context, tool)
    except Exception:
        return False
    return False

def _event_pressure(event):
    try:
        value = float(getattr(event, 'pressure', 1.0))
    except Exception:
        value = 1.0
    if value <= 0.0:
        value = 1.0
    return _clamp(value, 0.0, 1.0)

def _effective_brush_radius(settings, pressure=1.0):
    radius = max(1.0, float(getattr(settings, 'brush_radius', 80.0)))
    if bool(getattr(settings, 'brush_use_pressure_size', False)):
        radius *= max(0.05, float(pressure))
    return max(1.0, radius)

def _effective_brush_strength(settings, pressure=1.0):
    strength = _clamp(float(getattr(settings, 'brush_strength', getattr(settings, 'strength', 0.35))))
    if bool(getattr(settings, 'brush_use_pressure_strength', False)):
        strength *= max(0.0, float(pressure))
    return _clamp(strength)

def _effective_brush_amount(settings):
    return float(getattr(settings, 'brush_amount', getattr(settings, 'amount', 0.05)))

def _hardened_falloff_weight(ratio, falloff, hardness):
    hardness = _clamp(float(hardness), 0.0, 0.98)
    ratio = _clamp(float(ratio), 0.0, 1.0)
    if ratio <= hardness:
        return 1.0
    scaled = (ratio - hardness) / max(1e-08, 1.0 - hardness)
    return _brush_falloff_weight(scaled, falloff)

def _average_target_normal(targets, fallback):
    acc = Vector((0.0, 0.0, 0.0))
    total = 0.0
    for v, weight in targets:
        if v.hide:
            continue
        n = v.normal.copy()
        if n.length_squared <= 1e-12:
            continue
        n.normalize()
        w = max(0.0, float(weight))
        acc += n * w
        total += w
    if total <= 1e-08 or acc.length_squared <= 1e-12:
        return fallback.copy()
    acc.normalize()
    return acc

def _brush_falloff_weight(ratio, falloff):
    x = _clamp(float(ratio), 0.0, 1.0)
    t = 1.0 - x
    if falloff == 'CONSTANT':
        return 1.0
    if falloff == 'LINEAR':
        return t
    if falloff == 'ROUND':
        return math.sqrt(max(0.0, 1.0 - x * x))
    if falloff == 'SHARP':
        return t * t
    return t * t * (3.0 - 2.0 * t)

def _view3d_space_for_area(area):
    if area is None or getattr(area, 'type', None) != 'VIEW_3D':
        return None
    try:
        active = getattr(getattr(area, 'spaces', None), 'active', None)
        if getattr(active, 'type', None) == 'VIEW_3D':
            return active
    except Exception:
        pass
    try:
        for space in getattr(area, 'spaces', []) or []:
            if getattr(space, 'type', None) == 'VIEW_3D':
                return space
    except Exception:
        pass
    return None

def _view3d_window_view_tuples(area):
    """Return (region, rv3d) pairs for every usable View3D WINDOW region.

    Quad View and split View3D layouts expose multiple WINDOW regions.  A
    modal operator keeps receiving events after launch, but Blender does not
    automatically swap the operator's stored region_data when the pointer moves
    into another quadrant or another View3D area.  The brush therefore resolves
    the region/RegionView3D pair from the current mouse coordinates for each
    pointer event.
    """
    space = _view3d_space_for_area(area)
    if space is None:
        return []
    try:
        regions = [r for r in getattr(area, 'regions', []) or [] if getattr(r, 'type', None) == 'WINDOW']
    except Exception:
        regions = []
    if not regions:
        return []
    try:
        quadviews = list(getattr(space, 'region_quadviews', []) or [])
    except Exception:
        quadviews = []
    default_rv3d = getattr(space, 'region_3d', None)
    pairs = []
    for index, region in enumerate(regions):
        rv3d = None
        try:
            candidate = getattr(region, 'data', None)
            if candidate is not None and getattr(candidate, 'view_matrix', None) is not None:
                rv3d = candidate
        except Exception:
            rv3d = None
        if rv3d is None and index < len(quadviews):
            try:
                rv3d = quadviews[index]
            except Exception:
                rv3d = None
        if rv3d is None:
            rv3d = default_rv3d
        if rv3d is None:
            continue
        pairs.append((region, rv3d))
    return pairs

def _view3d_window_region(context):
    area = getattr(context, 'area', None)
    space = _view3d_space_for_area(area)
    if area is not None and getattr(area, 'type', None) == 'VIEW_3D' and (space is not None):
        ctx_region = getattr(context, 'region', None)
        ctx_rv3d = getattr(context, 'region_data', None)
        if getattr(ctx_region, 'type', None) == 'WINDOW' and ctx_rv3d is not None:
            return (area, ctx_region, ctx_rv3d)
        pairs = _view3d_window_view_tuples(area)
        if pairs:
            region, rv3d = pairs[0]
            return (area, region, rv3d)
    return (None, None, None)

def _event_view3d_window_region(context, event):
    """Compatibility wrapper returning the live View3D target under an event."""
    target = _view3d_event_target(context, event)
    if isinstance(target, dict) and target.get('viewport', False):
        area = target.get('area')
        region = target.get('region')
        rv3d = target.get('rv3d')
        if area is not None and region is not None and (rv3d is not None):
            return (area, region, rv3d)
    return None

def _event_region_mouse(event, region):
    return Vector((float(event.mouse_x - region.x), float(event.mouse_y - region.y)))

def _mouse_inside_region(mouse, region):
    return 0.0 <= mouse.x <= float(region.width) and 0.0 <= mouse.y <= float(region.height)

def _active_view3d_space(area):
    """Return the active 3D View space for an area without relying on stale context."""
    try:
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return None
        active = getattr(getattr(area, 'spaces', None), 'active', None)
        if active is not None and getattr(active, 'type', None) == 'VIEW_3D':
            return active
        for space in getattr(area, 'spaces', []) or []:
            if getattr(space, 'type', None) == 'VIEW_3D':
                return space
    except Exception:
        pass
    return None

def _view3d_window_region_from_area(area):
    try:
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return (None, None, None)
        space = _active_view3d_space(area)
        if space is None:
            return (None, None, None)
        window_region = None
        for region in getattr(area, 'regions', []) or []:
            if getattr(region, 'type', None) == 'WINDOW':
                window_region = region
                break
        rv3d = getattr(space, 'region_3d', None)
        if window_region is None or rv3d is None:
            return (None, None, None)
        return (area, window_region, rv3d)
    except Exception:
        return (None, None, None)

def _event_inside_area_bounds(event, area, margin=0.0):
    if area is None or not _event_has_window_xy(event):
        return False
    try:
        x = float(event.mouse_x)
        y = float(event.mouse_y)
        ax = float(getattr(area, 'x', 0.0) or 0.0) - float(margin)
        ay = float(getattr(area, 'y', 0.0) or 0.0) - float(margin)
        aw = float(getattr(area, 'width', 0.0) or 0.0) + float(margin) * 2.0
        ah = float(getattr(area, 'height', 0.0) or 0.0) + float(margin) * 2.0
        return aw > 1.0 and ah > 1.0 and (ax <= x <= ax + aw) and (ay <= y <= ay + ah)
    except Exception:
        return False

def _iter_view3d_areas_from_context(context):
    try:
        screen = getattr(context, 'screen', None)
        window = getattr(context, 'window', None)
        if screen is None and window is not None:
            screen = getattr(window, 'screen', None)
        if screen is None:
            return []
        return [area for area in getattr(screen, 'areas', []) or [] if getattr(area, 'type', None) == 'VIEW_3D']
    except Exception:
        return []

def _quadview_index_from_mouse(region, mouse):
    """Map coordinates in a full-size quad-view region to RegionView3D index.

    Blender 5.1 exposes quad-view RegionView3D entries in this visual order:
    bottom-left, top-left, bottom-right, top-right.  Usually Blender also
    exposes four quarter-sized WINDOW regions and the add-on uses the direct
    region-to-RegionView3D pair instead.  This fallback is only for the short
    interval immediately after entering Quad View where WINDOW regions can still
    report the same full bounds.
    """
    try:
        width = max(1.0, float(getattr(region, 'width', 0.0) or 0.0))
        height = max(1.0, float(getattr(region, 'height', 0.0) or 0.0))
        x = _clamp(float(mouse.x) / width, 0.0, 1.0)
        y = _clamp(float(mouse.y) / height, 0.0, 1.0)
        right = x >= 0.5
        top = y >= 0.5
        if not top and (not right):
            return 0
        if top and (not right):
            return 1
        if not top and right:
            return 2
        return 3
    except Exception:
        return 3

def _region_view3d_for_mouse(space, region, mouse):
    if space is None:
        return None
    try:
        quadviews = list(getattr(space, 'region_quadviews', []) or [])
    except Exception:
        quadviews = []
    if len(quadviews) >= 4:
        index = _quadview_index_from_mouse(region, mouse)
        try:
            return quadviews[index]
        except Exception:
            pass
    try:
        return getattr(space, 'region_3d', None)
    except Exception:
        return None

def _view3d_event_target(context, event, prefer_area=None):
    """Resolve the exact brushable View3D target under the current event."""
    if event is None or not _event_has_window_xy(event):
        return None
    areas = _iter_view3d_areas_from_context(context)
    ctx_area = getattr(context, 'area', None)
    try:
        if ctx_area is not None and getattr(ctx_area, 'type', None) == 'VIEW_3D' and (ctx_area not in areas):
            areas.insert(0, ctx_area)
    except Exception:
        pass
    if not areas:
        return None
    ordered = []
    for candidate in (prefer_area, ctx_area):
        try:
            if candidate is not None and getattr(candidate, 'type', None) == 'VIEW_3D' and (candidate in areas) and (candidate not in ordered):
                ordered.append(candidate)
        except Exception:
            pass
    for area in areas:
        if area not in ordered:
            ordered.append(area)
    for area in ordered:
        if getattr(area, 'type', None) != 'VIEW_3D':
            continue
        if not _event_inside_area_bounds(event, area, margin=0.0):
            continue
        pairs = _view3d_window_view_tuples(area)
        if not pairs:
            return {'area': area, 'region': None, 'rv3d': None, 'mouse': None, 'viewport': False, 'priority_ui': False}
        if _event_inside_view3d_priority_ui_region(event, area, window_region=None):
            return {'area': area, 'region': None, 'rv3d': None, 'mouse': None, 'viewport': False, 'priority_ui': True}
        matches = []
        for region, rv3d in pairs:
            if _event_inside_region_bounds(event, region, margin=0.0, default=False):
                matches.append((region, rv3d))
        if not matches:
            fallback_area, fallback_region, fallback_rv3d = _view3d_window_region_from_area(area)
            return {'area': fallback_area, 'region': fallback_region, 'rv3d': fallback_rv3d, 'mouse': None, 'viewport': False, 'priority_ui': False}

        def _region_area(pair):
            region = pair[0]
            try:
                return float(getattr(region, 'width', 0.0) or 0.0) * float(getattr(region, 'height', 0.0) or 0.0)
            except Exception:
                return 1e+30
        matches.sort(key=_region_area)
        region, rv3d = matches[0]
        mouse = _event_region_mouse(event, region)
        try:
            if len(matches) > 1:
                first = matches[0][0]
                same_bounds = all((abs(float(getattr(r, 'x', 0.0) or 0.0) - float(getattr(first, 'x', 0.0) or 0.0)) <= 1.0 and abs(float(getattr(r, 'y', 0.0) or 0.0) - float(getattr(first, 'y', 0.0) or 0.0)) <= 1.0 and (abs(float(getattr(r, 'width', 0.0) or 0.0) - float(getattr(first, 'width', 0.0) or 0.0)) <= 1.0) and (abs(float(getattr(r, 'height', 0.0) or 0.0) - float(getattr(first, 'height', 0.0) or 0.0)) <= 1.0) for r, _rv in matches))
                if same_bounds:
                    fallback_rv3d = _region_view3d_for_mouse(_active_view3d_space(area), region, mouse)
                    if fallback_rv3d is not None:
                        rv3d = fallback_rv3d
        except Exception:
            pass
        if _event_inside_view3d_priority_ui_region(event, area, window_region=region):
            return {'area': area, 'region': region, 'rv3d': rv3d, 'mouse': None, 'viewport': False, 'priority_ui': True}
        if rv3d is None:
            return {'area': area, 'region': region, 'rv3d': None, 'mouse': None, 'viewport': False, 'priority_ui': False}
        return {'area': area, 'region': region, 'rv3d': rv3d, 'mouse': mouse, 'viewport': True, 'priority_ui': False}
    return None

def _same_view3d_target(area_a, region_a, rv3d_a, area_b, region_b, rv3d_b):
    try:
        return _state_area_pointer(area_a) == _state_area_pointer(area_b) and _state_region_pointer(region_a) == _state_region_pointer(region_b) and (_state_region_pointer(rv3d_a) == _state_region_pointer(rv3d_b))
    except Exception:
        return area_a is area_b and region_a is region_b and (rv3d_a is rv3d_b)

def _ray_local_from_mouse(region, rv3d, obj, mouse):
    coord = (float(mouse.x), float(mouse.y))
    origin_world = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction_world = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    if direction_world.length_squared <= 1e-12:
        return (None, None, None, None)
    direction_world.normalize()
    inv = obj.matrix_world.inverted()
    origin_local = inv @ origin_world
    direction_local = inv.to_3x3() @ direction_world
    if direction_local.length_squared <= 1e-12:
        return (None, None, None, None)
    direction_local.normalize()
    return (origin_world, direction_world, origin_local, direction_local)

def _surface_hit_from_mouse(region, rv3d, obj, bm, mouse):
    bm.faces.ensure_lookup_table()
    bm.faces.index_update()
    origin_world, direction_world, origin_local, direction_local = _ray_local_from_mouse(region, rv3d, obj, mouse)
    if origin_local is None:
        return None
    try:
        bvh = BVHTree.FromBMesh(bm, epsilon=0.0)
        loc, normal, face_index, distance = bvh.ray_cast(origin_local, direction_local)
    except Exception:
        return None
    if loc is None:
        return None
    if face_index is not None and 0 <= face_index < len(bm.faces):
        if bm.faces[face_index].hide:
            return None
    if normal.length_squared <= 1e-12:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal.normalize()
    return {'local': loc.copy(), 'world': obj.matrix_world @ loc, 'normal_local': normal.copy(), 'face_index': face_index, 'distance': distance, 'ray_direction_local': direction_local.copy(), 'ray_direction_world': direction_world.copy()}

def _screen_radius_to_local(region, rv3d, obj, mouse, radius_px, hit_world, hit_local):
    try:
        edge_world = view3d_utils.region_2d_to_location_3d(region, rv3d, (float(mouse.x + radius_px), float(mouse.y)), hit_world)
        edge_local = obj.matrix_world.inverted() @ edge_world
        return max(1e-08, (edge_local - hit_local).length)
    except Exception:
        return 0.0

def _brush_targets_from_mouse(region, rv3d, obj, bm, mouse, settings, hit, pressure=1.0):
    bm.verts.ensure_lookup_table()
    radius = _effective_brush_radius(settings, pressure)
    local_radius = _screen_radius_to_local(region, rv3d, obj, mouse, radius, hit['world'], hit['local'])
    ray_dir = hit.get('ray_direction_local', Vector((0.0, 0.0, -1.0)))
    falloff = getattr(settings, 'brush_falloff', 'SMOOTH')
    hardness = float(getattr(settings, 'brush_hardness', 0.0))
    front_only = bool(getattr(settings, 'brush_front_faces_only', True))
    targets = []
    for v in bm.verts:
        if v.hide:
            continue
        if front_only:
            n = v.normal.copy()
            if n.length_squared > 1e-12:
                n.normalize()
                if n.dot(ray_dir) >= 0.0:
                    continue
        if local_radius > 1e-08 and (v.co - hit['local']).length > local_radius * 2.25:
            continue
        try:
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v.co)
        except Exception:
            screen = None
        if screen is None:
            continue
        dist = (Vector((screen.x, screen.y)) - mouse).length
        if dist > radius:
            continue
        weight = _hardened_falloff_weight(dist / radius, falloff, hardness)
        if weight > 1e-06:
            targets.append((v, weight))
    return (targets, local_radius)

def _direct_weight_map(targets):
    return {v: max(w, 0.0) for v, w in targets if w > 1e-06 and (not v.hide)}

def _apply_direct_smooth(bm, targets, settings, tangent=False, sharpen=False):
    bm.normal_update()
    mask = _mask_layer(bm, False)
    strength = _clamp(float(getattr(settings, 'brush_strength', getattr(settings, 'strength', 0.35))))
    coords = {v: v.co.copy() for v in bm.verts if not v.hide}
    updates = {}
    for v, weight in targets:
        if v.hide or v not in coords:
            continue
        avg = _neighbor_average(v, coords)
        delta = avg - coords[v]
        if tangent:
            n = v.normal.copy()
            if n.length_squared > 1e-12:
                n.normalize()
                delta -= n * delta.dot(n)
        if sharpen:
            delta = -delta
        infl = strength * weight * _influence(v, settings, mask)
        if infl > 1e-06:
            updates[v] = coords[v] + delta * infl
    for v, co in updates.items():
        v.co = co
    bm.normal_update()
    return len(updates)
_BRUSH_TOOL_ALIASES = {'MASK_PAINT': 'MASK', 'FACE_SET_PAINT': 'DRAW_FACE_SETS', 'COLOR_PAINT': 'PAINT', 'ELASTIC': 'ELASTIC_DEFORM', 'RELAX': 'TOPOLOGY', 'DENSITY': 'SIMPLIFY', 'TWIST': 'ROTATE', 'FILTER_RELAX': 'TOPOLOGY', 'FILTER_SMOOTH': 'SMOOTH', 'FILTER_SCALE': 'ELASTIC_DEFORM'}
_DIRECT_NON_COORD_TOOLS = {'PAINT_SELECT', 'MASK', 'DRAW_FACE_SETS', 'PAINT'}
_DIRECT_COLOR_COORD_TOOLS = {'BLUR', 'SMEAR'}

def _resolved_direct_tool(tool):
    resolved = _brush_operation(tool or 'DRAW')
    return _BRUSH_TOOL_ALIASES.get(resolved or 'DRAW', resolved or 'DRAW')

def _direct_tool_changes_coordinates(tool):
    return _resolved_direct_tool(tool) not in _DIRECT_NON_COORD_TOOLS

def _direct_tool_needs_mirrored_execution(tool):
    resolved = _resolved_direct_tool(tool)
    return resolved in _DIRECT_NON_COORD_TOOLS or resolved in _DIRECT_COLOR_COORD_TOOLS

def _ensure_direct_tool_custom_layers(bm, tool):
    """Pre-create custom data layers so BMesh element references stay valid.

    Adding a BMesh custom-data layer can invalidate previously held BMVert/BMFace
    Python wrappers on some Blender builds.  Direct brush mirroring stores target
    references for the original and mirrored sides, so layers are created before
    target lists are built.
    """
    resolved = _resolved_direct_tool(tool)
    if resolved == 'MASK':
        _mask_layer(bm, True)
    elif resolved == 'DRAW_FACE_SETS':
        _face_set_layer(bm, True)
    elif resolved in {'PAINT', 'SMEAR', 'BLUR'}:
        _color_layer(bm, True)
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.faces.index_update()
    except Exception:
        pass

def _loop_color_vector(loop, layer):
    try:
        return Vector(loop[layer])
    except Exception:
        return Vector((0.0, 0.0, 0.0, 1.0))

def _apply_direct_color_blur(bm, targets, settings, layer):
    if layer is None:
        return 0
    strength = _clamp(float(getattr(settings, 'brush_strength', 0.35)))
    weight_map = _direct_weight_map(targets)
    source = {}
    for f in bm.faces:
        if f.hide:
            continue
        for loop in f.loops:
            source[loop] = _loop_color_vector(loop, layer)
    if not source:
        return 0
    changed = 0
    for f in bm.faces:
        if f.hide:
            continue
        for loop in f.loops:
            weight = weight_map.get(loop.vert, 0.0)
            if weight <= 1e-06:
                continue
            values = [source.get(loop)]
            for edge in loop.vert.link_edges:
                other = edge.other_vert(loop.vert)
                for linked_loop in other.link_loops:
                    if linked_loop in source:
                        values.append(source[linked_loop])
            avg = Vector((0.0, 0.0, 0.0, 0.0))
            count = 0
            for value in values:
                if value is None:
                    continue
                avg += value
                count += 1
            if count:
                avg /= count
                loop[layer] = source[loop].lerp(avg, _clamp(strength * weight))
                changed += 1
    return changed

def _apply_direct_color_smear(bm, targets, settings, hit_local, layer):
    if layer is None:
        return 0
    strength = _clamp(float(getattr(settings, 'brush_strength', 0.35)))
    weight_map = _direct_weight_map(targets)
    source = {}
    nearest_color = None
    nearest_distance = 1e+30
    for f in bm.faces:
        if f.hide:
            continue
        for loop in f.loops:
            value = _loop_color_vector(loop, layer)
            source[loop] = value
            distance = (loop.vert.co - hit_local).length_squared
            if distance < nearest_distance:
                nearest_distance = distance
                nearest_color = value
    if nearest_color is None:
        nearest_color = Vector(getattr(settings, 'color', (0.8, 0.35, 0.15, 1.0)))
    changed = 0
    for f in bm.faces:
        if f.hide:
            continue
        for loop in f.loops:
            weight = weight_map.get(loop.vert, 0.0)
            if weight <= 1e-06:
                continue
            current = source.get(loop, nearest_color)
            loop[layer] = current.lerp(nearest_color, _clamp(strength * weight * 0.65))
            changed += 1
    return changed

def _is_boundary_vertex(v):
    return any((e.is_boundary for e in v.link_edges))

def _apply_density_brush(bm, targets, settings, sign=1.0):
    weight_map = _direct_weight_map(targets)
    if sign < 0.0:
        return _apply_direct_smooth(bm, targets, settings, tangent=True, sharpen=False)
    edges = []
    threshold = 0.05
    for e in bm.edges:
        if e.hide:
            continue
        w = min(weight_map.get(e.verts[0], 0.0), weight_map.get(e.verts[1], 0.0))
        if w > threshold:
            edges.append(e)
    if not edges:
        return 0
    try:
        bmesh.ops.subdivide_edges(bm, edges=edges, cuts=1, use_grid_fill=True, smooth=0.0)
        bm.normal_update()
        return len(edges)
    except Exception:
        return 0

def _apply_direct_brush_tool(bm, targets, settings, tool, hit_local, normal_local, sign=1.0, pressure=1.0, original_coords=None):
    if not targets:
        return 0
    original_tool = tool or 'DRAW'
    if _brush_is_boundary_limited(original_tool):
        targets = [(v, w) for v, w in targets if _is_boundary_vertex(v)]
        if not targets:
            return 0
    tool = _brush_operation(original_tool)
    if normal_local.length_squared <= 1e-12:
        normal_local = Vector((0.0, 0.0, 1.0))
    else:
        normal_local = normal_local.normalized()
    try:
        normal_blend = _clamp(float(getattr(settings, 'brush_normal_radius', 0.0)))
    except Exception:
        normal_blend = 0.0
    if normal_blend > 1e-06:
        averaged = _average_target_normal(targets, normal_local)
        mixed = normal_local.lerp(averaged, normal_blend)
        if mixed.length_squared > 1e-12:
            mixed.normalize()
            normal_local = mixed
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.verts.index_update()
    bm.normal_update()
    tool = _BRUSH_TOOL_ALIASES.get(tool or 'DRAW', tool or 'DRAW')
    target_indices = [(v.index, weight) for v, weight in targets if not v.hide and v.index >= 0]
    precreated_mask_layer = _mask_layer(bm, True) if tool == 'MASK' else None
    precreated_face_set_layer = _face_set_layer(bm, True) if tool == 'DRAW_FACE_SETS' else None
    precreated_color_layer = _color_layer(bm, True) if tool in {'PAINT', 'SMEAR', 'BLUR'} else None
    if precreated_mask_layer is not None or precreated_face_set_layer is not None or precreated_color_layer is not None:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        targets = [(bm.verts[index], weight) for index, weight in target_indices if 0 <= index < len(bm.verts) and (not bm.verts[index].hide)]
    strength = _effective_brush_strength(settings, pressure)
    amount = _effective_brush_amount(settings)
    signed_amount = amount * (1.0 if sign >= 0.0 else -1.0)
    runtime_settings = _settings_proxy(settings, brush_strength=strength, brush_amount=amount)
    mask = _mask_layer(bm, False)
    original_coords = original_coords if isinstance(original_coords, dict) else None
    coords = {}
    for v in bm.verts:
        if v.hide:
            continue
        if original_coords is not None and v.index in original_coords:
            coords[v] = original_coords[v.index].copy()
        else:
            coords[v] = v.co.copy()
    weight_map = _direct_weight_map(targets)
    if tool in {'SMOOTH', 'DISPLACEMENT_ERASER', 'SIMPLIFY'}:
        return _apply_direct_smooth(bm, targets, runtime_settings, tangent=False, sharpen=False)
    if tool in {'TOPOLOGY'}:
        return _apply_direct_smooth(bm, targets, runtime_settings, tangent=True, sharpen=False)
    if tool == 'FILTER_SHARPEN':
        return _apply_direct_smooth(bm, targets, runtime_settings, tangent=False, sharpen=True)
    if tool == 'BLUR':
        color_changed = _apply_direct_color_blur(bm, targets, runtime_settings, precreated_color_layer)
        smooth_changed = _apply_direct_smooth(bm, targets, runtime_settings, tangent=False, sharpen=False)
        return max(color_changed, smooth_changed)
    if tool == 'SMEAR':
        color_changed = _apply_direct_color_smear(bm, targets, runtime_settings, hit_local, precreated_color_layer)
        smooth_changed = _apply_direct_smooth(bm, targets, runtime_settings, tangent=True, sharpen=False)
        return max(color_changed, smooth_changed)
    if tool == 'PAINT_SELECT':
        select_value = sign >= 0.0
        touched_verts = {v for v, weight in targets if weight > 1e-06 and (not v.hide)}
        select_mode = set(getattr(bm, 'select_mode', set()))
        if not select_mode:
            select_mode = {'VERT'}
        for v in touched_verts:
            v.select_set(select_value)
        if 'EDGE' in select_mode:
            for e in bm.edges:
                if e.hide:
                    continue
                if select_value and all((v in touched_verts for v in e.verts)):
                    e.select_set(True)
                elif not select_value and any((v in touched_verts for v in e.verts)):
                    e.select_set(False)
        if 'FACE' in select_mode:
            for f in bm.faces:
                if f.hide:
                    continue
                if select_value and any((v in touched_verts for v in f.verts)):
                    f.select_set(True)
                elif not select_value and any((v in touched_verts for v in f.verts)):
                    f.select_set(False)
        try:
            bm.select_flush_mode()
        except Exception:
            pass
        return len(touched_verts)
    if tool == 'MASK':
        layer = precreated_mask_layer or _mask_layer(bm, True)
        changed = 0
        for v, weight in targets:
            if v.hide:
                continue
            delta = strength * weight * (1.0 if sign >= 0.0 else -1.0)
            v[layer] = _clamp(float(v[layer]) + delta)
            changed += 1
        return changed
    if tool == 'DRAW_FACE_SETS':
        layer = precreated_face_set_layer or _face_set_layer(bm, True)
        face_set_id = int(getattr(settings, 'face_set_id', 1)) if sign >= 0.0 else 0
        changed = 0
        for f in bm.faces:
            if f.hide:
                continue
            if any((weight_map.get(v, 0.0) > 0.05 for v in f.verts)):
                f[layer] = face_set_id
                changed += 1
        return changed
    if tool == 'PAINT':
        layer = precreated_color_layer or _color_layer(bm, True)
        target_color = Vector(getattr(settings, 'color', (0.8, 0.35, 0.15, 1.0)))
        if sign < 0.0:
            target_color = Vector((0.0, 0.0, 0.0, target_color[3]))
        changed = 0
        for f in bm.faces:
            if f.hide:
                continue
            for loop in f.loops:
                weight = weight_map.get(loop.vert, 0.0)
                if weight <= 1e-06:
                    continue
                current = Vector(loop[layer])
                loop[layer] = current.lerp(target_color, _clamp(strength * weight))
                changed += 1
        return changed
    updates = {}
    for v, weight in targets:
        if v.hide or v not in coords:
            continue
        infl = strength * weight * _influence(v, settings, mask)
        if infl <= 1e-06:
            continue
        co = coords[v]
        n = v.normal.copy()
        if n.length_squared <= 1e-12:
            n = normal_local.copy()
        else:
            n.normalize()
        target = co.copy()
        if tool == 'DRAW':
            target = co + n * signed_amount
        elif tool == 'DRAW_SHARP':
            target = co + n * signed_amount * 0.9 + (hit_local - co) * 0.18 * abs(sign)
        elif tool == 'CLAY':
            target = co + normal_local * signed_amount * 0.8
        elif tool == 'CLAY_STRIPS':
            plane_dist = (co - hit_local).dot(normal_local)
            target = co + normal_local * signed_amount * 0.65 - normal_local * plane_dist * 0.25
        elif tool == 'CLAY_THUMB':
            plane_dist = (co - hit_local).dot(normal_local)
            tangent = hit_local - co
            if tangent.length_squared > 1e-12:
                tangent -= normal_local * tangent.dot(normal_local)
            target = co + normal_local * signed_amount * 0.45 - normal_local * plane_dist * 0.18 + tangent * 0.18
        elif tool == 'LAYER':
            plane_dist = (co - hit_local).dot(normal_local)
            target = co + normal_local * signed_amount * 0.55 - normal_local * plane_dist * 0.12
        elif tool == 'BLOB':
            radial = co - hit_local
            radial_dir = radial.normalized() if radial.length_squared > 1e-12 else n
            target = co + n * signed_amount + radial_dir * abs(signed_amount) * 0.35 * (1.0 if sign >= 0.0 else -1.0)
        elif tool == 'CREASE':
            target = co - n * abs(amount) * (1.0 if sign >= 0.0 else -1.0) + (hit_local - co) * 0.35
        elif tool in {'FLATTEN', 'FILL', 'SCRAPE', 'PLANE', 'MULTIPLANE_SCRAPE'}:
            plane_offset = float(getattr(settings, 'brush_plane_offset', 0.0)) * amount
            plane_point = hit_local + normal_local * plane_offset
            plane_dist = (co - plane_point).dot(normal_local)
            active_tool = 'FLATTEN' if tool in {'PLANE', 'MULTIPLANE_SCRAPE'} else tool
            if sign < 0.0:
                if active_tool == 'FILL':
                    active_tool = 'SCRAPE'
                elif active_tool == 'SCRAPE':
                    active_tool = 'FILL'
            if active_tool == 'FILL' and plane_dist >= 0.0:
                continue
            if active_tool == 'SCRAPE' and plane_dist <= 0.0:
                continue
            scrape_factor = 1.35 if tool == 'MULTIPLANE_SCRAPE' else 1.0
            target = co - normal_local * plane_dist * scrape_factor
        elif tool == 'INFLATE':
            target = co + n * abs(amount) * (1.0 if sign >= 0.0 else -1.0)
        elif tool == 'DEFLATE':
            target = co - n * abs(amount) * (1.0 if sign >= 0.0 else -1.0)
        elif tool == 'PINCH':
            target = co.lerp(hit_local, 0.65)
        elif tool == 'GRAB':
            target = co + normal_local * signed_amount
        elif tool == 'SNAKE_HOOK':
            target = co + normal_local * signed_amount + (co - hit_local) * 0.25
        elif tool in {'ELASTIC_DEFORM', 'CLOTH'}:
            scale_factor = 1.0 + signed_amount * (0.75 if tool == 'CLOTH' else 1.0)
            target = hit_local + (co - hit_local) * scale_factor
        elif tool == 'THUMB':
            tangent = co - hit_local
            if tangent.length_squared > 1e-12:
                tangent -= normal_local * tangent.dot(normal_local)
                tangent.normalize()
            else:
                tangent = Vector((1.0, 0.0, 0.0))
            target = co + tangent * signed_amount
        elif tool == 'NUDGE':
            tangent = normal_local.cross(Vector((0.0, 0.0, 1.0)))
            if tangent.length_squared <= 1e-12:
                tangent = normal_local.cross(Vector((0.0, 1.0, 0.0)))
            tangent.normalize()
            target = co + tangent * signed_amount
        elif tool == 'ROTATE':
            angle = signed_amount * 4.0
            mat = Matrix.Rotation(angle, 3, normal_local)
            target = hit_local + mat @ (co - hit_local)
        elif tool == 'BOUNDARY':
            boundary_factor = 1.0 if any((e.is_boundary for e in v.link_edges)) else 0.25
            target = co + normal_local * signed_amount * boundary_factor
        elif tool == 'POSE':
            axis_map = {'X': Vector((1.0, 0.0, 0.0)), 'Y': Vector((0.0, 1.0, 0.0)), 'Z': Vector((0.0, 0.0, 1.0))}
            axis = axis_map.get(getattr(settings, 'pose_axis', 'Z'), Vector((0.0, 0.0, 1.0)))
            angle = math.radians(float(getattr(settings, 'pose_angle', 15.0))) * (1.0 if sign >= 0.0 else -1.0)
            mat = Matrix.Rotation(angle, 3, axis)
            target = hit_local + mat @ (co - hit_local)
        else:
            target = co + n * signed_amount
        updates[v] = co.lerp(target, _clamp(infl))
    for v, co in updates.items():
        v.co = co
    bm.normal_update()
    if tool in {'CLAY', 'CLAY_STRIPS', 'CLAY_THUMB', 'CLOTH'} and updates:
        _apply_direct_smooth(bm, [(v, weight_map.get(v, 0.0) * 0.35) for v in updates], runtime_settings, tangent=True)
    if tool == 'MULTIPLANE_SCRAPE' and updates:
        _apply_direct_smooth(bm, [(v, weight_map.get(v, 0.0) * 0.25) for v in updates], runtime_settings, tangent=False, sharpen=True)
    auto_smooth = _clamp(float(getattr(settings, 'brush_auto_smooth', 0.0)))
    if auto_smooth > 1e-06 and updates and (tool not in {'SMOOTH', 'TOPOLOGY', 'FILTER_SHARPEN', 'MASK', 'DRAW_FACE_SETS', 'PAINT'}):
        smooth_settings = _settings_proxy(settings, brush_strength=auto_smooth)
        _apply_direct_smooth(bm, [(v, weight_map.get(v, 0.0)) for v in updates], smooth_settings, tangent=True)
    return len(updates)

def _apply_direct_drag_target_set(bm, drag_targets, settings, tool, center, normal, delta_local, strength, mask, sign, radius, mouse_delta, pressure=1.0, mirror_sign=None):
    axis_map = {'X': Vector((1.0, 0.0, 0.0)), 'Y': Vector((0.0, 1.0, 0.0)), 'Z': Vector((0.0, 0.0, 1.0))}
    axis = axis_map.get(getattr(settings, 'pose_axis', 'Z'), Vector((0.0, 0.0, 1.0)))
    if mirror_sign is not None:
        axis = _mirror_rotation_axis(axis, mirror_sign)
    updates = 0
    for v, weight, original in drag_targets:
        if v.hide:
            continue
        infl = _clamp(weight * strength * _influence(v, settings, mask))
        if infl <= 1e-06:
            continue
        if tool == 'GRAB':
            target = original + delta_local
        elif tool in {'THUMB', 'NUDGE'}:
            target = original + delta_local * (0.85 if tool == 'THUMB' else 0.45)
        elif tool == 'SNAKE_HOOK':
            radial = original - center
            radial_dir = radial.normalized() if radial.length_squared > 1e-12 else normal
            target = original + delta_local * 1.35 + radial_dir * delta_local.length * 0.15
        elif tool == 'ELASTIC_DEFORM':
            scale = 1.0 + delta_local.length / max(radius, 1e-08) * 0.45 * (1.0 if sign >= 0.0 else -1.0)
            target = center + (original - center) * scale + delta_local * 0.2
        elif tool == 'BOUNDARY':
            is_boundary = any((len(e.link_faces) < 2 for e in v.link_edges))
            target = original + delta_local * (1.0 if is_boundary else 0.2)
        elif tool == 'CLOTH':
            target = original + delta_local * 0.7
        elif tool in {'POSE', 'ROTATE'}:
            angle_scale = mouse_delta.x / max(_effective_brush_radius(settings, pressure), 1.0)
            angle = math.radians(float(getattr(settings, 'pose_angle', 15.0))) * angle_scale * (1.0 if sign >= 0.0 else -1.0)
            rotate_axis = axis if tool == 'POSE' else normal
            if mirror_sign is not None and tool == 'ROTATE' and (_mirror_determinant(mirror_sign) < 0.0):
                rotate_axis = -rotate_axis
            mat = Matrix.Rotation(angle, 3, rotate_axis)
            target = center + mat @ (original - center)
        else:
            target = original + delta_local
        v.co = original.lerp(target, infl)
        updates += 1
    return updates

class SES_OT_DirectBrush(Operator):
    bl_idname = 'strict_edit_sculpt.direct_brush'
    bl_label = 'Direct Edit Brush'
    bl_description = 'Starts an Edit Mode surface brush without entering Sculpt Mode or registering global hotkeys.'
    bl_options = {'UNDO', 'BLOCKING'}
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return not bool(getattr(bpy.app, 'background', False)) and getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' and (_ensure_edit_mesh(context) is not None)

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', '') or getattr(_settings(context), 'brush_tool', 'DRAW')
        title = _tool_label(tool)
        specific = _direct_op_tip(tool)
        if not str(specific).startswith(str(title)):
            specific = title + '\n' + specific
        return specific + '\n' + tr('tip_direct_brush')

    def _tag_redraw(self):
        try:
            self._sync_draw_state()
        except Exception:
            pass
        tagged = set()
        try:
            for area in _iter_view3d_areas_from_context(bpy.context):
                try:
                    ptr = _state_area_pointer(area)
                    if ptr not in tagged:
                        area.tag_redraw()
                        tagged.add(ptr)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            area = getattr(self, '_area', None)
            ptr = _state_area_pointer(area)
            if area is not None and ptr not in tagged:
                area.tag_redraw()
        except Exception:
            pass

    def _set_active_view(self, area, region, rv3d, context=None):
        if area is None or region is None or rv3d is None:
            return False
        old_area = getattr(self, '_area', None)
        old_region = getattr(self, '_region', None)
        old_rv3d = getattr(self, '_rv3d', None)
        changed = old_area is not area or old_region is not region or old_rv3d is not rv3d
        if changed:
            try:
                if old_area is not None:
                    old_area.tag_redraw()
            except Exception:
                pass
        self._area = area
        self._region = region
        self._rv3d = rv3d
        try:
            state = getattr(self, '_draw_state', None)
            if isinstance(state, dict):
                state['area_pointer'] = _state_area_pointer(area)
                state['region_pointer'] = _state_region_pointer(region)
                state['region_width'] = float(getattr(region, 'width', 0.0) or 0.0)
                state['region_height'] = float(getattr(region, 'height', 0.0) or 0.0)
                state['region_x'] = float(getattr(region, 'x', 0.0) or 0.0)
                state['region_y'] = float(getattr(region, 'y', 0.0) or 0.0)
        except Exception:
            pass
        try:
            area.tag_redraw()
        except Exception:
            pass
        return changed

    def _set_status(self, context):
        try:
            _status_runtime.set_service('smart_sculpt_suite.edit_mode_sculpt.brush', f"{tr('brush_active_status')}: {_tool_label(self._active_tool)}   {tr('brush_keys')}", context=context)
        except Exception:
            pass

    def _clear_status(self, context):
        try:
            _status_runtime.clear('smart_sculpt_suite.edit_mode_sculpt.brush', context=context)
        except Exception:
            pass

    def _sync_draw_state(self):
        state = getattr(self, '_draw_state', None)
        if not isinstance(state, dict):
            return
        settings = getattr(self, '_settings_ref', None)
        mouse = getattr(self, '_mouse', Vector((0.0, 0.0)))
        try:
            mouse_xy = (float(mouse.x), float(mouse.y))
        except Exception:
            mouse_xy = (0.0, 0.0)
        try:
            radius = max(1.0, float(getattr(settings, 'brush_radius', 80.0)))
        except Exception:
            radius = 80.0
        try:
            strength = float(getattr(settings, 'brush_strength', 0.35))
        except Exception:
            strength = 0.35
        state.update({'mouse_xy': mouse_xy, 'radius': radius, 'strength': strength,
                      'active_tool': getattr(self, '_active_tool', 'DRAW'),
                      'adjust_mode': getattr(self, '_draw_adjust_mode', '') or getattr(self, '_adjust_mode', ''),
                      'last_ctrl': bool(getattr(self, '_last_ctrl', False)),
                      'last_shift': bool(getattr(self, '_last_shift', False)),
                      'cursor_color': tuple(getattr(self, '_cursor_color', (1.0, 1.0, 1.0, 0.92))),
                      'viewport': _region_viewport_snapshot(getattr(self, '_region', None))})
        _build_direct_brush_packet(state)

    def _add_draw_handler(self, context):
        self._draw_state = {'alive': True, 'packet': _gpu_state.build_packet()}
        self._sync_draw_state()
        try:
            self._draw_handle = _add_tracked_draw_handler(_draw_direct_brush_overlay, self._draw_state, 'WINDOW', 'POST_PIXEL')
        except Exception as exc:
            _runtime_errors.record('direct_brush_draw_handler', exc)
            self._draw_handle = None

    def _remove_draw_handler(self):
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
        for handle in list(getattr(self, '_draw_handles', []) or []):
            _remove_tracked_draw_handler(handle, state)
        self._draw_handles = []
        if getattr(self, '_draw_handle', None) is not None:
            _remove_tracked_draw_handler(self._draw_handle, state)
            self._draw_handle = None
        self._draw_state = None

    def _set_view_target(self, area, region, rv3d):
        if area is None or region is None or rv3d is None:
            return False
        old_area = getattr(self, '_area', None)
        old_region = getattr(self, '_region', None)
        old_rv3d = getattr(self, '_rv3d', None)
        if _same_view3d_target(old_area, old_region, old_rv3d, area, region, rv3d):
            return True
        self._area = area
        self._region = region
        self._rv3d = rv3d
        try:
            if old_area is not None and old_area != area:
                old_area.tag_redraw()
        except Exception:
            pass
        self._tag_redraw()
        return True

    def _event_view_target(self, context, event):
        return _view3d_event_target(context, event, prefer_area=getattr(self, '_area', None))

    def _event_target_matches_current_view(self, target):
        if not isinstance(target, dict) or not target.get('viewport', False):
            return False
        return _same_view3d_target(getattr(self, '_area', None), getattr(self, '_region', None), getattr(self, '_rv3d', None), target.get('area'), target.get('region'), target.get('rv3d'))

    def _activate_event_view(self, target, update_mouse=True):
        if not isinstance(target, dict) or not target.get('viewport', False):
            return False
        self._set_view_target(target.get('area'), target.get('region'), target.get('rv3d'))
        if update_mouse and target.get('mouse') is not None:
            self._mouse = target['mouse'].copy()
        return True

    def _set_active_tool(self, context, tool):
        if not tool:
            return False
        tool = str(tool)
        settings = getattr(self, '_settings_ref', None)
        try:
            old_tool = str(getattr(self, '_active_tool', '') or getattr(settings, 'brush_settings_active_key', '') or getattr(settings, 'brush_tool', 'DRAW') or 'DRAW')
        except Exception:
            old_tool = 'DRAW'
        try:
            if settings is not None:
                _switch_brush_settings_to_tool(settings, tool, old_tool=old_tool)
        except Exception:
            pass
        self._active_tool = tool
        if not getattr(self, '_is_stroking', False):
            self._stroke_tool = tool
        try:
            self._set_status(context)
        except Exception:
            pass
        self._tag_redraw()
        return True

    def _warp_adjust_cursor(self, context):
        anchor = getattr(self, '_adjust_anchor_window', None)
        if anchor is None or getattr(context, 'window', None) is None:
            return
        try:
            context.window.cursor_warp(int(round(anchor[0])), int(round(anchor[1])))
            self._adjust_last_window_x = float(anchor[0])
            self._adjust_last_window_y = float(anchor[1])
            self._adjust_warp_pending = True
        except Exception:
            pass

    def _finish(self, context, report=True):
        """Commit one successful modal operation or rollback an empty one."""
        if bool(getattr(self, '_finish_complete', False)):
            return set(getattr(self, '_finish_result', {'CANCELLED'}))
        self._finish_complete = True
        success = bool(getattr(self, '_did_modify', False))
        transaction = getattr(self, '_transaction', None)
        try:
            if success and transaction is not None:
                transaction.finish()
            elif transaction is not None:
                transaction.cancel()
        except Exception as exc:
            _runtime_errors.record('direct_brush_finish_transaction', exc)
            success = False
        self._transaction = None
        if success:
            try:
                _save_brush_settings_for_tool(getattr(self, '_settings_ref', None), getattr(self, '_active_tool', None))
            except Exception as exc:
                _runtime_errors.record('direct_brush_save_settings', exc)
        self._modal_alive = False
        self._modal_handler_registered = False
        _clear_active_direct_brush(self)
        self._remove_draw_handler()
        self._clear_status(context)
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        self._tag_redraw()
        if report and success:
            self.report({'INFO'}, tr('brush_finished'))
        self._finish_result = {'FINISHED'} if success else {'CANCELLED'}
        return set(self._finish_result)

    def _cancel_session(self, context, reason='cancel'):
        """Idempotent cancellation shared by every abnormal/explicit exit."""
        if bool(getattr(self, '_finish_complete', False)):
            return set(getattr(self, '_finish_result', {'CANCELLED'}))
        if bool(getattr(self, '_cancel_complete', False)):
            return {'CANCELLED'}
        self._cancel_complete = True
        self._finish_complete = True
        self._finish_result = {'CANCELLED'}
        try:
            if getattr(self, '_adjust_mode', ''):
                self._finish_adjust(context=context, cancel=True)
        except Exception:
            pass
        self._is_stroking = False
        self._stroke_changed = False
        self._modal_alive = False
        self._modal_handler_registered = False
        transaction = getattr(self, '_transaction', None)
        try:
            if transaction is not None:
                transaction.cancel()
        except Exception as exc:
            _runtime_errors.record(f'direct_brush_cancel:{reason}', exc)
        self._transaction = None
        _clear_active_direct_brush(self)
        self._remove_draw_handler()
        self._clear_status(context)
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        self._tag_redraw()
        return {'CANCELLED'}

    def cancel(self, context):
        self._cancel_session(context, 'blender_cancel')

    def _current_bmesh(self):
        obj = getattr(self, '_obj', None)
        if obj is None or obj.mode != 'EDIT':
            return None
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def _ensure_session_undo_baseline(self):
        """Mark the one modal transaction as modified without pushing Undo."""
        self._session_undo_pushed = True
        return True

    def _apply_sample(self, context, mouse, event):
        obj = _ensure_edit_mesh(context)
        if obj is None or obj != self._obj:
            return False
        bm = self._current_bmesh()
        if bm is None:
            return False
        hit = _surface_hit_from_mouse(self._region, self._rv3d, obj, bm, mouse)
        self._last_hit = hit
        if hit is None:
            return False
        settings = self._settings_ref
        pressure = _event_pressure(event)
        tool = 'SMOOTH' if event.shift else self._stroke_tool
        targets, _local_radius = _brush_targets_from_mouse(self._region, self._rv3d, obj, bm, mouse, settings, hit, pressure=pressure)
        if not targets:
            return False
        target_indices = [(v.index, weight) for v, weight in targets if not v.hide and v.index >= 0]
        if not target_indices:
            return False
        if not self._ensure_session_undo_baseline():
            return False
        _ensure_direct_tool_custom_layers(bm, tool)
        bm.verts.ensure_lookup_table()
        targets = [(bm.verts[index], weight) for index, weight in target_indices if 0 <= index < len(bm.verts) and (not bm.verts[index].hide)]
        if not targets:
            return False
        sign = -1.0 if event.ctrl else 1.0
        if getattr(settings, 'brush_direction', 'ADD') == 'SUBTRACT':
            sign *= -1.0
        before_coords = _mirror_coords_from_bmesh(bm) if _mesh_mirror_enabled(obj) else None
        mirror_groups = _mirror_direct_target_groups(obj, bm, targets, before_coords=before_coords, skip_source=True) if before_coords else []
        original_map = self._stroke_original_map()
        changed = _apply_direct_brush_tool(bm, targets, settings, tool, hit['local'], hit['normal_local'], sign=sign, pressure=pressure, original_coords=original_map)
        if before_coords is not None and _direct_tool_needs_mirrored_execution(tool):
            for mirror_sign, mirror_targets in mirror_groups:
                mirror_hit = _mirror_vector(hit['local'], mirror_sign)
                mirror_normal = _mirror_vector(hit['normal_local'], mirror_sign)
                if mirror_normal.length_squared <= 1e-12:
                    mirror_normal = Vector((0.0, 0.0, 1.0))
                changed += _apply_direct_brush_tool(bm, mirror_targets, settings, tool, mirror_hit, mirror_normal, sign=sign, pressure=pressure, original_coords=original_map)
        if before_coords is not None and _direct_tool_changes_coordinates(tool):
            changed += _mirror_changed_vertex_coordinates(obj, bm, before_coords, [v for v, _weight in targets])
        if changed:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            if _brush_operation(tool) == 'MASK':
                _refresh_mask_lock_anchors(obj)
            self._did_modify = True
            self._stroke_changed = True
            return True
        return False

    def _begin_drag(self, context, mouse, event):
        obj = _ensure_edit_mesh(context)
        bm = self._current_bmesh()
        if obj is None or bm is None:
            return False
        hit = _surface_hit_from_mouse(self._region, self._rv3d, obj, bm, mouse)
        self._last_hit = hit
        if hit is None:
            return False
        settings = self._settings_ref
        pressure = _event_pressure(event)
        targets, local_radius = _brush_targets_from_mouse(self._region, self._rv3d, obj, bm, mouse, settings, hit, pressure=pressure)
        if not targets:
            return False
        bm.verts.index_update()
        before_coords = _mirror_coords_from_bmesh(bm) if _mesh_mirror_enabled(obj) else None
        self._drag_start_mouse = mouse.copy()
        self._drag_hit_world = hit['world'].copy()
        self._drag_hit_local = hit['local'].copy()
        self._drag_normal_local = hit['normal_local'].copy()
        self._drag_local_radius = max(local_radius, 1e-08)
        # BMVert references do not survive from one modal event to the next: keep indices.
        self._drag_targets = [(v.index, w, v.co.copy()) for v, w in targets if not v.hide]
        self._drag_mirror_targets = [
            (mirror_sign, [(v.index, w, co) for v, w, co in group])
            for mirror_sign, group in (_mirror_drag_target_groups(obj, bm, [(v, w) for v, w in targets if not v.hide], before_coords=before_coords) if before_coords else [])
        ]
        self._drag_mirror_coords = before_coords
        self._drag_mirror_lookup = _mirror_lookup_from_coords(before_coords) if before_coords else None
        return bool(self._drag_targets)

    def _apply_drag(self, context, mouse, event):
        obj = _ensure_edit_mesh(context)
        if obj is None or obj != self._obj or (not self._drag_targets):
            return False
        bm = self._current_bmesh()
        if bm is None:
            return False
        settings = self._settings_ref
        try:
            start_world = view3d_utils.region_2d_to_location_3d(self._region, self._rv3d, self._drag_start_mouse, self._drag_hit_world)
            current_world = view3d_utils.region_2d_to_location_3d(self._region, self._rv3d, mouse, self._drag_hit_world)
        except Exception:
            return False
        pressure = _event_pressure(event)
        sign = -1.0 if event.ctrl else 1.0
        if getattr(settings, 'brush_direction', 'ADD') == 'SUBTRACT':
            sign *= -1.0
        delta_world = (current_world - start_world) * sign
        delta_local = obj.matrix_world.inverted().to_3x3() @ delta_world
        strength = _effective_brush_strength(settings, pressure)
        mask = _mask_layer(bm, False)
        tool = _BRUSH_TOOL_ALIASES.get(_brush_operation(self._stroke_tool), _brush_operation(self._stroke_tool))
        if event.shift:
            return self._apply_sample(context, mouse, event)
        mouse_delta = mouse - self._drag_start_mouse
        if strength <= 1e-06:
            return False
        if tool in {'POSE', 'ROTATE'}:
            has_motion = abs(float(mouse_delta.x)) > 1e-06
        else:
            has_motion = delta_local.length_squared > 1e-16
        if not has_motion:
            return False
        if not self._ensure_session_undo_baseline():
            return False
        center = self._drag_hit_local
        radius = max(self._drag_local_radius, 1e-08)
        bm.verts.ensure_lookup_table()
        vert_count = len(bm.verts)
        def _live(group):
            return [(bm.verts[index], w, co) for index, w, co in group if 0 <= index < vert_count]
        updates = _apply_direct_drag_target_set(bm, _live(self._drag_targets), settings, tool, center, self._drag_normal_local, delta_local, strength, mask, sign, radius, mouse_delta, pressure=pressure, mirror_sign=None)
        for mirror_sign, mirror_targets in getattr(self, '_drag_mirror_targets', []) or []:
            mirror_center = _mirror_vector(center, mirror_sign)
            mirror_normal = _mirror_vector(self._drag_normal_local, mirror_sign)
            mirror_delta = _mirror_vector(delta_local, mirror_sign)
            updates += _apply_direct_drag_target_set(bm, _live(mirror_targets), settings, tool, mirror_center, mirror_normal, mirror_delta, strength, mask, sign, radius, mouse_delta, pressure=pressure, mirror_sign=mirror_sign)
        if updates and getattr(self, '_drag_mirror_coords', None) is not None:
            _mirror_changed_vertex_coordinates(obj, bm, self._drag_mirror_coords, [v for v, _w, _co in _live(self._drag_targets)], lookup=self._drag_mirror_lookup)
        if updates:
            bm.normal_update()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            self._did_modify = True
            self._stroke_changed = True
            return True
        return False

    def _stroke_to_mouse(self, context, mouse, event):
        settings = self._settings_ref
        mouse = self._stabilized_mouse(mouse)
        pressure = _event_pressure(event)
        spacing = max(1.0, _effective_brush_radius(settings, pressure) * max(0.01, float(getattr(settings, 'brush_spacing', 0.25))))
        if self._last_sample_mouse is None:
            self._apply_sample(context, mouse, event)
            self._last_sample_mouse = mouse.copy()
            return
        delta = mouse - self._last_sample_mouse
        distance = delta.length
        if distance < spacing:
            return
        sample_multiplier = max(1, min(8, int(getattr(settings, 'brush_input_samples', 1) or 1)))
        steps = max(1, min(96, int(distance / spacing) * sample_multiplier))
        start = self._last_sample_mouse.copy()
        for i in range(1, steps + 1):
            sample = start + delta * (i / steps)
            self._apply_sample(context, sample, event)
        self._last_sample_mouse = mouse.copy()

    def _begin_stroke(self, context, mouse, event):
        if not _mouse_inside_region(mouse, self._region):
            return
        bm = self._current_bmesh()
        if bm is None:
            return
        self._is_stroking = True
        self._stroke_changed = False
        self._stroke_tool = 'SMOOTH' if event.shift else self._active_tool
        self._last_sample_mouse = None
        self._stabilized_stroke_mouse = mouse.copy()
        self._drag_targets = []
        self._drag_mirror_targets = []
        self._stroke_original_coords_map = None
        if not bool(getattr(self._settings_ref, 'brush_accumulate', True)):
            try:
                self._stroke_original_coords_map = {v.index: v.co.copy() for v in bm.verts if not v.hide and v.index >= 0}
            except Exception:
                self._stroke_original_coords_map = None
        if _is_direct_drag_tool(self._stroke_tool):
            if not self._begin_drag(context, mouse, event):
                self.report({'INFO'}, tr('brush_no_hit'))
        else:
            self._stroke_to_mouse(context, mouse, event)

    def _end_stroke(self, context=None):
        """End a stroke without creating an intermediate Undo checkpoint."""
        self._is_stroking = False
        self._stroke_changed = False
        self._last_sample_mouse = None
        self._stabilized_stroke_mouse = None
        self._stroke_original_coords_map = None
        self._drag_targets = []
        self._drag_mirror_targets = []

    def _begin_adjust(self, mode, mouse, context=None, event=None):
        self._adjust_mode = mode
        self._adjust_start_mouse = mouse.copy()
        self._adjust_accum_dx = 0.0
        self._adjust_anchor_window = None
        self._adjust_warp_pending = False
        self._adjust_cursor_hidden = False
        try:
            self._adjust_anchor_window = (float(event.mouse_x), float(event.mouse_y))
            self._adjust_last_window_x = float(event.mouse_x)
            self._adjust_last_window_y = float(event.mouse_y)
        except Exception:
            self._adjust_anchor_window = None
            self._adjust_last_window_x = 0.0
            self._adjust_last_window_y = 0.0
        if mode == 'RADIUS':
            self._adjust_original = float(getattr(self._settings_ref, 'brush_radius', 80.0))
        else:
            self._adjust_original = float(getattr(self._settings_ref, 'brush_strength', 0.35))
        self._mouse = self._adjust_start_mouse.copy()
        try:
            if context is not None and getattr(context, 'window', None) is not None:
                context.window.cursor_modal_set('NONE')
                self._adjust_cursor_hidden = True
        except Exception:
            self._adjust_cursor_hidden = False
        self._warp_adjust_cursor(context)
        self._tag_redraw()

    def _update_adjust(self, mouse, context=None, event=None):
        dx = 0.0
        anchor = getattr(self, '_adjust_anchor_window', None)
        if anchor is not None and event is not None:
            try:
                ex = float(event.mouse_x)
                ey = float(event.mouse_y)
            except Exception:
                ex, ey = (float(anchor[0]), float(anchor[1]))
            if bool(getattr(self, '_adjust_warp_pending', False)) and abs(ex - float(anchor[0])) <= 1.0 and (abs(ey - float(anchor[1])) <= 1.0):
                self._adjust_warp_pending = False
                self._adjust_last_window_x = float(anchor[0])
                self._adjust_last_window_y = float(anchor[1])
                self._mouse = self._adjust_start_mouse.copy()
                self._tag_redraw()
                return
            raw_dx = ex - float(getattr(self, '_adjust_last_window_x', anchor[0]))
            self._adjust_accum_dx = float(getattr(self, '_adjust_accum_dx', 0.0)) + raw_dx
            dx = float(getattr(self, '_adjust_accum_dx', 0.0))
            self._mouse = self._adjust_start_mouse.copy()
            self._warp_adjust_cursor(context)
        else:
            dx = mouse.x - self._adjust_start_mouse.x
        if self._adjust_mode == 'RADIUS':
            self._settings_ref.brush_radius = max(1.0, min(1200.0, self._adjust_original + dx * _BRUSH_RADIUS_DRAG_SCALE))
        elif self._adjust_mode == 'STRENGTH':
            self._settings_ref.brush_strength = _clamp(self._adjust_original + dx * _BRUSH_STRENGTH_DRAG_SCALE, 0.0, 1.0)
        self._tag_redraw()

    def _finish_adjust(self, context=None, cancel=False):
        if cancel:
            if self._adjust_mode == 'RADIUS':
                self._settings_ref.brush_radius = self._adjust_original
            elif self._adjust_mode == 'STRENGTH':
                self._settings_ref.brush_strength = self._adjust_original
        try:
            _save_brush_settings_for_tool(getattr(self, '_settings_ref', None), getattr(self, '_active_tool', None))
        except Exception:
            pass
        self._warp_adjust_cursor(context)
        self._adjust_mode = ''
        self._adjust_anchor_window = None
        self._adjust_warp_pending = False
        self._adjust_cursor_hidden = False
        try:
            if context is not None and getattr(context, 'window', None) is not None:
                context.window.cursor_modal_set('CROSSHAIR')
        except Exception:
            pass
        self._tag_redraw()

    def _cycle_falloff(self):
        ids = [item[0] for item in _falloff_items()]
        current = getattr(self._settings_ref, 'brush_falloff', 'SMOOTH')
        try:
            index = ids.index(current)
        except ValueError:
            index = 0
        self._settings_ref.brush_falloff = ids[(index + 1) % len(ids)]
        self._tag_redraw()

    def _open_falloff_pie(self, context):
        try:
            override = {}
            if getattr(self, '_area', None) is not None:
                override['area'] = self._area
            if getattr(self, '_region', None) is not None:
                override['region'] = self._region
            if getattr(self, '_rv3d', None) is not None:
                override['region_data'] = self._rv3d
            if override:
                with context.temp_override(**override):
                    bpy.ops.wm.call_menu_pie(name='STRICT_EDIT_SCULPT_MT_falloff_pie')
            else:
                bpy.ops.wm.call_menu_pie(name='STRICT_EDIT_SCULPT_MT_falloff_pie')
            self._tag_redraw()
            return True
        except Exception:
            self._cycle_falloff()
            return False

    def _stabilized_mouse(self, mouse):
        settings = self._settings_ref
        if not bool(getattr(settings, 'brush_stabilize_stroke', False)):
            return mouse.copy()
        radius = max(0.0, float(getattr(settings, 'brush_stabilize_radius', 24.0)))
        current = getattr(self, '_stabilized_stroke_mouse', None)
        if current is None:
            self._stabilized_stroke_mouse = mouse.copy()
            return mouse.copy()
        delta = mouse - current
        distance = delta.length
        if distance <= radius:
            return current.copy()
        follow = (distance - radius) / max(distance, 1e-08)
        self._stabilized_stroke_mouse = current + delta * _clamp(follow, 0.0, 1.0)
        return self._stabilized_stroke_mouse.copy()

    def _stroke_original_map(self):
        if bool(getattr(self._settings_ref, 'brush_accumulate', True)):
            return None
        return getattr(self, '_stroke_original_coords_map', None)

    def _adjust_radius_multiplier(self, factor):
        self._settings_ref.brush_radius = max(1.0, min(1200.0, float(self._settings_ref.brush_radius) * factor))
        try:
            _save_brush_settings_for_tool(getattr(self, '_settings_ref', None), getattr(self, '_active_tool', None))
        except Exception:
            pass
        self._tag_redraw()

    def _adjust_strength_delta(self, delta):
        self._settings_ref.brush_strength = _clamp(float(self._settings_ref.brush_strength) + delta, 0.0, 1.0)
        try:
            _save_brush_settings_for_tool(getattr(self, '_settings_ref', None), getattr(self, '_active_tool', None))
        except Exception:
            pass
        self._tag_redraw()

    def _strength_step(self):
        return max(0.001, min(1.0, float(getattr(self._settings_ref, 'brush_strength_step', 0.05))))

    def _start_modal(self, context, event=None):
        self._transaction = None
        self._cancel_complete = False
        self._finish_complete = False
        self._finish_result = {'CANCELLED'}
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        area, region, rv3d = _view3d_window_region(context)
        if area is None or region is None or rv3d is None:
            self.report({'ERROR'}, tr('brush_no_view'))
            return {'CANCELLED'}
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        active = _active_direct_brush_instance()
        if active is not None and active is not self:
            active._set_active_tool(context, self.tool or settings.brush_tool)
            return {'FINISHED'}
        try:
            transaction = _transactions.DirectBrushSession(context, settings=settings)
            transaction.__enter__()
            self._transaction = transaction
            if self.tool:
                settings.brush_tool = self.tool
            _ensure_brush_settings_initialized(settings, settings.brush_tool)
            self._obj = obj
            self._area = area
            self._region = region
            self._rv3d = rv3d
            self._settings_ref = settings
            self._active_tool = settings.brush_tool
            self._mouse = _initial_direct_brush_mouse(event, area, region)
            self._is_stroking = False
            self._stroke_tool = self._active_tool
            self._last_sample_mouse = None
            self._stabilized_stroke_mouse = None
            self._stroke_original_coords_map = None
            self._drag_targets = []
            self._drag_mirror_targets = []
            self._last_hit = None
            self._adjust_mode = ''
            self._adjust_original = 0.0
            global _DIRECT_BRUSH_RESTART_BASELINE_READY
            self._did_modify = False
            self._stroke_changed = False
            self._session_undo_pushed = False
            _DIRECT_BRUSH_RESTART_BASELINE_READY = False
            self._ui_passthrough_active = False
            self._adjust_cursor_hidden = False
            self._modal_alive = False
            self._modal_handler_registered = False
            self._add_draw_handler(context)
            self._set_status(context)
            try:
                context.window.cursor_modal_set('CROSSHAIR')
            except Exception:
                pass
            context.window_manager.modal_handler_add(self)
            self._modal_handler_registered = True
            self._modal_alive = True
            _set_active_direct_brush(self)
            self._tag_redraw()
            return {'RUNNING_MODAL'}
        except Exception as exc:
            _runtime_errors.record('direct_brush_start', exc)
            return self._cancel_session(context, 'start_failure')

    def invoke(self, context, event):
        return self._start_modal(context, event)

    def execute(self, context):
        override = _view3d_override_args(context)
        if override:
            try:
                with context.temp_override(**override):
                    return self._start_modal(context, None)
            except Exception:
                pass
        return self._start_modal(context, None)

    def _modal_impl(self, context, event):
        try:
            obj_ref = getattr(self, '_obj', None)
            obj_mode = getattr(obj_ref, 'mode', None) if obj_ref is not None else None
        except ReferenceError:
            obj_ref = None
            obj_mode = None
        except Exception:
            obj_ref = None
            obj_mode = None
        if _ensure_edit_mesh(context) is None or obj_ref is None or obj_mode != 'EDIT':
            return self._cancel_session(context, 'mode_or_object_lost')
        pointer_event_types = {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'TABLET_STYLUS', 'TABLET_ERASER'}
        if _popup_modal_active():
            if getattr(self, '_is_stroking', False) and event.type in pointer_event_types:
                self._end_stroke(context)
                self._tag_redraw()
            if getattr(self, '_adjust_mode', ''):
                self._finish_adjust(context=context, cancel=False)
            self._ui_passthrough_active = True
            return {'PASS_THROUGH'}
        if event.type == 'ESC' and event.value == 'PRESS' and (not getattr(self, '_is_stroking', False)):
            if getattr(self, '_adjust_mode', ''):
                self._finish_adjust(context=context, cancel=True)
                return {'RUNNING_MODAL'}
            return self._finish(context, report=True)
        target_mouse = None
        event_target = _view3d_event_target(context, event, prefer_area=getattr(self, '_area', None)) if _event_has_window_xy(event) else None
        if isinstance(event_target, dict) and event_target.get('viewport', False):
            target_area = event_target.get('area')
            target_region = event_target.get('region')
            target_rv3d = event_target.get('rv3d')
            target_mouse = event_target.get('mouse')
            changed_view = not _same_view3d_target(target_area, target_region, target_rv3d, getattr(self, '_area', None), getattr(self, '_region', None), getattr(self, '_rv3d', None))
            if changed_view and getattr(self, '_is_stroking', False) and (event.type in pointer_event_types):
                self._end_stroke(context)
            self._set_active_view(target_area, target_region, target_rv3d, context=context)
            if target_mouse is not None:
                try:
                    self._mouse = target_mouse.copy()
                except Exception:
                    self._mouse = target_mouse
            pass_to_view_ui = False
        elif isinstance(event_target, dict) and (event_target.get('priority_ui', False) or not event_target.get('viewport', False)):
            pass_to_view_ui = True
        else:
            pass_to_view_ui = _event_should_pass_to_sidebar_or_popup(event, getattr(self, '_area', None), getattr(self, '_region', None), context=context)
        if pass_to_view_ui:
            self._last_pointer_over_non_view = bool(_event_has_window_xy(event))
            if getattr(self, '_is_stroking', False) and event.type in pointer_event_types:
                self._end_stroke(context)
                self._tag_redraw()
            if getattr(self, '_adjust_mode', ''):
                self._finish_adjust(context=context, cancel=False)
            self._ui_passthrough_active = True
            return {'PASS_THROUGH'}
        popup_operator = _popup_shortcut_id_from_event(context, event)
        if popup_operator:
            if getattr(self, '_is_stroking', False):
                self._end_stroke(context)
                self._tag_redraw()
            if getattr(self, '_adjust_mode', ''):
                self._finish_adjust(context=context, cancel=False)
            if _invoke_popup_operator_from_direct_brush(context, popup_operator, brush_instance=self, event=event):
                self._ui_passthrough_active = True
                self._tag_redraw()
                return {'RUNNING_MODAL'}
            self._ui_passthrough_active = True
            return {'PASS_THROUGH'}
        if event.type in pointer_event_types:
            self._ui_passthrough_active = False
        is_pointer_inside_view = _event_inside_viewport_content(event, getattr(self, '_area', None), getattr(self, '_region', None))
        if _event_has_window_xy(event) and is_pointer_inside_view:
            self._last_pointer_over_non_view = False
            if target_mouse is not None:
                try:
                    self._mouse = target_mouse.copy()
                except Exception:
                    self._mouse = target_mouse
            else:
                self._mouse = _event_region_mouse(event, self._region)
        elif not _event_has_window_xy(event) and (bool(getattr(self, '_last_pointer_over_non_view', False)) or bool(getattr(self, '_ui_passthrough_active', False))) and (not getattr(self, '_adjust_mode', '')):
            return {'PASS_THROUGH'}
        mouse = getattr(self, '_mouse', Vector((0.0, 0.0)))
        self._last_ctrl = bool(getattr(event, 'ctrl', False))
        self._last_shift = bool(getattr(event, 'shift', False))
        if self._adjust_mode:
            if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                self._update_adjust(mouse, context=context, event=event)
                return {'RUNNING_MODAL'}
            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                self._finish_adjust(context=context, cancel=False)
                return {'RUNNING_MODAL'}
            if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
                self._finish_adjust(context=context, cancel=True)
                return {'RUNNING_MODAL'}
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS' and event.ctrl and (event.type in {'Z', 'Y'}):
            if self._is_stroking:
                self._end_stroke(context)
            redo = bool(event.type == 'Y' or event.shift)
            if not _schedule_direct_brush_history_action(context, self, redo=redo):
                self.report({'WARNING'}, tr('undo_failed'))
                return {'RUNNING_MODAL'}
            return self._finish(context, report=False)
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS' and (not self._is_stroking):
            return self._finish(context, report=True)
        if event.type == 'F' and event.value == 'PRESS':
            if getattr(self, '_is_stroking', False):
                self._end_stroke(context)
            mode = 'STRENGTH' if event.shift else 'RADIUS'
            try:
                override = {'area': getattr(self, '_area', None), 'region': getattr(self, '_region', None), 'region_data': getattr(self, '_rv3d', None), 'active_object': getattr(self, '_obj', None), 'object': getattr(self, '_obj', None)}
                override = {key: value for key, value in override.items() if value is not None}
                with context.temp_override(**override):
                    result = bpy.ops.strict_edit_sculpt.adjust_brush_value('INVOKE_DEFAULT', mode=mode)
                if 'RUNNING_MODAL' in result:
                    return {'RUNNING_MODAL'}
            except Exception:
                pass
            self._begin_adjust(mode, mouse, context=context, event=event)
            return {'RUNNING_MODAL'}
        strength_hotkeys = bool(getattr(self._settings_ref, 'brush_strength_hotkeys', True))
        if event.type == 'LEFT_BRACKET' and event.value == 'PRESS':
            if strength_hotkeys and event.shift:
                self._adjust_strength_delta(-self._strength_step())
            else:
                self._adjust_radius_multiplier(0.9)
            return {'RUNNING_MODAL'}
        if event.type == 'RIGHT_BRACKET' and event.value == 'PRESS':
            if strength_hotkeys and event.shift:
                self._adjust_strength_delta(self._strength_step())
            else:
                self._adjust_radius_multiplier(1.1)
            return {'RUNNING_MODAL'}
        if strength_hotkeys and event.type in {'MINUS', 'NUMPAD_MINUS'} and (event.value == 'PRESS'):
            self._adjust_strength_delta(-self._strength_step())
            return {'RUNNING_MODAL'}
        if strength_hotkeys and event.type in {'EQUAL', 'PLUS', 'NUMPAD_PLUS'} and (event.value == 'PRESS'):
            self._adjust_strength_delta(self._strength_step())
            return {'RUNNING_MODAL'}
        if strength_hotkeys and event.ctrl and (event.type in {'WHEELUPMOUSE', 'WHEELINMOUSE'}):
            self._adjust_strength_delta(self._strength_step())
            return {'RUNNING_MODAL'}
        if strength_hotkeys and event.ctrl and (event.type in {'WHEELDOWNMOUSE', 'WHEELOUTMOUSE'}):
            self._adjust_strength_delta(-self._strength_step())
            return {'RUNNING_MODAL'}
        if event.type == 'E' and event.value == 'PRESS':
            if event.shift:
                self._cycle_falloff()
            else:
                self._open_falloff_pie(context)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS':
            switched_tool = ''
            if event.type == 'V' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'DRAW'
            elif event.type == 'S' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'SMOOTH'
            elif event.type == 'P' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'PINCH'
            elif event.type == 'I' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'INFLATE'
            elif event.type == 'G' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'GRAB'
            elif event.type == 'T' and event.shift and (not (event.ctrl or event.alt)):
                switched_tool = 'SCRAPE'
            elif event.type == 'C' and event.shift and (not (event.ctrl or event.alt)):
                switched_tool = 'CREASE'
            elif event.type == 'C' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'CLAY_STRIPS'
            elif event.type == 'K' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'SNAKE_HOOK'
            elif event.type == 'M' and (not (event.shift or event.ctrl or event.alt)):
                switched_tool = 'MASK'
            if switched_tool:
                self._set_active_tool(context, switched_tool)
                return {'RUNNING_MODAL'}
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'NDOF_MOTION'}:
            return {'PASS_THROUGH'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self._begin_stroke(context, mouse, event)
            self._tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._end_stroke(context)
            self._tag_redraw()
            return {'RUNNING_MODAL'}
        if self._is_stroking and event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            if _is_direct_drag_tool(self._stroke_tool):
                self._apply_drag(context, mouse, event)
            else:
                self._stroke_to_mouse(context, mouse, event)
            self._tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            self._tag_redraw()
            return {'RUNNING_MODAL'}
        if not _mouse_inside_region(mouse, self._region) and event.type not in {'F', 'E', 'LEFT_BRACKET', 'RIGHT_BRACKET', 'MINUS', 'EQUAL', 'PLUS', 'NUMPAD_MINUS', 'NUMPAD_PLUS'}:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        try:
            # Only a press during a stroke abandons the session; between strokes
            # _modal_impl ends the brush and commits (or leaves F-adjust).
            if getattr(event, 'value', '') == 'PRESS' and getattr(event, 'type', '') in {'ESC', 'RIGHTMOUSE'} and getattr(self, '_is_stroking', False):
                return self._cancel_session(context, 'user_cancel')
            return self._modal_impl(context, event)
        except ReferenceError as exc:
            _runtime_errors.record('direct_brush_reference_error', exc)
            return self._cancel_session(context, 'reference_error')
        except Exception as exc:
            _runtime_errors.record('direct_brush_modal_exception', exc)
            return self._cancel_session(context, 'modal_exception')

class SES_OT_StartDirectBrush(Operator):
    bl_idname = 'strict_edit_sculpt.start_direct_brush'
    bl_label = 'Direct Edit Brush'
    bl_description = 'Starts the Edit Mode direct brush from UI controls after the button event has completed.'
    bl_options = set()
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return not bool(getattr(bpy.app, 'background', False)) and getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' and (_ensure_edit_mesh(context) is not None)

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', '') or getattr(_settings(context), 'brush_tool', 'DRAW')
        title = _tool_label(tool)
        specific = _direct_op_tip(tool)
        if not str(specific).startswith(str(title)):
            specific = title + '\n' + specific
        return specific + '\n' + tr('tip_direct_brush')

    def _start_from_context(self, context):
        tool = str(self.tool or getattr(_settings(context), 'brush_tool', 'DRAW') or 'DRAW')
        try:
            settings = _settings(context)
            if not getattr(settings, 'enabled', False):
                self.report({'WARNING'}, tr('not_enabled'))
                return {'CANCELLED'}
            settings.brush_tool = tool
        except Exception:
            pass
        if _request_direct_brush_start(context, tool, from_ui=True):
            return {'FINISHED'}
        self.report({'ERROR'}, tr('brush_no_view'))
        return {'CANCELLED'}

    def invoke(self, context, event):
        return self._start_from_context(context)

    def execute(self, context):
        return self._start_from_context(context)

    def invoke(self, context, event):
        return self.execute(context)

class SES_OT_AdjustBrushValue(Operator):
    bl_idname = 'strict_edit_sculpt.adjust_brush_value'
    bl_label = 'Adjust Edit Sculpt Brush'
    bl_description = 'Adjusts the active Edit Mode sculpt brush radius or strength with a short cursor-grab modal session.'
    bl_options = {'BLOCKING', 'GRAB_CURSOR', 'MODAL_PRIORITY'}
    mode: EnumProperty(name='Mode', items=(('RADIUS', 'Radius', 'Adjust the active Edit Mode brush radius.'), ('STRENGTH', 'Strength', 'Adjust the active Edit Mode brush strength.')), default='RADIUS')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None and _peek_active_direct_brush_instance() is not None

    def _settings(self):
        inst = _active_direct_brush_instance()
        settings = getattr(inst, '_settings_ref', None) if inst is not None else None
        if settings is None:
            try:
                settings = _settings(bpy.context)
            except Exception:
                settings = None
        return (inst, settings)

    def _tag_redraw(self, context=None):
        inst = _active_direct_brush_instance()
        if inst is not None:
            try:
                inst._draw_adjust_mode = self.mode
                inst._tag_redraw()
                return
            except Exception:
                pass
        try:
            screen = getattr(getattr(context, 'window', None), 'screen', None) or getattr(context, 'screen', None)
            for area in getattr(screen, 'areas', []):
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        except Exception:
            pass

    def _clear_draw_adjust(self, context=None):
        inst = _active_direct_brush_instance()
        if inst is not None:
            try:
                inst._draw_adjust_mode = ''
                inst._tag_redraw()
            except Exception:
                pass

    def _apply_delta(self, context, dx):
        _inst, settings = self._settings()
        if settings is None:
            return False
        if self.mode == 'RADIUS':
            value = max(1.0, min(1200.0, float(self._initial_value) + float(dx) * _BRUSH_RADIUS_DRAG_SCALE))
            settings.brush_radius = value
        else:
            value = _clamp(float(self._initial_value) + float(dx) * _BRUSH_STRENGTH_DRAG_SCALE, 0.0, 1.0)
            settings.brush_strength = value
        try:
            _save_brush_settings_for_tool(settings, getattr(settings, 'brush_tool', None))
        except Exception:
            pass
        self._tag_redraw(context)
        return True

    def _finish(self, context, cancelled=False):
        if cancelled:
            _inst, settings = self._settings()
            if settings is not None:
                try:
                    if self.mode == 'RADIUS':
                        settings.brush_radius = float(self._initial_value)
                    else:
                        settings.brush_strength = float(self._initial_value)
                    _save_brush_settings_for_tool(settings, getattr(settings, 'brush_tool', None))
                except Exception:
                    pass
        try:
            if getattr(context, 'window', None) is not None:
                context.window.cursor_warp(int(round(float(getattr(self, '_initial_mouse_x', 0.0)))), int(round(float(getattr(self, '_initial_mouse_y', 0.0)))))
        except Exception:
            pass
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        self._clear_draw_adjust(context)
        return {'CANCELLED' if cancelled else 'FINISHED'}

    def invoke(self, context, event):
        inst, settings = self._settings()
        if inst is None or settings is None:
            return {'CANCELLED'}
        try:
            self._initial_mouse_x = float(event.mouse_x)
            self._initial_mouse_y = float(event.mouse_y)
        except Exception:
            self._initial_mouse_x = 0.0
            self._initial_mouse_y = 0.0
        self._initial_value = float(getattr(settings, 'brush_radius', 80.0) if self.mode == 'RADIUS' else getattr(settings, 'brush_strength', 0.35))
        try:
            inst._draw_adjust_mode = self.mode
        except Exception:
            pass
        try:
            context.window.cursor_modal_set('NONE')
        except Exception:
            pass
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            return self._finish(context, cancelled=True)
        self._tag_redraw(context)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if _ensure_edit_mesh(context) is None or _active_direct_brush_instance() is None:
            return self._finish(context, cancelled=True)
        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            try:
                dx = float(event.mouse_x) - float(self._initial_mouse_x)
            except Exception:
                dx = 0.0
            self._apply_delta(context, dx)
            return {'RUNNING_MODAL'}
        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'} and event.value == 'PRESS':
            return self._finish(context, cancelled=False)
        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            return self._finish(context, cancelled=True)
        return {'RUNNING_MODAL'}

class SES_OT_SetFalloff(Operator):
    bl_idname = 'strict_edit_sculpt.set_falloff'
    bl_label = 'Falloff Type'
    bl_description = 'Sets the Edit Mode direct brush falloff type.'
    bl_options = set()
    falloff: StringProperty(default='SMOOTH')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        falloff = getattr(properties, 'falloff', 'SMOOTH')
        for op_id, label_key, tip_key in _falloff_items():
            if op_id == falloff:
                return tr(label_key) + '\n' + tr(tip_key)
        return tr('tip_open_falloff_pie')

    def execute(self, context):
        settings = _settings(context)
        ids = {item[0] for item in _falloff_items()}
        if self.falloff not in ids:
            return {'CANCELLED'}
        settings.brush_falloff = self.falloff
        self.report({'INFO'}, tr('falloff_selected'))
        try:
            for area in context.window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}

class SES_OT_OpenFalloffPie(Operator):
    bl_idname = 'strict_edit_sculpt.open_falloff_pie'
    bl_label = 'Falloff Pie'
    bl_description = 'Opens the falloff type pie menu for the Edit Mode direct brush.'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None and (not bpy.app.background)

    @classmethod
    def description(cls, context, properties):
        return tr('tip_open_falloff_pie')

    def invoke(self, context, event):
        try:
            bpy.ops.wm.call_menu_pie(name='STRICT_EDIT_SCULPT_MT_falloff_pie')
            return {'FINISHED'}
        except Exception as ex:
            self.report({'ERROR'}, str(ex))
            return {'CANCELLED'}

    def execute(self, context):
        return self.invoke(context, None)

class SES_MT_FalloffPie(Menu):
    bl_idname = 'STRICT_EDIT_SCULPT_MT_falloff_pie'
    bl_label = 'Falloff Type'

    def draw(self, context):
        pie = self.layout.menu_pie()
        current = getattr(_settings(context), 'brush_falloff', 'SMOOTH')
        for falloff, label_key, _tip_key in _falloff_items():
            op = pie.operator('strict_edit_sculpt.set_falloff', text=tr(label_key), icon='CHECKBOX_HLT' if falloff == current else 'NONE')
            op.falloff = falloff

def _point_in_poly(point, polygon):
    if len(polygon) < 3:
        return False
    x, y = (float(point.x), float(point.y))
    inside = False
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = (float(polygon[i].x), float(polygon[i].y))
        xj, yj = (float(polygon[j].x), float(polygon[j].y))
        if (yi > y) != (yj > y):
            denom = yj - yi if abs(yj - yi) > 1e-08 else 1e-08
            x_cross = (xj - xi) * (y - yi) / denom + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside

def _distance_to_segment_2d(point, start, end):
    p = Vector((float(point.x), float(point.y)))
    a = Vector((float(start.x), float(start.y)))
    b = Vector((float(end.x), float(end.y)))
    ab = b - a
    length_sq = ab.length_squared
    if length_sq <= 1e-08:
        return (p - a).length
    t = max(0.0, min(1.0, (p - a).dot(ab) / length_sq))
    return (p - (a + ab * t)).length

def _shape_contains_screen_point(kind, points, point, radius=8.0):
    if not points:
        return False
    if kind == 'BOX' and len(points) >= 2:
        a, b = (points[0], points[-1])
        return min(a.x, b.x) <= point.x <= max(a.x, b.x) and min(a.y, b.y) <= point.y <= max(a.y, b.y)
    if kind in {'LASSO', 'POLYLINE'}:
        if len(points) >= 3:
            return _point_in_poly(point, points)
        if len(points) >= 2:
            return _distance_to_segment_2d(point, points[0], points[-1]) <= radius
        return False
    if kind == 'LINE' and len(points) >= 2:
        return _distance_to_segment_2d(point, points[0], points[-1]) <= radius
    return False

def _gesture_kind_action(operation):
    parts = (operation or 'BOX_MASK').split('_', 1)
    if len(parts) == 2 and parts[0] in {'BOX', 'LASSO', 'LINE', 'POLYLINE'}:
        return (parts[0], parts[1])
    if operation == 'LINE_PROJECT':
        return ('LINE', 'PROJECT')
    return ('BOX', 'MASK')

def _gesture_tip(operation):
    _kind, action = _gesture_kind_action(operation)
    if action == 'MASK':
        return tr('tip_gesture_mask')
    if action == 'HIDE':
        return tr('tip_gesture_hide')
    if action == 'FACE_SET':
        return tr('tip_gesture_face_set')
    if action == 'TRIM':
        return tr('tip_gesture_trim')
    if action == 'PROJECT':
        return tr('tip_gesture_line_project')
    return tr('tip_gesture_filter')

class SES_OT_ToolbarTool(Operator):
    bl_idname = 'strict_edit_sculpt.toolbar_tool'
    bl_label = 'Sculpt Toolbar Replacement'
    bl_description = 'Selects or starts an Edit Mode replacement for a Blender Sculpt toolbar tool without switching to Sculpt Mode.'
    bl_options = {'UNDO'}
    tool: StringProperty(default='BRUSH')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', 'BRUSH')
        for ident, label_key, _icon, action, target in _sculpt_toolbar_defs():
            if ident == tool:
                if action == 'GESTURE':
                    return _gesture_tip(target)
                if action == 'BRUSH':
                    return _direct_op_tip(target)
                if action == 'FILTER':
                    return tr('tip_gesture_filter')
                return tr(label_key)
        return tr('toolbar_hint')

    def _definition(self):
        for item in _sculpt_toolbar_defs():
            if item[0] == self.tool:
                return item
        return _sculpt_toolbar_defs()[0]

    def invoke(self, context, event):
        _ident, _label_key, _icon, action, target = self._definition()
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        if action == 'BRUSH':
            settings.brush_tool = target
            _apply_native_brush_preset(settings, target, only_if_default=False)
            return {'FINISHED'} if _request_direct_brush_start(context, target, from_ui=True) else {'CANCELLED'}
        if action == 'GESTURE':
            return bpy.ops.strict_edit_sculpt.gesture_tool('INVOKE_DEFAULT', tool=target)
        if action == 'TRANSFORM':
            try:
                if target == 'TRANSLATE':
                    return bpy.ops.transform.translate('INVOKE_DEFAULT')
                if target == 'ROTATE':
                    return bpy.ops.transform.rotate('INVOKE_DEFAULT')
                if target == 'RESIZE':
                    return bpy.ops.transform.resize('INVOKE_DEFAULT')
                return bpy.ops.transform.transform('INVOKE_DEFAULT')
            except Exception as ex:
                self.report({'ERROR'}, str(ex))
                return {'CANCELLED'}
        return self.execute(context)

    def execute(self, context):
        _ident, _label_key, _icon, action, target = self._definition()
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        if action == 'BRUSH':
            settings.brush_tool = target
            _apply_native_brush_preset(settings, target, only_if_default=False)
            self.report({'INFO'}, tr('done'))
            return {'FINISHED'}
        if action == 'GESTURE':
            self.report({'INFO'}, tr('gesture_keys'))
            return {'FINISHED'}
        if action == 'FILTER':
            if target == 'FILTER_SMOOTH':
                return bpy.ops.strict_edit_sculpt.vertex_operation(operation='FILTER_SMOOTH')
            if target == 'CLOTH':
                settings.brush_tool = 'CLOTH'
                return bpy.ops.strict_edit_sculpt.vertex_operation(operation='ELASTIC')
            if target == 'COLOR_SMOOTH':
                return bpy.ops.strict_edit_sculpt.color_operation(operation='SMOOTH')
            if target == 'FACE_SET_EDIT':
                return bpy.ops.strict_edit_sculpt.face_set_operation(operation='SELECT')
            if target == 'MASK_BY_COLOR':
                return bpy.ops.strict_edit_sculpt.mask_operation(operation='SET')
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

def _point_to_segment_distance_2d(point, a, b):
    ab = b - a
    denom = ab.length_squared
    if denom <= 1e-08:
        return (point - a).length
    t = max(0.0, min(1.0, (point - a).dot(ab) / denom))
    return (point - (a + ab * t)).length

def _point_in_polygon_2d(point, polygon):
    if len(polygon) < 3:
        return False
    inside = False
    x, y = (point.x, point.y)
    j = len(polygon) - 1
    for i in range(len(polygon)):
        xi, yi = (polygon[i].x, polygon[i].y)
        xj, yj = (polygon[j].x, polygon[j].y)
        if (yi > y) != (yj > y):
            denom = yj - yi if abs(yj - yi) > 1e-08 else 1e-08
            x_intersect = (xj - xi) * (y - yi) / denom + xi
            if x < x_intersect:
                inside = not inside
        j = i
    return inside

def _gesture_shape_from_tool(tool):
    if tool.startswith('BOX_'):
        return 'BOX'
    if tool.startswith('LASSO_'):
        return 'LASSO'
    if tool.startswith('LINE_') or tool == 'LINE_PROJECT':
        return 'LINE'
    if tool.startswith('POLYLINE_'):
        return 'POLYLINE'
    return 'BOX'

def _gesture_action_from_tool(tool):
    for item_id, _label_key, _tip_key, _icon_name, kind, payload in _SCULPT_TOOLBAR_ITEMS:
        if item_id == tool and kind == 'GESTURE':
            return payload
    return 'MASK'

def _gesture_screen_targets(region, rv3d, obj, bm, shape, points, radius_px):
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    radius_px = max(4.0, float(radius_px))
    verts = []
    vertex_set = set()
    if not points:
        return ([], [])
    if shape == 'BOX' and len(points) >= 2:
        x0, x1 = sorted((points[0].x, points[-1].x))
        y0, y1 = sorted((points[0].y, points[-1].y))

        def contains(pt):
            return x0 <= pt.x <= x1 and y0 <= pt.y <= y1
    elif shape in {'LASSO', 'POLYLINE'} and len(points) >= 3:
        polygon = points

        def contains(pt):
            return _point_in_polygon_2d(pt, polygon)
    elif shape == 'LINE' and len(points) >= 2:
        a, b = (points[0], points[-1])

        def contains(pt):
            return _point_to_segment_distance_2d(pt, a, b) <= radius_px
    else:
        center = points[-1]

        def contains(pt):
            return (pt - center).length <= radius_px
    for v in bm.verts:
        if v.hide:
            continue
        try:
            screen = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v.co)
        except Exception:
            screen = None
        if screen is None:
            continue
        pt = Vector((screen.x, screen.y))
        if contains(pt):
            verts.append(v)
            vertex_set.add(v)
    faces = [f for f in bm.faces if not f.hide and any((v in vertex_set for v in f.verts))]
    return (verts, faces)

def _apply_gesture_edit(bm, verts, faces, settings, action, ctrl=False, points=None):
    if action == 'MASK':
        layer = _mask_layer(bm, True)
        value = 0.0 if ctrl else 1.0
        for v in verts:
            if not v.hide:
                v[layer] = value
        return (len(verts), False)
    if action == 'HIDE':
        if ctrl:
            for v in bm.verts:
                v.hide_set(False)
            for e in bm.edges:
                e.hide_set(False)
            for f in bm.faces:
                f.hide_set(False)
            return (len(bm.faces), False)
        for f in faces:
            f.hide_set(True)
        return (len(faces), False)
    if action == 'FACE_SET':
        layer = _face_set_layer(bm, True)
        value = 0 if ctrl else int(getattr(settings, 'face_set_id', 1))
        for f in faces:
            f[layer] = value
        return (len(faces), False)
    if action == 'TRIM':
        if faces:
            bmesh.ops.delete(bm, geom=faces, context='FACES')
            return (len(faces), True)
        if verts:
            bmesh.ops.delete(bm, geom=verts, context='VERTS')
            return (len(verts), True)
        return (0, False)
    if action == 'PROJECT':
        if not verts:
            return (0, False)
        bm.normal_update()
        center = _center(verts)
        normal = _average_normal(verts)
        strength = _clamp(float(getattr(settings, 'strength', 0.35)))
        for v in verts:
            dist = (v.co - center).dot(normal)
            v.co -= normal * dist * strength
        return (len(verts), False)
    return (0, False)

def _mask_by_active_edit_color(context):
    obj = _ensure_edit_mesh(context)
    if obj is None:
        return 0
    settings = _settings(context)
    mesh = obj.data
    bm = bmesh.from_edit_mesh(mesh)
    bm.faces.ensure_lookup_table()
    color_layer = _color_layer(bm, False)
    if color_layer is None:
        return 0
    mask_layer = _mask_layer(bm, True)
    target = Vector(getattr(settings, 'color', (0.8, 0.35, 0.15, 1.0)))
    threshold = max(0.02, 1.0 - _clamp(float(getattr(settings, 'strength', 0.35))))
    changed = 0
    for f in bm.faces:
        if f.hide:
            continue
        accum = Vector((0.0, 0.0, 0.0, 0.0))
        for loop in f.loops:
            accum += Vector(loop[color_layer])
        avg = accum / max(1, len(f.loops))
        diff = (Vector((avg.x, avg.y, avg.z)) - Vector((target.x, target.y, target.z))).length
        value = 1.0 if diff <= threshold else 0.0
        for v in f.verts:
            v[mask_layer] = max(float(v[mask_layer]), value)
            changed += 1
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    return changed

class SES_OT_ToolCommand(Operator):
    bl_idname = 'strict_edit_sculpt.toolbar_command'
    bl_label = 'Edit Sculpt Toolbar Command'
    bl_description = 'Runs a Sculpt-toolbar-style command replacement in Mesh Edit Mode without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    tool: StringProperty(default='MESH_FILTER')
    command: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', '')
        for item_id, _label_key, tip_key, _icon_name, _kind, _payload in _SCULPT_TOOLBAR_ITEMS:
            if item_id == tool:
                return tr(tip_key)
        return tr('mode_ok')

    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        command = self.command
        if not command:
            for item_id, _label_key, _tip_key, _icon_name, kind, payload in _SCULPT_TOOLBAR_ITEMS:
                if item_id == self.tool:
                    command = payload if kind in {'COMMAND', 'TRANSFORM'} else ''
                    break
        try:
            if command == 'TRANSLATE':
                return bpy.ops.transform.translate('INVOKE_DEFAULT')
            if command == 'ROTATE':
                return bpy.ops.transform.rotate('INVOKE_DEFAULT')
            if command == 'SCALE':
                return bpy.ops.transform.resize('INVOKE_DEFAULT')
            if command == 'TRANSFORM':
                return bpy.ops.transform.transform('INVOKE_DEFAULT')
        except Exception as ex:
            self.report({'ERROR'}, str(ex))
            return {'CANCELLED'}
        if command == 'FILTER_SMOOTH':
            bpy.ops.strict_edit_sculpt.vertex_operation(operation='FILTER_SMOOTH')
        elif command == 'CLOTH_FILTER':
            bpy.ops.strict_edit_sculpt.vertex_operation(operation='ELASTIC')
        elif command == 'COLOR_FILTER':
            bpy.ops.strict_edit_sculpt.color_operation(operation='SET')
        elif command == 'FACE_SET_EDIT':
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()
            selected = [f for f in bm.faces if f.select and (not f.hide)]
            if selected:
                bpy.ops.strict_edit_sculpt.face_set_operation(operation='ASSIGN')
            else:
                bpy.ops.strict_edit_sculpt.face_set_operation(operation='SELECT')
        elif command == 'MASK_BY_COLOR':
            changed = _mask_by_active_edit_color(context)
            if not changed:
                self.report({'WARNING'}, tr('gesture_no_target'))
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, tr('mode_error'))
            return {'CANCELLED'}
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}
_BRUSH_SETTINGS_RESTORE_LOCK = False
_BRUSH_SETTING_FIELDS = ('brush_radius', 'brush_strength', 'brush_amount', 'brush_direction', 'brush_spacing', 'brush_falloff', 'brush_front_faces_only', 'brush_hardness', 'brush_normal_radius', 'brush_auto_smooth', 'brush_accumulate', 'brush_plane_offset', 'brush_stabilize_stroke', 'brush_stabilize_radius', 'brush_input_samples', 'brush_use_pressure_size', 'brush_use_pressure_strength', 'brush_strength_hotkeys', 'brush_strength_step', 'grab_offset', 'pose_axis', 'pose_angle', 'face_set_id', 'color')
_BRUSH_SETTING_DEFAULTS = {'brush_radius': 80.0, 'brush_strength': 0.35, 'brush_amount': 0.05, 'brush_direction': 'ADD', 'brush_spacing': 0.25, 'brush_falloff': 'SMOOTH', 'brush_front_faces_only': True, 'brush_hardness': 0.0, 'brush_normal_radius': 0.0, 'brush_auto_smooth': 0.0, 'brush_accumulate': True, 'brush_plane_offset': 0.0, 'brush_stabilize_stroke': False, 'brush_stabilize_radius': 24.0, 'brush_input_samples': 1, 'brush_use_pressure_size': False, 'brush_use_pressure_strength': True, 'brush_strength_hotkeys': True, 'brush_strength_step': 0.05, 'grab_offset': (0.0, 0.0, 1.0), 'pose_axis': 'Z', 'pose_angle': 15.0, 'face_set_id': 1, 'color': (0.8, 0.35, 0.15, 1.0)}

def _brush_settings_read(settings):
    raw = ''
    try:
        raw = str(getattr(settings, 'brush_settings_json', '') or '')
    except Exception:
        raw = ''
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _brush_settings_write(settings, data):
    try:
        settings.brush_settings_json = json.dumps(data if isinstance(data, dict) else {}, sort_keys=True, separators=(',', ':'))
    except Exception:
        pass

def _brush_settings_snapshot(settings):
    snap = {}
    for name in _BRUSH_SETTING_FIELDS:
        try:
            value = getattr(settings, name)
            if isinstance(value, bool):
                snap[name] = bool(value)
            elif isinstance(value, int):
                snap[name] = int(value)
            elif isinstance(value, float):
                snap[name] = float(value)
            elif isinstance(value, str):
                snap[name] = value
            else:
                try:
                    snap[name] = [float(v) for v in value]
                except Exception:
                    snap[name] = _BRUSH_SETTING_DEFAULTS.get(name)
        except Exception:
            snap[name] = _BRUSH_SETTING_DEFAULTS.get(name)
    return snap

def _coerce_brush_setting_value(name, value):
    default = _BRUSH_SETTING_DEFAULTS.get(name)
    try:
        if name in {'grab_offset', 'color'}:
            seq = value if isinstance(value, (list, tuple)) else default
            size = 4 if name == 'color' else 3
            out = [float(v) for v in list(seq)[:size]]
            while len(out) < size:
                out.append(float(default[len(out)]))
            if name == 'color':
                return tuple((_clamp(v, 0.0, 1.0) for v in out))
            return tuple(out)
        if name in {'brush_front_faces_only', 'brush_accumulate', 'brush_stabilize_stroke', 'brush_use_pressure_size', 'brush_use_pressure_strength', 'brush_strength_hotkeys'}:
            return bool(value)
        if name in {'brush_input_samples', 'face_set_id'}:
            return int(value)
        if name in {'brush_direction', 'brush_falloff', 'pose_axis'}:
            return str(value or default)
        return float(value)
    except Exception:
        return default

def _brush_settings_apply_snapshot(settings, snap):
    global _BRUSH_SETTINGS_RESTORE_LOCK
    if not isinstance(snap, dict):
        snap = {}
    _BRUSH_SETTINGS_RESTORE_LOCK = True
    try:
        for name in _BRUSH_SETTING_FIELDS:
            value = _coerce_brush_setting_value(name, snap.get(name, _BRUSH_SETTING_DEFAULTS.get(name)))
            try:
                setattr(settings, name, value)
            except Exception:
                try:
                    setattr(settings, name, _coerce_brush_setting_value(name, _BRUSH_SETTING_DEFAULTS.get(name)))
                except Exception:
                    pass
    finally:
        _BRUSH_SETTINGS_RESTORE_LOCK = False

def _save_brush_settings_for_tool(settings, tool):
    if not tool:
        return
    data = _brush_settings_read(settings)
    data[str(tool)] = _brush_settings_snapshot(settings)
    _brush_settings_write(settings, data)

def _default_brush_settings_snapshot(tool):
    return dict(_BRUSH_SETTING_DEFAULTS)

def _restore_or_initialize_brush_settings(settings, tool):
    if not tool:
        return
    data = _brush_settings_read(settings)
    key = str(tool)
    if key not in data or not isinstance(data.get(key), dict):
        data[key] = _default_brush_settings_snapshot(key)
        _brush_settings_write(settings, data)
    _brush_settings_apply_snapshot(settings, data.get(key, {}))

def _switch_brush_settings_to_tool(settings, tool, old_tool=None):
    """Switch the active brush without update-callback reentrancy.

    Blender property update callbacks run immediately when brush_tool changes.
    During a running Direct Brush session, calling settings.brush_tool from
    _set_active_tool() previously re-entered _brush_tool_update(), which restored
    the new tool defaults and then saved those defaults back over the old tool.
    This helper performs the save/restore and brush_tool/active_key assignment
    under the restore lock so each brush keeps its own stored values.
    """
    global _BRUSH_SETTINGS_RESTORE_LOCK
    if settings is None or not tool:
        return False
    key = str(tool)
    old = str(old_tool or getattr(settings, 'brush_settings_active_key', '') or getattr(settings, 'brush_tool', 'DRAW') or 'DRAW')
    if old and old != key:
        _save_brush_settings_for_tool(settings, old)
    data = _brush_settings_read(settings)
    if key not in data or not isinstance(data.get(key), dict):
        data[key] = _default_brush_settings_snapshot(key)
        _brush_settings_write(settings, data)
    _brush_settings_apply_snapshot(settings, data.get(key, {}))
    _BRUSH_SETTINGS_RESTORE_LOCK = True
    try:
        try:
            settings.brush_tool = key
        except Exception:
            pass
        try:
            settings.brush_settings_active_key = key
        except Exception:
            pass
    finally:
        _BRUSH_SETTINGS_RESTORE_LOCK = False
    return True

def _brush_setting_value_update(self, context):
    if _BRUSH_SETTINGS_RESTORE_LOCK:
        return
    try:
        tool = str(getattr(self, 'brush_settings_active_key', '') or getattr(self, 'brush_tool', 'DRAW') or 'DRAW')
        _save_brush_settings_for_tool(self, tool)
    except Exception:
        pass

def _brush_tool_update(self, context):
    if _BRUSH_SETTINGS_RESTORE_LOCK:
        return
    try:
        new_tool = str(getattr(self, 'brush_tool', 'DRAW') or 'DRAW')
        old_tool = str(getattr(self, 'brush_settings_active_key', '') or 'DRAW')
        _switch_brush_settings_to_tool(self, new_tool, old_tool=old_tool)
        try:
            _update_active_direct_brush_tool(context, new_tool, sync_settings=False)
        except Exception:
            pass
    except Exception:
        pass

def _ensure_brush_settings_initialized(settings, tool=None):
    try:
        active = str(tool or getattr(settings, 'brush_tool', 'DRAW') or 'DRAW')
        if not str(getattr(settings, 'brush_settings_active_key', '') or ''):
            settings.brush_settings_active_key = active
        data = _brush_settings_read(settings)
        if active not in data or not isinstance(data.get(active), dict):
            data[active] = _default_brush_settings_snapshot(active)
            _brush_settings_write(settings, data)
        return True
    except Exception:
        return False

def _apply_native_brush_preset(settings, tool, only_if_default=True):
    try:
        _restore_or_initialize_brush_settings(settings, tool)
        try:
            settings.brush_settings_active_key = str(tool or getattr(settings, 'brush_tool', 'DRAW') or 'DRAW')
        except Exception:
            pass
        return True
    except Exception:
        return _ensure_brush_settings_initialized(settings, tool)

class SES_Settings(PropertyGroup):
    enabled: BoolProperty(name='Enabled', description=I18N['en_US']['prop_enabled_desc'], default=True)
    strength: FloatProperty(name='Strength', description=I18N['en_US']['prop_strength_desc'], default=0.35, min=0.0, max=1.0, subtype='FACTOR')
    amount: FloatProperty(name='Amount', description=I18N['en_US']['prop_amount_desc'], default=0.05, min=-10.0, max=10.0, precision=4)
    iterations: IntProperty(name='Iterations', description=I18N['en_US']['prop_iterations_desc'], default=1, min=1, max=100)
    affect_visible_when_none: BoolProperty(name='Use visible vertices when nothing is selected', description=I18N['en_US']['prop_affect_all_desc'], default=False)
    use_mask: BoolProperty(name='Use Edit Mask', description=I18N['en_US']['prop_use_mask_desc'], default=False, update=_mask_lock_settings_update)
    use_mask_for_mesh_editing: BoolProperty(name='Apply Edit Mask to Mesh Editing', description=I18N['en_US']['prop_mask_mesh_edit_lock_desc'], default=False, update=_mask_lock_settings_update)
    mask_lock_threshold: FloatProperty(name='Lock Threshold', description=I18N['en_US']['prop_mask_lock_threshold_desc'], default=0.99, min=0.0, max=1.0, subtype='FACTOR', update=_mask_lock_settings_update)
    mask_overlay_enabled: BoolProperty(name='Locked Vertex Overlay', description=I18N['en_US']['prop_mask_overlay_enabled_desc'], default=False, update=_mask_overlay_settings_update)
    mask_overlay_color: FloatVectorProperty(name='Locked Vertex Color', description=I18N['en_US']['prop_mask_overlay_color_desc'], subtype='COLOR', size=4, default=(1.0, 0.12, 0.04, 0.88), min=0.0, max=1.0, update=_mask_overlay_style_update)
    mask_overlay_size: FloatProperty(name='Locked Vertex Size', description=I18N['en_US']['prop_mask_overlay_size_desc'], default=8.0, min=1.0, max=48.0, precision=1, update=_mask_overlay_style_update)
    grab_offset: FloatVectorProperty(name='Move Offset', description=I18N['en_US']['prop_grab_offset_desc'], default=(0.0, 0.0, 1.0), size=3, precision=4, update=_brush_setting_value_update)
    pose_axis: EnumProperty(name='Pose Axis', description=I18N['en_US']['prop_pose_axis_desc'], items=[('X', 'X Axis', I18N['en_US']['prop_pose_axis_desc']), ('Y', 'Y Axis', I18N['en_US']['prop_pose_axis_desc']), ('Z', 'Z Axis', I18N['en_US']['prop_pose_axis_desc'])], default='Z', update=_brush_setting_value_update)
    pose_angle: FloatProperty(name='Pose Angle', description=I18N['en_US']['prop_pose_angle_desc'], default=15.0, min=-180.0, max=180.0, update=_brush_setting_value_update)
    face_set_id: IntProperty(name='Face Set ID', description=I18N['en_US']['prop_face_set_id_desc'], default=1, min=0, max=2147483647, update=_brush_setting_value_update)
    color: FloatVectorProperty(name='Color', description=I18N['en_US']['prop_color_desc'], subtype='COLOR', size=4, default=(0.8, 0.35, 0.15, 1.0), min=0.0, max=1.0, update=_brush_setting_value_update)
    sym_direction: EnumProperty(name='Symmetry Direction', description=I18N['en_US']['prop_sym_dir_desc'], items=[('NEGATIVE_X', '-X to +X', I18N['en_US']['prop_sym_dir_desc']), ('POSITIVE_X', '+X to -X', I18N['en_US']['prop_sym_dir_desc']), ('NEGATIVE_Y', '-Y to +Y', I18N['en_US']['prop_sym_dir_desc']), ('POSITIVE_Y', '+Y to -Y', I18N['en_US']['prop_sym_dir_desc']), ('NEGATIVE_Z', '-Z to +Z', I18N['en_US']['prop_sym_dir_desc']), ('POSITIVE_Z', '+Z to -Z', I18N['en_US']['prop_sym_dir_desc'])], default='NEGATIVE_X')
    brush_tool: EnumProperty(name='Brush', description=I18N['en_US']['prop_brush_tool_desc'], items=_brush_tool_enum_items(), default='DRAW', update=_brush_tool_update)
    toolbar_tool: EnumProperty(name='Toolbar Tool', description=I18N['en_US']['tip_toolbar_tool_prop'], items=_toolbar_tool_enum_items(), default='BOX_MASK')
    brush_radius: FloatProperty(name='Radius', description=I18N['en_US']['prop_brush_radius_desc'], default=80.0, min=1.0, max=1200.0, precision=1, update=_brush_setting_value_update)
    brush_strength: FloatProperty(name='Brush Strength', description=I18N['en_US']['prop_brush_strength_desc'], default=0.35, min=0.0, max=1.0, subtype='FACTOR', update=_brush_setting_value_update)
    brush_amount: FloatProperty(name='Brush Amount', description=I18N['en_US']['prop_brush_amount_desc'], default=0.05, min=0.0, max=10.0, precision=4, update=_brush_setting_value_update)
    brush_spacing: FloatProperty(name='Spacing', description=I18N['en_US']['prop_brush_spacing_desc'], default=0.25, min=0.01, max=2.0, subtype='FACTOR', update=_brush_setting_value_update)
    brush_falloff: EnumProperty(name='Falloff', description=I18N['en_US']['prop_brush_falloff_desc'], items=_falloff_enum_items(), default='SMOOTH', update=_brush_setting_value_update)
    brush_front_faces_only: BoolProperty(name='Front faces only', description=I18N['en_US']['prop_brush_front_faces_only_desc'], default=True, update=_brush_setting_value_update)
    brush_direction: EnumProperty(name='Direction', description=I18N['en_US']['prop_brush_direction_desc'], items=[('ADD', 'Add', I18N['en_US']['prop_brush_direction_desc']), ('SUBTRACT', 'Subtract', I18N['en_US']['prop_brush_direction_desc'])], default='ADD', update=_brush_setting_value_update)
    brush_hardness: FloatProperty(name='Hardness', description=I18N['en_US']['prop_brush_hardness_desc'], default=0.0, min=0.0, max=1.0, subtype='FACTOR', update=_brush_setting_value_update)
    brush_normal_radius: FloatProperty(name='Normal Radius', description=I18N['en_US']['prop_brush_normal_radius_desc'], default=0.0, min=0.0, max=1.0, subtype='FACTOR', update=_brush_setting_value_update)
    brush_auto_smooth: FloatProperty(name='Auto Smooth', description=I18N['en_US']['prop_brush_auto_smooth_desc'], default=0.0, min=0.0, max=1.0, subtype='FACTOR', update=_brush_setting_value_update)
    brush_accumulate: BoolProperty(name='Accumulate', description=I18N['en_US']['prop_brush_accumulate_desc'], default=True, update=_brush_setting_value_update)
    brush_plane_offset: FloatProperty(name='Plane Offset', description=I18N['en_US']['prop_brush_plane_offset_desc'], default=0.0, min=-1.0, max=1.0, precision=3, update=_brush_setting_value_update)
    brush_stabilize_stroke: BoolProperty(name='Stabilize Stroke', description=I18N['en_US']['prop_brush_stabilize_stroke_desc'], default=False, update=_brush_setting_value_update)
    brush_stabilize_radius: FloatProperty(name='Stabilize Radius', description=I18N['en_US']['prop_brush_stabilize_radius_desc'], default=24.0, min=0.0, max=240.0, precision=1, update=_brush_setting_value_update)
    brush_input_samples: IntProperty(name='Input Samples', description=I18N['en_US']['prop_brush_input_samples_desc'], default=1, min=1, max=8, update=_brush_setting_value_update)
    brush_use_pressure_size: BoolProperty(name='Pressure Radius', description=I18N['en_US']['prop_brush_use_pressure_size_desc'], default=False, update=_brush_setting_value_update)
    brush_use_pressure_strength: BoolProperty(name='Pressure Strength', description=I18N['en_US']['prop_brush_use_pressure_strength_desc'], default=True, update=_brush_setting_value_update)
    brush_strength_hotkeys: BoolProperty(name='Strength Hotkeys', description=I18N['en_US']['prop_brush_strength_hotkeys_desc'], default=True, update=_brush_setting_value_update)
    brush_strength_step: FloatProperty(name='Strength Step', description=I18N['en_US']['prop_brush_strength_step_desc'], default=0.05, min=0.001, max=1.0, subtype='FACTOR', update=_brush_setting_value_update)
    brush_settings_json: StringProperty(name='Brush Settings Store', description='Internal per-brush settings storage.', default='{}', options={'HIDDEN'})
    brush_settings_active_key: StringProperty(name='Active Brush Settings Key', description='Internal active brush key used to save and restore per-brush settings.', default='DRAW', options={'HIDDEN'})

class SES_OT_VertexOperation(Operator):
    bl_idname = 'strict_edit_sculpt.vertex_operation'
    bl_label = 'Edit Sculpt Operation'
    bl_description = 'Runs an Edit Mode-only sculpt-like vertex operation without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    operation: StringProperty(default='SMOOTH')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        return _op_tip(getattr(properties, 'operation', ''))

    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        verts = _selected_verts(bm, settings)
        if not verts:
            self.report({'WARNING'}, tr('no_selection'))
            return {'CANCELLED'}
        mirror_before_coords = _mirror_coords_from_bmesh(bm) if _mesh_mirror_enabled(obj) else None
        bm.normal_update()
        op = self.operation
        if op == 'DRAW':
            _apply_normal_offset(bm, verts, settings, 1.0)
        elif op == 'DRAW_SHARP':
            _apply_normal_offset(bm, verts, settings, 0.8)
            _apply_pinch(bm, verts, settings, 0.25)
        elif op == 'CLAY':
            _apply_normal_offset(bm, verts, settings, 0.75)
            _apply_smooth(bm, verts, settings, tangent=True)
        elif op == 'CLAY_STRIPS':
            _apply_normal_offset(bm, verts, settings, 0.65)
            _apply_plane(bm, verts, settings, 'FLATTEN')
        elif op == 'BLOB':
            _apply_normal_offset(bm, verts, settings, 1.0)
            _apply_scale(bm, verts, settings, 1.0 + settings.strength * abs(settings.amount))
        elif op == 'CREASE':
            _apply_pinch(bm, verts, settings, 0.6)
            _apply_normal_offset(bm, verts, settings, -0.5)
        elif op == 'SMOOTH' or op == 'FILTER_SMOOTH':
            _apply_smooth(bm, verts, settings, tangent=False)
        elif op == 'RELAX' or op == 'FILTER_RELAX':
            _apply_smooth(bm, verts, settings, tangent=True)
        elif op == 'FILTER_SHARPEN':
            _apply_smooth(bm, verts, settings, tangent=False, sharpen=True)
        elif op == 'FILTER_SCALE':
            _apply_scale(bm, verts, settings)
        elif op == 'FLATTEN':
            _apply_plane(bm, verts, settings, 'FLATTEN')
        elif op == 'FILL':
            _apply_plane(bm, verts, settings, 'FILL')
        elif op == 'SCRAPE':
            _apply_plane(bm, verts, settings, 'SCRAPE')
        elif op == 'INFLATE':
            _apply_normal_offset(bm, verts, settings, 1.0)
        elif op == 'DEFLATE':
            _apply_normal_offset(bm, verts, settings, -1.0)
        elif op == 'PINCH':
            _apply_pinch(bm, verts, settings)
        elif op == 'GRAB':
            _apply_grab(bm, verts, settings, snake=False)
        elif op == 'SNAKE_HOOK':
            _apply_grab(bm, verts, settings, snake=True)
        elif op == 'ELASTIC':
            _apply_scale(bm, verts, settings, 1.0 + settings.strength * settings.amount)
            _apply_smooth(bm, verts, settings, tangent=True)
        elif op == 'POSE':
            _apply_pose(bm, verts, settings)
        else:
            self.report({'ERROR'}, tr('unknown_operation'))
            return {'CANCELLED'}
        if mirror_before_coords is not None:
            _mirror_changed_vertex_coordinates(obj, bm, mirror_before_coords, verts)
        bm.normal_update()
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        _refresh_mask_lock_anchors(obj)
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

class SES_OT_MaskOperation(Operator):
    bl_idname = 'strict_edit_sculpt.mask_operation'
    bl_label = 'Edit Mask Operation'
    bl_description = 'Edits the add-on mask layer in Mesh Edit Mode without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    operation: StringProperty(default='SET')
    iterations: IntProperty(name='Iterations', default=0, min=0, max=100, options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tips = {'SET': 'tip_mask_set', 'CLEAR': 'tip_mask_clear', 'INVERT': 'tip_mask_invert', 'SMOOTH': 'tip_mask_smooth', 'BOUNDARY': 'tip_mask_boundary', 'CAVITY': 'tip_mask_cavity'}
        return tr(tips.get(getattr(properties, 'operation', ''), 'tip_mask_set'))

    @_transactions.transactional_execute
    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        layer = _mask_layer(bm, True)
        op = self.operation
        if op == 'SET':
            verts = _selected_verts(bm, settings)
            if not verts:
                self.report({'WARNING'}, tr('no_selection'))
                return {'CANCELLED'}
            verts = _mirror_expand_verts(obj, bm, verts)
            for v in verts:
                v[layer] = 1.0
        elif op == 'CLEAR':
            for v in bm.verts:
                if not v.hide:
                    v[layer] = 0.0
        elif op == 'INVERT':
            for v in bm.verts:
                if not v.hide:
                    v[layer] = 1.0 - max(0.0, min(1.0, float(v[layer])))
        elif op in {'GROW', 'SHRINK', 'SHARPEN'}:
            for _i in range(max(1, self.iterations or settings.iterations)):
                vals = {v: float(v[layer]) for v in bm.verts if not v.hide}
                updates = {}
                for v, value in vals.items():
                    linked = [vals[e.other_vert(v)] for e in v.link_edges if e.other_vert(v) in vals]
                    if not linked:
                        continue
                    if op == 'GROW':
                        updates[v] = max(value, max(linked))
                    elif op == 'SHRINK':
                        updates[v] = min(value, min(linked))
                    else:
                        updates[v] = value + (value - sum(linked) / len(linked))
                for v, val in updates.items():
                    v[layer] = max(0.0, min(1.0, val))
        elif op == 'SMOOTH':
            for _i in range(max(1, self.iterations or settings.iterations)):
                vals = {v: float(v[layer]) for v in bm.verts if not v.hide}
                updates = {}
                for v in bm.verts:
                    if v.hide:
                        continue
                    linked = [e.other_vert(v) for e in v.link_edges if not e.other_vert(v).hide]
                    if linked:
                        avg = sum((vals[n] for n in linked)) / len(linked)
                        updates[v] = vals[v] + (avg - vals[v]) * settings.strength
                for v, val in updates.items():
                    v[layer] = max(0.0, min(1.0, val))
        elif op == 'BOUNDARY':
            for v in bm.verts:
                if not v.hide:
                    v[layer] = 0.0
            for e in bm.edges:
                if e.hide:
                    continue
                if len(e.link_faces) < 2:
                    for v in e.verts:
                        v[layer] = 1.0
        elif op == 'CAVITY':
            coords = {v: v.co.copy() for v in bm.verts if not v.hide}
            values = []
            for v in bm.verts:
                if v.hide:
                    continue
                avg = _neighbor_average(v, coords)
                val = (coords[v] - avg).length
                values.append((v, val))
            max_val = max((val for _v, val in values), default=0.0)
            for v, val in values:
                v[layer] = 0.0 if max_val <= 1e-12 else max(0.0, min(1.0, val / max_val))
        else:
            self.report({'ERROR'}, tr('unknown_operation'))
            return {'CANCELLED'}
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        _refresh_mask_lock_anchors(obj)
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

class SES_OT_FaceSetOperation(Operator):
    bl_idname = 'strict_edit_sculpt.face_set_operation'
    bl_label = 'Edit Face Set Operation'
    bl_description = 'Edits the add-on face-set layer in Mesh Edit Mode without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    operation: StringProperty(default='ASSIGN')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tips = {'ASSIGN': 'tip_faceset_assign', 'SELECT': 'tip_faceset_select', 'HIDE': 'tip_faceset_hide', 'REVEAL': 'tip_faceset_reveal', 'CLEAR': 'tip_faceset_clear'}
        return tr(tips.get(getattr(properties, 'operation', ''), 'tip_faceset_assign'))

    @_transactions.transactional_execute
    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        layer = _face_set_layer(bm, True)
        fs_id = int(settings.face_set_id)
        op = self.operation
        if op == 'ASSIGN':
            faces = _selected_faces(bm, settings)
            if not faces:
                self.report({'WARNING'}, tr('no_selection'))
                return {'CANCELLED'}
            faces = _mirror_expand_faces(obj, bm, faces)
            for f in faces:
                f[layer] = fs_id
        elif op == 'SELECT':
            for f in bm.faces:
                f.select_set(not f.hide and int(f[layer]) == fs_id)
        elif op == 'HIDE':
            for f in bm.faces:
                if int(f[layer]) == fs_id:
                    f.hide_set(True)
        elif op == 'REVEAL':
            for v in bm.verts:
                v.hide_set(False)
            for e in bm.edges:
                e.hide_set(False)
            for f in bm.faces:
                f.hide_set(False)
        elif op == 'CLEAR':
            for f in bm.faces:
                f[layer] = 0
        else:
            self.report({'ERROR'}, tr('unknown_operation'))
            return {'CANCELLED'}
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

class SES_OT_ColorOperation(Operator):
    bl_idname = 'strict_edit_sculpt.color_operation'
    bl_label = 'Edit Color Operation'
    bl_description = 'Edits the add-on color layer in Mesh Edit Mode without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    operation: StringProperty(default='SET')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tips = {'SET': 'tip_color_set', 'LIGHTEN': 'tip_color_lighten', 'DARKEN': 'tip_color_darken', 'SMOOTH': 'tip_color_smooth'}
        return tr(tips.get(getattr(properties, 'operation', ''), 'tip_color_set'))

    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        layer = _color_layer(bm, True)
        faces = _selected_faces(bm, settings)
        if not faces:
            self.report({'WARNING'}, tr('no_selection'))
            return {'CANCELLED'}
        faces = _mirror_expand_faces(obj, bm, faces)
        op = self.operation
        if op == 'SET':
            col = settings.color
            for f in faces:
                for loop in f.loops:
                    loop[layer] = col
        elif op in {'LIGHTEN', 'DARKEN'}:
            sign = 1.0 if op == 'LIGHTEN' else -1.0
            delta = settings.strength * 0.25 * sign
            for f in faces:
                for loop in f.loops:
                    c = loop[layer]
                    loop[layer] = (max(0.0, min(1.0, c[0] + delta)), max(0.0, min(1.0, c[1] + delta)), max(0.0, min(1.0, c[2] + delta)), c[3])
        elif op == 'SMOOTH':
            for _i in range(max(1, settings.iterations)):
                accum = {}
                counts = {}
                for f in bm.faces:
                    for loop in f.loops:
                        v = loop.vert
                        accum[v] = accum.get(v, Vector((0.0, 0.0, 0.0, 0.0))) + Vector(loop[layer])
                        counts[v] = counts.get(v, 0) + 1
                avg = {v: accum[v] / counts[v] for v in accum if counts[v]}
                for f in faces:
                    for loop in f.loops:
                        c = Vector(loop[layer])
                        target = avg.get(loop.vert, c)
                        loop[layer] = c.lerp(target, settings.strength)
        else:
            self.report({'ERROR'}, tr('unknown_operation'))
            return {'CANCELLED'}
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

class SES_OT_TopologyOperation(Operator):
    bl_idname = 'strict_edit_sculpt.topology_operation'
    bl_label = 'Edit Topology Operation'
    bl_description = 'Runs Edit Mode topology operations without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    operation: StringProperty(default='TRIM_SELECTED')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tips = {'TRIM_SELECTED': 'tip_trim_selected', 'SUBDIVIDE': 'tip_subdivide', 'SYMMETRIZE': 'tip_symmetrize'}
        return tr(tips.get(getattr(properties, 'operation', ''), 'tip_trim_selected'))

    @_transactions.transactional_execute
    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        mesh = obj.data
        if self.operation == 'SYMMETRIZE':
            try:
                bpy.ops.mesh.symmetrize(direction=settings.sym_direction)
            except Exception as ex:
                self.report({'ERROR'}, str(ex))
                return {'CANCELLED'}
            self.report({'INFO'}, tr('done'))
            return {'FINISHED'}
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        if self.operation == 'TRIM_SELECTED':
            faces = _mirror_expand_faces(obj, bm, _selected_faces(bm, settings))
            verts = _mirror_expand_verts(obj, bm, _selected_verts(bm, settings))
            if faces:
                bmesh.ops.delete(bm, geom=faces, context='FACES_ONLY')
            elif verts:
                bmesh.ops.delete(bm, geom=verts, context='VERTS')
            else:
                self.report({'WARNING'}, tr('no_selection'))
                return {'CANCELLED'}
            bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)
        elif self.operation == 'SUBDIVIDE':
            edges = _selected_edges(bm, settings)
            if not edges:
                self.report({'WARNING'}, tr('no_selection'))
                return {'CANCELLED'}
            bmesh.ops.subdivide_edges(bm, edges=edges, cuts=1, use_grid_fill=True)
            bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)
        else:
            self.report({'ERROR'}, tr('unknown_operation'))
            return {'CANCELLED'}
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

def _screen_point_for_vertex(region, rv3d, obj, v):
    try:
        p = view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ v.co)
        if p is None:
            return None
        return Vector((float(p.x), float(p.y)))
    except Exception:
        return None

def _point_in_poly_2d(point, poly):
    if len(poly) < 3:
        return False
    x, y = (point.x, point.y)
    inside = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = (poly[i].x, poly[i].y)
        xj, yj = (poly[j].x, poly[j].y)
        if (yi > y) != (yj > y):
            denom = yj - yi if abs(yj - yi) > 1e-08 else 1e-08
            x_cross = (xj - xi) * (y - yi) / denom + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside

def _distance_to_segment_2d(point, a, b):
    ab = b - a
    denom = ab.length_squared
    if denom <= 1e-08:
        return (point - a).length
    t = max(0.0, min(1.0, (point - a).dot(ab) / denom))
    return (point - (a + ab * t)).length

def _gesture_shape_contains(point, points, shape):
    if shape == 'BOX' and len(points) >= 2:
        x1, y1 = (points[0].x, points[0].y)
        x2, y2 = (points[-1].x, points[-1].y)
        return min(x1, x2) <= point.x <= max(x1, x2) and min(y1, y2) <= point.y <= max(y1, y2)
    if shape == 'LINE' and len(points) >= 2:
        return _distance_to_segment_2d(point, points[0], points[-1]) <= 10.0
    if shape in {'LASSO', 'POLYLINE'}:
        return _point_in_poly_2d(point, points)
    return False

def _capture_gesture_selection_state(bm):
    """Capture the exact edit selection before a visibility gesture.

    BMesh ``hide_set`` updates adjacent selection flags as a side effect.  If
    those implicit changes are left as-is, the state immediately after the
    click differs from the state Blender reconstructs on redo.  Keep the
    user's pre-click selection for every element that remains visible.
    """
    return {'verts': {elem for elem in bm.verts if elem.select}, 'edges': {elem for elem in bm.edges if elem.select}, 'faces': {elem for elem in bm.faces if elem.select}, 'history': list(bm.select_history), 'active_face': getattr(bm.faces, 'active', None)}

def _restore_gesture_selection_after_visibility_change(bm, snapshot):
    if not isinstance(snapshot, dict):
        return
    for key, elements in (('verts', bm.verts), ('edges', bm.edges), ('faces', bm.faces)):
        selected = snapshot.get(key, set())
        for elem in elements:
            try:
                elem.select_set(bool(elem in selected and (not elem.hide)))
            except Exception:
                try:
                    elem.select = bool(elem in selected and (not elem.hide))
                except Exception:
                    pass
    try:
        bm.select_history.clear()
        for elem in snapshot.get('history', ()):
            if getattr(elem, 'is_valid', False) and getattr(elem, 'select', False) and (not getattr(elem, 'hide', False)):
                bm.select_history.add(elem)
    except Exception:
        pass
    try:
        active_face = snapshot.get('active_face')
        bm.faces.active = active_face if active_face is not None and getattr(active_face, 'is_valid', False) and getattr(active_face, 'select', False) and (not getattr(active_face, 'hide', False)) else None
    except Exception:
        pass

def _gesture_targets(region, rv3d, obj, bm, points, shape):
    verts = []
    vert_set = set()
    for v in bm.verts:
        if v.hide:
            continue
        p = _screen_point_for_vertex(region, rv3d, obj, v)
        if p is not None and _gesture_shape_contains(p, points, shape):
            verts.append(v)
            vert_set.add(v)
    faces = []
    for f in bm.faces:
        if f.hide:
            continue
        if any((v in vert_set for v in f.verts)):
            faces.append(f)
    return (verts, faces)

def _apply_color_filter_static(bm, settings):
    layer = _color_layer(bm, True)
    if layer is None:
        return 0
    faces = _selected_faces(bm, settings)
    if not faces:
        faces = [f for f in bm.faces if not f.hide]
    changed = 0
    for f in faces:
        for loop in f.loops:
            current = Vector(loop[layer])
            target = Vector(getattr(settings, 'color', (0.8, 0.35, 0.15, 1.0)))
            loop[layer] = current.lerp(target, _clamp(float(getattr(settings, 'strength', 0.35))))
            changed += 1
    return changed

def _apply_mask_by_color(bm, settings):
    layer = _color_layer(bm, False)
    mask = _mask_layer(bm, True)
    if layer is None:
        return 0
    target = Vector(getattr(settings, 'color', (0.8, 0.35, 0.15, 1.0)))
    changed = 0
    per_vert = {}
    for f in bm.faces:
        if f.hide:
            continue
        for loop in f.loops:
            c = Vector(loop[layer])
            dist = (Vector((c[0], c[1], c[2])) - Vector((target[0], target[1], target[2]))).length
            value = 1.0 if dist <= 0.35 else 0.0
            per_vert[loop.vert] = max(per_vert.get(loop.vert, 0.0), value)
    for v, value in per_vert.items():
        v[mask] = value
        changed += 1
    return changed

def _apply_toolbar_action(context, obj, bm, tool_id, verts=None, faces=None, ctrl=False):
    settings = _settings(context)
    verts = verts or []
    faces = faces or []
    item = _toolbar_item(tool_id)
    if item is None:
        return 0
    _tid, _name_en, _name_ja, _icon, action, shape = item
    if action.startswith('GESTURE_') or action == 'TOOLBAR_FACE_SET_EDIT':
        verts, faces = _mirror_expand_verts_faces(obj, bm, verts, faces)
    changed = 0
    if action == 'GESTURE_MASK':
        vert_indices = [v.index for v in verts if not v.hide and v.index >= 0]
        layer = _mask_layer(bm, True)
        bm.verts.ensure_lookup_table()
        value = 0.0 if ctrl else 1.0
        for index in vert_indices:
            if not 0 <= index < len(bm.verts):
                continue
            v = bm.verts[index]
            old_value = float(v[layer])
            if abs(old_value - value) <= 1e-08:
                continue
            v[layer] = value
            changed += 1
    elif action == 'GESTURE_HIDE':
        if ctrl:
            for elem in list(bm.verts) + list(bm.edges) + list(bm.faces):
                if not bool(getattr(elem, 'hide', False)):
                    continue
                try:
                    elem.hide_set(False)
                except Exception:
                    elem.hide = False
                changed += 1
        else:
            for f in faces:
                if bool(getattr(f, 'hide', False)):
                    continue
                try:
                    f.hide_set(True)
                except Exception:
                    f.hide = True
                changed += 1
            for v in verts:
                if bool(getattr(v, 'hide', False)):
                    continue
                try:
                    v.hide_set(True)
                except Exception:
                    v.hide = True
                changed += 1
    elif action == 'GESTURE_FACE_SET':
        face_indices = [f.index for f in faces if not f.hide and f.index >= 0]
        layer = _face_set_layer(bm, True)
        bm.faces.ensure_lookup_table()
        value = 0 if ctrl else int(getattr(settings, 'face_set_id', 1))
        for index in face_indices:
            if not 0 <= index < len(bm.faces):
                continue
            f = bm.faces[index]
            if int(f[layer]) == value:
                continue
            f[layer] = value
            changed += 1
    elif action == 'GESTURE_TRIM':
        geom = [f for f in faces if not f.hide]
        if geom:
            try:
                bmesh.ops.delete(bm, geom=geom, context='FACES')
                changed = len(geom)
            except Exception:
                changed = 0
    elif action == 'GESTURE_PROJECT':
        if len(verts) >= 1:
            if len(verts) > 1:
                center = _center(verts)
            else:
                center = verts[0].co.copy()
            bm.normal_update()
            avg_n = _average_normal(verts) if verts else Vector((0.0, 0.0, 1.0))
            for v in verts:
                d = (v.co - center).dot(avg_n)
                v.co = v.co - avg_n * d * float(getattr(settings, 'strength', 0.35))
                changed += 1
    elif action == 'TOOLBAR_MESH_FILTER':
        targets = [v for v in verts or _selected_verts(bm, settings) if not v.hide]
        if targets:
            mirror_before_coords = _mirror_coords_from_bmesh(bm) if _mesh_mirror_enabled(obj) else None
            _apply_smooth(bm, targets, settings, tangent=False)
            if mirror_before_coords is not None:
                _mirror_changed_vertex_coordinates(obj, bm, mirror_before_coords, targets)
            changed = len(targets)
    elif action == 'TOOLBAR_CLOTH_FILTER':
        targets = [v for v in verts or _selected_verts(bm, settings) if not v.hide]
        if targets:
            mirror_before_coords = _mirror_coords_from_bmesh(bm) if _mesh_mirror_enabled(obj) else None
            _apply_smooth(bm, targets, settings, tangent=True)
            _apply_scale(bm, targets, settings, scale_factor=1.0 + float(getattr(settings, 'amount', 0.05)) * float(getattr(settings, 'strength', 0.35)) * 0.25)
            if mirror_before_coords is not None:
                _mirror_changed_vertex_coordinates(obj, bm, mirror_before_coords, targets)
            changed = len(targets)
    elif action == 'TOOLBAR_COLOR_FILTER':
        changed = _apply_color_filter_static(bm, settings)
    elif action == 'TOOLBAR_FACE_SET_EDIT':
        layer = _face_set_layer(bm, True)
        targets = faces or _selected_faces(bm, settings)
        for f in targets:
            f[layer] = int(getattr(settings, 'face_set_id', 1))
            changed += 1
    elif action == 'TOOLBAR_MASK_BY_COLOR':
        changed = _apply_mask_by_color(bm, settings)
    elif action.startswith('TRANSFORM_'):
        try:
            if action == 'TRANSFORM_MOVE':
                bpy.ops.transform.translate('INVOKE_DEFAULT')
            elif action == 'TRANSFORM_ROTATE':
                bpy.ops.transform.rotate('INVOKE_DEFAULT')
            elif action == 'TRANSFORM_SCALE':
                bpy.ops.transform.resize('INVOKE_DEFAULT')
            else:
                bpy.ops.transform.transform('INVOKE_DEFAULT')
            return 0
        except Exception:
            return 0
    return changed

class SES_OT_GestureTool(Operator):
    bl_idname = 'strict_edit_sculpt.gesture_tool'
    bl_label = 'Edit Sculpt Toolbar Gesture'
    bl_description = 'Runs an Edit Mode replacement for a Blender Sculpt toolbar gesture tool without entering Sculpt Mode.'
    bl_options = {'UNDO', 'BLOCKING'}
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return not bool(getattr(bpy.app, 'background', False)) and getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' and (_ensure_edit_mesh(context) is not None)

    @classmethod
    def description(cls, context, properties):
        tool_id = getattr(properties, 'tool', '')
        return tr('toolbar_tip_' + tool_id.lower()) if tool_id else tr('gesture_keys')

    def _sync_draw_state(self):
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['points_xy'] = tuple((float(p.x), float(p.y)) for p in getattr(self, '_points', []))
            state['shape'] = getattr(self, '_shape', 'BOX')
            state['viewport'] = _region_viewport_snapshot(getattr(self, '_region', None))
            _build_gesture_packet(state)

    def _tag_redraw(self):
        try:
            self._sync_draw_state()
        except Exception:
            pass
        try:
            self._area.tag_redraw()
        except Exception:
            pass

    def _finish(self, context, cancel=False):
        if bool(getattr(self, '_finish_complete', False)):
            return set(getattr(self, '_finish_result', {'CANCELLED'}))
        self._finish_complete = True
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
        for handle in list(getattr(self, '_draw_handles', []) or []):
            _remove_tracked_draw_handler(handle, state)
        self._draw_handles = []
        if getattr(self, '_draw_handle', None) is not None:
            _remove_tracked_draw_handler(self._draw_handle, state)
            self._draw_handle = None
        self._draw_state = None
        changed = bool(getattr(self, '_did_modify', False))
        tx = getattr(self, '_transaction', None)
        try:
            if tx is not None:
                if cancel or not changed:
                    tx.rollback()
                else:
                    tx.finish()
        except Exception as exc:
            _runtime_errors.record('gesture_transaction_finish', exc)
            changed = False
            cancel = True
            try:
                if tx is not None:
                    tx.rollback()
            except Exception:
                pass
        self._transaction = None
        if cancel or not changed:
            settings_ref = getattr(self, '_toolbar_settings_ref', None)
            if settings_ref is not None and bool(getattr(self, '_toolbar_tool_had_value', False)):
                try:
                    settings_ref.toolbar_tool = getattr(self, '_toolbar_tool_before', '')
                except Exception:
                    pass
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        try:
            _status_runtime.clear('smart_sculpt_suite.edit_mode_sculpt.gesture', context=context)
        except Exception:
            pass
        try:
            self._area.tag_redraw()
        except Exception:
            pass
        self._finish_result = {'CANCELLED'} if cancel or not changed else {'FINISHED'}
        return set(self._finish_result)

    def cancel(self, context):
        self._finish(context, cancel=True)

    def _apply(self, context, ctrl=False):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            return 0
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        verts, faces = _gesture_targets(self._region, self._rv3d, obj, bm, self._points, self._shape)
        item = _toolbar_item(self.tool)
        action = item[4] if item is not None else ''
        settings = _settings(context)
        selection_before = _capture_gesture_selection_state(bm) if action == 'GESTURE_HIDE' else None
        will_change = False
        if action == 'GESTURE_MASK':
            value = 0.0 if ctrl else 1.0
            layer = _mask_layer(bm, False)
            will_change = bool(verts) and (layer is None or any((abs(float(v[layer]) - value) > 1e-08 for v in verts if not v.hide)))
        elif action == 'GESTURE_HIDE':
            if ctrl:
                will_change = any((bool(getattr(elem, 'hide', False)) for elem in list(bm.verts) + list(bm.edges) + list(bm.faces)))
            else:
                will_change = any((not bool(getattr(f, 'hide', False)) for f in faces)) or any((not bool(getattr(v, 'hide', False)) for v in verts))
        elif action == 'GESTURE_FACE_SET':
            value = 0 if ctrl else int(getattr(settings, 'face_set_id', 1))
            layer = _face_set_layer(bm, False)
            will_change = bool(faces) and (layer is None or any((int(f[layer]) != value for f in faces if not f.hide)))
        elif action == 'GESTURE_TRIM':
            will_change = any((not f.hide for f in faces))
        elif action == 'GESTURE_PROJECT':
            strength = float(getattr(settings, 'strength', 0.35))
            if verts and abs(strength) > 1e-08:
                center = _center(verts)
                avg_n = _average_normal(verts) if verts else Vector((0.0, 0.0, 1.0))
                will_change = any((abs((v.co - center).dot(avg_n) * strength) > 1e-08 for v in verts))
        if not will_change:
            return 0
        label = f"Strict Edit Sculpt - {tr('toolbar_' + self.tool.lower())}"
        changed = _apply_toolbar_action(context, obj, bm, self.tool, verts, faces, ctrl=ctrl)
        if changed and selection_before is not None:
            _restore_gesture_selection_after_visibility_change(bm, selection_before)
        if changed:
            bm.normal_update()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=True)
            if self.tool and ('MASK' in self.tool or 'MASK' in str(_toolbar_item(self.tool) or '')):
                _refresh_mask_lock_anchors(obj)
            self._did_modify = True
            self.report({'INFO'}, tr('gesture_finished'))
        return changed

    def invoke(self, context, event):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        area, region, rv3d = _view3d_window_region(context)
        if area is None or region is None or rv3d is None:
            self.report({'ERROR'}, tr('brush_no_view'))
            return {'CANCELLED'}
        item = _toolbar_item(self.tool)
        if item is None:
            return {'CANCELLED'}
        self._finish_complete = False
        self._finish_result = {'CANCELLED'}
        self._transaction = None
        self._toolbar_settings_ref = None
        self._toolbar_tool_had_value = False
        self._toolbar_tool_before = ''
        try:
            self._transaction = _transactions.SculptStateTransaction(context, label=self.bl_label)
            self._transaction.__enter__()
        except Exception as exc:
            _runtime_errors.record('gesture_transaction_start', exc)
            self._transaction = None
            return {'CANCELLED'}
        try:
            toolbar_settings = _settings(context)
            self._toolbar_settings_ref = toolbar_settings
            self._toolbar_tool_had_value = hasattr(toolbar_settings, 'toolbar_tool')
            if self._toolbar_tool_had_value:
                self._toolbar_tool_before = str(getattr(toolbar_settings, 'toolbar_tool', '') or '')
                toolbar_settings.toolbar_tool = self.tool
        except Exception:
            pass
        self._area = area
        self._region = region
        self._rv3d = rv3d
        self._shape = item[5]
        self._points = []
        self._drawing = False
        self._did_modify = False
        self._draw_state = {'alive': True, 'points': [], 'shape': self._shape, 'area_pointer': _state_area_pointer(area), 'region_pointer': _state_region_pointer(region), 'region_width': float(getattr(region, 'width', 0.0) or 0.0), 'region_height': float(getattr(region, 'height', 0.0) or 0.0)}
        try:
            self._draw_handle = _add_tracked_draw_handler(_draw_toolbar_gesture_overlay, self._draw_state, 'WINDOW', 'POST_PIXEL')
        except Exception as exc:
            _runtime_errors.record('gesture_draw_handler', exc)
            self._draw_handle = None
            return self._finish(context, cancel=True)
        try:
            context.window.cursor_modal_set('CROSSHAIR')
            _status_runtime.set_service('smart_sculpt_suite.edit_mode_sculpt.gesture', f"{tr('toolbar_' + self.tool.lower())}: {tr('gesture_keys')}", context=context)
        except Exception:
            pass
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self.report({'ERROR'}, tr('brush_no_view'))
            return self._finish(context, cancel=True)
        return {'RUNNING_MODAL'}

    def _modal_impl(self, context, event):
        transaction = getattr(self, '_transaction', None)
        if transaction is None or _ensure_edit_mesh(context) is None or getattr(context.view_layer.objects, 'active', None) is not getattr(transaction, '_active', None):
            return self._finish(context, cancel=True)
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            return self._finish(context, cancel=True)
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'NDOF_MOTION'}:
            return {'PASS_THROUGH'}
        if event.type in {'LEFTMOUSE', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            mouse = _event_region_mouse(event, self._region)
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                self._drawing = True
                self._points = [mouse.copy()]
                self._tag_redraw()
                return {'RUNNING_MODAL'}
            if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'} and self._drawing:
                if self._shape in {'LASSO', 'POLYLINE'}:
                    if not self._points or (mouse - self._points[-1]).length > 3.0:
                        self._points.append(mouse.copy())
                elif self._points:
                    if len(self._points) == 1:
                        self._points.append(mouse.copy())
                    else:
                        self._points[-1] = mouse.copy()
                self._tag_redraw()
                return {'RUNNING_MODAL'}
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE' and self._drawing:
                self._drawing = False
                mouse = _event_region_mouse(event, self._region)
                if len(self._points) == 1:
                    self._points.append(mouse.copy())
                elif self._points:
                    self._points[-1] = mouse.copy()
                self._apply(context, ctrl=event.ctrl)
                return self._finish(context, cancel=False)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        try:
            return self._modal_impl(context, event)
        except ReferenceError as exc:
            _runtime_errors.record('gesture_reference_error', exc)
            return self._finish(context, cancel=True)
        except Exception as exc:
            _runtime_errors.record('gesture_modal_exception', exc)
            return self._finish(context, cancel=True)

class SES_OT_ToolbarOperation(Operator):
    bl_idname = 'strict_edit_sculpt.toolbar_operation'
    bl_label = 'Edit Sculpt Toolbar Operation'
    bl_description = 'Runs an Edit Mode replacement for a Blender Sculpt toolbar operation without entering Sculpt Mode.'
    bl_options = {'UNDO'}
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        tool_id = getattr(properties, 'tool', '')
        return tr('toolbar_tip_' + tool_id.lower()) if tool_id else tr('mode_error')

    def execute(self, context):
        obj = _ensure_edit_mesh(context)
        if obj is None:
            self.report({'ERROR'}, tr('mode_error'))
            return {'CANCELLED'}
        try:
            _settings(context).toolbar_tool = self.tool
        except Exception:
            pass
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        changed = _apply_toolbar_action(context, obj, bm, self.tool, ctrl=False)
        if changed:
            bm.normal_update()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=True)
            if self.tool and ('MASK' in self.tool or 'MASK' in str(_toolbar_item(self.tool) or '')):
                _refresh_mask_lock_anchors(obj)
        self.report({'INFO'}, tr('done'))
        return {'FINISHED'}

def _view3d_override_args(context):
    """Return a stable 3D View WINDOW-region override for modal viewport tools."""
    try:
        area, region, rv3d = _view3d_window_region(context)
        if area is not None and region is not None and (rv3d is not None):
            ctx_region = getattr(context, 'region', None)
            if getattr(ctx_region, 'type', '') == 'WINDOW':
                return {}
            view_space = None
            for space in getattr(area, 'spaces', []) or []:
                if getattr(space, 'type', None) == 'VIEW_3D' and getattr(space, 'region_3d', None) is not None:
                    view_space = space
                    break
            override = {'area': area, 'region': region}
            if view_space is not None:
                override['space_data'] = view_space
            override['region_data'] = rv3d
            window = getattr(context, 'window', None)
            screen = getattr(context, 'screen', None)
            if window is not None:
                override['window'] = window
            if screen is not None:
                override['screen'] = screen
            return override
    except Exception:
        pass
    try:
        window = getattr(context, 'window', None)
        screen = getattr(context, 'screen', None)
        if screen is None and window is not None:
            screen = getattr(window, 'screen', None)
        if screen is None:
            return {}
        for area in getattr(screen, 'areas', []):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            pairs = _view3d_window_view_tuples(area)
            if not pairs:
                continue
            window_region, rv3d = pairs[0]
            view_space = _view3d_space_for_area(area)
            if view_space is None:
                continue
            override = {'area': area, 'region': window_region, 'space_data': view_space, 'region_data': rv3d}
            if window is not None:
                override['window'] = window
            if screen is not None:
                override['screen'] = screen
            return override
    except Exception:
        pass
    return {}

def _run_with_view3d_override(context, op_callable, *args, **kwargs):
    """Call an operator with the active/available 3D View so menu and overlay clicks can start modal tools."""
    override = _view3d_override_args(context)
    if override:
        try:
            with context.temp_override(**override):
                return op_callable(*args, **kwargs)
        except Exception:
            pass
    return op_callable(*args, **kwargs)

def _operator_result_started(result):
    if isinstance(result, set):
        return 'CANCELLED' not in result
    return bool(result)
_PENDING_DIRECT_BRUSH_START = None
_DIRECT_BRUSH_START_TIMER_ACTIVE = False

def _direct_brush_started_for_tool(tool=None):
    inst = _active_direct_brush_instance()
    if inst is None:
        return False
    if tool:
        try:
            inst._set_active_tool(bpy.context, str(tool))
        except Exception:
            pass
    return True

def _start_direct_brush_now(context, tool):
    """Start the modal direct brush from a stable 3D View WINDOW context."""
    if not tool:
        return False
    if _update_active_direct_brush_tool(context, tool):
        return True
    try:
        settings = _settings(context)
        settings.brush_tool = str(tool)
        _ensure_brush_settings_initialized(settings, str(tool))
    except Exception:
        pass

    def _call_direct(call_context, invoke_mode):
        override = _view3d_override_args(call_context)
        if override:
            with call_context.temp_override(**override):
                return bpy.ops.strict_edit_sculpt.direct_brush(invoke_mode, tool=str(tool))
        return bpy.ops.strict_edit_sculpt.direct_brush(invoke_mode, tool=str(tool))
    for invoke_mode in ('INVOKE_DEFAULT', 'EXEC_DEFAULT'):
        try:
            result = _call_direct(context, invoke_mode)
            if _operator_result_started(result) and _active_direct_brush_instance() is not None:
                return True
        except Exception:
            pass
    return _active_direct_brush_instance() is not None

def _direct_brush_deferred_start_timer():
    global _PENDING_DIRECT_BRUSH_START, _DIRECT_BRUSH_START_TIMER_ACTIVE
    pending = _PENDING_DIRECT_BRUSH_START
    if not pending:
        _DIRECT_BRUSH_START_TIMER_ACTIVE = False
        return None
    tool = str(pending.get('tool') or 'DRAW')
    attempts = int(pending.get('attempts', 0) or 0)
    try:
        context = bpy.context
        if _start_direct_brush_now(context, tool):
            _PENDING_DIRECT_BRUSH_START = None
            _DIRECT_BRUSH_START_TIMER_ACTIVE = False
            return None
    except Exception:
        pass
    attempts += 1
    pending['attempts'] = attempts
    _PENDING_DIRECT_BRUSH_START = pending
    if attempts < 20:
        return 0.05
    _PENDING_DIRECT_BRUSH_START = None
    _DIRECT_BRUSH_START_TIMER_ACTIVE = False
    return None

def _request_direct_brush_start(context, tool, from_ui=False):
    """Start Direct Brush from UI or popup, and report success only after a real modal session exists."""
    global _PENDING_DIRECT_BRUSH_START, _DIRECT_BRUSH_START_TIMER_ACTIVE
    if not tool:
        return False
    tool = str(tool)
    try:
        settings = _settings(context)
        settings.brush_tool = tool
    except Exception:
        pass
    if _update_active_direct_brush_tool(context, tool):
        return True
    _PENDING_DIRECT_BRUSH_START = None
    _DIRECT_BRUSH_START_TIMER_ACTIVE = False
    if _start_direct_brush_now(context, tool):
        return True
    return False

def _launch_direct_brush_from_selection(context, tool):
    """Start Direct Brush, or retarget the running brush without replacing it."""
    if not tool:
        return False
    try:
        settings = _settings(context)
        try:
            settings.brush_tool = tool
        except Exception:
            pass
        if _update_active_direct_brush_tool(context, tool):
            return True
        return _request_direct_brush_start(context, tool, from_ui=True)
    except Exception:
        return False

def _launch_toolbar_tool_from_selection(context, tool):
    """Run the selected Sculpt-toolbar replacement immediately after an icon selection."""
    if not tool:
        return False
    try:
        override = _view3d_override_args(context)
        if override:
            try:
                with context.temp_override(**override):
                    return _operator_result_started(_run_toolbar_tool_by_id(context, tool))
            except Exception:
                pass
        return _operator_result_started(_run_toolbar_tool_by_id(context, tool))
    except Exception:
        return False

class SES_OT_SelectBrushAsset(Operator):
    bl_idname = 'strict_edit_sculpt.select_brush_asset'
    bl_label = 'Select Brush Asset'
    bl_description = 'Selects a standard Sculpt brush asset replacement as the active Edit Mode direct brush.'
    bl_options = set()
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return not bool(getattr(bpy.app, 'background', False)) and getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' and (_ensure_edit_mesh(context) is not None)

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', '') or 'DRAW'
        return _tool_label(tool) + '\n' + tr('tip_select_brush_asset')

    def execute(self, context):
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        if not self.tool:
            return {'CANCELLED'}
        settings.brush_tool = self.tool
        try:
            _apply_native_brush_preset(settings, self.tool, only_if_default=False)
        except Exception:
            pass
        self.report({'INFO'}, tr('brush_selected'))
        if not _launch_direct_brush_from_selection(context, self.tool):
            return {'CANCELLED'}
        return {'FINISHED'}

class SES_OT_SelectToolbarTool(Operator):
    bl_idname = 'strict_edit_sculpt.select_toolbar_tool'
    bl_label = 'Select Sculpt Toolbar Tool'
    bl_description = 'Selects a standard Sculpt toolbar replacement as the active toolbar tool.'
    bl_options = set()
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return not bool(getattr(bpy.app, 'background', False)) and getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' and (_ensure_edit_mesh(context) is not None)

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', '') or 'MESH_FILTER'
        return _toolbar_tool_label(tool) + '\n' + tr('tip_select_toolbar_tool')

    def execute(self, context):
        settings = _settings(context)
        if not settings.enabled:
            self.report({'WARNING'}, tr('not_enabled'))
            return {'CANCELLED'}
        if not self.tool:
            return {'CANCELLED'}
        settings.toolbar_tool = self.tool
        self.report({'INFO'}, tr('toolbar_selected'))
        if not _launch_toolbar_tool_from_selection(context, self.tool):
            return {'CANCELLED'}
        return {'FINISHED'}
POPUP_BRUSH_COLUMNS = 8
POPUP_TOOLBAR_COLUMNS = 4
POPUP_BRUSH_SCALE = 1.0
POPUP_TOOLBAR_SCALE = 1.35
POPUP_OVERLAY_BRUSH_COLUMNS = 8
POPUP_OVERLAY_BRUSH_CELL = 58
POPUP_OVERLAY_BRUSH_ICON = 52
POPUP_OVERLAY_TOOLBAR_COLUMNS = 4
POPUP_OVERLAY_TOOLBAR_CELL = 42
POPUP_OVERLAY_TOOLBAR_ICON = 30
POPUP_OVERLAY_MARGIN = 10
POPUP_OVERLAY_HEADER = 24
_POPUP_OVERLAY_TEXTURES = OrderedDict()

def _draw_brush_assets_popup_content(layout, context):
    """Draw from prewarmed icon IDs only; no file or preview loading occurs here."""
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.ui_units_x = max(1.0, POPUP_BRUSH_COLUMNS * POPUP_BRUSH_SCALE)
    except Exception:
        pass
    s = _settings(context)
    col = layout.column(align=True)
    col.enabled = s.enabled
    col.operator_context = 'EXEC_DEFAULT'
    row = None
    for index, (op_id, label_key, _tip_key, icon) in enumerate(_direct_brush_items()):
        if index % POPUP_BRUSH_COLUMNS == 0:
            row = col.row(align=True)
            row.operator_context = 'EXEC_DEFAULT'
            row.scale_x = POPUP_BRUSH_SCALE
            row.scale_y = POPUP_BRUSH_SCALE
        _popup_icon_button(row, 'strict_edit_sculpt.select_brush_asset', label_key, icon, 'tool', op_id, selected=op_id == s.brush_tool, popup_kind='brush')

def _draw_sculpt_toolbar_popup_content(layout, context):
    """Draw from prewarmed icon IDs only; no file or preview loading occurs here."""
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
        layout.ui_units_x = max(1.0, float(POPUP_TOOLBAR_COLUMNS) * float(POPUP_TOOLBAR_SCALE))
    except Exception:
        pass
    s = _settings(context)
    col = layout.column(align=True)
    col.enabled = s.enabled
    col.operator_context = 'EXEC_DEFAULT'
    row = None
    for index, (tool_id, _name_en, _name_ja, icon_handle, _action, _shape) in enumerate(_toolbar_display_items()):
        if index % POPUP_TOOLBAR_COLUMNS == 0:
            row = col.row(align=True)
            row.operator_context = 'EXEC_DEFAULT'
            try:
                row.scale_y = POPUP_TOOLBAR_SCALE
            except Exception:
                pass
        label_key = 'toolbar_' + tool_id.lower()
        popup_icon = _toolbar_popup_icon_spec(tool_id, icon_handle)
        _popup_icon_button(row, 'strict_edit_sculpt.select_toolbar_tool', label_key, popup_icon, 'tool', tool_id, selected=tool_id == s.toolbar_tool, popup_kind='toolbar')

def _popup_overlay_icon_path(icon_spec, fallback_slug=''):
    """Resolve a bundled brush preview image path for the modal icon popup."""
    if not isinstance(icon_spec, str):
        return ''
    slug = ''
    if icon_spec.startswith('preview:'):
        slug = icon_spec.split(':', 1)[1]
    elif icon_spec.startswith('popup:'):
        slug = icon_spec.split(':', 1)[1]
    elif icon_spec.startswith('brush.sculpt.'):
        slug = icon_spec.rsplit('.', 1)[1]
    elif icon_spec.startswith('brush.'):
        slug = fallback_slug or 'generic'
    elif icon_spec.lower().endswith('.png'):
        return icon_spec if os.path.exists(icon_spec) else ''
    if not slug:
        slug = fallback_slug
    if not slug:
        return ''
    base = os.path.dirname(__file__)
    for subdir in ('icons_popup_opaque_brush', 'icons_popup_brush', 'icons'):
        candidate = os.path.join(base, subdir, slug + '.png')
        if os.path.exists(candidate):
            return candidate
    return ''

def _popup_overlay_texture(filepath):
    """Return a GPU texture for an image path, keeping the Image alive."""
    if not filepath:
        return None
    cached = _bounded_cache_get(_POPUP_OVERLAY_TEXTURES, filepath)
    if cached is not None:
        return cached.get('texture')
    try:
        import gpu
        image = bpy.data.images.load(filepath, check_existing=True)
        texture = gpu.texture.from_image(image)
        _bounded_cache_store(_POPUP_OVERLAY_TEXTURES, filepath, {'image': image, 'texture': texture}, _POPUP_OVERLAY_TEXTURE_CACHE_LIMIT)
        return texture
    except Exception:
        _bounded_cache_store(_POPUP_OVERLAY_TEXTURES, filepath, {'image': None, 'texture': None}, _POPUP_OVERLAY_TEXTURE_CACHE_LIMIT)
        return None

def _release_popup_overlay_textures():
    """Release bounded transient Image/texture references after popup completion."""
    _POPUP_OVERLAY_TEXTURES.clear()

def _draw_brush_asset_overlay(state):
    """Replay completed immutable brush-popup packets only."""
    _gpu_state.replay_state_packet(state)

def _brush_asset_overlay_items(context):
    result = []
    for op_id, label_key, tip_key, icon in _direct_brush_items():
        fallback_slug = _brush_slug(op_id)
        if fallback_slug == 'generic':
            fallback_slug = op_id.lower()
        result.append({'id': op_id, 'label': tr(label_key), 'tip': tr(tip_key), 'path': _popup_overlay_icon_path(icon, fallback_slug)})
    return result

def _rebuild_popup_overlay_packets(state):
    """Build one immutable packet per known View3D draw region outside draw."""
    if not isinstance(state, dict):
        return
    items = tuple(state.get('items', ()))
    rects = tuple(state.get('rects', ()))
    area = state.get('area')
    region_rows = []
    try:
        region_rows = [r for r in tuple(area.regions) if getattr(r, 'type', '') in {'WINDOW', 'UI', 'TOOLS'}]
    except Exception:
        region_rows = []
    if not region_rows:
        region_rows = [None]
    packets = []
    for region in region_rows:
        ox = float(getattr(region, 'x', 0.0) or 0.0) if region is not None else 0.0
        oy = float(getattr(region, 'y', 0.0) or 0.0) if region is not None else 0.0
        # POST_PIXEL draws into a region-local framebuffer in Blender 5.1.
        # Keep the window origin for positioning, and match the GPU viewport locally.
        bounds = _region_viewport_snapshot(region)
        viewport = (0, 0, bounds[2], bounds[3]) if bounds is not None else None
        primitives = []
        texts = []
        textures = []
        x0 = float(state.get('x', 20.0)) - ox
        y0 = float(state.get('y', 20.0)) - oy
        width = float(state.get('width', 250.0))
        height = float(state.get('height', 250.0))
        primitives.append(_rect_primitive(x0 - 1.0, y0 - 1.0, width + 2.0, height + 2.0, (0.02, 0.02, 0.02, 1.0)))
        primitives.append(_rect_primitive(x0, y0, width, height, (0.16, 0.16, 0.16, 1.0)))
        primitives.append(_rect_primitive(x0, y0 + height - POPUP_OVERLAY_HEADER, width, POPUP_OVERLAY_HEADER, (0.11, 0.11, 0.11, 1.0)))
        title = tr('menu_brush_assets') if state.get('kind') == 'brush_assets' else tr('menu_sculpt_toolbar')
        texts.append({'text': title, 'x': x0 + 8.0, 'y': y0 + height - 17.0, 'size': 12,
                      'color': (0.92, 0.92, 0.92, 1.0)})
        hover = int(state.get('hover', -1))
        selected = str(state.get('selected_tool', ''))
        for index, item in enumerate(items):
            if index >= len(rects):
                break
            ax, ay, rw, rh = rects[index]
            rx, ry = float(ax) - ox, float(ay) - oy
            chosen = str(item.get('id', '')) == selected
            hot = index == hover
            cell = (0.30, 0.42, 0.58, 1.0) if chosen else (0.28, 0.28, 0.28, 1.0) if hot else (0.205, 0.205, 0.205, 1.0)
            border = (0.54, 0.64, 0.78, 1.0) if chosen else (0.42, 0.42, 0.42, 1.0) if hot else (0.08, 0.08, 0.08, 1.0)
            primitives.append(_rect_primitive(rx, ry, rw, rh, cell))
            primitives.extend(_outline_primitives(rx, ry, rw, rh, border))
            icon_size = min(float(state.get('icon', 32.0)), float(rw) - 8.0, float(rh) - 8.0)
            ix, iy = rx + (rw - icon_size) * 0.5, ry + (rh - icon_size) * 0.5
            texture = _popup_overlay_texture(str(item.get('path', '')))
            if texture is not None:
                textures.append({'texture': texture, 'x': ix, 'y': iy, 'width': icon_size, 'height': icon_size})
            else:
                texts.append({'text': str(item.get('label', '?'))[:1], 'x': ix + icon_size * 0.38,
                              'y': iy + icon_size * 0.33, 'size': 14, 'color': (0.85, 0.85, 0.85, 1.0)})
        if 0 <= hover < len(items):
            item = items[hover]
            tip = str(item.get('tip', '') or item.get('label', ''))
            texts.append({'text': tip[:160], 'x': x0 + 8.0, 'y': y0 + 7.0,
                          'size': 11, 'color': (0.96, 0.96, 0.96, 1.0)})
        packets.append(_gpu_state.build_packet(primitives=tuple(primitives), texts=tuple(texts),
                                               textures=tuple(textures), expected_viewport=viewport))
    state['packets'] = tuple(packets)
    state['packet'] = None


def _build_brush_asset_overlay_state(context, event):
    area, region, _rv3d = _view3d_window_region(context)
    items = _brush_asset_overlay_items(context)
    columns = max(1, int(POPUP_OVERLAY_BRUSH_COLUMNS))
    cell = float(POPUP_OVERLAY_BRUSH_CELL)
    margin = float(POPUP_OVERLAY_MARGIN)
    header = float(POPUP_OVERLAY_HEADER)
    rows = int(math.ceil(len(items) / columns)) if items else 1
    width = margin * 2.0 + columns * cell
    height = margin * 2.0 + header + rows * cell
    region_width = float(getattr(region, 'width', 800) or 800)
    region_height = float(getattr(region, 'height', 600) or 600)
    overlay_x, overlay_y, overlay_width, overlay_height = _view3d_overlay_bounds(area, region)
    x = overlay_x + max(8.0, (overlay_width - width) * 0.5)
    y = overlay_y + max(8.0, (overlay_height - height) * 0.5)
    if y + height > overlay_y + overlay_height - 8.0:
        y = max(overlay_y + 8.0, overlay_y + overlay_height - height - 8.0)
    rects = []
    top = y + height - margin - header
    for index, _item in enumerate(items):
        col = index % columns
        row = index // columns
        rx = x + margin + col * cell
        ry = top - (row + 1) * cell
        rects.append((rx, ry, cell, cell))
    state = {'alive': True, 'kind': 'brush_assets', 'items': items, 'rects': rects, 'x': x, 'y': y, 'width': width, 'height': height, 'icon': float(POPUP_OVERLAY_BRUSH_ICON), 'hover': -1, 'selected_tool': getattr(_settings(context), 'brush_tool', 'DRAW'), 'area': area, 'area_overlay': True, 'overlay_x': overlay_x, 'overlay_y': overlay_y, 'overlay_width': overlay_width, 'overlay_height': overlay_height, 'area_pointer': _state_area_pointer(area), 'region_pointer': _state_region_pointer(region), 'region_x': float(getattr(region, 'x', 0.0) or 0.0), 'region_y': float(getattr(region, 'y', 0.0) or 0.0), 'region_width': float(getattr(region, 'width', region_width) or region_width), 'region_height': float(getattr(region, 'height', region_height) or region_height)}
    _rebuild_popup_overlay_packets(state)
    return state

def _popup_overlay_hit_index(state, mx, my):
    for index, (x, y, w, h) in enumerate(state.get('rects', [])):
        if x <= mx <= x + w and y <= my <= y + h:
            return index
    return -1

def _popup_overlay_event_xy(state, event):
    """Return mouse coordinates in the overlay coordinate system."""
    if isinstance(state, dict) and state.get('area_overlay', False):
        try:
            return (float(event.mouse_x), float(event.mouse_y))
        except Exception:
            return (0.0, 0.0)
    region_x = float(state.get('region_x', 0.0) or 0.0)
    region_y = float(state.get('region_y', 0.0) or 0.0)
    candidates = []
    try:
        candidates.append((float(event.mouse_x) - region_x, float(event.mouse_y) - region_y))
    except Exception:
        pass
    try:
        candidates.append((float(event.mouse_region_x), float(event.mouse_region_y)))
    except Exception:
        pass
    width = float(state.get('region_width', 0.0) or 0.0)
    height = float(state.get('region_height', 0.0) or 0.0)
    for mx, my in candidates:
        if (width <= 0.0 or 0.0 <= mx <= width) and (height <= 0.0 or 0.0 <= my <= height):
            return (mx, my)
    return candidates[0] if candidates else (0.0, 0.0)

def _popup_overlay_select_brush(context, tool):
    if not tool:
        return False
    settings = _settings(context)
    settings.brush_tool = tool
    try:
        _apply_native_brush_preset(settings, tool, only_if_default=False)
    except Exception:
        pass
    try:
        _update_active_direct_brush_tool(context, tool)
    except Exception:
        pass
    return True

def _popup_overlay_select_toolbar(context, tool):
    if not tool:
        return False
    _settings(context).toolbar_tool = tool
    return True

def _toolbar_overlay_icon_path(tool_id, icon_handle=''):
    """Resolve a bundled image rendered from Blender's own toolbar icon .dat file."""
    base = os.path.dirname(__file__)
    candidate = os.path.join(base, 'icons_standard_sculpt_toolbar', (tool_id or '').lower() + '.png')
    if os.path.exists(candidate):
        return candidate
    handle = icon_handle or _toolbar_icon_spec(tool_id)
    if handle:
        candidate = os.path.join(base, 'icons_standard_sculpt_toolbar', handle + '.png')
        if os.path.exists(candidate):
            return candidate
    return ''

def _toolbar_overlay_items(context):
    result = []
    for tool_id, _name_en, _name_ja, icon_handle, _action, _shape in _toolbar_display_items():
        result.append({'id': tool_id, 'label': _toolbar_tool_label(tool_id), 'tip': tr('toolbar_tip_' + tool_id.lower()), 'path': _toolbar_overlay_icon_path(tool_id, icon_handle)})
    return result

def _build_toolbar_overlay_state(context, event):
    area, region, _rv3d = _view3d_window_region(context)
    items = _toolbar_overlay_items(context)
    columns = max(1, int(POPUP_OVERLAY_TOOLBAR_COLUMNS))
    cell = float(POPUP_OVERLAY_TOOLBAR_CELL)
    margin = float(POPUP_OVERLAY_MARGIN)
    header = float(POPUP_OVERLAY_HEADER)
    rows = int(math.ceil(len(items) / columns)) if items else 1
    width = margin * 2.0 + columns * cell
    height = margin * 2.0 + header + rows * cell
    region_width = float(getattr(region, 'width', 800) or 800)
    region_height = float(getattr(region, 'height', 600) or 600)
    overlay_x, overlay_y, overlay_width, overlay_height = _view3d_overlay_bounds(area, region)
    x = overlay_x + max(8.0, (overlay_width - width) * 0.5)
    y = overlay_y + max(8.0, (overlay_height - height) * 0.5)
    if y + height > overlay_y + overlay_height - 8.0:
        y = max(overlay_y + 8.0, overlay_y + overlay_height - height - 8.0)
    rects = []
    top = y + height - margin - header
    for index, _item in enumerate(items):
        col = index % columns
        row = index // columns
        rx = x + margin + col * cell
        ry = top - (row + 1) * cell
        rects.append((rx, ry, cell, cell))
    state = {'alive': True, 'kind': 'sculpt_toolbar', 'title_key': 'menu_sculpt_toolbar', 'items': items, 'rects': rects, 'x': x, 'y': y, 'width': width, 'height': height, 'icon': float(POPUP_OVERLAY_TOOLBAR_ICON), 'hover': -1, 'selected_tool': getattr(_settings(context), 'toolbar_tool', 'MESH_FILTER'), 'area': area, 'area_overlay': True, 'overlay_x': overlay_x, 'overlay_y': overlay_y, 'overlay_width': overlay_width, 'overlay_height': overlay_height, 'area_pointer': _state_area_pointer(area), 'region_pointer': _state_region_pointer(region), 'region_x': float(getattr(region, 'x', 0.0) or 0.0), 'region_y': float(getattr(region, 'y', 0.0) or 0.0), 'region_width': float(getattr(region, 'width', region_width) or region_width), 'region_height': float(getattr(region, 'height', region_height) or region_height)}
    _rebuild_popup_overlay_packets(state)
    return state

def _draw_toolbar_overlay(state):
    """Replay completed immutable toolbar-popup packets only."""
    _gpu_state.replay_state_packet(state)

class SES_MT_BrushAssetsPopup(Menu):
    bl_idname = 'STRICT_EDIT_SCULPT_MT_brush_assets_popup'
    bl_label = 'Brush Assets'

    def draw(self, context):
        _draw_brush_assets_popup_content(self.layout, context)

class SES_MT_SculptToolbarPopup(Menu):
    bl_idname = 'STRICT_EDIT_SCULPT_MT_sculpt_toolbar_popup'
    bl_label = 'Sculpt Toolbar'

    def draw(self, context):
        _draw_sculpt_toolbar_popup_content(self.layout, context)

def _add_popup_overlay_draw_handlers(callback, state):
    """Add draw handlers for View3D WINDOW/UI/TOOLS regions so popup overlays can cover the Sidebar."""
    handles = []
    for region_type in ('WINDOW', 'UI', 'TOOLS'):
        try:
            handle = _add_tracked_draw_handler(callback, state, region_type, 'POST_PIXEL')
            handles.append(handle)
        except Exception:
            pass
    return handles

class SES_OT_BrushAssetsPopup(Operator):
    bl_idname = 'strict_edit_sculpt.popup_brush_assets'
    bl_label = 'Open Brush Asset Popup'
    bl_description = 'Opens the full icon grid for the standard Sculpt brush asset replacements.'
    bl_options = {'BLOCKING'}

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        return tr('tip_popup_brush_assets')

    def _tag_redraw(self):
        try:
            self._area.tag_redraw()
        except Exception:
            pass

    def _finish(self, context, cancel=False):
        global _POPUP_MODAL_DEPTH
        if getattr(self, '_popup_depth_counted', False):
            _POPUP_MODAL_DEPTH = max(0, int(_POPUP_MODAL_DEPTH) - 1)
            self._popup_depth_counted = False
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
        for handle in list(getattr(self, '_draw_handles', []) or []):
            _remove_tracked_draw_handler(handle, state)
        self._draw_handles = []
        if getattr(self, '_draw_handle', None) is not None:
            _remove_tracked_draw_handler(self._draw_handle, state)
            self._draw_handle = None
        self._draw_state = None
        _release_popup_overlay_textures()
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        try:
            _status_runtime.clear('smart_sculpt_suite.edit_mode_sculpt.brush_popup', context=context)
        except Exception:
            pass
        self._tag_redraw()
        return {'CANCELLED' if cancel else 'FINISHED'}

    def invoke(self, context, event):
        if bpy.app.background or getattr(context, 'window', None) is None:
            self.report({'WARNING'}, tr('popup_open_failed'))
            return {'CANCELLED'}
        area, region, _rv3d = _view3d_window_region(context)
        if area is None or region is None:
            self.report({'WARNING'}, tr('popup_open_failed'))
            return {'CANCELLED'}
        _warm_preview_icons()
        self._area = area
        self._region = region
        self._draw_handles = []
        self._draw_state = _build_brush_asset_overlay_state(context, event)
        try:
            self._draw_handles = _add_popup_overlay_draw_handlers(_draw_brush_asset_overlay, self._draw_state)
            self._draw_handle = self._draw_handles[0] if self._draw_handles else None
            if not self._draw_handles:
                raise RuntimeError(tr('popup_open_failed'))
        except Exception as ex:
            self.report({'ERROR'}, str(ex))
            self._draw_handle = None
            return self._finish(context, cancel=True)
        try:
            context.window.cursor_modal_set('DEFAULT')
            _status_runtime.set_service('smart_sculpt_suite.edit_mode_sculpt.brush_popup', tr('tip_popup_brush_assets'), context=context)
        except Exception:
            pass
        global _POPUP_MODAL_DEPTH
        _POPUP_MODAL_DEPTH += 1
        self._popup_depth_counted = True
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self.report({'ERROR'}, tr('popup_open_failed'))
            return self._finish(context, cancel=True)
        self._tag_redraw()
        return {'RUNNING_MODAL'}

    def execute(self, context):

        class _Event:
            mouse_region_x = 0
            mouse_region_y = 0
            mouse_x = 0
            mouse_y = 0
        return self.invoke(context, _Event())

    def modal(self, context, event):
        if _ensure_edit_mesh(context) is None:
            return self._finish(context, cancel=True)
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            return self._finish(context, cancel=True)
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'NDOF_MOTION'}:
            return {'PASS_THROUGH'}
        state = getattr(self, '_draw_state', None)
        if not isinstance(state, dict):
            return self._finish(context, cancel=True)
        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            mx, my = _popup_overlay_event_xy(state, event)
            hit = _popup_overlay_hit_index(state, mx, my)
            state['mouse'] = (mx, my)
            if hit != state.get('hover', -1):
                state['hover'] = hit
                _rebuild_popup_overlay_packets(state)
                self._tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            mx, my = _popup_overlay_event_xy(state, event)
            hit = _popup_overlay_hit_index(state, mx, my)
            if hit >= 0 and hit < len(state.get('items', [])):
                tool = state['items'][hit].get('id', '')
                if _popup_overlay_select_brush(context, tool):
                    self.report({'INFO'}, tr('brush_selected'))
                    self._finish(context, cancel=False)
                    _launch_direct_brush_from_selection(context, tool)
                    return {'FINISHED'}
            return self._finish(context, cancel=True)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        _draw_brush_assets_popup_content(self.layout, context)

class SES_OT_SculptToolbarPopup(Operator):
    bl_idname = 'strict_edit_sculpt.popup_sculpt_toolbar'
    bl_label = 'Open Sculpt Toolbar Popup'
    bl_description = 'Opens the full icon button list for the standard Sculpt toolbar replacements.'
    bl_options = {'BLOCKING'}

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        return tr('tip_popup_sculpt_toolbar')

    def _tag_redraw(self):
        try:
            self._area.tag_redraw()
        except Exception:
            pass

    def _finish(self, context, cancel=False):
        global _POPUP_MODAL_DEPTH
        if getattr(self, '_popup_depth_counted', False):
            _POPUP_MODAL_DEPTH = max(0, int(_POPUP_MODAL_DEPTH) - 1)
            self._popup_depth_counted = False
        state = getattr(self, '_draw_state', None)
        if isinstance(state, dict):
            state['alive'] = False
        for handle in list(getattr(self, '_draw_handles', []) or []):
            _remove_tracked_draw_handler(handle, state)
        self._draw_handles = []
        if getattr(self, '_draw_handle', None) is not None:
            _remove_tracked_draw_handler(self._draw_handle, state)
            self._draw_handle = None
        self._draw_state = None
        _release_popup_overlay_textures()
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        try:
            _status_runtime.clear('smart_sculpt_suite.edit_mode_sculpt.toolbar_popup', context=context)
        except Exception:
            pass
        self._tag_redraw()
        return {'CANCELLED' if cancel else 'FINISHED'}

    def invoke(self, context, event):
        if bpy.app.background or getattr(context, 'window', None) is None:
            self.report({'WARNING'}, tr('popup_open_failed'))
            return {'CANCELLED'}
        area, region, _rv3d = _view3d_window_region(context)
        if area is None or region is None:
            self.report({'WARNING'}, tr('popup_open_failed'))
            return {'CANCELLED'}
        _warm_preview_icons()
        self._area = area
        self._region = region
        self._draw_handles = []
        self._draw_state = _build_toolbar_overlay_state(context, event)
        try:
            self._draw_handles = _add_popup_overlay_draw_handlers(_draw_toolbar_overlay, self._draw_state)
            self._draw_handle = self._draw_handles[0] if self._draw_handles else None
            if not self._draw_handles:
                raise RuntimeError(tr('popup_open_failed'))
        except Exception as ex:
            self.report({'ERROR'}, str(ex))
            self._draw_handle = None
            return self._finish(context, cancel=True)
        try:
            context.window.cursor_modal_set('DEFAULT')
            _status_runtime.set_service('smart_sculpt_suite.edit_mode_sculpt.toolbar_popup', tr('tip_popup_sculpt_toolbar'), context=context)
        except Exception:
            pass
        global _POPUP_MODAL_DEPTH
        _POPUP_MODAL_DEPTH += 1
        self._popup_depth_counted = True
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self.report({'ERROR'}, tr('popup_open_failed'))
            return self._finish(context, cancel=True)
        self._tag_redraw()
        return {'RUNNING_MODAL'}

    def execute(self, context):

        class _Event:
            mouse_region_x = 0
            mouse_region_y = 0
            mouse_x = 0
            mouse_y = 0
        return self.invoke(context, _Event())

    def modal(self, context, event):
        if _ensure_edit_mesh(context) is None:
            return self._finish(context, cancel=True)
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            return self._finish(context, cancel=True)
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'NDOF_MOTION'}:
            return {'PASS_THROUGH'}
        state = getattr(self, '_draw_state', None)
        if not isinstance(state, dict):
            return self._finish(context, cancel=True)
        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            mx, my = _popup_overlay_event_xy(state, event)
            hit = _popup_overlay_hit_index(state, mx, my)
            state['mouse'] = (mx, my)
            if hit != state.get('hover', -1):
                state['hover'] = hit
                _rebuild_popup_overlay_packets(state)
                self._tag_redraw()
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            mx, my = _popup_overlay_event_xy(state, event)
            hit = _popup_overlay_hit_index(state, mx, my)
            if hit >= 0 and hit < len(state.get('items', [])):
                tool = state['items'][hit].get('id', '')
                if _popup_overlay_select_toolbar(context, tool):
                    self.report({'INFO'}, tr('toolbar_selected'))
                    self._finish(context, cancel=False)
                    _launch_toolbar_tool_from_selection(context, tool)
                    return {'FINISHED'}
            return self._finish(context, cancel=True)
        return {'RUNNING_MODAL'}

    def draw(self, context):
        _draw_sculpt_toolbar_popup_content(self.layout, context)

class SES_OT_RunToolbarSelection(Operator):
    bl_idname = 'strict_edit_sculpt.run_toolbar_selection'
    bl_label = 'Use Selected Toolbar Tool'
    bl_description = 'Runs the selected standard Sculpt toolbar replacement in Mesh Edit Mode.'
    bl_options = set()
    tool: StringProperty(default='')

    @classmethod
    def poll(cls, context):
        return not bool(getattr(bpy.app, 'background', False)) and getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' and (_ensure_edit_mesh(context) is not None)

    @classmethod
    def description(cls, context, properties):
        tool = getattr(properties, 'tool', '')
        if tool:
            return tr('toolbar_tip_' + tool.lower()) + '\n' + tr('tip_run_selected_toolbar_tool')
        return tr('tip_run_selected_toolbar_tool')

    def execute(self, context):
        tool = self.tool or _settings(context).toolbar_tool
        result = _run_toolbar_tool_by_id(context, tool)
        return result if isinstance(result, set) else {'FINISHED'}

class SES_OT_CopyOperatorID(Operator):
    bl_idname = 'strict_edit_sculpt.copy_operator_id'
    bl_label = 'Copy Operator ID'
    bl_description = 'Copies a Strict Edit Mode Sculpt keymap registration operator ID to the clipboard.'
    bl_options = {'INTERNAL'}
    text: StringProperty(default='')

    @classmethod
    def description(cls, context, properties):
        return tr('tip_copy_operator_id')

    def execute(self, context):
        context.window_manager.clipboard = self.text
        self.report({'INFO'}, tr('copied_operator_id'))
        return {'FINISHED'}

class SES_OT_NativeReport(Operator):
    bl_idname = 'strict_edit_sculpt.native_report'
    bl_label = 'Native Sculpt Report'
    bl_description = 'Shows whether native sculpt operators can run directly in the current Edit Mode context without changing modes.'
    report_cache: StringProperty(default='')
    page: popup_page_property()
    page_text: popup_text_property()
    page_size: IntProperty(default=16, options={'HIDDEN', 'SKIP_SAVE'})
    page_count: IntProperty(default=1, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    @classmethod
    def description(cls, context, properties):
        return tr('tip_report')

    def _build_report(self):
        lines = [tr('diagnostic_note'), '']
        for name in _native_sculpt_ops():
            op = getattr(bpy.ops.sculpt, name, None)
            try:
                ok = bool(op.poll()) if op else False
            except Exception:
                ok = False
            status = tr('native_available') if ok else tr('native_blocked')
            lines.append(f'sculpt.{name}: {status}')
        return '\n'.join(lines)

    def execute(self, context):
        before_mode = context.object.mode if context.object else ''
        self.report_cache = self._build_report()
        after_mode = context.object.mode if context.object else ''
        if before_mode != after_mode:
            self.report({'ERROR'}, tr('mode_changed_unexpectedly'))
            return {'CANCELLED'}
        self.report({'INFO'}, tr('mode_ok'))
        return {'FINISHED'}

    def invoke(self, context, event):
        self.report_cache = self._build_report()
        content = PopupText(760)
        for line in self.report_cache.splitlines():
            if line:
                content.label(text=line)
            else:
                content.separator()
        store_popup_text(self, context, content)
        return context.window_manager.invoke_popup(self, width=760)

    def draw(self, context):
        layout = self.layout
        layout.label(text=tr('diagnostic_title'))
        layout.label(text=tr('native_intro'))
        layout.label(text=tr('native_toggle_only'))
        draw_popup_text(self, layout.column(align=True), ('Page' if _locale() == 'en_US' else 'ページ'))

def _safe_builtin_icon(icon):
    if not icon or not isinstance(icon, str):
        return 'NONE'
    if icon.startswith('preview:'):
        slug = icon.split(':', 1)[1]
        if slug.startswith('filter') or slug in {'smooth', 'relax', 'sharpen'}:
            return 'FILTER'
        if 'mask' in slug:
            return 'MOD_MASK'
        if 'face' in slug:
            return 'FACESEL'
        if 'paint' in slug or 'color' in slug:
            return 'BRUSH_DATA'
        return 'BRUSH_DATA'
    if '.' in icon:
        if 'mesh_filter' in icon or 'cloth_filter' in icon or 'color_filter' in icon:
            return 'FILTER'
        if 'mask' in icon:
            return 'MOD_MASK'
        if 'face_set' in icon:
            return 'FACESEL'
        if 'trim' in icon or 'hide' in icon:
            return 'SELECT_SUBTRACT'
        if 'translate' in icon:
            return 'EMPTY_ARROWS'
        if 'rotate' in icon:
            return 'DRIVER_ROTATIONAL_DIFFERENCE'
        if 'resize' in icon or 'transform' in icon:
            return 'TRANSFORM_ORIGINS'
        return 'SCULPTMODE_HLT'
    return icon

def _draw_section(layout, title_key, icon):
    box = layout.box()
    row = box.row(align=True)
    try:
        row.label(text=tr(title_key), icon=_safe_builtin_icon(icon))
    except TypeError:
        row.label(text=tr(title_key), icon='NONE')
    return box

def _button(grid, op_name, label_key, icon, attr_name, attr_value, text=None, force_preview=False, depress=False):
    label = tr(label_key) if text is None else text
    icon_value = 0
    if force_preview or label == '':
        icon_value = icon if isinstance(icon, int) else _ui_icon_value(icon)
    try:
        if icon_value:
            item = grid.operator(op_name, text=label, icon_value=icon_value, depress=bool(depress))
        else:
            item = grid.operator(op_name, text=label, icon=_safe_builtin_icon(icon), depress=bool(depress))
    except TypeError:
        item = grid.operator(op_name, text=label, icon='NONE')
    setattr(item, attr_name, attr_value)
    return item

def _square_icon_button(grid, op_name, label_key, icon, attr_name, attr_value):
    return _button(grid, op_name, label_key, icon, attr_name, attr_value, text='', force_preview=True)

def _popup_icon_button(grid, op_name, label_key, icon, attr_name, attr_value, selected=False, popup_kind='brush'):
    """Icon-only selector button used by popup launchers.

    The tooltip still comes from the operator description and its properties.
    Button text is intentionally empty so preview and toolbar icons cannot
    overlap labels. Popup variants use separate thumbnail sizes: brush assets
    are about 3x the previous size; toolbar tools are about 2x.
    """
    icon_spec = icon
    if popup_kind != 'toolbar' and attr_name == 'tool' and (attr_value in {item[0] for item in STANDARD_SCULPT_TOOLBAR_DATA}):
        toolbar_item = _toolbar_item(attr_value)
        if toolbar_item and (not str(toolbar_item[4]).startswith('GESTURE_')):
            icon_spec = _toolbar_safe_icon_spec(attr_value)
    icon_value = _popup_icon_value(icon_spec, popup_kind)
    kwargs = {'text': ''}
    if icon_value:
        kwargs['icon_value'] = icon_value
    else:
        kwargs['icon'] = _safe_builtin_icon(icon_spec)
    try:
        item = grid.operator(op_name, depress=bool(selected), **kwargs)
    except TypeError:
        item = grid.operator(op_name, **kwargs)
    setattr(item, attr_name, attr_value)
    return item

def draw_integrated_ui(layout, context):
    """Draw the Strict Edit Mode Sculpt controls inside Smart Sculpt Suite.

    This keeps all mesh-changing operators in Mesh Edit Mode and does not draw
    the standalone Strict Edit Sculpt N-panel when used as an embedded module.
    """
    layout = layout
    s = _settings(context)
    box = _draw_section(layout, 'section_main', 'EDITMODE_HLT')
    col = box.column(align=True)
    col.prop(s, 'enabled', text=tr('enabled'))
    col.prop(s, 'strength', text=tr('strength'), slider=True)
    col.prop(s, 'amount', text=tr('amount'))
    col.prop(s, 'iterations', text=tr('iterations'))
    col.prop(s, 'affect_visible_when_none', text=tr('affect_all'))
    col.prop(s, 'use_mask', text=tr('use_mask'))
    box = _draw_section(layout, 'section_sculpt_brush_assets', 'BRUSH_DATA')
    col = box.column(align=True)
    col.enabled = s.enabled
    col.prop(s, 'brush_tool', text=tr('brush_tool'))
    active_row = col.row(align=True)
    active_row.label(text=f"{tr('active_brush')}: {_tool_label(s.brush_tool)}", icon='BRUSH_DATA')
    start_icon = 'preview:' + _brush_slug(s.brush_tool)
    col.operator_context = 'INVOKE_DEFAULT'
    start = _button(col, 'strict_edit_sculpt.direct_brush', 'brush_start', 'BRUSH_DATA', 'tool', s.brush_tool, depress=_peek_active_direct_brush_instance() is not None)
    col.operator_context = 'EXEC_DEFAULT'
    settings_box = box.box()
    settings_box.label(text=tr('section_brush_settings'), icon='SETTINGS')
    settings_col = settings_box.column(align=True)
    settings_col.enabled = s.enabled
    settings_col.prop(s, 'brush_radius', text=tr('brush_radius'), slider=True)
    settings_col.prop(s, 'brush_strength', text=tr('brush_strength'), slider=True)
    settings_col.prop(s, 'brush_amount', text=tr('brush_amount'))
    settings_col.label(text=tr('brush_direction'))
    settings_col.prop(s, 'brush_direction', text='')
    settings_col.prop(s, 'brush_spacing', text=tr('brush_spacing'), slider=True)
    settings_col.label(text=tr('brush_falloff'))
    falloff_row = settings_col.row(align=True)
    falloff_row.prop(s, 'brush_falloff', text='')
    falloff_row.operator_context = 'INVOKE_DEFAULT'
    falloff_row.operator('strict_edit_sculpt.open_falloff_pie', text='', icon='MENU_PANEL')
    settings_col.prop(s, 'brush_hardness', text=tr('brush_hardness'), slider=True)
    settings_col.prop(s, 'brush_normal_radius', text=tr('brush_normal_radius'), slider=True)
    settings_col.prop(s, 'brush_auto_smooth', text=tr('brush_auto_smooth'), slider=True)
    settings_col.prop(s, 'brush_accumulate', text=tr('brush_accumulate'))
    settings_col.prop(s, 'brush_plane_offset', text=tr('brush_plane_offset'), slider=True)
    settings_col.prop(s, 'brush_front_faces_only', text=tr('brush_front_faces_only'))
    settings_col.prop(s, 'brush_stabilize_stroke', text=tr('brush_stabilize_stroke'))
    if s.brush_stabilize_stroke:
        settings_col.prop(s, 'brush_stabilize_radius', text=tr('brush_stabilize_radius'), slider=True)
    settings_col.prop(s, 'brush_input_samples', text=tr('brush_input_samples'))
    pressure_row = settings_col.row(align=True)
    pressure_row.prop(s, 'brush_use_pressure_size', text=tr('brush_use_pressure_size'))
    pressure_row.prop(s, 'brush_use_pressure_strength', text=tr('brush_use_pressure_strength'))
    settings_col.prop(s, 'brush_strength_hotkeys', text=tr('brush_strength_hotkeys'))
    if s.brush_strength_hotkeys:
        settings_col.prop(s, 'brush_strength_step', text=tr('brush_strength_step'), slider=True)
    popup_row = box.row(align=True)
    popup_row.enabled = s.enabled
    popup_row.operator_context = 'INVOKE_DEFAULT'
    popup_row.operator('strict_edit_sculpt.popup_brush_assets', text=tr('popup_brush_assets'), icon='BRUSH_DATA')
    box.prop(s, 'grab_offset', text=tr('grab_offset'))
    row = box.column(align=True)
    row.label(text=tr('pose_axis'))
    row.prop(s, 'pose_axis', text='')
    row.prop(s, 'pose_angle', text=tr('pose_angle'))
    box = _draw_section(layout, 'section_sculpt_toolbar', 'SCULPTMODE_HLT')
    tcol = box.column(align=True)
    tcol.enabled = s.enabled
    tcol.label(text=tr('toolbar_tool'))
    tcol.prop(s, 'toolbar_tool', text='')
    active_toolbar_row = tcol.row(align=True)
    active_toolbar_row.label(text=f"{tr('toolbar_tool')}: {_toolbar_tool_label(s.toolbar_tool)}", icon='SCULPTMODE_HLT')
    row = tcol.row(align=True)
    row.operator_context = 'INVOKE_DEFAULT'
    op = row.operator('strict_edit_sculpt.run_toolbar_selection', text=tr('run_selected_toolbar_tool'), icon='SCULPTMODE_HLT')
    op.tool = s.toolbar_tool
    prow = tcol.row(align=True)
    prow.operator_context = 'INVOKE_DEFAULT'
    prow.operator('strict_edit_sculpt.popup_sculpt_toolbar', text=tr('popup_sculpt_toolbar'), icon='SCULPTMODE_HLT')
    box = _draw_section(layout, 'section_filter', 'FILTER')
    grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    grid.enabled = s.enabled
    for op_id, label_key, _tip_key, icon in _filter_items():
        _button(grid, 'strict_edit_sculpt.vertex_operation', label_key, icon, 'operation', op_id)
    box = _draw_section(layout, 'section_mask', 'MOD_MASK')
    mask_col = box.column(align=True)
    mask_col.enabled = s.enabled
    mask_col.label(text=tr('mask_mesh_edit_lock'), icon='CHECKMARK' if bool(s.use_mask_for_mesh_editing) else 'PAUSE')
    mask_col.prop(s, 'mask_lock_threshold', text=tr('mask_lock_threshold'), slider=True)
    mask_col.label(text=tr('mask_overlay_enabled'), icon='CHECKMARK' if bool(s.mask_overlay_enabled) else 'PAUSE')
    if s.mask_overlay_enabled:
        mask_col.prop(s, 'mask_overlay_color', text=tr('mask_overlay_color'))
        mask_col.prop(s, 'mask_overlay_size', text=tr('mask_overlay_size'), slider=True)
    grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    grid.enabled = s.enabled
    for op_id, label_key, icon in [('SET', 'op_mask_set', 'MOD_MASK'), ('CLEAR', 'op_mask_clear', 'X'), ('INVERT', 'op_mask_invert', 'ARROW_LEFTRIGHT'), ('SMOOTH', 'op_mask_smooth', 'MOD_SMOOTH'), ('BOUNDARY', 'op_mask_boundary', 'EDGESEL'), ('CAVITY', 'op_mask_cavity', 'SHADING_TEXTURE')]:
        _button(grid, 'strict_edit_sculpt.mask_operation', label_key, icon, 'operation', op_id)
    box = _draw_section(layout, 'section_faceset', 'FACE_MAPS')
    box.prop(s, 'face_set_id', text=tr('face_set_id'))
    grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    grid.enabled = s.enabled
    for op_id, label_key, icon in [('ASSIGN', 'op_faceset_assign', 'FACE_MAPS'), ('SELECT', 'op_faceset_select', 'RESTRICT_SELECT_OFF'), ('HIDE', 'op_faceset_hide', 'HIDE_ON'), ('REVEAL', 'op_faceset_reveal', 'HIDE_OFF'), ('CLEAR', 'op_faceset_clear', 'X')]:
        _button(grid, 'strict_edit_sculpt.face_set_operation', label_key, icon, 'operation', op_id)
    box = _draw_section(layout, 'section_color', 'COLOR')
    box.prop(s, 'color', text=tr('color'))
    grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    grid.enabled = s.enabled
    for op_id, label_key, icon in [('SET', 'op_color_set', 'COLOR'), ('LIGHTEN', 'op_color_lighten', 'LIGHT'), ('DARKEN', 'op_color_darken', 'LIGHT'), ('SMOOTH', 'op_color_smooth', 'MOD_SMOOTH')]:
        _button(grid, 'strict_edit_sculpt.color_operation', label_key, icon, 'operation', op_id)
    box = _draw_section(layout, 'section_topology', 'MOD_REMESH')
    box.label(text=tr('sym_dir'))
    box.prop(s, 'sym_direction', text='')
    grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    grid.enabled = s.enabled
    for op_id, label_key, icon in [('TRIM_SELECTED', 'op_trim_selected', 'SELECT_SUBTRACT'), ('SUBDIVIDE', 'op_subdivide', 'MESH_GRID'), ('SYMMETRIZE', 'op_symmetrize', 'MOD_MIRROR')]:
        _button(grid, 'strict_edit_sculpt.topology_operation', label_key, icon, 'operation', op_id)
    box = _draw_section(layout, 'section_shortcut_launchers', 'KEYINGSET')
    row = box.row(align=True)
    row.label(text=tr('direct_brush_id'))
    op = row.operator('strict_edit_sculpt.copy_operator_id', text='', icon='COPYDOWN')
    op.text = 'strict_edit_sculpt.direct_brush'
    row = box.row(align=True)
    row.label(text=tr('brush_popup_id'))
    op = row.operator('strict_edit_sculpt.copy_operator_id', text='', icon='COPYDOWN')
    op.text = 'strict_edit_sculpt.popup_brush_assets'
    row = box.row(align=True)
    row.label(text=tr('toolbar_popup_id'))
    op = row.operator('strict_edit_sculpt.copy_operator_id', text='', icon='COPYDOWN')
    op.text = 'strict_edit_sculpt.popup_sculpt_toolbar'
    box = _draw_section(layout, 'section_native', 'SCULPTMODE_HLT')
    box.operator('strict_edit_sculpt.native_report', text=tr('op_report'), icon='VIEWZOOM')

class SES_PT_Main(Panel):
    bl_label = 'Strict Edit Sculpt'
    bl_idname = 'SES_PT_main'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = PANEL_CATEGORY

    @classmethod
    def poll(cls, context):
        return _ensure_edit_mesh(context) is not None

    def draw(self, context):
        draw_integrated_ui(self.layout, context)

def _ses_make_persisting_update(existing_update):

    def _update(self, context):
        if callable(existing_update):
            try:
                existing_update(self, context)
            except Exception:
                pass
        try:
            from ..core import settings as _persistent_settings
            _persistent_settings.request_immediate_save(getattr(context, 'scene', None), context, force=False)
        except Exception:
            pass
    return _update

def _ses_install_persistence_updates() -> None:
    """Static RNA definitions are not reconstructed at import time."""
    return None
classes = (SES_Settings, SES_OT_DirectBrush, SES_OT_StartDirectBrush, SES_OT_AdjustBrushValue, SES_OT_SetFalloff, SES_OT_OpenFalloffPie, SES_MT_FalloffPie, SES_OT_VertexOperation, SES_OT_MaskOperation, SES_OT_FaceSetOperation, SES_OT_ColorOperation, SES_OT_TopologyOperation, SES_OT_GestureTool, SES_OT_ToolbarOperation, SES_OT_SelectBrushAsset, SES_OT_SelectToolbarTool, SES_MT_BrushAssetsPopup, SES_MT_SculptToolbarPopup, SES_OT_BrushAssetsPopup, SES_OT_SculptToolbarPopup, SES_OT_RunToolbarSelection, SES_OT_CopyOperatorID, SES_OT_NativeReport, SES_PT_Main)
_PANEL_CLASSES = (SES_PT_Main,)
_RUNTIME_CLASSES = tuple((cls for cls in classes if cls is not SES_PT_Main))
classes = _RUNTIME_CLASSES
_REGISTERED = False
_REGISTERED_CLASSES = []
_TRANSLATIONS_REGISTERED = False

def _registration_classes(register_panel=False):
    if register_panel:
        return _RUNTIME_CLASSES + _PANEL_CLASSES
    return _RUNTIME_CLASSES

def _delete_scene_settings_pointer():
    if _rna_safety is not None:
        _rna_safety.unregister_property(bpy.types.Scene, 'strict_edit_mode_sculpt_settings')

def _edit_blender_exit_unregister_in_progress() -> bool:
    if _rna_safety is None:
        return False
    try:
        return bool(_rna_safety.is_blender_exit_unregister_in_progress())
    except Exception:
        return False

def _safe_register_class(cls):
    if _rna_safety is not None:
        return _rna_safety.register_class(cls)
    if not isinstance(cls, type):
        return False
    try:
        return bool(_rna_safety.register_class(cls)) if _rna_safety is not None else False
    except Exception:
        return False
    return True

def _safe_unregister_class(cls):
    if _rna_safety is not None:
        _rna_safety.unregister_class(cls)
        return
    if not isinstance(cls, type):
        return
    try:
        if _rna_safety is not None:
            _rna_safety.unregister_class(cls)
    except Exception:
        pass

def register(*, register_panel=False):
    global _REGISTERED, _REGISTERED_CLASSES, _TRANSLATIONS_REGISTERED
    if _REGISTERED:
        return
    registered_now = []
    try:
        _lifecycle.register_translation(ADDON_ID, _TRANSLATION_TABLE)
        _TRANSLATIONS_REGISTERED = True
        # Resolve all packaged preview/tool icons once at registration. Draw and
        # enum callbacks are cache-only and never perform filesystem/GPU work.
        _warm_preview_icons()
        for cls in _registration_classes(register_panel):
            if not _safe_register_class(cls):
                raise RuntimeError(f'Edit Sculpt class registration failed: {cls.__name__}')
            registered_now.append(cls)
        _rna_safety.register_property(bpy.types.Scene, 'strict_edit_mode_sculpt_settings', PointerProperty(type=SES_Settings))
        _REGISTERED_CLASSES = list(registered_now)
        _REGISTERED = True
        _sync_mask_runtime(getattr(bpy, 'context', None))
    except Exception:
        _REGISTERED = False
        _remove_mask_lock_timer()
        _remove_mask_overlay_handler()
        _cancel_direct_brush_history_action()
        _cleanup_draw_handlers()
        _rna_safety.unregister_property(bpy.types.Scene, 'strict_edit_mode_sculpt_settings')
        for cls in reversed(registered_now):
            _safe_unregister_class(cls)
        _REGISTERED_CLASSES = []
        if _TRANSLATIONS_REGISTERED:
            _lifecycle.unregister_translation(ADDON_ID)
        _TRANSLATIONS_REGISTERED = False
        raise

def unregister():
    global _REGISTERED, _REGISTERED_CLASSES, _PREVIEW_COLLECTION, _TRANSLATIONS_REGISTERED
    _GESTURE_UNDO_BASELINED_MESHES.clear()
    _remove_mask_lock_timer()
    _remove_mask_overlay_handler()
    _cancel_direct_brush_history_action()
    _cancel_active_direct_brush_for_reload()
    _cleanup_draw_handlers()
    _reset_mask_lock_anchors()
    _rna_safety.unregister_property(bpy.types.Scene, 'strict_edit_mode_sculpt_settings')
    for cls in reversed(_REGISTERED_CLASSES):
        _safe_unregister_class(cls)
    _REGISTERED_CLASSES = []
    if _PREVIEW_COLLECTION is not None and _PREVIEW_COLLECTION is not False:
        _lifecycle.release_resource(_PREVIEW_COLLECTION, 'preview_collection')
    _PREVIEW_COLLECTION = None
    _TOOL_ICON_CACHE.clear()
    _BRUSH_ASSET_ICON_CACHE.clear()
    _BRUSH_ASSET_OBJECT_CACHE.clear()
    _POPUP_OVERLAY_TEXTURES.clear()
    _release_icon_values()
    if _TRANSLATIONS_REGISTERED:
        _lifecycle.unregister_translation(ADDON_ID)
    _TRANSLATIONS_REGISTERED = False
    _REGISTERED = False
if __name__ == '__main__':
    register(register_panel=True)
