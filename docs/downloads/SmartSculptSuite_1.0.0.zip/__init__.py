# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Smart Sculpt Suite Blender Extension bootstrap."""
from __future__ import annotations
import importlib
import sys
from typing import Any
import bpy
from . import _sss_lifecycle as _lifecycle
from . import _sss_runtime_errors as _errors
from . import rna_safety as _rna
from . import _sss_ownership as _ownership

bl_info={
    'name':'Smart Sculpt','author':'JELararagi','version':(1, 0, 0),
    'blender':(5,1,0),'location':'Sidebar > Smart Sculpt',
    'description':'Smart Sculpt workflow tools for Blender 5.1.',
    'category':'Sculpt',
}
_ROOT_TRANSLATION_PAIRS={
    'Open Smart Sculpt':'スマートスカルプトを開く',
    'Open the Smart Sculpt N-panel.':'スマートスカルプトのNパネルを開きます。',
}
_TRANSLATIONS={locale:{(context,en):ja for en,ja in _ROOT_TRANSLATION_PAIRS.items() for context in (None,'*','Operator','Tooltip')}
               for locale in ('ja','ja_JP','ja_JP.UTF-8','ja_JP.utf8')}
_REGISTERED=False
_REGISTERED_MODULES:list[Any]=[]
_MODULE_IDENTITY=0
_OWNER_KEY='SMART_SCULPT_SUITE_OWNER'
_LEGACY_OWNER_KEYS=('SMART_SCULPT_SUITE_OWNER_V1944','SMART_SCULPT_SUITE_OWNER_V1943','SMART_SCULPT_SUITE_OWNER_V1937')

def _import(name:str): return importlib.import_module(f'{__package__}.{name}')
def _preferences_module(): return _import('preferences')
def _core_module(): return _import('core')
def _common_module(): return _import('common')
def _navigation_module(): return _import('navigation')
def _mask_facesets_module(): return _import('mask_facesets_tools')
def _fixed_roots_module(): return _import('_sss_fixed_roots')
def _legacy_proxy_cleanup_module(): return _import('core.legacy_proxy_cleanup')

def _owner_token(journal):
    return {'owner_uuid':_lifecycle.OWNER_UUID,'generation_uuid':journal.generation_uuid,
            'revision':_lifecycle.REVISION,'module_identity':_MODULE_IDENTITY}
def _install_owner_token(journal):
    namespace=getattr(getattr(bpy,'app',None),'driver_namespace',None)
    if not isinstance(namespace,dict): return
    for key in (_OWNER_KEY,*_LEGACY_OWNER_KEYS):
        existing=namespace.get(key)
        if existing is None:
            continue
        # Only an exact Smart Sculpt token can be discarded.  Foreign values
        # are never touched.  begin_registration() has already adopted or
        # exactly rolled back any live generation before this boundary.
        if isinstance(existing,dict) and existing.get('owner_uuid')==_lifecycle.OWNER_UUID:
            namespace.pop(key,None)
            continue
        _errors.warn_once('owner-token-collision',
                          'Smart Sculpt owner token key is occupied by a foreign value; continuing without replacing it')
        return False
    token=_owner_token(journal); namespace[_OWNER_KEY]=token
    def remove(value):
        ns,key,expected=value
        if ns.get(key) is expected: ns.pop(key,None)
    journal.acquire('owner_token',(namespace,_OWNER_KEY,token),remove,metadata={'owner_uuid':_lifecycle.OWNER_UUID})
    return True

def _register_translation_payload():
    _lifecycle.register_translation(__name__,_TRANSLATIONS)

def _register_module(module):
    if module in _REGISTERED_MODULES: return
    if _lifecycle.register_module(module): _REGISTERED_MODULES.append(module)
def _unregister_module(module):
    _lifecycle.unregister_module(module)
    try: _REGISTERED_MODULES.remove(module)
    except ValueError: pass

def _safe_text(en,ja):
    try:
        lang=str(getattr(getattr(bpy.context.preferences,'view',None),'language','') or '').lower()
        return ja if lang.startswith('ja') else en
    except Exception: return en

def is_main_runtime_enabled():
    journal = _lifecycle.current_journal()
    loaded_core = sys.modules.get(f'{__package__}.core')
    if journal is not None and str(getattr(journal, 'state', '')) == 'READY':
        return bool(getattr(loaded_core, '_RUNTIME_REGISTERED', False)) if loaded_core is not None else False
    return bool(getattr(loaded_core, '_RUNTIME_REGISTERED', False)) if loaded_core is not None else False
def is_integrated_runtime_enabled(): return is_main_runtime_enabled()
def enable_main_runtime():
    if is_main_runtime_enabled(): return True,_safe_text('Smart Sculpt runtime is already loaded.','スマートスカルプトランタイムはすでに読み込み済みです。')
    try: _register_module(_core_module()); return True,_safe_text('Smart Sculpt runtime loaded.','スマートスカルプトランタイムを読み込みました。')
    except Exception as exc: _errors.record('main_runtime',exc); return False,str(exc)
def disable_main_runtime():
    try: _unregister_module(_core_module()); return True,_safe_text('Smart Sculpt runtime unloaded.','スマートスカルプトランタイムを停止しました。')
    except Exception as exc: _errors.record('main_runtime_unload',exc); return False,str(exc)
def ensure_integrated_runtime(): return enable_main_runtime()
def release_integrated_runtime(): return disable_main_runtime()
def ensure_runtime_initialized(context=None,*_args,force=False,**_kwargs): del context,force; return enable_main_runtime()[0]
def _sss_repair_runtime(context=None): del context; return None

class SMARTSCULPTSUITE_OT_open_tools(bpy.types.Operator):
    bl_idname='wm.core_open_tools'; bl_label='Open Smart Sculpt'; bl_description='Open the Smart Sculpt N-panel.'; bl_options=set()
    _sms_no_undo=True
    def execute(self,context):
        ok,message=enable_main_runtime()
        if not ok:
            self.report({'ERROR'},message); return {'CANCELLED'}
        # The panel lives in the sidebar of the 3D View: show it, here or in this screen's views.
        space=getattr(context,'space_data',None)
        if getattr(space,'type','')=='VIEW_3D':
            space.show_region_ui=True
        else:
            for area in getattr(getattr(context,'screen',None),'areas',()):
                if area.type=='VIEW_3D':
                    area.spaces.active.show_region_ui=True
        return {'FINISHED'}
_CLASSES=(SMARTSCULPTSUITE_OT_open_tools,)

def _register_degraded_step(tag, callback):
    try:
        return callback()
    except Exception as exc:
        _errors.warn_once(tag, exc)
        return None


def _register_impl():
    """Register every independently available surface without escaping errors.

    Blender can invoke add-on registration before a complete window/context is
    available or after a failed live replacement.  Each acquisition is exact
    generation-owned; a failed optional step is rolled back to its module
    checkpoint and recorded once in the bounded UI diagnostic state.
    """
    global _REGISTERED,_MODULE_IDENTITY
    if _REGISTERED:
        return None
    _MODULE_IDENTITY=id(register)
    try:
        journal=_lifecycle.begin_registration(_MODULE_IDENTITY)
    except Exception as exc:
        # Absolute enable boundary: restricted startup/live-reload failures are
        # recorded once and registration continues with a fresh exact journal.
        _errors.warn_once('lifecycle-begin', exc)
        journal=_lifecycle.force_new_registration(_MODULE_IDENTITY)
    if str(getattr(journal,'state',''))=='READY':
        _REGISTERED=True
        return None

    _register_degraded_step('owner-token', lambda: _install_owner_token(journal))
    _register_degraded_step('translation-root', _register_translation_payload)
    for cls in _CLASSES:
        _register_degraded_step(f'class:{getattr(cls,"__name__","unknown")}', lambda cls=cls: _rna.register_class(cls))

    module_factories=(
        ('preferences',_preferences_module),
        ('core',_core_module),
        ('navigation',_navigation_module),
        ('mask-facesets',_mask_facesets_module),
        ('common',_common_module),
        ('fixed-roots',_fixed_roots_module),
        ('integrated-compatibility',lambda: _import('core.runtime')),
    )
    for tag,factory in module_factories:
        module=_register_degraded_step(f'import:{tag}',factory)
        if module is not None:
            _register_degraded_step(f'module:{tag}',lambda module=module:_register_module(module))

    # Modules imported above add English/Japanese pairs while they load.
    _register_degraded_step('translation-runtime',lambda: _import('translation').register_translations())

    try:
        journal.commit()
    except Exception as exc:
        _errors.warn_once('lifecycle-commit',exc)
        # The journal remains the exact owner of every successful acquisition.
        # Marking it READY permits safe use and a later exact disable rollback.
        try:
            journal.state='READY'
            journal.last_error=str(exc)[:1024]
            _lifecycle._sync(journal,'degraded_commit')
        except Exception as sync_exc:
            _errors.warn_once('lifecycle-commit-sync',sync_exc)
    _REGISTERED=True
    return None


def register():
    """Absolute Blender enable boundary: never propagate a registration error."""
    global _REGISTERED, _MODULE_IDENTITY
    try:
        return _register_impl()
    except Exception as exc:
        try:
            _errors.warn_once('register-boundary', exc)
        except Exception:
            pass
        try:
            if not _MODULE_IDENTITY:
                _MODULE_IDENTITY = id(register)
            journal = _lifecycle.current_journal()
            if journal is None or str(getattr(journal, 'state', '')) == 'CLOSED':
                journal = _lifecycle.force_new_registration(_MODULE_IDENTITY)
            if str(getattr(journal, 'state', '')) == 'OPEN':
                journal.state = 'READY'
                journal.last_error = str(exc)[:1024]
                try:
                    _lifecycle._sync(journal, 'degraded_register_boundary')
                except Exception:
                    pass
        except Exception:
            pass
        _REGISTERED = True
        return None


def unregister():
    global _REGISTERED
    journal=_lifecycle.current_journal()
    if journal is not None:
        try:
            journal.rollback('unregister')
        except Exception as exc:
            _errors.warn_once('unregister-rollback',exc)
    try:
        _lifecycle.retry_orphan_cleanup('unregister')
    except Exception as exc:
        _errors.warn_once('unregister-orphan-cleanup',exc)
    try:
        _ownership.clear_registry()
    except Exception as exc:
        _errors.warn_once('unregister-data-ledger',exc)
    _REGISTERED_MODULES.clear()
    _REGISTERED=False
    return None

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
