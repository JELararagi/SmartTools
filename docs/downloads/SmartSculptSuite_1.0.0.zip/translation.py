from __future__ import annotations
import importlib
import re
from collections import OrderedDict
from typing import Any
import bpy
from . import _sss_lifecycle as _lifecycle
_JAPANESE_TEXT_RE = re.compile('[\\u3040-\\u30ff\\u4e00-\\u9fff]')
_LAYOUT_TEXT_KWARGS = {'text', 'heading', 'placeholder'}
_POSITIONAL_TEXT_INDEXES = {'label': (0,), 'operator': (1,), 'menu': (1,), 'popover': (1,), 'prop': (2,), 'prop_enum': (2,), 'prop_menu_enum': (2,), 'operator_menu_enum': (2,), 'operator_enum': (2,)}
_PROP_FACTORY_NAMES = {'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty', 'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty', 'PointerProperty', 'StringProperty'}
_TRANSLATION_CONTEXTS = (None, '*', 'Operator', 'Property', 'Tooltip', 'UI', 'Panel', 'Menu', 'Addon')
_TRANSLATION_LOCALES = ('ja', 'ja_JP', 'ja_JP.UTF-8', 'ja_JP.utf8')
_TRANSLATION_OWNER = (__package__ or __name__ or 'core') + '.translation_runtime'
_DYNAMIC_PAIR_LIMIT = 4096
_DYNAMIC_EN_TO_JA: OrderedDict[str, str] = OrderedDict()
_EN_TO_JA_CACHE: dict[str, str] | None = None
_JA_TO_EN_CACHE: dict[str, str] | None = None
_SOURCE_TO_EN_CACHE: dict[str, str] | None = None
_REGISTERED = False
_TRANSLATION_REVISION = 0
_REGISTERED_REVISION = -1

def _invalidate_cache() -> None:
    global _EN_TO_JA_CACHE, _JA_TO_EN_CACHE, _SOURCE_TO_EN_CACHE
    _EN_TO_JA_CACHE = None
    _JA_TO_EN_CACHE = None
    _SOURCE_TO_EN_CACHE = None

def locale_is_japanese() -> bool:
    try:
        prefs = getattr(bpy.context, 'preferences', None)
        view = getattr(prefs, 'view', None) if prefs else None
        if view is not None:
            if not getattr(view, 'use_translate_interface', True):
                return False
            language = str(getattr(view, 'language', 'DEFAULT') or 'DEFAULT')
            language_upper = language.upper()
            if language_upper.startswith('JA') or language_upper in {'JAPANESE', 'JA_JP'}:
                return True
            if language_upper not in {'DEFAULT', 'DEFAULT_LANGUAGE'}:
                return False
        locale = getattr(getattr(bpy.app, 'translations', None), 'locale', '') or ''
        return str(locale).lower().startswith('ja')
    except Exception:
        return False

def ui_text(english: str, japanese: str) -> str:
    return str(japanese if locale_is_japanese() else english)

def contains_japanese_text(text: str | None) -> bool:
    return bool(_JAPANESE_TEXT_RE.search(str(text or '')))

def _first_japanese_index(text: str | None) -> int:
    match = _JAPANESE_TEXT_RE.search(str(text or ''))
    return match.start() if match else -1

def _split_bilingual_by_safe_separator(raw: str) -> tuple[str, str]:
    spaced = None
    for match in re.finditer(r"\s+/\s+", raw):
        if not contains_japanese_text(raw[:match.start()]) and contains_japanese_text(raw[match.end():]):
            spaced = match
    if spaced is not None:
        return raw[:spaced.start()].strip(), raw[spaced.end():].strip()
    best_fallback: tuple[str, str, int] | None = None
    for match in re.finditer('\\s*/\\s*', raw):
        english = raw[:match.start()].strip()
        japanese = raw[match.end():].strip()
        if not english or not japanese:
            continue
        if contains_japanese_text(english) or not contains_japanese_text(japanese):
            continue
        first_japanese = _first_japanese_index(japanese)
        if first_japanese < 0:
            continue
        if best_fallback is None:
            best_fallback = (english, japanese, first_japanese)
        if first_japanese <= 72:
            return (english, japanese)
    if best_fallback is not None:
        return (best_fallback[0], best_fallback[1])
    return ('', '')

def split_bilingual_text(text: str | None) -> tuple[str, str]:
    raw = str(text or '').strip()
    if not raw:
        return ('', '')
    english, japanese = _split_bilingual_by_safe_separator(raw)
    if english or japanese:
        return (english, japanese)
    if contains_japanese_text(raw):
        return ('', raw)
    return (raw, '')

def register_pair(english: str | None, japanese: str | None, *, english_display: str | None=None) -> str:
    global _TRANSLATION_REVISION
    source = str(english or '').strip()
    target = str(japanese or '').strip()
    if not source or not target or source == target:
        return source
    display = str(english_display or source).strip() or source
    old_source = _DYNAMIC_EN_TO_JA.get(source)
    old_display = _DYNAMIC_EN_TO_JA.get(display)
    changed = old_source != target or old_display != target
    for key in (source, display):
        _DYNAMIC_EN_TO_JA[key] = target
        _DYNAMIC_EN_TO_JA.move_to_end(key)
    evicted = False
    while len(_DYNAMIC_EN_TO_JA) > _DYNAMIC_PAIR_LIMIT:
        _DYNAMIC_EN_TO_JA.popitem(last=False)
        evicted = True
    if changed:
        _TRANSLATION_REVISION += 1
        if (not evicted) and _EN_TO_JA_CACHE is not None and _JA_TO_EN_CACHE is not None and (_SOURCE_TO_EN_CACHE is not None) and (old_source in (None, target)) and (old_display in (None, target)):
            _EN_TO_JA_CACHE[source] = target
            _EN_TO_JA_CACHE[display] = target
            if display != source:
                _SOURCE_TO_EN_CACHE[source] = display
            _JA_TO_EN_CACHE.setdefault(target, display)
        else:
            _invalidate_cache()
    return display

def _package_root_name() -> str:
    package = str(__package__ or '').strip()
    if package:
        return package
    module_name = str(__name__ or 'smart_sculpt_suite.translation').strip()
    if '.' in module_name:
        return module_name.rsplit('.', 1)[0]
    return 'core'

def _try_import(module_name: str):
    """Import one known package module; never enumerate or rewrite sys.modules."""
    try:
        return importlib.import_module(str(module_name))
    except Exception:
        return None

def _load_translation_maps() -> tuple[dict[str, str], dict[str, str]]:
    en_to_ja: dict[str, str] = {}
    source_to_en: dict[str, str] = {}
    root = _package_root_name()
    mod = _try_import(f'{root}.core.translation')
    if mod is not None:
        try:
            en_to_ja.update({str(k): str(v) for k, v in dict(getattr(mod, '_JA_MAP', {}) or {}).items() if str(k or '') and str(v or '')})
        except Exception:
            pass
    mod = _try_import(f'{root}.navigation.translation')
    if mod is not None:
        try:
            en_to_ja.update({str(k): str(v) for k, v in dict(getattr(mod, '_BASE_TRANSLATIONS', {}) or {}).items() if str(k or '') and str(v or '')})
        except Exception:
            pass
    mod = _try_import(f'{root}.mask_facesets_tools.translation')
    if mod is not None:
        try:
            tables = dict(getattr(mod, 'TRANSLATIONS', {}) or {})
            en_table = dict(tables.get('en_US', {}) or {})
            ja_table = dict(tables.get('ja_JP', {}) or {})
            for source, ja_value in ja_table.items():
                source_text = str(source or '').strip()
                ja_text = str(ja_value or '').strip()
                if not source_text or not ja_text:
                    continue
                display_en = str(en_table.get(source, source_text) or source_text).strip()
                en_to_ja[source_text] = ja_text
                en_to_ja[display_en] = ja_text
                if display_en and display_en != source_text:
                    source_to_en[source_text] = display_en
        except Exception:
            pass
    en_to_ja.update(_DYNAMIC_EN_TO_JA)
    return (en_to_ja, source_to_en)

def _maps() -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    global _EN_TO_JA_CACHE, _JA_TO_EN_CACHE, _SOURCE_TO_EN_CACHE
    if _EN_TO_JA_CACHE is None or _JA_TO_EN_CACHE is None or _SOURCE_TO_EN_CACHE is None:
        en_to_ja, source_to_en = _load_translation_maps()
        ja_to_en: dict[str, str] = {}
        for en_text, ja_text in en_to_ja.items():
            en_text = str(en_text or '').strip()
            ja_text = str(ja_text or '').strip()
            if not en_text or not ja_text:
                continue
            ja_to_en.setdefault(ja_text, source_to_en.get(en_text, en_text))
        _EN_TO_JA_CACHE = en_to_ja
        _JA_TO_EN_CACHE = ja_to_en
        _SOURCE_TO_EN_CACHE = source_to_en
    return (_EN_TO_JA_CACHE, _JA_TO_EN_CACHE, _SOURCE_TO_EN_CACHE)

def canonicalize_text(text: str | None) -> str:
    raw = str(text or '').strip()
    if not raw:
        return ''
    english, japanese = split_bilingual_text(raw)
    if english and japanese:
        register_pair(english, japanese)
        return english
    en_to_ja, ja_to_en, source_to_en = _maps()
    if raw in source_to_en:
        return source_to_en[raw]
    if contains_japanese_text(raw):
        return ja_to_en.get(raw, raw)
    return raw

def japanese_for_english(text: str | None) -> str:
    """Return the registered Japanese for an English msgid, or an empty string."""
    return _maps()[0].get(str(text or '').strip(), '')

def localize_any_text(text: str | None) -> str:
    raw = str(text or '').strip()
    if not raw:
        return ''
    english, japanese = split_bilingual_text(raw)
    if english and japanese:
        register_pair(english, japanese)
        return ui_text(english, japanese)
    en_to_ja, ja_to_en, source_to_en = _maps()
    canonical = source_to_en.get(raw, raw)
    if locale_is_japanese():
        if contains_japanese_text(raw) and raw not in ja_to_en:
            return raw
        return en_to_ja.get(raw) or en_to_ja.get(canonical) or raw
    if contains_japanese_text(raw):
        return ja_to_en.get(raw, raw)
    return canonical

def localize_bilingual_text(text: str | None, *, fallback_japanese: str | None=None) -> str:
    english, japanese = split_bilingual_text(text)
    if not english and (not japanese):
        return ''
    if not japanese:
        japanese = str(fallback_japanese or english)
    if not english:
        english = canonicalize_text(text)
    register_pair(english, japanese)
    return ui_text(english, japanese)

def exception_ui_text(exc) -> str:
    """Return an exception as a short sentence in the active UI language."""
    raw = str(exc or '').strip()
    if contains_japanese_text(raw) and locale_is_japanese():
        return raw
    if 'poll() failed' in raw or 'context is incorrect' in raw:
        return ui_text('This cannot run in the current mode or selection.', 'いまのモードや選択では実行できません。')
    if locale_is_japanese():
        return '内部の処理でエラーが発生しました。'
    # 英語設定で残すのは、アドオンが利用者向けに書いた文（RuntimeError や文字列）だけ。
    if not raw or contains_japanese_text(raw) or (isinstance(exc, BaseException) and type(exc) is not RuntimeError):
        return 'An internal error occurred.'
    return raw.splitlines()[0]

def localize_bilingual_format(text: str | None, /, *args, fallback_japanese: str | None=None, **kwargs) -> str:
    template = localize_bilingual_text(text, fallback_japanese=fallback_japanese)
    if not template:
        return ''
    args = tuple(exception_ui_text(value) if isinstance(value, BaseException) else value for value in args)
    kwargs = {key: exception_ui_text(value) if isinstance(value, BaseException) else value for key, value in kwargs.items()}
    try:
        return template.format(*args, **kwargs)
    except Exception:
        return template

def translate_registered_text(text: str | None) -> str:
    """Translate a single UI string to the active add-on/Blender interface language."""
    value = canonicalize_text(text)
    if not value:
        return ''
    if locale_is_japanese():
        en_to_ja, _ja_to_en, _source_to_en = _maps()
        if value in en_to_ja:
            return en_to_ja[value]
        try:
            translated = bpy.app.translations.pgettext_iface(value)
            if translated:
                return str(translated)
        except Exception:
            pass
    return value

def _localize_layout_arg(value):
    if isinstance(value, str):
        return translate_registered_text(value)
    return value

class _LocalizedUILayout:
    """Small proxy that localizes UILayout text arguments without changing layout behavior."""
    __slots__ = ('_layout',)

    def __init__(self, layout):
        object.__setattr__(self, '_layout', layout)

    def __getattr__(self, name):
        attr = getattr(object.__getattribute__(self, '_layout'), name)
        if not callable(attr):
            return attr

        def _wrapped(*args, **kwargs):
            if args:
                indexes = _POSITIONAL_TEXT_INDEXES.get(str(name), ())
                if indexes:
                    args = list(args)
                    for index in indexes:
                        if index < len(args):
                            args[index] = _localize_layout_arg(args[index])
                    args = tuple(args)
            if kwargs:
                kwargs = dict(kwargs)
                for key in _LAYOUT_TEXT_KWARGS:
                    if key in kwargs:
                        kwargs[key] = _localize_layout_arg(kwargs[key])
            result = attr(*args, **kwargs)
            return localized_layout(result)
        return _wrapped

    def __setattr__(self, name, value):
        setattr(object.__getattribute__(self, '_layout'), name, value)

    def __bool__(self):
        return bool(object.__getattribute__(self, '_layout'))

def _is_blender_ui_layout(value) -> bool:
    try:
        return isinstance(value, bpy.types.UILayout)
    except Exception:
        return value.__class__.__name__ == 'UILayout'

def localized_layout(layout):
    """Return Blender's native UILayout object unchanged.

    Blender 5.x is sensitive to drawing through Python proxy objects while a
    Panel.draw callback is running.  Text localization is handled by explicit
    ui_text()/translation calls and RNA translation registration instead of
    wrapping UILayout, so the standard N-panel draw path stays native.
    """
    try:
        if isinstance(layout, _LocalizedUILayout) or layout.__class__.__name__ == '_LocalizedUILayout':
            try:
                return object.__getattribute__(layout, '_layout')
            except Exception:
                return getattr(layout, '_layout', layout)
    except Exception:
        pass
    return layout

def _property_keywords(prop_def) -> tuple[dict[str, Any] | None, str]:
    keywords = getattr(prop_def, 'keywords', None)
    if isinstance(keywords, dict):
        function = getattr(prop_def, 'function', None)
        return (keywords, str(getattr(function, '__name__', '') or ''))
    if isinstance(prop_def, tuple) and len(prop_def) == 2 and isinstance(prop_def[1], dict):
        return (prop_def[1], str(prop_def[0] or ''))
    return (None, '')

def _canonicalize_property_items(items):
    if not isinstance(items, (list, tuple)):
        return items
    changed = False
    rebuilt_items = []
    for item in items:
        if not isinstance(item, (list, tuple)) or len(item) < 2:
            rebuilt_items.append(item)
            continue
        rebuilt = list(item)
        for index in (1, 2):
            if index < len(rebuilt) and isinstance(rebuilt[index], str):
                raw = rebuilt[index]
                new = canonicalize_text(raw)
                if new != raw:
                    rebuilt[index] = new
                    changed = True
        rebuilt_items.append(tuple(rebuilt) if isinstance(item, tuple) else rebuilt)
    if not changed:
        return items
    return tuple(rebuilt_items) if isinstance(items, tuple) else rebuilt_items

def normalize_class_texts(classes) -> None:
    """Use English msgids for RNA registration and keep Japanese through translations.

    Older builds sometimes created RNA labels/descriptions in the active language at
    import time.  Blender then kept that language even after the UI language changed.
    This pass rewrites registered class and property metadata back to English msgids;
    Japanese display is supplied by registered translation dictionaries.
    """
    for cls in tuple(classes or ()):
        if not isinstance(cls, type):
            continue
        for attr_name in ('bl_label', 'bl_description', 'bl_category'):
            try:
                value = getattr(cls, attr_name, None)
            except Exception:
                value = None
            if isinstance(value, str) and value:
                try:
                    setattr(cls, attr_name, canonicalize_text(value))
                except Exception:
                    pass
        annotations = getattr(cls, '__annotations__', None)
        if not isinstance(annotations, dict):
            continue
        for _prop_name, prop_def in annotations.items():
            keywords, factory_name = _property_keywords(prop_def)
            if not isinstance(keywords, dict):
                continue
            if factory_name and factory_name not in _PROP_FACTORY_NAMES:
                continue
            for key in ('name', 'description'):
                value = keywords.get(key)
                if isinstance(value, str) and value:
                    keywords[key] = canonicalize_text(value)
            if 'items' in keywords:
                keywords['items'] = _canonicalize_property_items(keywords.get('items'))

def translation_dict() -> dict[str, dict[tuple[str | None, str], str]]:
    en_to_ja, _ja_to_en, _source_to_en = _maps()
    return {locale: {(context, english): japanese for english, japanese in en_to_ja.items() if str(english or '') and str(japanese or '') for context in _TRANSLATION_CONTEXTS} for locale in _TRANSLATION_LOCALES}

def register_translations() -> None:
    global _REGISTERED, _REGISTERED_REVISION
    if _REGISTERED and _REGISTERED_REVISION == _TRANSLATION_REVISION:
        return
    # register_pair() may have added pairs since the last registration; Blender keeps a
    # payload by owner key, so the previous one has to be released before the update.
    if _REGISTERED:
        _lifecycle.unregister_translation(_TRANSLATION_OWNER)
    _lifecycle.register_translation(_TRANSLATION_OWNER, translation_dict())
    _REGISTERED = True
    _REGISTERED_REVISION = _TRANSLATION_REVISION

def unregister_translations() -> None:
    global _REGISTERED, _REGISTERED_REVISION
    _lifecycle.unregister_translation(_TRANSLATION_OWNER)
    _REGISTERED = False
    _REGISTERED_REVISION = -1
