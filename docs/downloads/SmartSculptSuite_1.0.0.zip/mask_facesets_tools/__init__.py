bl_info = {'name': 'Sculpt Mask FaceSets Tools', 'author': 'JELararagi', 'version': (1, 0, 0), 'blender': (5, 1, 0), 'location': 'View3D > Sculpt Mode', 'description': 'Sculpt Mask FaceSets support Tools', 'warning': '', 'category': 'Sculpt'}
import os
import sys
import bpy
try:
    import rna_keymap_ui
except Exception:
    rna_keymap_ui = None
from bpy.types import Menu, Operator, Panel, UIList, PropertyGroup
try:
    from bl_ui.space_toolsystem_common import ToolSelectPanelHelper, ToolDef
except Exception:
    ToolSelectPanelHelper = None
    ToolDef = None
from bpy.props import StringProperty, EnumProperty, BoolProperty
from bpy.app.handlers import persistent
from . import translation
try:
    from .. import translation as _translation
    from .. import rna_safety as _rna_safety
    from .. import _sss_lifecycle as _lifecycle
    from .. import _sss_transactions as _transactions
except Exception:
    import translation as _translation
    _rna_safety = None
    _lifecycle = None

def _root_package_name():
    package_name = str(__package__ or __name__ or '').strip()
    return package_name.rsplit('.mask_facesets_tools', 1)[0] if '.mask_facesets_tools' in package_name else package_name.rsplit('.', 1)[0]

def _root_tool_preferences(context=None):
    try:
        root_name = _root_package_name()
        if not root_name:
            return None
        prefs_module = sys.modules.get(f'{root_name}.preferences')
        find_fn = getattr(prefs_module, 'find_tool_settings', None) if prefs_module is not None else None
        if callable(find_fn):
            return find_fn('mask_facesets_tools', context=context)
    except Exception:
        pass
    return None

def _find_addon_preferences(context=None, addon_name: str | None=None):
    return _root_tool_preferences(context=context)
_current_language = 'AUTO'

def _resolve_language_code(lang_code=None):
    code = str(lang_code or _current_language or 'AUTO').strip().upper()
    if code in {'', 'AUTO', 'DEFAULT', 'DEFAULT_LANGUAGE'}:
        try:
            return 'ja_JP' if _translation.locale_is_japanese() else 'en_US'
        except Exception:
            return 'en_US'
    if code.startswith('JA'):
        return 'ja_JP'
    return 'en_US'

def gettext(msg):
    """Return the translated text for the active language."""
    return translation.get_translation(_resolve_language_code(), msg)

def update_language(lang_code):
    """Update the requested language mode and redraw the UI."""
    global _current_language
    _current_language = str(lang_code or 'AUTO')
    _refresh_ui()

def get_current_language():
    """Return the resolved UI language code."""
    return _resolve_language_code()

def get_current_language_name():
    """Return the localized UI language name."""
    return '日本語' if get_current_language() == 'ja_JP' else 'English'

def _refresh_ui():
    """刷新所有UI区域"""
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception as e:
        None
_ = gettext

def _icon(icon: str | None, fallback: str='NONE') -> str:
    try:
        root_name = _root_package_name()
        _smart_utils = sys.modules.get(f'{root_name}.core.utils') if root_name else None
        safe = getattr(_smart_utils, 'safe_icon', None) if _smart_utils is not None else None
        if callable(safe):
            return safe(icon, fallback)
    except Exception:
        pass
    value = str(icon or '').strip()
    return value or str(fallback or 'NONE')
_VIEW3D_TOOL_FALLBACK_ICONS = {'builtin.box_mask': 'MESH_GRID', 'builtin.lasso_mask': 'SELECT_LASSO', 'builtin.line_mask': 'IPO_LINEAR', 'builtin.polyline_mask': 'MOD_EDGESPLIT', 'builtin.box_hide': 'HIDE_ON', 'builtin.lasso_hide': 'SELECT_LASSO', 'builtin.line_hide': 'IPO_LINEAR', 'builtin.polyline_hide': 'MOD_EDGESPLIT', 'builtin.box_face_set': 'MESH_GRID', 'builtin.lasso_face_set': 'SELECT_LASSO', 'builtin.line_face_set': 'IPO_LINEAR', 'builtin.polyline_face_set': 'MOD_EDGESPLIT', 'builtin.box_trim': 'MESH_CUBE', 'builtin.lasso_trim': 'SELECT_LASSO', 'builtin.line_trim': 'IPO_LINEAR', 'builtin.polyline_trim': 'MOD_BOOLEAN', 'builtin.transform': 'ORIENTATION_GIMBAL', 'builtin.move': 'TRANSFORM_MOVE'}
addon_keymaps = []
_OWNED_KEYMAP_NAMES = {'Sculpt'}

def _addon_keymaps_collection():
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    keyconfigs = getattr(wm, 'keyconfigs', None) if wm is not None else None
    addon_cfg = getattr(keyconfigs, 'addon', None) if keyconfigs is not None else None
    return getattr(addon_cfg, 'keymaps', None) if addon_cfg is not None else None

def _remove_empty_keymap(km):
    """Compatibility no-op.

    Empty keymaps are not removed by name.  Only exact KeyMap identities
    acquired by this generation are released through the lifecycle journal.
    """
    return None


def _prune_empty_owned_keymaps():
    """Compatibility no-op; name-based keymap ownership is prohibited."""
    return None

class SCULPT_OT_Capture_Key(Operator):
    """捕获按键操作符 - 点击后等待用户按下快捷键"""
    bl_idname = 'sculpt_assistant.capture_key'
    bl_label = 'Capture Key'
    bl_description = 'Click then press any key combination to set shortcut'
    bl_options = {'UNDO'}
    target_property: StringProperty(default='pie_menu_key')
    captured_key: StringProperty(default='')
    captured_ctrl: BoolProperty(default=False)
    captured_shift: BoolProperty(default=False)
    captured_alt: BoolProperty(default=False)
    captured_oskey: BoolProperty(default=False)
    key_captured: BoolProperty(default=False)

    def modal(self, context, event):
        """模态循环 - 处理按键事件"""
        if event.type == 'ESC' and event.value == 'PRESS':
            self.report({'INFO'}, _('Key capture cancelled'))
            context.area.header_text_set(None)
            return {'CANCELLED'}
        if event.value == 'PRESS':
            if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_ALT', 'RIGHT_ALT', 'OSKEY'}:
                return {'RUNNING_MODAL'}
            self.captured_key = event.type
            self.captured_ctrl = event.ctrl
            self.captured_shift = event.shift
            self.captured_alt = event.alt
            self.captured_oskey = event.oskey
            self.key_captured = True
            key_display = self.format_key_display()
            self.report({'INFO'}, f"{_('Captured:')} {key_display}")
            context.area.header_text_set(None)
            self.update_preferences(context)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        """调用时进入模态状态"""
        prefs = _find_addon_preferences(context)
        if not prefs:
            self.report({'ERROR'}, _('Cannot access N-panel settings'))
            return {'CANCELLED'}
        context.area.header_text_set(_('Press any key combination (ESC to cancel)'))
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            try:
                context.area.header_text_set(None)
            except Exception:
                pass
            self.report({'INFO'}, _('Key capture cancelled'))
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def format_key_display(self):
        """格式化按键显示"""
        if not self.captured_key:
            return _('None')
        parts = []
        if self.captured_ctrl:
            parts.append('Ctrl')
        if self.captured_shift:
            parts.append('Shift')
        if self.captured_alt:
            parts.append('Alt')
        if self.captured_oskey:
            parts.append('Cmd/Win')
        parts.append(self.captured_key)
        return ' + '.join(parts)

    def update_preferences(self, context):
        """Update the N-panel preference store and refresh shortcut state."""
        prefs = _find_addon_preferences(context)
        if not prefs:
            return
        setattr(prefs, self.target_property, self.captured_key)
        setattr(prefs, 'pie_menu_ctrl', self.captured_ctrl)
        setattr(prefs, 'pie_menu_shift', self.captured_shift)
        setattr(prefs, 'pie_menu_alt', self.captured_alt)
        setattr(prefs, 'pie_menu_oskey', self.captured_oskey)
        update_keymap(prefs, context)

def get_keymap_item_properties(prefs):
    """从偏好设置获取快捷键属性，如果没有偏好设置则返回默认值"""
    if prefs:
        return {'idname': 'wm.call_menu_pie', 'properties': {'name': 'SCULPTMASKSUPPORT_MT_piemenu'}, 'type': prefs.pie_menu_key, 'value': 'PRESS', 'ctrl': prefs.pie_menu_ctrl, 'shift': prefs.pie_menu_shift, 'alt': prefs.pie_menu_alt, 'oskey': prefs.pie_menu_oskey}
    else:
        return {'idname': 'wm.call_menu_pie', 'properties': {'name': 'SCULPTMASKSUPPORT_MT_piemenu'}, 'type': 'ONE', 'value': 'PRESS', 'ctrl': False, 'shift': False, 'alt': False, 'oskey': False}

def unregister_keymap():
    """Automatic keymap cleanup is intentionally disabled."""
    global addon_keymaps
    addon_keymaps.clear()

def register_keymap():
    """Automatic keymap registration is intentionally disabled.

    Register this pie menu manually from Blender Preferences > Keymap using the
    IDs kept for manual shortcut setup in Blender Preferences > Keymap.
    """
    global addon_keymaps
    addon_keymaps.clear()

def update_keymap(self, context):
    """Keep preference values only; do not modify Blender keymaps automatically."""
    return None
_SAFE_VIEW3D_TOOL_OPERATOR_ID = 'mask_facesets_tools.set_view3d_tool'

def _view3d_override_context(context):
    if context is None:
        return None
    area = getattr(context, 'area', None)
    if getattr(area, 'type', None) == 'VIEW_3D':
        return None
    wm = getattr(context, 'window_manager', None)
    windows = getattr(wm, 'windows', None) if wm is not None else ()
    for window in windows or ():
        screen = getattr(window, 'screen', None)
        for candidate_area in getattr(screen, 'areas', ()) or ():
            if getattr(candidate_area, 'type', None) != 'VIEW_3D':
                continue
            region = None
            for candidate_region in getattr(candidate_area, 'regions', ()) or ():
                if getattr(candidate_region, 'type', None) == 'WINDOW':
                    region = candidate_region
                    break
            return {'window': window, 'screen': screen, 'area': candidate_area, 'region': region}
    return None

def _set_view3d_tool_by_id(context, tool_id: str) -> set[str]:
    tool_id = str(tool_id or '').strip()
    if not tool_id:
        return {'CANCELLED'}
    override = _view3d_override_context(context)
    if override is None:
        return bpy.ops.wm.tool_set_by_id(name=tool_id)
    override = {key: value for key, value in override.items() if value is not None}
    try:
        with context.temp_override(**override):
            return bpy.ops.wm.tool_set_by_id(name=tool_id)
    except Exception:
        return bpy.ops.wm.tool_set_by_id(name=tool_id)

def _draw_view3d_tool_button(layout, tool_id: str, icon_handle: str):
    icon_value = 0
    try:
        if ToolSelectPanelHelper is not None:
            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(icon_handle)
    except Exception:
        icon_value = 0
    kwargs = {'text': '', 'emboss': True}
    if icon_value:
        kwargs['icon_value'] = icon_value
    else:
        kwargs['icon'] = _icon(_VIEW3D_TOOL_FALLBACK_ICONS.get(str(tool_id or ''), 'TOOL_SETTINGS'))
    op = layout.operator(_SAFE_VIEW3D_TOOL_OPERATOR_ID, **kwargs)
    op.tool_id = str(tool_id or '')
    return op

def _active_view3d_tool(context):
    try:
        workspace = getattr(context, 'workspace', None)
        tools = getattr(workspace, 'tools', None) if workspace is not None else None
        mode = str(getattr(context, 'mode', '') or '').strip()
        if tools is None or not mode:
            return None
        return tools.from_space_view3d_mode(mode)
    except Exception:
        return None

class SCULPTMASKSUPPORT_OT_set_view3d_tool(Operator):
    bl_idname = _SAFE_VIEW3D_TOOL_OPERATOR_ID
    bl_label = 'Set View3D Tool'
    bl_description = 'Switch the active 3D View tool after confirming that the tool ID is not empty.'
    bl_options = set()
    _sms_no_undo = True
    _smart_sculpt_internal_operator = True
    tool_id: StringProperty(name='Tool ID', description='Internal Blender tool identifier to activate in the 3D View.', default='', options={'HIDDEN'})

    @classmethod
    def description(cls, _context, properties):
        tool_id = str(getattr(properties, 'tool_id', '') or '').strip()
        if tool_id:
            return _translation.ui_text(f"Switch the active 3D View tool to {tool_id}. The add-on checks that the tool ID is not empty before calling Blender's tool selector.", f'3Dビューのアクティブツールを {tool_id} に切り替えます。Blenderのツール選択処理を呼ぶ前に、ツールIDが空でないことを確認します。')
        return _translation.ui_text('Switch the active 3D View tool. Empty tool IDs are ignored so Blender is not asked to activate a blank tool.', '3Dビューのアクティブツールを切り替えます。空のツールIDは無視し、Blenderに空ツールを有効化させません。')

    def execute(self, context):
        tool_id = str(self.tool_id or '').strip()
        if not tool_id:
            self.report({'WARNING'}, _translation.ui_text('No View3D tool ID was specified.', '3DビューのツールIDが指定されていません。'))
            return {'CANCELLED'}
        try:
            result = _set_view3d_tool_by_id(context, tool_id)
        except Exception as exc:
            self.report({'WARNING'}, _translation.ui_text(f'Could not switch the 3D View tool: {_translation.exception_ui_text(exc)}', f'3Dビューのツールへ切り替えられませんでした: {_translation.exception_ui_text(exc)}'))
            return {'CANCELLED'}
        if result and 'FINISHED' in result:
            return {'FINISHED'}
        self.report({'WARNING'}, _translation.ui_text(f'View3D tool {tool_id} is unavailable in the current mode.', f'現在のモードでは3Dビューツール {tool_id} を使用できません。'))
        return {'CANCELLED'}

class SCULPTMASKSUPPORT_OT_selection_to_mask(Operator):
    """Create Blender's sculpt mask attribute from the mesh selection.

    Blender 5.1 no longer exposes ``mesh.selection_to_mask``.  Keeping this
    small compatibility operator inside the suite preserves the original
    Edit Selection button without depending on a removed built-in operator.
    """
    bl_idname = 'sculptmask.selection_to_mask'
    bl_label = 'Selection to Sculpt Mask'
    bl_description = 'Use selected mesh vertices as the sculpt mask. Selected vertices become fully masked and unselected vertices become unmasked'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, 'active_object', None)
        return bool(obj is not None and getattr(obj, 'type', '') == 'MESH')

    @_transactions.transactional_execute
    def execute(self, context):
        obj = getattr(context, 'active_object', None)
        mesh = getattr(obj, 'data', None) if obj is not None else None
        if mesh is None:
            self.report({'WARNING'}, _('An active mesh object is required.'))
            return {'CANCELLED'}
        try:
            if getattr(obj, 'mode', '') == 'EDIT':
                import bmesh
                bm = bmesh.from_edit_mesh(mesh)
                layer = bm.verts.layers.float.get('.sculpt_mask')
                if layer is None:
                    layer = bm.verts.layers.float.new('.sculpt_mask')
                for vert in bm.verts:
                    vert[layer] = 1.0 if vert.select else 0.0
                bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
            else:
                attribute = mesh.attributes.get('.sculpt_mask')
                if attribute is not None and (getattr(attribute, 'domain', '') != 'POINT' or getattr(attribute, 'data_type', '') != 'FLOAT'):
                    mesh.attributes.remove(attribute)
                    attribute = None
                if attribute is None:
                    attribute = mesh.attributes.new(name='.sculpt_mask', type='FLOAT', domain='POINT')
                for vertex, value in zip(mesh.vertices, attribute.data):
                    value.value = 1.0 if vertex.select else 0.0
                mesh.update()
        except Exception as exc:
            self.report({'WARNING'}, _('Could not create the sculpt mask: ') + _translation.exception_ui_text(exc))
            return {'CANCELLED'}
        try:
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}

_SCULPT_PIE_GROUPS = (
    ('MASK', 'Mask Tools', 'マスクツール', 'MOD_MASK'),
    ('FACE_SETS', 'Face Sets and Trim', 'フェイスセットとトリム', 'FACESEL'),
    ('FILTER', 'Filters and Extract', 'フィルターと抽出', 'MOD_SMOOTH'),
    ('TRANSFORM', 'Transform and Visibility', '変形と表示', 'ORIENTATION_GLOBAL'),
)


def _draw_pie_mask(col, ctx):
    tool = _active_view3d_tool(ctx)
    tool_id = str(getattr(tool, 'idname', '') or '')
    propsmesh = propscloth = propscolor = propsline = props1 = props2 = None
    row = col.row(align=True)
    row.scale_y = 1.5
    _draw_view3d_tool_button(row, 'builtin.line_project', 'ops.sculpt.line_project')
    _draw_view3d_tool_button(row, 'builtin.mask_by_color', 'ops.sculpt.mask_by_color')
    _draw_view3d_tool_button(row, 'builtin.mesh_filter', 'ops.sculpt.mesh_filter')
    _draw_view3d_tool_button(row, 'builtin.cloth_filter', 'ops.sculpt.cloth_filter')
    col.separator()
    if tool_id == 'builtin.mesh_filter':
        propsmesh = tool.operator_properties('sculpt.mesh_filter')
    if tool_id == 'builtin.cloth_filter':
        propscloth = tool.operator_properties('sculpt.cloth_filter')
    if tool_id == 'builtin.mask_by_color':
        propscolor = tool.operator_properties('sculpt.mask_by_color')
    if tool_id == 'builtin.line_project':
        propsline = tool.operator_properties('sculpt.project_line_gesture')
    try:
        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop(propsmesh, 'type', expand=False, text='')
        col.prop(propsmesh, 'strength')
        row = col.row(align=True)
        row.prop(propsmesh, 'deform_axis')
        row = col.row(align=True)
        row.prop(propsmesh, 'orientation', expand=True)
        if propsmesh.type == 'SURFACE_SMOOTH':
            col.prop(propsmesh, 'surface_smooth_shape_preservation', expand=False)
            col.prop(propsmesh, 'surface_smooth_current_vertex', expand=False)
        elif propsmesh.type == 'SHARPEN':
            col.prop(propsmesh, 'sharpen_smooth_ratio', expand=False)
            col.prop(propsmesh, 'sharpen_intensify_detail_strength', expand=False)
            col.prop(propsmesh, 'sharpen_curvature_smooth_iterations', expand=False)
    except:
        pass
    try:
        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop(propscloth, 'type', expand=False, text='')
        col.prop(propscloth, 'strength')
        row = col.row(align=True)
        row.prop(propscloth, 'force_axis')
        row = col.row(align=True)
        row.prop(propscloth, 'orientation', expand=True)
        col.prop(propscloth, 'cloth_mass')
        col.prop(propscloth, 'cloth_damping')
        row = col.row(align=True)
        row.prop(propscloth, 'use_face_sets', text=_('Face Set'))
        row.prop(propscloth, 'use_collisions', text=_('Collisions'))
    except:
        pass
    try:
        col.prop(propscolor, 'threshold')
        row = col.row(align=True)
        row.prop(propscolor, 'contiguous')
        row.prop(propscolor, 'invert')
        col.prop(propscolor, 'preserve_previous_mask')
    except:
        pass
    try:
        col.prop(propsline, 'use_limit_to_segment', expand=False)
    except:
        pass
    col.separator()
    col1 = col.box().column()
    col1.label(text=_('Mask:'), icon='NODE_SOCKET_MATERIAL')
    row = col1.row(align=True)
    row.scale_y = 1.5
    _draw_view3d_tool_button(row, 'builtin.box_mask', 'ops.sculpt.border_mask')
    _draw_view3d_tool_button(row, 'builtin.lasso_mask', 'ops.sculpt.lasso_mask')
    _draw_view3d_tool_button(row, 'builtin.line_mask', 'ops.sculpt.line_mask')
    _draw_view3d_tool_button(row, 'builtin.polyline_mask', 'ops.sculpt.polyline_mask')
    try:
        overlay = getattr(getattr(ctx, 'space_data', None), 'overlay', None)
        if overlay is not None and hasattr(overlay, 'sculpt_mode_mask_opacity'):
            col1.prop(overlay, 'sculpt_mode_mask_opacity', text=_('Show Mask'))
    except Exception:
        pass
    if tool_id == 'builtin.box_mask':
        props1 = tool.operator_properties('paint.mask_box_gesture')
    if tool_id == 'builtin.lasso_mask':
        props1 = tool.operator_properties('paint.mask_lasso_gesture')
    if tool_id == 'builtin.line_mask':
        props1 = tool.operator_properties('paint.mask_line_gesture')
    if tool_id == 'builtin.polyline_mask':
        props1 = tool.operator_properties('paint.mask_polyline_gesture')
    try:
        row = col1.row(align=True)
        row.scale_y = 1.3
        row.prop(props1, 'use_front_faces_only', text=_('Front Faces Only'))
        if tool_id == 'builtin.lasso_mask':
            col1.prop(props1, 'use_smooth_stroke', text=_('Stabilize Stroke'))
            if props1.use_smooth_stroke == True:
                col1.prop(props1, 'smooth_stroke_radius', text=_('Radius'), slider=True)
                col1.prop(props1, 'smooth_stroke_factor', text=_('Factor'), slider=True)
        if tool_id == 'builtin.line_mask':
            col1.prop(props1, 'use_limit_to_segment', expand=False)
    except:
        pass
    col.separator()
    col1 = col.box().column()
    col1.label(text=_('Create Mask:'), icon='NODE_SOCKET_MATERIAL')
    row = col1.row(align=True)
    row.scale_y = 1.2
    row.operator('sculpt.mask_from_boundary', text=_('Boundary'), icon=_icon('BORDERMOVE')).boundary_mode = 'MESH'
    row.operator('sculpt.mask_from_boundary', text=_('FaceSet Bonundary'), icon=_icon('MESH_GRID')).boundary_mode = 'FACE_SETS'
    row = col1.row(align=True)
    row.scale_y = 1.2
    row.operator('sculptmask.selection_to_mask', text=_('Edit Sel'), icon=_icon('EDITMODE_HLT'))
    row.operator('sculpt.mask_from_cavity', text=_('Cavity'), icon=_icon('BRUSH_DATA')).settings_source = 'OPERATOR'
    row.operator('sculpt.mask_by_color', text=_('Color'), icon=_icon('COLOR'))
    col2 = col.box().column()
    row = col2.row(align=True)
    row.scale_y = 1.2
    row.operator('paint.mask_flood_fill', text=_('Invert'), icon='IMAGE_ALPHA').mode = 'INVERT'
    clear_mask = row.operator('paint.mask_flood_fill', text=_('Clear'), icon='CANCEL')
    clear_mask.mode = 'VALUE'
    clear_mask.value = 0.0
    row = col2.row(align=True)
    row.scale_y = 1.2
    row.operator('sculpt.mask_filter', text=_('Smooth'), icon=_icon('MOD_SMOOTH')).filter_type = 'SMOOTH'
    row.operator('sculpt.mask_filter', text=_('Sharpen'), icon=_icon('BRUSH_DATA')).filter_type = 'SHARPEN'
    row = col2.row(align=True)
    row.scale_y = 1.2
    op = row.operator('sculpt.mask_filter', text=_('Contrast+'), icon=_icon('ADD'))
    op.filter_type = 'CONTRAST_INCREASE'
    op.auto_iteration_count = False
    op.iterations = 1
    op = row.operator('sculpt.mask_filter', text=_('Contrast-'), icon=_icon('REMOVE'))
    op.filter_type = 'CONTRAST_DECREASE'
    op.auto_iteration_count = False
    op.iterations = 1
    col2.separator()
    row = col2.row(align=True)
    row.scale_y = 1.2
    row.operator('sculpt.mask_filter', text=_('Grow'), icon=_icon('ADD')).filter_type = 'GROW'
    row.operator('sculpt.mask_filter', text=_('Shrink'), icon=_icon('REMOVE')).filter_type = 'SHRINK'
    row = col2.row(align=True)
    row.scale_y = 1.2
    op = row.operator('sculpt.expand', text=_('By Topo'), icon=_icon('MESH_GRID'))
    op.target = 'MASK'
    op.falloff_type = 'GEODESIC'
    op.invert = False
    op.use_mask_preserve = True
    op.use_auto_mask = False
    op = row.operator('sculpt.expand', text=_('By Normals'), icon=_icon('NORMALS_FACE'))
    op.target = 'MASK'
    op.falloff_type = 'NORMALS'
    op.invert = False
    op.use_mask_preserve = True
    col.separator()
    col1 = col.box().column()
    col1.label(text=_('Mask Hide Tools:'), icon='NODE_SOCKET_MATERIAL')
    row = col1.row(align=True)
    row.scale_y = 1.5
    _draw_view3d_tool_button(row, 'builtin.box_hide', 'ops.sculpt.border_hide')
    _draw_view3d_tool_button(row, 'builtin.lasso_hide', 'ops.sculpt.lasso_hide')
    _draw_view3d_tool_button(row, 'builtin.line_hide', 'ops.sculpt.line_hide')
    _draw_view3d_tool_button(row, 'builtin.polyline_hide', 'ops.sculpt.polyline_hide')
    if tool_id == 'builtin.box_hide':
        props2 = tool.operator_properties('paint.hide_show')
    if tool_id == 'builtin.lasso_hide':
        props2 = tool.operator_properties('paint.hide_show_lasso_gesture')
    if tool_id == 'builtin.polyline_hide':
        props2 = tool.operator_properties('paint.hide_show_polyline_gesture')
    try:
        row = col1.row(align=True)
        row.scale_y = 1.5
        row.prop(props2, 'area', expand=False, text='')
        if tool_id == 'builtin.lasso_hide':
            col1.prop(props2, 'use_smooth_stroke')
            if props2.use_smooth_stroke == True:
                col1.prop(props2, 'smooth_stroke_radius', text=_('Radius'), slider=True)
                col1.prop(props2, 'smooth_stroke_factor', text=_('Factor'), slider=True)
    except:
        pass
    if tool_id == 'builtin.line_hide':
        props2 = tool.operator_properties('paint.hide_show_line_gesture')
        try:
            col1.prop(props2, 'use_limit_to_segment')
        except:
            pass


def _draw_pie_face_sets(col, ctx):
    tool = _active_view3d_tool(ctx)
    tool_id = str(getattr(tool, 'idname', '') or '')
    col1 = col.box().column()
    col1.label(text=_('Face Sets:'), icon='NODE_SOCKET_GEOMETRY')
    row = col1.row(align=True)
    row.scale_y = 1.5
    _draw_view3d_tool_button(row, 'builtin_brush.draw_face_sets', 'brush.sculpt.draw_face_sets')
    _draw_view3d_tool_button(row, 'builtin.face_set_edit', 'ops.sculpt.face_set_edit')
    row = col1.row(align=True)
    row.scale_y = 1.3
    row.operator('paint.hide_show_all', text=_('All'), icon='HIDE_OFF').action = 'SHOW'
    row.operator('paint.visibility_invert', text=_('Vis Invert'), icon=_icon('HIDE_OFF'))
    row.operator('sculpt.face_set_change_visibility', text=_('Change Vis'), icon=_icon('HIDE_ON')).mode = 'HIDE_ACTIVE'
    if tool_id == 'builtin.face_set_edit':
        props = tool.operator_properties('sculpt.face_set_edit')
        try:
            col1.prop(props, 'mode', expand=False, text='')
            col1.prop(props, 'modify_hidden')
        except:
            pass
    col.separator()
    row = col.row(align=True)
    row.scale_y = 1.5
    _draw_view3d_tool_button(row, 'builtin.box_face_set', 'ops.sculpt.border_face_set')
    _draw_view3d_tool_button(row, 'builtin.lasso_face_set', 'ops.sculpt.lasso_face_set')
    _draw_view3d_tool_button(row, 'builtin.line_face_set', 'ops.sculpt.line_face_set')
    _draw_view3d_tool_button(row, 'builtin.polyline_face_set', 'ops.sculpt.polyline_face_set')
    try:
        overlay = getattr(getattr(ctx, 'space_data', None), 'overlay', None)
        if overlay is not None and hasattr(overlay, 'sculpt_mode_face_sets_opacity'):
            col.prop(overlay, 'sculpt_mode_face_sets_opacity', text=_('Show Face Sets'))
    except Exception:
        pass
    if tool_id == 'builtin.box_face_set':
        props = tool.operator_properties('sculpt.face_set_box_gesture')
    if tool_id == 'builtin.lasso_face_set':
        props = tool.operator_properties('sculpt.face_set_lasso_gesture')
    if tool_id == 'builtin.line_face_set':
        props = tool.operator_properties('sculpt.face_set_line_gesture')
    if tool_id == 'builtin.polyline_face_set':
        props = tool.operator_properties('sculpt.face_set_polyline_gesture')
    try:
        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop(props, 'use_front_faces_only', text=_('Front Faces Only'))
        if tool_id == 'builtin.lasso_face_set':
            col.prop(props, 'use_smooth_stroke', text=_('Stabilize Stroke'))
            if props.use_smooth_stroke == True:
                col.prop(props, 'smooth_stroke_radius', text=_('Radius'), slider=True)
                col.prop(props, 'smooth_stroke_factor', text=_('Factor'), slider=True)
        if tool_id == 'builtin.line_face_set':
            col.prop(props, 'use_limit_to_segment', expand=False)
    except:
        pass
    col.separator()
    col2 = col.box().column()
    col2.label(text=_('Create FaceSet：'), icon='NODE_SOCKET_GEOMETRY')
    row = col2.row(align=True)
    row.scale_y = 1.3
    row.operator('sculpt.face_sets_create', text=_('Visible'), icon=_icon('HIDE_OFF')).mode = 'VISIBLE'
    row.operator('sculpt.face_sets_init', text=_('Loose'), icon=_icon('MESH_GRID')).mode = 'LOOSE_PARTS'
    row = col2.row(align=True)
    row.scale_y = 1.3
    row.operator('sculpt.face_sets_create', text=_('Mask'), icon=_icon('IMAGE_ALPHA')).mode = 'MASKED'
    row.operator('sculpt.face_sets_create', text=_('Edit Sel'), icon=_icon('EDITMODE_HLT')).mode = 'SELECTION'
    row.operator('sculpt.face_sets_randomize_colors', text=_('Random col'), icon=_icon('COLOR'))
    row = col2.row(align=True)
    row.scale_y = 1.3
    row.operator('sculpt.face_sets_init', text=_('FaceBound'), icon=_icon('BORDERMOVE')).mode = 'FACE_SET_BOUNDARIES'
    row.operator('sculpt.face_sets_init', text=_('Seam'), icon=_icon('GROUP_UVS')).mode = 'UV_SEAMS'
    row.operator('sculpt.face_sets_init', text=_('Normal'), icon=_icon('NORMALS_FACE')).mode = 'NORMALS'
    row = col2.row(align=True)
    row.scale_y = 1.3
    row.operator('sculpt.face_sets_init', text=_('Bevel Weight'), icon=_icon('MOD_BEVEL')).mode = 'BEVEL_WEIGHT'
    row.operator('sculpt.face_sets_init', text=_('Crease'), icon=_icon('MOD_EDGESPLIT')).mode = 'CREASES'
    row.operator('sculpt.face_sets_init', text=_('Sharp'), icon=_icon('BRUSH_DATA')).mode = 'SHARP_EDGES'
    col2.separator()
    row = col2.row(align=True)
    row.scale_y = 1.2
    row.operator('sculpt.face_set_edit', text=_('Fair Positions'), icon=_icon('MOD_SMOOTH')).mode = 'FAIR_POSITIONS'
    row.operator('sculpt.face_set_edit', text=_('Fair Tangency'), icon=_icon('MOD_SMOOTH')).mode = 'FAIR_TANGENCY'
    row = col2.row(align=True)
    row.scale_y = 1.2
    row.operator('sculpt.face_set_edit', text=_('Grow'), icon=_icon('ADD')).mode = 'GROW'
    row.operator('sculpt.face_set_edit', text=_('Shrink'), icon=_icon('REMOVE')).mode = 'SHRINK'
    row = col2.row(align=True)
    row.scale_y = 1.2
    op = row.operator('sculpt.expand', text=_('By Topo'), icon=_icon('MESH_GRID'))
    op.target = 'FACE_SETS'
    op.falloff_type = 'GEODESIC'
    op = row.operator('sculpt.expand', text=_('By Normals'), icon=_icon('NORMALS_FACE'))
    op.target = 'FACE_SETS'
    op.falloff_type = 'NORMALS'
    row = col2.row(align=True)
    row.scale_y = 1.3
    row.operator('sculpt.face_set_extract', text=_('Select Copy to new objects'), icon=_icon('MOD_SOLIDIFY'))
    col.separator()
    col1 = col.box().column()
    col1.label(text=_('Trim:'), icon='NODE_SOCKET_GEOMETRY')
    row = col1.row(align=True)
    row.scale_y = 1.3
    _draw_view3d_tool_button(row, 'builtin.box_trim', 'ops.sculpt.box_trim')
    _draw_view3d_tool_button(row, 'builtin.lasso_trim', 'ops.sculpt.lasso_trim')
    _draw_view3d_tool_button(row, 'builtin.line_trim', 'ops.sculpt.line_trim')
    _draw_view3d_tool_button(row, 'builtin.polyline_trim', 'ops.sculpt.polyline_trim')
    col.separator()
    if tool_id == 'builtin.box_trim':
        props = tool.operator_properties('sculpt.trim_box_gesture')
    if tool_id == 'builtin.polyline_trim':
        props = tool.operator_properties('sculpt.trim_polyline_gesture')
    if tool_id == 'builtin.lasso_trim':
        props = tool.operator_properties('sculpt.trim_lasso_gesture')
    if tool_id == 'builtin.line_trim':
        props = tool.operator_properties('sculpt.trim_line_gesture')
    try:
        row = col1.row(align=True)
        row.scale_y = 1.3
        row.prop(props, 'trim_solver', expand=False, text='')
        if tool_id == 'builtin.line_trim':
            row.prop(props, 'use_limit_to_segment', expand=False)
        else:
            row.prop(props, 'trim_mode', expand=False, text='')
        row = col1.row(align=True)
        row.scale_y = 1.3
        row.prop(props, 'trim_orientation', expand=False, text='')
        row.prop(props, 'trim_extrude_mode', expand=False, text='')
        col.prop(props, 'use_cursor_depth', expand=False)
        if tool_id == 'builtin.lasso_trim':
            props = tool.operator_properties('sculpt.trim_lasso_gesture')
            col.prop(props, 'use_smooth_stroke', text=_('Stabilize Stroke'))
            if props.use_smooth_stroke == True:
                col.prop(props, 'smooth_stroke_radius', text=_('Radius'), slider=True)
                col.prop(props, 'smooth_stroke_factor', text=_('Factor'), slider=True)
    except:
        pass
    col.separator()
    col1 = col.box().column()
    col1.label(text=_('Add Mesh:'), icon='NODE_SOCKET_GEOMETRY')
    row = col1.row(align=True)
    row.scale_y = 1.3
    row.operator('sculpt.trim_box_gesture', text=_('Box'), icon=_icon('MESH_CUBE')).trim_mode = 'JOIN'
    row.operator('sculpt.trim_lasso_gesture', text=_('Lasso'), icon=_icon('SELECT_LASSO')).trim_mode = 'JOIN'
    row.operator('sculpt.trim_polyline_gesture', text=_('Polyline'), icon=_icon('MOD_EDGESPLIT')).trim_mode = 'JOIN'


def _draw_pie_filter(col, ctx):
    col2 = col.box().column()
    col2.label(text=_('Mesh Filter:'), icon='NODE_SOCKET_OBJECT')
    row = col2.row(align=True)
    op = row.operator('sculpt.mesh_filter', text=_('Smooth'), icon=_icon('MOD_SMOOTH'))
    op.type = 'SMOOTH'
    op.strength = 1
    op = row.operator('sculpt.mesh_filter', text=_('Sharpen'), icon=_icon('BRUSH_DATA'))
    op.type = 'SHARPEN'
    op.strength = 0.1
    row = col2.row(align=True)
    op = row.operator('sculpt.mesh_filter', text=_('Surface Smooth'), icon=_icon('MOD_SMOOTH'))
    op.type = 'SURFACE_SMOOTH'
    op.strength = 1
    row.operator('sculpt.mesh_filter', text=_('Inflate'), icon=_icon('MOD_DISPLACE')).type = 'INFLATE'
    row = col2.row(align=True)
    op = row.operator('sculpt.mesh_filter', text=_('Relax'), icon=_icon('MOD_SMOOTH'))
    op.type = 'RELAX'
    op.strength = 1
    op = row.operator('sculpt.mesh_filter', text=_('Relax FaceSet'), icon=_icon('MESH_GRID'))
    op.type = 'RELAX_FACE_SETS'
    op.strength = 1
    row = col2.row(align=True)
    op = row.operator('sculpt.mesh_filter', text=_('Enhance Details'), icon=_icon('BRUSH_DATA'))
    op.type = 'ENHANCE_DETAILS'
    op.strength = 1
    col2.operator('sculpt.mesh_filter', text=_('Erase Displacement'), icon=_icon('X')).type = 'ERASE_DISPLACEMENT'
    col2 = col.box().column()
    col2.label(text=_('Mask Extract:'), icon='NODE_SOCKET_OBJECT')
    col2.scale_y = 1.2
    row = col2.row(align=True)
    row.operator('sculpt.paint_mask_extract', text=_('Extract'), icon='SNAP_FACE')
    props = row.operator('sculpt.paint_mask_slice', text=_('Slice'), icon=_icon('MESH_CUBE'))
    props.fill_holes = False
    props.new_object = False
    row = col2.row(align=True)
    props = row.operator('sculpt.paint_mask_slice', text=_('Fill Holes'), icon=_icon('MOD_SOLIDIFY'))
    props.new_object = False
    props = row.operator('sculpt.paint_mask_slice', text=_('to New Obj'), icon=_icon('DUPLICATE'))
    props.fill_holes = False
    props.new_object = True


def _draw_pie_transform(col, ctx):
    scene = ctx.scene
    tool = _active_view3d_tool(ctx)
    tool_id = str(getattr(tool, 'idname', '') or '')
    colx = col.box().column()
    row = colx.row(align=True)
    colx.scale_y = 1.3
    _draw_view3d_tool_button(row, 'builtin.transform', 'ops.transform.transform')
    _draw_view3d_tool_button(row, 'builtin.move', 'ops.transform.translate')
    _draw_view3d_tool_button(row, 'builtin.rotate', 'ops.transform.rotate')
    _draw_view3d_tool_button(row, 'builtin.scale', 'ops.transform.resize')
    row = colx.row(align=True)
    try:
        if tool_id in {'builtin.transform', 'builtin.move', 'builtin.rotate', 'builtin.scale'}:
            sculpt_ts = getattr(getattr(scene, 'tool_settings', None), 'sculpt', None)
            if sculpt_ts is not None and hasattr(sculpt_ts, 'transform_mode'):
                row.prop(sculpt_ts, 'transform_mode', text='')
        slots = getattr(scene, 'transform_orientation_slots', None)
        if slots is not None:
            if tool_id in {'builtin.transform', 'builtin.move'} and len(slots) > 1:
                row.prop(slots[1], 'type', text='')
            if tool_id == 'builtin.rotate' and len(slots) > 2:
                row.prop(slots[2], 'type', text='')
            if tool_id == 'builtin.scale' and len(slots) > 3:
                row.prop(slots[3], 'type', text='')
    except Exception:
        pass
    row = colx.row(align=True)
    row.operator('sculpt.set_pivot_position', text=_('Act'), icon=_icon('PIVOT_CURSOR')).mode = 'ACTIVE'
    row.operator('sculpt.set_pivot_position', text=_('Sur'), icon=_icon('SNAP_FACE')).mode = 'SURFACE'
    row.operator('sculpt.set_pivot_position', text=_('Origin'), icon=_icon('EMPTY_AXIS')).mode = 'ORIGIN'
    row.operator('sculpt.set_pivot_position', text=_('Border'), icon=_icon('BORDERMOVE')).mode = 'BORDER'
    row.operator('sculpt.set_pivot_position', text=_('Unmasked'), icon=_icon('IMAGE_ALPHA')).mode = 'UNMASKED'
    col2 = col.box().column()
    row = col2.row(align=True)
    row.scale_y = 1.2
    row.operator('paint.hide_show_all', text=_('All'), icon='HIDE_OFF').action = 'SHOW'
    row.operator('paint.hide_show_masked', text=_('Hide'), icon=_icon('HIDE_ON')).action = 'HIDE'
    row.operator('paint.visibility_invert', text=_('VisInvert'), icon=_icon('HIDE_OFF'))
    row = col2.row(align=True)
    row.scale_y = 1.3
    row.operator('paint.visibility_filter', text=_('Grow'), icon=_icon('ADD')).action = 'GROW'
    row.operator('paint.visibility_filter', text=_('Shrink'), icon=_icon('REMOVE')).action = 'SHRINK'



_SCULPT_PIE_DRAW = {
    'MASK': _draw_pie_mask,
    'FACE_SETS': _draw_pie_face_sets,
    'FILTER': _draw_pie_filter,
    'TRANSFORM': _draw_pie_transform,
}


class SCULPTMASKSUPPORT_OT_open_pie_group(Operator):
    bl_idname = 'mask_facesets_tools.open_pie_group'
    bl_label = 'Sculpt Mask & Face Sets'
    bl_options = {'INTERNAL'}

    group: StringProperty(default='MASK', options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and context.mode == 'SCULPT'

    def invoke(self, context, _event):
        if self.group not in _SCULPT_PIE_DRAW:
            return {'CANCELLED'}
        return context.window_manager.invoke_popup(self, width=650)

    def draw(self, context):
        self.layout.operator_context = 'INVOKE_DEFAULT'
        draw = _SCULPT_PIE_DRAW.get(self.group)
        if draw is not None and self.poll(context):
            draw(self.layout.column(align=True), context)

    def execute(self, _context):
        return {'FINISHED'}


class SCULPTMASKSUPPORT_MT_piemenu(Menu):
    bl_label = 'Sculpt Mask & Face Sets'
    bl_idname = 'SCULPTMASKSUPPORT_MT_piemenu'

    def draw(self, context):
        pie = self.layout.menu_pie()
        if not SCULPTMASKSUPPORT_OT_open_pie_group.poll(context):
            pie.label(text=_translation.ui_text('Open this menu in Sculpt Mode.', 'スカルプトモードでこのメニューを開いてください。'), icon=_icon('ERROR'))
            return
        pie.operator_context = 'INVOKE_DEFAULT'
        for group, english, japanese, icon in _SCULPT_PIE_GROUPS:
            op = pie.operator(SCULPTMASKSUPPORT_OT_open_pie_group.bl_idname,
                              text=_translation.ui_text(english, japanese), icon=_icon(icon))
            op.group = group


class My_AddonPreferences(PropertyGroup):
    bl_idname = __package__
    language: bpy.props.EnumProperty(name='Language', description='Choose whether this tool follows Blender, uses English, or uses Japanese.', items=[('AUTO', 'Auto', "Follow Blender's interface language automatically."), ('en_US', 'English', 'Show this tool in English.'), ('ja_JP', 'Japanese', 'Show this tool in Japanese.')], default='AUTO', update=lambda self, context: update_language(self.language))
    pie_menu_key: StringProperty(name='Pie Menu Key', description='Choose which key opens the sculpt pie menu. Use the capture button below if you want to read the current shortcut instead of typing the key code yourself.', default='ONE', update=update_keymap)
    pie_menu_ctrl: BoolProperty(name='Ctrl', description='Require Ctrl key', default=False, update=update_keymap)
    pie_menu_shift: BoolProperty(name='Shift', description='Require Shift key', default=False, update=update_keymap)
    pie_menu_alt: BoolProperty(name='Alt', description='Require Alt key', default=False, update=update_keymap)
    pie_menu_oskey: BoolProperty(name='Cmd/Win', description='Require Cmd (Mac) or Win key', default=False, update=update_keymap)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text=_('Select Language:'))
        row = box.row(align=True)
        row.prop(self, 'language', expand=True)
        row = box.row(align=True)
        row.label(text=_('Current language: ') + get_current_language_name())
        box = layout.box()
        box.label(text=_('Customize Pie Menu Shortcut:'))
        row = box.row(align=True)
        row.scale_y = 1.5
        current = self.get_current_key_display()
        row.label(text=_('Current Key:'), icon='KEYINGSET')
        row.label(text=current)
        capture_op = row.operator('sculpt_assistant.capture_key', text=_('Click set new shortcut'), icon='ADD')
        capture_op.target_property = 'pie_menu_key'

    def get_current_key_display(self):
        """获取当前快捷键的显示文本"""
        parts = []
        if self.pie_menu_ctrl:
            parts.append('Ctrl')
        if self.pie_menu_shift:
            parts.append('Shift')
        if self.pie_menu_alt:
            parts.append('Alt')
        if self.pie_menu_oskey:
            parts.append('Cmd/Win')
        parts.append(self.pie_menu_key)
        return ' + '.join(parts)

@persistent
def load_post_handler(dummy=None, *args, **kwargs):
    """Blender完全启动后加载保存的语言设置"""
    try:
        addon_prefs = _find_addon_preferences()
        if addon_prefs is not None and hasattr(addon_prefs, 'language'):
            saved_language = addon_prefs.language
            update_language(saved_language)
    except Exception:
        update_language('AUTO')
classes = [SCULPTMASKSUPPORT_OT_set_view3d_tool, SCULPTMASKSUPPORT_OT_selection_to_mask, SCULPTMASKSUPPORT_OT_open_pie_group, SCULPTMASKSUPPORT_MT_piemenu, SCULPT_OT_Capture_Key]

def _safe_register_class(cls):
    if _rna_safety is not None:
        _rna_safety.register_class(cls)
        return
    try:
        return bool(_rna_safety.register_class(cls)) if _rna_safety is not None else False
    except Exception:
        return False

def _safe_unregister_class(cls):
    if _rna_safety is not None:
        _rna_safety.unregister_class(cls)
        return
    try:
        if _rna_safety is not None:
            _rna_safety.unregister_class(cls)
    except Exception:
        pass

_REGISTERED = False
_REGISTERED_CLASSES = []

def register():
    global _REGISTERED
    if _REGISTERED:
        return
    registered_now=[]
    translation_registered=False
    try:
        try:
            _translation.normalize_class_texts(classes)
        except Exception:
            pass
        for cls in classes:
            _safe_register_class(cls)
            registered_now.append(cls)
        register_keymap()
        if _lifecycle is not None:
            _lifecycle.register_translation(__name__, translation.get_all_translations())
            translation_registered=True
        try:
            addon_prefs = _find_addon_preferences()
            if addon_prefs is not None and hasattr(addon_prefs, 'language'):
                update_language(addon_prefs.language)
        except Exception:
            pass
        _REGISTERED_CLASSES[:] = registered_now
        _REGISTERED=True
    except Exception:
        unregister_keymap()
        if translation_registered and _lifecycle is not None:
            try: _lifecycle.unregister_translation(__name__)
            except Exception: pass
        for cls in reversed(registered_now):
            try: _safe_unregister_class(cls)
            except Exception: pass
        _REGISTERED_CLASSES.clear()
        _REGISTERED=False
        raise

def rollback_registration():
    global _REGISTERED
    unregister_keymap()
    if _lifecycle is not None:
        try: _lifecycle.unregister_translation(__name__)
        except Exception: pass
    for cls in reversed(tuple(_REGISTERED_CLASSES)):
        try: _safe_unregister_class(cls)
        except Exception: pass
    _REGISTERED_CLASSES.clear()
    _REGISTERED=False

def unregister():
    rollback_registration()
if __name__ == '__main__':
    register()
