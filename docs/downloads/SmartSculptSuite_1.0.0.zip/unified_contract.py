CONTRACT_VERSION = 1
EXTENSION_ID = "smart_sculpt_suite"
CONFIG_FOLDER = "Smart_Sculpt_Suite"
CONFIG_FILE = "Smart_Sculpt_Suite.json"
STATE_SAVE_PATH = "scene.core.always_on_npanel_autosave_restore"
SECTION_OPEN_PATH = "scene.core.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "scene.core.always_on_navigation_border_overlay",
    "scene.strict_edit_mode_sculpt_settings.use_mask_for_mesh_editing",
    "scene.strict_edit_mode_sculpt_settings.mask_overlay_enabled",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PERSISTENCE_ROOTS = (
    "scene.core",
    "scene.strict_edit_mode_sculpt_settings",
)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.core.name",
    "scene.core.tool_pipe_slot_1_tool",
    "scene.core.tool_pipe_slot_2_tool",
    "scene.core.tool_pipe_slot_3_tool",
    "scene.strict_edit_mode_sculpt_settings.name",
    "scene.strict_edit_mode_sculpt_settings.brush_settings_json",
    "scene.strict_edit_mode_sculpt_settings.brush_settings_active_key",
    "window_manager.sculptnav.name",
    # Native compatibility mirror rebuilt from the authoritative, visible
    # scene.core.navigation_enabled N-panel setting.
    "window_manager.sculptnav.enabled",
    # Stored as stable datablock names in navigation_settings rather than raw
    # Collection RNA pointers/indices.
    "scene.sculptnav_ignored_collections",
    "scene.sculptnav_ignored_collections_index",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    # SculptNavigation registers these only when its integrated tool is loaded.
    "window_manager.sculptnav",
    # Stored as stable Collection datablock names; collection contents remain
    # authoritative in the current .blend and are never copied to user JSON.
    "scene.sculptnav_ignored_collections",
    "scene.sculptnav_ignored_collections_index",
)
ROOT_PANEL_IDS = (
    "SSS_PT_main",
)
