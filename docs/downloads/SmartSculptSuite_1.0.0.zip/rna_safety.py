# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Exact-identity RNA helpers backed by the active lifecycle journal."""
from __future__ import annotations
from typing import Any, Iterable
import bpy
from . import _sss_lifecycle as _lifecycle

def is_blender_exit_unregister_in_progress() -> bool: return False
def is_property_group_class(cls: object) -> bool:
    try: return isinstance(cls, type) and issubclass(cls, bpy.types.PropertyGroup)
    except Exception: return False
def class_name(cls: object) -> str: return str(getattr(cls, "__name__", "") or "")
def existing_registered_class(cls: object) -> type | None:
    if not isinstance(cls, type):
        return None
    return cls if _lifecycle.class_registration_identity(cls)[0] else None
def class_is_registered(cls: object) -> bool: return existing_registered_class(cls) is cls
def bind_module_class_reference(original: type, replacement: type) -> type:
    del replacement; return original
def resolve_property_group_class(cls: type) -> type: return cls
def registered_property_group_type(cls: type) -> type: return cls
def rebind_deferred_property_group_types(cls: type) -> None: del cls
def register_class(cls: type) -> bool: return _lifecycle.register_class(cls)
def unregister_class(cls: type) -> bool: return _lifecycle.unregister_class(cls)
def unregister_classes(classes: Iterable[type] | None) -> None:
    for cls in reversed(tuple(classes or ())): _lifecycle.unregister_class(cls)
def register_property(owner: Any, name: str, definition: Any) -> bool: return _lifecycle.set_rna_property(owner, name, definition)
def unregister_property(owner: Any, name: str) -> bool: return _lifecycle.remove_rna_property(owner, name)
def set_rna_property(owner: Any, name: str, definition: Any) -> bool: return _lifecycle.set_rna_property(owner, name, definition)
def remove_rna_property(owner: Any, name: str) -> bool: return _lifecycle.remove_rna_property(owner, name)
