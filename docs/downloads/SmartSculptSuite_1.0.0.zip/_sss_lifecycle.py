# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Exact generation-owned Blender resource lifecycle for Smart Sculpt Suite.

Every native resource is journalled immediately after acquisition.  Rollback
uses the captured object and native remover only; it never searches
``bpy.types`` or ``sys.modules`` and never patches a process-global API.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import functools
import threading
import uuid
from collections import deque
from typing import Any, Callable

OWNER_UUID = "b54222fc-29cf-5f8c-b745-4d6822831be3"
REVISION = "1.9.55"
_NAMESPACE_KEY = "JELARARAGI_SMART_SCULPT_LIFECYCLE"
_LEGACY_NAMESPACE_KEYS = (
    "JELARARAGI_SMART_SCULPT_LIFECYCLE_V1944",
    "JELARARAGI_SMART_SCULPT_LIFECYCLE_V1943",
    "JELARARAGI_SMART_SCULPT_LIFECYCLE_V1937",
)
_LOCK = threading.RLock()
_CURRENT: "RegistrationJournal | Any | None" = None
_FALLBACK: dict[str, Any] = {}
_ORPHANED_JOURNALS: deque[Any] = deque(maxlen=8)


def _namespace() -> dict[str, Any]:
    try:
        import bpy
        value = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    return _FALLBACK


def _identity(value: Any) -> int:
    return id(value) if value is not None else 0


def _pointer_identity(value: Any) -> int:
    if value is None:
        return 0
    try:
        as_pointer = getattr(value, "as_pointer", None)
        if callable(as_pointer):
            pointer = int(as_pointer())
            if pointer:
                return pointer
    except Exception:
        pass
    return id(value)


def _direct_class_rna(cls: type) -> Any:
    try:
        return vars(cls).get("bl_rna")
    except Exception:
        return None


def class_registration_identity(cls: type) -> tuple[bool, int, int]:
    """Return exact class-local RNA identity without inherited/base state.

    Blender RNA base classes can expose registration-related attributes through
    their metaclass.  Reading them with ``getattr`` can therefore classify a new
    PropertyGroup subclass as already registered.  Only values stored directly
    on this exact Python class object are authoritative here.
    """
    direct_rna = _direct_class_rna(cls)
    try:
        registered_flag = bool(vars(cls).get("is_registered", False))
    except Exception:
        registered_flag = False
    return bool(direct_rna is not None or registered_flag), _pointer_identity(direct_rna), id(cls)


def _property_identity(owner: Any, name: str) -> tuple[int, int]:
    descriptor = 0
    rna = 0
    try:
        descriptor = _identity(vars(owner).get(name))
    except Exception:
        try:
            descriptor = _identity(getattr(owner, name, None))
        except Exception:
            pass
    try:
        properties = getattr(getattr(owner, "bl_rna", None), "properties", None)
        prop = properties.get(name) if hasattr(properties, "get") else properties[name]
        rna = _pointer_identity(prop)
    except Exception:
        pass
    return descriptor, rna


def _property_exists(owner: Any, name: str) -> bool:
    identity = _property_identity(owner, name)
    if identity != (0, 0):
        return True
    try:
        return name in vars(owner)
    except Exception:
        return False


def _already_unregistered_error(exc: BaseException) -> bool:
    text = str(exc or "").casefold()
    return any(token in text for token in (
        "not registered", "already unregistered", "missing bl_rna",
        "does not contain", "is not registered",
    ))


@dataclass(slots=True)
class ResourceRecord:
    sequence: int
    kind: str
    value: Any
    remover: Callable[[Any], None]
    owner_uuid: str
    generation_uuid: str
    identity: int
    callback_identity: int = 0
    space_type: str = ""
    region_type: str = ""
    native_remover: Any = None
    metadata: dict[str, Any] = field(default_factory=dict)
    released: bool = False
    release_error: str = ""

    def view(self) -> dict[str, Any]:
        scalar_metadata = {
            key: value for key, value in self.metadata.items()
            if isinstance(value, (str, int, float, bool, type(None)))
        }
        return {
            "sequence": self.sequence,
            "kind": self.kind,
            "owner_uuid": self.owner_uuid,
            "generation_uuid": self.generation_uuid,
            "identity": self.identity,
            "callback_identity": self.callback_identity,
            "space_type": self.space_type,
            "region_type": self.region_type,
            "native_remover_identity": _identity(self.native_remover),
            "released": self.released,
            "release_error": self.release_error,
            "metadata": scalar_metadata,
        }


class LifecycleRollbackError(RuntimeError):
    pass


@dataclass(slots=True)
class _ClassState:
    cls: type
    generation_uuid: str
    native_unregister: Callable[[type], None]
    registration_identity: tuple[bool, int, int]
    leases: int = 0


@dataclass(slots=True)
class _PropertyState:
    owner: Any
    name: str
    generation_uuid: str
    property_identity: tuple[int, int]
    leases: int = 0


_CLASS_STATES: dict[tuple[str, int], _ClassState] = {}
_PROPERTY_STATES: dict[tuple[str, int, str], _PropertyState] = {}


class RegistrationJournal:
    def __init__(self, module_identity: int = 0) -> None:
        self.owner_uuid = OWNER_UUID
        self.generation_uuid = str(uuid.uuid4())
        self.module_identity = int(module_identity or 0)
        self.state = "OPEN"
        self.records: list[ResourceRecord] = []
        self._sequence = 0
        self.adopted = False
        self.last_error = ""
        self.rollback_reason = ""

    def checkpoint(self) -> int:
        # Sequence checkpoints stay valid even when completed transient
        # resources are pruned from the active ledger.
        return int(self._sequence)

    def acquire(
        self,
        kind: str,
        value: Any,
        remover: Callable[[Any], None],
        *,
        callback: Any = None,
        space_type: str = "",
        region_type: str = "",
        native_remover: Any = None,
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        if self.state not in {"OPEN", "READY"}:
            raise RuntimeError("Smart Sculpt lifecycle journal is not acquirable")
        if not callable(remover):
            raise TypeError("resource remover must be callable")
        self._sequence += 1
        record = ResourceRecord(
            sequence=self._sequence,
            kind=str(kind or "resource"),
            value=value,
            remover=remover,
            owner_uuid=self.owner_uuid,
            generation_uuid=self.generation_uuid,
            identity=_identity(value),
            callback_identity=_identity(callback),
            space_type=str(space_type or ""),
            region_type=str(region_type or ""),
            native_remover=native_remover,
            metadata=dict(metadata or {}),
        )
        self.records.append(record)
        _sync(self)
        return value

    def _release(self, record: ResourceRecord) -> bool:
        if record.released:
            return False
        if record.owner_uuid != self.owner_uuid or record.generation_uuid != self.generation_uuid:
            raise RuntimeError("resource ownership mismatch")
        try:
            record.remover(record.value)
        except Exception as exc:
            record.release_error = f"{type(exc).__name__}: {exc}"
            _sync(self, record.release_error)
            raise
        record.release_error = ""
        record.released = True
        try:
            self.records.remove(record)
        except ValueError:
            pass
        _sync(self)
        return True

    def release(self, value: Any, kind: str | None = None) -> bool:
        identity = _identity(value)
        for record in reversed(self.records):
            if record.released or record.identity != identity:
                continue
            if kind is not None and record.kind != kind:
                continue
            return self._release(record)
        return False

    def release_matching(self, predicate: Callable[[ResourceRecord], bool]) -> bool:
        for record in reversed(self.records):
            if record.released:
                continue
            try:
                matches = bool(predicate(record))
            except Exception:
                matches = False
            if matches:
                return self._release(record)
        return False

    def _release_range(self, records: tuple[ResourceRecord, ...], reason: str) -> None:
        failures: list[str] = []
        for record in reversed(records):
            if record.released:
                continue
            try:
                self._release(record)
            except Exception as exc:
                failures.append(f"{record.kind}#{record.sequence}:{type(exc).__name__}:{exc}")
        if failures:
            self.last_error = "; ".join(failures)
            _sync(self, reason or self.last_error)
            raise LifecycleRollbackError(self.last_error)

    def rollback_to(self, checkpoint: int, reason: str = "") -> None:
        marker = max(0, int(checkpoint))
        records = tuple(record for record in self.records if int(record.sequence) > marker)
        self._release_range(records, reason or "rollback_to")
        _sync(self, reason)

    def complete_transient(self, record: ResourceRecord) -> None:
        """Forget a native resource that ended itself without a remover call."""
        if record.released:
            return
        record.released = True
        record.release_error = ""
        try:
            self.records.remove(record)
        except ValueError:
            pass
        _sync(self)

    def commit(self) -> None:
        if self.state != "OPEN":
            raise RuntimeError("Smart Sculpt lifecycle commit is invalid")
        self.state = "READY"
        self.last_error = ""
        _sync(self)

    def rollback(self, reason: str = "") -> None:
        global _CURRENT
        if self.state == "CLOSED":
            return
        self.rollback_reason = str(reason or "rollback")
        self.state = "ROLLING_BACK"
        _sync(self, self.rollback_reason)
        try:
            self._release_range(tuple(self.records), reason or "rollback")
        except Exception:
            self.state = "ROLLBACK_FAILED"
            _sync(self, self.last_error or reason)
            raise
        self.state = "CLOSED"
        self.last_error = ""
        generation = self.generation_uuid
        for key in tuple(_CLASS_STATES):
            if key[0] == generation:
                _CLASS_STATES.pop(key, None)
        for key in tuple(_PROPERTY_STATES):
            if key[0] == generation:
                _PROPERTY_STATES.pop(key, None)
        with _LOCK:
            namespace = _namespace()
            for key in (_NAMESPACE_KEY, *_LEGACY_NAMESPACE_KEYS):
                stored = namespace.get(key)
                if not isinstance(stored, dict) or stored.get("owner_uuid") != OWNER_UUID:
                    continue
                live = stored.get("journal")
                if live is self or stored.get("generation_uuid") == generation:
                    namespace.pop(key, None)
            if _CURRENT is self:
                _CURRENT = None


def _sync(journal: Any, reason: str = "") -> None:
    try:
        records = [record.view() for record in tuple(getattr(journal, "records", ()))]
    except Exception:
        records = []
    with _LOCK:
        _namespace()[_NAMESPACE_KEY] = {
            "owner_uuid": OWNER_UUID,
            "revision": REVISION,
            "generation_uuid": str(getattr(journal, "generation_uuid", "")),
            "module_identity": int(getattr(journal, "module_identity", 0) or 0),
            "state": str(getattr(journal, "state", "")),
            "reason": str(reason or ""),
            "records": records,
            "journal": journal,
        }


def _stored_entries() -> tuple[tuple[str, dict[str, Any]], ...]:
    namespace = _namespace()
    out = []
    for key in (_NAMESPACE_KEY, *_LEGACY_NAMESPACE_KEYS):
        stored = namespace.get(key)
        if isinstance(stored, dict) and stored.get("owner_uuid") == OWNER_UUID:
            out.append((key, stored))
    return tuple(out)


def _remember_orphan(journal: Any, tag: str, error: BaseException | str) -> None:
    """Retain a bounded exact journal for a later disable-time cleanup retry."""
    if journal is not None and journal not in _ORPHANED_JOURNALS:
        _ORPHANED_JOURNALS.append(journal)
    try:
        from . import _sss_runtime_errors as _errors
        _errors.warn_once(tag, error)
    except Exception:
        pass


def _discard_owned_namespace_entry(key: str, expected: Any = None) -> None:
    namespace = _namespace()
    stored = namespace.get(key)
    if not isinstance(stored, dict) or stored.get("owner_uuid") != OWNER_UUID:
        return
    if expected is not None and stored is not expected:
        return
    namespace.pop(key, None)


def begin_registration(module_identity: int = 0) -> Any:
    """Begin or adopt an exact generation without raising through add-on enable.

    Exact partial generations are rolled back first.  If a native remover is
    temporarily unavailable, its journal is retained in a bounded retry ledger
    and registration continues in degraded mode.  No foreign namespace value is
    modified and no live RNA class is rebound.
    """
    global _CURRENT
    requested_identity = int(module_identity or 0)
    with _LOCK:
        current = _CURRENT
        if current is not None:
            state = str(getattr(current, "state", ""))
            if state == "READY":
                current_identity = int(getattr(current, "module_identity", 0) or 0)
                if current_identity == requested_identity:
                    current.adopted = False
                    return current
                # A different package-module identity is a live replacement,
                # not a duplicate enable.  Retire the exact prior generation
                # before any new RNA class/property identity is acquired.
                try:
                    current.rollback("retire_ready_generation_for_live_replacement")
                except Exception as exc:
                    _remember_orphan(current, "lifecycle-live-replacement", exc)
                _CURRENT = None
            if state in {"OPEN", "ROLLING_BACK", "ROLLBACK_FAILED"}:
                try:
                    current.rollback("recover_in_process_partial_registration")
                except Exception as exc:
                    _remember_orphan(current, "lifecycle-current-partial", exc)
                _CURRENT = None
            elif state == "CLOSED":
                _CURRENT = None

        for key, stored in _stored_entries():
            live = stored.get("journal")
            state = str(stored.get("state", ""))
            if live is not None and getattr(live, "owner_uuid", None) == OWNER_UUID:
                live_state = str(getattr(live, "state", state))
                if live_state == "READY":
                    live_identity = int(getattr(live, "module_identity", 0) or 0)
                    if live_identity == requested_identity:
                        live.adopted = False
                        _CURRENT = live
                        _sync(live, "adopt_ready_generation")
                        return live
                    try:
                        live.rollback("retire_stored_ready_generation_for_live_replacement")
                    except Exception as exc:
                        _remember_orphan(live, "lifecycle-stored-live-replacement", exc)
                    _discard_owned_namespace_entry(key, stored)
                    _CURRENT = None
                    continue
                if live_state in {"OPEN", "ROLLING_BACK", "ROLLBACK_FAILED"}:
                    try:
                        live.rollback("recover_partial_registration")
                    except Exception as exc:
                        _remember_orphan(live, "lifecycle-stored-partial", exc)
                    _discard_owned_namespace_entry(key, stored)
                    continue
                _discard_owned_namespace_entry(key, stored)
                continue
            if state in {"OPEN", "READY", "ROLLING_BACK", "ROLLBACK_FAILED"}:
                _remember_orphan(None, "lifecycle-metadata-without-journal",
                                 "owned lifecycle metadata had no exact live journal; continuing degraded")
            _discard_owned_namespace_entry(key, stored)

        journal = RegistrationJournal(requested_identity)
        _CURRENT = journal
        _sync(journal)
        return journal



def force_new_registration(module_identity: int = 0) -> RegistrationJournal:
    """Install a minimal fresh journal after an unexpected bootstrap failure.

    This is used only by the package root's final exception barrier. It never
    scans or mutates foreign resources and guarantees that later successful
    acquisitions still have an exact generation owner.
    """
    global _CURRENT
    try:
        journal = RegistrationJournal(int(module_identity or 0))
    except Exception:
        # uuid.uuid4() is the only expected constructor dependency; retain a
        # deterministic process-local generation if an embedded test replaces it.
        journal = RegistrationJournal.__new__(RegistrationJournal)
        journal.owner_uuid = OWNER_UUID
        journal.generation_uuid = f"degraded-{id(journal):x}"
        journal.module_identity = int(module_identity or 0)
        journal.state = "OPEN"
        journal.records = []
        journal._sequence = 0
        journal.adopted = False
        journal.last_error = "bootstrap fallback"
        journal.rollback_reason = ""
    _CURRENT = journal
    try:
        _sync(journal, "force_new_registration")
    except Exception:
        pass
    return journal

def retry_orphan_cleanup(reason: str = "disable") -> int:
    """Retry exact cleanup for bounded prior-generation journals."""
    pending = tuple(_ORPHANED_JOURNALS)
    _ORPHANED_JOURNALS.clear()
    failures = 0
    for journal in pending:
        try:
            journal.rollback(reason)
        except Exception as exc:
            failures += 1
            _remember_orphan(journal, f"orphan-cleanup-{id(journal)}", exc)
    return failures


def current_journal() -> Any | None:
    global _CURRENT
    if _CURRENT is not None and str(getattr(_CURRENT, "state", "")) == "CLOSED":
        _CURRENT = None
    return _CURRENT


def active_generation() -> str:
    journal = current_journal()
    if journal is None or str(getattr(journal, "state", "")) not in {"OPEN", "READY"}:
        return ""
    return str(getattr(journal, "generation_uuid", ""))


def generation_is_current(generation_uuid: str) -> bool:
    journal = current_journal()
    return bool(
        generation_uuid
        and journal is not None
        and str(getattr(journal, "owner_uuid", "")) == OWNER_UUID
        and str(getattr(journal, "generation_uuid", "")) == str(generation_uuid)
        and str(getattr(journal, "state", "")) in {"OPEN", "READY"}
    )


def generation_guard(callback: Callable[..., Any], *, stale_result: Any = None) -> Callable[..., Any]:
    generation = active_generation()

    @functools.wraps(callback)
    def guarded(*args, **kwargs):
        if not generation_is_current(generation):
            return stale_result
        try:
            return callback(*args, **kwargs)
        except Exception as exc:
            try:
                from . import _sss_runtime_errors as _errors
                _errors.record(f"callback:{getattr(callback, '__module__', '')}.{getattr(callback, '__name__', 'anonymous')}", exc)
            except Exception:
                pass
            return stale_result

    guarded._sss_owner_uuid = OWNER_UUID
    guarded._sss_generation_uuid = generation
    guarded._sss_original_callback = callback
    return guarded


def _can_acquire(journal: Any) -> bool:
    # ``adopted`` only records that a duplicate enable found the exact existing
    # READY generation.  Runtime resources requested later by those already-
    # registered exact classes (modal draw handlers, bounded one-shot timers)
    # must remain acquirable.  The duplicate register() path itself returns
    # before adding any resources, so this does not exchange live RNA.
    return bool(
        journal is not None
        and str(getattr(journal, "state", "")) in {"OPEN", "READY"}
    )


def _exact_unregister_class(state: _ClassState) -> None:
    try:
        state.native_unregister(state.cls)
    except Exception as exc:
        # Never infer successful teardown from a missing optional ``bl_rna``
        # identity: Extension classes are not guaranteed to expose one.  Only
        # Blender's explicit already-unregistered result is a safe no-op.
        if _already_unregistered_error(exc):
            return
        raise


def _add_class_lease(journal: RegistrationJournal, state: _ClassState) -> bool:
    token = object()
    state.leases += 1

    def remove(_token: object) -> None:
        if state.leases <= 0:
            return
        state.leases -= 1
        if state.leases:
            return
        key = (state.generation_uuid, id(state.cls))
        try:
            _exact_unregister_class(state)
        finally:
            _CLASS_STATES.pop(key, None)

    try:
        journal.acquire(
            "class", token, remove,
            callback=state.cls,
            native_remover=state.native_unregister,
            metadata={
                "class": state.cls,
                "class_name": str(getattr(state.cls, "__name__", "")),
                "class_module": str(getattr(state.cls, "__module__", "")),
                "class_identity": id(state.cls),
                "registration_rna_identity": state.registration_identity[1],
            },
        )
    except Exception:
        state.leases -= 1
        raise
    return True


def _strip_redo_panel_from_owned_operator(cls: type) -> bool:
    """Remove REGISTER only from this Suite's undoable Operators before RNA registration.

    Blender exposes Adjust Last Operation when an Operator combines REGISTER
    and UNDO.  Smart Sculpt keeps UNDO while removing REGISTER so the operation
    remains a single undo step without creating the redo panel.  Ownership is
    restricted to classes defined inside this exact package; foreign Blender or
    add-on classes passed accidentally through this helper remain untouched.
    """
    import bpy
    package_name = str(__package__ or "").strip()
    module_name = str(getattr(cls, "__module__", "") or "").strip()
    if not package_name or not (module_name == package_name or module_name.startswith(package_name + ".")):
        return False
    try:
        if not issubclass(cls, bpy.types.Operator):
            return False
    except Exception:
        return False
    try:
        options = set(getattr(cls, "bl_options", ()) or ())
    except Exception:
        return False
    if "REGISTER" not in options or "UNDO" not in options:
        return False
    options.discard("REGISTER")
    cls.bl_options = options
    return True


def register_class(cls: type) -> bool:
    import bpy
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("class registration requires the active owned Smart Sculpt generation")
    if not isinstance(cls, type):
        raise TypeError("RNA class must be a type")
    key = (journal.generation_uuid, id(cls))
    state = _CLASS_STATES.get(key)
    if state is not None:
        return _add_class_lease(journal, state)

    if class_registration_identity(cls)[0]:
        raise RuntimeError(f"RNA class collision with a non-owned exact class: {getattr(cls, '__name__', cls)!s}")
    _strip_redo_panel_from_owned_operator(cls)
    try:
        bpy.utils.register_class(cls)
    except Exception as registration_error:
        # Native registration can fail after allocating RNA without exposing
        # class-local ``bl_rna``.  Unregistering this exact Python class object
        # cannot release a foreign same-name class; never resolve by identifier.
        try:
            bpy.utils.unregister_class(cls)
        except Exception as cleanup_error:
            if not _already_unregistered_error(cleanup_error):
                raise RuntimeError(
                    f"RNA class partial-registration rollback failed for "
                    f"{getattr(cls, '__name__', cls)!s}: {cleanup_error}"
                ) from registration_error
        raise

    # Native success is authoritative.  Some Extension RNA classes do not
    # expose an ``is_registered`` flag; optional class-local bl_rna identity is
    # retained when available but its absence is not a registration failure.
    registration_identity = class_registration_identity(cls)
    state = _ClassState(
        cls=cls,
        generation_uuid=journal.generation_uuid,
        native_unregister=bpy.utils.unregister_class,
        registration_identity=registration_identity,
    )
    _CLASS_STATES[key] = state
    try:
        return _add_class_lease(journal, state)
    except Exception:
        try:
            _exact_unregister_class(state)
        finally:
            _CLASS_STATES.pop(key, None)
        raise


def unregister_class(cls: type) -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "class" and record.metadata.get("class") is cls
    ))


def _add_property_lease(journal: RegistrationJournal, state: _PropertyState, definition: Any) -> bool:
    token = object()
    state.leases += 1

    def remove(_token: object) -> None:
        if state.leases <= 0:
            return
        state.leases -= 1
        if state.leases:
            return
        key = (state.generation_uuid, id(state.owner), state.name)
        try:
            current = _property_identity(state.owner, state.name)
            if current == (0, 0) and not _property_exists(state.owner, state.name):
                return
            if current != state.property_identity:
                raise RuntimeError(f"RNA property identity changed before exact removal: {state.name}")
            delattr(state.owner, state.name)
            if _property_identity(state.owner, state.name) == state.property_identity:
                raise RuntimeError(f"RNA property exact removal failed: {state.name}")
        finally:
            _PROPERTY_STATES.pop(key, None)

    try:
        journal.acquire(
            "rna_property", token, remove,
            metadata={
                "owner": state.owner,
                "owner_identity": id(state.owner),
                "name": state.name,
                "property_descriptor_identity": state.property_identity[0],
                "property_rna_identity": state.property_identity[1],
                "definition_identity": id(definition),
            },
        )
    except Exception:
        state.leases -= 1
        raise
    return True


def set_rna_property(owner: Any, name: str, definition: Any) -> bool:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("RNA property registration requires the active owned Smart Sculpt generation")
    prop_name = str(name or "").strip()
    if not prop_name:
        raise ValueError("RNA property name is empty")
    key = (journal.generation_uuid, id(owner), prop_name)
    state = _PROPERTY_STATES.get(key)
    if state is not None:
        if _property_identity(owner, prop_name) != state.property_identity:
            raise RuntimeError(f"RNA property identity changed while owned: {prop_name}")
        return _add_property_lease(journal, state, definition)
    if _property_exists(owner, prop_name):
        raise RuntimeError(f"RNA property collision with a non-owned exact property: {prop_name}")

    setattr(owner, prop_name, definition)
    if not _property_exists(owner, prop_name):
        try:
            delattr(owner, prop_name)
        except Exception:
            pass
        raise RuntimeError(f"RNA property failed exact registration verification: {prop_name}")
    state = _PropertyState(owner, prop_name, journal.generation_uuid, _property_identity(owner, prop_name))
    _PROPERTY_STATES[key] = state
    try:
        return _add_property_lease(journal, state, definition)
    except Exception:
        try:
            if _property_identity(owner, prop_name) == state.property_identity:
                delattr(owner, prop_name)
        finally:
            _PROPERTY_STATES.pop(key, None)
        raise


def remove_rna_property(owner: Any, name: str) -> bool:
    prop_name = str(name or "").strip()
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "rna_property"
        and record.metadata.get("owner") is owner
        and record.metadata.get("name") == prop_name
    ))


def append_handler(collection: Any, callback: Callable[..., Any]) -> Callable[..., Any]:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("handler registration requires the active owned Smart Sculpt generation")
    for record in reversed(journal.records):
        if (
            not record.released and record.kind == "handler"
            and isinstance(record.value, tuple) and len(record.value) == 2
            and record.value[0] is collection
            and record.metadata.get("original_callback") is callback
        ):
            wrapped_existing = record.value[1]
            try:
                if wrapped_existing in collection:
                    return wrapped_existing
            except Exception:
                pass
            journal._release(record)
            break
    wrapped = generation_guard(callback)
    collection.append(wrapped)

    def remove(value: tuple[Any, Callable[..., Any]]) -> None:
        target, fn = value
        while fn in target:
            target.remove(fn)

    journal.acquire(
        "handler", (collection, wrapped), remove,
        callback=wrapped,
        native_remover=getattr(collection, "remove", None),
        metadata={
            "collection_identity": id(collection),
            "original_callback": callback,
            "original_callback_identity": id(callback),
        },
    )
    return wrapped


def remove_handler(collection: Any, callback_or_wrapper: Callable[..., Any]) -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "handler"
        and isinstance(record.value, tuple) and len(record.value) == 2
        and record.value[0] is collection
        and (
            record.value[1] is callback_or_wrapper
            or record.metadata.get("original_callback") is callback_or_wrapper
        )
    ))


def register_timer(
    callback: Callable[[], Any], *, first_interval: float = 0.0, persistent: bool = False,
    max_runs: int = 64,
) -> Callable[[], Any]:
    import bpy
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("timer registration requires the active owned Smart Sculpt generation")
    generation = journal.generation_uuid
    record_box: dict[str, ResourceRecord] = {}
    run_limit = max(1, min(int(max_runs or 1), 4096))
    run_count = 0

    @functools.wraps(callback)
    def wrapped():
        nonlocal run_count
        result = None
        run_count += 1
        try:
            if generation_is_current(generation) and run_count <= run_limit:
                result = callback()
        except Exception as exc:
            try:
                from . import _sss_runtime_errors as _errors
                _errors.record(f"timer:{getattr(callback, '__module__', '')}.{getattr(callback, '__name__', 'anonymous')}", exc)
            except Exception:
                pass
            result = None
        # Every app timer is a bounded one-shot/retry chain. A stale
        # generation, callback completion, or the explicit run cap stops it.
        if run_count >= run_limit:
            result = None
        if result is None:
            record = record_box.get("record")
            if record is not None:
                journal.complete_transient(record)
        return result

    wrapped._sss_owner_uuid = OWNER_UUID
    wrapped._sss_generation_uuid = generation
    wrapped._sss_original_callback = callback
    # Persistent timers are prohibited. Keep the legacy parameter for API
    # compatibility but always register a finite non-persistent callback.
    bpy.app.timers.register(
        wrapped, first_interval=max(0.0, float(first_interval)), persistent=False
    )

    def remove(fn: Callable[[], Any]) -> None:
        try:
            registered = bool(bpy.app.timers.is_registered(fn))
        except Exception:
            registered = True
        if registered:
            bpy.app.timers.unregister(fn)

    try:
        journal.acquire(
            "timer", wrapped, remove,
            callback=wrapped,
            native_remover=bpy.app.timers.unregister,
            metadata={
                "persistent": False,
                "requested_persistent": bool(persistent),
                "max_runs": run_limit,
                "stop_condition": "callback returns None, generation becomes stale, or max_runs reached",
                "original_callback": callback,
                "original_callback_identity": id(callback),
            },
        )
        record_box["record"] = journal.records[-1]
    except Exception:
        try:
            remove(wrapped)
        except Exception:
            pass
        raise
    return wrapped


def unregister_timer(callback_or_wrapper: Callable[[], Any]) -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "timer" and (
            record.value is callback_or_wrapper
            or record.metadata.get("original_callback") is callback_or_wrapper
        )
    ))


def add_draw_handler(
    space_type: Any,
    callback: Callable[..., Any],
    args: tuple[Any, ...],
    region_type: str,
    draw_type: str,
) -> tuple[Any, Callable[..., Any]]:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("draw handler registration requires the active owned Smart Sculpt generation")
    wrapped = generation_guard(callback)
    handle = space_type.draw_handler_add(wrapped, tuple(args), str(region_type), str(draw_type))
    resource = (space_type, handle, str(region_type), wrapped)

    def remove(value: tuple[Any, Any, str, Callable[..., Any]]) -> None:
        space, native_handle, region, _fn = value
        space.draw_handler_remove(native_handle, region)

    try:
        journal.acquire(
            "draw_handler", resource, remove,
            callback=wrapped,
            space_type=str(getattr(space_type, "__name__", space_type)),
            region_type=str(region_type),
            native_remover=space_type.draw_handler_remove,
            metadata={
                "draw_type": str(draw_type),
                "handle_identity": id(handle),
                "original_callback": callback,
                "original_callback_identity": id(callback),
            },
        )
    except Exception:
        try:
            remove(resource)
        except Exception:
            pass
        raise
    return handle, wrapped


def remove_draw_handler(space_type: Any, handle: Any, region_type: str = "WINDOW") -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "draw_handler"
        and isinstance(record.value, tuple) and len(record.value) == 4
        and record.value[0] is space_type
        and record.value[1] is handle
        and record.value[2] == str(region_type)
    ))


def subscribe_msgbus(
    *, key: Any, notify: Callable[..., Any], args: tuple[Any, ...] = (), options: set[str] | None = None
) -> Any:
    import bpy
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("msgbus registration requires the active owned Smart Sculpt generation")
    owner = object()
    wrapped = generation_guard(notify)
    bpy.msgbus.subscribe_rna(
        key=key, owner=owner, args=tuple(args), notify=wrapped, options=set(options or ())
    )

    def remove(value: Any) -> None:
        bpy.msgbus.clear_by_owner(value)

    try:
        journal.acquire(
            "msgbus", owner, remove,
            callback=wrapped,
            native_remover=bpy.msgbus.clear_by_owner,
            metadata={
                "key_identity": id(key),
                "original_callback": notify,
                "original_callback_identity": id(notify),
            },
        )
    except Exception:
        try:
            remove(owner)
        except Exception:
            pass
        raise
    return owner


def clear_msgbus(owner: Any) -> bool:
    journal = current_journal()
    return bool(journal and journal.release(owner, "msgbus"))


def register_keymap_item(keymap: Any, item: Any) -> tuple[Any, Any]:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("keymap registration requires the active owned Smart Sculpt generation")
    value = (keymap, item)

    def remove(resource: tuple[Any, Any]) -> None:
        km, kmi = resource
        km.keymap_items.remove(kmi)

    journal.acquire(
        "keymap", value, remove,
        callback=item,
        native_remover=getattr(getattr(keymap, "keymap_items", None), "remove", None),
        metadata={"keymap_identity": id(keymap), "item_identity": id(item)},
    )
    return value


def remove_keymap_item(keymap: Any, item: Any) -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "keymap" and record.value == (keymap, item)
    ))


def register_translation(owner_key: str, payload: Any) -> bool:
    import bpy
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("translation registration requires the active owned Smart Sculpt generation")
    key = str(owner_key)
    # One exact owner key per generation.  A duplicate call from the same module
    # does not invoke Blender's global translation registry twice.
    for record in reversed(journal.records):
        if not record.released and record.kind == "translation" and record.metadata.get("owner_key") == key:
            if record.metadata.get("payload_identity") == id(payload):
                return True
            raise RuntimeError(f"translation owner collision inside generation: {key}")
    bpy.app.translations.register(key, payload)
    resource = (key, id(payload))

    def remove(value: tuple[str, int]) -> None:
        bpy.app.translations.unregister(value[0])

    try:
        journal.acquire(
            "translation", resource, remove,
            native_remover=bpy.app.translations.unregister,
            metadata={"owner_key": key, "payload_identity": id(payload)},
        )
    except Exception:
        try:
            remove(resource)
        except Exception:
            pass
        raise
    return True


def unregister_translation(owner_key: str) -> bool:
    key = str(owner_key)
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "translation" and record.metadata.get("owner_key") == key
    ))


def register_module(module: Any) -> bool:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("module registration requires the active owned Smart Sculpt generation")
    for record in reversed(journal.records):
        if not record.released and record.kind == "module" and record.metadata.get("module") is module:
            return True
    register_fn = getattr(module, "register", None)
    if not callable(register_fn):
        return False
    checkpoint = journal.checkpoint()
    unregister_fn = getattr(module, "unregister", None)
    try:
        register_fn()

        def remove(target: Any) -> None:
            target_unregister = getattr(target, "unregister", None)
            if callable(target_unregister):
                target_unregister()

        journal.acquire(
            "module", module, remove,
            callback=register_fn,
            metadata={
                "module": module,
                "module_name": str(getattr(module, "__name__", "")),
                "module_identity": id(module),
            },
        )
        return True
    except Exception as registration_error:
        # Reset module-local flags even when register() failed before the module
        # marker itself could be journalled.  Native resources are then released
        # by the exact generation checkpoint.  Never suppress a cleanup failure.
        cleanup_error = None
        rollback_fn = getattr(module, "rollback_registration", None)
        try:
            if callable(rollback_fn):
                rollback_fn()
            elif callable(unregister_fn):
                unregister_fn()
        except Exception as exc:
            cleanup_error = exc
        try:
            journal.rollback_to(checkpoint, "module_register_failure")
        except Exception as rollback_error:
            if cleanup_error is not None:
                raise LifecycleRollbackError(
                    f"module cleanup failed: {cleanup_error}; journal rollback failed: {rollback_error}"
                ) from registration_error
            raise
        if cleanup_error is not None:
            raise RuntimeError(
                f"module unregister after failed registration failed: {cleanup_error}"
            ) from registration_error
        raise


def unregister_module(module: Any) -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "module" and record.metadata.get("module") is module
    ))


def acquire_resource(
    kind: str,
    value: Any,
    remover: Callable[[Any], None],
    *,
    callback: Any = None,
    space_type: str = "",
    region_type: str = "",
    native_remover: Any = None,
    metadata: dict[str, Any] | None = None,
) -> Any:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("resource acquisition requires the active owned Smart Sculpt generation")
    return journal.acquire(
        kind, value, remover,
        callback=callback,
        space_type=space_type,
        region_type=region_type,
        native_remover=native_remover,
        metadata=metadata,
    )


def release_resource(value: Any, kind: str | None = None) -> bool:
    journal = current_journal()
    return bool(journal and journal.release(value, kind))


def add_event_timer(window_manager: Any, time_step: float, *, window: Any = None) -> Any:
    journal = current_journal()
    if not _can_acquire(journal):
        raise RuntimeError("event timer registration requires the active owned Smart Sculpt generation")
    timer = window_manager.event_timer_add(float(time_step), window=window)
    resource = (window_manager, timer)

    def remove(value: tuple[Any, Any]) -> None:
        wm, native_timer = value
        wm.event_timer_remove(native_timer)

    try:
        journal.acquire(
            "event_timer", resource, remove,
            callback=timer,
            native_remover=getattr(window_manager, "event_timer_remove", None),
            metadata={"timer_identity": id(timer), "window_identity": id(window)},
        )
    except Exception:
        try:
            remove(resource)
        except Exception:
            pass
        raise
    return timer


def remove_event_timer(window_manager: Any, timer: Any) -> bool:
    journal = current_journal()
    return bool(journal and journal.release_matching(
        lambda record: record.kind == "event_timer"
        and isinstance(record.value, tuple) and len(record.value) == 2
        and record.value[0] is window_manager and record.value[1] is timer
    ))


def live_replacement_rollback_active() -> bool:
    """Return true only while the exact current generation is being replaced live."""
    journal = current_journal()
    if journal is None or str(getattr(journal, "state", "")) != "ROLLING_BACK":
        return False
    return "live_replacement" in str(getattr(journal, "rollback_reason", "")).casefold()


def rollback_current(reason: str = "") -> None:
    journal = current_journal()
    if journal is not None:
        try:
            journal.rollback(reason)
        except Exception as exc:
            _remember_orphan(journal, "rollback-current", exc)
    retry_orphan_cleanup(reason or "rollback_current")


def snapshot() -> dict[str, Any]:
    journal = current_journal()
    if journal is None:
        return {"owner_uuid": OWNER_UUID, "revision": REVISION, "state": "EMPTY", "records": (),
                "orphaned_journals": len(_ORPHANED_JOURNALS)}
    return {
        "owner_uuid": OWNER_UUID,
        "revision": REVISION,
        "generation_uuid": str(getattr(journal, "generation_uuid", "")),
        "module_identity": int(getattr(journal, "module_identity", 0) or 0),
        "state": str(getattr(journal, "state", "")),
        "adopted": bool(getattr(journal, "adopted", False)),
        "records": tuple(record.view() for record in tuple(getattr(journal, "records", ()))),
        "orphaned_journals": len(_ORPHANED_JOURNALS),
    }
