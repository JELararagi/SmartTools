# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Data-only persistent feature switches; no process-global API interception."""
from __future__ import annotations
from contextlib import AbstractContextManager
from pathlib import Path
import json,re
from typing import Any,Callable
import bpy
from bpy.props import BoolProperty,StringProperty
from . import rna_safety as _rna
from . import _sss_json_store
from . import _sss_runtime_errors as _runtime_errors
_SUITE_KEY='smart_sculpt_suite'; _SUITE_LABEL='Smart Sculpt Suite'; _CATEGORY='Smart Sculpt'
_OPERATOR_ID='smart_sculpt_suite.toggle_persistent_feature'
_FEATURES:dict[str,dict[str,dict[str,Any]]]={}; _STATE:dict[str,dict[str,bool]]={}; _REGISTERED=False
_KIND_ORDER=('handlers','timers','msgbus','keymaps','draw_handlers')
_KIND_INFO={
'handlers':('Application Handlers','アプリケーションハンドラー'),
'timers':('Background Timers','バックグラウンドタイマー'),
'msgbus':('RNA Message Bus Watchers','RNAメッセージバス監視'),
'keymaps':('Hotkeys','ホットキー'),
'draw_handlers':('Viewport / Editor Draw','ビューポート / エディター描画'),
}
def _clean_identifier(value,fallback='smart_tools'):
    value=re.sub(r'[^0-9A-Za-z_]+','_',str(value or '').split('.')[-1]).strip('_').lower(); return value or fallback
def configure(*,suite_key=None,suite_label=None,category=None):
    global _SUITE_KEY,_SUITE_LABEL,_CATEGORY
    if suite_key: _SUITE_KEY=_clean_identifier(suite_key)
    if suite_label: _SUITE_LABEL=str(suite_label)
    if category: _CATEGORY=str(category)
def toggle_operator_id(): return _OPERATOR_ID
def _settings_path():
    try: root=Path(bpy.utils.user_resource('CONFIG',path='Smart_Sculpt_Suite',create=True))
    except Exception: root=Path.home()/'.config'/'Smart_Sculpt_Suite'; root.mkdir(parents=True,exist_ok=True)
    return root/'Smart_Sculpt_Suite_features.json'
def _load_state():
    global _STATE
    doc=_sss_json_store.read_with_backup(_settings_path(),allow_legacy=True)
    payload=_sss_json_store.payload_only(doc) if isinstance(doc,dict) else {}
    raw=payload.get('feature_toggles',payload) if isinstance(payload,dict) else {}
    _STATE={str(a):{str(k):bool(v) for k,v in dict(values).items()} for a,values in dict(raw or {}).items() if isinstance(values,dict)}
    return _STATE
def _save_state(): _sss_json_store.atomic_write(_settings_path(),{'feature_toggles':_STATE})
def flush_state(): _save_state(); return True
def is_feature_enabled(alias,feature_key):
    alias=str(alias or ''); key=str(feature_key or '')
    return bool(_STATE.get(alias,{}).get(key,False))
def set_feature_enabled(alias,feature_key,enabled):
    alias=str(alias or ''); key=str(feature_key or '')
    if not alias or not key: return False
    bucket=_STATE.setdefault(alias,{})
    existed=key in bucket; previous=bool(bucket.get(key,False)); desired=bool(enabled)
    bucket[key]=desired
    try:
        _save_state()
    except Exception as exc:
        if existed: bucket[key]=previous
        else:
            bucket.pop(key,None)
            if not bucket: _STATE.pop(alias,None)
        _runtime_errors.record('feature_toggle_save',exc)
        return False
    _set_feature_active(alias,key,desired)
    return True
def _feature_record(alias,label,key):
    en,ja=_KIND_INFO.get(key,(key,key)); return {'alias':alias,'tool_label':label,'key':key,'label_en':en,'label_ja':ja,'enabled':is_feature_enabled(alias,key)}
def feature_entries(alias=None):
    aliases=(str(alias),) if alias else tuple(_FEATURES)
    result=[]
    for name in aliases:
        label=str(_FEATURES.get(name,{}).get('_meta',{}).get('tool_label') or name)
        for key in _KIND_ORDER:
            if key in _FEATURES.get(name,{}): result.append(_feature_record(name,label,key))
    return result
def all_feature_aliases(): return tuple(_FEATURES)
def _add_action(alias,tool_label,feature_key,action):
    record=_FEATURES.setdefault(str(alias),{'_meta':{'tool_label':str(tool_label or alias)}})
    record.setdefault(str(feature_key),{'actions':[]})['actions'].append(dict(action or {}))
def _remove_action(action):
    callback=action.get('remove') if isinstance(action,dict) else None
    if callable(callback):
        try: callback()
        except Exception: pass
def _apply_action(action):
    callback=action.get('add') if isinstance(action,dict) else None
    if callable(callback):
        try: callback()
        except Exception: pass
def _set_feature_active(alias,key,enabled):
    rec=_FEATURES.get(alias,{}).get(key,{})
    for action in tuple(rec.get('actions',())): (_apply_action if enabled else _remove_action)(action)
def deactivate_alias(alias):
    for key in _KIND_ORDER: _set_feature_active(str(alias),key,False)
def clear_alias(alias): deactivate_alias(alias); _FEATURES.pop(str(alias),None)
class _RuntimeCapture(AbstractContextManager):
    """Finite data-only capture boundary. Native APIs are never replaced."""
    def __init__(self,alias,tool_label=None): self.alias=str(alias or ''); self.tool_label=str(tool_label or alias or '')
    def __enter__(self):
        record=_FEATURES.setdefault(self.alias,{'_meta':{'tool_label':self.tool_label}})
        for key in _KIND_ORDER: record.setdefault(key,{'actions':[]})
        return self
    def __exit__(self,*_args): return False
    def kind_enabled(self,key): return is_feature_enabled(self.alias,key)
    def record_action(self,key,action): _add_action(self.alias,self.tool_label,key,action)
def capture_runtime(alias,tool_label=None): return _RuntimeCapture(alias,tool_label)
def capture_call(alias,tool_label,callback:Callable[[],Any]):
    with capture_runtime(alias,tool_label): return callback()
class SMARTTOOLS_OT_toggle_persistent_feature(bpy.types.Operator):
    bl_idname=_OPERATOR_ID; bl_label='Toggle Feature'; bl_description='Enable or disable this persistent Smart Sculpt feature.'; bl_options={'UNDO'}
    alias:StringProperty(default=''); feature_key:StringProperty(default=''); enabled:BoolProperty(default=True)
    def execute(self,context):
        return {'FINISHED'} if set_feature_enabled(self.alias,self.feature_key,self.enabled) else {'CANCELLED'}

# Public Python compatibility aliases; every name resolves to the same exact RNA class.
SMARTTOOLS_OT_SMART_SCULPT_SUITE_TOGGLE_PERSISTENT_FEATURE = SMARTTOOLS_OT_toggle_persistent_feature
SMARTTOOLS_OT_SCULPT_TOGGLE_PERSISTENT_FEATURE = SMARTTOOLS_OT_toggle_persistent_feature
def register_ui(**_kwargs):
    global _REGISTERED
    configure(**_kwargs); _load_state()
    if not _REGISTERED: _rna.register_class(SMARTTOOLS_OT_toggle_persistent_feature); _REGISTERED=True
def unregister_ui():
    global _REGISTERED
    if _REGISTERED: _rna.unregister_class(SMARTTOOLS_OT_toggle_persistent_feature); _REGISTERED=False
def _draw_rows(layout,context,entries):
    for item in entries:
        enabled=bool(item['enabled']); row=layout.row(align=True); row.label(text=item['label_en'])
        op=row.operator(_OPERATOR_ID,text='Enabled' if enabled else 'Disabled',icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',depress=enabled)
        op.alias=item['alias']; op.feature_key=item['key']; op.enabled=not enabled
    return bool(entries)
def draw_inline_toggles(layout,context,alias,*,compact=True): del compact; return _draw_rows(layout,context,feature_entries(alias))
def unregister_all():
    for alias in tuple(_FEATURES): deactivate_alias(alias)
    unregister_ui(); _FEATURES.clear()
