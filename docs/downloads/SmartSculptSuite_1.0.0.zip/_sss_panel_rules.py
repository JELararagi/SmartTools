# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Read-only Smart Tools Manager placement adapter for native Smart Sculpt roots.

This module is intentionally hot-path safe.  Panel.poll calls only inspect
already-loaded modules through fixed ``sys.modules`` names and then invoke the
Manager public placement API when it is present.  No import, reload, scan,
class mutation, timer, I/O, redraw request, proxy creation, or Manager private
state access is performed from poll/draw.
"""
from __future__ import annotations

import sys
from typing import Any, Callable, Final

TOOL_KEY: Final[str] = "SMART_SCULPT"
ON: Final[str] = "ON"
OFF: Final[str] = "OFF"
NOT_READY: Final[str] = "NOT_READY"

_MANAGER_MODULE_NAMES: Final[tuple[str, ...]] = (
    "bl_ext.user_default.smart_tools_manager",
    "smart_tools_manager",
)
_PUBLIC_API_NAMES: Final[tuple[str, ...]] = (
    "placement_allowed",
    "panel_rule_allows_context",
)

# Current Manager logical editor catalog.  Invalid/mismatched keys fail closed
# once an authoritative Manager callback is present.
LOGICAL_EDITOR_KEYS: Final[frozenset[str]] = frozenset({
    "VIEW_3D",
    "IMAGE_EDITOR",
    "UV_EDITOR",
    "SHADER_EDITOR",
    "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR",
    "TEXTURE_NODE_EDITOR",
    "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR",
    "DOPE_SHEET",
    "GRAPH_EDITOR",
    "DRIVERS",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "ASSET_BROWSER",
    "FILE_BROWSER",
    "SPREADSHEET",
})


def _find_public_callback() -> tuple[Any | None, Callable[..., Any] | None, str]:
    """Return an already-loaded Manager public placement callback.

    Only the two stable top-level module names are inspected.  Some Manager
    builds expose the callback from ``manager`` imported into the package root;
    others expose it directly on ``smart_tools_manager``.  This lookup accepts
    either without importing submodules.
    """
    for module_name in _MANAGER_MODULE_NAMES:
        module = sys.modules.get(module_name)
        if module is None:
            continue
        for api_name in _PUBLIC_API_NAMES:
            callback = getattr(module, api_name, None)
            if callable(callback):
                return module, callback, api_name
    return None, None, ""


def bind_public_manager_api() -> str:
    """Compatibility no-op retained for the registration transaction.

    Earlier builds cached a Manager function here.  The native root contract now
    requires fixed ``sys.modules`` hot-path lookups, so no binding is retained.
    """
    module, callback, _name = _find_public_callback()
    return ON if module is not None and callback is not None else NOT_READY


def unbind() -> None:
    """No cached Manager state is stored."""
    return None


def _call_with_supported_signature(callback: Callable[..., Any], context: Any, editor_key: str) -> Any:
    """Call Manager placement API without requiring a specific historical signature."""
    # Preferred current public surface: placement_allowed(tool_key, context=..., editor_key=...).
    attempts = (
        lambda: callback(TOOL_KEY, context=context, editor_key=editor_key),
        lambda: callback(TOOL_KEY, context, editor_key),
        lambda: callback(tool_key=TOOL_KEY, context=context, editor_key=editor_key),
        lambda: callback(TOOL_KEY, context=context, logical_editor=editor_key),
        lambda: callback(TOOL_KEY, context=context, expected_editor_key=editor_key),
    )
    last_type_error: TypeError | None = None
    for attempt in attempts:
        try:
            return attempt()
        except TypeError as exc:
            last_type_error = exc
            continue
    if last_type_error is not None:
        raise last_type_error
    return None


def state(context: Any, editor_key: str) -> str:
    """Return ON/OFF/NOT_READY for the current Manager cell."""
    key = str(editor_key or "").strip().upper()
    module, callback, _api_name = _find_public_callback()
    if module is None or callback is None:
        return NOT_READY
    if key not in LOGICAL_EDITOR_KEYS:
        return OFF
    try:
        result = _call_with_supported_signature(callback, context, key)
    except TypeError:
        # An authoritative Manager exists but its public API contract does not
        # accept this exact cell query: treat the known mismatch as denied.
        return OFF
    except Exception:
        return NOT_READY
    if result is True:
        return ON
    if result is False:
        return OFF
    text = str(result or "").strip().upper()
    if text in {"ON", "TRUE", "ALLOW", "ALLOWED", "VISIBLE"}:
        return ON
    if text in {"OFF", "FALSE", "DENY", "DENIED", "HIDDEN"}:
        return OFF
    if text in {"NOT_READY", "DISABLED", "ABSENT", "UNKNOWN", ""}:
        return NOT_READY
    return NOT_READY


def placement_allowed(context: Any, editor_key: str) -> bool:
    """Panel.poll helper: fail open when Manager has no verified authority."""
    current = state(context, editor_key)
    return current != OFF


def visible(context: Any, editor_key: str) -> bool:
    return placement_allowed(context, editor_key)


def snapshot() -> dict[str, Any]:
    module, callback, api_name = _find_public_callback()
    if module is None or callback is None:
        return {"state": NOT_READY, "tool_key": TOOL_KEY, "bound": False}
    return {
        "state": ON,
        "tool_key": TOOL_KEY,
        "bound": True,
        "module_name": getattr(module, "__name__", ""),
        "module_identity": id(module),
        "callback_identity": id(callback),
        "api_name": api_name,
    }
