# Smart Shapekey 1.0.0

Blender 5.1.2 用のシェイプキー編集・フェイシャルキャプチャツールです。
インストールと操作例は SmartShapekey の解説書を参照してください。

Smart Shapekey is a shape-key editing and facial-capture extension for Blender 5.1.2.
See the SmartShapekey guide for installation and worked examples.
