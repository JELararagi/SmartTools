# SPDX-License-Identifier: GPL-3.0-or-later
"""Store absolute Base and local-space offsets on a per-object reference mesh."""
from array import array
from contextlib import contextmanager
import uuid

import bpy
import bmesh
from mathutils import Vector
from mathutils.kdtree import KDTree

BASIS='.skm_morphmapper_basis'
OWNER='skm_identity_uuid'
REFERENCE='skm_ref_object_name'
ACTIVE='skm_morphmapper_active_channel'
PREVIEW='SKM_Map_Preview'
busy=set()


def checked(obj):
    if not obj or obj.type!='MESH' or not obj.is_editable or not obj.data.is_editable:
        raise ValueError('Select an editable mesh.')
    if obj.data.users>1:raise ValueError('Make a single-user copy of the mesh first.')
    if obj.mode not in ('OBJECT','EDIT'):raise ValueError('Switch to Object or Edit Mode.')
    if obj.data.shape_keys and (not obj.data.shape_keys.use_relative or obj.mode=='EDIT'):
        raise ValueError('Use Object Mode and relative shape keys to edit a mapped mesh.')
    return obj


def reference(obj):
    ref=bpy.data.objects.get(obj.get(REFERENCE,''))
    if ref and ref!=obj and ref.type=='MESH' and ref.data.attributes.get(BASIS):
        peers=[o for o in bpy.data.objects if o.get(REFERENCE)==ref.name]
        if len(peers)!=1 or peers[0]!=obj or not obj.get(OWNER):raise ValueError('The map reference is shared or its owner cannot be identified.')
        if ref.get('_smart_shape_source_id',obj.get(OWNER))!=obj.get(OWNER):raise ValueError('The stored map owner differs from this object.')
        if len(ref.data.vertices)!=len(obj.data.vertices):raise ValueError('The saved map has a different vertex count.')
        return ref
    return None


def layer_name(cid):
    return BASIS if cid==99 else '.skm_morphmapper_delta_'+str(cid)


def read_layer(mesh,cid):
    a=mesh.attributes.get(layer_name(cid))
    if not a or a.domain!='POINT' or a.data_type!='FLOAT_VECTOR':raise ValueError('A saved channel is missing.')
    return [Vector(p.vector) for p in a.data]


def store_layer(mesh,cid,coords):
    if len(coords)!=len(mesh.vertices):raise ValueError('Vertex count mismatch.')
    a=mesh.attributes.get(layer_name(cid)) or mesh.attributes.new(layer_name(cid),'FLOAT_VECTOR','POINT')
    a.data.foreach_set('vector',array('f',(i for v in coords for i in v)))


def absolute(ref,cid):
    base=read_layer(ref.data,99)
    return base if cid==99 else [a+b for a,b in zip(base,read_layer(ref.data,cid),strict=True)]


def current_coords(obj):
    if obj.mode=='EDIT':
        vertices=bmesh.from_edit_mesh(obj.data).verts
        vertices.ensure_lookup_table()
        return [v.co.copy() for v in vertices]
    keys=obj.data.shape_keys
    if keys:
        preview=keys.key_blocks.get(PREVIEW)
        if preview and obj.get('_smart_shape_preview',False):return [v.co.copy() for v in preview.data]
    return [v.co.copy() for v in obj.data.vertices]


def selection(obj,faces=False):
    if obj.mode=='EDIT':
        bm=bmesh.from_edit_mesh(obj.data)
        bm.verts.index_update()
        return ({v.index for f in bm.faces if f.select for v in f.verts} if faces else
                {v.index for v in bm.verts if v.select})
    return ({i for p in obj.data.polygons if p.select for i in p.vertices} if faces else
            {v.index for v in obj.data.vertices if v.select})


def display(obj,coords):
    if len(coords)!=len(obj.data.vertices):raise ValueError('Vertex count mismatch.')
    if obj.mode=='EDIT':
        bm=bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        for i,p in enumerate(coords):bm.verts[i].co=p
        bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
    elif obj.data.shape_keys:
        block=obj.data.shape_keys.key_blocks.get(PREVIEW)
        if block and not obj.get('_smart_shape_preview',False):raise ValueError('The preview key name is already used.')
        if not block:
            block=obj.shape_key_add(name=PREVIEW,from_mix=False)
            obj['_smart_shape_preview']=True
        block.data.foreach_set('co',array('f',(i for p in coords for i in p)))
        if '_smart_shape_preview_index' not in obj:
            obj['_smart_shape_preview_index']=obj.active_shape_key_index
            obj['_smart_shape_preview_solo']=obj.show_only_shape_key
        obj.active_shape_key_index=list(obj.data.shape_keys.key_blocks).index(block)
        obj.show_only_shape_key=True
    else:
        obj.data.vertices.foreach_set('co',array('f',(i for p in coords for i in p)))
    obj.data.update()


def release_preview(obj):
    keys=obj.data.shape_keys
    if not keys or not obj.get('_smart_shape_preview',False):return
    block=keys.key_blocks.get(PREVIEW)
    if block:obj.shape_key_remove(block)
    obj.active_shape_key_index=min(int(obj.get('_smart_shape_preview_index',0)),len(keys.key_blocks)-1)
    obj.show_only_shape_key=bool(obj.get('_smart_shape_preview_solo',False))
    for k in ('_smart_shape_preview','_smart_shape_preview_index','_smart_shape_preview_solo'):
        if k in obj:del obj[k]


def create_reference(obj,coords):
    ident=uuid.uuid4().hex
    mesh=bpy.data.meshes.new('.__SKM_MORPHMAPPER_'+ident)
    ref=None
    try:
        mesh.from_pydata([tuple(p)for p in coords],[],[])
        store_layer(mesh,99,coords)
        ref=bpy.data.objects.new(obj.name+'_SKM_REF',mesh)
        bpy.context.scene.collection.objects.link(ref)
        ref.hide_render=True;ref.hide_viewport=True
        obj[OWNER]=ident;obj[REFERENCE]=ref.name
        if obj.data.uv_layers.active:obj.skm_uv_map_name=obj.data.uv_layers.active.name
        ref['_smart_shape_source_id']=ident
        return ref
    except Exception:
        if ref:bpy.data.objects.remove(ref,do_unlink=True)
        if mesh.users==0:bpy.data.meshes.remove(mesh)
        raise


@contextmanager
def quiet(obj):
    uid=obj.as_pointer();already=uid in busy;busy.add(uid)
    try:yield
    finally:
        if not already:busy.discard(uid)


def pick(obj,index):
    with quiet(obj):
        obj.skm_index=index
        obj[ACTIVE]=obj.skm_maps[index].chn_id


def commit(obj,ref,cid,only=None):
    shown=current_coords(obj)
    basis=read_layer(ref.data,99)
    values=shown if cid==99 else [p-b for p,b in zip(shown,basis,strict=True)]
    if only is not None:
        if not only:raise ValueError('Select vertices or faces first.')
        prior=read_layer(ref.data,cid)
        values=[v if i in only else prior[i] for i,v in enumerate(values)]
    store_layer(ref.data,cid,values)


def switch(obj,ctx=None):
    if obj.as_pointer() in busy or obj.skm__suppress_apply or obj.skm_edit_mode:return
    if not (0<=obj.skm_index<len(obj.skm_maps)):return
    checked(obj)
    ref=reference(obj)
    if not ref:return
    target=obj.skm_maps[obj.skm_index].chn_id;prior=obj.get(ACTIVE,99)
    if target==prior:return
    with quiet(obj):
        commit(obj,ref,prior)
        if target==99 and obj.data.shape_keys:
            release_preview(obj)
        else:display(obj,absolute(ref,target))
        obj[ACTIVE]=target


def edit_mode_change(obj,context):
    if obj.skm_edit_mode:
        obj.skm_edit_index=obj.skm_index
    elif 0<=obj.skm_edit_index<len(obj.skm_maps):
        obj.skm_index=obj.skm_edit_index


def unique(obj,label):
    names=set(obj.skm_maps.keys());base=label.strip() or 'NewMap'
    if base not in names:return base
    i=1
    while f'{base}.{i:03}' in names:i+=1
    return f'{base}.{i:03}'


def create_row(obj,ref,label,coords,cid=None):
    used={row.chn_id for row in obj.skm_maps}
    cid=cid if cid is not None and cid not in used else next((i for i in range(98,-1,-1)if i not in used),None)
    if cid is None:raise ValueError('All available channels are occupied.')
    name=unique(obj,label)
    deltas=[p-b for p,b in zip(coords,read_layer(ref.data,99),strict=True)]
    store_layer(ref.data,cid,deltas)
    with quiet(obj):
        row=obj.skm_maps.add();row.name=name;row.prev_name=name;row.chn_id=cid
    return len(obj.skm_maps)-1


def base(obj,selected=False):
    checked(obj);coords=current_coords(obj);ref=reference(obj)
    if not ref:
        if obj.skm_maps:raise ValueError('The existing map reference could not be found.')
        ref=create_reference(obj,coords)
        with quiet(obj):
            r=obj.skm_maps.add();r.name='Basis';r.prev_name='Basis';r.chn_id=99;r.locked=True;pick(obj,0)
    else:
        original=read_layer(ref.data,99)
        desired=coords
        if selected:
            ids=selection(obj,True)
            if not ids:raise ValueError('Select faces first.')
            desired=[p if i in ids else original[i]for i,p in enumerate(coords)]
        if obj.skm_keep_map_shapes:
            old={r.chn_id:absolute(ref,r.chn_id)for r in obj.skm_maps if r.chn_id!=99}
            for cid,points in old.items():store_layer(ref.data,cid,[p-b for p,b in zip(points,desired)])
        store_layer(ref.data,99,desired)
        pick(obj,0);display(obj,desired)
    return ref


def active(obj):
    checked(obj);ref=reference(obj)
    if not ref or not obj.skm_maps:raise ValueError('Set the Base before creating a map.')
    cid=obj.get(ACTIVE,99)
    row=next((r for r in obj.skm_maps if r.chn_id==cid),None)
    if not row:raise ValueError('Choose a current map.')
    return ref,row


def selected_rows(obj,mode):
    return [r for r in obj.skm_maps if r.chn_id!=99 and (mode!='SELECTED' or r.selected)]


def mirror(obj,ref,coords,groups,direction):
    axis='XYZ'.index(obj.skm_mirror_axis)
    center=getattr(obj,'skm_mirror_center_'+obj.skm_mirror_axis.lower())
    epsilon=obj.skm_mirror_epsilon;basis=read_layer(ref.data,99)
    tree=KDTree(len(basis))
    for i,v in enumerate(basis):tree.insert(v,i)
    tree.balance()
    result=[p.copy() for p in coords];count=0
    for i in groups:
        side=basis[i][axis]-center
        if abs(side)<=epsilon or (direction=='LR' and side>0) or (direction=='RL' and side<0):continue
        pt=basis[i].copy();pt[axis]=2*center-pt[axis]
        _,j,d=tree.find(pt)
        if d<=epsilon:
            delta=coords[i]-basis[i];delta[axis]*=-1
            result[j]=basis[j]+delta;count+=1
    if not count:raise ValueError('No selected vertices have matching opposite vertices.')
    return result


def cleanup(obj):
    checked(obj);ref=reference(obj)
    if not ref:return
    existing=obj.data.shape_keys
    with quiet(obj):
        if existing and obj.get('_smart_shape_preview',False) and existing.key_blocks.get(PREVIEW):
            obj.shape_key_remove(existing.key_blocks[PREVIEW])
            obj.active_shape_key_index=min(int(obj.get('_smart_shape_preview_index',0)),len(existing.key_blocks)-1)
            obj.show_only_shape_key=bool(obj.get('_smart_shape_preview_solo',False))
        elif not existing:display(obj,read_layer(ref.data,99))
        obj.skm_maps.clear();obj.skm_index=-1
        for k in (ACTIVE,OWNER,REFERENCE,'_smart_shape_preview','_smart_shape_preview_index','_smart_shape_preview_solo'):
            if k in obj:del obj[k]
    data=ref.data;bpy.data.objects.remove(ref,do_unlink=True)
    if data.users==0:bpy.data.meshes.remove(data)
