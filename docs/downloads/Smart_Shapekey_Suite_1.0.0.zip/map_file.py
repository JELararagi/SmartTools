# SPDX-License-Identifier: GPL-3.0-or-later
"""Read and write the observed .skmuv loop-domain format with validated UV correspondence."""
from array import array
import json
import math
import os
from pathlib import Path
import struct
import tempfile
import zlib

HEADER_LIMIT = 32 * 1024 * 1024
PAYLOAD_LIMIT = 256 * 1024 * 1024


def _decode(path):
    with Path(path).open('rb') as stream:
        prefix = stream.read(4)
        if len(prefix) != 4:
            raise ValueError('The map header is incomplete.')
        size, = struct.unpack('<I', prefix)
        if not 1 <= size <= HEADER_LIMIT:
            raise ValueError('The map header length is outside the supported range.')
        header = json.loads(stream.read(size).decode('utf8'))
        count = header['nloops']
        maps = header['maps']
        triangles = header['tri_loop_indices']
        if type(count) is not int or count < 1 or not isinstance(maps,list) or len(maps)>99:
            raise ValueError('Unsupported map dimensions.')
        names = [m['name'] for m in maps]
        ids = [m['chn_id'] for m in maps]
        if (any(type(n) is not str or not n for n in names) or len(set(names))!=len(names)
                or any(type(i) is not int or not 0 <= i < 99 for i in ids) or len(set(ids))!=len(ids)):
            raise ValueError('Invalid map names or channel numbers.')
        if any(len(t)!=3 or any(type(i) is not int or not 0<=i<count for i in t) for t in triangles):
            raise ValueError('A source triangle points outside the map.')
        expected = 4 * count * (2 + 3 * (1 + len(maps)))
        if expected > PAYLOAD_LIMIT:
            raise ValueError('The map data exceeds the supported in-memory size.')
        codec=zlib.decompressobj()
        compressed=stream.read(PAYLOAD_LIMIT+1)
        if len(compressed)>PAYLOAD_LIMIT:
            raise ValueError('The compressed map is too large.')
        raw=codec.decompress(compressed,expected+1)
        if len(raw)!=expected or not codec.eof or codec.unused_data or codec.unconsumed_tail:
            raise ValueError('The declared map size differs from its compressed data.')
    floats = array('f')
    floats.frombytes(raw)
    if any(not math.isfinite(v) for v in floats):
        raise ValueError('The map has a non-finite coordinate.')
    return header, floats


def _records(values, offset, step, count):
    return [tuple(values[i:i+step]) for i in range(offset,offset+count*step,step)]


def decode(path):
    header,coords=_decode(path)
    n=header['nloops']
    uv=_records(coords,0,2,n)
    blocks=[_records(coords,2*n+i*3*n,3,n) for i in range(1+len(header['maps']))]
    return header,uv,blocks


def save(path,uv_name,loops,uv,triangles,basis,channels):
    n=len(loops)
    if not n or len(uv)!=n:
        raise ValueError('Choose a non-empty UV map.')
    header={'version':'1.4.20','uv_name':uv_name,'nloops':n,'tri_loop_indices':[list(t)for t in triangles],
            'maps':[{'name':name,'chn_id':cid} for name,cid,_ in channels]}
    desc=json.dumps(header,separators=(',',':'),ensure_ascii=False).encode('utf8')
    if len(desc)>HEADER_LIMIT or 4*n*(2+3*(1+len(channels)))>PAYLOAD_LIMIT:
        raise ValueError('The map exceeds the supported file size.')
    flat=array('f',[v for p in uv for v in p])
    for points in [basis,*[c[2] for c in channels]]:
        flat.extend(value for idx in loops for value in points[idx])
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent,prefix='.smart-shapekey-',suffix='.part',delete=False) as temp:
        scratch=Path(temp.name)
    try:
        with scratch.open('wb') as stream:
            stream.write(struct.pack('<I',len(desc)))
            stream.write(desc)
            stream.write(zlib.compress(flat.tobytes()))
            stream.flush()
        os.replace(scratch,path)
    finally:
        scratch.unlink(missing_ok=True)


def project(header,source_uv,blocks,loop_vertices,dest_uv,dest_coords):
    """Use identical loop order first. Otherwise interpolate source UV triangles with geometry for seam resolution."""
    if not loop_vertices or len(loop_vertices)!=len(dest_uv):raise ValueError('The destination has no usable UV map.')
    n=len(dest_coords)
    samples=[None]*len(loop_vertices)
    if len(source_uv)==len(dest_uv) and all(math.dist(a,b)<=1e-6 for a,b in zip(source_uv,dest_uv)):
        samples=[((i,), (1.,)) for i in range(len(dest_uv))]
    else:
        # A uniform grid limits candidates when a dense mesh shares a single UV layout.
        triangles=header['tri_loop_indices'];side=max(1,min(128,int(math.sqrt(len(triangles)/6))))
        bounds=[(min(p[i] for p in source_uv),max(p[i] for p in source_uv))for i in range(2)]
        def cell(v,axis):
            lo,hi=bounds[axis]
            return min(side-1,max(0,int((v-lo)*side/max(hi-lo,1e-10))))
        grid={}
        for t in triangles:
            tri=[source_uv[k] for k in t]
            xs=[cell(u,0) for u,v in tri];ys=[cell(v,1) for u,v in tri]
            for gx in range(min(xs),max(xs)+1):
                for gy in range(min(ys),max(ys)+1):grid.setdefault((gx,gy),[]).append(t)
        for l,(px,py) in enumerate(dest_uv):
            options=[]
            for t in grid.get((cell(px,0),cell(py,1)),[]):
                (ax,ay),(bx,by),(cx,cy)=(source_uv[k] for k in t)
                det=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
                if abs(det)<1e-12:continue
                wa=((by-cy)*(px-cx)+(cx-bx)*(py-cy))/det
                wb=((cy-ay)*(px-cx)+(ax-cx)*(py-cy))/det
                weights=(wa,wb,1-wa-wb)
                if min(weights)<-1e-5:continue
                predicted=tuple(sum(w*blocks[0][i][a] for w,i in zip(weights,t)) for a in range(3))
                options.append((math.dist(predicted,dest_coords[loop_vertices[l]]),t,weights))
            if not options:raise ValueError('The destination UV map is outside the saved layout.')
            dist,t,weights=min(options,key=lambda opt:opt[0])
            samples[l]=(t,weights)
        radius=math.dist(tuple(min(c[i] for c in dest_coords)for i in range(3)),tuple(max(c[i] for c in dest_coords)for i in range(3)))
        errors=[]
        for v,(t,w) in zip(loop_vertices,samples):
            co=[sum(m*blocks[0][i][a]for m,i in zip(w,t)) for a in range(3)]
            errors.append(math.dist(dest_coords[v],co))
        if max(errors)>max(1e-5,radius*.12):
            raise ValueError('The saved UV positions do not correspond to this mesh shape.')
    output=[]
    for block in blocks:
        coords=[None]*n
        for v,(t,weights) in zip(loop_vertices,samples):
            point=tuple(sum(w*block[i][a] for i,w in zip(t,weights))for a in range(3))
            if coords[v] is not None and math.dist(coords[v],point)>1e-4:
                raise ValueError('The UV seam gives conflicting values at one destination vertex.')
            coords[v]=point
        if any(p is None for p in coords):raise ValueError('The destination has unmapped loose vertices.')
        output.append(coords)
    return output

