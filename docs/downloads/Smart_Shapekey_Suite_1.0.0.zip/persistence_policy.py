"""Pure persistence state machine for Smart Shapekey resident settings.

The Blender runtime owns one instance.  Keeping the policy independent of
``bpy`` makes the restoration and OFF-writer barrier exhaustively testable.
"""
from __future__ import annotations

from dataclasses import dataclass, field


class PersistencePolicyError(RuntimeError):
    pass


def write_required(*, path_exists: bool, dirty: bool, pending: bool,
                   current: dict[str, object], proposed: dict[str, object]) -> bool:
    """Return False only for an already durable, unchanged generation."""
    return not (bool(path_exists) and not bool(dirty) and not bool(pending) and current == proposed)


@dataclass(slots=True)
class WriteBarrier:
    phase: str = "COLD"
    restore_depth: int = 0
    ready: bool = False
    off_commit_available: bool = False
    off_commit_count: int = 0
    _owner_key: object | None = field(default=None, repr=False)

    def begin_restore(self) -> None:
        if self.phase == "STOPPED":
            raise PersistencePolicyError("cannot restore a stopped persistence owner")
        self.restore_depth += 1
        self.phase = "RESTORING"
        self.ready = False
        self.off_commit_available = False

    def finish_restore(self, *, owner_key: object, enabled: bool) -> None:
        if self.restore_depth <= 0:
            raise PersistencePolicyError("restore depth underflow")
        if owner_key is None:
            raise PersistencePolicyError("restore requires a live persistence owner")
        self.restore_depth -= 1
        if self.restore_depth == 0:
            self._owner_key = owner_key
            self.ready = True
            self.phase = "ENABLED" if bool(enabled) else "DISABLED"

    def _live_owner_matches(self, owner_key: object, owner_enabled: bool) -> bool:
        del owner_enabled
        return (
            owner_key is not None
            and owner_key == self._owner_key
            and self.ready
            and self.restore_depth == 0
        )

    def begin_disable_commit(self, *, owner_key: object, owner_enabled: bool) -> bool:
        if not self._live_owner_matches(owner_key, owner_enabled):
            return False
        if self.phase != "ENABLED" or bool(owner_enabled):
            return False
        self.phase = "OFF_SELF_COMMIT"
        self.off_commit_available = True
        return True

    def finish_disable(self, *, owner_key: object) -> bool:
        if owner_key is None or owner_key != self._owner_key or self.phase != "OFF_SELF_COMMIT":
            return False
        self.off_commit_available = False
        self.phase = "DISABLED"
        return True

    def enable(self, *, owner_key: object, owner_enabled: bool) -> bool:
        if owner_key is None or owner_key != self._owner_key:
            return False
        if not self.ready or self.restore_depth != 0 or self.phase == "STOPPED" or not bool(owner_enabled):
            return False
        self.off_commit_available = False
        self.phase = "ENABLED"
        return True

    def stop(self) -> None:
        self.restore_depth = 0
        self.ready = False
        self.off_commit_available = False
        self.phase = "STOPPED"
        self._owner_key = None

    def reset(self) -> None:
        self.phase = "COLD"
        self.restore_depth = 0
        self.ready = False
        self.off_commit_available = False
        self.off_commit_count = 0
        self._owner_key = None

    def authorize(self, reason: str = "ordinary", *, owner_key: object | None = None,
                  owner_enabled: bool | None = None) -> bool:
        if not self.ready or self.restore_depth != 0:
            return False
        if reason == "off_self_commit":
            if (
                self.phase != "OFF_SELF_COMMIT"
                or not self.off_commit_available
                or owner_key is None
                or owner_key != self._owner_key
                or owner_enabled is not False
            ):
                return False
            self.off_commit_available = False
            self.off_commit_count += 1
            return True
        return self.phase == "ENABLED"

    @property
    def enabled(self) -> bool:
        return self.ready and self.restore_depth == 0 and self.phase == "ENABLED"

    def snapshot(self) -> dict[str, object]:
        return {
            "phase": self.phase,
            "restore_depth": self.restore_depth,
            "ready": self.ready,
            "owner_bound": self._owner_key is not None,
            "off_commit_available": self.off_commit_available,
            "off_commit_count": self.off_commit_count,
        }
