# SPDX-License-Identifier: GPL-3.0-or-later
import bpy
from . import runtime, maps, lifecycle
from .control_help import hint
_uv_cache={}
def uv_choices(obj,ctx):
    names=tuple(layer.name for layer in obj.data.uv_layers) if obj and obj.type=='MESH' else ()
    return _uv_cache.setdefault(names,tuple((n,n,'',i)for i,n in enumerate(names)))
def remember(field):
    def changed(settings,context):
        runtime.save_persistent_setting(field,getattr(settings,field))
    return changed
class SKM_LoadChoice(bpy.types.PropertyGroup):
    selected:bpy.props.BoolProperty(default=True)

class SKM_MapItem(bpy.types.PropertyGroup):
    prev_name: bpy.props.StringProperty(name='prev_name', default='', description=hint('prev_name',''))
    chn_id: bpy.props.IntProperty(name='chn_id', default=0, min=-2147483648, max=2147483647, description=hint('chn_id',''))
    selected: bpy.props.BoolProperty(name='Select', default=False, description=hint('selected',''))
    locked: bpy.props.BoolProperty(name='Lock', default=False, description=hint('locked',''))

class SKM_PG_suite_settings(bpy.types.PropertyGroup):
    n_panel_state_save_enabled: bpy.props.BoolProperty(name='N-panel State Save', default=True, description=hint('n_panel_state_save_enabled',''), update=remember('n_panel_state_save_enabled'))
    show_always_on_toggles: bpy.props.BoolProperty(name='Always-on Features', default=False, description=hint('show_always_on_toggles',''), update=remember('show_always_on_toggles'))
    always_axis_ui_enabled: bpy.props.BoolProperty(name='Axis UI', default=False, description=hint('always_axis_ui_enabled',''), update=remember('always_axis_ui_enabled'))
    always_frame_sync_enabled: bpy.props.BoolProperty(name='Frame Sync', default=False, description=hint('always_frame_sync_enabled',''), update=remember('always_frame_sync_enabled'))
    always_external_tracker_enabled: bpy.props.BoolProperty(name='External Tracker (UDP)', default=False, description=hint('always_external_tracker_enabled',''), update=remember('always_external_tracker_enabled'))
    always_face_tracker_enabled: bpy.props.BoolProperty(name='Face Tracker (Built-In)', default=False, description=hint('always_face_tracker_enabled',''), update=remember('always_face_tracker_enabled'))
    always_face_tracker_hud_enabled: bpy.props.BoolProperty(name='Face Tracker Point HUD', default=False, description=hint('always_face_tracker_hud_enabled',''), update=remember('always_face_tracker_hud_enabled'))

class SKM_UL_MapList(runtime.MapList,bpy.types.UIList):
    pass

class SKM_OT_clean_orphans(runtime.Command,bpy.types.Operator):
    bl_idname='skm.clean_orphans'
    bl_label='Clean Orphans'
    scene_wide: bpy.props.BoolProperty(name='scene_wide', default=False, description=hint('scene_wide','clean_orphans'))

class SKM_OT_clear_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.clear_map'
    bl_label='Clear'
    target_range: bpy.props.EnumProperty(name='Clear', items=(('SELECTED', 'Selected Polygons', '', 0), ('ALL', 'All Polygons', '', 1)), default='SELECTED')

class SKM_OT_copy_selected_verts(runtime.Command,bpy.types.Operator):
    bl_idname='skm.copy_selected_verts'
    bl_label='Copy Selected Verts'

class SKM_OT_delete_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.delete_map'
    bl_label='Delete Map'

class SKM_OT_duplicate_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.duplicate_map'
    bl_label='Duplicate Map'
    inverted: bpy.props.BoolProperty(name='inverted', default=False, description=hint('inverted','duplicate_map'))

class SKM_OT_export_maps(runtime.Command,bpy.types.Operator):
    bl_idname='skm.export_maps'
    bl_label='Export Morph Maps'
    output: bpy.props.EnumProperty(name='Output', items=(('SHAPE_KEYS', 'Shape Keys', '', 0), ('OBJECT', 'Object', '', 1)), default='SHAPE_KEYS')
    prefix: bpy.props.StringProperty(name='Prefix', default='')
    offset: bpy.props.FloatProperty(name='Offset', default=10.0, min=-9999.0, max=9999.0)
    line: bpy.props.IntProperty(name='Line', default=5, min=1, max=9999)
    replace_matching: bpy.props.BoolProperty(name='Replace matching Shape Keys', default=False)

class SKM_OT_export_objects(runtime.Command,bpy.types.Operator):
    bl_idname='skm.export_objects'
    bl_label='Export to Objects'
    target: bpy.props.EnumProperty(name='Target', items=(('ALL', 'All', '', 0), ('SELECTED', 'Selected', '', 1)), default='ALL', description=hint('target','export_objects'))
    source_layout: bpy.props.BoolProperty(name='source_layout', default=False)
    prefix: bpy.props.StringProperty(name='Prefix', default='')
    spacing: bpy.props.FloatProperty(name='Spacing', default=0.5, min=-9999.0, max=9999.0, description=hint('spacing','export_objects'))
    columns: bpy.props.IntProperty(name='Columns', default=5, min=1, max=9999, description=hint('columns','export_objects'))
    origin: bpy.props.EnumProperty(name='Start', items=(('CURSOR', '3D Cursor', '', 0), ('ACTIVE', 'Active Object', '', 1), ('WORLD', 'World Origin', '', 2)), default='CURSOR', description=hint('origin','export_objects'))

class SKM_OT_export_shapekeys(runtime.Command,bpy.types.Operator):
    bl_idname='skm.export_shapekeys'
    bl_label='Export to Shape Keys'
    overwrite_existing: bpy.props.BoolProperty(name='overwrite_existing', default=True)
    target: bpy.props.EnumProperty(name='Target', items=(('ALL', 'All', '', 0), ('SELECTED', 'Selected', '', 1)), default='ALL', description=hint('target','export_shapekeys'))

class SKM_OT_full_cleanup(runtime.Command,bpy.types.Operator):
    bl_idname='skm.full_cleanup'
    bl_label='Full Cleanup'
    scene_wide: bpy.props.BoolProperty(name='scene_wide', default=False, description=hint('scene_wide','full_cleanup'))

class SKM_OT_import_shape_keys(runtime.Command,bpy.types.Operator):
    bl_idname='skm.import_shape_keys'
    bl_label='Import Shape Keys to Channels'
    replace_owned: bpy.props.BoolProperty(name='replace_owned', default=False)

class SKM_OT_invert_selected(runtime.Command,bpy.types.Operator):
    bl_idname='skm.invert_selected'
    bl_label='Invert Selected Shape'

class SKM_OT_load_choose(runtime.Command,bpy.types.Operator):
    bl_idname='skm.load_choose'
    bl_label='Choose maps to import'
    filepath: bpy.props.StringProperty(name='filepath', default='', subtype='FILE_PATH', description=hint('filepath','load_choose'))
    choices: bpy.props.CollectionProperty(name='choices', description=hint('choices','load_choose'), type=SKM_LoadChoice)
    select_all: bpy.props.BoolProperty(name='select_all', default=False, description=hint('select_all','load_choose'))
    deselect_all: bpy.props.BoolProperty(name='deselect_all', default=False, description=hint('deselect_all','load_choose'))

class SKM_OT_load_file(runtime.Command,bpy.types.Operator):
    bl_idname='skm.load_file'
    bl_label='Load'
    filter_glob: bpy.props.StringProperty(name='filter_glob', default='*.skmuv', description=hint('filter_glob','load_file'))
    filepath: bpy.props.StringProperty(name='filepath', default='', subtype='FILE_PATH', description=hint('filepath','load_file'))

class SKM_OT_load_toggle_all(runtime.Command,bpy.types.Operator):
    bl_idname='skm.load_toggle_all'
    bl_label='Toggle All'
    state: bpy.props.BoolProperty(name='state', default=True, description=hint('state','load_toggle_all'))

class SKM_OT_mirror_selected(runtime.Command,bpy.types.Operator):
    bl_idname='skm.mirror_selected'
    bl_label='Mirror Selected'
    direction: bpy.props.EnumProperty(name='Direction', items=(('LR', 'L→R', '', 0), ('RL', 'R→L', '', 1)), default='LR', description=hint('direction','mirror_selected'))

class SKM_OT_mirror_settings(runtime.Command,bpy.types.Operator):
    bl_idname='skm.mirror_settings'
    bl_label='Mirror Settings'

class SKM_OT_move_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.move_map'
    bl_label='Move'
    direction: bpy.props.EnumProperty(name='Direction', items=(('UP', 'Up', '', 0), ('DOWN', 'Down', '', 1)), default='UP', description=hint('direction','move_map'))

class SKM_OT_new_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.new_map'
    bl_label='New Map'
    map_name: bpy.props.StringProperty(name='Name', default='NewMap')
    dialog_invoked: bpy.props.BoolProperty(name='dialog_invoked', default=False)

class SKM_OT_order_maps(runtime.Command,bpy.types.Operator):
    bl_idname='skm.order_maps'
    bl_label='Order Maps'
    mode: bpy.props.EnumProperty(name='mode', items=(('NAME', 'Sort by Name', '', 0), ('CHANNEL_ID', 'ID Order', '', 1)), default='NAME')

class SKM_OT_paste_verts(runtime.Command,bpy.types.Operator):
    bl_idname='skm.paste_verts'
    bl_label='Paste Verts'
    mirrored: bpy.props.BoolProperty(name='mirrored', default=False, description=hint('mirrored','paste_verts'))

class SKM_OT_rename_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.rename_map'
    bl_label='Rename Map'
    map_name: bpy.props.StringProperty(name='Name', default='')
    dialog_invoked: bpy.props.BoolProperty(name='dialog_invoked', default=False)

class SKM_OT_save_file(runtime.Command,bpy.types.Operator):
    bl_idname='skm.save_file'
    bl_label='Save Map File'
    filepath: bpy.props.StringProperty(name='filepath', default='', subtype='FILE_PATH', description=hint('filepath','save_file'))
    check_existing: bpy.props.BoolProperty(name='Check Existing', default=True, description=hint('check_existing','save_file'))
    filter_glob: bpy.props.StringProperty(name='filter_glob', default='*.skmuv', description=hint('filter_glob','save_file'))
    selected_only: bpy.props.BoolProperty(name='selected_only', default=False, description=hint('selected_only','save_file'))

class SKM_OT_save_overwrite(runtime.Command,bpy.types.Operator):
    bl_idname='skm.save_overwrite'
    bl_label='Overwrite Map File'
    selected_only: bpy.props.BoolProperty(name='selected_only', default=False, description=hint('selected_only','save_overwrite'))
    filepath: bpy.props.StringProperty(name='filepath', default='', subtype='FILE_PATH', description=hint('filepath','save_overwrite'))

class SKM_OT_set_base(runtime.Command,bpy.types.Operator):
    bl_idname='skm.set_base'
    bl_label='Set Base'
    selected_polygons: bpy.props.BoolProperty(name='Set Base on Selected Polygons', default=False)
    dialog_range: bpy.props.EnumProperty(name='Set Base', items=(('SELECTED', 'Selected Polygons', '', 0), ('ALL', 'All Polygons', '', 1)), default='SELECTED')
    dialog_invoked: bpy.props.BoolProperty(name='dialog_invoked', default=False)

class SKM_OT_show_help(runtime.Command,bpy.types.Operator):
    bl_idname='skm.show_help'
    bl_label='Help'
    tool_id: bpy.props.StringProperty(name='Tool', default='', description=hint('tool_id','show_help'))

class SKM_OT_show_view3d_npanel(runtime.Command,bpy.types.Operator):
    bl_idname='skm.show_view3d_npanel'
    bl_label='Smart Shapekey'

class SKM_OT_store_map(runtime.Command,bpy.types.Operator):
    bl_idname='skm.store_map'
    bl_label='Store Current Channel'
    selected_polygons: bpy.props.BoolProperty(name='selected_polygons', default=False)
    clear_selected: bpy.props.BoolProperty(name='clear_selected', default=False)
    clear_all: bpy.props.BoolProperty(name='clear_all', default=False)

class SKM_OT_toggle_always_on(runtime.Command,bpy.types.Operator):
    bl_idname='skm.toggle_always_on'
    bl_label='Toggle Always-on Feature'
    target: bpy.props.EnumProperty(name='Feature', items=(('AXIS_UI', 'Axis UI', 'Interactive 2D HUD Axis controller in the 3D Viewport.', 0), ('FRAME_SYNC', 'Frame Sync', 'Frame-change handler that updates animated Shape Axis handles.', 1), ('EXTERNAL_TRACKER', 'External Tracker (UDP)', 'UDP listener for external joystick or tracking data.', 2), ('FACE_TRACKER', 'Face Tracker (Built-In)', 'Webcam-based built-in face tracker.', 3), ('FACE_TRACKER_HUD', 'Face Tracker Point HUD', 'Landmark overlay for the built-in Face Tracker.', 4)), default='AXIS_UI', description=hint('target','toggle_always_on'))
    enable: bpy.props.BoolProperty(name='Enable', default=True, description=hint('enable','toggle_always_on'))

class SKM_OT_toggle_ui_section(runtime.Command,bpy.types.Operator):
    bl_idname='skm.toggle_ui_section'
    bl_label='Toggle UI Section'
    section_key: bpy.props.StringProperty(name='Section', default='', description=hint('section_key','toggle_ui_section'))
    label: bpy.props.StringProperty(name='Label', default='', description=hint('label','toggle_ui_section'))
    default_state: bpy.props.BoolProperty(name='Default State', default=False, description=hint('default_state','toggle_ui_section'))

class SKM_PT_asset_browser_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_asset_browser_root'
    bl_space_type='FILE_BROWSER'
    bl_region_type='TOOL_PROPS'

class SKM_PT_clip_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_clip_editor_root'
    bl_space_type='CLIP_EDITOR'
    bl_region_type='UI'

class SKM_PT_dopesheet_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_dopesheet_editor_root'
    bl_space_type='DOPESHEET_EDITOR'
    bl_region_type='UI'

class SKM_PT_file_browser_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_file_browser_root'
    bl_space_type='FILE_BROWSER'
    bl_region_type='UI'

class SKM_PT_graph_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_graph_editor_root'
    bl_space_type='GRAPH_EDITOR'
    bl_region_type='UI'

class SKM_PT_image_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_image_editor_root'
    bl_space_type='IMAGE_EDITOR'
    bl_region_type='UI'

class SKM_PT_nla_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_nla_editor_root'
    bl_space_type='NLA_EDITOR'
    bl_region_type='UI'

class SKM_PT_node_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_node_editor_root'
    bl_space_type='NODE_EDITOR'
    bl_region_type='UI'

class SKM_PT_sequence_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_sequence_editor_root'
    bl_space_type='SEQUENCE_EDITOR'
    bl_region_type='UI'

class SKM_PT_spreadsheet_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_spreadsheet_root'
    bl_space_type='SPREADSHEET'
    bl_region_type='UI'

class SKM_PT_text_editor_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_text_editor_root'
    bl_space_type='TEXT_EDITOR'
    bl_region_type='UI'

class SKM_PT_view3d_root(runtime.SuitePanel,bpy.types.Panel):
    bl_idname='SKM_PT_view3d_root'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'

GROUPS=(
    SKM_LoadChoice,
    SKM_MapItem,
    SKM_PG_suite_settings,
    SKM_UL_MapList,
)
COMMANDS=(
    SKM_OT_clean_orphans,
    SKM_OT_clear_map,
    SKM_OT_copy_selected_verts,
    SKM_OT_delete_map,
    SKM_OT_duplicate_map,
    SKM_OT_export_maps,
    SKM_OT_export_objects,
    SKM_OT_export_shapekeys,
    SKM_OT_full_cleanup,
    SKM_OT_import_shape_keys,
    SKM_OT_invert_selected,
    SKM_OT_load_choose,
    SKM_OT_load_file,
    SKM_OT_load_toggle_all,
    SKM_OT_mirror_selected,
    SKM_OT_mirror_settings,
    SKM_OT_move_map,
    SKM_OT_new_map,
    SKM_OT_order_maps,
    SKM_OT_paste_verts,
    SKM_OT_rename_map,
    SKM_OT_save_file,
    SKM_OT_save_overwrite,
    SKM_OT_set_base,
    SKM_OT_show_help,
    SKM_OT_show_view3d_npanel,
    SKM_OT_store_map,
    SKM_OT_toggle_always_on,
    SKM_OT_toggle_ui_section,
)
PANELS=(
    SKM_PT_asset_browser_root,
    SKM_PT_clip_editor_root,
    SKM_PT_dopesheet_editor_root,
    SKM_PT_file_browser_root,
    SKM_PT_graph_editor_root,
    SKM_PT_image_editor_root,
    SKM_PT_nla_editor_root,
    SKM_PT_node_editor_root,
    SKM_PT_sequence_editor_root,
    SKM_PT_spreadsheet_root,
    SKM_PT_text_editor_root,
    SKM_PT_view3d_root,
)

def properties(ledger):
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm__suppress_apply',bpy.props.BoolProperty(name='skm__suppress_apply', default=False, description=hint('skm__suppress_apply','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_edit_index',bpy.props.IntProperty(name='skm_edit_index', default=-1, min=-2147483648, max=2147483647))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_edit_mode',bpy.props.BoolProperty(name='Edit', default=False, update=maps.edit_mode_change))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_index',bpy.props.IntProperty(name='skm_index', default=-1, min=-2147483648, max=2147483647, description=hint('skm_index',''), update=maps.switch))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_keep_map_shapes',bpy.props.BoolProperty(name='Keep Map Shapes', default=True, description=hint('skm_keep_map_shapes','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_maps',bpy.props.CollectionProperty(name='skm_maps', description=hint('skm_maps',''), type=SKM_MapItem))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_mirror_axis',bpy.props.EnumProperty(name='Axis', items=(('X', 'X', '', 0), ('Y', 'Y', '', 1), ('Z', 'Z', '', 2)), default='X', description=hint('skm_mirror_axis','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_mirror_center_x',bpy.props.FloatProperty(name='Center X', default=0.0, min=-3.4028234663852886e+38, max=3.4028234663852886e+38, description=hint('skm_mirror_center_x','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_mirror_center_y',bpy.props.FloatProperty(name='Center Y', default=0.0, min=-3.4028234663852886e+38, max=3.4028234663852886e+38, description=hint('skm_mirror_center_y','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_mirror_center_z',bpy.props.FloatProperty(name='Center Z', default=0.0, min=-3.4028234663852886e+38, max=3.4028234663852886e+38, description=hint('skm_mirror_center_z','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_mirror_epsilon',bpy.props.FloatProperty(name='Tolerance', default=0.0010000000474974513, min=0.0, max=3.4028234663852886e+38, description=hint('skm_mirror_epsilon','')))
    lifecycle.register_rna_property(ledger,bpy.types.Object,'skm_uv_map_name',bpy.props.EnumProperty(name='UV Map',description=hint('skm_uv_map_name'),items=uv_choices))
    lifecycle.register_rna_property(ledger,bpy.types.WindowManager,'skm_suite_settings',bpy.props.PointerProperty(name='skm_suite_settings', description=hint('skm_suite_settings',''), type=SKM_PG_suite_settings))
    lifecycle.register_rna_property(ledger,bpy.types.WindowManager,'smart_shapekey_suite_always_on_enabled',bpy.props.BoolProperty(name='Always-on', default=False, description=hint('smart_shapekey_suite_always_on_enabled','')))
