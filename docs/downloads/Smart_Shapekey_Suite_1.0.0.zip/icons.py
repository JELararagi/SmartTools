# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from pathlib import Path
from typing import Final

_PREVIEW_COLLECTION = None

# Blender標準アイコンでは機能差が十分に伝わらないボタンだけ独自PNGを使います。
CUSTOM_ICON_FILES: Final[dict[str, str]] = {
    'DUPLICATE_MAP_INVERTED': 'duplicate_map_inverted.png',
    'COPY_SELECTED_VERTS': 'copy_selected_verts.png',
    'PASTE_VERTS': 'paste_verts.png',
    'PASTE_VERTS_MIRROR': 'paste_verts_mirror.png',
    'INVERT_SELECTED_VERTS': 'invert_selected_verts.png',
    'MIRROR_SELECTED_LR': 'mirror_selected_lr.png',
    'MIRROR_SELECTED_RL': 'mirror_selected_rl.png',
    'CAPTURE_MIN': 'capture_min.png',
    'CAPTURE_MAX': 'capture_max.png',
    'OPEN_TRACKER_REFERENCE_MAP': 'open_tracker_reference_map.png',
}

# Blender標準アイコンで機能が十分に表せるものは標準アイコンを優先します。
STANDARD_ICON_MAP: Final[dict[str, str]] = {
    'HELP': 'QUESTION',
    'ADD': 'ADD',
    'REMOVE': 'REMOVE',
    'UP': 'TRIA_UP',
    'DOWN': 'TRIA_DOWN',
    'LEFT': 'TRIA_LEFT',
    'RIGHT': 'TRIA_RIGHT',
    'DUPLICATE': 'DUPLICATE',
    'TRASH': 'TRASH',
    'SETTINGS': 'TOOL_SETTINGS',
    'PIN_ON': 'PINNED',
    'PIN_OFF': 'UNPINNED',
    'MIRROR': 'MOD_MIRROR',
    'COPY': 'COPYDOWN',
    'PASTE': 'PASTEDOWN',
    'INVERT': 'ARROW_LEFTRIGHT',
    'KEY': 'KEY_HLT',
    'CHECK': 'CHECKMARK',
    'SAVE': 'FILE_TICK',
    'LOAD': 'FILEBROWSER',
    'CANCEL': 'CANCEL',
    'RESET': 'FILE_REFRESH',
    'IMPORT': 'IMPORT',
    'EXPORT': 'EXPORT',
    'GROUP': 'GROUP',
    'PRESET': 'USER',
    'TRACKER': 'CAMERA_DATA',
    'CAMERA': 'CAMERA_DATA',
    'START': 'PLAY',
    'STOP': 'PAUSE',
    'MODIFIER': 'MODIFIER',
    'DRIVER': 'DRIVER',
    'ENABLED': 'CHECKMARK',
    'DISABLED': 'ERROR',
    'CREATE_MAP': 'MESH_DATA',
    'BASE': 'KEY_HLT',
    'NEW_MAP': 'ADD',
    'DUPLICATE_MAP': 'DUPLICATE',
    'DELETE_MAP': 'TRASH',
    'MOVE_MAP_UP': 'TRIA_UP',
    'MOVE_MAP_DOWN': 'TRIA_DOWN',
    'OPEN_MIRROR_SETTINGS': 'TOOL_SETTINGS',
    'EXPORT_TO_SHAPE_KEYS': 'SHAPEKEY_DATA',
    'EXPORT_SELECTED_SHAPE_KEYS': 'CHECKMARK',
    'EXPORT_TO_OBJECTS': 'MESH_CUBE',
    'EXPORT_SELECTED_OBJECTS': 'CHECKMARK',
    'SAVE_ALL': 'FILE_TICK',
    'SAVE_SELECTED': 'FILE_TICK',
    'LOAD_FILE': 'FILEBROWSER',
    'CLEAN_ORPHANS': 'BRUSH_DATA',
    'CLEAN_ORPHANS_SCENE': 'BRUSH_DATA',
    'FULL_CLEANUP': 'CANCEL',
    'FULL_CLEANUP_SCENE': 'CANCEL',
    'APPLY_MODIFIERS_CHOOSE': 'CHECKMARK',
    'INSTALL_FACE_TRACKER_DEPS': 'PLUGIN',
    'ADD_TRACKER_TARGET': 'ADD',
    'REMOVE_TRACKER_TARGET': 'REMOVE',
    'PRESET_MOUTH': 'MESH_DATA',
    'PRESET_EYES': 'HIDE_OFF',
    'PRESET_BLINK': 'HIDE_ON',
    'AXIS_RESET_HUD': 'DRIVER',
    'AXIS_RESET': 'FILE_REFRESH',
    'AXIS_RESET_ALL': 'FILE_REFRESH',
    'HUD': 'MODIFIER',
    'CREATE_FIRST_GROUP': 'ADD',
    'ADD_GROUP': 'ADD',
    'REMOVE_GROUP': 'REMOVE',
    'MOVE_GROUP_UP': 'TRIA_UP',
    'MOVE_GROUP_DOWN': 'TRIA_DOWN',
    'RESET_HANDLE': 'FILE_REFRESH',
    'KEY_HANDLE': 'KEY_HLT',
    'EDIT_VALUES': 'DRIVER',
    'BAKE_ANIMATION': 'ACTION_TWEAK',
    'IMPORT_GROUP_JSON': 'IMPORT',
    'EXPORT_GROUP_JSON': 'EXPORT',
    'ADD_MAPPING': 'ADD',
    'REMOVE_MAPPING': 'REMOVE',
    'MOVE_MAPPING_UP': 'TRIA_UP',
    'MOVE_MAPPING_DOWN': 'TRIA_DOWN',
    'MIRROR_MAPPINGS': 'MOD_MIRROR',
    'ADD_PRESET': 'ADD',
    'REMOVE_PRESET': 'REMOVE',
    'MOVE_PRESET_UP': 'TRIA_UP',
    'MOVE_PRESET_DOWN': 'TRIA_DOWN',
    'SET_PRESET_BUTTON': 'GREASEPENCIL',
    'CALL_PRESET_BUTTON': 'RESTRICT_SELECT_OFF',
    'KEY_PRESET': 'KEY_HLT',
    'GENERATE_FORMULA': 'DRIVER',
}


def _icons_dir() -> Path:
    return Path(__file__).resolve().parent / 'icon' / 'assets'


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        icons_dir = _icons_dir()
        for key, filename in CUSTOM_ICON_FILES.items():
            path = icons_dir / filename
            if path.exists():
                try:
                    pcoll.load(key, str(path), 'IMAGE')
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name: str | None) -> int:
    if not name:
        return 0
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', 0) or 0)
    except Exception:
        return 0


def fallback_icon(name: str | None, default: str = 'NONE') -> str:
    if not name:
        return str(default or 'NONE')
    return STANDARD_ICON_MAP.get(str(name), str(default or 'NONE'))


def operator(layout, operator_id: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    value = icon_value(icon_name)
    if value:
        attempts = (
            lambda: layout.operator(operator_id, text=text, icon_value=value, emboss=emboss, **kwargs),
            lambda: layout.operator(operator_id, text=text, icon_value=value, **kwargs),
        )
        for attempt in attempts:
            try:
                return attempt()
            except TypeError:
                continue
            except Exception:
                continue
    icon = fallback_icon(icon_name, fallback)
    attempts = (
        lambda: layout.operator(operator_id, text=text, icon=icon, emboss=emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, icon=icon, **kwargs),
        lambda: layout.operator(operator_id, text=text, emboss=emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.operator(operator_id, text=text)


def label(layout, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', translate: bool = True):
    value = icon_value(icon_name)
    if value:
        try:
            return layout.label(text=text, translate=translate, icon_value=value)
        except Exception:
            pass
    icon = fallback_icon(icon_name, fallback)
    try:
        return layout.label(text=text, translate=translate, icon=icon)
    except Exception:
        return layout.label(text=text, translate=translate)


def prop(layout, data, property_name: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    value = icon_value(icon_name)
    if value:
        attempts = (
            lambda: layout.prop(data, property_name, text=text, icon_value=value, emboss=emboss, **kwargs),
            lambda: layout.prop(data, property_name, text=text, icon_value=value, **kwargs),
        )
        for attempt in attempts:
            try:
                return attempt()
            except TypeError:
                continue
            except Exception:
                continue
    icon = fallback_icon(icon_name, fallback)
    attempts = (
        lambda: layout.prop(data, property_name, text=text, icon=icon, emboss=emboss, **kwargs),
        lambda: layout.prop(data, property_name, text=text, icon=icon, **kwargs),
        lambda: layout.prop(data, property_name, text=text, emboss=emboss, **kwargs),
        lambda: layout.prop(data, property_name, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.prop(data, property_name, text=text)


def register():
    _load_previews()


def unregister():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None
