# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shared UI helpers without process-global class or Panel patching."""
from __future__ import annotations

import os
from pathlib import Path

import bpy
from bpy.props import BoolProperty, StringProperty

PACKAGE_ID = "smart_shapekey_suite"
ADDON_NAME = "Smart Shapekey Suite"
TOOL_LABEL_EN = "Smart Shapekey"
TOOL_LABEL_JA = "Smart Shapekey"
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + "_always_on_enabled"
_STORAGE_DIRNAME = "Smart_Shapekey_Suite"
_PREVIEW_COLLECTION = None

_ALWAYS_ON_NAME = "Always-on"
_ALWAYS_ON_DESCRIPTION = (
    "Saved suite-wide switch. Persistent helper resources are started only while explicitly enabled."
)

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggle'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', 'Open the detailed help popup for this tool group.'): 'このツールグループの詳細ヘルプポップアップを開きます。',
    ('*', 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'): '常時機能の有効・無効を切り替え、Nパネル設定を即時保存します。',
    ('*', 'Save current N-panel settings to the Smart Shapekey folder in Blender CONFIG and request Blender to save user preferences.'): '現在のNパネル設定を Blender の設定フォルダー内の Smart Shapekey フォルダーへ保存し、Blender にユーザープリファレンスの保存を要求します。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated files must never be written beside the immutable Extension
    # package.  Keep them in this suite's Blender CONFIG folder.
    try:
        from . import storage as _sss_storage
        return _sss_storage.user_data_dir(create=bool(create))
    except Exception:
        pass
    try:
        version = f"{int(bpy.app.version[0])}.{int(bpy.app.version[1])}"
    except Exception:
        version = '5.1'
    if os.name == 'nt':
        base = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming'))
        root = base / 'Blender Foundation' / 'Blender' / version / 'config' / _STORAGE_DIRNAME
    else:
        base = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config'))
        root = base / 'blender' / version / 'config' / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    try:
        from . import runtime
        path_fn = getattr(runtime, '_settings_json_path', None)
        if callable(path_fn):
            return Path(path_fn())
    except Exception:
        pass
    try:
        version = f"{int(bpy.app.version[0])}.{int(bpy.app.version[1])}"
    except Exception:
        version = '5.1'
    if os.name == 'nt':
        base = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming'))
        return base / 'Blender Foundation' / 'Blender' / version / 'config' / 'Smart_Shapekey_Suite' / 'Smart_Shapekey_Suite.json'
    base = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config'))
    return base / 'blender' / version / 'config' / 'Smart_Shapekey_Suite' / 'Smart_Shapekey_Suite.json'


def _load_previews():
    return None


def icon_value(name, fallback=0):
    del name
    return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    # Operator bl_label lookups use the 'Operator' i18n context, not '*';
    # mirror the curated entries there so operator names translate too.
    payload = dict(data)
    for key, ja in data.items():
        if isinstance(key, tuple) and len(key) == 2 and key[0] == '*':
            payload[('Operator', key[1])] = ja
    return {'ja_JP': payload}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


_HELP_TOPIC_ALIASES = {
    'overview': 'smart_shapekey_core',
    'SMART_SHAPEKEY_OT_set_always_on': 'always_on',
    'SKM_PT_view3d_root': 'smart_shapekey_core',
    'SKM_PT_view3d_mirror_settings': 'smart_shapekey_mirror_settings',
    'SKM_PT_view3d_modifiers': 'modifiers_group',
    'SKM_PT_view3d_drivers': 'drivers_group',
    'SKM_PT_view3d_control_tracking': 'control_tracking_group',
    'AMWSK_PT_smarttools_panel': 'apply_modifiers',
    'DRIVERHELPER_PT_smarttools_panel': 'driver_helper',
    'SHAPE_XY_PT_panel': 'shape_axis_control',
    'SHAPE_XY_PT_tracker_interface_panel': 'external_tracker',
    'SHAPE_XY_PT_tracker_panel': 'face_tracker',
}


def _resolve_help_topic(topic):
    value = str(topic or '').strip()
    return _HELP_TOPIC_ALIASES.get(value, value or 'smart_shapekey_core')


def _curated_help_module():
    try:
        from . import help as lazy_help
        return lazy_help
    except Exception:
        return None


def _help_popup_width(topic, context=None):
    help_module = _curated_help_module()
    resolved = _resolve_help_topic(topic)
    try:
        width_fn = getattr(help_module, 'popup_width', None) if help_module is not None else None
        if callable(width_fn):
            return int(width_fn(resolved, context))
    except Exception:
        pass
    return 760


def _draw_curated_help(layout, context, topic):
    help_module = _curated_help_module()
    resolved = _resolve_help_topic(topic)
    try:
        data = getattr(help_module, 'HELP_DATA', {}) if help_module is not None else {}
        if resolved not in data and str(topic or '') in data:
            resolved = str(topic or '')
        draw_fn = getattr(help_module, 'draw_help_popup', None) if help_module is not None else None
        if callable(draw_fn) and resolved in data:
            draw_fn(layout, context, resolved)
            return True
    except Exception as exc:
        box = layout.box()
        box.alert = True
        box.label(text=text('Help popup draw failed.', 'ヘルプポップアップの描画に失敗しました。', context), icon='ERROR')
        return True
    return False


def _exception_text(error, context=None) -> str:
    from .translation import exception_text
    return exception_text(error, context)


def _save_runtime_panel_settings(context=None):
    try:
        from . import runtime
        saver = getattr(runtime, 'save_current_panel_settings', None)
        if callable(saver):
            saver(context if context is not None else getattr(bpy, 'context', None))
            return True
    except Exception:
        pass
    return False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


class SMART_SHAPEKEY_OT_open_help(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the detailed help popup for this tool group.'

    topic: StringProperty(default='overview', options={'SKIP_SAVE'}, description='Internal help topic identifier used by the header help button.')

    def invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_popup(self, width=_help_popup_width(getattr(self, 'topic', ''), context))
        except Exception:
            return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = str(getattr(self, 'topic', '') or 'overview')
        if _draw_curated_help(layout, context, topic):
            return
        box = layout.box()
        box.alert = True
        box.label(text=text('Help content is not available for this tool.', 'このツールのヘルプ内容を利用できません。', context), icon='ERROR')


class SMART_SHAPEKEY_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'

    alias: StringProperty(default='', options={'SKIP_SAVE'}, description='Internal tool alias used to route the Always-on toggle to the correct feature set.')
    feature_key: StringProperty(default='', options={'SKIP_SAVE'}, description='Internal feature key identifying which Always-on function is being enabled or disabled.')
    enabled: BoolProperty(default=False, options={'SKIP_SAVE'}, description='Target enabled state for the selected Always-on feature.')

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception as exc:
                self.report({'WARNING'}, _exception_text(exc, context))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception as exc:
                self.report({'WARNING'}, _exception_text(exc, context))
        try:
            save_persistent_settings(context, force=True)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_SHAPEKEY_OT_save_preferences(bpy.types.Operator):
    _sms_no_undo = True
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_description = 'Save current N-panel settings to the Smart Shapekey folder in Blender CONFIG and request Blender to save user preferences.'

    def execute(self, context):
        _save_runtime_panel_settings(context)
        save_persistent_settings(context, force=True)
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}



def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = True
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            op.alias = alias
            op.feature_key = feature_key
            op.enabled = False
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    op.enabled = True
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    op.enabled = False


def save_persistent_settings(context=None, force=False):
    """Delegate to the authoritative strict runtime settings transaction."""
    try:
        from . import runtime
        saver = getattr(runtime, "save_current_panel_settings", None)
        if callable(saver):
            try:
                return bool(saver(context or getattr(bpy, "context", None), force=bool(force)))
            except TypeError:
                return bool(saver(context or getattr(bpy, "context", None)))
    except Exception:
        return False
    return False


def _retire_stale_always_on_property() -> bool:
    """Remove only the previous suite-owned BoolProperty descriptor."""
    owner = bpy.types.WindowManager
    try:
        direct = vars(owner).get(_ALWAYS_ON_PROP)
    except Exception:
        direct = None
    if direct is None:
        return False
    try:
        properties = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        prop = properties.get(_ALWAYS_ON_PROP) if properties is not None else None
        exact = bool(
            prop is not None
            and str(getattr(prop, 'identifier', '') or '') == _ALWAYS_ON_PROP
            and str(getattr(prop, 'type', '') or '') == 'BOOLEAN'
            and str(getattr(prop, 'name', '') or '') == _ALWAYS_ON_NAME
            and str(getattr(prop, 'description', '') or '') == _ALWAYS_ON_DESCRIPTION
            and int(getattr(prop, 'array_length', 0) or 0) == 0
            and bool(getattr(prop, 'default', False)) is False
        )
    except Exception:
        exact = False
    if not exact:
        return False
    delattr(owner, _ALWAYS_ON_PROP)
    try:
        remains = vars(owner).get(_ALWAYS_ON_PROP)
    except Exception:
        remains = None
    if remains is not None:
        raise RuntimeError(f'Could not retire stale {owner.__name__}.{_ALWAYS_ON_PROP}')
    return True


def register(ledger):
    """Register only this module's declared classes and one owned RNA property."""
    from . import lifecycle

    # Deterministic owner + unregister-first: clears the stale translations
    # cache left when an old installation's unregister was orphaned by a file
    # load (driver_namespace reset). A uuid-suffixed owner can never be
    # reclaimed once its ledger is lost.
    translation_owner = f"{PACKAGE_ID}.common"
    try:
        bpy.app.translations.unregister(translation_owner)
    except Exception:
        pass
    bpy.app.translations.register(translation_owner, _translation_payload())
    ledger.record(
        "translation",
        translation_owner,
        lambda owner=translation_owner: bpy.app.translations.unregister(owner),
        label=translation_owner,
        native_owner=bpy.app.translations,
    )
    try:
        direct = vars(bpy.types.WindowManager).get(_ALWAYS_ON_PROP)
    except Exception:
        direct = None
    if direct is not None and not _retire_stale_always_on_property():
        # Not an exact-signature match, but still residue this suite must
        # survive: an old installation's unregister can be orphaned by a file
        # load (driver_namespace reset), leaving its property attached with a
        # different name/description. Retire it forcibly; only a descriptor
        # that survives delattr is fatal.
        try:
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
        except Exception:
            pass
        try:
            remains = vars(bpy.types.WindowManager).get(_ALWAYS_ON_PROP)
        except Exception:
            remains = None
        if remains is not None:
            raise RuntimeError(
                f'RESTART_REQUIRED: stale RNA property could not be retired: '
                f'WindowManager.{_ALWAYS_ON_PROP}'
            )
    lifecycle.register_rna_property(
        ledger,
        bpy.types.WindowManager,
        _ALWAYS_ON_PROP,
        BoolProperty(
            name=_ALWAYS_ON_NAME,
            description=_ALWAYS_ON_DESCRIPTION,
            default=False,
        ),
    )
    for cls in COMMON_CLASSES:
        lifecycle.register_class(ledger, cls)


def unregister():
    """Resources are removed by the generation ledger; keep this idempotent."""
    _remove_previews()


COMMON_CLASSES = (
    SMART_SHAPEKEY_OT_open_help,
    SMART_SHAPEKEY_OT_set_always_on,
    SMART_SHAPEKEY_OT_save_preferences,
)
