# SPDX-License-Identifier: GPL-3.0-or-later
"""Public operations for editing, projecting and exporting independent expression maps."""
from pathlib import Path
import re
from mathutils import Vector
import bpy
from . import maps as m, map_file
from .apply_modifiers_with_shape_keys import functions as keygraph


def _shape_export(obj,ref,rows,overwrite):
    if not rows:raise ValueError('Select at least one expression.')
    if obj.mode!='OBJECT':raise ValueError('Use Object Mode to create shape keys.')
    originals=obj.data.shape_keys
    overrides={};appended=[]
    if not originals:appended.append(('Basis',m.absolute(ref,99)))
    names=set(originals.key_blocks.keys())if originals else {'Basis'}
    for row in rows:
        name=row.name;coords=m.absolute(ref,row.chn_id)
        if name in names and overwrite:overrides[name]=coords
        else:
            base=name;index=1
            while name in names:name=f'{base}.{index:03}';index+=1
            appended.append((name,coords));names.add(name)
    with keygraph._duplicate(bpy.context,obj) as staged:
        keygraph.rebuild_shape_key_graph(obj,staged,coordinate_overrides=overrides,appended_keys=appended,excluded_keys=(m.PREVIEW,) if obj.get('_smart_shape_preview') else ())
        obj.data=staged.data
    for k in ('_smart_shape_preview','_smart_shape_preview_index','_smart_shape_preview_solo'):
        if k in obj:del obj[k]


def _object_export(obj,ref,rows,op):
    if not rows:raise ValueError('Select one or more maps to export.')
    origin=getattr(op,'origin','ACTIVE')
    start=Vector((0,0,0))if origin=='WORLD' else bpy.context.scene.cursor.location.copy() if origin=='CURSOR' else obj.location.copy()
    spacing=getattr(op,'spacing',getattr(op,'offset',1.0));columns=max(1,getattr(op,'columns',getattr(op,'line',5)))
    if not hasattr(op,'origin'):start.x+=spacing
    made=[]
    try:
        for i,r in enumerate(rows):
            data=obj.data.copy();clone=bpy.data.objects.new(getattr(op,'prefix','')+r.name,data)
            made.append((clone,data));bpy.context.collection.objects.link(clone)
            if data.shape_keys:clone.shape_key_clear()
            for v,p in zip(data.vertices,m.absolute(ref,r.chn_id),strict=True):v.co=p
            clone.matrix_world=obj.matrix_world.copy()
            clone.location=start+Vector((i%columns*spacing,i//columns*spacing,0));data.update()
    except Exception:
        for clone,data in made:
            bpy.data.objects.remove(clone,do_unlink=True)
            if data.users==0:bpy.data.meshes.remove(data)
        raise


def uv_data(obj):
    if obj.mode!='OBJECT':raise ValueError('Switch to Object Mode for file exchange.')
    mesh=obj.data
    name=obj.get('skm_uv_map_name','')
    uv=mesh.uv_layers.get(name) if isinstance(name,str) and name else None
    uv=uv or mesh.uv_layers.active
    if not uv:raise ValueError('Choose a UV map.')
    mesh.calc_loop_triangles()
    return uv.name,[loop.vertex_index for loop in mesh.loops],[tuple(row.vector)for row in uv.uv],[list(t.loops)for t in mesh.loop_triangles]


def _load(obj,op):
    p=Path(bpy.path.abspath(op.filepath))
    header,source_uv,layers=map_file.decode(p)
    name,loops,uv,_=uv_data(obj)
    coords=m.current_coords(obj)
    output=map_file.project(header,source_uv,layers,loops,uv,coords)
    choices=getattr(op,'choices',None)
    keep={row.name for row in choices if getattr(row,'selected',True)}if choices else None
    filtered=[(i,r) for i,r in enumerate(header['maps'])if keep is None or r['name']in keep]
    if len(filtered)+len(obj.skm_maps)>99:raise ValueError('The file exceeds the available map channels.')
    ref=m.reference(obj)
    if not ref:ref=m.base(obj)
    m.store_layer(ref.data,99,output[0]);m.display(obj,output[0])
    for i,row in filtered:
        existing=next((r for r in obj.skm_maps if r.name==row['name'] and r.chn_id!=99),None)
        if existing:
            m.store_layer(ref.data,existing.chn_id,[Vector(p)-Vector(b)for p,b in zip(output[i+1],output[0])])
        else:m.create_row(obj,ref,row['name'],list(map(Vector,output[i+1])),row['chn_id'])
    m.pick(obj,0);obj['_smart_shape_map_path']=str(p)


def clipboard(context,obj,cmd,mirrored):
    points=m.current_coords(obj)
    if cmd=='copy_selected_verts':
        ids=sorted(m.selection(obj))
        if not ids:raise ValueError('Select vertices to copy.')
        context.window_manager['skm_clipboard']={'data':[[float(i),*points[i]]for i in ids]}
        return
    stored=context.window_manager.get('skm_clipboard')
    if not stored or not stored.get('data'):raise ValueError('Copy vertices first.')
    records=list(stored['data'])
    if any(len(row)!=4 or row[0]!=int(row[0]) or not 0<=int(row[0])<len(points) for row in records):
        raise ValueError('The copied vertices do not fit this mesh.')
    selected=set()
    for record in records:
        idx=int(record[0]);selected.add(idx);points[idx]=Vector(record[1:])
    if mirrored:
        ref=m.reference(obj)
        if not ref:raise ValueError('Set a Base for mirrored paste.')
        points=m.mirror(obj,ref,points,selected,None)
    m.display(obj,points)
    if m.reference(obj):
        ref,row=m.active(obj)
        if row.chn_id!=99:m.commit(obj,ref,row.chn_id)


def remove_orphan_channels(obj):
    ref=m.reference(obj)
    if not ref:return
    used={r.chn_id for r in obj.skm_maps}
    for uv in list(ref.data.uv_layers):
        match=re.fullmatch(r'SKM_CH([0-9]{1,2})_[AB]',uv.name)
        if match and int(match[1]) not in used:ref.data.uv_layers.remove(uv)
    for layer in list(ref.data.attributes):
        match=re.fullmatch(r'\.skm_morphmapper_delta_([0-9]{1,2})',layer.name)
        if match and int(match[1]) not in used:ref.data.attributes.remove(layer)


def operate(context,op):
    cmd=op.bl_idname.lower().replace('_ot_', '.').rsplit('.', 1)[-1]
    obj=m.checked(context.active_object)
    if cmd=='set_base':m.base(obj,op.selected_polygons or (op.dialog_invoked and op.dialog_range=='SELECTED'));return
    if cmd in ('load_file','load_choose'):_load(obj,op);return
    if cmd in ('copy_selected_verts','paste_verts'):
        clipboard(context,obj,cmd,getattr(op,'mirrored',False));return
    if cmd=='mirror_settings':return
    if cmd in ('clean_orphans','full_cleanup'):
        if cmd=='full_cleanup':
            for owner in list(context.scene.objects)if op.scene_wide else [obj]:
                if owner.type=='MESH' and owner.get(m.REFERENCE):m.cleanup(owner)
        else:
            for source in list(context.scene.objects) if op.scene_wide else [obj]:
                if source.type=='MESH' and source.get(m.REFERENCE):remove_orphan_channels(source)
            linked={o.get(m.REFERENCE)for o in bpy.data.objects if o.get(m.REFERENCE)}
            for owner in list(bpy.data.objects):
                if owner.get('_smart_shape_source_id') and owner.name not in linked and (op.scene_wide or owner.get('_smart_shape_source_id')==obj.get(m.OWNER)):
                    data=owner.data;bpy.data.objects.remove(owner,do_unlink=True)
                    if data.users==0:bpy.data.meshes.remove(data)
        return
    if cmd=='import_shape_keys':
        keys=obj.data.shape_keys
        if not keys:raise ValueError('The selected mesh has no shape keys.')
        ref=m.reference(obj) or m.base(obj)
        for block in list(keys.key_blocks):
            if block==keys.reference_key or block.name==m.PREVIEW:continue
            coords=[v.co.copy()for v in block.data]
            existing=next((r for r in obj.skm_maps if r.name==block.name and r.chn_id!=99),None)
            if existing and op.replace_owned:m.store_layer(ref.data,existing.chn_id,[p-b for p,b in zip(coords,m.read_layer(ref.data,99))])
            elif not existing:m.create_row(obj,ref,block.name,coords)
        return
    ref,row=m.active(obj);cid=row.chn_id;basis=m.read_layer(ref.data,99)
    if cmd=='new_map':
        index=m.create_row(obj,ref,op.map_name,m.current_coords(obj));m.pick(obj,index);return
    if cmd in ('save_file','save_overwrite'):
        m.commit(obj,ref,cid)
        path=op.filepath or obj.get('_smart_shape_map_path','')
        if not path:raise ValueError('Choose where to save the map file.')
        name,loops,uv,tri=uv_data(obj)
        rows=m.selected_rows(obj,'SELECTED'if op.selected_only else 'ALL')
        if not rows:raise ValueError('Choose at least one expression to save.')
        map_file.save(bpy.path.abspath(path),name,loops,uv,tri,m.read_layer(ref.data,99),[(r.name,r.chn_id,m.absolute(ref,r.chn_id))for r in rows]);obj['_smart_shape_map_path']=path;return
    if cmd.startswith('export_'):
        m.commit(obj,ref,cid);rows=m.selected_rows(obj,getattr(op,'target','SELECTED'if obj.skm_edit_mode else 'ALL'))
        if cmd=='export_objects' or getattr(op,'output','')=='OBJECT':_object_export(obj,ref,rows,op)
        else:
            m.display(obj,basis)
            m.pick(obj,0)
            _shape_export(obj,ref,rows,getattr(op,'overwrite_existing',getattr(op,'replace_matching',False)))
        return
    if cmd in ('order_maps','move_map'):
        if not obj.skm_edit_mode:raise ValueError('Switch the list to Edit mode.')
        if cmd=='move_map':
            i=obj.skm_edit_index;new=i+(-1 if op.direction=='UP' else 1)
            if min(i,new)<1 or max(i,new)>=len(obj.skm_maps):raise ValueError('The row cannot be moved further.')
            obj.skm_maps.move(i,new);obj.skm_edit_index=new
        else:
            ordered=sorted(list(obj.skm_maps)[1:],key=(lambda r:r.name.casefold()) if op.mode=='NAME' else lambda r:-r.chn_id)
            for idx,channel in enumerate([r.chn_id for r in ordered],1):
                pos=next(i for i,r in enumerate(obj.skm_maps)if r.chn_id==channel);obj.skm_maps.move(pos,idx)
        m.pick(obj,next(i for i,r in enumerate(obj.skm_maps)if r.chn_id==cid));return
    if cid==99:raise ValueError('Choose an expression instead of Base.')
    if cmd=='store_map' and not(op.clear_all or op.clear_selected):
        m.commit(obj,ref,cid,m.selection(obj,True) if op.selected_polygons else None);return
    coords=m.current_coords(obj)
    if cmd=='rename_map':
        name=op.map_name.strip()
        if not name or name in {r.name for r in obj.skm_maps if r.chn_id!=cid}:raise ValueError('Choose a unique expression name.')
        row.name=name;row.prev_name=name;return
    if cmd=='duplicate_map':
        new=[b-(p-b) if op.inverted else p.copy()for p,b in zip(coords,basis)]
        index=m.create_row(obj,ref,'NewMap',new);m.pick(obj,index);m.display(obj,new);return
    if cmd=='delete_map':
        name=m.layer_name(cid);i=next(i for i,r in enumerate(obj.skm_maps)if r.chn_id==cid)
        with m.quiet(obj):obj.skm_maps.remove(i);m.pick(obj,0)
        ref.data.attributes.remove(ref.data.attributes[name]);m.display(obj,basis);return
    faces=cmd in ('clear_map','store_map');ids=m.selection(obj,faces)
    if cmd in ('clear_map','store_map'):
        if getattr(op,'target_range',None)=='ALL' or getattr(op,'clear_all',False):ids=range(len(coords))
        if not ids:raise ValueError('Select one or more faces.')
        for i in ids:coords[i]=basis[i].copy()
    elif cmd=='invert_selected':
        if not ids:raise ValueError('Select vertices to invert.')
        for i in ids:coords[i]=basis[i]-(coords[i]-basis[i])
    elif cmd=='mirror_selected':coords=m.mirror(obj,ref,coords,ids,op.direction)
    else:raise ValueError('Unsupported map command: '+cmd)
    m.display(obj,coords);m.commit(obj,ref,cid)
