# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shape Axis registration and event-driven frame synchronization."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import threading

import bpy

from .. import activity as _activity
from .. import lifecycle as _lifecycle
try:
    from .. import translation as _translation
except Exception:
    _translation = None

from .core import state
from .core import main as core
from .ui import properties
from .ui import draw
from .operators import main as operators
from .ui import panel as ui
from .interface import tracker as interface_tracker
from . import face_tracker


def _is_japanese_locale(context=None) -> bool:
    try:
        return bool(_translation is not None and _translation.is_japanese_locale(context))
    except Exception:
        return False


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _translation is not None:
            return _translation.ui_text(en, ja, context)
    except Exception:
        pass
    return ja if _is_japanese_locale(context) else en


def _persistent_default(key: str, default):
    try:
        from .. import runtime
        return runtime.get_persistent_setting(key, default)
    except Exception:
        return default


def _save_scene_runtime_setting(prop_name: str, value) -> None:
    try:
        from .. import runtime
        runtime.save_scene_runtime_setting(prop_name, value)
    except Exception:
        pass


classes = (
    properties.SHAPE_XY_PG_item,
    properties.SHAPE_XY_PG_preset_state,
    properties.SHAPE_XY_PG_preset,
    properties.SHAPE_XY_PG_group,
    operators.SHAPE_XY_OT_edit_values,
    operators.SHAPE_XY_OT_reset_handle,
    operators.SHAPE_XY_OT_reset_all,
    operators.SHAPE_XY_OT_keyframe_handle,
    operators.SHAPE_XY_OT_bake_animation,
    operators.SHAPE_XY_OT_export_group,
    operators.SHAPE_XY_OT_import_group,
    operators.SHAPE_XY_OT_reset_hud,
    operators.SHAPE_XY_OT_ui_joystick,
    operators.SHAPE_XY_OT_move_item,
    operators.SHAPE_XY_OT_mirror_mappings,
    operators.SHAPE_XY_OT_move_group,
    operators.SHAPE_XY_OT_move_preset,
    operators.SHAPE_XY_OT_add_preset,
    operators.SHAPE_XY_OT_remove_preset,
    operators.SHAPE_XY_OT_set_preset,
    operators.SHAPE_XY_OT_call_preset,
    operators.SHAPE_XY_OT_keyframe_preset,
    ui.SHAPE_XY_UL_group_list,
    ui.SHAPE_XY_UL_list,
    ui.SHAPE_XY_UL_preset_list,
    ui.SHAPE_XY_OT_add_group,
    ui.SHAPE_XY_OT_remove_group,
    ui.SHAPE_XY_OT_add,
    ui.SHAPE_XY_OT_remove,
)

_FRAME_SYNC_PROP = 'shape_xy_enable_frame_sync'
_FRAME_SYNC_NAME = _ui_text('Frame Sync', 'フレーム同期')
_FRAME_SYNC_DESCRIPTION = _ui_text(
    'Update only Shape Axis groups that have animation channels, plus objects reported dirty by the depsgraph. No per-frame object scan is performed. Disable it when timeline synchronization is not needed; all owned handlers are then removed.',
    'アニメーションチャンネルを持つシェイプ軸グループと、依存グラフが変更を通知したオブジェクトだけを更新します。毎フレームの全オブジェクト走査は行いません。不要なときは無効にすると所有ハンドラーをすべて解除します。',
)
_ALLOW_DRAG_NAME = _ui_text('Enable Drag Point', 'ポイントドラッグを有効化')
_ALLOW_DRAG_DESCRIPTION = _ui_text(
    'Allow direct mapping-point dragging in the Axis HUD. This option alone starts no timer, thread, socket, handler, or draw callback.',
    'シェイプ軸 HUD 内のマッピング点を直接ドラッグできるようにします。この設定だけではタイマー、スレッド、ソケット、ハンドラー、描画コールバックを開始しません。',
)


@dataclass(frozen=True, slots=True)
class _FrameTarget:
    object_name: str
    group_name: str


FRAME_MAX_TARGETS = 8192
FRAME_MAX_DIRTY_OBJECTS = 2048
FRAME_DIRTY_PER_TICK = 32

_FRAME_LOCK = threading.RLock()
_FRAME_TARGETS: dict[tuple[str, str], _FrameTarget] = {}
_FRAME_OBJECT_KEYS: dict[str, set[tuple[str, str]]] = {}
_FRAME_DIRTY: set[str] = set()
_FRAME_LEASE = None
_FRAME_INDEX_REBUILDS = 0
_FRAME_DIRTY_REINDEXES = 0
_FRAME_TICKS = 0
_FRAME_UPDATES = 0
_FRAME_TARGET_OVERFLOW = 0
_FRAME_DIRTY_OVERFLOW = 0


def _frame_sync_enabled(scene=None) -> bool:
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    return bool(scene is not None and getattr(scene, _FRAME_SYNC_PROP, False))


def _groups(obj) -> tuple[Any, ...]:
    try:
        value = getattr(obj, 'shape_xy_groups', None)
        return tuple(value) if value else ()
    except Exception:
        return ()


def _object_animation_paths(obj) -> frozenset[str]:
    """Collect animation paths only at enable/depsgraph-dirty boundaries."""
    paths: set[str] = set()
    animation_data = getattr(obj, 'animation_data', None)
    action = getattr(animation_data, 'action', None) if animation_data is not None else None
    for curve in tuple(getattr(action, 'fcurves', ()) or ()):
        path = str(getattr(curve, 'data_path', '') or '')
        if path:
            paths.add(path)
    for curve in tuple(getattr(animation_data, 'drivers', ()) or ()) if animation_data is not None else ():
        path = str(getattr(curve, 'data_path', '') or '')
        if path:
            paths.add(path)
    for track in tuple(getattr(animation_data, 'nla_tracks', ()) or ()) if animation_data is not None else ():
        for strip in tuple(getattr(track, 'strips', ()) or ()):
            strip_action = getattr(strip, 'action', None)
            for curve in tuple(getattr(strip_action, 'fcurves', ()) or ()):
                path = str(getattr(curve, 'data_path', '') or '')
                if path:
                    paths.add(path)
    return frozenset(paths)


def _animated_groups(obj) -> tuple[Any, ...]:
    paths = _object_animation_paths(obj)
    if not paths:
        return ()
    out = []
    for group in _groups(obj):
        try:
            x_path = str(group.path_from_id('joy_x'))
            y_path = str(group.path_from_id('joy_y'))
        except Exception:
            continue
        if x_path in paths or y_path in paths:
            out.append(group)
    return tuple(out)


def _reindex_frame_object(obj, *, object_name: str = '') -> None:
    global _FRAME_DIRTY_REINDEXES, _FRAME_TARGET_OVERFLOW
    name = str(getattr(obj, 'name', '') or object_name or '')
    if not name:
        return
    targets: list[_FrameTarget] = []
    if getattr(obj, 'type', None) == 'MESH':
        for group in _animated_groups(obj):
            group_name = str(getattr(group, 'name', '') or '')
            if group_name:
                targets.append(_FrameTarget(name, group_name))
    with _FRAME_LOCK:
        for key in tuple(_FRAME_OBJECT_KEYS.pop(name, ())):
            _FRAME_TARGETS.pop(key, None)
        object_keys: set[tuple[str, str]] = set()
        for target in targets:
            key = (target.object_name, target.group_name)
            if key in _FRAME_TARGETS or len(_FRAME_TARGETS) < FRAME_MAX_TARGETS:
                _FRAME_TARGETS[key] = target
                object_keys.add(key)
            else:
                _FRAME_TARGET_OVERFLOW += 1
        if object_keys:
            _FRAME_OBJECT_KEYS[name] = object_keys
        _FRAME_DIRTY_REINDEXES += 1


def _build_frame_target_index(scene=None) -> None:
    """One explicit enable/load-post scan; never called from frame/draw callbacks."""
    global _FRAME_INDEX_REBUILDS, _FRAME_DIRTY_REINDEXES, _FRAME_TARGET_OVERFLOW, _FRAME_DIRTY_OVERFLOW
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    try:
        objects = tuple(getattr(scene, 'objects', ()) or ()) if scene is not None else ()
    except Exception:
        objects = ()
    targets: dict[tuple[str, str], _FrameTarget] = {}
    reverse: dict[str, set[tuple[str, str]]] = {}
    for obj in objects:
        if getattr(obj, 'type', None) != 'MESH':
            continue
        name = str(getattr(obj, 'name', '') or '')
        if not name:
            continue
        for group in _animated_groups(obj):
            group_name = str(getattr(group, 'name', '') or '')
            if group_name:
                key = (name, group_name)
                if key in targets or len(targets) < FRAME_MAX_TARGETS:
                    targets[key] = _FrameTarget(name, group_name)
                    reverse.setdefault(name, set()).add(key)
                else:
                    _FRAME_TARGET_OVERFLOW += 1
    with _FRAME_LOCK:
        _FRAME_TARGETS.clear()
        _FRAME_TARGETS.update(targets)
        _FRAME_OBJECT_KEYS.clear()
        _FRAME_OBJECT_KEYS.update(reverse)
        _FRAME_DIRTY.clear()
        _FRAME_INDEX_REBUILDS += 1
        _FRAME_DIRTY_REINDEXES = 0
        _FRAME_DIRTY_OVERFLOW = 0


def _frame_depsgraph_dirty(_scene, depsgraph) -> None:
    global _FRAME_DIRTY_OVERFLOW
    try:
        updates = tuple(getattr(depsgraph, 'updates', ()) or ())
    except Exception:
        updates = ()
    names: set[str] = set()
    for update in updates:
        value = getattr(update, 'id', None)
        if isinstance(value, bpy.types.Object):
            name = str(getattr(value, 'name', '') or '')
            if name:
                names.add(name)
    if names:
        with _FRAME_LOCK:
            for name in names:
                if name in _FRAME_DIRTY or len(_FRAME_DIRTY) < FRAME_MAX_DIRTY_OBJECTS:
                    _FRAME_DIRTY.add(name)
                else:
                    _FRAME_DIRTY_OVERFLOW += 1


def _drain_frame_dirty(limit: int = 32) -> None:
    names: list[str] = []
    with _FRAME_LOCK:
        while _FRAME_DIRTY and len(names) < max(1, int(limit)):
            names.append(_FRAME_DIRTY.pop())
    for name in names:
        try:
            obj = bpy.data.objects.get(name)
        except Exception:
            obj = None
        _reindex_frame_object(obj, object_name=name)


def _resolve_target(target: _FrameTarget):
    try:
        obj = bpy.data.objects.get(target.object_name)
    except Exception:
        obj = None
    if obj is None:
        return None, None
    groups = getattr(obj, 'shape_xy_groups', None)
    if groups is None:
        return obj, None
    getter = getattr(groups, 'get', None)
    if callable(getter):
        try:
            return obj, getter(target.group_name)
        except Exception:
            pass
    finder = getattr(groups, 'find', None)
    if callable(finder):
        try:
            index = int(finder(target.group_name))
            return obj, groups[index] if index >= 0 else None
        except Exception:
            pass
    return obj, None


def frame_handler(scene, depsgraph=None):
    """Compatibility callback; dynamically wrapped by the activity generation."""
    del depsgraph
    global _FRAME_TICKS, _FRAME_UPDATES
    if not _frame_sync_enabled(scene):
        return None
    _drain_frame_dirty(limit=FRAME_DIRTY_PER_TICK)
    with _FRAME_LOCK:
        targets = tuple(_FRAME_TARGETS.values())
    updates = 0
    for target in targets:
        obj, group = _resolve_target(target)
        if obj is None or group is None:
            continue
        try:
            core.update_shapes(obj, group, core.get_limit(group))
            updates += 1
        except Exception:
            continue
    _FRAME_TICKS += 1
    _FRAME_UPDATES += updates
    return None


def start_frame_sync(scene=None) -> bool:
    global _FRAME_LEASE
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None or not _frame_sync_enabled(scene):
        stop_frame_sync()
        return False
    lease = _activity.get_lease('axis_frame_sync')
    if lease is not None and lease.state == 'ACTIVE':
        return True
    _build_frame_target_index(scene)
    lease = _activity.new_lease('axis_frame_sync', replace=True)
    _activity.add_handler(lease, bpy.app.handlers.depsgraph_update_post, _frame_depsgraph_dirty, label='Axis frame-sync dirty index')
    _activity.add_handler(lease, bpy.app.handlers.frame_change_post, frame_handler, label='Axis frame-sync update')
    _FRAME_LEASE = lease
    return True


def stop_frame_sync() -> bool:
    global _FRAME_LEASE
    ok = _activity.teardown_feature('axis_frame_sync')
    if ok:
        _FRAME_LEASE = None
        with _FRAME_LOCK:
            _FRAME_TARGETS.clear()
            _FRAME_OBJECT_KEYS.clear()
            _FRAME_DIRTY.clear()
    return ok


def clear_runtime_cache() -> None:
    """Clear event-derived indexes after the exact handlers have stopped."""
    lease = _activity.get_lease('axis_frame_sync')
    if lease is not None and lease.state == 'ACTIVE':
        return
    with _FRAME_LOCK:
        _FRAME_TARGETS.clear()
        _FRAME_OBJECT_KEYS.clear()
        _FRAME_DIRTY.clear()


def _allow_drag_update(self, _context):
    _save_scene_runtime_setting('shape_xy_allow_drag', bool(getattr(self, 'shape_xy_allow_drag', False)))


def _frame_sync_update(self, _context):
    enabled = bool(getattr(self, _FRAME_SYNC_PROP, False))
    _save_scene_runtime_setting(_FRAME_SYNC_PROP, enabled)
    if enabled:
        start_frame_sync(self)
    else:
        stop_frame_sync()


def set_frame_sync_enabled(enabled: bool, scene=None):
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        stop_frame_sync()
        return False
    try:
        current = bool(getattr(scene, _FRAME_SYNC_PROP, False))
        if current != bool(enabled):
            setattr(scene, _FRAME_SYNC_PROP, bool(enabled))
        elif enabled:
            start_frame_sync(scene)
        else:
            stop_frame_sync()
        return bool(enabled is False or start_frame_sync(scene))
    except Exception:
        stop_frame_sync()
        return False


def refresh_frame_sync_registration(scene=None):
    if _frame_sync_enabled(scene):
        return start_frame_sync(scene)
    return stop_frame_sync()


def frame_sync_audit_snapshot() -> dict[str, Any]:
    with _FRAME_LOCK:
        targets = len(_FRAME_TARGETS)
        dirty = len(_FRAME_DIRTY)
    lease = _activity.get_lease('axis_frame_sync')
    return {
        'active': bool(lease is not None and lease.state == 'ACTIVE'),
        'target_count': targets,
        'dirty_count': dirty,
        'index_rebuilds': _FRAME_INDEX_REBUILDS,
        'dirty_reindexes': _FRAME_DIRTY_REINDEXES,
        'frame_ticks': _FRAME_TICKS,
        'target_updates': _FRAME_UPDATES,
        'target_overflow': _FRAME_TARGET_OVERFLOW,
        'dirty_overflow': _FRAME_DIRTY_OVERFLOW,
        'limits': {
            'targets': FRAME_MAX_TARGETS,
            'dirty_objects': FRAME_MAX_DIRTY_OBJECTS,
            'dirty_per_tick': FRAME_DIRTY_PER_TICK,
        },
    }


def register(ledger):
    for cls in classes:
        _lifecycle.register_class(ledger, cls)
    lp = _lifecycle.register_rna_property
    lp(ledger, bpy.types.Scene, 'shape_xy_allow_drag', bpy.props.BoolProperty(
        name=_ALLOW_DRAG_NAME,
        default=bool(_persistent_default('axis_point_drag_enabled', False)),
        description=_ALLOW_DRAG_DESCRIPTION,
        update=_allow_drag_update,
    ))
    lp(ledger, bpy.types.Scene, _FRAME_SYNC_PROP, bpy.props.BoolProperty(
        name=_FRAME_SYNC_NAME,
        default=bool(_persistent_default('always_frame_sync_enabled', False)),
        description=_FRAME_SYNC_DESCRIPTION,
        update=_frame_sync_update,
    ))
    lp(ledger, bpy.types.Object, 'shape_xy_groups', bpy.props.CollectionProperty(
        type=properties.SHAPE_XY_PG_group,
        description=_ui_text('Shape Axis groups stored on this object.', 'このオブジェクトに保存するシェイプ軸グループです。'),
    ))
    lp(ledger, bpy.types.Object, 'shape_xy_group_index', bpy.props.IntProperty(
        default=-1,
        description=_ui_text('Active Shape Axis group index.', '現在のシェイプ軸グループ番号です。'),
        update=properties.on_property_update,
    ))
    lp(ledger, bpy.types.Scene, 'shape_xy_presets', bpy.props.CollectionProperty(
        type=properties.SHAPE_XY_PG_preset,
        description=_ui_text('Global Shape Axis presets stored with the scene.', 'シーンに保存するグローバルシェイプ軸プリセットです。'),
    ))
    lp(ledger, bpy.types.Scene, 'shape_xy_preset_index', bpy.props.IntProperty(
        default=-1,
        description=_ui_text('Active global Shape Axis preset index.', '現在のグローバルシェイプ軸プリセット番号です。'),
        update=properties.on_preset_change,
    ))
    interface_tracker.register(ledger)
    face_tracker.register(ledger)


def unregister():
    stop_frame_sync()
    try:
        operators.stop_axis_hud()
    except Exception:
        pass
    interface_tracker.unregister()
    face_tracker.unregister()
    try:
        draw.clear_snapshot()
    except Exception:
        pass


if __name__ == '__main__':
    raise RuntimeError('Smart Shapekey Suite must be registered as a Blender Extension')
