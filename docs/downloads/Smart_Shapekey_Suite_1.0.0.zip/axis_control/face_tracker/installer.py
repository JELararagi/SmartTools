# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Explicit, generation-scoped dependency installer for Face Tracker.

No installer worker, process, timer, file probe, or network activity exists while
Face Tracker installation is idle.  Runtime resources are owned by one
``activity.ActivityLease`` and are torn down by exact identity.  Process pipes
are closed and the process is terminated before the worker join is attempted;
references are retained until the join has actually completed.
"""
from __future__ import annotations

from collections import deque
import importlib.machinery
import importlib.util
import os
import subprocess
import sys
import threading
import time
from typing import Any

import bpy

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None


_STATUS_MAX_ITEMS = 32
_STATUS_TICK_MAX_ITEMS = 8
_STATUS_TICK_BUDGET_SECONDS = 0.002
_INSTALL_JOIN_TIMEOUT_SECONDS = 3.0
_INSTALL_FEATURE = "face_installer"

_STATE_LOCK = threading.RLock()
_STATUS_LOCK = threading.RLock()
_STATUS_ITEMS: deque[dict[str, str]] = deque(maxlen=_STATUS_MAX_ITEMS)
_STATUS_DROPPED = 0
_INSTALL_THREAD: threading.Thread | None = None
_INSTALL_PROCESS: subprocess.Popen[str] | None = None
_INSTALL_STOP_EVENT: threading.Event | None = None
_INSTALL_LEASE = None
_LAST_REPORT_SIGNATURE = ""
_LAST_ERROR = ""

# A bounded scalar cache.  UI draw reads this only; explicit register/operator
# boundaries refresh it, so panel drawing never probes the filesystem.
_DEPENDENCY_CACHE: dict[str, object] = {
    "ready": False,
    "checked": False,
    "stamp": 0.0,
}


def _activity_module():
    from ... import activity
    return activity


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, "preferences", None), "view", None)
    if view is None:
        prefs = getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
    language = str(getattr(view, "language", "DEFAULT") or "DEFAULT").upper()
    return language.startswith("JA")


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _extension_user_dir(*parts: str, create: bool = False) -> str:
    try:
        from ... import runtime
        helper = getattr(runtime, "extension_user_dir", None)
        if callable(helper):
            return helper(*parts, create=bool(create))
    except Exception:
        pass
    try:
        from ... import storage as _sss_storage
        return str(_sss_storage.user_default_root(*parts, package_id="smart_shapekey_suite", create=bool(create)))
    except Exception:
        pass
    base = ""
    try:
        base = bpy.utils.user_resource("CONFIG", path="", create=bool(create)) or ""
    except Exception:
        base = ""
    if not base:
        try:
            version = f"{int(bpy.app.version[0])}.{int(bpy.app.version[1])}"
        except Exception:
            version = "5.1"
        if os.name == "nt" and os.environ.get("APPDATA"):
            base = os.path.join(os.environ["APPDATA"], "Blender Foundation", "Blender", version, "config")
        else:
            base = os.path.join(
                os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config"),
                "blender",
                version,
                "config",
            )
    base = os.path.join(base, "Smart_Shapekey_Suite")
    if parts:
        base = os.path.join(base, *parts)
    if create:
        os.makedirs(base, exist_ok=True)
    return base


def dependency_target_dir(create: bool = False) -> str:
    return _extension_user_dir("python_modules", create=bool(create))


def ensure_dependency_target_on_path() -> str:
    target = dependency_target_dir(create=False)
    if target and target not in sys.path:
        sys.path.insert(0, target)
    return target


def _status_text(key: str, detail: str = "", context=None) -> str:
    if key == "installing":
        return _ui_text("Installing (this may take a few minutes)...", "インストール中です（数分かかる場合があります）...", context)
    if key == "cancelled":
        return _ui_text("Installation was cancelled.", "インストールをキャンセルしました。", context)
    if key == "success":
        return _ui_text("Installed successfully.", "インストールに成功しました。", context)
    if key == "failed":
        if detail:
            return _ui_text(f"Installation failed: {detail}", f"インストールに失敗しました: {detail}", context)
        return _ui_text("Installation failed.", "インストールに失敗しました。", context)
    if key == "error":
        if detail:
            return _ui_text(f"Error: {detail}", f"エラー: {detail}", context)
        return _ui_text("An unexpected error occurred.", "予期しないエラーが発生しました。", context)
    return str(detail or "")


class SHAPE_XY_OT_report_message(bpy.types.Operator):
    bl_idname = "shape_xy.report_message"
    bl_label = _ui_text("Report Message", "報告メッセージ")
    bl_description = _ui_text(
        "Show the latest Face Tracker dependency or installation message.",
        "フェイストラッカー の依存関係やインストール結果の最新メッセージを表示します。",
    )

    message: bpy.props.StringProperty(
        description=_ui_text(
            "Message text shown in Blender Info Log after a dependency installation result is reported.",
            "依存関係インストール結果を報告するときに、Blender の情報ログへ表示するメッセージ本文です。",
        ),
        options={"HIDDEN"},
    )
    msg_type: bpy.props.StringProperty(
        default="ERROR",
        description=_ui_text(
            "Internal report type used for dependency installation messages, such as INFO or ERROR.",
            "依存関係インストールメッセージに使う内部報告種別です。INFO や ERROR などを指定します。",
        ),
        options={"HIDDEN"},
    )

    def execute(self, context):
        message = str(self.message or "").strip()
        if not message:
            return {"CANCELLED"}
        report_type = str(self.msg_type or "INFO").upper()
        allowed = {
            "DEBUG", "INFO", "OPERATOR", "PROPERTY", "WARNING", "ERROR",
            "ERROR_INVALID_INPUT", "ERROR_INVALID_CONTEXT", "ERROR_OUT_OF_MEMORY",
        }
        if report_type not in allowed:
            report_type = "INFO"
        self.report({report_type}, message)
        return {"FINISHED"}


def _queue_status(
    status_key: str,
    detail: str = "",
    report_type: str = "",
    report_key: str = "",
    report_detail: str = "",
) -> None:
    global _STATUS_DROPPED
    payload = {
        "status_key": str(status_key or ""),
        "detail": str(detail or "")[:800],
        "report_type": str(report_type or ""),
        "report_key": str(report_key or ""),
        "report_detail": str(report_detail or "")[:800],
    }
    with _STATUS_LOCK:
        # Coalesce consecutive status updates with the same semantic key.
        if _STATUS_ITEMS and _STATUS_ITEMS[-1].get("status_key") == payload["status_key"]:
            _STATUS_ITEMS[-1] = payload
            return
        if len(_STATUS_ITEMS) >= _STATUS_MAX_ITEMS:
            _STATUS_DROPPED += 1
        _STATUS_ITEMS.append(payload)


def _pop_status() -> dict[str, str] | None:
    with _STATUS_LOCK:
        if not _STATUS_ITEMS:
            return None
        return _STATUS_ITEMS.popleft()


def _has_status() -> bool:
    with _STATUS_LOCK:
        return bool(_STATUS_ITEMS)


def _worker_alive() -> bool:
    with _STATE_LOCK:
        thread = _INSTALL_THREAD
    return bool(thread is not None and thread.is_alive())


def _drain_install_status_queue():
    """Bounded UI-thread status delivery.  Never drains without a budget."""
    global _LAST_REPORT_SIGNATURE, _LAST_ERROR
    started = time.perf_counter()
    processed = 0
    while processed < _STATUS_TICK_MAX_ITEMS and (time.perf_counter() - started) < _STATUS_TICK_BUDGET_SECONDS:
        payload = _pop_status()
        if payload is None:
            break
        processed += 1
        status_key = payload["status_key"]
        detail = payload["detail"]
        scene = getattr(getattr(bpy, "context", None), "scene", None)
        if scene is not None and hasattr(scene, "tracker_install_status"):
            try:
                scene.tracker_install_status = _status_text(status_key, detail, bpy.context)
            except Exception:
                pass

        report_type = payload["report_type"]
        report_key = payload["report_key"]
        if report_type and report_key:
            report_message = _status_text(report_key, payload["report_detail"], bpy.context)[:800]
            signature = f"{report_type}:{report_message}"
            if signature != _LAST_REPORT_SIGNATURE:
                _LAST_REPORT_SIGNATURE = signature
                try:
                    bpy.ops.shape_xy.report_message(
                        "EXEC_DEFAULT",
                        message=report_message,
                        msg_type=report_type,
                    )
                except Exception as exc:
                    # Never emit raw console output.  Retain one bounded audit value.
                    _LAST_ERROR = f"report:{type(exc).__name__}:{exc}"[:800]

    if _worker_alive() or _has_status():
        return 0.1
    return None


def invalidate_dependency_cache() -> None:
    _DEPENDENCY_CACHE["ready"] = False
    _DEPENDENCY_CACHE["checked"] = False
    _DEPENDENCY_CACHE["stamp"] = 0.0


def is_installed(package_name: str) -> bool:
    """Explicit filesystem/import probe; never called by panel draw implicitly."""
    package_name = str(package_name or "").strip()
    if not package_name:
        return False
    target = dependency_target_dir(create=False)
    try:
        if target and importlib.machinery.PathFinder.find_spec(package_name, [target]) is not None:
            return True
    except Exception:
        pass
    try:
        return importlib.util.find_spec(package_name) is not None
    except Exception:
        return False


def refresh_dependency_cache() -> bool:
    ready = bool(is_installed("cv2") and is_installed("mediapipe"))
    _DEPENDENCY_CACHE["ready"] = ready
    _DEPENDENCY_CACHE["checked"] = True
    _DEPENDENCY_CACHE["stamp"] = time.perf_counter()
    return ready


def check_dependencies(force: bool = False) -> bool:
    # `force=False` is a pure cached read suitable for Panel.draw.
    if force:
        return refresh_dependency_cache()
    return bool(_DEPENDENCY_CACHE.get("ready", False))


def _close_process_io_and_terminate(process: subprocess.Popen[str] | None) -> None:
    if process is None:
        return
    for stream_name in ("stdin", "stdout", "stderr"):
        stream = getattr(process, stream_name, None)
        if stream is not None:
            try:
                stream.close()
            except Exception:
                pass
    try:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=1.0)
            except Exception:
                process.kill()
                try:
                    process.wait(timeout=1.0)
                except Exception:
                    pass
    except Exception:
        pass


def _join_install_thread(thread: threading.Thread) -> None:
    stop_event = _INSTALL_STOP_EVENT
    if stop_event is not None:
        stop_event.set()
    with _STATE_LOCK:
        process = _INSTALL_PROCESS
    _close_process_io_and_terminate(process)
    if thread is threading.current_thread():
        return
    # ``track_thread`` journals before ``start`` so registration/start faults can
    # roll back safely without calling ``join`` on a never-started Thread.
    if thread.ident is None and not thread.is_alive():
        return
    thread.join(timeout=_INSTALL_JOIN_TIMEOUT_SECONDS)
    if thread.is_alive():
        # Preserve the handle in the lease/globals; teardown may be retried.
        raise RuntimeError("Face dependency installer worker did not stop")


def _install_worker(target: str, cache_dir: str, tmp_dir: str, stop_event: threading.Event, lease) -> None:
    global _INSTALL_PROCESS, _LAST_ERROR
    invalidate_dependency_cache()
    _queue_status("installing")
    process: subprocess.Popen[str] | None = None
    try:
        for path in (target, cache_dir, tmp_dir):
            if stop_event.is_set():
                _queue_status("cancelled")
                return
            os.makedirs(path, exist_ok=True)
        env = os.environ.copy()
        env["PYTHONNOUSERSITE"] = "1"
        env["PIP_CACHE_DIR"] = cache_dir
        env["TMPDIR"] = tmp_dir
        env["TEMP"] = tmp_dir
        env["TMP"] = tmp_dir
        command = [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--upgrade",
            "--target",
            target,
            "--disable-pip-version-check",
            "--no-warn-script-location",
            "opencv-python",
            "mediapipe",
        ]
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            text=True,
            env=env,
        )
        with _STATE_LOCK:
            _INSTALL_PROCESS = process
        _activity_module().track_resource(
            lease,
            "process",
            process,
            lambda proc=process: _close_process_io_and_terminate(proc),
            label="face dependency pip process",
        )
        stdout, stderr = process.communicate()
        if stop_event.is_set():
            _queue_status("cancelled")
            return
        if process.returncode == 0:
            if target and target not in sys.path:
                sys.path.insert(0, target)
            # The target directory may already have a cached import finder.
            importlib.invalidate_caches()
            refresh_dependency_cache()
            _queue_status("success", report_type="INFO", report_key="success")
            return
        detail = (stderr or stdout or "pip exited with a non-zero status").strip()
        short_detail = detail[-400:].replace("\r", " ").replace("\n", " ")
        _LAST_ERROR = f"pip:{process.returncode}:{short_detail}"[:800]
        invalidate_dependency_cache()
        _queue_status("failed", short_detail, "ERROR", "failed", short_detail)
    except Exception as exc:
        if stop_event.is_set():
            _queue_status("cancelled")
        else:
            detail = f"{type(exc).__name__}: {exc}"[:400]
            _LAST_ERROR = detail
            invalidate_dependency_cache()
            _queue_status("error", detail, "ERROR", "error", detail)
    finally:
        # The exact process handle stays journaled until lease teardown.  The
        # global pointer can be cleared only after process completion.
        with _STATE_LOCK:
            if _INSTALL_PROCESS is process and (process is None or process.poll() is not None):
                _INSTALL_PROCESS = None


class SHAPE_XY_OT_install_deps(bpy.types.Operator):
    bl_idname = "shape_xy.install_deps"
    bl_label = _ui_text("Install Face Tracker Requirements", "フェイストラッカー の必要環境をインストール")
    bl_description = _ui_text(
        "Install the Python packages required by the built-in Face Tracker into Smart_Shapekey_Suite/python_modules in Blender CONFIG. Installation starts only when this button is pressed and can be stopped safely during reload or file load.",
        "内蔵フェイストラッカーに必要な Python パッケージを Blender の設定フォルダー内の Smart_Shapekey_Suite/python_modules へインストールします。このボタンを押したときだけ開始し、再読み込みやファイル読み込み時は安全に停止します。",
    )

    def execute(self, context):
        global _INSTALL_THREAD, _INSTALL_STOP_EVENT, _INSTALL_LEASE
        if _worker_alive():
            self.report({"INFO"}, _ui_text("Installation is already running.", "インストールはすでに実行中です。", context))
            return {"CANCELLED"}
        stop_install_worker()
        try:
            if not bool(getattr(getattr(bpy, "app", None), "online_access", True)):
                self.report(
                    {"ERROR"},
                    _ui_text(
                        "Blender online access is disabled. Enable Online Access before installing Face Tracker requirements.",
                        "Blender のオンラインアクセスが無効です。必要環境をインストールする前にオンラインアクセスを有効にしてください。",
                        context,
                    ),
                )
                return {"CANCELLED"}
            target = dependency_target_dir(create=True)
            cache_dir = _extension_user_dir("pip_cache", create=True)
            tmp_dir = _extension_user_dir("pip_tmp", create=True)
        except Exception as exc:
            self.report(
                {"ERROR"},
                _ui_text(
                    "Could not prepare dependency folders: " + _sss_translation.exception_text(exc, context),
                    "依存関係フォルダーを準備できませんでした: " + _sss_translation.exception_text(exc, context),
                    context,
                ),
            )
            return {"CANCELLED"}

        activity = _activity_module()
        lease = None
        stop_event = threading.Event()
        thread = None
        try:
            lease = activity.new_lease(_INSTALL_FEATURE, replace=True)
            thread = threading.Thread(
                target=_install_worker,
                args=(target, cache_dir, tmp_dir, stop_event, lease),
                name=f"SmartShapekeyFaceInstaller-g{lease.token.generation}",
                daemon=True,
            )
            with _STATE_LOCK:
                _INSTALL_LEASE = lease
                _INSTALL_STOP_EVENT = stop_event
                _INSTALL_THREAD = thread
            # Record the worker before starting it.  Any process resource recorded
            # later is removed first by reverse-order teardown.
            activity.track_thread(lease, thread, lambda th=thread: _join_install_thread(th), label="face dependency installer worker")
            activity.add_timer(lease, _drain_install_status_queue, first_interval=0.1, label="face dependency installer status")
            thread.start()
            return {"FINISHED"}
        except Exception as exc:
            global _LAST_ERROR
            _LAST_ERROR = f"installer-start:{type(exc).__name__}:{exc}"[:800]
            stop_event.set()
            stop_install_worker()
            self.report({"ERROR"}, _ui_text("Could not start the installer worker.", "インストーラーワーカーを開始できませんでした。", context))
            return {"CANCELLED"}


def stop_install_worker() -> bool:
    """Idempotently stop process/timer/thread and retain live handles on failure."""
    global _INSTALL_THREAD, _INSTALL_PROCESS, _INSTALL_STOP_EVENT, _INSTALL_LEASE
    with _STATE_LOCK:
        stop_event = _INSTALL_STOP_EVENT
        process = _INSTALL_PROCESS
        thread = _INSTALL_THREAD
    if stop_event is not None:
        stop_event.set()
    _close_process_io_and_terminate(process)
    try:
        ok = bool(_activity_module().teardown_feature(_INSTALL_FEATURE))
    except Exception:
        ok = False
    alive = bool(thread is not None and thread.is_alive())
    if ok and not alive:
        with _STATE_LOCK:
            _INSTALL_THREAD = None
            _INSTALL_PROCESS = None
            _INSTALL_STOP_EVENT = None
            _INSTALL_LEASE = None
        with _STATUS_LOCK:
            _STATUS_ITEMS.clear()
        return True
    return False


def audit_snapshot() -> dict[str, Any]:
    with _STATUS_LOCK:
        queued = len(_STATUS_ITEMS)
        dropped = int(_STATUS_DROPPED)
    with _STATE_LOCK:
        thread = _INSTALL_THREAD
        process = _INSTALL_PROCESS
    return {
        "queue_max_items": _STATUS_MAX_ITEMS,
        "queue_items": queued,
        "queue_dropped": dropped,
        "tick_max_items": _STATUS_TICK_MAX_ITEMS,
        "tick_budget_seconds": _STATUS_TICK_BUDGET_SECONDS,
        "thread_alive": bool(thread is not None and thread.is_alive()),
        "process_alive": bool(process is not None and process.poll() is None),
        "dependency_cache_checked": bool(_DEPENDENCY_CACHE.get("checked", False)),
        "dependency_cache_ready": bool(_DEPENDENCY_CACHE.get("ready", False)),
        "last_error": _LAST_ERROR,
    }


def register(ledger):
    from ... import lifecycle
    for cls in (SHAPE_XY_OT_report_message, SHAPE_XY_OT_install_deps):
        lifecycle.register_class(ledger, cls)
    lifecycle.register_rna_property(
        ledger,
        bpy.types.Scene,
        "tracker_install_status",
        bpy.props.StringProperty(
            default="",
            description=_ui_text(
                "Current dependency installation status displayed in the Face Tracker panel.",
                "フェイストラッカーパネルに表示する、現在の依存関係インストール状態です。",
            ),
        ),
    )
    # Explicit registration boundary, never Panel.draw.
    try:
        refresh_dependency_cache()
    except Exception:
        invalidate_dependency_cache()


def unregister():
    stop_install_worker()
    invalidate_dependency_cache()
