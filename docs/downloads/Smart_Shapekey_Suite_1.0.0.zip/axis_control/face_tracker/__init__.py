# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
from . import installer
from . import core
from . import ui
from . import operator
from . import draw_hud
from ... import facial_capture

def register(ledger):
    facial_capture.register(ledger)
    installer.register(ledger)
    core.register(ledger)
    operator.register(ledger)
    draw_hud.register(ledger)
    ui.register(ledger)


def unregister():
    for module in (ui, draw_hud, operator, core, installer, facial_capture):
        try:
            module.unregister()
        except Exception:
            pass
