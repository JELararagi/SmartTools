# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Manage the face tracker's feature lifetime."""

from contextlib import suppress

from ... import facial_capture
from . import core, draw_hud, installer, operator, ui

_FEATURES = (facial_capture, installer, core, operator, draw_hud, ui)


def register(ledger):
    for feature in _FEATURES:
        feature.register(ledger)


def unregister():
    for feature in reversed(_FEATURES):
        with suppress(Exception):
            feature.unregister()
