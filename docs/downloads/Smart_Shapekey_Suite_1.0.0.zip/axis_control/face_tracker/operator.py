# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import os
import subprocess
import sys

import bpy

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None


from .core import start_tracker, stop_tracker


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, 'preferences', None), 'view', None)
    if view is None:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
    language = str(getattr(view, 'language', 'DEFAULT') or 'DEFAULT').upper()
    return language.startswith('JA')


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)




def _set_suite_always_on_state(context, key: str, value: bool) -> None:
    try:
        from ... import runtime
        settings = getattr(getattr(context, 'window_manager', None), 'skm_suite_settings', None)
        if settings is not None and hasattr(settings, key):
            setattr(settings, key, bool(value))
        saver = getattr(runtime, 'save_persistent_setting', None)
        if callable(saver):
            saver(key, bool(value))
    except Exception:
        pass

def _save_panel_settings(context=None):
    try:
        from ... import runtime
        saver = getattr(runtime, 'save_current_panel_settings', None)
        if callable(saver):
            saver(context if context is not None else getattr(bpy, 'context', None))
    except Exception:
        pass


def get_tracker_settings_group(context):
    idx = context.scene.tracker_target_index
    if not hasattr(context.scene, 'tracker_targets') or idx < 0 or idx >= len(context.scene.tracker_targets):
        return None
    target = context.scene.tracker_targets[idx]
    obj = target.obj
    if obj and target.group_name and hasattr(obj, 'shape_xy_groups') and target.group_name in obj.shape_xy_groups:
        return obj.shape_xy_groups[target.group_name]
    return None


def _open_path(path: str) -> bool:
    if os.name == 'nt':
        os.startfile(path)
        return True
    if sys.platform == 'darwin':
        return subprocess.call(['open', path]) == 0
    return subprocess.call(['xdg-open', path]) == 0


_PRESET_FILES = {
    'MOUTH': 'mouth_default.json',
    'EYES': 'eye_default.json',
    'EYE_BLINK': 'eye_blink_default.json',
}


def _asset_path(filename: str) -> str:
    return os.path.join(os.path.dirname(__file__), 'assets', filename)


def _normalize_tracker_mode(value: object) -> str:
    mode = str(value or 'None')
    low = mode.lower().strip()
    if low in {'none', 'off', 'disabled'}:
        return 'None'
    if low.startswith('2pt'):
        return '2pt (Dist)'
    if low.startswith('1pt'):
        return '1pt (Proj)'
    if 'iris' in low:
        return 'iris'
    return 'None'


def _preset_value(axis_data: dict, *keys: str, default=0.0):
    for key in keys:
        if key in axis_data:
            return axis_data.get(key)
    return default


def _load_tracker_preset(preset_type: str) -> dict | None:
    filename = _PRESET_FILES.get(str(preset_type or ''))
    if not filename:
        return None
    path = _asset_path(filename)
    if not os.path.exists(path):
        raise FileNotFoundError(path)
    with open(path, 'r', encoding='utf-8') as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(_ui_text('Preset file must contain a JSON object.', 'プリセットファイルは JSON オブジェクトである必要があります。'))
    return data


def _apply_axis_preset(group, axis: str, axis_data: dict) -> None:
    if not isinstance(axis_data, dict):
        return
    prefix = f'tracker_{axis}_'
    setattr(group, prefix + 'mode', _normalize_tracker_mode(axis_data.get('mode', 'None')))
    setattr(group, prefix + 'pt_a', int(_preset_value(axis_data, 'point_a', 'pt_a', default=0)))
    setattr(group, prefix + 'pt_b', int(_preset_value(axis_data, 'point_b', 'pt_b', default=0)))
    setattr(group, prefix + 'rmin', float(_preset_value(axis_data, 'radius_min', 'rmin', default=0.0)))
    setattr(group, prefix + 'rmax', float(_preset_value(axis_data, 'radius_max', 'rmax', default=1.0)))
    setattr(group, prefix + 'omin', float(_preset_value(axis_data, 'out_min', 'omin', default=0.0)))
    setattr(group, prefix + 'omax', float(_preset_value(axis_data, 'out_max', 'omax', default=1.0)))
    setattr(group, prefix + 'sens', float(_preset_value(axis_data, 'sens', default=1.0)))
    setattr(group, prefix + 'exp', float(_preset_value(axis_data, 'exp_power', 'exp', default=1.2)))
    setattr(group, prefix + 'lerp_en', bool(_preset_value(axis_data, 'lerp_en', default=False)))
    setattr(group, prefix + 'lerp_fac', float(_preset_value(axis_data, 'lerp_fac', default=0.15)))


def _apply_tracker_preset_data(group, data: dict) -> None:
    _apply_axis_preset(group, 'x', data.get('x', {}))
    _apply_axis_preset(group, 'y', data.get('y', {}))


class SHAPE_XY_OT_tracker_native_start(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_native_start'
    bl_options = {'INTERNAL'}
    bl_label = _ui_text('Start Face Tracker', 'フェイストラッカー を開始')
    bl_description = _ui_text('Start the built-in webcam face tracker.', '内蔵ウェブカメラ フェイストラッカー を開始します。')

    def execute(self, context):
        if not start_tracker(context.scene.tracker_cam_index):
            _set_suite_always_on_state(context, 'always_face_tracker_enabled', False)
            self.report({'ERROR'}, _ui_text('Face Tracker could not be started. Install dependencies and check the bundled model file.', 'フェイストラッカーを開始できませんでした。依存関係のインストール状態と同梱モデルファイルを確認してください。', context))
            return {'CANCELLED'}
        _set_suite_always_on_state(context, 'always_face_tracker_enabled', True)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_native_stop(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_native_stop'
    bl_options = {'INTERNAL'}
    bl_label = _ui_text('Stop Face Tracker', 'フェイストラッカー を停止')
    bl_description = _ui_text('Stop the built-in webcam face tracker.', '内蔵ウェブカメラ フェイストラッカー を停止します。')

    def execute(self, context):
        stop_tracker()
        _set_suite_always_on_state(context, 'always_face_tracker_enabled', False)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_open_map(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_open_map'
    bl_label = _ui_text('Open Feature Map', '特徴点マップを開く')
    bl_description = _ui_text('Open the landmark reference image with your OS default viewer.', 'ランドマーク参照画像を OS の既定ビューアで開きます。')

    def execute(self, context):
        if bpy.app.background:
            self.report({'WARNING'}, _ui_text('A desktop session is required to open the reference map.', '参照マップを開くにはデスクトップセッションが必要です。', context))
            return {'CANCELLED'}
        path = os.path.join(os.path.dirname(__file__), 'assets', 'face_mesh.png')
        if not os.path.exists(path):
            self.report({'ERROR'}, _ui_text('Reference map image was not found.', '参照マップ画像が見つかりませんでした。', context))
            return {'CANCELLED'}
        try:
            if not _open_path(path):
                raise RuntimeError(_ui_text('open command failed', '開くコマンドが失敗しました。', context))
        except Exception as exc:
            self.report({'ERROR'}, _ui_text('Failed to open the reference map: ' + _sss_translation.exception_text(exc, context), '参照マップを開けませんでした: ' + _sss_translation.exception_text(exc, context), context))
            return {'CANCELLED'}
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_cal_min_x(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_cal_min_x'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Capture X Min', 'X 最小を取得')
    bl_description = _ui_text('Store the current raw X tracker value as the lower input bound.', '現在の生の X トラッカー値を入力下限として保存します。')

    def execute(self, context):
        group = get_tracker_settings_group(context)
        if not group:
            self.report({'ERROR'}, _ui_text('Select a valid tracker target first.', '先に有効なトラッカー対象を選択してください。', context))
            return {'CANCELLED'}
        group.tracker_x_rmin = abs(context.scene.tracker_raw_x)
        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_cal_max_x(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_cal_max_x'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Capture X Max', 'X 最大を取得')
    bl_description = _ui_text('Store the current raw X tracker value as the upper input bound.', '現在の生の X トラッカー値を入力上限として保存します。')

    def execute(self, context):
        group = get_tracker_settings_group(context)
        if not group:
            self.report({'ERROR'}, _ui_text('Select a valid tracker target first.', '先に有効なトラッカー対象を選択してください。', context))
            return {'CANCELLED'}
        group.tracker_x_rmax = abs(context.scene.tracker_raw_x)
        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_cal_min_y(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_cal_min_y'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Capture Y Min', 'Y 最小を取得')
    bl_description = _ui_text('Store the current raw Y tracker value as the lower input bound.', '現在の生の Y トラッカー値を入力下限として保存します。')

    def execute(self, context):
        group = get_tracker_settings_group(context)
        if not group:
            self.report({'ERROR'}, _ui_text('Select a valid tracker target first.', '先に有効なトラッカー対象を選択してください。', context))
            return {'CANCELLED'}
        group.tracker_y_rmin = abs(context.scene.tracker_raw_y)
        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_cal_max_y(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_cal_max_y'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Capture Y Max', 'Y 最大を取得')
    bl_description = _ui_text('Store the current raw Y tracker value as the upper input bound.', '現在の生の Y トラッカー値を入力上限として保存します。')

    def execute(self, context):
        group = get_tracker_settings_group(context)
        if not group:
            self.report({'ERROR'}, _ui_text('Select a valid tracker target first.', '先に有効なトラッカー対象を選択してください。', context))
            return {'CANCELLED'}
        group.tracker_y_rmax = abs(context.scene.tracker_raw_y)
        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_apply_preset(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_apply_preset'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Apply Tracking Preset', 'トラッキングプリセットを適用')
    bl_description = _ui_text('Fill the current tracker settings with a prepared mouth, eye, or blink preset.', '現在のトラッカー設定へ、口・目・まばたき用の準備済みプリセットを入れます。')

    preset_type: bpy.props.StringProperty(
        description=_ui_text(
            'Internal preset identifier that chooses mouth, eye, or blink tracking defaults.',
            '口・目・まばたき用のトラッキング初期値を選ぶ内部プリセット識別子です。',
        ),
        options={'HIDDEN'},
    )

    def execute(self, context):
        group = get_tracker_settings_group(context)
        if not group:
            self.report({'ERROR'}, _ui_text('Select a valid tracker target first.', '先に有効なトラッカー対象を選択してください。', context))
            return {'CANCELLED'}

        try:
            data = _load_tracker_preset(self.preset_type)
            if data is None:
                raise ValueError(_ui_text('Unknown tracking preset.', '不明なトラッキングプリセットです。', context))
            _apply_tracker_preset_data(group, data)
        except Exception as exc:
            self.report({'ERROR'}, _ui_text('Failed to load tracking preset: ' + _sss_translation.exception_text(exc, context), 'トラッキングプリセットを読み込めませんでした: ' + _sss_translation.exception_text(exc, context), context))
            return {'CANCELLED'}

        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_add_target(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_add_target'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Add Target', '対象を追加')
    bl_description = _ui_text('Add a new object-and-group target entry for the face tracker.', 'フェイストラッカー 用のオブジェクト・グループ対象を新しく追加します。')

    def execute(self, context):
        context.scene.tracker_targets.add()
        context.scene.tracker_target_index = len(context.scene.tracker_targets) - 1
        _save_panel_settings(context)
        return {'FINISHED'}


class SHAPE_XY_OT_tracker_remove_target(bpy.types.Operator):
    bl_idname = 'shape_xy.tracker_remove_target'
    bl_options = {'UNDO'}
    bl_label = _ui_text('Remove Target', '対象を削除')
    bl_description = _ui_text('Remove the currently selected face-tracker target entry.', '現在選択中の フェイストラッカー 対象エントリーを削除します。')

    def execute(self, context):
        idx = context.scene.tracker_target_index
        if hasattr(context.scene, 'tracker_targets') and 0 <= idx < len(context.scene.tracker_targets):
            context.scene.tracker_targets.remove(idx)
            context.scene.tracker_target_index = min(max(0, idx - 1), len(context.scene.tracker_targets) - 1) if len(context.scene.tracker_targets) else -1
            _save_panel_settings(context)
        return {'FINISHED'}


classes = (
    SHAPE_XY_OT_tracker_native_start,
    SHAPE_XY_OT_tracker_native_stop,
    SHAPE_XY_OT_tracker_open_map,
    SHAPE_XY_OT_tracker_cal_min_x,
    SHAPE_XY_OT_tracker_cal_max_x,
    SHAPE_XY_OT_tracker_cal_min_y,
    SHAPE_XY_OT_tracker_cal_max_y,
    SHAPE_XY_OT_tracker_apply_preset,
    SHAPE_XY_OT_tracker_add_target,
    SHAPE_XY_OT_tracker_remove_target,
)


def register(ledger):
    from ... import lifecycle
    for cls in classes:
        lifecycle.register_class(ledger, cls)


def unregister():
    return None
