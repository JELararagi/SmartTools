# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Built-in Face Tracker worker and main-thread bridge.

The camera/MediaPipe handles are retained globally while alive. Teardown closes
camera and landmarker I/O before joining the worker so blocking reads are
unblocked before Blender unloads RNA or a new file.
"""
from __future__ import annotations

from types import MappingProxyType
from typing import Any
import math
import os
import threading
import time

import bpy

from ... import activity as _activity
from ... import lifecycle as _lifecycle
try:
    from ... import translation as _translation
except Exception:
    _translation = None


def _is_japanese_locale(context=None) -> bool:
    try:
        return bool(_translation is not None and _translation.is_japanese_locale(context))
    except Exception:
        return False


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _translation is not None:
            return _translation.ui_text(en, ja, context)
    except Exception:
        pass
    return ja if _is_japanese_locale(context) else en


def _persistent_default(key: str, default):
    try:
        from ... import runtime
        return runtime.get_persistent_setting(key, default)
    except Exception:
        return default


def _save_scene_runtime_setting(prop_name: str, value) -> None:
    try:
        from ... import runtime
        runtime.save_scene_runtime_setting(prop_name, value)
    except Exception:
        pass


def _on_tracker_cam_index_update(self, _context):
    _save_scene_runtime_setting('tracker_cam_index', int(getattr(self, 'tracker_cam_index', 0)))


TRACKER_RUNNING = False
TRACKER_THREAD: threading.Thread | None = None
TRACKER_START_EVENT: threading.Event | None = None
TRACKER_START_ERROR = ''
CAMERA_PIXELS = None
CURRENT_CONFIG: dict[str, Any] = {}
CURRENT_RESULTS: dict[str, Any] = {}
FPS_STAT = '0'
RAW_VALUES = {'x': 0.0, 'y': 0.0}
CURRENT_LANDMARKS: tuple[tuple[float, float], ...] = ()
PREVIEW_REQUESTED = False

EYE_R = {'iris': 468, 'inner': 133, 'outer': 33, 'top': 159, 'bottom': 145}
EYE_L = {'iris': 473, 'inner': 362, 'outer': 263, 'top': 386, 'bottom': 374}

_LOCK = threading.RLock()
_DATA_LOCK = threading.RLock()
_STOP_EVENT = threading.Event()
_CAMERA_HANDLE = None
_LANDMARKER_HANDLE = None
_LEASE = None
_WORKER_TOKEN = None
_LAST_ERROR = ''
_TIMER_TICKS = 0
_TARGET_UPDATES = 0


def calculate_distance(p1, p2):
    return math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2 + (p1.z - p2.z) ** 2)


def normalize_value(val, radius_min, radius_max, out_min, out_max):
    try:
        val = float(val)
        radius_min = float(radius_min)
        radius_max = float(radius_max)
        out_min = float(out_min)
        out_max = float(out_max)
    except Exception:
        return float(out_min) if isinstance(out_min, (int, float)) else 0.0
    span = radius_max - radius_min
    if abs(span) < 1.0e-8:
        return out_min
    normalized = max(0.0, min(1.0, (val - radius_min) / span))
    return out_min + (out_max - out_min) * normalized


def _set_error(message: object) -> None:
    global _LAST_ERROR, TRACKER_START_ERROR
    text = str(message or '')[:2048]
    _LAST_ERROR = text
    TRACKER_START_ERROR = text


def last_error() -> str:
    return _LAST_ERROR


def _signal_tracker_start(error: str = '') -> None:
    global TRACKER_START_ERROR
    TRACKER_START_ERROR = str(error or '')
    event = TRACKER_START_EVENT
    if event is not None:
        event.set()


def _release_camera(camera) -> None:
    try:
        camera.release()
    except Exception:
        pass


def _close_landmarker(landmarker) -> None:
    try:
        landmarker.close()
    except Exception:
        pass


def _close_worker_io() -> None:
    with _LOCK:
        camera = _CAMERA_HANDLE
        landmarker = _LANDMARKER_HANDLE
    if camera is not None:
        _release_camera(camera)
    if landmarker is not None:
        _close_landmarker(landmarker)


def _join_worker(thread: threading.Thread) -> None:
    if thread is threading.current_thread():
        raise RuntimeError('cannot join Face Tracker worker from itself')
    deadline = time.monotonic() + 3.0
    while thread.is_alive() and time.monotonic() < deadline:
        thread.join(timeout=0.05)
    if thread.is_alive():
        raise RuntimeError('Face Tracker worker did not stop after camera/landmarker close')


def _tracker_preview_requested() -> bool:
    return bool(PREVIEW_REQUESTED)


def _update_preview_requested_from_main_thread() -> None:
    global PREVIEW_REQUESTED
    try:
        PREVIEW_REQUESTED = bpy.data.images.get('FaceTracker_Preview') is not None
    except Exception:
        PREVIEW_REQUESTED = False


def _process_face_results(results, rgb, np, cv2, iris_ema, lerp_values, f_w: int, f_h: int):
    """Worker-only conversion from MediaPipe output to immutable Python data."""
    with _DATA_LOCK:
        cfg = {name: dict(value) for name, value in CURRENT_CONFIG.items()}
    payload: dict[str, dict[str, float]] = {}
    raw_out = {'x': 0.0, 'y': 0.0}
    landmarks: tuple[tuple[float, float], ...] = ()
    active_pts: set[int] = set()

    if results.face_landmarks:
        lms = results.face_landmarks[0]
        landmarks = tuple((float(lm.x), float(lm.y)) for lm in lms)
        f_width = calculate_distance(lms[234], lms[454]) or 1.0
        fx_v = (lms[454].x - lms[234].x, lms[454].y - lms[234].y, lms[454].z - lms[234].z)
        fy_v = (lms[152].x - lms[10].x, lms[152].y - lms[10].y, lms[152].z - lms[10].z)
        for group_name, mappings in cfg.items():
            out_d = {'x': 0.0, 'y': 0.0}
            for axis in ('x', 'y'):
                mapping = dict(mappings.get(axis, {}) or {})
                mode = str(mapping.get('mode', 'None') or 'None')
                ia = int(mapping.get('pt_a', 0) or 0)
                ib = int(mapping.get('pt_b', 0) or 0)
                raw = 0.0
                if 'iris' in mode:
                    eye_key = 'L' if ib in {EYE_L['outer'], EYE_L['top']} else 'R'
                    eye = EYE_L if eye_key == 'L' else EYE_R
                    try:
                        pa, pi, po = lms[eye['iris']], lms[eye['inner']], lms[eye['outer']]
                        pt, pb = lms[eye['top']], lms[eye['bottom']]
                        ew = abs(pi.x - po.x) or 1.0
                        eh = abs(pt.y - pb.y) or 0.1
                        if eh > 0.05 * ew:
                            instant = (pa.x - (pi.x + po.x) / 2.0) / ew if axis == 'x' else (pa.y - (pt.y + pb.y) / 2.0) / eh
                            iris_ema[eye_key][axis] += 0.3 * (instant - iris_ema[eye_key][axis])
                        raw = iris_ema[eye_key][axis]
                    except Exception:
                        raw = iris_ema[eye_key][axis]
                    raw = math.copysign(abs(raw) ** float(mapping.get('exp', 1.2) or 1.2), raw)
                    active_pts.update({eye['iris'], eye['inner'], eye['outer'], eye['top'], eye['bottom']})
                elif '1pt' in mode:
                    try:
                        pa, pb = lms[ia], lms[ib]
                        vec = (pa.x - pb.x, pa.y - pb.y, pa.z - pb.z)
                        face_vector = fx_v if axis == 'x' else fy_v
                        raw = sum(vec[i] * face_vector[i] for i in range(3)) / f_width * 10.0
                    except Exception:
                        raw = 0.0
                    active_pts.update({ia, ib})
                elif '2pt' in mode:
                    try:
                        raw = calculate_distance(lms[ia], lms[ib]) / f_width
                    except Exception:
                        raw = 0.0
                    active_pts.update({ia, ib})
                if mappings.get('_is_active_target'):
                    raw_out[axis] = raw
                value = normalize_value(
                    raw if '2pt' in mode else abs(raw),
                    mapping.get('rmin', 0.0), mapping.get('rmax', 1.0),
                    mapping.get('omin', 0.0), mapping.get('omax', 1.0),
                )
                if '2pt' not in mode:
                    value *= math.copysign(1.0, raw)
                value *= float(mapping.get('sens', 1.0) or 1.0)
                if bool(mapping.get('lerp_en', False)):
                    key = f'{group_name}:{axis}'
                    previous = float(lerp_values.get(key, value))
                    previous += (value - previous) * float(mapping.get('lerp_fac', 0.15) or 0.15)
                    lerp_values[key] = previous
                    value = previous
                out_d[axis] = max(-1.0, min(1.0, value))
            payload[group_name] = out_d

    # Privacy preview: render landmarks on a black frame, never camera pixels.
    preview = None
    if _tracker_preview_requested():
        canvas = np.zeros_like(rgb)
        if results.face_landmarks:
            lms = results.face_landmarks[0]
            for index, landmark in enumerate(lms):
                px, py = int(landmark.x * f_w), int(landmark.y * f_h)
                color = (255, 50, 50) if index in active_pts else (0, 255, 100)
                cv2.circle(canvas, (px, py), 3 if index in active_pts else 1, color, -1)
        resized = cv2.resize(canvas, (320, 240))
        rgba = cv2.cvtColor(resized, cv2.COLOR_RGB2RGBA)
        rgba = cv2.flip(rgba, 0)
        preview = tuple((rgba.astype(np.float32) / 255.0).reshape(-1).tolist())
    return payload, raw_out, landmarks, preview


def tracker_loop(cam_idx, stop_event: threading.Event, token, lease) -> None:
    global TRACKER_RUNNING, CAMERA_PIXELS, CURRENT_RESULTS, FPS_STAT, RAW_VALUES, CURRENT_LANDMARKS
    global _CAMERA_HANDLE, _LANDMARKER_HANDLE
    try:
        import cv2
        import numpy as np
        import mediapipe as mp
        from mediapipe.tasks import python
        from mediapipe.tasks.python import vision
    except Exception as exc:
        _set_error(f'missing dependency: {exc}')
        _signal_tracker_start(_LAST_ERROR)
        with _LOCK:
            TRACKER_RUNNING = False
        return

    model_path = os.path.join(os.path.dirname(__file__), 'assets', 'face_landmarker.task')
    if not os.path.isfile(model_path):
        _set_error(f'model file not found: {model_path}')
        _signal_tracker_start(_LAST_ERROR)
        with _LOCK:
            TRACKER_RUNNING = False
        return

    landmarker = None
    camera = None
    try:
        landmarker = vision.FaceLandmarker.create_from_options(vision.FaceLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=model_path),
            running_mode=vision.RunningMode.VIDEO,
            output_face_blendshapes=True,
        ))
        camera = cv2.VideoCapture(int(cam_idx))
        if not camera.isOpened():
            raise RuntimeError(f'camera could not be opened: {cam_idx}')
        with _LOCK:
            _LANDMARKER_HANDLE = landmarker
            _CAMERA_HANDLE = camera
        _activity.track_resource(lease, 'camera', camera, lambda c=camera: _release_camera(c), label='Face Tracker camera')
        _activity.track_resource(lease, 'landmarker', landmarker, lambda l=landmarker: _close_landmarker(l), label='MediaPipe landmarker')
        _signal_tracker_start('')

        last_time = time.monotonic()
        last_timestamp_ms = 0
        iris_ema = {'R': {'x': 0.0, 'y': 0.0}, 'L': {'x': 0.0, 'y': 0.0}}
        lerp_values: dict[str, float] = {}
        while not stop_event.is_set() and _activity.token_is_current(token):
            success, frame = camera.read()
            if not success:
                if stop_event.wait(0.005):
                    break
                continue
            frame = cv2.flip(frame, 1)
            f_h, f_w = frame.shape[:2]
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            timestamp_ms = max(last_timestamp_ms + 1, int(time.monotonic() * 1000))
            last_timestamp_ms = timestamp_ms
            results = landmarker.detect_for_video(mp_image, timestamp_ms)
            payload, raw_out, landmarks, preview = _process_face_results(results, rgb, np, cv2, iris_ema, lerp_values, f_w, f_h)
            now = time.monotonic()
            fps = int(1.0 / max(now - last_time, 0.001))
            last_time = now
            with _DATA_LOCK:
                CURRENT_RESULTS = payload
                RAW_VALUES = raw_out
                CURRENT_LANDMARKS = landmarks
                CAMERA_PIXELS = preview
                FPS_STAT = f'FPS: {fps}'
    except Exception as exc:
        _set_error(exc)
        if TRACKER_START_EVENT is not None and not TRACKER_START_EVENT.is_set():
            _signal_tracker_start(_LAST_ERROR)
    finally:
        _release_camera(camera)
        if camera is not None:
            _activity.mark_native_finished('face_tracker', camera)
        _close_landmarker(landmarker)
        if landmarker is not None:
            _activity.mark_native_finished('face_tracker', landmarker)
        with _LOCK:
            if _CAMERA_HANDLE is camera:
                _CAMERA_HANDLE = None
            if _LANDMARKER_HANDLE is landmarker:
                _LANDMARKER_HANDLE = None
            TRACKER_RUNNING = False
        # Retain the exact thread entry until the main-thread stop boundary has
        # joined it.  Marking it finished from inside the worker would discard
        # the only authoritative join handle before termination is confirmed.


def _target_config(scene) -> tuple[dict[str, Any], tuple[tuple[Any, Any, str], ...]]:
    cfg: dict[str, Any] = {}
    resolved: list[tuple[Any, Any, str]] = []
    try:
        rows = tuple(getattr(scene, 'tracker_targets', ()) or ())
        active_index = int(getattr(scene, 'tracker_target_index', -1))
    except Exception:
        return cfg, ()
    for row_index, target in enumerate(rows):
        obj = getattr(target, 'obj', None)
        group_name = str(getattr(target, 'group_name', '') or '')
        if obj is None or not group_name:
            continue
        group = None
        try:
            groups = getattr(obj, 'shape_xy_groups', None)
            if groups is not None:
                try:
                    group = groups.get(group_name)
                except Exception:
                    group = None
                if group is None:
                    for candidate in tuple(groups):
                        if str(getattr(candidate, 'name', '') or '') == group_name:
                            group = candidate
                            break
        except Exception:
            group = None
        if group is None:
            continue
        uid = f'{obj.name}_{group.name}'
        cfg[uid] = {
            '_is_active_target': row_index == active_index,
            'x': {
                'mode': group.tracker_x_mode, 'pt_a': group.tracker_x_pt_a, 'pt_b': group.tracker_x_pt_b,
                'rmin': group.tracker_x_rmin, 'rmax': group.tracker_x_rmax,
                'omin': group.tracker_x_omin, 'omax': group.tracker_x_omax,
                'sens': group.tracker_x_sens, 'exp': group.tracker_x_exp,
                'lerp_en': group.tracker_x_lerp_en, 'lerp_fac': group.tracker_x_lerp_fac,
            },
            'y': {
                'mode': group.tracker_y_mode, 'pt_a': group.tracker_y_pt_a, 'pt_b': group.tracker_y_pt_b,
                'rmin': group.tracker_y_rmin, 'rmax': group.tracker_y_rmax,
                'omin': group.tracker_y_omin, 'omax': group.tracker_y_omax,
                'sens': group.tracker_y_sens, 'exp': group.tracker_y_exp,
                'lerp_en': group.tracker_y_lerp_en, 'lerp_fac': group.tracker_y_lerp_fac,
            },
        }
        resolved.append((obj, group, uid))
    return cfg, tuple(resolved)


def _process_blender_timer_impl():
    global CURRENT_CONFIG, _TIMER_TICKS, _TARGET_UPDATES
    if not is_tracker_running():
        # Natural camera/MediaPipe failure is finalized on Blender's main
        # thread.  This closes any residual I/O and joins while retaining the
        # exact worker handle until success.
        with _LOCK:
            pending = TRACKER_THREAD is not None or _CAMERA_HANDLE is not None or _LANDMARKER_HANDLE is not None or _LEASE is not None
        if pending:
            stop_tracker()
        return None
    scene = getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return 0.05
    _update_preview_requested_from_main_thread()
    cfg, targets = _target_config(scene)
    with _DATA_LOCK:
        CURRENT_CONFIG = cfg
        results = {name: dict(value) for name, value in CURRENT_RESULTS.items()}
        raw_values = dict(RAW_VALUES)
        pixels = CAMERA_PIXELS
        landmarks = tuple(CURRENT_LANDMARKS)
        fps = str(FPS_STAT)

    updates = 0
    if results:
        from ..core.main import update_shapes, get_limit
        try:
            from ..ui import properties as props_module
            props_module.set_panel_setting_save_suppressed(True)
        except Exception:
            props_module = None
        try:
            for obj, group, uid in targets:
                value = results.get(uid)
                if value is None:
                    continue
                group.joy_x = float(value.get('x', group.joy_x))
                group.joy_y = float(value.get('y', group.joy_y))
                update_shapes(obj, group, get_limit(group))
                updates += 1
        finally:
            if props_module is not None:
                try:
                    props_module.set_panel_setting_save_suppressed(False)
                except Exception:
                    pass

    if pixels is not None:
        try:
            image = bpy.data.images.get('FaceTracker_Preview')
            if image is not None and tuple(image.size[:2]) == (320, 240) and len(pixels) == 320 * 240 * 4:
                image.pixels.foreach_set(pixels)
                image.update()
        except Exception:
            pass

    try:
        scene.tracker_fps_status = fps
        scene.tracker_raw_x = float(raw_values.get('x', 0.0))
        scene.tracker_raw_y = float(raw_values.get('y', 0.0))
    except Exception:
        pass
    try:
        from . import draw_hud
        draw_hud.update_snapshot(landmarks)
    except Exception:
        pass
    _TIMER_TICKS += 1
    _TARGET_UPDATES += updates
    return 0.05


def process_blender_timer():
    try:
        return _process_blender_timer_impl()
    except Exception as exc:
        _set_error(exc)
        stop_tracker()
        return None


def start_tracker(cam_idx=0) -> bool:
    global TRACKER_RUNNING, TRACKER_THREAD, TRACKER_START_EVENT, TRACKER_START_ERROR
    global _STOP_EVENT, _LEASE, _WORKER_TOKEN, CURRENT_RESULTS, RAW_VALUES, CURRENT_LANDMARKS, PREVIEW_REQUESTED
    if is_tracker_running():
        return True
    stop_tracker()
    try:
        from .installer import check_dependencies, ensure_dependency_target_on_path
        ensure_dependency_target_on_path()
        if not check_dependencies():
            _set_error('required Python modules are not installed')
            return False
    except Exception as exc:
        _set_error(f'dependency check failed: {exc}')
        return False
    model_path = os.path.join(os.path.dirname(__file__), 'assets', 'face_landmarker.task')
    if not os.path.isfile(model_path):
        _set_error(f'model file not found: {model_path}')
        return False
    try:
        cam_idx = max(0, int(cam_idx))
    except Exception:
        cam_idx = 0

    with _DATA_LOCK:
        CURRENT_RESULTS = {}
        RAW_VALUES = {'x': 0.0, 'y': 0.0}
        CURRENT_LANDMARKS = ()
        PREVIEW_REQUESTED = False
    _update_preview_requested_from_main_thread()
    TRACKER_START_ERROR = ''
    start_event = threading.Event()
    stop_event = threading.Event()
    lease = None
    thread = None
    try:
        lease = _activity.new_lease('face_tracker', replace=True)
        token = lease.token
        thread = threading.Thread(
            target=tracker_loop,
            args=(cam_idx, stop_event, token, lease),
            name=f'SmartShapekeyFace-g{token.generation}',
            daemon=True,
        )
        _activity.track_thread(lease, thread, lambda t=thread: _join_worker(t), label='Face Tracker worker')
        with _LOCK:
            TRACKER_START_EVENT = start_event
            _STOP_EVENT = stop_event
            TRACKER_THREAD = thread
            _LEASE = lease
            _WORKER_TOKEN = token
            TRACKER_RUNNING = True
        thread.start()
        started = start_event.wait(timeout=5.0)
    except Exception as exc:
        _set_error(exc)
        started = False
    finally:
        TRACKER_START_EVENT = None
    if not started or TRACKER_START_ERROR or not TRACKER_RUNNING:
        if not TRACKER_START_ERROR:
            _set_error('Face Tracker startup confirmation timed out')
        stop_tracker()
        return False
    try:
        _activity.add_timer(lease, process_blender_timer, first_interval=0.05, persistent=False, label='Face Tracker main-thread bridge')
    except Exception as exc:
        _set_error(exc)
        stop_tracker()
        return False
    return True


def stop_tracker() -> bool:
    global TRACKER_RUNNING, TRACKER_THREAD, CAMERA_PIXELS, CURRENT_RESULTS, RAW_VALUES, CURRENT_LANDMARKS
    global PREVIEW_REQUESTED, _LEASE, _CAMERA_HANDLE, _LANDMARKER_HANDLE
    with _LOCK:
        TRACKER_RUNNING = False
        stop_event = _STOP_EVENT
        thread = TRACKER_THREAD
    stop_event.set()
    # Close I/O before joining to unblock camera.read()/MediaPipe processing.
    _close_worker_io()
    ok = _activity.teardown_feature('face_tracker')
    alive = bool(thread is not None and thread.is_alive())
    if alive and thread is not threading.current_thread():
        try:
            _join_worker(thread)
            alive = False
            # Retry the exact lease after the blocking native resource has now
            # stopped; this marks the retained journal identity removed.
            ok = bool(_activity.teardown_feature('face_tracker') and ok)
        except Exception as exc:
            _set_error(exc)
            ok = False
    if not alive:
        with _LOCK:
            if TRACKER_THREAD is thread:
                TRACKER_THREAD = None
            _CAMERA_HANDLE = None
            _LANDMARKER_HANDLE = None
            _LEASE = None
        with _DATA_LOCK:
            CAMERA_PIXELS = None
            CURRENT_RESULTS = {}
            RAW_VALUES = {'x': 0.0, 'y': 0.0}
            CURRENT_LANDMARKS = ()
            PREVIEW_REQUESTED = False
    try:
        from . import draw_hud
        draw_hud.update_snapshot(())
    except Exception:
        pass
    return bool(ok and not alive)


def stop_tracking() -> bool:
    return stop_tracker()


def is_tracker_running() -> bool:
    with _LOCK:
        return bool(TRACKER_RUNNING and TRACKER_THREAD is not None and TRACKER_THREAD.is_alive())


def tracker_audit_snapshot() -> dict[str, Any]:
    with _LOCK:
        thread_alive = bool(TRACKER_THREAD is not None and TRACKER_THREAD.is_alive())
        camera_open = _CAMERA_HANDLE is not None
        landmarker_open = _LANDMARKER_HANDLE is not None
    with _DATA_LOCK:
        result_count = len(CURRENT_RESULTS)
        landmark_count = len(CURRENT_LANDMARKS)
    return {
        'running': is_tracker_running(),
        'thread_alive': thread_alive,
        'camera_handle_retained': camera_open,
        'landmarker_handle_retained': landmarker_open,
        'result_count': result_count,
        'landmark_count': landmark_count,
        'timer_ticks': _TIMER_TICKS,
        'target_updates': _TARGET_UPDATES,
        'last_error': _LAST_ERROR,
    }


def register(ledger):
    lp = _lifecycle.register_rna_property
    for name, prop in (
        ('tracker_fps_status', bpy.props.StringProperty(
            default=_ui_text('Stopped', '停止中'),
            description=_ui_text('Current Face Tracker status and measured frame rate.', '現在のフェイストラッカー状態と計測FPSです。'),
        )),
        ('tracker_raw_x', bpy.props.FloatProperty(
            description=_ui_text('Latest raw X input before remapping.', '変換前の最新の生X入力です。'),
        )),
        ('tracker_raw_y', bpy.props.FloatProperty(
            description=_ui_text('Latest raw Y input before remapping.', '変換前の最新の生Y入力です。'),
        )),
        ('tracker_cam_index', bpy.props.IntProperty(
            name=_ui_text('Camera Index', 'カメラ番号'),
            description=_ui_text('Camera device index used only while the built-in Face Tracker is enabled.', '内蔵フェイストラッカー有効中だけ使用するカメラ番号です。'),
            default=int(_persistent_default('tracker_cam_index', 0)), min=0,
            update=_on_tracker_cam_index_update,
        )),
    ):
        lp(ledger, bpy.types.Scene, name, prop)


def unregister():
    stop_tracker()
