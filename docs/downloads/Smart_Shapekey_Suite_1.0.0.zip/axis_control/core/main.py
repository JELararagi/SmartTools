# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import math

def get_active_group(obj):
    if obj and hasattr(obj, 'shape_xy_groups') and len(obj.shape_xy_groups) > 0:
        idx = obj.shape_xy_group_index
        if 0 <= idx < len(obj.shape_xy_groups):
            return obj.shape_xy_groups[idx]
    return None

def unique_group_name(groups, base):
    """Return base, or base.NNN when it is taken. Presets and tracker targets find groups by name."""
    used = {str(group.name) for group in groups}
    if base not in used:
        return base
    number = 1
    while f"{base}.{number:03d}" in used:
        number += 1
    return f"{base}.{number:03d}"

def get_limit(group):
    if group and hasattr(group, 'shape_xy_list') and len(group.shape_xy_list) > 0:
        values = [1.0]
        for item in group.shape_xy_list:
            try:
                values.append(abs(float(item.target_x)))
                values.append(abs(float(item.target_y)))
            except Exception:
                pass
        return max(values) or 1.0
    return 1.0

def update_shapes(obj, group, limit):
    val_x = group.joy_x * limit
    val_y = group.joy_y * limit

    if obj and obj.type == 'MESH' and obj.data and hasattr(obj.data, 'shape_keys') and obj.data.shape_keys:
        shape_values = {}

        for item in group.shape_xy_list:
            if item.shape_name:
                shape_values[item.shape_name] = 0.0

        for item in group.shape_xy_list:
            if item.shape_name in obj.data.shape_keys.key_blocks:
                mode = item.blend_mode
                if mode == 'AUTO':
                    is_x = abs(item.target_y) < 0.001 and abs(item.target_x) > 0.001
                    is_y = abs(item.target_x) < 0.001 and abs(item.target_y) > 0.001
                    if is_x:
                        mode = 'AXIS_X'
                    elif is_y:
                        mode = 'AXIS_Y'
                    else:
                        mode = 'BOX'

                if mode == 'AXIS_X':
                    dist = abs(val_x - item.target_x)
                elif mode == 'AXIS_Y':
                    dist = abs(val_y - item.target_y)
                elif mode == 'BOX':
                    dist = max(abs(val_x - item.target_x), abs(val_y - item.target_y))
                else:
                    dist = math.hypot(val_x - item.target_x, val_y - item.target_y)

                val = max(0.0, 1.0 - (dist / item.radius)) if item.radius > 0 else 0.0
                val = max(0.0, min(1.0, float(val)))
                shape_values[item.shape_name] = max(shape_values.get(item.shape_name, 0.0), val)

        updated = False
        for sk_name, val in shape_values.items():
            if sk_name in obj.data.shape_keys.key_blocks:
                sk = obj.data.shape_keys.key_blocks[sk_name]
                slider_min = float(getattr(sk, 'slider_min', 0.0))
                slider_max = float(getattr(sk, 'slider_max', 1.0))
                target = max(slider_min, min(slider_max, float(val)))
                if abs(sk.value - target) > 0.0001:
                    sk.value = target
                    updated = True

        if updated:
            obj.data.update()
