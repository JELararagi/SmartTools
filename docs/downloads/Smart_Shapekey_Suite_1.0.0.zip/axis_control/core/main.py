# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Apply position-dependent shape-key values for the two-axis controller."""

from collections import defaultdict
from math import hypot

AXIS_TOLERANCE = 0.001
VALUE_TOLERANCE = 0.0001


def get_active_group(obj):
    groups = getattr(obj, "shape_xy_groups", ())
    index = getattr(obj, "shape_xy_group_index", -1)
    return groups[index] if 0 <= index < len(groups) else None


def unique_group_name(groups, base):
    existing = {str(group.name) for group in groups}
    if base not in existing:
        return base
    suffix = 1
    while (name := f"{base}.{suffix:03d}") in existing:
        suffix += 1
    return name


def get_limit(group):
    limit = 1.0
    for item in getattr(group, "shape_xy_list", ()):
        for coordinate in (item.target_x, item.target_y):
            try:
                limit = max(limit, abs(float(coordinate)))
            except (TypeError, ValueError, OverflowError):
                continue
    return limit


def _distance(item, cursor_x, cursor_y):
    dx = abs(cursor_x - item.target_x)
    dy = abs(cursor_y - item.target_y)
    mode = item.blend_mode
    if mode == "AUTO":
        magnitudes = (abs(item.target_x), abs(item.target_y))
        if magnitudes[0] > AXIS_TOLERANCE > magnitudes[1]:
            return dx
        if magnitudes[1] > AXIS_TOLERANCE > magnitudes[0]:
            return dy
        return max(dx, dy)
    if mode == "AXIS_X":
        return dx
    if mode == "AXIS_Y":
        return dy
    return max(dx, dy) if mode == "BOX" else hypot(dx, dy)


def update_shapes(obj, group, limit):
    if getattr(obj, "type", None) != "MESH":
        return
    keys = getattr(obj.data, "shape_keys", None)
    if keys is None:
        return
    x, y = group.joy_x * limit, group.joy_y * limit
    weights = defaultdict(float)
    for item in group.shape_xy_list:
        if not item.shape_name or keys.key_blocks.get(item.shape_name) is None:
            continue
        strength = max(0.0, 1.0 - _distance(item, x, y) / item.radius) if item.radius > 0 else 0.0
        weights[item.shape_name] = max(weights[item.shape_name], min(1.0, strength))
    edited = False
    for name, weight in weights.items():
        key = keys.key_blocks[name]
        value = min(key.slider_max, max(key.slider_min, weight))
        if abs(key.value - value) > VALUE_TOLERANCE:
            key.value = value
            edited = True
    if edited:
        obj.data.update()
