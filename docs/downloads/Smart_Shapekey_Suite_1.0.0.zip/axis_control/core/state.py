# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Session state of the axis control overlay."""


def _initial_hud():
    return dict(
        running=False, handle=None, x=50, y=120, size=200,
        dragging=False, dragging_hud=False, drag_offset_x=0.0, drag_offset_y=0.0,
        dragging_target_idx=-1, drag_start_limit=1.0,
    )


HUD_STATE = _initial_hud()
