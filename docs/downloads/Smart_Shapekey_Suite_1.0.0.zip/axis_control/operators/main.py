# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None

import math
import json
import os
import threading
from dataclasses import dataclass
from typing import Any
from bpy_extras import anim_utils
from bpy_extras.io_utils import ExportHelper, ImportHelper
from ..core.state import HUD_STATE
from ..core.main import get_active_group, get_limit, unique_group_name, update_shapes
from ..ui import draw as _axis_draw
try:
    from ..ui import properties as _axis_properties
except Exception:
    _axis_properties = None


def _set_axis_property_update_suppressed(value: bool) -> None:
    setter = getattr(_axis_properties, 'set_axis_property_update_suppressed', None) if _axis_properties is not None else None
    if callable(setter):
        try:
            setter(bool(value))
        except Exception:
            pass



def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, "preferences", None), "view", None)
    if view is None:
        prefs = getattr(getattr(bpy, "context", None), "preferences", None)
        view = getattr(prefs, "view", None)
    language = str(getattr(view, "language", "DEFAULT") or "DEFAULT").upper()
    return language.startswith("JA")


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


def _iter_view3d_targets(context):
    current_window = getattr(context, "window", None)
    wm = getattr(context, "window_manager", None)
    windows = []
    if current_window is not None:
        windows.append(current_window)
    for window in tuple(getattr(wm, "windows", ()) or ()):
        if window is not current_window:
            windows.append(window)

    for window in windows:
        screen = getattr(window, "screen", None)
        for area in tuple(getattr(screen, "areas", ()) or ()):
            if getattr(area, "type", None) != 'VIEW_3D':
                continue
            region = next((region for region in tuple(getattr(area, "regions", ()) or ()) if getattr(region, "type", None) == 'WINDOW'), None)
            if region is not None:
                yield window, area, region


def _find_view3d_target(context):
    return next(_iter_view3d_targets(context), (None, None, None))


def _save_panel_settings(context=None):
    try:
        from ... import runtime
        saver = getattr(runtime, 'save_current_panel_settings', None)
        if callable(saver):
            saver(context if context is not None else getattr(bpy, 'context', None))
    except Exception:
        pass


def _tag_view3d_redraw(context):
    try:
        area = getattr(context, "area", None)
        if getattr(area, "type", None) == 'VIEW_3D':
            area.tag_redraw()
            return
    except Exception:
        pass
    for _window, area, _region in _iter_view3d_targets(context):
        try:
            area.tag_redraw()
        except Exception:
            pass


_AXIS_LOCK = threading.RLock()
_ACTIVE_AXIS_OPERATOR = None
_AXIS_CANCEL_ERRORS = 0
_AXIS_FINISH_ERRORS = 0


def _activity_module():
    from ... import activity
    return activity


def _serialize_keyframe_point(point) -> dict[str, Any]:
    data: dict[str, Any] = {
        'co': tuple(float(v) for v in point.co),
        'handle_left': tuple(float(v) for v in point.handle_left),
        'handle_right': tuple(float(v) for v in point.handle_right),
    }
    for name in (
        'handle_left_type', 'handle_right_type', 'interpolation', 'easing',
        'type', 'amplitude', 'back', 'period',
    ):
        if hasattr(point, name):
            try:
                data[name] = getattr(point, name)
            except Exception:
                pass
    return data


def _owner_channelbag(owner, *, ensure: bool = False):
    # Blender 5 keeps F-Curves in the channelbag of the slot the owner is assigned to.
    animation_data = getattr(owner, 'animation_data', None) if owner is not None else None
    action = getattr(animation_data, 'action', None) if animation_data is not None else None
    slot = getattr(animation_data, 'action_slot', None) if animation_data is not None else None
    if action is None or slot is None:
        return None
    if ensure:
        return anim_utils.action_ensure_channelbag_for_slot(action, slot)
    return anim_utils.action_get_channelbag_for_slot(action, slot)


def _action_has_fcurves(action) -> bool:
    return any(
        len(channelbag.fcurves) > 0
        for layer in action.layers
        for strip in layer.strips
        for channelbag in getattr(strip, 'channelbags', ())
    )


def _snapshot_animation_paths(owner, paths: tuple[tuple[str, int], ...]) -> dict[str, Any]:
    animation_data = getattr(owner, 'animation_data', None) if owner is not None else None
    action = getattr(animation_data, 'action', None) if animation_data is not None else None
    channelbag = _owner_channelbag(owner)
    rows: list[dict[str, Any]] = []
    for data_path, array_index in paths:
        fcurve = None
        if channelbag is not None:
            try:
                fcurve = channelbag.fcurves.find(data_path, index=int(array_index))
            except Exception:
                fcurve = None
        row: dict[str, Any] = {
            'data_path': str(data_path),
            'array_index': int(array_index),
            'existed': fcurve is not None,
            'points': (),
            'group_name': '',
            'extrapolation': 'CONSTANT',
        }
        if fcurve is not None:
            try:
                row['points'] = tuple(_serialize_keyframe_point(p) for p in tuple(fcurve.keyframe_points))
            except Exception:
                row['points'] = ()
            try:
                row['group_name'] = str(getattr(getattr(fcurve, 'group', None), 'name', '') or '')
            except Exception:
                pass
            try:
                row['extrapolation'] = str(fcurve.extrapolation)
            except Exception:
                pass
        rows.append(row)
    return {
        'owner': owner,
        'animation_data_existed': animation_data is not None,
        'action': action,
        'rows': tuple(rows),
    }


def _remove_fcurve(channelbag, fcurve) -> None:
    if channelbag is None or fcurve is None:
        return
    try:
        channelbag.fcurves.remove(fcurve)
    except Exception:
        pass


def _restore_keyframe_points(fcurve, points: tuple[dict[str, Any], ...]) -> None:
    collection = getattr(fcurve, 'keyframe_points', None)
    if collection is None:
        return
    try:
        for point in reversed(tuple(collection)):
            collection.remove(point)
    except Exception:
        try:
            collection.clear()
        except Exception:
            pass
    for point_data in points:
        co = point_data.get('co', (0.0, 0.0))
        try:
            point = collection.insert(float(co[0]), float(co[1]), options={'FAST'})
        except TypeError:
            point = collection.insert(float(co[0]), float(co[1]))
        for name, value in point_data.items():
            if name == 'co' or not hasattr(point, name):
                continue
            try:
                setattr(point, name, value)
            except Exception:
                pass
    try:
        fcurve.update()
    except Exception:
        pass


def _restore_animation_paths(snapshot: dict[str, Any]) -> None:
    owner = snapshot.get('owner')
    if owner is None:
        return
    original_action = snapshot.get('action')
    animation_data = getattr(owner, 'animation_data', None)
    current_action = getattr(animation_data, 'action', None) if animation_data is not None else None

    if original_action is not None:
        if animation_data is None:
            try:
                animation_data = owner.animation_data_create()
            except Exception:
                animation_data = None
        if animation_data is not None and current_action is not original_action:
            try:
                animation_data.action = original_action
                current_action = original_action
            except Exception:
                pass
    action = original_action if original_action is not None else current_action
    if action is not None:
        needs_channelbag = any(bool(row.get('existed')) for row in snapshot.get('rows', ()))
        channelbag = _owner_channelbag(owner, ensure=needs_channelbag)
        for row in snapshot.get('rows', ()):
            path = row['data_path']
            index = int(row['array_index'])
            try:
                fcurve = channelbag.fcurves.find(path, index=index) if channelbag is not None else None
            except Exception:
                fcurve = None
            if not bool(row.get('existed')):
                _remove_fcurve(channelbag, fcurve)
                continue
            if fcurve is None:
                try:
                    group_name = str(row.get('group_name') or '')
                    fcurve = channelbag.fcurves.new(path, index=index, group_name=group_name)
                except Exception:
                    continue
            try:
                fcurve.extrapolation = row.get('extrapolation', fcurve.extrapolation)
            except Exception:
                pass
            _restore_keyframe_points(fcurve, tuple(row.get('points', ())))

    if original_action is None:
        # Only paths created by this HUD session are removed.  The newly-created
        # action is discarded only when it has no remaining curves and is not
        # shared by another datablock.
        animation_data = getattr(owner, 'animation_data', None)
        action = getattr(animation_data, 'action', None) if animation_data is not None else None
        if action is not None:
            channelbag = _owner_channelbag(owner)
            for row in snapshot.get('rows', ()):
                try:
                    fcurve = channelbag.fcurves.find(row['data_path'], index=int(row['array_index'])) if channelbag is not None else None
                except Exception:
                    fcurve = None
                _remove_fcurve(channelbag, fcurve)
            try:
                empty = not _action_has_fcurves(action)
            except Exception:
                empty = False
            if empty and animation_data is not None:
                try:
                    animation_data.action = None
                except Exception:
                    pass
                try:
                    if getattr(action, 'users', 1) == 0:
                        bpy.data.actions.remove(action)
                except Exception:
                    pass
        if not bool(snapshot.get('animation_data_existed')):
            try:
                owner.animation_data_clear()
            except Exception:
                pass


def _group_animation_paths(group) -> tuple[tuple[str, int], ...]:
    paths: list[tuple[str, int]] = []
    for prop_name in ('joy_x', 'joy_y'):
        try:
            paths.append((str(group.path_from_id(prop_name)), 0))
        except Exception:
            pass
    return tuple(paths)


def _shape_key_animation_paths(key_data) -> tuple[tuple[str, int], ...]:
    rows: list[tuple[str, int]] = []
    for key_block in tuple(getattr(key_data, 'key_blocks', ()) or ()):
        try:
            rows.append((str(key_block.path_from_id('value')), 0))
        except Exception:
            pass
    return tuple(rows)


def _session_group(obj, index: int, name: str):
    groups = getattr(obj, 'shape_xy_groups', None)
    if groups is None:
        return None
    if 0 <= index < len(groups) and str(groups[index].name) == name:
        return groups[index]
    return next((candidate for candidate in groups if str(candidate.name) == name), None)


def _detach_action_snapshot(kind: str, snapshot: dict[str, Any]) -> dict[str, Any]:
    action = snapshot.get('action')
    return {
        'kind': kind,
        'action_name': str(action.name) if action is not None else '',
        'animation_data_existed': snapshot.get('animation_data_existed'),
        'rows': snapshot.get('rows', ()),
    }


def _attach_action_snapshot(obj, detached: dict[str, Any]) -> dict[str, Any] | None:
    owner = obj
    if detached.get('kind') == 'shape_keys':
        owner = getattr(getattr(obj, 'data', None), 'shape_keys', None)
    if owner is None:
        return None
    action_name = str(detached.get('action_name') or '')
    action = bpy.data.actions.get(action_name) if action_name else None
    if action_name and action is None:
        return None
    return {
        'owner': owner,
        'action': action,
        'animation_data_existed': detached.get('animation_data_existed'),
        'rows': detached.get('rows', ()),
    }


def _snapshot_axis_session(context, obj, group) -> dict[str, Any]:
    # Undo re-creates every datablock during the modal session, so the snapshot
    # keeps names and indices only and looks everything up again on restore.
    view_layer = getattr(context, 'view_layer', None)
    selected = tuple(getattr(context, 'selected_objects', ()) or ())
    active = getattr(getattr(view_layer, 'objects', None), 'active', None)
    mode = str(getattr(active, 'mode', 'OBJECT') or 'OBJECT') if active is not None else 'OBJECT'
    tool_settings = getattr(getattr(context, 'scene', None), 'tool_settings', None)
    auto_key = bool(getattr(tool_settings, 'use_keyframe_insert_auto', False)) if tool_settings is not None else False
    shape_values = []
    key_data = getattr(getattr(obj, 'data', None), 'shape_keys', None) if obj is not None else None
    for key_block in tuple(getattr(key_data, 'key_blocks', ()) or ()):
        try:
            shape_values.append((str(key_block.name), float(key_block.value)))
        except Exception:
            pass
    mappings = []
    for index, item in enumerate(tuple(getattr(group, 'shape_xy_list', ()) or ())):
        try:
            mappings.append((index, float(item.target_x), float(item.target_y), float(item.radius)))
        except Exception:
            pass
    action_snapshots = []
    if group is not None:
        group_owner = getattr(group, 'id_data', None)
        paths = _group_animation_paths(group)
        if group_owner is not None and paths:
            action_snapshots.append(_detach_action_snapshot('object', _snapshot_animation_paths(group_owner, paths)))
    if key_data is not None:
        paths = _shape_key_animation_paths(key_data)
        if paths:
            action_snapshots.append(_detach_action_snapshot('shape_keys', _snapshot_animation_paths(key_data, paths)))
    return {
        'object_name': str(obj.name) if obj is not None else '',
        'group_name': str(group.name) if group is not None else '',
        'group_index': int(getattr(obj, 'shape_xy_group_index', -1)) if group is not None else -1,
        'group_joy': (
            float(getattr(group, 'joy_x', 0.0)),
            float(getattr(group, 'joy_y', 0.0)),
        ) if group is not None else (0.0, 0.0),
        'shape_values': tuple(shape_values),
        'mappings': tuple(mappings),
        'actions': tuple(action_snapshots),
        'selected': tuple(str(candidate.name) for candidate in selected),
        'active': str(active.name) if active is not None else '',
        'mode': mode,
        'auto_key': auto_key,
        'hud_position': (
            float(HUD_STATE.get('x', 50.0)),
            float(HUD_STATE.get('y', 120.0)),
            float(HUD_STATE.get('size', 200.0)),
        ),
    }


def _restore_axis_context(context, snapshot: dict[str, Any]) -> None:
    tool_settings = getattr(getattr(context, 'scene', None), 'tool_settings', None)
    if tool_settings is not None:
        try:
            tool_settings.use_keyframe_insert_auto = bool(snapshot.get('auto_key', False))
        except Exception:
            pass
    view_layer = getattr(context, 'view_layer', None)
    view_objects = getattr(view_layer, 'objects', None)
    try:
        for candidate in tuple(view_objects or ()):
            candidate.select_set(False)
    except Exception:
        pass
    for name in snapshot.get('selected', ()):
        candidate = bpy.data.objects.get(name)
        if candidate is None:
            continue
        try:
            candidate.select_set(True)
        except Exception:
            pass
    active = bpy.data.objects.get(str(snapshot.get('active') or ''))
    if view_objects is not None and active is not None:
        try:
            view_objects.active = active
        except Exception:
            pass
    mode = str(snapshot.get('mode') or 'OBJECT')
    if active is not None and mode != 'OBJECT':
        try:
            if getattr(active, 'mode', 'OBJECT') != mode:
                bpy.ops.object.mode_set(mode=mode)
        except Exception:
            pass


def _restore_axis_session(context, snapshot: dict[str, Any]) -> None:
    obj = bpy.data.objects.get(str(snapshot.get('object_name') or ''))
    group = _session_group(obj, int(snapshot.get('group_index', -1)), str(snapshot.get('group_name') or '')) if obj is not None else None
    _set_axis_property_update_suppressed(True)
    try:
        if group is not None:
            joy_x, joy_y = snapshot.get('group_joy', (0.0, 0.0))
            try:
                group.joy_x = float(joy_x)
                group.joy_y = float(joy_y)
            except Exception:
                pass
        items = getattr(group, 'shape_xy_list', ()) if group is not None else ()
        for index, target_x, target_y, radius in snapshot.get('mappings', ()):
            if index >= len(items):
                continue
            item = items[index]
            try:
                item.target_x = float(target_x)
                item.target_y = float(target_y)
                item.radius = float(radius)
            except Exception:
                pass
    finally:
        _set_axis_property_update_suppressed(False)
    for detached in snapshot.get('actions', ()):
        action_snapshot = _attach_action_snapshot(obj, detached)
        if action_snapshot is None:
            continue
        try:
            _restore_animation_paths(action_snapshot)
        except Exception:
            pass
    hud_x, hud_y, hud_size = snapshot.get('hud_position', (50.0, 120.0, 200.0))
    HUD_STATE['x'] = hud_x
    HUD_STATE['y'] = hud_y
    HUD_STATE['size'] = hud_size
    if obj is not None and group is not None:
        try:
            update_shapes(obj, group, get_limit(group))
        except Exception:
            pass
    # Mapping evaluation can write Shape Key values. Restore the exact invoke-time
    # values last so Esc/right-click/reload is a true transaction rollback even
    # when the user had manual values not derivable from the current mapping.
    key_blocks = getattr(getattr(getattr(obj, 'data', None), 'shape_keys', None), 'key_blocks', None)
    for name, value in snapshot.get('shape_values', ()):
        key_block = key_blocks.get(name) if key_blocks is not None else None
        if key_block is None:
            continue
        try:
            key_block.value = float(value)
        except Exception:
            pass
    _restore_axis_context(context, snapshot)


def _refresh_hud_after_undo(*_args) -> None:
    context = getattr(bpy, 'context', None)
    obj = getattr(context, 'active_object', None)
    group = get_active_group(obj) if obj is not None else None
    if group is None:
        _axis_draw.clear_snapshot()
    else:
        _axis_draw.update_snapshot(obj, group, context)
    _tag_view3d_redraw(context)


def _reset_hud_state() -> None:
    HUD_STATE['running'] = False
    HUD_STATE['handle'] = None
    HUD_STATE['dragging'] = False
    HUD_STATE['dragging_hud'] = False
    HUD_STATE['dragging_target_idx'] = -1
    HUD_STATE.pop('operator_token', None)
    _axis_draw.clear_snapshot()


def stop_axis_hud(*, rollback: bool = False, context=None) -> bool:
    """Exact, idempotent HUD teardown used by Esc, load_pre and unregister."""
    global _ACTIVE_AXIS_OPERATOR, _AXIS_FINISH_ERRORS
    with _AXIS_LOCK:
        operator = _ACTIVE_AXIS_OPERATOR
    if operator is not None:
        try:
            operator._finish_session(context or getattr(bpy, 'context', None), rollback=bool(rollback))
            return True
        except Exception:
            _AXIS_FINISH_ERRORS = min(_AXIS_FINISH_ERRORS + 1, 2**31 - 1)
    try:
        ok = bool(_activity_module().teardown_feature('axis_hud'))
    except Exception:
        ok = False
    if ok:
        with _AXIS_LOCK:
            _ACTIVE_AXIS_OPERATOR = None
        _reset_hud_state()
    return ok


def _stop_hud_now(context) -> bool:
    return stop_axis_hud(rollback=False, context=context)


class SHAPE_XY_OT_edit_values(bpy.types.Operator):
    bl_idname = "shape_xy.edit_values"
    bl_label = _ui_text("Edit X and Y Values", "X と Y の値を編集")
    bl_description = _ui_text("Manually input exact X and Y coordinates for the current group's joystick.", "現在のグループのジョイスティックに対して、正確な X と Y 座標を手入力します。")
    bl_options = {'UNDO'}

    input_x: bpy.props.FloatProperty(name=_ui_text("X Value", "X 値"), description=_ui_text("Exact X coordinate to write into the current group joystick.", "現在のグループのジョイスティックへ書き込む正確な X 座標です。"))
    input_y: bpy.props.FloatProperty(name=_ui_text("Y Value", "Y 値"), description=_ui_text("Exact Y coordinate to write into the current group joystick.", "現在のグループのジョイスティックへ書き込む正確な Y 座標です。"))

    def invoke(self, context, event):
        obj = context.active_object
        group = get_active_group(obj)
        if not group:
            return {'CANCELLED'}
        limit = get_limit(group) or 1.0
        if abs(limit) < 1.0e-8:
            limit = 1.0
        self.input_x = group.joy_x * limit
        self.input_y = group.joy_y * limit
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if group:
            limit = get_limit(group) or 1.0
            if abs(limit) < 1.0e-8:
                limit = 1.0
            group.joy_x = max(-1.0, min(1.0, self.input_x / limit))
            group.joy_y = max(-1.0, min(1.0, self.input_y / limit))
            update_shapes(obj, group, limit)
            _tag_view3d_redraw(context)
            _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_reset_handle(bpy.types.Operator):
    bl_idname = "shape_xy.reset_handle"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Reset Handle", "ハンドルをリセット")
    bl_description = _ui_text("Reset the active group joystick handle to center (0.0, 0.0).", "アクティブグループのジョイスティックハンドルを中央 (0.0, 0.0) に戻します。")

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if group:
            group.joy_x = 0.0
            group.joy_y = 0.0
            update_shapes(obj, group, get_limit(group))
            _tag_view3d_redraw(context)
            _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_reset_all(bpy.types.Operator):
    bl_idname = "shape_xy.reset_all"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Reset All Handles", "すべてのハンドルをリセット")
    bl_description = _ui_text("Reset every joystick handle across all groups and objects to center (0.0, 0.0).", "すべてのオブジェクト・すべてのグループのジョイスティックハンドルを中央 (0.0, 0.0) に戻します。")

    def execute(self, context):
        for obj in context.scene.objects:
            if hasattr(obj, 'shape_xy_groups'):
                for group in obj.shape_xy_groups:
                    group.joy_x = 0.0
                    group.joy_y = 0.0
                    update_shapes(obj, group, get_limit(group))
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_keyframe_handle(bpy.types.Operator):
    bl_idname = "shape_xy.keyframe_handle"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Keyframe Handle", "ハンドルにキーフレーム")
    bl_description = _ui_text("Insert keyframes for the current group joystick handle at the current frame.", "現在フレームで、現在のグループのジョイスティックハンドルへキーフレームを挿入します。")

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if group is None:
            self.report({'WARNING'}, _ui_text("Select a joystick group before inserting keyframes.", "キーフレームを挿入する前にジョイスティックグループを選択してください。", context))
            return {'CANCELLED'}
        group.keyframe_insert(data_path="joy_x")
        group.keyframe_insert(data_path="joy_y")
        self.report({'INFO'}, _ui_text("Keyframes inserted for the handle", "ハンドルにキーフレームを挿入しました", context))
        return {'FINISHED'}


class SHAPE_XY_OT_bake_animation(bpy.types.Operator):
    bl_idname = "shape_xy.bake_animation"
    bl_label = _ui_text("Bake Animation to Shape Keys", "アニメーションをシェイプキーにベイク")
    bl_description = _ui_text("Bake the animated joystick logic into raw Shape Key keyframes for export such as FBX or glTF.", "アニメーションしたジョイスティック制御を、FBX や glTF などへ書き出しやすいシェイプキーキーフレームへベイクします。")
    bl_options = {'UNDO'}

    start_frame: bpy.props.IntProperty(name=_ui_text("Start Frame", "開始フレーム"), description=_ui_text("First frame included in the bake range.", "ベイク範囲に含める最初のフレームです。"), default=1)
    end_frame: bpy.props.IntProperty(name=_ui_text("End Frame", "終了フレーム"), description=_ui_text("Last frame included in the bake range.", "ベイク範囲に含める最後のフレームです。"), default=250)
    step: bpy.props.IntProperty(name=_ui_text("Step", "ステップ"), description=_ui_text("Bake every Nth frame. Use 1 to bake every frame.", "何フレームごとにベイクするかを指定します。1 なら毎フレームです。"), default=1, min=1)

    def invoke(self, context, event):
        self.start_frame = context.scene.frame_start
        self.end_frame = context.scene.frame_end
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if not group or not hasattr(group, 'shape_xy_list'):
            return {'CANCELLED'}

        if self.end_frame < self.start_frame:
            self.report({'ERROR'}, _ui_text("End Frame must be greater than or equal to Start Frame.", "終了フレームは開始フレーム以上にしてください。", context))
            return {'CANCELLED'}

        original_frame = context.scene.frame_current

        # Prepare shapekeys
        if not obj.data or not hasattr(obj.data, 'shape_keys') or not obj.data.shape_keys:
            self.report({'ERROR'}, _ui_text("Object has no Shape Keys.", "オブジェクトにシェイプキーがありません。", context))
            return {'CANCELLED'}

        shape_names = [item.shape_name for item in group.shape_xy_list if item.shape_name in obj.data.shape_keys.key_blocks]
        if not shape_names:
            self.report({'ERROR'}, _ui_text("No valid Shape Keys are mapped in this group.", "このグループには有効なシェイプキーマッピングがありません。", context))
            return {'CANCELLED'}

        limit = get_limit(group) or 1.0
        if abs(limit) < 1.0e-8:
            limit = 1.0

        key_data = obj.data.shape_keys
        bake_paths = tuple(
            (str(key_data.key_blocks[name].path_from_id("value")), 0)
            for name in shape_names
        )
        animation_snapshot = _snapshot_animation_paths(key_data, bake_paths)
        value_snapshot = tuple((key_data.key_blocks[name], float(key_data.key_blocks[name].value)) for name in shape_names)
        count = 0
        try:
            for f in range(self.start_frame, self.end_frame + 1, self.step):
                context.scene.frame_set(f)
                update_shapes(obj, group, limit)
                for name in shape_names:
                    sk = key_data.key_blocks[name]
                    inserted = sk.keyframe_insert(data_path="value", frame=f)
                    if inserted is False:
                        raise RuntimeError(f"keyframe insertion failed for {name} at frame {f}")
                    count += 1
        except Exception as exc:
            # Restore existing curves/keyframes byte-for-byte at the RNA value
            # level and delete every keyframe/action created by this attempt.
            try:
                _restore_animation_paths(animation_snapshot)
            except Exception:
                pass
            for key_block, value in value_snapshot:
                try:
                    key_block.value = value
                except Exception:
                    pass
            self.report({'ERROR'}, _ui_text("Bake failed: " + _sss_translation.exception_text(exc, context), "ベイクに失敗しました: " + _sss_translation.exception_text(exc, context), context))
            return {'CANCELLED'}
        finally:
            try:
                context.scene.frame_set(original_frame)
            except Exception:
                pass

        self.report({'INFO'}, _ui_text(f"Baked {count} keyframes from frame {self.start_frame} to {self.end_frame}.", f"フレーム {self.start_frame} から {self.end_frame} まで {count} 個のキーフレームをベイクしました。", context))
        return {'FINISHED'}

class SHAPE_XY_OT_export_group(bpy.types.Operator, ExportHelper):
    bl_idname = "shape_xy.export_group"
    bl_label = _ui_text("Export Group Settings", "グループ設定を書き出し")
    bl_description = _ui_text("Export the current ShapeKey group mappings to a JSON file.", "現在のシェイプキー グループのマッピングを JSON ファイルへ書き出します。")

    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'},
        description=_ui_text(
            "File browser filter that shows JSON group setting files.",
            "JSON グループ設定ファイルをファイルブラウザーに表示するためのフィルターです。",
        ),
    )

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if not group or not hasattr(group, 'shape_xy_list'):
            return {'CANCELLED'}

        filepath = str(getattr(self, 'filepath', '') or '').strip()
        if not filepath:
            self.report({'WARNING'}, _ui_text("Choose where to save the group settings first.", "グループ設定の保存先を選択してください。", context))
            return {'CANCELLED'}

        data = {
            "group_name": group.name,
            "mappings": []
        }

        for item in group.shape_xy_list:
            if item.shape_name:
                data["mappings"].append({
                    "name": item.shape_name,
                    "target_x": item.target_x,
                    "target_y": item.target_y,
                    "radius": item.radius,
                    "blend_mode": item.blend_mode
                })

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
        except Exception as exc:
            self.report({'ERROR'}, _ui_text("Failed to write the file: " + _sss_translation.exception_text(exc, context), "ファイルを書き出せませんでした: " + _sss_translation.exception_text(exc, context), context))
            return {'CANCELLED'}

        self.report({'INFO'}, _ui_text(f"Exported {len(data['mappings'])} mappings.", f"{len(data['mappings'])} 件のマッピングを書き出しました。", context))
        return {'FINISHED'}

class SHAPE_XY_OT_import_group(bpy.types.Operator, ImportHelper):
    bl_idname = "shape_xy.import_group"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Import Group Settings", "グループ設定を読み込み")
    bl_description = _ui_text("Import ShapeKey group mappings from a JSON file.", "JSON ファイルからシェイプキー グループのマッピングを読み込みます。")

    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(
        default="*.json",
        options={'HIDDEN'},
        description=_ui_text(
            "File browser filter that shows JSON group setting files.",
            "JSON グループ設定ファイルをファイルブラウザーに表示するためのフィルターです。",
        ),
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or not hasattr(obj, 'shape_xy_groups'):
            return {'CANCELLED'}

        filepath = str(getattr(self, 'filepath', '') or '').strip()
        if not filepath:
            self.report({'WARNING'}, _ui_text("Choose a group settings file first.", "グループ設定ファイルを選択してください。", context))
            return {'CANCELLED'}

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, _ui_text("Failed to read the file: " + _sss_translation.exception_text(e, context), "ファイルを読み込めませんでした: " + _sss_translation.exception_text(e, context), context))
            return {'CANCELLED'}

        mappings = data.get("mappings") if isinstance(data, dict) else None
        if not isinstance(mappings, list):
            self.report({'ERROR'}, _ui_text("Invalid JSON format.", "JSON 形式が不正です。", context))
            return {'CANCELLED'}

        # Create a new group for the imported data
        name = unique_group_name(obj.shape_xy_groups, str(data.get("group_name") or _ui_text("Imported Group", "読み込みグループ", context)))
        group = obj.shape_xy_groups.add()
        group.name = name
        obj.shape_xy_group_index = len(obj.shape_xy_groups) - 1

        count = 0
        valid_blend_modes = {'AUTO', 'BOX', 'RADIAL', 'AXIS_X', 'AXIS_Y'}
        for info in mappings:
            if not isinstance(info, dict):
                continue
            item = group.shape_xy_list.add()
            item.shape_name = str(info.get("name") or "")
            try:
                item.target_x = float(info.get("target_x", 1.0))
                item.target_y = float(info.get("target_y", 0.0))
                item.radius = max(0.001, float(info.get("radius", 1.0)))
            except Exception:
                item.target_x = 1.0
                item.target_y = 0.0
                item.radius = 1.0
            blend_mode = str(info.get("blend_mode") or 'AUTO')
            item.blend_mode = blend_mode if blend_mode in valid_blend_modes else 'AUTO'
            count += 1

        _save_panel_settings(context)
        self.report({'INFO'}, _ui_text(f"Imported a new group with {count} mappings.", f"{count} 件のマッピングを含む新規グループを読み込みました。", context))
        return {'FINISHED'}

class SHAPE_XY_OT_reset_hud(bpy.types.Operator):
    bl_idname = "shape_xy.reset_hud"
    bl_label = _ui_text("Reset Modal HUD", "モーダル HUD をリセット")
    bl_description = _ui_text("Reset the Axis UI position back to its default on-screen location.", "シェイプ軸 HUD の位置を既定の画面内位置へ戻します。")

    def execute(self, context):
        HUD_STATE["x"] = 50
        HUD_STATE["y"] = 120
        HUD_STATE["size"] = 200
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_ui_joystick(bpy.types.Operator):
    bl_idname = "shape_xy.ui_joystick"
    bl_options = {'UNDO', 'BLOCKING', 'INTERNAL'}
    bl_label = _ui_text("Toggle Axis UI", "シェイプ軸 HUD を切り替え")
    bl_description = _ui_text(
        "Start or stop the interactive 2D HUD Axis controller. Esc or right-click cancels the session and restores Shape Key values, mapping targets, auto-key state, selection, mode, and keyframes created by the session.",
        '対話式のシェイプ軸 HUD を開始または停止します。Esc または右クリックでセッションをキャンセルし、シェイプキー値、マッピング位置、自動キー状態、選択、モード、セッション中に追加したキーフレームを復元します。',
    )

    _session_snapshot = None
    _activity_token = None
    _finished = False
    _cancelled = False

    def _active_target(self, context):
        obj = getattr(context, 'active_object', None)
        group = get_active_group(obj) if obj is not None else None
        limit = get_limit(group) if group is not None else 1.0
        try:
            limit = float(limit)
        except Exception:
            limit = 1.0
        if abs(limit) < 1.0e-8:
            limit = 1.0
        return obj, group, limit

    def _refresh_draw_snapshot(self, context, obj=None, group=None) -> None:
        if obj is None or group is None:
            obj, group, _limit = self._active_target(context)
        if obj is None or group is None:
            _axis_draw.clear_snapshot()
        else:
            _axis_draw.update_snapshot(obj, group, context)
        _tag_view3d_redraw(context)

    def _finish_session(self, context, *, rollback: bool) -> None:
        global _ACTIVE_AXIS_OPERATOR, _AXIS_CANCEL_ERRORS
        if self._finished:
            return
        self._finished = True
        self._cancelled = bool(rollback)
        if rollback and self._session_snapshot is not None:
            try:
                _restore_axis_session(context or getattr(bpy, 'context', None), self._session_snapshot)
            except Exception:
                _AXIS_CANCEL_ERRORS = min(_AXIS_CANCEL_ERRORS + 1, 2**31 - 1)
        try:
            _activity_module().teardown_feature('axis_hud')
        except Exception:
            pass
        with _AXIS_LOCK:
            if _ACTIVE_AXIS_OPERATOR is self:
                _ACTIVE_AXIS_OPERATOR = None
        _reset_hud_state()
        if not rollback:
            _save_panel_settings(context)
        _tag_view3d_redraw(context or getattr(bpy, 'context', None))

    def cancel(self, context):
        self._finish_session(context, rollback=True)

    def finish(self, context):
        self._finish_session(context, rollback=False)

    def _modal_impl(self, context, event):
        activity = _activity_module()
        if self._activity_token is None or not activity.token_is_current(self._activity_token):
            self._finish_session(context, rollback=True)
            return {'CANCELLED'}
        if not HUD_STATE.get('running', False):
            return {'CANCELLED'} if self._cancelled else {'FINISHED'}

        area = getattr(context, 'area', None)
        if getattr(area, 'type', None) != 'VIEW_3D':
            return {'PASS_THROUGH'}

        event_type = str(getattr(event, 'type', '') or '')
        event_value = str(getattr(event, 'value', '') or '')
        if event_type == 'ESC' and event_value in {'PRESS', 'CLICK', ''}:
            self._finish_session(context, rollback=True)
            return {'CANCELLED'}

        dragging_target = HUD_STATE.get('dragging_target_idx', -1) >= 0
        dragging_hud = bool(HUD_STATE.get('dragging_hud', False))
        dragging_handle = bool(HUD_STATE.get('dragging', False))
        active_drag = dragging_target or dragging_hud or dragging_handle
        if not active_drag and event_type not in {'LEFTMOUSE', 'MOUSEMOVE', 'RIGHTMOUSE', 'I'}:
            return {'PASS_THROUGH'}

        window_region = next(
            (region for region in tuple(getattr(area, 'regions', ()) or ()) if getattr(region, 'type', None) == 'WINDOW'),
            None,
        )
        if window_region is None:
            return {'PASS_THROUGH'}

        x = float(HUD_STATE.get('x', 50.0))
        y = float(HUD_STATE.get('y', 120.0))
        size = max(32.0, float(HUD_STATE.get('size', 200.0)))
        is_in_window = (
            window_region.x <= event.mouse_x <= window_region.x + window_region.width
            and window_region.y <= event.mouse_y <= window_region.y + window_region.height
        )
        if is_in_window:
            mx = float(event.mouse_x - window_region.x)
            my = float(event.mouse_y - window_region.y)
        else:
            mx = float(getattr(event, 'mouse_region_x', 0.0))
            my = float(getattr(event, 'mouse_region_y', 0.0))
        hud_bound = is_in_window and (x - 4 <= mx <= x + size + 4) and (y - 112 <= my <= y + size + 25)

        if event_type == 'RIGHTMOUSE' and event_value in {'PRESS', 'CLICK', ''}:
            if hud_bound or active_drag:
                self._finish_session(context, rollback=True)
                return {'CANCELLED'}
            return {'PASS_THROUGH'}
        if not active_drag:
            if event_type == 'MOUSEMOVE' and not hud_bound:
                return {'PASS_THROUGH'}
            if event_type == 'LEFTMOUSE' and event_value == 'PRESS' and not hud_bound:
                return {'PASS_THROUGH'}
            if event_type == 'I' and event_value == 'PRESS' and not hud_bound:
                return {'PASS_THROUGH'}

        in_joy = is_in_window and x <= mx <= x + size and y <= my <= y + size
        in_header = is_in_window and x <= mx <= x + size and y + size <= my <= y + size + 25
        in_reset = is_in_window and x <= mx <= x + size and y - 35 <= my <= y - 5
        in_edit = is_in_window and x <= mx <= x + size and y - 75 <= my <= y - 40
        in_prev_group = is_in_window and x <= mx <= x + 30 and y - 105 <= my <= y - 80
        in_next_group = is_in_window and x + size - 30 <= mx <= x + size and y - 105 <= my <= y - 80

        obj, group, limit = self._active_target(context)
        obj_name = str(getattr(obj, 'name', '') or '') if obj is not None else ''
        group_name = str(getattr(group, 'name', '') or '') if group is not None else ''
        if hud_bound and not active_drag and (
            obj_name != HUD_STATE.get('last_obj_name', '')
            or group_name != HUD_STATE.get('last_group_name', '')
        ):
            HUD_STATE['last_obj_name'] = obj_name
            HUD_STATE['last_group_name'] = group_name
            self._refresh_draw_snapshot(context, obj, group)

        if event_type == 'LEFTMOUSE':
            if event_value == 'PRESS':
                if (
                    is_in_window and obj is not None and getattr(obj, 'type', None) == 'MESH'
                    and group is not None and hasattr(group, 'shape_xy_list')
                    and bool(getattr(context.scene, 'shape_xy_allow_drag', False))
                ):
                    cx, cy = x + size * 0.5, y + size * 0.5
                    for idx, item in enumerate(tuple(group.shape_xy_list)):
                        px = cx + (float(item.target_x) / limit) * (size * 0.5)
                        py = cy + (float(item.target_y) / limit) * (size * 0.5)
                        if math.hypot(mx - px, my - py) < 12.0:
                            HUD_STATE['dragging_target_idx'] = idx
                            HUD_STATE['drag_start_limit'] = limit
                            return {'RUNNING_MODAL'}
                if in_header:
                    HUD_STATE['dragging_hud'] = True
                    HUD_STATE['drag_offset_x'] = mx - x
                    HUD_STATE['drag_offset_y'] = my - y
                    return {'RUNNING_MODAL'}
                if in_joy and group is not None:
                    HUD_STATE['dragging'] = True
                    return {'RUNNING_MODAL'}
                if in_reset and group is not None:
                    _set_axis_property_update_suppressed(True)
                    try:
                        group.joy_x = 0.0
                        group.joy_y = 0.0
                    finally:
                        _set_axis_property_update_suppressed(False)
                    update_shapes(obj, group, limit)
                    self._refresh_draw_snapshot(context, obj, group)
                    return {'RUNNING_MODAL'}
                if in_edit:
                    bpy.ops.shape_xy.edit_values('INVOKE_DEFAULT')
                    return {'RUNNING_MODAL'}
                if in_prev_group and obj is not None and hasattr(obj, 'shape_xy_groups') and obj.shape_xy_groups:
                    obj.shape_xy_group_index = (obj.shape_xy_group_index - 1) % len(obj.shape_xy_groups)
                    obj, group, _limit = self._active_target(context)
                    self._refresh_draw_snapshot(context, obj, group)
                    return {'RUNNING_MODAL'}
                if in_next_group and obj is not None and hasattr(obj, 'shape_xy_groups') and obj.shape_xy_groups:
                    obj.shape_xy_group_index = (obj.shape_xy_group_index + 1) % len(obj.shape_xy_groups)
                    obj, group, _limit = self._active_target(context)
                    self._refresh_draw_snapshot(context, obj, group)
                    return {'RUNNING_MODAL'}
            elif event_value == 'RELEASE':
                changed = bool(
                    HUD_STATE.get('dragging_hud', False)
                    or HUD_STATE.get('dragging_target_idx', -1) >= 0
                    or HUD_STATE.get('dragging', False)
                )
                HUD_STATE['dragging'] = False
                HUD_STATE['dragging_hud'] = False
                HUD_STATE['dragging_target_idx'] = -1
                if changed:
                    self._refresh_draw_snapshot(context, obj, group)
                    return {'RUNNING_MODAL'}

        if event_type == 'I' and event_value == 'PRESS' and hud_bound and group is not None:
            inserted_x = group.keyframe_insert(data_path='joy_x')
            inserted_y = group.keyframe_insert(data_path='joy_y')
            if inserted_x is False or inserted_y is False:
                raise RuntimeError('Axis handle keyframe insertion failed')
            return {'RUNNING_MODAL'}

        if event_type == 'MOUSEMOVE':
            target_idx = int(HUD_STATE.get('dragging_target_idx', -1))
            if target_idx >= 0:
                if group is not None and 0 <= target_idx < len(group.shape_xy_list):
                    item = group.shape_xy_list[target_idx]
                    cx, cy = x + size * 0.5, y + size * 0.5
                    drag_limit = float(HUD_STATE.get('drag_start_limit', 1.0) or 1.0)
                    new_tx = max(-drag_limit, min(drag_limit, ((mx - cx) / (size * 0.5)) * drag_limit))
                    new_ty = max(-drag_limit, min(drag_limit, ((my - cy) / (size * 0.5)) * drag_limit))
                    if float(item.target_x) != new_tx or float(item.target_y) != new_ty:
                        _set_axis_property_update_suppressed(True)
                        try:
                            item.target_x = new_tx
                            item.target_y = new_ty
                        finally:
                            _set_axis_property_update_suppressed(False)
                        update_shapes(obj, group, limit)
                        self._refresh_draw_snapshot(context, obj, group)
                return {'RUNNING_MODAL'}
            if bool(HUD_STATE.get('dragging_hud', False)):
                new_x = mx - float(HUD_STATE.get('drag_offset_x', 0.0))
                new_y = my - float(HUD_STATE.get('drag_offset_y', 0.0))
                if float(HUD_STATE.get('x', 0.0)) != new_x or float(HUD_STATE.get('y', 0.0)) != new_y:
                    HUD_STATE['x'] = new_x
                    HUD_STATE['y'] = new_y
                    self._refresh_draw_snapshot(context, obj, group)
                return {'RUNNING_MODAL'}
            if bool(HUD_STATE.get('dragging', False)) and group is not None:
                new_x = max(-1.0, min(1.0, (mx - (x + size * 0.5)) / (size * 0.5)))
                new_y = max(-1.0, min(1.0, (my - (y + size * 0.5)) / (size * 0.5)))
                if float(group.joy_x) != new_x or float(group.joy_y) != new_y:
                    _set_axis_property_update_suppressed(True)
                    try:
                        group.joy_x = new_x
                        group.joy_y = new_y
                    finally:
                        _set_axis_property_update_suppressed(False)
                    update_shapes(obj, group, limit)
                    if bool(getattr(context.scene.tool_settings, 'use_keyframe_insert_auto', False)):
                        inserted_x = group.keyframe_insert(data_path='joy_x')
                        inserted_y = group.keyframe_insert(data_path='joy_y')
                        if inserted_x is False or inserted_y is False:
                            raise RuntimeError('Axis auto-key insertion failed')
                    self._refresh_draw_snapshot(context, obj, group)
                return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}

    def modal(self, context, event):
        try:
            return self._modal_impl(context, event)
        except Exception as exc:
            self._finish_session(context, rollback=True)
            self.report(
                {'ERROR'},
                _ui_text(
                    "Axis HUD was cancelled and restored after an error: " + _sss_translation.exception_text(exc, context),
                    "エラーのためシェイプ軸 HUD をキャンセルし、開始前の状態へ復元しました: " + _sss_translation.exception_text(exc, context),
                    context,
                ),
            )
            return {'CANCELLED'}

    def _start_in_view3d(self, context) -> set[str]:
        global _ACTIVE_AXIS_OPERATOR
        obj, group, _limit = self._active_target(context)
        self._session_snapshot = _snapshot_axis_session(context, obj, group)
        activity = _activity_module()
        lease = activity.new_lease('axis_hud', replace=True)
        self._activity_token = lease.token
        try:
            handle = activity.add_draw_handler(
                lease,
                bpy.types.SpaceView3D,
                _axis_draw.draw_hud,
                (),
                'WINDOW',
                'POST_PIXEL',
                label='Axis HUD immutable draw',
            )
            activity.add_handler(lease, bpy.app.handlers.undo_post, _refresh_hud_after_undo, label='Axis HUD undo refresh')
            activity.add_handler(lease, bpy.app.handlers.redo_post, _refresh_hud_after_undo, label='Axis HUD redo refresh')
        except Exception as exc:
            activity.teardown_feature('axis_hud')
            self.report({'ERROR'}, _ui_text("Failed to start Axis UI: " + _sss_translation.exception_text(exc, context), "シェイプ軸 HUD を開始できませんでした: " + _sss_translation.exception_text(exc, context), context))
            return {'CANCELLED'}
        HUD_STATE['handle'] = handle
        HUD_STATE['running'] = True
        HUD_STATE['operator_token'] = lease.token.owner_uuid
        HUD_STATE['last_obj_name'] = str(getattr(obj, 'name', '') or '') if obj is not None else ''
        HUD_STATE['last_group_name'] = str(getattr(group, 'name', '') or '') if group is not None else ''
        with _AXIS_LOCK:
            _ACTIVE_AXIS_OPERATOR = self
        if obj is not None and group is not None and not _axis_draw.update_snapshot(obj, group, context):
            error = _axis_draw.consume_build_error()
            self._finish_session(context, rollback=True)
            self.report({'ERROR'}, _ui_text("Failed to build Axis HUD: " + _sss_translation.exception_text(error, context), "シェイプ軸 HUD を構築できませんでした: " + _sss_translation.exception_text(error, context), context))
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        _tag_view3d_redraw(context)
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        del event
        if HUD_STATE.get('running', False):
            stop_axis_hud(rollback=False, context=context)
            return {'FINISHED'}
        area = getattr(context, 'area', None)
        if getattr(area, 'type', None) == 'VIEW_3D':
            return self._start_in_view3d(context)
        window, view3d_area, region = _find_view3d_target(context)
        if window is None or view3d_area is None or region is None:
            self.report({'ERROR'}, _ui_text("3D View was not found.", "3Dビュー が見つかりません。", context))
            return {'CANCELLED'}
        try:
            with context.temp_override(window=window, area=view3d_area, region=region):
                return self._start_in_view3d(context)
        except Exception as exc:
            self.report({'ERROR'}, _ui_text("Failed to open Axis UI in 3D View: " + _sss_translation.exception_text(exc, context), "3Dビューでシェイプ軸 HUD を開けませんでした: " + _sss_translation.exception_text(exc, context), context))
            return {'CANCELLED'}

class SHAPE_XY_OT_move_item(bpy.types.Operator):
    bl_idname = "shape_xy.move_item"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Move Mapping", "マッピングを移動")
    bl_description = _ui_text("Move the selected ShapeKey mapping up or down in the list.", "選択中のシェイプキーマッピングを一覧内で上下へ移動します。")

    direction: bpy.props.EnumProperty(
        items=(('UP', _ui_text('Up', '上へ'), _ui_text('Move the selected item upward.', '選択項目を上へ移動します。')), ('DOWN', _ui_text('Down', '下へ'), _ui_text('Move the selected item downward.', '選択項目を下へ移動します。'))),
        description=_ui_text('Direction to move the selected item.', '選択項目を移動する方向です。'),
    )

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if group and hasattr(group, 'shape_xy_list'):
            idx = group.shape_xy_index
            new_idx = idx + (-1 if self.direction == 'UP' else 1)
            if 0 <= idx < len(group.shape_xy_list) and 0 <= new_idx < len(group.shape_xy_list):
                group.shape_xy_list.move(idx, new_idx)
                group.shape_xy_index = new_idx
                _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_mirror_mappings(bpy.types.Operator):
    bl_idname = "shape_xy.mirror_mappings"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Mirror Mappings", "マッピングを左右反転")
    bl_description = _ui_text("Automatically generate symmetrical ShapeKey mappings for .L/.R style name pairs.", ".L・.R などの名前ペアから、左右対称のシェイプキーマッピングを自動生成します。")

    def execute(self, context):
        obj = context.active_object
        group = get_active_group(obj)
        if not group or not hasattr(group, 'shape_xy_list'):
            return {'CANCELLED'}

        new_items = []
        for item in group.shape_xy_list:
            name = item.shape_name
            if not name:
                continue

            mirrored_name = None
            if name.endswith('.L'): mirrored_name = name[:-2] + '.R'
            elif name.endswith('.R'): mirrored_name = name[:-2] + '.L'
            elif name.endswith('_L'): mirrored_name = name[:-2] + '_R'
            elif name.endswith('_R'): mirrored_name = name[:-2] + '_L'
            elif name.endswith(' L'): mirrored_name = name[:-2] + ' R'
            elif name.endswith(' R'): mirrored_name = name[:-2] + ' L'

            # Check if this mirrored shapekey actually exists on the mesh
            if mirrored_name and obj.data and hasattr(obj.data, 'shape_keys') and obj.data.shape_keys:
                if mirrored_name in obj.data.shape_keys.key_blocks:
                    # Check if it's already mapped in this group
                    already_exists = any(mapped.shape_name == mirrored_name for mapped in group.shape_xy_list)
                    if not already_exists:
                        # Prepare mapping info, flipping the target_x across the Y axis
                        new_items.append({
                            'name': mirrored_name,
                            'target_x': -item.target_x,
                            'target_y': item.target_y,
                            'radius': item.radius,
                            'blend_mode': item.blend_mode
                        })

        count = 0
        for info in new_items:
            new_item = group.shape_xy_list.add()
            new_item.shape_name = info['name']
            new_item.target_x = info['target_x']
            new_item.target_y = info['target_y']
            new_item.radius = info['radius']
            new_item.blend_mode = info['blend_mode']
            count += 1

        group.shape_xy_index = len(group.shape_xy_list) - 1
        _save_panel_settings(context)
        self.report({'INFO'}, _ui_text(f"Auto-mirrored {count} Shape Keys.", f"{count} 件のシェイプキーを自動で左右反転追加しました。", context))
        return {'FINISHED'}

class SHAPE_XY_OT_move_group(bpy.types.Operator):
    bl_idname = "shape_xy.move_group"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Move Group", "グループを移動")
    bl_description = _ui_text("Move the selected ShapeKey group up or down in the list.", "選択中のシェイプキー グループを一覧内で上下へ移動します。")

    direction: bpy.props.EnumProperty(
        items=(('UP', _ui_text('Up', '上へ'), _ui_text('Move the selected item upward.', '選択項目を上へ移動します。')), ('DOWN', _ui_text('Down', '下へ'), _ui_text('Move the selected item downward.', '選択項目を下へ移動します。'))),
        description=_ui_text('Direction to move the selected item.', '選択項目を移動する方向です。'),
    )

    def execute(self, context):
        obj = context.active_object
        if obj and hasattr(obj, 'shape_xy_groups'):
            idx = obj.shape_xy_group_index
            new_idx = idx + (-1 if self.direction == 'UP' else 1)
            if 0 <= idx < len(obj.shape_xy_groups) and 0 <= new_idx < len(obj.shape_xy_groups):
                obj.shape_xy_groups.move(idx, new_idx)
                obj.shape_xy_group_index = new_idx
                _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_move_preset(bpy.types.Operator):
    bl_idname = "shape_xy.move_preset"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Move Preset", "プリセットを移動")
    bl_description = _ui_text("Move the selected global animation preset up or down in the list.", "選択中のアニメーションプリセットを一覧内で上下へ移動します。")

    direction: bpy.props.EnumProperty(
        items=(('UP', _ui_text('Up', '上へ'), _ui_text('Move the selected item upward.', '選択項目を上へ移動します。')), ('DOWN', _ui_text('Down', '下へ'), _ui_text('Move the selected item downward.', '選択項目を下へ移動します。'))),
        description=_ui_text('Direction to move the selected item.', '選択項目を移動する方向です。'),
    )

    def execute(self, context):
        presets = context.scene.shape_xy_presets
        idx = context.scene.shape_xy_preset_index
        new_idx = idx + (-1 if self.direction == 'UP' else 1)
        if 0 <= idx < len(presets) and 0 <= new_idx < len(presets):
            presets.move(idx, new_idx)
            context.scene.shape_xy_preset_index = new_idx
            _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_add_preset(bpy.types.Operator):
    bl_idname = "shape_xy.add_preset"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Add Global Preset", "グローバルプリセットを追加")
    bl_description = _ui_text("Create a new global animation preset.", "新しいアニメーションプリセットを作成します。")

    def execute(self, context):
        presets = context.scene.shape_xy_presets
        preset = presets.add()
        preset.name = _ui_text(f"Preset {len(presets)}", f"プリセット {len(presets)}", context)
        context.scene.shape_xy_preset_index = len(presets) - 1
        _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_remove_preset(bpy.types.Operator):
    bl_idname = "shape_xy.remove_preset"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Remove Global Preset", "グローバルプリセットを削除")
    bl_description = _ui_text("Delete the currently selected global animation preset.", "現在選択中のアニメーションプリセットを削除します。")

    def execute(self, context):
        presets = context.scene.shape_xy_presets
        idx = context.scene.shape_xy_preset_index
        if 0 <= idx < len(presets):
            presets.remove(idx)
            if len(presets) > 0:
                context.scene.shape_xy_preset_index = min(max(0, idx - 1), len(presets) - 1)
            else:
                context.scene.shape_xy_preset_index = -1
            _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_set_preset(bpy.types.Operator):
    bl_idname = "shape_xy.set_preset"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Set Global Preset", "グローバルプリセットを保存")
    bl_description = _ui_text("Store the current joystick coordinates of all groups across all objects into this preset.", "すべてのオブジェクト・すべてのグループの現在ジョイスティック座標を、このプリセットへ保存します。")

    def execute(self, context):
        presets = context.scene.shape_xy_presets
        idx = context.scene.shape_xy_preset_index
        if 0 <= idx < len(presets):
            preset = presets[idx]
            preset.states.clear()

            for obj in context.scene.objects:
                if hasattr(obj, 'shape_xy_groups'):
                    for group in obj.shape_xy_groups:
                        state = preset.states.add()
                        state.obj_name = obj.name
                        state.group_name = group.name
                        state.joy_x = group.joy_x
                        state.joy_y = group.joy_y
            _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_call_preset(bpy.types.Operator):
    bl_idname = "shape_xy.call_preset"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Call Global Preset", "グローバルプリセットを呼び出し")
    bl_description = _ui_text("Apply the saved joystick coordinates from this preset to all groups across all objects.", "このプリセットに保存されたジョイスティック座標を、すべてのオブジェクト・すべてのグループへ適用します。")

    def execute(self, context):
        presets = context.scene.shape_xy_presets
        idx = context.scene.shape_xy_preset_index
        if 0 <= idx < len(presets):
            preset = presets[idx]

            for state in preset.states:
                obj = context.scene.objects.get(state.obj_name)
                if obj and hasattr(obj, 'shape_xy_groups'):
                    group = obj.shape_xy_groups.get(state.group_name)
                    if group:
                        group.joy_x = state.joy_x
                        group.joy_y = state.joy_y
                        update_shapes(obj, group, get_limit(group))

            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
            _save_panel_settings(context)
        return {'FINISHED'}

class SHAPE_XY_OT_keyframe_preset(bpy.types.Operator):
    bl_idname = "shape_xy.keyframe_preset"
    bl_options = {'UNDO'}
    bl_label = _ui_text("Insert Keyframe for Global Preset", "グローバルプリセットへキー挿入")
    bl_description = _ui_text("Call this preset and immediately insert keyframes for all affected Shape Keys.", "このプリセットを呼び出した直後に、影響するすべてのシェイプキーへキーフレームを挿入します。")

    def execute(self, context):
        presets = context.scene.shape_xy_presets
        idx = context.scene.shape_xy_preset_index
        if 0 <= idx < len(presets):
            preset = presets[idx]

            # Step 1: Call the Preset to update values
            for state in preset.states:
                obj = context.scene.objects.get(state.obj_name)
                if obj and hasattr(obj, 'shape_xy_groups'):
                    group = obj.shape_xy_groups.get(state.group_name)
                    if group:
                        group.joy_x = state.joy_x
                        group.joy_y = state.joy_y
                        update_shapes(obj, group, get_limit(group))

                        # Step 2: Keyframe all affected shapekeys for this object
                        if obj.data and hasattr(obj.data, 'shape_keys') and obj.data.shape_keys:
                            for item in group.shape_xy_list:
                                if item.shape_name in obj.data.shape_keys.key_blocks:
                                    sk = obj.data.shape_keys.key_blocks[item.shape_name]
                                    sk.keyframe_insert(data_path="value")

            # Refresh Viewport
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D':
                        area.tag_redraw()
            _save_panel_settings(context)
        return {'FINISHED'}
