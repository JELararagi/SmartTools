# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy

try:
    from ... import translation as _sss_translation
except Exception:
    _sss_translation = None


from ..core.main import get_active_group, get_limit, update_shapes
from ..core.state import HUD_STATE
from . import draw as _axis_draw


def _is_japanese_locale(context=None) -> bool:
    try:
        if _sss_translation is not None:
            return bool(_sss_translation.is_japanese_locale(context))
    except Exception:
        pass
    view = getattr(getattr(context, 'preferences', None), 'view', None)
    if view is None:
        prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
    language = str(getattr(view, 'language', 'DEFAULT') or 'DEFAULT').upper()
    return language.startswith('JA')


def _ui_text(en: str, ja: str, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(ja if _is_japanese_locale(context) else en)


_PANEL_SETTING_SAVE_SUPPRESSED = False
_AXIS_PROPERTY_UPDATE_SUPPRESSED = False


def set_panel_setting_save_suppressed(value: bool) -> None:
    global _PANEL_SETTING_SAVE_SUPPRESSED
    _PANEL_SETTING_SAVE_SUPPRESSED = bool(value)


def set_axis_property_update_suppressed(value: bool) -> None:
    global _AXIS_PROPERTY_UPDATE_SUPPRESSED
    _AXIS_PROPERTY_UPDATE_SUPPRESSED = bool(value)


def _save_panel_settings(context=None):
    try:
        from ... import runtime
        saver = getattr(runtime, 'save_current_panel_settings', None)
        if callable(saver):
            saver(context if context is not None else getattr(bpy, 'context', None))
    except Exception:
        pass


def _defer_panel_settings_save() -> bool:
    if _PANEL_SETTING_SAVE_SUPPRESSED:
        return True
    try:
        return bool(HUD_STATE.get('dragging') or HUD_STATE.get('dragging_hud') or HUD_STATE.get('dragging_target_idx', -1) >= 0)
    except Exception:
        return False


def _tag_view3d_redraw(context):
    try:
        area = getattr(context, 'area', None)
        if getattr(area, 'type', None) == 'VIEW_3D':
            area.tag_redraw()
            return
    except Exception:
        pass
    wm = getattr(context, 'window_manager', None) or getattr(getattr(bpy, 'context', None), 'window_manager', None)
    for window in tuple(getattr(wm, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) == 'VIEW_3D':
                try:
                    area.tag_redraw()
                except Exception:
                    pass


def _refresh_hud_snapshot(context):
    if not HUD_STATE.get('running', False):
        return
    obj = getattr(context, 'active_object', None)
    group = get_active_group(obj) if obj is not None else None
    if group is not None:
        _axis_draw.update_snapshot(obj, group, context)


def on_property_update(self, context):
    if _AXIS_PROPERTY_UPDATE_SUPPRESSED:
        return
    obj = getattr(self, 'id_data', None)
    if not obj or getattr(obj, 'type', None) != 'MESH':
        obj = getattr(context, 'active_object', None)
    group = self if hasattr(self, 'shape_xy_list') and hasattr(self, 'joy_x') and hasattr(self, 'joy_y') else get_active_group(obj)
    if obj and group:
        limit = get_limit(group)
        update_shapes(obj, group, limit)
    _refresh_hud_snapshot(context)
    _tag_view3d_redraw(context)
    if not _defer_panel_settings_save():
        _save_panel_settings(context)


class SHAPE_XY_PG_item(bpy.types.PropertyGroup):
    shape_name: bpy.props.StringProperty(
        name=_ui_text('Shape Key', 'シェイプキー'),
        description=_ui_text(
            'Shape Key name driven by this mapping point. Choose one of the mesh Shape Keys you want this target position to affect.',
            'このマッピング点で駆動するシェイプキー名です。目標位置に応じて変化させたいメッシュのシェイプキーを選んでください。',
        ),
        update=on_property_update,
    )
    target_x: bpy.props.FloatProperty(
        name=_ui_text('Target X', '目標 X'),
        description=_ui_text(
            'Horizontal target position of this mapping point inside the Axis controller. Move farther from the center to react at a larger X range.',
            'シェイプ軸コントローラー内でのこのマッピング点の水平目標位置です。中心から離すほど、より大きい X 範囲で反応します。',
        ),
        default=1.0,
        update=on_property_update,
    )
    target_y: bpy.props.FloatProperty(
        name=_ui_text('Target Y', '目標 Y'),
        description=_ui_text(
            'Vertical target position of this mapping point inside the Axis controller. Move farther from the center to react at a larger Y range.',
            'シェイプ軸コントローラー内でのこのマッピング点の垂直目標位置です。中心から離すほど、より大きい Y 範囲で反応します。',
        ),
        default=0.0,
        update=on_property_update,
    )
    radius: bpy.props.FloatProperty(
        name=_ui_text('Radius', '半径'),
        description=_ui_text(
            'Influence radius around this mapping point. Larger values make the Shape Key react across a wider area of the controller.',
            'このマッピング点の影響半径です。値を大きくすると、コントローラー内のより広い範囲でシェイプキーが反応します。',
        ),
        default=1.0,
        min=0.001,
        update=on_property_update,
    )
    blend_mode: bpy.props.EnumProperty(
        name=_ui_text('Blend Mode', 'ブレンドモード'),
        description=_ui_text(
            'Choose how the controller distance is converted into Shape Key influence for this mapping point.',
            'このマッピング点で、コントローラー位置の距離をシェイプキー の影響量へどう変換するかを選びます。',
        ),
        items=[
            ('AUTO', _ui_text('Auto', '自動'), _ui_text('Automatically choose the most suitable falloff behavior.', '最適な減衰方法を自動で選びます。')),
            ('BOX', _ui_text('Box Falloff', 'ボックス減衰'), _ui_text('Use a box-shaped falloff around the target point.', '目標点の周囲でボックス状の減衰を使います。')),
            ('RADIAL', _ui_text('Radial Falloff', '放射状減衰'), _ui_text('Use a circular radial falloff around the target point.', '目標点の周囲で円形の放射状減衰を使います。')),
            ('AXIS_X', _ui_text('X-Axis', 'X 軸'), _ui_text('React mainly along the X axis.', '主に X 軸方向に反応させます。')),
            ('AXIS_Y', _ui_text('Y-Axis', 'Y 軸'), _ui_text('React mainly along the Y axis.', '主に Y 軸方向に反応させます。')),
        ],
        default='AUTO',
        update=on_property_update,
    )


class SHAPE_XY_PG_preset_state(bpy.types.PropertyGroup):
    obj_name: bpy.props.StringProperty(
        description=_ui_text(
            'Object name stored in this global Shape Axis preset state.',
            'このグローバルシェイプ軸プリセット状態に保存されているオブジェクト名です。',
        ),
        options={'HIDDEN'},
    )
    group_name: bpy.props.StringProperty(
        description=_ui_text(
            'Shape Axis group name stored in this global preset state.',
            'このグローバルプリセット状態に保存されているシェイプ軸グループ名です。',
        ),
        options={'HIDDEN'},
    )
    joy_x: bpy.props.FloatProperty(
        default=0.0,
        description=_ui_text(
            'Stored horizontal joystick value restored when this global preset is applied.',
            'このグローバルプリセットを適用したときに復元される水平ジョイスティック値です。',
        ),
        options={'HIDDEN'},
    )
    joy_y: bpy.props.FloatProperty(
        default=0.0,
        description=_ui_text(
            'Stored vertical joystick value restored when this global preset is applied.',
            'このグローバルプリセットを適用したときに復元される垂直ジョイスティック値です。',
        ),
        options={'HIDDEN'},
    )


def on_preset_change(self, context):
    del self
    _save_panel_settings(context)
    return None


class SHAPE_XY_PG_preset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name=_ui_text('Preset Name', 'プリセット名'),
        description=_ui_text(
            'Name of this global preset. Use presets to store joystick positions for multiple objects and groups at once.',
            'このグローバルプリセットの名前です。複数オブジェクト・複数グループのジョイスティック位置をまとめて保存できます。',
        ),
        default=_ui_text('New Preset', '新規プリセット'),
        update=on_preset_change,
    )
    states: bpy.props.CollectionProperty(
        type=SHAPE_XY_PG_preset_state,
        description=_ui_text(
            'Stored object/group joystick states included in this global preset.',
            'このグローバルプリセットに含まれるオブジェクト・グループごとのジョイスティック状態です。',
        ),
    )
class SHAPE_XY_PG_group(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name=_ui_text('Group Name', 'グループ名'),
        description=_ui_text(
            'Name of this Shape Axis group. Each group stores one joystick handle and a list of Shape Key mappings.',
            'このシェイプ軸グループの名前です。各グループは 1 つのジョイスティックハンドルとシェイプキーマッピング一覧を持ちます。',
        ),
        default=_ui_text('New Group', '新規グループ'),
        update=on_property_update,
    )
    joy_x: bpy.props.FloatProperty(
        name=_ui_text('Joystick X', 'ジョイスティック X'),
        description=_ui_text(
            'Current horizontal joystick value for this group. This can be keyed, driven, or adjusted from the HUD.',
            'このグループの現在の水平ジョイスティック値です。キーフレーム、ドライバー、HUD から調整できます。',
        ),
        default=0.0,
        update=on_property_update,
    )
    joy_y: bpy.props.FloatProperty(
        name=_ui_text('Joystick Y', 'ジョイスティック Y'),
        description=_ui_text(
            'Current vertical joystick value for this group. This can be keyed, driven, or adjusted from the HUD.',
            'このグループの現在の垂直ジョイスティック値です。キーフレーム、ドライバー、HUD から調整できます。',
        ),
        default=0.0,
        update=on_property_update,
    )
    shape_xy_list: bpy.props.CollectionProperty(
        type=SHAPE_XY_PG_item,
        description=_ui_text(
            'Shape Key mapping rows driven by this Shape Axis group.',
            'このシェイプ軸グループで駆動するシェイプキーマッピング行です。',
        ),
    )
    shape_xy_index: bpy.props.IntProperty(
        description=_ui_text(
            'Active mapping row inside this Shape Axis group.',
            'このシェイプ軸グループ内で現在選択しているマッピング行です。',
        ),
        update=on_property_update,
    )

    tracker_x_mode: bpy.props.EnumProperty(
        name=_ui_text('X Tracking Mode', 'X トラッキングモード'),
        description=_ui_text(
            'Choose how the face tracker calculates the X-axis input for this group.',
            'このグループの X 軸入力を、フェイストラッカーがどの方法で計算するかを選びます。',
        ),
        items=[
            ('None', _ui_text('None', 'なし'), _ui_text('Disable tracking for the X axis.', 'X 軸のトラッキングを無効にします。')),
            ('2pt (Dist)', _ui_text('2pt (Dist)', '2点距離'), _ui_text('Use the normalized distance between two landmark points.', '2 つのランドマーク間の正規化距離を使います。')),
            ('1pt (Proj)', _ui_text('1pt (Proj)', '1点投影'), _ui_text('Project one point relative to another along the face axis.', '顔の軸に沿って 1 点を別の点に対して投影します。')),
            ('iris', _ui_text('Iris', '虹彩'), _ui_text('Use iris motion as the source value.', '虹彩の動きを入力値として使います。')),
        ],
        default='2pt (Dist)',
        update=on_property_update,
    )
    tracker_x_pt_a: bpy.props.IntProperty(
        name=_ui_text('X Point A', 'X 点 A'),
        description=_ui_text('First landmark index used for X-axis tracking.', 'X 軸トラッキングに使う 1 つ目のランドマーク番号です。'),
        default=0,
        min=0,
        max=477,
        update=on_property_update,
    )
    tracker_x_pt_b: bpy.props.IntProperty(
        name=_ui_text('X Point B', 'X 点 B'),
        description=_ui_text('Second landmark index used for X-axis tracking.', 'X 軸トラッキングに使う 2 つ目のランドマーク番号です。'),
        default=0,
        min=0,
        max=477,
        update=on_property_update,
    )
    tracker_x_rmin: bpy.props.FloatProperty(
        name=_ui_text('X Radius Min', 'X 半径最小'),
        description=_ui_text('Lower tracked input bound for X-axis normalization.', 'X 軸の正規化に使う入力下限値です。'),
        default=0.0,
        update=on_property_update,
    )
    tracker_x_rmax: bpy.props.FloatProperty(
        name=_ui_text('X Radius Max', 'X 半径最大'),
        description=_ui_text('Upper tracked input bound for X-axis normalization.', 'X 軸の正規化に使う入力上限値です。'),
        default=1.0,
        update=on_property_update,
    )
    tracker_x_omin: bpy.props.FloatProperty(
        name=_ui_text('X Output Min', 'X 出力最小'),
        description=_ui_text('Minimum output value sent to the X joystick channel after normalization.', '正規化後に X ジョイスティックへ送る最小出力値です。'),
        default=0.0,
        update=on_property_update,
    )
    tracker_x_omax: bpy.props.FloatProperty(
        name=_ui_text('X Output Max', 'X 出力最大'),
        description=_ui_text('Maximum output value sent to the X joystick channel after normalization.', '正規化後に X ジョイスティックへ送る最大出力値です。'),
        default=1.0,
        update=on_property_update,
    )
    tracker_x_sens: bpy.props.FloatProperty(
        name=_ui_text('X Gain', 'X ゲイン'),
        description=_ui_text('Extra gain multiplier applied to the X-axis tracker output.', 'X 軸トラッカー出力へ追加で掛けるゲイン倍率です。'),
        default=1.0,
        update=on_property_update,
    )
    tracker_x_exp: bpy.props.FloatProperty(
        name=_ui_text('X Curve', 'X カーブ'),
        description=_ui_text('Curve exponent applied to the raw X-axis tracker signal before final output.', '最終出力前に、生の X 軸トラッカー信号へ掛けるカーブ指数です。'),
        default=1.2,
        update=on_property_update,
    )
    tracker_x_lerp_en: bpy.props.BoolProperty(
        name=_ui_text('X Smooth', 'X スムーズ'),
        description=_ui_text('Smooth the X-axis tracker output over time to reduce jitter.', 'X 軸トラッカー出力を時間方向で平滑化し、細かな揺れを減らします。'),
        default=False,
        update=on_property_update,
    )
    tracker_x_lerp_fac: bpy.props.FloatProperty(
        name=_ui_text('X Smooth Factor', 'X スムーズ係数'),
        description=_ui_text('How strongly the X-axis smoothing filter blends toward the new value each update.', '更新ごとに X 軸スムージングが新しい値へどれだけ寄せるかを決めます。'),
        default=0.15,
        update=on_property_update,
    )

    tracker_y_mode: bpy.props.EnumProperty(
        name=_ui_text('Y Tracking Mode', 'Y トラッキングモード'),
        description=_ui_text(
            'Choose how the face tracker calculates the Y-axis input for this group.',
            'このグループの Y 軸入力を、フェイストラッカーがどの方法で計算するかを選びます。',
        ),
        items=[
            ('None', _ui_text('None', 'なし'), _ui_text('Disable tracking for the Y axis.', 'Y 軸のトラッキングを無効にします。')),
            ('2pt (Dist)', _ui_text('2pt (Dist)', '2点距離'), _ui_text('Use the normalized distance between two landmark points.', '2 つのランドマーク間の正規化距離を使います。')),
            ('1pt (Proj)', _ui_text('1pt (Proj)', '1点投影'), _ui_text('Project one point relative to another along the face axis.', '顔の軸に沿って 1 点を別の点に対して投影します。')),
            ('iris', _ui_text('Iris', '虹彩'), _ui_text('Use iris motion as the source value.', '虹彩の動きを入力値として使います。')),
        ],
        default='2pt (Dist)',
        update=on_property_update,
    )
    tracker_y_pt_a: bpy.props.IntProperty(
        name=_ui_text('Y Point A', 'Y 点 A'),
        description=_ui_text('First landmark index used for Y-axis tracking.', 'Y 軸トラッキングに使う 1 つ目のランドマーク番号です。'),
        default=0,
        min=0,
        max=477,
        update=on_property_update,
    )
    tracker_y_pt_b: bpy.props.IntProperty(
        name=_ui_text('Y Point B', 'Y 点 B'),
        description=_ui_text('Second landmark index used for Y-axis tracking.', 'Y 軸トラッキングに使う 2 つ目のランドマーク番号です。'),
        default=0,
        min=0,
        max=477,
        update=on_property_update,
    )
    tracker_y_rmin: bpy.props.FloatProperty(
        name=_ui_text('Y Radius Min', 'Y 半径最小'),
        description=_ui_text('Lower tracked input bound for Y-axis normalization.', 'Y 軸の正規化に使う入力下限値です。'),
        default=0.0,
        update=on_property_update,
    )
    tracker_y_rmax: bpy.props.FloatProperty(
        name=_ui_text('Y Radius Max', 'Y 半径最大'),
        description=_ui_text('Upper tracked input bound for Y-axis normalization.', 'Y 軸の正規化に使う入力上限値です。'),
        default=1.0,
        update=on_property_update,
    )
    tracker_y_omin: bpy.props.FloatProperty(
        name=_ui_text('Y Output Min', 'Y 出力最小'),
        description=_ui_text('Minimum output value sent to the Y joystick channel after normalization.', '正規化後に Y ジョイスティックへ送る最小出力値です。'),
        default=0.0,
        update=on_property_update,
    )
    tracker_y_omax: bpy.props.FloatProperty(
        name=_ui_text('Y Output Max', 'Y 出力最大'),
        description=_ui_text('Maximum output value sent to the Y joystick channel after normalization.', '正規化後に Y ジョイスティックへ送る最大出力値です。'),
        default=1.0,
        update=on_property_update,
    )
    tracker_y_sens: bpy.props.FloatProperty(
        name=_ui_text('Y Gain', 'Y ゲイン'),
        description=_ui_text('Extra gain multiplier applied to the Y-axis tracker output.', 'Y 軸トラッカー出力へ追加で掛けるゲイン倍率です。'),
        default=1.0,
        update=on_property_update,
    )
    tracker_y_exp: bpy.props.FloatProperty(
        name=_ui_text('Y Curve', 'Y カーブ'),
        description=_ui_text('Curve exponent applied to the raw Y-axis tracker signal before final output.', '最終出力前に、生の Y 軸トラッカー信号へ掛けるカーブ指数です。'),
        default=1.2,
        update=on_property_update,
    )
    tracker_y_lerp_en: bpy.props.BoolProperty(
        name=_ui_text('Y Smooth', 'Y スムーズ'),
        description=_ui_text('Smooth the Y-axis tracker output over time to reduce jitter.', 'Y 軸トラッカー出力を時間方向で平滑化し、細かな揺れを減らします。'),
        default=False,
        update=on_property_update,
    )
    tracker_y_lerp_fac: bpy.props.FloatProperty(
        name=_ui_text('Y Smooth Factor', 'Y スムーズ係数'),
        description=_ui_text('How strongly the Y-axis smoothing filter blends toward the new value each update.', '更新ごとに Y 軸スムージングが新しい値へどれだけ寄せるかを決めます。'),
        default=0.15,
        update=on_property_update,
    )
