# SPDX-License-Identifier: GPL-3.0-or-later
"""Short, newly written explanations for the map and driver controls."""
import bpy

TEXT={
'output_text':('Copy this expression into a driver whose input is named var.','入力変数にvarと名付けたドライバーへこの式をコピーします。'),
'scene_wide':('Include mapped meshes in the current scene.','現在のシーン内のマップ付きメッシュを対象にします。'),
'inverted':('Create the opposite displacement around Basis.','Basisを中心に反対向きの変形を作ります。'),
'columns':('Start a new row after this many meshes.','この個数ごとに次の行へ送ります。'),
'origin':('Set the starting point of the output grid.','書き出すメッシュの整列開始位置を指定します。'),
'spacing':('Set the gap between grid positions in scene units.','シーン単位で整列位置の間隔を指定します。'),
'target':('Use every expression or the checked rows.','全表情またはチェックした行を処理します。'),
'choices':('Mark the expressions to take from this file.','このファイルから読み込む表情にチェックします。'),
'deselect_all':('Clear all expression checkboxes.','すべての表情のチェックを外します。'),
'filepath':('Choose the expression-map file on disk.','ディスク上の表情マップファイルを選びます。'),
'select_all':('Check every expression in the file.','ファイル内のすべての表情を選択します。'),
'filter_glob':('Show files matching the map extension.','表情マップの拡張子に合うファイルを表示します。'),
'state':('Apply this selection state to every listed expression.','一覧の全表情へ同じ選択状態を適用します。'),
'mirror_selected.direction':('Choose which side supplies the displacement.','変形を読み取る側を指定します。'),
'move_map.direction':('Move the selected row up or down.','選択した行を上または下へ移動します。'),
'mirrored':('Reflect copied vertices around the configured center.','設定した中心を基準にコピーした頂点を反転します。'),
'check_existing':('Ask before replacing an existing file.','既存ファイルの置き換え前に確認します。'),
'selected_only':('Write only checked expression rows.','チェックした表情の行だけを書き出します。'),
'tool_id':('Show help for this panel section.','このパネル項目のヘルプを表示します。'),
'enable':('Turn the selected feature on or off.','選択した機能の有効・無効を切り替えます。'),
'toggle_always_on.target':('Choose the tracking or axis feature to change.','変更するトラッキングまたは軸機能を選択します。'),
'default_state':('Use this state until a section preference is saved.','開閉状態が保存されるまでこの値を使います。'),
'label':('The heading displayed for this control.','この操作の見出しに表示する名前です。'),
'section_key':('Identifies the section whose open state is stored.','開閉状態を記憶するパネルの項目を指定します。'),
'driverhelper_max':('Input value at a full-strength response.','効果が最大になる入力値です。'),
'driverhelper_min':('Input value at a zero response.','効果がゼロになる入力値です。'),
'driverhelper_mode':('Select a transform channel. Rotation limits are entered in degrees.','変換チャンネルを選びます。回転の範囲は度で入力します。'),
'driverhelper_power':('Change the curvature between the two limits.','最小値と最大値の間の変化の曲がり方を調整します。'),
'chn_id':('Persistent numeric channel of this expression.','この表情の保存に使うチャンネル番号です。'),
'locked':('Protect the reference row in the map list.','一覧の基準行を保護します。'),
'prev_name':('Previous name used to track a renamed row.','行の名前を変更する前の名前です。'),
'selected':('Include this expression in selection-based operations.','選択した行だけを対象とする操作に含めます。'),
'always_axis_ui_enabled':('Enable interactive axis controls.','軸の対話操作を有効にします。'),
'always_external_tracker_enabled':('Listen for an external tracker on the configured port.','指定したポートで外部トラッカーの入力を受け取ります。'),
'always_face_tracker_enabled':('Start or stop local face tracking.','ローカルのフェイストラッキングを開始または停止します。'),
'always_face_tracker_hud_enabled':('Display detected landmark points in the viewport.','検出した特徴点をビューポートに表示します。'),
'always_frame_sync_enabled':('Update axis handles when the current frame changes.','現在のフレームを変更したとき軸のハンドルを更新します。'),
'n_panel_state_save_enabled':('Remember panel settings between Blender sessions.','次回のBlender起動時にもパネル設定を復元します。'),
'show_always_on_toggles':('Open the section containing the continuous features.','継続動作する機能の切り替え欄を開きます。'),
'skm__suppress_apply':('Pause automatic map display while rebuilding a list.','一覧の更新中はマップの自動表示を一時停止します。'),
'skm_index':('Expression currently shown on the mesh.','メッシュに表示中の表情です。'),
'skm_keep_map_shapes':('Keep expression positions when the base mesh changes.','基準形状を変更しても各表情の頂点位置を保ちます。'),
'skm_maps':('Expression channels stored for this mesh.','このメッシュに保存している表情の一覧です。'),
'skm_mirror_axis':('Choose the axis perpendicular to the mirror plane.','反転面に垂直な軸を選びます。'),
'skm_mirror_epsilon':('Maximum local distance for pairing mirrored vertices.','反転する頂点どうしを対応付ける最大距離です。'),
'skm_uv_map_name':('UV coordinates used to transfer expressions.','表情を転送する際に使うUVマップです。'),
'driver_helper_props':('Settings used to build a transform driver.','変換ドライバーの式を作るための設定です。'),
'skm_suite_settings':('Saved preferences for the Smart Shapekey panel.','Smart Shapekeyパネルで使う保存設定です。'),
}
for axis in 'xyz':
    TEXT['skm_mirror_center_'+axis]=(f'Local {axis.upper()} coordinate of the mirror center.',f'反転中心のローカル{axis.upper()}座標です。')
def hint(prop,owner=''):
    pair=TEXT.get(owner+'.'+prop,TEXT.get(prop))
    return pair[0] if pair else ''
def register():
    table={('*',en):ja for en,ja in TEXT.values()}
    bpy.app.translations.register(__name__,{'ja_JP':table,'ja':table})
def unregister():
    bpy.app.translations.unregister(__name__)

