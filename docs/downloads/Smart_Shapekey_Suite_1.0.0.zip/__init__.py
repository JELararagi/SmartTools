# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Smart Shapekey Suite Blender Extension bootstrap.

Registration is a single generation-scoped transaction.  Every Blender class,
RNA property, handler, timer, msgbus subscription, draw handle, socket and worker
is owned by the exact resource ledger implemented in :mod:`lifecycle`.
"""
from __future__ import annotations

import importlib
import sys
import uuid

import bpy

# Blender Extensions are loaded as ``bl_ext.<repo>.smart_shapekey_suite``.
# Remove only the stale legacy alias that points at this exact module/file.
if __name__ != "smart_shapekey_suite":
    _legacy = sys.modules.get("smart_shapekey_suite")
    try:
        if _legacy is sys.modules.get(__name__) or str(getattr(_legacy, "__file__", "") or "") == str(__file__):
            sys.modules.pop("smart_shapekey_suite", None)
    except Exception:
        pass
    del _legacy

_RUNTIME_MODULE = None
_BOOTSTRAP_INSTANCE_UUID = uuid.uuid4().hex


def _runtime_module():
    global _RUNTIME_MODULE
    if _RUNTIME_MODULE is None:
        _RUNTIME_MODULE = importlib.import_module(".runtime", __package__)
    return _RUNTIME_MODULE


def register():
    """Register the complete suite as one exact-identity transaction."""
    from . import lifecycle

    current = lifecycle.current_ledger()
    if (
        current is not None
        and current.state == "READY"
        and current.token.active
        and getattr(current.token, "registration_instance_uuid", "") == _BOOTSTRAP_INSTANCE_UUID
    ):
        return

    ledger = lifecycle.begin_registration(_BOOTSTRAP_INSTANCE_UUID)
    try:
        runtime = _runtime_module()
        runtime.register_runtime(ledger)
        lifecycle.finish_registration(ledger)
        runtime.mark_runtime_ready(ledger.token)
    except Exception:
        try:
            runtime = _RUNTIME_MODULE
            if runtime is not None:
                runtime.abort_runtime_registration()
        finally:
            lifecycle.teardown_current()
        raise


def unregister():
    """Idempotently stop activity, then remove this generation's exact resources."""
    global _RUNTIME_MODULE
    from . import lifecycle

    runtime = _RUNTIME_MODULE
    if runtime is None:
        runtime = sys.modules.get(f"{__package__}.runtime")
    try:
        if runtime is not None:
            runtime.unregister_runtime()
    finally:
        lifecycle.teardown_current()
        _RUNTIME_MODULE = None


if __name__ == "__main__":
    unregister()
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)

# English text for Japanese source strings.
from .locale_fallback import wrap as _locale_fallback_wrap

register, unregister = _locale_fallback_wrap(register, unregister)
