# SPDX-License-Identifier: GPL-3.0-or-later
"""Preserve Blender GPU state around a local draw callback."""

from contextlib import contextmanager

try:
    from gpu import state
except ImportError:
    state = None


_FIELDS = (
    "blend", "depth_test", "depth_mask", "face_culling", "front_facing",
    "line_width", "point_size", "program_point_size", "scissor_test", "viewport",
)


def capture():
    entries = []
    for field in _FIELDS:
        query = getattr(state, f"{field}_get", None)
        assign = getattr(state, f"{field}_set", None)
        if callable(query) and callable(assign):
            try:
                entries.append((field, query()))
            except Exception:
                continue
    return tuple(entries)


def restore(snapshot):
    for field, value in reversed(tuple(snapshot)):
        assign = getattr(state, f"{field}_set", None)
        if not callable(assign):
            continue
        try:
            if isinstance(value, tuple):
                try:
                    assign(*value)
                except TypeError:
                    assign(value)
            else:
                assign(value)
        except Exception:
            continue


@contextmanager
def preserved():
    initial = capture()
    try:
        yield
    finally:
        restore(initial)
