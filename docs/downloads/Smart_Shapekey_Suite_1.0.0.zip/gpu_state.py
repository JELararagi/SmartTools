# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Best-effort exact restoration of queryable Blender GPU state."""
from __future__ import annotations

from contextlib import contextmanager
from typing import Any

try:
    import gpu
except Exception:
    gpu = None

# State names whose Blender GPU API exposes matching ``*_get``/``*_set`` calls.
_STATE_NAMES = (
    "blend",
    "depth_test",
    "depth_mask",
    "face_culling",
    "front_facing",
    "line_width",
    "point_size",
    "program_point_size",
    "scissor_test",
    "viewport",
)


def capture() -> tuple[tuple[str, Any], ...]:
    state = getattr(gpu, "state", None)
    if state is None:
        return ()
    out: list[tuple[str, Any]] = []
    for name in _STATE_NAMES:
        getter = getattr(state, f"{name}_get", None)
        setter = getattr(state, f"{name}_set", None)
        if not callable(getter) or not callable(setter):
            continue
        try:
            value = getter()
        except Exception:
            continue
        out.append((name, value))
    return tuple(out)


def restore(snapshot: tuple[tuple[str, Any], ...]) -> None:
    state = getattr(gpu, "state", None)
    if state is None:
        return
    for name, value in reversed(tuple(snapshot)):
        setter = getattr(state, f"{name}_set", None)
        if not callable(setter):
            continue
        try:
            if isinstance(value, tuple):
                setter(*value)
            else:
                setter(value)
        except TypeError:
            try:
                setter(value)
            except Exception:
                pass
        except Exception:
            pass


@contextmanager
def preserved():
    snapshot = capture()
    try:
        yield
    finally:
        restore(snapshot)
