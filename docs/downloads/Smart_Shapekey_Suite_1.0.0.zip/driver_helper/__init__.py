# SPDX-License-Identifier: GPL-3.0-or-later
"""Generate a bounded, optionally curved response to a Blender transform variable."""
import math
import bpy
from .. import lifecycle
from ..control_help import hint

def _label(en,ja):
    return ja if bpy.app.translations.locale.startswith('ja') else en

def driver_formula(min_val,max_val,transform_type='ROT',power=1.0):
    if not all(math.isfinite(v) for v in (min_val,max_val,power)):
        raise ValueError('Enter finite numeric limits.')
    rotation=transform_type=='ROT'
    low,high=(math.radians(min_val),math.radians(max_val)) if rotation else (min_val,max_val)
    distance=high-low
    source='var'
    if low!=0:
        origin=f'({low})' if rotation else str(low)
        source+='-'+origin
    if distance not in (0,1):
        source=f'({source})/({distance})'
    response=f'min(max({source},0),1)'
    return response if power==1 else f'pow({response},{power})'

def update_driverhelper_mode(self,context):
    from .. import runtime
    runtime.save_current_panel_settings(context)

class DriverHelperProperties(bpy.types.PropertyGroup):
    driverhelper_mode:bpy.props.EnumProperty(description=hint('driverhelper_mode'),name='Driver Mode',items=[('LOC','LOC','Location channel'),('ROT','ROT','Rotation channel'),('SCALE','SCALE','Scale channel')],default='LOC',update=update_driverhelper_mode)
    driverhelper_min:bpy.props.FloatProperty(description=hint('driverhelper_min'),name='Min',default=0,update=update_driverhelper_mode)
    driverhelper_max:bpy.props.FloatProperty(description=hint('driverhelper_max'),name='Max',default=1,update=update_driverhelper_mode)
    driverhelper_power:bpy.props.FloatProperty(description=hint('driverhelper_power'),name='Power',default=1,update=update_driverhelper_mode)

class DRIVERHELPER_OT_show_text(bpy.types.Operator):
    bl_idname='driverhelper.show_text'
    bl_label='DriverHelper Formula'
    output_text:bpy.props.StringProperty(name='Formula',description=hint('output_text'))
    def invoke(self,context,event):
        return context.window_manager.invoke_props_dialog(self,width=520)
    def draw(self,context):
        self.layout.prop(self,'output_text',text=_label('Expression','式'))
    def execute(self,context):
        return {'FINISHED'}

class DRIVERHELPER_OT_genformula_operator(bpy.types.Operator):
    bl_idname='driverhelper.genformula_operator'
    bl_label='Generate Driver Formula'
    def execute(self,context):
        settings=context.scene.driver_helper_props
        expression=driver_formula(settings.driverhelper_min,settings.driverhelper_max,settings.driverhelper_mode,settings.driverhelper_power)
        if bpy.app.background:
            self.report({'INFO'},expression)
        else:bpy.ops.driverhelper.show_text('INVOKE_DEFAULT',output_text=expression)
        return {'FINISHED'}

def draw_driver_helper_body(layout,context):
    p=context.scene.driver_helper_props
    layout.prop(p,'driverhelper_mode',text=_label('Channel','チャンネル'))
    row=layout.row(align=True)
    row.prop(p,'driverhelper_min',text=_label('Min','最小'))
    row.prop(p,'driverhelper_max',text=_label('Max','最大'))
    layout.prop(p,'driverhelper_power',text=_label('Power','べき指数'))
    layout.operator('driverhelper.genformula_operator',text=_label('Generate expression','ドライバー式を生成'),icon='DRIVER')

def register(ledger):
    for cls in (DriverHelperProperties,DRIVERHELPER_OT_show_text,DRIVERHELPER_OT_genformula_operator):
        lifecycle.register_class(ledger,cls)
    lifecycle.register_rna_property(ledger,bpy.types.Scene,'driver_helper_props',bpy.props.PointerProperty(type=DriverHelperProperties,description=hint('driver_helper_props')))

def unregister():
    # The suite owns the three classes and the Scene property in this registration ledger.
    return None
