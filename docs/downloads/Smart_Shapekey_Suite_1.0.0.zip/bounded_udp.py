# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Pure-Python bounded/coalescing UDP inbox used by the Blender tracker."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, asdict
from typing import Any, Callable
import json
import math
import threading
import time

MAX_PACKET_BYTES = 65507
MAX_CONTROL_ITEMS = 64
MAX_CONTROL_BYTES = 128 * 1024
MAX_CONTINUOUS_BYTES = 64 * 1024
MAX_CONTINUOUS_TARGETS = 64
TICK_MAX_CONTROL = 8
TICK_MAX_ITEMS = 9
TICK_MAX_DIRTY_TARGETS = 8
TICK_MAX_CONTINUOUS_TARGETS = 8
TICK_TIME_BUDGET_SECONDS = 0.004


@dataclass(slots=True)
class InboxStats:
    packets_received: int = 0
    bytes_received: int = 0
    oversize_packets: int = 0
    malformed_packets: int = 0
    continuous_coalesced: int = 0
    continuous_dropped: int = 0
    continuous_deferred: int = 0
    continuous_deferred_superseded: int = 0
    continuous_target_overflow: int = 0
    control_deduplicated: int = 0
    control_overflow: int = 0
    control_dropped: int = 0
    max_control_depth: int = 0
    max_control_bytes: int = 0
    max_continuous_bytes: int = 0
    ticks: int = 0
    tick_items_processed: int = 0
    max_tick_items: int = 0
    max_tick_seconds: float = 0.0


class BoundedUDPInbox:
    """One latest-value slot plus a bounded deduplicated control queue."""

    __slots__ = ("_lock", "_continuous", "_continuous_size", "_controls", "_control_keys", "_control_bytes", "stats")

    def __init__(self):
        self._lock = threading.RLock()
        self._continuous: tuple[dict[str, Any], int] | None = None
        self._continuous_size = 0
        self._controls: deque[tuple[tuple[Any, ...], dict[str, Any], int]] = deque()
        self._control_keys: set[tuple[Any, ...]] = set()
        self._control_bytes = 0
        self.stats = InboxStats()

    @staticmethod
    def _control_key(message: dict[str, Any], address: Any) -> tuple[Any, ...]:
        kind = str(message.get("type", "")).upper()
        # GET_GROUPS is deduplicated per remote endpoint. Other controls include
        # a stable canonical payload key so retries cannot fill the queue.
        if kind == "GET_GROUPS":
            return (kind, tuple(address) if isinstance(address, (tuple, list)) else str(address))
        canonical = json.dumps(message, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
        return (kind or "CONTROL", canonical, tuple(address) if isinstance(address, (tuple, list)) else str(address))

    @staticmethod
    def _parse(raw: bytes) -> dict[str, Any]:
        text = raw.decode("utf-8", errors="strict")
        value = json.loads(text, parse_constant=lambda token: (_ for _ in ()).throw(ValueError(token)))
        if type(value) is not dict:
            raise ValueError("packet root must be object")
        return value

    @staticmethod
    def _is_control(message: dict[str, Any]) -> bool:
        return bool(str(message.get("type", "")).upper() in {"GET_GROUPS", "PING", "STOP", "START", "CALIBRATE"})

    @staticmethod
    def _finite_pair(x_value: Any, y_value: Any) -> tuple[float, float]:
        x = float(x_value)
        y = float(y_value)
        if not math.isfinite(x) or not math.isfinite(y):
            raise ValueError("continuous values must be finite")
        return x, y

    @classmethod
    def _continuous_payload(cls, message: dict[str, Any]) -> tuple[dict[str, Any] | None, int]:
        if "x" in message and "y" in message:
            x, y = cls._finite_pair(message["x"], message["y"])
            payload: dict[str, Any] = {"_ACTIVE_GROUP_": {"x": x, "y": y}}
            object_name = message.get("object_name", message.get("object", ""))
            if type(object_name) is str and object_name:
                payload["object_name"] = object_name[:1024]
            return payload, 0
        parsed: dict[str, Any] = {}
        overflow = 0
        for key, value in message.items():
            if type(value) is not dict or "x" not in value or "y" not in value:
                continue
            if len(parsed) >= MAX_CONTINUOUS_TARGETS:
                overflow += 1
                continue
            x, y = cls._finite_pair(value["x"], value["y"])
            parsed[str(key)[:1024]] = {"x": x, "y": y}
        return (parsed or None), overflow

    def offer_packet(self, raw: bytes, address: Any = None) -> bool:
        size = len(raw)
        with self._lock:
            self.stats.packets_received += 1
            self.stats.bytes_received += size
        if size <= 0 or size > MAX_PACKET_BYTES:
            with self._lock:
                self.stats.oversize_packets += 1
            return False
        try:
            message = self._parse(raw)
        except Exception:
            with self._lock:
                self.stats.malformed_packets += 1
            return False

        if self._is_control(message):
            payload = dict(message)
            payload["_address"] = address
            payload_size = size + 64
            key = self._control_key(message, address)
            with self._lock:
                if key in self._control_keys:
                    self.stats.control_deduplicated += 1
                    return True
                # Preserve new control requests by evicting the oldest control
                # only when the fixed capacity has been reached.
                while self._controls and (
                    len(self._controls) >= MAX_CONTROL_ITEMS or self._control_bytes + payload_size > MAX_CONTROL_BYTES
                ):
                    old_key, _old_payload, old_size = self._controls.popleft()
                    self._control_keys.discard(old_key)
                    self._control_bytes -= old_size
                    self.stats.control_overflow += 1
                    self.stats.control_dropped += 1
                if payload_size > MAX_CONTROL_BYTES:
                    self.stats.control_overflow += 1
                    self.stats.control_dropped += 1
                    return False
                self._controls.append((key, payload, payload_size))
                self._control_keys.add(key)
                self._control_bytes += payload_size
                self.stats.max_control_depth = max(self.stats.max_control_depth, len(self._controls))
                self.stats.max_control_bytes = max(self.stats.max_control_bytes, self._control_bytes)
            return True

        try:
            payload, target_overflow = self._continuous_payload(message)
        except Exception:
            payload, target_overflow = None, 0
        if payload is None:
            with self._lock:
                self.stats.malformed_packets += 1
            return False
        payload_size = len(json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
        if payload_size > MAX_CONTINUOUS_BYTES:
            with self._lock:
                self.stats.continuous_dropped += 1
            return False
        with self._lock:
            self.stats.continuous_target_overflow += int(target_overflow)
            if self._continuous is not None:
                self.stats.continuous_coalesced += 1
            self._continuous = (payload, payload_size)
            self._continuous_size = payload_size
            self.stats.max_continuous_bytes = max(self.stats.max_continuous_bytes, payload_size)
        return True

    def pop_tick(
        self,
        *,
        clock: Callable[[], float] = time.perf_counter,
        budget: float = TICK_TIME_BUDGET_SECONDS,
        deadline: float | None = None,
        max_control: int = TICK_MAX_CONTROL,
        max_items: int = TICK_MAX_ITEMS,
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        started = clock()
        hard_deadline = float(deadline) if deadline is not None else started + max(0.0, float(budget))
        controls: list[dict[str, Any]] = []
        continuous = None
        with self._lock:
            while self._controls and len(controls) < max(0, int(max_control)) and (len(controls) + 1) < max(1, int(max_items)):
                if clock() >= hard_deadline:
                    break
                key, payload, size = self._controls.popleft()
                self._control_keys.discard(key)
                self._control_bytes -= size
                controls.append(payload)
            if len(controls) < max(1, int(max_items)) and clock() < hard_deadline and self._continuous is not None:
                continuous = self._continuous[0]
                self._continuous = None
                self._continuous_size = 0
            elapsed = max(0.0, clock() - started)
            processed = len(controls) + (1 if continuous is not None else 0)
            self.stats.ticks += 1
            self.stats.tick_items_processed += processed
            self.stats.max_tick_items = max(self.stats.max_tick_items, processed)
            self.stats.max_tick_seconds = max(self.stats.max_tick_seconds, elapsed)
        return controls, continuous

    def pop_control(self, *, clock: Callable[[], float] = time.perf_counter, deadline: float | None = None) -> dict[str, Any] | None:
        if deadline is not None and clock() >= float(deadline):
            return None
        with self._lock:
            if not self._controls:
                return None
            key, payload, size = self._controls.popleft()
            self._control_keys.discard(key)
            self._control_bytes -= size
            return payload

    def pop_continuous(self, *, clock: Callable[[], float] = time.perf_counter, deadline: float | None = None) -> dict[str, Any] | None:
        if deadline is not None and clock() >= float(deadline):
            return None
        with self._lock:
            if self._continuous is None:
                return None
            payload = self._continuous[0]
            self._continuous = None
            self._continuous_size = 0
            return payload

    def defer_continuous(self, payload: dict[str, Any]) -> bool:
        """Return an unfinished continuous frame to the single latest slot.

        A packet received after ``pop_continuous`` is newer and therefore wins;
        the unfinished older frame is then deliberately dropped.  The outcome
        remains observable through the audit counters.
        """
        if type(payload) is not dict or not payload:
            return False
        try:
            payload_size = len(json.dumps(payload, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8"))
        except Exception:
            with self._lock:
                self.stats.continuous_dropped += 1
            return False
        if payload_size > MAX_CONTINUOUS_BYTES:
            with self._lock:
                self.stats.continuous_dropped += 1
            return False
        with self._lock:
            if self._continuous is not None:
                self.stats.continuous_deferred_superseded += 1
                return False
            self._continuous = (dict(payload), payload_size)
            self._continuous_size = payload_size
            self.stats.continuous_deferred += 1
            self.stats.max_continuous_bytes = max(self.stats.max_continuous_bytes, payload_size)
            return True

    def record_tick(self, processed: int, elapsed: float) -> None:
        processed = max(0, int(processed))
        elapsed = max(0.0, float(elapsed))
        with self._lock:
            self.stats.ticks += 1
            self.stats.tick_items_processed += processed
            self.stats.max_tick_items = max(self.stats.max_tick_items, processed)
            self.stats.max_tick_seconds = max(self.stats.max_tick_seconds, elapsed)

    def clear(self, *, reset_stats: bool = False) -> None:
        with self._lock:
            self._continuous = None
            self._continuous_size = 0
            self._controls.clear()
            self._control_keys.clear()
            self._control_bytes = 0
            if reset_stats:
                self.stats = InboxStats()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            out = asdict(self.stats)
            out.update({
                "control_depth": len(self._controls),
                "control_bytes": self._control_bytes,
                "continuous_slot_occupied": self._continuous is not None,
                "continuous_slot_bytes": self._continuous_size,
                "limits": {
                    "packet_bytes": MAX_PACKET_BYTES,
                    "control_items": MAX_CONTROL_ITEMS,
                    "control_bytes": MAX_CONTROL_BYTES,
                    "continuous_bytes": MAX_CONTINUOUS_BYTES,
                    "continuous_targets": MAX_CONTINUOUS_TARGETS,
                    "tick_control": TICK_MAX_CONTROL,
                    "tick_items": TICK_MAX_ITEMS,
                    "tick_dirty_targets": TICK_MAX_DIRTY_TARGETS,
                    "tick_continuous_targets": TICK_MAX_CONTINUOUS_TARGETS,
                    "tick_seconds": TICK_TIME_BUDGET_SECONDS,
                },
            })
            return out
