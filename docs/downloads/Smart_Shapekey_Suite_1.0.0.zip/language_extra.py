# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Supplemental UI translations for static source labels."""

EXTRA_TRANSLATIONS = {
    ('*', 'Smart Shapekey'): 'Smart Shapekey',
}


# --- 納品 20261102：英語の残りの日本語化（UI の文字列だけ） ---
EXTRA_TRANSLATIONS.update({
    ('*', 'Internal help topic identifier used by the header help button.'): '見出しの「？」ヘルプボタンが使う、内部のヘルプ項目の識別子です。',
    ('Operator', 'Internal help topic identifier used by the header help button.'): '見出しの「？」ヘルプボタンが使う、内部のヘルプ項目の識別子です。',
    ('*', 'Internal tool alias used to route the Always-on toggle to the correct feature set.'): '常時起動の切り替えを正しい機能へ振り分けるための、内部のツール名です。',
    ('Operator', 'Internal tool alias used to route the Always-on toggle to the correct feature set.'): '常時起動の切り替えを正しい機能へ振り分けるための、内部のツール名です。',
    ('*', 'Internal feature key identifying which Always-on function is being enabled or disabled.'): 'どの常時起動機能をオン / オフにするかを示す、内部の機能キーです。',
    ('Operator', 'Internal feature key identifying which Always-on function is being enabled or disabled.'): 'どの常時起動機能をオン / オフにするかを示す、内部の機能キーです。',
    ('*', 'Target enabled state for the selected Always-on feature.'): '選んだ常時起動機能を、オンにするかオフにするかの指定です。',
    ('Operator', 'Target enabled state for the selected Always-on feature.'): '選んだ常時起動機能を、オンにするかオフにするかの指定です。',
    ('*', 'Save Neutral Calibration Draft'): '無表情の校正の下書きを保存',
    ('Operator', 'Save Neutral Calibration Draft'): '無表情の校正の下書きを保存',
    ('*', 'Controller Calibration (EDIT Only)'): 'コントローラーの校正（EDIT のみ）',
    ('Operator', 'Controller Calibration (EDIT Only)'): 'コントローラーの校正（EDIT のみ）',
    ('*', 'Action Contact Report Text'): 'アクションの接触の報告文',
    ('Operator', 'Action Contact Report Text'): 'アクションの接触の報告文',
    ('*', 'Action Contact Continue'): 'アクションの接触：続行',
    ('Operator', 'Action Contact Continue'): 'アクションの接触：続行',
    ('*', 'Action Contact Inspection Result'): 'アクションの接触の検査結果',
    ('Operator', 'Action Contact Inspection Result'): 'アクションの接触の検査結果',
})
