# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shape-key RNA paths and settings that are private to a Blender file."""

CONTRACT_VERSION = 3
EXTENSION_ID = "smart_shapekey_suite"
CONFIG_FOLDER = "Smart_Shapekey_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"
_SETTINGS = "window_manager.skm_suite_settings"

STATE_SAVE_PATH = f"{_SETTINGS}.n_panel_state_save_enabled"
SECTION_OPEN_PATH = f"{_SETTINGS}.show_always_on_toggles"
_RUNTIME = {
    "axis_ui": False,
    "frame_sync": False,
    "external_tracker": True,
    "face_tracker": True,
    "face_tracker_hud": False,
}
RUNTIME_TOGGLE_PATHS = tuple(f"{_SETTINGS}.always_{key}_enabled" for key in _RUNTIME)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = tuple(
    path for path, uses_device in zip(RUNTIME_TOGGLE_PATHS, _RUNTIME.values()) if uses_device
)

_EDITORS = (
    ("view3d", ("VIEW_3D",)),
    ("image_editor", ("IMAGE_EDITOR", "UV_EDITOR")),
    ("node_editor", ("SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR")),
    ("sequence_editor", ("VIDEO_SEQUENCER",)),
    ("clip_editor", ("MOVIE_CLIP_EDITOR",)),
    ("dopesheet_editor", ("DOPE_SHEET",)),
    ("graph_editor", ("GRAPH_EDITOR", "DRIVERS")),
    ("nla_editor", ("NLA_EDITOR",)),
    ("text_editor", ("TEXT_EDITOR",)),
    ("file_browser", ("FILE_BROWSER",)),
    ("spreadsheet", ("SPREADSHEET",)),
    ("asset_browser", ("ASSET_BROWSER",)),
)
ROOT_PANEL_LOGICAL_EDITOR_KEYS = {f"SKM_PT_{editor}_root": aliases for editor, aliases in _EDITORS}
ROOT_PANEL_IDS = tuple(ROOT_PANEL_LOGICAL_EDITOR_KEYS)
ROOT_PANEL_REGIONS = {
    panel: "TOOL_PROPS" if editors == ("ASSET_BROWSER",) else "UI"
    for panel, editors in ROOT_PANEL_LOGICAL_EDITOR_KEYS.items()
}

_OBJECT_MIRROR_KEYS = ("axis", "center_x", "center_y", "center_z", "epsilon")
PERSISTENCE_ROOTS = (
    _SETTINGS,
    "object.skm_uv_map_name", "object.skm_keep_map_shapes",
    *(f"object.skm_mirror_{key}" for key in _OBJECT_MIRROR_KEYS),
    "object.skm_index",
    "scene.shape_xy_tracker_port", "scene.tracker_cam_index",
    "scene.driver_helper_props", "scene.shape_xy_allow_drag",
    "object.shape_xy_groups", "object.shape_xy_group_index",
    "scene.shape_xy_presets", "scene.shape_xy_preset_index",
    "scene.tracker_targets", "scene.tracker_target_index",
)
EXCLUDED_TRANSIENT_PATHS = (
    f"{_SETTINGS}.name", "scene.driver_helper_props.name", "object.skm__suppress_apply", "object.skm_maps",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = ()
PERSISTED_INTERNAL_STATE_KEYS = tuple(f"axis_hud_{key}" for key in ("x", "y", "size"))
