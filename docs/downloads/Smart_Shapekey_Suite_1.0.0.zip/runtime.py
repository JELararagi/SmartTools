# SPDX-License-Identifier: GPL-3.0-or-later
"""Independent suite lifecycle, settings and interactive map operations."""
import contextlib
import importlib
from pathlib import Path
import bpy
from . import lifecycle, maps, map_ops

_settings={}
_ready=False
_registered=[]
_guard=0
_ledger=None
_load_dialog=None
_root_panels=()


def _settings_json_path():
    directory=Path(bpy.utils.user_resource('CONFIG'))/'Smart_Shapekey_Suite'
    return directory/'Smart_Shapekey_Suite.json'


DEFAULTS = {'always_axis_ui_enabled': False,
 'always_external_tracker_enabled': False,
 'always_face_tracker_enabled': False,
 'always_face_tracker_hud_enabled': False,
 'always_frame_sync_enabled': False,
 'axis_hud_size': 200,
 'axis_hud_x': 50,
 'axis_hud_y': 120,
 'axis_point_drag_enabled': False,
 'driverhelper_max': 1.0,
 'driverhelper_min': 0.0,
 'driverhelper_mode': 'LOC',
 'driverhelper_power': 1.0,
 'n_panel_state_save_enabled': True,
 'shape_axis_preset_index': -1,
 'shape_axis_presets': [],
 'shape_xy_allow_drag': False,
 'shape_xy_preset_index': -1,
 'shape_xy_presets': [],
 'shape_xy_tracker_port': 5000,
 'show_always_on_toggles': False,
 'skm_keep_map_shapes': True,
 'skm_mirror_axis': 'X',
 'skm_mirror_center_x': 0.0,
 'skm_mirror_center_y': 0.0,
 'skm_mirror_center_z': 0.0,
 'skm_mirror_epsilon': 0.0010000000474974513,
 'skm_uv_map_name': 'UVMap',
 'tracker_cam_index': 0,
 'ui_sections': {}}

def get_persistent_setting(key,default=None):
    return _settings.get(key,default)


def get_ui_section_state(section_key,default=False):
    return bool(_settings.get('ui_sections',{}).get(str(section_key),default))


def save_ui_section_state(section_key,value):
    if _guard:return
    _settings.setdefault('ui_sections',{})[str(section_key)]=bool(value)
    save_current_panel_settings()


def save_persistent_setting(key,value):
    if _guard:return
    _settings[str(key)]=value
    save_current_panel_settings(force=key=='n_panel_state_save_enabled')


def save_scene_runtime_setting(prop_name,value):
    save_persistent_setting(prop_name,value)


def _scene_and_object(ctx):
    window=getattr(ctx,'window',None)
    if window is None:
        windows=ctx.window_manager.windows
        window=windows[0] if windows else None
    scene=getattr(ctx,'scene',None) or getattr(window,'scene',None)
    layer=getattr(window,'view_layer',None)
    obj=getattr(ctx,'object',None) or (layer.objects.active if layer else None)
    return scene,obj


def _flat_fields(ctx):
    scene,obj=_scene_and_object(ctx)
    return ((getattr(ctx.window_manager,'skm_suite_settings',None),('n_panel_state_save_enabled','show_always_on_toggles',*_flag_map.values())),
            (getattr(scene,'driver_helper_props',None),('driverhelper_mode','driverhelper_min','driverhelper_max','driverhelper_power')),
            (scene,('shape_xy_allow_drag','shape_xy_preset_index','shape_xy_tracker_port','tracker_cam_index')),
            (obj,('skm_keep_map_shapes','skm_mirror_axis','skm_mirror_center_x','skm_mirror_center_y','skm_mirror_center_z','skm_mirror_epsilon')))


def save_current_panel_settings(context=None,force=False):
    if _guard:return False
    from . import settings_io
    if not _settings.get('n_panel_state_save_enabled',True) and not force:return False
    ctx=context or bpy.context
    for owner,names in _flat_fields(ctx):
        if owner is not None:
            for key in names:
                if hasattr(owner,key):_settings[key]=getattr(owner,key)
    if getattr(ctx,'object',None) and ctx.object.type=='MESH':
        uv=getattr(ctx.object,'skm_uv_map_name','')
        if uv:_settings['skm_uv_map_name']=uv
    if settings_io.STATE.last_good and settings_io.STATE.last_good.settings==_settings and _settings_json_path().exists():return True
    settings_io.atomic_write_settings(_settings_json_path(),_settings,DEFAULTS)
    return True


def begin_registration_restore():
    global _guard
    from . import settings_io
    _guard+=1
    snap=settings_io.recover_settings(_settings_json_path(),DEFAULTS,quarantine_main=False)
    _settings.clear()
    _settings.update(snap.settings)
    return snap.settings


def end_registration_restore():
    global _guard
    _guard=max(0,_guard-1)


def apply_registration_restore(payload=None,context=None):
    ctx=context or bpy.context
    values=_settings if payload is None else payload
    for owner,names in _flat_fields(ctx):
        if owner is not None:
            for key in names:
                if key in values and hasattr(owner,key):setattr(owner,key,values[key])
    scene,obj=_scene_and_object(ctx)
    if obj and obj.type=='MESH' and values.get('skm_uv_map_name') in obj.data.uv_layers:
        obj.skm_uv_map_name=values['skm_uv_map_name']
    if scene and values.get('always_frame_sync_enabled'):
        from . import axis_control
        axis_control.set_frame_sync_enabled(True,scene)


def extension_user_dir(*parts,create=True):
    from . import storage
    return str(storage.user_default_root(*parts,create=create))


def _tr(en,ja):
    return ja if bpy.app.translations.locale.startswith('ja') else en


_flag_map={'AXIS_UI':'always_axis_ui_enabled','FRAME_SYNC':'always_frame_sync_enabled',
           'EXTERNAL_TRACKER':'always_external_tracker_enabled','FACE_TRACKER':'always_face_tracker_enabled','FACE_TRACKER_HUD':'always_face_tracker_hud_enabled'}


def _always(context,target,enable):
    scene=context.scene
    if target=='FRAME_SYNC':
        from . import axis_control
        axis_control.set_frame_sync_enabled(enable,scene)
        scene.shape_xy_enable_frame_sync=enable
    elif target=='FACE_TRACKER':
        result=(bpy.ops.shape_xy.tracker_native_start if enable else bpy.ops.shape_xy.tracker_native_stop)()
        if 'FINISHED' not in result:raise ValueError('The face tracker could not change state.')
    elif target=='FACE_TRACKER_HUD':
        from .axis_control.face_tracker import draw_hud
        if enable:draw_hud.start_hud(scene)
        else:draw_hud.stop_hud()
    elif target=='EXTERNAL_TRACKER':
        from .axis_control.interface import tracker
        if enable:tracker.start_tracker(scene.shape_xy_tracker_port)
        else:tracker.stop_tracker()
    elif target=='AXIS_UI':
        from .axis_control.operators.main import stop_axis_hud
        if enable:
            if not context.area or context.area.type!='VIEW_3D':
                raise ValueError('Open the 3D Viewport to start the interactive axis control.')
            outcome=bpy.ops.shape_xy.ui_joystick('INVOKE_DEFAULT')
            if not ({'RUNNING_MODAL','FINISHED'} & outcome):raise ValueError('The interactive axis control could not start.')
        else:stop_axis_hud(context=context)
    setattr(context.window_manager.skm_suite_settings,_flag_map[target],enable)
    save_persistent_setting(_flag_map[target],enable)


class Command:
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        global _load_dialog
        cmd=self.bl_idname.lower().replace('_ot_', '.').rsplit('.', 1)[-1]
        try:
            if cmd=='show_help':
                from . import help
                def body(holder,ctx):
                    help.draw_help_popup(holder.layout,ctx,self.tool_id)
                context.window_manager.popup_menu(body,title=help.get_title(self.tool_id,context),icon='QUESTION')
            elif cmd=='toggle_ui_section':
                from . import ui_sections
                ui_sections.section_state_toggle(context,self.section_key,self.default_state)
            elif cmd=='toggle_always_on':_always(context,self.target,self.enable)
            elif cmd=='show_view3d_npanel':show_view3d_npanel(context)
            elif cmd=='load_toggle_all':
                parent=_load_dialog
                if parent is None or not hasattr(parent,'choices'):raise ValueError('Open the map import dialog first.')
                for choice in parent.choices:choice.selected=self.state
            elif cmd=='load_file' and not bpy.app.background:
                return bpy.ops.skm.load_choose('INVOKE_DEFAULT',filepath=self.filepath)
            else:map_ops.operate(context,self)
            if cmd=='load_choose':_load_dialog=None
            return {'FINISHED'}
        except (ValueError,RuntimeError,IndexError,OSError,KeyError,TypeError) as exc:
            self.report({'WARNING'},str(exc));return {'CANCELLED'}

    def invoke(self,context,event):
        global _load_dialog
        cmd=self.bl_idname.lower().replace('_ot_', '.').rsplit('.', 1)[-1]
        if cmd in ('save_file','load_file'):
            context.window_manager.fileselect_add(self);return {'RUNNING_MODAL'}
        if cmd=='load_choose':
            from . import map_file
            header,_,_=map_file.decode(bpy.path.abspath(self.filepath))
            self.choices.clear()
            _load_dialog=self
            for info in header['maps']:
                choice=self.choices.add();choice.name=info['name'];choice.selected=True
            return context.window_manager.invoke_props_dialog(self)
        if cmd in ('new_map','rename_map','clear_map','set_base','mirror_settings','export_maps','export_shapekeys','export_objects'):
            if hasattr(self,'dialog_invoked'):self.dialog_invoked=True
            return context.window_manager.invoke_props_dialog(self)
        if cmd in ('full_cleanup','delete_map'):return context.window_manager.invoke_confirm(self,event)
        return self.execute(context)

    def cancel(self,context):
        global _load_dialog
        if _load_dialog is self:_load_dialog=None

    def draw(self,context):
        cmd=self.bl_idname.lower().replace('_ot_', '.').rsplit('.', 1)[-1];layout=self.layout
        if cmd=='mirror_settings':
            for prop in ('skm_mirror_axis','skm_mirror_center_x','skm_mirror_center_y','skm_mirror_center_z','skm_mirror_epsilon'):
                layout.prop(context.object,prop)
        elif cmd=='load_choose':
            line=layout.row(align=True)
            for enabled,label in [(True,_tr('Select all','すべて選択')),(False,_tr('Clear selection','選択解除'))]:
                line.operator('skm.load_toggle_all',text=label).state=enabled
            for choice in self.choices:layout.prop(choice,'selected',text=choice.name)
        else:
            for p in self.properties.bl_rna.properties:
                if p.identifier not in {'rna_type','dialog_invoked','check_existing','filter_glob'} and not p.is_hidden and p.type not in ('POINTER','COLLECTION'):
                    layout.prop(self,p.identifier)


class MapList:
    def draw_item(self,context,layout,data,item,icon,active_data,active_propname,index=0,flt_flag=0):
        row=layout.row(align=True)
        if data.skm_edit_mode and item.chn_id!=99:row.prop(item,'selected',text='')
        row.label(text=item.name,icon='SHAPEKEY_DATA' if item.chn_id!=99 else 'MESH_DATA')


class SuitePanel:
    bl_label='Smart Shapekey'
    bl_category='Smart Shapekey'
    bl_region_type='UI'
    def draw_header_preset(self,context):
        self.layout.operator('skm.show_help',text='',icon='QUESTION').tool_id='root'
    @classmethod
    def poll(cls,context):
        if 'asset_browser' in cls.__name__:return getattr(context.area,'ui_type','')=='ASSETS'
        if 'file_browser' in cls.__name__:return getattr(context.area,'ui_type','')!='ASSETS'
        return True
    def draw(self,context):draw_view3d_npanel_contents(self.layout,context)


def draw_view3d_npanel_contents(layout,context):
    from . import ui_sections,common,facial_capture
    from .apply_modifiers_with_shape_keys import draw_apply_modifiers_body
    from .driver_helper import draw_driver_helper_body
    from .axis_control.ui.panel import draw_shape_axis_control_body
    from .axis_control.interface.tracker import draw_external_tracker_body
    from .axis_control.face_tracker.ui import draw_face_tracker_body
    obj=context.active_object
    def header(key,en,ja,icon):
        return ui_sections.draw_collapsible_section(layout,context,'runtime.'+key,_tr(en,ja),icon=icon,help_id=key,default=False)
    def commands(box,items):
        if box is None:return
        for name,en,ja in items:box.operator('skm.'+name,text=_tr(en,ja))
    b=header('always_on','Always-on Toggles','常時機能切り替え','TIME')
    if b is not None:common.draw_always_on_panel(b,context)
    commands(header('base','Basis and New Map','Basis と新規マップ','MESH_DATA'),[
        ('set_base','Set Base','ベースを設定'),('new_map','New Map','新規')])
    b=header('maps','Maps','マップ','SHAPEKEY_DATA')
    if b is not None and obj and obj.type=='MESH':
        b.prop(obj,'skm_edit_mode',text=_tr('Edit list','一覧を編集'))
        b.template_list('SKM_UL_MapList','',obj,'skm_maps',obj,'skm_edit_index' if obj.skm_edit_mode else 'skm_index',rows=4)
        commands(b,[('store_map','Store current shape','現在の形状を保存'),('rename_map','Rename','名前変更'),('duplicate_map','Duplicate','複製'),('clear_map','Clear','クリア'),('delete_map','Delete','削除')])
        b.operator('skm.duplicate_map',text=_tr('Duplicate inverted','反転して複製')).inverted=True
        for direction,en,ja in [('UP','Up','上へ'),('DOWN','Down','下へ')]:b.operator('skm.move_map',text=_tr(en,ja)).direction=direction
        for mode,en,ja in [('NAME','Name order','名前順'),('CHANNEL_ID','ID order','ID順')]:b.operator('skm.order_maps',text=_tr(en,ja)).mode=mode
    b=header('mirror_tools','Mirror Tools','ミラーと反転ツール','MOD_MIRROR')
    if b is not None:
        commands(b,[('copy_selected_verts','Copy selected vertices','選択頂点をコピー'),('paste_verts','Paste','貼り付け'),('invert_selected','Invert selected','選択頂点を反転')])
        b.operator('skm.paste_verts',text=_tr('Paste mirrored','反転して貼り付け')).mirrored=True
        for code,label in [('LR','− → +'),('RL','+ → −')]:b.operator('skm.mirror_selected',text=label).direction=code
    commands(header('export','Export','書き出し','EXPORT'),[('import_shape_keys','Read shape keys','シェイプキーを読み込み'),('export_maps','Export maps','書き出し'),('export_shapekeys','Write shape keys','シェイプキーに書き出し'),('export_objects','Create expression meshes','表情メッシュを作成')])
    commands(header('files','Save/Load','保存と読み込み','FILE_FOLDER'),[('save_file','Save maps','全て保存'),('save_overwrite','Save to last file','前回のファイルを更新'),('load_file','Load maps','読み込み'),('clean_orphans','Clean unused channels','未使用チャンネルを整理'),('full_cleanup','Remove all maps','すべて削除')])
    commands(header('mirror_settings','Mirror Settings','ミラー設定','PREFERENCES'),[('mirror_settings','Mirror settings','ミラー設定')])
    b=header('modifiers','Modifiers','モディファイア','MODIFIER')
    if b is not None:
        sub=ui_sections.draw_child_section(b,context,'runtime.modifiers.apply_modifiers',_tr('Apply Keeping Shape Keys','シェイプキー保持で適用'),help_id='apply_modifiers')
        if sub is not None:draw_apply_modifiers_body(sub,context)
    b=header('drivers','Drivers','ドライバー','DRIVER')
    if b is not None:draw_driver_helper_body(b,context)
    b=header('tracking','Control / Tracking','制御・トラッキング','TRACKER')
    if b is not None:
        for key,en,ja,fn in [('axis','Shape axes','シェイプ軸',draw_shape_axis_control_body),('tracker','External tracker','外部トラッカー',draw_external_tracker_body),('face','Face tracker','フェイストラッカー',draw_face_tracker_body),('capture','Facial capture','フェイシャル収録',facial_capture.draw)]:
            sub=ui_sections.draw_child_section(b,context,'runtime.tracking.'+key,_tr(en,ja),help_id=key)
            if sub is not None:fn(sub,context)


def show_view3d_npanel(context=None,reuse_existing=True):
    ctx=context or bpy.context
    if ctx.area and ctx.area.type=='VIEW_3D':
        ctx.space_data.show_region_ui=True
        side=next((r for r in ctx.area.regions if r.type=='UI'),None)
        if side:side.active_panel_category='Smart Shapekey'
    return True


def register_runtime(ledger):
    global _ledger,_root_panels
    from . import icons,translation,common,map_bindings,control_help
    _ledger=ledger;begin_registration_restore()
    try:
        translation.register();ledger.record('translation','smart_shapekey_suite',translation.unregister)
        control_help.register();ledger.record('translation',control_help.__name__,control_help.unregister)
        icons.register();ledger.record('icons','smart_shapekey_suite',icons.unregister)
        for cls in map_bindings.GROUPS:lifecycle.register_class(ledger,cls)
        map_bindings.properties(ledger)
        for cls in map_bindings.COMMANDS:lifecycle.register_class(ledger,cls)
        common.register(ledger)
        for name in ('apply_modifiers_with_shape_keys','driver_helper','axis_control'):
            mod=importlib.import_module('.'+name,__package__)
            mod.register(ledger);_registered.append(mod)
            ledger.record('module',mod.__name__,mod.unregister)
        for cls in map_bindings.PANELS:lifecycle.register_class(ledger,cls)
        _root_panels=map_bindings.PANELS
        apply_registration_restore()
    finally:end_registration_restore()


def mark_runtime_ready(token):
    global _ready
    _ready=True


def unregister_runtime():
    global _ready,_ledger,_root_panels
    _ready=False;_ledger=None;_root_panels=();_registered.clear()
    maps.busy.clear();_settings.clear()


def abort_runtime_registration(*args):unregister_runtime()
def prepare_view3d_npanel_panels(*args):return view3d_npanel_classes()
def view3d_npanel_classes():return tuple(_root_panels)
def install_view3d_npanel_panels(*,deferred=False):
    if _ledger is None:return False
    for cls in view3d_npanel_classes():
        if getattr(bpy.types,cls.__name__,None) is None:lifecycle.register_class(_ledger,cls)
    return all(getattr(bpy.types,c.__name__,None) is c for c in view3d_npanel_classes())

def uninstall_view3d_npanel_panels():
    for cls in reversed(view3d_npanel_classes()):
        if getattr(bpy.types,cls.__name__,None) is cls:lifecycle.unregister_class_exact(cls)
    return all(getattr(bpy.types,c.__name__,None) is not c for c in view3d_npanel_classes())
def is_runtime_registered():return _ready
def ensure_runtime_loaded(context=None):return _ready
def teardown_runtime_activity(*args,**kwargs):
    from .axis_control import stop_frame_sync
    from .axis_control.interface.tracker import stop_tracker
    from .axis_control.face_tracker.draw_hud import stop_hud
    from . import axis_control
    for func in (stop_frame_sync,stop_tracker,stop_hud,axis_control.clear_runtime_cache):
        with contextlib.suppress(RuntimeError,AttributeError):func()
def runtime_audit_snapshot():return {'registered':_ready,'panels':len(_root_panels),'modules':len(_registered)}
