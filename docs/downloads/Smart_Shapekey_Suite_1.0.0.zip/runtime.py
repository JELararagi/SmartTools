# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
import bmesh
from bpy_extras.io_utils import ExportHelper
import os
import json
import re
import shutil
import sys
import time
import uuid
from collections import OrderedDict
from pathlib import Path
from bpy.app.handlers import persistent
from mathutils import Vector
from array import array
from math import floor

from . import translation as _sss_translation
from . import lifecycle as _sss_lifecycle
from . import activity as _sss_activity
from . import settings_io as _sss_settings_io
from . import persistence_policy as _sss_persistence_policy
from . import ownership as _sss_ownership
from . import common as _sss_common
try:
    from . import storage as _sss_storage
except Exception:
    _sss_storage = None
try:
    from . import icons as _sss_icons
except Exception:
    _sss_icons = None
try:
    from . import ui_sections as _skm_ui_sections
except Exception:
    _skm_ui_sections = None
import sys as _skm_sys


# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------
PREFIX = "SKM_"
BASE_ID = 99
BASIS_NAME = "Basis"
DEFAULT_MAP_BASENAME = "NewMap"

REF_COLLECTION_NAME = "SKM_Refs"
REF_TAG_PROP = "SKM_REF_FOR"            # stored on ref object
OBJ_PROP_REF = "skm_ref_object_name"    # stored on main object (custom prop)
OBJ_PROP_UV = "skm_uv_map_name"         # stored on main object (custom prop)
OBJ_PROP_ACTIVE_CHANNEL = "skm_morphmapper_active_channel"
MM_BASIS_ATTRIBUTE = ".skm_morphmapper_basis"
MM_PREVIEW_KEY_NAME = "SKM_Map_Preview"
MM_DELTA_PREFIX = ".skm_morphmapper_delta_"

FILE_EXT = ".skmuv"

ADDON_NAME = "Smart Shapekey Suite"
PANEL_TAB_NAME = "Smart Shapekey"

# Test-only fault boundary used by the non-GUI transaction audit and Blender
# fault-injection harness.  It is never populated during normal operation.
_MAP_FAULT_INJECTION_HOOK = None


def _map_checkpoint(stage: str) -> None:
    hook = _MAP_FAULT_INJECTION_HOOK
    if callable(hook):
        hook(str(stage))

# Smart Tools Manager compatibility.  The Suite declares one immutable native
# root for every supported physical editor and resolves the 17 logical editor
# keys through the Manager's public read-only current-cell rule API.
_SKM_NPANEL_SPACE_TYPES = {
    'VIEW_3D',
    'IMAGE_EDITOR',
    'NODE_EDITOR',
    'SEQUENCE_EDITOR',
    'CLIP_EDITOR',
    'DOPESHEET_EDITOR',
    'GRAPH_EDITOR',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'FILE_BROWSER',
    'SPREADSHEET',
}

_SKM_SMART_TOOLS_MANAGER_EDITOR_KEYS = (
    'VIEW_3D',
    'IMAGE_EDITOR',
    'UV_EDITOR',
    'SHADER_EDITOR',
    'COMPOSITOR',
    'GEOMETRY_NODE_EDITOR',
    'TEXTURE_NODE_EDITOR',
    'VIDEO_SEQUENCER',
    'MOVIE_CLIP_EDITOR',
    'DOPE_SHEET',
    'GRAPH_EDITOR',
    'DRIVERS',
    'NLA_EDITOR',
    'TEXT_EDITOR',
    'ASSET_BROWSER',
    'FILE_BROWSER',
    'SPREADSHEET',
)

# Storage UV layer naming: 2 layers per map/channel (XY / Z0) on the *reference mesh*.
def _uv_store_name_a(chn_id: int) -> str:
    return f"{PREFIX}CH{chn_id:02d}_A"

def _uv_store_name_b(chn_id: int) -> str:
    return f"{PREFIX}CH{chn_id:02d}_B"


# -----------------------------------------------------------------------------
# i18n (detailed tooltips for beginners)
# -----------------------------------------------------------------------------
translation_dict = {
    "ja_JP": {
        ("*", ADDON_NAME): "Smart Shapekey Suite",
        ("*", "Smart Shapekey"): "Smart Shapekey",
        ("*", "Basis and New Map"): "Basis と新規マップ",
        ("*", "Store Current Channel"): "現在のチャンネルを保存",
        ("*", "Store Selected Polygons"): "選択ポリゴンを保存",
        ("*", "Set Base on Selected Polygons"): "選択ポリゴンのベースを設定",
        ("*", "Clear Selected Polygons"): "選択ポリゴンをクリア",
        ("*", "Clear All"): "すべてクリア",
        ("*", "Delete All"): "すべて削除",
        ("*", "Rename Map"): "マップ名を変更",
        ("*", "Rename the active map without changing its channel ID or geometry."): "チャンネルIDや形状を変えずにアクティブなマップ名を変更します。",
        ("*", "Name must not be empty."): "名前を入力してください。",
        ("*", "Map name already exists."): "同じ名前のマップが既にあります。",
        ("*", "Edit"): "編集",
        ("*", "Auto Key is enabled. Turn it off before switching maps."): "オートキーがONになっています。マップを切り替える前にOFFにしてください。",
        ("*", "Selected Polygons"): "選択ポリゴン",
        ("*", "All Polygons"): "すべてのポリゴン",
        ("*", "Mapping Channel: {id}"): "マッピングチャンネル: {id}",
        ("*", "Reference Map: {name}"): "参照マップ: {name}",
        ("*", "Current Map Name: {name}"): "現在のマップ名: {name}",
        ("*", "Choose a nonempty new name."): "空でない新しい名前を入力してください。",
        ("*", "Clear"): "クリア",
        ("*", "Clear the active Morph Map on selected or all polygons."): "アクティブなモーフマップを選択ポリゴンまたは全ポリゴンでクリアします。",
        ("*", "Output"): "出力先",
        ("*", "Shape Keys"): "シェイプキー",
        ("*", "Prefix"): "接頭辞",
        ("*", "Offset"): "間隔",
        ("*", "Line"): "1行の個数",
        ("*", "Replace matching Shape Keys"): "同名のシェイプキーを置換",
        ("*", "Export Morph Maps"): "モーフマップを書き出し",
        ("*", "New"): "新規",
        ("*", "Rename"): "名前変更",
        ("*", "Delete"): "削除",
        ("*", "Import"): "読み込み",
        ("*", "Up"): "上へ",
        ("*", "Down"): "下へ",
        ("*", "Order Maps"): "マップを並べ替え",
        ("*", "Sort by Name"): "名前順",
        ("*", "ID Order"): "ID順",
        ("*", "Import Shape Keys to Channels"): "シェイプキーをチャンネルへ読み込み",
        ("*", "Commit the current mesh coordinates to the active map channel as Basis-relative XYZ offsets."): "現在のメッシュ座標を Basis 相対XYZオフセットとしてアクティブなマップチャンネルへ保存します。",
        ("*", "Sort map rows without changing channel identity or stored geometry."): "チャンネルIDや保存済み形状を変えずにマップ行を並べ替えます。",
        ("*", "Append every non-Basis Shape Key as an exact Basis-relative map channel."): "Basis以外の各シェイプキーを正確なBasis相対マップチャンネルとして追加します。",
        ("*", "Select at least one polygon."): "ポリゴンを1つ以上選択してください。",
        ("*", "No non-Basis Shape Keys are available."): "Basis以外のシェイプキーはありません。",
        ("*", "Shape Key topology does not match the stored Basis."): "シェイプキーのトポロジーが保存済みBasisと一致しません。",
        ("*", "No free map channel is available."): "空きマップチャンネルがありません。",
        ("*", "No non-Basis Shape Keys were imported."): "Basis以外のシェイプキーは読み込まれませんでした。",
        ("*", "Owned map attribute has an incompatible type: {name}"): "所有するマップ属性の型に互換性がありません: {name}",
        ("*", "The mesh topology does not match the stored Basis."): "マップのトポロジーが保存済みBasisと一致しません。",
        ("*", "Maps require local single-user mesh data."): "マップにはローカルの単一ユーザーメッシュデータが必要です。",
        ("*", "Basis is immutable; use Set Base for an explicit replacement."): "Basisは不変です。明示的に置き換えるにはSet Baseを使用してください。",
        ("*", "Always-on Features"): "常時機能切り替え",
        ("*", "Always-on Toggles"): "常時機能切り替え",
        ("*", "Always-on Features draw failed."): "常時機能切り替えの描画に失敗しました。",
        ("*", "Enable or disable a long-running Smart Shapekey feature from the unified Always-on Features group."): "常時機能切り替えグループから、Smart Shapekey の継続動作機能を有効または無効にします。",
        ("*", "N-panel State Save"): "Nパネル状態保存",
        ("*", "When enabled, every Smart Shapekey N-panel setting change is saved immediately to the Blender config JSON. Turning it off saves that Off state once; all later writers remain blocked until it is enabled again."): "有効の場合は、Smart Shapekey のNパネル設定変更をBlender config内のJSONへ即時保存します。無効へ切り替えた操作だけを最後に1回保存し、再度有効にするまで以後の書き込みをすべて停止します。",
        ("*", "Tool Settings"): "ツール設定",
        ("*", "UV-driven shape map storage & export (topology independent by UV)."):
            "UVを基準にした形状マップの保存と書き出しを行い、UV が一致する別トポロジーにも復元できる機能です。",
        ("*", "UV-driven shapekey map storage, mirroring, save/load, export, and cleanup for the 3D View N-panel."): "UVをキーに形状を保存し、トポロジーが変わってもUVが一致すれば復元・書き出しできるNパネル用ツール。",

        # Header / basics
        ("*", "Select a mesh object."): "メッシュオブジェクトを選択してください。",
        ("*", "Object"): "オブジェクト",
        ("*", "Verts"): "頂点数",
        ("*", "Maps"): "マップ",
        ("*", "Map Count"): "マップ数",

        # UV
        ("*", "UV Map"): "UVマップ",
        ("*", "Choose the UV map used as the correspondence key. The tool reconstructs shapes by sampling in UV space."): "対応付けに使うUVマップを選びます。本ツールは“UV空間でサンプリング”して形状を復元するため、別トポロジーでもUVが同じなら復元できます。",

        # Keep toggle
        ("*", "Keep Map Shapes"): "マップ形状を保持",
        ("*", "When ON, maps are treated as absolute shapes in UV space. Base deformation does not affect maps. When OFF, maps follow base deformation by applying offsets."): "ON：マップは“絶対形状”として保存または適用され、ベースを変形してもマップは影響を受けません。OFF：マップはベースの変形に追従し、オフセットとして適用されます。",

        # Base / map ops
        ("*", "Set Base"): "ベースを設定",
        ("*", "Create a base snapshot (Basis) used as reference. This does NOT change the current mesh."): "基準となるベース（Basis）を作成します。現在のメッシュ形状は変更しません（UVと形状を参照データとして保存するだけです）。",
        ("*", "New Map"): "新規マップ",
        ("*", "Create a new map from the current mesh shape. The mesh shape is not changed."): "現在の形状から新しいマップを作成します。現在のメッシュ形状は変更しません。",

        ("*", "Delete Map"): "マップ削除",
        ("*", "Delete the selected map (locked maps cannot be deleted)."): "選択中のマップを削除します（ロック中は削除できません）。",
        ("*", "Duplicate Map"): "複製",
        ("*", "Duplicate the selected map as a new map."): "選択中のマップを複製して新規マップとして追加します。",
        ("*", "Duplicate Inverted"): "反転で複製",
        ("*", "Create a duplicated map, inverted around Basis (new = 2*Basis - Map)."): "選択中のマップをベース基準で反転して複製します（新 = 2*Basis − 元マップ）。",
        ("*", "Move Up"): "上へ",
        ("*", "Move Down"): "下へ",
        ("*", "Reorder the map list. Export order follows this list order."): "マップリストを並び替えます。書き出しの順もこの並び順に従います。",

        # Map list fields
        ("*", "Select"): "選択",
        ("*", "If enabled, this map will be included when using Selected export/save."): "オンにすると「選択のみ」の書き出しまたは保存に含まれます。",
        ("*", "Lock"): "ロック",
        ("*", "Lock the map to prevent deletion."): "ロックすると削除できなくなります。",
        ("*", "Map name (must be unique). Click to rename."): "マップ名（重複不可）。クリックでリスト上から直接リネームできます。",

        # Mirror tools
        ("*", "Mirror Tools"): "ミラーと反転ツール",
        ("*", "Mirror Settings"): "ミラー設定",
        ("*", "Open mirror settings (axis / center / tolerance)."): "ミラー設定（軸・中心・許容距離）を開きます。",
        ("*", "Axis"): "軸",
        ("*", "Mirror axis used by mirror tools."): "ミラーに使用する軸です。",
        ("*", "Center X"): "中心X",
        ("*", "Center Y"): "中心Y",
        ("*", "Center Z"): "中心Z",
        ("*", "Mirror center coordinate. Usually 0.0 for symmetrical models."): "ミラー中心座標です。左右対称モデルなら通常0.0です。",
        ("*", "Tolerance"): "許容値",
        ("*", "Mirror Axis"): "ミラー軸",
        ("*", "Mirror Center"): "ミラー中心",
        ("*", "Mirror Epsilon"): "ミラー許容値",
        ("*", "Maximum distance to find the mirrored counterpart vertex. Increase if vertices do not match."): "ミラー先頂点を探す最大距離です。対応が取れない場合は少し増やしてください。",

        ("*", "Copy Selected Verts"): "選択頂点のコピー",
        ("*", "Copy positions of currently selected vertices into an internal clipboard."): "現在選択中の頂点座標を内部クリップボードにコピーします。",
        ("*", "Paste Verts"): "頂点の貼り付け",
        ("*", "Paste copied vertex positions back to the currently selected vertices."): "コピーした頂点座標を、現在選択中の頂点へ貼り付けます。",
        ("*", "Paste Mirrored"): "反転して貼り付け",
        ("*", "Paste copied vertex positions mirrored (uses mirror settings)."): "コピーした頂点座標をミラーして貼り付けます（ミラー設定を使用）。",
        ("*", "Invert Selected Shape"): "選択頂点の形状を反転",
        ("*", "Invert the current selection around Basis (selected verts only)."): "選択頂点のみをベース（Basis）基準で反転します。",
        ("*", "Mirror Selected (L→R)"): "選択頂点の形状をミラー（左→右）",
        ("*", "Mirror Selected (R→L)"): "選択頂点の形状をミラー（右→左）",

        # Export
        ("*", "Export"): "書き出し",
        ("*", "Target"): "対象",
        ("*", "All"): "全て",
        ("*", "Selected"): "選択のみ",
        ("*", "Export to Shape Keys"): "シェイプキーへ書き出し",
        ("*", "Export all or selected maps as Shape Keys on the active object."): "全てまたは選択中のマップをシェイプキーとしてアクティブオブジェクトに書き出します。",
        ("*", "Export to Objects"): "オブジェクトに書き出し",
        ("*", "Create clean mesh objects for each map, placed in a grid."): "各マップをクリーンオブジェクトとして生成し、グリッド配置します。",
        ("*", "Spacing"): "間隔",
        ("*", "Distance between generated objects. Example: 0.5 means 50cm if your scene uses meters."): "生成オブジェクト同士の間隔です。例：シーン単位がmなら0.5で50cm。",
        ("*", "Columns"): "列数",
        ("*", "How many objects per row before wrapping to next row."): "横に並べる数（この数で折り返して次の行に移ります）。",
        ("*", "Start"): "開始位置",
        ("*", "3D Cursor"): "3Dカーソル",
        ("*", "Active Object"): "アクティブ",
        ("*", "World Origin"): "原点",
        ("*", "Choose where the grid starts."): "配置の開始位置を選びます。",

        # Save/Load
        ("*", "Save/Load"): "保存と読み込み",
        ("*", "Save (All)"): "全て保存",
        ("*", "Save Map File"): "マップファイルを保存",
        ("*", "Overwrite Map File"): "マップファイルの上書き",
        ("*", "Replace the existing map file with the current maps."): "既存のマップファイルを今のマップで置き換えます。",
        ("*", "This file already exists: {name}"): "このファイルは既にあります: {name}",
        ("*", "Overwrite"): "上書き",
        ("*", "Save all maps to an external file."): "全マップを外部ファイルに保存します。",
        ("*", "Save (Selected)"): "選択を保存",
        ("*", "Save only maps with the Select checkbox enabled in the list."): "マップの一覧でチェックを入れたマップだけを外部ファイルに保存します。",
        ("*", "Load"): "読み込み",
        ("*", "Load maps from an external file. A popup lets you choose which maps to import."): "外部ファイルからマップを読み込みます。ポップアップで読み込むマップを選べます。",
        ("*", "Choose maps to import"): "読み込むマップを選択",
        ("*", "Select All"): "全選択",
        ("*", "Deselect All"): "全選択解除",

        # Cleanup
        ("*", "Cleanup"): "クリーンアップ",
        ("*", "Clean Orphans"): "孤立キャッシュ掃除",
        ("*", "Remove hidden/unused internal map data that is not listed."): "リストに表示されていない隠れマップや不要な内部データを削除します。",
        ("*", "Clean Orphans (Scene)"): "シーン内の全孤立キャッシュを掃除",
        ("*", "Run orphan cleanup for all objects in the scene using this tool."): "シーン内で本ツールを使っている全オブジェクトに孤立掃除を実行します。",
        ("*", "Full Cleanup"): "全てクリーンナップ",
        ("*", "Delete ALL data created by this tool on the selected object."): "選択オブジェクトの本ツール関連データをすべて削除します。",
        ("*", "Full Cleanup (Scene)"): "シーン内を全てクリーンナップ",
        ("*", "Delete ALL data created by this tool from ALL objects in the scene."): "シーン内全オブジェクトから本ツール関連データをすべて削除します。",

        # Messages
        ("*", "Active object must be a mesh."): "アクティブオブジェクトはメッシュである必要があります。",
        ("*", "No UV layers found."): "UVレイヤーが見つかりません。",
        ("*", "Please run Set Base first."): "先に「ベースを設定」を実行してください。",
        ("*", "Locked map cannot be deleted."): "ロック中のマップは削除できません。",
        ("*", "Basis cannot be deleted."): "Basisは削除できません。",
        ("*", "Map name must be unique."): "マップ名は重複できません。",
        ("*", "Done."): "完了しました。",
        ("*", "No maps were selected."): "マップが選ばれていません。",
        ("*", "Invalid file."): "ファイル形式が不正です。",
        ("*", "This map file cannot be rebuilt on a different topology. Load it on a mesh with the same loop count."): "このマップファイルは、異なるトポロジーの上には作り直せません。ループ数が同じメッシュへ読み込んでください。",
        ("*", "Show the Smart Shapekey controls in the 3D View N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data."): "スマートシェイプキー操作項目を3DビューのNパネルに表示します。ベース形状の設定、UV基準マップ保存、頂点編集のミラー、マップファイルの保存と読み込み、結果の書き出し、ツールデータ整理に使います。",

        # Panel section headers / states
        ("*", "Object / UV / Base"): "オブジェクト / UV / ベース",
        ("*", "Switch to Object Mode or Edit Mode."): "オブジェクトモードまたは編集モードに切り替えてください。",
        ("*", "This section is not available."): "このセクションは利用できません。",
        ("*", "Toggle UI Section"): "UIセクションを開閉",
        ("*", "Expand or collapse this Smart Shapekey UI section."): "この Smart Shapekey UIセクションを展開または折りたたみます。",
        ("*", "Bundled tool sections draw failed."): "同梱ツールセクションの描画に失敗しました。",
        ("*", "Modifiers UI draw failed."): "モディファイアUIの描画に失敗しました。",
        ("*", "Drivers UI draw failed."): "ドライバーUIの描画に失敗しました。",
        ("*", "Control / Tracking UI draw failed."): "コントロール / トラッキングUIの描画に失敗しました。",

        # Property tooltips
        ("*", "Choose the UV map used as the correspondence key."): "対応付けキーに使うUVマップを選びます。",
        ("*", "Keep maps as absolute UV-space shapes instead of base-relative offsets."): "マップをベース相対オフセットではなく、UV空間の絶対形状として保持します。",
        ("*", "Mirror center coordinate."): "ミラー中心座標です。",
        ("*", "Maximum mirrored counterpart distance."): "ミラー先対応頂点を探す最大距離です。",
        ("*", "When enabled, clean this add-on's reference data in the current scene."): "有効の場合、現在のシーン内でこのアドオンが作った物と確認できた参照データを掃除します。",
        ("*", "When enabled, remove this add-on's reference data in the current scene."): "有効の場合、現在のシーン内でこのアドオンが作った物と確認できた参照データを削除します。",
        ("*", "Remove unused internal map layers from this add-on's reference data."): "このアドオンが作った物と確認できた参照データからのみ、未使用の内部マップレイヤーを削除します。",
        ("*", "Delete all map data of the selected object."): "選択オブジェクトから、このアドオンが作った物と確認できたマップ参照データのみを削除します。",

        # Reports / popups / validation messages
        ("*", "No Blender context is available."): "Blenderコンテキストを利用できません。",
        ("*", "The selected map has no valid stored geometry."): "選択中のマップに有効な保存形状がありません。",
        ("*", "The reference mesh loop count is outside the supported range."): "参照メッシュのループ数が対応範囲外です。",
        ("*", "Too many maps were selected for one file."): "1つのファイルに対して選択されたマップが多すぎます。",
        ("*", "Map geometry contains NaN or Infinity."): "マップ形状に NaN または Infinity が含まれています。",
        ("*", "Map metadata is too large."): "マップのメタデータが大きすぎます。",
        ("*", "The map file exceeds the supported size limit."): "マップファイルが対応サイズ上限を超えています。",
        ("*", "The destination folder does not exist."): "保存先フォルダーが存在しません。",
        ("*", "The settings file was damaged or could not be saved; the last validated settings remain active."): "設定ファイルが破損しているか保存できませんでした。最後に検証済みの設定が有効なまま維持されます。",
        ("*", "A requested runtime feature could not be started. The saved setting was kept unchanged."): "要求されたランタイム機能を開始できませんでした。保存済み設定は変更されていません。",
        ("*", "The requested runtime feature could not be started. The saved setting was kept unchanged."): "要求されたランタイム機能を開始できませんでした。保存済み設定は変更されていません。",
        ("*", "The requested runtime feature could not be started and was returned to Off."): "要求されたランタイム機能を開始できなかったため、オフに戻しました。",
        ("*", "No maps are selected for export."): "書き出し対象のマップが選択されていません。",
        ("*", "No collection is available for export."): "書き出しに使えるコレクションがありません。",
        ("*", "No collection is available for staging."): "ステージングに使えるコレクションがありません。",
        ("*", "Map metadata validation failed."): "マップのメタデータ検証に失敗しました。",
        ("*", "A selected map has no complete stored geometry."): "選択されたマップに完全な保存形状がありません。",
        ("*", "Map vertex count validation failed."): "マップの頂点数検証に失敗しました。",
        ("*", "This mesh has Shape Keys. Switch to Object Mode before switching maps."): "このメッシュにはシェイプキーがあります。オブジェクトモードにしてからマップを切り替えてください。",
        ("*", "Staged Shape Key validation failed."): "ステージング中のシェイプキー検証に失敗しました。",
        ("*", "Shape Key mesh swap validation failed."): "シェイプキーのメッシュ入れ替え検証に失敗しました。",
        ("*", "Generated object validation failed."): "生成オブジェクトの検証に失敗しました。",
        ("*", "Generated object commit validation failed."): "生成オブジェクトの確定検証に失敗しました。",
        ("*", "Choose where to save the Smart Shapekey map file first."): "先に Smart Shapekey マップファイルの保存先を選んでください。",
        ("*", "Choose a Smart Shapekey map file first."): "先に Smart Shapekey マップファイルを選んでください。",
        ("*", "The selected map file is no longer available."): "選択されたマップファイルは利用できなくなりました。",
        ("*", "Select at least one map to import."): "読み込むマップを1つ以上選択してください。",
        ("*", "This map file cannot be rebuilt on a different topology."): "このマップファイルは異なるトポロジー上では再構築できません。",
        ("*", "No free map channel remains."): "空きマップチャンネルが残っていません。",
        ("*", "The UV layout of this mesh differs from the map file, so the shape would break. Nothing was loaded. Give the mesh the same UV layout, then load again."): "このメッシュの UV の開き方がファイルと違うので、読み込むと形が崩れます。読み込みを止めました（メッシュは変わっていません）。UV の開き方を同じにしてから読み込んでください。",
        ("*", "The saved mesh has overlapping UVs, so positions cannot be read from them on a different vertex layout. Nothing was loaded. Save from a mesh without overlapping UVs, or load onto a mesh with the same vertex layout."): "保存元のメッシュの UV が重なっているので、頂点の並びが違うメッシュへは位置を読み取れません。読み込みを止めました（メッシュは変わっていません）。UV が重ならないメッシュから保存するか、頂点の並びが同じメッシュへ読み込んでください。",
    }
}

def _t(msg: str) -> str:
    text = str(msg)
    try:
        translated = _sss_translation.pgettext(text)
        if translated != text:
            return translated
    except Exception:
        translated = text
    try:
        if _sss_translation.is_japanese_locale():
            local = translation_dict.get("ja_JP", {}).get(("*", text))
            if local:
                return str(local)
    except Exception:
        pass
    try:
        translated = bpy.app.translations.pgettext(text)
        if translated:
            return translated
    except Exception:
        pass
    return text


def _t_alt(msgid: str, english: str) -> str:
    """Translate *msgid* (a key of its own); show *english* where it has no translation.

    The count line "Maps: N" needs マップ数 in Japanese while the Maps heading is マップ, so the
    count uses the separate key "Map Count" and keeps the English text "Maps".
    """
    text = _t(msgid)
    return english if text == msgid else text


def _extension_package_name() -> str:
    try:
        if _sss_storage is not None:
            package_id = getattr(_sss_storage, 'PACKAGE_ID', '')
            if package_id:
                return str(package_id)
    except Exception:
        pass
    package = str(__package__ or __name__ or "").strip()
    if package:
        package = package.split(".", 1)[0]
    return package or "smart_shapekey_suite"


def _legacy_extension_user_dir(*parts: str) -> str:
    """Return the old package-local mutable path without creating it."""
    base = os.path.dirname(os.path.abspath(__file__))
    if parts:
        base = os.path.join(base, *parts)
    return base


def _extension_user_dir(*parts: str, create: bool = True) -> str:
    """Return this suite's mutable CONFIG path.

    The historical function name is retained for internal compatibility, but
    it must never resolve inside the installed Extension package.
    """
    package = _extension_package_name()
    if _sss_storage is not None:
        try:
            path = _sss_storage.user_default_root(*parts, package_id=package, create=bool(create))
            return str(path)
        except Exception:
            pass
    base = os.path.join(str(_blender_config_dir(bool(create))), 'Smart_Shapekey_Suite')
    if parts:
        base = os.path.join(base, *parts)
    if create:
        os.makedirs(base, exist_ok=True)
    return base


def _default_map_filepath() -> str:
    if bpy.data.filepath:
        base_name = bpy.path.display_name_from_filepath(bpy.data.filepath) or "skm_maps"
    else:
        base_name = "skm_maps"
    base_name = bpy.path.clean_name(base_name) or "skm_maps"
    return os.path.join(_extension_user_dir("maps"), bpy.path.ensure_ext(base_name, FILE_EXT))



# -----------------------------------------------------------------------------
# Persistent N-panel settings
# -----------------------------------------------------------------------------
# The suite keeps lightweight UI/runtime preferences outside the blend file so
# N-panel settings survive Blender restarts and are also applied when a different
# scene or file is opened. Heavy map data, shape-key maps, and object-specific
# collections remain ordinary Blender data and are saved in the .blend file.
_SKM_SETTINGS_DIRNAME = "Smart_Shapekey_Suite"
_SKM_SETTINGS_FILE = "Smart_Shapekey_Suite.json"
_SKM_SETTINGS_CACHE: dict[str, object] | None = None
_SKM_SETTINGS_PENDING: dict[str, object] | None = None
_SKM_RESTORING_SETTINGS = False
_SKM_REGISTRATION_WRITE_GUARD_DEPTH = 0
_SKM_WRITE_BARRIER = _sss_persistence_policy.WriteBarrier()
# Bounded one-shot UI notices for runtime feature start failures.  These are
# deliberately separate from persistence faults so a temporary camera/socket
# failure never marks validated JSON dirty or overwrites a saved ON preference.
_SKM_RUNTIME_NOTICE_PENDING: OrderedDict[str, str] = OrderedDict()
_SKM_RUNTIME_NOTICE_SHOWN: set[str] = set()
_SKM_RUNTIME_NOTICE_LIMIT = 16

_SKM_PERSISTENT_DEFAULTS: dict[str, object] = {
    "n_panel_state_save_enabled": True,
    "show_always_on_toggles": False,
    "always_axis_ui_enabled": False,
    "axis_point_drag_enabled": False,
    "shape_xy_allow_drag": False,
    "always_frame_sync_enabled": False,
    "always_external_tracker_enabled": False,
    "always_face_tracker_enabled": False,
    "always_face_tracker_hud_enabled": False,
    "shape_xy_tracker_port": 5000,
    "tracker_cam_index": 0,
    "skm_keep_map_shapes": True,
    "skm_mirror_axis": "X",
    "skm_mirror_center_x": 0.0,
    "skm_mirror_center_y": 0.0,
    "skm_mirror_center_z": 0.0,
    "skm_mirror_epsilon": 0.001,
    "driverhelper_mode": "LOC",
    "driverhelper_min": 0.0,
    "driverhelper_max": 1.0,
    "driverhelper_power": 1.0,
    "axis_hud_x": 50,
    "axis_hud_y": 120,
    "axis_hud_size": 200,
    "shape_axis_presets": [],
    "shape_xy_presets": [],
    "shape_axis_preset_index": -1,
    "shape_xy_preset_index": -1,
    "skm_uv_map_name": "",
    "ui_sections": {},
}

_SKM_BOOL_SETTING_KEYS = {
    "n_panel_state_save_enabled",
    "show_always_on_toggles",
    "always_axis_ui_enabled",
    "axis_point_drag_enabled",
    "shape_xy_allow_drag",
    "always_frame_sync_enabled",
    "always_external_tracker_enabled",
    "always_face_tracker_enabled",
    "always_face_tracker_hud_enabled",
    "skm_keep_map_shapes",
}
_SKM_FLOAT_SETTING_KEYS = {
    "skm_mirror_center_x",
    "skm_mirror_center_y",
    "skm_mirror_center_z",
    "skm_mirror_epsilon",
    "driverhelper_min",
    "driverhelper_max",
    "driverhelper_power",
}
_SKM_INT_SETTING_KEYS = {
    "shape_xy_tracker_port",
    "tracker_cam_index",
    "axis_hud_x",
    "axis_hud_y",
    "axis_hud_size",
    "shape_axis_preset_index",
    "shape_xy_preset_index",
}
_SKM_ENUM_CHOICES = {
    "skm_mirror_axis": {"X", "Y", "Z"},
    "driverhelper_mode": {"LOC", "ROT", "SCALE"},
}

_SKM_LEGACY_SETTING_ALIASES = {
    "always_axis_drag_enabled": "axis_point_drag_enabled",
}


def _blender_config_dir(create: bool = True) -> Path:
    """Return Blender's versioned config directory for this user."""
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': bool(create)}),
                (('CONFIG',), {'create': bool(create)}),
            ):
                try:
                    value = user_resource(*args, **kwargs)
                except TypeError:
                    continue
                except Exception:
                    continue
                if value:
                    path = Path(value)
                    if create:
                        path.mkdir(parents=True, exist_ok=True)
                    return path
    except Exception:
        pass

    try:
        version = f"{int(bpy.app.version[0])}.{int(bpy.app.version[1])}"
    except Exception:
        version = '5.1'

    if os.name == 'nt':
        root = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming'))
        path = root / 'Blender Foundation' / 'Blender' / version / 'config'
    else:
        root = Path(os.environ.get('XDG_CONFIG_HOME') or (Path.home() / '.config'))
        path = root / 'blender' / version / 'config'

    if create:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def _legacy_settings_paths() -> tuple[Path, ...]:
    paths: list[Path] = []

    # Previous config-root and old folder locations. These are migration sources
    # only; the active path is config/Smart_Shapekey_Suite/Smart_Shapekey_Suite.json.
    try:
        config_dir = _blender_config_dir(False)
        for folder in ('', 'Smart Shapekey Suite', 'Smart_Shapekey_Suite'):
            base = config_dir / folder if folder else config_dir
            for filename in (
                'Smart_Shapekey_Suite.json',
                'Smart Shapekey Suite.json',
                'smart_shapekey_suite_settings.json',
                'n_panel_settings.json',
            ):
                paths.append(base / filename)
    except Exception:
        pass

    # Earlier extension-local settings locations.
    for filename in (
        'Smart_Shapekey_Suite.json',
        'Smart Shapekey Suite.json',
        'smart_shapekey_suite_settings.json',
        'n_panel_settings.json',
    ):
        try:
            paths.append(Path(_extension_user_dir('settings', create=False)) / filename)
        except Exception:
            pass
        try:
            legacy_dir = _legacy_extension_user_dir('settings')
            if legacy_dir:
                paths.append(Path(legacy_dir) / filename)
        except Exception:
            pass

    out: list[Path] = []
    seen = set()
    for path in paths:
        try:
            key = str(path)
        except Exception:
            key = ''
        if key and key not in seen:
            out.append(path)
            seen.add(key)
    return tuple(out)


def _settings_json_path() -> str:
    """Return the authoritative path without reading, migrating or rewriting it."""
    settings_dir = _blender_config_dir(True) / _SKM_SETTINGS_DIRNAME
    settings_dir.mkdir(parents=True, exist_ok=True)
    return str(settings_dir / _SKM_SETTINGS_FILE)


def _settings_backup_path() -> str:
    path = Path(_settings_json_path())
    return str(path.with_name(path.name + ".bak"))


def _coerce_persistent_setting(key: str, value: object) -> object:
    """Coerce only values produced by Blender RNA before strict validation."""
    if key in {"shape_axis_presets", "shape_xy_presets", "face_tracker_targets", "tracker_targets"}:
        return value if isinstance(value, list) else list(_SKM_PERSISTENT_DEFAULTS.get(key, []))
    if key in {"shape_axis_object_groups", "shape_xy_groups", "ui_sections"}:
        return value if isinstance(value, dict) else {}
    if key == "skm_uv_map_name":
        return str(value or "")
    if key in _SKM_BOOL_SETTING_KEYS:
        return bool(value)
    if key in _SKM_INT_SETTING_KEYS:
        try:
            ivalue = int(value)
        except Exception:
            ivalue = int(_SKM_PERSISTENT_DEFAULTS.get(key, 0))
        if key == "shape_xy_tracker_port":
            return max(1024, min(65535, ivalue))
        if key == "tracker_cam_index":
            return max(0, ivalue)
        if key == "axis_hud_size":
            return max(80, min(600, ivalue))
        if key in {"axis_hud_x", "axis_hud_y"}:
            return max(-10000, min(10000, ivalue))
        return ivalue
    if key in _SKM_FLOAT_SETTING_KEYS:
        try:
            fvalue = float(value)
        except Exception:
            fvalue = float(_SKM_PERSISTENT_DEFAULTS.get(key, 0.0))
        if key == "skm_mirror_epsilon":
            return max(0.0, fvalue)
        return fvalue
    choices = _SKM_ENUM_CHOICES.get(key)
    if choices:
        text = str(value or _SKM_PERSISTENT_DEFAULTS.get(key, "")).strip().upper()
        return text if text in choices else _SKM_PERSISTENT_DEFAULTS.get(key)
    return value


def _clean_settings_payload(data: dict[str, object] | None) -> dict[str, object]:
    incoming = dict(data or {})
    cleaned: dict[str, object] = {}
    for raw_key, value in incoming.items():
        raw_key = str(raw_key)
        key = _SKM_LEGACY_SETTING_ALIASES.get(raw_key, raw_key)
        if key != raw_key and key in incoming:
            continue
        cleaned[key] = _coerce_persistent_setting(key, value) if key in _SKM_PERSISTENT_DEFAULTS else value
    for key, value in _SKM_PERSISTENT_DEFAULTS.items():
        if key not in cleaned:
            cleaned[key] = value
    return _sss_settings_io.validate_settings(cleaned, _SKM_PERSISTENT_DEFAULTS)


def _read_settings_file(*, force: bool = False) -> dict[str, object]:
    global _SKM_SETTINGS_CACHE
    if _SKM_SETTINGS_CACHE is not None and not bool(force):
        return dict(_SKM_SETTINGS_CACHE)
    snapshot = _sss_settings_io.recover_settings(
        Path(_settings_json_path()),
        _SKM_PERSISTENT_DEFAULTS,
        backup_path=Path(_settings_backup_path()),
        legacy_paths=_legacy_settings_paths(),
        quarantine_main=True,
        state=_sss_settings_io.STATE,
    )
    _SKM_SETTINGS_CACHE = dict(snapshot.settings)
    return dict(_SKM_SETTINGS_CACHE)


def _notify_settings_issue_once(context=None) -> None:
    """Consume one pending persistence fault and show at most one UI notice."""
    message = _sss_settings_io.peek_notification()
    if not message:
        return
    wm = getattr(context, "window_manager", None) if context is not None else getattr(getattr(bpy, "context", None), "window_manager", None)
    popup = getattr(wm, "popup_menu", None) if wm is not None else None
    if not callable(popup):
        return

    def draw(self, _context):
        self.layout.label(text=_t("The settings file was damaged or could not be saved; the last validated settings remain active."), icon='ERROR')

    try:
        popup(draw, title=ADDON_NAME, icon='ERROR')
        _sss_settings_io.acknowledge_notification()
    except Exception:
        # Keep the one-shot notice pending until a valid UI context exists.
        pass



def _notify_runtime_issue_once(code: str, message: str, context=None) -> None:
    """Show one bounded UI notice without mutating validated settings state."""
    key = str(code or "runtime")[:256]
    if key in _SKM_RUNTIME_NOTICE_SHOWN:
        return
    text = str(message or _t('A requested runtime feature could not be started. The saved setting was kept unchanged.'))[:2048]
    _SKM_RUNTIME_NOTICE_PENDING[key] = text
    _SKM_RUNTIME_NOTICE_PENDING.move_to_end(key)
    while len(_SKM_RUNTIME_NOTICE_PENDING) > _SKM_RUNTIME_NOTICE_LIMIT:
        _SKM_RUNTIME_NOTICE_PENDING.popitem(last=False)

    wm = getattr(context, "window_manager", None) if context is not None else getattr(getattr(bpy, "context", None), "window_manager", None)
    popup = getattr(wm, "popup_menu", None) if wm is not None else None
    if not callable(popup):
        return

    def draw(self, _context):
        self.layout.label(text=text, icon='ERROR')

    try:
        popup(draw, title=ADDON_NAME, icon='ERROR')
    except Exception:
        return
    _SKM_RUNTIME_NOTICE_PENDING.pop(key, None)
    _SKM_RUNTIME_NOTICE_SHOWN.add(key)
    # Keep the shown-code set bounded as well; retaining the newest pending
    # codes is more important than preserving process-lifetime history.
    if len(_SKM_RUNTIME_NOTICE_SHOWN) > (_SKM_RUNTIME_NOTICE_LIMIT * 4):
        _SKM_RUNTIME_NOTICE_SHOWN.clear()
        _SKM_RUNTIME_NOTICE_SHOWN.add(key)

def _write_settings_file(data: dict[str, object], *, reason: str = "ordinary",
                         owner_key: object | None = None,
                         owner_enabled: bool | None = None) -> bool:
    """Commit settings atomically; authoritative cache changes only after read-back."""
    global _SKM_SETTINGS_CACHE, _SKM_SETTINGS_PENDING
    if _SKM_REGISTRATION_WRITE_GUARD_DEPTH > 0 or _SKM_RESTORING_SETTINGS:
        return False
    if not _SKM_WRITE_BARRIER.authorize(
        reason, owner_key=owner_key, owner_enabled=owner_enabled,
    ):
        return False
    cleaned = _clean_settings_payload(data)
    main_path = Path(_settings_json_path())
    if not _sss_persistence_policy.write_required(
        path_exists=main_path.is_file(),
        dirty=bool(_sss_settings_io.STATE.dirty),
        pending=isinstance(_SKM_SETTINGS_PENDING, dict),
        current=_read_settings_file(),
        proposed=cleaned,
    ):
        return True
    try:
        snapshot = _sss_settings_io.atomic_write_settings(
            main_path,
            cleaned,
            _SKM_PERSISTENT_DEFAULTS,
            backup_path=Path(_settings_backup_path()),
            state=_sss_settings_io.STATE,
        )
    except Exception:
        _SKM_SETTINGS_PENDING = dict(cleaned) if reason == "ordinary" and _SKM_WRITE_BARRIER.enabled else None
        _notify_settings_issue_once(getattr(bpy, 'context', None))
        return False
    _SKM_SETTINGS_CACHE = dict(snapshot.settings)
    _SKM_SETTINGS_PENDING = None
    return True

def get_persistent_setting(key: str, default: object | None = None) -> object:
    data = _SKM_SETTINGS_PENDING if isinstance(_SKM_SETTINGS_PENDING, dict) else _read_settings_file()
    if default is None:
        default = _SKM_PERSISTENT_DEFAULTS.get(key)
    return data.get(key, default)


def begin_registration_restore() -> dict[str, object]:
    global _SKM_REGISTRATION_WRITE_GUARD_DEPTH
    if _SKM_WRITE_BARRIER.phase == "STOPPED":
        _SKM_WRITE_BARRIER.reset()
    _SKM_WRITE_BARRIER.begin_restore()
    _SKM_REGISTRATION_WRITE_GUARD_DEPTH += 1
    try:
        payload = _read_settings_file(force=True)
    except Exception:
        _SKM_REGISTRATION_WRITE_GUARD_DEPTH = max(0, _SKM_REGISTRATION_WRITE_GUARD_DEPTH - 1)
        _SKM_WRITE_BARRIER.stop()
        raise
    return dict(payload)


def apply_registration_restore(payload: dict[str, object] | None, context=None) -> None:
    global _SKM_SETTINGS_CACHE
    if isinstance(payload, dict):
        _SKM_SETTINGS_CACHE = dict(payload)
    _apply_persistent_settings_now(context or getattr(bpy, 'context', None), resume_features=False)


def end_registration_restore() -> None:
    global _SKM_REGISTRATION_WRITE_GUARD_DEPTH
    if _SKM_WRITE_BARRIER.restore_depth > 0:
        if _RUNTIME_STATE != 'READY':
            raise _sss_persistence_policy.PersistencePolicyError('restore cannot finish before runtime READY')
        owner = _suite_settings(getattr(bpy, 'context', None))
        owner_key = _persistence_owner_key(owner)
        if owner_key is None or not hasattr(owner, 'n_panel_state_save_enabled'):
            raise _sss_persistence_policy.PersistencePolicyError('restore requires the live RNA settings owner')
        enabled = bool(getattr(owner, 'n_panel_state_save_enabled'))
        _SKM_WRITE_BARRIER.finish_restore(owner_key=owner_key, enabled=enabled)
        _SKM_REGISTRATION_WRITE_GUARD_DEPTH = max(0, _SKM_REGISTRATION_WRITE_GUARD_DEPTH - 1)


def _n_panel_state_save_enabled(context=None) -> bool:
    try:
        settings = _suite_settings(context)
        if settings is not None and hasattr(settings, 'n_panel_state_save_enabled'):
            return bool(getattr(settings, 'n_panel_state_save_enabled', True))
    except Exception:
        pass
    try:
        return bool(_read_settings_file().get('n_panel_state_save_enabled', True))
    except Exception:
        return True


def save_persistent_setting(key: str, value: object) -> None:
    if _SKM_RESTORING_SETTINGS or key not in _SKM_PERSISTENT_DEFAULTS:
        return
    if not _SKM_WRITE_BARRIER.enabled:
        return
    data = _read_settings_file()
    value = _coerce_persistent_setting(key, value)
    if data.get(key) == value:
        return
    data[key] = value
    if _n_panel_state_save_enabled():
        _write_settings_file(data)


def _suite_settings(context=None):
    try:
        wm = getattr(context, "window_manager", None) if context is not None else getattr(getattr(bpy, "context", None), "window_manager", None)
        settings = getattr(wm, "skm_suite_settings", None) if wm is not None else None
        return settings
    except Exception:
        return None


def _persistence_owner_key(owner) -> object | None:
    if owner is None:
        return None
    pointer = getattr(owner, 'as_pointer', None)
    if callable(pointer):
        try:
            value = int(pointer())
            if value:
                return ('RNA', value)
        except Exception:
            pass
    return ('PY', id(owner))


def _live_persistence_owner_state(candidate, context=None) -> tuple[object, bool] | None:
    """Authenticate the callback against the currently-owned RNA instance."""
    live_owner = _suite_settings(context)
    live_key = _persistence_owner_key(live_owner)
    if live_key is None or live_key != _persistence_owner_key(candidate):
        return None
    try:
        enabled = bool(getattr(live_owner, 'n_panel_state_save_enabled'))
    except Exception:
        return None
    return live_key, enabled


def _set_property_safely(owner, prop: str, value: object) -> bool:
    if owner is None or not hasattr(owner, prop):
        return False
    try:
        if getattr(owner, prop) == value:
            return True
    except Exception:
        pass
    try:
        setattr(owner, prop, value)
        return True
    except Exception:
        return False




_SHAPE_AXIS_GROUP_PROPS = (
    'name', 'joy_x', 'joy_y', 'shape_xy_index',
    'tracker_x_mode', 'tracker_x_pt_a', 'tracker_x_pt_b', 'tracker_x_rmin', 'tracker_x_rmax',
    'tracker_x_omin', 'tracker_x_omax', 'tracker_x_sens', 'tracker_x_exp', 'tracker_x_lerp_en', 'tracker_x_lerp_fac',
    'tracker_y_mode', 'tracker_y_pt_a', 'tracker_y_pt_b', 'tracker_y_rmin', 'tracker_y_rmax',
    'tracker_y_omin', 'tracker_y_omax', 'tracker_y_sens', 'tracker_y_exp', 'tracker_y_lerp_en', 'tracker_y_lerp_fac',
)
_SHAPE_AXIS_ITEM_PROPS = ('shape_name', 'target_x', 'target_y', 'radius', 'blend_mode')
_PRESET_STATE_PROPS = ('obj_name', 'group_name', 'joy_x', 'joy_y')


def _plain_prop_value(owner, prop: str):
    try:
        value = getattr(owner, prop)
    except Exception:
        return None
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float):
        return float(value)
    if value is None:
        return None
    return str(value)


def _collect_axis_hud_state(data: dict[str, object]) -> None:
    try:
        from .axis_control.core import state as axis_state
        hud = getattr(axis_state, 'HUD_STATE', {})
        data['axis_hud_x'] = _coerce_persistent_setting('axis_hud_x', hud.get('x', 50))
        data['axis_hud_y'] = _coerce_persistent_setting('axis_hud_y', hud.get('y', 120))
        data['axis_hud_size'] = _coerce_persistent_setting('axis_hud_size', hud.get('size', 200))
    except Exception:
        pass


def _apply_axis_hud_state(data: dict[str, object]) -> None:
    try:
        from .axis_control.core import state as axis_state
        hud = getattr(axis_state, 'HUD_STATE', {})
        hud['x'] = int(data.get('axis_hud_x', 50))
        hud['y'] = int(data.get('axis_hud_y', 120))
        hud['size'] = int(data.get('axis_hud_size', 200))
    except Exception:
        pass


def _collect_ui_section_state(data: dict[str, object], context=None) -> None:
    states = data.get('ui_sections')
    if not isinstance(states, dict):
        states = {}
    else:
        states = dict(states)
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is not None:
            prefix = '_smart_shapekey_ui_section_'
            for key in tuple(wm.keys()):
                try:
                    if str(key).startswith(prefix):
                        states[str(key)[len(prefix):]] = bool(wm[key])
                except Exception:
                    continue
    except Exception:
        pass
    data['ui_sections'] = states


def _apply_ui_section_state(data: dict[str, object], context=None) -> None:
    states = data.get('ui_sections')
    if not isinstance(states, dict):
        return
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is None:
            return
        prefix = '_smart_shapekey_ui_section_'
        for key, value in states.items():
            safe = re.sub(r'[^A-Za-z0-9_.:-]+', '_', str(key or '').strip()) or 'section'
            wm[prefix + safe] = bool(value)
    except Exception:
        pass


def get_ui_section_state(section_key: object, default: bool = False) -> bool:
    try:
        states = _read_settings_file().get('ui_sections', {})
        if isinstance(states, dict):
            key = re.sub(r'[^A-Za-z0-9_.:-]+', '_', str(section_key or '').strip()) or 'section'
            if key in states:
                return bool(states[key])
    except Exception:
        pass
    return bool(default)


def save_ui_section_state(section_key: object, value: bool) -> None:
    if _SKM_RESTORING_SETTINGS or not _SKM_WRITE_BARRIER.enabled:
        return
    key = re.sub(r'[^A-Za-z0-9_.:-]+', '_', str(section_key or '').strip()) or 'section'
    data = _read_settings_file()
    states = data.get('ui_sections', {})
    if not isinstance(states, dict):
        states = {}
    else:
        states = dict(states)
    if states.get(key) == bool(value):
        return
    states[key] = bool(value)
    data['ui_sections'] = states
    if _n_panel_state_save_enabled():
        _write_settings_file(data)


def _serialize_shape_axis_objects(scene) -> dict[str, object]:
    out: dict[str, object] = {}
    if scene is None:
        return out
    for obj in tuple(getattr(scene, 'objects', ()) or ()):  # type: ignore[union-attr]
        try:
            groups = getattr(obj, 'shape_xy_groups', None)
            if groups is None or len(groups) == 0:
                continue
            payload = {
                'index': int(getattr(obj, 'shape_xy_group_index', -1)),
                'groups': [],
            }
            for group in groups:
                group_payload = {prop: _plain_prop_value(group, prop) for prop in _SHAPE_AXIS_GROUP_PROPS if hasattr(group, prop)}
                items = []
                for item in tuple(getattr(group, 'shape_xy_list', ()) or ()):  # type: ignore[union-attr]
                    items.append({prop: _plain_prop_value(item, prop) for prop in _SHAPE_AXIS_ITEM_PROPS if hasattr(item, prop)})
                group_payload['items'] = items
                payload['groups'].append(group_payload)
            out[str(obj.name)] = payload
        except Exception:
            continue
    return out


def _scene_object_by_name(scene, name: object):
    text = str(name or '')
    if scene is None or not text:
        return None
    try:
        return scene.objects.get(text)
    except Exception:
        pass
    try:
        obj = bpy.data.objects.get(text)
        if obj is not None and obj.name in scene.objects:
            return obj
    except Exception:
        pass
    return None


def _restore_shape_axis_objects(scene, payload) -> None:
    if scene is None or not isinstance(payload, dict):
        return
    # The external payload is keyed by object name.  Resolve those names
    # directly instead of scanning every object whenever a file is opened.
    for object_name, obj_payload in tuple(payload.items()):
        if not isinstance(obj_payload, dict):
            continue
        obj = _scene_object_by_name(scene, object_name)
        if obj is None:
            continue
        groups_data = obj_payload.get('groups')
        if not isinstance(groups_data, list):
            continue
        groups = getattr(obj, 'shape_xy_groups', None)
        if groups is None:
            continue
        try:
            if len(groups) > 0:
                continue
            for group_data in groups_data:
                if not isinstance(group_data, dict):
                    continue
                group = groups.add()
                for prop in _SHAPE_AXIS_GROUP_PROPS:
                    if prop == 'shape_xy_index':
                        continue
                    if prop in group_data and hasattr(group, prop):
                        _set_property_safely(group, prop, group_data.get(prop))
                for item_data in tuple(group_data.get('items') or ()):
                    if not isinstance(item_data, dict):
                        continue
                    item = group.shape_xy_list.add()
                    for prop in _SHAPE_AXIS_ITEM_PROPS:
                        if prop in item_data and hasattr(item, prop):
                            _set_property_safely(item, prop, item_data.get(prop))
                if hasattr(group, 'shape_xy_index'):
                    count = len(getattr(group, 'shape_xy_list', ()) or ())
                    idx = int(group_data.get('shape_xy_index', -1) or -1)
                    group.shape_xy_index = min(max(idx, -1), count - 1) if count else -1
            idx = int(obj_payload.get('index', -1) or -1)
            obj.shape_xy_group_index = min(max(idx, -1), len(groups) - 1) if len(groups) else -1
        except Exception:
            continue


def _serialize_shape_axis_presets(scene) -> list[dict[str, object]]:
    presets = getattr(scene, 'shape_xy_presets', None) if scene is not None else None
    out: list[dict[str, object]] = []
    if presets is None:
        return out
    for preset in presets:
        try:
            states = []
            for state in tuple(getattr(preset, 'states', ()) or ()):  # type: ignore[union-attr]
                states.append({prop: _plain_prop_value(state, prop) for prop in _PRESET_STATE_PROPS if hasattr(state, prop)})
            out.append({'name': str(getattr(preset, 'name', '')), 'states': states})
        except Exception:
            continue
    return out


def _restore_shape_axis_presets(scene, payload, index_value) -> None:
    presets = getattr(scene, 'shape_xy_presets', None) if scene is not None else None
    if presets is None or not isinstance(payload, list):
        return
    try:
        if len(presets) == 0:
            for preset_data in payload:
                if not isinstance(preset_data, dict):
                    continue
                source_states = tuple(preset_data.get('states') or ())
                verified_states = []
                for state_data in source_states:
                    if not isinstance(state_data, dict):
                        continue
                    obj = _scene_object_by_name(scene, state_data.get('obj_name'))
                    group_name = str(state_data.get('group_name') or '')
                    groups = getattr(obj, 'shape_xy_groups', None) if obj is not None else None
                    if obj is None or groups is None or not group_name:
                        continue
                    if not any(str(getattr(group, 'name', '') or '') == group_name for group in groups):
                        continue
                    verified_states.append(state_data)
                if source_states and not verified_states:
                    continue
                preset = presets.add()
                if 'name' in preset_data:
                    preset.name = str(preset_data.get('name') or '')
                for state_data in verified_states:
                    state = preset.states.add()
                    for prop in _PRESET_STATE_PROPS:
                        if prop in state_data and hasattr(state, prop):
                            _set_property_safely(state, prop, state_data.get(prop))
        if hasattr(scene, 'shape_xy_preset_index'):
            idx = int(index_value if index_value is not None else -1)
            if idx == -1 or 0 <= idx < len(presets):
                scene.shape_xy_preset_index = idx
    except Exception:
        pass


def _serialize_face_tracker_targets(scene) -> list[dict[str, object]]:
    targets = getattr(scene, 'tracker_targets', None) if scene is not None else None
    out: list[dict[str, object]] = []
    if targets is None:
        return out
    for target in targets:
        try:
            obj = getattr(target, 'obj', None)
            out.append({
                'obj_name': str(getattr(obj, 'name', '') or ''),
                'group_name': str(getattr(target, 'group_name', '') or ''),
            })
        except Exception:
            continue
    return out


def _restore_face_tracker_targets(scene, payload, index_value) -> None:
    targets = getattr(scene, 'tracker_targets', None) if scene is not None else None
    if targets is None or not isinstance(payload, list):
        return
    try:
        if len(targets) == 0:
            for target_data in payload:
                if not isinstance(target_data, dict):
                    continue
                target = targets.add()
                obj_name = str(target_data.get('obj_name') or '')
                if obj_name:
                    obj = bpy.data.objects.get(obj_name)
                    if obj is not None:
                        target.obj = obj
                target.group_name = str(target_data.get('group_name') or '')
        if hasattr(scene, 'tracker_target_index'):
            idx = int(index_value if index_value is not None else -1)
            scene.tracker_target_index = idx
    except Exception:
        pass

def _load_settings_into_window_manager(context=None) -> None:
    global _SKM_RESTORING_SETTINGS
    settings = _suite_settings(context)
    if settings is None:
        return
    data = _read_settings_file(force=True)
    _SKM_RESTORING_SETTINGS = True
    try:
        for key in (
            "n_panel_state_save_enabled",
            "show_always_on_toggles",
            "always_axis_ui_enabled",
            "always_frame_sync_enabled",
            "always_external_tracker_enabled",
            "always_face_tracker_enabled",
            "always_face_tracker_hud_enabled",
        ):
            if hasattr(settings, key):
                _set_property_safely(settings, key, data.get(key, _SKM_PERSISTENT_DEFAULTS.get(key)))
        _apply_ui_section_state(data, context)
    finally:
        _SKM_RESTORING_SETTINGS = False


def _apply_persistent_scene_settings(scene=None) -> None:
    """Apply N-panel scene-level settings from the external config JSON."""
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return
    data = _read_settings_file()
    global _SKM_RESTORING_SETTINGS
    _SKM_RESTORING_SETTINGS = True
    try:
        scene_map = {
            'shape_xy_allow_drag': data.get('axis_point_drag_enabled', False),
            'shape_xy_enable_frame_sync': data.get('always_frame_sync_enabled', False),
            'shape_xy_tracker_port': data.get('shape_xy_tracker_port', 5000),
            'tracker_cam_index': data.get('tracker_cam_index', 0),
            'tracker_show_hud': data.get('always_face_tracker_hud_enabled', False),
        }
        for prop, value in scene_map.items():
            if hasattr(scene, prop):
                _set_property_safely(scene, prop, value)

        _restore_shape_axis_presets(
            scene,
            data.get('shape_axis_presets', data.get('shape_xy_presets', [])),
            data.get('shape_axis_preset_index', data.get('shape_xy_preset_index', -1)),
        )
    finally:
        _SKM_RESTORING_SETTINGS = False

    _apply_axis_hud_state(data)



def _persistent_object_targets(context, data: dict[str, object]) -> list[object]:
    """Resolve only objects that currently need external N-panel defaults."""
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    targets: list[object] = []
    seen: set[int] = set()

    def add(obj) -> None:
        if obj is None:
            return
        try:
            pointer = int(obj.as_pointer())
        except Exception:
            pointer = id(obj)
        if pointer in seen:
            return
        seen.add(pointer)
        targets.append(obj)

    active = None
    try:
        active = getattr(ctx, 'active_object', None)
        add(active)
    except Exception:
        pass
    # N-panel object settings belong to the active editing target.  A saved
    # scene can contain thousands of selected objects; applying the same panel
    # defaults to all of them would reintroduce a scene-size load cost.  Only
    # fall back to the first selected object when Blender exposes no active one.
    if active is None:
        try:
            for selected in tuple(getattr(ctx, 'selected_objects', ()) or ()):
                add(selected)
                break
        except Exception:
            pass

    return targets


def _apply_persistent_object_settings(context=None) -> None:
    """Apply object settings lazily to the active or explicitly named targets.

    Object RNA defaults already use the external JSON at registration time.
    Existing .blend overrides are refreshed when an object becomes active;
    saved Shape Axis groups are restored immediately by their stored names.
    """
    data = _read_settings_file()
    ctx = context or getattr(bpy, 'context', None)
    objects = _persistent_object_targets(ctx, data)

    global _SKM_RESTORING_SETTINGS
    _SKM_RESTORING_SETTINGS = True
    try:
        for obj in objects:
            try:
                if getattr(obj, 'type', None) != 'MESH':
                    continue
                for prop in (
                    'skm_keep_map_shapes',
                    'skm_mirror_axis',
                    'skm_mirror_center_x',
                    'skm_mirror_center_y',
                    'skm_mirror_center_z',
                    'skm_mirror_epsilon',
                ):
                    if hasattr(obj, prop):
                        _set_property_safely(obj, prop, data.get(prop, _SKM_PERSISTENT_DEFAULTS.get(prop)))

                uv_name = str(data.get('skm_uv_map_name') or '')
                if uv_name and hasattr(obj, 'skm_uv_map_name'):
                    uv_layers = getattr(getattr(obj, 'data', None), 'uv_layers', None)
                    if uv_layers is not None and uv_name in uv_layers:
                        _set_property_safely(obj, 'skm_uv_map_name', uv_name)
            except Exception:
                pass
    finally:
        _SKM_RESTORING_SETTINGS = False



def _apply_persistent_driver_helper_settings(scene=None) -> None:
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    props = getattr(scene, 'driver_helper_props', None) if scene is not None else None
    if props is None:
        return
    data = _read_settings_file()
    global _SKM_RESTORING_SETTINGS
    _SKM_RESTORING_SETTINGS = True
    try:
        _set_property_safely(props, 'driverhelper_mode', data.get('driverhelper_mode', 'LOC'))
        _set_property_safely(props, 'driverhelper_min', float(data.get('driverhelper_min', 0.0)))
        _set_property_safely(props, 'driverhelper_max', float(data.get('driverhelper_max', 1.0)))
        _set_property_safely(props, 'driverhelper_power', float(data.get('driverhelper_power', 1.0)))
    finally:
        _SKM_RESTORING_SETTINGS = False



def _save_scene_setting_from_prop(prop_name: str, value: object) -> None:
    mapping = {
        "shape_xy_allow_drag": "axis_point_drag_enabled",
        "shape_xy_enable_frame_sync": "always_frame_sync_enabled",
        "shape_xy_tracker_port": "shape_xy_tracker_port",
        "tracker_cam_index": "tracker_cam_index",
        "tracker_show_hud": "always_face_tracker_hud_enabled",
        "tracker_target_index": "face_tracker_target_index",
    }
    key = mapping.get(prop_name)
    if key:
        save_persistent_setting(key, value)
    if prop_name in _SKM_PERSISTENT_DEFAULTS:
        save_persistent_setting(prop_name, value)


def save_scene_runtime_setting(prop_name: str, value: object) -> None:
    _save_scene_setting_from_prop(prop_name, value)
    settings = _suite_settings()
    if settings is not None:
        key = {
            "shape_xy_allow_drag": "axis_point_drag_enabled",
            "shape_xy_enable_frame_sync": "always_frame_sync_enabled",
            "tracker_show_hud": "always_face_tracker_hud_enabled",
        }.get(prop_name)
        if key and hasattr(settings, key):
            global _SKM_RESTORING_SETTINGS
            _SKM_RESTORING_SETTINGS = True
            try:
                _set_property_safely(settings, key, bool(value))
            finally:
                _SKM_RESTORING_SETTINGS = False


def _save_current_panel_settings(context=None, *, write_reason: str = "ordinary",
                                 write_owner_key: object | None = None,
                                 write_owner_enabled: bool | None = None) -> bool:
    if write_reason == "ordinary" and not _SKM_WRITE_BARRIER.enabled:
        return False
    data = _read_settings_file()
    ctx = context if context is not None else getattr(bpy, 'context', None)

    settings = _suite_settings(ctx)
    if settings is not None:
        for key in (
            "n_panel_state_save_enabled",
            "show_always_on_toggles",
            "always_axis_ui_enabled",
            "always_frame_sync_enabled",
            "always_external_tracker_enabled",
            "always_face_tracker_enabled",
            "always_face_tracker_hud_enabled",
        ):
            if hasattr(settings, key):
                data[key] = _coerce_persistent_setting(key, getattr(settings, key))

    _collect_ui_section_state(data, ctx)

    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    if scene is not None:
        if hasattr(scene, 'shape_xy_allow_drag'):
            data['axis_point_drag_enabled'] = bool(getattr(scene, 'shape_xy_allow_drag', False))
            data['shape_xy_allow_drag'] = data['axis_point_drag_enabled']
        if hasattr(scene, 'shape_xy_enable_frame_sync'):
            data['always_frame_sync_enabled'] = bool(getattr(scene, 'shape_xy_enable_frame_sync', data.get('always_frame_sync_enabled', False)))
        if hasattr(scene, 'shape_xy_tracker_port'):
            data['shape_xy_tracker_port'] = _coerce_persistent_setting('shape_xy_tracker_port', getattr(scene, 'shape_xy_tracker_port', 5000))
        if hasattr(scene, 'tracker_cam_index'):
            data['tracker_cam_index'] = _coerce_persistent_setting('tracker_cam_index', getattr(scene, 'tracker_cam_index', 0))
        if hasattr(scene, 'tracker_show_hud'):
            data['always_face_tracker_hud_enabled'] = bool(getattr(scene, 'tracker_show_hud', data.get('always_face_tracker_hud_enabled', False)))

        data['shape_axis_presets'] = _serialize_shape_axis_presets(scene)
        data['shape_xy_presets'] = data['shape_axis_presets']
        data['shape_axis_preset_index'] = _coerce_persistent_setting(
            'shape_axis_preset_index', getattr(scene, 'shape_xy_preset_index', -1),
        )
        data['shape_xy_preset_index'] = data['shape_axis_preset_index']

        # Shape Axis groups, tracker targets, maps, Basis, channels, drivers and
        # geometry remain .blend data and are never reconstructed from config.
        driver_props = getattr(scene, 'driver_helper_props', None)
        if driver_props is not None:
            for key, prop in (
                ('driverhelper_mode', 'driverhelper_mode'),
                ('driverhelper_min', 'driverhelper_min'),
                ('driverhelper_max', 'driverhelper_max'),
                ('driverhelper_power', 'driverhelper_power'),
            ):
                if hasattr(driver_props, prop):
                    data[key] = _coerce_persistent_setting(key, getattr(driver_props, prop))

    obj = getattr(ctx, 'active_object', None) if ctx is not None else None
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        for key, prop in (
            ('skm_keep_map_shapes', 'skm_keep_map_shapes'),
            ('skm_mirror_axis', 'skm_mirror_axis'),
            ('skm_mirror_center_x', 'skm_mirror_center_x'),
            ('skm_mirror_center_y', 'skm_mirror_center_y'),
            ('skm_mirror_center_z', 'skm_mirror_center_z'),
            ('skm_mirror_epsilon', 'skm_mirror_epsilon'),
            ('skm_uv_map_name', 'skm_uv_map_name'),
        ):
            if hasattr(obj, prop):
                data[key] = _coerce_persistent_setting(key, getattr(obj, prop))

    _collect_axis_hud_state(data)
    return bool(_write_settings_file(
        data,
        reason=write_reason,
        owner_key=write_owner_key,
        owner_enabled=write_owner_enabled,
    ))



def extension_user_dir(*parts: str, create: bool = True) -> str:
    return _extension_user_dir(*parts, create=create)


def save_current_panel_settings(context=None, force: bool = False) -> bool:
    del force
    if _SKM_RESTORING_SETTINGS or not _SKM_WRITE_BARRIER.enabled:
        return False
    ctx = context if context is not None else getattr(bpy, 'context', None)
    if not _n_panel_state_save_enabled(ctx):
        return False
    return bool(_save_current_panel_settings(ctx))


def _tag_view3d_redraw(context=None) -> None:
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):  # type: ignore[union-attr]
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):  # type: ignore[union-attr]
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------
class ForceObjectMode:
    """Temporarily activate one object in Object Mode and restore context exactly."""
    def __init__(self, obj, context=None):
        self.obj = obj
        self.context = context or getattr(bpy, 'context', None)
        self.original_mode = 'OBJECT'
        self.original_active = None
        self.original_selected = ()

    def __enter__(self):
        ctx = self.context
        view_layer = getattr(ctx, 'view_layer', None) if ctx is not None else None
        self.original_active = getattr(getattr(view_layer, 'objects', None), 'active', None)
        try:
            self.original_selected = tuple(getattr(ctx, 'selected_objects', ()) or ())
        except Exception:
            self.original_selected = ()
        self.original_mode = str(getattr(self.original_active, 'mode', 'OBJECT') or 'OBJECT')
        try:
            for candidate in tuple(getattr(view_layer, 'objects', ()) or ()):
                if hasattr(candidate, 'select_set'):
                    candidate.select_set(candidate is self.obj)
            if view_layer is not None:
                view_layer.objects.active = self.obj
            if self.obj is not None and str(getattr(self.obj, 'mode', 'OBJECT')) != 'OBJECT':
                with ctx.temp_override(object=self.obj, active_object=self.obj, selected_objects=[self.obj], selected_editable_objects=[self.obj]):
                    bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            # Enter must not leave a partially changed selection if mode switch fails.
            self._restore_context()
            raise
        return self

    def _restore_context(self):
        ctx = self.context
        view_layer = getattr(ctx, 'view_layer', None) if ctx is not None else None
        try:
            for candidate in tuple(getattr(view_layer, 'objects', ()) or ()):
                if hasattr(candidate, 'select_set'):
                    candidate.select_set(candidate in self.original_selected)
        except Exception:
            pass
        try:
            if view_layer is not None:
                view_layer.objects.active = self.original_active
        except Exception:
            pass
        if self.original_active is not None and self.original_mode not in {'', 'OBJECT'}:
            try:
                with ctx.temp_override(
                    object=self.original_active,
                    active_object=self.original_active,
                    selected_objects=list(self.original_selected),
                    selected_editable_objects=list(self.original_selected),
                ):
                    bpy.ops.object.mode_set(mode=self.original_mode)
            except Exception:
                pass

    def __exit__(self, exc_type, exc, tb):
        self._restore_context()
        return False


_REF_COLLECTION_NAMESPACE_KEY = "SMART_SHAPEKEY_SUITE_REF_COLLECTION_V1420"
_REF_COLLECTION_SCHEMA = "smart_shapekey_suite.ref_collection.v1"


def _owned_ref_collection(col) -> bool:
    if col is None:
        return False
    try:
        return bool(
            col.get(_sss_ownership.PROP_SUITE) == _sss_ownership.SUITE_ID
            and col.get(_sss_ownership.PROP_SCHEMA) == _REF_COLLECTION_SCHEMA
            and col.get(_sss_ownership.PROP_TEMPORARY) is True
            and col.get(_sss_ownership.PROP_FILE_GENERATION) == _sss_ownership.current_file_generation()
            and col.get(_sss_ownership.PROP_SESSION_GENERATION) == _sss_ownership.current_session_generation()
            and isinstance(col.get(_sss_ownership.PROP_OWNER_UUID), str)
            and bool(col.get(_sss_ownership.PROP_OWNER_UUID))
        )
    except Exception:
        return False


def _adopt_persistent_ref_collection():
    """Adopt only a collection carrying the complete Suite ownership schema."""
    namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', {})
    matches = []
    for candidate in tuple(getattr(bpy.data, 'collections', ()) or ()):
        try:
            if (
                candidate.get(_sss_ownership.PROP_SUITE) == _sss_ownership.SUITE_ID
                and candidate.get(_sss_ownership.PROP_SCHEMA) == _REF_COLLECTION_SCHEMA
                and candidate.get(_sss_ownership.PROP_TEMPORARY) is True
                and isinstance(candidate.get(_sss_ownership.PROP_OWNER_UUID), str)
                and bool(candidate.get(_sss_ownership.PROP_OWNER_UUID))
            ):
                matches.append(candidate)
        except Exception:
            continue
    # Ambiguous persisted owners are not adopted. A later explicit operation can
    # create a fresh exact-owned collection without touching either candidate.
    if len(matches) != 1:
        namespace.pop(_REF_COLLECTION_NAMESPACE_KEY, None)
        return None
    col = matches[0]
    col[_sss_ownership.PROP_FILE_GENERATION] = _sss_ownership.current_file_generation()
    col[_sss_ownership.PROP_SESSION_GENERATION] = _sss_ownership.current_session_generation()
    namespace[_REF_COLLECTION_NAMESPACE_KEY] = col
    return col


def _ensure_ref_collection():
    """Return a Suite-owned collection without adopting a foreign same-name one."""
    namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', {})
    col = namespace.get(_REF_COLLECTION_NAMESPACE_KEY)
    try:
        if col is not None and bpy.data.collections.get(str(col.name)) is col and _owned_ref_collection(col):
            return col
    except Exception:
        col = None
    # Operation-bound bounded lookup. It never deletes or mutates a foreign collection.
    for candidate in tuple(getattr(bpy.data, 'collections', ()) or ()):
        if _owned_ref_collection(candidate):
            col = candidate
            break
    if col is None:
        col = bpy.data.collections.new(REF_COLLECTION_NAME)
        col[_sss_ownership.PROP_SUITE] = _sss_ownership.SUITE_ID
        col[_sss_ownership.PROP_OWNER_UUID] = uuid.uuid4().hex
        col[_sss_ownership.PROP_FILE_GENERATION] = _sss_ownership.current_file_generation()
        col[_sss_ownership.PROP_SESSION_GENERATION] = _sss_ownership.current_session_generation()
        col[_sss_ownership.PROP_SCHEMA] = _REF_COLLECTION_SCHEMA
        col[_sss_ownership.PROP_TEMPORARY] = True
        bpy.context.scene.collection.children.link(col)
    col.hide_viewport = True
    col.hide_render = True
    namespace[_REF_COLLECTION_NAMESPACE_KEY] = col
    return col


def _plan_source_identity(obj: bpy.types.Object) -> dict[str, object]:
    mesh = getattr(obj, 'data', None)
    if obj is None or mesh is None:
        raise RuntimeError(_t("Active object must be a mesh."))
    old_obj_uuid = _sss_ownership.existing_identity(obj)
    old_mesh_uuid = _sss_ownership.existing_identity(mesh)
    object_uuid = old_obj_uuid or uuid.uuid4().hex
    mesh_uuid = old_mesh_uuid or uuid.uuid4().hex
    identity = _sss_ownership.OwnershipIdentity(
        owner_uuid=object_uuid,
        source_object_uuid=object_uuid,
        source_mesh_uuid=mesh_uuid,
        file_generation=_sss_ownership.current_file_generation(),
        session_generation=_sss_ownership.current_session_generation(),
    )
    return {
        'obj': obj,
        'mesh': mesh,
        'old_obj_uuid': old_obj_uuid,
        'old_mesh_uuid': old_mesh_uuid,
        'identity': identity,
        'applied': False,
    }


def _apply_source_identity_plan(plan: dict[str, object]) -> None:
    obj = plan['obj']
    mesh = plan['mesh']
    identity = plan['identity']
    if not plan['old_obj_uuid']:
        obj[_sss_ownership.PROP_ID_UUID] = identity.source_object_uuid
    if not plan['old_mesh_uuid']:
        mesh[_sss_ownership.PROP_ID_UUID] = identity.source_mesh_uuid
    plan['applied'] = True


def _rollback_source_identity_plan(plan: dict[str, object]) -> None:
    if not plan.get('applied'):
        return
    obj = plan['obj']
    mesh = plan['mesh']
    identity = plan['identity']
    if not plan['old_obj_uuid']:
        try:
            if obj.get(_sss_ownership.PROP_ID_UUID) == identity.source_object_uuid:
                del obj[_sss_ownership.PROP_ID_UUID]
        except Exception:
            pass
    if not plan['old_mesh_uuid']:
        try:
            if mesh.get(_sss_ownership.PROP_ID_UUID) == identity.source_mesh_uuid:
                del mesh[_sss_ownership.PROP_ID_UUID]
        except Exception:
            pass
    plan['applied'] = False


def _snapshot_map_rows(obj) -> list[dict[str, object]]:
    return [
        {
            'name': str(getattr(item, 'name', '') or ''),
            'prev_name': str(getattr(item, 'prev_name', '') or ''),
            'chn_id': int(getattr(item, 'chn_id', 0)),
            'selected': bool(getattr(item, 'selected', False)),
            'locked': bool(getattr(item, 'locked', False)),
        }
        for item in tuple(getattr(obj, 'skm_maps', ()) or ())
    ]


def _replace_map_rows(obj, rows: list[dict[str, object]], index: int) -> None:
    previous_suppress = bool(getattr(obj, 'skm__suppress_apply', False))
    obj.skm__suppress_apply = True
    try:
        obj.skm_maps.clear()
        for row in rows:
            item = obj.skm_maps.add()
            item.chn_id = int(row['chn_id'])
            item.prev_name = str(row['prev_name'])
            item.name = str(row['name'])
            item.selected = bool(row['selected'])
            item.locked = bool(row['locked'])
        obj.skm_index = int(index)
    finally:
        obj.skm__suppress_apply = previous_suppress


def _snapshot_source_map_state(obj) -> dict[str, object]:
    return {
        'rows': _snapshot_map_rows(obj),
        'index': int(getattr(obj, 'skm_index', -1)),
        'ref_present': OBJ_PROP_REF in obj,
        'ref_name': str(obj.get(OBJ_PROP_REF, '') or ''),
        'uv_present': OBJ_PROP_UV in obj,
        'uv_name': str(obj.get(OBJ_PROP_UV, '') or ''),
        'enum_uv': str(getattr(obj, 'skm_uv_map_name', '') or ''),
    }


def _restore_source_map_state(obj, state: dict[str, object]) -> None:
    _replace_map_rows(obj, list(state['rows']), int(state['index']))
    try:
        if state['ref_present']:
            obj[OBJ_PROP_REF] = state['ref_name']
        elif OBJ_PROP_REF in obj:
            del obj[OBJ_PROP_REF]
    except Exception:
        pass
    try:
        if state['uv_present']:
            obj[OBJ_PROP_UV] = state['uv_name']
        elif OBJ_PROP_UV in obj:
            del obj[OBJ_PROP_UV]
    except Exception:
        pass
    try:
        obj.skm_uv_map_name = state['enum_uv']
    except Exception:
        pass


def _copy_mesh_data_block(source_mesh: bpy.types.Mesh, name: str | None = None) -> bpy.types.Mesh:
    new_mesh = source_mesh.copy()
    if name:
        try:
            new_mesh.name = str(name)
        except Exception:
            pass
    return new_mesh


def _stage_owned_reference_mesh(obj, identity) -> bpy.types.Mesh:
    ref = _find_existing_ref_for_object(obj)
    if ref is None or not _sss_ownership.is_owned_temporary(ref, identity):
        raise RuntimeError(_t("Please run Set Base first."))
    mesh = getattr(ref, 'data', None)
    if mesh is None or not _sss_ownership.is_owned_temporary(mesh, identity) or not _sss_ownership.same_owned_graph(ref, mesh):
        raise RuntimeError(_t("Please run Set Base first."))
    staged = _copy_mesh_data_block(mesh, f".__SKM_STAGE_MESH_{uuid.uuid4().hex}")
    _sss_ownership.mark_temporary(staged, identity)
    return staged


def _discard_staged_mesh(mesh) -> None:
    if mesh is None:
        return
    try:
        if getattr(mesh, 'users', 0) == 0:
            bpy.data.meshes.remove(mesh)
    except Exception:
        pass


def _commit_reference_state(
    obj,
    staged_mesh,
    rows: list[dict[str, object]],
    uv_name: str,
    index: int,
    identity_plan: dict[str, object],
):
    """Commit one staged reference state or restore the source byte-for-byte."""
    state = _snapshot_source_map_state(obj)
    identity = identity_plan['identity']
    existing_ref = _find_existing_ref_for_object(obj)
    old_mesh = getattr(existing_ref, 'data', None) if existing_ref is not None else None
    old_mesh_owned = bool(
        existing_ref is not None
        and old_mesh is not None
        and _sss_ownership.is_owned_temporary(existing_ref, identity)
        and _sss_ownership.is_owned_temporary(old_mesh, identity)
        and _sss_ownership.same_owned_graph(existing_ref, old_mesh)
    )
    ref = existing_ref
    created_ref = False
    linked_ref = False
    committed = False
    try:
        _map_checkpoint('before_identity_commit')
        _apply_source_identity_plan(identity_plan)
        _map_checkpoint('after_identity_commit')
        if ref is None:
            ref = bpy.data.objects.new(f"{obj.name}_SKM_REF", staged_mesh)
            created_ref = True
            _sss_ownership.mark_temporary(ref, identity)
            _sss_ownership.mark_temporary(staged_mesh, identity)
            ref[REF_TAG_PROP] = obj.name
            col = _ensure_ref_collection()
            col.objects.link(ref)
            linked_ref = True
            _map_checkpoint('after_reference_link')
        else:
            ref.data = staged_mesh
            _sss_ownership.mark_temporary(ref, identity)
            _sss_ownership.mark_temporary(staged_mesh, identity)
            ref[REF_TAG_PROP] = obj.name
            _map_checkpoint('after_reference_mesh_swap')
        for attr, value in (('hide_viewport', True), ('hide_render', True), ('hide_select', True)):
            try:
                setattr(ref, attr, value)
            except Exception:
                pass
        try:
            ref.hide_set(True)
        except Exception:
            pass
        obj[OBJ_PROP_REF] = ref.name
        obj[OBJ_PROP_UV] = str(uv_name)
        try:
            obj.skm_uv_map_name = str(uv_name)
        except Exception:
            pass
        _replace_map_rows(obj, rows, index)
        _map_checkpoint('after_map_rows_replace')
        # Read-back verifies the source pointer and row manifest before old data
        # becomes eligible for deletion.
        if str(obj.get(OBJ_PROP_REF, '') or '') != str(ref.name):
            raise RuntimeError("reference object commit read-back failed")
        if getattr(ref, 'data', None) is not staged_mesh:
            raise RuntimeError("reference mesh commit read-back failed")
        if _snapshot_map_rows(obj) != rows or int(getattr(obj, 'skm_index', -1)) != int(index):
            raise RuntimeError("map row commit read-back failed")
        _map_checkpoint('after_commit_readback')
        committed = True
    except Exception:
        try:
            _restore_source_map_state(obj, state)
        finally:
            if ref is not None and not created_ref and old_mesh is not None:
                try:
                    ref.data = old_mesh
                except Exception:
                    pass
            if created_ref and ref is not None:
                try:
                    bpy.data.objects.remove(ref, do_unlink=True)
                except Exception:
                    pass
            _rollback_source_identity_plan(identity_plan)
            _discard_staged_mesh(staged_mesh)
        raise
    if committed and old_mesh_owned and old_mesh is not staged_mesh and getattr(old_mesh, 'users', 0) == 0:
        try:
            bpy.data.meshes.remove(old_mesh)
        except Exception:
            pass
    return ref


def _get_or_create_ref_object(obj: bpy.types.Object):
    """Compatibility helper used only by explicit operations.

    New map transactions use staged commit helpers above. This path never adopts
    foreign same-name data and creates source UUIDs only for an explicit action.
    """
    identity = _sss_ownership.source_identity(obj)
    ref = _find_existing_ref_for_object(obj)
    if ref is not None:
        _normalize_ref_object(ref, obj)
        return ref
    col = _ensure_ref_collection()
    ref_mesh = bpy.data.meshes.new(f"{obj.name}_SKM_REF_MESH")
    ref = bpy.data.objects.new(f"{obj.name}_SKM_REF", ref_mesh)
    _sss_ownership.mark_temporary(ref_mesh, identity)
    _sss_ownership.mark_temporary(ref, identity)
    ref[REF_TAG_PROP] = obj.name
    col.objects.link(ref)
    _normalize_ref_object(ref, obj)
    obj[OBJ_PROP_REF] = ref.name
    return ref


def _replace_object_mesh_from_source(target_obj: bpy.types.Object, source_mesh: bpy.types.Mesh, name: str | None = None) -> bpy.types.Mesh:
    """Compatibility atomic swap; never removes an unowned prior mesh."""
    old_mesh = getattr(target_obj, 'data', None)
    new_mesh = _copy_mesh_data_block(source_mesh, name or getattr(old_mesh, 'name', None) or f"{target_obj.name}_MESH")
    try:
        target_obj.data = new_mesh
        if getattr(target_obj, 'data', None) is not new_mesh:
            raise RuntimeError("mesh swap read-back failed")
    except Exception:
        try:
            if old_mesh is not None:
                target_obj.data = old_mesh
        finally:
            _discard_staged_mesh(new_mesh)
        raise
    return new_mesh

def _remove_ref_object(obj: bpy.types.Object) -> bool:
    """Remove only the exact temporary graph owned by *obj*."""
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    identity = _sss_ownership.source_identity(obj, create=False)
    stored = str(obj.get(OBJ_PROP_REF, '') or '')
    ref = bpy.data.objects.get(stored) if stored else None
    if ref is None or not _sss_ownership.is_owned_temporary(ref, identity):
        return False
    mesh = getattr(ref, 'data', None)
    mesh_owned = bool(mesh is not None and _sss_ownership.is_owned_temporary(mesh, identity) and _sss_ownership.same_owned_graph(ref, mesh))
    try:
        bpy.data.objects.remove(ref, do_unlink=True)
    except Exception:
        return False
    if mesh_owned and getattr(mesh, 'users', 0) == 0:
        try:
            bpy.data.meshes.remove(mesh)
        except Exception:
            pass
    try:
        if str(obj.get(OBJ_PROP_REF, '') or '') == stored:
            del obj[OBJ_PROP_REF]
    except Exception:
        pass
    return True

def _normalize_ref_object(ref: bpy.types.Object, owner: bpy.types.Object | None = None) -> None:
    if ref is None:
        return
    if owner is not None:
        identity = _sss_ownership.source_identity(owner, create=False)
        if not _sss_ownership.is_owned_temporary(ref, identity):
            return
        try:
            ref[REF_TAG_PROP] = owner.name
            owner[OBJ_PROP_REF] = ref.name
        except Exception:
            pass
    for attr, value in (('hide_viewport', True), ('hide_render', True), ('hide_select', True)):
        try:
            setattr(ref, attr, value)
        except Exception:
            pass
    try:
        ref.hide_set(True)
    except Exception:
        pass


def _find_existing_ref_for_object(obj: bpy.types.Object):
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    identity = _sss_ownership.source_identity(obj, create=False)
    stored = str(obj.get(OBJ_PROP_REF, '') or '')
    if stored:
        ref = bpy.data.objects.get(stored)
        if ref is not None and _sss_ownership.is_owned_temporary(ref, identity):
            mesh = getattr(ref, 'data', None)
            if mesh is not None and _sss_ownership.is_owned_temporary(mesh, identity) and _sss_ownership.same_owned_graph(ref, mesh):
                return ref
    # Legacy name/custom-property candidates are intentionally not adopted.
    # They remain untouched until the user explicitly recreates this object's map.
    return None


def _adopt_loaded_reference_graphs(context=None) -> int:
    """Refresh generations only for exact persisted source/ref graphs in this Scene."""
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    adopted = 0
    for source in tuple(getattr(scene, 'objects', ()) or ()):
        if source is None or getattr(source, 'type', None) != 'MESH':
            continue
        stored = str(source.get(OBJ_PROP_REF, '') or '')
        ref = bpy.data.objects.get(stored) if stored else None
        mesh = getattr(ref, 'data', None) if ref is not None else None
        if ref is None or mesh is None:
            continue
        identity = _sss_ownership.adopt_persistent_graph(ref, mesh, source)
        if identity is None:
            continue
        _normalize_ref_object(ref, source)
        adopted += 1
    return adopted


def _cleanup_stale_smart_shapekey_proxy_data(context=None, *, aggressive: bool = False) -> dict[str, int]:
    """Safety-first cleanup limited to explicitly selected source ownership graphs.

    The function never scans/deletes Object/Image/NodeGroup/Mesh datablocks by
    prefix, zero-user state or generic custom properties.  Scene-wide callers
    iterate source mesh objects, but each removal still requires the complete
    owner UUID/source UUID/file generation/session generation/schema match.
    """
    result = {'objects': 0, 'meshes': 0, 'props': 0, 'collections': 0}
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return result
    if aggressive:
        candidates = tuple(getattr(getattr(ctx, 'scene', None), 'objects', ()) or ())
    else:
        active = _context_mesh_object(ctx)
        candidates = (active,) if active is not None else ()
    for source in candidates:
        if source is None or getattr(source, 'type', None) != 'MESH':
            continue
        stored = str(source.get(OBJ_PROP_REF, '') or '')
        ref = bpy.data.objects.get(stored) if stored else None
        if ref is None:
            continue
        identity = _sss_ownership.source_identity(source, create=False)
        if not _sss_ownership.is_owned_temporary(ref, identity):
            continue
        # A valid, still-referenced graph is normalized, never deleted merely
        # because a map list is empty or a generated name changed.
        _normalize_ref_object(ref, source)
    return result

def _get_mapping_uv_name(obj: bpy.types.Object) -> str:
    mesh = obj.data
    if not mesh or not getattr(mesh, "uv_layers", None) or len(mesh.uv_layers) == 0:
        return ""
    stored = obj.get(OBJ_PROP_UV, "")
    if stored and mesh.uv_layers.get(stored):
        return stored
    # default: active
    if mesh.uv_layers.active:
        return mesh.uv_layers.active.name
    return mesh.uv_layers[-1].name


def _ensure_storage_layers(ref_mesh: bpy.types.Mesh, chn_id: int):
    a = _uv_store_name_a(chn_id)
    b = _uv_store_name_b(chn_id)
    if ref_mesh.uv_layers.get(a) is None:
        ref_mesh.uv_layers.new(name=a)  # appended => highest index
    if ref_mesh.uv_layers.get(b) is None:
        ref_mesh.uv_layers.new(name=b)
    return a, b


def _encode_positions_to_uv_layers(mesh: bpy.types.Mesh, uv_a_name: str, uv_b_name: str, loop_pos):
    """Store (x,y) to uv_a and (z,0) to uv_b, per loop. Does not touch user's UV unwrap layers."""
    uv_a = mesh.uv_layers.get(uv_a_name) or mesh.uv_layers.new(name=uv_a_name)
    uv_b = mesh.uv_layers.get(uv_b_name) or mesh.uv_layers.new(name=uv_b_name)

    prev_active = getattr(mesh.uv_layers, 'active', None)
    prev_active_render = getattr(mesh.uv_layers, 'active_render', None)

    n = len(mesh.loops)
    flat_a = array('f', [0.0]) * (n * 2)
    flat_b = array('f', [0.0]) * (n * 2)
    for i, p in enumerate(loop_pos):
        flat_a[i*2 + 0] = float(p[0])
        flat_a[i*2 + 1] = float(p[1])
        flat_b[i*2 + 0] = float(p[2])
        flat_b[i*2 + 1] = 0.0
    uv_a.data.foreach_set("uv", flat_a)
    uv_b.data.foreach_set("uv", flat_b)

    try:
        if prev_active is not None:
            mesh.uv_layers.active = prev_active
    except Exception:
        pass
    try:
        if prev_active_render is not None and hasattr(mesh.uv_layers, 'active_render'):
            setattr(mesh.uv_layers, 'active_render', prev_active_render)
    except Exception:
        pass


def _decode_positions_from_uv_layers(mesh: bpy.types.Mesh, uv_a_name: str, uv_b_name: str):
    uv_a = mesh.uv_layers.get(uv_a_name)
    uv_b = mesh.uv_layers.get(uv_b_name)
    if uv_a is None or uv_b is None:
        return None
    n = len(mesh.loops)
    flat_a = array('f', [0.0]) * (n * 2)
    flat_b = array('f', [0.0]) * (n * 2)
    uv_a.data.foreach_get("uv", flat_a)
    uv_b.data.foreach_get("uv", flat_b)
    out = [None] * n
    for i in range(n):
        out[i] = (flat_a[i*2], flat_a[i*2+1], flat_b[i*2])
    return out


def _mm_delta_attribute_name(chn_id: int) -> str:
    return f"{MM_DELTA_PREFIX}{int(chn_id):02d}"


def _mm_read_vectors(mesh: bpy.types.Mesh, name: str):
    attr = getattr(getattr(mesh, 'attributes', None), 'get', lambda _name: None)(name)
    if attr is None or str(getattr(attr, 'data_type', '')) != 'FLOAT_VECTOR' or str(getattr(attr, 'domain', '')) != 'POINT':
        return None
    if len(attr.data) != len(mesh.vertices):
        return None
    flat = array('f', [0.0]) * (len(mesh.vertices) * 3)
    attr.data.foreach_get('vector', flat)
    return flat


def _mm_write_vectors(mesh: bpy.types.Mesh, name: str, values) -> None:
    flat = array('f', values)
    expected = len(mesh.vertices) * 3
    if len(flat) != expected:
        raise RuntimeError(_t("Map vertex count validation failed."))
    attrs = mesh.attributes
    attr = attrs.get(name)
    if attr is not None and (str(getattr(attr, 'data_type', '')) != 'FLOAT_VECTOR' or str(getattr(attr, 'domain', '')) != 'POINT'):
        raise RuntimeError(_t("Owned map attribute has an incompatible type: {name}").format(name=name))
    if attr is None:
        attr = attrs.new(name=name, type='FLOAT_VECTOR', domain='POINT')
    if len(attr.data) != len(mesh.vertices):
        raise RuntimeError(_t("Map vertex count validation failed."))
    attr.data.foreach_set('vector', flat)


def _mm_legacy_vertex_positions(ref_mesh: bpy.types.Mesh, chn_id: int):
    """Read the absolute UV payload without modifying it."""
    loop_values = _decode_positions_from_uv_layers(
        ref_mesh, _uv_store_name_a(chn_id), _uv_store_name_b(chn_id)
    )
    if loop_values is None:
        return None
    count = len(ref_mesh.vertices)
    sums = [[0.0, 0.0, 0.0, 0] for _ in range(count)]
    for loop, value in zip(ref_mesh.loops, loop_values):
        index = int(loop.vertex_index)
        if 0 <= index < count:
            row = sums[index]
            row[0] += float(value[0]); row[1] += float(value[1]); row[2] += float(value[2]); row[3] += 1
    flat = array('f', [0.0]) * (count * 3)
    for index, row in enumerate(sums):
        if row[3] <= 0:
            # A loose vertex has no loop to carry a position: it stays where it is.
            flat[index * 3:index * 3 + 3] = array('f', ref_mesh.vertices[index].co)
            continue
        scale = 1.0 / row[3]
        flat[index * 3] = row[0] * scale
        flat[index * 3 + 1] = row[1] * scale
        flat[index * 3 + 2] = row[2] * scale
    return flat


def _mm_basis_vectors(ref_mesh: bpy.types.Mesh):
    basis = _mm_read_vectors(ref_mesh, MM_BASIS_ATTRIBUTE)
    return basis if basis is not None else _mm_legacy_vertex_positions(ref_mesh, BASE_ID)


def _mm_delta_vectors(ref_mesh: bpy.types.Mesh, chn_id: int, basis):
    delta = _mm_read_vectors(ref_mesh, _mm_delta_attribute_name(chn_id))
    if delta is not None:
        return delta
    legacy = _mm_legacy_vertex_positions(ref_mesh, chn_id)
    if legacy is None or basis is None or len(legacy) != len(basis):
        return None
    return array('f', (float(legacy[i]) - float(basis[i]) for i in range(len(basis))))


def _mm_object_coordinates(obj: bpy.types.Object):
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        raise RuntimeError(_t("Active object must be a mesh."))
    if str(getattr(obj, 'mode', 'OBJECT')) == 'EDIT':
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.verts.index_update()
        flat = array('f', [0.0]) * (len(bm.verts) * 3)
        for vert in bm.verts:
            offset = int(vert.index) * 3
            flat[offset:offset + 3] = array('f', vert.co)
        return flat
    flat = array('f', [0.0]) * (len(mesh.vertices) * 3)
    mesh.vertices.foreach_get('co', flat)
    return flat


def _mm_apply_live_coordinates(obj: bpy.types.Object, positions) -> None:
    mesh = obj.data
    if str(getattr(obj, 'mode', 'OBJECT')) == 'EDIT':
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.verts.index_update()
        if len(positions) != len(bm.verts) * 3:
            raise RuntimeError(_t("Map vertex count validation failed."))
        for vert in bm.verts:
            offset = int(vert.index) * 3
            vert.co = positions[offset:offset + 3]
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    else:
        if len(positions) != len(mesh.vertices) * 3:
            raise RuntimeError(_t("Map vertex count validation failed."))
        mesh.vertices.foreach_set('co', positions)
        mesh.update()


def _mm_sync_shape_key_preview(obj: bpy.types.Object, ref_mesh=None, channel=None) -> None:
    """Show the active map on a mesh with Shape Keys.

    Such a mesh displays the mix of its keys, not its vertices. The stored shape
    of the map goes into one extra relative key, so Basis and the values of the
    user's keys stay as they are. The stored data is the source because leaving
    Edit Mode resets the vertices to the Shape Key Basis.
    """
    mesh = obj.data
    shape_keys = getattr(mesh, 'shape_keys', None)
    if shape_keys is None or not shape_keys.use_relative or str(getattr(obj, 'mode', 'OBJECT')) == 'EDIT':
        return
    key_blocks = shape_keys.key_blocks
    if ref_mesh is None:
        ref_mesh = _get_ref_mesh(obj)
    if channel is None:
        channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
    target = _mm_positions(ref_mesh, channel) if ref_mesh is not None else None
    reference = shape_keys.reference_key
    base = array('f', [0.0]) * (len(mesh.vertices) * 3)
    reference.data.foreach_get('co', base)
    differs = target is not None and len(target) == len(base) and any(
        abs(float(target[i]) - float(base[i])) > 1.0e-6 for i in range(len(base))
    )
    preview = key_blocks.get(MM_PREVIEW_KEY_NAME)
    active_index = int(obj.active_shape_key_index)
    if not differs:
        if preview is not None:
            obj.shape_key_remove(preview)
            obj.active_shape_key_index = min(active_index, max(0, len(key_blocks) - 1))
            if target is None:
                # No map remains, so nothing may keep the vertices away from Basis.
                mesh.vertices.foreach_set('co', base)
            mesh.update()
        return
    if preview is None:
        preview = obj.shape_key_add(name=MM_PREVIEW_KEY_NAME, from_mix=False)
    preview.data.foreach_set('co', target)
    preview.relative_key = reference
    preview.mute = False
    preview.value = 1.0
    obj.active_shape_key_index = active_index
    mesh.update()


def _mm_basis_is_own_shape(obj: bpy.types.Object) -> bool:
    # The preview key on the Basis row means Set Base stored a shape other than the Shape Key Basis.
    shape_keys = getattr(obj.data, 'shape_keys', None)
    return shape_keys is not None and shape_keys.key_blocks.get(MM_PREVIEW_KEY_NAME) is not None


def _mm_refresh_map_vertices(obj: bpy.types.Object) -> None:
    """Put the active map back into the vertices of a mesh with Shape Keys.

    Operations below read the vertices as the shape of the active map, but
    leaving Edit Mode has reset them to the Shape Key Basis.
    """
    if getattr(obj.data, 'shape_keys', None) is None:
        return
    channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
    ref_mesh = _get_ref_mesh(obj)
    if ref_mesh is None or (channel == BASE_ID and not _mm_basis_is_own_shape(obj)):
        return
    positions = _mm_positions(ref_mesh, channel)
    if len(positions) == len(obj.data.vertices) * 3:
        obj.data.vertices.foreach_set('co', positions)
        obj.data.update()


def _mm_read_live_edit(obj: bpy.types.Object):
    """Read an unsaved Edit Mode change on a mesh with Shape Keys.

    Leaving Edit Mode writes the change into the active Shape Key (and through
    Basis into the other keys), where a map can no longer see it. The key data
    still holds the shape from before the edit while Edit Mode is open.
    """
    shape_keys = getattr(obj.data, 'shape_keys', None)
    if shape_keys is None or str(getattr(obj, 'mode', 'OBJECT')) != 'EDIT':
        return None
    keys = {}
    for block in shape_keys.key_blocks:
        values = array('f', [0.0]) * (len(block.data) * 3)
        block.data.foreach_get('co', values)
        keys[block.name] = values
    active = getattr(obj, 'active_shape_key', None) or shape_keys.reference_key
    return {'live': _mm_object_coordinates(obj), 'keys': keys, 'shown': keys[active.name]}


def _mm_apply_live_edit(obj: bpy.types.Object, edit) -> None:
    """Put the active map moved by the edit into the vertices, ready to be stored."""
    ref_mesh = _get_ref_mesh(obj)
    if ref_mesh is not None:
        _mm_validate_topology(obj, ref_mesh)
    live, shown = edit['live'], edit['shown']
    if len(live) != len(shown) or len(live) != len(obj.data.vertices) * 3:
        return
    # Use the pre-edit stored channel, including Basis. After mode_set the mesh
    # may already contain the live Basis edit; reading it would add that edit
    # twice. With no stored map, the original active key is the reference.
    positions = (_mm_positions(ref_mesh, int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID)))
                 if ref_mesh is not None else edit['shown'])
    moved = array('f', (float(positions[i]) + float(live[i]) - float(shown[i]) for i in range(len(live))))
    obj.data.vertices.foreach_set('co', moved)
    obj.data.update()


def _mm_restore_edit_keys(obj: bpy.types.Object, edit) -> None:
    """After the map took the edit, undo what leaving Edit Mode wrote into the keys."""
    key_blocks = obj.data.shape_keys.key_blocks
    for name, values in edit['keys'].items():
        block = key_blocks.get(name)
        if block is not None and len(block.data) * 3 == len(values):
            block.data.foreach_set('co', values)


def _mm_connectivity_signature(mesh: bpy.types.Mesh):
    """Return an order-insensitive face/edge signature over stable vertex ids."""
    edges = tuple(sorted(tuple(sorted((int(edge.vertices[0]), int(edge.vertices[1])))) for edge in mesh.edges))

    def canonical_face(values):
        vertices = tuple(int(value) for value in values)
        if not vertices:
            return ()
        rotations = []
        for sequence in (vertices, tuple(reversed(vertices))):
            rotations.extend(sequence[index:] + sequence[:index] for index in range(len(sequence)))
        return min(rotations)

    polygons = tuple(sorted(canonical_face(polygon.vertices) for polygon in mesh.polygons))
    return (len(mesh.vertices), len(mesh.loops), edges, polygons)


def _mm_edit_connectivity_signature(mesh: bpy.types.Mesh):
    bm = bmesh.from_edit_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.verts.index_update()
    edges = tuple(sorted(tuple(sorted((int(vert.index) for vert in edge.verts))) for edge in bm.edges))

    def canonical_face(values):
        vertices = tuple(int(value) for value in values)
        if not vertices:
            return ()
        rotations = []
        for sequence in (vertices, tuple(reversed(vertices))):
            rotations.extend(sequence[index:] + sequence[:index] for index in range(len(sequence)))
        return min(rotations)

    polygons = tuple(sorted(canonical_face(vert.index for vert in face.verts) for face in bm.faces))
    return (len(bm.verts), sum(len(face.loops) for face in bm.faces), edges, polygons)


def _mm_validate_topology(obj: bpy.types.Object, ref_mesh: bpy.types.Mesh) -> None:
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        raise RuntimeError(_t("The mesh topology does not match the stored Basis."))
    mode = str(getattr(obj, 'mode', 'OBJECT'))
    if mode not in {'OBJECT', 'EDIT'}:
        raise RuntimeError(_t("The mesh topology does not match the stored Basis."))
    signature = _mm_edit_connectivity_signature(mesh) if mode == 'EDIT' else _mm_connectivity_signature(mesh)
    if (
        signature != _mm_connectivity_signature(ref_mesh)
    ):
        raise RuntimeError(_t("The mesh topology does not match the stored Basis."))


def _mm_capture_basis(obj: bpy.types.Object, ref_mesh: bpy.types.Mesh) -> None:
    _mm_validate_topology(obj, ref_mesh)
    _mm_write_vectors(ref_mesh, MM_BASIS_ATTRIBUTE, _mm_object_coordinates(obj))


def _mm_capture_delta(obj: bpy.types.Object, ref_mesh: bpy.types.Mesh, chn_id: int) -> None:
    _mm_validate_topology(obj, ref_mesh)
    if int(chn_id) == BASE_ID:
        return
    basis = _mm_basis_vectors(ref_mesh)
    current = _mm_object_coordinates(obj)
    if basis is None or len(basis) != len(current):
        raise RuntimeError(_t("Please run Set Base first."))
    delta = array('f', (float(current[i]) - float(basis[i]) for i in range(len(current))))
    _mm_write_vectors(ref_mesh, _mm_delta_attribute_name(chn_id), delta)


def _mm_commit_active_channel(obj: bpy.types.Object, ref_mesh: bpy.types.Mesh, channels) -> None:
    """Store the shape held by the vertices into the active map.

    MorphMapper's New stores the shape into the current channel before the new
    one, so an edit made on the current map stays in both. Call it after the
    vertices hold the active map (refresh or live edit).
    """
    channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
    if channel == BASE_ID:
        _mm_capture_basis(obj, ref_mesh)
    elif channel in channels:
        _mm_capture_delta(obj, ref_mesh, channel)


def _mm_selected_polygon_vertices(obj: bpy.types.Object) -> tuple[int, ...]:
    """Return unique geometry vertices belonging to selected polygons."""
    if obj.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.index_update()
        return tuple(sorted({vert.index for face in bm.faces if face.select for vert in face.verts}))
    return tuple(sorted({int(index) for polygon in obj.data.polygons if polygon.select for index in polygon.vertices}))


def _mm_capture_selected_delta(obj, ref_mesh, chn_id: int, vertex_indices, *, clear: bool = False):
    _mm_validate_topology(obj, ref_mesh)
    basis = _mm_basis_vectors(ref_mesh)
    current = _mm_object_coordinates(obj)
    delta = _mm_delta_vectors(ref_mesh, chn_id, basis)
    if basis is None or delta is None or len(delta) != len(current):
        raise RuntimeError(_t("The selected map has no valid stored geometry."))
    updated_mesh = array('f', current)
    for vertex_index in vertex_indices:
        offset = int(vertex_index) * 3
        for axis in range(3):
            delta[offset + axis] = 0.0 if clear else float(current[offset + axis]) - float(basis[offset + axis])
            if clear:
                updated_mesh[offset + axis] = float(basis[offset + axis])
    _mm_write_vectors(ref_mesh, _mm_delta_attribute_name(chn_id), delta)
    return updated_mesh


def _mm_positions(ref_mesh: bpy.types.Mesh, chn_id: int):
    basis = _mm_basis_vectors(ref_mesh)
    if basis is None:
        raise RuntimeError(_t("Please run Set Base first."))
    if int(chn_id) == BASE_ID:
        return array('f', basis)
    delta = _mm_delta_vectors(ref_mesh, chn_id, basis)
    if delta is None or len(delta) != len(basis):
        raise RuntimeError(_t("The selected map has no valid stored geometry."))
    return array('f', (float(basis[i]) + float(delta[i]) for i in range(len(basis))))


# -----------------------------------------------------------------------------
# UV Triangle Sampler (2D UV -> 3D position) + acceleration
# -----------------------------------------------------------------------------
def _closest_point_triangle_2d(p, a, b, c):
    p = Vector(p); a = Vector(a); b = Vector(b); c = Vector(c)
    ab = b - a
    ac = c - a
    ap = p - a

    d1 = ab.dot(ap)
    d2 = ac.dot(ap)
    if d1 <= 0.0 and d2 <= 0.0:
        return a, (1.0, 0.0, 0.0)

    bp = p - b
    d3 = ab.dot(bp)
    d4 = ac.dot(bp)
    if d3 >= 0.0 and d4 <= d3:
        return b, (0.0, 1.0, 0.0)

    vc = d1 * d4 - d3 * d2
    if vc <= 0.0 and d1 >= 0.0 and d3 <= 0.0:
        v = d1 / (d1 - d3) if (d1 - d3) != 0.0 else 0.0
        q = a + v * ab
        return q, (1.0 - v, v, 0.0)

    cp = p - c
    d5 = ab.dot(cp)
    d6 = ac.dot(cp)
    if d6 >= 0.0 and d5 <= d6:
        return c, (0.0, 0.0, 1.0)

    vb = d5 * d2 - d1 * d6
    if vb <= 0.0 and d2 >= 0.0 and d6 <= 0.0:
        w = d2 / (d2 - d6) if (d2 - d6) != 0.0 else 0.0
        q = a + w * ac
        return q, (1.0 - w, 0.0, w)

    va = d3 * d6 - d5 * d4
    if va <= 0.0 and (d4 - d3) >= 0.0 and (d5 - d6) >= 0.0:
        w = (d4 - d3) / ((d4 - d3) + (d5 - d6)) if ((d4 - d3) + (d5 - d6)) != 0.0 else 0.0
        q = b + w * (c - b)
        return q, (0.0, 1.0 - w, w)

    denom = (va + vb + vc)
    if denom == 0.0:
        return a, (1.0, 0.0, 0.0)
    v = vb / denom
    w = vc / denom
    u = 1.0 - v - w
    q = a + ab * v + ac * w
    return q, (u, v, w)


class UVSampler:
    __slots__ = ("tri_uv", "tri_p0", "tri_p1", "tri_p2", "grid", "bb_min", "bb_max", "res")

    def __init__(self, tri_uv, tri_p0, tri_p1, tri_p2, bb_min, bb_max, grid, res=64):
        self.tri_uv = tri_uv
        self.tri_p0 = tri_p0
        self.tri_p1 = tri_p1
        self.tri_p2 = tri_p2
        self.bb_min = bb_min
        self.bb_max = bb_max
        self.grid = grid
        self.res = res

    def _cell(self, uv):
        u, v = uv
        min_u, min_v = self.bb_min
        max_u, max_v = self.bb_max
        du = (max_u - min_u) if (max_u - min_u) != 0.0 else 1.0
        dv = (max_v - min_v) if (max_v - min_v) != 0.0 else 1.0
        x = int(floor((u - min_u) / du * self.res))
        y = int(floor((v - min_v) / dv * self.res))
        if x < 0: x = 0
        if y < 0: y = 0
        if x >= self.res: x = self.res - 1
        if y >= self.res: y = self.res - 1
        return x, y

    def sample(self, uv, *, lookup_uv=None):
        # A nudged UV selects the source face; the original UV evaluates it.
        lookup = uv if lookup_uv is None else lookup_uv
        x, y = self._cell(lookup)
        cand = self.grid[y * self.res + x]
        if not cand:
            cand = []
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    xx = x + dx
                    yy = y + dy
                    if 0 <= xx < self.res and 0 <= yy < self.res:
                        cand.extend(self.grid[yy * self.res + xx])
        if not cand:
            # Sparse UV islands or UVs outside occupied grid cells can otherwise
            # be missed entirely. Fall back to all triangles so sampling remains
            # correct even when the acceleration grid has no local candidates.
            cand = range(len(self.tri_uv))

        best_d2 = 1e30
        best_pos = None
        p = Vector(lookup)
        for ti in cand:
            a, b, c = self.tri_uv[ti]
            q, (u, v, w) = _closest_point_triangle_2d(p, a, b, c)
            d2 = (p - q).length_squared
            if d2 < best_d2:
                p0 = Vector(self.tri_p0[ti])
                p1 = Vector(self.tri_p1[ti])
                p2 = Vector(self.tri_p2[ti])
                if lookup_uv is not None:
                    _q, (u, v, w) = _closest_point_triangle_2d(Vector(uv), a, b, c)
                best_pos = (p0 * u + p1 * v + p2 * w)
                best_d2 = d2
                if best_d2 == 0.0:
                    break
        return best_pos


def _build_sampler_from_mesh(mesh: bpy.types.Mesh, uv_name: str, positions_loop=None) -> UVSampler:
    if mesh is None or len(mesh.loops) == 0:
        raise RuntimeError(_t("No UV layers found."))
    uv_layer = mesh.uv_layers.get(uv_name)
    if uv_layer is None:
        raise RuntimeError(_t("No UV layers found."))

    mesh.calc_loop_triangles()
    tris = mesh.loop_triangles
    if len(tris) == 0:
        raise RuntimeError(_t("Mesh has no faces."))

    nloops = len(mesh.loops)
    uv_flat = array('f', [0.0]) * (nloops * 2)
    uv_layer.data.foreach_get("uv", uv_flat)

    if positions_loop is None:
        co_flat = array('f', [0.0]) * (len(mesh.vertices) * 3)
        mesh.vertices.foreach_get("co", co_flat)

        def loop_pos(li):
            vi = mesh.loops[li].vertex_index
            return (co_flat[vi*3], co_flat[vi*3+1], co_flat[vi*3+2])
    else:
        def loop_pos(li):
            return positions_loop[li]

    def loop_uv(li):
        return (uv_flat[li*2], uv_flat[li*2+1])

    tri_uv = []
    tri_p0 = []
    tri_p1 = []
    tri_p2 = []
    bb_min = [1e30, 1e30]
    bb_max = [-1e30, -1e30]

    for t in tris:
        li0, li1, li2 = t.loops[0], t.loops[1], t.loops[2]
        a = loop_uv(li0); b = loop_uv(li1); c = loop_uv(li2)
        area = (Vector(b) - Vector(a)).cross(Vector(c) - Vector(a))
        if abs(area) < 1e-20:
            continue

        tri_uv.append((a, b, c))
        tri_p0.append(loop_pos(li0))
        tri_p1.append(loop_pos(li1))
        tri_p2.append(loop_pos(li2))

        for uu, vv in (a, b, c):
            if uu < bb_min[0]: bb_min[0] = uu
            if vv < bb_min[1]: bb_min[1] = vv
            if uu > bb_max[0]: bb_max[0] = uu
            if vv > bb_max[1]: bb_max[1] = vv

    if not tri_uv:
        raise RuntimeError(_t("UV triangles are degenerate."))

    res = 64
    grid = [[] for _ in range(res * res)]
    du = (bb_max[0] - bb_min[0]) if (bb_max[0] - bb_min[0]) != 0.0 else 1.0
    dv = (bb_max[1] - bb_min[1]) if (bb_max[1] - bb_min[1]) != 0.0 else 1.0

    for i, (a, b, c) in enumerate(tri_uv):
        umin = min(a[0], b[0], c[0]); umax = max(a[0], b[0], c[0])
        vmin = min(a[1], b[1], c[1]); vmax = max(a[1], b[1], c[1])
        x0 = int(floor((umin - bb_min[0]) / du * res)); x1 = int(floor((umax - bb_min[0]) / du * res))
        y0 = int(floor((vmin - bb_min[1]) / dv * res)); y1 = int(floor((vmax - bb_min[1]) / dv * res))
        if x0 < 0: x0 = 0
        if y0 < 0: y0 = 0
        if x1 >= res: x1 = res - 1
        if y1 >= res: y1 = res - 1
        for yy in range(y0, y1 + 1):
            for xx in range(x0, x1 + 1):
                grid[yy * res + xx].append(i)

    return UVSampler(tri_uv, tri_p0, tri_p1, tri_p2, (bb_min[0], bb_min[1]), (bb_max[0], bb_max[1]), grid, res=res)


def _vertex_uv_average(mesh: bpy.types.Mesh, uv_name: str):
    uv_layer = mesh.uv_layers.get(uv_name)
    if uv_layer is None:
        return None
    nloops = len(mesh.loops)
    uv_flat = array('f', [0.0]) * (nloops * 2)
    uv_layer.data.foreach_get("uv", uv_flat)

    sums_u = [0.0] * len(mesh.vertices)
    sums_v = [0.0] * len(mesh.vertices)
    counts = [0] * len(mesh.vertices)

    for li, loop in enumerate(mesh.loops):
        vi = loop.vertex_index
        sums_u[vi] += uv_flat[li*2]
        sums_v[vi] += uv_flat[li*2+1]
        counts[vi] += 1

    out = [None] * len(mesh.vertices)
    for i in range(len(mesh.vertices)):
        if counts[i] > 0:
            out[i] = (sums_u[i] / counts[i], sums_v[i] / counts[i])
        else:
            out[i] = (0.0, 0.0)
    return out


def _get_ref_mesh(obj: bpy.types.Object):
    ref = _find_existing_ref_for_object(obj)
    if ref is None or getattr(ref, 'type', None) != 'MESH':
        return None
    identity = _sss_ownership.source_identity(obj, create=False)
    mesh = getattr(ref, 'data', None)
    if mesh is None or not _sss_ownership.is_owned_temporary(mesh, identity):
        return None
    if not _sss_ownership.same_owned_graph(ref, mesh):
        return None
    return mesh


def _next_free_id(obj: bpy.types.Object) -> int:
    used = {it.chn_id for it in obj.skm_maps}
    for i in range(BASE_ID - 1, 0, -1):
        if i not in used:
            return i
    return 1


def _unique_map_name(requested: object, existing_names, *, preserve_raw: bool = False) -> str:
    existing = {str(name or '') for name in (existing_names or set())}
    base = str(requested or '')
    if not preserve_raw:
        base = base.strip()
    base = base[:128]
    if not preserve_raw:
        base = base.strip()
    base = base or DEFAULT_MAP_BASENAME
    if base not in existing:
        return base
    root = base[:124] if preserve_raw else (base[:124].rstrip(' .') or DEFAULT_MAP_BASENAME)
    index = 1
    while True:
        suffix = f".{index:03d}"
        candidate = f"{root[:128 - len(suffix)]}{suffix}"
        if candidate not in existing:
            return candidate
        index += 1


def _next_newmap_name(obj: bpy.types.Object) -> str:
    return _unique_map_name(DEFAULT_MAP_BASENAME, {it.name for it in obj.skm_maps})


def _capture_shape_to_ref_layers(obj: bpy.types.Object, chn_id: int, *, ref_mesh=None, context=None):
    """Capture one exact vertex-index delta into durable POINT vectors."""
    del context
    target_mesh = ref_mesh if ref_mesh is not None else _get_ref_mesh(obj)
    if target_mesh is None:
        raise RuntimeError(_t("Please run Set Base first."))
    _mm_capture_delta(obj, target_mesh, chn_id)

def _compute_positions_for_object(obj: bpy.types.Object, chn_id: int, *, ref_mesh=None):
    ref_mesh = ref_mesh if ref_mesh is not None else _get_ref_mesh(obj)
    if ref_mesh is None:
        raise RuntimeError(_t("Please run Set Base first."))
    _mm_validate_topology(obj, ref_mesh)
    return _mm_positions(ref_mesh, chn_id)


def _apply_map_to_object(obj: bpy.types.Object, chn_id: int):
    pos = _compute_positions_for_object(obj, chn_id)
    mesh = obj.data
    mesh.vertices.foreach_set("co", pos)
    mesh.update()
    _mm_sync_shape_key_preview(obj, channel=chn_id)


# -----------------------------------------------------------------------------
# Property Groups
# -----------------------------------------------------------------------------
_MAP_NAME_UPDATE_GUARD = set()


def _map_item_pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return id(value)


def _map_name_update(self, context):
    obj = getattr(self, "id_data", None)
    if not obj or not isinstance(obj, bpy.types.Object):
        return

    self_key = _map_item_pointer(self)
    if self_key in _MAP_NAME_UPDATE_GUARD:
        return

    _MAP_NAME_UPDATE_GUARD.add(self_key)
    try:
        other_names = {
            str(getattr(it, 'name', '') or '')
            for it in getattr(obj, 'skm_maps', [])
            if _map_item_pointer(it) != self_key
        }

        if self.chn_id == BASE_ID:
            if self.name != BASIS_NAME:
                self.name = BASIS_NAME
            self.prev_name = BASIS_NAME
            return

        raw_name = str(getattr(self, 'name', '') or '')
        if raw_name == '':
            previous = str(getattr(self, 'prev_name', '') or '')
            fallback = previous if previous and previous not in other_names else _unique_map_name(DEFAULT_MAP_BASENAME, other_names)
            if self.name != fallback:
                self.name = fallback
            self.prev_name = fallback
            return

        if raw_name in other_names:
            previous = str(getattr(self, 'prev_name', '') or '')
            fallback = previous if previous and previous not in other_names else _unique_map_name(raw_name, other_names, preserve_raw=True)
            if self.name != fallback:
                self.name = fallback
            self.prev_name = fallback
            return

        self.prev_name = raw_name
    finally:
        _MAP_NAME_UPDATE_GUARD.discard(self_key)


class SKM_MapItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        name=_t("Name"),
        default="",
        description=_t("Map name (must be unique). Click to rename."),
        update=_map_name_update
    )
    prev_name: bpy.props.StringProperty(
        options={'HIDDEN'},
        default="",
        description=_t("Previous internal map name used to restore the value when a duplicate name is rejected."),
    )
    chn_id: bpy.props.IntProperty(
        default=0,
        description=_t("Internal channel ID that links this map entry to its hidden UV storage layers."),
    )
    selected: bpy.props.BoolProperty(
        name=_t("Select"),
        default=False,
        description=_t("If enabled, this map will be included when using Selected export/save.")
    )
    locked: bpy.props.BoolProperty(
        name=_t("Lock"),
        default=False,
        description=_t("Lock the map to prevent deletion.")
    )


class SKM_LoadChoice(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(
        options={'HIDDEN'},
        description=_t("Map name found in the selected external map file."),
    )
    enabled: bpy.props.BoolProperty(
        default=True,
        description=_t("When enabled, this map is imported from the selected external map file."),
    )


# -----------------------------------------------------------------------------
# UI List
# -----------------------------------------------------------------------------
class SKM_UL_MapList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        it = item
        row = layout.row(align=True)
        if bool(getattr(data, 'skm_edit_mode', False)) and int(it.chn_id) != BASE_ID:
            row.prop(it, "selected", text="")
        row.label(text=str(it.name), translate=False, icon='SHAPEKEY_DATA' if int(it.chn_id) != BASE_ID else 'MESH_DATA')
        row.label(text=str(it.chn_id))


def _on_edit_mode_update(obj, context):
    del context
    if bool(obj.skm_edit_mode):
        try:
            _SKM_DEFERRED_APPLY_PENDING.pop(int(obj.as_pointer()), None)
        except Exception:
            pass
        _restore_current_channel_index(obj)
        obj.skm_edit_index = int(obj.skm_index)
    else:
        _restore_current_channel_index(obj)
        for item in obj.skm_maps:
            item.selected = False


def _auto_key_enabled(context) -> bool:
    return bool(getattr(getattr(getattr(context, 'scene', None), 'tool_settings', None), 'use_keyframe_insert_auto', False))


def _restore_current_channel_index(obj) -> None:
    channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
    index = next((i for i, item in enumerate(obj.skm_maps) if int(item.chn_id) == channel), -1)
    if index >= 0 and int(obj.skm_index) != index:
        prior = bool(obj.skm__suppress_apply)
        obj.skm__suppress_apply = True
        try:
            obj.skm_index = index
        finally:
            obj.skm__suppress_apply = prior
        _save_object_setting('skm_index', index)


def _show_auto_key_warning(context) -> None:
    if bool(getattr(bpy.app, 'background', False)):
        return
    window = getattr(context, 'window', None)
    area = getattr(context, 'area', None)
    if window is None or area is None:
        return
    manager = getattr(context, 'window_manager', None)
    if manager is not None and window in tuple(manager.windows) and area in tuple(window.screen.areas) and hasattr(manager, 'popup_menu'):
        manager.popup_menu(
            lambda self, _context: self.layout.label(text=_t("Auto Key is enabled. Turn it off before switching maps.")),
            title=_t("Maps"), icon='ERROR',
        )


def _popup_map_message(context, message: str) -> None:
    # A map switch can end in a timer, where the context has no window or area.
    manager = getattr(context, 'window_manager', None)
    if manager is None or bool(getattr(bpy.app, 'background', False)):
        return
    window = getattr(context, 'window', None) or next(iter(manager.windows), None)
    if window is None:
        return
    try:
        with context.temp_override(window=window):
            manager.popup_menu(
                lambda self, _context: self.layout.label(text=message),
                title=_t("Maps"), icon='ERROR',
            )
    except (RuntimeError, TypeError):
        pass


def _show_map_edit_mode_warning(context) -> None:
    _popup_map_message(context, _t("This mesh has Shape Keys. Switch to Object Mode before switching maps."))


def _show_map_switch_error(context, error: Exception) -> None:
    _popup_map_message(context, _sss_translation.exception_text(error, context))


def _move_selected_map_rows(rows, direction):
    """Move the Edit-mode selection one slot without moving Basis or IDs."""
    ordered = [dict(row) for row in rows]
    if direction not in {'UP', 'DOWN'}:
        raise ValueError('Invalid map move direction')
    indices = range(1, len(ordered)) if direction == 'UP' else range(len(ordered) - 2, 0, -1)
    for index in indices:
        adjacent = index - 1 if direction == 'UP' else index + 1
        if adjacent == 0 or adjacent >= len(ordered):
            continue
        if ordered[index]['selected'] and not ordered[adjacent]['selected']:
            ordered[index], ordered[adjacent] = ordered[adjacent], ordered[index]
    return ordered


# -----------------------------------------------------------------------------
# Index update: selecting a map applies it through one bounded generation timer
# -----------------------------------------------------------------------------
_SKM_DEFERRED_APPLY_PENDING: "OrderedDict[int, tuple[object, int]]" = OrderedDict()
_SKM_DEFERRED_APPLY_MAX = 256
_SKM_DEFERRED_APPLY_TICK_MAX = 8
_SKM_DEFERRED_APPLY_TICK_SECONDS = 0.003
_SKM_DEFERRED_APPLY_STATS = {"scheduled": 0, "coalesced": 0, "dropped": 0, "processed": 0}


def _schedule_deferred_apply(obj, chn_id: int) -> None:
    try:
        key = int(obj.as_pointer())
    except Exception:
        key = id(obj)
    if key in _SKM_DEFERRED_APPLY_PENDING:
        _SKM_DEFERRED_APPLY_STATS["coalesced"] += 1
        _SKM_DEFERRED_APPLY_PENDING.pop(key, None)
    _SKM_DEFERRED_APPLY_PENDING[key] = (obj, int(chn_id))
    _SKM_DEFERRED_APPLY_STATS["scheduled"] += 1
    while len(_SKM_DEFERRED_APPLY_PENDING) > _SKM_DEFERRED_APPLY_MAX:
        _SKM_DEFERRED_APPLY_PENDING.popitem(last=False)
        _SKM_DEFERRED_APPLY_STATS["dropped"] += 1
    lease = _sss_activity.get_lease("map_index_apply")
    if lease is None or lease.state != "ACTIVE":
        lease = _sss_activity.new_lease("map_index_apply", replace=True)
        _sss_activity.add_timer(
            lease,
            _deferred_apply_tick,
            first_interval=0.0,
            persistent=False,
            label="bounded map index apply",
        )


def _on_index_update(self, context):
    try:
        if not hasattr(context, "view_layer"):
            return
        obj = self
        if not obj or obj.type != 'MESH' or getattr(obj, 'skm__suppress_apply', False):
            return
        if bool(getattr(obj, 'skm_edit_mode', False)):
            _restore_current_channel_index(obj)
            return
        idx = int(obj.skm_index)
        if idx < 0 or idx >= len(obj.skm_maps):
            return
        target_channel = int(obj.skm_maps[idx].chn_id)
        current_channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
        if target_channel != current_channel and _auto_key_enabled(context):
            _restore_current_channel_index(obj)
            _show_auto_key_warning(context)
            return
        if target_channel != current_channel and str(getattr(obj, 'mode', 'OBJECT')) == 'EDIT' and getattr(obj.data, 'shape_keys', None) is not None:
            # Edit Mode writes back into the active Shape Key, which would overwrite Basis.
            _restore_current_channel_index(obj)
            _show_map_edit_mode_warning(context)
            return
        _save_object_setting('skm_index', idx)
        if target_channel != current_channel:
            _schedule_deferred_apply(obj, target_channel)
    except Exception as error:
        try:
            _restore_current_channel_index(self)
        except Exception as restore_error:
            print(f"Smart Shapekey map index restore failed: {restore_error}", file=sys.stderr)
        _show_map_switch_error(context, error)


def _on_uv_map_name_update(self, context):
    del context
    try:
        _save_object_setting('skm_uv_map_name', str(getattr(self, 'skm_uv_map_name', '') or ''))
    except Exception:
        pass



def _save_object_setting(prop_name: str, value: object) -> None:
    save_persistent_setting(prop_name, value)


def _on_keep_map_shapes_update(self, context):
    del context
    try:
        _save_object_setting('skm_keep_map_shapes', bool(getattr(self, 'skm_keep_map_shapes', True)))
    except Exception:
        pass


def _on_mirror_axis_update(self, context):
    del context
    try:
        _save_object_setting('skm_mirror_axis', str(getattr(self, 'skm_mirror_axis', 'X') or 'X'))
    except Exception:
        pass


def _on_mirror_center_x_update(self, context):
    del context
    try:
        _save_object_setting('skm_mirror_center_x', float(getattr(self, 'skm_mirror_center_x', 0.0)))
    except Exception:
        pass


def _on_mirror_center_y_update(self, context):
    del context
    try:
        _save_object_setting('skm_mirror_center_y', float(getattr(self, 'skm_mirror_center_y', 0.0)))
    except Exception:
        pass


def _on_mirror_center_z_update(self, context):
    del context
    try:
        _save_object_setting('skm_mirror_center_z', float(getattr(self, 'skm_mirror_center_z', 0.0)))
    except Exception:
        pass


def _on_mirror_epsilon_update(self, context):
    del context
    try:
        _save_object_setting('skm_mirror_epsilon', float(getattr(self, 'skm_mirror_epsilon', 0.001)))
    except Exception:
        pass


def _deferred_apply_tick():
    started = time.perf_counter()
    processed = 0
    while _SKM_DEFERRED_APPLY_PENDING and processed < _SKM_DEFERRED_APPLY_TICK_MAX:
        if time.perf_counter() - started >= _SKM_DEFERRED_APPLY_TICK_SECONDS:
            break
        _key, (obj, chn_id) = _SKM_DEFERRED_APPLY_PENDING.popitem(last=False)
        processed += 1
        try:
            name = obj.name
        except ReferenceError:
            # A deleted object's pending selection no longer has a target.
            continue
        if not name or bpy.data.objects.get(name) != obj:
            continue
        try:
            if getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
                continue
            if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') not in {'OBJECT', 'EDIT'}:
                _restore_current_channel_index(obj)
                continue
            if bool(getattr(obj, 'skm_edit_mode', False)) or _auto_key_enabled(bpy.context):
                _restore_current_channel_index(obj)
                continue
            if str(getattr(obj, 'mode', 'OBJECT') or 'OBJECT') == 'EDIT' and getattr(obj.data, 'shape_keys', None) is not None:
                # Edit Mode writes back into the active Shape Key, which would overwrite Basis.
                _restore_current_channel_index(obj)
                _show_map_edit_mode_warning(bpy.context)
                continue
            _switch_morphmapper_channel(obj, chn_id)
            _SKM_DEFERRED_APPLY_STATS["processed"] += 1
        except Exception as error:
            try:
                _restore_current_channel_index(obj)
            except Exception as restore_error:
                print(f"Smart Shapekey map index restore failed: {restore_error}", file=sys.stderr)
            _show_map_switch_error(bpy.context, error)
    return 0.0 if _SKM_DEFERRED_APPLY_PENDING else None


def _switch_morphmapper_channel(obj: bpy.types.Object, target_channel: int) -> None:
    """Commit the departing Base/delta, then restore the selected channel."""
    ref_mesh = _get_ref_mesh(obj)
    if ref_mesh is None:
        raise RuntimeError(_t("Please run Set Base first."))
    _mm_validate_topology(obj, ref_mesh)
    target_channel = int(target_channel)
    current_channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
    rows = _snapshot_map_rows(obj)
    valid = {int(row['chn_id']) for row in rows}
    if target_channel not in valid:
        raise RuntimeError(_t("The selected map has no valid stored geometry."))
    if current_channel not in valid:
        raise RuntimeError(_t("The selected map has no valid stored geometry."))

    previous_positions = _mm_object_coordinates(obj)
    plan = _plan_source_identity(obj)
    staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
    applied = False
    try:
        _mm_validate_topology(obj, staged_mesh)
        if current_channel == BASE_ID:
            if not _mm_basis_is_own_shape(obj):
                _mm_capture_basis(obj, staged_mesh)
        elif getattr(obj.data, 'shape_keys', None) is None:
            # With Shape Keys, Edit Mode edits the keys and resets the vertices to Basis, so the vertices no longer hold the map.
            _mm_capture_delta(obj, staged_mesh, current_channel)
        target = _compute_positions_for_object(obj, target_channel, ref_mesh=staged_mesh)
        uv_name = _get_mapping_uv_name(obj)
        applied = True
        _mm_apply_live_coordinates(obj, target)
        _mm_sync_shape_key_preview(obj, staged_mesh, target_channel)
        obj[OBJ_PROP_ACTIVE_CHANNEL] = target_channel
        _commit_reference_state(obj, staged_mesh, rows, uv_name, int(getattr(obj, 'skm_index', -1)), plan)
        staged_mesh = None
    except Exception as error:
        rollback_errors = []
        if applied:
            try:
                _mm_apply_live_coordinates(obj, previous_positions)
                _mm_sync_shape_key_preview(obj, channel=current_channel)
            except Exception as restore_error:
                rollback_errors.append(f"geometry: {restore_error}")
        try:
            obj[OBJ_PROP_ACTIVE_CHANNEL] = current_channel
            _restore_current_channel_index(obj)
        except Exception as restore_error:
            rollback_errors.append(f"active row: {restore_error}")
        if rollback_errors:
            raise RuntimeError(f"Map switch failed: {error}; rollback failed: {'; '.join(rollback_errors)}") from error
        raise
    finally:
        _discard_staged_mesh(staged_mesh)


# -----------------------------------------------------------------------------
# Object context helpers
# -----------------------------------------------------------------------------
def _context_object(context):
    for attr in ("object", "active_object"):
        try:
            obj = getattr(context, attr, None)
        except Exception:
            obj = None
        if obj is not None:
            return obj

    try:
        view_layer = getattr(context, "view_layer", None)
        active = getattr(getattr(view_layer, "objects", None), "active", None)
        if active is not None:
            return active
    except Exception:
        pass

    try:
        for obj in tuple(getattr(context, "selected_objects", ()) or ()):
            if obj is not None:
                return obj
    except Exception:
        pass
    return None


def _context_mesh_object(context):
    obj = _context_object(context)
    candidates = []
    if obj is not None:
        candidates.append(obj)
    try:
        candidates.extend(tuple(getattr(context, 'selected_objects', ()) or ()))
    except Exception:
        pass
    seen = set()
    for candidate in candidates:
        if candidate is None or id(candidate) in seen:
            continue
        seen.add(id(candidate))
        try:
            if getattr(candidate, 'type', None) != 'MESH' or getattr(candidate, 'data', None) is None:
                continue
            if hasattr(bpy.data.objects, 'get') and bpy.data.objects.get(getattr(candidate, 'name', '')) is not candidate:
                continue
            return candidate
        except Exception:
            continue
    return None


def _panel_active_mesh_object(context, *, require_selected: bool = True):
    """Resolve a stable active mesh object for UI panel drawing.

    During mode changes Blender may briefly expose a context object that is no
    longer selected, no longer in bpy.data, or has no valid data pointer. Do not
    build RNA UI widgets for such objects.
    """
    obj = None
    for attr in ('object', 'active_object'):
        try:
            candidate = getattr(context, attr, None)
        except Exception:
            candidate = None
        if candidate is not None:
            obj = candidate
            break
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        if getattr(obj, 'data', None) is None:
            return None
    except Exception:
        return None
    try:
        if getattr(bpy.data.objects, 'get', None) and bpy.data.objects.get(getattr(obj, 'name', '')) is not obj:
            return None
    except Exception:
        return None
    if require_selected:
        try:
            selected_objects = tuple(getattr(context, 'selected_objects', ()) or ())
            if selected_objects and obj not in selected_objects:
                return None
        except Exception:
            pass
        try:
            mode = str(getattr(context, 'mode', '') or '')
            if mode in {'', 'OBJECT'} and hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
    return obj


def _panel_context_mode_supported(context) -> bool:
    try:
        mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        mode = ''
    return mode in {'', 'OBJECT', 'EDIT_MESH'}


def _is_mesh_panel_context(context) -> bool:
    # Keep the root N-panel visible even when the active mesh is deselected or
    # when no mesh is selected.  The draw method handles missing mesh data and
    # shows the appropriate section headers / guidance instead of making the
    # whole Smart Shapekey tab look empty.
    return _is_view3d_npanel_context(context)


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------
class SKM_OT_set_base(bpy.types.Operator):
    bl_idname = "skm.set_base"
    bl_label = _t("Set Base")
    bl_description = _t("Create a base snapshot (Basis) used as reference. This does NOT change the current mesh.")
    bl_options = {'UNDO'}

    selected_polygons: bpy.props.BoolProperty(
        name=_t("Set Base on Selected Polygons"), default=False,
    )
    dialog_range: bpy.props.EnumProperty(
        name=_t("Set Base"),
        items=[('SELECTED', _t("Selected Polygons"), ''), ('ALL', _t("All Polygons"), '')],
        default='SELECTED',
    )
    dialog_invoked: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        del event
        self.dialog_invoked = True
        obj = _context_mesh_object(context)
        if obj is None or _get_ref_mesh(obj) is None:
            self.dialog_range = 'ALL'
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        obj = _context_mesh_object(context)
        row = self.layout.row()
        row.enabled = obj is not None and _get_ref_mesh(obj) is not None
        row.prop(self, 'dialog_range', expand=True)
        self.layout.label(text=_t("Mapping Channel: {id}").format(id=BASE_ID))

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, _t("Active object must be a mesh."))
            return {'CANCELLED'}
        mesh = getattr(obj, 'data', None)
        if mesh is None:
            self.report({'ERROR'}, _t("Active object must be a mesh."))
            return {'CANCELLED'}
        if getattr(obj, 'library', None) is not None or getattr(mesh, 'library', None) is not None or int(getattr(mesh, 'users', 1)) != 1:
            self.report({'ERROR'}, _t("Maps require local single-user mesh data."))
            return {'CANCELLED'}
        uv_name = _get_mapping_uv_name(obj)

        staged_mesh = None
        try:
            reference = _get_ref_mesh(obj)
            if reference is not None:
                _mm_validate_topology(obj, reference)
            live_edit = _mm_read_live_edit(obj)
            with ForceObjectMode(obj, context):
                if live_edit is None:
                    _mm_refresh_map_vertices(obj)
                else:
                    _mm_apply_live_edit(obj, live_edit)
                plan = _plan_source_identity(obj)
                rows = _snapshot_map_rows(obj)
                existing_ref = _get_ref_mesh(obj)
                absolute_channels = {}
                if existing_ref is not None and rows:
                    _mm_validate_topology(obj, existing_ref)
                    for row in rows:
                        channel = int(row['chn_id'])
                        if channel != BASE_ID:
                            absolute_channels[channel] = _mm_positions(existing_ref, channel)
                    staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                else:
                    staged_mesh = _copy_mesh_data_block(mesh, f".__SKM_MORPHMAPPER_{uuid.uuid4().hex}")
                    _sss_ownership.mark_temporary(staged_mesh, plan['identity'])
                    rows = [{
                        'name': BASIS_NAME,
                        'prev_name': BASIS_NAME,
                        'chn_id': BASE_ID,
                        'selected': False,
                        'locked': True,
                    }]
                new_basis = _mm_object_coordinates(obj)
                use_selected = bool(self.selected_polygons or (self.dialog_invoked and self.dialog_range == 'SELECTED'))
                if use_selected and existing_ref is not None:
                    selected = set(_mm_selected_polygon_vertices(obj))
                    if not selected:
                        raise RuntimeError(_t("Select at least one polygon."))
                    prior_basis = _mm_basis_vectors(existing_ref)
                    if prior_basis is None:
                        raise RuntimeError(_t("Please run Set Base first."))
                    for vertex_index in range(len(obj.data.vertices)):
                        if vertex_index not in selected:
                            start = vertex_index * 3
                            new_basis[start:start + 3] = prior_basis[start:start + 3]
                _mm_write_vectors(staged_mesh, MM_BASIS_ATTRIBUTE, new_basis)
                for channel, absolute in absolute_channels.items():
                    new_delta = array('f', (float(absolute[i]) - float(new_basis[i]) for i in range(len(new_basis))))
                    _mm_write_vectors(staged_mesh, _mm_delta_attribute_name(channel), new_delta)
                basis_index = next((i for i, row in enumerate(rows) if int(row['chn_id']) == BASE_ID), 0)
                _commit_reference_state(obj, staged_mesh, rows, uv_name, basis_index, plan)
                staged_mesh = None
                obj[OBJ_PROP_ACTIVE_CHANNEL] = BASE_ID
                if live_edit is not None:
                    _mm_restore_edit_keys(obj, live_edit)
                _mm_sync_shape_key_preview(obj)
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        self.report({'INFO'}, _t("Done."))
        return {'FINISHED'}



class SKM_OT_new_map(bpy.types.Operator):
    bl_idname = "skm.new_map"
    bl_label = _t("New Map")
    bl_description = _t("Create a new map from the current mesh shape. The mesh shape is not changed.")
    bl_options = {'UNDO'}

    map_name: bpy.props.StringProperty(name=_t("Name"), default=DEFAULT_MAP_BASENAME)
    dialog_invoked: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        del event
        self.dialog_invoked = True
        self.map_name = ""
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, 'map_name')
        obj = _context_mesh_object(context)
        if obj is not None:
            channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
            current = next((str(row.name) for row in obj.skm_maps if int(row.chn_id) == channel), BASIS_NAME)
            self.layout.label(text=_t("Reference Map: {name}").format(name=current))
            used = {int(row.chn_id) for row in obj.skm_maps}
            free = next((value for value in range(BASE_ID - 1, 0, -1) if value not in used), None)
            if free is not None:
                self.layout.label(text=_t("Mapping Channel: {id}").format(id=free))
        if str(self.map_name or '') == '':
            self.layout.label(text=_t("Choose a nonempty new name."), icon='ERROR')

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, _t("Active object must be a mesh."))
            return {'CANCELLED'}
        rows = _snapshot_map_rows(obj)
        if not rows or int(rows[0]['chn_id']) != BASE_ID:
            self.report({'ERROR'}, _t("Please run Set Base first."))
            return {'CANCELLED'}
        if str(self.map_name or '') == '':
            self.report({'ERROR'}, _t("Name must not be empty."))
            return {'CANCELLED'}
        staged_mesh = None
        try:
            _mm_validate_topology(obj, _get_ref_mesh(obj))
            live_edit = _mm_read_live_edit(obj)
            with ForceObjectMode(obj, context):
                if live_edit is None:
                    _mm_refresh_map_vertices(obj)
                else:
                    _mm_apply_live_edit(obj, live_edit)
                plan = _plan_source_identity(obj)
                staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                used = {int(row['chn_id']) for row in rows}
                _mm_commit_active_channel(obj, staged_mesh, used)
                chn = next((value for value in range(BASE_ID - 1, 0, -1) if value not in used), 1)
                requested = str(self.map_name or '')
                name = _unique_map_name(requested, {row['name'] for row in rows}, preserve_raw=True)
                _capture_shape_to_ref_layers(obj, chn, ref_mesh=staged_mesh, context=context)
                rows.append({
                    'name': name,
                    'prev_name': name,
                    'chn_id': chn,
                    'selected': False,
                    'locked': False,
                })
                uv_name = _get_mapping_uv_name(obj)
                _commit_reference_state(obj, staged_mesh, rows, uv_name, len(rows) - 1, plan)
                staged_mesh = None
                obj[OBJ_PROP_ACTIVE_CHANNEL] = chn
                if live_edit is not None:
                    _mm_restore_edit_keys(obj, live_edit)
                _mm_sync_shape_key_preview(obj)
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        self.report({'INFO'}, _t("Done."))
        return {'FINISHED'}


class SKM_OT_store_map(bpy.types.Operator):
    bl_idname = "skm.store_map"
    bl_label = _t("Store Current Channel")
    bl_description = _t("Commit the current mesh coordinates to the active map channel as Basis-relative XYZ offsets.")
    bl_options = {'UNDO'}

    selected_polygons: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    clear_selected: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    clear_all: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        rows = _snapshot_map_rows(obj)
        index = int(getattr(obj, 'skm_index', -1))
        if not (0 <= index < len(rows)):
            return {'CANCELLED'}
        channel = int(rows[index]['chn_id'])
        if channel == BASE_ID:
            self.report({'WARNING'}, _t("Basis is immutable; use Set Base for an explicit replacement."))
            return {'CANCELLED'}
        staged_mesh = None
        try:
            # Refuse invalid input before leaving Edit Mode: mode_set writes
            # pending edits into user Shape Keys, even when saving later fails.
            reference = _get_ref_mesh(obj)
            if reference is not None:
                _mm_validate_topology(obj, reference)
            if self.selected_polygons and not self.clear_all and not _mm_selected_polygon_vertices(obj):
                raise RuntimeError(_t("Select at least one polygon."))
            live_edit = _mm_read_live_edit(obj)
            with ForceObjectMode(obj, context):
                if live_edit is None:
                    _mm_refresh_map_vertices(obj)
                else:
                    _mm_apply_live_edit(obj, live_edit)
                plan = _plan_source_identity(obj)
                staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                updated_mesh = None
                if self.clear_all:
                    _mm_validate_topology(obj, staged_mesh)
                    basis = _mm_basis_vectors(staged_mesh)
                    if basis is None:
                        raise RuntimeError(_t("Please run Set Base first."))
                    _mm_write_vectors(staged_mesh, _mm_delta_attribute_name(channel), array('f', [0.0]) * len(basis))
                    updated_mesh = array('f', basis)
                elif self.selected_polygons:
                    selected = _mm_selected_polygon_vertices(obj)
                    if not selected:
                        raise RuntimeError(_t("Select at least one polygon."))
                    updated_mesh = _mm_capture_selected_delta(
                        obj, staged_mesh, channel, selected, clear=bool(self.clear_selected)
                    )
                else:
                    _mm_capture_delta(obj, staged_mesh, channel)
                _commit_reference_state(obj, staged_mesh, rows, _get_mapping_uv_name(obj), index, plan)
                staged_mesh = None
                if live_edit is not None:
                    _mm_restore_edit_keys(obj, live_edit)
                if updated_mesh is not None:
                    obj.data.vertices.foreach_set('co', updated_mesh)
                    obj.data.update()
                obj[OBJ_PROP_ACTIVE_CHANNEL] = channel
                _mm_sync_shape_key_preview(obj)
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}



class SKM_OT_clear_map(bpy.types.Operator):
    bl_idname = "skm.clear_map"
    bl_label = _t("Clear")
    bl_description = _t("Clear the active Morph Map on selected or all polygons.")
    bl_options = {'UNDO'}

    target_range: bpy.props.EnumProperty(
        name=_t("Clear"),
        items=[('SELECTED', _t("Selected Polygons"), ''), ('ALL', _t("All Polygons"), '')],
        default='SELECTED',
    )

    def invoke(self, context, event):
        del event
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, 'target_range', expand=True)
        obj = _context_mesh_object(context)
        index = int(getattr(obj, 'skm_index', -1)) if obj else -1
        if obj is not None and 0 <= index < len(obj.skm_maps):
            self.layout.label(text=_t("Current Map Name: {name}").format(name=str(obj.skm_maps[index].name)))
            self.layout.label(text=_t("Mapping Channel: {id}").format(id=int(obj.skm_maps[index].chn_id)))

    def execute(self, context):
        try:
            if self.target_range == 'SELECTED':
                return bpy.ops.skm.store_map(selected_polygons=True, clear_selected=True)
            return bpy.ops.skm.store_map(clear_all=True)
        except RuntimeError as exc:
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}


class SKM_OT_delete_map(bpy.types.Operator):
    bl_idname = "skm.delete_map"
    bl_label = _t("Delete Map")
    bl_description = _t("Delete the selected map (locked maps cannot be deleted).")
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH' or getattr(obj, 'skm__suppress_apply', False):
            return {'CANCELLED'}
        rows = _snapshot_map_rows(obj)
        idx = int(getattr(obj, 'skm_index', -1))
        if not (0 <= idx < len(rows)):
            return {'CANCELLED'}
        row = rows[idx]
        if int(row['chn_id']) == BASE_ID:
            self.report({'WARNING'}, _t("Basis cannot be deleted."))
            return {'CANCELLED'}
        if bool(row['locked']):
            self.report({'WARNING'}, _t("Locked map cannot be deleted."))
            return {'CANCELLED'}
        staged_mesh = None
        try:
            with ForceObjectMode(obj, context):
                plan = _plan_source_identity(obj)
                staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                for name in (_mm_delta_attribute_name(int(row['chn_id'])),):
                    attribute = staged_mesh.attributes.get(name)
                    if attribute is not None:
                        staged_mesh.attributes.remove(attribute)
                for name in (_uv_store_name_a(int(row['chn_id'])), _uv_store_name_b(int(row['chn_id']))):
                    layer = staged_mesh.uv_layers.get(name)
                    if layer is not None:
                        staged_mesh.uv_layers.remove(layer)
                rows.pop(idx)
                new_index = 0 if rows else -1
                _commit_reference_state(obj, staged_mesh, rows, _get_mapping_uv_name(obj), new_index, plan)
                staged_mesh = None
                target_channel = int(rows[new_index]['chn_id']) if new_index >= 0 else BASE_ID
                _apply_map_to_object(obj, target_channel)
                obj[OBJ_PROP_ACTIVE_CHANNEL] = target_channel
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}



class SKM_OT_rename_map(bpy.types.Operator):
    bl_idname = "skm.rename_map"
    bl_label = _t("Rename Map")
    bl_description = _t("Rename the active map without changing its channel ID or geometry.")
    bl_options = {'UNDO'}

    map_name: bpy.props.StringProperty(name=_t("Name"), default="")
    dialog_invoked: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        del event
        obj = _context_mesh_object(context)
        index = int(getattr(obj, 'skm_index', -1)) if obj else -1
        if obj is None or not (0 <= index < len(obj.skm_maps)) or int(obj.skm_maps[index].chn_id) == BASE_ID:
            return {'CANCELLED'}
        self.map_name = str(obj.skm_maps[index].name)
        self.dialog_invoked = True
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.prop(self, 'map_name')
        obj = _context_mesh_object(context)
        index = int(getattr(obj, 'skm_index', -1)) if obj else -1
        if obj is not None and 0 <= index < len(obj.skm_maps):
            self.layout.label(text=_t("Current Map Name: {name}").format(name=str(obj.skm_maps[index].name)))
            self.layout.label(text=_t("Mapping Channel: {id}").format(id=int(obj.skm_maps[index].chn_id)))

    def execute(self, context):
        obj = _context_mesh_object(context)
        index = int(getattr(obj, 'skm_index', -1)) if obj else -1
        if obj is None or not (0 <= index < len(obj.skm_maps)) or int(obj.skm_maps[index].chn_id) == BASE_ID:
            return {'CANCELLED'}
        name = str(self.map_name or '')
        if name == '':
            self.report({'ERROR'}, _t("Name must not be empty."))
            return {'CANCELLED'}
        if self.dialog_invoked and name == str(obj.skm_maps[index].name):
            self.report({'ERROR'}, _t("Choose a nonempty new name."))
            return {'CANCELLED'}
        if any(i != index and str(item.name).casefold() == name.casefold() for i, item in enumerate(obj.skm_maps)):
            self.report({'ERROR'}, _t("Map name already exists."))
            return {'CANCELLED'}
        obj.skm_maps[index].name = name
        return {'FINISHED'}


class SKM_OT_duplicate_map(bpy.types.Operator):
    bl_idname = "skm.duplicate_map"
    bl_label = _t("Duplicate Map")
    bl_description = _t("Duplicate the selected map as a new map.")
    bl_options = {'UNDO'}

    inverted: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'},
        description=_t("When enabled, duplicate the selected map as the inverse of its stored offset from Basis."),
    )

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH' or getattr(obj, 'skm__suppress_apply', False):
            return {'CANCELLED'}
        rows = _snapshot_map_rows(obj)
        idx = int(getattr(obj, 'skm_index', -1))
        if not rows:
            self.report({'ERROR'}, _t("Please run Set Base first."))
            return {'CANCELLED'}
        if not (0 <= idx < len(rows)) or int(rows[idx]['chn_id']) == BASE_ID:
            return {'CANCELLED'}
        staged_mesh = None
        try:
            live_edit = _mm_read_live_edit(obj)
            with ForceObjectMode(obj, context):
                if live_edit is None:
                    _mm_refresh_map_vertices(obj)
                else:
                    _mm_apply_live_edit(obj, live_edit)
                plan = _plan_source_identity(obj)
                staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                source = rows[idx]
                used = {int(row['chn_id']) for row in rows}
                _mm_commit_active_channel(obj, staged_mesh, used)
                chn = next((value for value in range(BASE_ID - 1, 0, -1) if value not in used), 1)
                name = _unique_map_name(DEFAULT_MAP_BASENAME, {row['name'] for row in rows})
                basis_pos = _mm_basis_vectors(staged_mesh)
                source_delta = _mm_delta_vectors(staged_mesh, int(source['chn_id']), basis_pos)
                if source_delta is None or basis_pos is None:
                    raise RuntimeError(_t("Please run Set Base first."))
                if self.inverted:
                    new_delta = array('f', (-float(value) for value in source_delta))
                else:
                    new_delta = array('f', source_delta)
                _mm_write_vectors(staged_mesh, _mm_delta_attribute_name(chn), new_delta)
                rows.append({
                    'name': name,
                    'prev_name': name,
                    'chn_id': chn,
                    'selected': bool(source['selected']),
                    'locked': False,
                })
                _commit_reference_state(obj, staged_mesh, rows, _get_mapping_uv_name(obj), len(rows) - 1, plan)
                staged_mesh = None
                _apply_map_to_object(obj, chn)
                obj[OBJ_PROP_ACTIVE_CHANNEL] = chn
                if live_edit is not None:
                    _mm_restore_edit_keys(obj, live_edit)
                    _mm_sync_shape_key_preview(obj)
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}



class SKM_OT_move_map(bpy.types.Operator):
    bl_idname = "skm.move_map"
    bl_label = _t("Move")
    bl_description = _t("Reorder the map list. Export order follows this list order.")
    bl_options = {'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('UP', _t('Up'), ''), ('DOWN', _t('Down'), '')],
        name=_t("Direction"),
        description=_t("Choose whether the selected map moves up or down in the map list."),
        default='UP'
    )

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        if getattr(obj, 'skm__suppress_apply', False):
            return {'CANCELLED'}
        rows = _snapshot_map_rows(obj)
        idx = int(obj.skm_index)
        if not (0 <= idx < len(rows)):
            return {'CANCELLED'}
        if bool(getattr(obj, 'skm_edit_mode', False)):
            if not any(bool(row['selected']) and int(row['chn_id']) != BASE_ID for row in rows):
                return {'CANCELLED'}
            ordered = _move_selected_map_rows(rows, self.direction)
            if ordered == rows:
                return {'CANCELLED'}
            active_channel = int(rows[idx]['chn_id'])
            new = next(i for i, row in enumerate(ordered) if int(row['chn_id']) == active_channel)
            _replace_map_rows(obj, ordered, new)
            return {'FINISHED'}
        if idx == 0:
            return {'CANCELLED'}
        new = idx - 1 if self.direction == 'UP' else idx + 1
        if new <= 0 or new >= len(rows):
            return {'CANCELLED'}
        obj.skm_maps.move(idx, new)
        obj.skm_index = new
        return {'FINISHED'}


class SKM_OT_order_maps(bpy.types.Operator):
    bl_idname = "skm.order_maps"
    bl_label = _t("Order Maps")
    bl_description = _t("Sort map rows without changing channel identity or stored geometry.")
    bl_options = {'UNDO'}

    mode: bpy.props.EnumProperty(
        items=[('NAME', _t("Sort by Name"), ''), ('CHANNEL_ID', _t("ID Order"), '')],
        default='NAME', options={'HIDDEN'},
    )

    def execute(self, context):
        obj = _context_mesh_object(context)
        rows = _snapshot_map_rows(obj) if obj is not None else []
        if not obj or len(rows) < 2:
            return {'CANCELLED'}
        selected_channel = int(rows[max(0, min(int(obj.skm_index), len(rows) - 1))]['chn_id'])
        basis_rows = [row for row in rows if int(row['chn_id']) == BASE_ID]
        other_rows = [row for row in rows if int(row['chn_id']) != BASE_ID]
        if self.mode == 'NAME':
            other_rows.sort(key=lambda row: (str(row['name']).casefold(), -int(row['chn_id'])))
        else:
            other_rows.sort(key=lambda row: -int(row['chn_id']))
        ordered = basis_rows + other_rows
        new_index = next(i for i, row in enumerate(ordered) if int(row['chn_id']) == selected_channel)
        staged_mesh = None
        try:
            with ForceObjectMode(obj, context):
                plan = _plan_source_identity(obj)
                staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                _commit_reference_state(obj, staged_mesh, ordered, _get_mapping_uv_name(obj), new_index, plan)
                staged_mesh = None
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}


class SKM_OT_import_shape_keys(bpy.types.Operator):
    bl_idname = "skm.import_shape_keys"
    bl_label = _t("Import Shape Keys to Channels")
    bl_description = _t("Append every non-Basis Shape Key as an exact Basis-relative map channel.")
    bl_options = {'UNDO'}

    replace_owned: bpy.props.BoolProperty(default=False, options={'HIDDEN'})

    def invoke(self, context, event):
        self.replace_owned = True
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = _context_mesh_object(context)
        rows = _snapshot_map_rows(obj) if obj is not None else []
        keys = getattr(getattr(getattr(obj, 'data', None), 'shape_keys', None), 'key_blocks', None)
        keys = [key for key in keys if str(key.name) != MM_PREVIEW_KEY_NAME] if keys is not None else None
        if not obj or not rows or keys is None or len(keys) <= 1:
            self.report({'ERROR'}, _t("No non-Basis Shape Keys are available."))
            return {'CANCELLED'}
        staged_mesh = None
        original_coords = None
        original_key_values = ()
        original_axis_handles = ()
        original_active_key = None
        try:
            with ForceObjectMode(obj, context):
                if self.replace_owned:
                    original_coords = _mm_object_coordinates(obj)
                plan = _plan_source_identity(obj)
                staged_mesh = _stage_owned_reference_mesh(obj, plan['identity'])
                _mm_validate_topology(obj, staged_mesh)
                basis = _mm_basis_vectors(staged_mesh)
                if self.replace_owned:
                    for row in rows:
                        channel = int(row['chn_id'])
                        if channel == BASE_ID:
                            continue
                        attribute = staged_mesh.attributes.get(_mm_delta_attribute_name(channel))
                        if attribute is not None:
                            staged_mesh.attributes.remove(attribute)
                        for layer_name in (_uv_store_name_a(channel), _uv_store_name_b(channel)):
                            layer = staged_mesh.uv_layers.get(layer_name)
                            if layer is not None:
                                staged_mesh.uv_layers.remove(layer)
                    rows = [row for row in rows if int(row['chn_id']) == BASE_ID]
                used = {int(row['chn_id']) for row in rows}
                names = {str(row['name']) for row in rows}
                imported = 0
                for key in tuple(keys)[1:]:
                    absolute = array('f', [0.0]) * (len(key.data) * 3)
                    key.data.foreach_get('co', absolute)
                    if basis is None or len(absolute) != len(basis):
                        raise RuntimeError(_t("Shape Key topology does not match the stored Basis."))
                    channel = next((value for value in range(BASE_ID - 1, 0, -1) if value not in used), None)
                    if channel is None:
                        raise RuntimeError(_t("No free map channel is available."))
                    name = _unique_map_name(str(key.name), names)
                    delta = array('f', (float(absolute[i]) - float(basis[i]) for i in range(len(basis))))
                    _mm_write_vectors(staged_mesh, _mm_delta_attribute_name(channel), delta)
                    rows.append({'name': name, 'prev_name': name, 'chn_id': channel, 'selected': False, 'locked': False})
                    used.add(channel); names.add(name); imported += 1
                if not imported:
                    raise RuntimeError(_t("No non-Basis Shape Keys were imported."))
                active_channel = BASE_ID if self.replace_owned else int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
                active_index = next((i for i, row in enumerate(rows) if int(row['chn_id']) == active_channel), 0)
                if self.replace_owned and basis is not None:
                    # A mesh with Shape Keys displays their mix, not its vertices.
                    original_key_values = tuple((key, float(key.value)) for key in tuple(keys)[1:])
                    # Axis handles write Shape Key values, so they follow to center first.
                    original_axis_handles = tuple(
                        (group, float(group.joy_x), float(group.joy_y))
                        for group in getattr(obj, 'shape_xy_groups', ())
                    )
                    for group, _x, _y in original_axis_handles:
                        group.joy_x = 0.0
                        group.joy_y = 0.0
                    for key, _value in original_key_values:
                        key.value = 0.0
                    if obj.show_only_shape_key:
                        original_active_key = int(obj.active_shape_key_index)
                        obj.active_shape_key_index = 0
                    obj.data.vertices.foreach_set('co', basis)
                    obj.data.update()
                _commit_reference_state(obj, staged_mesh, rows, _get_mapping_uv_name(obj), active_index, plan)
                staged_mesh = None
                obj[OBJ_PROP_ACTIVE_CHANNEL] = active_channel
                _mm_sync_shape_key_preview(obj)
        except Exception as exc:
            _discard_staged_mesh(staged_mesh)
            if original_coords is not None:
                try:
                    for group, x, y in original_axis_handles:
                        group.joy_x = x
                        group.joy_y = y
                    for key, value in original_key_values:
                        key.value = value
                    if original_active_key is not None:
                        obj.active_shape_key_index = original_active_key
                    obj.data.vertices.foreach_set('co', original_coords)
                    obj.data.update()
                except Exception:
                    pass
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}


# Clipboard tools
def _get_clipboard(wm):
    if "skm_clipboard" not in wm:
        wm["skm_clipboard"] = {"data": []}
    return wm["skm_clipboard"]


class SKM_OT_copy_selected_verts(bpy.types.Operator):
    bl_idname = "skm.copy_selected_verts"
    bl_label = _t("Copy Selected Verts")
    bl_description = _t("Copy positions of currently selected vertices into an internal clipboard.")
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        # Copy must not leave Edit Mode: that would write pending map edits into
        # the user's active Shape Key. Read the map plus its live edit offset.
        mesh = obj.data
        if obj.mode == 'EDIT':
            bm = bmesh.from_edit_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.verts.index_update()
            sel = [v.index for v in bm.verts if v.select]
        else:
            sel = [v.index for v in mesh.vertices if v.select]
        if not sel:
            return {'CANCELLED'}
        co = _mm_object_coordinates(obj)
        ref = _get_ref_mesh(obj)
        if mesh.shape_keys is not None and ref is not None:
            _mm_validate_topology(obj, ref)
            channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
            co = _mm_positions(ref, channel)
            edit = _mm_read_live_edit(obj)
            if edit is not None:
                co = array('f', (co[i] + edit['live'][i] - edit['shown'][i] for i in range(len(co))))
        data = [(i, co[i*3], co[i*3+1], co[i*3+2]) for i in sel]
        cb = _get_clipboard(context.window_manager)
        cb["data"] = data
        return {'FINISHED'}


class SKM_OT_paste_verts(bpy.types.Operator):
    bl_idname = "skm.paste_verts"
    bl_label = _t("Paste Verts")
    bl_description = _t("Paste copied vertex positions back to the currently selected vertices.")
    bl_options = {'UNDO'}

    mirrored: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'},
        description=_t("When enabled, paste copied vertices mirrored by the current mirror settings."),
    )

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        cb = _get_clipboard(context.window_manager)
        data = cb.get("data", [])
        if not data:
            return {'CANCELLED'}

        ref = _get_ref_mesh(obj)
        channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
        if ref is not None:
            if channel == BASE_ID:
                self.report({'WARNING'}, _t("Basis is immutable; use Set Base for an explicit replacement."))
                return {'CANCELLED'}
            _mm_validate_topology(obj, ref)
        live_edit = _mm_read_live_edit(obj)
        with ForceObjectMode(obj):
            mesh = obj.data
            sel = {v.index for v in mesh.vertices if v.select}
            if not sel:
                return {'CANCELLED'}

            if live_edit is None:
                _mm_refresh_map_vertices(obj)
            else:
                _mm_apply_live_edit(obj, live_edit)
            co = array('f', [0.0]) * (len(mesh.vertices) * 3)
            mesh.vertices.foreach_get("co", co)

            axis = obj.skm_mirror_axis
            center = Vector((obj.skm_mirror_center_x, obj.skm_mirror_center_y, obj.skm_mirror_center_z))
            eps = obj.skm_mirror_epsilon

            import mathutils
            # Partners are found on the rest shape: a copied vertex has usually
            # moved, so its pasted position has no vertex at the mirrored place.
            ref_mesh = _get_ref_mesh(obj)
            rest = _mm_basis_vectors(ref_mesh) if ref_mesh is not None else None
            if rest is None or len(rest) != len(co):
                rest = co[:]
            kd = mathutils.kdtree.KDTree(len(mesh.vertices))
            for v in mesh.vertices:
                kd.insert(Vector(rest[v.index*3:v.index*3+3]), v.index)
            kd.balance()

            def mirror_point(p):
                p = Vector(p)
                q = p - center
                if axis == 'X':
                    q.x = -q.x
                elif axis == 'Y':
                    q.y = -q.y
                else:
                    q.z = -q.z
                return q + center

            for item in data:
                # Blender ID properties store homogeneous numeric sequences, so
                # the integer vertex index written by Copy can be read back as a
                # float.  Normalise and validate every clipboard row before it is
                # used as an ``array`` index.
                try:
                    i, x, y, z = item
                    i = int(i)
                    x = float(x)
                    y = float(y)
                    z = float(z)
                except (TypeError, ValueError, OverflowError):
                    continue
                if i < 0 or i >= len(mesh.vertices):
                    continue
                if not self.mirrored:
                    if i not in sel:
                        continue
                    co[i*3] = x
                    co[i*3+1] = y
                    co[i*3+2] = z
                else:
                    mp = mirror_point((x, y, z))
                    loc, idx, dist = kd.find(mirror_point(rest[i*3:i*3+3]))
                    if dist <= eps and idx in sel:
                        co[idx*3] = mp.x
                        co[idx*3+1] = mp.y
                        co[idx*3+2] = mp.z

            # Commit the pasted absolute positions to the map transaction too.
            # Merely writing mesh.vertices is discarded by the next Store on
            # meshes with Shape Keys when it restores the active stored map.
            if ref is not None:
                staged = None
                try:
                    plan = _plan_source_identity(obj)
                    staged = _stage_owned_reference_mesh(obj, plan['identity'])
                    basis = _mm_basis_vectors(staged)
                    delta = array('f', (float(co[i]) - float(basis[i]) for i in range(len(co))))
                    _mm_write_vectors(staged, _mm_delta_attribute_name(channel), delta)
                    _commit_reference_state(obj, staged, _snapshot_map_rows(obj), _get_mapping_uv_name(obj), int(obj.skm_index), plan)
                    staged = None
                finally:
                    _discard_staged_mesh(staged)
            mesh.vertices.foreach_set("co", co)
            mesh.update()
            if live_edit is not None:
                _mm_restore_edit_keys(obj, live_edit)
            _mm_sync_shape_key_preview(obj)
        return {'FINISHED'}


def _mm_edit_channel(obj, selected, mirror=None):
    """Prepare all coordinates before atomically replacing owned channel storage."""
    channel = int(obj.get(OBJ_PROP_ACTIVE_CHANNEL, BASE_ID))
    if channel == BASE_ID:
        raise RuntimeError(_t("Basis is immutable; use Set Base for an explicit replacement."))
    rows = _snapshot_map_rows(obj)
    index = next((i for i, row in enumerate(rows) if int(row['chn_id']) == channel), -1)
    if index < 0:
        raise RuntimeError(_t("The selected map has no valid stored geometry."))
    ref = _get_ref_mesh(obj)
    if ref is None:
        raise RuntimeError(_t("Please run Set Base first."))
    _mm_validate_topology(obj, ref)
    _mm_refresh_map_vertices(obj)
    basis = _mm_basis_vectors(ref)
    before = _mm_object_coordinates(obj)
    if basis is None or len(basis) != len(before):
        raise RuntimeError(_t("Please run Set Base first."))
    after = array('f', before)
    if mirror is None:
        for vi in selected:
            for axis in range(3):
                k = vi * 3 + axis
                after[k] = 2 * float(basis[k]) - float(before[k])
    else:
        from mathutils.kdtree import KDTree
        axis = 'XYZ'.index(obj.skm_mirror_axis)
        center = (obj.skm_mirror_center_x, obj.skm_mirror_center_y, obj.skm_mirror_center_z)
        kd = KDTree(len(obj.data.vertices))
        for vi in range(len(obj.data.vertices)):
            kd.insert(Vector(basis[vi*3:vi*3+3]), vi)
        kd.balance()
        mirrored = 0
        for vi in selected:
            source_basis = list(basis[vi*3:vi*3+3])
            side = source_basis[axis] - center[axis]
            if not ((mirror == 'LR' and side < 0) or (mirror == 'RL' and side > 0)):
                continue
            query = list(source_basis)
            query[axis] = 2 * center[axis] - query[axis]
            _location, target, distance = kd.find(Vector(query))
            target_side = basis[target*3+axis] - center[axis]
            if distance > obj.skm_mirror_epsilon or side * target_side >= 0:
                continue
            for component in range(3):
                delta = float(before[vi*3+component]) - float(source_basis[component])
                after[target*3+component] = float(basis[target*3+component]) + (-delta if component == axis else delta)
            mirrored += 1
        if not mirrored:
            raise RuntimeError(_t("No selected vertices on the source side, or no matching vertices on the other side."))
    staged = None
    try:
        plan = _plan_source_identity(obj)
        staged = _stage_owned_reference_mesh(obj, plan['identity'])
        delta = array('f', (float(after[i]) - float(basis[i]) for i in range(len(after))))
        _mm_write_vectors(staged, _mm_delta_attribute_name(channel), delta)
        # If the reference transaction fails, restore visible coordinates too.
        obj.data.vertices.foreach_set('co', after)
        obj.data.update()
        _commit_reference_state(obj, staged, rows, _get_mapping_uv_name(obj), index, plan)
        staged = None
        _mm_sync_shape_key_preview(obj)
    except Exception:
        obj.data.vertices.foreach_set('co', before)
        obj.data.update()
        raise
    finally:
        _discard_staged_mesh(staged)


class SKM_OT_invert_selected(bpy.types.Operator):
    bl_idname = "skm.invert_selected"
    bl_label = _t("Invert Selected Shape")
    bl_description = _t("Invert the current selection around Basis (selected verts only).")
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        try:
            with ForceObjectMode(obj, context):
                selected = [v.index for v in obj.data.vertices if v.select]
                if not selected:
                    self.report({'WARNING'}, _t("Select vertices in Edit Mode first."))
                    return {'CANCELLED'}
                _mm_edit_channel(obj, selected)
        except Exception as exc:
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}


class SKM_OT_mirror_selected(bpy.types.Operator):
    bl_idname = "skm.mirror_selected"
    bl_label = _t("Mirror Selected")
    bl_description = _t("Mirror selected vertices shape (uses mirror settings).")
    bl_options = {'UNDO'}

    direction: bpy.props.EnumProperty(
        items=[('LR', "L→R", ""), ('RL', "R→L", "")],
        name=_t("Direction"),
        description=_t("Choose which side is copied across the mirror plane: left to right or right to left."),
        default='LR'
    )

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        try:
            with ForceObjectMode(obj, context):
                selected = [v.index for v in obj.data.vertices if v.select]
                if not selected:
                    self.report({'WARNING'}, _t("Select vertices in Edit Mode first."))
                    return {'CANCELLED'}
                _mm_edit_channel(obj, selected, self.direction)
        except Exception as exc:
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        return {'FINISHED'}


class SKM_OT_mirror_settings(bpy.types.Operator):
    bl_idname = "skm.mirror_settings"
    bl_label = _t("Mirror Settings")
    bl_description = _t("Open mirror settings (axis / center / tolerance).")
    bl_options = {'UNDO'}

    _target = None
    _snapshot = None

    def invoke(self, context, event):
        obj = _context_mesh_object(context)
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            self.report({'WARNING'}, _t("Select a mesh object."))
            return {'CANCELLED'}
        self._target = obj
        self._snapshot = (
            str(getattr(obj, 'skm_mirror_axis', 'X') or 'X'),
            float(getattr(obj, 'skm_mirror_center_x', 0.0)),
            float(getattr(obj, 'skm_mirror_center_y', 0.0)),
            float(getattr(obj, 'skm_mirror_center_z', 0.0)),
            float(getattr(obj, 'skm_mirror_epsilon', 0.001)),
        )
        return context.window_manager.invoke_props_dialog(self, width=340)

    def _restore_snapshot(self):
        obj = self._target
        snap = self._snapshot
        if obj is None or snap is None:
            return
        try:
            name = str(getattr(obj, 'name', '') or '')
            if not name or bpy.data.objects.get(name) is not obj:
                return
            obj.skm_mirror_axis = snap[0]
            obj.skm_mirror_center_x = snap[1]
            obj.skm_mirror_center_y = snap[2]
            obj.skm_mirror_center_z = snap[3]
            obj.skm_mirror_epsilon = snap[4]
        except Exception:
            pass

    def cancel(self, context):
        del context
        self._restore_snapshot()

    def execute(self, context):
        del context
        self._snapshot = None
        self._target = None
        return {'FINISHED'}

    def draw(self, context):
        obj = self._target or _context_mesh_object(context)
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if not obj or getattr(obj, "type", None) != 'MESH':
            layout.label(text=_t("Select a mesh object."))
            return
        layout.prop(obj, "skm_mirror_axis")
        col = layout.column(align=True)
        col.label(text=_t("Center"))
        row = col.row(align=True)
        row.prop(obj, "skm_mirror_center_x", text="X")
        row.prop(obj, "skm_mirror_center_y", text="Y")
        row.prop(obj, "skm_mirror_center_z", text="Z")
        layout.prop(obj, "skm_mirror_epsilon")



# Export
class SKM_OT_export_shapekeys(bpy.types.Operator):
    bl_idname = "skm.export_shapekeys"
    bl_label = _t("Export to Shape Keys")
    bl_description = _t("Export all or selected maps as Shape Keys on the active object.")
    bl_options = {'UNDO'}
    overwrite_existing: bpy.props.BoolProperty(default=True, options={'HIDDEN'})

    target: bpy.props.EnumProperty(
        items=[('ALL', _t('All'), ''), ('SELECTED', _t('Selected'), '')],
        name=_t("Target"),
        description=_t("Choose whether the operation uses all maps or only maps marked Select."),
        default='ALL'
    )

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        selected_rows = [
            item for item in tuple(obj.skm_maps)
            if item.chn_id != BASE_ID and (self.target != 'SELECTED' or item.selected)
        ]
        if not selected_rows:
            self.report({'WARNING'}, _t("No maps are selected for export."))
            return {'CANCELLED'}

        staged_obj = None
        staged_mesh = None
        original_mesh = obj.data
        committed = False
        try:
            # Validate and calculate every map before any source mutation.
            coordinate_arrays = OrderedDict()
            vertex_count = len(original_mesh.vertices)
            for item in selected_rows:
                flat = _compute_positions_for_object(obj, int(item.chn_id))
                if len(flat) != vertex_count * 3:
                    raise RuntimeError(_t("Map vertex count validation failed."))
                coordinates = [
                    (float(flat[index]), float(flat[index + 1]), float(flat[index + 2]))
                    for index in range(0, len(flat), 3)
                ]
                coordinate_arrays[str(item.name)] = coordinates

            from .apply_modifiers_with_shape_keys import functions as _shape_transaction
            staged_mesh = original_mesh.copy()
            staged_mesh.name = f".__SKM_SHAPEKEY_EXPORT_{uuid.uuid4().hex}"
            staged_obj = obj.copy()
            staged_obj.data = staged_mesh
            staged_obj.name = f".__SKM_SHAPEKEY_EXPORT_OBJ_{uuid.uuid4().hex}"
            collection = tuple(getattr(obj, 'users_collection', ()) or ())
            target_collection = collection[0] if collection else getattr(context, 'collection', None)
            if target_collection is None:
                raise RuntimeError(_t("No collection is available for staging."))
            target_collection.objects.link(staged_obj)
            staged_obj.hide_viewport = True
            staged_obj.hide_render = True

            existing_keys = getattr(original_mesh, 'shape_keys', None)
            overrides = {}
            appended = []
            if existing_keys is None or not tuple(getattr(existing_keys, 'key_blocks', ()) or ()):
                basis_flat = _compute_positions_for_object(obj, BASE_ID)
                if len(basis_flat) != vertex_count * 3:
                    raise RuntimeError(_t("Map vertex count validation failed."))
                basis_values = [
                    (float(basis_flat[index]), float(basis_flat[index + 1]), float(basis_flat[index + 2]))
                    for index in range(0, len(basis_flat), 3)
                ]
                appended.append((BASIS_NAME, basis_values))
            existing_names = {
                str(key.name) for key in tuple(getattr(existing_keys, 'key_blocks', ()) or ())
            }
            expected_names = []
            for name, values in coordinate_arrays.items():
                if name in existing_names:
                    if self.overwrite_existing:
                        overrides[name] = values
                        expected_names.append(name)
                    else:
                        safe_name = _unique_map_name(name, existing_names | {entry[0] for entry in appended})
                        appended.append((safe_name, values))
                        expected_names.append(safe_name)
                else:
                    appended.append((name, values))
                    expected_names.append(name)
            _shape_transaction.rebuild_shape_key_graph(
                obj,
                staged_obj,
                coordinate_overrides=overrides,
                appended_keys=appended,
                excluded_keys=(MM_PREVIEW_KEY_NAME,),
            )
            staged_keys = getattr(staged_mesh, 'shape_keys', None)
            for name in expected_names:
                if staged_keys is None or staged_keys.key_blocks.get(name) is None:
                    raise RuntimeError(_t("Staged Shape Key validation failed."))

            # Single model commit. The old mesh is retained for Blender Undo and
            # is never deleted by this operator.
            obj.data = staged_mesh
            if obj.data is not staged_mesh:
                raise RuntimeError(_t("Shape Key mesh swap validation failed."))
            committed = True
            # The new keys are the result: the mesh goes back to the Basis row,
            # so the map on display does not stay mixed in with them.
            obj[OBJ_PROP_ACTIVE_CHANNEL] = BASE_ID
            _restore_current_channel_index(obj)
            obj.data.vertices.foreach_set('co', _compute_positions_for_object(obj, BASE_ID))
            obj.data.update()
            _mm_sync_shape_key_preview(obj)
            return {'FINISHED'}
        except Exception as exc:
            if not committed:
                try:
                    if obj.data is not original_mesh:
                        obj.data = original_mesh
                except Exception:
                    pass
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        finally:
            if staged_obj is not None:
                try:
                    bpy.data.objects.remove(staged_obj, do_unlink=True)
                except Exception:
                    pass
            if not committed and staged_mesh is not None:
                try:
                    if getattr(staged_mesh, 'users', 0) == 0:
                        bpy.data.meshes.remove(staged_mesh)
                except Exception:
                    pass


class SKM_OT_export_objects(bpy.types.Operator):
    bl_idname = "skm.export_objects"
    bl_label = _t("Export to Objects")
    bl_description = _t("Create clean mesh objects for each map, placed in a grid.")
    bl_options = {'UNDO'}

    target: bpy.props.EnumProperty(
        items=[('ALL', _t('All'), ''), ('SELECTED', _t('Selected'), '')],
        name=_t("Target"),
        description=_t("Choose whether the operation uses all maps or only maps marked Select."),
        default='ALL'
    )
    source_layout: bpy.props.BoolProperty(default=False, options={'HIDDEN'})
    prefix: bpy.props.StringProperty(name=_t("Prefix"), default="")
    spacing: bpy.props.FloatProperty(name=_t("Spacing"), default=0.5, min=-9999.0, max=9999.0,
                                     description=_t("Distance between generated objects. Example: 0.5 means 50cm if your scene uses meters."))
    columns: bpy.props.IntProperty(name=_t("Columns"), default=5, min=1, max=9999,
                                   description=_t("How many objects per row before wrapping to next row."))
    origin: bpy.props.EnumProperty(
        items=[('CURSOR', _t('3D Cursor'), ''), ('ACTIVE', _t('Active Object'), ''), ('WORLD', _t('World Origin'), '')],
        name=_t("Start"),
        default='CURSOR',
        description=_t("Choose where the grid starts.")
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        maps = [
            item for item in tuple(obj.skm_maps)
            if item.chn_id != BASE_ID and (self.target != 'SELECTED' or item.selected)
        ]
        if not maps:
            self.report({'WARNING'}, _t("No maps are selected for export."))
            return {'CANCELLED'}
        target_collection = getattr(context, 'collection', None)
        if target_collection is None:
            self.report({'ERROR'}, _t("No collection is available for export."))
            return {'CANCELLED'}

        if self.source_layout:
            base_loc = obj.location.copy()
        elif self.origin == 'CURSOR':
            base_loc = context.scene.cursor.location.copy()
        elif self.origin == 'ACTIVE':
            base_loc = obj.location.copy()
        else:
            base_loc = Vector((0.0, 0.0, 0.0))

        staged = []
        linked = []
        try:
            # Compute all arrays first; no Object/Mesh is linked until every
            # input and every generated datablock has passed validation.
            payloads = []
            expected = len(obj.data.vertices) * 3
            for item in maps:
                positions = _compute_positions_for_object(obj, int(item.chn_id))
                if len(positions) != expected:
                    raise RuntimeError(_t("Map vertex count validation failed."))
                payloads.append((str(item.name), positions))
            for index, (name, positions) in enumerate(payloads):
                mesh = obj.data.copy()
                mesh.name = f"{obj.data.name}_{name}"
                # Exported objects are clean geometry snapshots, not Shape Key
                # containers. Clearing happens only on the private staged mesh.
                temp_name = f"{self.prefix}{name}" if self.source_layout else f"{obj.name}_{name}"
                temp = bpy.data.objects.new(temp_name, mesh)
                staged.append((temp, mesh))
                try:
                    if getattr(mesh, 'shape_keys', None) is not None:
                        temp.shape_key_clear()
                except Exception:
                    pass
                mesh.vertices.foreach_set("co", positions)
                mesh.update()
                column = index % int(self.columns)
                row = index // int(self.columns)
                offset = (self.spacing * (column + 1), 0.0, -self.spacing * row) if self.source_layout else (self.spacing * column, -self.spacing * row, 0.0)
                temp.location = base_loc + Vector(offset)
                if len(mesh.vertices) * 3 != expected:
                    raise RuntimeError(_t("Generated object validation failed."))

            for temp, _mesh in staged:
                target_collection.objects.link(temp)
                linked.append(temp)
            if len(linked) != len(staged):
                raise RuntimeError(_t("Generated object commit validation failed."))
            return {'FINISHED'}
        except Exception as exc:
            for temp in reversed(linked):
                try:
                    target_collection.objects.unlink(temp)
                except Exception:
                    pass
            for temp, mesh in reversed(staged):
                try:
                    bpy.data.objects.remove(temp, do_unlink=True)
                except Exception:
                    pass
                try:
                    if getattr(mesh, 'users', 0) == 0:
                        bpy.data.meshes.remove(mesh)
                except Exception:
                    pass
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}


class SKM_OT_export_maps(bpy.types.Operator):
    """MorphMapper's one Export dialog with safe Blender output choices."""
    bl_idname = "skm.export_maps"
    bl_label = _t("Export Morph Maps")
    bl_options = {'UNDO'}

    output: bpy.props.EnumProperty(
        name=_t("Output"),
        items=[('SHAPE_KEYS', _t("Shape Keys"), ''), ('OBJECT', _t("Object"), '')],
        default='SHAPE_KEYS',
    )
    prefix: bpy.props.StringProperty(name=_t("Prefix"), default="")
    offset: bpy.props.FloatProperty(name=_t("Offset"), default=10.0, min=-9999.0, max=9999.0)
    line: bpy.props.IntProperty(name=_t("Line"), default=5, min=1, max=9999)
    replace_matching: bpy.props.BoolProperty(name=_t("Replace matching Shape Keys"), default=False)

    def invoke(self, context, event):
        del event
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        del context
        self.layout.prop(self, 'output', expand=True)
        object_options = self.layout.column()
        object_options.enabled = self.output == 'OBJECT'
        object_options.prop(self, 'prefix')
        object_options.prop(self, 'offset')
        object_options.prop(self, 'line')
        shape_options = self.layout.column()
        shape_options.enabled = self.output == 'SHAPE_KEYS'
        shape_options.prop(self, 'replace_matching')

    def execute(self, context):
        obj = _context_mesh_object(context)
        if obj is None:
            return {'CANCELLED'}
        target = 'SELECTED' if any(int(row.chn_id) != BASE_ID and row.selected for row in obj.skm_maps) else 'ALL'
        try:
            if self.output == 'OBJECT':
                return bpy.ops.skm.export_objects(
                    target=target, source_layout=True, prefix=self.prefix,
                    spacing=self.offset, columns=self.line, origin='ACTIVE',
                )
            return bpy.ops.skm.export_shapekeys(target=target, overwrite_existing=self.replace_matching)
        except RuntimeError as exc:
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}


# Save/Load (external file)
def _collect_maps_for_save(obj, selected_only: bool):
    out = []
    for it in obj.skm_maps:
        if it.chn_id == BASE_ID:
            continue
        if selected_only and not it.selected:
            continue
        out.append(it)
    return out


_MAP_FILE_MAX_BYTES = 256 * 1024 * 1024
_MAP_FILE_MAX_META_BYTES = 8 * 1024 * 1024
_MAP_FILE_MAX_LOOPS = 20_000_000
_MAP_FILE_MAX_MAPS = 65_535


def _strict_json_loads_map_meta(text: str):
    def reject_constant(value):
        raise ValueError(f"non-finite JSON constant: {value}")

    def no_duplicates(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key: {key}")
            result[key] = value
        return result

    return json.loads(text, object_pairs_hook=no_duplicates, parse_constant=reject_constant)


def _serialize_to_bytes(obj, items):
    import struct
    import zlib
    ref_mesh = _get_ref_mesh(obj)
    if ref_mesh is None:
        raise RuntimeError(_t("Please run Set Base first."))
    uv_name = _get_mapping_uv_name(obj)
    ref_uv_layer = ref_mesh.uv_layers.get(uv_name)
    if ref_uv_layer is None:
        raise RuntimeError(_t("No UV layers found."))

    nloops = len(ref_mesh.loops)
    if nloops <= 0 or nloops > _MAP_FILE_MAX_LOOPS:
        raise RuntimeError(_t("The reference mesh loop count is outside the supported range."))
    item_list = tuple(items or ())
    if len(item_list) > _MAP_FILE_MAX_MAPS:
        raise RuntimeError(_t("Too many maps were selected for one file."))
    uv_flat = array('f', [0.0]) * (nloops * 2)
    ref_uv_layer.data.foreach_get("uv", uv_flat)

    basis_vertex = _mm_basis_vectors(ref_mesh)
    if basis_vertex is None or len(basis_vertex) != len(ref_mesh.vertices) * 3:
        raise RuntimeError(_t("Please run Set Base first."))
    basis = [
        (
            float(basis_vertex[int(loop.vertex_index) * 3]),
            float(basis_vertex[int(loop.vertex_index) * 3 + 1]),
            float(basis_vertex[int(loop.vertex_index) * 3 + 2]),
        )
        for loop in ref_mesh.loops
    ]
    try:
        ref_mesh.calc_loop_triangles()
        tri_loop_indices = [list(map(int, tuple(triangle.loops)[:3])) for triangle in ref_mesh.loop_triangles]
    except Exception:
        tri_loop_indices = []

    maps = []
    position_blocks = []
    seen_names = set()
    seen_ids = set()
    for item in item_list:
        name = str(getattr(item, 'name', '') or '')
        channel = int(getattr(item, 'chn_id', 0))
        if not name or len(name) > 128 or name in seen_names or not (1 <= channel < BASE_ID) or channel in seen_ids:
            raise RuntimeError(_t("Map metadata validation failed."))
        absolute_vertex = _mm_positions(ref_mesh, channel)
        if absolute_vertex is None or len(absolute_vertex) != len(ref_mesh.vertices) * 3:
            raise RuntimeError(_t("A selected map has no complete stored geometry."))
        positions = [
            (
                float(absolute_vertex[int(loop.vertex_index) * 3]),
                float(absolute_vertex[int(loop.vertex_index) * 3 + 1]),
                float(absolute_vertex[int(loop.vertex_index) * 3 + 2]),
            )
            for loop in ref_mesh.loops
        ]
        seen_names.add(name)
        seen_ids.add(channel)
        maps.append({"name": name, "chn_id": channel})
        position_blocks.append(positions)

    meta = {
        "version": "1.4.20",
        "uv_name": str(uv_name),
        "nloops": int(nloops),
        "tri_loop_indices": tri_loop_indices,
        "maps": maps,
    }
    floats = array('f')
    floats.extend(uv_flat)
    for position in basis:
        floats.extend((float(position[0]), float(position[1]), float(position[2])))
    for block in position_blocks:
        for position in block:
            floats.extend((float(position[0]), float(position[1]), float(position[2])))
    import math
    if any(not math.isfinite(float(value)) for value in floats):
        raise RuntimeError(_t("Map geometry contains NaN or Infinity."))

    meta_bytes = json.dumps(meta, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')
    if len(meta_bytes) <= 0 or len(meta_bytes) > _MAP_FILE_MAX_META_BYTES:
        raise RuntimeError(_t("Map metadata is too large."))
    compressed = zlib.compress(floats.tobytes(), level=6)
    blob = struct.pack("<I", len(meta_bytes)) + meta_bytes + compressed
    if len(blob) > _MAP_FILE_MAX_BYTES:
        raise RuntimeError(_t("The map file exceeds the supported size limit."))
    return blob


def _deserialize_from_bytes(data: bytes):
    import math
    import struct
    import zlib
    try:
        if not isinstance(data, (bytes, bytearray)) or len(data) < 5 or len(data) > _MAP_FILE_MAX_BYTES:
            raise ValueError("invalid file size")
        meta_len = struct.unpack("<I", bytes(data[:4]))[0]
        if meta_len <= 0 or meta_len > _MAP_FILE_MAX_META_BYTES or meta_len > len(data) - 5:
            raise ValueError("invalid metadata length")
        meta_text = bytes(data[4:4 + meta_len]).decode('utf-8', errors='strict')
        if '\x00' in meta_text:
            raise ValueError("NUL in metadata")
        meta = _strict_json_loads_map_meta(meta_text)
        if not isinstance(meta, dict) or set(meta) != {"version", "uv_name", "nloops", "tri_loop_indices", "maps"}:
            raise ValueError("unknown or missing metadata fields")
        if meta["version"] not in {"1.4.1", "1.4.20"}:
            raise ValueError("unsupported version")
        if not isinstance(meta["uv_name"], str) or not meta["uv_name"] or len(meta["uv_name"]) > 1024:
            raise ValueError("invalid UV name")
        nloops = meta["nloops"]
        if isinstance(nloops, bool) or not isinstance(nloops, int) or not (1 <= nloops <= _MAP_FILE_MAX_LOOPS):
            raise ValueError("invalid loop count")
        maps = meta["maps"]
        if not isinstance(maps, list) or len(maps) > _MAP_FILE_MAX_MAPS:
            raise ValueError("invalid map list")
        seen_names = set()
        seen_channels = set()
        for item in maps:
            if not isinstance(item, dict) or set(item) != {"name", "chn_id"}:
                raise ValueError("invalid map item fields")
            name = item["name"]
            channel = item["chn_id"]
            if not isinstance(name, str) or name == '' or len(name) > 128 or name in seen_names:
                raise ValueError("invalid map name")
            if isinstance(channel, bool) or not isinstance(channel, int) or not (1 <= channel < BASE_ID) or channel in seen_channels:
                raise ValueError("invalid map channel")
            seen_names.add(name)
            seen_channels.add(channel)
        triangles = meta["tri_loop_indices"]
        if not isinstance(triangles, list) or len(triangles) > nloops * 4:
            raise ValueError("invalid triangle list")
        for triangle in triangles:
            if not isinstance(triangle, list) or len(triangle) != 3:
                raise ValueError("invalid triangle")
            for index in triangle:
                if isinstance(index, bool) or not isinstance(index, int) or not (0 <= index < nloops):
                    raise ValueError("invalid triangle index")

        expected_float_count = nloops * 2 + nloops * 3 * (1 + len(maps))
        expected_bytes = expected_float_count * 4
        if expected_bytes > _MAP_FILE_MAX_BYTES:
            raise ValueError("decompressed payload too large")
        compressed = bytes(data[4 + meta_len:])
        decompressor = zlib.decompressobj()
        raw = decompressor.decompress(compressed, expected_bytes + 1)
        if len(raw) != expected_bytes or not decompressor.eof or decompressor.unused_data or decompressor.unconsumed_tail:
            raise ValueError("compressed payload length mismatch")
        floats = array('f')
        floats.frombytes(raw)
        if len(floats) != expected_float_count or any(not math.isfinite(float(value)) for value in floats):
            raise ValueError("invalid/non-finite geometry payload")
        return meta, floats
    except Exception as exc:
        if isinstance(exc, RuntimeError) and str(exc):
            raise
        raise RuntimeError(_t("Invalid file.")) from exc

def _decode_position_block(floats, start: int, nloops: int):
    end = start + nloops * 3
    if start < 0 or end > len(floats):
        raise RuntimeError(_t("Invalid file."))
    out = []
    for idx in range(start, end, 3):
        out.append((floats[idx], floats[idx + 1], floats[idx + 2]))
    return out, end


def _build_sampler_from_serialized(uv_flat, positions_loop, tri_loop_indices) -> UVSampler:
    nloops = len(positions_loop)
    if nloops <= 0 or len(uv_flat) < nloops * 2:
        raise RuntimeError(_t("Invalid file."))
    if not isinstance(tri_loop_indices, (list, tuple)) or not tri_loop_indices:
        raise RuntimeError(_t("This map file cannot be rebuilt on a different topology. Load it on a mesh with the same loop count."))

    tri_uv = []
    tri_p0 = []
    tri_p1 = []
    tri_p2 = []
    bb_min = [1e30, 1e30]
    bb_max = [-1e30, -1e30]

    def loop_uv(li):
        return (float(uv_flat[li * 2]), float(uv_flat[li * 2 + 1]))

    for raw_tri in tri_loop_indices:
        try:
            li0, li1, li2 = int(raw_tri[0]), int(raw_tri[1]), int(raw_tri[2])
        except Exception:
            continue
        if not (0 <= li0 < nloops and 0 <= li1 < nloops and 0 <= li2 < nloops):
            continue
        a = loop_uv(li0); b = loop_uv(li1); c = loop_uv(li2)
        area = (Vector(b) - Vector(a)).cross(Vector(c) - Vector(a))
        if abs(area) < 1e-20:
            continue
        tri_uv.append((a, b, c))
        tri_p0.append(positions_loop[li0])
        tri_p1.append(positions_loop[li1])
        tri_p2.append(positions_loop[li2])
        for uv in (a, b, c):
            bb_min[0] = min(bb_min[0], uv[0]); bb_min[1] = min(bb_min[1], uv[1])
            bb_max[0] = max(bb_max[0], uv[0]); bb_max[1] = max(bb_max[1], uv[1])

    if not tri_uv:
        raise RuntimeError(_t("Invalid file."))

    res = 64
    grid = [[] for _ in range(res * res)]
    min_u, min_v = bb_min
    max_u, max_v = bb_max
    du = (max_u - min_u) if (max_u - min_u) != 0.0 else 1.0
    dv = (max_v - min_v) if (max_v - min_v) != 0.0 else 1.0

    for ti, uvtri in enumerate(tri_uv):
        u0 = min(p[0] for p in uvtri); u1 = max(p[0] for p in uvtri)
        v0 = min(p[1] for p in uvtri); v1 = max(p[1] for p in uvtri)
        x0 = max(0, min(res - 1, int(floor((u0 - min_u) / du * res))))
        x1 = max(0, min(res - 1, int(floor((u1 - min_u) / du * res))))
        y0 = max(0, min(res - 1, int(floor((v0 - min_v) / dv * res))))
        y1 = max(0, min(res - 1, int(floor((v1 - min_v) / dv * res))))
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                grid[y * res + x].append(ti)

    return UVSampler(tri_uv, tri_p0, tri_p1, tri_p2, tuple(bb_min), tuple(bb_max), grid, res=res)


def _pull_uvs_into_faces(ref_mesh, uv_flat) -> None:
    """Move each corner slightly into its own face, so a touching UV island cannot answer for it."""
    source = uv_flat[:]
    for polygon in ref_mesh.polygons:
        corners = tuple(polygon.loop_indices)
        center_u = sum(source[li * 2] for li in corners) / len(corners)
        center_v = sum(source[li * 2 + 1] for li in corners) / len(corners)
        for li in corners:
            uv_flat[li * 2] = source[li * 2] + (center_u - source[li * 2]) * 0.005
            uv_flat[li * 2 + 1] = source[li * 2 + 1] + (center_v - source[li * 2 + 1]) * 0.005


def _sample_serialized_positions_to_ref_mesh(ref_mesh, uv_name: str, saved_uv_flat, source_positions, tri_loop_indices, *, evaluate_original_uv=False):
    sampler = _build_sampler_from_serialized(saved_uv_flat, source_positions, tri_loop_indices)
    uv_layer = ref_mesh.uv_layers.get(uv_name)
    if uv_layer is None:
        raise RuntimeError(_t("No UV layers found."))
    nloops = len(ref_mesh.loops)
    uv_flat = array('f', [0.0]) * (nloops * 2)
    uv_layer.data.foreach_get("uv", uv_flat)
    original_uv = uv_flat[:] if evaluate_original_uv else None
    _pull_uvs_into_faces(ref_mesh, uv_flat)
    out = []
    for li in range(nloops):
        lookup = (uv_flat[li * 2], uv_flat[li * 2 + 1])
        if original_uv is None:
            p = sampler.sample(lookup)
        else:
            p = sampler.sample((original_uv[li * 2], original_uv[li * 2 + 1]), lookup_uv=lookup)
        if p is None:
            p = Vector((0.0, 0.0, 0.0))
        out.append((p.x, p.y, p.z))
    return out


_UV_MATCH_MAX_OUTSIDE = 0.10
_UV_MATCH_MAX_TORN = 0.25
_UV_MATCH_MAX_OVERLAP = 0.01
_UV_MATCH_MAX_ISLAND_OUTSIDE = 0.25
_UV_MATCH_MAX_ISLAND_TORN = 0.5
_UV_MATCH_MAX_SHIFT = 0.0015
_UV_MATCH_MAX_ISLAND_SHIFT = 0.008
_UV_MATCH_MIN_ISLAND_LOOPS = 16
_UV_MATCH_MIN_ISLAND_SHARE = 0.01
_UV_MATCH_MIN_ISLAND_SEAMS = 6
_UV_MATCH_SAME_SHAPE_MEAN = 0.01
_UV_MATCH_SAME_SHAPE_MAX = 0.1


def _map_file_matches_loops(ref_mesh, saved_basis, tri_loop_indices) -> bool:
    """True when the file's loops are this mesh's loops: same count, same faces, same vertices."""
    nloops = len(ref_mesh.loops)
    if len(saved_basis) != nloops:
        return False
    loop_vertex = [0] * nloops
    ref_mesh.loops.foreach_get("vertex_index", loop_vertex)
    first_position = {}
    for loop_index, vertex_index in enumerate(loop_vertex):
        position = saved_basis[loop_index]
        known = first_position.setdefault(vertex_index, position)
        if known != position and any(abs(a - b) > 1e-5 for a, b in zip(known, position)):
            return False
    loop_face = [0] * nloops
    for polygon in ref_mesh.polygons:
        for loop_index in polygon.loop_indices:
            loop_face[loop_index] = polygon.index
    for raw_tri in tri_loop_indices or ():
        try:
            faces = {loop_face[int(raw_tri[0])], loop_face[int(raw_tri[1])], loop_face[int(raw_tri[2])]}
        except Exception:
            return False
        if len(faces) != 1:
            return False
    return True


class _UVCoverage:
    """Plain-float grid over UV triangles: answers for a far point at once, unlike the sampler's full search."""

    def __init__(self, uv_flat, triangles, reach=0.0):
        self.reach = reach
        self.tris = []
        self.loops = []
        for raw_tri in triangles:
            l0, l1, l2 = int(raw_tri[0]), int(raw_tri[1]), int(raw_tri[2])
            ax, ay = float(uv_flat[l0 * 2]), float(uv_flat[l0 * 2 + 1])
            bx, by = float(uv_flat[l1 * 2]), float(uv_flat[l1 * 2 + 1])
            cx, cy = float(uv_flat[l2 * 2]), float(uv_flat[l2 * 2 + 1])
            if abs((bx - ax) * (cy - ay) - (cx - ax) * (by - ay)) < 1e-20:
                continue
            self.tris.append((ax, ay, bx, by, cx, cy))
            self.loops.append((l0, l1, l2))
        self.res = max(8, min(256, int(len(self.tris) ** 0.5)))
        self.min_u = min(min(t[0], t[2], t[4]) for t in self.tris) if self.tris else 0.0
        self.min_v = min(min(t[1], t[3], t[5]) for t in self.tris) if self.tris else 0.0
        self.max_u = max(max(t[0], t[2], t[4]) for t in self.tris) if self.tris else 0.0
        self.max_v = max(max(t[1], t[3], t[5]) for t in self.tris) if self.tris else 0.0
        self.scale_u = self.res / max(self.max_u - self.min_u, 1e-9)
        self.scale_v = self.res / max(self.max_v - self.min_v, 1e-9)
        self.grid = {}
        for index, (ax, ay, bx, by, cx, cy) in enumerate(self.tris):
            x0, y0 = self._cell(min(ax, bx, cx) - reach, min(ay, by, cy) - reach)
            x1, y1 = self._cell(max(ax, bx, cx) + reach, max(ay, by, cy) + reach)
            for y in range(y0, y1 + 1):
                for x in range(x0, x1 + 1):
                    self.grid.setdefault((x, y), []).append(index)

    def _cell(self, u, v):
        x = int((u - self.min_u) * self.scale_u)
        y = int((v - self.min_v) * self.scale_v)
        return max(0, min(self.res - 1, x)), max(0, min(self.res - 1, y))

    def _bary(self, index, u, v):
        ax, ay, bx, by, cx, cy = self.tris[index]
        det = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
        w0 = ((by - cy) * (u - cx) + (cx - bx) * (v - cy)) / det
        w1 = ((cy - ay) * (u - cx) + (ax - cx) * (v - cy)) / det
        return w0, w1, 1.0 - w0 - w1

    def is_near(self, u, v):
        reach = self.reach
        if u < self.min_u - reach or u > self.max_u + reach or v < self.min_v - reach or v > self.max_v + reach:
            return False
        limit = reach * reach
        for index in self.grid.get(self._cell(u, v), ()):
            w0, w1, w2 = self._bary(index, u, v)
            if w0 >= 0.0 and w1 >= 0.0 and w2 >= 0.0:
                return True
            ax, ay, bx, by, cx, cy = self.tris[index]
            for px, py, qx, qy in ((ax, ay, bx, by), (bx, by, cx, cy), (cx, cy, ax, ay)):
                ex, ey = qx - px, qy - py
                length = ex * ex + ey * ey
                t = max(0.0, min(1.0, ((u - px) * ex + (v - py) * ey) / length)) if length > 0.0 else 0.0
                dx, dy = px + ex * t - u, py + ey * t - v
                if dx * dx + dy * dy <= limit:
                    return True
        return False

    def covering(self, u, v):
        for index in self.grid.get(self._cell(u, v), ()):
            w0, w1, w2 = self._bary(index, u, v)
            if w0 > 1e-3 and w1 > 1e-3 and w2 > 1e-3:
                yield index, w0, w1, w2


def _position_span(positions) -> float:
    low = [min(p[axis] for p in positions) for axis in range(3)]
    high = [max(p[axis] for p in positions) for axis in range(3)]
    return sum((b - a) ** 2 for a, b in zip(low, high)) ** 0.5


def _saved_uv_overlap_share(saved_uv_flat, triangles, saved_basis) -> float:
    """Share of the saved UV area where one UV point stands for two places of the saved surface."""
    coverage = _UVCoverage(saved_uv_flat, triangles)
    tear = 0.02 * max(_position_span(saved_basis), 1e-6)
    step = max(1, len(coverage.tris) // 4000)
    total = ambiguous = 0.0
    for index in range(0, len(coverage.tris), step):
        ax, ay, bx, by, cx, cy = coverage.tris[index]
        area = abs((bx - ax) * (cy - ay) - (cx - ax) * (by - ay))
        total += area
        u, v = (ax + bx + cx) / 3.0, (ay + by + cy) / 3.0
        l0, l1, l2 = coverage.loops[index]
        center = [(saved_basis[l0][axis] + saved_basis[l1][axis] + saved_basis[l2][axis]) / 3.0 for axis in range(3)]
        for other, w0, w1, w2 in coverage.covering(u, v):
            if other == index:
                continue
            o0, o1, o2 = coverage.loops[other]
            there = [
                saved_basis[o0][axis] * w0 + saved_basis[o1][axis] * w1 + saved_basis[o2][axis] * w2
                for axis in range(3)
            ]
            if sum((a - b) ** 2 for a, b in zip(center, there)) > tear * tear:
                ambiguous += area
                break
    return ambiguous / total if total else 0.0


def _uv_islands(ref_mesh, uv_flat, loop_vertex) -> list:
    """Island number of each loop: faces joined where a vertex keeps one UV across them."""
    parent = list(range(len(loop_vertex)))

    def find(item):
        while parent[item] != item:
            parent[item] = parent[parent[item]]
            item = parent[item]
        return item

    for polygon in ref_mesh.polygons:
        corners = tuple(polygon.loop_indices)
        root = find(corners[0])
        for corner in corners[1:]:
            parent[find(corner)] = root
    first_at = {}
    for loop_index, vertex_index in enumerate(loop_vertex):
        key = (vertex_index, round(uv_flat[loop_index * 2], 5), round(uv_flat[loop_index * 2 + 1], 5))
        other = first_at.setdefault(key, loop_index)
        if other != loop_index:
            parent[find(loop_index)] = find(other)
    return [find(loop_index) for loop_index in range(len(loop_vertex))]


def _uv_layout_measure(ref_mesh, uv_name: str, saved_uv_flat, tri_loop_indices) -> dict:
    """How far this mesh's UV layout is from the saved one, from the UVs alone (shares of 0..1)."""
    nloops = len(ref_mesh.loops)
    uv_flat = array('f', [0.0]) * (nloops * 2)
    ref_mesh.uv_layers[uv_name].data.foreach_get("uv", uv_flat)
    ref_mesh.calc_loop_triangles()
    target_tris = [tuple(triangle.loops)[:3] for triangle in ref_mesh.loop_triangles]
    saved_loops = len(saved_uv_flat) // 2

    saved_us = saved_uv_flat[0::2]
    saved_vs = saved_uv_flat[1::2]
    reach = 0.005 * max(max(saved_us) - min(saved_us), max(saved_vs) - min(saved_vs), 1e-6)
    # A coarse mesh only covers the saved UVs to about the size of its own faces.
    uv_edge_sum = uv_edge_count = 0
    for tri in target_tris:
        for loop_a, loop_b in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])):
            uv_edge_sum += ((uv_flat[loop_a * 2] - uv_flat[loop_b * 2]) ** 2 + (uv_flat[loop_a * 2 + 1] - uv_flat[loop_b * 2 + 1]) ** 2) ** 0.5
            uv_edge_count += 1
    if uv_edge_count:
        reach = max(reach, 0.25 * uv_edge_sum / uv_edge_count)

    saved_coverage = _UVCoverage(saved_uv_flat, tri_loop_indices, reach)
    target_coverage = _UVCoverage(uv_flat, target_tris, reach)

    def outside_share(points_flat, count, coverage):
        step = max(1, count // 4000)
        total = outside = 0
        for i in range(0, count, step):
            total += 1
            if not coverage.is_near(float(points_flat[i * 2]), float(points_flat[i * 2 + 1])):
                outside += 1
        return outside / total if total else 0.0

    loop_vertex = [0] * nloops
    ref_mesh.loops.foreach_get("vertex_index", loop_vertex)
    islands = _uv_islands(ref_mesh, uv_flat, loop_vertex)
    members = {}
    for loop_index, island in enumerate(islands):
        members.setdefault(island, []).append(loop_index)
    least = max(_UV_MATCH_MIN_ISLAND_LOOPS, int(nloops * _UV_MATCH_MIN_ISLAND_SHARE))
    island_outside = 0.0
    for loops in members.values():
        if len(loops) < least:
            continue
        step = max(1, len(loops) // 64)
        probes = loops[::step]
        missed = sum(
            1 for li in probes
            if not saved_coverage.is_near(float(uv_flat[li * 2]), float(uv_flat[li * 2 + 1]))
        )
        island_outside = max(island_outside, missed / len(probes))

    return {
        'target_outside': outside_share(uv_flat, nloops, saved_coverage),
        'saved_outside': outside_share(saved_uv_flat, saved_loops, target_coverage),
        'island_outside': island_outside,
        'uv_flat': uv_flat,
        'loop_vertex': loop_vertex,
        'islands': islands,
        'island_sizes': {island: len(loops) for island, loops in members.items()},
        'target_tris': target_tris,
    }


def _median(values) -> float:
    return sorted(values)[len(values) // 2]


def _match_exact_subdivision(ref_mesh, uv_name, saved_uv, saved_basis, triangles, saved_maps):
    """Prove a subdivision correspondence instead of relaxing the UV guards.

    Saved triangle loop IDs retain the original polygon boundaries. Rebuild a
    temporary reference and accept only when every target corner has both its
    UV and position on an actual Blender subdivision of that reference.
    """
    count = len(saved_basis)
    levels = [n for n in range(1, 5) if len(ref_mesh.polygons) == count * (4 ** (n - 1))]
    if not levels:
        return None
    parent = list(range(count))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for tri in triangles:
        a = root(int(tri[0]))
        for b in tri[1:]:
            parent[root(int(b))] = a
    groups = {}
    for i in range(count):
        groups.setdefault(root(i), []).append(i)
    faces = sorted(groups.values(), key=lambda face: face[0])
    if any(len(face) < 3 for face in faces):
        return None
    vertices, lookup, loop_vertex = [], {}, []
    for p in saved_basis:
        key = tuple(p)
        if key not in lookup:
            lookup[key] = len(vertices)
            vertices.append(key)
        loop_vertex.append(lookup[key])
    # Coincident disconnected pieces with different maps cannot be welded safely.
    map_vertices = []
    for positions in saved_maps:
        rows = [None] * len(vertices)
        for vi, p in zip(loop_vertex, positions):
            if rows[vi] is not None and (Vector(rows[vi]) - Vector(p)).length > 1e-6:
                return None
            rows[vi] = p
        map_vertices.append(rows)
    mesh = obj = None
    evaluated = None
    try:
        mesh = bpy.data.meshes.new('.__SKM_SUBDIV_PROOF')
        mesh.from_pydata(vertices, [], [[loop_vertex[i] for i in face] for face in faces])
        mesh.update()
        uv = mesh.uv_layers.new(name=uv_name)
        source_loops = [i for face in faces for i in face]
        for li, old in enumerate(source_loops):
            uv.data[li].uv = (saved_uv[old * 2], saved_uv[old * 2 + 1])
        obj = bpy.data.objects.new('.__SKM_SUBDIV_PROOF', mesh)
        bpy.context.scene.collection.objects.link(obj)
        sub = obj.modifiers.new('Subdivision proof', 'SUBSURF')
        tolerance = max(_position_span(saved_basis), 1e-6) * 1e-5
        target_uv = ref_mesh.uv_layers[uv_name]
        for level in levels:
            sub.levels = level
            for method in ('SIMPLE', 'CATMULL_CLARK'):
                sub.subdivision_type = method
                bpy.context.view_layer.update()
                evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                sample = evaluated.to_mesh()
                try:
                    if len(sample.loops) != len(ref_mesh.loops):
                        continue
                    sample_uv = sample.uv_layers[uv_name]
                    buckets = {}
                    for loop in sample.loops:
                        u = sample_uv.data[loop.index].uv
                        buckets.setdefault((round(u.x, 5), round(u.y, 5)), []).append(loop.index)
                    mapping = []
                    for loop in ref_mesh.loops:
                        u = target_uv.data[loop.index].uv
                        p = ref_mesh.vertices[loop.vertex_index].co
                        candidates = buckets.get((round(u.x, 5), round(u.y, 5)), ())
                        match = next((li for li in candidates if
                            (sample_uv.data[li].uv - u).length <= 2e-6 and
                            (sample.vertices[sample.loops[li].vertex_index].co - p).length <= tolerance), None)
                        if match is None:
                            break
                        candidates.remove(match)
                        mapping.append(sample.loops[match].vertex_index)
                    if len(mapping) != len(ref_mesh.loops):
                        continue
                    basis = [tuple(sample.vertices[i].co) for i in mapping]
                finally:
                    evaluated.to_mesh_clear()
                    evaluated = None
                maps = []
                for positions in map_vertices:
                    for vertex, p in zip(mesh.vertices, positions):
                        vertex.co = p
                    mesh.update()
                    bpy.context.view_layer.update()
                    evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
                    sample = evaluated.to_mesh()
                    try:
                        maps.append([tuple(sample.vertices[i].co) for i in mapping])
                    finally:
                        evaluated.to_mesh_clear()
                        evaluated = None
                return basis, maps
    finally:
        if evaluated is not None:
            evaluated.to_mesh_clear()
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        if mesh is not None:
            bpy.data.meshes.remove(mesh)
    return None


def _uv_seam_measure(measure, sampled_basis) -> dict:
    """Loops of one vertex on a UV seam land on the same point only when the seams are the saved ones."""
    uv_flat = measure['uv_flat']
    loop_vertex = measure['loop_vertex']
    islands = measure['islands']
    target_tris = measure['target_tris']
    tear = 0.02 * max(_position_span(sampled_basis), 1e-6)
    # A coarse mesh only follows the saved surface to about the size of its own faces.
    edge_sum = edge_count = 0
    for tri in target_tris:
        for loop_a, loop_b in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])):
            edge_sum += sum((x - y) ** 2 for x, y in zip(sampled_basis[loop_a], sampled_basis[loop_b])) ** 0.5
            edge_count += 1
    if edge_count:
        tear = max(tear, 0.5 * edge_sum / edge_count)
    by_vertex = {}
    for loop_index, vertex_index in enumerate(loop_vertex):
        by_vertex.setdefault(vertex_index, []).append(loop_index)
    seam_total = seam_torn = 0
    island_seams = {}
    island_torn = {}
    for loops in by_vertex.values():
        first = loops[0]
        if all(uv_flat[l * 2] == uv_flat[first * 2] and uv_flat[l * 2 + 1] == uv_flat[first * 2 + 1] for l in loops):
            continue
        seam_total += 1
        p0 = sampled_basis[first]
        torn = any(sum((a - b) ** 2 for a, b in zip(p0, sampled_basis[l])) > tear * tear for l in loops)
        if torn:
            seam_torn += 1
        for island in {islands[l] for l in loops}:
            island_seams[island] = island_seams.get(island, 0) + 1
            if torn:
                island_torn[island] = island_torn.get(island, 0) + 1
    least = max(_UV_MATCH_MIN_ISLAND_LOOPS, int(len(loop_vertex) * _UV_MATCH_MIN_ISLAND_SHARE))
    worst_island = 0.0
    for island, seams in island_seams.items():
        if seams >= _UV_MATCH_MIN_ISLAND_SEAMS and measure['island_sizes'][island] >= least:
            worst_island = max(worst_island, island_torn.get(island, 0) / seams)
    return {
        'seam_torn': seam_torn / seam_total if seam_total else 0.0,
        'island_torn': worst_island,
    }


def _saved_shape_matches_mesh(ref_mesh, uv_name: str, saved_uv_flat, saved_basis, tri_loop_indices) -> bool:
    """True when the saved surface, read through this mesh's UVs, is where this mesh already is."""
    sampler = _build_sampler_from_serialized(saved_uv_flat, saved_basis, tri_loop_indices)
    nloops = len(ref_mesh.loops)
    uv_flat = array('f', [0.0]) * (nloops * 2)
    ref_mesh.uv_layers[uv_name].data.foreach_get("uv", uv_flat)
    _pull_uvs_into_faces(ref_mesh, uv_flat)
    loop_vertex = [0] * nloops
    ref_mesh.loops.foreach_get("vertex_index", loop_vertex)
    size = max(_position_span(saved_basis), 1e-6)
    total = 0.0
    count = 0
    for li in range(0, nloops, max(1, nloops // 2000)):
        found = sampler.sample((uv_flat[li * 2], uv_flat[li * 2 + 1]))
        if found is None:
            return False
        distance = (Vector(ref_mesh.vertices[loop_vertex[li]].co) - found).length
        if distance > _UV_MATCH_SAME_SHAPE_MAX * size:
            return False
        total += distance
        count += 1
    return count > 0 and total / count <= _UV_MATCH_SAME_SHAPE_MEAN * size


def _fsync_directory(path: Path) -> None:
    if os.name == 'nt':
        return
    descriptor = None
    try:
        descriptor = os.open(str(path), os.O_RDONLY)
        os.fsync(descriptor)
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _atomic_write_map_file(filepath: str, blob: bytes) -> None:
    target = Path(filepath).expanduser()
    parent = target.parent
    if not parent.exists() or not parent.is_dir():
        raise RuntimeError(_t("The destination folder does not exist."))
    token = uuid.uuid4().hex
    temporary = parent / f".{target.name}.{token}.tmp"
    backup = parent / f".{target.name}.{token}.bak"
    backup_created = False
    replaced = False
    try:
        with open(temporary, 'xb') as handle:
            written = handle.write(blob)
            if written != len(blob):
                raise OSError("short write")
            handle.flush()
            os.fsync(handle.fileno())
        if temporary.read_bytes() != blob:
            raise OSError("temporary read-back mismatch")
        if target.exists():
            with open(target, 'rb') as source, open(backup, 'xb') as destination:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    destination.write(chunk)
                destination.flush()
                os.fsync(destination.fileno())
            backup_created = True
        os.replace(temporary, target)
        replaced = True
        _fsync_directory(parent)
        if target.read_bytes() != blob:
            raise OSError("destination read-back mismatch")
        if backup_created:
            backup.unlink(missing_ok=True)
            _fsync_directory(parent)
    except Exception:
        if replaced and backup_created and backup.exists():
            try:
                os.replace(backup, target)
                _fsync_directory(parent)
            except Exception:
                pass
        raise
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            backup.unlink(missing_ok=True)
        except Exception:
            pass


def _save_maps_to_file(operator, context, obj, filepath: str, selected_only: bool):
    items = _collect_maps_for_save(obj, selected_only)
    if not items:
        operator.report({'WARNING'}, _t("No maps were selected."))
        return {'CANCELLED'}
    try:
        blob = _serialize_to_bytes(obj, items)
        _atomic_write_map_file(filepath, blob)
    except Exception as exc:
        operator.report({'ERROR'}, _sss_translation.exception_text(exc, context))
        return {'CANCELLED'}
    operator.report({'INFO'}, _t("Done."))
    return {'FINISHED'}


class SKM_OT_save_file(ExportHelper, bpy.types.Operator):
    bl_idname = "skm.save_file"
    bl_label = _t("Save Map File")
    bl_description = _t("Save all maps to an external file.")
    bl_options = set()
    filename_ext = FILE_EXT

    filter_glob: bpy.props.StringProperty(
        default=f"*{FILE_EXT}", options={'HIDDEN'},
        description=_t("File browser filter that shows Smart Shapekey map files."),
    )
    selected_only: bpy.props.BoolProperty(
        default=False, options={'HIDDEN'},
        description=_t("When enabled, save only maps marked Select instead of every map."),
    )
    filepath: bpy.props.StringProperty(
        subtype="FILE_PATH",
        description=_t("External file path where Smart Shapekey map data is saved."),
    )

    @classmethod
    def description(cls, context, properties):
        del cls, context
        if bool(properties.selected_only):
            return _t("Save only maps with the Select checkbox enabled in the list.")
        return _t("Save all maps to an external file.")

    def invoke(self, context, event):
        self.filepath = _default_map_filepath()
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        filepath = str(self.filepath or '').strip()
        if not filepath:
            self.report({'WARNING'}, _t("Choose where to save the Smart Shapekey map file first."))
            return {'CANCELLED'}
        filepath = bpy.path.ensure_ext(filepath, FILE_EXT)
        if self.options.is_invoke and os.path.exists(filepath):
            # The file browser only marks an existing name in red and would replace the file at once.
            return bpy.ops.skm.save_overwrite('INVOKE_DEFAULT', filepath=filepath, selected_only=self.selected_only)
        return _save_maps_to_file(self, context, obj, filepath, self.selected_only)


class SKM_OT_save_overwrite(bpy.types.Operator):
    bl_idname = "skm.save_overwrite"
    bl_label = _t("Overwrite Map File")
    bl_description = _t("Replace the existing map file with the current maps.")
    bl_options = {'INTERNAL'}

    selected_only: bpy.props.BoolProperty(
        default=False, options={'HIDDEN'},
        description=_t("When enabled, save only maps marked Select instead of every map."),
    )
    filepath: bpy.props.StringProperty(
        subtype="FILE_PATH", options={'HIDDEN'},
        description=_t("External file path where Smart Shapekey map data is saved."),
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self, event,
            title=_t("Overwrite Map File"),
            message=_t("This file already exists: {name}").format(name=os.path.basename(self.filepath)),
            confirm_text=_t("Overwrite"),
            icon='ERROR',
        )

    def execute(self, context):
        obj = _context_mesh_object(context)
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        return _save_maps_to_file(self, context, obj, str(self.filepath), self.selected_only)


class SKM_OT_load_file(bpy.types.Operator):
    bl_idname = "skm.load_file"
    bl_label = _t("Load")
    bl_description = _t("Load maps from an external file. A popup lets you choose which maps to import.")
    bl_options = set()

    filter_glob: bpy.props.StringProperty(
        default=f"*{FILE_EXT}",
        options={'HIDDEN'},
        description=_t("File browser filter that shows Smart Shapekey map files."),
    )
    filepath: bpy.props.StringProperty(
        subtype="FILE_PATH",
        description=_t("External Smart Shapekey map file to load."),
    )

    def invoke(self, context, event):
        self.filepath = _default_map_filepath()
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        # After choosing file, open selection dialog operator
        filepath = str(self.filepath or '').strip()
        if not filepath:
            self.report({'WARNING'}, _t("Choose a Smart Shapekey map file first."))
            return {'CANCELLED'}
        return bpy.ops.skm.load_choose('INVOKE_DEFAULT', filepath=filepath)


class SKM_OT_load_choose(bpy.types.Operator):
    bl_idname = "skm.load_choose"
    bl_label = _t("Choose maps to import")
    bl_description = _t("Choose which maps to import from the file.")
    bl_options = {'UNDO'}

    filepath: bpy.props.StringProperty(
        subtype="FILE_PATH",
        description=_t("External Smart Shapekey map file currently being inspected for import."),
    )
    choices: bpy.props.CollectionProperty(
        type=SKM_LoadChoice,
        description=_t("Internal list of Smart Shapekey maps detected in the selected import file."),
    )
    select_all: bpy.props.BoolProperty(default=False, options={'HIDDEN'}, description=_t("Internal select-all state."))
    deselect_all: bpy.props.BoolProperty(default=False, options={'HIDDEN'}, description=_t("Internal deselect-all state."))

    _meta = None
    _floats = None

    _open_dialog = None

    def _clear_loaded_payload(self):
        self._meta = None
        self._floats = None
        type(self)._open_dialog = None

    def cancel(self, context):
        del context
        self._clear_loaded_payload()

    def _load(self):
        if self._meta is not None:
            return
        filepath = str(self.filepath or '').strip()
        if not filepath:
            raise ValueError(_t("Choose a Smart Shapekey map file first."))
        path = Path(filepath)
        if not path.is_file() or path.stat().st_size > _MAP_FILE_MAX_BYTES:
            raise RuntimeError(_t("Invalid file."))
        meta, floats = _deserialize_from_bytes(path.read_bytes())
        self._meta = meta
        self._floats = floats
        self.choices.clear()
        for map_data in meta["maps"]:
            choice = self.choices.add()
            choice.name = str(map_data["name"])
            choice.enabled = True

    def invoke(self, context, event):
        if not str(self.filepath or '').strip():
            self.report({'WARNING'}, _t("Choose a Smart Shapekey map file first."))
            return {'CANCELLED'}
        try:
            self._load()
        except Exception as exc:
            self._clear_loaded_payload()
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}
        type(self)._open_dialog = self
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        # File I/O and payload validation belong to invoke/execute only. Draw is
        # deliberately a pure read of the already validated operator snapshot.
        layout = self.layout
        if self._meta is None or self._floats is None:
            layout.label(text=_t("The selected map file is no longer available."), icon='ERROR')
            return
        row = layout.row(align=True)
        op = row.operator("skm.load_toggle_all", text=_t("Select All")); op.state = True
        op = row.operator("skm.load_toggle_all", text=_t("Deselect All")); op.state = False
        column = layout.column(align=True)
        for choice in self.choices:
            column.prop(choice, "enabled", text=choice.name, translate=False)

    def execute(self, context):
        return self._execute_impl(context)

    def _execute_impl(self, context):
        staged_mesh = None
        identity_plan = None
        try:
            obj = _context_mesh_object(context)
            if not obj or obj.type != 'MESH':
                return {'CANCELLED'}
            self._load()
            meta = self._meta
            floats = self._floats
            if meta is None or floats is None or len(self.choices) != len(meta["maps"]):
                raise RuntimeError(_t("Invalid file."))
            selected_indices = [index for index, choice in enumerate(self.choices) if bool(choice.enabled)]
            if not selected_indices:
                raise RuntimeError(_t("Select at least one map to import."))

            nloops = int(meta["nloops"])
            saved_uv_flat = array('f', floats[0:nloops * 2])
            cursor = nloops * 2
            saved_basis, cursor = _decode_position_block(floats, cursor, nloops)
            saved_maps = []
            for _map_data in meta["maps"]:
                positions, cursor = _decode_position_block(floats, cursor, nloops)
                saved_maps.append(positions)
            if cursor != len(floats):
                raise RuntimeError(_t("Invalid file."))

            target_mesh = obj.data
            target_uv_layers = getattr(target_mesh, 'uv_layers', None)
            target_uv_name = str(meta.get('uv_name') or '')
            if target_uv_layers is None or target_uv_layers.get(target_uv_name) is None:
                target_uv_name = _get_mapping_uv_name(obj)
            if not target_uv_name or target_uv_layers is None or target_uv_layers.get(target_uv_name) is None:
                raise RuntimeError(_t("No UV layers found."))

            identity_plan = _plan_source_identity(obj)
            identity = identity_plan['identity']
            if str(getattr(obj, 'mode', 'OBJECT')) == 'EDIT':
                obj.update_from_editmode()
            staged_mesh = _copy_mesh_data_block(target_mesh, f".__SKM_STAGE_MESH_{uuid.uuid4().hex}")
            _sss_ownership.mark_temporary(staged_mesh, identity)
            triangles = meta.get('tri_loop_indices')
            if len(staged_mesh.loops) == nloops and _map_file_matches_loops(staged_mesh, saved_basis, triangles):
                basis_positions = saved_basis
                map_positions = saved_maps
            else:
                if not triangles:
                    raise RuntimeError(_t("This map file cannot be rebuilt on a different topology."))
                layout_differs = _t("The UV layout of this mesh differs from the map file, so the shape would break. Nothing was loaded. Give the mesh the same UV layout, then load again.")
                # The checks that need only UVs go first: a mismatch is reported before the slow position lookup.
                if _saved_uv_overlap_share(saved_uv_flat, triangles, saved_basis) > _UV_MATCH_MAX_OVERLAP:
                    raise RuntimeError(_t("The saved mesh has overlapping UVs, so positions cannot be read from them on a different vertex layout. Nothing was loaded. Save from a mesh without overlapping UVs, or load onto a mesh with the same vertex layout."))
                measure = _uv_layout_measure(staged_mesh, target_uv_name, saved_uv_flat, triangles)
                if measure['target_outside'] > _UV_MATCH_MAX_OUTSIDE or measure['island_outside'] > _UV_MATCH_MAX_ISLAND_OUTSIDE:
                    raise RuntimeError(layout_differs)
                # Saved UVs the mesh does not reach are expected on a part of the saved mesh, but then the mesh stands where the saved surface is.
                if measure['saved_outside'] > _UV_MATCH_MAX_OUTSIDE and not _saved_shape_matches_mesh(
                    staged_mesh, target_uv_name, saved_uv_flat, saved_basis, triangles
                ):
                    raise RuntimeError(layout_differs)
                basis_positions = _sample_serialized_positions_to_ref_mesh(
                    staged_mesh, target_uv_name, saved_uv_flat, saved_basis, triangles
                )
                # A small displaced island or a near-identical UV scale can pass
                # overlap/mean checks yet move a whole piece. A median ignores the few
                # corners on sliver triangles and the centres of non-flat faces, which
                # move on a correct subdivided mesh too.
                size = max(_position_span(saved_basis), 1e-6)
                shifts = [
                    (Vector(staged_mesh.vertices[loop.vertex_index].co) - Vector(position)).length / size
                    for loop, position in zip(staged_mesh.loops, basis_positions)
                ]
                by_island = {}
                for loop_index, island in enumerate(measure['islands']):
                    by_island.setdefault(island, []).append(shifts[loop_index])
                shift_mismatch = bool(shifts and _median(shifts) > _UV_MATCH_MAX_SHIFT)
                shift_mismatch |= any(_median(values) > _UV_MATCH_MAX_ISLAND_SHIFT for values in by_island.values() if len(values) >= 8)
                # A minority of warped loops can leave both medians unchanged.
                # Normal displacement is expected when subdividing a non-planar
                # face; tangential displacement changes its UV correspondence.
                # A corner on a sliver triangle can read far off on a correct mesh,
                # so a vertex counts only when all of its corners are off. Even
                # one such vertex requires subdivision proof: a percentage
                # allowance also admits an isolated, genuinely warped UV.
                tangent_ok = set()
                tangent_off = set()
                for loop, position in zip(staged_mesh.loops, basis_positions):
                    vertex = staged_mesh.vertices[loop.vertex_index]
                    delta = Vector(vertex.co) - Vector(position)
                    normal = Vector(vertex.normal).normalized()
                    tangent = delta - normal * delta.dot(normal)
                    (tangent_off if tangent.length > 0.015 * size else tangent_ok).add(loop.vertex_index)
                far_off = tangent_off - tangent_ok
                if far_off:
                    shift_mismatch = True
                seams = _uv_seam_measure(measure, basis_positions)
                shift_mismatch |= seams['seam_torn'] > _UV_MATCH_MAX_TORN or seams['island_torn'] > _UV_MATCH_MAX_ISLAND_TORN
                # Prefer the exact result even when a shallow curve passes the
                # medians. UV triangle interpolation otherwise flattens its
                # non-planar faces and can move a valid subdivided Basis.
                proof = _match_exact_subdivision(staged_mesh, target_uv_name, saved_uv_flat, saved_basis, triangles, saved_maps)
                if proof is not None:
                    basis_positions, map_positions = proof
                elif shift_mismatch:
                    raise RuntimeError(layout_differs)
                else:
                    # Different topology keeps its own Basis. Transfer deformation,
                    # not absolute positions that flatten non-planar subdivided faces.
                    basis_positions = [tuple(staged_mesh.vertices[loop.vertex_index].co) for loop in staged_mesh.loops]
                    map_positions = []
                    for positions in saved_maps:
                        deltas = [tuple(p[i] - base[i] for i in range(3)) for p, base in zip(positions, saved_basis)]
                        sampled = _sample_serialized_positions_to_ref_mesh(
                            staged_mesh, target_uv_name, saved_uv_flat, deltas, triangles,
                            evaluate_original_uv=True,
                        )
                        map_positions.append([tuple(base[i] + delta[i] for i in range(3)) for base, delta in zip(basis_positions, sampled)])

            base_a, base_b = _ensure_storage_layers(staged_mesh, BASE_ID)
            _encode_positions_to_uv_layers(staged_mesh, base_a, base_b, basis_positions)
            rows = [{
                'name': BASIS_NAME,
                'prev_name': BASIS_NAME,
                'chn_id': BASE_ID,
                'selected': False,
                'locked': True,
            }]
            used_names = {BASIS_NAME}
            next_channel = BASE_ID - 1
            for index in selected_indices:
                while next_channel > 0 and any(row['chn_id'] == next_channel for row in rows):
                    next_channel -= 1
                if next_channel <= 0:
                    raise RuntimeError(_t("No free map channel remains."))
                name = _unique_map_name(meta["maps"][index]["name"], used_names, preserve_raw=True)
                used_names.add(name)
                channel = next_channel
                next_channel -= 1
                layer_a, layer_b = _ensure_storage_layers(staged_mesh, channel)
                _encode_positions_to_uv_layers(staged_mesh, layer_a, layer_b, map_positions[index])
                rows.append({
                    'name': name,
                    'prev_name': name,
                    'chn_id': channel,
                    'selected': False,
                    'locked': False,
                })
            loaded_basis = _mm_positions(staged_mesh, BASE_ID)
            _commit_reference_state(obj, staged_mesh, rows, target_uv_name, 0, identity_plan)
            staged_mesh = None
            identity_plan = None
            # The Basis row is active now. The mesh must show the loaded Basis, or the next map switch
            # stores the old shape over it.
            obj[OBJ_PROP_ACTIVE_CHANNEL] = BASE_ID
            _mm_apply_live_coordinates(obj, loaded_basis)
            _mm_sync_shape_key_preview(obj, channel=BASE_ID)
            self._clear_loaded_payload()
            return {'FINISHED'}
        except Exception as exc:
            if staged_mesh is not None:
                _discard_staged_mesh(staged_mesh)
            if identity_plan is not None:
                _rollback_source_identity_plan(identity_plan)
            self.report({'ERROR'}, _sss_translation.exception_text(exc, context))
            return {'CANCELLED'}


class SKM_OT_load_toggle_all(bpy.types.Operator):
    bl_idname = "skm.load_toggle_all"
    bl_label = _t("Toggle All")
    bl_description = _t("Enable or disable every map entry in the current import selection dialog.")
    bl_options = {'INTERNAL'}

    state: bpy.props.BoolProperty(
        default=True,
        description=_t("Target checked state applied to all map import choices."),
    )

    def execute(self, context):
        dialog = SKM_OT_load_choose._open_dialog
        if dialog is None:
            return {'CANCELLED'}
        try:
            for choice in dialog.choices:
                choice.enabled = bool(self.state)
        except ReferenceError:
            SKM_OT_load_choose._open_dialog = None
            return {'CANCELLED'}
        for area in context.window.screen.areas if context.window is not None else ():
            area.tag_redraw()
        return {'FINISHED'}


# Cleanup
def _cleanup_orphans_for_object(obj: bpy.types.Object):
    """Remove only obsolete UV layers inside this object's exact owned ref graph."""
    ref_mesh = _get_ref_mesh(obj)
    if not ref_mesh:
        return 0
    valid = set()
    for it in obj.skm_maps:
        valid.add(_uv_store_name_a(it.chn_id))
        valid.add(_uv_store_name_b(it.chn_id))
    removed = 0
    for uv in tuple(ref_mesh.uv_layers):
        if uv.name.startswith(PREFIX) and uv.name not in valid:
            try:
                ref_mesh.uv_layers.remove(uv)
                removed += 1
            except Exception:
                pass
    return removed


class SKM_OT_clean_orphans(bpy.types.Operator):
    bl_idname = "skm.clean_orphans"
    bl_label = _t("Clean Orphans")
    bl_description = _t("Remove unused internal map layers from this add-on's reference data.")
    bl_options = {'UNDO'}

    scene_wide: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'},
        description=_t("When enabled, clean this add-on's reference data in the current scene."),
    )

    def execute(self, context):
        targets = tuple(context.scene.objects) if self.scene_wide else (_context_mesh_object(context),)
        for obj in targets:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                continue
            if _find_existing_ref_for_object(obj) is not None:
                _cleanup_orphans_for_object(obj)
        return {'FINISHED'}


class SKM_OT_full_cleanup(bpy.types.Operator):
    bl_idname = "skm.full_cleanup"
    bl_label = _t("Full Cleanup")
    bl_description = _t("Delete all map data of the selected object.")
    bl_options = {'UNDO'}

    scene_wide: bpy.props.BoolProperty(
        default=False,
        options={'HIDDEN'},
        description=_t("When enabled, remove this add-on's reference data in the current scene."),
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        targets = tuple(context.scene.objects) if self.scene_wide else (_context_mesh_object(context),)
        for obj in targets:
            if obj is None or getattr(obj, 'type', None) != 'MESH':
                continue
            # A same-name Object/custom property is foreign unless the complete
            # owner UUID/source UUID/file+session generation/schema graph matches.
            if _find_existing_ref_for_object(obj) is None:
                # The rows and the preview key are the object's own even when
                # its reference is gone, for example on a duplicated object.
                if len(getattr(obj, 'skm_maps', ())) or getattr(getattr(getattr(obj.data, 'shape_keys', None), 'key_blocks', None), 'get', lambda _name: None)(MM_PREVIEW_KEY_NAME) is not None:
                    _replace_map_rows(obj, [], -1)
                    _mm_sync_shape_key_preview(obj)
                continue
            state = _snapshot_source_map_state(obj)
            try:
                if hasattr(obj, 'skm_maps'):
                    _replace_map_rows(obj, [], -1)
                removed = _remove_ref_object(obj)
                _mm_sync_shape_key_preview(obj)
                if not removed:
                    _restore_source_map_state(obj, state)
                    continue
                try:
                    if OBJ_PROP_UV in obj:
                        del obj[OBJ_PROP_UV]
                except Exception:
                    pass
            except Exception:
                _restore_source_map_state(obj, state)
                raise
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# UI Panel (stylish, compact, narrow-friendly)
# -----------------------------------------------------------------------------
_UV_ENUM_ITEMS_CACHE: "OrderedDict[object, tuple]" = OrderedDict()
_UV_ENUM_ITEMS_CACHE_MAX = 256


def _cached_uv_enum_items(key, builder):
    cached = _UV_ENUM_ITEMS_CACHE.get(key)
    if cached is not None:
        _UV_ENUM_ITEMS_CACHE.move_to_end(key)
        return cached
    items = tuple(builder())
    _UV_ENUM_ITEMS_CACHE[key] = items
    _UV_ENUM_ITEMS_CACHE.move_to_end(key)
    while len(_UV_ENUM_ITEMS_CACHE) > _UV_ENUM_ITEMS_CACHE_MAX:
        _UV_ENUM_ITEMS_CACHE.popitem(last=False)
    return items


def _uv_items(self, context):
    # Blender keeps C-side references to dynamic EnumProperty item strings while
    # drawing the UI. Returning freshly-created strings on every callback can
    # leave dangling text pointers, which shows up as mojibake in the UV map
    # dropdown and can destabilize the panel handler. Cache each item tuple so
    # the identifier/name/description strings remain alive for the session.
    obj = self if getattr(self, "type", None) == 'MESH' else _context_mesh_object(context)
    none_label = str(_t("None"))
    none_key = ("NONE", none_label)
    if not obj or getattr(obj, "type", None) != 'MESH' or not getattr(obj, "data", None):
        return _cached_uv_enum_items(none_key, lambda: [("NONE", none_label, "")])
    uvs = getattr(obj.data, 'uv_layers', None)
    if not uvs or len(uvs) == 0:
        return _cached_uv_enum_items(none_key, lambda: [("NONE", none_label, "")])

    names = tuple(str(getattr(uv, 'name', '') or '') for uv in uvs if str(getattr(uv, 'name', '') or ''))
    if not names:
        return _cached_uv_enum_items(none_key, lambda: [("NONE", none_label, "")])
    return _cached_uv_enum_items(("UV", names), lambda: [(name, name, "") for name in names])


# -----------------------------------------------------------------------------
# Standard 3D View N-panel integration
# -----------------------------------------------------------------------------
_SKM_ADDON_KEY = "smart_shapekey_suite"
_SKM_TAB_LABEL = "Smart Shapekey"
_SKM_TAB_TOOLTIP = _t("Show the Smart Shapekey controls in the 3D View N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data.")


def _is_view3d_npanel_context(context) -> bool:
    area = getattr(context, 'area', None)
    if area is None:
        return True
    try:
        return str(getattr(area, 'type', '') or '') in _SKM_NPANEL_SPACE_TYPES
    except Exception:
        return False


def _view3d_npanel_active(context):
    return _is_view3d_npanel_context(context)


def _set_view3d_npanel_active(context, active: bool):
    del context, active
    return None


def _show_npanel(context, reuse_existing=True):
    context = context or bpy.context
    area = context.area
    if area is None and reuse_existing and context.screen is not None:
        area = next((item for item in context.screen.areas if item.type == 'VIEW_3D'), None)
    if area is None or area.type not in _SKM_NPANEL_SPACE_TYPES:
        return False
    space = area.spaces.active
    if not hasattr(space, 'show_region_ui'):
        return False
    space.show_region_ui = True
    area.tag_redraw()
    address = area.as_pointer()
    space_type = area.type
    attempts = 0

    def select_tab():
        nonlocal attempts
        if not is_runtime_registered():
            return None
        for window in bpy.context.window_manager.windows:
            for current in window.screen.areas:
                if current.as_pointer() != address or current.type != space_type:
                    continue
                if not current.spaces.active.show_region_ui:
                    return None
                region = next((item for item in current.regions if item.type == 'UI'), None)
                if region is not None:
                    try:
                        region.active_panel_category = _SKM_TAB_LABEL
                        if region.active_panel_category == _SKM_TAB_LABEL:
                            current.tag_redraw()
                            return None
                    except (AttributeError, RuntimeError, TypeError, ValueError):
                        pass
                attempts += 1
                return 0.1 if attempts < 5 else None
        return None

    if select_tab() is not None:
        bpy.app.timers.register(select_tab, first_interval=0.1)
    return True



# -----------------------------------------------------------------------------
# Always-on feature toggles
# -----------------------------------------------------------------------------
def _import_optional_module(relative_name: str):
    try:
        import importlib
        package = str(__package__ or '').strip()
        return importlib.import_module(relative_name, package=package)
    except Exception:
        return None



def _axis_ui_available(context) -> bool:
    try:
        if bool(getattr(getattr(bpy, 'app', None), 'background', False)):
            return False
        ctx = context or getattr(bpy, 'context', None)
        obj = getattr(ctx, 'active_object', None) if ctx is not None else None
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            return False
        if not bool(getattr(bpy.ops, 'shape_xy', None) and hasattr(bpy.ops.shape_xy, 'ui_joystick')):
            return False

        area = getattr(ctx, 'area', None)
        if getattr(area, 'type', None) == 'VIEW_3D':
            return True

        wm = getattr(ctx, 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                if getattr(area, 'type', None) == 'VIEW_3D':
                    for region in tuple(getattr(area, 'regions', ()) or ()):
                        if getattr(region, 'type', None) == 'WINDOW':
                            return True
        return False
    except Exception:
        return False


def _axis_hud_running() -> bool:
    module = _import_optional_module('.axis_control.core.state')
    state_dict = getattr(module, 'HUD_STATE', {}) if module is not None else {}
    try:
        return bool(state_dict.get('running', False) or state_dict.get('handle'))
    except Exception:
        return False


def _set_axis_hud_enabled(context, enabled: bool) -> bool:
    operators_module = _import_optional_module('.axis_control.operators.main')
    if bool(enabled) == _axis_hud_running():
        return True
    if enabled:
        if not _axis_ui_available(context or getattr(bpy, 'context', None)):
            return False
        try:
            result = bpy.ops.shape_xy.ui_joystick('INVOKE_DEFAULT')
            return 'CANCELLED' not in set(result or ())
        except Exception:
            return False
    stop_fn = getattr(operators_module, '_stop_hud_now', None) if operators_module is not None else None
    if callable(stop_fn):
        try:
            stop_fn(context)
            return True
        except Exception:
            pass
    try:
        if _axis_hud_running():
            bpy.ops.shape_xy.ui_joystick('INVOKE_DEFAULT')
        return True
    except Exception:
        return False


def _frame_sync_running(scene=None) -> bool:
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return False
    try:
        return bool(getattr(scene, 'shape_xy_enable_frame_sync', False))
    except Exception:
        return False


def _set_frame_sync_enabled(scene, enabled: bool) -> bool:
    module = _import_optional_module('.axis_control')
    setter = getattr(module, 'set_frame_sync_enabled', None) if module is not None else None
    if callable(setter):
        try:
            return bool(setter(bool(enabled), scene=scene))
        except Exception:
            pass
    try:
        setattr(scene, 'shape_xy_enable_frame_sync', bool(enabled))
        return True
    except Exception:
        return False


def _axis_drag_enabled(scene=None) -> bool:
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return False
    try:
        return bool(getattr(scene, 'shape_xy_allow_drag', False))
    except Exception:
        return False


def _set_axis_drag_enabled(scene, enabled: bool) -> bool:
    try:
        setattr(scene, 'shape_xy_allow_drag', bool(enabled))
        return True
    except Exception:
        return False


def _external_tracker_running() -> bool:
    module = _import_optional_module('.axis_control.interface.tracker')
    checker = getattr(module, 'is_tracker_running', None) if module is not None else None
    if callable(checker):
        try:
            return bool(checker())
        except Exception:
            return False
    try:
        return bool(getattr(module, 'TRACKER_RUNNING', False)) if module is not None else False
    except Exception:
        return False


def _set_external_tracker_enabled(scene, enabled: bool) -> bool:
    module = _import_optional_module('.axis_control.interface.tracker')
    if module is None:
        return False
    if bool(enabled) == _external_tracker_running():
        return True
    try:
        if enabled:
            port = int(getattr(scene, 'shape_xy_tracker_port', 5000)) if scene is not None else 5000
            result = getattr(module, 'start_tracker')(port)
            return bool(result) if result is not None else _external_tracker_running()
        else:
            getattr(module, 'stop_tracker')()
        return True
    except Exception:
        return False


def _face_tracker_running() -> bool:
    module = _import_optional_module('.axis_control.face_tracker.core')
    try:
        return bool(getattr(module, 'TRACKER_RUNNING', False)) if module is not None else False
    except Exception:
        return False


def _set_face_tracker_enabled(scene, enabled: bool) -> bool:
    module = _import_optional_module('.axis_control.face_tracker.core')
    if module is None:
        return False
    if bool(enabled) == _face_tracker_running():
        return True
    try:
        if enabled:
            installer = _import_optional_module('.axis_control.face_tracker.installer')
            check_dependencies = getattr(installer, 'check_dependencies', None) if installer is not None else None
            if callable(check_dependencies) and not check_dependencies():
                return False
            cam_index = int(getattr(scene, 'tracker_cam_index', 0)) if scene is not None else 0
            result = getattr(module, 'start_tracker')(cam_index)
            return bool(result) if result is not None else _face_tracker_running()
        else:
            getattr(module, 'stop_tracker')()
        return True
    except Exception:
        return False


def _face_tracker_hud_enabled(scene=None) -> bool:
    scene = scene or getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        return False
    try:
        return bool(getattr(scene, 'tracker_show_hud', False))
    except Exception:
        return False


def _set_face_tracker_hud_enabled(scene, enabled: bool) -> bool:
    try:
        setattr(scene, 'tracker_show_hud', bool(enabled))
    except Exception:
        return False
    module = _import_optional_module('.axis_control.face_tracker.draw_hud')
    sync = getattr(module, 'sync_hud_handler', None) if module is not None else None
    if callable(sync):
        try:
            sync(scene)
        except Exception:
            pass
    return True


def _always_on_status(target: str, scene=None) -> bool:
    if target == 'AXIS_UI':
        return _axis_hud_running()
    if target == 'FRAME_SYNC':
        return _frame_sync_running(scene)
    if target == 'EXTERNAL_TRACKER':
        return _external_tracker_running()
    if target == 'FACE_TRACKER':
        return _face_tracker_running()
    if target == 'FACE_TRACKER_HUD':
        return _face_tracker_hud_enabled(scene)
    return False


def _set_always_on_status(target: str, scene, context, enabled: bool) -> bool:
    if target == 'AXIS_UI':
        return _set_axis_hud_enabled(context, enabled)
    if target == 'FRAME_SYNC':
        return _set_frame_sync_enabled(scene, enabled)
    if target == 'EXTERNAL_TRACKER':
        return _set_external_tracker_enabled(scene, enabled)
    if target == 'FACE_TRACKER':
        return _set_face_tracker_enabled(scene, enabled)
    if target == 'FACE_TRACKER_HUD':
        return _set_face_tracker_hud_enabled(scene, enabled)
    return False




# Window-manager backed UI state. Stored in JSON through update callbacks so it
# is available across restarts and across opened scenes.
def _sync_setting_to_runtime(setting_key: str, context=None, *, force: bool = False, startup_restore: bool = False) -> bool:
    settings = _suite_settings(context)
    if settings is None or not hasattr(settings, setting_key):
        return False
    scene = getattr(context, 'scene', None) if context is not None else getattr(getattr(bpy, 'context', None), 'scene', None)
    enabled = bool(getattr(settings, setting_key, False))
    target = {
        'always_axis_ui_enabled': 'AXIS_UI',
        'always_frame_sync_enabled': 'FRAME_SYNC',
        'always_external_tracker_enabled': 'EXTERNAL_TRACKER',
        'always_face_tracker_enabled': 'FACE_TRACKER',
        'always_face_tracker_hud_enabled': 'FACE_TRACKER_HUD',
    }.get(setting_key)
    if not target:
        return True
    try:
        # At a load-post/register boundary the new Scene and runtime generation
        # already exist.  Resume the Axis HUD only when the saved toggle is ON
        # and a real 3D View is available; its operator performs the exact
        # context override and generation-owned draw registration.
        if target == 'AXIS_UI' and enabled and not _axis_ui_available(context or bpy.context):
            return True
        # For disabled entries, always enforce a real stop so timers, handlers,
        # sockets, modal operators, and draw handlers do not remain active.
        # For enabled entries, start only the selected runtime feature.
        ok = _set_always_on_status(target, scene, context or bpy.context, enabled)
    except Exception:
        ok = False
    if ok or force:
        return bool(ok)

    if enabled:
        # A load/register restore must never rewrite a validated user setting
        # merely because a transient camera, socket, or editor context was not
        # available.  Preserve the saved ON value and report the start failure
        # once.  A direct user toggle may be reverted to OFF because that
        # interaction explicitly requested an immediate runtime transition.
        _notify_runtime_issue_once(
            f"feature_start:{setting_key}",
            _t('The requested runtime feature could not be started. The saved setting was kept unchanged.')
            if startup_restore else
            _t('The requested runtime feature could not be started and was returned to Off.'),
            context,
        )
        if startup_restore:
            return False
        global _SKM_RESTORING_SETTINGS
        _SKM_RESTORING_SETTINGS = True
        try:
            _set_property_safely(settings, setting_key, False)
        finally:
            _SKM_RESTORING_SETTINGS = False
        save_persistent_setting(setting_key, False)
        _tag_view3d_redraw(context)
    return False


def _sync_all_always_on_settings(context=None) -> None:
    for key in (
        'always_frame_sync_enabled',
        'always_external_tracker_enabled',
        'always_face_tracker_enabled',
        'always_face_tracker_hud_enabled',
        'always_axis_ui_enabled',
    ):
        _sync_setting_to_runtime(key, context, force=False, startup_restore=True)


def _on_n_panel_state_save_update(self, context):
    global _SKM_SETTINGS_PENDING
    if _SKM_RESTORING_SETTINGS:
        return
    live_state = _live_persistence_owner_state(self, context)
    if live_state is None:
        return
    owner_key, enabled = live_state
    if enabled:
        if not _SKM_WRITE_BARRIER.enable(owner_key=owner_key, owner_enabled=True):
            return
        try:
            _save_current_panel_settings(context if context is not None else getattr(bpy, 'context', None))
        except Exception:
            pass
    else:
        opened = _SKM_WRITE_BARRIER.begin_disable_commit(
            owner_key=owner_key, owner_enabled=False,
        )
        if not opened:
            return
        try:
            _save_current_panel_settings(
                context if context is not None else getattr(bpy, 'context', None),
                write_reason="off_self_commit",
                write_owner_key=owner_key,
                write_owner_enabled=False,
            )
        except Exception:
            _notify_settings_issue_once(context)
        finally:
            _SKM_SETTINGS_PENDING = None
            _SKM_WRITE_BARRIER.finish_disable(owner_key=owner_key)
    _tag_view3d_redraw(context)


def _make_setting_update(setting_key: str):
    def _update(self, context):
        if _SKM_RESTORING_SETTINGS:
            return
        value = bool(getattr(self, setting_key, False))
        save_persistent_setting(setting_key, value)
        if setting_key != 'show_always_on_toggles':
            _sync_setting_to_runtime(setting_key, context, force=False)
        _tag_view3d_redraw(context)
    return _update


class SKM_PG_suite_settings(bpy.types.PropertyGroup):
    n_panel_state_save_enabled: bpy.props.BoolProperty(
        name=_t('N-panel State Save'),
        description=_t('When enabled, every Smart Shapekey N-panel setting change is saved immediately to the Blender config JSON. Turning it off saves that Off state once; all later writers remain blocked until it is enabled again.'),
        default=True,
        update=_on_n_panel_state_save_update,
    )
    show_always_on_toggles: bpy.props.BoolProperty(
        name=_t('Always-on Features'),
        description=_t('Open or close the Always-on Features group at the top of the N-panel. It is closed by default.'),
        default=False,
        update=_make_setting_update('show_always_on_toggles'),
    )
    always_axis_ui_enabled: bpy.props.BoolProperty(
        name=_t('Axis UI'),
        description=_t('Start or stop the interactive 2D HUD Axis controller in the 3D Viewport. Disable it when you are not editing joystick values so Blender does not keep a modal viewport tool running.'),
        default=False,
        update=_make_setting_update('always_axis_ui_enabled'),
    )
    always_frame_sync_enabled: bpy.props.BoolProperty(
        name=_t('Frame Sync'),
        description=_t('Enable or disable the frame-change handler that updates Shape Axis handles during timeline playback and scrubbing. Keep it off unless animated joystick values need to follow the current frame.'),
        default=False,
        update=_make_setting_update('always_frame_sync_enabled'),
    )
    always_external_tracker_enabled: bpy.props.BoolProperty(
        name=_t('External Tracker (UDP)'),
        description=_t('Start or stop the UDP listener that receives joystick values from an external tracking app. Enable it only while a sender is running and the port setting matches the sender.'),
        default=False,
        update=_make_setting_update('always_external_tracker_enabled'),
    )
    always_face_tracker_enabled: bpy.props.BoolProperty(
        name=_t('Face Tracker (Built-In)'),
        description=_t('Start or stop the built-in webcam face tracker. Enable it only while capturing live facial motion because it keeps a camera thread and Blender update timer active.'),
        default=False,
        update=_make_setting_update('always_face_tracker_enabled'),
    )
    always_face_tracker_hud_enabled: bpy.props.BoolProperty(
        name=_t('Face Tracker Point HUD'),
        description=_t('Enable or disable the face-tracker landmark overlay in the 3D View. The overlay is drawn only while the built-in Face Tracker is running.'),
        default=False,
        update=_make_setting_update('always_face_tracker_hud_enabled'),
    )


def _always_on_target_description(target: str) -> str:
    if target == 'N_PANEL_STATE_SAVE':
        return _t('When enabled, every Smart Shapekey N-panel setting change is saved immediately to the Blender config JSON. Turning it off saves that Off state once; all later writers remain blocked until it is enabled again.')
    if target == 'AXIS_UI':
        return _t('Start or stop the interactive 2D HUD Axis controller in the 3D Viewport. Disable it when you are not editing joystick values so Blender does not keep a modal viewport tool running.')
    if target == 'FRAME_SYNC':
        return _t('Enable or disable the frame-change handler that updates Shape Axis handles during timeline playback and scrubbing. Keep it off unless animated joystick values need to follow the current frame.')
    if target == 'EXTERNAL_TRACKER':
        return _t('Start or stop the UDP listener that receives joystick values from an external tracking app. Enable it only while a sender is running and the port setting matches the sender.')
    if target == 'FACE_TRACKER':
        return _t('Start or stop the built-in webcam face tracker. Enable it only while capturing live facial motion because it keeps a camera thread and Blender update timer active.')
    if target == 'FACE_TRACKER_HUD':
        return _t('Enable or disable the face-tracker landmark overlay in the 3D View. The overlay is drawn only while the built-in Face Tracker is running.')
    return _t('Enable or disable a long-running Smart Shapekey feature from the unified Always-on Features group.')


def _always_on_items(context):
    scene = getattr(context, 'scene', None)
    settings = _suite_settings(context)
    return (
        {
            'target': 'N_PANEL_STATE_SAVE',
            'prop': 'n_panel_state_save_enabled',
            'label': _t('N-panel State Save'),
            'description': _always_on_target_description('N_PANEL_STATE_SAVE'),
            'available': settings is not None,
            'enabled': bool(getattr(settings, 'n_panel_state_save_enabled', True)) if settings is not None else True,
        },
        {
            'target': 'AXIS_UI',
            'prop': 'always_axis_ui_enabled',
            'label': _t('Axis UI'),
            'description': _always_on_target_description('AXIS_UI'),
            'available': settings is not None,
            'enabled': bool(getattr(settings, 'always_axis_ui_enabled', False)) if settings is not None else False,
        },
        {
            'target': 'FRAME_SYNC',
            'prop': 'always_frame_sync_enabled',
            'label': _t('Frame Sync'),
            'description': _always_on_target_description('FRAME_SYNC'),
            'available': settings is not None and scene is not None and hasattr(scene, 'shape_xy_enable_frame_sync'),
            'enabled': bool(getattr(settings, 'always_frame_sync_enabled', False)) if settings is not None else False,
        },
        {
            'target': 'EXTERNAL_TRACKER',
            'prop': 'always_external_tracker_enabled',
            'label': _t('External Tracker (UDP)'),
            'description': _always_on_target_description('EXTERNAL_TRACKER'),
            'available': settings is not None,
            'enabled': bool(getattr(settings, 'always_external_tracker_enabled', False)) if settings is not None else False,
        },
        {
            'target': 'FACE_TRACKER',
            'prop': 'always_face_tracker_enabled',
            'label': _t('Face Tracker (Built-In)'),
            'description': _always_on_target_description('FACE_TRACKER'),
            'available': settings is not None,
            'enabled': bool(getattr(settings, 'always_face_tracker_enabled', False)) if settings is not None else False,
        },
        {
            'target': 'FACE_TRACKER_HUD',
            'prop': 'always_face_tracker_hud_enabled',
            'label': _t('Face Tracker Point HUD'),
            'description': _always_on_target_description('FACE_TRACKER_HUD'),
            'available': settings is not None and scene is not None and hasattr(scene, 'tracker_show_hud'),
            'enabled': bool(getattr(settings, 'always_face_tracker_hud_enabled', False)) if settings is not None else False,
        },
    )


def _always_on_state_text(enabled) -> str:
    # 常時の行の状態の文字。訳が付く言語（日本語など）は今までどおり Enabled／Disabled の訳、
    # 訳が付かない時（英語）は右の欄に収まる On／Off にする。
    msgid = 'Enabled' if enabled else 'Disabled'
    text = _t(msgid)
    if text == msgid:
        return 'On' if enabled else 'Off'
    return text


def _draw_always_on_toggle_controls(layout, context):
    settings = _suite_settings(context)
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    if settings is None:
        col.label(text=_t('Scene settings are not available.'), icon='ERROR')
        return

    for item in _always_on_items(context):
        prop = str(item.get('prop') or '')
        if not prop or not hasattr(settings, prop):
            enabled = bool(item.get('enabled', False))
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            left = split.row(align=True)
            left.label(text=str(item.get('label') or ''))
            right = split.row(align=True)
            right.use_property_split = False
            right.use_property_decorate = False
            right.alignment = 'RIGHT'
            holder = right.row(align=True)
            holder.enabled = False
            holder.label(
                text=_always_on_state_text(enabled),
                icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            )
            continue
        enabled = bool(getattr(settings, prop, False))
        row = col.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        # Row explanations are intentionally kept in the BoolProperty tooltip;
        # the visible row contains only the feature name and the state button.
        left.label(text=str(item.get('label') or ''))
        right = split.row(align=True)
        right.use_property_split = False
        right.use_property_decorate = False
        right.alignment = 'RIGHT'
        right.row(align=True).prop(
            settings,
            prop,
            text=_always_on_state_text(enabled),
            icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
            toggle=True,
        )
        if prop == 'n_panel_state_save_enabled':
            try:
                col.separator(factor=0.5)
            except Exception:
                pass



def _icon_value(name: str | None) -> int:
    try:
        if _sss_icons is not None:
            return int(_sss_icons.icon_value(name) or 0)
    except Exception:
        pass
    return 0


def _icon_op(layout, operator_id: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    effective_emboss = True if (str(text or '') == '' and (icon_name or str(fallback or 'NONE').upper() != 'NONE')) else bool(emboss)
    try:
        if _sss_icons is not None:
            return _sss_icons.operator(layout, operator_id, text=text, icon_name=icon_name, fallback=fallback, emboss=effective_emboss, **kwargs)
    except Exception:
        pass
    attempts = (
        lambda: layout.operator(operator_id, text=text, icon=fallback, emboss=effective_emboss, **kwargs),
        lambda: layout.operator(operator_id, text=text, icon=fallback, **kwargs),
        lambda: layout.operator(operator_id, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.operator(operator_id, text=text)


def _icon_label(layout, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE'):
    try:
        if _sss_icons is not None:
            return _sss_icons.label(layout, text=text, icon_name=icon_name, fallback=fallback)
    except Exception:
        pass
    try:
        return layout.label(text=text, icon=fallback)
    except Exception:
        return layout.label(text=text)


def _icon_prop(layout, data, property_name: str, *, text: str = '', icon_name: str | None = None, fallback: str = 'NONE', emboss: bool = True, **kwargs):
    effective_emboss = True if (str(text or '') == '' and (icon_name or str(fallback or 'NONE').upper() != 'NONE')) else bool(emboss)
    try:
        if _sss_icons is not None:
            return _sss_icons.prop(layout, data, property_name, text=text, icon_name=icon_name, fallback=fallback, emboss=effective_emboss, **kwargs)
    except Exception:
        pass
    attempts = (
        lambda: layout.prop(data, property_name, text=text, icon=fallback, emboss=effective_emboss, **kwargs),
        lambda: layout.prop(data, property_name, text=text, icon=fallback, **kwargs),
        lambda: layout.prop(data, property_name, text=text, **kwargs),
    )
    for attempt in attempts:
        try:
            return attempt()
        except TypeError:
            continue
        except Exception:
            continue
    return layout.prop(data, property_name, text=text)


def _large_icon_row(layout, *, scale: float = 1.35):
    row = layout.row(align=True)
    try:
        row.scale_y = max(float(getattr(row, 'scale_y', 1.0) or 1.0), float(scale))
    except Exception:
        pass
    return row


def _draw_help_button(layout, tool_id: str, context=None, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Selector-style help button.

    The button uses Blender's built-in QUESTION icon and an empty label.
    """
    del context, icon, text
    if not tool_id:
        return None
    try:
        op = layout.operator('skm.show_help', text='', icon='QUESTION')
        op.tool_id = str(tool_id or '')
        return op
    except Exception:
        return None


def _draw_help_header(layout, label: str, icon: str, tool_id: str, context=None, *, help_text: str | None = None):
    row = layout.row(align=True)
    split = row.split(factor=0.68, align=True)
    left = split.row(align=True)
    _icon_label(left, text=label, icon_name=_builtin_to_suite_icon(icon), fallback=icon)
    right = split.row(align=True)
    right.alignment = 'RIGHT'
    _draw_help_button(right, tool_id, context, text=help_text)
    return row


def _builtin_to_suite_icon(icon: str | None) -> str | None:
    mapping = {
        'OUTLINER_COLLECTION': 'GROUP',
        'MOD_MIRROR': 'MIRROR',
        'EXPORT': 'EXPORT',
        'FILE_FOLDER': 'LOAD',
        'TRASH': 'TRASH',
        'TIME': 'TRACKER',
        'MODIFIER': 'MODIFIER',
        'DRIVER': 'DRIVER',
        'CAMERA_DATA': 'TRACKER',
        'HELP': 'HELP',
    }
    return mapping.get(str(icon or ''), None)

def _draw_always_on_toggle_group(layout, context):
    """Draw the common top-level resident-feature section."""
    settings = _suite_settings(context)
    is_open = bool(getattr(settings, 'show_always_on_toggles', False)) if settings is not None else False
    box = layout.box()
    header = box.row(align=True)
    header.use_property_split = False
    header.use_property_decorate = False
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    if settings is not None and hasattr(settings, 'show_always_on_toggles'):
        header.prop(settings, 'show_always_on_toggles', text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=True)
        header.prop(settings, 'show_always_on_toggles', text=_t('Always-on Toggles'), icon='TIME', emboss=False)
    else:
        header.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
        header.label(text=_t('Always-on Toggles'), icon='TIME')
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    help_row = header.row(align=True)
    help_row.scale_x = 0.82
    _draw_help_button(help_row, 'always_on', context)
    if is_open:
        _draw_always_on_toggle_controls(box, context)



def _import_help():
    import importlib
    package = str(__package__ or '').strip()
    if not package:
        package = __name__.rsplit('.', 1)[0]
    return importlib.import_module(f'{package}.help')


class SKM_OT_show_help(bpy.types.Operator):
    bl_idname = 'skm.show_help'
    bl_label = _t('Help')
    bl_description = _t('Open a help popup for this Smart Shapekey tool.')
    bl_options = {'INTERNAL'}

    tool_id: bpy.props.StringProperty(
        name=_t('Tool'),
        description=_t('Internal help topic identifier.'),
        default='',
        options={'HIDDEN'},
    )

    def invoke(self, context, event):
        del event
        try:
            help = _import_help()
            width = int(getattr(help, 'popup_width', lambda *_args, **_kwargs: 760)(getattr(self, 'tool_id', ''), context))
        except Exception:
            width = 760
        return context.window_manager.invoke_popup(self, width=width)

    def draw(self, context):
        try:
            help = _import_help()
            draw_fn = getattr(help, 'draw_help_popup', None)
            if callable(draw_fn):
                draw_fn(self.layout, context, getattr(self, 'tool_id', ''))
                return
        except Exception as exc:
            box = self.layout.box()
            box.alert = True
            box.label(text=_t('Help popup draw failed.'), icon='ERROR')
            return
        self.layout.label(text=_t('Help content is not available for this tool.'), icon='ERROR')

    def execute(self, context):
        del context
        return {'FINISHED'}

class SKM_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = 'skm.toggle_ui_section'
    bl_label = _t('Toggle UI Section')
    bl_description = _t('Expand or collapse this Smart Shapekey UI section.')
    bl_options = {'INTERNAL'}

    section_key: bpy.props.StringProperty(
        name=_t('Section'),
        description=_t('Internal UI section key.'),
        default='',
        options={'HIDDEN'},
    )
    label: bpy.props.StringProperty(
        name=_t('Label'),
        description=_t('Section label used only for UI state changes.'),
        default='',
        options={'HIDDEN'},
    )
    default_state: bpy.props.BoolProperty(
        name=_t('Default State'),
        description=_t('Default expanded state used before this section is toggled.'),
        default=False,
        options={'HIDDEN'},
    )

    def execute(self, context):
        if _skm_ui_sections is not None:
            _skm_ui_sections.section_state_toggle(context, getattr(self, 'section_key', ''), bool(getattr(self, 'default_state', False)))
        return {'FINISHED'}



class SKM_OT_toggle_always_on(bpy.types.Operator):
    bl_idname = 'skm.toggle_always_on'
    bl_label = _t('Toggle Always-on Feature')
    bl_description = _t('Enable or disable a long-running Smart Shapekey feature from the unified Always-on Features group.')
    bl_options = {'INTERNAL'}

    target: bpy.props.EnumProperty(
        name=_t('Feature'),
        description=_t('Long-running feature to enable or disable.'),
        items=(
            ('AXIS_UI', _t('Axis UI'), _t('Interactive 2D HUD Axis controller in the 3D Viewport.')),
            ('FRAME_SYNC', _t('Frame Sync'), _t('Frame-change handler that updates animated Shape Axis handles.')),
            ('EXTERNAL_TRACKER', _t('External Tracker (UDP)'), _t('UDP listener for external joystick or tracking data.')),
            ('FACE_TRACKER', _t('Face Tracker (Built-In)'), _t('Webcam-based built-in face tracker.')),
            ('FACE_TRACKER_HUD', _t('Face Tracker Point HUD'), _t('Landmark overlay for the built-in Face Tracker.')),
        ),
    )
    enable: bpy.props.BoolProperty(
        name=_t('Enable'),
        description=_t('Turn this feature on when enabled, or turn it off when disabled.'),
        default=True,
        options={'HIDDEN'},
    )

    @classmethod
    def description(cls, context, properties):
        del cls, context
        try:
            return _always_on_target_description(str(getattr(properties, 'target', '') or ''))
        except Exception:
            return _t('Enable or disable a long-running Smart Shapekey feature from the unified Always-on Features group.')

    def execute(self, context):
        scene = getattr(context, 'scene', None)
        if scene is None:
            self.report({'ERROR'}, _t('Scene settings are not available.'))
            return {'CANCELLED'}
        target = str(getattr(self, 'target', '') or '')
        if not target:
            self.report({'ERROR'}, _t('No feature was selected.'))
            return {'CANCELLED'}
        setting_key = {
            'AXIS_UI': 'always_axis_ui_enabled',
                'FRAME_SYNC': 'always_frame_sync_enabled',
            'EXTERNAL_TRACKER': 'always_external_tracker_enabled',
            'FACE_TRACKER': 'always_face_tracker_enabled',
            'FACE_TRACKER_HUD': 'always_face_tracker_hud_enabled',
        }.get(target)
        settings = _suite_settings(context)
        requested = bool(getattr(self, 'enable', True))
        if setting_key and settings is not None and hasattr(settings, setting_key):
            setattr(settings, setting_key, requested)
            actual = _always_on_status(target, scene)
            if requested and not actual:
                try:
                    setattr(settings, setting_key, False)
                except Exception:
                    pass
                self.report({'ERROR'}, _t('Failed to switch the feature.'))
                return {'CANCELLED'}
            return {'FINISHED'}
        ok = _set_always_on_status(target, scene, context, requested)
        if not ok:
            self.report({'ERROR'}, _t('Failed to switch the feature.'))
            return {'CANCELLED'}
        return {'FINISHED'}

def _draw_bundled_tool_sections(layout, context):
    if _skm_ui_sections is None:
        return

    modifiers = _skm_ui_sections.draw_collapsible_section(
        layout, context, 'runtime.modifiers', _t('Modifiers'), icon='MODIFIER', help_id='modifiers_group', default=False
    )
    if modifiers is not None:
        body = _skm_ui_sections.draw_child_section(
            modifiers,
            context,
            'runtime.modifiers.apply_modifiers',
            _t('Apply Keeping Shape Keys'),
            icon='MODIFIER',
            help_id='apply_modifiers',
            default=False,
        )
        if body is not None:
            try:
                from .apply_modifiers_with_shape_keys import draw_apply_modifiers_body
                draw_apply_modifiers_body(body, context)
            except Exception as exc:
                warn = body.box(); warn.alert = True
                warn.label(text=_t('Modifiers UI draw failed.'), icon='ERROR')

    drivers = _skm_ui_sections.draw_collapsible_section(
        layout, context, 'runtime.drivers', _t('Drivers'), icon='DRIVER', help_id='drivers_group', default=False
    )
    if drivers is not None:
        body = _skm_ui_sections.draw_child_section(
            drivers,
            context,
            'runtime.drivers.driver_helper',
            _t('Driver Helper'),
            icon='DRIVER',
            help_id='driver_helper',
            default=False,
        )
        if body is not None:
            try:
                from .driver_helper import draw_driver_helper_body
                draw_driver_helper_body(body, context)
            except Exception as exc:
                warn = body.box(); warn.alert = True
                warn.label(text=_t('Drivers UI draw failed.'), icon='ERROR')

    control = _skm_ui_sections.draw_collapsible_section(
        layout, context, 'runtime.control_tracking', _t('Control / Tracking'), icon='TIME', help_id='control_tracking_group', default=False
    )
    if control is not None:
        sections = (
            ('runtime.control_tracking.axis_control', _t('ShapeKey Axis Control'), 'DRIVER', 'shape_axis_control', '.axis_control.ui.panel', 'draw_shape_axis_control_body'),
            ('runtime.control_tracking.external_tracker', _t('External Tracker (UDP)'), 'DRIVER', 'external_tracker', '.axis_control.interface.tracker', 'draw_external_tracker_body'),
            ('runtime.control_tracking.face_tracker', _t('Face Tracker (Built-In)'), 'CAMERA_DATA', 'face_tracker', '.axis_control.face_tracker.ui', 'draw_face_tracker_body'),
        )
        for key, label, icon, help_id, module_name, func_name in sections:
            body = _skm_ui_sections.draw_child_section(control, context, key, label, icon=icon, help_id=help_id, default=False)
            if body is None:
                continue
            try:
                module = _import_optional_module(module_name)
                draw_fn = getattr(module, func_name, None) if module is not None else None
                if callable(draw_fn):
                    draw_fn(body, context)
                else:
                    body.label(text=_t('This section is not available.'))
            except Exception as exc:
                warn = body.box(); warn.alert = True
                warn.label(text=_t('Control / Tracking UI draw failed.'), icon='ERROR')



class SKM_OT_show_view3d_npanel(bpy.types.Operator):
    bl_idname = "skm.show_view3d_npanel"
    bl_label = "Smart Shapekey"
    bl_description = _t("Show the Smart Shapekey controls in the 3D View N-panel. Use this suite to set a base shape, store UV-based maps, mirror vertex edits, save and load map files, export results, and clean tool data.")
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        del cls
        area = getattr(context, 'area', None)
        if area is None:
            return True
        try:
            return str(getattr(area, 'type', '') or '') in _SKM_NPANEL_SPACE_TYPES
        except Exception:
            return False

    def execute(self, context):
        try:
            _ensure_skm_runtime_bound(context=context)
        except Exception:
            pass
        return {'FINISHED'} if _show_npanel(context) else {'CANCELLED'}


class _SKM_PT_full_body_impl:
    bl_label = "Smart Shapekey"
    bl_idname = "SKM_PT_view3d_root"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        del cls
        return _is_mesh_panel_context(context)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = False
        layout.use_property_decorate = False

        try:
            _draw_always_on_toggle_group(layout, context)
        except Exception as exc:
            warn_box = layout.box()
            warn_box.alert = True
            warn_box.label(text=_t('Always-on Features draw failed.'), icon='ERROR')

        obj = _panel_active_mesh_object(context, require_selected=False)
        if not obj or obj.type != 'MESH':
            layout.label(text=_t("Select a mesh object."))
            return
        if not _panel_context_mode_supported(context):
            layout.label(text=_t("Switch to Object Mode or Edit Mode."))
            return

        section = _skm_ui_sections.draw_collapsible_section(
            layout,
            context,
            'core.object_uv_base',
            _t('Basis and New Map'),
            icon='OBJECT_DATA',
            help_id='smart_shapekey_core',
            default=False,
        ) if _skm_ui_sections is not None else layout.box()
        if section is not None:
            _icon_label(section, text=f"{_t('Object')}: {obj.name}", icon_name='GROUP', fallback='OBJECT_DATA')
            _icon_label(section, text=f"{_t('Verts')}: {len(obj.data.vertices)}    {_t_alt('Map Count', 'Maps')}: {len(obj.skm_maps)}", icon_name='CREATE_MAP', fallback='MESH_DATA')
            row = section.row(align=True)
            _icon_op(row, "skm.set_base", text=_t("Set Base"), icon_name='BASE', fallback='KEY_HLT')
            _icon_op(row, "skm.new_map", text=_t("New"), icon_name='NEW_MAP', fallback='ADD')

        maps = _skm_ui_sections.draw_collapsible_section(layout, context, 'core.maps', _t('Maps'), icon='OUTLINER_COLLECTION', help_id='smart_shapekey_maps', default=False) if _skm_ui_sections is not None else layout.box()
        if maps is not None:
            maps.template_list("SKM_UL_MapList", "", obj, "skm_maps", obj, "skm_edit_index" if obj.skm_edit_mode else "skm_index", rows=6)
            maps.prop(obj, "skm_edit_mode", text=_t("Edit") if obj.skm_edit_mode else _t("Select"), toggle=True)
            edit = maps.column(align=True)
            edit.enabled = bool(obj.skm_edit_mode)
            row = edit.row(align=True)
            _icon_op(row, "skm.move_map", text=_t("Up"), icon_name='MOVE_MAP_UP', fallback='TRIA_UP').direction = 'UP'
            _icon_op(row, "skm.move_map", text=_t("Down"), icon_name='MOVE_MAP_DOWN', fallback='TRIA_DOWN').direction = 'DOWN'
            row = edit.row(align=True)
            op = _icon_op(row, "skm.order_maps", text=_t("Sort by Name"), icon_name='MOVE_MAP_UP', fallback='SORTALPHA'); op.mode = 'NAME'
            op = _icon_op(row, "skm.order_maps", text=_t("ID Order"), icon_name='MOVE_MAP_DOWN', fallback='SORTBYEXT'); op.mode = 'CHANNEL_ID'
            row = maps.row(align=True)
            active = 0 <= int(obj.skm_index) < len(obj.skm_maps) and int(obj.skm_maps[obj.skm_index].chn_id) != BASE_ID
            actions = row.row(align=True)
            actions.enabled = active
            _icon_op(actions, "skm.rename_map", text=_t("Rename"), icon_name='CREATE_MAP', fallback='GREASEPENCIL')
            _icon_op(actions, "skm.clear_map", text=_t("Clear"), icon_name='DELETE_MAP', fallback='X')
            _icon_op(actions, "skm.delete_map", text=_t("Delete"), icon_name='DELETE_MAP', fallback='TRASH')
            _icon_op(maps, "skm.full_cleanup", text=_t("Delete All"), icon_name='DELETE_MAP', fallback='TRASH')

        mirror_tools = _skm_ui_sections.draw_collapsible_section(layout, context, 'core.mirror_tools', _t('Mirror Tools'), icon='MOD_MIRROR', help_id='smart_shapekey_mirror_tools', default=False) if _skm_ui_sections is not None else layout.box()
        if mirror_tools is not None:
            tools = mirror_tools.column(align=True)
            tools.enabled = 0 <= int(obj.skm_index) < len(obj.skm_maps) and int(obj.skm_maps[obj.skm_index].chn_id) != BASE_ID
            _icon_op(tools, "skm.invert_selected", text=_t("Invert Selected Shape"), icon_name='INVERT_SELECTED_VERTS', fallback='ARROW_LEFTRIGHT')
            mirror_axis = str(obj.skm_mirror_axis)
            row = tools.row(align=True)
            _icon_op(row, "skm.mirror_selected", text=f"-{mirror_axis} → +{mirror_axis}", icon_name='MIRROR_SELECTED_LR', fallback='MOD_MIRROR').direction = 'LR'
            _icon_op(row, "skm.mirror_selected", text=f"+{mirror_axis} → -{mirror_axis}", icon_name='MIRROR_SELECTED_RL', fallback='MOD_MIRROR').direction = 'RL'

        export = _skm_ui_sections.draw_collapsible_section(layout, context, 'core.export', _t('Export'), icon='EXPORT', help_id='smart_shapekey_export', default=False) if _skm_ui_sections is not None else layout.box()
        if export is not None:
            row = export.row(align=True)
            _icon_op(row, "skm.export_maps", text=_t("Export"), icon_name='EXPORT_TO_SHAPE_KEYS', fallback='EXPORT')
            _icon_op(row, "skm.import_shape_keys", text=_t("Import"), icon_name='EXPORT_TO_SHAPE_KEYS', fallback='IMPORT')

        files = _skm_ui_sections.draw_collapsible_section(layout, context, 'core.save_load', _t('Save/Load'), icon='FILE_FOLDER', help_id='smart_shapekey_save_load', default=False) if _skm_ui_sections is not None else layout.box()
        if files is not None:
            row = files.row(align=True)
            has_maps = any(int(it.chn_id) != BASE_ID for it in obj.skm_maps)
            save_all = row.row(align=True)
            save_all.enabled = has_maps
            _icon_op(save_all, "skm.save_file", text=_t("Save (All)"), fallback='EXPORT').selected_only = False
            save_selected = row.row(align=True)
            save_selected.enabled = any(bool(it.selected) and int(it.chn_id) != BASE_ID for it in obj.skm_maps)
            _icon_op(save_selected, "skm.save_file", text=_t("Save (Selected)"), fallback='EXPORT').selected_only = True
            _icon_op(files, "skm.load_file", text=_t("Load"), fallback='IMPORT')

        mirror_settings = _skm_ui_sections.draw_collapsible_section(layout, context, 'core.mirror_settings', _t('Mirror Settings'), icon='MOD_MIRROR', help_id='smart_shapekey_mirror_settings', default=False, body_property_split=True) if _skm_ui_sections is not None else layout.box()
        if mirror_settings is not None:
            mirror_settings.prop(obj, "skm_mirror_axis")
            col = mirror_settings.column(align=True)
            col.prop(obj, "skm_mirror_center_x", text=f"{_t('Center')} X")
            col.prop(obj, "skm_mirror_center_y", text="Y")
            col.prop(obj, "skm_mirror_center_z", text="Z")
            mirror_settings.prop(obj, "skm_mirror_epsilon", text=_t('Tolerance'))

        try:
            _draw_bundled_tool_sections(layout, context)
        except Exception as exc:
            warn_box = layout.box()
            warn_box.alert = True
            warn_box.label(text=_t('Bundled tool sections draw failed.'), icon='ERROR')


# Shared complete body used by every statically declared suite-owned root.
# No Panel type or registered Panel attribute is created or mutated at runtime.
_SKM_PT_VIEW3D_ROOT_IMPL = _SKM_PT_full_body_impl


_SKM_MANAGER_RULE_CACHE: "OrderedDict[tuple[str, str], bool]" = OrderedDict()
# Kept as an always-empty compatibility/audit field. Panel.poll is immutable and
# never populates a Suite-side decision cache; Manager owns the authoritative
# pure cached current-cell rule. NOT_READY/missing Manager deliberately fail open.
_SKM_MANAGER_RULE_CACHE_MAX = 0


def _skm_manager_module_names() -> tuple[str, ...]:
    names: list[str] = []
    package_name = str(__package__ or '')
    if '.' in package_name:
        names.append(f"{package_name.rsplit('.', 1)[0]}.smart_tools_manager.manager")
    names.extend((
        'bl_ext.user_default.smart_tools_manager.manager',
        'smart_tools_manager.manager',
    ))
    return tuple(dict.fromkeys(names))


_SKM_MANAGER_MODULE_NAMES = _skm_manager_module_names()


def _skm_loaded_manager_module():
    """Resolve Manager by a fixed finite set of public module identities.

    This is an O(1), read-only lookup suitable for Panel.poll. It never scans
    ``sys.modules``, imports Manager, reads disk, starts a timer, or mutates state.
    """
    for module_name in _SKM_MANAGER_MODULE_NAMES:
        module = sys.modules.get(module_name)
        if module is not None:
            return module
    return None


def _skm_normalize_manager_rule(result):
    if type(result) is bool:
        return result
    if isinstance(result, dict):
        state = str(result.get('state', result.get('status', '')) or '').upper()
        if state in {'OFF', 'DISABLED', 'DENY', 'HIDDEN', 'FALSE'}:
            return False
        if state in {'ON', 'ENABLED', 'ALLOW', 'VISIBLE', 'TRUE'}:
            return True
        ready = result.get('ready')
        if ready is False or state in {'NOT_READY', 'UNAVAILABLE', 'LOADING'}:
            return None
        for key in ('allowed', 'visible', 'enabled', 'value'):
            if type(result.get(key)) is bool:
                return bool(result[key])
        return None
    if isinstance(result, (tuple, list)) and result:
        return _skm_normalize_manager_rule(result[0])
    state = str(result or '').upper()
    if state in {'OFF', 'DISABLED', 'DENY', 'HIDDEN'}:
        return False
    if state in {'ON', 'ENABLED', 'ALLOW', 'VISIBLE'}:
        return True
    return None


def _skm_query_manager_rule(context, editor_key: str):
    """Call only the Manager's documented pure cached public poll API."""
    module = _skm_loaded_manager_module()
    if module is None:
        return None
    api = getattr(module, 'panel_rule_allows_context', None)
    if not callable(api):
        return None
    try:
        return _skm_normalize_manager_rule(
            api('SMART_SHAPEKEY', context=context, editor_key=editor_key)
        )
    except TypeError:
        try:
            return _skm_normalize_manager_rule(api('SMART_SHAPEKEY', context, editor_key))
        except Exception:
            return None
    except Exception:
        return None

def _skm_context_text(owner, *names: str) -> str:
    for name in names:
        try:
            value = getattr(owner, name, None)
        except Exception:
            value = None
        text = str(value or '').upper()
        if text:
            return text
    return ''


def _skm_logical_editor_key(context, supported: tuple[str, ...]) -> str:
    """Resolve the current logical editor from RNA already present in context.

    This function is a pure read. It performs no Manager import, file access,
    registration, cache mutation, timer work, or scene/datablock traversal.
    """
    supported = tuple(str(key) for key in supported if key)
    fallback = supported[0] if supported else 'VIEW_3D'
    area = getattr(context, 'area', None)
    space = getattr(context, 'space_data', None)
    area_type = _skm_context_text(area, 'type')
    area_ui_type = _skm_context_text(area, 'ui_type')
    actual = _skm_context_text(space, 'type') or area_type
    mode = _skm_context_text(space, 'mode', 'ui_mode')
    tree_type = _skm_context_text(space, 'tree_type') or area_ui_type
    browse_mode = _skm_context_text(space, 'browse_mode', 'mode')
    if not browse_mode:
        browse_mode = _skm_context_text(getattr(space, 'params', None), 'browse_mode')

    candidate = fallback
    if actual == 'IMAGE_EDITOR':
        candidate = 'UV_EDITOR' if mode in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'} or area_ui_type in {'UV', 'UV_EDIT', 'UVS', 'UV_EDITOR'} else 'IMAGE_EDITOR'
    elif actual == 'NODE_EDITOR':
        if tree_type in {'COMPOSITORNODETREE', 'COMPOSITOR', 'COMPOSITOR_NODE_TREE'}:
            candidate = 'COMPOSITOR'
        elif tree_type in {'GEOMETRYNODETREE', 'GEOMETRY', 'GEOMETRY_NODE_TREE'}:
            candidate = 'GEOMETRY_NODE_EDITOR'
        elif tree_type in {'TEXTURENODETREE', 'TEXTURE', 'TEXTURE_NODE_TREE'}:
            candidate = 'TEXTURE_NODE_EDITOR'
        else:
            candidate = 'SHADER_EDITOR'
    elif actual == 'GRAPH_EDITOR':
        candidate = 'DRIVERS' if mode in {'DRIVERS', 'DRIVER'} or area_ui_type in {'DRIVERS', 'DRIVER'} else 'GRAPH_EDITOR'
    elif actual == 'FILE_BROWSER':
        candidate = 'ASSET_BROWSER' if browse_mode in {'ASSETS', 'ASSET_BROWSER'} or area_ui_type in {'ASSETS', 'ASSET_BROWSER'} else 'FILE_BROWSER'
    else:
        physical_map = {
            'VIEW_3D': 'VIEW_3D',
            'SEQUENCE_EDITOR': 'VIDEO_SEQUENCER',
            'CLIP_EDITOR': 'MOVIE_CLIP_EDITOR',
            'DOPESHEET_EDITOR': 'DOPE_SHEET',
            'NLA_EDITOR': 'NLA_EDITOR',
            'TEXT_EDITOR': 'TEXT_EDITOR',
            'SPREADSHEET': 'SPREADSHEET',
        }
        candidate = physical_map.get(actual, fallback)
    return candidate if candidate in supported else fallback


def _skm_root_panel_visible(context, supported: tuple[str, ...]) -> bool:
    """Immutable root poll: explicit Manager OFF hides; otherwise fail open."""
    editor_key = _skm_logical_editor_key(context, supported)
    decision = _skm_query_manager_rule(context, editor_key)
    return decision if type(decision) is bool else True


def _skm_draw_full_body(self, context):
    return _SKM_PT_VIEW3D_ROOT_IMPL.draw(self, context)


def _skm_draw_root_header_preset(self, context):
    """Header "?" of every Smart Shapekey root panel (SmartTools help rule 2026-10-17)."""
    _draw_help_button(self.layout, 'smart_shapekey_suite', context)


class SKM_PT_view3d_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_view3d_root'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'VIEW_3D'
    _smart_tools_manager_editor_keys = ('VIEW_3D',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_image_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_image_editor_root'
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'IMAGE_EDITOR'
    _smart_tools_manager_editor_keys = ('IMAGE_EDITOR', 'UV_EDITOR')
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_node_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_node_editor_root'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'SHADER_EDITOR'
    _smart_tools_manager_editor_keys = ('SHADER_EDITOR', 'COMPOSITOR', 'GEOMETRY_NODE_EDITOR', 'TEXTURE_NODE_EDITOR')
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_sequence_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_sequence_editor_root'
    bl_space_type = 'SEQUENCE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'VIDEO_SEQUENCER'
    _smart_tools_manager_editor_keys = ('VIDEO_SEQUENCER',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_clip_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_clip_editor_root'
    bl_space_type = 'CLIP_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'MOVIE_CLIP_EDITOR'
    _smart_tools_manager_editor_keys = ('MOVIE_CLIP_EDITOR',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_dopesheet_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_dopesheet_editor_root'
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'DOPE_SHEET'
    _smart_tools_manager_editor_keys = ('DOPE_SHEET',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_graph_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_graph_editor_root'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'GRAPH_EDITOR'
    _smart_tools_manager_editor_keys = ('GRAPH_EDITOR', 'DRIVERS')
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_nla_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_nla_editor_root'
    bl_space_type = 'NLA_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'NLA_EDITOR'
    _smart_tools_manager_editor_keys = ('NLA_EDITOR',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_text_editor_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_text_editor_root'
    bl_space_type = 'TEXT_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'TEXT_EDITOR'
    _smart_tools_manager_editor_keys = ('TEXT_EDITOR',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_file_browser_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_file_browser_root'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'FILE_BROWSER'
    _smart_tools_manager_editor_keys = ('FILE_BROWSER',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_file_browser_root_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


def _skm_file_browser_root_visible(context, supported):
    if getattr(getattr(context, 'area', None), 'type', None) != 'FILE_BROWSER':
        return False
    editor_key = _skm_logical_editor_key(context, ('FILE_BROWSER', 'ASSET_BROWSER'))
    return editor_key in supported and _skm_root_panel_visible(context, supported)


class SKM_PT_asset_browser_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_asset_browser_root'
    bl_space_type = 'FILE_BROWSER'
    bl_region_type = 'TOOL_PROPS'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'ASSET_BROWSER'
    _smart_tools_manager_editor_keys = ('ASSET_BROWSER',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_file_browser_root_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset


class SKM_PT_spreadsheet_root(bpy.types.Panel):
    bl_label = 'Smart Shapekey'
    bl_idname = 'SKM_PT_spreadsheet_root'
    bl_space_type = 'SPREADSHEET'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    _smart_tools_manager_editor_key = 'SPREADSHEET'
    _smart_tools_manager_editor_keys = ('SPREADSHEET',)
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        return _skm_root_panel_visible(context, cls._smart_tools_manager_editor_keys)

    draw = _skm_draw_full_body
    draw_header_preset = _skm_draw_root_header_preset




class SKM_PT_view3d_mirror_settings(bpy.types.Panel):
    bl_label = _t("Mirror Settings")
    bl_idname = "SKM_PT_view3d_mirror_settings"
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_options = {'DEFAULT_CLOSED'}
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        return None

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'smart_shapekey_mirror_settings', context)


class SKM_PT_view3d_modifiers(bpy.types.Panel):
    bl_label = _t("Modifiers")
    bl_idname = "SKM_PT_view3d_modifiers"
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 20
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        return None

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'modifiers_group', context)


class SKM_PT_view3d_drivers(bpy.types.Panel):
    bl_label = _t("Drivers")
    bl_idname = "SKM_PT_view3d_drivers"
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 30
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        return None

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'drivers_group', context)


class SKM_PT_view3d_control_tracking(bpy.types.Panel):
    bl_label = _t("Control / Tracking")
    bl_idname = "SKM_PT_view3d_control_tracking"
    bl_parent_id = ""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Shapekey'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 40
    skm_skip_detection = True

    @classmethod
    def poll(cls, context):
        del cls, context
        return False

    def draw(self, context):
        return None

    def draw_header_preset(self, context):
        _draw_help_button(self.layout, 'control_tracking_group', context)


_VIEW3D_NPANEL_CLASSES = (
    SKM_PT_view3d_root,
    SKM_PT_image_editor_root,
    SKM_PT_node_editor_root,
    SKM_PT_sequence_editor_root,
    SKM_PT_clip_editor_root,
    SKM_PT_dopesheet_editor_root,
    SKM_PT_graph_editor_root,
    SKM_PT_nla_editor_root,
    SKM_PT_text_editor_root,
    SKM_PT_file_browser_root,
    SKM_PT_spreadsheet_root,
    SKM_PT_asset_browser_root,
)



def prepare_view3d_npanel_panels():
    return tuple(_VIEW3D_NPANEL_CLASSES)



def install_view3d_npanel_panels(*, deferred: bool = False):
    del deferred
    # Legacy API retained for older internal callers.  Do not register any
    # Compatibility shim for older internal callers. The classes above are
    # ordinary VIEW_3D > UI panels and need no special installation.
    return True


def uninstall_view3d_npanel_panels():
    return True


try:
    SKM_OT_show_view3d_npanel.bl_label = _SKM_TAB_LABEL
    SKM_OT_show_view3d_npanel.bl_description = _SKM_TAB_TOOLTIP
except Exception:
    pass




def view3d_npanel_classes() -> tuple[type, ...]:
    return tuple(_VIEW3D_NPANEL_CLASSES)


def draw_view3d_npanel_contents(layout, context):
    # Compatibility helper for older internal callers. The actual UI is made of
    # ordinary registered VIEW_3D > UI Panel classes, so this function does not
    # create proxy Panel instances or call other Panel.draw methods manually.
    del context
    try:
        layout.label(text='Smart Shapekey', icon='SHAPEKEY_DATA')
    except Exception:
        pass
    return True


_SKM_LAZY_RUNTIME_DIRTY = True


def _smart_tools_prepare_before_open(context=None):
    try:
        _ensure_skm_runtime_bound(context=context, force=True)
    except Exception:
        return False
    return True


def _smart_tools_finalize_after_open(context=None):
    # Standard N-panel build: bundled tool panels are registered directly, so no
    # SmartTools proxy refresh or repeated timer rebinding is required.
    del context
    return True


def _rebind_smart_shapekey_runtime():
    return None


def _ensure_skm_runtime_bound(context=None, *, force: bool = False) -> bool:
    global _SKM_LAZY_RUNTIME_DIRTY
    del context, force
    was_dirty = bool(_SKM_LAZY_RUNTIME_DIRTY)
    _SKM_LAZY_RUNTIME_DIRTY = False
    return was_dirty


def _apply_persistent_settings_now(context=None, *, resume_features: bool = True) -> None:
    """Restore validated settings without scanning or deleting Blender data."""
    context = context or getattr(bpy, 'context', None)
    scene = getattr(context, 'scene', None) if context is not None else None
    _load_settings_into_window_manager(context)
    _apply_persistent_scene_settings(scene)
    _apply_persistent_object_settings(context)
    _apply_persistent_driver_helper_settings(scene)
    if resume_features:
        _sync_all_always_on_settings(context)
    _notify_settings_issue_once(context)


def _on_active_scene_changed() -> None:
    _apply_persistent_settings_now(getattr(bpy, 'context', None))
    _register_scene_change_subscription()


def _on_active_object_changed() -> None:
    # Apply object-owned panel values only when the user targets that object.
    # This keeps file loading proportional to the edited set, not scene size.
    try:
        _apply_persistent_object_settings(getattr(bpy, 'context', None))
    except Exception:
        pass


def _register_scene_change_subscription() -> None:
    """No idle msgbus subscription: explicit events and load handlers own updates."""
    return None


def _unregister_scene_change_subscription() -> None:
    return None

def _schedule_persistent_settings_apply(first_interval: float = 0.05) -> None:
    del first_interval
    try:
        _apply_persistent_settings_now(getattr(bpy, 'context', None))
    except Exception:
        pass


def _clear_runtime_caches() -> None:
    _UV_ENUM_ITEMS_CACHE.clear()
    _SKM_MANAGER_RULE_CACHE.clear()
    _SKM_DEFERRED_APPLY_PENDING.clear()
    for key in tuple(_SKM_DEFERRED_APPLY_STATS):
        _SKM_DEFERRED_APPLY_STATS[key] = 0
    try:
        from .axis_control.ui import draw as axis_draw
        clear_fn = getattr(axis_draw, 'clear_snapshot', None)
        if callable(clear_fn):
            clear_fn()
    except Exception:
        pass
    try:
        from .axis_control.face_tracker import draw_hud as face_draw
        clear_fn = getattr(face_draw, 'clear_snapshot', None)
        if callable(clear_fn):
            clear_fn()
    except Exception:
        pass
    try:
        from .axis_control.interface import tracker as udp_tracker
        clear_fn = getattr(udp_tracker, 'clear_runtime_cache', None)
        if callable(clear_fn):
            clear_fn()
    except Exception:
        pass
    try:
        from .axis_control import clear_runtime_cache as clear_axis_cache
        clear_axis_cache()
    except Exception:
        pass


def teardown_runtime_activity(reason: str = 'teardown') -> bool:
    """Synchronously invalidate callbacks and stop every optional resource."""
    del reason
    _sss_activity.invalidate_generation()
    ok = True
    import importlib
    stop_calls = (
        ('.axis_control.interface.tracker', 'stop_tracker', {}),
        ('.axis_control.face_tracker.core', 'stop_tracking', {}),
        ('.axis_control.face_tracker.draw_hud', 'stop_hud', {}),
        ('.axis_control.face_tracker.installer', 'stop_install_worker', {}),
        ('.axis_control', 'stop_frame_sync', {}),
        ('.axis_control.operators.main', 'stop_axis_hud', {'rollback': True}),
    )
    for module_name, function_name, kwargs in stop_calls:
        try:
            module = importlib.import_module(module_name, __package__)
            function = getattr(module, function_name, None)
            if callable(function) and function(**kwargs) is False:
                ok = False
        except Exception:
            ok = False
    if not _sss_activity.teardown_all():
        ok = False
    _clear_runtime_caches()
    return ok


@persistent
def _skm_smart_tools_load_pre(*_args):
    global _SKM_SETTINGS_CACHE
    # Invalidate first, then close blocking I/O and synchronously join every worker.
    # No old-generation callback may retain the outgoing Scene/RNA while settings
    # are snapshotted or when Blender begins replacing the file data.
    teardown_runtime_activity('load_pre')
    try:
        if _SKM_WRITE_BARRIER.enabled and (_sss_settings_io.STATE.dirty or isinstance(_SKM_SETTINGS_PENDING, dict)):
            _save_current_panel_settings(getattr(bpy, 'context', None))
    except Exception:
        _notify_settings_issue_once(getattr(bpy, 'context', None))
    _SKM_SETTINGS_CACHE = None
    return None


@persistent
def _skm_smart_tools_load_post(*_args):
    global _SKM_SETTINGS_CACHE, _SKM_REGISTRATION_WRITE_GUARD_DEPTH
    try:
        _SKM_SETTINGS_CACHE = None
        payload = begin_registration_restore()
        _sss_ownership.new_file_generation()
        _adopt_persistent_ref_collection()
        _adopt_loaded_reference_graphs(getattr(bpy, 'context', None))
        _sss_activity.new_generation(teardown_existing=True)
        apply_registration_restore(payload, getattr(bpy, 'context', None))
        end_registration_restore()
        _sync_all_always_on_settings(getattr(bpy, 'context', None))
    except Exception:
        # Persistent handlers must never leak a traceback into Blender's console.
        # Retire every resource created by the incomplete new generation and leave
        # settings uncached so the next explicit safe boundary may retry.
        try:
            teardown_runtime_activity('load_post_error')
        except Exception:
            pass
        _SKM_REGISTRATION_WRITE_GUARD_DEPTH = 0
        _SKM_WRITE_BARRIER.stop()
        _SKM_SETTINGS_CACHE = None
    return None


@persistent
def _skm_smart_tools_save_userpref_pre(*_args):
    # Every editable setting has a synchronous update callback.  Blender can
    # also emit save_userpref_pre during shutdown after Scene teardown, where a
    # forced full snapshot would replace valid dynamic values with defaults.
    # The suite's explicit Save Preferences operator performs its own safe
    # snapshot before invoking Blender, so the global handler is read-only.
    return None


@persistent
def _skm_smart_tools_save_pre(*_args):
    if _SKM_WRITE_BARRIER.enabled:
        try:
            _save_current_panel_settings(getattr(bpy, 'context', None))
        except Exception:
            pass
    return None


def _schedule_skm_rebind(*, attempts: int = 8, first_interval: float = 0.05) -> None:
    del attempts, first_interval
    return None


# -----------------------------------------------------------------------------
# Single authoritative registration transaction
# -----------------------------------------------------------------------------
_BUNDLED_TOOL_MODULE_NAMES = (
    'apply_modifiers_with_shape_keys',
    'driver_helper',
    'axis_control',
)
_BUNDLED_TOOL_MODULES: list[object] = []


classes = (
    SKM_PG_suite_settings,
    SKM_MapItem,
    SKM_LoadChoice,
    SKM_UL_MapList,
    SKM_OT_set_base,
    SKM_OT_new_map,
    SKM_OT_store_map,
    SKM_OT_clear_map,
    SKM_OT_delete_map,
    SKM_OT_rename_map,
    SKM_OT_duplicate_map,
    SKM_OT_move_map,
    SKM_OT_order_maps,
    SKM_OT_import_shape_keys,
    SKM_OT_copy_selected_verts,
    SKM_OT_paste_verts,
    SKM_OT_invert_selected,
    SKM_OT_mirror_selected,
    SKM_OT_mirror_settings,
    SKM_OT_export_shapekeys,
    SKM_OT_export_objects,
    SKM_OT_export_maps,
    SKM_OT_save_file,
    SKM_OT_load_file,
    SKM_OT_load_choose,
    SKM_OT_load_toggle_all,
    SKM_OT_save_overwrite,
    SKM_OT_clean_orphans,
    SKM_OT_full_cleanup,
    SKM_OT_show_help,
    SKM_OT_toggle_ui_section,
    SKM_OT_toggle_always_on,
    SKM_OT_show_view3d_npanel,
    *_VIEW3D_NPANEL_CLASSES,
)

_RUNTIME_OBJECT_PROPS = (
    'skm_maps', 'skm_index', 'skm_edit_index', 'skm_edit_mode', 'skm_uv_map_name', 'skm_keep_map_shapes',
    'skm_mirror_axis', 'skm_mirror_center_x', 'skm_mirror_center_y',
    'skm_mirror_center_z', 'skm_mirror_epsilon', 'skm__suppress_apply',
)
_RUNTIME_REGISTERED = False
_RUNTIME_STATE = 'INACTIVE'
_RUNTIME_TOKEN = None
_RUNTIME_LEDGER = None
_RUNTIME_FAULT_STAGE: str | None = None


def set_registration_fault_injection(stage: str | None) -> None:
    global _RUNTIME_FAULT_STAGE
    _RUNTIME_FAULT_STAGE = str(stage) if stage else None


def _registration_checkpoint(stage: str) -> None:
    if _RUNTIME_FAULT_STAGE and _RUNTIME_FAULT_STAGE == str(stage):
        raise RuntimeError(f'injected registration fault: {stage}')


def _import_bundled_tool_module(module_name: str):
    import importlib
    return importlib.import_module(f'.{module_name}', str(__package__ or ''))


def _register_translation_resource(ledger) -> None:
    # Deterministic owner + unregister-first: a uuid-suffixed owner can never
    # be reclaimed once its ledger is orphaned (Blender clears
    # driver_namespace on every file load), so stale caches accumulated across
    # live reinstalls. Unregistering our own deterministic owner first clears
    # the previous generation's cache and never touches foreign owners.
    owner = str(__name__)
    try:
        bpy.app.translations.unregister(owner)
    except Exception:
        pass
    table = {language: dict(messages) for language, messages in translation_dict.items()}
    for language, messages in _sss_translation.translation_dict().items():
        table.setdefault(language, {}).update(messages)
    bpy.app.translations.register(owner, table)
    ledger.record(
        'translation', owner,
        lambda translation_owner=owner: bpy.app.translations.unregister(translation_owner),
        label=owner, native_owner=bpy.app.translations,
    )


def _register_icon_resource(ledger) -> None:
    if _sss_icons is None:
        return
    _sss_icons.register()
    ledger.record(
        'preview_collection', _sss_icons,
        lambda: _sss_icons.unregister(),
        label='Smart Shapekey icon previews', native_owner=_sss_icons,
    )


def _register_bundled_tool_modules(ledger) -> None:
    _BUNDLED_TOOL_MODULES.clear()
    for module_name in _BUNDLED_TOOL_MODULE_NAMES:
        _registration_checkpoint(f'before_module:{module_name}')
        module = _import_bundled_tool_module(module_name)
        register_fn = getattr(module, 'register', None)
        if not callable(register_fn):
            raise RuntimeError(f'bundled module has no register(): {module_name}')
        register_fn(ledger)
        _BUNDLED_TOOL_MODULES.append(module)
        unregister_fn = getattr(module, 'unregister', None)
        if callable(unregister_fn):
            ledger.record(
                'module_state', module,
                lambda fn=unregister_fn: fn(),
                label=module_name, native_owner=module,
            )
        _registration_checkpoint(f'after_module:{module_name}')


def _unregister_bundled_runtime_state() -> None:
    for module in reversed(tuple(_BUNDLED_TOOL_MODULES)):
        try:
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                unregister_fn()
        except Exception:
            pass
    _BUNDLED_TOOL_MODULES.clear()


_SUITE_HANDLER_COLLECTION_NAMES = ('load_pre', 'load_post', 'save_pre', 'save_userpref_pre')


def _retire_stale_handler_residue() -> None:
    """Remove app handlers leaked by an old installation of THIS package.

    When an old version's unregister is orphaned (driver_namespace is cleared
    on every file load, losing its ledger), its handler callbacks stay in
    ``bpy.app.handlers`` referencing dead module code. Scoped strictly to
    callables whose ``__module__`` is this package's own dotted prefix; this
    runs before the current generation appends its own callbacks, so every
    match is residue. Foreign add-ons are never touched.
    """
    prefix = str(__package__ or '')
    if not prefix:
        return
    handlers = getattr(bpy.app, 'handlers', None)
    for handler_name in _SUITE_HANDLER_COLLECTION_NAMES:
        collection = getattr(handlers, handler_name, None)
        if collection is None:
            continue
        for idx in range(len(collection) - 1, -1, -1):
            try:
                cb = collection[idx]
                mod = str(getattr(cb, '__module__', '') or '')
                if mod == prefix or mod.startswith(prefix + '.'):
                    collection.pop(idx)
            except Exception:
                pass


def _register_runtime_rna(ledger) -> None:
    lp = _sss_lifecycle.register_rna_property
    lp(ledger, bpy.types.WindowManager, 'skm_suite_settings', bpy.props.PointerProperty(
        type=SKM_PG_suite_settings,
        description=_t('Persistent Smart Shapekey N-panel settings stored in a validated config JSON.'),
    ))
    lp(ledger, bpy.types.Object, 'skm_maps', bpy.props.CollectionProperty(
        type=SKM_MapItem,
        description=_t('Smart Shapekey map rows stored on this object.'),
    ))
    lp(ledger, bpy.types.Object, 'skm_index', bpy.props.IntProperty(
        default=-1,
        description=_t('Active Smart Shapekey map index.'),
        update=_on_index_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_edit_index', bpy.props.IntProperty(default=-1))
    lp(ledger, bpy.types.Object, 'skm_edit_mode', bpy.props.BoolProperty(
        name=_t('Edit'), default=False, update=_on_edit_mode_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_uv_map_name', bpy.props.EnumProperty(
        name=_t('UV Map'),
        description=_t('Choose the UV map used as the correspondence key.'),
        items=_uv_items,
        default=0,
        update=_on_uv_map_name_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_keep_map_shapes', bpy.props.BoolProperty(
        name=_t('Keep Map Shapes'),
        description=_t('Keep maps as absolute UV-space shapes instead of base-relative offsets.'),
        default=bool(get_persistent_setting('skm_keep_map_shapes', True)),
        update=_on_keep_map_shapes_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_mirror_axis', bpy.props.EnumProperty(
        name=_t('Axis'), description=_t('Mirror axis used by mirror tools.'),
        items=[('X', 'X', ''), ('Y', 'Y', ''), ('Z', 'Z', '')],
        default=str(get_persistent_setting('skm_mirror_axis', 'X') or 'X'),
        update=_on_mirror_axis_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_mirror_center_x', bpy.props.FloatProperty(
        name=_t('Center X'), default=float(get_persistent_setting('skm_mirror_center_x', 0.0)),
        description=_t('Mirror center coordinate.'), update=_on_mirror_center_x_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_mirror_center_y', bpy.props.FloatProperty(
        name=_t('Center Y'), default=float(get_persistent_setting('skm_mirror_center_y', 0.0)),
        description=_t('Mirror center coordinate.'), update=_on_mirror_center_y_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_mirror_center_z', bpy.props.FloatProperty(
        name=_t('Center Z'), default=float(get_persistent_setting('skm_mirror_center_z', 0.0)),
        description=_t('Mirror center coordinate.'), update=_on_mirror_center_z_update,
    ))
    lp(ledger, bpy.types.Object, 'skm_mirror_epsilon', bpy.props.FloatProperty(
        name=_t('Tolerance'), default=float(get_persistent_setting('skm_mirror_epsilon', 0.001)),
        min=0.0, precision=4, description=_t('Maximum mirrored counterpart distance.'),
        update=_on_mirror_epsilon_update,
    ))
    lp(ledger, bpy.types.Object, 'skm__suppress_apply', bpy.props.BoolProperty(
        default=False, options={'HIDDEN'},
        description=_t('Internal guard for transactional map updates.'),
    ))


def is_runtime_registered() -> bool:
    return bool(_RUNTIME_REGISTERED and _RUNTIME_STATE in {'REGISTERING', 'READY'})


def ensure_runtime_loaded(context=None) -> bool:
    del context
    return is_runtime_registered()


def show_view3d_npanel(context=None, reuse_existing: bool = True) -> bool:
    return is_runtime_registered() and _show_npanel(context, reuse_existing)


def register_runtime(ledger) -> None:
    global _RUNTIME_REGISTERED, _RUNTIME_STATE, _RUNTIME_TOKEN, _RUNTIME_LEDGER, _SKM_LAZY_RUNTIME_DIRTY
    if _RUNTIME_REGISTERED:
        if _RUNTIME_LEDGER is ledger:
            return
        raise RuntimeError('Smart Shapekey runtime is already owned by another generation')
    _RUNTIME_STATE = 'REGISTERING'
    _RUNTIME_TOKEN = ledger.token
    _RUNTIME_LEDGER = ledger
    _registration_checkpoint('begin')
    restore_payload = begin_registration_restore()
    try:
        _sss_ownership.new_session_generation()
        _sss_ownership.new_file_generation()
        # Migration is bounded to the suite config directory and never mutates
        # Blender Scene datablocks. It runs only at this explicit register boundary.
        if _sss_storage is not None:
            migrate = getattr(_sss_storage, 'migrate_legacy_extension_data', None)
            if callable(migrate):
                migrate()
        _registration_checkpoint('after_migration')

        _register_translation_resource(ledger)
        _sss_common.register(ledger)
        _register_icon_resource(ledger)
        _registration_checkpoint('after_shared_resources')

        for cls in classes:
            _sss_lifecycle.register_class(ledger, cls)
        _registration_checkpoint('after_runtime_classes')

        _register_runtime_rna(ledger)
        _registration_checkpoint('after_runtime_rna')

        _register_bundled_tool_modules(ledger)
        _registration_checkpoint('after_bundled_modules')

        _retire_stale_handler_residue()
        for handler_name, callback in (
            ('load_pre', _skm_smart_tools_load_pre),
            ('load_post', _skm_smart_tools_load_post),
            ('save_pre', _skm_smart_tools_save_pre),
            ('save_userpref_pre', _skm_smart_tools_save_userpref_pre),
        ):
            collection = getattr(getattr(bpy.app, 'handlers', None), handler_name, None)
            if collection is not None:
                _sss_lifecycle.append_handler(ledger, collection, callback, label=f'{handler_name}:{callback.__name__}')
        _registration_checkpoint('after_handlers')

        _adopt_persistent_ref_collection()
        _adopt_loaded_reference_graphs(getattr(bpy, 'context', None))
        _sss_activity.new_generation(teardown_existing=True)
        apply_registration_restore(restore_payload, getattr(bpy, 'context', None))
        _SKM_LAZY_RUNTIME_DIRTY = False
        _RUNTIME_REGISTERED = True
        _registration_checkpoint('registered')
    except Exception:
        abort_runtime_registration()
        raise


def mark_runtime_ready(token) -> None:
    global _RUNTIME_STATE
    if not _RUNTIME_REGISTERED or _RUNTIME_TOKEN is not token:
        raise RuntimeError('runtime READY identity mismatch')
    if not _sss_lifecycle.generation_is_current(token):
        raise RuntimeError('runtime READY requested for inactive generation')
    _RUNTIME_STATE = 'READY'
    end_registration_restore()
    _sync_all_always_on_settings(getattr(bpy, 'context', None))
    _notify_settings_issue_once(getattr(bpy, 'context', None))


def abort_runtime_registration() -> None:
    global _RUNTIME_REGISTERED, _RUNTIME_STATE, _RUNTIME_TOKEN, _RUNTIME_LEDGER
    global _SKM_REGISTRATION_WRITE_GUARD_DEPTH, _SKM_SETTINGS_PENDING
    teardown_runtime_activity('registration_abort')
    _unregister_bundled_runtime_state()
    _RUNTIME_REGISTERED = False
    _RUNTIME_STATE = 'INACTIVE'
    _RUNTIME_TOKEN = None
    _RUNTIME_LEDGER = None
    _SKM_REGISTRATION_WRITE_GUARD_DEPTH = 0
    _SKM_SETTINGS_PENDING = None
    _SKM_WRITE_BARRIER.stop()


def unregister_runtime() -> None:
    global _RUNTIME_REGISTERED, _RUNTIME_STATE, _RUNTIME_TOKEN, _RUNTIME_LEDGER
    global _SKM_REGISTRATION_WRITE_GUARD_DEPTH, _SKM_SETTINGS_PENDING
    if _RUNTIME_STATE == 'INACTIVE' and not _RUNTIME_REGISTERED:
        teardown_runtime_activity('idempotent_unregister')
        return
    _RUNTIME_STATE = 'STOPPING'
    teardown_runtime_activity('unregister')
    _unregister_bundled_runtime_state()
    _clear_runtime_caches()
    _RUNTIME_REGISTERED = False
    _RUNTIME_STATE = 'INACTIVE'
    _RUNTIME_TOKEN = None
    _RUNTIME_LEDGER = None
    _SKM_REGISTRATION_WRITE_GUARD_DEPTH = 0
    _SKM_SETTINGS_PENDING = None
    _SKM_WRITE_BARRIER.stop()


def runtime_audit_snapshot() -> dict[str, object]:
    return {
        'registered': bool(_RUNTIME_REGISTERED),
        'state': _RUNTIME_STATE,
        'lifecycle': _sss_lifecycle.resource_snapshot(),
        'activity': _sss_activity.resource_snapshot(),
        'manager_rule_cache_size': len(_SKM_MANAGER_RULE_CACHE),
        'uv_enum_cache_size': len(_UV_ENUM_ITEMS_CACHE),
        'settings_dirty': bool(_sss_settings_io.STATE.dirty),
        'settings_last_error': str(_sss_settings_io.STATE.last_error or ''),
        'settings_write_barrier': _SKM_WRITE_BARRIER.snapshot(),
    }
