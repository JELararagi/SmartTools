# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Embed the modifier checklist in the Smart Shapekey sidebar."""
import bpy
from .apply_modifiers_with_shape_keys import ModifierList,OBJECT_OT_apply_modifiers_with_shape_keys,message
classes=[ModifierList,OBJECT_OT_apply_modifiers_with_shape_keys]

def draw_apply_modifiers_body(layout,context):
    obj=getattr(context,'active_object',None)
    if obj is None or obj.type!='MESH' or not obj.select_get():
        text=message('Select a mesh to start.','メッシュを選択してください。')
    elif obj.mode!='OBJECT':
        text=message('Switch to Object Mode to apply a modifier.','適用するにはオブジェクトモードに切り替えてください。')
    elif not obj.data.shape_keys:
        text=message('This mesh has no shape keys.','このメッシュにはシェイプキーがありません。')
    elif not obj.modifiers:
        text=message('This mesh has no modifiers.','このメッシュにはモディファイアがありません。')
    else:
        layout.operator(OBJECT_OT_apply_modifiers_with_shape_keys.bl_idname,text=message('Choose Modifiers','モディファイアを選択'),icon='MODIFIER')
        return
    layout.label(text=text)

class AMWSK_PT_smarttools_panel(bpy.types.Panel):
    bl_idname='AMWSK_PT_smarttools_panel'
    bl_label=message('Apply Keeping Shape Keys','シェイプキー保持で適用')
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Smart Shapekey'
    bl_options={'DEFAULT_CLOSED'}
    @classmethod
    def poll(cls,context):
        # The modern unified sidebar draws the body in its own section.
        return False
    def draw(self,context):draw_apply_modifiers_body(self.layout,context)
    def draw_header_preset(self,context):
        self.layout.operator('skm.show_help',text='',icon='QUESTION').tool_id='apply_modifiers'

def register(ledger):
    from .. import lifecycle
    for cls in classes:lifecycle.register_class(ledger,cls)

def unregister():
    # The parent unregisters classes through the same lifecycle ledger.
    pass
