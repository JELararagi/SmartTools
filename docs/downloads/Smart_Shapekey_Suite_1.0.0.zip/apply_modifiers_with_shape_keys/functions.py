# SPDX-License-Identifier: GPL-3.0-or-later
"""Evaluate each absolute shape in an isolated object, then exchange the prepared mesh."""
from array import array
from contextlib import contextmanager

import bmesh
import bpy


def _coords(items):
    flat = array('f', [0.0]) * (len(items) * 3)
    items.foreach_get('co', flat)
    return flat


def _topology(mesh):
    signature = []
    for seq, field, width in ((mesh.edges, 'vertices', 2), (mesh.loops, 'vertex_index', 1),
                              (mesh.polygons, 'loop_start', 1), (mesh.polygons, 'loop_total', 1)):
        values = array('i', [0]) * (len(seq) * width)
        seq.foreach_get(field, values)
        signature.append(values)
    return (len(mesh.vertices), *signature)


def morph_maps_block_apply(obj):
    attrs = getattr(getattr(obj, 'data', None), 'attributes', None)
    if getattr(obj,'skm_maps',None) or obj.get('skm_ref_object_name'):
        return True
    if not attrs:
        return False
    return any(a.name.startswith('.skm_morphmapper_') for a in attrs)


def morph_maps_block_message(context):
    if bpy.app.translations.locale.startswith('ja'):
        return 'マップのある衣装や顔は、マップを書き出した複製で適用してください。'
    return 'Export the morph maps and apply modifiers on a copy without maps.'


def _ensure_mesh(obj):
    if obj is None or obj.type != 'MESH' or obj.mode != 'OBJECT':
        raise ValueError('Select a mesh in Object Mode.')
    if not obj.is_editable or not obj.data.is_editable:
        raise ValueError('The active mesh is read-only.')


@contextmanager
def _duplicate(context, source):
    data = source.data.copy()
    dup = None
    copied_key = data.shape_keys
    key_id = copied_key.as_pointer() if copied_key else 0
    try:
        dup = source.copy()
        dup.data = data
        context.scene.collection.objects.link(dup)
        dup.hide_render = True
        dup.hide_viewport = False
        yield dup
    finally:
        if dup is not None:
            bpy.data.objects.remove(dup, do_unlink=True)
        if data.users == 0:
            bpy.data.meshes.remove(data)
        # Clearing shapes can leave this scratch mesh's disconnected Key in Main.
        orphan = next((k for k in bpy.data.shape_keys if k.as_pointer() == key_id and k.user is None), None)
        if orphan is not None:
            bpy.data.batch_remove(ids=(orphan,))


def _write_key(key, rows):
    if len(rows) != len(key.data):
        raise ValueError('The stored map and the destination have different vertex counts.')
    xyz = array('f', (component for row in rows for component in row))
    if len(xyz) != 3 * len(key.data):
        raise ValueError('Each vertex requires three coordinates.')
    key.data.foreach_set('co', xyz)


def rebuild_shape_key_graph(source_obj, target_obj, *, coordinate_overrides=None, appended_keys=(), excluded_keys=()):
    """Finish a staged Mesh.copy created by the mapper, preserving its native Key animation."""
    if source_obj.data == target_obj.data:
        raise ValueError('Shape keys must be prepared on an independent mesh.')
    src = source_obj.data.shape_keys
    dst = target_obj.data.shape_keys
    if src and (not dst or src == dst or list(src.key_blocks.keys()) != list(dst.key_blocks.keys())):
        raise ValueError('A native, independent copy of the shape-key graph is required.')
    if src and dst:
        _remap_copied_driver_targets(src, dst, source_obj, target_obj, destination_object=source_obj)
    for name in excluded_keys:
        if dst and (key := dst.key_blocks.get(name)) is not None:
            target_obj.shape_key_remove(key)
    for name, rows in (coordinate_overrides or {}).items():
        _write_key(target_obj.data.shape_keys.key_blocks[name], rows)
    for name, rows in appended_keys:
        block = target_obj.shape_key_add(name=name, from_mix=False)
        if block.name != name:
            raise ValueError('Duplicate shape key: ' + name)
        _write_key(block, rows)
    target_obj.data.update()


def _remap_copied_driver_targets(old, new, src, staged, destination_object):
    anim = new.animation_data
    if not anim:
        return
    for fc in anim.drivers:
        for variable in fc.driver.variables:
            for target in variable.targets:
                target_id = target.id
                if target_id == old:
                    target.id = new
                elif target_id == src.data:
                    target.id = staged.data
                elif target_id == staged:
                    target.id = destination_object


def _group_weights(mesh, index):
    return [
        next((membership.weight for membership in vertex.groups if membership.group == index), 0.0)
        for vertex in mesh.vertices
    ]


def _mesh_at_shape(context, obj, depsgraph, points):
    obj.data.vertices.foreach_set('co', points)
    obj.data.update()
    context.view_layer.update()
    return obj.evaluated_get(depsgraph)


def _shape_sample(context, obj, depsgraph, points, topology, *, required=True):
    evaluated = _mesh_at_shape(context, obj, depsgraph, points)
    mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        if _topology(mesh) == topology:
            return _coords(mesh.vertices)
        if required:
            raise ValueError('A selected modifier changes vertex correspondence between shapes.')
        return None
    finally:
        evaluated.to_mesh_clear()


def _shape_with_baked_mask(points, weights, reference_points, evaluate, output_weights, output_reference):
    # Blender will still apply the group to the stored delta. Solve for that delta
    # using the evaluated preview so fractional weights are applied exactly once.
    preview = array('f', (
        anchor + weights[index // 3] * (value - anchor)
        for index, (value, anchor) in enumerate(zip(points, reference_points))
    ))
    rendered = evaluate(preview)
    decoded = array('f', output_reference)
    fallback = []
    float_max = 3.4028234663852886e38  # Blender stores key coordinates as float32.
    for start, weight in zip(range(0, len(rendered), 3), output_weights):
        if weight:
            raw = [
                output_reference[i] + (rendered[i] - output_reference[i]) / weight
                for i in range(start, start + 3)
            ]
            if all(-float_max <= component <= float_max for component in raw):
                decoded[start:start + 3] = array('f', raw)
                continue
        # A zero or extremely small weight may hide a displacement that the
        # modifier transported from a neighbour. Keep finite, editable geometry.
        fallback.append(start)
    if fallback:
        unmasked = evaluate(points, required=False)
        if unmasked is not None:
            for start in fallback:
                decoded[start:start + 3] = unmasked[start:start + 3]
    return decoded


def _prepare_evaluated(context, source, evaluate, selected, staged):
    key_data = source.data.shape_keys
    if not key_data or not staged.data.shape_keys or staged.data.shape_keys == key_data:
        raise ValueError('Cannot isolate the shape keys.')
    reference = key_data.reference_key
    if reference is None:
        raise ValueError('No reference shape was available.')
    evaluate.animation_data_clear()
    evaluate.shape_key_clear()
    for modifier in list(evaluate.modifiers):
        if modifier.name not in selected:
            evaluate.modifiers.remove(modifier)
        else:
            modifier.show_viewport = True
    depsgraph = context.evaluated_depsgraph_get()
    source_basis = _coords(reference.data)
    evaluated = _mesh_at_shape(context, evaluate, depsgraph, source_basis)
    basis = bpy.data.meshes.new_from_object(evaluated, preserve_all_data_layers=True, depsgraph=depsgraph)
    try:
        topology = _topology(basis)
        output_basis = _coords(basis.vertices)
        shapes = {reference.name: output_basis}

        def sample(points, *, required=True):
            return _shape_sample(context, evaluate, depsgraph, points, topology, required=required)

        for key in key_data.key_blocks:
            if key == reference:
                continue
            points = _coords(key.data)
            mask = source.vertex_groups.get(key.vertex_group) if key.vertex_group else None
            if mask is not None and key_data.use_relative and key.relative_key == reference:
                shapes[key.name] = _shape_with_baked_mask(
                    points, _group_weights(source.data, mask.index), source_basis, sample,
                    _group_weights(basis, mask.index), output_basis,
                )
            elif mask is not None:
                # Keep the existing sampling path for absolute and chained keys.
                weights = _group_weights(source.data, mask.index)
                for i, anchor in enumerate(source_basis):
                    points[i] = anchor + weights[i // 3] * (points[i] - anchor)
                shapes[key.name] = sample(points)
            else:
                shapes[key.name] = sample(points)
        _replace_shape_geometry(staged.data, basis, shapes)
        _remap_copied_driver_targets(key_data, staged.data.shape_keys, source, staged, destination_object=source)
    finally:
        if basis.users == 0:
            bpy.data.meshes.remove(basis)


def _replace_shape_geometry(mesh, basis, shapes):
    bm = bmesh.new()
    try:
        bm.from_mesh(basis)
        bm.to_mesh(mesh)
    finally:
        bm.free()
    if _topology(mesh) != _topology(basis):
        raise ValueError('Staged mesh topology did not match its evaluated reference.')
    for name, points in shapes.items():
        block = mesh.shape_keys.key_blocks[name]
        if len(block.data)*3 != len(points):
            raise ValueError('Staged shape key has an incorrect length.')
        block.data.foreach_set('co', points)
    mesh.vertices.foreach_set('co', _coords(basis.vertices))
    mesh.update()


def apply_modifiers_with_shape_keys(context, selected_modifiers):
    source = context.active_object
    try:
        _ensure_mesh(source)
        if not source.data.shape_keys or morph_maps_block_apply(source):
            raise ValueError(morph_maps_block_message(context))
        names = list(selected_modifiers)
        if not names or len(set(names)) != len(names) or any(name not in source.modifiers for name in names):
            raise ValueError('Choose a current modifier once.')
        modifiers = [m for m in source.modifiers if m.name in names]
        unsafe = {'BOOLEAN','DECIMATE','REMESH','BEVEL','WELD','BUILD','MASK','NODES','PARTICLE_SYSTEM','FLUID','DYNAMIC_PAINT'}
        if any(m.type in unsafe for m in modifiers):
            raise ValueError('The chosen modifier may assign different vertices to different shapes.')
        active = source.active_shape_key_index
        with _duplicate(context, source) as staged, _duplicate(context, source) as evaluate:
            _prepare_evaluated(context, source, evaluate, set(names), staged)
            previous = source.data
            source.data = staged.data
            try:
                source.active_shape_key_index = active
                for mod in modifiers:
                    source.modifiers.remove(mod)
            except (RuntimeError, ReferenceError):
                source.data = previous
                raise
        return True, ''
    except (ValueError, RuntimeError, ReferenceError, KeyError, TypeError) as exc:
        return False, str(exc)
