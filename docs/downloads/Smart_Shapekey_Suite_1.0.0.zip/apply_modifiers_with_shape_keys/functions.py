# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package
"""Transactional modifier application while preserving Shape Keys.

The source Object/Mesh/Key datablocks are never edited during staging.  A fully
reconstructed mesh and Key datablock is validated on private temporary objects,
then committed with one ``Object.data`` swap.  Every failure before or during
commit returns the source to its exact prior mesh/modifier/context state.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable
from array import array
import copy
import uuid

import bpy
from idprop.types import IDPropertyArray, IDPropertyGroup

try:
    from .. import translation as _sss_translation
except Exception:
    _sss_translation = None


_FAULT_INJECTION_HOOK: Callable[[str], None] | None = None


def _checkpoint(name: str) -> None:
    hook = _FAULT_INJECTION_HOOK
    if callable(hook):
        hook(str(name))


def _l(en: str, ja: str | None = None, context=None) -> str:
    try:
        if _sss_translation is not None:
            return _sss_translation.ui_text(en, ja, context)
    except Exception:
        pass
    return str(en)


@dataclass(slots=True)
class _ContextSnapshot:
    active: Any
    selected: tuple[Any, ...]
    mode: str
    active_shape_index: int
    show_only_shape_key: bool


@dataclass(slots=True)
class _Stage:
    objects: list[Any] = field(default_factory=list)
    meshes: list[Any] = field(default_factory=list)
    actions: list[Any] = field(default_factory=list)
    # Preserve shared Action identity across active Action and NLA strips while
    # rebuilding the private staged Key datablock.
    action_map: dict[int, Any] = field(default_factory=dict)
    committed_mesh: Any = None

    def remove_object(self, obj) -> None:
        if obj is None:
            return
        mesh = getattr(obj, "data", None)
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            return
        if obj in self.objects:
            self.objects.remove(obj)
        if mesh in self.meshes and mesh is not self.committed_mesh and getattr(mesh, "users", 0) == 0:
            try:
                bpy.data.meshes.remove(mesh)
            except Exception:
                pass
            try:
                self.meshes.remove(mesh)
            except ValueError:
                pass

    def cleanup(self) -> None:
        for obj in tuple(reversed(self.objects)):
            self.remove_object(obj)
        for mesh in tuple(reversed(self.meshes)):
            if mesh is self.committed_mesh:
                continue
            try:
                if getattr(mesh, "users", 0) == 0:
                    bpy.data.meshes.remove(mesh)
            except Exception:
                pass
        for action in tuple(reversed(self.actions)):
            try:
                if getattr(action, "users", 0) == 0:
                    bpy.data.actions.remove(action)
            except Exception:
                pass
        self.objects.clear()
        self.meshes[:] = [mesh for mesh in self.meshes if mesh is self.committed_mesh]
        self.actions.clear()
        self.action_map.clear()


def _context_snapshot(context, obj) -> _ContextSnapshot:
    view_layer = getattr(context, "view_layer", None)
    active = getattr(getattr(view_layer, "objects", None), "active", None)
    try:
        selected = tuple(getattr(context, "selected_objects", ()) or ())
    except Exception:
        selected = ()
    return _ContextSnapshot(
        active=active,
        selected=selected,
        mode=str(getattr(active, "mode", "OBJECT") or "OBJECT"),
        active_shape_index=int(getattr(obj, "active_shape_key_index", 0) or 0),
        show_only_shape_key=bool(getattr(obj, "show_only_shape_key", False)),
    )


def _restore_context(context, snapshot: _ContextSnapshot, obj) -> None:
    view_layer = getattr(context, "view_layer", None)
    try:
        for candidate in tuple(getattr(view_layer, "objects", ()) or ()):
            if hasattr(candidate, "select_set"):
                candidate.select_set(candidate in snapshot.selected)
    except Exception:
        pass
    try:
        if view_layer is not None:
            view_layer.objects.active = snapshot.active
    except Exception:
        pass
    try:
        obj.active_shape_key_index = snapshot.active_shape_index
        obj.show_only_shape_key = snapshot.show_only_shape_key
    except Exception:
        pass
    if snapshot.active is not None and snapshot.mode not in {"", "OBJECT"}:
        try:
            with context.temp_override(
                object=snapshot.active,
                active_object=snapshot.active,
                selected_objects=list(snapshot.selected),
                selected_editable_objects=list(snapshot.selected),
            ):
                bpy.ops.object.mode_set(mode=snapshot.mode)
        except Exception:
            pass


def _best_link_collection(context, source_obj):
    users = tuple(getattr(source_obj, "users_collection", ()) or ())
    if users:
        return users[0]
    layer = getattr(getattr(context, "view_layer", None), "active_layer_collection", None)
    return getattr(layer, "collection", None) or getattr(context, "collection", None) or getattr(getattr(context, "scene", None), "collection", None)


def duplicate_object(context, obj, *, stage: _Stage | None = None):
    new_obj = obj.copy()
    new_obj.data = obj.data.copy()
    # The scene collection is always part of the view layer, even when the source's collection is hidden.
    collection = getattr(getattr(context, "scene", None), "collection", None) or _best_link_collection(context, obj)
    if collection is None:
        raise RuntimeError(_l("No collection was available for the temporary duplicate object.", "一時複製オブジェクトを配置するコレクションが見つかりませんでした。", context))
    collection.objects.link(new_obj)
    new_obj.name = f".__SKM_STAGE_{uuid.uuid4().hex}"
    new_obj.hide_render = True
    # A viewport-disabled object is not in the depsgraph, so its modifiers would not be evaluated.
    new_obj.hide_viewport = False
    if stage is not None:
        stage.objects.append(new_obj)
        stage.meshes.append(new_obj.data)
    return new_obj


def _remove_object_and_mesh(obj):
    if obj is None:
        return
    mesh = getattr(obj, "data", None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return
    if mesh is not None and getattr(mesh, "users", 0) == 0:
        try:
            bpy.data.meshes.remove(mesh)
        except Exception:
            pass


def disable_modifiers(obj, selected_modifiers):
    saved: list[tuple[Any, bool]] = []
    selected = set(selected_modifiers or ())
    for modifier in tuple(getattr(obj, "modifiers", ()) or ()):
        value = bool(getattr(modifier, "show_viewport", False))
        saved.append((modifier, value))
        modifier.show_viewport = modifier.name in selected
    return saved


def _restore_modifier_visibility(saved) -> None:
    for modifier, value in saved:
        try:
            modifier.show_viewport = bool(value)
        except Exception:
            pass


def evaluate_mesh(context, obj):
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    if eval_obj is obj:
        raise RuntimeError(_l("The modifiers could not be evaluated.", "モディファイアを評価できませんでした。", context))
    return bpy.data.meshes.new_from_object(eval_obj, preserve_all_data_layers=True, depsgraph=depsgraph)


def apply_modifier_to_object(context, obj, selected_modifiers):
    """Compatibility helper that swaps only a temporary object's evaluated mesh."""
    saved = disable_modifiers(obj, selected_modifiers)
    try:
        mesh = evaluate_mesh(context, obj)
        old = obj.data
        obj.data = mesh
        if old is not None and getattr(old, "users", 0) == 0:
            bpy.data.meshes.remove(old)
        for name in tuple(selected_modifiers):
            modifier = obj.modifiers.get(name)
            if modifier is not None:
                obj.modifiers.remove(modifier)
        return mesh
    finally:
        _restore_modifier_visibility(saved)


def _simple_rna_snapshot(value) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if hasattr(value, "to_tuple"):
        try:
            return tuple(value.to_tuple())
        except Exception:
            pass
    try:
        return tuple(value)
    except Exception:
        return value


def _writable_properties(owner, *, exclude: set[str] | None = None) -> dict[str, Any]:
    """Snapshot assignable scalar/array/pointer RNA without traversing collections.

    ID pointers (Object, NodeTree, Texture, etc.) must be preserved when a
    modifier stack is reconstructed during rollback.  Collection properties are
    intentionally excluded because assigning them is unsupported by Blender RNA.
    """
    exclude = set(exclude or ()) | {"rna_type"}
    out: dict[str, Any] = {}
    for prop in tuple(getattr(getattr(owner, "bl_rna", None), "properties", ()) or ()):
        name = str(getattr(prop, "identifier", "") or "")
        if not name or name in exclude or bool(getattr(prop, "is_readonly", False)):
            continue
        if str(getattr(prop, "type", "") or "") == "COLLECTION":
            continue
        try:
            value = getattr(owner, name)
        except Exception:
            continue
        if isinstance(value, (bool, int, float, str)) or value is None or hasattr(value, "to_tuple"):
            out[name] = _simple_rna_snapshot(value)
            continue
        # Blender ID/RNA pointers are stable identities and are safe to retain.
        if hasattr(value, "bl_rna") or hasattr(value, "as_pointer"):
            out[name] = value
            continue
        try:
            out[name] = tuple(value)
        except Exception:
            # Unsupported non-assignable values are skipped rather than copied
            # recursively, which could traverse arbitrary user datablocks.
            continue
    return out


def _assign_properties(owner, values: dict[str, Any]) -> None:
    for name, value in values.items():
        try:
            setattr(owner, name, value)
        except Exception:
            pass


def save_shape_key_properties(obj):
    properties = OrderedDict()
    keys = getattr(getattr(getattr(obj, "data", None), "shape_keys", None), "key_blocks", None)
    if not keys:
        return properties
    for key in keys:
        properties[key.name] = {
            "properties": _writable_properties(key, exclude={"name", "relative_key"}),
            "relative_name": str(getattr(getattr(key, "relative_key", None), "name", "") or ""),
        }
    return properties


def restore_shape_key_properties(obj, property_dict):
    keys = getattr(getattr(getattr(obj, "data", None), "shape_keys", None), "key_blocks", None)
    if not keys:
        return
    for name, payload in dict(property_dict or {}).items():
        key = keys.get(name)
        if key is not None:
            _assign_properties(key, dict(payload.get("properties") or {}))
    for name, payload in dict(property_dict or {}).items():
        key = keys.get(name)
        relative = keys.get(str(payload.get("relative_name") or ""))
        if key is not None and relative is not None:
            try:
                key.relative_key = relative
            except Exception:
                pass


def join_as_shape(temp_obj, original_obj):
    source = temp_obj.shape_key_add(from_mix=False)
    target = original_obj.shape_key_add(from_mix=False)
    if len(source.data) != len(target.data):
        raise RuntimeError("shape vertex count mismatch")
    for source_vert, target_vert in zip(source.data, target.data):
        target_vert.co = source_vert.co


def _snapshot_fcurve(fcurve) -> dict[str, Any]:
    # Capture every assignable FCurve/keyframe-point field, not only the common
    # interpolation fields.  This preserves amplitude/back/period, selection,
    # auto-smoothing/color state and future scalar RNA added by Blender.
    points = [
        _writable_properties(point)
        for point in tuple(getattr(fcurve, "keyframe_points", ()) or ())
    ]
    modifiers = []
    for modifier in tuple(getattr(fcurve, "modifiers", ()) or ()):
        modifiers.append({"type": modifier.type, "properties": _writable_properties(modifier, exclude={"type", "name"})})
    return {
        "data_path": str(fcurve.data_path),
        "array_index": int(fcurve.array_index),
        "group": str(getattr(getattr(fcurve, "group", None), "name", "") or ""),
        "properties": _writable_properties(
            fcurve,
            exclude={"data_path", "array_index", "group", "driver", "keyframe_points", "modifiers"},
        ),
        "points": points,
        "modifiers": modifiers,
    }


def _iter_action_fcurves(action) -> tuple[Any, ...]:
    """Return every discoverable Action FCurve without assuming legacy storage.

    Blender 5.x Actions may expose layered slot/channelbag storage rather than the
    legacy top-level ``action.fcurves`` collection.  This bounded identity walk is
    performed only during the explicit staging operation, never from draw/timer.
    """
    found: list[Any] = []
    seen: set[int] = set()

    def add_from(owner) -> None:
        try:
            curves = tuple(getattr(owner, "fcurves", ()) or ())
        except Exception:
            curves = ()
        for curve in curves:
            marker = id(curve)
            if marker not in seen:
                seen.add(marker)
                found.append(curve)

    add_from(action)
    try:
        layers = tuple(getattr(action, "layers", ()) or ())
    except Exception:
        layers = ()
    for layer in layers:
        try:
            strips = tuple(getattr(layer, "strips", ()) or ())
        except Exception:
            strips = ()
        for strip in strips:
            add_from(strip)
            try:
                channelbags = tuple(getattr(strip, "channelbags", ()) or ())
            except Exception:
                channelbags = ()
            for channelbag in channelbags:
                add_from(channelbag)
    return tuple(found)


def _action_slot_manifest(action) -> tuple[tuple[str, int, str], ...]:
    out: list[tuple[str, int, str]] = []
    try:
        slots = tuple(getattr(action, "slots", ()) or ())
    except Exception:
        slots = ()
    for slot in slots:
        identifier = str(getattr(slot, "identifier", "") or getattr(slot, "name", "") or "")
        try:
            handle = int(getattr(slot, "handle", 0) or 0)
        except Exception:
            handle = 0
        target_id_type = str(getattr(slot, "target_id_type", "") or "")
        out.append((identifier, handle, target_id_type))
    return tuple(out)


def _action_layer_manifest(action) -> tuple[tuple[str, tuple[tuple[str, str], ...]], ...]:
    out: list[tuple[str, tuple[tuple[str, str], ...]]] = []
    try:
        layers = tuple(getattr(action, "layers", ()) or ())
    except Exception:
        layers = ()
    for layer in layers:
        layer_name = str(getattr(layer, "name", "") or "")
        strips_out: list[tuple[str, str]] = []
        try:
            strips = tuple(getattr(layer, "strips", ()) or ())
        except Exception:
            strips = ()
        for strip in strips:
            strips_out.append((str(getattr(strip, "name", "") or ""), str(getattr(strip, "type", "") or "")))
        out.append((layer_name, tuple(strips_out)))
    return tuple(out)


def _action_fingerprint(action) -> dict[str, Any] | None:
    if action is None:
        return None
    return {
        "slots": _action_slot_manifest(action),
        "layers": _action_layer_manifest(action),
        "fcurves": tuple(_snapshot_fcurve(fc) for fc in _iter_action_fcurves(action)),
    }


def _snapshot_action_slot(owner) -> dict[str, Any]:
    out: dict[str, Any] = {}
    slot = None
    try:
        slot = getattr(owner, "action_slot", None)
    except Exception:
        slot = None
    if slot is not None:
        out["identifier"] = str(getattr(slot, "identifier", "") or getattr(slot, "name", "") or "")
        try:
            out["handle"] = int(getattr(slot, "handle", 0) or 0)
        except Exception:
            out["handle"] = 0
    for attr in ("action_slot_identifier", "last_slot_identifier"):
        try:
            value = getattr(owner, attr)
        except Exception:
            continue
        if isinstance(value, str):
            out[attr] = value
    try:
        value = getattr(owner, "action_slot_handle")
        if type(value) is int:
            out["action_slot_handle"] = int(value)
    except Exception:
        pass
    return out


def _restore_action_slot(owner, snapshot: dict[str, Any] | None, action) -> None:
    if owner is None or action is None or not snapshot:
        return
    identifier = str(snapshot.get("identifier") or snapshot.get("action_slot_identifier") or snapshot.get("last_slot_identifier") or "")
    try:
        handle = int(snapshot.get("handle", snapshot.get("action_slot_handle", 0)) or 0)
    except Exception:
        handle = 0
    selected = None
    try:
        slots = tuple(getattr(action, "slots", ()) or ())
    except Exception:
        slots = ()
    for slot in slots:
        slot_identifier = str(getattr(slot, "identifier", "") or getattr(slot, "name", "") or "")
        try:
            slot_handle = int(getattr(slot, "handle", 0) or 0)
        except Exception:
            slot_handle = 0
        if (identifier and slot_identifier == identifier) or (handle and slot_handle == handle):
            selected = slot
            break
    if selected is not None and hasattr(owner, "action_slot"):
        try:
            owner.action_slot = selected
            return
        except Exception:
            pass
    # Compatibility fallback for Blender builds exposing scalar slot selectors.
    for attr, value in (
        ("action_slot_identifier", identifier),
        ("last_slot_identifier", identifier),
        ("action_slot_handle", handle),
    ):
        if not value or not hasattr(owner, attr):
            continue
        try:
            setattr(owner, attr, value)
            return
        except Exception:
            pass


def _snapshot_action(action) -> dict[str, Any] | None:
    if action is None:
        return None
    return {
        # The exact source ID is read-only staging input. ``Action.copy`` preserves
        # layered slots, channelbags, groups, FCurve modifiers and future Action
        # fields more completely than manually reconstructing known RNA alone.
        "source_action": action,
        "name": str(action.name),
        "properties": _writable_properties(action, exclude={"name"}),
        "custom_properties": {str(key): copy.deepcopy(action[key]) for key in tuple(action.keys()) if str(key) != "_RNA_UI"},
        "fcurves": [_snapshot_fcurve(fc) for fc in tuple(getattr(action, "fcurves", ()) or ())],
        "fingerprint": _action_fingerprint(action),
    }


def _restore_action(snapshot: dict[str, Any] | None, stage: _Stage):
    if not snapshot:
        return None
    source_action = snapshot.get("source_action")
    if source_action is not None:
        cached = stage.action_map.get(id(source_action))
        if cached is not None:
            return cached
        copier = getattr(source_action, "copy", None)
        if callable(copier):
            try:
                action = copier()
                action.name = f"{snapshot.get('name', 'Action')}.__SKM_STAGE"
                stage.actions.append(action)
                stage.action_map[id(source_action)] = action
                expected = snapshot.get("fingerprint")
                if expected is not None and _action_fingerprint(action) != expected:
                    raise RuntimeError("staged layered Action fingerprint mismatch")
                return action
            except Exception:
                # Remove a partially copied Action before falling back to the
                # legacy reconstruction path. Source action remains untouched.
                try:
                    if 'action' in locals() and action is not None and getattr(action, "users", 0) == 0:
                        bpy.data.actions.remove(action)
                except Exception:
                    pass
                try:
                    if 'action' in locals() and action in stage.actions:
                        stage.actions.remove(action)
                except Exception:
                    pass
                stage.action_map.pop(id(source_action), None)

    action = bpy.data.actions.new(name=f"{snapshot.get('name', 'Action')}.__SKM_STAGE")
    stage.actions.append(action)
    if source_action is not None:
        stage.action_map[id(source_action)] = action
    _assign_properties(action, dict(snapshot.get("properties") or {}))
    for key, value in dict(snapshot.get("custom_properties") or {}).items():
        try:
            action[key] = copy.deepcopy(value)
        except Exception:
            pass
    for data in snapshot.get("fcurves", ()):
        group = str(data.get("group") or "") or None
        fc = action.fcurves.new(str(data["data_path"]), index=int(data.get("array_index", 0)), action_group=group)
        _assign_properties(fc, dict(data.get("properties") or {}))
        points = list(data.get("points") or ())
        if points:
            fc.keyframe_points.add(len(points))
            for point, source in zip(fc.keyframe_points, points):
                _assign_properties(point, source)
        for modifier_data in data.get("modifiers", ()):
            modifier = fc.modifiers.new(str(modifier_data.get("type") or "GENERATOR"))
            _assign_properties(modifier, dict(modifier_data.get("properties") or {}))
    return action

def _snapshot_driver_fcurve(fcurve) -> dict[str, Any]:
    driver = fcurve.driver
    variables = []
    for variable in tuple(getattr(driver, "variables", ()) or ()):
        targets = []
        for target in tuple(getattr(variable, "targets", ()) or ()):
            targets.append({
                "id_type": getattr(target, "id_type", None),
                "id": getattr(target, "id", None),
                "data_path": str(getattr(target, "data_path", "") or ""),
                "bone_target": str(getattr(target, "bone_target", "") or ""),
                "transform_type": getattr(target, "transform_type", None),
                "transform_space": getattr(target, "transform_space", None),
                "rotation_mode": getattr(target, "rotation_mode", None),
            })
        variables.append({"name": variable.name, "type": variable.type, "targets": targets})
    data = _snapshot_fcurve(fcurve)
    data["driver"] = {
        "type": driver.type,
        "expression": driver.expression,
        "use_self": bool(getattr(driver, "use_self", False)),
        "variables": variables,
    }
    return data


def save_shape_key_drivers(obj):
    shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
    animation = getattr(shape_keys, "animation_data", None) if shape_keys is not None else None
    if animation is None:
        return []
    return [_snapshot_driver_fcurve(fc) for fc in tuple(getattr(animation, "drivers", ()) or ())]


def _restore_driver_fcurve(shape_keys, data, source_obj, target_obj):
    path = str(data["data_path"])
    resolved = shape_keys.path_resolve(path)
    index = int(data.get("array_index", 0))
    if isinstance(resolved, (bool, int, float)):
        if index != 0:
            raise IndexError(f"Scalar driver path has invalid array index: {path}[{index}]")
        fc = shape_keys.driver_add(path)
    elif hasattr(resolved, "__len__") and not isinstance(resolved, (str, bytes)):
        if not 0 <= index < len(resolved):
            raise IndexError(f"Array driver index out of range: {path}[{index}]")
        if not isinstance(resolved[index], (bool, int, float)):
            raise TypeError(f"Driver array element is not numeric: {path}[{index}]")
        fc = shape_keys.driver_add(path, index)
    else:
        raise TypeError(f"Driver path is not numeric: {path}")
    _assign_properties(fc, dict(data.get("properties") or {}))
    driver_data = data.get("driver") or {}
    driver = fc.driver
    driver.type = str(driver_data.get("type") or "SCRIPTED")
    driver.expression = str(driver_data.get("expression") or "")
    if hasattr(driver, "use_self"):
        driver.use_self = bool(driver_data.get("use_self", False))
    while len(driver.variables):
        driver.variables.remove(driver.variables[0])
    for var_data in driver_data.get("variables", ()):
        variable = driver.variables.new()
        variable.name = str(var_data.get("name") or "var")
        variable.type = str(var_data.get("type") or "SINGLE_PROP")
        for target, target_data in zip(variable.targets, var_data.get("targets", ())):
            for attr in ("id_type", "data_path", "bone_target", "transform_type", "transform_space", "rotation_mode"):
                value = target_data.get(attr)
                if value is not None and hasattr(target, attr):
                    try:
                        setattr(target, attr, value)
                    except Exception:
                        pass
            target_id = target_data.get("id")
            source_mesh = getattr(source_obj, "data", None)
            target_mesh = getattr(target_obj, "data", None)
            source_keys = getattr(source_mesh, "shape_keys", None)
            target_keys = getattr(target_mesh, "shape_keys", None)
            # The source Object survives the atomic Mesh swap, so an original
            # driver target pointing at that Object must keep the original exact
            # Object identity.  Only the replaced Mesh/Key datablocks are remapped
            # to the fully validated staged graph.  Pointing at ``target_obj``
            # would leave a dangling driver after the temporary staging Object is
            # unlinked and deleted.
            if target_id is source_obj:
                target_id = source_obj
            elif target_id is source_mesh:
                target_id = target_mesh
            elif target_id is source_keys:
                target_id = target_keys
            try:
                target.id = target_id
            except Exception:
                pass
    for modifier_data in data.get("modifiers", ()):
        modifier = fc.modifiers.new(str(modifier_data.get("type") or "GENERATOR"))
        _assign_properties(modifier, dict(modifier_data.get("properties") or {}))


def restore_shape_key_drivers(obj, copy_obj, drivers):
    shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
    if shape_keys is None:
        return
    if drivers and shape_keys.animation_data is None:
        shape_keys.animation_data_create()
    for data in tuple(drivers or ()):
        _restore_driver_fcurve(shape_keys, data, copy_obj, obj)


def copy_shape_key_animation(source_obj, target_obj, *, snapshot=None, stage: _Stage | None = None):
    source_keys = getattr(getattr(source_obj, "data", None), "shape_keys", None)
    target_keys = getattr(getattr(target_obj, "data", None), "shape_keys", None)
    if target_keys is None:
        return
    animation = getattr(source_keys, "animation_data", None) if source_keys is not None else None
    action_snapshot = snapshot if snapshot is not None else _snapshot_action(getattr(animation, "action", None))
    if action_snapshot is None:
        return
    if target_keys.animation_data is None:
        target_keys.animation_data_create()
    target_keys.animation_data.action = _restore_action(action_snapshot, stage or _Stage())



def _snapshot_nla_strip(strip) -> dict[str, Any]:
    return {
        "name": str(getattr(strip, "name", "") or "NlaStrip"),
        "frame_start": float(getattr(strip, "frame_start", 0.0)),
        "action": _snapshot_action(getattr(strip, "action", None)),
        "action_slot": _snapshot_action_slot(strip),
        "properties": _writable_properties(strip, exclude={"name", "action", "action_slot", "strips"}),
        "custom_properties": {str(key): copy.deepcopy(strip[key]) for key in tuple(strip.keys()) if str(key) != "_RNA_UI"},
    }


def _snapshot_animation_data(shape_keys) -> dict[str, Any] | None:
    animation = getattr(shape_keys, "animation_data", None) if shape_keys is not None else None
    if animation is None:
        return None
    tracks = []
    for track in tuple(getattr(animation, "nla_tracks", ()) or ()):
        tracks.append({
            "name": str(getattr(track, "name", "") or "NlaTrack"),
            "properties": _writable_properties(track, exclude={"name", "strips"}),
            "custom_properties": {
                str(key): copy.deepcopy(track[key])
                for key in tuple(getattr(track, "keys", lambda: ())())
                if str(key) != "_RNA_UI"
            },
            "strips": [_snapshot_nla_strip(strip) for strip in tuple(getattr(track, "strips", ()) or ())],
        })
    return {
        "properties": _writable_properties(animation, exclude={"action", "action_slot", "drivers", "nla_tracks"}),
        "action": _snapshot_action(getattr(animation, "action", None)),
        "action_slot": _snapshot_action_slot(animation),
        "nla_tracks": tracks,
    }


def _restore_animation_data(shape_keys, snapshot: dict[str, Any] | None, stage: _Stage) -> None:
    if shape_keys is None or not snapshot:
        return
    animation = shape_keys.animation_data_create()
    _assign_properties(animation, dict(snapshot.get("properties") or {}))
    action = _restore_action(snapshot.get("action"), stage)
    if action is not None:
        animation.action = action
        _restore_action_slot(animation, snapshot.get("action_slot"), action)
    for track_data in snapshot.get("nla_tracks", ()):
        track = animation.nla_tracks.new()
        track.name = str(track_data.get("name") or "NlaTrack")
        _assign_properties(track, dict(track_data.get("properties") or {}))
        for key, value in dict(track_data.get("custom_properties") or {}).items():
            try:
                track[key] = copy.deepcopy(value)
            except Exception:
                pass
        for strip_data in track_data.get("strips", ()):
            strip_action = _restore_action(strip_data.get("action"), stage)
            if strip_action is None:
                continue
            strip = track.strips.new(
                str(strip_data.get("name") or "NlaStrip"),
                int(round(float(strip_data.get("frame_start", 0.0)))),
                strip_action,
            )
            _assign_properties(strip, dict(strip_data.get("properties") or {}))
            _restore_action_slot(strip, strip_data.get("action_slot"), strip_action)
            for key, value in dict(strip_data.get("custom_properties") or {}).items():
                try:
                    strip[key] = copy.deepcopy(value)
                except Exception:
                    pass


def _copy_key_custom_property(value, seen: set[int] | None = None):
    """Detach native IDProperty containers without copying Blender ID owners."""
    if isinstance(value, bpy.types.ID):
        return value
    if isinstance(value, IDPropertyArray):
        return array(value.typecode, value.to_list())
    if isinstance(value, (str, bytes, bool, int, float)):
        return value
    if isinstance(value, (IDPropertyGroup, dict, list, tuple, array)):
        active = set() if seen is None else seen
        identity = id(value)
        if identity in active:
            raise ValueError("cyclic Shape Key custom property")
        active.add(identity)
        try:
            if isinstance(value, (IDPropertyGroup, dict)):
                return {str(key): _copy_key_custom_property(item, active) for key, item in value.items()}
            if isinstance(value, array):
                return array(value.typecode, value)
            copied = [_copy_key_custom_property(item, active) for item in value]
            return tuple(copied) if isinstance(value, tuple) else copied
        finally:
            active.remove(identity)
    raise TypeError(f"Unsupported Shape Key custom property type: {type(value).__name__}")


def snapshot_shape_key_graph(source_obj) -> dict[str, Any]:
    mesh = getattr(source_obj, "data", None)
    shape_keys = getattr(mesh, "shape_keys", None)
    if shape_keys is None:
        return {
            "key_properties": OrderedDict(),
            "key_coordinates": OrderedDict(),
            "key_datablock_properties": {},
            "key_datablock_custom": {},
            "animation": None,
            "drivers": [],
        }
    coordinates = OrderedDict()
    for key in tuple(shape_keys.key_blocks):
        values = []
        for point in tuple(key.data):
            values.append(tuple(point.co))
        coordinates[str(key.name)] = values
    return {
        "key_properties": save_shape_key_properties(source_obj),
        "key_coordinates": coordinates,
        "key_datablock_properties": _writable_properties(shape_keys, exclude={"name", "key_blocks", "reference_key"}),
        "key_datablock_custom": {str(key): _copy_key_custom_property(shape_keys[key]) for key in tuple(shape_keys.keys()) if str(key) != "_RNA_UI"},
        "animation": _snapshot_animation_data(shape_keys),
        "drivers": save_shape_key_drivers(source_obj),
    }


def rebuild_shape_key_graph(
    source_obj,
    target_obj,
    *,
    coordinate_overrides: dict[str, Any] | None = None,
    appended_keys: list[tuple[str, Any]] | None = None,
    excluded_keys: tuple[str, ...] = (),
    stage: _Stage | None = None,
) -> dict[str, Any]:
    """Rebuild all Shape Keys/relations/animation/drivers on a staged object."""
    own_stage = stage or _Stage()
    snapshot = snapshot_shape_key_graph(source_obj)
    overrides = dict(coordinate_overrides or {})
    for name in excluded_keys:
        snapshot["key_coordinates"].pop(name, None)
        snapshot["key_properties"].pop(name, None)
    coordinates = OrderedDict(snapshot["key_coordinates"])
    for name, values in overrides.items():
        coordinates[str(name)] = values
    for name, values in tuple(appended_keys or ()):
        coordinates[str(name)] = values
    try:
        if getattr(getattr(target_obj, "data", None), "shape_keys", None) is not None:
            target_obj.shape_key_clear()
    except Exception:
        pass
    vertex_count = len(getattr(target_obj.data, "vertices", ()) or ())
    for name, values in coordinates.items():
        key = target_obj.shape_key_add(name=str(name), from_mix=False)
        # shape_key_add starts at 1.0; keys that already existed get their value back below.
        if len(target_obj.data.shape_keys.key_blocks) > 1:
            key.value = 0.0
        if len(key.data) != vertex_count or len(values) != vertex_count:
            raise RuntimeError(f"Shape Key vertex count mismatch: {name}")
        for point, co in zip(key.data, values):
            point.co = co
    target_keys = getattr(target_obj.data, "shape_keys", None)
    if target_keys is not None:
        _assign_properties(target_keys, dict(snapshot["key_datablock_properties"]))
        for key, value in dict(snapshot["key_datablock_custom"]).items():
            target_keys[key] = _copy_key_custom_property(value)
    restore_shape_key_properties(target_obj, snapshot["key_properties"])
    _restore_animation_data(target_keys, snapshot["animation"], own_stage)
    restore_shape_key_drivers(target_obj, source_obj, snapshot["drivers"])

    expected_names = tuple(coordinates.keys())
    actual_names = tuple(key.name for key in tuple(getattr(target_keys, "key_blocks", ()) or ()))
    if actual_names != expected_names:
        raise RuntimeError("Shape Key name/order validation failed")
    for name, payload in snapshot["key_properties"].items():
        key = target_keys.key_blocks.get(name)
        relative_name = str(payload.get("relative_name") or "")
        if key is None or (relative_name and str(getattr(getattr(key, "relative_key", None), "name", "") or "") != relative_name):
            raise RuntimeError(f"Shape Key relative relation validation failed: {name}")
    drivers = tuple(getattr(getattr(target_keys, "animation_data", None), "drivers", ()) or ())
    if len(drivers) != len(snapshot["drivers"]):
        raise RuntimeError("Shape Key driver count validation failed")
    return snapshot

def _modifier_custom_properties(modifier) -> dict[str, Any]:
    # Only some modifier types (Geometry Nodes) can hold custom properties; keys() raises on the others.
    try:
        names = tuple(modifier.keys())
    except TypeError:
        return {}
    return {str(key): copy.deepcopy(modifier[key]) for key in names if str(key) != "_RNA_UI"}


def _snapshot_modifier_stack(obj) -> list[dict[str, Any]]:
    out = []
    for modifier in tuple(getattr(obj, "modifiers", ()) or ()):
        out.append({
            "name": str(modifier.name),
            "type": str(modifier.type),
            "properties": _writable_properties(modifier, exclude={"name", "type"}),
            "custom_properties": _modifier_custom_properties(modifier),
        })
    return out


def _restore_modifier_stack(obj, snapshot) -> None:
    try:
        obj.modifiers.clear()
    except Exception:
        for modifier in tuple(obj.modifiers):
            try:
                obj.modifiers.remove(modifier)
            except Exception:
                pass
    for data in snapshot:
        modifier = obj.modifiers.new(name=str(data["name"]), type=str(data["type"]))
        _assign_properties(modifier, dict(data.get("properties") or {}))
        for key, value in dict(data.get("custom_properties") or {}).items():
            try:
                modifier[key] = copy.deepcopy(value)
            except Exception:
                pass


def _prepare_shape_for_evaluation(obj, key_index: int) -> None:
    keys = getattr(getattr(obj.data, "shape_keys", None), "key_blocks", None)
    if not keys:
        return
    for key in keys:
        try:
            key.value = 0.0
            # A muted key would show Basis while locked, and its own shape would be lost.
            key.mute = False
        except Exception:
            pass
    obj.show_only_shape_key = True
    obj.active_shape_key_index = int(key_index)


def _evaluate_shape(context, source_obj, selected_modifiers, key_index: int, stage: _Stage):
    temp = duplicate_object(context, source_obj, stage=stage)
    _prepare_shape_for_evaluation(temp, key_index)
    visibility = disable_modifiers(temp, selected_modifiers)
    try:
        result = evaluate_mesh(context, temp)
        result.name = f".__SKM_EVAL_{uuid.uuid4().hex}"
        stage.meshes.append(result)
        return result
    finally:
        _restore_modifier_visibility(visibility)
        stage.remove_object(temp)


def _edge_keys(mesh):
    flat = array("i", [0]) * (len(mesh.edges) * 2)
    mesh.edges.foreach_get("vertices", flat)
    return flat


def _vertices_keep_matching(source_mesh, key_meshes) -> bool:
    """Tell whether every evaluated key numbers its vertices the same way.

    Coordinates are copied between keys by vertex number. A modifier such as
    Decimate or Boolean can build a different mesh for each key with the same
    vertex count, and the numbers then point at unrelated vertices.
    """
    first = _edge_keys(key_meshes[0])
    first_set = None
    for mesh in key_meshes[1:]:
        edges = _edge_keys(mesh)
        if edges == first:
            continue
        if first_set is None:
            first_set = {tuple(sorted(first[i:i + 2])) for i in range(0, len(first), 2)}
        if first_set == {tuple(sorted(edges[i:i + 2])) for i in range(0, len(edges), 2)}:
            continue
        break
    else:
        return True
    # The connections differ. That is still safe when the vertices are the source's
    # own and all its edges remain: Triangulate only picks different diagonals.
    if len(key_meshes[0].vertices) != len(source_mesh.vertices):
        return False
    source = _edge_keys(source_mesh)
    source_set = {tuple(sorted(source[i:i + 2])) for i in range(0, len(source), 2)}
    for mesh in key_meshes:
        edges = _edge_keys(mesh)
        if not source_set <= {tuple(sorted(edges[i:i + 2])) for i in range(0, len(edges), 2)}:
            return False
    return True


def _build_staged_result(context, source_obj, selected_modifiers, stage: _Stage):
    source_keys = source_obj.data.shape_keys
    key_blocks = tuple(source_keys.key_blocks)
    graph = snapshot_shape_key_graph(source_obj)
    key_meshes = []
    for index, key in enumerate(key_blocks):
        _checkpoint(f"evaluate:{index}:{key.name}")
        key_meshes.append(_evaluate_shape(context, source_obj, selected_modifiers, index, stage))
    if not key_meshes:
        raise RuntimeError("source Shape Key graph is empty")
    vertex_count = len(key_meshes[0].vertices)
    if any(len(mesh.vertices) != vertex_count for mesh in key_meshes):
        raise RuntimeError(_l("Selected modifiers change vertex count differently between Shape Keys.", "選択したモディファイアによりシェイプキー間で頂点数が一致しません。", context))
    if not _vertices_keep_matching(source_obj.data, key_meshes):
        raise RuntimeError(_l("Selected modifiers build a different mesh for each Shape Key, so the keys cannot be kept.", "選択したモディファイアはシェイプキーごとに違うメッシュを作るので、シェイプキーを保てません。", context))

    result_mesh = key_meshes[0].copy()
    result_mesh.name = f".__SKM_RESULT_{uuid.uuid4().hex}"
    stage.meshes.append(result_mesh)
    result_obj = bpy.data.objects.new(f".__SKM_RESULT_OBJ_{uuid.uuid4().hex}", result_mesh)
    collection = _best_link_collection(context, source_obj)
    if collection is None:
        raise RuntimeError(_l("No collection was available for the staged result.", "ステージ結果を配置するコレクションが見つかりませんでした。", context))
    collection.objects.link(result_obj)
    stage.objects.append(result_obj)

    _checkpoint("before_shape_graph_rebuild")
    for source_key, evaluated_mesh in zip(key_blocks, key_meshes):
        key = result_obj.shape_key_add(name=str(source_key.name), from_mix=False)
        if len(key.data) != len(evaluated_mesh.vertices):
            raise RuntimeError("staged Shape Key vertex count mismatch")
        for point, vertex in zip(key.data, evaluated_mesh.vertices):
            point.co = vertex.co

    result_keys = result_obj.data.shape_keys
    if result_keys is None:
        raise RuntimeError("staged Key datablock was not created")
    _assign_properties(result_keys, dict(graph["key_datablock_properties"]))
    for custom_key, value in dict(graph["key_datablock_custom"]).items():
        result_keys[custom_key] = _copy_key_custom_property(value)
    restore_shape_key_properties(result_obj, graph["key_properties"])
    _restore_animation_data(result_keys, graph["animation"], stage)
    restore_shape_key_drivers(result_obj, source_obj, graph["drivers"])
    _checkpoint("after_shape_graph_rebuild")

    # Durable validation: names/order, relative relationships, user-visible key
    # properties, animation/NLA and drivers must all survive before commit.
    expected_names = tuple(str(key.name) for key in key_blocks)
    actual_names = tuple(str(key.name) for key in result_keys.key_blocks)
    if actual_names != expected_names:
        raise RuntimeError("staged Shape Key name/order validation failed")
    for source_key in key_blocks:
        staged_key = result_keys.key_blocks.get(str(source_key.name))
        if staged_key is None:
            raise RuntimeError(f"missing staged Shape Key: {source_key.name}")
        source_relative = str(getattr(getattr(source_key, "relative_key", None), "name", "") or "")
        staged_relative = str(getattr(getattr(staged_key, "relative_key", None), "name", "") or "")
        if source_relative != staged_relative:
            raise RuntimeError(f"relative Shape Key validation failed: {source_key.name}")
        for prop_name, expected in dict(graph["key_properties"][source_key.name]["properties"]).items():
            try:
                actual = _simple_rna_snapshot(getattr(staged_key, prop_name))
            except Exception as exc:
                raise RuntimeError(f"Shape Key property validation failed: {source_key.name}.{prop_name}") from exc
            if actual != expected:
                raise RuntimeError(f"Shape Key property validation failed: {source_key.name}.{prop_name}")
    staged_animation = getattr(result_keys, "animation_data", None)
    source_animation = graph.get("animation")
    if bool(staged_animation) != bool(source_animation or graph["drivers"]):
        raise RuntimeError("staged Shape Key animation presence validation failed")
    if source_animation:
        source_tracks = tuple(source_animation.get("nla_tracks", ()) or ())
        staged_tracks = tuple(getattr(staged_animation, "nla_tracks", ()) or ())
        if len(staged_tracks) != len(source_tracks):
            raise RuntimeError("staged NLA track count validation failed")
        source_action_snapshot = source_animation.get("action") or {}
        staged_action = getattr(staged_animation, "action", None)
        expected_action_fingerprint = source_action_snapshot.get("fingerprint")
        if expected_action_fingerprint is not None and _action_fingerprint(staged_action) != expected_action_fingerprint:
            raise RuntimeError("staged Action fingerprint validation failed")
    staged_drivers = tuple(getattr(staged_animation, "drivers", ()) or ()) if staged_animation is not None else ()
    if len(staged_drivers) != len(graph["drivers"]):
        raise RuntimeError("staged driver count validation failed")
    _checkpoint("staged_graph_validated")
    return result_obj, result_mesh

def preflight_modifiers_keep_vertex_count(context, source_obj, selected_modifiers, shape_key_names):
    del shape_key_names
    stage = _Stage()
    try:
        _build_staged_result(context, source_obj, selected_modifiers, stage)
        return True, None
    except Exception as exc:
        return False, exc
    finally:
        stage.cleanup()


def morph_maps_block_apply(obj) -> bool:
    # A stored map belongs to the vertices of this mesh, and the mesh is replaced on apply.
    keys = getattr(getattr(getattr(obj, "data", None), "shape_keys", None), "key_blocks", None)
    return len(getattr(obj, "skm_maps", ())) > 0 or (keys is not None and keys.get("SKM_Map_Preview") is not None)


def morph_maps_block_message(context) -> str:
    return _l("This mesh has maps. Export them if needed and press Delete All in Maps before applying modifiers.", "このメッシュにはマップがあります。必要なら書き出してから、「マップ」の「すべて削除」を押して適用してください。", context)


def apply_modifiers_with_shape_keys(context, selected_modifiers):
    original_obj = getattr(context, "active_object", None)
    if original_obj is None or getattr(original_obj, "type", None) != "MESH":
        return False, _l("Active object must be a mesh.", "アクティブオブジェクトはメッシュである必要があります。", context)
    if morph_maps_block_apply(original_obj):
        return False, morph_maps_block_message(context)
    source_keys = getattr(getattr(original_obj, "data", None), "shape_keys", None)
    if source_keys is None or len(source_keys.key_blocks) == 0:
        return False, _l("The active mesh has no Shape Keys.", "シェイプキーがありません。", context)
    selected = tuple(dict.fromkeys(str(name) for name in selected_modifiers if str(name)))
    if not selected:
        return False, _l("No modifiers selected.", "モディファイアが選択されていません。", context)
    if any(original_obj.modifiers.get(name) is None for name in selected):
        return False, _l("A selected modifier no longer exists.", "選択したモディファイアが存在しません。", context)

    snapshot = _context_snapshot(context, original_obj)
    original_mesh = original_obj.data
    original_mesh_name = str(getattr(original_mesh, "name", "") or "Mesh")
    modifier_snapshot = _snapshot_modifier_stack(original_obj)
    stage = _Stage()
    committed = False
    try:
        if snapshot.mode != "OBJECT":
            with context.temp_override(object=original_obj, active_object=original_obj, selected_objects=[original_obj], selected_editable_objects=[original_obj]):
                bpy.ops.object.mode_set(mode="OBJECT")
        _checkpoint("stage_begin")
        _result_obj, result_mesh = _build_staged_result(context, original_obj, selected, stage)
        # All names, relations, key metadata, animation, NLA and drivers are
        # validated before the sole data-pointer commit.
        _checkpoint("stage_validated")
        result_mesh.name = f"{original_mesh_name}.__SKM_COMMIT_{uuid.uuid4().hex[:8]}"

        original_obj.data = result_mesh
        if getattr(original_obj, "data", None) is not result_mesh:
            raise RuntimeError("mesh swap read-back failed")
        stage.committed_mesh = result_mesh
        _checkpoint("after_mesh_swap")

        try:
            for name in selected:
                modifier = original_obj.modifiers.get(name)
                if modifier is None:
                    raise RuntimeError(f"modifier disappeared during commit: {name}")
                original_obj.modifiers.remove(modifier)
        except Exception:
            # No user datablock was deleted. Restore the original pointer and a
            # complete modifier manifest before propagating the failure.
            original_obj.data = original_mesh
            stage.committed_mesh = None
            _restore_modifier_stack(original_obj, modifier_snapshot)
            raise

        # No fallible validation/checkpoint follows modifier removal. From this
        # point the operation has committed exactly once for Blender Undo.
        committed = True
        # Keep the original user Mesh datablock intact for Blender's single-step
        # Undo/Redo.  It is never deleted or purged by the Suite.  Rename only
        # after the sole pointer commit so the source remained untouched during
        # all staging and validation.
        try:
            if original_mesh is not None and getattr(original_mesh, "users", 0) == 0:
                original_mesh.name = f"{original_mesh_name}.__SKM_UNDO_{uuid.uuid4().hex[:8]}"
            result_mesh.name = original_mesh_name
        except Exception:
            pass
        return True, None
    except Exception as exc:
        if not committed:
            try:
                if getattr(original_obj, "data", None) is not original_mesh:
                    original_obj.data = original_mesh
                if getattr(original_obj, "data", None) is original_mesh:
                    # The staged result is no longer committed and must be
                    # removed by Stage.cleanup. Keeping this marker set would
                    # leak the temporary Mesh after an injected post-swap fault.
                    stage.committed_mesh = None
            except Exception:
                pass
        return False, exc
    finally:
        stage.cleanup()
        _restore_context(context, snapshot, original_obj)
