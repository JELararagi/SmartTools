# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Select a modifier subset and pass it to the suite's shape-key transaction."""
import bpy
from . import functions

def message(en,ja):
    return ja if bpy.app.translations.locale.startswith('ja') else en

def target(context):
    obj=getattr(context,'active_object',None)
    return obj if (obj and obj.type=='MESH' and obj.mode=='OBJECT' and obj.data.shape_keys and obj.modifiers) else None

class ModifierList(bpy.types.PropertyGroup):
    apply_modifier:bpy.props.BoolProperty(name='',default=False,
        description=message('Apply this modifier and keep the shape keys','このモディファイアを適用し、シェイプキーを保持します'))

class OBJECT_OT_apply_modifiers_with_shape_keys(bpy.types.Operator):
    bl_idname='object.apply_modifiers_with_shape_keys'
    bl_label=message('Apply Modifier(s) for Mesh with Shape Keys','シェイプキー保持で適用')
    bl_description=message('Choose modifiers to bake into every shape while keeping the shape keys',
                           'すべての形状に適用するモディファイアを選び、シェイプキーを保持します')
    bl_options={'UNDO'}
    collection_property:bpy.props.CollectionProperty(type=ModifierList,options={'SKIP_SAVE'})

    @classmethod
    def poll(cls,context):
        return target(context) is not None

    def invoke(self,context,event):
        obj=target(context)
        if obj is None:return {'CANCELLED'}
        if functions.morph_maps_block_apply(obj):
            self.report({'WARNING'},functions.morph_maps_block_message(context))
            return {'CANCELLED'}
        self.collection_property.clear()
        self._dialog_object=obj.as_pointer()
        self._dialog_modifiers={m.name:m.as_pointer() for m in obj.modifiers}
        for m in obj.modifiers:
            row=self.collection_property.add();row.name=m.name
        return context.window_manager.invoke_props_dialog(self)

    def draw(self,context):
        col=self.layout.column(align=True)
        for item in self.collection_property:col.prop(item,'apply_modifier',text=item.name)

    def execute(self,context):
        obj=target(context)
        if obj is None or getattr(self,'_dialog_object',obj.as_pointer())!=obj.as_pointer():
            self.report({'WARNING'},message('Select the original mesh and open the checklist again.',
                                            '元のメッシュを選び、チェックリストを開き直してください。'))
            return {'CANCELLED'}
        names={row.name for row in self.collection_property if row.apply_modifier}
        if not names:
            self.report({'WARNING'},message('Select at least one modifier.','適用するモディファイアを選んでください。'))
            return {'CANCELLED'}
        current={m.name:m.as_pointer() for m in obj.modifiers}
        previous=getattr(self,'_dialog_modifiers',current)
        if any(name not in current or current[name]!=previous.get(name) for name in names):
            self.report({'WARNING'},message('The modifier list changed. Open the checklist again.',
                                            'モディファイアの一覧が変わりました。チェックリストを開き直してください。'))
            return {'CANCELLED'}
        if functions.morph_maps_block_apply(obj):
            self.report({'WARNING'},functions.morph_maps_block_message(context))
            return {'CANCELLED'}
        ordered=[name for name in current if name in names]
        ok,detail=functions.apply_modifiers_with_shape_keys(context,ordered)
        if not ok:
            self.report({'WARNING'},str(detail) if detail else message('The mesh could not be updated.','メッシュを更新できませんでした。'))
            return {'CANCELLED'}
        return {'FINISHED'}
