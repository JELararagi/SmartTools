# SPDX-License-Identifier: GPL-3.0-or-later
"""Scale and filter sampled facial channels without mutating the take."""

from math import expm1, isfinite

if __package__:
    from .capture_csv import CaptureClip
else:
    from capture_csv import CaptureClip


_REGIONS = {
    "eye": "eyes",
    "mouth": "mouth",
    "jaw": "mouth",
    "brow": "brows",
    "cheek": "cheeks",
    "nose": "cheeks",
}


def region(name):
    return next((group for prefix, group in _REGIONS.items() if name.startswith(prefix)), "tongue")


def _filter(samples, times, seconds):
    if len(samples) < 3:
        return samples
    weights = [-expm1((left - right) / seconds) for left, right in zip(times, times[1:])]
    from_past = samples.copy()
    for index, weight in enumerate(weights, 1):
        previous = from_past[index - 1]
        from_past[index] = previous + weight * (samples[index] - previous)
    result = samples.copy()
    neighbor = samples[-1]
    for index in range(len(samples) - 2, 0, -1):
        neighbor += weights[index] * (samples[index] - neighbor)
        result[index] = (from_past[index] + neighbor) / 2
    return result


def process(clip, *, gains=None, smoothing_seconds=0.0, calibration=None):
    gains = {} if gains is None else gains
    if not isfinite(smoothing_seconds) or not 0 <= smoothing_seconds <= 1:
        raise ValueError("Smoothing time must be 0..1 seconds")
    if not all(isfinite(value) and 0 <= value <= 3 for value in gains.values()):
        raise ValueError("Region gain must be finite and 0..3")
    if calibration is not None:
        if __package__:
            from .capture_calibration import apply
        else:
            from capture_calibration import apply
        clip = apply(clip, calibration)
    output = {}
    for name, source in clip.channels.items():
        amplitude = gains.get(region(name), 1.0)
        samples = [float(value) * amplitude for value in source]
        if smoothing_seconds:
            samples = _filter(samples, clip.times, smoothing_seconds)
        output[name] = tuple(samples)
    return CaptureClip(clip.times, output, clip.ignored_columns, clip.range_violations)
