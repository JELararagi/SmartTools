"""Optional edit processing; input clip remains untouched, time remains in seconds."""
import math
try:
    from .capture_csv import CaptureClip
except ImportError:
    from capture_csv import CaptureClip

def region(name):
    if name.startswith('eye'):return 'eyes'
    if name.startswith(('mouth','jaw')):return 'mouth'
    if name.startswith('brow'):return 'brows'
    if name.startswith(('cheek','nose')):return 'cheeks'
    return 'tongue'

def process(clip, *, gains=None, smoothing_seconds=0.0, calibration=None):
    gains=gains or {}
    if not math.isfinite(smoothing_seconds) or not 0<=smoothing_seconds<=1:
        raise ValueError('Smoothing time must be 0..1 seconds')
    if any(not math.isfinite(g) or not 0<=g<=3 for g in gains.values()):
        raise ValueError('Region gain must be finite and 0..3')
    if calibration is not None:
        try:
            from .capture_calibration import apply
        except ImportError:
            from capture_calibration import apply
        clip=apply(clip,calibration)
    channels={}
    for name,series in clip.channels.items():
        values=[float(v)*gains.get(region(name),1.0) for v in series]
        if smoothing_seconds:
            # Two opposite time-domain passes, combined symmetrically. Endpoints
            # are retained exactly; boundary response still requires visual review.
            forward=values.copy();backward=values.copy()
            for i in range(1,len(values)):
                alpha=-math.expm1(-(clip.times[i]-clip.times[i-1])/smoothing_seconds)
                forward[i]=forward[i-1]+alpha*(values[i]-forward[i-1])
            for i in range(len(values)-2,-1,-1):
                alpha=-math.expm1(-(clip.times[i+1]-clip.times[i])/smoothing_seconds)
                backward[i]=backward[i+1]+alpha*(values[i]-backward[i+1])
            values=[(a+b)/2 for a,b in zip(forward,backward)]
            values[0]=series[0]*gains.get(region(name),1.0)
            values[-1]=series[-1]*gains.get(region(name),1.0)
        channels[name]=tuple(values)
    return CaptureClip(clip.times,channels,clip.ignored_columns,clip.range_violations)
