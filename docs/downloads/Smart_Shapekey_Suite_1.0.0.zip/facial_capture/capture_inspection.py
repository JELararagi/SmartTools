"""Capture inspection table, before (RAW) and after (EDIT) the import processing.

Pure Python, no bpy.  RAW is the CSV read exactly as the import reads it; EDIT is produced by the
same functions the import uses for its EDIT Action (calibration, estimation, gains, smoothing),
in the capture's own samples (before resampling to scene frames).

Per channel and per side (RAW / EDIT):
  min, max                 reach
  p50, p95, p99            linear interpolation between closest ranks: (n-1)*q
  stick_share              share of samples >= stick_line (default 0.99)
  half_share               share of samples >= 0.5
  peak_index, peak_time    first sample holding the maximum (0-based row, CSV time)
  neutral_*                samples whose time from the first sample is within [neutral_start, neutral_end]
Flags (EDIT side): STICK (stick_share > stick_limit), WEAK (max < reach_line),
NEUTRAL_RESIDUAL (neutral max > residual_line).
"""
import csv
import io
import json
import math

try:
    from .capture_csv import ARKIT_NAMES
except ImportError:  # pragma: no cover
    from capture_csv import ARKIT_NAMES

FORMAT = 'smart_shapekey_capture_inspection'
VERSION = 1
CSV_FIELDS = ('channel', 'raw_min', 'raw_max', 'raw_p50', 'raw_p95', 'raw_p99', 'raw_stick_share', 'raw_half_share',
              'raw_peak_index', 'raw_peak_time', 'edit_min', 'edit_max', 'edit_p50', 'edit_p95', 'edit_p99',
              'edit_stick_share', 'edit_half_share', 'edit_peak_index', 'edit_peak_time', 'neutral_count',
              'neutral_raw_mean', 'neutral_raw_max', 'neutral_edit_max', 'flags')


def quantile(values, q):
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q
    lo = math.floor(pos)
    hi = min(lo + 1, len(ordered) - 1)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (pos - lo)


def _side(times, series, stick_line):
    n = len(series)
    peak = max(series)
    index = series.index(peak)
    return {'min': min(series), 'max': peak, 'p50': quantile(series, .5), 'p95': quantile(series, .95),
            'p99': quantile(series, .99), 'stick_share': sum(1 for v in series if v >= stick_line) / n,
            'half_share': sum(1 for v in series if v >= .5) / n, 'peak_index': index, 'peak_time': times[index]}


def inspect(raw, edit, *, stick_line=.99, stick_limit=.01, reach_line=.3, residual_line=.1,
            neutral_start=0.0, neutral_end=1.0):
    for v in (stick_line, stick_limit, reach_line, residual_line, neutral_start, neutral_end):
        if not math.isfinite(v):
            raise ValueError('Inspection settings must be finite numbers.')
    if neutral_end < neutral_start or neutral_start < 0:
        raise ValueError('Neutral segment needs 0 <= start <= end.')
    times = raw.times
    t0 = times[0]
    window = [i for i, t in enumerate(times) if neutral_start - 1e-9 <= t - t0 <= neutral_end + 1e-9]
    if not window:
        raise ValueError('The neutral segment has no samples.')
    rows = []
    for name in ARKIT_NAMES:
        if name not in raw.channels:
            continue
        r = list(raw.channels[name])
        e = list(edit.channels[name]) if edit is not None and name in edit.channels else None
        row = {'channel': name, 'raw': _side(times, r, stick_line),
               'edit': _side(edit.times, e, stick_line) if e is not None else None,
               'neutral': {'count': len(window), 'raw_mean': sum(r[i] for i in window) / len(window),
                           'raw_max': max(r[i] for i in window),
                           'edit_max': max(e[i] for i in window) if e is not None else None}}
        flags = []
        if e is not None:
            if row['edit']['stick_share'] > stick_limit:
                flags.append('STICK')
            if row['edit']['max'] < reach_line:
                flags.append('WEAK')
            if row['neutral']['edit_max'] > residual_line:
                flags.append('NEUTRAL_RESIDUAL')
        row['flags'] = flags
        rows.append(row)
    counts = {f: sum(f in row['flags'] for row in rows) for f in ('STICK', 'WEAK', 'NEUTRAL_RESIDUAL')}
    return {'format': FORMAT, 'version': VERSION, 'samples': len(times), 'duration': times[-1] - t0,
            'settings': {'stick_line': stick_line, 'stick_limit': stick_limit, 'reach_line': reach_line,
                         'residual_line': residual_line, 'neutral_start': neutral_start, 'neutral_end': neutral_end},
            'flag_counts': counts, 'channels': rows}


def to_json(report):
    return json.dumps(report, ensure_ascii=False, indent=1, allow_nan=False)


def to_csv(report):
    out = io.StringIO(newline='')
    writer = csv.writer(out)
    writer.writerow(CSV_FIELDS)
    for row in report['channels']:
        raw, edit, neu = row['raw'], row['edit'] or {}, row['neutral']

        def g(side, key):
            value = side.get(key)
            return '' if value is None else format(value, '.17g') if isinstance(value, float) else str(value)

        writer.writerow([row['channel']] + [g(raw, k) for k in ('min', 'max', 'p50', 'p95', 'p99', 'stick_share', 'half_share', 'peak_index', 'peak_time')]
                        + [g(edit, k) for k in ('min', 'max', 'p50', 'p95', 'p99', 'stick_share', 'half_share', 'peak_index', 'peak_time')]
                        + [str(neu['count']), g(neu, 'raw_mean'), g(neu, 'raw_max'), g(neu, 'edit_max'), ' '.join(row['flags'])])
    return out.getvalue()
