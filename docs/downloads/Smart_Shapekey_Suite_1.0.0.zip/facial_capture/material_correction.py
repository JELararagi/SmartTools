"""Private selected-slot texture-to-color override, with protected original restore."""
import hashlib,json,math,uuid
import bpy
TAG='smart_shapekey_facial_material_owner'
META='smart_shapekey_facial_material_metadata'
ORIGINAL='smart_shapekey_facial_original_material'

def driver_signature(owner):
    ad=owner.animation_data
    if not ad:return []
    return [[c.data_path,c.array_index,c.mute,c.driver.type,c.driver.expression,c.driver.use_self,
        [[v.name,v.type,[[plain(t.id),t.data_path,t.bone_target,t.transform_type,t.transform_space,t.rotation_mode] for t in v.targets]] for v in c.driver.variables]]
        for c in ad.drivers]

def plain(value):
    if isinstance(value,(str,int,float,bool)) or value is None:return value
    if isinstance(value,bpy.types.ID):return {'id_type':value.bl_rna.identifier,'name':value.name_full,'library':value.library.filepath if value.library else None}
    try:return [plain(v) for v in value]
    except TypeError:return str(value)

def fingerprint(material):
    nodes=[];tree=material.node_tree
    driven={c.data_path for c in tree.animation_data.drivers} if tree and tree.animation_data else set()
    for node in tree.nodes if tree else ():
        props={key:plain(getattr(node,key)) for key in ('mute','image','node_tree','operation','blend_type','extension','interpolation',
            'projection','projection_blend','is_active_output','uv_map','attribute_name','vector_type','convert_from','convert_to',
            'space','distribution','subsurface_method','normalize','data_type','clamp') if hasattr(node,key)}
        sockets=[[socket.identifier,({'driven':True} if socket.path_from_id('default_value') in driven else plain(socket.default_value)) if hasattr(socket,'default_value') else None] for socket in list(node.inputs)+list(node.outputs)]
        nodes.append([node.name,node.bl_idname,props,sockets])
    values={'material':{k:plain(getattr(material,k)) for k in ('diffuse_color','use_nodes','surface_render_method','use_backface_culling','use_transparent_shadow') if hasattr(material,k)},
        'nodes':sorted(nodes,key=lambda n:n[0]),'links':sorted((l.from_node.name,l.from_socket.identifier,l.to_node.name,l.to_socket.identifier) for l in tree.links) if tree else [],
        'material_drivers':driver_signature(material),'tree_drivers':driver_signature(tree) if tree else []}
    return hashlib.sha256(json.dumps(values,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def target(obj):
    if not obj or obj.type!='MESH' or obj.library or obj.data.library or not obj.is_editable or not obj.data.is_editable or obj.data.users!=1:
        raise ValueError('共有されていない編集可能なメッシュを1つ選択してください')
    index=obj.active_material_index
    if index>=len(obj.material_slots) or obj.material_slots[index].link!='DATA':raise ValueError('メッシュ側の材質スロットが必要です')
    material=obj.material_slots[index].material
    if not material or material.library or not material.is_editable or not material.use_nodes or not material.node_tree:
        raise ValueError('編集可能なノード材質が必要です')
    for owner in (material,material.node_tree):
        ad=owner.animation_data
        if ad and (ad.action or ad.nla_tracks or (owner==material and ad.drivers)):raise ValueError('材質の既存アクション/NLAを保護します')
        if ad:
            for curve in ad.drivers:
                if not curve.driver.is_simple_expression or any(t.id==owner or not isinstance(t.id,bpy.types.Object) for v in curve.driver.variables for t in v.targets):
                    raise ValueError('外部オブジェクトを参照する単純シェーダーのドライバーだけに対応しています')
    return index,material

def owned(obj):
    index,material=target(obj)
    if not material.get(TAG) or not material.get(META):raise ValueError('このアドオンの操作で補正した材質を選択してください')
    meta=json.loads(material[META]);original=material.get(ORIGINAL)
    if meta.get('object')!=obj.name or meta.get('slot')!=index or not isinstance(original,bpy.types.Material):raise ValueError('所有する元材質の参照が不一致です')
    if fingerprint(material)!=meta['result_hash'] or fingerprint(original)!=meta['original_hash']:raise ValueError('補正材質または元材質が手編集されています')
    if material.users!=1:raise ValueError('補正材質が他の部品と共有されています')
    rim=meta if meta.get('kind')=='rim' else meta.get('rim')
    if rim:
        scale=material.node_tree.nodes.get(rim.get('scale_node','SS_Facial_Rim_Scale'))
        if not scale or scale.bl_idname!='ShaderNodeMath' or scale.use_clamp:
            raise ValueError('リム倍率ノードが手編集されています')
    return index,material,original,meta

def correct_material(obj,node_name,color):
    if len(color)!=4 or not all(math.isfinite(x) and 0<=x<=1 for x in color):raise ValueError('色は有限のRGBA（0〜1）を指定してください')
    index,original=target(obj)
    if original.get(TAG):
        _,_,_,meta=owned(obj)
        if meta.get('kind','color')=='color' and meta['source_node']==node_name and all(abs(a-b)<1e-7 for a,b in zip(meta['color'],color)):return {'reused':True,'links':meta['links'],'material':original.name}
        raise ValueError('別の色に変更する前に元の材質へ戻してください')
    tree=original.node_tree;node=tree.nodes.get(node_name)
    if not node or node.bl_idname!='ShaderNodeTexImage' or not node.image:raise ValueError('置き換える画像テクスチャノードを指定してください')
    links=[l for l in tree.links if l.from_node==node]
    if not links or any(l.from_socket.name not in ('Color','Alpha') for l in links):raise ValueError('画像のColor/Alpha出力への接続が必要です')
    if tree.animation_data and any(c.data_path.startswith(node.path_from_id()) for c in tree.animation_data.drivers):raise ValueError('画像ノード自身のドライバーを保護します')
    before=fingerprint(original);copy=None
    try:
        copy=original.copy();copy.name=original.name+'_SS_Facial_Color';copy.use_fake_user=False
        if copy.node_tree==tree:raise RuntimeError('独立した材質ノードの複製に失敗しました')
        cloned=copy.node_tree.nodes[node_name];rgb=copy.node_tree.nodes.new('ShaderNodeRGB');rgb.name='SS_Facial_Color';rgb.outputs[0].default_value=color
        alpha=copy.node_tree.nodes.new('ShaderNodeValue');alpha.name='SS_Facial_Alpha';alpha.outputs[0].default_value=color[3]
        count=0
        for link in list(copy.node_tree.links):
            if link.from_node!=cloned:continue
            socket=rgb.outputs[0] if link.from_socket.name=='Color' else alpha.outputs[0];destination=link.to_socket
            copy.node_tree.links.remove(link);copy.node_tree.links.new(socket,destination);count+=1
        copy.node_tree.nodes.remove(cloned);copy.diffuse_color=color
        if driver_signature(copy.node_tree)!=driver_signature(tree):raise RuntimeError('既存シェーダーのドライバーの複製が一致しません')
        uid=uuid.uuid4().hex;copy[TAG]=uid;copy[ORIGINAL]=original
        meta={'version':1,'kind':'color','object':obj.name,'slot':index,'source_node':node_name,'source_image':node.image.name if node.image else None,
            'color':list(color),'links':count,'original_hash':before,'result_hash':fingerprint(copy)}
        copy[META]=json.dumps(meta,ensure_ascii=False,allow_nan=False)
        if fingerprint(original)!=before:raise RuntimeError('元の共有材質が変更されました')
        obj.data.materials[index]=copy
        return {'reused':False,'links':count,'material':copy.name}
    except Exception:
        if copy:
            if obj.data.materials[index]==copy:obj.data.materials[index]=original
            bpy.data.materials.remove(copy)
        raise

def restore_material(obj):
    index,material,original,_=owned(obj)
    obj.data.materials[index]=original
    bpy.data.materials.remove(material)
    return {'material':original.name}


def _rim_socket(node):
    if node and node.bl_idname=='ShaderNodeEmission':return node.inputs['Strength']
    if node and node.bl_idname=='ShaderNodeMixRGB':return node.inputs[0]
    raise ValueError('リム合成のMixRGBノード、または発光のEmissionノードを指定してください')

def _rim_link(tree,node_name,factor):
    dest=_rim_socket(tree.nodes.get(node_name));links=list(dest.links)
    if len(links)>1:raise ValueError('リム入力の複数接続には対応していません')
    if tree.animation_data and any(c.data_path==dest.path_from_id('default_value') for c in tree.animation_data.drivers):
        raise ValueError('リム入力自身のドライバーを保護します')
    old_source=links[0].from_socket if links else None;old_value=dest.default_value
    scale=tree.nodes.new('ShaderNodeMath');scale.name='SS_Facial_Rim_Scale';scale.operation='MULTIPLY';scale.inputs[1].default_value=factor
    try:
        if old_source:
            tree.links.remove(links[0]);tree.links.new(old_source,scale.inputs[0])
        else:scale.inputs[0].default_value=old_value
        tree.links.new(scale.outputs[0],dest)
    except Exception:
        tree.nodes.remove(scale)
        if old_source:tree.links.new(old_source,dest)
        else:dest.default_value=old_value
        raise
    return scale,dest,old_source,old_value,len(links)

def _rim_rollback(tree,scale,dest,source,value):
    tree.nodes.remove(scale)
    if source:tree.links.new(source,dest)
    else:dest.default_value=value

def correct_rim(obj,node_name,factor):
    """Scale a selected emission strength or rim-color mix, including owned color copies."""
    if not math.isfinite(factor) or not 0<=factor<=1:raise ValueError('リムの倍率は0〜1を指定してください')
    index,material=target(obj)
    if material.get(TAG):
        _,material,original,meta=owned(obj);rim=meta if meta.get('kind')=='rim' else meta.get('rim')
        if rim:
            if rim['source_node']!=node_name:raise ValueError('別のリムを補正する前に元の材質へ戻してください')
            if abs(rim['factor']-factor)<1e-7:return {'reused':True,'links':rim['links'],'material':material.name}
            scale=material.node_tree.nodes[rim['scale_node']];old_factor=scale.inputs[1].default_value;old_meta=material[META]
            try:
                scale.inputs[1].default_value=factor;rim['factor']=factor;meta['result_hash']=fingerprint(material);material[META]=json.dumps(meta,ensure_ascii=False,allow_nan=False)
            except Exception:
                scale.inputs[1].default_value=old_factor;material[META]=old_meta;raise
            return {'reused':False,'links':rim['links'],'material':material.name}
        if meta.get('kind','color')!='color':raise ValueError('この材質補正へリムを追加できません')
        old_meta=material[META];old_drivers=driver_signature(material.node_tree);scale=None
        try:
            scale,dest,source,value,count=_rim_link(material.node_tree,node_name,factor)
            if driver_signature(material.node_tree)!=old_drivers:raise RuntimeError('既存シェーダーのドライバーが変更されました')
            meta['rim']={'source_node':node_name,'factor':factor,'scale_node':scale.name,'links':count};meta['result_hash']=fingerprint(material)
            if fingerprint(original)!=meta['original_hash']:raise RuntimeError('元の共有材質が変更されました')
            material[META]=json.dumps(meta,ensure_ascii=False,allow_nan=False)
            return {'reused':False,'links':count,'material':material.name}
        except Exception:
            if scale:_rim_rollback(material.node_tree,scale,dest,source,value)
            material[META]=old_meta;raise
    original=material;before=fingerprint(original);copy=None
    try:
        copy=original.copy();copy.name=original.name+'_SS_Facial_Rim';copy.use_fake_user=False
        if copy.node_tree==original.node_tree:raise RuntimeError('独立した材質ノードの複製に失敗しました')
        scale,dest,source,value,count=_rim_link(copy.node_tree,node_name,factor)
        if driver_signature(copy.node_tree)!=driver_signature(original.node_tree):raise RuntimeError('既存シェーダーのドライバーの複製が一致しません')
        copy[TAG]=uuid.uuid4().hex;copy[ORIGINAL]=original
        meta={'version':1,'kind':'rim','object':obj.name,'slot':index,'source_node':node_name,'factor':factor,'scale_node':scale.name,'links':count,'original_hash':before,'result_hash':fingerprint(copy)}
        if fingerprint(original)!=before:raise RuntimeError('元の共有材質が変更されました')
        copy[META]=json.dumps(meta,ensure_ascii=False,allow_nan=False);obj.data.materials[index]=copy
        return {'reused':False,'links':count,'material':copy.name}
    except Exception:
        if copy:
            if obj.data.materials[index]==copy:obj.data.materials[index]=original
            bpy.data.materials.remove(copy)
        raise
