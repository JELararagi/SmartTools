"""Standard ARKit/Live Link Face CSV time handling, without Blender dependencies.
CSV column vocabulary follows Nick Fisher's MIT licensed blender_livelinkface
commit 8f40285042626f4104e4caebcae7f523fc0d24bc. See inputs/upstream_livelinkface.
"""
import bisect
import csv
from dataclasses import dataclass
import math
from pathlib import Path
import re

ARKIT_NAMES = ('eyeBlinkLeft', 'eyeLookDownLeft', 'eyeLookInLeft', 'eyeLookOutLeft', 'eyeLookUpLeft', 'eyeSquintLeft', 'eyeWideLeft', 'eyeBlinkRight', 'eyeLookDownRight', 'eyeLookInRight', 'eyeLookOutRight', 'eyeLookUpRight', 'eyeSquintRight', 'eyeWideRight', 'jawForward', 'jawRight', 'jawLeft', 'jawOpen', 'mouthClose', 'mouthFunnel', 'mouthPucker', 'mouthRight', 'mouthLeft', 'mouthSmileLeft', 'mouthSmileRight', 'mouthFrownLeft', 'mouthFrownRight', 'mouthDimpleLeft', 'mouthDimpleRight', 'mouthStretchLeft', 'mouthStretchRight', 'mouthRollLower', 'mouthRollUpper', 'mouthShrugLower', 'mouthShrugUpper', 'mouthPressLeft', 'mouthPressRight', 'mouthLowerDownLeft', 'mouthLowerDownRight', 'mouthUpperUpLeft', 'mouthUpperUpRight', 'browDownLeft', 'browDownRight', 'browInnerUp', 'browOuterUpLeft', 'browOuterUpRight', 'cheekPuff', 'cheekSquintLeft', 'cheekSquintRight', 'noseSneerLeft', 'noseSneerRight', 'tongueOut')
_LOOKUP = {n.lower(): n for n in ARKIT_NAMES}

@dataclass(frozen=True)
class CaptureClip:
    times: tuple
    channels: dict
    ignored_columns: tuple = ()
    range_violations: tuple = ()

    @property
    def duration(self):
        return self.times[-1] - self.times[0]


def canonical_name(name):
    text = str(name).strip()
    text = re.sub(r'_L$', 'Left', text, flags=re.I)
    text = re.sub(r'_R$', 'Right', text, flags=re.I)
    return _LOOKUP.get(text.lower())


def timecode_seconds(text, fps):
    if not math.isfinite(fps) or fps <= 0:
        raise ValueError('Positive source fps required for frame-based timecode')
    if ';' in text:
        raise ValueError('Drop-frame timecode needs an explicit supported conversion; not treated as non-drop')
    pieces = text.strip().split(':')
    if len(pieces) == 1:
        result = float(pieces[0])
    elif len(pieces) == 4:
        h, m, s = map(int, pieces[:3])
        f = float(pieces[3])
        if not (0 <= h < 24 and 0 <= m < 60 and 0 <= s < 60 and 0 <= f < math.ceil(fps)):
            raise ValueError('Invalid timecode')
        result = h * 3600 + m * 60 + s + f / fps
    else:
        raise ValueError('Expected seconds or HH:MM:SS:FF timecode')
    if not math.isfinite(result) or result < 0:
        raise ValueError('Invalid capture time')
    return result


def read_csv(path, *, source_fps=60.0, value_scale=1.0, max_rows=30000, range_policy="reject"):
    if range_policy not in ("reject", "preserve"):
        raise ValueError("Unknown range policy")
    if not math.isfinite(value_scale) or value_scale <= 0:
        raise ValueError('value_scale must be finite and positive')
    with Path(path).open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        if len(set(h.lower() for h in headers)) != len(headers):
            raise ValueError('Duplicate CSV column names')
        lower = {h.lower(): h for h in headers}
        if 'time_seconds' in lower:
            time_col, mode = lower['time_seconds'], 'seconds'
        elif 'timestamp_ms' in lower:
            time_col, mode = lower['timestamp_ms'], 'milliseconds'
        elif 'timecode' in lower:
            time_col, mode = lower['timecode'], 'timecode'
        else:
            raise ValueError('Capture needs time_seconds, timestamp_ms, or Timecode; row index is not time')
        mapping = {}
        ignored = []
        for header in headers:
            channel = canonical_name(header)
            if channel:
                if channel in mapping.values():
                    raise ValueError('Duplicate aliases for '+channel)
                mapping[header] = channel
            elif header != time_col:
                ignored.append(header)
        if not mapping:
            raise ValueError('No recognized ARKit channels')
        times, values = [], {n: [] for n in mapping.values()}
        violations = []
        day_offset, previous_clock = 0.0, None
        for row_num, row in enumerate(reader, start=2):
            if len(times) >= max_rows:
                raise ValueError('Capture row limit exceeded')
            if None in row or any(v is None for v in row.values()):
                raise ValueError('CSV row width mismatch at row '+str(row_num))
            try:
                clock = timecode_seconds(row[time_col], source_fps) if mode == 'timecode' else float(row[time_col]) / (1000 if mode == 'milliseconds' else 1)
                if not math.isfinite(clock) or clock < 0:
                    raise ValueError('Nonfinite or negative timestamp')
                if mode == 'timecode' and previous_clock is not None and clock - previous_clock < -23 * 3600:
                    day_offset += 86400
                t = clock + day_offset
                if times and t <= times[-1]:
                    raise ValueError('Timestamps must increase strictly')
                for header, channel in mapping.items():
                    weight = float(row[header]) * value_scale
                    if not math.isfinite(weight):
                        raise ValueError('Nonfinite coefficient for '+channel)
                    if not -1e-6 <= weight <= 1 + 1e-6:
                        if range_policy == 'reject':
                            raise ValueError('Invalid 0..1 coefficient for '+channel)
                        violations.append((row_num, channel, weight))
                    values[channel].append(weight if range_policy == 'preserve' else min(1.0,max(0.0,weight)))
                times.append(t)
                previous_clock = clock
            except (ValueError, TypeError) as e:
                raise ValueError('CSV row '+str(row_num)+': '+str(e)) from e
    if len(times) < 2:
        raise ValueError('At least two timed samples required')
    return CaptureClip(tuple(times), {n: tuple(v) for n,v in values.items()}, tuple(ignored),tuple(violations))


def scene_samples(clip, *, fps, fps_base=1.0, start_frame=1.0):
    rate = float(fps) / float(fps_base)
    if not math.isfinite(rate) or rate <= 0 or not math.isfinite(start_frame):
        raise ValueError('Invalid target timebase')
    end = clip.duration * rate
    frame_offsets = [float(i) for i in range(math.floor(end + 1e-8) + 1)]
    # Preserve a fractional final sample rather than truncating the take.
    if end - frame_offsets[-1] > 1e-7:
        frame_offsets.append(end)
    for offset in frame_offsets:
        t = clip.times[0] + offset / rate
        right = min(len(clip.times)-1, bisect.bisect_right(clip.times, t))
        left = max(0, right-1)
        alpha = max(0.0, min(1.0, (t-clip.times[left]) / (clip.times[right]-clip.times[left]))) if right != left else 0.0
        yield start_frame + offset, {name: series[left]*(1-alpha)+series[right]*alpha for name,series in clip.channels.items()}


def write_standard_csv(path, clip):
    names = list(clip.channels)
    with Path(path).open('w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['time_seconds'] + names)
        for i,t in enumerate(clip.times):
            writer.writerow([format(t, '.12g')] + [format(clip.channels[n][i], '.9g') for n in names])
