"""Build a per-channel calibration table from the distribution of several RAW captures.

Pure Python, no bpy, no code evaluation.  Deterministic: the same CSV values, the same optional
previous table / target table / gaze caps and the same rule values always give the same table.

Rules (defaults are the documented v4 rules A, C, D, E, F; the v5 preset only changes the
neutral percentile of the three brow-raise channels to 75):

  A  jawOpen          neutral = previous table, max = target maximum, knots
                      [[0,0],[a1x,a1y],[a2x,a2y],[1,1]].  Skipped (row kept) without a target.
  C  narrow span      previous span (max-neutral) < span_small and target < target_min (or none):
                      max = neutral + span_min (never above 1).
  D  narrow span      previous span < span_small and target >= target_min: max = target.
  E  eyeLook* (8)     neutral = eye_neutral_pct percentile, max = max(previous max, target,
                      eye_max_pct percentile); a gaze cap below 1 adds knots [[0,0],[1,cap]].
  F  brows (5)        browDown neutral = brow_down_neutral_pct, brow raise neutral =
                      brow_up_neutral_pct, max = brow_max_pct percentile.
  G  (optional, off)  after A-F, a row whose calibrated share >= stick_line exceeds stick_limit
                      gets max = max(max, (100 - 100*stick_limit) percentile).
  other rows          copied from the previous table unchanged (knots included).

Percentile = sorted(values)[int(q/100*(n-1))] (lower nearest rank, no interpolation) over all
frames of all chosen captures, rounded to ``percentile_digits`` decimals.  Rule values from the
UI are rounded to 6 decimals before use so a float32 property cannot flip a comparison.
Without a previous table every row starts as neutral = fallback_neutral_pct percentile,
max = fallback_max_pct percentile (an assumption, not a measured recommendation).
"""
import hashlib
import json
import math
from pathlib import Path

try:
    from .capture_csv import ARKIT_NAMES, canonical_name, read_csv
    from . import capture_calibration as calibration
except ImportError:  # pragma: no cover - plain-python tests
    from capture_csv import ARKIT_NAMES, canonical_name, read_csv
    import capture_calibration as calibration

FORMAT_REPORT = 'smart_shapekey_calibration_build_report'
EYE_LOOK = tuple(n for n in ARKIT_NAMES if n.startswith('eyeLook'))
BROW_DOWN = ('browDownLeft', 'browDownRight')
BROW_UP = ('browInnerUp', 'browOuterUpLeft', 'browOuterUpRight')
JAW = 'jawOpen'
MANUAL_ONLY = frozenset(('tongueOut', 'cheekPuff'))
MAX_TAKES = 64
MAX_CSV_BYTES = 20 * 1024 * 1024
MAX_SIDE_BYTES = 2 * 1024 * 1024
MIN_SPAN = calibration.MIN_SPAN

RULES_V4 = {
    'percentile_digits': 5,
    'jaw_rule': True, 'jaw_knot1': (0.1, 0.1), 'jaw_knot2': (0.3, 0.42),
    'span_small': 0.12, 'target_min': 0.15, 'span_min': 0.25,
    'eye_neutral_pct': 75.0, 'eye_max_pct': 99.5,
    'eye_caps': {n: 1.0 for n in EYE_LOOK},
    'brow_down_neutral_pct': 50.0, 'brow_up_neutral_pct': 50.0, 'brow_max_pct': 99.0,
    'fallback_neutral_pct': 50.0, 'fallback_max_pct': 99.5,
    'neutral_from_segment': False, 'segment_take': 0, 'segment_start': 0.0, 'segment_end': 1.0,
    'stick_line': 0.99, 'stick_limit': 0.01, 'stick_widen': False, 'residual_line': 0.10,
}
RULES_V5 = dict(RULES_V4, brow_up_neutral_pct=75.0)
PRESETS = {'V4': RULES_V4, 'V5': RULES_V5}


def _r6(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('Rule values must be finite numbers.')
    return round(value, 6)


def normalize_rules(values):
    """Validate and round rule values (UI floats are float32)."""
    base = dict(RULES_V4)
    base.update(values or {})
    r = dict(base)
    r['percentile_digits'] = int(base['percentile_digits'])
    if not 0 <= r['percentile_digits'] <= 9:
        raise ValueError('Percentile rounding must be 0 to 9 digits.')
    for key in ('span_small', 'target_min', 'span_min', 'stick_line', 'stick_limit', 'residual_line',
                'segment_start', 'segment_end'):
        r[key] = _r6(base[key])
    for key in ('eye_neutral_pct', 'eye_max_pct', 'brow_down_neutral_pct', 'brow_up_neutral_pct',
                'brow_max_pct', 'fallback_neutral_pct', 'fallback_max_pct'):
        r[key] = _r6(base[key])
        if not 0 <= r[key] <= 100:
            raise ValueError('Percentiles must be between 0 and 100: ' + key)
    for key in ('span_small', 'target_min', 'span_min', 'stick_line', 'stick_limit', 'residual_line'):
        if not 0 <= r[key] <= 1:
            raise ValueError('Rule values must be between 0 and 1: ' + key)
    if r['span_min'] < MIN_SPAN:
        raise ValueError('Minimum span must be at least 0.000001.')
    for key in ('jaw_knot1', 'jaw_knot2'):
        x, y = base[key]
        r[key] = (_r6(x), _r6(y))
    (x1, y1), (x2, y2) = r['jaw_knot1'], r['jaw_knot2']
    if not (0 < x1 < x2 < 1 and 0 <= y1 <= y2 <= 1):
        raise ValueError('jawOpen knots need 0 < x1 < x2 < 1 and 0 <= y1 <= y2 <= 1.')
    caps = {}
    for name in EYE_LOOK:
        cap = _r6(dict(base['eye_caps']).get(name, 1.0))
        if not 0 < cap <= 1:
            raise ValueError('Gaze caps must be above 0 and at most 1: ' + name)
        caps[name] = cap
    r['eye_caps'] = caps
    r['jaw_rule'] = bool(base['jaw_rule'])
    r['stick_widen'] = bool(base['stick_widen'])
    r['neutral_from_segment'] = bool(base['neutral_from_segment'])
    r['segment_take'] = int(base['segment_take'])
    if r['segment_take'] < 0 or r['segment_end'] < r['segment_start'] or r['segment_start'] < 0:
        raise ValueError('Neutral segment needs take 0 or more and start <= end.')
    return r


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()


def read_take(path):
    """RAW values exactly as written in the CSV (no clamping), with provenance."""
    path = Path(path)
    if path.suffix.lower() != '.csv' or not path.is_file() or path.stat().st_size > MAX_CSV_BYTES:
        raise ValueError('Choose capture CSV files within 20 MiB: ' + path.name)
    clip = read_csv(path, range_policy='preserve')
    return {'path': str(path), 'name': path.stem, 'sha256': sha256_file(path), 'frames': len(clip.times),
            'clip': clip, 'out_of_range': len(clip.range_violations)}


def percentile(values, q, digits):
    ordered = sorted(values)
    if not ordered:
        raise ValueError('No values to count.')
    return round(ordered[int(q / 100.0 * (len(ordered) - 1))], digits)


def _side_json(path):
    path = Path(path)
    if not path.is_file() or path.stat().st_size > MAX_SIDE_BYTES:
        raise ValueError('Choose a JSON/CSV file within 2 MiB: ' + path.name)
    return json.loads(path.read_text(encoding='utf-8-sig'))


def read_targets(path):
    """Targeted maxima per channel.

    .json  segment table: {"区間"|"segments": [{"狙った表情の最大"|"targets": {channel: {"値"|"value": v}}}]}
           (the largest value per channel wins) or a flat {channel: number} / {"targets": {...}}.
    .csv   the maximum of each channel over that capture.
    """
    path = Path(path)
    out = {}
    if path.suffix.lower() == '.csv':
        clip = read_take(path)['clip']
        for name, series in clip.channels.items():
            out[name] = max(series)
        return out, 'CSV_MAX'
    if path.suffix.lower() != '.json':
        raise ValueError('Targets must be a JSON or CSV file.')
    data = _side_json(path)
    segments = None
    if isinstance(data, dict):
        segments = data.get('区間', data.get('segments'))
    if isinstance(segments, list):
        for seg in segments:
            if not isinstance(seg, dict):
                continue
            block = seg.get('狙った表情の最大', seg.get('targets', {}))
            if not isinstance(block, dict):
                continue
            for label, item in block.items():
                name = canonical_name(label)
                if not name or not isinstance(item, dict):
                    continue
                value = item.get('値', item.get('value'))
                if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 1:
                    continue
                if name not in out or value > out[name]:
                    out[name] = float(value)
        return out, 'SEGMENT_TABLE'
    flat = data.get('targets', data) if isinstance(data, dict) else None
    if not isinstance(flat, dict):
        raise ValueError('Unknown target table format.')
    for label, value in flat.items():
        name = canonical_name(label)
        if name and type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1:
            out[name] = float(value)
    if not out:
        raise ValueError('The target table has no ARKit channel values.')
    return out, 'FLAT'


def caps_from_sweep(path, vis_min):
    """Gaze caps from a visibility sweep {channel: {"0.0": {"vis": v}, "0.1": ...}}.

    The cap is the upper end of the run, starting at 0, where vis >= vis_min (1.0 = no cap).
    """
    data = _side_json(path)
    if not isinstance(data, dict):
        raise ValueError('Unknown sweep format.')
    vis_min = _r6(vis_min)
    caps = {}
    for name in EYE_LOOK:
        sweep = data.get(name)
        if not isinstance(sweep, dict) or not sweep:
            continue
        points = []
        for key, item in sweep.items():
            try:
                amount = float(key)
            except ValueError:
                continue
            vis = item.get('vis') if isinstance(item, dict) else None
            if type(vis) in (int, float) and math.isfinite(vis) and 0 <= amount <= 1:
                points.append((amount, float(vis)))
        top = 0.0
        for amount, vis in sorted(points):
            if vis >= vis_min:
                top = amount
            else:
                break
        if top > 0:
            caps[name] = min(1.0, top)
    if not caps:
        raise ValueError('The sweep file has no eyeLook channels with visible amounts.')
    return caps


def map_value(row, value):
    """Same mapping as capture_calibration.apply for one value."""
    mapped = (float(value) - row['neutral']) / (row['max'] - row['neutral'])
    if row.get('clamp', True):
        mapped = max(0.0, min(1.0, mapped))
    if 'knots' in row:
        mapped = calibration._evaluate_knots(row['knots'], mapped)
    return mapped


def _segment_values(takes, rules, name):
    chosen = takes if rules['segment_take'] == 0 else [takes[rules['segment_take'] - 1]]
    values = []
    for take in chosen:
        clip = take['clip']
        t0 = clip.times[0]
        for t, v in zip(clip.times, clip.channels[name]):
            if rules['segment_start'] - 1e-9 <= t - t0 <= rules['segment_end'] + 1e-9:
                values.append(v)
    return values


def build(takes, rules, *, base=None, targets=None):
    """Return (table, report). ``takes`` from read_take, ``base`` a normalized table or None."""
    rules = normalize_rules(rules)
    if not takes:
        raise ValueError('Add at least one capture CSV.')
    if len(takes) > MAX_TAKES:
        raise ValueError('Use at most 64 captures.')
    if rules['segment_take'] > len(takes):
        raise ValueError('The neutral segment take number is larger than the capture count.')
    targets = dict(targets or {})
    digits = rules['percentile_digits']
    common = set(ARKIT_NAMES)
    for take in takes:
        common &= set(take['clip'].channels)
    if base is not None:
        base = calibration.normalize(base)
        names = [n for n in ARKIT_NAMES if n in base['channels']]
    else:
        names = [n for n in ARKIT_NAMES if n in common and n not in MANUAL_ONLY]
    missing = [n for n in names if n not in common]
    if missing:
        raise ValueError('Every capture must have these columns: ' + ', '.join(missing))
    values = {n: [v for take in takes for v in take['clip'].channels[n]] for n in names}
    seg_values = {n: _segment_values(takes, rules, n) for n in names}
    if any(not v for v in seg_values.values()):
        raise ValueError('The neutral segment has no frames.')

    def pct(name, q):
        return percentile(values[name], q, digits)

    def neutral_pct(name, q):
        if rules['neutral_from_segment']:
            return percentile(seg_values[name], q, digits)
        return pct(name, q)

    def fixed_span(neutral, maximum):
        if maximum - neutral >= MIN_SPAN:
            return maximum
        return min(1.0, neutral + rules['span_min'])

    rows, why = {}, {}
    for name in names:
        if base is not None:
            prev = dict(base['channels'][name])
        else:
            n0 = pct(name, rules['fallback_neutral_pct'])
            prev = {'neutral': n0, 'max': fixed_span(n0, pct(name, rules['fallback_max_pct'])), 'clamp': True}
        target = targets.get(name)
        if name == JAW and rules['jaw_rule']:
            if target is not None and target - prev['neutral'] >= MIN_SPAN:
                (x1, y1), (x2, y2) = rules['jaw_knot1'], rules['jaw_knot2']
                rows[name] = {'neutral': prev['neutral'], 'max': target, 'clamp': True,
                              'knots': [[0.0, 0.0], [x1, y1], [x2, y2], [1.0, 1.0]]}
                why[name] = 'A'
            else:
                rows[name] = prev
                why[name] = 'A_SKIPPED_NO_TARGET'
            continue
        if name in EYE_LOOK:
            neutral = neutral_pct(name, rules['eye_neutral_pct'])
            maximum = max(prev['max'], target if target is not None else 0.0, pct(name, rules['eye_max_pct']))
            row = {'neutral': neutral, 'max': fixed_span(neutral, maximum), 'clamp': True}
            cap = rules['eye_caps'][name]
            if cap < 1.0:
                row['knots'] = [[0.0, 0.0], [1.0, cap]]
            rows[name] = row
            why[name] = 'E'
            continue
        if name in BROW_DOWN or name in BROW_UP:
            q = rules['brow_down_neutral_pct'] if name in BROW_DOWN else rules['brow_up_neutral_pct']
            neutral = neutral_pct(name, q)
            rows[name] = {'neutral': neutral, 'max': fixed_span(neutral, pct(name, rules['brow_max_pct'])), 'clamp': True}
            why[name] = 'F'
            continue
        span = prev['max'] - prev['neutral']
        if span >= rules['span_small']:
            rows[name] = prev
            why[name] = 'KEEP'
            continue
        if target is not None and target >= rules['target_min'] and target - prev['neutral'] >= MIN_SPAN:
            rows[name] = {'neutral': prev['neutral'], 'max': target, 'clamp': True}
            why[name] = 'D'
        else:
            rows[name] = {'neutral': prev['neutral'], 'max': fixed_span(prev['neutral'], min(1.0, prev['neutral'] + rules['span_min'])), 'clamp': True}
            why[name] = 'C'

    def stick_share(name, row):
        return sum(1 for v in values[name] if map_value(row, v) >= rules['stick_line']) / len(values[name])

    if rules['stick_widen']:
        q = 100.0 - 100.0 * rules['stick_limit']
        for name in names:
            row = rows[name]
            if stick_share(name, row) > rules['stick_limit']:
                wider = pct(name, q)
                if wider > row['max']:
                    row = dict(row, max=wider)
                    rows[name] = row
                    why[name] += '+G'

    version = 2 if any('knots' in r for r in rows.values()) else 1
    table = calibration.normalize({'format': calibration.FORMAT, 'version': version, 'channels': rows})
    channels = {}
    for name in names:
        row = table['channels'][name]
        mapped = sorted(map_value(row, v) for v in values[name])
        seg_mapped = [map_value(row, v) for v in seg_values[name]]
        stick = stick_share(name, row)
        residual = max(seg_mapped)
        prev = None if base is None else base['channels'][name]
        channels[name] = {
            'rule': why[name], 'target': targets.get(name),
            'raw': {'p50': pct(name, 50.0), 'p75': pct(name, 75.0), 'p95': pct(name, 95.0), 'p99': pct(name, 99.0),
                    'p99_5': pct(name, 99.5), 'max': round(max(values[name]), digits)},
            'previous': prev, 'row': row,
            'after': {'p50': round(mapped[int(0.5 * (len(mapped) - 1))], 6), 'p95': round(mapped[int(0.95 * (len(mapped) - 1))], 6),
                      'stick_share': round(stick, 6), 'neutral_segment_max': round(residual, 6)},
            'flags': [f for f, bad in (('STICK', stick > rules['stick_limit']),
                                       ('NEUTRAL_RESIDUAL', residual > rules['residual_line'])) if bad],
        }
    report = {
        'format': FORMAT_REPORT, 'version': 1,
        'takes': [{'path': t['path'], 'sha256': t['sha256'], 'frames': t['frames'], 'out_of_range': t['out_of_range']} for t in takes],
        'frames': sum(t['frames'] for t in takes), 'rules': _rules_json(rules),
        'percentile_definition': 'sorted(values)[int(q/100*(n-1))], rounded to percentile_digits; all frames of all captures',
        'channels': channels,
        'changed': sorted(n for n in names if base is None or table['channels'][n] != base['channels'][n]),
        'flag_counts': {'STICK': sum('STICK' in c['flags'] for c in channels.values()),
                        'NEUTRAL_RESIDUAL': sum('NEUTRAL_RESIDUAL' in c['flags'] for c in channels.values())},
    }
    return table, report


def _rules_json(rules):
    out = dict(rules)
    out['jaw_knot1'] = list(rules['jaw_knot1'])
    out['jaw_knot2'] = list(rules['jaw_knot2'])
    out['eye_caps'] = dict(rules['eye_caps'])
    return out


def write_new(path, text):
    """Write text to a NEW file only (never replaces an existing file)."""
    path = Path(path)
    if path.exists():
        raise ValueError('Protecting an existing file; choose a new file name: ' + path.name)
    with path.open('x', encoding='utf-8', newline='') as stream:
        stream.write(text)
    return str(path)


def report_path(table_path):
    table_path = Path(table_path)
    return table_path.with_name(table_path.stem + '_report.json')
