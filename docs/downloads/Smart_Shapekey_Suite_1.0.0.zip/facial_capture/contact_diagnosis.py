# SPDX-License-Identifier: GPL-3.0-or-later
"""Finite user-invoked intersection report; no geometry, pose or runtime changes."""
import array,hashlib,json,math
from collections import Counter
import bpy
from mathutils.bvhtree import BVHTree

REPORT_OWNER='smart_shapekey_suite.contact_diagnosis.v1'
MAX_TRIANGLES=20000
MAX_DENSE_SCAN_VERTICES=60000
MAX_DENSE_SCAN_TRIANGLES=120000
MAX_AABB_CHECKS=250000
MAX_CANDIDATES=20000
MAX_SAMPLES=128

def segment_hit(a,b,tri):
    origin=tri[0];e1=tri[1]-origin;e2=tri[2]-origin;direction=b-a
    h=direction.cross(e2);det=e1.dot(h)
    if abs(det)<1e-15:return None
    inv=1/det;s=a-origin;u=inv*s.dot(h)
    if u< -1e-7 or u>1+1e-7:return None
    q=s.cross(e1);v=inv*direction.dot(q)
    if v< -1e-7 or u+v>1+1e-7:return None
    t=inv*e2.dot(q)
    return a+direction*t if -1e-7<=t<=1+1e-7 else None

def crossing(a,b):
    hits=[]
    for tri,other in ((a,b),(b,a)):
        for i in range(3):
            point=segment_hit(tri[i],tri[(i+1)%3],other)
            if point is not None and not any((point-p).length<1e-7 for p in hits):hits.append(point)
    na=(a[1]-a[0]).cross(a[2]-a[0]);nb=(b[1]-b[0]).cross(b[2]-b[0])
    coplanar=na.length>1e-14 and nb.length>1e-14 and na.normalized().cross(nb.normalized()).length<1e-6 and abs(na.normalized().dot(b[0]-a[0]))<1e-7
    return hits,coplanar

def source_support_allowed(source_vertices,evaluated_vertices,source_polygons,evaluated_polygons,modifiers):
    # Counts alone cannot prove vertex identity after Mirror/Geometry Nodes/reordering.
    if any(kind!='ARMATURE' and not(kind=='SUBSURF' and level==0) for kind,level in modifiers):return False
    return source_vertices==evaluated_vertices and source_polygons==evaluated_polygons

def subdivision_evidence(source_count,evaluated_count,modifiers,use_simplify,simplify_limit):
    enabled=[min(m['viewport_level'],simplify_limit) if use_simplify else m['viewport_level'] for m in modifiers if m['viewport_enabled']]
    requested=max(enabled,default=0);growth=evaluated_count>source_count
    observed=requested>0 and growth
    status='評価頂点の増加を確認' if observed else ('有効な細分化による頂点増加なし' if requested>0 else '表示の細分化は無効または実効段階0')
    return dict(source_vertex_count=source_count,evaluated_vertex_count=evaluated_count,vertex_growth_observed=growth,
        enabled_subdivision_density_observed=observed,effective_requested_viewport_level=requested,
        configured_modifiers=modifiers,scene_use_simplify=bool(use_simplify),scene_simplify_subdivision=int(simplify_limit),
        settings_alone_certify_subdivision=False,subdivision_level_certified=False,other_modifiers_can_change_topology=True,status=status)

def secondary_triangle_ids(points,tris,reference_bounds):
    if len(points)>MAX_DENSE_SCAN_VERTICES or len(tris)>MAX_DENSE_SCAN_TRIANGLES:
        raise ValueError('局所探索の読み取り上限は60,000頂点・120,000三角形です')
    if not points or len(reference_bounds)!=2 or any(len(v)!=3 for v in reference_bounds):raise ValueError('局所探索の参照範囲が不正です')
    if any(not math.isfinite(v) for p in points for v in p) or any(not math.isfinite(v) for p in reference_bounds for v in p):raise ValueError('局所探索の座標は有限値にしてください')
    lo,hi=reference_bounds
    if any(lo[k]>hi[k] for k in range(3)):raise ValueError('局所探索の参照範囲が不正です')
    # Intersection with the reference requires AABB overlap. Retain whole original
    # triangles; conservative padding also covers the existing sweep tolerance.
    padding=max(1e-7,max(abs(v) for p in points for v in p)*1e-5,max(abs(v) for p in reference_bounds for v in p)*1e-5)
    kept=[]
    for i,t in enumerate(tris):
        pp=[points[k] for k in t]
        if any(max(p[k] for p in pp)<lo[k]-padding or min(p[k] for p in pp)>hi[k]+padding for k in range(3)):continue
        if len(kept)>=MAX_TRIANGLES:raise ValueError('局所探索後も20,000三角形を超えています。選択部品または表示段階を減らしてください')
        kept.append(i)
    return kept

def geometry(obj,depsgraph,*,reference_bounds=None):
    evaluated=obj.evaluated_get(depsgraph);mesh=evaluated.to_mesh()
    try:
        mesh.calc_loop_triangles()
        render=depsgraph.scene_eval.render
        subdivision=subdivision_evidence(len(obj.data.vertices),len(mesh.vertices),[dict(name=m.name,viewport_enabled=bool(m.show_viewport),viewport_level=int(m.levels),render_enabled=bool(m.show_render),render_level=int(m.render_levels)) for m in obj.modifiers if m.type=='SUBSURF'],render.use_simplify,render.simplify_subdivision)
        dense=len(mesh.loop_triangles)>MAX_TRIANGLES
        if dense and reference_bounds is not None and (len(mesh.vertices)>MAX_DENSE_SCAN_VERTICES or len(mesh.loop_triangles)>MAX_DENSE_SCAN_TRIANGLES):raise ValueError('局所探索の読み取り上限は60,000頂点・120,000三角形です: '+obj.name)
        if len(mesh.loop_triangles)==0 or (dense and reference_bounds is None):raise ValueError('対象の評価済み三角形は1～20,000個にしてください: '+obj.name+' / 元頂点 '+str(len(obj.data.vertices))+' → 評価頂点 '+str(len(mesh.vertices))+' / '+subdivision['status'])
        points=[evaluated.matrix_world@v.co for v in mesh.vertices]
        if any(not math.isfinite(v) for p in points for v in p):raise ValueError('座標が有限値ではありません: '+obj.name)
        tris=[tuple(t.vertices) for t in mesh.loop_triangles];ids=secondary_triangle_ids(points,tris,reference_bounds) if dense else list(range(len(tris)))
        full_triangles=len(tris);tris=[tris[i] for i in ids];edges=Counter()
        geometry_scope=dict(mode='REFERENCE_AABB' if dense else 'FULL',full_evaluated_triangles=full_triangles,retained_triangles=len(tris),reference_bounds=reference_bounds if dense else None,retained_original_triangle_ids=ids if dense else None,triangles_unchanged=True,reference_intersection_candidates_preserved=True,whole_surface_clearance_accepted=False)
        polys=[tuple(p.vertices) for p in mesh.polygons]
        enabled=[(m.type,int(m.levels) if m.type=='SUBSURF' else None) for m in obj.modifiers if m.show_viewport]
        allowed=all(kind=='ARMATURE' or (kind=='SUBSURF' and level==0) for kind,level in enabled)
        originals=[tuple(p.vertices) for p in obj.data.polygons] if allowed else []
        exact=not dense and source_support_allowed(len(obj.data.vertices),len(mesh.vertices),originals,polys,enabled)
        for poly in mesh.polygons:
            vv=list(poly.vertices)
            for a,b in zip(vv,vv[1:]+vv[:1]):edges[tuple(sorted((a,b)))]+=1
        signature=hashlib.sha256(array.array('f',(v for p in points for v in p)).tobytes()+json.dumps(tris,separators=(',',':')).encode()).hexdigest()
        return dict(points=points,tris=tris,polys=polys,signature=signature,triangle_polygons=[mesh.loop_triangles[i].polygon_index for i in ids],geometry_scope=geometry_scope,
            source_support=dict(exact_source_vertex_mapping=exact,source_vertex_count=len(obj.data.vertices),evaluated_vertex_count=len(mesh.vertices),enabled_modifiers=[dict(type=k,subdivision_level=v) for k,v in enabled],
                reason='Armature・段階0のサブディビジョンのみ。頂点数と面の頂点順が一致' if exact else '元頂点への対応は未証明。評価済み番号を編集用の番号として使用しない'),
            subdivision_evidence=subdivision,boundary_edges=sum(v==1 for v in edges.values()),nonmanifold_edges=sum(v>2 for v in edges.values()))
    finally:evaluated.to_mesh_clear()

def candidate_pairs(first,second):
    # Incremental sweep bounds candidate allocation even for densely overlapping meshes.
    boxes=[]
    bounds=[(tuple(min(p[k] for p in geo['points']) for k in range(3)),tuple(max(p[k] for p in geo['points']) for k in range(3))) for geo in (first,second)]
    for side,geo in enumerate((first,second)):
        for i,tri in enumerate(geo['tris']):
            pp=[geo['points'][k] for k in tri]
            margin=max(1e-7,max(abs(v) for p in pp for v in p)*1e-6)
            lo=tuple(min(p[k] for p in pp)-margin for k in range(3));hi=tuple(max(p[k] for p in pp)+margin for k in range(3))
            otherlo,otherhi=bounds[1-side]
            if any(hi[k]<otherlo[k] or otherhi[k]<lo[k] for k in range(3)):continue
            boxes.append((lo[0],side,i,lo,hi))
    active=[{},{}];checks=0;count=0
    for x,side,i,lo,hi in sorted(boxes):
        for bucket in active:
            for j in [j for j,(_,end) in bucket.items() if end[0]<x]:del bucket[j]
        for j,(start,end) in active[1-side].items():
            checks+=1
            if checks>MAX_AABB_CHECKS:raise ValueError('交差候補の探索上限に達しました。選択部品またはサブディビジョン表示段階を減らしてください')
            if any(hi[k]<start[k] or end[k]<lo[k] for k in (1,2)):continue
            count+=1
            if count>MAX_CANDIDATES:raise ValueError('交差候補は20,000組を上限にしています。部品またはサブディビジョン表示段階を減らしてください')
            yield (i,j) if side==0 else (j,i)
        active[side][i]=(lo,hi)

def diagnose_selected(context):
    if context.mode!='OBJECT':raise ValueError('オブジェクトモードで舌をアクティブにし、顔・上下歯を選択してください')
    selected=sorted((o for o in context.selected_objects if o.type=='MESH'),key=lambda o:o.name)
    reference=context.view_layer.objects.active
    if reference is None or reference.type!='MESH' or reference not in selected or not 2<=len(selected)<=4:
        raise ValueError('舌をアクティブにし、検査する顔・歯と合わせて2～4メッシュを選択してください')
    if any(o.type!='MESH' for o in context.selected_objects):raise ValueError('検査にはメッシュだけを選択してください')
    depsgraph=context.evaluated_depsgraph_get();primary=geometry(reference,depsgraph)
    bounds=(tuple(min(p[k] for p in primary['points']) for k in range(3)),tuple(max(p[k] for p in primary['points']) for k in range(3)))
    geos={o.name:(primary if o==reference else geometry(o,depsgraph,reference_bounds=bounds)) for o in selected}
    first=geos[reference.name]
    report=dict(schema_version=3,reference_part=reference.name,reference_mesh=reference.data.name,reference_active_key=reference.active_shape_key.name if reference.active_shape_key else None,frame=float(context.scene.frame_current_final),
        visibility_evaluated=False,material_alpha_evaluated=False,containment_evaluated=False,full_clearance_accepted=False,
        geometry_and_animation_modified=False,budgets=dict(dense_secondary_scan_vertices=MAX_DENSE_SCAN_VERTICES,dense_secondary_scan_triangles=MAX_DENSE_SCAN_TRIANGLES,triangles_per_part=MAX_TRIANGLES,aabb_checks_per_pair=MAX_AABB_CHECKS,candidates_per_pair=MAX_CANDIDATES,sample_pairs=MAX_SAMPLES),surface={})
    report['pose_values']={}
    report['source_vertex_support']={name:geo['source_support'] for name,geo in geos.items()}
    report['subdivision_evidence']={name:geo['subdivision_evidence'] for name,geo in geos.items()}
    report['geometry_scope']={name:geo['geometry_scope'] for name,geo in geos.items()}
    report['geometry_signatures']={name:geo['signature'] for name,geo in geos.items()}
    for obj in selected:
        keys=obj.data.shape_keys
        if keys:report['pose_values'][obj.name]={k.name:float(k.value) for k in keys.evaluated_get(depsgraph).key_blocks if k.name!='Basis' and abs(k.value)>1e-8}
    for obj in selected:
        if obj==reference:continue
        second=geos[obj.name];candidates=0;exact=0;coplanar=0;samples=[]
        guard_candidates=sum(1 for _ in candidate_pairs(first,second))
        native_candidates=[]
        if first['tris'] and second['tris']:
            a=BVHTree.FromPolygons(first['points'],first['tris'],all_triangles=True)
            b=BVHTree.FromPolygons(second['points'],second['tris'],all_triangles=True)
            native_candidates=a.overlap(b)
        if len(native_candidates)>MAX_CANDIDATES:raise ValueError('BVH交差候補は20,000組を上限にしています')
        for i,j in native_candidates:
            candidates+=1;hits,cop=crossing([first['points'][k] for k in first['tris'][i]],[second['points'][k] for k in second['tris'][j]])
            if cop:coplanar+=1
            elif hits:
                exact+=1
                if len(samples)<MAX_SAMPLES:
                    rp=first['triangle_polygons'][i];sp=second['triangle_polygons'][j]
                    rv=first['tris'][i];sv=second['tris'][j]
                    ra,rb,rc=[first['points'][k] for k in rv];sa,sb,sc=[second['points'][k] for k in sv]
                    re=first['source_support']['exact_source_vertex_mapping'];se=second['source_support']['exact_source_vertex_mapping']
                    samples.append(dict(reference_triangle=i,surface_triangle=j,world_points_mm=[[v*1000 for v in p] for p in hits],
                        reference_evaluated_vertices=list(rv),surface_evaluated_vertices=list(sv),reference_world_normal=list((rb-ra).cross(rc-ra).normalized()),surface_world_normal=list((sb-sa).cross(sc-sa).normalized()),
                        reference_source_vertices=list(rv) if re else None,reference_source_polygon=rp if re else None,reference_source_polygon_vertices=list(first['polys'][rp]) if re else None,
                        surface_source_vertices=list(sv) if se else None,surface_source_polygon=sp if se else None,surface_source_polygon_vertices=list(second['polys'][sp]) if se else None))
        report['surface'][obj.name]=dict(aabb_guard_candidate_pairs=guard_candidates,bvh_candidate_pairs=candidates,exact_noncoplanar_intersecting_pairs=exact,unresolved_coplanar_candidate_pairs=coplanar,
            reference_triangles=len(first['tris']),surface_triangles=len(second['tris']),reference_boundary_edges=first['boundary_edges'],surface_boundary_edges=second['boundary_edges'],
            reference_nonmanifold_edges=first['nonmanifold_edges'],surface_nonmanifold_edges=second['nonmanifold_edges'],sample_pairs=samples,sample_pairs_truncated=exact>len(samples))
    return report

def validated_report_sample(context,surface_name,sample_index):
    from .corrective_authoring import _object,_records,_verify
    if context.mode!='OBJECT':raise ValueError('Select contact vertices from Object Mode.')
    obj,keys=_object(context);target=obj.active_shape_key;records=_records(obj)
    record=records.get(target.name) if target else None
    if not record or record['status']!='PREPARED':raise ValueError('Activate an owned prepared editing target before selecting contacts.')
    _verify(obj,keys,record)
    cfg=context.scene.smart_shapekey_facial_settings;text=bpy.data.texts.get(cfg.contact_report_name)
    if not(text and not text.library and text.get('ss_contact_owner')==REPORT_OWNER and text.get('ss_contact_scene')==context.scene.name):raise ValueError('Run the owned contact report before selecting vertices.')
    raw=text.as_string()
    if len(raw)>2*1024*1024:raise ValueError('Contact report exceeds the selection read limit.')
    data=json.loads(raw)
    if data.get('schema_version')!=3 or data.get('reference_part')!=obj.name or data.get('reference_mesh')!=obj.data.name or data.get('reference_active_key')!=target.name:raise ValueError('Reinspect the current editing target before selecting vertices.')
    if abs(float(data['frame'])-context.scene.frame_current_final)>1e-6:raise ValueError('The contact report frame is stale. Reinspect the current target.')
    current=geometry(obj,context.evaluated_depsgraph_get())
    if not current['source_support']['exact_source_vertex_mapping']:raise ValueError('Current source vertex mapping is unavailable.')
    if data['geometry_signatures'].get(obj.name)!=current['signature']:raise ValueError('The contact report geometry is stale. Reinspect the current target.')
    row=data['surface'].get(surface_name)
    if not row or not 0<=sample_index<len(row['sample_pairs']):raise ValueError('Choose a reported surface and an available sample number.')
    sample=row['sample_pairs'][sample_index];poly=sample.get('reference_source_polygon');indices=sample.get('reference_source_polygon_vertices')
    if type(poly)!=int or not 0<=poly<len(obj.data.polygons) or not isinstance(indices,list) or not 1<=len(indices)<=64 or any(type(v)!=int for v in indices):raise ValueError('The report has no verified source polygon for this sample.')
    indices=sorted(set(indices))
    if indices!=sorted(obj.data.polygons[poly].vertices):raise ValueError('Reported source polygon vertices differ from the current mesh.')
    return obj,target,text,data,current,poly,indices

def select_report_vertices(context,surface_name,sample_index):
    obj,target,text,data,current,poly,indices=validated_report_sample(context,surface_name,sample_index)
    old_selected={o:o.select_get() for o in context.view_layer.objects};active=context.view_layer.objects.active
    old_flags=([v.select for v in obj.data.vertices],[e.select for e in obj.data.edges],[p.select for p in obj.data.polygons]);old_mode=tuple(context.tool_settings.mesh_select_mode)
    try:
        for o in context.view_layer.objects:o.select_set(o==obj)
        context.view_layer.objects.active=obj
        for seq in (obj.data.vertices,obj.data.edges,obj.data.polygons):
            for item in seq:item.select=False
        for i in indices:obj.data.vertices[i].select=True
        context.tool_settings.mesh_select_mode=(True,False,False)
        if bpy.ops.object.mode_set(mode='EDIT')!={'FINISHED'}:raise RuntimeError('Could not enter the editing target.')
        return dict(object=obj.name,target=target.name,surface=surface_name,sample=sample_index,polygon=poly,vertices=indices,geometry_changed=False)
    except Exception:
        if obj.mode=='EDIT':bpy.ops.object.mode_set(mode='OBJECT')
        for seq,flags in zip((obj.data.vertices,obj.data.edges,obj.data.polygons),old_flags):
            for item,flag in zip(seq,flags):item.select=flag
        context.tool_settings.mesh_select_mode=old_mode
        for o,flag in old_selected.items():o.select_set(flag)
        context.view_layer.objects.active=active
        raise

def write_report(context,report):
    cfg=context.scene.smart_shapekey_facial_settings
    old_name=cfg.contact_report_name;old_status=cfg.contact_report_status
    text=bpy.data.texts.get(cfg.contact_report_name)
    if not(text and not text.library and text.get('ss_contact_owner')==REPORT_OWNER and text.get('ss_contact_scene')==context.scene.name):text=None
    content=json.dumps(report,ensure_ascii=False,indent=2)
    previous=text.as_string() if text else None;created=text is None
    if created:text=bpy.data.texts.new('SS_Facial_Contact_Report')
    try:
        text.clear();text.write(content);text['ss_contact_owner']=REPORT_OWNER;text['ss_contact_scene']=context.scene.name
        cfg.contact_report_name=text.name
        cfg.contact_report_status='\n'.join([n+': '+str(row['exact_noncoplanar_intersecting_pairs'])+'組' for n,row in report['surface'].items()]+[n+': '+str(row['source_vertex_count'])+'→'+str(row['evaluated_vertex_count'])+'頂点 / '+row['status'] for n,row in report.get('subdivision_evidence',{}).items()]+[n+': 局所探索 '+str(row['retained_triangles'])+'/'+str(row['full_evaluated_triangles'])+'三角形' for n,row in report.get('geometry_scope',{}).items() if row['mode']=='REFERENCE_AABB'])
    except Exception:
        if created:bpy.data.texts.remove(text)
        else:text.clear();text.write(previous)
        cfg.contact_report_name=old_name;cfg.contact_report_status=old_status
        raise
    return text.name
