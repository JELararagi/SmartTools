"""Explicit MediaPipe -> named ARKit CSV adapter; no guessed tongue coefficient."""
import math
try:
    from .capture_csv import ARKIT_NAMES,canonical_name
except ImportError:
    from capture_csv import ARKIT_NAMES,canonical_name
EXPECTED_CHANNELS=tuple(n for n in ARKIT_NAMES if n!='tongueOut')

def coefficients(categories):
    values={}
    for category in categories:
        label=category.category_name
        if label=='_neutral':continue
        name=canonical_name(label)
        if not name or name not in EXPECTED_CHANNELS:raise ValueError('Unsupported MediaPipe category: '+str(label))
        if name in values:raise ValueError('Duplicate MediaPipe category: '+name)
        score=float(category.score)
        if not math.isfinite(score) or not 0<=score<=1:raise ValueError('Invalid MediaPipe score: '+name)
        values[name]=score
    missing=set(EXPECTED_CHANNELS)-set(values)
    if missing:raise ValueError('MediaPipe schema missing: '+', '.join(sorted(missing)))
    return {n:values[n] for n in EXPECTED_CHANNELS}
