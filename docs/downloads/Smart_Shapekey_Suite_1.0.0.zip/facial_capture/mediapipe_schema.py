# SPDX-License-Identifier: GPL-3.0-or-later
"""Map scores from an external MediaPipe session to supported output columns."""

from math import isfinite

if __package__:
    from .capture_csv import ARKIT_NAMES, canonical_name
else:
    from capture_csv import ARKIT_NAMES, canonical_name


EXPECTED_CHANNELS = tuple(channel for channel in ARKIT_NAMES if channel != "tongueOut")
_EXPECTED = frozenset(EXPECTED_CHANNELS)


def coefficients(categories):
    scores = {}
    for item in categories:
        if item.category_name == "_neutral":
            continue
        channel = canonical_name(item.category_name)
        if channel not in _EXPECTED:
            raise ValueError(f"Unsupported MediaPipe category: {item.category_name}")
        score = float(item.score)
        if channel in scores:
            raise ValueError(f"Duplicate MediaPipe category: {channel}")
        if not isfinite(score) or not 0 <= score <= 1:
            raise ValueError(f"Invalid MediaPipe score: {channel}")
        scores[channel] = score
    missing = _EXPECTED.difference(scores)
    if missing:
        raise ValueError("MediaPipe schema missing: " + ", ".join(sorted(missing)))
    return dict(zip(EXPECTED_CHANNELS, map(scores.__getitem__, EXPECTED_CHANNELS)))
