# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit, removable jaw clearance using existing shapes and standard drivers."""
import hashlib, math
from types import SimpleNamespace
import bpy
from . import combination_driver as connection
from .capture_csv import canonical_name
from .shape_library import coordinates, digest

MODES={'JAW_FLOOR','FLOOR_BOX','FLOOR_PLATEAU','FLOOR_RAMP'}

def _objects(context):
    from . import targets
    objects=targets(context)
    if sum(len(o.data.vertices) for o in objects)>2000000:
        raise ValueError('選択メッシュの合計頂点数は200万以下にしてください')
    for obj in objects:
        keys=obj.data.shape_keys
        if not keys.use_relative:raise ValueError('相対シェイプキーを使用してください')
    return objects

def _channel(obj,name):
    found=[k for k in obj.data.shape_keys.key_blocks if canonical_name(k.name)==name]
    if len(found)>1:raise ValueError('同じARKit表情の別名キーが複数あります: '+obj.name)
    return found[0] if found else None

def create(context,limit=.5):
    if type(limit) not in (int,float) or not math.isfinite(limit) or not .01<=limit<=1:
        raise ValueError('開口補助の上限は0.01から1にしてください')
    objects=_objects(context);plans=[]
    for obj in objects:
        keys=obj.data.shape_keys;records=connection._records(obj)
        ctx=SimpleNamespace(object=obj,selected_objects=objects,mode='OBJECT',view_layer=context.view_layer)
        jaw=_channel(obj,'jawOpen');tongue=_channel(obj,'tongueOut')
        if tongue:source_t=None;actual_t=tongue.name
        else:
            possible=[(o,_channel(o,'tongueOut')) for o in objects if o!=obj]
            possible=[(o,k) for o,k in possible if k]
            if len(possible)!=1:
                if jaw or any('jawOpen' in [canonical_name(n) for n in r['settings']['inputs']] for r in records.values()):
                    raise ValueError('舌入力の部品を1つ選択してください: '+obj.name)
                continue
            source_obj,source_key=possible[0];source_t=source_obj.name;actual_t=source_key.name
        candidates=[]
        if jaw and coordinates(jaw.data)!=coordinates(keys.reference_key.data):
            candidates.append(('SS_JawFloor_Jaw',jaw,'JAW_FLOOR',[limit,0],1,[source_t,None],[actual_t,jaw.name]))
        for name,record in records.items():
            settings=record['settings'];mode=settings.get('mode','BOX')
            if mode in MODES:continue
            canonical=[canonical_name(n) for n in settings['inputs']]
            if 'jawOpen' not in canonical:continue
            if set(canonical)!={'jawOpen','tongueOut'} or mode not in ('BOX','PLATEAU','RAMP'):
                raise ValueError('開口補助は顎と舌の2入力補正に対応します: '+name)
            source=keys.key_blocks.get(name);curve=connection._curve(keys,source.path_from_id('value')) if source else None
            if not source or source.relative_key!=keys.reference_key or source.vertex_group or source.mute or connection._signature(curve,keys)!=record['driver']:
                raise ValueError('元の補正またはドライバーが変更されています: '+name)
            connection._foreign_references(keys,source.path_from_id('value'),curve)
            refs=connection._input_keys(keys,settings);ti=canonical.index('tongueOut');ji=canonical.index('jawOpen')
            sources=settings.get('sources',[None,None]);centers=settings['centers']
            token=hashlib.sha256(name.encode('utf-8')).hexdigest()[:12]
            candidates.append(('SS_JawFloor_'+token,source,'FLOOR_'+mode,[centers[ti],centers[ji]],settings['radius'],[sources[ti],sources[ji]],[refs[ti][1].name,refs[ji][1].name]))
        for name,source,mode,centers,radius,sources,inputs in candidates:
            if source.relative_key!=keys.reference_key or source.vertex_group or source.mute:
                raise ValueError('Basis基準で未ミュートの形状を使用してください: '+source.name)
            settings=connection._settings(keys,source,*inputs,*centers,radius,context=ctx,mode=mode,sources=sources,jaw_floor=limit)
            data=coordinates(source.data);existing=keys.key_blocks.get(name)
            if existing:
                record=records.get(name);curve=connection._curve(keys,existing.path_from_id('value'))
                if not record or record['settings']!=settings or connection._signature(curve,keys)!=record['driver'] or coordinates(existing.data)!=data or existing.relative_key!=keys.reference_key or existing.vertex_group or existing.mute or existing.slider_min!=(-1 if mode!='JAW_FLOOR' else 0) or existing.slider_max!=1 or existing.interpolation!=source.interpolation:
                    raise ValueError('異なる既存開口補助キーを保護しています: '+name)
                connection._foreign_references(keys,existing.path_from_id('value'),curve)
            else:plans.append((obj,ctx,name,source,mode,centers,radius,sources,inputs,data))
        if len(records)+sum(p[0]==obj for p in plans)>32:
            raise ValueError('1メッシュの補正ドライバーは32個以内にしてください')
    if not plans:
        return {'created':0,'status':'KEPT','original_channels_preserved':True}
    originals={o.name:(o.active_shape_key_index,o.get(connection.PROPERTY),o.data.shape_keys.animation_data is None) for o in objects}
    created=[]
    try:
        for obj,ctx,name,source,mode,centers,radius,sources,inputs,data in plans:
            key=obj.shape_key_add(name=name,from_mix=False);created.append((obj,ctx,key))
            if key.name!=name:raise ValueError('指定した補助キー名が使用できません')
            key.relative_key=obj.data.shape_keys.reference_key;key.slider_min=-1 if mode!='JAW_FLOOR' else 0;key.slider_max=1;key.interpolation=source.interpolation;key.value=0
            # Standard shape key coordinates are copied, never original vertex/Basis data.
            key.data.foreach_set('co',[v for p in source.data for v in p.co])
            if coordinates(key.data)!=data:raise ValueError('補助形状の複製が一致しません')
            connection.bind(ctx,name,*inputs,*centers,radius,mode=mode,sources=sources,jaw_floor=limit)
        return {'created':len(created),'status':'CREATED','original_channels_preserved':True}
    except Exception:
        for obj,ctx,key in reversed(created):
            if connection._curve(obj.data.shape_keys,key.path_from_id('value')):key.driver_remove('value')
            obj.shape_key_remove(key)
        for obj in objects:
            _,raw,ad_absent=originals[obj.name]
            if raw is None:
                if connection.PROPERTY in obj:del obj[connection.PROPERTY]
            else:obj[connection.PROPERTY]=raw
            keys=obj.data.shape_keys
            if ad_absent and keys.animation_data and not keys.animation_data.action and not keys.animation_data.nla_tracks and not keys.animation_data.drivers:keys.animation_data_clear()
        raise
    finally:
        for obj in objects:obj.active_shape_key_index=originals[obj.name][0]
        context.view_layer.update()

def remove(context):
    objects=_objects(context);plans=[]
    for obj in objects:
        keys=obj.data.shape_keys;ctx=SimpleNamespace(object=obj,selected_objects=objects,mode='OBJECT',view_layer=context.view_layer)
        for name,record in connection._records(obj).items():
            if record['settings'].get('mode') not in MODES:continue
            _,_,key=connection._target(ctx,name);curve=connection._curve(keys,key.path_from_id('value'))
            if connection._signature(curve,keys)!=record['driver']:raise ValueError('開口補助ドライバーが変更されています: '+name)
            connection._foreign_references(keys,key.path_from_id('value'),curve)
            plans.append((obj,ctx,key))
    # Every reference and ownership is checked before the first removal.
    active={o.name:o.active_shape_key.name if o.active_shape_key else None for o in objects}
    for obj,ctx,key in reversed(plans):
        connection.release(ctx,key.name);obj.shape_key_remove(key)
    for obj in objects:
        names=[k.name for k in obj.data.shape_keys.key_blocks]
        obj.active_shape_key_index=names.index(active[obj.name]) if active[obj.name] in names else 0
    context.view_layer.update()
    return {'removed':len(plans),'original_channels_preserved':True}
