"""Non-executable, exact-correspondence shape library for separate face/body work.

Only new shape keys and owned declarative corrective drivers are created. Basis, vertices, weights, rig, materials,
old keys and Actions are untouched. Different existing keys fail before mutation.
"""
import array,hashlib,json,math,os,sys,uuid,zipfile
from pathlib import Path
from .capture_csv import ARKIT_NAMES,canonical_name

MAX_BYTES=256*1024*1024

def coordinates(data):
    values=array.array('f',[0])*(len(data)*3);data.foreach_get('co',values)
    if sys.byteorder!='little':values.byteswap()
    return values.tobytes()

def digest(data):return hashlib.sha256(data).hexdigest()

def topology(mesh):
    values={'edges':[tuple(e.vertices) for e in mesh.edges],
            'faces':[tuple(p.vertices) for p in mesh.polygons]}
    return digest(json.dumps(values,separators=(',',':')).encode('ascii'))

def safe_objects(objects):
    objects=list(objects)
    if not objects or len(objects)>64:raise ValueError('対象は1〜64メッシュにしてください')
    seen=set()
    for obj in objects:
        if obj.type!='MESH':raise ValueError('メッシュを選択してください: '+obj.name)
        if obj.library or obj.data.library or not obj.is_editable or not obj.data.is_editable:
            raise ValueError('編集可能なローカルメッシュが必要です: '+obj.name)
        if obj.data.users!=1 or obj.data.as_pointer() in seen:raise ValueError('共有メッシュを保護します: '+obj.name)
        if len(obj.data.vertices)>200000:raise ValueError('対象は20万頂点以内にしてください: '+obj.name)
        if obj.data.shape_keys and (obj.data.shape_keys.library or not obj.data.shape_keys.is_editable):
            raise ValueError('編集できないシェイプキーを保護します: '+obj.name)
        seen.add(obj.data.as_pointer())
    return sorted(objects,key=lambda o:o.name)

def export_library(objects,path,*,selection_only=False):
    if type(selection_only) is not bool:raise ValueError("Invalid selected-part library option.")
    objects=safe_objects(objects);manifest={'format':'smart_shapekey_facial_library','version':1,'objects':[]}
    payload={};channels=set();size=0;corrective_count=0
    for i,obj in enumerate(objects):
        keys=obj.data.shape_keys
        if not keys or not keys.use_relative:raise ValueError('相対シェイプキーが必要です: '+obj.name)
        basis=keys.key_blocks[0]
        part={'name':obj.name,'vertex_count':len(obj.data.vertices),'vertices_sha256':digest(coordinates(obj.data.vertices)),
              'basis_sha256':digest(coordinates(basis.data)),'topology_sha256':topology(obj.data),'shapes':[]}
        names=set()
        for key in keys.key_blocks:
            channel=canonical_name(key.name)
            if not channel:continue
            if channel in names:raise ValueError('同じARKit表情の別名が重複しています: '+obj.name)
            if key.relative_key!=basis or key.vertex_group:raise ValueError('Basis基準・頂点グループなしのキーが必要です: '+key.name)
            data=coordinates(key.data)
            values=array.array('f');values.frombytes(data)
            if sys.byteorder!='little':values.byteswap()
            if any(not math.isfinite(v) for v in values):raise ValueError('非有限の座標があります: '+key.name)
            member=f'parts/{i:03d}/{channel}.f32';payload[member]=data;size+=len(data)
            part['shapes'].append({'name':channel,'member':member,'sha256':digest(data),
                'slider_min':key.slider_min,'slider_max':key.slider_max,'interpolation':key.interpolation})
            channels.add(channel);names.add(channel)
        if not part['shapes']:raise ValueError('ARKitキーがありません: '+obj.name)
        from .corrective_library import export_correctives
        count,extra_size=export_correctives(obj,i,part,payload);corrective_count+=count;size+=extra_size
        manifest['objects'].append(part)
    if corrective_count:manifest['version']=3 if any('sources' in row['box'] or row['box'].get('mode','BOX')!='BOX' for part in manifest['objects'] for row in part.get('correctives',[])) else 2
    if selection_only:
        manifest.update(version=4,scope="SELECTED_PARTS",channels=sorted(channels))
    if corrective_count:
        from .corrective_library import validate_input_parts
        validate_input_parts(manifest)
    if not selection_only and channels!=set(ARKIT_NAMES):raise ValueError('選択全体でARKit 52表情が必要です')
    if size>MAX_BYTES:raise ValueError('プリセットが256 MiBを超えます')
    path=Path(path);temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as archive:
            archive.writestr('manifest.json',json.dumps(manifest,separators=(',',':'),ensure_ascii=False).encode('utf-8'))
            for name,data in payload.items():archive.writestr(name,data)
        os.replace(temporary,path)
    finally:
        if temporary.exists():temporary.unlink()
    return {'parts':len(objects),'channels':len(channels),'shape_bindings':sum(len(p['shapes']) for p in manifest['objects']),
        'corrective_bindings':corrective_count,'preset_version':manifest['version']}

def read_library(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>MAX_BYTES:raise ValueError('256 MiB以内のプリセットが必要です')
    with zipfile.ZipFile(path) as archive:
        infos=archive.infolist();names=[i.filename for i in infos]
        if len(infos)>5500 or len(names)!=len(set(names)) or sum(i.file_size for i in infos)>MAX_BYTES:
            raise ValueError('プリセットのサイズ・メンバー数が不正です')
        if 'manifest.json' not in names or archive.getinfo('manifest.json').file_size>2*1024*1024:
            raise ValueError('プリセットのマニフェストが不正です')
        manifest=json.loads(archive.read('manifest.json'))
        if manifest.get('format')!='smart_shapekey_facial_library' or type(manifest.get('version')) is not int or manifest.get('version') not in (1,2,3,4):
            raise ValueError('対応していないプリセット形式です')
        selection_only=manifest['version']==4
        if selection_only:
            declared=manifest.get('channels')
            if manifest.get('scope')!='SELECTED_PARTS' or not isinstance(declared,list) or not 1<=len(declared)<=52 or any(not isinstance(n,str) or n not in ARKIT_NAMES for n in declared) or declared!=sorted(set(declared)):
                raise ValueError('Invalid selected-part library declaration.')
        elif 'scope' in manifest or 'channels' in manifest:
            raise ValueError('Selected-part libraries require format version 4.')
        parts=manifest.get('objects')
        if not isinstance(parts,list) or not 1<=len(parts)<=64:raise ValueError('プリセットの対象数が不正です')
        payload={};expected={'manifest.json'};object_names=set();channels=set()
        for i,part in enumerate(parts):
            name=part['name'];count=part['vertex_count'];shapes=part['shapes']
            if not isinstance(name,str) or name in object_names or not isinstance(count,int) or not 1<=count<=200000:
                raise ValueError('対象名・頂点数が不正です')
            object_names.add(name);used=set()
            if not isinstance(shapes,list) or not 1<=len(shapes)<=52:raise ValueError('表情数が不正です')
            for shape in shapes:
                channel=shape['name'];member=shape['member']
                if channel not in ARKIT_NAMES or channel in used or member!=f'parts/{i:03d}/{channel}.f32':
                    raise ValueError('表情名・格納パスが不正です')
                if member not in names or archive.getinfo(member).file_size!=count*12:raise ValueError('表情座標の長さが不正です')
                data=archive.read(member)
                if digest(data)!=shape['sha256']:raise ValueError('表情座標のハッシュが一致しません')
                values=array.array('f');values.frombytes(data)
                if sys.byteorder!='little':values.byteswap()
                if any(not math.isfinite(v) for v in values):raise ValueError('非有限の表情座標があります')
                lo=shape['slider_min'];hi=shape['slider_max']
                if not all(isinstance(v,(int,float)) and math.isfinite(v) for v in (lo,hi)) or not -10<=lo<=hi<=10:
                    raise ValueError('表情スライダーの範囲が不正です')
                if shape['interpolation'] not in ('KEY_LINEAR','KEY_CARDINAL','KEY_CATMULL_ROM','KEY_BSPLINE'):
                    raise ValueError('表情の補間形式が不正です')
                payload[member]=values;used.add(channel);channels.add(channel);expected.add(member)
            if manifest['version'] in (2,3,4):
                from .corrective_library import read_correctives
                read_correctives(archive,part,i,payload,expected,names)
            elif part.get('correctives'):raise ValueError('対応していないプリセット形式です')
        if manifest['version'] in (2,3,4):
            from .corrective_library import validate_input_parts
            validate_input_parts(manifest)
        if set(names)!=expected:raise ValueError('52表情または格納メンバーが不一致です')
        if selection_only:
            if channels!=set(declared):raise ValueError('Selected-part channel declaration does not match the payload.')
        elif channels!=set(ARKIT_NAMES):raise ValueError('52表情または格納メンバーが不一致です')
    return manifest,payload

def apply_library(objects,path):
    objects=safe_objects(objects);manifest,payload=read_library(path)
    if any(part.get('correctives') for part in manifest['objects']):
        from .corrective_library import apply_correctives
        return apply_correctives(objects,manifest,payload,_apply_shapes)
    return _apply_shapes(objects,manifest,payload)

def _apply_shapes(objects,manifest,payload):
    by_name={o.name:o for o in objects}
    if set(by_name)!={p['name'] for p in manifest['objects']}:raise ValueError('プリセットと同じ名前の顔部品を全て選択してください')
    plans=[];skipped=0
    for part in manifest['objects']:
        obj=by_name[part['name']];keys=obj.data.shape_keys
        if len(obj.data.vertices)!=part['vertex_count'] or digest(coordinates(obj.data.vertices))!=part['vertices_sha256'] or topology(obj.data)!=part['topology_sha256']:
            raise ValueError('元頂点・頂点順・トポロジーが一致しません: '+obj.name)
        basis=coordinates(keys.key_blocks[0].data) if keys else coordinates(obj.data.vertices)
        if digest(basis)!=part['basis_sha256'] or (keys and not keys.use_relative):raise ValueError('Basisが一致しません: '+obj.name)
        for shape in part['shapes']:
            existing=[k for k in keys.key_blocks if canonical_name(k.name)==shape['name']] if keys else []
            if existing:
                if len(existing)!=1 or digest(coordinates(existing[0].data))!=shape['sha256']:
                    raise ValueError('異なる既存表情を保護します: '+obj.name+'/'+shape['name'])
                skipped+=1
            else:plans.append((obj,shape))
    made=[];old_active={o.name:o.active_shape_key_index for o in objects}
    try:
        for obj,shape in plans:
            if obj.data.shape_keys is None:
                basis=obj.shape_key_add(name='Basis',from_mix=False);made.append((obj,basis))
            key=obj.shape_key_add(name=shape['name'],from_mix=False);made.append((obj,key))
            key.data.foreach_set('co',payload[shape['member']]);key.slider_min=shape['slider_min'];key.slider_max=shape['slider_max']
            key.interpolation=shape['interpolation'];key.value=0
        for obj,shape in plans:
            assert digest(coordinates(obj.data.shape_keys.key_blocks[shape['name']].data))==shape['sha256']
    except Exception:
        for obj,key in reversed(made):obj.shape_key_remove(key)
        raise
    finally:
        for obj in objects:obj.active_shape_key_index=old_active[obj.name]
    return {'parts':len(objects),'channels':len({s['name'] for p in manifest['objects'] for s in p['shapes']}),'created':len(plans),'identical_existing_kept':skipped}
