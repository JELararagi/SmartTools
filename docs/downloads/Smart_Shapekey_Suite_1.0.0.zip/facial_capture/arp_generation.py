"""Existing control poses -> standard relative Keys, with replay and rollback.

Recipes are data, never Python. Initial shapes require visual refinement.
There is no new rig, driver, constraint, Action, solver or background runtime.
"""
import array,json,math,time
from pathlib import Path
import bpy
from mathutils import Vector
from .capture_csv import ARKIT_NAMES,canonical_name
from .shape_library import safe_objects,coordinates,digest,topology

REPLAY_LIMIT_METERS=.00001 # 0.01 mm, fixed; never relaxed on retry.
TOPOLOGY_MODIFIERS={'SUBSURF','MIRROR','SOLIDIFY','ARRAY'}
ATTRIBUTE_MODIFIERS={'UV_PROJECT','DATA_TRANSFER'} # Attribute evaluation does not move vertices; topology/replay gates still apply.

def read_recipe(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>1024*1024:raise ValueError('1 MiB以内のポーズレシピJSONが必要です')
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    if data.get('format')!='smart_shapekey_arp_control_recipe_draft' or data.get('version')!=1:
        raise ValueError('対応していないポーズレシピです')
    recipes=data.get('recipes')
    if not isinstance(recipes,dict) or set(recipes)!=set(ARKIT_NAMES):raise ValueError('ARKit 52表情のレシピが必要です')
    units=data.get('unit_scale',1)
    if not isinstance(units,(int,float)) or not math.isfinite(units) or units<=0:raise ValueError('レシピの単位が不正です')
    for name,operations in recipes.items():
        if not isinstance(operations,list) or not 1<=len(operations)<=64:raise ValueError('ポーズ操作数が不正です: '+name)
        for op in operations:
            if not isinstance(op,dict) or not isinstance(op.get('bone'),str) or not 1<=len(op['bone'])<=128:
                raise ValueError('制御ボーン名が不正です')
            kind=op.get('type');field={'translation':'armature_delta','local_translation':'delta','scale':'scale'}.get(kind)
            if not field:raise ValueError('対応していない制御操作です')
            vector=op.get(field)
            if not isinstance(vector,list) or len(vector)!=3 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in vector):
                raise ValueError('制御ベクトルが不正です')
            if kind=='scale':
                if any(not .05<=v<=3 for v in vector):raise ValueError('制御スケールは0.05〜3にしてください')
            elif any(abs(v)>.25 for v in vector):raise ValueError('制御移動量が範囲外です')
    return data

def _float_coords(data):
    values=array.array('f',[0])*(len(data)*3);data.foreach_get('co',values);return values

def _distance(a,b):
    return max((math.sqrt(sum((a[i+j]-b[i+j])**2 for j in range(3))) for i in range(0,len(a),3)),default=0.)

def generate(objects,rig,recipe,*,strength=1.,timeout_seconds=120.):
    objects=safe_objects(objects)
    if rig is None or rig.type!='ARMATURE' or rig.library or rig.data.library or not rig.is_editable:
        raise ValueError('編集可能なローカル表情リグを指定してください')
    if not math.isfinite(strength) or not .1<=strength<=3:raise ValueError('生成強度は0.1〜3にしてください')
    if abs(bpy.context.scene.unit_settings.scale_length-recipe.get('unit_scale',1))>1e-6:
        raise ValueError('シーンとレシピの単位スケールが一致しません')
    recipes=recipe['recipes']
    if sum(len(o.data.vertices) for o in objects)*52*12>256*1024*1024:
        raise ValueError('生成座標の見積りが256 MiBを超えます。顔部品だけを選択してください')
    bones={op['bone'] for operations in recipes.values() for op in operations}
    missing=sorted(bones-set(rig.pose.bones.keys()))
    if missing:raise ValueError('必要な制御ボーンがありません: '+', '.join(missing))
    controls={name:rig.pose.bones[name] for name in bones}
    if rig.animation_data:
        prefixes=[p.path_from_id() for p in controls.values()]
        if any(any(c.data_path.startswith(prefix+'.') for prefix in prefixes) for c in rig.animation_data.drivers):
            raise ValueError('生成対象の制御ボーンにあるドライバーを保護します')
    mod_states=[]
    old={};active={};basis_coords={};world_inverse={}
    bpy.context.view_layer.update()
    for obj in objects:
        keys=obj.data.shape_keys
        if keys and (not keys.use_relative or any(canonical_name(k.name) for k in keys.key_blocks)):
            raise ValueError('既存ARKitキーまたは絶対キーを保護します: '+obj.name)
        old[obj.name]={'vertices':digest(coordinates(obj.data.vertices)),'topology':topology(obj.data),
            'keys':{k.name:(digest(coordinates(k.data)),k.relative_key.name,k.vertex_group,k.value,k.slider_min,k.slider_max,k.interpolation,k.mute) for k in keys.key_blocks} if keys else {}}
        active[obj.name]=obj.active_shape_key_index
        basis_coords[obj.name]=_float_coords(keys.key_blocks[0].data if keys else obj.data.vertices)
        if abs(obj.matrix_world.determinant())<1e-12:raise ValueError('特異なオブジェクト行列を保護します: '+obj.name)
        world_inverse[obj.name]=obj.matrix_world.inverted()
        for modifier in obj.modifiers:
            if modifier.type in TOPOLOGY_MODIFIERS:mod_states.append((modifier,modifier.show_viewport,modifier.show_render))
            elif modifier.show_viewport and modifier.type not in ({'ARMATURE'}|ATTRIBUTE_MODIFIERS):
                raise ValueError('生成に未対応の変形モディファイアがあります: '+obj.name+'/'+modifier.name)
    transforms={name:{field:tuple(getattr(p,field)) for field in ('location','rotation_euler','rotation_quaternion','rotation_axis_angle','scale')} for name,p in controls.items()}
    pose_before={p.name:p.matrix_basis.copy() for p in rig.pose.bones}
    frame=(bpy.context.scene.frame_current,bpy.context.scene.frame_subframe)
    action_ids={a.as_pointer() for a in bpy.data.actions}
    started=time.monotonic();made=[];new_keys={};shapes={};metrics=[];committed=False

    def deadline():
        if time.monotonic()-started>timeout_seconds:raise RuntimeError('生成の時間上限です。変更を戻します')

    def restore_controls():
        for name,fields in transforms.items():
            for field,value in fields.items():setattr(controls[name],field,value)
        bpy.context.view_layer.update()

    def sample():
        deadline();bpy.context.view_layer.update();depsgraph=bpy.context.evaluated_depsgraph_get();result={}
        for obj in objects:
            evaluated=obj.evaluated_get(depsgraph);mesh=evaluated.to_mesh()
            try:
                if len(mesh.vertices)!=len(obj.data.vertices) or topology(mesh)!=old[obj.name]['topology']:
                    raise RuntimeError('評価後の頂点対応が変わりました: '+obj.name)
                transform=world_inverse[obj.name]@evaluated.matrix_world
                values=_float_coords(mesh.vertices)
                if max(abs(transform[i][j]-(1 if i==j else 0)) for i in range(4) for j in range(4))>1e-7:
                    converted=array.array('f')
                    for i in range(0,len(values),3):converted.extend(transform@Vector(values[i:i+3]))
                    values=converted
                if not all(math.isfinite(v) for v in values):raise RuntimeError('評価座標が非有限です: '+obj.name)
                result[obj.name]=values
            finally:evaluated.to_mesh_clear()
        return result

    def apply(operations):
        for op in operations:
            deadline();p=controls[op['bone']]
            if op['type']=='scale':
                value=[1+(v-1)*strength for v in op['scale']]
                if any(v<=0 for v in value):raise ValueError('生成強度でスケールが非正になりました')
                if any(locked and abs(v-original)>1e-7 for locked,v,original in zip(p.lock_scale,value,transforms[p.name]['scale'])):
                    raise ValueError('ロックされたスケールを保護します: '+p.name)
                p.scale=value
            else:
                delta=Vector(op['armature_delta'] if op['type']=='translation' else op['delta'])*strength
                if op['type']=='translation':delta=p.matrix.to_3x3().inverted()@delta
                if any(locked and abs(v)>1e-7 for locked,v in zip(p.lock_location,delta)):
                    raise ValueError('ロックされた位置を保護します: '+p.name)
                p.location+=delta
            bpy.context.view_layer.update()

    def verify_originals():
        for obj in objects:
            before=old[obj.name];keys=obj.data.shape_keys
            if digest(coordinates(obj.data.vertices))!=before['vertices'] or topology(obj.data)!=before['topology']:
                raise RuntimeError('原頂点・トポロジーの保持検査に失敗しました')
            for name,value in before['keys'].items():
                k=keys.key_blocks[name]
                now=(digest(coordinates(k.data)),k.relative_key.name,k.vertex_group,k.value,k.slider_min,k.slider_max,k.interpolation,k.mute)
                if now!=value:raise RuntimeError('既存キーの保持検査に失敗しました: '+obj.name+'/'+name)
        if {a.as_pointer() for a in bpy.data.actions}!=action_ids:raise RuntimeError('アクション一覧が変わりました')
        if (bpy.context.scene.frame_current,bpy.context.scene.frame_subframe)!=frame:raise RuntimeError('現在フレームが変わりました')
        error=max((abs(p.matrix_basis[i][j]-pose_before[p.name][i][j]) for p in rig.pose.bones for i in range(4) for j in range(4)),default=0)
        if error>1e-6:raise RuntimeError('元のポーズを復元できませんでした')
        return error

    try:
        for modifier,view,render in mod_states:modifier.show_viewport=False;modifier.show_render=False
        neutral=sample()
        for name in ARKIT_NAMES:
            restore_controls();apply(recipes[name]);posed=sample();deltas={};amplitudes={}
            for obj in objects:
                amplitude=_distance(posed[obj.name],neutral[obj.name])
                if amplitude>1e-6:
                    deltas[obj.name]=array.array('f',(a-b for a,b in zip(posed[obj.name],neutral[obj.name])))
                    amplitudes[obj.name]=amplitude*1000
            if not deltas:raise RuntimeError('非零の表情を生成できません: '+name)
            shapes[name]=deltas;metrics.append({'channel':name,'amplitude_mm':amplitudes})
        restore_controls()
        for name,deltas in shapes.items():
            new_keys[name]=[]
            for obj in objects:
                if obj.name not in deltas:continue
                if obj.data.shape_keys is None:
                    basis=obj.shape_key_add(name='Basis',from_mix=False);made.append((obj,basis))
                key=obj.shape_key_add(name=name,from_mix=False);made.append((obj,key));new_keys[name].append(key)
                if key.name!=name:raise RuntimeError('表情名が衝突しました')
                key.data.foreach_set('co',array.array('f',(a+b for a,b in zip(basis_coords[obj.name],deltas[obj.name]))));key.value=0
        max_error=0.
        for row in metrics:
            name=row['channel']
            try:
                for key in new_keys[name]:key.value=1
                replay=sample();errors={}
                for obj in objects:
                    expected=array.array('f',(a+b for a,b in zip(neutral[obj.name],shapes[name].get(obj.name,[0.]*len(neutral[obj.name])))))
                    error=_distance(replay[obj.name],expected);errors[obj.name]=error*1000;max_error=max(max_error,error)
                    if error>REPLAY_LIMIT_METERS:raise RuntimeError('標準キーの再生誤差が0.01 mmを超えました: '+name+'/'+obj.name)
                row['replay_error_mm']=errors
            finally:
                for key in new_keys[name]:key.value=0
        restore_controls();pose_error=verify_originals()
        from .shape_correction import register_initial
        register_initial(objects,new_keys)
        committed=True
        return {'channels':52,'bindings':sum(len(keys) for keys in new_keys.values()),'maximum_replay_error_mm':max_error*1000,
                'pose_restore_error':pose_error,'metrics':metrics,'elapsed_seconds':time.monotonic()-started,
                'initial_shapes_only':True,'visual_accepted':False,'full52_accepted':False}
    finally:
        for keys in new_keys.values():
            for key in keys:key.value=0
        if not committed:
            for obj,key in reversed(made):obj.shape_key_remove(key)
        restore_controls()
        for modifier,view,render in mod_states:modifier.show_viewport=view;modifier.show_render=render
        for obj in objects:obj.active_shape_key_index=active[obj.name]
