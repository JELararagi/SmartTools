"""Transactional standard Object Actions. Body and manual channels are retained."""
import hashlib,json,math,uuid
import bpy
from .capture_csv import ARKIT_NAMES,canonical_name,scene_samples
from .capture_calibration import dumps
from .bone_capture_processing import MANUAL_ONLY,edit_clip

PREFIX='smart_shapekey_facial_'

def target_rig(context,cfg):
    rig=cfg.rig or context.object
    if not rig or rig.type!='ARMATURE':raise ValueError('Select the ARKit controller armature.')
    return rig

def preflight(rig,channels,*,archive_existing=False):
    if not rig or rig.type!='ARMATURE' or rig.library or rig.data.library:
        raise ValueError('A local writable armature is required.')
    if rig.override_library or rig.data.override_library:raise ValueError('Library override rigs are protected.')
    ad=rig.animation_data
    if ad and ad.use_nla and any(not t.mute for t in ad.nla_tracks):raise ValueError('Active NLA protected.')
    if ad and ad.action:
        if ad.action.library or ad.use_tweak_mode:raise ValueError('Linked/tweak-mode body Action protected.')
        if not archive_existing:raise ValueError('Enable Keep Existing Actions before importing over a body Action.')
        if not ad.action_slot or ad.action_slot.target_id_type!='OBJECT':raise ValueError('Object Action Slot required.')
        if len(ad.action.layers)!=1 or len(ad.action.layers[0].strips)!=1:
            raise ValueError('Multi-layer body Actions are protected; use a single-layer working copy.')
    bones={};requested=set(channels)-MANUAL_ONLY
    for bone in rig.pose.bones:
        if not bone.name.lower().startswith('cc_arkit_'):continue
        channel=canonical_name(bone.name[9:])
        if channel not in requested:continue
        if channel in bones:raise ValueError('Ambiguous ARKit bone: '+channel)
        path=bone.path_from_id('location')
        if ad and any(c.data_path==path and c.array_index==1 for c in ad.drivers):
            raise ValueError('Driven controller protected: '+bone.name)
        bones[channel]=bone
    if not bones:raise ValueError('No matching cc_arkit controller bones.')
    warnings=[];eye=rig.pose.bones.get('c_eye_target.x')
    if eye is None or eye.get('eye_target')!=1.0:
        warnings.append('c_eye_target.x[eye_target] is not1.0; eye target was not changed.')
    return bones,warnings

def _bake(clip,rig,bones,old_action,old_identifier,name,start_frame,created):
    ad=rig.animation_data_create()
    action=old_action.copy() if old_action else bpy.data.actions.new(name)
    created.append(action);action.name=name;action.use_fake_user=True
    ad.action=action
    if old_action:
        ad.action_slot=next(s for s in action.slots if s.identifier==old_identifier)
        paths={b.path_from_id('location') for b in bones.values()}
        for layer in action.layers:
            for strip in layer.strips:
                bag=strip.channelbag(ad.action_slot)
                if bag:
                    for curve in list(bag.fcurves):
                        if curve.data_path in paths and curve.array_index==1:bag.fcurves.remove(curve)
    count=0;samples=0
    for frame,values in scene_samples(clip,fps=bpy.context.scene.render.fps,
                 fps_base=bpy.context.scene.render.fps_base,start_frame=start_frame):
        samples+=1
        for channel,bone in bones.items():
            bone.location[1]=values[channel]
            if abs(bone.location[1]-values[channel])>1e-6:raise ValueError('Rejected controller coefficient: '+channel)
            if not bone.keyframe_insert(data_path='location',index=1,frame=frame,group='ARKit52'):
                raise RuntimeError('Controller key insertion failed.')
            count+=1
    slot=ad.action_slot
    if not slot or slot.target_id_type!='OBJECT':raise RuntimeError('Missing Object Action Slot.')
    paths={b.path_from_id('location') for b in bones.values()}
    for layer in action.layers:
        for strip in layer.strips:
            bag=strip.channelbag(slot)
            if bag:
                for c in bag.fcurves:
                    if c.data_path in paths and c.array_index==1:
                        c.extrapolation='CONSTANT'
                        for point in c.keyframe_points:point.interpolation='LINEAR'
    return action,slot.identifier,count,samples

def create_bone_take(clip,rig,*,name,source_text,source='',source_sha256='',source_fps=60,
       start_frame=1.0,frame_offset=0.0,archive_existing=False,calibration=None,
       calibration_sha256='',smoothing_seconds=0.0,estimate_nose=True,estimate_cheek=True,
       nose_k=.6,cheek_k=.8):
    bones,warnings=preflight(rig,clip.channels,archive_existing=archive_existing)
    effective=start_frame+frame_offset
    if not all(math.isfinite(x) for x in (start_frame,frame_offset,effective,source_fps)):
        raise ValueError('Finite frame/FPS values required.')
    if source_fps<=0 or abs(effective)>1048574:raise ValueError('Frame/FPS outside supported range.')
    samples=math.ceil(clip.duration*bpy.context.scene.render.fps/bpy.context.scene.render.fps_base)+2
    if samples*len(bones)*2>250000:raise ValueError('RAW + EDIT exceeds 250,000 keys; split this take.')
    if len(source_text.encode('utf-8'))>20*1024*1024:raise ValueError('Source CSV exceeds 20 MiB.')
    ad=rig.animation_data;had_ad=ad is not None
    old_action=ad.action if ad else None;old_slot=ad.action_slot if ad else None
    old_fake=old_action.use_fake_user if old_action else False
    values=[(b,float(b.location[1])) for b in bones.values()]
    created=[];text=None;take_id=str(uuid.uuid4())
    missing=sorted(set(ARKIT_NAMES)-set(clip.channels))
    unmapped=sorted(set(clip.channels)-MANUAL_ONLY-set(bones))
    try:
        raw,raw_slot,raw_count,sample_count=_bake(clip,rig,bones,old_action,
            old_slot.identifier if old_slot else '',name+'_RAW',effective,created)
        edited,inference=edit_clip(clip,table=calibration,smoothing_seconds=smoothing_seconds,
            estimate_nose=estimate_nose,estimate_cheek=estimate_cheek,nose_k=nose_k,cheek_k=cheek_k)
        edit,edit_slot,edit_count,_=_bake(edited,rig,bones,old_action,
            old_slot.identifier if old_slot else '',name+'_EDIT',effective,created)
        text=bpy.data.texts.new('SmartShapekey_RAW_CSV_'+take_id);text.use_fake_user=True;text.write(source_text)
        digest=source_sha256 or hashlib.sha256(source_text.encode('utf-8')).hexdigest()
        cal_json=dumps(calibration) if calibration is not None else ''
        cal_sha=calibration_sha256 or (hashlib.sha256(cal_json.encode()).hexdigest() if cal_json else '')
        for role,action,identifier in (('RAW_CAPTURE',raw,raw_slot),('EDIT_CAPTURE',edit,edit_slot)):
            action[PREFIX+'owner_rig']=rig.name;action[PREFIX+'slot_identifier']=identifier
            action[PREFIX+'role']=role;action[PREFIX+'take_id']=take_id;action[PREFIX+'destination']='BONES'
            action[PREFIX+'source_text']=text.name;action[PREFIX+'source_sha256']=digest
            action[PREFIX+'missing_columns']=','.join(missing);action[PREFIX+'unmapped_channels']=','.join(unmapped)
            action[PREFIX+'ignored_columns']=','.join(clip.ignored_columns)
            action[PREFIX+'smoothing_seconds']=float(smoothing_seconds) if role=='EDIT_CAPTURE' else 0.0
            action['ark_capture']={'source':source,'frames':sample_count,
                'fps':bpy.context.scene.render.fps/bpy.context.scene.render.fps_base,
                'offset':float(frame_offset),'sha256':digest,
                'calibration_sha256':cal_sha if role=='EDIT_CAPTURE' else '',
                'estimator_k':{'noseSneer':float(nose_k),'cheekSquint':float(cheek_k)}}
            action[PREFIX+'source_fps']=float(source_fps);action[PREFIX+'start_frame']=float(start_frame)
            action[PREFIX+'inference_json']=json.dumps(inference if role=='EDIT_CAPTURE' else {},sort_keys=True)
            if role=='EDIT_CAPTURE' and cal_json:action[PREFIX+'calibration_json']=cal_json
        if old_action:old_action.use_fake_user=True
        return {'take_id':take_id,'raw':{'actions':[raw.name],'mapped_channels':sorted(bones),
                'keys_inserted':raw_count},'editable_actions':[edit.name],'source_text':text.name,
            'missing_columns':missing,'unmapped_channels':unmapped,'warnings':warnings,
            'manual_only_not_written':sorted(MANUAL_ONLY),'inference':inference,
            'edit_keys_inserted':edit_count,'start_frame':effective,'full52_verified':False}
    except Exception:
        rig.animation_data_create().action=old_action
        if old_action and old_slot:rig.animation_data.action_slot=old_slot;old_action.use_fake_user=old_fake
        for action in created:bpy.data.actions.remove(action)
        if text:bpy.data.texts.remove(text)
        if not had_ad:rig.animation_data_clear()
        raise
    finally:
        for b,value in values:b.location[1]=value

def switch_role(rig,role):
    if rig.library or rig.data.library:raise ValueError('Linked rig protected.')
    ad=rig.animation_data
    if not ad or not ad.action:raise ValueError('No active controller capture Action.')
    if ad.use_nla and any(not t.mute for t in ad.nla_tracks):raise ValueError('Active NLA protected.')
    current=ad.action;take=current.get(PREFIX+'take_id')
    if current.get(PREFIX+'owner_rig')!=rig.name or not take:raise ValueError('Controller take owner mismatch.')
    actions=[a for a in bpy.data.actions if a.get(PREFIX+'take_id')==take and
        a.get(PREFIX+'owner_rig')==rig.name and a.get(PREFIX+'role')==role]
    if len(actions)!=1:raise ValueError('RAW/EDIT pair is ambiguous.')
    action=actions[0];slots=[s for s in action.slots if s.identifier==action.get(PREFIX+'slot_identifier') and s.target_id_type=='OBJECT']
    if len(slots)!=1:raise ValueError('Object Action Slot mismatch.')
    ad.action=action;ad.action_slot=slots[0]
