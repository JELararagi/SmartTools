# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Preview a validated coefficient set across the selected face meshes."""

from .capture_csv import canonical_name
from .mix_presets import coefficient_valid
from .shape_library import safe_objects


def _editable_blocks(obj, values, clear_missing):
    keys = obj.data.shape_keys
    if not keys or not keys.use_relative:
        raise ValueError("Preview requires relative shape keys on every selected facial mesh.")
    if obj.show_only_shape_key:
        raise ValueError("Turn off Show Only Shape Key before previewing a mix.")
    drivers = set()
    animation = keys.animation_data
    if animation:
        if animation.action:
            raise ValueError("Existing shape-key Action protected during preview.")
        if animation.use_nla and any(not layer.mute for layer in animation.nla_tracks):
            raise ValueError("Active shape-key NLA protected during preview.")
        drivers = {curve.data_path for curve in animation.drivers}
    bindings = {}
    names = set()
    for block in keys.key_blocks:
        name = canonical_name(block.name)
        if not name:
            continue
        if name in names:
            raise ValueError("Ambiguous duplicate ARKit names in one mesh.")
        names.add(name)
        if not clear_missing and name not in values:
            continue
        if block.path_from_id("value") in drivers:
            raise ValueError("Driven ARKit input protected during preview.")
        if block.mute or block.relative_key != keys.reference_key:
            raise ValueError("Preview requires unmuted ARKit shapes relative to Basis.")
        value = float(values.get(name, 0))
        if not block.slider_min <= value <= block.slider_max:
            raise ValueError("An ARKit slider range does not include the preview value.")
        bindings[name] = (block, block.value, value)
    return keys, bindings


def apply(context, objects, values, *, reset_others=False):
    from ..axis_control.face_tracker import core

    if context.mode != "OBJECT":
        raise ValueError("Preview facial coefficients in Object Mode.")
    if core.TRACKER_RUNNING:
        raise ValueError("Stop live Face Tracker before previewing facial coefficients.")
    if not isinstance(values, dict) or not all(coefficient_valid(*entry) for entry in values.items()):
        raise ValueError("Preview inputs must be distinct ARKit names with finite values from zero to one.")
    if not values and not reset_others:
        raise ValueError("Choose at least one ARKit preview input.")
    owners = []
    mutations = []
    missing = set(values)
    for obj in safe_objects(objects):
        keys, bindings = _editable_blocks(obj, values, reset_others)
        owners.append(keys)
        missing.difference_update(bindings)
        mutations.extend(bindings.values())
    if missing:
        raise ValueError("Selected facial meshes do not contain all requested preview inputs.")
    if not 1 <= len(mutations) <= 5500:
        raise ValueError("Preview requires one to 5500 ARKit bindings.")

    def flush():
        for keys in owners:
            keys.update_tag()
        context.view_layer.update()

    modified = []
    try:
        for block, previous, new in mutations:
            modified.append((block, previous))
            block.value = new
            if abs(block.value - new) > 1e-6:
                raise ValueError("Blender rejected an ARKit preview value.")
        flush()
    except Exception:
        for block, previous in reversed(modified):
            block.value = previous
        flush()
        raise
    return dict(parts=len(owners), bindings=len(mutations), reset_others=bool(reset_others))
