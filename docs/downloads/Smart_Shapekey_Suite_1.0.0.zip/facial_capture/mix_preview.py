# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit synchronized coefficient preview; no animation or shape creation."""
import math
from .capture_csv import canonical_name,ARKIT_NAMES
from .shape_library import safe_objects

def apply(context,objects,values,*,reset_others=False):
    from ..axis_control.face_tracker import core
    if context.mode!='OBJECT':raise ValueError('Preview facial coefficients in Object Mode.')
    if core.TRACKER_RUNNING:raise ValueError('Stop live Face Tracker before previewing facial coefficients.')
    if not isinstance(values,dict) or any(n not in ARKIT_NAMES or isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<=v<=1 for n,v in values.items()):
        raise ValueError('Preview inputs must be distinct ARKit names with finite values from zero to one.')
    if not values and not reset_others:raise ValueError('Choose at least one ARKit preview input.')
    objects=safe_objects(objects);rows=[];owners=[];seen=set()
    for obj in objects:
        keys=obj.data.shape_keys
        if not keys or not keys.use_relative:raise ValueError('Preview requires relative shape keys on every selected facial mesh.')
        if obj.show_only_shape_key:raise ValueError('Turn off Show Only Shape Key before previewing a mix.')
        ad=keys.animation_data
        if ad and ad.action:raise ValueError('Existing shape-key Action protected during preview.')
        if ad and ad.use_nla and any(not t.mute for t in ad.nla_tracks):raise ValueError('Active shape-key NLA protected during preview.')
        driver_paths={c.data_path for c in ad.drivers} if ad else set()
        names=set()
        for block in keys.key_blocks:
            name=canonical_name(block.name)
            if not name:continue
            if name in names:raise ValueError('Ambiguous duplicate ARKit names in one mesh.')
            names.add(name)
            if name not in values and not reset_others:continue
            if block.path_from_id('value') in driver_paths:raise ValueError('Driven ARKit input protected during preview.')
            if block.mute or block.relative_key!=keys.reference_key:raise ValueError('Preview requires unmuted ARKit shapes relative to Basis.')
            value=float(values.get(name,0))
            if not block.slider_min<=value<=block.slider_max:raise ValueError('An ARKit slider range does not include the preview value.')
            rows.append((block,block.value,value));seen.add(name)
        owners.append(keys)
    if set(values)-seen:raise ValueError('Selected facial meshes do not contain all requested preview inputs.')
    if not rows or len(rows)>5500:raise ValueError('Preview requires one to 5500 ARKit bindings.')
    try:
        for block,old,value in rows:
            block.value=value
            if abs(block.value-value)>1e-6:raise ValueError('Blender rejected an ARKit preview value.')
        for keys in owners:keys.update_tag()
        context.view_layer.update()
    except Exception:
        for block,old,value in rows:block.value=old
        for keys in owners:keys.update_tag()
        context.view_layer.update()
        raise
    return {'parts':len(objects),'bindings':len(rows),'reset_others':bool(reset_others)}
