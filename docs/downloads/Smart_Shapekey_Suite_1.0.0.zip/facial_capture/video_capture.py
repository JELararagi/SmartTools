"""Finite local recording -> existing standard CSV/take path. No camera or worker."""
import csv,hashlib,io,math,time
from pathlib import Path
try:
    from .capture_csv import CaptureClip
    from .mediapipe_schema import coefficients,EXPECTED_CHANNELS
except ImportError:
    from capture_csv import CaptureClip
    from mediapipe_schema import coefficients,EXPECTED_CHANNELS

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
    return h.hexdigest().upper()

def csv_text(clip):
    text=io.StringIO(newline='');writer=csv.writer(text)
    writer.writerow(['time_seconds',*EXPECTED_CHANNELS])
    for i,seconds in enumerate(clip.times):
        writer.writerow([format(seconds,'.17g'),*[format(clip.channels[n][i],'.17g') for n in EXPECTED_CHANNELS]])
    return text.getvalue()

def convert_video(video,model,*,input_mirrored=False,timestamps='decoded',max_duration=30,budget_seconds=60):
    video=Path(video).resolve();model=Path(model).resolve()
    if not video.is_file() or video.stat().st_size>256*1024*1024 or video.suffix.lower() not in ('.mp4','.mov','.mkv','.avi','.webm'):
        raise ValueError('256 MiB以内のローカル録画ファイルを選択してください')
    if not model.is_file() or model.stat().st_size>32*1024*1024:raise ValueError('顔認識モデル欄に、別途入手した32 MiB以下のFace Landmarkerモデルを指定してください')
    if timestamps not in ('decoded','cfr') or not 0<max_duration<=30 or not 0<budget_seconds<=60:
        raise ValueError('動画処理の時間設定が不正です')
    try:
        import cv2
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions,vision
    except (ImportError,OSError) as error:
        raise ValueError('フェイストラッカーのMediaPipe/OpenCV依存を準備してください: '+str(error)) from error
    capture=None;landmarker=None;started=time.monotonic();rows=[];previous=-1;decoded=0
    previous_threads=cv2.getNumThreads();cv2.setNumThreads(1)
    report={'source_video':str(video),'source_sha256':digest(video),'model_sha256':digest(model),
            'mediapipe_version':mp.__version__,'input_mirrored':bool(input_mirrored),'timestamp_mode':timestamps,
            'supported_channels':list(EXPECTED_CHANNELS),'unsupported_channels':['tongueOut'],
            'head_transforms_included':False,'user_device_capture_accepted':False,
            'decoder_released':False,'landmarker_closed':False}
    try:
        capture=cv2.VideoCapture(str(video))
        if not capture.isOpened():raise ValueError('録画ファイルのデコーダーを開けませんでした')
        fps=float(capture.get(cv2.CAP_PROP_FPS));frames=int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if not math.isfinite(fps) or not 1<=fps<=240 or frames<2:raise ValueError('動画のfps・フレーム数が不正です')
        if frames>3600 or frames/fps>max_duration:
            raise ValueError('今回取り込める長さを超えています。録画を短いテイクに分割してください')
        options=vision.FaceLandmarkerOptions(base_options=BaseOptions(model_asset_path=str(model),delegate=BaseOptions.Delegate.CPU),
            running_mode=vision.RunningMode.VIDEO,num_faces=1,output_face_blendshapes=True,
            output_facial_transformation_matrixes=False,min_face_detection_confidence=.5,
            min_face_presence_confidence=.5,min_tracking_confidence=.5)
        landmarker=vision.FaceLandmarker.create_from_options(options)
        while True:
            if time.monotonic()-started>budget_seconds:raise RuntimeError('動画解析の60秒予算を超えました。短いテイクで再開してください')
            ok,frame=capture.read()
            if not ok:break
            if decoded>=3600:raise ValueError('デコードフレーム数が上限を超えました')
            milliseconds=decoded*1000/fps if timestamps=='cfr' else float(capture.get(cv2.CAP_PROP_POS_MSEC))
            if not math.isfinite(milliseconds) or milliseconds<0 or milliseconds/1000>max_duration:
                raise ValueError('デコード時刻が不正です')
            timestamp=round(milliseconds)
            if timestamp<=previous:raise ValueError('動画の時刻が増加していません。固定fpsの録画だけCFR指定を使用できます')
            if input_mirrored:frame=cv2.flip(frame,1)
            height,width=frame.shape[:2]
            if max(height,width)>1280:
                ratio=1280/max(height,width);frame=cv2.resize(frame,(round(width*ratio),round(height*ratio)))
            rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            result=landmarker.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB,data=rgb),timestamp)
            if len(result.face_blendshapes)!=1:raise ValueError('顔の追跡を失いました（フレーム '+str(decoded)+'）')
            rows.append((milliseconds/1000,coefficients(result.face_blendshapes[0])))
            previous=timestamp;decoded+=1
        if len(rows)<2 or decoded!=frames:raise ValueError('動画を最後まで追跡できませんでした')
        if digest(video)!=report['source_sha256']:raise RuntimeError('解析中に元動画が変わりました')
        clip=CaptureClip(tuple(row[0] for row in rows),{n:tuple(row[1][n] for row in rows) for n in EXPECTED_CHANNELS})
        report.update(decoded_frames=decoded,declared_fps=fps,duration_seconds=clip.duration,source_unchanged=True)
        return clip,report
    finally:
        try:
            if landmarker is not None:landmarker.close();report['landmarker_closed']=True
        finally:
            if capture is not None:capture.release();report['decoder_released']=True
            cv2.setNumThreads(previous_threads)
            report['elapsed_seconds']=time.monotonic()-started
