"""Prepare captured face coefficients for animation and calibration drafts."""

from bisect import bisect_left
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
from statistics import median

from . import capture_calibration as calibration
from .capture_csv import ARKIT_NAMES, CaptureClip
from .capture_processing import process

MANUAL_ONLY = frozenset({"cheekPuff", "tongueOut"})
ZERO_THRESHOLD = 4e-4
ANNOTATIONS = frozenset({
    "status", "source", "neutral_frames", "stable_frames", "span_min",
    "eye_targets", "estimators", "policy", "instants",
})
TABLE_FIELDS = frozenset({"format", "version", "channels"})


def read_bone_calibration(path):
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix not in (".csv", ".json"):
        raise ValueError("Choose a calibration CSV/JSON file within 256 KiB.")
    with source.open("rb") as stream:
        payload = stream.read(calibration.MAX_FILE_BYTES + 1)
    if len(payload) > calibration.MAX_FILE_BYTES:
        raise ValueError("Calibration exceeds 256 KiB.")
    content = payload.decode("utf-8-sig")
    if suffix == ".csv":
        return calibration.from_csv(content), sha256(payload).hexdigest(), ""
    try:
        annotated = json.loads(content, object_pairs_hook=calibration._unique_pairs)
    except (ValueError, RecursionError) as error:
        raise ValueError("Invalid calibration JSON.") from error
    if not isinstance(annotated, dict) or annotated.keys() - TABLE_FIELDS - ANNOTATIONS:
        raise ValueError("Unknown annotated calibration fields.")
    table = calibration.normalize({field: annotated.get(field) for field in TABLE_FIELDS})
    return table, sha256(payload).hexdigest(), str(annotated.get("status", ""))[:240]


def default_bone_calibration():
    return read_bone_calibration(Path(__file__).with_name("generic_calibration_v1.json"))


def _with_channels(clip, channels):
    return CaptureClip(clip.times, channels, clip.ignored_columns, clip.range_violations)


def _estimate(channels, measured, target, dependencies, gain, blend, report):
    if target not in measured:
        return
    if any(sample > ZERO_THRESHOLD for sample in measured[target]):
        report["measured_preferred"].append(target)
        return
    left, right = dependencies
    if left not in channels or right not in channels:
        report["estimator_dependencies_missing"].append(target)
        return
    channels[target] = tuple(gain * blend(x, y) for x, y in zip(channels[left], channels[right]))
    report["inferred"].append(target)


def _coincidence(left, right):
    return left * right


def edit_clip(raw, *, table=None, smoothing_seconds=0.0, estimate_nose=True,
              estimate_cheek=True, nose_k=0.6, cheek_k=0.8):
    if any(type(gain) not in (int, float) or not 0 <= gain <= 1 for gain in (nose_k, cheek_k)):
        raise ValueError("Estimator k must be between 0 and 1.")
    source = {name: samples for name, samples in raw.channels.items() if name not in MANUAL_ONLY}
    calibrated = process(_with_channels(raw, source), calibration=table)
    channels = {name: tuple(max(0, min(sample, 1)) for sample in samples)
                for name, samples in calibrated.channels.items()}
    report = dict(inferred=[], measured_preferred=[], estimator_dependencies_missing=[],
                  zero_threshold=ZERO_THRESHOLD)
    for side in ("Left", "Right"):
        squint = f"eyeSquint{side}"
        if estimate_nose:
            _estimate(channels, source, f"noseSneer{side}", (f"browDown{side}", squint),
                      nose_k, min, report)
        if estimate_cheek:
            _estimate(channels, source, f"cheekSquint{side}", (f"mouthSmile{side}", squint),
                      cheek_k, _coincidence, report)
    return process(_with_channels(raw, channels), smoothing_seconds=smoothing_seconds), report


def neutral_draft(clip, *, source="", seconds=0.5, frames=0):
    if not isfinite(seconds) or not 0 < seconds <= 5:
        raise ValueError("Neutral window must be 0 to 5 seconds.")
    if type(frames) is not int or not 0 <= frames <= 30000:
        raise ValueError("Invalid neutral frame count.")
    if not clip.times:
        raise ValueError("Empty neutral window.")
    count = min(frames, len(clip.times)) if frames else bisect_left(
        clip.times, seconds, key=lambda timestamp: timestamp - clip.times[0],
    )
    result = dict(format=calibration.FORMAT, version=1, status="DRAFT_MAX_REQUIRES_HUMAN_INPUT",
                  source=source, neutral_frames=count,
                  policy="Median neutral; fill max manually before loading.")
    result["channels"] = {
        name: dict(neutral=median(clip.channels[name][:count]), max=None, clamp=True)
        for name in ARKIT_NAMES if name in clip.channels and name not in MANUAL_ONLY
    }
    return result
