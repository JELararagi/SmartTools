"""Import-time processing of ARKit controller coefficients; no live driver."""
import hashlib,json,math,statistics
from pathlib import Path
from .capture_csv import ARKIT_NAMES,CaptureClip
from .capture_processing import process
from . import capture_calibration as calibration

MANUAL_ONLY=frozenset(('tongueOut','cheekPuff'))
ZERO_THRESHOLD=0.0004
ANNOTATIONS=frozenset(('status','source','neutral_frames','stable_frames','span_min',
    'eye_targets','estimators','policy','instants'))

def read_bone_calibration(path):
    path=Path(path)
    if path.stat().st_size>calibration.MAX_FILE_BYTES:raise ValueError('Calibration exceeds 256 KiB.')
    data=path.read_bytes();status=''
    if path.suffix.lower()=='.json':
        try:table=json.loads(data.decode('utf-8-sig'),object_pairs_hook=calibration._unique_pairs)
        except (ValueError,RecursionError) as error:raise ValueError('Invalid calibration JSON.') from error
        if not isinstance(table,dict) or set(table)-{'format','version','channels'}-ANNOTATIONS:
            raise ValueError('Unknown annotated calibration fields.')
        status=str(table.get('status',''))[:240]
        table=calibration.normalize({k:table.get(k) for k in ('format','version','channels')})
    else:table=calibration.read_table(path)
    return table,hashlib.sha256(data).hexdigest(),status

def default_bone_calibration():
    """Bundled generic v1; explicit user tables still take precedence."""
    return read_bone_calibration(Path(__file__).with_name('generic_calibration_v1.json'))


def edit_clip(raw,*,table=None,smoothing_seconds=0.0,estimate_nose=True,
              estimate_cheek=True,nose_k=.6,cheek_k=.8):
    for k in (nose_k,cheek_k):
        if type(k) not in (int,float) or not math.isfinite(k) or not 0<=k<=1:
            raise ValueError('Estimator k must be between 0 and 1.')
    selected={n:v for n,v in raw.channels.items() if n not in MANUAL_ONLY}
    clipped=CaptureClip(raw.times,selected,raw.ignored_columns,raw.range_violations)
    calibrated=process(clipped,calibration=table)
    channels={n:tuple(min(1,max(0,x)) for x in v) for n,v in calibrated.channels.items()}
    inferred=[];measured=[];dependencies_missing=[]
    for side in ('Left','Right'):
        for target,deps,k,enabled in (
            ('noseSneer'+side,('browDown'+side,'eyeSquint'+side),nose_k,estimate_nose),
            ('cheekSquint'+side,('mouthSmile'+side,'eyeSquint'+side),cheek_k,estimate_cheek)):
            # An absent column is never synthesized; measured takes always win.
            if target not in selected or not enabled:continue
            if max(selected[target])>ZERO_THRESHOLD:measured.append(target);continue
            if any(n not in channels for n in deps):dependencies_missing.append(target);continue
            a,b=(channels[n] for n in deps)
            channels[target]=tuple(min(1,k*(min(x,y) if target.startswith('nose') else x*y)) for x,y in zip(a,b))
            inferred.append(target)
    result=process(CaptureClip(raw.times,channels,raw.ignored_columns,raw.range_violations),
                   smoothing_seconds=smoothing_seconds)
    return result,{'inferred':inferred,'measured_preferred':measured,
                   'estimator_dependencies_missing':dependencies_missing,'zero_threshold':ZERO_THRESHOLD}

def neutral_draft(clip,*,source='',seconds=.5,frames=0):
    if not math.isfinite(seconds) or not 0<seconds<=5:raise ValueError('Neutral window must be 0 to 5 seconds.')
    if type(frames) is not int or frames<0 or frames>30000:raise ValueError('Invalid neutral frame count.')
    count=min(frames,len(clip.times)) if frames else sum(t-clip.times[0]<seconds for t in clip.times)
    if count<1:raise ValueError('Empty neutral window.')
    return {'format':calibration.FORMAT,'version':1,'status':'DRAFT_MAX_REQUIRES_HUMAN_INPUT',
        'source':source,'neutral_frames':count,'policy':'Median neutral; fill max manually before loading.',
        'channels':{n:{'neutral':statistics.median(clip.channels[n][:count]),'max':None,'clamp':True}
                    for n in ARKIT_NAMES if n in clip.channels and n not in MANUAL_ONLY}}
