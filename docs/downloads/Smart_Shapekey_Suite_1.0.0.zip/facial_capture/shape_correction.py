"""Correct only hash-matched Suite initial shapes; retain and restore their source."""
import hashlib,json,uuid
from pathlib import Path
import bpy
from .capture_csv import canonical_name
from .shape_library import safe_objects,coordinates,digest,topology,read_library

PROPERTY='smart_shapekey_facial_owned_shapes_json'
FORMAT='smart_shapekey_owned_initial_shapes'

def state(key):
    return {'sha256':digest(coordinates(key.data)),'slider_min':key.slider_min,'slider_max':key.slider_max,
            'interpolation':key.interpolation,'relative_key':key.relative_key.name,'vertex_group':key.vertex_group,'mute':key.mute}

def _write(key,values,settings):
    key.data.foreach_set('co',values)
    key.slider_min=settings['slider_min'];key.slider_max=settings['slider_max'];key.interpolation=settings['interpolation']

def _floats(data):
    import array,sys
    values=array.array('f');values.frombytes(data)
    if sys.byteorder!='little':values.byteswap()
    return values

def register_initial(objects,new_keys):
    plans=[]
    for obj in objects:
        keys=obj.data.shape_keys
        owned={name:state(key) for name,blocks in new_keys.items() for key in blocks if key.id_data==keys} if keys else {}
        if PROPERTY in obj:raise ValueError('既存の初期形状記録を保護します: '+obj.name)
        data={'format':FORMAT,'version':2,'state':'INITIAL','object':obj.name,
              'vertices':digest(coordinates(obj.data.vertices)),'topology':topology(obj.data),
              'basis':digest(coordinates(keys.key_blocks[0].data if keys else obj.data.vertices)),'owned':owned}
        plans.append((obj,json.dumps(data,allow_nan=False)))
    done=[]
    try:
        for obj,text in plans:obj[PROPERTY]=text;done.append(obj)
    except Exception:
        for obj in done:del obj[PROPERTY]
        raise

def _record(obj):
    keys=obj.data.shape_keys
    text=obj.get(PROPERTY)
    if not isinstance(text,str) or len(text)>256*1024:raise ValueError('このアドオンの初期生成記録が必要です: '+obj.name)
    data=json.loads(text)
    if data.get('format')!=FORMAT or data.get('version')!=2 or data.get('object')!=obj.name:
        raise ValueError('初期生成の所有記録が一致しません: '+obj.name)
    if (keys and not keys.use_relative) or digest(coordinates(obj.data.vertices))!=data['vertices'] or topology(obj.data)!=data['topology'] or digest(coordinates(keys.key_blocks[0].data if keys else obj.data.vertices))!=data['basis']:
        raise ValueError('原頂点・トポロジー・Basisが変わっています: '+obj.name)
    expected=data['owned'] if data['state']=='INITIAL' else data.get('current')
    if not isinstance(expected,dict) or (data['state']!='INITIAL' and not expected):raise ValueError('初期形状記録が不正です')
    present={k.name for k in keys.key_blocks if canonical_name(k.name)} if keys else set()
    if present!=set(expected):raise ValueError('所有外の表情追加・削除を保護します: '+obj.name)
    for name,settings in expected.items():
        key=keys.key_blocks[name]
        if canonical_name(name)!=name or state(key)!=settings:
            raise ValueError('手修正された表情を保護します: '+obj.name+'/'+name)
        if key.relative_key!=keys.key_blocks[0] or key.vertex_group:raise ValueError('Basis基準の初期形状が必要です')
    if data['state']=='CORRECTED':
        for entry in data['backups'].values():
            backup=keys.key_blocks.get(entry['name'])
            if not backup or state(backup)!=entry['state']:raise ValueError('保管した初期形状が変わっています')
    return data,text

def _references(keys,names):
    if not keys:return False # A new Key ID cannot have an existing bound animation or driver.
    paths={f'key_blocks["{n}"].value' for n in names}
    bindings=[];ad=keys.animation_data
    if ad:
        if ad.action and ad.action_slot:bindings.append((ad.action,ad.action_slot))
        bindings.extend((s.action,s.action_slot) for t in ad.nla_tracks for s in t.strips if s.action and s.action_slot)
    for action in bpy.data.actions:
        if action.get('smart_shapekey_facial_owner_key')==keys.name:
            bindings.extend((action,s) for s in action.slots if s.identifier==action.get('smart_shapekey_facial_slot_identifier'))
    for action,slot in bindings:
        for layer in action.layers:
            for strip in layer.strips:
                bag=strip.channelbag(slot)
                if bag and any(f.data_path in paths for f in bag.fcurves):return True
    for owner in list(bpy.data.objects)+list(bpy.data.shape_keys):
        ad=owner.animation_data
        if not ad:continue
        for f in ad.drivers:
            if owner==keys and f.data_path in paths:return True
            for variable in f.driver.variables:
                if any(t.id==keys and t.data_path in paths for t in variable.targets):return True
    return False

def apply_correction(objects,path):
    objects=safe_objects(objects);manifest,payload=read_library(path);by_name={o.name:o for o in objects}
    if any(part.get('correctives') for part in manifest['objects']):raise ValueError('補正キー付きプリセットは表情・補正プリセットの適用を使用してください')
    if set(by_name)!={p['name'] for p in manifest['objects']}:raise ValueError('プリセットと同じ顔部品を全て選択してください')
    h=hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):h.update(block)
    library_sha=h.hexdigest();plans=[];records={};texts={};modes=set()
    for part in manifest['objects']:
        obj=by_name[part['name']];record,text=_record(obj);records[obj.name]=record;texts[obj.name]=text;modes.add(record['state'])
        if record['vertices']!=part['vertices_sha256'] or record['topology']!=part['topology_sha256'] or record['basis']!=part['basis_sha256'] or len(obj.data.vertices)!=part['vertex_count']:
            raise ValueError('補正プリセットの頂点対応・Basisが一致しません: '+obj.name)
        names={s['name'] for s in part['shapes']}
        if not set(record['owned'])<=names:raise ValueError('初期表情が不足するプリセットです: '+obj.name)
        if record['state']=='CORRECTED':
            if record.get('library_sha256')!=library_sha:raise ValueError('初期へ戻してから別の補正を適用してください')
        elif record['state']=='INITIAL':
            for shape in part['shapes']:
                keys=obj.data.shape_keys
                if (not keys or not keys.key_blocks.get(shape['name'])) and _references(keys,[shape['name']]):
                    raise ValueError('追加する表情への既存アニメーション・ドライバーを保護します')
                plans.append((obj,shape))
        else:raise ValueError('対応していない補正状態です')
    if modes=={'CORRECTED'}:return {'changed_owned':0,'new_bindings':0,'initial_backups':0,'already_applied':True}
    if modes!={'INITIAL'}:raise ValueError('選択部品の補正状態が揃っていません')
    made=[];changed=[];active={o.name:o.active_shape_key_index for o in objects};backups={o.name:{} for o in objects};added={o.name:[] for o in objects}
    basis_created={o.name:o.data.shape_keys is None for o in objects}
    try:
        for obj,shape in plans:
            if obj.data.shape_keys is None:
                basis=obj.shape_key_add(name='Basis',from_mix=False);made.append((obj,basis))
            keys=obj.data.shape_keys;key=keys.key_blocks.get(shape['name'])
            if key:
                target={'sha256':shape['sha256'],'slider_min':shape['slider_min'],'slider_max':shape['slider_max'],'interpolation':shape['interpolation']}
                if all(state(key)[field]==value for field,value in target.items()):continue
                original=coordinates(key.data);settings=state(key);changed.append((key,original,settings))
                archive_name='SS_Initial_'+uuid.uuid4().hex[:10]+'_'+key.name
                backup=obj.shape_key_add(name=archive_name,from_mix=False);made.append((obj,backup))
                if backup.name!=archive_name:raise RuntimeError('初期形状の保管名が衝突しました')
                _write(backup,_floats(original),settings);backup.value=0;backup.mute=True
                backups[obj.name][key.name]={'name':backup.name,'state':state(backup)}
            else:
                key=obj.shape_key_add(name=shape['name'],from_mix=False);made.append((obj,key));added[obj.name].append(key.name)
                if key.name!=shape['name']:raise RuntimeError('補正表情名が衝突しました')
                key.value=0
            _write(key,payload[shape['member']],shape)
            if digest(coordinates(key.data))!=shape['sha256']:raise RuntimeError('補正した表情座標が一致しません')
        for obj in objects:
            record=records[obj.name];record.update(state='CORRECTED',library_sha256=library_sha,
                initial_record=texts[obj.name],backups=backups[obj.name],added=added[obj.name],basis_created=basis_created[obj.name],
                current={k.name:state(k) for k in obj.data.shape_keys.key_blocks if canonical_name(k.name)})
            obj[PROPERTY]=json.dumps(record,allow_nan=False)
    except Exception:
        for key,data,settings in changed:_write(key,_floats(data),settings)
        for obj,key in reversed(made):obj.shape_key_remove(key)
        for obj in objects:obj[PROPERTY]=texts[obj.name]
        raise
    finally:
        for obj in objects:obj.active_shape_key_index=active[obj.name]
    return {'changed_owned':len(changed),'new_bindings':sum(len(v) for v in added.values()),
            'initial_backups':sum(len(v) for v in backups.values()),'already_applied':False}

def restore_initial(objects):
    objects=safe_objects(objects);plans=[]
    for obj in objects:
        record,text=_record(obj)
        if record['state']!='CORRECTED':raise ValueError('補正済みの部品を全て選択してください')
        keys=obj.data.shape_keys
        for name,entry in record['backups'].items():
            backup=keys.key_blocks.get(entry['name'])
            if not backup or state(backup)!=entry['state']:raise ValueError('保管した初期形状が変わっています')
        removable=list(record['added'])+[entry['name'] for entry in record['backups'].values()]
        if record['basis_created']:removable.append(keys.key_blocks[0].name)
        if _references(keys,removable):raise ValueError('戻す対象にアニメーション・ドライバーがあります。収録前の制作コピーで戻してください')
        plans.append((obj,record))
    active={o.name:o.active_shape_key_index for o in objects};changed=[];removed=[]
    texts={obj.name:obj[PROPERTY] for obj,_ in plans}
    try:
        # Complete and verify every coordinate restore before deleting any own key.
        for obj,record in plans:
            keys=obj.data.shape_keys
            for name,entry in record['backups'].items():
                key=keys.key_blocks[name];changed.append((key,coordinates(key.data),state(key)))
                _write(key,_floats(coordinates(keys.key_blocks[entry['name']].data)),record['owned'][name])
                if state(key)!=record['owned'][name]:raise RuntimeError('復元した初期座標が一致しません')
        for obj,record in plans:
            keys=obj.data.shape_keys
            removable=list(reversed(record['added']))+[entry['name'] for entry in reversed(list(record['backups'].values()))]
            if record['basis_created']:removable.append(keys.key_blocks[0].name)
            for name in removable:
                key=keys.key_blocks[name];removed.append((obj,name,coordinates(key.data),state(key),key.value))
                obj.shape_key_remove(key)
            obj[PROPERTY]=record['initial_record']
        for obj in objects:_record(obj)
    except Exception:
        for obj,name,data,settings,value in reversed(removed):
            if obj.data.shape_keys and obj.data.shape_keys.key_blocks.get(name):continue
            key=obj.shape_key_add(name=name,from_mix=False)
            _write(key,_floats(data),settings);key.mute=settings['mute'];key.value=value
        for key,data,settings in changed:_write(key,_floats(data),settings)
        for obj in objects:obj[PROPERTY]=texts[obj.name]
        raise
    finally:
        for obj in objects:obj.active_shape_key_index=min(active[obj.name],len(obj.data.shape_keys.key_blocks)-1) if obj.data.shape_keys else 0
    return {'parts':len(objects),'initial_shapes_restored':True}
