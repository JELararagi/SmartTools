"""Bounded declarative per-channel calibration. No bpy, code evaluation or worker.
Calibration is optional and only transforms an EDIT copy, before gain/smoothing.
Version 2 (JSON only) adds optional per-row piecewise-linear knots after the linear map.
"""
import csv,io,json,math,os,uuid
from pathlib import Path
try:
    from .capture_csv import ARKIT_NAMES,CaptureClip,canonical_name
except ImportError:
    from capture_csv import ARKIT_NAMES,CaptureClip,canonical_name

FORMAT='smart_shapekey_facial_calibration'
MAX_FILE_BYTES=256*1024
MAX_STORED_BYTES=16384
MIN_SPAN=1e-6

def _number(value):
    if type(value) not in (int,float) or not math.isfinite(value) or not 0<=value<=1:
        raise ValueError('Calibration neutral/max must be finite numbers between 0 and 1.')
    return float(value)

MIN_KNOTS=2
MAX_KNOTS=4

def _knots(value,name):
    """Version 2 only: 2..4 [x,y] pairs, finite, 0..1, x strictly and y non-decreasing.
    x is the linear-calibrated value, y the mapped value. Plain data, never code."""
    if not isinstance(value,(list,tuple)) or not MIN_KNOTS<=len(value)<=MAX_KNOTS:
        raise ValueError('Calibration knots need2 to4 [x,y] pairs: '+name)
    pairs=[]
    for pair in value:
        if not isinstance(pair,(list,tuple)) or len(pair)!=2:
            raise ValueError('Calibration knot must be an [x,y] pair: '+name)
        for v in pair:
            if type(v) not in (int,float) or not math.isfinite(v):
                raise ValueError('Calibration knot x/y must be finite numbers: '+name)
            if not 0<=v<=1:raise ValueError('Calibration knot x/y must be between 0 and1: '+name)
        pairs.append([float(pair[0]),float(pair[1])])
    for (x0,y0),(x1,y1) in zip(pairs,pairs[1:]):
        if not x1>x0:raise ValueError('Calibration knot x must strictly increase: '+name)
        if y1<y0:raise ValueError('Calibration knot y must not decrease: '+name)
    return pairs

def normalize(table):
    if not isinstance(table,dict) or set(table)!={'format','version','channels'}:
        raise ValueError('Invalid calibration table schema.')
    if table['format']!=FORMAT or type(table['version']) is not int or table['version'] not in (1,2):
        raise ValueError('Unsupported calibration table version.')
    version=table['version'];allowed={'neutral','max','clamp','knots'} if version==2 else {'neutral','max','clamp'}
    rows=table['channels']
    if not isinstance(rows,dict) or not 1<=len(rows)<=52:raise ValueError('Calibration needs 1 to 52 named channels.')
    normalized={}
    for label,row in rows.items():
        if not isinstance(label,str):raise ValueError('Calibration channel names must be strings.')
        name=canonical_name(label)
        if not name or name in normalized:raise ValueError('Unknown or duplicate calibration channel: '+label)
        if not isinstance(row,dict) or not {'neutral','max'}<=set(row)<= allowed:
            raise ValueError('Invalid calibration channel fields: '+name)
        neutral=_number(row['neutral']);maximum=_number(row['max']);clamp=row.get('clamp',True)
        if maximum-neutral<MIN_SPAN:raise ValueError('Calibration max must exceed neutral by at least0.000001: '+name)
        if type(clamp) is not bool:raise ValueError('Calibration clamp must be true or false: '+name)
        normalized[name]={'neutral':neutral,'max':maximum,'clamp':clamp}
        if 'knots' in row:normalized[name]['knots']=_knots(row['knots'],name)
    return {'format':FORMAT,'version':version,'channels':{n:normalized[n] for n in ARKIT_NAMES if n in normalized}}

def _evaluate_knots(knots,x):
    # Outside [x first, x last] the end value is held (no extrapolation of an end segment).
    if x<=knots[0][0]:return knots[0][1]
    if x>=knots[-1][0]:return knots[-1][1]
    for (x0,y0),(x1,y1) in zip(knots,knots[1:]):
        if x<=x1:return y0+(y1-y0)*(x-x0)/(x1-x0)
    return knots[-1][1]

def dumps(table):
    text=json.dumps(normalize(table),ensure_ascii=False,separators=(',',':'),allow_nan=False)
    if len(text.encode('utf-8'))>MAX_STORED_BYTES:raise ValueError('Calibration table exceeds the stored-data limit.')
    return text

def _unique_pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('Duplicate calibration JSON field: '+key)
        result[key]=value
    return result

def loads(text):
    if not isinstance(text,str) or len(text.encode('utf-8'))>MAX_FILE_BYTES:raise ValueError('Calibration table exceeds 256 KiB.')
    try:table=json.loads(text,object_pairs_hook=_unique_pairs)
    except (ValueError,RecursionError) as error:raise ValueError('Invalid calibration JSON: '+str(error)) from error
    return normalize(table)

def from_csv(text):
    if not isinstance(text,str) or len(text.encode('utf-8'))>MAX_FILE_BYTES:raise ValueError('Calibration table exceeds 256 KiB.')
    reader=csv.DictReader(io.StringIO(text,newline=''))
    try:fields=reader.fieldnames
    except csv.Error as error:raise ValueError('Invalid calibration CSV: '+str(error)) from error
    if fields and {'version','knots'}&set(fields):
        raise ValueError('Calibration version 2 (knots) is JSON only; CSV supports version 1 neutral/max/clamp.')
    if not fields or len(fields)!=len(set(fields)) or not {'channel','neutral','max'}<=set(fields)<= {'channel','neutral','max','clamp'}:
        raise ValueError('Calibration CSV requires channel,neutral,max and optional clamp columns.')
    rows={}
    i=0
    while True:
        try:row=next(reader)
        except StopIteration:break
        except csv.Error as error:raise ValueError('Invalid calibration CSV: '+str(error)) from error
        if i>=52 or None in row or any(v is None for v in row.values()):raise ValueError('Invalid calibration CSV row or row limit.')
        name=canonical_name(row['channel'])
        if not name or name in rows:raise ValueError('Unknown or duplicate calibration CSV channel.')
        value=row.get('clamp','true').strip().lower()
        if value not in ('true','false','1','0'):raise ValueError('Calibration CSV clamp must be true,false,1 or 0.')
        try:neutral=float(row['neutral']);maximum=float(row['max'])
        except ValueError as error:raise ValueError('Invalid calibration CSV number.') from error
        rows[name]={'neutral':neutral,'max':maximum,'clamp':value in ('true','1')}
        i+=1
    return normalize({'format':FORMAT,'version':1,'channels':rows})

def to_csv(table):
    table=normalize(table)
    if table['version']!=1:raise ValueError('Calibration version 2 (knots) is JSON only; save it as .json.')
    out=io.StringIO(newline='');writer=csv.writer(out)
    writer.writerow(['channel','neutral','max','clamp'])
    for name,row in table['channels'].items():writer.writerow([name,format(row['neutral'],'.17g'),format(row['max'],'.17g'),'true' if row['clamp'] else 'false'])
    return out.getvalue()

def read_table(path):
    path=Path(path)
    if not path.is_file() or path.stat().st_size>MAX_FILE_BYTES or path.suffix.lower() not in ('.csv','.json'):
        raise ValueError('Choose a calibration CSV/JSON file within 256 KiB.')
    text=path.read_text(encoding='utf-8-sig')
    return from_csv(text) if path.suffix.lower()=='.csv' else loads(text)

def write_table(path,table):
    path=Path(path);suffix=path.suffix.lower()
    if suffix not in ('.csv','.json'):raise ValueError('Save calibration as .csv or .json.')
    if path.exists():raise ValueError('Protecting an existing file; choose a new calibration filename.')
    text=to_csv(table) if suffix=='.csv' else dumps(table)
    temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temporary.open('x',encoding='utf-8',newline='') as f:f.write(text)
        # Windows rename does not replace an existing target, including a race after preflight.
        temporary.rename(path)
    finally:
        if temporary.exists():temporary.unlink()
    return str(path)

def apply(clip,table):
    table=normalize(table);rows=table['channels'];channels={}
    for name,series in clip.channels.items():
        if name not in rows:channels[name]=series;continue
        row=rows[name];neutral=row['neutral'];span=row['max']-neutral;values=[]
        for value in series:
            if not math.isfinite(value):raise ValueError('Calibration source coefficient is not finite: '+name)
            mapped=(float(value)-neutral)/span
            if row['clamp']:mapped=max(0.,min(1.,mapped))
            if 'knots' in row and math.isfinite(mapped):mapped=_evaluate_knots(row['knots'],mapped)
            if not math.isfinite(mapped):raise ValueError('Calibration result is not finite: '+name)
            values.append(mapped)
        channels[name]=tuple(values)
    return CaptureClip(clip.times,channels,clip.ignored_columns,clip.range_violations)
