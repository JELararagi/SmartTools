"""Owned standard Object Actions, additive local head constraint; body Action untouched."""
import bisect, hashlib, json, math, uuid
import bpy
from mathutils import Euler, Matrix, Quaternion

TAG='smart_shapekey_head_take'
META='smart_shapekey_head_metadata'
IDENTITY_GUARD='1 if x*x+y*y+z*z>1e-14 else 0'

def _target(rig,bone_name):
    if not rig or rig.type!='ARMATURE' or rig.library or rig.data.library:
        raise ValueError('編集可能な頭リグを指定してください')
    bone=rig.pose.bones.get(bone_name)
    if not bone or any(bone.lock_rotation):raise ValueError('回転できる頭コントローラーを指定してください')
    if bone.constraints:raise ValueError('頭に既存拘束があります。二重適用を避けて先に確認してください')
    prefix=bone.path_from_id()
    if rig.animation_data and any(c.data_path.startswith(prefix+'.rotation_') for c in rig.animation_data.drivers):
        raise ValueError('頭の回転ドライバーを保護するため取り込めません')
    return bone

def mapped_samples(rows,*,fps,start_frame,units,axes,signs):
    if units not in ('RADIANS','DEGREES') or sorted(axes)!=['X','Y','Z'] or len(signs)!=3 or any(s not in (-1,1) for s in signs):
        raise ValueError('角度単位と重複しない3軸を指定してください')
    if len(rows)<2 or not math.isfinite(fps) or fps<=0 or not math.isfinite(start_frame):raise ValueError('無効な頭回転テイクです')
    if any(not math.isfinite(t) or len(v)!=3 or not all(math.isfinite(x) for x in v) for t,v in rows):raise ValueError('非有限の頭回転です')
    times=[t for t,_ in rows]
    if any(b<=a for a,b in zip(times,times[1:])):raise ValueError('時刻が増加していません')
    duration=times[-1]-times[0]
    if not math.isfinite(duration) or duration<=0 or duration>180:raise ValueError('頭回転テイクが長すぎます')
    count=math.ceil(duration*fps)
    if duration>180 or count*4>250000:raise ValueError('頭回転テイクが長すぎます')
    scale=math.pi/180 if units=='DEGREES' else 1
    if any(abs(x*scale)>100*math.pi for _,v in rows for x in v):raise ValueError('頭角度が許容範囲を超えています')
    # Each angle turns about its own chosen axis in pitch, yaw, roll order. Conjugating with a
    # signed basis cannot do this: an odd reflection flips the other two axes instead.
    source=[]
    for _,angles in rows:
        rotation=Matrix.Identity(3)
        for angle,axis,sign in zip(angles,axes,signs):rotation=Matrix.Rotation(sign*angle*scale,3,axis)@rotation
        source.append(rotation.to_quaternion())
    neutral=source[0].inverted(); quats=[]
    for q in source:
        q=neutral@q; q.normalize()
        if quats and quats[-1].dot(q)<0:q.negate()
        quats.append(q)
    quats[0]=Quaternion()
    samples=[]
    for i in range(count+1):
        seconds=min(i/fps,duration);t=times[0]+seconds
        j=min(max(bisect.bisect_right(times,t)-1,0),len(times)-2)
        q=quats[j].slerp(quats[j+1],min(max((t-times[j])/(times[j+1]-times[j]),0),1))
        q.normalize();samples.append((start_frame+seconds*fps,q))
    samples[0]=(start_frame,Quaternion())
    return samples

def _curves(obj,action):
    slot=obj.animation_data.action_slot
    if slot is None or slot.target_id_type!='OBJECT':raise RuntimeError('頭回転アクションスロットがありません')
    return [c for l in action.layers for s in l.strips for bag in [s.channelbag(slot)] if bag for c in bag.fcurves]

def create_head_take(rows,rig,bone_name,*,source_text='',name='Head',start_frame=1,units='RADIANS',axes=('X','Y','Z'),signs=(1,1,1)):
    bone=_target(rig,bone_name);scene=bpy.context.scene
    samples=mapped_samples(rows,fps=scene.render.fps/scene.render.fps_base,start_frame=start_frame,units=units,axes=axes,signs=signs)
    if samples[0][0]<-1048573 or samples[-1][0]>1048573:raise ValueError('Blenderのフレーム範囲を超えています')
    uid=uuid.uuid4().hex;obj=None;raw=None;edit=None;text=None;constraint=None;driver_path=None
    try:
        obj=bpy.data.objects.new('SS_Head_'+uid[:8],None);scene.collection.objects.link(obj)
        obj.empty_display_type='PLAIN_AXES';obj.empty_display_size=.03;obj.hide_render=True;obj.rotation_mode='QUATERNION'
        obj[TAG]=uid
        raw=bpy.data.actions.new(name+'_RAW_HEAD');raw.use_fake_user=True
        obj.animation_data_create().action=raw
        bounded=[(samples[0][0]-1,Quaternion())]+samples+[(samples[-1][0]+1,Quaternion())]
        obj.rotation_quaternion=Quaternion()
        if not obj.keyframe_insert(data_path='rotation_quaternion',frame=samples[0][0],group='Head Capture'):raise RuntimeError('頭回転キーの作成に失敗しました')
        for curve in _curves(obj,raw):
            # Bulk coordinates avoid keyframe_insert's nearby-key replacement threshold.
            curve.keyframe_points.clear();curve.keyframe_points.add(len(bounded))
            curve.keyframe_points.foreach_set('co',[v for frame,q in bounded for v in (frame,q[curve.array_index])])
            curve.extrapolation='CONSTANT'
            for point in curve.keyframe_points:point.interpolation='LINEAR'
            curve.keyframe_points[-2].interpolation='CONSTANT'
            curve.update()
        raw[TAG]=uid;raw['role']='RAW_HEAD'
        edit=raw.copy();edit.name=name+'_EDIT_HEAD';edit.use_fake_user=True;edit['role']='EDIT_HEAD'
        obj.animation_data.action=edit;obj.animation_data.action_slot=edit.slots[0]
        text=bpy.data.texts.new(name+'_Head_Source.csv');text.write(source_text);text[TAG]=uid
        constraint=bone.constraints.new('COPY_ROTATION');constraint.name='SS_Head_'+uid
        # Unparented Empty world rotation is the declared bone-local delta.
        # Object target LOCAL removed this transform in exact 5.1.2; WORLD is required.
        constraint.target=obj;constraint.owner_space='LOCAL';constraint.target_space='WORLD';constraint.mix_mode='AFTER'
        # A standard simple Driver prevents identity Copy Rotation from re-decomposing
        # existing ARP transforms and perturbing downstream facial controls.
        driver_path=constraint.path_from_id('influence');curve=rig.driver_add(driver_path)
        driver=curve.driver;driver.type='SCRIPTED';driver.expression=IDENTITY_GUARD
        for index,variable_name in enumerate(('x','y','z'),1):
            variable=driver.variables.new();variable.name=variable_name;variable.type='SINGLE_PROP'
            target=variable.targets[0];target.id=obj;target.data_path=f'rotation_quaternion[{index}]'
        if not driver.is_simple_expression:raise RuntimeError('頭回転の標準ドライバーが無効です')
        metadata={'version':1,'take_id':uid,'rig':rig.name,'bone':bone_name,'constraint':constraint.name,'raw':raw.name,'edit':edit.name,
            'driver_path':driver_path,
            'source_text':text.name,'source_sha256':hashlib.sha256(source_text.encode()).hexdigest(),'units':units,'axes':list(axes),'signs':list(signs),
            'neutral':'first_sample','euler_order':'XYZ','start_frame':samples[0][0],'end_frame':samples[-1][0],
            'restore_body_frame':samples[-1][0]+1,'fps':scene.render.fps/scene.render.fps_base}
        obj[META]=json.dumps(metadata,ensure_ascii=False,allow_nan=False)
        scene.frame_set(scene.frame_current,subframe=scene.frame_subframe)
        return {'object':obj.name,'raw':raw.name,'edit':edit.name,'samples':len(samples),'metadata':metadata}
    except Exception:
        if driver_path:rig.driver_remove(driver_path)
        if constraint:bone.constraints.remove(constraint)
        if obj:bpy.data.objects.remove(obj,do_unlink=True)
        for action in (raw,edit):
            if action:bpy.data.actions.remove(action)
        if text:bpy.data.texts.remove(text)
        raise

def owned_head(rig,bone_name):
    if not rig or rig.type!='ARMATURE':raise ValueError('頭リグを指定してください')
    bone=rig.pose.bones.get(bone_name)
    if not bone:raise ValueError('頭コントローラーがありません')
    found=[]
    for c in bone.constraints:
        obj=c.target if c.type=='COPY_ROTATION' else None
        if not obj or not obj.get(TAG) or not obj.get(META):continue
        meta=json.loads(obj[META])
        if meta['rig']!=rig.name or meta['bone']!=bone_name or meta['constraint']!=c.name or c.name!='SS_Head_'+obj[TAG]:continue
        if c.owner_space!='LOCAL' or c.target_space!='WORLD' or c.mix_mode!='AFTER' or c.mute or not all((c.use_x,c.use_y,c.use_z)) or any((c.invert_x,c.invert_y,c.invert_z)):
            raise ValueError('頭回転接続が手編集されています')
        if obj.parent or obj.rotation_mode!='QUATERNION' or any(abs(x)>1e-6 for x in obj.location) or any(abs(x-1)>1e-6 for x in obj.scale):raise ValueError('頭回転用エンプティの変換が変更されています')
        path=c.path_from_id('influence')
        drivers=[d for d in rig.animation_data.drivers if d.data_path==path] if rig.animation_data else []
        if meta.get('driver_path')!=path or len(drivers)!=1 or drivers[0].driver.expression!=IDENTITY_GUARD or len(drivers[0].driver.variables)!=3:
            raise ValueError('頭回転の加算ドライバーが変更されています')
        for variable,index in zip(drivers[0].driver.variables,(1,2,3)):
            if variable.name!=('x','y','z')[index-1] or variable.type!='SINGLE_PROP' or variable.targets[0].id!=obj or variable.targets[0].data_path!=f'rotation_quaternion[{index}]':
                raise ValueError('頭回転ドライバーの参照が変更されています')
        found.append((bone,c,obj,meta))
    if len(found)!=1:raise ValueError('接続中のこのアドオン頭回転テイクを1つ指定してください')
    return found[0]

def switch_head_role(rig,bone_name,role):
    if role not in ('RAW_HEAD','EDIT_HEAD'):raise ValueError('頭回転の役割が不正です')
    _,_,obj,meta=owned_head(rig,bone_name)
    action=bpy.data.actions.get(meta['raw' if role=='RAW_HEAD' else 'edit'])
    if not action or action.get(TAG)!=obj[TAG] or action.get('role')!=role or len(action.slots)!=1 or action.slots[0].target_id_type!='OBJECT':
        raise ValueError('所有する頭回転アクションが見つかりません')
    obj.animation_data.action=action;obj.animation_data.action_slot=action.slots[0]
    bpy.context.scene.frame_set(bpy.context.scene.frame_current,subframe=bpy.context.scene.frame_subframe)
    return obj

def disconnect_head(rig,bone_name):
    bone,constraint,obj,_=owned_head(rig,bone_name)
    rig.driver_remove(constraint.path_from_id('influence'))
    bone.constraints.remove(constraint)
    bpy.context.scene.frame_set(bpy.context.scene.frame_current,subframe=bpy.context.scene.frame_subframe)
    return obj
