# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded, transactional Action contact batches; no Blender dependencies."""
import copy
import math

MAX_FRAMES = 4096
BATCH_SIZE = 4
SCHEMA = 1


def frame_plan(values):
    frames = set()
    count = 0
    for value in values:
        count += 1
        if count > 500000:
            raise ValueError('Action key point limit exceeded.')
        value = float(value)
        if not math.isfinite(value) or not -1048574 <= value <= 1048574:
            raise ValueError('Action contains an invalid frame.')
        frames.add(value)
        if len(frames) > MAX_FRAMES:
            raise ValueError('Action has more than 4096 distinct key frames.')
    if not frames:
        raise ValueError('No assigned ARKit shape-key Action frames were found.')
    return sorted(frames)


def new_report(frames, signature, origin, reference):
    return dict(schema_version=SCHEMA, frames=frame_plan(frames),
                source_signature=signature, origin=list(origin), reference=reference,
                next_index=0, rows=[], status='PENDING',
                all_key_frames_contact_clear=False,
                between_keys_evaluated=False, normals_evaluated=False,
                visibility_evaluated=False, material_alpha_evaluated=False,
                artistic_quality_accepted=False, whole_model_accepted=False)


def validate_report(report, signature, origin):
    if report.get('schema_version') != SCHEMA:
        raise ValueError('Restart the Action contact inspection.')
    frames = report.get('frames')
    if not isinstance(frames, list) or frame_plan(frames) != frames:
        raise ValueError('The Action contact frame plan is invalid. Restart.')
    rows = report.get('rows')
    index = report.get('next_index')
    if type(index) is not int or not 0 <= index <= len(frames) or not isinstance(rows, list) or len(rows) != index:
        raise ValueError('The Action contact progress is invalid. Restart.')
    if [row.get('frame') for row in rows] != frames[:index]:
        raise ValueError('The Action contact rows do not match the frame plan. Restart.')
    if report.get('source_signature') != signature or report.get('origin') != list(origin):
        raise ValueError('Source data, Actions, selection or the starting frame changed. Restart the inspection.')
    if report.get('status') not in {'PENDING', 'COMPLETE', 'CONTACT_FOUND'}:
        raise ValueError('The Action contact status is invalid. Restart.')
    if report['status'] != 'PENDING':
        raise ValueError('This inspection has stopped. Start a new inspection.')


def compact_row(frame, result):
    surfaces = result.get('surface')
    if not isinstance(surfaces, dict) or not 1 <= len(surfaces) <= 3:
        raise ValueError('The contact diagnosis returned invalid surfaces.')
    compact = {}
    for name, values in surfaces.items():
        crossing = values.get('exact_noncoplanar_intersecting_pairs')
        coplanar = values.get('unresolved_coplanar_candidate_pairs')
        if type(crossing) is not int or type(coplanar) is not int or crossing < 0 or coplanar < 0:
            raise ValueError('The contact diagnosis returned invalid contact counts.')
        compact[name] = dict(crossings=crossing, unresolved_coplanar=coplanar)
    return dict(frame=frame, surfaces=compact,
                subdivision_evidence=copy.deepcopy(result.get('subdivision_evidence', {})),
                contact_clear=all(v['crossings'] == v['unresolved_coplanar'] == 0 for v in compact.values()))


def run_batch(report, signature, origin, set_frame, restore_frame, diagnose, verify_restored):
    """Return a new report only after every diagnosis and restoration succeeds.

    Caller commits the Text afterwards. A crossing stops this run at that frame.
    Failure leaves the caller's report and progress untouched.
    """
    validate_report(report, signature, origin)
    updated = copy.deepcopy(report)
    start = report['next_index']
    try:
        for frame in report['frames'][start:start + BATCH_SIZE]:
            set_frame(frame)
            row = compact_row(frame, diagnose())
            updated['rows'].append(row)
            updated['next_index'] += 1
            if not row['contact_clear']:
                updated['status'] = 'CONTACT_FOUND'
                break
    finally:
        restore_frame(origin)
        if not verify_restored():
            raise RuntimeError('The starting frame or source state could not be restored; progress was not saved.')
    if updated['status'] == 'PENDING' and updated['next_index'] == len(updated['frames']):
        updated['status'] = 'COMPLETE'
        updated['all_key_frames_contact_clear'] = True
    return updated
