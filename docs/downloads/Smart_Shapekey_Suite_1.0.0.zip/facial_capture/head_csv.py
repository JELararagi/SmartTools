"""Strict head-channel CSV data; units/rig basis are explicit, never inferred."""
import csv,math
from pathlib import Path
from .capture_csv import timecode_seconds

def read_head_csv(path,*,source_fps=60):
    path=Path(path)
    if path.suffix.lower()!='.csv' or not path.is_file() or path.stat().st_size>20*1024*1024:
        raise ValueError('20 MiB以内の頭回転CSVが必要です')
    source=path.read_text(encoding='utf-8-sig');rows=[]
    with path.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream)
        fields=reader.fieldnames or [];lookup={n.strip().lower():n for n in fields}
        if len(lookup)!=len(fields):raise ValueError('CSV列名が重複しています')
        names=('headpitch','headyaw','headroll')
        if not all(n in lookup for n in names):raise ValueError('HeadPitch/HeadYaw/HeadRollの3列が必要です')
        time_name=next((lookup[n] for n in ('time_seconds','seconds','timecode') if n in lookup),None)
        if not time_name:raise ValueError('SecondsまたはTimecode列が必要です')
        for i,row in enumerate(reader):
            if i>=20000:raise ValueError('頭回転CSVは2万行以内にしてください')
            seconds=timecode_seconds(row[time_name],source_fps)
            values=tuple(float(row[lookup[n]]) for n in names)
            if not all(math.isfinite(v) for v in values):raise ValueError('非有限の頭回転角があります')
            if rows and seconds<=rows[-1][0]:raise ValueError('頭回転CSVの時刻が増加していません')
            rows.append((seconds,values))
    if len(rows)<2 or rows[-1][0]-rows[0][0]>180:raise ValueError('2行以上・180秒以内の頭回転テイクが必要です')
    return rows,source
