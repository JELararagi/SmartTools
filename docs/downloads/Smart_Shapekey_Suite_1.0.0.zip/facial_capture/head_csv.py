# SPDX-License-Identifier: GPL-3.0-or-later
"""Parse an explicitly timed, three-angle head capture."""

from csv import DictReader
from io import BytesIO, TextIOWrapper
from math import isfinite
from pathlib import Path

from .capture_csv import timecode_seconds


_MAX_BYTES = 20 * 1024 * 1024
_MAX_ROWS = 20_000
_ANGLE_COLUMNS = ("headpitch", "headyaw", "headroll")


def read_head_csv(path, *, source_fps=60):
    path = Path(path)
    if path.suffix.casefold() != ".csv" or not path.is_file():
        raise ValueError("20 MiB以内の頭回転CSVが必要です")
    with path.open("rb") as stream:
        raw = stream.read(_MAX_BYTES + 1)
    if len(raw) > _MAX_BYTES:
        raise ValueError("20 MiB以内の頭回転CSVが必要です")

    rows = []
    with TextIOWrapper(BytesIO(raw), encoding="utf-8-sig", newline="") as stream:
        reader = DictReader(stream)
        fields = reader.fieldnames or []
        normalized = {field.strip().lower(): field for field in fields}
        if len(fields) != len(normalized):
            raise ValueError("CSV列名が重複しています")
        if not normalized.keys() >= set(_ANGLE_COLUMNS):
            raise ValueError("HeadPitch/HeadYaw/HeadRollの3列が必要です")
        angles = tuple(normalized[column] for column in _ANGLE_COLUMNS)
        time = next((normalized[key] for key in ("time_seconds", "seconds", "timecode")
                     if key in normalized), None)
        if time is None:
            raise ValueError("SecondsまたはTimecode列が必要です")
        for index, record in enumerate(reader):
            if index == _MAX_ROWS:
                raise ValueError("頭回転CSVは2万行以内にしてください")
            seconds = timecode_seconds(record[time], source_fps)
            rotation = tuple(float(record[column]) for column in angles)
            if not all(map(isfinite, rotation)):
                raise ValueError("非有限の頭回転角があります")
            if rows and not seconds > rows[-1][0]:
                raise ValueError("頭回転CSVの時刻が増加していません")
            rows.append((seconds, rotation))
    if len(rows) < 2 or rows[-1][0] - rows[0][0] > 180:
        raise ValueError("2行以上・180秒以内の頭回転テイクが必要です")
    with TextIOWrapper(BytesIO(raw), encoding="utf-8-sig") as stream:
        return rows, stream.read()
