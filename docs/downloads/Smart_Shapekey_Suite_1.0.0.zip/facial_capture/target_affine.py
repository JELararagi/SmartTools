"""Pure local Basis-relative delta, used only on an explicitly captured editing target."""
import math

def root_xy_delta(points,scale_x,scale_y,maximum_delta,*,tip_lift=0.,profile_lift=0.,profile_arrival=.5,thickness_scale=1.):
    for value in (scale_x,scale_y,maximum_delta,tip_lift,profile_lift,profile_arrival,thickness_scale):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            raise ValueError('Use finite numeric target parameters.')
    if not .6<=scale_x<=1 or not .6<=scale_y<=1:
        raise ValueError('Use target width and depth scales between 0.6 and 1.0.')
    if not 0<maximum_delta<=1:
        raise ValueError('Use a positive target displacement limit.')
    if not -.01<=tip_lift<=.01 or not -.01<=profile_lift<=.01 or not .05<=profile_arrival<=1:
        raise ValueError('Use lift values within 0.01 local units and arrival between 0.05 and 1.0.')
    if not .4<=thickness_scale<=1:
        raise ValueError('Use a target thickness scale between 0.4 and 1.0.')
    if not points or len(points)>100000:
        raise ValueError('Use a target Basis with at most 100000 vertices.')
    if any(len(p)!=3 or any(not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) for v in p) for p in points):
        raise ValueError('The target Basis contains invalid coordinates.')
    minimum_x=min(p[0] for p in points);maximum_x=max(p[0] for p in points)
    minimum_y=min(p[1] for p in points);root_y=max(p[1] for p in points)
    if maximum_x-minimum_x<1e-9 or root_y-minimum_y<1e-9:
        raise ValueError('The target Basis needs nonzero local width and depth.')
    center_x=(minimum_x+maximum_x)/2
    delta=[[(scale_x-1)*(p[0]-center_x),(1-scale_y)*(root_y-p[1]),0.] for p in points]
    y_mean=sum(p[1] for p in points)/len(points)
    z_mean=sum(p[2] for p in points)/len(points)
    variance=sum((p[1]-y_mean)**2 for p in points)
    spine_slope=sum((p[1]-y_mean)*(p[2]-z_mean) for p in points)/variance if variance>0 else 0.
    for point,change in zip(points,delta):
        t=(root_y-point[1])/(root_y-minimum_y)
        u=max(0.,min(1.,t/profile_arrival))
        weight=u*u*(3-2*u)
        change[2]=tip_lift*t+profile_lift*u*u*(3-2*u)+(thickness_scale-1)*(point[2]-(z_mean+spine_slope*(point[1]-y_mean)))*weight
    largest=max(math.sqrt(sum(v*v for v in d)) for d in delta)
    if largest>maximum_delta+1e-12:
        raise ValueError('The target displacement exceeds the chosen limit.')
    return dict(delta=delta,center_x=center_x,root_y=root_y,maximum_delta=largest,scale_x=scale_x,scale_y=scale_y,tip_lift=tip_lift,profile_lift=profile_lift,profile_arrival=profile_arrival,thickness_scale=thickness_scale,spine_y_mean=y_mean,spine_z_mean=z_mean,spine_slope=spine_slope)

"""Template appended to the existing Suite pure geometry module, no addon entry."""
def root_tip_thickness_delta(basis,reference,scale,maximum_delta,*,root_hold=.2,increment_limit=.0007):
    for value in (scale,maximum_delta,root_hold,increment_limit):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            raise ValueError('Use finite numeric thickness parameters.')
    if not 1<scale<=2 or not 0<=root_hold<=.8 or not 0<increment_limit<=.01 or not 0<maximum_delta<=1:
        raise ValueError('Use thickness 1 to 2, root hold 0 to 0.8 and positive displacement limits.')
    if not basis or len(basis)!=len(reference) or len(basis)>100000:
        raise ValueError('The captured thickness reference must match the Basis vertex count.')
    for points in (basis,reference):
        if any(len(p)!=3 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in p) for p in points):
            raise ValueError('The thickness geometry contains invalid coordinates.')
    root_y=max(p[1] for p in basis);minimum_y=min(p[1] for p in basis)
    if root_y-minimum_y<1e-9:
        raise ValueError('The thickness Basis needs nonzero local depth.')
    y_mean=sum(p[1] for p in reference)/len(reference);z_mean=sum(p[2] for p in reference)/len(reference)
    variance=sum((p[1]-y_mean)**2 for p in reference)
    if variance<1e-18:
        raise ValueError('The captured thickness reference needs nonzero local depth.')
    slope=sum((p[1]-y_mean)*(p[2]-z_mean) for p in reference)/variance
    delta=[];held=[];clipped=[]
    for i,(base,point) in enumerate(zip(basis,reference)):
        t=(root_y-base[1])/(root_y-minimum_y)
        u=max(0.,min(1.,(t-root_hold)/(1-root_hold)));weight=u*u*(3-2*u)
        change=(scale-1)*(point[2]-(z_mean+slope*(point[1]-y_mean)))*weight
        capped=max(-increment_limit,min(increment_limit,change))
        if t<=root_hold:held.append(i);assert capped==0
        if capped!=change:clipped.append(i)
        delta.append([0.,0.,capped])
    largest=max(abs(d[2]) for d in delta)
    if largest>maximum_delta+1e-12:
        raise ValueError('The target displacement exceeds the chosen limit.')
    return dict(delta=delta,maximum_delta=largest,center_x=(min(p[0] for p in basis)+max(p[0] for p in basis))/2,root_y=root_y,mode='THICKEN_CAPTURED_REFERENCE',thickness_scale=scale,root_hold=root_hold,increment_limit=increment_limit,root_held_indices=held,clipped_indices=clipped,spine_y_mean=y_mean,spine_z_mean=z_mean,spine_slope=slope)

def captured_tip_delta(reference,width_scale,thickness_scale,shortening,maximum_delta,*,root_hold=.45,center_retraction=0.):
    """Monotonic +Y tip compression with positive transverse scales; root held exactly."""
    for value in (width_scale,thickness_scale,shortening,maximum_delta,root_hold,center_retraction):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            raise ValueError('Use finite captured tip parameters.')
    if not 0<=center_retraction<=.01:raise ValueError('Captured tip center retraction must be between 0 and 0.01.')
    if not 1<=width_scale<=2 or not 1<=thickness_scale<=3 or not 0<=shortening<=.02 or not 0<=root_hold<=.8 or not 0<maximum_delta<=1:
        raise ValueError('Use tip width 1 to 2, thickness 1 to 3, shortening 0 to 0.02 and root hold 0 to 0.8.')
    if not reference or len(reference)>100000 or any(len(p)!=3 or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in p) for p in reference):
        raise ValueError('The captured tip reference contains invalid coordinates.')
    root_y=max(p[1] for p in reference);tip_y=min(p[1] for p in reference);length=root_y-tip_y
    if length<1e-9:raise ValueError('The captured tip needs nonzero local depth.')
    minimum_jacobian=1-1.5*(shortening+center_retraction)/((1-root_hold)*length)
    if minimum_jacobian<.1:raise ValueError('Tip shortening would fold the longitudinal profile.')
    center_x=(min(p[0] for p in reference)+max(p[0] for p in reference))/2
    y_mean=sum(p[1] for p in reference)/len(reference);z_mean=sum(p[2] for p in reference)/len(reference)
    variance=sum((p[1]-y_mean)**2 for p in reference)
    slope=sum((p[1]-y_mean)*(p[2]-z_mean) for p in reference)/variance
    half_width=(max(p[0] for p in reference)-min(p[0] for p in reference))/2
    if center_retraction and half_width<1e-9:raise ValueError('The captured tip needs nonzero local width.')
    delta=[];held=[]
    for i,p in enumerate(reference):
        t=(root_y-p[1])/length;u=max(0.,min(1.,(t-root_hold)/(1-root_hold)));w=u*u*(3-2*u)
        change=[(p[0]-center_x)*(width_scale-1)*w,shortening*w,(p[2]-(z_mean+slope*(p[1]-y_mean)))*(thickness_scale-1)*w]
        if center_retraction:
            transverse=max(0.,1-((p[0]-center_x)/half_width)**2)
            change[1]+=center_retraction*transverse*w
        if t<=root_hold:held.append(i);assert change==[0.,0.,0.]
        delta.append(change)
    largest=max(math.sqrt(sum(v*v for v in d)) for d in delta)
    if largest>maximum_delta+1e-12:raise ValueError('The target displacement exceeds the chosen limit.')
    return dict(delta=delta,maximum_delta=largest,center_x=center_x,root_y=root_y,mode='CAPTURED_TIP_PROFILE',tip_width=width_scale,tip_thickness=thickness_scale,tip_shortening=shortening,tip_root_hold=root_hold,tip_center_retraction=center_retraction,minimum_jacobian=minimum_jacobian,root_held_indices=held)
