# SPDX-License-Identifier: GPL-3.0-or-later
"""Small declarative ARKit coefficient files; no executable content."""
import json,math
from pathlib import Path
from .capture_csv import ARKIT_NAMES,canonical_name
FORMAT='smart_shapekey_facial_mix'
MAX_BYTES=65536

def validate(values):
    if not isinstance(values,dict) or not 1<=len(values)<=52:
        raise ValueError('A facial mix must contain one to 52 ARKit coefficients.')
    if any(n not in ARKIT_NAMES or isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<=v<=1 for n,v in values.items()):
        raise ValueError('Facial mix coefficients require exact ARKit names and finite values from zero to one.')
    return {n:float(v) for n,v in sorted(values.items())}

def _unique(pairs):
    result={}
    for name,value in pairs:
        if name in result:raise ValueError('Duplicate fields are not allowed in a facial mix.')
        result[name]=value
    return result

def decode(text):
    if len(text.encode('utf-8'))>MAX_BYTES:raise ValueError('Facial mix file exceeds 64 KiB.')
    try:doc=json.loads(text,object_pairs_hook=_unique)
    except (json.JSONDecodeError,RecursionError) as error:raise ValueError('Invalid facial mix JSON.') from error
    if not isinstance(doc,dict) or set(doc)!={'format','version','coefficients'} or doc['format']!=FORMAT or type(doc['version']) is not int or doc['version']!=1:
        raise ValueError('Unsupported facial mix format or version.')
    return validate(doc['coefficients'])

def read(path):
    with Path(path).open('rb') as stream:raw=stream.read(MAX_BYTES+1)
    if len(raw)>MAX_BYTES:raise ValueError('Facial mix file exceeds 64 KiB.')
    try:return decode(raw.decode('utf-8-sig'))
    except UnicodeDecodeError as error:raise ValueError('Facial mix file must use UTF-8.') from error

def save(path,values):
    values=validate(values)
    text=json.dumps({'format':FORMAT,'version':1,'coefficients':values},indent=2,ensure_ascii=False)+'\n'
    if len(text.encode('utf-8'))>MAX_BYTES:raise ValueError('Facial mix file exceeds 64 KiB.')
    path=Path(path)
    try:
        with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
    except FileExistsError as error:raise ValueError('Existing facial mix file protected; choose a new filename.') from error
    return values

def capture(objects):
    from .shape_library import safe_objects
    result={};bindings=0
    for obj in safe_objects(objects):
        keys=obj.data.shape_keys
        if not keys or not keys.use_relative:raise ValueError('Facial mix export requires relative shape keys.')
        seen=set()
        for key in keys.key_blocks:
            name=canonical_name(key.name)
            if not name:continue
            if name in seen:raise ValueError('Ambiguous duplicate ARKit names in one mesh.')
            seen.add(name);value=float(key.value);validate({name:value});bindings+=1
            if name in result and abs(result[name]-value)>1e-6:
                raise ValueError('Selected facial meshes have different values for the same ARKit input.')
            result[name]=value
    if not 1<=bindings<=5500:raise ValueError('Facial mix export requires one to 5500 ARKit bindings.')
    return validate(result)
