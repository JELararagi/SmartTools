# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read, write and capture validated facial coefficient presets."""

import json
from pathlib import Path

from .capture_csv import ARKIT_NAMES, canonical_name


FORMAT = "smart_shapekey_facial_mix"
MAX_BYTES = 64 * 1024
_MAX_BINDINGS = 5500


def coefficient_valid(name, value):
    return name in ARKIT_NAMES and type(value) in (int, float) and 0 <= value <= 1


def validate(values):
    if not isinstance(values, dict) or not 1 <= len(values) <= len(ARKIT_NAMES):
        raise ValueError("A facial mix must contain one to 52 ARKit coefficients.")
    if not all(coefficient_valid(*entry) for entry in values.items()):
        raise ValueError("Facial mix coefficients require exact ARKit names and finite values from zero to one.")
    return {key: float(values[key]) for key in sorted(values)}


def _without_duplicates(pairs):
    output = dict(pairs)
    if len(output) != len(pairs):
        raise ValueError("Duplicate fields are not allowed in a facial mix.")
    return output


def decode(text):
    if len(text.encode("utf-8")) > MAX_BYTES:
        raise ValueError("Facial mix file exceeds 64 KiB.")
    try:
        entry = json.loads(text, object_pairs_hook=_without_duplicates)
    except (json.JSONDecodeError, RecursionError) as error:
        raise ValueError("Invalid facial mix JSON.") from error
    if not isinstance(entry, dict) or entry.keys() != {"format", "version", "coefficients"}:
        raise ValueError("Unsupported facial mix format or version.")
    if entry["format"] != FORMAT or type(entry["version"]) is not int or entry["version"] != 1:
        raise ValueError("Unsupported facial mix format or version.")
    return validate(entry["coefficients"])


def read(path):
    with Path(path).open("rb") as stream:
        data = stream.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError("Facial mix file exceeds 64 KiB.")
    try:
        return decode(data.decode("utf-8-sig"))
    except UnicodeDecodeError as error:
        raise ValueError("Facial mix file must use UTF-8.") from error


def save(path, values):
    normalized = validate(values)
    payload = json.dumps(dict(format=FORMAT, version=1, coefficients=normalized), ensure_ascii=False, indent=2)
    try:
        with Path(path).open("xb") as stream:
            stream.write(payload.encode("utf-8") + b"\n")
    except FileExistsError as error:
        raise ValueError("Existing facial mix file protected; choose a new filename.") from error
    return normalized


def capture(objects):
    from .shape_library import safe_objects

    coefficients = {}
    binding_count = 0
    for obj in safe_objects(objects):
        keys = obj.data.shape_keys
        if not keys or not keys.use_relative:
            raise ValueError("Facial mix export requires relative shape keys.")
        bindings = {}
        for key in keys.key_blocks:
            name = canonical_name(key.name)
            if not name:
                continue
            if name in bindings:
                raise ValueError("Ambiguous duplicate ARKit names in one mesh.")
            value = float(key.value)
            if not coefficient_valid(name, value):
                raise ValueError("Invalid current facial coefficient.")
            bindings[name] = value
        for name, value in bindings.items():
            if name in coefficients and abs(coefficients[name] - value) > 1e-6:
                raise ValueError("Selected facial meshes have different values for the same ARKit input.")
        coefficients.update(bindings)
        binding_count += len(bindings)
    if not 1 <= binding_count <= _MAX_BINDINGS:
        raise ValueError("Facial mix export requires one to 5500 ARKit bindings.")
    return validate(coefficients)
