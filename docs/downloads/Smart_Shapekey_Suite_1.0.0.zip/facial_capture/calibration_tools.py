# SPDX-License-Identifier: GPL-3.0-or-later
"""User operations inside Facial CSV Capture.

"Build Calibration Table": count several RAW captures and write a calibration table JSON with
documented, deterministic rules (calibration_builder).  "Capture Inspection": a per-channel
table of RAW and EDIT reach, stick share, peak sample and neutral residual (capture_inspection).

Nothing here runs on its own: no timer, handler, network or camera.  Files are only read when an
operator runs and are only written to NEW file names the user chooses.
"""
import hashlib
import json
import math
from pathlib import Path

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from . import calibration_builder as builder
from . import capture_inspection as inspection
from .capture_csv import read_csv
from .capture_calibration import read_table as read_calibration_table, write_table as write_calibration_table, dumps as calibration_dumps, loads as read_calibration_text
from .bone_capture_processing import read_bone_calibration, default_bone_calibration, edit_clip
from .capture_processing import process

SCENE_PROP = 'smart_shapekey_facial_tools'
EYE_CAP_PROPS = tuple((name, 'cap_' + name) for name in builder.EYE_LOOK)


def _text(en, ja, context=None):
    from ..translation import ui_text
    return ui_text(en, ja, context)


def _message(error, context=None):
    from ..translation import exception_text
    return exception_text(error, context)


def _tools(context):
    return getattr(context.scene, SCENE_PROP)


class SMARTSHAPEKEY_PG_CalibrationTake(bpy.types.PropertyGroup):
    path: StringProperty(name='Capture CSV', default='', maxlen=1024)
    frames: IntProperty(name='Frames', default=0, min=0)
    sha256: StringProperty(name='SHA-256', default='', maxlen=64)


class SMARTSHAPEKEY_PG_InspectionRow(bpy.types.PropertyGroup):
    channel: StringProperty(name='Channel', default='', maxlen=64)
    raw_max: FloatProperty(name='RAW Maximum', default=0)
    edit_max: FloatProperty(name='EDIT Maximum', default=0)
    edit_stick: FloatProperty(name='EDIT Stick Share', default=0)
    peak_index: IntProperty(name='Peak Row', default=0)
    peak_time: FloatProperty(name='Peak Time', default=0)
    neutral_edit_max: FloatProperty(name='Neutral Residual', default=0)
    flags: StringProperty(name='Flags', default='', maxlen=64)
    has_edit: BoolProperty(name='Has EDIT', default=True)


def _pct(name, default):
    return FloatProperty(name=name, default=default, min=0, max=100, precision=1)


def _unit(name, default):
    return FloatProperty(name=name, default=default, min=0, max=1, precision=3)


class SMARTSHAPEKEY_PG_FacialTools(bpy.types.PropertyGroup):
    # Inputs
    takes: CollectionProperty(type=SMARTSHAPEKEY_PG_CalibrationTake)
    take_index: IntProperty(name='Active Capture', default=0, min=0)
    base_table: StringProperty(name='Previous Table (Optional)', subtype='FILE_PATH', default='', maxlen=1024)
    target_table: StringProperty(name='Targeted Maxima (Optional)', subtype='FILE_PATH', default='', maxlen=1024)
    # Rules (defaults = v5 rules; "v4 Rules" sets brow raise neutral to 50)
    percentile_digits: IntProperty(name='Percentile Rounding Digits', default=5, min=0, max=9)
    jaw_rule: BoolProperty(name='Rule A: jawOpen', default=True)
    jaw_knot1_x: _unit('jawOpen Knot 1 In', .1)
    jaw_knot1_y: _unit('jawOpen Knot 1 Out', .1)
    jaw_knot2_x: _unit('jawOpen Knot 2 In', .3)
    jaw_knot2_y: _unit('jawOpen Knot 2 Out', .42)
    span_small: _unit('Narrow Span Below', .12)
    target_min: _unit('Target Needed for Rule D', .15)
    span_min: _unit('Minimum Span', .25)
    eye_neutral_pct: _pct('Gaze Neutral Percentile', 75)
    eye_max_pct: _pct('Gaze Maximum Percentile', 99.5)
    cap_eyeLookDownLeft: _unit('eyeLookDownLeft Cap', 1)
    cap_eyeLookInLeft: _unit('eyeLookInLeft Cap', 1)
    cap_eyeLookOutLeft: _unit('eyeLookOutLeft Cap', 1)
    cap_eyeLookUpLeft: _unit('eyeLookUpLeft Cap', 1)
    cap_eyeLookDownRight: _unit('eyeLookDownRight Cap', 1)
    cap_eyeLookInRight: _unit('eyeLookInRight Cap', 1)
    cap_eyeLookOutRight: _unit('eyeLookOutRight Cap', 1)
    cap_eyeLookUpRight: _unit('eyeLookUpRight Cap', 1)
    visible_share: _unit('Visible Share Needed', .55)
    brow_down_neutral_pct: _pct('Brow Down Neutral Percentile', 50)
    brow_up_neutral_pct: _pct('Brow Raise Neutral Percentile', 75)
    brow_max_pct: _pct('Brow Maximum Percentile', 99)
    fallback_neutral_pct: _pct('No-Table Neutral Percentile', 50)
    fallback_max_pct: _pct('No-Table Max Percentile', 99.5)
    neutral_from_segment: BoolProperty(name='Gaze/Brow Neutral from Segment', default=False)
    segment_take: IntProperty(name='Neutral Capture (0 = All)', default=0, min=0, max=64)
    segment_start: FloatProperty(name='Neutral From (Seconds)', default=0, min=0, max=3600, precision=3)
    segment_end: FloatProperty(name='Neutral To (Seconds)', default=1, min=0, max=3600, precision=3)
    stick_line: _unit('Stick Line', .99)
    stick_limit: _unit('Stick Share Limit', .01)
    stick_widen: BoolProperty(name='Rule G: Widen Sticking Channels', default=False)
    residual_line: _unit('Neutral Residual Line', .1)
    load_after_build: BoolProperty(name='Use the New Table for Import', default=True)
    build_status: StringProperty(name='Build Result', default='', maxlen=512)
    # Inspection
    inspect_csv: StringProperty(name='Capture to Inspect', subtype='FILE_PATH', default='', maxlen=1024)
    inspect_fps: FloatProperty(name='Source Timecode FPS', default=60, min=1, max=240)
    inspect_units: EnumProperty(name='Coefficient Units', items=(('UNIT', '0 to 1', 'Standard coefficients'), ('PERCENT', '0 to 100', 'Divide percentages by one hundred')), default='UNIT')
    reach_line: _unit('Reach Line', .3)
    inspect_neutral_start: FloatProperty(name='Check Neutral From (s)', default=0, min=0, max=3600, precision=3)
    inspect_neutral_end: FloatProperty(name='Check Neutral To (s)', default=1, min=0, max=3600, precision=3)
    inspect_start_frame: FloatProperty(name='Peak Jump Start Frame', default=1, min=-1048574, max=1048574)
    rows: CollectionProperty(type=SMARTSHAPEKEY_PG_InspectionRow)
    row_index: IntProperty(name='Active Channel', default=0, min=0)
    inspect_report: StringProperty(default='', options={'HIDDEN'})
    inspect_status: StringProperty(name='Inspection Result', default='', maxlen=512)


def _rules(tools):
    return {
        'percentile_digits': tools.percentile_digits, 'jaw_rule': tools.jaw_rule,
        'jaw_knot1': (tools.jaw_knot1_x, tools.jaw_knot1_y), 'jaw_knot2': (tools.jaw_knot2_x, tools.jaw_knot2_y),
        'span_small': tools.span_small, 'target_min': tools.target_min, 'span_min': tools.span_min,
        'eye_neutral_pct': tools.eye_neutral_pct, 'eye_max_pct': tools.eye_max_pct,
        'eye_caps': {name: getattr(tools, prop) for name, prop in EYE_CAP_PROPS},
        'brow_down_neutral_pct': tools.brow_down_neutral_pct, 'brow_up_neutral_pct': tools.brow_up_neutral_pct,
        'brow_max_pct': tools.brow_max_pct, 'fallback_neutral_pct': tools.fallback_neutral_pct,
        'fallback_max_pct': tools.fallback_max_pct, 'neutral_from_segment': tools.neutral_from_segment,
        'segment_take': tools.segment_take, 'segment_start': tools.segment_start, 'segment_end': tools.segment_end,
        'stick_line': tools.stick_line, 'stick_limit': tools.stick_limit, 'stick_widen': tools.stick_widen,
        'residual_line': tools.residual_line,
    }


class SMARTSHAPEKEY_UL_calibration_takes(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        path = str(item.path or '')
        row.label(text=str(index + 1) + '. ' + (Path(path).name if path else '-'), translate=False, icon='FILE_TEXT')
        if item.frames:
            row.label(text=str(item.frames))


class SMARTSHAPEKEY_UL_capture_inspection(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=item.channel, translate=False, icon='ERROR' if item.flags else 'NONE')
        edit = (format(item.edit_max, '.2f') if item.has_edit else '-')
        row.label(text=format(item.raw_max, '.2f') + ' > ' + edit)
        row.label(text=(format(item.edit_stick * 100, '.1f') + '%') if item.has_edit else '-')
        row.label(text='#' + str(item.peak_index))
        row.label(text=format(item.neutral_edit_max, '.2f') if item.has_edit else '-')


class SMARTSHAPEKEY_OT_calibration_takes_add(bpy.types.Operator, ImportHelper):
    bl_idname = 'smart_shapekey.add_calibration_takes'
    bl_label = 'Add Captures'
    bl_description = 'Add one or more RAW ARKit capture CSV files to the list used to build a calibration table'
    bl_options = {'UNDO'}
    filename_ext = '.csv'
    filter_glob: StringProperty(default='*.csv', options={'HIDDEN'})
    files: CollectionProperty(type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        try:
            tools = _tools(context)
            paths = [Path(self.directory) / f.name for f in self.files if f.name] if self.directory and len(self.files) else [Path(self.filepath)]
            known = {str(Path(t.path)) for t in tools.takes}
            added = 0
            for path in paths:
                if path.suffix.lower() != '.csv' or not path.is_file() or path.stat().st_size > builder.MAX_CSV_BYTES:
                    raise ValueError('Choose capture CSV files within 20 MiB: ' + path.name)
                if str(path) in known:
                    continue
                if len(tools.takes) >= builder.MAX_TAKES:
                    raise ValueError('Use at most 64 captures.')
                item = tools.takes.add()
                item.path = str(path)
                item.name = path.stem
                known.add(str(path))
                added += 1
            tools.take_index = max(0, len(tools.takes) - 1)
            tools.build_status = _text('{count} captures in the list', '収録 {count} 本', context).format(count=len(tools.takes))
            self.report({'INFO'}, tools.build_status)
            return {'FINISHED'}
        except (ValueError, OSError) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


class SMARTSHAPEKEY_OT_calibration_takes_remove(bpy.types.Operator):
    bl_idname = 'smart_shapekey.remove_calibration_take'
    bl_label = 'Remove Capture'
    bl_description = 'Remove the active capture from the list (the file is not touched)'
    bl_options = {'UNDO'}
    remove_all: BoolProperty(name='Remove All', default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        tools = _tools(context)
        if self.remove_all:
            tools.takes.clear()
        elif 0 <= tools.take_index < len(tools.takes):
            tools.takes.remove(tools.take_index)
        tools.take_index = max(0, min(tools.take_index, len(tools.takes) - 1))
        tools.build_status = _text('{count} captures in the list', '収録 {count} 本', context).format(count=len(tools.takes))
        return {'FINISHED'}


def _read_takes(tools):
    takes = []
    for item in tools.takes:
        take = builder.read_take(item.path)
        item.frames = take['frames']
        item.sha256 = take['sha256']
        takes.append(take)
    return takes


class SMARTSHAPEKEY_OT_calibration_count(bpy.types.Operator):
    bl_idname = 'smart_shapekey.count_calibration_takes'
    bl_label = 'Count Distribution'
    bl_description = 'Read every listed capture and count its frames (nothing is written)'
    bl_options = {'UNDO'}

    def execute(self, context):
        tools = _tools(context)
        try:
            if not len(tools.takes):
                raise ValueError('Add at least one capture CSV.')
            takes = _read_takes(tools)
            frames = sum(t['frames'] for t in takes)
            tools.build_status = _text('Counted {takes} captures, {frames} frames', '収録 {takes} 本・{frames} コマを数えました', context).format(takes=len(takes), frames=format(frames, ','))
            self.report({'INFO'}, tools.build_status)
            return {'FINISHED'}
        except (ValueError, OSError, UnicodeError) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


class SMARTSHAPEKEY_OT_calibration_rules(bpy.types.Operator):
    bl_idname = 'smart_shapekey.apply_calibration_rules'
    bl_label = 'Rule Defaults'
    bl_description = 'Put the documented v4 or v5 rule values into the rule settings (gaze caps, files and segment are kept)'
    bl_options = {'UNDO'}
    preset: EnumProperty(name='Rules', items=(('V5', 'v5 Rules', 'v4 rules with brow raise neutral at the 75th percentile'), ('V4', 'v4 Rules', 'Rules A, C, D, E and F of calibration v4')), default='V5')

    def execute(self, context):
        tools = _tools(context)
        r = builder.PRESETS[self.preset]
        tools.percentile_digits = r['percentile_digits']
        tools.jaw_rule = r['jaw_rule']
        tools.jaw_knot1_x, tools.jaw_knot1_y = r['jaw_knot1']
        tools.jaw_knot2_x, tools.jaw_knot2_y = r['jaw_knot2']
        for key in ('span_small', 'target_min', 'span_min', 'eye_neutral_pct', 'eye_max_pct', 'brow_down_neutral_pct',
                    'brow_up_neutral_pct', 'brow_max_pct', 'fallback_neutral_pct', 'fallback_max_pct', 'stick_line',
                    'stick_limit', 'residual_line', 'stick_widen', 'neutral_from_segment'):
            setattr(tools, key, r[key])
        tools.build_status = _text('Rules set: {name}', '決め方を入れました：{name}', context).format(name='v5' if self.preset == 'V5' else 'v4')
        return {'FINISHED'}


class SMARTSHAPEKEY_OT_calibration_caps(bpy.types.Operator, ImportHelper):
    bl_idname = 'smart_shapekey.read_gaze_caps'
    bl_label = 'Read Gaze Caps from Sweep'
    bl_description = 'Set the eyeLook caps from a measured visibility sweep JSON (upper end where the visible share stays at or above the line)'
    bl_options = {'UNDO'}
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def execute(self, context):
        tools = _tools(context)
        try:
            caps = builder.caps_from_sweep(self.filepath, tools.visible_share)
            for name, prop in EYE_CAP_PROPS:
                if name in caps:
                    setattr(tools, prop, caps[name])
            tools.build_status = _text('Gaze caps read: {count}', '視線の頭打ちを読みました：{count} 本', context).format(count=len(caps))
            self.report({'INFO'}, tools.build_status)
            return {'FINISHED'}
        except (ValueError, OSError, UnicodeError) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


def load_into_import_slot(cfg, path):
    """Same effect as Load Calibration (smart_shapekey.import_facial_calibration) for one file."""
    if cfg.capture_destination == 'BONES':
        table, digest, status = read_bone_calibration(path)
    else:
        table, digest, status = read_calibration_table(path), '', ''
    encoded = calibration_dumps(table)
    previous = (cfg.calibration_table_json, cfg.calibration_label, cfg.bone_calibration_sha, cfg.bone_calibration_status)
    try:
        cfg.calibration_table_json = encoded
        cfg.calibration_label = str(len(table['channels'])) + ' / ' + Path(path).name
        cfg.bone_calibration_sha = digest
        cfg.bone_calibration_status = status
    except Exception:
        cfg.calibration_table_json, cfg.calibration_label, cfg.bone_calibration_sha, cfg.bone_calibration_status = previous
        raise


class SMARTSHAPEKEY_OT_calibration_build(bpy.types.Operator, ExportHelper):
    bl_idname = 'smart_shapekey.build_calibration_table'
    bl_label = 'Build Calibration Table'
    bl_description = 'Count the listed captures and write a new calibration table JSON (plus a _report.json) with the rule settings'
    bl_options = {'UNDO'}
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json', options={'HIDDEN'})

    def execute(self, context):
        tools = _tools(context)
        cfg = context.scene.smart_shapekey_facial_settings
        try:
            if not len(tools.takes):
                raise ValueError('Add at least one capture CSV.')
            target = Path(self.filepath).with_suffix('.json')
            report_file = builder.report_path(target)
            if target.exists() or report_file.exists():
                raise ValueError('Protecting an existing file; choose a new file name: ' + target.name)
            takes = _read_takes(tools)
            base = read_bone_calibration(bpy.path.abspath(tools.base_table))[0] if tools.base_table else None
            targets, target_kind = builder.read_targets(bpy.path.abspath(tools.target_table)) if tools.target_table else ({}, 'NONE')
            table, report = builder.build(takes, _rules(tools), base=base, targets=targets)
            report['inputs'] = {
                'previous_table': {'path': bpy.path.abspath(tools.base_table), 'sha256': builder.sha256_file(bpy.path.abspath(tools.base_table))} if tools.base_table else None,
                'targets': {'path': bpy.path.abspath(tools.target_table), 'sha256': builder.sha256_file(bpy.path.abspath(tools.target_table)), 'kind': target_kind} if tools.target_table else None,
            }
            write_calibration_table(target, table)
            report['table'] = {'path': str(target), 'sha256': builder.sha256_file(target)}
            builder.write_new(report_file, json.dumps(report, ensure_ascii=False, indent=1, allow_nan=False))
            if tools.load_after_build:
                load_into_import_slot(cfg, str(target))
            tools.build_status = _text('Table built: {rows} channels, {changed} changed, sticking {stick}, neutral residual {res}',
                                    '表を作りました：{rows} 係数・変えた {changed}・張り付き {stick}・真顔の残り {res}', context).format(
                rows=len(table['channels']), changed=len(report['changed']), stick=report['flag_counts']['STICK'], res=report['flag_counts']['NEUTRAL_RESIDUAL'])
            self.report({'INFO'}, tools.build_status)
            return {'FINISHED'}
        except (ValueError, OSError, UnicodeError) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


def _edit_for(cfg, raw):
    """The EDIT clip exactly as smart_shapekey.import_facial_csv computes it (before scene resampling)."""
    if cfg.capture_destination == 'BONES':
        if not cfg.bone_calibration_enabled:
            table, label = None, ''
        elif cfg.calibration_table_json:
            table, label = read_calibration_text(cfg.calibration_table_json), cfg.calibration_label
        else:
            table, label = default_bone_calibration()[0], 'generic_calibration_v1.json'
        edited, _ = edit_clip(raw, table=table, smoothing_seconds=cfg.smoothing, estimate_nose=cfg.estimate_nose,
                              estimate_cheek=cfg.estimate_cheek, nose_k=cfg.nose_k, cheek_k=cfg.cheek_k)
        return edited, table, label
    if cfg.calibration_enabled:
        if not cfg.calibration_table_json:
            raise ValueError('Load a calibration CSV/JSON table before enabling calibration.')
        table, label = read_calibration_text(cfg.calibration_table_json), cfg.calibration_label
    else:
        table, label = None, ''
    edited = process(raw, gains={'eyes': cfg.eyes_gain, 'mouth': cfg.mouth_gain, 'brows': cfg.brows_gain,
                                 'cheeks': cfg.cheeks_gain, 'tongue': cfg.tongue_gain},
                     smoothing_seconds=cfg.smoothing, calibration=table)
    return edited, table, label


class SMARTSHAPEKEY_OT_capture_inspect(bpy.types.Operator):
    bl_idname = 'smart_shapekey.inspect_facial_capture'
    bl_label = 'Inspect Capture'
    bl_description = 'Read the capture CSV and list, per channel, RAW and EDIT reach, stick share, peak row and neutral residual with the current import settings'
    bl_options = {'UNDO'}

    def execute(self, context):
        tools = _tools(context)
        cfg = context.scene.smart_shapekey_facial_settings
        try:
            source = tools.inspect_csv or cfg.last_capture_csv
            if not source:
                raise ValueError('Choose the capture CSV to inspect.')
            path = Path(bpy.path.abspath(source))
            if path.suffix.lower() != '.csv' or not path.is_file() or path.stat().st_size > builder.MAX_CSV_BYTES:
                raise ValueError('Choose capture CSV files within 20 MiB: ' + path.name)
            raw = read_csv(path, source_fps=tools.inspect_fps, value_scale=.01 if tools.inspect_units == 'PERCENT' else 1, range_policy='reject')
            edited, table, label = _edit_for(cfg, raw)
            report = inspection.inspect(raw, edited, stick_line=round(tools.stick_line, 6), stick_limit=round(tools.stick_limit, 6),
                                        reach_line=round(tools.reach_line, 6), residual_line=round(tools.residual_line, 6),
                                        neutral_start=round(tools.inspect_neutral_start, 6), neutral_end=round(tools.inspect_neutral_end, 6))
            report['source'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest().upper(), 'first_time': raw.times[0]}
            report['edit'] = {'destination': cfg.capture_destination, 'calibration_label': label,
                              'calibration_sha256': hashlib.sha256(calibration_dumps(table).encode()).hexdigest().upper() if table else '',
                              'smoothing_seconds': cfg.smoothing}
            tools.rows.clear()
            for row in report['channels']:
                item = tools.rows.add()
                item.name = item.channel = row['channel']
                item.raw_max = row['raw']['max']
                item.peak_index = row['raw']['peak_index']
                item.peak_time = row['raw']['peak_time']
                item.has_edit = row['edit'] is not None
                if row['edit'] is not None:
                    item.edit_max = row['edit']['max']
                    item.edit_stick = row['edit']['stick_share']
                    item.neutral_edit_max = row['neutral']['edit_max']
                item.flags = ' '.join(row['flags'])
            tools.row_index = 0
            tools.inspect_report = json.dumps(report, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            counts = report['flag_counts']
            tools.inspect_status = _text('{rows} channels: sticking {stick}, weak {weak}, neutral residual {res}',
                                      '{rows} 係数：張り付き {stick}・届かない {weak}・真顔に残る {res}', context).format(
                rows=len(report['channels']), stick=counts['STICK'], weak=counts['WEAK'], res=counts['NEUTRAL_RESIDUAL'])
            self.report({'INFO'}, tools.inspect_status)
            return {'FINISHED'}
        except (ValueError, OSError, UnicodeError) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


class SMARTSHAPEKEY_OT_capture_peak(bpy.types.Operator):
    bl_idname = 'smart_shapekey.jump_capture_peak'
    bl_label = 'Go to Peak Frame'
    bl_description = 'Move the current frame to the RAW peak of the active channel in the inspection list'
    bl_options = {'UNDO'}

    def execute(self, context):
        tools = _tools(context)
        cfg = context.scene.smart_shapekey_facial_settings
        try:
            if not tools.inspect_report or not 0 <= tools.row_index < len(tools.rows):
                raise ValueError('Inspect a capture first.')
            report = json.loads(tools.inspect_report)
            row = tools.rows[tools.row_index]
            channel = next(r for r in report['channels'] if r['channel'] == row.channel)
            start = cfg.bone_start_frame + cfg.bone_frame_offset if cfg.capture_destination == 'BONES' else tools.inspect_start_frame
            rate = context.scene.render.fps / context.scene.render.fps_base
            frame = start + (channel['raw']['peak_time'] - report['source']['first_time']) * rate
            if not math.isfinite(frame) or abs(frame) > 1048574:
                raise ValueError('The peak frame is outside the supported range.')
            context.scene.frame_set(math.floor(frame), subframe=frame % 1)
            return {'FINISHED'}
        except (ValueError, KeyError, StopIteration) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


class SMARTSHAPEKEY_OT_capture_inspection_export(bpy.types.Operator, ExportHelper):
    bl_idname = 'smart_shapekey.export_capture_inspection'
    bl_label = 'Export Inspection Table'
    bl_description = 'Write the last inspection table to a new JSON or CSV file'
    bl_options = set()
    filename_ext = '.json'
    filter_glob: StringProperty(default='*.json;*.csv', options={'HIDDEN'})
    file_format: EnumProperty(name='Table Format', items=(('JSON', 'JSON', 'Inspection JSON'), ('CSV', 'CSV', 'Inspection CSV')), default='JSON')

    def check(self, context):
        suffix = '.csv' if self.file_format == 'CSV' else '.json'
        self.filename_ext = suffix
        if self.filepath and Path(self.filepath).suffix.lower() != suffix:
            self.filepath = str(Path(self.filepath).with_suffix(suffix))
            return True
        return False

    def execute(self, context):
        tools = _tools(context)
        try:
            if not tools.inspect_report:
                raise ValueError('Inspect a capture first.')
            report = json.loads(tools.inspect_report)
            target = Path(self.filepath).with_suffix('.csv' if self.file_format == 'CSV' else '.json')
            builder.write_new(target, inspection.to_csv(report) if self.file_format == 'CSV' else inspection.to_json(report))
            self.report({'INFO'}, _text('Inspection table saved.', '点検表を保存しました。', context))
            return {'FINISHED'}
        except (ValueError, OSError, UnicodeError) as error:
            self.report({'ERROR'}, _message(error, context))
            return {'CANCELLED'}


def draw_build(layout, context):
    """Section (collapsible, "?" help at its header)."""
    from ..axis_control.face_tracker.ui import _draw_section
    from ..ui_sections import stacked_prop
    body = _draw_section(layout, context, 'face_tracker.calibration_build',
                         _text('Build Calibration Table', '校正表を作る', context), 'PRESET', 'facial_calibration_build', default=False)
    if body is None:
        return
    tools = _tools(context)
    row = body.row()
    row.template_list('SMARTSHAPEKEY_UL_calibration_takes', '', tools, 'takes', tools, 'take_index', rows=4)
    side = row.column(align=True)
    side.operator('smart_shapekey.add_calibration_takes', text='', icon='ADD')
    side.operator('smart_shapekey.remove_calibration_take', text='', icon='REMOVE').remove_all = False
    side.operator('smart_shapekey.remove_calibration_take', text='', icon='TRASH').remove_all = True
    body.operator('smart_shapekey.count_calibration_takes', icon='SEQ_HISTOGRAM')
    stacked_prop(body, tools, 'base_table')
    stacked_prop(body, tools, 'target_table')
    rules = _draw_section(body, context, 'face_tracker.calibration_rules',
                          _text('Rules (fixed values)', '決め方（決まりの値）', context), 'PREFERENCES', 'facial_calibration_rules', default=False)
    if rules is not None:
        presets = rules.row(align=True)
        presets.operator('smart_shapekey.apply_calibration_rules', text=_text('v5 Rules', 'v5 の決め方', context)).preset = 'V5'
        presets.operator('smart_shapekey.apply_calibration_rules', text=_text('v4 Rules', 'v4 の決め方', context)).preset = 'V4'
        rules.prop(tools, 'percentile_digits')
        col = rules.column(align=True)
        col.prop(tools, 'jaw_rule')
        knots = col.column(align=True)
        knots.enabled = tools.jaw_rule
        knots.prop(tools, 'jaw_knot1_x')
        knots.prop(tools, 'jaw_knot1_y')
        knots = col.column(align=True)
        knots.enabled = tools.jaw_rule
        knots.prop(tools, 'jaw_knot2_x')
        knots.prop(tools, 'jaw_knot2_y')
        col = rules.column(align=True)
        for key in ('span_small', 'target_min', 'span_min'):
            col.prop(tools, key)
        col = rules.column(align=True)
        col.prop(tools, 'eye_neutral_pct')
        col.prop(tools, 'eye_max_pct')
        caps = rules.column(align=True)
        for _name, prop in EYE_CAP_PROPS:
            caps.prop(tools, prop)
        sweep = rules.row(align=True)
        sweep.prop(tools, 'visible_share')
        sweep.operator('smart_shapekey.read_gaze_caps', text='', icon='IMPORT')
        col = rules.column(align=True)
        for key in ('brow_down_neutral_pct', 'brow_up_neutral_pct', 'brow_max_pct', 'fallback_neutral_pct', 'fallback_max_pct'):
            col.prop(tools, key)
        col = rules.column(align=True)
        col.prop(tools, 'neutral_from_segment')
        col.prop(tools, 'segment_take')
        seg = col.column(align=True)
        seg.prop(tools, 'segment_start')
        seg.prop(tools, 'segment_end')
        col = rules.column(align=True)
        col.prop(tools, 'stick_widen')
        col.prop(tools, 'stick_line')
        col.prop(tools, 'stick_limit')
        col.prop(tools, 'residual_line')
    body.prop(tools, 'load_after_build')
    body.operator('smart_shapekey.build_calibration_table', icon='EXPORT')
    if tools.build_status:
        body.label(text=tools.build_status)


def draw_inspection(layout, context):
    """Section (collapsible, "?" help at its header)."""
    from ..axis_control.face_tracker.ui import _draw_section
    from ..ui_sections import stacked_prop
    body = _draw_section(layout, context, 'face_tracker.capture_inspection',
                         _text('Capture Inspection', '取り込みの点検', context), 'VIEWZOOM', 'facial_capture_inspection', default=False)
    if body is None:
        return
    tools = _tools(context)
    cfg = context.scene.smart_shapekey_facial_settings
    stacked_prop(body, tools, 'inspect_csv')
    row = body.column(align=True)
    row.prop(tools, 'inspect_fps')
    row.prop(tools, 'inspect_units', text='')
    col = body.column(align=True)
    col.prop(tools, 'inspect_neutral_start')
    col.prop(tools, 'inspect_neutral_end')
    col = body.column(align=True)
    for key in ('reach_line', 'stick_line', 'stick_limit', 'residual_line'):
        col.prop(tools, key)
    if cfg.capture_destination != 'BONES':
        body.prop(tools, 'inspect_start_frame')
    body.operator('smart_shapekey.inspect_facial_capture', icon='VIEWZOOM')
    if tools.inspect_status:
        body.label(text=tools.inspect_status)
    head = body.row(align=True)
    for en, ja in (('Chan.', '係数'), ('Max', '最大'), ('Stick', '張付'), ('Peak', '山'), ('Rest', '真顔')):
        head.label(text=_text(en, ja, context))
    body.template_list('SMARTSHAPEKEY_UL_capture_inspection', '', tools, 'rows', tools, 'row_index', rows=6)
    body.operator('smart_shapekey.jump_capture_peak', icon='NEXT_KEYFRAME')
    actions = body.row(align=True)
    actions.operator('smart_shapekey.export_capture_inspection', text='JSON', translate=False, icon='EXPORT').file_format = 'JSON'
    actions.operator('smart_shapekey.export_capture_inspection', text='CSV', translate=False, icon='EXPORT').file_format = 'CSV'


classes = (SMARTSHAPEKEY_PG_CalibrationTake, SMARTSHAPEKEY_PG_InspectionRow, SMARTSHAPEKEY_PG_FacialTools,
           SMARTSHAPEKEY_UL_calibration_takes, SMARTSHAPEKEY_UL_capture_inspection,
           SMARTSHAPEKEY_OT_calibration_takes_add, SMARTSHAPEKEY_OT_calibration_takes_remove, SMARTSHAPEKEY_OT_calibration_count,
           SMARTSHAPEKEY_OT_calibration_rules, SMARTSHAPEKEY_OT_calibration_caps, SMARTSHAPEKEY_OT_calibration_build,
           SMARTSHAPEKEY_OT_capture_inspect, SMARTSHAPEKEY_OT_capture_peak, SMARTSHAPEKEY_OT_capture_inspection_export)


def register(ledger):
    from .. import lifecycle
    for cls in classes:
        lifecycle.register_class(ledger, cls)
    lifecycle.register_rna_property(ledger, bpy.types.Scene, SCENE_PROP, PointerProperty(type=SMARTSHAPEKEY_PG_FacialTools))
