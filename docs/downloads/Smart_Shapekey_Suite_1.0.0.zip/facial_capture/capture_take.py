"""Transaction over standard Key Actions. Keep raw, editable and previous takes.
No driver, NLA or rig manipulation. Stored source text is data, never executed.
"""
import math,uuid,hashlib,json
import bpy
try:
    from .blender_bake import bake,preflight_targets
    from .capture_processing import process
except ImportError:
    from blender_bake import bake,preflight_targets
    from capture_processing import process

def create_take(clip, objects, *, name, source_text, start_frame=1.0,
                require_all=True, archive_existing=False, gains=None, smoothing_seconds=0.0, calibration=None):
    bindings,owners=preflight_targets(objects,clip.channels,allow_new_take=archive_existing)
    missing=sorted(set(clip.channels)-set(bindings))
    if require_all and missing:raise ValueError('Unmapped channels: '+', '.join(missing))
    scene=bpy.context.scene
    frames=math.ceil(clip.duration*scene.render.fps/scene.render.fps_base)+2
    if frames*sum(len(v) for v in bindings.values())>250000:
        raise ValueError('Take exceeds 250,000 keys; split the source take before import')
    if len(source_text.encode('utf-8'))>20*1024*1024:raise ValueError('Source CSV exceeds 20 MiB')
    edited=process(clip,gains=gains,smoothing_seconds=smoothing_seconds,calibration=calibration)
    calibration_json=None
    if calibration is not None:
        try:
            from .capture_calibration import dumps
        except ImportError:
            from capture_calibration import dumps
        calibration_json=dumps(calibration)
    previous=[(keys,keys.animation_data.action if keys.animation_data else None,keys.animation_data.action_slot if keys.animation_data else None) for _,keys in owners]
    previous_values=[(block,block.value) for items in bindings.values() for _,block in items]
    created=[];text=None;take_id=str(uuid.uuid4())
    try:
        for keys,action,slot in previous:
            if keys.animation_data:keys.animation_data.action=None
        raw=bake(clip,objects,name=name+'_RAW',start_frame=start_frame,require_all=require_all)
        raw_objects=[(keys,keys.animation_data.action,keys.animation_data.action_slot.identifier) for _,keys in owners]
        created.extend(a for _,a,_ in raw_objects)
        for keys,action,identifier in raw_objects:keys.animation_data.action=None
        if calibration is None and not smoothing_seconds and all(g==1 for g in (gains or {}).values()):
            for keys,action,identifier in raw_objects:
                editable=action.copy();created.append(editable);editable.name=name+'_EDIT_'+keys.name
                editable.use_fake_user=True;keys.animation_data.action=editable
                slot=next((s for s in editable.slots if s.identifier==identifier),None)
                if slot is None:raise RuntimeError('Editable Action Slot identity lost')
                keys.animation_data.action_slot=slot
            edit_actions=[k.animation_data.action for _,k in owners]
            edit_info={'copied_from_raw':True}
        else:
            edit_info=bake(edited,objects,name=name+'_EDIT',start_frame=start_frame,require_all=require_all)
            edit_actions=[k.animation_data.action for _,k in owners];created.extend(edit_actions)
        text=bpy.data.texts.new('SmartShapekey_RAW_CSV_'+take_id);text.use_fake_user=True;text.write(source_text)
        source_sha=hashlib.sha256(source_text.encode('utf-8')).hexdigest()
        action_owners={action.as_pointer():(keys.name,identifier) for keys,action,identifier in raw_objects}
        action_owners.update({keys.animation_data.action.as_pointer():(keys.name,keys.animation_data.action_slot.identifier) for _,keys in owners})
        for role,actions in (('RAW_CAPTURE',[a for _,a,_ in raw_objects]),('EDIT_CAPTURE',edit_actions)):
            for action in actions:
                owner,identifier=action_owners[action.as_pointer()]
                action['smart_shapekey_facial_owner_key']=owner
                action['smart_shapekey_facial_slot_identifier']=identifier
                action['smart_shapekey_facial_role']=role;action['smart_shapekey_facial_take_id']=take_id
                action['smart_shapekey_facial_source_text']=text.name;action['smart_shapekey_facial_source_sha256']=source_sha
                action['smart_shapekey_facial_source_samples']=len(clip.times);action['smart_shapekey_facial_start_frame']=start_frame
                action['smart_shapekey_facial_timecode_start_seconds']=clip.times[0]
                action['smart_shapekey_facial_unmapped_channels']=','.join(missing)
                action['smart_shapekey_facial_range_violations_count']=len(clip.range_violations)
                action['smart_shapekey_facial_smoothing_seconds']=float(smoothing_seconds) if role=='EDIT_CAPTURE' else 0.0
                action['smart_shapekey_facial_region_gains_json']=json.dumps(gains or {},sort_keys=True) if role=='EDIT_CAPTURE' else '{}'
                if role=='EDIT_CAPTURE' and calibration_json is not None:
                    action['smart_shapekey_facial_calibration_json']=calibration_json
                    action['smart_shapekey_facial_calibration_sha256']=hashlib.sha256(calibration_json.encode('utf-8')).hexdigest()
        for keys,action,slot in previous:
            if action:action.use_fake_user=True
        return {'take_id':take_id,'raw':raw,'editable_actions':[a.name for a in edit_actions],
                'editing':edit_info,'source_text':text.name,'unmapped_channels':missing,
                'previous_actions_retained':[a.name for _,a,_ in previous if a],
                'range_violations_count':len(clip.range_violations),'full52_verified':False}
    except Exception:
        for keys,action,slot in previous:
            keys.animation_data_create().action=action
            if action and slot:keys.animation_data.action_slot=slot
        for action in created:
            if bpy.data.actions.get(action.name)==action:bpy.data.actions.remove(action)
        if text:bpy.data.texts.remove(text)
        for block,value in previous_values:block.value=value
        raise
