"""Blender 5.1 standard Key Actions. No sockets, handlers, or FCurve.update."""
import math
import bpy
try:
    from .capture_csv import canonical_name, scene_samples
except ImportError:
    from capture_csv import canonical_name, scene_samples


def preflight_targets(objects, channels, *, allow_new_take=False):
    bindings = {}
    used_keys = {}
    for obj in objects:
        if obj.type != 'MESH' or not obj.data.shape_keys:
            continue
        keys = obj.data.shape_keys
        driver_paths = {f.data_path for f in keys.animation_data.drivers} if keys.animation_data else set()
        for block in keys.key_blocks:
            name = canonical_name(block.name)
            if name in channels:
                if keys.animation_data:
                    if keys.animation_data.action and not allow_new_take:
                        raise ValueError('Existing shape-key Action protected: '+obj.name)
                    if keys.animation_data.use_nla and any(not t.mute for t in keys.animation_data.nla_tracks):
                        raise ValueError('Active NLA protected: '+obj.name)
                path = block.path_from_id('value')
                if path in driver_paths:
                    raise ValueError('Driven target protected: '+obj.name+' / '+block.name)
                bindings.setdefault(name, []).append((obj, block))
                used_keys[keys.as_pointer()] = (obj, keys)
    if not bindings:
        raise ValueError('No matching driver-free ARKit target shapes')
    return bindings, list(used_keys.values())


def bake(clip, objects, *, name='SmartShapekey_Facial_Capture', start_frame=1.0, require_all=True):
    scene = bpy.context.scene
    bindings, owners = preflight_targets(objects, clip.channels)
    missing = sorted(set(clip.channels) - set(bindings))
    if require_all and missing:
        raise ValueError('Unmapped channels: '+', '.join(missing))
    old_values = [(block, block.value) for items in bindings.values() for _,block in items]
    actions = []
    try:
        for obj,keys in owners:
            ad=keys.animation_data_create()
            action=bpy.data.actions.new(name+'_'+obj.name)
            action.use_fake_user=True
            ad.action=action
            actions.append((keys, action))
        count=0
        for frame,values in scene_samples(clip,fps=scene.render.fps,fps_base=scene.render.fps_base,start_frame=start_frame):
            for channel,items in bindings.items():
                for obj,block in items:
                    block.value=values[channel]
                    if abs(block.value-values[channel])>1e-6:
                        raise ValueError('Blender rejected raw coefficient: '+channel+' = '+str(values[channel]))
                    if not block.keyframe_insert(data_path='value',frame=frame,group='ARKit Face'):
                        raise RuntimeError('Key insertion failed')
                    count+=1
        for keys,action in actions:
            slot=keys.animation_data.action_slot
            if slot is None:
                raise RuntimeError('Missing Key Action Slot')
            for layer in action.layers:
                for strip in layer.strips:
                    bag=strip.channelbag(slot)
                    if bag:
                        for curve in bag.fcurves:
                            curve.extrapolation='CONSTANT'
                            for key in curve.keyframe_points:
                                key.interpolation='LINEAR'
        return {'actions':[a.name for _,a in actions], 'slots':[k.animation_data.action_slot.identifier for k,_ in actions],
                'keys_inserted':count, 'mapped_channels':sorted(bindings), 'unmapped_channels':missing,
                'duration_seconds':clip.duration, 'source_samples':len(clip.times),
                'target_fps':scene.render.fps/scene.render.fps_base}
    except Exception:
        for keys,action in actions:
            keys.animation_data.action=None
            bpy.data.actions.remove(action)
        raise
    finally:
        for block,value in old_values:
            block.value=value
