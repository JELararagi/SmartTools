# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Write a face capture clip into Blender's native slotted Key Actions."""

from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass

import bpy

try:
    from .capture_csv import canonical_name, scene_samples
except ImportError:
    from capture_csv import canonical_name, scene_samples


def preflight_targets(objects, channels, *, allow_new_take=False):
    """Find eligible shape keys and refuse to override existing animation."""
    channel_names = set(channels)
    matches = defaultdict(list)
    owners = {}
    for obj in objects:
        if obj.type != "MESH" or (keys := obj.data.shape_keys) is None:
            continue
        selected = [(canonical_name(block.name), block) for block in keys.key_blocks]
        selected = [(name, block) for name, block in selected if name in channel_names]
        if not selected:
            continue
        animation = keys.animation_data
        if animation is not None:
            if animation.action and not allow_new_take:
                raise ValueError(f"Existing shape-key Action protected: {obj.name}")
            if animation.use_nla and any(not track.mute for track in animation.nla_tracks):
                raise ValueError(f"Active NLA protected: {obj.name}")
            driven_paths = {curve.data_path for curve in animation.drivers}
            for _, block in selected:
                if block.path_from_id("value") in driven_paths:
                    raise ValueError(f"Driven target protected: {obj.name} / {block.name}")
        owners[keys.as_pointer()] = obj, keys
        for name, block in selected:
            matches[name].append((obj, block))
    if not matches:
        raise ValueError("No matching driver-free ARKit target shapes")
    return dict(matches), list(owners.values())


@dataclass
class _PendingAction:
    keys: object
    action: object
    had_animation_data: bool


@contextmanager
def _take_transaction(owners, matches, name):
    values = [(block, block.value) for entries in matches.values() for _, block in entries]
    pending = []
    try:
        for obj, keys in owners:
            record = _PendingAction(keys, bpy.data.actions.new(f"{name}_{obj.name}"),
                                    keys.animation_data is not None)
            pending.append(record)
            record.action.use_fake_user = True
            keys.animation_data_create().action = record.action
        yield pending
    except BaseException:
        for record in reversed(pending):
            keys = record.keys
            if keys.animation_data is not None and keys.animation_data.action == record.action:
                keys.animation_data.action = None
            if not record.had_animation_data and keys.animation_data is not None:
                keys.animation_data_clear()
            bpy.data.actions.remove(record.action)
        raise
    finally:
        for block, value in values:
            block.value = value


def _finalize(record):
    action = record.action
    slot = record.keys.animation_data.action_slot
    if slot is None:
        raise RuntimeError("Missing Key Action Slot")
    for layer in action.layers:
        for strip in layer.strips:
            channelbag = strip.channelbag(slot)
            if channelbag is not None:
                for curve in channelbag.fcurves:
                    curve.extrapolation = "CONSTANT"
                    for point in curve.keyframe_points:
                        point.interpolation = "LINEAR"
    return slot.identifier


def bake(clip, objects, *, name="SmartShapekey_Facial_Capture", start_frame=1.0, require_all=True):
    render = bpy.context.scene.render
    matches, owners = preflight_targets(objects, clip.channels)
    missing = sorted(set(clip.channels).difference(matches))
    if missing and require_all:
        raise ValueError("Unmapped channels: " + ", ".join(missing))

    inserted = 0
    with _take_transaction(owners, matches, name) as pending:
        for frame, values in scene_samples(clip, fps=render.fps, fps_base=render.fps_base,
                                            start_frame=start_frame):
            for channel, targets in matches.items():
                coefficient = values[channel]
                for _, block in targets:
                    block.value = coefficient
                    if abs(block.value - coefficient) > 1e-6:
                        raise ValueError(f"Blender rejected raw coefficient: {channel} = {coefficient}")
                    if not block.keyframe_insert(data_path="value", frame=frame, group="ARKit Face"):
                        raise RuntimeError("Key insertion failed")
                    inserted += 1
        slots = [_finalize(record) for record in pending]
        actions = [record.action.name for record in pending]
    return {
        "actions": actions, "slots": slots, "keys_inserted": inserted,
        "mapped_channels": sorted(matches), "unmapped_channels": missing,
        "duration_seconds": clip.duration, "source_samples": len(clip.times),
        "target_fps": render.fps / render.fps_base,
    }
