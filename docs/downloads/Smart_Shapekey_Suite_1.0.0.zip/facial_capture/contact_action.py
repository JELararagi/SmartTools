# SPDX-License-Identifier: GPL-3.0-or-later
"""User-invoked, four-key-frame contact inspection inside the existing Suite.

No runtime services. Reports describe key frames only, and never promote a
contact count into a normals, visual, whole-model or between-keys acceptance.
"""
import array
import hashlib
import json
import math
import bpy
from .capture_csv import canonical_name
from .contact_diagnosis import diagnose_selected
from .contact_batch import frame_plan, new_report, run_batch

OWNER = 'smart_shapekey_suite.contact_action.v1'
MAX_TEXT = 8 * 1024 * 1024
MAX_SCALARS = 20000000
MAX_ITEMS = 1000000
MAX_IDS = 64


def assigned_curves(animation):
    if not animation or not animation.action:
        return
    if animation.use_nla and any(not track.mute and len(track.strips) for track in animation.nla_tracks):
        raise ValueError('Mute the shape-key NLA tracks before inspecting the assigned Action.')
    slot = animation.action_slot
    if slot is None:
        raise ValueError('The assigned Action has no active slot.')
    for layer in animation.action.layers:
        for strip in layer.strips:
            if strip.type != 'KEYFRAME':
                raise ValueError('Only standard keyframe Action strips are supported.')
            for bag in strip.channelbags:
                if bag.slot_handle == slot.handle:
                    yield from bag.fcurves


def selected_meshes(context):
    selected = sorted(context.selected_objects, key=lambda obj: obj.name_full)
    active = context.view_layer.objects.active
    if context.mode != 'OBJECT' or not 2 <= len(selected) <= 4 or active not in selected or any(obj.type != 'MESH' for obj in selected):
        raise ValueError('Activate the tongue and select two to four oral meshes in Object Mode.')
    if context.scene.library or not context.scene.is_editable:
        raise ValueError('Use an editable local scene for the Action contact report.')
    return selected, active


def action_frames(selected):
    def values():
        for obj in selected:
            keys = obj.data.shape_keys
            if not keys:
                continue
            paths = {key.path_from_id('value') for key in keys.key_blocks if canonical_name(key.name)}
            for curve in assigned_curves(keys.animation_data):
                if curve.data_path in paths and curve.array_index == 0:
                    if curve.mute or not curve.is_valid:
                        raise ValueError('An assigned ARKit Action curve is muted or invalid.')
                    for point in curve.keyframe_points:
                        yield point.co[0]
    return frame_plan(values())


def source_signature(context, selected, active):
    """Hash geometry only where geometry affects the selected oral parts.

    Transform/numeric dependencies retain transforms, Actions, constraints and
    resolved driver inputs. Data Transfer, armature deformation, vertex parents
    and geometric constraints explicitly request their geometry/rig inputs.
    Roles can be upgraded after an ID has already been visited. Budgets stay
    unchanged; reopening the file still requires a new report.
    """
    STATE, GEOMETRY, RIG = 1, 2, 4
    digest = hashlib.sha256()
    pending, roles, visited = [], {}, {}
    visited_structs = set()
    budget = dict(scalars=0, items=0)
    def enqueue(value, role=STATE):
        if value is None:
            return
        token = value.as_pointer()
        roles[token] = roles.get(token, 0) | STATE | role
        pending.append(value)
    for obj in selected:
        enqueue(obj, GEOMETRY)
    def emit(value):
        digest.update(json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8'))
        digest.update(b'\n')
    def ident(value):
        return [value.bl_rna.identifier, value.name_full, value.as_pointer(), value.library.filepath if value.library else None]
    def scalar(value):
        if isinstance(value, bpy.types.ID):
            enqueue(value)
            return ident(value)
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, set):
            return sorted(value)
        if hasattr(value, 'items'):
            return {str(key): scalar(item) for key, item in value.items()}
        return [scalar(item) for item in value]
    def driver_input(value):
        target = getattr(value, 'id', None)
        path = getattr(value, 'data_path', '')
        extra = {}
        if isinstance(target, bpy.types.ID):
            enqueue(target)
            if isinstance(target, bpy.types.Object):
                if getattr(value, 'bone_target', '') or path.startswith('pose.'):
                    enqueue(target, RIG)
                if path.startswith('data.shape_keys.') and path.endswith('.value'):
                    enqueue(target.data)
                elif path.startswith('data.') or path.startswith('dimensions') or path.startswith('bound_box'):
                    enqueue(target, GEOMETRY)
            elif isinstance(target, bpy.types.Key) and ('.data[' in path or path.endswith('.co')):
                enqueue(target, GEOMETRY)
            if path:
                try:
                    extra['resolved_driver_input'] = scalar(target.path_resolve(path, False))
                except (ValueError, TypeError, AttributeError):
                    # Existing invalid driver paths remain explicit and stable.
                    # If the path becomes valid, the signature changes.
                    extra['resolved_driver_input'] = {'unresolved_path': path}
        return extra
    def key_points(items):
        """Read RNA numeric columns in bounded buffers instead of per point."""
        if not items:
            return {'bulk_keyframe_points': 0}
        first = items[0]
        for prop in first.bl_rna.properties:
            name = prop.identifier
            if name in {'rna_type', 'id_data'}:
                continue
            if prop.type in {'FLOAT', 'INT', 'BOOLEAN'}:
                width = prop.array_length if prop.is_array else 1
                count = len(items) * width
                budget['scalars'] += count
                if budget['scalars'] > MAX_SCALARS:
                    raise ValueError('Action contact source coordinate limit exceeded.')
                kind = {'FLOAT': 'f', 'INT': 'i', 'BOOLEAN': 'b'}[prop.type]
                packed = array.array(kind, [0]) * count
                items.foreach_get(name, packed)
                emit(['keyframe_column', name, prop.type, width, len(items)])
                digest.update(packed.tobytes())
            elif prop.type in {'ENUM', 'STRING'}:
                emit(['keyframe_column', name, prop.type, [scalar(getattr(point, name)) for point in items]])
            else:
                raise ValueError('Unsupported contact dependency. Use the single-frame report instead.')
        return {'bulk_keyframe_points': len(items)}
    def struct(value, depth=0):
        token = value.as_pointer() if hasattr(value, 'as_pointer') else id(value)
        if token in visited_structs:
            return {'rna_reference': token}
        visited_structs.add(token)
        if depth > 16:
            raise ValueError('Action contact dependency depth exceeded.')
        result = driver_input(value) if hasattr(value, 'id') and hasattr(value, 'data_path') else {}
        for prop in value.bl_rna.properties:
            name = prop.identifier
            if name in {'rna_type', 'id_data'}:
                continue
            if isinstance(value, (bpy.types.Bone, bpy.types.PoseBone)):
                if name.startswith('custom_shape') or (prop.type == 'COLLECTION' and name != 'constraints'):
                    continue
            item = getattr(value, name)
            if prop.type == 'COLLECTION':
                budget['items'] += len(item)
                if budget['items'] > MAX_ITEMS:
                    raise ValueError('Action contact dependency item limit exceeded.')
                result[name] = key_points(item) if name == 'keyframe_points' and hasattr(item, 'foreach_get') else [struct(child, depth + 1) for child in item]
            elif prop.type == 'POINTER':
                if item is None or isinstance(item, bpy.types.ID):
                    result[name] = scalar(item)
                elif name == 'driver':
                    result[name] = struct(item, depth + 1)
                elif name == 'action_slot':
                    result[name] = [item.identifier, item.handle]
            else:
                result[name] = scalar(item)
        return result
    def coords(collection):
        count = len(collection) * 3
        budget['scalars'] += count
        if budget['scalars'] > MAX_SCALARS:
            raise ValueError('Action contact source coordinate limit exceeded.')
        packed = array.array('f', [0]) * count
        collection.foreach_get('co', packed)
        digest.update(packed.tobytes())
    def animation(value):
        data = value.animation_data
        if data:
            emit(struct(data))
    def constraints(items):
        for constraint in items:
            target = getattr(constraint, 'target', None)
            kind = getattr(constraint, 'type', '')
            if target:
                if kind in {'SHRINKWRAP', 'FOLLOW_PATH', 'CLAMP_TO'}:
                    enqueue(target, GEOMETRY)
                elif getattr(constraint, 'subtarget', ''):
                    enqueue(target, RIG)
            if kind == 'ARMATURE':
                for item in constraint.targets:
                    enqueue(item.target, RIG)
        return [struct(item) for item in items]
    emit(dict(scene=ident(context.scene), view_layer=context.view_layer.name, active=ident(active),
              selected=[ident(obj) for obj in selected], origin=[context.scene.frame_current, context.scene.frame_subframe],
              simplify=[context.scene.render.use_simplify, context.scene.render.simplify_subdivision],
              blender=list(bpy.app.version), build=str(bpy.app.build_hash)))
    while pending:
        value = pending.pop(0)
        token = value.as_pointer()
        role = roles[token]
        if visited.get(token, 0) & role == role:
            continue
        visited[token] = visited.get(token, 0) | role
        if len(visited) > MAX_IDS:
            raise ValueError('Action contact dependency ID limit exceeded.')
        emit([ident(value), role])
        geometry_required = bool(role & GEOMETRY)
        rig_required = bool(role & RIG) or (geometry_required and isinstance(value, bpy.types.Object) and value.type == 'ARMATURE')
        if isinstance(value, bpy.types.Object):
            supported_modifiers = {'ARMATURE', 'SUBSURF', 'CORRECTIVE_SMOOTH', 'SMOOTH', 'WEIGHTED_NORMAL', 'NORMAL_EDIT', 'MIRROR', 'SOLIDIFY', 'SIMPLE_DEFORM', 'TRIANGULATE', 'DATA_TRANSFER'}
            if value.rigid_body or (geometry_required and any(mod.type not in supported_modifiers for mod in value.modifiers)):
                raise ValueError('This Action contact batch does not support simulation or this modifier type.')
            if geometry_required or rig_required:
                enqueue(value.data, RIG if value.type == 'ARMATURE' else GEOMETRY)
            if value.parent and value.parent_type in {'VERTEX', 'VERTEX_3'}:
                enqueue(value.parent, GEOMETRY)
            elif value.parent and value.parent_type == 'BONE':
                enqueue(value.parent, RIG)
            if geometry_required:
                for mod in value.modifiers:
                    if mod.type == 'DATA_TRANSFER':
                        enqueue(mod.object, GEOMETRY)
                    elif mod.type == 'ARMATURE':
                        enqueue(mod.object, RIG)
            emit(dict(type=value.type, parent=scalar(value.parent), data=ident(value.data) if value.data else None,
                      matrix=[list(row) for row in value.matrix_world], hide_viewport=value.hide_viewport,
                      parent_inverse=[list(row) for row in value.matrix_parent_inverse], parent_bone=value.parent_bone, parent_type=value.parent_type,
                      transforms={name: scalar(getattr(value, name)) for name in ('location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'rotation_mode', 'scale', 'delta_location', 'delta_rotation_euler', 'delta_rotation_quaternion', 'delta_scale')},
                      modifiers=[struct(mod) for mod in value.modifiers] if geometry_required else [],
                      constraints=constraints(value.constraints),
                      vertex_groups=[[g.name, g.index] for g in value.vertex_groups] if geometry_required else []))
            if rig_required and value.pose:
                for bone in value.pose.bones:
                    constraints(bone.constraints)
                    emit(dict(rna=struct(bone), custom={name: scalar(bone[name]) for name in sorted(bone.keys()) if name != '_RNA_UI'}))
            animation(value)
        elif isinstance(value, bpy.types.Mesh):
            if geometry_required:
                coords(value.vertices)
                if len(value.loops) + len(value.edges) > MAX_ITEMS:
                    raise ValueError('Action contact mesh topology limit exceeded.')
                emit([list(edge.vertices) for edge in value.edges])
                emit([[p.loop_start, p.loop_total] for p in value.polygons])
                emit([loop.vertex_index for loop in value.loops])
                emit([[[g.group, g.weight] for g in vertex.groups] for vertex in value.vertices])
                for attribute in value.attributes:
                    emit([attribute.name, attribute.data_type, attribute.domain])
                    # Supported position modifiers do not consume UV/color
                    # values. Keep metadata, weights, crease and normal data;
                    # this report never accepts materials or rendered shading.
                    if attribute.data_type in {'FLOAT2', 'FLOAT_COLOR', 'BYTE_COLOR'}:
                        continue
                    budget['items'] += len(attribute.data)
                    if budget['items'] > MAX_ITEMS:
                        raise ValueError('Action contact attribute item limit exceeded.')
                    for item in attribute.data:
                        emit(struct(item))
            enqueue(value.shape_keys, GEOMETRY if geometry_required else STATE)
            animation(value)
        elif isinstance(value, bpy.types.Key):
            emit(dict(use_relative=value.use_relative, eval_time=value.eval_time))
            for key in value.key_blocks:
                emit([key.name, key.value, key.mute, key.relative_key.name, key.vertex_group, key.interpolation, key.frame])
                if geometry_required:
                    coords(key.data)
            animation(value)
        elif isinstance(value, bpy.types.Action):
            emit([dict(name=layer.name, strips=[struct(strip) for strip in layer.strips]) for layer in value.layers])
        elif isinstance(value, bpy.types.Armature):
            if role & RIG:
                emit([dict(rna=struct(bone), parent=bone.parent.name if bone.parent else None,
                           custom={name: scalar(bone[name]) for name in sorted(bone.keys()) if name != '_RNA_UI'}) for bone in value.bones])
            animation(value)
        elif isinstance(value, bpy.types.Scene):
            animation(value)
        elif isinstance(value, bpy.types.Collection):
            for obj in value.all_objects:
                enqueue(obj, GEOMETRY if geometry_required else STATE)
        else:
            raise ValueError('Unsupported contact dependency. Use the single-frame report instead.')
        if hasattr(value, 'keys') and not isinstance(value, bpy.types.Scene):
            emit({name: scalar(value[name]) for name in sorted(value.keys()) if name != '_RNA_UI'})
    return digest.hexdigest()


def inspect_action_batch(context, *, restart=False):
    selected, active = selected_meshes(context)
    cfg = context.scene.smart_shapekey_facial_settings
    origin = (context.scene.frame_current, context.scene.frame_subframe)
    signature = source_signature(context, selected, active)
    old_text = bpy.data.texts.get(cfg.contact_action_report_name)
    if restart:
        report = new_report(action_frames(selected), signature, origin, active.name_full)
    else:
        if not old_text or old_text.library or not old_text.is_editable or old_text.get('ss_contact_action_owner') != OWNER or old_text.get('ss_contact_action_scene') != context.scene.name_full:
            raise ValueError('Start an Action contact inspection first.')
        raw = old_text.as_string()
        if len(raw.encode('utf-8')) > MAX_TEXT:
            raise ValueError('Action contact report exceeds the read limit.')
        if hashlib.sha256(raw.encode('utf-8')).hexdigest() != old_text.get('ss_contact_action_sha256'):
            raise ValueError('The Action contact report was edited. Start a new inspection.')
        report = json.loads(raw)
    def set_frame(frame):
        whole = math.floor(frame)
        context.scene.frame_set(whole, subframe=frame - whole)
        if abs(context.scene.frame_current_final - frame) > 1e-5:
            raise ValueError('Blender did not reach the requested Action frame.')
    def restore_frame(value):
        context.scene.frame_set(value[0], subframe=value[1])
    updated = run_batch(report, signature, origin, set_frame, restore_frame,
                        lambda: diagnose_selected(context),
                        lambda: source_signature(context, selected, active) == signature)
    encoded = json.dumps(updated, indent=2, ensure_ascii=False, allow_nan=False)
    if len(encoded.encode('utf-8')) > MAX_TEXT:
        raise ValueError('Action contact report exceeds the write limit; progress was not saved.')
    # One bounded report per run; retain the preceding run when restarting.
    # On write failure restore both the report content and selected RNA fields.
    text = bpy.data.texts.new('SS_Facial_Contact_Action_Report') if restart else old_text
    old_name, old_status = cfg.contact_action_report_name, cfg.contact_action_report_status
    old_pending = cfg.contact_action_pending
    old_hash = text.get('ss_contact_action_sha256')
    try:
        text['ss_contact_action_owner'] = OWNER
        text['ss_contact_action_scene'] = context.scene.name_full
        if not restart:
            text.clear()
        text.write(encoded)
        text['ss_contact_action_sha256'] = hashlib.sha256(encoded.encode('utf-8')).hexdigest()
        cfg.contact_action_report_name = text.name
        status = updated['status']
        labels = dict(PENDING='継続可', COMPLETE='全キー時刻の交差検査終了', CONTACT_FOUND='接触を検出・停止')
        cfg.contact_action_report_status = f"{updated['next_index']}/{len(updated['frames'])}点: {labels[status]}"
        cfg.contact_action_pending = status == 'PENDING'
    except Exception:
        cfg.contact_action_report_name, cfg.contact_action_report_status = old_name, old_status
        cfg.contact_action_pending = old_pending
        if restart:
            bpy.data.texts.remove(text)
        else:
            text.clear()
            text.write(raw)
            text['ss_contact_action_sha256'] = old_hash
        raise
    return updated
