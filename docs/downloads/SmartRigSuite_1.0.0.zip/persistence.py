# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Portable N-panel state persistence for Smart Rig Suite.

Only user-editable panel and add-on preference values are stored. Scene objects
are referenced by datablock name; no rig, animation, mesh, or external add-on
data is copied into the JSON file.
"""

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()


import copy
import json
import os
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent

from . import generation

from .unified_contract import CONFIG_FILE, CONFIG_FOLDER, EXTENSION_ID

_SCHEMA_VERSION = 1
_TRANSIENT_SCENE_NAMES = {
    "rna_type",
    "name",
    "last_status",
    "last_report_text",
    "last_preflight_text",
    "rescale_factor",
    "rescale_target_height_mm",
    "rescale_current_height_mm",
    "rescale_measured_top_mm",
    "rescale_measured_bottom_mm",
    "rescale_measured_rig",
    "rescale_measured_basis",
    "rescale_rebind_bound",
    "jiggle_named_chains",
    "part_motion_name",
    "jiggle_clear_prefix",
}
_TRANSIENT_PREFERENCE_NAMES = {"rna_type", "bl_idname"}
# Panel display state (which sections are open) follows the saved state everywhere. Every other
# scene setting belongs to the file once the file has set it: lengths such as the collision
# thickness or the floor are part of the character. Measured 2026-10-03: MIK_132 was saved at
# 158 cm with chain_collide_mm 3.8303, and opening it replaced that with the global 4.0 (the
# 165 cm value), which the next bake would have used.
_DISPLAY_PREFIXES = ("show_", "ui_section_")

_APPLYING = False
_REGISTERED = False
_PAYLOAD: dict[str, Any] | None = None
_LAST_TEXT = ""
_SCENE_MSGBUS_OWNER = object()


def config_path(*, create: bool = True) -> Path:
    try:
        root = Path(bpy.utils.user_resource("CONFIG", create=create))
    except TypeError:
        root = Path(bpy.utils.user_resource("CONFIG"))
    folder = root / CONFIG_FOLDER
    if create:
        folder.mkdir(parents=True, exist_ok=True)
    return folder / CONFIG_FILE


def _empty_payload() -> dict[str, Any]:
    return {
        "schema_version": _SCHEMA_VERSION,
        "addon_id": EXTENSION_ID,
        "scene_settings": {},
        "preferences": {},
    }


def _read_payload(*, refresh: bool = False) -> dict[str, Any]:
    global _PAYLOAD
    if isinstance(_PAYLOAD, dict) and not refresh:
        return _PAYLOAD
    payload = _empty_payload()
    path = config_path(create=True)
    try:
        raw = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        raw = {}
    if isinstance(raw, dict):
        for key in ("scene_settings", "preferences"):
            value = raw.get(key)
            if isinstance(value, dict):
                payload[key] = value
    payload["schema_version"] = _SCHEMA_VERSION
    payload["addon_id"] = EXTENSION_ID
    _PAYLOAD = payload
    return payload


def _simple_json_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    try:
        if isinstance(value, bpy.types.ID):
            return {
                "__smart_rig_id__": True,
                "id_type": str(getattr(getattr(value, "bl_rna", None), "identifier", "") or type(value).__name__),
                "name": str(getattr(value, "name", "") or ""),
            }
    except Exception:
        pass
    try:
        sequence = list(value)
    except Exception:
        return None
    if len(sequence) > 128:
        return None
    converted = []
    for item in sequence:
        if not isinstance(item, (bool, int, float, str)):
            return None
        converted.append(item)
    return converted


def _serialize_owner(owner: Any, excluded: set[str]) -> dict[str, Any]:
    if owner is None:
        return {}
    result: dict[str, Any] = {}
    try:
        properties = tuple(getattr(getattr(owner, "bl_rna", None), "properties", ()) or ())
    except Exception:
        properties = ()
    for prop in properties:
        try:
            name = str(getattr(prop, "identifier", "") or "")
            if not name or name in excluded or bool(getattr(prop, "is_readonly", False)):
                continue
            value = getattr(owner, name)
        except Exception:
            continue
        prop_type = str(getattr(prop, "type", "") or "").upper()
        if prop_type == "POINTER" and value is None:
            fixed_type = str(getattr(getattr(prop, "fixed_type", None), "identifier", "") or "")
            result[name] = {
                "__smart_rig_id__": True,
                "id_type": fixed_type,
                "name": "",
            }
            continue
        converted = _simple_json_value(value)
        if converted is not None:
            result[name] = converted
    return result


def _resolve_saved_id(value: Any) -> Any:
    if not isinstance(value, dict) or not bool(value.get("__smart_rig_id__")):
        return value
    name = str(value.get("name") or "")
    if not name:
        return None
    id_type = str(value.get("id_type") or "").lower()
    try:
        if "object" in id_type or id_type in {"armature", "mesh"}:
            return bpy.data.objects.get(name)
        if "collection" in id_type:
            return bpy.data.collections.get(name)
        if "material" in id_type:
            return bpy.data.materials.get(name)
        if "text" in id_type:
            return bpy.data.texts.get(name)
    except Exception:
        return None
    return None


def _apply_owner(owner: Any, values: Any, excluded: set[str], keep_file_values: bool = False) -> None:
    if owner is None or not isinstance(values, dict):
        return
    for name, value in values.items():
        name = str(name or "")
        if not name or name in excluded or not hasattr(owner, name):
            continue
        if keep_file_values and not name.startswith(_DISPLAY_PREFIXES):
            try:
                if owner.is_property_set(name):
                    continue
            except Exception:
                pass
        try:
            setattr(owner, name, _resolve_saved_id(value))
        except Exception:
            pass


def _context_scene(context=None):
    ctx = context or getattr(bpy, "context", None)
    if ctx is None:
        return None
    try:
        window = getattr(ctx, "window", None)
        scene = getattr(window, "scene", None) if window is not None else None
        if scene is not None:
            return scene
    except Exception:
        pass
    return getattr(ctx, "scene", None)


def _scene_settings(context=None):
    scene = _context_scene(context)
    return getattr(scene, "srs_settings", None) if scene is not None else None


def _addon_preferences(context=None):
    try:
        from .preferences import get_preferences
        return get_preferences(context)
    except Exception:
        return None


def state_save_enabled(context=None) -> bool:
    settings = _scene_settings(context)
    if settings is not None:
        try:
            return bool(settings.n_panel_state_save)
        except Exception:
            pass
    try:
        return bool(_read_payload().get("scene_settings", {}).get("n_panel_state_save", True))
    except Exception:
        return True


def _collect(context=None) -> dict[str, Any]:
    current = copy.deepcopy(_read_payload())
    settings = _scene_settings(context)
    preferences = _addon_preferences(context)
    if settings is not None:
        current["scene_settings"] = _serialize_owner(settings, _TRANSIENT_SCENE_NAMES)
    if preferences is not None:
        current["preferences"] = _serialize_owner(preferences, _TRANSIENT_PREFERENCE_NAMES)
    current["schema_version"] = _SCHEMA_VERSION
    current["addon_id"] = EXTENSION_ID
    return current


def _write_payload(payload: dict[str, Any]) -> bool:
    global _PAYLOAD, _LAST_TEXT
    try:
        text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        return False
    if text == _LAST_TEXT:
        _PAYLOAD = payload
        return True
    path = config_path(create=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    try:
        temporary.write_text(text, encoding="utf-8")
        os.replace(str(temporary), str(path))
    except Exception:
        try:
            temporary.unlink(missing_ok=True)
        except Exception:
            pass
        return False
    _PAYLOAD = payload
    _LAST_TEXT = text
    return True


def save(context=None, *, force: bool = False) -> bool:
    if _APPLYING:
        return False
    if not force and not state_save_enabled(context):
        return False
    return _write_payload(_collect(context))


def property_updated(_owner=None, context=None, *, force: bool = False) -> None:
    """Persist a changed property and keep lifecycle hooks in sync.

    The state-save switch itself uses ``force=True`` so its new value is
    written before hooks are removed.  With the switch disabled there is no
    timer, application handler, message-bus subscription, draw handler, or
    keymap owned by this persistence layer.
    """
    if _APPLYING:
        return
    ctx = context or getattr(bpy, "context", None)
    save(ctx, force=force)
    if force and _REGISTERED:
        if state_save_enabled(ctx):
            _register_hooks()
        else:
            _unregister_hooks()


def apply(context=None, *, refresh: bool = False) -> bool:
    global _APPLYING
    payload = _read_payload(refresh=refresh)
    settings = _scene_settings(context)
    preferences = _addon_preferences(context)
    if settings is None and preferences is None:
        return False
    _APPLYING = True
    try:
        _apply_owner(preferences, payload.get("preferences", {}), _TRANSIENT_PREFERENCE_NAMES)
        _apply_owner(settings, payload.get("scene_settings", {}), _TRANSIENT_SCENE_NAMES, keep_file_values=True)
    finally:
        _APPLYING = False
    try:
        from . import compatibility
        compatibility.sync_runtime_state()
    except Exception:
        pass
    return True


def _scene_changed_notify() -> None:
    context = getattr(bpy, "context", None)
    if not state_save_enabled(context):
        _unregister_hooks()
        return
    try:
        apply(context, refresh=False)
    except Exception:
        pass


def _subscribe_scene_changes() -> None:
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass
    generation.untrack_msgbus_owner(_SCENE_MSGBUS_OWNER, module_name=__name__)
    subscribed = False
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.Window, "scene"),
            owner=_SCENE_MSGBUS_OWNER,
            args=(),
            notify=_scene_changed_notify,
            options={"PERSISTENT"},
        )
        subscribed = True
        generation.track_msgbus_owner(_SCENE_MSGBUS_OWNER, module_name=__name__)
    except Exception:
        if subscribed:
            try:
                bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
            except Exception:
                pass
        generation.untrack_msgbus_owner(_SCENE_MSGBUS_OWNER, module_name=__name__)


@persistent
def _load_post(_dummy=None) -> None:
    context = getattr(bpy, "context", None)
    try:
        apply(context, refresh=True)
    finally:
        if state_save_enabled(context):
            _register_hooks()
        else:
            _unregister_hooks()


@persistent
def _save_boundary(_dummy=None) -> None:
    try:
        save(getattr(bpy, "context", None), force=False)
    except Exception:
        pass


def _append_once(collection, handler, label: str) -> None:
    added = False
    try:
        if not any(item is handler for item in tuple(collection)):
            collection.append(handler)
            added = True
        generation.track_handler(
            collection,
            handler,
            module_name=__name__,
            label=label,
        )
    except Exception:
        if added:
            try:
                collection.remove(handler)
            except Exception:
                pass
        generation.untrack_handler(handler, module_name=__name__)


def _remove_all(collection, handler) -> None:
    try:
        while any(item is handler for item in tuple(collection)):
            for item in tuple(collection):
                if item is handler:
                    collection.remove(item)
                    break
    except Exception:
        pass
    generation.untrack_handler(handler, module_name=__name__)


def _register_hooks() -> None:
    if not _REGISTERED:
        return
    _append_once(bpy.app.handlers.load_post, _load_post, "load_post")
    for handler_name in ("save_pre", "undo_post", "redo_post", "exit_pre"):
        collection = getattr(bpy.app.handlers, handler_name, None)
        if collection is not None:
            _append_once(collection, _save_boundary, handler_name)
    _subscribe_scene_changes()


def _unregister_hooks() -> None:
    try:
        bpy.msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass
    generation.untrack_msgbus_owner(_SCENE_MSGBUS_OWNER, module_name=__name__)
    _remove_all(bpy.app.handlers.load_post, _load_post)
    for handler_name in ("save_pre", "undo_post", "redo_post", "exit_pre"):
        collection = getattr(bpy.app.handlers, handler_name, None)
        if collection is not None:
            _remove_all(collection, _save_boundary)


def _shutdown_persistence() -> None:
    """Persist the final state and detach hooks using retained callback identities."""
    errors = []
    try:
        save(getattr(bpy, "context", None), force=False)
    except Exception as exc:
        errors.append(f"save: {type(exc).__name__}: {exc}")
    try:
        _unregister_hooks()
    except Exception as exc:
        errors.append(f"hooks: {type(exc).__name__}: {exc}")
    if errors:
        raise RuntimeError("; ".join(errors))


def register() -> bool:
    global _REGISTERED, _LAST_TEXT
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False
    generation.assert_module_context(__name__, __srs_revision__, __srs_module_generation_marker__)
    _LAST_TEXT = ""
    _read_payload(refresh=True)
    apply(getattr(bpy, "context", None), refresh=False)
    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    try:
        if state_save_enabled(getattr(bpy, "context", None)):
            _register_hooks()
        else:
            _unregister_hooks()
        generation.track_cleanup(
            _shutdown_persistence,
            module_name=__name__,
            label="final JSON save and persistence hook shutdown",
        )
    except Exception:
        try:
            _shutdown_persistence()
        except Exception:
            pass
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
        raise
    return True


def unregister() -> dict:
    global _REGISTERED
    errors = []
    try:
        save(getattr(bpy, "context", None), force=False)
    except Exception as exc:
        errors.append(f"save: {type(exc).__name__}: {exc}")
    try:
        _unregister_hooks()
    except Exception as exc:
        errors.append(f"hooks: {type(exc).__name__}: {exc}")
    resource_report = generation.cleanup_non_ui_resources(module_name=__name__)
    errors.extend(resource_report.get("errors", ()))
    if resource_report.get("all_removed"):
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return {
        "all_removed": bool(resource_report.get("all_removed")),
        "resources": resource_report,
        "errors": errors,
    }
