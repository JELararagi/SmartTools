# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Pose several chains together with one control.

The user's requirement for MIK's four braids (2026-09-29): "4本ともズレずに
まとめて回転などでポーズ操作したい", originally asked as "same bone count and
roughly the same bone lengths". Pivots placed on the geometry (element boundaries,
polygon divisions) gave the braids 38/38/41/41 links of very uneven length
(2 mm metal joints next to 74 mm hair spans), so rotating "the k-th bone of every
braid" can never line them up.

Instead of forcing equal counts, the control layer is separated from the deform
layer:

* ``<key>_swing`` turns every chain about its own root (each root link copies the
  control's local rotation, influence 1).
* ``<key>_curl`` bends every chain along its length. Each link copies a share of the
  control's local rotation equal to its share of the chain's length, so a 30-degree
  curl bends every chain by 30 degrees in total whatever its link count.

Both are COPY_ROTATION constraints in LOCAL space with mix ADD, so animation keys
and baked jiggle on the links still play underneath.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import re

import bpy
from mathutils import Vector

from . import costume_bind

CON_PREFIX = "SRS group "
COLLECTION = "SRS Controls"


def chain_links(armature, prefix):
    """Links of the chain whose bones are named ``<prefix>_<n>``, ordered root to tip."""
    pat = re.compile(r"^" + re.escape(prefix) + r"_(\d+)$")
    out = []
    for b in armature.data.bones:
        m = pat.match(b.name)
        if m:
            out.append((int(m.group(1)), b.name))
    return [n for _, n in sorted(out)]


def chain_prefixes_from_bones(names):
    out = []
    for n in names:
        m = re.match(r"^(.*)_(\d+)$", n)
        if m and m.group(1) not in out:
            out.append(m.group(1))
    return out


def _ensure_mode(armature, mode):
    vl = bpy.context.view_layer
    if vl.objects.active is not armature:
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        vl.objects.active = armature
    if armature.mode != mode:
        bpy.ops.object.mode_set(mode=mode)


def build(armature, prefixes, key="braids", size=0.06):
    """Create (or rebuild) the swing/curl controls for the chains. Returns (report, error)."""
    chains = {p: chain_links(armature, p) for p in prefixes}
    chains = {p: links for p, links in chains.items() if links}
    if not chains:
        return None, "No chain found for the given names."
    remove(armature, key)
    roots = [armature.data.bones[links[0]] for links in chains.values()]
    parent = roots[0].parent.name if roots[0].parent else ""
    head = sum((b.head_local for b in roots), Vector()) / len(roots)
    names = {"swing": "srs_ctl_%s_swing" % key, "curl": "srs_ctl_%s_curl" % key}
    saved = costume_bind.visible_for_edit([armature])
    try:
        _ensure_mode(armature, "EDIT")
        eb = armature.data.edit_bones
        for i, (kind, name) in enumerate(names.items()):
            b = eb.new(name)
            b.head = head + Vector((0.0, 0.0, size * (0.6 + i * 0.9)))
            b.tail = b.head + Vector((0.0, 0.0, size * 0.75))
            b.roll = 0.0
            b.use_deform = False
            if parent and parent in eb:
                b.parent = eb[parent]
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        costume_bind.restore_visibility(saved)
    coll = armature.data.collections_all.get(COLLECTION) or armature.data.collections.new(COLLECTION)
    for name in names.values():
        coll.assign(armature.data.bones[name])
    pb = armature.pose.bones
    made = 0
    for prefix, links in chains.items():
        lengths = [armature.data.bones[n].length for n in links]
        total = sum(lengths) or 1.0
        c = pb[links[0]].constraints.new("COPY_ROTATION")
        c.name = CON_PREFIX + key + " swing"
        c.target, c.subtarget = armature, names["swing"]
        c.mix_mode, c.target_space, c.owner_space = "ADD", "LOCAL", "LOCAL"
        c.influence = 1.0
        made += 1
        for n, length in zip(links, lengths):
            c = pb[n].constraints.new("COPY_ROTATION")
            c.name = CON_PREFIX + key + " curl"
            c.target, c.subtarget = armature, names["curl"]
            c.mix_mode, c.target_space, c.owner_space = "ADD", "LOCAL", "LOCAL"
            c.influence = max(0.0, min(1.0, length / total))
            made += 1
    for name in names.values():
        p = pb[name]
        p.rotation_mode = "XYZ"
        p.lock_location = (True, True, True)
        p.lock_scale = (True, True, True)
    return {"key": key, "chains": {p: len(l) for p, l in chains.items()},
            "controls": list(names.values()), "constraints": made, "parent": parent}, ""


def remove(armature, key):
    """Remove the controls and constraints of one group. Returns the number removed."""
    removed = 0
    prefix = CON_PREFIX + key + " "
    for p in armature.pose.bones:
        for c in list(p.constraints):
            if c.name.startswith(prefix):
                p.constraints.remove(c)
                removed += 1
    names = ["srs_ctl_%s_swing" % key, "srs_ctl_%s_curl" % key]
    if any(n in armature.data.bones for n in names):
        saved = costume_bind.visible_for_edit([armature])
        try:
            _ensure_mode(armature, "EDIT")
            for n in names:
                b = armature.data.edit_bones.get(n)
                if b is not None:
                    armature.data.edit_bones.remove(b)
                    removed += 1
            bpy.ops.object.mode_set(mode="OBJECT")
        finally:
            costume_bind.restore_visibility(saved)
    return removed
