# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Rig a character one collection at a time, so each part stays separable.

A finished character is not one mesh. The reference character keeps its parts in
fifteen collections under one parent -- body, face, four hair groups, tops,
bottoms, outer, skirt, shoes, and several accessories -- and the file also holds
collections that are not the character at all: cameras, lights, references, and
the rig's own control shapes.

Two things follow, and this module exists for both.

**Only some collections are targets.** A name marker decides. Collections whose
name does not carry the marker are left alone, which is what keeps reference and
lighting collections out of the rig. The armature's own collections are excluded
too, so the rig never tries to rig itself.

**A costume must stay removable.** Bones generated for a part are placed in a
*bone collection* named after the source collection, nested under one parent. A
part can then be hidden or deleted as a unit: its meshes, its bones, and the
vertex groups those bones own all carry the same name, so nothing is orphaned.
Without this the generated bones land in no bone collection at all and cannot be
hidden as a group -- measured on the reference rig, fifty hair bones sat outside
every collection while Auto-Rig Pro's own bones were tidily filed in seventeen.
"""

import bpy

PARENT_COLLECTION = "SmartRig Parts"
DEFAULT_MARKER = "MIK"


def _armature_collection_names():
    """Collections that hold an armature -- never rigging targets themselves."""
    out = set()
    for c in bpy.data.collections:
        for o in c.objects:
            if o.type == "ARMATURE":
                out.add(c.name)
                break
    return out


def _custom_shape_names(armature):
    """Meshes the rig uses as bone shapes. These are controls, not costume."""
    out = set()
    for obj in (armature, _rig_add(armature)):
        if obj is None or obj.type != "ARMATURE" or obj.pose is None:
            continue
        for pb in obj.pose.bones:
            shape = pb.custom_shape
            if shape is not None:
                out.add(shape.name)
    return out


def _rig_add(armature):
    """Auto-Rig Pro's additive armature, which carries its own bone shapes."""
    if armature is None:
        return None
    return bpy.data.objects.get(armature.name + "_add")


def _is_control_shelf(collection, shapes):
    """True when every mesh here is one of the rig's bone shapes.

    Auto-Rig Pro keeps its controls in a collection that carries the character's
    name and holds nothing but meshes, so nothing about the name or the shape of
    it tells a costume apart from the control shelf. What a bone points at does:
    measured on the reference character, all 52 meshes in that collection were
    referenced as bone shapes and every shape the rig used was one of them.
    """
    if not shapes:
        return False
    meshes = [o for o in collection.objects if o.type == "MESH"]
    return bool(meshes) and all(o.name in shapes for o in meshes)


def discover_parts(marker=DEFAULT_MARKER, require_mesh=True, leaf_only=True,
                   armature=None):
    """Collections that should be rigged. Returns ``(parts, error)``.

    ``marker`` is matched case-sensitively against the collection name, because
    the character's own prefix is what separates its parts from everything else
    in the file.

    ``leaf_only`` keeps the containers out. The naming convention is three deep
    -- character, then genre, then part, as in ``MIK`` / ``MIK_geo`` /
    ``MIK_geo_bodyA`` -- and only the deepest level holds a part. The two above
    it carry the marker just as plainly, so without this rule the character
    itself would be reported as one of its own costumes.
    """
    if not marker:
        return None, "A name marker is required, or every collection would match"
    skip = _armature_collection_names()
    shapes = _custom_shape_names(armature)
    parts = []
    for c in bpy.data.collections:
        if marker not in c.name:
            continue
        if c.name in skip:
            continue
        if leaf_only and c.children:
            continue
        if _is_control_shelf(c, shapes):
            continue
        meshes = [o for o in c.objects if o.type == "MESH"]
        if require_mesh and not meshes:
            continue
        parts.append({
            "collection": c.name,
            "objects": [o.name for o in meshes],
            "n_objects": len(meshes),
            "verts": sum(len(o.data.vertices) for o in meshes if o.data),
            "children": [ch.name for ch in c.children],
        })
    parts.sort(key=lambda p: p["collection"])
    if not parts:
        return None, "No collection carries the marker %r" % marker
    return parts, ""


def skipped_collections(marker=DEFAULT_MARKER, leaf_only=True, armature=None):
    """What discovery deliberately left out, and why -- never a silent drop."""
    skip = _armature_collection_names()
    shapes = _custom_shape_names(armature)
    out = []
    for c in bpy.data.collections:
        if c.name in skip:
            why = "holds an armature"
        elif marker not in c.name:
            why = "name does not carry %r" % marker
        elif leaf_only and c.children:
            why = "is a container for %d sub-collections" % len(c.children)
        elif _is_control_shelf(c, shapes):
            why = "holds the rig's bone shapes, not costume"
        elif not [o for o in c.objects if o.type == "MESH"]:
            why = "holds no mesh"
        else:
            continue
        out.append({"collection": c.name, "why": why,
                    "n_objects": len(c.objects)})
    out.sort(key=lambda r: r["collection"])
    return out


def shared_meshes(marker=DEFAULT_MARKER, armature=None):
    """Meshes of a part that are also linked somewhere outside it.

    A second link defeats the whole point of a part. Hiding a collection hides
    what it holds only through that collection, so a mesh linked into two places
    stays visible when its own part is hidden -- measured on the reference
    character, whose body mesh sat in both its part and the rig's own
    collection, so hiding the body did nothing.
    """
    parts, err = discover_parts(marker=marker, armature=armature)
    if parts is None:
        return [], err
    own = {p["collection"] for p in parts}
    out = []
    for p in parts:
        c = bpy.data.collections.get(p["collection"])
        if c is None:
            continue
        for o in c.objects:
            extra = sorted(x.name for x in o.users_collection
                           if x.name != p["collection"])
            if extra:
                out.append({"object": o.name, "part": p["collection"],
                            "also_in": extra,
                            "other_part": [n for n in extra if n in own]})
    return out, ""


def ensure_bone_collection(armature, name, parent=PARENT_COLLECTION):
    """The bone collection for a part, nested under one parent. Creates as needed."""
    if armature is None or armature.type != "ARMATURE":
        return None
    arm = armature.data
    top = None
    if parent:
        top = arm.collections_all.get(parent)
        if top is None:
            top = arm.collections.new(parent)
    bc = arm.collections_all.get(name)
    if bc is None:
        bc = arm.collections.new(name, parent=top) if top else arm.collections.new(name)
    elif top is not None and bc.parent is None and bc is not top:
        try:
            bc.parent = top
        except (AttributeError, TypeError):
            pass
    return bc


def assign_bones(armature, bone_names, part, parent=PARENT_COLLECTION):
    """Put bones in the part's bone collection. Returns how many were filed."""
    bc = ensure_bone_collection(armature, part, parent=parent)
    if bc is None:
        return 0
    n = 0
    for name in bone_names:
        bone = armature.data.bones.get(name)
        if bone is None:
            continue
        bc.assign(bone)
        n += 1
    return n


LINK_PROP = "srs_linked_keys"


def linked_keys(part):
    """``[(object name, shape key name, value when shown, value when hidden)]`` stored on the part."""
    c = bpy.data.collections.get(part)
    if c is None:
        return []
    out = []
    for item in str(c.get(LINK_PROP, "")).split(";"):
        bits = item.split("|")
        if len(bits) == 4 and bits[0] and bits[1]:
            try:
                out.append((bits[0], bits[1], float(bits[2]), float(bits[3])))
            except ValueError:
                continue
    return out


def link_key(part, obj_name, key_name, shown=1.0, hidden=0.0, remove=False):
    """Make a shape key follow the part's Show / Hide. ``(links, error)``."""
    c = bpy.data.collections.get(part)
    if c is None:
        return None, "No collection called %s" % part
    obj = bpy.data.objects.get(obj_name)
    keys = getattr(getattr(obj, "data", None), "shape_keys", None) if obj is not None else None
    if not remove and (keys is None or keys.key_blocks.get(key_name) is None):
        return None, "%s has no shape key called %s" % (obj_name, key_name)
    rows = [row for row in linked_keys(part) if (row[0], row[1]) != (obj_name, key_name)]
    if not remove:
        rows.append((obj_name, key_name, float(shown), float(hidden)))
    c[LINK_PROP] = ";".join("%s|%s|%g|%g" % row for row in rows)
    return rows, ""


def apply_linked_keys(part, visible):
    """Set every linked shape key to its shown / hidden value. Returns how many were set."""
    n = 0
    for obj_name, key_name, shown, hidden in linked_keys(part):
        obj = bpy.data.objects.get(obj_name)
        keys = getattr(getattr(obj, "data", None), "shape_keys", None) if obj is not None else None
        block = keys.key_blocks.get(key_name) if keys is not None else None
        if block is not None:
            block.value = shown if visible else hidden
            n += 1
    return n


def set_part_visible(part, armature=None, visible=True, parent=PARENT_COLLECTION):
    """Show or hide a part's meshes AND its bones together.

    Hiding only the meshes leaves the part's controls floating in the viewport,
    which is the thing that makes a costume feel un-removable.
    """
    touched = {"collection": False, "bones": False, "keys": 0}
    c = bpy.data.collections.get(part)
    if c is not None:
        c.hide_viewport = not visible
        c.hide_render = not visible
        touched["collection"] = True
        touched["keys"] = apply_linked_keys(part, visible)
    if armature is not None and armature.type == "ARMATURE":
        bc = armature.data.collections_all.get(part)
        if bc is not None:
            bc.is_visible = bool(visible)
            touched["bones"] = True
        # the collision capsules follow the part too (collide.fit_without)
        from . import collide
        touched["colliders"] = collide.apply_parts(armature)["capsules"]
    return touched


def delete_part(part, armature=None, delete_meshes=True, parent=PARENT_COLLECTION):
    """Remove a costume completely: meshes, bones and the groups they owned.

    Returns ``(report, error)``.
    """
    report = {"part": part, "objects": 0, "bones": 0, "vertex_groups": 0}
    c = bpy.data.collections.get(part)
    if c is None and armature is None:
        return None, "No collection called %r" % part

    bone_names = []
    if armature is not None and armature.type == "ARMATURE":
        bc = armature.data.collections_all.get(part)
        if bc is not None:
            bone_names = [b.name for b in bc.bones]

    if c is not None and delete_meshes:
        for o in list(c.objects):
            report["objects"] += 1
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.data.collections.remove(c)

    if bone_names and armature is not None:
        view = bpy.context.view_layer
        prev_active = view.objects.active
        prev_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
        try:
            if bpy.context.object and bpy.context.object.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            view.objects.active = armature
            bpy.ops.object.mode_set(mode="EDIT")
            for n in bone_names:
                eb = armature.data.edit_bones.get(n)
                if eb is not None:
                    armature.data.edit_bones.remove(eb)
                    report["bones"] += 1
        finally:
            if bpy.context.object and bpy.context.object.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            view.objects.active = prev_active
            if prev_active is not None and prev_mode != "OBJECT":
                try:
                    bpy.ops.object.mode_set(mode=prev_mode)
                except RuntimeError:
                    pass
        bc = armature.data.collections_all.get(part)
        if bc is not None:
            armature.data.collections.remove(bc)

    # A deleted part's bones leave dead vertex groups on every mesh that is left.
    if bone_names:
        dead = set(bone_names)
        for o in bpy.data.objects:
            if o.type != "MESH":
                continue
            for vg in list(o.vertex_groups):
                if vg.name in dead:
                    o.vertex_groups.remove(vg)
                    report["vertex_groups"] += 1
    return report, ""


def enforce_single_home(marker=DEFAULT_MARKER, armature=None):
    """Give every part mesh exactly one collection: its own. ``(report, error)``.

    Auto-Rig Pro's bind links what it binds into the rig's own collection, and
    its ``parent_bound_objects`` preference defaults on. That second link is what
    breaks a costume: hiding a collection hides what it holds only through that
    collection, so a mesh linked in two places stays visible when its own part is
    hidden -- measured on the reference character, the body mesh sat in both its
    part and the rig's collection and hiding the body did nothing at all. Binding
    reintroduces the problem every time, so fixing it is a step of the bind rather
    than a one-off repair.
    """
    parts, err = discover_parts(marker=marker, armature=armature)
    if parts is None:
        return None, err
    report = {"marker": marker, "fixed": []}
    for part in parts:
        home = bpy.data.collections.get(part["collection"])
        if home is None:
            continue
        for obj in list(home.objects):
            extra = [c for c in obj.users_collection if c is not home]
            if not extra:
                continue
            for collection in extra:
                collection.objects.unlink(obj)
            report["fixed"].append({"object": obj.name,
                                    "part": part["collection"],
                                    "unlinked_from": [c.name for c in extra]})
    return report, ""


def audit(armature=None, marker=DEFAULT_MARKER, parent=PARENT_COLLECTION):
    """Which parts exist, which are filed under a bone collection, what is loose."""
    parts, err = discover_parts(marker=marker, armature=armature)
    out = {"marker": marker, "parts": [],
           "skipped": skipped_collections(marker, armature=armature),
           "loose_bones": 0, "issues": []}
    shared, _shared_err = shared_meshes(marker=marker, armature=armature)
    out["shared_meshes"] = shared
    if shared:
        out["issues"].append(
            "%d meshes are linked outside their own part, so hiding the part "
            "will not hide them" % len(shared))
    if parts is None:
        out["issues"].append(err)
        return out
    filed = {}
    if armature is not None and armature.type == "ARMATURE":
        for bc in armature.data.collections_all:
            filed[bc.name] = len(bc.bones)
        loose = [b.name for b in armature.data.bones if not b.collections]
        out["loose_bones"] = len(loose)
        out["loose_sample"] = sorted(loose)[:8]
        if loose:
            out["issues"].append(
                "%d bones belong to no bone collection, so they cannot be hidden "
                "or removed as part of anything" % len(loose))
    for p in parts:
        out["parts"].append({
            "collection": p["collection"], "objects": p["n_objects"],
            "verts": p["verts"],
            "bone_collection": p["collection"] in filed,
            "bones": filed.get(p["collection"], 0)})
    return out
