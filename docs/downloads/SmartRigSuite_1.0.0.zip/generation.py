# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Process-stable ownership registry for Smart Rig Suite.

The authoritative lifecycle state is deliberately stored outside package module
namespaces.  Re-executing or removing a child module therefore cannot discard
the exact Python identities Blender registered on the C/RNA side.
"""

from __future__ import annotations

import builtins
import sys
import uuid
from collections.abc import MutableMapping
from typing import Any, Iterable

import bpy

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

CODE_REVISION = __srs_revision__
OWNER_ID = "smart_rig_suite"
REGISTRY_SCHEMA = 3
DRIVER_NAMESPACE_KEY = "_JELARARAGI_SMART_RIG_SUITE_GENERATION_REGISTRY_V3"
BUILTINS_SLOT = "_JELARARAGI_SMART_RIG_SUITE_GENERATION_REGISTRY_V3"
HISTORY_LIMIT = 4


class GenerationError(RuntimeError):
    """Base error for an unsafe generation transition."""


class RegistryUnavailable(GenerationError):
    """Raised when the external ownership slots cannot be trusted."""


class RestartRequired(GenerationError):
    """Raised when old live RNA/resources prevent a safe in-process update."""


def _new_registry() -> dict[str, Any]:
    return {
        "schema": REGISTRY_SCHEMA,
        "owner": OWNER_ID,
        "active": None,
        "history": [],
        "restart_required": False,
        "restart_reason": "",
        "blocked_revision": "",
        "clean_shutdown": None,
        "clean_shutdown_identities": None,
    }


def _valid_registry(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("schema") == REGISTRY_SCHEMA
        and value.get("owner") == OWNER_ID
        and isinstance(value.get("history"), list)
    )


def _driver_mapping() -> MutableMapping[str, Any]:
    try:
        namespace = bpy.app.driver_namespace
    except Exception as exc:
        raise RegistryUnavailable(f"bpy.app.driver_namespace is unavailable: {exc}") from exc
    if not isinstance(namespace, MutableMapping):
        raise RegistryUnavailable("bpy.app.driver_namespace is not a mutable mapping")
    return namespace


def _builtins_registry() -> Any:
    try:
        return getattr(builtins, BUILTINS_SLOT, None)
    except Exception:
        return None


def get_registry(*, create: bool = True, for_cleanup: bool = False) -> dict[str, Any]:
    """Return the process registry, validating both external ownership slots.

    Registration requires a healthy driver namespace.  Cleanup may fall back to
    the matching builtins slot so a corrupted driver namespace cannot strand RNA.
    """

    builtins_value = _builtins_registry()
    try:
        namespace = _driver_mapping()
    except RegistryUnavailable:
        if for_cleanup and _valid_registry(builtins_value):
            return builtins_value
        raise

    driver_value = namespace.get(DRIVER_NAMESPACE_KEY)
    if driver_value is not None and not _valid_registry(driver_value):
        if for_cleanup and _valid_registry(builtins_value):
            return builtins_value
        raise RegistryUnavailable("Smart Rig Suite driver-namespace registry is malformed")
    if builtins_value is not None and not _valid_registry(builtins_value):
        raise RegistryUnavailable("Smart Rig Suite builtins ownership registry is malformed")

    if _valid_registry(driver_value) and _valid_registry(builtins_value):
        if driver_value is not builtins_value:
            if for_cleanup:
                driver_active = bool(driver_value.get("active"))
                builtins_active = bool(builtins_value.get("active"))
                if builtins_active and not driver_active:
                    return builtins_value
                if driver_active and not builtins_active:
                    return driver_value
            raise RegistryUnavailable("Smart Rig Suite ownership slots disagree")
        return driver_value

    if _valid_registry(driver_value):
        try:
            setattr(builtins, BUILTINS_SLOT, driver_value)
        except Exception as exc:
            if not for_cleanup:
                raise RegistryUnavailable(f"cannot bind the builtins ownership slot: {exc}") from exc
        return driver_value

    if _valid_registry(builtins_value):
        try:
            namespace[DRIVER_NAMESPACE_KEY] = builtins_value
        except Exception as exc:
            if not for_cleanup:
                raise RegistryUnavailable(f"cannot repair the driver ownership slot: {exc}") from exc
        return builtins_value

    if not create:
        raise RegistryUnavailable("Smart Rig Suite ownership registry does not exist")

    registry = _new_registry()
    try:
        namespace[DRIVER_NAMESPACE_KEY] = registry
        setattr(builtins, BUILTINS_SLOT, registry)
    except Exception as exc:
        try:
            if namespace.get(DRIVER_NAMESPACE_KEY) is registry:
                del namespace[DRIVER_NAMESPACE_KEY]
        except Exception:
            pass
        raise RegistryUnavailable(f"cannot create process ownership registry: {exc}") from exc
    return registry


def mark_restart_required(reason: str, *, revision: str = CODE_REVISION) -> None:
    text = str(reason or "A clean Blender restart is required.")
    try:
        registry = get_registry(create=True, for_cleanup=True)
    except Exception:
        return
    registry["restart_required"] = True
    registry["restart_reason"] = text
    registry["blocked_revision"] = str(revision)
    active = registry.get("active")
    if isinstance(active, dict):
        active["restart_required"] = True
        active["restart_reason"] = text
        if active.get("state") not in {"active", "registering", "unregistering"}:
            active["state"] = "blocked"


def clear_restart_required() -> None:
    registry = get_registry(create=True)
    registry["restart_required"] = False
    registry["restart_reason"] = ""
    registry["blocked_revision"] = ""


def _new_active(package: str, revision: str, token: str, control_module: Any) -> dict[str, Any]:
    return {
        "token": token,
        "revision": str(revision),
        "package": str(package),
        "state": "registering",
        "restart_required": False,
        "restart_reason": "",
        "control_module": control_module,
        "modules": {},
        "classes": [],
        "pointer_properties": [],
        "handlers": [],
        "timers": [],
        "msgbus_owners": [],
        "keymaps": [],
        "patches": [],
        "translations": [],
        "cleanups": [],
        "errors": [],
    }


def active_generation(*, for_cleanup: bool = False) -> dict[str, Any] | None:
    try:
        registry = get_registry(create=False, for_cleanup=for_cleanup)
    except Exception:
        return None
    active = registry.get("active")
    return active if isinstance(active, dict) else None


def active_token(*, revision: str | None = None, for_cleanup: bool = False) -> str:
    active = active_generation(for_cleanup=for_cleanup)
    if not active:
        raise GenerationError("Smart Rig Suite has no active generation")
    if revision is not None and str(active.get("revision")) != str(revision):
        raise RestartRequired(
            f"loaded generation {active.get('revision')} does not match code revision {revision}"
        )
    token = str(active.get("token") or "")
    if not token:
        raise RegistryUnavailable("active generation token is missing")
    return token


def _record_is_live(record: dict[str, Any]) -> bool:
    kind = record.get("resource_kind")
    if kind == "class":
        cls = record.get("identity")
        name = str(record.get("name") or getattr(cls, "__name__", ""))
        try:
            current = getattr(bpy.types, name, None)
        except Exception:
            current = None
        if current is cls:
            return True
        try:
            return bool(getattr(cls, "is_registered", False))
        except Exception:
            return False
    if kind == "pointer_property":
        host = record.get("host")
        name = str(record.get("name") or "")
        try:
            return bool(host is not None and name and hasattr(host, name))
        except Exception:
            return bool(record.get("state") == "registered")
    if kind == "handler":
        collection = record.get("collection")
        callback = record.get("identity")
        try:
            for item in tuple(collection):
                if item is callback:
                    return True
                if getattr(item, "_jelararagi_status_original_v2", None) is callback:
                    return True
                if getattr(item, "_jelararagi_status_original_v3", None) is callback:
                    return True
            return False
        except Exception:
            return bool(record.get("state") == "registered")
    if kind == "timer":
        callback = record.get("identity")
        try:
            return bool(bpy.app.timers.is_registered(callback))
        except Exception:
            return bool(record.get("state") == "registered")
    if kind == "patch":
        replacement = record.get("replacement")
        collection = record.get("collection")
        module = record.get("target_module")
        attribute = str(record.get("attribute") or "")
        try:
            if collection is not None and any(item is replacement for item in tuple(collection)):
                return True
        except Exception:
            pass
        try:
            return bool(module is not None and attribute and getattr(module, attribute, None) is replacement)
        except Exception:
            return bool(record.get("state") == "registered")
    if kind in {"msgbus_owner", "keymap", "translation", "cleanup"}:
        return bool(record.get("state") == "registered")
    return bool(record.get("state") == "registered")


def live_resource_summary(active: dict[str, Any] | None = None) -> dict[str, int]:
    generation = active or active_generation(for_cleanup=True)
    counts = {
        "classes": 0,
        "panels": 0,
        "property_groups": 0,
        "pointer_properties": 0,
        "handlers": 0,
        "timers": 0,
        "msgbus_owners": 0,
        "keymaps": 0,
        "patches": 0,
        "translations": 0,
    }
    if not generation:
        return counts
    for record in generation.get("classes", ()):
        if not isinstance(record, dict) or not _record_is_live(record):
            continue
        counts["classes"] += 1
        class_kind = record.get("class_kind")
        if class_kind == "Panel":
            counts["panels"] += 1
        elif class_kind == "PropertyGroup":
            counts["property_groups"] += 1
    mapping = (
        ("pointer_properties", "pointer_properties"),
        ("handlers", "handlers"),
        ("timers", "timers"),
        ("msgbus_owners", "msgbus_owners"),
        ("keymaps", "keymaps"),
        ("patches", "patches"),
        ("translations", "translations"),
    )
    for list_name, count_name in mapping:
        counts[count_name] = sum(
            1 for record in generation.get(list_name, ())
            if isinstance(record, dict) and _record_is_live(record)
        )
    return counts


def has_live_resources(active: dict[str, Any] | None = None) -> bool:
    return any(live_resource_summary(active).values())


def _archive_active(registry: dict[str, Any], active: dict[str, Any], final_state: str) -> None:
    # Keep a serialisable summary for diagnostics and an exact-reference contract
    # in a separate external slot.  Integer ``id`` values alone are not proof of
    # identity after garbage collection, whereas retained object references make
    # the clean-shutdown transition unambiguous.
    module_contract = {
        str(name): {
            "module_identity_id": id(record.get("module")) if isinstance(record, dict) and record.get("module") is not None else 0,
            "marker_identity_id": id(record.get("marker")) if isinstance(record, dict) and record.get("marker") is not None else 0,
            "revision": str(record.get("revision") or "") if isinstance(record, dict) else "",
            "token": str(record.get("token") or "") if isinstance(record, dict) else "",
            "registered": bool(record.get("registered")) if isinstance(record, dict) else False,
        }
        for name, record in tuple(active.get("modules", {}).items())
    }
    exact_module_contract = {
        str(name): {
            "module": record.get("module") if isinstance(record, dict) else None,
            "marker": record.get("marker") if isinstance(record, dict) else None,
            "revision": str(record.get("revision") or "") if isinstance(record, dict) else "",
            "token": str(record.get("token") or "") if isinstance(record, dict) else "",
            "registered": bool(record.get("registered")) if isinstance(record, dict) else False,
        }
        for name, record in tuple(active.get("modules", {}).items())
    }
    live = live_resource_summary(active)
    summary = {
        "token": str(active.get("token") or ""),
        "revision": str(active.get("revision") or ""),
        "state": str(final_state),
        "restart_required": bool(active.get("restart_required")),
        "restart_reason": str(active.get("restart_reason") or ""),
        "errors": tuple(str(item) for item in active.get("errors", ())[-16:]),
        "live": dict(live),
        "modules": module_contract,
    }
    history = registry.setdefault("history", [])
    history.append(summary)
    del history[:-HISTORY_LIMIT]
    if str(final_state) == "inactive" and not any(live.values()):
        registry["clean_shutdown"] = {
            "token": summary["token"],
            "revision": summary["revision"],
            "state": "inactive",
            "live": dict(live),
            "modules": module_contract,
        }
        registry["clean_shutdown_identities"] = {
            "token": summary["token"],
            "revision": summary["revision"],
            "state": "inactive",
            "modules": exact_module_contract,
        }
    else:
        registry["clean_shutdown"] = None
        registry["clean_shutdown_identities"] = None
    registry["active"] = None


def begin_generation(package: str, revision: str, *, control_module: Any) -> dict[str, Any]:
    registry = get_registry(create=True)
    active = registry.get("active")
    if isinstance(active, dict):
        live = has_live_resources(active)
        if live:
            if str(active.get("revision")) == str(revision) and active.get("state") == "active":
                return {"status": "already_active", "token": str(active.get("token") or "")}
            reason = (
                f"live Smart Rig Suite generation {active.get('revision')} still owns Blender resources; "
                f"code revision {revision} was not mixed into the process"
            )
            mark_restart_required(reason, revision=revision)
            return {"status": "restart_required", "reason": reason, "token": ""}
        _archive_active(registry, active, "inactive")

    token = f"{revision}:{uuid.uuid4().hex}"
    # A new generation supersedes the preceding clean-shutdown proof.  Clear its
    # retained module references only after the root has used them for revision
    # preflight and discarded the proven-clean old sys.modules entries.
    registry["clean_shutdown"] = None
    registry["clean_shutdown_identities"] = None
    registry["active"] = _new_active(package, revision, token, control_module)
    clear_restart_required()
    return {"status": "started", "token": token}


def finish_generation(token: str) -> None:
    active = active_generation()
    if not active or str(active.get("token")) != str(token):
        raise GenerationError("generation token changed before registration completed")
    active["state"] = "active"


def set_generation_state(token: str, state: str, *, reason: str = "") -> None:
    active = active_generation(for_cleanup=True)
    if not active or str(active.get("token")) != str(token):
        return
    active["state"] = str(state)
    if reason:
        active["errors"].append(str(reason))


def bind_module(module_name: str, module: Any, revision: str, marker: Any) -> None:
    active = active_generation()
    if not active:
        raise GenerationError("cannot bind a module without an active generation")
    if str(active.get("revision")) != str(revision):
        raise RestartRequired(
            f"module {module_name} revision {revision} does not match active revision {active.get('revision')}"
        )
    token = str(active.get("token") or "")
    modules = active.setdefault("modules", {})
    existing = modules.get(str(module_name))
    if isinstance(existing, dict):
        if existing.get("module") is not module or existing.get("marker") is not marker:
            raise RestartRequired(
                f"module {module_name} was re-executed or re-imported while generation {token} is live"
            )
        return
    modules[str(module_name)] = {
        "module": module,
        "marker": marker,
        "revision": str(revision),
        "token": token,
        "registered": False,
    }


def assert_module_context(module_name: str, revision: str, marker: Any) -> str:
    token = active_token(revision=revision)
    active = active_generation()
    assert active is not None
    if active.get("state") not in {"registering", "active"}:
        raise GenerationError(f"generation is not registerable in state {active.get('state')}")
    record = active.get("modules", {}).get(str(module_name))
    if not isinstance(record, dict):
        raise RestartRequired(f"module {module_name} was not bound by the root registration transaction")
    current_module = sys.modules.get(str(module_name))
    if record.get("marker") is not marker or record.get("module") is not current_module:
        raise RestartRequired(f"module {module_name} identity changed after binding")
    if str(record.get("revision")) != str(revision) or str(record.get("token")) != token:
        raise RestartRequired(f"module {module_name} ownership contract changed")
    return token


def module_is_registered(module_name: str, *, marker: Any | None = None) -> bool:
    active = active_generation(for_cleanup=True)
    if not active:
        return False
    record = active.get("modules", {}).get(str(module_name))
    if not isinstance(record, dict) or not bool(record.get("registered")):
        return False
    if marker is not None and record.get("marker") is not marker:
        return False
    return True


def mark_module_registered(module_name: str, registered: bool) -> None:
    active = active_generation(for_cleanup=True)
    if not active:
        return
    record = active.get("modules", {}).get(str(module_name))
    if isinstance(record, dict):
        record["registered"] = bool(registered)


def _class_kind(cls: type) -> str:
    checks = (
        ("Panel", getattr(bpy.types, "Panel", None)),
        ("Operator", getattr(bpy.types, "Operator", None)),
        ("PropertyGroup", getattr(bpy.types, "PropertyGroup", None)),
        ("AddonPreferences", getattr(bpy.types, "AddonPreferences", None)),
        ("Menu", getattr(bpy.types, "Menu", None)),
        ("UIList", getattr(bpy.types, "UIList", None)),
        ("GizmoGroup", getattr(bpy.types, "GizmoGroup", None)),
        ("Gizmo", getattr(bpy.types, "Gizmo", None)),
    )
    for label, base in checks:
        if not isinstance(base, type):
            continue
        try:
            if issubclass(cls, base):
                return label
        except Exception:
            continue
    return "RNAClass"


def track_class(cls: type, *, module_name: str, revision: str, marker: Any) -> dict[str, Any]:
    token = assert_module_context(module_name, revision, marker)
    active = active_generation()
    assert active is not None
    for record in active.get("classes", ()):
        if isinstance(record, dict) and record.get("identity") is cls:
            return record
    try:
        setattr(cls, "__srs_generation_token__", token)
        setattr(cls, "__srs_code_revision__", str(revision))
    except Exception:
        pass
    record = {
        "resource_kind": "class",
        "identity": cls,
        "identity_id": id(cls),
        "name": str(getattr(cls, "__name__", "")),
        "module": str(module_name),
        "class_kind": _class_kind(cls),
        "token": token,
        "revision": str(revision),
        "state": "registered",
        "errors": [],
    }
    active["classes"].append(record)
    return record


def forget_class(cls: type) -> None:
    active = active_generation(for_cleanup=True)
    if not active:
        return
    active["classes"][:] = [
        record for record in active.get("classes", ())
        if not isinstance(record, dict) or record.get("identity") is not cls
    ]


def class_records(
    *, module_name: str | None = None, kinds: Iterable[str] | None = None
) -> list[dict[str, Any]]:
    active = active_generation(for_cleanup=True)
    if not active:
        return []
    allowed = set(kinds) if kinds is not None else None
    result = []
    for record in active.get("classes", ()):
        if not isinstance(record, dict):
            continue
        if module_name is not None and str(record.get("module")) != str(module_name):
            continue
        if allowed is not None and str(record.get("class_kind")) not in allowed:
            continue
        result.append(record)
    return result


def _registered_identity(cls: type) -> type | None:
    name = str(getattr(cls, "__name__", "") or "")
    if name:
        try:
            current = getattr(bpy.types, name, None)
        except Exception:
            current = None
        if isinstance(current, type):
            return current
    try:
        if bool(getattr(cls, "is_registered", False)):
            return cls
    except Exception:
        pass
    return None


def unregister_class_record(record: dict[str, Any], *, attempts: int = 1) -> dict[str, Any]:
    cls = record.get("identity")
    name = str(record.get("name") or getattr(cls, "__name__", ""))
    result = {
        "name": name,
        "kind": str(record.get("class_kind") or "RNAClass"),
        "identity_id": int(record.get("identity_id") or id(cls)),
        "status": "unknown",
        "attempts": 0,
        "remaining": False,
        "errors": [],
    }
    current = _registered_identity(cls)
    if current is None:
        result["status"] = "absent"
        record["state"] = "absent"
        return result
    if current is not cls:
        result["status"] = "identity_mismatch"
        result["remaining"] = True
        result["current_identity_id"] = id(current)
        record["state"] = "identity_mismatch"
        return result

    for _index in range(max(1, int(attempts))):
        result["attempts"] += 1
        try:
            bpy.utils.unregister_class(cls)
        except Exception as exc:
            result["errors"].append(f"{type(exc).__name__}: {exc}")
        current = _registered_identity(cls)
        if current is None:
            result["status"] = "removed"
            record["state"] = "removed"
            record["errors"] = list(result["errors"])
            return result
        if current is not cls:
            result["status"] = "identity_mismatch"
            result["remaining"] = True
            result["current_identity_id"] = id(current)
            record["state"] = "identity_mismatch"
            record["errors"] = list(result["errors"])
            return result

    result["status"] = "error"
    result["remaining"] = True
    record["state"] = "error"
    record["errors"] = list(result["errors"])
    return result


def unregister_class_records(
    *, module_name: str | None = None, kinds: Iterable[str] | None = None, attempts: int = 1
) -> dict[str, Any]:
    records = class_records(module_name=module_name, kinds=kinds)
    results = [unregister_class_record(record, attempts=attempts) for record in reversed(records)]
    remaining = [item for item in results if bool(item.get("remaining"))]
    return {
        "results": results,
        "removed": sum(item.get("status") == "removed" for item in results),
        "absent": sum(item.get("status") == "absent" for item in results),
        "identity_mismatches": sum(item.get("status") == "identity_mismatch" for item in results),
        "errors": [error for item in results for error in item.get("errors", ())],
        "remaining": remaining,
        "all_removed": not remaining,
    }


def _rna_fixed_type_identifier(host: Any, name: str) -> str:
    try:
        prop = host.bl_rna.properties.get(name)
    except Exception:
        prop = None
    if prop is None:
        try:
            prop = next(
                (item for item in host.bl_rna.properties if str(getattr(item, "identifier", "")) == name),
                None,
            )
        except Exception:
            prop = None
    try:
        return str(getattr(getattr(prop, "fixed_type", None), "identifier", "") or "")
    except Exception:
        return ""


def _class_rna_identifier(cls: type) -> str:
    try:
        return str(getattr(getattr(cls, "bl_rna", None), "identifier", "") or cls.__name__)
    except Exception:
        return str(getattr(cls, "__name__", "") or "")


def track_pointer_property(
    host: Any,
    name: str,
    property_group_cls: type,
    *,
    module_name: str,
    revision: str,
    marker: Any,
) -> dict[str, Any]:
    token = assert_module_context(module_name, revision, marker)
    active = active_generation()
    assert active is not None
    for record in active.get("pointer_properties", ()):
        if (
            isinstance(record, dict)
            and record.get("host") is host
            and str(record.get("name")) == str(name)
        ):
            if record.get("property_group_cls") is not property_group_cls:
                raise RestartRequired(f"{host}.{name} ownership identity changed")
            return record
    record = {
        "resource_kind": "pointer_property",
        "host": host,
        "host_identity_id": id(host),
        "name": str(name),
        "property_group_cls": property_group_cls,
        "property_group_identity_id": id(property_group_cls),
        "expected_identifier": _class_rna_identifier(property_group_cls),
        "module": str(module_name),
        "token": token,
        "revision": str(revision),
        "state": "registered",
        "errors": [],
    }
    active["pointer_properties"].append(record)
    return record


def pointer_record_owned(record: dict[str, Any]) -> bool:
    active = active_generation(for_cleanup=True)
    if not active:
        return False
    if str(record.get("token")) != str(active.get("token")):
        return False
    cls = record.get("property_group_cls")
    name = str(record.get("name") or "")
    host = record.get("host")
    if cls is None or host is None or not name:
        return False
    if _registered_identity(cls) is not cls:
        return False
    try:
        if not hasattr(host, name):
            return False
    except Exception:
        return False
    expected = str(record.get("expected_identifier") or _class_rna_identifier(cls))
    actual = _rna_fixed_type_identifier(host, name)
    return bool(expected and actual and expected == actual)


def unregister_pointer_records(*, module_name: str | None = None) -> dict[str, Any]:
    active = active_generation(for_cleanup=True)
    records = [] if not active else list(active.get("pointer_properties", ()))
    if module_name is not None:
        records = [record for record in records if str(record.get("module")) == str(module_name)]
    results: list[dict[str, Any]] = []
    for record in reversed(records):
        item = {
            "name": str(record.get("name") or ""),
            "status": "unknown",
            "remaining": False,
            "errors": [],
        }
        host = record.get("host")
        name = str(record.get("name") or "")
        try:
            exists = bool(host is not None and name and hasattr(host, name))
        except Exception:
            exists = True
        if not exists:
            item["status"] = "absent"
            record["state"] = "absent"
            results.append(item)
            continue
        if not pointer_record_owned(record):
            item["status"] = "identity_mismatch"
            item["remaining"] = True
            record["state"] = "identity_mismatch"
            results.append(item)
            continue
        try:
            delattr(host, name)
        except Exception as exc:
            item["status"] = "error"
            item["remaining"] = True
            item["errors"].append(f"{type(exc).__name__}: {exc}")
            record["state"] = "error"
            results.append(item)
            continue
        try:
            still_exists = hasattr(host, name)
        except Exception:
            still_exists = True
        if still_exists:
            item["status"] = "error"
            item["remaining"] = True
            item["errors"].append("property still exists after deletion")
            record["state"] = "error"
        else:
            item["status"] = "removed"
            record["state"] = "removed"
        results.append(item)
    remaining = [item for item in results if bool(item.get("remaining"))]
    return {
        "results": results,
        "removed": sum(item.get("status") == "removed" for item in results),
        "absent": sum(item.get("status") == "absent" for item in results),
        "identity_mismatches": sum(item.get("status") == "identity_mismatch" for item in results),
        "errors": [error for item in results for error in item.get("errors", ())],
        "remaining": remaining,
        "all_removed": not remaining,
    }


def _track_record(list_name: str, record: dict[str, Any]) -> dict[str, Any]:
    active = active_generation()
    if not active:
        raise GenerationError(f"cannot track {list_name} without an active generation")
    record.setdefault("token", str(active.get("token") or ""))
    record.setdefault("revision", str(active.get("revision") or ""))
    record.setdefault("state", "registered")
    target = active.setdefault(list_name, [])
    target.append(record)
    return record


def _find_identity_record(list_name: str, identity: Any, *, module_name: str = "") -> dict[str, Any] | None:
    active = active_generation(for_cleanup=True)
    if not active:
        return None
    for record in active.get(list_name, ()):
        if not isinstance(record, dict):
            continue
        if record.get("identity") is not identity:
            continue
        if module_name and str(record.get("module")) != str(module_name):
            continue
        return record
    return None


def track_handler(collection: Any, callback: Any, *, module_name: str, label: str) -> None:
    if _find_identity_record("handlers", callback, module_name=module_name):
        return
    _track_record("handlers", {
        "resource_kind": "handler",
        "collection": collection,
        "collection_identity_id": id(collection),
        "identity": callback,
        "identity_id": id(callback),
        "module": str(module_name),
        "label": str(label),
    })


def untrack_handler(callback: Any, *, module_name: str = "") -> None:
    record = _find_identity_record("handlers", callback, module_name=module_name)
    if record is not None:
        record["state"] = "removed"


def track_timer(callback: Any, *, module_name: str) -> None:
    if _find_identity_record("timers", callback, module_name=module_name):
        return
    _track_record("timers", {
        "resource_kind": "timer",
        "identity": callback,
        "identity_id": id(callback),
        "module": str(module_name),
    })


def untrack_timer(callback: Any, *, module_name: str = "") -> None:
    record = _find_identity_record("timers", callback, module_name=module_name)
    if record is not None:
        record["state"] = "removed"


def track_msgbus_owner(owner: Any, *, module_name: str) -> None:
    if _find_identity_record("msgbus_owners", owner, module_name=module_name):
        return
    _track_record("msgbus_owners", {
        "resource_kind": "msgbus_owner",
        "identity": owner,
        "identity_id": id(owner),
        "module": str(module_name),
    })


def untrack_msgbus_owner(owner: Any, *, module_name: str = "") -> None:
    record = _find_identity_record("msgbus_owners", owner, module_name=module_name)
    if record is not None:
        record["state"] = "removed"


def track_keymap(keymap: Any, keymap_item: Any, *, module_name: str) -> None:
    _track_record("keymaps", {
        "resource_kind": "keymap",
        "keymap": keymap,
        "identity": keymap_item,
        "identity_id": id(keymap_item),
        "module": str(module_name),
    })


def track_patch(
    *,
    collection: Any,
    original: Any,
    replacement: Any,
    target_module: Any,
    attribute: str,
    module_name: str,
) -> None:
    if _find_identity_record("patches", replacement, module_name=module_name):
        return
    _track_record("patches", {
        "resource_kind": "patch",
        "collection": collection,
        "original": original,
        "replacement": replacement,
        "identity": replacement,
        "identity_id": id(replacement),
        "target_module": target_module,
        "attribute": str(attribute),
        "module": str(module_name),
    })


def untrack_patch(replacement: Any, *, module_name: str = "") -> None:
    record = _find_identity_record("patches", replacement, module_name=module_name)
    if record is not None:
        record["state"] = "removed"


def track_translation(domain: str, *, module_name: str) -> None:
    active = active_generation()
    if not active:
        raise GenerationError("cannot track a translation without an active generation")
    for record in active.get("translations", ()):
        if isinstance(record, dict) and str(record.get("domain")) == str(domain):
            record["state"] = "registered"
            return
    _track_record("translations", {
        "resource_kind": "translation",
        "domain": str(domain),
        "module": str(module_name),
    })


def untrack_translation(domain: str, *, module_name: str = "") -> None:
    active = active_generation(for_cleanup=True)
    if not active:
        return
    for record in active.get("translations", ()):
        if not isinstance(record, dict) or str(record.get("domain")) != str(domain):
            continue
        if module_name and str(record.get("module")) != str(module_name):
            continue
        record["state"] = "removed"


def track_cleanup(callback: Any, *, module_name: str, label: str) -> None:
    if _find_identity_record("cleanups", callback, module_name=module_name):
        return
    _track_record("cleanups", {
        "resource_kind": "cleanup",
        "identity": callback,
        "identity_id": id(callback),
        "module": str(module_name),
        "label": str(label),
    })


def _cleanup_record(record: dict[str, Any]) -> tuple[str, list[str]]:
    kind = str(record.get("resource_kind") or "")
    errors: list[str] = []
    try:
        if kind == "patch":
            replacement = record.get("replacement")
            original = record.get("original")
            collection = record.get("collection")
            try:
                for index, current in enumerate(tuple(collection)):
                    if current is replacement:
                        collection[index] = original
            except Exception as exc:
                errors.append(f"collection restore: {type(exc).__name__}: {exc}")
            module = record.get("target_module")
            attribute = str(record.get("attribute") or "")
            try:
                if module is not None and attribute and getattr(module, attribute, None) is replacement:
                    setattr(module, attribute, original)
            except Exception as exc:
                errors.append(f"module restore: {type(exc).__name__}: {exc}")
            if _record_is_live(record):
                return "error", errors or ["patch replacement is still live"]
            return "removed", errors
        if kind == "timer":
            callback = record.get("identity")
            try:
                if bpy.app.timers.is_registered(callback):
                    bpy.app.timers.unregister(callback)
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
            try:
                if bpy.app.timers.is_registered(callback):
                    return "error", errors or ["timer remains registered"]
            except Exception:
                if errors:
                    return "error", errors
            return "removed", errors
        if kind == "handler":
            collection = record.get("collection")
            callback = record.get("identity")

            def _belongs(item: Any) -> bool:
                if item is callback:
                    return True
                try:
                    if getattr(item, "_jelararagi_status_original_v2", None) is callback:
                        return True
                    if getattr(item, "_jelararagi_status_original_v3", None) is callback:
                        return True
                except Exception:
                    pass
                return False

            try:
                while any(_belongs(item) for item in tuple(collection)):
                    for item in tuple(collection):
                        if _belongs(item):
                            collection.remove(item)
                            break
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
            try:
                if any(_belongs(item) for item in tuple(collection)):
                    return "error", errors or ["handler or status wrapper remains registered"]
            except Exception:
                if errors:
                    return "error", errors
            return "removed", errors
        if kind == "msgbus_owner":
            owner = record.get("identity")
            try:
                bpy.msgbus.clear_by_owner(owner)
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
                return "error", errors
            return "removed", errors
        if kind == "keymap":
            keymap = record.get("keymap")
            item = record.get("identity")
            try:
                keymap.keymap_items.remove(item)
            except Exception as exc:
                text = str(exc).lower()
                if "not found" not in text and "removed" not in text:
                    errors.append(f"{type(exc).__name__}: {exc}")
            return ("error" if errors else "removed"), errors
        if kind == "translation":
            domain = str(record.get("domain") or "")
            try:
                bpy.app.translations.unregister(domain)
            except Exception as exc:
                text = str(exc).lower()
                if "not registered" not in text:
                    errors.append(f"{type(exc).__name__}: {exc}")
            return ("error" if errors else "removed"), errors
        if kind == "cleanup":
            callback = record.get("identity")
            try:
                callback()
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {exc}")
                return "error", errors
            return "removed", errors
    except Exception as exc:
        return "error", [f"{type(exc).__name__}: {exc}"]
    return "absent", errors


def cleanup_non_ui_resources(*, token: str | None = None, module_name: str | None = None) -> dict[str, Any]:
    active = active_generation(for_cleanup=True)
    if not active:
        return {"results": [], "errors": [], "remaining": [], "all_removed": True}
    if token is not None and str(active.get("token")) != str(token):
        return {
            "results": [],
            "errors": ["generation token mismatch during cleanup"],
            "remaining": [],
            "all_removed": False,
        }
    results: list[dict[str, Any]] = []
    # Restore foreign patches before deleting our callbacks; then remove all
    # independently tracked resources. Every failure is isolated.
    for list_name in ("cleanups", "patches", "timers", "handlers", "msgbus_owners", "keymaps", "translations"):
        for record in reversed(tuple(active.get(list_name, ()))):
            if not isinstance(record, dict) or record.get("state") != "registered":
                continue
            if module_name is not None and str(record.get("module")) != str(module_name):
                continue
            status, errors = _cleanup_record(record)
            record["state"] = status
            record["errors"] = list(errors)
            results.append({
                "kind": str(record.get("resource_kind") or list_name),
                "module": str(record.get("module") or ""),
                "identity_id": int(record.get("identity_id") or 0),
                "status": status,
                "errors": list(errors),
            })
    remaining = []
    for list_name in ("cleanups", "patches", "timers", "handlers", "msgbus_owners", "keymaps", "translations"):
        for record in active.get(list_name, ()):
            if (
                isinstance(record, dict)
                and (module_name is None or str(record.get("module")) == str(module_name))
                and _record_is_live(record)
            ):
                remaining.append({
                    "kind": str(record.get("resource_kind") or list_name),
                    "module": str(record.get("module") or ""),
                    "identity_id": int(record.get("identity_id") or 0),
                })
    errors = [error for item in results for error in item.get("errors", ())]
    active["errors"].extend(errors)
    return {"results": results, "errors": errors, "remaining": remaining, "all_removed": not remaining}


def finalize_unregistration(token: str, *, reports: Iterable[dict[str, Any]] = ()) -> dict[str, Any]:
    registry = get_registry(create=False, for_cleanup=True)
    active = registry.get("active")
    if not isinstance(active, dict) or str(active.get("token")) != str(token):
        return {"finalized": False, "restart_required": True, "reason": "generation token changed"}
    unresolved: list[dict[str, Any]] = []
    for report in reports:
        if not isinstance(report, dict):
            continue
        active["errors"].extend(str(item) for item in report.get("errors", ()))
        if report.get("all_removed") is False:
            unresolved.append({
                "remaining": list(report.get("remaining", ())),
                "protected": bool(report.get("protected")),
            })
    live = live_resource_summary(active)
    if any(live.values()) or unresolved:
        reason = f"Smart Rig Suite teardown is incomplete: live={live}, unresolved={unresolved}"
        active["state"] = "deferred"
        active["restart_required"] = True
        active["restart_reason"] = reason
        registry["restart_required"] = True
        registry["restart_reason"] = reason
        registry["blocked_revision"] = str(active.get("revision") or "")
        registry["clean_shutdown"] = None
        registry["clean_shutdown_identities"] = None
        return {
            "finalized": False,
            "restart_required": True,
            "reason": reason,
            "live": live,
            "unresolved": unresolved,
        }
    for record in active.get("modules", {}).values():
        if isinstance(record, dict):
            record["registered"] = False
    active["state"] = "inactive"
    _archive_active(registry, active, "inactive")
    registry["restart_required"] = False
    registry["restart_reason"] = ""
    registry["blocked_revision"] = ""
    return {"finalized": True, "restart_required": False, "reason": "", "live": live, "unresolved": []}


def registry_audit_snapshot() -> dict[str, Any]:
    try:
        registry = get_registry(create=False, for_cleanup=True)
    except Exception as exc:
        return {"available": False, "error": f"{type(exc).__name__}: {exc}"}
    active = registry.get("active")
    active_summary = None
    if isinstance(active, dict):
        class_identity_ids = []
        panel_identity_ids = []
        operator_count = 0
        property_group_count = 0
        for item in active.get("classes", ()):
            identity_id = int(item.get("identity_id") or 0)
            class_identity_ids.append(identity_id)
            class_kind = item.get("class_kind")
            if class_kind == "Panel":
                panel_identity_ids.append(identity_id)
            if class_kind == "Operator":
                operator_count += 1
            if class_kind == "PropertyGroup":
                property_group_count += 1
        active_summary = {
            "token": str(active.get("token") or ""),
            "revision": str(active.get("revision") or ""),
            "state": str(active.get("state") or ""),
            "module_count": len(active.get("modules", {})),
            "class_identity_ids": class_identity_ids,
            "panel_identity_ids": panel_identity_ids,
            "operator_count": operator_count,
            "property_group_count": property_group_count,
            "pointer_property_count": len(active.get("pointer_properties", ())),
            "handler_identity_ids": [int(item.get("identity_id") or 0) for item in active.get("handlers", ())],
            "timer_identity_ids": [int(item.get("identity_id") or 0) for item in active.get("timers", ())],
            "live": live_resource_summary(active),
        }
    return {
        "available": True,
        "schema": registry.get("schema"),
        "owner": registry.get("owner"),
        "restart_required": bool(registry.get("restart_required")),
        "restart_reason": str(registry.get("restart_reason") or ""),
        "active": active_summary,
        "history": list(registry.get("history", ())),
        "clean_shutdown": registry.get("clean_shutdown"),
    }
