# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Make the eyelid's cast shadow follow the eyelid.

A stylised eye often carries the lid's shadow as a texture on the eyeball rather
than as real shading: a gradient map, dark at the top, that reads as the shadow
the upper lid throws. Painted into the eyeball's own UVs it is fixed -- the eye
closes and the shadow stays exactly where it was, which is the one moment it
should be moving.

A UV Project modifier solves it. The map is sampled through UVs that the modifier
generates from a projector object each frame, so moving that projector slides the
map across the eyeball. Tie the projector's height to the upper lid and the
shadow travels with the lid, on a mesh that never deforms.

Two things this module measures rather than assumes:

* **How far the lid margin actually travels.** The controller is not the lid: the
  Transformation constraint on this rig turns 8.38mm of controller LOCATION into
  121 degrees of lid ROTATION, so the margin moves much further than the control
  does. The ratio is measured, not guessed, and written into the driver.
* **What the driver variable reads.** A Transform Channel variable in Local Space
  reports the bone's local translation, which is not ``pose_bone.location``
  unless the bone's rest axes happen to line up -- measured elsewhere on this rig,
  24mm of location read back as 21.74mm. So the coefficient is calibrated against
  what the variable actually returns at a known pose.

The projector's SCALE is what sets the map's footprint: an Empty projects its own
local 1x1 area onto UV 0..1, so an Empty at scale 1 would map a whole metre onto
a 22mm eyeball. Its footprint is not guessed: the uv layer already stored on the
mesh IS a planar projection (fitted residual 1e-7 on the reference character), so
the projector is placed to reproduce that layer exactly, mirror included -- the two
eyes share one texture and the right eye's stored mapping is flipped across X.

**The projector follows the head (2.62.33).** Up to 2.62.32 the projector was an
Empty with no parent, standing in the world. The lid moved it up and down, but the
head, neck and body did not: on MIK_193 the head travelled 3.7 m in a take while the
projector moved 11.8 mm, the eyeball left the projection, its UVs ran far outside
0..1 and the sclera rendered black (MIK_194 change notes, 2026-10-17). The projector
is now BONE-parented to the bone the eye socket follows: the bone that is both an
ancestor of the bone carrying the eyeball (by its weights, or its bone parent) and
of the upper-lid control -- ``c_eye_offset.l/.r`` on Auto-Rig Pro. Not the eye bone
itself: that one turns with the gaze, and the shadow belongs to the lid, not to the
pupil. With no lid control the nearest head bone is used.

The world matrix at rest is kept exactly: the rest placement is converted into the
bone's rest frame (the bone's TAIL, which is where a bone parent sits), and the lid
drivers are rewritten so that the projector moves along the SAME world direction by
the SAME amount as before -- in the bone's coordinates, which usually means a small
share on all three location channels. The lid term of an existing driver (for
example one with different coefficients for opening and closing) is kept verbatim.

**Running it again is safe.** An existing projector is read before anything is
written: its rest world matrix (lid at zero, shoe lift taken into account), the lid
term and the driver variables. A projector with no parent (the 2.62.32 / MIK_193
form) is migrated; one already parented (MIK_194, or a previous run) is rebuilt in
the bone's coordinates from its own rest placement, which reproduces it. Anything
the module cannot read -- a constraint, an action, a location driver in a form it
does not know -- refuses before a single value changes.
"""

import json
import math
import re

import bpy
import mathutils
from mathutils import Matrix, Vector

PROJECTOR_PREFIX = "SRS_LidShadow"
STATE_KEY = "srs_lid_shadow_v1"
LID_CONTROL = "c_eyelid_top"
# SmartModifier's transform guard keeps the basis it last saw; left stale it would put the
# projector back at its old world-space basis under the new bone parent.
GUARD_KEY = "_smsm_transform_guard_basis_v1"
HEAD_NAMES = ("head.x", "c_head.x", "head", "Head", "DEF-head", "ORG-head",
              "mixamorig:Head", "J_Bip_C_Head")
EXPRESSION_MAX = 255  # Driver.expression is char[256]
# A component of the lid direction below this (in the parent's units) gets no driver.
AXIS_EPS = 1.0e-7
FOLLOW_TOLERANCE = 1.0e-3   # UV units: the visible defect was 0.7 .. 18.8


def _uv_project(mesh_object):
    for modifier in getattr(mesh_object, "modifiers", ()):
        if modifier.type == "UV_PROJECT":
            return modifier
    return None


def read_state(mesh_object) -> dict:
    """What this module recorded about the eyeball, if anything."""
    if mesh_object is None:
        return {}
    stored = mesh_object.get(STATE_KEY)
    if stored is None:
        return {}
    try:
        return {str(k): stored[k] for k in stored.keys()}
    except Exception:
        return {}


def lid_travel(mesh_object, armature, side, pull_mm=8.38, ring=None):
    """How far the upper lid margin moves, and what the driver will read.

    ``(report, error)``. The margin is the aperture ring's upper half on the face
    -- the vertices the lid actually closes with -- so the answer is the motion a
    viewer sees, not a controller value.
    """
    from . import face_regions

    control = LID_CONTROL + side
    pose_bone = armature.pose.bones.get(control) if armature else None
    if pose_bone is None:
        return None, "%s has no bone %s" % (getattr(armature, "name", "?"), control)
    face = ring if ring is not None else None
    if face is None:
        return None, "Need the face mesh whose aperture ring measures the lid"
    aperture, error = face_regions.aperture_ring(face, armature, side)
    if error:
        return None, error
    upper = aperture.get("upper") or aperture.get("ring")
    if not upper:
        return None, "The aperture ring has no upper margin"

    def margin_height():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = face.evaluated_get(depsgraph)
        matrix = face.matrix_world
        total = 0.0
        count = 0
        for index in upper:
            if index < len(evaluated.data.vertices):
                total += (matrix @ evaluated.data.vertices[index].co).z
                count += 1
        return total / max(1, count)

    def variable_reading():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = armature.evaluated_get(depsgraph)
        bone = evaluated.pose.bones.get(control)
        if bone is None:
            return 0.0
        rest = armature.data.bones[control].matrix_local
        return (rest.inverted() @ bone.matrix).translation.z

    saved = face_regions._pose_snapshot(armature)
    try:
        face_regions._pose_neutral(saved)
        bpy.context.view_layer.update()
        rest_height = margin_height()
        rest_variable = variable_reading()
        pose_bone.location = (0.0, 0.0, -abs(pull_mm) * 0.001)
        bpy.context.view_layer.update()
        closed_height = margin_height()
        closed_variable = variable_reading()
    finally:
        face_regions._pose_restore(saved)
        bpy.context.view_layer.update()

    margin = closed_height - rest_height
    reading = closed_variable - rest_variable
    if abs(reading) < 1.0e-9:
        return None, ("%s reads no local translation when posed, so nothing can "
                      "be driven from it" % control)
    return {"control": control, "pull_mm": pull_mm,
            "margin_travel_mm": round(margin * 1000, 4),
            "variable_travel_mm": round(reading * 1000, 4),
            "coefficient": round(margin / reading, 6),
            "rest_height_mm": round(rest_height * 1000, 3),
            "vertices": len(upper)}, ""


def _line(pairs):
    """Least squares ``y = slope*x + intercept``, plus the worst residual."""
    count = len(pairs)
    if count < 2:
        return None
    sum_x = sum(x for x, _ in pairs)
    sum_y = sum(y for _, y in pairs)
    sum_xx = sum(x * x for x, _ in pairs)
    sum_xy = sum(x * y for x, y in pairs)
    determinant = count * sum_xx - sum_x * sum_x
    if abs(determinant) < 1.0e-18:
        return None
    slope = (count * sum_xy - sum_x * sum_y) / determinant
    intercept = (sum_y - slope * sum_x) / count
    residual = max(abs(slope * x + intercept - y) for x, y in pairs)
    return slope, intercept, residual


def stored_projection(eyeball, uv_layer_name, tolerance=1.0e-4):
    """Recover the projection the mesh's OWN uv layer already is.

    ``(fit, error)``. A drop-shadow map painted through a projection is a planar
    projection, so the layer stored on the mesh can be read back as one: fit
    ``u = a*X + b`` and ``v = c*Z + d`` against world coordinates and look at the
    residual. If it is at the noise floor, the layer IS that projection and the
    projector can be placed to reproduce it exactly instead of being guessed from
    the eyeball's bounding box.

    Guessing was wrong on the reference character and visibly so: a bounding-box
    footprint of 39.23mm put the map at u 0.25..0.75 where the mesh's own layer
    ran 0.1289..0.7828, and it also missed that the two eyes are MIRRORED -- the
    right eye's stored slope is negative. Fitting finds all of that.

    The relationship between the fit and the projector is exact, not empirical
    guesswork, and was checked against Blender: an Empty's footprint spans
    ``2 * scale``, so ``slope = 1 / (2 * scale)``, and the world coordinate that
    lands on 0.5 is ``(0.5 - intercept) / slope``.
    """
    if eyeball is None or eyeball.type != "MESH":
        return None, "Select the eyeball mesh"
    layer = eyeball.data.uv_layers.get(uv_layer_name)
    if layer is None:
        return None, "%s has no uv layer called %r" % (eyeball.name,
                                                       uv_layer_name)
    matrix = eyeball.matrix_world
    across, down = [], []
    for index, loop in enumerate(eyeball.data.loops):
        world = matrix @ eyeball.data.vertices[loop.vertex_index].co
        uv = layer.uv[index].vector
        across.append((world.x, uv[0]))
        down.append((world.z, uv[1]))
    horizontal = _line(across)
    vertical = _line(down)
    if horizontal is None or vertical is None:
        return None, "Not enough uv data to fit"
    a, b, residual_u = horizontal
    c, d, residual_v = vertical
    if abs(a) < 1.0e-9 or abs(c) < 1.0e-9:
        return None, "The stored uv layer does not vary along X or Z"
    planar = max(residual_u, residual_v) <= tolerance
    return {"u_slope": a, "u_intercept": b, "v_slope": c, "v_intercept": d,
            "residual_u": residual_u, "residual_v": residual_v,
            "planar": planar,
            # A mirrored eye reads as a negative slope across X.
            "mirrored": a < 0.0,
            "anisotropy": abs(abs(c) - abs(a)) / max(abs(a), 1.0e-9),
            "scale": 1.0 / (2.0 * abs(a)),
            "centre_x": (0.5 - b) / a,
            "centre_z": (0.5 - d) / c,
            "uv_layer": uv_layer_name}, ""


# --- following the head ----------------------------------------------------------------------


def _chain(bone):
    """``bone`` and its ancestors, nearest first."""
    out = []
    while bone is not None:
        out.append(bone)
        bone = bone.parent
    return out


def _armature_objects(mesh_object):
    return [m.object for m in getattr(mesh_object, "modifiers", ())
            if m.type == "ARMATURE" and m.object is not None and m.object.type == "ARMATURE"]


def eyeball_carrier(eyeball, armature):
    """``(bone name, how)``: the bone that carries the eyeball, or ``(None, why)``.

    A bone parent wins; otherwise the bone of ``armature`` with the largest summed
    weight on the eyeball. On MIK 194 of the 218 vertices are 1.0 on ``c_eye.l``.
    """
    bones = armature.data.bones
    if (eyeball.parent == armature and eyeball.parent_type == "BONE"
            and eyeball.parent_bone in bones):
        return eyeball.parent_bone, "bone parent"
    names = {group.index: group.name for group in eyeball.vertex_groups}
    totals = {}
    for vertex in eyeball.data.vertices:
        for element in vertex.groups:
            name = names.get(element.group)
            if name in bones and element.weight > 0.0:
                totals[name] = totals.get(name, 0.0) + element.weight
    if not totals:
        return None, "no weight on any bone of %s" % armature.name
    best = max(totals, key=totals.get)
    return best, "weights (%.1f on %s)" % (totals[best], best)


def follow_bone(eyeball, armature, side):
    """``(bone name, report)`` the projector is parented to, or ``(None, error)``.

    Chosen from the hierarchy, never from a name list first: the nearest bone that
    is an ancestor-or-self of BOTH the eyeball's carrier and the upper-lid control's
    parent. That is the eye socket: it moves with the head, neck and body and with an
    eye-offset control, but not with the gaze (the carrier turns with the gaze), and
    the lid hangs from it. Without a lid control: the nearest bone named like a head
    above the carrier, then a known head name.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    bones = armature.data.bones
    carrier_name, how = eyeball_carrier(eyeball, armature)
    carrier = bones.get(carrier_name) if carrier_name else None
    lid = bones.get(LID_CONTROL + side)
    lid_parent = lid.parent if lid is not None else None
    report = {"carrier": carrier_name, "carrier_from": how,
              "lid_control": lid.name if lid is not None else None,
              "lid_parent": lid_parent.name if lid_parent is not None else None}
    if carrier is not None and lid_parent is not None:
        socket = {bone.name for bone in _chain(lid_parent)}
        for bone in _chain(carrier):
            if bone.name in socket:
                report["rule"] = "socket: shared ancestor of the eyeball's bone and the lid control"
                return bone.name, report
    if carrier is None and lid_parent is not None:
        report["rule"] = "parent of the lid control (the eyeball has no bone)"
        return lid_parent.name, report
    if carrier is not None:
        for bone in _chain(carrier):
            if "head" in bone.name.lower():
                report["rule"] = "head: nearest head bone above the eyeball's bone"
                return bone.name, report
    for name in HEAD_NAMES:
        if name in bones:
            report["rule"] = "head: known head bone name"
            return name, report
    return None, ("Found no bone for the projector to follow on %s (no %s%s and no head bone)"
                  % (armature.name, LID_CONTROL, side))


def parent_rest_world(armature, bone_name):
    """World matrix a bone parent hands its child at REST: the bone's TAIL frame."""
    bone = armature.data.bones[bone_name]
    return (armature.matrix_world @ bone.matrix_local
            @ Matrix.Translation((0.0, bone.length, 0.0)))


def _current_parent_rest(projector):
    """``(matrix, error)``: the rest world matrix of the projector's present parent."""
    parent = projector.parent
    if parent is None:
        return Matrix.Identity(4), ""
    if projector.parent_type == "BONE":
        if parent.type != "ARMATURE" or projector.parent_bone not in parent.data.bones:
            return None, "%s has a bone parent that does not exist" % projector.name
        return parent_rest_world(parent, projector.parent_bone), ""
    if projector.parent_type == "OBJECT":
        return parent.matrix_world.copy(), ""
    return None, ("%s is parented as %s, which this cannot convert"
                  % (projector.name, projector.parent_type))


_NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
_FORM_SCALED = re.compile(r"\s*(%s)\s*\+\s*(%s)\s*\*\s*\((.+)\)\s*" % (_NUMBER, _NUMBER))
_FORM_SIGNED = re.compile(r"\s*(%s)\s*([+-])\s*\((.+)\)\s*" % _NUMBER)
_FORM_PLAIN = re.compile(r"\s*(%s)\s*\+\s*(.+?)\s*" % _NUMBER)


def _balanced(text):
    depth = 0
    for char in text:
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def split_lid_expression(expression):
    """``(rest, direction, term)`` of a lid driver's expression, or None.

    The three forms this module has written or met:

    * ``rest + term`` -- 2.62.32's ``rest + k * lid`` and MIK_193's
      ``rest + 0.871501 * max(lid, 0.0) + 1.432237 * min(lid, 0.0)``;
    * ``rest + (term)`` / ``rest - (term)``;
    * ``rest + a * (term)`` -- one share of the lid motion in a bone's axes.

    The term is zero with the lid at rest in all of them, so ``rest`` is the value
    at rest.
    """
    if not isinstance(expression, str):
        return None
    match = _FORM_SCALED.fullmatch(expression)
    if match and _balanced(match.group(3)):
        return float(match.group(1)), float(match.group(2)), match.group(3).strip()
    match = _FORM_SIGNED.fullmatch(expression)
    if match and _balanced(match.group(3)):
        return (float(match.group(1)), 1.0 if match.group(2) == "+" else -1.0,
                match.group(3).strip())
    match = _FORM_PLAIN.fullmatch(expression)
    if match and _balanced(match.group(2)):
        return float(match.group(1)), 1.0, match.group(2).strip()
    return None


def _variable_spec(driver):
    spec = []
    for variable in driver.variables:
        targets = []
        for target in variable.targets:
            targets.append({"id_type": target.id_type, "id": target.id,
                            "data_path": target.data_path, "bone_target": target.bone_target,
                            "transform_type": target.transform_type,
                            "transform_space": target.transform_space,
                            "rotation_mode": target.rotation_mode})
        spec.append({"name": variable.name, "type": variable.type, "targets": targets})
    return spec


def _apply_variables(driver, spec):
    for item in spec:
        variable = driver.variables.new()
        variable.name = item["name"]
        variable.type = item["type"]
        for target, source in zip(variable.targets, item["targets"]):
            if item["type"] == "SINGLE_PROP":
                target.id_type = source["id_type"]
            target.id = source["id"]
            target.data_path = source["data_path"]
            target.bone_target = source["bone_target"]
            target.transform_type = source["transform_type"]
            target.transform_space = source["transform_space"]
            target.rotation_mode = source["rotation_mode"]


def _lid_variable_spec(armature, control):
    return [{"name": "lid", "type": "TRANSFORMS",
             "targets": [{"id_type": "OBJECT", "id": armature, "data_path": "",
                          "bone_target": control, "transform_type": "LOC_Z",
                          "transform_space": "LOCAL_SPACE", "rotation_mode": "AUTO"}]}]


def _shoe_drivers(projector):
    from . import shoe_lift

    ad = projector.animation_data
    if ad is None:
        return []
    return [curve for curve in ad.drivers
            if curve.data_path == "delta_location" and shoe_lift._is_ours(curve)]


def read_existing(projector, armature):
    """What an existing projector is, read without writing: ``(info, error)``.

    ``info["rest_world"]`` is its world matrix with the lid at zero. A shoe-lift
    driver counts when the projector stands outside the lifted parent (2.62.32,
    MIK_193: the driver is what lifts it), and does not when it already descends
    from it (the lift then arrives twice; the second one is not part of where it
    belongs).
    """
    from . import shoe_lift

    if projector.constraints:
        return None, ("%s has constraints (%s); remove them or the projector first"
                      % (projector.name, ", ".join(c.name for c in projector.constraints)))
    ad = projector.animation_data
    if ad is not None and ad.action is not None:
        return None, "%s is animated by %s; it cannot be re-parented safely" % (
            projector.name, ad.action.name)
    lid_curves = [curve for curve in (ad.drivers if ad else ())
                  if curve.data_path == "location"]
    constants, directions, term, spec = {}, {}, None, None
    for curve in lid_curves:
        driver = curve.driver
        parsed = split_lid_expression(driver.expression) if driver.type == "SCRIPTED" else None
        if parsed is None or not len(driver.variables):
            return None, ("%s location[%d] has a driver this cannot read (%r); left untouched"
                          % (projector.name, curve.array_index, driver.expression))
        rest, direction, this_term = parsed
        if term is None:
            term, spec = this_term, _variable_spec(driver)
        elif this_term != term:
            return None, ("%s drives its location with two different lid terms (%r, %r)"
                          % (projector.name, term, this_term))
        constants[curve.array_index] = rest
        directions[curve.array_index] = direction
    shoe = _shoe_drivers(projector)
    others = [curve for curve in (ad.drivers if ad else ())
              if curve.data_path in ("rotation_euler", "rotation_quaternion", "scale",
                                     "rotation_axis_angle", "delta_rotation_euler",
                                     "delta_rotation_quaternion", "delta_scale",
                                     "delta_location")
              and curve not in shoe]
    if others:
        return None, ("%s has a driver on %s; left untouched"
                      % (projector.name, others[0].data_path))
    parent_rest, error = _current_parent_rest(projector)
    if error:
        return None, error
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = projector.evaluated_get(depsgraph)
    basis = evaluated.matrix_basis.copy()
    location = Vector(evaluated.location)
    for index, rest in constants.items():
        location[index] = rest
    delta = Vector(evaluated.delta_location)
    holder = shoe_lift.holder(armature)
    double = bool(shoe) and holder is not None and shoe_lift._descends(projector, holder)
    if double:
        for curve in shoe:
            delta[curve.array_index] = projector.delta_location[curve.array_index]
    basis.translation = location + delta
    to_world = parent_rest @ projector.matrix_parent_inverse
    motion = Vector((0.0, 0.0, 0.0))
    for index, direction in directions.items():
        axis = Vector((0.0, 0.0, 0.0))
        axis[index] = direction
        motion += to_world.to_3x3() @ axis
    return {"rest_world": to_world @ basis,
            "motion_world": motion if term is not None else None,
            "term": term, "variables": spec,
            "parent": projector.parent.name if projector.parent else None,
            "parent_type": projector.parent_type if projector.parent else None,
            "parent_bone": projector.parent_bone if projector.parent else "",
            "lid_drivers": len(lid_curves), "shoe_drivers": len(shoe),
            "shoe_counted_twice": double}, ""


def _decompose_exact(matrix, tolerance=1.0e-7):
    location, rotation, scale = matrix.decompose()
    rebuilt = Matrix.LocRotScale(location, rotation, scale)
    size = max(1.0, max(abs(v) for row in matrix for v in row))
    error = max(abs(rebuilt[r][c] - matrix[r][c]) for r in range(4) for c in range(4))
    return location, rotation, scale, error <= tolerance * size


def plan_placement(armature, bone_name, rest_world, motion_world, term):
    """The projector's values in the bone's coordinates. ``(plan, error)``.

    The parent inverse stays identity and the basis carries the rest pose in the
    bone's tail frame, as MIK_194 was fixed by hand. If the bone frame and the rest
    matrix cannot be composed without shear (a non-uniformly scaled parent), the
    parent inverse takes the bone's rest frame instead, so the basis stays the
    world-space one.
    """
    parent = parent_rest_world(armature, bone_name)
    if abs(parent.determinant()) < 1.0e-12:
        return None, "%s has a degenerate rest matrix" % bone_name
    inverse = Matrix.Identity(4)
    basis = parent.inverted() @ rest_world
    location, rotation, scale, exact = _decompose_exact(basis)
    if not exact:
        inverse = parent.inverted()
        basis = rest_world.copy()
        location, rotation, scale, exact = _decompose_exact(basis)
        if not exact:
            return None, "The projector's own rest matrix is sheared; it cannot be rebuilt"
    to_world = parent @ inverse
    axis = to_world.to_3x3().inverted() @ motion_world
    expressions = {}
    limit = AXIS_EPS * max(1.0, axis.length)
    for index in range(3):
        if abs(axis[index]) < limit:
            continue
        rest = float(location[index])
        if abs(abs(axis[index]) - 1.0) < 1.0e-7:
            text = "%r %s (%s)" % (rest, "+" if axis[index] > 0 else "-", term)
        else:
            text = "%r + %r * (%s)" % (rest, float(axis[index]), term)
        if len(text) > EXPRESSION_MAX:
            return None, "The lid expression would be %d characters (limit %d)" % (
                len(text), EXPRESSION_MAX)
        expressions[index] = text
    if not expressions:
        return None, "The lid moves the projector along no axis"
    return {"bone": bone_name, "parent_inverse": inverse, "location": location,
            "rotation": rotation, "scale": scale, "axis": axis,
            "expressions": expressions, "parent_rest": parent}, ""


def _write_placement(projector, armature, plan, variables):
    """Write a planned placement. Everything that can refuse has already been checked."""
    ad = projector.animation_data
    if ad is not None:
        for curve in list(ad.drivers):
            if curve.data_path == "location":
                projector.driver_remove("location", curve.array_index)
    removed_shoe = []
    for curve in _shoe_drivers(projector):
        removed_shoe.append(curve.array_index)
        projector.driver_remove("delta_location", curve.array_index)
    projector.delta_location = (0.0, 0.0, 0.0)
    projector.delta_rotation_euler = (0.0, 0.0, 0.0)
    projector.delta_rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
    projector.delta_scale = (1.0, 1.0, 1.0)
    projector.parent = armature
    projector.parent_type = "BONE"
    projector.parent_bone = plan["bone"]
    projector.matrix_parent_inverse = plan["parent_inverse"]
    projector.location = plan["location"]
    mode = projector.rotation_mode
    if mode == "QUATERNION":
        projector.rotation_quaternion = plan["rotation"]
    elif mode == "AXIS_ANGLE":
        axis, angle = plan["rotation"].to_axis_angle()
        projector.rotation_axis_angle = (angle, axis[0], axis[1], axis[2])
    else:
        projector.rotation_euler = plan["rotation"].to_euler(mode, projector.rotation_euler)
    projector.scale = plan["scale"]
    for index, text in sorted(plan["expressions"].items()):
        curve = projector.driver_add("location", index)
        # driver_add can hand back a curve with a Generator; the plain driver value is wanted
        for modifier in list(curve.modifiers):
            curve.modifiers.remove(modifier)
        driver = curve.driver
        driver.type = "SCRIPTED"
        for variable in list(driver.variables):
            driver.variables.remove(variable)
        _apply_variables(driver, variables)
        driver.expression = text
    if GUARD_KEY in projector.keys():
        basis = projector.matrix_basis.copy()
        world = plan["parent_rest"] @ plan["parent_inverse"] @ basis
        projector[GUARD_KEY] = json.dumps(
            {"basis": [list(row) for row in basis], "world": [list(row) for row in world],
             "rotation_mode": projector.rotation_mode}, separators=(",", ":"))
    projector.update_tag()
    return removed_shoe


def _matrix_error(a, b):
    return max(abs(a[r][c] - b[r][c]) for r in range(4) for c in range(4))


def build(eyeball, face, armature, side, pull_mm=8.38, distance_mm=200.0,
          follow=1.0, collection=None, remeasure=False):
    """Give one eyeball a projector that tracks the upper lid AND the head.

    ``(report, error)``. ``follow`` scales the measured travel: 1.0 makes the
    shadow slide exactly as far as the lid margin does, lower values hold it back.

    An existing projector keeps its rest placement and its lid expression and is
    (re)parented to the socket bone -- unless ``remeasure`` is set, which places it
    from the stored layer and measures the lid again, as a first build does.
    ``follow``, ``distance_mm`` and ``pull_mm`` only apply to a measured build.

    The modifier is left pointing at whatever UV layer it already names. On this
    character that is the eyeball's first layer, which is the one the sclera
    material samples when it has no UV Map node of its own -- the iris and pupil
    name ``UVChannel_1`` explicitly and are untouched.
    """
    if eyeball is None or eyeball.type != "MESH":
        return None, "Select the eyeball mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    bone_name, choice = follow_bone(eyeball, armature, side)
    if bone_name is None:
        return None, choice
    name = "%s_%s" % (PROJECTOR_PREFIX, side.strip(".").upper() or "X")
    projector = bpy.data.objects.get(name)
    if projector is not None and projector.type != "EMPTY":
        return None, "%s exists and is a %s, not an Empty" % (name, projector.type)
    bpy.context.view_layer.update()

    existing = None
    if projector is not None:
        existing, error = read_existing(projector, armature)
        if error:
            return None, error
        if existing["term"] is None:
            existing = None if remeasure else existing
    keep = existing is not None and existing["term"] is not None and not remeasure

    modifier = _uv_project(eyeball)
    created_modifier = modifier is None
    previous = read_state(eyeball)
    travel = None
    width = None
    if keep:
        rest_world = existing["rest_world"]
        motion_world = existing["motion_world"]
        term = existing["term"]
        variables = existing["variables"]
        coefficient = None
    else:
        travel, error = lid_travel(eyeball, armature, side, pull_mm=pull_mm, ring=face)
        if error:
            return None, error
        corners = [eyeball.matrix_world @ mathutils.Vector(c) for c in eyeball.bound_box]
        width = max(max(c.x for c in corners) - min(c.x for c in corners),
                    max(c.z for c in corners) - min(c.z for c in corners))
        centre = mathutils.Vector((0.0, 0.0, 0.0))
        for corner in corners:
            centre += corner
        centre /= len(corners)
        # Prefer the mesh's own layer over the bounding box. The stored layer is what
        # the artist painted the shadow against, so reproducing it is the whole point
        # -- a projector sized from the bounding box changes the mapping, which is a
        # visible regression even though the shadow still follows the lid.
        layer_name = (modifier.uv_layer if modifier is not None
                      else (eyeball.data.uv_layers[0].name if eyeball.data.uv_layers else ""))
        fit, fit_error = stored_projection(eyeball, layer_name) \
            if layer_name else (None, "the modifier names no uv layer")
        if fit is not None and not fit["planar"]:
            fit = None
        # An Empty projects along its own -Z, like a camera. Rotating +90 degrees
        # about X turns -Z towards +Y, so an Empty placed in FRONT of the face
        # (further -Y) looks back at the eye.
        if fit is not None:
            # A mirrored eye is fixed by turning the Empty 180 degrees about its own
            # Z. That flips local X and leaves the projection direction and V alone.
            # A negative object scale reproduces the same mapping but leaves a
            # mirrored matrix behind, and the modifier's own scale_x does NOT mirror
            # at all -- both were measured before choosing this.
            rotation = mathutils.Euler((1.5707963267948966, 0.0,
                                        math.pi if fit["mirrored"] else 0.0), "XYZ")
            location = Vector((fit["centre_x"], centre.y - abs(distance_mm) * 0.001,
                               fit["centre_z"]))
            size = fit["scale"]
        else:
            rotation = mathutils.Euler((1.5707963267948966, 0.0, 0.0), "XYZ")
            location = Vector((centre.x, centre.y - abs(distance_mm) * 0.001, centre.z))
            # Scale sets the footprint: the Empty's local 1x1 area becomes UV 0..1.
            size = max(width, 1.0e-4)
        rest_world = Matrix.LocRotScale(location, rotation, Vector((size, size, size)))
        coefficient = travel["coefficient"] * float(follow)
        term = "%r * lid" % coefficient
        variables = _lid_variable_spec(armature, travel["control"])
        # The lid moves the shadow straight up and down in the world at rest.
        motion_world = Vector((0.0, 0.0, 1.0))

    plan, error = plan_placement(armature, bone_name, rest_world, motion_world, term)
    if error:
        return None, error

    # --- nothing has been written above this line ---
    if modifier is None:
        modifier = eyeball.modifiers.new(name="UV Project", type="UV_PROJECT")
        if modifier is None:
            return None, "%s would not take a UV Project modifier" % eyeball.name
        if eyeball.data.uv_layers:
            modifier.uv_layer = eyeball.data.uv_layers[0].name
    if projector is None:
        projector = bpy.data.objects.new(name, None)
        projector.empty_display_type = "IMAGE"
        target = collection or bpy.context.scene.collection
        target.objects.link(projector)
        projector.rotation_mode = "XYZ"
    if width is not None:
        projector.empty_display_size = max(width, 1.0e-4)
    removed_shoe = _write_placement(projector, armature, plan, variables)

    modifier.projector_count = 1
    modifier.projectors[0].object = projector
    # Any aspect or scale other than one would move the map off the layer it is
    # being matched to.
    modifier.aspect_x = 1.0
    modifier.aspect_y = 1.0
    modifier.scale_x = 1.0
    modifier.scale_y = 1.0
    modifier.show_viewport = True
    modifier.show_render = True
    bpy.context.view_layer.update()

    achieved = plan["parent_rest"] @ plan["parent_inverse"] @ Matrix.LocRotScale(
        plan["location"], plan["rotation"], plan["scale"])
    rest_error = _matrix_error(achieved, rest_world)
    if keep:
        mode = "migrated" if existing["parent"] is None else "rebuilt"
    else:
        mode = "measured" if existing is not None or previous else "created"
    state = {
        "projector": projector.name, "modifier": modifier.name,
        "uv_layer": modifier.uv_layer, "side": side,
        "rest_z": float(rest_world.translation.z),
        "parent_bone": bone_name, "follow_rule": choice.get("rule", ""),
        "lid_term": term, "kept_expression": bool(keep), "mode": mode,
        "created_modifier": bool(previous.get("created_modifier", created_modifier)),
    }
    if coefficient is not None:
        state["coefficient"] = float(coefficient)
    elif "coefficient" in previous:
        state["coefficient"] = float(previous["coefficient"])
    if travel is not None:
        state["margin_travel_mm"] = travel["margin_travel_mm"]
        state["variable_travel_mm"] = travel["variable_travel_mm"]
    else:
        for key in ("margin_travel_mm", "variable_travel_mm"):
            if key in previous:
                state[key] = float(previous[key])
    eyeball[STATE_KEY] = state
    return {"eyeball": eyeball.name, "projector": projector.name,
            "modifier": modifier.name, "uv_layer": modifier.uv_layer,
            "mode": mode, "parent": armature.name, "parent_bone": bone_name,
            "choice": choice,
            "previous_parent": (None if existing is None else
                                [existing["parent"], existing["parent_bone"]]),
            "footprint_mm": None if width is None else round(width * 1000, 3),
            "rest_z_mm": round(rest_world.translation.z * 1000, 3),
            "rest_world_error": rest_error,
            "lid_axis_in_parent": [float(v) for v in plan["axis"]],
            "expressions": {"location[%d]" % i: t for i, t in sorted(plan["expressions"].items())},
            "expression": plan["expressions"][max(plan["expressions"],
                                                  key=lambda i: abs(plan["axis"][i]))],
            "kept_expression": bool(keep), "travel": travel,
            "shoe_drivers_removed": removed_shoe,
            "created_modifier": created_modifier}, ""


# --- checking ------------------------------------------------------------------------------


def _subtree(armature, bone_name):
    bones = armature.data.bones
    return {bone.name for bone in bones if bone_name in {b.name for b in _chain(bone)}}


def rigid_loops(eyeball, armature, bone_name):
    """Loop indices whose vertex moves only with ``bone_name`` and the bones under it.

    A vertex with any weight on a bone outside that subtree (MIK's eyeballs carry 24
    vertices on the shoulder helper ``epaules_bend.x``) does not move rigidly with
    the socket, so comparing its UV after a head move would measure the skin, not the
    projector. Vertex groups that are no bone of any deforming armature are ignored.
    """
    under = _subtree(armature, bone_name)
    others = set()
    deformers = _armature_objects(eyeball)
    for other in deformers:
        if other != armature:
            others.update(bone.name for bone in other.data.bones)
    bone_parented = eyeball.parent == armature and eyeball.parent_type == "BONE"
    if bone_parented and eyeball.parent_bone not in under:
        return []
    if armature not in deformers:
        return list(range(len(eyeball.data.loops))) if bone_parented else []
    names = {group.index: group.name for group in eyeball.vertex_groups}
    rigid = []
    for vertex in eyeball.data.vertices:
        inside = 0.0
        outside = False
        for element in vertex.groups:
            if element.weight <= 1.0e-6:
                continue
            name = names.get(element.group)
            if name in others:
                outside = True
            elif name in under:
                inside += element.weight
            elif name in armature.data.bones:
                outside = True
        rigid.append(inside > 1.0e-6 and not outside)
    return [index for index, loop in enumerate(eyeball.data.loops) if rigid[loop.vertex_index]]


def _external_constraints(armature, under):
    """Constraints in the socket's subtree that pull a bone towards something outside it.

    The gaze (``c_eye.l``'s Damped Track to ``c_eye_target.l``) is the one that matters:
    with the head turned the eye keeps looking at the target, so the eyeball rotates
    under the shadow on purpose. The follow check measures the projector, so it holds
    those still.
    """
    found = []
    for name in sorted(under):
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is None:
            continue
        for constraint in pose_bone.constraints:
            if constraint.mute:
                continue
            targets = []
            if hasattr(constraint, "targets"):
                targets = [(t.target, getattr(t, "subtarget", "")) for t in constraint.targets]
            elif hasattr(constraint, "target"):
                targets = [(constraint.target, getattr(constraint, "subtarget", ""))]
            if any(target is not None and (target != armature or not sub or sub not in under)
                   for target, sub in targets):
                found.append(constraint)
    return found


FOLLOW_POSES = (
    ("head 40/0/30 deg", {"head": mathutils.Euler((math.radians(40.0), 0.0, math.radians(30.0)))
                          .to_matrix().to_4x4()}),
    ("body moved and turned 90 deg, head -35/0/-30 deg",
     {"root": Matrix.Translation((0.3, -0.5, 0.2)) @ Matrix.Rotation(math.radians(90.0), 4, "Z"),
      "head": mathutils.Euler((math.radians(-35.0), 0.0, math.radians(-30.0))).to_matrix().to_4x4()}),
)


def verify(eyeball, armature, side, pull_mm=8.38):
    """Does the projector actually move with the lid, and the UVs with it -- and
    does it follow the head?

    ``(report, error)``. The lid halves are checked: a projector that moves while the
    modifier is off changes nothing, and UVs that change while the projector sits
    still would mean something else is driving them. Then the head is turned hard
    (and the body moved and turned), the gaze held: on the vertices that move only
    with the eye socket the generated UVs must stay what they were at rest. A
    projector standing in the world fails this by 0.7 .. 18.8 in UV (MIK_193).
    """
    from . import face_regions

    modifier = _uv_project(eyeball)
    if modifier is None:
        return None, "%s has no UV Project modifier" % eyeball.name
    projector = modifier.projectors[0].object if modifier.projector_count else None
    if projector is None:
        return None, "%s has no projector assigned" % eyeball.name
    control = LID_CONTROL + side

    def sample():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = eyeball.evaluated_get(depsgraph)
        layer = evaluated.data.uv_layers.get(modifier.uv_layer)
        rows = []
        if layer is not None:
            # uv_layers[..].uv is a Float2Attribute collection: its elements
            # carry .vector, not .uv. Reaching for .uv raises AttributeError.
            for element in layer.uv:
                vector = element.vector
                rows.append((vector[0], vector[1]))
        return (projector.matrix_world.translation.copy(), rows)

    if projector.parent == armature and projector.parent_type == "BONE":
        socket = projector.parent_bone
    else:
        socket, _report = follow_bone(eyeball, armature, side)
    follow = {"socket": socket, "judged": False, "uv_maxdiff": None, "poses": {}}

    saved = face_regions._pose_snapshot(armature)
    muted = []
    try:
        face_regions._pose_neutral(saved)
        bpy.context.view_layer.update()
        rest_position, rest_uv = sample()
        pose_bone = armature.pose.bones.get(control)
        if pose_bone is None:
            return None, "no %s" % control
        pose_bone.location = (0.0, 0.0, -abs(pull_mm) * 0.001)
        bpy.context.view_layer.update()
        closed_position, closed_uv = sample()
        pose_bone.location = (0.0, 0.0, 0.0)

        if socket and socket in armature.data.bones:
            loops = rigid_loops(eyeball, armature, socket)
            bone = armature.data.bones[socket]
            movers = {"head": bone.parent.name if bone.parent else None,
                      "root": _chain(bone)[-1].name}
            if movers["root"] in (socket, movers["head"]):
                movers["root"] = None
            follow["rigid_loops"] = len(loops)
            follow["moved"] = movers
            if loops and len(loops) <= len(rest_uv):
                for constraint in _external_constraints(armature, _subtree(armature, socket)):
                    constraint.mute = True
                    muted.append(constraint)
                follow["held_constraints"] = len(muted)
                bpy.context.view_layer.update()
                _p, still_uv = sample()
                worst = 0.0
                for label, pose in FOLLOW_POSES:
                    face_regions._pose_neutral(saved)
                    applied = False
                    for role, matrix in pose.items():
                        target = movers.get(role)
                        if target:
                            armature.pose.bones[target].matrix_basis = matrix
                            applied = True
                    if not applied:
                        continue
                    bpy.context.view_layer.update()
                    _p, posed_uv = sample()
                    if len(posed_uv) != len(still_uv):
                        continue
                    diff = max(max(abs(posed_uv[i][0] - still_uv[i][0]),
                                   abs(posed_uv[i][1] - still_uv[i][1])) for i in loops)
                    follow["poses"][label] = round(diff, 7)
                    worst = max(worst, diff)
                    follow["judged"] = True
                if follow["judged"]:
                    follow["uv_maxdiff"] = round(worst, 7)
    finally:
        for constraint in muted:
            constraint.mute = False
        face_regions._pose_restore(saved)
        bpy.context.view_layer.update()

    moved = (closed_position - rest_position).length * 1000
    shift = 0.0
    median = 0.0
    if rest_uv and len(rest_uv) == len(closed_uv):
        deltas = [b[1] - a[1] for a, b in zip(rest_uv, closed_uv)]
        shift = max(abs(d) for d in deltas)
        moving = sorted(d for d in deltas if abs(d) > 1.0e-6)
        if moving:
            median = moving[len(moving) // 2]

    # The third thing to check, and the one that was missed the first time: at
    # REST the generated layer has to land where the artist's own layer already
    # is. A projector can follow the lid perfectly and still have moved the whole
    # map, which is a visible regression rather than a subtle one.
    match = None
    layer = eyeball.data.uv_layers.get(modifier.uv_layer)
    if layer is not None and rest_uv and len(layer.uv) == len(rest_uv):
        match = 0.0
        for element, generated in zip(layer.uv, rest_uv):
            stored = element.vector
            match = max(match, abs(stored[0] - generated[0]),
                        abs(stored[1] - generated[1]))

    follows = (not follow["judged"]) or follow["uv_maxdiff"] <= FOLLOW_TOLERANCE
    return {"eyeball": eyeball.name, "projector": projector.name,
            "projector_moved_mm": round(moved, 4),
            "uv_v_shift": round(shift, 6),
            "uv_v_shift_median": round(median, 6),
            "uv_pairs": len(rest_uv),
            "uv_match_at_rest": None if match is None else round(match, 7),
            "modifier_on": [modifier.show_viewport, modifier.show_render],
            "parent": [projector.parent.name if projector.parent else None,
                       projector.parent_type if projector.parent else None,
                       projector.parent_bone if projector.parent else ""],
            "follow": follow,
            "follows_head": bool(follow["judged"] and follows),
            "ok": (moved > 0.1 and shift > 1.0e-5
                   and (match is None or match <= 1.0e-3)
                   and follows)}, ""


def remove(eyeball, delete_projector=True):
    """Undo the setup, leaving the modifier the way it was found."""
    if eyeball is None:
        return None, "No mesh"
    state = read_state(eyeball)
    modifier = _uv_project(eyeball)
    removed = []
    if modifier is not None:
        if state.get("created_modifier"):
            removed.append(modifier.name)
            eyeball.modifiers.remove(modifier)
        else:
            if modifier.projector_count:
                modifier.projectors[0].object = None
            modifier.show_viewport = False
            modifier.show_render = False
    name = state.get("projector")
    if delete_projector and name:
        projector = bpy.data.objects.get(name)
        if projector is not None:
            bpy.data.objects.remove(projector, do_unlink=True)
            removed.append(name)
    if STATE_KEY in eyeball.keys():
        del eyeball[STATE_KEY]
    return {"eyeball": eyeball.name, "removed": removed}, ""


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
