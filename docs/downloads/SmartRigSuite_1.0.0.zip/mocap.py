# -*- coding: utf-8 -*-
"""Motion capture in, and a straight answer about whether the rig survived it.

Auto-Rig Pro can already retarget: the Remap tab takes a source armature and
bakes its action onto the controllers. What it cannot do is the part either side
of that -- getting the file in, naming the bones correctly, and telling you
afterwards whether the character came through intact.

The bone map is where it goes wrong quietly. ARP guesses names by fragment, and
measured on a CMU skeleton it mapped ``LHipJoint`` to ``c_lips_bot.l``,
``LowerBack`` to ``c_eye_ref_track.l`` and ``LThumb`` to the RIGHT thumb, because
"hip", "lip" and "l" appear where they do. Every one of those bakes without an
error. The presets here are written out in full so the map is a fact rather than
a guess.

The check afterwards is the other half. A retarget that "plays" tells you
nothing: the failures are local -- a band around a sleeve crushing at the elbow,
a chain of collar links stretching to three times its length -- and they are
invisible at the scale you watch the whole body. :func:`check` measures every
edge of every bound mesh against its rest length and reports which vertex groups
the broken ones belong to, which names the culprit directly.
"""

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = "srs_mocap"

import os

import math

import bpy
import mathutils

from . import generation


# The skeleton the CMU database ships as BVH (the cgspeed conversions and the
# mirrors of them). Fingers are deliberately absent -- see FINGER_NOTE.
CMU = {
    "Hips": "c_root_master.x",
    "LowerBack": "c_spine_01.x",
    "Spine": "c_spine_02.x",
    "Spine1": "c_spine_03.x",
    "Neck": "c_neck.x",
    "Neck1": "c_neck_01.x",
    "Head": "c_head.x",
    "LeftShoulder": "c_shoulder.l",
    "LeftArm": "c_arm_fk.l",
    "LeftForeArm": "c_forearm_fk.l",
    "LeftFingerBase": "c_hand_fk.l",
    "RightShoulder": "c_shoulder.r",
    "RightArm": "c_arm_fk.r",
    "RightForeArm": "c_forearm_fk.r",
    "RightFingerBase": "c_hand_fk.r",
    "LeftUpLeg": "c_thigh_fk.l",
    "LeftLeg": "c_leg_fk.l",
    "LeftFoot": "c_foot_fk.l",
    "LeftToeBase": "c_toes_fk.l",
    "RightUpLeg": "c_thigh_fk.r",
    "RightLeg": "c_leg_fk.r",
    "RightFoot": "c_foot_fk.r",
    "RightToeBase": "c_toes_fk.r",
}
# The CMU wrist: LeftHand -> LeftFingerBase sit at the same point (zero offset), so LeftHand imports as a
# zero-length bone whose direction means nothing and which carries only the forearm-twist part; the bend of
# the wrist is in LeftFingerBase. Mapped from LeftHand, MIK's wrist stood still at 90 degrees for the whole
# of 79_22 (measured 2026-10-10); mapped from LeftFingerBase it moves 25-73 / 41-69 degrees. A clip without
# FingerBase falls back to Hand.
CMU_HAND_FALLBACK = {"LeftFingerBase": "LeftHand", "RightFingerBase": "RightHand"}
# Bones left out of the rest-pose alignment: end bones (hands, feet, toes) are short or zero-length in the
# capture skeletons, so aiming them along the rig's bone turns a meaningless direction into a constant bend.
REST_SKIP_ENDS = ("c_hand_fk.l", "c_hand_fk.r", "c_foot_fk.l", "c_foot_fk.r", "c_toes_fk.l", "c_toes_fk.r")
TOE_SOURCES = ("LeftToeBase", "RightToeBase")
# Whether toes are mapped when the caller does not say. CMU's are not: on MIK
# the left toe of 79_22 sat at 88-101 degrees for every frame (rest 41.6, the
# right one 27-70) and the shoe tip creased, so the CMU toe channel is read as
# a constant offset rather than motion. HumanIK clips keep theirs.
TOES_BY_DEFAULT = {"CMU": False}
CMU_FINGERS = {
    "LeftHandIndex1": "c_index1.l",
    "LThumb": "c_thumb1.l",
    "RightHandIndex1": "c_index1.r",
    "RThumb": "c_thumb1.r",
}
# The HumanIK names: what MotionBuilder writes, and what Mixamo, Rokoko and most
# FBX motion packs reuse. Mixamo's are the same names behind "mixamorig:", and
# MotionBuilder's behind "Character1_", so one table reads all of them once
# :func:`bone_key` has taken the prefix off.
HUMANIK = {
    "Hips": "c_root_master.x",
    "Spine": "c_spine_01.x",
    "Spine1": "c_spine_02.x",
    "Spine2": "c_spine_03.x",
    "Neck": "c_neck.x",
    "Neck1": "c_neck_01.x",
    "Head": "c_head.x",
    "LeftShoulder": "c_shoulder.l",
    "LeftArm": "c_arm_fk.l",
    "LeftForeArm": "c_forearm_fk.l",
    "LeftHand": "c_hand_fk.l",
    "RightShoulder": "c_shoulder.r",
    "RightArm": "c_arm_fk.r",
    "RightForeArm": "c_forearm_fk.r",
    "RightHand": "c_hand_fk.r",
    "LeftUpLeg": "c_thigh_fk.l",
    "LeftLeg": "c_leg_fk.l",
    "LeftFoot": "c_foot_fk.l",
    "LeftToeBase": "c_toes_fk.l",
    "RightUpLeg": "c_thigh_fk.r",
    "RightLeg": "c_leg_fk.r",
    "RightFoot": "c_foot_fk.r",
    "RightToeBase": "c_toes_fk.r",
}
# Three bones a finger from the knuckle out, as Auto-Rig Pro's c_<finger>1-3
# (its *_base bones are the palm, which these skeletons do not have).
HUMANIK_FINGERS = {
    "%sHand%s%d" % (side, finger.capitalize(), joint): "c_%s%d.%s" % (finger, joint, side[0].lower())
    for side in ("Left", "Right")
    for finger in ("thumb", "index", "middle", "ring", "pinky")
    for joint in (1, 2, 3)
}
MIXAMO = HUMANIK
PRESETS = {"CMU": CMU, "MIXAMO": HUMANIK, "HUMANIK": HUMANIK, "AUTO": None}
FINGERS = {"CMU": CMU_FINGERS, "MIXAMO": HUMANIK_FINGERS, "HUMANIK": HUMANIK_FINGERS, "AUTO": {}}
# Bones only one of the two namings has. A clip read with the other table maps
# its spine one bone out of step and bakes without an error, so a clear
# mismatch is refused rather than baked.
SIGNATURE = {"CMU": ("LowerBack", "LeftFingerBase"), "HUMANIK": ("Spine2",)}


def bone_key(name):
    """A source bone's name without the exporter's prefix.

    ``mixamorig:LeftArm``, ``mixamorig1:LeftArm``, any ``namespace:LeftArm``
    and MotionBuilder's ``Character1_LeftArm`` all read as ``LeftArm``.
    """
    name = str(name).rsplit(":", 1)[-1]
    if name.startswith("Character"):
        head, _, rest = name.partition("_")
        if rest and (head == "Character" or head[len("Character"):].isdigit()):
            name = rest
    return name


FINGER_NOTE = (
    "Mocap finger channels are left out on purpose. Pointing a two-joint capture "
    "at a full finger rig imposes the difference between their rest "
    "orientations as a constant bend: measured, mapping them tripled the "
    "collapsed-vertex count on the arm accessories (3.0% -> 12.0%) and doubled "
    "it on the body."
)


def presets():
    """The maps this module knows, newest first in usefulness order."""
    return ["CMU", "HUMANIK", "AUTO"]


def _enable(module_name):
    import addon_utils

    try:
        _ok, loaded = addon_utils.check(module_name)
    except Exception:
        return False
    if loaded:
        return True
    try:
        addon_utils.enable(module_name, default_set=False, persistent=True)
    except Exception:
        return False
    return True


# ARP's remap writes each bone's deviation from the SOURCE's own rest pose onto
# the TARGET's rest pose, so any difference between the two rest poses rides
# along as a constant offset for every frame of the clip. These are the source
# bones to leave alone when correcting for that: the root carries translation,
# and rotating its rest would turn the direction the character travels in.
REST_KEEP = ("c_root_master.x", "root.x", "c_traj")


def _hierarchy_order(armature, names):
    """Parents before children -- the matrix setter reads the parent's state."""
    depth = {}

    def rank(bone):
        if bone.name in depth:
            return depth[bone.name]
        depth[bone.name] = 0 if bone.parent is None else rank(bone.parent) + 1
        return depth[bone.name]

    for bone in armature.data.bones:
        rank(bone)
    return sorted(names, key=lambda row: depth.get(row[0], 0))


def align_rest(source, target, pairs=None, skip=REST_KEEP):
    """Make the source's rest pose match the rig's. ``(report, error)``.

    This is the thing ARP puts behind its Redefine Rest Pose button, whose own
    tooltip says it is "necessary for accurate retargetting" -- and which no
    script path reaches, so ``preserve`` is always False and the uncorrected
    branch always runs.

    Why it matters here, measured rather than feared: the CMU skeleton's
    hierarchy holds each leg at exactly 20.000 degrees of abduction (``LeftLeg
    OFFSET 2.20103 -6.04728 0`` -> sin 20.000), which is the ASF calibration
    stance, and the motion data spends the whole clip counter-rotating it back
    under the hips -- frame 1 of all three local clips is literally
    ``LeftUpLeg Zrot -21 / RightUpLeg +21``. Copied verbatim onto a rig whose
    thighs hang vertically, that counter-rotation IS adduction: roughly 17
    degrees left and 14 right, held for every frame. Both ankles swing inboard
    past the midline. The source clips cross their own feet on 0 frames; MIK
    crossed on 60 of 60 sampled, worst 456.6mm.

    Each mapped source bone is aimed along its target bone's REST direction by
    the minimal rotation, which is what ARP's own Copy Bone Rest does with a
    damped track, and the snapshot is taken from there. The action is unlinked
    first -- leaving it on means the curves overwrite the pose before the
    snapshot reads it -- and ARP's ``save_pose_rest`` links it back.
    """
    if source is None or source.type != "ARMATURE":
        return None, "No source armature"
    if target is None or target.type != "ARMATURE":
        return None, "No target armature"
    for name in ("redefine_rest_pose", "save_pose_rest"):
        if not hasattr(getattr(bpy.ops, "arp", None), name):
            return None, "Auto-Rig Pro's rest pose tools are missing, so the rest pose cannot be corrected"
    scene = bpy.context.scene
    if pairs is None:
        pairs = []
        for item in getattr(scene, "bones_map_v2", []) or []:
            goal = str(getattr(item, "name", "") or "")
            if goal and goal != "None":
                pairs.append((item.source_bone, goal))
    chain = list(pairs)
    pairs = [(a, b) for a, b in pairs if b not in set(skip or ())]
    if not pairs:
        return None, "No mapped bones to align"

    for obj in bpy.context.view_layer.objects:
        obj.select_set(False)
    source.select_set(True)
    bpy.context.view_layer.objects.active = source
    if source.animation_data is not None:
        source.animation_data.action = None
    for pose_bone in source.pose.bones:
        pose_bone.location = (0.0, 0.0, 0.0)
        pose_bone.scale = (1.0, 1.0, 1.0)
        pose_bone.rotation_euler = (0.0, 0.0, 0.0)
        pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
    bpy.context.view_layer.update()

    axis = mathutils.Vector((0.0, 1.0, 0.0))
    world = source.matrix_world
    inverse = world.inverted()
    turned, rows, worst, worst_at = 0, [], 0.0, ""
    for source_name, target_name in _hierarchy_order(source, pairs):
        pose_bone = source.pose.bones.get(source_name)
        bone = target.data.bones.get(target_name)
        if pose_bone is None or bone is None:
            continue
        want = target.matrix_world.to_3x3() @ (bone.tail_local - bone.head_local)
        if want.length <= 1.0e-9:
            continue
        want.normalize()
        matrix = world @ pose_bone.matrix
        child = _chain_child(source, target, pose_bone, bone, chain)
        if child is not None:
            have = world.to_3x3() @ (child.head - pose_bone.head)
        elif len(pose_bone.children):
            # A junction every child leaves from its head (CMU's chest): it
            # has no direction of its own, and the one the importer gave it
            # differs by format, so its rest is left as it is.
            continue
        else:
            have = matrix.to_3x3() @ axis
        if have.length <= 1.0e-9:
            continue
        before = _angle(have, want)
        head = matrix.translation.copy()
        turn = have.normalized().rotation_difference(want)
        matrix = (mathutils.Matrix.Translation(head)
                  @ turn.to_matrix().to_4x4()
                  @ mathutils.Matrix.Translation(-head) @ matrix)
        pose_bone.matrix = inverse @ matrix
        bpy.context.view_layer.update()
        if child is not None:
            after = _angle(world.to_3x3() @ (child.head - pose_bone.head), want)
        else:
            after = _angle((world @ pose_bone.matrix).to_3x3() @ axis, want)
        rows.append({"source": source_name, "target": target_name,
                     "was_off_deg": round(before, 2),
                     "left_off_deg": round(after, 2)})
        turned += 1
        if after > worst:
            worst, worst_at = after, source_name
    if not turned:
        return None, "None of the mapped bones could be aimed"

    try:
        bpy.ops.arp.redefine_rest_pose(preserve=True, rest_pose='CURRENT')
    except Exception:
        return None, "Redefining the source rest pose failed"
    try:
        bpy.ops.arp.save_pose_rest()
    except Exception:
        return None, "Saving the redefined rest pose failed"
    stored = "rest_transf_offset" in scene.keys()
    preserved = bool(source.get("remap_redefine_preserve"))
    if not (stored and preserved):
        return None, ("The rest pose correction did not take: "
                      "rest_transf_offset=%s preserve=%s"
                      % (stored, preserved))
    rows.sort(key=lambda row: -row["was_off_deg"])
    return {"aligned": turned,
            "worst_left_deg": round(worst, 2), "worst_bone": worst_at,
            "biggest_corrections": rows[:8],
            "stored": stored, "preserve": preserved}, ""


def _chain_child(source, target, pose_bone, bone, chain):
    """The source bone that continues this one's line, or None.

    A bone's own axis is a convention, not anatomy: where a bone has several
    children (hips, chest) or no length (CMU's hand), the BVH importer and the
    FBX importer point it differently -- measured, 180 degrees apart on the
    same clip. Aiming that axis made the rest correction, and so the whole
    baked motion, depend on the file format: the chest of 79_22 came out 180
    degrees apart between the BVH and the same motion as FBX. The line from
    the bone to the next joint is the same in every format. The next joint is
    the mapped descendant whose rig bone starts where this rig bone ends;
    failing that, the bone's only child (an end bone such as ``_end``).
    Bones that start at this bone's own head give no line and are passed
    over: CMU's chest has its neck and both collarbones there, and an FBX
    round trip leaves them 1e-7 apart, which read as a direction.
    """
    reach = max((b.head_local.length for b in source.data.bones), default=1.0)
    near = 1.0e-4 * max(reach, 1.0e-6)
    best, best_gap = None, None
    for other_source, other_target in chain:
        other = source.pose.bones.get(other_source)
        goal = target.data.bones.get(other_target)
        if other is None or goal is None or other_source == pose_bone.name:
            continue
        if pose_bone.name not in {p.name for p in other.parent_recursive}:
            continue
        if (other.head - pose_bone.head).length <= near:
            continue
        gap = (goal.head_local - bone.tail_local).length
        if best_gap is None or gap < best_gap:
            best, best_gap = other, gap
    if best is None and len(pose_bone.children) == 1:
        best = pose_bone.children[0]
    if best is not None and (best.head - pose_bone.head).length <= near:
        return None
    return best


def _angle(vector, want):
    if vector.length <= 1.0e-9:
        return 180.0
    return math.degrees(vector.normalized().angle(want))


def _discard_imported(source):
    """Remove an imported armature with the action and the armature data it brought."""
    action = source.animation_data.action if source.animation_data else None
    data = source.data
    bpy.data.objects.remove(source, do_unlink=True)
    if action is not None and action.users == 0:
        bpy.data.actions.remove(action)
    if data is not None and data.users == 0:
        bpy.data.armatures.remove(data)


def import_motion(filepath, match_fps=True):
    """Bring a motion file in and return its armature. ``(object, error)``.

    Blender's BVH importer is a core add-on that is NOT on by default, and the
    failure is confusing: ``bpy.ops.import_anim.bvh`` passes ``hasattr`` and then
    raises "could not be found" when called. Enabling it first is the whole fix.

    ``match_fps`` resamples the clip to the scene's frame rate. Without it one
    BVH sample becomes one Blender frame whatever the clip's own rate was, and
    the CMU files are 120fps: on a 24fps scene that is five times slow motion,
    so a 240-frame bake covers two seconds of performance and the test file
    looks like the character is barely moving.
    """
    if not filepath or not os.path.isfile(filepath):
        return None, "No such file: %s" % filepath
    extension = os.path.splitext(filepath)[1].lower()
    before = set(bpy.data.objects.keys())
    if extension == ".bvh":
        if not _enable("io_anim_bvh"):
            return None, "The BVH importer add-on could not be enabled"
        try:
            bpy.ops.import_anim.bvh(filepath=filepath, global_scale=1.0,
                                    frame_start=1,
                                    use_fps_scale=bool(match_fps),
                                    update_scene_fps=False,
                                    update_scene_duration=True,
                                    rotate_mode="NATIVE",
                                    axis_forward="-Z", axis_up="Y")
        except Exception:
            return None, "BVH import failed. Check the file."
    elif extension == ".fbx":
        if not _enable("io_scene_fbx"):
            return None, "The FBX importer add-on could not be enabled"
        try:
            # Leaf bones are kept: an FBX written without end bones has its
            # head and toes as the leaves, and ignoring leaves dropped them
            # (measured: 20 of 23 bones mapped). Where a file does carry end
            # bones they stay unmapped and give the last joint its direction.
            bpy.ops.import_scene.fbx(filepath=filepath,
                                     ignore_leaf_bones=False,
                                     automatic_bone_orientation=True)
        except Exception:
            return None, "FBX import failed. Check the file."
    else:
        return None, "Only .bvh and .fbx are handled, not %r" % extension
    fresh = [bpy.data.objects[n] for n in bpy.data.objects.keys()
             if n not in before]
    armatures = [o for o in fresh if o.type == "ARMATURE"]
    if not armatures:
        for obj in fresh:
            bpy.data.objects.remove(obj, do_unlink=True)
        return None, "That file brought in no armature"
    keep = armatures[0]
    for obj in fresh:
        if obj is not keep and obj.type != "ARMATURE":
            bpy.data.objects.remove(obj, do_unlink=True)
    if keep.animation_data is None or keep.animation_data.action is None:
        for obj in armatures:
            _discard_imported(obj)
        return None, "The imported armature carries no action"
    return keep, ""


def retarget(source, target, preset="CMU", frame_start=1, frame_end=0,
             fingers=False, auto_scale=True, remove_source=True,
             align_rest_pose=True, toes=None):
    """Bake the source's action onto the target's controllers. ``(report, error)``.

    ``preset`` names a map from :func:`presets`; ``"AUTO"`` keeps whatever ARP
    guessed, which is worth a look but should be read before it is trusted.
    """
    if source is None or source.type != "ARMATURE":
        return None, "No source armature"
    if target is None or target.type != "ARMATURE":
        return None, "No target armature"
    if not hasattr(bpy.ops, "arp") or not hasattr(bpy.ops.arp, "retarget"):
        return None, ("Auto-Rig Pro's Remap module is not available in this "
                      "Blender; it is what does the baking")
    action = source.animation_data.action if source.animation_data else None
    if action is None:
        return None, "The source armature carries no action"
    scene = bpy.context.scene
    for name in ("source_rig", "target_rig", "source_action"):
        if not hasattr(scene, name):
            return None, "Auto-Rig Pro's Remap properties are missing"
    scene.source_rig = source.name
    scene.target_rig = target.name
    try:
        scene.source_action = action.name
    except Exception:
        pass
    for obj in bpy.context.view_layer.objects:
        obj.select_set(False)
    target.select_set(True)
    bpy.context.view_layer.objects.active = target
    try:
        bpy.ops.arp.build_bones_list()
    except Exception:
        return None, "Building the bone list failed"

    preset = str(preset).upper()
    keys = {bone_key(b.name) for b in source.data.bones}
    family = "HUMANIK" if preset == "MIXAMO" else preset
    for other, marks in SIGNATURE.items():
        if (family in SIGNATURE and other != family and any(m in keys for m in marks)
                and not any(m in keys for m in SIGNATURE[family])):
            return None, ("This clip has %s bones (%s); choose that skeleton, "
                          "not %s" % (other, ", ".join(m for m in marks if m in keys), preset))
    if toes is None:
        toes = TOES_BY_DEFAULT.get(preset, True)
    wanted = dict(PRESETS.get(preset) or {})
    if preset == "CMU":
        for base, hand in CMU_HAND_FALLBACK.items():
            if base not in keys and hand in keys:
                wanted[hand] = wanted.pop(base)
    if not toes:
        for name in TOE_SOURCES:
            wanted.pop(name, None)
    if fingers:
        wanted.update(FINGERS.get(preset) or {})
    have = {b.name for b in target.pose.bones}
    applied, missing, unmapped, taken = 0, [], [], set()
    if wanted:
        for item in scene.bones_map_v2:
            key = bone_key(item.source_bone)
            goal = wanted.get(key)
            if goal is None or key in taken:
                item.name = "None"
                unmapped.append(item.source_bone)
                continue
            taken.add(key)
            if goal not in have:
                item.name = "None"
                missing.append("%s -> %s" % (item.source_bone, goal))
                continue
            item.name = goal
            applied += 1
            if goal == "c_root_master.x":
                try:
                    item.set_as_root = True
                except Exception:
                    pass
    if auto_scale:
        try:
            bpy.ops.arp.auto_scale()
        except Exception:
            return None, "Auto scale failed"
    aligned = None
    if align_rest_pose:
        aligned, error = align_rest(source, target, skip=REST_KEEP + REST_SKIP_ENDS)
        if error:
            return None, "Rest pose alignment failed: %s" % error
    last = int(action.frame_range[1])
    # Bake from the clip's first key, not before it: the FBX importer can place
    # a clip one frame in, and a held copy of the first frame in front of it
    # hides the reference pose from reference_frame().
    frame_start = max(int(frame_start), int(round(action.frame_range[0])))
    end = int(frame_end) if int(frame_end) > 0 else last
    end = max(int(frame_start), min(end, last))
    try:
        bpy.ops.arp.retarget(frame_start=int(frame_start), frame_end=end,
                             freeze_source='NO', freeze_target='NO',
                             interpolation_type='LINEAR',
                             handle_type='DEFAULT')
    except Exception:
        return None, "Retarget failed"
    # ARP bakes Hips rotation but drops the set_as_root translation on this
    # SmartRig path. Restore the source Hips XYZ translation delta on the
    # mapped root controller; preserve all ARP-baked rotations and scales.
    src_hips = source.pose.bones.get("Hips")
    dst_root = target.pose.bones.get("c_root_master.x")
    if src_hips is not None and dst_root is not None:
        saved = scene.frame_current
        scene.frame_set(int(frame_start))
        base = source.matrix_world @ src_hips.head
        axis = dst_root.bone.matrix_local.to_3x3()
        for frame in range(int(frame_start), end + 1):
            scene.frame_set(frame)
            delta = (source.matrix_world @ src_hips.head) - base
            local_delta = axis.transposed() @ delta
            for index in range(3):
                dst_root.location[index] = local_delta[index]
                dst_root.keyframe_insert(data_path="location", index=index, frame=frame)
        scene.frame_set(saved)
    baked = target.animation_data.action if target.animation_data else None
    name = source.name
    if remove_source:
        bpy.data.objects.remove(source, do_unlink=True)
    scene.frame_start = int(frame_start)
    scene.frame_end = end
    return {"source": name, "target": target.name, "preset": preset,
            "mapped": applied, "missing": missing, "unmapped": unmapped[:8],
            "fingers": bool(fingers), "toes": bool(toes), "note": None if fingers else FINGER_NOTE,
            "action": baked.name if baked else None,
            "rest_aligned": aligned,
            "frames": [int(frame_start), end]}, ""


REFERENCE_JUMP_M = 0.05
REFERENCE_RATIO = 10.0
REFERENCE_BONES = ("thigh_stretch.l", "thigh_stretch.r", "foot.l", "foot.r",
                   "spine_01.x")


def reference_frame(armature, frame):
    """Is ``frame`` a reference pose the clip jumps away from? ``(skip, [mm, mm])``.

    The CMU files open on a calibration T-pose: frame 1 is that pose and the
    performance starts at frame 2, so after the retarget the body teleports
    between them -- measured on MIK, 354 mm into frame 2 on 05_17 against 3.6 mm
    for the frame after. Swing and cloth baked from frame 1 start through that
    jump, and cloth is left inside the body for the first frames. The frame
    counts as a reference when the largest move of the hips, feet and spine to
    the next frame is over 50 mm and over ten times the move after it. The two
    moves are returned in millimetres of real size: Blender units times the
    scene's unit scale, so a centimetre scene is judged the same as a metre one.
    """
    scene = bpy.context.scene
    unit = float(scene.unit_settings.scale_length or 1.0)
    bones = [armature.pose.bones.get(n) for n in REFERENCE_BONES]
    bones = [b for b in bones if b is not None]
    if not bones:
        bones = [b for b in armature.pose.bones if b.bone.use_deform]
    if not bones:
        return False, [0.0, 0.0]
    saved = scene.frame_current
    heads = []
    try:
        for f in (frame, frame + 1, frame + 2):
            scene.frame_set(f)
            heads.append([(armature.matrix_world @ b.head).copy() for b in bones])
    finally:
        scene.frame_set(saved)
    first = max((a - b).length for a, b in zip(heads[0], heads[1])) * unit
    then = max((a - b).length for a, b in zip(heads[1], heads[2])) * unit
    skip = first > REFERENCE_JUMP_M and first > REFERENCE_RATIO * max(then, 1.0e-6)
    return skip, [round(first * 1000, 1), round(then * 1000, 1)]


def load(filepath, target, preset="CMU", frame_start=1, frame_end=0,
         fingers=False, auto_scale=True, remove_source=True,
         align_rest_pose=True, match_fps=True, skip_reference_frame=True, toes=None):
    """Import a motion file and put it on the rig in one go. ``(report, error)``.

    ``skip_reference_frame`` starts the scene one frame later when the clip
    opens on a reference pose (see :func:`reference_frame`); the key stays.
    """
    view_layer = bpy.context.view_layer
    active_before = view_layer.objects.active
    mode_before = active_before.mode if active_before is not None else "OBJECT"
    selected_before = list(bpy.context.selected_objects)
    scene = bpy.context.scene
    range_before = scene.frame_start, scene.frame_end

    def refuse(message):
        # A refused clip leaves the scene as it found it: the importer already moved the
        # scene's range, the active object and the selection.
        scene.frame_start, scene.frame_end = range_before
        view_layer.objects.active = active_before
        for obj in selected_before:
            obj.select_set(True)
        # Importers leave Edit/Pose mode even when retargeting is refused.
        # Restore the original editor state with the original active object.
        if active_before is not None and active_before.mode != mode_before:
            bpy.ops.object.mode_set(mode=mode_before)
        return None, message

    source, error = import_motion(filepath, match_fps=match_fps)
    if error:
        return refuse(error)
    report, error = retarget(source, target, preset=preset,
                             frame_start=frame_start, frame_end=frame_end,
                             fingers=fingers, auto_scale=auto_scale,
                             remove_source=remove_source,
                             align_rest_pose=align_rest_pose, toes=toes)
    if error:
        if source is not None and source.name in bpy.data.objects:
            _discard_imported(source)
        return refuse(error)
    # The import and the retarget move the active object and the selection; removing the
    # imported armature leaves no active object at all. Hand the user's own back.
    if active_before is not None and active_before.name in bpy.data.objects:
        view_layer.objects.active = active_before
        for obj in selected_before:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
    report["file"] = os.path.basename(filepath)
    report["reference_frame_skipped"] = False
    start, end = int(report["frames"][0]), int(report["frames"][1])
    if skip_reference_frame and end - start >= 2:
        skip, jumps = reference_frame(target, start)
        report["start_jump_mm"] = jumps
        if skip:
            scene = bpy.context.scene
            scene.frame_start = start + 1
            scene.frame_set(start + 1)
            report["frames"] = [start + 1, end]
            report["reference_frame_skipped"] = True
    return report, ""


def bound_meshes(armature):
    """Meshes this armature actually deforms."""
    rows = []
    for obj in bpy.data.objects:
        if obj.type != "MESH" or not len(obj.vertex_groups):
            continue
        for modifier in obj.modifiers:
            if modifier.type == "ARMATURE" and modifier.object is armature:
                rows.append(obj)
                break
    return rows


def check(armature, meshes=None, frame_start=1, frame_end=0, step=8,
          low=0.5, high=2.0, min_edge_mm=0.5, keep_modifiers=(),
          rest_from_pose=True, ripple=True):
    """Does the character survive the motion? ``(report, error)``.

    Every edge is compared with its own rest length and counted when it leaves
    ``[low, high]``. The count alone is not useful; what is useful is the pair of
    vertex groups the broken edge's ends belong to, because that names the thing
    that is wrong -- "the belt is on the elbow bend bone", "the collar links are
    on the shoulder" -- without anybody having to scrub the timeline.

    **The baseline is the armature's rest pose**, not frame 1. After a retarget,
    frame 1 is the clip's first posed frame, and taking lengths there normalises
    whatever is already broken to 1.0 -- the worst frame of a bad rig can read
    perfectly clean. ``rest_from_pose=False`` goes back to frame ``frame_start``
    for a file whose rest pose is not the modelled shape.

    **The whole distribution, not just the tail.** Counting only the edges
    outside the band cannot tell "nothing moved wrongly" from "everything moved
    wrongly by the same factor": an island collapsed onto one weight vector, or
    a part riding a bone that scales, shrinks uniformly and every ratio stays
    inside the band. ``mean``/``p99``/``spread`` are reported per mesh.

    **``ripple``** measures what the band cannot: the checkerboard a weight edit
    leaves. It is the change, from rest, in how far each vertex sits from the
    mean of its neighbours -- a sub-millimetre excursion along the normal that
    moves an edge ratio by 0.005 and is invisible to any band.

    **Denominators are reported.** ``edges``, ``edges_skipped`` and
    ``frames_skipped`` say how much was actually looked at, so a mesh whose
    edges were all filtered out cannot be mistaken for a mesh that passed.

    This walks the edges of the STORED mesh and reads coordinates from the
    evaluated one, so anything that changes the vertex count makes the two
    incomparable. Leaving a Subdivision on does not make the measurement more
    realistic, it makes it meaningless -- and leaving a clamp on while the
    Subdivision in front of it is off measures a stack that never exists.
    Measured while getting this wrong: a Shrinkwrap spared behind a suspended
    Subdivision read 41.71 % of the belt as broken, against 0.15 % for the same
    file. Use ``costume_bind.penetration(full_stack=True)`` to judge a clamp.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    scene = bpy.context.scene
    targets = list(meshes) if meshes else bound_meshes(armature)
    if not targets:
        return None, "This armature deforms no mesh with vertex groups"
    end = int(frame_end) if int(frame_end) > 0 else int(scene.frame_end)
    start = int(frame_start)
    if end < start:
        return None, "The frame range is empty"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    spare = {"ARMATURE"} | {str(k).upper() for k in keep_modifiers or ()}

    hidden = []
    saved_frame = scene.frame_current
    saved_pose = armature.data.pose_position
    pairs = {}
    per_mesh = {}
    stats = {}
    frames_skipped = {}
    try:
        for obj in targets:
            for modifier in obj.modifiers:
                if modifier.type not in spare and modifier.show_viewport:
                    modifier.show_viewport = False
                    hidden.append(modifier)

        dominant = {}
        for obj in targets:
            by_index = {g.index: g.name for g in obj.vertex_groups}
            rows = []
            for vertex in obj.data.vertices:
                best, weight = None, 0.0
                for entry in vertex.groups:
                    name = by_index.get(entry.group)
                    if name in deform and entry.weight > weight:
                        best, weight = name, entry.weight
                rows.append(best)
            dominant[obj.name] = rows

        def world(obj):
            bpy.context.view_layer.update()
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated = obj.evaluated_get(depsgraph)
            matrix = obj.matrix_world
            return [matrix @ v.co for v in evaluated.data.vertices]

        def neighbours(obj):
            rows = [[] for _ in obj.data.vertices]
            for edge in obj.data.edges:
                a, b = edge.vertices
                if max(a, b) < len(rows):
                    rows[a].append(b)
                    rows[b].append(a)
            return rows

        if rest_from_pose:
            armature.data.pose_position = "REST"
        else:
            scene.frame_set(start)
        rest = {obj.name: world(obj) for obj in targets}
        near = {obj.name: neighbours(obj) for obj in targets} if ripple else {}

        def bumps(obj, points):
            rows = near.get(obj.name) or []
            out = []
            for index, links in enumerate(rows):
                if not links or index >= len(points):
                    out.append(0.0)
                    continue
                total = mathutils.Vector((0.0, 0.0, 0.0))
                for other in links:
                    total = total + points[other]
                out.append((points[index] - total / len(links)).length)
            return out

        rest_bump = {obj.name: bumps(obj, rest[obj.name]) for obj in targets} \
            if ripple else {}

        edges = {}
        skipped = {}
        for obj in targets:
            at = rest[obj.name]
            kept, dropped = [], 0
            for edge in obj.data.edges:
                a, b = edge.vertices
                if max(a, b) >= len(at):
                    dropped += 1
                    continue
                if (at[a] - at[b]).length * 1000 <= min_edge_mm:
                    dropped += 1
                    continue
                kept.append((a, b))
            edges[obj.name] = kept
            skipped[obj.name] = dropped

        armature.data.pose_position = "POSE"
        for frame in range(start, end + 1, max(1, int(step))):
            scene.frame_set(frame)
            for obj in targets:
                now = world(obj)
                at = rest[obj.name]
                if len(now) != len(at):
                    frames_skipped[obj.name] = frames_skipped.get(obj.name, 0) + 1
                    continue
                row = stats.setdefault(obj.name, [0, 0.0, 0.0, []])
                for a, b in edges[obj.name]:
                    span = (at[a] - at[b]).length
                    ratio = (now[a] - now[b]).length / span
                    row[0] += 1
                    row[1] += ratio
                    row[2] = max(row[2], abs(ratio - 1.0))
                    if len(row[3]) < 20000:
                        row[3].append(ratio)
                    if low <= ratio <= high:
                        continue
                    key = (obj.name, dominant[obj.name][a] or "?",
                           dominant[obj.name][b] or "?")
                    slot = pairs.setdefault(key, [0, 9.9, 0.0, frame])
                    slot[0] += 1
                    if ratio < slot[1]:
                        slot[1], slot[3] = round(ratio, 4), frame
                    slot[2] = max(slot[2], round(ratio, 4))
                    mrow = per_mesh.setdefault(obj.name, [0, 9.9, 0.0, set()])
                    mrow[0] += 1
                    mrow[1] = min(mrow[1], round(ratio, 4))
                    mrow[2] = max(mrow[2], round(ratio, 4))
                    mrow[3].add(a)
                    mrow[3].add(b)
                if ripple and rest_bump.get(obj.name):
                    was = rest_bump[obj.name]
                    now_bump = bumps(obj, now)
                    worst = 0.0
                    for index, value in enumerate(now_bump):
                        if index < len(was):
                            worst = max(worst, abs(value - was[index]))
                    slot = stats.setdefault(obj.name, [0, 0.0, 0.0, []])
                    if len(slot) < 5:
                        slot.append(0.0)
                    slot[4] = max(slot[4], worst)
    finally:
        scene.frame_set(saved_frame)
        armature.data.pose_position = saved_pose
        for modifier in hidden:
            modifier.show_viewport = True

    def summary(name):
        row = stats.get(name)
        if not row or not row[0]:
            return {}
        ordered = sorted(row[3])
        at99 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.99))] \
            if ordered else 1.0
        out = {"edges_sampled": row[0],
               "mean": round(row[1] / row[0], 4),
               "p99": round(at99, 4),
               "spread": round(row[2], 4)}
        if len(row) > 4:
            out["ripple_mm"] = round(row[4] * 1000.0, 4)
        return out

    worst = sorted(pairs.items(), key=lambda kv: -kv[1][0])[:12]
    rows = {}
    for obj in targets:
        row = per_mesh.get(obj.name)
        entry = {"samples": row[0] if row else 0,
                 "min": row[1] if row else None,
                 "max": row[2] if row else None,
                 "vertices": len(row[3]) if row else 0,
                 "percent": round(100.0 * len(row[3])
                                  / max(1, len(rest.get(obj.name, []))), 2)
                 if row else 0.0,
                 "edges": len(edges.get(obj.name, [])),
                 "edges_skipped": skipped.get(obj.name, 0),
                 "frames_skipped": frames_skipped.get(obj.name, 0)}
        entry.update(summary(obj.name))
        rows[obj.name] = entry
    ordered = dict(sorted(rows.items(), key=lambda kv: -kv[1]["samples"]))
    return {"armature": armature.name, "meshes": len(targets),
            "frames": [start, end, int(step)],
            "band": [low, high],
            "rest": "rest pose" if rest_from_pose else "frame %d" % start,
            "per_mesh": ordered,
            "worst_pairs": [{"mesh": k[0], "bone_a": k[1], "bone_b": k[2],
                             "samples": v[0], "min": v[1], "max": v[2],
                             "frame": v[3]} for k, v in worst],
            "clean": not per_mesh}, ""


def register() -> bool:
    return generation.mark_module_registered(__name__, True)


def unregister() -> dict:
    generation.mark_module_registered(__name__, False)
    return {"all_removed": True}
