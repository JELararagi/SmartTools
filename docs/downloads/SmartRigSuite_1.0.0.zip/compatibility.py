# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()


import functools
import sys
from dataclasses import dataclass
from typing import Any

import bpy
from bpy.app.handlers import persistent

from . import generation

from .external_tools import PROXY_SUFFIXES, find_enabled_addon_key
from .preferences import get_preferences


@dataclass
class _GuardRecord:
    module: Any
    attribute: str
    original: Any
    guarded: Any


_PROXY_GUARDS: list[_GuardRecord] = []
_RETRY_COUNT = 0
_MAX_RETRIES = 6
_REGISTERED = False


def _guard_enabled() -> bool:
    preferences = get_preferences()
    return bool(getattr(preferences, "guard_proxy_picker_context", False)) if preferences is not None else False


def _is_restricted_context_error(exc: BaseException) -> bool:
    text = f"{type(exc).__name__}: {exc}"
    return "_RestrictContext" in text or any(
        token in text
        for token in (
            "has no attribute 'scene'",
            "has no attribute 'active_object'",
            "has no attribute 'selected_pose_bones'",
            "has no attribute 'active_pose_bone'",
        )
    )


def _looks_like_proxy_handler(func: Any, enabled_key: str) -> bool:
    if not callable(func):
        return False
    if bool(getattr(func, "_srs_context_guard", False)):
        return False
    module_name = str(getattr(func, "__module__", ""))
    function_name = str(getattr(func, "__name__", ""))
    if function_name != "proxy_picker":
        return False
    lower = module_name.lower()
    key_lower = enabled_key.lower()
    return lower == key_lower + ".proxy_picker" or lower.endswith(".proxy_picker")


def _make_guard(original):
    @persistent
    @functools.wraps(original)
    def guarded(*args, **kwargs):
        context = bpy.context
        if not hasattr(context, "scene") or not hasattr(context, "active_object"):
            return None
        try:
            if len(args) > 1:
                return original(args[0])
            return original(*args, **kwargs)
        except AttributeError as exc:
            if _is_restricted_context_error(exc):
                return None
            raise
        except TypeError as exc:
            if "positional argument" in str(exc) and args:
                try:
                    return original(args[0])
                except AttributeError as nested:
                    if _is_restricted_context_error(nested):
                        return None
                    raise
            raise

    guarded._srs_context_guard = True
    guarded._srs_original = original
    return guarded


def install_proxy_picker_context_guard() -> bool:
    if not _guard_enabled():
        return False
    enabled_key = find_enabled_addon_key(PROXY_SUFFIXES)
    if not enabled_key:
        return False

    handlers = bpy.app.handlers.depsgraph_update_pre
    installed = False
    for index, func in enumerate(tuple(handlers)):
        if bool(getattr(func, "_srs_context_guard", False)):
            installed = True
            continue
        if not _looks_like_proxy_handler(func, enabled_key):
            continue
        guarded = _make_guard(func)
        handlers[index] = guarded
        module_name = str(getattr(func, "__module__", ""))
        module = sys.modules.get(module_name)
        attribute = str(getattr(func, "__name__", "proxy_picker"))
        if module is not None:
            try:
                if getattr(module, attribute, None) is func:
                    setattr(module, attribute, guarded)
            except Exception:
                pass
        _PROXY_GUARDS.append(_GuardRecord(module, attribute, func, guarded))
        try:
            generation.track_patch(
                collection=handlers,
                original=func,
                replacement=guarded,
                target_module=module,
                attribute=attribute,
                module_name=__name__,
            )
        except Exception:
            for current_index, current in enumerate(tuple(handlers)):
                if current is guarded:
                    handlers[current_index] = func
            if module is not None:
                try:
                    if getattr(module, attribute, None) is guarded:
                        setattr(module, attribute, func)
                except Exception:
                    pass
            _PROXY_GUARDS.pop()
            continue
        installed = True
    return installed


def remove_proxy_picker_context_guard() -> None:
    handlers = bpy.app.handlers.depsgraph_update_pre
    while _PROXY_GUARDS:
        record = _PROXY_GUARDS.pop()
        for index, func in enumerate(tuple(handlers)):
            if func is record.guarded:
                handlers[index] = record.original
        if record.module is not None:
            try:
                if getattr(record.module, record.attribute, None) is record.guarded:
                    setattr(record.module, record.attribute, record.original)
            except Exception:
                pass
        generation.untrack_patch(record.guarded, module_name=__name__)


def _cancel_retry() -> None:
    global _RETRY_COUNT
    _RETRY_COUNT = 0
    try:
        if bpy.app.timers.is_registered(_delayed_install):
            bpy.app.timers.unregister(_delayed_install)
    except Exception:
        pass
    generation.untrack_timer(_delayed_install, module_name=__name__)


def _delayed_install():
    global _RETRY_COUNT
    if not _guard_enabled() or not find_enabled_addon_key(PROXY_SUFFIXES):
        _RETRY_COUNT = 0
        return None
    if install_proxy_picker_context_guard():
        _RETRY_COUNT = 0
        return None
    _RETRY_COUNT += 1
    return 0.5 if _RETRY_COUNT < _MAX_RETRIES else None


def _schedule_retry_if_needed() -> None:
    global _RETRY_COUNT
    if not _guard_enabled() or not find_enabled_addon_key(PROXY_SUFFIXES):
        return
    _RETRY_COUNT = 0
    registered_now = False
    try:
        if not bpy.app.timers.is_registered(_delayed_install):
            bpy.app.timers.register(_delayed_install, first_interval=0.25, persistent=False)
            registered_now = True
    except TypeError:
        try:
            if not bpy.app.timers.is_registered(_delayed_install):
                bpy.app.timers.register(_delayed_install, first_interval=0.25)
                registered_now = True
        except Exception:
            return
    except Exception:
        return
    try:
        if registered_now or bpy.app.timers.is_registered(_delayed_install):
            generation.track_timer(_delayed_install, module_name=__name__)
    except Exception:
        try:
            if bpy.app.timers.is_registered(_delayed_install):
                bpy.app.timers.unregister(_delayed_install)
        except Exception:
            pass


@persistent
def _load_post(_dummy):
    if not _guard_enabled():
        set_guard_enabled(False)
        return
    remove_proxy_picker_context_guard()
    if not install_proxy_picker_context_guard():
        _schedule_retry_if_needed()


def set_guard_enabled(enabled: bool) -> None:
    enabled = bool(enabled)
    handlers = bpy.app.handlers.load_post
    if not enabled:
        _cancel_retry()
        try:
            while any(item is _load_post for item in tuple(handlers)):
                for item in tuple(handlers):
                    if item is _load_post:
                        handlers.remove(item)
                        break
        except Exception:
            pass
        generation.untrack_handler(_load_post, module_name=__name__)
        remove_proxy_picker_context_guard()
        return

    added = False
    try:
        if not any(item is _load_post for item in tuple(handlers)):
            handlers.append(_load_post)
            added = True
        generation.track_handler(handlers, _load_post, module_name=__name__, label="load_post")
    except Exception:
        if added:
            try:
                handlers.remove(_load_post)
            except Exception:
                pass
        return
    if not install_proxy_picker_context_guard():
        _schedule_retry_if_needed()


def sync_runtime_state() -> None:
    set_guard_enabled(_guard_enabled())


def _shutdown_runtime() -> None:
    """Stop every optional compatibility resource without retaining callbacks."""
    errors = []
    try:
        _cancel_retry()
    except Exception as exc:
        errors.append(f"timer: {type(exc).__name__}: {exc}")
    try:
        set_guard_enabled(False)
    except Exception as exc:
        errors.append(f"guard: {type(exc).__name__}: {exc}")
    try:
        _PROXY_GUARDS.clear()
    except Exception as exc:
        errors.append(f"cache: {type(exc).__name__}: {exc}")
    if errors:
        raise RuntimeError("; ".join(errors))


def register() -> bool:
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False
    generation.assert_module_context(__name__, __srs_revision__, __srs_module_generation_marker__)
    try:
        sync_runtime_state()
        generation.track_cleanup(
            _shutdown_runtime,
            module_name=__name__,
            label="compatibility handler, timer, patch, and cache shutdown",
        )
    except Exception:
        try:
            _shutdown_runtime()
        except Exception:
            pass
        raise
    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    return True


def unregister() -> dict:
    global _REGISTERED
    errors = []
    try:
        set_guard_enabled(False)
    except Exception as exc:
        errors.append(f"guard: {type(exc).__name__}: {exc}")
    resource_report = generation.cleanup_non_ui_resources(module_name=__name__)
    errors.extend(resource_report.get("errors", ()))
    if resource_report.get("all_removed"):
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return {
        "all_removed": bool(resource_report.get("all_removed")),
        "resources": resource_report,
        "errors": errors,
    }
