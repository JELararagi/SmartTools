"""Suite-local enforcement for SmartTools registration contracts."""

from __future__ import annotations

import sys
from contextlib import contextmanager

import bpy


_PACKAGE = __package__ or ""
_SUITE_ID = _PACKAGE.rsplit(".", 1)[-1]
if _SUITE_ID == "smart_rig_suite":
    __srs_revision__ = "2.26.0"
_ROOT_LABELS = {
    "smart_file_suite": "Smart File",
    "smart_workspace_suite": "Smart Workspace",
    "smart_overlay_suite": "Smart Overlay",
    "smart_transform_suite": "Smart Transform",
    "smart_id_suite": "Smart ID",
    "smart_geometry_suite": "Smart Geometry",
    "smart_camlight_suite": "Smart CamLight",
    "smart_modeling_suite": "Smart Modeling",
    "smart_modifier_suite": "Smart Modifier",
    "smart_sculpt_suite": "Smart Sculpt",
    "smart_shapekey_suite": "Smart Shapekey",
    "smart_uv_suite": "Smart UV",
    "smart_paint_suite": "Smart Paint",
    "smart_shader_suite": "Smart Shader",
    "smart_rig_suite": "Smart Rig",
    "smart_cloth_suite": "Smart Cloth",
    "smart_animation_suite": "Smart Animation",
    "smart_selector_suite": "Smart Selector",
    "smart_render_suite": "Smart Render",
    "smart_node_suite": "Smart Node",
    "smart_composite_suite": "Smart Composite",
}
_ROOT_IDS = {
    "smart_file_suite": {"SFS_PT_file_clip", "SFS_PT_file_dopesheet", "SFS_PT_file_browser", "SFS_PT_file_graph", "SFS_PT_file_image", "SFS_PT_file_nla", "SFS_PT_file_node", "SFS_PT_file_sequence", "SFS_PT_file_spreadsheet", "SFS_PT_file_text", "SF_PT_reference_manager_reference_manager_workspace"},
    "smart_workspace_suite": {"NPTL_PT_properties_root_clip_editor", "NPTL_PT_properties_root_dopesheet_editor", "NPTL_PT_properties_root_file_browser", "NPTL_PT_properties_root_graph_editor", "NPTL_PT_properties_root_image_editor", "NPTL_PT_properties_root_nla_editor", "NPTL_PT_properties_root_node_editor", "NPTL_PT_properties_root_sequence_editor", "NPTL_PT_properties_root_spreadsheet", "NPTL_PT_properties_root_text_editor", "NPTL_PT_properties_root"},
    "smart_overlay_suite": {"VIEW3D_PT_sos_root", "IMAGE_PT_sos_root", "NODE_PT_sos_root", "SEQUENCER_PT_sos_root", "CLIP_PT_sos_root", "DOPESHEET_PT_sos_root", "GRAPH_PT_sos_root", "NLA_PT_sos_root", "TEXT_PT_sos_root", "FILEBROWSER_PT_sos_root", "SPREADSHEET_PT_sos_root"},
    "smart_transform_suite": {"SMART_TRANSFORM_PT_core_suite"},
    "smart_id_suite": {"SMARTID_PT_clip_editor_root", "SMARTID_PT_dopesheet_editor_root", "SMARTID_PT_file_browser_root", "SMARTID_PT_graph_editor_root", "SMARTID_PT_image_editor_root", "SMARTID_PT_nla_editor_root", "SMARTID_PT_node_editor_root", "SMARTID_PT_sequence_editor_root", "SMARTID_PT_spreadsheet_root", "SMARTID_PT_text_editor_root", "SMARTID_PT_main"},
    "smart_geometry_suite": {"CLIP_PT_sgs_root", "DOPESHEET_PT_sgs_root", "FILEBROWSER_PT_sgs_file_root", "GRAPH_PT_sgs_graph_root", "IMAGE_PT_sgs_image_root", "NLA_PT_sgs_root", "NODE_PT_sgs_geometry_root", "SEQUENCER_PT_sgs_root", "SPREADSHEET_PT_sgs_root", "TEXT_PT_sgs_root", "VIEW3D_PT_sgs_root"},
    "smart_camlight_suite": {"CLIP_PT_scls_root", "DOPESHEET_PT_scls_root", "FILEBROWSER_PT_scls_root", "GRAPH_PT_scls_root", "IMAGE_PT_scls_image_root", "NLA_PT_scls_root", "NODE_PT_scls_shader_root", "SEQUENCER_PT_scls_root", "SPREADSHEET_PT_scls_root", "TEXT_PT_scls_root", "VIEW3D_PT_scls_root"},
    "smart_modeling_suite": {"CLIP_PT_sms_hub", "DOPESHEET_PT_sms_hub", "FILEBROWSER_PT_sms_hub", "GRAPH_PT_sms_hub", "IMAGE_PT_sms_hub", "NLA_PT_sms_hub", "NODE_PT_sms_hub", "SEQUENCER_PT_sms_hub", "SPREADSHEET_PT_sms_hub", "TEXT_PT_sms_hub", "VIEW3D_PT_sms_hub"},
    "smart_modifier_suite": {"VIEW3D_PT_smart_modifier_root_panel"},
    "smart_sculpt_suite": {"SSS_PT_FIXED_CLIP", "SSS_PT_FIXED_DOPESHEET", "SSS_PT_FIXED_FILE", "SSS_PT_FIXED_GRAPH", "SSS_PT_FIXED_IMAGE", "SSS_PT_FIXED_NLA", "SSS_PT_FIXED_NODE", "SSS_PT_FIXED_VSE", "SSS_PT_FIXED_SPREADSHEET", "SSS_PT_FIXED_TEXT", "SSS_PT_FIXED_VIEW3D"},
    "smart_shapekey_suite": {"SKM_PT_clip_editor_root", "SKM_PT_dopesheet_editor_root", "SKM_PT_file_browser_root", "SKM_PT_graph_editor_root", "SKM_PT_image_editor_root", "SKM_PT_nla_editor_root", "SKM_PT_node_editor_root", "SKM_PT_sequence_editor_root", "SKM_PT_spreadsheet_root", "SKM_PT_text_editor_root", "SKM_PT_view3d_root"},
    "smart_uv_suite": {"SMARTUVSUITE_PT_1881_CLIP_EDITOR_BODY", "SMARTUVSUITE_PT_1881_DOPESHEET_EDITOR_BODY", "SMARTUVSUITE_PT_1881_FILE_BROWSER_BODY", "SMARTUVSUITE_PT_1881_GRAPH_EDITOR_BODY", "SMARTUVSUITE_PT_1881_UV_EDITOR_BODY", "SMARTUVSUITE_PT_1881_NLA_EDITOR_BODY", "SMARTUVSUITE_PT_1881_NODE_EDITOR_BODY", "SMARTUVSUITE_PT_1881_SEQUENCE_EDITOR_BODY", "SMARTUVSUITE_PT_1881_SPREADSHEET_BODY", "SMARTUVSUITE_PT_1881_TEXT_EDITOR_BODY", "SMARTUVSUITE_PT_1881_VIEW3D_BODY"},
    "smart_paint_suite": {"SPS_PT_root_movie_clip_editor", "SPS_PT_root_dope_sheet", "SPS_PT_root_file_browser", "SPS_PT_root_graph_editor", "SPS_PT_lightweight_image_editor", "SPS_PT_root_nla_editor", "SPS_PT_root_node_editor", "SPS_PT_root_video_sequencer", "SPS_PT_root_spreadsheet", "SPS_PT_root_text_editor", "SPS_PT_lightweight_view3d"},
    "smart_shader_suite": {"SSS_PT_shader_tools_movie_clip_editor", "SSS_PT_shader_tools_dope_sheet", "SSS_PT_shader_tools_file_browser", "SSS_PT_shader_tools_graph_editor", "SSS_PT_shader_tools_image_editor", "SSS_PT_shader_tools_nla_editor", "SSS_PT_shader_tools_shader_editor", "SSS_PT_shader_tools_video_sequencer", "SSS_PT_shader_tools_spreadsheet", "SSS_PT_shader_tools_text_editor", "SSS_PT_shader_tools"},
    "smart_rig_suite": {"CLIP_PT_smart_rig_root", "DOPESHEET_PT_smart_rig_root", "FILEBROWSER_PT_smart_rig_root", "FILEBROWSER_PT_smart_rig_asset_root", "GRAPH_PT_smart_rig_root", "IMAGE_PT_smart_rig_root", "NLA_PT_smart_rig_root", "NODE_PT_smart_rig_root", "SEQUENCER_PT_smart_rig_root", "SPREADSHEET_PT_smart_rig_root", "TEXT_PT_smart_rig_root", "SRS_PT_smart_rig"},
    "smart_cloth_suite": {"SMARTCLOTHSUITE_PT_main_panel_clip_v283", "SMARTCLOTHSUITE_PT_main_panel_dopesheet_v283", "SMARTCLOTHSUITE_PT_main_panel_file_v283", "SMARTCLOTHSUITE_PT_main_panel_graph_v283", "SMARTCLOTHSUITE_PT_main_panel_image_v283", "SMARTCLOTHSUITE_PT_main_panel_nla_v283", "SMARTCLOTHSUITE_PT_main_panel_node_v283", "SMARTCLOTHSUITE_PT_main_panel_sequence_v283", "SMARTCLOTHSUITE_PT_main_panel_spreadsheet_v283", "SMARTCLOTHSUITE_PT_main_panel_text_v283", "SMARTCLOTHSUITE_PT_main_panel_view3d_v283"},
    "smart_animation_suite": {"SAS_PT_main_clip", "SAS_PT_main_dopesheet", "SAS_PT_main_file_browser", "SAS_PT_main_graph", "SAS_PT_main_image", "SAS_PT_main_nla", "SAS_PT_main_node", "SAS_PT_main_sequence", "SAS_PT_main_spreadsheet", "SAS_PT_main_text", "SAS_PT_main"},
    "smart_selector_suite": {"SSSUITE_PT_root_clip_editor", "SSSUITE_PT_root_dopesheet_editor", "SSSUITE_PT_root_file_browser", "SSSUITE_PT_root_graph_editor", "SSSUITE_PT_root_image_editor", "SSSUITE_PT_root_nla_editor", "SSSUITE_PT_root_node_editor", "SSSUITE_PT_root_sequence_editor", "SSSUITE_PT_root_spreadsheet", "SSSUITE_PT_root_text_editor", "SSSUITE_PT_root_view_3d"},
    "smart_render_suite": {"SRR_CLIP_PT_ROOT", "SRR_DOPESHEET_PT_ROOT", "SRR_FILEBROWSER_PT_ROOT", "SRR_GRAPH_PT_ROOT", "SRR_IMAGE_PT_ROOT", "SRR_NLA_PT_ROOT", "SRR_NODE_PT_ROOT", "SRR_SEQUENCER_PT_ROOT", "SRR_SPREADSHEET_PT_ROOT", "SRR_TEXT_PT_ROOT", "SRR_PT_MAIN_PANEL"},
    "smart_node_suite": {"CLIP_PT_smart_node_suite", "DOPESHEET_PT_smart_node_suite", "FILEBROWSER_PT_smart_node_suite", "GRAPH_PT_smart_node_suite", "IMAGE_PT_smart_node_suite", "NLA_PT_smart_node_suite", "NODE_PT_smart_node_suite", "SEQUENCER_PT_smart_node_suite", "SPREADSHEET_PT_smart_node_suite", "TEXT_PT_smart_node_suite", "VIEW3D_PT_smart_node_suite"},
    "smart_composite_suite": {"SCOMP_PT_root_clip_editor", "SCOMP_PT_root_dopesheet_editor", "SCOMP_PT_root_file_browser", "SCOMP_PT_root_graph_editor", "SCOMP_PT_root_image_editor", "SCOMP_PT_root_nla_editor", "SCOMP_PT_root_compositor", "SCOMP_PT_root_sequence_editor", "SCOMP_PT_root_spreadsheet", "SCOMP_PT_root_text_editor", "SCOMP_PT_root_view_3d"},
}


def _owned_class(cls) -> bool:
    module_name = str(getattr(cls, "__module__", "") or "")
    return bool(_PACKAGE and (module_name == _PACKAGE or module_name.startswith(_PACKAGE + ".")))


def _without_register(cls):
    try:
        if not isinstance(cls, type) or not issubclass(cls, bpy.types.Operator):
            return cls
    except Exception:
        return cls
    if not _owned_class(cls):
        return cls
    options = set(getattr(cls, "bl_options", set()) or set())
    options.discard("REGISTER")
    cls.bl_options = options
    return cls


_BROWSER_ROOTS = {
    "FILEBROWSER_PT_smart_rig_root": ("UI", ("FILE_BROWSER",)),
    "FILEBROWSER_PT_smart_rig_asset_root": ("TOOL_PROPS", ("ASSET_BROWSER",)),
}


def _prepare_panel(cls):
    try:
        if not isinstance(cls, type) or not issubclass(cls, bpy.types.Panel):
            return cls
    except Exception:
        return cls
    if not _owned_class(cls):
        return cls
    region = getattr(cls, "bl_region_type", "")
    is_browser = getattr(cls, "bl_space_type", "") == "FILE_BROWSER"
    if region != "UI" and not (is_browser and region == "TOOL_PROPS"):
        return cls
    identifiers = {
        str(getattr(cls, "__name__", "") or ""),
        str(getattr(cls, "bl_idname", "") or ""),
    }
    roots = _ROOT_IDS.get(_SUITE_ID, set())
    if is_browser or cls.__name__ in _BROWSER_ROOTS:
        expected = _BROWSER_ROOTS.get(cls.__name__)
        allowed = is_browser and cls.bl_idname == cls.__name__ and expected == (
            region, getattr(cls, "_smart_tools_manager_editor_keys", ()),
        )
    else:
        allowed = bool(identifiers.intersection(roots))
    if allowed:
        label = _ROOT_LABELS.get(_SUITE_ID)
        if label:
            cls.bl_label = label
            cls.bl_category = label
        return cls
    cls.poll = classmethod(lambda _cls, _context: False)
    cls._smarttools_spec_hidden_sidebar = True
    return cls


def _descendants(base):
    seen = set()
    pending = list(base.__subclasses__())
    while pending:
        cls = pending.pop()
        if cls in seen:
            continue
        seen.add(cls)
        yield cls
        try:
            pending.extend(cls.__subclasses__())
        except Exception:
            pass


def _is_registered(cls) -> bool:
    try:
        return bool(getattr(cls, "is_registered", False))
    except Exception:
        pass
    try:
        getattr(cls, "bl_rna")
        return True
    except Exception:
        return False


def _cleanup_after_unregister() -> None:
    for module_name, module in tuple(sys.modules.items()):
        if not (module_name == _PACKAGE or module_name.startswith(_PACKAGE + ".")):
            continue
        try:
            values = tuple(vars(module).values())
        except Exception:
            continue
        for value in values:
            if not callable(value):
                continue
            try:
                if bpy.app.timers.is_registered(value):
                    bpy.app.timers.unregister(value)
            except Exception:
                pass
    for base in (bpy.types.Panel, bpy.types.Operator):
        for cls in _descendants(base):
            if not _owned_class(cls) or not _is_registered(cls):
                continue
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass


@contextmanager
def _registration_guard():
    original_register = bpy.utils.register_class
    original_unregister = bpy.utils.unregister_class
    aliases = []

    def guarded_register(cls):
        return original_register(_without_register(_prepare_panel(cls)))

    for module_name, module in tuple(sys.modules.items()):
        if not (module_name == _PACKAGE or module_name.startswith(_PACKAGE + ".")):
            continue
        namespace = getattr(module, "__dict__", None)
        if not isinstance(namespace, dict):
            continue
        for name, value in tuple(namespace.items()):
            if value is original_register:
                aliases.append((namespace, name, value))
                namespace[name] = guarded_register

    bpy.utils.register_class = guarded_register
    try:
        yield original_register, original_unregister
        leftovers = []
        for cls in _descendants(bpy.types.Operator):
            if not _owned_class(cls) or "REGISTER" not in set(getattr(cls, "bl_options", set()) or set()):
                continue
            leftovers.append(cls)
        for cls in leftovers:
            was_registered = _is_registered(cls)
            old_options = set(getattr(cls, "bl_options", set()) or set())
            _without_register(cls)
            if not was_registered:
                continue
            try:
                original_unregister(cls)
                original_register(cls)
            except Exception:
                try:
                    cls.bl_options = old_options
                    if not _is_registered(cls):
                        original_register(cls)
                except Exception:
                    pass
                raise
    finally:
        if bpy.utils.register_class is guarded_register:
            bpy.utils.register_class = original_register
        for namespace, name, value in reversed(aliases):
            if namespace.get(name) is guarded_register:
                namespace[name] = value


def wrap(register_fn, unregister_fn):
    """Wrap one add-on boundary without retaining a process-global hook."""

    def register():
        with _registration_guard():
            return register_fn()

    def unregister():
        try:
            return unregister_fn()
        finally:
            _cleanup_after_unregister()

    register.__name__ = "register"
    unregister.__name__ = "unregister"
    return register, unregister
