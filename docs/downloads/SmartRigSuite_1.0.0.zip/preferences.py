# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty

from .i18n import ui_tr as tr
from . import generation
from .lifecycle import register_classes, unregister_owned_classes

ADDON_ID = __package__ or "smart_rig_suite"


def get_preferences(context: bpy.types.Context | None = None):
    ctx = context or bpy.context
    try:
        addons = ctx.preferences.addons
    except Exception:
        return None
    # ``ADDON_ID`` is the exact package key Blender used for this module,
    # including a non-default Extension repository prefix. Direct lookups keep
    # N-panel draw paths O(1) and avoid scanning every installed add-on.
    candidates = dict.fromkeys((
        ADDON_ID,
        "smart_rig_suite",
        "bl_ext.user_default.smart_rig_suite",
    ))
    for key in candidates:
        addon = addons.get(key)
        if addon is not None:
            return addon.preferences
    return None


def _persist_update(self, context) -> None:
    try:
        from . import persistence
        persistence.property_updated(self, context)
    except Exception:
        pass


def _guard_update(self, context) -> None:
    _persist_update(self, context)
    try:
        from . import compatibility
        compatibility.set_guard_enabled(bool(self.guard_proxy_picker_context))
    except Exception:
        pass


def _help_heading(box, title: str, topic: str):
    """Box title with the Smart Rig "?" help at the right end (the help text lives in ui.py)."""
    split = box.row(align=True).split(factor=0.9, align=True)
    split.label(text=title)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    right.operator("srs.show_section_help", text="", icon="QUESTION", emboss=False).topic = topic


class SRS_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID

    ai_runtime_path: StringProperty(
        name="AI Runtime Path",
        description=(
            "External AI_win root folder containing info.dat and the inference subfolder. "
            "Choose the already installed runtime folder; Smart Rig Suite does not extract or copy binaries"
        ),
        subtype="DIR_PATH",
        default="",
        update=_persist_update,
    )
    auto_sync_ai_path: BoolProperty(
        name="Synchronize validated AI path automatically",
        description=(
            "When a valid external AI runtime is detected and Auto-Rig Pro is enabled, synchronize the path "
            "preference immediately before an AI workflow is started. Disable it to keep the external preference unchanged"
        ),
        default=True,
        update=_persist_update,
    )
    proxy_prefix: StringProperty(
        name="Proxy Bone Prefix",
        description="Prefix used by Batch Pair by Name to identify proxy bones. Example: proxy_arm.L",
        default="proxy_",
        update=_persist_update,
    )
    target_prefix: StringProperty(
        name="Target Bone Prefix",
        description="Prefix used by Batch Pair by Name to find the real target bone with the same suffix. Example: c_arm.L",
        default="c_",
        update=_persist_update,
    )
    report_text_name: StringProperty(
        name="Report Text Name",
        description="Name of the Blender Text datablock used for audit and integration reports. Existing unrelated Text data is not overwritten without using this name",
        default="Smart Rig Suite Report",
        update=_persist_update,
    )
    weight_sum_tolerance: FloatProperty(
        name="Weight Sum Tolerance",
        description="Allowed difference from a total weight of 1.0 before a vertex is reported as non-normalized. Use a smaller value for stricter audits",
        default=0.001,
        min=0.000001,
        max=0.25,
        precision=6,
        update=_persist_update,
    )
    maximum_influences: IntProperty(
        name="Maximum Influences",
        description="Maximum number of non-zero deform groups allowed per vertex before the weight audit reports it. Four is a common real-time target",
        default=4,
        min=1,
        max=32,
        update=_persist_update,
    )
    tiny_weight_threshold: FloatProperty(
        name="Tiny Weight Threshold",
        description="Weights below this value are reported as tiny influences during the weight audit. Set zero to disable tiny-weight reporting",
        default=0.0001,
        min=0.0,
        max=0.1,
        precision=6,
        update=_persist_update,
    )
    guard_proxy_picker_context: BoolProperty(
        name="Guard Proxy Picker restricted contexts",
        description=(
            "Function: while enabled, wrap only the separately installed Proxy Picker depsgraph callback so restricted "
            "Blender contexts do not raise missing-scene errors. How to use: enable it only when Proxy Picker is installed "
            "and produces restricted-context errors; disable it for zero Smart Rig background runtime. External files are never modified"
        ),
        default=False,
        update=_guard_update,
    )

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        _help_heading(box, tr("External AI Runtime", "外部AIランタイム"), "ai")
        box.prop(self, "ai_runtime_path")
        box.prop(self, "auto_sync_ai_path")

        box = layout.box()
        _help_heading(box, tr("Proxy Picker Batch Pairing", "Proxy Picker一括ペア設定"), "proxy_roles")
        row = box.row(align=True)
        row.prop(self, "proxy_prefix")
        row.prop(self, "target_prefix")

        box = layout.box()
        _help_heading(box, tr("Audit and Weight Quality", "監査・ウェイト品質"), "prefs_audit")
        box.prop(self, "report_text_name")
        row = box.row(align=True)
        row.prop(self, "weight_sum_tolerance")
        row.prop(self, "maximum_influences")
        box.prop(self, "tiny_weight_threshold")


CLASSES = (SRS_AddonPreferences,)
_REGISTERED = False


def register() -> bool:
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False
    register_classes(
        CLASSES,
        module_name=__name__,
        revision=__srs_revision__,
        module_marker=__srs_module_generation_marker__,
    )
    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    return True


def unregister() -> dict:
    global _REGISTERED
    report = unregister_owned_classes(module_name=__name__, attempts=2)
    if report.get("all_removed"):
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return report
