# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Character resize: scale a rigged character about the world origin without redoing the rig.

S is a uniform scale by s about the world origin and conj(A) = S A S^-1. The resize

1. conjugates every object's matrix_basis / matrix_parent_inverse (translations *= s,
   rotations and scales kept), so origins such as the eye pivots move to s times where they
   were and are never pulled to the world origin;
2. scales object DATA by s in its own local space (meshes with their shape keys once per
   datablock, armatures through Armature.transform), and bakes any non-unit mesh object scale
   into the mesh so meshes and armatures end at object scale exactly 1.0;
3. multiplies every pose / animation translation by s;
4. multiplies every length-valued parameter by s (modifiers, constraints, physics, SmartRig and
   Auto-Rig Pro custom properties, the SmartRig panel's millimetre settings);
5. keeps drivers consistent through their F-curve keys / Generator coefficients, and rewrites a
   numeric constant in a scripted expression only where a numeric solver proves it is needed.

No modifier is applied. For every pose whose rotations are the same and whose translations are
multiplied by s, every evaluated world vertex afterwards equals s times the same vertex before.
The method is the one proven on MIK_131 -> MIK_132 (158/165, every vertex within 0.0063 mm over
more than 100 tests); the categories counted in the report keep the names used there so a run can
be compared one to one.

Everything is refused before anything changes when the character cannot be resized cleanly: not
in Object Mode, linked or overridden data, object data or an action slot shared with something
outside the character, an object type this cannot scale, another character pulled in by a
reference, an armature that is not at scale 1, a legacy particle system, an object instancing a
collection, a UV Project projector that is not an empty, an action slot whose length channels are
used both by a Multiply NLA strip (factors) and as ordinary animation (lengths), or a bound deform
modifier (Corrective Smooth with
a bind rest, Surface Deform, Mesh Deform, Laplacian Deform: their bind data is stored in the old
size and nothing in RNA can scale it). With ``rebind_bound`` those modifiers are unbound before the
resize and bound again afterwards with Blender's own Bind operators, first at rest position, then at
the current pose; the evaluated result is compared with s times the original at both and a difference
above 0.01 mm is reported as a defect (the data has then been changed; one undo takes it back).

A mesh scale is never baked when anything reads the object's transform with that scale in it (a
Hook / Child Of / Copy Scale / Copy Transforms target, a driver reading its scale, matrix or mesh
coordinates, a UV projector, a widget drawn without the bone length, particle settings...: see
``scale_readers``) or when the object has constraints of its own; the object then keeps its scale and
its data takes plain s, which is exact. Shrinkwrap targets, Vertex Weight Proximity geometry targets
and Data Transfer sources (with Object Transform) work in the target's own space: such a target may
be baked when its scale is positive and uniform (k), and the lengths measured in its space take s*k.
Lengths Blender measures in the world (Vertex Weight Proximity object distance) take s, whatever the
owner's bake. A mesh scale is baked only where every object-space setting on it can follow exactly: a Hook's
``matrix_inverse`` absorbs the baked scale (P' = S P D^-1), its center takes D and its falloff radius
s*|k|; a Displace strength takes s*k^2 (world axes: Blender moves the vertex by strength x W W^T axis, W the
object's world 3x3, so a uniform scale k shows as k^2 -- measured on 5.1.2), the signed per-axis factor (local
axes) or s*|k| (normals); a mirrored (negative-determinant) bake flips the face winding back with
Mesh.flip_normals and re-checks the custom normals corner by corner. Where no exact mapping exists (a
non-uniform scale with a scalar length, a Hook with uniform or non-uniform falloff, a normal or world-axis
Displace on a non-uniform scale) the object keeps its scale and the data takes plain s, which is always exact.

What cannot be refused beforehand is reported afterwards: ``report["defects"]`` lists every note that
means part of the result may not be exactly s times what it was (an expression the solver could not make
consistent, a driver that failed, a Displace texture read at moved positions, a Geometry Nodes input
declared as a length that was left as it is, a modifier that could not be bound again, a constraint or
modifier reading an object the resize leaves as it is...), and
``report["new_invalid_drivers"]`` the drivers Blender marks invalid only after the resize. The operator
raises those to an error headline; the resize stays one undo step. Geometry Nodes inputs without a
length unit are a warning only: they cannot be judged, and a test with such inputs scales exactly.

Round 5 (the round-1 verifier's findings 1-12): a mesh scale is baked only where every modifier on the object is
proven to follow it. Under a non-uniform bake only the modifiers in ``NONUNIFORM_BAKE_TYPES`` may be on the object;
an Array that reads another object (offset object, start / end cap), a Cast with a control object and automatic size,
and a Skin on a mirrored or non-uniform scale keep the scale for any baked factor. Skin radii take the data's length
factor, Cast size and Wave speed are lengths, Wave narrowness is an inverse length, Remesh adaptivity and Data
Transfer islands precision are not lengths, a Laplacian Smooth without Normalized takes the square of the length
factor (its weights divide by the ring area; the closest single factor, not exact in general: round 6 measured 135 mm on
a 6 x 6 grid with lambda 2.0, so every Laplacian Smooth is reported as a defect). A keyed mesh scale is baked only when
every scale curve is used by Replace at full influence. Animated and driven settings take the same factor as the setting
itself (``value_factor``). A Multires modifier with levels, and a UV Project projector that anything else reads, is
constrained by, or animates its scale, stop the resize. A Geometry Nodes modifier whose node tree can move positions
is a defect; one built only from shading nodes (Smooth by Angle) is exact and not reported. Objects outside the
character that read it are named. Finally every in-scope mesh is measured before and after the resize at the current
pose and at rest (``result_check``): a vertex further than RESULT_TOL_MM from s times where it was is a defect, so
what no rule foresaw (a Decimate whose collapse order flips on a tie) is never silent in those two states.

Round 6 (the round-2 verifier's findings 1-5): ELASTIC keys take the value factor on their amplitude and the time factor
on their period (a negative value factor cannot be mapped when the amplitude reaches the change: such a scale bake keeps
the scale, any other curve is a defect); a NOISE F-modifier blended by Multiply keeps its strength (it is a factor). A
Geometry Attribute constraint taking a location from any attribute but ``position``, a simulation (Cloth, Soft Body,
Dynamic Paint, Fluid, a rigid body world) that is on or baked, a Simple Deform that stretches and any modifier type
without a proven rule (``PROVEN_MOD_TYPES``; a UV Warp offset by objects) that can take effect stop the resize before
anything changes; switched off they are named as warnings. The measured check now covers every in-scope mesh, empty,
armature and bone (and lights / cameras when included), hidden ones shown for the time of the measurement, the render
switches of the modifiers, and up to RESULT_MAX_FRAMES of the character's key frames; anything it cannot evaluate is a
defect (W_NOT_MEASURED), and a roll Blender computed from a near-zero vector before the resize is a warning
(W_ROLL_UNDETERMINED).

Nothing here saves a file. The SmartRig panel's settings are written with the N-panel state save held
back and the panel is saved once (``persistence.save``) when a shared value changed. Refusal reasons and
notes are returned as English catalog msgids (``(msgid, values)`` pairs and report entries); the
operators translate them.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import io
import itertools
import math
import random
import time
import tokenize
from collections import Counter

import bpy
from mathutils import Matrix, Vector

from . import collide, shoe_lift


# ----------------------------------------------------------------------------------------------
# catalog msgids (translated by the operators with i18n.tr_format; values inserted afterwards)
# ----------------------------------------------------------------------------------------------
MSG_MODE = "Switch to Object Mode first."
MSG_NO_RIG = "Choose an Auto-Rig Pro rig (an armature with c_pos and c_traj)."
MSG_NOT_ARP = "%(name)s is not an Auto-Rig Pro rig (it has no c_pos and c_traj bones), so it cannot be resized."
MSG_RIG_NAMED = "There is no Auto-Rig Pro rig named %(name)s."
MSG_MANY_RIGS = "The selection holds more than one rig: %(rigs)s."
MSG_RIG_NOT_IN_SCENE = "%(name)s is not in this scene."
MSG_FACTOR_LOW = "The factor must be above 0."
MSG_FACTOR_ONE = "The factor is 1, so nothing would change."
MSG_NO_CURRENT = "Measure or enter the current height first."
MSG_NO_TARGET = "Enter the target height."
MSG_LINKED = "%(name)s is linked from a library and cannot be resized."
MSG_SHARED_DATA = "%(data)s is also used by %(users)s, outside the character."
MSG_SHARED_SLOT = "Action %(action)s (slot %(slot)s) is shared with %(users)s, outside the character."
MSG_TYPE = "%(name)s is a %(type)s, which cannot be resized yet."
MSG_OTHER_RIG = "%(name)s belongs to another character (%(rig)s). Turn on Whole Scene to resize both."
MSG_ARM_SCALE = "Armature %(name)s is not at scale 1 (%(scale)s)."
MSG_NO_MESHES = "Select the character's meshes to measure."
MSG_NO_VERTS = "The selected meshes have no vertices."
MSG_BOUND = ("%(object)s: the %(type)s modifier %(modifier)s is bound, and its bind would not follow the new size. "
             "Unbind it first, or turn on Rebind Bound Modifiers.")
MSG_NLA_MULTIPLY = ("Action %(action)s (slot %(slot)s) is used both by a Multiply NLA strip and as ordinary animation, "
                    "so its location values cannot be factors and lengths at once.")
MSG_PARTICLES = "%(name)s has the particle system %(system)s, which cannot be resized yet."
MSG_INSTANCE = "%(name)s instances the collection %(collection)s, which cannot be resized yet."
MSG_PROJECTOR = "%(name)s is a %(type)s used as a UV Project projector, which cannot be resized yet."
MSG_MULTIRES = ("%(object)s: the Multires modifier %(modifier)s holds sculpted levels, whose detail cannot be resized "
                "yet.")
MSG_PROJECTOR_READ = ("%(name)s is a UV Project projector, and %(reader)s reads it, constrains it or animates its "
                      "scale, so it cannot be resized yet.")
# round 6 (the round-2 verifier's findings 3-5)
MSG_GEOMETRY_ATTRIBUTE = ("%(subject)s reads the attribute %(attribute)s of %(target)s as a location, and whether that "
                          "attribute is a length cannot be known, so it cannot be resized yet.")
MSG_SIM_BAKED = ("%(object)s: the %(type)s simulation %(modifier)s has a cache baked at the old size. Free the bake "
                 "first; bake it again after the resize.")
MSG_SIM_ON = ("%(object)s: the %(type)s simulation %(modifier)s is on, and a simulation does not repeat its motion "
              "times the factor at a new size. Turn it off in the viewport and for render first.")
MSG_RIGID_BODY = ("%(name)s is in the rigid body simulation, which is on or baked and would not follow the new size. "
                  "Turn the rigid body world off and free its bake first.")
MSG_STRETCH = ("%(object)s: the Simple Deform modifier %(modifier)s stretches, and a stretch depends on the size, so "
               "no factor keeps it the same. Set its factor to 0 or turn it off first.")
MSG_MOD_UNPROVEN = ("%(object)s: the %(type)s modifier %(modifier)s has no proven resize rule, so the character cannot "
                    "be resized with it on. Turn it off first.")

REFUSAL_MSGIDS = (
    MSG_MODE, MSG_NO_RIG, MSG_NOT_ARP, MSG_RIG_NAMED, MSG_MANY_RIGS, MSG_RIG_NOT_IN_SCENE, MSG_FACTOR_LOW, MSG_FACTOR_ONE,
    MSG_NO_CURRENT, MSG_NO_TARGET, MSG_LINKED, MSG_SHARED_DATA, MSG_SHARED_SLOT, MSG_TYPE, MSG_OTHER_RIG,
    MSG_ARM_SCALE, MSG_NO_MESHES, MSG_NO_VERTS, MSG_BOUND, MSG_NLA_MULTIPLY, MSG_PARTICLES, MSG_INSTANCE,
    MSG_PROJECTOR, MSG_MULTIRES, MSG_PROJECTOR_READ, MSG_GEOMETRY_ATTRIBUTE, MSG_SIM_BAKED, MSG_SIM_ON,
    MSG_RIGID_BODY, MSG_STRETCH, MSG_MOD_UNPROVEN,
)

# Notes written to report["warnings"][i]["msg"]. Every one is a catalog msgid without placeholders;
# the operator prints the translated msgid followed by the object it is about.
W_PARENT_OUT = "in-scope object has out-of-scope parent"
W_CHILD_OUT = "out-of-scope object has in-scope parent (its world transform will move)"
W_STAGING_CHILD = "light or camera left at its size; it follows its resized parent"
W_ARRAY = "cannot read array length prop"
W_MATRIX_PROP = "cannot scale matrix custom prop"
W_DICT_PROP = "cannot scale dict custom prop"
W_NOT_NUMERIC = "custom prop is not numeric"
W_FMOD = "unhandled F-modifier"
W_LOC_DIFF = "LOC_DIFF between in-scope and out-of-scope objects: not scale-consistent"
W_VAR_PATH = "driver variable path not resolvable; treated as dimensionless"
W_CONTEXT_PROP = "CONTEXT_PROP variable treated as dimensionless"
W_DRIVEN_PATH = "driven path not resolvable"
W_USE_SELF = "driver uses self; not analysed"
W_EXPR = "expression could not be made scale-consistent"
W_EXPR_AMBIGUOUS = "expression rewrite was ambiguous"
W_AGGREGATE = "aggregate driver mixes length and non-length variables"
W_BACKUP = "SmartRig backup expression not made consistent"
W_SLOT_SHARED = "action slot used by in-scope and out-of-scope IDs; not scaled"
W_ACTION_PATH = "action F-curve path unresolved; left"
W_MAT_SHARED = "material shared with out-of-scope objects; not scaled"
W_MAT_LINKED = "material is linked from a library; not scaled"
W_NODE_GROUP = "node group with length-dependent nodes not scaled"
W_MAPPING_LINKED = "mapping Scale is linked; not compensated"
W_TEX_OBJECT = "texture fed directly by Object coordinates cannot be compensated"
W_TEX_OBJECT_BAKED = ("texture read at Object coordinates on a mesh whose scale was baked: the material makes up for the "
                      "resize but not for the bake, so the pattern changes size there")
W_DATA_SHARED = "datablock shared between in-scope and out-of-scope objects; data not scaled"
W_WIDGET_MIXED = "widget used by bones with and without bone-size scaling; data scaled for the latter"
W_WIDGET_ANIM = "widget scale is animated/driven; left"
W_WIDGET_CHILDREN = "widget has children; scale left"
W_PROJECTOR_OUT = "UV Project projector is out of scope; UVs will shift"
W_SCALE_CHILDREN = "mesh with non-unit scale has children; scale not applied"
W_MULTI_USER = "multi-user mesh with different object scales; using plain s"
W_ATTR_KEPT = "attribute added by custom-normal re-encode is not all-default; kept"
W_ATTR_CHANGED = "mesh attribute set changed"
W_ARM_SCALE = "armature object scale is not exactly 1; left (applying it would move children)"
W_MOD_REF_OUT = "modifier references out-of-scope object"
W_DRIVER_FAILED = "driver processing failed"
W_TYPE = "object type not handled for data scaling"
W_CON_TARGET_OUT = "constraint targets an out-of-scope object"
W_DISPLACE_TEX = "Displace texture is read at moved positions, so its pattern may shift"
W_NODES = "Geometry Nodes modifier can move positions and was not judged; its result may not follow the new size"
W_NODES_LENGTH = "Geometry Nodes input with a length unit was not scaled"
W_SCALE_KEPT = ("mesh scale is driven or keyed in a way a bake cannot follow (a shared action slot, a blend other than "
                "Replace, an influence below 1), or its mesh data lengths are animated; scale not applied")
W_SCALE_MODIFIER = "mesh scale kept: a modifier on it could not follow a baked scale exactly"
W_SCALE_ZERO = "mesh scale has a zero axis; scale not applied"
W_SCALE_REFERENCED = "mesh scale kept: another object, constraint, modifier, driver or particle setting reads it"
W_SCALE_CONSTRAINED = "mesh scale kept: its own object constraints work with it"
W_FLIP_CORNERS = "corners of a mirrored mesh could not be matched after flipping; custom normals not checked"
W_CN_DRIFT = "custom normals moved more than 0.1 from their direction"
W_CN_DRIFT_BLENDER = ("custom normals moved more than 0.1 on a few corners, no more than Blender's own Apply Scale "
                      "moves them")
W_KNEE_TEXT = "knee profile text (angle:mm) is not scaled; re-enter it before setting the profile again"
W_REBOUND = "bound modifier was unbound before the resize and bound again after it"
W_REBIND_FAILED = "bound modifier could not be bound again"
W_REBIND_MISMATCH = "bound-again modifier does not reproduce the original shape"
W_ANIM_FACTOR = "animated or driven value has no single resize factor; left as it is"
W_OUT_READS_IN = "object outside the character reads a resized object, so it changes as well"
W_STAGING_READS_IN = "light or camera reads the resized character; it follows it"
W_RESULT_DRIFT = "measured after the resize: not exactly the new size"
W_LAPLACIAN = ("Laplacian Smooth solves a linear system that amplifies rounding, so its result can differ from the new "
               "size by more than 0.01 mm")
# round 6
W_SIM_OFF = ("simulation is off; when it is turned on it simulates at the new size, which does not repeat its old "
             "motion times the factor")
W_UNPROVEN_OFF = ("modifier is off and has no proven resize rule; if it is turned on, its result may not follow the "
                  "new size")
W_ELASTIC_SIGN = ("elastic keys whose amplitude reaches the change cannot be turned over, so this curve does not "
                  "follow the new size exactly")
W_TEXTURE_COORDS = "texture is read at moved positions (coordinates other than UV), so its pattern may shift"
W_NOT_MEASURED = ("could not be measured before and after the resize (not evaluated even when shown), so it is not "
                  "proven to have the new size")
W_CLAMPED = "Blender limits this setting, so it could not take the resize factor exactly"
W_ITASC = ("armature solves IK with iTaSC, whose result depends on the evaluation history, so the new size cannot be "
           "checked to match exactly")
W_ACTION_UNUSED = ("action used by nothing (a kept take or a pose asset) is the character's but was left at the old "
                   "size; assign it before resizing, or it will not fit")
W_ROLL_UNDETERMINED = ("roll was numerically undetermined before the resize (its axes were not perpendicular); its "
                       "head and direction match the new size, its roll does not")

WARNING_MSGIDS = (
    W_PARENT_OUT, W_CHILD_OUT, W_STAGING_CHILD, W_ARRAY, W_MATRIX_PROP, W_DICT_PROP, W_NOT_NUMERIC, W_FMOD,
    W_LOC_DIFF, W_VAR_PATH, W_CONTEXT_PROP, W_DRIVEN_PATH, W_USE_SELF, W_EXPR, W_EXPR_AMBIGUOUS, W_AGGREGATE,
    W_BACKUP, W_SLOT_SHARED, W_ACTION_PATH, W_MAT_SHARED, W_MAT_LINKED, W_NODE_GROUP, W_MAPPING_LINKED,
    W_TEX_OBJECT, W_DATA_SHARED, W_WIDGET_MIXED, W_WIDGET_ANIM, W_WIDGET_CHILDREN, W_PROJECTOR_OUT,
    W_SCALE_CHILDREN, W_MULTI_USER, W_ATTR_KEPT, W_ATTR_CHANGED, W_ARM_SCALE,
    W_MOD_REF_OUT, W_DRIVER_FAILED, W_TYPE, W_CON_TARGET_OUT, W_DISPLACE_TEX, W_NODES, W_NODES_LENGTH,
    W_SCALE_KEPT, W_SCALE_MODIFIER, W_SCALE_ZERO, W_SCALE_REFERENCED, W_SCALE_CONSTRAINED, W_FLIP_CORNERS,
    W_CN_DRIFT, W_CN_DRIFT_BLENDER, W_KNEE_TEXT, W_REBOUND, W_REBIND_FAILED, W_REBIND_MISMATCH,
    W_ANIM_FACTOR, W_OUT_READS_IN, W_STAGING_READS_IN, W_RESULT_DRIFT, W_LAPLACIAN, W_SIM_OFF, W_UNPROVEN_OFF,
    W_ELASTIC_SIGN, W_TEXTURE_COORDS, W_NOT_MEASURED, W_ROLL_UNDETERMINED, W_CLAMPED, W_ACTION_UNUSED, W_ITASC,
    W_TEX_OBJECT_BAKED,
)
# Notes about a deliberate choice (reported as information).
INFO_WARNINGS = frozenset({W_STAGING_CHILD, W_KNEE_TEXT, W_REBOUND, W_STAGING_READS_IN})
# Notes about something that is switched off (round 6): with its switches as they are, every state of the character is
# exactly s times (measured); turned on later it would not be. A warning naming it, not a defect. A simulation or a
# modifier without a proven rule that is ON (in the viewport or for render, or with animated switches) stops the resize.
OFF_WARNINGS = frozenset({W_SIM_OFF, W_UNPROVEN_OFF})
# A setting Blender clamps (round 8, the round-3 verifier's finding 8: a 1 mm Collision thickness or cloth Minimum
# Distance at 158/165, thickness_outer 0.2 at 10 -- hard limits 0.001 / 1.0): named with the wanted and the stored value.
# Not a defect by itself: a clamped value that changes the shape is caught by the measured check (W_RESULT_DRIFT).
CLAMP_WARNINGS = frozenset({W_CLAMPED})
# An action nothing uses whose channels are the character's (round 10, the round-5 verifier's finding 2: a kept take of
# the rig played after the resize put it 121.67 mm off, a pose asset 30.00 mm, with only an unprinted "untouched" line):
# not scaled -- the same take may drive another character with the same bones -- and a defect (W_ACTION_UNUSED), so the
# resize ends with the error headline naming it: played as it is, it no longer fits the character.
# Notes about an object scale left as it was: the shape is still exactly s times (the data took plain s), only
# the object does not end at scale 1. Reported as warnings and listed by name.
SCALE_LEFT_WARNINGS = frozenset({W_SCALE_CHILDREN, W_MULTI_USER, W_SCALE_KEPT, W_ARM_SCALE, W_WIDGET_ANIM,
                                 W_WIDGET_CHILDREN, W_SCALE_MODIFIER, W_SCALE_ZERO, W_SCALE_REFERENCED,
                                 W_SCALE_CONSTRAINED})
SHAPE_NEUTRAL_WARNINGS = INFO_WARNINGS | SCALE_LEFT_WARNINGS
# Notes about something that cannot be judged and that is known to scale exactly. Empty since round 5: a Geometry Nodes
# modifier whose node tree can move positions may hold a length constant inside it (measured: a Set Position offset of
# 50 mm left the shape 5.0 mm off at 1.1 with only a warning), so W_NODES is a defect; a node tree built only from the
# shading nodes of GN_POSITION_NEUTRAL_NODES (Blender's Smooth by Angle) cannot move a vertex and gets no note. A
# Geometry Nodes input declared as a length (Distance / Translation / Velocity / Acceleration) holding a non-zero
# value is left unscaled and is a defect as well (W_NODES_LENGTH).
UNJUDGED_WARNINGS = frozenset()
# Custom normals that drift on corners whose normal spaces are ill-conditioned, by no more than Blender's own data
# transform (the one Apply Scale uses) drifts them on the same mesh: measured on MIK_131's belt with the typed factor
# 0.95757574, 4 corners after the re-encode where Blender's Apply Scale leaves 18. A warning naming the mesh; the
# drift is a defect (W_CN_DRIFT) only where the result is worse than that transform alone.
# A bone or object whose roll Blender computed from a near-zero vector before the resize (a Track To whose target's up
# axis runs along the track: the axes come out skewed, measured on MIK_131's toes_track.l / .r, 0.227 between Y and Z)
# keeps its head and its direction exactly but takes another roll at the new size (0.275 / 0.085 in the matrix there,
# the deforming bones 1.8e-5): Blender's own rounding, a warning naming it (round 6).
BLENDER_LIMIT_WARNINGS = frozenset({W_CN_DRIFT_BLENDER, W_ROLL_UNDETERMINED})
# Every other note means that part of the result may not be exactly s times what it was (the standalone MIK
# script refused to save on any of them): report["defects"], raised by the operator to an error headline.
NOT_DEFECT_WARNINGS = (SHAPE_NEUTRAL_WARNINGS | UNJUDGED_WARNINGS | BLENDER_LIMIT_WARNINGS | OFF_WARNINGS
                       | CLAMP_WARNINGS)

# Which report-entry key names the thing a note is about, in order of preference ("subject" is a ready label such
# as "body: CorrectiveSmooth" for notes about one modifier).
WARNING_SUBJECT_KEYS = ("subject", "object", "mesh", "data", "widget", "projector", "material", "action", "modifier",
                        "constraint", "where", "path", "key", "group", "setting")


# ----------------------------------------------------------------------------------------------
# rules (identical to the verified rescale_lib, plus srs_jiggle_tip_mm and Camera.ortho_scale)
# ----------------------------------------------------------------------------------------------
LEN_SUBTYPES = {"TRANSLATION", "DISTANCE", "DISTANCE_DIAMETER", "XYZ_LENGTH"}
STAGING_TYPES = {"LIGHT", "CAMERA", "LIGHT_PROBE", "SPEAKER"}
RESIZABLE_TYPES = {"MESH", "ARMATURE", "EMPTY"}
STAGING_RESIZABLE_TYPES = {"LIGHT", "CAMERA"}
# Object types whose DATA the resize writes (lights and cameras only when they are included). An empty's data
# (the image of an image empty) is never written, so sharing or linking it does not stop the resize: measured on
# MIK_131, whose reference-image empties share one image with an empty under the camera.
SCALED_DATA_TYPES = {"MESH", "ARMATURE"}
BBONE_CURVES = ("bbone_curveinx", "bbone_curveinz", "bbone_curveoutx", "bbone_curveoutz")
EXPR_MAX = 255  # Driver.expression is char[256]
NEAR_UNIFORM_REL = 2.0e-7  # object-scale non-uniformity treated as float32 noise when baking scale
CN_TOL = 1.0e-3            # custom-normal drift that triggers the re-encode trial
FACTOR_ONE_TOL = 1.0e-12
ARMATURE_SCALE_TOL = 1.0e-6
# Modifiers whose length settings act in WORLD space (simulation / collision data is evaluated in world
# coordinates). Every other modifier works in the object's local space, so on an object whose scale is
# baked into its mesh the local-space lengths get s * baked_scale, these get plain s.
WORLD_SPACE_MOD_TYPES = {"COLLISION", "CLOTH", "SOFT_BODY", "DYNAMIC_PAINT", "FLUID", "PARTICLE_SYSTEM"}
# A baked scale is "uniform" for modifier lengths when the magnitudes of its three axes agree to this ratio (MIK's
# two least uniform baked scales differ by 2.4e-6, float32 noise; 1e-5 of a 2 m character is 0.02 mm at most).
LEN_UNIFORM_REL = 1.0e-5
# Modifiers whose scalar lengths are signed positions along one local axis (Wave start position, Screw offset):
# on a mirrored (negative) bake they would need the axis' sign, so such an object keeps its scale.
AXIS_LENGTH_MOD_TYPES = {"WAVE", "SCREW"}
# Bound deform modifiers: their bind data (Corrective Smooth bind coordinates, Surface Deform / Mesh Deform bind
# weights and offsets, Laplacian Deform rest positions) is stored in the old size and no RNA property reaches it.
# Bound in this order (self-contained binds first, then the binds that read another object's evaluated mesh).
BIND_OPERATORS = {"CORRECTIVE_SMOOTH": "correctivesmooth_bind", "LAPLACIANDEFORM": "laplaciandeform_bind",
                  "MESH_DEFORM": "meshdeform_bind", "SURFACE_DEFORM": "surfacedeform_bind"}
BIND_ORDER = ("CORRECTIVE_SMOOTH", "LAPLACIANDEFORM", "MESH_DEFORM", "SURFACE_DEFORM")
REBIND_TOL_MM = 0.01
# Geometry Nodes interface sockets that declare a length (prefix of bl_socket_idname; 2D / 4D variants included).
GN_LENGTH_SOCKETS = ("NodeSocketFloatDistance", "NodeSocketVectorTranslation", "NodeSocketVectorVelocity",
                     "NodeSocketVectorAcceleration")
# Mesh-level remesh settings: voxel size is an object-space length. remesh_voxel_adaptivity carries the
# DISTANCE subtype in RNA but is OpenVDB's dimensionless 0..1 adaptivity, so it is never scaled.
MESH_LOCAL_LENGTHS = ("remesh_voxel_size",)
# Modifiers proven to follow a NON-UNIFORM bake exactly (round 5, finding 7): they act on each vertex through an affine
# map or not on positions at all, given their three-component lengths take the per-axis factor (Armature, Hook without
# falloff, Displace along a local axis, Mirror, Smooth, the vertex-weight modifiers, Mask, UV Project, Data Transfer
# settled per pair). Any other modifier on a non-uniformly scaled mesh keeps the scale (measured before: SimpleDeform
# Bend 105.2 mm, Twist 274.8 mm, Cast 21.0 mm, Corrective Smooth 9.8 mm, Laplacian Smooth 2.6 mm, Decimate 170.7 mm off
# at 1.1). The simulation types of WORLD_SPACE_MOD_TYPES work in the world and are not affected by a bake.
NONUNIFORM_BAKE_TYPES = {"ARMATURE", "HOOK", "DISPLACE", "MIRROR", "SMOOTH", "VERTEX_WEIGHT_EDIT", "VERTEX_WEIGHT_MIX",
                         "VERTEX_WEIGHT_PROXIMITY", "MASK", "UV_PROJECT", "DATA_TRANSFER"}
# Geometry Nodes node types that can never move a vertex (shading flags and the comparisons that feed them): a node
# tree built only from these (Blender's Smooth by Angle, measured on 5.1.2's essentials asset) is exact under a uniform
# resize and gets no note. Anything else in a Geometry Nodes modifier is a defect (W_NODES).
GN_POSITION_NEUTRAL_NODES = {"NodeGroupInput", "NodeGroupOutput", "NodeReroute", "NodeFrame",
                             "GeometryNodeSetShadeSmooth", "GeometryNodeInputShadeSmooth", "GeometryNodeInputEdgeSmooth",
                             "GeometryNodeInputMeshEdgeAngle", "FunctionNodeCompare", "FunctionNodeBooleanMath"}
# Measured check after the resize (``result_check``): every in-scope mesh, empty, armature (and light / camera when
# included) and every bone must be within RESULT_TOL_MM of s times where it was (float32 meshes: the tolerance grows
# with the size of the coordinates, RESULT_TOL_REL of the largest one, so a scene far from the origin is not reported
# for rounding), with the rotation part of each matrix within RESULT_ROT_TOL. Measured at the current pose and frame,
# at rest, with the render switches of the modifiers when they differ from the viewport ones, and at up to
# RESULT_MAX_FRAMES other frames taken from the character's keys (round 6, finding 5). Objects hidden in the viewport,
# hidden in the view layer or in a hidden / excluded collection are shown for the measurement and hidden again.
RESULT_TOL_MM = 0.01
RESULT_TOL_REL = 4.0e-7
RESULT_ROT_TOL = 1.0e-4
RESULT_SKEW_TOL = 1.0e-3  # axes of a matrix further from perpendicular than this: its roll was undetermined
RESULT_MAX_FRAMES = 6
# Simulations (round 6, finding 4): their cache is in the old size and their motion is not covariant (scene gravity,
# mass, the solver), measured on 5.1.2 at 1.1: a baked cloth played back 96.3 mm off, a live one 113.8 mm off at frame
# 10. On (viewport or render, or animated switches) or baked stops the resize; off is a warning (W_SIM_OFF).
SIM_MOD_TYPES = {"CLOTH", "SOFT_BODY", "DYNAMIC_PAINT", "FLUID"}
# Modifier types with a resize rule proven by a measured test (round 6, finding 5: SimpleDeform Stretch had no rule and
# drifted 77.7 mm with nothing said wherever the measured check did not look). Every other modifier type, when it can
# take effect (on in the viewport or for render, or with animated switches), stops the resize (MSG_MOD_UNPROVEN); when
# it is off it is a warning (W_UNPROVEN_OFF). Geometry Nodes keep their own rule (W_NODES / W_NODES_LENGTH), the
# simulations theirs (SIM_MOD_TYPES), Simple Deform's Stretch is refused (MSG_STRETCH). Where each one is proven:
#   ARMATURE SOLIDIFY MIRROR (synth), HOOK DISPLACE CORRECTIVE_SMOOTH SURFACE_DEFORM MESH_DEFORM LAPLACIANDEFORM
#   SHRINKWRAP BOOLEAN LATTICE CURVE (adv / adv2), VERTEX_WEIGHT_PROXIMITY DATA_TRANSFER UV_PROJECT (refs), ARRAY SKIN
#   MULTIRES CAST REMESH LAPLACIANSMOOTH SMOOTH MASK DECIMATE SUBSURF WAVE SIMPLE_DEFORM (round5), WEIGHTED_NORMAL
#   COLLISION (MIK_131), BEVEL WELD TRIANGULATE EDGE_SPLIT WIREFRAME SCREW BUILD NORMAL_EDIT UV_WARP VERTEX_WEIGHT_EDIT
#   VERTEX_WEIGHT_MIX WARP (round6 ``types``).
PROVEN_MOD_TYPES = {
    "ARMATURE", "SOLIDIFY", "MIRROR", "HOOK", "DISPLACE", "CORRECTIVE_SMOOTH", "SURFACE_DEFORM", "MESH_DEFORM",
    "LAPLACIANDEFORM", "SHRINKWRAP", "BOOLEAN", "LATTICE", "CURVE", "VERTEX_WEIGHT_PROXIMITY", "DATA_TRANSFER",
    "UV_PROJECT", "ARRAY", "SKIN", "MULTIRES", "CAST", "REMESH", "LAPLACIANSMOOTH", "SMOOTH", "MASK", "DECIMATE",
    "SUBSURF", "WAVE", "SIMPLE_DEFORM", "WEIGHTED_NORMAL", "COLLISION", "BEVEL", "WELD", "TRIANGULATE", "EDGE_SPLIT",
    "WIREFRAME", "SCREW", "BUILD", "NORMAL_EDIT", "UV_WARP", "VERTEX_WEIGHT_EDIT", "VERTEX_WEIGHT_MIX", "WARP",
}
# Modifiers that read a texture at positions: (texture property, coordinates property). A texture read
# at local / global / object coordinates is read where the resize moved the points, so its pattern shifts (Displace has
# its own note, W_DISPLACE_TEX).
TEXTURE_READERS = {"WAVE": ("texture", "texture_coords"), "WARP": ("texture", "texture_coords"),
                   "VERTEX_WEIGHT_EDIT": ("mask_texture", "mask_tex_mapping"),
                   "VERTEX_WEIGHT_MIX": ("mask_texture", "mask_tex_mapping"),
                   "VERTEX_WEIGHT_PROXIMITY": ("mask_texture", "mask_tex_mapping")}
# Constraints a UV Project projector may carry: they never set its scale, which the resize multiplies by s.
PROJECTOR_SAFE_CONSTRAINTS = {"TRACK_TO", "DAMPED_TRACK", "LOCKED_TRACK", "COPY_LOCATION", "COPY_ROTATION",
                              "LIMIT_LOCATION", "LIMIT_ROTATION", "LIMIT_DISTANCE"}

# (RNA type identifier, property) -> length dimension, for properties whose RNA unit does not say so
# FieldSettings names that share one stored value (measured on 5.1.2): size IS rest_length (a length: a Turbulence's
# noise size, a Harmonic's rest length); guide_minimum IS strength IS linear_drag (a length only in a Guide field). The
# dimension follows the stored value, whichever name a key or a driver uses (round 9, the round-4 verifier's finding 9:
# keys on field.size of a Harmonic stayed at the old size); scale_struct scales each stored value once (FIELD_ALIAS_CANON).
FIELD_ALIASED_LENGTHS = {
    "size": lambda t: True,
    "rest_length": lambda t: True,
    "guide_minimum": lambda t: t == "GUIDE",
    "strength": lambda t: t == "GUIDE",
    "linear_drag": lambda t: t == "GUIDE",
    "guide_kink_amplitude": lambda t: t == "GUIDE",
}
FIELD_ALIAS_CANON = {"rest_length": "size", "strength": "guide_minimum", "linear_drag": "guide_minimum"}

EXPLICIT_DIMS = {
    # force fields (round 8): distances stored without a length unit in RNA (distance_min / _max have one); size,
    # rest_length and guide_minimum share storage with other settings and are decided by the field type (prop_dim)
    ("FieldSettings", "radial_min"): 1,
    ("FieldSettings", "radial_max"): 1,
    ("FieldSettings", "texture_nabla"): 1,
    ("CollisionSettings", "thickness_outer"): 1,
    ("CollisionSettings", "thickness_inner"): 1,
    ("ClothSettings", "voxel_cell_size"): 1,
    ("ClothSettings", "internal_spring_max_length"): 1,
    ("ClothSettings", "target_volume"): 3,
    ("KinematicConstraint", "distance"): 1,
    ("PoseBone", "custom_shape_translation"): 1,
    ("Bone", "bbone_x"): 1, ("Bone", "bbone_z"): 1,
    ("EditBone", "bbone_x"): 1, ("EditBone", "bbone_z"): 1,
    # RNA unit NONE (measured on 5.1.2); only reached when lights and cameras are included
    ("Camera", "ortho_scale"): 1,
    # round 5 (finding 4 and the same audit): RNA unit NONE but a length. Cast size is the radius of the cast shape
    # (4.2 mm off at 1.1 when left), Wave speed a distance per frame, a Skin vertex radius the skin's radius (5.0 mm)
    ("CastModifier", "size"): 1,
    ("WaveModifier", "speed"): 1,
    ("MeshSkinVertex", "radius"): 1,
    # an INVERSE length: the wave profile is exp(-(distance x narrowness)^2), so narrowness takes 1/s (measured: 0.69 mm
    # off with s, 0.00002 mm with 1/s)
    ("WaveModifier", "narrowness"): -1,
    # RNA says LENGTH but these are dimensionless (finding 5): Remesh adaptivity (scaling it changed the topology) and
    # Data Transfer islands precision (a 0..1 precision factor, hard range 0..1)
    ("RemeshModifier", "adaptivity"): 0,
    ("DataTransferModifier", "islands_precision"): 0,
    # round 6 (found by the ``types`` test): RNA subtype COORDINATES, unit NONE, but the Radial centre's offset from the
    # object's origin in object space (a corner normal turned by 0.24 when left at 1.1 on a 1.3 bake); a three-component
    # length, so it takes the per-axis data factor
    ("NormalEditModifier", "offset"): 1,
}
for _t in ("PoseBone", "Bone", "EditBone"):
    for _p in BBONE_CURVES:
        EXPLICIT_DIMS[(_t, _p)] = 1
# Properties that are never written by the generic struct walker (derived, read-only in practice,
# or handled elsewhere).
GENERIC_SKIP = {"dimensions", "matrix_world", "matrix_local", "matrix_basis", "matrix_parent_inverse",
                "location", "delta_location", "rotation_euler", "scale", "execution_time",
                "error_location", "error_rotation", "influence"}

# Custom (ID) properties that hold lengths. key -> dim, or key -> {subkey: dim} for dict props; the subkey "*" stands
# for every subkey (a dict keyed by names the user chose, such as collide.ALT_KEY's part collections).
# Not lengths (never scaled): srs_jiggle_stiffness, _damping, _inertia, _exit_slope, _substeps,
# _rest_contact, and ARP's collide_spread / collide_dist_falloff.
CUSTOM_DIMS = {
    "Object": {shoe_lift.PROP: 1, shoe_lift.MEASURED: 1,
               "srs_lid_shadow_v1": {"rest_z": 1, "margin_travel_mm": 1, "variable_travel_mm": 1},
               "_smart_cloth_suite_skirt_profile_v1": {"clearance": 1, "correction_offset": 1}},
    # The capsules' dressed radii (collide.BASE_KEY) and the radii with a part taken off (collide.ALT_KEY,
    # {part: [head, tail]}) are what collide.apply_parts writes back when a part is shown or hidden: left at the old
    # size, hiding the coat after a resize gave every capsule its old radius back.
    "PoseBone": {"srs_jiggle_gravity": 1, "srs_jiggle_tip_mm": 1, "srs_knee_profile_to_min_y": 1,
                 "srs_knee_profile_to_max_y": 1, collide.BASE_KEY: 1, collide.ALT_KEY: {"*": 1},
                 # 2.62.14: a chain root's per-link collision radii, measured from the mesh at rest (m, an array)
                 "srs_jiggle_link_radii": 1,
                 "collide_dist": 1},
    "Bone": {"lips_floor_offset": 1, "kilt_collide_offset": 1},
    "Armature": {"arp_chin_loc": 1, "arp_chin_pos_vec": 1,
                 "srs_wrist_fold_v1": {"flex_mm": 1, "ext_mm": 1}},
}
# Bone custom props that are 4x4 matrices whose translation is a length
CUSTOM_MATRIX_BONE = {"arp_offset_matrix"}
# SmartRig's own custom keys that are not scaled by CUSTOM_DIMS: flags, names, factors, bake records, and the driver
# expression backups (rewritten with their drivers). Every "srs_*" key SmartRig writes is in CUSTOM_DIMS or here; the
# round-7 test fails on a key in neither, so a new length cannot be left at the old size unnoticed (2.62.5-2.62.8 added
# three: collide.BASE_KEY, collide.ALT_KEY and srs_knee_profile_to_max_y).
CUSTOM_NOT_SCALED_HERE = frozenset((
    "srs_jiggle_stiffness", "srs_jiggle_damping", "srs_jiggle_inertia", "srs_jiggle_exit_slope",
    "srs_jiggle_substeps", "srs_jiggle_rest_contact", "srs_jiggle_collide", "srs_jiggle_bake", "srs_jiggle_muted",
    "srs_chain_key", "srs_chain_bones", "srs_chain_swing", "srs_chain_swing_switch",
    "srs_col_enable", "srs_col_group", "srs_col_inside", "srs_skirt_cloth", "srs_smoothed_regions",
    "srs_linked_keys", "srs_driver_expression_backup",
    "srs_parts_motion",  # 2.62.11: JSON {part: {chains, switch, values, label}} -- names and switch values
    "srs_jiggle_gravity_rest",  # 2.62.12: bool on a chain root (gravity measured from the rest shape)
    "srs_jiggle_rest_clear",  # 2.62.13: bool on a chain root (its capsules shrink at bake time; margin is a code constant)
    "srs_jiggle_entry_push",  # 2.62.16: bool on a chain root
    "srs_costume_part",  # bool on a mesh Bind Costume Part has bound
))
# Key prefixes of the same kind whose full names are made at run time: the part switches (jiggle.register_part_motion
# writes rig["srs_sim_" + part] = int).
CUSTOM_NOT_SCALED_PREFIXES = ("srs_sim_",)

# SmartRig panel settings: lengths are the FLOAT settings whose name ends in _mm plus any FLOAT setting
# whose RNA unit / subtype is a length (chain_floor_z). These three are measurements of the model and are
# always scaled; the target height is the caller's intent and never is.
ALWAYS_SCALED_SETTINGS = ("rescale_current_height_mm", "rescale_measured_top_mm", "rescale_measured_bottom_mm")
NEVER_SCALED_SETTINGS = {"rescale_target_height_mm", "rescale_factor"}
LENGTH_TEXT_SETTINGS = ("knee_profile_front", "knee_profile_back")

# Scope rules
BACKWARD_MODIFIERS = {"ARMATURE": ("object",), "MESH_DEFORM": ("object",), "SURFACE_DEFORM": ("target",),
                      "LATTICE": ("object",), "HOOK": ("object",)}
BACKWARD_CONSTRAINTS = {"CHILD_OF", "COPY_TRANSFORMS", "ARMATURE", "COPY_LOCATION"}

# What reads a mesh object's scale. A mesh scale is baked into the mesh only when nothing else reads the object's
# transform with that scale in it (measured at 1.1 before this rule: a Child Of to it 278.5 mm off, Copy Scale from it
# 35.2 mm, a Hook to it 55.0 mm, a driver reading its X scale 22.0 mm, a Shrinkwrap constraint to it 16.5 mm).
READ_KEEP = "keep"        # the reader sees the scale: the mesh keeps its scale and its data takes plain s
READ_UNIFORM = "uniform"  # the reader works in the mesh's own space and its lengths there take s * k (compensated):
                          # exact for a positive uniform bake k, so the scale is kept only when it is not one
READ_PAIR = "pair"        # a Data Transfer without Object Transform: its owner and this source must take one uniform
                          # factor (raw local coordinates are compared); settled per pair (raw_data_transfer_pairs)
# Constraints that read only the world location of their target (with a vertex-group subtarget, the world position of
# the group's vertices), which a bake does not move: they do not keep a mesh's scale.
LOCATION_ONLY_CONSTRAINTS = {"TRACK_TO", "DAMPED_TRACK", "LOCKED_TRACK", "COPY_LOCATION", "LIMIT_DISTANCE",
                             "STRETCH_TO", "PIVOT"}
# Object paths a Single Property driver variable reads without the object's scale in them (custom properties too).
SCALE_FREE_OBJECT_PATHS = {"location", "delta_location", "rotation_euler", "rotation_quaternion",
                           "rotation_axis_angle", "delta_rotation_euler", "delta_rotation_quaternion", "rotation_mode"}
# Constraints whose result does not change when a target outside the character stays as it is: they take only the
# target's rotation or scale, which the resize never changes. Every other constraint with an object outside the
# character (target, pole, Armature targets, a custom space in use) is reported (W_CON_TARGET_OUT).
CON_OUT_EXACT_TYPES = {"COPY_ROTATION", "COPY_SCALE"}
# Shrinkwrap methods (modifier wrap_method / constraint shrinkwrap_type) whose offset or distance Blender applies in
# the TARGET's space: the point is moved into the target's space, snapped with the offset there and moved back. Project
# works in the owner's space. Measured with the owner's factor: 16.5 mm (owner 0.5), 217.8 mm (FBX-like 0.01 target).
SHRINKWRAP_TARGET_SPACE = {"NEAREST_SURFACEPOINT", "NEAREST_SURFACE", "NEAREST_VERTEX", "TARGET_PROJECT"}

_LAST_REPORT = {}


# ----------------------------------------------------------------------------------------------
# reporting helpers
# ----------------------------------------------------------------------------------------------
def _r(v, n=9):
    try:
        if isinstance(v, (list, tuple)):
            return [_r(x, n) for x in v]
        return round(float(v), n)
    except Exception:
        return str(v)


class Rep:
    """One run's report and its per-run state (nothing is kept at module level between runs)."""

    def __init__(self, report):
        self.d = report
        report.setdefault("changes", [])
        report.setdefault("counts", Counter())
        report.setdefault("warnings", [])
        report.setdefault("untouched", [])
        report.setdefault("drivers", [])
        report.setdefault("expressions_rewritten", [])
        # (struct pointer, property) already scaled in this run: one struct reachable by two paths
        # (e.g. CollisionModifier.settings IS Object.collision) must be scaled exactly once
        self.seen = set()
        self._ns = None

    def change(self, cat, path, before, after, **kw):
        e = {"cat": cat, "path": path, "before": _r(before), "after": _r(after)}
        e.update(kw)
        self.d["changes"].append(e)
        self.d["counts"][cat] += 1

    def warn(self, msg, **kw):
        e = {"msg": msg}
        e.update(kw)
        self.d["warnings"].append(e)

    def untouched(self, what, why):
        e = {"what": what, "why": why}
        if not any(x["what"] == what for x in self.d["untouched"]):
            self.d["untouched"].append(e)

    def namespace(self):
        if self._ns is None:
            self._ns = _expr_namespace()
        return self._ns


def _idpath(idb):
    try:
        coll = {"Object": "objects", "Mesh": "meshes", "Armature": "armatures", "Key": "shape_keys",
                "Material": "materials", "Action": "actions", "Scene": "scenes", "Curve": "curves",
                "Lattice": "lattices", "ShaderNodeTree": "node_groups"}.get(type(idb).__name__, type(idb).__name__)
        return 'bpy.data.%s["%s"]' % (coll, idb.name)
    except Exception:
        return repr(idb)


def warning_subject(entry):
    """The name a report warning is about, for one line of the operator's report."""
    for key in WARNING_SUBJECT_KEYS:
        if key in entry and entry[key] not in (None, ""):
            return str(entry[key])
    return ""


# ----------------------------------------------------------------------------------------------
# dimension rules
# ----------------------------------------------------------------------------------------------
def rna_type_name(st):
    try:
        return st.bl_rna.identifier
    except Exception:
        return type(st).__name__


def prop_dim(owner, ident):
    """Length dimension (0 none, 1 length, 2 area, 3 volume) of RNA property `ident` on `owner`."""
    tn = rna_type_name(owner)
    if (tn, ident) in EXPLICIT_DIMS:
        return EXPLICIT_DIMS[(tn, ident)]
    if tn == "ActionConstraint" and ident in ("min", "max"):
        return 1 if str(owner.transform_channel).startswith("LOCATION") else 0
    if tn == "FieldSettings" and ident in FIELD_ALIASED_LENGTHS:
        # one stored value behind two or three names (measured on 5.1.2, round 8: size IS rest_length, guide_minimum IS
        # strength IS linear_drag): exactly one name is scaled, the one the field type uses as a distance -- scaling
        # both doubled the factor (0.2 -> 0.242 at 1.1), and guide_minimum outside a Guide field would scale the
        # strength
        return 1 if FIELD_ALIASED_LENGTHS[ident](str(owner.type)) else 0
    if tn == "BevelModifier" and ident == "width":
        # width (LENGTH) and width_pct (PERCENTAGE) are one stored value: with the Percent offset type it is a
        # percentage of the edge length, not a length (round 6, found by the ``types`` test: 20 % became 22 % and the
        # bevel moved 3.1 mm at rest at 1.1)
        return 0 if str(owner.offset_type) == "PERCENT" else 1
    try:
        p = owner.bl_rna.properties.get(ident)
    except Exception:
        p = None
    if p is None or p.type != "FLOAT":
        return 0
    if p.subtype == "MATRIX":
        return 0
    if p.unit == "LENGTH":
        return 1
    if p.unit == "AREA":
        return 2
    if p.unit == "VOLUME":
        return 3
    if p.subtype in LEN_SUBTYPES:
        return 1
    return 0


def custom_dim(owner, key, sub=None):
    tn = rna_type_name(owner)
    table = CUSTOM_DIMS.get(tn, {})
    if tn == "Bone" and key == "three_bones_leg_ik_height":
        try:
            return 1 if owner.get("three_bones_leg") else 0
        except Exception:
            return 0
    v = table.get(key, 0)
    if isinstance(v, dict):
        return v.get(sub, 0) if sub is not None else 0
    return v


# ----------------------------------------------------------------------------------------------
# RNA data path parsing
# ----------------------------------------------------------------------------------------------
def parse_path(path):
    """Tokenise an RNA path into ('attr', name) / ('key', str) / ('idx', int)."""
    toks = []
    i, n = 0, len(path)
    while i < n:
        c = path[i]
        if c == ".":
            i += 1
            continue
        if c == "[":
            i += 1
            if i < n and path[i] in "\"'":
                q = path[i]
                i += 1
                buf = []
                while i < n and path[i] != q:
                    if path[i] == "\\" and i + 1 < n:
                        buf.append(path[i + 1])
                        i += 2
                        continue
                    buf.append(path[i])
                    i += 1
                i += 1  # closing quote
                while i < n and path[i] != "]":
                    i += 1
                i += 1
                toks.append(("key", "".join(buf)))
            else:
                j = path.index("]", i)
                toks.append(("idx", int(path[i:j].strip())))
                i = j + 1
            continue
        j = i
        while j < n and (path[j].isalnum() or path[j] == "_"):
            j += 1
        if j == i:
            raise ValueError("bad path %r at %d" % (path, i))
        toks.append(("attr", path[i:j]))
        i = j
    return toks


def resolve_leaf(idb, path):
    """Return (owner, ident, kind, index) where kind is 'rna' or 'custom' (ident = custom key),
    or (None, ...) if it cannot be resolved."""
    toks = parse_path(path)
    obj = idb
    idx = None
    if toks and toks[-1][0] == "idx":
        idx = toks[-1][1]
        toks = toks[:-1]
    if not toks:
        return None, None, None, idx
    for kind, val in toks[:-1]:
        try:
            if kind == "attr":
                obj = getattr(obj, val)
            else:
                obj = obj[val]
        except Exception:
            return None, None, None, idx
    kind, val = toks[-1]
    if kind == "attr":
        if hasattr(obj, "bl_rna") and val in obj.bl_rna.properties:
            return obj, val, "rna", idx
        return obj, val, "attr?", idx
    if kind == "key":
        return obj, val, "custom", idx
    return None, None, None, idx


def path_dim(idb, path):
    """Dimension of the value addressed by `path` on ID `idb`; None if unresolved."""
    try:
        owner, ident, kind, idx = resolve_leaf(idb, path)
    except Exception:
        return None
    if owner is None:
        return None
    if kind == "rna":
        return prop_dim(owner, ident)
    if kind == "custom":
        return custom_dim(owner, ident)
    return None


# ----------------------------------------------------------------------------------------------
# generic struct walker
# ----------------------------------------------------------------------------------------------
def scale_struct(st, s, rep, path, cat, depth=0, maxdepth=2, axis=None):
    """Multiply every length-valued float of ``st`` (and its non-ID sub-structs) by s**dim.

    ``axis`` (three signed factors) is given for a modifier on an object whose scale is baked into its mesh: a
    three-component length (a local position or offset) then takes the per-axis factor of the mesh data, which is
    exact even for a non-uniform or mirrored bake; scalar lengths take ``s``.
    """
    try:
        props = list(st.bl_rna.properties)
        ptr = st.as_pointer()
    except Exception:
        return
    for p in props:
        ident = p.identifier
        if ident in ("rna_type",) or ident in GENERIC_SKIP:
            continue
        if p.type == "FLOAT":
            if p.is_readonly:
                continue
            dim = prop_dim(st, ident)
            if not dim:
                continue
            seen_key = (ptr, FIELD_ALIAS_CANON.get(ident, ident) if rna_type_name(st) == "FieldSettings" else ident)
            if seen_key in rep.seen:
                continue
            rep.seen.add(seen_key)
            f = s ** dim
            try:
                v = getattr(st, ident)
            except Exception:
                continue
            if p.is_array:
                try:
                    old = [float(x) for x in v]
                except Exception:
                    rep.warn(W_ARRAY, path=path + "." + ident)
                    continue
                if all(x == 0.0 for x in old):
                    continue
                if axis is not None and dim == 1 and len(old) == 3:
                    new = [x * a for x, a in zip(old, axis)]
                else:
                    new = [x * f for x in old]
                setattr(st, ident, new)
                got = [float(x) for x in getattr(st, ident)]
                rep.change(cat, path + "." + ident, old, got)
                if any(_clamped(w, g) for w, g in zip(new, got)):
                    rep.warn(W_CLAMPED, path=path + "." + ident, wanted=_r(new), stored=_r(got))
            else:
                old = float(v)
                if old == 0.0:
                    continue
                setattr(st, ident, old * f)
                got = float(getattr(st, ident))
                rep.change(cat, path + "." + ident, old, got)
                if _clamped(old * f, got):
                    rep.warn(W_CLAMPED, path=path + "." + ident, wanted=_r(old * f), stored=_r(got))
        elif p.type == "POINTER" and depth < maxdepth:
            try:
                sub = getattr(st, ident)
            except Exception:
                continue
            if sub is None or isinstance(sub, bpy.types.ID):
                continue
            scale_struct(sub, s, rep, path + "." + ident, cat, depth + 1, maxdepth, axis)


def _clamped(wanted, got):
    """True when Blender stored ``got`` for ``wanted`` beyond float32 rounding (a hard minimum or maximum)."""
    return abs(got - wanted) > 1.0e-5 * max(abs(wanted), 1.0e-6)


def conj_matrix(m, s):
    m = m.copy()
    m.translation = m.translation * s
    return m


# ----------------------------------------------------------------------------------------------
# custom properties
# ----------------------------------------------------------------------------------------------
def _scale_idprop_value(v, f):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v) * f
    try:
        return [float(x) * f for x in v]
    except Exception:
        return None


def _plain(v):
    try:
        if isinstance(v, (int, float, str)):
            return v
        return [float(x) for x in v]
    except Exception:
        return str(v)


def scale_custom_props(owner, s, rep, path, cat="custom_prop"):
    tn = rna_type_name(owner)
    table = CUSTOM_DIMS.get(tn, {})
    try:
        keys = list(owner.keys())
    except Exception:
        return
    for key in keys:
        spec = table.get(key)
        if tn == "Bone" and key == "three_bones_leg_ik_height":
            spec = 1 if owner.get("three_bones_leg") else None
            if spec is None:
                rep.untouched(path + '["three_bones_leg_ik_height"]', "three_bones_leg is off; value unused")
        if tn == "Bone" and key in CUSTOM_MATRIX_BONE:
            try:
                M = Matrix([list(r) for r in owner[key]])
                old = list(M.translation)
                M.translation = M.translation * s
                owner[key] = [list(r) for r in M]
                rep.change(cat, path + '["%s"].translation' % key, old, list(M.translation))
            except Exception as e:
                rep.warn(W_MATRIX_PROP, path=path + '["%s"]' % key, error=repr(e))
            continue
        if spec is None:
            continue
        val = owner[key]
        if isinstance(spec, dict):
            try:
                subs = [(sub, spec["*"]) for sub in val.keys()] if "*" in spec else list(spec.items())
            except Exception as e:
                rep.warn(W_DICT_PROP, path=path + '["%s"]' % key, error=repr(e))
                continue
            for sub, dim in subs:
                try:
                    if sub not in val:
                        continue
                    old = _plain(val[sub])
                    new = _scale_idprop_value(old, s ** dim)
                    if new is None or new == old:
                        continue
                    val[sub] = new
                    rep.change(cat, path + '["%s"]["%s"]' % (key, sub), old, new)
                except Exception as e:
                    rep.warn(W_DICT_PROP, path=path + '["%s"]["%s"]' % (key, sub), error=repr(e))
        else:
            old = _plain(val)
            new = _scale_idprop_value(old, s ** spec)
            if new is None:
                rep.warn(W_NOT_NUMERIC, path=path + '["%s"]' % key)
                continue
            if new == old:
                continue
            owner[key] = new
            rep.change(cat, path + '["%s"]' % key, old, new)


# ----------------------------------------------------------------------------------------------
# F-curves
# ----------------------------------------------------------------------------------------------
def elastic_sign_problem(fc):
    """True when an ELASTIC segment of ``fc`` cannot take a negative value factor: Blender's elastic easing compares the
    amplitude with |change| and, when the amplitude reaches it, takes its phase from asin(change / amplitude), whose
    sign turns with the value (measured on 5.1.2: up to 1.10 off for a factor of -1.1 with amplitude 0.8 over a change
    of 0.2; an amplitude of 0 or below |change| scales exactly)."""
    kps = fc.keyframe_points
    for i in range(len(kps) - 1):
        kp = kps[i]
        if kp.interpolation != "ELASTIC" or kp.amplitude == 0.0:
            continue
        if kp.amplitude >= abs(kps[i + 1].co[1] - kp.co[1]):
            return True
    return False


def _scale_elastic_keys(kps, a, b):
    """ELASTIC keys: the amplitude is a value (compared with |change| and multiplied into the bounce), the period a time
    (x). With keys (x a, y b) Blender's elastic easing gives b F(x / a) exactly when the amplitude takes |b| and the
    period takes a (measured on 5.1.2: 1.4e-6 at most over the three easings, both amplitude branches and an automatic
    period; the keys alone left an empty 2.31 mm off at frame 3 at 1.1, round 6 finding 1). Only the keys that use them
    (interpolation ELASTIC) are written."""
    n = 0
    for kp in kps:
        if kp.interpolation != "ELASTIC":
            continue
        if kp.amplitude != 0.0 and b != 1.0:
            kp.amplitude = kp.amplitude * abs(b)
        if kp.period != 0.0 and a != 1.0:
            kp.period = kp.period * a
        n += 1
    return n


def scale_fcurve(fc, a, b, rep, path, cat, allow_add_generator=True):
    """Map F(x) -> b * F(x / a): keys (x*a, y*b) incl. handles and elastic amplitude / period, F-modifiers
    accordingly."""
    if a == 1.0 and b == 1.0:
        return False
    kps = fc.keyframe_points
    before = [tuple(kp.co) for kp in kps]
    if b < 0.0 and elastic_sign_problem(fc):
        rep.warn(W_ELASTIC_SIGN, path=path, factor=b)
    for kp in kps:
        co = kp.co.copy()
        hl = kp.handle_left.copy()
        hr = kp.handle_right.copy()
        kp.co = (co[0] * a, co[1] * b)
        kp.handle_left = (hl[0] * a, hl[1] * b)
        kp.handle_right = (hr[0] * a, hr[1] * b)
    n_elastic = _scale_elastic_keys(kps, a, b)
    mods = []
    if n_elastic:
        mods.append(("ELASTIC_KEYS", n_elastic))
    for m in fc.modifiers:
        t = m.type
        if m.use_restricted_range:
            m.frame_start, m.frame_end = m.frame_start * a, m.frame_end * a
            m.blend_in, m.blend_out = m.blend_in * a, m.blend_out * a
        if t == "GENERATOR":
            old = list(m.coefficients)
            if m.mode == "POLYNOMIAL":
                new = [c * b / (a ** i) for i, c in enumerate(old)]
            else:  # POLYNOMIAL_FACTORISED: c0 * prod(c_{2i-1} x + c_{2i})
                new = list(old)
                new[0] = old[0] * b
                for i in range(1, len(old), 2):
                    new[i] = old[i] / a
            for i, c in enumerate(new):
                m.coefficients[i] = c
            mods.append(("GENERATOR", m.mode, _r(old[:m.poly_order + 1]), _r(list(m.coefficients)[:m.poly_order + 1])))
        elif t == "FNGENERATOR":
            m.amplitude *= b
            m.value_offset *= b
            m.phase_multiplier /= a
            mods.append(("FNGENERATOR",))
        elif t == "LIMITS":
            m.min_x *= a
            m.max_x *= a
            if b >= 0.0:
                m.min_y *= b
                m.max_y *= b
            else:
                # a negative factor turns the value range over: the old maximum becomes the new minimum
                lo, hi, use_lo, use_hi = m.min_y, m.max_y, m.use_min_y, m.use_max_y
                m.min_y, m.max_y = hi * b, lo * b
                m.use_min_y, m.use_max_y = use_hi, use_lo
            mods.append(("LIMITS",))
        elif t == "NOISE":
            # Replace / Add / Subtract add noise x strength to the value (a length: b); Multiply multiplies the value by
            # noise x strength, a factor (round 6, finding 2: scaling it put a keyed empty 25.6 mm off at frame 7)
            if m.blend_type != "MULTIPLY":
                m.strength *= b
            m.scale *= a
            m.offset *= a
            mods.append(("NOISE", m.blend_type))
        elif t == "ENVELOPE":
            m.reference_value *= b
            m.default_min *= b
            m.default_max *= b
            for cp in m.control_points:
                cp.frame *= a
                cp.min *= b
                cp.max *= b
            mods.append(("ENVELOPE",))
        elif t == "STEPPED":
            m.frame_step *= a
            m.frame_offset *= a
            # FModifierStepped has two frame_start / frame_end (the restricted range and its own), and one
            # Python write reaches both (measured on 5.1.2): with the restricted range on they were scaled above
            if not m.use_restricted_range:
                m.frame_start *= a
                m.frame_end *= a
            mods.append(("STEPPED",))
        elif t in ("CYCLES", "SMOOTH"):
            pass
        else:
            rep.warn(W_FMOD, path=path, type=t)
    added = False
    if len(kps) == 0 and allow_add_generator and abs(b / a - 1.0) > 0.0:
        has_gen = any(m.type == "GENERATOR" and not m.use_additive and not m.mute for m in fc.modifiers)
        if not has_gen:
            g = fc.modifiers.new(type="GENERATOR")
            g.mode = "POLYNOMIAL"
            g.poly_order = 1
            g.use_additive = False
            g.coefficients[0] = 0.0
            g.coefficients[1] = b / a
            added = True
            mods.append(("GENERATOR_ADDED", [0.0, b / a]))
    rep.change(cat, path, before, [tuple(kp.co) for kp in kps], x_factor=a, y_factor=b, modifiers=mods,
               generator_added=added)
    return True


# ----------------------------------------------------------------------------------------------
# expression solver
# ----------------------------------------------------------------------------------------------
def _expr_namespace():
    ns = {k: getattr(math, k) for k in dir(math) if not k.startswith("_")}
    ns.update(min=min, max=max, abs=abs, round=round, pow=pow, int=int, float=float, bool=bool,
              clamp=lambda x, lo=0.0, hi=1.0: min(max(x, lo), hi),
              lerp=lambda a, b, t: a + (b - a) * t,
              smoothstep=lambda e0, e1, x: (lambda t: t * t * (3 - 2 * t))(min(max((x - e0) / (e1 - e0), 0.0), 1.0)),
              True_=True)
    try:
        for k, v in bpy.app.driver_namespace.items():
            if k not in ns and (callable(v) or isinstance(v, (int, float))):
                ns[k] = v
    except Exception:
        pass
    ns["__builtins__"] = {}
    return ns


def _number_tokens(expr):
    out = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(expr).readline):
            if tok.type == tokenize.NUMBER:
                (r0, c0), (r1, c1) = tok.start, tok.end
                if r0 != 1 or r1 != 1:
                    continue
                try:
                    val = float(tok.string)
                except ValueError:
                    continue
                out.append((c0, c1, tok.string, val))
    except (tokenize.TokenError, IndentationError):
        pass
    return out


def _fmt(x):
    return repr(float(x))


def _build(expr, toks, assign):
    """assign: dict token_index -> multiplier."""
    parts = []
    last = 0
    for i, (c0, c1, txt, val) in enumerate(toks):
        if i in assign:
            parts.append(expr[last:c0])
            parts.append(_fmt(val * assign[i]))
            last = c1
    parts.append(expr[last:])
    out = "".join(parts)
    if len(out) > EXPR_MAX:
        parts = []
        last = 0
        for i, (c0, c1, txt, val) in enumerate(toks):
            if i in assign:
                parts.append(expr[last:c0])
                parts.append("%.12g" % (val * assign[i]))
                last = c1
        parts.append(expr[last:])
        out = "".join(parts)
    return out


def _eval(code, vals, ns):
    scope = dict(ns)
    scope.update(vals)
    return float(eval(code, scope))


def _samples(var_dims, consts, current, s, n=400, seed=12345):
    rnd = random.Random(seed)
    nz = [abs(c) for c in consts if c != 0.0]
    per = {}
    for name, dim in var_dims.items():
        cur = current.get(name, 0.0) if current else 0.0
        if dim:
            M = max([abs(cur), 0.01] + nz)
            pts = [0.0, cur, -cur]
            for c in nz:
                for k in (1.0, s, 1.0 / s, (1 + s) / 2, (1 + 1 / s) / 2, 0.5, 2.0):
                    pts += [c * k, -c * k]
            pts += [rnd.uniform(-3 * M, 3 * M) for _ in range(40)]
            pts += [rnd.uniform(-0.1, 0.1) for _ in range(20)]
        else:
            pts = [0.0, 1.0, 0.5, 2.0, -1.0, cur] + [c for c in consts] + [rnd.uniform(-3, 3) for _ in range(30)]
        per[name] = pts
    names = list(var_dims)
    out = []
    if not names:
        return [{}]
    for _ in range(n):
        out.append({nm: rnd.choice(per[nm]) for nm in names})
    # also the all-current point
    out.append({nm: (current.get(nm, 0.0) if current else 0.0) for nm in names})
    return out


def _close(a, b):
    if math.isnan(a) or math.isnan(b):
        return math.isnan(a) and math.isnan(b)
    return abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b)) + 1e-12


def solve_expression(expr, var_dims, k, s, current=None, fixed_d=None, max_rewrites=4, ns=None):
    """Find the smallest set of numeric constants to multiply by s (then s or 1/s) such that
    f'(s^dim * v) == s^d * f(v) for all samples. Returns dict (with "error" when none exists)."""
    if ns is None:
        ns = _expr_namespace()
    toks = _number_tokens(expr)
    consts = [t[3] for t in toks]
    try:
        code0 = compile(expr, "<drv>", "eval")
    except SyntaxError:
        return {"error": "syntax"}
    base = []
    for vals in _samples(var_dims, consts, current or {}, s):
        try:
            y = _eval(code0, vals, ns)
        except Exception:
            continue
        if math.isfinite(y):
            base.append((vals, y))
    if len(base) < 20:
        return {"error": "too few evaluable samples (%d)" % len(base)}
    scaled_vals = [({nm: v * (s ** var_dims[nm]) for nm, v in vals.items()}, y) for vals, y in base]
    cand = [i for i, t in enumerate(toks) if t[3] != 0.0]
    ds = [fixed_d] if fixed_d is not None else [0, 1]

    def check(cexpr, d):
        try:
            code = compile(cexpr, "<drv>", "eval")
        except SyntaxError:
            return False
        f = s ** d
        for vals, y in scaled_vals:
            try:
                y2 = _eval(code, vals, ns)
            except Exception:
                return False
            if not _close(y2, f * y):
                return False
        return True

    for mults in ((s,), (s, 1.0 / s)):
        for nrw in range(0, min(len(cand), max_rewrites) + 1):
            sols = []
            for subset in itertools.combinations(cand, nrw):
                for ma in itertools.product(mults, repeat=nrw):
                    if len(mults) == 2 and nrw > 0 and all(m == s for m in ma):
                        continue
                    if len(mults) == 2 and nrw == 0:
                        continue
                    assign = dict(zip(subset, ma))
                    cexpr = _build(expr, toks, assign) if assign else expr
                    for d in ds:
                        if check(cexpr, d):
                            sols.append({"d": d, "expr": cexpr,
                                         "rewritten": [(toks[i][2], _fmt(toks[i][3] * m)) for i, m in assign.items()]})
            if sols:
                pref = [x for x in sols if x["d"] == k] or sols
                best = pref[0]
                distinct = {x["expr"] for x in pref}
                best["ambiguous"] = len(distinct) > 1
                best["alternatives"] = [x["expr"] for x in sols if x["expr"] != best["expr"]][:6]
                best["n_samples"] = len(base)
                return best
    return {"error": "no constant rewrite found"}


# ----------------------------------------------------------------------------------------------
# driver processing
# ----------------------------------------------------------------------------------------------
class Scope:
    def __init__(self, objs):
        self.objects = set(objs)
        self.ids = set()
        for o in objs:
            self.ids.add(o)
            if o.data is not None:
                self.ids.add(o.data)
                sk = getattr(o.data, "shape_keys", None)
                if sk is not None:
                    self.ids.add(sk)

    def has(self, idb):
        if idb is None:
            return False
        if idb in self.ids:
            return True
        try:
            orig = idb.original
            return orig in self.ids
        except Exception:
            return False


def _dim_of_factor(f, s):
    """The power d of s that the factor ``f`` is (0, 1, 2, 3 or -1), or None when it is not one (a baked factor)."""
    for d in (0, 1, 2, 3, -1):
        if abs(f - s ** d) <= 1.0e-9 * max(1.0, abs(f)):
            return d
    return None


def var_dim(var, scope, rep, where, vf=None):
    t = var.type
    if t == "ROTATION_DIFF":
        return 0
    if t == "TRANSFORMS":
        tg = var.targets[0]
        if tg.transform_type.startswith("LOC"):
            return 1 if scope.has(tg.id) else 0
        return 0
    if t == "LOC_DIFF":
        a = scope.has(var.targets[0].id)
        b = scope.has(var.targets[1].id)
        if a and b:
            return 1
        if a or b:
            rep.warn(W_LOC_DIFF, where=where, var=var.name)
        return 0
    if t == "SINGLE_PROP":
        tg = var.targets[0]
        if tg.id is None or not scope.has(tg.id):
            return 0
        f = vf(tg.id, tg.data_path) if vf is not None else None
        if f is not None:
            # a modifier / constraint setting the resize changes by its own rule (Displace strength, a target-space
            # offset...): the variable changes by that factor, which must be a power of s for the solver
            d = None if math.isnan(f) else _dim_of_factor(f, vf.s)
            if d is None:
                rep.warn(W_ANIM_FACTOR, where=where, var=var.name, path=tg.data_path, factor=f)
                return 0
            return d
        d = path_dim(tg.id, tg.data_path)
        if d is None:
            rep.warn(W_VAR_PATH, where=where, var=var.name, path=tg.data_path)
            return 0
        return d
    if t == "CONTEXT_PROP":
        rep.warn(W_CONTEXT_PROP, where=where, var=var.name)
        return 0
    return 0


def _var_current(var):
    try:
        tg = var.targets[0]
        if var.type == "SINGLE_PROP" and tg.id is not None:
            return float(tg.id.path_resolve(tg.data_path))
    except Exception:
        pass
    return 0.0


def process_driver(idb, fc, s, scope, rep, srs_backup=None, vf=None):
    """``vf`` (a ``ValueFactors``) gives the factor of a driven modifier / constraint setting that the resize changes by
    its own rule (s x a baked factor, a Displace strength, a target-space length...): the F-curve output takes that
    factor, exactly what the setting itself took (round 5, finding 9)."""
    where = "%s.drivers[%s[%d]]" % (_idpath(idb), fc.data_path, fc.array_index)
    drv = fc.driver
    owner_in = scope.has(idb)
    k = 0
    out_f = None
    if owner_in:
        out_f = vf(idb, fc.data_path, fc.array_index) if vf is not None else None
        if out_f is not None and math.isnan(out_f):
            rep.warn(W_ANIM_FACTOR, where=where)
            return None
        kd = path_dim(idb, fc.data_path)
        if kd is None:
            if out_f is None:
                rep.warn(W_DRIVEN_PATH, where=where)
            kd = 0
        k = kd
    vdims = {}
    for v in drv.variables:
        vdims[v.name] = var_dim(v, scope, rep, where, vf)
    any_len_in = any(vdims.values())
    entry = {"where": where, "type": drv.type, "k_out": k, "var_dims": dict(vdims)}
    if out_f is not None:
        entry["out_factor"] = out_f
    if not any_len_in and k == 0 and (out_f is None or out_f == 1.0):
        return None
    d = 0
    if drv.type == "SCRIPTED":
        entry["expression_before"] = drv.expression
        if drv.use_self:
            rep.warn(W_USE_SELF, where=where)
        if any_len_in:
            cur = {v.name: _var_current(v) for v in drv.variables}
            sol = solve_expression(drv.expression, vdims, k, s, current=cur, ns=rep.namespace())
            if sol is None or "error" in sol:
                rep.warn(W_EXPR, where=where, expression=drv.expression, detail=sol)
                entry["error"] = sol
                rep.d["drivers"].append(entry)
                return entry
            d = sol["d"]
            entry["solution"] = {k2: sol[k2] for k2 in ("d", "rewritten", "ambiguous", "alternatives", "n_samples")}
            if sol["expr"] != drv.expression:
                old = drv.expression
                drv.expression = sol["expr"]
                rep.change("driver_expression", where + ".driver.expression", old, drv.expression)
                rep.d["expressions_rewritten"].append({"where": where, "before": old, "after": drv.expression,
                                                        "rewritten_constants": sol["rewritten"],
                                                        "ambiguous": sol["ambiguous"]})
            if sol.get("ambiguous"):
                rep.warn(W_EXPR_AMBIGUOUS, where=where, chosen=sol["expr"], alternatives=sol["alternatives"])
        else:
            d = 0
    else:  # AVERAGE / SUM / MIN / MAX
        ds = set(vdims.values())
        if len(ds) > 1:
            rep.warn(W_AGGREGATE, where=where, var_dims=vdims)
            entry["error"] = "mixed"
            rep.d["drivers"].append(entry)
            return entry
        d = ds.pop() if ds else 0
    a = s ** d
    b = out_f if out_f is not None else s ** k
    entry["value_dim"] = d
    entry["x_factor"] = a
    entry["y_factor"] = b
    if a != 1.0 or b != 1.0:
        scale_fcurve(fc, a, b, rep, where + ".fcurve", "driver_fcurve")
    # SmartRig keeps a backup of ARP expressions it wrapped; keep it consistent.
    if srs_backup is not None:
        key = "%s|%d" % (fc.data_path, fc.array_index)
        if key in srs_backup and drv.type == "SCRIPTED":
            bexpr = str(srs_backup[key])
            cur = {v.name: _var_current(v) for v in drv.variables}
            sol = solve_expression(bexpr, vdims, k, s, current=cur, fixed_d=d, ns=rep.namespace())
            if sol is None or "error" in sol:
                rep.warn(W_BACKUP, key=key, expression=bexpr, detail=sol)
            elif sol["expr"] != bexpr:
                srs_backup[key] = sol["expr"]
                rep.change("srs_backup_expression", 'srs_driver_expression_backup["%s"]' % key, bexpr, sol["expr"])
                rep.d["expressions_rewritten"].append({"where": "srs_driver_expression_backup[%s]" % key,
                                                        "before": bexpr, "after": sol["expr"],
                                                        "rewritten_constants": sol["rewritten"],
                                                        "ambiguous": sol["ambiguous"]})
    rep.d["drivers"].append(entry)
    return entry


def all_anim_ids():
    out = []
    # textures and particle settings carry drivers too (round 9, the round-4 verifier's finding 6: a Displace texture
    # outside the character, its brightness driven by the spine's height, moved 22.00 mm with no note)
    for coll in (bpy.data.objects, bpy.data.meshes, bpy.data.armatures, bpy.data.shape_keys, bpy.data.materials,
                 bpy.data.node_groups, bpy.data.scenes, bpy.data.worlds, bpy.data.lights, bpy.data.cameras,
                 bpy.data.curves, bpy.data.lattices, bpy.data.textures, bpy.data.particles):
        for idb in coll:
            out.append(idb)
            if isinstance(idb, (bpy.types.Material, bpy.types.World, bpy.types.Light)):
                nt = getattr(idb, "node_tree", None)
                if nt is not None:
                    out.append(nt)
    return out


def invalid_drivers():
    """Drivers Blender currently marks invalid, as 'name:path[index]'."""
    bad = []
    for idb in all_anim_ids():
        ad = getattr(idb, "animation_data", None)
        if not ad:
            continue
        for fc in ad.drivers:
            if not (fc.driver.is_valid and fc.is_valid):
                bad.append("%s:%s[%d]" % (idb.name, fc.data_path, fc.array_index))
    return bad


# ----------------------------------------------------------------------------------------------
# actions
# ----------------------------------------------------------------------------------------------
def _slot_name(slot):
    """The slot's name as the Action editor shows it (``name_display``, without the ID-type prefix)."""
    if slot is None:
        return "?"
    try:
        return str(slot.name_display or slot.identifier)
    except Exception:
        return str(getattr(slot, "identifier", "?"))


def iter_channelbags(action):
    for ly in action.layers:
        for st in ly.strips:
            try:
                bags = st.channelbags
            except Exception:
                continue
            for cb in bags:
                yield cb


def _action_fcurve_dim(tgt, fc):
    """Length dimension of an action F-curve on the ID ``tgt`` (None when the path cannot be judged)."""
    dim = path_dim(tgt, fc.data_path)
    if dim is None:
        # pose.bones["x"].location for a bone that is missing etc: decide by leaf name
        leaf = fc.data_path.rsplit(".", 1)[-1]
        if leaf in ("location", "delta_location") or leaf in BBONE_CURVES:
            dim = 1
    return dim


def blend_uses(idbs):
    """``{(action pointer, slot handle): {"MULTIPLY", "OTHER"}}``: how the IDs ``idbs`` use each action slot.

    An NLA strip with the Multiply blend (or inside a Multiply meta strip), and an active action blended with Multiply,
    multiplies what lies below it: every channel value of its action is a factor, never a length (measured: scaling the
    location keys of a Multiply strip by 1.1 put the character 8.58 mm off). Every other use (Replace, Combine, Add,
    Subtract, the active action) holds lengths."""
    uses = {}

    def add(act, slot, multiply):
        if act is None or slot is None:
            return
        uses.setdefault((act.as_pointer(), slot.handle), set()).add("MULTIPLY" if multiply else "OTHER")

    for idb in idbs:
        ad = getattr(idb, "animation_data", None)
        if not ad:
            continue
        if ad.action is not None:
            add(ad.action, ad.action_slot, ad.action_blend_type == "MULTIPLY")
        for tr in ad.nla_tracks:
            stack = [(st, False) for st in tr.strips]
            while stack:
                st, under = stack.pop()
                multiply = under or st.blend_type == "MULTIPLY"
                if st.type == "META":
                    stack.extend((inner, multiply) for inner in st.strips)
                elif st.type == "CLIP":
                    add(st.action, st.action_slot, multiply)
    return uses


def _same_factor(a, b):
    if a is None or b is None:
        return a is None and b is None
    if math.isnan(a) or math.isnan(b):
        return math.isnan(a) and math.isnan(b)
    return a == b


def _unused_slot_owner(cb, slot, scope_ids):
    """The in-scope object an action slot that nothing uses belongs to, or None: its identifier names the object
    ("OB" + name), or one of its curves is a length channel of a bone of an in-scope armature."""
    objs = [i for i in scope_ids if isinstance(i, bpy.types.Object)]
    ident = str(getattr(slot, "identifier", "") or "")
    for o in objs:
        if ident == "OB" + o.name:
            return o.name
    for o in objs:
        if o.type != "ARMATURE" or o.pose is None:
            continue
        for fc in cb.fcurves:
            if fc.data_path.startswith('pose.bones["') and path_dim(o, fc.data_path):
                return o.name
    return None


def process_actions(s, scope, rep, vf=None):
    """Scale the length channels of every action slot used only by the character. A modifier / constraint setting that
    the resize changes by its own rule takes that factor (``vf``, round 5 finding 9: keyed Solidify thickness on a
    1.5 bake, Displace strength, a target-space Shrinkwrap offset), every other channel s**dimension."""
    uses = blend_uses(scope.ids)
    for act in bpy.data.actions:
        if _is_linked(act):
            # never written: a library action comes back as it was when the file is opened again (preflight refuses
            # a linked action the character uses)
            continue
        bags = list(iter_channelbags(act))
        nfc = sum(len(cb.fcurves) for cb in bags)
        if nfc == 0:
            continue
        for cb in bags:
            slot = cb.slot
            try:
                users = list(slot.users()) if slot is not None else []
            except Exception:
                users = []
            ins = [u for u in users if scope.has(u)]
            outs = [u for u in users if not scope.has(u)]
            sname = _slot_name(slot)
            if not users:
                owner = _unused_slot_owner(cb, slot, scope.ids)
                if owner is not None:
                    rep.warn(W_ACTION_UNUSED, action=act.name, slot=sname, subject="%s (%s)" % (act.name, owner))
                else:
                    rep.untouched('actions["%s"] slot %s' % (act.name, sname), "slot has no users; not scaled")
                continue
            if outs and ins:
                rep.warn(W_SLOT_SHARED, action=act.name, slot=sname, users=[u.name for u in users])
                continue
            if not ins:
                rep.untouched('actions["%s"] slot %s' % (act.name, sname),
                              "used only by out-of-scope IDs: %s" % [u.name for u in outs])
                continue
            if uses.get((act.as_pointer(), slot.handle)) == {"MULTIPLY"}:
                # factors, not lengths (a slot used both ways is refused by preflight)
                rep.untouched('actions["%s"] slot %s' % (act.name, sname),
                              "used only by Multiply NLA strips: its values are factors; not scaled")
                rep.d["counts"]["action_slot_multiply_left"] += 1
                continue
            tgt = ins[0]
            for fc in cb.fcurves:
                where = 'actions["%s"].%s[%d]' % (act.name, fc.data_path, fc.array_index)
                f = None
                if vf is not None:
                    fs = [vf(u, fc.data_path, fc.array_index) for u in ins]
                    f = fs[0]
                    if any(not _same_factor(x, f) for x in fs[1:]):
                        # one channel, two users that took different factors (one baked, one not)
                        rep.warn(W_ANIM_FACTOR, where=where, users=[u.name for u in ins])
                        continue
                if f is not None:
                    if math.isnan(f):
                        rep.warn(W_ANIM_FACTOR, where=where)
                        continue
                    if f != 1.0:
                        scale_fcurve(fc, 1.0, f, rep, where, "action_fcurve", allow_add_generator=False)
                    continue
                dim = _action_fcurve_dim(tgt, fc)
                if dim is None:
                    rep.warn(W_ACTION_PATH, action=act.name, path=fc.data_path)
                    continue
                if dim:
                    scale_fcurve(fc, 1.0, s ** dim, rep, where, "action_fcurve", allow_add_generator=False)


# ----------------------------------------------------------------------------------------------
# materials
# ----------------------------------------------------------------------------------------------
# Musgrave is no longer a shader node on 5.1.2 (it is ShaderNodeTexNoise.noise_type), so it is not listed.
TEX_SCALE_NODES = {"TEX_NOISE", "TEX_VORONOI", "TEX_WAVE", "TEX_MAGIC", "TEX_CHECKER", "TEX_BRICK", "TEX_GABOR"}


def _linked_from(sock):
    if not sock.is_linked:
        return None
    lk = sock.links[0]
    return lk.from_node, lk.from_socket


def _scale_materials(scope_objs, s, rep):
    sset = set(scope_objs)
    users_in, users_out = {}, {}
    for o in bpy.data.objects:
        mats = []
        try:
            mats = [sl.material for sl in o.material_slots if sl.material is not None]
        except Exception:
            pass
        for m in mats:
            (users_in if o in sset else users_out).setdefault(m, set()).add(o.name)
        # a Geometry Nodes tree can apply a material too (Set Material): an outside one shares it (round 8, finding 6)
        if o not in sset:
            for md in getattr(o, "modifiers", ()):
                if md.type == "NODES" and md.node_group is not None:
                    for m in _node_tree_ids(md.node_group)[2]:
                        users_out.setdefault(m, set()).add("%s: %s" % (o.name, md.name))
                    # a Material input of the modifier itself (round 9, the round-4 verifier's finding 8)
                    try:
                        values = [md[k] for k in md.keys()]
                    except Exception:
                        values = []
                    for v in values:
                        if isinstance(v, bpy.types.Material):
                            users_out.setdefault(v, set()).add("%s: %s" % (o.name, md.name))
    for mat, obs in sorted(users_in.items(), key=lambda x: x[0].name):
        if mat in users_out:
            rep.warn(W_MAT_SHARED, material=mat.name, out_users=sorted(users_out[mat]))
            continue
        if mat.library is not None or mat.override_library is not None:
            rep.warn(W_MAT_LINKED, material=mat.name)
            continue
        nt = mat.node_tree
        if nt is None:
            continue
        mp = 'materials["%s"].node_tree' % mat.name
        # the meshes of this material whose object scale was baked into their data (round 11, the round-6 verifier's
        # finding 1: an eye at 0.03 with an Object-coordinate noise read coordinates 0.03 times as large, mirrored on the
        # right eye, with no note). One material serves meshes baked by different factors (the two eyes, one mirrored),
        # so the bake cannot be made up for in the material: it is named.
        # A scale within 1e-4 of 1 on every axis (MIK_131 has 15 meshes at about 0.99999 from float error) changes the
        # pattern by less than 0.01 %: not named (measured on MIK_131: its headset, belt, zip and piercings were named
        # for 0.99999 before this tolerance).
        vecs = rep.d.get("baked_scale_vector", {})
        baked_users = sorted(n_ for n_ in obs if n_ in vecs and any(abs(x - 1.0) > 1.0e-4 for x in vecs[n_]))
        object_coords = False
        for n in nt.nodes:
            t = n.type
            if t == "GROUP" and n.node_tree is not None:
                inner = [x.type for x in n.node_tree.nodes]
                if any(x in ("MAPPING", "BUMP", "TEX_COORD", "BEVEL", "AMBIENT_OCCLUSION", "DISPLACEMENT") for x in inner):
                    rep.warn(W_NODE_GROUP, material=mat.name, group=n.node_tree.name)
            if t == "MAPPING":
                src = _linked_from(n.inputs["Vector"])
                if src and src[0].type == "TEX_COORD" and src[1].name == "Object" and \
                        (src[0].object is None or src[0].object in sset):
                    vt = n.vector_type
                    sc = n.inputs.get("Scale")
                    lo = n.inputs.get("Location")
                    if vt == "NORMAL":
                        continue
                    if sc is not None and sc.is_linked:
                        rep.warn(W_MAPPING_LINKED, path=mp + '.nodes["%s"]' % n.name)
                        continue
                    old = list(sc.default_value)
                    if vt in ("POINT", "VECTOR"):
                        sc.default_value = [x / s for x in old]
                    elif vt == "TEXTURE":
                        sc.default_value = [x * s for x in old]
                        if lo is not None and not lo.is_linked:
                            ol = list(lo.default_value)
                            lo.default_value = [x * s for x in ol]
                            rep.change("material", mp + '.nodes["%s"].inputs["Location"]' % n.name, ol, list(lo.default_value))
                    rep.change("material", mp + '.nodes["%s"].inputs["Scale"]' % n.name, old, list(sc.default_value),
                               note="Object texture coordinates shrink with the mesh")
                    object_coords = True
            elif t in TEX_SCALE_NODES:
                src = _linked_from(n.inputs["Vector"]) if "Vector" in n.inputs else None
                if src and src[0].type == "TEX_COORD" and src[1].name == "Object":
                    sc = n.inputs.get("Scale")
                    if sc is not None and not sc.is_linked:
                        old = sc.default_value
                        sc.default_value = old / s
                        rep.change("material", mp + '.nodes["%s"].inputs["Scale"]' % n.name, old, sc.default_value)
                        object_coords = True
            elif t in ("TEX_IMAGE", "TEX_GRADIENT", "TEX_ENVIRONMENT"):
                src = _linked_from(n.inputs["Vector"]) if "Vector" in n.inputs else None
                if src and src[0].type == "TEX_COORD" and src[1].name == "Object":
                    rep.warn(W_TEX_OBJECT, path=mp + '.nodes["%s"]' % n.name)
            elif t == "BUMP":
                sk = n.inputs.get("Distance")
                if sk is not None and not sk.is_linked and sk.default_value != 0.0:
                    old = sk.default_value
                    sk.default_value = old * s
                    rep.change("material", mp + '.nodes["%s"].inputs["Distance"]' % n.name, old, sk.default_value)
            elif t == "BSDF_PRINCIPLED":
                sk = n.inputs.get("Subsurface Scale")
                if sk is not None and not sk.is_linked and sk.default_value != 0.0:
                    old = sk.default_value
                    sk.default_value = old * s
                    rep.change("material", mp + '.nodes["%s"].inputs["Subsurface Scale"]' % n.name, old, sk.default_value)
            elif t in ("SUBSURFACE_SCATTERING",):
                sk = n.inputs.get("Scale")
                if sk is not None and not sk.is_linked:
                    old = sk.default_value
                    sk.default_value = old * s
                    rep.change("material", mp + '.nodes["%s"].inputs["Scale"]' % n.name, old, sk.default_value)
            elif t in ("BEVEL", "AMBIENT_OCCLUSION", "DISPLACEMENT", "VECTOR_DISPLACEMENT", "WIREFRAME"):
                nm = {"BEVEL": "Radius", "AMBIENT_OCCLUSION": "Distance", "DISPLACEMENT": "Scale",
                      "VECTOR_DISPLACEMENT": "Scale", "WIREFRAME": "Size"}[t]
                if t == "WIREFRAME" and n.use_pixel_size:
                    continue
                sk = n.inputs.get(nm)
                if sk is not None and not sk.is_linked:
                    old = sk.default_value
                    sk.default_value = old * s
                    rep.change("material", mp + '.nodes["%s"].inputs["%s"]' % (n.name, nm), old, sk.default_value)

        if object_coords and baked_users:
            rep.warn(W_TEX_OBJECT_BAKED, material=mat.name, subject=mat.name, meshes=baked_users)


# ----------------------------------------------------------------------------------------------
# mesh helpers
# ----------------------------------------------------------------------------------------------
def _strip_blend_problem(st):
    """Why the values of NLA strip ``st`` do not reach the result at full strength by Replace, or None."""
    if st.blend_type != "REPLACE":
        return "NLA strip %s blends by %s" % (st.name, st.blend_type)
    if st.use_animated_influence:
        return "NLA strip %s has an animated influence" % st.name
    if st.blend_in != 0.0 or st.blend_out != 0.0 or st.use_auto_blend:
        return "NLA strip %s blends in or out" % st.name
    return None


def action_uses(idb):
    """``[(action, slot, problem)]``: every action slot the ID ``idb`` evaluates (the active action, every NLA strip,
    the strips inside meta strips), with why its values are not used by Replace at full influence (None when they
    are). A transition strip blends its neighbours, so every strip of its track gets a problem."""
    ad = getattr(idb, "animation_data", None)
    if not ad:
        return []
    out = []
    if ad.action is not None:
        prob = None
        if ad.action_blend_type != "REPLACE":
            prob = "the active action blends by %s" % ad.action_blend_type
        elif ad.action_influence != 1.0:
            prob = "the active action's influence is %g" % ad.action_influence
        out.append((ad.action, ad.action_slot, prob))

    def walk(strips, outer):
        for st in strips:
            prob = outer or _strip_blend_problem(st)
            if st.type == "META":
                walk(st.strips, prob)
            elif st.action is not None:
                out.append((st.action, st.action_slot, prob))

    for tr in ad.nla_tracks:
        transition = next((st.name for st in tr.strips if st.type == "TRANSITION"), None)
        walk(tr.strips, "NLA track %s has the transition strip %s" % (tr.name, transition) if transition else None)
    return out


def _scale_fcurves_exclusive(o):
    """F-curves that animate o.scale (active action slot, NLA strips, strips in meta strips). Returns (fcurves,
    problem): problem is a string when the scale cannot be baked exactly.

    Baking divides every scale key by the baked scale, which keeps the animated shape only when each scale curve
    reaches the result by Replace at full influence (round 5, finding 8: a Combine strip multiplies two divided values,
    an influence below 1 blends a divided value with the property's default 1; measured 2455.5 / 315.7 / 326.5 mm off
    at 1.1). A driven scale, scale keys in a slot shared with another ID, or any other blend keeps the scale."""
    ad = o.animation_data
    if not ad:
        return [], None
    for fc in ad.drivers:
        if fc.data_path == "scale":
            return None, "scale is driven"
    fcs = []
    for act, slot, prob in action_uses(o):
        for cb in iter_channelbags(act):
            if slot is not None and cb.slot != slot:
                continue
            for fc in cb.fcurves:
                if fc.data_path != "scale":
                    continue
                try:
                    users = list(cb.slot.users()) if cb.slot is not None else []
                except Exception:
                    users = []
                if any(u != o for u in users):
                    return None, "scale keys live in an action slot shared with %s" % sorted(u.name for u in users)
                if prob:
                    return None, "scale keys in action %s: %s" % (act.name, prob)
                if fc not in fcs:
                    fcs.append(fc)
    return fcs, None


def _animated_paths(idb):
    """Data paths of ``idb`` that a driver or an action it evaluates writes."""
    ad = getattr(idb, "animation_data", None)
    if not ad:
        return []
    paths = [fc.data_path for fc in ad.drivers]
    for act, slot, _prob in action_uses(idb):
        for cb in iter_channelbags(act):
            if slot is not None and cb.slot != slot:
                continue
            paths.extend(fc.data_path for fc in cb.fcurves)
    return paths


def _animated_modifier_names(o):
    """Names of the modifiers of ``o`` with an animated or driven setting."""
    names = set()
    for p in _animated_paths(o):
        if not p.startswith("modifiers["):
            continue
        try:
            toks = parse_path(p)
        except Exception:
            continue
        if len(toks) >= 2 and toks[1][0] == "key":
            names.add(toks[1][1])
    return names


def _mesh_data_length_animated(o):
    """The first animated or driven length of the object's mesh data or shape keys (a vertex coordinate, a Skin
    radius...), or None. Such channels take plain s, so the object keeps its scale."""
    me = o.data
    for idb in (me, getattr(me, "shape_keys", None)):
        if idb is None:
            continue
        for p in _animated_paths(idb):
            if path_dim(idb, p):  # an unresolvable path is reported where the channel is processed
                return p
    return None


def _attr_sig(me):
    return {(a.name, a.data_type, a.domain) for a in me.attributes}


def _attr_all_default(at):
    import numpy as np
    n = len(at.data)
    if n == 0:
        return True
    if at.data_type == "BOOLEAN":
        arr = np.empty(n, dtype=bool)
        at.data.foreach_get("value", arr)
        return not arr.any()
    dt = {"FLOAT": np.float32, "INT": np.int32, "INT8": np.int8}.get(at.data_type)
    if dt is not None:
        arr = np.empty(n, dtype=dt)
        at.data.foreach_get("value", arr)
        return not arr.any()
    return False


def _is_animated_or_driven(idb, path_prefix):
    ad = getattr(idb, "animation_data", None)
    if not ad:
        return False
    for fc in ad.drivers:
        if fc.data_path == path_prefix:
            return True
    act = ad.action
    if act is not None:
        for cb in iter_channelbags(act):
            for fc in cb.fcurves:
                if fc.data_path == path_prefix:
                    return True
    return False


def _raw_custom_normals(me):
    import numpy as np
    at = me.attributes.get("custom_normal")
    if at is None or at.data_type != "INT16_2D" or at.domain != "CORNER":
        return None
    a = np.empty(len(at.data) * 2, dtype=np.int32)
    at.data.foreach_get("value", a)
    return a


def _restore_raw_custom_normals(me, raw):
    at = me.attributes.get("custom_normal")
    at.data.foreach_set("value", raw)
    me.update()


def _cn_stats(c, target):
    import numpy as np
    if not len(c):
        return {"n": 0, "gt1e-3": 0, "gt1e-2": 0, "gt1e-1": 0, "max": 0.0}
    d = np.abs(c - target).max(1)
    return {"n": int(len(d)), "gt1e-3": int((d > 1e-3).sum()), "gt1e-2": int((d > 1e-2).sum()),
            "gt1e-1": int((d > 1e-1).sum()), "max": float(d.max())}


def _corner_normals(me, fresh=True):
    """Decoded corner normals. fresh=True decodes from a throw-away copy so no runtime cache of the
    original (possibly shared with evaluated copies) can leak into the measurement."""
    import numpy as np
    src = me
    tmp = None
    if fresh:
        tmp = me.copy()
        tmp.update()
        src = tmp
    a = np.empty(len(src.loops) * 3, dtype=np.float32)
    if len(a):
        src.corner_normals.foreach_get("vector", a)
    if tmp is not None:
        bpy.data.meshes.remove(tmp)
    return a.reshape(-1, 3).astype(np.float64)


def _bbox(me):
    n = len(me.vertices)
    if n == 0:
        return None
    import numpy as np
    a = np.empty(n * 3, dtype=np.float32)
    me.vertices.foreach_get("co", a)
    a = a.reshape(-1, 3)
    return [_r(list(a.min(0)), 7), _r(list(a.max(0)), 7)]


def _corner_verts(me):
    import numpy as np
    a = np.empty(len(me.loops), dtype=np.int32)
    if len(a):
        me.loops.foreach_get("vertex_index", a)
    return a.astype(np.int64)


def _corner_permutation(me, cv_before):
    """``(perm, ok)`` after Mesh.flip_normals: new corner i is old corner perm[i] (same face, same vertex).

    Matched by (face, vertex) instead of assuming how the flip orders a face's corners; ``ok`` is False when the
    match does not reproduce the vertex of every corner (it cannot fail for faces with distinct vertices)."""
    import numpy as np
    nl = len(me.loops)
    cv_after = _corner_verts(me)
    if nl == 0:
        return np.zeros(0, dtype=np.int64), True
    nf = len(me.polygons)
    starts = np.empty(nf, dtype=np.int32)
    totals = np.empty(nf, dtype=np.int32)
    me.polygons.foreach_get("loop_start", starts)
    me.polygons.foreach_get("loop_total", totals)
    order = np.argsort(starts, kind="stable")
    face_of = np.repeat(order.astype(np.int64), totals[order])
    if len(face_of) != nl or len(cv_before) != nl:
        return None, False
    nv = max(1, len(me.vertices))
    key_b = face_of * nv + cv_before
    key_a = face_of * nv + cv_after
    ob = np.argsort(key_b, kind="stable")
    oa = np.argsort(key_a, kind="stable")
    perm = np.empty(nl, dtype=np.int64)
    perm[oa] = ob
    ok = bool(np.array_equal(key_b[ob], key_a[oa]) and np.array_equal(cv_before[perm], cv_after))
    return perm, ok


def _uniform_abs(v):
    """True when the magnitudes of the three components agree to LEN_UNIFORM_REL (their signs may differ)."""
    a = [abs(float(x)) for x in v]
    m = sum(a) / 3.0
    return m > 0.0 and max(abs(x - m) for x in a) <= LEN_UNIFORM_REL * m


def _near_one(v):
    return all(abs(float(x) - 1.0) <= LEN_UNIFORM_REL for x in v)


def _has_scalar_length(st):
    """True when the struct holds a non-zero, writable scalar length (what scale_struct would scale by one factor)."""
    try:
        props = list(st.bl_rna.properties)
    except Exception:
        return False
    for p in props:
        ident = p.identifier
        if p.type != "FLOAT" or p.is_readonly or p.is_array or ident in GENERIC_SKIP:
            continue
        if not prop_dim(st, ident):
            continue
        try:
            if float(getattr(st, ident)) != 0.0:
                return True
        except Exception:
            continue
    return False


def _owner_scalar_length(m):
    """``_has_scalar_length`` without the lengths measured in another object's space or in the world
    (``_reference_space_lengths``): only those follow the owner's bake."""
    try:
        props = list(m.bl_rna.properties)
    except Exception:
        return False
    refs = _reference_space_lengths(m)
    for p in props:
        ident = p.identifier
        if p.type != "FLOAT" or p.is_readonly or p.is_array or ident in GENERIC_SKIP or ident in refs:
            continue
        if not prop_dim(m, ident):
            continue
        try:
            if float(getattr(m, ident)) != 0.0:
                return True
        except Exception:
            continue
    return False


def _cast_auto_size(m):
    """True when the Cast modifier sizes its shape from the vertices (the size it uses is 0)."""
    used = m.radius if m.use_radius_as_size else m.size
    return float(used) <= 0.0


def _hook_falloff_active(m):
    return m.falloff_type != "NONE" and m.falloff_radius != 0.0


def _bake_blocker(o, sc):
    """``(modifier name, reason)`` when baking the per-axis scale ``sc`` into the mesh would leave a modifier of
    ``o`` with no exact equivalent, else None. The object then keeps its scale and its data takes plain s.

    Exact after a bake (so never a blocker): Hook ``matrix_inverse`` (P' = S P D^-1) and ``center`` (D), a Hook
    without falloff, Displace along a local axis (signed per-axis factor) or, on a scale uniform in magnitude, a
    global axis (s * k^2), three-component lengths (per-axis factor), and every scalar length when the scale is
    uniform in magnitude (s * |k|, the normals being flipped back on a mirrored bake). Blockers: a Hook falloff on a
    non-uniform scale or with Uniform Falloff (its distances are measured in the hook's own space), a normal-direction
    or world-axis Displace on a non-uniform scale (a world-axis displacement is strength x W W^T axis, which a
    non-uniform bake turns as well as stretches), a local RGB-to-XYZ Displace unless all three axes share one factor,
    a non-zero scalar length of any other local modifier on a non-uniform scale, and a Wave / Screw axis position on
    a mirrored scale. (A Data Transfer without Object Transform is settled together with its source:
    ``raw_data_transfer_pairs``.)

    Round 5: on a non-uniform scale only the modifiers of NONUNIFORM_BAKE_TYPES may be present (finding 7), without an
    animated or driven setting; an Array reading another object (object offset, start / end cap: its offset is
    inverse(owner) x other, which a bake changes; finding 1), a Cast with a control object, Use Transform and an
    automatic size (measured from the owner's vertices but used in the control object's space), and a Skin on a
    mirrored scale keep the scale for any baked factor."""
    if any(float(v) == 0.0 for v in sc):
        return "", "zero scale on an axis"  # a bake would flatten the mesh data for good
    uni = _uniform_abs(sc)
    near_one = _near_one(sc)
    mirrored = any(float(v) < 0.0 for v in sc)
    same_sign = all(float(v) > 0.0 for v in sc) or all(float(v) < 0.0 for v in sc)
    animated = _animated_modifier_names(o) if not uni else set()
    for m in o.modifiers:
        t = m.type
        if t in WORLD_SPACE_MOD_TYPES:
            continue
        if not uni and t not in NONUNIFORM_BAKE_TYPES:
            return m.name, "%s on a non-uniform scale" % _modifier_type_label(m)
        if not uni and m.name in animated:
            return m.name, "animated or driven setting on a non-uniform scale"
        if t == "ARRAY" and not near_one and ((m.use_object_offset and m.offset_object is not None)
                                              or m.start_cap is not None or m.end_cap is not None):
            return m.name, "Array offset by another object or capped"
        if t == "SKIN" and mirrored:
            return m.name, "Skin on a mirrored scale"
        if t == "CAST" and not near_one and m.object is not None and m.use_transform and _cast_auto_size(m):
            return m.name, "Cast with a control object and an automatic size"
        if t == "HOOK":
            if _hook_falloff_active(m):
                if m.use_falloff_uniform and not _near_one(sc):
                    return m.name, "Hook with Uniform Falloff"
                if not uni:
                    return m.name, "Hook falloff on a non-uniform scale"
            continue
        if t == "DISPLACE":
            if m.direction in ("NORMAL", "CUSTOM_NORMAL") and not uni:
                return m.name, "Displace along normals on a non-uniform scale"
            if m.space == "GLOBAL" and m.direction in ("X", "Y", "Z", "RGB_TO_XYZ") and not uni:
                return m.name, "world-axis Displace on a non-uniform scale"
            if m.direction == "RGB_TO_XYZ" and m.space == "LOCAL" and not (uni and same_sign):
                return m.name, "local RGB to XYZ Displace on axes with different factors"
            continue
        if not uni and _owner_scalar_length(m):
            return m.name, "length setting on a non-uniform scale"
        if mirrored and t in AXIS_LENGTH_MOD_TYPES and _has_scalar_length(m):
            return m.name, "axis position on a mirrored scale"
    return None


def _modifier_type_label(m):
    """The modifier type's English UI name (``Surface Deform``...); the operator translates it."""
    try:
        return str(m.bl_rna.properties["type"].enum_items[m.type].name)
    except Exception:
        return str(m.type)


def _is_bound(m):
    """True for a deform modifier whose bind data is in use (Corrective Smooth only with the bind rest source)."""
    t = m.type
    try:
        if t == "CORRECTIVE_SMOOTH":
            return m.rest_source == "BIND" and bool(m.is_bind)
        if t in ("SURFACE_DEFORM", "MESH_DEFORM"):
            return bool(m.is_bound)
        if t == "LAPLACIANDEFORM":
            return bool(m.is_bind)
    except Exception:
        return False
    return False


def _modifier_switches_animated(paths, m):
    """True when one of ``paths`` (``_animated_paths`` of the modifier's object) keys or drives the modifier's
    show_viewport or show_render."""
    for p in paths:
        try:
            toks = parse_path(p)
        except Exception:
            continue
        if len(toks) == 3 and toks[0] == ("attr", "modifiers") and toks[1] == ("key", m.name) \
                and toks[2] in (("attr", "show_viewport"), ("attr", "show_render")):
            return True
    return False


def _modifier_setting_animated(paths, m, ident):
    for p in paths:
        try:
            toks = parse_path(p)
        except Exception:
            continue
        if len(toks) == 3 and toks[0] == ("attr", "modifiers") and toks[1] == ("key", m.name) \
                and toks[2] == ("attr", ident):
            return True
    return False


def _sim_baked(m):
    """True when the simulation modifier ``m`` holds a baked cache (made at the old size)."""
    caches = []
    t = m.type
    try:
        if t in ("CLOTH", "SOFT_BODY"):
            caches.append(m.point_cache)
        elif t == "DYNAMIC_PAINT" and m.canvas_settings is not None:
            caches.extend(sf.point_cache for sf in m.canvas_settings.canvas_surfaces)
        elif t == "FLUID" and m.fluid_type == "DOMAIN" and m.domain_settings is not None:
            if m.domain_settings.has_cache_baked_any:
                return True
    except Exception:
        return False
    for pc in caches:
        if pc is not None and (pc.is_baked or getattr(pc, "use_external", False)):
            return True
    return False


def _stretch_active(paths, m):
    """True when the Simple Deform modifier ``m`` stretches (or may: its method or factor is keyed / driven). Stretch
    maps z to z (1 + f) and x, y by z^2 f - f + 1, which is not homogeneous in z, so no factor reproduces it at another
    size (round 6, finding 5: 77.7 mm off at 1.1). Bend, Twist and Taper divide by the deformed extent and are exact."""
    if _modifier_setting_animated(paths, m, "deform_method"):
        return True
    if m.deform_method != "STRETCH":
        return False
    return float(m.factor) != 0.0 or _modifier_setting_animated(paths, m, "factor")


def _unproven_mode(m):
    """True for a configuration of a proven modifier type that its rule does not cover: a UV Warp offset by two
    different objects takes the UV offset from their distance, which the resize multiplies by s (round 6, measured by
    the ``types`` test: UVs moved 0.0053 at 1.1); without objects it works in UV units and is exact."""
    if m.type == "UV_WARP":
        a, b = m.object_from, m.object_to
        return (a is not None or b is not None) and (a is not b or m.bone_from != m.bone_to)
    return False


def modifier_rule_problems(o, paths=None):
    """``([(msgid, values)], [(warning msgid, values)])`` for the modifiers of ``o`` without an exact resize rule (round
    6, findings 4 and 5): a simulation that is baked or on, a stretching Simple Deform or a modifier type outside
    PROVEN_MOD_TYPES that can take effect stop the resize; switched off they are warnings. A modifier "can take effect"
    when it is on in the viewport or for render, or its switches are keyed or driven (a simulation only when it is on:
    a simulation switched by the rig, off now, starts a new simulation at the new size when it is switched on)."""
    refusals, notes = [], []
    if paths is None:
        paths = _animated_paths(o)
    for m in getattr(o, "modifiers", ()):
        t = m.type
        on = bool(m.show_viewport or m.show_render)
        if t in SIM_MOD_TYPES:
            if t == "FLUID" and m.fluid_type == "NONE":
                continue
            values = {"object": o.name, "modifier": m.name, "type": _modifier_type_label(m)}
            if _sim_baked(m):
                refusals.append((MSG_SIM_BAKED, values))
            elif on:
                refusals.append((MSG_SIM_ON, values))
            else:
                notes.append((W_SIM_OFF, {"subject": _mod_label(o, m), "object": o.name, "modifier": m.name,
                                          "type": t, "switch_animated": _modifier_switches_animated(paths, m)}))
            continue
        if t in ("NODES", "PARTICLE_SYSTEM"):
            continue  # Geometry Nodes have their own rule; particle systems are refused as such
        acts = on or _modifier_switches_animated(paths, m)
        if t == "SIMPLE_DEFORM" and _stretch_active(paths, m):
            if acts:
                refusals.append((MSG_STRETCH, {"object": o.name, "modifier": m.name}))
            else:
                notes.append((W_UNPROVEN_OFF, {"subject": _mod_label(o, m), "object": o.name, "modifier": m.name,
                                               "type": "SIMPLE_DEFORM STRETCH"}))
            continue
        if t not in PROVEN_MOD_TYPES or _unproven_mode(m):
            if acts:
                refusals.append((MSG_MOD_UNPROVEN, {"object": o.name, "modifier": m.name,
                                                    "type": _modifier_type_label(m)}))
            else:
                notes.append((W_UNPROVEN_OFF, {"subject": _mod_label(o, m), "object": o.name, "modifier": m.name,
                                               "type": t}))
    return refusals, notes


def _geometry_attribute_problem(c):
    """True when the Geometry Attribute constraint ``c`` takes a location from an attribute the resize may not scale:
    only the built-in ``position`` is mesh data the resize scales; any other vector or matrix attribute may hold a
    length or not, which cannot be told (round 6, finding 3: a custom vector attribute left an empty 36.4 mm off at
    1.1). A quaternion takes nothing the resize changes. Mix Location off does not exempt a vector (it still moved the
    owner 36.4 mm)."""
    if c.target is None or c.data_type == "QUATERNION":
        return False
    # a vector attribute moves the owner even with Mix Location off (measured on 5.1.2: 36.4 mm at 1.1), so the mix
    # switches exempt nothing
    return not (c.data_type == "VECTOR" and c.attribute_name == "position")


def _rigid_body_objects(scene, objs):
    """Objects of ``objs`` simulated by the scene's rigid body world when that world is on or baked."""
    world = getattr(scene, "rigidbody_world", None)
    if world is None:
        return []
    try:
        active = bool(world.enabled) or bool(world.point_cache.is_baked)
    except Exception:
        active = bool(getattr(world, "enabled", False))
    if not active:
        return []
    members = set()
    for coll in (getattr(world, "collection", None), getattr(world, "constraints", None)):
        if coll is not None:
            members.update(coll.all_objects)
    return [o for o in objs if o in members and (o.rigid_body is not None or o.rigid_body_constraint is not None)]


def bound_modifiers(objs):
    """``[(object, modifier)]`` of every bound deform modifier on ``objs``, in BIND_ORDER then object order."""
    out = []
    for t in BIND_ORDER:
        for o in objs:
            for m in getattr(o, "modifiers", ()):
                if m.type == t and _is_bound(m):
                    out.append((o, m))
    return out


def _mod_label(o, m):
    return "%s: %s" % (o.name, m.name)


def _nodes_length_inputs(m):
    """Names of the Geometry Nodes inputs of ``m`` declared as lengths that hold a non-zero value (not read from an
    attribute)."""
    out = []
    ng = getattr(m, "node_group", None)
    if ng is None:
        return out
    try:
        items = list(ng.interface.items_tree)
    except Exception:
        return out
    for item in items:
        if getattr(item, "item_type", "") != "SOCKET" or getattr(item, "in_out", "") != "INPUT":
            continue
        idname = str(getattr(item, "bl_socket_idname", "") or "")
        if not idname.startswith(GN_LENGTH_SOCKETS):
            continue
        ident = str(getattr(item, "identifier", "") or "")
        try:
            if m.get(ident + "_use_attribute"):
                continue
            v = m.get(ident)
        except Exception:
            continue
        if v is None:
            continue
        try:
            vals = [float(x) for x in v]
        except TypeError:
            try:
                vals = [float(v)]
            except Exception:
                continue
        except Exception:
            continue
        if any(x != 0.0 for x in vals):
            out.append(str(item.name))
    return out


def _scale_hook(m, s, d3, rep, mp, seen_key):
    """Hook on an object whose data took the per-axis factors ``d3`` (s, or s * baked scale).

    The hook moves a vertex co (object space) to (W_o^-1 W_t P) co. After the resize W_o' = S W_o S^-1 K^-1, W_t' =
    S W_t S^-1 and co' = D co (D = s K), so P' = S P D^-1 keeps every hooked vertex at s times where it was; with no
    baked scale this is the plain conjugation S P S^-1. ``center`` is an object-space point (D); ``falloff_radius``
    an object-space distance (s * |k|, uniform by the bake rule)."""
    rep.seen.add((seen_key, "center"))
    rep.seen.add((seen_key, "falloff_radius"))
    mi = m.matrix_inverse.copy()
    dinv = Matrix.Diagonal((1.0 / d3[0], 1.0 / d3[1], 1.0 / d3[2], 1.0))
    m.matrix_inverse = Matrix.Scale(s, 4) @ mi @ dinv
    rep.change("modifier_hook_matrix", mp + ".matrix_inverse", [list(r) for r in mi],
               [list(r) for r in m.matrix_inverse], data_factors=_r(list(d3)))
    c = Vector(m.center)
    if c.length != 0.0:
        m.center = (c.x * d3[0], c.y * d3[1], c.z * d3[2])
        rep.change("modifier_hook_center", mp + ".center", list(c), list(m.center))
    r = float(m.falloff_radius)
    if r != 0.0:
        f = (abs(d3[0]) + abs(d3[1]) + abs(d3[2])) / 3.0
        m.falloff_radius = r * f
        rep.change("modifier_hook_falloff", mp + ".falloff_radius", r, float(m.falloff_radius), factor=f)


def _mean_abs(d3):
    return (abs(d3[0]) + abs(d3[1]) + abs(d3[2])) / 3.0


def _displace_factor(m, s, d3):
    """The factor of a Displace strength on an object whose data took the per-axis factors ``d3`` (see
    ``_scale_displace``)."""
    if m.space == "GLOBAL" and m.direction in ("X", "Y", "Z", "RGB_TO_XYZ"):
        k = _mean_abs(d3) / s
        # d3 comes from a float32 Matrix: an unbaked object reads s to 6e-8 relative, so it takes s exactly
        return s if abs(k - 1.0) <= 1.0e-6 else s * k * k
    if m.direction in ("X", "Y", "Z"):
        return d3["XYZ".index(m.direction)]
    if m.direction == "RGB_TO_XYZ":
        return (d3[0] + d3[1] + d3[2]) / 3.0  # all three equal (bake rule): signed
    return _mean_abs(d3)


def _scale_cast_control(m, s, rep, mp, seen_key):
    """Cast with a control object and Use Transform: the cast is made in the control object's space (the vertices are
    taken there by inverse(control) x owner), so its size and radius are lengths of that space, which takes s (a
    control object is a reader: a mesh one keeps its scale). The owner's bake plays no part (measured before round 5:
    22.7 mm off with the owner's 1.4 bake)."""
    for ident in ("size", "radius"):
        rep.seen.add((seen_key, ident))
        old = float(getattr(m, ident))
        if old != 0.0:
            setattr(m, ident, old * s)
            rep.change("modifier", mp + "." + ident, old, float(getattr(m, ident)), factor=s,
                       space=m.object.name)


def _scale_laplacian(m, d3, rep, mp, seen_key):
    """Laplacian Smooth without Normalized: its weights divide by the ring area around each vertex, so the effect
    of ``lambda_factor`` falls with the square of the size; it takes the square of the data's length factor
    (measured on 5.1.2: 7.9 mm off when left, 0.0004 mm with s^2). The border lambda works on edge-length ratios and
    is left. With Normalized every weight is a ratio and nothing changes. This is the closest single factor, not an
    exact rule: a 6 x 6 grid with lambda 2.0 and 2 iterations ends 135 mm off at 1.1 (round 6; the round-2 verifier
    measured 199.5 mm on its grid), so every Laplacian Smooth is a defect (W_LAPLACIAN) and the measured check names
    the drift."""
    rep.seen.add((seen_key, "lambda_factor"))
    f = _mean_abs(d3) ** 2
    old = float(m.lambda_factor)
    if old != 0.0:
        m.lambda_factor = old * f
        rep.change("modifier", mp + ".lambda_factor", old, float(m.lambda_factor), factor=f)


def modifier_value_factor(o, m, ident, index, s, d3, kmap):
    """The factor the resize applies to setting ``ident`` (element ``index``) of modifier ``m`` on object ``o`` whose
    data took the per-axis factors ``d3``; ``kmap`` maps each baked object's name to its baked length factor. 1.0 for
    a setting that is not a length, NaN when no single factor exists (a hook matrix). The static writes in
    ``_rescale_objects`` follow the same rules (``_scale_hook``, ``_scale_displace``, ``_scale_cast_control``,
    ``_scale_laplacian``, ``_scale_reference_space_lengths``, ``scale_struct``); animated and driven settings take the
    factor from here (round 5, finding 9)."""
    t = m.type
    if t in WORLD_SPACE_MOD_TYPES:
        return s ** prop_dim(m, ident)
    if t == "HOOK":
        if ident == "center":
            return float(d3[index]) if index is not None and 0 <= index < 3 else float("nan")
        if ident == "falloff_radius":
            return _mean_abs(d3)
        if ident == "matrix_inverse":
            return float("nan")
    if t == "DISPLACE" and ident == "strength":
        return _displace_factor(m, s, d3)
    if t == "CAST" and ident in ("size", "radius") and m.object is not None and m.use_transform:
        return s
    if t == "LAPLACIANSMOOTH" and ident == "lambda_factor":
        return 1.0 if m.use_normalized else _mean_abs(d3) ** 2
    refs = _reference_space_lengths(m)
    if ident in refs:
        ref = refs[ident]
        return s * float(kmap.get(ref.name, 1.0)) if ref is not None else s
    dim = prop_dim(m, ident)
    if not dim:
        return 1.0
    if o.name in kmap:
        p = m.bl_rna.properties.get(ident)
        if dim == 1 and p is not None and p.is_array and p.array_length == 3:
            return float(d3[index]) if index is not None and 0 <= index < 3 else float("nan")
        return (s * float(kmap[o.name])) ** dim
    return s ** dim


def constraint_value_factor(c, ident, s, kmap):
    """The factor of a constraint setting the resize changes by its own rule (a target-space Shrinkwrap distance:
    s x the target's baked factor), or None (s ** dimension)."""
    if c.type == "SHRINKWRAP" and ident == "distance" and c.shrinkwrap_type in SHRINKWRAP_TARGET_SPACE:
        t = c.target
        return s * float(kmap.get(t.name, 1.0)) if t is not None else s
    return None


class ValueFactors:
    """``vf(idb, path, index=None)``: the factor of the value at ``path`` of the in-scope object ``idb`` when the resize
    changes it by its own rule (modifier settings, target-space constraint distances), else None (s ** dimension of
    the path applies). NaN means no single factor exists."""

    def __init__(self, s, scope, kmap, data_diag):
        self.s = s
        self.scope = scope
        self.kmap = kmap
        self.data_diag = data_diag

    def __call__(self, idb, path, index=None):
        if not isinstance(idb, bpy.types.Object) or not self.scope.has(idb):
            return None
        try:
            toks = parse_path(path)
        except Exception:
            return None
        if toks and toks[-1][0] == "idx":
            if index is None:
                index = toks[-1][1]
            toks = toks[:-1]
        o = idb.original if getattr(idb, "original", None) is not None else idb
        if len(toks) == 3 and toks[0] == ("attr", "modifiers") and toks[1][0] == "key" and toks[2][0] == "attr":
            m = o.modifiers.get(toks[1][1])
            if m is None:
                return None
            d3 = self.data_diag.get(o, (self.s, self.s, self.s))
            return modifier_value_factor(o, m, toks[2][1], index, self.s, d3, self.kmap)
        c, ident = None, None
        if len(toks) == 3 and toks[0] == ("attr", "constraints") and toks[1][0] == "key" and toks[2][0] == "attr":
            c, ident = o.constraints.get(toks[1][1]), toks[2][1]
        elif len(toks) == 6 and toks[0] == ("attr", "pose") and toks[1] == ("attr", "bones") and toks[2][0] == "key" \
                and toks[3] == ("attr", "constraints") and toks[4][0] == "key" and toks[5][0] == "attr":
            pb = o.pose.bones.get(toks[2][1]) if o.pose is not None else None
            c, ident = (pb.constraints.get(toks[4][1]) if pb is not None else None), toks[5][1]
        if c is not None:
            return constraint_value_factor(c, ident, self.s, self.kmap)
        return None


def _nodes_position_neutral(ng, seen=None):
    """True when the node tree ``ng`` (and every group inside it) is built only from GN_POSITION_NEUTRAL_NODES: it
    cannot move a vertex, so the resize is exact for it."""
    if ng is None:
        return True
    seen = set() if seen is None else seen
    if ng.name in seen:
        return True
    seen.add(ng.name)
    for n in ng.nodes:
        if n.bl_idname in GN_POSITION_NEUTRAL_NODES:
            continue
        if n.bl_idname == "GeometryNodeGroup" and _nodes_position_neutral(getattr(n, "node_tree", None), seen):
            continue
        return False
    return True


def _scale_skin_radii(me, f, rep):
    """Multiply every Skin vertex radius of mesh ``me`` by ``f``."""
    import numpy as np
    for lay in me.skin_vertices:
        n = len(lay.data)
        if not n:
            continue
        r = np.empty(n * 2, dtype=np.float32)
        lay.data.foreach_get("radius", r)
        if not r.any():
            continue
        new = (r.astype(np.float64) * f).astype(np.float32)
        lay.data.foreach_set("radius", new)
        rep.change("mesh_skin_radius", 'meshes["%s"].skin_vertices["%s"].radius' % (me.name, lay.name),
                   [float(r.min()), float(r.max())], [float(new.min()), float(new.max())], factor=f, n_verts=n)


def _scale_displace(o, m, s, d3, rep, mp, seen_key):
    """Displace strength: RNA unit NONE, but the displacement is (texture - mid level) x strength in object space
    along a local axis (signed per-axis data factor), along normals or local RGB axes (s * |k|, the bake rule keeps
    those uniform; a mirrored bake flips the normals back), or along a world axis.

    World axis: Blender moves the vertex by strength x W W^T axis in world space (W the object's world 3x3), so the
    world displacement of an object at a uniform scale k is k^2 x strength (measured on 5.1.2, also under a rotated,
    non-uniformly scaled parent and with a mirrored k). The resize keeps W's rotation and parent part; a bake of k
    (uniform in magnitude by the bake rule) removes k^2, so the strength takes s * k^2 with k = mean |d3| / s, which
    is plain s on an object whose scale is not baked."""
    rep.seen.add((seen_key, "strength"))
    f = _displace_factor(m, s, d3)
    old = float(m.strength)
    if old != 0.0:
        m.strength = old * f
        rep.change("modifier_displace_strength", mp + ".strength", old, float(m.strength), factor=f,
                   direction=m.direction, space=m.space)
    if m.texture is not None and m.texture_coords != "UV":
        rep.warn(W_DISPLACE_TEX, subject=_mod_label(o, m), object=o.name, modifier=m.name,
                 texture_coords=m.texture_coords)


def _reference_space_lengths(m):
    """``{property: object}`` for the lengths of modifier ``m`` that are not measured in its owner's space: in the
    space of that object, or in the world (None). Shrinkwrap offset (target space, except Project), Vertex Weight
    Proximity distances (Object: world; Geometry: target space), Data Transfer with Object Transform (source space)."""
    t = m.type
    if t == "SHRINKWRAP" and m.wrap_method in SHRINKWRAP_TARGET_SPACE:
        return {"offset": m.target}
    if t == "VERTEX_WEIGHT_PROXIMITY":
        ref = m.target if m.proximity_mode == "GEOMETRY" else None
        return {"min_dist": ref, "max_dist": ref}
    if t == "DATA_TRANSFER" and m.use_object_transform:
        return {"max_distance": m.object, "ray_radius": m.object}
    return {}


def _scale_reference_space_lengths(m, s, kmap, rep, mp, seen_key, cat):
    """Lengths of ``m`` measured in another object's space take s * k of THAT object's bake (k = 1 when it keeps its
    scale; ``scale_readers`` lets only a positive uniform bake through), world lengths take s; the owner's own bake
    plays no part. Measured before this rule (the owner's factor): Shrinkwrap 16.5 mm, Vertex Weight Proximity 6.88 /
    16.45 mm off at 1.1."""
    for ident, ref in _reference_space_lengths(m).items():
        rep.seen.add((seen_key, ident))
        old = float(getattr(m, ident))
        if old == 0.0:
            continue
        k = float(kmap.get(ref.name, 1.0)) if ref is not None else 1.0
        setattr(m, ident, old * s * k)
        rep.change(cat, mp + "." + ident, old, float(getattr(m, ident)), factor=s * k,
                   space=ref.name if ref is not None else "world")


def _scale_constraint(c, s, rep, path, scope, kmap=None):
    if c.type == "SHRINKWRAP" and c.shrinkwrap_type in SHRINKWRAP_TARGET_SPACE:
        # the distance is applied in the target's space (as the modifier's offset): s * k of the target's bake
        t = c.target
        k = float((kmap or {}).get(t.name, 1.0)) if t is not None else 1.0
        rep.seen.add((c.as_pointer(), "distance"))
        old = float(c.distance)
        if old != 0.0:
            c.distance = old * s * k
            rep.change("constraint", path + ".distance", old, float(c.distance), factor=s * k,
                       space=t.name if t is not None else "world")
    scale_struct(c, s, rep, path, "constraint", maxdepth=0)
    if hasattr(c, "inverse_matrix"):
        im = c.inverse_matrix.copy()
        if im.translation.length != 0.0:
            c.inverse_matrix = conj_matrix(im, s)
            rep.change("constraint_inverse_matrix", path + ".inverse_matrix.translation", list(im.translation),
                       list(c.inverse_matrix.translation))
    # every object the constraint reads that the resize leaves as it is (round 4, G3: tracking constraints to an
    # out-of-scope camera measured 9.20 / 2.32 / 0.245 mm, Track To an empty outside the scene 6.60 mm); only Copy
    # Rotation / Copy Scale take nothing the resize changes
    outs = sorted({t.name for _ident, t in _constraint_object_refs(c) if not scope.has(t)})
    if outs and c.type not in CON_OUT_EXACT_TYPES:
        rep.warn(W_CON_TARGET_OUT, constraint=path, target=", ".join(outs))


# ----------------------------------------------------------------------------------------------
# rig and scope
# ----------------------------------------------------------------------------------------------
def _rig_of(obj):
    """The ARP rig an object belongs to: itself, an ancestor, or an Armature modifier's target."""
    if obj is None:
        return None
    rig = shoe_lift.arp_rig(obj)
    if rig is not None:
        return rig
    parent = obj.parent
    while parent is not None:
        rig = shoe_lift.arp_rig(parent)
        if rig is not None:
            return rig
        parent = parent.parent
    for mod in getattr(obj, "modifiers", ()):
        if mod.type == "ARMATURE":
            rig = shoe_lift.arp_rig(mod.object)
            if rig is not None:
                return rig
    return None


def find_rig(context, name=""):
    """``(rig, problem)``: the ARP rig to resize, or None and a ``(msgid, values)`` reason.

    Order: the object named ``name``; the active object, its ancestors, its Armature modifier's
    target; the same for every selected object (two different rigs refuse); the panel's rig. No
    guessing beyond that: a scene-wide resize must never pick a rig by name.
    """
    name = str(name or "").strip()
    if name:
        rig = shoe_lift.arp_rig(bpy.data.objects.get(name))
        if rig is None:
            return None, (MSG_RIG_NAMED, {"name": name})
        return rig, None
    from_active = _rig_of(getattr(context, "active_object", None))
    found = []
    for obj in getattr(context, "selected_objects", None) or ():
        rig = _rig_of(obj)
        if rig is not None and rig not in found:
            found.append(rig)
    if from_active is not None:
        others = [r for r in found if r != from_active]
        if others:
            names = sorted({from_active.name} | {r.name for r in others})
            return None, (MSG_MANY_RIGS, {"rigs": ", ".join(names)})
        return from_active, None
    if len(found) > 1:
        return None, (MSG_MANY_RIGS, {"rigs": ", ".join(sorted(r.name for r in found))})
    if found:
        return found[0], None
    settings = getattr(getattr(context, "scene", None), "srs_settings", None)
    panel_rig = getattr(settings, "target_armature", None) if settings is not None else None
    rig = shoe_lift.arp_rig(panel_rig)
    if rig is None:
        chosen = [getattr(context, "active_object", None), *(getattr(context, "selected_objects", None) or ())]
        other = _armature_of(chosen + [panel_rig])
        if other is not None:
            return None, (MSG_NOT_ARP, {"name": other.name})
        return None, (MSG_NO_RIG, {})
    return rig, None


def _armature_of(objects):
    """The first armature among ``objects``, their ancestors and their Armature modifiers' targets."""
    for obj in objects:
        while obj is not None:
            if obj.type == "ARMATURE":
                return obj
            for mod in getattr(obj, "modifiers", ()):
                if mod.type == "ARMATURE" and mod.object is not None:
                    return mod.object
            obj = obj.parent
    return None


def _root(obj):
    while obj.parent is not None:
        obj = obj.parent
    return obj


def _staging_set(objs):
    """Lights, cameras and their rigs (rescale_lib's rule): staging types, their descendants, empties their
    constraints or depth of field aim at, and empties whose every descendant is staging -- but never an empty that
    something else holds or follows (``anchored``)."""
    objs = list(objs)
    staging = {o for o in objs if o.type in STAGING_TYPES}
    # who follows whom by a constraint (an object's or a pose bone's), across these objects
    followers = {}
    for o in objs:
        for _label, c in _all_constraints(o):
            for _ident, t in _constraint_object_refs(c):
                if t is not None and t is not o:
                    followers.setdefault(t, set()).add(o)

    def anchored(e):
        """True when the empty belongs to the character: walking from it along parents, children and constraints (its
        own targets and what follows it), through other empties that are not staging, reaches an object that is
        neither an empty nor a light, camera, probe or speaker -- a mesh, an armature, a curve... (Round 9, the
        round-4 verifier's finding 4: a socket held by Child Of on the spine with a sword following it, a head-cam
        mount on a bone. Round 12, the MIK_131 parity: the scene's camera rig -- a free root empty holding the camera,
        the sun and their two target empties -- had its empties anchor one another before any became staging, so the
        whole-scene resize moved the rig the production rescale left alone; walking to real content decides it in any
        order.)"""
        seen = {e}
        stack = [e]
        while stack:
            x = stack.pop()
            neigh = list(x.children)
            if x.parent is not None:
                neigh.append(x.parent)
            for _label, c in _all_constraints(x):
                for _ident, t in _constraint_object_refs(c):
                    if t is not None:
                        neigh.append(t)
            neigh.extend(followers.get(x, ()))
            for n in neigh:
                if n in seen:
                    continue
                seen.add(n)
                if n in staging or n.type in STAGING_TYPES:
                    continue
                if n.type != "EMPTY":
                    return True
                stack.append(n)
        return False

    def add_desc():
        changed = True
        while changed:
            changed = False
            for o in objs:
                if o not in staging and o.parent in staging:
                    staging.add(o)
                    changed = True

    add_desc()
    for o in list(staging):
        refs = []
        for c in o.constraints:
            t = getattr(c, "target", None)
            if t is not None:
                refs.append(t)
        if o.type == "CAMERA":
            try:
                if o.data.dof.focus_object:
                    refs.append(o.data.dof.focus_object)
            except Exception:
                pass
        for t in refs:
            if t.type != "EMPTY":
                continue
            # an empty attached to something that is not staging (a socket on a character's bone), or holding meshes
            # or rigs, stays with what holds it: made staging, its children were cut out of the character and
            # followed the resized bone at the old size (round 8, the round-3 verifier's finding 2: a hat under a
            # camera's focus empty 140.0 mm, a sword under a light's Track To target 151.8 mm, no note)
            if anchored(t):
                continue
            staging.add(t)
    for o in objs:
        if o.type == "EMPTY" and o not in staging:
            kids = list(o.children_recursive)
            if kids and all(k in staging for k in kids) and not anchored(o):
                staging.add(o)
    add_desc()
    return staging


def _object_pointer_items(struct):
    """``[(property, object)]`` held by the Object-typed pointer properties of an RNA struct (a modifier or
    constraint)."""
    out = []
    try:
        props = struct.bl_rna.properties
    except Exception:
        return out
    for p in props:
        if p.type != "POINTER":
            continue
        try:
            fixed = p.fixed_type
        except Exception:
            continue
        if fixed is None or fixed.identifier != "Object":
            continue
        try:
            value = getattr(struct, p.identifier)
        except Exception:
            continue
        if isinstance(value, bpy.types.Object):
            out.append((p.identifier, value))
    return out


def _object_pointers(struct):
    """Objects held by the Object-typed pointer properties of an RNA struct (a modifier or constraint)."""
    return [value for _ident, value in _object_pointer_items(struct)]


def _constraint_object_refs(c):
    """``[(property, object)]`` a constraint reads: target, pole target, the Armature constraint's targets, camera /
    depth objects of the tracking constraints, and the custom space object when a custom space is in use."""
    out = []
    custom = "CUSTOM" in (getattr(c, "owner_space", ""), getattr(c, "target_space", ""))
    for ident, value in _object_pointer_items(c):
        if ident == "space_object" and not custom:
            continue
        out.append((ident, value))
    if c.type == "ARMATURE":
        for tg in c.targets:
            if tg.target is not None:
                out.append(("targets", tg.target))
    return out


def _all_constraints(o):
    """``[(label, constraint)]``: the object's constraints and, for an armature, its pose bones' constraints."""
    out = [("%s: %s" % (o.name, c.name), c) for c in o.constraints]
    if o.type == "ARMATURE" and o.pose is not None:
        for pb in o.pose.bones:
            out.extend(("%s: %s: %s" % (o.name, pb.name, c.name), c) for c in pb.constraints)
    return out


def _modifier_read_kind(m, ident):
    """How the modifier ``m`` reads the object in its pointer ``ident``: READ_KEEP, READ_UNIFORM or None (only its
    world location, or not at all)."""
    t = m.type
    if t == "ARMATURE":
        return None
    if t == "SHRINKWRAP" and ident in ("target", "auxiliary_target"):
        return READ_UNIFORM  # nearest point / ray cast in the target's space; target-space offset compensated
    if t == "VERTEX_WEIGHT_PROXIMITY" and ident == "target":
        # Object distance: between world positions; Geometry distance: measured in the target's space (compensated)
        return None if m.proximity_mode == "OBJECT" else READ_UNIFORM
    if t == "DATA_TRANSFER" and ident == "object":
        # with Object Transform the mapping is made in the source's space (lengths compensated); without it the raw
        # local coordinates of both meshes are compared: owner and source must take one uniform factor
        return READ_UNIFORM if m.use_object_transform else READ_PAIR
    return READ_KEEP


def _driver_reads_scale(t, path):
    """True when a Single Property driver variable reading ``path`` of ``t`` (an object, a mesh or a shape-key
    datablock) can see a different value once the object's scale is baked into its mesh."""
    p = str(path or "").strip()
    if not p:
        return False
    try:
        toks = parse_path(p)
    except Exception:
        return True
    if not toks:
        return False
    if toks[0][0] == "key":
        return False  # a custom property of the datablock: a bake never writes it
    if isinstance(t, bpy.types.Object):
        return not (toks[0][0] == "attr" and toks[0][1] in SCALE_FREE_OBJECT_PATHS)
    d = path_dim(t, p)  # mesh or shape-key data: coordinates and other lengths take the baked factor
    return d is None or d != 0


def scale_readers(accept=None, projector_slots=True):
    """``{mesh object: [(who, kind)]}``: what reads each mesh object's scale (round 4, G1/G2).

    Readers anywhere in the file count, in the character or not: modifier object pointers (Hook, Shrinkwrap, Data
    Transfer, Vertex Weight Proximity, Boolean, Array, Mirror, Warp, Cast, Displace / Wave texture objects, UV Project
    projectors, Geometry Nodes object / collection inputs...), constraint targets (except the location-only ones),
    custom-shape widgets drawn without the bone length, particle settings (instance object / collection, a particle
    system's parent) and driver variables that read a scale, a matrix or mesh coordinates. ``kind`` is READ_KEEP or
    READ_UNIFORM (see the constants).

    ``accept(object)`` chooses whose readers are collected (default: meshes); ``projector_slots`` False leaves out the
    UV Project projector slots themselves (round 5: the readers of a projector other than its UV Project modifiers)."""
    out = {}
    if accept is None:
        def accept(t):
            return t.type == "MESH"

    def add(t, who, kind):
        if kind is not None and isinstance(t, bpy.types.Object) and accept(t):
            out.setdefault(t, []).append((who, kind))

    for o in bpy.data.objects:
        for m in getattr(o, "modifiers", ()):
            who = "%s: %s" % (o.name, m.name)
            for ident, t in _object_pointer_items(m):
                if t is not o:
                    add(t, who, _modifier_read_kind(m, ident))
            if m.type == "UV_PROJECT" and projector_slots:
                for p in m.projectors:
                    add(p.object, who, READ_KEEP)
            if m.type == "BOOLEAN" and getattr(m, "operand_type", "") == "COLLECTION" and m.collection is not None:
                for t in m.collection.all_objects:
                    add(t, who, READ_KEEP)
            if m.type == "NODES":
                try:
                    values = [m[k] for k in m.keys()]
                except Exception:
                    values = []
                for v in values:
                    if isinstance(v, bpy.types.Object):
                        add(v, who, READ_KEEP)
                    elif isinstance(v, bpy.types.Collection):
                        for t in v.all_objects:
                            add(t, who, READ_KEEP)
        for who, c in _all_constraints(o):
            for ident, t in _constraint_object_refs(c):
                if t is o:
                    continue
                if ident == "target" and c.type in LOCATION_ONLY_CONSTRAINTS:
                    continue
                add(t, who, READ_UNIFORM if (c.type == "SHRINKWRAP" and ident == "target") else READ_KEEP)
        if o.type == "ARMATURE" and o.pose is not None:
            for pb in o.pose.bones:
                # a bone that draws a mesh without the bone length reads its scale; a part that is also a bone-sized
                # shape keeps its scale too, so its data takes plain s and the bone's custom_shape_scale_xyz / s keeps
                # the drawing exactly s times (a baked scale would change the shape the bone draws, round 8)
                if pb.custom_shape is not None and (not pb.use_custom_shape_bone_size
                                                    or widget_is_part(pb.custom_shape)):
                    add(pb.custom_shape, "%s: %s" % (o.name, pb.name), READ_KEEP)
        for ps in getattr(o, "particle_systems", ()):
            add(ps.parent, "%s: %s" % (o.name, ps.name), READ_KEEP)
    for pset in bpy.data.particles:
        add(pset.instance_object, pset.name, READ_KEEP)
        if pset.instance_collection is not None:
            for t in pset.instance_collection.all_objects:
                add(t, pset.name, READ_KEEP)
    users = {}
    for o in bpy.data.objects:
        if o.type == "MESH" and o.data is not None:
            users.setdefault(o.data, []).append(o)
            sk = getattr(o.data, "shape_keys", None)
            if sk is not None:
                users.setdefault(sk, []).append(o)
    for idb in all_anim_ids():
        ad = getattr(idb, "animation_data", None)
        if not ad:
            continue
        for fc in ad.drivers:
            who = "%s: %s[%d]" % (idb.name, fc.data_path, fc.array_index)
            for var in fc.driver.variables:
                if var.type == "TRANSFORMS":
                    tg = var.targets[0]
                    if not str(tg.transform_type).startswith("LOC"):
                        add(tg.id, who, READ_KEEP)
                elif var.type == "SINGLE_PROP":
                    tg = var.targets[0]
                    t = tg.id
                    if t is None or not _driver_reads_scale(t, tg.data_path):
                        continue
                    for u in ([t] if isinstance(t, bpy.types.Object) else users.get(t, ())):
                        add(u, who, READ_KEEP)
    return out


def reader_keeps_scale(reads, sc):
    """True when the readers ``reads`` (from ``scale_readers``) need the mesh to keep its scale ``sc``."""
    reads = [r for r in (reads or ()) if r[1] != READ_PAIR]
    if not reads:
        return False
    if any(kind == READ_KEEP for _who, kind in reads):
        return True
    return not (all(float(v) > 0.0 for v in sc) and _uniform_abs(sc))


def projector_problems(objs):
    """``[(projector, who)]`` for every UV Project projector of the character (an empty: the resize multiplies its scale
    by s) whose transform something else reads (a constraint, a modifier, a driver reading its scale or matrix, a
    widget, a particle setting), that carries a constraint which can set its scale, or whose scale is animated or
    driven: each of those would see or overwrite the multiplied scale (round 5, finding 10: a Copy Scale from it 6.6 mm,
    a Child Of 155.5 mm, a SCALE_X driver 11.0 mm off at 1.1, silently)."""
    sset = set(objs)
    projs = []
    for o in objs:
        for m in getattr(o, "modifiers", ()):
            if m.type != "UV_PROJECT":
                continue
            for p in m.projectors:
                t = p.object
                if t is not None and t in sset and t.type == "EMPTY" and t not in projs:
                    projs.append(t)
    if not projs:
        return []
    pset = set(projs)
    readers = scale_readers(accept=lambda t: t in pset, projector_slots=False)
    out = []
    for p in projs:
        who = sorted({w for w, _kind in readers.get(p, ())})
        who += ["%s: %s" % (p.name, c.name) for c in p.constraints if c.type not in PROJECTOR_SAFE_CONSTRAINTS]
        if any(path == "scale" for path in _animated_paths(p)):
            who.append("%s: scale" % p.name)
        if who:
            out.append((p, ", ".join(who[:5]) + (", ..." if len(who) > 5 else "")))
    return out


ROTATION_PATHS = {"rotation_euler", "rotation_quaternion", "rotation_axis_angle", "delta_rotation_euler",
                  "delta_rotation_quaternion", "rotation_mode"}


def _var_resized_reads(var, scope):
    """Names of the in-scope IDs the driver variable ``var`` reads a value of that the resize changes (a location, a
    length, a scale, a matrix), as opposed to a rotation or a dimensionless value."""
    t = var.type
    if t in ("ROTATION_DIFF", "CONTEXT_PROP"):
        return set()
    if t == "TRANSFORMS":
        tg = var.targets[0]
        if str(tg.transform_type).startswith("ROT") or tg.id is None or not scope.has(tg.id):
            return set()
        return {tg.id.name}
    if t == "LOC_DIFF":
        return {tg.id.name for tg in var.targets if tg.id is not None and scope.has(tg.id)}
    if t == "SINGLE_PROP":
        tg = var.targets[0]
        if tg.id is None or not scope.has(tg.id):
            return set()
        try:
            toks = parse_path(tg.data_path)
        except Exception:
            return {tg.id.name}
        attrs = [v for k, v in toks if k == "attr"]
        if attrs and attrs[-1] in ROTATION_PATHS:
            return set()
        if any(a.startswith("matrix") or a in ("scale", "dimensions") for a in attrs):
            return {tg.id.name}
        d = path_dim(tg.id, tg.data_path)
        return {tg.id.name} if (d is None or d != 0) else set()
    return set()


def _id_pointer_values(struct, type_names):
    """The IDs held by the pointer properties of an RNA struct whose fixed type is one of ``type_names``."""
    out = []
    try:
        props = struct.bl_rna.properties
    except Exception:
        return out
    for p in props:
        if p.type != "POINTER":
            continue
        try:
            fixed = p.fixed_type
        except Exception:
            continue
        if fixed is None or fixed.identifier not in type_names:
            continue
        try:
            v = getattr(struct, p.identifier)
        except Exception:
            continue
        if isinstance(v, bpy.types.ID):
            out.append(v)
    return out


def _node_tree_ids(nt, seen=None):
    """``(objects, collections, materials)`` a node tree names in its unlinked Object / Collection / Material sockets,
    through its group nodes (round 8, the round-3 verifier's findings 5 and 6: an Object Info node hard-wired to the
    body, a Set Material node applying the character's material)."""
    objs, colls, mats = set(), set(), set()
    if nt is None:
        return objs, colls, mats
    seen = set() if seen is None else seen
    if nt.as_pointer() in seen:
        return objs, colls, mats
    seen.add(nt.as_pointer())
    for n in nt.nodes:
        inner = getattr(n, "node_tree", None)
        if inner is not None:
            a, b, c = _node_tree_ids(inner, seen)
            objs |= a
            colls |= b
            mats |= c
        # the node's own Object / Collection / Material (the Object, Collection and Material input nodes; round 9, the
        # round-4 verifier's findings 5 and 8: 155.75 mm, and the character's material scaled while used outside)
        for v in _id_pointer_values(n, ("Object", "Collection", "Material")):
            if isinstance(v, bpy.types.Object):
                objs.add(v)
            elif isinstance(v, bpy.types.Collection):
                colls.add(v)
            elif isinstance(v, bpy.types.Material):
                mats.add(v)
        for sock in getattr(n, "inputs", ()):
            try:
                if sock.is_linked:
                    continue
                t = sock.type
                if t not in ("OBJECT", "COLLECTION", "MATERIAL"):
                    continue
                v = sock.default_value
            except Exception:
                continue
            if isinstance(v, bpy.types.Object):
                objs.add(v)
            elif isinstance(v, bpy.types.Collection):
                colls.add(v)
            elif isinstance(v, bpy.types.Material):
                mats.add(v)
    return objs, colls, mats


SIM_MODIFIER_TYPES = {"CLOTH", "SOFT_BODY", "PARTICLE_SYSTEM", "DYNAMIC_PAINT", "FLUID"}


def _sim_reads(o, colliders, fields, fluids):
    """Names of the character's colliders / force fields an outside object's simulation reads (round 8, the round-3
    verifier's finding 7: a cloth outside the character falling on the body's Collision modifier, 455.70 mm)."""
    names = set()

    def from_collection(coll, pool):
        if coll is None:
            return {t.name for t in pool}  # no collection set: every collider / field of the scene
        members = set(coll.all_objects)
        return {t.name for t in pool if t in members}

    for m in getattr(o, "modifiers", ()):
        if m.type not in SIM_MODIFIER_TYPES:
            continue
        if not (getattr(m, "show_viewport", True) or getattr(m, "show_render", True)):
            continue
        try:
            if m.type == "CLOTH":
                if m.collision_settings.use_collision:
                    names |= from_collection(m.collision_settings.collection, colliders)
                names |= from_collection(m.settings.effector_weights.collection, fields)
            elif m.type == "SOFT_BODY":
                names |= from_collection(m.settings.collision_collection, colliders)
                names |= from_collection(m.settings.effector_weights.collection, fields)
            elif m.type == "PARTICLE_SYSTEM":
                pset = m.particle_system.settings
                if pset is not None and pset.physics_type != "NO":
                    names |= from_collection(pset.collision_collection, colliders)
                    names |= from_collection(pset.effector_weights.collection, fields)
            elif m.type == "DYNAMIC_PAINT":
                cs = m.canvas_settings
                for surf in (cs.canvas_surfaces if cs is not None else ()):
                    names |= from_collection(surf.brush_collection, colliders | fields)
            elif m.type == "FLUID" and m.fluid_type == "DOMAIN":
                ds = m.domain_settings
                if ds is not None:
                    names |= from_collection(ds.effector_group, fluids)
                    names |= from_collection(ds.fluid_group, fluids)
                    names |= from_collection(ds.force_collection, fields)
        except Exception:
            names |= {t.name for t in colliders | fields | fluids}
    return names


def outside_readers(scope_objs, scope):
    """``[(object, [names])]``: objects outside the character that read something the resize changes (a modifier,
    constraint, custom shape, material texture coordinate or particle setting pointing at an object of the character,
    a driver variable reading one of its IDs); such an object changes as well (round 5, finding 12: another
    character's Shrinkwrap onto this body moved 44.8 mm with no note). A Copy Rotation and driver variables reading a
    rotation only take what the resize keeps. Being a child of the character is reported on its own (W_CHILD_OUT)."""
    sset = set(scope_objs)
    out = []
    colliders = {o for o in sset if any(m.type == "COLLISION" for m in getattr(o, "modifiers", ()))}
    fields = {o for o in sset if getattr(o, "field", None) is not None and o.field.type != "NONE"}
    fluids = {o for o in sset if any(m.type == "FLUID" and m.fluid_type in ("FLOW", "EFFECTOR")
                                     for m in getattr(o, "modifiers", ()))}
    for o in bpy.data.objects:
        if o in sset:
            continue
        names = set()
        # an instancer of a collection holding the character draws it at the new size (round 8, finding 3)
        if o.instance_type == "COLLECTION" and o.instance_collection is not None:
            names.update(t.name for t in o.instance_collection.all_objects if t in sset)
        if colliders or fields or fluids:
            names |= _sim_reads(o, colliders, fields, fluids)
        # Grease Pencil layers parented to the character (round 10, the round-5 verifier's finding 1: 110.00 / 159.24 mm)
        if o.type == "GREASEPENCIL":
            for ly in getattr(o.data, "layers", ()):
                if getattr(ly, "parent", None) in sset:
                    names.add(ly.parent.name)
        # hair curves deformed on a surface of the character (round 9, the round-4 verifier's finding 7: 93.58 mm)
        if o.type == "CURVES" and getattr(o.data, "surface", None) in sset:
            names.add(o.data.surface.name)
        for m in getattr(o, "modifiers", ()):
            for _ident, t in _object_pointer_items(m):
                if t in sset:
                    names.add(t.name)
            # a collection a modifier reads (Grease Pencil Line Art's source collection; round 9, finding 7)
            for c in _id_pointer_values(m, ("Collection",)):
                names.update(t.name for t in c.all_objects if t in sset)
            if m.type == "NODES" and m.node_group is not None:
                # Object / Collection sockets set inside the node tree, not only the modifier's inputs (finding 5)
                objs, colls, _mats = _node_tree_ids(m.node_group)
                names.update(t.name for t in objs if t in sset)
                for c in colls:
                    names.update(t.name for t in c.all_objects if t in sset)
            if m.type == "UV_PROJECT":
                names.update(p.object.name for p in m.projectors if p.object in sset)
            if m.type == "BOOLEAN" and getattr(m, "operand_type", "") == "COLLECTION" and m.collection is not None:
                names.update(t.name for t in m.collection.all_objects if t in sset)
            if m.type == "NODES":
                try:
                    values = [m[k] for k in m.keys()]
                except Exception:
                    values = []
                for v in values:
                    if isinstance(v, bpy.types.Object) and v in sset:
                        names.add(v.name)
                    elif isinstance(v, bpy.types.Collection):
                        names.update(t.name for t in v.all_objects if t in sset)
        for _label, c in _all_constraints(o):
            if c.type == "COPY_ROTATION":
                continue
            for _ident, t in _constraint_object_refs(c):
                if t in sset:
                    names.add(t.name)
        if o.type == "ARMATURE" and o.pose is not None:
            for pb in o.pose.bones:
                if pb.custom_shape is not None and pb.custom_shape in sset:
                    names.add(pb.custom_shape.name)
        for ps in getattr(o, "particle_systems", ()):
            pset = ps.settings
            if pset is not None and pset.instance_object in sset:
                names.add(pset.instance_object.name)
            # a particle system instancing a collection that holds the character (round 8, finding 4)
            if pset is not None and pset.render_type == "COLLECTION" and pset.instance_collection is not None:
                names.update(t.name for t in pset.instance_collection.all_objects if t in sset)
        owners = [o]
        if o.data is not None:
            owners.append(o.data)
            if getattr(o.data, "shape_keys", None) is not None:
                owners.append(o.data.shape_keys)
        for idb in owners:
            ad = getattr(idb, "animation_data", None)
            if not ad:
                continue
            for fc in ad.drivers:
                for var in fc.driver.variables:
                    names.update(_var_resized_reads(var, scope))
        for slot in getattr(o, "material_slots", ()):
            mat = slot.material
            nt = getattr(mat, "node_tree", None) if mat is not None else None
            if nt is None:
                continue
            for n in nt.nodes:
                if n.type == "TEX_COORD" and getattr(n, "object", None) in sset:
                    names.add(n.object.name)
        if names:
            out.append((o, sorted(names)))
    return out


def raw_data_transfer_pairs(meshes):
    """``[(owner, source, modifier name)]`` for every Data Transfer without Object Transform on ``meshes``. Blender then
    compares the raw local coordinates of owner and source, so the mapping (and its maximum distance) stays the same
    only when both meshes' data take one uniform factor: the resize keeps both scales when their bakes would differ
    (MIK_131's face transfers from a source at 0.9999902 while the face is at 0.99998975: one factor within 1e-5)."""
    out = []
    for o in meshes:
        for m in getattr(o, "modifiers", ()):
            if m.type == "DATA_TRANSFER" and not m.use_object_transform and isinstance(m.object, bpy.types.Object) \
                    and m.object.type == "MESH" and m.object is not o:
                out.append((o, m.object, m.name))
    return out


def _effective_data_matrices(meshes, plans, s):
    """``{object: matrix}`` its mesh data will take: the planned matrix, or plain s for every user of a mesh whose
    users plan different matrices (W_MULTI_USER)."""
    by_data = {}
    for o in meshes:
        by_data.setdefault(o.data, []).append(o)
    out = {}
    for _data, obs in by_data.items():
        mats = [plans[o][1] for o in obs]
        same = all(m == mats[0] for m in mats)
        for o, m in zip(obs, mats):
            out[o] = m if same else Matrix.Scale(s, 4)
    return out


def _same_uniform_diag(a, b):
    """True when the data matrices ``a`` and ``b`` (None: the data is not scaled) are one uniform factor (signs may
    differ per axis as long as they match: a reflection keeps every distance)."""
    da = [1.0, 1.0, 1.0] if a is None else [a[0][0], a[1][1], a[2][2]]
    db = [1.0, 1.0, 1.0] if b is None else [b[0][0], b[1][1], b[2][2]]
    if not (_uniform_abs(da) and _uniform_abs(db)):
        return False
    if any((x < 0.0) != (y < 0.0) for x, y in zip(da, db)):
        return False
    m = sum(abs(y) for y in db) / 3.0
    return max(abs(x - y) for x, y in zip(da, db)) <= LEN_UNIFORM_REL * m


def _forward_refs(o):
    """``[(object, reason)]`` this object needs: modifier, constraint, driver, custom-shape and
    material references."""
    out = []
    for m in o.modifiers:
        for t in _object_pointers(m):
            out.append((t, "modifier"))
        if m.type == "UV_PROJECT":
            for p in m.projectors:
                if p.object is not None:
                    out.append((p.object, "modifier"))
        if m.type == "BOOLEAN" and getattr(m, "operand_type", "") == "COLLECTION" and m.collection is not None:
            for t in m.collection.all_objects:
                out.append((t, "modifier"))
    constraints = list(o.constraints)
    if o.type == "ARMATURE" and o.pose is not None:
        for pb in o.pose.bones:
            constraints.extend(pb.constraints)
            if pb.custom_shape is not None:
                out.append((pb.custom_shape, "custom_shape"))
    for c in constraints:
        for t in _object_pointers(c):
            out.append((t, "constraint"))
        if c.type == "ARMATURE":
            for tg in c.targets:
                if tg.target is not None:
                    out.append((tg.target, "constraint"))
    owners = [o]
    if o.data is not None:
        owners.append(o.data)
        sk = getattr(o.data, "shape_keys", None)
        if sk is not None:
            owners.append(sk)
    for idb in owners:
        ad = getattr(idb, "animation_data", None)
        if not ad:
            continue
        for fc in ad.drivers:
            for var in fc.driver.variables:
                for tg in var.targets:
                    if isinstance(tg.id, bpy.types.Object):
                        out.append((tg.id, "driver"))
    for slot in getattr(o, "material_slots", ()):
        mat = slot.material
        nt = getattr(mat, "node_tree", None) if mat is not None else None
        if nt is None:
            continue
        for n in nt.nodes:
            if n.type == "TEX_COORD" and getattr(n, "object", None) is not None:
                out.append((n.object, "material"))
    return out


def _backward_reason(o, scope):
    """Why an object outside the scope must come along: something inside deforms it or it is attached."""
    for m in o.modifiers:
        for ident in BACKWARD_MODIFIERS.get(m.type, ()):
            if getattr(m, ident, None) in scope:
                return "deformed_by"
    constraints = list(o.constraints)
    if o.type == "ARMATURE" and o.pose is not None:
        for pb in o.pose.bones:
            constraints.extend(pb.constraints)
    for c in constraints:
        if c.type not in BACKWARD_CONSTRAINTS:
            continue
        if c.type == "ARMATURE":
            if any(tg.target in scope for tg in c.targets if tg.target is not None):
                return "attached_to"
        elif getattr(c, "target", None) in scope:
            return "attached_to"
    return None


def collect_scope(rig, *, include_all_scene=False, include_staging=False, scene=None):
    """What a resize of ``rig`` covers.

    Default: the rig's top parent and everything under it, plus every object those reference (modifiers,
    constraints, drivers, custom shapes, material texture coordinates) and every object they deform or
    hold (Armature / Mesh Deform / Surface Deform / Lattice / Hook modifiers, Child Of / Copy Transforms /
    Armature / Copy Location constraints), each with its whole top-parent hierarchy, until nothing new
    comes in. ``include_all_scene``: every object of the scene. Lights, cameras and their rigs are left
    out unless ``include_staging``; objects outside the scene are never included.
    """
    if scene is None:
        scene = bpy.context.scene
    scene_objs = list(scene.objects)
    in_scene = set(scene_objs)
    staging = set() if include_staging else _staging_set(scene_objs)
    reasons, via = {}, {}
    if include_all_scene:
        chosen = {o for o in scene_objs if o not in staging}
        for o in chosen:
            reasons[o.name] = "all_scene"
        hierarchy = set(chosen)
    else:
        chosen = set()

        def add_tree(seed, reason, source):
            added = []
            root = _root(seed)
            for o in [root] + list(root.children_recursive):
                if o in chosen or o not in in_scene or o in staging:
                    continue
                chosen.add(o)
                added.append(o)
                reasons[o.name] = reason if o == seed else "hierarchy"
                if source is not None:
                    via[o.name] = seed.name
            return added

        frontier = add_tree(rig, "hierarchy", None) if rig in in_scene else []
        hierarchy = set(chosen)
        while frontier:
            new = []
            for o in frontier:
                for ref, why in _forward_refs(o):
                    if ref not in chosen and ref in in_scene and ref not in staging:
                        new.extend(add_tree(ref, why, o))
            for o in scene_objs:
                if o in chosen or o in staging:
                    continue
                why = _backward_reason(o, chosen)
                if why:
                    new.extend(add_tree(o, why, o))
            frontier = new
    objects = [o for o in bpy.data.objects if o in chosen]
    excluded = []
    for o in bpy.data.objects:
        if o in chosen:
            continue
        if o not in in_scene:
            why = "not_in_scene"
        elif o in staging:
            why = "staging"
        else:
            why = "not_part_of_character"
        excluded.append((o.name, why))
    return {
        "objects": objects,
        "reasons": reasons,
        "via": via,
        "hierarchy": sorted(o.name for o in hierarchy),
        "excluded": excluded,
        "staging": sorted(o.name for o in staging),
        "all_scene": bool(include_all_scene),
        "include_staging": bool(include_staging),
        "scene": scene.name,
    }


# ----------------------------------------------------------------------------------------------
# factor, refusals, height
# ----------------------------------------------------------------------------------------------
def resolve_factor(mode, factor, target_height_mm, current_height_mm):
    """``(s, problems)``: the factor from ``FACTOR`` or ``HEIGHT`` mode, or None and ``(msgid, values)`` pairs."""
    problems = []
    if mode == "HEIGHT":
        current = float(current_height_mm or 0.0)
        target = float(target_height_mm or 0.0)
        if not (math.isfinite(current) and current > 0.0):
            problems.append((MSG_NO_CURRENT, {}))
        if not (math.isfinite(target) and target > 0.0):
            problems.append((MSG_NO_TARGET, {}))
        if problems:
            return None, problems
        s = target / current
    else:
        s = float(factor)
        if not (math.isfinite(s) and s > 0.0):
            return None, [(MSG_FACTOR_LOW, {})]
    if abs(s - 1.0) < FACTOR_ONE_TOL:
        return None, [(MSG_FACTOR_ONE, {})]
    return s, problems


def _is_linked(idb):
    return idb is not None and (getattr(idb, "library", None) is not None
                                or getattr(idb, "override_library", None) is not None)


def _actions_of(idb):
    ad = getattr(idb, "animation_data", None)
    if not ad:
        return []
    acts = [ad.action] if ad.action is not None else []
    for tr in ad.nla_tracks:
        for st in tr.strips:
            if st.action is not None and st.action not in acts:
                acts.append(st.action)
    return acts


def _type_label(obj):
    """The object type's English UI name (``Curve``, ``Lattice``...); the operator translates it."""
    try:
        return str(obj.bl_rna.properties["type"].enum_items[obj.type].name)
    except Exception:
        return str(obj.type)


def _names(objs, limit=5):
    names = sorted({o.name for o in objs})
    text = ", ".join(names[:limit])
    if len(names) > limit:
        text += ", ..."
    return text


def preflight(context, rig, s, scope, rebind=False):
    """Everything that stops the resize, as ``[(msgid, values)]``; empty means it may run.

    All reasons are collected (it does not stop at the first). ``s`` None skips the factor checks
    (the caller reports those from ``resolve_factor``); ``scope`` None checks only mode, rig and factor.
    Every bound deform modifier is listed (one reason each) unless ``rebind`` is on. Legacy particle
    systems, collection instances, a UV Project projector that is not an empty, and an action slot whose
    length channels are used both by a Multiply NLA strip and as ordinary animation are refused as well
    (round 4); so are a Multires modifier with levels and an empty projector that something else reads,
    constrains or animates the scale of (round 5); and a simulation that is on or baked, a rigid body world that
    is on or baked, a stretching Simple Deform, a modifier without a proven rule that can take effect
    (``modifier_rule_problems``) and a Geometry Attribute constraint taking a location from an attribute other
    than position (round 6).
    """
    problems = []

    def add(msgid, **values):
        item = (msgid, values)
        if item not in problems:
            problems.append(item)

    objs = list(scope["objects"]) if scope else []
    if getattr(context, "mode", "OBJECT") != "OBJECT" or any(getattr(o, "mode", "OBJECT") != "OBJECT" for o in objs):
        add(MSG_MODE)
    if rig is None:
        add(MSG_NO_RIG)
        return problems
    if s is not None:
        if not (math.isfinite(s) and s > 0.0):
            add(MSG_FACTOR_LOW)
        elif abs(s - 1.0) < FACTOR_ONE_TOL:
            add(MSG_FACTOR_ONE)
    if scope is None:
        return problems
    sset = set(objs)
    if rig not in sset:
        add(MSG_RIG_NOT_IN_SCENE, name=rig.name)
    allowed = RESIZABLE_TYPES | (STAGING_RESIZABLE_TYPES if scope.get("include_staging") else set())
    data_types = SCALED_DATA_TYPES | (STAGING_RESIZABLE_TYPES if scope.get("include_staging") else set())
    # linked or overridden data the resize writes, and actions they use
    for o in objs:
        ids = [o]
        if o.data is not None and o.type in data_types:
            ids.append(o.data)
            sk = getattr(o.data, "shape_keys", None)
            if sk is not None:
                ids.append(sk)
        for idb in list(ids):
            ids.extend(_actions_of(idb))
        # actions the character's Action constraints play (round 9, the round-4 verifier's finding 10: a linked one was
        # written in memory and came back from the library on reload, 13.00 mm)
        for _label, c in _all_constraints(o):
            act = getattr(c, "action", None) if c.type == "ACTION" else None
            if act is not None and act not in ids:
                ids.append(act)
        for idb in ids:
            if _is_linked(idb):
                add(MSG_LINKED, name=idb.name)
    # object data shared with objects outside the character (in or out of the scene)
    users = {}
    for o in bpy.data.objects:
        if o.data is not None:
            users.setdefault(o.data, []).append(o)
    for o in objs:
        if o.data is None or o.type not in data_types:
            continue
        outside = [u for u in users.get(o.data, ()) if u not in sset]
        if outside:
            add(MSG_SHARED_DATA, data=o.data.name, users=_names(outside))
    # action slots used inside and outside the character; a slot whose length channels are used both by a Multiply
    # NLA strip (factors) and as ordinary animation (lengths) cannot be scaled one way
    sc = Scope(objs)
    uses = blend_uses(sc.ids)
    for act in bpy.data.actions:
        for cb in iter_channelbags(act):
            if not len(cb.fcurves):
                continue
            slot = cb.slot
            try:
                slot_users = list(slot.users()) if slot is not None else []
            except Exception:
                slot_users = []
            ins = [u for u in slot_users if sc.has(u)]
            outs = [u for u in slot_users if not sc.has(u)]
            if ins and outs:
                add(MSG_SHARED_SLOT, action=act.name, slot=_slot_name(slot), users=_names(outs))
            if ins and slot is not None and len(uses.get((act.as_pointer(), slot.handle), ())) > 1 \
                    and any(_action_fcurve_dim(ins[0], fc) for fc in cb.fcurves):
                add(MSG_NLA_MULTIPLY, action=act.name, slot=_slot_name(slot))
    # object types
    for o in objs:
        if o.type not in allowed:
            add(MSG_TYPE, name=o.name, type=_type_label(o))
    # legacy particles (hair keys and particle settings are not scaled: measured 12.0 mm off at 1.1) and collection
    # instances (the instanced objects are outside the character: 4.24 mm)
    for o in objs:
        systems = [ps.name for ps in getattr(o, "particle_systems", ())]
        if systems:
            add(MSG_PARTICLES, name=o.name, system=", ".join(systems))
        if getattr(o, "instance_type", "NONE") == "COLLECTION" and o.instance_collection is not None:
            add(MSG_INSTANCE, name=o.name, collection=o.instance_collection.name)
    # UV Project projectors in the character take the scale s on their object (an empty's footprint); a mesh or any
    # other type would be resized twice, once by its data and once by that scale (measured: a mesh 3.81 mm off)
    for o in objs:
        for m in getattr(o, "modifiers", ()):
            if m.type != "UV_PROJECT":
                continue
            for p in m.projectors:
                if p.object is not None and p.object in sset and p.object.type != "EMPTY":
                    add(MSG_PROJECTOR, name=p.object.name, type=_type_label(p.object))
    # ... and an empty projector whose scale something else reads, constrains or animates (round 5, finding 10)
    for p, who in projector_problems(objs):
        add(MSG_PROJECTOR_READ, name=p.name, reader=who)
    # Multires sculpt levels (round 5, finding 3): the displacement is stored per corner in tangent space, where
    # neither Mesh.transform nor any RNA property reaches it (measured: 1.0 mm off at scale 1, 3.3 mm on a 1.3 bake)
    for o in objs:
        for m in getattr(o, "modifiers", ()):
            if m.type == "MULTIRES" and m.total_levels > 0:
                add(MSG_MULTIRES, object=o.name, modifier=m.name)
    # round 6: simulations that are on or baked, a stretching Simple Deform and any modifier type without a proven rule
    # that can take effect (findings 4 and 5), on every object of the character whether it is shown or not
    for o in objs:
        for msgid, values in modifier_rule_problems(o)[0]:
            add(msgid, **values)
    rb_scene = bpy.data.scenes.get(scope.get("scene", "")) or getattr(context, "scene", None)
    for o in _rigid_body_objects(rb_scene, objs):
        add(MSG_RIGID_BODY, name=o.name)
    # a Geometry Attribute constraint taking a location from an attribute other than position (finding 3)
    for o in objs:
        for label, c in _all_constraints(o):
            if c.type == "GEOMETRY_ATTRIBUTE" and _geometry_attribute_problem(c):
                add(MSG_GEOMETRY_ATTRIBUTE, subject=label, attribute=str(c.attribute_name), target=c.target.name)
    # another character pulled in by a reference
    if not scope.get("all_scene"):
        hierarchy = set(scope.get("hierarchy", ()))
        via = scope.get("via", {})
        for o in objs:
            if o is rig or o.type != "ARMATURE" or o.name in hierarchy:
                continue
            if shoe_lift.arp_rig(o) is not None:
                add(MSG_OTHER_RIG, name=via.get(o.name, o.name), rig=o.name)
    # armatures must already be at scale 1 (applying it would move their children)
    for o in objs:
        if o.type == "ARMATURE" and any(abs(v - 1.0) > ARMATURE_SCALE_TOL for v in o.scale):
            add(MSG_ARM_SCALE, name=o.name, scale=", ".join("%.6g" % v for v in o.scale))
    # bound deform modifiers: their bind data stays in the old size (measured: Corrective Smooth 5.42 mm, Surface
    # Deform 2.98 mm, Mesh Deform 140.09 mm off at factor 0.9), so each one stops the resize unless rebinding is on
    if not rebind:
        for o, m in bound_modifiers(objs):
            add(MSG_BOUND, object=o.name, modifier=m.name, type=_modifier_type_label(m))
    return problems


def _lift_refresh(rig):
    parent = shoe_lift.holder(rig)
    if parent is not None:
        parent.update_tag()
    for name, _mesh, _kind, action in shoe_lift.outside(rig):
        obj = bpy.data.objects.get(name)
        if obj is not None and action == "lift":
            obj.update_tag()
    bpy.context.view_layer.update()


def measure_height(rig, meshes, basis="EXTENT"):
    """``(report, problem)``: the evaluated height of ``meshes`` at rest with the shoe lift at 0.

    ``EXTENT``: highest minus lowest world Z. ``TOP``: highest world Z (above the floor at Z = 0).
    The lift and the rest position are put back afterwards, as in ``shoe_lift.measure``.
    """
    if rig is None:
        return None, (MSG_NO_RIG, {})
    meshes = [m for m in meshes if m is not None and m.type == "MESH"]
    if not meshes:
        return None, (MSG_NO_MESHES, {})
    import numpy as np
    parent = shoe_lift.holder(rig)
    had = parent is not None and shoe_lift.PROP in parent.keys()
    before = float(parent[shoe_lift.PROP]) if had else 0.0
    poses = []
    for arm in (rig, bpy.data.objects.get(rig.name + "_add")):
        if arm is not None and arm.type == "ARMATURE":
            poses.append((arm, arm.data.pose_position))
            arm.data.pose_position = "REST"
    low = high = None
    try:
        if had:
            parent[shoe_lift.PROP] = 0.0
            _lift_refresh(rig)
        else:
            bpy.context.view_layer.update()
        deps = bpy.context.evaluated_depsgraph_get()
        for mesh in meshes:
            ev = mesh.evaluated_get(deps)
            data = ev.to_mesh()
            try:
                n = len(data.vertices)
                if n:
                    co = np.empty(n * 3, dtype=np.float32)
                    data.vertices.foreach_get("co", co)
                    mw = np.array(ev.matrix_world, dtype=np.float64)
                    z = co.reshape(-1, 3).astype(np.float64) @ mw[2, :3] + mw[2, 3]
                    lo, hi = float(z.min()), float(z.max())
                    low = lo if low is None or lo < low else low
                    high = hi if high is None or hi > high else high
            finally:
                ev.to_mesh_clear()
    finally:
        for arm, mode in poses:
            arm.data.pose_position = mode
        if had:
            parent[shoe_lift.PROP] = before
            _lift_refresh(rig)
        else:
            bpy.context.view_layer.update()
    if low is None:
        return None, (MSG_NO_VERTS, {})
    height = high if basis == "TOP" else high - low
    return {"top_mm": high * 1000.0, "bottom_mm": low * 1000.0, "height_mm": height * 1000.0,
            "basis": "TOP" if basis == "TOP" else "EXTENT", "meshes": [m.name for m in meshes],
            "rig": rig.name}, None


# ----------------------------------------------------------------------------------------------
# bound deform modifiers: unbind before, bind again after (``rebind_bound``)
# ----------------------------------------------------------------------------------------------
def _set_rest(objs):
    """Put the armatures among ``objs`` at rest position; ``[(armature data, previous pose_position)]``."""
    saved, seen = [], set()
    for o in objs:
        if o.type != "ARMATURE" or o.data is None or o.data in seen:
            continue
        seen.add(o.data)
        saved.append((o.data, o.data.pose_position))
        o.data.pose_position = "REST"
    return saved


def _restore_pose_position(saved):
    for arm, mode in saved:
        arm.pose_position = mode


def _world_coords(context, objs):
    """Evaluated world vertex positions (metres, float64) of each object, by name."""
    import numpy as np
    context.view_layer.update()
    dg = context.evaluated_depsgraph_get()
    out = {}
    for o in objs:
        oe = o.evaluated_get(dg)
        me = oe.to_mesh()
        try:
            n = len(me.vertices)
            a = np.empty(n * 3, dtype=np.float32)
            if n:
                me.vertices.foreach_get("co", a)
            mw = np.array(oe.matrix_world, dtype=np.float64)
            out[o.name] = a.reshape(-1, 3).astype(np.float64) @ mw[:3, :3].T + mw[:3, 3]
        finally:
            oe.to_mesh_clear()
    return out


def _capture_bind_states(context, objs, scope_objs, mods=()):
    """``{"CURRENT": ..., "REST": ...}``: the objects at the pose they are in and with every armature of the
    character at rest position (the pose is put back). The modifiers in ``mods`` that are hidden in the viewport
    are shown while measuring, so their effect is part of the comparison (and hidden again)."""
    hidden = [m for m in mods if not m.show_viewport]
    for m in hidden:
        m.show_viewport = True
    try:
        states = {"CURRENT": _world_coords(context, objs)}
        saved = _set_rest(scope_objs)
        try:
            states["REST"] = _world_coords(context, objs)
        finally:
            _restore_pose_position(saved)
    finally:
        for m in hidden:
            m.show_viewport = False
        context.view_layer.update()
    return states


def _bind_toggle(context, o, m):
    """Press Blender's own Bind button of ``m`` (it unbinds a bound modifier and binds an unbound one, evaluating
    the object at once). Returns an error text, or None."""
    op = getattr(bpy.ops.object, BIND_OPERATORS[m.type])
    shown = m.show_viewport
    try:
        if not shown:
            # a modifier hidden in the viewport is not evaluated, so it would never bind; the depsgraph must see it
            # enabled before the operator evaluates the object
            m.show_viewport = True
            context.view_layer.update()
        with context.temp_override(object=o, active_object=o, selected_objects=[o]):
            result = op(modifier=m.name)
        if "FINISHED" not in result:
            return "operator returned %s" % sorted(result)
        return None
    except Exception as exc:
        return repr(exc)
    finally:
        if not shown:
            m.show_viewport = False
        context.view_layer.update()


def _unbind(context, bound):
    """Unbind every modifier of ``bound`` before anything is resized; the ones that stay bound, with the error."""
    failed = []
    for o, m in bound:
        if not _is_bound(m):
            continue
        err = _bind_toggle(context, o, m)
        if _is_bound(m):
            failed.append({"subject": _mod_label(o, m), "error": err or "still bound"})
    return failed


def _bind_at(context, bound, state, scope_objs):
    """Bind every modifier of ``bound`` with the character at ``state`` (``REST``: every armature at rest
    position; ``CURRENT``: as it is). The modifiers that did not end bound, with the error."""
    errors = []
    saved = _set_rest(scope_objs) if state == "REST" else []
    try:
        context.view_layer.update()
        for o, m in bound:
            if _is_bound(m):
                _bind_toggle(context, o, m)  # a bind left by an earlier attempt or a failed unbind goes first
            err = _bind_toggle(context, o, m)
            if not _is_bound(m):
                errors.append({"subject": _mod_label(o, m), "object": o.name, "modifier": m.name,
                               "error": err or "not bound afterwards"})
    finally:
        _restore_pose_position(saved)
        context.view_layer.update()
    return errors


def _max_mm(after, before, s):
    import numpy as np
    out = {}
    for name, b in before.items():
        a = after.get(name)
        if a is None or a.shape != b.shape:
            out[name] = float("inf")
        elif len(b):
            out[name] = float(np.max(np.linalg.norm(a - s * b, axis=1))) * 1000.0
        else:
            out[name] = 0.0
    return out


def _rebind(context, bound, s, before, scope_objs, rep, report):
    """Bind ``bound`` again after the resize and prove it: the evaluated world vertices of every object carrying
    one must be within REBIND_TOL_MM of s times ``before`` both at rest position and at the current pose.

    The bind is first made at rest position (where a character is normally bound); when that does not reproduce
    the original (the original bind was made in another pose) it is made again at the current pose. When neither
    reproduces it, the closer attempt is kept and every modifier concerned is reported as a defect: the data has
    been changed (unbound and bound again), and one undo takes the whole resize back."""
    objs = []
    for o, _m in bound:
        if o not in objs:
            objs.append(o)
    import numpy as np
    same = all(before["CURRENT"][n].shape == before["REST"][n].shape
               and (not len(before["REST"][n])
                    or float(np.max(np.abs(before["CURRENT"][n] - before["REST"][n]))) <= 1.0e-9)
               for n in before["REST"])
    states = ("REST",) if same else ("REST", "CURRENT")

    def attempt(state):
        errors = _bind_at(context, bound, state, scope_objs)
        after = _capture_bind_states(context, objs, scope_objs, [m for _o, m in bound])
        err = {st: _max_mm(after[st], before[st], s) for st in ("REST", "CURRENT")}
        worst = max([0.0] + [v for per in err.values() for v in per.values()])
        return {"state": state, "errors": errors, "max_mm": err, "worst_mm": worst}

    attempts = []
    chosen = None
    for state in states:
        a = attempt(state)
        attempts.append(a)
        if not a["errors"] and a["worst_mm"] <= REBIND_TOL_MM:
            chosen = a
            break
    if chosen is None:
        best = min(attempts, key=lambda x: (len(x["errors"]), x["worst_mm"]))
        if best is not attempts[-1]:
            best = attempt(best["state"])
            best["repeated"] = True
            attempts.append(best)
        chosen = best
    failed = set()
    for e in chosen["errors"]:
        failed.add(e["subject"])
        rep.warn(W_REBIND_FAILED, subject=e["subject"], object=e["object"], modifier=e["modifier"], error=e["error"])
    for o in objs:
        worst = max(chosen["max_mm"][st].get(o.name, 0.0) for st in ("REST", "CURRENT"))
        if worst > REBIND_TOL_MM:
            rep.warn(W_REBIND_MISMATCH, subject=o.name, object=o.name, max_mm=_r(worst, 6),
                     rest_mm=_r(chosen["max_mm"]["REST"].get(o.name), 6),
                     current_mm=_r(chosen["max_mm"]["CURRENT"].get(o.name), 6))
            failed.update(_mod_label(oo, m) for oo, m in bound if oo == o)
    if not failed:
        for o, m in bound:
            rep.warn(W_REBOUND, subject=_mod_label(o, m), object=o.name, modifier=m.name, state=chosen["state"])
    report["rebind"] = {
        "bound": [_mod_label(o, m) for o, m in bound],
        "state": chosen["state"],
        "worst_mm": chosen["worst_mm"],
        "max_mm": chosen["max_mm"],
        "attempts": [{"state": a["state"], "worst_mm": a["worst_mm"], "errors": a["errors"],
                      "repeated": bool(a.get("repeated"))} for a in attempts],
        "failed": sorted(failed),
        "unbind_failed": report.pop("_unbind_failed", []),
    }


# ----------------------------------------------------------------------------------------------
# measured check after the resize (round 5; round 6: every object type, every bone, hidden objects, render switches,
# key frames)
# ----------------------------------------------------------------------------------------------
MATRIX_TYPES = {"EMPTY", "ARMATURE", "LIGHT", "CAMERA"}


def result_targets(scope_objs):
    """``(meshes, matrix objects)`` the measured check compares: every in-scope mesh (world vertices) and every in-scope
    empty, armature, light and camera (world matrix; an armature also each bone's world matrix)."""
    meshes = [o for o in scope_objs if o.type == "MESH"]
    mats = [o for o in scope_objs if o.type in MATRIX_TYPES]
    return meshes, mats


def _evaluated_pointers(context):
    """``(depsgraph, {pointer of every object the viewport depsgraph evaluates as visible})``."""
    context.view_layer.update()
    dg = context.evaluated_depsgraph_get()
    vis = set()
    for ob in dg.objects:
        try:
            vis.add(ob.original.as_pointer())
        except Exception:
            continue
    return dg, vis


def _show_for_measuring(context, objs):
    """Make every object of ``objs`` part of the viewport evaluation for the measurement, and return the steps that
    undo it (``_hide_again``). An object the depsgraph does not evaluate as visible keeps a stale matrix (measured on
    MIK_131: two hidden meshes looked 0.0157 / 1.045 mm off through identity matrices), and round 2 of the verification
    put a 77.7 mm drift on a hidden mesh where nothing looked. Disabled in viewports: switched on; hidden in the view
    layer: unhidden (its selection is put back); in a hidden or excluded collection: linked to the scene's own
    collection for the time of the measurement (measured on 5.1.2: each of the three is then evaluated, and the
    collections, flags and links are as before afterwards)."""
    scene, vl = context.scene, context.view_layer
    _dg, vis = _evaluated_pointers(context)
    pending = [o for o in objs if o.as_pointer() not in vis]
    undo = []
    if not pending:
        return undo
    for o in pending:
        if o.hide_viewport:
            o.hide_viewport = False
            undo.append(("hide_viewport", o, None))
        try:
            if o.hide_get(view_layer=vl):
                sel = o.select_get(view_layer=vl)
                o.hide_set(False, view_layer=vl)
                undo.append(("hide_set", o, sel))
        except RuntimeError:
            pass  # not in this view layer (only in an excluded collection): linked below
    _dg, vis = _evaluated_pointers(context)
    master = scene.collection
    for o in pending:
        if o.as_pointer() in vis or any(x == o for x in master.objects):
            continue
        master.objects.link(o)
        undo.append(("link", o, None))
        try:
            if o.hide_get(view_layer=vl):
                o.hide_set(False, view_layer=vl)
                undo.append(("hide_set", o, False))
        except RuntimeError:
            pass
    vl.update()
    return undo


def _hide_again(context, undo):
    """Undo ``_show_for_measuring``: last step first."""
    vl = context.view_layer
    for kind, o, extra in reversed(undo):
        try:
            if kind == "link":
                context.scene.collection.objects.unlink(o)
            elif kind == "hide_set":
                o.hide_set(True, view_layer=vl)
                if extra is not None and o.select_get(view_layer=vl) != extra:
                    o.select_set(extra, view_layer=vl)
            elif kind == "hide_viewport":
                o.hide_viewport = True
        except Exception:
            pass
    if undo:
        vl.update()


def _capture_now(context, meshes, mats):
    """``{"verts": {mesh: world vertices}, "mats": {object or "rig: bone": world matrix}}`` as the depsgraph evaluates
    them now; None for an object it does not evaluate as visible or cannot evaluate."""
    import numpy as np
    dg, vis = _evaluated_pointers(context)
    verts, mts = {}, {}
    for o in meshes:
        try:
            if o.as_pointer() not in vis:
                verts[o.name] = None
                continue
            oe = o.evaluated_get(dg)
            me = oe.to_mesh()
        except Exception:
            verts[o.name] = None
            continue
        try:
            n = len(me.vertices)
            a = np.empty(n * 3, dtype=np.float32)
            if n:
                me.vertices.foreach_get("co", a)
            mw = np.array(oe.matrix_world, dtype=np.float64)
            verts[o.name] = a.reshape(-1, 3).astype(np.float64) @ mw[:3, :3].T + mw[:3, 3]
        finally:
            oe.to_mesh_clear()
    for o in mats:
        try:
            if o.as_pointer() not in vis:
                mts[o.name] = None
                continue
            oe = o.evaluated_get(dg)
            mw = oe.matrix_world.copy()
        except Exception:
            mts[o.name] = None
            continue
        mts[o.name] = np.array(mw, dtype=np.float64)
        pose = getattr(oe, "pose", None) if o.type == "ARMATURE" else None
        if pose is not None:
            for pb in pose.bones:
                mts["%s: %s" % (o.name, pb.name)] = np.array(mw @ pb.matrix, dtype=np.float64)
    return {"verts": verts, "mats": mts}


def result_frames(scene, scope):
    """Frames other than the current one to measure at (round 6, finding 5a: a keyed factor drifted 77.7 mm at frame 10
    with the current frame exact): the key frames of the character's active actions and the start / end of its NLA
    strips (its objects, their data and shape keys) and the frames halfway between them, at most RESULT_MAX_FRAMES of
    them spread evenly over the animated range."""
    keys = set()
    for idb in scope.ids:
        ad = getattr(idb, "animation_data", None)
        if not ad:
            continue
        if ad.action is not None:
            for cb in iter_channelbags(ad.action):
                if ad.action_slot is not None and cb.slot != ad.action_slot:
                    continue
                for fc in cb.fcurves:
                    keys.update(int(round(kp.co[0])) for kp in fc.keyframe_points)
        for tr in ad.nla_tracks:
            for st in tr.strips:
                keys.update((int(round(st.frame_start)), int(round(st.frame_end))))
    keys = sorted(keys)
    cands = set(keys)
    for x, y in zip(keys, keys[1:]):
        if y - x > 1:
            cands.add((x + y) // 2)
    cands.discard(int(scene.frame_current))
    cands = sorted(cands)
    n = len(cands)
    if n > RESULT_MAX_FRAMES:
        cands = sorted({cands[int(round(i * (n - 1) / (RESULT_MAX_FRAMES - 1)))] for i in range(RESULT_MAX_FRAMES)})
    return cands


def _render_switches(meshes):
    """``[(modifier, viewport switch)]`` of the modifiers whose render switch differs from the viewport one (switches
    that are keyed or driven are left to their animation)."""
    out = []
    for o in meshes:
        paths = None
        for m in o.modifiers:
            if bool(m.show_render) == bool(m.show_viewport):
                continue
            if paths is None:
                paths = _animated_paths(o)
            if not _modifier_switches_animated(paths, m):
                out.append((m, bool(m.show_viewport)))
    return out


def capture_result_states(context, meshes, mats, scope_objs, frames=()):
    """``(states, info)``. ``states``: ``{state: _capture_now(...)}`` for CURRENT (as it is), REST (every armature of
    the character at rest position, when one is posed), RENDER (the modifiers' render switches in place of the viewport
    ones, when any differs: a render-only modifier is otherwise never measured; meshes only) and F<n> for each frame of
    ``frames`` (``result_frames``). Hidden objects are shown for the measurement (``_show_for_measuring``); the pose
    position, the switches, the frame and the visibility are put back."""
    states = {}
    info = {"shown": [], "render_switches": [], "frames": list(frames)}
    undo = _show_for_measuring(context, list(meshes) + list(mats))
    info["shown"] = sorted({o.name for _kind, o, _extra in undo})
    try:
        states["CURRENT"] = _capture_now(context, meshes, mats)
        if any(o.type == "ARMATURE" and o.data is not None and o.data.pose_position == "POSE" for o in scope_objs):
            saved = _set_rest(scope_objs)
            try:
                states["REST"] = _capture_now(context, meshes, mats)
            finally:
                _restore_pose_position(saved)
                context.view_layer.update()
        switches = _render_switches(meshes)
        if switches:
            info["render_switches"] = sorted("%s: %s" % (m.id_data.name, m.name) for m, _v in switches)
            try:
                for m, _v in switches:
                    m.show_viewport = bool(m.show_render)
                states["RENDER"] = _capture_now(context, meshes, ())
            finally:
                for m, v in switches:
                    m.show_viewport = v
                context.view_layer.update()
        if frames:
            scene = context.scene
            f0, sub0 = int(scene.frame_current), float(scene.frame_subframe)
            try:
                for f in frames:
                    # frame_current + update evaluates the animation as frame_set does, without running the frame
                    # change handlers (measured on 5.1.2), so no add-on handler writes anything while measuring
                    scene.frame_current = int(f)
                    scene.frame_subframe = 0.0
                    states["F%d" % int(f)] = _capture_now(context, meshes, mats)
            finally:
                scene.frame_current = f0
                scene.frame_subframe = sub0
                context.view_layer.update()
    finally:
        _hide_again(context, undo)
    return states, info


def _skew(m3):
    """How far the axes of a 3 x 3 matrix are from perpendicular (largest |cosine| between two of its columns)."""
    import numpy as np
    cols = []
    for i in range(3):
        c = m3[:, i]
        n = float(np.linalg.norm(c))
        if n == 0.0:
            return 1.0
        cols.append(c / n)
    return max(abs(float(cols[0] @ cols[1])), abs(float(cols[1] @ cols[2])), abs(float(cols[0] @ cols[2])))


def result_drift(before, after, s, scaled_3x3=(), rolls=None):
    """``({name: (worst mm, state, tolerance mm, rotation difference)}, largest distance measured)`` for every measured
    mesh, object and bone further than its tolerance from s times ``before``: mesh vertices s x before (a changed
    vertex count is infinite); a world matrix's translation s x before and its 3 x 3 part as before (s x before for the
    objects named in ``scaled_3x3``, the UV projectors whose scale takes s), within RESULT_ROT_TOL. A name not evaluated
    (None) before or after is not compared here (``result_not_measured``).

    A matrix whose translation and Y axis (a bone's direction) match, whose roll does not, and whose axes were skewed
    before the resize (more than RESULT_SKEW_TOL from perpendicular: Blender computed that roll from a near-zero vector)
    goes to ``rolls`` (``{name: (rotation difference, state, skew)}``) instead: W_ROLL_UNDETERMINED."""
    import numpy as np
    out = {}
    worst_all = 0.0
    scaled_3x3 = set(scaled_3x3)
    if rolls is None:
        rolls = {}

    def keep(name, d, st, tol, rot):
        if name not in out or d + (rot or 0.0) > out[name][0] + (out[name][3] or 0.0):
            out[name] = (d, st, tol, rot)

    for st, per in before.items():
        aft = after.get(st, {})
        for name, b in per.get("verts", {}).items():
            a = aft.get("verts", {}).get(name)
            if a is None or b is None:
                continue
            if a.shape != b.shape:
                d, tol = float("inf"), RESULT_TOL_MM
            elif not len(b):
                d, tol = 0.0, RESULT_TOL_MM
            else:
                d = float(np.max(np.linalg.norm(a - s * b, axis=1))) * 1000.0
                tol = max(RESULT_TOL_MM, RESULT_TOL_REL * float(np.max(np.abs(a))) * 1000.0)
            worst_all = max(worst_all, d)
            if d > tol:
                keep(name, d, st, tol, None)
        for name, b in per.get("mats", {}).items():
            a = aft.get("mats", {}).get(name)
            if a is None or b is None:
                continue
            f = s if name in scaled_3x3 else 1.0
            d = float(np.linalg.norm(a[:3, 3] - s * b[:3, 3])) * 1000.0
            want = f * b[:3, :3]
            rot = float(np.max(np.abs(a[:3, :3] - want))) / max(1.0, float(np.max(np.abs(want))))
            tol = max(RESULT_TOL_MM, RESULT_TOL_REL * float(np.max(np.abs(a[:3, 3]))) * 1000.0)
            worst_all = max(worst_all, d)
            if d > tol or rot > RESULT_ROT_TOL:
                ydiff = float(np.max(np.abs(a[:3, 1] - want[:, 1]))) / max(1.0, float(np.max(np.abs(want))))
                skew = _skew(b[:3, :3])
                if d <= tol and ydiff <= RESULT_ROT_TOL and skew > RESULT_SKEW_TOL:
                    if name not in rolls or rot > rolls[name][0]:
                        rolls[name] = (rot, st, skew)
                    continue
                keep(name, d, st, tol, rot)
    return out, worst_all


def result_not_measured(before, after):
    """Names some state could not evaluate (None) before or after the resize: not proven, so each is a defect
    (W_NOT_MEASURED) instead of a silent list (round 6, finding 5)."""
    names = set()
    for states in (before, after):
        for per in states.values():
            for kind in ("verts", "mats"):
                names.update(n for n, v in per.get(kind, {}).items() if v is None)
    return sorted(names)


def _collections_render():
    """Collections of the current scene that render (they and every collection above them have Render on)."""
    out = set()
    try:
        root = bpy.context.scene.collection
    except Exception:
        return out
    stack = [(c, True) for c in root.children]
    while stack:
        c, ok = stack.pop()
        ok = ok and not c.hide_render
        if ok:
            out.add(c)
            stack.extend((k, True) for k in c.children)
    return out


def widget_is_part(o, rendering=None):
    """True when a custom-shape mesh is also a part of the character, so it is resized and measured like any part:
    - it has a modifier (an Armature or a Hook deforms it, a Skin or Solidify grows faces on it) or a constraint, or a
      parent other than a plain object (a bone, an armature, vertices, a lattice, a curve) carries or deforms it;
    - or it has faces and is shown in the viewport OR renders.
    Only a shape with none of these -- drawn as lines (edges only), or hidden in the viewport AND off for render, with no
    modifier, constraint or deforming parent (Auto-Rig Pro's cs_ shapes) -- is a display shape whose data stays.
    (Round 8, the round-3 verifier's finding 1: a skinned eye a bone also drew kept its old data, 147.79 mm, no note.
    Round 9, the round-4 verifier's findings 1-3: a prop hidden but rendered, shown but not rendered, or in a collection
    off for render, 129.58 mm; an edges-only mesh whose Skin modifier renders a tube, 169.57 mm; a costume variant
    deformed through Armature parenting, 150.48 mm; a widget deformed by a Hook, 140.27 mm -- all silent.)"""
    if o is None or o.type != "MESH":
        return False
    if len(getattr(o, "modifiers", ())) or len(getattr(o, "constraints", ())):
        return True
    if o.parent is not None and o.parent_type != "OBJECT":
        return True
    # drawn as lines (edges only, the usual bone shape) with nothing to grow faces: renders nothing, a display shape
    if o.data is None or len(o.data.polygons) == 0:
        return False
    try:
        shown = bool(o.visible_get())
    except Exception:
        shown = not o.hide_get() and not o.hide_viewport
    if shown:
        return True
    if o.hide_render:
        return False
    if rendering is None:
        rendering = _collections_render()
    try:
        master = bpy.context.scene.collection
    except Exception:
        master = None
    return any(c is master or c in rendering for c in o.users_collection)


def bone_sized_widgets(scope_objs):
    """Names of the display-only custom-shape widgets every user of which draws them with the bone length: their data is
    kept on purpose (``_rescale_objects``), so the measured check leaves them out. A widget that is also a part of the
    character (``widget_is_part``) is resized and measured."""
    users = {}
    for o in scope_objs:
        if o.type == "ARMATURE" and o.pose is not None:
            for pb in o.pose.bones:
                if pb.custom_shape is not None:
                    users.setdefault(pb.custom_shape, []).append(bool(pb.use_custom_shape_bone_size))
    rendering = _collections_render()
    return {w.name for w, sized in users.items() if all(sized) and not widget_is_part(w, rendering)}


def _uv_projectors_in(scope_objs):
    """Names of the in-scope objects used as UV Project projectors by the character (their scale takes s)."""
    sset = set(scope_objs)
    out = set()
    for o in scope_objs:
        for m in getattr(o, "modifiers", ()):
            if m.type == "UV_PROJECT":
                out.update(p.object.name for p in m.projectors if p.object is not None and p.object in sset)
    return out


# ----------------------------------------------------------------------------------------------
# the resize
# ----------------------------------------------------------------------------------------------
def _persistence_module():
    try:
        from . import persistence
        return persistence
    except Exception:
        return None


def _scale_scene_settings(context, scene, s, rep, report, scale_panel_lengths):
    """SmartRig panel lengths of the running scene.

    Every setting's update callback saves the whole panel to the shared JSON (N-panel State Save), so the
    writes here are made with that save held back (``persistence._APPLYING``, the module's own re-entrancy
    flag) and the panel is saved once at the end, only when a shared value changed. The measured heights
    are transient (never in the JSON) and are always scaled: they describe this file's model.
    """
    report["clamped"] = []
    report["panel_state_saved"] = False
    report["panel_lengths_scaled"] = []
    settings = getattr(scene, "srs_settings", None)
    if settings is None:
        rep.untouched("scenes['%s'].srs_settings" % scene.name, "SmartRig settings are not registered")
        return
    ps = _persistence_module()
    held = ps is not None and hasattr(ps, "_APPLYING")
    previous = ps._APPLYING if held else False
    transient = set(getattr(ps, "_TRANSIENT_SCENE_NAMES", ())) if ps is not None else set()
    shared_changed = False
    if held:
        ps._APPLYING = True
    try:
        for p in settings.bl_rna.properties:
            ident = p.identifier
            if p.type != "FLOAT" or p.is_readonly or p.is_array or ident in NEVER_SCALED_SETTINGS:
                continue
            always = ident in ALWAYS_SCALED_SETTINGS
            is_length = ident.endswith("_mm") or prop_dim(settings, ident) == 1
            if not always and not (scale_panel_lengths and is_length):
                continue
            old = float(getattr(settings, ident))
            if old == 0.0:
                continue
            want = old * s
            setattr(settings, ident, want)
            new = float(getattr(settings, ident))
            rep.change("scene_setting", "scenes['%s'].srs_settings.%s" % (scene.name, ident), old, new)
            if not always:
                report["panel_lengths_scaled"].append(ident)
            if ident not in transient:
                shared_changed = True
            if abs(new - want) > 1.0e-6 * max(1.0, abs(want)):
                report["clamped"].append({"setting": ident, "name": str(p.name or ident), "wanted": want,
                                          "got": new})
    finally:
        if held:
            ps._APPLYING = previous
    if shared_changed and ps is not None:
        # one write of the whole panel (nothing when State Save is off), instead of one per setting
        try:
            report["panel_state_saved"] = bool(ps.save(context))
        except Exception:
            report["panel_state_saved"] = False
    if not scale_panel_lengths:
        rep.untouched("scenes['%s'].srs_settings *_mm / chain_floor_z" % scene.name,
                      "caller turned panel lengths off")
    for ident in LENGTH_TEXT_SETTINGS:
        if hasattr(settings, ident):
            rep.untouched("scenes['%s'].srs_settings.%s" % (scene.name, ident),
                          "angle:mm text, an argument for re-running the knee profile; not scaled")
            if scale_panel_lengths and str(getattr(settings, ident) or "").strip():
                # the millimetre settings beside it were scaled; this text keeps the old millimetres
                rep.warn(W_KNEE_TEXT, setting=str(settings.bl_rna.properties[ident].name or ident))
    rep.untouched("scenes['%s'].gravity / unit_settings / render / eevee" % scene.name,
                  "physical constants and scene settings are not model lengths")


def spend_panel_factor(settings):
    """Put the panel's factor back to 1.0 after a resize that used it, so a second press is refused instead
    of resizing twice. The factor is transient (never in the shared JSON); the write does not save the panel."""
    if settings is None or not hasattr(settings, "rescale_factor"):
        return
    ps = _persistence_module()
    held = ps is not None and hasattr(ps, "_APPLYING")
    previous = ps._APPLYING if held else False
    if held:
        ps._APPLYING = True
    try:
        settings.rescale_factor = 1.0
    finally:
        if held:
            ps._APPLYING = previous


def _rescale_objects(context, scene, scope_info, s, rep, report, *, scale_materials_flag, scale_panel_lengths):
    """rescale_lib.rescale_scene steps 1-8 on the given scope (same order, same categories)."""
    scope_objs = scope_info["objects"]
    scope = Scope(scope_objs)
    sset = set(scope_objs)
    report["scope_objects"] = sorted(o.name for o in scope_objs)
    staging = set(scope_info.get("staging", ()))
    for name, why in scope_info.get("excluded", ()):
        o = bpy.data.objects.get(name)
        label = "objects['%s'] (%s)" % (name, o.type if o is not None else "?")
        rep.untouched(label, {"staging": "staging (lights/camera rig): not part of the model",
                              "not_in_scene": "not linked to this scene",
                              "not_part_of_character": "not part of this character"}.get(why, why))
    for o in scope_objs:
        if o.parent is not None and o.parent not in sset:
            rep.warn(W_PARENT_OUT, object=o.name, parent=o.parent.name)
    for o in bpy.data.objects:
        if o not in sset and o.parent in sset:
            rep.warn(W_STAGING_CHILD if o.name in staging else W_CHILD_OUT, object=o.name, parent=o.parent.name)
    # objects outside the character that read it change with it (round 5, finding 12); a light or camera rig that
    # aims at the character is information, anything else a defect
    # iTaSC (round 10): the same pose solved twice can land differently (measured: one synthetic arm 226.71 mm off in one
    # Blender session and exact in another, with the same module), so the measured check cannot vouch for it -- a defect
    for o in scope_objs:
        if o.type == "ARMATURE" and o.pose is not None and getattr(o.pose, "ik_solver", "LEGACY") == "ITASC":
            rep.warn(W_ITASC, object=o.name)
    followers = set()
    for o, names in outside_readers(scope_objs, scope):
        rep.warn(W_STAGING_READS_IN if o.name in staging else W_OUT_READS_IN, object=o.name, reads=names)
        if o.name in staging:
            followers.add(o)
    followers |= {o for o in bpy.data.objects if o.name in staging and o.parent in sset}
    # a light or a camera that follows the character carries what hangs below it: a mesh (or curve, text...) there
    # changes with no light rule to excuse it (round 10, the round-5 verifier's finding 4: a card under a light tracking
    # the head, 49.10 mm)
    named = set()
    for f in sorted(followers, key=lambda x: x.name):
        for k in f.children_recursive:
            if k in sset or k.name in named or k.type in STAGING_TYPES or k.type == "EMPTY":
                continue
            named.add(k.name)
            rep.warn(W_OUT_READS_IN, object=k.name, reads=[f.name])
    # simulations and modifiers without a proven rule that are switched off (round 6): named, never silent (on, they
    # stopped the resize in preflight)
    for o in scope_objs:
        for msgid, values in modifier_rule_problems(o)[1]:
            rep.warn(msgid, **values)
    # a rigid body world that is on or baked stopped the resize (preflight); a rigid body here is off (its world is off,
    # or it is not in the world's collection): named the same way, its lengths are scaled below
    for o in scope_objs:
        if getattr(o, "rigid_body", None) is not None or getattr(o, "rigid_body_constraint", None) is not None:
            rep.warn(W_SIM_OFF, subject="%s: Rigid Body" % o.name, object=o.name, type="RIGID_BODY")

    # --- data users sanity (refused by preflight; kept as a guard) ----------------------------------
    data_users = {}
    for o in bpy.data.objects:
        if o.data is not None and o.type in ("MESH", "ARMATURE", "CURVE", "LATTICE", "SURFACE", "FONT"):
            data_users.setdefault(o.data, []).append(o)
    blocked_data = set()
    for dat, us in data_users.items():
        ins = [u for u in us if u in sset]
        outs = [u for u in us if u not in sset]
        if ins and outs:
            blocked_data.add(dat)
            rep.warn(W_DATA_SHARED, data=dat.name, users=[u.name for u in us])

    # --- custom shape widgets ------------------------------------------------------------------------
    widget_users = {}
    for o in scope_objs:
        if o.type == "ARMATURE" and o.pose is not None:
            for pb in o.pose.bones:
                if pb.custom_shape is not None:
                    widget_users.setdefault(pb.custom_shape, []).append((o, pb))
    widget_keep = set()
    widget_parts = {}  # part meshes some bones also draw with the bone length -> those pose bones
    rendering = _collections_render()
    for w, us in widget_users.items():
        sized = [pb.use_custom_shape_bone_size for _, pb in us]
        if w in sset and widget_is_part(w, rendering):
            if any(sized):
                widget_parts[w] = [pb for _, pb in us if pb.use_custom_shape_bone_size]
        elif all(sized):
            widget_keep.add(w)  # display is bone-length relative; bones shrink by s already
        elif any(sized):
            rep.warn(W_WIDGET_MIXED, widget=w.name)
    # a part drawn as a bone's shape with the bone length: its data takes s (it keeps its scale, scale_readers) and
    # the bone takes s, so the bone's own shape scale takes 1/s and the drawing ends exactly s times (round 8)
    for w, pbs in sorted(widget_parts.items(), key=lambda x: x[0].name):
        for pb in pbs:
            old = Vector(pb.custom_shape_scale_xyz)
            pb.custom_shape_scale_xyz = old / s
            rep.change("pose_custom_shape_scale", "pose.bones['%s'].custom_shape_scale_xyz" % pb.name, list(old),
                       list(pb.custom_shape_scale_xyz), note="drawn with the bone length; part %s takes s" % w.name)
    widget_readers = scale_readers()
    for w in sorted(widget_keep, key=lambda x: x.name):
        if w not in sset:
            continue
        rep.untouched("objects['%s'] mesh data (widget)" % w.name,
                      "custom-shape widget: drawn in bone space times bone length (all users have "
                      "use_custom_shape_bone_size); bones already shrink by s, so scaling the widget data "
                      "would shrink it twice")
        # The widget object's scale is only a parking transform (ARP's edit-shape operator overwrites it
        # from the bone matrix), so it is reset to exactly 1.0; mesh data, rotation and every pose-bone
        # custom_shape_* setting stay, so the bone display is unchanged up to the global s.
        sc = Vector(w.scale)
        if all(v == 1.0 for v in sc):
            continue
        if w in widget_readers:
            # a Hook / Child Of / driver reads this widget's scale: resetting it moved the mesh hooked to it (round 9,
            # the round-4 verifier's w09: 15.88 mm); the scale stays and the data stays (display only)
            rep.warn(W_SCALE_REFERENCED, object=w.name, by=sorted({who for who, _kind in widget_readers[w]}))
            continue
        if _is_animated_or_driven(w, "scale"):
            rep.warn(W_WIDGET_ANIM, object=w.name, scale=_r(list(sc), 9))
            continue
        if w.children:
            rep.warn(W_WIDGET_CHILDREN, object=w.name)
            continue
        w.scale = (1.0, 1.0, 1.0)
        rep.change("widget_object_scale_reset", "objects['%s'].scale" % w.name, list(sc), list(w.scale),
                   note="parking transform only; bone display uses mesh data x bone length x custom_shape_*")

    # widgets drawn with the bone length keep their data: the measured check after the resize leaves them out
    report["_widget_keep"] = sorted(w.name for w in widget_keep)

    # --- UV projector objects --------------------------------------------------------------------------
    projectors = {}
    for o in scope_objs:
        for m in o.modifiers:
            if m.type == "UV_PROJECT":
                for p in m.projectors:
                    if p.object is not None:
                        projectors.setdefault(p.object, []).append((o, m))
    for p in projectors:
        if p not in sset:
            rep.warn(W_PROJECTOR_OUT, projector=p.name)

    # --- 1. mesh data ------------------------------------------------------------------------------------
    mesh_mats = {}
    applied_scale = {}
    scale_keys = {}  # object -> scale F-curves whose values are divided by the baked per-axis scale
    report.setdefault("baked_scale_factor", {})
    readers = scale_readers()
    meshes = [o for o in scope_objs if o.type == "MESH" and o.data not in blocked_data and o not in widget_keep]
    dt_pairs = raw_data_transfer_pairs(meshes)

    def plan_of(o, forced):
        """``(apply, M, anim_fcs, notes)`` for mesh object ``o``: whether its scale is baked and the matrix its data
        takes; ``notes`` are the report entries, written when the plan is carried out."""
        notes = []
        sc = Vector(o.scale)
        what = "objects['%s'].scale %s" % (o.name, _r(list(sc), 7))
        apply = any(v != 1.0 for v in sc)
        anim_fcs = []
        if apply:
            fcs, problem = _scale_fcurves_exclusive(o)
            blocker = None
            if not problem:
                # the scale keys are divided by the baked scale: an elastic segment cannot take a negative divisor
                # (elastic_sign_problem); a positive one is exact with the amplitude divided as well (round 6)
                for fc in fcs or ():
                    if sc[fc.array_index] < 0.0 and elastic_sign_problem(fc):
                        problem = "elastic scale keys on the mirrored axis %d" % fc.array_index
                        break
            if not problem:
                anim = _mesh_data_length_animated(o)
                if anim:
                    # an animated vertex coordinate / Skin radius of the data takes plain s, the data would take s*k
                    problem = "mesh data length %s is animated or driven" % anim
            if problem:
                apply = False
                notes += [("untouched", what, problem), (W_SCALE_KEPT, {"object": o.name, "detail": problem})]
            elif o.children:
                apply = False
                notes.append((W_SCALE_CHILDREN, {"object": o.name}))
            elif len(o.constraints):
                # its constraints evaluate with its scale in the object matrix (Copy Scale, Limit Scale, a
                # Shrinkwrap projection in its own space...): keeping the scale keeps them exact
                apply = False
                names = [c.name for c in o.constraints]
                notes += [("untouched", what, "object constraints %s" % names),
                          (W_SCALE_CONSTRAINED, {"object": o.name, "constraints": names})]
            elif reader_keeps_scale(readers.get(o), sc):
                # something else reads this object's transform with the scale in it (G2): keep it
                apply = False
                by = sorted({who for who, _kind in readers[o]})
                notes += [("untouched", what, "read by %s" % by), (W_SCALE_REFERENCED, {"object": o.name, "by": by})]
            else:
                blocker = _bake_blocker(o, sc)
            if apply and blocker is not None:
                # a modifier of this object has no exact equivalent after a bake of this scale: keep the scale,
                # the data takes plain s (exact)
                mod_name, reason = blocker
                apply = False
                notes.append(("untouched", what, reason))
                if mod_name:
                    notes.append((W_SCALE_MODIFIER, {"subject": "%s: %s" % (o.name, mod_name), "object": o.name,
                                                     "modifier": mod_name, "detail": reason}))
                else:
                    notes.append((W_SCALE_ZERO, {"object": o.name, "scale": _r(list(sc), 9)}))
            elif apply and o in forced:
                # a Data Transfer without Object Transform compares raw local coordinates: its owner and source must
                # take one uniform factor, so both keep their scales when the bakes would differ
                owner, src, mod_name = forced[o]
                apply = False
                reason = "Data Transfer without Object Transform: %s and %s must take one factor" % (owner.name,
                                                                                                      src.name)
                notes.append(("untouched", what, reason))
                if o is owner:
                    notes.append((W_SCALE_MODIFIER, {"subject": "%s: %s" % (o.name, mod_name), "object": o.name,
                                                     "modifier": mod_name, "detail": reason}))
                else:
                    notes.append((W_SCALE_REFERENCED, {"object": o.name, "by": ["%s: %s" % (owner.name, mod_name)]}))
            elif apply:
                # keyed scale: the current per-axis scale is baked into the mesh and every scale key / handle
                # is divided by it, so the animated world shape is unchanged (x s) and a constant key becomes
                # exactly 1.0
                anim_fcs = fcs
        if apply:
            mean = (sc.x + sc.y + sc.z) / 3.0
            spread = max(abs(v - mean) for v in sc)
            if spread <= NEAR_UNIFORM_REL * abs(mean) and not anim_fcs:
                # float32 rounding-level non-uniformity: bake one uniform factor (a uniform matrix keeps
                # custom normals better conditioned); the dropped part is reported as a bound
                M = Matrix.Scale(s * mean, 4)
                notes.append(("near_uniform", {"object": o.name, "scale": _r(list(sc), 10),
                                               "baked_uniform": _r(mean, 10),
                                               "dropped_rel": _r(spread / abs(mean), 12)}))
            else:
                M = Matrix.Diagonal((s * sc.x, s * sc.y, s * sc.z, 1.0))
        else:
            M = Matrix.Scale(s, 4)
        return apply, M, anim_fcs, notes

    # plans, then the pairs of a Data Transfer without Object Transform: a pair whose two data matrices are not one
    # uniform factor keeps both scales (each round only turns bakes into kept scales, so it ends)
    forced = {}
    while True:
        plans = {o: plan_of(o, forced) for o in meshes}
        eff = _effective_data_matrices(meshes, plans, s)
        new = {}
        for owner, src, mod_name in dt_pairs:
            if _same_uniform_diag(eff.get(owner), eff.get(src)):
                continue
            for x in (owner, src):
                if x in plans and plans[x][0] and x not in forced:
                    new[x] = (owner, src, mod_name)
        if not new:
            break
        forced.update(new)
    report["data_transfer_raw_pairs"] = [[a.name, b.name, n] for a, b, n in dt_pairs]

    for o in meshes:
        apply, M, anim_fcs, notes = plans[o]
        sc = Vector(o.scale)
        for note in notes:
            if note[0] == "untouched":
                rep.untouched(note[1], note[2])
            elif note[0] == "near_uniform":
                rep.d.setdefault("near_uniform_scale_baked", []).append(note[1])
            else:
                rep.warn(note[0], **note[1])
        prev = mesh_mats.get(o.data)
        if prev is not None and prev[0] != M:
            rep.warn(W_MULTI_USER, mesh=o.data.name)
            mesh_mats[o.data] = (Matrix.Scale(s, 4), prev[1] + [o])
            for oo in prev[1] + [o]:
                applied_scale.pop(oo, None)
                scale_keys.pop(oo, None)
            continue
        mesh_mats[o.data] = (M, (prev[1] if prev else []) + [o])
        if apply:
            applied_scale[o] = sc.copy()
            if anim_fcs:
                scale_keys[o] = anim_fcs
    for me, (M, obs) in mesh_mats.items():
        n = len(me.vertices)
        bb_b = _bbox(me)
        auto_ts = me.use_auto_texspace
        ts_loc = Vector(me.texspace_location)
        ts_size = Vector(me.texspace_size)
        cn_before = _corner_normals(me) if me.has_custom_normals else None
        raw_cn = _raw_custom_normals(me) if cn_before is not None else None
        attrs_before = _attr_sig(me)
        # a mirrored bake (negative determinant) turns every face inside out: Mesh.transform keeps the winding, so
        # the winding is flipped back afterwards (Blender's own Apply Scale does the same)
        mirrored = M.to_3x3().determinant() < 0.0
        cv_before = _corner_verts(me) if mirrored else None
        me.transform(M, shape_keys=True)
        diag = Vector((M[0][0], M[1][1], M[2][2]))
        perm = None
        if mirrored:
            me.flip_normals()
            me.update()
            perm, perm_ok = _corner_permutation(me, cv_before)
            rep.change("mesh_winding_flipped", 'meshes["%s"]' % me.name, None, None, corners_matched=perm_ok,
                       note="mirrored bake: face winding flipped back so the normals keep their world direction")
            if not perm_ok:
                perm = None
                if cn_before is not None:
                    rep.warn(W_FLIP_CORNERS, mesh=me.name)
                    cn_before = None
            if cn_before is not None:
                # "keep the stored encoding" means the custom normals as the flip left them
                raw_cn = _raw_custom_normals(me)
        if cn_before is not None:
            # Custom normals are stored relative to per-corner spaces built from float32 geometry. On
            # near-degenerate faces those spaces are ill-conditioned and a non power-of-two scale rotates the
            # decoded normal. Re-encoding helps there but is lossy on meshes whose stored normals are not
            # representable per smooth fan. So: keep the stored encoding unless it drifted, then try
            # re-encoding and keep whichever reproduces the pre-scale directions better.
            import numpy as np
            # Blender returns non-unit decoded normals on some corners, so the target keeps each corner's
            # original length; only the direction is inverse-transposed.
            it = np.array([1.0 / diag.x, 1.0 / diag.y, 1.0 / diag.z])
            target = cn_before * it
            ln = np.linalg.norm(target, axis=1)
            ln0 = np.linalg.norm(cn_before, axis=1)
            ln[ln == 0.0] = 1.0
            target = target / ln[:, None] * ln0[:, None]
            if perm is not None:
                target = target[perm]  # corners in the order the winding flip left them
            st_keep = _cn_stats(_corner_normals(me), target)
            choice = "kept_stored_encoding"
            st_set = None
            if st_keep["max"] > CN_TOL and raw_cn is not None:
                me.normals_split_custom_set([tuple(v) for v in target.tolist()])
                st_set = _cn_stats(_corner_normals(me), target)
                if (st_set["gt1e-2"], st_set["max"]) < (st_keep["gt1e-2"], st_keep["max"]):
                    choice = "re_encoded"
                else:
                    _restore_raw_custom_normals(me, raw_cn)
                    choice = "kept_stored_encoding (re-encode was worse)"
            # normals_split_custom_set() creates a `sharp_edge` attribute (all False) on meshes that had
            # none. An all-default attribute is equivalent to its absence, so it is removed again; the
            # decoded normals are compared around the removal to prove that.
            for (an, at_type, at_dom) in sorted(_attr_sig(me) - attrs_before):
                at = me.attributes.get(an)
                if at is None or at.is_required or at.is_internal:
                    continue
                if not _attr_all_default(at):
                    rep.warn(W_ATTR_KEPT, mesh=me.name, attribute=an)
                    continue
                c_pre = _corner_normals(me)
                me.attributes.remove(at)
                me.update()
                c_post = _corner_normals(me)
                dmax = float(np.abs(c_post - c_pre).max()) if len(c_pre) else 0.0
                rep.change("mesh_attribute_removed", 'meshes["%s"].attributes["%s"]' % (me.name, an),
                           [at_type, at_dom, "all default"], None, decoded_normals_max_change=dmax,
                           note="added by normals_split_custom_set during the re-encode; removed again")
            final = _cn_stats(_corner_normals(me), target)
            rep.change("mesh_custom_normals", 'meshes["%s"].custom_normals' % me.name, st_keep, final,
                       choice=choice, re_encode_trial=st_set, winding_flipped=perm is not None)
            if final["gt1e-1"]:
                # a decoded normal more than 0.1 (about 6 degrees) off its direction: never silent. st_keep is the
                # stored encoding after Mesh.transform alone, which is what Blender's own Apply Scale leaves (the same
                # data transform): no worse than that is a warning, worse is a defect. Measured on MIK_131's belt:
                # 0 corners with the factor 158/165 as a double, 4 (max 1.0) with the typed float32 factor, where
                # the stored encoding alone leaves 14 and Blender's Apply Scale 18.
                no_worse = final["gt1e-1"] <= st_keep["gt1e-1"] and final["max"] <= st_keep["max"] + 1.0e-9
                rep.warn(W_CN_DRIFT_BLENDER if no_worse else W_CN_DRIFT, mesh=me.name, corners=final["gt1e-1"],
                         max=_r(final["max"], 6), transform_only_corners=st_keep["gt1e-1"],
                         transform_only_max=_r(st_keep["max"], 6))
        if not auto_ts:
            want_loc = Vector((ts_loc.x * diag.x, ts_loc.y * diag.y, ts_loc.z * diag.z))
            want_size = Vector((ts_size.x * diag.x, ts_size.y * diag.y, ts_size.z * diag.z))
            me.texspace_location = want_loc
            me.texspace_size = want_size
            rep.change("mesh_texspace", 'meshes["%s"].texspace_location/size' % me.name,
                       [list(ts_loc), list(ts_size)], [list(me.texspace_location), list(me.texspace_size)])
        # object-space lengths stored on the mesh follow the mesh data: s, or s * |baked object scale|
        lf = (abs(diag.x) + abs(diag.y) + abs(diag.z)) / 3.0
        for ident in MESH_LOCAL_LENGTHS:
            v = getattr(me, ident)
            if v != 0.0:
                setattr(me, ident, v * lf)
                rep.change("mesh_setting", 'meshes["%s"].%s' % (me.name, ident), v, getattr(me, ident), factor=lf)
        if me.remesh_voxel_adaptivity != 0.0:
            rep.untouched('meshes["%s"].remesh_voxel_adaptivity' % me.name,
                          "OpenVDB adaptivity is a dimensionless 0..1 ratio (RNA subtype says DISTANCE)")
        # Skin modifier radii are per-vertex object-space lengths of the data (round 5, finding 2: 5.0 mm off at
        # scale 1, 21.5 mm on a 1.3 bake when left); a Skin keeps a mirrored scale and is not baked on a non-uniform
        # one, so the data's length factor is one number
        _scale_skin_radii(me, lf, rep)
        nk = len(me.shape_keys.key_blocks) if me.shape_keys else 0
        rep.change("mesh_data", 'meshes["%s"]' % me.name, bb_b, _bbox(me), n_verts=n, n_shape_keys=nk,
                   matrix_diag=_r(list(diag)), users=[o.name for o in obs])
        me.update()
        a_add = sorted(_attr_sig(me) - attrs_before)
        a_rem = sorted(attrs_before - _attr_sig(me))
        if a_add or a_rem:
            rep.warn(W_ATTR_CHANGED, mesh=me.name, added=a_add, removed=a_rem)
    for o, sc in applied_scale.items():
        old = list(o.scale)
        o.scale = (1.0, 1.0, 1.0)
        rep.change("object_scale_applied", "objects['%s'].scale" % o.name, old, list(o.scale))
        M = mesh_mats[o.data][0]
        # the length factor of the bake (magnitudes: a mirrored axis does not make a length negative)
        k = (abs(M[0][0]) + abs(M[1][1]) + abs(M[2][2])) / (3.0 * s)
        report["baked_scale_factor"][o.name] = k
        # the object scale that went into the data, per axis and signed (a mirrored axis flips what reads it)
        report.setdefault("baked_scale_vector", {})[o.name] = [float(x) for x in sc]
        for fc in scale_keys.get(o, []):
            i = fc.array_index
            scale_fcurve(fc, 1.0, 1.0 / sc[i], rep, "objects['%s'] scale F-curve [%d]" % (o.name, i),
                         "object_scale_keys_divided", allow_add_generator=False)
            # a constant key equal to the baked value must land on exactly 1.0 (float32 round trip)
            for kp in fc.keyframe_points:
                if kp.co[1] != 1.0 and abs(kp.co[1] - 1.0) < 1e-7:
                    kp.co = (kp.co[0], 1.0)
        if scale_keys.get(o):
            ad = o.animation_data
            o.scale = (1.0, 1.0, 1.0)
            rep.d.setdefault("scale_keys_baked", []).append(
                {"object": o.name, "baked_per_axis": _r(list(sc), 10),
                 "fcurves": ["scale[%d]" % fc.array_index for fc in scale_keys[o]],
                 "action": ad.action.name if ad and ad.action else None})

    # per-axis factors each mesh object's data took (s, or s * baked scale): Hook / Displace / vector lengths
    data_diag = {}
    for me, (M, obs) in mesh_mats.items():
        for oo in obs:
            data_diag[oo] = (M[0][0], M[1][1], M[2][2])

    # --- 2. armature data ---------------------------------------------------------------------------------
    arm_done = set()
    for o in scope_objs:
        if o.type != "ARMATURE" or o.data in blocked_data or o.data in arm_done:
            continue
        arm = o.data
        arm_done.add(arm)
        sc = Vector(o.scale)
        if any(v != 1.0 for v in sc):
            rep.warn(W_ARM_SCALE, object=o.name, scale=_r(list(sc), 9))
        before = {b.name: (b.head_local.copy(), b.tail_local.copy(), b.length) for b in arm.bones}
        arm.transform(Matrix.Scale(s, 4))
        for b in arm.bones:
            hb, tb, ln = before[b.name]
            rep.change("bone_rest", 'armatures["%s"].bones["%s"]' % (arm.name, b.name),
                       {"head": list(hb), "tail": list(tb), "len": ln},
                       {"head": list(b.head_local), "tail": list(b.tail_local), "len": b.length})
            for ident in BBONE_CURVES:
                v = getattr(b, ident)
                if v != 0.0:
                    setattr(b, ident, v * s)
                    rep.change("bone_bbone_curve", 'armatures["%s"].bones["%s"].%s' % (arm.name, b.name, ident), v,
                               getattr(b, ident))
            scale_custom_props(b, s, rep, 'armatures["%s"].bones["%s"]' % (arm.name, b.name))
        rep.d["counts"]["bone_envelope_radius_bbone_xz_scaled_by_Armature.transform"] += len(before)
        scale_custom_props(arm, s, rep, 'armatures["%s"]' % arm.name)
        arm.update_tag()

    # --- 3. objects: transforms, empties, pose, constraints, modifiers, physics --------------------------
    staging_data_done = set()
    for o in scope_objs:
        op = "objects['%s']" % o.name
        baked = o.name in report["baked_scale_factor"]
        kb = report["baked_scale_factor"].get(o.name, 1.0)
        d3 = data_diag.get(o, (s, s, s))
        loc = Vector(o.location)
        if loc.length != 0.0:
            o.location = loc * s
            rep.change("object_location", op + ".location", list(loc), list(o.location))
        dl = Vector(o.delta_location)
        if dl.length != 0.0:
            o.delta_location = dl * s
            rep.change("object_delta_location", op + ".delta_location", list(dl), list(o.delta_location))
        mpi = o.matrix_parent_inverse.copy()
        if o.parent in projectors and o.parent in sset and o.parent_type == "OBJECT":
            # the projector's world matrix becomes S*P (its scale takes s, below), not S*P*S^-1: its children take
            # mpi * S^-1 so that their world matrix is still S*W*S^-1 (measured before: a child 11.1 mm off at 1.1)
            o.matrix_parent_inverse = mpi @ Matrix.Scale(1.0 / s, 4)
            rep.change("projector_child_parent_inverse", op + ".matrix_parent_inverse", [list(r) for r in mpi],
                       [list(r) for r in o.matrix_parent_inverse])
        elif mpi.translation.length != 0.0:
            o.matrix_parent_inverse = conj_matrix(mpi, s)
            rep.change("object_parent_inverse", op + ".matrix_parent_inverse.translation", list(mpi.translation),
                       list(o.matrix_parent_inverse.translation))
        if getattr(o, "instance_type", "NONE") == "FACES" and o.use_instance_faces_scale:
            # face instances are scaled by the face size, which grows by s with the data, and the instanced children
            # are resized as well: the factor takes 1/s (measured before: instances 0.19 mm off at 1.1)
            v = float(o.instance_faces_scale)
            o.instance_faces_scale = v / s
            rep.change("instance_faces_scale", op + ".instance_faces_scale", v, float(o.instance_faces_scale))
        if o.type == "EMPTY":
            v = o.empty_display_size
            o.empty_display_size = v * s
            rep.change("empty_display_size", op + ".empty_display_size", v, o.empty_display_size)
        if o.type in STAGING_RESIZABLE_TYPES and o.data is not None and o.data not in staging_data_done:
            # lights and cameras (only when the caller included them): lengths of the data, never brightness
            staging_data_done.add(o.data)
            scale_struct(o.data, s, rep, "%s['%s']" % ("lights" if o.type == "LIGHT" else "cameras", o.data.name),
                         "staging_data", maxdepth=1)
        if o in projectors:
            old = list(o.scale)
            o.scale = Vector(o.scale) * s
            rep.change("uv_projector_scale", op + ".scale", old, list(o.scale),
                       note="UV Project footprint: world projector matrix becomes S*P, so UVs stay identical")
        # custom props on the object
        scale_custom_props(o, s, rep, op)
        # object constraints (an object with constraints never has its scale baked: W_SCALE_CONSTRAINED)
        kmap = report["baked_scale_factor"]
        for c in o.constraints:
            _scale_constraint(c, s, rep, op + ".constraints['%s']" % c.name, scope, kmap)
        # modifiers (local-space lengths follow the mesh data: s * |baked object scale|, three-component lengths the
        # per-axis factor; Hook and Displace first, so the generic walker leaves the values they own alone; lengths
        # measured in another object's space or in the world take that space's factor)
        for m in o.modifiers:
            mp = op + ".modifiers['%s']" % m.name
            try:
                mkey = m.as_pointer()
            except Exception:
                mkey = None
            if m.type == "HOOK":
                _scale_hook(m, s, d3, rep, mp, mkey)
            elif m.type == "DISPLACE":
                _scale_displace(o, m, s, d3, rep, mp, mkey)
            elif m.type == "CAST" and m.object is not None and m.use_transform:
                _scale_cast_control(m, s, rep, mp, mkey)
            elif m.type == "LAPLACIANSMOOTH" and not m.use_normalized:
                _scale_laplacian(m, d3, rep, mp, mkey)
            if m.type == "LAPLACIANSMOOTH" and (m.show_viewport or m.show_render):
                # the factor is exact, the solve is not: measured with no resize rule involved, a 3 x 8 x 6 grid
                # 1.2 m from its origin moved 0.0136 mm (0.0036 mm with Normalized) when only its data and lambda
                # were scaled, and 0.019 mm at 3 m; at the origin 0.0001 mm. So it is never left silent.
                rep.warn(W_LAPLACIAN, subject=_mod_label(o, m), object=o.name, modifier=m.name,
                         normalized=bool(m.use_normalized))
            _scale_reference_space_lengths(
                m, s, kmap, rep, mp, mkey,
                "modifier_on_baked_scale_object" if baked and m.type not in WORLD_SPACE_MOD_TYPES else "modifier")
            if baked and m.type not in WORLD_SPACE_MOD_TYPES:
                scale_struct(m, s * kb, rep, mp, "modifier_on_baked_scale_object", axis=d3)
            else:
                scale_struct(m, s, rep, mp, "modifier")
            for ident in ("object", "target", "offset_object", "mirror_object", "start_cap", "end_cap"):
                ref = getattr(m, ident, None)
                if isinstance(ref, bpy.types.Object) and ref not in sset:
                    rep.warn(W_MOD_REF_OUT, modifier=mp, ref=ref.name)
            if m.type == "BEVEL" and _is_animated_or_driven(o, 'modifiers["%s"].offset_type' % m.name):
                # the width is a length or a percentage by the offset type: keyed, it has no single factor (round 10,
                # the round-5 verifier's finding 3: 0.878 mm at a frame the measured check did not sample)
                rep.warn(W_ANIM_FACTOR, where=mp + ".width", subject=_mod_label(o, m))
            tex = TEXTURE_READERS.get(m.type)
            if tex is not None and getattr(m, tex[0], None) is not None and getattr(m, tex[1], "UV") != "UV":
                # the texture is read where the resize moved the points (as Displace: W_DISPLACE_TEX)
                rep.warn(W_TEXTURE_COORDS, subject=_mod_label(o, m), object=o.name, modifier=m.name,
                         coordinates=str(getattr(m, tex[1])))
            if m.type == "NODES":
                lengths = _nodes_length_inputs(m)
                if lengths:
                    rep.warn(W_NODES_LENGTH, subject=_mod_label(o, m), object=o.name, modifier=m.name,
                             inputs=lengths)
                elif not _nodes_position_neutral(m.node_group):
                    # a length constant inside the node tree cannot be seen from here (round 5, finding 11)
                    rep.warn(W_NODES, subject=_mod_label(o, m), object=o.name, modifier=m.name)
        # collision settings (unit NONE in RNA but distances). Object.collision is the same struct as a
        # Collision modifier's settings (scaled once through rep.seen); without the modifier the values are
        # dormant, but if they were configured (non-default) they are scaled so re-enabling behaves the same.
        col = o.collision
        if col is not None:
            configured = any(m.type == "COLLISION" for m in o.modifiers)
            if not configured:
                for ident in ("thickness_outer", "thickness_inner"):
                    pr = col.bl_rna.properties[ident]
                    if abs(getattr(col, ident) - pr.default) > 1e-9:
                        configured = True
            if configured:
                scale_struct(col, s, rep, op + ".collision", "collision", maxdepth=0)
        # force field settings (round 8, the round-3 verifier's finding 8: size, falloff distances and the harmonic rest
        # length stayed at the old size): their distances follow the character
        fld = getattr(o, "field", None)
        if fld is not None and fld.type != "NONE":
            scale_struct(fld, s, rep, op + ".field", "field", maxdepth=0)
        # rigid body settings (round 6): only an object whose rigid body world is off gets here; its lengths (collision
        # margin, constraint limits) follow the resize so the world can be turned on again at the new size
        for ident in ("rigid_body", "rigid_body_constraint"):
            rb = getattr(o, ident, None)
            if rb is not None:
                scale_struct(rb, s, rep, op + "." + ident, "rigid_body", maxdepth=0)
        # armature pose (an armature that was never evaluated has no pose yet)
        if o.type == "ARMATURE" and o.pose is not None:
            for pb in o.pose.bones:
                pp = op + ".pose.bones['%s']" % pb.name
                lv = Vector(pb.location)
                if lv.length != 0.0:
                    pb.location = lv * s
                    rep.change("pose_location", pp + ".location", list(lv), list(pb.location))
                ct = Vector(pb.custom_shape_translation)
                if ct.length != 0.0:
                    pb.custom_shape_translation = ct * s
                    rep.change("pose_custom_shape_translation", pp + ".custom_shape_translation", list(ct),
                               list(pb.custom_shape_translation))
                for ident in BBONE_CURVES:
                    v = getattr(pb, ident)
                    if v != 0.0:
                        setattr(pb, ident, v * s)
                        rep.change("pose_bbone_curve", pp + "." + ident, v, getattr(pb, ident))
                scale_custom_props(pb, s, rep, pp)
                for c in pb.constraints:
                    _scale_constraint(c, s, rep, pp + ".constraints['%s']" % c.name, scope, kmap)
        o.update_tag(refresh={"OBJECT", "DATA"})

    # --- 4. drivers ---------------------------------------------------------------------------------------
    # animated and driven modifier / constraint settings take the factor the setting itself took (round 5)
    vf = ValueFactors(s, scope, report["baked_scale_factor"], data_diag)
    srs_backup = None
    for o in scope_objs:
        if "srs_driver_expression_backup" in o.keys():
            srs_backup = o["srs_driver_expression_backup"]
            report["srs_driver_expression_backup_on"] = o.name
    seen_fc = set()
    for idb in all_anim_ids():
        ad = getattr(idb, "animation_data", None)
        if not ad:
            continue
        for fc in ad.drivers:
            key = (idb.as_pointer(), fc.data_path, fc.array_index)
            if key in seen_fc:
                continue
            seen_fc.add(key)
            try:
                process_driver(idb, fc, s, scope, rep, srs_backup=srs_backup, vf=vf)
            except Exception as e:
                import traceback
                rep.warn(W_DRIVER_FAILED, where="%s %s[%d]" % (idb.name, fc.data_path, fc.array_index),
                         error=repr(e), tb=traceback.format_exc()[-800:])

    # --- 5. actions ---------------------------------------------------------------------------------------
    process_actions(s, scope, rep, vf=vf)
    nla_strips = 0
    for o in scope_objs:
        ad = o.animation_data
        if ad:
            nla_strips += sum(len(t.strips) for t in ad.nla_tracks)
    report["nla_strips_in_scope"] = nla_strips

    # --- 6. SmartRig panel settings of the running scene ---------------------------------------------------
    _scale_scene_settings(context, scene, s, rep, report, scale_panel_lengths)

    # --- 7. materials -------------------------------------------------------------------------------------
    if scale_materials_flag:
        _scale_materials(scope_objs, s, rep)
    else:
        rep.untouched("materials", "caller disabled material compensation")

    # --- 8. leftovers to report ---------------------------------------------------------------------------
    report["nonunit_scale_left"] = []
    report["nonunit_scale_other_types"] = []
    for o in scope_objs:
        if any(v != 1.0 for v in o.scale) or any(v != 1.0 for v in o.delta_scale):
            e = {"object": o.name, "type": o.type, "scale": _r(list(o.scale), 9),
                 "delta_scale": _r(list(o.delta_scale), 9)}
            if o.type in ("MESH", "ARMATURE"):
                report["nonunit_scale_left"].append(e)
            else:
                report["nonunit_scale_other_types"].append(e)
        if o.type not in RESIZABLE_TYPES and o.type not in STAGING_RESIZABLE_TYPES:
            rep.warn(W_TYPE, object=o.name, type=o.type)

    for o in scope_objs:
        o.update_tag(refresh={"OBJECT", "DATA"})
    context.view_layer.update()


def rescale(context, rig, s, *, include_all_scene=False, include_staging=False, scale_materials=True,
            scale_panel_lengths=True, rebind_bound=False):
    """Resize the character of ``rig`` by ``s`` about the world origin. ``(report, problems)``.

    When ``preflight`` finds anything, nothing is changed and ``(None, problems)`` comes back. Bound deform
    modifiers stop the resize unless ``rebind_bound``: they are then unbound before anything is resized and bound
    again afterwards (``_rebind``, which proves the result and reports a difference as a defect).
    """
    global _LAST_REPORT
    t0 = time.time()
    scene = context.scene
    if rig is None:
        return None, [(MSG_NO_RIG, {})]
    scope = collect_scope(rig, include_all_scene=include_all_scene, include_staging=include_staging, scene=scene)
    problems = preflight(context, rig, s, scope, rebind=bool(rebind_bound))
    if problems:
        return None, problems
    report = {
        "rig": rig.name,
        "s": s,
        "scene": scene.name,
        "options": {"include_all_scene": bool(include_all_scene), "include_staging": bool(include_staging),
                    "scale_materials": bool(scale_materials), "scale_panel_lengths": bool(scale_panel_lengths),
                    "rebind_bound": bool(rebind_bound)},
        "scope": {"reasons": dict(scope["reasons"]), "via": dict(scope["via"]),
                  "excluded": list(scope["excluded"]), "staging": list(scope["staging"])},
    }
    rep = Rep(report)
    report["invalid_drivers_before"] = invalid_drivers()
    # the measured check: every in-scope mesh, object and bone as it is now, at rest, with the render switches and at
    # the character's key frames, before anything changes (hidden ones shown for the time of the measurement)
    t_check = time.time()
    check_meshes, check_mats = result_targets(scope["objects"])
    widgets = bone_sized_widgets(scope["objects"])
    check_meshes = [o for o in check_meshes if o.name not in widgets]
    check_frames = result_frames(scene, Scope(scope["objects"]))
    check_before, info_before = capture_result_states(context, check_meshes, check_mats, scope["objects"],
                                                      check_frames)
    t_check = time.time() - t_check
    bound = bound_modifiers(scope["objects"]) if rebind_bound else []
    before_bind = None
    if bound:
        # the shape to reproduce, taken before anything changes; then the old binds are released
        bound_objs = []
        for o, _m in bound:
            if o not in bound_objs:
                bound_objs.append(o)
        before_bind = _capture_bind_states(context, bound_objs, scope["objects"], [m for _o, m in bound])
        report["_unbind_failed"] = _unbind(context, bound)
    _rescale_objects(context, scene, scope, s, rep, report, scale_materials_flag=bool(scale_materials),
                     scale_panel_lengths=bool(scale_panel_lengths))
    if bound:
        try:
            _rebind(context, bound, s, before_bind, scope["objects"], rep, report)
        except Exception as exc:
            # the resize and the unbinding are done: never leave this silent (and never abort the one undo step)
            import traceback
            labels = [_mod_label(o, m) for o, m in bound]
            for label in labels:
                rep.warn(W_REBIND_FAILED, subject=label, error=repr(exc))
            report["rebind"] = {"bound": labels, "state": None, "worst_mm": float("inf"), "max_mm": {},
                                "attempts": [], "failed": labels, "error": traceback.format_exc()[-1500:],
                                "unbind_failed": report.pop("_unbind_failed", [])}
    # the measured check: s times the shape before, within RESULT_TOL_MM, at the current pose and at rest. Widgets drawn
    # with the bone length keep their data on purpose, and rebound objects were compared by the rebind already.
    t1 = time.time()
    skip = set(report.pop("_widget_keep", ())) | {o.name for o, _m in bound}
    measured = [o for o in check_meshes if o.name not in skip]
    check_after, info_after = capture_result_states(context, measured, check_mats, scope["objects"], check_frames)
    before_kept = {st: {"verts": {n: v for n, v in per["verts"].items() if n not in skip}, "mats": per["mats"]}
                   for st, per in check_before.items()}
    rolls = {}
    drift, worst = result_drift(before_kept, check_after, s, _uv_projectors_in(scope["objects"]), rolls)
    for name in sorted(rolls):
        rot, st, skew = rolls[name]
        rep.warn(W_ROLL_UNDETERMINED, object=name, rotation=_r(rot, 6), state=st, skew_before=_r(skew, 6))
    for name in sorted(drift):
        d, st, tol, rot = drift[name]
        extra = {} if rot is None else {"rotation": _r(rot, 8)}
        rep.warn(W_RESULT_DRIFT, object=name, max_mm=_r(d, 6) if math.isfinite(d) else "vertex count changed",
                 state=st, tol_mm=_r(tol, 6), **extra)
    # not evaluated in some state even when shown (a visibility kept by a driver, an evaluation error): never silent
    not_evaluated = result_not_measured(before_kept, check_after)
    for name in not_evaluated:
        rep.warn(W_NOT_MEASURED, object=name)
    n_bones = len([n for n in check_after.get("CURRENT", {}).get("mats", {}) if ": " in n
                   and n.split(": ", 1)[0] in {o.name for o in check_mats if o.type == "ARMATURE"}])
    report["result_check"] = {"measured": sorted(o.name for o in measured if o.name not in not_evaluated),
                              "measured_objects": sorted(o.name for o in check_mats if o.name not in not_evaluated),
                              "measured_bones": n_bones,
                              "not_evaluated": not_evaluated, "states": sorted(check_after),
                              "frames": list(check_frames), "shown": info_before["shown"],
                              "render_switches": info_before["render_switches"],
                              "worst_mm": worst,
                              "drift": {n: [_r(v[0], 6) if math.isfinite(v[0]) else "inf", v[1]]
                                        + ([] if v[3] is None else [_r(v[3], 8)]) for n, v in drift.items()},
                              "roll_undetermined": {n: [_r(v[0], 6), v[1], _r(v[2], 6)] for n, v in rolls.items()},
                              "skipped": sorted(skip),
                              "seconds": t_check + time.time() - t1}
    report["invalid_drivers_after"] = invalid_drivers()
    before_bad = set(report["invalid_drivers_before"])
    report["new_invalid_drivers"] = [d for d in report["invalid_drivers_after"] if d not in before_bad]
    # what may not be exactly s times what it was: every note outside NOT_DEFECT_WARNINGS (the operator
    # adds the drivers that became invalid); the standalone MIK script refused to save on either
    report["defects"] = [w for w in report["warnings"] if w.get("msg") not in NOT_DEFECT_WARNINGS]
    report["counts"] = dict(report["counts"])
    report["changes_total"] = len(report["changes"])
    report["seconds"] = time.time() - t0
    _LAST_REPORT = report
    return report, []


def last_report():
    """The report of the last ``rescale`` in this session (one is kept, in memory only)."""
    return _LAST_REPORT


def register() -> bool:
    return True


def unregister() -> dict:
    global _LAST_REPORT
    _LAST_REPORT = {}
    return {}
