# -*- coding: utf-8 -*-
"""Collision shapes for the jiggle chains, fitted to the character's own skin.

What the user asked for is lightweight low-poly collision objects of the same
shape as the model, rather than the model itself. That is exactly right, and it
is what the cloth simulation gets -- :func:`build_proxy` emits real low-poly
meshes with a Collision modifier. The bone solver reads the same shapes
analytically instead of as triangles, for three measured reasons:

1. **A coarse mesh's facets sit inside the shape they stand for.** The chord
   sag of an inscribed n-gon of radius r is ``r * (1 - cos(pi/n))``: on a 100mm
   limb that is 3.4mm at 12 sides, and on a 500mm torso 17.0mm -- the same order
   as the entire clearance budget. A draped cloth's rest height swung 12mm
   between 8 and 64 sides while the triangle distance stayed pinned at 13.00mm.
   So a mesh proxy has no single radius: it has one that oscillates between the
   vertex rings and the facet valleys. A capsule has no sag term at all.
2. **A mesh gives no inside/outside sign.** ``closest_point_on_mesh`` returns a
   face normal with no sidedness, so the sign has to come from
   ``(p - hit).dot(normal)``, which is wrong in concave regions -- the armpit,
   the crotch, under the chin, behind the knee. Those are precisely where hair
   and straps come to rest. A capsule's sign is ``|p - q| - R``, exact
   everywhere including inside.
3. **The cost lands in the solver's inner loop**, which is links x colliders x
   sweeps x frames. A capsule test is a closest-point-between-segments and one
   normalise; a mesh test crosses into C for every one of them.

The two cannot drift apart, because the proxy meshes are generated FROM the
collider bones and never hand-edited.

**A collider is a bone.** head to tail is the capsule's axis and
``head_radius`` / ``tail_radius`` are its radii, which is the parameterisation
both consumers want. It follows the rig with no mesh evaluation, Blender draws
it as a capsule in envelope display so the user can see and drag it, and there
is no per-object visibility flag that can silently freeze it.

The name matters. ``srs_col_`` and not ``c_*``: the hygiene sweep locks any
bone whose channels measure no mesh movement, and a collider moves no mesh, so
a ``c_``-named collider would be locked and the user could no longer drag it.
Not ``cc_*`` either -- ARP registers that as a custom bone and its FBX writer
puts ``head_radius`` into the exported bone's size.
"""

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = "srs_collide"

import math
import re

import bpy
import mathutils

from . import generation

PREFIX = "srs_col_"
COLLECTION = "SRS Colliders"
PROXY_PREFIX = "SRS_Proxy_"
PROXY_COLLECTION = "SRS Collision Proxy"


def proxy_objects(collection):
    """Every object in ``collection`` and its children, read from the collections' own object lists.

    ``Collection.all_objects`` is a cache; on a real character file it handed back
    ``None`` entries and the loop that changed the proxies' visibility reached 13 of
    the 25 (measured on MIK_128, SmartRig 2.61.1).
    """
    out, seen, stack = [], set(), [collection]
    while stack:
        current = stack.pop()
        for obj in current.objects:
            if obj is not None and obj.name not in seen:
                seen.add(obj.name)
                out.append(obj)
        stack.extend(current.children)
    return out


def layer_collections(scene, collection):
    """The collection's entry in every view layer of ``scene`` (the eye icon lives there)."""
    found = []
    for view_layer in scene.view_layers:
        stack = [view_layer.layer_collection]
        while stack:
            current = stack.pop()
            if current.collection == collection:
                found.append(current)
            stack.extend(current.children)
    return found


def hide_from_rays(obj):
    """Out of the rendered image, still in the scene. hide_render would also take a collider away from an unbaked
    cloth at render time, and hiding the collection from the viewport takes it out of evaluation altogether."""
    obj.hide_render = False
    for name in ("visible_camera", "visible_diffuse", "visible_glossy", "visible_transmission",
                 "visible_volume_scatter", "visible_shadow"):
        if hasattr(obj, name):
            setattr(obj, name, False)

# Resolve by stem. ``use_deform`` is useless as a filter -- 539 of 1009 bones
# carry it and 363 of those ARE the jiggle chains, so fitting from them is
# self-collision by construction. ARP's own "skip c_*" heuristic is useless the
# other way: 86 of the 89 c_* facial bones deform skin.
GROUPS = {
    "head": [("head", ("head.x",)), ("neck", ("neck.x", "subneck_twist_1.x"))],
    "torso": [("chest", ("spine_03.x",)), ("waist", ("spine_02.x",)),
              ("belly", ("spine_01.x",)), ("hips", ("root.x",))],
    "arms": [("shoulder", ("shoulder",)), ("upper", ("arm",)),
             ("fore", ("forearm",)), ("hand", ("hand",))],
    "legs": [("thigh", ("thigh",)), ("shin", ("leg",)), ("foot", ("foot",)),
             ("toes", ("toes_01",))],
}
SIDED = {"shoulder", "upper", "fore", "hand", "thigh", "shin", "foot", "toes"}
# in the same buckets by name, but nothing collides with a tongue, and these
# carry no weight at all
NEVER = {"jawbone.x", "tong_01.x", "tong_02.x", "tong_03.x",
         "c_chin_02.x", "c_eye_ref_track.l", "c_eye_ref_track.r"}
OPTIONAL = {"toes"}


def _side_names(stem, sided):
    if not sided:
        return [(stem, "")]
    return [("%s.l" % stem, ".l"), ("%s.r" % stem, ".r")]


def limb_family(armature, stem, side):
    """The deform sub-bones ARP split one limb segment into.

    Five is this rig's setting, not ARP's default: ``arm_twist_bones`` /
    ``leg_twist_bones`` are ``IntProperty(default=1, min=1, max=32)``, so read
    the count off the reference bone rather than hard-coding it, and fall back
    to a numeric scan. A ``*twist*`` name filter must NOT be used -- the
    ``_stretch`` member holds a minority of its family everywhere on the body
    (forearm 8/20/20/11/48), and such a filter would also destroy
    ``subneck_twist_1.x``, which is a neck carrying 5824 dominant vertices.
    """
    bones = armature.data.bones
    reference = None
    for name in ("%s_ref%s" % (stem, side), "%s_ref%s" % (
            "thigh" if stem == "leg" else stem, side)):
        reference = bones.get(name)
        if reference is not None:
            break
    count = 0
    if reference is not None:
        try:
            count = int(reference.get("twist_bones_amount", 0) or 0)
        except (TypeError, ValueError):
            count = 0
    members = []
    first = ["%s_twist%s" % (stem, side),
             "c_%s_twist_offset%s" % (stem, side)]
    for name in first:
        if bones.get(name) is not None:
            members.append(name)
            break
    if count > 1:
        for n in range(2, count + 1):
            members.append("%s_twist_%d%s" % (stem, n, side))
    else:
        # scan: the count is unavailable or 1, so find what actually exists
        for n in range(2, 33):
            name = "%s_twist_%d%s" % (stem, n, side)
            if bones.get(name) is None:
                break
            members.append(name)
    members.append("%s_stretch%s" % (stem, side))
    out = []
    for name in members:
        bone = bones.get(name)
        if bone is not None and bone.use_deform and name not in NEVER:
            out.append(name)
    if not out:
        bone = bones.get("%s%s" % (stem, side))
        if bone is not None and bone.use_deform:
            out = ["%s%s" % (stem, side)]
    return out


def segment_axis(armature, stem, side, members):
    """``(head, tail)`` in world space for one capsule's axis.

    The rig already carries the segment axis as a NON-deform bone -- ``thigh.l``
    ``leg.l`` ``arm.l`` ``forearm.l`` -- whose length matches the member sum to
    0.001mm. Use it. Otherwise order the members by projection along the chain,
    never by name suffix: ``<stem>_twist`` is the proximal end on the thigh and
    upper arm but the DISTAL end on the shin and forearm, and a name-ordered
    axis measured 267.326mm on a shin whose true length is 445.543mm.
    """
    matrix = armature.matrix_world
    whole = armature.data.bones.get("%s%s" % (stem, side))
    if whole is not None:
        return matrix @ whole.head_local, matrix @ whole.tail_local
    rows = [armature.data.bones[n] for n in members
            if armature.data.bones.get(n) is not None]
    if not rows:
        return None, None
    if len(rows) == 1:
        return matrix @ rows[0].head_local, matrix @ rows[0].tail_local
    points = []
    for bone in rows:
        points.append(matrix @ bone.head_local)
        points.append(matrix @ bone.tail_local)
    centre = sum(points, mathutils.Vector()) / len(points)
    best, axis = -1.0, None
    for n in range(len(points)):
        for m in range(n + 1, len(points)):
            span = (points[m] - points[n]).length
            if span > best:
                best, axis = span, (points[n], points[m])
    if axis is None:
        return None, None
    head, tail = axis
    if (head - centre).length < (tail - centre).length:
        return head, tail
    return tail, head


def _dominant(meshes, armature):
    """``{bone name: [world points]}`` by argmax weight.

    Restricted to groups that name an existing ``use_deform`` bone, which is a
    required fix and not a refinement: 50.3% of this character's skin vertices
    have their heaviest group pointing at a name with NO bone at all
    (``epaules_bend.x`` 2169, ``hand_bend.l/r`` 1262, ``c_foot_bend.l/r`` 554).
    Fitted literally the head capsule saw 278 of 2229 face vertices.
    """
    real = {b.name for b in armature.data.bones if b.use_deform}
    out = {}
    for obj in meshes:
        if obj is None or obj.type != "MESH":
            continue
        names = {g.index: g.name for g in obj.vertex_groups}
        matrix = obj.matrix_world
        for vertex in obj.data.vertices:
            best, who = 0.0, None
            for entry in vertex.groups:
                name = names.get(entry.group)
                if name not in real:
                    continue
                if entry.weight > best:
                    best, who = entry.weight, name
            if who is not None:
                out.setdefault(who, []).append(matrix @ vertex.co)
    return out


def _percentile(values, fraction):
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, int(fraction * len(ordered))))
    return ordered[index]


def _spread(head, unit, points, percentile):
    """How wide and how deep the part is, across its own axis.

    ``(wide_axis, wide, narrow)``. A torso measured this way is about 140mm
    across and 100mm deep, and a single circular capsule cannot be both.
    """
    seed = mathutils.Vector((1.0, 0.0, 0.0))
    if abs(unit.dot(seed)) > 0.9:
        seed = mathutils.Vector((0.0, 1.0, 0.0))
    e1 = (seed - unit * unit.dot(seed))
    if e1.length <= 1.0e-9:
        return None, 0.0, 0.0
    e1 = e1.normalized()
    e2 = unit.cross(e1).normalized()
    first, second = [], []
    for point in points:
        offset = point - head
        offset = offset - unit * offset.dot(unit)
        first.append(abs(offset.dot(e1)))
        second.append(abs(offset.dot(e2)))
    a = _percentile(first, percentile)
    b = _percentile(second, percentile)
    if a >= b:
        return e1, a, b
    return e2, b, a


def _fit_one(head, tail, points, percentile, inset, split_ratio=0.0):
    """``(a, b, r0, r1, sample, raw_max)`` -- the capsule for one family.

    With ``split_ratio`` set, a part whose cross-section is wider than it is
    deep by more than that factor comes back as a LIST of two such tuples,
    offset along the wide direction with the narrow radius each.
    """
    axis = tail - head
    span = axis.length
    if span <= 1.0e-9 or not points:
        return None
    unit = axis / span
    radial, along = [], []
    for point in points:
        offset = point - head
        t = offset.dot(unit)
        radial.append((offset - unit * t).length)
        along.append(t)
    if not radial:
        return None
    radius = _percentile(radial, percentile) * inset
    # clamp the extent to the family's own segment: the raw projection runs
    # several bone lengths out on 37% of bones, and the worst owns foreign
    # meshes entirely (an ear bone owning headset vertices down to t = -4.76)
    low = max(min(along), -0.12 * span)
    high = min(max(along), 1.12 * span)
    if high - low <= 1.0e-9:
        low, high = 0.0, span
    half = max(0.0, 0.5 * (high - low))
    middle = head + unit * (low + half)
    a = middle - unit * half
    b = middle + unit * half
    # taper: sample a short window at each end, not the first and last thirds,
    # which sample at L/6 and 5L/6 and understate the caps
    window = max(0.12 * (high - low), 1.0e-6)
    near = [radial[n] for n in range(len(along)) if along[n] <= low + window]
    far = [radial[n] for n in range(len(along)) if along[n] >= high - window]
    r0 = _percentile(near, percentile) * inset if near else radius
    r1 = _percentile(far, percentile) * inset if far else radius
    r0, r1 = max(r0, 1.0e-4), max(r1, 1.0e-4)
    if split_ratio > 1.0:
        wide_axis, wide, narrow = _spread(head, unit, points, percentile)
        if wide_axis is not None and narrow > 1.0e-6 \
                and wide > narrow * float(split_ratio):
            step = max(0.0, (wide - narrow)) * inset
            thin = max(narrow * inset, 1.0e-4)
            return [(a + wide_axis * step, b + wide_axis * step,
                     thin, thin, len(radial), max(radial)),
                    (a - wide_axis * step, b - wide_axis * step,
                     thin, thin, len(radial), max(radial))]
    return a, b, r0, r1, len(radial), max(radial)


def plan(armature, meshes, percentile=0.90, inset=1.05, include_toes=False,
         min_vertices=50, split_ratio=1.25):
    """What capsules would be made, without making them. ``(rows, error)``."""
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    meshes = [m for m in meshes or () if m is not None and m.type == "MESH"]
    if not meshes:
        return None, ("Choose the skin mesh(es) to fit against. Over all bound "
                      "meshes dominance is not stable -- a costume bound almost "
                      "entirely to one bone hands that bone a vertex set with "
                      "no relation to the bone.")
    owned = _dominant(meshes, armature)
    extent = [p for obj in meshes for p in
              (obj.matrix_world @ mathutils.Vector(c) for c in obj.bound_box)]
    if extent:
        box = max((max(p[n] for p in extent) - min(p[n] for p in extent))
                  for n in range(3))
    else:
        box = 2.0
    ceiling = 0.25 * box
    rows = []
    for group, parts in GROUPS.items():
        for part, stems in parts:
            if part in OPTIONAL and not include_toes:
                continue
            for stem in stems:
                done = False
                for name, side in _side_names(stem, part in SIDED):
                    members = limb_family(armature, name.rsplit(".", 1)[0],
                                          side) if part in SIDED else []
                    if not members:
                        bone = armature.data.bones.get(name)
                        if bone is None or not bone.use_deform \
                                or name in NEVER:
                            continue
                        members = [name]
                    head, tail = segment_axis(
                        armature, name.rsplit(".", 1)[0] if side else name,
                        side, members)
                    if head is None:
                        continue
                    points = []
                    for member in members:
                        points.extend(owned.get(member, ()))
                    fitted = _fit_one(head, tail, points, percentile, inset,
                                      split_ratio=split_ratio)
                    halves = None
                    if isinstance(fitted, list):
                        halves, fitted = fitted, fitted[0]
                    fallback = False
                    if fitted is None or fitted[4] < int(min_vertices):
                        # fall back to the bone's own geometry rather than to a
                        # vertex cloud too small to describe a radius
                        axis = tail - head
                        if axis.length <= 1.0e-9:
                            continue
                        guess = max(0.02, 0.12 * axis.length)
                        fitted = (head, tail, guess, guess,
                                  fitted[4] if fitted else 0,
                                  fitted[5] if fitted else guess)
                        fallback = True
                    a, b, r0, r1, sample, raw = fitted
                    radius = max(r0, r1)
                    if halves and not fallback:
                        for n, half in enumerate(halves):
                            ha, hb, hr0, hr1, hsample, hraw = half
                            rows.append({
                                "name": "%s%s_%s%s_%d"
                                        % (PREFIX, group, part, side, n + 1),
                                "group": group, "part": part, "side": side,
                                "a": ha, "b": hb, "r0": hr0, "r1": hr1,
                                "sample": hsample,
                                "raw_max_mm": round(hraw * 1000, 1),
                                "fitted_mm": round(max(hr0, hr1) * 1000, 1),
                                "length_mm": round((hb - ha).length * 1000, 1),
                                "fallback": False, "members": members,
                                "refused": False, "split": True,
                            })
                        done = True
                        continue
                    if radius > ceiling:
                        rows.append({"name": "%s%s_%s%s"
                                     % (PREFIX, group, part, side),
                                     "group": group, "refused": True,
                                     "why": ("radius %.0fmm exceeds a quarter "
                                             "of the character (%.0fmm)"
                                             % (radius * 1000, ceiling * 1000)),
                                     "members": members})
                        continue
                    rows.append({
                        "name": "%s%s_%s%s" % (PREFIX, group, part, side),
                        "group": group, "part": part, "side": side,
                        "a": a, "b": b, "r0": r0, "r1": r1,
                        "sample": sample, "raw_max_mm": round(raw * 1000, 1),
                        "fitted_mm": round(radius * 1000, 1),
                        "length_mm": round((b - a).length * 1000, 1),
                        "fallback": fallback, "members": members,
                        "refused": False,
                    })
                    done = True
                if done:
                    break
    return rows, ""


def fit(armature, meshes, percentile=0.90, inset=1.05, include_toes=False,
        min_vertices=50, ceiling=48, bone_collection=COLLECTION,
        split_ratio=1.25):
    """Build the collider bones. ``(report, error)``."""
    rows, error = plan(armature, meshes, percentile=percentile, inset=inset,
                       include_toes=include_toes, min_vertices=min_vertices,
                       split_ratio=split_ratio)
    if error:
        return None, error
    made = [r for r in rows if not r["refused"]]
    if len(made) > int(ceiling):
        return None, ("%d capsules would be generated, over the ceiling of %d. "
                      "Raise the ceiling deliberately or narrow the skin "
                      "meshes." % (len(made), int(ceiling)))
    previous = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature
    names = []
    try:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        to_rig = armature.matrix_world.inverted()
        scale = armature.matrix_world.to_scale()
        unit = (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0 or 1.0
        for row in made:
            bone = edit.get(row["name"]) or edit.new(row["name"])
            bone.head = to_rig @ row["a"]
            bone.tail = to_rig @ row["b"]
            bone.head_radius = row["r0"] / unit
            bone.tail_radius = row["r1"] / unit
            # a collider must never deform anything. use_deform, not the
            # radius, is what gates envelope deformation.
            bone.use_deform = False
            parent = None
            for member in row["members"]:
                parent = edit.get(member)
                if parent is not None:
                    break
            bone.parent = parent
            bone.use_connect = False
            names.append(row["name"])
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous

    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for name in names:
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)
    for row in made:
        bone = armature.data.bones.get(row["name"])
        if bone is None:
            continue
        # per-bone override, so the rest of the rig keeps its own display
        bone.display_type = 'ENVELOPE'
        pose_bone = armature.pose.bones.get(row["name"])
        if pose_bone is not None:
            pose_bone["srs_col_group"] = row["group"]
            pose_bone["srs_col_enable"] = True
            pose_bone["srs_col_inside"] = False
    return {"made": names, "count": len(names),
            "refused": [{"name": r["name"], "why": r["why"]}
                        for r in rows if r["refused"]],
            "fallback": [r["name"] for r in made if r["fallback"]],
            "rows": [{"name": r["name"], "fitted_mm": r["fitted_mm"],
                      "raw_max_mm": r["raw_max_mm"],
                      "length_mm": r["length_mm"], "sample": r["sample"]}
                     for r in made]}, ""


ALT_KEY = "srs_col_alt"     # {part: [head_radius, tail_radius]} with that part taken off
BASE_KEY = "srs_col_base"   # [head_radius, tail_radius] with every part on


def _collider_bones(armature):
    return [pb for pb in armature.pose.bones if pb.name.startswith(PREFIX)]


def fit_without(armature, meshes, part, part_meshes, percentile=0.90, inset=1.05,
                include_toes=False, min_vertices=50, split_ratio=1.25):
    """Keep on every capsule the radii it should have with ``part`` taken off. ``(report, error)``.

    The capsules are fitted to the dressed silhouette, so a coat's sleeves and body
    are part of the arm and torso capsules. Hide the coat and the hair and straps
    still collide with a coat that is not there, floating off the shirt underneath.
    Both silhouettes are planned the same way -- ``meshes`` with and without
    ``part_meshes`` -- and each capsule keeps its own radii scaled by the ratio of the
    two plans (never larger), so a capsule that was adjusted by hand keeps its
    adjustment. :func:`apply_parts` switches to them while the part is hidden; the
    part's Show / Hide (part_rig.set_part_visible) calls it.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    part_set = {m for m in part_meshes or () if m is not None}
    if not part_set:
        return None, "The part has no meshes to take off."
    dressed = list({m for m in meshes or () if m is not None} | part_set)
    bare = [m for m in dressed if m not in part_set]
    if not bare:
        return None, "Nothing is left to fit against once the part is taken off."
    options = dict(percentile=percentile, inset=inset, include_toes=include_toes,
                   min_vertices=min_vertices, split_ratio=split_ratio)
    rows_on, error = plan(armature, dressed, **options)
    if error:
        return None, error
    rows_off, error = plan(armature, bare, **options)
    if error:
        return None, error
    on = {r["name"]: r for r in rows_on if not r["refused"]}
    off = {r["name"]: r for r in rows_off if not r["refused"]}
    changed = []
    for pb in _collider_bones(armature):
        bone = pb.bone
        if BASE_KEY not in pb.keys():
            pb[BASE_KEY] = [float(bone.head_radius), float(bone.tail_radius)]
        base = [float(x) for x in pb[BASE_KEY]]
        a, b = on.get(pb.name), off.get(pb.name)
        k0 = k1 = 1.0
        if a is not None and b is not None:
            k0 = min(1.0, b["r0"] / a["r0"]) if a["r0"] > 1.0e-9 else 1.0
            k1 = min(1.0, b["r1"] / a["r1"]) if a["r1"] > 1.0e-9 else 1.0
        alt = {k: [float(x) for x in v] for k, v in pb.get(ALT_KEY, {}).items()}
        alt[part] = [base[0] * k0, base[1] * k1]
        pb[ALT_KEY] = alt
        if k0 < 0.999 or k1 < 0.999:
            changed.append({"capsule": pb.name, "head_mm": [round(base[0] * 1000, 1), round(alt[part][0] * 1000, 1)],
                            "tail_mm": [round(base[1] * 1000, 1), round(alt[part][1] * 1000, 1)]})
    state = apply_parts(armature)
    return {"part": part, "capsules": len(_collider_bones(armature)), "smaller_without": changed,
            "dressed_meshes": len(dressed), "bare_meshes": len(bare), "hidden_now": state["hidden"]}, ""


def apply_parts(armature):
    """Give every capsule the radii for the parts hidden right now. ``{"hidden", "capsules"}``."""
    if armature is None or armature.type != "ARMATURE":
        return {"hidden": [], "capsules": 0}
    parts = set()
    for pb in _collider_bones(armature):
        parts |= set(pb.get(ALT_KEY, {}).keys())
    hidden = sorted(p for p in parts if bpy.data.collections.get(p) is not None
                    and bpy.data.collections[p].hide_viewport)
    n = 0
    for pb in _collider_bones(armature):
        if BASE_KEY not in pb.keys():
            continue
        r0, r1 = (float(x) for x in pb[BASE_KEY])
        alt = pb.get(ALT_KEY, {})
        for part in hidden:
            if part in alt.keys():
                r0, r1 = min(r0, float(alt[part][0])), min(r1, float(alt[part][1]))
        if abs(pb.bone.head_radius - r0) > 1.0e-9 or abs(pb.bone.tail_radius - r1) > 1.0e-9:
            pb.bone.head_radius, pb.bone.tail_radius = r0, r1
            n += 1
    return {"hidden": hidden, "capsules": n}


def clear_alternates(armature, part=None):
    """Forget the radii for ``part`` (or every part) and restore the dressed radii. ``(report, error)``."""
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    n = 0
    for pb in _collider_bones(armature):
        alt = {k: [float(x) for x in v] for k, v in pb.get(ALT_KEY, {}).items()}
        if part is None:
            alt = {}
        else:
            alt.pop(part, None)
        if alt:
            pb[ALT_KEY] = alt
        elif ALT_KEY in pb.keys():
            del pb[ALT_KEY]
        if not alt and BASE_KEY in pb.keys():
            pb.bone.head_radius, pb.bone.tail_radius = (float(x) for x in pb[BASE_KEY])
            del pb[BASE_KEY]
            n += 1
    apply_parts(armature)
    return {"restored": n}, ""


def clear(armature):
    """Remove every collider bone. ``(report, error)``."""
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    names = [b.name for b in armature.data.bones if b.name.startswith(PREFIX)]
    if not names:
        return {"removed": 0}, ""
    previous = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        for name in names:
            bone = edit.get(name)
            if bone is not None:
                edit.remove(bone)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous
    return {"removed": len(names)}, ""


def colliders(armature):
    """The collider bones that exist, with their fitted sizes."""
    out = []
    if armature is None or armature.type != "ARMATURE":
        return out
    for bone in armature.data.bones:
        if not bone.name.startswith(PREFIX):
            continue
        out.append({"name": bone.name,
                    "length_mm": round(bone.length * 1000, 1),
                    "head_mm": round(bone.head_radius * 1000, 1),
                    "tail_mm": round(bone.tail_radius * 1000, 1),
                    "deform": bone.use_deform})
    return out


def _capsule_mesh(name, span, r0, r1, sides=12, rings=2):
    """A low-poly capsule, built along +Y so it matches a bone's own axis."""
    verts, faces = [], []
    step = 2.0 * math.pi / sides
    bands = []
    for level in range(rings + 1):
        t = level / float(rings)
        bands.append((t * span, r0 + (r1 - r0) * t))
    for y, radius in bands:
        for n in range(sides):
            angle = n * step
            verts.append((math.cos(angle) * radius, y,
                          math.sin(angle) * radius))
    for band in range(len(bands) - 1):
        base = band * sides
        for n in range(sides):
            nxt = (n + 1) % sides
            faces.append((base + n, base + nxt,
                          base + sides + nxt, base + sides + n))
    low = len(verts)
    verts.append((0.0, -r0 * 0.75, 0.0))
    high = len(verts)
    verts.append((0.0, span + r1 * 0.75, 0.0))
    top = (len(bands) - 1) * sides
    for n in range(sides):
        nxt = (n + 1) % sides
        faces.append((low, nxt, n))
        faces.append((high, top + n, top + nxt))
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.validate()
    mesh.update()
    return mesh


def build_proxy(armature, sides=12, thickness_mm=8.0, damping=0.2,
                friction=5.0, collection=PROXY_COLLECTION):
    """Low-poly collision meshes from the collider bones. ``(report, error)``.

    This is the thing the user asked for, and it is what Blender's own cloth
    solver consumes. Each capsule becomes one object parented to its collider
    bone, so it follows the rig without an Armature modifier and without a mesh
    deform -- a bone-parented rigid island is both cheaper and exactly rigid.

    It must stay visible to the depsgraph. ``hide_viewport`` (the monitor icon)
    takes it out of evaluation and the cloth falls through it, and an unbaked
    cloth rendered with F12 ignores a ``hide_render`` collider. So the proxy is
    kept out of the image by its ray visibility, drawn as bounds and not
    selectable, and left evaluable.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    rows = [b for b in armature.data.bones if b.name.startswith(PREFIX)]
    if not rows:
        return None, ("No collider bones. Fit the colliders first -- the proxy "
                      "is generated from them so the two cannot disagree.")
    group = bpy.data.collections.get(collection)
    if group is None:
        group = bpy.data.collections.new(collection)
        bpy.context.scene.collection.children.link(group)
    made = []
    for bone in rows:
        name = PROXY_PREFIX + bone.name[len(PREFIX):]
        old = bpy.data.objects.get(name)
        if old is not None:
            bpy.data.objects.remove(old, do_unlink=True)
        mesh = _capsule_mesh(name, bone.length, bone.head_radius,
                             bone.tail_radius, sides=int(sides))
        obj = bpy.data.objects.new(name, mesh)
        group.objects.link(obj)
        obj.parent = armature
        obj.parent_type = "BONE"
        obj.parent_bone = bone.name
        # a bone parent puts the child at the bone's TAIL, so step back by the
        # bone's length along its own Y to land on the head
        obj.matrix_parent_inverse = mathutils.Matrix.Translation(
            (0.0, -bone.length, 0.0))
        hide_from_rays(obj)
        obj.display_type = "BOUNDS"
        obj.hide_select = True
        modifier = obj.modifiers.new(name="SRS Collision", type="COLLISION")
        settings = obj.collision
        settings.use = True
        settings.thickness_outer = max(0.001, thickness_mm * 0.001)
        # Blender's default inner thickness is 0.2 -- 200mm at this scale -- and
        # the existing add_collision never set it, so the body carried a 200mm
        # inner shell
        settings.thickness_inner = max(0.001, thickness_mm * 0.001)
        settings.damping = float(damping)
        settings.cloth_friction = float(friction)
        settings.use_culling = True
        if hasattr(modifier, "use_pin_to_last"):
            # keeps Collision last even when a modifier is added afterwards;
            # modifiers.move() does not survive that
            modifier.use_pin_to_last = True
        made.append(name)
    return {"made": made, "count": len(made), "collection": collection,
            "sides": int(sides),
            "sag_mm": round(1000.0 * max(
                b.head_radius for b in rows) * (1.0 - math.cos(
                    math.pi / max(3, int(sides)))), 2)}, ""


def clear_proxy(collection=PROXY_COLLECTION):
    """Remove the generated proxy meshes. ``(report, error)``."""
    gone = 0
    for obj in list(bpy.data.objects):
        if obj.name.startswith(PROXY_PREFIX):
            bpy.data.objects.remove(obj, do_unlink=True)
            gone += 1
    group = bpy.data.collections.get(collection)
    if group is not None and not group.objects:
        bpy.data.collections.remove(group)
    return {"removed": gone}, ""


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
