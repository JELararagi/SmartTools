# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Keep a facial bone inside the feature it belongs to.

Auto-Rig Pro's generated facial weights are deliberately generous. On a human
scan that reads as softness; on a stylised head with separate accessory meshes it
reads as everything moving at once. Measured on the reference character, with
reach expressed against the spacing to the bone's nearest sibling (its own length
is meaningless here -- every ``c_eyebrow_*`` is the same 4.9mm generator default):

    c_nose_01.x          reach 33.62mm = 5.67x spacing, 621 vertices weighted
    c_eye_offset.l/.r    reach 97.61mm = 4.06x, 496 weighted
    c_cheek_inflate.l/.r reach 61.85mm = 3.33x, 493 weighted
    c_eyelid_corner_01   reach 38.87mm = 1.62x, 322 weighted

and the consequences, as displacement of the thing that should not have moved:

    closing the left eyelid moved the brow region of the face by 14.79mm
    closing the left eyelid moved the face piercings by 23.87mm
    raising the left brow moved the eyelid region by 4.60mm
    opening the jaw moved the upper lip's centre by 5.06mm, downward

The last one is worth spelling out because it is not the obvious cause. Auto-Rig
Pro's lip-retain system was NOT the path: ``c_jawbone.x["lips_retain"]`` is 0 and
the centre bone ``c_lips_top.x`` measures 0.000mm of motion under an open jaw.
What moves the upper lip is that LOWER-lip bones carry weight on it --
``c_lips_bot.x`` holds weight on 20 upper-lip vertices and travels 46.84mm, and
``c_lips_bot_01.*`` on 12 more at 33.71mm. So the fix there is a weight
boundary, not a property.

The treatment is a boundary per (bone family, region) pair rather than a global
reach cap. A global cap was rejected on the evidence: ``c_eye_offset`` is a
28.01mm aim bone whose long reach is its job, so a rule keyed on reach alone
would cut the thing it is supposed to do while leaving the 4.90mm brow bones --
whose absolute reach is small but whose ratio is the worst -- untouched.

Two guards, both of which exist because the naive version is wrong:

* **One renormalisation at the end, never one per rule.** Removing a bone's share
  and immediately renormalising hands that share to whatever else happens to be
  on the vertex, so a second rule then trims an already-inflated weight and the
  vertex drifts. All rules are collected, then the vertex is normalised once.
* **A vertex never loses its last bone.** If the trims would leave a vertex with
  almost no main-rig weight, the trims on that vertex are abandoned and it is
  reported. An unweighted vertex does not stay put, it collapses, and it would
  not show up in a weight-sum check that only counts vertices that still have
  groups.

Depth into a region is measured along the MESH, not through space: shortest path
over the edges from the region's boundary. A lip and the skin above it are
millimetres apart through the air and far apart across the surface, and a
Euclidean taper leaks through the gap.
"""

import bpy
from mathutils import Vector

MIN_REMAINING = 0.05
# The most weight one bone may GAIN on one vertex from a normalise. Without this
# the normalise divides the freed weight by whatever untrimmed weight happens to
# be left, and where that is almost nothing the multiplier is enormous: measured
# on the reference character, c_eye_offset.l went from 0.0001 to 0.5648 on a
# single vertex whose four neighbours stayed at 0.0013, 0.0000, 0.0011 and 0.4256.
# Which bones are negligible varies vertex to vertex, so the result alternates --
# a checkerboard in the weight field, which is exactly what reads as juddering in
# the surface between the eye and the brow. This is the defect, not the geometry.
MAX_GAIN = 0.15
# A bone holding less than this on a vertex was not carrying it, and must not be
# drafted in to carry it by a normalise.
CANDIDATE_FLOOR = 0.02
TAPER_MM = 14.0
EPSILON = 0.0005
# How far from the eye opening still counts as "around the eye". The lid
# region itself is 573 vertices on this character -- it reaches the brow, so
# using it as the forbidden zone for brow bones stripped the brow of its own
# weights and made the defect worse (brow displacement 14.79 -> 22.66mm).
EYE_AREA_MM = 12.0
# Half-width of "the middle of the upper lip". The user asked for the centre
# to be completely still under the jaw, and this is the core that is cleared
# outright; the taper then carries it back to full weight further out.
LIP_CENTRE_MM = 8.0
# How far from the midline a vertex has to be before a sided bone is asked to
# leave it alone. Inside this band both sides legitimately blend.
MIDLINE_MM = 6.0
# Width of the blend band across the centre line for the midline
# rules. An eye or brow bone reaching past this is reaching onto the
# other face; the eye itself sits 40mm out. Kept narrow on purpose:
# at 3mm the band was wider than the measurement threshold, so the
# crossing hid inside it and the rule looked like it had done nothing.
STRICT_MIDLINE_MM = 1.0

# Each rule says: this family of bones must not reach into that region.
# "forbid" names a region produced by :func:`regions`.
# The rules that pay for themselves. Every one was measured against the
# untreated character, and together they add NO edge folded past 40 or 70
# degrees anywhere on the face:
#
#     a blink moved the brow 14.792mm           to 2.29mm
#     a blink moved the OTHER brow 0.742mm      to 0.013mm
#     the eye aim moved the upper lip 2.393mm   to 0.000mm
#     an open jaw moved the upper lip 14.249mm  to 11.78mm
#     lid closure 102.03 to 100.57 per cent, brow throw 4.64 to 5.83mm
RULES = (
    {"key": "eyelid out of the brow", "forbid": "brow",
     "bones": ("c_eyelid_", "eyelid_base", "c_eye_offset", "c_eye."),
     "taper_mm": 14.0},
    {"key": "eyelid out of the lips", "forbid": "lips",
     "bones": ("c_eyelid_", "c_eye_offset", "c_eye."), "taper_mm": 14.0},
    {"key": "lower lip out of the upper lip", "forbid": "lip_upper",
     "bones": ("c_lips_bot", "c_lips_roll_bot", "c_chin_"), "taper_mm": 14.0},
    # A sided eye, lid, brow or cheek bone has no business on the other half of
    # the face. Measured on the reference character, moving a LEFT control moved
    # the whole right half: c_eyelid_bot.l by 5.645mm, c_eye_offset.l by 2.435mm,
    # c_eyebrow_full.l by 2.329mm, c_eyelid_corner_01.l by 1.895mm, and 41 of the
    # 55 left-side facial controls moved it at all. Lips, nose, jaw and chin are
    # deliberately NOT in these rules -- those are midline structures and they
    # blend across on purpose.
    {"key": "left eye bones off the right half", "forbid": "across_right",
     "bones": ("c_eyelid_", "eyelid_", "c_eyebrow_", "eyebrow_", "c_eye.",
               "c_eye_offset", "c_cheek_"),
     "suffix": ".l", "taper_mm": 6.0, "hard_core": True,
     "keep_brow": False},
    {"key": "right eye bones off the left half", "forbid": "across_left",
     "bones": ("c_eyelid_", "eyelid_", "c_eyebrow_", "eyebrow_", "c_eye.",
               "c_eye_offset", "c_cheek_"),
     "suffix": ".r", "taper_mm": 6.0, "hard_core": True,
     "keep_brow": False},
    # The lips DO blend across the centre line -- they are one continuous strip --
    # so these get a much wider band than the eye rules, 14mm against 6mm. What is
    # being removed is a left lip bone acting 10mm onto the right lip, measured at
    # 0.1466 on 29 vertices, which moved the right half 1.229mm from a left
    # control. The blend near the centre survives; the reach past it does not.
    {"key": "left lip bones off the right half", "forbid": "across_right",
     "bones": ("c_lips_", "lips_"),
     "suffix": ".l", "taper_mm": 14.0, "hard_core": True, "keep_brow": False},
    {"key": "right lip bones off the left half", "forbid": "across_left",
     "bones": ("c_lips_", "lips_"),
     "suffix": ".r", "taper_mm": 14.0, "hard_core": True, "keep_brow": False},
    # The midline of the upper lip must not ride the jaw. Everything here was
    # measured travelling with an open jaw: c_lips_bot.x 46.84mm, c_lips_bot_01
    # 33.71mm, c_lips_top_01 8.77mm, against a recipient that travels 0.000mm.
    #
    # c_lips_corner_mini is deliberately NOT in this list even though it holds
    # weight here, because it travels 20.43mm and trimming it creases the lip:
    # every strength from 0.3 up put 12 edges past 40 degrees and 2 past 70 where
    # the untreated character had 16 and 0. Leaving it in costs 1.0mm at the
    # midline (6.07mm against 5.06mm untreated) and buys a lip with no crease in
    # it. That is the whole trade, and it is not a defect that can be smoothed
    # away -- see OPTIONAL_RULES.
    {"key": "jaw out of the upper lip centre", "forbid": "lip_upper_centre",
     "bones": ("c_lips_bot", "c_lips_roll_bot", "c_chin_", "c_lips_top_01",
               "c_lips_top.", "c_jawbone"),
     "taper_mm": 20.0,
     "donate_to": "c_lips_top.x"},
)

# Rules that do NOT pay for themselves here, kept because another character
# may need them and because the cost is worth writing down.
#
# What they lose is geometric, not a defect waiting to be fixed. Hold one
# region still while its neighbour travels and the difference has to be
# absorbed by the edge loops between them; there are about four of them here.
# The two eye-area rules buy 2.31mm and 0.69mm of crosstalk and cost, between
# them, 14 edges folded past 40 degrees and 6 past 70 where the untreated
# character had 2 and 0 -- the worst a 149-degree fold at the outer eye
# corner, where c_nose_03.x reaches 34.64mm from its own head and still
# carries 0.64 of the weight. The lip-centre rule buys 1.2mm on the upper lip
# and costs a crease across it.
#
# Smoothing cannot buy the difference back. Relaxing every group took the lid
# closure from 102 per cent to 12.5, because the lid weights ARE the closure;
# relaxing only the allowed groups keeps the rig intact but leaves the folds,
# because they are not noise.
#
# Pass them as rules=RULES + OPTIONAL_RULES if a character needs them, and
# measure new_over_70 either side.
OPTIONAL_RULES = (
    # The aggressive form of the midline rule: adds c_lips_corner_mini, which
    # travels 20.43mm. It takes the midline from 6.07mm to 5.53mm and creases the
    # upper lip at every strength tried, from 0.3 upward.
    {"key": "lip corner out of the upper lip centre",
     "forbid": "lip_upper_centre", "bones": ("c_lips_corner_mini",),
     "taper_mm": 28.0, "donate_to": "c_lips_top.x"},
    {"key": "brow out of the eye area", "forbid": "eye_area",
     "bones": ("c_eyebrow_", "eyebrow_"), "taper_mm": 14.0},
    {"key": "nose out of the eye area", "forbid": "eye_area",
     "bones": ("c_nose_",), "taper_mm": 14.0},
    {"key": "brow out of the lips", "forbid": "lips",
     "bones": ("c_eyebrow_", "eyebrow_"), "taper_mm": 14.0},
)


def _deform_names(armature):
    return {bone.name for bone in armature.data.bones if bone.use_deform}


def matching(armature, patterns):
    """Deform bone names that start with any of ``patterns``."""
    names = _deform_names(armature)
    return sorted(n for n in names
                  if any(n.startswith(p) for p in patterns))


def regions(face, armature, brow_object=None, teeth_upper=None,
            teeth_lower=None):
    """The named regions the rules refer to. ``(regions, error)``.

    Only integer vertex sets are kept. The region helpers also return bounding
    boxes and counts, and a float that looks like an index is a real bug source.
    """
    from . import face_regions

    if face is None or armature is None:
        return None, "Need the face mesh and the armature"
    out = {}
    lid = set()
    eye = set()
    count = len(face.data.vertices)

    def harvest(source, keys, into):
        """Named keys only, and every index checked against the mesh.

        Sniffing by type is what went wrong here, and it went wrong invisibly:
        ``aperture_ring`` also returns ``all_boundary_ring_sizes``, a list of ring
        LENGTHS, which is a list of ints and so passed a type test and was unioned
        in as if those lengths were vertex indices. The arithmetic is exact -- the
        eye region came back 50 where two 24-vertex sockets are 48 -- and the
        giveaway was that those two strays moved 3.64mm on BOTH sides from a
        purely left-side pose, because a ring length is mesh-global and the same
        two numbers were injected into each side.
        """
        if not source:
            return
        for key in keys:
            value = source.get(key)
            if not isinstance(value, (list, set, tuple)):
                continue
            for index in value:
                if isinstance(index, int) and 0 <= index < count:
                    into.add(index)

    for side in (".l", ".r"):
        ring, error = face_regions.aperture_ring(face, armature, side)
        if not error:
            harvest(ring, ("ring", "upper", "lower"), eye)
        region, error = face_regions.lid_region(face, armature, side)
        if not error:
            harvest(region, ("vertices",), lid)
    out["eye"] = eye
    out["lid"] = lid | eye
    # "Around the eye" is a band measured out from the opening itself, NOT the
    # lid region, which on this character reaches the brow.
    out["eye_area"] = set(_spread(face, eye, EYE_AREA_MM))

    if brow_object is not None:
        footprint, error = face_regions.brow_footprint(face, brow_object)
        if not error and footprint:
            brow_set = set()
            harvest(footprint, ("footprint_vertices",), brow_set)
            out["brow"] = brow_set
            # The brow's own vertices are never "around the eye", whatever the
            # band reached. Overlapping regions make two rules fight over the
            # same vertex and the loser gets amplified by the normalise.
            out["eye_area"] -= out["brow"]
    lips, error = face_regions.lip_regions(face, teeth_upper=teeth_upper,
                                           teeth_lower=teeth_lower)
    if not error and lips:
        upper = set(lips.get("confident_upper") or ())
        lower = set(lips.get("confident_lower") or ())
        out["lip_upper"] = upper - out.get("eye_area", set()) \
            - out.get("brow", set())
        out["lip_lower"] = lower - out.get("eye_area", set()) \
            - out.get("brow", set())
        out["lips"] = out["lip_upper"] | out["lip_lower"]
    upper = out.get("lip_upper") or set()
    if upper:
        matrix = face.matrix_world
        out["lip_upper_centre"] = set(
            i for i in upper
            if abs((matrix @ face.data.vertices[i].co).x) <= LIP_CENTRE_MM * 0.001)
    matrix = face.matrix_world
    left, right = set(), set()
    for vertex in face.data.vertices:
        x = (matrix @ vertex.co).x * 1000.0
        if x > MIDLINE_MM:
            left.add(vertex.index)
        elif x < -MIDLINE_MM:
            right.add(vertex.index)
    out["side_left"] = left
    out["side_right"] = right
    across = [(matrix @ v.co).x * 1000.0 for v in face.data.vertices]
    out["across_right"] = set(i for i, x in enumerate(across)
                              if x < -STRICT_MIDLINE_MM)
    out["across_left"] = set(i for i, x in enumerate(across)
                             if x > STRICT_MIDLINE_MM)
    missing = [r["forbid"] for r in RULES if r["forbid"] not in out]
    return out, ("no region for: %s" % ", ".join(sorted(set(missing)))
                 if missing else "")


def _neighbours(mesh_object):
    table = {}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        table.setdefault(a, []).append(b)
        table.setdefault(b, []).append(a)
    return table


def _hop_field(mesh_object, seeds, smooth=3):
    """Edge hops from ``seeds``, averaged into a continuous field.

    The raw hop count is an integer, so a ramp built straight on it moves a whole
    loop at a time: every vertex of loop five gets one factor and every vertex of
    loop six another, and that step is the same crease the coordinate limits were
    introduced to avoid. Averaging over the neighbourhood keeps the loop-to-loop
    gradient -- the field still rises by about one per loop, because it rose by
    exactly one before -- while making the value vary continuously WITHIN a loop,
    which is what a weight needs to stay smooth along the boundary as well as
    across it.

    A vertex the seeds cannot reach along the edges is absent from the result: it
    is not within any number of loops of them.

    Returns ``(field, origin)``. ``origin`` is the seed each vertex was reached
    from, which is what makes "below the loop" answerable: the loop is not flat, so
    the only honest reference height for a vertex is the height of the part of the
    loop the walk came from. Measured against the loop's LOWEST point instead, a
    6mm gate leaves a horizontal band in which the loop count barely applies, and
    that band runs sideways to the ear -- which is how the nose studs, 1mm below
    the loop's lowest point and fifteen loops away, kept their eyelid weight.
    """
    table = _neighbours(mesh_object)
    seeds = [i for i in seeds if 0 <= i < len(mesh_object.data.vertices)]
    if not seeds:
        return {}, {}
    hops = {i: 0 for i in seeds}
    origin = {i: i for i in seeds}
    frontier = list(seeds)
    while frontier:
        nxt = []
        for index in frontier:
            for other in table.get(index, ()):
                if other not in hops:
                    hops[other] = hops[index] + 1
                    origin[other] = origin[index]
                    nxt.append(other)
        frontier = nxt
    field = {i: float(h) for i, h in hops.items()}
    for _round in range(max(0, int(smooth))):
        updated = {}
        for index, value in field.items():
            total, count = value, 1
            for other in table.get(index, ()):
                if other in field:
                    total += field[other]
                    count += 1
            updated[index] = total / count
        # The seeds are the boundary condition. Letting them drift inward pulls
        # the whole field down and the ramp starts a loop early.
        for index in seeds:
            updated[index] = 0.0
        field = updated
    return field, origin


def _unit_mm(mesh_object):
    scale = mesh_object.matrix_world.to_scale()
    return (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0 * 1000.0


def _spread(mesh_object, seeds, limit_mm):
    """Vertices within ``limit_mm`` of ``seeds``, measured along the edges.

    Along the mesh, not through the air: a lip and the skin above it are
    millimetres apart in space and far apart across the surface, so a Euclidean
    ball leaks straight through the gap.
    """
    import heapq

    if not seeds:
        return {}
    neighbours = _neighbours(mesh_object)
    coords = [v.co for v in mesh_object.data.vertices]
    unit = _unit_mm(mesh_object)
    best = {v: 0.0 for v in seeds}
    heap = [(0.0, v) for v in seeds]
    heapq.heapify(heap)
    while heap:
        distance, vertex = heapq.heappop(heap)
        if distance > best.get(vertex, 1.0e18) + 1.0e-9:
            continue
        for other in neighbours.get(vertex, ()):
            step = distance + (coords[vertex] - coords[other]).length * unit
            if step <= limit_mm and step < best.get(other, 1.0e18):
                best[other] = step
                heapq.heappush(heap, (step, other))
    return best


def _harmonic(mesh_object, core, band, rounds=400):
    """The smoothest ramp from 0 on ``core`` to 1 outside ``band``.

    Returns ``{vertex: factor}`` over the band. Solved by Jacobi relaxation of
    Laplace's equation with those two boundaries fixed, which is by definition the
    field of least gradient energy for the given width -- there is no smoother way
    to get from nothing to everything across that many edge loops.

    Smoothstep over geodesic distance is NOT that field, and the difference is
    what the eye sees. A Dijkstra distance on an irregular mesh is itself rough
    vertex to vertex, and any function of a rough input is rough: measured on the
    reference character, the band between the eye and the brow came out with a
    weight gradient of 0.1014 per millimetre at p95 against 0.0747 before the
    repair, and the three steepest pairs all belonged to c_eye_offset -- a bone
    whose own field spans 97.61mm, so trimming it locally is exactly where a rough
    ramp shows up worst.
    """
    if not band:
        return {}
    neighbours = {}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        neighbours.setdefault(a, []).append(b)
        neighbours.setdefault(b, []).append(a)
    inside = set(core)
    middle = set(band) - inside
    value = {}
    for vertex in middle:
        value[vertex] = 0.5
    for _round in range(int(max(1, rounds))):
        shift = 0.0
        for vertex in middle:
            total = 0.0
            count = 0
            for other in neighbours.get(vertex, ()):
                if other in inside:
                    continue
                elif other in middle:
                    total += value[other]
                else:
                    total += 1.0
                count += 1
            # A vertex whose only neighbours are inside the core is pinned at 0.
            fresh = (total / count) if count else 0.0
            shift = max(shift, abs(fresh - value[vertex]))
            value[vertex] = fresh
        if shift < 1.0e-6:
            break
    return value


def _depth_inside(mesh_object, forbidden):
    """Millimetres from the region's boundary, along the mesh's own edges.

    Dijkstra outward from every vertex that is NOT in the region, so a vertex on
    the boundary comes back near zero and the middle of the region comes back
    large.
    """
    import heapq

    inside = set(forbidden)
    if not inside:
        return {}
    neighbours = {}
    coords = [v.co for v in mesh_object.data.vertices]
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        neighbours.setdefault(a, []).append(b)
        neighbours.setdefault(b, []).append(a)
    scale = mesh_object.matrix_world.to_scale()
    unit = (abs(scale.x) + abs(scale.y) + abs(scale.z)) / 3.0 * 1000.0
    best = {}
    heap = []
    for vertex in inside:
        for other in neighbours.get(vertex, ()):
            if other not in inside:
                step = (coords[vertex] - coords[other]).length * unit
                if step < best.get(vertex, 1.0e18):
                    best[vertex] = step
                    heapq.heappush(heap, (step, vertex))
                break
    while heap:
        distance, vertex = heapq.heappop(heap)
        if distance > best.get(vertex, 1.0e18) + 1.0e-9:
            continue
        for other in neighbours.get(vertex, ()):
            if other not in inside:
                continue
            step = distance + (coords[vertex] - coords[other]).length * unit
            if step < best.get(other, 1.0e18):
                best[other] = step
                heapq.heappush(heap, (step, other))
    # A region vertex with no path to the outside is fully interior.
    for vertex in inside:
        best.setdefault(vertex, 1.0e18)
    return best


def _ease(t):
    """Smoothstep. Zero slope at BOTH ends, which is the whole point.

    A linear ramp meets the fully-cleared core with a slope discontinuity, and a
    kink in the weight field is a crease in the deformed surface. Measured on the
    reference character with a linear ramp: the worst edge angle on the upper lip
    degraded by 94 degrees under an open jaw, against 8 degrees before the repair.
    """
    t = max(0.0, min(1.0, t))
    return t * t * (3.0 - 2.0 * t)


def audit(face, armature, brow_object=None, teeth_upper=None, teeth_lower=None,
          zones=None):
    """What each rule would touch, and how far each facial bone reaches.

    ``(report, error)``. Read this before and after :func:`trim`; the reach
    numbers are the ones the module's own docstring quotes.

    Pass the SAME ``zones`` to both calls. ``aperture_ring`` and ``lid_region``
    are derived from weights, so trimming moves the regions themselves: a second
    audit that recomputes them reports weight "left behind" on vertices that were
    not in the region when the trim ran. That is how 8 vertices came back holding
    c_nose_03.x at 0.64 after a pass that had cleared them.
    """
    from . import face_regions

    if zones is None:
        zones, error = regions(face, armature, brow_object, teeth_upper,
                               teeth_lower)
        if zones is None:
            return None, error
    groups = {g.name: g.index for g in face.vertex_groups}
    rows = []
    for rule in RULES:
        forbidden = zones.get(rule["forbid"]) or set()
        recipient = rule.get("donate_to")
        bones = [n for n in matching(armature, rule["bones"])
                 if n in groups and n != recipient]
        touched = 0
        total = 0.0
        worst = []
        for name in bones:
            index = groups[name]
            weight = 0.0
            count = 0
            for vertex_index in forbidden:
                for entry in face.data.vertices[vertex_index].groups:
                    if entry.group == index and entry.weight > EPSILON:
                        weight += entry.weight
                        count += 1
            if count:
                worst.append([name, count, round(weight, 3)])
                touched += count
                total += weight
        worst.sort(key=lambda r: -r[2])
        rows.append({"rule": rule["key"], "region": rule["forbid"],
                     "region_vertices": len(forbidden),
                     "bones_in_region": len(worst),
                     "vertex_bone_pairs": touched,
                     "weight_in_region": round(total, 3),
                     "worst": worst[:8]})
    reach = []
    for name in sorted(_deform_names(armature)):
        if not any(k in name for k in ("eyebrow", "eyelid", "nose", "cheek",
                                       "lips", "eye_offset", "c_eye.", "chin")):
            continue
        row, error = face_regions.bone_reach(face, armature, name)
        if error or not row or not row.get("weighted"):
            continue
        ratio = row.get("reach_over_sibling_spacing", row.get(
            "reach_over_length", 0.0))
        reach.append([name, row["weighted"], row["strong"],
                      round(row["reach_mm"], 2), round(ratio, 2)])
    reach.sort(key=lambda r: -r[4])
    return {"rules": rows, "reach": reach[:20],
            "region_sizes": {k: len(v) for k, v in sorted(zones.items())}}, ""


def _renormalise(face, armature, indices):
    """Put each of these vertices back on 1.0 over the main rig's deform bones."""
    from . import rig_hygiene

    report, error = rig_hygiene.normalise_deform(face, armature,
                                                 indices=sorted(indices))
    if error:
        return None, error
    return report.get("renormalised"), ""


def trim(face, armature, brow_object=None, teeth_upper=None, teeth_lower=None,
         taper_mm=TAPER_MM, rules=RULES, min_remaining=MIN_REMAINING,
         dry_run=False, zones=None, passes=1, strength=1.0, smooth_band=True,
         relax=4):
    """Pull each bone family back out of the region it does not belong in.

    ``(report, error)``. Weight is scaled down by how deep into the forbidden
    region the vertex sits -- unchanged at the boundary, gone by ``taper_mm`` --
    so no seam is introduced where a hard cut would leave one.
    """
    if face is None or face.type != "MESH":
        return None, "Select the face mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if zones is None:
        zones, error = regions(face, armature, brow_object, teeth_upper,
                               teeth_lower)
        if zones is None:
            return None, error
    if passes > 1:
        # A second pass catches what the first pass's normalise moved: a bone
        # whose weight was under EPSILON is not trimmed, and then gets scaled up
        # when its neighbours' shares are removed.
        reports = []
        for _index in range(int(passes)):
            report, error = trim(face, armature, brow_object, teeth_upper,
                                 teeth_lower, taper_mm=taper_mm, rules=rules,
                                 min_remaining=min_remaining, dry_run=dry_run,
                                 zones=zones, passes=1)
            if error:
                return report, error
            reports.append(report)
        merged = dict(reports[-1])
        merged["passes"] = [{"weight_removed": sum(
            r.get("weight_removed", 0.0) or 0.0 for r in rep["rules"]),
            "vertices_touched": rep["vertices_touched"]} for rep in reports]
        return merged, ""

    groups = {g.name: g for g in face.vertex_groups}
    main = _deform_names(armature)
    index_to_name = {g.index: g.name for g in face.vertex_groups}

    # Collect every intended change first. Nothing is written until the guards
    # have seen the whole picture for each vertex.
    factor_for = {}
    donate = {}
    bands = {}
    depths = {}
    per_rule = []
    for rule in rules:
        forbidden = zones.get(rule["forbid"]) or set()
        if not forbidden:
            per_rule.append({"rule": rule["key"], "skipped": "no region"})
            continue
        key = rule["forbid"]
        width = float(rule.get("taper_mm") or taper_mm)
        hard = bool(rule.get("hard_core"))
        protect = zones.get("brow") or set()
        if key not in depths:
            # How deep inside the region each of its own vertices sits. The factor
            # is built from a SIGNED field -- negative inside, positive outside --
            # so it varies smoothly THROUGH the region instead of being pinned at
            # zero and then jumping at the boundary.
            #
            # A hard core is what the user was seeing. Clearing the region outright
            # and ramping only outside leaves a step from 0 to (original weight x
            # the first ring's factor) across one edge: measured, 0.62 of weight
            # across 2.45mm between two neighbours, which is a visible kink in the
            # surface right where the brow meets the lid.
            depths[key] = _depth_inside(face, forbidden)
        depth = depths[key]
        deepest = max([v for v in depth.values() if v < 1.0e17] or [0.0])
        if key not in bands:
            # The region is cleared OUTRIGHT and the ramp lives OUTSIDE it. The
            # other way round -- tapering inward from the boundary -- leaves the
            # foreign bone in place wherever the region is thinner than the taper,
            # and the brow footprint is a 61-vertex band, so 87% of the weight
            # came off and the displacement still only halved.
            band = _spread(face, forbidden, width)
            # The brow's own vertices are shielded from the OTHER regions' bands,
            # because those bands grow outward and would otherwise scale a brow
            # bone inside the brow. The midline rules are exempt: a left-side bone
            # on a right-side brow vertex is exactly what they exist to remove,
            # and shielding the brow from them left the last of the crossing in
            # place -- c_eyebrow_01_end.l at 0.1184 on a vertex 9.3mm past the
            # centre line, which is why raising the left brow still moved the
            # right half of the face by 2.255mm.
            if rule.get("keep_brow", True) and key != "brow" and protect:
                # The band grows OUTWARD from the cleared region, so without this
                # a brow bone inside the band is still scaled by distance/taper --
                # an effective reach of the region plus the taper into the brow.
                band = {v: d for v, d in band.items() if v not in protect}
            bands[key] = band
        band = bands[key]
        bones = [n for n in matching(armature, rule["bones"]) if n in groups]
        suffix = rule.get("suffix")
        if suffix:
            bones = [n for n in bones if n.endswith(suffix)]
        recipient = rule.get("donate_to")
        pairs = 0
        removed = 0.0
        for name in bones:
            if name == recipient:
                continue
            group_index = groups[name].index
            for vertex_index, distance in band.items():
                for entry in face.data.vertices[vertex_index].groups:
                    if entry.group != group_index or entry.weight <= EPSILON:
                        continue
                    if vertex_index in forbidden:
                        if hard:
                            # The midline rules use a hard core on purpose. The
                            # step it leaves is bounded by what is removed, and
                            # across the centre line that is small -- the largest
                            # wrong-side weight measured was 0.1256 -- so the kink
                            # is negligible, where the same construction on the
                            # brow left a 0.62 step and was plainly visible.
                            factor = 0.0
                        else:
                            inside = depth.get(vertex_index, 0.0)
                            if inside > 1.0e17:
                                inside = deepest
                            # 0 at the deepest point of the region, rising toward
                            # its edge and on across the band outside it, so there
                            # is no step anywhere.
                            factor = _ease((deepest - inside)
                                           / max(deepest + width, 1.0e-6))
                    elif hard:
                        factor = _ease(distance / max(width, 1.0e-6))
                    else:
                        # Smoothstep over distance, NOT a harmonic field. A
                        # harmonic ramp minimises total gradient energy but, with a
                        # small protected region and a wide band, does so by rising
                        # FASTEST right at the core boundary -- measured, it left
                        # the first ring at 0.84 of its original weight, so the
                        # step barely changed. Minimum energy is not minimum step.
                        factor = _ease((deepest + distance)
                                       / max(deepest + width, 1.0e-6))
                    # strength below one leaves some of the influence in place,
                    # which is the knob that trades isolation for smoothness. Per
                    # rule, because they are not equally worth their cost: taking
                    # the lower lip's bones off the upper lip is nearly free,
                    # while holding the midline against the jaw fights a 20mm
                    # differential and creases the lip if pushed all the way.
                    force = rule.get("strength")
                    if force is None:
                        force = strength
                    factor = 1.0 - (1.0 - factor) * max(0.0, min(1.0, force))
                    slot = (vertex_index, name)
                    factor_for[slot] = min(factor_for.get(slot, 1.0), factor)
                    if recipient:
                        donate[vertex_index] = recipient
                    pairs += 1
                    removed += entry.weight * (1.0 - factor)
        per_rule.append({"rule": rule["key"], "region": rule["forbid"],
                         "taper_mm": width,
                         "region_vertices": len(forbidden),
                         "band_vertices": len(band),
                         "bones": len(bones),
                         "donate_to": recipient,
                         "vertex_bone_pairs": pairs,
                         "weight_removed": round(removed, 3)})

    # What every touched bone held before anything was written, so the report can
    # say which bones the normalise made FATTER. A displacement gate cannot see
    # that, and it is how c_lips_top_01's reach grew from 21.89mm to 27.95mm.
    original = {}
    for (vertex_index, _name) in factor_for:
        for entry in face.data.vertices[vertex_index].groups:
            name = index_to_name.get(entry.group)
            if name in main:
                original[(vertex_index, name)] = entry.weight

    # Guard: never strip a vertex bare.
    by_vertex = {}
    for (vertex_index, name), factor in factor_for.items():
        by_vertex.setdefault(vertex_index, {})[name] = factor
    abandoned = []
    for vertex_index, plan in list(by_vertex.items()):
        before = 0.0
        after = 0.0
        for entry in face.data.vertices[vertex_index].groups:
            name = index_to_name.get(entry.group)
            if name not in main:
                continue
            before += entry.weight
            after += entry.weight * plan.get(name, 1.0)
        if before > 0.0 and after < min_remaining * before:
            abandoned.append([vertex_index, round(before, 4), round(after, 4)])
            del by_vertex[vertex_index]

    report = {"rules": per_rule, "taper_mm": taper_mm,
              "vertices_touched": len(by_vertex),
              "abandoned_to_keep_a_bone": abandoned[:20],
              "abandoned_count": len(abandoned)}
    if dry_run:
        return report, ""

    # Write, then normalise once.
    for vertex_index, plan in by_vertex.items():
        for name, factor in plan.items():
            group = groups[name]
            current = 0.0
            for entry in face.data.vertices[vertex_index].groups:
                if entry.group == group.index:
                    current = entry.weight
                    break
            new = current * factor
            if new <= EPSILON:
                group.remove([vertex_index])
            else:
                group.add([vertex_index], new, "REPLACE")

    # Scale the UNTRIMMED bones only, or hand the freed weight to the bone the
    # rule names. Including the trimmed ones puts part of what was just removed
    # straight back -- a bone cut to half came back at 0.176 of the original on a
    # vertex whose remainder was 0.85 -- and it also inflates the reach of
    # whichever bone is left, which was measured: c_lips_top_01 went from 21.89mm
    # of reach to 27.95mm.
    renormalised = 0
    donated = 0
    stuck = []
    rebalanced = []
    relaxed_back = []
    relaxed_back = 0
    worst_before = 0.0
    for vertex_index, plan in by_vertex.items():
        recipient = donate.get(vertex_index)
        if recipient is not None and recipient not in groups:
            groups[recipient] = face.vertex_groups.new(name=recipient)
            index_to_name[groups[recipient].index] = recipient
        trimmed = 0.0
        loose = 0.0
        for entry in face.data.vertices[vertex_index].groups:
            name = index_to_name.get(entry.group)
            if name not in main:
                continue
            if name in plan:
                trimmed += entry.weight
            else:
                loose += entry.weight
        total = trimmed + loose
        if total <= 1.0e-6:
            continue
        worst_before = max(worst_before, abs(1.0 - total))
        headroom = 1.0 - trimmed
        needed = 1.0 - total
        if recipient is not None and recipient in main and needed > 1.0e-9:
            current = 0.0
            for entry in face.data.vertices[vertex_index].groups:
                if entry.group == groups[recipient].index:
                    current = entry.weight
                    break
            # Everything the trims freed goes to the named bone and the untrimmed
            # ones keep exactly the share they already had, so the vertex lands on
            # 1.0 without anything being scaled up.
            groups[recipient].add([vertex_index], current + needed, "REPLACE")
            donated += 1
            continue
        # Hand the freed weight to the untrimmed bones, but no bone may gain more
        # than MAX_GAIN, and a bone that held almost nothing is not a candidate at
        # all -- it was not carrying this vertex before and inflating it to carry
        # it now is what produces the checkerboard.
        if headroom > 1.0e-6 and loose > 1.0e-6:
            rows = []
            for entry in face.data.vertices[vertex_index].groups:
                name = index_to_name.get(entry.group)
                if name in main and name not in plan                         and entry.weight >= CANDIDATE_FLOOR:
                    rows.append((name, entry.weight))
            share = sum(weight for _n, weight in rows)
            want = headroom - loose
            if rows and share > 1.0e-9 and want > 1.0e-9:
                placed = 0.0
                for name, weight in rows:
                    give = min(want * (weight / share), MAX_GAIN)
                    if give <= 0.0:
                        continue
                    groups[name].add([vertex_index], weight + give, "REPLACE")
                    placed += give
                left = want - placed
                if left > 1.0e-6:
                    # Nowhere safe to put the rest, so the trim on this vertex is
                    # relaxed by exactly that much instead of distorting a
                    # neighbouring bone. Isolation gives way to smoothness here,
                    # which is the right way round.
                    back = 0.0
                    for entry in face.data.vertices[vertex_index].groups:
                        name = index_to_name.get(entry.group)
                        if name in main and name in plan:
                            back += entry.weight
                    if back > 1.0e-9:
                        scale = (back + left) / back
                        for entry in list(
                                face.data.vertices[vertex_index].groups):
                            name = index_to_name.get(entry.group)
                            if name in main and name in plan:
                                groups[name].add([vertex_index],
                                                 entry.weight * scale,
                                                 "REPLACE")
                        relaxed_back += 1
                    else:
                        stuck.append([vertex_index, round(trimmed, 4),
                                      round(loose, 4)])
                renormalised += 1
                continue

        if headroom <= 1.0e-6 or loose <= 1.0e-6:
            # Every bone on this vertex was trimmed, so there is no untrimmed one
            # to grow into. Leaving it short is not an option -- a vertex whose
            # main-rig weights do not sum to one is pulled toward its rest
            # position, which is tens of millimetres of lag on any head turn, and
            # 18 vertices came back like that. The trimmed bones are scaled back
            # to one instead, which keeps the RELATIVE rebalancing the rules asked
            # for and gives up only the absolute reduction on these few vertices.
            stuck.append([vertex_index, round(trimmed, 4), round(loose, 4)])
            if trimmed > 1.0e-6:
                for entry in list(face.data.vertices[vertex_index].groups):
                    name = index_to_name.get(entry.group)
                    if name not in main or name not in plan:
                        continue
                    groups[name].add([vertex_index], entry.weight / trimmed,
                                     "REPLACE")
                rebalanced.append(vertex_index)
            continue
        factor = headroom / loose
        for entry in list(face.data.vertices[vertex_index].groups):
            name = index_to_name.get(entry.group)
            if name not in main or name in plan:
                continue
            groups[name].add([vertex_index], entry.weight * factor, "REPLACE")
        renormalised += 1
    report["donated"] = donated
    gains = {}
    for vertex_index in by_vertex:
        for entry in face.data.vertices[vertex_index].groups:
            name = index_to_name.get(entry.group)
            if name not in main:
                continue
            grew = entry.weight - original.get((vertex_index, name), 0.0)
            if grew > gains.get(name, 0.0):
                gains[name] = grew
    if smooth_band and relax:
        # Smooth ONLY the bones that are allowed to be here, and leave the trimmed
        # ones exactly as they were set. Smoothing everything is what broke the
        # rig the first time: the lid's own weights got averaged away with the
        # rest and the eye stopped closing (102% shut down to 12.5%), while the
        # brow control lost 62% of its throw.
        #
        # This step exists because the wide falloff was load-bearing for
        # SMOOTHNESS as well as for the crosstalk. Take a lid bone's broad, gentle
        # influence out of the brow and what is left is four 4.9mm brow bones
        # whose individual footprints read as facets -- measured, the brow's worst
        # edge angle degraded 68.9 degrees where it had degraded 20.9 before.
        field = set(by_vertex)
        trimmed_names = {name for (_v, name) in factor_for}
        present = set()
        for vertex_index in field:
            for entry in face.data.vertices[vertex_index].groups:
                name = index_to_name.get(entry.group)
                if name in main and name not in trimmed_names                         and entry.weight > EPSILON:
                    present.add(name)
        if field and present:
            from . import costume_bind
            result, error = costume_bind.smooth_groups(
                face, field, sorted(present), factor=0.5,
                repeat=int(max(1, relax)))
            report["smoothed_groups"] = error or result.get("groups")
            report["smoothed_vertices"] = len(field)
            report["left_alone"] = sorted(trimmed_names)[:12]
            fixed, error = _renormalise(face, armature, field)
            report["resmoothed_renormalised"] = error or fixed

    report["largest_weight_gain_per_bone"] = sorted(
        ([n, round(v, 4)] for n, v in gains.items() if v > 0.001),
        key=lambda r: -r[1])[:12]
    report["renormalised"] = renormalised
    report["no_untrimmed_bone_to_grow_into"] = stuck[:20]
    report["stuck_count"] = len(stuck)
    report["rebalanced_without_headroom"] = len(rebalanced)
    report["trim_relaxed_for_smoothness"] = relaxed_back
    report["worst_sum_error_before_normalise"] = round(worst_before, 5)
    face.data.update()
    return report, ""


def _capped_normalise(mesh_object, armature, touched, trimmed_names,
                      max_gain=MAX_GAIN, floor=CANDIDATE_FLOOR,
                      fallback=None, neighbours=None, ceiling=None):
    """Put each touched vertex back on 1.0 without inflating a negligible bone.

    ``(report, error)``. The freed weight is offered in this order:

      1. bones that were ALREADY carrying the vertex, none gaining more than
         ``max_gain`` -- dividing the freed weight by whatever untrimmed weight
         happens to be left is what produced the juddering: measured,
         c_eye_offset.l went from 0.0001 to 0.5648 on one vertex while its four
         neighbours stayed near zero, because the multiplier there was five
         thousand, and which bones are negligible varies vertex to vertex, so the
         field comes out as a checkerboard;
      2. the average of what the NEIGHBOURS still carry, seeded from zero. A
         vertex whose only weight was the trimmed bone has nothing to scale up,
         and the neighbourhood average has no edge in it, because it IS what the
         neighbours do. Measured, 96 vertices around the eye had eyelid weight and
         nothing else;
      3. back to the trimmed bones, which yields isolation to smoothness;
      4. ``fallback``.

    Step 2 has to come before step 3, and ``ceiling`` is why. Giving back scales
    the trimmed bones by ``(trimmed + left) / trimmed``, and in a taper band that
    can hand a bone MORE than it had before the trim -- with carriers holding
    ~0.2, max_gain 0.15 and an eye family holding 0.6-0.9, the factor reaches 1.75,
    so the cheek would come out following the eyelid harder than it did to start
    with and plane_trim would still report success. ``ceiling`` is the weight the
    limits allow, per (vertex, bone), and nothing here may exceed it.
    """
    deform = {b.name for b in armature.data.bones if b.use_deform}
    groups = {g.name: g for g in mesh_object.vertex_groups}
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}
    ceiling = ceiling or {}
    worst_gain = {}
    given_back = 0
    short = []
    used_fallback = []
    borrowed_from = []
    for vertex_index in sorted(touched):
        rows = []
        trimmed = []
        for entry in mesh_object.data.vertices[vertex_index].groups:
            name = by_index.get(entry.group)
            if name not in deform:
                continue
            if name in trimmed_names:
                trimmed.append([name, entry.weight])
            else:
                rows.append([name, entry.weight])
        total = sum(w for _n, w in rows) + sum(w for _n, w in trimmed)
        if total <= 1.0e-9:
            short.append(vertex_index)
            continue
        want = 1.0 - total
        if want <= 1.0e-9:
            continue

        carrying = [(n, w) for n, w in rows if w >= floor]
        share = sum(w for _n, w in carrying)
        placed = 0.0
        if carrying and share > 1.0e-9:
            for name, weight in carrying:
                give = min(want * (weight / share), max_gain)
                if give <= 0.0:
                    continue
                groups[name].add([vertex_index], weight + give, "REPLACE")
                placed += give
                if give > worst_gain.get(name, 0.0):
                    worst_gain[name] = give
        left = want - placed

        if left > 1.0e-6 and neighbours is not None:
            borrowed = {}
            seen = 0
            for other in neighbours.get(vertex_index, ()):
                near = {}
                for entry in mesh_object.data.vertices[other].groups:
                    name = by_index.get(entry.group)
                    if name in deform and name not in trimmed_names:
                        near[name] = entry.weight
                scale = sum(near.values())
                if scale <= 1.0e-9:
                    continue
                seen += 1
                for name, weight in near.items():
                    borrowed[name] = borrowed.get(name, 0.0) + weight / scale
            if seen:
                stock = sum(borrowed.values())
                for name, weight in borrowed.items():
                    if name not in groups:
                        continue
                    current = 0.0
                    for entry in mesh_object.data.vertices[vertex_index].groups:
                        if entry.group == groups[name].index:
                            current = entry.weight
                            break
                    groups[name].add([vertex_index],
                                     current + left * weight / stock, "REPLACE")
                borrowed_from.append(vertex_index)
                left = 0.0

        if left > 1.0e-6 and trimmed:
            room = 0.0
            for name, weight in trimmed:
                cap = ceiling.get((vertex_index, name))
                room += (weight if cap is None else max(0.0, cap - weight))
            if room > 1.0e-9:
                portion = min(1.0, left / room)
                for name, weight in trimmed:
                    cap = ceiling.get((vertex_index, name))
                    head_room = weight if cap is None else max(0.0, cap - weight)
                    groups[name].add([vertex_index],
                                     weight + head_room * portion, "REPLACE")
                given_back += 1
                left -= room * portion

        if left > 1.0e-6 and fallback and fallback in groups:
            # Last resort, and it must exist: a vertex whose main-rig weights do
            # not sum to one is dragged toward its rest position, which is tens of
            # millimetres of lag the moment the head turns.
            current = 0.0
            for entry in mesh_object.data.vertices[vertex_index].groups:
                if entry.group == groups[fallback].index:
                    current = entry.weight
                    break
            groups[fallback].add([vertex_index], current + left, "REPLACE")
            used_fallback.append(vertex_index)
        elif left > 1.0e-6:
            short.append(vertex_index)
    mesh_object.data.update()
    return {"vertices": len(touched), "given_back": given_back,
            "still_short": len(short), "fallback_used": len(used_fallback),
            "borrowed_from_neighbours": len(borrowed_from),
            "largest_gain": sorted(([n, round(v, 4)]
                                    for n, v in worst_gain.items()),
                                   key=lambda r: -r[1])[:8]}, ""


def plane_trim(mesh_object, armature, limits, epsilon=EPSILON,
               fallback="head.x"):
    """Stop a bone influencing anything past a plane. ``(report, error)``.

    Each entry of ``limits`` is a dict:

        bones      tuple of name prefixes the limit applies to
        kind       "plane", "side" or "rings"
        axis       0 for X, 2 for Z (plane and rings)
        at         the boundary, in metres of world space (plane and rings)
        keep       "below" or "above" -- which side the bone may act on
        taper_mm   how far back from the boundary the influence recovers
        side       optional ".l"/".r": only bones whose name ends that way
        seeds      rings only: the loop the allowance is counted from
        full       rings only: hops the bone keeps its whole weight for
        fade       rings only: hops the weight takes to reach zero after that
        smooth     rings only: rounds of averaging on the hop field (default 3)

    ``kind="rings"`` is the loop-count case: past ``full`` loops from ``seeds`` the
    bone fades out and past ``full + fade`` it is gone. With ``axis`` and ``keep``
    the allowance only bites in one direction -- measured against the height of the
    SEED the walk came from, not against a fixed plane, so it follows the loop round
    its corners instead of cutting a horizontal band across it -- fading in over
    ``taper_mm``. Omit ``axis`` and the loop count applies in every direction, which
    is the right form for a cap that only has to remove the far strays. The field is
    averaged rather than the raw integer hop count for the reason given in
    ``_hop_field``.

    ``kind="side"`` is the mirror case: a bone whose name ends ``.l`` may only act
    where world X is positive, and ``.r`` where it is negative, with the taper
    measured from the midline.

    The factor is a smoothstep of a COORDINATE, so it is an analytic function of
    position: no geodesic distance, no per-vertex roughness, and exactly zero past
    the plane rather than nearly zero. That last part matters -- the requirement
    here is no influence at all, not a small influence.

    A plane also has ONE boundary. A band-shaped region has two, and the outer one
    is a step: measured on the reference character, a region cleared outright left
    0.62 of weight jumping across 2.45mm at its far edge, which is the crease that
    showed up between the eye and the brow.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    groups = {g.name: g for g in mesh_object.vertex_groups}
    matrix = mesh_object.matrix_world
    world = [matrix @ v.co for v in mesh_object.data.vertices]

    def mirror(name):
        if name.endswith(".l"):
            return name[:-2] + ".r"
        if name.endswith(".r"):
            return name[:-2] + ".l"
        return None

    factor_for = {}
    hand_to = {}
    pending = []
    rows = []
    for limit in limits:
        names = [n for n in sorted(deform)
                 if any(n.startswith(p) for p in limit["bones"])
                 and n in groups]
        if limit.get("side"):
            names = [n for n in names if n.endswith(limit["side"])]
        field = origin = None
        if limit["kind"] == "rings":
            field, origin = _hop_field(mesh_object, limit["seeds"],
                                       smooth=limit.get("smooth", 3))
            full = float(limit.get("full", 4.0))
            fade = max(float(limit.get("fade", 2.0)), 1.0e-6)
        touched = 0
        removed = 0.0
        for name in names:
            if limit["kind"] == "side":
                if name.endswith(".l"):
                    axis, keep, at = 0, "above", 0.0
                elif name.endswith(".r"):
                    axis, keep, at = 0, "below", 0.0
                else:
                    continue
            elif limit["kind"] == "rings":
                axis = limit.get("axis")
                keep = limit.get("keep", "below")
                at = None
            else:
                axis = limit["axis"]
                keep = limit["keep"]
                at = limit["at"]
            taper = max(float(limit["taper_mm"]) * 0.001, 1.0e-6)
            index = groups[name].index
            for vertex in mesh_object.data.vertices:
                weight = 0.0
                for entry in vertex.groups:
                    if entry.group == index:
                        weight = entry.weight
                        break
                if weight <= epsilon:
                    continue
                if limit["kind"] == "rings":
                    # The direction is the gate, not the cut: it says WHERE the
                    # loop count applies and fades that in, so the eye corner -- a
                    # vertex several loops away but level with the ring -- does not
                    # sit on a step between one rule and none. The reference is the
                    # seed the walk came from, so "below" bends with the loop.
                    if axis is None:
                        gate = 1.0
                    else:
                        seed = origin.get(vertex.index)
                        if seed is None:
                            gate = 1.0
                        else:
                            value = world[vertex.index][axis]
                            base = world[seed][axis]
                            inside = (base - value) if keep == "below" \
                                else (value - base)
                            gate = _ease(inside / taper) if inside > 0.0 else 0.0
                    hop = field.get(vertex.index)
                    if hop is None:
                        allowance = 0.0
                    elif hop <= full:
                        allowance = 1.0
                    elif hop < full + fade:
                        allowance = _ease((full + fade - hop) / fade)
                    else:
                        allowance = 0.0
                    factor = 1.0 - gate * (1.0 - allowance)
                else:
                    value = world[vertex.index][axis]
                    inside = (at - value) if keep == "below" else (value - at)
                    factor = _ease(inside / taper) if inside > 0.0 else 0.0
                if factor >= 1.0:
                    continue
                slot = (vertex.index, name)
                factor_for[slot] = min(factor_for.get(slot, 1.0), factor)
                touched += 1
                removed += weight * (1.0 - factor)
                if limit["kind"] == "side":
                    # Recorded, not applied: whether the mirror bone may actually
                    # take this weight depends on the OTHER limits, and those are
                    # not all known yet.
                    pending.append((vertex.index, name, mirror(name),
                                    weight * (1.0 - factor)))
        rows.append({"limit": limit["key"], "bones": len(names),
                     "vertex_bone_pairs": touched,
                     "weight_removed": round(removed, 3)})

    allowed = {}
    for (vertex_index, name), factor in factor_for.items():
        group = groups[name]
        current = 0.0
        for entry in mesh_object.data.vertices[vertex_index].groups:
            if entry.group == group.index:
                current = entry.weight
                break
        new = current * factor
        # What the limits allow here. Recorded so the normalise pass cannot hand
        # any of it back: past the allowance the answer is zero, not "less".
        allowed[(vertex_index, name)] = new
        if new <= epsilon:
            group.remove([vertex_index])
        else:
            group.add([vertex_index], new, "REPLACE")

    # The right side's skin belongs to the right side's bone, so the mirror is
    # the natural recipient -- 49 vertices near the midline had nothing BUT the
    # wrong side's bones, and clearing those left them unweighted, which drags a
    # vertex to its rest position.
    #
    # But the mirror may be forbidden here too, and then the hand-over silently
    # undoes the trim. Two ways that happened, both measured: at a midline vertex
    # both sides are trimmed and each donates to the other, so they swap and
    # nothing changes; and above the brow line c_eye_offset.r's trimmed weight was
    # handed to c_eye_offset.l, putting 0.3603 back exactly where the requirement
    # is zero.
    for vertex_index, name, twin, amount in pending:
        if not twin or twin not in groups or twin not in deform:
            continue
        if factor_for.get((vertex_index, twin), 1.0) < 1.0:
            continue
        key = (vertex_index, twin)
        hand_to[key] = hand_to.get(key, 0.0) + amount

    for (vertex_index, twin), amount in hand_to.items():
        if amount <= epsilon:
            continue
        group = groups[twin]
        current = 0.0
        for entry in mesh_object.data.vertices[vertex_index].groups:
            if entry.group == group.index:
                current = entry.weight
                break
        group.add([vertex_index], min(1.0, current + amount), "REPLACE")

    touched_vertices = {v for v, _n in factor_for}
    trimmed_names = {n for _v, n in factor_for}
    balance, error = _capped_normalise(mesh_object, armature, touched_vertices,
                                      trimmed_names, fallback=fallback,
                                      neighbours=_neighbours(mesh_object),
                                      ceiling=allowed)
    return {"mesh": mesh_object.name, "limits": rows,
            "handed_to_mirror": len(hand_to),
            "vertices_touched": len(touched_vertices),
            "bones_trimmed": len(trimmed_names),
            "normalise": error or balance}, ""


