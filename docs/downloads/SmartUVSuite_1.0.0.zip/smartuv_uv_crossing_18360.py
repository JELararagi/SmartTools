# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Exact UV Editor crossing-selection engine for Smart UV Suite.

The geometry section is pure Python over plain data so it can be verified
without Blender.  Box gestures retain Blender's native ``uv.select_box``
modal presentation and contained-element result, then add only the eligible
UV-space segments or faces that intersect the box.  Circle and lasso retain
their existing exact SmartUV transactions.  Only the Image/UV Editor
participates; no 3D View event is read or intercepted.
"""
from __future__ import annotations

from typing import Any, Iterable, Sequence

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - static tooling
    bpy = None  # type: ignore

SU_EPSILON = 1e-9
UV_CROSS_GESTURE_ID = "smart_uv_suite.uv_crossing_gesture"

# ---------------------------------------------------------------------------
# Pure UV-space geometry.  Shapes:
#   ("BOX", (xmin, ymin, xmax, ymax))
#   ("CIRCLE", (cx, cy, radius))
#   ("LASSO", ((x, y), (x, y), ...))   closed polygon, even-odd winding
# ---------------------------------------------------------------------------


def su_point_in_rect(point: Sequence[float], rect: Sequence[float]) -> bool:
    x, y = float(point[0]), float(point[1])
    xmin, ymin, xmax, ymax = (float(v) for v in rect)
    return (xmin - SU_EPSILON) <= x <= (xmax + SU_EPSILON) and (ymin - SU_EPSILON) <= y <= (ymax + SU_EPSILON)


def su_point_in_circle(point: Sequence[float], circle: Sequence[float]) -> bool:
    dx = float(point[0]) - float(circle[0])
    dy = float(point[1]) - float(circle[1])
    r = float(circle[2])
    return (dx * dx + dy * dy) <= (r * r + SU_EPSILON)


def su_point_in_polygon(point: Sequence[float], polygon: Sequence[Sequence[float]]) -> bool:
    # Even-odd winding.
    x, y = float(point[0]), float(point[1])
    inside = False
    count = len(polygon)
    if count < 3:
        return False
    j = count - 1
    for i in range(count):
        xi, yi = float(polygon[i][0]), float(polygon[i][1])
        xj, yj = float(polygon[j][0]), float(polygon[j][1])
        if (yi > y) != (yj > y):
            slope_x = (xj - xi) * (y - yi) / ((yj - yi) or SU_EPSILON) + xi
            if x < slope_x:
                inside = not inside
        j = i
    return inside


def _orient(a: Sequence[float], b: Sequence[float], c: Sequence[float]) -> float:
    return (float(b[0]) - float(a[0])) * (float(c[1]) - float(a[1])) - (float(b[1]) - float(a[1])) * (float(c[0]) - float(a[0]))


def _on_segment(a: Sequence[float], b: Sequence[float], p: Sequence[float]) -> bool:
    return (
        min(float(a[0]), float(b[0])) - SU_EPSILON <= float(p[0]) <= max(float(a[0]), float(b[0])) + SU_EPSILON
        and min(float(a[1]), float(b[1])) - SU_EPSILON <= float(p[1]) <= max(float(a[1]), float(b[1])) + SU_EPSILON
    )


def su_segments_intersect(a: Sequence[float], b: Sequence[float], c: Sequence[float], d: Sequence[float]) -> bool:
    o1 = _orient(a, b, c)
    o2 = _orient(a, b, d)
    o3 = _orient(c, d, a)
    o4 = _orient(c, d, b)
    if ((o1 > SU_EPSILON and o2 < -SU_EPSILON) or (o1 < -SU_EPSILON and o2 > SU_EPSILON)) and (
        (o3 > SU_EPSILON and o4 < -SU_EPSILON) or (o3 < -SU_EPSILON and o4 > SU_EPSILON)
    ):
        return True
    if abs(o1) <= SU_EPSILON and _on_segment(a, b, c):
        return True
    if abs(o2) <= SU_EPSILON and _on_segment(a, b, d):
        return True
    if abs(o3) <= SU_EPSILON and _on_segment(c, d, a):
        return True
    if abs(o4) <= SU_EPSILON and _on_segment(c, d, b):
        return True
    return False


def _rect_corners(rect: Sequence[float]) -> tuple[tuple[float, float], ...]:
    xmin, ymin, xmax, ymax = (float(v) for v in rect)
    return ((xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax))


def su_segment_intersects_rect(a: Sequence[float], b: Sequence[float], rect: Sequence[float]) -> bool:
    if su_point_in_rect(a, rect) or su_point_in_rect(b, rect):
        return True
    corners = _rect_corners(rect)
    for i in range(4):
        if su_segments_intersect(a, b, corners[i], corners[(i + 1) % 4]):
            return True
    return False


def su_segment_intersects_circle(a: Sequence[float], b: Sequence[float], circle: Sequence[float]) -> bool:
    if su_point_in_circle(a, circle) or su_point_in_circle(b, circle):
        return True
    ax, ay = float(a[0]), float(a[1])
    bx, by = float(b[0]), float(b[1])
    cx, cy, r = float(circle[0]), float(circle[1]), float(circle[2])
    dx, dy = bx - ax, by - ay
    length_sq = dx * dx + dy * dy
    if length_sq <= SU_EPSILON:
        return su_point_in_circle(a, circle)
    t = ((cx - ax) * dx + (cy - ay) * dy) / length_sq
    t = max(0.0, min(1.0, t))
    px, py = ax + t * dx, ay + t * dy
    ddx, ddy = px - cx, py - cy
    return (ddx * ddx + ddy * ddy) <= (r * r + SU_EPSILON)


def su_segment_intersects_polygon(a: Sequence[float], b: Sequence[float], polygon: Sequence[Sequence[float]]) -> bool:
    count = len(polygon)
    if count < 3:
        return False
    if su_point_in_polygon(a, polygon) or su_point_in_polygon(b, polygon):
        return True
    for i in range(count):
        if su_segments_intersect(a, b, polygon[i], polygon[(i + 1) % count]):
            return True
    return False


def su_segment_intersects_shape(a: Sequence[float], b: Sequence[float], shape: tuple[str, Any]) -> bool:
    kind, data = shape
    if kind == "BOX":
        return su_segment_intersects_rect(a, b, data)
    if kind == "CIRCLE":
        return su_segment_intersects_circle(a, b, data)
    if kind == "LASSO":
        return su_segment_intersects_polygon(a, b, data)
    return False


def su_point_in_shape(point: Sequence[float], shape: tuple[str, Any]) -> bool:
    kind, data = shape
    if kind == "BOX":
        return su_point_in_rect(point, data)
    if kind == "CIRCLE":
        return su_point_in_circle(point, data)
    if kind == "LASSO":
        return su_point_in_polygon(point, data)
    return False


def _shape_sample_points(shape: tuple[str, Any]) -> tuple[tuple[float, float], ...]:
    kind, data = shape
    if kind == "BOX":
        return _rect_corners(data)
    if kind == "CIRCLE":
        return ((float(data[0]), float(data[1])),)
    if kind == "LASSO":
        return tuple((float(p[0]), float(p[1])) for p in data)
    return ()


def su_polygon_intersects_shape(polygon: Sequence[Sequence[float]], shape: tuple[str, Any]) -> bool:
    """Face polygon vs gesture shape: any face point inside the shape, any
    shape point inside the face polygon, or any boundary crossing."""
    count = len(polygon)
    if count == 0:
        return False
    for point in polygon:
        if su_point_in_shape(point, shape):
            return True
    if count >= 3:
        for sample in _shape_sample_points(shape):
            if su_point_in_polygon(sample, polygon):
                return True
    for i in range(count):
        if su_segment_intersects_shape(polygon[i], polygon[(i + 1) % count], shape):
            return True
    return False


def su_polygon_intersects_rect(polygon: Sequence[Sequence[float]], rect: Sequence[float]) -> bool:
    return su_polygon_intersects_shape(polygon, ("BOX", tuple(rect)))


def su_polygon_intersects_circle(polygon: Sequence[Sequence[float]], circle: Sequence[float]) -> bool:
    return su_polygon_intersects_shape(polygon, ("CIRCLE", tuple(circle)))


def su_polygon_intersects_polygon(polygon: Sequence[Sequence[float]], lasso: Sequence[Sequence[float]]) -> bool:
    return su_polygon_intersects_shape(polygon, ("LASSO", tuple(tuple(p) for p in lasso)))


def su_normalize_box(a: Sequence[float], b: Sequence[float], *, point_tolerance: float = 0.0) -> tuple[str, tuple[float, float, float, float]]:
    """Axis-aligned box from two corners.  A degenerate box falls back to a
    point-tolerance box so a click still hits stable geometry."""
    xmin, xmax = sorted((float(a[0]), float(b[0])))
    ymin, ymax = sorted((float(a[1]), float(b[1])))
    tol = max(0.0, float(point_tolerance))
    if (xmax - xmin) <= SU_EPSILON and (ymax - ymin) <= SU_EPSILON:
        xmin -= tol
        xmax += tol
        ymin -= tol
        ymax += tol
    return ("BOX", (xmin, ymin, xmax, ymax))


def su_compute_crossing(
    primitives: dict[str, Any],
    shape: tuple[str, Any],
    *,
    select_verts: bool = True,
    select_edges: bool = True,
    select_faces: bool = True,
) -> dict[str, set]:
    """Exact crossing sets over plain data.

    ``primitives`` is ``{"verts": {vid: (u, v)}, "edges": {eid: (vid_a, vid_b)},
    "faces": {fid: (vid, vid, ...)}}``.  A vertex crosses when its point is
    inside the shape.  An edge crosses when either endpoint is inside or the
    segment intersects the shape boundary.  A face crosses when any face point
    is inside the shape, any shape point is inside the face polygon, or any
    boundary segments intersect.
    """
    verts: dict[Any, Sequence[float]] = dict(primitives.get("verts", {}) or {})
    edges: dict[Any, Sequence[Any]] = dict(primitives.get("edges", {}) or {})
    faces: dict[Any, Sequence[Any]] = dict(primitives.get("faces", {}) or {})
    hit_verts: set = set()
    hit_edges: set = set()
    hit_faces: set = set()
    if select_verts:
        for vid, uv in verts.items():
            if uv is not None and su_point_in_shape(uv, shape):
                hit_verts.add(vid)
    if select_edges:
        for eid, (va, vb) in edges.items():
            uva = verts.get(va)
            uvb = verts.get(vb)
            if uva is None or uvb is None:
                continue
            if su_segment_intersects_shape(uva, uvb, shape):
                hit_edges.add(eid)
    if select_faces:
        for fid, vids in faces.items():
            polygon = [verts[vid] for vid in vids if verts.get(vid) is not None]
            if len(polygon) >= 3 and su_polygon_intersects_shape(polygon, shape):
                hit_faces.add(fid)
    return {"verts": hit_verts, "edges": hit_edges, "faces": hit_faces}


def su_compute_contained(
    primitives: dict[str, Any],
    shape: tuple[str, Any],
    *,
    select_verts: bool = True,
    select_edges: bool = True,
    select_faces: bool = True,
) -> dict[str, set]:
    """Elements selected by Blender's ordinary full-containment predicate.

    This is deliberately separate from :func:`su_compute_crossing`: the
    native box operator remains authoritative for the contained selection and
    this set is used only to isolate the additional intersection hits.
    """
    verts: dict[Any, Sequence[float]] = dict(primitives.get("verts", {}) or {})
    edges: dict[Any, Sequence[Any]] = dict(primitives.get("edges", {}) or {})
    faces: dict[Any, Sequence[Any]] = dict(primitives.get("faces", {}) or {})
    hit_verts: set = set()
    hit_edges: set = set()
    hit_faces: set = set()
    if select_verts:
        hit_verts = {vid for vid, uv in verts.items() if uv is not None and su_point_in_shape(uv, shape)}
    if select_edges:
        for eid, (va, vb) in edges.items():
            uva = verts.get(va)
            uvb = verts.get(vb)
            if uva is not None and uvb is not None and su_point_in_shape(uva, shape) and su_point_in_shape(uvb, shape):
                hit_edges.add(eid)
    if select_faces:
        for fid, vids in faces.items():
            polygon = [verts[vid] for vid in vids if verts.get(vid) is not None]
            if len(polygon) >= 3 and all(su_point_in_shape(point, shape) for point in polygon):
                hit_faces.add(fid)
    return {"verts": hit_verts, "edges": hit_edges, "faces": hit_faces}


def su_apply_selection_op(snapshot: Iterable[Any], crossing: Iterable[Any], op: str) -> set:
    """Exact selection transaction semantics relative to the pre-gesture
    snapshot: REPLACE, ADD, SUBTRACT or XOR."""
    base = set(snapshot)
    hits = set(crossing)
    mode = str(op or "REPLACE").upper()
    if mode == "ADD":
        return base | hits
    if mode == "SUBTRACT":
        return base - hits
    if mode == "XOR":
        return base ^ hits
    return hits


def su_selection_op_from_modifiers(*, shift: bool, ctrl: bool) -> str:
    if shift and ctrl:
        return "XOR"
    if shift:
        return "ADD"
    if ctrl:
        return "SUBTRACT"
    return "REPLACE"


# ---------------------------------------------------------------------------
# Blender gesture operator.
# ---------------------------------------------------------------------------


def _tr_report(template: str) -> str:
    try:
        translations = getattr(getattr(bpy, "app", None), "translations", None)
        fn = getattr(translations, "pgettext_report", None) or getattr(translations, "pgettext", None)
        if callable(fn):
            return str(fn(template))
    except Exception:
        pass
    return template


def _loop_uv_selected(loop: Any, luv: Any, *, edge: bool = False) -> bool:
    """Read one live UV loop flag.

    Blender 5.1 exposes ``.uv_select_vert`` / ``.uv_select_edge`` through
    BMLoop; the writable ``BMLoopUV.select`` members no longer exist there, so
    they are only consulted when the live API itself is unavailable."""
    live_name = "uv_select_edge" if edge else "uv_select_vert"
    legacy_name = "select_edge" if edge else "select"
    try:
        return bool(getattr(loop, live_name))
    except Exception:
        try:
            return bool(getattr(luv, legacy_name))
        except Exception:
            return False


def _set_loop_uv_selected(loop: Any, luv: Any, value: bool, *, edge: bool = False) -> bool:
    """Write one live UV loop flag without creating hidden mesh attributes."""
    value = bool(value)
    live_name = "uv_select_edge" if edge else "uv_select_vert"
    setter_name = "uv_select_edge_set" if edge else "uv_select_vert_set"
    legacy_name = "select_edge" if edge else "select"
    try:
        setter = getattr(loop, setter_name, None)
        if callable(setter):
            setter(value)
            return True
    except Exception:
        pass
    try:
        getattr(loop, live_name)
        setattr(loop, live_name, value)
        return True
    except Exception:
        try:
            setattr(luv, legacy_name, value)
            return True
        except Exception:
            return False


def _face_uv_selected(face: Any) -> bool:
    """Read Blender 5.1's live BMFace UV flag when that API exists."""
    try:
        return bool(getattr(face, "uv_select"))
    except Exception:
        return False


def _set_face_uv_selected(face: Any, value: bool) -> bool:
    """Write Blender 5.1's live BMFace UV flag when that API exists."""
    value = bool(value)
    try:
        setter = getattr(face, "uv_select_set", None)
        if callable(setter):
            setter(value)
            return True
    except Exception:
        pass
    try:
        getattr(face, "uv_select")
        setattr(face, "uv_select", value)
        return True
    except Exception:
        # Old Blender has no independent BMFace UV flag; the per-loop flags
        # written alongside this call carry the face selection there.
        return False


def _is_uv_editor_context(context: Any) -> bool:
    try:
        area = getattr(context, "area", None)
        if getattr(area, "type", "") != "IMAGE_EDITOR":
            return False
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "IMAGE_EDITOR":
            return False
        mode = getattr(space, "mode", None)
        if mode not in {None, "", "UV"}:
            return False
        return True
    except Exception:
        return False


def _workspace_settings(context: Any) -> Any:
    try:
        return getattr(getattr(context, "scene", None), "suv_workspace", None)
    except Exception:
        return None


def _crossing_toggles(context: Any) -> tuple[bool, bool]:
    settings = _workspace_settings(context)
    edges = bool(getattr(settings, "operation_uv_crossing_select_edges_enabled", False)) if settings is not None else False
    faces = bool(getattr(settings, "operation_uv_crossing_select_faces_enabled", False)) if settings is not None else False
    return edges, faces


def _edit_mesh_objects(context: Any) -> list:
    objs = []
    try:
        for obj in getattr(context, "objects_in_mode_unique_data", None) or ():
            if getattr(obj, "type", "") == "MESH":
                objs.append(obj)
    except Exception:
        pass
    if not objs:
        try:
            obj = getattr(context, "edit_object", None)
            if getattr(obj, "type", "") == "MESH":
                objs.append(obj)
        except Exception:
            pass
    return objs


class _SUObjectSnapshot:
    """Pre-gesture selection snapshot for one edit-mesh object.

    Captures UV loop select flags, UV edge select flags and mesh
    vertex/edge/face select flags so cancel and REPLACE/ADD/SUBTRACT/XOR are
    exact transactions."""

    __slots__ = ("object", "loop_select", "loop_select_edge", "vert_select", "edge_select", "face_select", "face_uv_select")

    def __init__(self, obj: Any, bm: Any, uv_layer: Any) -> None:
        self.object = obj
        self.loop_select: dict[tuple[int, int], bool] = {}
        self.loop_select_edge: dict[tuple[int, int], bool] = {}
        self.vert_select: dict[int, bool] = {}
        self.edge_select: dict[int, bool] = {}
        self.face_select: dict[int, bool] = {}
        self.face_uv_select: dict[int, bool] = {}
        for face in bm.faces:
            self.face_select[face.index] = bool(face.select)
            self.face_uv_select[face.index] = _face_uv_selected(face)
            for loop in face.loops:
                key = (face.index, loop.vert.index)
                luv = loop[uv_layer]
                self.loop_select[key] = _loop_uv_selected(loop, luv)
                self.loop_select_edge[key] = _loop_uv_selected(loop, luv, edge=True)
        for vert in bm.verts:
            self.vert_select[vert.index] = bool(vert.select)
        for edge in bm.edges:
            self.edge_select[edge.index] = bool(edge.select)

    def restore(self, bm: Any, uv_layer: Any) -> None:
        for face in bm.faces:
            if face.index in self.face_select:
                face.select = self.face_select[face.index]
            if face.index in self.face_uv_select:
                _set_face_uv_selected(face, self.face_uv_select[face.index])
            for loop in face.loops:
                key = (face.index, loop.vert.index)
                luv = loop[uv_layer]
                if key in self.loop_select:
                    _set_loop_uv_selected(loop, luv, self.loop_select[key])
                if key in self.loop_select_edge:
                    _set_loop_uv_selected(loop, luv, self.loop_select_edge[key], edge=True)
        for vert in bm.verts:
            if vert.index in self.vert_select:
                vert.select = self.vert_select[vert.index]
        for edge in bm.edges:
            if edge.index in self.edge_select:
                edge.select = self.edge_select[edge.index]


def _resolve_mode(context: Any, requested: str) -> str:
    mode = str(requested or "AUTO").upper()
    if mode in {"VERTEX", "EDGE", "FACE"}:
        return mode
    try:
        tool = getattr(context, "tool_settings", None)
        if bool(getattr(tool, "use_uv_select_sync", False)):
            select_mode = tuple(getattr(tool, "mesh_select_mode", (True, False, False)))
            if len(select_mode) >= 3 and select_mode[2]:
                return "FACE"
            if len(select_mode) >= 2 and select_mode[1]:
                return "EDGE"
            return "VERTEX"
        uv_mode = str(getattr(tool, "uv_select_mode", "VERTEX") or "VERTEX").upper()
        if uv_mode in {"EDGE", "FACE"}:
            return uv_mode
        if uv_mode == "ISLAND":
            return "FACE"
        return "VERTEX"
    except Exception:
        return "VERTEX"


class SMARTUVSUITE_OT_uv_crossing_gesture(bpy.types.Operator if bpy is not None else object):  # type: ignore[misc]
    bl_idname = UV_CROSS_GESTURE_ID
    bl_label = "UV Crossing Gesture Select"
    bl_description = "Runs an exact UV Editor box, circle or lasso crossing selection owned by Smart UV Suite."
    bl_options = {"REGISTER", "UNDO"}

    if bpy is not None:
        gesture: bpy.props.EnumProperty(  # type: ignore[valid-type]
            name="Gesture",
            description="UV crossing gesture shape used for this selection.",
            items=(
                ("BOX", "Box", "Axis-aligned UV crossing box selection."),
                ("CIRCLE", "Circle", "UV crossing circle selection."),
                ("LASSO", "Lasso", "UV crossing lasso selection."),
            ),
            default="BOX",
        )
        mode: bpy.props.EnumProperty(  # type: ignore[valid-type]
            name="Mode",
            description="UV element mode for this crossing selection.",
            items=(
                ("AUTO", "Auto", "Follow the current UV or mesh select mode."),
                ("VERTEX", "Vertex", "UV vertex crossing selection."),
                ("EDGE", "Edge", "UV edge crossing selection."),
                ("FACE", "Face", "UV face crossing selection."),
            ),
            default="AUTO",
        )
        selection_op: bpy.props.EnumProperty(  # type: ignore[valid-type]
            name="Selection Operation",
            description="How the UV crossing set combines with the pre-gesture selection.",
            items=(
                ("AUTO", "Auto", "Shift adds, Ctrl subtracts, Shift+Ctrl toggles."),
                ("REPLACE", "Replace", "Replace the selection with the crossing set."),
                ("ADD", "Add", "Add the crossing set to the selection."),
                ("SUBTRACT", "Subtract", "Remove the crossing set from the selection."),
                ("XOR", "Toggle", "Toggle the crossing set relative to the selection."),
            ),
            default="AUTO",
        )

    _MIN_LASSO_PIXEL_SPACING = 3.0
    _CIRCLE_DEFAULT_RADIUS_PX = 25.0
    _CLICK_TOLERANCE_PX = 4.0

    @classmethod
    def poll(cls, context):
        # UV Editor only: this operator never observes 3D View events.
        return _is_uv_editor_context(context) and bool(_edit_mesh_objects(context))

    # -- lifecycle -----------------------------------------------------

    def invoke(self, context, event):
        if bpy is None:
            return {"CANCELLED"}
        try:
            if not _is_uv_editor_context(context):
                return {"PASS_THROUGH"}
            if not _edit_mesh_objects(context):
                return {"PASS_THROUGH"}
            # Gate on the Operation toggles BEFORE consuming the gesture.  When
            # the feature does not apply (toggle off, or vertex mode where
            # native semantics already equal crossing semantics), the event
            # must reach Blender's native selection operators — consuming the
            # whole gesture and cancelling in _finish killed native box select
            # whenever the gate failed.
            mode = _resolve_mode(context, str(self.mode))
            edges_enabled, faces_enabled = _crossing_toggles(context)
            if mode == "EDGE" and not edges_enabled:
                return {"PASS_THROUGH"}
            if mode == "FACE" and not faces_enabled:
                return {"PASS_THROUGH"}
            if mode == "VERTEX":
                return {"PASS_THROUGH"}
            self._resolved_mode = mode
            self._start = (float(event.mouse_region_x), float(event.mouse_region_y))
            self._current = tuple(self._start)
            self._lasso_path: list[tuple[float, float]] = [tuple(self._start)]
            self._radius_px = float(self._CIRCLE_DEFAULT_RADIUS_PX)
            self._draw_handle = None
            self._native_timer = None
            self._native_box = False
            self._native_release_pending = False
            self._native_cancel_pending = False
            self._snapshots: list[tuple[Any, _SUObjectSnapshot]] = []
            # B / C key entries would otherwise anchor the region at the key
            # press position; wait for the first LMB press instead so the
            # gesture starts where the user actually clicks.
            etype = str(getattr(event, "type", "") or "").upper()
            self._waiting = etype not in {"LEFTMOUSE", "RIGHTMOUSE", "MIDDLEMOUSE", "PEN", "ERASER"}
            if str(getattr(self, "selection_op", "AUTO")).upper() in {"", "AUTO"}:
                if str(self.gesture).upper() == "LASSO" and etype == "RIGHTMOUSE":
                    # Ctrl+RMB is the lasso binding itself; Ctrl there must not
                    # be misread as a subtraction request.
                    self._resolved_op = "ADD" if bool(event.shift) else "REPLACE"
                else:
                    self._resolved_op = su_selection_op_from_modifiers(shift=bool(event.shift), ctrl=bool(event.ctrl))
            else:
                self._resolved_op = str(self.selection_op).upper()
            if str(self.gesture).upper() == "BOX":
                # Preserve Blender's native dashed selection rectangle and its
                # standard containment result.  This transient modal stays on
                # top only to record the same gesture and add intersection-only
                # hits after native dispatch has completed.
                self._capture_snapshots(context)
                native_mode = {
                    "REPLACE": "SET",
                    "ADD": "ADD",
                    "SUBTRACT": "SUB",
                    # Blender has no XOR box mode.  Keep the prior SmartUV XOR
                    # transaction and use native ADD only for presentation.
                    "XOR": "ADD",
                }.get(str(self._resolved_op), "SET")
                native_result = set(
                    bpy.ops.uv.select_box(
                        "INVOKE_DEFAULT",
                        wait_for_input=bool(self._waiting),
                        mode=native_mode,
                    )
                )
                if "RUNNING_MODAL" not in native_result:
                    return {"CANCELLED"}
                self._native_box = True
                context.window_manager.modal_handler_add(self)
                self._native_timer = context.window_manager.event_timer_add(0.02, window=context.window)
                return {"RUNNING_MODAL"}
            self._install_draw_handler(context)
            try:
                context.window_manager.modal_handler_add(self)
            except Exception:
                self._remove_draw_handler()
                return {"CANCELLED"}
            self._tag_redraw(context)
            return {"RUNNING_MODAL"}
        except Exception:
            # Never let an exception escape to Blender: it would terminate the
            # operator without cleanup and can leak the draw handler.
            try:
                self._remove_draw_handler()
            except Exception:
                pass
            return {"CANCELLED"}

    def modal(self, context, event):
        try:
            return self._modal_guarded(context, event)
        except Exception:
            # A raising modal is silently terminated by Blender with the draw
            # handler still installed and the selection half-written.  Restore
            # and cancel instead — the loop must never die dirty.
            try:
                self._cleanup(context)
            except Exception:
                pass
            try:
                self._restore_all(context)
            except Exception:
                pass
            return {"CANCELLED"}

    def _modal_guarded(self, context, event):
        if bool(getattr(self, "_native_box", False)):
            return self._modal_native_box(context, event)
        etype = str(getattr(event, "type", "") or "").upper()
        evalue = str(getattr(event, "value", "") or "").upper()
        if bool(getattr(self, "_waiting", False)):
            if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
                self._current = (float(event.mouse_region_x), float(event.mouse_region_y))
                self._start = tuple(self._current)
                self._lasso_path = [tuple(self._current)]
                self._tag_redraw(context)
                return {"RUNNING_MODAL"}
            if etype == "LEFTMOUSE" and evalue == "PRESS":
                self._waiting = False
                self._start = (float(event.mouse_region_x), float(event.mouse_region_y))
                self._current = tuple(self._start)
                self._lasso_path = [tuple(self._start)]
                if str(getattr(self, "selection_op", "AUTO")).upper() in {"", "AUTO"}:
                    self._resolved_op = su_selection_op_from_modifiers(shift=bool(event.shift), ctrl=bool(event.ctrl))
                return {"RUNNING_MODAL"}
            if etype in {"ESC", "RIGHTMOUSE", "WINDOW_DEACTIVATE"}:
                return self._cancel(context)
            return {"RUNNING_MODAL"}
        if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            self._current = (float(event.mouse_region_x), float(event.mouse_region_y))
            if str(self.gesture) == "LASSO":
                last = self._lasso_path[-1]
                dx = self._current[0] - last[0]
                dy = self._current[1] - last[1]
                if (dx * dx + dy * dy) >= (self._MIN_LASSO_PIXEL_SPACING ** 2):
                    self._lasso_path.append(tuple(self._current))
            self._tag_redraw(context)
            return {"RUNNING_MODAL"}
        if str(self.gesture) == "CIRCLE" and etype in {"WHEELUPMOUSE", "NUMPAD_PLUS"} and evalue == "PRESS":
            self._radius_px = min(4096.0, self._radius_px * 1.2)
            self._tag_redraw(context)
            return {"RUNNING_MODAL"}
        if str(self.gesture) == "CIRCLE" and etype in {"WHEELDOWNMOUSE", "NUMPAD_MINUS"} and evalue == "PRESS":
            self._radius_px = max(2.0, self._radius_px / 1.2)
            self._tag_redraw(context)
            return {"RUNNING_MODAL"}
        if etype in {"RIGHTMOUSE", "ESC"} and str(self.gesture) != "LASSO":
            return self._cancel(context)
        if etype in {"ESC", "WINDOW_DEACTIVATE"}:
            return self._cancel(context)
        if etype == "LEFTMOUSE" and evalue == "RELEASE":
            return self._finish(context)
        if etype == "RIGHTMOUSE" and evalue == "RELEASE" and str(self.gesture) == "LASSO":
            # Ctrl+RMB lasso path: release completes the gesture.
            return self._finish(context)
        return {"RUNNING_MODAL"}

    def _modal_native_box(self, context, event):
        """Observe but never replace Blender's native box modal."""
        etype = str(getattr(event, "type", "") or "").upper()
        evalue = str(getattr(event, "value", "") or "").upper()
        if etype in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            self._current = (float(event.mouse_region_x), float(event.mouse_region_y))
            if bool(getattr(self, "_waiting", False)):
                self._start = tuple(self._current)
            return {"PASS_THROUGH"}
        if bool(getattr(self, "_waiting", False)) and etype == "LEFTMOUSE" and evalue == "PRESS":
            self._waiting = False
            self._start = (float(event.mouse_region_x), float(event.mouse_region_y))
            self._current = tuple(self._start)
            return {"PASS_THROUGH"}
        if etype in {"ESC", "RIGHTMOUSE", "WINDOW_DEACTIVATE"}:
            self._native_cancel_pending = True
            return {"PASS_THROUGH"}
        if etype == "LEFTMOUSE" and evalue == "RELEASE":
            self._current = (float(event.mouse_region_x), float(event.mouse_region_y))
            self._native_release_pending = True
            return {"PASS_THROUGH"}
        if etype == "TIMER":
            if bool(getattr(self, "_native_cancel_pending", False)):
                self._cleanup(context)
                self._restore_all(context)
                return {"CANCELLED"}
            if bool(getattr(self, "_native_release_pending", False)):
                return self._finish_native_box(context)
        return {"PASS_THROUGH"}

    def _finish_native_box(self, context):
        shape = self._gesture_shape_uv(context)
        if shape is None:
            self._cleanup(context)
            return {"CANCELLED"}
        try:
            count = self._apply_crossing(context, shape, str(self._resolved_mode), native_delta=True)
        except Exception:
            self._restore_all(context)
            self._cleanup(context)
            return {"CANCELLED"}
        self._cleanup(context)
        template = _tr_report("Smart UV crossing selection selected {count} UV elements")
        try:
            self.report({"INFO"}, template.format(count=int(count)))
        except Exception:
            pass
        return {"FINISHED"}

    def cancel(self, context):
        self._cleanup(context)

    # -- helpers -------------------------------------------------------

    def _tag_redraw(self, context) -> None:
        try:
            context.area.tag_redraw()
        except Exception:
            pass

    def _install_draw_handler(self, context) -> None:
        # Visual feedback only; selection math never depends on drawing.
        try:
            import gpu
            from gpu_extras.batch import batch_for_shader

            operator = self

            def _draw():
                try:
                    points = operator._gesture_outline_px()
                    if len(points) < 2:
                        return
                    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
                    batch = batch_for_shader(shader, "LINE_LOOP", {"pos": points})
                    shader.bind()
                    shader.uniform_float("color", (1.0, 1.0, 1.0, 0.6))
                    batch.draw(shader)
                except Exception:
                    pass

            self._draw_handle = bpy.types.SpaceImageEditor.draw_handler_add(_draw, (), "WINDOW", "POST_PIXEL")
        except Exception:
            self._draw_handle = None

    def _remove_draw_handler(self) -> None:
        handle = getattr(self, "_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceImageEditor.draw_handler_remove(handle, "WINDOW")
            except Exception:
                pass
        self._draw_handle = None

    def _gesture_outline_px(self) -> list[tuple[float, float]]:
        gesture = str(self.gesture)
        if gesture == "BOX":
            (x0, y0), (x1, y1) = self._start, self._current
            return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        if gesture == "CIRCLE":
            import math

            cx, cy = self._current
            r = self._radius_px
            return [
                (cx + r * math.cos(i * math.tau / 32.0), cy + r * math.sin(i * math.tau / 32.0))
                for i in range(32)
            ]
        return list(self._lasso_path)

    def _region_to_uv(self, context, point_px: Sequence[float]) -> tuple[float, float]:
        region = getattr(context, "region", None)
        view2d = getattr(region, "view2d", None)
        if view2d is None:
            return (float(point_px[0]), float(point_px[1]))
        u, v = view2d.region_to_view(float(point_px[0]), float(point_px[1]))
        return (float(u), float(v))

    def _gesture_shape_uv(self, context) -> tuple[str, Any] | None:
        gesture = str(self.gesture)
        if gesture == "BOX":
            a = self._region_to_uv(context, self._start)
            b = self._region_to_uv(context, self._current)
            tol_a = self._region_to_uv(context, (0.0, 0.0))
            tol_b = self._region_to_uv(context, (self._CLICK_TOLERANCE_PX, 0.0))
            tolerance = abs(tol_b[0] - tol_a[0])
            return su_normalize_box(a, b, point_tolerance=tolerance)
        if gesture == "CIRCLE":
            center = self._region_to_uv(context, self._current)
            edge = self._region_to_uv(context, (self._current[0] + self._radius_px, self._current[1]))
            radius = abs(edge[0] - center[0])
            if radius <= SU_EPSILON:
                return None
            return ("CIRCLE", (center[0], center[1], radius))
        if len(self._lasso_path) < 3:
            return None
        return ("LASSO", tuple(self._region_to_uv(context, p) for p in self._lasso_path))

    def _iter_bmesh(self, context):
        import bmesh

        for obj in _edit_mesh_objects(context):
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.verify()
            except Exception:
                continue
            try:
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                bm.faces.ensure_lookup_table()
            except Exception:
                pass
            yield obj, bm, uv_layer

    def _capture_snapshots(self, context) -> None:
        self._snapshots = []
        for obj, bm, uv_layer in self._iter_bmesh(context):
            try:
                self._snapshots.append((obj, _SUObjectSnapshot(obj, bm, uv_layer)))
            except Exception:
                continue

    def _finish(self, context):
        shape = self._gesture_shape_uv(context)
        self._cleanup(context)
        if shape is None:
            return {"CANCELLED"}
        # The invoke-time gate is authoritative; this re-check is defensive only.
        mode = str(getattr(self, "_resolved_mode", "") or "") or _resolve_mode(context, str(self.mode))
        edges_enabled, faces_enabled = _crossing_toggles(context)
        if mode == "EDGE" and not edges_enabled:
            self.report({"WARNING"}, _tr_report("Smart UV crossing selection for edges is disabled in settings"))
            return {"CANCELLED"}
        if mode == "FACE" and not faces_enabled:
            self.report({"WARNING"}, _tr_report("Smart UV crossing selection for faces is disabled in settings"))
            return {"CANCELLED"}
        try:
            count = self._apply_crossing(context, shape, mode)
        except Exception:
            self._restore_all(context)
            self.report({"WARNING"}, _tr_report("Smart UV crossing selection cancelled; previous UV selection restored"))
            return {"CANCELLED"}
        template = _tr_report("Smart UV crossing selection selected {count} UV elements")
        try:
            self.report({"INFO"}, template.format(count=int(count)))
        except Exception:
            pass
        return {"FINISHED"}

    def _cancel(self, context):
        self._cleanup(context)
        self._restore_all(context)
        self.report({"INFO"}, _tr_report("Smart UV crossing selection cancelled; previous UV selection restored"))
        return {"CANCELLED"}

    def _cleanup(self, context) -> None:
        timer = getattr(self, "_native_timer", None)
        if timer is not None:
            try:
                context.window_manager.event_timer_remove(timer)
            except Exception:
                pass
        self._native_timer = None
        self._remove_draw_handler()
        self._tag_redraw(context)

    def _restore_all(self, context) -> None:
        import bmesh

        for obj, snapshot in getattr(self, "_snapshots", ()) or ():
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.verify()
                snapshot.restore(bm, uv_layer)
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                continue

    # -- exact application --------------------------------------------

    def _apply_crossing(self, context, shape: tuple[str, Any], mode: str, *, native_delta: bool = False) -> int:
        import bmesh

        tool = getattr(context, "tool_settings", None)
        sync = bool(getattr(tool, "use_uv_select_sync", False))
        op = str(getattr(self, "_resolved_op", "REPLACE"))
        total = 0
        if not native_delta:
            self._capture_snapshots(context)
        if not self._snapshots and _edit_mesh_objects(context):
            # A snapshot that cannot be captured must never degrade into a
            # silent zero-element "success": report it as a real failure so the
            # caller restores the previous selection and the gate can see it.
            raise RuntimeError("SmartUV crossing selection could not snapshot the current UV selection")
        for obj, bm, uv_layer in self._iter_bmesh(context):
            snapshot = None
            for snap_obj, snap in self._snapshots:
                if snap_obj is obj:
                    snapshot = snap
                    break
            if snapshot is None:
                continue
            if native_delta and op != "XOR":
                # Snapshot Blender's completed native selection.  Intersection
                # extras are then added/subtracted relative to that exact
                # standard result; eligibility and sync propagation stay native.
                native_snapshot = _SUObjectSnapshot(obj, bm, uv_layer)
                delta_op = "SUBTRACT" if op == "SUBTRACT" else "ADD"
                total += self._apply_one_object(
                    bm,
                    uv_layer,
                    native_snapshot,
                    shape,
                    mode,
                    delta_op,
                    sync,
                    crossing_delta_only=True,
                )
            else:
                total += self._apply_one_object(bm, uv_layer, snapshot, shape, mode, op, sync)
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
        if sync:
            try:
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type={"VERTEX": "VERT", "EDGE": "EDGE", "FACE": "FACE"}[mode])
            except Exception:
                pass
        self._tag_redraw(context)
        return total

    def _visible_faces(self, bm: Any, sync: bool):
        for face in bm.faces:
            if face.hide:
                continue
            if not sync and not face.select:
                # Non-sync UV editing only shows UVs of selected mesh faces.
                continue
            yield face

    def _apply_one_object(
        self,
        bm: Any,
        uv_layer: Any,
        snapshot: _SUObjectSnapshot,
        shape: tuple[str, Any],
        mode: str,
        op: str,
        sync: bool,
        *,
        crossing_delta_only: bool = False,
    ) -> int:
        # Build pure-data primitives keyed by stable ids, evaluate exactly,
        # then write flags in one pass.
        verts: dict[Any, tuple[float, float]] = {}
        edges: dict[Any, tuple[Any, Any]] = {}
        faces: dict[Any, tuple[Any, ...]] = {}
        loop_uv: dict[tuple[int, int], tuple[float, float]] = {}
        for face in self._visible_faces(bm, sync):
            loop_ids = []
            for loop in face.loops:
                key = (face.index, loop.vert.index)
                uv = tuple(loop[uv_layer].uv)
                loop_uv[key] = uv
                if sync:
                    verts.setdefault(("V", loop.vert.index), uv)
                    # Coincident UVs: any instance can hit; keep the first and
                    # test edges per-loop below.
                    verts[("L",) + key] = uv
                else:
                    verts[("L",) + key] = uv
                loop_ids.append(("L",) + key)
            faces[face.index] = tuple(loop_ids)
            for loop in face.loops:
                nxt = loop.link_loop_next
                eid = ("E", face.index, loop.edge.index)
                edges[eid] = (("L", face.index, loop.vert.index), ("L", face.index, nxt.vert.index))
        crossing = su_compute_crossing(
            {"verts": verts, "edges": edges, "faces": faces},
            shape,
            select_verts=(mode == "VERTEX"),
            select_edges=(mode == "EDGE"),
            select_faces=(mode == "FACE"),
        )
        if crossing_delta_only:
            contained = su_compute_contained(
                {"verts": verts, "edges": edges, "faces": faces},
                shape,
                select_verts=(mode == "VERTEX"),
                select_edges=(mode == "EDGE"),
                select_faces=(mode == "FACE"),
            )
            crossing = {
                key: set(crossing[key]) - set(contained[key])
                for key in ("verts", "edges", "faces")
            }
        if sync:
            return self._write_sync_selection(bm, snapshot, crossing, mode, op)
        return self._write_uv_selection(bm, uv_layer, snapshot, crossing, mode, op, loop_uv)

    def _write_uv_selection(self, bm: Any, uv_layer: Any, snapshot: _SUObjectSnapshot, crossing: dict[str, set], mode: str, op: str, loop_uv: dict) -> int:
        changed = 0
        if mode == "VERTEX":
            hit_keys = {key[1:] for key in crossing["verts"] if isinstance(key, tuple) and key and key[0] == "L"}
            base = {key for key, sel in snapshot.loop_select.items() if sel}
            final = su_apply_selection_op(base, hit_keys & set(loop_uv), op)
            for face in self._visible_faces(bm, False):
                for loop in face.loops:
                    key = (face.index, loop.vert.index)
                    if key not in loop_uv:
                        continue
                    want = key in final
                    luv = loop[uv_layer]
                    if _loop_uv_selected(loop, luv) != want:
                        _set_loop_uv_selected(loop, luv, want)
                        changed += 1
            return changed
        if mode == "EDGE":
            hit_edges = {(key[1], key[2]) for key in crossing["edges"] if isinstance(key, tuple) and key and key[0] == "E"}
            base_edges = set()
            for face in self._visible_faces(bm, False):
                for loop in face.loops:
                    key = (face.index, loop.vert.index)
                    if snapshot.loop_select_edge.get(key, False):
                        base_edges.add((face.index, loop.edge.index))
            final_edges = su_apply_selection_op(base_edges, hit_edges, op)
            for face in self._visible_faces(bm, False):
                for loop in face.loops:
                    ekey = (face.index, loop.edge.index)
                    want = ekey in final_edges
                    luv = loop[uv_layer]
                    if _loop_uv_selected(loop, luv, edge=True) != want:
                        _set_loop_uv_selected(loop, luv, want, edge=True)
                        changed += 1
            # Endpoint loop select flags follow the exact final edge set.
            touched: set = set()
            for face in self._visible_faces(bm, False):
                for loop in face.loops:
                    if (face.index, loop.edge.index) in final_edges:
                        touched.add((face.index, loop.vert.index))
                        touched.add((face.index, loop.link_loop_next.vert.index))
            for face in self._visible_faces(bm, False):
                for loop in face.loops:
                    key = (face.index, loop.vert.index)
                    luv = loop[uv_layer]
                    want = key in touched or (op in {"ADD", "XOR", "SUBTRACT"} and snapshot.loop_select.get(key, False))
                    if _loop_uv_selected(loop, luv) != want:
                        _set_loop_uv_selected(loop, luv, want)
                        changed += 1
            return changed
        # FACE
        hit_faces = set(crossing["faces"])
        base_faces = set()
        for face in self._visible_faces(bm, False):
            if face.index in snapshot.face_uv_select and snapshot.face_uv_select[face.index]:
                base_faces.add(face.index)
                continue
            keys = [(face.index, loop.vert.index) for loop in face.loops]
            if keys and all(snapshot.loop_select.get(key, False) for key in keys):
                base_faces.add(face.index)
        final_faces = su_apply_selection_op(base_faces, hit_faces, op)
        for face in self._visible_faces(bm, False):
            want = face.index in final_faces
            if _face_uv_selected(face) != want:
                if _set_face_uv_selected(face, want):
                    changed += 1
            for loop in face.loops:
                luv = loop[uv_layer]
                if _loop_uv_selected(loop, luv) != want:
                    _set_loop_uv_selected(loop, luv, want)
                    changed += 1
                if _loop_uv_selected(loop, luv, edge=True) != want:
                    _set_loop_uv_selected(loop, luv, want, edge=True)
                    changed += 1
        return changed

    def _write_sync_selection(self, bm: Any, snapshot: _SUObjectSnapshot, crossing: dict[str, set], mode: str, op: str) -> int:
        changed = 0
        if mode == "VERTEX":
            hits = {key[1] for key in crossing["verts"] if isinstance(key, tuple) and key and key[0] == "V"}
            base = {index for index, sel in snapshot.vert_select.items() if sel}
            final = su_apply_selection_op(base, hits, op)
            for vert in bm.verts:
                if vert.hide:
                    continue
                want = vert.index in final
                if bool(vert.select) != want:
                    vert.select = want
                    changed += 1
        elif mode == "EDGE":
            hits = {key[2] for key in crossing["edges"] if isinstance(key, tuple) and key and key[0] == "E"}
            base = {index for index, sel in snapshot.edge_select.items() if sel}
            final = su_apply_selection_op(base, hits, op)
            for edge in bm.edges:
                if edge.hide:
                    continue
                want = edge.index in final
                if bool(edge.select) != want:
                    edge.select = want
                    changed += 1
                if want:
                    for vert in edge.verts:
                        if not vert.select:
                            vert.select = True
        else:
            hits = set(crossing["faces"])
            base = {index for index, sel in snapshot.face_select.items() if sel}
            final = su_apply_selection_op(base, hits, op)
            for face in bm.faces:
                if face.hide:
                    continue
                want = face.index in final
                if bool(face.select) != want:
                    face.select = want
                    changed += 1
                if want:
                    for vert in face.verts:
                        if not vert.select:
                            vert.select = True
                    for edge in face.edges:
                        if not edge.select:
                            edge.select = True
        try:
            bm.select_flush_mode()
        except Exception:
            pass
        return changed


# ---------------------------------------------------------------------------
# 1.8.229: the window-modal watcher (wm.smart_uv_crossing_watch) and its apply
# proxy were removed.  A permanently armed modal that consumed every MOUSEMOVE
# in the window, drew no feedback, and could stay armed forever after a native
# gesture stole its finish event is unfixable by design; owned keymap rows for
# smart_uv_suite.uv_crossing_gesture (key entries plus the Select Box / Circle
# / Lasso tool maps) are the correct entry points.  The public helpers below
# stay as inert stubs so retained callers keep working.
# ---------------------------------------------------------------------------


def su_ensure_crossing_watchers(context: Any = None) -> dict[str, Any]:
    """Retired: crossing selection is dispatched by owned keymap rows only."""
    del context
    return {"started": 0, "active": 0, "retired": True}


def su_stop_crossing_watchers() -> dict[str, Any]:
    """Retired: there are no crossing watchers to stop."""
    return {"stopped": 0, "active": 0, "retired": True}


def su_crossing_runtime_diagnostics() -> dict[str, Any]:
    return {"watchers": 0, "post_callbacks": 0, "retired": True, "last": {}}


CROSSING_CLASSES = (SMARTUVSUITE_OT_uv_crossing_gesture,)
