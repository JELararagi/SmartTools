# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable

import bpy

from . import text_translation as _text_translation
from . import preferences as _preferences
from . import npanel_persistence as _npanel_store

MOVED_ALWAYS_ON_OPERATOR_IDS: frozenset[str] = frozenset({
    # UV Suite / Blender live state moved to the single top Always-on group.
    'suv.toggle_live_unwrap',
    'uv.suv_uv_sync_mode_toggle',
    'smart_uv_suite.integrated_uv_action',
})



_FOLDOUT_PREFIX = 'uv_suite_ui_foldout_'


def _foldout_prop(key: str) -> str:
    raw = str(key or '').strip().lower()
    safe = ''.join(ch if ch.isalnum() or ch == '_' else '_' for ch in raw).strip('_')
    return _FOLDOUT_PREFIX + (safe or 'section')


def _foldout_state(context, key: str, default: bool = False) -> bool:
    del context
    try:
        return bool(_npanel_store.peek_foldout(str(key or ''), bool(default)))
    except Exception:
        return bool(default)


def _draw_foldout_header(layout, context, key: str, label_en: str, label_ja: str, *, icon: str = 'TIME', default_open: bool = False, hint_en: str = '', hint_ja: str = '', help_id: str = '') -> tuple[object, bool]:
    expanded = _foldout_state(context, key, default_open)
    box = layout.box()
    title = _t(context, label_en, label_ja)
    try:
        row = box.row(align=True)
        split = row.split(factor=0.92, align=True)
        main = split.row(align=True)
        help_row = split.row(align=True)
        help_row.alignment = 'RIGHT'
    except Exception:
        main = box.row(align=True)
        help_row = main
    try:
        if _op_has_props('smart_uv_suite.toggle_ui_foldout', {'key', 'default_open'}):
            op = main.operator('smart_uv_suite.toggle_ui_foldout', text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=True, depress=bool(expanded))
            _safe_set_props(op, {'key': key, 'default_open': bool(default_open)})
            op = main.operator('smart_uv_suite.toggle_ui_foldout', text=title, icon=icon, emboss=False, depress=bool(expanded))
            _safe_set_props(op, {'key': key, 'default_open': bool(default_open)})
        else:
            main.label(text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
            main.label(text=title, icon=icon)
        if help_id:
            _draw_help_button(help_row, context, help_id, label_en, label_ja)
    except Exception:
        try:
            main.label(text=title, icon=icon)
        except Exception:
            pass
    del hint_en, hint_ja
    return box, expanded


def moved_always_on_operator_ids() -> set[str]:
    return set(MOVED_ALWAYS_ON_OPERATOR_IDS)


def is_moved_always_on_operator(op_idname: str, props: dict | None = None) -> bool:
    op_id = str(op_idname or '').strip()
    if op_id in MOVED_ALWAYS_ON_OPERATOR_IDS:
        return True
    props = props or {}
    try:
        if op_id == 'uv.suv_native_stage_compat_tools' and str(props.get('mode') or '') == 'BATCH_LIVE_UNWRAP':
            return True
    except Exception:
        pass
    return False


def _t(context, en: str, ja: str) -> str:
    try:
        return str(_text_translation.pick(str(en or ''), str(ja or ''), context=context))
    except Exception:
        return str(ja if _text_translation.is_japanese(context) else en)


def _op_exists(op_idname: str) -> bool:
    op_idname = str(op_idname or '').strip()
    if '.' not in op_idname:
        return False
    head, tail = op_idname.split('.', 1)
    try:
        group = getattr(bpy.ops, head, None)
        if group is None:
            return False
        op = getattr(group, tail, None)
        rna = op.get_rna_type()
        identifier = str(getattr(rna, 'identifier', '') or '')
        return bool(identifier) and identifier not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _op_has_props(op_idname: str, names: tuple[str, ...] | list[str] | set[str]) -> bool:
    if not _op_exists(op_idname):
        return False
    try:
        head, tail = str(op_idname).split('.', 1)
        op = getattr(getattr(bpy.ops, head), tail)
        props = _operator_prop_names_from_rna(op.get_rna_type())
    except Exception:
        props = set()
    required = {str(name) for name in (names or ()) if str(name)}
    return required.issubset(props)


def _operator_prop_names_from_rna(rna) -> set[str]:
    names: set[str] = set()
    try:
        props = getattr(rna, 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _operator_prop_names(op) -> set[str]:
    names: set[str] = set()
    try:
        props = getattr(getattr(op, 'bl_rna', None), 'properties', None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _safe_set_props(op, props: dict | None) -> None:
    if op is None or not props:
        return
    available = _operator_prop_names(op)
    if not available:
        return
    for key, value in dict(props).items():
        key = str(key)
        if key not in available:
            continue
        try:
            setattr(op, key, value)
        except Exception:
            pass


def _draw_help_button(row, context, help_id: str, title_en: str, title_ja: str):
    try:
        if not _op_has_props('smart_uv_suite.show_help', {'help_id'}):
            return None
        try:
            help_row = row.row(align=True)
            help_row.scale_x = 0.82
            help_row.scale_y = 1.0
        except Exception:
            help_row = row
        op = help_row.operator('smart_uv_suite.show_help', text='', icon='QUESTION')
        _safe_set_props(op, {'help_id': str(help_id or ''), 'title_en': str(title_en or ''), 'title_ja': str(title_ja or '')})
        return op
    except Exception:
        return None


def _draw_enabled_operator(row, context, op_idname: str, enabled: bool):
    enabled = bool(enabled)
    text = _t(context, 'Enabled' if enabled else 'Disabled', '有効' if enabled else '無効')
    icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
    try:
        return row.operator(str(op_idname), text=text, icon=icon, depress=enabled)
    except TypeError:
        return row.operator(str(op_idname), text=text, icon=icon)


def _class_running(class_name: str, context) -> bool | None:
    try:
        cls = getattr(bpy.types, str(class_name or ''), None)
        fn = getattr(cls, 'is_running', None)
        if callable(fn):
            return bool(fn(context))
    except Exception:
        return None
    return None


def _live_unwrap_state(context) -> bool | None:
    names = ('use_live_unwrap', 'use_edge_path_live_unwrap')
    try:
        wm = getattr(context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', '') not in {'IMAGE_EDITOR', 'VIEW_3D'}:
                    continue
                for space in getattr(area, 'spaces', ()) or ():
                    for name in names:
                        if hasattr(space, name):
                            return bool(getattr(space, name))
    except Exception:
        pass
    try:
        tool_settings = getattr(getattr(context, 'scene', None), 'tool_settings', None)
        for name in names:
            if hasattr(tool_settings, name):
                return bool(getattr(tool_settings, name))
    except Exception:
        pass
    return None


def _uv_sync_state(context) -> bool | None:
    try:
        tool_settings = getattr(context, 'tool_settings', None) or getattr(getattr(context, 'scene', None), 'tool_settings', None)
        if tool_settings is not None and hasattr(tool_settings, 'use_uv_select_sync'):
            return bool(getattr(tool_settings, 'use_uv_select_sync'))
    except Exception:
        pass
    return None



def _set_operator_props(op, props: dict | None) -> None:
    if op is None or not props:
        return
    prop_names = set()
    try:
        prop_defs = getattr(getattr(op, 'bl_rna', None), 'properties', None)
        prop_names.update(str(k) for k in prop_defs.keys())
        for prop in prop_defs:
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident:
                prop_names.add(ident)
    except Exception:
        pass
    for key, value in dict(props).items():
        key = str(key)
        if key not in prop_names:
            continue
        try:
            setattr(op, key, value)
        except Exception:
            pass

def _button_row(layout, context, *, op_id: str, label_en: str, label_ja: str, desc_en: str, desc_ja: str, state: bool | None = None, props: dict | None = None, action_en: str | None = None, action_ja: str | None = None) -> bool:
    try:
        row = layout.row(align=True)
        exists = _op_exists(op_id)
        icon = 'CHECKBOX_HLT' if state is True else ('CHECKBOX_DEHLT' if state is False else 'DOT')
        default_en = 'Enabled' if state is True else ('Disabled' if state is False else 'Toggle')
        default_ja = '有効' if state is True else ('無効' if state is False else '切替')
        text = _t(context, action_en or default_en, action_ja or default_ja)
        if exists and (not props or _op_has_props(op_id, set(dict(props).keys()))):
            try:
                op = row.operator(op_id, text=text, icon=icon, depress=bool(state) if state is not None else False)
            except TypeError:
                op = row.operator(op_id, text=text, icon=icon)
            _set_operator_props(op, props)
        else:
            row.enabled = False
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        label_col = row.column(align=True)
        label_col.label(text=_t(context, label_en, label_ja))
        if desc_en or desc_ja:
            hint = label_col.row(align=True)
            hint.scale_y = 0.72
            hint.label(text=_t(context, desc_en, desc_ja)[:140])
        return True
    except Exception:
        return False


def _draw_prop_toggle(layout, context, owner, prop_name: str, label_en: str, label_ja: str) -> bool:
    label = _t(context, label_en, label_ja)
    try:
        if owner is not None and hasattr(owner, prop_name):
            row = layout.row(align=True)
            row.prop(owner, prop_name, text=label, toggle=True)
            return True
        row = layout.row(align=True)
        row.enabled = False
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
        row.label(text=label)
        return True
    except Exception:
        return False


def _native_suite_preferences(context):
    try:
        from . import preferences_proxy
        return preferences_proxy.get_addon_preferences(context, __package__, None)
    except Exception:
        return None


def _native_overlay_settings(context):
    return None


def _scene_props(context, attr_name: str):
    try:
        return getattr(getattr(context, 'scene', None), str(attr_name or ''), None)
    except Exception:
        return None



def _draw_manual_toggles(layout, context) -> int:
    # Always-on controls are drawn exclusively from Smart UV Suite's own
    # _ALWAYS_ON_FEATURES table.  Old external live/modal toggles are kept out of
    # the top group and are available only as on-demand integrated actions.
    return 0


def _draw_quick_overlay_controls(layout, context) -> int:
    'Central quick build/clear controls for UV Suite preview overlays.\n\n    These are persistent viewport/material preview states, so quick switches live in\n    the always-on group.  Advanced overlay settings remain available in the normal\n    tool sections and the all-tools catalog.\n    '
    entries = (
        ('uv.suv_issue_overlay_tools', 'Issue Overlay', '問題オーバーレイ', 'BUILD_SELECTED', 'CLEAR'),
        ('uv.suv_uv_stack_compare_overlay_tools', 'Stack Compare Overlay', 'スタック比較オーバーレイ', 'BUILD_ACTIVE', 'CLEAR'),
        ('uv.suv_uv_seam_candidate_overlay_tools', 'Seam Candidate Overlay', 'シーム候補オーバーレイ', 'BUILD_SELECTED', 'CLEAR'),
        ('uv.suv_uv_seam_state_overlay_tools', 'Seam State Overlay', 'シーム状態オーバーレイ', 'BUILD_SELECTED', 'CLEAR'),
        ('uv.suv_uv_similarity_cluster_overlay_tools', 'Similarity Cluster Overlay', '類似クラスタオーバーレイ', 'BUILD_SELECTED', 'CLEAR'),
    )
    drawn = 0
    available = [item for item in entries if _op_has_props(item[0], {'mode'})]
    if not available:
        return 0
    box = layout.box()
    box.label(text=_t(context, 'UV Suite Preview Overlays', 'UV Suite プレビューオーバーレイ'), icon='OVERLAY')
    for op_id, label_en, label_ja, build_mode, clear_mode in available:
        row = box.row(align=True)
        try:
            op = row.operator(op_id, text=_t(context, 'Build', '作成'), icon='PLAY')
            _set_operator_props(op, {'mode': build_mode})
            op = row.operator(op_id, text=_t(context, 'Clear', 'クリア'), icon='X')
            _set_operator_props(op, {'mode': clear_mode})
            row.label(text=_t(context, label_en, label_ja))
            drawn += 1
        except Exception:
            continue
    return drawn

def _draw_captured_tool_runtime_toggles(layout, context) -> int:
    try:
        from . import feature_toggle
        fn = getattr(feature_toggle, 'draw_global_toggles', None)
        if callable(fn):
            return int(fn(layout, context, compact=True) or 0)
    except Exception as exc:
        try:
            layout.label(text=_t(context, f'Captured background toggles failed: {exc}', f'登録時常駐切替の表示に失敗しました: {exc}'), icon='ERROR')
        except Exception:
            pass
    return 0


def _prefs(context=None):
    """Return the already-created runtime holder without persistence I/O.

    N-panel draw functions must not apply JSON state, mutate RNA, or perform
    lifecycle work.  Stored values are restored once by preferences.register()
    and by the file-load handler; drawing only reads that live holder.
    """
    try:
        accessor = getattr(_preferences, 'runtime_preferences', None)
        if callable(accessor):
            return accessor(context)
    except Exception:
        pass
    return None


def _always_on_prop_name(fid: str) -> str:
    try:
        fn = getattr(_preferences, 'always_on_property_name', None)
        if callable(fn):
            return str(fn(fid))
    except Exception:
        pass
    raw = str(fid or '').strip().lower()
    safe = ''.join(ch if ch.isalnum() else '_' for ch in raw).strip('_')
    safe = '_'.join(part for part in safe.split('_') if part)
    return 'always_on_' + (safe or 'feature')


def _draw_smart_render_style_feature_rows(layout, context) -> int:
    try:
        root = __import__(__package__, fromlist=['_ALWAYS_ON_FEATURES', '_sus_always_on_state'])
        features = tuple(getattr(root, '_ALWAYS_ON_FEATURES', ()) or ())
        state_fn = getattr(root, '_sus_always_on_state', None)
    except Exception:
        features = ()
        state_fn = None
    prefs = _prefs(context)
    if not features or not callable(state_fn):
        return 0
    drawn = 0
    col = layout.column(align=True)
    col.use_property_split = False
    col.use_property_decorate = False
    for feature in features:
        try:
            fid = str(feature.get('id') or '').strip().upper()
            if not fid:
                continue
            available, enabled, _source = state_fn(fid, context)
            label = _t(context, str(feature.get('label_en') or fid), str(feature.get('label_ja') or fid))
            prop_name = _always_on_prop_name(fid)
            row = col.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            left = split.row(align=True)
            left.label(text=label)
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            if not available and not enabled:
                right.enabled = False
            if prefs is not None and hasattr(prefs, prop_name):
                try:
                    value = bool(getattr(prefs, prop_name))
                except Exception:
                    value = bool(enabled)
                right.prop(
                    prefs,
                    prop_name,
                    text=_t(context, 'Enabled', '有効') if value else _t(context, 'Disabled', '無効'),
                    icon='CHECKBOX_HLT' if value else 'CHECKBOX_DEHLT',
                    toggle=True,
                )
            elif _op_has_props('smart_uv_suite.toggle_always_on_feature', {'feature_id'}):
                op = _draw_enabled_operator(right, context, 'smart_uv_suite.toggle_always_on_feature', enabled)
                _safe_set_props(op, {'feature_id': fid})
            else:
                right.enabled = False
                right.label(text=_t(context, 'Disabled', '無効'), icon='CHECKBOX_DEHLT')
            drawn += 1
        except Exception:
            continue
    return drawn



def _draw_npanel_state_save_row(layout, context):
    """Draw the N-panel state persistence switch in the same row style as the always-on switches."""
    prefs = _prefs(context)
    try:
        enabled = bool(getattr(prefs, 'npanel_state_save'))
    except Exception:
        enabled = True
    try:
        row = layout.row(align=True)
        row.scale_y = 0.95
        split = row.split(factor=0.72, align=True)
        left = split.row(align=True)
        left.label(text=_t(context, 'N-panel State Save', 'Nパネル状態保存'))
        right = split.row(align=True)
        right.alignment = 'RIGHT'
        right.use_property_split = False
        right.use_property_decorate = False
        icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
        text = _t(context, 'Enabled' if enabled else 'Disabled', '有効' if enabled else '無効')
        if prefs is not None and hasattr(prefs, 'npanel_state_save'):
            right.prop(prefs, 'npanel_state_save', text=text, icon=icon, toggle=True)
            return prefs
        right.label(text=text, icon=icon)
    except Exception:
        pass
    return None


def _draw_workspace_runtime_rows(layout, context) -> int:
    """Draw runtime switches that are owned by the main Scene workspace PG."""
    try:
        owner = getattr(getattr(context, 'scene', None), 'suv_workspace', None)
    except Exception:
        owner = None
    if owner is None:
        return 0
    entries = (
        ('operation_instant_select_enabled', 'Instant Select Drag Move', '即時選択ドラッグ移動'),
        ('operation_axis_constraint_memory_enabled', 'Axis Constraint Memory', '軸拘束の記憶'),
        ('operation_uv_gizmo_grip_fix_enabled', 'UV Gizmo Grip Fix', 'UVギズモつかみ補助'),
    )
    drawn = 0
    for prop_name, en, ja in entries:
        try:
            if not hasattr(owner, prop_name):
                continue
            enabled = bool(getattr(owner, prop_name))
            row = layout.row(align=True)
            row.scale_y = 0.95
            split = row.split(factor=0.72, align=True)
            left = split.row(align=True)
            left.label(text=_t(context, en, ja))
            right = split.row(align=True)
            right.alignment = 'RIGHT'
            right.use_property_split = False
            right.use_property_decorate = False
            right.prop(
                owner,
                prop_name,
                text=_t(context, 'Enabled' if enabled else 'Disabled', '有効' if enabled else '無効'),
                icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
                toggle=True,
            )
            drawn += 1
        except Exception:
            continue
    return drawn


def draw_top_group(layout, context) -> bool:
    'Draw the centralized always-on/live controls at the very top of the Smart UV N-panel.'
    if layout is None:
        return False
    try:
        prefs = _prefs(context)
        section_layout = layout.column(align=True)
        section_layout.use_property_split = False
        section_layout.use_property_decorate = False
        box = section_layout.box()
        box.use_property_split = False
        box.use_property_decorate = False
        is_open = bool(getattr(prefs, 'show_always_on_toggles', False)) if prefs is not None else False
        title_en = 'Always-on Toggles'
        title_ja = '常時機能切り替え'
        title = _t(context, title_en, title_ja)
        try:
            main = box.row(align=True)
        except Exception:
            main = box
        main.use_property_split = False
        main.use_property_decorate = False
        if prefs is not None and hasattr(prefs, 'show_always_on_toggles'):
            main.prop(prefs, 'show_always_on_toggles', text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=True)
        else:
            main.label(text='', icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT')
        try:
            split = main.split(factor=0.86, align=True)
            title_area = split.row(align=True)
            help_area = split.row(align=True)
            help_area.alignment = 'RIGHT'
            help_area.scale_x = 0.82
            help_area.scale_y = 1.0
        except Exception:
            title_area = main
            help_area = main
        if prefs is not None and hasattr(prefs, 'show_always_on_toggles'):
            title_area.prop(
                prefs,
                'show_always_on_toggles',
                text=title,
                icon='TIME',
                toggle=True,
                emboss=False,
            )
        else:
            title_area.label(text=title, icon='TIME')
        _draw_help_button(help_area, context, 'always_on', title_en, title_ja)
        if not is_open:
            return True
        col = box.column(align=True)
        col.use_property_split = False
        col.use_property_decorate = False
        col.separator(factor=0.25)
        _draw_npanel_state_save_row(col, context)
        try:
            col.separator(factor=0.5)
        except Exception:
            pass
        manual_count = _draw_smart_render_style_feature_rows(col, context)
        manual_count += _draw_workspace_runtime_rows(col, context)
        if manual_count <= 0:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        return True
    except Exception as exc:
        try:
            layout.label(text=_t(context, f'Always-on control draw failed: {exc}', f'常時機能切り替えの描画に失敗しました: {exc}'), icon='ERROR')
        except Exception:
            pass
        return False
