# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Any

TOOL_ORDER: tuple[str, ...] = (
    "bridges",
    "smart_render_smart",
    "camera_plane",
    "camera_rigs",
    "dynamic_sky",
    "frame_range_renderer",
    "freestyle_svg_exporter",
    "hdr_rotation",
    "k_tools_render_preset_manager",
    "overscan",
    "pseudo_rendering_farm",
    "profiler",
    "rendernames",
    "sun_position",
    "tri_lighting",
    "use_for_rendering_plus",
)




_TOOL_INFO: dict[str, dict[str, Any]] = {
    "smart_render_smart": {
        "display_name": 'Render Pipeline Manager',
        "version": (1, 0, 0),
        "summary_en": "Superset render-pipeline orchestrator that consolidates state/take management, batch queues, token naming, AOV mapping, USD/PDG manifests, realtime render queue handoff, renderer ecosystem metadata, farm job metadata, asset-prep handoff, and preflight checks into one Smart Render N-panel tool.",
        "summary_ja": "ステート/テイク管理、レンダーキュー、トークン命名、AOV写像、USD/PDGマニフェスト、リアルタイムレンダーキュー連携、レンダラーエコシステム情報、ファームジョブ情報、アセット準備連携、プリフライト検証を、Smart Render Nパネル内の単一上位互換ツールとして統合します。",
        "usage_en": "Load Render Pipeline Manager from Integrated Tools, choose a pipeline preset, use the large icon cockpit to run Run Production Autopilot or Analyze, optionally apply the preset, build the queue, then export a manifest, submission pack, or headless script under the Smart_Render_Suite folder in Blender's config directory unless a manual output folder is specified.",
        "usage_ja": '統合ツールから Render Pipeline Manager を読み込み、パイプラインプリセットを選び、大判アイコンの本番オートパイロットを実行または診断を実行してください。必要に応じてパイプラインプリセットを適用、レンダーキューを生成を行い、手動出力先を指定していない場合は Blender の設定フォルダー内の Smart_Render_Suite フォルダーへマニフェストまたはヘッドレススクリプトを書き出します。',
        "description_en": "Superset render pipeline orchestrator and manifest bridge",
    },
    "bridges": {
        "display_name": 'External Pipeline Bridge',
        "version": (1, 0, 0),
        "summary_en": "Build bridge/export manifests and farm-ready command descriptions for external render managers, DCC pipelines, and automation targets.",
        "summary_ja": "外部レンダーマネージャー、DCC パイプライン、各種自動化先へ渡すためのブリッジ/エクスポート用マニフェストと実行コマンド記述を生成します。",
        "usage_en": "Use this as an internal utility from Smart Render bridge/export workflows. It is not a direct scene editing tool and usually does not require standalone interaction.",
        "usage_ja": "Smart Render のブリッジ/エクスポート系ワークフローから内部ユーティリティとして使います。通常は単独でシーン編集するタイプのツールではありません。",
        "description_en": "Bridge/export manifest builder for external pipelines",
    },
    "camera_plane": {
        "display_name": 'Camera Image Plane',
        "version": (3, 0, 0),
        "summary_en": "Create and manage camera-aligned image planes, camera mapping helpers, grouping, opacity helpers, and maintenance tools for image-based shot setup.",
        "summary_ja": "カメラに追従する画像プレーン、カメラマッピング補助、グループ化、透明度補助、保守処理をまとめて扱う、画像ベースのショット準備ツールです。",
        "usage_en": "Open the migrated Camera Plane panel inside Smart Render N-panel, add or convert planes, then use grouping, update, reverse, or maintenance actions as needed. Use maintenance mainly for older files or repaired data.",
        "usage_ja": "Smart Render Nパネル内へ移植された Camera Plane パネルを開き、プレーン追加や変換を行ってください。必要に応じてグループ更新、順序を反転、保守処理を使います。保守処理は主に旧ファイルや修復が必要なデータ向けです。",
        "description_en": "Camera-aligned image plane and camera mapping workflow",
    },
    "camera_rigs": {
        "display_name": 'Camera Rig Builder',
        "version": (1, 8, 2),
        "summary_en": "Create dolly, crane, and 2D camera rigs with reusable widgets and rig controls for animation and cinematic camera motion.",
        "summary_ja": "ドリー、クレーン、2D の各カメラリグを生成し、再利用可能なウィジェットとリグ操作系でアニメーションやシネマティックなカメラ演出を支援します。",
        "usage_en": "Run the build rig operator from Smart Render N-panel, then animate the generated controls. The runtime settings panel lets you change widget naming and the widget collection used for generated rig objects.",
        "usage_ja": "Smart Render Nパネルからリグ作成オペレーターを実行し、生成されたコントロールをアニメーションしてください。設定パネルではウィジェット接頭辞と生成先コレクション名を変更できます。",
        "description_en": "Animation-ready dolly, crane, and 2D camera rig builder",
    },
    "dynamic_sky": {
        "display_name": 'Cycles Sky Generator',
        "version": (1, 0, 6),
        "summary_en": "Generate a procedural Cycles sky world with adjustable node-based controls for sky color, sun shape, and atmosphere styling.",
        "summary_ja": "Cycles 用の手続き型スカイワールドを生成し、空色、太陽形状、大気表現をノードベースで調整できます。",
        "usage_en": "Press Create Procedural Sky in the Smart Render N-panel. It switches the engine to Cycles, makes a new sky World, and assigns it to the scene. The Settings below the button adjust the sky made last.",
        "usage_ja": "Smart Render Nパネルの「プロシージャルスカイを作成」を押してください。エンジンを Cycles にして、空のワールドを新しく作り、シーンのワールドにします。ボタンの下の「設定」で、最後に作った空を調整できます。",
        "description_en": "Procedural Cycles sky generator",
    },
    "frame_range_renderer": {
        "display_name": 'Frame Range Render',
        "version": (1, 0, 0),
        "summary_en": "Render only the frame numbers or frame ranges you specify, such as 1,2,5-8, without changing the scene's global start and end frame values.",
        "summary_ja": "1,2,5-8 のように指定したフレーム番号や範囲だけをレンダーし、シーン全体の開始/終了フレーム設定を直接書き換えずに運用できます。",
        "usage_en": "Enter a comma-separated frame list or ranges in the migrated panel, start rendering, and cancel from the same panel if needed. This is useful for patch renders and selective reruns.",
        "usage_ja": "移植済みパネルへカンマ区切りのフレーム番号や範囲を入力して実行し、必要なら同じパネルから停止します。差し替えレンダーや一部だけの再実行に向いています。",
        "description_en": "Selective render runner for explicit frame lists and ranges",
    },
    "freestyle_svg_exporter": {
        "display_name": 'Freestyle SVG Export',
        "version": (1, 0, 0),
        "summary_en": "Export Freestyle strokes and optional fills to SVG during rendering, so stylized line work can continue into vector-based finishing or compositing workflows.",
        "summary_ja": "レンダー時に Freestyle のストロークと必要に応じた塗りを SVG へ出力し、線画ベースの仕上げやベクターワークフローへつなげられます。",
        "usage_en": "Configure the migrated SVG export panels and line style options inside Smart Render N-panel, enable Freestyle where needed, then render so the SVG files are written alongside the render process.",
        "usage_ja": "Smart Render Nパネル内へ移植された SVG 出力パネルとラインスタイル設定を調整し、必要な Freestyle を有効化したうえでレンダーしてください。レンダー処理に合わせて SVG が書き出されます。",
        "description_en": "Freestyle SVG line and fill exporter",
    },
    "hdr_rotation": {
        "display_name": 'HDRI Rotation',
        "version": (1, 0, 7),
        "summary_en": "Rotate the active environment texture interactively in the 3D View so you can align HDR lighting and reflections without opening shader nodes manually.",
        "summary_ja": "3D ビュー上でアクティブな環境テクスチャを対話的に回転し、シェーダーノードを直接開かなくても HDR ライティングや反射方向を合わせられます。",
        "usage_en": "In Material Preview or Rendered view, use the HDRI Rotation action and drag on empty space in the viewport. Dragging directly on objects prioritizes 3D cursor movement instead.",
        "usage_ja": "マテリアルプレビューまたはレンダー表示で HDRI Rotation を使い、ビューポートの空いている場所をドラッグしてください。オブジェクト上では 3D カーソル移動が優先されます。",
        "description_en": "Interactive HDRI environment rotation in the 3D View",
    },
    "k_tools_render_preset_manager": {
        "display_name": 'Render Preset Manager',
        "version": (1, 3, 0),
        "summary_en": "Save, load, compare, audit, and manage reusable render setting presets with whitelist filtering and user preset storage.",
        "summary_ja": "レンダー設定プリセットを保存・読込・比較・監査し、ホワイトリスト制御やユーザープリセット保存先も含めて再利用しやすく管理します。",
        "usage_en": "Use the migrated preset manager panels in Smart Render N-panel to save or load render presets. The runtime settings panel controls storage location, display style, developer audit options, and whitelist management.",
        "usage_ja": "Smart Render Nパネルに移植されたプリセット管理パネルからレンダープリセットを保存・読込してください。設定パネルでは保存先、表示形式、開発者向け監査オプション、ホワイトリスト管理を調整できます。",
        "description_en": "Render settings preset manager with audit and whitelist controls",
    },
    "overscan": {
        "display_name": 'Render Overscan',
        "version": (1, 2, 3),
        "summary_en": "Adjust render overscan and related camera framing options so compositing-safe margins can be rendered without rebuilding the shot manually.",
        "summary_ja": "コンポジット用の余白を確保するために、レンダーのレンダーオーバースキャン量や関連するカメラフレーミング設定を調整できます。",
        "usage_en": "Set the desired overscan amount and related options in the migrated panel, render with the expanded framing, and use the revert action when you want to restore the original state.",
        "usage_ja": "移植済みパネルでレンダーオーバースキャン量と関連オプションを設定し、余白込みでレンダーしてください。元に戻したい場合はリバート操作を使います。",
        "description_en": "Overscan and safe-framing render utility",
    },
    "pseudo_rendering_farm": {
        "display_name": 'Local Render Farm',
        "version": (0, 9, 0),
        "summary_en": "Launch multiple local background Blender render processes and benchmark instance counts to estimate a practical parallel render setup on the current machine.",
        "summary_ja": "ローカル環境で複数の Blender バックグラウンドレンダープロセスを起動し、インスタンス数のベンチマークも行って、現マシン向けの実用的な並列レンダー構成を探れます。",
        "usage_en": "Save the .blend file first, make sure overwrite is disabled and placeholders are enabled, then launch renders or benchmark from the migrated panel. Use this for local batch experiments, not for distributed farm management.",
        "usage_ja": "先に .blend を保存し、「上書き」を無効、「プレースホルダー」を有効にしたうえで、移植済みパネルから実行またはベンチマークしてください。分散管理というより、ローカル並列レンダー検証向けです。",
        "description_en": "Local parallel render launcher and benchmark helper",
    },
    "profiler": {
        "display_name": 'Render Profiler',
        "version": (0, 9, 4),
        "summary_en": "Render Profile viewport or render activity and open a live report so geometry, materials, objects, and other scene costs can be inspected more systematically.",
        "summary_ja": "ビューポートまたはレンダー動作を計測し、ジオメトリ、マテリアル、オブジェクトなどの負荷をライブレポートで体系的に確認できます。",
        "usage_en": "Use the migrated controls to choose the report mode, start profiling, open the report, and stop profiling when finished. In this integrated package, legacy top bar and menu injections stay disabled so the entry point remains inside Smart Render N-panel.",
        "usage_ja": "移植済みコントロールからレポートモードを選び、計測開始、レポート表示、計測停止を行ってください。この統合版では旧トップバー/メニューへの追加UIは無効化し、入口を Smart Render Nパネルに集約しています。",
        "description_en": "Viewport and render performance profiler with live report",
    },
    "rendernames": {
        "display_name": 'Render Output Naming',
        "version": (1, 2, 0),
        "summary_en": "Build template-based output file and folder names with preview, presets, sanitizing, and organization options for scene, camera, date, and other variables.",
        "summary_ja": "テンプレートベースで出力ファイル名やフォルダー構成を組み立て、プレビュー、プリセット、サニタイズ、シーン/カメラ/日付などの整理規則をまとめて扱えます。",
        "usage_en": "Enable the migrated Render Output Naming panel, assemble the naming template, confirm the live preview path, then save presets or render with the generated naming scheme.",
        "usage_ja": '移植済みレンダー出力の命名パネルを有効化し、命名テンプレートを組み立て、ライブプレビューで出力先を確認してから、必要ならプリセット保存やレンダー実行を行ってください。',
        "description_en": "Template-based render output naming and preset workflow",
    },
    "sun_position": {
        "display_name": 'Sun Position Control',
        "version": (4, 4, 0),
        "summary_en": "Control sun placement, date/time, geographic coordinates, environment linkage, and viewport overlays for physically guided daylight setup.",
        "summary_ja": "太陽位置、日時、地理座標、環境連動、ビューポートオーバーレイを制御し、物理ベースの日照セットアップを行えます。",
        "usage_en": "Use the migrated Sun Position Control panels to choose mode, location, date, time, and optional overlays. Enable automatic callbacks only when you need live updates during timeline playback or after loading files.",
        "usage_ja": "移植済み Sun Position Control パネルからモード、場所、日付、時刻、必要に応じてオーバーレイを設定してください。タイムライン再生中やファイル読込後も自動更新したい時だけコールバックを有効にします。",
        "description_en": "Physically guided daylight, coordinates, and sun environment controls",
    },
    "tri_lighting": {
        "display_name": 'Three-Point Lighting',
        "version": (0, 2, 1),
        "summary_en": "Create a three-point lighting rig around the selected object with controllable lamp types, energies, angles, and contrast values.",
        "summary_ja": "選んだ物の周りに、キー・フィル・バックの 3 つのライトを作り、種類、強さ、角度、コントラストを調整できます。",
        "usage_en": "Select the target object and press Create Three-Point Lighting in the Smart Render N-panel. The Settings below the button adjust height, distance, power, angles, and light types; changes apply at once to the three lights made last. The light directions follow the active camera. Without a camera, or with the camera at the object or straight above it, the lights are placed as if viewing the object from the front (-Y).",
        "usage_ja": "対象の物を選び、Smart Render Nパネルの「三点照明を作成」を押してください。ボタンの下の「設定」で高さ、距離、強さ、角度、ライトの種類を変えられ、最後に作った 3 つのライトへすぐ反映されます。ライトの向きはアクティブカメラの位置を基準に決まります。カメラが無い時や、カメラが物と同じ位置・真上にある時は、物を正面（-Y 側）から見た向きで置きます。",
        "description_en": "Three-point lighting rig generator",
    },
    "use_for_rendering_plus": {
        "display_name": 'View Layer Manager',
        "version": (1, 2, 5),
        "summary_en": "Extend View Layer management with batch toggles, copy/paste helpers, pass and AOV utilities, and manager panels for layer-focused workflows.",
        "summary_ja": 'ビューレイヤー管理を拡張し、一括切替、コピー/貼り付け補助、パス/AOV ユーティリティ、マネージャーパネルを提供してレイヤー運用を効率化します。',
        "usage_en": "Use the migrated View Layer Manager tools and proxy panels from Smart Render N-panel. The runtime settings panel controls which manager sections remain visible in the integrated workflow.",
        "usage_ja": 'Smart Render Nパネルから移植済みのビューレイヤーマネージャーツールとプロキシパネルを使用してください。設定パネルでは統合ワークフロー内で表示を残す管理セクションを調整できます。',
        "description_en": "Extended View Layer management and copy utilities",
    },
}


def tool_aliases() -> tuple[str, ...]:
    return TOOL_ORDER


def tool_info(alias: str) -> dict[str, Any]:
    return dict(_TOOL_INFO.get(str(alias or "").strip(), {}))


def tool_spec_defaults(alias: str) -> dict[str, Any]:
    alias = str(alias or "").strip()
    info = tool_info(alias)
    if not info:
        return {}
    return {
        "display_name": str(info.get("display_name") or alias),
        "summary_en": str(info.get("summary_en") or ""),
        "summary_ja": str(info.get("summary_ja") or ""),
        "usage_en": str(info.get("usage_en") or ""),
        "usage_ja": str(info.get("usage_ja") or ""),
        "description_en": str(info.get("description_en") or info.get("summary_en") or ""),
        "version": tuple(info.get("version") or (1, 0, 0)),
        "blender": (5, 1, 0),
    }


_DISPLAY_NAME_JA = {
    'bridges': '外部パイプライン連携',
    'smart_render_smart': 'レンダーパイプライン管理',
    'camera_plane': 'カメラの画像板',
    'camera_rigs': 'カメラリグの作成',
    'dynamic_sky': 'Cycles の空の作成',
    'frame_range_renderer': 'フレーム範囲レンダー',
    'freestyle_svg_exporter': 'Freestyle の SVG 書き出し',
    'hdr_rotation': 'HDR の回転',
    'k_tools_render_preset_manager': 'レンダープリセット管理',
    'overscan': 'レンダーのオーバースキャン',
    'pseudo_rendering_farm': 'ローカルレンダーファーム',
    'profiler': 'レンダープロファイラー',
    'rendernames': 'レンダー出力の命名',
    'sun_position': '太陽の位置',
    'tri_lighting': '三点照明',
    'use_for_rendering_plus': 'ビューレイヤーマネージャー',
}


def display_name_ja(alias: str) -> str:
    return _DISPLAY_NAME_JA.get(str(alias or "").strip(), "")


def display_name(alias: str, fallback: str = "") -> str:
    info = tool_info(alias)
    text = str(info.get("display_name") or "").strip()
    if text:
        return text
    alias = str(alias or "").strip()
    return fallback or alias.replace("_", " ").title() or "Integrated Tool"


def enabled_prop_name(alias: str) -> str:
    alias = str(alias or "").strip()
    return f"integrated_tool_enabled__{alias}"


def expanded_prop_name(alias: str) -> str:
    alias = str(alias or "").strip()
    return f"integrated_tool_expanded__{alias}"


def tool_enabled(alias: str, context=None, *, default: bool = True) -> bool:
    return True

def search_text_blob(spec: dict[str, Any]) -> str:
    alias = str(spec.get("alias") or "").strip()
    defaults = tool_spec_defaults(alias)
    parts = [
        alias,
        str(spec.get("display_name") or defaults.get("display_name") or ""),
        display_name_ja(alias),
        str(spec.get("description") or defaults.get("description_en") or ""),
        str(spec.get("summary_en") or defaults.get("summary_en") or ""),
        str(spec.get("summary_ja") or defaults.get("summary_ja") or ""),
        str(spec.get("usage_en") or defaults.get("usage_en") or ""),
        str(spec.get("usage_ja") or defaults.get("usage_ja") or ""),
    ]
    return " ".join(part for part in parts if part).lower()
