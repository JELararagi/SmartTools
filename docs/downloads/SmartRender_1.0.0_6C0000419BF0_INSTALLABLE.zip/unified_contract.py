CONTRACT_VERSION = 1
EXTENSION_ID = "smart_render_suite"
CONFIG_FOLDER = "Smart_Render_Suite"
CONFIG_FILE = "Smart_Render_Suite.json"
STATE_SAVE_PATH = "scene.srr_settings.n_panel_state_save"
SECTION_OPEN_PATH = "scene.srr_settings.show_always_on_toggles"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.srr_persistent_toggle_state.known__rendernames__enabled",
    "window_manager.srr_persistent_toggle_state.known__freestyle_svg_exporter__auto_render_hooks",
    "window_manager.srr_persistent_toggle_state.known__sun_position__auto_update_callbacks",
    "window_manager.srr_persistent_toggle_state.known__sun_position__show_north",
    "window_manager.srr_persistent_toggle_state.known__sun_position__show_analemmas",
    "window_manager.srr_persistent_toggle_state.known__sun_position__show_surface",
    "window_manager.srr_persistent_toggle_state.known__profiler__report_enabled",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
PERSISTENCE_ROOTS = (
    "scene.srr_settings",
    # User-authored structured N-panel state.  These collections and their
    # active rows are serialized by settings.py and must be audited through the
    # real add/remove/duplicate/move UI operators.
    "scene.srr_variants",
    "scene.srr_variant_index",
    "scene.srr_queue",
    "scene.srr_queue_index",
    "window_manager.smart_render_suite_search_text",
    "window_manager.smart_render_suite_show_integrated_tools",
    "window_manager.srr_persistent_toggle_state",
)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.srr_settings.name",
    # Derived compatibility mirror rebuilt from the authoritative
    # ``integrated_tool_expanded__<alias>`` booleans.  It is not an editable
    # N-panel setting and must not be treated as an independent scalar.
    "scene.srr_settings.integrated_tool_section_state_json",
    # Internal migration marker, not an editable N-panel setting.  It remains
    # in the payload solely to prevent legacy defaults being applied twice.
    "scene.srr_settings.render_elements_items_initialized",
    # Runtime diagnostic output.  Logs are produced by actions, are not user
    # settings, and deliberately do not survive a restart or scene change.
    "scene.srr_logs",
    "scene.srr_log_index",
    # CollectionProperty rows inherit an internal PropertyGroup ``name``.
    # The N-panel exposes the real variant name / queue label fields instead;
    # these inherited RNA implementation details are not user settings.
    "scene.srr_queue[*].name",
    "window_manager.srr_persistent_toggle_state.name",
    # Inherited PropertyGroup display names are RNA implementation details, not
    # editable N-panel controls.  Pointer selectors within these groups remain
    # persisted as stable type+name records.
    "scene.rendernames.name",
    "scene.sun_pos_properties.name",
    "scene.svg_export.name",
    "window_manager.profiler.name",
    "window_manager.rendernames_global.name",
    # Derived compatibility mirrors of ``scene.rendernames``.  The global
    # group's remaining fields are persisted, while the canonical resident
    # switch is the top-level ``known__rendernames__enabled`` control and the
    # obsolete preview timer is permanently on-demand.
    "window_manager.rendernames_global.enabled",
    "window_manager.rendernames_global.auto_refresh_preview",
    "window_manager.smart_render_sun_position_prefs.name",
    "scene.rendernames.enabled",
    "scene.rendernames.auto_refresh_preview",
    "scene.rendernames.preview",
    "scene.sun_pos_properties.auto_update_callbacks",
    "scene.sun_pos_properties.show_north",
    "scene.sun_pos_properties.show_analemmas",
    "scene.sun_pos_properties.show_surface",
    "scene.svg_export.auto_render_hooks",
    "window_manager.profiler.report_enabled",
    # Lazy tools have their own authoritative settings.  The feature proxies are
    # navigation buttons, while the seven ``known__`` properties above are the
    # stable always-on controls and are intentionally persisted here.
    "window_manager.srr_persistent_toggle_state.feature__*",
)
PERSISTED_DYNAMIC_RNA_PATTERNS = (
    # Integrated-tool settings exist only after that individual tool is loaded.
    # The central proxy toggles above remain available without loading them.
    "scene.rendernames",
    "scene.sun_pos_properties",
    "scene.svg_export",
    "scene.render_preset_settings",
    "scene.ufrp",
    "scene.overscan_settings",
    "window_manager.profiler",
    "window_manager.camera_plane_settings",
    "window_manager.rendernames_global",
    "window_manager.smart_render_k_tools_prefs",
    "window_manager.smart_render_camera_rigs_prefs",
    "window_manager.smart_render_sun_position_prefs",
    "window_manager.smart_render_ufrp_prefs",
    "window_manager.smart_render_smart_settings",
    # Registered by pseudo_rendering_farm when that integrated tool is loaded.
    "scene.pseudo_rendering_farm_instances",
    # Registered by frame_range_renderer when that integrated tool is loaded.
    "scene.frame_range_input",
)
ROOT_PANEL_IDS = (
    "SRR_PT_MAIN_PANEL",
)
