"""Construct distributable feature inventories and live, scene-based diagnostic reports."""
from collections import Counter
from statistics import fmean
import bpy
from . import catalog
def groups():
    out=[]
    for group in bpy.data.node_groups:
        k=group.get('sgs_feature_id');f=catalog.FEATURE_BY_ID.get(k)
        if f:out.append(dict(name=group.name,feature_id=k,category=f['category'],design_domain=catalog.domain_id(f),nodes=len(group.nodes),links=len(group.links),complexity_score=len(group.nodes)+len(group.links),is_pack=False,pack_id='',recipe=catalog.PUBLIC['features'].get(k,{}).get('effect',''),requirement_code=k))
    return out
def facts():
    names=dict(catalog.PUBLIC['items']['feature_items']);domains=dict(catalog.PUBLIC['items']['design_domain_items'])
    ja_categories=dict(catalog.JA['category_items']);ja_packs=dict(catalog.JA['pack_items']);ja_features=dict(catalog.JA['feature_items']);ja_domains=dict(catalog.JA['design_domain_items'])
    category_table=[{'id':k,'label_en':label,'label_ja':ja_categories[k],'summary_en':label,'summary_ja':ja_categories[k]} for k,label in catalog.PUBLIC['items']['category_items']]
    pack_names=dict(catalog.PUBLIC['items']['pack_items']);packs=[{**p,'label_en':pack_names[p['id']],'label_ja':ja_packs[p['id']],'description_en':str(len(p['feature_ids']))+' capsules','description_ja':str(len(p['feature_ids']))+' カプセル'} for p in catalog.PACKS]
    features=[]
    for i,f in enumerate(catalog.FEATURES):
        domain=catalog.domain_id(f);d=domains.get(domain,domain);k=f['id'];label=names[k];effect=catalog.PUBLIC['features'][k]['effect']
        features.append({**f,'design_domain_id':domain,'index':i,'label_en':label,'label_ja':ja_features[k],'design_domain':d,'design_domain_en':d,'design_domain_ja':ja_domains.get(domain,domain),'recipe':effect,'keywords':[f['category'],domain],'implementation':'Geometry Nodes','priority':0,'requirement_code':k,'source_feature':k,'source_system':'Smart Geometry','summary_en':f'Apply {label} to selected geometry.','summary_ja':f'選択したジオメトリに {label} を適用します。','tooltip_en':label,'tooltip_ja':ja_features[k]})
    return category_table,packs,features
def coverage():
    categories,packs,features=facts();domains=Counter(f['design_domain_id'] for f in features)
    return {'schema':'smart_geometry_suite_design_coverage','version':'1.0.0','categories':dict(Counter(f['category'] for f in features)),'design_domains':dict(Counter(f['design_domain_en'] for f in features)),'design_domains_ja':dict(Counter(f['design_domain_ja'] for f in features)),'packs':len(packs),'total_features':len(features),'policy':'Independently built from public behavior','native_composite_capsules':sum(f['recipe']!='pass' for f in features),'document_requirement_capsules':len(features),'added_v7_features':[],'precision_upgrade':'Surface field analysis','precision_version':'1.0.0','v7_command_precision_capsules':sum('precision' in f['id'] for f in features),'v7_precision_coverage':dict(Counter(f['recipe'] for f in features)),'v8_operation_grade_capsules':sum('v8' in f['id'] for f in features)}
def inventory():
    categories,packs,features=facts()
    return {'schema':'smart_geometry_suite_feature_inventory','version':'1.0.0','maintainer':'JELararagi','copyright':'2026 JELararagi','document':'Smart Geometry','features':features,'feature_count':len(features),'categories':categories,'category_count':len(categories),'packs':packs,'pack_count':len(packs),'coverage':coverage(),'precision_upgrade':'Surface field analysis','independence_policy':'Independent Blender implementation'}
def diagnostics(ctx):
    out=[];resources=groups();meshes=[]
    for o in ctx.scene.objects:
        mesh=None;score=0
        if o.type=='MESH':
            fields=[a.name for a in o.data.attributes if a.name.startswith('sgs_')];score=len(o.data.vertices)+len(o.data.polygons)
            mesh={'vertices':len(o.data.vertices),'edges':len(o.data.edges),'faces':len(o.data.polygons),'attributes':fields};meshes.append(mesh)
        out.append({'name':o.name,'type':o.type,'selected':o.select_get(),'active':o==ctx.active_object,'smart_generated':bool(o.get('smart_geometry_suite_generated')),'algorithm':o.get('sgs_algorithm',''),'builder':o.get('sgs_builder',''),'mesh':mesh,'modifiers':[m.name for m in o.modifiers],'complexity_score':score+len(o.modifiers)})
    names=[a[0] for a in catalog.PUBLIC['fields']['create_terrain']];found={g['feature_id'] for g in resources}
    def precision(prefix):
        keys=[k for k in names if k.startswith(prefix)];stats=[{'mesh':m,'completeness':len(set(m['attributes'])&set(keys))/max(1,len(keys))} for m in meshes]
        return {'schema':'smart_geometry_suite_precision','attribute_contract':keys,'objects':stats,'mean_attribute_completeness':fmean([s['completeness'] for s in stats]) if stats else 0}
    counts={'features':len(catalog.FEATURES),'categories':len(catalog.PUBLIC['items']['category_items']),'packs':len(catalog.PACKS),'generated_node_groups':len(resources),'scene_objects':len(out),'smart_objects':sum(o['smart_generated'] for o in out),'custom_icons':26,'visual_references':5}
    settings=ctx.window_manager.smart_geometry_suite_settings
    def completeness(prefix,key,ui=False):
        record=precision(prefix);record[key]=record.pop('mean_attribute_completeness')
        if ui:record.update(ui_contract='Smart Geometry',custom_icon_count=counts['custom_icons'])
        return record
    def attribute_mean(key):
        values=[]
        for obj in ctx.scene.objects:
            if obj.type!='MESH':continue
            field=obj.data.attributes.get('sgs_'+key)
            if field and field.data_type in ('FLOAT','INT','BOOLEAN'):values.extend(float(v.value) for v in field.data)
        return fmean(values) if values else 0.
    command={'schema':'smart_geometry_suite_command_precision','ui_assets':counts['custom_icons']+counts['visual_references']}
    for key,attr in [('v7_precision','v7_precision'),('topology_risk','topology_risk'),('attribute_confidence','attribute_confidence'),('distribution_priority','distribution_priority'),('selection_clarity','selection_clarity'),('material_wear','material_wear'),('command_quality','command_score')]:command[key+'_mean']=attribute_mean(attr)
    operation=completeness('sgs_v8_','mean_v8_completeness',True)
    operation.update(icon_canvas=32,reference_image_count=counts['visual_references'])
    return {'schema':'smart_geometry_suite_diagnostics','suite_version':'1.0.0','feature_coverage':coverage(),'coverage_health':{'catalog_features':counts['features'],'generated_feature_groups':len(found),'missing_feature_groups':sorted(catalog.FEATURE_BY_ID.keys()-found),'coverage_ratio':len(found)/max(1,counts['features'])},'objects':out,'generated_node_groups':resources,'heatmap_top_node_groups':sorted(resources,key=lambda x:x['complexity_score'],reverse=True)[:10],'heatmap_top_objects':sorted(out,key=lambda x:x['complexity_score'],reverse=True)[:10],'counts':counts,'precision_overdrive':precision('sgs_'),'hyper_precision':completeness('sgs_','mean_hyper_completeness'),'v7_command_precision':command,'interface_precision':completeness('sgs_v7_','mean_v7_completeness',True),'operation_grade_precision':operation,'always_on':{'schema':'smart_geometry_suite_always_on','features':{p.identifier:bool(getattr(settings,p.identifier)) for p in settings.bl_rna.properties if p.identifier.startswith('always_on_')}}}
