"""Operator actions shared between the sidebar, Blender search and Python calls."""
import csv,json,operator,os,re,shutil
from pathlib import Path
import bpy
from . import catalog,scene_io as io,landscape as land,capsules,debris_workflows
from .geometry_fields import point_fields,write,clamp
from .max_procedural_primitives import runtime
from .grease_mesh import stroke_tools
ROOT=Path(__file__).resolve().parent
MANUAL='https://jelararagi.github.io/SmartTools/manuals/SmartGeometry/'
def folder(name):
    p=Path(bpy.utils.user_resource('CONFIG',create=True))/'Smart_Geometry_Suite'/name;p.mkdir(parents=True,exist_ok=True);return p
def documentation(ctx):
    return MANUAL if catalog.is_japanese(ctx) else MANUAL.replace('/manuals/','/en/manuals/')
def report_export(ctx,name):
    if name=='export_icon_reference_sheet':
        target=folder('icons')/'smart_geometry_suite_icon_reference_v8.png';shutil.copyfile(ROOT/'assets/references/icon_reference_sheet_v8.png',target);return target
    exports={'export_usd_manifest':('interop','usd_sidecar_manifest'),'export_bundle_manifest':('interop','bundle_manifest'),'export_design_coverage':('reports','design_coverage'),'export_diagnostics':('reports','diagnostics'),'export_inventory':('reports','feature_inventory')}
    direct,stem=exports[name]
    from . import reports
    if name=='export_inventory':out=reports.inventory()
    elif name=='export_design_coverage':
        out=reports.coverage()
        icons=len(list((ROOT/'icons').glob('*.png')));plates=len(list((ROOT/'assets/references').glob('*.png')))
        out['v7_command_precision']={'capsules':out.pop('v7_command_precision_capsules'),'additional_capsules':[f['id'] for f in catalog.FEATURES if f['category']=='command_precision'],'custom_icons':icons,'ui_panels':len([p for p in bpy.types.Panel.__subclasses__() if '_PT_sgs_' in getattr(p,'bl_idname','')]),'visual_references':plates,'borderless_full_canvas_icon_policy':True}
        out['v8_operation_grade']={'capsules':out.pop('v8_operation_grade_capsules'),'commercial_name_isolation':True,'icon_assets':icons,'image_text_policy':'Separate captions in the interface','reference_images':plates}
        out['v7_precision_coverage']={'interface_attributes':sorted({a[0] for fields in catalog.PUBLIC['fields'].values() for a in fields if a[0].startswith('sgs_v7_')}),'ui_assets':icons+plates,'workflow_operators':len(catalog.PUBLIC['fields'])}
    else:
        out=reports.diagnostics(ctx)
        if name=='export_bundle_manifest':out.update(bundle_note='Geometry Nodes and procedural geometry',ui_assets={'icon_style':'RGBA transparent','icon_canvas':32,'reference_images':5})
        if name=='export_usd_manifest':out.update(usd_note='Sidecar for scene attributes',suggested_primvars_v8=sorted({a[0] for v in catalog.PUBLIC['fields'].values() for a in v}))
    file=folder(direct)/('smart_geometry_suite_'+stem+'.json');out.update(catalog.PUBLIC.get('report_schemas',{}).get(file.name,{}));partial=file.with_suffix('.json.'+str(os.getpid())+'.part');partial.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n','utf8');os.replace(partial,file);return file

def selection(obj,settings):
    mesh=obj.data;tokens=re.split(r'[,;|\s]+',settings.selection_string.strip().lower());indices=set()
    methods={'>':operator.gt,'<':operator.lt,'>=':operator.ge,'<=':operator.le,'==':operator.eq,'!=':operator.ne}
    for token in tokens:
        if token in ('all','*'):indices.update(range(len(mesh.vertices)));continue
        if token in ('none',''):continue
        if token.startswith('random:'):
            from random import Random
            try:fraction=float(token.partition(':')[2])
            except ValueError:continue
            rng=Random(settings.random_seed);indices.update(i for i in range(len(mesh.vertices)) if rng.random()<fraction);continue
        number=re.fullmatch(r'(?:id:)?(\d+)(?:-(\d+))?',token)
        if number:
            a,b=int(number[1]),int(number[2] or number[1]);indices.update(range(max(0,min(a,b)),min(len(mesh.vertices)-1,max(a,b))+1));continue
        cmp=re.fullmatch(r'@?([a-z][a-z0-9_]*)(>=|<=|!=|==|>|<)(-?\d+(?:\.\d+)?)',token)
        if cmp:
            name=cmp[1] if cmp[1].startswith('sgs_') else 'sgs_'+cmp[1];field=mesh.attributes.get(name)
            if field and field.domain=='POINT' and field.data_type in ('FLOAT','INT','BOOLEAN'):indices.update(i for i,x in enumerate(field.data) if methods[cmp[2]](x.value,float(cmp[3])))
    ordered=sorted(indices);mask=[int(i in indices) for i in range(len(mesh.vertices))]
    for v,x in zip(mesh.vertices,mask):v.select=bool(x)
    attr=mesh.attributes.get('sgs_selection');write(mesh,'sgs_selection',attr.data_type if attr else 'FLOAT',mask)
    group=obj.vertex_groups.get('SGS Selection') or obj.vertex_groups.new(name='SGS Selection');group.remove(list(range(len(mesh.vertices))))
    if ordered:group.add(ordered,1,'REPLACE')
    return len(indices)

def heatmap(ctx,s,duplicate=False):
    o=land.mesh_source(ctx)
    if duplicate:
        copy=o.copy();copy.data=o.data.copy();copy.name='SGS Attribute Snapshot '+o.name[:36];ctx.collection.objects.link(copy);io._mark_owned(copy,'attribute_snapshot');o=copy
    attr=o.data.attributes.get(s.debug_attribute)
    if not attr:point_fields(o,s,'create_greeble_blocks');attr=o.data.attributes.get(s.debug_attribute)
    if not attr or attr.domain!='POINT':raise ValueError('Choose a numeric point attribute')
    vals=[getattr(x,'value',0) for x in attr.data];lo=min(vals,default=0);hi=max(vals,default=1);r=max(.00001,hi-lo)
    colors=[(min(1,2*t),max(0,1-abs(2*t-1)),max(0,1-2*t),1) for t in ((v-lo)/r for v in vals)];write(o.data,'sgs_debug_heatmap','FLOAT_COLOR',colors)
    mat=io._material('SGS Debug Heatmap Material',(1,1,1,1));nt=mat.node_tree
    vertex=next((n for n in nt.nodes if n.type=='VERTEX_COLOR'),None) or nt.nodes.new('ShaderNodeVertexColor');vertex.layer_name='sgs_debug_heatmap';shader=next(n for n in nt.nodes if n.type=='BSDF_PRINCIPLED');nt.links.new(vertex.outputs['Color'],shader.inputs['Base Color'])
    if mat.name not in o.data.materials:o.data.materials.append(mat)
    index=o.data.materials.find(mat.name)
    for f in o.data.polygons:f.material_index=index
    io._select_only(ctx,[o]);return o

def feature_visual(ctx,s,key):
    if key in ('terrain','environment','landscape'):return land.terrain(ctx,s)
    if key in ('scatter','distribution'):return land.scatter(ctx,s)
    if key in ('fragment','fragmentation'):return land.fragment(ctx,s)
    if key in ('growth','organic'):return land.curves(ctx,s,False)
    if key in ('building','structure'):return land.building(ctx,s)
    if key in ('diagnostics','inspect'):return report_export(ctx,'export_diagnostics')
    if key in ('heatmap','attribute'):return heatmap(ctx,s)
    if key in ('refine','precision','polish'):
        for o in ctx.selected_objects:
            if o.type=='MESH':point_fields(o,s,'create_greeble_blocks')
        return
    raise ValueError('Unknown workflow: '+key)

def execute(self,ctx):
    op_id=self.bl_rna.identifier.lower().replace('_ot_','.');name=op_id.split('.')[-1];s=ctx.window_manager.smart_geometry_suite_settings
    if op_id.startswith('gptools.'):return stroke_tools.execute(name,ctx,self)
    if op_id.startswith('jel_max.'):
        if name in ('add_generator','draw_generator'):
            o=runtime.create_parametric_object(self.generator_id);io._select_only(ctx,[o])
        elif name=='update_all':runtime.update_all(True)
        elif name in ('update_selected','refresh_selected'):
            for o in tuple(ctx.selected_objects):runtime.regenerate_object(o,True)
        elif name=='install_assets':
            # Native local assets contain data produced by the same builder as manual Add.
            path=folder('assets')/'Smart Geometry Primitives.blend'
            output=set()
            try:
                for k in runtime.GENERATOR_SPECS:
                    o=runtime.create_parametric_object(k,link=False);output.add(o);o.asset_mark()
                bpy.data.libraries.write(str(path),output,fake_user=True,compress=True)
                libraries=ctx.preferences.filepaths.asset_libraries
                if not any(Path(lib.path).resolve()==path.parent.resolve() for lib in libraries if lib.path):
                    libraries.new(name='Max Primitives',directory=str(path.parent))
            finally:
                for ob in output:
                    d=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
                    if not d.users:(bpy.data.meshes if isinstance(d,bpy.types.Mesh) else bpy.data.curves).remove(d)
        return {'FINISHED'}
    from . import lifecycle
    if name.startswith(('create_','apply_','refine_','refresh_')):lifecycle.on_action(ctx,name)
    creation={'create_terrain':land.terrain,'create_scatter_points':land.scatter,'relax_distribution_points':land.relax,'create_distribution_proxy_instances':land.proxy,'create_building_proxy':land.building,'create_greeble_blocks':land.greeble,'explode_mesh_to_pieces':land.fragment}
    if name in creation:creation[name](ctx,s)
    elif name in ('create_flow_network','create_ivy_curve'):land.curves(ctx,s,name=='create_flow_network')
    elif name=='create_demo_scene':land.terrain(ctx,s);land.scatter(ctx,s);land.proxy(ctx,s)
    elif name=='debris_generate':debris_workflows.generate(ctx,ctx.scene.smart_geometry_suite_debris,io)
    elif name=='import_csv_points':land.csv_points(ctx,s,self.filepath)
    elif name in ('create_attribute_heatmap','create_attribute_snapshot'):heatmap(ctx,s,name.endswith('snapshot'))
    elif name=='apply_selection_string':selection(land.mesh_source(ctx),s)
    elif name=='add_standard_attributes':point_fields(land.mesh_source(ctx),s,'create_greeble_blocks')
    elif name=='apply_feature':capsules.apply(ctx,self.feature_id or s.active_feature)
    elif name in ('apply_full_independent_suite','apply_pack'):
        keys=catalog.FEATURES if name=='apply_full_independent_suite' else catalog.features_for_pack(self.pack_id or s.active_pack)
        for f in keys:capsules.apply(ctx,f['id'])
    elif name in ('create_node_library','rebuild_node_library'):
        for f in catalog.FEATURES:capsules.tree(ctx,f['id'],replace=name.startswith('rebuild'))
    elif name=='remove_generated_node_groups':capsules.cleanup()
    elif name.startswith('export_'):self.report({'INFO'},str(report_export(ctx,name)))
    elif name=='refresh_diagnostics':report_export(ctx,'export_diagnostics')
    elif name in ('polish_precision_overdrive','refine_scene_precision'):feature_visual(ctx,s,'refine')
    elif name=='run_visual_workflow':feature_visual(ctx,s,self.workflow_id)
    elif name=='apply_precision_preset':
        preset=self.preset_id or s.precision_preset
        if preset not in ('preview','production','extreme'):raise ValueError('Unknown preset')
        values=catalog.PUBLIC.get('presets',{}).get(preset,{})
        for key,v in values.items():
            if hasattr(s,key):setattr(s,key,v)
        s.precision_preset=preset
    elif name=='toggle_ui_section':
        k=self.section_key
        if not k.startswith('ui_') or not hasattr(s,k):raise ValueError('Unknown section')
        setattr(s,k,not getattr(s,k))
    elif name=='open_help':
        key=self.help_key or self.topic or 's1';anchors={'s1','first-task','f1','f2','f3','f4','f5','f6','f7','f8','f9','f10'};fragment=key if key in anchors else 's1'
        def display(menu,context):
            menu.layout.label(text=catalog.text('Generate terrain, then select it to place markers on its surface.','地形を作成し、選択した地形の面に確認用の点を散布できます。',context))
            button=menu.layout.operator('wm.url_open',text=catalog.text('Open user guide','解説書を開く',context),icon='URL');button.url=documentation(context)+'#'+fragment
        if not bpy.app.background:ctx.window_manager.popup_menu(display,title='Smart Geometry',icon='QUESTION')
    elif name=='debris_open_url':
        project='https://github.com/TheOnlyAaron/Debris_Maker2'
        urls={'PROJECT':project,'HELP':'https://www.scriptspot.com/3ds-max/scripts/debrismaker2','FEATURE':project+'/issues','BUG':project+'/issues'}
        bpy.ops.wm.url_open(url=urls[self.action])
    elif name=='open_visual_reference':
        path=ROOT/'assets/references/workflow_reference.png';image=bpy.data.images.load(str(path),check_existing=True)
        area=next((a for a in ctx.screen.areas if a.type=='IMAGE_EDITOR'),None) or ctx.area
        if area:area.type='IMAGE_EDITOR';area.spaces.active.image=image
    elif name=='debris_open_modules_dir':bpy.ops.wm.path_open(filepath=str(folder('modules')))
    elif name=='debris_refresh_modules':
        settings=ctx.scene.smart_geometry_suite_debris
        configured={item.identifier for item in settings.bl_rna.properties['module'].enum_items}
        available={key for key,handler in debris_workflows.OPERATIONS.items() if callable(handler)}
        missing=configured-available
        if missing:raise ValueError('Unavailable generators: '+', '.join(sorted(missing)))
        if ctx.area:ctx.area.tag_redraw()
        self.report({'INFO'},catalog.text(f'{len(available)} debris generators available',f'{len(available)}種類のデブリを使用できます',ctx))
    elif name=='debris_about':
        message=catalog.text('Generate debris from a seed and editable shape settings.','種類とシードを選び、形や大きさを調整してデブリを作成します。',ctx)
        if bpy.app.background:self.report({'INFO'},message)
        else:
            def info(menu,context):
                menu.layout.label(text=message)
                link=menu.layout.operator('wm.url_open',text=catalog.text('Debris documentation','デブリの使い方',context),icon='HELP')
                link.url=documentation(context)+'#f7'
            ctx.window_manager.popup_menu(info,title='Smart Geometry')
    elif name=='debris_open_window':
        self.report({'INFO'},catalog.text('The debris generator is available in the Smart Geometry sidebar.','サイドバーのSmart Geometryでデブリを生成できます。',ctx))
    elif name=='reload_custom_icons':
        from . import interface
        interface.load_icons()
    else:raise ValueError(name)
    return {'FINISHED'}
class Operation:
    @classmethod
    def poll(cls,ctx):
        if not cls.bl_idname.startswith('gptools.'):return True
        op=cls.bl_idname.split('.')[1];active=ctx.active_object
        if ctx.mode!='OBJECT' or active is None:return False
        if op=='apply_all_modifiers':return any(len(obj.modifiers) for obj in ctx.selected_objects)
        if op in ('bool_cut','knife_cut'):return {'MESH','GREASEPENCIL'}.issubset({obj.type for obj in ctx.selected_objects})
        return active.type=='GREASEPENCIL'
    def invoke(self,ctx,event):
        if self.bl_idname in ('gptools.bool_cut','gptools.knife_cut'):return ctx.window_manager.invoke_props_dialog(self)
        return self.execute(ctx)
    def execute(self,context):
        try:return execute(self,context)
        except (ValueError,KeyError,OSError,RuntimeError) as exc:self.report({'WARNING'},str(exc));return {'CANCELLED'}
