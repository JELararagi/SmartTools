# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import math
from pathlib import Path
import tomllib
from typing import Any

import bpy

from . import catalog, node_factory, storage


def _release_version() -> str:
    manifest = Path(__file__).with_name("blender_manifest.toml")
    with manifest.open("rb") as stream:
        return tomllib.load(stream)["version"]


_NUMERIC_ATTR_SAMPLE_LIMIT_DEFAULT = 2048


def _custom_icon_count() -> int:
    try:
        from . import icons
        return len(icons.bundled_icon_filenames())
    except Exception:
        return 0


def _settings(context=None):
    try:
        return getattr((context or bpy.context).window_manager, 'smart_geometry_suite_settings', None)
    except Exception:
        return None


def _sample_limit(context=None) -> int:
    settings = _settings(context)
    try:
        return max(16, int(getattr(settings, 'diagnostic_sample_limit', _NUMERIC_ATTR_SAMPLE_LIMIT_DEFAULT) or _NUMERIC_ATTR_SAMPLE_LIMIT_DEFAULT))
    except Exception:
        return _NUMERIC_ATTR_SAMPLE_LIMIT_DEFAULT


def _numeric_value(item, default: float = 0.0) -> float:
    try:
        if hasattr(item, 'value'):
            return float(item.value)
        if hasattr(item, 'vector'):
            vec = item.vector
            return math.sqrt(float(vec[0]) ** 2 + float(vec[1]) ** 2 + float(vec[2]) ** 2)
        if hasattr(item, 'color'):
            col = item.color
            return float(sum(col[:3]) / 3.0)
    except Exception:
        pass
    return float(default)


def _histogram(values: list[float], bins: int = 8) -> list[int]:
    if not values:
        return []
    mn = min(values)
    mx = max(values)
    if abs(mx - mn) <= 1e-12:
        result = [0] * bins
        result[0] = len(values)
        return result
    result = [0] * bins
    for value in values:
        idx = min(bins - 1, max(0, int((value - mn) / (mx - mn) * bins)))
        result[idx] += 1
    return result


def _attr_stats(attr, sample_limit: int) -> dict[str, Any]:
    data = list(getattr(attr, 'data', []) or [])
    length = len(data)
    sample = data[:sample_limit]
    values = [_numeric_value(item) for item in sample]
    payload: dict[str, Any] = {
        'name': str(getattr(attr, 'name', '')),
        'data_type': str(getattr(attr, 'data_type', '')),
        'domain': str(getattr(attr, 'domain', '')),
        'length': length,
        'sampled': len(values),
    }
    if values:
        hist = _histogram(values, 8)
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / max(1, len(values))
        ranked = sorted(values)
        def pct(q: float) -> float:
            if not ranked:
                return 0.0
            pos = max(0, min(len(ranked) - 1, int(round((len(ranked) - 1) * q))))
            return ranked[pos]
        total = max(1, sum(hist))
        entropy = -sum((h / total) * math.log2(h / total) for h in hist if h)
        payload.update({
            'min': min(values),
            'max': max(values),
            'mean': mean,
            'stdev': math.sqrt(max(0.0, variance)),
            'p05': pct(0.05),
            'p50': pct(0.50),
            'p95': pct(0.95),
            'entropy8': entropy,
            'histogram8': hist,
        })
    return payload


def _mesh_stats(obj, context=None) -> dict[str, Any]:
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return {}
    sample_limit = _sample_limit(context)
    attrs = []
    try:
        for attr in getattr(mesh, 'attributes', []) or []:
            attrs.append(_attr_stats(attr, sample_limit))
    except Exception:
        pass
    vertices = len(getattr(mesh, 'vertices', []) or [])
    edges = len(getattr(mesh, 'edges', []) or [])
    polygons = len(getattr(mesh, 'polygons', []) or [])
    attr_count = len(attrs)
    risk = 'low'
    if vertices > 250000 or polygons > 250000 or attr_count > 48:
        risk = 'high'
    elif vertices > 75000 or polygons > 75000 or attr_count > 24:
        risk = 'medium'
    return {
        'vertices': vertices,
        'edges': edges,
        'polygons': polygons,
        'attributes': attrs,
        'attribute_count': attr_count,
        'complexity_score': vertices + edges * 0.25 + polygons * 1.5 + attr_count * 250,
        'performance_risk': risk,
    }


def _modifier_stats(obj) -> list[dict[str, Any]]:
    mods = []
    for mod in list(getattr(obj, 'modifiers', []) or []):
        try:
            group = getattr(mod, 'node_group', None)
            node_count = len(getattr(group, 'nodes', []) or []) if group else 0
            link_count = len(getattr(group, 'links', []) or []) if group else 0
            mods.append({
                'name': mod.name,
                'type': mod.type,
                'smart_generated': bool(mod.get(node_factory.GENERATED_FLAG, False)) if hasattr(mod, 'get') else False,
                'feature_id': str(mod.get('sgs_feature_id', '')) if hasattr(mod, 'get') else '',
                'category': str(mod.get('sgs_category', '')) if hasattr(mod, 'get') else '',
                'recipe': str(mod.get('sgs_recipe', '')) if hasattr(mod, 'get') else '',
                'design_domain': str(mod.get('sgs_design_domain', '')) if hasattr(mod, 'get') else '',
                'requirement_code': str(mod.get('sgs_requirement_code', '')) if hasattr(mod, 'get') else '',
                'node_group': getattr(group, 'name', '') if group else '',
                'nodes': node_count,
                'links': link_count,
                'complexity_score': node_count * 2 + link_count,
            })
        except Exception:
            pass
    return mods


def _object_stats(context=None) -> list[dict[str, Any]]:
    ctx = context or bpy.context
    result = []
    scene = getattr(ctx, 'scene', None)
    for obj in list(getattr(scene, 'objects', []) if scene else []):
        try:
            mesh_payload = _mesh_stats(obj, context) if obj.type == 'MESH' else {}
            result.append({
                'name': obj.name,
                'type': obj.type,
                'selected': bool(obj.select_get()) if hasattr(obj, 'select_get') else False,
                'active': bool(obj == getattr(ctx, 'object', None)),
                'smart_generated': bool(obj.get(node_factory.GENERATED_FLAG, False)) if hasattr(obj, 'get') else False,
                'builder': str(obj.get('sgs_builder', '')) if hasattr(obj, 'get') else '',
                'algorithm': str(obj.get('sgs_algorithm', '')) if hasattr(obj, 'get') else '',
                'mesh': mesh_payload,
                'modifiers': _modifier_stats(obj),
                'complexity_score': float(mesh_payload.get('complexity_score', 0.0)) + sum(float(m.get('complexity_score', 0.0)) for m in _modifier_stats(obj)),
            })
        except Exception:
            pass
    return result


def _node_group_stats() -> list[dict[str, Any]]:
    result = []
    for group in list(getattr(bpy.data, 'node_groups', []) or []):
        try:
            if not bool(group.get(node_factory.GENERATED_FLAG, False)):
                continue
            node_count = len(getattr(group, 'nodes', []) or [])
            link_count = len(getattr(group, 'links', []) or [])
            feature_id = str(group.get('sgs_feature_id', ''))
            pack_id = str(group.get('sgs_pack_id', ''))
            result.append({
                'name': group.name,
                'feature_id': feature_id,
                'pack_id': pack_id,
                'category': str(group.get('sgs_category', '')),
                'recipe': str(group.get('sgs_recipe', '')),
                'design_domain': str(group.get('sgs_design_domain', '')),
                'requirement_code': str(group.get('sgs_requirement_code', '')),
                'nodes': node_count,
                'links': link_count,
                'complexity_score': node_count * 2 + link_count,
                'is_pack': bool(pack_id),
            })
        except Exception:
            pass
    return result


def _coverage_health(groups: list[dict[str, Any]]) -> dict[str, Any]:
    generated_feature_ids = {str(g.get('feature_id')) for g in groups if g.get('feature_id')}
    all_feature_ids = {str(f.get('id')) for f in catalog.FEATURES if f.get('id')}
    missing = sorted(all_feature_ids - generated_feature_ids)
    return {
        'catalog_features': len(all_feature_ids),
        'generated_feature_groups': len(generated_feature_ids),
        'missing_feature_groups': missing[:128],
        'coverage_ratio': (len(generated_feature_ids) / max(1, len(all_feature_ids))),
    }


def diagnostics_payload(context=None) -> dict[str, Any]:
    groups = _node_group_stats()
    objects = _object_stats(context)
    heavy_groups = sorted(groups, key=lambda g: int(g.get('complexity_score') or 0), reverse=True)[:20]
    heavy_objects = sorted(objects, key=lambda o: float(o.get('complexity_score') or 0.0), reverse=True)[:20]
    smart_objects = [o for o in objects if o.get('smart_generated') or o.get('builder')]
    return {
        'schema': 'smart_geometry_suite.diagnostics.v5',
        'suite_version': _release_version(),
        'feature_coverage': catalog.coverage_summary(),
        'coverage_health': _coverage_health(groups),
        'objects': objects,
        'generated_node_groups': groups,
        'heatmap_top_node_groups': heavy_groups,
        'heatmap_top_objects': heavy_objects,
        'counts': {
            'features': len(catalog.FEATURES),
            'categories': len(catalog.CATEGORIES),
            'packs': len(catalog.PACKS),
            'generated_node_groups': len(groups),
            'scene_objects': len(objects),
            'smart_objects': len(smart_objects),
        },
    }


def write_diagnostics(context=None):
    return storage.write_json('smart_geometry_suite_diagnostics.json', diagnostics_payload(context), subdir='reports')


def write_inventory():
    return storage.write_json('smart_geometry_suite_feature_inventory.json', {**catalog.inventory_dict(), "version": _release_version()}, subdir='reports')


def write_design_coverage():
    return storage.write_json('smart_geometry_suite_design_coverage.json', {**catalog.DESIGN_COVERAGE, "version": _release_version()}, subdir='reports')


def write_usd_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.usd_sidecar_manifest.v5'
    payload['usd_note'] = 'Portable sidecar manifest for scene-description and primvar planning. It records neutral Smart Geometry attributes and does not write a native scene-description stage by itself.'
    payload['suggested_primvars'] = [
        'sgs_id', 'sgs_density', 'sgs_mask', 'sgs_variation', 'sgs_height', 'sgs_slope',
        'sgs_curvature', 'sgs_convexity', 'sgs_boundary', 'sgs_edge_distance', 'sgs_selection',
        'sgs_piece_id', 'sgs_scale', 'sgs_biome', 'sgs_wetness', 'sgs_flow', 'sgs_erosion',
        'sgs_sediment', 'sgs_lod', 'sgs_cull', 'sgs_normal', 'sgs_source_face',
        'sgs_aspect', 'sgs_roughness', 'sgs_accessibility', 'sgs_channel', 'sgs_deposition',
        'sgs_stability', 'sgs_visibility_score', 'sgs_habitat_score', 'sgs_flow_direction', 'sgs_debug_heatmap',
    ]
    return storage.write_json('smart_geometry_suite_usd_sidecar_manifest.json', payload, subdir='interop')


def write_bundle_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.bundle_manifest.v5'
    payload['bundle_note'] = 'Independent suite bundle manifest describing generated Smart Geometry capsules, dense attributes, procedural builders, diagnostics, design coverage, and packs.'
    return storage.write_json('smart_geometry_suite_bundle_manifest.json', payload, subdir='interop')

# -----------------------------------------------------------------------------
# Precision Overdrive v5 diagnostics overrides
# -----------------------------------------------------------------------------

_SGS_V4_diagnostics_payload = diagnostics_payload


def _nearest_distance_stats(obj, sample_limit: int) -> dict[str, Any]:
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return {}
    try:
        verts = [obj.matrix_world @ v.co for v in list(mesh.vertices)[:max(0, sample_limit)]]
    except Exception:
        return {}
    if len(verts) < 2:
        return {'count': len(verts)}
    distances = []
    # O(n^2) but explicitly capped by diagnostic_sample_limit.
    for i, v in enumerate(verts):
        best = None
        for j, u in enumerate(verts):
            if i == j:
                continue
            d = (v - u).length
            if best is None or d < best:
                best = d
        if best is not None:
            distances.append(float(best))
    if not distances:
        return {'count': len(verts)}
    mean = sum(distances) / len(distances)
    variance = sum((d - mean) ** 2 for d in distances) / len(distances)
    return {
        'count': len(distances),
        'nearest_min': min(distances),
        'nearest_max': max(distances),
        'nearest_mean': mean,
        'nearest_stddev': variance ** 0.5,
        'blue_noise_uniformity': max(0.0, min(1.0, 1.0 - (variance ** 0.5) / max(mean, 1e-9))),
    }


def _attribute_completeness(obj) -> dict[str, Any]:
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return {'score': 0.0, 'present': [], 'missing': []}
    required = [
        'sgs_id', 'sgs_density', 'sgs_mask', 'sgs_variation', 'sgs_height', 'sgs_slope',
        'sgs_curvature', 'sgs_convexity', 'sgs_boundary', 'sgs_edge_distance', 'sgs_wetness',
        'sgs_flow', 'sgs_erosion', 'sgs_sediment', 'sgs_biome', 'sgs_lod', 'sgs_cull',
        'sgs_quality', 'sgs_habitat_score', 'sgs_visibility', 'sgs_material_id',
    ]
    try:
        names = {a.name for a in mesh.attributes}
    except Exception:
        names = set()
    present = [name for name in required if name in names]
    missing = [name for name in required if name not in names]
    return {'score': len(present) / max(1, len(required)), 'present': present, 'missing': missing}


def diagnostics_payload(context=None) -> dict[str, Any]:
    payload = _SGS_V4_diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.diagnostics.v5'
    payload['suite_version'] = _release_version()
    sample_limit = _sample_limit(context)
    overdrive = []
    try:
        objects = bpy.context.scene.objects if context is None else context.scene.objects
    except Exception:
        objects = []
    for obj in objects:
        if getattr(obj, 'type', None) != 'MESH':
            continue
        mesh = getattr(obj, 'data', None)
        if mesh is None:
            continue
        completeness = _attribute_completeness(obj)
        nearest = {}
        try:
            if len(mesh.polygons) == 0 and len(mesh.vertices) > 1:
                nearest = _nearest_distance_stats(obj, min(sample_limit, 2048))
        except Exception:
            nearest = {}
        overdrive.append({
            'object': obj.name,
            'builder': obj.get('sgs_builder', ''),
            'attribute_completeness': completeness,
            'distribution_quality': nearest,
            'precision': obj.get('sgs_attribute_precision', ''),
            'algorithm': obj.get('sgs_algorithm', ''),
        })
    payload['precision_overdrive'] = {
        'schema': 'v5_overdrive_quality_layer',
        'attribute_contract': 'dense terrain, habitat, visibility, material-intent, quality, stream, and distribution attributes',
        'objects': overdrive,
        'mean_attribute_completeness': (sum(o['attribute_completeness']['score'] for o in overdrive) / max(1, len(overdrive))) if overdrive else 0.0,
    }
    return payload


def write_usd_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.usd_sidecar_manifest.v5'
    payload['usd_note'] = 'Portable sidecar manifest for scene-description and primvar planning. It records neutral Smart Geometry attributes and does not write a native scene-description stage by itself.'
    payload['suggested_primvars'] = [
        'sgs_id', 'sgs_density', 'sgs_mask', 'sgs_variation', 'sgs_height', 'sgs_slope',
        'sgs_curvature', 'sgs_convexity', 'sgs_boundary', 'sgs_edge_distance', 'sgs_selection',
        'sgs_piece_id', 'sgs_scale', 'sgs_biome', 'sgs_wetness', 'sgs_flow', 'sgs_erosion',
        'sgs_sediment', 'sgs_lod', 'sgs_cull', 'sgs_normal', 'sgs_tangent', 'sgs_source_face',
        'sgs_quality', 'sgs_habitat_score', 'sgs_visibility', 'sgs_material_id', 'sgs_channel',
        'sgs_stream_order', 'sgs_strata', 'sgs_deposition', 'sgs_bank', 'sgs_fragment_energy',
    ]
    return storage.write_json('smart_geometry_suite_usd_sidecar_manifest.json', payload, subdir='interop')


def write_bundle_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.bundle_manifest.v5'
    payload['bundle_note'] = 'Independent suite bundle manifest describing generated Smart Geometry capsules, overdrive attributes, procedural builders, diagnostics, design coverage, and packs.'
    return storage.write_json('smart_geometry_suite_bundle_manifest.json', payload, subdir='interop')


# -----------------------------------------------------------------------------
# SGS command-precision diagnostics
# -----------------------------------------------------------------------------

_SGS_V5_diagnostics_payload = diagnostics_payload
_SGS_V5_write_usd_manifest = write_usd_manifest
_SGS_V5_write_bundle_manifest = write_bundle_manifest


def _v7_attribute_names(obj) -> set[str]:
    try:
        return {a.name for a in obj.data.attributes}
    except Exception:
        return set()


def _v7_hyper_completeness(obj) -> dict[str, Any]:
    required = [
        'sgs_principal_curvature', 'sgs_cavity', 'sgs_occlusion', 'sgs_accessibility',
        'sgs_watershed', 'sgs_contour', 'sgs_contour_line', 'sgs_channel_influence',
        'sgs_micro_relief', 'sgs_biome_transition', 'sgs_deposition_balance',
        'sgs_material_blend', 'sgs_distribution_weight', 'sgs_remesh_target_size',
        'sgs_debug_score', 'sgs_nearest_distance', 'sgs_distribution_quality',
        'sgs_distribution_fairness', 'sgs_spacing_error', 'sgs_fragment_contiguity',
    ]
    names = _v7_attribute_names(obj)
    present = [name for name in required if name in names]
    missing = [name for name in required if name not in names]
    return {'score': len(present) / max(1, len(required)), 'present': present, 'missing': missing}


def _v7_mean_attr(obj, name: str) -> float:
    try:
        attr = obj.data.attributes.get(name)
        if attr is None:
            return 0.0
        vals = []
        for item in attr.data[:min(len(attr.data), 4096)]:
            if hasattr(item, 'value'):
                vals.append(float(item.value))
            elif hasattr(item, 'vector'):
                vals.append(float((item.vector[0] ** 2 + item.vector[1] ** 2 + item.vector[2] ** 2) ** 0.5))
        return sum(vals) / max(1, len(vals))
    except Exception:
        return 0.0


def diagnostics_payload(context=None) -> dict[str, Any]:
    payload = _SGS_V5_diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.diagnostics.v7'
    payload['suite_version'] = _release_version()
    try:
        objects = bpy.context.scene.objects if context is None else context.scene.objects
    except Exception:
        objects = []
    hyper_objects = []
    for obj in objects:
        if getattr(obj, 'type', None) != 'MESH':
            continue
        names = _v7_attribute_names(obj)
        if not names:
            continue
        hyper_objects.append({
            'object': obj.name,
            'builder': obj.get('sgs_builder', ''),
            'algorithm': obj.get('sgs_algorithm', ''),
            'hyper_completeness': _v7_hyper_completeness(obj),
            'mean_distribution_quality': _v7_mean_attr(obj, 'sgs_distribution_quality'),
            'mean_distribution_fairness': _v7_mean_attr(obj, 'sgs_distribution_fairness'),
            'mean_channel_influence': _v7_mean_attr(obj, 'sgs_channel_influence'),
            'mean_debug_score': _v7_mean_attr(obj, 'sgs_debug_score'),
            'watershed_count': obj.get('sgs_watershed_count', 0),
            'attribute_count': len(names),
        })
    payload['hyper_precision'] = {
        'schema': 'v7_command_precision_quality_contract',
        'attribute_contract': 'hydrology, watershed, contour, material-blend, accessibility, tangent-relaxed distribution, graph-contiguous fragments, and debug-score attributes',
        'objects': hyper_objects,
        'mean_hyper_completeness': (sum(o['hyper_completeness']['score'] for o in hyper_objects) / max(1, len(hyper_objects))) if hyper_objects else 0.0,
    }
    return payload


def write_usd_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.usd_sidecar_manifest.v7'
    payload['usd_note'] = 'Portable sidecar manifest for neutral Smart Geometry attributes, generated as data only and not as a native scene-description stage.'
    payload['suggested_primvars'] = [
        'sgs_id', 'sgs_density', 'sgs_mask', 'sgs_variation', 'sgs_height', 'sgs_slope',
        'sgs_curvature', 'sgs_convexity', 'sgs_boundary', 'sgs_edge_distance', 'sgs_selection',
        'sgs_piece_id', 'sgs_scale', 'sgs_biome', 'sgs_wetness', 'sgs_flow', 'sgs_erosion',
        'sgs_sediment', 'sgs_lod', 'sgs_cull', 'sgs_normal', 'sgs_tangent', 'sgs_source_face',
        'sgs_quality', 'sgs_habitat_score', 'sgs_visibility', 'sgs_material_id', 'sgs_channel',
        'sgs_stream_order', 'sgs_strata', 'sgs_deposition', 'sgs_bank', 'sgs_fragment_energy',
        'sgs_principal_curvature', 'sgs_cavity', 'sgs_occlusion', 'sgs_accessibility',
        'sgs_watershed', 'sgs_contour', 'sgs_contour_line', 'sgs_channel_influence',
        'sgs_micro_relief', 'sgs_biome_transition', 'sgs_deposition_balance', 'sgs_material_blend',
        'sgs_distribution_weight', 'sgs_remesh_target_size', 'sgs_debug_score', 'sgs_nearest_distance',
        'sgs_distribution_quality', 'sgs_distribution_fairness', 'sgs_spacing_error', 'sgs_fragment_contiguity',
    ]
    return storage.write_json('smart_geometry_suite_usd_sidecar_manifest.json', payload, subdir='interop')


def write_bundle_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.bundle_manifest.v7'
    payload['bundle_note'] = 'Independent suite bundle manifest describing generated Smart Geometry capsules, hyper-precision attributes, procedural builders, diagnostics, design coverage, and packs.'
    return storage.write_json('smart_geometry_suite_bundle_manifest.json', payload, subdir='interop')


# -----------------------------------------------------------------------------
# command-precision diagnostics and manifests
# -----------------------------------------------------------------------------

_SGS_V6_diagnostics_payload = diagnostics_payload
_SGS_V6_write_usd_manifest = write_usd_manifest
_SGS_V6_write_bundle_manifest = write_bundle_manifest


def _v6_attribute_names(obj) -> set[str]:
    return _v7_attribute_names(obj)


def _v6_mean_attr(obj, name: str) -> float:
    return _v7_mean_attr(obj, name)


def _v7_mean_for_attr(objects: list[dict[str, Any]], attr_name: str) -> float:
    values = []
    for obj in objects:
        mesh = obj.get('mesh') or {}
        for attr in mesh.get('attributes') or []:
            if attr.get('name') == attr_name and 'mean' in attr:
                values.append(float(attr.get('mean') or 0.0))
    return sum(values) / len(values) if values else 0.0


def diagnostics_payload(context=None) -> dict[str, Any]:
    payload = _SGS_V6_diagnostics_payload(context)
    objects = payload.get('objects') or []
    ui_assets = {
        'custom_icon_count': _custom_icon_count(),
        'reference_image_count': 2,
        'transparent_borderless_glyph_policy': True,
        'command_deck_enabled': True,
    }
    payload['schema'] = 'smart_geometry_suite.diagnostics.v7'
    payload['suite_version'] = _release_version()
    payload['v7_command_precision'] = {
        'schema': 'v7_command_precision_quality_contract',
        'ui_assets': ui_assets,
        'v7_precision_mean': _v7_mean_for_attr(objects, 'sgs_v7_precision'),
        'topology_risk_mean': _v7_mean_for_attr(objects, 'sgs_topology_risk'),
        'attribute_confidence_mean': _v7_mean_for_attr(objects, 'sgs_attribute_confidence'),
        'distribution_priority_mean': _v7_mean_for_attr(objects, 'sgs_distribution_priority'),
        'selection_clarity_mean': _v7_mean_for_attr(objects, 'sgs_selection_clarity'),
        'material_wear_mean': _v7_mean_for_attr(objects, 'sgs_material_wear'),
        'command_quality_mean': _v7_mean_for_attr(objects, 'sgs_command_quality'),
    }
    payload.setdefault('counts', {})['custom_icons'] = ui_assets['custom_icon_count']
    payload.setdefault('counts', {})['visual_references'] = ui_assets['reference_image_count']
    return payload


def write_usd_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.usd_sidecar_manifest.v7'
    payload['recommended_primvars_v7'] = [
        'sgs_v7_precision', 'sgs_topology_risk', 'sgs_attribute_confidence', 'sgs_material_wear',
        'sgs_uv_seam_intent', 'sgs_distribution_priority', 'sgs_selection_clarity',
        'sgs_patch_id', 'sgs_patch_boundary', 'sgs_command_quality',
    ]
    return storage.write_json('smart_geometry_suite_usd_sidecar_manifest.json', payload, subdir='reports')


def write_bundle_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.bundle_manifest.v7'
    payload['bundle_policy'] = {
        'commercial_name_isolation': True,
        'custom_icon_assets': True,
        'visual_reference_assets': True,
        'localized_panel_text': True,
        'neutral_open_data': True,
    }
    return storage.write_json('smart_geometry_suite_bundle_manifest.json', payload, subdir='reports')

# -----------------------------------------------------------------------------
# SGS interface-precision diagnostics
# -----------------------------------------------------------------------------

_SGS_V7_COMMAND_diagnostics_payload = diagnostics_payload
_SGS_V7_COMMAND_write_usd_manifest = write_usd_manifest
_SGS_V7_COMMAND_write_bundle_manifest = write_bundle_manifest


def _v7_completeness(obj) -> dict[str, Any]:
    required = [
        'sgs_geodesic_boundary_distance', 'sgs_boundary_proximity', 'sgs_height_laplacian',
        'sgs_curvature_laplacian', 'sgs_bitangent', 'sgs_orientation_confidence',
        'sgs_material_wear', 'sgs_material_dust', 'sgs_material_moss', 'sgs_water_accumulation',
        'sgs_asset_priority', 'sgs_operation_confidence', 'sgs_edge_safety',
        'sgs_selection_confidence', 'sgs_material_weathering', 'sgs_debug_priority',
        'sgs_quality_grade', 'sgs_stream_power', 'sgs_sediment_transport',
        'sgs_instance_priority', 'sgs_spacing_score', 'sgs_distribution_entropy',
    ]
    names = _v6_attribute_names(obj)
    present = [name for name in required if name in names]
    missing = [name for name in required if name not in names]
    return {'score': len(present) / max(1, len(required)), 'present': present, 'missing': missing}


def diagnostics_payload(context=None) -> dict[str, Any]:
    payload = _SGS_V7_COMMAND_diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.diagnostics.v7'
    payload['suite_version'] = _release_version()
    try:
        objects = bpy.context.scene.objects if context is None else context.scene.objects
    except Exception:
        objects = []
    interface_objects = []
    for obj in objects:
        if getattr(obj, 'type', None) != 'MESH':
            continue
        names = _v6_attribute_names(obj)
        if not names:
            continue
        interface_objects.append({
            'object': obj.name,
            'builder': obj.get('sgs_builder', ''),
            'algorithm': obj.get('sgs_algorithm', ''),
            'v7_completeness': _v7_completeness(obj),
            'mean_operation_confidence': _v6_mean_attr(obj, 'sgs_operation_confidence'),
            'mean_asset_priority': _v6_mean_attr(obj, 'sgs_asset_priority'),
            'mean_material_weathering': _v6_mean_attr(obj, 'sgs_material_weathering'),
            'mean_debug_priority': _v6_mean_attr(obj, 'sgs_debug_priority'),
            'mean_spacing_score': _v6_mean_attr(obj, 'sgs_spacing_score'),
            'quality_grade_mean': _v6_mean_attr(obj, 'sgs_quality_grade'),
            'attribute_count': len(names),
        })
    payload['interface_precision'] = {
        'schema': 'v7_visual_command_quality_contract',
        'ui_contract': 'borderless maximum-fill custom icon buttons, visual command deck, preset-driven operation profiles, and beginner-readable panel grouping',
        'attribute_contract': 'geodesic boundary distance, material weathering, asset priority, operation confidence, debug priority, spacing entropy, and quality grades',
        'objects': interface_objects,
        'mean_v7_completeness': (sum(o['v7_completeness']['score'] for o in interface_objects) / max(1, len(interface_objects))) if interface_objects else 0.0,
        'custom_icon_count': _custom_icon_count(),
    }
    return payload


def write_usd_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.usd_sidecar_manifest.v7'
    payload['usd_note'] = 'Portable sidecar manifest for neutral Smart Geometry attributes and UI-guided procedural metadata. It records data only and does not write a native scene-description stage.'
    payload['suggested_primvars'] = list(dict.fromkeys([
        'sgs_id', 'sgs_density', 'sgs_mask', 'sgs_variation', 'sgs_height', 'sgs_slope',
        'sgs_curvature', 'sgs_convexity', 'sgs_boundary', 'sgs_edge_distance', 'sgs_selection',
        'sgs_piece_id', 'sgs_scale', 'sgs_biome', 'sgs_wetness', 'sgs_flow', 'sgs_erosion',
        'sgs_sediment', 'sgs_lod', 'sgs_cull', 'sgs_normal', 'sgs_tangent', 'sgs_source_face',
        'sgs_quality', 'sgs_habitat_score', 'sgs_visibility', 'sgs_material_id', 'sgs_channel',
        'sgs_stream_order', 'sgs_strata', 'sgs_deposition', 'sgs_bank', 'sgs_fragment_energy',
        'sgs_principal_curvature', 'sgs_cavity', 'sgs_occlusion', 'sgs_accessibility',
        'sgs_watershed', 'sgs_contour', 'sgs_contour_line', 'sgs_channel_influence',
        'sgs_micro_relief', 'sgs_biome_transition', 'sgs_deposition_balance', 'sgs_material_blend',
        'sgs_distribution_weight', 'sgs_remesh_target_size', 'sgs_debug_score', 'sgs_nearest_distance',
        'sgs_distribution_quality', 'sgs_distribution_fairness', 'sgs_spacing_error', 'sgs_fragment_contiguity',
        'sgs_geodesic_boundary_distance', 'sgs_boundary_proximity', 'sgs_height_laplacian',
        'sgs_curvature_laplacian', 'sgs_bitangent', 'sgs_orientation_confidence',
        'sgs_material_wear', 'sgs_material_dust', 'sgs_material_moss', 'sgs_water_accumulation',
        'sgs_asset_priority', 'sgs_operation_confidence', 'sgs_edge_safety',
        'sgs_selection_confidence', 'sgs_material_weathering', 'sgs_debug_priority',
        'sgs_quality_grade', 'sgs_stream_power', 'sgs_sediment_transport',
        'sgs_instance_priority', 'sgs_spacing_score', 'sgs_distribution_entropy',
    ]))
    return storage.write_json('smart_geometry_suite_usd_sidecar_manifest.json', payload, subdir='interop')


def write_bundle_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.bundle_manifest.v7'
    payload['bundle_note'] = 'Independent suite bundle manifest describing generated capsules, visual command UI, custom icon set, interface-precision attributes, procedural builders, diagnostics, design coverage, and packs.'
    payload['ui_assets'] = {
        'icon_style': 'bundled transparent 32 px custom PNG icons',
        'icon_canvas': '32x32 RGBA',
        'reference_image': 'assets/references/workflow_reference.png',
    }
    return storage.write_json('smart_geometry_suite_bundle_manifest.json', payload, subdir='interop')


# -----------------------------------------------------------------------------
# SGS operation-grade diagnostics and manifests
# -----------------------------------------------------------------------------

_SGS_V8_BASE_diagnostics_payload = diagnostics_payload
_SGS_V8_BASE_write_usd_manifest = write_usd_manifest
_SGS_V8_BASE_write_bundle_manifest = write_bundle_manifest


def _v8_completeness(obj) -> dict[str, Any]:
    required = [
        'sgs_v8_surface_saliency', 'sgs_v8_field_coherence', 'sgs_v8_mask_confidence',
        'sgs_v8_material_signal', 'sgs_v8_material_lane', 'sgs_v8_distribution_stability',
        'sgs_v8_hydrology_priority', 'sgs_v8_detail_budget', 'sgs_v8_selection_resilience',
        'sgs_v8_interaction_score', 'sgs_v8_artifact_risk', 'sgs_v8_lod_score',
        'sgs_v8_ui_inspection_score', 'sgs_v8_stability_grade', 'sgs_v8_safety_grade',
    ]
    names = _v6_attribute_names(obj)
    present = [name for name in required if name in names]
    missing = [name for name in required if name not in names]
    return {'score': len(present) / max(1, len(required)), 'present': present, 'missing': missing}


def diagnostics_payload(context=None) -> dict[str, Any]:
    payload = _SGS_V8_BASE_diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.diagnostics.v8_1'
    payload['suite_version'] = _release_version()
    try:
        objects = bpy.context.scene.objects if context is None else context.scene.objects
    except Exception:
        objects = []
    v8_objects = []
    for obj in objects:
        if getattr(obj, 'type', None) != 'MESH':
            continue
        names = _v6_attribute_names(obj)
        if not names:
            continue
        v8_objects.append({
            'object': obj.name,
            'builder': obj.get('sgs_builder', ''),
            'algorithm': obj.get('sgs_algorithm', ''),
            'v8_completeness': _v8_completeness(obj),
            'mean_interaction_score': _v6_mean_attr(obj, 'sgs_v8_interaction_score'),
            'mean_artifact_risk': _v6_mean_attr(obj, 'sgs_v8_artifact_risk'),
            'mean_distribution_stability': _v6_mean_attr(obj, 'sgs_v8_distribution_stability'),
            'mean_hydrology_priority': _v6_mean_attr(obj, 'sgs_v8_hydrology_priority'),
            'mean_ui_inspection_score': _v6_mean_attr(obj, 'sgs_v8_ui_inspection_score'),
            'attribute_count': len(names),
        })
    payload['operation_grade_precision'] = {
        'schema': 'v8_1_operation_grade_quality_and_persistent_runtime_contract',
        'ui_contract': '32px bundled transparent 32 px custom PNG icons, large visual command deck, clock-marked persistent toggles, icon-only reference diagrams, localized labels outside image assets',
        'attribute_contract': 'surface saliency, field coherence, mask confidence, material lanes, distribution stability, hydrology priority, detail budget, selection resilience, interaction score, artifact risk, LOD score, and UI inspection score',
        'objects': v8_objects,
        'mean_v8_completeness': (sum(o['v8_completeness']['score'] for o in v8_objects) / max(1, len(v8_objects))) if v8_objects else 0.0,
        'custom_icon_count': _custom_icon_count(),
        'icon_canvas': '32x32 RGBA, borderless, Smart Rig-style black/white maximum-fill glyphs',
        'reference_image_count': 5,
    }
    payload.setdefault('counts', {})['custom_icons'] = _custom_icon_count()
    try:
        from . import always_on
        payload['always_on'] = {
            'schema': 'smart_geometry_suite.always_on_state.v8_1',
            'features': [
                {
                    'id': feature.feature_id,
                    'property': feature.pref_property,
                    'enabled': bool(always_on.feature_value(feature, context)),
                    'default': bool(feature.default),
                    'label': always_on.localized_label(feature, context),
                }
                for feature in always_on.feature_definitions()
            ],
        }
    except Exception:
        payload['always_on'] = {'schema': 'smart_geometry_suite.always_on_state.v8_1', 'features': []}
    payload.setdefault('counts', {})['visual_references'] = 5
    return payload


def write_usd_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.usd_sidecar_manifest.v8_1'
    payload['usd_note'] = 'Portable sidecar manifest for neutral Smart Geometry attributes and UI-guided procedural metadata. It records data only and does not write a native scene-description stage.'
    payload['suggested_primvars_v8'] = list(dict.fromkeys([
        'sgs_v8_surface_saliency', 'sgs_v8_field_coherence', 'sgs_v8_mask_confidence',
        'sgs_v8_material_signal', 'sgs_v8_material_lane', 'sgs_v8_distribution_stability',
        'sgs_v8_hydrology_priority', 'sgs_v8_detail_budget', 'sgs_v8_selection_resilience',
        'sgs_v8_interaction_score', 'sgs_v8_artifact_risk', 'sgs_v8_lod_score',
        'sgs_v8_ui_inspection_score', 'sgs_v8_stability_grade', 'sgs_v8_safety_grade',
        'sgs_v8_riverbank_mask', 'sgs_v8_erosion_confidence', 'sgs_v8_terrain_readability',
        'sgs_v8_spacing_balance', 'sgs_v8_overdraw_risk', 'sgs_v8_instance_readability',
        'sgs_v8_distribution_confidence', 'sgs_v8_fragment_glue', 'sgs_v8_fragment_seam',
        'sgs_v8_fragment_inertia', 'sgs_v8_fragment_readability',
    ]))
    return storage.write_json('smart_geometry_suite_usd_sidecar_manifest.json', payload, subdir='interop')


def write_bundle_manifest(context=None):
    payload = diagnostics_payload(context)
    payload['schema'] = 'smart_geometry_suite.bundle_manifest.v8_1'
    payload['bundle_note'] = 'Independent suite bundle manifest describing generated capsules, 32 px visual command UI, bundled custom icon set, always-on toggle and lazy help policy, operation-grade attributes, procedural builders, diagnostics, design coverage, and packs.'
    payload['ui_assets'] = {
        'icon_style': 'bundled transparent 32 px custom PNG icons',
        'icon_canvas': '32x32 RGBA',
        'reference_images': [
            'assets/references/command_deck_reference.png',
            'assets/references/workflow_reference.png',
            'assets/references/precision_pipeline_reference.png',
            'assets/references/attribute_stack_reference.png',
            'assets/references/icon_reference_sheet_v8.png',
        ],
    }
    return storage.write_json('smart_geometry_suite_bundle_manifest.json', payload, subdir='interop')
