"""Viewport click-drag placement on the cursor's construction plane."""
import bpy
from bpy_extras import view3d_utils
from mathutils import Vector
from . import scene_io
from .max_procedural_primitives import runtime

class Draw:
    def invoke(self,context,event):
        if not context.area or context.area.type!='VIEW_3D':return self.execute(context)
        self.origin=None;self.object=None;self.phase='BASE';self.height_y=0;self.saved=tuple(context.selected_objects);self.old=context.active_object
        context.window_manager.modal_handler_add(self);context.area.header_text_set('Click and drag to size  •  Esc to cancel');return {'RUNNING_MODAL'}
    def point(self,ctx,event):
        depth=self.origin if self.origin is not None else ctx.scene.cursor.location
        return view3d_utils.region_2d_to_location_3d(ctx.region,ctx.region_data,(event.mouse_region_x,event.mouse_region_y),depth)
    def modal(self,ctx,event):
        if event.type in ('ESC','RIGHTMOUSE'):
            if self.object:
                ob=self.object;data=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
                if not data.users:(bpy.data.meshes if isinstance(data,bpy.types.Mesh) else bpy.data.curves).remove(data)
            scene_io._select_only(ctx,self.saved);ctx.view_layer.objects.active=self.old;self.finish_draw(ctx);return {'CANCELLED'}
        if event.type=='LEFTMOUSE' and event.value=='PRESS' and self.origin is None:
            self.origin=self.point(ctx,event);self.object=runtime.create_parametric_object(self.generator_id,location=self.origin);scene_io._select_only(ctx,[self.object]);runtime.begin_interactive_drag();return {'RUNNING_MODAL'}
        if self.object and self.phase=='HEIGHT':
            if event.type=='MOUSEMOVE':
                height=max(.001,abs(event.mouse_region_y-self.height_y)*ctx.space_data.region_3d.view_distance/max(1,ctx.region.height))
                runtime.write_values(self.object,{'height':height});ctx.area.tag_redraw()
            elif event.type=='LEFTMOUSE' and event.value=='PRESS':self.finish_draw(ctx);return {'FINISHED'}
            return {'RUNNING_MODAL'}
        if self.object and event.type=='MOUSEMOVE':
            offset=self.point(ctx,event)-self.origin;size=max(.001,offset.length);params=runtime.read_values(self.object);updates={}
            for k in ('length','width','height','radius','radius1','radius2','size','path_length'):
                if k in params:updates[k]=size*(.5 if k in ('radius','radius1') else .18 if k=='radius2' else 1)
            runtime.write_values(self.object,updates);ctx.area.tag_redraw()
        if self.object and event.type=='LEFTMOUSE' and event.value=='RELEASE':
            if 'height' in runtime.read_values(self.object):
                self.phase='HEIGHT';self.height_y=event.mouse_region_y;ctx.area.header_text_set('Move to set height, then click');return {'RUNNING_MODAL'}
            self.finish_draw(ctx);return {'FINISHED'}
        return {'RUNNING_MODAL'}
    def finish_draw(self,ctx):
        runtime.end_interactive_drag()
        if ctx.area:ctx.area.header_text_set(None)
class SelectFile:
    def invoke(self,ctx,event):
        if self.filepath:return self.execute(ctx)
        ctx.window_manager.fileselect_add(self);return {'RUNNING_MODAL'}
def debris_fields(settings):
    prefix={'CORRUGATED':'corr','CRYSTAL':'gem','GEMSTONES':'gem','PIGEONS':'pigeon','RIVERSTONES':'river','SNOWFLAKES':'snow'}.get(settings.module,settings.module.lower())
    return [k for k in settings.bl_rna.properties.keys() if k.startswith(prefix+'_')]
class DebrisWindow:
    def invoke(self,context,event):return context.window_manager.invoke_props_dialog(self,width=415)
    def draw(self,ctx):
        p=ctx.scene.smart_geometry_suite_debris
        self.layout.prop(p,'module');self.layout.prop(p,'seed')
        for k in debris_fields(p):self.layout.prop(p,k)
        self.layout.operator('smart_geometry_suite.debris_generate')
