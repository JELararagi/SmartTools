"""Sampling and modelling tools for terrain, layout, growth and controlled fragmentation."""
from bisect import bisect_left
from collections import defaultdict
from math import sqrt,sin,cos,pi,tau
from random import Random
import csv
from pathlib import Path
from mathutils import Vector,noise,kdtree
from . import scene_io as io
from .geometry_fields import point_fields,write,clamp
from .mesh_form import MeshForm
def finish(ctx,obj,key):
    p=ctx.window_manager.smart_geometry_suite_settings
    obj['sgs_builder']=key.removeprefix('create_')
    from .catalog import PUBLIC
    for name,value in PUBLIC.get('builder_tags',{}).get(key,{}).items():obj[name]=value
    if obj.type=='MESH':point_fields(obj,p,key)
    io._select_only(ctx,[obj]);return obj

def terrain(ctx,s):
    n=max(2,s.terrain_resolution);size=s.terrain_size;amplitude=s.terrain_height;seed=s.random_seed*.0137
    heights=[]
    for y in range(n):
        for x in range(n):
            u=x/(n-1);v=y/(n-1);position=Vector((u*3.5,v*3.5,seed));primary=noise.fractal(position,1,2,4)
            ridge=1-abs(noise.noise_vector(position*1.7)[0]);heights.append(amplitude*((1-s.terrain_v7_ridge_preservation*.55)*primary+s.terrain_v7_ridge_preservation*.55*ridge))
    rng=Random(s.random_seed)
    for _ in range(s.terrain_hydraulic_droplets):
        x=rng.randrange(n);y=rng.randrange(n);i=y*n+x;carried=0.
        for j in range(s.terrain_hydraulic_iterations):
            options=[q for condition,q in ((x>0,i-1),(x<n-1,i+1),(y>0,i-n),(y<n-1,i+n)) if condition]
            dst=min(options,key=heights.__getitem__);delta=heights[i]-heights[dst]
            if delta<=0:break
            erode=min(delta*.11*s.terrain_channel_strength,amplitude*.004);heights[i]-=erode;carried+=erode
            i=dst;y,x=divmod(i,n)
        heights[i]+=carried
    for i in range(min(64,s.terrain_erosion_iterations)):
        for j in range((i%3)+n,n*n-n,3):
            if j%n not in (0,n-1):
                neighbors=(heights[j-1]+heights[j+1]+heights[j-n]+heights[j+n])*.25
                heights[j]+=(neighbors-heights[j])*(1-s.terrain_v7_ridge_preservation)*.2
    mesh=MeshForm().grid(n-1,n-1,lambda u,v:((u-.5)*size,(v-.5)*size,heights[round(v*(n-1))*n+round(u*(n-1))]))
    return finish(ctx,io.object_from_form(ctx,'SGS Hyper Precision Heightfield Terrain',mesh),'create_terrain')

def mesh_source(ctx):
    obj=ctx.active_object
    if not obj or obj.type!='MESH':raise ValueError('Select a mesh / メッシュを選択してください')
    return obj

def scatter(ctx,s):
    src=mesh_source(ctx);src.data.calc_loop_triangles();triangles=src.data.loop_triangles
    if not triangles:raise ValueError('Select a surface containing faces / 面を持つメッシュを選択してください')
    rng=Random(s.random_seed);total=0.;cdf=[];indices=[]
    for tri in triangles:
        if tri.area>0:total+=tri.area;cdf.append(total);indices.append(tuple(tri.vertices))
    if not indices:raise ValueError('Surface has zero area')
    coords=[];source=[];cells=defaultdict(list);spacing=max(.00001,s.scatter_min_spacing);v=src.data.vertices;budget=s.scatter_count*max(1,s.scatter_candidate_multiplier)
    for trial in range(budget):
        face=bisect_left(cdf,rng.random()*total);a,b,c=[v[i].co for i in indices[face]]
        u=sqrt(rng.random());w=rng.random();point=a*(1-u)+b*u*(1-w)+c*u*w
        normal=(b-a).cross(c-a).normalized();point+=normal*s.scatter_normal_offset
        cell=tuple(int(q//spacing) for q in point)
        if s.scatter_blue_noise and any((point-co).length<spacing for x in (-1,0,1) for y in (-1,0,1) for z in (-1,0,1) for co in cells.get((cell[0]+x,cell[1]+y,cell[2]+z),())):continue
        coords.append(point);source.append(face);cells[cell].append(point)
        if len(coords)>=s.scatter_count:break
    ob=io._mesh_obj(ctx,'SGS Overdrive Surface Distribution Points',coords,[]);ob.matrix_world=src.matrix_world;ob['sgs_source_object']=src.name
    finish(ctx,ob,'create_scatter_points');write(ob.data,'sgs_source_face','INT',source);return ob

def relax(ctx,s):
    ob=mesh_source(ctx);verts=ob.data.vertices;coords=[v.co.copy() for v in verts];source=ctx.scene.objects.get(ob.get('sgs_source_object',''));radius=max(.00001,s.scatter_min_spacing)
    for _ in range(s.scatter_relax_iterations):
        tree=kdtree.KDTree(len(coords))
        for i,p in enumerate(coords):tree.insert(p,i)
        tree.balance();next_points=[]
        for i,p in enumerate(coords):
            push=Vector((0,0,0))
            for co,j,d in tree.find_range(p,radius*1.5):
                if i!=j and d>.000001:push+=(p-co)*(radius*1.5-d)/(radius*1.5)
            co=p+push*.35
            if source and source.type=='MESH':
                hit,loc,norm,_=source.closest_point_on_mesh(co)
                if hit:co=loc+norm*s.scatter_normal_offset
            next_points.append(co)
        coords=next_points
    for v,p in zip(verts,coords):v.co=p
    ob.data.update();return ob

def proxy(ctx,s):
    src=mesh_source(ctx);m=MeshForm()
    for v in src.data.vertices:
        r=s.scatter_radius;co=v.co;start=len(m.vertices)
        m.vertices.extend([tuple(co+Vector(d)*r) for d in ((-1,-1,0),(1,-1,0),(1,1,0),(-1,1,0),(0,0,2))])
        m.faces.extend(tuple(start+i for i in row) for row in ((3,2,1,0),(0,1,4),(1,2,4),(2,3,4),(3,0,4)))
    ob=io.object_from_form(ctx,'SGS Distribution Proxy Instances',m);ob.matrix_world=src.matrix_world;ob['sgs_source_object']=src.name
    return finish(ctx,ob,'create_distribution_proxy_instances')

def curves(ctx,s,flow):
    src=mesh_source(ctx);rng=Random(s.random_seed);points=[v.co.copy() for v in src.data.vertices]
    if not points:raise ValueError('The active mesh has no points')
    neighbors=[[] for _ in points]
    for e in src.data.edges:
        a,b=e.vertices;neighbors[a].append(b);neighbors[b].append(a)
    result=[]
    for i in range(s.drainage_curve_count if flow else s.growth_branches):
        idx=rng.randrange(len(points));line=[points[idx]+Vector((0,0,.02))];used={idx}
        for j in range(min(36,len(points))):
            choices=[k for k in neighbors[idx] if k not in used]
            if not choices:break
            nxt=min(choices,key=lambda k:points[k].z+(0 if flow else rng.uniform(-.1,.1))) if flow else max(choices,key=lambda k:points[k].z+rng.uniform(-.4,.4))
            if flow and points[nxt].z>points[idx].z+.0001:break
            idx=nxt;used.add(idx);line.append(points[idx]+Vector((0,0,.02)))
        if len(line)>1:result.append(line)
    ob=io.curve_object(ctx,'SGS Precision Drainage Flow Network' if flow else 'SGS Overdrive Organic Growth Curves',result,.012 if flow else .023);ob.matrix_world=src.matrix_world;ob['sgs_source_object']=src.name
    return finish(ctx,ob,'create_flow_network' if flow else 'create_ivy_curve')

def building(ctx,s):
    m=MeshForm();n=s.structure_floors
    for i in range(n):
        z=i*.85;m.add_box(-1.8,1.8,-1.3,1.3,z,z+.1)
        for a in (-1.65,1.65):
            for b in (-1.15,1.15):m.add_box(a-.1,a+.1,b-.1,b+.1,z,z+.85)
        for a in range(6):
            x=-1.6+a*.57
            for b in (-1.2,1.2):m.add_box(x,x+.38,b-.035,b+.035,z+.16,z+.66)
    m.add_box(-1.85,1.85,-1.35,1.35,n*.85,n*.85+.11)
    return finish(ctx,io.object_from_form(ctx,'SGS Precision Modular Structure',m),'create_building_proxy')

def greeble(ctx,s):
    src=mesh_source(ctx);m=MeshForm();rng=Random(s.random_seed)
    for face in src.data.polygons:
        coords=[src.data.vertices[i].co.copy() for i in face.vertices];center=face.center.copy();inset=[center+(v-center)*rng.uniform(.65,.79) for v in coords];height=face.area**.5*rng.uniform(.035,.16);rings=m.rings([inset,[p+face.normal*height for p in inset]])
        m.faces.extend((tuple(rings[0][::-1]),tuple(rings[-1])))
    ob=io.object_from_form(ctx,'SGS Overdrive Surface Detail Panelizer',m);ob.matrix_world=src.matrix_world
    return finish(ctx,ob,'create_greeble_blocks')

def fragment(ctx,s):
    src=mesh_source(ctx);polys=src.data.polygons;n=min(len(polys),s.fragment_piece_count or max(1,round(sqrt(len(polys)))))
    if n<1:raise ValueError('The active mesh has no polygons')
    order=sorted(polys,key=lambda f:(f.center.x,f.center.y,f.center.z));objects=[]
    for i in range(n):
        m=MeshForm();batch=order[len(order)*i//n:len(order)*(i+1)//n]
        for f in batch:m.face([src.data.vertices[v].co for v in f.vertices])
        obj=io.object_from_form(ctx,f'SGS Hyper Precision Fragment {i:03d}',m.merge_seams());obj.matrix_world=src.matrix_world;obj['sgs_piece_id']=i;obj['sgs_face_count']=len(batch);obj['sgs_source_object']=src.name;finish(ctx,obj,'explode_mesh_to_pieces')
        write(obj.data,'sgs_piece_id','INT',[i]*len(obj.data.vertices));objects.append(obj)
    io._select_only(ctx,objects[::-1]);return objects

def csv_points(ctx,s,filename):
    file=Path(filename or s.csv_path);rows=[]
    with file.open(encoding='utf-8-sig',newline='') as stream:
        for row in csv.DictReader(stream):
            row={str(k).strip().lower():v for k,v in row.items()};rows.append((tuple(float(row[k]) for k in ('x','y','z')),float(row.get('scale') or 1),float(row.get('density') or 1)))
    obj=io._mesh_obj(ctx,'SGS CSV Point Cloud '+file.stem,[r[0] for r in rows],[]);finish(ctx,obj,'import_csv_points')
    for k,index in (('sgs_scale',1),('sgs_density',2)):write(obj.data,k,'FLOAT',[r[index] for r in rows])
    obj['sgs_csv_source']=str(file);obj['sgs_csv_rows']=len(rows);return obj

