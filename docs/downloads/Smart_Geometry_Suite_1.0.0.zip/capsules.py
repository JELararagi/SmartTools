"""Build editable Geometry Nodes capsules from their public input/output contracts."""
import bpy
from . import catalog,scene_io
def tree(ctx,key,replace=False):
    fact=catalog.PUBLIC['features'][key];s=ctx.window_manager.smart_geometry_suite_settings
    label=fact['name'].replace('SGS_',s.capsule_prefix+'_',1)
    found=next((g for g in bpy.data.node_groups if g.name==label and (g.get('sgs_feature_id')==key or g.get('smart_geometry_suite_generated'))),None)
    if found and not replace:return found
    group=found or bpy.data.node_groups.new(label,'GeometryNodeTree')
    if not found:
        group.interface.new_socket(name='Geometry',in_out='OUTPUT',socket_type='NodeSocketGeometry')
        defaults={'Factor':1.,'Density':1.,'Seed':0,'Scale':1.,'Radius':1.,'Amount':1.,'Threshold':.5,'Iterations':1}
        for name,kind in fact['inputs']:
            port=group.interface.new_socket(name=name,in_out='INPUT',socket_type=kind)
            if hasattr(port,'default_value') and name in fact.get('defaults',{}):port.default_value=fact['defaults'][name]
    group.is_modifier=True;scene_io._mark_owned(group,'capsule');group['sgs_feature_id']=key
    nodes=group.nodes;nodes.clear();link=group.links.new
    a=nodes.new('NodeGroupInput');a.location=(-520,0);b=nodes.new('NodeGroupOutput');b.location=(460,0);surface=a.outputs['Geometry']
    if fact['effect']=='attribute':
        n=nodes.new('GeometryNodeStoreNamedAttribute');n.location=(160,0);n.data_type='FLOAT';n.domain='POINT';n.inputs['Name'].default_value=(fact.get('attrs') or ['sgs_'+key])[0];link(surface,n.inputs['Geometry'])
        n.inputs['Value'].default_value=fact.get('attribute_value',.5)
        surface=n.outputs['Geometry']
    elif fact['effect']=='displacement':
        pos=nodes.new('GeometryNodeInputPosition');pos.location=(-520,-220);noise=nodes.new('ShaderNodeTexNoise');noise.location=(-300,-160);link(pos.outputs['Position'],noise.inputs['Vector'])
        vector=nodes.new('ShaderNodeVectorMath');vector.operation='SCALE';vector.location=(100,-180);vector.inputs[0].default_value=(0.,0.,1.);link(noise.outputs['Fac'],vector.inputs['Scale'])
        n=nodes.new('GeometryNodeSetPosition');n.location=(240,0);link(surface,n.inputs['Geometry']);link(vector.outputs[0],n.inputs['Offset']);surface=n.outputs['Geometry']
    elif fact['effect']=='realize':
        n=nodes.new('GeometryNodeRealizeInstances');n.location=(80,0);link(surface,n.inputs['Geometry']);surface=n.outputs[0]
    link(surface,b.inputs['Geometry']);group.use_fake_user=True
    if s.mark_assets and not group.asset_data:group.asset_mark()
    return group
def apply(ctx,key):
    if key not in catalog.FEATURE_BY_ID:raise ValueError('Unknown feature '+key)
    targets=[o for o in ctx.selected_objects if o.type in ('MESH','CURVE','CURVES','POINTCLOUD') and not o.library]
    if not targets:raise ValueError('Select a geometry object / 対象を選択してください')
    grp=tree(ctx,key);label=catalog.PUBLIC['features'][key]['modifier']
    for obj in targets:
        m=next((mod for mod in obj.modifiers if mod.type=='NODES' and mod.node_group==grp),None) or obj.modifiers.new(label,'NODES')
        m.node_group=grp;m['sgs_feature_id']=key
    return len(targets)
def cleanup():
    for grp in tuple(bpy.data.node_groups):
        if grp.get('sgs_feature_id') in catalog.FEATURE_BY_ID and grp.get('jelararagi_sgs_owner_suite')=='smart_geometry_suite':
            if grp.library:continue
            for obj in bpy.data.objects:
                if obj.library:continue
                for mod in tuple(obj.modifiers):
                    if mod.type=='NODES' and mod.node_group==grp and (mod.get('sgs_feature_id')==grp.get('sgs_feature_id') or mod.name==catalog.PUBLIC['features'][grp['sgs_feature_id']]['modifier']):obj.modifiers.remove(mod)
            grp.use_fake_user=False
            if grp.asset_data:grp.asset_clear()
            if grp.users==0:bpy.data.node_groups.remove(grp)
