"""Build modifier controls from Blender's curve, field and instance nodes."""
def path_geometry(node, link, inputs, fallback):
    def layer_curves(name):
        layer = node('GeometryNodeInputNamedLayerSelection', -940, -220)
        layer.inputs['Name'].default_value = name
        convert = node('GeometryNodeGreasePencilToCurves', -730, -180)
        link(inputs['Geometry'], convert.inputs[0])
        link(layer.outputs[0], convert.inputs['Selection'])
        convert.inputs['Layers as Instances'].default_value = False
        return convert.outputs[0]

    def with_default(curve, default):
        size = node('GeometryNodeAttributeDomainSize', -580, -370)
        size.component = 'CURVE'
        link(curve, size.inputs[0])
        choose = node('GeometryNodeSwitch', -400)
        choose.input_type = 'GEOMETRY'
        link(size.outputs['Spline Count'], choose.inputs['Switch'])
        link(curve, choose.inputs['True'])
        link(default, choose.inputs['False'])
        return choose.outputs[0]

    circle = node('GeometryNodeCurvePrimitiveCircle', -660, -420)
    circle.mode = 'RADIUS'
    circle.inputs['Radius'].default_value = .1
    profile = with_default(layer_curves('Profile'), circle.outputs[0])
    resample = node('GeometryNodeResampleCurve', -250, -340)
    link(profile, resample.inputs['Curve'])
    link(inputs['Profile Resolution'], resample.inputs['Count'])
    return with_default(layer_curves('Path'), fallback), resample.outputs[0]


def round_line(node, link, inputs, curve):
    fillet = node('GeometryNodeFilletCurve', -190, 60)
    if 'Mode' in fillet.inputs:fillet.inputs['Mode'].default_value='Poly'
    link(curve, fillet.inputs['Curve'])
    link(inputs['Corner Radius'], fillet.inputs['Radius'])
    link(inputs['Corner Resolution'], fillet.inputs['Count'])
    return fillet.outputs[0]


def perturb(node, link, inputs, curve):
    noise = node('ShaderNodeTexNoise', -400, -580)
    noise.noise_dimensions = '4D'
    position = node('GeometryNodeInputPosition', -600, -570)
    link(position.outputs[0], noise.inputs['Vector'])
    for source, dest in [('Noise Seed','W'),('Noise Scale','Scale'),('Noise Detail','Detail')]:
        link(inputs[source], noise.inputs[dest])
    centered = node('ShaderNodeVectorMath', -210, -550)
    centered.operation = 'SUBTRACT'
    link(noise.outputs['Color'], centered.inputs[0])
    centered.inputs[1].default_value = (.5, .5, .5)
    scale = node('ShaderNodeVectorMath', -90, -520)
    scale.operation = 'SCALE'
    link(centered.outputs['Vector'], scale.inputs[0])
    link(inputs['Noise Strength'], scale.inputs['Scale'])
    move = node('GeometryNodeSetPosition', 20, 60)
    link(curve, move.inputs[0])
    link(scale.outputs['Vector'], move.inputs['Offset'])
    orient = node('GeometryNodeSetCurveNormal', 75, -280)
    link(move.outputs[0],orient.inputs['Curve'])
    link(inputs['Normal Mode'],orient.inputs['Mode'])
    return orient.outputs[0]


def stamp_options(node, link, inputs, source, instance):
    target = node('GeometryNodeObjectInfo', -650, -360)
    target.transform_space = 'RELATIVE'
    link(inputs['Target Object'],target.inputs['Object'])
    normal = node('GeometryNodeInputNormal', -660, -520)
    sample = node('GeometryNodeSampleNearestSurface', -420, -360)
    sample.data_type = 'FLOAT_VECTOR'
    link(target.outputs['Geometry'],sample.inputs['Mesh'])
    link(normal.outputs[0],sample.inputs['Value'])
    align = node('FunctionNodeAlignRotationToVector', -120, -370)
    align.axis = 'Z'
    link(inputs['Align to Surface'],align.inputs['Factor'])
    link(sample.outputs['Value'],align.inputs['Vector'])
    random = node('FunctionNodeRandomValue', -420, -590)
    random.data_type='FLOAT'
    random.inputs[3].default_value=6.283185307
    link(inputs['Seed'],random.inputs['Seed'])
    seeded = node('ShaderNodeMath', -200, -610)
    seeded.operation = 'MULTIPLY'
    enabled = node('ShaderNodeMath', -400, -740)
    enabled.operation = 'GREATER_THAN'
    link(inputs['Seed'], enabled.inputs[0])
    enabled.inputs[1].default_value=0
    link(enabled.outputs[0],seeded.inputs[0])
    link(random.outputs[1],seeded.inputs[1])
    rotate = node('FunctionNodeAxisAngleToRotation', -50, -610)
    rotate.inputs['Axis'].default_value=(0,0,1)
    link(seeded.outputs[0],rotate.inputs['Angle'])
    compose = node('FunctionNodeRotateRotation', 80, -430)
    compose.rotation_space = 'LOCAL'
    link(align.outputs[0],compose.inputs['Rotation'])
    link(rotate.outputs[0],compose.inputs['Rotate By'])
    link(compose.outputs[0],instance.inputs['Rotation'])
    link(source,instance.inputs['Points'])
