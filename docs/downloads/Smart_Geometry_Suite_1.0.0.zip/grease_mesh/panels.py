# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Grease Mesh sidebar integration helpers.

Grease Mesh is drawn only inside the Smart Geometry Suite root N-panel. This
module registers no standalone View3D sidebar panel, and removes only the exact
legacy panel class owned by Smart Geometry. It never scans or mutates unrelated
Panel subclasses.
"""

from __future__ import annotations

import bpy


def _owned_legacy_panel(cls) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        module_name = str(getattr(cls, '__module__', '') or '')
        class_name = str(getattr(cls, '__name__', '') or '')
        bl_idname = str(getattr(cls, 'bl_idname', '') or '')
    except Exception:
        return False
    if class_name != 'GPTOOLS_PT_main' and bl_idname != 'GPTOOLS_PT_main':
        return False
    return bool(
        'smart_geometry_suite' in module_name
        or 'smart_geometry_node_suite' in module_name
        or module_name == __name__
    )


def unregister_standalone_panel() -> None:
    """Compatibility no-op; never scan or mutate existing Panel RNA."""
    return None


def register() -> None:
    return None


def unregister() -> None:
    return None
