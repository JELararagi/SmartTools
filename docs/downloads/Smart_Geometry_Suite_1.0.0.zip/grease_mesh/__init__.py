"""Stroke-derived modelling operators."""
