# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Lazy Grease Mesh implementation package for Smart Geometry bridges."""

from __future__ import annotations

import importlib

bl_info = {
    'name': 'Grease Mesh',
    'description': 'Smart Geometry sketch-to-mesh implementation modules.',
    'author': 'JELararagi',
    'version': (1, 0, 4),
    'blender': (5, 1, 0),
    'category': 'Smart Geometry',
}

_REGISTERED = False
_OPERATOR_LEAVES = (
    'add_gpencil', 'gn_solid_mesh', 'gn_mirror_mesh', 'gn_path_mesh',
    'gn_wall_mesh', 'screw_mesh', 'lattice_wrap', 'bool_cut',
    'array_on_curve', 'apply_modifiers', 'stamp_scatter', 'knife_cut',
)


def _module(name: str):
    return importlib.import_module(f'{__name__}.{name}')


def register() -> None:
    """Compatibility no-op; Grease implementation RNA is owned by Smart Geometry bridges."""
    global _REGISTERED
    _REGISTERED = True
    return None


def unregister() -> None:
    """Compatibility no-op; central exact-generation teardown owns resources."""
    global _REGISTERED
    _REGISTERED = False
    return None
