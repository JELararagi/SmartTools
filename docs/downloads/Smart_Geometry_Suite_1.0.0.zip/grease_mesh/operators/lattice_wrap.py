# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Build a shrink-wrapped deformation cage for a selected mesh."""
import bpy
from mathutils import Vector
from ... import catalog
from . import activate, modifier_tab, register, unregister


class GPTOOLS_OT_lattice_wrap:
    @staticmethod
    def poll(context):
        target = context.active_object
        return getattr(target, "type", None) == "MESH" and any(
            obj.type == "MESH" and obj != target for obj in context.selected_objects
        )

    def execute(self, context):
        target = context.active_object
        subject = next((obj for obj in context.selected_objects if obj.type == "MESH" and obj != target), None)
        if subject is None or getattr(target, "type", None) != "MESH":
            return {"CANCELLED"}
        rotation = subject.matrix_world.to_quaternion()
        points = [rotation.inverted() @ (subject.matrix_world @ Vector(corner)) for corner in subject.bound_box]
        low = Vector(tuple(min(p[i] for p in points) for i in range(3)))
        high = Vector(tuple(max(p[i] for p in points) for i in range(3)))
        size = high - low
        thickness_axis = min(range(3), key=lambda axis: size[axis])
        name = catalog.text("LatticeWrap", "ラティスラップ")
        selection = tuple(context.selected_objects)
        previous_parent = subject.parent
        previous_inverse = subject.matrix_parent_inverse.copy()
        previous_basis = subject.matrix_basis.copy()
        previous_world = subject.matrix_world.copy()
        data = bpy.data.lattices.new(name)
        cage = None
        modifier = None
        try:
            density = [10, 10, 10]
            density[thickness_axis] = 2
            data.points_u, data.points_v, data.points_w = density
            cage = bpy.data.objects.new(name, data)
            context.collection.objects.link(cage)
            cage.location = rotation @ ((low + high) * .5)
            cage.rotation_euler = rotation.to_euler()
            cage.scale = tuple(max(value * .5, .00001) for value in size)
            context.view_layer.update()
            wrap = cage.modifiers.new(catalog.text("Shrinkwrap", "シュリンクラップ"), "SHRINKWRAP")
            wrap.target = target
            wrap.wrap_method = "TARGET_PROJECT"
            wrap.wrap_mode = "ABOVE_SURFACE"
            wrap.offset = .05
            modifier = subject.modifiers.new(catalog.text("Lattice", "ラティス"), "LATTICE")
            modifier.object = cage
            subject.parent = cage
            subject.matrix_parent_inverse = cage.matrix_world.inverted()
            subject.matrix_world = previous_world
            activate(context, cage)
            modifier_tab(context)
        except Exception:
            subject.parent = previous_parent
            subject.matrix_parent_inverse = previous_inverse
            subject.matrix_basis = previous_basis
            if modifier:
                subject.modifiers.remove(modifier)
            if cage:
                bpy.data.objects.remove(cage, do_unlink=True)
            if not data.users:
                bpy.data.lattices.remove(data)
            for selected in selection:
                selected.select_set(True)
            context.view_layer.objects.active = target
            raise
        self.report({"INFO"}, catalog.text("Lattice wrap", "ラティスラップ") + f": {subject.name} → {target.name}")
        return {"FINISHED"}


