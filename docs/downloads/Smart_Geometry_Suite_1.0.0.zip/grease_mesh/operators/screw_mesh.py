# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy

from ... import catalog
import math
from mathutils import Vector
from ..utils.conversion import get_active_grease_pencil


def detect_revolution_axis(mesh_data, gp_obj):
    """Auto-detect the revolution axis from vertex spans.
    Largest span = revolution axis, middle = radial, smallest = flat/depth.
    Also moves the origin to the inner edge (centerline) on the radial axis."""
    vertices = [tuple(v.co) for v in mesh_data.vertices]

    xs = [v[0] for v in vertices]
    ys = [v[1] for v in vertices]
    zs = [v[2] for v in vertices]
    spans = [
        (max(xs) - min(xs), 0, "X"),
        (max(ys) - min(ys), 1, "Y"),
        (max(zs) - min(zs), 2, "Z"),
    ]
    spans.sort(key=lambda s: s[0])

    flat_span, flat_axis, flat_name = spans[0]
    radial_span, radial_axis, radial_name = spans[1]
    rev_span, rev_axis, rev_name = spans[2]

    # Find the inner edge using stroke endpoints (centerline detection)
    matrix = gp_obj.matrix_world
    endpoint_positions = []
    for layer in gp_obj.data.layers:
        for frame in layer.frames:
            for stroke in frame.drawing.strokes:
                if len(stroke.points) < 2:
                    continue
                endpoint_positions.append(tuple(matrix @ stroke.points[0].position))
                endpoint_positions.append(tuple(matrix @ stroke.points[-1].position))

    mins = [min(xs), min(ys), min(zs)]
    maxs = [max(xs), max(ys), max(zs)]

    if endpoint_positions:
        avg_endpoint_radial = sum(p[radial_axis] for p in endpoint_positions) / len(endpoint_positions)
        mid_radial = (mins[radial_axis] + maxs[radial_axis]) / 2
        if avg_endpoint_radial < mid_radial:
            inner_edge_pos = mins[radial_axis]
        else:
            inner_edge_pos = maxs[radial_axis]
    else:
        if abs(mins[radial_axis]) < abs(maxs[radial_axis]):
            inner_edge_pos = mins[radial_axis]
        else:
            inner_edge_pos = maxs[radial_axis]

    # Move origin to inner edge on radial axis, centered on other axes
    new_origin = [0.0, 0.0, 0.0]
    new_origin[radial_axis] = inner_edge_pos
    new_origin[flat_axis] = (mins[flat_axis] + maxs[flat_axis]) / 2
    new_origin[rev_axis] = (mins[rev_axis] + maxs[rev_axis]) / 2

    origin_vec = Vector(new_origin)
    for v in mesh_data.vertices:
        v.co -= origin_vec
    mesh_data.update()

    return rev_name, origin_vec


def build_profile_mesh(context, gp_obj):
    """Build edge-only profile mesh from GP strokes. Returns (mesh_obj, mesh_data) or (None, None)."""
    object_name = catalog.text("GP_Screw_Mesh", "スクリューメッシュ")
    mesh_data = bpy.data.meshes.new(name=object_name)
    mesh_obj = bpy.data.objects.new(name=object_name, object_data=mesh_data)
    context.collection.objects.link(mesh_obj)

    vertices = []
    edges = []
    matrix = gp_obj.matrix_world

    gp_data = gp_obj.data
    for layer in gp_data.layers:
        for frame in layer.frames:
            for stroke in frame.drawing.strokes:
                if len(stroke.points) < 2:
                    continue
                offset = len(vertices)
                for pt in stroke.points:
                    world_pos = matrix @ pt.position
                    vertices.append(tuple(world_pos))
                n = len(stroke.points)
                for i in range(n - 1):
                    edges.append((offset + i, offset + i + 1))

    if len(vertices) < 2:
        bpy.data.objects.remove(mesh_obj, do_unlink=True)
        bpy.data.meshes.remove(mesh_data)
        return None, None

    mesh_data.from_pydata(vertices, edges, [])
    mesh_data.update()
    return mesh_obj, mesh_data


class GPTOOLS_OT_screw_mesh(bpy.types.Operator):
    """Create screw (lathe) mesh from Grease Pencil profile using Screw modifier"""

    bl_idname = "gptools.screw_mesh"
    bl_label = "Create Screw Mesh"
    bl_description = "Create lathe-style screw mesh geometry from a Grease Pencil profile. Use this for revolved forms such as knobs, cups, vases, and turned parts."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        gp_obj = get_active_grease_pencil(context)
        if gp_obj is None:
            return False
        try:
            return any(
                len(stroke.points) >= 2
                for layer in gp_obj.data.layers
                for frame in layer.frames
                for stroke in frame.drawing.strokes
            )
        except Exception:
            return False

    def execute(self, context):
        gp_obj = get_active_grease_pencil(context)
        if not gp_obj:
            self.report({"WARNING"}, catalog.text("No active Grease Pencil found", "アクティブなGrease Pencilが見つかりません"))
            return {"CANCELLED"}

        gp_name = gp_obj.name

        mesh_obj, mesh_data = build_profile_mesh(context, gp_obj)
        if mesh_obj is None:
            self.report({"WARNING"}, catalog.text("Need at least 2 points in Grease Pencil", "Grease Pencilに少なくとも2点が必要です"))
            return {"CANCELLED"}

        # Auto-detect revolution axis and move origin to centerline
        detected_axis, origin_vec = detect_revolution_axis(mesh_data, gp_obj)
        mesh_obj.location = origin_vec

        # Add native Blender Screw modifier
        screw = mesh_obj.modifiers.new(name=catalog.text("Screw", "スクリュー"), type="SCREW")
        screw.steps = 32
        screw.render_steps = 32
        screw.axis = detected_axis
        screw.angle = math.tau
        screw.use_merge_vertices = True
        screw.merge_threshold = 0.0001
        screw.use_normal_calculate = True

        # Decimate modifier
        decimate = mesh_obj.modifiers.new(name=catalog.text("Decimate", "デシメート"), type="DECIMATE")
        decimate.ratio = 0.5

        # Select and activate
        context.view_layer.objects.active = mesh_obj
        mesh_obj.select_set(True)

        # Shade auto smooth (adds "Smooth by Angle" GN modifier)
        bpy.ops.object.shade_auto_smooth()

        # Delete original GP
        if gp_name in bpy.data.objects:
            bpy.data.objects.remove(bpy.data.objects[gp_name], do_unlink=True)

        # Switch Properties panel to Modifiers tab
        try:
            for area in context.screen.areas:
                if area.type == 'PROPERTIES':
                    for space in area.spaces:
                        if space.type == 'PROPERTIES':
                            space.context = 'MODIFIER'
                            break
                    break
        except TypeError:
            pass

        self.report({"INFO"}, catalog.text(f"Screw mesh created (axis: {detected_axis}).", f"スクリューメッシュを作成しました(軸: {detected_axis})。"))
        return {"FINISHED"}


classes = [
    GPTOOLS_OT_screw_mesh,
]


def register():
    """Compatibility no-op; the Suite registers the lightweight bridge class."""
    return None


def unregister():
    """Compatibility no-op; exact-generation teardown owns the bridge class."""
    return None
