# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy

from ... import catalog
from mathutils import Vector


def _gp_to_curve(gp_obj):
    """Convert a Grease Pencil object to a Curve object.

    bpy.ops.object.convert(target='CURVE') silently fails on GP v3
    in Blender 5.0, so we build the curve manually from stroke data.

    Spline points are stored in local space relative to the first point.
    The curve object's origin is placed at that first point in world space.
    """
    gp_data = gp_obj.data
    matrix = gp_obj.matrix_world

    # Collect all world-space points per stroke
    all_strokes = []
    for layer in gp_data.layers:
        for frame in layer.frames:
            for stroke in frame.drawing.strokes:
                n = len(stroke.points)
                if n < 2:
                    continue
                pts = []
                for i in range(n):
                    pts.append(Vector(matrix @ stroke.points[i].position))
                all_strokes.append(pts)

    if not all_strokes:
        return None

    # Use the first point of the first stroke as curve origin
    origin = all_strokes[0][0].copy()

    curve_data = bpy.data.curves.new(gp_obj.name + catalog.text("_Curve", "_カーブ"), type='CURVE')
    curve_data.dimensions = '3D'

    for pts in all_strokes:
        spline = curve_data.splines.new('POLY')
        spline.points.add(len(pts) - 1)
        for i, world_pos in enumerate(pts):
            local_pos = world_pos - origin
            spline.points[i].co = (local_pos.x, local_pos.y, local_pos.z, 1.0)

    curve_obj = bpy.data.objects.new(curve_data.name, curve_data)
    curve_obj.location = origin
    for col in gp_obj.users_collection:
        col.objects.link(curve_obj)

    return curve_obj


class GPTOOLS_OT_array_on_curve(bpy.types.Operator):
    """Convert GP to curve, add built-in Array modifier to mesh"""

    bl_idname = "gptools.array_on_curve"
    bl_label = "Array on Curve"
    bl_description = "Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path. Select or create a Grease Pencil stroke before running this command."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        selected = context.selected_objects
        has_gp = any(o.type == 'GREASEPENCIL' for o in selected)
        has_mesh = any(o.type == 'MESH' for o in selected)
        return has_gp and has_mesh

    def execute(self, context):
        gp_obj = None
        mesh_obj = None
        for obj in context.selected_objects:
            if obj.type == 'GREASEPENCIL' and gp_obj is None:
                gp_obj = obj
            elif obj.type == 'MESH' and mesh_obj is None:
                mesh_obj = obj

        if not gp_obj or not mesh_obj:
            self.report({"ERROR"}, catalog.text("Select a Grease Pencil and a mesh object", "Grease Pencilとメッシュオブジェクトを選択してください"))
            return {"CANCELLED"}

        # Convert GP to curve manually
        curve_obj = _gp_to_curve(gp_obj)
        if not curve_obj:
            self.report({"ERROR"}, catalog.text("No strokes found in Grease Pencil", "Grease Pencilにストロークが見つかりません"))
            return {"CANCELLED"}

        context.view_layer.update()

        # Hide original GP
        gp_obj.hide_set(True)

        # Select mesh so modifier_add_node_group targets it
        for obj in context.selected_objects:
            obj.select_set(False)
        mesh_obj.select_set(True)
        context.view_layer.objects.active = mesh_obj

        # Add Blender 5.0 built-in Array GN modifier
        existing_modifiers = {item.as_pointer() for item in mesh_obj.modifiers}
        bpy.ops.object.modifier_add_node_group(
            asset_library_type='ESSENTIALS',
            asset_library_identifier="",
            relative_asset_identifier="nodes/geometry_nodes_essentials.blend/NodeTree/Array",
        )

        # Asset modifier names are localized and can have numeric suffixes.
        # Resolve the instance created by this operation, not its display name.
        mod = next((item for item in mesh_obj.modifiers
                    if item.as_pointer() not in existing_modifiers
                    and item.type == 'NODES'), None)
        if not mod:
            self.report({"ERROR"}, catalog.text("Failed to add Array modifier", "配列モディファイアの追加に失敗しました"))
            return {"CANCELLED"}
        mod.name = catalog.text("Array", "配列")

        # Configure: Shape = Curve, Count Method = Distance, Curve Object = converted GP
        mod["Socket_2"] = 2       # Shape: Curve
        mod["Socket_33"] = 1      # Count Method: Distance
        mod["Socket_27"] = curve_obj  # Curve Object
        # Modifier ID properties do not tag the depsgraph: without this the mesh keeps
        # evaluating the default straight line until something else touches it.
        mesh_obj.update_tag()

        # Switch Properties panel to Modifier tab
        try:
            for area in context.screen.areas:
                if area.type == 'PROPERTIES':
                    for space in area.spaces:
                        if space.type == 'PROPERTIES':
                            space.context = 'MODIFIER'
                            break
                    break
        except TypeError:
            pass

        self.report({"INFO"}, catalog.text(f"Array on Curve added to '{mesh_obj.name}'", f"'{mesh_obj.name}'へカーブ配列を追加しました"))
        return {"FINISHED"}


classes = [
    GPTOOLS_OT_array_on_curve,
]


def register():
    """Compatibility no-op; the Suite registers the lightweight bridge class."""
    return None


def unregister():
    """Compatibility no-op; exact-generation teardown owns the bridge class."""
    return None
