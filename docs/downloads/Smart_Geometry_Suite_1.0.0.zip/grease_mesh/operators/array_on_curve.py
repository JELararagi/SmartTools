# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Place native Blender Array instances along the keyed strokes of a sketch."""
from pathlib import Path

import bpy

from ... import catalog
from ..utils.conversion import gpencil_to_points
from . import activate, modifier_tab, register, unregister


def _array_asset():
    folder = bpy.utils.system_resource("DATAFILES", path="assets/nodes")
    if not folder:
        raise RuntimeError(catalog.text("Blender node assets are unavailable", "Blenderのノード素材が見つかりません"))
    bundle = Path(folder) / "geometry_nodes_essentials.blend"
    # Append from the host's actual Essentials library, independent of the Asset Browser index.
    with bpy.data.libraries.load(str(bundle), reuse_local_id=True) as (library, chosen):
        if "Array" not in library.node_groups:
            raise RuntimeError(catalog.text("Array asset unavailable", "配列素材が見つかりません"))
        chosen.node_groups = ["Array"]
    return chosen.node_groups[0]


def _gp_to_curve(gp_obj):
    paths = [path for path in gpencil_to_points(gp_obj) if len(path) > 1]
    if not paths:
        return None
    offset = gp_obj.matrix_world @ paths[0][0]
    name = gp_obj.name + catalog.text("_Curve", "_カーブ")
    data = bpy.data.curves.new(name, "CURVE")
    obj = None
    try:
        data.dimensions = "3D"
        for path in paths:
            spline = data.splines.new("POLY")
            spline.points.add(len(path) - 1)
            for point, local in zip(spline.points, path):
                point.co = (*((gp_obj.matrix_world @ local) - offset), 1)
        obj = bpy.data.objects.new(name, data)
        (gp_obj.users_collection[0] if gp_obj.users_collection else bpy.context.collection).objects.link(obj)
        obj.location = offset
        return obj
    except Exception:
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)
        if not data.users:
            bpy.data.curves.remove(data)
        raise


class GPTOOLS_OT_array_on_curve:
    @staticmethod
    def poll(context):
        kinds = {obj.type for obj in context.selected_objects}
        return {"MESH", "GREASEPENCIL"}.issubset(kinds)

    def execute(self, context):
        picked = tuple(context.selected_objects)
        sketch = next((obj for obj in picked if obj.type == "GREASEPENCIL"), None)
        mesh = next((obj for obj in picked if obj.type == "MESH"), None)
        if mesh is None or sketch is None:
            return {"CANCELLED"}
        curve = _gp_to_curve(sketch)
        if curve is None:
            self.report({"WARNING"}, catalog.text("No drawable strokes", "有効なストロークがありません"))
            return {"CANCELLED"}
        preexisting_groups = {item.as_pointer() for item in bpy.data.node_groups}
        group = None
        modifier = None
        previous_active = context.active_object
        previous_hidden = sketch.hide_get()
        try:
            group = _array_asset()
            sockets = {s.name: s.identifier for s in group.interface.items_tree
                       if s.item_type == "SOCKET" and s.in_out == "INPUT"}
            modifier = mesh.modifiers.new(catalog.text("Array", "配列"), "NODES")
            modifier.node_group = group
            for label, value in (("Shape", 2), ("Count Method", 1), ("Curve Object", curve)):
                modifier[sockets[label]] = value
            mesh.update_tag()
            activate(context, mesh)
            sketch.hide_set(True)
            modifier_tab(context)
        except Exception:
            if modifier:
                mesh.modifiers.remove(modifier)
            data = curve.data
            bpy.data.objects.remove(curve, do_unlink=True)
            if not data.users:
                bpy.data.curves.remove(data)
            if group and group.as_pointer() not in preexisting_groups and not group.users:
                bpy.data.node_groups.remove(group)
            sketch.hide_set(previous_hidden)
            for obj in picked:
                obj.select_set(True)
            context.view_layer.objects.active = previous_active
            raise
        self.report({"INFO"}, catalog.text("Array on Curve", "カーブに沿って配列") + f": {mesh.name}")
        return {"FINISHED"}

