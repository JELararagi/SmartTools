# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shared scene selection for the operators implemented here."""

def register():
    pass


def unregister():
    pass


def activate(context, obj):
    for selected in tuple(context.selected_objects):
        selected.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj


def modifier_tab(context):
    screen = context.screen
    for area in screen.areas if screen else ():
        if area.type == "PROPERTIES" and area.spaces.active.pin_id is None:
            try:
                area.spaces.active.context = "MODIFIER"
            except (TypeError, RuntimeError):
                pass
