# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Start a new sketch using Blender's current empty Grease Pencil template."""

import bpy
from . import register, unregister


class GPTOOLS_OT_add_gpencil:
    @staticmethod
    def poll(context):
        return context.mode == "OBJECT"

    def execute(self, context):
        if not bpy.ops.object.grease_pencil_add.poll():
            return {"CANCELLED"}
        result = bpy.ops.object.grease_pencil_add(type="EMPTY", location=context.scene.cursor.location)
        if "FINISHED" in result and context.mode != "PAINT_GREASE_PENCIL":
            bpy.ops.object.mode_set(mode="PAINT_GREASE_PENCIL")
        return result
