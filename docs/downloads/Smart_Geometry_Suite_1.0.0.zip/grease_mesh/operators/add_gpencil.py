# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy


class GPTOOLS_OT_add_gpencil(bpy.types.Operator):
    """Add a new Grease Pencil object and enter Draw mode"""

    bl_idname = "gptools.add_gpencil"
    bl_label = "Add New Grease Pencil"
    bl_description = "Add a new Grease Pencil object for sketch-to-mesh generation. Use this first when you want to draw strokes that will later become mesh or Geometry Nodes generated geometry."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        if context.mode != 'OBJECT':
            cls.poll_message_set("Switch to Object mode first")
            return False
        return True

    def execute(self, context):
        bpy.ops.object.grease_pencil_add(type='EMPTY')
        bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')
        return {"FINISHED"}


classes = [
    GPTOOLS_OT_add_gpencil,
]


def register():
    """Compatibility no-op; the Suite registers the lightweight bridge class."""
    return None


def unregister():
    """Compatibility no-op; exact-generation teardown owns the bridge class."""
    return None
