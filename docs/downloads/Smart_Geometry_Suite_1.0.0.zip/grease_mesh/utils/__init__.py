"""Read native stroke geometry."""
