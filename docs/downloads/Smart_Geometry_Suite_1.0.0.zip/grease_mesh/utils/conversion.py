# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Read strokes stored across all keyed Grease Pencil drawings."""

def get_active_grease_pencil(context):
    active = context.active_object
    return active if getattr(active, "type", None) == "GREASEPENCIL" else None


def strokes_in(sketch):
    for layer in sketch.data.layers:
        for key in layer.frames:
            yield from key.drawing.strokes


def gpencil_to_points(gp_obj):
    return [[point.position.copy() for point in stroke.points] for stroke in strokes_in(gp_obj)]


def get_stroke_count(gp_obj):
    return sum(1 for _ in strokes_in(gp_obj))
