"""Geometry Nodes tools for native Blender Grease Pencil drawings."""
import json
from pathlib import Path
import bpy
from mathutils import Vector
from .. import scene_io as io
from ..mesh_form import MeshForm,rect_prism
from .utils.conversion import gpencil_to_points
from .operators import activate
from . import shaping
PORTS=json.loads(Path(__file__).with_name('sockets.json').read_text('utf8'))

def group_for(op):
    data=PORTS[op][0];group=next((g for g in bpy.data.node_groups if g.get('sgs_stroke_recipe')==op),None)
    if group:return group
    group=bpy.data.node_groups.new(data['group'],'GeometryNodeTree');group['sgs_stroke_recipe']=op;group.is_modifier=True
    for s in data['sockets']:
        socket=group.interface.new_socket(name=s['name'],in_out=s['io'],socket_type=s['type'])
        if hasattr(socket,'default_value') and s.get('default') is not None and s['type']!='NodeSocketMenu':
            if 'min_value' in s:socket.min_value=s['min_value'];socket.max_value=s['max_value']
            socket.default_value=s['default']
    group.use_fake_user=False;return group
def construct(group,op):
    nodes=group.nodes
    if nodes:return
    link=group.links.new;inp=nodes.new('NodeGroupInput');out=nodes.new('NodeGroupOutput');inp.location=(-730,0);out.location=(730,0)
    def node(kind,x,y=0):
        n=nodes.new(kind);n.location=(x,y);return n
    source=inp.outputs[0]
    if op=='stamp_scatter':
        objects=node('GeometryNodeObjectInfo',-350,-170);objects.transform_space='RELATIVE';link(inp.outputs['Mesh'],objects.inputs['Object']);inst=node('GeometryNodeInstanceOnPoints',100)
        shaping.stamp_options(node,link,inp.outputs,source,inst);link(objects.outputs['Geometry'],inst.inputs['Instance']);link(inp.outputs['Scale'],inst.inputs['Scale']);link(inst.outputs['Instances'],out.inputs[0]);return
    convert=node('GeometryNodeGreasePencilToCurves',-520);link(source,convert.inputs[0]);geometry=convert.outputs[0]
    if 'Layers as Instances' in convert.inputs:convert.inputs['Layers as Instances'].default_value=False
    if op=='gn_path_mesh':
        geometry,profile_curve=shaping.path_geometry(node,link,inp.outputs,geometry)
        raw=node('GeometryNodeCurveToMesh',-590,-280);link(geometry,raw.inputs['Curve'])
        weld=node('GeometryNodeMergeByDistance',-520,-280);link(raw.outputs[0],weld.inputs[0]);link(inp.outputs['Merge Distance'],weld.inputs['Distance'])
        curves=node('GeometryNodeMeshToCurve',-455,-280);link(weld.outputs[0],curves.inputs[0])
        geometry=shaping.round_line(node,link,inp.outputs,curves.outputs[0])
    if op=='gn_wall_mesh':
        raw=node('GeometryNodeCurveToMesh',-580,-120);link(geometry,raw.inputs['Curve'])
        weld=node('GeometryNodeMergeByDistance',-545,-120);link(raw.outputs[0],weld.inputs[0]);link(inp.outputs['Merge Distance'],weld.inputs['Distance'])
        curves=node('GeometryNodeMeshToCurve',-510,-120);link(weld.outputs[0],curves.inputs[0])
        close=node('GeometryNodeSetSplineCyclic',-465,-85);close.inputs['Cyclic'].default_value=True;link(curves.outputs[0],close.inputs[0])
        geometry=shaping.round_line(node,link,inp.outputs,close.outputs[0])
    resample=node('GeometryNodeResampleCurve',-330);link(geometry,resample.inputs['Curve']);link(inp.outputs.get('Resolution') or inp.outputs['Path Resolution'],resample.inputs['Count'])
    geometry=resample.outputs['Curve']
    if op in ('gn_solid_mesh','gn_mirror_mesh'):
        fill=node('GeometryNodeFillCurve',-120);link(geometry,fill.inputs['Curve'])
        thick=node('GeometryNodeExtrudeMesh',70);thick.mode='FACES';link(fill.outputs['Mesh'],thick.inputs['Mesh']);link(inp.outputs['Thickness'],thick.inputs['Offset Scale']);thick.inputs['Individual'].default_value=False
        reverse=node('GeometryNodeFlipFaces',70,-105);link(fill.outputs['Mesh'],reverse.inputs[0])
        closed=node('GeometryNodeJoinGeometry',105,0);link(thick.outputs['Mesh'],closed.inputs[0]);link(reverse.outputs[0],closed.inputs[0])
        weld=node('GeometryNodeMergeByDistance',130,0);weld.inputs['Distance'].default_value=.000001;link(closed.outputs[0],weld.inputs[0]);geometry=weld.outputs[0]
        if op=='gn_mirror_mesh':
            for j,axis in enumerate('XYZ'):
                transform=node('GeometryNodeTransform',160+j*120,-250);v=[1]*3;v[j]=-1;transform.inputs['Scale'].default_value=v;link(geometry,transform.inputs['Geometry'])
                switch=node('GeometryNodeSwitch',180+j*120,-75);switch.input_type='GEOMETRY';link(inp.outputs['Mirror '+axis],switch.inputs['Switch']);link(transform.outputs[0],switch.inputs['True'])
                join=node('GeometryNodeJoinGeometry',260+j*120);link(geometry,join.inputs[0]);link(switch.outputs[0],join.inputs[0]);geometry=join.outputs[0]
            weld=node('GeometryNodeMergeByDistance',630);link(geometry,weld.inputs[0]);link(inp.outputs['Merge Distance'],weld.inputs['Distance']);geometry=weld.outputs[0]
    else:
        if op=='gn_wall_mesh':
            profile=node('GeometryNodeCurvePrimitiveQuadrilateral',-90,-180);profile.mode='RECTANGLE';link(inp.outputs['Thickness'],profile.inputs['Width']);link(inp.outputs['Height'],profile.inputs['Height']);profile_curve=profile.outputs[0]
        else:
            geometry=shaping.perturb(node,link,inp.outputs,geometry)
        sweep=node('GeometryNodeCurveToMesh',130);link(geometry,sweep.inputs['Curve']);link(profile_curve,sweep.inputs['Profile Curve'])
        if 'Fill Caps' in inp.outputs:link(inp.outputs['Fill Caps'],sweep.inputs['Fill Caps'])
        else:sweep.inputs['Fill Caps'].default_value=True
        if op=='gn_wall_mesh':
            half=node('ShaderNodeMath',260,-155);half.operation='MULTIPLY';link(inp.outputs['Height'],half.inputs[0]);half.inputs[1].default_value=.5
            offset=node('ShaderNodeCombineXYZ',300,-130);link(half.outputs[0],offset.inputs['Z'])
            lift=node('GeometryNodeTransform',400);link(sweep.outputs[0],lift.inputs['Geometry']);link(offset.outputs[0],lift.inputs['Translation']);geometry=lift.outputs[0]
        else:
            geometry=sweep.outputs['Mesh']
    link(geometry,out.inputs[0])

def resample_closed(coords,count):
    if count<3 or count==len(coords):return coords
    spans=[(b-a).length for a,b in zip(coords,coords[1:]+coords[:1])]
    total=sum(spans)
    if total<1e-8:return coords
    result=[];j=0;start=0
    for i in range(count):
        offset=i*total/count
        while j<len(spans)-1 and start+spans[j]<offset:
            start+=spans[j];j+=1
        result.append(coords[j].lerp(coords[(j+1)%len(coords)],(offset-start)/max(1e-10,spans[j])))
    return result

def execute(op,ctx,settings):
    active=ctx.active_object;selected=list(ctx.selected_objects)
    gp=active if getattr(active,'type','')=='GREASEPENCIL' else next((o for o in selected if o.type=='GREASEPENCIL'),None)
    if op=='apply_all_modifiers':
        mesh=[o for o in selected if o.type=='MESH']
        for o in mesh:
            with ctx.temp_override(object=o,active_object=o,selected_objects=[o],selected_editable_objects=[o]):
                for mod in tuple(o.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
        return {'FINISHED'} if mesh else {'CANCELLED'}
    if not gp:return {'CANCELLED'}
    if op.startswith('gn_'):
        group=group_for(op);construct(group,op);mod=gp.modifiers.new(PORTS[op][0]['name'],'NODES');mod.node_group=group
        if op=='gn_path_mesh':
            mode=next(s for s in group.interface.items_tree if s.name=='Normal Mode' and s.in_out=='INPUT')
            mod[mode.identifier]=0
        return {'FINISHED'}
    lines=gpencil_to_points(gp)
    if not lines:return {'CANCELLED'}
    target=next((o for o in selected if o.type=='MESH'),None)
    if op=='screw_mesh':
        form=MeshForm()
        for line in lines:form.line(line)
        points=[gp.matrix_world@Vector(p) for p in form.vertices];low=Vector([min(p[i] for p in points) for i in range(3)]);high=Vector([max(p[i] for p in points) for i in range(3)])
        axis=max(range(3),key=lambda i:high[i]-low[i]);origin=points[0].copy();origin[axis]=(low[axis]+high[axis])*.5
        for j in range(3):
            if j!=axis:origin[j]=points[-1][j]
        form.vertices=[tuple(p-origin) for p in points]
        mesh=io.object_from_form(ctx,'GP_Screw_Mesh',form);mesh.location=origin;mod=mesh.modifiers.new('Screw','SCREW');mod.axis='XYZ'[axis];mod.steps=32;mod.render_steps=32;mod.use_merge_vertices=True;mod.use_normal_calculate=True
        dec=mesh.modifiers.new('Decimate','DECIMATE');dec.ratio=.5
        library=Path(bpy.utils.system_resource('DATAFILES',path='assets/nodes/geometry_nodes_essentials.blend'))
        if library.is_file():
            smooth=bpy.data.node_groups.get('Smooth by Angle')
            if not smooth:
                with bpy.data.libraries.load(str(library)) as (available,loaded):
                    loaded.node_groups=['Smooth by Angle'] if 'Smooth by Angle' in available.node_groups else []
                smooth=next(iter(loaded.node_groups),None)
            if smooth:mesh.modifiers.new('Smooth by Angle','NODES').node_group=smooth
        bpy.data.objects.remove(gp,do_unlink=True);activate(ctx,mesh);return {'FINISHED'}
    if op=='stamp_scatter':
        from . import marks
        group=group_for(op);construct(group,op);created=[]
        for layer in gp.data.layers:
            frame=layer.current_frame()
            if not frame:continue
            locations=marks.positions(frame.drawing)
            if not locations:continue
            points=io._mesh_obj(ctx,layer.name+'_Scatter_'+gp.name,locations,[]);points.matrix_world=gp.matrix_world
            mod=points.modifiers.new('Scatter','NODES');mod.node_group=group
            if target:
                surface=next(s for s in group.interface.items_tree if s.name=='Target Object' and s.in_out=='INPUT')
                mod[surface.identifier]=target
            created.append(points)
        if not created:return {'CANCELLED'}
        activate(ctx,created[-1]);return {'FINISHED'}
    if not target:return {'CANCELLED'}
    if op in ('bool_cut','knife_cut'):
        inverse=target.matrix_world.inverted_safe()@gp.matrix_world;extent=max(target.dimensions)*3+.1;shape=MeshForm()
        for line in lines:
            coords=[inverse@Vector(p) for p in line]
            if len(coords)<3:continue
            normal=(coords[1]-coords[0]).cross(coords[2]-coords[0]).normalized()
            if normal.length<.001:normal=Vector((0,0,1))
            coords=resample_closed(coords,settings.resolution)
            if op=='bool_cut':limits=(-.5*settings.cut_depth,.5*settings.cut_depth)
            elif settings.cut_through:limits=(-extent,extent)
            else:
                view=getattr(ctx,'region_data',None)
                front=target.matrix_world.to_3x3()@normal
                sign=1 if view is None or front.dot(view.view_rotation@Vector((0,0,1)))>=0 else -1
                limits=(0,extent*sign)
            segment=MeshForm();rings=segment.rings([[p+normal*depth for p in coords] for depth in limits])
            segment.faces.extend((tuple(rings[0][::-1]),tuple(rings[1])));shape.append(segment)
        if not shape.faces:return {'CANCELLED'}
        if op=='knife_cut':
            from ..max_procedural_primitives.compounds import boolean, capture
            from collections import Counter
            original=capture(target);outside=boolean(original,shape,1);inside=boolean(original,shape,2)
            # Retain both halves of the surface and discard faces internal to the cut.
            joined=outside.append(inside).merge_seams();counts=Counter(tuple(sorted(f)) for f in joined.faces)
            faces=[f for f in joined.faces if counts[tuple(sorted(f))]==1]
            if len(faces)==len(original.faces) and len(joined.vertices)==len(original.vertices):return {'CANCELLED'}
            data=target.data.copy() if target.data.users>1 else target.data
            if target.data!=data:target.data=data
            data.clear_geometry();data.from_pydata(joined.vertices,[],faces);data.update()
            bpy.data.objects.remove(gp,do_unlink=True);activate(ctx,target);return {'FINISHED'}
        cutter=io.object_from_form(ctx,'Stroke Cutting Volume',shape);cutter.matrix_world=target.matrix_world;data=cutter.data
        mod=target.modifiers.new('Cut Stroke','BOOLEAN');mod.object=cutter;mod.operation='DIFFERENCE';mod.solver='EXACT';modifier_name=mod.name
        try:
            activate(ctx,target);status=bpy.ops.object.modifier_apply(modifier=mod.name)
            if status!={'FINISHED'}:return status
        finally:
            if modifier_name in target.modifiers:target.modifiers.remove(target.modifiers[modifier_name])
            bpy.data.objects.remove(cutter,do_unlink=True)
            if not data.users:bpy.data.meshes.remove(data)
        bpy.data.objects.remove(gp,do_unlink=True);return {'FINISHED'}
    raise ValueError(op)
