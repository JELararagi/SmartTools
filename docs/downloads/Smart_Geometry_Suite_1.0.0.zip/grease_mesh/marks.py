"""Locate drawn stamps independently within each Grease Pencil layer."""
from mathutils import Vector
from mathutils.geometry import intersect_line_line

def positions(drawing):
    """Two crossing strokes represent one mark. An isolated stroke uses its center."""
    lines=[[p.position.copy() for p in s.points] for s in drawing.strokes if len(s.points)]
    remaining=set(range(len(lines)));result=[]
    for i,first in enumerate(lines):
        if i not in remaining:continue
        remaining.remove(i)
        center=None
        for j in sorted(remaining):
            for a,b in zip(first,first[1:]):
                for c,d in zip(lines[j],lines[j][1:]):
                    pair=intersect_line_line(a,b,c,d)
                    if pair is None:continue
                    x,y=pair
                    if (x-y).length>1e-4:continue
                    if (x-a).dot(x-b)>1e-6 or (y-c).dot(y-d)>1e-6:continue
                    center=(x+y)*.5;break
                if center is not None:break
            if center is not None:
                remaining.remove(j);break
        result.append(center if center is not None else sum(first,Vector())/len(first))
    return result
