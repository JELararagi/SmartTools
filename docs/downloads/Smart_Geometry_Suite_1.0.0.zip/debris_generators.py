# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package
#
# Smart Geometry Suite integrated debris generators.
# Original Debris Maker 2 concept and public-source attribution are preserved
# in debris_maker_2_THIRD_PARTY_NOTICES.md.

import math
import random
import tomllib
from pathlib import Path
from mathutils import Vector
import bpy

from . import catalog, ownership

from bpy.types import Operator, PropertyGroup
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
)

ADDON_ID = __name__
COLLECTION_NAME = "SGS_Debris_Generators"
_DEBRIS_RUNTIME_REGISTERED = False
_DEBRIS_MENU_REGISTERED = False
_DEBRIS_MENU_CALLBACK_KEY = 'SMART_GEOMETRY_SUITE_DEBRIS_MENU_CALLBACK'

# -----------------------------------------------------------------------------
# Translation
# -----------------------------------------------------------------------------

_JA = {
    "Debris Maker 2": "Debris Maker 2",
    "Smart Geometry Debris": "Smart Geometry デブリ",
    "Debris Generators": "デブリ生成",
    "Module": "モジュール",
    "Settings": "設定",
    "Info": "情報",
    "Module Selection": "モジュール選択",
    "Active Module Parameters": "選択モジュールの設定",
    "Generation": "生成",
    "Information and Links": "情報とリンク",
    "Generate": "生成",
    "Embedded Module Availability": "組み込みモジュールの利用状況",
    "Open modules directory": "モジュールフォルダーを開く",
    "Check online for more...": "オンラインで追加情報を確認...",
    "Online help...": "オンラインヘルプ...",
    "Request a feature...": "機能をリクエスト...",
    "Report a bug...": "不具合を報告...",
    "About": "このアドオンについて",
    "Language": "言語",
    "Use Blender Language": "Blenderの言語設定を使用",
    "English": "英語",
    "Japanese": "日本語",
    "Seed": "シード",
    "Choose desired debris module from the dropdown": "ドロップダウンから生成したいデブリモジュールを選択します。",
    "Creates the selected debris geometry in the scene.": "選択中のデブリ形状をシーン内に生成します。",
    "Reports that the bundled debris modules are available.": "同梱のデブリモジュールが利用可能であることを表示します。",
    "Opens the add-on folder that contains the embedded modules and notices.": "内蔵モジュールと通知文を含むアドオンフォルダーを開きます。",
    "Opens the original Debris Maker 2 project page in your web browser.": "元のDebris Maker 2プロジェクトページをWebブラウザーで開きます。",
    "Opens online help for the original tool.": "元ツールのオンラインヘルプを開きます。",
    "Opens the feature request page for the original project.": "元プロジェクトの機能リクエストページを開きます。",
    "Opens the bug report page for the original project.": "元プロジェクトの不具合報告ページを開きます。",
    "Shows version, license, and attribution information.": "バージョン、ライセンス、クレジット情報を表示します。",
    "Selects how add-on labels are displayed. Auto follows Blender's current interface language.": "アドオンの表示言語を選択します。自動の場合はBlenderの現在のUI言語に従います。",
    "Controls the pseudo-random pattern. Reusing the same seed with the same settings recreates the same result.": "疑似乱数のパターンを制御します。同じ設定と同じシードを使うと同じ結果を再生成できます。",
    "Construction - Brick Pieces": "建材 - レンガ片",
    "Brick Pieces": "レンガ片",
    "Corrugated Metal": "波板金属",
    "Crystal": "結晶",
    "Gemstones": "宝石",
    "Grass": "草",
    "Gravel": "砂利",
    "Fallen Leaves": "落ち葉",
    "Wood Logs": "丸太",
    "Meteor": "隕石片",
    "Obsidian": "黒曜石",
    "Pigeons": "ハト",
    "Planks": "板材",
    "Riverstones": "川石",
    "Sandstone": "砂岩",
    "Shrapnel": "榴散片",
    "Slate": "スレート",
    "Snowflakes": "雪結晶",
    "Splinters": "木片",
    "Twigs": "小枝",
    "Template": "テンプレート",
    "Cinder": "シンダーブロック",
    "Corner": "コーナー",
    "Mason": "レンガ",
    "Poly level": "ポリゴンレベル",
    "Low Poly": "低ポリゴン",
    "High Poly": "高ポリゴン",
    "Erosion": "浸食",
    "Irregularity": "不規則性",
    "Versions": "バリエーション数",
    "Arrangement": "配置",
    "Flat array": "平面配列",
    "Masonry Wall": "組積壁",
    "Running": "ランニング積み",
    "Brick English Bond": "イギリス積み",
    "Flemish": "フランドル積み",
    "Wall Width": "壁の幅",
    "Wall Height": "壁の高さ",
    "Mortar Gap": "目地幅",
    "Special Rate": "特殊レンガ率",
    "Choose which brick templates are eligible for generation. Cinder creates blocks with inset openings, Corner creates L-shaped corner pieces, and Mason creates simple masonry bricks.": "生成対象にするレンガテンプレートを選択します。シンダーは開口を持つブロック、コーナーはL字部材、レンガは通常の組積用レンガを作ります。",
    "Selects the mesh density. Low Poly is faster and closer to the original default; High Poly adds more bevel and surface variation.": "メッシュ密度を選択します。低ポリゴンは高速で元の既定値に近く、高ポリゴンはベベルと表面変化を増やします。",
    "Controls chipped edges and missing corners. Higher values make the bricks look more damaged.": "欠けた角や崩れたエッジの量を制御します。値が高いほど傷んだ外観になります。",
    "Controls random size and vertex displacement. Higher values make each brick less regular.": "サイズと頂点ずれのランダム量を制御します。値が高いほど個体差が大きくなります。",
    "Number of brick pieces or repeated variations to create when using flat array mode.": "平面配列モードで生成するレンガ片またはバリエーションの数です。",
    "Creates individual bricks laid out in a flat row rather than constructing a wall.": "壁を組まず、個別レンガを平面上に並べて生成します。",
    "Builds a wall using the selected bond pattern and wall dimensions.": "選択した積み方と壁寸法で組積壁を生成します。",
    "Uses staggered stretcher courses. This is the simplest wall bond and is useful for background rubble walls.": "段ごとに半分ずらす基本的な積み方です。背景用の崩れた壁などに適しています。",
    "Alternates courses with long and short brick faces, approximating English bond.": "長手面と小口面の段を交互に並べ、イギリス積みに近い壁を作ります。",
    "Alternates long and short brick faces within each course, approximating Flemish bond.": "各段の中で長手面と小口面を交互に配置し、フランドル積みに近い壁を作ります。",
    "Number of brick positions along the wall width.": "壁の横方向に配置するレンガ位置の数です。",
    "Number of brick courses in the wall height.": "壁の高さ方向に積む段数です。",
    "Space left between adjacent bricks to imitate mortar joints.": "レンガ同士の間に残す隙間で、目地を表現します。",
    "Frequency for special corner or header pieces in wall patterns.": "壁パターン内でコーナー材や小口材を挿入する頻度です。",
    "Debris Count": "デブリ数",
    "Detail Level": "ディテールレベル",
    "Slice panels": "パネルを切断",
    "Irregular Shapes": "不規則形状",
    "Rust Holes": "錆穴",
    "Rust Holes count": "錆穴数",
    "Rust Clusters": "錆クラスター",
    "Wrap Deform": "巻き変形",
    "Deform Creases": "変形の折れ数",
    "Deform Amount": "変形量",
    "Number of sheet-metal debris objects to create.": "生成する波板金属片の数です。",
    "Controls mesh subdivisions for corrugation and cut detail.": "波形と切断表現のメッシュ分割数を制御します。",
    "Cuts each panel into smaller broken sheets. Turn off for full rectangular panels.": "各パネルを小さな破片に切ります。無効にすると長方形パネルとして生成します。",
    "Offsets panel vertices and edges so pieces do not remain perfectly rectangular.": "パネル頂点と端をずらし、完全な長方形にならないようにします。",
    "Creates missing cells in the panel mesh to imitate rusted-through holes.": "メッシュの一部セルを抜き、錆で貫通した穴を表現します。",
    "Approximate number of rust holes placed on each generated panel.": "各パネルに配置する錆穴のおおよその数です。",
    "Controls how strongly rust holes clump together instead of being evenly scattered.": "錆穴が均一ではなくまとまって発生する度合いを制御します。",
    "Bends panels into warped sheets instead of leaving them flat.": "平面のままではなく、パネル全体を曲げて歪ませます。",
    "Number of major folds used by the wrap deformation.": "巻き変形で使う大きな折れの数です。",
    "Strength of bending and creasing applied to the metal sheet.": "金属板に適用する曲げと折れの強さです。",
    "Count": "数",
    "Shape Irregularity": "形状の不規則性",
    "Facets to cut": "カット面数",
    "Chamfer Edges": "エッジを面取り",
    "Chamfer amount": "面取り量",
    "Number of gemstone objects to create.": "生成する宝石オブジェクト数です。",
    "Amount of random vertex displacement used to make each gemstone unique.": "各宝石を個性的にするための頂点ずれの量です。",
    "Number of random planar cuts simulated by extra facets and bevels.": "追加ファセットとベベルで表現するランダムなカット面の数です。",
    "Adds beveled edges so stones catch light more like cut gems.": "エッジに面取りを追加し、カット宝石のように光を拾いやすくします。",
    "Width of the gemstone bevel.": "宝石エッジの面取り幅です。",
    "Tuft Count": "株数",
    "Grass Type": "草の種類",
    "switch grass": "スイッチグラス",
    "indian grass": "インディアングラス",
    "yard grass": "芝草",
    "wheat": "小麦",
    "bulrush": "ガマ",
    "Blades Count": "葉身数",
    "Fade off mode": "減衰モード",
    "Grass Height": "草丈",
    "Leaf Count": "葉数",
    "Leaf Bend": "葉の曲げ",
    "Leaf Irregularity": "葉の不規則性",
    "Number of grass tufts to create.": "生成する草株の数です。",
    "Selects the procedural proportions used for the generated grass.": "生成する草の比率と外観を選択します。",
    "Number of blade meshes in each tuft.": "各草株に含まれる葉身メッシュの数です。",
    "Makes outer blades shorter and thinner so the tuft naturally fades at the edges.": "外側の葉身を短く細くし、草株の端が自然に減衰するようにします。",
    "Average height of the blades. Larger values produce taller grass.": "葉身の平均高さです。値が大きいほど背の高い草になります。",
    "Number of broad leaves or seed-head elements added to each tuft.": "各草株に追加する広葉または穂状要素の数です。",
    "Bend angle for broad leaves and seed-head elements.": "広葉または穂状要素の曲げ角度です。",
    "Random variation used for blade width, height, and curvature.": "葉身の幅、高さ、曲率に使うランダム変化量です。",
    "Optimize result": "結果を最適化",
    "Optimize": "最適化",
    "Irregularity Size": "不規則性サイズ",
    "Roughness/Smoothness": "粗さ/滑らかさ",
    "Number of gravel stones to create.": "生成する砂利石の数です。",
    "Scale of large shape deviations on each stone.": "各石に入る大きな形状変化のスケールです。",
    "Controls small surface noise. Lower values look rougher; higher values look smoother.": "細かな表面ノイズを制御します。低い値ほど粗く、高い値ほど滑らかに見えます。",
    "Adds a Decimate modifier to reduce generated mesh complexity.": "生成メッシュの複雑さを下げるため、Decimateモディファイアーを追加します。",
    "Percentage of mesh reduction for generated stones.": "生成した石のメッシュ削減率です。",
    "Leaf Count": "葉の数",
    "High Resolution": "高解像度",
    "With thickness": "厚みあり",
    "Crease": "折り目",
    "Skew": "スキュー",
    "Twist": "ねじれ",
    "Noise": "ノイズ",
    "Tears": "破れ",
    "Holes": "穴",
    "Leaf Type": "葉タイプ",
    "Ash": "トネリコ",
    "Birch": "カバ",
    "Elm": "ニレ",
    "Maple": "カエデ",
    "Red Oak": "レッドオーク",
    "White Oak": "ホワイトオーク",
    "Number of fallen leaves to create.": "生成する落ち葉の数です。",
    "Uses more outline points and surface vertices for smoother leaf silhouettes.": "輪郭点と表面頂点を増やし、葉のシルエットを滑らかにします。",
    "Adds a slight solidified thickness so leaves are visible from side views.": "薄い厚みを追加し、横から見ても葉が見えるようにします。",
    "Adds a central fold along the leaf vein.": "葉脈に沿った中央の折り目を追加します。",
    "Amount of central crease deformation.": "中央折り目の変形量です。",
    "Shears the leaf shape so the left and right sides are not perfectly symmetrical.": "葉形をせん断し、左右が完全な対称にならないようにします。",
    "Amount of side-to-side skew.": "左右方向のスキュー量です。",
    "Rotates points along the leaf length to make curled fallen leaves.": "葉の長手方向に沿って点を回転させ、丸まった落ち葉を作ります。",
    "Amount of twisting along the leaf length.": "葉の長手方向のねじれ量です。",
    "Adds random surface and outline distortion.": "表面と輪郭にランダムな歪みを追加します。",
    "Strength of random leaf noise.": "葉ノイズの強さです。",
    "Cuts notches from the leaf outline.": "葉の輪郭に欠けや切れ込みを作ります。",
    "Creates small transparent-looking gaps by removing parts of the generated leaf surface.": "生成した葉面の一部を削除し、小さな穴のような隙間を作ります。",
    "Includes ash-shaped leaves in the random type selection.": "ランダムな葉タイプ選択にトネリコ形状を含めます。",
    "Includes birch-shaped leaves in the random type selection.": "ランダムな葉タイプ選択にカバ形状を含めます。",
    "Includes elm-shaped leaves in the random type selection.": "ランダムな葉タイプ選択にニレ形状を含めます。",
    "Includes maple-shaped leaves in the random type selection.": "ランダムな葉タイプ選択にカエデ形状を含めます。",
    "Includes red-oak-shaped leaves in the random type selection.": "ランダムな葉タイプ選択にレッドオーク形状を含めます。",
    "Includes white-oak-shaped leaves in the random type selection.": "ランダムな葉タイプ選択にホワイトオーク形状を含めます。",
    "Radius": "半径",
    "Radius Deviation": "半径のばらつき",
    "Length": "長さ",
    "Length Deviation": "長さのばらつき",
    "Deformation": "変形",
    "Make Bark": "樹皮を作成",
    "Bark Thickness": "樹皮の厚み",
    "High-Poly Result": "高ポリゴン結果",
    "Generation Number": "生成数",
    "Array": "配列",
    "Stacked": "積み重ね",
    "Stack Width": "積み幅",
    "Stack Height": "積み高さ",
    "Average log radius.": "丸太の平均半径です。",
    "Random percentage variation applied to log radius.": "丸太半径に適用するランダム変化率です。",
    "Average log length.": "丸太の平均長さです。",
    "Random percentage variation applied to log length.": "丸太の長さに適用するランダム変化率です。",
    "Amount of bending, surface bulging, and end irregularity.": "曲がり、表面の膨らみ、端面の不規則性の量です。",
    "Adds raised bark ridges around each log.": "丸太の周囲に盛り上がった樹皮の筋を追加します。",
    "Controls the height of generated bark ridges.": "生成される樹皮筋の高さを制御します。",
    "Uses more radial and length segments for smoother logs.": "半径方向と長さ方向の分割を増やして滑らかな丸太にします。",
    "Number of logs to generate.": "生成する丸太の数です。",
    "Places generated logs in a simple row.": "生成した丸太を単純な列に配置します。",
    "Stacks logs in a pile using the stack width and height controls.": "積み幅と積み高さの設定で丸太を山状に積みます。",
    "Number of logs across the stack before starting a new layer.": "新しい段に移る前に横方向へ並べる丸太数です。",
    "Number of vertical layers in the stack.": "積み重ねの縦方向段数です。",
    "Large irregularity": "大きな不規則性",
    "Medium irregularity": "中程度の不規則性",
    "Small irregularity/craters": "小さな不規則性/クレーター",
    "Number of meteor fragments to create.": "生成する隕石片の数です。",
    "Controls major silhouette deformation.": "大きなシルエット変形を制御します。",
    "Controls medium-scale bumps and dents.": "中程度の凹凸を制御します。",
    "Controls fine pitting and crater-like depressions.": "細かな孔食とクレーター状のへこみを制御します。",
    "Number of obsidian shards to create.": "生成する黒曜石片の数です。",
    "Create Material": "マテリアル作成",
    "Animation": "アニメーション",
    "casual flight": "通常飛行",
    "fast flight": "高速飛行",
    "Create Particle Flow": "鳥の群れを作成",
    "Number Of Birds": "鳥の数",
    "Creates simple grey pigeon materials for the generated birds.": "生成した鳥に単純な灰色のハト用マテリアルを作成します。",
    "Selects the generated wing flap and travel animation style.": "生成する羽ばたきと移動アニメーションの種類を選択します。",
    "Creates a group of birds to approximate the original Particle Flow flock behavior.": "元のParticle Flowによる群れ挙動に近づけるため、鳥の群れを生成します。",
    "Number of bird meshes to create.": "生成する鳥メッシュの数です。",
    "LenMax": "最大長",
    "LenMin": "最小長",
    "WidthMax": "最大幅",
    "WidthMin": "最小幅",
    "HeightMax": "最大高さ",
    "HeightMin": "最小高さ",
    "Irregular Ends": "不規則な端",
    "Break Planks": "板を折る",
    "Knot Holes": "節穴",
    "Twist Planks": "板をねじる",
    "Plank Cracks": "板の亀裂",
    "Cracks": "亀裂数",
    "Number of plank pieces to create.": "生成する板材の数です。",
    "Maximum plank length.": "板材の最大長です。",
    "Minimum plank length.": "板材の最小長です。",
    "Maximum plank width.": "板材の最大幅です。",
    "Minimum plank width.": "板材の最小幅です。",
    "Maximum plank thickness.": "板材の最大厚です。",
    "Minimum plank thickness.": "板材の最小厚です。",
    "Offsets end vertices so planks look broken or saw-cut unevenly.": "端の頂点をずらし、折れた板や不均一な切断面のように見せます。",
    "Splits some planks into two angled pieces.": "一部の板を2つの角度付き破片に分けます。",
    "Adds dark circular knot details to plank surfaces.": "板面に暗い円形の節ディテールを追加します。",
    "Rotates sections of each plank slightly along its length.": "各板の長手方向に沿って断面を少し回転させます。",
    "Adds thin dark crack details along the plank length.": "板の長手方向に細い暗色の亀裂ディテールを追加します。",
    "Number of crack lines per plank when plank cracks are enabled.": "板の亀裂が有効な場合に、各板へ入れる亀裂線の数です。",
    "Irregular Shape": "不規則形状",
    "Amount": "量",
    "Size": "サイズ",
    "Banding": "縞模様",
    "Pitting": "孔食",
    "Chipping": "欠け",
    "Number of river stones to create.": "生成する川石の数です。",
    "Adds broad shape distortion so stones are not perfect spheres.": "広い形状歪みを追加し、石が完全な球にならないようにします。",
    "Strength of broad river-stone shape distortion.": "川石の大きな形状歪みの強さです。",
    "Scale of broad river-stone shape distortion.": "川石の大きな形状歪みのスケールです。",
    "Adds layered color bands around stones.": "石の周囲に層状の色帯を追加します。",
    "Strength of generated banding detail.": "生成する縞模様ディテールの強さです。",
    "Scale of generated banding detail.": "生成する縞模様ディテールのスケールです。",
    "Adds small pitted depressions to the stone surface.": "石表面に小さな孔状のへこみを追加します。",
    "Strength of generated pitting detail.": "孔食ディテールの強さです。",
    "Scale of generated pitting detail.": "孔食ディテールのスケールです。",
    "Adds sharper chipped areas on some edges.": "一部のエッジに鋭い欠けを追加します。",
    "Strength of generated chip deformation.": "欠け変形の強さです。",
    "Facets start": "開始ファセット数",
    "Facets End": "終了ファセット数",
    "Thickness": "厚み",
    "Thickness Variation": "厚みのばらつき",
    "Edge Detail": "エッジディテール",
    "Number of sandstone chunks to create.": "生成する砂岩片の数です。",
    "Minimum number of sides used by sandstone slabs.": "砂岩スラブで使う最小辺数です。",
    "Maximum number of sides used by sandstone slabs.": "砂岩スラブで使う最大辺数です。",
    "Average slab thickness.": "スラブの平均厚みです。",
    "Random thickness variation applied per chunk.": "各破片に適用する厚みのばらつきです。",
    "Adds rough and chipped slab edges.": "スラブの端に粗さや欠けを追加します。",
    "Panel Resolution": "パネル解像度",
    "Panel Noise Scale": "パネルノイズスケール",
    "Cut Holes": "穴を切る",
    "Number of shrapnel panels to create.": "生成する破片パネルの数です。",
    "Subdivisions used before warping and cutting the panel.": "パネルを歪ませたり穴を切る前の分割数です。",
    "Scale of random panel surface displacement.": "パネル表面ランダム変位のスケールです。",
    "Removes random cells from the generated panel to make torn holes.": "生成パネルのセルをランダムに取り除き、破れ穴を作ります。",
    "Plates Count": "板層数",
    "Plates Count Variation": "板層数のばらつき",
    "Number of slate chunks to create.": "生成するスレート片の数です。",
    "Number of thin layers used in each slate chunk.": "各スレート片に含める薄い層の数です。",
    "Random variation applied to the number of slate layers.": "スレート層数に適用するランダムばらつきです。",
    "Number of snowflake meshes to create.": "生成する雪結晶メッシュの数です。",
    "Number of splinter pieces to create.": "生成する木片の数です。",
    "Twisting": "ねじれ",
    "Height": "高さ",
    "Height Variation": "高さのばらつき",
    "Amount of spiral twist along the splinter length.": "木片の長手方向に沿うらせん状ねじれの量です。",
    "Average splinter length.": "木片の平均長です。",
    "Random variation applied to splinter length.": "木片の長さに適用するランダムばらつきです。",
    "Twig Count": "小枝数",
    "Twig Length": "小枝の長さ",
    "Twig Segments": "小枝分割数",
    "Warping": "反り",
    "Twig Warts": "小枝のこぶ",
    "Warts": "こぶ数",
    "Broken ends": "折れた端",
    "Ends": "端の欠け",
    "Twig Branching": "枝分かれ",
    "Branch Length": "枝長",
    "Branch Count": "枝数",
    "Weld all elements": "全要素を結合",
    "Number of twig objects to create.": "生成する小枝オブジェクト数です。",
    "Average twig length.": "小枝の平均長です。",
    "Number of segments used along each twig.": "各小枝の長手方向分割数です。",
    "Twists the twig cross-section along its length.": "小枝の断面を長手方向に沿ってねじります。",
    "Bends the twig centerline so it does not remain straight.": "小枝の中心線を曲げ、直線のままにならないようにします。",
    "Adds small raised bumps on bark.": "樹皮上に小さな盛り上がりを追加します。",
    "Number of wart bumps per twig.": "各小枝に配置するこぶの数です。",
    "Creates jagged broken-looking twig ends.": "小枝の端をギザギザに折れたようにします。",
    "Strength of end break deformation.": "端部の欠け変形の強さです。",
    "Adds smaller branch cylinders coming from the main twig.": "主枝から伸びる小さな枝シリンダーを追加します。",
    "Average length of generated twig branches.": "生成する枝分かれ部分の平均長です。",
    "Number of branches per twig.": "各小枝から出る枝の数です。",
    "Joins generated twig pieces into one object per twig when possible.": "可能な場合、生成した小枝要素を小枝ごとに一つのオブジェクトへ結合します。",
    "Open URL": "URLを開く",
    "Opens an online resource for the original debris-generator source project.": "元のデブリ生成ソースプロジェクトのオンラインリソースを開きます。",
    "Opens a compact Smart Geometry debris generator window with the module dropdown and active module controls.": "モジュール選択ドロップダウンと選択中モジュールの設定を備えた、コンパクトなSmart Geometryデブリ生成ウィンドウを開きます。",
    "Resource": "リソース",
    "Selects which original Debris Maker 2 project or support page is opened in the system web browser.": "システムのWebブラウザで開く、元のDebris Maker 2プロジェクトまたはサポートページを選択します。",
    "Project": "プロジェクト",
    "Feature": "機能要望",
    "Bug": "不具合報告",
    "Open the original Debris Maker 2 project page.": "元のDebris Maker 2プロジェクトページを開きます。",
    "Open the original Debris Maker 2 usage and reference page.": "元のDebris Maker 2の使い方・リファレンスページを開きます。",
    "Open the project issue page for feature requests.": "機能要望用のプロジェクトissueページを開きます。",
    "Open the project issue page for bug reports.": "不具合報告用のプロジェクトissueページを開きます。",
    "Show Debris Module Selection Child Section": "デブリモジュール選択子セクションを表示",
    "Opens or closes the Blender-standard child foldout for choosing the active debris module, opening the compact debris window, and setting the random seed.": "使用するデブリモジュールの選択、コンパクトなデブリウィンドウの表示、ランダムシード設定を行うBlender標準の子フォールドアウトを開閉します。",
    "Show Debris Parameters Child Section": "デブリパラメータ子セクションを表示",
    "Opens or closes the Blender-standard child foldout that contains the settings for the currently selected debris generator module.": "現在選択中のデブリ生成モジュールの設定を含むBlender標準の子フォールドアウトを開閉します。",
    "Show Debris Generation Child Section": "デブリ生成子セクションを表示",
    "Opens or closes the Blender-standard child foldout containing the command that generates the selected debris geometry in the scene.": "選択したデブリジオメトリをシーンへ生成するコマンドを含むBlender標準の子フォールドアウトを開閉します。",
    "Show Debris Information Child Section": "デブリ情報子セクションを表示",
    "Opens or closes the Blender-standard child foldout containing refresh, folder, online help, request, report, and attribution actions for the integrated debris generators.": "統合デブリ生成の更新、フォルダー、オンラインヘルプ、要望、報告、クレジット操作を含むBlender標準の子フォールドアウトを開閉します。",
    "Smart Geometry Debris Settings": "Smart Geometryデブリ設定",
    "Stores the Smart Geometry debris generator module, parameters, section state, and persistence options for this scene.": "このシーンのSmart Geometryデブリ生成モジュール、パラメータ、セクション状態、保持オプションを保存します。",
}

_TRANSLATIONS = {
    "ja_JP": {(context, key): value for key, value in _JA.items() for context in ("*", "Operator")}
}


def _locale_is_ja(context=None):
    try:
        return bool(catalog.is_japanese(context or bpy.context))
    except Exception:
        try:
            locale = bpy.app.translations.locale
        except Exception:
            locale = "en_US"
        return str(locale).startswith("ja")


def tr(msgid, context=None):
    if _locale_is_ja(context):
        return _JA.get(msgid, msgid)
    return msgid


MODULE_ITEMS = [
    ("BRICK", "Brick Pieces", "Construction - Brick Pieces"),
    ("CORRUGATED", "Corrugated Metal", "Corrugated Metal"),
    ("CRYSTAL", "Crystal", "Crystal"),
    ("GEMSTONES", "Gemstones", "Gemstones"),
    ("GRASS", "Grass", "Grass"),
    ("GRAVEL", "Gravel", "Gravel"),
    ("LEAVES", "Fallen Leaves", "Fallen Leaves"),
    ("LOGS", "Wood Logs", "Wood Logs"),
    ("METEOR", "Meteor", "Meteor"),
    ("OBSIDIAN", "Obsidian", "Obsidian"),
    ("PIGEONS", "Pigeons", "Pigeons"),
    ("PLANKS", "Planks", "Planks"),
    ("RIVERSTONES", "Riverstones", "Riverstones"),
    ("SANDSTONE", "Sandstone", "Sandstone"),
    ("SHRAPNEL", "Shrapnel", "Shrapnel"),
    ("SLATE", "Slate", "Slate"),
    ("SNOWFLAKES", "Snowflakes", "Snowflakes"),
    ("SPLINTERS", "Splinters", "Splinters"),
    ("TWIGS", "Twigs", "Twigs"),
]

MODULE_TITLES = {item[0]: item[2] for item in MODULE_ITEMS}

# -----------------------------------------------------------------------------
# Geometry helpers
# -----------------------------------------------------------------------------

_MAX_MESH_DATA_CACHE = None


def _max_mesh_data():
    """Load the large embedded debris mesh table only for a generator call."""
    global _MAX_MESH_DATA_CACHE
    if _MAX_MESH_DATA_CACHE is None:
        try:
            import importlib
            module = importlib.import_module(f'{__package__}.sgs_debris_mesh_data')
            _MAX_MESH_DATA_CACHE = getattr(module, 'MESH_DATA', {}) or {}
            try:
                from . import ownership
                ledger = ownership.shared_ledger()
                if ledger is not None:
                    ownership.record_lazy_module(ledger, module)
            except Exception:
                pass
        except Exception:
            _MAX_MESH_DATA_CACHE = {}
    return _MAX_MESH_DATA_CACHE


def clear_runtime_caches() -> None:
    global _MAX_MESH_DATA_CACHE
    _MAX_MESH_DATA_CACHE = None

MAX_UNIT_SCALE = 1.0
_OWNER_SUITE_KEY = 'jelararagi_sgs_owner_suite'
_OWNER_REVISION_KEY = 'jelararagi_sgs_owner_revision'
_OWNER_GENERATION_KEY = 'jelararagi_sgs_owner_generation'


def _ledger():
    ledger = ownership.shared_ledger()
    return ledger if ownership.ledger_is_exact(ledger) else None


def _is_owned(value) -> bool:
    ledger = _ledger()
    if value is None or ledger is None:
        return False
    try:
        return bool(
            value.get(_OWNER_SUITE_KEY) == ownership.SUITE_ID
            and value.get(_OWNER_REVISION_KEY) == ownership.REVISION
            and value.get(_OWNER_GENERATION_KEY) == str(ledger.get('generation') or '')
        )
    except Exception:
        return False


def _mark_owned(value, *, role: str = '') -> bool:
    ledger = _ledger()
    if value is None or ledger is None:
        return False
    try:
        value[_OWNER_SUITE_KEY] = ownership.SUITE_ID
        value[_OWNER_REVISION_KEY] = ownership.REVISION
        value[_OWNER_GENERATION_KEY] = str(ledger.get('generation') or '')
        value['smart_geometry_suite_generated'] = True
        if role:
            value['jelararagi_sgs_resource_role'] = str(role)
        return True
    except Exception:
        return False


def _remove_owned_object_and_data(obj) -> bool:
    if obj is None or not _is_owned(obj):
        return False
    data = getattr(obj, 'data', None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return False
    if data is not None and _is_owned(data):
        try:
            if int(getattr(data, 'users', 0)) == 0:
                if isinstance(data, bpy.types.Mesh):
                    bpy.data.meshes.remove(data)
                elif isinstance(data, bpy.types.Curve):
                    bpy.data.curves.remove(data)
        except Exception:
            pass
    return True


def _collection(context):
    collection = bpy.data.collections.get(COLLECTION_NAME)
    if collection is not None and not _is_owned(collection):
        collection = None
    if collection is None:
        try:
            collection = next(
                item for item in bpy.data.collections
                if _is_owned(item) and item.get('jelararagi_sgs_resource_role') == 'debris_collection'
            )
        except Exception:
            collection = None
    if collection is None:
        collection = bpy.data.collections.new(tr("Debris Generators", context) if _locale_is_ja(context) else COLLECTION_NAME)
        if not _mark_owned(collection, role='debris_collection'):
            try:
                bpy.data.collections.remove(collection)
            except Exception:
                pass
            raise RuntimeError('Debris collection ownership tagging failed')
        context.scene.collection.children.link(collection)
    return collection


_MATERIAL_NAMES_JA = {
    "SGS Debris Max Brick": "デブリ レンガ",
    "SGS Debris Max Corrugated Metal": "デブリ 波板金属",
    "SGS Debris Crystal": "デブリ 結晶",
    "SGS Debris Gemstone": "デブリ 宝石",
    "SGS Debris Grass": "デブリ 草",
    "SGS Debris Grass Seed": "デブリ 草の種",
    "SGS Debris Gravel": "デブリ 砂利",
    "SGS Debris Fallen Leaves": "デブリ 落ち葉",
    "SGS Debris Log Core": "デブリ 丸太",
    "SGS Debris Meteorite": "デブリ 隕石",
    "SGS Debris Obsidian": "デブリ 黒曜石",
    "SGS Debris Pigeon Gray": "デブリ ハト 灰色",
    "SGS Debris Pigeon Dark": "デブリ ハト 濃色",
    "SGS Debris Plank Wood": "デブリ 板材",
    "SGS Debris Plank Dark Cracks": "デブリ 板材の割れ目",
    "SGS Debris Riverstone": "デブリ 川石",
    "SGS Debris Sandstone": "デブリ 砂岩",
    "SGS Debris Shrapnel": "デブリ 金属片",
    "SGS Debris Slate": "デブリ スレート",
    "SGS Debris Snowflake": "デブリ 雪の結晶",
    "SGS Debris Splinter": "デブリ 木片",
    "SGS Debris Twig": "デブリ 小枝",
    "SGS Debris Twig Wart": "デブリ 小枝のこぶ",
}


def _material(name, color, roughness=0.6, metallic=0.0):
    if _locale_is_ja():
        name = _MATERIAL_NAMES_JA.get(name, name)
    mat = bpy.data.materials.get(name)
    if mat is not None and not _is_owned(mat):
        mat = None
    if mat is None:
        mat = bpy.data.materials.new(name)
        if not _mark_owned(mat, role='debris_material'):
            try:
                bpy.data.materials.remove(mat)
            except Exception:
                pass
            raise RuntimeError('Debris material ownership tagging failed')
        mat.use_nodes = True
    try:
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            bsdf.inputs["Base Color"].default_value = color
            bsdf.inputs["Roughness"].default_value = roughness
            bsdf.inputs["Metallic"].default_value = metallic
    except Exception:
        pass
    mat.diffuse_color = color
    return mat


def _link_object(context, obj):
    collection = _collection(context)
    if not any(existing.name == obj.name for existing in collection.objects):
        for col in list(obj.users_collection):
            try:
                col.objects.unlink(obj)
            except RuntimeError:
                pass
        collection.objects.link(obj)
    return obj


def _mesh_obj(context, name, verts, faces, mat=None, smooth=False):
    clean_faces = []
    for face in faces:
        if len(face) >= 3 and len(set(face)) >= 3:
            clean_faces.append(tuple(int(i) for i in face))
    mesh = bpy.data.meshes.new(name + "Mesh")
    mesh.from_pydata([tuple(v) for v in verts], [], clean_faces)
    mesh.update(calc_edges=True)
    obj = bpy.data.objects.new(name, mesh)
    if not (_mark_owned(mesh, role='debris_mesh') and _mark_owned(obj, role='debris_object')):
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass
        try:
            if int(getattr(mesh, 'users', 0)) == 0:
                bpy.data.meshes.remove(mesh)
        except Exception:
            pass
        raise RuntimeError('Debris object ownership tagging failed')
    if mat is not None:
        mesh.materials.append(mat)
    if smooth:
        for poly in mesh.polygons:
            poly.use_smooth = True
    _collection(context).objects.link(obj)
    return obj


def _select_only(context, objects):
    try:
        bpy.ops.object.select_all(action="DESELECT")
    except Exception:
        pass
    for obj in objects:
        obj.select_set(True)
    if objects:
        context.view_layer.objects.active = objects[-1]


def _add_bevel(obj, amount, segments=1):
    if amount <= 0:
        return None
    mod = obj.modifiers.new(catalog.text("SGS Debris Bevel", "デブリ ベベル"), "BEVEL")
    _mark_owned(mod, role='debris_modifier')
    mod.width = float(amount)
    mod.segments = max(1, int(segments))
    mod.affect = "EDGES"
    return mod


def _add_decimate(obj, keep_percent):
    if keep_percent <= 0 or keep_percent >= 100:
        return None
    mod = obj.modifiers.new(catalog.text("SGS Debris ProOptimizer Approx", "デブリ 面数削減"), "DECIMATE")
    _mark_owned(mod, role='debris_modifier')
    mod.ratio = max(0.05, min(1.0, keep_percent / 100.0))
    return mod


def _bounds_center(verts):
    xs = [v[0] for v in verts]
    ys = [v[1] for v in verts]
    zs = [v[2] for v in verts]
    return ((min(xs) + max(xs)) * 0.5, (min(ys) + max(ys)) * 0.5, (min(zs) + max(zs)) * 0.5)


def _static_mesh(context, name, block, mat=None, loc=(0, 0, 0), scale=(1, 1, 1), rot=(0, 0, 0), pivot_center=False, smooth=False, vertex_noise=0.0):
    verts = [tuple(v) for v in block["verts"]]
    if pivot_center and verts:
        cx, cy, cz = _bounds_center(verts)
        verts = [(v[0] - cx, v[1] - cy, v[2] - cz) for v in verts]
    sx, sy, sz = scale if hasattr(scale, "__len__") else (scale, scale, scale)
    verts2 = []
    for v in verts:
        x = v[0] * sx * MAX_UNIT_SCALE
        y = v[1] * sy * MAX_UNIT_SCALE
        z = v[2] * sz * MAX_UNIT_SCALE
        if vertex_noise:
            # Max Noise/Shell/Boolean erosion is modifier based. This deterministic perturbation is only
            # applied when the original control requests destructive irregularity.
            x += random.uniform(-vertex_noise, vertex_noise)
            y += random.uniform(-vertex_noise, vertex_noise)
            z += random.uniform(-vertex_noise, vertex_noise)
        verts2.append((x, y, z))
    obj = _mesh_obj(context, name, verts2, block["faces"], mat=mat, smooth=smooth)
    obj.location = (loc[0] * MAX_UNIT_SCALE, loc[1] * MAX_UNIT_SCALE, loc[2] * MAX_UNIT_SCALE)
    obj.rotation_euler = rot
    return obj


def _copy_object_mesh(context, name, source_obj, mat=None):
    mesh = source_obj.data.copy()
    obj = bpy.data.objects.new(name, mesh)
    if not (_mark_owned(mesh, role='debris_mesh') and _mark_owned(obj, role='debris_object')):
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass
        try:
            if int(getattr(mesh, 'users', 0)) == 0:
                bpy.data.meshes.remove(mesh)
        except Exception:
            pass
        raise RuntimeError('Debris copied-object ownership tagging failed')
    obj.matrix_world = source_obj.matrix_world.copy()
    if mat is not None:
        mesh.materials.clear()
        mesh.materials.append(mat)
    _collection(context).objects.link(obj)
    return obj


def _transform_point(v, mat):
    return mat @ Vector((v[0], v[1], v[2]))


def _combine_mesh_objects(context, name, objects, mat=None, remove=True, smooth=False):
    try:
        context.view_layer.update()
    except Exception:
        pass
    verts = []
    faces = []
    for obj in objects:
        offset = len(verts)
        world = obj.matrix_world.copy()
        for v in obj.data.vertices:
            verts.append(tuple(world @ v.co))
        for f in obj.data.polygons:
            faces.append(tuple(offset + idx for idx in f.vertices))
    new_obj = _mesh_obj(context, name, verts, faces, mat=mat, smooth=smooth)
    if remove:
        for obj in objects:
            _remove_owned_object_and_data(obj)
    return new_obj


def _rotate_xy(x, y, angle):
    ca = math.cos(angle)
    sa = math.sin(angle)
    return x * ca - y * sa, x * sa + y * ca


def _simple_noise_3(v, seed=0, scale=1.0):
    x, y, z = v
    return math.sin(x * 12.9898 / scale + y * 78.233 / scale + z * 37.719 / scale + seed * 0.1337)


def _max_box_mesh(length=1, width=1, height=1, length_segs=1, width_segs=1, height_segs=1, noise=0.0, rough_ends=False):
    # 3ds Max Box: width = X, length = Y, height = Z. Blender mesh coordinates below preserve that mapping.
    w = float(width) * 0.5
    l = float(length) * 0.5
    h = float(height) * 0.5
    nx = max(1, int(width_segs))
    ny = max(1, int(length_segs))
    nz = max(1, int(height_segs))
    verts = []
    faces = []

    def add_face(axis, sign, u_steps, v_steps):
        start = len(verts)
        for iv in range(v_steps + 1):
            fv = iv / v_steps
            for iu in range(u_steps + 1):
                fu = iu / u_steps
                if axis == "Z":
                    x = -w + fu * 2 * w
                    y = -l + fv * 2 * l
                    z = sign * h
                elif axis == "Y":
                    x = -w + fu * 2 * w
                    z = -h + fv * 2 * h
                    y = sign * l
                else:
                    y = -l + fu * 2 * l
                    z = -h + fv * 2 * h
                    x = sign * w
                edge_factor = 1.0 if (iu in (0, u_steps) or iv in (0, v_steps)) else 0.35
                if rough_ends and axis == "Y" and sign > 0:
                    edge_factor *= 2.0
                if noise:
                    x += random.uniform(-noise, noise) * edge_factor
                    y += random.uniform(-noise, noise) * edge_factor
                    z += random.uniform(-noise, noise) * edge_factor
                verts.append((x, y, z))
        for iv in range(v_steps):
            for iu in range(u_steps):
                a = start + iv * (u_steps + 1) + iu
                b = a + 1
                c = a + (u_steps + 1) + 1
                d = a + (u_steps + 1)
                faces.append((a, b, c, d) if sign > 0 else (a, d, c, b))

    add_face("Z", 1, nx, ny)
    add_face("Z", -1, nx, ny)
    add_face("Y", 1, nx, nz)
    add_face("Y", -1, nx, nz)
    add_face("X", 1, ny, nz)
    add_face("X", -1, ny, nz)
    return verts, faces


def _create_max_box(context, name, length, width, height, pos=(0, 0, 0), mat=None, length_segs=1, width_segs=1, height_segs=1, noise=0.0, rough_ends=False, rot=(0, 0, 0), smooth=False):
    verts, faces = _max_box_mesh(length, width, height, length_segs, width_segs, height_segs, noise, rough_ends)
    obj = _mesh_obj(context, name, verts, faces, mat=mat, smooth=smooth)
    obj.location = pos
    obj.rotation_euler = rot
    return obj


def _max_plane_mesh(length=1, width=1, length_segs=1, width_segs=1, noise=0.0, holes=None):
    # 3ds Max Plane: width = X, length = Y.
    nx = max(1, int(width_segs))
    ny = max(1, int(length_segs))
    w = float(width) * 0.5
    l = float(length) * 0.5
    verts = []
    faces = []
    for iy in range(ny + 1):
        fy = iy / ny
        for ix in range(nx + 1):
            fx = ix / nx
            x = -w + fx * 2 * w
            y = -l + fy * 2 * l
            z = 0.0
            if noise:
                x += random.uniform(-noise, noise) * 0.25
                y += random.uniform(-noise, noise) * 0.25
                z += random.uniform(-noise, noise)
            verts.append((x, y, z))
    holes = holes or []
    for iy in range(ny):
        for ix in range(nx):
            cx = (ix + 0.5) / nx
            cy = (iy + 0.5) / ny
            skip = False
            for hx, hy, hr in holes:
                if (cx - hx) ** 2 + (cy - hy) ** 2 < hr * hr:
                    skip = True
                    break
            if skip:
                continue
            a = iy * (nx + 1) + ix
            faces.append((a, a + 1, a + nx + 2, a + nx + 1))
    return verts, faces


def _max_cylinder_mesh(radius=1, height=1, sides=16, height_segs=1, capsegs=1, axis="Z", noise=0.0, taper=0.0, jagged=0.0):
    sides = max(3, int(sides))
    rings = max(1, int(height_segs))
    verts = []
    faces = []
    for r in range(rings + 1):
        t = r / rings
        z = (t - 0.5) * height
        local_radius = radius * (1.0 + taper * (t - 0.5))
        if jagged and r in (0, rings):
            z += random.uniform(-jagged, jagged)
        for s in range(sides):
            a = math.tau * s / sides
            rr = local_radius * (1.0 + random.uniform(-noise, noise))
            x = math.cos(a) * rr
            y = math.sin(a) * rr
            co = Vector((x, y, z))
            if axis == "Y":
                co = Vector((x, z, y))
            elif axis == "X":
                co = Vector((z, x, y))
            verts.append(tuple(co))
    for r in range(rings):
        for s in range(sides):
            a = r * sides + s
            b = r * sides + (s + 1) % sides
            c = (r + 1) * sides + (s + 1) % sides
            d = (r + 1) * sides + s
            faces.append((a, b, c, d))
    start_center = len(verts)
    end_center = len(verts) + 1
    if axis == "Z":
        verts.append((0, 0, -height * 0.5)); verts.append((0, 0, height * 0.5))
    elif axis == "Y":
        verts.append((0, -height * 0.5, 0)); verts.append((0, height * 0.5, 0))
    else:
        verts.append((-height * 0.5, 0, 0)); verts.append((height * 0.5, 0, 0))
    for s in range(sides):
        faces.append((start_center, (s + 1) % sides, s))
        faces.append((end_center, rings * sides + s, rings * sides + (s + 1) % sides))
    return verts, faces


def _create_max_cylinder(context, name, radius, height, pos=(0, 0, 0), mat=None, sides=16, height_segs=1, capsegs=1, axis="Z", noise=0.0, taper=0.0, jagged=0.0, smooth=True):
    verts, faces = _max_cylinder_mesh(radius, height, sides, height_segs, capsegs, axis, noise, taper, jagged)
    obj = _mesh_obj(context, name, verts, faces, mat=mat, smooth=smooth)
    obj.location = pos
    return obj


def _faceted_rock(context, name, radius=(1, 1, 1), loc=(0, 0, 0), mat=None, lat=8, lon=12, noise=0.2, smooth=False, flatten=1.0, chip=0.0):
    verts = []
    faces = []
    for i in range(lat + 1):
        theta = math.pi * i / lat
        for j in range(lon):
            phi = math.tau * j / lon
            n = 1.0 + random.uniform(-noise, noise)
            if chip and random.random() < chip:
                n *= random.uniform(0.55, 0.85)
            x = math.sin(theta) * math.cos(phi) * radius[0] * n
            y = math.sin(theta) * math.sin(phi) * radius[1] * n
            z = math.cos(theta) * radius[2] * n * flatten
            verts.append((loc[0] + x, loc[1] + y, loc[2] + z))
    for i in range(lat):
        for j in range(lon):
            a = i * lon + j
            b = i * lon + (j + 1) % lon
            c = (i + 1) * lon + (j + 1) % lon
            d = (i + 1) * lon + j
            if i == 0:
                faces.append((a, c, d))
            elif i == lat - 1:
                faces.append((a, b, d))
            else:
                faces.append((a, b, c, d))
    return _mesh_obj(context, name, verts, faces, mat=mat, smooth=smooth)


def _apply_twist_bend_noise_to_vertices(verts, twist=0.0, bend=0.0, noise=0.0, skew=0.0, axis_len="Y"):
    if not verts:
        return verts
    ys = [v[1] for v in verts]
    ymin, ymax = min(ys), max(ys)
    span = max(0.0001, ymax - ymin)
    out = []
    for v in verts:
        x, y, z = v
        t = (y - ymin) / span
        if skew:
            x += z * skew * 0.1 + (t - 0.5) * skew * 2.0
        if twist:
            ang = math.radians(twist * 360.0 * (t - 0.5))
            x, z = _rotate_xy(x, z, ang)
        if bend:
            z += math.sin((t - 0.5) * math.pi) * bend * 6.0
        if noise:
            x += random.uniform(-noise, noise)
            y += random.uniform(-noise, noise)
            z += random.uniform(-noise, noise)
        out.append((x, y, z))
    return out



def _curve_tube_mesh(points, radii, sides=8, noise=0.0):
    verts = []
    faces = []
    if len(points) < 2:
        return verts, faces
    sides = max(3, int(sides))
    for idx, pnt in enumerate(points):
        pvec = Vector(pnt)
        if idx < len(points) - 1:
            tangent = Vector(points[idx + 1]) - pvec
        else:
            tangent = pvec - Vector(points[idx - 1])
        if tangent.length <= 0.000001:
            tangent = Vector((0, 1, 0))
        tangent.normalize()
        up = Vector((0, 0, 1))
        if abs(tangent.dot(up)) > 0.92:
            up = Vector((1, 0, 0))
        n1 = tangent.cross(up)
        if n1.length <= 0.000001:
            n1 = Vector((1, 0, 0))
        n1.normalize()
        n2 = tangent.cross(n1)
        if n2.length <= 0.000001:
            n2 = Vector((0, 0, 1))
        n2.normalize()
        radius = float(radii[idx]) if idx < len(radii) else float(radii[-1])
        for side in range(sides):
            a = math.tau * side / sides
            rr = radius * (1.0 + random.uniform(-noise, noise))
            co = pvec + n1 * math.cos(a) * rr + n2 * math.sin(a) * rr
            verts.append(tuple(co))
    for idx in range(len(points) - 1):
        for side in range(sides):
            a = idx * sides + side
            faces.append((a, idx * sides + (side + 1) % sides, (idx + 1) * sides + (side + 1) % sides, (idx + 1) * sides + side))
    faces.append(tuple(reversed(range(sides))))
    end = (len(points) - 1) * sides
    faces.append(tuple(range(end, end + sides)))
    return verts, faces

def _bar_between(context, name, start, end, thickness, mat, z_thickness=None):
    zt = thickness if z_thickness is None else z_thickness
    sx, sy, sz = start
    ex, ey, ez = end
    dx, dy, dz = ex - sx, ey - sy, ez - sz
    length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length <= 0.0001:
        length = 0.0001
    mid = ((sx + ex) * 0.5, (sy + ey) * 0.5, (sz + ez) * 0.5)
    obj = _create_max_box(context, name, length=thickness, width=length, height=zt, pos=mid, mat=mat, noise=0.0)
    obj.rotation_euler[2] = math.atan2(dy, dx)
    _add_bevel(obj, thickness * 0.05, 1)
    return obj

# -----------------------------------------------------------------------------
# Generators
# -----------------------------------------------------------------------------


def gen_brick(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Max Brick", (0.48, 0.18, 0.10, 1), 0.85)
    objects = []
    style_pool = []
    if p.brick_cinder:
        style_pool.append(1)
    if p.brick_corner:
        style_pool.append(2)
    if p.brick_mason:
        style_pool.append(3)
    if not style_pool:
        style_pool = [1]

    def dims_for_style(style):
        if style in (1, 2):
            return 16.0, 8.0, 8.0  # brickWidth, brickHeight, brickLength from MaxScript
        return 7.5, 2.5, 3.5

    def make_brick(idx, pos, style=None, add_rot_z=0.0):
        style = style or random.choice(style_pool)
        block = _max_mesh_data().get("BRICK", [])[style - 1]
        noise = max(0.0, float(p.brick_irregularity)) * 0.015
        obj = _static_mesh(context, f"SGS_Debris_Brick_{idx:03d}", block, mat=mat, loc=pos, pivot_center=True, smooth=True, vertex_noise=noise)
        # Original script rotates every generated brick 90 degrees around Z after the source mesh is created.
        obj.rotation_euler[2] = math.radians(90.0) + add_rot_z
        if p.brick_high_poly and not p.brick_low_poly:
            _add_bevel(obj, 0.03 + p.brick_erosion * 0.01, 2)
        elif p.brick_erosion > 0:
            _add_bevel(obj, 0.015 + p.brick_erosion * 0.006, 1)
        objects.append(obj)
        return obj

    if p.brick_wall:
        style0 = style_pool[0]
        brick_width, brick_height, brick_length = dims_for_style(style0)
        gap = p.brick_mortar_gap
        n = 0

        def stretcher(row, col):
            nonlocal n
            x = col * brick_width + col * gap
            if row % 2 > 0:
                x += brick_width * 0.5
            z = row * brick_height - brick_height * 0.5 + row * gap
            obj = make_brick(n, (x, 0, z), random.choice(style_pool), 0.0)
            if random.randint(1, 2) == 1:
                obj.rotation_euler[1] += math.radians(180)
            if random.randint(1, 2) == 1:
                obj.rotation_euler[2] += math.radians(180)
            n += 1

        def english(row, col):
            nonlocal n
            z = row * brick_height - brick_height * 0.5 + row * gap
            x = (col * brick_width) * 0.5 + col * gap + brick_width * 0.5
            y = brick_length * 0.55
            obj = make_brick(n, (x, y, z), random.choice(style_pool), math.radians(90))
            if random.randint(1, 2) == 1:
                obj.rotation_euler[1] += math.radians(180)
            if random.randint(1, 2) == 1:
                obj.rotation_euler[2] += math.radians(180)
            n += 1

        def flemish(row, col):
            nonlocal n
            z = row * brick_height - brick_height * 0.5 + row * gap
            x = ((col * brick_width) * 0.75 + col * gap) - brick_length * 0.5 + brick_width * 0.5
            y = 0.0
            rot = 0.0
            if col % 2 > 0:
                rot = math.radians(90)
                y = brick_length * 0.55
            obj = make_brick(n, (x, y, z), random.choice(style_pool), rot)
            if random.randint(1, 2) == 1:
                obj.rotation_euler[1] += math.radians(180)
            if random.randint(1, 2) == 1:
                obj.rotation_euler[2] += math.radians(180)
            n += 1

        for row in range(1, p.brick_wall_height + 1):
            if p.brick_english and row % max(1, p.brick_special_n) == 0:
                for col in range(1, p.brick_wall_width * 2 + 1):
                    english(row, col)
            elif p.brick_flemish and row % max(1, p.brick_special_n) == 0:
                for col in range(1, int(p.brick_wall_width * 1.4) + 1):
                    flemish(row, col)
            else:
                for col in range(1, p.brick_wall_width + 1):
                    stretcher(row, col)
    else:
        style0 = style_pool[0]
        brick_width, brick_height, _ = dims_for_style(style0)
        for i in range(1, p.brick_versions + 1):
            make_brick(i, (i * (brick_width * 1.1), 0, brick_height * 0.5), random.choice(style_pool), 0.0)
    _select_only(context, objects)
    return objects


def gen_corrugated(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Max Corrugated Metal", (0.45, 0.44, 0.40, 1), 0.75, metallic=0.55)
    objects = []
    waves = 26
    res_x = max(27, 27 * int(p.corr_detail))
    res_y = max(30, 30 * int(p.corr_detail))
    for i in range(1, p.corr_count + 1):
        holes = []
        if p.corr_rust_holes:
            for _ in range(p.corr_rust_clusters):
                hx = random.random()
                hy = random.random()
                for _k in range(p.corr_rust_holes_count):
                    holes.append((min(1, max(0, hx + random.uniform(-0.08, 0.08))), min(1, max(0, hy + random.uniform(-0.08, 0.08))), random.uniform(0.008, 0.025)))
        verts = []
        faces = []
        for y in range(res_y + 1):
            fy = y / res_y
            for x in range(res_x + 1):
                fx = x / res_x
                px = -20.603 + fx * 41.206
                py = -80.0 * fy
                pz = math.sin((fx * waves + 0.25) * math.pi) * 0.560264
                if p.corr_irregular:
                    edge = 1.0 if x in (0, res_x) or y in (0, res_y) else 0.12
                    px += random.uniform(-1.0, 1.0) * edge
                    py += random.uniform(-1.0, 1.0) * edge
                if p.corr_wrap:
                    for c in range(max(1, p.corr_deform_creases)):
                        phase = (c / max(1, p.corr_deform_creases)) * math.tau + random.random()
                        pz += math.sin(fy * math.pi * (c + 1) + phase) * p.corr_deform_amount * 1.8
                        px += math.sin(fy * math.pi * (c + 1) + phase) * p.corr_deform_amount * 0.55
                verts.append((px * 0.25 + i * 20.0, py * 0.25, pz * 0.25))
        for y in range(res_y):
            for x in range(res_x):
                cx = (x + 0.5) / res_x
                cy = (y + 0.5) / res_y
                if p.corr_slice:
                    # Emulates Slice_Type:3 by discarding a corner half-plane on some panels.
                    if i % 2 == 0 and cx + cy > 1.78 + random.uniform(-0.02, 0.02):
                        continue
                remove = False
                for hx, hy, hr in holes:
                    if (cx - hx) ** 2 + (cy - hy) ** 2 < hr * hr:
                        remove = True
                        break
                if not remove:
                    a = y * (res_x + 1) + x
                    faces.append((a, a + 1, a + res_x + 2, a + res_x + 1))
        obj = _mesh_obj(context, f"Roofing_{i}", verts, faces, mat=mat, smooth=True)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_crystal(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Crystal", (0.55, 0.78, 0.95, 0.72), 0.2)
    objects = []
    for i in range(1, p.gem_count + 1):
        sides = max(5, min(12, int(p.gem_facets / 3) + 5))
        radius = random.uniform(1.2, 2.0)
        height = random.uniform(6.0, 12.0)
        verts = [(0, 0, height * 0.5), (0, 0, -height * 0.5)]
        for z, scale in ((height * 0.22, 1.0), (-height * 0.22, 0.75)):
            for s in range(sides):
                a = math.tau * s / sides + random.uniform(-0.08, 0.08)
                rr = radius * scale * random.uniform(0.85, 1.15)
                verts.append((math.cos(a) * rr, math.sin(a) * rr, z))
        faces = []
        upper = 2
        lower = 2 + sides
        for s in range(sides):
            faces.append((0, upper + s, upper + (s + 1) % sides))
            faces.append((upper + s, lower + s, lower + (s + 1) % sides, upper + (s + 1) % sides))
            faces.append((1, lower + (s + 1) % sides, lower + s))
        obj = _mesh_obj(context, f"Crystal_{i:03d}", verts, faces, mat=mat, smooth=False)
        obj.location = (i * 6.0, 0, height * 0.5)
        if p.gem_chamfer:
            _add_bevel(obj, p.gem_chamfer_amount * 0.03, 1)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_gemstones(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Gemstone", (0.16, 0.55, 0.82, 1), 0.26)
    objects = []
    for i in range(1, p.gem_count + 1):
        r = 4.0  # geosphere radius 20 scaled by .2 in MaxScript
        obj = _faceted_rock(context, f"Gemstone_{i:04d}", radius=(r, r, r), loc=(i * 10.0, 0, 0), mat=mat, lat=5 + min(12, p.gem_facets // 8), lon=10 + min(24, p.gem_facets // 3), noise=max(0.02, p.gem_irregularity * 0.018), smooth=False, chip=0.08)
        if p.gem_chamfer:
            _add_bevel(obj, p.gem_chamfer_amount * 0.1, 1)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_grass(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Grass", (0.20, 0.42, 0.10, 1), 0.8)
    seed_mat = _material("SGS Debris Grass Seed", (0.55, 0.42, 0.18, 1), 0.75)
    objects = []
    # Max source: base scatter radius 100 scaled by grassScaleModifier .025 -> about 2.5 generic units footprint.
    # Blade primitives themselves use cylinder height:grassHeight, so height remains in the 10-30 unit range.
    footprint = 100.0 * 0.025
    for j in range(1, p.grass_tuft_count + 1):
        parts = []
        base_x = (j - 1) * 25.0
        blade_count = max(1, min(int(p.grass_blades_count), 160))
        for b in range(blade_count):
            angle = random.random() * math.tau
            radius = footprint * math.sqrt(random.random())
            bx = base_x + math.cos(angle) * radius
            by = math.sin(angle) * radius
            blade_h = p.grass_height * random.uniform(0.72, 1.10)
            blade_r = random.uniform(0.035, 0.075)
            # Source blades are triangular cylinders (sides:3) with noise/frizz. A slight lean is baked into vertices
            # so later object-combine does not lose transform data.
            lean_angle = angle + math.radians(random.uniform(-35, 35))
            lean_amount = blade_h * random.uniform(0.03, 0.16)
            verts, faces = _max_cylinder_mesh(radius=blade_r, height=blade_h, sides=3, height_segs=15, axis="Z", noise=p.grass_leaf_irregularity * 0.05, taper=random.uniform(-0.15, 0.08))
            verts2 = []
            for x, y, z in verts:
                t = (z + blade_h * 0.5) / max(blade_h, 0.0001)
                verts2.append((bx + x + math.cos(lean_angle) * lean_amount * t, by + y + math.sin(lean_angle) * lean_amount * t, z + blade_h * 0.5))
            blade = _mesh_obj(context, f"GrassBlade_{j}_{b}", verts2, faces, mat=mat, smooth=True)
            parts.append(blade)
            if p.grass_leaf_count > 0 and random.random() < 0.45:
                leaf_z = blade_h * random.uniform(0.20, 0.70)
                leaf_len = blade_h * random.uniform(0.12, 0.28)
                leaf_w = random.uniform(0.035, 0.09)
                side_ang = angle + math.radians(p.grass_leaf_bend) + random.uniform(-0.35, 0.35)
                leaf_start = (bx, by, leaf_z)
                leaf_end = (bx + math.cos(side_ang) * leaf_len, by + math.sin(side_ang) * leaf_len, leaf_z + random.uniform(-0.12, 0.20) * leaf_len)
                leaf = _bar_between(context, f"GrassLeaf_{j}_{b}", leaf_start, leaf_end, leaf_w, mat, leaf_w * 0.35)
                parts.append(leaf)
        if p.grass_type in {"WHEAT", "BULRUSH", "INDIAN"}:
            for k in range(max(2, blade_count // 12)):
                angle = random.random() * math.tau
                radius = footprint * random.random() * 0.6
                sx = base_x + math.cos(angle) * radius
                sy = math.sin(angle) * radius
                seed = _create_max_cylinder(context, f"GrassSeed_{j}_{k}", radius=random.uniform(0.08, 0.18), height=random.uniform(0.35, 0.90), pos=(sx, sy, p.grass_height * random.uniform(0.72, 1.08)), mat=seed_mat, sides=6, height_segs=3, axis="Z", noise=0.04, taper=random.uniform(-0.2, 0.2), smooth=True)
                parts.append(seed)
        tuft = _combine_mesh_objects(context, f"Grass_Tuft_{j}", parts, mat=mat, smooth=True)
        objects.append(tuft)
    _select_only(context, objects)
    return objects

def gen_gravel(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Gravel", (0.31, 0.29, 0.25, 1), 0.9)
    objects = []
    for i in range(1, p.gravel_count + 1):
        length = random.uniform(10, 20)
        width = random.uniform(10, 20)
        height = random.uniform(5, 15)
        radius = (width * 0.5 * 0.2, length * 0.5 * 0.2, height * 0.5 * 0.2)
        obj = _faceted_rock(context, f"Gravel_{i:04d}", radius=radius, loc=((i * 10) - i, 0, 0), mat=mat, lat=10, lon=16, noise=0.08 + p.gravel_irregularity_size * 0.015 + (20 - p.gravel_roughness) * 0.005, smooth=True)
        if p.gravel_optimize:
            _add_decimate(obj, p.gravel_optimize_percent)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_leaves(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Fallen Leaves", (0.55, 0.28, 0.08, 1), 0.86)
    objects = []
    selected = []
    flags = [p.leaves_ash, p.leaves_birch, p.leaves_elm, p.leaves_maple, p.leaves_red_oak, p.leaves_white_oak]
    for idx, enabled in enumerate(flags):
        if enabled:
            selected.append(idx)
    if not selected:
        selected = [0]
    blocks = _max_mesh_data().get("LEAVES", [])
    iv = 0
    for leaf_type in selected:
        for j in range(1, p.leaves_count + 1):
            block_idx = leaf_type * 2 + random.choice([0, 1])
            block = blocks[block_idx % len(blocks)]
            scale = random.uniform(0.135, 0.165)
            verts = [(v[0] * scale, v[1] * scale, v[2] * scale) for v in block["verts"]]
            verts = _apply_twist_bend_noise_to_vertices(
                verts,
                twist=(p.leaves_twist_value if p.leaves_twist else 0.0),
                bend=(p.leaves_crease_value if p.leaves_crease else 0.0),
                noise=(p.leaves_noise_value * 0.08 if p.leaves_noise else 0.0),
                skew=(p.leaves_skew_value if p.leaves_skew else 0.0),
            )
            if random.randint(1, 2) == 2:
                verts = [(-x, y, z) for x, y, z in verts]
            faces = []
            for face in block["faces"]:
                if p.leaves_holes and random.random() < 0.015:
                    continue
                if p.leaves_tears and random.random() < 0.010:
                    continue
                faces.append(face)
            obj = _mesh_obj(context, f"Leaf_{leaf_type + 1}_{j}", verts, faces, mat=mat, smooth=p.leaves_high_res)
            obj.location = ((j - 1) * 20, iv * 25, 0)
            if p.leaves_thickness:
                solid = obj.modifiers.new(catalog.text("SGS Debris Leaf Shell", "デブリ 葉の厚み"), "SOLIDIFY")
                _mark_owned(solid, role='debris_modifier')
                solid.thickness = 0.5 * scale
            objects.append(obj)
        iv += 1
    _select_only(context, objects)
    return objects


def gen_logs(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Log Core", (0.36, 0.22, 0.11, 1), 0.85)
    objects = []
    bank = []
    x_pos = 0.0
    count = p.logs_generation_number
    for i in range(1, count + 1):
        sign = 1 if random.randint(0, 1) == 1 else -1
        radius = p.logs_radius + (random.uniform(0.0, p.logs_radius_deviation) * 0.015) * sign
        length = p.logs_length + (random.uniform(0.0, p.logs_length_deviation) * 0.04) * sign
        obj = _create_max_cylinder(context, f"Log_Geo_{i}", max(0.05, radius), max(0.1, length), pos=(x_pos, 0, radius), mat=mat, sides=24, height_segs=10, axis="Y", noise=0.05 * p.logs_deformation, taper=random.uniform(-0.13, 0.13), jagged=0.5, smooth=True)
        if p.logs_high_poly:
            _add_bevel(obj, 0.05, 2)
        if p.logs_make_bark:
            bark = obj.modifiers.new(catalog.text("SGS Debris Bark Shell", "デブリ 樹皮の厚み"), "SOLIDIFY")
            _mark_owned(bark, role='debris_modifier')
            bark.thickness = p.logs_bark_thickness * 0.1
        bank.append(obj)
        x_pos += radius * 3.0
    if p.logs_stacked:
        for row in range(p.logs_stack_height):
            for col in range(max(1, p.logs_stack_width - row)):
                src = random.choice(bank)
                obj = _copy_object_mesh(context, f"Log_Stack_{row+1}_{col+1}", src, mat=mat)
                obj.location = (col * p.logs_radius * 2.05 + row * p.logs_radius, 0, p.logs_radius + row * p.logs_radius * 1.75)
                obj.rotation_euler[1] = math.radians(random.uniform(0, 360))
                objects.append(obj)
        for obj in bank:
            bpy.data.objects.remove(obj, do_unlink=True)
    else:
        objects = bank
    _select_only(context, objects)
    return objects


def gen_meteor(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Meteorite", (0.12, 0.11, 0.10, 1), 0.93)
    objects = []
    for i in range(1, p.meteor_count + 1):
        sx, sy, sz = random.uniform(8, 20), random.uniform(8, 20), random.uniform(8, 20)
        obj = _faceted_rock(context, f"Meteorite_{i:04d}", radius=(sy * 0.2, sx * 0.2, sz * 0.2), loc=((i - 1) * 10, 0, 0), mat=mat, lat=12, lon=24, noise=0.10 + p.meteor_large * 0.015 + p.meteor_medium * 0.006 + p.meteor_small * 0.004, smooth=True, chip=0.10 + p.meteor_small * 0.004)
        if p.meteor_optimize:
            _add_decimate(obj, p.meteor_optimize_percent)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_obsidian(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Obsidian", (0.015, 0.012, 0.018, 1), 0.18)
    objects = []
    for i in range(1, p.obsidian_count + 1):
        sx, sy, sz = random.uniform(10, 20), random.uniform(10, 20), random.uniform(5, 15)
        obj = _faceted_rock(context, f"Obsidian_{i:04d}", radius=(sy * 0.2, sx * 0.2, sz * 0.25), loc=(i * 6, 0, 0), mat=mat, lat=7, lon=14, noise=0.08 + p.obsidian_irregularity * 0.02, smooth=False, chip=0.25)
        obj.scale[2] *= random.uniform(1.2, 2.0)
        if p.obsidian_optimize:
            _add_decimate(obj, p.obsidian_optimize_percent)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_pigeons(context, p):
    random.seed(p.seed)
    gray = _material("SGS Debris Pigeon Gray", (0.55, 0.55, 0.55, 1), 0.6)
    dark = _material("SGS Debris Pigeon Dark", (0.12, 0.14, 0.14, 1), 0.7)
    blocks = _max_mesh_data().get("PIGEONS", [])
    objects = []
    count = p.pigeon_number if p.pigeon_particle else 1
    for i in range(count):
        base_x = (i % 10) * 6.0
        base_y = (i // 10) * 5.0
        body = _static_mesh(context, f"pigeon_BodyMesh_{i+1}", blocks[0], mat=gray, loc=(base_x, base_y, 0), pivot_center=False, smooth=True)
        wing_l = _static_mesh(context, f"pigeon_WingBaseMesh_{i+1}", blocks[1], mat=dark, loc=(base_x - 1.416, base_y - 0.081, 1.491), pivot_center=False, smooth=True)
        tip_l = _static_mesh(context, f"pigeon_WingTipMesh_{i+1}", blocks[2], mat=dark, loc=(base_x - 1.416 - 4.872, base_y - 0.081 - 0.469, 1.491), pivot_center=False, smooth=True)
        wing_r = _static_mesh(context, f"pigeon_WingBaseMesh2_{i+1}", blocks[1], mat=dark, loc=(base_x + 1.416, base_y - 0.081, 1.491), pivot_center=False, smooth=True)
        tip_r = _static_mesh(context, f"pigeon_WingTipMesh2_{i+1}", blocks[2], mat=dark, loc=(base_x + 1.416 + 4.872, base_y - 0.081 - 0.469, 1.491), pivot_center=False, smooth=True)
        wing_l.rotation_euler[1] = math.radians(45)
        tip_l.rotation_euler[1] = math.radians(45)
        wing_r.scale[0] *= -1
        tip_r.scale[0] *= -1
        wing_r.rotation_euler[1] = math.radians(-45)
        tip_r.rotation_euler[1] = math.radians(-45)
        if p.pigeon_animation == "FAST":
            frame_a, frame_b = 5, 9
        else:
            frame_a, frame_b = 8, 12
        for obj, a1, a2 in ((wing_l, -120, 120), (tip_l, -120, 120), (wing_r, 120, -120), (tip_r, 120, -120)):
            obj.keyframe_insert(data_path="rotation_euler", frame=1)
            obj.rotation_euler[1] += math.radians(a1)
            obj.keyframe_insert(data_path="rotation_euler", frame=frame_a)
            obj.rotation_euler[1] += math.radians(a2 - a1)
            obj.keyframe_insert(data_path="rotation_euler", frame=frame_b)
        objects.extend([body, wing_l, tip_l, wing_r, tip_r])
    _select_only(context, objects)
    return objects


def gen_planks(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Plank Wood", (0.42, 0.26, 0.12, 1), 0.82)
    dark = _material("SGS Debris Plank Dark Cracks", (0.04, 0.025, 0.015, 1), 0.9)
    objects = []
    for i in range(p.planks_count):
        cur_width = random.uniform(p.planks_width_max, p.planks_width_min)
        cur_length = random.uniform(p.planks_len_min, p.planks_len_max)
        cur_height = random.uniform(p.planks_height_min, p.planks_height_max)
        verts, faces = _max_box_mesh(length=cur_length, width=cur_width, height=cur_height, length_segs=max(1, int(cur_length / 5)), width_segs=max(1, int(cur_width)), height_segs=2 if cur_height <= 1 else 3, noise=0.0, rough_ends=p.planks_irregular_ends)
        if p.planks_irregular_ends:
            verts = [(x + (random.uniform(-0.8, 0.8) if abs(y) > cur_length * 0.45 else 0), y, z + random.uniform(-0.08, 0.08)) for x, y, z in verts]
        if p.planks_twist:
            verts = _apply_twist_bend_noise_to_vertices(verts, twist=random.uniform(-0.08, 0.08), bend=random.uniform(-0.03, 0.03), noise=0.03)
        obj = _mesh_obj(context, f"Plank_{i+1}", verts, faces, mat=mat, smooth=False)
        obj.location = (i * 10.0, 0, cur_height * 0.5)
        if p.planks_break and random.random() < 0.7:
            obj.rotation_euler[2] = math.radians(random.uniform(-4, 4))
        _add_bevel(obj, 0.03, 1)
        objects.append(obj)
        if p.planks_knots:
            for k in range(random.randint(0, 2)):
                knot = _create_max_cylinder(context, f"Plank_Knot_{i+1}_{k+1}", radius=random.uniform(0.25, 0.75), height=0.035, pos=(obj.location.x + random.uniform(-cur_width * 0.4, cur_width * 0.4), obj.location.y + random.uniform(-cur_length * 0.4, cur_length * 0.4), obj.location.z + cur_height * 0.52), mat=dark, sides=16, axis="Z")
                objects.append(knot)
        if p.planks_cracks:
            for k in range(p.planks_cracks_count):
                crack_len = random.uniform(0.3, 0.8) * cur_length
                crack = _create_max_box(context, f"Plank_Crack_{i+1}_{k+1}", length=crack_len, width=random.uniform(0.05, 0.30), height=0.03, pos=(obj.location.x + random.uniform(-cur_width * 0.45, cur_width * 0.45), obj.location.y + random.uniform(-cur_length * 0.25, cur_length * 0.25), obj.location.z + cur_height * 0.55), mat=dark)
                crack.rotation_euler[2] = math.radians(random.uniform(-30, 30))
                objects.append(crack)
    _select_only(context, objects)
    return objects


def gen_riverstones(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Riverstone", (0.38, 0.36, 0.32, 1), 0.88)
    objects = []
    for i in range(1, p.river_count + 1):
        box_x, box_y, box_z = random.uniform(5, 10), random.uniform(5, 10), random.uniform(2, 6)
        noise = 0.04
        if p.river_irregular:
            noise += p.river_irregular_amount * 0.006
        if p.river_pitting:
            noise += p.river_pitting_amount * 0.004
        obj = _faceted_rock(context, f"Riverstone_{i:04d}", radius=(box_x * 0.4, box_y * 0.4, box_z * 0.4), loc=((i - 1) * 10, 0, 0), mat=mat, lat=10, lon=20, noise=noise, smooth=True, flatten=0.65, chip=(0.12 if p.river_chipping else 0.0))
        if p.river_optimize:
            _add_decimate(obj, p.river_optimize_percent)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def _slab_stack(context, name_prefix, count, facets_start, facets_end, thickness, thickness_var, plates, plates_var, loc_step, mat, optimize=False, optimize_percent=30):
    objects = []
    for i in range(1, count + 1):
        sides = random.randint(facets_start, facets_end)
        stacks = max(1, plates + random.randint(-plates_var, plates_var if plates_var else 0))
        parts = []
        base_radius = random.uniform(3.0, 8.0)
        thick_range = (thickness_var * 0.03) * 0.5
        shell_t = (random.uniform(0.65 - thick_range, 0.65 + thick_range) * 0.2 * (thickness * 0.1))
        for s in range(stacks):
            verts = []
            faces = []
            z0 = s * shell_t
            z1 = z0 + max(0.02, shell_t)
            for z in (z0, z1):
                for k in range(sides):
                    a = math.tau * k / sides + random.uniform(-0.08, 0.08)
                    rr = base_radius * random.uniform(0.75, 1.15)
                    verts.append((math.cos(a) * rr + random.uniform(-0.25, 0.25), math.sin(a) * rr + random.uniform(-0.25, 0.25), z + random.uniform(-0.04, 0.04)))
            faces.append(tuple(range(sides - 1, -1, -1)))
            faces.append(tuple(range(sides, sides * 2)))
            for k in range(sides):
                faces.append((k, (k + 1) % sides, sides + (k + 1) % sides, sides + k))
            part = _mesh_obj(context, f"{name_prefix}_plate_{i}_{s}", verts, faces, mat=mat, smooth=False)
            parts.append(part)
        obj = _combine_mesh_objects(context, f"{name_prefix}_{i:04d}", parts, mat=mat, smooth=False)
        obj.location = (i * loc_step, 0, 0)
        if optimize:
            _add_decimate(obj, optimize_percent)
        objects.append(obj)
    return objects


def gen_sandstone(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Sandstone", (0.62, 0.46, 0.28, 1), 0.92)
    objects = _slab_stack(context, "Sandstone", p.sandstone_count, p.sandstone_facets_start, p.sandstone_facets_end, p.sandstone_thickness, p.sandstone_thickness_var, 1, 0, 10, mat, p.sandstone_optimize, p.sandstone_optimize_percent)
    _select_only(context, objects)
    return objects


def gen_shrapnel(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Shrapnel", (0.18, 0.18, 0.17, 1), 0.62, metallic=0.75)
    objects = []
    for i in range(1, p.shrapnel_count + 1):
        holes = []
        if p.shrapnel_cut_holes:
            for _ in range(random.randint(1, 4)):
                holes.append((random.random(), random.random(), random.uniform(0.04, 0.14)))
        verts, faces = _max_plane_mesh(length=random.uniform(6, 12), width=random.uniform(6, 12), length_segs=p.shrapnel_resolution, width_segs=p.shrapnel_resolution, noise=p.shrapnel_noise_scale * 0.08, holes=holes)
        verts = [(x, y, z + _simple_noise_3((x, y, z), p.seed + i, 4.0) * p.shrapnel_noise_scale * 0.12) for x, y, z in verts]
        obj = _mesh_obj(context, f"Shrapnel_{i:04d}", verts, faces, mat=mat, smooth=False)
        obj.location = (i * 10, 0, 0)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_slate(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Slate", (0.17, 0.18, 0.19, 1), 0.9)
    objects = _slab_stack(context, "Slate", p.slate_count, p.slate_facets_start, p.slate_facets_end, p.slate_thickness, p.slate_thickness_var, p.slate_plates, p.slate_plates_variation, 15, mat, p.slate_optimize, p.slate_optimize_percent)
    _select_only(context, objects)
    return objects


def gen_snowflakes(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Snowflake", (0.88, 0.96, 1.0, 1), 0.25)
    objects = []
    for i in range(1, p.snow_count + 1):
        parts = []
        width_amount = random.uniform(8.0, 15.0)
        branch_count = random.randint(3, 15)
        arm_thick = random.uniform(0.25, 1.75)
        shell_t = random.uniform(0.25, 0.50)
        base_x = (i - 1) * 25.0
        for arm in range(6):
            angle = math.tau * arm / 6.0
            start = (base_x, 0, 0)
            end = (base_x + math.cos(angle) * width_amount, math.sin(angle) * width_amount, 0)
            parts.append(_bar_between(context, f"Snowflake_{i}_arm_{arm}", start, end, arm_thick, mat, shell_t))
            sub_thick = arm_thick * 0.80
            for b in range(branch_count):
                dist = width_amount * random.uniform(0.20, 0.90)
                sub_len = max(0.25, (width_amount - dist) * random.uniform(0.20, 0.55))
                for side in (-1, 1):
                    branch_angle = angle + side * math.radians(60.0)
                    sx = base_x + math.cos(angle) * dist
                    sy = math.sin(angle) * dist
                    start_b = (sx, sy, 0)
                    end_b = (sx + math.cos(branch_angle) * sub_len, sy + math.sin(branch_angle) * sub_len, 0)
                    parts.append(_bar_between(context, f"Snowflake_{i}_branch_{arm}_{b}_{side}", start_b, end_b, max(0.05, sub_thick), mat, shell_t))
                sub_thick *= 0.80
        obj = _combine_mesh_objects(context, f"Snowflake_{i:04d}", parts, mat=mat, smooth=False)
        objects.append(obj)
    _select_only(context, objects)
    return objects

def gen_splinters(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Splinter", (0.29, 0.16, 0.08, 1), 0.88)
    objects = []
    for i in range(1, p.splinters_count + 1):
        cur_height = random.uniform(0, p.splinters_height_variation) + p.splinters_height
        verts, faces = _max_plane_mesh(length=random.uniform(0.75, 1.5), width=random.uniform(0.75, 3.0), length_segs=1, width_segs=1)
        # Shell outward along Z in Max, then taper/twist/noise and half-scale.
        thickness = cur_height
        box_verts, box_faces = _max_box_mesh(length=random.uniform(0.75, 1.5), width=random.uniform(0.75, 3.0), height=thickness, length_segs=2, width_segs=2, height_segs=max(2, int(thickness / 5)), noise=0.10, rough_ends=True)
        box_verts = _apply_twist_bend_noise_to_vertices(box_verts, twist=random.uniform(-p.splinters_twisting, p.splinters_twisting) / 120.0, bend=random.uniform(-0.1, 0.1), noise=0.18)
        box_verts = [(x * 0.5, y * 0.5, z * 0.5) for x, y, z in box_verts]
        obj = _mesh_obj(context, f"Splinter_{i}", box_verts, box_faces, mat=mat, smooth=False)
        obj.location = (i * 5, 0, cur_height * 0.25)
        objects.append(obj)
    _select_only(context, objects)
    return objects


def gen_twigs(context, p):
    random.seed(p.seed)
    mat = _material("SGS Debris Twig", (0.22, 0.12, 0.055, 1), 0.9)
    wart_mat = _material("SGS Debris Twig Wart", (0.16, 0.08, 0.035, 1), 0.94)
    objects = []
    for i in range(1, p.twigs_count + 1):
        parts = []
        twig_length = max(1.0, p.twigs_length + random.uniform(-5.0, 5.0))
        twig_segs = max(2, int(p.twigs_segments + random.randint(-3, 3)))
        spacing = twig_length / twig_segs
        base_x = (i - 1) * 25.0
        points = []
        for k in range(twig_segs + 1):
            y = k * spacing + random.uniform(-0.25, 0.25) * spacing
            x = base_x + (random.uniform(-0.65, 0.65) if p.twigs_warping else 0.0)
            z = random.uniform(-0.65, 0.65) if p.twigs_warping else 0.0
            points.append((x, y, z))
        radii = []
        for k in range(twig_segs + 1):
            t = k / max(1, twig_segs)
            radii.append(max(0.08, random.uniform(0.65, 0.75) * (1.0 - 0.50 * t)))
        verts, faces = _curve_tube_mesh(points, radii, sides=8, noise=(0.12 if p.twigs_twisting else 0.04))
        if p.twigs_broken_ends and verts:
            jag = p.twigs_ends_value
            verts = [(x + random.uniform(-jag, jag) * 0.15 if idx < 8 or idx >= len(verts) - 8 else x,
                      y + random.uniform(-jag, jag) * 0.15 if idx < 8 or idx >= len(verts) - 8 else y,
                      z + random.uniform(-jag, jag) * 0.15 if idx < 8 or idx >= len(verts) - 8 else z) for idx, (x, y, z) in enumerate(verts)]
        main = _mesh_obj(context, f"Twig_Main_{i}", verts, faces, mat=mat, smooth=True)
        parts.append(main)
        if p.twigs_warts:
            wart_count = max(1, int(p.twigs_warts_count))
            for k in range(wart_count):
                t = (k + 1) / (wart_count + 1)
                idx = min(twig_segs, max(0, int(round(t * twig_segs))))
                px, py, pz = points[idx]
                a = random.random() * math.tau
                r = radii[idx]
                wart = _create_max_cylinder(context, f"Twig_Wart_{i}_{k}", radius=0.75 * random.uniform(0.65, 1.05), height=1.25 * random.uniform(0.65, 1.05), pos=(px + math.cos(a) * r, py + math.sin(a) * r, pz), mat=wart_mat, sides=8, height_segs=4, axis="Z", noise=0.12, taper=-0.35, smooth=True)
                wart.rotation_euler[0] = math.radians(-34)
                wart.rotation_euler[1] = random.random() * math.tau
                parts.append(wart)
        if p.twigs_branching:
            count = max(1, int(p.twigs_branch_count))
            for k in range(count):
                start_idx = random.randint(1, max(1, twig_segs - 1))
                sx, sy, sz = points[start_idx]
                ex = sx + random.uniform(-p.twigs_branch_length, p.twigs_branch_length)
                ey = sy + random.uniform(p.twigs_branch_length * 0.5, p.twigs_branch_length * 1.5)
                ez = sz + random.uniform(-p.twigs_branch_length, p.twigs_branch_length)
                mid = ((sx + ex) * 0.5 + random.uniform(-0.5, 0.5), (sy + ey) * 0.5 + random.uniform(-0.5, 0.5), (sz + ez) * 0.5 + random.uniform(-0.5, 0.5))
                branch_points = [(sx, sy, sz), mid, (ex, ey, ez)]
                branch_radii = [radii[start_idx] * 0.55, radii[start_idx] * 0.35, max(0.05, radii[start_idx] * 0.18)]
                bv, bf = _curve_tube_mesh(branch_points, branch_radii, sides=8, noise=0.08)
                parts.append(_mesh_obj(context, f"Twig_Branch_{i}_{k}", bv, bf, mat=mat, smooth=True))
        if p.twigs_weld_all:
            obj = _combine_mesh_objects(context, f"Twig_{i:03d}", parts, mat=mat, smooth=True)
            objects.append(obj)
        else:
            objects.extend(parts)
    _select_only(context, objects)
    return objects

GENERATORS = {
    "BRICK": gen_brick,
    "CORRUGATED": gen_corrugated,
    "CRYSTAL": gen_crystal,
    "GEMSTONES": gen_gemstones,
    "GRASS": gen_grass,
    "GRAVEL": gen_gravel,
    "LEAVES": gen_leaves,
    "LOGS": gen_logs,
    "METEOR": gen_meteor,
    "OBSIDIAN": gen_obsidian,
    "PIGEONS": gen_pigeons,
    "PLANKS": gen_planks,
    "RIVERSTONES": gen_riverstones,
    "SANDSTONE": gen_sandstone,
    "SHRAPNEL": gen_shrapnel,
    "SLATE": gen_slate,
    "SNOWFLAKES": gen_snowflakes,
    "SPLINTERS": gen_splinters,
    "TWIGS": gen_twigs,
}


# -----------------------------------------------------------------------------
# Properties
# -----------------------------------------------------------------------------


class SGS_DebrisSettings(PropertyGroup):
    module: EnumProperty(
        name="Module",
        description="Choose desired debris module from the dropdown",
        items=MODULE_ITEMS,
        default="BRICK",
    )
    seed: IntProperty(name="Seed", description="Controls the pseudo-random pattern. Reusing the same seed with the same settings recreates the same result.", default=1, min=0, max=999999)

    ui_child_debris_module: BoolProperty(name="Show Debris Module Selection Child Section", description="Opens or closes the Blender-standard child foldout for choosing the active debris module, opening the compact debris window, and setting the random seed.", default=True)
    ui_child_debris_parameters: BoolProperty(name="Show Debris Parameters Child Section", description="Opens or closes the Blender-standard child foldout that contains the settings for the currently selected debris generator module.", default=True)
    ui_child_debris_generation: BoolProperty(name="Show Debris Generation Child Section", description="Opens or closes the Blender-standard child foldout containing the command that generates the selected debris geometry in the scene.", default=True)
    ui_child_debris_info: BoolProperty(name="Show Debris Information Child Section", description="Opens or closes the Blender-standard child foldout containing refresh, folder, online help, request, report, and attribution actions for the integrated debris generators.", default=False)


    brick_cinder: BoolProperty(name="Cinder", description="Choose which brick templates are eligible for generation. Cinder creates blocks with inset openings, Corner creates L-shaped corner pieces, and Mason creates simple masonry bricks.", default=True)
    brick_corner: BoolProperty(name="Corner", description="Choose which brick templates are eligible for generation. Cinder creates blocks with inset openings, Corner creates L-shaped corner pieces, and Mason creates simple masonry bricks.", default=False)
    brick_mason: BoolProperty(name="Mason", description="Choose which brick templates are eligible for generation. Cinder creates blocks with inset openings, Corner creates L-shaped corner pieces, and Mason creates simple masonry bricks.", default=False)
    brick_low_poly: BoolProperty(name="Low Poly", description="Selects the mesh density. Low Poly is faster and closer to the original default; High Poly adds more bevel and surface variation.", default=True)
    brick_high_poly: BoolProperty(name="High Poly", description="Selects the mesh density. Low Poly is faster and closer to the original default; High Poly adds more bevel and surface variation.", default=False)
    brick_erosion: FloatProperty(name="Erosion", description="Controls chipped edges and missing corners. Higher values make the bricks look more damaged.", default=2.0, min=0.0, max=10.0)
    brick_irregularity: FloatProperty(name="Irregularity", description="Controls random size and vertex displacement. Higher values make each brick less regular.", default=4.0, min=0.0, max=6.0)
    brick_versions: IntProperty(name="Versions", description="Number of brick pieces or repeated variations to create when using flat array mode.", default=5, min=1, max=25)
    brick_flat_array: BoolProperty(name="Flat array", description="Creates individual bricks laid out in a flat row rather than constructing a wall.", default=True)
    brick_wall: BoolProperty(name="Masonry Wall", description="Builds a wall using the selected bond pattern and wall dimensions.", default=False)
    brick_running: BoolProperty(name="Running", description="Uses staggered stretcher courses. This is the simplest wall bond and is useful for background rubble walls.", default=True)
    brick_english: BoolProperty(name="English", description="Alternates courses with long and short brick faces, approximating English bond.", default=False)
    brick_flemish: BoolProperty(name="Flemish", description="Alternates long and short brick faces within each course, approximating Flemish bond.", default=False)
    brick_wall_width: IntProperty(name="Wall Width", description="Number of brick positions along the wall width.", default=5, min=1, max=50)
    brick_wall_height: IntProperty(name="Wall Height", description="Number of brick courses in the wall height.", default=5, min=1, max=50)
    brick_mortar_gap: FloatProperty(name="Mortar Gap", description="Space left between adjacent bricks to imitate mortar joints.", default=0.1, min=0.0, max=0.5)
    brick_special_n: IntProperty(name="Special Rate", description="Frequency for special corner or header pieces in wall patterns.", default=4, min=1, max=10)

    corr_count: IntProperty(name="Debris Count", description="Number of sheet-metal debris objects to create.", default=10, min=1, max=20)
    corr_detail: IntProperty(name="Detail Level", description="Controls mesh subdivisions for corrugation and cut detail.", default=2, min=1, max=3)
    corr_slice: BoolProperty(name="Slice panels", description="Cuts each panel into smaller broken sheets. Turn off for full rectangular panels.", default=True)
    corr_irregular: BoolProperty(name="Irregular Shapes", description="Offsets panel vertices and edges so pieces do not remain perfectly rectangular.", default=True)
    corr_rust_holes: BoolProperty(name="Rust Holes", description="Creates missing cells in the panel mesh to imitate rusted-through holes.", default=True)
    corr_rust_holes_count: IntProperty(name="Rust Holes count", description="Approximate number of rust holes placed on each generated panel.", default=10, min=1, max=20)
    corr_rust_clusters: IntProperty(name="Rust Clusters", description="Controls how strongly rust holes clump together instead of being evenly scattered.", default=5, min=1, max=10)
    corr_wrap: BoolProperty(name="Wrap Deform", description="Bends panels into warped sheets instead of leaving them flat.", default=True)
    corr_deform_creases: IntProperty(name="Deform Creases", description="Number of major folds used by the wrap deformation.", default=6, min=1, max=12)
    corr_deform_amount: FloatProperty(name="Deform Amount", description="Strength of bending and creasing applied to the metal sheet.", default=0.3, min=0.1, max=1.0)

    gem_count: IntProperty(name="Count", description="Number of gemstone objects to create.", default=5, min=1, max=10)
    gem_irregularity: FloatProperty(name="Shape Irregularity", description="Amount of random vertex displacement used to make each gemstone unique.", default=10.0, min=0.0, max=10.0)
    gem_facets: IntProperty(name="Facets to cut", description="Number of random planar cuts simulated by extra facets and bevels.", default=10, min=1, max=100)
    gem_chamfer: BoolProperty(name="Chamfer Edges", description="Adds beveled edges so stones catch light more like cut gems.", default=True)
    gem_chamfer_amount: FloatProperty(name="Chamfer amount", description="Width of the gemstone bevel.", default=1.0, min=0.1, max=9.9)

    grass_tuft_count: IntProperty(name="Tuft Count", description="Number of grass tufts to create.", default=5, min=1, max=20)
    grass_type: EnumProperty(name="Grass Type", description="Selects the procedural proportions used for the generated grass.", items=(("SWITCH", "switch grass", "switch grass"), ("INDIAN", "indian grass", "indian grass"), ("YARD", "yard grass", "yard grass"), ("WHEAT", "wheat", "wheat"), ("BULRUSH", "bulrush", "bulrush")), default="SWITCH")
    grass_blades_count: IntProperty(name="Blades Count", description="Number of blade meshes in each tuft.", default=80, min=1, max=160)
    grass_fade: BoolProperty(name="Fade off mode", description="Makes outer blades shorter and thinner so the tuft naturally fades at the edges.", default=True)
    grass_height: FloatProperty(name="Grass Height", description="Average height of the blades. Larger values produce taller grass.", default=20.0, min=10.0, max=30.0)
    grass_leaf_count: IntProperty(name="Leaf Count", description="Number of broad leaves or seed-head elements added to each tuft.", default=5, min=0, max=10)
    grass_leaf_bend: FloatProperty(name="Leaf Bend", description="Bend angle for broad leaves and seed-head elements.", default=-45.0, min=-45.0, max=0.0)
    grass_leaf_irregularity: FloatProperty(name="Leaf Irregularity", description="Random variation used for blade width, height, and curvature.", default=0.25, min=0.10, max=0.95)

    gravel_count: IntProperty(name="Count", description="Number of gravel stones to create.", default=10, min=1, max=50)
    gravel_irregularity_size: FloatProperty(name="Irregularity Size", description="Scale of large shape deviations on each stone.", default=5.0, min=1.0, max=10.0)
    gravel_roughness: FloatProperty(name="Roughness/Smoothness", description="Controls small surface noise. Lower values look rougher; higher values look smoother.", default=10.0, min=0.0, max=20.0)
    gravel_optimize: BoolProperty(name="Optimize result", description="Adds a Decimate modifier to reduce generated mesh complexity.", default=True)
    gravel_optimize_percent: FloatProperty(name="Optimize", description="Percentage of mesh reduction for generated stones.", default=30.0, min=10.0, max=90.0)

    leaves_count: IntProperty(name="Leaf Count", description="Number of fallen leaves to create.", default=10, min=1, max=20)
    leaves_high_res: BoolProperty(name="High Resolution", description="Uses more outline points and surface vertices for smoother leaf silhouettes.", default=True)
    leaves_thickness: BoolProperty(name="With thickness", description="Adds a slight solidified thickness so leaves are visible from side views.", default=True)
    leaves_crease: BoolProperty(name="Crease", description="Adds a central fold along the leaf vein.", default=True)
    leaves_crease_value: FloatProperty(name="Crease", description="Amount of central crease deformation.", default=1.0, min=-1.0, max=1.0)
    leaves_skew: BoolProperty(name="Skew", description="Shears the leaf shape so the left and right sides are not perfectly symmetrical.", default=True)
    leaves_skew_value: FloatProperty(name="Skew", description="Amount of side-to-side skew.", default=0.5, min=-0.5, max=1.0)
    leaves_twist: BoolProperty(name="Twist", description="Rotates points along the leaf length to make curled fallen leaves.", default=True)
    leaves_twist_value: FloatProperty(name="Twist", description="Amount of twisting along the leaf length.", default=0.5, min=-1.0, max=1.0)
    leaves_noise: BoolProperty(name="Noise", description="Adds random surface and outline distortion.", default=True)
    leaves_noise_value: FloatProperty(name="Noise", description="Strength of random leaf noise.", default=0.5, min=-1.0, max=1.0)
    leaves_tears: BoolProperty(name="Tears", description="Cuts notches from the leaf outline.", default=True)
    leaves_holes: BoolProperty(name="Holes", description="Creates small transparent-looking gaps by removing parts of the generated leaf surface.", default=False)
    leaves_ash: BoolProperty(name="Ash", description="Includes ash-shaped leaves in the random type selection.", default=True)
    leaves_birch: BoolProperty(name="Birch", description="Includes birch-shaped leaves in the random type selection.", default=True)
    leaves_elm: BoolProperty(name="Elm", description="Includes elm-shaped leaves in the random type selection.", default=True)
    leaves_maple: BoolProperty(name="Maple", description="Includes maple-shaped leaves in the random type selection.", default=True)
    leaves_red_oak: BoolProperty(name="Red Oak", description="Includes red-oak-shaped leaves in the random type selection.", default=True)
    leaves_white_oak: BoolProperty(name="White Oak", description="Includes white-oak-shaped leaves in the random type selection.", default=True)

    logs_radius: FloatProperty(name="Radius", description="Average log radius.", default=3.0, min=3.0, max=10.0)
    logs_radius_deviation: FloatProperty(name="Radius Deviation", description="Random percentage variation applied to log radius.", default=50.0, min=30.0, max=80.0)
    logs_length: FloatProperty(name="Length", description="Average log length.", default=10.0, min=3.0, max=20.0)
    logs_length_deviation: FloatProperty(name="Length Deviation", description="Random percentage variation applied to log length.", default=50.0, min=30.0, max=80.0)
    logs_deformation: FloatProperty(name="Deformation", description="Amount of bending, surface bulging, and end irregularity.", default=6.0, min=3.0, max=12.0)
    logs_make_bark: BoolProperty(name="Make Bark", description="Adds raised bark ridges around each log.", default=False)
    logs_bark_thickness: FloatProperty(name="Bark Thickness", description="Controls the height of generated bark ridges.", default=2.0, min=1.0, max=3.0)
    logs_high_poly: BoolProperty(name="High-Poly Result", description="Uses more radial and length segments for smoother logs.", default=False)
    logs_generation_number: IntProperty(name="Generation Number", description="Number of logs to generate.", default=5, min=1, max=20)
    logs_array: BoolProperty(name="Array", description="Places generated logs in a simple row.", default=True)
    logs_stacked: BoolProperty(name="Stacked", description="Stacks logs in a pile using the stack width and height controls.", default=False)
    logs_stack_width: IntProperty(name="Stack Width", description="Number of logs across the stack before starting a new layer.", default=12, min=3, max=35)
    logs_stack_height: IntProperty(name="Stack Height", description="Number of vertical layers in the stack.", default=3, min=1, max=8)

    meteor_count: IntProperty(name="Count", description="Number of meteor fragments to create.", default=5, min=1, max=10)
    meteor_large: FloatProperty(name="Large irregularity", description="Controls major silhouette deformation.", default=10.0, min=0.0, max=20.0)
    meteor_medium: FloatProperty(name="Medium irregularity", description="Controls medium-scale bumps and dents.", default=10.0, min=0.0, max=20.0)
    meteor_small: FloatProperty(name="Small irregularity/craters", description="Controls fine pitting and crater-like depressions.", default=10.0, min=0.0, max=20.0)
    meteor_optimize: BoolProperty(name="Optimize", description="Adds a Decimate modifier to reduce generated mesh complexity.", default=False)
    meteor_optimize_percent: FloatProperty(name="Optimize", description="Percentage of mesh reduction for generated stones.", default=30.0, min=10.0, max=90.0)

    obsidian_count: IntProperty(name="Count", description="Number of obsidian shards to create.", default=5, min=1, max=10)
    obsidian_irregularity: FloatProperty(name="Shape Irregularity", description="Amount of random vertex displacement used to make each gemstone unique.", default=10.0, min=0.0, max=10.0)
    obsidian_optimize: BoolProperty(name="Optimize", description="Adds a Decimate modifier to reduce generated mesh complexity.", default=False)
    obsidian_optimize_percent: FloatProperty(name="Optimize", description="Percentage of mesh reduction for generated stones.", default=30.0, min=10.0, max=90.0)

    pigeon_material: BoolProperty(name="Create Material", description="Creates simple grey pigeon materials for the generated birds.", default=True)
    pigeon_animation: EnumProperty(name="Animation", description="Selects the generated wing flap and travel animation style.", items=(("CASUAL", "casual flight", "casual flight"), ("FAST", "fast flight", "fast flight")), default="CASUAL")
    pigeon_particle: BoolProperty(name="Create Particle Flow", description="Creates a group of birds to approximate the original Particle Flow flock behavior.", default=True)
    pigeon_number: IntProperty(name="Number Of Birds", description="Number of bird meshes to create.", default=15, min=1, max=50)

    planks_count: IntProperty(name="Count", description="Number of plank pieces to create.", default=10, min=1, max=25)
    planks_len_max: FloatProperty(name="LenMax", description="Maximum plank length.", default=60.0, min=10.0, max=80.0)
    planks_len_min: FloatProperty(name="LenMin", description="Minimum plank length.", default=50.0, min=10.0, max=80.0)
    planks_width_max: FloatProperty(name="WidthMax", description="Maximum plank width.", default=6.0, min=0.5, max=20.0)
    planks_width_min: FloatProperty(name="WidthMin", description="Minimum plank width.", default=4.0, min=0.5, max=20.0)
    planks_height_max: FloatProperty(name="HeightMax", description="Maximum plank thickness.", default=1.0, min=0.5, max=20.0)
    planks_height_min: FloatProperty(name="HeightMin", description="Minimum plank thickness.", default=1.0, min=0.5, max=20.0)
    planks_irregular_ends: BoolProperty(name="Irregular Ends", description="Offsets end vertices so planks look broken or saw-cut unevenly.", default=True)
    planks_break: BoolProperty(name="Break Planks", description="Splits some planks into two angled pieces.", default=True)
    planks_knots: BoolProperty(name="Knot Holes", description="Adds dark circular knot details to plank surfaces.", default=True)
    planks_twist: BoolProperty(name="Twist Planks", description="Rotates sections of each plank slightly along its length.", default=True)
    planks_cracks: BoolProperty(name="Plank Cracks", description="Adds thin dark crack details along the plank length.", default=False)
    planks_cracks_count: IntProperty(name="Cracks", description="Number of crack lines per plank when plank cracks are enabled.", default=2, min=1, max=4)

    river_count: IntProperty(name="Count", description="Number of river stones to create.", default=5, min=1, max=10)
    river_irregular: BoolProperty(name="Irregular Shape", description="Adds broad shape distortion so stones are not perfect spheres.", default=True)
    river_irregular_amount: FloatProperty(name="Amount", description="Strength of broad river-stone shape distortion.", default=10.0, min=0.0, max=30.0)
    river_irregular_size: FloatProperty(name="Size", description="Scale of broad river-stone shape distortion.", default=10.0, min=0.0, max=30.0)
    river_banding: BoolProperty(name="Banding", description="Adds layered color bands around stones.", default=True)
    river_band_amount: FloatProperty(name="Amount", description="Strength of generated banding detail.", default=10.0, min=0.0, max=30.0)
    river_band_size: FloatProperty(name="Size", description="Scale of generated banding detail.", default=10.0, min=0.0, max=30.0)
    river_pitting: BoolProperty(name="Pitting", description="Adds small pitted depressions to the stone surface.", default=True)
    river_pitting_amount: FloatProperty(name="Amount", description="Strength of generated pitting detail.", default=10.0, min=0.0, max=30.0)
    river_pitting_size: FloatProperty(name="Size", description="Scale of generated pitting detail.", default=10.0, min=0.0, max=30.0)
    river_chipping: BoolProperty(name="Chipping", description="Adds sharper chipped areas on some edges.", default=False)
    river_chip_amount: FloatProperty(name="Amount", description="Strength of generated chip deformation.", default=10.0, min=0.0, max=30.0)
    river_optimize: BoolProperty(name="Optimize", description="Adds a Decimate modifier to reduce generated mesh complexity.", default=False)
    river_optimize_percent: FloatProperty(name="Optimize", description="Percentage of mesh reduction for generated stones.", default=30.0, min=10.0, max=90.0)

    sandstone_count: IntProperty(name="Count", description="Number of sandstone chunks to create.", default=5, min=1, max=10)
    sandstone_facets_start: IntProperty(name="Facets start", description="Minimum number of sides used by sandstone slabs.", default=4, min=3, max=15)
    sandstone_facets_end: IntProperty(name="Facets End", description="Maximum number of sides used by sandstone slabs.", default=9, min=3, max=15)
    sandstone_thickness: FloatProperty(name="Thickness", description="Average slab thickness.", default=10.0, min=1.0, max=20.0)
    sandstone_thickness_var: FloatProperty(name="Thickness Variation", description="Random thickness variation applied per chunk.", default=10.0, min=0.0, max=20.0)
    sandstone_edge_detail: BoolProperty(name="Edge Detail", description="Adds rough and chipped slab edges.", default=True)
    sandstone_optimize: BoolProperty(name="Optimize", description="Adds a Decimate modifier to reduce generated mesh complexity.", default=False)
    sandstone_optimize_percent: FloatProperty(name="Optimize", description="Percentage of mesh reduction for generated stones.", default=30.0, min=10.0, max=90.0)

    shrapnel_count: IntProperty(name="Debris Count", description="Number of shrapnel panels to create.", default=10, min=1, max=50)
    shrapnel_resolution: IntProperty(name="Panel Resolution", description="Subdivisions used before warping and cutting the panel.", default=20, min=1, max=50)
    shrapnel_noise_scale: FloatProperty(name="Panel Noise Scale", description="Scale of random panel surface displacement.", default=2.5, min=1.0, max=10.0)
    shrapnel_cut_holes: BoolProperty(name="Cut Holes", description="Removes random cells from the generated panel to make torn holes.", default=True)

    slate_count: IntProperty(name="Count", description="Number of slate chunks to create.", default=5, min=1, max=10)
    slate_facets_start: IntProperty(name="Facets start", description="Minimum number of sides used by sandstone slabs.", default=4, min=3, max=15)
    slate_facets_end: IntProperty(name="Facets End", description="Maximum number of sides used by sandstone slabs.", default=9, min=3, max=15)
    slate_thickness: FloatProperty(name="Thickness", description="Average slab thickness.", default=10.0, min=1.0, max=40.0)
    slate_thickness_var: FloatProperty(name="Thickness Variation", description="Random thickness variation applied per chunk.", default=10.0, min=0.0, max=20.0)
    slate_plates: IntProperty(name="Plates Count", description="Number of thin layers used in each slate chunk.", default=5, min=1, max=15)
    slate_plates_variation: IntProperty(name="Plates Count Variation", description="Random variation applied to the number of slate layers.", default=0, min=0, max=14)
    slate_optimize: BoolProperty(name="Optimize", description="Adds a Decimate modifier to reduce generated mesh complexity.", default=False)
    slate_optimize_percent: FloatProperty(name="Optimize", description="Percentage of mesh reduction for generated stones.", default=30.0, min=10.0, max=90.0)

    snow_count: IntProperty(name="Debris Count", description="Number of snowflake meshes to create.", default=5, min=1, max=50)

    splinters_count: IntProperty(name="Count", description="Number of splinter pieces to create.", default=20, min=1, max=40)
    splinters_twisting: FloatProperty(name="Twisting", description="Amount of spiral twist along the splinter length.", default=10.0, min=1.0, max=120.0)
    splinters_height: FloatProperty(name="Height", description="Average splinter length.", default=50.0, min=30.0, max=100.0)
    splinters_height_variation: FloatProperty(name="Height Variation", description="Random variation applied to splinter length.", default=20.0, min=0.0, max=40.0)

    twigs_count: IntProperty(name="Twig Count", description="Number of twig objects to create.", default=5, min=1, max=20)
    twigs_length: FloatProperty(name="Twig Length", description="Average twig length.", default=50.0, min=30.0, max=100.0)
    twigs_segments: IntProperty(name="Twig Segments", description="Number of segments used along each twig.", default=10, min=5, max=20)
    twigs_twisting: BoolProperty(name="Twisting", description="Twists the twig cross-section along its length.", default=True)
    twigs_warping: BoolProperty(name="Warping", description="Bends the twig centerline so it does not remain straight.", default=True)
    twigs_warts: BoolProperty(name="Twig Warts", description="Adds small raised bumps on bark.", default=True)
    twigs_warts_count: IntProperty(name="Warts", description="Number of wart bumps per twig.", default=8, min=1, max=20)
    twigs_broken_ends: BoolProperty(name="Broken ends", description="Creates jagged broken-looking twig ends.", default=True)
    twigs_ends_value: FloatProperty(name="Ends", description="Strength of end break deformation.", default=0.5, min=0.10, max=1.0)
    twigs_branching: BoolProperty(name="Twig Branching", description="Adds smaller branch cylinders coming from the main twig.", default=False)
    twigs_branch_length: FloatProperty(name="Branch Length", description="Average length of generated twig branches.", default=5.0, min=1.0, max=30.0)
    twigs_branch_count: IntProperty(name="Branch Count", description="Number of branches per twig.", default=3, min=1, max=5)
    twigs_weld_all: BoolProperty(name="Weld all elements", description="Joins generated twig pieces into one object per twig when possible.", default=True)


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


def _resource_snapshot() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    for name in ('objects', 'meshes', 'curves', 'materials', 'collections'):
        try:
            result[name] = {id(item) for item in getattr(bpy.data, name)}
        except Exception:
            result[name] = set()
    return result


def _cleanup_generation_transaction(snapshot: dict[str, set[int]], preserve=()) -> bool:
    """Rollback only exact resources created after *snapshot*.

    The function never calls global orphan purge and never removes an untagged,
    foreign, old-generation, linked, or user-created datablock.
    """
    ok = True
    preserve_ids = {id(item) for item in preserve if item is not None}
    try:
        objects = list(getattr(bpy.data, 'objects', []) or [])
    except Exception:
        objects = []
    for obj in reversed(objects):
        if id(obj) in snapshot.get('objects', set()) or id(obj) in preserve_ids:
            continue
        if _is_owned(obj):
            ok = _remove_owned_object_and_data(obj) and ok
    for name, collection_name in (('meshes', 'meshes'), ('curves', 'curves'), ('materials', 'materials')):
        collection = getattr(bpy.data, collection_name, None)
        if collection is None:
            continue
        for item in reversed(list(collection)):
            if id(item) in snapshot.get(name, set()) or id(item) in preserve_ids or not _is_owned(item):
                continue
            try:
                if int(getattr(item, 'users', 0)) == 0:
                    collection.remove(item)
            except Exception:
                ok = False
    collections = getattr(bpy.data, 'collections', None)
    if collections is not None:
        for item in reversed(list(collections)):
            if id(item) in snapshot.get('collections', set()) or not _is_owned(item):
                continue
            try:
                if len(getattr(item, 'objects', ())) == 0 and len(getattr(item, 'children', ())) == 0:
                    collections.remove(item)
            except Exception:
                ok = False
    return ok


def _localize_object_names(objects, module, context=None) -> None:
    if not _locale_is_ja(context):
        return
    label = next((tr(item[1], context) for item in MODULE_ITEMS if item[0] == module), '')
    if not label:
        return
    index = 0
    for obj in objects:
        index += 1
        while f"{label} {index:03d}" in bpy.data.objects:
            index += 1
        obj.name = f"{label} {index:03d}"
        data = getattr(obj, "data", None)
        if data is not None and data.users == 1:
            data.name = obj.name


class SGS_OT_debris_generate(Operator):
    bl_idname = "smart_geometry_suite.debris_generate"
    bl_label = "Generate"
    bl_description = "Creates the selected debris geometry in the scene."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(ownership.runtime_active_for_generation() and str(getattr(context, 'mode', '') or '') == 'OBJECT')

    def execute(self, context):
        p = get_settings(context)
        if p is None:
            self.report({"ERROR"}, catalog.text("Smart Geometry debris settings are not available.", "Smart Geometryデブリ設定を利用できません。"))
            return {"CANCELLED"}
        generator = GENERATORS.get(p.module)
        if generator is None:
            self.report({"ERROR"}, catalog.text(f"Unknown module: {p.module}", f"不明なモジュールです: {p.module}"))
            return {"CANCELLED"}
        snapshot = _resource_snapshot()
        objects = []
        try:
            objects = list(generator(context, p) or [])
            if not objects:
                raise RuntimeError('Generator returned no objects')
            if any(obj is None or not _is_owned(obj) for obj in objects):
                raise RuntimeError('Generator returned an unowned or invalid object')
            _cleanup_generation_transaction(snapshot, preserve=objects)
            _localize_object_names(objects, p.module, context)
        except Exception as exc:
            _cleanup_generation_transaction(snapshot)
            self.report({"ERROR"}, catalog.failure_text("Smart Geometry debris generation failed", "Smart Geometryデブリ生成に失敗しました", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, catalog.text(
            f"Generated {len(objects)} object(s) with {MODULE_TITLES.get(p.module, p.module)}",
            f"{tr(MODULE_TITLES.get(p.module, p.module), context)}で{len(objects)}個のオブジェクトを生成しました"))
        return {"FINISHED"}


class SGS_OT_debris_refresh_modules(Operator):
    bl_idname = "smart_geometry_suite.debris_refresh_modules"
    bl_label = "Embedded Module Availability"
    bl_description = "Reports that the bundled debris modules are available."

    def execute(self, context):
        self.report({"INFO"}, catalog.text("Smart Geometry debris modules are embedded and ready.", "Smart Geometryデブリモジュールは組み込み済みで、すぐに使えます。"))
        return {"FINISHED"}


class SGS_OT_debris_open_modules_dir(Operator):
    bl_idname = "smart_geometry_suite.debris_open_modules_dir"
    bl_label = "Open modules directory"
    bl_description = "Opens the add-on folder that contains the embedded modules and notices."

    def execute(self, context):
        import os
        import subprocess
        path = os.path.dirname(__file__)
        try:
            if hasattr(os, "startfile"):
                os.startfile(path)
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            self.report({"ERROR"}, catalog.failure_text("Could not open the folder", "フォルダーを開けませんでした", exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SGS_OT_debris_open_url(Operator):
    bl_idname = "smart_geometry_suite.debris_open_url"
    bl_label = "Open URL"
    bl_description = "Opens an online resource for the original debris-generator source project."
    action: EnumProperty(
        name="Resource",
        description="Selects which original Debris Maker 2 project or support page is opened in the system web browser.",
        items=(
            ("PROJECT", "Project", "Open the original Debris Maker 2 project page."),
            ("HELP", "Help", "Open the original Debris Maker 2 usage and reference page."),
            ("FEATURE", "Feature", "Open the project issue page for feature requests."),
            ("BUG", "Bug", "Open the project issue page for bug reports."),
        ),
    )

    def execute(self, context):
        urls = {
            "PROJECT": "https://github.com/TheOnlyAaron/Debris_Maker2",
            "HELP": "https://www.scriptspot.com/3ds-max/scripts/debrismaker2",
            "FEATURE": "https://github.com/TheOnlyAaron/Debris_Maker2/issues",
            "BUG": "https://github.com/TheOnlyAaron/Debris_Maker2/issues",
        }
        import webbrowser
        try:
            opened = bool(webbrowser.open(urls.get(self.action, urls["PROJECT"])))
        except Exception as exc:
            self.report({"ERROR"}, catalog.failure_text("Could not open the page", "ページを開けませんでした", exc))
            return {"CANCELLED"}
        if not opened:
            self.report({"ERROR"}, catalog.text("The system web browser did not accept the URL.", "システムのWebブラウザがURLを受け付けませんでした。"))
            return {"CANCELLED"}
        return {"FINISHED"}


class SGS_OT_debris_about(Operator):
    bl_idname = "smart_geometry_suite.debris_about"
    bl_label = "About"
    bl_description = "Shows version, license, and attribution information."

    def execute(self, context):
        manifest_path = Path(__file__).with_name("blender_manifest.toml")
        try:
            with manifest_path.open("rb") as manifest_file:
                manifest = tomllib.load(manifest_file)
            version = manifest["version"]
            license_text = ", ".join(manifest["license"])
        except (OSError, ValueError, KeyError, TypeError) as exc:
            self.report({"ERROR"}, catalog.failure_text(
                "Could not read debris version and license",
                "デブリのバージョンとライセンスを読み込めませんでした", exc))
            return {"CANCELLED"}
        self.report({"INFO"}, catalog.text(
            f"Smart Geometry {version} debris generators ({license_text}), integrated by JELararagi. "
            "Original Debris Maker 2 (MIT License) by Aaron Dabelow.",
            f"Smart Geometry {version} のデブリ生成（{license_text}）はJELararagiが統合しました。"
            "原案はAaron DabelowのDebris Maker 2（MITライセンス）です。",
            context))
        return {"FINISHED"}


# -----------------------------------------------------------------------------
# UI
# -----------------------------------------------------------------------------


def _prop(layout, data, prop_name, text=None, enabled=True):
    row = layout.row()
    row.enabled = enabled
    row.prop(data, prop_name, text=tr(text or getattr(type(data), prop_name).keywords.get("name", prop_name)))
    return row


def draw_brick(layout, p):
    layout.label(text=tr("Construction - Brick Pieces"))
    box = layout.box(); box.label(text=tr("Template"))
    row = box.row(align=True); row.prop(p, "brick_cinder", text=tr("Cinder")); row.prop(p, "brick_corner", text=tr("Corner")); row.prop(p, "brick_mason", text=tr("Mason"))
    box = layout.box(); box.label(text=tr("Poly level"))
    row = box.row(align=True); row.prop(p, "brick_low_poly", text=tr("Low Poly")); row.prop(p, "brick_high_poly", text=tr("High Poly"))
    _prop(layout, p, "brick_erosion", "Erosion")
    _prop(layout, p, "brick_irregularity", "Irregularity")
    _prop(layout, p, "brick_versions", "Versions", enabled=p.brick_flat_array)
    box = layout.box(); box.label(text=tr("Arrangement"))
    row = box.row(align=True); row.prop(p, "brick_flat_array", text=tr("Flat array")); row.prop(p, "brick_wall", text=tr("Masonry Wall"))
    row = box.row(align=True); row.enabled = p.brick_wall; row.prop(p, "brick_running", text=tr("Running")); row.prop(p, "brick_english", text=(tr("Brick English Bond") if tr("Brick English Bond") != "Brick English Bond" else "English")); row.prop(p, "brick_flemish", text=tr("Flemish"))
    _prop(box, p, "brick_wall_width", "Wall Width", enabled=p.brick_wall)
    _prop(box, p, "brick_wall_height", "Wall Height", enabled=p.brick_wall)
    _prop(box, p, "brick_mortar_gap", "Mortar Gap", enabled=p.brick_wall)
    _prop(box, p, "brick_special_n", "Special Rate", enabled=p.brick_wall)


def draw_corrugated(layout, p):
    layout.label(text=tr("Corrugated Metal"))
    for prop, label in (("corr_count", "Debris Count"), ("corr_detail", "Detail Level")):
        _prop(layout, p, prop, label)
    for prop, label in (("corr_slice", "Slice panels"), ("corr_irregular", "Irregular Shapes"), ("corr_rust_holes", "Rust Holes")):
        _prop(layout, p, prop, label)
    _prop(layout, p, "corr_rust_holes_count", "Rust Holes count", enabled=p.corr_rust_holes)
    _prop(layout, p, "corr_rust_clusters", "Rust Clusters", enabled=p.corr_rust_holes)
    _prop(layout, p, "corr_wrap", "Wrap Deform")
    _prop(layout, p, "corr_deform_creases", "Deform Creases", enabled=p.corr_wrap)
    _prop(layout, p, "corr_deform_amount", "Deform Amount", enabled=p.corr_wrap)


def draw_gem(layout, p, title="Gemstones"):
    layout.label(text=tr(title))
    _prop(layout, p, "gem_count", "Count")
    _prop(layout, p, "gem_irregularity", "Shape Irregularity")
    _prop(layout, p, "gem_facets", "Facets to cut")
    _prop(layout, p, "gem_chamfer", "Chamfer Edges")
    _prop(layout, p, "gem_chamfer_amount", "Chamfer amount", enabled=p.gem_chamfer)


def draw_grass(layout, p):
    layout.label(text=tr("Grass"))
    _prop(layout, p, "grass_tuft_count", "Tuft Count")
    _prop(layout, p, "grass_type", "Grass Type")
    _prop(layout, p, "grass_blades_count", "Blades Count")
    _prop(layout, p, "grass_fade", "Fade off mode")
    _prop(layout, p, "grass_height", "Grass Height")
    _prop(layout, p, "grass_leaf_count", "Leaf Count")
    _prop(layout, p, "grass_leaf_bend", "Leaf Bend")
    _prop(layout, p, "grass_leaf_irregularity", "Leaf Irregularity")


def draw_gravel(layout, p):
    layout.label(text=tr("Gravel"))
    _prop(layout, p, "gravel_count", "Count")
    _prop(layout, p, "gravel_irregularity_size", "Irregularity Size")
    _prop(layout, p, "gravel_roughness", "Roughness/Smoothness")
    _prop(layout, p, "gravel_optimize", "Optimize result")
    _prop(layout, p, "gravel_optimize_percent", "Optimize", enabled=p.gravel_optimize)


def draw_leaves(layout, p):
    layout.label(text=tr("Fallen Leaves"))
    _prop(layout, p, "leaves_count", "Leaf Count")
    _prop(layout, p, "leaves_high_res", "High Resolution")
    _prop(layout, p, "leaves_thickness", "With thickness")
    for check, val, label in (("leaves_crease", "leaves_crease_value", "Crease"), ("leaves_skew", "leaves_skew_value", "Skew"), ("leaves_twist", "leaves_twist_value", "Twist"), ("leaves_noise", "leaves_noise_value", "Noise")):
        row = layout.row(align=True); row.prop(p, check, text=tr(label)); sub = row.row(); sub.enabled = getattr(p, check); sub.prop(p, val, text="")
    _prop(layout, p, "leaves_tears", "Tears")
    _prop(layout, p, "leaves_holes", "Holes")
    box = layout.box(); box.label(text=tr("Leaf Type"))
    col = box.column(align=True)
    for prop, label in (("leaves_ash", "Ash"), ("leaves_birch", "Birch"), ("leaves_elm", "Elm"), ("leaves_maple", "Maple"), ("leaves_red_oak", "Red Oak"), ("leaves_white_oak", "White Oak")):
        col.prop(p, prop, text=tr(label))


def draw_logs(layout, p):
    layout.label(text=tr("Wood Logs"))
    for prop, label in (("logs_radius", "Radius"), ("logs_radius_deviation", "Radius Deviation"), ("logs_length", "Length"), ("logs_length_deviation", "Length Deviation"), ("logs_deformation", "Deformation")):
        _prop(layout, p, prop, label)
    _prop(layout, p, "logs_make_bark", "Make Bark")
    _prop(layout, p, "logs_bark_thickness", "Bark Thickness", enabled=p.logs_make_bark)
    _prop(layout, p, "logs_high_poly", "High-Poly Result")
    _prop(layout, p, "logs_generation_number", "Generation Number")
    row = layout.row(align=True); row.prop(p, "logs_array", text=tr("Array")); row.prop(p, "logs_stacked", text=tr("Stacked"))
    _prop(layout, p, "logs_stack_width", "Stack Width", enabled=p.logs_stacked)
    _prop(layout, p, "logs_stack_height", "Stack Height", enabled=p.logs_stacked)


def draw_meteor(layout, p):
    layout.label(text=tr("Meteor"))
    _prop(layout, p, "meteor_count", "Count")
    _prop(layout, p, "meteor_large", "Large irregularity")
    _prop(layout, p, "meteor_medium", "Medium irregularity")
    _prop(layout, p, "meteor_small", "Small irregularity/craters")
    _prop(layout, p, "meteor_optimize", "Optimize")
    _prop(layout, p, "meteor_optimize_percent", "Optimize", enabled=p.meteor_optimize)


def draw_obsidian(layout, p):
    layout.label(text=tr("Obsidian"))
    _prop(layout, p, "obsidian_count", "Count")
    _prop(layout, p, "obsidian_irregularity", "Shape Irregularity")
    _prop(layout, p, "obsidian_optimize", "Optimize")
    _prop(layout, p, "obsidian_optimize_percent", "Optimize", enabled=p.obsidian_optimize)


def draw_pigeons(layout, p):
    layout.label(text=tr("Pigeons"))
    _prop(layout, p, "pigeon_material", "Create Material")
    _prop(layout, p, "pigeon_animation", "Animation")
    _prop(layout, p, "pigeon_particle", "Create Particle Flow")
    _prop(layout, p, "pigeon_number", "Number Of Birds", enabled=p.pigeon_particle)


def draw_planks(layout, p):
    layout.label(text=tr("Planks"))
    for prop, label in (("planks_count", "Count"), ("planks_len_max", "LenMax"), ("planks_len_min", "LenMin"), ("planks_width_max", "WidthMax"), ("planks_width_min", "WidthMin"), ("planks_height_max", "HeightMax"), ("planks_height_min", "HeightMin")):
        _prop(layout, p, prop, label)
    for prop, label in (("planks_irregular_ends", "Irregular Ends"), ("planks_break", "Break Planks"), ("planks_knots", "Knot Holes"), ("planks_twist", "Twist Planks"), ("planks_cracks", "Plank Cracks")):
        _prop(layout, p, prop, label)
    _prop(layout, p, "planks_cracks_count", "Cracks", enabled=p.planks_cracks)


def draw_river(layout, p):
    layout.label(text=tr("Riverstones"))
    _prop(layout, p, "river_count", "Count")
    for chk, amount, size, label in (("river_irregular", "river_irregular_amount", "river_irregular_size", "Irregular Shape"), ("river_banding", "river_band_amount", "river_band_size", "Banding"), ("river_pitting", "river_pitting_amount", "river_pitting_size", "Pitting")):
        box = layout.box(); box.prop(p, chk, text=tr(label)); box.enabled = True
        _prop(box, p, amount, "Amount", enabled=getattr(p, chk)); _prop(box, p, size, "Size", enabled=getattr(p, chk))
    _prop(layout, p, "river_chipping", "Chipping")
    _prop(layout, p, "river_chip_amount", "Amount", enabled=p.river_chipping)
    _prop(layout, p, "river_optimize", "Optimize")
    _prop(layout, p, "river_optimize_percent", "Optimize", enabled=p.river_optimize)


def draw_sandstone(layout, p):
    layout.label(text=tr("Sandstone"))
    for prop, label in (("sandstone_count", "Count"), ("sandstone_facets_start", "Facets start"), ("sandstone_facets_end", "Facets End"), ("sandstone_thickness", "Thickness"), ("sandstone_thickness_var", "Thickness Variation")):
        _prop(layout, p, prop, label)
    _prop(layout, p, "sandstone_edge_detail", "Edge Detail")
    _prop(layout, p, "sandstone_optimize", "Optimize")
    _prop(layout, p, "sandstone_optimize_percent", "Optimize", enabled=p.sandstone_optimize)


def draw_shrapnel(layout, p):
    layout.label(text=tr("Shrapnel"))
    _prop(layout, p, "shrapnel_count", "Debris Count")
    _prop(layout, p, "shrapnel_resolution", "Panel Resolution")
    _prop(layout, p, "shrapnel_noise_scale", "Panel Noise Scale")
    _prop(layout, p, "shrapnel_cut_holes", "Cut Holes")


def draw_slate(layout, p):
    layout.label(text=tr("Slate"))
    for prop, label in (("slate_count", "Count"), ("slate_facets_start", "Facets start"), ("slate_facets_end", "Facets End"), ("slate_thickness", "Thickness"), ("slate_thickness_var", "Thickness Variation"), ("slate_plates", "Plates Count"), ("slate_plates_variation", "Plates Count Variation")):
        _prop(layout, p, prop, label)
    _prop(layout, p, "slate_optimize", "Optimize")
    _prop(layout, p, "slate_optimize_percent", "Optimize", enabled=p.slate_optimize)


def draw_snow(layout, p):
    layout.label(text=tr("Snowflakes"))
    _prop(layout, p, "snow_count", "Debris Count")


def draw_splinters(layout, p):
    layout.label(text=tr("Splinters"))
    _prop(layout, p, "splinters_count", "Count")
    _prop(layout, p, "splinters_twisting", "Twisting")
    _prop(layout, p, "splinters_height", "Height")
    _prop(layout, p, "splinters_height_variation", "Height Variation")


def draw_twigs(layout, p):
    layout.label(text=tr("Twigs"))
    for prop, label in (("twigs_count", "Twig Count"), ("twigs_length", "Twig Length"), ("twigs_segments", "Twig Segments")):
        _prop(layout, p, prop, label)
    for prop, label in (("twigs_twisting", "Twisting"), ("twigs_warping", "Warping"), ("twigs_warts", "Twig Warts")):
        _prop(layout, p, prop, label)
    _prop(layout, p, "twigs_warts_count", "Warts", enabled=p.twigs_warts)
    _prop(layout, p, "twigs_broken_ends", "Broken ends")
    _prop(layout, p, "twigs_ends_value", "Ends", enabled=p.twigs_broken_ends)
    _prop(layout, p, "twigs_branching", "Twig Branching")
    _prop(layout, p, "twigs_branch_length", "Branch Length", enabled=p.twigs_branching)
    _prop(layout, p, "twigs_branch_count", "Branch Count", enabled=p.twigs_branching)
    _prop(layout, p, "twigs_weld_all", "Weld all elements")


DRAWERS = {
    "BRICK": draw_brick,
    "CORRUGATED": draw_corrugated,
    "CRYSTAL": lambda layout, p: draw_gem(layout, p, "Crystal"),
    "GEMSTONES": draw_gem,
    "GRASS": draw_grass,
    "GRAVEL": draw_gravel,
    "LEAVES": draw_leaves,
    "LOGS": draw_logs,
    "METEOR": draw_meteor,
    "OBSIDIAN": draw_obsidian,
    "PIGEONS": draw_pigeons,
    "PLANKS": draw_planks,
    "RIVERSTONES": draw_river,
    "SANDSTONE": draw_sandstone,
    "SHRAPNEL": draw_shrapnel,
    "SLATE": draw_slate,
    "SNOWFLAKES": draw_snow,
    "SPLINTERS": draw_splinters,
    "TWIGS": draw_twigs,
}


def get_settings(context=None):
    try:
        scene = (context or bpy.context).scene
        return getattr(scene, "smart_geometry_suite_debris", None)
    except Exception:
        return None


def _draw_child_panel(layout, owner, prop_name: str, label_key: str, *, icon: str = "NONE"):
    label = tr(label_key)
    try:
        header, body = layout.panel_prop(owner, prop_name)
    except Exception:
        try:
            owner_key = int(owner.as_pointer())
        except Exception:
            owner_key = id(owner)
        header, body = layout.panel(
            idname=f"smart_geometry_debris_child_{prop_name}_{owner_key}",
            default_closed=not bool(getattr(owner, prop_name, True)),
        )
    if icon and icon != "NONE":
        header.label(text=label, icon=icon)
    else:
        header.label(text=label)
    return body


def draw_panel(layout, context, *, include_popup_button: bool = True, include_info: bool = True) -> None:
    p = get_settings(context)
    if p is None:
        layout.label(text=tr("Settings", context), icon="ERROR")
        return

    module_body = _draw_child_panel(layout, p, "ui_child_debris_module", "Module Selection", icon="MESH_ICOSPHERE")
    if module_body is not None:
        if include_popup_button:
            module_body.operator("smart_geometry_suite.debris_open_window", text=tr("Smart Geometry Debris", context), icon="MESH_ICOSPHERE")
        module_body.prop(p, "module", text=tr("Module", context))
        module_body.prop(p, "seed", text=tr("Seed", context))

    params_body = _draw_child_panel(layout, p, "ui_child_debris_parameters", "Active Module Parameters", icon="TOOL_SETTINGS")
    if params_body is not None:
        drawer = DRAWERS.get(p.module)
        if drawer:
            drawer(params_body, p)

    generation_body = _draw_child_panel(layout, p, "ui_child_debris_generation", "Generation", icon="MESH_ICOSPHERE")
    if generation_body is not None:
        generation_body.operator("smart_geometry_suite.debris_generate", text=tr("Generate", context), icon="MESH_ICOSPHERE")

    if include_info:
        info = _draw_child_panel(layout, p, "ui_child_debris_info", "Information and Links", icon="URL")
        if info is not None:
            info.operator("smart_geometry_suite.debris_refresh_modules", text=tr("Embedded Module Availability", context), icon="CHECKMARK")
            info.operator("smart_geometry_suite.debris_open_modules_dir", text=tr("Open modules directory", context), icon="FILE_FOLDER")
            op = info.operator("smart_geometry_suite.debris_open_url", text=tr("Check online for more...", context), icon="URL"); op.action = "PROJECT"
            op = info.operator("smart_geometry_suite.debris_open_url", text=tr("Online help...", context), icon="HELP"); op.action = "HELP"
            op = info.operator("smart_geometry_suite.debris_open_url", text=tr("Request a feature...", context), icon="LIGHT_DATA"); op.action = "FEATURE"
            op = info.operator("smart_geometry_suite.debris_open_url", text=tr("Report a bug...", context), icon="ERROR"); op.action = "BUG"
            info.operator("smart_geometry_suite.debris_about", text=tr("About", context))

class SGS_OT_debris_open_window(Operator):
    bl_idname = "smart_geometry_suite.debris_open_window"
    bl_label = "Smart Geometry Debris"
    bl_description = "Opens a compact Smart Geometry debris generator window with the module dropdown and active module controls."

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=240)

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        draw_panel(self.layout, context, include_popup_button=False, include_info=True)

def menu_func(self, context):
    layout = self.layout
    previous_context = getattr(layout, "operator_context", None)
    try:
        layout.operator_context = 'INVOKE_DEFAULT'
        layout.operator(
            "smart_geometry_suite.debris_open_window",
            text=tr("Smart Geometry Debris"),
            icon="MESH_ICOSPHERE",
        )
    finally:
        if previous_context is not None:
            try:
                layout.operator_context = previous_context
            except Exception:
                pass


def _install_persistence_updates() -> None:
    """Attach the canonical JSON callback to every portable debris setting."""
    annotations = getattr(SGS_DebrisSettings, '__annotations__', {}) or {}
    for name, prop_def in tuple(annotations.items()):
        factory = getattr(prop_def, 'function', None)
        keywords = getattr(prop_def, 'keywords', None)
        if not callable(factory) or not isinstance(keywords, dict):
            continue
        previous = keywords.get('update')

        def _make_update(previous_callback):
            # Blender validates update callback arity and rejects a closure
            # that exposes a third defaulted argument.  Capture the previous
            # callback in an outer factory so the registered function has the
            # exact required ``(self, context)`` signature.
            def _update(self, context):
                if callable(previous_callback):
                    previous_callback(self, context)
                try:
                    from . import properties
                    properties.on_debris_setting_changed(context)
                except Exception:
                    pass
            return _update

        rebuilt = dict(keywords)
        rebuilt['update'] = _make_update(previous)
        annotations[name] = factory(**rebuilt)


_install_persistence_updates()


CLASSES = (
    SGS_DebrisSettings,
    SGS_OT_debris_generate,
    SGS_OT_debris_refresh_modules,
    SGS_OT_debris_open_modules_dir,
    SGS_OT_debris_open_url,
    SGS_OT_debris_about,
    SGS_OT_debris_open_window,
)


def register_runtime(
    ledger=None, *, register_menu: bool = True, register_translation: bool = True,
) -> None:
    """Register exact Debris runtime resources through the Suite ledger."""
    global _DEBRIS_RUNTIME_REGISTERED, _DEBRIS_MENU_REGISTERED
    from . import ownership
    ledger = ledger or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        raise RuntimeError('Smart Geometry Debris ownership ledger is unavailable')
    owned = any(
        record.get('owner') is bpy.types.Scene
        and record.get('name') == 'smart_geometry_suite_debris'
        for record in ledger.get('pointers', ())
    )
    if not owned:
        ownership.register_pointer(
            ledger,
            bpy.types.Scene,
            'smart_geometry_suite_debris',
            PointerProperty(
                name='Smart Geometry Debris Settings',
                description='Stores the Smart Geometry debris generator module, parameters, section state, and persistence options for this scene.',
                type=SGS_DebrisSettings,
            ),
        )
    if register_translation:
        ownership.register_translation(ledger, __name__, _TRANSLATIONS)
    if register_menu:
        ownership.register_menu(ledger, bpy.types.VIEW3D_MT_mesh_add, menu_func)
        _DEBRIS_MENU_REGISTERED = True
    _DEBRIS_RUNTIME_REGISTERED = True


def resume_runtime(ledger=None) -> bool:
    """Compatibility entry point; central runtime owns normal menu registration."""
    global _DEBRIS_MENU_REGISTERED
    from . import ownership
    ledger = ledger or ownership.shared_ledger()
    if not _DEBRIS_RUNTIME_REGISTERED or not ownership.ledger_is_exact(ledger):
        return False
    for record in ledger.get('menus', ()):
        callback = record.get('callback')
        if getattr(callback, '_jelararagi_sgs_original', None) is menu_func:
            _DEBRIS_MENU_REGISTERED = True
            return True
    ownership.register_menu(ledger, bpy.types.VIEW3D_MT_mesh_add, menu_func)
    _DEBRIS_MENU_REGISTERED = True
    return True


def suspend_runtime() -> bool:
    """Mark compatibility state; exact callback removal is ledger-owned."""
    global _DEBRIS_MENU_REGISTERED
    _DEBRIS_MENU_REGISTERED = False
    clear_runtime_caches()
    return True


def unregister_runtime() -> bool:
    """Compatibility hook; full RNA teardown is performed transactionally."""
    global _DEBRIS_RUNTIME_REGISTERED, _DEBRIS_MENU_REGISTERED
    _DEBRIS_RUNTIME_REGISTERED = False
    _DEBRIS_MENU_REGISTERED = False
    clear_runtime_caches()
    return True
