"""Smart Geometry 1.0.0 — independent native Blender implementation."""
import bpy
from . import schema,bindings,interface,preferences_store,lifecycle
from .max_procedural_primitives import runtime
__version__='1.0.0'
REGISTERED=[]
def register():
    try:
        schema.register()
        for cls in bindings.CLASSES:bpy.utils.register_class(cls);REGISTERED.append(cls)
        interface.load_icons();bpy.types.VIEW3D_MT_add.append(interface.add_menu);runtime.register_handlers();preferences_store.register();lifecycle.register()
    except Exception:
        unregister()
        raise
def unregister():
    lifecycle.unregister();preferences_store.unregister();runtime.unregister_handlers()
    try:bpy.types.VIEW3D_MT_add.remove(interface.add_menu)
    except (ValueError,AttributeError):pass
    interface.unload_icons()
    for cls in reversed(REGISTERED):bpy.utils.unregister_class(cls)
    REGISTERED.clear();schema.unregister()
