# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Smart Geometry settings and event-driven persistence.

The module has no timers, watchdogs, mtime polling, or import-time Blender
registration.  RNA is installed by the Suite registration transaction, and every
handler/msgbus subscription is recorded by the exact generation ledger.
"""

import json
from typing import Any

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from . import catalog, ownership, storage

# Dynamic factories below receive validated runtime text.  Keep this alias separate
# from declarative BoolProperty calls so every generated field is guaranteed a
# non-empty name and beginner-readable tooltip before RNA construction.
_DYNAMIC_BOOL_FIELD_FACTORY = BoolProperty

_SETTINGS_PROP = 'smart_geometry_suite_settings'
_SETTINGS_FILE = 'Smart_Geometry_Suite.json'
_SETTINGS_DIR = 'Smart_Geometry_Suite'
_SETTINGS_SCHEMA = 'smart_geometry_suite.blender_config_settings.v3'
_SETTINGS_VERSION = '8.2.46'
_N_PANEL_STATE_SAVE_PROP = 'n_panel_state_save'

_LAST_SERIALIZED_SETTINGS = ''
_LAST_FLUSH_ERROR = ''
_APPLYING_SETTINGS = False
_STARTUP_RESTORE_PENDING = False
_SUSPEND_SETTINGS_SAVE = False
_SETTINGS_DIRTY = False
_SETTINGS_PROP_NAMES_CACHE: tuple[str, ...] | None = None
_PERSISTENCE_HOOKS_REGISTERED = False
_ACTIVE_HOOK_GENERATION = ''
_LOAD_PRE_FLUSH_OK = True

_SUPPORTED_REDRAW_SPACES = frozenset({
    'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR', 'SEQUENCE_EDITOR', 'CLIP_EDITOR',
    'DOPESHEET_EDITOR', 'GRAPH_EDITOR', 'NLA_EDITOR', 'TEXT_EDITOR',
    'FILE_BROWSER', 'SPREADSHEET',
})


def _legacy_settings_dir_name() -> str:
    return 'Smart_Geometry' + 'Node_Suite'


def _legacy_settings_file_name() -> str:
    return 'Smart_Geometry' + 'Node_Suite.json'


def _settings_storage_path(create: bool = True):
    folder = storage.blender_config_dir(_SETTINGS_DIR, create=create)
    path = folder / _SETTINGS_FILE
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def settings_storage_path(create: bool = True):
    """Return the canonical external N-panel settings JSON path."""
    return _settings_storage_path(create=create)


def _legacy_settings_storage_paths() -> tuple[object, ...]:
    """Return read-only compatibility candidates; this function never migrates."""
    paths: list[object] = []
    candidates = (
        lambda: storage.blender_config_file(_SETTINGS_FILE, create=False),
        lambda: storage.blender_config_dir(_legacy_settings_dir_name(), create=False) / _legacy_settings_file_name(),
        lambda: storage.blender_config_file(_legacy_settings_file_name(), create=False),
        lambda: storage.legacy_extension_user_data_dir('settings') / 'n_panel_settings.json',
        lambda: storage.blender_config_file('n_panel_settings.json', create=False),
    )
    for factory in candidates:
        try:
            paths.append(factory())
        except Exception:
            pass
    result: list[object] = []
    seen: set[str] = set()
    try:
        current = str(_settings_storage_path(create=False))
    except Exception:
        current = ''
    for path in paths:
        try:
            key = str(path)
        except Exception:
            continue
        if not key or key == current or key in seen:
            continue
        seen.add(key)
        result.append(path)
    return tuple(result)


def _migrate_legacy_settings_storage() -> None:
    """Compatibility no-op retained for public callers.

    Automatic migration was removed because registration/repair must not mutate
    user configuration.  Legacy files remain readable and are copied only when a
    user explicitly changes a setting and the canonical file is atomically saved.
    """
    return None


def _tag_view3d_redraw(context=None) -> None:
    """Redraw all eleven supported N-panel physical spaces on explicit events."""
    try:
        wm = getattr(context or bpy.context, 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            screen = getattr(window, 'screen', None)
            for area in tuple(getattr(screen, 'areas', ()) or ()):
                if getattr(area, 'type', None) in _SUPPORTED_REDRAW_SPACES:
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _simple_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return str(value)


def _settings_prop_names() -> tuple[str, ...]:
    global _SETTINGS_PROP_NAMES_CACHE
    if _SETTINGS_PROP_NAMES_CACHE is None:
        try:
            annotations = getattr(SGS_Settings, '__annotations__', {}) or {}
            _SETTINGS_PROP_NAMES_CACHE = tuple(
                str(name) for name in annotations if not str(name).startswith('_')
            )
        except Exception:
            _SETTINGS_PROP_NAMES_CACHE = ()
    return _SETTINGS_PROP_NAMES_CACHE


def _collect_setting_values(settings) -> dict[str, object]:
    values: dict[str, object] = {}
    if settings is None:
        return values
    for name in _settings_prop_names():
        try:
            values[name] = _simple_value(getattr(settings, name))
        except Exception:
            pass
    return values


def _debris_settings(context=None):
    try:
        scene = getattr(context or bpy.context, 'scene', None)
        return getattr(scene, 'smart_geometry_suite_debris', None)
    except Exception:
        return None


def _debris_prop_names() -> tuple[str, ...]:
    try:
        from . import debris_generators
        annotations = getattr(debris_generators.SGS_DebrisSettings, '__annotations__', {}) or {}
        return tuple(str(name) for name in annotations if not str(name).startswith('_'))
    except Exception:
        return ()


def _collect_debris_values(context=None) -> dict[str, object]:
    settings = _debris_settings(context)
    if settings is None:
        return {}
    values: dict[str, object] = {}
    for name in _debris_prop_names():
        try:
            value = getattr(settings, name)
            if isinstance(value, (bool, int, float, str)) or value is None:
                values[name] = value
        except Exception:
            pass
    return values


def _load_full_payload(path) -> dict[str, object]:
    try:
        if path is not None and path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            return raw if isinstance(raw, dict) else {}
    except Exception:
        pass
    return {}


def _normalise_loaded_payload(raw) -> dict[str, object]:
    if not isinstance(raw, dict):
        return {}
    payload: Any = raw
    if isinstance(raw.get('settings'), dict):
        payload = raw.get('settings') or {}
    elif isinstance(raw.get('window_manager'), dict):
        nested = (raw.get('window_manager') or {}).get(_SETTINGS_PROP)
        if isinstance(nested, dict):
            payload = nested
    if not isinstance(payload, dict):
        return {}
    names = set(_settings_prop_names())
    if not names:
        return {str(k): v for k, v in payload.items() if isinstance(k, str)}
    return {str(k): v for k, v in payload.items() if str(k) in names}


def _load_settings_from_path(path) -> dict[str, object]:
    return _normalise_loaded_payload(_load_full_payload(path))


def load_saved_settings() -> dict[str, object]:
    """Read settings at an explicit startup/load boundary without writing files."""
    paths: list[object] = []
    try:
        paths.append(_settings_storage_path(create=False))
    except Exception:
        pass
    paths.extend(_legacy_settings_storage_paths())
    for path in paths:
        loaded = _load_settings_from_path(path)
        if loaded:
            return loaded
    return {}


def load_saved_debris_settings() -> dict[str, object]:
    """Read portable Debris settings without migration or repair writes."""
    names = set(_debris_prop_names())
    paths: list[object] = []
    try:
        paths.append(_settings_storage_path(create=False))
    except Exception:
        pass
    paths.extend(_legacy_settings_storage_paths())
    for path in paths:
        values = _load_full_payload(path).get('debris_settings')
        if isinstance(values, dict):
            return {str(k): v for k, v in values.items() if str(k) in names}
    return {}


def _n_panel_state_save_enabled(context=None, settings=None) -> bool:
    try:
        settings = settings or get_settings(context)
        return bool(getattr(settings, _N_PANEL_STATE_SAVE_PROP))
    except Exception:
        return True


def settings_dirty() -> bool:
    return bool(_SETTINGS_DIRTY)


def last_flush_error() -> str:
    return str(_LAST_FLUSH_ERROR)


def save_settings(context=None, *, force: bool = False):
    """Atomically save the current RNA values; raise on every write failure."""
    del force
    global _LAST_SERIALIZED_SETTINGS, _SETTINGS_DIRTY
    if _APPLYING_SETTINGS or _STARTUP_RESTORE_PENDING:
        raise RuntimeError('Smart Geometry settings are currently being restored')
    settings = get_settings(context)
    if settings is None:
        raise RuntimeError('Smart Geometry settings RNA is unavailable')
    payload = {
        'schema': _SETTINGS_SCHEMA,
        'version': _SETTINGS_VERSION,
        'settings': _collect_setting_values(settings),
        'debris_settings': _collect_debris_values(context),
    }
    serialized = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
        allow_nan=False, default=str,
    )
    path = _settings_storage_path(create=True)
    if serialized == _LAST_SERIALIZED_SETTINGS and path.exists():
        _SETTINGS_DIRTY = False
        return path
    try:
        if path.exists() and path.read_text(encoding='utf-8') == serialized:
            _LAST_SERIALIZED_SETTINGS = serialized
            _SETTINGS_DIRTY = False
            return path
    except Exception:
        # A failed optimization read must not prevent the authoritative atomic write.
        pass
    storage.atomic_write_text(path, serialized, encoding='utf-8')
    # Verify the exact committed bytes before reporting success.
    committed = path.read_text(encoding='utf-8')
    if committed != serialized:
        raise IOError('Smart Geometry settings atomic readback mismatch')
    _LAST_SERIALIZED_SETTINGS = serialized
    _SETTINGS_DIRTY = False
    return path


def flush_deferred_settings(context=None, *, force: bool = True) -> bool:
    """Flush current RNA values and return an explicit success/failure result."""
    del force
    global _SETTINGS_DIRTY, _LAST_FLUSH_ERROR
    if _APPLYING_SETTINGS or _STARTUP_RESTORE_PENDING:
        _LAST_FLUSH_ERROR = 'settings_restore_in_progress'
        return False
    # Lifecycle boundaries flush only unsaved RNA.  A clean boundary performs no
    # config read, stat, directory creation, or write.  Direct save_settings()
    # remains the explicit-save API when the caller intentionally wants a file.
    if not _SETTINGS_DIRTY:
        _LAST_FLUSH_ERROR = ''
        return True
    try:
        save_settings(context, force=True)
    except Exception as exc:
        _SETTINGS_DIRTY = True
        _LAST_FLUSH_ERROR = f'{type(exc).__name__}: {exc}'
        return False
    _LAST_FLUSH_ERROR = ''
    _SETTINGS_DIRTY = False
    return True


def _settings_deferred_save_required(context=None) -> bool:
    del context
    return bool(_SETTINGS_DIRTY)


def _mark_settings_dirty(context=None) -> bool:
    global _SETTINGS_DIRTY
    if _APPLYING_SETTINGS or _STARTUP_RESTORE_PENDING:
        return True
    # RNA remains installed during a Manager soft-OFF.  External scripts may still
    # change a setting, so retain the dirty state without starting I/O or runtime
    # reconciliation while suspended.
    _SETTINGS_DIRTY = True
    if _SUSPEND_SETTINGS_SAVE:
        return True
    if _n_panel_state_save_enabled(context=context):
        return flush_deferred_settings(context, force=True)
    return True


def apply_saved_settings(context=None, *, reconcile_runtime: bool = True) -> bool:
    """Restore JSON only at a fresh-register or explicit load-post boundary."""
    global _APPLYING_SETTINGS
    settings = get_settings(context)
    if settings is None:
        return False
    loaded = load_saved_settings()
    changed = False
    previous = _APPLYING_SETTINGS
    _APPLYING_SETTINGS = True
    try:
        for name, value in loaded.items():
            if not hasattr(settings, name):
                continue
            try:
                if getattr(settings, name) != value:
                    setattr(settings, name, value)
                    changed = True
            except Exception:
                pass
    finally:
        _APPLYING_SETTINGS = previous
    changed = apply_saved_debris_settings(context) or changed
    if reconcile_runtime:
        _reconcile_feature_runtime(context)
    if changed:
        _tag_view3d_redraw(context)
    return changed


def apply_saved_debris_settings(context=None) -> bool:
    global _APPLYING_SETTINGS
    settings = _debris_settings(context)
    loaded = load_saved_debris_settings()
    if settings is None or not loaded:
        return False
    previous = _APPLYING_SETTINGS
    _APPLYING_SETTINGS = True
    changed = False
    try:
        for name, value in loaded.items():
            if not hasattr(settings, name):
                continue
            try:
                if getattr(settings, name) != value:
                    setattr(settings, name, value)
                    changed = True
            except Exception:
                pass
    finally:
        _APPLYING_SETTINGS = previous
    if changed:
        _tag_view3d_redraw(context)
    return changed


def _reconcile_feature_runtime(context=None) -> None:
    if not ownership.runtime_active_for_generation():
        return
    try:
        from . import always_on
        always_on.apply_all_persistent_features(context)
    except Exception:
        pass


def _release_lazy_runtime_caches() -> None:
    try:
        from . import runtime
        runtime.release_lazy_implementation_caches()
    except Exception:
        pass


def _on_settings_update(self, context) -> None:
    del self
    _mark_settings_dirty(context)
    _tag_view3d_redraw(context)


def on_debris_setting_changed(context=None) -> None:
    _mark_settings_dirty(context)
    _tag_view3d_redraw(context)


def _on_selection_string_update(self, context) -> None:
    _on_settings_update(self, context)
    if not _APPLYING_SETTINGS and not _SUSPEND_SETTINGS_SAVE:
        try:
            from . import always_on
            always_on.on_selection_string_changed(context)
        except Exception:
            pass


def _on_n_panel_state_save_update(self, context) -> None:
    del self
    global _SETTINGS_DIRTY
    if not _APPLYING_SETTINGS and not _SUSPEND_SETTINGS_SAVE:
        _SETTINGS_DIRTY = True
        flush_deferred_settings(context, force=True)
    _tag_view3d_redraw(context)


def _on_always_on_update(self, context) -> None:
    _on_settings_update(self, context)
    if not _APPLYING_SETTINGS and not _SUSPEND_SETTINGS_SAVE:
        _reconcile_feature_runtime(context)


def _sgs_load_pre_handler(*_args) -> None:
    global _SUSPEND_SETTINGS_SAVE, _LOAD_PRE_FLUSH_OK
    # File loading cannot be cancelled by an add-on.  Never tear down modal/lazy
    # resources or arm JSON restoration unless the current RNA snapshot was
    # committed successfully.
    _LOAD_PRE_FLUSH_OK = flush_deferred_settings(bpy.context, force=True)
    if not _LOAD_PRE_FLUSH_OK:
        return
    _SUSPEND_SETTINGS_SAVE = True
    try:
        from . import runtime
        runtime.on_load_pre_boundary()
    except Exception:
        # Preserve the installed RNA generation.  load_post will not restore JSON
        # unless the complete pre-load boundary succeeded.
        _LOAD_PRE_FLUSH_OK = False
        _SUSPEND_SETTINGS_SAVE = False


def _sgs_load_post_handler(*_args) -> None:
    global _SUSPEND_SETTINGS_SAVE, _LOAD_PRE_FLUSH_OK
    boundary_ok = bool(_LOAD_PRE_FLUSH_OK)
    _LOAD_PRE_FLUSH_OK = True
    try:
        if not boundary_ok:
            return
        apply_saved_settings(bpy.context, reconcile_runtime=False)
        try:
            from . import runtime
            runtime.on_load_post_boundary()
        except Exception:
            return
        _reconcile_feature_runtime(bpy.context)
        try:
            if any(group.name.startswith("Max Primitives_GN_v21_") for group in bpy.data.node_groups):
                from .max_procedural_primitives import node_interface
                node_interface.rename_saved_groups()
        except Exception:
            pass
        _reconcile_feature_runtime(bpy.context)
        try:
            from . import always_on
            always_on.on_load_post(bpy.context)
        except Exception:
            pass
    finally:
        _SUSPEND_SETTINGS_SAVE = False
    _tag_view3d_redraw(bpy.context)


def _sgs_save_pre_handler(*_args) -> None:
    if not flush_deferred_settings(bpy.context, force=True):
        return
    try:
        from . import always_on
        if always_on.feature_value('transform_snapshot_restore', bpy.context):
            from . import transform_guard
            transform_guard.save_scene_transform_snapshot(bpy.context)
        always_on.on_scene_lifecycle(bpy.context)
    except Exception:
        pass


def _sgs_exit_pre_handler(*_args) -> None:
    flush_deferred_settings(bpy.context, force=True)
    try:
        from . import runtime
        runtime.on_exit_pre_boundary()
    except Exception:
        pass


def _sgs_autosave_timer():
    """Removed compatibility callback: recurring autosave is intentionally absent."""
    return None


def _sgs_preferences_save_watch_timer():
    """Removed compatibility callback: preference-file polling is absent."""
    return None


def _on_scene_switched() -> None:
    # A scene transition is an explicit persistence boundary: commit the outgoing
    # RNA snapshot before restoring per-scene Debris values for the incoming scene.
    if not flush_deferred_settings(bpy.context, force=True):
        return
    apply_saved_debris_settings(bpy.context)
    _reconcile_feature_runtime(bpy.context)
    _tag_view3d_redraw(bpy.context)


def register_persistence_hooks(ledger: dict[str, Any]) -> None:
    global _PERSISTENCE_HOOKS_REGISTERED, _ACTIVE_HOOK_GENERATION
    if not ownership.ledger_is_exact(ledger):
        raise RuntimeError('Smart Geometry persistence ledger is unavailable')
    generation = str(ledger.get('generation') or '')
    if _PERSISTENCE_HOOKS_REGISTERED and _ACTIVE_HOOK_GENERATION == generation:
        return
    handlers = bpy.app.handlers
    for collection_name, callback in (
        ('load_pre', _sgs_load_pre_handler),
        ('load_post', _sgs_load_post_handler),
        ('load_post_fail', _sgs_load_post_handler),
        ('save_pre', _sgs_save_pre_handler),
        ('exit_pre', _sgs_exit_pre_handler),
        ('load_factory_startup_post', _sgs_load_post_handler),
    ):
        collection = getattr(handlers, collection_name, None)
        if collection is not None:
            ownership.register_handler(ledger, collection, callback, persistent=True)
    try:
        ownership.register_msgbus(
            ledger,
            key=(bpy.types.Window, 'scene'),
            notify=_on_scene_switched,
            options={'PERSISTENT'},
        )
    except Exception:
        # The Window.scene RNA key can be unavailable in stripped test stubs; no
        # substitute polling path is created.
        pass
    _PERSISTENCE_HOOKS_REGISTERED = True
    _ACTIVE_HOOK_GENERATION = generation


def _mark_hooks_suspended() -> None:
    global _PERSISTENCE_HOOKS_REGISTERED, _ACTIVE_HOOK_GENERATION
    _PERSISTENCE_HOOKS_REGISTERED = False
    _ACTIVE_HOOK_GENERATION = ''


def suspend_runtime(*, flush: bool = True) -> bool:
    """Flush before Manager soft-OFF; return False without changing state on failure."""
    global _SUSPEND_SETTINGS_SAVE
    if flush and not flush_deferred_settings(bpy.context, force=True):
        return False
    _SUSPEND_SETTINGS_SAVE = True
    _mark_hooks_suspended()
    return True


def resume_runtime(ledger: dict[str, Any] | None = None) -> bool:
    """Install event hooks once; never reload JSON during Manager resume/repair."""
    global _SUSPEND_SETTINGS_SAVE
    ledger = ledger or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return False
    register_persistence_hooks(ledger)
    _SUSPEND_SETTINGS_SAVE = False
    return True


def _category_items(self, context):
    return catalog.category_items(context)


def _feature_items(self, context):
    return catalog.feature_items(context)


def _pack_items(self, context):
    return catalog.pack_items(context)


def _source_items(self, context):
    return catalog.source_items(context)


_PRECISION_PRESET_ITEMS = [
    ('preview', 'Preview', 'Fast responsive setup for early blocking and icon-driven testing.'),
    ('production', 'Production', 'Balanced high-quality defaults for most procedural scenes.'),
    ('extreme', 'Extreme', 'Maximum local quality defaults for dense terrain, distribution, and diagnostics.'),
]

_UI_DENSITY_ITEMS = [
    ('visual', 'Visual Command Deck', 'Prioritize large icon buttons and fewer exposed technical controls.'),
    ('balanced', 'Balanced', 'Show visual buttons plus the most important technical controls.'),
    ('technical', 'Technical', 'Show dense controls, catalogs, metadata, and diagnostic details.'),
]


def _precision_preset_items(self, context):
    return _PRECISION_PRESET_ITEMS


def _ui_density_items(self, context):
    return _UI_DENSITY_ITEMS


_DEFAULT_FEATURE = catalog.FEATURES[0]['id'] if catalog.FEATURES else 'smart_attribute_dictionary'
_DEFAULT_PACK = catalog.PACKS[0]['id'] if catalog.PACKS else 'p0_core'


class SGS_Settings(bpy.types.PropertyGroup):
    feature_category: EnumProperty(
        name='Feature Category',
        description='Filters the catalog by functional family. This only changes the displayed list and never deletes, disables, or modifies generated node groups.',
        items=_category_items,
        default=0,
        update=_on_settings_update,
    )
    source_filter: EnumProperty(
        name='Design Domain Filter',
        description='Filters the catalog by independent design domain such as attributes, selection, terrain, motion, architecture, materials, diagnostics, automation, or open data.',
        items=_source_items,
        default=0,
        update=_on_settings_update,
    )
    active_feature: EnumProperty(
        name='Active Feature',
        description='Selects the feature capsule to apply or inspect. Each item maps a researched functional requirement to an independent Blender-safe Geometry Nodes workflow with its own naming, metadata, and UI.',
        items=_feature_items,
        default=0,
        update=_on_settings_update,
    )
    active_pack: EnumProperty(
        name='Active Pack',
        description='Selects a predefined group of feature capsules. Packs are workflow stacks such as core attributes, environment generation, motion FX, architecture, interop, or precision-overdrive workflows.',
        items=_pack_items,
        default=0,
        update=_on_settings_update,
    )
    search_filter: StringProperty(
        name='Search Filter',
        description='Type a feature name, design domain, keyword, category, or Japanese term to narrow the visible catalog. Leave empty to show all features matching the other filters.',
        default='',
        update=_on_settings_update,
    )
    capsule_prefix: StringProperty(
        name='Capsule Prefix',
        description='Prefix used for generated node groups, Geometry Nodes modifiers, helper objects, reports, and attributes. A unique prefix makes generated data easy to locate and remove.',
        default='SGS',
        update=_on_settings_update,
    )
    mark_assets: BoolProperty(
        name='Mark Node Groups as Assets',
        description='When enabled, newly generated node groups are marked as Blender assets if the current Blender build supports asset marking. Disable this when creating temporary test groups.',
        default=True,
        update=_on_settings_update,
    )
    selection_string: StringProperty(
        name='Selection String',
        description='Selection expression for the precision selection engine. Supported forms include all, none, even, odd, active, ranges such as 2-15, invert:0-9, density>0.5, height:0.2-0.8, slope<0.4, boundary, interior, highest(density,0.25), lowest(), band(), rank(), grow(), shrink(), and boolean combinations with and/or/xor/except.',
        default='all',
        update=_on_selection_string_update,
    )
    terrain_resolution: IntProperty(
        name='Terrain Resolution',
        description='Number of grid points per side when generating precision terrain. Higher values create more vertices and richer terrain attributes but take longer to compute.',
        default=96,
        min=2,
        max=512,
        update=_on_settings_update,
    )
    terrain_size: FloatProperty(
        name='Terrain Size',
        description='World size of the generated terrain grid. Use larger values for landscape blockouts and smaller values for material or habitat tests.',
        default=12.0,
        min=0.01,
        max=10000.0,
        update=_on_settings_update,
    )
    terrain_height: FloatProperty(
        name='Terrain Height',
        description='Maximum procedural displacement height used by the terrain generator. This writes height, slope, flow, wetness, sediment, erosion, channel, stream, bank, and strata attributes for later scattering and materials.',
        default=1.5,
        min=0.0,
        max=1000.0,
        update=_on_settings_update,
    )
    terrain_erosion_iterations: IntProperty(
        name='Terrain Erosion Iterations',
        description='Number of thermal relaxation passes used before hydraulic flow and sediment attributes are calculated. Increase for smoother eroded ridges; decrease for faster previews.',
        default=12,
        min=0,
        max=120,
        update=_on_settings_update,
    )
    terrain_hydraulic_droplets: IntProperty(
        name='Terrain Hydraulic Droplets',
        description='Number of deterministic water-drop walkers used by the terrain solver. Higher values carve cleaner channels, banks, deposition fields, and stream-order attributes, but increase generation time.',
        default=4096,
        min=0,
        max=250000,
        update=_on_settings_update,
    )
    terrain_hydraulic_iterations: IntProperty(
        name='Terrain Hydraulic Iterations',
        description='Optional lightweight hydraulic transport pass count used by precision terrain helpers. Higher values sharpen channels and sediment maps when helper functions use this control.',
        default=18,
        min=0,
        max=120,
        update=_on_settings_update,
    )
    terrain_channel_strength: FloatProperty(
        name='Terrain Channel Strength',
        description='Strength of the hydraulic channel and deposition pass. Use values near 1 for natural terrain, lower values for subtle erosion, and higher values for stronger river cuts.',
        default=1.0,
        min=0.0,
        max=5.0,
        update=_on_settings_update,
    )
    terrain_v7_ridge_preservation: FloatProperty(
        name='Terrain Ridge Preservation',
        description='Controls the ridge-preserving terrain relaxation. Higher values keep sharp ridges while still smoothing unstable pits and terraces for cleaner hydrology.',
        default=0.55,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    )
    terrain_v7_channel_count: IntProperty(
        name='Terrain Channel Count',
        description='Maximum number of deterministic primary channel walkers used by the terrain pass. Increase for denser river networks; decrease for faster or drier terrain.',
        default=24,
        min=0,
        max=512,
        update=_on_settings_update,
    )
    scatter_count: IntProperty(
        name='Scatter Count',
        description='Target amount used by surface distribution, helper blocks, growth curves, and visible proxy instances. Distribution may create fewer points when blue-noise spacing rejects overcrowded samples.',
        default=512,
        min=1,
        max=200000,
        update=_on_settings_update,
    )
    structure_floors: IntProperty(
        name='Structure Floors',
        description='Number of floors in the modular structure. More floors make a taller structure; the width and depth follow Radius / Size.',
        default=15,
        min=1,
        max=160,
        update=_on_settings_update,
    )
    scatter_radius: FloatProperty(
        name='Scatter Radius',
        description='Default radius, spacing, or helper-object size used by scatter, growth, surface-detail, visible proxy, and fragmentation tools. Keep this near the visible asset footprint for better spacing.',
        default=0.15,
        min=0.0001,
        max=1000.0,
        update=_on_settings_update,
    )
    scatter_min_spacing: FloatProperty(
        name='Scatter Minimum Spacing',
        description='Minimum world-space distance between accepted scatter points when blue-noise mode is enabled. Use this to reduce overlaps and produce cleaner environment distributions.',
        default=0.12,
        min=0.0,
        max=10000.0,
        update=_on_settings_update,
    )
    scatter_blue_noise: BoolProperty(
        name='Use Blue-Noise Rejection',
        description='Rejects scatter candidates that are too close to accepted points. This improves distribution quality and avoids obvious clumping at the cost of additional computation.',
        default=True,
        update=_on_settings_update,
    )
    scatter_quality_passes: IntProperty(
        name='Scatter Quality Passes',
        description='Candidate multiplier for the low-discrepancy adaptive surface distributor. Higher values improve blue-noise quality and density fairness when many candidates are rejected.',
        default=5,
        min=1,
        max=24,
        update=_on_settings_update,
    )
    scatter_relax_iterations: IntProperty(
        name='Scatter Relax Iterations',
        description='Number of post-placement relaxation passes for point distributions. This reduces residual clumping after blue-noise rejection and improves spacing regularity.',
        default=2,
        min=0,
        max=16,
        update=_on_settings_update,
    )
    scatter_adaptive_spacing: BoolProperty(
        name='Use Adaptive Spacing',
        description='Adapts point spacing per sampled density, habitat score, and slope. Dense stable areas can accept closer points while sparse or steep areas keep wider spacing.',
        default=True,
        update=_on_settings_update,
    )
    scatter_visibility_culling: BoolProperty(
        name='Use Camera Visibility Gate',
        description='When a scene camera exists, lowers or rejects distribution on surfaces outside the camera frustum by using the sgs_visibility attribute. Disable for full-world generation.',
        default=False,
        update=_on_settings_update,
    )
    scatter_normal_offset: FloatProperty(
        name='Scatter Normal Offset',
        description='Offsets generated scatter points along the sampled surface normal. Use a small positive value to keep preview points or instances above the source surface.',
        default=0.01,
        min=-1000.0,
        max=1000.0,
        update=_on_settings_update,
    )
    scatter_biome_bias: FloatProperty(
        name='Scatter Habitat Bias',
        description='Adjusts how strongly habitat attributes influence surface distribution. Positive values favor general-ground and dense-habitat areas; zero uses only area and density.',
        default=0.25,
        min=-5.0,
        max=5.0,
        update=_on_settings_update,
    )
    scatter_candidate_multiplier: IntProperty(
        name='Scatter Candidate Multiplier',
        description='Controls how many candidate samples the precision surface distributor may test per requested point. Increase for cleaner spacing and better weighted placement; decrease for faster previews.',
        default=12,
        min=1,
        max=64,
        update=_on_settings_update,
    )
    scatter_v7_lloyd_iterations: IntProperty(
        name='Tangent Relax Iterations',
        description='Additional tangent-plane relaxation passes applied after point distribution. This evens spacing while preserving the sampled surface normal direction as much as possible.',
        default=2,
        min=0,
        max=24,
        update=_on_settings_update,
    )
    scatter_v7_fairness_strength: FloatProperty(
        name='Distribution Fairness Strength',
        description='Controls how strongly spacing diagnostics and tangent relaxation try to normalize nearest-neighbor spacing across dense and sparse regions.',
        default=0.65,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    )
    density_threshold: FloatProperty(
        name='Density Threshold',
        description='Threshold used by density, selection, habitat, scatter, and visibility tools. Values below the threshold are treated as less likely to generate or be selected.',
        default=0.5,
        min=0.0,
        max=1.0,
        update=_on_settings_update,
    )
    growth_branches: IntProperty(
        name='Growth Branches',
        description='Number of deterministic branch splines created by the organic growth curve builder. More branches produce denser ivy, root, cable, vein, or trail-style guides.',
        default=5,
        min=1,
        max=96,
        update=_on_settings_update,
    )
    drainage_curve_count: IntProperty(
        name='Drainage Curve Count',
        description='Maximum number of downhill flow curves generated from high-flow terrain or mesh attributes. Use this after building precision attributes or terrain to visualize drainage and channel guides.',
        default=32,
        min=1,
        max=256,
        update=_on_settings_update,
    )
    fragment_piece_count: IntProperty(
        name='Fragment Piece Count',
        description='Target number of clustered mesh fragments created by the precision fragmentation builder. A value of zero chooses the amount automatically from the face count of the mesh.',
        default=0,
        min=0,
        max=768,
        update=_on_settings_update,
    )
    fragment_v7_contiguity: FloatProperty(
        name='Fragment Contiguity Bias',
        description='Controls how strongly the graph clustering keeps adjacent faces in the same fragment before separation. Higher values reduce scattered islands inside a single fragment.',
        default=0.82,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    )
    diagnostic_sample_limit: IntProperty(
        name='Diagnostic Sample Limit',
        description='Maximum number of object and attribute samples written into diagnostics reports. Increase for deeper audits and decrease to keep reports compact.',
        default=2048,
        min=16,
        max=200000,
        update=_on_settings_update,
    )
    debug_attribute: StringProperty(
        name='Debug Attribute',
        description='Attribute name used by heatmap and snapshot tools. You can type names such as sgs_density, sgs_slope, sgs_flow, sgs_channel, sgs_quality, or short aliases such as density, slope, flow, quality.',
        default='sgs_density',
        update=_on_settings_update,
    )
    random_seed: IntProperty(
        name='Random Seed',
        description='Deterministic seed used by generated attributes, terrain noise, point placement, surface-detail blocks, fragments, growth curves, and visible proxy instances.',
        default=1729,
        min=0,
        max=2147483647,
        update=_on_settings_update,
    )
    csv_path: StringProperty(
        name='CSV Path',
        description='Optional path to a CSV file containing x, y, z columns and optional id, scale, density, and custom numeric columns. The Import CSV Points operator also provides a file browser.',
        subtype='FILE_PATH',
        default='',
        update=_on_settings_update,
    )

    precision_preset: EnumProperty(
        name='Precision Preset',
        description='Chooses a tuned default profile for terrain, distribution, relaxation, diagnostics, and visual workflow buttons. Preview is fast, Production is balanced, and Extreme spends more computation for cleaner results.',
        items=_PRECISION_PRESET_ITEMS,
        default='production',
        update=_on_settings_update,
    )
    ui_density: EnumProperty(
        name='UI Density',
        description='Controls how the Smart Geometry panels are presented. Visual mode emphasizes large custom icon buttons, Balanced keeps both icons and key controls, and Technical exposes dense controls and metadata.',
        items=_UI_DENSITY_ITEMS,
        default='balanced',
        update=_on_settings_update,
    )
    ui_use_custom_icons: BoolProperty(
        name='Use Custom Icon Buttons',
        description='Blender 5.1 crash-safe mode keeps live custom preview icon IDs disabled. Command buttons use Blender standard icons; bundled 32 px transparent PNGs remain available as static reference/export assets.',
        default=False,
        update=_on_settings_update,
    )


    precision_v7_strength: FloatProperty(
        name='Base Precision Strength',
        description='Global intensity for the precision polish. Higher values strengthen distribution priority, material-region contrast, contact scoring, and debug quality while keeping generated attributes deterministic and Blender-native.',
        default=0.85,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    )
    precision_v7_feature_preservation: FloatProperty(
        name='Feature Preservation',
        description='Controls how strongly the precision polish preserves ridges, cavities, boundary details, and high-curvature regions while smoothing noisy attribute fields.',
        default=0.72,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    )
    precision_v7_material_regions: IntProperty(
        name='Material Regions',
        description='Number of stable material-region IDs generated by the material composer. These IDs can drive procedural material masks and neutral export primvars.',
        default=7,
        min=2,
        max=64,
        update=_on_settings_update,
    )

    show_advanced: BoolProperty(
        name='Show Advanced',
        description='Shows advanced controls, design coverage, requirement metadata, generated IDs, and technical diagnostics in the Smart Geometry panels.',
        default=False,
        update=_on_settings_update,
    )




# Unified Smart Modeling-style section visibility.  Stored on WindowManager so
# the N-panel can be redrawn without add-on preferences access.
SGS_Settings.__annotations__.update({
    'ui_section_always_on': BoolProperty(
        name='Show Always-on Toggles Section',
        description='Expand or collapse the Smart Geometry always-on toggle section in the compact grouped N-panel UI.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_suite_controls': BoolProperty(
        name='Show Suite Controls Section',
        description='Expand or collapse the active feature, active pack, apply, and library controls section.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_visual_dashboard': BoolProperty(
        name='Show Visual Dashboard Section',
        description='Expand or collapse the visual workflow dashboard section.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_quick_start': BoolProperty(
        name='Show Quick Start Section',
        description='Expand or collapse the quick start setup and preset controls section.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_feature_catalog': BoolProperty(
        name='Show Feature Catalog Section',
        description='Expand or collapse the filtered feature catalog section.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_procedural_builders': BoolProperty(
        name='Show Procedural Builders Section',
        description='Expand or collapse the procedural builders section.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_builder_controls': BoolProperty(
        name='Show Builder Controls Section',
        description='Expand or collapse detailed terrain, scatter, drainage, growth, fragment, precision, and debug builder controls.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_debris_generators': BoolProperty(
        name='Show Debris Generators Section',
        description='Expand or collapse the integrated Smart Geometry debris generator controls inside the Procedural Builders section. These controls create procedural rubble, stones, vegetation, metal sheets, wood pieces, birds, snowflakes, and related scene debris from the selected module.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_interop': BoolProperty(
        name='Show Interop and Manifests Section',
        description='Expand or collapse CSV, USD, bundle, and exchange manifest controls.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_diagnostics': BoolProperty(
        name='Show Diagnostics Section',
        description='Expand or collapse mesh diagnostics, generated node group reports, and diagnostic export commands.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_visual_ui': BoolProperty(
        name='Show Visual UI Section',
        description='Expand or collapse visual UI, icon scale, precision, and custom icon reference controls.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_design_coverage': BoolProperty(
        name='Show Design Coverage Section',
        description='Expand or collapse design coverage and domain coverage reports.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_terrain_generators': BoolProperty(
        name='Show Terrain and Environment Generators Section',
        description='Expand or collapse the terrain and environment generator section. It contains only direct generation commands for terrain meshes and drainage flow curves, with the parameters those generators actually read.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_distribution_generators': BoolProperty(
        name='Show Distribution and Scatter Generators Section',
        description='Expand or collapse the distribution generator section. It contains point-cloud, scatter, relaxation, proxy instance, and CSV point generation controls with the relevant distribution settings.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_structure_surface_generators': BoolProperty(
        name='Show Structure and Surface Generators Section',
        description='Expand or collapse the structure and surface generator section. It contains direct generation tools for surface detail blocks and modular structures with their own settings.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_organic_stroke_generators': BoolProperty(
        name='Show Organic and Stroke Generators Section',
        description='Expand or collapse the organic and stroke generator section. It contains organic curve creation and Grease Pencil to mesh generation commands.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_debris_fragment_generators': BoolProperty(
        name='Show Debris and Fragment Generators Section',
        description='Expand or collapse the debris and fragment generator section. It contains the integrated debris module generator and mesh fragmentation generator with only their generation settings.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_primitive_generators': BoolProperty(
        name='Show Primitive Generators Section',
        description='Expand or collapse the primitive generator section. It contains direct Max Primitive creation commands without unrelated asset maintenance controls.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_attribute_visual_generators': BoolProperty(
        name='Show Attribute and Visualization Generators Section',
        description='Expand or collapse the attribute and visualization generator section. It contains only direct commands that build precision attributes, procedural selection attributes, heatmap materials, and attribute snapshot meshes, with the exact settings those commands use.',
        default=False,
        update=_on_settings_update,
    ),
    'ui_section_settings': BoolProperty(
        name='Show Settings Section',
        description='Expand or collapse the consolidated settings section at the bottom of the Smart Geometry panel. Non-generation controls, diagnostics, reports, visual reference options, and advanced feature application tools are grouped here.',
        default=False,
        update=_on_settings_update,
    ),
})


def _child_foldout_property(name: str, description: str, default: bool = True):
    safe_name = str(name or '').strip() or 'Smart Geometry Child Section'
    safe_description = str(description or '').strip() or (
        'Controls whether this Smart Geometry child section is expanded in the N-panel. '
        'Enable it to show the contained controls and disable it to collapse them; the '
        'setting is stored with the other Smart Geometry N-panel states.'
    )
    return _DYNAMIC_BOOL_FIELD_FACTORY(
        name=safe_name,
        description=safe_description,
        default=default,
        update=_on_settings_update,
    )


# Blender-standard child foldouts used inside the existing top-level Smart
# Geometry sections.  These are stored with the N-panel settings so users can
# keep frequently used groups open without adding extra sidebar panels.
SGS_Settings.__annotations__.update({
    'ui_child_always_on_state_save': _child_foldout_property('Show N-Panel State Child Section', 'Opens or closes the child foldout that controls whether Smart Geometry remembers N-panel section states between Blender sessions. Use the triangle beside the label to keep this storage control visible or hidden.', True),
    'ui_child_always_on_helpers': _child_foldout_property('Show Background Helpers Child Section', 'Opens or closes the child foldout containing lightweight always-on helper toggles such as mesh inspection, attribute guards, selection sync, visibility gates, and diagnostics snapshots.', True),

    'ui_child_suite_overview': _child_foldout_property('Show Suite Overview Child Section', 'Opens or closes the child foldout that shows the Smart Geometry Suite identity and version summary inside Suite Controls.', True),
    'ui_child_suite_active_targets': _child_foldout_property('Show Active Targets Child Section', 'Opens or closes the child foldout for choosing the active feature and active pack before applying Smart Geometry operations.', True),
    'ui_child_suite_actions': _child_foldout_property('Show Suite Actions Child Section', 'Opens or closes the child foldout that contains the main apply and node-library creation commands.', True),
    'ui_child_suite_storage': _child_foldout_property('Show Storage Child Section', 'Opens or closes the advanced child foldout that displays the Smart Geometry external storage path used for generated reports, manifests, and persistent settings.', False),

    'ui_child_dashboard_preset': _child_foldout_property('Show Dashboard Preset Child Section', 'Opens or closes the child foldout for selecting and applying the dashboard precision preset.', True),
    'ui_child_dashboard_precision': _child_foldout_property('Show Dashboard Precision Child Section', 'Opens or closes the child foldout containing the precision polish and refinement workflow tiles.', True),
    'ui_child_dashboard_scene_workflows': _child_foldout_property('Show Dashboard Scene Workflows Child Section', 'Opens or closes the child foldout containing environment, surface, fragment, diagnostic, and full-demo workflow tiles.', True),

    'ui_child_quick_start_actions': _child_foldout_property('Show Quick Start Actions Child Section', 'Opens or closes the child foldout for node-library setup, rebuild, demo-scene creation, full toolset application, and quick precision polish commands.', True),
    'ui_child_quick_start_presets': _child_foldout_property('Show Quick Start Presets Child Section', 'Opens or closes the child foldout for capsule prefix, asset marking, and precision preset settings used by quick-start commands.', True),
    'ui_child_quick_start_display': _child_foldout_property('Show Quick Start Display Child Section', 'Opens or closes the child foldout for quick-start display and advanced-view options.', False),

    'ui_child_catalog_filters': _child_foldout_property('Show Catalog Filters Child Section', 'Opens or closes the child foldout for filtering the feature catalog by category, design domain, and search text.', True),
    'ui_child_catalog_results': _child_foldout_property('Show Catalog Results Child Section', 'Opens or closes the child foldout that lists matching Smart Geometry features with apply and help buttons.', True),

    'ui_child_builders_precision_setup': _child_foldout_property('Show Builder Precision Setup Child Section', 'Opens or closes the child foldout for standard attribute creation, scene precision refinement, and precision polish commands.', True),
    'ui_child_builders_selection': _child_foldout_property('Show Builder Selection Child Section', 'Opens or closes the child foldout for entering and applying selection-string based procedural targeting.', True),
    'ui_child_builder_controls_terrain': _child_foldout_property('Show Terrain Builder Controls Child Section', 'Opens or closes the nested child foldout for terrain, erosion, hydrology, channel, ridge, and field-fusion builder parameters.', False),
    'ui_child_builder_controls_distribution': _child_foldout_property('Show Distribution Builder Controls Child Section', 'Opens or closes the nested child foldout for scatter amount, spacing, relaxation, camera visibility, biome, fairness, anisotropy, and density controls.', False),
    'ui_child_builder_controls_fragments': _child_foldout_property('Show Fragment Builder Controls Child Section', 'Opens or closes the nested child foldout for growth branch counts and fragmentation readability controls.', False),
    'ui_child_builder_controls_precision': _child_foldout_property('Show Precision Builder Controls Child Section', 'Opens or closes the nested child foldout for precision, stability, interlock, debug attribute, and random seed parameters.', False),
    'ui_child_builders_migrated_generators': _child_foldout_property('Show Migrated Generators Child Section', 'Opens or closes the child foldout containing Max Primitives and Grease Mesh tools that are now managed inside Smart Geometry Suite.', True),
    'ui_child_builders_max_primitives': _child_foldout_property('Show Max Primitives Child Section', 'Opens or closes the nested child foldout for Max Primitives menu access, common primitive generators, asset installation, and update commands.', True),
    'ui_child_builders_grease_mesh': _child_foldout_property('Show Grease Mesh Child Section', 'Opens or closes the nested child foldout for Grease Pencil to mesh and Geometry Nodes conversion tools.', True),
    'ui_child_builders_scene_generators': _child_foldout_property('Show Scene Generators Child Section', 'Opens or closes the child foldout containing terrain, scatter, relaxation, flow, greeble, structure, growth, fragment, proxy, heatmap, and snapshot generation commands.', True),

    'ui_child_interop_paths': _child_foldout_property('Show Interop Paths Child Section', 'Opens or closes the child foldout for file-path inputs used by CSV and manifest workflows.', True),
    'ui_child_interop_exports': _child_foldout_property('Show Interop Exports Child Section', 'Opens or closes the child foldout for CSV import, USD sidecar manifest export, bundle manifest export, and design coverage JSON export commands.', True),
    'ui_child_interop_bridges': _child_foldout_property('Show Interop Bridges Child Section', 'Opens or closes the child foldout that lists feature-backed attribute, field, USD, and CSV exchange bridge tools.', True),

    'ui_child_diagnostics_active_mesh': _child_foldout_property('Show Active Mesh Diagnostics Child Section', 'Opens or closes the child foldout that reports the selected mesh name, topology counts, attribute count, and modifier count.', True),
    'ui_child_diagnostics_node_groups': _child_foldout_property('Show Generated Node Groups Child Section', 'Opens or closes the child foldout that counts and previews node groups generated by Smart Geometry Suite.', True),
    'ui_child_diagnostics_exports': _child_foldout_property('Show Diagnostics Export Child Section', 'Opens or closes the child foldout for exporting diagnostics and inventory JSON reports.', True),
    'ui_child_diagnostics_maintenance': _child_foldout_property('Show Diagnostics Maintenance Child Section', 'Opens or closes the advanced child foldout for destructive maintenance commands such as removing generated node groups.', False),

    'ui_child_visual_ui_display': _child_foldout_property('Show Visual UI Display Child Section', 'Opens or closes the child foldout for UI density, icon scale, dashboard tile scale, and reference strip display controls.', True),
    'ui_child_visual_ui_precision': _child_foldout_property('Show Visual UI Precision Child Section', 'Opens or closes the child foldout for precision preset and precision display parameter controls.', True),
    'ui_child_visual_ui_reference': _child_foldout_property('Show Visual Reference Tools Child Section', 'Opens or closes the child foldout for opening the visual reference and exporting the icon reference sheet.', True),

    'ui_child_coverage_categories': _child_foldout_property('Show Coverage Categories Child Section', 'Opens or closes the child foldout that summarizes Smart Geometry feature coverage by category.', True),
    'ui_child_coverage_domains': _child_foldout_property('Show Coverage Domains Child Section', 'Opens or closes the child foldout that summarizes Smart Geometry feature coverage by design domain.', True),

    'ui_child_gen_terrain_mesh': _child_foldout_property('Show Terrain Mesh Generator Child Section', 'Opens or closes the Blender-standard child foldout for the terrain mesh generator. It shows the seed, resolution, size, height, erosion, and hydraulic droplet settings used when creating a precision terrain mesh.', True),
    'ui_child_gen_terrain_flow': _child_foldout_property('Show Drainage Flow Generator Child Section', 'Opens or closes the Blender-standard child foldout for drainage flow curve generation from the active mesh terrain attributes.', True),
    'ui_child_gen_distribution_surface': _child_foldout_property('Show Surface Distribution Generator Child Section', 'Opens or closes the Blender-standard child foldout for creating surface distribution point-cloud meshes, including amount, spacing, blue-noise, normal offset, biome bias, candidate multiplier, and density settings.', True),
    'ui_child_gen_distribution_relax_proxy': _child_foldout_property('Show Distribution Relax and Proxy Child Section', 'Opens or closes the Blender-standard child foldout for relaxing generated distribution points and creating visible distribution proxy instances.', True),
    'ui_child_gen_distribution_csv': _child_foldout_property('Show CSV Point Cloud Generator Child Section', 'Opens or closes the Blender-standard child foldout for importing CSV x/y/z data as a generated point-cloud mesh.', False),
    'ui_child_gen_structure_surface': _child_foldout_property('Show Surface Detail Generator Child Section', 'Opens or closes the Blender-standard child foldout for generating surface detail blocks from the active mesh or fallback grid.', True),
    'ui_child_gen_structure_modular': _child_foldout_property('Show Modular Structure Generator Child Section', 'Opens or closes the Blender-standard child foldout for generating tiered modular structure meshes with Smart Geometry attributes.', True),
    'ui_child_gen_organic_growth': _child_foldout_property('Show Organic Growth Generator Child Section', 'Opens or closes the Blender-standard child foldout for generating organic growth curves such as ivy, roots, cables, veins, and trail guides.', True),
    'ui_child_gen_stroke_mesh': _child_foldout_property('Show Stroke Mesh Generator Child Section', 'Opens or closes the Blender-standard child foldout for Grease Pencil to mesh and Geometry Nodes generation commands.', True),
    'ui_child_gen_debris_module': _child_foldout_property('Show Debris Module Generator Child Section', 'Opens or closes the Blender-standard child foldout for the integrated debris module generator. The active module controls show only the settings for the selected debris generator.', True),
    'ui_child_gen_fragment_mesh': _child_foldout_property('Show Mesh Fragment Generator Child Section', 'Opens or closes the Blender-standard child foldout for clustered mesh fragment generation using the active mesh faces.', True),
    'ui_child_gen_primitives_max': _child_foldout_property('Show Max Primitive Generator Child Section', 'Opens or closes the Blender-standard child foldout for direct Max Primitive generator commands such as box, sphere, cylinder, and wall.', True),
    'ui_child_gen_attribute_precision': _child_foldout_property('Show Precision Attribute Generator Child Section', 'Opens or closes the Blender-standard child foldout for building and refining Smart Geometry precision attributes. It shows the preset, precision strength, quality pass, feature radius, material contrast, risk suppression, and debug attribute settings used by the attribute generators.', True),
    'ui_child_gen_attribute_selection': _child_foldout_property('Show Procedural Selection Attribute Child Section', 'Opens or closes the Blender-standard child foldout for writing a procedural selection attribute from the selection string and density threshold values.', True),
    'ui_child_gen_attribute_visual_outputs': _child_foldout_property('Show Attribute Visual Output Child Section', 'Opens or closes the Blender-standard child foldout for generating attribute heatmap materials and attribute snapshot meshes from the selected debug attribute.', True),

    'ui_child_settings_interface': _child_foldout_property('Show Interface Settings Child Section', 'Opens or closes the consolidated interface child foldout for UI density, icon scale, and advanced display controls.', True),
    'ui_child_settings_library': _child_foldout_property('Show Node Library Settings Child Section', 'Opens or closes the consolidated node-library child foldout for capsule prefix, asset marking, and library creation or rebuild commands.', True),
    'ui_child_settings_feature_apply': _child_foldout_property('Show Feature and Pack Apply Child Section', 'Opens or closes the consolidated feature and pack child foldout. Use it to choose an active feature or pack and apply it without the old standalone catalog section.', True),
    'ui_child_settings_precision_tools': _child_foldout_property('Show Precision Tools Child Section', 'Opens or closes the consolidated precision child foldout for attributes, presets, selection strings, heatmaps, snapshots, and precision-polish commands.', True),
    'ui_child_settings_diagnostics': _child_foldout_property('Show Diagnostics and Cleanup Child Section', 'Opens or closes the consolidated diagnostics child foldout for active mesh status, generated node group counts, diagnostic exports, inventory export, and cleanup.', False),
    'ui_child_settings_reports': _child_foldout_property('Show Manifest Report Child Section', 'Opens or closes the consolidated import/export child foldout for USD sidecar manifests, toolset bundle manifests, and design coverage JSON exports.', False),
    'ui_child_settings_debris_utility': _child_foldout_property('Show Debris Utility Settings Child Section', 'Opens or closes the consolidated debris utility child foldout for module refresh and attribution information that are not direct generation controls.', False),
    'ui_child_settings_visual_reference': _child_foldout_property('Show Visual Reference Settings Child Section', 'Opens or closes the consolidated visual reference child foldout for optional reference popups and icon reference sheet export.', False),
    'ui_child_settings_coverage': _child_foldout_property('Show Coverage Summary Child Section', 'Opens or closes the advanced coverage child foldout that summarizes feature coverage by category and design domain.', False),
    'ui_child_settings_storage': _child_foldout_property('Show Storage Path Child Section', 'Opens or closes the advanced storage child foldout that displays the extension user-data folder used for generated reports, manifests, and persistent settings.', False),
})

# Persistent always-on controls are N-panel WindowManager settings, not add-on
# Preferences properties, so they are saved by the suite's Blender config JSON store.
try:
    from . import always_on as _always_on

    SGS_Settings.__annotations__.update({
        'n_panel_state_save': BoolProperty(
            name='N-panel State Save',
            description="Controls how Smart Geometry N-panel settings are written to Smart_Geometry_Suite/Smart_Geometry_Suite.json in Blender's versioned config directory. Enable for immediate save on every setting change. Disable to defer writing until a scene switch, explicit file save/load boundary, Manager transition, or Blender exit.",
            default=True,
            update=_on_n_panel_state_save_update,
        ),
        'show_always_on_toggles': BoolProperty(
            name='Always-on Toggles Group Open',
            description='Shows or collapses the on-demand helper controls in the N-panel. These toggles no longer start recurring timers; they enable safe checks at UI, command, save, load, or setting-change boundaries.',
            default=True,
            update=_on_settings_update,
        ),
    })
    for _feature in _always_on.feature_definitions():
        _feature_name = str(getattr(_feature, 'label_en', '') or '').strip() or 'Smart Geometry Background Helper'
        _feature_description = str(getattr(_feature, 'description_en', '') or '').strip() or (
            'Controls this Smart Geometry background helper. Enable it only while the '
            'described event-driven assistance is required; disabling it releases every '
            'Suite-owned handler, timer, and cached runtime resource used by that helper.'
        )
        SGS_Settings.__annotations__[_feature.pref_property] = _DYNAMIC_BOOL_FIELD_FACTORY(
            name=_feature_name,
            description=_feature_description,
            default=bool(_feature.default),
            update=_on_always_on_update,
        )
except Exception:
    pass

# command-precision UI and quality controls. These are injected before class registration
# so Blender registers them as native PropertyGroup fields.
SGS_Settings.__annotations__.update({
    'ui_show_icon_dashboard': BoolProperty(
        name='Show Icon Dashboard',
        description='Shows the command dashboard. In Blender 5.1 crash-safe mode, it uses Blender standard UI icons instead of live custom preview icon IDs.',
        default=True,
        update=_on_settings_update,
    ),
    'ui_show_visual_guides': BoolProperty(
        name='Show Visual Guides',
        description='Shows generated visual reference panels that explain the Smart Geometry workflow using icon-only diagrams rather than embedded text.',
        default=True,
        update=_on_settings_update,
    ),
    'ui_borderless_icon_buttons': BoolProperty(
        name='Borderless Icon Buttons',
        description='Uses compact Blender operator button styling where possible. In Blender 5.1 crash-safe mode, buttons use standard icons and avoid live custom preview icon IDs.',
        default=True,
        update=_on_settings_update,
    ),
    'ui_icon_scale': FloatProperty(
        name='Icon Preview Scale',
        description='Controls optional visual reference preview scale only. Sidebar operator buttons always use Blender normal button height.',
        default=1.0,
        min=1.0,
        max=12.0,
        update=_on_settings_update,
    ),
    'ui_button_scale': FloatProperty(
        name='Command Button Height',
        description='Legacy compatibility value. Sidebar operator buttons always use Blender normal button height.',
        default=1.0,
        min=1.0,
        max=4.0,
        update=_on_settings_update,
    ),
    'terrain_v7_field_fusion': FloatProperty(
        name='Terrain Field Fusion',
        description='Strength of the post-terrain fusion pass. Higher values reinforce channel, watershed, contour, patch, material, and distribution handoff attributes after terrain generation or precision refinement.',
        default=0.72,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'scatter_v7_anisotropy_strength': FloatProperty(
        name='Scatter Anisotropy Strength',
        description='Controls how strongly distribution diagnostics account for normal, tangent, flow, and slope direction. Higher values improve directional placement quality for terrain and architectural surfaces.',
        default=0.58,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'scatter_v7_priority_bias': FloatProperty(
        name='Scatter Priority Bias',
        description='Controls how strongly scatter priority favors high-confidence, high-habitat, low-risk areas. Use this when distribution must prioritize production-safe placement over raw density.',
        default=0.62,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'fragment_v7_compactness': FloatProperty(
        name='Fragment Compactness',
        description='Controls the compactness scoring for generated fragments. Higher values emphasize compact, readable pieces for animation and simulation handoff diagnostics.',
        default=0.70,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
})

# operation-grade precision and visual-command controls.
SGS_Settings.__annotations__.update({
    'ui_v8_show_command_ribbon': BoolProperty(
        name='Show Command Ribbon',
        description='Shows the command ribbon for fast one-click access to main procedural workflows. Blender 5.1 crash-safe mode uses standard UI icons.',
        default=True,
        update=_on_settings_update,
    ),
    'ui_v8_max_icon_fill': FloatProperty(
        name='Icon Figure Fill',
        description='Documents the intended fill ratio of the bundled icon artwork. The PNG files are generated without frames and their figure occupies nearly the full transparent canvas for high readability.',
        default=0.94,
        min=0.70,
        max=0.98,
        update=_on_settings_update,
    ),
    'ui_v8_tile_scale': FloatProperty(
        name='Dashboard Tile Scale',
        description='Controls the dashboard tile height. Increase this on high-DPI monitors; Blender 5.1 crash-safe mode keeps live custom preview icons disabled.',
        default=8.0,
        min=2.0,
        max=14.0,
        update=_on_settings_update,
    ),
    'ui_v8_show_reference_strips': BoolProperty(
        name='Show Reference Strips',
        description='Shows static bundled reference diagrams. The diagrams contain no embedded two-language text so the UI language remains controlled by Blender localization.',
        default=True,
        update=_on_settings_update,
    ),
    'precision_v8_strength': FloatProperty(
        name='Precision Strength',
        description='Global strength for the operation-grade quality layer. Higher values make confidence, stability, distribution, material, hydrology, and diagnostic scores more decisive.',
        default=0.88,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'precision_v8_quality_passes': IntProperty(
        name='Quality Passes',
        description='Number of lightweight quality analysis passes applied when refining selected meshes. Higher values improve smoothed fields and risk suppression at the cost of additional computation.',
        default=3,
        min=1,
        max=12,
        update=_on_settings_update,
    ),
    'precision_v8_feature_radius': IntProperty(
        name='Feature Radius',
        description='Neighborhood radius used by stability, saliency, and field-coherence approximations. Larger values produce broader, smoother masks; smaller values preserve sharp local details.',
        default=2,
        min=1,
        max=8,
        update=_on_settings_update,
    ),
    'precision_v8_material_contrast': FloatProperty(
        name='Material Contrast',
        description='Contrast applied to the material-lane composer. Increase to separate wear, moss, dust, wetness, and exposed-surface masks more clearly for procedural materials.',
        default=0.74,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'precision_v8_risk_suppression': FloatProperty(
        name='Risk Suppression',
        description='Controls how strongly high-risk topology, boundary, overdraw, and low-confidence regions are down-ranked by distribution, material, and LOD scores.',
        default=0.66,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'scatter_v8_stability_bias': FloatProperty(
        name='Scatter Stability Bias',
        description='Prioritizes stable, visible, high-confidence regions when scoring distribution points. Increase when generated proxies or instancing should avoid risky surfaces.',
        default=0.72,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
    'fragment_v8_interlock_bias': FloatProperty(
        name='Fragment Interlock Bias',
        description='Controls the fragment readability and glue/seam metadata written after clustered fragmentation. Higher values favor visually coherent, easier-to-animate pieces.',
        default=0.62,
        min=0.0,
        max=2.0,
        update=_on_settings_update,
    ),
})


def get_settings(context=None) -> SGS_Settings | None:
    try:
        wm = (context or bpy.context).window_manager
        return getattr(wm, _SETTINGS_PROP, None)
    except Exception:
        return None


CLASSES = (SGS_Settings,)


def register_properties(
    ledger: dict[str, Any] | None = None, *, register_hooks: bool = True,
    restore_settings: bool = True,
) -> None:
    """Install the exact WindowManager pointer through the ownership ledger."""
    ledger = ledger or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        raise RuntimeError('Smart Geometry registration ledger is unavailable')
    owned = any(
        record.get('owner') is bpy.types.WindowManager
        and record.get('name') == _SETTINGS_PROP
        for record in ledger.get('pointers', ())
    )
    if not owned:
        ownership.register_pointer(
            ledger,
            bpy.types.WindowManager,
            _SETTINGS_PROP,
            PointerProperty(
                name='Smart Geometry Suite Settings',
                description='Stores Smart Geometry N-panel controls, section states, generator parameters, and always-on feature switches for the current Blender session.',
                type=SGS_Settings,
            ),
        )
    if restore_settings:
        global _STARTUP_RESTORE_PENDING
        previous = _STARTUP_RESTORE_PENDING
        _STARTUP_RESTORE_PENDING = True
        try:
            apply_saved_settings(bpy.context, reconcile_runtime=False)
        finally:
            _STARTUP_RESTORE_PENDING = previous
    if register_hooks:
        resume_runtime(ledger)


def unregister_properties(*, flush: bool = True) -> bool:
    """Compatibility hook; full pointer removal belongs to the owner transaction."""
    return suspend_runtime(flush=flush)
