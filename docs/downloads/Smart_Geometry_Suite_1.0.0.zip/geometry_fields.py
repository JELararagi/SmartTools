"""Point fields derived from mesh adjacency, surface normals, drainage and local relief."""
from collections import defaultdict, deque
from math import exp, pi, sqrt
from random import Random
from mathutils import Vector
from .catalog import PUBLIC
def clamp(x):return max(0,min(1,x))
def write(mesh,name,kind,values):
    attr=mesh.attributes.get(name)
    if attr and (attr.domain!='POINT' or attr.data_type!=kind):return
    if not attr:attr=mesh.attributes.new(name,kind,'POINT')
    member={'INT':'value','FLOAT':'value','FLOAT_VECTOR':'vector','FLOAT_COLOR':'color'}[kind]
    if kind in ('INT','FLOAT'):attr.data.foreach_set(member,values)
    else:attr.data.foreach_set(member,[v for co in values for v in co])

def point_fields(obj,settings,mode,overrides=None):
    mesh=obj.data;positions=[v.co.copy() for v in mesh.vertices];n=len(positions)
    if not n:return
    normals=[v.normal.copy() for v in mesh.vertices]
    neighbors=[[] for _ in positions];areas=[0.]*n;edge_usage=defaultdict(int)
    for edge in mesh.edges:
        a,b=edge.vertices;neighbors[a].append(b);neighbors[b].append(a)
    for face in mesh.polygons:
        ids=tuple(face.vertices);area=face.area/len(ids)
        for i,a in enumerate(ids):
            areas[a]+=area;b=ids[i-1];edge_usage[min(a,b),max(a,b)]+=1
    border={i for edge,frequency in edge_usage.items() if frequency==1 for i in edge}
    zmin=min(p.z for p in positions);zmax=max(p.z for p in positions);span=max(.00001,zmax-zmin)
    height=[(p.z-zmin)/span for p in positions];rng=Random(settings.random_seed);variation=[rng.random() for _ in positions]
    low=[min(neighbors[i],key=lambda j:height[j]) if neighbors[i] else i for i in range(n)];water=[1.]*n
    for i in sorted(range(n),key=height.__getitem__,reverse=True):
        if height[low[i]]<height[i]:water[low[i]]+=water[i]
    peak=max(water);edge_dist=[0 if i in border else -1 for i in range(n)];queue=deque(border)
    while queue:
        i=queue.popleft()
        for j in neighbors[i]:
            if edge_dist[j]<0:edge_dist[j]=edge_dist[i]+1;queue.append(j)
    maximum=max(1,max(edge_dist));values=[{} for _ in positions]
    for i,p in enumerate(positions):
        ns=neighbors[i];norm=normals[i];grad=(positions[low[i]]-p).normalized() if ns else Vector((0,0,0));d=max(0,edge_dist[i])/maximum
        laplace=(sum(positions[j].z-p.z for j in ns)/len(ns)) if ns else 0;slope=1-abs(norm.z);bend=clamp(abs(laplace)/span*6)
        wet=clamp(.55*water[i]/peak+.45*(1-height[i]));quality=clamp((1-.35*slope)*(1-.35*bend));density=clamp(.45*(1-slope)+.35*wet+.2*variation[i]);priority=quality*density
        valley=clamp(laplace*6/span);ridge=clamp(-laplace*6/span);tangent=Vector((norm.z,0,-norm.x)).normalized();meanedge=sum((positions[j]-p).length for j in ns)/len(ns) if ns else 0
        metrics={'height':height[i],'slope':slope,'convexity':ridge,'wetness':wet,'flow':water[i]/peak,'erosion':wet*slope,'sediment':wet*(1-slope),'biome':int(height[i]*3+wet*2),'channel':clamp((water[i]-1)/peak),'stream_order':int(water[i]).bit_length(),'terrace':round(height[i]*8)/8,'strata':int(height[i]*8),'hydraulic':wet*slope,'deposition':valley*wet,'bank':(1-wet)*slope,'watershed':low[i],'contour':height[i],'contour_line':1-abs(height[i]*12%1-.5)*2,'micro_relief':bend,'deposition_balance':valley-ridge,'id':i,'density':density,'mask':density>=settings.density_threshold,'variation':variation[i],'curvature':bend,'boundary':int(i in border),'edge_distance':d,'valence':len(ns),'vertex_area':areas[i],'mean_edge_length':meanedge,'aspect':norm.x,'cavity':valley,'occlusion':valley*.7,'thickness':meanedge,'ambient':1-valley*.7,'flow_dir':tuple(grad),'temperature':1-height[i],'stability':quality,'habitat_score':density*(1-slope),'region':int(height[i]*settings.precision_v7_material_regions),'lod':int((1-quality)*3),'cull':0,'quality':quality,'selection':int(mesh.vertices[i].select),'roughness':bend,'accessibility':1-valley,'visibility_score':1-slope*.4,'flow_direction':tuple(grad),'height_variance':sum((height[j]-height[i])**2 for j in ns)/max(1,len(ns)),'density_rank':density,'flow_rank':water[i]/peak,'erosion_rank':wet*slope,'ridge':ridge,'valley':valley,'exposure':slope*(1-wet),'accumulation':water[i],'drainage':water[i]/peak,'visibility':1-slope*.4,'cluster':low[i],'material_id':int(height[i]*4),'normal':tuple(norm),'bitangent':tuple(norm.cross(tangent)),'tangent':tuple(tangent),'scale':.5+.5*density,'source_face':-1,'principal_curvature':bend,'curvature_signed':laplace,'height_laplacian':laplace,'geodesic_boundary_distance':max(0,edge_dist[i])*meanedge,'boundary_proximity':1-d,'height_laplacian':laplace,'patch_id':low[i],'patch_boundary':int(i in border),'material_region':int(height[i]*settings.precision_v7_material_regions)}
        values[i]=(metrics,quality,priority,wet,bend,slope)
    fields=PUBLIC['fields'].get(mode,PUBLIC['fields']['create_greeble_blocks'])
    for key,kind,_ in fields:
        short=key[4:]
        if overrides and key in overrides:array=overrides[key]
        else:
            array=[]
            for i,(m,q,priority,wet,bend,slope) in enumerate(values):
                value=m.get(short)
                if value is None:
                    if kind=='FLOAT_COLOR':value=(m['height'],m['density'],m['wetness'],1)
                    elif kind=='FLOAT_VECTOR':value=m['normal']
                    elif any(v in short for v in ('risk','error','seam','wear','saliency','feature','detail','curvature','silhouette')):value=clamp(.55*bend+.45*slope)
                    elif any(v in short for v in ('water','hydro','erosion','transport','riverbank','moss','flow','terrain','drainage')):value=wet
                    elif any(v in short for v in ('material','biome','mask','habitat','distribution','priority','instance','density')):value=priority
                    elif 'size' in short or 'spacing' in short:value=m['mean_edge_length']
                    else:value=q
                    if kind=='INT':value=round(value*5)
                array.append(value)
        write(mesh,key,kind,[int(v) for v in array] if kind=='INT' else array)
    obj['sgs_standard_attributes']=','.join(a.name for a in mesh.attributes if a.name.startswith('sgs_'))
    obj['sgs_quality_mean']=sum(x[1] for x in values)/n
    obj['sgs_v7_attribute_count']=sum(a.name.startswith('sgs_') for a in mesh.attributes)
