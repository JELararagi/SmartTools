# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Pure cached Smart Tools Manager placement adapter.

The adapter performs exact ``sys.modules`` lookups only; it never imports,
enables, disables, reloads, scans, patches, or retries another add-on.  Each of the
eleven physical root Panels classifies its current logical editor and calls the
Manager 1.5.55+ public ``placement_allowed`` API with that exact key.  The local
classifier prevents cross-editor leakage while shared physical spaces keep one root.
"""

from __future__ import annotations

import sys
from typing import Any, Callable

_TOOL_KEY = "SMART_GEOMETRY"
_API_NAMES = (
    "smart_tools_manager",
    "bl_ext.user_default.smart_tools_manager",
    "bl_ext.blender_org.smart_tools_manager",
)
_API_MODULE = None
_API_PLACEMENT: Callable[..., Any] | None = None
_API_LOGICAL: Callable[..., Any] | None = None

LOGICAL_EDITORS = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "UV_EDITOR",
    "SHADER_EDITOR",
    "COMPOSITOR",
    "GEOMETRY_NODE_EDITOR",
    "TEXTURE_NODE_EDITOR",
    "VIDEO_SEQUENCER",
    "MOVIE_CLIP_EDITOR",
    "DOPE_SHEET",
    "GRAPH_EDITOR",
    "DRIVERS",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "ASSET_BROWSER",
    "FILE_BROWSER",
    "SPREADSHEET",
)

PHYSICAL_SPACES = (
    "VIEW_3D",
    "IMAGE_EDITOR",
    "NODE_EDITOR",
    "SEQUENCE_EDITOR",
    "CLIP_EDITOR",
    "DOPESHEET_EDITOR",
    "GRAPH_EDITOR",
    "NLA_EDITOR",
    "TEXT_EDITOR",
    "FILE_BROWSER",
    "SPREADSHEET",
)


def _text(value: Any) -> str:
    return str(value or "").strip().upper()


def _value_text(value: Any, *names: str) -> str:
    for name in names:
        try:
            result = _text(getattr(value, name, ""))
        except Exception:
            result = ""
        if result:
            return result
    return ""


def logical_editor_key_from_context(context=None) -> str | None:
    """Map 11 physical Blender spaces to the Manager's 17 logical editors."""
    if context is None:
        return None
    area = getattr(context, "area", None)
    space = getattr(context, "space_data", None)
    area_type = _value_text(area, "type")
    space_type = _value_text(space, "type")
    physical = space_type or area_type
    area_ui = _value_text(area, "ui_type")
    space_ui = _value_text(space, "ui_type")

    if physical == "VIEW_3D":
        return "VIEW_3D"
    if physical == "IMAGE_EDITOR":
        mode = _value_text(space, "mode", "ui_mode")
        return "UV_EDITOR" if {mode, area_ui, space_ui}.intersection({"UV", "UV_EDIT", "UVS", "UV_EDITOR"}) else "IMAGE_EDITOR"
    if physical == "NODE_EDITOR":
        tree = _value_text(space, "tree_type")
        tokens = {tree, area_ui, space_ui}
        if tokens.intersection({"SHADERNODETREE", "SHADER", "SHADER_NODE_TREE", "SHADER_EDITOR"}):
            return "SHADER_EDITOR"
        if tokens.intersection({"COMPOSITORNODETREE", "COMPOSITOR", "COMPOSITOR_NODE_TREE", "COMPOSITING"}):
            return "COMPOSITOR"
        if tokens.intersection({"GEOMETRYNODETREE", "GEOMETRY", "GEOMETRY_NODE_TREE", "GEOMETRY_NODES", "GEOMETRY_NODE_EDITOR"}):
            return "GEOMETRY_NODE_EDITOR"
        if tokens.intersection({"TEXTURENODETREE", "TEXTURE", "TEXTURE_NODE_TREE", "TEXTURE_NODE_EDITOR"}):
            return "TEXTURE_NODE_EDITOR"
        return None
    if physical == "SEQUENCE_EDITOR":
        return "VIDEO_SEQUENCER"
    if physical == "CLIP_EDITOR":
        return "MOVIE_CLIP_EDITOR"
    if physical == "DOPESHEET_EDITOR":
        mode = _value_text(space, "mode", "ui_mode")
        if {mode, area_ui, space_ui}.intersection({"TIMELINE", "DRIVER", "DRIVERS"}):
            return None
        return "DOPE_SHEET"
    if physical == "GRAPH_EDITOR":
        mode = _value_text(space, "mode", "ui_mode")
        return "DRIVERS" if {mode, area_ui, space_ui}.intersection({"DRIVER", "DRIVERS"}) else "GRAPH_EDITOR"
    if physical == "NLA_EDITOR":
        return "NLA_EDITOR"
    if physical == "TEXT_EDITOR":
        return "TEXT_EDITOR"
    if physical == "FILE_BROWSER":
        browse = _value_text(space, "browse_mode", "mode")
        params_browse = _value_text(getattr(space, "params", None), "browse_mode")
        return "ASSET_BROWSER" if {browse, params_browse, area_ui, space_ui}.intersection({"ASSETS", "ASSET_BROWSER"}) else "FILE_BROWSER"
    if physical == "SPREADSHEET":
        return "SPREADSHEET"
    return None


def _candidate_names() -> tuple[str, ...]:
    package = str(__package__ or "")
    names = list(_API_NAMES)
    if package.endswith(".smart_geometry_suite"):
        names.insert(0, package.rsplit(".", 1)[0] + ".smart_tools_manager")
    result: list[str] = []
    for name in names:
        if name and name not in result:
            result.append(name)
    return tuple(result)


def _resolve_cached_api() -> tuple[Callable[..., Any] | None, Callable[..., Any] | None]:
    global _API_MODULE, _API_PLACEMENT, _API_LOGICAL
    module = _API_MODULE
    if module is not None and sys.modules.get(getattr(module, "__name__", "")) is module:
        placement = getattr(module, "placement_allowed", None)
        logical = getattr(module, "logical_editor_key_from_context", None)
        if callable(placement):
            _API_PLACEMENT = placement
            _API_LOGICAL = logical if callable(logical) else None
            return _API_PLACEMENT, _API_LOGICAL

    _API_MODULE = None
    _API_PLACEMENT = None
    _API_LOGICAL = None
    for name in _candidate_names():
        module = sys.modules.get(name)
        if module is None:
            continue
        placement = getattr(module, "placement_allowed", None)
        if not callable(placement):
            continue
        _API_MODULE = module
        _API_PLACEMENT = placement
        logical = getattr(module, "logical_editor_key_from_context", None)
        _API_LOGICAL = logical if callable(logical) else None
        break
    return _API_PLACEMENT, _API_LOGICAL


def placement_allowed(context, expected_editor_key: str) -> bool:
    """Return one pure current-cell decision for a Suite-owned native root."""
    expected = _text(expected_editor_key)
    if expected not in LOGICAL_EDITORS:
        return False
    local = logical_editor_key_from_context(context)
    if local != expected:
        return False
    placement, manager_logical = _resolve_cached_api()
    if placement is None:
        return True
    if manager_logical is not None:
        try:
            manager_key = manager_logical(context)
        except Exception:
            manager_key = local
        if manager_key in LOGICAL_EDITORS and manager_key != expected:
            return False
    try:
        return bool(placement(_TOOL_KEY, context, editor_key=expected))
    except Exception:
        # Manager decision API is contractually fail-open on integration faults,
        # while the exact local editor match remains fail-closed.
        return True


def workspace_tool_allowed(context=None) -> bool:
    """Pure owner-retention query; never use this for Panel visibility."""
    module = _resolve_cached_api()[0]
    owner_api = getattr(_API_MODULE, "workspace_tool_allowed", None) if module else None
    if not callable(owner_api):
        return True
    try:
        return bool(owner_api(_TOOL_KEY, context))
    except Exception:
        return True


def register() -> None:
    _resolve_cached_api()


def unregister() -> None:
    global _API_MODULE, _API_PLACEMENT, _API_LOGICAL
    _API_MODULE = None
    _API_PLACEMENT = None
    _API_LOGICAL = None


def clear_runtime_caches() -> None:
    unregister()
