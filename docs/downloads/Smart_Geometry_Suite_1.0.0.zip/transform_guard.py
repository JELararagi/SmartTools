# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import hashlib
import json
import math
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

_SCENE_KEY_PREFIX = 'smart_geometry_suite_transform_guard_v2'
_SCHEMA = 'jelararagi.smart_geometry_suite.transform_guard.v2'
_TIMER_TAG = 'transform_guard.restore_timer'
_OWNER_SUITE_KEY = 'jelararagi_sgs_owner_suite'
_OWNER_REVISION_KEY = 'jelararagi_sgs_owner_revision'
_OWNER_GENERATION_KEY = 'jelararagi_sgs_owner_generation'
_EPS = 1.0e-6
_PROXY_TRANSFORM_SKIP_BUILDERS = {'v5_visible_distribution_proxy_instances'}


def _float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        if math.isfinite(result):
            return result
    except Exception:
        pass
    return float(default)


def _vector3(value: Any, default: tuple[float, float, float]) -> list[float]:
    try:
        return [_float(value[0], default[0]), _float(value[1], default[1]), _float(value[2], default[2])]
    except Exception:
        try:
            return [_float(value.x, default[0]), _float(value.y, default[1]), _float(value.z, default[2])]
        except Exception:
            return [float(default[0]), float(default[1]), float(default[2])]


def _vector4(value: Any, default: tuple[float, float, float, float]) -> list[float]:
    try:
        return [_float(value[0], default[0]), _float(value[1], default[1]), _float(value[2], default[2]), _float(value[3], default[3])]
    except Exception:
        try:
            return [_float(value.w, default[0]), _float(value.x, default[1]), _float(value.y, default[2]), _float(value.z, default[3])]
        except Exception:
            return [float(default[0]), float(default[1]), float(default[2]), float(default[3])]


def _near_list(values: list[float], expected: tuple[float, ...], eps: float = _EPS) -> bool:
    if len(values) != len(expected):
        return False
    return all(abs(float(a) - float(b)) <= eps for a, b in zip(values, expected))


def _rotation_values(obj) -> tuple[str, list[float]]:
    mode = str(getattr(obj, 'rotation_mode', 'XYZ') or 'XYZ')
    if mode == 'QUATERNION':
        return mode, _vector4(getattr(obj, 'rotation_quaternion', (1.0, 0.0, 0.0, 0.0)), (1.0, 0.0, 0.0, 0.0))
    if mode == 'AXIS_ANGLE':
        return mode, _vector4(getattr(obj, 'rotation_axis_angle', (0.0, 0.0, 0.0, 1.0)), (0.0, 0.0, 0.0, 1.0))
    return mode, _vector3(getattr(obj, 'rotation_euler', (0.0, 0.0, 0.0)), (0.0, 0.0, 0.0))


def _is_default_rotation(mode: str, values: list[float]) -> bool:
    if mode == 'QUATERNION':
        return _near_list(values, (1.0, 0.0, 0.0, 0.0))
    if mode == 'AXIS_ANGLE':
        return _near_list(values, (0.0, 0.0, 0.0, 1.0))
    return _near_list(values, (0.0, 0.0, 0.0))


def _transform_is_default(record: dict[str, Any]) -> bool:
    loc = list(record.get('location') or [])
    scale = list(record.get('scale') or [])
    mode = str(record.get('rotation_mode') or 'XYZ')
    rot = list(record.get('rotation') or [])
    return _near_list(loc, (0.0, 0.0, 0.0)) and _near_list(scale, (1.0, 1.0, 1.0)) and _is_default_rotation(mode, rot)


def _object_key(obj) -> str:
    try:
        return str(getattr(obj, 'name_full', None) or getattr(obj, 'name', ''))
    except Exception:
        return ''


def _is_nonpersistent_proxy_object(obj) -> bool:
    try:
        if obj is None:
            return False
        if bool(obj.get('ms_shape_proxy_internal', False)):
            return True
        if bool(obj.get('sgs_ephemeral_proxy', False)):
            return True
        if str(obj.get('sgs_builder', '') or '') in _PROXY_TRANSFORM_SKIP_BUILDERS:
            return True
        return False
    except Exception:
        return False


def _can_store_object(obj) -> bool:
    try:
        if obj is None:
            return False
        if getattr(obj, 'library', None) is not None:
            return False
        if getattr(obj, 'override_library', None) is not None:
            return False
        if _is_nonpersistent_proxy_object(obj):
            return False
        if not _object_key(obj):
            return False
        return True
    except Exception:
        return False


def _has_transform_animation_or_constraints(obj) -> bool:
    try:
        if getattr(obj, 'constraints', None) and len(obj.constraints) > 0:
            return True
    except Exception:
        pass
    try:
        anim = getattr(obj, 'animation_data', None)
        if anim is None:
            return False
        if getattr(anim, 'drivers', None):
            for driver in anim.drivers:
                path = str(getattr(driver, 'data_path', '') or '')
                if path.startswith(('location', 'rotation_', 'scale', 'matrix_')):
                    return True
        action = getattr(anim, 'action', None)
        if action is not None:
            for fc in getattr(action, 'fcurves', []) or []:
                path = str(getattr(fc, 'data_path', '') or '')
                if path.startswith(('location', 'rotation_', 'scale')):
                    return True
    except Exception:
        pass
    return False


def capture_object_transform(obj) -> dict[str, Any] | None:
    if not _can_store_object(obj):
        return None
    try:
        mode, rotation = _rotation_values(obj)
        return {
            'location': _vector3(getattr(obj, 'location', (0.0, 0.0, 0.0)), (0.0, 0.0, 0.0)),
            'rotation_mode': mode,
            'rotation': rotation,
            'scale': _vector3(getattr(obj, 'scale', (1.0, 1.0, 1.0)), (1.0, 1.0, 1.0)),
        }
    except Exception:
        return None


def restore_object_transform_if_reset(obj, saved: dict[str, Any] | None) -> bool:
    """Restore only when the current local transform is default but the saved one was not.

    This avoids overwriting intentional edits. It targets the failure mode reported for
    save/reopen where non-default object transforms appear as location 0, rotation 0,
    and scale 1 after file load.
    """
    if obj is None or not isinstance(saved, dict) or _has_transform_animation_or_constraints(obj):
        return False
    current = capture_object_transform(obj)
    if current is None:
        return False
    if _transform_is_default(saved) or not _transform_is_default(current):
        return False
    try:
        mode = str(saved.get('rotation_mode') or getattr(obj, 'rotation_mode', 'XYZ') or 'XYZ')
        try:
            obj.rotation_mode = mode
        except Exception:
            pass
        loc = list(saved.get('location') or [0.0, 0.0, 0.0])[:3]
        scale = list(saved.get('scale') or [1.0, 1.0, 1.0])[:3]
        rot = list(saved.get('rotation') or [])
        obj.location = (_float(loc[0]), _float(loc[1]), _float(loc[2]))
        obj.scale = (_float(scale[0], 1.0), _float(scale[1], 1.0), _float(scale[2], 1.0))
        if mode == 'QUATERNION' and len(rot) >= 4:
            obj.rotation_quaternion = (_float(rot[0], 1.0), _float(rot[1]), _float(rot[2]), _float(rot[3]))
        elif mode == 'AXIS_ANGLE' and len(rot) >= 4:
            obj.rotation_axis_angle = (_float(rot[0]), _float(rot[1]), _float(rot[2]), _float(rot[3], 1.0))
        elif len(rot) >= 3:
            obj.rotation_euler = (_float(rot[0]), _float(rot[1]), _float(rot[2]))
        return True
    except Exception:
        return False


def preserve_object_transform(obj, callback, *args, **kwargs):
    before = capture_object_transform(obj)
    result = callback(*args, **kwargs)
    if before is not None:
        restore_object_transform_if_reset(obj, before)
    return result



def _ownership_module():
    try:
        from . import ownership
        return ownership
    except Exception:
        return None


def _active_generation() -> str:
    ownership = _ownership_module()
    if ownership is None:
        return ''
    ledger = ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return ''
    return str(ledger.get('generation') or '')


def _scene_storage_key(generation: str | None = None) -> str:
    token = str(generation or _active_generation())
    if not token:
        return ''
    digest = hashlib.sha256(token.encode('utf-8')).hexdigest()[:16]
    return f'{_SCENE_KEY_PREFIX}_{digest}'


def _is_exact_owned_object(obj, generation: str | None = None) -> bool:
    ownership = _ownership_module()
    expected = str(generation or _active_generation())
    if ownership is None or obj is None or not expected:
        return False
    try:
        return bool(
            obj.get(_OWNER_SUITE_KEY) == ownership.SUITE_ID
            and obj.get(_OWNER_REVISION_KEY) == ownership.REVISION
            and obj.get(_OWNER_GENERATION_KEY) == expected
        )
    except Exception:
        return False


def _payload_is_exact(payload: Any, generation: str) -> bool:
    ownership = _ownership_module()
    return bool(
        ownership is not None
        and isinstance(payload, dict)
        and payload.get('schema') == _SCHEMA
        and payload.get('owner_suite') == ownership.SUITE_ID
        and payload.get('owner_revision') == ownership.REVISION
        and payload.get('owner_generation') == generation
        and isinstance(payload.get('objects'), dict)
    )


def cleanup_scene_transform_snapshots(context=None) -> int:
    """Prune only the exact current-generation snapshot payload.

    Legacy, malformed, foreign, and previous-generation scene properties are left
    untouched.  This function never guesses ownership from a key suffix or object
    name.
    """
    if bpy is None:
        return 0
    generation = _active_generation()
    key = _scene_storage_key(generation)
    if not generation or not key:
        return 0
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    if scene is None:
        return 0
    try:
        raw = scene.get(key, '')
    except Exception:
        return 0
    if not raw:
        return 0
    try:
        payload = json.loads(str(raw))
    except Exception:
        return 0
    if not _payload_is_exact(payload, generation):
        return 0
    objects = payload['objects']
    live: dict[str, Any] = {}
    try:
        for obj in list(getattr(bpy.data, 'objects', []) or []):
            if _is_exact_owned_object(obj, generation):
                live[_object_key(obj)] = obj
    except Exception:
        return 0
    filtered = {name: record for name, record in objects.items() if name in live}
    removed = len(objects) - len(filtered)
    if removed <= 0:
        return 0
    try:
        if filtered:
            payload['objects'] = filtered
            scene[key] = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        else:
            del scene[key]
    except Exception:
        return 0
    return removed


def save_scene_transform_snapshot(context=None) -> int:
    """Store transforms for exact current-generation Suite-created objects only."""
    if bpy is None:
        return 0
    ownership = _ownership_module()
    generation = _active_generation()
    key = _scene_storage_key(generation)
    if ownership is None or not generation or not key:
        return 0
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    if scene is None:
        return 0
    objects: dict[str, dict[str, Any]] = {}
    try:
        for obj in list(getattr(bpy.data, 'objects', []) or []):
            if not _is_exact_owned_object(obj, generation) or _is_nonpersistent_proxy_object(obj):
                continue
            record = capture_object_transform(obj)
            if record is not None:
                objects[_object_key(obj)] = record
    except Exception:
        return 0
    payload = {
        'schema': _SCHEMA,
        'owner_suite': ownership.SUITE_ID,
        'owner_revision': ownership.REVISION,
        'owner_generation': generation,
        'objects': objects,
    }
    try:
        scene[key] = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return 0
    return len(objects)


def _load_scene_payload(context=None) -> tuple[str, dict[str, Any]]:
    if bpy is None:
        return '', {}
    generation = _active_generation()
    key = _scene_storage_key(generation)
    if not generation or not key:
        return '', {}
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    if scene is None:
        return generation, {}
    try:
        raw = scene.get(key, '')
        payload = json.loads(str(raw)) if raw else {}
    except Exception:
        return generation, {}
    if not _payload_is_exact(payload, generation):
        return generation, {}
    return generation, dict(payload.get('objects') or {})


def restore_scene_transforms_if_reset(context=None) -> int:
    if bpy is None:
        return 0
    generation, saved = _load_scene_payload(context)
    if not generation or not saved:
        return 0
    restored = 0
    try:
        for obj in list(getattr(bpy.data, 'objects', []) or []):
            if not _is_exact_owned_object(obj, generation):
                continue
            record = saved.get(_object_key(obj))
            if isinstance(record, dict) and restore_object_transform_if_reset(obj, record):
                restored += 1
    except Exception:
        return restored
    return restored


def _restore_once():
    restore_scene_transforms_if_reset()
    return None


def cancel_scheduled_restore() -> bool:
    ownership = _ownership_module()
    if ownership is None:
        return True
    ledger = ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return True
    return bool(ownership.remove_tagged_dynamic_resources(ledger, _TIMER_TAG))


def schedule_restore_after_load(context=None) -> bool:
    """Restore now and schedule one bounded post-load pass; never poll at idle."""
    ownership = _ownership_module()
    if bpy is None or ownership is None:
        return False
    ledger = ownership.shared_ledger()
    if not ownership.runtime_active_for_generation() or not ownership.ledger_is_exact(ledger):
        return False
    restore_scene_transforms_if_reset(context)
    if not ownership.remove_tagged_dynamic_resources(ledger, _TIMER_TAG):
        return False
    try:
        ownership.register_timer(
            ledger, _restore_once, first_interval=0.1,
            persistent=False, tag=_TIMER_TAG,
        )
        return True
    except Exception:
        return False


def clear_runtime_caches() -> None:
    return None
