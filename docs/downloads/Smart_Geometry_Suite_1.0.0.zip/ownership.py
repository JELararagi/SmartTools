# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Exact, generation-scoped ownership for Smart Geometry Suite.

This module is intentionally small and has no registration side effects.  A single
ledger is published in ``bpy.app.driver_namespace`` only after a complete
registration transaction succeeds.  Reloaded Python modules never infer ownership
from names or suffixes and never replace live RNA.  The published ledger keeps the
exact Python identities required to stop an older generation safely at an explicit
full-unregister boundary.
"""

from __future__ import annotations

from collections.abc import MutableMapping
from functools import wraps
import inspect
import sys
import uuid
from typing import Any, Callable

import bpy

SUITE_ID = "smart_geometry_suite"
REVISION = "8.2.46"
LEDGER_SCHEMA = "jelararagi.smart_geometry_suite.runtime_ledger.v1"
LEDGER_KEY = "JELARARAGI_SMART_GEOMETRY_RUNTIME_LEDGER_V1"
GENERATION_TOKEN = f"{REVISION}:{uuid.uuid4().hex}"

_MISSING = object()

# Blender empties driver_namespace whenever a file is loaded, while this package
# stays registered.  The published ledger is kept here too and put back on access.
_PUBLISHED_LEDGER: dict[str, Any] | None = None


def package_name() -> str:
    return str(__package__ or __name__.rsplit(".", 1)[0])


def _namespace() -> MutableMapping[str, Any] | None:
    try:
        value = bpy.app.driver_namespace
    except Exception:
        return None
    if not isinstance(value, MutableMapping):
        return None
    if _PUBLISHED_LEDGER is not None and LEDGER_KEY not in value:
        value[LEDGER_KEY] = _PUBLISHED_LEDGER
    return value


def shared_ledger() -> dict[str, Any] | None:
    ns = _namespace()
    if ns is None:
        return None
    value = ns.get(LEDGER_KEY)
    if not isinstance(value, dict):
        return None
    if value.get("schema") != LEDGER_SCHEMA or value.get("suite_id") != SUITE_ID:
        return None
    return value


def new_ledger() -> dict[str, Any]:
    """Create an unpublished transaction ledger for this imported generation."""
    return {
        "schema": LEDGER_SCHEMA,
        "suite_id": SUITE_ID,
        "revision": REVISION,
        "generation": GENERATION_TOKEN,
        "package": package_name(),
        "status": "REGISTERING",
        "runtime_active": False,
        "shutting_down": False,
        "shutdown_epoch": 0,
        "classes": [],
        "pointers": [],
        "handlers": [],
        "timers": [],
        "msgbus": [],
        "menus": [],
        "translations": [],
        "dynamic_cleanups": [],
        "lazy_modules": [],
        "modals": {},
        "registration_failures": [],
        "cleanup_failures": [],
        "shutdown_callback": None,
        "runtime_api": {},
    }


def ledger_is_exact(ledger: Any, *, generation: str | None = None) -> bool:
    if not isinstance(ledger, dict):
        return False
    if ledger.get("schema") != LEDGER_SCHEMA or ledger.get("suite_id") != SUITE_ID:
        return False
    if generation is not None and ledger.get("generation") != generation:
        return False
    return True


def ledger_is_active(ledger: Any) -> bool:
    return bool(
        ledger_is_exact(ledger)
        and ledger.get("status") == "ACTIVE"
        and not bool(ledger.get("shutting_down"))
    )


def current_generation_is_active() -> bool:
    return ledger_is_active(shared_ledger()) and shared_ledger().get("generation") == GENERATION_TOKEN


def active_generation_token() -> str:
    ledger = shared_ledger()
    if ledger_is_active(ledger):
        return str(ledger.get("generation") or "")
    return ""


def registration_state() -> tuple[str, dict[str, Any] | None]:
    """Return NEW, CURRENT, ADOPT_OLD, BUSY, or FOREIGN without mutating Blender."""
    ns = _namespace()
    if ns is None:
        return "NEW", None
    raw = ns.get(LEDGER_KEY)
    if raw is None:
        return "NEW", None
    if not ledger_is_exact(raw):
        return "FOREIGN", None
    status = str(raw.get("status") or "")
    if status in {"REGISTERING", "STOPPING"}:
        return "BUSY", raw
    if status == "ACTIVE":
        if raw.get("generation") == GENERATION_TOKEN:
            return "CURRENT", raw
        return "ADOPT_OLD", raw
    if status == "SUSPENDED":
        if raw.get("generation") == GENERATION_TOKEN:
            return "CURRENT", raw
        return "ADOPT_OLD", raw
    if status == "STOPPED" and not _ledger_has_resources(raw):
        return "NEW", raw
    return "BUSY", raw


def publish_ledger(
    ledger: dict[str, Any], shutdown_callback: Callable[..., Any],
    runtime_api: dict[str, Callable[..., Any]] | None = None,
) -> None:
    """Atomically publish only a fully registered generation."""
    global _PUBLISHED_LEDGER
    if not ledger_is_exact(ledger, generation=GENERATION_TOKEN):
        raise RuntimeError("Smart Geometry registration ledger identity mismatch")
    ns = _namespace()
    if ns is None:
        raise RuntimeError("Blender driver_namespace is unavailable")
    existing = ns.get(LEDGER_KEY)
    if existing is not None and existing is not ledger:
        if ledger_is_exact(existing) and existing.get("status") == "STOPPED" and not _ledger_has_resources(existing):
            pass
        else:
            raise RuntimeError("A Smart Geometry generation is already active")
    ledger["shutdown_callback"] = shutdown_callback
    ledger["runtime_api"] = dict(runtime_api or {})
    ledger["status"] = "ACTIVE"
    ledger["runtime_active"] = True
    ledger["shutting_down"] = False
    ns[LEDGER_KEY] = ledger
    _PUBLISHED_LEDGER = ledger




def retain_failed_ledger(
    ledger: dict[str, Any], shutdown_callback: Callable[..., Any],
    runtime_api: dict[str, Callable[..., Any]] | None = None,
) -> bool:
    """Publish an inert exact ledger only when rollback itself could not finish.

    This is a recovery lease, not a live generation.  It prevents a later import
    from guessing ownership or registering duplicate RNA while preserving the exact
    resources that still require cleanup.
    """
    global _PUBLISHED_LEDGER
    if not ledger_is_exact(ledger, generation=GENERATION_TOKEN):
        return False
    ns = _namespace()
    if ns is None:
        return False
    existing = ns.get(LEDGER_KEY)
    if existing is not None and existing is not ledger:
        return False
    ledger["shutdown_callback"] = shutdown_callback
    ledger["runtime_api"] = dict(runtime_api or {})
    ledger["status"] = "RECOVERY_REQUIRED"
    ledger["runtime_active"] = False
    ledger["shutting_down"] = False
    ns[LEDGER_KEY] = ledger
    _PUBLISHED_LEDGER = ledger
    return True

def clear_published_ledger(ledger: dict[str, Any]) -> None:
    global _PUBLISHED_LEDGER
    if _PUBLISHED_LEDGER is ledger:
        _PUBLISHED_LEDGER = None
    ns = _namespace()
    if ns is None:
        return
    if ns.get(LEDGER_KEY) is ledger:
        ns.pop(LEDGER_KEY, None)


def _ledger_has_resources(ledger: dict[str, Any]) -> bool:
    return any(
        bool(ledger.get(key))
        for key in (
            "classes", "pointers", "handlers", "timers", "msgbus", "menus",
            "translations", "dynamic_cleanups", "lazy_modules", "modals",
        )
    )


_CLASS_OWNER_ATTRS = (
    "_jelararagi_sgs_suite_id",
    "_jelararagi_sgs_revision",
    "_jelararagi_sgs_generation",
)


def mark_class(cls: type, ledger: dict[str, Any]) -> None:
    """Stamp only this Python class identity immediately before acquisition."""
    setattr(cls, "_jelararagi_sgs_suite_id", SUITE_ID)
    setattr(cls, "_jelararagi_sgs_revision", str(ledger["revision"]))
    setattr(cls, "_jelararagi_sgs_generation", str(ledger["generation"]))


def _clear_class_mark(cls: Any, ledger: dict[str, Any]) -> None:
    """Remove this generation's Python-only mark after exact RNA release."""
    if not isinstance(cls, type):
        return
    if not class_identity_matches(cls, ledger):
        return
    for name in _CLASS_OWNER_ATTRS:
        try:
            delattr(cls, name)
        except Exception:
            pass


def class_identity_matches(cls: Any, ledger: dict[str, Any]) -> bool:
    """Match only ownership marks stored directly on this class identity."""
    if not isinstance(cls, type):
        return False
    try:
        direct = vars(cls)
    except Exception:
        return False
    return bool(
        direct.get("_jelararagi_sgs_suite_id") == SUITE_ID
        and direct.get("_jelararagi_sgs_revision") == ledger.get("revision")
        and direct.get("_jelararagi_sgs_generation") == ledger.get("generation")
    )


def _direct_class_attribute(cls: type, name: str) -> Any:
    """Read only attributes owned by ``cls``; inherited RNA is not evidence."""
    try:
        return vars(cls).get(str(name), _MISSING)
    except Exception:
        return _MISSING


def _bpy_types_published_identity(cls: type) -> Any:
    """Return the exact object currently published for ``cls.__name__``.

    The lookup is used only for identity comparison.  A same-name different
    object is a foreign collision, never evidence of Suite ownership.
    """
    try:
        name = str(getattr(cls, "__name__", "") or "")
        if not name:
            return _MISSING
        return getattr(bpy.types, name, _MISSING)
    except Exception:
        return _MISSING


def _exact_bpy_types_identity(cls: type) -> bool:
    """Return True only when ``bpy.types`` publishes this exact class object."""
    return _bpy_types_published_identity(cls) is cls


def _rna_resolver_exact_identity(cls: type) -> bool:
    """Resolve only an RNA identifier back to this exact Python class object.

    ``bl_rna_get_subclass_py`` is used as an identity oracle, never as an
    ownership guess.  Candidate identifiers come from this class's own dictionary
    or its Python class name.  Inherited ``bl_rna`` data is deliberately excluded.
    """
    identifiers: list[str] = []
    direct_rna = _direct_class_attribute(cls, "bl_rna")
    if direct_rna is not _MISSING and direct_rna is not None:
        identifier = str(getattr(direct_rna, "identifier", "") or "")
        if identifier:
            identifiers.append(identifier)
    class_name = str(getattr(cls, "__name__", "") or "")
    if class_name and class_name not in identifiers:
        identifiers.append(class_name)
    direct_bl_idname = _direct_class_attribute(cls, "bl_idname")
    if isinstance(direct_bl_idname, str) and direct_bl_idname and direct_bl_idname not in identifiers:
        identifiers.append(direct_bl_idname)
    if not identifiers:
        return False

    for base in getattr(cls, "__mro__", ())[1:]:
        resolver = getattr(base, "bl_rna_get_subclass_py", None)
        if not callable(resolver):
            continue
        for identifier in identifiers:
            try:
                resolved = resolver(identifier, None)
            except TypeError:
                try:
                    resolved = resolver(identifier)
                except Exception:
                    continue
            except Exception:
                continue
            if resolved is cls:
                return True
    return False


def class_registration_probe(cls: type) -> dict[str, Any]:
    """Return a mutation-free, exact-identity registration probe.

    Both ``is_registered`` and ``bl_rna`` are read from ``vars(cls)`` only.
    Blender 5.1.x may expose truthy registration data on registered base classes;
    inherited values are diagnostic information only and cannot authorize
    adoption, unregistration, or rollback.
    """
    published = _bpy_types_published_identity(cls)
    direct_flag = _direct_class_attribute(cls, "is_registered")
    direct_rna = _direct_class_attribute(cls, "bl_rna")

    # Registration evidence must resolve to this exact identity.  A bare truthy
    # ``is_registered`` value is intentionally diagnostic only: it may be inherited
    # from a registered RNA base or remain stale after an interrupted teardown.
    # An exact publication in ``bpy.types`` is authoritative.  Otherwise, a direct
    # ``is_registered=False`` is an authoritative unregister signal and suppresses
    # a stale direct RNA resolver result.
    published_exact = published is cls
    resolver_exact = False
    if published_exact or direct_flag is not False:
        resolver_exact = _rna_resolver_exact_identity(cls)
    exact_registered = bool(published_exact or resolver_exact)

    inherited_flag = _MISSING
    inherited_rna = _MISSING
    if direct_flag is _MISSING:
        try:
            inherited_flag = getattr(cls, "is_registered")
        except Exception:
            inherited_flag = _MISSING
    if direct_rna is _MISSING:
        try:
            inherited_rna = getattr(cls, "bl_rna")
        except Exception:
            inherited_rna = _MISSING

    return {
        "class": cls,
        "exact_registered": bool(exact_registered),
        "published_identity": published,
        "foreign_same_name": bool(published is not _MISSING and published is not cls),
        "direct_is_registered": direct_flag,
        "direct_bl_rna": direct_rna,
        "inherited_is_registered_present": inherited_flag is not _MISSING,
        "inherited_is_registered_truthy": bool(inherited_flag) if inherited_flag is not _MISSING else False,
        "inherited_bl_rna_present": inherited_rna is not _MISSING and inherited_rna is not None,
    }


def class_registered_exact(cls: type) -> bool:
    """Return whether this exact Python class identity is registered in Blender."""
    return bool(class_registration_probe(cls)["exact_registered"])


def _class_receipt(ledger: dict[str, Any], cls: type) -> dict[str, Any] | None:
    for record in tuple(ledger.get("classes", ())):
        if record.get("class") is cls:
            return record
    return None


_OPERATOR_METHOD_SIGNATURES: dict[str, tuple[str, ...]] = {
    "execute": ("self", "context"),
    "invoke": ("self", "context", "event"),
    "modal": ("self", "context", "event"),
    "cancel": ("self", "context"),
}


def _is_operator_class(cls: type) -> bool:
    try:
        return isinstance(cls, type) and issubclass(cls, bpy.types.Operator)
    except Exception:
        return False


def _operator_method_descriptor(cls: type, method_name: str) -> tuple[Any, Any]:
    """Resolve a Suite-defined method without inspecting Blender's RNA base."""
    operator_base = getattr(bpy.types, "Operator", None)
    for base in getattr(cls, "__mro__", ()):
        if base is operator_base or base is object:
            break
        try:
            direct = vars(base).get(method_name, _MISSING)
        except Exception:
            direct = _MISSING
        if direct is not _MISSING:
            return direct, base
    return _MISSING, None


def operator_method_signature_probe(cls: type) -> dict[str, Any]:
    """Inspect concrete Operator methods exactly as Blender RNA will see them.

    ``inspect.signature(..., follow_wrapped=False)`` is intentional: Blender 5.1
    validates the registered function's code object, not a decorator's
    ``__wrapped__`` metadata.  The four RNA callbacks must be plain synchronous
    instance functions with the exact positional names/counts, no defaults, no
    keyword-only parameters, and no variadic arguments.
    """
    result: dict[str, Any] = {
        "class": cls,
        "class_name": str(getattr(cls, "__name__", "") or ""),
        "is_operator": _is_operator_class(cls),
        "methods": {},
        "issues": [],
        "valid": True,
    }
    if not result["is_operator"]:
        return result

    for method_name, expected_names in _OPERATOR_METHOD_SIGNATURES.items():
        descriptor, owner = _operator_method_descriptor(cls, method_name)
        if descriptor is _MISSING:
            continue
        descriptor_kind = "function"
        function = descriptor
        if isinstance(descriptor, classmethod):
            descriptor_kind = "classmethod"
            function = descriptor.__func__
        elif isinstance(descriptor, staticmethod):
            descriptor_kind = "staticmethod"
            function = descriptor.__func__

        method_record: dict[str, Any] = {
            "owner": str(getattr(owner, "__name__", "") or ""),
            "descriptor_kind": descriptor_kind,
            "expected_parameters": list(expected_names),
            "actual_parameters": [],
            "code_argcount": None,
            "code_posonlyargcount": None,
            "code_kwonlyargcount": None,
            "has_varargs": None,
            "has_varkw": None,
            "defaults_count": None,
            "kwdefaults_count": None,
            "valid": False,
        }
        issues: list[str] = []
        if descriptor_kind != "function":
            issues.append(f"{method_name} must be a plain instance function")
        if not inspect.isfunction(function):
            issues.append(f"{method_name} is not a Python function")
        elif inspect.iscoroutinefunction(function):
            issues.append(f"{method_name} must not be async")
        else:
            try:
                signature = inspect.signature(function, follow_wrapped=False)
                parameters = tuple(signature.parameters.values())
            except Exception as exc:
                parameters = ()
                issues.append(f"{method_name} signature inspection failed: {type(exc).__name__}")

            actual_names = tuple(parameter.name for parameter in parameters)
            method_record["actual_parameters"] = list(actual_names)
            if actual_names != expected_names:
                issues.append(
                    f"{method_name} parameters must be {expected_names!r}, found {actual_names!r}"
                )
            for parameter in parameters:
                if parameter.kind is not inspect.Parameter.POSITIONAL_OR_KEYWORD:
                    issues.append(f"{method_name} contains non-standard parameter kind")
                    break
                if parameter.default is not inspect.Parameter.empty:
                    issues.append(f"{method_name} contains a default parameter")
                    break

            code = getattr(function, "__code__", None)
            if code is None:
                issues.append(f"{method_name} has no Python code object")
            else:
                has_varargs = bool(code.co_flags & inspect.CO_VARARGS)
                has_varkw = bool(code.co_flags & inspect.CO_VARKEYWORDS)
                defaults_count = len(getattr(function, "__defaults__", ()) or ())
                kwdefaults_count = len(getattr(function, "__kwdefaults__", {}) or {})
                method_record.update({
                    "code_argcount": int(code.co_argcount),
                    "code_posonlyargcount": int(getattr(code, "co_posonlyargcount", 0)),
                    "code_kwonlyargcount": int(code.co_kwonlyargcount),
                    "has_varargs": has_varargs,
                    "has_varkw": has_varkw,
                    "defaults_count": defaults_count,
                    "kwdefaults_count": kwdefaults_count,
                })
                if code.co_argcount != len(expected_names):
                    issues.append(
                        f"{method_name} code argcount must be {len(expected_names)}, found {code.co_argcount}"
                    )
                if getattr(code, "co_posonlyargcount", 0) != 0:
                    issues.append(f"{method_name} contains positional-only parameters")
                if code.co_kwonlyargcount != 0:
                    issues.append(f"{method_name} contains keyword-only parameters")
                if has_varargs:
                    issues.append(f"{method_name} contains *args")
                if has_varkw:
                    issues.append(f"{method_name} contains **kwargs")
                if defaults_count:
                    issues.append(f"{method_name} code object has positional defaults")
                if kwdefaults_count:
                    issues.append(f"{method_name} code object has keyword defaults")

        method_record["valid"] = not issues
        method_record["issues"] = issues
        result["methods"][method_name] = method_record
        result["issues"].extend(issues)

    result["valid"] = not result["issues"]
    return result


def validate_operator_method_signatures(cls: type) -> dict[str, Any]:
    """Fail before ``bpy.utils.register_class`` on an invalid RNA callback."""
    probe = operator_method_signature_probe(cls)
    if not probe["valid"]:
        details = "; ".join(str(item) for item in probe["issues"])
        raise ValueError(
            f"Invalid Blender Operator method signature: {probe['class_name']}: {details}"
        )
    return probe


def register_class(ledger: dict[str, Any], cls: type) -> None:
    """Acquire one class through the Suite's single registration path.

    The same exact identity is idempotent only when this transaction already holds
    its receipt and the exact Blender registration still exists.  Older
    generations, same-name foreign objects, and out-of-transaction registrations
    remain fail-closed.
    """
    if not ledger_is_exact(ledger, generation=GENERATION_TOKEN):
        raise RuntimeError("Smart Geometry class transaction generation mismatch")

    validate_operator_method_signatures(cls)

    receipt = _class_receipt(ledger, cls)
    if receipt is not None:
        if (
            receipt.get("registered_here") is True
            and receipt.get("generation") == ledger.get("generation")
            and receipt.get("revision") == ledger.get("revision")
            and class_identity_matches(cls, ledger)
            and class_registered_exact(cls)
        ):
            return
        raise RuntimeError(f"Recorded RNA class lease is inconsistent: {cls.__name__}")

    before = class_registration_probe(cls)
    if before["foreign_same_name"]:
        raise RuntimeError(f"Foreign RNA class identity already uses this name: {cls.__name__}")
    if before["exact_registered"]:
        raise RuntimeError(f"RNA class was already registered outside this transaction: {cls.__name__}")

    mark_class(cls, ledger)
    try:
        bpy.utils.register_class(cls)
    except Exception as exc:
        # Blender can acquire the exact class and then raise.  Record only that
        # identity so reverse rollback removes only this transaction's resource.
        after_error = class_registration_probe(cls)
        if after_error["exact_registered"] and not after_error["foreign_same_name"]:
            ledger["classes"].append({
                "class": cls,
                "generation": ledger["generation"],
                "revision": ledger["revision"],
                "registered_here": True,
                "acquired_by": "bpy.utils.register_class",
                "partial_registration": True,
            })
        else:
            _clear_class_mark(cls, ledger)
        ledger["registration_failures"].append({
            "kind": "class",
            "name": cls.__name__,
            "error": type(exc).__name__,
        })
        raise

    after = class_registration_probe(cls)
    if after["foreign_same_name"] or not after["exact_registered"]:
        _clear_class_mark(cls, ledger)
        raise RuntimeError(f"RNA class registration identity verification failed: {cls.__name__}")
    ledger["classes"].append({
        "class": cls,
        "generation": ledger["generation"],
        "revision": ledger["revision"],
        "registered_here": True,
        "acquired_by": "bpy.utils.register_class",
        "partial_registration": False,
    })


def unregister_class_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    cls = record.get("class")
    if not (
        record.get("registered_here") is True
        and record.get("generation") == ledger.get("generation")
        and record.get("revision") == ledger.get("revision")
        and class_identity_matches(cls, ledger)
    ):
        return False
    probe = class_registration_probe(cls)
    if probe["foreign_same_name"]:
        return False
    if not probe["exact_registered"]:
        _clear_class_mark(cls, ledger)
        return True
    try:
        bpy.utils.unregister_class(cls)
        removed = not class_registered_exact(cls)
        if removed:
            _clear_class_mark(cls, ledger)
        return removed
    except Exception as exc:
        # A remover may complete and then raise; exact state decides whether the
        # lease can be released without touching any replacement identity.
        if not class_registered_exact(cls):
            _clear_class_mark(cls, ledger)
            return True
        ledger["cleanup_failures"].append({
            "kind": "class",
            "name": getattr(cls, "__name__", ""),
            "error": type(exc).__name__,
        })
        return False

def register_pointer(
    ledger: dict[str, Any], owner_type: type, name: str, property_value: Any,
) -> None:
    """Install one PointerProperty only when no pre-existing RNA/Python slot exists.

    The record is provisional until Blender confirms the installed descriptor.  If
    ``setattr`` installs a transformed RNA descriptor and then raises, the exact
    previously-absent slot is receipted so transaction rollback can remove only
    that descriptor.
    """
    if not ledger_is_exact(ledger, generation=GENERATION_TOKEN):
        raise RuntimeError("Smart Geometry pointer transaction generation mismatch")
    name = str(name)
    owner_dict = vars(owner_type)
    existing = owner_dict.get(name, _MISSING)
    if existing is not _MISSING or hasattr(owner_type, name):
        raise RuntimeError(f"PointerProperty already exists and is not owned by this generation: {name}")
    record = {
        "owner": owner_type,
        "name": name,
        "installed": _MISSING,
        "generation": ledger["generation"],
        "provisional": True,
    }
    try:
        setattr(owner_type, name, property_value)
        installed = vars(owner_type).get(name, _MISSING)
        if installed is _MISSING:
            try:
                installed = getattr(owner_type, name)
            except Exception:
                installed = _MISSING
        if installed is _MISSING:
            raise RuntimeError(f"PointerProperty installation verification failed: {name}")
        record["installed"] = installed
        record["provisional"] = False
        ledger["pointers"].append(record)
    except Exception:
        try:
            current = vars(owner_type).get(name, _MISSING)
        except Exception:
            current = _MISSING
        if current is not _MISSING:
            record["installed"] = current
            record["partial_registration"] = True
            ledger["pointers"].append(record)
        raise


def remove_pointer_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    if record.get("generation") != ledger.get("generation"):
        return False
    owner = record.get("owner")
    name = str(record.get("name") or "")
    installed = record.get("installed", _MISSING)
    try:
        current = vars(owner).get(name, _MISSING)
    except Exception:
        return False
    if current is not installed:
        # Do not touch a descriptor replaced by Blender, the user, or another add-on.
        return current is _MISSING
    try:
        delattr(owner, name)
    except Exception as exc:
        ledger["cleanup_failures"].append({"kind": "pointer", "name": name, "error": type(exc).__name__})
        return False
    try:
        return name not in vars(owner)
    except Exception:
        return True


def _guarded_callback(ledger: dict[str, Any], callback: Callable[..., Any], *, default: Any = None):
    generation = str(ledger["generation"])

    @wraps(callback)
    def guarded(*args, **kwargs):
        active = shared_ledger()
        if active is not ledger or active.get("generation") != generation:
            return default
        if (
            active.get("status") != "ACTIVE"
            or not bool(active.get("runtime_active"))
            or bool(active.get("shutting_down"))
        ):
            return default
        try:
            return callback(*args, **kwargs)
        except Exception:
            # Handler, msgbus, and timer boundaries must not leak traceback noise.
            return default

    guarded._jelararagi_sgs_suite_id = SUITE_ID
    guarded._jelararagi_sgs_revision = ledger["revision"]
    guarded._jelararagi_sgs_generation = generation
    guarded._jelararagi_sgs_original = callback
    return guarded


def register_handler(
    ledger: dict[str, Any], collection: Any, callback: Callable[..., Any], *,
    persistent: bool = True, tag: str = "",
) -> Callable[..., Any]:
    wrapped = _guarded_callback(ledger, callback, default=None)
    if persistent:
        try:
            wrapped = bpy.app.handlers.persistent(wrapped)
        except Exception:
            pass
    record = {"collection": collection, "callback": wrapped, "tag": str(tag)}
    try:
        collection.append(wrapped)
    except Exception:
        # A list-like Blender callback collection can acquire then raise.  The
        # wrapper is generation-unique, so removing this exact identity is safe.
        try:
            for item in tuple(collection):
                if item is wrapped:
                    ledger["handlers"].append(record)
                    break
        except Exception:
            pass
        raise
    ledger["handlers"].append(record)
    return wrapped


def remove_handler_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    collection = record.get("collection")
    callback = record.get("callback")
    try:
        for item in tuple(collection):
            if item is callback:
                collection.remove(item)
                return True
        return True
    except Exception as exc:
        ledger["cleanup_failures"].append({"kind": "handler", "name": getattr(callback, "__name__", ""), "error": type(exc).__name__})
        return False


def register_msgbus(
    ledger: dict[str, Any], *, key: Any, notify: Callable[..., Any],
    args: tuple[Any, ...] = (), options: set[str] | None = None, tag: str = "",
) -> object:
    owner = object()
    wrapped = _guarded_callback(ledger, notify, default=None)
    try:
        bpy.msgbus.subscribe_rna(
            key=key,
            owner=owner,
            args=tuple(args),
            notify=wrapped,
            options=set(options or ()),
        )
    except Exception:
        # subscribe_rna may acquire the owner before raising; clearing this fresh
        # unique owner cannot affect foreign subscriptions.
        try:
            bpy.msgbus.clear_by_owner(owner)
        except Exception:
            pass
        raise
    ledger["msgbus"].append({"owner": owner, "notify": wrapped, "tag": str(tag)})
    return owner


def remove_msgbus_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    owner = record.get("owner")
    try:
        bpy.msgbus.clear_by_owner(owner)
        return True
    except Exception as exc:
        ledger["cleanup_failures"].append({"kind": "msgbus", "name": "owner", "error": type(exc).__name__})
        return False


def register_menu(
    ledger: dict[str, Any], menu_type: Any, callback: Callable[..., Any], *, tag: str = "",
) -> Callable[..., Any]:
    wrapped = _guarded_callback(ledger, callback, default=None)
    record = {"menu": menu_type, "callback": wrapped, "tag": str(tag)}
    try:
        menu_type.append(wrapped)
    except Exception:
        # ``remove`` receives the exact unique wrapper; it cannot remove a foreign
        # callback even when Blender appended before reporting an exception.
        try:
            menu_type.remove(wrapped)
        except Exception:
            pass
        raise
    ledger["menus"].append(record)
    return wrapped


def remove_menu_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    menu_type = record.get("menu")
    callback = record.get("callback")
    try:
        menu_type.remove(callback)
        return True
    except Exception:
        # Blender raises when the exact callback is already absent; absence is clean.
        return True


def register_timer(
    ledger: dict[str, Any], callback: Callable[..., Any], *,
    first_interval: float = 0.0, persistent: bool = False, tag: str = "",
) -> Callable[..., Any]:
    """Register one exact timer and retire its ledger lease when it finishes."""
    generation = str(ledger.get("generation") or "")
    record: dict[str, Any] = {"callback": None, "tag": str(tag)}

    @wraps(callback)
    def wrapped(*args, **kwargs):
        active = shared_ledger()
        if (
            active is not ledger
            or active.get("generation") != generation
            or active.get("status") != "ACTIVE"
            or not bool(active.get("runtime_active"))
            or bool(active.get("shutting_down"))
        ):
            result = None
        else:
            try:
                result = callback(*args, **kwargs)
            except Exception:
                result = None
        if result is None:
            try:
                if record in ledger.get("timers", []):
                    ledger["timers"].remove(record)
            except Exception:
                pass
        return result

    wrapped._jelararagi_sgs_suite_id = SUITE_ID
    wrapped._jelararagi_sgs_revision = ledger.get("revision")
    wrapped._jelararagi_sgs_generation = generation
    wrapped._jelararagi_sgs_original = callback
    record["callback"] = wrapped
    ledger["timers"].append(record)
    try:
        try:
            bpy.app.timers.register(wrapped, first_interval=float(first_interval), persistent=bool(persistent))
        except TypeError:
            bpy.app.timers.register(wrapped, first_interval=float(first_interval))
    except Exception:
        # Timer registration may acquire the callback and then raise.  Retain the
        # exact receipt when Blender reports it registered so transaction rollback
        # can unregister only this wrapper; otherwise discard the provisional row.
        acquired = False
        try:
            is_registered = getattr(bpy.app.timers, "is_registered", None)
            acquired = bool(callable(is_registered) and is_registered(wrapped))
        except Exception:
            acquired = False
        if not acquired and record in ledger["timers"]:
            ledger["timers"].remove(record)
        raise
    return wrapped


def remove_timer_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    callback = record.get("callback")
    timers = getattr(bpy.app, "timers", None)
    is_registered = getattr(timers, "is_registered", None)
    try:
        if callable(is_registered) and not bool(is_registered(callback)):
            return True
        timers.unregister(callback)
        if callable(is_registered):
            return not bool(is_registered(callback))
        return True
    except Exception as exc:
        if callable(is_registered):
            try:
                if not bool(is_registered(callback)):
                    return True
            except Exception:
                pass
        ledger["cleanup_failures"].append({
            "kind": "timer", "name": getattr(callback, "__name__", ""),
            "error": type(exc).__name__,
        })
        return False


def register_translation(ledger: dict[str, Any], key: str, dictionary: dict[str, Any]) -> None:
    """Register translations under a generation-unique exact cleanup key."""
    if not ledger_is_exact(ledger, generation=GENERATION_TOKEN):
        raise RuntimeError("Smart Geometry translation transaction generation mismatch")
    source_key = str(key)
    registered_key = f"{source_key}::{SUITE_ID}::{ledger['generation']}"
    # A1-97: a same-generation dictionary left behind by an interrupted disable
    # would make register() fail with "translations message cache already
    # contains some data"; the key belongs to this suite only, so drop it first.
    try:
        bpy.app.translations.unregister(registered_key)
    except Exception:
        pass
    try:
        bpy.app.translations.register(registered_key, dictionary)
    except Exception:
        # The key is unique to this generation; cleaning it cannot affect a foreign
        # translation dictionary even if registration completed before raising.
        try:
            bpy.app.translations.unregister(registered_key)
        except Exception:
            pass
        raise
    ledger["translations"].append({
        "key": source_key,
        "registered_key": registered_key,
        "generation": ledger["generation"],
    })


def remove_translation_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    if record.get("generation") != ledger.get("generation"):
        return False
    key = str(record.get("registered_key") or "")
    if not key:
        return False
    try:
        bpy.app.translations.unregister(key)
        return True
    except Exception:
        # Blender raises when a key is already absent; absence is clean.  The key
        # is generation-unique, so no foreign dictionary can occupy it normally.
        return True


def add_dynamic_cleanup(
    ledger: dict[str, Any], cleanup: Callable[[], Any], name: str, *, tag: str = "",
) -> None:
    ledger["dynamic_cleanups"].append({
        "cleanup": cleanup, "name": str(name), "tag": str(tag),
    })


def remove_dynamic_cleanup_record(ledger: dict[str, Any], record: dict[str, Any]) -> bool:
    cleanup = record.get("cleanup")
    if not callable(cleanup):
        return True
    try:
        result = cleanup()
        return result is not False
    except Exception as exc:
        ledger["cleanup_failures"].append({"kind": "dynamic_cleanup", "name": record.get("name", ""), "error": type(exc).__name__})
        return False


def record_lazy_module(ledger: dict[str, Any], module: Any) -> None:
    name = str(getattr(module, "__name__", "") or "")
    package = str(ledger.get("package") or "")
    if not name or not (name == package or name.startswith(package + ".")):
        return
    if any(item.get("module") is module for item in ledger["lazy_modules"]):
        return
    ledger["lazy_modules"].append({"name": name, "module": module})


def release_lazy_modules(ledger: dict[str, Any], *, include_names: set[str] | None = None) -> bool:
    ok = True
    retained: list[dict[str, Any]] = []
    for record in reversed(tuple(ledger.get("lazy_modules", ()))):
        name = str(record.get("name") or "")
        module = record.get("module")
        if include_names is not None and name not in include_names:
            retained.append(record)
            continue
        released = True
        try:
            clear = getattr(module, "clear_runtime_caches", None)
            if callable(clear) and clear() is False:
                released = False
        except Exception as exc:
            ledger["cleanup_failures"].append({
                "kind": "lazy_module", "name": name, "error": type(exc).__name__,
            })
            released = False
        if released and sys.modules.get(name) is module:
            sys.modules.pop(name, None)
        elif released and sys.modules.get(name) is not module:
            # A different module generation now owns the import slot.  Do not remove it.
            pass
        else:
            retained.append(record)
            ok = False
    ledger["lazy_modules"][:] = list(reversed(retained))
    return ok


def runtime_active_for_generation(generation: str | None = None) -> bool:
    ledger = shared_ledger()
    return bool(
        ledger_is_exact(ledger)
        and ledger.get("status") == "ACTIVE"
        and bool(ledger.get("runtime_active"))
        and not bool(ledger.get("shutting_down"))
        and (generation is None or ledger.get("generation") == generation)
    )


def set_runtime_active(ledger: dict[str, Any], active: bool) -> None:
    if ledger_is_exact(ledger):
        ledger["runtime_active"] = bool(active)
        if active:
            ledger["status"] = "ACTIVE"
            ledger["shutting_down"] = False
        else:
            ledger["status"] = "SUSPENDED"


def saved_data_is_owned(value: Any) -> bool:
    """Return whether an editable datablock carries this Suite's saved owner mark.

    Runtime resources are generation-scoped, but a generation lives only as long
    as one Blender process.  Data written into a .blend must stay recognisable in
    later sessions, so saved marks are matched by Suite identity alone.  Linked
    library data is read-only here and never counts as owned.
    """
    if value is None:
        return False
    try:
        holder = getattr(value, "id_data", None) or value
        if getattr(holder, "library", None) is not None:
            return False
        return value.get("jelararagi_sgs_owner_suite") == SUITE_ID
    except Exception:
        return False


def _safe_pointer(value: Any) -> int:
    if value is None:
        return 0
    try:
        return int(value.as_pointer())
    except Exception:
        return int(id(value))


def begin_modal(instance: Any, context: Any, cancel_callback: Callable[[str], Any]) -> dict[str, Any] | None:
    ledger = shared_ledger()
    if not runtime_active_for_generation():
        return None
    token = {
        "generation": ledger.get("generation"),
        "shutdown_epoch": int(ledger.get("shutdown_epoch", 0)),
        "window": getattr(context, "window", None),
        "screen": getattr(context, "screen", None),
        "workspace": getattr(context, "workspace", None),
        "area": getattr(context, "area", None),
        "region": getattr(context, "region", None),
        "window_ptr": _safe_pointer(getattr(context, "window", None)),
        "screen_ptr": _safe_pointer(getattr(context, "screen", None)),
        "workspace_ptr": _safe_pointer(getattr(context, "workspace", None)),
        "area_ptr": _safe_pointer(getattr(context, "area", None)),
        "region_ptr": _safe_pointer(getattr(context, "region", None)),
    }
    ledger["modals"][id(instance)] = {
        "instance": instance,
        "token": token,
        "cancel": cancel_callback,
    }
    return token


def finish_modal(instance: Any) -> None:
    ledger = shared_ledger()
    if ledger_is_exact(ledger):
        ledger.get("modals", {}).pop(id(instance), None)


def _contains_identity(values: Any, target: Any) -> bool:
    try:
        return any(value is target or _safe_pointer(value) == _safe_pointer(target) for value in values or ())
    except Exception:
        return False


def modal_environment_valid(token: dict[str, Any] | None, context: Any) -> bool:
    ledger = shared_ledger()
    if not token or not runtime_active_for_generation(str(token.get("generation") or "")):
        return False
    if int(ledger.get("shutdown_epoch", 0)) != int(token.get("shutdown_epoch", -1)):
        return False
    if bool(ledger.get("shutting_down")):
        return False
    wm = getattr(context, "window_manager", None)
    window = token.get("window")
    screen = token.get("screen")
    workspace = token.get("workspace")
    area = token.get("area")
    region = token.get("region")
    if wm is None or not _contains_identity(getattr(wm, "windows", ()), window):
        return False
    if getattr(window, "screen", None) is not screen:
        return False
    if getattr(window, "workspace", None) is not workspace:
        return False
    if not _contains_identity(getattr(screen, "areas", ()), area):
        return False
    if not _contains_identity(getattr(area, "regions", ()), region):
        return False
    return all(
        _safe_pointer(value) == int(token.get(key, 0))
        for value, key in (
            (window, "window_ptr"), (screen, "screen_ptr"), (workspace, "workspace_ptr"),
            (area, "area_ptr"), (region, "region_ptr"),
        )
    )


def cancel_all_modals(ledger: dict[str, Any], reason: str) -> bool:
    """Cancel every exact-generation modal and retain failed records.

    RNA teardown is forbidden while any record remains.  A modal callback may
    return ``False`` to report that draw handlers/timers or generated data could
    not be released; every other non-exception result counts as completed.
    """
    if not ledger_is_exact(ledger):
        return True
    ledger["shutting_down"] = True
    ledger["shutdown_epoch"] = int(ledger.get("shutdown_epoch", 0)) + 1
    records = tuple(ledger.get("modals", {}).values())
    for record in records:
        callback = record.get("cancel")
        completed = not callable(callback)
        if callable(callback):
            try:
                completed = callback(str(reason)) is not False
            except Exception as exc:
                ledger["cleanup_failures"].append({
                    "kind": "modal",
                    "name": type(record.get("instance")).__name__,
                    "error": type(exc).__name__,
                })
                completed = False
        if completed:
            ledger.get("modals", {}).pop(id(record.get("instance")), None)
    return not bool(ledger.get("modals"))


def active_modal_count(ledger: dict[str, Any] | None = None) -> int:
    ledger = ledger or shared_ledger()
    if not ledger_is_exact(ledger):
        return 0
    return len(ledger.get("modals", {}))


def _remove_records_reverse(
    ledger: dict[str, Any], key: str, remover: Callable[[dict[str, Any], dict[str, Any]], bool],
    *, tag: str | None = None,
) -> bool:
    """Remove exact records and retain every failed lease for a safe retry."""
    records = ledger.get(key, [])
    ok = True
    for record in reversed(tuple(records)):
        if tag is not None and str(record.get("tag") or "") != tag:
            continue
        removed = False
        try:
            removed = bool(remover(ledger, record))
        except Exception as exc:
            ledger["cleanup_failures"].append({
                "kind": key, "name": str(record.get("name") or ""),
                "error": type(exc).__name__,
            })
        if removed:
            if record in records:
                records.remove(record)
        else:
            ok = False
    return ok


def remove_tagged_dynamic_resources(ledger: dict[str, Any], tag: str) -> bool:
    """Remove one feature's exact resources without touching other callbacks."""
    if not ledger_is_exact(ledger):
        return False
    tag = str(tag)
    ok = _remove_records_reverse(ledger, "dynamic_cleanups", remove_dynamic_cleanup_record, tag=tag)
    for key, remover in (
        ("timers", remove_timer_record),
        ("msgbus", remove_msgbus_record),
        ("menus", remove_menu_record),
        ("handlers", remove_handler_record),
    ):
        ok = _remove_records_reverse(ledger, key, remover, tag=tag) and ok
    return ok


def remove_dynamic_resources(ledger: dict[str, Any], *, reason: str) -> bool:
    """Remove only exact generation-owned dynamic resources."""
    if not ledger_is_exact(ledger):
        return False
    ok = cancel_all_modals(ledger, reason)
    ok = _remove_records_reverse(ledger, "dynamic_cleanups", remove_dynamic_cleanup_record) and ok
    for key, remover in (
        ("timers", remove_timer_record),
        ("msgbus", remove_msgbus_record),
        ("menus", remove_menu_record),
        ("handlers", remove_handler_record),
    ):
        ok = _remove_records_reverse(ledger, key, remover) and ok
    ledger["runtime_active"] = False
    ledger["status"] = "SUSPENDED"
    return ok and active_modal_count(ledger) == 0 and not any(
        ledger.get(key) for key in (
            "dynamic_cleanups", "timers", "msgbus", "menus", "handlers",
        )
    )


def rollback_registration(ledger: dict[str, Any]) -> bool:
    """Rollback only resources successfully acquired by this unpublished transaction."""
    if not ledger_is_exact(ledger, generation=GENERATION_TOKEN):
        return False
    ledger["status"] = "STOPPING"
    ok = remove_dynamic_resources(ledger, reason="registration_rollback")
    # RNA teardown is unsafe while any exact dynamic lease or modal remains.
    if not ok:
        ledger["status"] = "SUSPENDED"
        ledger["runtime_active"] = False
        return False
    ok = _remove_records_reverse(ledger, "translations", remove_translation_record) and ok
    ok = _remove_records_reverse(ledger, "pointers", remove_pointer_record) and ok
    ok = _remove_records_reverse(ledger, "classes", unregister_class_record) and ok
    ok = release_lazy_modules(ledger) and ok
    if ok and not _ledger_has_resources(ledger):
        ledger["status"] = "STOPPED"
        ledger["shutting_down"] = False
    else:
        ledger["status"] = "SUSPENDED"
        ledger["runtime_active"] = False
    return ok and not _ledger_has_resources(ledger)


def stop_generation(ledger: dict[str, Any], *, reason: str = "unregister") -> bool:
    """Fully stop an exact published generation in dependency-safe reverse order."""
    if not ledger_is_exact(ledger):
        return False
    ledger["status"] = "STOPPING"
    ok = remove_dynamic_resources(ledger, reason=reason)
    if not ok or active_modal_count(ledger) != 0:
        # Keep every RNA owner intact when any exact dynamic lease could not be
        # removed.  This leaves a safe suspended generation that can be retried.
        ledger["status"] = "SUSPENDED"
        ledger["runtime_active"] = False
        return False
    ok = _remove_records_reverse(ledger, "translations", remove_translation_record) and ok
    ok = _remove_records_reverse(ledger, "pointers", remove_pointer_record) and ok
    ok = _remove_records_reverse(ledger, "classes", unregister_class_record) and ok
    ok = release_lazy_modules(ledger) and ok
    if not ok or _ledger_has_resources(ledger):
        ledger["status"] = "SUSPENDED"
        ledger["runtime_active"] = False
        return False
    ledger["status"] = "STOPPED"
    ledger["runtime_active"] = False
    ledger["shutting_down"] = False
    ledger["shutdown_callback"] = None
    ledger["runtime_api"] = {}
    clear_published_ledger(ledger)
    return True


def call_runtime_api(ledger: dict[str, Any], name: str, *args, **kwargs):
    """Call an exact old-generation lifecycle callback without importing modules."""
    callback = (ledger.get("runtime_api") or {}).get(str(name)) if ledger_is_exact(ledger) else None
    if not callable(callback):
        return None
    try:
        return callback(*args, **kwargs)
    except Exception:
        return None


def request_exact_shutdown(ledger: dict[str, Any], *, reason: str) -> bool:
    callback = ledger.get("shutdown_callback") if ledger_is_exact(ledger) else None
    if callable(callback):
        try:
            return bool(callback(ledger, reason=reason))
        except TypeError:
            return bool(callback())
        except Exception:
            return False
    return stop_generation(ledger, reason=reason)
