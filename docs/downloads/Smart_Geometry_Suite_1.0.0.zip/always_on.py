# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

from dataclasses import dataclass
import importlib
import sys
import time

import bpy


@dataclass(frozen=True)
class AlwaysOnFeature:
    feature_id: str
    pref_property: str
    default: bool
    label_en: str
    label_ja: str
    description_en: str
    description_ja: str
    icon: str = 'DOT'


_FEATURES: tuple[AlwaysOnFeature, ...] = (
    AlwaysOnFeature(
        'icon_preview_cache', 'always_on_icon_preview_cache', False,
        'Static Icon Asset Check', '静的アイコンアセット確認',
        'Function: keeps Blender 5.1 crash-safe UI behavior by avoiding live preview icon IDs. When enabled, the suite only verifies that bundled 32 px PNG assets exist for reference/export use. How to use: leave enabled only when you want asset presence checks; it does not start a background timer and it does not replace Blender standard UI icons.',
        '機能: Blender 5.1で安全に使えるよう、ライブプレビューアイコンIDは使わず、同梱32px PNGが参照・書き出し用アセットとして存在するかだけ確認します。使い方: アセット存在確認が必要な場合だけ有効にしてください。バックグラウンドタイマーは開始せず、UIのBlender標準アイコンも置き換えません。',
        'IMAGE_DATA',
    ),
    AlwaysOnFeature(
        'live_mesh_inspector', 'always_on_live_mesh_inspector', False,
        'On-demand Mesh Inspector', 'オンデマンドメッシュ検査',
        'Function: updates active mesh name, vertex count, face count, attribute count, and modifier count only when the Diagnostics section is drawn or the toggle is changed. How to use: enable this when you want the N-panel diagnostics cache to refresh from UI activity without any continuous scene-scanning timer.',
        '機能: アクティブメッシュ名、頂点数、面数、属性数、モディファイア数を、診断セクション描画時または切り替え操作時だけ更新します。使い方: 常時シーンを走査するタイマーを使わず、Nパネル操作時に診断キャッシュを更新したい場合に有効にしてください。',
        'VIEWZOOM',
    ),
    AlwaysOnFeature(
        'live_attribute_guard', 'always_on_live_attribute_guard', False,
        'On-demand Attribute Guard', 'オンデマンド属性ガード',
        'Function: creates missing SGS base attributes only at safe command boundaries such as toggling this item, applying suite features, or running builder operations. How to use: enable this if selected meshes should be repaired before Smart Geometry operations; it does not watch the scene continuously.',
        '機能: この項目を切り替えた時、機能適用時、生成コマンド実行時など、安全な操作境界でだけ不足しているSGS基礎属性を作成します。使い方: Smart Geometry操作前に選択メッシュの属性を補修したい場合に有効にしてください。シーンを常時監視しません。',
        'RNA',
    ),
    AlwaysOnFeature(
        'live_selection_sync', 'always_on_live_selection_sync', False,
        'Selection String Apply-on-change', '選択文字列の変更時適用',
        'Function: reapplies the current Selection String to the active mesh when this toggle is changed or the Selection String setting is edited. How to use: enable while authoring attribute-driven selections; the expression is not polled in the background.',
        '機能: この項目を切り替えた時、またはSelection String設定を編集した時だけ、現在の選択文字列をアクティブメッシュへ再適用します。使い方: 属性駆動の選択範囲を作成している間だけ有効にしてください。バックグラウンドで式をポーリングしません。',
        'RESTRICT_SELECT_OFF',
    ),
    AlwaysOnFeature(
        'live_camera_visibility_gate', 'always_on_live_camera_visibility_gate', False,
        'Camera Visibility Refresh', 'カメラ可視性更新',
        'Function: refreshes sgs_visibility and sgs_cull only when this toggle is changed, relevant Smart Geometry operations run, or deferred save/load hooks are executed. How to use: enable for camera-dependent culling checks without a continuous camera-transform watcher.',
        '機能: この項目を切り替えた時、関連するSmart Geometry操作時、または保存・読み込みフック実行時だけ、sgs_visibilityとsgs_cullを更新します。使い方: カメラ変換を常時監視せず、カメラ依存のカリング確認をしたい場合に有効にしてください。',
        'CAMERA_DATA',
    ),
    AlwaysOnFeature(
        'node_library_guard', 'always_on_node_library_guard', False,
        'Node Library Ensure-on-use', 'ノードライブラリ使用時確認',
        'Function: checks and creates the generated Smart Geometry node-group library only when this toggle is changed, the suite is loaded, or a command needs the library. How to use: enable for template scenes that should repair a missing library at safe operation points; no interval timer is used.',
        '機能: この項目を切り替えた時、スイート読み込み時、またはライブラリを必要とするコマンド実行時だけ、生成済みノードグループライブラリの有無を確認して不足時に作成します。使い方: テンプレートシーンでライブラリ欠落を安全なタイミングで補修したい場合に有効にしてください。間隔タイマーは使いません。',
        'NODETREE',
    ),
    AlwaysOnFeature(
        'parametric_primitive_auto_update', 'always_on_parametric_primitive_auto_update', False,
        'Parametric Primitive Auto Update', 'パラメトリックプリミティブ自動更新',
        'Function: keeps Max Primitives synchronized from depsgraph and frame-change events. How to use: enable only while you need automatic regeneration; disabling removes every owned depsgraph/frame handler and pending update timer.',
        '機能: depsgraphとフレーム変更イベントからMax Primitivesを同期します。使い方: 自動再生成が必要な間だけ有効にしてください。無効化すると所有するdepsgraph・フレームハンドラーと保留中の更新タイマーをすべて解除します。',
        'MODIFIER',
    ),
    AlwaysOnFeature(
        'automatic_proxy_cleanup', 'always_on_automatic_proxy_cleanup', False,
        'Automatic Proxy Cleanup', 'プロキシ自動クリーンアップ',
        'Function: cleans legacy and ephemeral geometry proxies at load/save lifecycle boundaries. How to use: enable only for files that need automatic maintenance; disabling removes its load/save handlers and cleanup timer.',
        '機能: 読み込み・保存時に旧形式および一時ジオメトリプロキシを整理します。使い方: 自動保守が必要なファイルだけ有効にしてください。無効化すると読み込み・保存ハンドラーとクリーンアップタイマーを解除します。',
        'BRUSH_DATA',
    ),
    AlwaysOnFeature(
        'transform_snapshot_restore', 'always_on_transform_snapshot_restore', False,
        'Transform Snapshot Restore', 'トランスフォームスナップショット復元',
        'Function: records generated-object transforms on save and restores protected values after loading a file. How to use: enable only when this automatic lifecycle repair is required; disabling prevents both the snapshot mutation and its delayed restore timer.',
        '機能: 保存時に生成オブジェクトのトランスフォームを記録し、ファイル読み込み後に保護値を復元します。使い方: 自動ライフサイクル修復が必要な場合だけ有効にしてください。無効化するとスナップショット変更と遅延復元タイマーの両方を停止します。',
        'ORIENTATION_GLOBAL',
    ),
    AlwaysOnFeature(
        'auto_diagnostics_snapshot', 'always_on_auto_diagnostics_snapshot', False,
        'Diagnostics Snapshot on Save', '保存時診断スナップショット',
        'Function: writes the Smart Geometry diagnostics JSON at safe save/load or toggle points instead of at repeated intervals. How to use: enable during production audits when you want a report captured at scene lifecycle boundaries without continuous report-writing.',
        '機能: Smart Geometry診断JSONを、繰り返し間隔ではなく、安全な保存・読み込み・切り替えタイミングで書き出します。使い方: 常時レポートを書き続けず、シーンライフサイクルの節目で診断レポートを残したい監査時に有効にしてください。',
        'TEXT',
    ),
)

_FEATURE_BY_ID = {item.feature_id: item for item in _FEATURES}
_FEATURE_BY_PROP = {item.pref_property: item for item in _FEATURES}
_LAST_SELECTION_STATE: tuple[str, str, int] | None = None
_LAST_CAMERA_STATE: tuple[str, tuple[float, ...], int] | None = None
_NODE_GUARD_DONE = False
_NODE_GUARD_PENDING = False
_NODE_GUARD_GENERATION = 0
_NODE_GUARD_TIMER_FN = None
_NODE_GUARD_LAST_ERROR: str | None = None


def _load_feature_module(relative_name: str):
    """Lazy-load and ledger-record one known Suite implementation module."""
    full_name = f'{__package__}.{str(relative_name).lstrip(".")}'
    module = importlib.import_module(full_name)
    try:
        from . import ownership
        ledger = ownership.shared_ledger()
        if ownership.ledger_is_exact(ledger):
            ownership.record_lazy_module(ledger, module)
    except Exception:
        pass
    return module


def _loaded_feature_module(relative_name: str):
    return sys.modules.get(f'{__package__}.{str(relative_name).lstrip(".")}')


def feature_definitions() -> tuple[AlwaysOnFeature, ...]:
    return _FEATURES


def get_feature(feature_id: str) -> AlwaysOnFeature | None:
    return _FEATURE_BY_ID.get(str(feature_id or '')) or _FEATURE_BY_PROP.get(str(feature_id or ''))


def get_settings(context=None):
    try:
        wm = (context or bpy.context).window_manager
        return getattr(wm, 'smart_geometry_suite_settings', None)
    except Exception:
        return None


def feature_value(feature_or_id: AlwaysOnFeature | str, context=None) -> bool:
    feature = feature_or_id if isinstance(feature_or_id, AlwaysOnFeature) else get_feature(str(feature_or_id))
    if feature is None:
        return False
    settings = get_settings(context)
    if settings is not None and hasattr(settings, feature.pref_property):
        try:
            return bool(getattr(settings, feature.pref_property))
        except Exception:
            pass
    return bool(feature.default)


def _text(en: str, ja: str, context=None) -> str:
    try:
        from . import catalog
        return catalog.text(en, ja, context)
    except Exception:
        try:
            locale = str(getattr(bpy.app.translations, 'locale', '') or '')
            if not locale:
                locale = str(getattr(bpy.context.preferences.view, 'language', '') or '')
            return str(ja if locale.lower().startswith('ja') else en)
        except Exception:
            return str(en)


def localized_label(feature: AlwaysOnFeature, context=None) -> str:
    return _text(feature.label_en, feature.label_ja, context)


def localized_description(feature: AlwaysOnFeature, context=None) -> str:
    return _text(feature.description_en, feature.description_ja, context)


def _tag_view3d_redraw(context=None) -> None:
    try:
        wm = getattr(context or bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    try:
                        area.tag_redraw()
                    except Exception:
                        pass
    except Exception:
        pass


def _active_mesh(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        mode = str(getattr(ctx, 'mode', '') or '')
        if mode not in {'', 'OBJECT'}:
            return None
        obj = getattr(ctx, 'active_object', None) or getattr(ctx, 'object', None)
        if getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
            return None
        try:
            if hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
        return obj
    except Exception:
        return None


def _safe_len(value) -> int:
    try:
        return int(len(value or []))
    except Exception:
        return 0


def _mesh_vertex_count(obj) -> int:
    try:
        return _safe_len(getattr(getattr(obj, 'data', None), 'vertices', None))
    except Exception:
        return 0


def _write_mesh_inspection_cache(obj=None, context=None) -> None:
    wm = getattr(context or bpy.context, 'window_manager', None)
    if wm is None:
        return
    try:
        if obj is None:
            wm['sgs_live_mesh_name'] = ''
            wm['sgs_live_vertex_count'] = 0
            wm['sgs_live_edge_count'] = 0
            wm['sgs_live_face_count'] = 0
            wm['sgs_live_attribute_count'] = 0
            wm['sgs_live_modifier_count'] = 0
            return
        mesh = obj.data
        wm['sgs_live_mesh_name'] = str(getattr(obj, 'name', '') or '')
        wm['sgs_live_vertex_count'] = _safe_len(getattr(mesh, 'vertices', None))
        wm['sgs_live_edge_count'] = _safe_len(getattr(mesh, 'edges', None))
        wm['sgs_live_face_count'] = _safe_len(getattr(mesh, 'polygons', None))
        wm['sgs_live_attribute_count'] = _safe_len(getattr(mesh, 'attributes', None))
        wm['sgs_live_modifier_count'] = _safe_len(getattr(obj, 'modifiers', None))
        wm['sgs_live_updated'] = float(time.time())
    except Exception:
        pass


def refresh_mesh_inspector(context=None, *, force: bool = False) -> bool:
    if not force and not feature_value('live_mesh_inspector', context):
        return False
    _write_mesh_inspection_cache(_active_mesh(context), context)
    return True


def ensure_attributes_if_enabled(context=None, obj=None) -> bool:
    if not feature_value('live_attribute_guard', context):
        return False
    obj = obj or _active_mesh(context)
    if obj is None:
        return False
    try:
        mesh_tools = _load_feature_module('mesh_tools')
        mesh_tools.ensure_standard_attributes(obj)
        return True
    except Exception:
        return False


def apply_selection_if_enabled(context=None, *, force: bool = False) -> bool:
    global _LAST_SELECTION_STATE
    if not force and not feature_value('live_selection_sync', context):
        return False
    obj = _active_mesh(context)
    settings = get_settings(context)
    if obj is None or settings is None:
        return False
    try:
        expr = str(getattr(settings, 'selection_string', 'all') or 'all')
        state = (str(getattr(obj, 'name_full', getattr(obj, 'name', 'active'))), expr, _mesh_vertex_count(obj))
        if not force and state == _LAST_SELECTION_STATE:
            return True
        mesh_tools = _load_feature_module('mesh_tools')
        mesh_tools.apply_selection_string(obj, expr)
        _LAST_SELECTION_STATE = state
        return True
    except Exception:
        return False


def _camera_state(context=None) -> tuple[str, tuple[float, ...], int] | None:
    try:
        scene = (context or bpy.context).scene
        camera = scene.camera
        if camera is None:
            return None
        mat = getattr(camera, 'matrix_world', None)
        values = tuple(round(float(v), 5) for row in mat for v in row) if mat is not None else ()
        return (str(getattr(camera, 'name_full', camera.name)), values, int(getattr(scene, 'frame_current', 0)))
    except Exception:
        return None


def refresh_camera_visibility_if_enabled(context=None, *, force: bool = False) -> bool:
    global _LAST_CAMERA_STATE
    if not force and not feature_value('live_camera_visibility_gate', context):
        return False
    obj = _active_mesh(context)
    state = _camera_state(context)
    if obj is None or state is None:
        return False
    try:
        combined = (state[0] + '|' + str(getattr(obj, 'name_full', getattr(obj, 'name', 'active'))), state[1], _mesh_vertex_count(obj) + state[2])
        if not force and combined == _LAST_CAMERA_STATE:
            return True
        mesh_tools = _load_feature_module('mesh_tools')
        refresher = getattr(mesh_tools, 'refresh_camera_visibility_attributes', None)
        if callable(refresher):
            refresher(obj)
        else:
            mesh_tools.ensure_standard_attributes(obj)
        _LAST_CAMERA_STATE = combined
        return True
    except Exception:
        return False


def _deferred_create_library(node_factory, settings, generation: int) -> None:
    global _NODE_GUARD_DONE, _NODE_GUARD_PENDING, _NODE_GUARD_TIMER_FN, _NODE_GUARD_LAST_ERROR
    if generation != _NODE_GUARD_GENERATION:
        # A prior register() generation scheduled this callback and was then
        # unregistered/superseded (e.g. disable, install-over-active, module
        # reload) before the timer fired. reset_node_library_guard() already
        # bumped the generation counter, so this is stale owned work: do not
        # mutate current-generation state or touch node_factory/settings that
        # may belong to a torn-down generation.
        return None
    _NODE_GUARD_PENDING = False
    _NODE_GUARD_TIMER_FN = None
    try:
        node_factory.create_library(settings, force_rebuild=False)
    except Exception as exc:
        # Bounded, non-crashing diagnostic: recorded for the next enable
        # attempt / diagnostics snapshot instead of silently discarded, and
        # the guard is left uncommitted so the next call retries the build.
        _NODE_GUARD_LAST_ERROR = f'{type(exc).__name__}: {exc}'[:500]
        return None
    _NODE_GUARD_LAST_ERROR = None
    _NODE_GUARD_DONE = True
    return None


def ensure_node_library_if_enabled(context=None, *, force: bool = False) -> bool:
    global _NODE_GUARD_PENDING, _NODE_GUARD_TIMER_FN
    if not force and not feature_value('node_library_guard', context):
        return False
    if _NODE_GUARD_DONE and not force:
        return True
    if _NODE_GUARD_PENDING and not force:
        # A build for the current generation is already scheduled; avoid
        # stacking duplicate timers on repeated enable/reconcile passes.
        return False
    try:
        node_factory = _load_feature_module('node_factory')
        if not node_factory.generated_node_groups():
            # The full catalog is 150+ features and 11 pack controllers; building
            # every node group synchronously here would block register()/the
            # calling operation boundary for the whole pass. Defer the actual
            # build one event-loop tick via a one-shot timer (it deregisters
            # itself by returning None) so enabling the Suite never freezes.
            # The guard is committed True only inside _deferred_create_library,
            # and only after create_library() actually succeeds -- never here,
            # so a failed or not-yet-run build stays observable and retryable.
            generation = _NODE_GUARD_GENERATION
            timer_fn = lambda: _deferred_create_library(node_factory, get_settings(context), generation)
            _NODE_GUARD_PENDING = True
            _NODE_GUARD_TIMER_FN = timer_fn
            bpy.app.timers.register(timer_fn, first_interval=0.0)
            return False
        return True
    except Exception:
        _NODE_GUARD_PENDING = False
        _NODE_GUARD_TIMER_FN = None
        return False


def reset_node_library_guard() -> None:
    """Invalidate any in-flight deferred library build.

    Called on unregister/disable so a timer callback scheduled by an earlier
    register() generation cannot fire against (and mutate the guard state or
    settings of) a later generation -- the scenario exercised by repeated
    enable/disable cycles and install-over-active.
    """
    global _NODE_GUARD_DONE, _NODE_GUARD_PENDING, _NODE_GUARD_GENERATION, _NODE_GUARD_TIMER_FN
    _NODE_GUARD_GENERATION += 1
    _NODE_GUARD_DONE = False
    _NODE_GUARD_PENDING = False
    timer_fn, _NODE_GUARD_TIMER_FN = _NODE_GUARD_TIMER_FN, None
    if timer_fn is not None:
        try:
            if bpy.app.timers.is_registered(timer_fn):
                bpy.app.timers.unregister(timer_fn)
        except Exception:
            pass


def write_diagnostics_snapshot_if_enabled(context=None, *, force: bool = False) -> bool:
    if not force and not feature_value('auto_diagnostics_snapshot', context):
        return False
    try:
        diagnostics = _load_feature_module('diagnostics')
        path = diagnostics.write_diagnostics()
        wm = getattr(context or bpy.context, 'window_manager', None)
        if wm is not None:
            wm['sgs_last_auto_diagnostics_path'] = str(path)
        return True
    except Exception:
        return False


def _check_static_icons_if_enabled(context=None) -> bool:
    if not feature_value('icon_preview_cache', context):
        return False
    try:
        icons = _load_feature_module('icons')
        icons.missing_icons()
    except Exception:
        pass
    _tag_view3d_redraw(context)
    return True


def apply_feature(feature_or_id: AlwaysOnFeature | str, context=None) -> None:
    feature = feature_or_id if isinstance(feature_or_id, AlwaysOnFeature) else get_feature(str(feature_or_id))
    if feature is None or not feature_value(feature, context):
        return
    if feature.feature_id == 'icon_preview_cache':
        _check_static_icons_if_enabled(context)
    elif feature.feature_id == 'live_mesh_inspector':
        refresh_mesh_inspector(context, force=True)
    elif feature.feature_id == 'live_attribute_guard':
        ensure_attributes_if_enabled(context)
    elif feature.feature_id == 'live_selection_sync':
        apply_selection_if_enabled(context, force=True)
    elif feature.feature_id == 'live_camera_visibility_gate':
        refresh_camera_visibility_if_enabled(context, force=True)
    elif feature.feature_id == 'node_library_guard':
        ensure_node_library_if_enabled(context)
    elif feature.feature_id == 'auto_diagnostics_snapshot':
        write_diagnostics_snapshot_if_enabled(context)


def _sync_background_runtime(context=None) -> bool:
    """Reconcile event-driven feature leases without importing disabled tools."""
    ok = True
    max_enabled = feature_value('parametric_primitive_auto_update', context)
    max_runtime = _load_feature_module('max_procedural_primitives.runtime') if max_enabled else _loaded_feature_module('max_procedural_primitives.runtime')
    if max_runtime is not None:
        try:
            ok = max_runtime.sync_automatic_updates(bool(max_enabled)) is not False and ok
        except Exception:
            ok = False

    proxy_enabled = feature_value('automatic_proxy_cleanup', context)
    proxy_cleanup = _load_feature_module('proxy_cleanup') if proxy_enabled else _loaded_feature_module('proxy_cleanup')
    if proxy_cleanup is not None:
        try:
            ok = proxy_cleanup.sync(bool(proxy_enabled)) is not False and ok
        except Exception:
            ok = False

    if not feature_value('transform_snapshot_restore', context):
        transform_guard = _loaded_feature_module('transform_guard')
        if transform_guard is not None:
            try:
                ok = transform_guard.cancel_scheduled_restore() is not False and ok
            except Exception:
                ok = False
    return ok


def apply_all_persistent_features(context=None) -> bool:
    # No interval timer is registered. Enabled items perform a bounded pass only
    # at an explicit register/load/toggle/operation boundary.
    for feature in _FEATURES:
        apply_feature(feature, context)
    return _sync_background_runtime(context)


def disable_all_persistent_features(context=None) -> bool:
    """Stop exact loaded feature leases; disabled modules are never imported."""
    ok = True
    reset_node_library_guard()
    for relative_name, callback_name, args in (
        ('max_procedural_primitives.runtime', 'sync_automatic_updates', (False,)),
        ('proxy_cleanup', 'sync', (False,)),
        ('transform_guard', 'cancel_scheduled_restore', ()),
    ):
        module = _loaded_feature_module(relative_name)
        callback = getattr(module, callback_name, None) if module is not None else None
        if callable(callback):
            try:
                ok = callback(*args) is not False and ok
            except Exception:
                ok = False
    _tag_view3d_redraw(context)
    return ok


def set_feature_value(feature_id: str, value: bool, context=None) -> bool:
    feature = get_feature(feature_id)
    if feature is None:
        return False
    settings = get_settings(context)
    if settings is not None and hasattr(settings, feature.pref_property):
        try:
            setattr(settings, feature.pref_property, bool(value))
        except Exception:
            return False
    apply_feature(feature, context)
    _sync_background_runtime(context)
    return True


def on_selection_string_changed(context=None) -> None:
    apply_selection_if_enabled(context, force=True)


def on_operation_boundary(context=None, *, obj=None) -> None:
    # Called by explicit Smart Geometry operators to replace former
    # background guards with safe on-demand synchronization.
    ensure_attributes_if_enabled(context, obj=obj)
    refresh_camera_visibility_if_enabled(context)
    ensure_node_library_if_enabled(context)


def on_scene_lifecycle(context=None) -> None:
    # Save/load points are safe boundaries for non-timer diagnostics and camera
    # visibility refreshes.
    refresh_mesh_inspector(context)
    refresh_camera_visibility_if_enabled(context)
    ensure_node_library_if_enabled(context)
    write_diagnostics_snapshot_if_enabled(context)


def on_load_post(context=None) -> bool:
    """Run bounded post-load work; no recurring timer survives the pass."""
    ok = _sync_background_runtime(context)
    if feature_value('transform_snapshot_restore', context):
        try:
            transform_guard = _load_feature_module('transform_guard')
            ok = transform_guard.schedule_restore_after_load(context) is not False and ok
        except Exception:
            ok = False
    return ok
