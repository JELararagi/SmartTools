# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible storage helpers.

from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Iterable

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

PACKAGE_ID = 'smart_geometry_suite'
USER_DATA_DIRNAME = 'user_data'
CONFIG_DIRNAME = 'Smart_Geometry_Suite'


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def _clean_part(value: object) -> str:
    text = str(value or '').replace('\\', '/').strip('/')
    pieces = [piece for piece in text.split('/') if piece and piece not in {'.', '..'}]
    return '/'.join(pieces)


def _clean_parts(parts: Iterable[object]) -> list[str]:
    result: list[str] = []
    for part in parts:
        cleaned = _clean_part(part)
        if cleaned:
            result.extend([piece for piece in cleaned.split('/') if piece])
    return result


def _blender_version() -> str:
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', None) if bpy is not None else None
        if version and len(version) >= 2:
            return f"{int(version[0])}.{int(version[1])}"
    except Exception:
        pass
    return '5.1'


def _is_user_default_extension_path(path: Path) -> bool:
    try:
        parts = [str(part).lower() for part in Path(path).resolve().parts]
    except Exception:
        parts = [str(part).lower() for part in Path(path).parts]
    for index in range(max(0, len(parts) - 1)):
        if parts[index] == 'extensions' and parts[index + 1] == 'user_default':
            return True
    return False


def _installed_extension_root() -> Path | None:
    current = _package_root()
    try:
        if current.parent.name == 'user_default' and current.parent.parent.name == 'extensions':
            return current
    except Exception:
        pass
    return None


def _extension_path_user_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    fn = getattr(getattr(bpy, 'utils', None), 'extension_path_user', None)
    if not callable(fn):
        return None
    for args, kwargs in (
        ((package_id,), {'path': '', 'create': create}),
        ((package_id,), {'create': create}),
        ((package_id, ''), {'create': create}),
    ):
        try:
            value = fn(*args, **kwargs)
        except TypeError:
            continue
        except Exception:
            continue
        if value:
            path = Path(value)
            if not _is_user_default_extension_path(path):
                continue
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    return None


def _user_resource_root(package_id: str, create: bool) -> Path | None:
    if bpy is None:
        return None
    user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
    if not callable(user_resource):
        return None
    for kind, rel in (
        ('EXTENSIONS', f'user_default/{package_id}'),
        ('EXTENSIONS', f'user_default/smart_geometry_suite'),
    ):
        try:
            value = user_resource(kind, path=rel, create=create)
        except Exception:
            value = ''
        if value:
            path = Path(value)
            if not _is_user_default_extension_path(path):
                continue
            try:
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
            except Exception:
                continue
    try:
        config = user_resource('CONFIG', create=False) or ''
        if config:
            path = Path(config).resolve().parent / 'extensions' / 'user_default' / package_id
            if create:
                path.mkdir(parents=True, exist_ok=True)
            return path
    except Exception:
        pass
    return None


def _platform_user_default_package_root(package_id: str, create: bool) -> Path:
    version = _blender_version()
    if os.name == 'nt':
        roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
        path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'extensions' / 'user_default' / package_id
    else:
        # Non-Windows fallback still mirrors Blender's versioned user_default repository.
        path = Path.home() / '.config' / 'blender' / version / 'extensions' / 'user_default' / package_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def package_id(default: object = None) -> str:
    value = str(default or PACKAGE_ID or '').strip()
    return value or PACKAGE_ID


def manifest_extension_id(default: str = PACKAGE_ID) -> str:
    return package_id(default)


def extension_user_root(package: object | None = None, *, create: bool = False) -> Path:
    pkg = package_id(package)
    installed = _installed_extension_root() if pkg == PACKAGE_ID else None
    if installed is not None:
        return installed
    for candidate in (_extension_path_user_root(pkg, False), _user_resource_root(pkg, False)):
        if candidate is not None:
            return candidate
    return _platform_user_default_package_root(pkg, False)


def user_default_root(*parts: object, package_id: str | None = None, create: bool = True) -> Path:
    # Historical callers used this helper for mutable suite-owned data.  An
    # installed Blender Extension is immutable: writing below its package root
    # changes the archive content hash and can be discarded on update.  Keep
    # all such data in the versioned Blender CONFIG tree instead.
    del package_id
    root = blender_config_dir(CONFIG_DIRNAME, create=create)
    clean = _clean_parts(parts)
    path = root.joinpath(*clean) if clean else root
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def extension_dir(create: bool = False) -> Path:
    return extension_user_root(PACKAGE_ID, create=create)


def user_data_dir(*parts: object, create: bool = False) -> Path:
    """Return the canonical mutable-data root outside the Extension package."""
    path = blender_config_dir(CONFIG_DIRNAME, create=create)
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def user_data_file(*parts: object, create_parent: bool = False) -> Path:
    if not parts:
        raise ValueError('user_data_file requires at least one path component')
    clean = _clean_parts(parts)
    if not clean:
        raise ValueError('user_data_file requires a non-empty filename')
    path = user_data_dir(*clean[:-1], create=create_parent) / clean[-1]
    if create_parent:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def addon_data_path(*parts: object, create: bool = True) -> Path:
    clean = _clean_parts(parts)
    if not clean:
        return addon_data_dir(create=create)
    path = addon_data_dir(*clean[:-1], create=create) / clean[-1]
    return path


def storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def storage_path(filename: object, *parts: object, create: bool = True) -> Path:
    clean = _clean_parts([*parts, filename])
    if not clean:
        raise ValueError('storage_path requires a filename')
    path = storage_dir(*clean[:-1], create=create) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('storage', *parts, create=create)


def data_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('data', *parts, create=create)


def settings_dir(*parts: object, create: bool = True) -> Path:
    return user_data_dir('settings', *parts, create=create)


def blender_config_dir(*parts: object, create: bool = True) -> Path:
    """Return Blender's versioned user config directory.

    Windows target for Blender 5.1:
    C:/Users/<user>/AppData/Roaming/Blender Foundation/Blender/5.1/config
    """
    path: Path | None = None
    if bpy is not None:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            for args, kwargs in (
                (('CONFIG',), {'path': '', 'create': create}),
                (('CONFIG',), {'create': create}),
            ):
                try:
                    value = user_resource(*args, **kwargs)
                except TypeError:
                    continue
                except Exception:
                    continue
                if value:
                    path = Path(value)
                    break
        if path is None:
            resource_path = getattr(getattr(bpy, 'utils', None), 'resource_path', None)
            if callable(resource_path):
                try:
                    value = resource_path('USER')
                except Exception:
                    value = ''
                if value:
                    path = Path(value) / 'config'
    if path is None:
        version = _blender_version()
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            path = Path(roaming) / 'Blender Foundation' / 'Blender' / version / 'config'
        else:
            path = Path.home() / '.config' / 'blender' / version / 'config'
    clean = _clean_parts(parts)
    if clean:
        path = path.joinpath(*clean)
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def blender_config_file(name: object, *, create: bool = True) -> Path:
    clean = _clean_part(name)
    if not clean:
        raise ValueError('blender_config_file requires a filename')
    path = blender_config_dir(create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_dir(*parts: object, create: bool = True, package: object | None = None) -> Path:
    del package
    root = blender_config_dir(CONFIG_DIRNAME, 'runtime', create=create)
    clean = _clean_parts(parts)
    if clean:
        root = root.joinpath(*clean)
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root


def settings_file(name: object, *, create: bool = True) -> Path:
    # Suite N-panel settings are stored in a suite-owned folder inside
    # Blender's versioned config directory so they are preserved across scene
    # switches, Blender restarts, and extension reinstall/update operations.
    clean = _clean_part(name)
    if not clean:
        raise ValueError('settings_file requires a filename')
    path = blender_config_dir(CONFIG_DIRNAME, create=create) / clean
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def runtime_file(filename: object, *subdirs: object, create: bool = True, package: object | None = None) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('runtime_file requires a filename')
    path = runtime_dir(*clean[:-1], create=create, package=package) / clean[-1]
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    return path


def addon_storage_path(filename: object, *subdirs: object, package_id: str | None = None, create: bool = True) -> Path:
    clean = _clean_parts([*subdirs, filename])
    if not clean:
        raise ValueError('addon_storage_path requires a filename')
    del package_id
    root = blender_config_dir(CONFIG_DIRNAME, 'storage', create=create)
    if len(clean) > 1:
        root = root.joinpath(*clean[:-1])
    if create:
        root.mkdir(parents=True, exist_ok=True)
    return root / clean[-1]


def write_json(filename: object, payload: Any, subdir: str = 'reports') -> Path:
    """Write a mutable report/manifest below CONFIG/Smart_Geometry_Suite."""
    path = user_data_file(subdir, filename, create_parent=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    return path


def legacy_extension_user_data_dir(*parts: object) -> Path:
    """Return the pre-8.2.32 package-local mutable-data location, read-only."""
    path = extension_user_root(PACKAGE_ID, create=False) / USER_DATA_DIRNAME
    clean = _clean_parts(parts)
    return path.joinpath(*clean) if clean else path


def migrate_legacy_extension_user_data() -> list[str]:
    """Copy old package-local mutable files into CONFIG without source mutation.

    Existing CONFIG files remain authoritative. Installed Extension files are
    immutable and remain available as read-only migration inputs.
    """
    source_root = legacy_extension_user_data_dir()
    target_root = blender_config_dir(CONFIG_DIRNAME, create=True)
    try:
        if not source_root.is_dir() or source_root.resolve() == target_root.resolve():
            return []
    except Exception:
        return []

    migrated: list[str] = []
    try:
        entries = sorted(source_root.rglob('*'), key=lambda path: (len(path.parts), path.as_posix()))
    except Exception:
        return migrated
    for source in entries:
        try:
            if source.is_symlink() or not source.is_file():
                continue
            relative = source.relative_to(source_root)
            target = target_root / relative
            if target.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            migrated.append(relative.as_posix())
        except Exception:
            continue
    return migrated


def read_json(path: str | Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_write_text(path: str | Path, text: str, *, encoding: str = 'utf-8') -> None:
    """Commit text with a unique same-directory temporary file and readback.

    The target is never opened in-place.  Every failure before ``os.replace``
    leaves the previous authoritative file untouched; a failed replace/readback
    is reported to the caller so the active RNA generation can remain installed.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f'.{target.name}.', suffix='.tmp', dir=str(target.parent))
    tmp = Path(tmp_name)
    committed = False
    try:
        with os.fdopen(fd, 'w', encoding=encoding, newline='') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        if tmp.read_text(encoding=encoding) != text:
            raise IOError(f'atomic temporary readback mismatch: {target.name}')
        os.replace(tmp, target)
        committed = True
        try:
            directory_fd = os.open(str(target.parent), os.O_RDONLY)
        except (AttributeError, OSError):
            directory_fd = -1
        if directory_fd >= 0:
            try:
                os.fsync(directory_fd)
            except OSError:
                pass
            finally:
                os.close(directory_fd)
        if target.read_text(encoding=encoding) != text:
            raise IOError(f'atomic final readback mismatch: {target.name}')
    finally:
        if not committed or tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def atomic_write_json(path: str | Path, data: Any, *, indent: int = 2, ensure_ascii: bool = False, sort_keys: bool = False) -> None:
    atomic_write_text(path, json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, sort_keys=sort_keys, default=str), encoding='utf-8')


def migrate_legacy_file(legacy_path: Path | None, target_path: Path | None, *, remove_legacy: bool = False) -> bool:
    """Copy one legacy file to CONFIG while retaining the source by default."""
    if legacy_path is None or target_path is None:
        return False
    legacy = Path(legacy_path)
    target = Path(target_path)
    try:
        if not legacy.exists() or target.exists():
            return False
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(legacy, target)
        package_local = False
        try:
            legacy.resolve(strict=False).relative_to(_package_root().resolve(strict=False))
            package_local = True
        except Exception:
            package_local = False
        if remove_legacy and not package_local:
            try:
                legacy.unlink()
            except Exception:
                pass
        return True
    except Exception:
        return False
