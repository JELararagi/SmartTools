# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Migrated Smart Modeling geometry-node generator tools.

These tools now belong to Smart Geometry Suite.  They keep their existing
operator identifiers for user keymap and file compatibility, but their package
location, sidebar category, and runtime ownership are Smart Geometry Suite.
"""

from __future__ import annotations

import importlib
from types import ModuleType
from typing import Iterable

import bpy

_MODULE_NAMES = (
    'max_procedural_primitives',
    'grease_mesh',
)
_REGISTERED_MODULES: list[ModuleType] = []


def _module_full_name(module_name: str) -> str:
    package = __package__ or __name__.rsplit('.', 1)[0]
    return f'{package}.{module_name}'


def _iter_modules() -> Iterable[ModuleType]:
    for module_name in _MODULE_NAMES:
        yield importlib.import_module(_module_full_name(module_name))


def _set_shutdown_flag(value: bool) -> None:
    try:
        ns = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
        if isinstance(ns, dict):
            ns['SMART_GEOMETRY_SUITE_SHUTTING_DOWN'] = bool(value)
    except Exception:
        pass


def _instrument_owned_operator_classes(modules: Iterable[ModuleType]) -> None:
    """Instrument only this package's known modules before their RNA registration."""
    try:
        from . import status_runtime
    except Exception:
        return
    package = str(__package__ or __name__.rsplit('.', 1)[0])
    pending = list(modules)
    seen_modules: set[int] = set()
    seen_classes: set[type] = set()
    while pending:
        module = pending.pop()
        if not isinstance(module, ModuleType) or id(module) in seen_modules:
            continue
        module_name = str(getattr(module, '__name__', '') or '')
        if module_name != package and not module_name.startswith(package + '.'):
            continue
        seen_modules.add(id(module))
        try:
            values = tuple(vars(module).values())
        except Exception:
            values = ()
        for value in values:
            if isinstance(value, ModuleType):
                child_name = str(getattr(value, '__name__', '') or '')
                if child_name == package or child_name.startswith(package + '.'):
                    pending.append(value)
            elif isinstance(value, type) and value not in seen_classes:
                seen_classes.add(value)
                try:
                    status_runtime.instrument_operator_class(
                        value, 'smart_geometry_suite', 'Smart Geometry Suite'
                    )
                except Exception:
                    pass


def register() -> None:
    _set_shutdown_flag(False)
    if _REGISTERED_MODULES:
        return
    modules = list(_iter_modules())
    _instrument_owned_operator_classes(modules)
    registered: list[ModuleType] = []
    try:
        for module in modules:
            register_fn = getattr(module, 'register', None)
            if callable(register_fn):
                register_fn()
            registered.append(module)
    except Exception:
        for module in reversed(registered):
            unregister_fn = getattr(module, 'unregister', None)
            if callable(unregister_fn):
                try:
                    unregister_fn()
                except Exception:
                    pass
        raise
    _REGISTERED_MODULES[:] = registered




def suspend_runtime() -> None:
    """Disable integrated background/UI callbacks without replacing RNA classes."""
    _set_shutdown_flag(True)
    try:
        from .max_procedural_primitives import runtime as primitive_runtime
        primitive_runtime.unregister_handlers()
    except Exception:
        pass
    try:
        from .max_procedural_primitives import modifier_ui
        modifier_ui.suspend_runtime()
    except Exception:
        pass


def resume_runtime() -> None:
    """Re-enable integrated panel polling; always-on reconciliation owns handlers."""
    _set_shutdown_flag(False)
    try:
        from .max_procedural_primitives import modifier_ui
        modifier_ui.resume_runtime()
    except Exception:
        pass


def unregister() -> None:
    _set_shutdown_flag(True)
    modules = list(_REGISTERED_MODULES)
    if not modules:
        try:
            modules = list(_iter_modules())
        except Exception:
            modules = []
    for module in reversed(modules):
        unregister_fn = getattr(module, 'unregister', None)
        if callable(unregister_fn):
            try:
                unregister_fn()
            except Exception:
                pass
    _REGISTERED_MODULES.clear()
