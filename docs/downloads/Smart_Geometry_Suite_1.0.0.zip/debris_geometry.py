# SPDX-License-Identifier: GPL-3.0-or-later
"""Local geometry constructors for the Smart Geometry debris tools."""
from math import cos, pi, sin, tau
from mathutils import Vector


class Mesh:
    def __init__(self, vertices=(), faces=()):
        self.vertices=list(vertices)
        self.faces=list(faces)
        self.accent=set()

    def extend(self, other, offset=(0,0,0), accent=False):
        first=len(self.vertices)
        start=len(self.faces)
        self.vertices.extend((x+offset[0],y+offset[1],z+offset[2]) for x,y,z in other.vertices)
        self.faces.extend(tuple(first+i for i in face) for face in other.faces)
        if accent:self.accent.update(range(start,len(self.faces)))
        else:self.accent.update(start+i for i in other.accent)

    @classmethod
    def from_shape(cls,data):
        return cls(data['verts'],data['faces'])


def tapered(path,radii,sides=7,twist=0):
    """Parallel-transport polygon sections along a polyline; radii may be elliptical."""
    mesh=Mesh(); centres=[Vector(v) for v in path]
    normal=None
    for j,pt in enumerate(centres):
        direction=(centres[min(j+1,len(centres)-1)]-centres[max(0,j-1)]).normalized()
        if normal is None:
            ref=Vector((0,0,1)) if abs(direction.z)<0.85 else Vector((1,0,0))
            normal=direction.cross(ref).normalized()
        else:
            normal=(normal-direction*direction.dot(normal)).normalized()
        other=direction.cross(normal)
        a,b=radii[j] if isinstance(radii[j],tuple) else (radii[j],radii[j])
        for k in range(sides):
            angle=tau*k/sides+twist*j/max(1,len(path)-1)
            mesh.vertices.append(tuple(pt+normal*(a*cos(angle))+other*(b*sin(angle))))
        if j:
            for k in range(sides):
                left=(j-1)*sides+k
                right=(j-1)*sides+(k+1)%sides
                mesh.faces.append((left,right,right+sides,left+sides))
    mesh.faces.append(tuple(reversed(range(sides))))
    mesh.faces.append(tuple(range(len(mesh.vertices)-sides,len(mesh.vertices))))
    return mesh


def globe(rng,radii,bands,sides,distort):
    """Closed triangulated UV shell with independent longitudes and no pole duplicates."""
    offset=rng.uniform(-pi,pi)
    mesh=Mesh([(0,0,-radii[2])])
    for j in range(1,bands):
        lat=pi*(j/bands-0.5)
        for k in range(sides):
            lon=tau*(k+0.15*sin(j*1.7))/sides+offset
            scale=max(0.2,1+distort(lon,lat))
            mesh.vertices.append((radii[0]*cos(lat)*cos(lon)*scale,radii[1]*cos(lat)*sin(lon)*scale,radii[2]*sin(lat)*scale))
    top=len(mesh.vertices);mesh.vertices.append((0,0,radii[2]))
    for k in range(sides):
        nxt=(k+1)%sides
        mesh.faces.append((0,nxt+1,k+1))
        for row in range(bands-2):
            q=1+row*sides
            a,b,c,d=q+k,q+nxt,q+nxt+sides,q+k+sides
            mesh.faces.extend(((a,b,c),(a,c,d)))
        last=1+(bands-2)*sides
        mesh.faces.append((last+k,last+nxt,top))
    return mesh


def sheet(nx,ny,point,visible):
    mesh=Mesh([point(i/nx,j/ny) for j in range(ny+1) for i in range(nx+1)])
    for j in range(ny):
        for i in range(nx):
            if visible((i+0.5)/nx,(j+0.5)/ny):
                a=j*(nx+1)+i
                mesh.faces.append((a,a+1,a+nx+2,a+nx+1))
    # Remove vertices that belong exclusively to cut-away cells.
    used=sorted({i for face in mesh.faces for i in face})
    index={v:k for k,v in enumerate(used)}
    return Mesh([mesh.vertices[i] for i in used],[tuple(index[i] for i in face) for face in mesh.faces])


def plank(length,width,height,twist,rough,rng):
    mesh=Mesh()
    for i in range(7):
        t=i/6;theta=twist*(t-0.5)
        for y,z in [(-width,-height),(width,-height),(width,height),(-width,height)]:
            end_jitter=rng.uniform(-rough,rough) if i in (0,6) else 0
            mesh.vertices.append(((t-0.5)*length+end_jitter,
                                  0.5*(y*cos(theta)-z*sin(theta)),0.5*(y*sin(theta)+z*cos(theta))))
        if i:
            for k in range(4):
                a=4*(i-1)+k;b=4*(i-1)+(k+1)%4
                mesh.faces.append((a,b,b+4,a+4))
    mesh.faces.extend(((3,2,1,0),(24,25,26,27)))
    return mesh
