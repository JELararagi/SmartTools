# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 1
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
EXTENSION_ID = "smart_geometry_suite"
CONFIG_FOLDER = "Smart_Geometry_Suite"
CONFIG_FILE = "Smart_Geometry_Suite.json"
STATE_SAVE_PATH = "window_manager.smart_geometry_suite_settings.n_panel_state_save"
SECTION_OPEN_PATH = "window_manager.smart_geometry_suite_settings.ui_section_always_on"
RUNTIME_TOGGLE_PATHS = (
    "window_manager.smart_geometry_suite_settings.always_on_icon_preview_cache",
    "window_manager.smart_geometry_suite_settings.always_on_live_mesh_inspector",
    "window_manager.smart_geometry_suite_settings.always_on_live_attribute_guard",
    "window_manager.smart_geometry_suite_settings.always_on_live_selection_sync",
    "window_manager.smart_geometry_suite_settings.always_on_live_camera_visibility_gate",
    "window_manager.smart_geometry_suite_settings.always_on_node_library_guard",
    "window_manager.smart_geometry_suite_settings.always_on_parametric_primitive_auto_update",
    "window_manager.smart_geometry_suite_settings.always_on_automatic_proxy_cleanup",
    "window_manager.smart_geometry_suite_settings.always_on_transform_snapshot_restore",
    "window_manager.smart_geometry_suite_settings.always_on_auto_diagnostics_snapshot",
)
ROOT_PANEL_IDS = ("VIEW3D_PT_sgs_root",)
PERSISTENCE_ROOTS = (
    "window_manager.smart_geometry_suite_settings",
    "scene.smart_geometry_suite_debris",
)
EXCLUDED_TRANSIENT_PATHS = (
    "window_manager.smart_geometry_suite_settings.name",
    "scene.smart_geometry_suite_debris.name",
)
