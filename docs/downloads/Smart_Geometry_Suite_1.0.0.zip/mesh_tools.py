# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import bisect
import csv
import math
import random
import re
from array import array
from collections import deque
from pathlib import Path
from typing import Any, Iterable

import bpy

from . import catalog, node_factory


def _object_name(en: str, ja: str) -> str:
    return ja if catalog.is_japanese() else en


def _fragment_name_ja(piece_id: int) -> str:
    number = piece_id
    while f'破片 {number:03d}' in bpy.data.objects:
        number += 1
    return f'破片 {number:03d}'


# -----------------------------------------------------------------------------
# Low-level utility helpers
# -----------------------------------------------------------------------------


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return int(default)


def _to_tuple(co: Any) -> tuple[float, float, float]:
    try:
        return (float(co.x), float(co.y), float(co.z))
    except Exception:
        try:
            return (float(co[0]), float(co[1]), float(co[2]))
        except Exception:
            return (0.0, 0.0, 0.0)


def _v_add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _v_sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _v_mul(a, s: float):
    return (a[0] * s, a[1] * s, a[2] * s)


def _v_dot(a, b) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _v_cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def _v_len(a) -> float:
    return math.sqrt(max(0.0, _v_dot(a, a)))


def _v_norm(a, fallback=(0.0, 0.0, 1.0)):
    length = _v_len(a)
    if length <= 1e-12:
        return fallback
    return (a[0] / length, a[1] / length, a[2] / length)


def _v_lerp(a, b, t: float):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)


def _smoothstep(t: float) -> float:
    t = _clamp(t)
    return t * t * (3.0 - 2.0 * t)


def _sanitize_attr_name(name: str) -> str:
    text = re.sub(r'[^A-Za-z0-9_]+', '_', str(name or '').strip().lower()).strip('_')
    return text[:48] or 'value'


def _link_object(obj, context=None) -> None:
    ctx = context or bpy.context
    data = getattr(obj, 'data', None)
    if data is not None and data.name.startswith('SGS_') and catalog.is_japanese():
        data.name = obj.name
    try:
        collection = ctx.collection
        if obj.name not in collection.objects:
            collection.objects.link(obj)
    except Exception:
        try:
            bpy.context.collection.objects.link(obj)
        except Exception:
            pass
    try:
        for other in ctx.selected_objects:
            other.select_set(False)
        obj.select_set(True)
        ctx.view_layer.objects.active = obj
    except Exception:
        pass


# -----------------------------------------------------------------------------
# Attribute IO
# -----------------------------------------------------------------------------


def _ensure_attribute(mesh, name: str, data_type: str = 'FLOAT', domain: str = 'POINT'):
    try:
        attr = mesh.attributes.get(name)
        if attr is None:
            attr = mesh.attributes.new(name=name, type=data_type, domain=domain)
        return attr
    except Exception:
        return None


def _write_attr_values(mesh, name: str, data_type: str, values: list[Any], domain: str = 'POINT') -> bool:
    attr = _ensure_attribute(mesh, name, data_type, domain)
    if attr is None:
        return False
    try:
        # Whole-layer transfer: one Python call per element is what makes dense meshes slow.
        if attr.data_type == data_type and len(values) == len(attr.data):
            if data_type == 'FLOAT':
                attr.data.foreach_set('value', array('f', values))
                mesh.update_tag()
                return True
            if data_type == 'INT':
                attr.data.foreach_set('value', array('i', [int(v) for v in values]))
                mesh.update_tag()
                return True
            if data_type == 'FLOAT_VECTOR':
                flat = array('f', [c for v in values for c in v])
                if len(flat) == len(values) * 3:
                    attr.data.foreach_set('vector', flat)
                    mesh.update_tag()
                    return True
        for i, item in enumerate(attr.data):
            if i >= len(values):
                break
            value = values[i]
            if data_type == 'INT':
                item.value = int(value)
            elif data_type == 'BOOLEAN':
                item.value = bool(value)
            elif data_type == 'FLOAT_VECTOR':
                item.vector = value
            elif data_type in {'FLOAT_COLOR', 'BYTE_COLOR'}:
                item.color = value
            else:
                item.value = float(value)
        return True
    except Exception:
        return False


def _read_attr_values(mesh, name: str, default: float = 0.0, count: int | None = None) -> list[float]:
    if mesh is None:
        return []
    if count is None:
        count = len(getattr(mesh, 'vertices', []) or [])
    attr = None
    try:
        attr = mesh.attributes.get(name)
    except Exception:
        attr = None
    if attr is None:
        return [float(default)] * int(count or 0)
    result: list[float] = []
    try:
        if attr.data_type in {'FLOAT', 'INT'}:
            layer = array('f' if attr.data_type == 'FLOAT' else 'i', [0]) * len(attr.data)
            attr.data.foreach_get('value', layer)
            result = [float(v) for v in layer]
            if len(result) < count:
                result.extend([float(default)] * (count - len(result)))
            return result[:count]
        for item in attr.data:
            if hasattr(item, 'value'):
                result.append(float(item.value))
            elif hasattr(item, 'vector'):
                result.append(float(_v_len(item.vector)))
            elif hasattr(item, 'color'):
                result.append(float(sum(item.color[:3]) / 3.0))
            else:
                result.append(float(default))
    except Exception:
        result = []
    if len(result) < count:
        result.extend([float(default)] * (count - len(result)))
    return result[:count]


def _read_int_attr(mesh, name: str, default: int = 0, count: int | None = None) -> list[int]:
    return [int(round(v)) for v in _read_attr_values(mesh, name, float(default), count)]


# -----------------------------------------------------------------------------
# Deterministic procedural fields
# -----------------------------------------------------------------------------


def _hash01(ix: int, iy: int, seed: int) -> float:
    n = (ix * 374761393 + iy * 668265263 + seed * 1442695040888963407) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFFFFFF) / 4294967295.0


def _value_noise2(x: float, y: float, seed: int) -> float:
    ix = math.floor(x)
    iy = math.floor(y)
    fx = x - ix
    fy = y - iy
    sx = _smoothstep(fx)
    sy = _smoothstep(fy)
    a = _hash01(ix, iy, seed)
    b = _hash01(ix + 1, iy, seed)
    c = _hash01(ix, iy + 1, seed)
    d = _hash01(ix + 1, iy + 1, seed)
    ab = a + (b - a) * sx
    cd = c + (d - c) * sx
    return ab + (cd - ab) * sy


def _fbm2(x: float, y: float, seed: int, octaves: int = 6) -> float:
    total = 0.0
    amp = 0.55
    freq = 1.0
    denom = 0.0
    for octave in range(max(1, octaves)):
        total += (_value_noise2(x * freq, y * freq, seed + octave * 1013) * 2.0 - 1.0) * amp
        denom += amp
        freq *= 2.03
        amp *= 0.52
    return total / max(1e-9, denom)


def _ridge2(x: float, y: float, seed: int) -> float:
    return 1.0 - abs(_fbm2(x, y, seed, 5))


def _normalize_values(values: list[float], lo: float = 0.0, hi: float = 1.0) -> list[float]:
    if not values:
        return []
    mn = min(values)
    mx = max(values)
    span = max(1e-12, mx - mn)
    scale = hi - lo
    return [lo + ((v - mn) / span) * scale for v in values]


def _safe_mean(values: Iterable[float], default: float = 0.0) -> float:
    vals = [float(v) for v in values]
    return sum(vals) / len(vals) if vals else float(default)


def _rank01(values: list[float], reverse: bool = False) -> list[float]:
    """Return stable 0..1 ranks. Ties keep deterministic index order."""
    if not values:
        return []
    if len(values) == 1:
        return [1.0]
    order = sorted(range(len(values)), key=lambda i: (values[i], i), reverse=reverse)
    out = [0.0] * len(values)
    denom = max(1, len(values) - 1)
    for rank, idx in enumerate(order):
        out[idx] = rank / denom
    return out


def _grid_cell_key(point, spacing: float) -> tuple[int, int, int]:
    spacing = max(1e-9, float(spacing))
    return (math.floor(point[0] / spacing), math.floor(point[1] / spacing), math.floor(point[2] / spacing))


def _rebuild_cell_map(points: list[tuple[float, float, float]], spacing: float) -> dict[tuple[int, int, int], list[int]]:
    cells: dict[tuple[int, int, int], list[int]] = {}
    for idx, point in enumerate(points):
        cells.setdefault(_grid_cell_key(point, spacing), []).append(idx)
    return cells


def _nearby_point_indices(point, cells: dict[tuple[int, int, int], list[int]], spacing: float) -> Iterable[int]:
    key = _grid_cell_key(point, spacing)
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                yield from cells.get((key[0] + dx, key[1] + dy, key[2] + dz), [])


def _relax_point_set(points: list[tuple[float, float, float]], spacing: float, iterations: int, strength: float = 0.38) -> list[tuple[float, float, float]]:
    """Small deterministic blue-noise relaxation pass for accepted points.

    It avoids expensive global nearest-neighbor searches by using a sparse grid.
    The function intentionally does not project back to a source surface; it is
    a geometry-safe refinement for helper point clouds and preview points.
    """
    if len(points) < 2 or spacing <= 1e-9 or iterations <= 0:
        return list(points)
    pts = [tuple(map(float, p)) for p in points]
    for _ in range(max(0, min(12, int(iterations)))):
        cells = _rebuild_cell_map(pts, spacing)
        moved: list[tuple[float, float, float]] = []
        for i, point in enumerate(pts):
            push = (0.0, 0.0, 0.0)
            total = 0.0
            for j in _nearby_point_indices(point, cells, spacing):
                if i == j:
                    continue
                diff = _v_sub(point, pts[j])
                dist = _v_len(diff)
                if 1e-9 < dist < spacing:
                    w = (spacing - dist) / spacing
                    push = _v_add(push, _v_mul(diff, w / dist))
                    total += w
            if total > 0.0:
                step = _v_mul(push, strength * spacing / max(1.0, total))
                moved.append(_v_add(point, step))
            else:
                moved.append(point)
        pts = moved
    return pts


def _vertex_area_values(mesh) -> list[float]:
    count = _mesh_vertex_count(mesh)
    areas = [0.0] * count
    try:
        for poly in mesh.polygons:
            share = float(getattr(poly, 'area', 0.0)) / max(1, len(poly.vertices))
            for vid in poly.vertices:
                if 0 <= int(vid) < count:
                    areas[int(vid)] += share
    except Exception:
        pass
    return _normalize_values(areas)


def _mean_edge_length_values(mesh, neighbors: list[set[int]]) -> list[float]:
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    coords = [_to_tuple(v.co) for v in mesh.vertices]
    out: list[float] = []
    for i in range(count):
        if not neighbors[i]:
            out.append(0.0)
            continue
        out.append(sum(_v_len(_v_sub(coords[i], coords[j])) for j in neighbors[i]) / max(1, len(neighbors[i])))
    return _normalize_values(out)


def _flow_direction_values(mesh, heights: list[float], neighbors: list[set[int]]) -> list[tuple[float, float, float]]:
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    coords = [_to_tuple(v.co) for v in mesh.vertices]
    result: list[tuple[float, float, float]] = []
    for i in range(count):
        best = i
        best_drop = 0.0
        for j in neighbors[i]:
            drop = heights[i] - heights[j]
            if drop > best_drop:
                best_drop = drop
                best = j
        if best == i:
            result.append((0.0, 0.0, 0.0))
        else:
            v = _v_sub(coords[best], coords[i])
            result.append(_v_norm((v[0], v[1], 0.0), (0.0, 0.0, 0.0)))
    return result


def _aspect_values(mesh) -> list[float]:
    result: list[float] = []
    try:
        for v in mesh.vertices:
            n = getattr(v, 'normal', None)
            x = float(getattr(n, 'x', 0.0))
            y = float(getattr(n, 'y', 0.0))
            result.append(((math.atan2(y, x) / math.tau) + 1.0) % 1.0)
    except Exception:
        result = [0.0] * _mesh_vertex_count(mesh)
    return result


def _face_adjacency(mesh) -> list[set[int]]:
    polys = list(getattr(mesh, 'polygons', []) or [])
    adjacency = [set() for _ in polys]
    edge_to_faces: dict[tuple[int, int], list[int]] = {}
    for pi, poly in enumerate(polys):
        verts = [int(v) for v in poly.vertices]
        for i, a in enumerate(verts):
            b = verts[(i + 1) % len(verts)]
            key = (a, b) if a <= b else (b, a)
            edge_to_faces.setdefault(key, []).append(pi)
    for faces in edge_to_faces.values():
        if len(faces) < 2:
            continue
        for a in faces:
            for b in faces:
                if a != b:
                    adjacency[a].add(b)
    return adjacency


def _farthest_face_seeds(centers: list[tuple[float, float, float]], count: int, seed: int) -> list[int]:
    if not centers:
        return []
    count = max(1, min(int(count), len(centers)))
    rng = random.Random(seed)
    seeds = [rng.randrange(len(centers))]
    min_dist = [_v_len(_v_sub(c, centers[seeds[0]])) for c in centers]
    while len(seeds) < count:
        best = max(range(len(centers)), key=lambda i: (min_dist[i], -i))
        if best in seeds:
            break
        seeds.append(best)
        for i, c in enumerate(centers):
            min_dist[i] = min(min_dist[i], _v_len(_v_sub(c, centers[best])))
    return seeds


# -----------------------------------------------------------------------------
# Mesh analysis attributes
# -----------------------------------------------------------------------------


def _mesh_vertex_count(mesh) -> int:
    try:
        return len(mesh.vertices)
    except Exception:
        return 0


def _mesh_neighbors(mesh) -> tuple[list[set[int]], set[int]]:
    count = _mesh_vertex_count(mesh)
    neighbors = [set() for _ in range(count)]
    edge_face_count: dict[tuple[int, int], int] = {}
    try:
        edge_verts = array('i', [0]) * (len(mesh.edges) * 2)
        mesh.edges.foreach_get('vertices', edge_verts)
        for a, b in zip(edge_verts[0::2], edge_verts[1::2]):
            if 0 <= a < count and 0 <= b < count:
                neighbors[a].add(b)
                neighbors[b].add(a)
                key = (a, b) if a <= b else (b, a)
                edge_face_count.setdefault(key, 0)
    except Exception:
        pass
    try:
        loop_verts = array('i', [0]) * len(mesh.loops)
        mesh.loops.foreach_get('vertex_index', loop_verts)
        loop_starts = array('i', [0]) * len(mesh.polygons)
        loop_totals = array('i', [0]) * len(mesh.polygons)
        mesh.polygons.foreach_get('loop_start', loop_starts)
        mesh.polygons.foreach_get('loop_total', loop_totals)
        for start, total in zip(loop_starts, loop_totals):
            verts = loop_verts[start:start + total]
            for i, a in enumerate(verts):
                b = verts[(i + 1) % total]
                key = (a, b) if a <= b else (b, a)
                edge_face_count[key] = edge_face_count.get(key, 0) + 1
                if 0 <= a < count and 0 <= b < count:
                    neighbors[a].add(b)
                    neighbors[b].add(a)
    except Exception:
        pass
    boundary: set[int] = set()
    for (a, b), nfaces in edge_face_count.items():
        if nfaces <= 1:
            boundary.add(a)
            boundary.add(b)
    return neighbors, boundary


def _vertex_heights(mesh) -> list[float]:
    try:
        return [float(v.co.z) for v in mesh.vertices]
    except Exception:
        return []


def _normal_z_values(mesh) -> list[float]:
    values: list[float] = []
    try:
        for v in mesh.vertices:
            values.append(float(getattr(v.normal, 'z', 1.0)))
    except Exception:
        values = [1.0] * _mesh_vertex_count(mesh)
    return values


def _curvature_values(mesh, neighbors: list[set[int]] | None = None) -> list[float]:
    count = _mesh_vertex_count(mesh)
    if count == 0:
        return []
    if neighbors is None:
        neighbors, _boundary = _mesh_neighbors(mesh)
    try:
        normals = [v.normal.copy() for v in mesh.vertices]
    except Exception:
        return [0.0] * count
    values: list[float] = []
    for i in range(count):
        if not neighbors[i]:
            values.append(0.0)
            continue
        total = 0.0
        for j in neighbors[i]:
            try:
                total += _clamp(1.0 - float(normals[i].dot(normals[j])), 0.0, 2.0)
            except Exception:
                pass
        values.append(_clamp(total / max(1, len(neighbors[i])), 0.0, 1.0))
    return values


def _edge_distance_values(neighbors: list[set[int]], boundary: set[int]) -> list[float]:
    count = len(neighbors)
    if count == 0:
        return []
    if not boundary:
        return [1.0] * count
    dist = [-1] * count
    queue: deque[int] = deque()
    for idx in boundary:
        if 0 <= idx < count:
            dist[idx] = 0
            queue.append(idx)
    while queue:
        cur = queue.popleft()
        for nxt in neighbors[cur]:
            if dist[nxt] < 0:
                dist[nxt] = dist[cur] + 1
                queue.append(nxt)
    max_d = max([d for d in dist if d >= 0] or [1])
    return [_clamp((d if d >= 0 else max_d) / max(1, max_d)) for d in dist]


def _convexity_values(heights: list[float], neighbors: list[set[int]]) -> list[float]:
    if not heights:
        return []
    span = max(1e-8, max(heights) - min(heights))
    result: list[float] = []
    for i, h in enumerate(heights):
        if not neighbors[i]:
            result.append(0.5)
            continue
        avg = sum(heights[j] for j in neighbors[i]) / max(1, len(neighbors[i]))
        result.append(_clamp(0.5 + (h - avg) / span * 1.75))
    return result


def _biome_values(height_norm: list[float], slopes: list[float], wetness: list[float], curvature: list[float]) -> list[int]:
    result: list[int] = []
    for h, s, w, c in zip(height_norm, slopes, wetness, curvature):
        if h < 0.16 and w > 0.45:
            result.append(0)  # water / low basin
        elif s > 0.68 or c > 0.52:
            result.append(3)  # rock / exposed steep surface
        elif h > 0.82:
            result.append(4)  # high ridge / snow marker
        elif w > 0.62 and s < 0.38:
            result.append(2)  # dense habitat
        else:
            result.append(1)  # general ground
    return result


def ensure_standard_attributes(obj) -> list[str]:
    """Write the dense v5 neutral attribute layer on the active mesh.

    The layer is intentionally independent from external products. It improves
    downstream selection, distribution, terrain, material, visibility, and
    diagnostic workflows by storing reusable scalar and vector fields instead of
    requiring every tool to recompute local topology.
    """
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return []
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return []
    try:
        mesh.update()
        mesh.calc_normals()
    except Exception:
        pass
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []

    neighbors, boundary = _mesh_neighbors(mesh)
    heights = _vertex_heights(mesh)
    height_norm = _normalize_values(heights)
    normal_z = _normal_z_values(mesh)
    slopes = [_clamp(1.0 - abs(z)) for z in normal_z]
    normal_curvature = _curvature_values(mesh, neighbors)
    convexity = _convexity_values(heights, neighbors)
    edge_dist = _edge_distance_values(neighbors, boundary)
    valence = [len(n) for n in neighbors]
    valence_norm = _normalize_values([float(v) for v in valence])
    vertex_area = _vertex_area_values(mesh)
    mean_edge = _mean_edge_length_values(mesh, neighbors)
    aspect = _aspect_values(mesh)
    flow_dir = _flow_direction_values(mesh, heights, neighbors)

    # Preserve author/generated terrain fields when present; otherwise derive
    # robust analytical fallbacks from height, normal, boundary, and curvature.
    wetness = _read_attr_values(mesh, 'sgs_wetness', 0.0, count)
    if not any(abs(w) > 1e-9 for w in wetness):
        wetness = [_clamp((1.0 - h) * 0.48 + (1.0 - s) * 0.19 + (1.0 - e) * 0.18 + max(0.0, 0.5 - cv) * 0.15) for h, s, e, cv in zip(height_norm, slopes, edge_dist, convexity)]
    flow = _read_attr_values(mesh, 'sgs_flow', 0.0, count)
    if not any(abs(f) > 1e-9 for f in flow):
        flow = [_clamp(w * 0.58 + s * 0.27 + (1.0 - e) * 0.15) for w, s, e in zip(wetness, slopes, edge_dist)]
    erosion = _read_attr_values(mesh, 'sgs_erosion', 0.0, count)
    if not any(abs(e) > 1e-9 for e in erosion):
        erosion = [_clamp(f * (0.35 + s * 0.65) * (0.6 + c * 0.4)) for f, s, c in zip(flow, slopes, normal_curvature)]
    sediment = _read_attr_values(mesh, 'sgs_sediment', 0.0, count)
    if not any(abs(sed) > 1e-9 for sed in sediment):
        sediment = [_clamp((1.0 - s) * f * (0.45 + (1.0 - h) * 0.55)) for f, s, h in zip(flow, slopes, height_norm)]

    channel = _read_attr_values(mesh, 'sgs_channel', 0.0, count)
    if not any(abs(c) > 1e-9 for c in channel):
        channel = [_clamp(flow[i] * wetness[i] * (0.55 + erosion[i] * 0.45)) for i in range(count)]
    temperature = _read_attr_values(mesh, 'sgs_temperature', 0.0, count)
    if not any(abs(t) > 1e-9 for t in temperature):
        temperature = [_clamp(1.0 - height_norm[i] * 0.72 - wetness[i] * 0.12 + slopes[i] * 0.08 + aspect[i] * 0.05) for i in range(count)]
    cavity = [_clamp(normal_curvature[i] * 0.48 + (1.0 - convexity[i]) * 0.34 + (1.0 - edge_dist[i]) * 0.18) for i in range(count)]
    occlusion = [_clamp(cavity[i] * 0.7 + (1.0 - vertex_area[i]) * 0.15 + (1.0 - valence_norm[i]) * 0.15) for i in range(count)]
    thickness = [_clamp(edge_dist[i] * 0.55 + vertex_area[i] * 0.25 + (1.0 - normal_curvature[i]) * 0.20) for i in range(count)]
    stability = [_clamp(1.0 - slopes[i] * 0.44 - erosion[i] * 0.24 - (1.0 - edge_dist[i]) * 0.12 + sediment[i] * 0.12) for i in range(count)]
    habitat = [_clamp((1.0 - slopes[i]) * 0.34 + wetness[i] * 0.24 + stability[i] * 0.23 + temperature[i] * 0.11 + edge_dist[i] * 0.08) for i in range(count)]
    density = [_clamp(habitat[i] * 0.54 + (1.0 - normal_curvature[i]) * 0.18 + thickness[i] * 0.14 + sediment[i] * 0.08 + vertex_area[i] * 0.06) for i in range(count)]
    ambient = [_clamp(0.94 - occlusion[i] * 0.54 + convexity[i] * 0.08 + edge_dist[i] * 0.08) for i in range(count)]
    lod = [_clamp(density[i] * 0.50 + stability[i] * 0.20 + edge_dist[i] * 0.16 + (1.0 - slopes[i]) * 0.14) for i in range(count)]
    biome = _read_int_attr(mesh, 'sgs_biome', 0, count)
    if not any(biome):
        biome = _biome_values(height_norm, slopes, wetness, normal_curvature)

    # Region is a compact semantic class for downstream filters: 0 basin, 1 ground,
    # 2 high-density habitat, 3 exposed/steep, 4 ridge, 5 channel.
    region: list[int] = []
    for i in range(count):
        if channel[i] > 0.58 and wetness[i] > 0.45:
            region.append(5)
        elif height_norm[i] < 0.16 and wetness[i] > 0.42:
            region.append(0)
        elif slopes[i] > 0.66 or normal_curvature[i] > 0.54:
            region.append(3)
        elif height_norm[i] > 0.82:
            region.append(4)
        elif habitat[i] > 0.66:
            region.append(2)
        else:
            region.append(1)
    rng = random.Random(91357)
    random_values = [rng.random() for _ in range(count)]
    quality = [_clamp(0.22 + density[i] * 0.28 + stability[i] * 0.18 + thickness[i] * 0.12 + ambient[i] * 0.12 + (1.0 - abs(valence_norm[i] - 0.5) * 2.0) * 0.08) for i in range(count)]

    specs = [
        ('sgs_id', 'INT', list(range(count))),
        ('sgs_density', 'FLOAT', density),
        ('sgs_mask', 'FLOAT', [1.0] * count),
        ('sgs_variation', 'FLOAT', random_values),
        ('sgs_height', 'FLOAT', height_norm),
        ('sgs_slope', 'FLOAT', slopes),
        ('sgs_curvature', 'FLOAT', normal_curvature),
        ('sgs_convexity', 'FLOAT', convexity),
        ('sgs_boundary', 'FLOAT', [1.0 if i in boundary else 0.0 for i in range(count)]),
        ('sgs_edge_distance', 'FLOAT', edge_dist),
        ('sgs_valence', 'FLOAT', valence_norm),
        ('sgs_vertex_area', 'FLOAT', vertex_area),
        ('sgs_mean_edge_length', 'FLOAT', mean_edge),
        ('sgs_aspect', 'FLOAT', aspect),
        ('sgs_cavity', 'FLOAT', cavity),
        ('sgs_occlusion', 'FLOAT', occlusion),
        ('sgs_thickness', 'FLOAT', thickness),
        ('sgs_ambient', 'FLOAT', ambient),
        ('sgs_wetness', 'FLOAT', wetness),
        ('sgs_flow', 'FLOAT', flow),
        ('sgs_flow_dir', 'FLOAT_VECTOR', flow_dir),
        ('sgs_erosion', 'FLOAT', erosion),
        ('sgs_sediment', 'FLOAT', sediment),
        ('sgs_channel', 'FLOAT', channel),
        ('sgs_temperature', 'FLOAT', temperature),
        ('sgs_stability', 'FLOAT', stability),
        ('sgs_habitat_score', 'FLOAT', habitat),
        ('sgs_biome', 'INT', biome),
        ('sgs_region', 'INT', region),
        ('sgs_lod', 'FLOAT', lod),
        ('sgs_cull', 'FLOAT', [1.0 if v >= 0.08 else 0.0 for v in lod]),
        ('sgs_quality', 'FLOAT', quality),
        ('sgs_selection', 'FLOAT', _read_attr_values(mesh, 'sgs_selection', 1.0, count)),
    ]
    written: list[str] = []
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        written.extend(_write_v5_analysis_attributes(obj, neighbors, boundary, heights, slopes, normal_curvature, convexity, edge_dist, wetness, flow, erosion, sediment, density, lod))
    except Exception:
        pass
    try:
        obj[node_factory.GENERATED_FLAG] = True
        obj['sgs_standard_attributes'] = ','.join(written)
        obj['sgs_attribute_precision'] = 'v5_dense_topology_habitat_flow_quality'
        obj['sgs_quality_mean'] = _safe_mean(quality)
    except Exception:
        pass
    return written


def _write_v5_analysis_attributes(
        obj,
        neighbors: list[set[int]],
        boundary: set[int],
        heights: list[float],
        slopes: list[float],
        curvature: list[float],
        convexity: list[float],
        edge_dist: list[float],
        wetness: list[float],
        flow: list[float],
        erosion: list[float],
        sediment: list[float],
        density: list[float],
        lod: list[float]) -> list[str]:
    """Write v5 high-precision analysis attributes without disturbing authored data."""
    mesh = getattr(obj, 'data', None)
    count = _mesh_vertex_count(mesh)
    if mesh is None or count <= 0:
        return []
    try:
        normals = [_to_tuple(v.normal) for v in mesh.vertices]
    except Exception:
        normals = [(0.0, 0.0, 1.0)] * count
    aspect = [((math.atan2(n[1], n[0]) / math.tau) + 1.0) % 1.0 for n in normals]
    roughness: list[float] = []
    flow_dir: list[tuple[float, float, float]] = []
    for i in range(count):
        neigh = neighbors[i] if i < len(neighbors) else set()
        if not neigh:
            roughness.append(0.0)
            flow_dir.append((0.0, 0.0, 0.0))
            continue
        avg_slope = sum(slopes[j] for j in neigh) / max(1, len(neigh))
        avg_h = sum(heights[j] for j in neigh) / max(1, len(neigh))
        roughness.append(_clamp(abs(slopes[i] - avg_slope) * 1.8 + curvature[i] * 0.75 + abs(heights[i] - avg_h) * 0.35))
        best = min(neigh, key=lambda j: heights[j])
        try:
            flow_dir.append(_v_norm(_v_sub(_to_tuple(mesh.vertices[best].co), _to_tuple(mesh.vertices[i].co)), (0.0, 0.0, 0.0)))
        except Exception:
            flow_dir.append((0.0, 0.0, 0.0))
    existing_channel = _read_attr_values(mesh, 'sgs_channel', 0.0, count)
    if any(existing_channel):
        channel = existing_channel
    else:
        channel = [_clamp(flow[i] * (0.72 + slopes[i] * 0.55) + erosion[i] * 0.35 - sediment[i] * 0.18) for i in range(count)]
    existing_deposition = _read_attr_values(mesh, 'sgs_deposition', 0.0, count)
    if any(existing_deposition):
        deposition = existing_deposition
    else:
        deposition = [_clamp(sediment[i] * 0.82 + wetness[i] * (1.0 - slopes[i]) * 0.32) for i in range(count)]
    stability = [_clamp((1.0 - slopes[i]) * 0.46 + edge_dist[i] * 0.18 + (1.0 - erosion[i]) * 0.22 + (1.0 - roughness[i]) * 0.14) for i in range(count)]
    accessibility = [_clamp(edge_dist[i] * 0.35 + (1.0 - slopes[i]) * 0.38 + density[i] * 0.20 + lod[i] * 0.07) for i in range(count)]
    visibility = [_clamp(lod[i] * 0.44 + (1.0 - curvature[i]) * 0.22 + edge_dist[i] * 0.17 + stability[i] * 0.17) for i in range(count)]
    habitat_score = [_clamp(density[i] * 0.38 + wetness[i] * 0.18 + stability[i] * 0.26 + (1.0 - roughness[i]) * 0.18) for i in range(count)]
    specs = [
        ('sgs_aspect', 'FLOAT', aspect),
        ('sgs_roughness', 'FLOAT', roughness),
        ('sgs_accessibility', 'FLOAT', accessibility),
        ('sgs_channel', 'FLOAT', channel),
        ('sgs_deposition', 'FLOAT', deposition),
        ('sgs_stability', 'FLOAT', stability),
        ('sgs_visibility_score', 'FLOAT', visibility),
        ('sgs_habitat_score', 'FLOAT', habitat_score),
        ('sgs_flow_direction', 'FLOAT_VECTOR', flow_dir),
    ]
    written: list[str] = []
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    return written


# -----------------------------------------------------------------------------
# Selection expression engine
# -----------------------------------------------------------------------------


_ATTR_ALIASES = {
    'id': 'sgs_id', 'density': 'sgs_density', 'mask': 'sgs_mask', 'variation': 'sgs_variation',
    'random': 'sgs_variation', 'height': 'sgs_height', 'slope': 'sgs_slope', 'curvature': 'sgs_curvature',
    'convexity': 'sgs_convexity', 'boundary': 'sgs_boundary', 'edge': 'sgs_edge_distance', 'edge_distance': 'sgs_edge_distance',
    'ambient': 'sgs_ambient', 'wetness': 'sgs_wetness', 'flow': 'sgs_flow', 'erosion': 'sgs_erosion',
    'sediment': 'sgs_sediment', 'biome': 'sgs_biome', 'lod': 'sgs_lod', 'cull': 'sgs_cull', 'selection': 'sgs_selection',
    'aspect': 'sgs_aspect', 'cavity': 'sgs_cavity', 'occlusion': 'sgs_occlusion', 'thickness': 'sgs_thickness',
    'temperature': 'sgs_temperature', 'stability': 'sgs_stability', 'channel': 'sgs_channel', 'habitat': 'sgs_habitat_score',
    'habitat_score': 'sgs_habitat_score', 'region': 'sgs_region', 'quality': 'sgs_quality', 'vertex_area': 'sgs_vertex_area',
    'mean_edge': 'sgs_mean_edge_length', 'edge_length': 'sgs_mean_edge_length', 'piece': 'sgs_piece_id', 'piece_id': 'sgs_piece_id', 'scale': 'sgs_scale',
    'aspect': 'sgs_aspect', 'roughness': 'sgs_roughness', 'accessibility': 'sgs_accessibility',
    'channel': 'sgs_channel', 'deposition': 'sgs_deposition', 'deposit': 'sgs_deposition',
    'stability': 'sgs_stability', 'visibility': 'sgs_visibility_score', 'habitat': 'sgs_habitat_score',
    'flow_direction': 'sgs_flow_direction', 'noise': 'sgs_variation',
}


def _attr_name_from_token(name: str) -> str:
    key = str(name or '').strip().lower()
    return _ATTR_ALIASES.get(key, key if key.startswith('sgs_') else f'sgs_{key}')


def _parse_index_token(token: str, count: int) -> set[int]:
    token = token.strip().lower()
    if not token:
        return set()
    if token in {'all', 'default', '*'}:
        return set(range(count))
    if token in {'none', 'empty'}:
        return set()
    if token == 'even':
        return set(range(0, count, 2))
    if token == 'odd':
        return set(range(1, count, 2))
    if token == 'active':
        return {0} if count else set()
    token = token.replace(':', '-') if re.fullmatch(r'-?\d*:-?\d*', token) else token
    if re.fullmatch(r'-?\d+\s*-\s*-?\d+', token):
        parts = re.split(r'\s*-\s*', token, maxsplit=1)
        try:
            start = int(parts[0])
            end = int(parts[1])
        except Exception:
            return set()
        if start < 0:
            start = count + start
        if end < 0:
            end = count + end
        lo, hi = sorted((max(0, start), min(count - 1, end)))
        return set(range(lo, hi + 1))
    try:
        idx = int(token)
        if idx < 0:
            idx = count + idx
        if 0 <= idx < count:
            return {idx}
    except Exception:
        pass
    return set()


def _compare_values(values: list[float], operator: str, rhs: float) -> set[int]:
    result: set[int] = set()
    for i, value in enumerate(values):
        if operator in {'=', '=='} and abs(value - rhs) <= 1e-6:
            result.add(i)
        elif operator == '!=' and abs(value - rhs) > 1e-6:
            result.add(i)
        elif operator == '>' and value > rhs:
            result.add(i)
        elif operator == '>=' and value >= rhs:
            result.add(i)
        elif operator == '<' and value < rhs:
            result.add(i)
        elif operator == '<=' and value <= rhs:
            result.add(i)
    return result


def _select_percentile(values: list[float], ratio: float, highest: bool) -> set[int]:
    if not values:
        return set()
    ratio = _clamp(ratio, 0.0, 1.0)
    n = max(1, int(round(len(values) * ratio)))
    ranked = sorted(range(len(values)), key=lambda i: values[i], reverse=highest)
    return set(ranked[:n])



def _selection_function_token(mesh, token: str, count: int) -> set[int] | None:
    token = token.strip().lower()
    fn = re.fullmatch(r'(between|near|top|bottom|highest|lowest)\(([^)]*)\)', token)
    if fn:
        name = fn.group(1)
        args = [a.strip() for a in fn.group(2).split(',') if a.strip()]
        if len(args) >= 2:
            attr = _attr_name_from_token(args[0])
            values = _read_attr_values(mesh, attr, 0.0, count)
            if name == 'between' and len(args) >= 3:
                lo = _safe_float(args[1], 0.0)
                hi = _safe_float(args[2], 1.0)
                if lo > hi:
                    lo, hi = hi, lo
                return {i for i, value in enumerate(values) if lo <= value <= hi}
            if name == 'near' and len(args) >= 3:
                center = _safe_float(args[1], 0.0)
                tolerance = abs(_safe_float(args[2], 0.05))
                return {i for i, value in enumerate(values) if abs(value - center) <= tolerance}
            if name in {'top', 'highest', 'bottom', 'lowest'}:
                ratio = _safe_float(args[1], 0.25)
                return _select_percentile(values, ratio, highest=name in {'top', 'highest'})
    in_match = re.fullmatch(r'([a-zA-Z0-9_]+)\s+(in|notin)\s*\(?\s*([-,.0-9\s|]+)\s*\)?', token)
    if in_match:
        attr = _attr_name_from_token(in_match.group(1))
        values = _read_attr_values(mesh, attr, 0.0, count)
        wanted = {_safe_int(v, -999999) for v in re.split(r'[|,\s]+', in_match.group(3)) if v.strip()}
        selected = {i for i, value in enumerate(values) if int(round(value)) in wanted}
        if in_match.group(2) == 'notin':
            selected = set(range(count)) - selected
        return selected
    return None


def _selection_token(mesh, token: str, count: int) -> set[int]:
    token = token.strip().lower()
    if not token:
        return set()
    negated = False
    if token.startswith('!'):
        negated = True
        token = token[1:].strip()
    if token.startswith('not:'):
        negated = True
        token = token.split(':', 1)[1].strip()
    function_result = _selection_function_token(mesh, token, count)
    if function_result is not None:
        result = function_result
    elif token == 'boundary':
        result = {i for i, v in enumerate(_read_attr_values(mesh, 'sgs_boundary', 0.0, count)) if v > 0.5}
    elif token == 'interior':
        result = {i for i, v in enumerate(_read_attr_values(mesh, 'sgs_boundary', 0.0, count)) if v <= 0.5}
    elif token in {'visible', 'kept'}:
        result = {i for i, v in enumerate(_read_attr_values(mesh, 'sgs_cull', 1.0, count)) if v > 0.5}
    else:
        high_low = re.fullmatch(r'(highest|lowest)\(([^,]+),\s*([0-9.]+)\)', token)
        if high_low:
            attr_name = _attr_name_from_token(high_low.group(2))
            values = _read_attr_values(mesh, attr_name, 0.0, count)
            result = _select_percentile(values, float(high_low.group(3)), highest=high_low.group(1) == 'highest')
        else:
            range_match = re.fullmatch(r'([a-zA-Z0-9_]+)\s*:\s*([-+0-9.]+)\s*-\s*([-+0-9.]+)', token)
            if range_match:
                attr_name = _attr_name_from_token(range_match.group(1))
                lo = float(range_match.group(2))
                hi = float(range_match.group(3))
                if lo > hi:
                    lo, hi = hi, lo
                values = _read_attr_values(mesh, attr_name, 0.0, count)
                result = {i for i, value in enumerate(values) if lo <= value <= hi}
            else:
                comp = re.fullmatch(r'([a-zA-Z0-9_]+)\s*(<=|>=|==|!=|=|<|>)\s*([-+0-9.]+)', token)
                if comp:
                    attr_name = _attr_name_from_token(comp.group(1))
                    values = _read_attr_values(mesh, attr_name, 0.0, count)
                    result = _compare_values(values, comp.group(2), float(comp.group(3)))
                else:
                    result = _parse_index_token(token, count)
    if negated:
        result = set(range(count)) - result
    return result


def _split_top_level(expression: str, separators: tuple[str, ...]) -> list[str]:
    """Split expression by one-character separators outside parentheses."""
    result: list[str] = []
    start = 0
    depth = 0
    for i, char in enumerate(expression):
        if char == '(':
            depth += 1
        elif char == ')':
            depth = max(0, depth - 1)
        elif depth == 0 and char in separators:
            part = expression[start:i].strip()
            if part:
                result.append(part)
            start = i + 1
    tail = expression[start:].strip()
    if tail:
        result.append(tail)
    return result


def apply_selection_string(obj, expression: str) -> int:
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    mesh = getattr(obj, 'data', None)
    count = _mesh_vertex_count(mesh) if mesh else 0
    if count <= 0:
        return 0
    ensure_standard_attributes(obj)
    expr = str(expression or 'all').strip().lower()
    invert = False
    if expr.startswith('invert:') or expr.startswith('not:'):
        invert = True
        expr = expr.split(':', 1)[1]
    # Union clauses: comma, pipe, or textual OR. Commas inside functions such as highest(density,0.25) are preserved.
    expr = re.sub(r'\s+or\s+', '|', expr)
    union_clauses = _split_top_level(expr, (',', '|'))
    selected: set[int] = set()
    for clause in union_clauses or ['all']:
        subtractors = [p.strip() for p in re.split(r'\s+except\s+', clause) if p.strip()]
        main = subtractors[0]
        main = re.sub(r'\s+and\s+', '&', main)
        parts = _split_top_level(main, ('&', '+'))
        current = set(range(count)) if parts else set()
        for part in parts:
            current &= _selection_token(mesh, part, count)
        for subtractor in subtractors[1:]:
            current -= _selection_token(mesh, subtractor, count)
        selected |= current
    if invert:
        selected = set(range(count)) - selected
    values = [1.0 if i in selected else 0.0 for i in range(count)]
    _write_attr_values(mesh, 'sgs_selection', 'FLOAT', values)
    try:
        group = obj.vertex_groups.get('SGS Selection') or obj.vertex_groups.new(name='SGS Selection')
        for i, value in enumerate(values):
            group.add([i], value, 'REPLACE')
    except Exception:
        pass
    try:
        obj['sgs_selection_string'] = str(expression or '')
        obj['sgs_selection_count'] = len(selected)
    except Exception:
        pass
    return len(selected)


# -----------------------------------------------------------------------------
# Terrain generation with erosion and habitat attributes
# -----------------------------------------------------------------------------


def _terrain_index(x: int, y: int, res: int) -> int:
    return y * res + x


def _terrain_neighbors4(x: int, y: int, res: int) -> Iterable[tuple[int, int]]:
    if x > 0:
        yield x - 1, y
    if x < res - 1:
        yield x + 1, y
    if y > 0:
        yield x, y - 1
    if y < res - 1:
        yield x, y + 1



def _height_bilinear(h: list[float], res: int, x: float, y: float) -> float:
    x = _clamp(x, 0.0, float(res - 1))
    y = _clamp(y, 0.0, float(res - 1))
    x0 = int(math.floor(x)); y0 = int(math.floor(y))
    x1 = min(res - 1, x0 + 1); y1 = min(res - 1, y0 + 1)
    tx = x - x0; ty = y - y0
    a = h[_terrain_index(x0, y0, res)]
    b = h[_terrain_index(x1, y0, res)]
    c = h[_terrain_index(x0, y1, res)]
    d = h[_terrain_index(x1, y1, res)]
    return (a * (1.0 - tx) + b * tx) * (1.0 - ty) + (c * (1.0 - tx) + d * tx) * ty


def _terrain_gradient(h: list[float], res: int, x: float, y: float) -> tuple[float, float]:
    eps = 0.75
    gx = _height_bilinear(h, res, x + eps, y) - _height_bilinear(h, res, x - eps, y)
    gy = _height_bilinear(h, res, x, y + eps) - _height_bilinear(h, res, x, y - eps)
    return gx / (eps * 2.0), gy / (eps * 2.0)


def _add_height_bilinear(h: list[float], res: int, x: float, y: float, amount: float) -> None:
    x = _clamp(x, 0.0, float(res - 1))
    y = _clamp(y, 0.0, float(res - 1))
    x0 = int(math.floor(x)); y0 = int(math.floor(y))
    x1 = min(res - 1, x0 + 1); y1 = min(res - 1, y0 + 1)
    tx = x - x0; ty = y - y0
    weights = [((1.0 - tx) * (1.0 - ty), x0, y0), (tx * (1.0 - ty), x1, y0), ((1.0 - tx) * ty, x0, y1), (tx * ty, x1, y1)]
    for w, xi, yi in weights:
        h[_terrain_index(xi, yi, res)] += amount * w


def _apply_hydraulic_droplets(h: list[float], res: int, size: float, height: float, seed: int, droplets: int) -> list[float]:
    """Deterministic, bounded hydraulic erosion approximation.

    The algorithm is intentionally conservative: it carves channels and deposits
    material without trying to become a full simulator, keeping it safe for an
    add-on operator and small enough for interactive terrain blockouts.
    """
    droplets = max(0, min(40000, int(droplets)))
    if droplets <= 0 or res < 4 or height <= 0.0:
        return list(h)
    rng = random.Random(seed + 56093)
    out = list(h)
    capacity_factor = max(0.04, height * 2.2)
    min_capacity = max(1e-5, height * 0.002)
    erode_rate = 0.030
    deposit_rate = 0.12
    evaporation = 0.030
    inertia = 0.28
    max_steps = max(12, min(72, res // 2))
    for _d in range(droplets):
        x = rng.uniform(1.0, res - 2.0)
        y = rng.uniform(1.0, res - 2.0)
        dx = dy = 0.0
        speed = 1.0
        water = 1.0
        sediment = 0.0
        for _step in range(max_steps):
            old_height = _height_bilinear(out, res, x, y)
            gx, gy = _terrain_gradient(out, res, x, y)
            dx = dx * inertia - gx * (1.0 - inertia)
            dy = dy * inertia - gy * (1.0 - inertia)
            length = math.sqrt(dx * dx + dy * dy)
            if length <= 1e-9:
                angle = rng.random() * math.tau
                dx, dy = math.cos(angle), math.sin(angle)
            else:
                dx, dy = dx / length, dy / length
            nx = x + dx
            ny = y + dy
            if nx < 0.5 or nx > res - 1.5 or ny < 0.5 or ny > res - 1.5:
                break
            new_height = _height_bilinear(out, res, nx, ny)
            delta_h = new_height - old_height
            capacity = max(min_capacity, -delta_h * speed * water * capacity_factor)
            if sediment > capacity or delta_h > 0.0:
                amount = (sediment - capacity) * deposit_rate if delta_h <= 0.0 else min(delta_h, sediment)
                if amount > 0.0:
                    _add_height_bilinear(out, res, x, y, amount)
                    sediment -= amount
            else:
                amount = min((capacity - sediment) * erode_rate, height * 0.006)
                if amount > 0.0:
                    _add_height_bilinear(out, res, x, y, -amount)
                    sediment += amount
            speed = math.sqrt(max(0.01, speed * speed - delta_h * 0.12))
            water *= (1.0 - evaporation)
            if water <= 0.05:
                break
            x, y = nx, ny
    return out


def _terrain_d8_flow(h: list[float], wetness: list[float], res: int) -> tuple[list[float], list[tuple[float, float, float]], list[float]]:
    flow = [0.03 + wetness[i] * 0.07 for i in range(len(h))]
    flow_dir = [(0.0, 0.0, 0.0) for _ in h]
    receiver = list(range(len(h)))
    offsets = [(-1, -1), (0, -1), (1, -1), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1)]
    for y in range(res):
        for x in range(res):
            i = _terrain_index(x, y, res)
            best = i
            best_drop = 0.0
            for ox, oy in offsets:
                nx = x + ox; ny = y + oy
                if nx < 0 or nx >= res or ny < 0 or ny >= res:
                    continue
                j = _terrain_index(nx, ny, res)
                dist = math.sqrt(float(ox * ox + oy * oy))
                drop = (h[i] - h[j]) / max(1e-6, dist)
                if drop > best_drop:
                    best_drop = drop
                    best = j
                    flow_dir[i] = _v_norm((float(ox), float(oy), 0.0), (0.0, 0.0, 0.0))
            receiver[i] = best
    for i in sorted(range(len(h)), key=lambda k: h[k], reverse=True):
        j = receiver[i]
        if j != i:
            flow[j] += flow[i] * 0.86
    flow_norm = _normalize_values([math.log1p(v) for v in flow])
    return flow_norm, flow_dir, [1.0 if receiver[i] != i else 0.0 for i in range(len(h))]

def _terrain_maps(res: int, size: float, height: float, seed: int, iterations: int, hydraulic_droplets: int = 0) -> dict[str, list[Any]]:
    coords: list[tuple[float, float]] = []
    h: list[float] = []
    scale = max(0.001, size)
    for y in range(res):
        fy = (y / max(1, res - 1) - 0.5) * size
        for x in range(res):
            fx = (x / max(1, res - 1) - 0.5) * size
            nx = fx / scale
            ny = fy / scale
            continent = _fbm2(nx * 1.18 + 12.7, ny * 1.18 - 3.1, seed, 7)
            ridge = _ridge2(nx * 4.8 - 1.7, ny * 4.8 + 2.4, seed + 41)
            terrace = math.floor((_fbm2(nx * 2.2 + 8.0, ny * 2.2 - 6.0, seed + 509, 4) * 0.5 + 0.5) * 8.0) / 8.0
            detail = _fbm2(nx * 15.5, ny * 15.5, seed + 97, 4)
            basin = -0.24 * math.exp(-((nx * 1.75) ** 2 + (ny * 1.75) ** 2))
            value = continent * 0.57 + ridge * 0.24 + terrace * 0.09 + detail * 0.10 + basin
            h.append(value * height)
            coords.append((fx, fy))

    # Thermal relaxation: bounded talus transport removes numerical spikes while retaining silhouettes.
    iterations = max(0, min(120, int(iterations)))
    talus = max(1e-5, height * 0.017)
    for _step in range(iterations):
        delta = [0.0] * len(h)
        for y in range(res):
            for x in range(res):
                i = _terrain_index(x, y, res)
                hi = h[i]
                lower: list[tuple[int, float]] = []
                for nx, ny in _terrain_neighbors4(x, y, res):
                    j = _terrain_index(nx, ny, res)
                    diff = hi - h[j]
                    if diff > talus:
                        lower.append((j, diff))
                if not lower:
                    continue
                transfer = min(height * 0.014, sum(d for _j, d in lower) * 0.020)
                delta[i] -= transfer
                denom = max(1e-9, sum(d for _j, d in lower))
                for j, diff in lower:
                    delta[j] += transfer * (diff / denom)
        h = [h[i] + delta[i] for i in range(len(h))]

    # Hydraulic droplets are optional and bounded. They add channel precision without requiring external solvers.
    h = _apply_hydraulic_droplets(h, res, size, height, seed, hydraulic_droplets)

    slope: list[float] = []
    convexity: list[float] = []
    aspect: list[float] = []
    cell = max(1e-6, size / max(1, res - 1))
    for y in range(res):
        for x in range(res):
            i = _terrain_index(x, y, res)
            left = h[_terrain_index(max(0, x - 1), y, res)]
            right = h[_terrain_index(min(res - 1, x + 1), y, res)]
            down = h[_terrain_index(x, max(0, y - 1), res)]
            up = h[_terrain_index(x, min(res - 1, y + 1), res)]
            dx = (right - left) / (cell * 2.0)
            dy = (up - down) / (cell * 2.0)
            slope.append(_clamp(math.sqrt(dx * dx + dy * dy) / max(0.001, height * 2.05)))
            aspect.append(((math.atan2(dy, dx) / math.tau) + 1.0) % 1.0)
            neigh = [h[_terrain_index(nx, ny, res)] for nx, ny in _terrain_neighbors4(x, y, res)]
            avg = sum(neigh) / max(1, len(neigh))
            convexity.append(h[i] - avg)
    height_norm = _normalize_values(h)
    wetness = [_clamp((1.0 - hn) * 0.50 + (1.0 - s) * 0.20 + _value_noise2(coords[i][0] * 0.16, coords[i][1] * 0.16, seed + 203) * 0.18 + (0.12 if hn < 0.18 else 0.0)) for i, (hn, s) in enumerate(zip(height_norm, slope))]
    flow_norm, flow_dir, downhill_mask = _terrain_d8_flow(h, wetness, res)
    erosion = [_clamp(flow_norm[i] * slope[i] * 1.55 + downhill_mask[i] * 0.05) for i in range(len(h))]
    sediment = [_clamp(flow_norm[i] * (1.0 - slope[i]) * (1.0 - height_norm[i]) * 1.42) for i in range(len(h))]
    channel = [_clamp(flow_norm[i] * wetness[i] * (0.55 + erosion[i] * 0.45)) for i in range(len(h))]
    # Post-erosion shape pass: channels cut, stable lowlands receive deposits.
    h2 = [h[i] - erosion[i] * height * 0.075 - channel[i] * height * 0.030 + sediment[i] * height * 0.040 for i in range(len(h))]
    height_norm2 = _normalize_values(h2)
    convex_norm = _normalize_values(convexity)
    temperature = [_clamp(1.0 - height_norm2[i] * 0.70 - wetness[i] * 0.10 + slope[i] * 0.08 + aspect[i] * 0.04) for i in range(len(h))]
    stability = [_clamp(1.0 - slope[i] * 0.48 - erosion[i] * 0.20 + sediment[i] * 0.12) for i in range(len(h))]
    habitat = [_clamp((1.0 - slope[i]) * 0.33 + wetness[i] * 0.25 + temperature[i] * 0.16 + stability[i] * 0.18 + channel[i] * 0.08) for i in range(len(h))]
    biome = _biome_values(height_norm2, slope, wetness, convex_norm)
    return {
        'height': h2,
        'height_norm': height_norm2,
        'slope': slope,
        'convexity': convex_norm,
        'aspect': aspect,
        'wetness': wetness,
        'flow': flow_norm,
        'flow_dir': flow_dir,
        'erosion': erosion,
        'sediment': sediment,
        'channel': channel,
        'temperature': temperature,
        'stability': stability,
        'habitat_score': habitat,
        'biome': [float(b) for b in biome],
        'quality': [_clamp(habitat[i] * 0.45 + stability[i] * 0.28 + (1.0 - slope[i]) * 0.17 + flow_norm[i] * 0.10) for i in range(len(h))],
    }



def _terrain_maps_v5_initial_transport(res: int, size: float, height: float, seed: int, iterations: int, settings=None) -> dict[str, list[Any]]:
    """Deprecated initial transport helper retained for file-local compatibility; the final overdrive v5 solver below is used at runtime."""
    maps = _terrain_maps(res, size, height, seed, iterations)
    h = list(maps.get('height') or [])
    if not h:
        return maps
    hydraulic_iterations = max(0, min(120, int(getattr(settings, 'terrain_hydraulic_iterations', 18) or 18)))
    channel_strength = max(0.0, min(4.0, float(getattr(settings, 'terrain_channel_strength', 0.65) or 0.65)))
    water = [0.0] * len(h)
    sediment = [float(v) for v in maps.get('sediment', [0.0] * len(h))]
    rainfall = [0.012 + (1.0 - float(maps['height_norm'][i])) * 0.018 + _value_noise2(i % res, i // res, seed + 811) * 0.008 for i in range(len(h))]
    for _step in range(hydraulic_iterations):
        delta_h = [0.0] * len(h)
        next_water = [r * 0.35 for r in rainfall]
        order = sorted(range(len(h)), key=lambda i: h[i] + water[i], reverse=True)
        for i in order:
            x = i % res
            y = i // res
            current_level = h[i] + water[i]
            lower: list[tuple[int, float]] = []
            for nx, ny in _terrain_neighbors4(x, y, res):
                j = _terrain_index(nx, ny, res)
                diff = current_level - (h[j] + water[j])
                if diff > 0.0:
                    lower.append((j, diff))
            water[i] += rainfall[i]
            if not lower:
                sediment[i] += water[i] * 0.012
                water[i] *= 0.72
                continue
            total_diff = sum(d for _j, d in lower)
            transport = min(water[i] * 0.72, total_diff * 0.18)
            capacity = transport * (0.45 + float(maps['slope'][i]) * 1.8) * channel_strength
            erode = max(0.0, capacity - sediment[i]) * 0.035
            deposit = max(0.0, sediment[i] - capacity) * 0.018
            delta_h[i] -= erode
            delta_h[i] += deposit
            sediment[i] += erode - deposit
            water[i] -= transport
            for j, diff in lower:
                share = diff / max(1e-9, total_diff)
                next_water[j] += transport * share
                sediment[j] += sediment[i] * share * 0.035
        h = [h[i] + delta_h[i] * height for i in range(len(h))]
        water = [next_water[i] * 0.82 for i in range(len(h))]
    # Recalculate differential maps after transport.
    slope: list[float] = []
    roughness: list[float] = []
    flow_dir: list[tuple[float, float, float]] = []
    step = max(1e-6, size / max(1, res - 1))
    flow_acc = [0.02 + water[i] + rainfall[i] for i in range(len(h))]
    order = sorted(range(len(h)), key=lambda i: h[i], reverse=True)
    for i in order:
        x = i % res
        y = i // res
        best = i
        best_drop = 0.0
        for nx, ny in _terrain_neighbors4(x, y, res):
            j = _terrain_index(nx, ny, res)
            drop = h[i] - h[j]
            if drop > best_drop:
                best = j
                best_drop = drop
        if best != i:
            flow_acc[best] += flow_acc[i] * 0.86
    flow_norm = _normalize_values([math.log1p(max(0.0, v)) for v in flow_acc])
    height_norm = _normalize_values(h)
    for y in range(res):
        for x in range(res):
            i = _terrain_index(x, y, res)
            left = h[_terrain_index(max(0, x - 1), y, res)]
            right = h[_terrain_index(min(res - 1, x + 1), y, res)]
            down = h[_terrain_index(x, max(0, y - 1), res)]
            up = h[_terrain_index(x, min(res - 1, y + 1), res)]
            dx = (right - left) / (step * 2.0)
            dy = (up - down) / (step * 2.0)
            slope.append(_clamp(math.sqrt(dx * dx + dy * dy) / max(0.001, height * 2.1)))
            flow_dir.append(_v_norm((-dx, -dy, 0.0), (0.0, 0.0, 0.0)))
            neigh = [h[_terrain_index(nx, ny, res)] for nx, ny in _terrain_neighbors4(x, y, res)]
            avg = sum(neigh) / max(1, len(neigh))
            roughness.append(_clamp(abs(h[i] - avg) / max(1e-6, height) * 3.0 + slope[-1] * 0.25))
    sediment_norm = _normalize_values(sediment)
    erosion = [_clamp(flow_norm[i] * slope[i] * (0.95 + channel_strength * 0.28)) for i in range(len(h))]
    channel = [_clamp(flow_norm[i] * (0.72 + slope[i] * 0.58) - sediment_norm[i] * 0.16) for i in range(len(h))]
    deposition = [_clamp(sediment_norm[i] * 0.86 + flow_norm[i] * (1.0 - slope[i]) * 0.24) for i in range(len(h))]
    wetness = [_clamp(float(maps['wetness'][i]) * 0.45 + flow_norm[i] * 0.38 + deposition[i] * 0.17) for i in range(len(h))]
    convexity = _normalize_values([h[i] - (sum(h[_terrain_index(nx, ny, res)] for nx, ny in _terrain_neighbors4(i % res, i // res, res)) / max(1, len(list(_terrain_neighbors4(i % res, i // res, res))))) for i in range(len(h))])
    stability = [_clamp((1.0 - slope[i]) * 0.46 + (1.0 - erosion[i]) * 0.24 + deposition[i] * 0.18 + (1.0 - roughness[i]) * 0.12) for i in range(len(h))]
    biome = _biome_values(height_norm, slope, wetness, convexity)
    maps.update({
        'height': h,
        'height_norm': height_norm,
        'slope': slope,
        'convexity': convexity,
        'wetness': wetness,
        'flow': flow_norm,
        'erosion': erosion,
        'sediment': sediment_norm,
        'biome': [float(b) for b in biome],
        'flow_direction': flow_dir,
        'channel': channel,
        'deposition': deposition,
        'roughness': roughness,
        'stability': stability,
    })
    return maps


def create_terrain(context=None, settings=None):
    ctx = context or bpy.context
    res = max(2, min(512, int(getattr(settings, 'terrain_resolution', 96) or 96)))
    size = float(getattr(settings, 'terrain_size', 12.0) or 12.0)
    height = float(getattr(settings, 'terrain_height', 1.5) or 1.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    iterations = int(getattr(settings, 'terrain_erosion_iterations', 12) or 12)
    droplets = int(getattr(settings, 'terrain_hydraulic_droplets', 0) or 0)
    maps = _terrain_maps_v5_initial_transport(res, size, height, seed, iterations, settings)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    for y in range(res):
        fy = (y / (res - 1) - 0.5) * size if res > 1 else 0.0
        for x in range(res):
            fx = (x / (res - 1) - 0.5) * size if res > 1 else 0.0
            i = _terrain_index(x, y, res)
            verts.append((fx, fy, maps['height'][i]))
    for y in range(res - 1):
        for x in range(res - 1):
            a = y * res + x
            faces.append((a, a + 1, a + 1 + res, a + res))
    mesh = bpy.data.meshes.new('SGS_Precision_Heightfield_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Precision Heightfield Terrain', '地形'), mesh)
    _link_object(obj, ctx)
    _write_attr_values(mesh, 'sgs_height', 'FLOAT', maps['height_norm'])
    _write_attr_values(mesh, 'sgs_slope', 'FLOAT', maps['slope'])
    _write_attr_values(mesh, 'sgs_convexity', 'FLOAT', maps['convexity'])
    _write_attr_values(mesh, 'sgs_aspect', 'FLOAT', maps['aspect'])
    _write_attr_values(mesh, 'sgs_wetness', 'FLOAT', maps['wetness'])
    _write_attr_values(mesh, 'sgs_flow', 'FLOAT', maps['flow'])
    _write_attr_values(mesh, 'sgs_flow_dir', 'FLOAT_VECTOR', maps['flow_dir'])
    _write_attr_values(mesh, 'sgs_erosion', 'FLOAT', maps['erosion'])
    _write_attr_values(mesh, 'sgs_sediment', 'FLOAT', maps['sediment'])
    _write_attr_values(mesh, 'sgs_channel', 'FLOAT', maps['channel'])
    _write_attr_values(mesh, 'sgs_temperature', 'FLOAT', maps['temperature'])
    _write_attr_values(mesh, 'sgs_stability', 'FLOAT', maps['stability'])
    _write_attr_values(mesh, 'sgs_habitat_score', 'FLOAT', maps['habitat_score'])
    _write_attr_values(mesh, 'sgs_quality', 'FLOAT', maps['quality'])
    _write_attr_values(mesh, 'sgs_biome', 'INT', [int(v) for v in maps['biome']])
    if 'flow_direction' in maps:
        _write_attr_values(mesh, 'sgs_flow_direction', 'FLOAT_VECTOR', maps['flow_direction'])
    for _name in ('channel', 'deposition', 'roughness', 'stability'):
        if _name in maps:
            _write_attr_values(mesh, f'sgs_{_name}', 'FLOAT', maps[_name])
    attrs = ensure_standard_attributes(obj)
    try:
        obj['sgs_builder'] = 'precision_heightfield_terrain'
        obj['sgs_attribute_count'] = len(attrs)
        obj['sgs_erosion_iterations'] = iterations
        obj['sgs_hydraulic_droplets'] = droplets
        obj['sgs_algorithm'] = 'deterministic_fbm_thermal_hydraulic_d8_habitat_v5'
    except Exception:
        pass
    return obj


# -----------------------------------------------------------------------------
# Surface point distribution
# -----------------------------------------------------------------------------


def _world_vertex(obj, index: int):
    co = obj.data.vertices[index].co.copy()
    try:
        co = obj.matrix_world @ co
    except Exception:
        pass
    return _to_tuple(co)


def _poly_frame(obj, poly) -> tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float], tuple[float, float, float], float]:
    verts = [_world_vertex(obj, int(i)) for i in poly.vertices]
    center = (sum(v[0] for v in verts) / max(1, len(verts)), sum(v[1] for v in verts) / max(1, len(verts)), sum(v[2] for v in verts) / max(1, len(verts)))
    normal = (0.0, 0.0, 1.0)
    area = 0.0
    if len(verts) >= 3:
        acc = (0.0, 0.0, 0.0)
        for i in range(1, len(verts) - 1):
            cross = _v_cross(_v_sub(verts[i], verts[0]), _v_sub(verts[i + 1], verts[0]))
            acc = _v_add(acc, cross)
            area += _v_len(cross) * 0.5
        normal = _v_norm(acc)
    tangent = _v_norm(_v_sub(verts[1], verts[0]) if len(verts) > 1 else (1.0, 0.0, 0.0), (1.0, 0.0, 0.0))
    bitangent = _v_norm(_v_cross(normal, tangent), (0.0, 1.0, 0.0))
    tangent = _v_norm(_v_cross(bitangent, normal), tangent)
    return center, tangent, bitangent, normal, area


def _sample_triangle(a, b, c, rng: random.Random):
    r1 = math.sqrt(rng.random())
    r2 = rng.random()
    return _v_add(_v_add(_v_mul(a, 1.0 - r1), _v_mul(b, r1 * (1.0 - r2))), _v_mul(c, r1 * r2))


def _sample_poly(obj, poly, rng: random.Random):
    verts = [_world_vertex(obj, int(i)) for i in poly.vertices]
    if len(verts) < 3:
        return verts[0] if verts else (0.0, 0.0, 0.0)
    weights: list[float] = []
    total = 0.0
    for i in range(1, len(verts) - 1):
        area = _v_len(_v_cross(_v_sub(verts[i], verts[0]), _v_sub(verts[i + 1], verts[0]))) * 0.5
        total += area
        weights.append(total)
    if total <= 1e-12:
        return verts[0]
    pick = rng.random() * total
    tri = min(len(weights) - 1, bisect.bisect_left(weights, pick)) + 1
    return _sample_triangle(verts[0], verts[tri], verts[tri + 1], rng)



def _halton(index: int, base: int) -> float:
    result = 0.0
    f = 1.0 / float(base)
    i = max(1, int(index))
    while i > 0:
        result += f * (i % base)
        i //= base
        f /= float(base)
    return result


def _sample_poly_low_discrepancy(obj, poly, rng: random.Random, sequence_index: int):
    verts = [_world_vertex(obj, int(i)) for i in poly.vertices]
    if len(verts) < 3:
        return verts[0] if verts else (0.0, 0.0, 0.0)
    cumulative: list[float] = []
    total = 0.0
    for i in range(1, len(verts) - 1):
        area = _v_len(_v_cross(_v_sub(verts[i], verts[0]), _v_sub(verts[i + 1], verts[0]))) * 0.5
        total += area
        cumulative.append(total)
    if total <= 1e-12:
        return verts[0]
    # Cranley-Patterson rotation keeps the low-discrepancy pattern deterministic while avoiding visible regular bands.
    r_tri = ( _halton(sequence_index + 1, 5) + rng.random() * 0.37 ) % 1.0
    tri = min(len(cumulative) - 1, bisect.bisect_left(cumulative, r_tri * total)) + 1
    r1 = (_halton(sequence_index + 1, 2) + rng.random() * 0.19) % 1.0
    r2 = (_halton(sequence_index + 1, 3) + rng.random() * 0.23) % 1.0
    sr1 = math.sqrt(r1)
    return _v_add(_v_add(_v_mul(verts[0], 1.0 - sr1), _v_mul(verts[tri], sr1 * (1.0 - r2))), _v_mul(verts[tri + 1], sr1 * r2))


def _avg_poly_attr(mesh, poly, values: list[float], default: float) -> float:
    try:
        ids = list(poly.vertices)
        return sum(values[int(i)] for i in ids) / max(1, len(ids))
    except Exception:
        return default


def _poisson_accept(point, cell_map: dict[tuple[int, int, int], list[int]], points: list[tuple[float, float, float]], spacing: float) -> bool:
    if spacing <= 1e-9:
        return True
    cell_size = spacing
    key = (math.floor(point[0] / cell_size), math.floor(point[1] / cell_size), math.floor(point[2] / cell_size))
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                for idx in cell_map.get((key[0] + dx, key[1] + dy, key[2] + dz), []):
                    if _v_len(_v_sub(point, points[idx])) < spacing:
                        return False
    cell_map.setdefault(key, []).append(len(points))
    return True


def create_scatter_points(context=None, settings=None):
    ctx = context or bpy.context
    count = max(1, min(200000, int(getattr(settings, 'scatter_count', 512) or 512)))
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    threshold = float(getattr(settings, 'density_threshold', 0.5) or 0.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    blue_noise = bool(getattr(settings, 'scatter_blue_noise', True))
    min_spacing = float(getattr(settings, 'scatter_min_spacing', radius * 0.85) or 0.0) if blue_noise else 0.0
    normal_offset = float(getattr(settings, 'scatter_normal_offset', radius * 0.05) or 0.0)
    biome_bias = float(getattr(settings, 'scatter_biome_bias', 0.25) or 0.0)
    source = node_factory.active_mesh_object(ctx)
    rng = random.Random(seed)
    verts: list[tuple[float, float, float]] = []
    normals: list[tuple[float, float, float]] = []
    densities: list[float] = []
    scales: list[float] = []
    variations: list[float] = []
    source_faces: list[int] = []
    biomes: list[int] = []
    lods: list[float] = []
    cell_map: dict[tuple[int, int, int], list[int]] = {}
    if source is not None and getattr(source, 'data', None) is not None and len(source.data.polygons) > 0:
        ensure_standard_attributes(source)
        mesh = source.data
        density_values = _read_attr_values(mesh, 'sgs_density', 1.0, _mesh_vertex_count(mesh))
        biome_values = _read_int_attr(mesh, 'sgs_biome', 1, _mesh_vertex_count(mesh))
        slope_values = _read_attr_values(mesh, 'sgs_slope', 0.0, _mesh_vertex_count(mesh))
        polys = list(mesh.polygons)
        cumulative: list[float] = []
        total = 0.0
        frames = []
        for poly in polys:
            frame = _poly_frame(source, poly)
            frames.append(frame)
            area = frame[4]
            d = _avg_poly_attr(mesh, poly, density_values, 1.0)
            b = _avg_poly_attr(mesh, poly, [float(v) for v in biome_values], 1.0)
            s = _avg_poly_attr(mesh, poly, slope_values, 0.0)
            habitat_weight = 1.0 + biome_bias * (1.0 if int(round(b)) in {1, 2} else -0.35)
            weight = max(0.0, area * d * habitat_weight * (1.0 - s * 0.25))
            total += weight
            cumulative.append(total)
        attempts = 0
        candidate_multiplier = max(1, min(64, int(getattr(settings, 'scatter_candidate_multiplier', 12) or 12)))
        max_attempts = max(count * candidate_multiplier, count + 512)
        while len(verts) < count and attempts < max_attempts and total > 0.0:
            attempts += 1
            pick = rng.random() * total
            poly_index = min(len(cumulative) - 1, bisect.bisect_left(cumulative, pick))
            poly = polys[poly_index]
            center, tangent, bitangent, normal, _area = frames[poly_index]
            d = _avg_poly_attr(mesh, poly, density_values, 1.0)
            if d < threshold and rng.random() > d / max(1e-6, threshold):
                continue
            point = _sample_poly_low_discrepancy(source, poly, rng, attempts + seed)
            jitter_u = (rng.random() - 0.5) * radius * 0.35
            jitter_v = (rng.random() - 0.5) * radius * 0.35
            point = _v_add(point, _v_add(_v_mul(tangent, jitter_u), _v_mul(bitangent, jitter_v)))
            point = _v_add(point, _v_mul(normal, normal_offset))
            if not _poisson_accept(point, cell_map, verts, min_spacing):
                continue
            verts.append(point)
            normals.append(normal)
            densities.append(_clamp(d))
            scales.append(radius * (0.55 + rng.random() * 0.9) * (0.65 + d * 0.7))
            variations.append(rng.random())
            source_faces.append(poly_index)
            biomes.append(int(round(_avg_poly_attr(mesh, poly, [float(v) for v in biome_values], 1.0))))
            lods.append(_clamp(d * 0.75 + (1.0 - _avg_poly_attr(mesh, poly, slope_values, 0.0)) * 0.25))
    if not verts:
        side = max(1, int(math.sqrt(count)) + 1)
        attempts = 0
        while len(verts) < count and attempts < count * 16:
            attempts += 1
            x = ((len(verts) % side) - side * 0.5 + rng.random() * 0.75) * radius * 4.0
            y = ((len(verts) // side) - side * 0.5 + rng.random() * 0.75) * radius * 4.0
            p = (x, y, 0.0)
            if not _poisson_accept(p, cell_map, verts, min_spacing):
                continue
            verts.append(p)
            normals.append((0.0, 0.0, 1.0))
            d = rng.random()
            densities.append(d)
            scales.append(radius * (0.5 + rng.random()))
            variations.append(rng.random())
            source_faces.append(-1)
            biomes.append(1)
            lods.append(d)
    relax_iterations = max(0, min(12, int(getattr(settings, 'scatter_relax_iterations', 2) or 0)))
    if blue_noise and relax_iterations > 0 and min_spacing > 1e-9:
        verts = _relax_point_set(verts, min_spacing, relax_iterations, strength=0.34)
    mesh = bpy.data.meshes.new('SGS_Precision_Surface_Distribution_Mesh')
    mesh.from_pydata(verts, [], [])
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Precision Surface Distribution Points', '分布ポイント'), mesh)
    _link_object(obj, ctx)
    _write_attr_values(mesh, 'sgs_id', 'INT', list(range(len(verts))))
    _write_attr_values(mesh, 'sgs_density', 'FLOAT', densities)
    _write_attr_values(mesh, 'sgs_scale', 'FLOAT', scales)
    _write_attr_values(mesh, 'sgs_variation', 'FLOAT', variations)
    _write_attr_values(mesh, 'sgs_normal', 'FLOAT_VECTOR', normals)
    _write_attr_values(mesh, 'sgs_source_face', 'INT', source_faces)
    _write_attr_values(mesh, 'sgs_biome', 'INT', biomes)
    _write_attr_values(mesh, 'sgs_lod', 'FLOAT', lods)
    _write_attr_values(mesh, 'sgs_cull', 'FLOAT', [1.0 if v >= 0.08 else 0.0 for v in lods])
    _write_attr_values(mesh, 'sgs_relaxed', 'FLOAT', [1.0 if relax_iterations > 0 else 0.0 for _ in verts])
    try:
        obj['sgs_builder'] = 'precision_surface_distribution'
        obj['sgs_algorithm'] = 'weighted_area_density_blue_noise_relaxed_v5'
        obj['sgs_relax_iterations'] = relax_iterations
        obj['sgs_requested_count'] = count
        obj['sgs_accepted_count'] = len(verts)
        if source:
            obj['sgs_source_object'] = source.name
    except Exception:
        pass
    return obj


# -----------------------------------------------------------------------------
# Procedural mesh builders
# -----------------------------------------------------------------------------


def _add_box(verts: list[tuple[float, float, float]], faces: list[tuple[int, int, int, int]], center, sx: float, sy: float, sz: float) -> int:
    cx, cy, cz = center
    start = len(verts)
    hx, hy, hz = sx * 0.5, sy * 0.5, sz * 0.5
    verts.extend([
        (cx - hx, cy - hy, cz - hz), (cx + hx, cy - hy, cz - hz), (cx + hx, cy + hy, cz - hz), (cx - hx, cy + hy, cz - hz),
        (cx - hx, cy - hy, cz + hz), (cx + hx, cy - hy, cz + hz), (cx + hx, cy + hy, cz + hz), (cx - hx, cy + hy, cz + hz),
    ])
    faces.extend([
        (start, start + 1, start + 2, start + 3), (start + 4, start + 7, start + 6, start + 5),
        (start, start + 4, start + 5, start + 1), (start + 1, start + 5, start + 6, start + 2),
        (start + 2, start + 6, start + 7, start + 3), (start + 3, start + 7, start + 4, start),
    ])
    return start


def _add_oriented_box(verts: list[tuple[float, float, float]], faces: list[tuple[int, int, int, int]], center, u, v, n, sx: float, sy: float, sz: float) -> int:
    start = len(verts)
    ux, vy, nz = _v_mul(_v_norm(u, (1.0, 0.0, 0.0)), sx * 0.5), _v_mul(_v_norm(v, (0.0, 1.0, 0.0)), sy * 0.5), _v_mul(_v_norm(n, (0.0, 0.0, 1.0)), sz * 0.5)
    corners = []
    for dz in (-1, 1):
        for dy in (-1, 1):
            for dx in (-1, 1):
                corners.append(_v_add(center, _v_add(_v_add(_v_mul(ux, dx), _v_mul(vy, dy)), _v_mul(nz, dz))))
    # Reorder to match the axis-aligned face template: bottom 0..3, top 4..7.
    ordered = [corners[i] for i in (0, 1, 3, 2, 4, 5, 7, 6)]
    verts.extend(ordered)
    faces.extend([
        (start, start + 1, start + 2, start + 3), (start + 4, start + 7, start + 6, start + 5),
        (start, start + 4, start + 5, start + 1), (start + 1, start + 5, start + 6, start + 2),
        (start + 2, start + 6, start + 7, start + 3), (start + 3, start + 7, start + 4, start),
    ])
    return start


def create_greeble_blocks(context=None, settings=None):
    ctx = context or bpy.context
    count = max(1, min(5000, int(getattr(settings, 'scatter_count', 192) or 192)))
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    threshold = float(getattr(settings, 'density_threshold', 0.5) or 0.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    rng = random.Random(seed)
    source = node_factory.active_mesh_object(ctx)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    panel_ids: list[int] = []
    panel_heights: list[float] = []
    if source is not None and getattr(source, 'data', None) is not None and len(source.data.polygons) > 0:
        ensure_standard_attributes(source)
        mesh = source.data
        density = _read_attr_values(mesh, 'sgs_density', 1.0, _mesh_vertex_count(mesh))
        polys = list(mesh.polygons)
        ordered = sorted(range(len(polys)), key=lambda i: _avg_poly_attr(mesh, polys[i], density, 1.0), reverse=True)
        for local_id, poly_index in enumerate(ordered[:count]):
            poly = polys[poly_index]
            d = _avg_poly_attr(mesh, poly, density, 1.0)
            if d < threshold and rng.random() > d / max(1e-6, threshold):
                continue
            center, u, v, n, area = _poly_frame(source, poly)
            s = radius * (0.45 + rng.random() * 1.45) * (0.75 + d * 0.5)
            sy = s * (0.55 + rng.random() * 0.9)
            h = radius * (0.35 + rng.random() * 4.5) * (0.75 + math.sqrt(max(area, 1e-9)))
            start = _add_oriented_box(verts, faces, _v_add(center, _v_mul(n, h * 0.5)), u, v, n, s, sy, h)
            panel_ids.extend([local_id] * 8)
            panel_heights.extend([h] * 8)
    if not verts:
        side = int(math.sqrt(count)) + 1
        for i in range(count):
            x = (i % side) * radius * 3.0
            y = (i // side) * radius * 3.0
            s = radius * (0.5 + rng.random())
            h = radius * (0.5 + rng.random() * 4.0)
            _add_box(verts, faces, (x, y, h * 0.5), s, s * (0.6 + rng.random()), h)
            panel_ids.extend([i] * 8)
            panel_heights.extend([h] * 8)
    mesh = bpy.data.meshes.new('SGS_Precision_Surface_Detail_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Precision Surface Detail Panelizer', '表面ディテールブロック'), mesh)
    _link_object(obj, ctx)
    ensure_standard_attributes(obj)
    _write_attr_values(mesh, 'sgs_panel_id', 'INT', panel_ids)
    _write_attr_values(mesh, 'sgs_panel_height', 'FLOAT', panel_heights)
    try:
        obj['sgs_builder'] = 'precision_surface_detail_panelizer'
        obj['sgs_algorithm'] = 'normal_aligned_density_ranked_panels_v5'
    except Exception:
        pass
    return obj


def create_building_proxy(context=None, settings=None):
    ctx = context or bpy.context
    floors = max(1, min(160, int(getattr(settings, 'structure_floors', 15) or 15)))
    radius = float(getattr(settings, 'scatter_radius', 0.2) or 0.2)
    seed = int(getattr(settings, 'random_seed', 1729))
    rng = random.Random(seed)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    module_ids: list[int] = []
    module_kind: list[int] = []
    width = radius * (18.0 + rng.random() * 6.0)
    depth = radius * (14.0 + rng.random() * 5.0)
    floor_h = radius * 4.8
    module_id = 0
    for f in range(floors):
        tier = f / max(1, floors - 1)
        setback = 1.0 - min(0.52, tier * 0.42 + (0.08 if f % 9 == 0 else 0.0))
        start = _add_box(verts, faces, (0, 0, f * floor_h + floor_h * 0.5), width * setback, depth * setback, floor_h * 0.92)
        module_ids.extend([module_id] * 8)
        module_kind.extend([0] * 8)
        module_id += 1
        cols = max(3, min(14, int(width / max(radius * 1.7, 1e-5))))
        for side in range(4):
            for c in range(cols):
                if rng.random() < 0.58 + tier * 0.15:
                    x = -width * setback * 0.43 + c * width * setback / max(1, cols - 1)
                    y = -depth * setback * 0.515
                    if side == 1:
                        y = depth * setback * 0.515
                    elif side == 2:
                        x, y = -width * setback * 0.515, -depth * setback * 0.43 + c * depth * setback / max(1, cols - 1)
                    elif side == 3:
                        x, y = width * setback * 0.515, -depth * setback * 0.43 + c * depth * setback / max(1, cols - 1)
                    sx = radius * (0.85 if side < 2 else 0.28)
                    sy = radius * (0.28 if side < 2 else 0.85)
                    sz = radius * (1.15 + rng.random() * 0.8)
                    _add_box(verts, faces, (x, y, f * floor_h + floor_h * 0.5), sx, sy, sz)
                    module_ids.extend([module_id] * 8)
                    module_kind.extend([1] * 8)
                    module_id += 1
    for r in range(max(2, floors // 12)):
        sx = radius * (1.6 + rng.random() * 3.0)
        sy = radius * (1.2 + rng.random() * 2.5)
        sz = radius * (1.0 + rng.random() * 2.2)
        x = (rng.random() - 0.5) * width * 0.45
        y = (rng.random() - 0.5) * depth * 0.45
        z = floors * floor_h + sz * 0.5
        _add_box(verts, faces, (x, y, z), sx, sy, sz)
        module_ids.extend([module_id] * 8)
        module_kind.extend([2] * 8)
        module_id += 1
    mesh = bpy.data.meshes.new('SGS_Precision_Modular_Structure_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Precision Modular Structure', 'モジュラー構造'), mesh)
    _link_object(obj, ctx)
    ensure_standard_attributes(obj)
    _write_attr_values(mesh, 'sgs_module_id', 'INT', module_ids)
    _write_attr_values(mesh, 'sgs_module_kind', 'INT', module_kind)
    try:
        obj['sgs_builder'] = 'precision_modular_structure_generator'
        obj['sgs_floors'] = floors
        obj['sgs_algorithm'] = 'tiered_setback_facade_roof_modules_v5'
    except Exception:
        pass
    return obj


def create_ivy_curve(context=None, settings=None):
    ctx = context or bpy.context
    amount = max(4, min(4000, int(getattr(settings, 'scatter_count', 128) or 128)))
    radius = float(getattr(settings, 'scatter_radius', 0.1) or 0.1)
    seed = int(getattr(settings, 'random_seed', 1729))
    branches = max(1, min(64, int(getattr(settings, 'growth_branches', 5) or 5)))
    rng = random.Random(seed)
    source = node_factory.active_mesh_object(ctx)
    base_size = 4.0
    zmax = 4.0
    origin = (0.0, 0.0, 0.0)
    if source is not None:
        try:
            dims = source.dimensions
            base_size = max(float(dims.x), float(dims.y), 1.0)
            zmax = max(float(dims.z), 1.0)
            origin = _to_tuple(source.location)
        except Exception:
            pass
    curve = bpy.data.curves.new('SGS_Precision_Growth_Curve', type='CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 4
    curve.bevel_depth = radius * 0.15
    curve.bevel_resolution = 2
    per_branch = max(4, amount // branches)
    for branch in range(branches):
        spline = curve.splines.new('POLY')
        spline.points.add(per_branch - 1)
        phase = rng.random() * math.tau
        climb = 0.75 + rng.random() * 0.5
        radial = base_size * (0.09 + rng.random() * 0.12)
        for i, point in enumerate(spline.points):
            t = i / max(1, per_branch - 1)
            angle = phase + t * math.pi * (2.4 + rng.random() * 0.2) + math.sin(t * 12.0 + phase) * 0.18
            r = radial * (0.75 + 0.32 * math.sin(t * 7.0 + branch))
            wander = radius * (rng.random() - 0.5) * 0.8
            x = origin[0] + math.cos(angle) * (r + wander)
            y = origin[1] + math.sin(angle) * (r - wander)
            z = origin[2] + (t ** climb) * zmax + math.sin(t * 18.0 + branch) * radius
            point.co = (x, y, z, 1.0)
    obj = bpy.data.objects.new(_object_name('SGS Precision Organic Growth Curves', '有機成長カーブ'), curve)
    _link_object(obj, ctx)
    try:
        obj['sgs_builder'] = 'precision_organic_growth_curves'
        obj['sgs_branches'] = branches
        obj['sgs_algorithm'] = 'multi_branch_deterministic_growth_v5'
        if source:
            obj['sgs_source_object'] = source.name
    except Exception:
        pass
    return obj


def explode_mesh_to_pieces(context=None, settings=None) -> list[Any]:
    ctx = context or bpy.context
    source = node_factory.active_mesh_object(ctx)
    if source is None or getattr(source, 'data', None) is None or len(source.data.polygons) == 0:
        return []
    requested = int(getattr(settings, 'fragment_piece_count', 0) or 0)
    if requested <= 0:
        requested = int(getattr(settings, 'scatter_count', 64) or 64)
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    seed = int(getattr(settings, 'random_seed', 1729))
    rng = random.Random(seed)
    mesh = source.data
    polys = list(mesh.polygons)
    max_pieces = max(1, min(512, requested, len(polys)))
    centers: list[tuple[float, float, float]] = []
    for poly in polys:
        coords = [_world_vertex(source, int(i)) for i in poly.vertices]
        centers.append((sum(c[0] for c in coords) / len(coords), sum(c[1] for c in coords) / len(coords), sum(c[2] for c in coords) / len(coords)))
    if not centers:
        return []

    # v5 uses farthest-seed, multi-source face-region growth so fragments stay
    # mostly contiguous instead of becoming pure distance partitions.
    seed_ids = _farthest_face_seeds(centers, max_pieces, seed)
    adjacency = _face_adjacency(mesh)
    assigned = [-1] * len(polys)
    queue: deque[int] = deque()
    for piece_id, face_id in enumerate(seed_ids):
        assigned[face_id] = piece_id
        queue.append(face_id)
    while queue:
        face_id = queue.popleft()
        piece_id = assigned[face_id]
        neigh = list(adjacency[face_id])
        rng.shuffle(neigh)
        for nxt in neigh:
            if assigned[nxt] < 0:
                assigned[nxt] = piece_id
                queue.append(nxt)
    # Disconnected leftovers, if any, fall back to nearest seed center.
    seed_centers = [centers[i] for i in seed_ids]
    for poly_index, piece_id in enumerate(assigned):
        if piece_id < 0:
            assigned[poly_index] = min(range(len(seed_centers)), key=lambda k: _v_len(_v_sub(centers[poly_index], seed_centers[k])))
    clusters: dict[int, list[int]] = {i: [] for i in range(len(seed_ids))}
    for poly_index, piece_id in enumerate(assigned):
        clusters.setdefault(piece_id, []).append(poly_index)

    all_center = (sum(c[0] for c in centers) / len(centers), sum(c[1] for c in centers) / len(centers), sum(c[2] for c in centers) / len(centers))
    created = []
    for piece_id, poly_indices in clusters.items():
        if not poly_indices:
            continue
        verts: list[tuple[float, float, float]] = []
        faces: list[tuple[int, ...]] = []
        index_map: dict[int, int] = {}
        piece_center = (sum(centers[i][0] for i in poly_indices) / len(poly_indices), sum(centers[i][1] for i in poly_indices) / len(poly_indices), sum(centers[i][2] for i in poly_indices) / len(poly_indices))
        direction = _v_norm(_v_sub(piece_center, all_center), (rng.random() - 0.5, rng.random() - 0.5, rng.random()))
        offset = _v_add(_v_mul(direction, radius * (1.35 + rng.random() * 2.9)), (0.0, 0.0, radius * rng.random() * 1.8))
        cluster_area = 0.0
        for poly_index in poly_indices:
            poly = polys[poly_index]
            cluster_area += float(getattr(poly, 'area', 0.0) or 0.0)
            face = []
            for old_i in poly.vertices:
                old_i = int(old_i)
                if old_i not in index_map:
                    co = _world_vertex(source, old_i)
                    index_map[old_i] = len(verts)
                    verts.append(_v_add(co, offset))
                face.append(index_map[old_i])
            faces.append(tuple(face))
        piece_mesh = bpy.data.meshes.new(f'SGS_Precision_Fragment_{piece_id:03d}_Mesh')
        piece_mesh.from_pydata(verts, [], faces)
        piece_mesh.update()
        obj = bpy.data.objects.new(_object_name(f'SGS Precision Fragment {piece_id:03d}', _fragment_name_ja(piece_id)), piece_mesh)
        try:
            ctx.collection.objects.link(obj)
        except Exception:
            try:
                bpy.context.collection.objects.link(obj)
            except Exception:
                pass
        mass = max(1.0, float(len(poly_indices)))
        _write_attr_values(piece_mesh, 'sgs_piece_id', 'INT', [piece_id] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_variation', 'FLOAT', [_hash01(piece_id, i, seed) for i in range(len(verts))])
        _write_attr_values(piece_mesh, 'sgs_fragment_mass', 'FLOAT', [mass] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_area', 'FLOAT', [cluster_area] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_region', 'INT', [piece_id] * len(verts))
        try:
            obj['sgs_builder'] = 'precision_mesh_fragment_builder'
            obj['sgs_source_object'] = source.name
            obj['sgs_piece_id'] = piece_id
            obj['sgs_face_count'] = len(poly_indices)
            obj['sgs_algorithm'] = 'farthest_seed_contiguous_face_region_growth_v5'
            node_factory.mark_created_object(obj)
        except Exception:
            pass
        created.append(obj)
    return created


def relax_distribution_points(context=None, settings=None):
    ctx = context or bpy.context
    obj = node_factory.active_mesh_object(ctx)
    if obj is None or getattr(obj, 'data', None) is None:
        return 0
    mesh = obj.data
    if len(getattr(mesh, 'vertices', []) or []) <= 1:
        return 0
    spacing = float(getattr(settings, 'scatter_min_spacing', 0.12) or 0.12)
    if spacing <= 0.0:
        spacing = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    iterations = max(1, min(16, int(getattr(settings, 'scatter_relax_iterations', 2) or 2)))
    points = [_to_tuple(v.co) for v in mesh.vertices]
    relaxed = _relax_point_set(points, spacing, iterations, strength=0.42)
    moved = 0
    for vertex, co in zip(mesh.vertices, relaxed):
        old = _to_tuple(vertex.co)
        if _v_len(_v_sub(old, co)) > 1e-9:
            moved += 1
        try:
            vertex.co = co
        except Exception:
            pass
    _write_attr_values(mesh, 'sgs_relaxed', 'FLOAT', [1.0] * len(relaxed))
    _write_attr_values(mesh, 'sgs_quality', 'FLOAT', [1.0] * len(relaxed))
    try:
        mesh.update()
        obj['sgs_relax_iterations'] = iterations
        obj['sgs_algorithm'] = 'active_point_cloud_blue_noise_relaxation_v5'
        obj[node_factory.GENERATED_FLAG] = True
    except Exception:
        pass
    return moved


def refine_scene_precision(context=None, settings=None) -> int:
    ctx = context or bpy.context
    targets = []
    try:
        targets = [o for o in ctx.selected_objects if getattr(o, 'type', None) == 'MESH']
    except Exception:
        targets = []
    if not targets:
        obj = node_factory.active_mesh_object(ctx)
        targets = [obj] if obj is not None else []
    count = 0
    for obj in targets:
        written = ensure_standard_attributes(obj)
        if written:
            count += 1
    return count


def create_flow_network_curves(context=None, settings=None):
    ctx = context or bpy.context
    source = node_factory.active_mesh_object(ctx)
    if source is None or getattr(source, 'data', None) is None or len(source.data.vertices) == 0:
        return None
    mesh = source.data
    coords = [_world_vertex(source, i) for i in range(_mesh_vertex_count(mesh))]
    span = [max(c[axis] for c in coords) - min(c[axis] for c in coords) for axis in range(3)]
    diagonal = max(1e-6, _v_len(tuple(span)))
    # Water runs along the world Z of the object as placed; a level surface has no downhill at all.
    # Decide this before any attribute is written so a failed call leaves the mesh untouched.
    if span[2] <= diagonal * 1e-5:
        return None
    _attrs_before = set(mesh.attributes.keys())
    ensure_standard_attributes(source)
    neighbors, _boundary = _mesh_neighbors(mesh)
    flow = _read_attr_values(mesh, 'sgs_flow', 0.0, _mesh_vertex_count(mesh))
    channel = _read_attr_values(mesh, 'sgs_channel', 0.0, _mesh_vertex_count(mesh))
    amount = max(1, min(256, int(getattr(settings, 'drainage_curve_count', 32) or 32)))
    bottom = min(c[2] for c in coords)
    heights = [(c[2] - bottom) / span[2] for c in coords]
    # The line must stay readable on the whole surface, so its width follows the source size as well.
    bevel = max(0.0001, float(getattr(settings, 'scatter_radius', 0.15) or 0.15) * 0.035, diagonal * 0.0012)
    offset = max(float(getattr(settings, 'scatter_normal_offset', 0.01) or 0.01), bevel)
    # A downhill line has to start upstream: high-flow vertices sit at the bottom of the valleys.
    ranked = sorted(range(len(heights)), key=lambda i: heights[i] * 0.55 + (flow[i] * 0.62 + channel[i] * 0.38) * 0.45, reverse=True)
    seed_gap = diagonal / (math.sqrt(amount) * 2.0)
    seeds: list[int] = []
    for idx in ranked:
        if all(_v_len(_v_sub(coords[idx], coords[other])) >= seed_gap for other in seeds):
            seeds.append(idx)
            if len(seeds) >= amount * 4:
                break
    curve = bpy.data.curves.new('SGS_Precision_Drainage_Network', type='CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 3
    curve.bevel_depth = bevel
    curve.bevel_resolution = 1
    made = 0
    network: set[int] = set()
    max_steps = max(8, min(400, len(mesh.vertices) // 4 + 8))
    for min_length in (diagonal * 0.08, 0.0):
        for seed_idx in seeds:
            if made >= amount:
                break
            if seed_idx in network:
                continue
            path = [seed_idx]
            cur = seed_idx
            local = {cur}
            lowest = heights[cur]
            lowest_index = 0
            joined = False
            for _step in range(max_steps):
                # The small tolerance lets a line cross shallow pits without climbing a slope.
                candidates = [j for j in neighbors[cur] if j not in local and heights[j] <= lowest + 0.015]
                if not candidates:
                    break
                cur = min(candidates, key=lambda j: heights[j] - flow[j] * 0.002 - channel[j] * 0.001)
                path.append(cur)
                local.add(cur)
                if heights[cur] < lowest:
                    lowest = heights[cur]
                    lowest_index = len(path) - 1
                if cur in network:
                    joined = True
                    break
                if len(path) - 1 - lowest_index >= 6:
                    break
            if not joined:
                path = path[:lowest_index + 1]
            if len(path) < 2:
                continue
            if sum(_v_len(_v_sub(coords[path[i + 1]], coords[path[i]])) for i in range(len(path) - 1)) < min_length:
                continue
            network.update(path)
            spline = curve.splines.new('POLY')
            spline.points.add(len(path) - 1)
            for point, vid in zip(spline.points, path):
                co = coords[vid]
                try:
                    n = source.data.vertices[vid].normal
                    no = _v_norm((float(n.x), float(n.y), float(n.z)))
                except Exception:
                    no = (0.0, 0.0, 1.0)
                co = _v_add(co, _v_mul(no, offset))
                point.co = (co[0], co[1], co[2], 1.0)
            made += 1
        if made:
            break
    if not made:
        bpy.data.curves.remove(curve)
        for _name in list(mesh.attributes.keys()):
            if _name not in _attrs_before:
                try:
                    mesh.attributes.remove(mesh.attributes[_name])
                except Exception:
                    pass
        return None
    obj = bpy.data.objects.new(_object_name('SGS Precision Drainage Flow Network', '排水フローネットワーク'), curve)
    _link_object(obj, ctx)
    try:
        obj['sgs_builder'] = 'precision_drainage_flow_network'
        obj['sgs_source_object'] = source.name
        obj['sgs_curve_count'] = made
        obj['sgs_algorithm'] = 'attribute_ranked_downhill_channel_tracing_v5'
        node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj


# -----------------------------------------------------------------------------
# CSV/open-data point import
# -----------------------------------------------------------------------------


def _csv_coordinate(row: dict[str, str], names: tuple[str, ...]) -> float | None:
    for name in names:
        text = row.get(name, '')
        if text:
            try:
                value = float(text)
            except ValueError:
                return None
            return value if math.isfinite(value) else None
    return None


def import_csv_points(filepath: str, context=None):
    path = Path(str(filepath or '')).expanduser()
    if not path.exists() or not path.is_file():
        return None
    rows: list[dict[str, str]] = []
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            rows.append({_sanitize_attr_name(str(k or '')): str(v or '').strip() for k, v in row.items()})
    if not rows:
        return None
    verts: list[tuple[float, float, float]] = []
    ids: list[int] = []
    scales: list[float] = []
    densities: list[float] = []
    custom_numeric: dict[str, list[float]] = {}
    all_keys = sorted(set().union(*(row.keys() for row in rows)))
    # Also accept common alternate coordinate labels while keeping neutral internal attributes.
    coordinate_columns = (('x', 'px', 'pos_x'), ('y', 'py', 'pos_y'), ('z', 'pz', 'pos_z', 'height'))
    if not all(set(names).intersection(all_keys) for names in coordinate_columns):
        return None
    for key in all_keys:
        if key not in {'x', 'y', 'z', 'id', 'scale', 'density'}:
            custom_numeric[key] = []
    for idx, row in enumerate(rows):
        def f(name: str, default: float = 0.0) -> float:
            return _safe_float(row.get(name, default), default)
        co = [_csv_coordinate(row, names) for names in coordinate_columns]
        if None in co:
            # A row without three numbers is not a point; it must not become one at the origin.
            continue
        verts.append(tuple(co))
        ids.append(_safe_int(row.get('id', idx), idx))
        scales.append(f('scale', 1.0))
        densities.append(_clamp(f('density', 1.0)))
        for key in custom_numeric:
            custom_numeric[key].append(_safe_float(row.get(key, 0.0), 0.0))
    if not verts:
        return None
    mesh = bpy.data.meshes.new(f'SGS_CSV_PointCloud_{path.stem[:32]}_Mesh')
    mesh.from_pydata(verts, [], [])
    mesh.update()
    obj = bpy.data.objects.new(_object_name(f'SGS CSV Point Cloud {path.stem[:32]}', f'CSVポイントクラウド {path.stem[:32]}'), mesh)
    _link_object(obj, context)
    _write_attr_values(mesh, 'sgs_id', 'INT', ids)
    _write_attr_values(mesh, 'sgs_scale', 'FLOAT', scales)
    _write_attr_values(mesh, 'sgs_density', 'FLOAT', densities)
    _write_attr_values(mesh, 'sgs_variation', 'FLOAT', [_hash01(i, len(verts), 1729) for i in range(len(verts))])
    for key, values in custom_numeric.items():
        _write_attr_values(mesh, f'sgs_csv_{key[:48]}', 'FLOAT', values)
    try:
        obj['sgs_builder'] = 'precision_csv_point_cloud'
        obj['sgs_csv_source'] = str(path)
        obj['sgs_csv_rows'] = len(verts)
        node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj


# -----------------------------------------------------------------------------
# v5 debug, snapshot, and visible distribution proxy builders
# -----------------------------------------------------------------------------


def _resolve_debug_attr_name(name: str) -> str:
    raw = str(name or '').strip()
    if not raw:
        return 'sgs_density'
    return _attr_name_from_token(raw) if not raw.startswith('sgs_') else raw


def _heat_color(value: float) -> tuple[float, float, float, float]:
    v = _clamp(value)
    # Perceptual-ish five-stop ramp: deep blue -> cyan -> green -> yellow -> red.
    stops = [
        (0.00, (0.02, 0.05, 0.22)),
        (0.25, (0.00, 0.42, 0.82)),
        (0.50, (0.10, 0.78, 0.42)),
        (0.75, (0.95, 0.82, 0.18)),
        (1.00, (0.95, 0.12, 0.04)),
    ]
    for idx in range(len(stops) - 1):
        a_pos, a_col = stops[idx]
        b_pos, b_col = stops[idx + 1]
        if a_pos <= v <= b_pos:
            t = 0.0 if b_pos <= a_pos else (v - a_pos) / (b_pos - a_pos)
            col = tuple(a_col[c] + (b_col[c] - a_col[c]) * t for c in range(3))
            return (col[0], col[1], col[2], 1.0)
    return (stops[-1][1][0], stops[-1][1][1], stops[-1][1][2], 1.0)


def write_attribute_heatmap(obj, attr_name: str = 'sgs_density') -> bool:
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return False
    mesh = getattr(obj, 'data', None)
    count = _mesh_vertex_count(mesh) if mesh else 0
    if count <= 0:
        return False
    ensure_standard_attributes(obj)
    attr = _resolve_debug_attr_name(attr_name)
    if mesh.attributes.get(attr) is None:
        return False
    values = _read_attr_values(mesh, attr, 0.0, count)
    normalized = _normalize_values(values)
    colors = [_heat_color(v) for v in normalized]
    ok = _write_attr_values(mesh, 'sgs_debug_heatmap', 'FLOAT_COLOR', colors, domain='POINT')
    if not ok:
        return False
    try:
        mat = bpy.data.materials.get(_object_name('SGS Debug Heatmap Material', 'デバッグ ヒートマップ')) or bpy.data.materials.new(_object_name('SGS Debug Heatmap Material', 'デバッグ ヒートマップ'))
        mat.diffuse_color = (1.0, 0.22, 0.08, 1.0)
        if mat.name not in [m.name for m in obj.data.materials if m]:
            obj.data.materials.append(mat)
    except Exception:
        pass
    try:
        obj['sgs_debug_heatmap_attribute'] = attr
        obj['sgs_debug_heatmap_min'] = min(values) if values else 0.0
        obj['sgs_debug_heatmap_max'] = max(values) if values else 0.0
        obj['sgs_debug_heatmap_algorithm'] = 'v5_normalized_attribute_color_ramp'
    except Exception:
        pass
    return True


def create_attribute_snapshot(context=None, settings=None):
    ctx = context or bpy.context
    source = node_factory.active_mesh_object(ctx)
    if source is None or getattr(source, 'data', None) is None:
        return None
    ensure_standard_attributes(source)
    attr = _resolve_debug_attr_name(getattr(settings, 'debug_attribute', 'sgs_density') if settings else 'sgs_density')
    if source.data.attributes.get(attr) is None:
        return None
    try:
        mesh = source.data.copy()
    except Exception:
        return None
    obj = bpy.data.objects.new(_object_name(f'SGS Attribute Snapshot {source.name[:36]}', f'属性スナップショット {source.name[:36]}'), mesh)
    try:
        obj.matrix_world = source.matrix_world.copy()
    except Exception:
        pass
    _link_object(obj, ctx)
    write_attribute_heatmap(obj, attr)
    try:
        obj['sgs_builder'] = 'v5_attribute_snapshot'
        obj['sgs_source_object'] = source.name
        obj['sgs_snapshot_attribute'] = attr
        obj['sgs_snapshot_note'] = 'Frozen mesh-data copy with SGS attributes preserved for inspection.'
        node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj


def create_distribution_proxy_instances(context=None, settings=None):
    ctx = context or bpy.context
    source = node_factory.active_mesh_object(ctx)
    try:
        if source is not None and str(source.get('sgs_builder', '') or '') == 'v5_visible_distribution_proxy_instances':
            original_name = str(source.get('sgs_source_object', '') or '')
            original = bpy.data.objects.get(original_name) if original_name else None
            if original is not None and getattr(original, 'type', None) == 'MESH':
                source = original
    except Exception:
        pass
    if source is None or getattr(source, 'type', None) != 'MESH' or _mesh_vertex_count(source.data) == 0:
        source = create_scatter_points(ctx, settings)
    if source is None or getattr(source, 'type', None) != 'MESH':
        return None
    try:
        from . import proxy_cleanup
        proxy_cleanup.cleanup_sgs_distribution_proxies(source_name=source.name)
    except Exception:
        pass
    mesh_src = source.data
    count = _mesh_vertex_count(mesh_src)
    if count <= 0:
        return None
    max_instances = min(count, max(1, int(getattr(settings, 'scatter_count', count) or count)))
    scale_values = _read_attr_values(mesh_src, 'sgs_scale', float(getattr(settings, 'scatter_radius', 0.15) or 0.15), count)
    density_values = _read_attr_values(mesh_src, 'sgs_density', 1.0, count)
    biome_values = _read_int_attr(mesh_src, 'sgs_biome', 1, count)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, ...]] = []
    ids: list[int] = []
    density_out: list[float] = []
    biome_out: list[int] = []
    for i, vertex in enumerate(mesh_src.vertices[:max_instances]):
        p = _to_tuple(source.matrix_world @ vertex.co if hasattr(source, 'matrix_world') else vertex.co)
        s = max(0.001, float(scale_values[i]) * 0.42)
        base = len(verts)
        verts.extend([
            (p[0] - s, p[1] - s, p[2]),
            (p[0] + s, p[1] - s, p[2]),
            (p[0] + s, p[1] + s, p[2]),
            (p[0] - s, p[1] + s, p[2]),
            (p[0], p[1], p[2] + s * (1.35 + density_values[i])),
        ])
        faces.extend([(base, base + 1, base + 4), (base + 1, base + 2, base + 4), (base + 2, base + 3, base + 4), (base + 3, base, base + 4), (base, base + 3, base + 2, base + 1)])
        ids.extend([i] * 5)
        density_out.extend([density_values[i]] * 5)
        biome_out.extend([biome_values[i]] * 5)
    mesh = bpy.data.meshes.new('SGS_Distribution_Proxy_Instances_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Distribution Proxy Instances', '分布プロキシインスタンス'), mesh)
    _link_object(obj, ctx)
    _write_attr_values(mesh, 'sgs_id', 'INT', ids)
    _write_attr_values(mesh, 'sgs_density', 'FLOAT', density_out)
    _write_attr_values(mesh, 'sgs_biome', 'INT', biome_out)
    write_attribute_heatmap(obj, 'sgs_density')
    try:
        obj['sgs_builder'] = 'v5_visible_distribution_proxy_instances'
        obj['sgs_source_object'] = source.name
        obj['sgs_instance_count'] = max_instances
        obj['sgs_ephemeral_proxy'] = True
        mesh['sgs_ephemeral_proxy'] = True
        node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj

# -----------------------------------------------------------------------------
# Precision Overdrive v5 overrides
# -----------------------------------------------------------------------------

_SGS_V4_ensure_standard_attributes = ensure_standard_attributes
_SGS_V4_terrain_maps = _terrain_maps


def _rank_values(values: list[float]) -> list[float]:
    if not values:
        return []
    ranked = sorted(range(len(values)), key=lambda i: values[i])
    result = [0.0] * len(values)
    denom = max(1, len(values) - 1)
    for order, idx in enumerate(ranked):
        result[idx] = order / denom
    return result


def _vertex_area_values(mesh) -> list[float]:
    count = _mesh_vertex_count(mesh)
    areas = [0.0] * count
    try:
        for poly in mesh.polygons:
            share = float(getattr(poly, 'area', 0.0) or 0.0) / max(1, len(poly.vertices))
            for i in poly.vertices:
                idx = int(i)
                if 0 <= idx < count:
                    areas[idx] += share
    except Exception:
        pass
    return _normalize_values(areas)


def _position_bounds(mesh):
    try:
        coords = [_to_tuple(v.co) for v in mesh.vertices]
    except Exception:
        coords = []
    if not coords:
        return (0.0, 0.0, 0.0), (1.0, 1.0, 1.0), []
    mins = (min(c[0] for c in coords), min(c[1] for c in coords), min(c[2] for c in coords))
    maxs = (max(c[0] for c in coords), max(c[1] for c in coords), max(c[2] for c in coords))
    return mins, maxs, coords


def _cluster_values(mesh, bins: int = 12) -> list[int]:
    mins, maxs, coords = _position_bounds(mesh)
    if not coords:
        return []
    sx = max(1e-9, maxs[0] - mins[0])
    sy = max(1e-9, maxs[1] - mins[1])
    sz = max(1e-9, maxs[2] - mins[2])
    result: list[int] = []
    for x, y, z in coords:
        ix = min(bins - 1, max(0, int((x - mins[0]) / sx * bins)))
        iy = min(bins - 1, max(0, int((y - mins[1]) / sy * bins)))
        iz = min(bins - 1, max(0, int((z - mins[2]) / sz * max(2, bins // 3))))
        result.append(ix + iy * bins + iz * bins * bins)
    return result


def _camera_visibility_scores(obj, mesh, margin: float = 1.12) -> list[float]:
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    try:
        scene = bpy.context.scene
        camera = scene.camera
        if camera is None or getattr(camera, 'type', None) != 'CAMERA':
            return [1.0] * count
        cam_data = camera.data
        inv = camera.matrix_world.inverted()
        angle_x = float(getattr(cam_data, 'angle_x', getattr(cam_data, 'angle', 0.857)))
        angle_y = float(getattr(cam_data, 'angle_y', getattr(cam_data, 'angle', 0.857)))
        tan_x = math.tan(angle_x * 0.5) * margin
        tan_y = math.tan(angle_y * 0.5) * margin
        clip_start = float(getattr(cam_data, 'clip_start', 0.001) or 0.001)
        clip_end = float(getattr(cam_data, 'clip_end', 1.0e9) or 1.0e9)
        world = obj.matrix_world
        scores: list[float] = []
        for v in mesh.vertices:
            local = inv @ (world @ v.co)
            depth = -float(local.z)
            if depth < clip_start or depth > clip_end:
                scores.append(0.0)
                continue
            nx = abs(float(local.x)) / max(depth, 1e-9)
            ny = abs(float(local.y)) / max(depth, 1e-9)
            if nx <= tan_x and ny <= tan_y:
                edge = max(nx / max(tan_x, 1e-9), ny / max(tan_y, 1e-9))
                scores.append(_clamp(1.0 - max(0.0, edge - 0.82) / 0.18))
            else:
                scores.append(0.0)
        return scores
    except Exception:
        return [1.0] * count


def _neighbor_variance(values: list[float], neighbors: list[set[int]]) -> list[float]:
    result: list[float] = []
    for i, value in enumerate(values):
        if not neighbors[i]:
            result.append(0.0)
            continue
        avg = sum(values[j] for j in neighbors[i]) / max(1, len(neighbors[i]))
        result.append(abs(value - avg))
    return _normalize_values(result)


def ensure_standard_attributes(obj) -> list[str]:
    """v5: add overdrive analysis attributes on top of the dense base layer."""
    written = list(_SGS_V4_ensure_standard_attributes(obj) or [])
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return written
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return written
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return written
    try:
        mesh.update()
        mesh.calc_normals()
    except Exception:
        pass
    neighbors, boundary = _mesh_neighbors(mesh)
    heights = _read_attr_values(mesh, 'sgs_height', 0.0, count)
    slopes = _read_attr_values(mesh, 'sgs_slope', 0.0, count)
    curvature = _read_attr_values(mesh, 'sgs_curvature', 0.0, count)
    convexity = _read_attr_values(mesh, 'sgs_convexity', 0.5, count)
    density = _read_attr_values(mesh, 'sgs_density', 1.0, count)
    wetness = _read_attr_values(mesh, 'sgs_wetness', 0.0, count)
    flow = _read_attr_values(mesh, 'sgs_flow', 0.0, count)
    erosion = _read_attr_values(mesh, 'sgs_erosion', 0.0, count)
    sediment = _read_attr_values(mesh, 'sgs_sediment', 0.0, count)
    ambient = _read_attr_values(mesh, 'sgs_ambient', 0.5, count)
    edge_distance = _read_attr_values(mesh, 'sgs_edge_distance', 1.0, count)
    vertex_area = _vertex_area_values(mesh)
    height_variance = _neighbor_variance(heights, neighbors)
    density_rank = _rank_values(density)
    flow_rank = _rank_values(flow)
    erosion_rank = _rank_values(erosion)
    ridge = [_clamp((convexity[i] - 0.5) * 2.0) for i in range(count)]
    valley = [_clamp((0.5 - convexity[i]) * 2.0) for i in range(count)]
    habitat = [_clamp(density[i] * (1.0 - slopes[i] * 0.72) * (0.72 + wetness[i] * 0.34) * (1.0 - curvature[i] * 0.25)) for i in range(count)]
    stability = [_clamp(1.0 - erosion[i] * 0.55 - slopes[i] * 0.28 + sediment[i] * 0.18 + edge_distance[i] * 0.08) for i in range(count)]
    exposure = [_clamp(0.35 + ridge[i] * 0.32 + heights[i] * 0.24 - wetness[i] * 0.18 + slopes[i] * 0.16) for i in range(count)]
    accumulation = [_clamp(sediment[i] * 0.66 + valley[i] * 0.24 + wetness[i] * 0.10) for i in range(count)]
    drainage = [_clamp(flow[i] * (0.62 + slopes[i] * 0.38) * (1.0 - valley[i] * 0.18)) for i in range(count)]
    quality = [_clamp(ambient[i] * 0.25 + stability[i] * 0.30 + habitat[i] * 0.25 + (1.0 - height_variance[i]) * 0.20) for i in range(count)]
    visibility = _camera_visibility_scores(obj, mesh)
    clusters = _cluster_values(mesh, bins=12)
    material_id = []
    biome = _read_int_attr(mesh, 'sgs_biome', 1, count)
    for i in range(count):
        # Neutral material intent: 0 low/wet, 1 ground, 2 dense habitat, 3 exposed, 4 high/cold, 5 detail/trim.
        mat = biome[i]
        if ridge[i] > 0.72 and slopes[i] > 0.48:
            mat = 5
        material_id.append(int(mat))
    try:
        normals = [_to_tuple(v.normal) for v in mesh.vertices]
    except Exception:
        normals = [(0.0, 0.0, 1.0)] * count
    specs = [
        ('sgs_vertex_area', 'FLOAT', vertex_area),
        ('sgs_height_variance', 'FLOAT', height_variance),
        ('sgs_density_rank', 'FLOAT', density_rank),
        ('sgs_flow_rank', 'FLOAT', flow_rank),
        ('sgs_erosion_rank', 'FLOAT', erosion_rank),
        ('sgs_ridge', 'FLOAT', ridge),
        ('sgs_valley', 'FLOAT', valley),
        ('sgs_habitat_score', 'FLOAT', habitat),
        ('sgs_stability', 'FLOAT', stability),
        ('sgs_exposure', 'FLOAT', exposure),
        ('sgs_accumulation', 'FLOAT', accumulation),
        ('sgs_drainage', 'FLOAT', drainage),
        ('sgs_quality', 'FLOAT', quality),
        ('sgs_visibility', 'FLOAT', visibility),
        ('sgs_cluster', 'INT', clusters),
        ('sgs_material_id', 'INT', material_id),
        ('sgs_normal', 'FLOAT_VECTOR', normals),
    ]
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        obj['sgs_attribute_precision'] = 'v5_overdrive_density_habitat_visibility_quality'
        obj['sgs_overdrive_attributes'] = ','.join(name for name, _dtype, _values in specs)
        obj[node_factory.GENERATED_FLAG] = True
    except Exception:
        pass
    return sorted(set(written), key=written.index)


def _terrain_neighbors8(x: int, y: int, res: int) -> Iterable[tuple[int, int]]:
    for yy in range(max(0, y - 1), min(res - 1, y + 1) + 1):
        for xx in range(max(0, x - 1), min(res - 1, x + 1) + 1):
            if xx == x and yy == y:
                continue
            yield xx, yy


def _recompute_terrain_derivatives(h: list[float], res: int, size: float, height: float, seed: int, flow_seed: list[float] | None = None) -> dict[str, list[float]]:
    slope: list[float] = []
    convexity_raw: list[float] = []
    cell = max(1e-6, size / max(1, res - 1))
    for y in range(res):
        for x in range(res):
            i = _terrain_index(x, y, res)
            left = h[_terrain_index(max(0, x - 1), y, res)]
            right = h[_terrain_index(min(res - 1, x + 1), y, res)]
            down = h[_terrain_index(x, max(0, y - 1), res)]
            up = h[_terrain_index(x, min(res - 1, y + 1), res)]
            dx = (right - left) / (cell * 2.0)
            dy = (up - down) / (cell * 2.0)
            slope.append(_clamp(math.sqrt(dx * dx + dy * dy) / max(0.001, height * 2.35)))
            neigh = [h[_terrain_index(nx, ny, res)] for nx, ny in _terrain_neighbors8(x, y, res)]
            convexity_raw.append(h[i] - (sum(neigh) / max(1, len(neigh))))
    height_norm = _normalize_values(h)
    convexity = _normalize_values(convexity_raw)
    wetness = [_clamp((1.0 - height_norm[i]) * 0.48 + (1.0 - slope[i]) * 0.18 + _value_noise2(i % res * 0.11, i // res * 0.11, seed + 701) * 0.10) for i in range(len(h))]
    flow = [0.02 + wetness[i] * 0.05 + (flow_seed[i] if flow_seed else 0.0) for i in range(len(h))]
    order = sorted(range(len(h)), key=lambda i: h[i], reverse=True)
    for i in order:
        x = i % res
        y = i // res
        lower = []
        for nx, ny in _terrain_neighbors8(x, y, res):
            j = _terrain_index(nx, ny, res)
            if h[j] < h[i]:
                lower.append((j, h[i] - h[j]))
        if lower:
            denom = sum(v for _j, v in lower)
            for j, diff in lower:
                flow[j] += flow[i] * 0.72 * (diff / max(1e-9, denom))
    flow_norm = _normalize_values([math.log1p(v) for v in flow])
    erosion = [_clamp(flow_norm[i] * slope[i] * 1.55 + max(0.0, convexity[i] - 0.55) * 0.18) for i in range(len(h))]
    sediment = [_clamp(flow_norm[i] * (1.0 - slope[i]) * (1.0 - height_norm[i]) * 1.45 + max(0.0, 0.45 - convexity[i]) * 0.12) for i in range(len(h))]
    channel = [_clamp(flow_norm[i] * (0.55 + slope[i] * 0.45)) for i in range(len(h))]
    stream_order = _rank_values(flow_norm)
    terrace = [_clamp(abs((height_norm[i] * 9.0) % 1.0 - 0.5) * 2.0) for i in range(len(h))]
    strata = [float(min(7, max(0, int(height_norm[i] * 8.0)))) for i in range(len(h))]
    biome = _biome_values(height_norm, slope, wetness, convexity)
    return {
        'height': h,
        'height_norm': height_norm,
        'slope': slope,
        'convexity': convexity,
        'wetness': wetness,
        'flow': flow_norm,
        'erosion': erosion,
        'sediment': sediment,
        'channel': channel,
        'stream_order': stream_order,
        'terrace': terrace,
        'strata': strata,
        'biome': [float(b) for b in biome],
    }


def _terrain_maps_v5(res: int, size: float, height: float, seed: int, iterations: int, droplets: int, hydraulic_strength: float) -> dict[str, list[float]]:
    base = _SGS_V4_terrain_maps(res, size, height, seed, iterations)
    h = list(base.get('height') or [])
    if not h:
        return base
    rng = random.Random(seed * 131 + res * 17)
    droplets = max(0, min(250000, int(droplets)))
    strength = _clamp(hydraulic_strength, 0.0, 5.0)
    flow_seed = [0.0] * len(h)
    sediment_seed = [0.0] * len(h)
    if droplets > 0 and strength > 0.0 and res > 2:
        max_steps = max(8, min(96, int(12 + math.sqrt(res))))
        for d in range(droplets):
            # Halton-started droplets reduce directional artifacts compared with pure random starts.
            hx = _radical_inverse(d + 1 + seed % 997, 2)
            hy = _radical_inverse(d + 1 + seed % 577, 3)
            x = min(res - 2, max(1, int(hx * (res - 2)) + 1))
            y = min(res - 2, max(1, int(hy * (res - 2)) + 1))
            water = 1.0
            carried = 0.0
            for _step in range(max_steps):
                i = _terrain_index(x, y, res)
                candidates = []
                for nx, ny in _terrain_neighbors8(x, y, res):
                    j = _terrain_index(nx, ny, res)
                    drop = h[i] - h[j]
                    if drop > 0.0:
                        candidates.append((j, nx, ny, drop))
                flow_seed[i] += water
                if not candidates:
                    deposit = carried * 0.42 * strength
                    h[i] += deposit
                    sediment_seed[i] += deposit
                    break
                candidates.sort(key=lambda item: item[3], reverse=True)
                # Blend steepest descent with deterministic wandering for natural braided channels.
                choice = candidates[0 if rng.random() > 0.18 else min(len(candidates) - 1, int(rng.random() * len(candidates)))]
                j, nx, ny, drop = choice
                capacity = max(0.00001, drop * water * (0.82 + strength * 0.38))
                if carried > capacity:
                    deposit = (carried - capacity) * 0.36
                    h[i] += deposit
                    carried -= deposit
                    sediment_seed[i] += deposit
                else:
                    erode = min((capacity - carried) * 0.24, max(height * 0.006, 0.00001)) * strength
                    h[i] -= erode
                    carried += erode
                    sediment_seed[j] += erode * 0.30
                # A small fraction deposits downstream to form banks/deltas.
                h[j] += carried * 0.008 * strength
                x, y = nx, ny
                water *= 0.965
                if water < 0.045:
                    break
    maps = _recompute_terrain_derivatives(h, res, size, height, seed, flow_seed)
    hydro_norm = _normalize_values(flow_seed)
    dep_norm = _normalize_values(sediment_seed)
    maps['hydraulic'] = hydro_norm
    maps['deposition'] = dep_norm
    maps['bank'] = [_clamp(dep_norm[i] * 0.62 + maps['sediment'][i] * 0.38) for i in range(len(h))]
    return maps


def create_terrain(context=None, settings=None):
    ctx = context or bpy.context
    res = max(2, min(512, int(getattr(settings, 'terrain_resolution', 96) or 96)))
    size = float(getattr(settings, 'terrain_size', 12.0) or 12.0)
    height = float(getattr(settings, 'terrain_height', 1.5) or 1.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    iterations = int(getattr(settings, 'terrain_erosion_iterations', 12) or 12)
    droplets = int(getattr(settings, 'terrain_hydraulic_droplets', max(128, res * res // 2)) or 0)
    strength = float(getattr(settings, 'terrain_channel_strength', 1.0) or 1.0)
    maps = _terrain_maps_v5(res, size, height, seed, iterations, droplets, strength)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    for y in range(res):
        fy = (y / (res - 1) - 0.5) * size if res > 1 else 0.0
        for x in range(res):
            fx = (x / (res - 1) - 0.5) * size if res > 1 else 0.0
            i = _terrain_index(x, y, res)
            verts.append((fx, fy, maps['height'][i]))
    for y in range(res - 1):
        for x in range(res - 1):
            a = y * res + x
            faces.append((a, a + 1, a + 1 + res, a + res))
    mesh = bpy.data.meshes.new('SGS_Overdrive_Heightfield_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Overdrive Heightfield Terrain', '地形'), mesh)
    _link_object(obj, ctx)
    attr_specs = [
        ('sgs_height', 'FLOAT', maps['height_norm']), ('sgs_slope', 'FLOAT', maps['slope']),
        ('sgs_convexity', 'FLOAT', maps['convexity']), ('sgs_wetness', 'FLOAT', maps['wetness']),
        ('sgs_flow', 'FLOAT', maps['flow']), ('sgs_erosion', 'FLOAT', maps['erosion']),
        ('sgs_sediment', 'FLOAT', maps['sediment']), ('sgs_biome', 'INT', [int(v) for v in maps['biome']]),
        ('sgs_channel', 'FLOAT', maps['channel']), ('sgs_stream_order', 'FLOAT', maps['stream_order']),
        ('sgs_terrace', 'FLOAT', maps['terrace']), ('sgs_strata', 'INT', [int(v) for v in maps['strata']]),
        ('sgs_hydraulic', 'FLOAT', maps.get('hydraulic', [0.0] * len(verts))),
        ('sgs_deposition', 'FLOAT', maps.get('deposition', [0.0] * len(verts))),
        ('sgs_bank', 'FLOAT', maps.get('bank', [0.0] * len(verts))),
    ]
    for name, dtype, values in attr_specs:
        _write_attr_values(mesh, name, dtype, values)
    attrs = ensure_standard_attributes(obj)
    try:
        obj['sgs_builder'] = 'overdrive_heightfield_terrain'
        obj['sgs_attribute_count'] = len(attrs)
        obj['sgs_erosion_iterations'] = iterations
        obj['sgs_hydraulic_droplets'] = droplets
        obj['sgs_algorithm'] = 'deterministic_fbm_thermal_hydraulic_flow_v5'
    except Exception:
        pass
    return obj


def _radical_inverse(index: int, base: int) -> float:
    inv = 1.0 / float(base)
    f = inv
    result = 0.0
    i = max(0, int(index))
    while i > 0:
        result += f * (i % base)
        i //= base
        f *= inv
    return result


def _sample_triangle_uv(a, b, c, u: float, v: float):
    r1 = math.sqrt(_clamp(u))
    r2 = _clamp(v)
    return _v_add(_v_add(_v_mul(a, 1.0 - r1), _v_mul(b, r1 * (1.0 - r2))), _v_mul(c, r1 * r2))


def _sample_poly_uv(obj, poly, u: float, v: float):
    verts = [_world_vertex(obj, int(i)) for i in poly.vertices]
    if len(verts) < 3:
        return verts[0] if verts else (0.0, 0.0, 0.0)
    tri_weights: list[float] = []
    total = 0.0
    for i in range(1, len(verts) - 1):
        area = _v_len(_v_cross(_v_sub(verts[i], verts[0]), _v_sub(verts[i + 1], verts[0]))) * 0.5
        total += area
        tri_weights.append(total)
    if total <= 1e-12:
        return verts[0]
    pick = _clamp(u) * total
    tri = min(len(tri_weights) - 1, bisect.bisect_left(tri_weights, pick)) + 1
    return _sample_triangle_uv(verts[0], verts[tri], verts[tri + 1], v, (u * 1.61803398875) % 1.0)


def _poisson_accept_variable(point, cell_map: dict[tuple[int, int, int], list[int]], points: list[tuple[float, float, float]], radii: list[float], radius: float, cell_size: float) -> bool:
    if radius <= 1e-9 or cell_size <= 1e-9:
        return True
    key = (math.floor(point[0] / cell_size), math.floor(point[1] / cell_size), math.floor(point[2] / cell_size))
    reach = max(1, int(math.ceil(max(radius, max(radii[-32:] or [radius])) / cell_size)) + 1)
    for dx in range(-reach, reach + 1):
        for dy in range(-reach, reach + 1):
            for dz in range(-reach, reach + 1):
                for idx in cell_map.get((key[0] + dx, key[1] + dy, key[2] + dz), []):
                    min_dist = max(radius, radii[idx])
                    if _v_len(_v_sub(point, points[idx])) < min_dist:
                        return False
    cell_map.setdefault(key, []).append(len(points))
    return True


def create_scatter_points(context=None, settings=None):
    ctx = context or bpy.context
    count = max(1, min(200000, int(getattr(settings, 'scatter_count', 512) or 512)))
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    threshold = float(getattr(settings, 'density_threshold', 0.5) or 0.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    blue_noise = bool(getattr(settings, 'scatter_blue_noise', True))
    adaptive = bool(getattr(settings, 'scatter_adaptive_spacing', True))
    quality_passes = max(1, min(24, int(getattr(settings, 'scatter_quality_passes', 5) or 5)))
    min_spacing = float(getattr(settings, 'scatter_min_spacing', radius * 0.85) or 0.0) if blue_noise else 0.0
    normal_offset = float(getattr(settings, 'scatter_normal_offset', radius * 0.05) or 0.0)
    biome_bias = float(getattr(settings, 'scatter_biome_bias', 0.25) or 0.0)
    visibility_gate = bool(getattr(settings, 'scatter_visibility_culling', False))
    source = node_factory.active_mesh_object(ctx)
    rng = random.Random(seed)
    verts: list[tuple[float, float, float]] = []
    normals: list[tuple[float, float, float]] = []
    tangents: list[tuple[float, float, float]] = []
    densities: list[float] = []
    scales: list[float] = []
    variations: list[float] = []
    source_faces: list[int] = []
    biomes: list[int] = []
    lods: list[float] = []
    habitat_scores: list[float] = []
    visibility_scores: list[float] = []
    ranks: list[float] = []
    radii: list[float] = []
    cell_map: dict[tuple[int, int, int], list[int]] = {}
    if source is not None and getattr(source, 'data', None) is not None and len(source.data.polygons) > 0:
        ensure_standard_attributes(source)
        mesh = source.data
        vcount = _mesh_vertex_count(mesh)
        density_values = _read_attr_values(mesh, 'sgs_density', 1.0, vcount)
        habitat_values = _read_attr_values(mesh, 'sgs_habitat_score', 0.75, vcount)
        visibility_values = _read_attr_values(mesh, 'sgs_visibility', 1.0, vcount)
        biome_values = _read_int_attr(mesh, 'sgs_biome', 1, vcount)
        slope_values = _read_attr_values(mesh, 'sgs_slope', 0.0, vcount)
        quality_values = _read_attr_values(mesh, 'sgs_quality', 0.75, vcount)
        polys = list(mesh.polygons)
        cumulative: list[float] = []
        total = 0.0
        frames = []
        for poly in polys:
            frame = _poly_frame(source, poly)
            frames.append(frame)
            area = frame[4]
            d = _avg_poly_attr(mesh, poly, density_values, 1.0)
            h = _avg_poly_attr(mesh, poly, habitat_values, 0.75)
            q = _avg_poly_attr(mesh, poly, quality_values, 0.75)
            vis = _avg_poly_attr(mesh, poly, visibility_values, 1.0)
            b = _avg_poly_attr(mesh, poly, [float(v) for v in biome_values], 1.0)
            s = _avg_poly_attr(mesh, poly, slope_values, 0.0)
            if visibility_gate and vis <= 0.05:
                weight = 0.0
            else:
                habitat_weight = 1.0 + biome_bias * (1.0 if int(round(b)) in {1, 2} else -0.42)
                weight = max(0.0, area * d * max(0.0, habitat_weight) * (0.58 + h * 0.42) * (0.72 + q * 0.28) * (1.0 - s * 0.36) * (0.25 + vis * 0.75))
            total += weight
            cumulative.append(total)
        attempts = 0
        max_attempts = max(count * max(4, quality_passes * 5), count + 2048)
        base_cell = max(min_spacing * 0.75, radius * 0.12, 1e-6)
        while len(verts) < count and attempts < max_attempts and total > 0.0:
            attempts += 1
            qindex = attempts + seed % 8191
            pick = _radical_inverse(qindex, 2) * total
            poly_index = min(len(cumulative) - 1, bisect.bisect_left(cumulative, pick))
            poly = polys[poly_index]
            center, tangent, bitangent, normal, _area = frames[poly_index]
            d = _avg_poly_attr(mesh, poly, density_values, 1.0)
            hscore = _avg_poly_attr(mesh, poly, habitat_values, 0.75)
            vis = _avg_poly_attr(mesh, poly, visibility_values, 1.0)
            slope = _avg_poly_attr(mesh, poly, slope_values, 0.0)
            if d < threshold and _radical_inverse(qindex, 5) > d / max(1e-6, threshold):
                continue
            point = _sample_poly_uv(source, poly, _radical_inverse(qindex, 3), _radical_inverse(qindex, 5))
            jitter_scale = radius * (0.18 + (1.0 - hscore) * 0.16)
            jitter_u = (_radical_inverse(qindex, 7) - 0.5) * jitter_scale
            jitter_v = (_radical_inverse(qindex, 11) - 0.5) * jitter_scale
            point = _v_add(point, _v_add(_v_mul(tangent, jitter_u), _v_mul(bitangent, jitter_v)))
            point = _v_add(point, _v_mul(normal, normal_offset))
            local_spacing = min_spacing
            if adaptive:
                local_spacing = min_spacing * _clamp(1.22 - d * 0.38 - hscore * 0.18 + slope * 0.18, 0.42, 1.65)
            if not _poisson_accept_variable(point, cell_map, verts, radii, local_spacing, base_cell):
                continue
            verts.append(point)
            normals.append(normal)
            tangents.append(tangent)
            densities.append(_clamp(d))
            local_scale = radius * (0.45 + _radical_inverse(qindex, 13) * 1.05) * (0.62 + d * 0.58) * (0.75 + hscore * 0.25)
            scales.append(local_scale)
            variations.append(_radical_inverse(qindex, 17))
            source_faces.append(poly_index)
            biomes.append(int(round(_avg_poly_attr(mesh, poly, [float(v) for v in biome_values], 1.0))))
            lods.append(_clamp(d * 0.52 + (1.0 - slope) * 0.22 + vis * 0.16 + hscore * 0.10))
            habitat_scores.append(_clamp(hscore))
            visibility_scores.append(_clamp(vis))
            ranks.append(len(verts) / max(1, count))
            radii.append(max(local_spacing, radius * 0.02))
    if not verts:
        side = max(1, int(math.sqrt(count)) + 1)
        attempts = 0
        base_cell = max(min_spacing * 0.75, radius * 0.12, 1e-6)
        while len(verts) < count and attempts < count * 24:
            attempts += 1
            u = _radical_inverse(attempts + seed, 2)
            v = _radical_inverse(attempts + seed, 3)
            x = (u - 0.5) * side * radius * 4.0
            y = (v - 0.5) * side * radius * 4.0
            p = (x, y, 0.0)
            local_spacing = min_spacing * (0.85 + _radical_inverse(attempts + seed, 5) * 0.3)
            if not _poisson_accept_variable(p, cell_map, verts, radii, local_spacing, base_cell):
                continue
            verts.append(p)
            normals.append((0.0, 0.0, 1.0))
            tangents.append((1.0, 0.0, 0.0))
            d = _radical_inverse(attempts + seed, 7)
            densities.append(d)
            scales.append(radius * (0.5 + _radical_inverse(attempts + seed, 11)))
            variations.append(_radical_inverse(attempts + seed, 13))
            source_faces.append(-1)
            biomes.append(1)
            lods.append(d)
            habitat_scores.append(d)
            visibility_scores.append(1.0)
            ranks.append(len(verts) / max(1, count))
            radii.append(local_spacing)
    mesh = bpy.data.meshes.new('SGS_Overdrive_Surface_Distribution_Mesh')
    mesh.from_pydata(verts, [], [])
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Overdrive Surface Distribution Points', '分布ポイント'), mesh)
    _link_object(obj, ctx)
    _write_attr_values(mesh, 'sgs_id', 'INT', list(range(len(verts))))
    _write_attr_values(mesh, 'sgs_density', 'FLOAT', densities)
    _write_attr_values(mesh, 'sgs_scale', 'FLOAT', scales)
    _write_attr_values(mesh, 'sgs_variation', 'FLOAT', variations)
    _write_attr_values(mesh, 'sgs_normal', 'FLOAT_VECTOR', normals)
    _write_attr_values(mesh, 'sgs_tangent', 'FLOAT_VECTOR', tangents)
    _write_attr_values(mesh, 'sgs_source_face', 'INT', source_faces)
    _write_attr_values(mesh, 'sgs_biome', 'INT', biomes)
    _write_attr_values(mesh, 'sgs_lod', 'FLOAT', lods)
    _write_attr_values(mesh, 'sgs_cull', 'FLOAT', [1.0 if v >= 0.08 and visibility_scores[i] > 0.05 else 0.0 for i, v in enumerate(lods)])
    _write_attr_values(mesh, 'sgs_habitat_score', 'FLOAT', habitat_scores)
    _write_attr_values(mesh, 'sgs_visibility', 'FLOAT', visibility_scores)
    _write_attr_values(mesh, 'sgs_distribution_rank', 'FLOAT', ranks)
    _write_attr_values(mesh, 'sgs_spacing_radius', 'FLOAT', radii)
    try:
        obj['sgs_builder'] = 'overdrive_surface_distribution'
        obj['sgs_algorithm'] = 'weighted_area_halton_adaptive_poisson_v5'
        obj['sgs_requested_count'] = count
        obj['sgs_accepted_count'] = len(verts)
        obj['sgs_quality_passes'] = quality_passes
        obj['sgs_adaptive_spacing'] = adaptive
        if source:
            obj['sgs_source_object'] = source.name
    except Exception:
        pass
    return obj


def _strip_outer_parens(text: str) -> str:
    text = text.strip()
    while text.startswith('(') and text.endswith(')'):
        depth = 0
        ok = True
        for i, char in enumerate(text):
            if char == '(':
                depth += 1
            elif char == ')':
                depth -= 1
                if depth == 0 and i != len(text) - 1:
                    ok = False
                    break
        if not ok:
            break
        text = text[1:-1].strip()
    return text


def _split_text_operator(expression: str, operator: str) -> list[str]:
    result: list[str] = []
    depth = 0
    start = 0
    op = f' {operator} '
    lower = expression.lower()
    i = 0
    while i < len(expression):
        char = expression[i]
        if char == '(':
            depth += 1
            i += 1
            continue
        if char == ')':
            depth = max(0, depth - 1)
            i += 1
            continue
        if depth == 0 and lower.startswith(op, i):
            part = expression[start:i].strip()
            if part:
                result.append(part)
            i += len(op)
            start = i
            continue
        i += 1
    tail = expression[start:].strip()
    if tail:
        result.append(tail)
    return result


def _neighbor_expand(indices: set[int], neighbors: list[set[int]], steps: int) -> set[int]:
    result = set(indices)
    frontier = set(indices)
    for _ in range(max(0, steps)):
        nxt = set(frontier)
        for idx in frontier:
            if 0 <= idx < len(neighbors):
                nxt.update(neighbors[idx])
        frontier = nxt - result
        result.update(nxt)
        if not frontier:
            break
    return result


def _neighbor_shrink(indices: set[int], neighbors: list[set[int]], steps: int, universe: set[int]) -> set[int]:
    result = set(indices)
    for _ in range(max(0, steps)):
        remove = set()
        for idx in result:
            if any(n not in result for n in neighbors[idx]):
                remove.add(idx)
        result -= remove
        if not remove:
            break
    return result & universe


def apply_selection_string(obj, expression: str) -> int:
    """v5: recursive boolean selector with parentheses, grow/shrink, rank bands, and set membership."""
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    mesh = getattr(obj, 'data', None)
    count = _mesh_vertex_count(mesh) if mesh else 0
    if count <= 0:
        return 0
    ensure_standard_attributes(obj)
    neighbors, _boundary = _mesh_neighbors(mesh)
    universe = set(range(count))

    def token_eval(token: str) -> set[int]:
        token = _strip_outer_parens(token.strip().lower())
        if not token:
            return set()
        if token.startswith('not '):
            return universe - eval_expr(token[4:].strip())
        grow = re.fullmatch(r'grow\((\d+)\s*,\s*(.+)\)', token)
        if grow:
            return _neighbor_expand(eval_expr(grow.group(2)), neighbors, int(grow.group(1)))
        shrink = re.fullmatch(r'shrink\((\d+)\s*,\s*(.+)\)', token)
        if shrink:
            return _neighbor_shrink(eval_expr(shrink.group(2)), neighbors, int(shrink.group(1)), universe)
        band = re.fullmatch(r'band\(([^,]+),\s*([-+0-9.]+),\s*([-+0-9.]+)\)', token)
        if band:
            values = _read_attr_values(mesh, _attr_name_from_token(band.group(1)), 0.0, count)
            center = float(band.group(2)); width = abs(float(band.group(3)))
            return {i for i, v in enumerate(values) if abs(v - center) <= width * 0.5}
        rank = re.fullmatch(r'rank\(([^,]+),\s*([-+0-9.]+)\s*-\s*([-+0-9.]+)\)', token)
        if rank:
            values = _rank_values(_read_attr_values(mesh, _attr_name_from_token(rank.group(1)), 0.0, count))
            lo = _clamp(float(rank.group(2))); hi = _clamp(float(rank.group(3)))
            if lo > hi:
                lo, hi = hi, lo
            return {i for i, v in enumerate(values) if lo <= v <= hi}
        member = re.fullmatch(r'([a-zA-Z0-9_]+)\s+in\s+([0-9,|\s-]+)', token)
        if member:
            values = _read_int_attr(mesh, _attr_name_from_token(member.group(1)), 0, count)
            allowed = {int(v) for v in re.findall(r'-?\d+', member.group(2))}
            return {i for i, v in enumerate(values) if v in allowed}
        return _selection_token(mesh, token, count)

    def eval_expr(expr: str) -> set[int]:
        expr = _strip_outer_parens(expr.strip().lower())
        if not expr:
            return set()
        if expr.startswith('invert:'):
            return universe - eval_expr(expr[len('invert:'):])
        # Highest precedence is handled by recursion after splitting low-precedence operators.
        parts = _split_text_operator(expr, 'or')
        if len(parts) > 1:
            result: set[int] = set()
            for part in parts:
                result |= eval_expr(part)
            return result
        parts = _split_text_operator(expr, 'xor')
        if len(parts) > 1:
            result: set[int] = set()
            for part in parts:
                result ^= eval_expr(part)
            return result
        parts = _split_text_operator(expr, 'except')
        if len(parts) > 1:
            result = eval_expr(parts[0])
            for part in parts[1:]:
                result -= eval_expr(part)
            return result
        parts = _split_text_operator(expr, 'and')
        if len(parts) > 1:
            result = universe.copy()
            for part in parts:
                result &= eval_expr(part)
            return result
        # Top-level comma and pipe remain union separators for compact selection-string syntax.
        comma_parts = _split_top_level(expr, (',', '|'))
        if len(comma_parts) > 1:
            result: set[int] = set()
            for part in comma_parts:
                result |= eval_expr(part)
            return result
        return token_eval(expr)

    selected = eval_expr(str(expression or 'all'))
    values = [1.0 if i in selected else 0.0 for i in range(count)]
    _write_attr_values(mesh, 'sgs_selection', 'FLOAT', values)
    try:
        group = obj.vertex_groups.get('SGS Selection') or obj.vertex_groups.new(name='SGS Selection')
        for i, value in enumerate(values):
            group.add([i], value, 'REPLACE')
    except Exception:
        pass
    try:
        obj['sgs_selection_string'] = str(expression or '')
        obj['sgs_selection_count'] = len(selected)
        obj['sgs_selection_engine'] = 'recursive_boolean_rank_grow_shrink_v5'
    except Exception:
        pass
    return len(selected)


def _point_in_outline(x: float, y: float, outline: list[tuple[float, float]]) -> bool:
    inside = False
    for i, (ax, ay) in enumerate(outline):
        bx, by = outline[i - 1]
        if (ay > y) != (by > y) and x < (bx - ax) * (y - ay) / (by - ay) + ax:
            inside = not inside
    return inside


def create_greeble_blocks(context=None, settings=None):
    ctx = context or bpy.context
    count = max(1, min(8000, int(getattr(settings, 'scatter_count', 192) or 192)))
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    threshold = float(getattr(settings, 'density_threshold', 0.5) or 0.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    rng = random.Random(seed)
    source = node_factory.active_mesh_object(ctx)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    panel_ids: list[int] = []
    panel_heights: list[float] = []
    panel_kinds: list[int] = []
    if source is not None and getattr(source, 'data', None) is not None and len(source.data.polygons) > 0:
        ensure_standard_attributes(source)
        mesh = source.data
        density = _read_attr_values(mesh, 'sgs_density', 1.0, _mesh_vertex_count(mesh))
        ridge = _read_attr_values(mesh, 'sgs_ridge', 0.0, _mesh_vertex_count(mesh))
        valley = _read_attr_values(mesh, 'sgs_valley', 0.0, _mesh_vertex_count(mesh))
        quality = _read_attr_values(mesh, 'sgs_quality', 0.75, _mesh_vertex_count(mesh))
        polys = list(mesh.polygons)
        rank = [_avg_poly_attr(mesh, poly, density, 1.0) * 0.7 + _avg_poly_attr(mesh, poly, quality, 0.75) * 0.3 for poly in polys]
        spacing = 0.0
        if len(polys) > count:
            # More faces than blocks: sample by area and rank so the blocks reach the whole surface.
            weights = [max(1e-9, float(poly.area)) * max(1e-3, rank[i]) for i, poly in enumerate(polys)]
            step = sum(weights) / count
            shares: dict[int, float] = {}
            walked = 0.0
            target = rng.random() * step
            placed = 0
            for i, weight in enumerate(weights):
                walked += weight
                while walked > target and placed < count:
                    shares[i] = shares.get(i, 0.0) + 1.0
                    placed += 1
                    target = (placed + rng.random()) * step
            used = list(shares)
            frames = {i: _poly_frame(source, polys[i]) for i in used}
            local_area = max(1e-9, sum(float(polys[i].area) for i in used))
            world_area = sum(frames[i][4] for i in used) / local_area * sum(float(poly.area) for poly in polys)
            spacing = math.sqrt(world_area / count)
        else:
            used = sorted(range(len(polys)), key=lambda i: rank[i], reverse=True)
            frames = {i: _poly_frame(source, polys[i]) for i in used}
            total_area = max(1e-9, sum(frames[i][4] for i in used))
            # Share the target amount by face area.
            shares = {i: count * frames[i][4] / total_area for i in used}
        local_id = 0
        for poly_index in used:
            poly = polys[poly_index]
            d = _avg_poly_attr(mesh, poly, density, 1.0)
            q = _avg_poly_attr(mesh, poly, quality, 0.75)
            center, u, v, n, area = frames[poly_index]
            # Lay the blocks out over the whole face.
            subdivisions = max(1, int(math.sqrt(shares[poly_index])))
            outline = [_v_sub(_world_vertex(source, int(i)), center) for i in poly.vertices]
            outline = [(sum(c[k] * u[k] for k in range(3)), sum(c[k] * v[k] for k in range(3))) for c in outline]
            min_u, max_u = min(c[0] for c in outline), max(c[0] for c in outline)
            min_v, max_v = min(c[1] for c in outline), max(c[1] for c in outline)
            cell_u = (max_u - min_u) / subdivisions
            cell_v = (max_v - min_v) / subdivisions
            for syi in range(subdivisions):
                for sxi in range(subdivisions):
                    if d < threshold and rng.random() > d / max(1e-6, threshold):
                        continue
                    pos_u = min_u + (sxi + 0.5) * cell_u
                    pos_v = min_v + (syi + 0.5) * cell_v
                    if subdivisions > 1 and not _point_in_outline(pos_u, pos_v, outline):
                        continue
                    s = min(radius * (0.38 + rng.random() ** 2 * 1.35) * (0.72 + d * 0.52), max(cell_u, spacing) * 0.92)
                    sy = min(s * (0.45 + rng.random() * 1.05), max(cell_v, spacing) * 0.92)
                    pos_u += (rng.random() - 0.5) * max(0.0, cell_u - s)
                    pos_v += (rng.random() - 0.5) * max(0.0, cell_v - sy)
                    pc = _v_add(center, _v_add(_v_mul(u, pos_u), _v_mul(v, pos_v)))
                    # Most blocks stay low; none may grow into a spire taller than its footprint allows.
                    h = min(radius * (0.24 + rng.random() ** 2 * 1.6) * (0.65 + q * 0.55), max(s, sy) * 1.5)
                    start = _add_oriented_box(verts, faces, _v_add(pc, _v_mul(n, h * 0.5)), u, v, n, s, sy, h)
                    kind = 1
                    if _avg_poly_attr(mesh, poly, ridge, 0.0) > 0.55:
                        kind = 2
                    elif _avg_poly_attr(mesh, poly, valley, 0.0) > 0.55:
                        kind = 3
                    panel_ids.extend([local_id] * 8)
                    panel_heights.extend([h] * 8)
                    panel_kinds.extend([kind] * 8)
                    local_id += 1
                    if local_id >= count:
                        break
                if local_id >= count:
                    break
            if local_id >= count:
                break
    if not verts:
        side = int(math.sqrt(count)) + 1
        for i in range(count):
            u = _radical_inverse(i + seed + 1, 2)
            v = _radical_inverse(i + seed + 1, 3)
            x = (u - 0.5) * side * radius * 4.0
            y = (v - 0.5) * side * radius * 4.0
            s = radius * (0.5 + _radical_inverse(i + seed + 1, 5))
            h = radius * (0.5 + _radical_inverse(i + seed + 1, 7) * 4.0)
            _add_box(verts, faces, (x, y, h * 0.5), s, s * (0.6 + _radical_inverse(i + seed + 1, 11)), h)
            panel_ids.extend([i] * 8)
            panel_heights.extend([h] * 8)
            panel_kinds.extend([1] * 8)
    mesh = bpy.data.meshes.new('SGS_Overdrive_Surface_Detail_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Overdrive Surface Detail Panelizer', '表面ディテールブロック'), mesh)
    _link_object(obj, ctx)
    ensure_standard_attributes(obj)
    _write_attr_values(mesh, 'sgs_panel_id', 'INT', panel_ids)
    _write_attr_values(mesh, 'sgs_panel_height', 'FLOAT', panel_heights)
    _write_attr_values(mesh, 'sgs_panel_kind', 'INT', panel_kinds)
    try:
        obj['sgs_builder'] = 'overdrive_surface_detail_panelizer'
        obj['sgs_algorithm'] = 'density_quality_ranked_subpanel_normals_v5'
    except Exception:
        pass
    return obj


def create_ivy_curve(context=None, settings=None):
    ctx = context or bpy.context
    amount = max(4, min(8000, int(getattr(settings, 'scatter_count', 128) or 128)))
    radius = float(getattr(settings, 'scatter_radius', 0.1) or 0.1)
    seed = int(getattr(settings, 'random_seed', 1729))
    branches = max(1, min(96, int(getattr(settings, 'growth_branches', 5) or 5)))
    rng = random.Random(seed)
    source = node_factory.active_mesh_object(ctx)
    base_size = 4.0
    zmax = 4.0
    origin = (0.0, 0.0, 0.0)
    if source is not None:
        try:
            dims = source.dimensions
            base_size = max(float(dims.x), float(dims.y), 1.0)
            zmax = max(float(dims.z), 1.0)
            origin = _to_tuple(source.location)
        except Exception:
            pass
    curve = bpy.data.curves.new('SGS_Overdrive_Growth_Curve', type='CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 5
    curve.bevel_depth = radius * 0.12
    curve.bevel_resolution = 2
    per_branch = max(5, amount // branches)
    for branch in range(branches):
        parent_phase = rng.random() * math.tau
        climb = 0.68 + rng.random() * 0.62
        radial = base_size * (0.08 + rng.random() * 0.16)
        for child in range(1 + (1 if branch % 3 == 0 and branches < 80 else 0)):
            spline = curve.splines.new('POLY')
            points = per_branch if child == 0 else max(5, per_branch // 3)
            spline.points.add(points - 1)
            child_offset = child * 0.33 + rng.random() * 0.14
            for i, point in enumerate(spline.points):
                t = i / max(1, points - 1)
                tt = t if child == 0 else _clamp(t * 0.75 + child_offset)
                angle = parent_phase + tt * math.pi * (2.1 + rng.random() * 0.44) + math.sin(tt * 13.0 + branch) * 0.22
                r = radial * (0.72 + 0.36 * math.sin(tt * 6.5 + branch) + child * 0.24)
                curl = math.sin(tt * 24.0 + branch * 0.7) * radius * 0.45
                x = origin[0] + math.cos(angle) * (r + curl)
                y = origin[1] + math.sin(angle) * (r - curl)
                z = origin[2] + (tt ** climb) * zmax + math.sin(tt * 18.0 + branch) * radius * (0.5 + child * 0.5)
                point.co = (x, y, z, 1.0)
    obj = bpy.data.objects.new(_object_name('SGS Overdrive Organic Growth Curves', '有機成長カーブ'), curve)
    _link_object(obj, ctx)
    try:
        obj['sgs_builder'] = 'overdrive_organic_growth_curves'
        obj['sgs_branches'] = branches
        obj['sgs_algorithm'] = 'multi_branch_child_tendril_deterministic_growth_v5'
        if source:
            obj['sgs_source_object'] = source.name
    except Exception:
        pass
    return obj


def explode_mesh_to_pieces(context=None, settings=None) -> list[Any]:
    ctx = context or bpy.context
    source = node_factory.active_mesh_object(ctx)
    if source is None or getattr(source, 'data', None) is None or len(source.data.polygons) == 0:
        return []
    requested = int(getattr(settings, 'fragment_piece_count', 0) or 0)
    if requested <= 0:
        requested = int(getattr(settings, 'scatter_count', 64) or 64)
    k = max(1, min(768, requested))
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    seed = int(getattr(settings, 'random_seed', 1729))
    rng = random.Random(seed)
    mesh = source.data
    polys = list(mesh.polygons)
    centers = []
    areas = []
    for poly in polys:
        coords = [_world_vertex(source, int(i)) for i in poly.vertices]
        centers.append((sum(c[0] for c in coords) / len(coords), sum(c[1] for c in coords) / len(coords), sum(c[2] for c in coords) / len(coords)))
        areas.append(float(getattr(poly, 'area', 0.0) or 0.0))
    if not centers:
        return []
    # Farthest-point seeding then a few centroidal refinement passes improve piece balance over random seeds.
    seed_centers = [centers[(seed * 2654435761) % len(centers)]]
    while len(seed_centers) < min(k, len(centers)):
        next_idx = max(range(len(centers)), key=lambda i: min(_v_len(_v_sub(centers[i], s)) for s in seed_centers) * (0.65 + areas[i]))
        seed_centers.append(centers[next_idx])
    assignments = [0] * len(centers)
    for _pass in range(4):
        buckets: dict[int, list[int]] = {i: [] for i in range(len(seed_centers))}
        for poly_index, center in enumerate(centers):
            closest = min(range(len(seed_centers)), key=lambda idx: _v_len(_v_sub(center, seed_centers[idx])))
            assignments[poly_index] = closest
            buckets[closest].append(poly_index)
        for idx, bucket in buckets.items():
            if not bucket:
                continue
            denom = max(1e-9, sum(areas[i] + 1e-6 for i in bucket))
            seed_centers[idx] = (
                sum(centers[i][0] * (areas[i] + 1e-6) for i in bucket) / denom,
                sum(centers[i][1] * (areas[i] + 1e-6) for i in bucket) / denom,
                sum(centers[i][2] * (areas[i] + 1e-6) for i in bucket) / denom,
            )
    clusters: dict[int, list[int]] = {i: [] for i in range(len(seed_centers))}
    for poly_index, cluster in enumerate(assignments):
        clusters.setdefault(cluster, []).append(poly_index)
    all_center = (sum(c[0] for c in centers) / len(centers), sum(c[1] for c in centers) / len(centers), sum(c[2] for c in centers) / len(centers))
    created = []
    for piece_id, poly_indices in clusters.items():
        if not poly_indices:
            continue
        verts: list[tuple[float, float, float]] = []
        faces: list[tuple[int, ...]] = []
        index_map: dict[int, int] = {}
        piece_center = (sum(centers[i][0] for i in poly_indices) / len(poly_indices), sum(centers[i][1] for i in poly_indices) / len(poly_indices), sum(centers[i][2] for i in poly_indices) / len(poly_indices))
        direction = _v_norm(_v_sub(piece_center, all_center), (rng.random() - 0.5, rng.random() - 0.5, rng.random()))
        energy = 0.85 + len(poly_indices) / max(1, len(polys)) * 2.4 + rng.random() * 0.35
        offset = _v_add(_v_mul(direction, radius * (1.2 + energy * 2.7)), (0.0, 0.0, radius * rng.random() * 1.8))
        for poly_index in poly_indices:
            poly = polys[poly_index]
            face = []
            for old_i in poly.vertices:
                old_i = int(old_i)
                if old_i not in index_map:
                    co = _world_vertex(source, old_i)
                    # Pull very slightly toward the piece center to expose seams without destroying shape identity.
                    seam_pull = _v_mul(_v_sub(piece_center, co), 0.012)
                    index_map[old_i] = len(verts)
                    verts.append(_v_add(_v_add(co, offset), seam_pull))
                face.append(index_map[old_i])
            faces.append(tuple(face))
        piece_mesh = bpy.data.meshes.new(f'SGS_Overdrive_Fragment_{piece_id:03d}_Mesh')
        piece_mesh.from_pydata(verts, [], faces)
        piece_mesh.update()
        obj = bpy.data.objects.new(_object_name(f'SGS Overdrive Fragment {piece_id:03d}', _fragment_name_ja(piece_id)), piece_mesh)
        try:
            ctx.collection.objects.link(obj)
        except Exception:
            try:
                bpy.context.collection.objects.link(obj)
            except Exception:
                pass
        _write_attr_values(piece_mesh, 'sgs_piece_id', 'INT', [piece_id] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_variation', 'FLOAT', [_radical_inverse(piece_id + seed + 1, 2)] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_mass', 'FLOAT', [float(len(poly_indices))] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_energy', 'FLOAT', [energy] * len(verts))
        try:
            obj['sgs_builder'] = 'overdrive_mesh_fragment_builder'
            obj['sgs_source_object'] = source.name
            obj['sgs_piece_id'] = piece_id
            obj['sgs_face_count'] = len(poly_indices)
            obj['sgs_algorithm'] = 'farthest_point_centroidal_cluster_fragments_v5'
            node_factory.mark_created_object(obj)
        except Exception:
            pass
        created.append(obj)
    return created


# -----------------------------------------------------------------------------
# SGS v6 hyper-precision overrides
# -----------------------------------------------------------------------------

_SGS_V5_ensure_standard_attributes = ensure_standard_attributes
_SGS_V5_create_terrain = create_terrain
_SGS_V5_create_scatter_points = create_scatter_points
_SGS_V5_apply_selection_string = apply_selection_string
_SGS_V5_explode_mesh_to_pieces = explode_mesh_to_pieces


def _v6_normalize_int_labels(labels: list[int]) -> list[int]:
    remap: dict[int, int] = {}
    result: list[int] = []
    for value in labels:
        key = int(value)
        if key not in remap:
            remap[key] = len(remap)
        result.append(remap[key])
    return result


def _v6_graph_distance_from_mask(neighbors: list[set[int]], source_mask: list[bool]) -> list[float]:
    count = len(neighbors)
    if count <= 0:
        return []
    dist = [10**9] * count
    q = deque()
    for i, flag in enumerate(source_mask):
        if flag:
            dist[i] = 0
            q.append(i)
    if not q:
        return [0.0] * count
    while q:
        i = q.popleft()
        nd = dist[i] + 1
        for j in neighbors[i]:
            if nd < dist[j]:
                dist[j] = nd
                q.append(j)
    finite = [d for d in dist if d < 10**9]
    max_d = max(finite) if finite else 1
    return [_clamp(1.0 - (d / max(1, max_d))) if d < 10**9 else 0.0 for d in dist]


def _v6_watershed_labels_from_vertex_graph(mesh, heights: list[float], neighbors: list[set[int]]) -> list[int]:
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    sink_cache = [-1] * count
    for start in range(count):
        if sink_cache[start] >= 0:
            continue
        path: list[int] = []
        seen: set[int] = set()
        i = start
        while True:
            if sink_cache[i] >= 0:
                sink = sink_cache[i]
                break
            if i in seen:
                sink = i
                break
            seen.add(i)
            path.append(i)
            lower = [j for j in neighbors[i] if 0 <= j < count and heights[j] < heights[i] - 1e-8]
            if not lower:
                sink = i
                break
            i = min(lower, key=lambda j: (heights[j], _v_len(_v_sub(_to_tuple(mesh.vertices[j].co), _to_tuple(mesh.vertices[path[-1]].co)))))
        for p in path:
            sink_cache[p] = sink
    return _v6_normalize_int_labels(sink_cache)


def _v6_grid_watershed_labels(h: list[float], res: int) -> list[int]:
    if not h:
        return []
    labels = [-1] * len(h)
    for start in range(len(h)):
        if labels[start] >= 0:
            continue
        path: list[int] = []
        seen: set[int] = set()
        i = start
        while True:
            if labels[i] >= 0:
                sink = labels[i]
                break
            if i in seen:
                sink = i
                break
            seen.add(i)
            path.append(i)
            x = i % res
            y = i // res
            lower = []
            for nx, ny in _terrain_neighbors8(x, y, res):
                j = _terrain_index(nx, ny, res)
                if h[j] < h[i] - 1e-8:
                    lower.append(j)
            if not lower:
                sink = i
                break
            i = min(lower, key=lambda j: h[j])
        for p in path:
            labels[p] = sink
    return _v6_normalize_int_labels(labels)


def _v6_read_vector_attr(mesh, name: str, fallback=(0.0, 0.0, 1.0), count: int | None = None) -> list[tuple[float, float, float]]:
    if count is None:
        count = _mesh_vertex_count(mesh)
    result = [fallback] * int(count or 0)
    try:
        attr = mesh.attributes.get(name)
        if attr is None:
            return result
        data = attr.data
        for i in range(min(len(result), len(data))):
            item = data[i]
            if hasattr(item, 'vector'):
                result[i] = _to_tuple(item.vector)
            elif hasattr(item, 'color'):
                c = item.color
                result[i] = (float(c[0]), float(c[1]), float(c[2]))
            elif hasattr(item, 'value'):
                v = float(item.value)
                result[i] = (v, v, v)
    except Exception:
        pass
    return result


def _v6_nearest_distances(points: list[tuple[float, float, float]], radii: list[float] | None = None) -> list[float]:
    count = len(points)
    if count <= 1:
        return [0.0] * count
    if radii:
        positives = [max(1e-6, float(r)) for r in radii if float(r) > 0.0]
        cell_size = max(1e-6, sum(positives) / max(1, len(positives)))
    else:
        xs = [p[0] for p in points]; ys = [p[1] for p in points]; zs = [p[2] for p in points]
        diag = _v_len((max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)))
        cell_size = max(1e-6, diag / max(8.0, math.sqrt(count)))
    cells = _rebuild_cell_map(points, cell_size)
    distances = [float('inf')] * count
    for i, point in enumerate(points):
        key = _grid_cell_key(point, cell_size)
        found = False
        reach = 1
        while not found and reach <= 6:
            for dx in range(-reach, reach + 1):
                for dy in range(-reach, reach + 1):
                    for dz in range(-reach, reach + 1):
                        for j in cells.get((key[0] + dx, key[1] + dy, key[2] + dz), []):
                            if i == j:
                                continue
                            d = _v_len(_v_sub(point, points[j]))
                            if d < distances[i]:
                                distances[i] = d
                                found = True
            reach += 1
        if distances[i] == float('inf'):
            distances[i] = 0.0
    return distances


def _v6_tangent_relax_points(points: list[tuple[float, float, float]], normals: list[tuple[float, float, float]], radii: list[float], iterations: int, strength: float) -> list[tuple[float, float, float]]:
    if len(points) <= 1 or iterations <= 0:
        return points
    pts = list(points)
    base = max(1e-6, sum(max(1e-6, r) for r in radii) / max(1, len(radii)))
    for _pass in range(max(0, iterations)):
        cells = _rebuild_cell_map(pts, base)
        updates: list[tuple[float, float, float]] = []
        for i, point in enumerate(pts):
            radius = max(base * 0.2, radii[i] if i < len(radii) else base)
            push = (0.0, 0.0, 0.0)
            seen = 0
            key = _grid_cell_key(point, base)
            reach = max(1, int(math.ceil(radius * 2.4 / base)))
            for dx in range(-reach, reach + 1):
                for dy in range(-reach, reach + 1):
                    for dz in range(-reach, reach + 1):
                        for j in cells.get((key[0] + dx, key[1] + dy, key[2] + dz), []):
                            if i == j:
                                continue
                            delta = _v_sub(point, pts[j])
                            dist = _v_len(delta)
                            target = max(radius, radii[j] if j < len(radii) else radius)
                            if 1e-9 < dist < target * 2.0:
                                force = (target * 2.0 - dist) / max(target * 2.0, 1e-9)
                                push = _v_add(push, _v_mul(_v_norm(delta), force))
                                seen += 1
            if seen:
                n = _v_norm(normals[i] if i < len(normals) else (0.0, 0.0, 1.0))
                # remove the normal component so the point moves mostly in the tangent plane.
                push = _v_sub(push, _v_mul(n, _v_dot(push, n)))
                updates.append(_v_mul(push, strength / max(1, seen)))
            else:
                updates.append((0.0, 0.0, 0.0))
        pts = [_v_add(p, updates[i]) for i, p in enumerate(pts)]
    return pts


def ensure_standard_attributes(obj) -> list[str]:
    """v6: synthesize hydrology, visibility, material, and quality fields on top of the v5 layer."""
    written = list(_SGS_V5_ensure_standard_attributes(obj) or [])
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return written
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return written
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return written
    try:
        mesh.update()
        mesh.calc_normals()
    except Exception:
        pass
    neighbors, boundary = _mesh_neighbors(mesh)
    heights = _read_attr_values(mesh, 'sgs_height', 0.0, count)
    slopes = _read_attr_values(mesh, 'sgs_slope', 0.0, count)
    curvature = _read_attr_values(mesh, 'sgs_curvature', 0.0, count)
    convexity = _read_attr_values(mesh, 'sgs_convexity', 0.5, count)
    density = _read_attr_values(mesh, 'sgs_density', 1.0, count)
    wetness = _read_attr_values(mesh, 'sgs_wetness', 0.0, count)
    flow = _read_attr_values(mesh, 'sgs_flow', 0.0, count)
    erosion = _read_attr_values(mesh, 'sgs_erosion', 0.0, count)
    sediment = _read_attr_values(mesh, 'sgs_sediment', 0.0, count)
    ambient = _read_attr_values(mesh, 'sgs_ambient', 0.5, count)
    edge_distance = _read_attr_values(mesh, 'sgs_edge_distance', 1.0, count)
    quality = _read_attr_values(mesh, 'sgs_quality', 0.5, count)
    habitat = _read_attr_values(mesh, 'sgs_habitat_score', 0.5, count)
    visibility = _read_attr_values(mesh, 'sgs_visibility', 1.0, count)
    channel = _read_attr_values(mesh, 'sgs_channel', 0.0, count)
    ridge = _read_attr_values(mesh, 'sgs_ridge', 0.0, count)
    valley = _read_attr_values(mesh, 'sgs_valley', 0.0, count)
    biome = _read_int_attr(mesh, 'sgs_biome', 1, count)
    height_variance = _neighbor_variance(heights, neighbors)
    biome_float = [float(v) for v in biome]
    biome_transition = _neighbor_variance(biome_float, neighbors)
    watershed = _v6_watershed_labels_from_vertex_graph(mesh, heights, neighbors)
    channel_mask = [channel[i] > 0.48 or flow[i] > 0.82 for i in range(count)]
    channel_influence = _v6_graph_distance_from_mask(neighbors, channel_mask)
    principal_curvature = _normalize_values([curvature[i] * 0.42 + height_variance[i] * 0.26 + abs(convexity[i] - 0.5) * 0.64 for i in range(count)])
    cavity = [_clamp(valley[i] * 0.40 + (1.0 - ambient[i]) * 0.24 + wetness[i] * 0.18 + sediment[i] * 0.18) for i in range(count)]
    occlusion = [_clamp(cavity[i] * 0.54 + (1.0 - visibility[i]) * 0.20 + (1.0 - edge_distance[i]) * 0.16 + valley[i] * 0.10) for i in range(count)]
    accessibility = [_clamp(edge_distance[i] * 0.30 + visibility[i] * 0.28 + quality[i] * 0.22 + (1.0 - slopes[i]) * 0.20) for i in range(count)]
    contour = [((heights[i] * 17.0) % 1.0) for i in range(count)]
    contour_line = [_clamp(1.0 - abs(v - 0.5) * 2.0) for v in contour]
    micro_relief = _normalize_values([height_variance[i] * 0.42 + principal_curvature[i] * 0.32 + _value_noise2(i * 0.037, heights[i] * 3.17, 9901) * 0.26 for i in range(count)])
    deposition_balance = [_clamp(sediment[i] * 0.48 + wetness[i] * 0.20 + channel_influence[i] * 0.20 - erosion[i] * 0.16 + 0.20) for i in range(count)]
    material_blend = [_clamp(habitat[i] * 0.30 + wetness[i] * 0.20 + ridge[i] * 0.16 + cavity[i] * 0.18 + biome_transition[i] * 0.16) for i in range(count)]
    distribution_weight = [_clamp(density[i] * 0.36 + habitat[i] * 0.28 + accessibility[i] * 0.18 + (1.0 - slopes[i]) * 0.14 + visibility[i] * 0.04) for i in range(count)]
    remesh_target = [_clamp(0.18 + slopes[i] * 0.22 + principal_curvature[i] * 0.25 + channel[i] * 0.20 + micro_relief[i] * 0.15) for i in range(count)]
    debug_score = [_clamp(quality[i] * 0.28 + distribution_weight[i] * 0.28 + accessibility[i] * 0.18 + (1.0 - occlusion[i]) * 0.14 + channel_influence[i] * 0.12) for i in range(count)]
    flow_direction = _flow_direction_values(mesh, heights, neighbors)
    specs = [
        ('sgs_principal_curvature', 'FLOAT', principal_curvature),
        ('sgs_cavity', 'FLOAT', cavity),
        ('sgs_occlusion', 'FLOAT', occlusion),
        ('sgs_accessibility', 'FLOAT', accessibility),
        ('sgs_watershed', 'INT', watershed),
        ('sgs_contour', 'FLOAT', contour),
        ('sgs_contour_line', 'FLOAT', contour_line),
        ('sgs_channel_influence', 'FLOAT', channel_influence),
        ('sgs_micro_relief', 'FLOAT', micro_relief),
        ('sgs_biome_transition', 'FLOAT', biome_transition),
        ('sgs_deposition_balance', 'FLOAT', deposition_balance),
        ('sgs_material_blend', 'FLOAT', material_blend),
        ('sgs_distribution_weight', 'FLOAT', distribution_weight),
        ('sgs_remesh_target_size', 'FLOAT', remesh_target),
        ('sgs_debug_score', 'FLOAT', debug_score),
        ('sgs_flow_direction', 'FLOAT_VECTOR', flow_direction),
    ]
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        obj['sgs_attribute_precision'] = 'v7_visual_precision_hydrology_distribution_material_quality'
        obj['sgs_hyper_precision_attributes'] = ','.join(name for name, _dtype, _values in specs)
        obj['sgs_watershed_count'] = len(set(watershed))
        obj[node_factory.GENERATED_FLAG] = True
    except Exception:
        pass
    return sorted(set(written), key=written.index)


def _terrain_maps_v6(res: int, size: float, height: float, seed: int, iterations: int, droplets: int, hydraulic_strength: float, ridge_preservation: float, channel_count: int) -> dict[str, list[float]]:
    base = _terrain_maps_v5(res, size, height, seed, iterations, droplets, hydraulic_strength)
    h = list(base.get('height') or [])
    if not h:
        return base
    ridge_preservation = _clamp(ridge_preservation, 0.0, 2.0)
    strength = _clamp(hydraulic_strength, 0.0, 5.0)
    relax_passes = max(0, min(18, int(iterations // 4 + ridge_preservation * 3)))
    for _pass in range(relax_passes):
        new_h = list(h)
        for y in range(1, res - 1):
            for x in range(1, res - 1):
                i = _terrain_index(x, y, res)
                neigh = [h[_terrain_index(nx, ny, res)] for nx, ny in _terrain_neighbors8(x, y, res)]
                avg = sum(neigh) / max(1, len(neigh))
                convex = h[i] - avg
                # Smooth pits more strongly than ridges so drainage is stable without erasing silhouettes.
                if convex < 0.0:
                    new_h[i] = h[i] - convex * 0.055 * (1.0 + ridge_preservation * 0.4)
                else:
                    new_h[i] = h[i] - convex * 0.022 * max(0.0, 1.0 - ridge_preservation * 0.32)
        h = new_h
    height_norm_pre = _normalize_values(h)
    flow_seed = [float(base.get('hydraulic', [0.0] * len(h))[i]) if i < len(base.get('hydraulic', [])) else 0.0 for i in range(len(h))]
    channel_count = max(0, min(512, int(channel_count)))
    if channel_count <= 0:
        channel_count = max(4, min(96, int(math.sqrt(res) * (0.7 + strength))))
    # Start channels from deterministic high-score cells and follow descent with mild meander.
    candidate_count = min(len(h), max(channel_count * 32, channel_count + 1))
    candidates = []
    for c in range(candidate_count):
        u = _radical_inverse(c + seed + 1, 2)
        v = _radical_inverse(c + seed + 1, 3)
        x = min(res - 2, max(1, int(u * (res - 2)) + 1))
        y = min(res - 2, max(1, int(v * (res - 2)) + 1))
        i = _terrain_index(x, y, res)
        score = height_norm_pre[i] + _value_noise2(x * 0.17, y * 0.17, seed + 404) * 0.18
        candidates.append((score, x, y))
    candidates.sort(reverse=True)
    carved = [0.0] * len(h)
    bank = [float(base.get('bank', [0.0] * len(h))[i]) if i < len(base.get('bank', [])) else 0.0 for i in range(len(h))]
    for c, (_score, x, y) in enumerate(candidates[:channel_count]):
        water = 1.0
        last_dir = (0, 0)
        max_steps = max(12, min(res * 2, 160))
        for step in range(max_steps):
            i = _terrain_index(x, y, res)
            flow_seed[i] += water * (0.5 + c / max(1, channel_count))
            carved[i] += water
            cut = height * 0.0018 * strength * (1.0 + water * 0.7)
            h[i] -= cut
            for nx, ny in _terrain_neighbors8(x, y, res):
                j = _terrain_index(nx, ny, res)
                bank[j] += cut * 0.28 * max(0.0, 1.0 - abs(nx - x) * 0.35 - abs(ny - y) * 0.35)
                h[j] += cut * 0.018
            choices = []
            for nx, ny in _terrain_neighbors8(x, y, res):
                j = _terrain_index(nx, ny, res)
                drop = h[i] - h[j]
                meander = _value_noise2(nx * 0.23 + step * 0.013, ny * 0.23 + c, seed + 707) * 0.035
                inertia = 0.02 if (nx - x, ny - y) == last_dir else 0.0
                if drop > -height * 0.002:
                    choices.append((drop + meander + inertia, nx, ny))
            if not choices:
                break
            choices.sort(reverse=True)
            nx, ny = choices[0][1], choices[0][2]
            last_dir = (nx - x, ny - y)
            x, y = nx, ny
            water *= 0.982
            if x <= 0 or y <= 0 or x >= res - 1 or y >= res - 1 or water < 0.05:
                break
    maps = _recompute_terrain_derivatives(h, res, size, height, seed, flow_seed)
    maps['hydraulic'] = _normalize_values(flow_seed)
    maps['bank'] = _normalize_values([bank[i] + maps['sediment'][i] * 0.3 for i in range(len(h))])
    maps['channel'] = _normalize_values([maps['channel'][i] * 0.65 + carved[i] * 0.35 for i in range(len(h))])
    maps['deposition'] = _normalize_values([float(base.get('deposition', [0.0] * len(h))[i]) if i < len(base.get('deposition', [])) else 0.0 for i in range(len(h))])
    maps['watershed'] = _v6_grid_watershed_labels(h, res)
    maps['contour'] = [((maps['height_norm'][i] * 17.0) % 1.0) for i in range(len(h))]
    maps['contour_line'] = [_clamp(1.0 - abs(v - 0.5) * 2.0) for v in maps['contour']]
    maps['micro_relief'] = _normalize_values([abs(h[i] - sum(h[_terrain_index(nx, ny, res)] for nx, ny in _terrain_neighbors8(i % res, i // res, res)) / max(1, len(list(_terrain_neighbors8(i % res, i // res, res))))) for i in range(len(h))])
    maps['deposition_balance'] = [_clamp(maps['sediment'][i] * 0.35 + maps['bank'][i] * 0.25 + maps['wetness'][i] * 0.20 - maps['erosion'][i] * 0.12 + 0.25) for i in range(len(h))]
    return maps


def create_terrain(context=None, settings=None):
    ctx = context or bpy.context
    res = max(2, min(512, int(getattr(settings, 'terrain_resolution', 96) or 96)))
    size = float(getattr(settings, 'terrain_size', 12.0) or 12.0)
    height = float(getattr(settings, 'terrain_height', 1.5) or 1.5)
    seed = int(getattr(settings, 'random_seed', 1729))
    iterations = int(getattr(settings, 'terrain_erosion_iterations', 12) or 12)
    droplets = int(getattr(settings, 'terrain_hydraulic_droplets', max(128, res * res // 2)) or 0)
    strength = float(getattr(settings, 'terrain_channel_strength', 1.0) or 1.0)
    ridge_preservation = float(getattr(settings, 'terrain_v7_ridge_preservation', getattr(settings, 'terrain_v7_ridge_preservation', 0.55)) or 0.55)
    channel_count = int(getattr(settings, 'terrain_v7_channel_count', getattr(settings, 'terrain_v7_channel_count', 24)) or 24)
    maps = _terrain_maps_v6(res, size, height, seed, iterations, droplets, strength, ridge_preservation, channel_count)
    verts: list[tuple[float, float, float]] = []
    faces: list[tuple[int, int, int, int]] = []
    for y in range(res):
        fy = (y / (res - 1) - 0.5) * size if res > 1 else 0.0
        for x in range(res):
            fx = (x / (res - 1) - 0.5) * size if res > 1 else 0.0
            i = _terrain_index(x, y, res)
            verts.append((fx, fy, maps['height'][i]))
    for y in range(res - 1):
        for x in range(res - 1):
            a = y * res + x
            faces.append((a, a + 1, a + 1 + res, a + res))
    mesh = bpy.data.meshes.new('SGS_HyperPrecision_Heightfield_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(_object_name('SGS Hyper Precision Heightfield Terrain', '地形'), mesh)
    _link_object(obj, ctx)
    attr_specs = [
        ('sgs_height', 'FLOAT', maps['height_norm']), ('sgs_slope', 'FLOAT', maps['slope']),
        ('sgs_convexity', 'FLOAT', maps['convexity']), ('sgs_wetness', 'FLOAT', maps['wetness']),
        ('sgs_flow', 'FLOAT', maps['flow']), ('sgs_erosion', 'FLOAT', maps['erosion']),
        ('sgs_sediment', 'FLOAT', maps['sediment']), ('sgs_biome', 'INT', [int(v) for v in maps['biome']]),
        ('sgs_channel', 'FLOAT', maps['channel']), ('sgs_stream_order', 'FLOAT', maps['stream_order']),
        ('sgs_terrace', 'FLOAT', maps['terrace']), ('sgs_strata', 'INT', [int(v) for v in maps['strata']]),
        ('sgs_hydraulic', 'FLOAT', maps.get('hydraulic', [0.0] * len(verts))),
        ('sgs_deposition', 'FLOAT', maps.get('deposition', [0.0] * len(verts))),
        ('sgs_bank', 'FLOAT', maps.get('bank', [0.0] * len(verts))),
        ('sgs_watershed', 'INT', [int(v) for v in maps.get('watershed', [0] * len(verts))]),
        ('sgs_contour', 'FLOAT', maps.get('contour', [0.0] * len(verts))),
        ('sgs_contour_line', 'FLOAT', maps.get('contour_line', [0.0] * len(verts))),
        ('sgs_micro_relief', 'FLOAT', maps.get('micro_relief', [0.0] * len(verts))),
        ('sgs_deposition_balance', 'FLOAT', maps.get('deposition_balance', [0.0] * len(verts))),
    ]
    for name, dtype, values in attr_specs:
        _write_attr_values(mesh, name, dtype, values)
    attrs = ensure_standard_attributes(obj)
    try:
        obj['sgs_builder'] = 'hyper_precision_heightfield_terrain'
        obj['sgs_attribute_count'] = len(attrs)
        obj['sgs_erosion_iterations'] = iterations
        obj['sgs_hydraulic_droplets'] = droplets
        obj['sgs_channel_count'] = channel_count
        obj['sgs_algorithm'] = 'ridge_preserved_meander_hydrology_watershed_v7'
    except Exception:
        pass
    return obj


def create_scatter_points(context=None, settings=None):
    obj = _SGS_V5_create_scatter_points(context, settings)
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
        return obj
    mesh = obj.data
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return obj
    points = [_to_tuple(v.co) for v in mesh.vertices]
    normals = _v6_read_vector_attr(mesh, 'sgs_normal', (0.0, 0.0, 1.0), count)
    radii = _read_attr_values(mesh, 'sgs_spacing_radius', float(getattr(settings, 'scatter_min_spacing', 0.1) or 0.1), count)
    relax_iterations = max(0, min(24, int(getattr(settings, 'scatter_v7_lloyd_iterations', getattr(settings, 'scatter_v7_lloyd_iterations', 2)) or 0)))
    fairness_strength = _clamp(float(getattr(settings, 'scatter_v7_fairness_strength', getattr(settings, 'scatter_v7_fairness_strength', 0.65)) or 0.65), 0.0, 2.0)
    if relax_iterations > 0 and count <= 50000:
        points = _v6_tangent_relax_points(points, normals, radii, relax_iterations, 0.28 * fairness_strength)
        for v, co in zip(mesh.vertices, points):
            try:
                v.co = co
            except Exception:
                pass
        try:
            mesh.update()
        except Exception:
            pass
    nearest = _v6_nearest_distances(points, radii)
    positives = [d for d in nearest if d > 0.0]
    mean_nearest = sum(positives) / max(1, len(positives)) if positives else 0.0
    target = [max(1e-6, r * 2.0) for r in radii]
    local_density_raw = [1.0 / max(1e-9, nearest[i] * nearest[i]) if nearest[i] > 0.0 else 0.0 for i in range(count)]
    local_density = _normalize_values(local_density_raw)
    fairness = [_clamp(1.0 - abs(nearest[i] - target[i]) / max(target[i], mean_nearest, 1e-6)) for i in range(count)]
    spacing_error = [_clamp(abs(nearest[i] - target[i]) / max(target[i], mean_nearest, 1e-6)) for i in range(count)]
    distribution_quality = [_clamp(fairness[i] * 0.58 + (1.0 - local_density[i]) * 0.18 + min(1.0, nearest[i] / max(mean_nearest, 1e-6)) * 0.24) for i in range(count)]
    density = _read_attr_values(mesh, 'sgs_density', 1.0, count)
    weights = [_clamp(density[i] * 0.45 + distribution_quality[i] * 0.35 + fairness[i] * 0.20) for i in range(count)]
    _write_attr_values(mesh, 'sgs_nearest_distance', 'FLOAT', nearest)
    _write_attr_values(mesh, 'sgs_local_density', 'FLOAT', local_density)
    _write_attr_values(mesh, 'sgs_distribution_quality', 'FLOAT', distribution_quality)
    _write_attr_values(mesh, 'sgs_distribution_fairness', 'FLOAT', fairness)
    _write_attr_values(mesh, 'sgs_spacing_error', 'FLOAT', spacing_error)
    _write_attr_values(mesh, 'sgs_distribution_weight', 'FLOAT', weights)
    try:
        obj['sgs_builder'] = 'hyper_precision_surface_distribution'
        obj['sgs_algorithm'] = 'weighted_halton_poisson_tangent_relax_quality_v7'
        obj['sgs_mean_nearest_distance'] = mean_nearest
        obj['sgs_distribution_quality_mean'] = sum(distribution_quality) / max(1, count)
        obj['sgs_tangent_relax_iterations'] = relax_iterations
    except Exception:
        pass
    return obj


def apply_selection_string(obj, expression: str) -> int:
    expr = str(expression or 'all')
    # Friendly aliases for the v6 expression layer. The v5 recursive engine handles the rewritten form.
    expr = re.sub(r'within\(([^,]+),\s*([-+0-9.]+),\s*([-+0-9.]+)\)', r'\1:\2-\3', expr, flags=re.IGNORECASE)
    expr = re.sub(r'above\(([^,]+),\s*([-+0-9.]+)\)', r'\1>\2', expr, flags=re.IGNORECASE)
    expr = re.sub(r'below\(([^,]+),\s*([-+0-9.]+)\)', r'\1<\2', expr, flags=re.IGNORECASE)
    selected = _SGS_V5_apply_selection_string(obj, expr)
    try:
        if obj is not None:
            obj['sgs_selection_engine'] = 'visual_precision_recursive_boolean_aliases_v7'
            obj['sgs_selection_string_original'] = str(expression or '')
            obj['sgs_selection_string_rewritten'] = expr
    except Exception:
        pass
    return selected


def explode_mesh_to_pieces(context=None, settings=None) -> list[Any]:
    ctx = context or bpy.context
    source = node_factory.active_mesh_object(ctx)
    if source is None or getattr(source, 'data', None) is None or len(source.data.polygons) == 0:
        return []
    requested = int(getattr(settings, 'fragment_piece_count', 0) or 0)
    mesh = source.data
    polys = list(mesh.polygons)
    if not polys:
        return []
    if requested <= 0:
        # Automatic amount: about a dozen faces per fragment so the pieces really are clusters.
        requested = max(3, min(64, len(polys) // 12))
    k = max(1, min(len(polys), min(768, requested)))
    radius = float(getattr(settings, 'scatter_radius', 0.15) or 0.15)
    seed = int(getattr(settings, 'random_seed', 1729))
    contiguity = _clamp(float(getattr(settings, 'fragment_v7_contiguity', getattr(settings, 'fragment_v7_contiguity', 0.82)) or 0.82), 0.0, 2.0)
    rng = random.Random(seed)
    centers = []
    areas = []
    for poly in polys:
        coords = [_world_vertex(source, int(i)) for i in poly.vertices]
        centers.append((sum(c[0] for c in coords) / len(coords), sum(c[1] for c in coords) / len(coords), sum(c[2] for c in coords) / len(coords)))
        areas.append(float(getattr(poly, 'area', 0.0) or 0.0))
    seeds = _farthest_face_seeds(centers, k, seed)
    adjacency = _face_adjacency(mesh)
    assignments = [-1] * len(polys)
    clusters: dict[int, list[int]] = {ci: [] for ci in range(len(seeds))}
    frontiers: dict[int, set[int]] = {ci: set() for ci in range(len(seeds))}
    for ci, face_index in enumerate(seeds):
        assignments[face_index] = ci
        clusters[ci].append(face_index)
        frontiers[ci].update(adjacency[face_index])
    remaining = len(polys) - len(seeds)
    target_area = sum(areas) / max(1, k)
    while remaining > 0:
        progressed = False
        for ci in range(len(seeds)):
            frontier = [f for f in frontiers[ci] if 0 <= f < len(polys) and assignments[f] < 0]
            if not frontier:
                # A boxed-in cluster stops growing; jumping away would split it into islands.
                continue
            current_area = sum(areas[i] for i in clusters[ci])
            seed_center = centers[seeds[ci]]
            def score(face_index: int) -> float:
                area_penalty = abs((current_area + areas[face_index]) - target_area) / max(target_area, 1e-9)
                dist = _v_len(_v_sub(centers[face_index], seed_center))
                neighbor_bonus = sum(1 for n in adjacency[face_index] if assignments[n] == ci)
                return dist + area_penalty * (1.0 - min(0.95, contiguity * 0.35)) - neighbor_bonus * contiguity
            pick = min(frontier, key=score)
            if assignments[pick] >= 0:
                continue
            assignments[pick] = ci
            clusters[ci].append(pick)
            frontiers[ci].discard(pick)
            frontiers[ci].update(adjacency[pick])
            remaining -= 1
            progressed = True
            if remaining <= 0:
                break
        if not progressed:
            # Whatever no cluster could reach is a separate part without a seed: it joins the nearest cluster as a whole.
            for i, a in enumerate(assignments):
                if a >= 0:
                    continue
                ci = min(range(len(seeds)), key=lambda c: _v_len(_v_sub(centers[i], centers[seeds[c]])))
                assignments[i] = ci
                stack = [i]
                while stack:
                    face_index = stack.pop()
                    clusters[ci].append(face_index)
                    remaining -= 1
                    for other in adjacency[face_index]:
                        if assignments[other] < 0:
                            assignments[other] = ci
                            stack.append(other)
            break
    all_center = (sum(c[0] for c in centers) / len(centers), sum(c[1] for c in centers) / len(centers), sum(c[2] for c in centers) / len(centers))
    created = []
    for piece_id, poly_indices in clusters.items():
        if not poly_indices:
            continue
        verts: list[tuple[float, float, float]] = []
        faces: list[tuple[int, ...]] = []
        index_map: dict[int, int] = {}
        piece_center = (sum(centers[i][0] for i in poly_indices) / len(poly_indices), sum(centers[i][1] for i in poly_indices) / len(poly_indices), sum(centers[i][2] for i in poly_indices) / len(poly_indices))
        direction = _v_norm(_v_sub(piece_center, all_center), (rng.random() - 0.5, rng.random() - 0.5, rng.random()))
        piece_area = sum(areas[i] for i in poly_indices)
        energy = 0.65 + piece_area / max(1e-9, sum(areas)) * 3.2 + rng.random() * 0.25
        offset = _v_add(_v_mul(direction, radius * (1.0 + energy * 2.2)), (0.0, 0.0, radius * rng.random() * 1.5))
        for poly_index in poly_indices:
            poly = polys[poly_index]
            face = []
            for old_i in poly.vertices:
                old_i = int(old_i)
                if old_i not in index_map:
                    co = _world_vertex(source, old_i)
                    seam_pull = _v_mul(_v_sub(piece_center, co), 0.010)
                    index_map[old_i] = len(verts)
                    verts.append(_v_add(_v_add(co, offset), seam_pull))
                face.append(index_map[old_i])
            faces.append(tuple(face))
        piece_mesh = bpy.data.meshes.new(f'SGS_HyperPrecision_Fragment_{piece_id:03d}_Mesh')
        piece_mesh.from_pydata(verts, [], faces)
        piece_mesh.update()
        obj = bpy.data.objects.new(_object_name(f'SGS Hyper Precision Fragment {piece_id:03d}', _fragment_name_ja(piece_id)), piece_mesh)
        _link_object(obj, ctx)
        _write_attr_values(piece_mesh, 'sgs_piece_id', 'INT', [piece_id] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_variation', 'FLOAT', [_radical_inverse(piece_id + seed + 1, 2)] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_mass', 'FLOAT', [piece_area] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_energy', 'FLOAT', [energy] * len(verts))
        _write_attr_values(piece_mesh, 'sgs_fragment_contiguity', 'FLOAT', [contiguity] * len(verts))
        try:
            obj['sgs_builder'] = 'hyper_precision_graph_contiguous_fragment_builder'
            obj['sgs_source_object'] = source.name
            obj['sgs_piece_id'] = piece_id
            obj['sgs_face_count'] = len(poly_indices)
            obj['sgs_piece_area'] = piece_area
            obj['sgs_algorithm'] = 'farthest_seed_graph_contiguous_area_balanced_fragments_v7'
            node_factory.mark_created_object(obj)
        except Exception:
            pass
        created.append(obj)
    try:
        source['sgs_fragment_source_algorithm'] = 'graph_contiguous_area_balanced_v7'
        source['sgs_fragment_piece_count'] = len(created)
    except Exception:
        pass
    return created


# -----------------------------------------------------------------------------
# v7 command-precision overrides
# -----------------------------------------------------------------------------

_SGS_V6_ensure_standard_attributes = ensure_standard_attributes
_SGS_V6_create_terrain = create_terrain
_SGS_V6_create_scatter_points = create_scatter_points
_SGS_V6_apply_selection_string = apply_selection_string
_SGS_V6_explode_mesh_to_pieces = explode_mesh_to_pieces
_SGS_V6_create_ivy_curve = create_ivy_curve


def _v7_neighbors_mean(values: list[float], neighbors: list[set[int]]) -> list[float]:
    out = []
    for i, value in enumerate(values):
        if i >= len(neighbors) or not neighbors[i]:
            out.append(float(value))
        else:
            out.append(sum(values[j] for j in neighbors[i] if 0 <= j < len(values)) / max(1, len(neighbors[i])))
    return out


def _v7_patch_ids(mesh, height: list[float], channel: list[float], neighbors: list[set[int]]) -> list[int]:
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    patch = [-1] * count
    current = 0
    for start in range(count):
        if patch[start] >= 0:
            continue
        seed_band = int(_clamp(height[start]) * 8.0) + (4 if channel[start] > 0.55 else 0)
        stack = [start]
        patch[start] = current
        while stack and len(stack) < 4096:
            i = stack.pop()
            for j in neighbors[i]:
                if not (0 <= j < count) or patch[j] >= 0:
                    continue
                band = int(_clamp(height[j]) * 8.0) + (4 if channel[j] > 0.55 else 0)
                if abs(band - seed_band) <= 1:
                    patch[j] = current
                    stack.append(j)
        current += 1
    return patch


def ensure_standard_attributes(obj) -> list[str]:
    """v7: command-precision field fusion over the v6 layer."""
    written = list(_SGS_V6_ensure_standard_attributes(obj) or [])
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return written
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return written
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return written
    try:
        mesh.update()
        mesh.calc_normals()
    except Exception:
        pass
    neighbors, boundary = _mesh_neighbors(mesh)
    heights = _read_attr_values(mesh, 'sgs_height', 0.0, count)
    slopes = _read_attr_values(mesh, 'sgs_slope', 0.0, count)
    curvature = _read_attr_values(mesh, 'sgs_curvature', 0.0, count)
    convexity = _read_attr_values(mesh, 'sgs_convexity', 0.5, count)
    density = _read_attr_values(mesh, 'sgs_density', 1.0, count)
    quality = _read_attr_values(mesh, 'sgs_quality', 0.5, count)
    habitat = _read_attr_values(mesh, 'sgs_habitat_score', 0.5, count)
    visibility = _read_attr_values(mesh, 'sgs_visibility', 1.0, count)
    channel = _read_attr_values(mesh, 'sgs_channel', 0.0, count)
    channel_influence = _read_attr_values(mesh, 'sgs_channel_influence', 0.0, count)
    wetness = _read_attr_values(mesh, 'sgs_wetness', 0.0, count)
    erosion = _read_attr_values(mesh, 'sgs_erosion', 0.0, count)
    sediment = _read_attr_values(mesh, 'sgs_sediment', 0.0, count)
    ridge = _read_attr_values(mesh, 'sgs_ridge', 0.0, count)
    valley = _read_attr_values(mesh, 'sgs_valley', 0.0, count)
    cavity = _read_attr_values(mesh, 'sgs_cavity', 0.0, count)
    occlusion = _read_attr_values(mesh, 'sgs_occlusion', 0.0, count)
    material_blend = _read_attr_values(mesh, 'sgs_material_blend', 0.5, count)
    edge_distance = _read_attr_values(mesh, 'sgs_edge_distance', 1.0, count)
    accessibility = _read_attr_values(mesh, 'sgs_accessibility', 0.5, count)
    micro_relief = _read_attr_values(mesh, 'sgs_micro_relief', 0.0, count)
    distribution_weight = _read_attr_values(mesh, 'sgs_distribution_weight', density[0] if density else 0.5, count)
    height_mean = _v7_neighbors_mean(heights, neighbors)
    density_mean = _v7_neighbors_mean(density, neighbors)
    channel_mean = _v7_neighbors_mean(channel, neighbors)
    signed_curvature = [_clamp(0.5 + (convexity[i] - 0.5) * 0.9 + (curvature[i] - 0.5) * 0.18) for i in range(count)]
    silhouette = [_clamp((1.0 - edge_distance[i]) * 0.42 + slopes[i] * 0.28 + ridge[i] * 0.18 + (1.0 if i in boundary else 0.0) * 0.12) for i in range(count)]
    topology_risk = [_clamp((1.0 if i in boundary else 0.0) * 0.24 + slopes[i] * 0.18 + curvature[i] * 0.18 + occlusion[i] * 0.14 + abs(density[i] - density_mean[i]) * 0.18 + channel_influence[i] * 0.08) for i in range(count)]
    attribute_confidence = [_clamp(quality[i] * 0.28 + accessibility[i] * 0.22 + visibility[i] * 0.16 + (1.0 - topology_risk[i]) * 0.22 + distribution_weight[i] * 0.12) for i in range(count)]
    material_wear = [_clamp(erosion[i] * 0.30 + ridge[i] * 0.20 + curvature[i] * 0.16 + wetness[i] * 0.12 + micro_relief[i] * 0.12 + (1.0 - occlusion[i]) * 0.10) for i in range(count)]
    uv_seam_intent = [_clamp(silhouette[i] * 0.34 + curvature[i] * 0.24 + abs(heights[i] - height_mean[i]) * 0.20 + (1.0 if i in boundary else 0.0) * 0.22) for i in range(count)]
    distribution_priority = [_clamp(distribution_weight[i] * 0.34 + density[i] * 0.22 + habitat[i] * 0.18 + attribute_confidence[i] * 0.16 + (1.0 - topology_risk[i]) * 0.10) for i in range(count)]
    selection_clarity = [_clamp(abs(density[i] - 0.5) * 0.24 + abs(slopes[i] - 0.5) * 0.12 + attribute_confidence[i] * 0.28 + (1.0 - topology_risk[i]) * 0.20 + silhouette[i] * 0.16) for i in range(count)]
    habitat_mean = _safe_mean(habitat, 0.5)
    habitat_margin = [_clamp(abs(habitat[i] - habitat_mean) * 0.34 + (1.0 - topology_risk[i]) * 0.18 + density[i] * 0.16 + valley[i] * 0.12 + channel_mean[i] * 0.20) for i in range(count)]
    flow_persistence = [_clamp(channel[i] * 0.32 + channel_mean[i] * 0.28 + wetness[i] * 0.18 + sediment[i] * 0.10 + (1.0 - abs(heights[i] - height_mean[i])) * 0.12) for i in range(count)]
    patch_ids = _v7_patch_ids(mesh, heights, channel, neighbors)
    patch_boundary = []
    for i in range(count):
        is_boundary = i in boundary or any(0 <= j < count and patch_ids[j] != patch_ids[i] for j in neighbors[i])
        patch_boundary.append(1.0 if is_boundary else 0.0)
    v7_precision = [_clamp(attribute_confidence[i] * 0.32 + distribution_priority[i] * 0.24 + selection_clarity[i] * 0.18 + (1.0 - topology_risk[i]) * 0.16 + material_blend[i] * 0.10) for i in range(count)]
    command_score = [_clamp(v7_precision[i] * 0.44 + distribution_priority[i] * 0.24 + material_wear[i] * 0.12 + uv_seam_intent[i] * 0.10 + flow_persistence[i] * 0.10) for i in range(count)]
    specs = [
        ('sgs_curvature_signed', 'FLOAT', signed_curvature),
        ('sgs_silhouette', 'FLOAT', silhouette),
        ('sgs_topology_risk', 'FLOAT', topology_risk),
        ('sgs_attribute_confidence', 'FLOAT', attribute_confidence),
        ('sgs_material_wear', 'FLOAT', material_wear),
        ('sgs_uv_seam_intent', 'FLOAT', uv_seam_intent),
        ('sgs_distribution_priority', 'FLOAT', distribution_priority),
        ('sgs_selection_clarity', 'FLOAT', selection_clarity),
        ('sgs_habitat_margin', 'FLOAT', habitat_margin),
        ('sgs_flow_persistence', 'FLOAT', flow_persistence),
        ('sgs_patch_id', 'INT', patch_ids),
        ('sgs_patch_boundary', 'FLOAT', patch_boundary),
        ('sgs_v7_precision', 'FLOAT', v7_precision),
        ('sgs_command_score', 'FLOAT', command_score),
    ]
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        obj['sgs_attribute_precision'] = 'v7_command_precision_field_fusion'
        obj['sgs_v7_precision_mean'] = sum(v7_precision) / max(1, count)
        obj['sgs_v7_topology_risk_mean'] = sum(topology_risk) / max(1, count)
        obj['sgs_v7_patch_count'] = len(set(patch_ids))
        obj['sgs_command_precision_attributes'] = ','.join(name for name, _dtype, _values in specs)
        obj[node_factory.GENERATED_FLAG] = True
    except Exception:
        pass
    return sorted(set(written), key=written.index)


def refine_scene_precision(context=None, settings=None) -> int:
    ctx = context or bpy.context
    objects = [obj for obj in list(getattr(ctx, 'selected_objects', []) or []) if getattr(obj, 'type', None) == 'MESH']
    if not objects:
        active = node_factory.active_mesh_object(ctx)
        if active is not None:
            objects = [active]
    count = 0
    for obj in objects:
        ensure_standard_attributes(obj)
        count += 1
    return count


def create_terrain(context=None, settings=None):
    obj = _SGS_V6_create_terrain(context, settings)
    if obj is not None:
        ensure_standard_attributes(obj)
        try:
            obj['sgs_builder'] = 'v7_command_precision_heightfield_terrain'
            obj['sgs_algorithm'] = 'v7_field_fusion_hydrology_watershed_patch_material_distribution'
            obj['sgs_terrain_field_fusion'] = float(getattr(settings, 'terrain_v7_field_fusion', 0.72) or 0.72)
        except Exception:
            pass
    return obj


def create_scatter_points(context=None, settings=None):
    obj = _SGS_V6_create_scatter_points(context, settings)
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
        return obj
    mesh = obj.data
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return obj
    density = _read_attr_values(mesh, 'sgs_density', 1.0, count)
    quality = _read_attr_values(mesh, 'sgs_distribution_quality', 0.5, count)
    fairness = _read_attr_values(mesh, 'sgs_distribution_fairness', 0.5, count)
    nearest = _read_attr_values(mesh, 'sgs_nearest_distance', 0.0, count)
    normals = _v6_read_vector_attr(mesh, 'sgs_normal', (0.0, 0.0, 1.0), count) if '_v6_read_vector_attr' in globals() else [(0.0, 0.0, 1.0)] * count
    anisotropy_strength = _clamp(float(getattr(settings, 'scatter_v7_anisotropy_strength', 0.58) or 0.58), 0.0, 2.0)
    priority_bias = _clamp(float(getattr(settings, 'scatter_v7_priority_bias', 0.62) or 0.62), 0.0, 2.0)
    normal_alignment = [_clamp(0.5 + abs(normals[i][2]) * 0.5) for i in range(count)]
    priority = [_clamp(density[i] * 0.28 + quality[i] * 0.28 + fairness[i] * 0.20 + normal_alignment[i] * 0.12 * anisotropy_strength + priority_bias * 0.06) for i in range(count)]
    rank = _rank01(priority, reverse=False)
    spacing_norm = _normalize_values(nearest)
    command_quality = [_clamp(priority[i] * 0.44 + quality[i] * 0.28 + fairness[i] * 0.18 + spacing_norm[i] * 0.10) for i in range(count)]
    _write_attr_values(mesh, 'sgs_distribution_priority', 'FLOAT', priority)
    _write_attr_values(mesh, 'sgs_distribution_rank_v7', 'FLOAT', rank)
    _write_attr_values(mesh, 'sgs_command_quality', 'FLOAT', command_quality)
    try:
        obj['sgs_builder'] = 'v7_command_precision_surface_distribution'
        obj['sgs_algorithm'] = 'v7_anisotropic_priority_fairness_distribution'
        obj['sgs_command_quality_mean'] = sum(command_quality) / max(1, count)
        obj['sgs_distribution_priority_mean'] = sum(priority) / max(1, count)
    except Exception:
        pass
    return obj


def apply_selection_string(obj, expression: str) -> int:
    expr = str(expression or 'all')
    expr = re.sub(r'clarity\s*([<>]=?)\s*([-+0-9.]+)', r'selection_clarity\1\2', expr, flags=re.IGNORECASE)
    expr = re.sub(r'risk\s*([<>]=?)\s*([-+0-9.]+)', r'topology_risk\1\2', expr, flags=re.IGNORECASE)
    expr = re.sub(r'priority\s*([<>]=?)\s*([-+0-9.]+)', r'distribution_priority\1\2', expr, flags=re.IGNORECASE)
    expr = re.sub(r'wear\s*([<>]=?)\s*([-+0-9.]+)', r'material_wear\1\2', expr, flags=re.IGNORECASE)
    selected = _SGS_V6_apply_selection_string(obj, expr)
    try:
        if obj is not None:
            obj['sgs_selection_engine'] = 'v7_command_precision_field_algebra'
            obj['sgs_selection_string_original'] = str(expression or '')
            obj['sgs_selection_string_rewritten'] = expr
    except Exception:
        pass
    return selected


def create_ivy_curve(context=None, settings=None):
    obj = _SGS_V6_create_ivy_curve(context, settings)
    try:
        if obj is not None:
            obj['sgs_builder'] = 'v7_command_precision_organic_growth_curves'
            obj['sgs_algorithm'] = 'v7_attachment_aware_branch_curl_growth_guides'
            node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj


def explode_mesh_to_pieces(context=None, settings=None) -> list[Any]:
    pieces = list(_SGS_V6_explode_mesh_to_pieces(context, settings) or [])
    compactness_setting = _clamp(float(getattr(settings, 'fragment_v7_compactness', 0.70) or 0.70), 0.0, 2.0)
    for obj in pieces:
        mesh = getattr(obj, 'data', None)
        if mesh is None:
            continue
        coords = [_to_tuple(v.co) for v in getattr(mesh, 'vertices', [])]
        if not coords:
            continue
        mn = (min(c[0] for c in coords), min(c[1] for c in coords), min(c[2] for c in coords))
        mx = (max(c[0] for c in coords), max(c[1] for c in coords), max(c[2] for c in coords))
        span = _v_sub(mx, mn)
        bbox_volume = max(1e-9, abs(span[0] * span[1] * span[2]))
        surface = sum(float(getattr(p, 'area', 0.0) or 0.0) for p in getattr(mesh, 'polygons', []) or [])
        compactness = _clamp((surface ** 1.5) / max(1e-9, bbox_volume) * 0.012 * compactness_setting)
        balance = _clamp(1.0 - abs(span[0] - span[1]) / max(1e-9, max(span[0], span[1], span[2], 1e-9)))
        shape_quality = _clamp(compactness * 0.55 + balance * 0.35 + min(1.0, len(mesh.polygons) / 16.0) * 0.10)
        count = _mesh_vertex_count(mesh)
        _write_attr_values(mesh, 'sgs_fragment_compactness', 'FLOAT', [compactness] * count)
        _write_attr_values(mesh, 'sgs_fragment_balance', 'FLOAT', [balance] * count)
        _write_attr_values(mesh, 'sgs_fragment_shape_quality', 'FLOAT', [shape_quality] * count)
        try:
            obj['sgs_algorithm'] = 'v7_graph_contiguous_compactness_scored_fragments'
            obj['sgs_fragment_compactness'] = compactness
            obj['sgs_fragment_shape_quality'] = shape_quality
        except Exception:
            pass
    return pieces

# -----------------------------------------------------------------------------
# SGS v7 interface-precision and quality overrides
# -----------------------------------------------------------------------------

_SGS_V7_COMMAND_ensure_standard_attributes = ensure_standard_attributes
_SGS_V7_COMMAND_create_terrain = create_terrain
_SGS_V7_COMMAND_create_scatter_points = create_scatter_points
_SGS_V7_COMMAND_relax_distribution_points = relax_distribution_points
_SGS_V7_COMMAND_refine_scene_precision = refine_scene_precision
_SGS_V7_COMMAND_create_greeble_blocks = create_greeble_blocks
_SGS_V7_COMMAND_create_building_proxy = create_building_proxy
_SGS_V7_COMMAND_create_ivy_curve = create_ivy_curve
_SGS_V7_COMMAND_explode_mesh_to_pieces = explode_mesh_to_pieces


def _v7_float_attr(mesh, name: str, default: float, count: int) -> list[float]:
    return _read_attr_values(mesh, name, default, count)


def _v7_orientation_frames(mesh, count: int) -> tuple[list[tuple[float, float, float]], list[tuple[float, float, float]], list[float]]:
    normals = _v6_read_vector_attr(mesh, 'sgs_normal', (0.0, 0.0, 1.0), count)
    tangents: list[tuple[float, float, float]] = []
    bitangents: list[tuple[float, float, float]] = []
    confidence: list[float] = []
    for n in normals:
        nn = _v_norm(n, (0.0, 0.0, 1.0))
        ref = (0.0, 0.0, 1.0) if abs(_v_dot(nn, (0.0, 0.0, 1.0))) < 0.85 else (1.0, 0.0, 0.0)
        t = _v_norm(_v_cross(ref, nn), (1.0, 0.0, 0.0))
        b = _v_norm(_v_cross(nn, t), (0.0, 1.0, 0.0))
        tangents.append(t)
        bitangents.append(b)
        confidence.append(_clamp(_v_len(n)))
    return tangents, bitangents, confidence


def _v7_quality_grades(values: list[float]) -> list[int]:
    return [int(max(0, min(4, math.floor(_clamp(v) * 4.999)))) for v in values]


def ensure_standard_attributes(obj) -> list[str]:
    """v7: add operation-confidence, geodesic, material-weathering, and icon-workflow quality fields."""
    written = list(_SGS_V7_COMMAND_ensure_standard_attributes(obj) or [])
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return written
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return written
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return written
    try:
        mesh.update()
        mesh.calc_normals()
    except Exception:
        pass
    neighbors, boundary = _mesh_neighbors(mesh)
    heights = _v7_float_attr(mesh, 'sgs_height', 0.0, count)
    slopes = _v7_float_attr(mesh, 'sgs_slope', 0.0, count)
    curvature = _v7_float_attr(mesh, 'sgs_curvature', 0.0, count)
    convexity = _v7_float_attr(mesh, 'sgs_convexity', 0.5, count)
    density = _v7_float_attr(mesh, 'sgs_density', 1.0, count)
    wetness = _v7_float_attr(mesh, 'sgs_wetness', 0.0, count)
    flow = _v7_float_attr(mesh, 'sgs_flow', 0.0, count)
    erosion = _v7_float_attr(mesh, 'sgs_erosion', 0.0, count)
    sediment = _v7_float_attr(mesh, 'sgs_sediment', 0.0, count)
    channel = _v7_float_attr(mesh, 'sgs_channel', 0.0, count)
    cavity = _v7_float_attr(mesh, 'sgs_cavity', 0.0, count)
    occlusion = _v7_float_attr(mesh, 'sgs_occlusion', 0.0, count)
    habitat = _v7_float_attr(mesh, 'sgs_habitat_score', 0.5, count)
    visibility = _v7_float_attr(mesh, 'sgs_visibility', 1.0, count)
    quality = _v7_float_attr(mesh, 'sgs_quality', 0.5, count)
    micro = _v7_float_attr(mesh, 'sgs_micro_relief', 0.0, count)
    distribution_quality = _v7_float_attr(mesh, 'sgs_distribution_quality', 0.5, count)
    selection = _v7_float_attr(mesh, 'sgs_selection', 0.0, count)
    boundary_mask = [i in boundary for i in range(count)]
    boundary_near = _v6_graph_distance_from_mask(neighbors, boundary_mask)
    geodesic_boundary_distance = [1.0 - v for v in boundary_near]
    boundary_proximity = boundary_near
    height_laplacian = []
    curvature_laplacian = []
    for i in range(count):
        if neighbors[i]:
            height_laplacian.append(abs(heights[i] - _safe_mean(heights[j] for j in neighbors[i])))
            curvature_laplacian.append(abs(curvature[i] - _safe_mean(curvature[j] for j in neighbors[i])))
        else:
            height_laplacian.append(0.0)
            curvature_laplacian.append(0.0)
    height_laplacian = _normalize_values(height_laplacian)
    curvature_laplacian = _normalize_values(curvature_laplacian)
    tangents, bitangents, orientation_confidence = _v7_orientation_frames(mesh, count)
    material_wear = [_clamp(curvature[i] * 0.34 + convexity[i] * 0.22 + erosion[i] * 0.22 + channel[i] * 0.14 + boundary_proximity[i] * 0.08) for i in range(count)]
    material_dust = [_clamp((1.0 - slopes[i]) * 0.38 + cavity[i] * 0.32 + occlusion[i] * 0.18 + sediment[i] * 0.12) for i in range(count)]
    material_moss = [_clamp(wetness[i] * 0.40 + cavity[i] * 0.20 + habitat[i] * 0.25 + (1.0 - slopes[i]) * 0.15) for i in range(count)]
    water_accumulation = [_clamp(wetness[i] * 0.36 + flow[i] * 0.25 + channel[i] * 0.24 + sediment[i] * 0.15) for i in range(count)]
    asset_priority = [_clamp(density[i] * 0.32 + habitat[i] * 0.24 + visibility[i] * 0.22 + distribution_quality[i] * 0.22) for i in range(count)]
    operation_confidence = [_clamp(quality[i] * 0.34 + orientation_confidence[i] * 0.18 + geodesic_boundary_distance[i] * 0.14 + visibility[i] * 0.14 + (1.0 - height_laplacian[i]) * 0.10 + asset_priority[i] * 0.10) for i in range(count)]
    edge_safety = [_clamp(1.0 - boundary_proximity[i] * 0.85) for i in range(count)]
    selection_confidence = [_clamp(selection[i] * 0.50 + operation_confidence[i] * 0.30 + density[i] * 0.20) for i in range(count)]
    material_weathering = [_clamp(material_wear[i] * 0.40 + material_dust[i] * 0.25 + material_moss[i] * 0.20 + water_accumulation[i] * 0.15) for i in range(count)]
    debug_priority = [_clamp((1.0 - operation_confidence[i]) * 0.40 + curvature_laplacian[i] * 0.22 + height_laplacian[i] * 0.18 + boundary_proximity[i] * 0.10 + micro[i] * 0.10) for i in range(count)]
    quality_grade = _v7_quality_grades(operation_confidence)
    specs: list[tuple[str, str, list[Any]]] = [
        ('sgs_geodesic_boundary_distance', 'FLOAT', geodesic_boundary_distance),
        ('sgs_boundary_proximity', 'FLOAT', boundary_proximity),
        ('sgs_height_laplacian', 'FLOAT', height_laplacian),
        ('sgs_curvature_laplacian', 'FLOAT', curvature_laplacian),
        ('sgs_bitangent', 'FLOAT_VECTOR', bitangents),
        ('sgs_orientation_confidence', 'FLOAT', orientation_confidence),
        ('sgs_material_wear', 'FLOAT', material_wear),
        ('sgs_material_dust', 'FLOAT', material_dust),
        ('sgs_material_moss', 'FLOAT', material_moss),
        ('sgs_water_accumulation', 'FLOAT', water_accumulation),
        ('sgs_asset_priority', 'FLOAT', asset_priority),
        ('sgs_operation_confidence', 'FLOAT', operation_confidence),
        ('sgs_edge_safety', 'FLOAT', edge_safety),
        ('sgs_selection_confidence', 'FLOAT', selection_confidence),
        ('sgs_material_weathering', 'FLOAT', material_weathering),
        ('sgs_debug_priority', 'FLOAT', debug_priority),
        ('sgs_quality_grade', 'INT', quality_grade),
    ]
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        obj['sgs_attribute_precision'] = 'v7_interface_precision_geodesic_material_weathering_operation_confidence'
        obj['sgs_v7_attribute_count'] = len(set(written))
        obj['sgs_mean_operation_confidence'] = float(_safe_mean(operation_confidence))
        obj['sgs_mean_asset_priority'] = float(_safe_mean(asset_priority))
        obj['sgs_mean_debug_priority'] = float(_safe_mean(debug_priority))
    except Exception:
        pass
    return sorted(set(written))


def _v7_postbuild_object(obj, kind: str) -> None:
    if obj is None:
        return
    if getattr(obj, 'type', None) == 'MESH':
        try:
            ensure_standard_attributes(obj)
        except Exception:
            pass
    try:
        obj['sgs_v7_interface_precision'] = True
        obj['sgs_v7_builder_kind'] = str(kind)
        obj['sgs_algorithm'] = str(obj.get('sgs_algorithm', '')) + '|v7_quality_confidence_ui_guided'
        node_factory.mark_created_object(obj)
    except Exception:
        pass


def create_terrain(context=None, settings=None):
    obj = _SGS_V7_COMMAND_create_terrain(context, settings)
    _v7_postbuild_object(obj, 'terrain')
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        mesh = obj.data
        count = _mesh_vertex_count(mesh)
        if count > 0:
            stream = _read_attr_values(mesh, 'sgs_stream_order', 0.0, count)
            channel = _read_attr_values(mesh, 'sgs_channel', 0.0, count)
            deposition = _read_attr_values(mesh, 'sgs_deposition', 0.0, count)
            erosion = _read_attr_values(mesh, 'sgs_erosion', 0.0, count)
            stream_power = [_clamp(channel[i] * 0.55 + stream[i] * 0.30 + erosion[i] * 0.15) for i in range(count)]
            sediment_transport = [_clamp(deposition[i] * 0.45 + erosion[i] * 0.35 + channel[i] * 0.20) for i in range(count)]
            weathering = _read_attr_values(mesh, 'sgs_material_weathering', 0.0, count)
            terrain_story = [_clamp(stream_power[i] * 0.35 + sediment_transport[i] * 0.30 + weathering[i] * 0.35) for i in range(count)]
            _write_attr_values(mesh, 'sgs_stream_power', 'FLOAT', stream_power)
            _write_attr_values(mesh, 'sgs_sediment_transport', 'FLOAT', sediment_transport)
            _write_attr_values(mesh, 'sgs_terrain_story', 'FLOAT', terrain_story)
            try:
                obj['sgs_algorithm'] = 'v7_stream_power_sediment_transport_interface_precision_terrain'
            except Exception:
                pass
    return obj


def create_scatter_points(context=None, settings=None):
    obj = _SGS_V7_COMMAND_create_scatter_points(context, settings)
    _v7_postbuild_object(obj, 'distribution')
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        mesh = obj.data
        count = _mesh_vertex_count(mesh)
        if count > 1:
            points = [_to_tuple(v.co) for v in mesh.vertices]
            radii = _read_attr_values(mesh, 'sgs_spacing_radius', _safe_float(getattr(settings, 'scatter_radius', 0.15), 0.15) if settings else 0.15, count)
            nearest = _v6_nearest_distances(points, radii)
            nearest_norm = _normalize_values(nearest)
            density = _read_attr_values(mesh, 'sgs_density', 1.0, count)
            quality = _read_attr_values(mesh, 'sgs_distribution_quality', 0.5, count)
            priority = [_clamp(density[i] * 0.42 + quality[i] * 0.33 + nearest_norm[i] * 0.25) for i in range(count)]
            spacing_score = [_clamp(1.0 - abs(nearest[i] - radii[i] * 2.0) / max(radii[i] * 2.0, 1e-9)) for i in range(count)]
            entropy = _rank01([density[i] * spacing_score[i] for i in range(count)])
            _write_attr_values(mesh, 'sgs_instance_priority', 'FLOAT', priority)
            _write_attr_values(mesh, 'sgs_spacing_score', 'FLOAT', spacing_score)
            _write_attr_values(mesh, 'sgs_distribution_entropy', 'FLOAT', entropy)
            _write_attr_values(mesh, 'sgs_quality_grade', 'INT', _v7_quality_grades(priority))
            try:
                obj['sgs_algorithm'] = 'v7_priority_entropy_spacing_scored_distribution'
                obj['sgs_mean_instance_priority'] = float(_safe_mean(priority))
            except Exception:
                pass
    return obj


def relax_distribution_points(context=None, settings=None):
    moved = _SGS_V7_COMMAND_relax_distribution_points(context, settings)
    obj = node_factory.active_mesh_object(context)
    if obj is not None:
        _v7_postbuild_object(obj, 'distribution_relax')
    return moved


def refine_scene_precision(context=None, settings=None) -> int:
    count = _SGS_V7_COMMAND_refine_scene_precision(context, settings)
    ctx = context or bpy.context
    for obj in list(getattr(ctx, 'selected_objects', []) or []):
        if getattr(obj, 'type', None) == 'MESH':
            try:
                ensure_standard_attributes(obj)
                obj['sgs_v7_refined'] = True
            except Exception:
                pass
    return count


def create_greeble_blocks(context=None, settings=None):
    obj = _SGS_V7_COMMAND_create_greeble_blocks(context, settings)
    _v7_postbuild_object(obj, 'surface_detail')
    return obj


def create_building_proxy(context=None, settings=None):
    obj = _SGS_V7_COMMAND_create_building_proxy(context, settings)
    _v7_postbuild_object(obj, 'modular_structure')
    return obj


def create_ivy_curve(context=None, settings=None):
    obj = _SGS_V7_COMMAND_create_ivy_curve(context, settings)
    try:
        if obj is not None:
            obj['sgs_v7_interface_precision'] = True
            obj['sgs_v7_builder_kind'] = 'organic_growth'
            obj['sgs_algorithm'] = str(obj.get('sgs_algorithm', 'organic_growth')) + '|v7_branch_readability_profile'
    except Exception:
        pass
    return obj


def explode_mesh_to_pieces(context=None, settings=None) -> list[Any]:
    pieces = list(_SGS_V7_COMMAND_explode_mesh_to_pieces(context, settings) or [])
    for obj in pieces:
        _v7_postbuild_object(obj, 'fragment')
        if getattr(obj, 'type', None) == 'MESH':
            mesh = obj.data
            count = _mesh_vertex_count(mesh)
            if count > 0:
                confidence = _read_attr_values(mesh, 'sgs_operation_confidence', 0.75, count)
                _write_attr_values(mesh, 'sgs_fragment_readability', 'FLOAT', confidence)
    return pieces


# ---- Smart Geometry v7 precision polish additions ----
_SGS_V7_BASE_ensure_standard_attributes = ensure_standard_attributes


def _sgs_v7_neighbor_average(values: list[float], neighbors: list[set[int]], keep: float = 0.55) -> list[float]:
    if not values:
        return []
    result: list[float] = []
    for i, value in enumerate(values):
        nbs = neighbors[i] if i < len(neighbors) else set()
        if not nbs:
            result.append(float(value))
        else:
            avg = sum(values[j] for j in nbs if j < len(values)) / max(1, len(nbs))
            result.append(float(value) * keep + avg * (1.0 - keep))
    return result


def _sgs_v7_write_quality_layer(obj, settings=None) -> list[str]:
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return []
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    neighbors, boundary = _mesh_neighbors(mesh)
    density = _read_attr_values(mesh, 'sgs_density', 0.5, count)
    height = _read_attr_values(mesh, 'sgs_height', 0.0, count)
    slope = _read_attr_values(mesh, 'sgs_slope', 0.0, count)
    curvature = _read_attr_values(mesh, 'sgs_curvature', 0.0, count)
    cavity = _read_attr_values(mesh, 'sgs_cavity', 0.0, count)
    occlusion = _read_attr_values(mesh, 'sgs_occlusion', 0.0, count)
    wetness = _read_attr_values(mesh, 'sgs_wetness', 0.0, count)
    channel = _read_attr_values(mesh, 'sgs_channel', 0.0, count)
    flow = _read_attr_values(mesh, 'sgs_flow', 0.0, count)
    strength = _clamp(_safe_float(getattr(settings, 'precision_v7_strength', 0.85), 0.85), 0.0, 2.0) / 2.0
    preserve = _clamp(_safe_float(getattr(settings, 'precision_v7_feature_preservation', 0.72), 0.72), 0.0, 2.0) / 2.0
    density_smooth = _sgs_v7_neighbor_average(density, neighbors, keep=0.42 + preserve * 0.35)
    curvature_smooth = _sgs_v7_neighbor_average(curvature, neighbors, keep=0.50 + preserve * 0.30)
    height_var = _neighbor_variance(height, neighbors)
    vertex_area = _vertex_area_values(mesh)
    area_rank = _rank01(vertex_area)
    laplacian_error = [abs(a-b) for a, b in zip(density, density_smooth)]
    feature_score = [_clamp(0.48*c + 0.26*s + 0.18*hv + 0.08*(1.0 if i in boundary else 0.0)) for i, (c, s, hv) in enumerate(zip(curvature, slope, height_var))]
    stability = [_clamp(1.0 - 0.36*s - 0.24*le - 0.20*abs(f - 0.5) + 0.10*(1.0 - ch)) for s, le, f, ch in zip(slope, laplacian_error, flow, channel)]
    contact = [_clamp(0.42*cav + 0.24*occ + 0.20*wet + 0.14*ch) for cav, occ, wet, ch in zip(cavity, occlusion, wetness, channel)]
    material_blend = [_clamp(0.30*h + 0.22*s + 0.18*wet + 0.16*cav + 0.14*ch) for h, s, wet, cav, ch in zip(height, slope, wetness, cavity, channel)]
    distribution_priority = [_clamp(0.38*ds + 0.28*st + 0.18*(1.0-occ) + 0.10*ar + 0.06*strength) for ds, st, occ, ar in zip(density_smooth, stability, occlusion, area_rank)]
    remesh_size = [_clamp(1.0 - (0.48*fs + 0.22*s + 0.18*ch + 0.12*le)) for fs, s, ch, le in zip(feature_score, slope, channel, laplacian_error)]
    debug_score = [_clamp(0.24*distribution_priority[i] + 0.22*feature_score[i] + 0.20*stability[i] + 0.17*material_blend[i] + 0.17*(1.0-laplacian_error[i])) for i in range(count)]
    quality_grade = [max(0, min(9, int(v * 10.0))) for v in debug_score]
    region_count = max(2, min(64, _safe_int(getattr(settings, 'precision_v7_material_regions', 7), 7)))
    material_region = [max(0, min(region_count - 1, int(v * region_count))) for v in material_blend]
    written = []
    specs = [
        ('sgs_v7_density_smooth', 'FLOAT', density_smooth),
        ('sgs_v7_curvature_smooth', 'FLOAT', curvature_smooth),
        ('sgs_v7_laplacian_error', 'FLOAT', laplacian_error),
        ('sgs_v7_feature_score', 'FLOAT', feature_score),
        ('sgs_v7_stability_rank', 'FLOAT', _rank01(stability)),
        ('sgs_v7_distribution_priority', 'FLOAT', distribution_priority),
        ('sgs_v7_contact_score', 'FLOAT', contact),
        ('sgs_v7_material_blend', 'FLOAT', material_blend),
        ('sgs_v7_remesh_size', 'FLOAT', remesh_size),
        ('sgs_v7_debug_score', 'FLOAT', debug_score),
        ('sgs_v7_quality_grade', 'INT', quality_grade),
        ('sgs_material_region', 'INT', material_region),
    ]
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        obj['sgs_algorithm'] = 'v7_visual_precision_quality_polish'
        obj['sgs_v7_quality_attribute_count'] = len(written)
    except Exception:
        pass
    return written


def ensure_standard_attributes(obj) -> list[str]:
    written = list(_SGS_V7_BASE_ensure_standard_attributes(obj) or [])
    try:
        written.extend(_sgs_v7_write_quality_layer(obj, None))
    except Exception:
        pass
    seen = set()
    ordered = []
    for name in written:
        if name not in seen:
            seen.add(name)
            ordered.append(name)
    return ordered


def polish_precision_overdrive(context=None, settings=None) -> int:
    ctx = context or bpy.context
    objects = [obj for obj in list(getattr(ctx, 'selected_objects', []) or []) if getattr(obj, 'type', '') == 'MESH']
    if not objects and getattr(getattr(ctx, 'object', None), 'type', '') == 'MESH':
        objects = [ctx.object]
    count = 0
    for obj in objects:
        try:
            _SGS_V7_BASE_ensure_standard_attributes(obj)
            if _sgs_v7_write_quality_layer(obj, settings):
                count += 1
        except Exception:
            pass
    return count


# -----------------------------------------------------------------------------
# SGS v8 operation-grade precision, UI-readability, and quality overrides
# -----------------------------------------------------------------------------

_SGS_V8_BASE_ensure_standard_attributes = ensure_standard_attributes
_SGS_V8_BASE_polish_precision_overdrive = polish_precision_overdrive
_SGS_V8_BASE_refine_scene_precision = refine_scene_precision
_SGS_V8_BASE_create_terrain = create_terrain
_SGS_V8_BASE_create_scatter_points = create_scatter_points
_SGS_V8_BASE_relax_distribution_points = relax_distribution_points
_SGS_V8_BASE_create_greeble_blocks = create_greeble_blocks
_SGS_V8_BASE_create_building_proxy = create_building_proxy
_SGS_V8_BASE_create_ivy_curve = create_ivy_curve
_SGS_V8_BASE_explode_mesh_to_pieces = explode_mesh_to_pieces
_SGS_V8_BASE_create_flow_network_curves = create_flow_network_curves


def _sgs_v8_neighbor_blur(values: list[float], neighbors: list[set[int]], passes: int = 1, keep: float = 0.60) -> list[float]:
    result = [float(v) for v in values]
    for _ in range(max(1, int(passes))):
        new = []
        for i, value in enumerate(result):
            nbs = neighbors[i] if i < len(neighbors) else set()
            if not nbs:
                new.append(value)
                continue
            vals = [result[j] for j in nbs if 0 <= j < len(result)]
            avg = sum(vals) / max(1, len(vals))
            new.append(value * keep + avg * (1.0 - keep))
        result = new
    return result


def _sgs_v8_read(mesh, name: str, default: float, count: int) -> list[float]:
    return _read_attr_values(mesh, name, default, count)


def _sgs_v8_write_operation_layer(obj, settings=None) -> list[str]:
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return []
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return []
    neighbors, boundary = _mesh_neighbors(mesh)
    passes = max(1, min(12, _safe_int(getattr(settings, 'precision_v8_quality_passes', 3), 3)))
    radius = max(1, min(8, _safe_int(getattr(settings, 'precision_v8_feature_radius', 2), 2)))
    strength = _clamp(_safe_float(getattr(settings, 'precision_v8_strength', 0.88), 0.88), 0.0, 2.0) / 2.0
    material_contrast = _clamp(_safe_float(getattr(settings, 'precision_v8_material_contrast', 0.74), 0.74), 0.0, 2.0)
    risk_suppression = _clamp(_safe_float(getattr(settings, 'precision_v8_risk_suppression', 0.66), 0.66), 0.0, 2.0) / 2.0

    height = _sgs_v8_read(mesh, 'sgs_height', 0.0, count)
    slope = _sgs_v8_read(mesh, 'sgs_slope', 0.0, count)
    curvature = _sgs_v8_read(mesh, 'sgs_curvature', 0.0, count)
    density = _sgs_v8_read(mesh, 'sgs_density', 0.5, count)
    quality = _sgs_v8_read(mesh, 'sgs_quality', 0.5, count)
    visibility = _sgs_v8_read(mesh, 'sgs_visibility', 1.0, count)
    habitat = _sgs_v8_read(mesh, 'sgs_habitat_score', 0.5, count)
    channel = _sgs_v8_read(mesh, 'sgs_channel', 0.0, count)
    flow = _sgs_v8_read(mesh, 'sgs_flow', 0.0, count)
    wetness = _sgs_v8_read(mesh, 'sgs_wetness', 0.0, count)
    cavity = _sgs_v8_read(mesh, 'sgs_cavity', 0.0, count)
    occlusion = _sgs_v8_read(mesh, 'sgs_occlusion', 0.0, count)
    confidence = _sgs_v8_read(mesh, 'sgs_operation_confidence', 0.5, count)
    asset_priority = _sgs_v8_read(mesh, 'sgs_asset_priority', 0.5, count)
    material_wear = _sgs_v8_read(mesh, 'sgs_material_wear', 0.0, count)
    distribution_quality = _sgs_v8_read(mesh, 'sgs_distribution_quality', 0.5, count)
    spacing_score = _sgs_v8_read(mesh, 'sgs_spacing_score', 0.5, count)
    topology_risk = _sgs_v8_read(mesh, 'sgs_topology_risk', 0.0, count)
    edge_safety = _sgs_v8_read(mesh, 'sgs_edge_safety', 0.5, count)
    command_score = _sgs_v8_read(mesh, 'sgs_command_score', 0.5, count)

    smooth_density = _sgs_v8_neighbor_blur(density, neighbors, passes=passes, keep=0.48 + strength * 0.24)
    smooth_curvature = _sgs_v8_neighbor_blur(curvature, neighbors, passes=max(1, radius), keep=0.54)
    smooth_height = _sgs_v8_neighbor_blur(height, neighbors, passes=max(1, radius), keep=0.50)
    local_variance = _neighbor_variance(smooth_height, neighbors)
    field_delta = [abs(density[i] - smooth_density[i]) + abs(curvature[i] - smooth_curvature[i]) * 0.75 for i in range(count)]
    saliency = [_clamp(smooth_curvature[i] * 0.32 + slope[i] * 0.22 + local_variance[i] * 0.20 + channel[i] * 0.12 + (1.0 if i in boundary else 0.0) * 0.14) for i in range(count)]
    coherence = [_clamp(1.0 - field_delta[i] * (0.45 + risk_suppression * 0.35) + quality[i] * 0.20 + confidence[i] * 0.14) for i in range(count)]
    mask_confidence = [_clamp(coherence[i] * 0.34 + edge_safety[i] * 0.20 + visibility[i] * 0.18 + (1.0 - topology_risk[i]) * 0.18 + command_score[i] * 0.10) for i in range(count)]
    material_signal = [_clamp((material_wear[i] * 0.30 + wetness[i] * 0.21 + cavity[i] * 0.17 + occlusion[i] * 0.14 + saliency[i] * 0.18) * (0.75 + material_contrast * 0.25)) for i in range(count)]
    region_count = max(2, min(96, _safe_int(getattr(settings, 'precision_v7_material_regions', 7), 7) + 2))
    material_lane = [max(0, min(region_count - 1, int(v * region_count))) for v in material_signal]
    distribution_stability = [_clamp(smooth_density[i] * 0.24 + distribution_quality[i] * 0.20 + spacing_score[i] * 0.18 + mask_confidence[i] * 0.20 + habitat[i] * 0.18) for i in range(count)]
    hydrology_priority = [_clamp(channel[i] * 0.36 + flow[i] * 0.22 + wetness[i] * 0.18 + saliency[i] * 0.12 + local_variance[i] * 0.12) for i in range(count)]
    detail_budget = [_clamp(saliency[i] * 0.30 + mask_confidence[i] * 0.22 + material_signal[i] * 0.18 + asset_priority[i] * 0.17 + visibility[i] * 0.13) for i in range(count)]
    selection_resilience = [_clamp(mask_confidence[i] * 0.40 + coherence[i] * 0.26 + (1.0 - topology_risk[i]) * 0.20 + abs(density[i] - 0.5) * 0.14) for i in range(count)]
    artifact_risk = [_clamp(topology_risk[i] * 0.28 + (1.0 - coherence[i]) * 0.24 + field_delta[i] * 0.20 + (1.0 - edge_safety[i]) * 0.18 + occlusion[i] * 0.10) for i in range(count)]
    lod_score = [_clamp(visibility[i] * 0.28 + detail_budget[i] * 0.24 + asset_priority[i] * 0.18 + distribution_stability[i] * 0.16 + (1.0 - artifact_risk[i]) * 0.14) for i in range(count)]
    interaction_score = [_clamp(mask_confidence[i] * 0.30 + detail_budget[i] * 0.26 + selection_resilience[i] * 0.20 + lod_score[i] * 0.14 + strength * 0.10) for i in range(count)]
    ui_inspection_score = [_clamp(artifact_risk[i] * 0.32 + saliency[i] * 0.26 + (1.0 - mask_confidence[i]) * 0.20 + hydrology_priority[i] * 0.12 + material_signal[i] * 0.10) for i in range(count)]
    stability_grade = [max(0, min(9, int(distribution_stability[i] * 10.0))) for i in range(count)]
    safety_grade = [max(0, min(9, int((1.0 - artifact_risk[i]) * 10.0))) for i in range(count)]

    specs = [
        ('sgs_v8_surface_saliency', 'FLOAT', saliency),
        ('sgs_v8_field_coherence', 'FLOAT', coherence),
        ('sgs_v8_mask_confidence', 'FLOAT', mask_confidence),
        ('sgs_v8_material_signal', 'FLOAT', material_signal),
        ('sgs_v8_material_lane', 'INT', material_lane),
        ('sgs_v8_distribution_stability', 'FLOAT', distribution_stability),
        ('sgs_v8_hydrology_priority', 'FLOAT', hydrology_priority),
        ('sgs_v8_detail_budget', 'FLOAT', detail_budget),
        ('sgs_v8_selection_resilience', 'FLOAT', selection_resilience),
        ('sgs_v8_interaction_score', 'FLOAT', interaction_score),
        ('sgs_v8_artifact_risk', 'FLOAT', artifact_risk),
        ('sgs_v8_lod_score', 'FLOAT', lod_score),
        ('sgs_v8_ui_inspection_score', 'FLOAT', ui_inspection_score),
        ('sgs_v8_stability_grade', 'INT', stability_grade),
        ('sgs_v8_safety_grade', 'INT', safety_grade),
    ]
    written: list[str] = []
    for name, dtype, values in specs:
        if _write_attr_values(mesh, name, dtype, values):
            written.append(name)
    try:
        obj['sgs_attribute_precision'] = 'v8_operation_grade_precision_visual_quality'
        obj['sgs_v8_quality_attribute_count'] = len(written)
        obj['sgs_v8_interaction_score_mean'] = float(_safe_mean(interaction_score))
        obj['sgs_v8_artifact_risk_mean'] = float(_safe_mean(artifact_risk))
        obj['sgs_v8_icon_contract'] = 'borderless_maximum_fill_transparent_png_32'
        obj[node_factory.GENERATED_FLAG] = True
    except Exception:
        pass
    return written


def _sgs_v8_postbuild(obj, kind: str, settings=None) -> None:
    if obj is None:
        return
    if getattr(obj, 'type', None) == 'MESH':
        try:
            _sgs_v8_write_operation_layer(obj, settings)
        except Exception:
            pass
    try:
        obj['sgs_v8_operation_grade'] = True
        obj['sgs_v8_builder_kind'] = str(kind)
        obj['sgs_algorithm'] = str(obj.get('sgs_algorithm', '')) + '|v8_operation_grade_visual_quality'
        node_factory.mark_created_object(obj)
    except Exception:
        pass


def ensure_standard_attributes(obj) -> list[str]:
    written = list(_SGS_V8_BASE_ensure_standard_attributes(obj) or [])
    try:
        written.extend(_sgs_v8_write_operation_layer(obj, None))
    except Exception:
        pass
    seen: set[str] = set()
    ordered: list[str] = []
    for name in written:
        if name not in seen:
            seen.add(name)
            ordered.append(name)
    return ordered


def polish_precision_overdrive(context=None, settings=None) -> int:
    base_count = int(_SGS_V8_BASE_polish_precision_overdrive(context, settings) or 0)
    ctx = context or bpy.context
    objects = [obj for obj in list(getattr(ctx, 'selected_objects', []) or []) if getattr(obj, 'type', '') == 'MESH']
    if not objects and getattr(getattr(ctx, 'object', None), 'type', '') == 'MESH':
        objects = [ctx.object]
    count = 0
    for obj in objects:
        try:
            ensure_standard_attributes(obj)
            _sgs_v8_write_operation_layer(obj, settings)
            count += 1
        except Exception:
            pass
    return max(base_count, count)


def refine_scene_precision(context=None, settings=None) -> int:
    count = int(_SGS_V8_BASE_refine_scene_precision(context, settings) or 0)
    ctx = context or bpy.context
    objects = [obj for obj in list(getattr(ctx, 'selected_objects', []) or []) if getattr(obj, 'type', '') == 'MESH']
    if not objects and getattr(getattr(ctx, 'object', None), 'type', '') == 'MESH':
        objects = [ctx.object]
    for obj in objects:
        try:
            ensure_standard_attributes(obj)
            obj['sgs_v8_refined'] = True
        except Exception:
            pass
    return max(count, len(objects))


def create_terrain(context=None, settings=None):
    obj = _SGS_V8_BASE_create_terrain(context, settings)
    _sgs_v8_postbuild(obj, 'terrain', settings)
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        mesh = obj.data
        count = _mesh_vertex_count(mesh)
        if count > 0:
            channel = _sgs_v8_read(mesh, 'sgs_channel', 0.0, count)
            stream = _sgs_v8_read(mesh, 'sgs_stream_power', 0.0, count)
            erosion = _sgs_v8_read(mesh, 'sgs_erosion', 0.0, count)
            deposition = _sgs_v8_read(mesh, 'sgs_deposition', 0.0, count)
            slope = _sgs_v8_read(mesh, 'sgs_slope', 0.0, count)
            saliency = _sgs_v8_read(mesh, 'sgs_v8_surface_saliency', 0.0, count)
            riverbank = [_clamp(channel[i] * 0.42 + slope[i] * 0.22 + saliency[i] * 0.18 + deposition[i] * 0.18) for i in range(count)]
            erosion_confidence = [_clamp(erosion[i] * 0.36 + stream[i] * 0.30 + channel[i] * 0.22 + slope[i] * 0.12) for i in range(count)]
            terrain_readability = [_clamp(riverbank[i] * 0.28 + erosion_confidence[i] * 0.24 + saliency[i] * 0.24 + (1.0 - abs(deposition[i] - erosion[i])) * 0.24) for i in range(count)]
            _write_attr_values(mesh, 'sgs_v8_riverbank_mask', 'FLOAT', riverbank)
            _write_attr_values(mesh, 'sgs_v8_erosion_confidence', 'FLOAT', erosion_confidence)
            _write_attr_values(mesh, 'sgs_v8_terrain_readability', 'FLOAT', terrain_readability)
            try:
                obj['sgs_algorithm'] = 'v8_riverbank_erosion_confidence_terrain_readability'
                obj['sgs_v8_terrain_readability_mean'] = float(_safe_mean(terrain_readability))
            except Exception:
                pass
    return obj


def create_scatter_points(context=None, settings=None):
    obj = _SGS_V8_BASE_create_scatter_points(context, settings)
    _sgs_v8_postbuild(obj, 'distribution', settings)
    if obj is not None and getattr(obj, 'type', None) == 'MESH':
        mesh = obj.data
        count = _mesh_vertex_count(mesh)
        if count > 1:
            points = [_to_tuple(v.co) for v in mesh.vertices]
            radii = _read_attr_values(mesh, 'sgs_spacing_radius', _safe_float(getattr(settings, 'scatter_radius', 0.15), 0.15) if settings else 0.15, count)
            nearest = _v6_nearest_distances(points, radii) if '_v6_nearest_distances' in globals() else [0.0] * count
            nearest_norm = _normalize_values(nearest)
            density = _sgs_v8_read(mesh, 'sgs_density', 1.0, count)
            quality = _sgs_v8_read(mesh, 'sgs_distribution_quality', 0.5, count)
            stability = _sgs_v8_read(mesh, 'sgs_v8_distribution_stability', 0.5, count)
            artifact = _sgs_v8_read(mesh, 'sgs_v8_artifact_risk', 0.0, count)
            bias = _clamp(_safe_float(getattr(settings, 'scatter_v8_stability_bias', 0.72), 0.72), 0.0, 2.0) / 2.0
            spacing_balance = [_clamp(1.0 - abs(nearest[i] - radii[i] * 2.0) / max(radii[i] * 2.0, 1e-9)) for i in range(count)]
            overdraw_risk = [_clamp((1.0 - nearest_norm[i]) * 0.40 + artifact[i] * 0.28 + (1.0 - spacing_balance[i]) * 0.22 + (1.0 - quality[i]) * 0.10) for i in range(count)]
            instance_readability = [_clamp(density[i] * 0.20 + quality[i] * 0.22 + stability[i] * 0.26 + spacing_balance[i] * 0.20 + bias * 0.12 - overdraw_risk[i] * 0.18) for i in range(count)]
            _write_attr_values(mesh, 'sgs_v8_spacing_balance', 'FLOAT', spacing_balance)
            _write_attr_values(mesh, 'sgs_v8_overdraw_risk', 'FLOAT', overdraw_risk)
            _write_attr_values(mesh, 'sgs_v8_instance_readability', 'FLOAT', instance_readability)
            _write_attr_values(mesh, 'sgs_v8_distribution_confidence', 'FLOAT', [_clamp(instance_readability[i] * 0.70 + (1.0 - overdraw_risk[i]) * 0.30) for i in range(count)])
            try:
                obj['sgs_algorithm'] = 'v8_spacing_balance_overdraw_risk_instance_readability'
                obj['sgs_v8_instance_readability_mean'] = float(_safe_mean(instance_readability))
            except Exception:
                pass
    return obj


def relax_distribution_points(context=None, settings=None):
    moved = _SGS_V8_BASE_relax_distribution_points(context, settings)
    obj = node_factory.active_mesh_object(context)
    _sgs_v8_postbuild(obj, 'distribution_relax', settings)
    return moved


def create_greeble_blocks(context=None, settings=None):
    obj = _SGS_V8_BASE_create_greeble_blocks(context, settings)
    _sgs_v8_postbuild(obj, 'surface_detail', settings)
    return obj


def create_building_proxy(context=None, settings=None):
    obj = _SGS_V8_BASE_create_building_proxy(context, settings)
    _sgs_v8_postbuild(obj, 'modular_structure', settings)
    return obj


def create_ivy_curve(context=None, settings=None):
    obj = _SGS_V8_BASE_create_ivy_curve(context, settings)
    try:
        if obj is not None:
            obj['sgs_v8_operation_grade'] = True
            obj['sgs_v8_builder_kind'] = 'organic_growth'
            obj['sgs_algorithm'] = str(obj.get('sgs_algorithm', 'organic_growth')) + '|v8_readable_branch_flow'
            node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj


def create_flow_network_curves(context=None, settings=None):
    obj = _SGS_V8_BASE_create_flow_network_curves(context, settings)
    try:
        if obj is not None:
            obj['sgs_v8_operation_grade'] = True
            obj['sgs_v8_builder_kind'] = 'flow_network'
            obj['sgs_algorithm'] = str(obj.get('sgs_algorithm', 'flow_network')) + '|v8_flow_readability'
            node_factory.mark_created_object(obj)
    except Exception:
        pass
    return obj


def explode_mesh_to_pieces(context=None, settings=None) -> list[Any]:
    pieces = list(_SGS_V8_BASE_explode_mesh_to_pieces(context, settings) or [])
    interlock = _clamp(_safe_float(getattr(settings, 'fragment_v8_interlock_bias', 0.62), 0.62), 0.0, 2.0) / 2.0
    for obj in pieces:
        _sgs_v8_postbuild(obj, 'fragment', settings)
        mesh = getattr(obj, 'data', None)
        if mesh is None:
            continue
        count = _mesh_vertex_count(mesh)
        if count <= 0:
            continue
        mass = _sgs_v8_read(mesh, 'sgs_fragment_mass', 0.5, count)
        compactness = _sgs_v8_read(mesh, 'sgs_fragment_compactness', 0.5, count)
        shape = _sgs_v8_read(mesh, 'sgs_fragment_shape_quality', 0.5, count)
        glue = [_clamp(mass[i] * 0.22 + compactness[i] * 0.28 + shape[i] * 0.28 + interlock * 0.22) for i in range(count)]
        seam = [_clamp(1.0 - glue[i] + compactness[i] * 0.12) for i in range(count)]
        inertia = [_clamp(mass[i] * 0.50 + shape[i] * 0.22 + glue[i] * 0.18 + interlock * 0.10) for i in range(count)]
        readability = [_clamp(glue[i] * 0.30 + shape[i] * 0.32 + inertia[i] * 0.18 + (1.0 - seam[i]) * 0.20) for i in range(count)]
        _write_attr_values(mesh, 'sgs_v8_fragment_glue', 'FLOAT', glue)
        _write_attr_values(mesh, 'sgs_v8_fragment_seam', 'FLOAT', seam)
        _write_attr_values(mesh, 'sgs_v8_fragment_inertia', 'FLOAT', inertia)
        _write_attr_values(mesh, 'sgs_v8_fragment_readability', 'FLOAT', readability)
        try:
            obj['sgs_algorithm'] = 'v8_interlock_fragment_glue_seam_readability'
            obj['sgs_v8_fragment_readability_mean'] = float(_safe_mean(readability))
        except Exception:
            pass
    return pieces



def refresh_camera_visibility_attributes(obj) -> int:
    """Refresh only camera-dependent visibility/cull attributes for the active mesh.

    This is intentionally much lighter than rebuilding the complete SGS
    precision attribute stack and is used only by the optional always-on camera
    visibility gate.
    """
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return 0
    mesh = getattr(obj, 'data', None)
    if mesh is None:
        return 0
    count = _mesh_vertex_count(mesh)
    if count <= 0:
        return 0
    visibility = _camera_visibility_scores(obj, mesh)
    lods = _read_attr_values(mesh, 'sgs_lod', 1.0, count)
    if not visibility:
        visibility = [1.0] * count
    _write_attr_values(mesh, 'sgs_visibility', 'FLOAT', visibility[:count])
    _write_attr_values(mesh, 'sgs_cull', 'FLOAT', [1.0 if lods[i] >= 0.08 and visibility[i] > 0.05 else 0.0 for i in range(count)])
    try:
        mesh.update()
    except Exception:
        pass
    return count
