"""Native datablocks and selection adapters used by the procedural tool families."""
import bpy
from . import catalog
from .max_procedural_primitives.runtime import GENERATION
def _mark_owned(item,role='generated'):
    try:item['jelararagi_sgs_owner_suite']='smart_geometry_suite'
    except TypeError:
        # Legacy modifiers without custom properties keep their ownership record on the object.
        owner=item.id_data
        if isinstance(item,bpy.types.Modifier) and owner is not None:owner['sgs_modifier_role_'+item.name]=role
        return
    item['jelararagi_sgs_owner_revision']='1.0.0';item['jelararagi_sgs_owner_generation']=GENERATION
    item['smart_geometry_suite_generated']=True;item['sgs_role']=role
def _material(name,color,roughness=.5,metallic=0):
    mat=next((m for m in bpy.data.materials if m.get('sgs_material_id')==name and m.get('jelararagi_sgs_owner_suite')=='smart_geometry_suite'),None)
    if mat is None:
        mat=bpy.data.materials.new(name);mat.diffuse_color=color;mat.roughness=roughness;mat.metallic=metallic
        mat.use_nodes=True;shader=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
        for socket,value in (('Base Color',color),('Roughness',roughness),('Metallic',metallic)):shader.inputs[socket].default_value=value
        _mark_owned(mat,'material');mat['sgs_material_id']=name
    return mat
def _select_only(context,objects):
    for o in tuple(context.selected_objects):o.select_set(False)
    for o in objects:o.select_set(True)
    if objects:context.view_layer.objects.active=objects[0]
def _mesh_obj(context,label,vertices,faces,mat=None,smooth=False,edges=()):
    data=bpy.data.meshes.new(label);data.from_pydata(vertices,edges,faces);data.update()
    o=bpy.data.objects.new(label,data);context.collection.objects.link(o);_mark_owned(o)
    if mat:data.materials.append(mat)
    if smooth:
        for f in data.polygons:f.use_smooth=True
    return o
def _add_bevel(obj,width,segments):
    mod=obj.modifiers.new('Round Edges','BEVEL');mod.width=width;mod.segments=segments;_mark_owned(mod,'debris_modifier');return mod
def _add_decimate(obj,percent):
    mod=obj.modifiers.new('Simplify','DECIMATE');mod.ratio=max(.001,min(1,percent/100));_mark_owned(mod,'debris_modifier');return mod
def object_from_form(context,label,form):return _mesh_obj(context,label,form.vertices,form.faces,edges=form.edges)
def curve_object(context,label,lines,radius):
    data=bpy.data.curves.new(label,'CURVE');data.dimensions='3D';data.resolution_u=1;data.bevel_depth=radius;data.bevel_resolution=2
    for points in lines:
        if len(points)<2:continue
        line=data.splines.new('POLY');line.points.add(len(points)-1)
        for p,co in zip(line.points,points):p.co=(*co,1)
    ob=bpy.data.objects.new(label,data);context.collection.objects.link(ob);_mark_owned(ob);return ob
