# Third-party notices

This Blender add-on is a port/reimplementation of the original Debris Maker 2 MaxScript tool.

- Original project: Debris Maker 2
- Original author: Aaron Dabelow
- Original repository: TheOnlyAaron/Debris_Maker2
- Original public repository license: MIT License
- Blender port author: JELararagi
- Blender port license: GPL-3.0-or-later

The Blender port does not execute the original encrypted `.mse` files. For shape-parity conversion, selected public MaxScript mesh vertex/face tables are extracted into `sgs_debris_mesh_data.py` and regenerated as native Blender mesh data. Procedural modifiers and UI behavior are implemented in native Blender Python.

The original Debris Maker 2 MIT license text is included at `debris_maker_2_LICENSE.txt`.
Upstream source reference: `TheOnlyAaron/Debris_Maker2` commit `4a7116e23e3bd53ffd01e6f12ccab1781bd16153`.
