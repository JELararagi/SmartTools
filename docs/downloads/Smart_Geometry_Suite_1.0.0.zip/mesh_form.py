"""Construction operations for original parametric meshes in local space."""
from math import cos,sin,tau
from mathutils import Vector

class MeshForm:
    def __init__(self):
        self.vertices=[];self.edges=[];self.faces=[]
    def vertex(self,point):
        self.vertices.append(tuple(point));return len(self.vertices)-1
    def line(self,points,closed=False):
        ids=[self.vertex(p) for p in points]
        self.edges.extend(zip(ids,ids[1:]))
        if closed and len(ids)>2:self.edges.append((ids[-1],ids[0]))
        return ids
    def face(self,points):self.faces.append(tuple(self.vertex(p) for p in points))
    def append(self,other,transform=None):
        offset=len(self.vertices)
        self.vertices.extend(tuple(transform(Vector(p))) if transform else p for p in other.vertices)
        self.faces.extend(tuple(n+offset for n in f) for f in other.faces)
        self.edges.extend((a+offset,b+offset) for a,b in other.edges)
        return self
    def add_box(self,x0,x1,y0,y1,z0,z1):
        points=[(x,y,z) for z in (z0,z1) for y in (y0,y1) for x in (x0,x1)]
        offset=len(self.vertices);self.vertices.extend(points)
        self.faces.extend(tuple(i+offset for i in f) for f in ((0,2,3,1),(4,5,7,6),(0,1,5,4),(1,3,7,5),(3,2,6,7),(2,0,4,6)))
        return self
    def grid(self,nx,ny,sample):
        rows=[[self.vertex(sample(i/nx,j/ny)) for i in range(nx+1)] for j in range(ny+1)]
        for a,b in zip(rows,rows[1:]):
            self.faces.extend((a[i],a[i+1],b[i+1],b[i]) for i in range(nx))
        return self
    def bridge(self,first,second,close=True):
        n=max(len(first),len(second))
        for i in range(n if close else n-1):
            j=(i+1)%n
            face=[first[i%len(first)],first[j%len(first)],second[j%len(second)],second[i%len(second)]]
            face=list(dict.fromkeys(face))
            if len(face)>=3:self.faces.append(tuple(face))
    def rings(self,rows,close=True):
        ids=[[self.vertex(p) for p in loop] for loop in rows]
        for a,b in zip(ids,ids[1:]):self.bridge(a,b,close)
        return ids
    def merge_seams(self):
        seen={};points=[];indices=[]
        for p in self.vertices:
            key=tuple(round(v,9) for v in p)
            if key not in seen:seen[key]=len(points);points.append(p)
            indices.append(seen[key])
        self.vertices=points
        self.faces=[f for raw in self.faces if len(f:=tuple(dict.fromkeys(indices[i] for i in raw)))>=3]
        self.edges=[(indices[a],indices[b]) for a,b in self.edges if indices[a]!=indices[b]]
        return self

def around(radius,z,n,start=0,sweep=tau):
    if abs(radius)<1e-10:return [(0,0,z)]
    closed=abs(abs(sweep)-tau)<1e-7
    return [(radius*cos(start+sweep*i/n),radius*sin(start+sweep*i/n),z) for i in range(n if closed else n+1)]

def lathe(profile,sides,start=0,sweep=tau,caps=False):
    m=MeshForm();closed=abs(abs(sweep)-tau)<1e-7
    rings=m.rings([around(r,z,sides,start,sweep) for r,z in profile],closed)
    if caps:
        for end,reverse in ((rings[0],True),(rings[-1],False)):
            if len(end)>2:
                center=m.vertex((0,0,m.vertices[end[0]][2]))
                for i in range(len(end) if closed else len(end)-1):
                    a,b=end[i],end[(i+1)%len(end)];m.faces.append((center,b,a) if reverse else (center,a,b))
    if not closed:
        for column in (0,-1):
            boundary=list(dict.fromkeys(row[column] for row in rings))
            if len(boundary)>=3:m.faces.append(tuple(boundary if column==0 else reversed(boundary)))
    return m

def rect_prism(polygon,height):
    m=MeshForm();a,b=m.rings([[(x,y,z) for x,y in polygon] for z in (0,height)])
    m.faces.extend((tuple(a[::-1]),tuple(b)));return m

def profile_tube(points,radius,sides,cyclic=False,caps=True):
    m=MeshForm();path=[Vector(p) for p in points]
    if len(path)<2:return m
    rows=[]
    for i,center in enumerate(path):
        tangent=(path[(i+1)%len(path)]-path[i-1]) if cyclic else (path[min(i+1,len(path)-1)]-path[max(i-1,0)])
        tangent.normalize()
        side=tangent.cross(Vector((0,0,1)) if abs(tangent.z)<.95 else Vector((0,1,0))).normalized()
        up=side.cross(tangent).normalized()
        r=radius(i) if callable(radius) else radius
        rows.append([center+r*(cos(tau*j/sides)*side+sin(tau*j/sides)*up) for j in range(sides)])
    rings=m.rings(rows)
    if cyclic:m.bridge(rings[-1],rings[0])
    elif caps:m.faces.extend((tuple(rings[0][::-1]),tuple(rings[-1])))
    return m

def capped_count(n,lo=1,hi=512):return min(hi,max(lo,int(n)))

