import bpy
from . import schema, interface, operations, interaction
from .grease_mesh.operators import add_gpencil,array_on_curve,lattice_wrap

class GPTOOLS_OT_add_gpencil(add_gpencil.GPTOOLS_OT_add_gpencil,bpy.types.Operator):
    bl_idname='gptools.add_gpencil'
    bl_label='Add New Grease Pencil'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.add_gpencil')

    @classmethod
    def poll(cls,context):
        return add_gpencil.GPTOOLS_OT_add_gpencil.poll(context)

class GPTOOLS_OT_apply_all_modifiers(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.apply_all_modifiers'
    bl_label='Apply All Modifiers'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.apply_all_modifiers')

class GPTOOLS_OT_array_on_curve(array_on_curve.GPTOOLS_OT_array_on_curve,bpy.types.Operator):
    bl_idname='gptools.array_on_curve'
    bl_label='Array on Curve'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.array_on_curve')

    @classmethod
    def poll(cls,context):
        return array_on_curve.GPTOOLS_OT_array_on_curve.poll(context)

class GPTOOLS_OT_bool_cut(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.bool_cut'
    bl_label='Bool Cut'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.bool_cut')

class GPTOOLS_OT_gn_mirror_mesh(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.gn_mirror_mesh'
    bl_label='Mirror Mesh (GN)'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.gn_mirror_mesh')

class GPTOOLS_OT_gn_path_mesh(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.gn_path_mesh'
    bl_label='Path Mesh (GN)'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.gn_path_mesh')

class GPTOOLS_OT_gn_solid_mesh(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.gn_solid_mesh'
    bl_label='Solid Mesh (GN)'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.gn_solid_mesh')

class GPTOOLS_OT_gn_wall_mesh(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.gn_wall_mesh'
    bl_label='Wall Mesh (GN)'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.gn_wall_mesh')

class GPTOOLS_OT_knife_cut(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.knife_cut'
    bl_label='Knife Cut'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.knife_cut')

class GPTOOLS_OT_lattice_wrap(lattice_wrap.GPTOOLS_OT_lattice_wrap,bpy.types.Operator):
    bl_idname='gptools.lattice_wrap'
    bl_label='Lattice Wrap'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.lattice_wrap')

    @classmethod
    def poll(cls,context):
        return lattice_wrap.GPTOOLS_OT_lattice_wrap.poll(context)

class GPTOOLS_OT_screw_mesh(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.screw_mesh'
    bl_label='Create Screw Mesh'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.screw_mesh')

class GPTOOLS_OT_stamp_scatter(operations.Operation,bpy.types.Operator):
    bl_idname='gptools.stamp_scatter'
    bl_label='Stamp Scatter'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('gptools.stamp_scatter')

class JEL_MAX_OT_add_generator(operations.Operation,bpy.types.Operator):
    bl_idname='jel_max.add_generator'
    bl_label='Add Max Primitive'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('jel_max.add_generator')

class JEL_MAX_OT_draw_generator(interaction.Draw, operations.Operation,bpy.types.Operator):
    bl_idname='jel_max.draw_generator'
    bl_label='Drag Max Primitive'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('jel_max.draw_generator')

class JEL_MAX_OT_install_assets(operations.Operation,bpy.types.Operator):
    bl_idname='jel_max.install_assets'
    bl_label='Install Max Primitive Assets'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('jel_max.install_assets')

class JEL_MAX_OT_refresh_selected(operations.Operation,bpy.types.Operator):
    bl_idname='jel_max.refresh_selected'
    bl_label='Refresh Max Primitive'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('jel_max.refresh_selected')

class JEL_MAX_OT_update_all(operations.Operation,bpy.types.Operator):
    bl_idname='jel_max.update_all'
    bl_label='Update All Max Primitives'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('jel_max.update_all')

class JEL_MAX_OT_update_selected(operations.Operation,bpy.types.Operator):
    bl_idname='jel_max.update_selected'
    bl_label='Update Selected Max Primitive'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('jel_max.update_selected')

class SMART_GEOMETRY_SUITE_OT_add_standard_attributes(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.add_standard_attributes'
    bl_label='Build Precision Attributes'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.add_standard_attributes')

class SMART_GEOMETRY_SUITE_OT_apply_feature(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.apply_feature'
    bl_label='Apply Active Feature'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.apply_feature')

class SMART_GEOMETRY_SUITE_OT_apply_full_independent_suite(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.apply_full_independent_suite'
    bl_label='Apply Full Independent Toolset'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.apply_full_independent_suite')

class SMART_GEOMETRY_SUITE_OT_apply_pack(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.apply_pack'
    bl_label='Apply Active Pack'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.apply_pack')

class SMART_GEOMETRY_SUITE_OT_apply_precision_preset(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.apply_precision_preset'
    bl_label='Apply Precision Preset'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.apply_precision_preset')

class SMART_GEOMETRY_SUITE_OT_apply_selection_string(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.apply_selection_string'
    bl_label='Apply Precision Selection'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.apply_selection_string')

class SMART_GEOMETRY_SUITE_OT_create_attribute_heatmap(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_attribute_heatmap'
    bl_label='Create Attribute Heatmap'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_attribute_heatmap')

class SMART_GEOMETRY_SUITE_OT_create_attribute_snapshot(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_attribute_snapshot'
    bl_label='Create Attribute Snapshot'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_attribute_snapshot')

class SMART_GEOMETRY_SUITE_OT_create_building_proxy(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_building_proxy'
    bl_label='Create Modular Structure'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_building_proxy')

class SMART_GEOMETRY_SUITE_OT_create_demo_scene(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_demo_scene'
    bl_label='Create Demo Scene'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_demo_scene')

class SMART_GEOMETRY_SUITE_OT_create_distribution_proxy_instances(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_distribution_proxy_instances'
    bl_label='Create Distribution Proxy Instances'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_distribution_proxy_instances')

class SMART_GEOMETRY_SUITE_OT_create_flow_network(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_flow_network'
    bl_label='Create Drainage Flow Network'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_flow_network')

class SMART_GEOMETRY_SUITE_OT_create_greeble_blocks(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_greeble_blocks'
    bl_label='Create Surface Detail Blocks'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_greeble_blocks')

class SMART_GEOMETRY_SUITE_OT_create_ivy_curve(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_ivy_curve'
    bl_label='Create Organic Growth Curves'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_ivy_curve')

class SMART_GEOMETRY_SUITE_OT_create_node_library(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_node_library'
    bl_label='Create Node Group Library'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_node_library')

class SMART_GEOMETRY_SUITE_OT_create_scatter_points(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_scatter_points'
    bl_label='Create Precision Distribution Points'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_scatter_points')

class SMART_GEOMETRY_SUITE_OT_create_terrain(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.create_terrain'
    bl_label='Create Precision Terrain'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.create_terrain')

class SMART_GEOMETRY_SUITE_OT_debris_about(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.debris_about'
    bl_label='About'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.debris_about')

class SMART_GEOMETRY_SUITE_OT_debris_generate(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.debris_generate'
    bl_label='Generate'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.debris_generate')

class SMART_GEOMETRY_SUITE_OT_debris_open_modules_dir(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.debris_open_modules_dir'
    bl_label='Open modules directory'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.debris_open_modules_dir')

class SMART_GEOMETRY_SUITE_OT_debris_open_url(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.debris_open_url'
    bl_label='Open URL'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.debris_open_url')

class SMART_GEOMETRY_SUITE_OT_debris_open_window(interaction.DebrisWindow, operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.debris_open_window'
    bl_label='Smart Geometry Debris'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.debris_open_window')

class SMART_GEOMETRY_SUITE_OT_debris_refresh_modules(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.debris_refresh_modules'
    bl_label='Embedded Module Availability'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.debris_refresh_modules')

class SMART_GEOMETRY_SUITE_OT_explode_mesh_to_pieces(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.explode_mesh_to_pieces'
    bl_label='Create Clustered Fragments'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.explode_mesh_to_pieces')

class SMART_GEOMETRY_SUITE_OT_export_bundle_manifest(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.export_bundle_manifest'
    bl_label='Export Toolset Bundle Manifest'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.export_bundle_manifest')

class SMART_GEOMETRY_SUITE_OT_export_design_coverage(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.export_design_coverage'
    bl_label='Export Design Coverage JSON'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.export_design_coverage')

class SMART_GEOMETRY_SUITE_OT_export_diagnostics(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.export_diagnostics'
    bl_label='Export Diagnostics JSON'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.export_diagnostics')

class SMART_GEOMETRY_SUITE_OT_export_icon_reference_sheet(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.export_icon_reference_sheet'
    bl_label='Export Icon Reference Sheet'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.export_icon_reference_sheet')

class SMART_GEOMETRY_SUITE_OT_export_inventory(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.export_inventory'
    bl_label='Export Inventory JSON'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.export_inventory')

class SMART_GEOMETRY_SUITE_OT_export_usd_manifest(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.export_usd_manifest'
    bl_label='Export USD Sidecar Manifest'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.export_usd_manifest')

class SMART_GEOMETRY_SUITE_OT_import_csv_points(interaction.SelectFile, operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.import_csv_points'
    bl_label='Import CSV Points'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.import_csv_points')

class SMART_GEOMETRY_SUITE_OT_open_help(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.open_help'
    bl_label='Open Help'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.open_help')

class SMART_GEOMETRY_SUITE_OT_open_visual_reference(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.open_visual_reference'
    bl_label='Open Visual Reference'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.open_visual_reference')

class SMART_GEOMETRY_SUITE_OT_polish_precision_overdrive(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.polish_precision_overdrive'
    bl_label='Run Precision Polish'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.polish_precision_overdrive')

class SMART_GEOMETRY_SUITE_OT_rebuild_node_library(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.rebuild_node_library'
    bl_label='Rebuild Node Group Library'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.rebuild_node_library')

class SMART_GEOMETRY_SUITE_OT_refine_scene_precision(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.refine_scene_precision'
    bl_label='Refine Scene Precision'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.refine_scene_precision')

class SMART_GEOMETRY_SUITE_OT_refresh_diagnostics(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.refresh_diagnostics'
    bl_label='Refresh Diagnostics'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.refresh_diagnostics')

class SMART_GEOMETRY_SUITE_OT_relax_distribution_points(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.relax_distribution_points'
    bl_label='Relax Distribution Points'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.relax_distribution_points')

class SMART_GEOMETRY_SUITE_OT_reload_custom_icons(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.reload_custom_icons'
    bl_label='Reload Custom Icons'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.reload_custom_icons')

class SMART_GEOMETRY_SUITE_OT_remove_generated_node_groups(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.remove_generated_node_groups'
    bl_label='Remove Generated Node Groups'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.remove_generated_node_groups')

class SMART_GEOMETRY_SUITE_OT_run_visual_workflow(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.run_visual_workflow'
    bl_label='Run Visual Workflow'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.run_visual_workflow')

class SMART_GEOMETRY_SUITE_OT_toggle_ui_section(operations.Operation,bpy.types.Operator):
    bl_idname='smart_geometry_suite.toggle_ui_section'
    bl_label='Toggle Smart Geometry Section'
    bl_options={'REGISTER','UNDO'}
    __annotations__=schema.arguments('smart_geometry_suite.toggle_ui_section')

class CLIP_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='CLIP_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='CLIP_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class DOPESHEET_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='DOPESHEET_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='DOPESHEET_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class FILEBROWSER_PT_sgs_asset_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='FILEBROWSER_PT_sgs_asset_root'
    bl_label='Smart Geometry'
    bl_space_type='FILE_BROWSER'
    bl_region_type='TOOL_PROPS'
    bl_category='Smart Geometry'

class FILEBROWSER_PT_sgs_file_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='FILEBROWSER_PT_sgs_file_root'
    bl_label='Smart Geometry'
    bl_space_type='FILE_BROWSER'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class GRAPH_PT_sgs_graph_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='GRAPH_PT_sgs_graph_root'
    bl_label='Smart Geometry'
    bl_space_type='GRAPH_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class IMAGE_PT_sgs_image_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='IMAGE_PT_sgs_image_root'
    bl_label='Smart Geometry'
    bl_space_type='IMAGE_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class JELMAX_MT_add_root(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_add_root'
    bl_label='Max Primitives'

class JELMAX_MT_aec(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_aec'
    bl_label='AEC Extended'

class JELMAX_MT_compound(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_compound'
    bl_label='Compound Objects'

class JELMAX_MT_doors(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_doors'
    bl_label='Doors'

class JELMAX_MT_extended(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_extended'
    bl_label='Extended Primitives'

class JELMAX_MT_patch_nurbs(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_patch_nurbs'
    bl_label='Patch / NURBS Surfaces'

class JELMAX_MT_shape_extended(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_shape_extended'
    bl_label='Shapes / Extended Splines'

class JELMAX_MT_shape_nurbs(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_shape_nurbs'
    bl_label='Shapes / NURBS Curves'

class JELMAX_MT_shape_splines(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_shape_splines'
    bl_label='Shapes / Splines'

class JELMAX_MT_stairs(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_stairs'
    bl_label='Stairs'

class JELMAX_MT_standard(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_standard'
    bl_label='Standard Primitives'

class JELMAX_MT_windows(interface.AddMenu,bpy.types.Menu):
    bl_idname='JELMAX_MT_windows'
    bl_label='Windows'

class JELMAX_PT_modifier_active_controls(interface.ModifierPanel,bpy.types.Panel):
    bl_idname='JELMAX_PT_modifier_active_controls'
    bl_label='Max Primitives Parameters'
    bl_space_type='PROPERTIES'
    bl_region_type='WINDOW'

class NLA_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='NLA_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='NLA_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class NODE_PT_sgs_geometry_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='NODE_PT_sgs_geometry_root'
    bl_label='Smart Geometry'
    bl_space_type='NODE_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class SEQUENCER_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='SEQUENCER_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='SEQUENCE_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class SPREADSHEET_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='SPREADSHEET_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='SPREADSHEET'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class TEXT_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='TEXT_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='TEXT_EDITOR'
    bl_region_type='UI'
    bl_category='Smart Geometry'

class VIEW3D_PT_sgs_root(interface.MainPanel,bpy.types.Panel):
    bl_idname='VIEW3D_PT_sgs_root'
    bl_label='Smart Geometry'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Smart Geometry'

CLASSES=(
    GPTOOLS_OT_add_gpencil,
    GPTOOLS_OT_apply_all_modifiers,
    GPTOOLS_OT_array_on_curve,
    GPTOOLS_OT_bool_cut,
    GPTOOLS_OT_gn_mirror_mesh,
    GPTOOLS_OT_gn_path_mesh,
    GPTOOLS_OT_gn_solid_mesh,
    GPTOOLS_OT_gn_wall_mesh,
    GPTOOLS_OT_knife_cut,
    GPTOOLS_OT_lattice_wrap,
    GPTOOLS_OT_screw_mesh,
    GPTOOLS_OT_stamp_scatter,
    JEL_MAX_OT_add_generator,
    JEL_MAX_OT_draw_generator,
    JEL_MAX_OT_install_assets,
    JEL_MAX_OT_refresh_selected,
    JEL_MAX_OT_update_all,
    JEL_MAX_OT_update_selected,
    SMART_GEOMETRY_SUITE_OT_add_standard_attributes,
    SMART_GEOMETRY_SUITE_OT_apply_feature,
    SMART_GEOMETRY_SUITE_OT_apply_full_independent_suite,
    SMART_GEOMETRY_SUITE_OT_apply_pack,
    SMART_GEOMETRY_SUITE_OT_apply_precision_preset,
    SMART_GEOMETRY_SUITE_OT_apply_selection_string,
    SMART_GEOMETRY_SUITE_OT_create_attribute_heatmap,
    SMART_GEOMETRY_SUITE_OT_create_attribute_snapshot,
    SMART_GEOMETRY_SUITE_OT_create_building_proxy,
    SMART_GEOMETRY_SUITE_OT_create_demo_scene,
    SMART_GEOMETRY_SUITE_OT_create_distribution_proxy_instances,
    SMART_GEOMETRY_SUITE_OT_create_flow_network,
    SMART_GEOMETRY_SUITE_OT_create_greeble_blocks,
    SMART_GEOMETRY_SUITE_OT_create_ivy_curve,
    SMART_GEOMETRY_SUITE_OT_create_node_library,
    SMART_GEOMETRY_SUITE_OT_create_scatter_points,
    SMART_GEOMETRY_SUITE_OT_create_terrain,
    SMART_GEOMETRY_SUITE_OT_debris_about,
    SMART_GEOMETRY_SUITE_OT_debris_generate,
    SMART_GEOMETRY_SUITE_OT_debris_open_modules_dir,
    SMART_GEOMETRY_SUITE_OT_debris_open_url,
    SMART_GEOMETRY_SUITE_OT_debris_open_window,
    SMART_GEOMETRY_SUITE_OT_debris_refresh_modules,
    SMART_GEOMETRY_SUITE_OT_explode_mesh_to_pieces,
    SMART_GEOMETRY_SUITE_OT_export_bundle_manifest,
    SMART_GEOMETRY_SUITE_OT_export_design_coverage,
    SMART_GEOMETRY_SUITE_OT_export_diagnostics,
    SMART_GEOMETRY_SUITE_OT_export_icon_reference_sheet,
    SMART_GEOMETRY_SUITE_OT_export_inventory,
    SMART_GEOMETRY_SUITE_OT_export_usd_manifest,
    SMART_GEOMETRY_SUITE_OT_import_csv_points,
    SMART_GEOMETRY_SUITE_OT_open_help,
    SMART_GEOMETRY_SUITE_OT_open_visual_reference,
    SMART_GEOMETRY_SUITE_OT_polish_precision_overdrive,
    SMART_GEOMETRY_SUITE_OT_rebuild_node_library,
    SMART_GEOMETRY_SUITE_OT_refine_scene_precision,
    SMART_GEOMETRY_SUITE_OT_refresh_diagnostics,
    SMART_GEOMETRY_SUITE_OT_relax_distribution_points,
    SMART_GEOMETRY_SUITE_OT_reload_custom_icons,
    SMART_GEOMETRY_SUITE_OT_remove_generated_node_groups,
    SMART_GEOMETRY_SUITE_OT_run_visual_workflow,
    SMART_GEOMETRY_SUITE_OT_toggle_ui_section,
    CLIP_PT_sgs_root,
    DOPESHEET_PT_sgs_root,
    FILEBROWSER_PT_sgs_asset_root,
    FILEBROWSER_PT_sgs_file_root,
    GRAPH_PT_sgs_graph_root,
    IMAGE_PT_sgs_image_root,
    JELMAX_MT_add_root,
    JELMAX_MT_aec,
    JELMAX_MT_compound,
    JELMAX_MT_doors,
    JELMAX_MT_extended,
    JELMAX_MT_patch_nurbs,
    JELMAX_MT_shape_extended,
    JELMAX_MT_shape_nurbs,
    JELMAX_MT_shape_splines,
    JELMAX_MT_stairs,
    JELMAX_MT_standard,
    JELMAX_MT_windows,
    JELMAX_PT_modifier_active_controls,
    NLA_PT_sgs_root,
    NODE_PT_sgs_geometry_root,
    SEQUENCER_PT_sgs_root,
    SPREADSHEET_PT_sgs_root,
    TEXT_PT_sgs_root,
    VIEW3D_PT_sgs_root,
)
