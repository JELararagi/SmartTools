# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

_PACKAGE_DIR = Path(__file__).resolve().parent
_DATA_PATH = _PACKAGE_DIR / 'data' / 'feature_inventory.json'
_COVERAGE_PATH = _PACKAGE_DIR / 'data' / 'design_coverage.json'


def _load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}


INVENTORY: dict[str, Any] = _load_json(_DATA_PATH)
DESIGN_COVERAGE: dict[str, Any] = _load_json(_COVERAGE_PATH)
SOURCE_COVERAGE: dict[str, Any] = DESIGN_COVERAGE  # Backward-compatible alias for older callers.
FEATURES: list[dict[str, Any]] = list(INVENTORY.get('features') or [])
CATEGORIES: list[dict[str, Any]] = list(INVENTORY.get('categories') or [])
PACKS: list[dict[str, Any]] = list(INVENTORY.get('packs') or [])
FEATURE_BY_ID: dict[str, dict[str, Any]] = {str(f.get('id')): f for f in FEATURES if f.get('id')}
CATEGORY_BY_ID: dict[str, dict[str, Any]] = {str(c.get('id')): c for c in CATEGORIES if c.get('id')}
PACK_BY_ID: dict[str, dict[str, Any]] = {str(p.get('id')): p for p in PACKS if p.get('id')}

_DOMAIN_JA = {
    'Architecture Detail': '建築ディテール',
    'Automation': '自動化',
    'Capsule Workflow': 'カプセルワークフロー',
    'Debug Analysis': 'デバッグ解析',
    'Field & Attribute': 'フィールドと属性',
    'Fragmentation': '破片化',
    'Growth Curve': '成長カーブ',
    'Material Coordinates': 'マテリアル座標',
    'Matter & Volume': '物質とボリューム',
    'Open Data Exchange': 'オープンデータ連携',
    'Optimization': '最適化',
    'Selection Logic': '選択ロジック',
    'Simulation Proxy': 'シミュレーションプロキシ',
    'Surface Distribution': '表面分布',
    'Terrain Habitat': '地形と生息環境',
    'Time & Motion': '時間とモーション',
    'UV Bake': 'UVとベイク',
    'Utility': 'ユーティリティ',
    'Visual Interface': 'ビジュアルインターフェース',
}


_ENUM_ITEM_CACHE_MAX = 32
_FILTER_FEATURES_CACHE_MAX = 128
_ENUM_ITEM_CACHE: dict[str, list[tuple[str, str, str]]] = {}
_LANG_CACHE_KEY = None
_LANG_CACHE_VALUE = False
_FILTER_FEATURES_CACHE: dict[tuple[str, str, str], tuple[dict[str, Any], ...]] = {}
_COUNT_BY_CATEGORY_CACHE: dict[str, int] | None = None
_COUNT_BY_DOMAIN_CACHE: dict[str, int] | None = None


def _language_key(context=None) -> str:
    return 'ja' if is_japanese(context) else 'en'


def _cached_enum_items(key: str, context, builder):
    cache_key = f'{key}:{_language_key(context)}'
    items = _ENUM_ITEM_CACHE.get(cache_key)
    if items is None:
        items = list(builder())
        if len(_ENUM_ITEM_CACHE) >= _ENUM_ITEM_CACHE_MAX:
            _ENUM_ITEM_CACHE.clear()
        _ENUM_ITEM_CACHE[cache_key] = items
    return items


def _current_language_key(context=None) -> str:
    try:
        import bpy  # type: ignore
        locale = str(getattr(bpy.app.translations, 'locale', '') or '')
        if not locale:
            locale = str(getattr(bpy.context.preferences.view, 'language', '') or '')
        return locale or 'en_US'
    except Exception:
        return 'en_US'


def is_japanese(context=None) -> bool:
    global _LANG_CACHE_KEY, _LANG_CACHE_VALUE
    key = _current_language_key(context)
    if key != _LANG_CACHE_KEY:
        _LANG_CACHE_KEY = key
        _LANG_CACHE_VALUE = str(key).lower().startswith('ja')
    return bool(_LANG_CACHE_VALUE)


def text(en: str, ja: str, context=None) -> str:
    return str(ja if is_japanese(context) else en)


def failure_text(en: str, ja: str, exc: object = None, context=None) -> str:
    """Failure message in the UI language; a detail in the other language is left out."""
    detail = str(exc or '').strip()
    has_japanese = any(0x3040 <= ord(ch) <= 0x9FFF for ch in detail)
    japanese = is_japanese(context)
    message = str(ja if japanese else en)
    if detail and has_japanese == japanese:
        return f'{message}: {detail}'
    return message


def localized(item: dict[str, Any], key: str, context=None) -> str:
    suffix = 'ja' if is_japanese(context) else 'en'
    value = item.get(f'{key}_{suffix}')
    if value is None:
        value = item.get(f'{key}_en') or item.get(f'{key}_ja') or item.get(key) or ''
    return str(value)


def _domain_id(value: str) -> str:
    text_value = re.sub(r'[^a-z0-9]+', '_', str(value or '').lower()).strip('_')
    return text_value or 'general'


def domain_id(feature: dict[str, Any]) -> str:
    return str(feature.get('design_domain_id') or _domain_id(str(feature.get('design_domain') or feature.get('source_system') or 'General')))


def domain_label_from_value(value: str, context=None) -> str:
    return text(str(value), _DOMAIN_JA.get(str(value), str(value)), context)


def feature_domain_label(feature: dict[str, Any], context=None) -> str:
    en = str(feature.get('design_domain_en') or feature.get('design_domain') or feature.get('source_system') or '')
    ja = str(feature.get('design_domain_ja') or _DOMAIN_JA.get(en, en))
    return text(en, ja, context)


def feature_label(feature_id: str, context=None) -> str:
    return localized(FEATURE_BY_ID.get(str(feature_id), {}), 'label', context) or str(feature_id)


def feature_tooltip(feature_id: str, context=None) -> str:
    feature = FEATURE_BY_ID.get(str(feature_id), {})
    return localized(feature, 'tooltip', context) or localized(feature, 'summary', context)


def category_items(context=None):
    def _build():
        items = []
        for category in CATEGORIES:
            cid = str(category.get('id') or '')
            if not cid:
                continue
            items.append((cid, localized(category, 'label', context), localized(category, 'summary', context)))
        return items or [('all', 'All Features', 'Show every feature')]
    return _cached_enum_items('category', context, _build)


def feature_items(context=None):
    def _build():
        items = []
        for feature in FEATURES:
            fid = str(feature.get('id') or '')
            if not fid:
                continue
            items.append((fid, localized(feature, 'label', context), localized(feature, 'tooltip', context)))
        return items or [('smart_attribute_dictionary', 'Smart Attribute Dictionary', 'Create standard attributes')]
    return _cached_enum_items('feature', context, _build)


def pack_items(context=None):
    def _build():
        items = []
        for pack in PACKS:
            pid = str(pack.get('id') or '')
            if not pid:
                continue
            items.append((pid, localized(pack, 'label', context), localized(pack, 'description', context)))
        return items or [('p0_core', 'Independent Core', 'Core pack')]
    return _cached_enum_items('pack', context, _build)


def design_domain_items(context=None):
    def _build():
        label_all = text('All Domains', '全ドメイン', context)
        desc_all = text('Show every independent design domain.', 'すべての独自設計ドメインを表示します。', context)
        items = [('all', label_all, desc_all)]
        seen: set[str] = set()
        for feature in FEATURES:
            did = domain_id(feature)
            if did in seen:
                continue
            seen.add(did)
            label = feature_domain_label(feature, context)
            desc = text('Filter by this design domain.', 'この設計ドメインで絞り込みます。', context)
            items.append((did, label, desc))
        return items
    return _cached_enum_items('domain', context, _build)


def source_items(context=None):
    # Backward-compatible name used by the PropertyGroup. The UI presents this as a design-domain filter.
    return design_domain_items(context)


def features_for_pack(pack_id: str) -> list[dict[str, Any]]:
    pid = str(pack_id or '')
    if pid == 'all':
        return list(FEATURES)
    pack = PACK_BY_ID.get(pid)
    if not pack:
        return []
    result = []
    for fid in pack.get('feature_ids') or []:
        feature = FEATURE_BY_ID.get(str(fid))
        if feature:
            result.append(feature)
    return result


def filter_features(category: str = 'all', source: str = 'all', search: str = '', context=None) -> list[dict[str, Any]]:
    del context
    category = str(category or 'all')
    source = str(source or 'all')
    needle = str(search or '').strip().lower()
    cache_key = (category, source, needle)
    cached = _FILTER_FEATURES_CACHE.get(cache_key)
    if cached is not None:
        return list(cached)
    result: list[dict[str, Any]] = []
    for feature in FEATURES:
        if category not in {'', 'all'} and str(feature.get('category') or '') != category:
            continue
        if source not in {'', 'all'} and domain_id(feature) != source:
            continue
        if needle:
            hay = ' '.join([
                str(feature.get('id') or ''),
                domain_id(feature),
                str(feature.get('design_domain') or ''),
                str(feature.get('design_domain_ja') or ''),
                str(feature.get('requirement_code') or ''),
                str(feature.get('source_feature') or ''),
                str(feature.get('label_en') or ''),
                str(feature.get('label_ja') or ''),
                str(feature.get('summary_en') or ''),
                str(feature.get('summary_ja') or ''),
                ' '.join(str(k) for k in (feature.get('keywords') or [])),
            ]).lower()
            if needle not in hay:
                continue
        result.append(feature)
    if len(_FILTER_FEATURES_CACHE) >= _FILTER_FEATURES_CACHE_MAX:
        _FILTER_FEATURES_CACHE.clear()
    _FILTER_FEATURES_CACHE[cache_key] = tuple(result)
    return list(result)


def count_by_category() -> dict[str, int]:
    global _COUNT_BY_CATEGORY_CACHE
    if _COUNT_BY_CATEGORY_CACHE is None:
        counts: dict[str, int] = {}
        for feature in FEATURES:
            cid = str(feature.get('category') or '')
            counts[cid] = counts.get(cid, 0) + 1
        _COUNT_BY_CATEGORY_CACHE = counts
    return dict(_COUNT_BY_CATEGORY_CACHE)


def count_by_domain() -> dict[str, int]:
    global _COUNT_BY_DOMAIN_CACHE
    if _COUNT_BY_DOMAIN_CACHE is None:
        counts: dict[str, int] = {}
        for feature in FEATURES:
            label = str(feature.get('design_domain') or feature.get('source_system') or '')
            counts[label] = counts.get(label, 0) + 1
        _COUNT_BY_DOMAIN_CACHE = counts
    return dict(_COUNT_BY_DOMAIN_CACHE)


def clear_runtime_caches() -> None:
    """Release all bounded query/UI caches at Manager suspend boundaries."""
    global _LANG_CACHE_KEY, _LANG_CACHE_VALUE
    global _COUNT_BY_CATEGORY_CACHE, _COUNT_BY_DOMAIN_CACHE
    _ENUM_ITEM_CACHE.clear()
    _FILTER_FEATURES_CACHE.clear()
    _LANG_CACHE_KEY = None
    _LANG_CACHE_VALUE = False
    _COUNT_BY_CATEGORY_CACHE = None
    _COUNT_BY_DOMAIN_CACHE = None


def coverage_summary() -> dict[str, Any]:
    return dict(INVENTORY.get('coverage') or DESIGN_COVERAGE or {})


def inventory_dict() -> dict[str, Any]:
    return dict(INVENTORY)
