"""Public procedural vocabulary, bilingual UI string selection and pack lookup."""
import json
from pathlib import Path
import bpy
ROOT=Path(__file__).resolve().parent
CATALOG=json.loads((ROOT/'catalogue.json').read_text('utf8'))
PUBLIC=json.loads((ROOT/'public_fields.json').read_text('utf8'))
FEATURES=CATALOG['features']
PACKS=CATALOG['packs']
FEATURE_BY_ID={f['id']:f for f in FEATURES}
PACK_BY_ID={p['id']:p for p in PACKS}
def is_japanese(context=None):return (context or bpy.context).preferences.view.language.startswith('ja')
def text(en,ja,context=None):return ja if is_japanese(context) else en
JA=json.loads((ROOT/'public_menu_ja.json').read_text('utf8'))
MENUS={lang:{name:[(ident,title,'',i) for i,(ident,title) in enumerate(items)] for name,items in table.items()} for lang,table in [('ja',JA),('en',PUBLIC['items'])]}
def labels(entries,context=None):return MENUS['ja' if is_japanese(context) else 'en'][entries]
def category_items(context=None):return labels('category_items')
def design_domain_items(context=None):return labels('design_domain_items')
def feature_items(context=None):return labels('feature_items')
def source_items(context=None):return labels('source_items')
def pack_items(context=None):return labels('pack_items')
def domain_id(feature):return feature.get('design_domain_id') or PUBLIC.get('domains',{}).get(feature['id'],'utility')
def feature_label(feature_id,context=None):return dict((JA if is_japanese(context) else PUBLIC['items'])['feature_items']).get(feature_id,feature_id)
def features_for_pack(pack_id):return [FEATURE_BY_ID[i] for i in PACK_BY_ID.get(pack_id,{}).get('feature_ids',[]) if i in FEATURE_BY_ID]
def filter_features(category='all',source='all',search='',context=None):
    return [f for f in FEATURES if category in ('all',f['category']) and source in ('all',domain_id(f)) and search.casefold() in (f['id']+' '+feature_label(f['id'])).casefold()]
