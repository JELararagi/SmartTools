# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Bounded status compatibility API with no Blender-global interception.

Earlier builds temporarily replaced ``bpy.app.timers``, ``bpy.utils``, msgbus,
Property callbacks, draw-handler methods, and handler lists.  This implementation
keeps the callable surface used by Smart Geometry while never monkeypatching a
process-global Blender API and never registering an idle monitor.
"""

from __future__ import annotations

from contextlib import contextmanager
import time
import uuid
from typing import Optional

_MAX_ENTRIES = 128
_DEFAULT_TRANSIENT_SECONDS = 2.5
_ENTRIES: dict[str, dict[str, object]] = {}


def _trim() -> None:
    now = time.monotonic()
    expired = [key for key, value in _ENTRIES.items() if float(value.get("expires", 0.0) or 0.0) and float(value["expires"]) <= now]
    for key in expired:
        _ENTRIES.pop(key, None)
    while len(_ENTRIES) > _MAX_ENTRIES:
        try:
            _ENTRIES.pop(next(iter(_ENTRIES)))
        except Exception:
            _ENTRIES.clear()
            break


def _put(key: str, owner: str, text: str, *, expires: float = 0.0, kind: str = "status") -> str:
    _trim()
    _ENTRIES[str(key)] = {
        "owner": str(owner),
        "text": str(text),
        "expires": float(expires),
        "kind": str(kind),
        "updated": time.monotonic(),
    }
    _trim()
    return str(key)


def set_transient(owner: str, text: str, duration: float = _DEFAULT_TRANSIENT_SECONDS, *, context=None):
    del context
    key = f"transient:{owner}"
    return _put(key, owner, text, expires=time.monotonic() + max(0.0, float(duration)), kind="transient")


def set_service(owner: str, text: str, *, context=None):
    del context
    return _put(f"service:{owner}", owner, text, kind="service")


def begin_task(owner: str, text: str, *, context=None):
    del context
    token = f"task:{owner}:{uuid.uuid4().hex}"
    return _put(token, owner, text, kind="task")


def update_task(token: str, text: str, *, context=None):
    del context
    current = _ENTRIES.get(str(token))
    owner = str(current.get("owner", token)) if isinstance(current, dict) else str(token)
    return _put(str(token), owner, text, kind="task")


def finish_task(token: str, final_text: Optional[str] = None, duration: float = 0.12, *, context=None):
    del context
    current = _ENTRIES.pop(str(token), None)
    if final_text:
        owner = str(current.get("owner", token)) if isinstance(current, dict) else str(token)
        return set_transient(owner, str(final_text), duration=float(duration))
    return None


def clear(owner_or_token: str, *, context=None):
    del context
    key = str(owner_or_token)
    _ENTRIES.pop(key, None)
    for candidate in tuple(_ENTRIES):
        value = _ENTRIES.get(candidate) or {}
        if str(value.get("owner") or "") == key:
            _ENTRIES.pop(candidate, None)


def clear_prefix(prefix: str, *, context=None):
    del context
    prefix = str(prefix)
    for key in tuple(_ENTRIES):
        value = _ENTRIES.get(key) or {}
        if key.startswith(prefix) or str(value.get("owner") or "").startswith(prefix):
            _ENTRIES.pop(key, None)


def clear_all(*, context=None):
    del context
    _ENTRIES.clear()


def snapshot():
    _trim()
    return tuple(dict(value, token=key) for key, value in _ENTRIES.items())


@contextmanager
def task_scope(owner: str, text: str, *, context=None, completed_text: Optional[str] = None, error_prefix: Optional[str] = None):
    token = begin_task(owner, text, context=context)
    try:
        yield token
    except Exception:
        finish_task(token, f"{error_prefix or text}: cancelled", context=context)
        raise
    else:
        finish_task(token, completed_text, context=context)


def _default_operator_description(cls, suite_label: str) -> str:
    del cls, suite_label
    return ""


def instrument_operator_class(cls, suite_id: str, suite_label: str):
    """Compatibility no-op that only fills a missing static tooltip.

    It does not wrap execute/invoke/modal/cancel, register_class, handlers, timers,
    draw APIs, properties, or msgbus.
    """
    del suite_id
    try:
        if isinstance(cls, type) and not str(getattr(cls, "bl_description", "") or "").strip():
            cls.bl_description = _default_operator_description(cls, suite_label)
    except Exception:
        pass
    return cls


def instrument_loaded_package_operators(package_marker: str, suite_id: str, suite_label: str):
    del package_marker, suite_id, suite_label
    return 0


@contextmanager
def capture_runtime_resources(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield


@contextmanager
def capture_registration_callbacks(suite_id: str, suite_label: str):
    del suite_id, suite_label
    yield



class _HandlerStatusProxy:
    """Compatibility callable retained without handler interception.

    Existing imports may construct this private helper.  It forwards directly to
    the original callback and never inserts itself into Blender handler lists.
    """

    def __init__(self, callback, owner: str = "", handler_name: str = "", suite_label: str = ""):
        self._callback = callback
        self._owner = str(owner)
        self._handler_name = str(handler_name)
        self._suite_label = str(suite_label)
        self.__name__ = getattr(callback, "__name__", "handler")
        self.__qualname__ = getattr(callback, "__qualname__", self.__name__)
        self.__doc__ = getattr(callback, "__doc__", None)
        self.__module__ = getattr(callback, "__module__", __name__)

    def __call__(self, *args, **kwargs):
        return self._callback(*args, **kwargs)

    def __eq__(self, other):
        return bool(other is self or other is self._callback or (isinstance(other, _HandlerStatusProxy) and other._callback is self._callback))

    def __hash__(self):
        return hash(self._callback)

    def __getattr__(self, name):
        return getattr(self._callback, name)

def prune_orphan_persistent_handler_markers(suite_id: Optional[str] = None):
    del suite_id
    return 0


def instrument_loaded_package_handlers(package_marker: str, suite_id: str, suite_label: str):
    del package_marker, suite_id, suite_label
    return 0


def restore_package_handlers(suite_id: str):
    del suite_id
    return 0
