# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

import importlib
from functools import wraps
import sys

import bpy
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper

from . import catalog
from .properties import get_settings


class _LazyModuleProxy:
    """Import a heavy implementation module only on the first explicit use."""

    __slots__ = ('_leaf', '_module')

    def __init__(self, leaf: str):
        self._leaf = str(leaf)
        self._module = None

    @property
    def full_name(self) -> str:
        return f'{__package__}.{self._leaf}'

    def load(self):
        module = self._module
        if module is None or sys.modules.get(self.full_name) is not module:
            module = importlib.import_module(self.full_name)
            self._module = module
            try:
                from . import ownership
                ledger = ownership.shared_ledger()
                if ledger is not None:
                    ownership.record_lazy_module(ledger, module)
            except Exception:
                pass
        return module

    def release(self) -> None:
        self._module = None

    def __getattr__(self, name):
        return getattr(self.load(), name)


diagnostics = _LazyModuleProxy('diagnostics')
icons = _LazyModuleProxy('icons')
mesh_tools = _LazyModuleProxy('mesh_tools')
node_factory = _LazyModuleProxy('node_factory')


def release_lazy_modules() -> None:
    for proxy in (diagnostics, icons, mesh_tools, node_factory):
        proxy.release()


class SGS_OT_create_node_library(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_node_library'
    bl_label = 'Create Node Group Library'
    bl_description = 'Create or refresh every Smart Geometry node capsule and pack controller as reusable Geometry Nodes node groups. This does not alter scene objects unless asset marking is enabled for the generated groups.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        names = node_factory.create_library(settings, force_rebuild=False)
        self.report({'INFO'}, catalog.text(f'Node groups created or refreshed: {len(names)}', f'ノードグループを作成または更新しました: {len(names)}'))
        return {'FINISHED'}


class SGS_OT_rebuild_node_library(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.rebuild_node_library'
    bl_label = 'Rebuild Node Group Library'
    bl_description = 'Force-rebuild every generated Smart Geometry node group and pack controller. Use this after updating the add-on or changing the capsule prefix.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        names = node_factory.create_library(settings, force_rebuild=True)
        self.report({'INFO'}, catalog.text(f'Node groups rebuilt: {len(names)}', f'ノードグループを再構築しました: {len(names)}'))
        return {'FINISHED'}


class SGS_OT_apply_feature(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.apply_feature'
    bl_label = 'Apply Active Feature'
    bl_description = 'Apply the active Smart Geometry feature capsule to selected mesh objects as a non-destructive Geometry Nodes modifier. If no explicit feature ID is provided, the panel selection is used.'
    bl_options = {'UNDO'}

    feature_id: StringProperty(
        name='Feature ID',
        description='Optional feature ID to apply. Leave empty to use the active feature selected in the Smart Geometry panel.',
        default='',
    )

    def execute(self, context):
        settings = get_settings(context)
        fid = str(self.feature_id or getattr(settings, 'active_feature', '') or '').strip()
        if fid not in catalog.FEATURE_BY_ID:
            self.report({'ERROR'}, catalog.text('Feature not found.', '機能が見つかりません。'))
            return {'CANCELLED'}
        applied = node_factory.apply_feature_to_selection(context, fid, settings)
        if not applied:
            self.report({'ERROR'}, catalog.text('No mesh objects are selected. Select one or more mesh objects first.', 'メッシュオブジェクトが選択されていません。先に1つ以上のメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Applied feature to {len(applied)} modifier slot(s).', f'{len(applied)}個のモディファイアスロットへ機能を適用しました。'))
        return {'FINISHED'}


class SGS_OT_apply_pack(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.apply_pack'
    bl_label = 'Apply Active Pack'
    bl_description = 'Apply every feature capsule in the selected workflow pack to selected mesh objects as a modifier stack. Use packs for core setup, environment generation, motion FX, architecture, or interop workflows.'
    bl_options = {'UNDO'}

    pack_id: StringProperty(
        name='Pack ID',
        description='Optional pack ID to apply. Leave empty to use the active pack selected in the Smart Geometry panel.',
        default='',
    )

    def execute(self, context):
        settings = get_settings(context)
        pid = str(self.pack_id or getattr(settings, 'active_pack', '') or '').strip()
        if pid not in catalog.PACK_BY_ID and pid != 'all':
            self.report({'ERROR'}, catalog.text('Pack not found.', 'パックが見つかりません。'))
            return {'CANCELLED'}
        applied = node_factory.apply_pack_to_selection(context, pid, settings)
        if not applied:
            self.report({'ERROR'}, catalog.text('No mesh objects are selected. Select one or more mesh objects first.', 'メッシュオブジェクトが選択されていません。先に1つ以上のメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Applied pack features to {len(applied)} modifier slot(s).', f'{len(applied)}個のモディファイアスロットへパックの機能を適用しました。'))
        return {'FINISHED'}


class SGS_OT_apply_full_independent_suite(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.apply_full_independent_suite'
    bl_label = 'Apply Full Independent Toolset'
    bl_description = 'Apply every independently named Smart Geometry capsule derived from the research requirements. This is a full coverage test and creates many modifiers.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        applied = node_factory.apply_pack_to_selection(context, 'independent_full_suite', settings)
        if not applied:
            self.report({'ERROR'}, catalog.text('No mesh objects are selected. Select one or more mesh objects first.', 'メッシュオブジェクトが選択されていません。先に1つ以上のメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Full independent suite modifiers applied: {len(applied)}', f'完全独自ツールセットのモディファイアを適用しました: {len(applied)}'))
        return {'FINISHED'}


class SGS_OT_add_standard_attributes(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.add_standard_attributes'
    bl_label = 'Build Precision Attributes'
    bl_description = 'Create and update the dense Smart Geometry attribute layer on the active mesh: ID, density, mask, variation, height, slope, curvature, convexity, boundary, edge distance, wetness, flow, erosion, sediment, biome, LOD, culling, ambient, and selection. Use this before distribution, habitat, visibility, material, or diagnostic workflows.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = node_factory.active_mesh_object(context)
        if obj is None:
            self.report({'ERROR'}, catalog.text('No active mesh object. Select a mesh object first.', 'アクティブなメッシュオブジェクトがありません。先にメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        attrs = mesh_tools.ensure_standard_attributes(obj)
        self.report({'INFO'}, catalog.text(f'Precision attributes written: {len(attrs)}', f'高精度属性を書き込みました: {len(attrs)}'))
        return {'FINISHED'}


class SGS_OT_refine_scene_precision(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.refine_scene_precision'
    bl_label = 'Refine Scene Precision'
    bl_description = 'Rebuild the hyper-precision attribute layer on the selected mesh objects, including topology, flow direction, channel, habitat, stability, cavity, occlusion, thickness, LOD, culling, region, and quality attributes. Use this after editing meshes or before distribution, material, diagnostic, or export workflows.'
    bl_options = {'UNDO'}

    def execute(self, context):
        count = mesh_tools.refine_scene_precision(context, get_settings(context))
        if count <= 0:
            self.report({'ERROR'}, catalog.text('No mesh objects were refined. Select one or more mesh objects first.', '再構築されたメッシュオブジェクトはありません。先に1つ以上のメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Precision layer refined on {count} mesh object(s).', f'{count}個のメッシュオブジェクトで精度レイヤーを再構築しました。'))
        return {'FINISHED'}


class SGS_OT_apply_selection_string(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.apply_selection_string'
    bl_label = 'Apply Precision Selection'
    bl_description = 'Parse the panel expression and write it to the sgs_selection attribute and SGS Selection vertex group on the active mesh. Supports index ranges, invert:, density/height/slope/curvature comparisons, attribute ranges, boundary/interior, highest()/lowest(), and and/or/except combinations.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        obj = node_factory.active_mesh_object(context)
        if obj is None:
            self.report({'ERROR'}, catalog.text('No active mesh object. Select a mesh object first.', 'アクティブなメッシュオブジェクトがありません。先にメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        selected = mesh_tools.apply_selection_string(obj, getattr(settings, 'selection_string', 'all'))
        self.report({'INFO'}, catalog.text(f'Precision selection updated: {selected} vertices selected.', f'高精度選択を更新しました: {selected}頂点を選択中です。'))
        return {'FINISHED'}


class SGS_OT_create_terrain(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_terrain'
    bl_label = 'Create Precision Terrain'
    bl_description = 'Generate an editable precision heightfield terrain mesh with deterministic multi-octave noise, thermal relaxation, flow accumulation, sediment, wetness, erosion, slope, convexity, habitat, density, and visibility attributes.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = mesh_tools.create_terrain(context, get_settings(context))
        if obj is None:
            self.report({'ERROR'}, catalog.text('Terrain creation failed.', '地形の作成に失敗しました。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Precision terrain created: {obj.name}', f'高精度地形を作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_create_scatter_points(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_scatter_points'
    bl_label = 'Create Precision Distribution Points'
    bl_description = 'Create a weighted surface point-cloud from the active mesh or a fallback grid. The generator uses face area, density, habitat, slope, blue-noise rejection, normal offsets, source-face IDs, normals, scale, variation, LOD, and culling attributes.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = mesh_tools.create_scatter_points(context, get_settings(context))
        if obj is None:
            self.report({'ERROR'}, catalog.text('Scatter point creation failed.', '散布ポイントの作成に失敗しました。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Precision distribution points created: {obj.name}', f'高精度分布ポイントを作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_relax_distribution_points(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.relax_distribution_points'
    bl_label = 'Relax Distribution Points'
    bl_description = 'Run the blue-noise and tangent relaxation pass on the active point-cloud mesh. This improves residual spacing after point import or surface distribution and writes sgs_relaxed and sgs_quality attributes.'
    bl_options = {'UNDO'}

    def execute(self, context):
        moved = mesh_tools.relax_distribution_points(context, get_settings(context))
        if moved <= 0:
            if node_factory.active_mesh_object(context) is None:
                self.report({'WARNING'}, catalog.text('No distribution points were relaxed. Select an active mesh point cloud first.', '分布ポイントを緩和できませんでした。先にアクティブなメッシュのポイントクラウドを選んでください。'))
                return {'CANCELLED'}
            # The relax pass already ran and wrote its attributes; nothing was closer than the spacing.
            self.report({'INFO'}, catalog.text('Distribution points are already evenly spaced. No point moved.', '分布ポイントの間隔はすでに揃っています。動いた点はありません。'))
            return {'FINISHED'}
        self.report({'INFO'}, catalog.text(f'Distribution points relaxed: {moved}', f'分布ポイントを緩和しました: {moved}'))
        return {'FINISHED'}


class SGS_OT_create_flow_network(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_flow_network'
    bl_label = 'Create Drainage Flow Network'
    bl_description = 'Create downhill flow curves from the active mesh using sgs_height, sgs_flow, and sgs_channel. Use this after terrain generation or precision attribute refinement to visualize erosion channels, wear paths, and water-flow guides.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = mesh_tools.create_flow_network_curves(context, get_settings(context))
        if obj is None:
            self.report({'ERROR'}, catalog.text('Drainage flow network creation failed. Select an active mesh that has height differences first.', '排水フローネットワークの作成に失敗しました。先に高低差のあるアクティブメッシュを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Drainage flow network created: {obj.name}', f'排水フローネットワークを作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_create_greeble_blocks(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_greeble_blocks'
    bl_label = 'Create Surface Detail Blocks'
    bl_description = 'Create a combined helper mesh of density-ranked, normal-aligned surface detail blocks from active mesh faces or a fallback grid. Use this for mechanical panels, facade articulation, kitbash previews, and material-breakup tests.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = mesh_tools.create_greeble_blocks(context, get_settings(context))
        if obj is None:
            self.report({'ERROR'}, catalog.text('Surface detail creation failed.', '表面ディテールの作成に失敗しました。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Surface detail helper created: {obj.name}', f'表面ディテール補助を作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_create_building_proxy(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_building_proxy'
    bl_label = 'Create Modular Structure'
    bl_description = 'Generate a tiered modular structure mesh with floor modules, facade protrusions, roof modules, module IDs, module kinds, and dense standard attributes. Use it for independent architecture and layout workflows.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = mesh_tools.create_building_proxy(context, get_settings(context))
        if obj is None:
            self.report({'ERROR'}, catalog.text('Building proxy creation failed.', '建築プロキシの作成に失敗しました。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Modular structure created: {obj.name}', f'モジュラー構造を作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_create_ivy_curve(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_ivy_curve'
    bl_label = 'Create Organic Growth Curves'
    bl_description = 'Create multi-branch organic growth curve helpers for ivy, roots, cables, veins, or trail-style guides around the active object. The curves are generated deterministically from the suite seed and can be converted or consumed by Geometry Nodes.'
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = mesh_tools.create_ivy_curve(context, get_settings(context))
        if obj is None:
            self.report({'ERROR'}, catalog.text('Organic growth curve creation failed.', '有機成長カーブの作成に失敗しました。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Organic growth curves created: {obj.name}', f'有機成長カーブを作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_explode_mesh_to_pieces(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.explode_mesh_to_pieces'
    bl_label = 'Create Clustered Fragments'
    bl_description = 'Create clustered fragment helper objects from active mesh faces and assign stable sgs_piece_id, variation, and fragment-mass attributes. This preserves multi-face clusters where possible for more usable separation previews.'
    bl_options = {'UNDO'}

    def execute(self, context):
        pieces = mesh_tools.explode_mesh_to_pieces(context, get_settings(context))
        if not pieces:
            self.report({'ERROR'}, catalog.text('No mesh pieces were created. Select an active mesh with faces first.', 'メッシュ破片は作成されませんでした。先に面を持つアクティブメッシュを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Fragments created: {len(pieces)}', f'破片を作成しました: {len(pieces)}'))
        return {'FINISHED'}


class SGS_OT_import_csv_points(bpy.types.Operator, ImportHelper):
    bl_idname = 'smart_geometry_suite.import_csv_points'
    bl_label = 'Import CSV Points'
    bl_description = 'Read a CSV file and create a point-cloud mesh from x, y, and z columns. Optional id, scale, density, and numeric custom columns are preserved as neutral named attributes for point-distribution and open-data exchange.'
    bl_options = {'UNDO'}
    filename_ext = '.csv'
    filter_glob: StringProperty(
        name='CSV File Filter',
        description='Limits the Blender file browser to CSV files containing point coordinates and optional attribute columns.',
        default='*.csv',
        options={'HIDDEN'},
    )

    def execute(self, context):
        settings = get_settings(context)
        path = self.filepath or getattr(settings, 'csv_path', '')
        obj = mesh_tools.import_csv_points(path, context)
        if obj is None:
            self.report({'ERROR'}, catalog.text('CSV import failed. The file must exist and contain x, y, and z columns.', 'CSV読み込みに失敗しました。ファイルが存在し、x、y、z列を含む必要があります。'))
            return {'CANCELLED'}
        try:
            settings.csv_path = path
        except Exception:
            pass
        self.report({'INFO'}, catalog.text(f'CSV point cloud created: {obj.name}', f'CSVポイントクラウドを作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_create_demo_scene(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_demo_scene'
    bl_label = 'Create Demo Scene'
    bl_description = 'Create a compact Smart Geometry demonstration: terrain, standard attributes, environment modifiers, scatter points, greeble blocks, ivy/root curve, building proxy, and reports-ready metadata.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        created = []
        terrain = mesh_tools.create_terrain(context, settings)
        if terrain:
            created.append(terrain.name)
            node_factory.apply_pack_to_selection(context, 'terrain_habitat_pack', settings)
        scatter = mesh_tools.create_scatter_points(context, settings)
        if scatter:
            created.append(scatter.name)
        greeble = mesh_tools.create_greeble_blocks(context, settings)
        if greeble:
            created.append(greeble.name)
        ivy = mesh_tools.create_ivy_curve(context, settings)
        if ivy:
            created.append(ivy.name)
        building = mesh_tools.create_building_proxy(context, settings)
        if building:
            created.append(building.name)
        self.report({'INFO'}, catalog.text(f'Demo scene helpers created: {len(created)}', f'デモシーン補助を作成しました: {len(created)}'))
        return {'FINISHED'}


class SGS_OT_create_attribute_heatmap(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_attribute_heatmap'
    bl_label = 'Create Attribute Heatmap'
    bl_description = 'Create or refresh a normalized debug color attribute on the active mesh from the selected SGS attribute. This helps inspect density, slope, flow, roughness, channels, selection, or any numeric attribute directly in the scene.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        obj = node_factory.active_mesh_object(context)
        if obj is None:
            self.report({'ERROR'}, catalog.text('No active mesh object. Select a mesh object first.', 'アクティブなメッシュオブジェクトがありません。先にメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        attr = getattr(settings, 'debug_attribute', 'sgs_density') if settings else 'sgs_density'
        if not mesh_tools.write_attribute_heatmap(obj, attr):
            self.report({'ERROR'}, catalog.text('Heatmap creation failed. The active object must be a mesh with readable attributes.', 'ヒートマップの作成に失敗しました。アクティブオブジェクトは読み取り可能な属性を持つメッシュである必要があります。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Attribute heatmap refreshed: {attr}', f'属性ヒートマップを更新しました: {attr}'))
        return {'FINISHED'}


class SGS_OT_create_attribute_snapshot(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_attribute_snapshot'
    bl_label = 'Create Attribute Snapshot'
    bl_description = 'Duplicate the active mesh data into a frozen inspection object, preserve SGS attributes, and apply a debug heatmap. Use this before destructive tests or after generating terrain, scatter, or fragments.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        obj = mesh_tools.create_attribute_snapshot(context, settings)
        if obj is None:
            self.report({'ERROR'}, catalog.text('Snapshot creation failed. Select a mesh object that has the debug attribute first.', 'スナップショットの作成に失敗しました。先にデバッグ属性を持つメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Attribute snapshot created: {obj.name}', f'属性スナップショットを作成しました: {obj.name}'))
        return {'FINISHED'}


class SGS_OT_create_distribution_proxy_instances(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.create_distribution_proxy_instances'
    bl_label = 'Create Distribution Proxy Instances'
    bl_description = 'Convert active distribution points into lightweight visible proxy pyramids with density and biome attributes. This provides an immediate quality check for spacing, scale, LOD, and habitat distribution before final instancing.'
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = get_settings(context)
        obj = mesh_tools.create_distribution_proxy_instances(context, settings)
        if obj is None:
            self.report({'ERROR'}, catalog.text('Proxy instance creation failed. Select a point mesh or a source mesh first.', 'プロキシインスタンスの作成に失敗しました。先にポイントメッシュまたはソースメッシュを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Distribution proxy instances created: {obj.name}', f'分布プロキシインスタンスを作成しました: {obj.name}'))
        return {'FINISHED'}




class SGS_OT_polish_precision_overdrive(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.polish_precision_overdrive'
    bl_label = 'Run Precision Polish'
    bl_description = 'Run the operation-grade precision polish on selected mesh objects. It rebuilds dense SGS attributes and adds smoothed density, curvature coherence, contact score, material region, distribution priority, remesh intent, stability rank, and quality grade fields.'
    bl_options = {'UNDO'}

    def execute(self, context):
        count = mesh_tools.polish_precision_overdrive(context, get_settings(context))
        if count <= 0:
            self.report({'ERROR'}, catalog.text('No mesh objects were polished. Select one or more mesh objects first.', '磨き込まれたメッシュオブジェクトはありません。先に1つ以上のメッシュオブジェクトを選択してください。'))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Precision polish completed on {count} mesh object(s).', f'{count}個のメッシュオブジェクトで精度ポリッシュが完了しました。'))
        return {'FINISHED'}


class SGS_OT_export_icon_reference_sheet(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.export_icon_reference_sheet'
    bl_label = 'Export Icon Reference Sheet'
    bl_description = 'Copy the bundled icon reference sheet to CONFIG/Smart_Geometry_Suite. The icons are suite-owned borderless high-fill images for readable large action buttons.'
    bl_options = set()

    def execute(self, context):
        try:
            from . import icons
            path = icons.export_reference_sheet()
        except Exception as exc:
            self.report({'ERROR'}, catalog.failure_text('Icon reference export failed', 'アイコンリファレンスの書き出しに失敗しました', exc))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Icon reference sheet written: {path}', f'アイコンリファレンスシートを書き出しました: {path}'))
        return {'FINISHED'}


class SGS_OT_reload_custom_icons(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.reload_custom_icons'
    bl_label = 'Reload Custom Icons'
    bl_description = 'Validate bundled icon files. In Blender 5.1 crash-safe mode, live custom preview icon IDs are disabled and the UI uses Blender standard icons.'
    bl_options = set()

    def execute(self, context):
        try:
            from . import icons, properties
            bundled = len(icons.bundled_icon_filenames(include_reference_images=False))
            try:
                properties.save_settings(context, force=True)
            except Exception:
                pass
            self.report({'INFO'}, catalog.text(f'Bundled icon files validated: {bundled}. Live custom preview icon IDs remain disabled at runtime for Blender 5.1 crash safety.', f'同梱アイコンファイルを検証しました: {bundled}。Blender 5.1のクラッシュ安全性のため、ライブカスタムプレビューアイコンIDは実行時も無効のままです。'))
        except Exception as exc:
            self.report({'ERROR'}, catalog.failure_text('Icon validation failed', 'アイコン検証に失敗しました', exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class SGS_OT_apply_precision_preset(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.apply_precision_preset'
    bl_label = 'Apply Precision Preset'
    bl_description = 'Apply tuned Smart Geometry defaults for fast preview, balanced production, or extreme local quality. This changes only panel settings; it does not generate or delete scene data.'
    bl_options = set()

    preset_id: StringProperty(
        name='Preset ID',
        description='Precision preset to apply: preview, production, or extreme. Leave empty to use the preset selected in the panel.',
        default='',
    )

    def execute(self, context):
        settings = get_settings(context)
        if settings is None:
            self.report({'ERROR'}, catalog.text('Smart Geometry settings are not available.', 'Smart Geometry設定を利用できません。'))
            return {'CANCELLED'}
        preset = str(self.preset_id or getattr(settings, 'precision_preset', 'production') or 'production').lower()
        if preset == 'preview':
            values = dict(
                terrain_resolution=48, terrain_erosion_iterations=4, terrain_hydraulic_droplets=512,
                terrain_hydraulic_iterations=6, terrain_v7_channel_count=8, scatter_count=256,
                scatter_quality_passes=2, scatter_candidate_multiplier=5, scatter_relax_iterations=1,
                scatter_v7_lloyd_iterations=1, diagnostic_sample_limit=512, ui_icon_scale=1.0, ui_v8_tile_scale=6.0, precision_v8_quality_passes=1,
            )
        elif preset == 'extreme':
            values = dict(
                terrain_resolution=192, terrain_erosion_iterations=28, terrain_hydraulic_droplets=32768,
                terrain_hydraulic_iterations=36, terrain_v7_channel_count=64, scatter_count=4000,
                scatter_quality_passes=10, scatter_candidate_multiplier=32, scatter_relax_iterations=5,
                scatter_v7_lloyd_iterations=5, diagnostic_sample_limit=8192, ui_icon_scale=1.0, ui_v8_tile_scale=12.0, precision_v8_quality_passes=6, precision_v8_strength=1.35,
            )
        else:
            preset = 'production'
            values = dict(
                terrain_resolution=128, terrain_erosion_iterations=14, terrain_hydraulic_droplets=8192,
                terrain_hydraulic_iterations=20, terrain_v7_channel_count=28, scatter_count=1500,
                scatter_quality_passes=6, scatter_candidate_multiplier=16, scatter_relax_iterations=3,
                scatter_v7_lloyd_iterations=3, diagnostic_sample_limit=4096, ui_icon_scale=1.0, ui_v8_tile_scale=9.0, precision_v8_quality_passes=3, precision_v8_strength=0.88,
            )
        try:
            settings.precision_preset = preset
        except Exception:
            pass
        for name, value in values.items():
            try:
                setattr(settings, name, value)
            except Exception:
                pass
        self.report({'INFO'}, catalog.text(f'Precision preset applied: {preset}', f'精度プリセットを適用しました: {preset}'))
        return {'FINISHED'}


class SGS_OT_run_visual_workflow(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.run_visual_workflow'
    bl_label = 'Run Visual Workflow'
    bl_description = 'Run a polished icon-driven workflow: scene refinement, environment generation, surface design, fragmentation, or diagnostics. The workflow uses independent Smart Geometry algorithms and writes SGS metadata.'
    bl_options = {'UNDO'}

    workflow_id: StringProperty(
        name='Workflow ID',
        description='Workflow to run: refine, environment, surface, fragment, diagnose, or full_demo.',
        default='refine',
    )

    def execute(self, context):
        settings = get_settings(context)
        workflow = str(self.workflow_id or 'refine').lower()
        created = []
        refined = 0
        try:
            if workflow in {'refine', 'diagnose', 'surface', 'fragment'}:
                refined = mesh_tools.refine_scene_precision(context, settings)
            if workflow == 'environment':
                terrain = mesh_tools.create_terrain(context, settings)
                if terrain:
                    created.append(terrain.name)
                scatter = mesh_tools.create_scatter_points(context, settings)
                if scatter:
                    created.append(scatter.name)
                flow = mesh_tools.create_flow_network_curves(context, settings)
                if flow:
                    created.append(flow.name)
                obj = node_factory.active_mesh_object(context)
                if obj:
                    mesh_tools.write_attribute_heatmap(obj, getattr(settings, 'debug_attribute', 'sgs_density'))
            elif workflow == 'surface':
                scatter = mesh_tools.create_scatter_points(context, settings)
                if scatter:
                    created.append(scatter.name)
                greeble = mesh_tools.create_greeble_blocks(context, settings)
                if greeble:
                    created.append(greeble.name)
                proxy = mesh_tools.create_distribution_proxy_instances(context, settings)
                if proxy:
                    created.append(proxy.name)
            elif workflow == 'fragment':
                pieces = mesh_tools.explode_mesh_to_pieces(context, settings)
                created.extend([getattr(obj, 'name', 'Fragment') for obj in pieces or []])
            elif workflow == 'diagnose':
                obj = node_factory.active_mesh_object(context)
                if obj:
                    mesh_tools.write_attribute_heatmap(obj, getattr(settings, 'debug_attribute', 'sgs_density'))
                    snap = mesh_tools.create_attribute_snapshot(context, settings)
                    if snap:
                        created.append(snap.name)
                diagnostics.write_diagnostics(context)
            elif workflow == 'full_demo':
                terrain = mesh_tools.create_terrain(context, settings); created += [terrain.name] if terrain else []
                scatter = mesh_tools.create_scatter_points(context, settings); created += [scatter.name] if scatter else []
                flow = mesh_tools.create_flow_network_curves(context, settings); created += [flow.name] if flow else []
                greeble = mesh_tools.create_greeble_blocks(context, settings); created += [greeble.name] if greeble else []
                ivy = mesh_tools.create_ivy_curve(context, settings); created += [ivy.name] if ivy else []
                building = mesh_tools.create_building_proxy(context, settings); created += [building.name] if building else []
                diagnostics.write_diagnostics(context)
                try:
                    mesh_tools.polish_precision_overdrive(context, settings)
                except Exception:
                    pass
            else:
                refined = mesh_tools.refine_scene_precision(context, settings)
        except Exception as exc:
            self.report({'ERROR'}, catalog.failure_text('Visual workflow failed', 'ビジュアルワークフローに失敗しました', exc))
            return {'CANCELLED'}
        self.report({'INFO'}, catalog.text(f'Visual workflow finished: {workflow}, refined={refined}, created={len(created)}', f'ビジュアルワークフローが完了しました: {workflow}、再構築={refined}、作成={len(created)}'))
        return {'FINISHED'}


class SGS_OT_export_inventory(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.export_inventory'
    bl_label = 'Export Inventory JSON'
    bl_description = 'Write the complete Smart Geometry feature inventory to the CONFIG/Smart_Geometry_Suite reports folder. Use this to audit every independent feature capsule, native workflow, category, pack, and tooltip.'
    bl_options = set()

    def execute(self, context):
        path = diagnostics.write_inventory()
        self.report({'INFO'}, catalog.text(f'Inventory written: {path}', f'インベントリを書き出しました: {path}'))
        return {'FINISHED'}


class SGS_OT_export_design_coverage(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.export_design_coverage'
    bl_label = 'Export Design Coverage JSON'
    bl_description = 'Write the independent design coverage matrix extracted from the uploaded research document. This verifies that every listed requirement is represented by a uniquely named suite capsule.'
    bl_options = set()

    def execute(self, context):
        path = diagnostics.write_design_coverage()
        self.report({'INFO'}, catalog.text(f'Design coverage written: {path}', f'設計カバーを書き出しました: {path}'))
        return {'FINISHED'}


class SGS_OT_export_diagnostics(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.export_diagnostics'
    bl_label = 'Export Diagnostics JSON'
    bl_description = 'Write scene diagnostics including generated objects, mesh attributes, modifiers, node groups, and heat-map approximation scores to the CONFIG/Smart_Geometry_Suite reports folder.'
    bl_options = set()

    def execute(self, context):
        path = diagnostics.write_diagnostics(context)
        self.report({'INFO'}, catalog.text(f'Diagnostics written: {path}', f'診断を書き出しました: {path}'))
        return {'FINISHED'}


class SGS_OT_export_usd_manifest(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.export_usd_manifest'
    bl_label = 'Export USD Sidecar Manifest'
    bl_description = 'Write a USD-oriented JSON sidecar manifest describing suggested primvars, Smart Geometry attributes, generated node groups, and neutral open-data metadata. This does not write a native USD stage.'
    bl_options = set()

    def execute(self, context):
        path = diagnostics.write_usd_manifest(context)
        self.report({'INFO'}, catalog.text(f'USD sidecar manifest written: {path}', f'USDサイドカーマニフェストを書き出しました: {path}'))
        return {'FINISHED'}


class SGS_OT_export_bundle_manifest(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.export_bundle_manifest'
    bl_label = 'Export Toolset Bundle Manifest'
    bl_description = 'Write a neutral JSON manifest describing generated node groups, feature packs, design coverage, objects, attributes, and diagnostics for sharing or auditing suite-generated data.'
    bl_options = set()

    def execute(self, context):
        path = diagnostics.write_bundle_manifest(context)
        self.report({'INFO'}, catalog.text(f'Toolset bundle manifest written: {path}', f'ツールセットバンドルマニフェストを書き出しました: {path}'))
        return {'FINISHED'}


class SGS_OT_remove_generated_node_groups(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.remove_generated_node_groups'
    bl_label = 'Remove Generated Node Groups'
    bl_description = 'Remove node groups generated by Smart Geometry. This does not delete scene objects, meshes, or user-authored node groups that are not stamped with the suite marker.'
    bl_options = {'UNDO'}

    def execute(self, context):
        count = node_factory.remove_generated_node_groups()
        self.report({'INFO'}, catalog.text(f'Generated node groups removed: {count}', f'生成済みノードグループを削除しました: {count}'))
        return {'FINISHED'}


class SGS_OT_open_visual_reference(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.open_visual_reference'
    bl_label = 'Open Visual Reference'
    bl_description = 'Open the visual reference popup. It displays generated borderless custom icons and icon-only workflow diagrams so the command deck can be understood without copying another product UI.'
    bl_options = set()

    def invoke(self, context, event):
        try:
            return context.window_manager.invoke_props_dialog(self, width=880)
        except Exception:
            return self.execute(context)

    def draw(self, context):
        layout = self.layout
        settings = get_settings(context)
        scale = float(getattr(settings, 'ui_icon_scale', 5.6) if settings else 5.6)
        for icon_row in [
            [('logo', 'Suite', 'スイート'), ('dashboard', 'Deck', 'デッキ'), ('precision', 'Precision', '精度'), ('overdrive', 'Overdrive', '強化')],
            [('terrain', 'Terrain', '地形'), ('scatter', 'Scatter', '散布'), ('relax', 'Relax', '緩和'), ('flow', 'Flow', '流れ')],
            [('greeble', 'Surface', '表面'), ('fragment', 'Fragment', '破片'), ('heatmap', 'Heatmap', 'ヒートマップ'), ('attribute', 'Attribute', '属性')],
            [('selection', 'Selection', '選択'), ('material', 'Material/UV', 'マテリアル/UV'), ('manifest', 'Manifest', 'マニフェスト'), ('quality', 'Quality', '品質')],
            [('diagnostics', 'Diagnose', '診断'), ('snapshot', 'Snapshot', 'スナップショット'), ('csv', 'CSV', 'CSV'), ('structure', 'Structure', '構造')],
            [('growth', 'Growth', '成長'), ('volume', 'Volume', 'ボリューム'), ('motion', 'Motion', 'モーション'), ('automation', 'Automation', '自動化')],
            [('capsule', 'Capsule', 'カプセル'), ('utility', 'Utility', 'ユーティリティ')],
        ]:
            row = layout.row(align=True)
            for name, label_en, label_ja in icon_row:
                col = row.column(align=True)
                icons.draw_preview(col, name, scale=max(4.0, min(10.0, scale)), fallback_icon='IMAGE_DATA')
                col.label(text=catalog.text(label_en, label_ja, context))
        layout.separator()
        for ref_name, en, ja in [
            ('command_deck_reference', 'Command deck image contains only icon diagrams; localized text is drawn by Blender UI.', 'コマンドデッキ画像はアイコン図のみで、文字はBlender UI側でローカライズします。'),
            ('workflow_reference', 'Workflow image uses large borderless shapes to show the operation flow.', 'ワークフロー画像は大きな枠無し図形で操作の流れを示します。'),
            ('attribute_stack_reference', 'Attribute image shows layered field fusion without embedded two-language text.', '属性画像は、二言語併記の埋め込み文字なしでフィールド融合を示します。'),
            ('precision_pipeline_reference', 'Precision pipeline image shows terrain, flow, distribution, quality, and diagnostics as a single visual stack.', '精度パイプライン画像は、地形、流れ、分布、品質、診断を一つの視覚スタックとして示します。'),
        ]:
            box = layout.box()
            icons.draw_preview(box, ref_name, scale=max(5.0, min(11.0, scale)), fallback_icon='IMAGE_DATA')
            box.label(text=catalog.text(en, ja, context))

    def execute(self, context):
        return {'FINISHED'}


class SGS_OT_open_help(bpy.types.Operator):
    bl_idname = 'smart_geometry_suite.open_help'
    bl_label = 'Open Help'
    bl_description = 'Open the lazy-loaded detailed help popup for the selected Smart Geometry tool group or feature. The heavy help text is imported only after this button is clicked.'
    bl_options = set()

    help_key: StringProperty(
        name='Help Key',
        description='Internal help topic key. Leave empty to open the active feature help or the suite overview.',
        default='',
        options={'SKIP_SAVE'},
    )
    topic: StringProperty(
        name='Help Topic',
        description='Public help topic alias used by N-panel Help icon buttons. It is mapped to the lazy help catalog only when clicked.',
        default='',
        options={'SKIP_SAVE'},
    )
    feature_id: StringProperty(
        name='Feature ID',
        description='Optional feature ID for feature-specific help. Leave empty to use the active feature selected in the panel.',
        default='',
        options={'SKIP_SAVE'},
    )

    @classmethod
    def description(cls, context, properties):
        try:
            return catalog.text(
                'Open detailed help. The manual text is lazy-loaded only after clicking this Help icon.',
                '詳細ヘルプを開きます。マニュアル本文はこのヘルプアイコンをクリックした後だけ遅延読み込みされます。',
                context,
            )
        except Exception:
            return 'Open detailed help.'

    def _resolve_topic(self, context):
        settings = get_settings(context)
        key = str(getattr(self, 'help_key', '') or getattr(self, 'topic', '') or '').strip()
        fid = str(getattr(self, 'feature_id', '') or '').strip()
        if not fid and key in {'', 'feature'} and settings is not None:
            fid = str(getattr(settings, 'active_feature', '') or '')
        aliases = {
            'root': 'suite_overview',
            'dashboard': 'visual_dashboard',
            'workflow_polish': 'workflow_v8_polish',
            'catalog': 'feature_catalog',
            'builders': 'procedural_builders',
            'coverage': 'design_coverage',
        }
        key = aliases.get(key, key)
        if not key:
            key = 'feature' if fid else 'suite_overview'
        return key, fid

    def invoke(self, context, event):
        return self.execute(context)

    def execute(self, context):
        key, fid = self._resolve_topic(context)
        try:
            from . import lazy_help
            if lazy_help.show_help(context, key, fid):
                return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, catalog.failure_text('Help popup failed', 'ヘルプポップアップの表示に失敗しました', exc))
            return {'CANCELLED'}
        self.report({'ERROR'}, catalog.text('Help popup failed.', 'ヘルプポップアップの表示に失敗しました。'))
        return {'CANCELLED'}




# Blender 5.1 UI-handler crash safety: operators that create, modify, or inspect
# scene data from the command deck are callable only in Object Mode. This keeps
# mode-switch redraws from invoking mesh/node operations while Blender is between
# sculpt, edit, and object state transitions.
def _object_mode_poll(cls, context):
    del cls
    try:
        from . import ownership
        mode = str(getattr(context, 'mode', '') or '')
        return bool(
            ownership.runtime_active_for_generation()
            and mode in {'', 'OBJECT'}
            and getattr(context, 'window_manager', None) is not None
        )
    except Exception:
        return False


def _distribution_point_cloud_poll(cls, context):
    if not _object_mode_poll(cls, context):
        return False
    try:
        obj = context.active_object
        mesh = obj.data if obj is not None and obj.type == 'MESH' else None
        return bool(
            mesh is not None
            and len(mesh.vertices) > 1
            and len(mesh.polygons) == 0
        )
    except Exception:
        return False


_OBJECT_MODE_OPERATOR_CLASSES = (
    SGS_OT_create_node_library,
    SGS_OT_rebuild_node_library,
    SGS_OT_apply_feature,
    SGS_OT_apply_pack,
    SGS_OT_apply_full_independent_suite,
    SGS_OT_add_standard_attributes,
    SGS_OT_polish_precision_overdrive,
    SGS_OT_refine_scene_precision,
    SGS_OT_apply_selection_string,
    SGS_OT_create_terrain,
    SGS_OT_create_scatter_points,
    SGS_OT_relax_distribution_points,
    SGS_OT_create_flow_network,
    SGS_OT_create_greeble_blocks,
    SGS_OT_create_building_proxy,
    SGS_OT_create_ivy_curve,
    SGS_OT_explode_mesh_to_pieces,
    SGS_OT_import_csv_points,
    SGS_OT_create_demo_scene,
    SGS_OT_create_attribute_heatmap,
    SGS_OT_create_attribute_snapshot,
    SGS_OT_create_distribution_proxy_instances,
    SGS_OT_apply_precision_preset,
    SGS_OT_run_visual_workflow,
    SGS_OT_remove_generated_node_groups,
)

_OBJECT_MODE_FILE_OPERATOR_CLASSES = ()

for _sgs_operator_class in _OBJECT_MODE_OPERATOR_CLASSES:
    try:
        poll_function = (
            _distribution_point_cloud_poll
            if _sgs_operator_class is SGS_OT_relax_distribution_points
            else _object_mode_poll
        )
        _sgs_operator_class.poll = classmethod(poll_function)
    except Exception:
        pass

del _sgs_operator_class

CLASSES = (
    SGS_OT_create_node_library,
    SGS_OT_rebuild_node_library,
    SGS_OT_apply_feature,
    SGS_OT_apply_pack,
    SGS_OT_apply_full_independent_suite,
    SGS_OT_add_standard_attributes,
    SGS_OT_polish_precision_overdrive,
    SGS_OT_refine_scene_precision,
    SGS_OT_apply_selection_string,
    SGS_OT_create_terrain,
    SGS_OT_create_scatter_points,
    SGS_OT_relax_distribution_points,
    SGS_OT_create_flow_network,
    SGS_OT_create_greeble_blocks,
    SGS_OT_create_building_proxy,
    SGS_OT_create_ivy_curve,
    SGS_OT_explode_mesh_to_pieces,
    SGS_OT_import_csv_points,
    SGS_OT_create_demo_scene,
    SGS_OT_create_attribute_heatmap,
    SGS_OT_create_attribute_snapshot,
    SGS_OT_create_distribution_proxy_instances,
    SGS_OT_export_icon_reference_sheet,
    SGS_OT_reload_custom_icons,
    SGS_OT_apply_precision_preset,
    SGS_OT_run_visual_workflow,
    SGS_OT_export_inventory,
    SGS_OT_export_design_coverage,
    SGS_OT_export_diagnostics,
    SGS_OT_export_usd_manifest,
    SGS_OT_export_bundle_manifest,
    SGS_OT_remove_generated_node_groups,
    SGS_OT_open_visual_reference,
    SGS_OT_open_help,
)


def _make_execute_boundary(original):
    """Return a Blender-RNA-compatible ``execute(self, context)`` wrapper.

    Blender validates the concrete Python code object during class registration.
    Closure values therefore live in this factory instead of a hidden default
    parameter on the registered method; the returned function has exactly two
    positional parameters and no ``*args``/``**kwargs``.
    """

    @wraps(original)
    def guarded(self, context):
        try:
            from . import ownership
            if not ownership.runtime_active_for_generation():
                return {'CANCELLED'}
            result = original(self, context)
            if not isinstance(result, set) or not result:
                return {'CANCELLED'}
            return result
        except Exception as exc:
            try:
                self.report({'ERROR'}, catalog.failure_text('Smart Geometry command cancelled safely', 'Smart Geometryコマンドを安全に中止しました', exc))
            except Exception:
                pass
            return {'CANCELLED'}

    guarded._jelararagi_sgs_guarded = True
    return guarded


def _install_operator_boundaries() -> None:
    """Guard this generation's own command boundaries without global patching."""
    for cls in CLASSES:
        original = vars(cls).get('execute')
        if not callable(original) or bool(getattr(original, '_jelararagi_sgs_guarded', False)):
            continue
        setattr(cls, 'execute', _make_execute_boundary(original))


_install_operator_boundaries()
