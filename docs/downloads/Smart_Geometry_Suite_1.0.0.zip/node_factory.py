# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import re
from typing import Any, Iterable

import bpy

from . import catalog, ownership, transform_guard

GENERATED_FLAG = 'smart_geometry_suite_generated'
SUITE_VERSION = '8.2.46'
OWNER_SUITE_KEY = 'jelararagi_sgs_owner_suite'
OWNER_REVISION_KEY = 'jelararagi_sgs_owner_revision'
OWNER_GENERATION_KEY = 'jelararagi_sgs_owner_generation'
OWNER_SUITE_VALUE = ownership.SUITE_ID


def _ledger_generation() -> str:
    ledger = ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return ''
    return str(ledger.get('generation') or '')


def mark_owned(value) -> bool:
    """Tag one Suite-created datablock/resource with the exact live generation."""
    generation = _ledger_generation()
    if value is None or not generation:
        return False
    try:
        value[GENERATED_FLAG] = True
        value[OWNER_SUITE_KEY] = OWNER_SUITE_VALUE
        value[OWNER_REVISION_KEY] = ownership.REVISION
        value[OWNER_GENERATION_KEY] = generation
        return True
    except Exception:
        return False


def is_owned(value, *, generation: str | None = None) -> bool:
    """Return True only for an exact Suite/revision/generation ownership tag."""
    if value is None:
        return False
    expected = str(generation or _ledger_generation())
    if not expected:
        return False
    try:
        return bool(
            value.get(OWNER_SUITE_KEY) == OWNER_SUITE_VALUE
            and value.get(OWNER_REVISION_KEY) == ownership.REVISION
            and value.get(OWNER_GENERATION_KEY) == expected
        )
    except Exception:
        return False


def mark_created_object(obj) -> bool:
    """Tag a newly created object and its owned data as one transaction unit."""
    ok = mark_owned(obj)
    data = getattr(obj, 'data', None) if obj is not None else None
    if data is not None:
        ok = mark_owned(data) and ok
    return ok


def safe_name(value: str, *, max_len: int = 64) -> str:
    text = re.sub(r'[^A-Za-z0-9_]+', '_', str(value or '').strip())
    text = re.sub(r'_+', '_', text).strip('_')
    return (text or 'capsule')[:max_len]


def prefix(settings=None) -> str:
    try:
        value = str(getattr(settings, 'capsule_prefix', '') or '').strip()
    except Exception:
        value = ''
    return safe_name(value or 'SGS', max_len=20)


def feature_group_name(feature: dict[str, Any], settings=None) -> str:
    return f'{prefix(settings)}_{safe_name(catalog.localized(feature, "label"), max_len=42)}_{safe_name(str(feature.get("id")), max_len=48)}'


def pack_group_name(pack: dict[str, Any], settings=None) -> str:
    return f'{prefix(settings)}_PACK_{safe_name(catalog.localized(pack, "label"), max_len=42)}_{safe_name(str(pack.get("id")), max_len=32)}'


def _safe_remove_node_group(group) -> None:
    try:
        bpy.data.node_groups.remove(group)
    except Exception:
        pass


def _new_interface_socket(group, name: str, socket_type: str, in_out: str):
    try:
        socket = group.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
        return socket
    except Exception:
        pass
    try:
        sockets = group.inputs if in_out == 'INPUT' else group.outputs
        if name in sockets:
            return sockets[name]
        return sockets.new(socket_type, name)
    except Exception:
        return None


def _clear_interface(group) -> None:
    try:
        for item in list(group.interface.items_tree):
            try:
                group.interface.remove(item)
            except Exception:
                pass
        return
    except Exception:
        pass
    for collection_name in ('inputs', 'outputs'):
        try:
            collection = getattr(group, collection_name)
            for socket in list(collection):
                collection.remove(socket)
        except Exception:
            pass


def _clear_nodes(group) -> None:
    try:
        group.nodes.clear()
    except Exception:
        for node in list(getattr(group, 'nodes', []) or []):
            try:
                group.nodes.remove(node)
            except Exception:
                pass


def _socket_by_name(sockets, *names: str):
    wanted = {str(n) for n in names if n}
    try:
        for socket in sockets:
            if str(getattr(socket, 'name', '')) in wanted:
                return socket
    except Exception:
        pass
    try:
        return sockets[0]
    except Exception:
        return None


def _try_link(group, out_socket, in_socket) -> bool:
    if out_socket is None or in_socket is None:
        return False
    try:
        group.links.new(out_socket, in_socket)
        return True
    except Exception:
        return False


def _new_node(group, node_id: str, *, label: str = '', location=(0, 0)):
    try:
        node = group.nodes.new(node_id)
        node.location = location
        if label:
            node.label = label
        return node
    except Exception:
        return None


def _set_socket_default(socket, value) -> None:
    try:
        socket.default_value = value
    except Exception:
        pass


def _create_frame(group, label: str, body: str, *, location=(-320, 240), width=760) -> None:
    frame = _new_node(group, 'NodeFrame', label=label[:200], location=location)
    if frame is None:
        return
    try:
        frame.width = width
        frame.height = 260
    except Exception:
        pass
    # A nested frame label acts as a visible note while staying Blender-version safe.
    chunks = [body[i:i + 180] for i in range(0, min(len(body), 720), 180)] or ['']
    y = 140
    for chunk in chunks[:4]:
        note = _new_node(group, 'NodeFrame', label=chunk, location=(location[0] + 20, y))
        if note is not None:
            try:
                note.parent = frame
                note.width = width - 40
                note.height = 48
            except Exception:
                pass
        y -= 58


def _build_group_interface(group) -> None:
    _clear_interface(group)
    _new_interface_socket(group, 'Geometry', 'NodeSocketGeometry', 'INPUT')
    _new_interface_socket(group, 'Factor', 'NodeSocketFloat', 'INPUT')
    _new_interface_socket(group, 'Density', 'NodeSocketFloat', 'INPUT')
    _new_interface_socket(group, 'Seed', 'NodeSocketInt', 'INPUT')
    _new_interface_socket(group, 'Scale', 'NodeSocketFloat', 'INPUT')
    _new_interface_socket(group, 'Radius', 'NodeSocketFloat', 'INPUT')
    _new_interface_socket(group, 'Amount', 'NodeSocketFloat', 'INPUT')
    _new_interface_socket(group, 'Threshold', 'NodeSocketFloat', 'INPUT')
    _new_interface_socket(group, 'Iterations', 'NodeSocketInt', 'INPUT')
    _new_interface_socket(group, 'Geometry', 'NodeSocketGeometry', 'OUTPUT')


def _add_passthrough(group, input_node, output_node) -> bool:
    return _try_link(group, _socket_by_name(input_node.outputs, 'Geometry'), _socket_by_name(output_node.inputs, 'Geometry'))


def _add_realize(group, input_node, output_node, label: str) -> bool:
    node = _new_node(group, 'GeometryNodeRealizeInstances', label=label, location=(0, 20))
    if node is None:
        return False
    ok1 = _try_link(group, _socket_by_name(input_node.outputs, 'Geometry'), _socket_by_name(node.inputs, 'Geometry'))
    ok2 = _try_link(group, _socket_by_name(node.outputs, 'Geometry'), _socket_by_name(output_node.inputs, 'Geometry'))
    return ok1 and ok2


def _add_set_position(group, input_node, output_node, label: str) -> bool:
    node = _new_node(group, 'GeometryNodeSetPosition', label=label, location=(0, 20))
    if node is None:
        return False
    ok1 = _try_link(group, _socket_by_name(input_node.outputs, 'Geometry'), _socket_by_name(node.inputs, 'Geometry'))
    ok2 = _try_link(group, _socket_by_name(node.outputs, 'Geometry'), _socket_by_name(output_node.inputs, 'Geometry'))
    # Optional annotation nodes are created only when Blender exposes them. The geometry path remains safe even if no offset field can be linked.
    pos = _new_node(group, 'GeometryNodeInputPosition', label='Position Field', location=(-300, -180))
    noise = _new_node(group, 'ShaderNodeTexNoise', label='Precision Procedural Field', location=(-60, -200))
    combine = _new_node(group, 'ShaderNodeCombineXYZ', label='Vector Offset Composer', location=(170, -180))
    if pos is not None and noise is not None:
        _try_link(group, _socket_by_name(pos.outputs, 'Position', 'Vector'), _socket_by_name(noise.inputs, 'Vector'))
    if noise is not None and combine is not None:
        _try_link(group, _socket_by_name(noise.outputs, 'Fac', 'Value'), _socket_by_name(combine.inputs, 'Z'))
    if combine is not None:
        _try_link(group, _socket_by_name(combine.outputs, 'Vector'), _socket_by_name(node.inputs, 'Offset'))
    return ok1 and ok2


def _add_store_attribute(group, input_node, output_node, feature: dict[str, Any], attr_name: str) -> bool:
    node = _new_node(group, 'GeometryNodeStoreNamedAttribute', label='Store Smart Attribute', location=(0, 20))
    if node is None:
        return False
    try:
        node.data_type = 'FLOAT'
        node.domain = 'POINT'
    except Exception:
        pass
    for name_socket in ('Name', 'Attribute Name'):
        sock = _socket_by_name(node.inputs, name_socket)
        if sock is not None:
            _set_socket_default(sock, attr_name)
            break
    value_sock = _socket_by_name(node.inputs, 'Value')
    if value_sock is not None:
        if str(feature.get('recipe') or '') in {'density_filter', 'normal_density', 'curvature'}:
            _set_socket_default(value_sock, 1.0)
        else:
            _set_socket_default(value_sock, 0.5)
    ok1 = _try_link(group, _socket_by_name(input_node.outputs, 'Geometry'), _socket_by_name(node.inputs, 'Geometry'))
    ok2 = _try_link(group, _socket_by_name(node.outputs, 'Geometry'), _socket_by_name(output_node.inputs, 'Geometry'))
    return ok1 and ok2


def _recipe_attribute_name(feature: dict[str, Any]) -> str:
    recipe = str(feature.get('recipe') or '')
    mapping = {
        'density': 'sgs_density', 'density_filter': 'sgs_density', 'surface_sampler': 'sgs_density',
        'curvature': 'sgs_curvature', 'normal_density': 'sgs_slope', 'field': 'sgs_field',
        'selection_string': 'sgs_selection', 'selection_modifier': 'sgs_selection', 'boolean': 'sgs_mask', 'boolean_math': 'sgs_mask',
        'metadata': 'sgs_mask', 'attribute_transfer': 'sgs_mask', 'attribute_adjust': 'sgs_variation',
        'erosion': 'sgs_erosion', 'biome': 'sgs_biome', 'culling': 'sgs_cull', 'fracture': 'sgs_piece_id', 'explode': 'sgs_piece_id',
        'grain': 'sgs_grain', 'mapping': 'sgs_mapping_lock', 'auto_uv': 'sgs_uv_intent', 'bake': 'sgs_bake_checkpoint',
    }
    return mapping.get(recipe, f'sgs_{safe_name(recipe or "capsule", max_len=24).lower()}')


def _build_group_nodes(group, feature: dict[str, Any]) -> None:
    _clear_nodes(group)
    input_node = _new_node(group, 'NodeGroupInput', location=(-620, 0))
    output_node = _new_node(group, 'NodeGroupOutput', location=(620, 0))
    if input_node is None or output_node is None:
        return
    try:
        output_node.is_active_output = True
    except Exception:
        pass
    recipe = str(feature.get('recipe') or '')
    label = str(feature.get('label_en') or feature.get('id') or 'Smart Capsule')
    linked = False
    if recipe in {'realize', 'scatter', 'scatter_paint', 'copy_points', 'surface_sampler', 'bounds_point', 'hierarchical_grid'}:
        linked = _add_realize(group, input_node, output_node, f'{label} / instance realization stage')
    elif recipe in {'terrain', 'erosion', 'field', 'point_expression', 'trail', 'signal', 'greeble', 'building', 'ivy', 'smooth', 'liquid'}:
        linked = _add_set_position(group, input_node, output_node, f'{label} / geometry transform stage')
    elif recipe in {'metadata','density','density_filter','attribute_transfer','attribute_adjust','curvature','normal_density','selection_string','selection_modifier','group','filter','boolean','boolean_math','hash','curve_map','topology','bundle','usd','csv','attribute_bridge','field_bridge','image_attribute','mapping','grain','auto_uv','bake','heatmap','inspector','advisor','controller','output','compound','constraint','solver_proxy','volume_proxy','gpu_proxy','sdk_proxy','script','automation','rig_proxy','agent_proxy','retarget','fracture','explode','shatter'}:
        linked = _add_store_attribute(group, input_node, output_node, feature, _recipe_attribute_name(feature))
    if not linked:
        _add_passthrough(group, input_node, output_node)
    domain = str(feature.get('design_domain_en') or feature.get('design_domain') or feature.get('source_system') or '')
    requirement = str(feature.get('requirement_code') or '')
    body = f"Design domain: {domain}. Requirement: {requirement}. Recipe: {recipe}. Precision layer stores dense SGS attributes, supports procedural builders, and remains an independent Blender-native implementation. {feature.get('summary_en','')}"
    _create_frame(group, f'Smart Geometry: {label}', body)


def _stamp_group(group, feature: dict[str, Any]) -> None:
    try:
        mark_owned(group)
        group['sgs_version'] = SUITE_VERSION
        group['sgs_feature_id'] = str(feature.get('id') or '')
        group['sgs_feature_label_en'] = str(feature.get('label_en') or '')
        group['sgs_feature_label_ja'] = str(feature.get('label_ja') or '')
        group['sgs_category'] = str(feature.get('category') or '')
        group['sgs_recipe'] = str(feature.get('recipe') or '')
        group['sgs_design_domain'] = str(feature.get('design_domain_en') or feature.get('design_domain') or feature.get('source_system') or '')
        group['sgs_requirement_code'] = str(feature.get('requirement_code') or '')
        group['sgs_priority'] = str(feature.get('priority') or '')
        group['sgs_implementation'] = str(feature.get('implementation') or '')
        group['sgs_summary_en'] = str(feature.get('summary_en') or '')
        group['sgs_summary_ja'] = str(feature.get('summary_ja') or '')
        group['sgs_precision_layer'] = 'v8_operation_precision_attributes_builders_diagnostics'
        group['sgs_independence_policy'] = 'independent_names_data_model_ui_workflow'
    except Exception:
        pass


def _mark_asset(group, feature: dict[str, Any]) -> None:
    try:
        group.asset_mark()
        group.asset_data.description = str(feature.get('summary_en') or '')
        try:
            group.asset_data.author = 'JELararagi'
        except Exception:
            pass
    except Exception:
        pass


def create_node_group(feature_id: str, settings=None, *, force_rebuild: bool = False):
    feature = catalog.FEATURE_BY_ID.get(str(feature_id or ''))
    if not feature:
        return None
    name = feature_group_name(feature, settings)
    existing = bpy.data.node_groups.get(name)
    if existing is not None and not is_owned(existing):
        # A same-name user/foreign datablock is never adopted or changed. Blender
        # will assign a unique suffix to the newly created Suite group below.
        existing = None
    if existing is not None and force_rebuild:
        _safe_remove_node_group(existing)
        existing = None
    if existing is not None:
        _stamp_group(existing, feature)
        return existing
    try:
        group = bpy.data.node_groups.new(name=name, type='GeometryNodeTree')
    except Exception:
        return None
    _build_group_interface(group)
    _build_group_nodes(group, feature)
    _stamp_group(group, feature)
    if bool(getattr(settings, 'mark_assets', True)):
        _mark_asset(group, feature)
    return group


def create_pack_controller(pack_id: str, settings=None, *, force_rebuild: bool = False):
    pack = catalog.PACK_BY_ID.get(str(pack_id or ''))
    if not pack:
        return None
    name = pack_group_name(pack, settings)
    existing = bpy.data.node_groups.get(name)
    if existing is not None and not is_owned(existing):
        existing = None
    if existing is not None and force_rebuild:
        _safe_remove_node_group(existing)
        existing = None
    if existing is not None:
        return existing
    try:
        group = bpy.data.node_groups.new(name=name, type='GeometryNodeTree')
    except Exception:
        return None
    _build_group_interface(group)
    _clear_nodes(group)
    input_node = _new_node(group, 'NodeGroupInput', location=(-620, 0))
    output_node = _new_node(group, 'NodeGroupOutput', location=(620, 0))
    if input_node and output_node:
        _add_passthrough(group, input_node, output_node)
    features = catalog.features_for_pack(str(pack_id))
    body = '; '.join(str(f.get('label_en') or f.get('id')) for f in features[:16])
    _create_frame(group, f'Smart Geometry Pack: {pack.get("label_en")}', f'{pack.get("description_en")}. Included features: {body}', width=900)
    try:
        mark_owned(group)
        group['sgs_version'] = SUITE_VERSION
        group['sgs_pack_id'] = str(pack.get('id') or '')
        group['sgs_pack_label_en'] = str(pack.get('label_en') or '')
        group['sgs_pack_label_ja'] = str(pack.get('label_ja') or '')
        group['sgs_pack_features'] = ','.join(str(f.get('id') or '') for f in features)
    except Exception:
        pass
    if bool(getattr(settings, 'mark_assets', True)):
        try:
            group.asset_mark()
            group.asset_data.description = str(pack.get('description_en') or '')
            group.asset_data.author = 'JELararagi'
        except Exception:
            pass
    return group


def create_library(settings=None, feature_ids: Iterable[str] | None = None, *, force_rebuild: bool = False) -> list[str]:
    ids = list(feature_ids) if feature_ids is not None else [str(f.get('id')) for f in catalog.FEATURES]
    created: list[str] = []
    for fid in ids:
        group = create_node_group(fid, settings, force_rebuild=force_rebuild)
        if group is not None:
            created.append(group.name)
    for pack in catalog.PACKS:
        group = create_pack_controller(str(pack.get('id') or ''), settings, force_rebuild=force_rebuild)
        if group is not None:
            created.append(group.name)
    return created


def selected_mesh_objects(context) -> list[Any]:
    result = []
    try:
        if str(getattr(context, 'mode', '') or '') not in {'', 'OBJECT'}:
            return result
    except Exception:
        pass
    for obj in list(getattr(context, 'selected_objects', []) or []):
        try:
            if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'data', None) is not None:
                result.append(obj)
        except Exception:
            pass
    return result


def active_mesh_object(context):
    try:
        if str(getattr(context, 'mode', '') or '') not in {'', 'OBJECT'}:
            return None
        obj = getattr(context, 'active_object', None) or getattr(context, 'object', None)
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            return None
        # After select_all(DESELECT), Blender can still expose a previous active
        # object during mode-switch redraw. Treat unselected active objects as
        # unavailable for UI diagnostics and generated operations.
        try:
            if hasattr(obj, 'select_get') and not bool(obj.select_get()):
                return None
        except Exception:
            pass
        if getattr(obj, 'data', None) is None:
            return None
        return obj
    except Exception:
        return None


def apply_feature_to_object(obj, feature_id: str, settings=None):
    feature = catalog.FEATURE_BY_ID.get(str(feature_id or ''))
    if obj is None or not feature:
        return None
    transform_before = transform_guard.capture_object_transform(obj)
    try:
        from . import always_on
        always_on.ensure_attributes_if_enabled(bpy.context, obj=obj)
    except Exception:
        pass
    group = create_node_group(str(feature.get('id')), settings)
    if group is None:
        return None
    mod_name = f'{prefix(settings)} | {catalog.localized(feature, "label") or feature.get("id")}'[:63]
    modifier = None
    try:
        modifier = obj.modifiers.new(name=mod_name, type='NODES')
        modifier.node_group = group
    except Exception:
        modifier = None
    finally:
        try:
            transform_guard.restore_object_transform_if_reset(obj, transform_before)
        except Exception:
            pass
    if modifier is None:
        return None
    try:
        mark_owned(modifier)
        modifier['sgs_version'] = SUITE_VERSION
        modifier['sgs_feature_id'] = str(feature.get('id') or '')
        modifier['sgs_category'] = str(feature.get('category') or '')
        modifier['sgs_recipe'] = str(feature.get('recipe') or '')
        modifier['sgs_design_domain'] = str(feature.get('design_domain_en') or feature.get('design_domain') or feature.get('source_system') or '')
        modifier['sgs_requirement_code'] = str(feature.get('requirement_code') or '')
        modifier['sgs_precision_layer'] = 'v8_operation_precision_attributes_builders_diagnostics'
    except Exception:
        pass
    try:
        transform_guard.restore_object_transform_if_reset(obj, transform_before)
    except Exception:
        pass
    return modifier


def apply_feature_to_selection(context, feature_id: str, settings=None) -> list[str]:
    objects = selected_mesh_objects(context)
    if not objects:
        obj = active_mesh_object(context)
        objects = [obj] if obj is not None else []
    names: list[str] = []
    for obj in objects:
        mod = apply_feature_to_object(obj, feature_id, settings)
        if mod is not None:
            names.append(f'{obj.name}:{mod.name}')
    return names


def apply_pack_to_selection(context, pack_id: str, settings=None, *, limit: int | None = None) -> list[str]:
    features = catalog.features_for_pack(pack_id)
    if limit is not None:
        features = features[:max(0, int(limit))]
    applied: list[str] = []
    for feature in features:
        applied.extend(apply_feature_to_selection(context, str(feature.get('id') or ''), settings))
    return applied


def generated_node_groups() -> list[Any]:
    groups = []
    for group in list(getattr(bpy.data, 'node_groups', []) or []):
        try:
            if is_owned(group):
                groups.append(group)
        except Exception:
            pass
    return groups


def remove_generated_node_groups() -> int:
    groups = generated_node_groups()
    count = 0
    for group in groups:
        try:
            bpy.data.node_groups.remove(group)
            count += 1
        except Exception:
            pass
    return count
