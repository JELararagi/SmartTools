"""Detailed generator settings, node assets and scene diagnostics."""
from . import catalog
def draw(layout,ctx,s,heading,action):
    def box(key,en,ja):return heading(layout,ctx,s,'ui_section_'+key,en,ja,'')
    def fold(parent,key,en,ja):
        if parent is None:return None
        return heading(parent,ctx,s,'ui_child_'+key,en,ja,'')
    def buttons(group,rows):
        if group is not None:
            for name,en,ja in rows:action(group,name,en,ja,ctx)
    def props(group,prefixes):
        if group is not None:
            for k in s.bl_rna.properties.keys():
                if k.startswith(prefixes):group.prop(s,k)
    main=box('procedural_builders','Scene builders','シーン生成ツール')
    buttons(fold(main,'builders_scene_generators','Create scene objects','シーンに生成'),[('create_demo_scene','Build a demonstration scene','作例シーンを生成'),('create_terrain','Build terrain','地形を作成'),('create_building_proxy','Build structure','建物を作成'),('create_greeble_blocks','Build surface details','表面の凹凸を作成')])
    panel=fold(main,'builders_migrated_generators','Parametric models','パラメトリック形状')
    if panel is not None:panel.menu('JELMAX_MT_add_root');panel.operator('jel_max.install_assets',text=catalog.text('Install primitive asset library','プリミティブをアセットライブラリに登録',ctx))
    parent=box('builder_controls','Detailed geometry controls','生成パラメータの詳細')
    for suffix,en,ja,pref in [('terrain','Terrain relief and erosion','地形の起伏と侵食',('terrain_',)),('distribution','Point distribution','分布・間隔',('scatter_',)),('fragments','Connected fragments','破片の形状',('fragment_',)),('precision','Quality and inspection','精度と検査',('precision_','density_','diagnostic_'))]:
        props(fold(parent,'builder_controls_'+suffix,en,ja),pref)
    main=box('debris_generators','Debris tools','デブリ管理')
    if main is not None:
        d=ctx.scene.smart_geometry_suite_debris;main.prop(d,'module');main.prop(d,'seed')
        from .interaction import debris_fields
        for prop in debris_fields(d):main.prop(d,prop)
        buttons(main,[('debris_generate','Build debris','デブリを作成'),('debris_refresh_modules','Refresh modules','種類を再確認'),('debris_open_modules_dir','Open module folder','モジュールフォルダーを開く'),('debris_about','About debris','デブリについて')])
        for key,en,ja in [('PROJECT','Original project','参照元プロジェクト'),('HELP','Original guide','参照元の解説'),('FEATURE','Request a feature','機能要望'),('BUG','Report an issue','不具合を報告')]:action(main,'debris_open_url',en,ja,ctx).action=key
    interop=box('interop','File exchange','入出力・連携')
    group=fold(interop,'interop_paths','CSV input','CSV入力')
    if group is not None:group.prop(s,'csv_path')
    buttons(fold(interop,'interop_exports','Export sidecars','連携用ファイルを保存'),[('export_bundle_manifest','Toolset bundle manifest','機能一覧マニフェスト'),('export_usd_manifest','USD sidecar','USD用サイドカー'),('import_csv_points','Read point locations','点座標を読み込む')])
    main=box('diagnostics','Mesh diagnostics','メッシュ診断')
    group=fold(main,'diagnostics_active_mesh','Active object','選択中のメッシュ')
    ob=ctx.active_object
    if group is not None and getattr(ob,'type',None)=='MESH':
        group.label(text=ob.name,icon='MESH_DATA');group.label(text=catalog.text('Vertices','頂点数',ctx)+' '+str(len(ob.data.vertices)));group.label(text=catalog.text('Faces','面数',ctx)+' '+str(len(ob.data.polygons)));group.label(text=catalog.text('Attributes','属性数',ctx)+' '+str(len(ob.data.attributes)))
    buttons(fold(main,'diagnostics_exports','Save diagnostic reports','診断の保存'),[('refresh_diagnostics','Refresh diagnostics','診断を更新'),('export_diagnostics','Export diagnostics','診断を書き出す'),('export_inventory','Export inventory','機能一覧を書き出す')])
    tools=box('suite_controls','Node assets and selection','ノードアセット・適用')
    group=fold(tools,'suite_storage','Library','ライブラリ')
    if group is not None:
        group.prop(s,'capsule_prefix');group.prop(s,'mark_assets');group.operator('jel_max.install_assets',text=catalog.text('Install primitive assets','基本形状アセットを登録',ctx))
    buttons(group,[('create_node_library','Create node library','ノードライブラリを作成'),('rebuild_node_library','Rebuild node library','ノードライブラリを再構築'),('remove_generated_node_groups','Remove generated node groups','生成したノードグループを整理')])
    buttons(fold(tools,'suite_actions','Apply geometry capsules','カプセルを適用'),[('apply_pack','Apply selected pack','選択パックを適用'),('apply_full_independent_suite','Apply the full suite','全カプセルを適用')])
    vis=box('visual_dashboard','Scene workflows','シーンの一括操作')
    group=fold(vis,'dashboard_scene_workflows','Workflow shortcuts','用途別の操作')
    if group is not None:
        for key,en,ja in [('terrain','Terrain','地形'),('distribution','Scatter','散布'),('growth','Growth','成長'),('refine','Refine selection','選択形状を精密化')]:action(group,'run_visual_workflow',en,ja,ctx).workflow_id=key
        buttons(group,[('refine_scene_precision','Refine mesh fields','精度属性を更新'),('polish_precision_overdrive','Polish mesh fields','精度属性を仕上げ')])
    main=box('design_coverage','Feature coverage','機能の内訳')
    if main is not None:
        main.label(text=catalog.text('Capsules','カプセル数',ctx)+' '+str(len(catalog.FEATURES)));main.label(text=catalog.text('Packs','パック数',ctx)+' '+str(len(catalog.PACKS)));buttons(main,[('export_design_coverage','Save design coverage','機能の内訳を保存')])
    main=box('visual_ui','Display and reference plates','表示・参考図')
    group=fold(main,'visual_ui_display','Sidebar preferences','サイドバーの表示')
    props(group,('ui_density','ui_show_','ui_use_','ui_borderless_','ui_button_','ui_icon_','ui_v8_'))
    buttons(fold(main,'visual_ui_reference','Reference images','参考画像'),[('open_visual_reference','Open workflow guide','作業手順の参考図を開く'),('reload_custom_icons','Reload icon images','アイコンを読み直す'),('export_icon_reference_sheet','Save icon sheet','アイコンの一覧画像を保存')])
