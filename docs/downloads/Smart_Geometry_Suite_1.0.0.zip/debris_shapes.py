# SPDX-License-Identifier: GPL-3.0-or-later
"""Original procedural meshes for Smart Geometry, in the generator's local units."""

from math import cos, pi, sin, tau


def masonry(style):
    """Build a brick as the boundary of contiguous occupied rectangular cells."""
    if style == 'mason':
        xs, ys, zs = (-1.75, 1.75), (-3.75, 3.75), (-1.25, 1.25)
    else:
        xs = (-4, -2.7, 0, 2.7, 4)
        ys = (-8, -6.7, -0.65, 0.65, 6.7, 8)
        zs = (-4, 4)
    occupied = {(i, j) for i in range(len(xs)-1) for j in range(len(ys)-1)}
    if style == 'cinder':
        occupied -= {(i, j) for i in (1, 2) for j in (1, 3)}
    elif style == 'corner':
        occupied -= {(i, j) for i in (2, 3) for j in (3, 4)}
    vertices, faces, ids = [], [], {}

    def face(corners):
        indices = []
        for x, y, z in corners:
            p = xs[x], ys[y], zs[z]
            if p not in ids:
                ids[p] = len(vertices)
                vertices.append(p)
            indices.append(ids[p])
        faces.append(indices)

    for i, j in sorted(occupied):
        ring = [(i, j), (i+1, j), (i+1, j+1), (i, j+1)]
        face([(x, y, 0) for x, y in reversed(ring)])
        face([(x, y, 1) for x, y in ring])
        for side, (di, dj) in enumerate(((0,-1), (1,0), (0,1), (-1,0))):
            if (i+di, j+dj) not in occupied:
                a, b = ring[side], ring[(side+1) % 4]
                face([(*a, 0), (*b, 0), (*b, 1), (*a, 1)])
    return {"verts": vertices, "faces": faces}


def _maple_surface(length, variant, steps):
    """One continuous palmate lamina with five major lobes and a raised vein fan."""
    radii = ((0, .83), (19, .32), (40, .73), (57, .29), (76, .55),
             (98, .22), (117, .36), (146, .16), (180, .28))
    count = 2*steps
    vertices = [(0, .28*length, .07*length)]
    faces = []
    for band in range(1, 5):
        fraction = band/4
        for i in range(count):
            theta = tau*i/count
            angle = abs((360*i/count+180)%360-180)
            for (a0,r0),(a1,r1) in zip(radii,radii[1:]):
                if angle <= a1:
                    t = (angle-a0)/(a1-a0)
                    radius = length*(r0*(1-t)+r1*t)
                    break
            radius *= fraction*(1-.035*(i%2))
            x = -radius*sin(theta)*(1+.055*variant*sin(theta))
            y = .28*length + radius*cos(theta)
            ridge = cos(5*theta)**2*fraction*(1-fraction)
            vertices.append((x,y,length*(.07*(1-fraction)+.045*ridge+.015*variant*fraction)))
        for i in range(count):
            q = 1+(band-1)*count
            j = (i+1)%count
            if band==1:
                faces.append((0,q+i,q+j))
            else:
                faces.append((q+i-count,q+i,q+j,q+j-count))
    return {'verts':vertices,'faces':faces}


def foliage(species, variant, *, steps=36):
    """Build midrib strips, including individual leaflets for compound leaves."""
    vertices, faces = [], []
    def blade(root, length, width, angle, kind):
        rows = []
        for step in range(steps+1):
            t = step / steps
            envelope = max(0, sin(pi*t)) ** (0.68 if kind == 'birch' else 0.9)
            if kind == 'red oak':
                envelope *= 0.4 + 0.6 * abs(sin(4*pi*t)) ** 2
            elif kind == 'white oak':
                envelope *= 0.48 + 0.52 * abs(sin(3*pi*t)) ** 0.85
            elif kind in ('birch', 'elm'):
                envelope *= 1 if step % 2 else 0.86
            if kind == 'birch':
                envelope *= 1.3 - 0.6*t
            # Small asymmetric bend differentiates the two specimen variants.
            mid = length*(0.018 if variant else -0.024)*sin(pi*t)
            row = []
            for flank in ((0,) if step in (0,steps) else (-1,0,1)):
                transverse = mid + flank * width * envelope
                distance = length*t
                x = root[0] + sin(angle)*distance + cos(angle)*transverse
                y = root[1] + cos(angle)*distance - sin(angle)*transverse
                z = 0.06*y + (0.09 if variant else -0.08)*width*envelope*abs(flank)
                row.append(len(vertices))
                vertices.append((x,y,z))
            rows.append(row)
        for a,b in zip(rows,rows[1:]):
            if len(a)==1:
                faces.extend([[a[0],b[1],b[0]],[a[0],b[2],b[1]]])
            elif len(b)==1:
                faces.extend([[a[0],a[1],b[0]],[a[1],a[2],b[0]]])
            else:
                faces.extend([[a[0],a[1],b[1],b[0]],[a[1],a[2],b[2],b[1]]])

    length = (21 if variant else 19)
    if species == 'ash':
        blade((0,0), length*0.83, 0.28, 0, 'stalk')
        for i in range(3):
            for side in (-1,1):
                blade((0,length*(0.18+0.20*i)), length*(0.45-0.065*i), 1.6,
                      side*(0.97-0.10*i), 'leaflet')
        blade((0,length*0.76), length*0.35, 1.7, 0, 'leaflet')
    elif species == 'maple':
        return _maple_surface(length, variant, steps)
    else:
        blade((0,0), length, length*(0.34 if species=='birch' else 0.24), 0, species)
    return {"verts":vertices, "faces":faces}


def loft(rings):
    n = len(rings[0])
    faces = [tuple(reversed(range(n)))]
    for row in range(1,len(rings)):
        for i in range(n):
            j=(i+1)%n
            faces.append(((row-1)*n+i,(row-1)*n+j,row*n+j,row*n+i))
    faces.append(tuple(range((len(rings)-1)*n,len(rings)*n)))
    return {"verts":[p for ring in rings for p in ring], "faces":faces}


def pigeon_body():
    # Cross-sections progress from fan tail through breast, head and beak.
    sections = ((-3.6, 0.62, 0.60, 0.07), (-2.4, 0.77, 0.67, 0.17),
                (-1.45, 1.05, 0.94, 0.62), (-0.35, 1.18, 1.46, 0.97),
                (0.62, 1.28, 1.05, 0.90), (1.17, 1.85, 0.55, 0.55),
                (1.63, 2.01, 0.53, 0.49), (1.97, 2.0, 0.32, 0.27),
                (2.45, 1.95, 0.035, 0.035))
    return loft([[(w*cos(tau*i/14), y, z-h*sin(tau*i/14)) for i in range(14)]
                 for y,z,w,h in sections])


def pigeon_wing(tip):
    span = 3.7 if tip else 4.87
    rings = []
    for i in range(9):
        s=i/8
        chord=(1.15*(1-s)**0.7+0.04) if tip else (1.25+0.32*sin(pi*s)-0.06*s)
        axis_y=-0.47*s - (1.4*s*s if tip else 0)
        rings.append([(-span*s,axis_y+chord*cos(tau*j/12),
                       -0.11*chord*sin(tau*j/12)+0.13*sin(pi*s)) for j in range(12)])
    return loft(rings)
