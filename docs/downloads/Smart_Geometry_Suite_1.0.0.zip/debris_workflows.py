# SPDX-License-Identifier: GPL-3.0-or-later
"""Smart Geometry debris construction from the public settings and module descriptions."""
from math import cos, exp, pi, radians, sin, sqrt, tau
from random import Random
from . import debris_shapes
from .debris_geometry import Mesh, globe, plank, sheet, tapered

# Names are persistent material identifiers from Smart Geometry's bilingual UI.
SURFACES={
    'BRICK':('Max Brick',(0.47,0.16,0.085)), 'CORRUGATED':('Max Corrugated Metal',(0.32,0.36,0.37)),
    'CRYSTAL':('Crystal',(0.31,0.60,0.76)), 'GEMSTONES':('Gemstone',(0.14,0.48,0.32)),
    'GRASS':('Grass',(0.17,0.39,0.10)), 'GRAVEL':('Gravel',(0.35,0.32,0.29)),
    'LEAVES':('Fallen Leaves',(0.54,0.26,0.071)), 'LOGS':('Log Core',(0.38,0.21,0.095)),
    'METEOR':('Meteorite',(0.18,0.16,0.15)), 'OBSIDIAN':('Obsidian',(0.046,0.038,0.065)),
    'PIGEONS':('Pigeon Gray',(0.41,0.44,0.47)), 'PLANKS':('Plank Wood',(0.48,0.31,0.16)),
    'RIVERSTONES':('Riverstone',(0.34,0.38,0.37)), 'SANDSTONE':('Sandstone',(0.61,0.41,0.25)),
    'SHRAPNEL':('Shrapnel',(0.32,0.28,0.24)), 'SLATE':('Slate',(0.22,0.29,0.34)),
    'SNOWFLAKES':('Snowflake',(0.78,0.90,0.98)), 'SPLINTERS':('Splinter',(0.52,0.34,0.18)),
    'TWIGS':('Twig',(0.32,0.18,0.10)),
}


class Builder:
    def __init__(self,ctx,p,host):
        self.ctx,self.p,self.host=ctx,p,host
        self.rng=Random(p.seed)
        self.objects=[]

    def material(self,secondary=False):
        name,rgb=SURFACES[self.p.module]
        if self.p.module=='PIGEONS' and not self.p.pigeon_material:
            return None
        if secondary:
            name={'PIGEONS':'Pigeon Dark','GRASS':'Grass Seed','PLANKS':'Plank Dark Cracks','TWIGS':'Twig Wart'}.get(self.p.module,name+' Detail')
            rgb=tuple(v*0.48 for v in rgb)
        metallic=0.64 if self.p.module in ('CORRUGATED','SHRAPNEL') else 0
        roughness=0.21 if self.p.module in ('CRYSTAL','GEMSTONES','OBSIDIAN') else 0.72
        return self.host._material('SGS Debris '+name,(*rgb,1),roughness,metallic)

    def emit(self,mesh,location,*,name=None,smooth=False,bevel=0,segments=1,reduce=0,shell=0,secondary=False):
        label=name or ('SGS '+self.p.module.title())
        obj=self.host._mesh_obj(self.ctx,label,mesh.vertices,mesh.faces,self.material(secondary),smooth)
        obj.location=location
        if mesh.accent:
            obj.data.materials.append(self.material(True))
            for i in mesh.accent:obj.data.polygons[i].material_index=1
        if bevel:self.host._add_bevel(obj,bevel,segments)
        if reduce:self.host._add_decimate(obj,100-reduce)
        if shell:
            mod=obj.modifiers.new(self.host.catalog.text('Thickness','厚み'),'SOLIDIFY')
            self.host._mark_owned(mod,role='debris_modifier')
            mod.thickness=shell
        self.objects.append(obj)
        return obj


def bricks(b):
    p,r=b.p,b.rng
    styles=[name for name in ('cinder','corner','mason') if getattr(p,'brick_'+name)] or ['cinder']
    n=p.brick_wall_width if p.brick_wall else p.brick_versions
    rows=p.brick_wall_height if p.brick_wall else 1
    typical_width=7.5 if styles==['mason'] else 16
    typical_height=2.5 if styles==['mason'] else 8
    for row in range(rows):
        x=(row%2)*(typical_width+p.brick_mortar_gap)*0.5 if p.brick_wall and p.brick_running else 0
        for column in range(n):
            style=r.choice(styles)
            data=debris_shapes.masonry(style)
            jitter=p.brick_irregularity*0.018
            mesh=Mesh([tuple(c+r.uniform(-jitter,jitter) for c in v) for v in data['verts']],data['faces'])
            header=p.brick_wall and ((p.brick_english and row%2==1) or (p.brick_flemish and (row+column)%2==1) or
                                     ((p.brick_english or p.brick_flemish) and (column+1)%p.brick_special_n==0))
            length=(3.5 if header else 7.5) if style=='mason' else (8 if header else 16)
            y=0 if p.brick_wall or p.brick_flat_array else r.uniform(-typical_width/2,typical_width/2)
            obj=b.emit(mesh,(x+length/2,y,row*(typical_height+p.brick_mortar_gap)),
                       bevel=p.brick_erosion*0.025+(0.028 if p.brick_high_poly else 0),
                       segments=3 if p.brick_high_poly and not p.brick_low_poly else 1)
            obj.rotation_euler.z=0 if header else pi/2
            x+=length+(p.brick_mortar_gap if p.brick_wall else 1.5)


def panels(b):
    p,r=b.p,b.rng;corr=p.module=='CORRUGATED'
    count=p.corr_count if corr else p.shrapnel_count
    for i in range(count):
        n=9+3*p.corr_detail if corr else max(3,p.shrapnel_resolution)
        phi=r.uniform(0,tau)
        extent=r.uniform(0.5,0.90) if corr and p.corr_slice else 1
        centers=[]
        if corr and p.corr_rust_holes:
            clusters=[(r.uniform(.16,.84),r.uniform(.16,.84)) for _ in range(max(1,p.corr_rust_clusters))]
            for _ in range(p.corr_rust_holes_count):
                x,y=r.choice(clusters);centers.append((x+r.uniform(-.08,.08),y+r.uniform(-.08,.08),r.uniform(.028,.085)))
        if not corr and p.shrapnel_cut_holes:
            centers=[(r.uniform(.12,.88),r.uniform(.12,.88),r.uniform(.05,.14)) for _ in range(max(1,n//4))]
        def visible(u,v):
            if u>extent and v>0.42+0.16*sin(8*u+phi):return False
            return all((u-x)**2+(v-y)**2>rad**2 for x,y,rad in centers)
        def point(u,v):
            if corr:
                amplitude=.24*sin(tau*5*u+phi)
                deform=p.corr_deform_amount*sin(pi*max(1,p.corr_deform_creases)*v+phi) if p.corr_wrap else 0
                perturb=.10*sin(9*u+12*v+phi) if p.corr_irregular else 0
                return ((u-.5)*10+perturb,(v-.5)*13+perturb,amplitude+deform*(1+2*u))
            return ((u-.5)*8+(v-.5)*1.3,(v-.5)*9+0.52*sin(7*u+phi),
                    .3*p.shrapnel_noise_scale*(sin(5*u+phi)*v+.4*cos(8*v-u)))
        b.emit(sheet(2*n if corr else n,n,point,visible),(i*12,0,0),shell=.045)


def stones(b):
    p,r=b.p,b.rng;m=p.module
    prefix={'CRYSTAL':'gem','GEMSTONES':'gem','GRAVEL':'gravel','METEOR':'meteor','OBSIDIAN':'obsidian','RIVERSTONES':'river'}[m]
    for i in range(getattr(p,prefix+'_count')):
        phase=r.uniform(0,tau);dx,dy=r.uniform(.83,1.18),r.uniform(.83,1.18)
        if m=='CRYSTAL':
            sides=4+int(sqrt(p.gem_facets))
            noise=p.gem_irregularity/100
            stem=r.uniform(2.4,3.4)
            mesh=tapered([(0,0,0),(0,0,.4),(noise,.12,stem),(.14+noise,0,stem+1.2)],
                         [.63,1.0,.83,.035],sides)
        else:
            shape={'GEMSTONES':((2*dx,2*dy,1.7),3+int(sqrt(p.gem_facets)),6+int(sqrt(p.gem_facets))),
                   'GRAVEL':((1.3*dx,dy,.62),5,10), 'METEOR':((2.7*dx,2.6*dy,2.3),12,22),
                   'OBSIDIAN':((1.4*dx,dy,2.4),4,8),'RIVERSTONES':((2.4*dx,1.8*dy,1.18),12,20)}[m]
            def relief(lon,lat):
                broad=sin(2*lon+phase)*cos(2*lat)
                fine=sin(11*lon+phase)*sin(8*lat)
                if m=='GEMSTONES':return p.gem_irregularity*.009*broad
                if m=='OBSIDIAN':return p.obsidian_irregularity*.016*broad+.12*fine
                if m=='GRAVEL':return .12*sin(lon*p.gravel_irregularity_size+phase)*cos(lat*2)+.006*(20-p.gravel_roughness)*fine
                if m=='METEOR':return p.meteor_large*.009*broad+p.meteor_medium*.004*sin(5*lon+lat)+p.meteor_small*.003*min(0,fine)
                irregular=p.river_irregular_amount*.007*sin((2+p.river_irregular_size*.1)*lon+phase)*cos(2*lat) if p.river_irregular else 0
                pits=p.river_pitting_amount*.006*min(0,sin((6+p.river_pitting_size*.3)*lon+phase)*cos(7*lat)) if p.river_pitting else 0
                return irregular+pits-(p.river_chip_amount*.014 if p.river_chipping and broad>.65 else 0)
            mesh=globe(r,*shape,relief)
            if m=='RIVERSTONES' and p.river_banding:
                for j,face in enumerate(mesh.faces):
                    z=sum(mesh.vertices[k][2] for k in face)/len(face)
                    if sin(z*(1+p.river_band_size*.3)+phase)>1-min(.98,p.river_band_amount*.04):
                        mesh.accent.add(j)
        bevel=p.gem_chamfer_amount*.04 if prefix=='gem' and p.gem_chamfer else 0
        reduce=getattr(p,prefix+'_optimize_percent',0) if getattr(p,prefix+'_optimize',False) else 0
        b.emit(mesh,(i*6.5,0,0),smooth=m in ('RIVERSTONES','GRAVEL'),bevel=bevel,reduce=reduce)


def grass(b):
    p,r=b.p,b.rng
    height,width,seedhead={'SWITCH':(1,.20,False),'INDIAN':(1.05,.25,True),'YARD':(.46,.28,False),
                           'WHEAT':(.87,.16,True),'BULRUSH':(1.12,.20,True)}[p.grass_type]
    for tuft in range(p.grass_tuft_count):
        mesh=Mesh()
        for blade in range(p.grass_blades_count):
            a=r.uniform(0,tau);rad=sqrt(r.random())
            x,y=1.9*rad*cos(a),1.9*rad*sin(a)
            fade=1-.59*rad**2 if p.grass_fade else 1
            h=p.grass_height*height*fade*r.uniform(.84,1.10)
            w=width*fade;lean=h*(.05+.11*rad)
            def point(t,flank):
                sway=lean*t*t+p.grass_leaf_irregularity*sin(pi*t)*sin(a*3)
                return (x+sway*cos(a)-flank*w*(1-.88*t)*sin(a),
                        y+sway*sin(a)+flank*w*(1-.88*t)*cos(a),h*t)
            blade_mesh=sheet(1,5,lambda u,v:point(v,2*u-1),lambda u,v:True)
            mesh.extend(blade_mesh)
            for k in range(p.grass_leaf_count):
                t=(k+1)/(p.grass_leaf_count+1)*.72
                start=point(t,0);theta=a+(1 if k%2 else -1)*(.6+r.random())
                spread=h*(.13+.16*r.random())
                end=(start[0]+spread*cos(theta),start[1]+spread*sin(theta),start[2]+spread*(.62+sin(radians(p.grass_leaf_bend))))
                mid=tuple((u+v)*.5 for u,v in zip(start,end))
                mesh.extend(Mesh([start,(mid[0]-w*sin(theta),mid[1]+w*cos(theta),mid[2]+w),
                                  end,(mid[0]+w*sin(theta),mid[1]-w*cos(theta),mid[2]+w)],[(0,1,2,3)]))
            if seedhead and blade%4==0:
                tip=point(1,0)
                head=tapered([(0,0,0),(0,0,.17*h),(0,0,.22*h)],[w*.55,w*(1.15 if p.grass_type=='BULRUSH' else .85),w*.08],5)
                mesh.extend(head,tip,accent=True)
        b.emit(mesh,(tuft*6,0,0),smooth=True)


def foliage(b):
    p,r=b.p,b.rng
    species=['ash','birch','elm','maple','red oak','white oak']
    enabled=[s for s in species if getattr(p,'leaves_'+s.replace(' ','_'))] or ['ash']
    for row,kind in enumerate(enabled):
        for col in range(p.leaves_count):
            data=debris_shapes.foliage(kind,r.randrange(2),steps=36 if p.leaves_high_res else 18)
            mesh=Mesh();factor=r.uniform(.14,.17)
            for x,y,z in data['verts']:
                phase=y/20;angle=p.leaves_twist_value*phase if p.leaves_twist else 0
                shear=phase*y*p.leaves_skew_value*.12 if p.leaves_skew else 0
                crease=abs(x)*p.leaves_crease_value*.25 if p.leaves_crease else 0
                noise=r.uniform(-.24,.24)*p.leaves_noise_value if p.leaves_noise else 0
                mesh.vertices.append(((x*cos(angle)-z*sin(angle)+shear)*factor,y*factor,
                                      (z*cos(angle)+x*sin(angle)+crease+noise)*factor))
            for face in data['faces']:
                ux=sum(abs(data['verts'][j][0]) for j in face)/len(face)
                if p.leaves_tears and ux>1.5 and r.random()<.018:continue
                if p.leaves_holes and r.random()<.018:continue
                mesh.faces.append(face)
            b.emit(mesh,(col*4.5,row*5,0),smooth=p.leaves_high_res,shell=.018 if p.leaves_thickness else 0)


def logs(b):
    p,r=b.p,b.rng
    n=p.logs_generation_number
    stack=[(row,col) for row in range(p.logs_stack_height) for col in range(max(1,p.logs_stack_width-row))] if p.logs_stacked else []
    for j in range(len(stack) if stack else n):
        length=p.logs_length*(1+r.uniform(-1,1)*p.logs_length_deviation*.009)
        radius=p.logs_radius*(1+r.uniform(-1,1)*p.logs_radius_deviation*.009)
        steps=11 if p.logs_high_poly else 5
        sides=23 if p.logs_high_poly else 11
        phase=r.uniform(0,tau)
        path=[(length*(k/steps-.5),sin(pi*k/steps)*p.logs_deformation*.05*cos(phase),
               sin(tau*k/steps+phase)*p.logs_deformation*.025) for k in range(steps+1)]
        mesh=tapered(path,[radius*(1-.08*k/steps) for k in range(steps+1)],sides)
        if p.logs_make_bark:
            for k in range(sides):
                a=tau*k/sides
                groove=[(x,y+radius*.96*cos(a),z+radius*.96*sin(a)) for x,y,z in path]
                mesh.extend(tapered(groove,[p.logs_bark_thickness*.11]*(steps+1),4),accent=True)
        if p.logs_stacked:
            row,col=stack[j]
            loc=(0,(col+.5*min(row,p.logs_stack_width-1))*p.logs_radius*2.2,row*p.logs_radius*1.85)
        else:
            loc=(0,j*p.logs_radius*2.4,0) if p.logs_array else (r.uniform(-n,n),r.uniform(-n,n),0)
        b.emit(mesh,loc,smooth=p.logs_high_poly)


def pigeons(b):
    p,r=b.p,b.rng
    n=p.pigeon_number if p.pigeon_particle else 1
    parts=(debris_shapes.pigeon_body(),debris_shapes.pigeon_wing(False),debris_shapes.pigeon_wing(True))
    beat=5 if p.pigeon_animation=='FAST' else 8
    end=9 if p.pigeon_animation=='FAST' else 12
    for j in range(n):
        x,y=(j%8)*18.0,(j//8)*9.0
        body=b.emit(Mesh.from_shape(parts[0]),(x,y,0),name='Pigeon Body',smooth=True)
        body.keyframe_insert(data_path='location',frame=1)
        b.host._mark_owned(body.animation_data.action,role='debris_action')
        body.location.y+=2.4 if p.pigeon_animation=='FAST' else 1.5
        body.keyframe_insert(data_path='location',frame=end)
        for sign in (-1,1):
            upper=b.emit(Mesh.from_shape(parts[1]),(sign*1.24,-.08,1.45),name='Pigeon Wing',smooth=True,secondary=True)
            upper.parent=body
            if sign>0:upper.scale.x=-1
            tip=b.emit(Mesh.from_shape(parts[2]),(-4.87,-.47,0),name='Pigeon Wingtip',smooth=True,secondary=True)
            tip.parent=upper
            for part,amount in [(upper,.64),(tip,.33)]:
                for frame,angle in [(1,-.38),(beat,1.0),(end,-.38)]:
                    part.rotation_euler.y=angle*amount*(sign if part==upper else -1)
                    part.keyframe_insert(data_path='rotation_euler',frame=frame)
                    if frame==1:b.host._mark_owned(part.animation_data.action,role='debris_action')


def planks(b):
    p,r=b.p,b.rng
    for j in range(p.planks_count):
        length=r.uniform(p.planks_len_min,p.planks_len_max);width=r.uniform(p.planks_width_min,p.planks_width_max)
        height=r.uniform(p.planks_height_min,p.planks_height_max)
        twist=r.uniform(-.20,.20) if p.planks_twist else 0
        rough=width*.16 if p.planks_irregular_ends else 0
        pieces=(.59,.40) if p.planks_break and (j%2==0 or r.random()<.25) else (1.,)
        x=-length*.5;board=Mesh()
        y_offset=j*(p.planks_width_max+1.5)
        for k,ratio in enumerate(pieces):
            extent=length*ratio
            piece=plank(extent,width,height,twist,rough,r)
            angle=.16*k
            piece.vertices=[(u*cos(angle)-v*sin(angle),u*sin(angle)+v*cos(angle),w) for u,v,w in piece.vertices]
            board.extend(piece,(x+extent/2,0,0))
            x+=extent+rough+.15
        b.emit(board,(0,y_offset,0))
        if p.planks_knots:
            knot=globe(r,(length*.035,width*.12,height*.045),3,8,lambda u,v:0)
            b.emit(knot,(-length*.24,y_offset,height*.50),name='Plank Knot',secondary=True)
        if p.planks_cracks:
            for k in range(p.planks_cracks_count):
                y=(k+.5)/p.planks_cracks_count*width*.6-width*.3
                crack=tapered([(-length*.42,y,height*.51),(-length*.22,y+.06*width,height*.52),
                               (-length*.05,y,height*.50)],[.012,.032,.014],3)
                b.emit(crack,(0,y_offset,0),name='Plank Crack',secondary=True)


def layers(b):
    p,r=b.p,b.rng;prefix='slate' if p.module=='SLATE' else 'sandstone'
    def prop(key):return getattr(p,prefix+'_'+key)
    for i in range(prop('count')):
        n=r.randint(*sorted((prop('facets_start'),prop('facets_end'))))
        plates=max(1,p.slate_plates+r.randint(-p.slate_plates_variation,p.slate_plates_variation)) if prefix=='slate' else 1
        height=max(.15,prop('thickness')+r.uniform(-.48,.48)*prop('thickness_var'))
        mesh=Mesh();phase=r.uniform(0,tau)
        for j in range(plates):
            pan=tapered([(0,0,0),(0,0,height/plates*.43),(.03,0,height/plates*.95)],
                        [(3.7,3.2),(4.3,3.5),(3.82,3.0)],n,twist=.07)
            for k,(x,y,z) in enumerate(pan.vertices):
                wear=1+r.uniform(-.13,.13) if prefix=='slate' or p.sandstone_edge_detail else 1
                pan.vertices[k]=(wear*(x*cos(phase)-y*sin(phase)),wear*(x*sin(phase)+y*cos(phase)),z)
            mesh.extend(pan,(r.uniform(-.15,.15),r.uniform(-.15,.15),j*height/plates),accent=(prefix=='slate' and j%3==2))
        b.emit(mesh,(i*10,0,0),reduce=prop('optimize_percent') if prop('optimize') else 0)


def snow(b):
    p,r=b.p,b.rng
    for j in range(p.snow_count):
        mesh=Mesh();length=r.uniform(2.0,3.3);branches=r.randint(2,4)
        for k in range(6):
            a=tau*k/6
            def pos(distance,offset=0):
                return (distance*cos(a)-offset*sin(a),distance*sin(a)+offset*cos(a),0)
            mesh.extend(tapered([pos(0),pos(length)],[.10,.045],5))
            for step in range(1,branches+1):
                t=step/(branches+1)
                for side in (-1,1):
                    d=length*.28*(1-.55*t)
                    mesh.extend(tapered([pos(length*t),pos(length*t+d*.70,side*d)],[.067,.025],5))
        b.emit(mesh,(j*7,0,0))


def timber(b):
    p,r=b.p,b.rng;twig=p.module=='TWIGS'
    for j in range(p.twigs_count if twig else p.splinters_count):
        length=p.twigs_length if twig else max(1,p.splinters_height+r.uniform(-.8,.8)*p.splinters_height_variation)
        n=p.twigs_segments if twig else 6
        phase=r.uniform(0,tau)
        def center(t):
            if twig and not p.twigs_warping:return (0,0,t*length)
            return (sin(pi*t)*length*.05*cos(phase+2*t),sin(2*pi*t)*length*.035*sin(phase+t),t*length)
        path=[center(k/n) for k in range(n+1)]
        rs=[length*(.019 if twig else .014)*(1-.94*k/n) for k in range(n+1)]
        spin=(.9 if p.twigs_twisting else 0) if twig else radians(p.splinters_twisting)
        mesh=tapered(path,rs,7 if twig else 3,spin)
        pos=(j*4.6,0,0)
        if twig:
            if p.twigs_broken_ends:
                for i in range(len(mesh.vertices)-7,len(mesh.vertices)):
                    x,y,z=mesh.vertices[i];mesh.vertices[i]=(x,y,z-r.random()*p.twigs_ends_value)
            details=[]
            if p.twigs_branching:
                for k in range(p.twigs_branch_count):
                    t=(k+1)/(p.twigs_branch_count+1);base=center(t);a=phase+k*2.4;ln=p.twigs_branch_length
                    details.append((tapered([(0,0,0),(ln*.45*cos(a),ln*.45*sin(a),ln*.3),(ln*.75*cos(a),ln*.75*sin(a),ln*.64)],
                                             [rs[0]*.45,rs[0]*.22,.04],5),base))
            if p.twigs_warts:
                for k in range(p.twigs_warts_count):
                    t=r.uniform(.07,.92);x,y,z=center(t);a=r.uniform(0,tau);rad=rs[min(n,round(n*t))]
                    bump=globe(r,(rad*.39,rad*.37,rad*.48),3,5,lambda u,v:0)
                    details.append((bump,(x+.9*rad*cos(a),y+.9*rad*sin(a),z)))
            for detail,offset in details:
                if p.twigs_weld_all:mesh.extend(detail,offset,accent=True)
                else:b.emit(detail,tuple(v+w for v,w in zip(pos,offset)),name='Twig Detail',secondary=True)
        b.emit(mesh,pos,smooth=twig)


OPERATIONS={'BRICK':bricks,'CORRUGATED':panels,'CRYSTAL':stones,'GEMSTONES':stones,'GRASS':grass,
            'GRAVEL':stones,'LEAVES':foliage,'LOGS':logs,'METEOR':stones,'OBSIDIAN':stones,
            'PIGEONS':pigeons,'PLANKS':planks,'RIVERSTONES':stones,'SANDSTONE':layers,'SHRAPNEL':panels,
            'SLATE':layers,'SNOWFLAKES':snow,'SPLINTERS':timber,'TWIGS':timber}

def generate(context,settings,host):
    builder=Builder(context,settings,host)
    OPERATIONS[settings.module](builder)
    host._select_only(context,builder.objects)
    return builder.objects

