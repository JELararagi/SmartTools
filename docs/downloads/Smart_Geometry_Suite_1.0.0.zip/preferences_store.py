"""Persist settings to the public per-user configuration location with atomic replacement."""
import json,os
from pathlib import Path
import bpy
import bpy.app.handlers
from .schema import DATA
LOADING=False
def location():
    return Path(bpy.utils.user_resource('CONFIG'))/'Smart_Geometry_Suite'/'Smart_Geometry_Suite.json'
def groups(ctx):return [('settings',getattr(ctx.window_manager,'smart_geometry_suite_settings',None),'SGS_Settings'),('debris_settings',getattr(ctx.scene,'smart_geometry_suite_debris',None),'SGS_DebrisSettings')]
def read(ctx):
    global LOADING
    file=location()
    if not file.exists():return
    try:data=json.loads(file.read_text('utf-8-sig'))
    except (ValueError,OSError):return
    LOADING=True
    try:
        for namespace,props,cls in groups(ctx):
            if props:
                for k,v in data.get(namespace,{}).items():
                    if k in DATA['groups'][cls]:
                        try:setattr(props,k,v)
                        except (ValueError,TypeError,OverflowError):pass
    finally:LOADING=False
def write(ctx):
    if LOADING or not getattr(ctx,'scene',None):return
    groups_to_save=groups(ctx)
    if not all(o for n,o,c in groups_to_save):return
    file=location();file.parent.mkdir(exist_ok=True,parents=True)
    try:original=json.loads(file.read_text('utf-8-sig')) if file.exists() else {}
    except (OSError,ValueError):original={}
    if not isinstance(original,dict):original={}
    original.setdefault('schema','smart_geometry_suite_settings');original.setdefault('version','1.0.0')
    for namespace,props,cls in groups_to_save:
        old=original.setdefault(namespace,{})
        old.update({k:getattr(props,k) for k in DATA['groups'][cls]})
    tmp=file.with_suffix('.json.'+str(os.getpid())+'.part')
    tmp.write_text(json.dumps(original,ensure_ascii=False,indent=2)+'\n','utf8');os.replace(tmp,file)
@bpy.app.handlers.persistent
def restore_after_load(_):
    # Scene values in the opened .blend take precedence over unrelated previous scenes.
    if bpy.context.scene and not bpy.context.scene.get('smart_geometry_suite_debris'):read(bpy.context)
def flush():
    if getattr(bpy.context,'scene',None):write(bpy.context)
    return None
def changed(self,ctx):
    if LOADING or not ctx or not getattr(ctx,'scene',None):return
    settings=getattr(ctx.window_manager,'smart_geometry_suite_settings',None)
    if settings and not settings.n_panel_state_save:
        if bpy.app.timers.is_registered(flush):bpy.app.timers.unregister(flush)
    elif not location().is_file():write(ctx)
    elif not bpy.app.timers.is_registered(flush):bpy.app.timers.register(flush,first_interval=.3)
def bootstrap():
    if getattr(bpy.context,'scene',None):read(bpy.context)
    return None
def register():
    if not bpy.app.timers.is_registered(bootstrap):bpy.app.timers.register(bootstrap,first_interval=.05)
    if restore_after_load not in bpy.app.handlers.load_post:bpy.app.handlers.load_post.append(restore_after_load)
def unregister():
    if restore_after_load in bpy.app.handlers.load_post:bpy.app.handlers.load_post.remove(restore_after_load)
    if bpy.app.timers.is_registered(flush) and getattr(bpy.context,'scene',None):write(bpy.context)
    for callback in (bootstrap,flush):
        if bpy.app.timers.is_registered(callback):bpy.app.timers.unregister(callback)
