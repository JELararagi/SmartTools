# Third-party notices / 第三者のソフトウェアの表示

This add-on is licensed under GPL-3.0-or-later. Parts of it are derived from the software listed below; their copyright holders and licenses are kept here.
このアドオンは GPL-3.0-or-later です。一部は次のソフトウェアに由来します。元の著作権者とライセンスをここに残します。

## extra_curve_objectes
- Origin / 出どころ: extensions.blender.org: extra_curve_objectes — https://projects.blender.org/extensions/add_curve_extra_objects
- Copyright / 著作権者: Community
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - grease_mesh/operators/knife_cut.py

## blender org (vrm)
- Origin / 出どころ: extensions.blender.org: vrm — https://vrm-addon-for-blender.info
- Copyright / 著作権者: Isamu Mogi <dyob@lunaport.net>
- License / ライセンス: MIT
- Derived files in this add-on / 由来の部品:
  - grease_mesh/operators/screw_mesh.py

## pose_library
- Origin / 出どころ: Blender 5.1 bundled add-on (scripts/addons_core/pose_library)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - __init__.py

## bl_ui
- Origin / 出どころ: Blender 5.1 bundled startup scripts (scripts/startup/bl_ui)
- Copyright / 著作権者: Blender Foundation / Blender Authors
- License / ライセンス: GPL-2.0-or-later
- Derived files in this add-on / 由来の部品:
  - grease_mesh/operators/add_gpencil.py

## storytools (storytools_3_3_2_evidence)
- Origin / 出どころ: storytools (public upstream source) — https://github.com/Pullusb/storytools
- Copyright / 著作権者: Samuel Bernou <bernou.samuel@gmail.com>
- License / ライセンス: GPL-3.0-or-later
- Derived files in this add-on / 由来の部品:
  - grease_mesh/operators/array_on_curve.py
