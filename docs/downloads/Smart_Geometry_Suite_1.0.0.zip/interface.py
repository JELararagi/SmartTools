"""Artist-facing controls for the current editor and active procedural object."""
import bpy
import bpy.utils.previews
from pathlib import Path
from . import catalog
from .max_procedural_primitives import runtime
ICONS=None
def load_icons():
    global ICONS
    if ICONS:bpy.utils.previews.remove(ICONS)
    ICONS=bpy.utils.previews.new()
    for p in (Path(__file__).with_name('icons')).glob('*.png'):ICONS.load(p.stem,str(p),'IMAGE')
def unload_icons():
    global ICONS
    if ICONS is not None:bpy.utils.previews.remove(ICONS);ICONS=None
def help_button(layout,ctx,key='s1'):
    p=layout.operator('smart_geometry_suite.open_help',text='',icon='QUESTION',emboss=False);p.help_key=key
def heading(layout,ctx,settings,key,en,ja,icon):
    row=layout.row(align=True);flag=getattr(settings,key)
    button=row.operator('smart_geometry_suite.toggle_ui_section',text=catalog.text(en,ja,ctx),icon='TRIA_DOWN' if flag else 'TRIA_RIGHT',emboss=False);button.section_key=key;button.label=en
    help_button(row,ctx,{'ui_section_terrain_generators':'f3','ui_section_distribution_generators':'f4','ui_section_structure_surface_generators':'f5','ui_section_organic_stroke_generators':'f6','ui_section_debris_fragment_generators':'f7','ui_section_attribute_visual_generators':'f9','ui_section_primitive_generators':'f8'}.get(key,'s1'))
    if flag:return layout.box()
    return None
def action(layout,key,en,ja,ctx,icon=None):
    kw={'text':catalog.text(en,ja,ctx)}
    if icon and ICONS and icon in ICONS:kw['icon_value']=ICONS[icon].icon_id
    return layout.operator('smart_geometry_suite.'+key,**kw)
class MainPanel:
    bl_label='Smart Geometry'
    bl_category='Smart Geometry'
    def draw_header(self,ctx):
        self.layout.label(text='',icon='GEOMETRY_NODES')
    def draw_header_preset(self,ctx):help_button(self.layout,ctx)
    @classmethod
    def poll(cls,ctx):
        try:
            import sys
            for addon in ctx.preferences.addons:
                if addon.module.rsplit('.',1)[-1]=='smart_tools_manager':
                    manager=sys.modules.get(addon.module+'.manager')
                    if manager:return bool(manager.panel_rule_allows_context('SMART_GEOMETRY',ctx,manager.logical_editor_key_from_context(ctx)))
        except (ImportError,AttributeError):pass
        return True
    def draw(self,ctx):
        s=ctx.window_manager.smart_geometry_suite_settings;layout=self.layout
        box=heading(layout,ctx,s,'ui_section_quick_start','Quick start','はじめに','dashboard_command_deck')
        if box:
            box.prop(s,'precision_preset',text=catalog.text('Quality','品質',ctx));action(box,'apply_precision_preset','Apply quality preset','品質を適用',ctx)
        sections=[
            ('terrain_generators','Terrain and drainage','地形 / 環境生成',[('create_terrain','Create precision terrain','高精度地形を作成','terrain_hydrology'),('create_flow_network','Trace drainage','排水カーブを作成','flow_network')],['terrain_resolution','terrain_size','terrain_height','random_seed','terrain_hydraulic_droplets','terrain_hydraulic_iterations']),
            ('distribution_generators','Surface distribution','表面に点を散布',[('create_scatter_points','Distribute points','表面に点を散布','scatter_distribution'),('relax_distribution_points','Even out spacing','点の間隔をそろえる','relax_distribution'),('create_distribution_proxy_instances','Show distribution proxies','確認用の四角すいを作成','scatter_distribution'),('import_csv_points','Read point CSV','CSVから点を読込','csv_points')],['scatter_count','scatter_min_spacing','scatter_radius']),
            ('structure_surface_generators','Structures and surfaces','建物・表面生成',[('create_building_proxy','Build a modular structure','モジュール建物を作成','modular_structure'),('create_greeble_blocks','Panelize the surface','表面にパネルを作成','surface_greeble')],['structure_floors']),
            ('organic_stroke_generators','Organic growth and strokes','有機成長・手描き',[('create_ivy_curve','Grow climbing curves','蔦のカーブを作成','organic_growth')],['growth_branches']),
            ('debris_fragment_generators','Debris and fragments','デブリ・破片',[('debris_generate','Generate debris','デブリを作成','fragment_interlock'),('explode_mesh_to_pieces','Separate into pieces','面を破片に分ける','fragment_interlock')],['fragment_piece_count']),
            ('attribute_visual_generators','Fields and selection','属性・選択',[('add_standard_attributes','Write geometry attributes','形状属性を書き込む','attribute_field'),('apply_selection_string','Apply selection expression','選択文字列を適用','selection_logic'),('create_attribute_heatmap','Show heatmap','ヒートマップ表示','attribute_heatmap'),('create_attribute_snapshot','Snapshot attributes','属性の複製を作成','attribute_snapshot')],['selection_string','debug_attribute'])]
        for key,en,ja,items,props in sections:
            box=heading(layout,ctx,s,'ui_section_'+key,en,ja,items[0][3])
            if not box:continue
            if key=='debris_fragment_generators':box.prop(ctx.scene.smart_geometry_suite_debris,'module',text=catalog.text('Module','種類',ctx));box.operator('smart_geometry_suite.debris_open_window',text=catalog.text('Debris settings','デブリ設定',ctx))
            for prop in props:
                label={'terrain_resolution':('Grid resolution','格子解像度'),'terrain_size':('Width','地形の幅'),'terrain_height':('Height','地形の高さ'),'random_seed':('Seed','シード'),'terrain_hydraulic_droplets':('Hydraulic droplets','水滴数'),'terrain_hydraulic_iterations':('Hydraulic iterations','流水の反復回数'),'scatter_count':('Points','点の数'),'scatter_min_spacing':('Spacing','最小間隔'),'scatter_radius':('Proxy radius','四角すいの半径')}.get(prop)
                if label:box.prop(s,prop,text=catalog.text(*label,ctx))
                else:box.prop(s,prop)
            for name,en,ja,icon in items:action(box,name,en,ja,ctx,icon)
            if key=='organic_stroke_generators':
                for name in ('add_gpencil','gn_solid_mesh','gn_mirror_mesh','gn_path_mesh','gn_wall_mesh','screw_mesh','array_on_curve','lattice_wrap','stamp_scatter','bool_cut','knife_cut','apply_all_modifiers'):box.operator('gptools.'+name)
        box=heading(layout,ctx,s,'ui_section_primitive_generators','Editable primitives','編集可能な基本形状','modular_structure')
        if box:
            box.menu('JELMAX_MT_add_root',text=catalog.text('Add a primitive','基本形状を追加',ctx))
            row=box.row(align=True)
            for gen,en,ja in (('standard_box','Box','ボックス'),('standard_sphere','Sphere','球'),('standard_cylinder','Cylinder','円柱'),('aec_wall','Wall','壁')):row.operator('jel_max.draw_generator',text=catalog.text(en,ja,ctx)).generator_id=gen
            box.operator('jel_max.update_selected')
        box=heading(layout,ctx,s,'ui_section_feature_catalog','Geometry capsules','機能カタログ','capsule_stack')
        if box:
            for prop in ('feature_category','source_filter','search_filter','active_feature','active_pack'):box.prop(s,prop)
            for name in ('apply_feature','apply_pack','create_node_library'):box.operator('smart_geometry_suite.'+name)
        box=heading(layout,ctx,s,'ui_section_settings','Settings and reports','設定・レポート','diagnostics_inspection')
        if box:
            box.prop(s,'n_panel_state_save')
            for name in ('open_visual_reference','refresh_diagnostics','export_inventory','export_diagnostics','export_bundle_manifest','export_usd_manifest','export_design_coverage','export_icon_reference_sheet'):box.operator('smart_geometry_suite.'+name)
        box=heading(layout,ctx,s,'ui_section_always_on','Optional automatic tools','常時機能切り替え','automation_script')
        if box:
            for k in s.bl_rna.properties.keys():
                if k.startswith('always_on_'):box.prop(s,k)
        from . import advanced_ui
        advanced_ui.draw(layout,ctx,s,heading,action)
class ModifierPanel:
    bl_context='modifier';bl_label='Max Primitives'
    @classmethod
    def poll(cls,ctx):return runtime.is_owned_parametric_object(ctx.active_object)
    def draw_header_preset(self,ctx):help_button(self.layout,ctx)
    def draw(self,ctx):
        ob=ctx.active_object;m=runtime.modifier(ob)
        if not m:return
        for k,p in runtime.decode(ob,'jel_max_socket_map').items():
            if p in m:self.layout.prop(m,'["'+p+'"]',text=k.replace('_',' ').title())
        self.layout.operator('jel_max.update_selected')
class AddMenu:
    def draw(self,ctx):
        if self.bl_idname=='JELMAX_MT_add_root':
            for category in dict.fromkeys(v['category'] for v in runtime.GENERATOR_SPECS.values()):self.layout.menu('JELMAX_MT_'+category)
        else:
            key=self.bl_idname.removeprefix('JELMAX_MT_')
            for k,s in runtime.GENERATOR_SPECS.items():
                if s['category']==key:self.layout.operator('jel_max.draw_generator',text=runtime.NAMES[k]).generator_id=k
def add_menu(self,ctx):self.layout.menu('JELMAX_MT_add_root')
