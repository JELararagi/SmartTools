# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Lightweight RNA bridges for the integrated Max and Grease feature groups.

Only these compact classes are imported and registered during Suite startup.  The
large implementation modules, primitive specifications, mesh generators, teapot
data, and Grease operator modules are imported on the first explicit command/menu
use, then released at load-pre, suspend, or unregister boundaries.
"""

import importlib
import sys
from typing import Any

import bpy

from . import ownership

_LOADED: dict[str, Any] = {}

_KNOWN_DEPENDENCIES = {
    'max_procedural_primitives.operators': (
        'max_procedural_primitives',
        'max_procedural_primitives.operators',
        'max_procedural_primitives.asset_utils',
        'max_procedural_primitives.runtime',
        'max_procedural_primitives.specs',
        'max_procedural_primitives.node_interface',
        'max_procedural_primitives.mesh_generators',
        'max_procedural_primitives.teapot_data',
    ),
    'max_procedural_primitives.modifier_ui': (
        'max_procedural_primitives',
        'max_procedural_primitives.modifier_ui',
        'max_procedural_primitives.node_interface',
        'max_procedural_primitives.specs',
    ),
}


def _known_module_names(relative_name: str) -> tuple[str, ...]:
    if relative_name.startswith('grease_mesh.'):
        return (
            'grease_mesh',
            'grease_mesh.operators',
            relative_name,
            'grease_mesh.utils',
            'grease_mesh.utils.conversion',
        )
    return _KNOWN_DEPENDENCIES.get(relative_name, (relative_name,))


def _load(relative_name: str):
    name = f"{__package__}.{relative_name}"
    module = _LOADED.get(name)
    if module is None or sys.modules.get(name) is not module:
        module = importlib.import_module(name)
        _LOADED[name] = module
        ledger = ownership.shared_ledger()
        if ledger is not None:
            # Record only explicit known module identities; no package-wide scan.
            for relative in _known_module_names(relative_name):
                candidate = sys.modules.get(f"{__package__}.{relative}")
                if candidate is not None:
                    ownership.record_lazy_module(ledger, candidate)
    return module


def release_lazy_implementations() -> None:
    _LOADED.clear()


def _implementation(relative_name: str, class_name: str):
    return getattr(_load(relative_name), class_name)


def _report_cancelled(instance, exc: BaseException | None = None):
    try:
        from . import catalog
        text = catalog.failure_text("The command could not be completed", "コマンドを完了できませんでした", exc)
        instance.report({"ERROR"}, text[:512])
    except Exception:
        pass
    return {"CANCELLED"}


def _delegate(instance, relative_name: str, class_name: str, method_name: str, *args):
    if not ownership.runtime_active_for_generation():
        return {"CANCELLED"}
    try:
        method = getattr(_implementation(relative_name, class_name), method_name)
        result = method(instance, *args)
        return result if isinstance(result, set) else {"CANCELLED"}
    except Exception as exc:
        return _report_cancelled(instance, exc)


def _delegate_helper(instance, relative_name: str, class_name: str, method_name: str, *args, **kwargs):
    """Invoke an implementation helper on the registered lightweight bridge."""
    method = getattr(_implementation(relative_name, class_name), method_name)
    return method(instance, *args, **kwargs)


def _delegate_draw(instance, relative_name: str, class_name: str, context) -> None:
    try:
        getattr(_implementation(relative_name, class_name), "draw")(instance, context)
    except Exception:
        try:
            from . import catalog
            instance.layout.label(text=catalog.text("Smart Geometry command data is unavailable.", "Smart Geometry のコマンドのデータを読み込めません。"), icon="ERROR")
        except Exception:
            pass


def _active_gp(context):
    active = getattr(context, "active_object", None)
    if getattr(active, "type", None) == "GREASEPENCIL":
        return active
    try:
        for obj in getattr(context, "selected_objects", ()) or ():
            if getattr(obj, "type", None) == "GREASEPENCIL":
                return obj
    except Exception:
        pass
    return None


def _selected_meshes(context):
    try:
        return tuple(obj for obj in getattr(context, "selected_objects", ()) or () if getattr(obj, "type", None) == "MESH")
    except Exception:
        return ()


def _object_mode_runtime_poll(context) -> bool:
    try:
        return bool(
            ownership.runtime_active_for_generation()
            and str(getattr(context, "mode", "") or "") in {"", "OBJECT"}
        )
    except Exception:
        return False


def _is_exact_max_object(obj) -> bool:
    ledger = ownership.shared_ledger()
    if obj is None or not ownership.ledger_is_exact(ledger):
        return False
    try:
        return ownership.saved_data_is_owned(obj) and bool(obj.get('jel_max_generator_id'))
    except Exception:
        return False


class JELMAX_OT_add_generator(bpy.types.Operator):
    bl_idname = "jel_max.add_generator"
    bl_label = "Add Max Primitive"
    bl_description = "Creates a parametric object with its controls exposed on a Geometry Nodes modifier. The object remains editable through the modifier properties."
    bl_options = {"UNDO"}

    generator_id: bpy.props.StringProperty(
        name="Generator ID",
        description="Internal identifier of the procedural primitive generator to create.",
        default="standard_box",
    )

    @classmethod
    def poll(cls, context):
        return _object_mode_runtime_poll(context)

    def execute(self, context):
        return _delegate(self, "max_procedural_primitives.operators", "JELMAX_OT_add_generator", "execute", context)


class JELMAX_OT_draw_generator(bpy.types.Operator):
    bl_idname = "jel_max.draw_generator"
    bl_label = "Drag Max Primitive"
    bl_description = "Creates a Max Primitive by 3ds Max style viewport dragging. Click-drag on the construction plane to set the base or radius; primitives with height use a second drag for height."
    bl_options = {"UNDO"}

    generator_id: bpy.props.StringProperty(
        name="Generator ID",
        description="Internal identifier of the procedural primitive generator to create by viewport drag.",
        default="standard_box",
    )

    # Modal state is kept on the Blender-registered bridge instance. Helper
    # methods are forwarded on demand, so the heavy implementation module can be
    # released after the modal finishes instead of being retained by bound
    # function references on the RNA class.
    _obj = None
    _start = None
    _current = None
    _stage = "await"
    _plane_z = 0.0
    _height_start_y = 0.0
    _height_dragging = False
    _origin = None
    _u_axis = None
    _v_axis = None
    _n_axis = None
    _window_region = None
    _rv3d = None
    _last_valid_point = None
    _height_button_down = False
    _height_moved = False
    _sgs_modal_token = None
    _sgs_modal_context = None
    _sgs_draw_handle = None
    _sgs_event_timer = None
    _sgs_drag_active = False
    _sgs_pending_data = None
    _sgs_cleanup_ok = False

    def _project_event_point(self, context, event):
        return _delegate_helper(self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator", "_project_event_point", context, event)

    def _end_drag_once(self):
        if not bool(getattr(self, "_sgs_drag_active", False)):
            return True
        runtime_module = sys.modules.get(f"{__package__}.max_procedural_primitives.runtime")
        callback = getattr(runtime_module, "end_interactive_drag", None) if runtime_module is not None else None
        if callable(callback):
            try:
                callback()
            except Exception:
                return False
        self._sgs_drag_active = False
        return True

    def _remove_modal_resources(self, context=None):
        ok = True
        handle = getattr(self, "_sgs_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
                self._sgs_draw_handle = None
            except Exception:
                ok = False
        timer = getattr(self, "_sgs_event_timer", None)
        if timer is not None:
            modal_context = getattr(self, "_sgs_modal_context", None)
            wm = getattr(context, "window_manager", None) or getattr(modal_context, "window_manager", None)
            try:
                if wm is None:
                    ok = False
                else:
                    wm.event_timer_remove(timer)
                    self._sgs_event_timer = None
            except Exception:
                ok = False
        return ok

    @staticmethod
    def _remove_generated_object(obj):
        if obj is None:
            return True
        ledger = ownership.shared_ledger()
        if not ownership.ledger_is_exact(ledger):
            return False
        try:
            exact = bool(
                obj.get("jelararagi_sgs_owner_suite") == ownership.SUITE_ID
                and obj.get("jelararagi_sgs_owner_revision") == ownership.REVISION
                and obj.get("jelararagi_sgs_owner_generation") == str(ledger.get("generation") or "")
                and bool(obj.get("jel_max_generator_id"))
            )
        except Exception:
            exact = False
        if not exact:
            return False
        data = getattr(obj, "data", None)
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            return False
        if data is None:
            return True
        try:
            if int(getattr(data, "users", 0)) != 0:
                return True
            if isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)
            elif isinstance(data, bpy.types.Curve):
                bpy.data.curves.remove(data)
        except Exception:
            return False
        return True

    def _remove_generated_state(self):
        obj = getattr(self, "_obj", None)
        if obj is not None:
            data = getattr(obj, "data", None)
            if not self._remove_generated_object(obj):
                try:
                    if bpy.data.objects.get(str(getattr(obj, "name", ""))) is obj:
                        return False
                except Exception:
                    return False
                self._obj = None
                self._sgs_pending_data = data
            else:
                self._obj = None
        data = getattr(self, "_sgs_pending_data", None)
        if data is None:
            return True
        try:
            if int(getattr(data, "users", 0)) != 0:
                return False
            if isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)
            elif isinstance(data, bpy.types.Curve):
                bpy.data.curves.remove(data)
            self._sgs_pending_data = None
            return True
        except Exception:
            return False

    def _finish(self, context):
        return _delegate_helper(self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator", "_finish", context)

    def _cancel(self, context, *, reason="cancelled"):
        try:
            return _delegate_helper(
                self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator",
                "_cancel", context, reason=reason,
            )
        except Exception:
            # Last-resort exact cleanup must leave no active modal lease.
            resources_ok = False
            drag_ok = False
            object_ok = False
            try:
                resources_ok = bool(self._remove_modal_resources(context))
            except Exception:
                pass
            try:
                drag_ok = bool(self._end_drag_once())
            except Exception:
                pass
            try:
                object_ok = bool(self._remove_generated_state())
            except Exception:
                pass
            self._sgs_cleanup_ok = resources_ok and drag_ok and object_ok
            if self._sgs_cleanup_ok:
                ownership.finish_modal(self)
                self._sgs_modal_token = None
            return {"CANCELLED"}

    def _modal_impl(self, context, event):
        return _delegate_helper(self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator", "_modal_impl", context, event)

    @classmethod
    def poll(cls, context):
        return _object_mode_runtime_poll(context)

    def execute(self, context):
        return _delegate(self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator", "execute", context)

    def invoke(self, context, event):
        return _delegate(self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator", "invoke", context, event)

    def modal(self, context, event):
        try:
            return _delegate_helper(self, "max_procedural_primitives.operators", "JELMAX_OT_draw_generator", "modal", context, event)
        except Exception:
            return self._cancel(context, reason="bridge_modal_exception")

    def cancel(self, context):
        return self._cancel(context, reason="blender_cancel")


class JELMAX_OT_install_assets(bpy.types.Operator):
    bl_idname = "jel_max.install_assets"
    bl_label = "Install Max Primitive Assets"
    bl_description = "Builds procedural primitive assets, writes them to the user asset library, and registers the library in Blender preferences. This external-file and Preferences operation is not placed on Blender's scene Undo stack."
    bl_options = set()

    @classmethod
    def poll(cls, context):
        del context
        return ownership.runtime_active_for_generation()

    def execute(self, context):
        return _delegate(self, "max_procedural_primitives.operators", "JELMAX_OT_install_assets", "execute", context)


class JELMAX_OT_update_selected(bpy.types.Operator):
    bl_idname = "jel_max.update_selected"
    bl_label = "Update Selected Max Primitive"
    bl_description = "Forces regeneration of the selected Max Primitive from the current Geometry Nodes modifier values."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        try:
            return _object_mode_runtime_poll(context) and _is_exact_max_object(obj)
        except Exception:
            return False

    def execute(self, context):
        return _delegate(self, "max_procedural_primitives.operators", "JELMAX_OT_update_selected", "execute", context)


class JELMAX_OT_update_all(bpy.types.Operator):
    bl_idname = "jel_max.update_all"
    bl_label = "Update All Max Primitives"
    bl_description = "Forces regeneration of every Max Primitive object in the current file."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        return _object_mode_runtime_poll(context)

    def execute(self, context):
        return _delegate(self, "max_procedural_primitives.operators", "JELMAX_OT_update_all", "execute", context)


_MAX_CATEGORIES = (
    ("standard", "Standard Primitives"),
    ("extended", "Extended Primitives"),
    ("aec", "AEC Extended"),
    ("doors", "Doors"),
    ("windows", "Windows"),
    ("stairs", "Stairs"),
    ("patch_nurbs", "Patch / NURBS Surfaces"),
    ("compound", "Compound Objects"),
)


class _JELMAX_Category_Menu_Base(bpy.types.Menu):
    _category_id = ""

    def draw(self, context):
        try:
            module = _load("max_procedural_primitives.operators")
            target = getattr(module, "CATEGORY_MENU_BY_ID", {}).get(self._category_id)
            if target is not None:
                target.draw(self, context)
                return
        except Exception:
            pass
        from . import catalog
        self.layout.label(text=catalog.text("Primitive definitions are unavailable.", "プリミティブの定義を読み込めません。"), icon="ERROR")


def _category_menu_class(category_id: str, label: str):
    name = f"JELMAX_MT_{category_id}"
    return type(
        name,
        (_JELMAX_Category_Menu_Base,),
        {
            "__module__": __name__,
            "bl_idname": name,
            "bl_label": label,
            "bl_description": label,
            "_category_id": category_id,
        },
    )


JELMAX_MT_standard = _category_menu_class("standard", "Standard Primitives")
JELMAX_MT_extended = _category_menu_class("extended", "Extended Primitives")
JELMAX_MT_aec = _category_menu_class("aec", "AEC Extended")
JELMAX_MT_doors = _category_menu_class("doors", "Doors")
JELMAX_MT_windows = _category_menu_class("windows", "Windows")
JELMAX_MT_stairs = _category_menu_class("stairs", "Stairs")
JELMAX_MT_patch_nurbs = _category_menu_class("patch_nurbs", "Patch / NURBS Surfaces")
JELMAX_MT_compound = _category_menu_class("compound", "Compound Objects")
JELMAX_MT_shape_splines = _category_menu_class("shape_splines", "Shapes / Splines")
JELMAX_MT_shape_nurbs = _category_menu_class("shape_nurbs", "Shapes / NURBS Curves")
JELMAX_MT_shape_extended = _category_menu_class("shape_extended", "Shapes / Extended Splines")


class JELMAX_MT_add_root(bpy.types.Menu):
    bl_idname = "JELMAX_MT_add_root"
    bl_label = "Max Primitives"
    bl_description = "Max Primitive objects created as Blender Geometry Nodes modifier assets."

    def draw(self, context):
        _delegate_draw(self, "max_procedural_primitives.operators", "JELMAX_MT_add_root", context)


def max_add_menu_draw(self, context):
    del context
    try:
        self.layout.separator()
        self.layout.menu("JELMAX_MT_add_root", text="Max Primitives")
    except Exception:
        pass


class JELMAX_OT_refresh_selected(bpy.types.Operator):
    bl_idname = "jel_max.refresh_selected"
    bl_label = "Refresh Max Primitive"
    bl_description = "Applies the current Max Primitive modifier values to the generated mesh immediately."
    bl_options = {"UNDO"}

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        try:
            return _object_mode_runtime_poll(context) and _is_exact_max_object(obj)
        except Exception:
            return False

    def execute(self, context):
        return _delegate(self, "max_procedural_primitives.modifier_ui", "JELMAX_OT_refresh_selected", "execute", context)


class JELMAX_PT_modifier_active_controls(bpy.types.Panel):
    bl_idname = "JELMAX_PT_modifier_active_controls"
    bl_label = "Max Primitives Parameters"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "modifier"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        try:
            return ownership.runtime_active_for_generation() and _is_exact_max_object(obj)
        except Exception:
            return False

    def draw_header(self, context):
        try:
            impl = _implementation("max_procedural_primitives.modifier_ui", "JELMAX_PT_modifier_active_controls")
            callback = getattr(impl, "draw_header", None)
            if callable(callback):
                callback(self, context)
        except Exception:
            pass

    def draw_header_preset(self, context):
        op = self.layout.operator("smart_geometry_suite.open_help", text="", icon="QUESTION")
        op.help_key = "procedural_builders"

    def draw(self, context):
        _delegate_draw(self, "max_procedural_primitives.modifier_ui", "JELMAX_PT_modifier_active_controls", context)


class _GreaseBridgeBase:
    _implementation_module = ""
    _implementation_class = ""

    @classmethod
    def poll(cls, context):
        if not ownership.runtime_active_for_generation():
            return False
        mode = str(getattr(context, "mode", "") or "")
        if mode not in {"", "OBJECT"}:
            return False
        if cls._implementation_class == "GPTOOLS_OT_add_gpencil":
            return True
        gp = _active_gp(context)
        meshes = _selected_meshes(context)
        if cls._implementation_class == "GPTOOLS_OT_apply_all_modifiers":
            obj = getattr(context, "active_object", None)
            return bool(obj and getattr(obj, "type", None) in {"MESH", "GREASEPENCIL"} and getattr(obj, "modifiers", None))
        if cls._implementation_class == "GPTOOLS_OT_array_on_curve":
            return gp is not None and bool(meshes)
        if cls._implementation_class in {"GPTOOLS_OT_bool_cut", "GPTOOLS_OT_knife_cut"}:
            return gp is not None and any(obj is not gp for obj in meshes)
        if cls._implementation_class == "GPTOOLS_OT_lattice_wrap":
            active = getattr(context, "active_object", None)
            return bool(active and getattr(active, "type", None) == "MESH" and any(obj is not active for obj in meshes))
        return gp is not None

    def execute(self, context):
        return _delegate(self, self._implementation_module, self._implementation_class, "execute", context)


class GPTOOLS_OT_add_gpencil(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.add_gpencil"
    bl_label = "Add New Grease Pencil"
    bl_description = "Add a new Grease Pencil object for sketch-to-mesh generation."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.add_gpencil"
    _implementation_class = "GPTOOLS_OT_add_gpencil"


class GPTOOLS_OT_gn_solid_mesh(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.gn_solid_mesh"
    bl_label = "Solid Mesh (GN)"
    bl_description = "Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.gn_solid_mesh"
    _implementation_class = "GPTOOLS_OT_gn_solid_mesh"


class GPTOOLS_OT_gn_mirror_mesh(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.gn_mirror_mesh"
    bl_label = "Mirror Mesh (GN)"
    bl_description = "Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.gn_mirror_mesh"
    _implementation_class = "GPTOOLS_OT_gn_mirror_mesh"


class GPTOOLS_OT_gn_path_mesh(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.gn_path_mesh"
    bl_label = "Path Mesh (GN)"
    bl_description = "Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.gn_path_mesh"
    _implementation_class = "GPTOOLS_OT_gn_path_mesh"


class GPTOOLS_OT_gn_wall_mesh(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.gn_wall_mesh"
    bl_label = "Wall Mesh (GN)"
    bl_description = "Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.gn_wall_mesh"
    _implementation_class = "GPTOOLS_OT_gn_wall_mesh"


class GPTOOLS_OT_screw_mesh(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.screw_mesh"
    bl_label = "Create Screw Mesh"
    bl_description = "Create lathe-style screw mesh geometry from a Grease Pencil profile."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.screw_mesh"
    _implementation_class = "GPTOOLS_OT_screw_mesh"


class GPTOOLS_OT_lattice_wrap(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.lattice_wrap"
    bl_label = "Lattice Wrap"
    bl_description = "Create a lattice-based wrap helper around selected geometry."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.lattice_wrap"
    _implementation_class = "GPTOOLS_OT_lattice_wrap"


class GPTOOLS_OT_bool_cut(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.bool_cut"
    bl_label = "Bool Cut"
    bl_description = "Cut selected mesh geometry using Grease Pencil stroke shapes."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.bool_cut"
    _implementation_class = "GPTOOLS_OT_bool_cut"

    cut_depth: bpy.props.FloatProperty(
        name="Cut Depth", default=10.0, min=0.01, max=1000.0,
        description="Thickness of the cutter volume; it must exceed the target mesh thickness.",
    )
    resolution: bpy.props.IntProperty(
        name="Resolution", default=64, min=8, max=512,
        description="Number of points used to resample the cut shape.",
    )

    def invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_props_dialog(self)
        except Exception:
            return {"CANCELLED"}


class GPTOOLS_OT_array_on_curve(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.array_on_curve"
    bl_label = "Array on Curve"
    bl_description = "Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.array_on_curve"
    _implementation_class = "GPTOOLS_OT_array_on_curve"


class GPTOOLS_OT_apply_all_modifiers(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.apply_all_modifiers"
    bl_label = "Apply All Modifiers"
    bl_description = "Apply all modifiers on the active Grease Mesh result to create editable mesh data."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.apply_modifiers"
    _implementation_class = "GPTOOLS_OT_apply_all_modifiers"


class GPTOOLS_OT_stamp_scatter(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.stamp_scatter"
    bl_label = "Stamp Scatter"
    bl_description = "Scatter stamped mesh instances from Grease Pencil stroke input."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.stamp_scatter"
    _implementation_class = "GPTOOLS_OT_stamp_scatter"


class GPTOOLS_OT_knife_cut(_GreaseBridgeBase, bpy.types.Operator):
    bl_idname = "gptools.knife_cut"
    bl_label = "Knife Cut"
    bl_description = "Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing."
    bl_options = {"UNDO"}
    _implementation_module = "grease_mesh.operators.knife_cut"
    _implementation_class = "GPTOOLS_OT_knife_cut"

    cut_through: bpy.props.BoolProperty(
        name="Cut Through", default=False,
        description="Cut through the entire mesh instead of only the visible surface.",
    )
    resolution: bpy.props.IntProperty(
        name="Resolution", default=0, min=0, max=512,
        description="Resample strokes to this many points; zero uses the original points.",
    )

    def invoke(self, context, event):
        del event
        try:
            return context.window_manager.invoke_props_dialog(self)
        except Exception:
            return {"CANCELLED"}


MAX_CLASSES = (
    JELMAX_OT_add_generator,
    JELMAX_OT_draw_generator,
    JELMAX_OT_install_assets,
    JELMAX_OT_update_selected,
    JELMAX_OT_update_all,
    JELMAX_MT_standard,
    JELMAX_MT_extended,
    JELMAX_MT_aec,
    JELMAX_MT_doors,
    JELMAX_MT_windows,
    JELMAX_MT_stairs,
    JELMAX_MT_patch_nurbs,
    JELMAX_MT_compound,
    JELMAX_MT_shape_splines,
    JELMAX_MT_shape_nurbs,
    JELMAX_MT_shape_extended,
    JELMAX_MT_add_root,
    JELMAX_OT_refresh_selected,
    JELMAX_PT_modifier_active_controls,
)

GREASE_CLASSES = (
    GPTOOLS_OT_add_gpencil,
    GPTOOLS_OT_gn_solid_mesh,
    GPTOOLS_OT_gn_mirror_mesh,
    GPTOOLS_OT_gn_path_mesh,
    GPTOOLS_OT_gn_wall_mesh,
    GPTOOLS_OT_screw_mesh,
    GPTOOLS_OT_lattice_wrap,
    GPTOOLS_OT_bool_cut,
    GPTOOLS_OT_array_on_curve,
    GPTOOLS_OT_apply_all_modifiers,
    GPTOOLS_OT_stamp_scatter,
    GPTOOLS_OT_knife_cut,
)

CLASSES = MAX_CLASSES + GREASE_CLASSES
