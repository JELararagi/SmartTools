"""On-demand helpers and scene transitions. Only generated helper objects are eligible for cleanup."""
from mathutils import Matrix,Vector
from bpy.app.handlers import persistent
from bpy_extras.object_utils import world_to_camera_view
import bpy
from . import geometry_fields as fields,capsules,catalog,preferences_store
def config(ctx):return getattr(ctx.window_manager,'smart_geometry_suite_settings',None)
def inspect(obj):
    return dict(name=obj.name,vertices=len(obj.data.vertices),faces=len(obj.data.polygons),attributes=len(obj.data.attributes),modifiers=len(obj.modifiers))
def visibility(ctx,obj):
    camera=ctx.scene.camera
    if not camera or obj.type!='MESH':return
    values=[]
    for v in obj.data.vertices:
        ndc=world_to_camera_view(ctx.scene,camera,obj.matrix_world@v.co);values.append(float(ndc.z>0 and 0<=ndc.x<=1 and 0<=ndc.y<=1))
    fields.write(obj.data,'sgs_visibility','FLOAT',values)
def on_action(ctx,which):
    s=config(ctx)
    if not s or not ctx.active_object:return
    obj=ctx.active_object
    if obj.type=='MESH':
        if s.always_on_live_attribute_guard and not obj.data.attributes.get('sgs_density'):fields.point_fields(obj,s,'create_greeble_blocks')
        if s.always_on_live_camera_visibility_gate:visibility(ctx,obj)
        if s.always_on_live_selection_sync:
            attr=obj.data.attributes.get('sgs_selection')
            if attr and attr.domain=='POINT':
                fields.write(obj.data,'sgs_selection',attr.data_type,[int(v.select) for v in obj.data.vertices])
        if s.always_on_live_mesh_inspector:
            import json
            ctx.window_manager['sgs_inspector_result']=json.dumps(inspect(obj))
    if s.always_on_node_library_guard and which in ('apply_feature','apply_pack','build_library'):
        capsules.tree(ctx,s.active_feature)
def clean(ctx,s):
    if s.always_on_automatic_proxy_cleanup:
        for ob in tuple(ctx.scene.objects):
            if ob.get('jelararagi_sgs_owner_suite')=='smart_geometry_suite' and ob.get('sgs_transient_proxy'):bpy.data.objects.remove(ob,do_unlink=True)
@persistent
def before_save(_):
    ctx=bpy.context;s=config(ctx)
    if not s:return
    clean(ctx,s)
    if ctx.scene:
        for ob in ctx.scene.objects:
            if not ob.get('smart_geometry_suite_generated'):continue
            if s.always_on_transform_snapshot_restore:ob['sgs_saved_world_transform']=[x for row in ob.matrix_world for x in row]
            if s.always_on_live_camera_visibility_gate:visibility(ctx,ob)
        if s.always_on_auto_diagnostics_snapshot:
            from .operations import report_export
            report_export(ctx,'export_diagnostics')
    preferences_store.write(ctx)
@persistent
def after_open(_):
    ctx=bpy.context;s=config(ctx)
    if not s or not ctx.scene:return
    clean(ctx,s)
    if s.always_on_transform_snapshot_restore:
        for ob in ctx.scene.objects:
            data=ob.get('sgs_saved_world_transform')
            if ob.get('smart_geometry_suite_generated') and data and len(data)==16:ob.matrix_world=Matrix([data[i:i+4] for i in range(0,16,4)])
def register():
    for bank,callback in ((bpy.app.handlers.save_pre,before_save),(bpy.app.handlers.load_post,after_open)):
        if callback not in bank:bank.append(callback)
def unregister():
    for bank,callback in ((bpy.app.handlers.save_pre,before_save),(bpy.app.handlers.load_post,after_open)):
        if callback in bank:bank.remove(callback)

