"""Attach RNA properties at their persisted owner and preserve stored enum ordinals."""
import json
from pathlib import Path
import bpy
from . import catalog
DATA=json.loads(Path(__file__).with_name('rna.json').read_text('utf8'))
classes={}
attached=[]
DYNAMIC={'feature_category':'category_items','source_filter':'source_items','active_feature':'feature_items','active_pack':'pack_items'}
def remember(item,context):
    from . import preferences_store
    preferences_store.changed(item,context)
def field(k,p,settings=False):
    desc={'name':k.replace('_',' ').title()}
    kind=p['type']
    if kind=='POINTER':return bpy.props.PointerProperty(type=classes[p['ref']],**desc)
    if p.get('subtype') not in ('NONE',None):desc['subtype']=p['subtype']
    if settings:desc['update']=remember
    if kind=='ENUM':
        if p['items']:desc['items']=[(ident,ident.replace('_',' ').title(),'',n) for ident,n in p['items']];desc['default']=p['default']
        else:desc['items']=lambda owner,context:catalog.labels(DYNAMIC[k],context)
        return bpy.props.EnumProperty(**desc)
    if 'min' in p:desc.update(min=p['min'],max=p['max'])
    desc['default']=p['default']
    return {'BOOLEAN':bpy.props.BoolProperty,'INT':bpy.props.IntProperty,'FLOAT':bpy.props.FloatProperty,'STRING':bpy.props.StringProperty}[kind](**desc)
def register():
    for name,props in DATA['groups'].items():
        c=type(name,(bpy.types.PropertyGroup,),{'__module__':__name__,'__annotations__':{k:field(k,p,True) for k,p in props.items()}})
        bpy.utils.register_class(c);classes[name]=c
    for owner,props in DATA['roots'].items():
        t=getattr(bpy.types,owner)
        for k,p in props.items():
            if hasattr(t,k):raise RuntimeError(k+' is already registered')
            setattr(t,k,field(k,p));attached.append((t,k))
def unregister():
    for t,k in reversed(attached):delattr(t,k)
    attached.clear()
    for c in reversed(tuple(classes.values())):bpy.utils.unregister_class(c)
    classes.clear()
def arguments(op):return {k:field(k,p) for k,p in DATA['operators'][op].items()}
