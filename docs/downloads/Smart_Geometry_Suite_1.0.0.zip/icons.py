# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

import shutil
from pathlib import Path

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None  # type: ignore

_PACKAGE_DIR = Path(__file__).resolve().parent
_ICON_DIRS = (
    _PACKAGE_DIR / 'icons',
)
_REFERENCE_DIR = _PACKAGE_DIR / 'assets' / 'references'
_VALIDATED_ICONS: set[str] = set()
_LAST_LOAD_ERRORS: dict[str, str] = {}


def _blender_version_tuple() -> tuple[int, int, int]:
    try:
        version = tuple(int(v) for v in getattr(getattr(bpy, 'app', None), 'version', (0, 0, 0))[:3]) if bpy is not None else (0, 0, 0)
        return (version + (0, 0, 0))[:3]
    except Exception:
        return (0, 0, 0)


def live_preview_icons_enabled() -> bool:
    """Return whether bpy.utils.previews icon IDs may be used in UI draw.

    Blender 5.1.0 crash reports show the native panel handler crashing during
    mode-switch redraw with custom preview icon IDs still present in panel
    widgets. For the 5.1 series this add-on keeps the PNG assets bundled for
    export/reference, but draws live UI with Blender standard icons only.
    """
    major, minor, _patch = _blender_version_tuple()
    if (major, minor) >= (5, 1):
        return False
    return True
_PREVIEW_ICON_RUNTIME_ENABLED = False
_PREVIEW_ICON_DISABLED_REASON = 'Blender 5.1 crash-safe mode: live bpy.utils.previews icon IDs are disabled; standard Blender icons are used in UI.'


def custom_preview_icons_supported() -> bool:
    """Return False for the Blender 5.1 crash-safe build.

    The bundled PNG assets remain available for exports and reference sheets,
    but live bpy.utils.previews icon IDs are not exposed to UI controls.
    """
    return bool(_PREVIEW_ICON_RUNTIME_ENABLED)


def custom_preview_disabled_reason() -> str:
    return str(_PREVIEW_ICON_DISABLED_REASON)

_ICON_FILES = {
    'logo': 'sgs_logo.png',
    'dashboard': 'dashboard_command_deck.png',
    'precision': 'precision_focus.png',
    'overdrive': 'precision_overdrive.png',
    'terrain': 'terrain_hydrology.png',
    'scatter': 'scatter_distribution.png',
    'relax': 'relax_distribution.png',
    'flow': 'flow_network.png',
    'greeble': 'surface_greeble.png',
    'fragment': 'fragment_interlock.png',
    'heatmap': 'attribute_heatmap.png',
    'attribute': 'attribute_field.png',
    'selection': 'selection_logic.png',
    'material': 'material_uv.png',
    'manifest': 'manifest_exchange.png',
    'quality': 'quality_guard.png',
    'diagnostics': 'diagnostics_inspection.png',
    'snapshot': 'attribute_snapshot.png',
    'csv': 'csv_points.png',
    'structure': 'modular_structure.png',
    'growth': 'organic_growth.png',
    'volume': 'volume_matter.png',
    'motion': 'motion_signal.png',
    'automation': 'automation_script.png',
    'capsule': 'capsule_stack.png',
    'utility': 'utility_operations.png',
    'workflow_reference': 'workflow_reference.png',
    'attribute_stack_reference': 'attribute_stack_reference.png',
    'precision_pipeline_reference': 'precision_pipeline_reference.png',
    'command_deck_reference': 'command_deck_reference.png',
    'icon_reference_sheet': 'icon_reference_sheet_v8.png',
}

_REFERENCE_IMAGE_KEYS = frozenset({
    'workflow_reference',
    'attribute_stack_reference',
    'precision_pipeline_reference',
    'command_deck_reference',
    'icon_reference_sheet',
})


_FALLBACK_ICONS = {
    'logo': 'GEOMETRY_NODES',
    'dashboard': 'WINDOW',
    'precision': 'VIEWZOOM',
    'overdrive': 'SOLO_ON',
    'terrain': 'MESH_GRID',
    'scatter': 'PARTICLES',
    'relax': 'MOD_PARTICLE_INSTANCE',
    'flow': 'CURVE_PATH',
    'greeble': 'MESH_CUBE',
    'fragment': 'MOD_EXPLODE',
    'heatmap': 'COLOR',
    'attribute': 'RNA',
    'selection': 'RESTRICT_SELECT_OFF',
    'material': 'MATERIAL',
    'manifest': 'EXPORT',
    'quality': 'CHECKMARK',
    'diagnostics': 'VIEWZOOM',
    'snapshot': 'DUPLICATE',
    'csv': 'FILE',
    'structure': 'HOME',
    'growth': 'CURVE_DATA',
    'volume': 'OUTLINER_OB_MESH',
    'motion': 'CURVE_DATA',
    'automation': 'TOOL_SETTINGS',
    'capsule': 'GEOMETRY_NODES',
    'utility': 'TOOL_SETTINGS',
    'workflow_reference': 'IMAGE_DATA',
    'attribute_stack_reference': 'IMAGE_DATA',
    'precision_pipeline_reference': 'IMAGE_DATA',
    'command_deck_reference': 'IMAGE_DATA',
    'icon_reference_sheet': 'IMAGE_DATA',
}


def fallback_icon(name: str, default: str = 'NONE') -> str:
    return _FALLBACK_ICONS.get(str(name or ''), default)


def bundled_icon_filenames(*, include_reference_images: bool = False) -> tuple[str, ...]:
    """Return bundled deduplicated icon filenames used by the UI."""
    names = {
        filename
        for key, filename in _ICON_FILES.items()
        if include_reference_images or key not in _REFERENCE_IMAGE_KEYS
    }
    return tuple(sorted(names))



def _case_insensitive_child(directory: Path, filename: str) -> Path | None:
    """Return a matching bundled file even if an archive tool changed case."""
    try:
        if not directory.exists() or not directory.is_dir():
            return None
        target = Path(filename).name.lower()
        for child in directory.iterdir():
            if child.name.lower() == target and child.is_file():
                return child
    except Exception:
        pass
    return None


def _find_icon(filename: str) -> Path | None:
    value = str(filename or '').strip().replace('\\', '/')
    if not value:
        return None
    raw = Path(value)
    candidates: list[Path] = []
    if raw.is_absolute():
        candidates.append(raw)
    else:
        # Button icons are bundled in icons/. Reference-strip images are
        # bundled in assets/references. Legacy icon PNGs are intentionally
        # not bundled so the deduplicated icon pack is the only icon source.
        candidates.extend((icon_dir / raw).resolve() for icon_dir in _ICON_DIRS)
        candidates.append((_PACKAGE_DIR / raw).resolve())
        candidates.append((_REFERENCE_DIR / raw.name).resolve())
    seen: set[str] = set()
    for path in candidates:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        try:
            if path.exists() and path.is_file():
                return path
        except Exception:
            pass
        found = _case_insensitive_child(path.parent, path.name)
        if found is not None:
            return found
    return None


def _new_preview_collection():
    # Blender 5.1 UI panel handling can crash natively when custom preview
    # icon_value handles are used across object/edit/sculpt mode switches.
    # Keep this compatibility hook as a no-op so older calls remain safe.
    return None


def _remove_preview_collection(pcoll) -> None:
    return None


def register_icons(force: bool = False) -> None:
    global _VALIDATED_ICONS, _LAST_LOAD_ERRORS
    del force
    validated: set[str] = set()
    errors: dict[str, str] = {}
    for name, filename in _ICON_FILES.items():
        if name in _REFERENCE_IMAGE_KEYS:
            continue
        path = _find_icon(filename)
        if path is None:
            errors[name] = f'file not found: {filename}'
            continue
        validated.add(name)
    _VALIDATED_ICONS = validated
    _LAST_LOAD_ERRORS = errors


def ensure_icons_loaded(force: bool = False) -> bool:
    register_icons(force=force)
    return bool(_VALIDATED_ICONS)


def unregister_icons() -> None:
    global _VALIDATED_ICONS, _LAST_LOAD_ERRORS
    _VALIDATED_ICONS = set()
    _LAST_LOAD_ERRORS = {}


def register(force: bool = False) -> None:
    register_icons(force=force)


def unregister() -> None:
    unregister_icons()


def icon_value(name: str, default: int = 0) -> int:
    # Live N-panel UI intentionally uses Blender standard icons in 5.1-safe
    # mode. The custom PNG files remain bundled and validated but are not
    # converted into custom preview icon IDs.
    return int(default or 0)


def available_icons() -> tuple[str, ...]:
    return tuple(sorted(_ICON_FILES))


def standard_icon(name: str, default: str = 'IMAGE_DATA') -> str:
    return str(_FALLBACK_ICONS.get(str(name or ''), default or 'IMAGE_DATA'))


def loaded_icon_count() -> int:
    if not _VALIDATED_ICONS:
        ensure_icons_loaded()
    return int(len(_VALIDATED_ICONS))


def missing_icons() -> dict[str, str]:
    ensure_icons_loaded()
    return dict(_LAST_LOAD_ERRORS)


def icon_file_path(name: str) -> Path | None:
    filename = _ICON_FILES.get(str(name or ''))
    if not filename:
        return None
    return _find_icon(filename)


def draw_preview(layout, name: str, *, scale: float = 4.0, fallback_icon: str = 'NONE') -> bool:
    del scale
    key = str(name or '')
    icon = _FALLBACK_ICONS.get(key, fallback_icon if fallback_icon != 'NONE' else 'IMAGE_DATA')
    try:
        layout.label(text='', icon=icon)
        return True
    except Exception:
        try:
            layout.label(text='', icon=fallback_icon if fallback_icon != 'NONE' else 'IMAGE_DATA')
        except Exception:
            pass
    return False


def _operator_label(operator_id: str) -> str:
    value = str(operator_id or '').strip()
    if bpy is not None and value and '.' in value:
        try:
            prefix, name = value.split('.', 1)
            op_group = getattr(bpy.ops, prefix, None)
            op_func = getattr(op_group, name, None) if op_group is not None else None
            get_rna_type = getattr(op_func, 'get_rna_type', None)
            if callable(get_rna_type):
                label = str(getattr(get_rna_type(), 'name', '') or '').strip()
                if label:
                    return label
        except Exception:
            pass
    return value.replace('_', ' ').replace('.', ' / ').title() if value else 'Run Command'


def operator(layout, operator_id: str, text: str, icon_name: str, *, fallback_icon: str = 'NONE', emboss: bool = True):
    fallback = 'GEOMETRY_NODES' if fallback_icon == 'MOD_NODES' else ('GEOMETRY_SET' if fallback_icon == 'OUTLINER_DATA_GEOMETRYSET' else fallback_icon)
    if fallback == 'NONE':
        fallback = _FALLBACK_ICONS.get(str(icon_name or ''), 'NONE')
    label = str(text or '').strip() or _operator_label(operator_id)
    try:
        return layout.operator(operator_id, text=label, icon=fallback, emboss=True)
    except TypeError:
        try:
            return layout.operator(operator_id, text=label, icon=fallback)
        except TypeError:
            return layout.operator(operator_id, text=label, icon='NONE')


def draw_large_button(layout, operator_id: str, text: str, icon_name: str, *, fallback_icon: str = 'NONE', scale_y: float = 1.65, emboss: bool = True):
    del scale_y
    row = layout.row(align=True)
    try:
        row.scale_y = 1.0
    except Exception:
        pass
    return operator(row, operator_id, text, icon_name, fallback_icon=fallback_icon, emboss=emboss)


def draw_icon_tile(layout, operator_id: str, label: str, icon_name: str, *, fallback_icon: str = 'NONE', icon_scale: float = 6.0, button_scale: float = 1.6, emboss: bool = False):
    del icon_scale, button_scale
    row = layout.row(align=True)
    try:
        row.scale_y = 1.0
    except Exception:
        pass
    return operator(row, operator_id, label, icon_name, fallback_icon=fallback_icon, emboss=emboss)

def export_reference_sheet() -> Path:
    try:
        from . import storage
        target_dir = storage.user_data_dir('icons', create=True)
    except Exception as exc:
        raise RuntimeError('Smart Geometry icon reference export requires CONFIG/Smart_Geometry_Suite.') from exc
    target = target_dir / 'smart_geometry_suite_icon_reference_v8.png'
    for source in (
        _REFERENCE_DIR / 'icon_reference_sheet_v8.png',
        _REFERENCE_DIR / 'command_deck_reference.png',
        _REFERENCE_DIR / 'workflow_reference.png',
        _REFERENCE_DIR / 'attribute_stack_reference.png',
    ):
        try:
            if source.exists():
                shutil.copy2(source, target)
                return target
        except Exception:
            pass
    return target
