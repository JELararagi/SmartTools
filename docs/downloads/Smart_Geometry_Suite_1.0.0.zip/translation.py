# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

from . import catalog

_STATIC = {
    'Smart Geometry': 'Smart Geometry',
    'Always-on Toggles': '常時機能切り替え',
    'Always-on Toggles Group Open': '常時機能切り替えグループを開く',
    'Shows or collapses the always-on feature controls in the N-panel. The toggles below start or stop lightweight background helpers such as the icon cache, live mesh inspector, attribute guard, selection sync, camera visibility gate, node library guard, and automatic diagnostic snapshots.': 'Nパネル内の常時起動機能コントロールを表示または折りたたみます。下の切り替えは、アイコンキャッシュ、ライブメッシュインスペクター、属性ガード、選択同期、カメラ可視性ゲート、ノードライブラリガード、自動診断スナップショットなどの軽量バックグラウンド補助を開始または停止します。',
    'Open or close the clock-marked Always-on Toggles group at the top of the Smart Geometry N-panel. This group contains only features that keep timers, preview caches, or lightweight monitors alive while enabled.': 'Smart Geometry Nパネル最上部にある時計アイコン付きの常時機能切り替えグループを開閉します。このグループには、有効時にタイマー、プレビューキャッシュ、軽量監視を維持する機能だけを集約しています。',
    'Enabled': '有効',
    'Disabled': '無効',
    'Custom Icon Cache': 'カスタムアイコンキャッシュ',
    'Live Mesh Inspector': 'ライブメッシュインスペクター',
    'Live Attribute Guard': 'ライブ属性ガード',
    'Live Selection Sync': 'ライブ選択同期',
    'Live Camera Visibility Gate': 'ライブカメラ可視性ゲート',
    'Node Library Guard': 'ノードライブラリガード',
    'Auto Diagnostics Snapshot': '自動診断スナップショット',
    'Use Custom Icons': 'カスタムアイコンを使用',
    'Icon cache': 'アイコンキャッシュ',
    'Persistent feature registry is not available.': '常時起動機能の登録情報を利用できません。',
    'Base Precision Strength': '基礎精度強度',
    'Base Feature Preservation': '基礎特徴保持',
    'Material Regions': 'マテリアル領域数',

    'Visual Operation Precision': 'ビジュアル操作精度版',
    'Run Precision Polish': '精度ポリッシュを実行',
    'Precision Strength': '精度強度',
    'Quality Passes': '品質パス',
    'Feature Radius': '特徴半径',
    'Material Contrast': 'マテリアルコントラスト',
    'Risk Suppression': 'リスク抑制',
    'Dashboard Tile Scale': 'ダッシュボードタイル倍率',
    'Show Reference Strips': 'リファレンス帯を表示',
    'Scatter Stability': '分布安定性',
    'Fragment Interlock': '破片連結性',

    'Smart Geometry': 'Smart Geometry',
    'Quick Start': 'クイック開始',
    'Feature Catalog': '機能カタログ',
    'Procedural Builders': 'プロシージャル生成',
    'Interop / Manifests': '外部連携 / マニフェスト',
    'Diagnostics': '診断',
    'Design Coverage': '設計カバー範囲',
    'Help': 'ヘルプ',

    'Visual Dashboard': 'ビジュアルダッシュボード',
    'Visual UI': 'ビジュアルUI',
    'Visual Precision': 'ビジュアル精度版',
    'Preset': 'プリセット',
    'Refine': '再構築',
    'Environment': '環境',
    'Surface Design': '表面設計',
    'Fragments': '破片',
    'Diagnose': '診断',
    'Full Demo': '完全デモ',
    'UI Density': 'UI密度',
    'Use Custom Icons': 'カスタムアイコンを使用',
    'Icon Scale': 'アイコン倍率',
    'Precision Preset': '精度プリセット',
    'Precision Strength': '精度強度',
    'Feature Preservation': '特徴保持',
    'Material Regions': 'マテリアル領域数',
    'Generated borderless maximum-fill icons': '生成済みの枠無し最大充填アイコン',
    'Export Icon Reference Sheet': 'アイコンリファレンスを書き出し',
    'Reload Custom Icons': 'カスタムアイコンを再読み込み',
    'Open Visual Reference': 'ビジュアルリファレンスを開く',
    'Run Precision Polish': '精度ポリッシュを実行',
    'Create Node Group Library': 'ノードグループライブラリ作成',
    'Rebuild Node Group Library': 'ノードグループライブラリ再構築',
    'Apply Active Feature': 'アクティブ機能を適用',
    'Apply Active Pack': 'アクティブパックを適用',
    'Apply Full Independent Toolset': '完全独自ツールセットを適用',
    'Add Standard Attributes': '標準属性を追加',
    'Apply Selection String': '選択文字列を適用',
    'Create Smart Terrain': 'スマート地形を作成',
    'Create Scatter Points': '散布ポイントを作成',
    'Create Greeble Blocks': 'グリーブルブロックを作成',
    'Create Building Proxy': '建築プロキシを作成',
    'Create Ivy / Root Curve': '蔦 / 根カーブを作成',
    'Explode Mesh to Pieces': 'メッシュを破片に分解',
    'Import CSV Points': 'CSVポイントを読み込み',
    'Create Demo Scene': 'デモシーン作成',
    'Export Inventory JSON': 'インベントリJSONを書き出し',
    'Export Design Coverage JSON': '設計カバーJSONを書き出し',
    'Export Diagnostics JSON': '診断JSONを書き出し',
    'Export USD Sidecar Manifest': 'USDサイドカーマニフェストを書き出し',
    'Export Toolset Bundle Manifest': 'ツールセットバンドルマニフェストを書き出し',
    'Remove Generated Node Groups': '生成済みノードグループを削除',
    'Open Help': 'ヘルプを開く',
    'Feature Category': '機能カテゴリ',
    'Design Domain Filter': '設計ドメインフィルター',
    'Active Feature': 'アクティブ機能',
    'Active Pack': 'アクティブパック',
    'Search Filter': '検索フィルター',
    'Capsule Prefix': 'カプセル接頭辞',
    'Mark Node Groups as Assets': 'ノードグループをアセット化',
    'Selection String': '選択文字列',
    'Terrain Resolution': '地形解像度',
    'Terrain Size': '地形サイズ',
    'Terrain Height': '地形高さ',
    'Scatter Count': '散布数',
    'Scatter Radius': '散布半径',
    'Structure Floors': '階数',
    'Floors': '階数',
    'Density Threshold': '密度しきい値',
    'Random Seed': 'ランダムシード',
    'CSV Path': 'CSVパス',
    'Show Advanced': '詳細を表示',
    'Terrain Hydraulic Iterations': '地形水理反復',
    'Scatter Relax Iterations': '散布緩和反復',
    'Hydraulic Iterations': '水理反復',
    'Relax Iterations': '緩和反復',

    'Terrain Hydraulic Droplets': '地形水理ドロップ数',
    'Terrain Channel Strength': '地形水路強度',
    'Use Adaptive Spacing': '適応間隔を使用',
    'Scatter Quality Passes': '散布品質パス',
    'Use Camera Visibility Gate': 'カメラ可視性ゲートを使用',
    'Hydraulic Droplets': '水理ドロップ数',
    'Channel Strength': '水路強度',
    'Quality Passes': '品質パス',
    'Adaptive Spacing': '適応間隔',
    'Camera Visibility Gate': 'カメラ可視性ゲート',
    'Debug Attribute': 'デバッグ属性',
    'Create Attribute Heatmap': '属性ヒートマップを作成',
    'Create Attribute Snapshot': '属性スナップショットを作成',
    'Refine Scene Precision': 'シーン精度を再構築',
    'Relax Distribution Points': '分布ポイントを緩和',
    'Create Drainage Flow Network': '排水フローネットワークを作成',
    'Relax Iterations': '緩和反復',
    'Candidate Multiplier': '候補倍率',
    'Drainage Curves': '排水カーブ数',
    'Create Distribution Proxy Instances': '分布プロキシインスタンスを作成',

    'Terrain Erosion Iterations': '地形侵食反復',
    'Scatter Minimum Spacing': '散布最小間隔',
    'Use Blue-Noise Rejection': 'ブルーノイズ除外を使用',
    'Scatter Normal Offset': '散布法線オフセット',
    'Scatter Habitat Bias': '散布生息環境バイアス',
    'Growth Branches': '成長枝数',
    'Fragment Piece Count': '破片数',
    'Diagnostic Sample Limit': '診断サンプル上限',
    'Build Precision Attributes': '高精度属性を構築',
    'Create Precision Terrain': '高精度地形を作成',
    'Create Precision Distribution Points': '高精度分布ポイントを作成',
    'Create Surface Detail Blocks': '表面ディテールブロックを作成',
    'Create Modular Structure': 'モジュラー構造を作成',
    'Create Organic Growth Curves': '有機成長カーブを作成',
    'Create Clustered Fragments': 'クラスタ破片を作成',
    'Erosion Iterations': '侵食反復',
    'Minimum Spacing': '最小間隔',
    'Blue-Noise Rejection': 'ブルーノイズ除外',
    'Normal Offset': '法線オフセット',
    'Habitat Bias': '生息環境バイアス',
    'Fragment Pieces': '破片数',
    'Domain': 'ドメイン',
    'Requirement capsules': '要件カプセル',
    'Native composite capsules': 'ネイティブ複合カプセル',
    'Design Domains': '設計ドメイン',
}

_STATIC.update({
    'Precision Builders': '精度ビルダー',
    'Visual Guides': 'ビジュアルガイド',
    'Command Deck': 'コマンドデッキ',
    'Command Precision': 'コマンド精度',
    'Show Icon Dashboard': 'アイコンダッシュボード表示',
    'Show Visual Guides': 'ビジュアルガイド表示',
    'Borderless Icon Buttons': '枠無しアイコンボタン',
    'Icon Preview Scale': 'アイコンプレビュー倍率',
    'Command Button Height': 'コマンドボタン高さ',
    'Terrain Field Fusion': '地形フィールド融合',
    'Scatter Anisotropy Strength': '散布異方性強度',
    'Scatter Priority Bias': '散布優先度バイアス',
    'Fragment Compactness': '破片コンパクト性',
    'Apply Precision Preset': '精度プリセットを適用',
    'Run Visual Workflow': 'ビジュアルワークフローを実行',
    'Workflow ID': 'ワークフローID',
    'Open Large Visual Reference': '大型ビジュアルリファレンスを開く',
    'Visual Reference': 'ビジュアルリファレンス',
    'Icon Reference Sheet': 'アイコンリファレンスシート',
    'Reload Icons': 'アイコン再読込',
    'Export Icon Sheet': 'アイコンシート書き出し',
    'Precision Polish': '精度ポリッシュ',
    'Feature Preservation': '特徴保持',
    'Material Regions': 'マテリアル領域数',
    'Anisotropy Strength': '異方性強度',
    'Priority Bias': '優先度バイアス',
    'Tangent Relax': '接平面緩和',
    'Fairness Strength': '均等性強度',
    'Fragment Contiguity': '破片連続性',
})


_STATIC.update({
    'Lazy Help UI': '遅延ヘルプUI',
    'Packs': 'パック',
    'Requirements': '要件',
    'Apply Feature': '機能を適用',
    'Apply Pack': 'パックを適用',
    'Create Library': 'ライブラリ作成',
    'Storage': '保存先',
    'Visible': '表示',
    'Use search or advanced display for more rows.': '検索または詳細表示で表示行数を増やせます。',
    'Builder Controls': '生成コントロール',
    'Amount': '数量',
    'Radius / Size': '半径 / サイズ',
    'Ridge Preservation': '稜線保持',
    'Channel Count': '水路数',
    'Field Fusion': 'フィールド融合',
    'Icon Preview': 'アイコンプレビュー',
    'No active mesh object.': 'アクティブなメッシュオブジェクトがありません。',
    'Active Mesh': 'アクティブメッシュ',
    'Name': '名前',
    'Vertices': '頂点',
    'Edges': '辺',
    'Faces': '面',
    'Attributes': '属性',
    'Modifiers': 'モディファイア',
    'Generated Node Groups': '生成済みノードグループ',
    'Open the lazy-loaded detailed help popup for the selected Smart Geometry tool group or feature. The heavy help text is imported only after this button is clicked.': '選択したSmart Geometryツールグループまたは機能の詳細ヘルプを開きます。重いヘルプ本文はこのボタンをクリックした後だけ読み込まれます。',
    'Help Key': 'ヘルプキー',
    'Internal help topic key. Leave empty to open the active feature help or the suite overview.': '内部ヘルプ項目キーです。空欄の場合はアクティブ機能ヘルプまたはツールセット概要を開きます。',
    'Optional feature ID for feature-specific help. Leave empty to use the active feature selected in the panel.': '機能別ヘルプ用の任意機能IDです。空欄の場合はパネルで選択中のアクティブ機能を使います。',
    'Open detailed help. The manual text is lazy-loaded only after clicking this Help icon.': '詳細ヘルプを開きます。マニュアル本文はこのヘルプアイコンをクリックした後だけ遅延読み込みされます。',
    'Preview': 'プレビュー',
    'Fast responsive setup for early blocking and icon-driven testing.': '初期ブロックアウトとアイコン操作テスト向けの高速設定です。',
    'Production': 'プロダクション',
    'Balanced high-quality defaults for most procedural scenes.': '多くのプロシージャルシーン向けのバランス型高品質設定です。',
    'Extreme': 'エクストリーム',
    'Maximum local quality defaults for dense terrain, distribution, and diagnostics.': '高密度地形、分布、診断向けの最大品質設定です。',
    'Visual Command Deck': 'ビジュアルコマンドデッキ',
    'Prioritize large icon buttons and fewer exposed technical controls.': '大型アイコンボタンを優先し、表示する技術設定を少なくします。',
    'Balanced': 'バランス',
    'Show visual buttons plus the most important technical controls.': 'ビジュアルボタンと重要な技術設定を表示します。',
    'Technical': 'テクニカル',
    'Show dense controls, catalogs, metadata, and diagnostic details.': '高密度の設定、カタログ、メタデータ、診断詳細を表示します。',
    'Show Command Ribbon': 'コマンドリボン表示',
    'Icon Figure Fill': 'アイコン図形充填率',
    'Scatter Stability Bias': '散布安定性バイアス',
    'Fragment Interlock Bias': '破片連結性バイアス',
    'Fragment Contiguity Bias': '破片連続性バイアス',
    'Distribution Fairness Strength': '分布均等性強度',
    'Scatter Candidate Multiplier': '散布候補倍率',
    'Tangent Relax Iterations': '接平面緩和反復',
    'Terrain Ridge Preservation': '地形稜線保持',
    'Terrain Channel Count': '地形水路数',
    'Feature ID': '機能ID',
    'Smart Geometry Help': 'Smart Geometry ヘルプ',
    'Display detailed Smart Geometry tool help.': 'Smart Geometryツールの詳細ヘルプを表示します。',
})


_STATIC.update({
    'Migrated Geometry-Node Generators': '移植済みジオメトリノード生成ツール',
    'These tools were moved from Smart Modeling Suite and are now owned by Smart Geometry Suite.': 'これらのツールは Smart Modeling Suite から移動し、現在は Smart Geometry Suite 側の機能として管理されます。',
    'Max Primitives': 'Maxプリミティブ',
    'Open Max Primitives Menu': 'Maxプリミティブメニューを開く',
    'Box': 'ボックス',
    'Sphere': '球',
    'Cylinder': '円柱',
    'Wall': '壁',
    'Install Assets': 'アセットをインストール',
    'Update All': '全て更新',
    'Grease Mesh': 'グリースメッシュ',
    'Create mesh or Geometry Nodes modifiers from Grease Pencil strokes.': 'Grease Pencil ストロークからメッシュまたはジオメトリノードモディファイアを作成します。',
    'Add GP': 'GP追加',
    'Apply Modifiers': 'モディファイア適用',
    'Solid Mesh': 'ソリッドメッシュ',
    'Mirror Mesh': 'ミラーメッシュ',
    'Path Mesh': 'パスメッシュ',
    'Wall Mesh': '壁メッシュ',
    'Scatter': '散布',
    'Array on Pencil': 'ペンシル上に配列',
    'Add New Grease Pencil': '新規グリースペンシルを追加',
    'Apply All Modifiers': '全モディファイアを適用',
    'Array on Curve': 'カーブ上に配列',
    'Bool Cut': 'ブールカット',
    'Mirror Mesh (GN)': 'ミラーメッシュ（GN）',
    'Path Mesh (GN)': 'パスメッシュ（GN）',
    'Solid Mesh (GN)': 'ソリッドメッシュ（GN）',
    'Wall Mesh (GN)': '壁メッシュ（GN）',
    'Knife Cut': 'ナイフカット',
    'Lattice Wrap': 'ラティスラップ',
    'Create Screw Mesh': 'スクリューメッシュを作成',
    'Stamp Scatter': 'スタンプ散布',
    'Create': '作成',
    'Mesh from GP': 'GPからメッシュ生成',
    'Solid': 'ソリッド',
    'Mirror': 'ミラー',
    'Path': 'パス',
    'Screw Mesh': 'スクリューメッシュ',
    'Screw': 'スクリュー',
    'Other': 'その他',
    'Experimental': '実験的',
    'Add a new Grease Pencil object for sketch-to-mesh generation. Use this first when you want to draw strokes that will later become mesh or Geometry Nodes generated geometry.': 'スケッチからメッシュ生成するための新規 Grease Pencil オブジェクトを追加します。後でメッシュまたは Geometry Nodes 生成形状に変換するストロークを描く時に最初に使います。',
    'Apply all modifiers on the active Grease Mesh result. Use this when the generated Geometry Nodes preview is final and you want real editable mesh data.': 'アクティブな Grease Mesh 結果にある全モディファイアを適用します。Geometry Nodes の生成プレビューが確定し、実際に編集できるメッシュデータにしたい時に使います。',
    'Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path. Select or create a Grease Pencil stroke before running this command.': 'Grease Pencil ストロークからカーブパス上の配列風 Geometry Nodes セットアップを作成します。実行前に Grease Pencil ストロークを選択または作成してください。',
    'Cut selected mesh geometry using Grease Pencil stroke shapes. Adjust depth and resolution to control the generated cutter thickness and smoothness.': 'Grease Pencil ストローク形状を使って選択メッシュをカットします。生成カッターの厚みや滑らかさは深度と解像度で調整します。',
    'Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh. Use this for symmetrical sketch-based mesh blocking.': 'Grease Pencil ストローク形状をメッシュとしてミラー生成する Geometry Nodes モディファイアを追加します。左右対称のスケッチベースブロックアウトに使います。',
    'Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes. Use this for pipes, trims, cables, and stroke-based strips.': 'Grease Pencil のパスストロークに沿ってメッシュ形状をスイープする Geometry Nodes モディファイアを追加します。パイプ、トリム、ケーブル、ストロークベースの帯に使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry. Use this for quick sketch-to-solid blocking.': 'Grease Pencil ストロークをソリッドなメッシュ形状へ変換する Geometry Nodes モディファイアを追加します。素早いスケッチからソリッド形状へのブロックアウトに使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry. Use this for quick architectural blocking.': 'Grease Pencil の平面図ストロークを壁状メッシュへ変換する Geometry Nodes モディファイアを追加します。素早い建築ブロックアウトに使います。',
    'Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing. Enable cut-through when the stroke should affect geometry behind the visible front surface.': 'Grease Pencil ストロークガイドを、メッシュ編集用のナイフカット補助として使います。見えている前面の奥にある形状も切る場合は貫通カットを有効にします。',
    'Create a lattice-based wrap helper around selected geometry. Use this for broad deformation after sketch or mesh generation.': '選択形状の周囲にラティスベースのラップ補助を作成します。スケッチ生成またはメッシュ生成後の大まかな変形に使います。',
    'Create lathe-style screw mesh geometry from a Grease Pencil profile. Use this for revolved forms such as knobs, cups, vases, and turned parts.': 'Grease Pencil の輪郭から旋盤風のスクリューメッシュ形状を作成します。ノブ、カップ、花瓶、旋削部品のような回転形状に使います。',
    'Scatter stamped mesh instances from Grease Pencil stroke input. Use this for quick distribution of repeated sketch-based elements.': 'Grease Pencil ストローク入力からスタンプ状のメッシュインスタンスを散布します。繰り返し配置するスケッチベース要素を素早く分布させる時に使います。',
})
_STATIC.update({
    'Terrain / Environment Generators': '地形 / 環境生成',
    'Distribution / Scatter Generators': '分布 / 散布生成',
    'Structure / Surface Generators': '構造 / 表面生成',
    'Organic / Stroke Generators': '有機 / ストローク生成',
    'Debris / Fragment Generators': 'デブリ / 破砕生成',
    'Primitive Generators': 'プリミティブ生成',
    'Settings': '設定',
    'Terrain Mesh': '地形メッシュ',
    'Drainage Flow Curves': '排水フローカーブ',
    'Surface Distribution Points': '表面分布ポイント',
    'Relax and Preview Instances': '緩和とプレビューインスタンス',
    'CSV Point Cloud': 'CSVポイントクラウド',
    'Surface Detail Blocks': '表面ディテールブロック',
    'Modular Structure': 'モジュラー構造',
    'Organic Growth Curves': '有機成長カーブ',
    'Grease Pencil Mesh Generators': 'Grease Pencilメッシュ生成',
    'Debris Module Generator': 'デブリモジュール生成',
    'Mesh Fragment Generator': 'メッシュ破砕生成',
    'Max Primitive Generators': 'Maxプリミティブ生成',
    'Interface': 'インターフェース',
    'Node Library and Assets': 'ノードライブラリとアセット',
    'Feature / Pack Apply': '機能 / パック適用',
    'Precision Attributes and Selection': '精度属性と選択',
    'Diagnostics and Cleanup': '診断とクリーンアップ',
    'Import / Export Manifests': '読み込み / 書き出しマニフェスト',
    'Debris Utility Settings': 'デブリ補助設定',
    'Visual Reference': 'ビジュアルリファレンス',
    'Coverage Summary': 'カバー範囲サマリー',
    'Creates a terrain mesh. The settings below are the values read by this generator.': '地形メッシュを作成します。下の設定はこの生成処理が実際に参照する値です。',
    'Creates downhill guide curves from the active mesh terrain attributes.': 'アクティブメッシュの地形属性から下り方向のガイドカーブを作成します。',
    'Creates a point-cloud mesh from the active surface or a fallback grid.': 'アクティブな表面またはフォールバックグリッドからポイントクラウドメッシュを作成します。',
    'Relaxes generated points or creates lightweight visible proxy instances for distribution checking.': '生成済みポイントを緩和するか、分布確認用の軽量な可視プロキシインスタンスを作成します。',
    'Imports x, y, z CSV columns as a generated point-cloud mesh.': 'CSVのx, y, z列を生成ポイントクラウドメッシュとして読み込みます。',
    'Creates density-ranked helper blocks on the active surface or fallback grid.': 'アクティブ表面またはフォールバックグリッド上に、密度順の補助ブロックを作成します。',
    'Generates a tiered modular structure mesh with Smart Geometry attributes.': 'Smart Geometry属性付きの階層型モジュラー構造メッシュを生成します。',
    'Creates procedural curves for ivy, roots, cables, veins, or trail guides.': '蔦、根、ケーブル、脈、軌跡ガイド用のプロシージャルカーブを作成します。',
    'Creates mesh or Geometry Nodes results from Grease Pencil strokes. These operators use the selected stroke/object context and do not require SGS numeric parameters.': 'Grease PencilストロークからメッシュまたはGeometry Nodes結果を作成します。これらの処理は選択中のストローク/オブジェクト状態を使用し、SGS数値パラメータは不要です。',
    "Choose one debris module; only that module's active settings are shown before generation.": 'デブリモジュールを1つ選ぶと、そのモジュールに必要な設定だけを表示して生成します。',
    'Creates clustered fragment helper objects from the active mesh faces.': 'アクティブメッシュの面からクラスタ化された破片補助オブジェクトを作成します。',
    'Creates primitive and AEC-style generator objects from the integrated Max Primitives toolset.': '統合されたMax Primitivesツールセットから、プリミティブやAEC系生成オブジェクトを作成します。',
    'Top-level generation sections stay separate; non-generation controls are consolidated here.': '最上層の生成セクションは分離し、生成以外の操作はここに集約しています。',
    'Use search to narrow the advanced feature list.': '詳細機能一覧は検索で絞り込んでください。',
    'Live sidebar buttons use Blender standard icons; visual reference output remains optional.': 'ライブサイドバーのボタンはBlender標準アイコンを使用し、ビジュアルリファレンス出力は任意機能として残します。',
    'Show Terrain and Environment Generators Section': '地形 / 環境生成セクションを表示',
    'Show Distribution and Scatter Generators Section': '分布 / 散布生成セクションを表示',
    'Show Structure and Surface Generators Section': '構造 / 表面生成セクションを表示',
    'Show Organic and Stroke Generators Section': '有機 / ストローク生成セクションを表示',
    'Show Debris and Fragment Generators Section': 'デブリ / 破砕生成セクションを表示',
    'Show Primitive Generators Section': 'プリミティブ生成セクションを表示',
    'Show Settings Section': '設定セクションを表示',
    'Expand or collapse the terrain and environment generator section. It contains only direct generation commands for terrain meshes and drainage flow curves, with the parameters those generators actually read.': '地形 / 環境生成セクションを開閉します。地形メッシュと排水フローカーブを直接生成するコマンドだけを含み、それらの生成処理が実際に参照するパラメータを表示します。',
    'Expand or collapse the distribution generator section. It contains point-cloud, scatter, relaxation, proxy instance, and CSV point generation controls with the relevant distribution settings.': '分布生成セクションを開閉します。ポイントクラウド、散布、緩和、プロキシインスタンス、CSVポイント生成の操作と関連する分布設定を含みます。',
    'Expand or collapse the structure and surface generator section. It contains direct generation tools for surface detail blocks and modular structures with their own settings.': '構造 / 表面生成セクションを開閉します。表面ディテールブロックとモジュラー構造を直接生成するツールを、それぞれの設定と一緒に表示します。',
    'Expand or collapse the organic and stroke generator section. It contains organic curve creation and Grease Pencil to mesh generation commands.': '有機 / ストローク生成セクションを開閉します。有機カーブ作成とGrease Pencilからメッシュへの生成コマンドを含みます。',
    'Expand or collapse the debris and fragment generator section. It contains the integrated debris module generator and mesh fragmentation generator with only their generation settings.': 'デブリ / 破砕生成セクションを開閉します。統合デブリモジュール生成とメッシュ破砕生成を、それぞれの生成設定だけと一緒に表示します。',
    'Expand or collapse the primitive generator section. It contains direct Max Primitive creation commands without unrelated asset maintenance controls.': 'プリミティブ生成セクションを開閉します。関係のないアセット管理操作を除き、Max Primitiveの直接作成コマンドだけを表示します。',
    'Expand or collapse the consolidated settings section at the bottom of the Smart Geometry panel. Non-generation controls, diagnostics, reports, visual reference options, and advanced feature application tools are grouped here.': 'Smart Geometryパネル最下部の統合設定セクションを開閉します。生成以外の操作、診断、レポート、ビジュアルリファレンス、詳細な機能適用ツールをここにまとめます。',
    'Show Terrain Mesh Generator Child Section': '地形メッシュ生成子セクションを表示',
    'Show Drainage Flow Generator Child Section': '排水フロー生成子セクションを表示',
    'Show Surface Distribution Generator Child Section': '表面分布生成子セクションを表示',
    'Show Distribution Relax and Proxy Child Section': '分布緩和 / プロキシ子セクションを表示',
    'Show CSV Point Cloud Generator Child Section': 'CSVポイントクラウド生成子セクションを表示',
    'Show Surface Detail Generator Child Section': '表面ディテール生成子セクションを表示',
    'Show Modular Structure Generator Child Section': 'モジュラー構造生成子セクションを表示',
    'Show Organic Growth Generator Child Section': '有機成長生成子セクションを表示',
    'Show Stroke Mesh Generator Child Section': 'ストロークメッシュ生成子セクションを表示',
    'Show Debris Module Generator Child Section': 'デブリモジュール生成子セクションを表示',
    'Show Mesh Fragment Generator Child Section': 'メッシュ破砕生成子セクションを表示',
    'Show Max Primitive Generator Child Section': 'Maxプリミティブ生成子セクションを表示',
    'Show Interface Settings Child Section': 'インターフェース設定子セクションを表示',
    'Show Node Library Settings Child Section': 'ノードライブラリ設定子セクションを表示',
    'Show Feature and Pack Apply Child Section': '機能 / パック適用子セクションを表示',
    'Show Precision Tools Child Section': '精度ツール子セクションを表示',
    'Show Diagnostics and Cleanup Child Section': '診断 / クリーンアップ子セクションを表示',
    'Show Manifest Report Child Section': 'マニフェストレポート子セクションを表示',
    'Show Debris Utility Settings Child Section': 'デブリ補助設定子セクションを表示',
    'Show Visual Reference Settings Child Section': 'ビジュアルリファレンス設定子セクションを表示',
    'Show Coverage Summary Child Section': 'カバー範囲サマリー子セクションを表示',
    'Show Storage Path Child Section': '保存先パス子セクションを表示',
})
_translations = {'ja_JP': {}}
for en, ja in _STATIC.items():
    _translations['ja_JP'][('*', en)] = ja

try:
    from . import always_on as _always_on
    for _feature in _always_on.feature_definitions():
        _translations['ja_JP'][('*', _feature.label_en)] = _feature.label_ja
        _translations['ja_JP'][('*', _feature.description_en)] = _feature.description_ja
except Exception:
    pass

# Add feature strings so operator search, enum fallbacks, and help can be translated by Blender when it asks translation APIs.
for feature in catalog.FEATURES:
    for key in ('label', 'summary', 'tooltip'):
        en = str(feature.get(f'{key}_en') or '')
        ja = str(feature.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for category in catalog.CATEGORIES:
    for key in ('label', 'summary'):
        en = str(category.get(f'{key}_en') or '')
        ja = str(category.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for pack in catalog.PACKS:
    for key in ('label', 'description'):
        en = str(pack.get(f'{key}_en') or '')
        ja = str(pack.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for feature in catalog.FEATURES:
    en = str(feature.get('design_domain_en') or '')
    ja = str(feature.get('design_domain_ja') or '')
    if en and ja:
        _translations['ja_JP'][('*', en)] = ja

I18N_DICT = _translations

# lazy help UI additions.  These keep visible panel labels, operator names,
# and help-button tooltips localized without importing the lazy help body at startup.
_STATIC.update({
    'Lazy Help UI': '遅延ヘルプUI版',
    'Help Index': 'ヘルプ一覧',
    'Root': 'ルート',
    'Open detailed lazy-loaded help for a Smart Geometry tool group or feature.': 'Smart Geometryのツールグループまたは機能の詳細ヘルプを遅延読み込みで開きます。',
    'Help Topic': 'ヘルプ項目',
    'Tool group help topic. Use feature with Feature ID for feature-specific help.': 'ツールグループのヘルプ項目です。機能別ヘルプではFeature IDと組み合わせて使います。',
    'Feature ID': '機能ID',
    'Optional feature ID for feature-specific help. Leave empty to use the active feature selected in the panel.': '機能別ヘルプ用の任意IDです。空の場合はパネルで選択中のアクティブ機能を使います。',
    'Open detailed help for this feature. The help catalog is loaded only when the Help icon is clicked.': 'この機能の詳細ヘルプを表示します。ヘルプカタログはヘルプアイコンを押した時だけ読み込まれます。',
    'Open detailed help for this tool group. The help catalog is loaded only when the Help icon is clicked.': 'このツールグループの詳細ヘルプを表示します。ヘルプカタログはヘルプアイコンを押した時だけ読み込まれます。',
    'Failed to open help: ': 'ヘルプを開けませんでした: ',
    'Help is not available for this topic.': 'この項目のヘルプを利用できません。',
    'Smart Geometry Help': 'Smart Geometry ヘルプ',
    'Display detailed Smart Geometry help.': 'Smart Geometryの詳細ヘルプを表示します。',
    'Display detailed help for this Smart Geometry tool group. The help file is loaded only after a Help icon is clicked.': 'このSmart Geometryツールグループの詳細ヘルプを表示します。ヘルプファイルはヘルプアイコンを押した時だけ読み込まれます。',
    'Feature Overview': '機能概要',
    'Usage': '使用方法',
    'Settings': '設定項目',
    'Help Topics': 'ヘルプ項目',
    'Borderless maximum-fill icons': '枠無し最大充填アイコン',
    'Builder Controls': '生成コントロール',
    'Polish Workflow': '磨き込みワークフロー',
    'Refine Workflow': '再構築ワークフロー',
    'Environment Workflow': '環境ワークフロー',
    'Surface Design Workflow': '表面設計ワークフロー',
    'Fragment Workflow': '破片ワークフロー',
    'Diagnose Workflow': '診断ワークフロー',
    'Full Demo Workflow': '完全デモワークフロー',
})

# Rebuild after late additions so all appended strings are included.

_STATIC.update({
    'Lazy Help UI': '遅延ヘルプUI',
    'Packs': 'パック',
    'Requirements': '要件',
    'Apply Feature': '機能を適用',
    'Apply Pack': 'パックを適用',
    'Create Library': 'ライブラリ作成',
    'Storage': '保存先',
    'Visible': '表示',
    'Use search or advanced display for more rows.': '検索または詳細表示で表示行数を増やせます。',
    'Builder Controls': '生成コントロール',
    'Amount': '数量',
    'Radius / Size': '半径 / サイズ',
    'Ridge Preservation': '稜線保持',
    'Channel Count': '水路数',
    'Field Fusion': 'フィールド融合',
    'Icon Preview': 'アイコンプレビュー',
    'No active mesh object.': 'アクティブなメッシュオブジェクトがありません。',
    'Active Mesh': 'アクティブメッシュ',
    'Name': '名前',
    'Vertices': '頂点',
    'Edges': '辺',
    'Faces': '面',
    'Attributes': '属性',
    'Modifiers': 'モディファイア',
    'Generated Node Groups': '生成済みノードグループ',
    'Open the lazy-loaded detailed help popup for the selected Smart Geometry tool group or feature. The heavy help text is imported only after this button is clicked.': '選択したSmart Geometryツールグループまたは機能の詳細ヘルプを開きます。重いヘルプ本文はこのボタンをクリックした後だけ読み込まれます。',
    'Help Key': 'ヘルプキー',
    'Internal help topic key. Leave empty to open the active feature help or the suite overview.': '内部ヘルプ項目キーです。空欄の場合はアクティブ機能ヘルプまたはツールセット概要を開きます。',
    'Optional feature ID for feature-specific help. Leave empty to use the active feature selected in the panel.': '機能別ヘルプ用の任意機能IDです。空欄の場合はパネルで選択中のアクティブ機能を使います。',
    'Open detailed help. The manual text is lazy-loaded only after clicking this Help icon.': '詳細ヘルプを開きます。マニュアル本文はこのヘルプアイコンをクリックした後だけ遅延読み込みされます。',
    'Preview': 'プレビュー',
    'Fast responsive setup for early blocking and icon-driven testing.': '初期ブロックアウトとアイコン操作テスト向けの高速設定です。',
    'Production': 'プロダクション',
    'Balanced high-quality defaults for most procedural scenes.': '多くのプロシージャルシーン向けのバランス型高品質設定です。',
    'Extreme': 'エクストリーム',
    'Maximum local quality defaults for dense terrain, distribution, and diagnostics.': '高密度地形、分布、診断向けの最大品質設定です。',
    'Visual Command Deck': 'ビジュアルコマンドデッキ',
    'Prioritize large icon buttons and fewer exposed technical controls.': '大型アイコンボタンを優先し、表示する技術設定を少なくします。',
    'Balanced': 'バランス',
    'Show visual buttons plus the most important technical controls.': 'ビジュアルボタンと重要な技術設定を表示します。',
    'Technical': 'テクニカル',
    'Show dense controls, catalogs, metadata, and diagnostic details.': '高密度の設定、カタログ、メタデータ、診断詳細を表示します。',
    'Show Command Ribbon': 'コマンドリボン表示',
    'Icon Figure Fill': 'アイコン図形充填率',
    'Scatter Stability Bias': '散布安定性バイアス',
    'Fragment Interlock Bias': '破片連結性バイアス',
    'Fragment Contiguity Bias': '破片連続性バイアス',
    'Distribution Fairness Strength': '分布均等性強度',
    'Scatter Candidate Multiplier': '散布候補倍率',
    'Tangent Relax Iterations': '接平面緩和反復',
    'Terrain Ridge Preservation': '地形稜線保持',
    'Terrain Channel Count': '地形水路数',
    'Feature ID': '機能ID',
    'Smart Geometry Help': 'Smart Geometry ヘルプ',
    'Display detailed Smart Geometry tool help.': 'Smart Geometryツールの詳細ヘルプを表示します。',
})


_STATIC.update({
    'Migrated Geometry-Node Generators': '移植済みジオメトリノード生成ツール',
    'These tools were moved from Smart Modeling Suite and are now owned by Smart Geometry Suite.': 'これらのツールは Smart Modeling Suite から移動し、現在は Smart Geometry Suite 側の機能として管理されます。',
    'Max Primitives': 'Maxプリミティブ',
    'Open Max Primitives Menu': 'Maxプリミティブメニューを開く',
    'Box': 'ボックス',
    'Sphere': '球',
    'Cylinder': '円柱',
    'Wall': '壁',
    'Install Assets': 'アセットをインストール',
    'Update All': '全て更新',
    'Grease Mesh': 'グリースメッシュ',
    'Create mesh or Geometry Nodes modifiers from Grease Pencil strokes.': 'Grease Pencil ストロークからメッシュまたはジオメトリノードモディファイアを作成します。',
    'Add GP': 'GP追加',
    'Apply Modifiers': 'モディファイア適用',
    'Solid Mesh': 'ソリッドメッシュ',
    'Mirror Mesh': 'ミラーメッシュ',
    'Path Mesh': 'パスメッシュ',
    'Wall Mesh': '壁メッシュ',
    'Scatter': '散布',
    'Array on Pencil': 'ペンシル上に配列',
    'Add New Grease Pencil': '新規グリースペンシルを追加',
    'Apply All Modifiers': '全モディファイアを適用',
    'Array on Curve': 'カーブ上に配列',
    'Bool Cut': 'ブールカット',
    'Mirror Mesh (GN)': 'ミラーメッシュ（GN）',
    'Path Mesh (GN)': 'パスメッシュ（GN）',
    'Solid Mesh (GN)': 'ソリッドメッシュ（GN）',
    'Wall Mesh (GN)': '壁メッシュ（GN）',
    'Knife Cut': 'ナイフカット',
    'Lattice Wrap': 'ラティスラップ',
    'Create Screw Mesh': 'スクリューメッシュを作成',
    'Stamp Scatter': 'スタンプ散布',
    'Create': '作成',
    'Mesh from GP': 'GPからメッシュ生成',
    'Solid': 'ソリッド',
    'Mirror': 'ミラー',
    'Path': 'パス',
    'Screw Mesh': 'スクリューメッシュ',
    'Screw': 'スクリュー',
    'Other': 'その他',
    'Experimental': '実験的',
    'Add a new Grease Pencil object for sketch-to-mesh generation. Use this first when you want to draw strokes that will later become mesh or Geometry Nodes generated geometry.': 'スケッチからメッシュ生成するための新規 Grease Pencil オブジェクトを追加します。後でメッシュまたは Geometry Nodes 生成形状に変換するストロークを描く時に最初に使います。',
    'Apply all modifiers on the active Grease Mesh result. Use this when the generated Geometry Nodes preview is final and you want real editable mesh data.': 'アクティブな Grease Mesh 結果にある全モディファイアを適用します。Geometry Nodes の生成プレビューが確定し、実際に編集できるメッシュデータにしたい時に使います。',
    'Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path. Select or create a Grease Pencil stroke before running this command.': 'Grease Pencil ストロークからカーブパス上の配列風 Geometry Nodes セットアップを作成します。実行前に Grease Pencil ストロークを選択または作成してください。',
    'Cut selected mesh geometry using Grease Pencil stroke shapes. Adjust depth and resolution to control the generated cutter thickness and smoothness.': 'Grease Pencil ストローク形状を使って選択メッシュをカットします。生成カッターの厚みや滑らかさは深度と解像度で調整します。',
    'Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh. Use this for symmetrical sketch-based mesh blocking.': 'Grease Pencil ストローク形状をメッシュとしてミラー生成する Geometry Nodes モディファイアを追加します。左右対称のスケッチベースブロックアウトに使います。',
    'Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes. Use this for pipes, trims, cables, and stroke-based strips.': 'Grease Pencil のパスストロークに沿ってメッシュ形状をスイープする Geometry Nodes モディファイアを追加します。パイプ、トリム、ケーブル、ストロークベースの帯に使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry. Use this for quick sketch-to-solid blocking.': 'Grease Pencil ストロークをソリッドなメッシュ形状へ変換する Geometry Nodes モディファイアを追加します。素早いスケッチからソリッド形状へのブロックアウトに使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry. Use this for quick architectural blocking.': 'Grease Pencil の平面図ストロークを壁状メッシュへ変換する Geometry Nodes モディファイアを追加します。素早い建築ブロックアウトに使います。',
    'Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing. Enable cut-through when the stroke should affect geometry behind the visible front surface.': 'Grease Pencil ストロークガイドを、メッシュ編集用のナイフカット補助として使います。見えている前面の奥にある形状も切る場合は貫通カットを有効にします。',
    'Create a lattice-based wrap helper around selected geometry. Use this for broad deformation after sketch or mesh generation.': '選択形状の周囲にラティスベースのラップ補助を作成します。スケッチ生成またはメッシュ生成後の大まかな変形に使います。',
    'Create lathe-style screw mesh geometry from a Grease Pencil profile. Use this for revolved forms such as knobs, cups, vases, and turned parts.': 'Grease Pencil の輪郭から旋盤風のスクリューメッシュ形状を作成します。ノブ、カップ、花瓶、旋削部品のような回転形状に使います。',
    'Scatter stamped mesh instances from Grease Pencil stroke input. Use this for quick distribution of repeated sketch-based elements.': 'Grease Pencil ストローク入力からスタンプ状のメッシュインスタンスを散布します。繰り返し配置するスケッチベース要素を素早く分布させる時に使います。',
})
_STATIC.update({
    'Terrain / Environment Generators': '地形 / 環境生成',
    'Distribution / Scatter Generators': '分布 / 散布生成',
    'Structure / Surface Generators': '構造 / 表面生成',
    'Organic / Stroke Generators': '有機 / ストローク生成',
    'Debris / Fragment Generators': 'デブリ / 破砕生成',
    'Primitive Generators': 'プリミティブ生成',
    'Settings': '設定',
    'Terrain Mesh': '地形メッシュ',
    'Drainage Flow Curves': '排水フローカーブ',
    'Surface Distribution Points': '表面分布ポイント',
    'Relax and Preview Instances': '緩和とプレビューインスタンス',
    'CSV Point Cloud': 'CSVポイントクラウド',
    'Surface Detail Blocks': '表面ディテールブロック',
    'Modular Structure': 'モジュラー構造',
    'Organic Growth Curves': '有機成長カーブ',
    'Grease Pencil Mesh Generators': 'Grease Pencilメッシュ生成',
    'Debris Module Generator': 'デブリモジュール生成',
    'Mesh Fragment Generator': 'メッシュ破砕生成',
    'Max Primitive Generators': 'Maxプリミティブ生成',
    'Interface': 'インターフェース',
    'Node Library and Assets': 'ノードライブラリとアセット',
    'Feature / Pack Apply': '機能 / パック適用',
    'Precision Attributes and Selection': '精度属性と選択',
    'Diagnostics and Cleanup': '診断とクリーンアップ',
    'Import / Export Manifests': '読み込み / 書き出しマニフェスト',
    'Debris Utility Settings': 'デブリ補助設定',
    'Visual Reference': 'ビジュアルリファレンス',
    'Coverage Summary': 'カバー範囲サマリー',
    'Creates a terrain mesh. The settings below are the values read by this generator.': '地形メッシュを作成します。下の設定はこの生成処理が実際に参照する値です。',
    'Creates downhill guide curves from the active mesh terrain attributes.': 'アクティブメッシュの地形属性から下り方向のガイドカーブを作成します。',
    'Creates a point-cloud mesh from the active surface or a fallback grid.': 'アクティブな表面またはフォールバックグリッドからポイントクラウドメッシュを作成します。',
    'Relaxes generated points or creates lightweight visible proxy instances for distribution checking.': '生成済みポイントを緩和するか、分布確認用の軽量な可視プロキシインスタンスを作成します。',
    'Imports x, y, z CSV columns as a generated point-cloud mesh.': 'CSVのx, y, z列を生成ポイントクラウドメッシュとして読み込みます。',
    'Creates density-ranked helper blocks on the active surface or fallback grid.': 'アクティブ表面またはフォールバックグリッド上に、密度順の補助ブロックを作成します。',
    'Generates a tiered modular structure mesh with Smart Geometry attributes.': 'Smart Geometry属性付きの階層型モジュラー構造メッシュを生成します。',
    'Creates procedural curves for ivy, roots, cables, veins, or trail guides.': '蔦、根、ケーブル、脈、軌跡ガイド用のプロシージャルカーブを作成します。',
    'Creates mesh or Geometry Nodes results from Grease Pencil strokes. These operators use the selected stroke/object context and do not require SGS numeric parameters.': 'Grease PencilストロークからメッシュまたはGeometry Nodes結果を作成します。これらの処理は選択中のストローク/オブジェクト状態を使用し、SGS数値パラメータは不要です。',
    "Choose one debris module; only that module's active settings are shown before generation.": 'デブリモジュールを1つ選ぶと、そのモジュールに必要な設定だけを表示して生成します。',
    'Creates clustered fragment helper objects from the active mesh faces.': 'アクティブメッシュの面からクラスタ化された破片補助オブジェクトを作成します。',
    'Creates primitive and AEC-style generator objects from the integrated Max Primitives toolset.': '統合されたMax Primitivesツールセットから、プリミティブやAEC系生成オブジェクトを作成します。',
    'Top-level generation sections stay separate; non-generation controls are consolidated here.': '最上層の生成セクションは分離し、生成以外の操作はここに集約しています。',
    'Use search to narrow the advanced feature list.': '詳細機能一覧は検索で絞り込んでください。',
    'Live sidebar buttons use Blender standard icons; visual reference output remains optional.': 'ライブサイドバーのボタンはBlender標準アイコンを使用し、ビジュアルリファレンス出力は任意機能として残します。',
    'Show Terrain and Environment Generators Section': '地形 / 環境生成セクションを表示',
    'Show Distribution and Scatter Generators Section': '分布 / 散布生成セクションを表示',
    'Show Structure and Surface Generators Section': '構造 / 表面生成セクションを表示',
    'Show Organic and Stroke Generators Section': '有機 / ストローク生成セクションを表示',
    'Show Debris and Fragment Generators Section': 'デブリ / 破砕生成セクションを表示',
    'Show Primitive Generators Section': 'プリミティブ生成セクションを表示',
    'Show Settings Section': '設定セクションを表示',
    'Expand or collapse the terrain and environment generator section. It contains only direct generation commands for terrain meshes and drainage flow curves, with the parameters those generators actually read.': '地形 / 環境生成セクションを開閉します。地形メッシュと排水フローカーブを直接生成するコマンドだけを含み、それらの生成処理が実際に参照するパラメータを表示します。',
    'Expand or collapse the distribution generator section. It contains point-cloud, scatter, relaxation, proxy instance, and CSV point generation controls with the relevant distribution settings.': '分布生成セクションを開閉します。ポイントクラウド、散布、緩和、プロキシインスタンス、CSVポイント生成の操作と関連する分布設定を含みます。',
    'Expand or collapse the structure and surface generator section. It contains direct generation tools for surface detail blocks and modular structures with their own settings.': '構造 / 表面生成セクションを開閉します。表面ディテールブロックとモジュラー構造を直接生成するツールを、それぞれの設定と一緒に表示します。',
    'Expand or collapse the organic and stroke generator section. It contains organic curve creation and Grease Pencil to mesh generation commands.': '有機 / ストローク生成セクションを開閉します。有機カーブ作成とGrease Pencilからメッシュへの生成コマンドを含みます。',
    'Expand or collapse the debris and fragment generator section. It contains the integrated debris module generator and mesh fragmentation generator with only their generation settings.': 'デブリ / 破砕生成セクションを開閉します。統合デブリモジュール生成とメッシュ破砕生成を、それぞれの生成設定だけと一緒に表示します。',
    'Expand or collapse the primitive generator section. It contains direct Max Primitive creation commands without unrelated asset maintenance controls.': 'プリミティブ生成セクションを開閉します。関係のないアセット管理操作を除き、Max Primitiveの直接作成コマンドだけを表示します。',
    'Expand or collapse the consolidated settings section at the bottom of the Smart Geometry panel. Non-generation controls, diagnostics, reports, visual reference options, and advanced feature application tools are grouped here.': 'Smart Geometryパネル最下部の統合設定セクションを開閉します。生成以外の操作、診断、レポート、ビジュアルリファレンス、詳細な機能適用ツールをここにまとめます。',
    'Show Terrain Mesh Generator Child Section': '地形メッシュ生成子セクションを表示',
    'Show Drainage Flow Generator Child Section': '排水フロー生成子セクションを表示',
    'Show Surface Distribution Generator Child Section': '表面分布生成子セクションを表示',
    'Show Distribution Relax and Proxy Child Section': '分布緩和 / プロキシ子セクションを表示',
    'Show CSV Point Cloud Generator Child Section': 'CSVポイントクラウド生成子セクションを表示',
    'Show Surface Detail Generator Child Section': '表面ディテール生成子セクションを表示',
    'Show Modular Structure Generator Child Section': 'モジュラー構造生成子セクションを表示',
    'Show Organic Growth Generator Child Section': '有機成長生成子セクションを表示',
    'Show Stroke Mesh Generator Child Section': 'ストロークメッシュ生成子セクションを表示',
    'Show Debris Module Generator Child Section': 'デブリモジュール生成子セクションを表示',
    'Show Mesh Fragment Generator Child Section': 'メッシュ破砕生成子セクションを表示',
    'Show Max Primitive Generator Child Section': 'Maxプリミティブ生成子セクションを表示',
    'Show Interface Settings Child Section': 'インターフェース設定子セクションを表示',
    'Show Node Library Settings Child Section': 'ノードライブラリ設定子セクションを表示',
    'Show Feature and Pack Apply Child Section': '機能 / パック適用子セクションを表示',
    'Show Precision Tools Child Section': '精度ツール子セクションを表示',
    'Show Diagnostics and Cleanup Child Section': '診断 / クリーンアップ子セクションを表示',
    'Show Manifest Report Child Section': 'マニフェストレポート子セクションを表示',
    'Show Debris Utility Settings Child Section': 'デブリ補助設定子セクションを表示',
    'Show Visual Reference Settings Child Section': 'ビジュアルリファレンス設定子セクションを表示',
    'Show Coverage Summary Child Section': 'カバー範囲サマリー子セクションを表示',
    'Show Storage Path Child Section': '保存先パス子セクションを表示',
})
_translations = {'ja_JP': {}}
for en, ja in _STATIC.items():
    _translations['ja_JP'][('*', en)] = ja
try:
    from . import always_on as _always_on
    for _feature in _always_on.feature_definitions():
        _translations['ja_JP'][('*', _feature.label_en)] = _feature.label_ja
        _translations['ja_JP'][('*', _feature.description_en)] = _feature.description_ja
except Exception:
    pass
for feature in catalog.FEATURES:
    for key in ('label', 'summary', 'tooltip'):
        en = str(feature.get(f'{key}_en') or '')
        ja = str(feature.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for category in catalog.CATEGORIES:
    for key in ('label', 'summary'):
        en = str(category.get(f'{key}_en') or '')
        ja = str(category.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for pack in catalog.PACKS:
    for key in ('label', 'description'):
        en = str(pack.get(f'{key}_en') or '')
        ja = str(pack.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for feature in catalog.FEATURES:
    en = str(feature.get('design_domain_en') or '')
    ja = str(feature.get('design_domain_ja') or '')
    if en and ja:
        _translations['ja_JP'][('*', en)] = ja
I18N_DICT = _translations

# Additional operator/internal help property translations.
_STATIC.update({
    'Help Key': 'ヘルプキー',
    'Internal help topic key. Leave empty to open the active feature help or the suite overview.': '内部ヘルプ項目キーです。空の場合はアクティブ機能ヘルプまたはツールセット概要を開きます。',
    'Public help topic alias used by N-panel Help icon buttons. It is mapped to the lazy help catalog only when clicked.': 'Nパネルのヘルプアイコンボタンが使う公開ヘルプ項目エイリアスです。クリック時のみ遅延ヘルプカタログへ対応付けます。',
    'Open the lazy-loaded detailed help popup for the selected Smart Geometry tool group or feature. The heavy help text is imported only after this button is clicked.': '選択したSmart Geometryツールグループまたは機能の遅延読み込み詳細ヘルプを開きます。重いヘルプ本文はこのボタンをクリックした後だけ読み込まれます。',
    'Open detailed help. The manual text is lazy-loaded only after clicking this Help icon.': '詳細ヘルプを開きます。マニュアル本文はこのヘルプアイコンをクリックした後だけ遅延読み込みされます。',
    'Help popup failed.': 'ヘルプポップアップに失敗しました。',
})

_STATIC.update({
    'Migrated Geometry-Node Generators': '移植済みジオメトリノード生成ツール',
    'These tools were moved from Smart Modeling Suite and are now owned by Smart Geometry Suite.': 'これらのツールは Smart Modeling Suite から移動し、現在は Smart Geometry Suite 側の機能として管理されます。',
    'Max Primitives': 'Maxプリミティブ',
    'Open Max Primitives Menu': 'Maxプリミティブメニューを開く',
    'Box': 'ボックス',
    'Sphere': '球',
    'Cylinder': '円柱',
    'Wall': '壁',
    'Install Assets': 'アセットをインストール',
    'Update All': '全て更新',
    'Grease Mesh': 'グリースメッシュ',
    'Create mesh or Geometry Nodes modifiers from Grease Pencil strokes.': 'Grease Pencil ストロークからメッシュまたはジオメトリノードモディファイアを作成します。',
    'Add GP': 'GP追加',
    'Apply Modifiers': 'モディファイア適用',
    'Solid Mesh': 'ソリッドメッシュ',
    'Mirror Mesh': 'ミラーメッシュ',
    'Path Mesh': 'パスメッシュ',
    'Wall Mesh': '壁メッシュ',
    'Scatter': '散布',
    'Array on Pencil': 'ペンシル上に配列',
    'Add New Grease Pencil': '新規グリースペンシルを追加',
    'Apply All Modifiers': '全モディファイアを適用',
    'Array on Curve': 'カーブ上に配列',
    'Bool Cut': 'ブールカット',
    'Mirror Mesh (GN)': 'ミラーメッシュ（GN）',
    'Path Mesh (GN)': 'パスメッシュ（GN）',
    'Solid Mesh (GN)': 'ソリッドメッシュ（GN）',
    'Wall Mesh (GN)': '壁メッシュ（GN）',
    'Knife Cut': 'ナイフカット',
    'Lattice Wrap': 'ラティスラップ',
    'Create Screw Mesh': 'スクリューメッシュを作成',
    'Stamp Scatter': 'スタンプ散布',
    'Create': '作成',
    'Mesh from GP': 'GPからメッシュ生成',
    'Solid': 'ソリッド',
    'Mirror': 'ミラー',
    'Path': 'パス',
    'Screw Mesh': 'スクリューメッシュ',
    'Screw': 'スクリュー',
    'Other': 'その他',
    'Experimental': '実験的',
    'Add a new Grease Pencil object for sketch-to-mesh generation. Use this first when you want to draw strokes that will later become mesh or Geometry Nodes generated geometry.': 'スケッチからメッシュ生成するための新規 Grease Pencil オブジェクトを追加します。後でメッシュまたは Geometry Nodes 生成形状に変換するストロークを描く時に最初に使います。',
    'Apply all modifiers on the active Grease Mesh result. Use this when the generated Geometry Nodes preview is final and you want real editable mesh data.': 'アクティブな Grease Mesh 結果にある全モディファイアを適用します。Geometry Nodes の生成プレビューが確定し、実際に編集できるメッシュデータにしたい時に使います。',
    'Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path. Select or create a Grease Pencil stroke before running this command.': 'Grease Pencil ストロークからカーブパス上の配列風 Geometry Nodes セットアップを作成します。実行前に Grease Pencil ストロークを選択または作成してください。',
    'Cut selected mesh geometry using Grease Pencil stroke shapes. Adjust depth and resolution to control the generated cutter thickness and smoothness.': 'Grease Pencil ストローク形状を使って選択メッシュをカットします。生成カッターの厚みや滑らかさは深度と解像度で調整します。',
    'Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh. Use this for symmetrical sketch-based mesh blocking.': 'Grease Pencil ストローク形状をメッシュとしてミラー生成する Geometry Nodes モディファイアを追加します。左右対称のスケッチベースブロックアウトに使います。',
    'Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes. Use this for pipes, trims, cables, and stroke-based strips.': 'Grease Pencil のパスストロークに沿ってメッシュ形状をスイープする Geometry Nodes モディファイアを追加します。パイプ、トリム、ケーブル、ストロークベースの帯に使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry. Use this for quick sketch-to-solid blocking.': 'Grease Pencil ストロークをソリッドなメッシュ形状へ変換する Geometry Nodes モディファイアを追加します。素早いスケッチからソリッド形状へのブロックアウトに使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry. Use this for quick architectural blocking.': 'Grease Pencil の平面図ストロークを壁状メッシュへ変換する Geometry Nodes モディファイアを追加します。素早い建築ブロックアウトに使います。',
    'Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing. Enable cut-through when the stroke should affect geometry behind the visible front surface.': 'Grease Pencil ストロークガイドを、メッシュ編集用のナイフカット補助として使います。見えている前面の奥にある形状も切る場合は貫通カットを有効にします。',
    'Create a lattice-based wrap helper around selected geometry. Use this for broad deformation after sketch or mesh generation.': '選択形状の周囲にラティスベースのラップ補助を作成します。スケッチ生成またはメッシュ生成後の大まかな変形に使います。',
    'Create lathe-style screw mesh geometry from a Grease Pencil profile. Use this for revolved forms such as knobs, cups, vases, and turned parts.': 'Grease Pencil の輪郭から旋盤風のスクリューメッシュ形状を作成します。ノブ、カップ、花瓶、旋削部品のような回転形状に使います。',
    'Scatter stamped mesh instances from Grease Pencil stroke input. Use this for quick distribution of repeated sketch-based elements.': 'Grease Pencil ストローク入力からスタンプ状のメッシュインスタンスを散布します。繰り返し配置するスケッチベース要素を素早く分布させる時に使います。',
})
_STATIC.update({
    'Terrain / Environment Generators': '地形 / 環境生成',
    'Distribution / Scatter Generators': '分布 / 散布生成',
    'Structure / Surface Generators': '構造 / 表面生成',
    'Organic / Stroke Generators': '有機 / ストローク生成',
    'Debris / Fragment Generators': 'デブリ / 破砕生成',
    'Primitive Generators': 'プリミティブ生成',
    'Settings': '設定',
    'Terrain Mesh': '地形メッシュ',
    'Drainage Flow Curves': '排水フローカーブ',
    'Surface Distribution Points': '表面分布ポイント',
    'Relax and Preview Instances': '緩和とプレビューインスタンス',
    'CSV Point Cloud': 'CSVポイントクラウド',
    'Surface Detail Blocks': '表面ディテールブロック',
    'Modular Structure': 'モジュラー構造',
    'Organic Growth Curves': '有機成長カーブ',
    'Grease Pencil Mesh Generators': 'Grease Pencilメッシュ生成',
    'Debris Module Generator': 'デブリモジュール生成',
    'Mesh Fragment Generator': 'メッシュ破砕生成',
    'Max Primitive Generators': 'Maxプリミティブ生成',
    'Interface': 'インターフェース',
    'Node Library and Assets': 'ノードライブラリとアセット',
    'Feature / Pack Apply': '機能 / パック適用',
    'Precision Attributes and Selection': '精度属性と選択',
    'Diagnostics and Cleanup': '診断とクリーンアップ',
    'Import / Export Manifests': '読み込み / 書き出しマニフェスト',
    'Debris Utility Settings': 'デブリ補助設定',
    'Visual Reference': 'ビジュアルリファレンス',
    'Coverage Summary': 'カバー範囲サマリー',
    'Creates a terrain mesh. The settings below are the values read by this generator.': '地形メッシュを作成します。下の設定はこの生成処理が実際に参照する値です。',
    'Creates downhill guide curves from the active mesh terrain attributes.': 'アクティブメッシュの地形属性から下り方向のガイドカーブを作成します。',
    'Creates a point-cloud mesh from the active surface or a fallback grid.': 'アクティブな表面またはフォールバックグリッドからポイントクラウドメッシュを作成します。',
    'Relaxes generated points or creates lightweight visible proxy instances for distribution checking.': '生成済みポイントを緩和するか、分布確認用の軽量な可視プロキシインスタンスを作成します。',
    'Imports x, y, z CSV columns as a generated point-cloud mesh.': 'CSVのx, y, z列を生成ポイントクラウドメッシュとして読み込みます。',
    'Creates density-ranked helper blocks on the active surface or fallback grid.': 'アクティブ表面またはフォールバックグリッド上に、密度順の補助ブロックを作成します。',
    'Generates a tiered modular structure mesh with Smart Geometry attributes.': 'Smart Geometry属性付きの階層型モジュラー構造メッシュを生成します。',
    'Creates procedural curves for ivy, roots, cables, veins, or trail guides.': '蔦、根、ケーブル、脈、軌跡ガイド用のプロシージャルカーブを作成します。',
    'Creates mesh or Geometry Nodes results from Grease Pencil strokes. These operators use the selected stroke/object context and do not require SGS numeric parameters.': 'Grease PencilストロークからメッシュまたはGeometry Nodes結果を作成します。これらの処理は選択中のストローク/オブジェクト状態を使用し、SGS数値パラメータは不要です。',
    "Choose one debris module; only that module's active settings are shown before generation.": 'デブリモジュールを1つ選ぶと、そのモジュールに必要な設定だけを表示して生成します。',
    'Creates clustered fragment helper objects from the active mesh faces.': 'アクティブメッシュの面からクラスタ化された破片補助オブジェクトを作成します。',
    'Creates primitive and AEC-style generator objects from the integrated Max Primitives toolset.': '統合されたMax Primitivesツールセットから、プリミティブやAEC系生成オブジェクトを作成します。',
    'Top-level generation sections stay separate; non-generation controls are consolidated here.': '最上層の生成セクションは分離し、生成以外の操作はここに集約しています。',
    'Use search to narrow the advanced feature list.': '詳細機能一覧は検索で絞り込んでください。',
    'Live sidebar buttons use Blender standard icons; visual reference output remains optional.': 'ライブサイドバーのボタンはBlender標準アイコンを使用し、ビジュアルリファレンス出力は任意機能として残します。',
    'Show Terrain and Environment Generators Section': '地形 / 環境生成セクションを表示',
    'Show Distribution and Scatter Generators Section': '分布 / 散布生成セクションを表示',
    'Show Structure and Surface Generators Section': '構造 / 表面生成セクションを表示',
    'Show Organic and Stroke Generators Section': '有機 / ストローク生成セクションを表示',
    'Show Debris and Fragment Generators Section': 'デブリ / 破砕生成セクションを表示',
    'Show Primitive Generators Section': 'プリミティブ生成セクションを表示',
    'Show Settings Section': '設定セクションを表示',
    'Expand or collapse the terrain and environment generator section. It contains only direct generation commands for terrain meshes and drainage flow curves, with the parameters those generators actually read.': '地形 / 環境生成セクションを開閉します。地形メッシュと排水フローカーブを直接生成するコマンドだけを含み、それらの生成処理が実際に参照するパラメータを表示します。',
    'Expand or collapse the distribution generator section. It contains point-cloud, scatter, relaxation, proxy instance, and CSV point generation controls with the relevant distribution settings.': '分布生成セクションを開閉します。ポイントクラウド、散布、緩和、プロキシインスタンス、CSVポイント生成の操作と関連する分布設定を含みます。',
    'Expand or collapse the structure and surface generator section. It contains direct generation tools for surface detail blocks and modular structures with their own settings.': '構造 / 表面生成セクションを開閉します。表面ディテールブロックとモジュラー構造を直接生成するツールを、それぞれの設定と一緒に表示します。',
    'Expand or collapse the organic and stroke generator section. It contains organic curve creation and Grease Pencil to mesh generation commands.': '有機 / ストローク生成セクションを開閉します。有機カーブ作成とGrease Pencilからメッシュへの生成コマンドを含みます。',
    'Expand or collapse the debris and fragment generator section. It contains the integrated debris module generator and mesh fragmentation generator with only their generation settings.': 'デブリ / 破砕生成セクションを開閉します。統合デブリモジュール生成とメッシュ破砕生成を、それぞれの生成設定だけと一緒に表示します。',
    'Expand or collapse the primitive generator section. It contains direct Max Primitive creation commands without unrelated asset maintenance controls.': 'プリミティブ生成セクションを開閉します。関係のないアセット管理操作を除き、Max Primitiveの直接作成コマンドだけを表示します。',
    'Expand or collapse the consolidated settings section at the bottom of the Smart Geometry panel. Non-generation controls, diagnostics, reports, visual reference options, and advanced feature application tools are grouped here.': 'Smart Geometryパネル最下部の統合設定セクションを開閉します。生成以外の操作、診断、レポート、ビジュアルリファレンス、詳細な機能適用ツールをここにまとめます。',
    'Show Terrain Mesh Generator Child Section': '地形メッシュ生成子セクションを表示',
    'Show Drainage Flow Generator Child Section': '排水フロー生成子セクションを表示',
    'Show Surface Distribution Generator Child Section': '表面分布生成子セクションを表示',
    'Show Distribution Relax and Proxy Child Section': '分布緩和 / プロキシ子セクションを表示',
    'Show CSV Point Cloud Generator Child Section': 'CSVポイントクラウド生成子セクションを表示',
    'Show Surface Detail Generator Child Section': '表面ディテール生成子セクションを表示',
    'Show Modular Structure Generator Child Section': 'モジュラー構造生成子セクションを表示',
    'Show Organic Growth Generator Child Section': '有機成長生成子セクションを表示',
    'Show Stroke Mesh Generator Child Section': 'ストロークメッシュ生成子セクションを表示',
    'Show Debris Module Generator Child Section': 'デブリモジュール生成子セクションを表示',
    'Show Mesh Fragment Generator Child Section': 'メッシュ破砕生成子セクションを表示',
    'Show Max Primitive Generator Child Section': 'Maxプリミティブ生成子セクションを表示',
    'Show Interface Settings Child Section': 'インターフェース設定子セクションを表示',
    'Show Node Library Settings Child Section': 'ノードライブラリ設定子セクションを表示',
    'Show Feature and Pack Apply Child Section': '機能 / パック適用子セクションを表示',
    'Show Precision Tools Child Section': '精度ツール子セクションを表示',
    'Show Diagnostics and Cleanup Child Section': '診断 / クリーンアップ子セクションを表示',
    'Show Manifest Report Child Section': 'マニフェストレポート子セクションを表示',
    'Show Debris Utility Settings Child Section': 'デブリ補助設定子セクションを表示',
    'Show Visual Reference Settings Child Section': 'ビジュアルリファレンス設定子セクションを表示',
    'Show Coverage Summary Child Section': 'カバー範囲サマリー子セクションを表示',
    'Show Storage Path Child Section': '保存先パス子セクションを表示',
})
_translations = {'ja_JP': {}}
for en, ja in _STATIC.items():
    _translations['ja_JP'][('*', en)] = ja
try:
    from . import always_on as _always_on
    for _feature in _always_on.feature_definitions():
        _translations['ja_JP'][('*', _feature.label_en)] = _feature.label_ja
        _translations['ja_JP'][('*', _feature.description_en)] = _feature.description_ja
except Exception:
    pass
for feature in catalog.FEATURES:
    for key in ('label', 'summary', 'tooltip'):
        en = str(feature.get(f'{key}_en') or '')
        ja = str(feature.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for category in catalog.CATEGORIES:
    for key in ('label', 'summary'):
        en = str(category.get(f'{key}_en') or '')
        ja = str(category.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for pack in catalog.PACKS:
    for key in ('label', 'description'):
        en = str(pack.get(f'{key}_en') or '')
        ja = str(pack.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for feature in catalog.FEATURES:
    en = str(feature.get('design_domain_en') or '')
    ja = str(feature.get('design_domain_ja') or '')
    if en and ja:
        _translations['ja_JP'][('*', en)] = ja
I18N_DICT = _translations


# complete visible-text translation supplement.
_STATIC.update({'Number of floors in the modular structure. More floors make a taller structure; the width and depth follow Radius / Size.': 'モジュラー構造の階の数です。増やすほど高くなります。幅と奥行きは「半径 / サイズ」で決まります。'})
_STATIC.update({'Adapts point spacing per sampled density, habitat score, and slope. Dense stable areas can accept closer points while sparse or steep areas keep wider spacing.': 'サンプルした密度、生息環境スコア、傾斜に応じて点の間隔を調整します。安定した高密度領域では点を近づけ、疎または急傾斜の領域では広めの間隔を保ちます。', 'Additional tangent-plane relaxation passes applied after point distribution. This evens spacing while preserving the sampled surface normal direction as much as possible.': '点分布後に追加する接平面緩和パスです。サンプル面の法線方向をできるだけ保ちながら間隔を均一化します。', 'Adjusts how strongly habitat attributes influence surface distribution. Positive values favor general-ground and dense-habitat areas; zero uses only area and density.': '生息環境属性が表面分布へ影響する強さを調整します。正の値では一般地面や高密度生息領域を優先し、0では面積と密度のみを使います。', 'Apply Precision Selection': '高精度選択を適用', 'Apply every feature capsule in the selected workflow pack to selected mesh objects as a modifier stack. Use packs for core setup, environment generation, motion FX, architecture, or interop workflows.': '選択したワークフローパック内の全機能カプセルを、選択メッシュへモディファイアスタックとして適用します。コア設定、環境生成、モーション表現、建築、外部連携などに使います。', 'Apply every independently named Smart Geometry capsule derived from the research requirements. This is a full coverage test and creates many modifiers.': '調査要件から作成した独自名のSmart Geometryカプセルをすべて適用します。全カバー確認用の処理で、多数のモディファイアを作成します。', 'Apply the active Smart Geometry feature capsule to selected mesh objects as a non-destructive Geometry Nodes modifier. If no explicit feature ID is provided, the panel selection is used.': 'アクティブなSmart Geometry機能カプセルを、選択メッシュへ非破壊のGeometry Nodesモディファイアとして適用します。明示的な機能IDがない場合はパネル選択を使います。', 'Apply tuned Smart Geometry defaults for fast preview, balanced production, or extreme local quality. This changes only panel settings; it does not generate or delete scene data.': '高速プレビュー、バランス型制作、極限品質用に調整済みのSmart Geometry既定値を適用します。変更するのはパネル設定のみで、シーンデータの生成や削除は行いません。', 'Attribute name used by heatmap and snapshot tools. You can type names such as sgs_density, sgs_slope, sgs_flow, sgs_channel, sgs_quality, or short aliases such as density, slope, flow, quality.': 'ヒートマップとスナップショットツールで使う属性名です。sgs_density、sgs_slope、sgs_flow、sgs_channel、sgs_quality、またはdensity、slope、flow、qualityなどの短い別名を入力できます。', 'Candidate multiplier for the low-discrepancy adaptive surface distributor. Higher values improve blue-noise quality and density fairness when many candidates are rejected.': '低差異適応表面分布で使う候補倍率です。多くの候補が拒否される場合でも、値を高くするとブルーノイズ品質と密度の公平性が向上します。', 'Chooses a tuned default profile for terrain, distribution, relaxation, diagnostics, and visual workflow buttons. Preview is fast, Production is balanced, and Extreme spends more computation for cleaner results.': '地形、分布、緩和、診断、ビジュアルワークフローボタン用の調整済みプロファイルを選びます。プレビューは高速、プロダクションはバランス型、エクストリームはより多く計算して高品質化します。', 'Contrast applied to the material-lane composer. Increase to separate wear, moss, dust, wetness, and exposed-surface masks more clearly for procedural materials.': 'マテリアルレーン生成に適用するコントラストです。摩耗、苔、埃、湿り、露出面マスクをプロシージャルマテリアルでより明確に分離したい場合に上げます。', 'Controls how large the dashboard icon preview tiles appear. Increase this on high-DPI monitors; the icon artwork itself remains borderless and maximum-fill.': 'ダッシュボードのアイコンプレビュータイルの大きさを制御します。高DPIモニターでは大きくしてください。アイコン画像自体は枠無し最大充填のままです。', 'Controls how many candidate samples the precision surface distributor may test per requested point. Increase for cleaner spacing and better weighted placement; decrease for faster previews.': '高精度表面分布で、要求点1つにつき何個の候補を試すかを制御します。間隔や重み付き配置を整えたい場合は上げ、プレビュー速度を優先する場合は下げます。', 'Controls how strongly high-risk topology, boundary, overdraw, and low-confidence regions are down-ranked by distribution, material, and LOD scores.': '分布、マテリアル、LODスコアで、高リスクトポロジー、境界、過描画、低信頼領域をどれだけ低評価にするかを制御します。', 'Controls how strongly the graph clustering keeps adjacent faces in the same fragment before separation. Higher values reduce scattered islands inside a single fragment.': 'グラフクラスタリングで、分離前に隣接面を同じ破片に保つ強さを制御します。値を高くすると単一破片内の離れ小島を減らせます。', 'Controls how strongly the precision polish preserves ridges, cavities, boundary details, and high-curvature regions while smoothing noisy attribute fields.': 'ノイズの多い属性フィールドを平滑化しながら、稜線、窪み、境界ディテール、高曲率領域を精度ポリッシュがどれだけ保持するかを制御します。', 'Controls how strongly distribution diagnostics account for normal, tangent, flow, and slope direction. Higher values improve directional placement quality for terrain and architecture.': '分布診断が法線、接線、流れ、傾斜方向をどれだけ考慮するかを制御します。値を高くすると地形や建築向けの方向性配置品質が向上します。', 'Controls how strongly scatter priority favors high-confidence, high-habitat, low-risk areas. Use this when distribution must prioritize production-safe placement over raw density.': '散布優先度が高信頼、高生息適性、低リスク領域をどれだけ優先するかを制御します。単純な密度より制作上安全な配置を優先したい場合に使います。', 'Controls how strongly spacing diagnostics and tangent relaxation try to normalize nearest-neighbor spacing across dense and sparse regions.': '間隔診断と接線緩和が、密な領域と疎な領域にまたがって最近傍間隔をどれだけ正規化するかを制御します。', 'Controls how the Smart Geometry panels are presented. Visual mode emphasizes large custom icon buttons, Balanced keeps both icons and key controls, and Technical exposes dense controls and metadata.': 'Smart Geometryパネルの表示密度を制御します。ビジュアルは大型カスタムアイコンを重視し、バランスはアイコンと主要設定を併用し、テクニカルは詳細設定とメタデータを表示します。', 'Controls the display size of large icon previews in the command dashboard and visual guide panels. Increase this when using high-DPI displays or when the icon figure must be as large as possible.': 'コマンドダッシュボードとビジュアルガイドパネルで表示する大型アイコンプレビューのサイズを制御します。高DPI表示や、図形をできるだけ大きく見せたい場合に上げます。', 'Controls the fragment readability and glue/seam metadata written after clustered fragmentation. Higher values favor visually coherent, easier-to-animate pieces.': 'クラスタ破片化後に書き込む破片の読みやすさ、接着、切れ目メタデータを制御します。値を高くすると視覚的にまとまり、アニメーションしやすい破片を優先します。', 'Controls the compactness scoring for generated fragments. Higher values emphasize compact, readable pieces for animation and simulation handoff diagnostics.': '生成破片のコンパクト性スコアを制御します。値を高くすると、アニメーションやシミュレーション受け渡し診断で扱いやすい、まとまった破片を重視します。', 'Controls the ridge-preserving terrain relaxation. Higher values keep sharp ridges while still smoothing unstable pits and terraces for cleaner hydrology.': '稜線保持型の地形緩和を制御します。値を高くすると鋭い稜線を保ちつつ、不安定な窪みや段丘を滑らかにして水文属性を整えます。', 'Controls the vertical height of major command buttons. Larger values make the custom icons and labels easier to target in the sidebar.': '主要コマンドボタンの縦方向の高さを制御します。大きくするとサイドバー内でカスタムアイコンとラベルをクリックしやすくなります。', 'Convert active distribution points into lightweight visible proxy pyramids with density and biome attributes. This provides an immediate quality check for spacing, scale, LOD, and visibility.': 'アクティブな分布点を、密度とバイオーム属性を持つ軽量な可視プロキシピラミッドへ変換します。間隔、スケール、LOD、可視性をすぐ確認できます。', 'Copy the bundled icon reference sheet to the Smart Geometry user_default data folder. The icons are suite-owned borderless high-fill images for readable large action buttons.': '同梱のアイコンリファレンスシートをSmart Geometryのuser_defaultデータフォルダへコピーします。アイコンはツールセット所有の枠無し高充填画像で、大型操作ボタン用に視認性を高めています。', 'Create a combined helper mesh of density-ranked, normal-aligned surface detail blocks from active mesh faces or a fallback grid. Use this for mechanical panels, facade articulation, kitbash previews, and material-breakup tests.': 'アクティブメッシュ面またはフォールバックグリッドから、密度順位付きで法線整列した表面ディテールブロックの統合補助メッシュを作成します。機械パネル、ファサード、キットバッシュプレビュー、マテリアル分割テストに使います。', 'Create a compact Smart Geometry demonstration: terrain, standard attributes, environment modifiers, scatter points, greeble blocks, ivy/root curve, building proxy, and reports.': 'Smart Geometryの小型デモを作成します。地形、標準属性、環境モディファイア、散布点、グリーブルブロック、蔦/根カーブ、建築プロキシ、レポートを生成します。', 'Create a weighted surface point-cloud from the active mesh or a fallback grid. The generator uses face area, density, habitat, slope, blue-noise rejection, normal offsets, source-face IDs, tangent vectors, visibility, and distribution diagnostics.': 'アクティブメッシュまたはフォールバックグリッドから重み付き表面点群を作成します。面積、密度、生息適性、傾斜、ブルーノイズ除外、法線オフセット、ソース面ID、接線、可視性、分布診断を利用します。', 'Create and update the dense Smart Geometry attribute layer on the active mesh: ID, density, mask, variation, height, slope, curvature, convexity, boundary, edge distance, valence, ambient, wetness, flow, erosion, sediment, biome, LOD, cull, material, watershed, contour, and quality fields.': 'アクティブメッシュ上の高密度Smart Geometry属性レイヤーを作成・更新します。ID、密度、マスク、バリエーション、高さ、傾斜、曲率、凸度、境界、エッジ距離、価数、環境、湿り、流れ、侵食、堆積、バイオーム、LOD、カリング、マテリアル、流域、等高線、品質フィールドを扱います。', 'Create clustered fragment helper objects from active mesh faces and assign stable sgs_piece_id, variation, and fragment-mass attributes. This preserves multi-face clusters where possible for more usable separation previews.': 'アクティブメッシュ面からクラスタ破片の補助オブジェクトを作成し、安定したsgs_piece_id、variation、fragment-mass属性を割り当てます。可能な限り複数面クラスタを保ち、分離プレビューを扱いやすくします。', 'Create multi-branch organic growth curve helpers for ivy, roots, cables, veins, or trail-style guides around the active object. The curves are generated deterministically from the suite seed and can be converted or consumed by Geometry Nodes.': 'アクティブオブジェクト周辺に、蔦、根、ケーブル、葉脈、軌跡ガイド用の複数枝有機成長カーブヘルパーを作成します。カーブはツールセットのシードから決定論的に生成され、変換またはGeometry Nodes入力に使えます。', 'Create or refresh a normalized debug color attribute on the active mesh from the selected SGS attribute. This helps inspect density, slope, flow, roughness, channels, selection, or any numeric attribute directly in the scene.': '選択したSGS属性から、アクティブメッシュ上に正規化されたデバッグカラー属性を作成または更新します。密度、傾斜、流れ、粗さ、水路、選択、任意の数値属性をシーン上で直接確認できます。', 'Create or refresh every Smart Geometry node capsule and pack controller as reusable Geometry Nodes node groups. This does not alter scene objects unless asset marking is enabled for the generated groups.': 'Smart Geometryの全ノードカプセルとパックコントローラーを、再利用可能なGeometry Nodesノードグループとして作成または更新します。生成グループのアセット化が有効でない限り、シーンオブジェクトは変更しません。', 'Create downhill flow curves from the active mesh using sgs_height, sgs_flow, and sgs_channel. Use this after terrain generation or precision attribute refinement to visualize drainage and channel guides.': 'sgs_height、sgs_flow、sgs_channelを使って、アクティブメッシュから下り方向フローカーブを作成します。地形生成や精度属性再構築後に、排水と水路ガイドを可視化するために使います。', 'Default radius, spacing, or helper-object size used by scatter, growth, surface-detail, visible proxy, and fragmentation tools. Keep this near the visible asset footprint for better spacing.': '散布、成長、表面ディテール、可視プロキシ、破片化で使う既定の半径、間隔、補助オブジェクトサイズです。見えるアセットの占有幅に近づけると間隔が整いやすくなります。', 'Deterministic seed used by generated attributes, terrain noise, point placement, surface-detail blocks, fragments, growth curves, and visible proxy instances.': '生成属性、地形ノイズ、点配置、表面ディテールブロック、破片、成長カーブ、可視プロキシインスタンスで使う決定論的シードです。', 'Displays the suite-owned borderless maximum-fill icon artwork on command buttons. The icon images contain no frame and the graphic fills the 128 px canvas as much as possible for readability.': 'ツールセット所有の枠無し最大充填アイコン画像をコマンドボタンに表示します。アイコン画像は枠を含まず、読みやすさのため図形がキャンバスを可能な限り大きく占めます。', 'Documents the intended fill ratio of the bundled icon artwork. The PNG files are generated without frames and their figure occupies nearly the full transparent canvas for high readability.': '同梱アイコン画像の想定充填率を示します。PNGは枠無しで生成され、図形が透明キャンバスのほぼ全体を占めるため高い視認性を保ちます。', 'Drainage Curve Count': '排水カーブ数', 'Duplicate the active mesh data into a frozen inspection object, preserve SGS attributes, and apply a debug heatmap. Use this before destructive tests or after generating terrain, scatter, or fragments.': 'アクティブメッシュデータを凍結検査用オブジェクトとして複製し、SGS属性を保持してデバッグヒートマップを適用します。破壊的テスト前や地形、散布、破片生成後に使います。', 'Filters the catalog by functional family. This only changes the displayed list and never deletes, disables, or modifies generated node groups.': '機能カタログを機能ファミリーで絞り込みます。表示リストだけを変更し、生成済みノードグループの削除、無効化、変更は行いません。', 'Filters the catalog by independent design domain such as attributes, selection, terrain, motion, architecture, materials, diagnostics, automation, or open data.': '属性、選択、地形、モーション、建築、マテリアル、診断、自動化、外部データなどの独自設計ドメインでカタログを絞り込みます。', 'Force-rebuild every generated Smart Geometry node group and pack controller. Use this after updating the add-on or changing the capsule prefix.': '生成済みのSmart Geometryノードグループとパックコントローラーをすべて強制再構築します。アドオン更新後やカプセル接頭辞変更後に使います。', 'Generate a tiered modular structure mesh with floor modules, facade protrusions, roof modules, module IDs, module kinds, and dense standard attributes. Use it for independent architecture blockouts and procedural facade tests.': '床モジュール、ファサード突起、屋上モジュール、モジュールID、モジュール種別、高密度標準属性を持つ段状モジュラー構造メッシュを生成します。独自建築ブロックアウトやプロシージャルファサードテストに使います。', 'Generate an editable precision heightfield terrain mesh with deterministic multi-octave noise, thermal relaxation, flow accumulation, sediment, wetness, erosion, slope, convexity, watershed, contours, material masks, and readability fields.': '決定論的マルチオクターブノイズ、熱緩和、流量蓄積、堆積、湿り、侵食、傾斜、凸度、流域、等高線、マテリアルマスク、読みやすさフィールドを持つ編集可能な高精度ハイトフィールド地形メッシュを生成します。', 'Global intensity for the precision polish. Higher values strengthen distribution priority, material-region contrast, contact scoring, and debug quality while keeping generated attributes deterministic and Blender-native.': '精度ポリッシュの全体強度です。値を高くすると、生成属性を決定論的かつBlenderネイティブに保ちながら、分布優先度、マテリアル領域コントラスト、接触スコア、デバッグ品質を強化します。', 'Global strength for the operation-grade quality layer. Higher values make confidence, stability, distribution, material, hydrology, and diagnostic scores more decisive.': '操作品質レイヤーの全体強度です。値を高くすると、信頼度、安定性、分布、マテリアル、水文、診断スコアの判定がより明確になります。', 'Icon Button Scale': 'アイコンボタン倍率', 'Maximum number of deterministic primary channel walkers used by the terrain pass. Increase for denser river networks; decrease for faster or drier terrain.': '地形パスで使う決定論的な主要水路ウォーカーの最大数です。密な河川ネットワークには増やし、高速または乾いた地形には減らします。', 'Maximum number of downhill flow curves generated from high-flow terrain or mesh attributes. Use this after building precision attributes or terrain to visualize drainage and channel guides.': '高流量の地形またはメッシュ属性から生成する下り方向フローカーブの最大数です。精度属性または地形を作成した後、排水や水路ガイドの可視化に使います。', 'Maximum number of object and attribute samples written into diagnostics reports. Increase for deeper audits and decrease to keep reports compact.': '診断レポートに書き込むオブジェクトと属性サンプルの最大数です。詳細監査では増やし、レポートを軽く保つ場合は減らします。', 'Maximum procedural displacement height used by the terrain generator. This writes height, slope, flow, wetness, sediment, erosion, channel, stream, bank, and strata attributes for later scattering and materials.': '地形生成で使う最大プロシージャル変位高さです。後続の散布やマテリアルで使う高さ、傾斜、流れ、湿り、堆積、侵食、水路、流路、河岸、地層属性を書き込みます。', 'Minimum world-space distance between accepted scatter points when blue-noise mode is enabled. Use this to reduce overlaps and produce cleaner environment distributions.': 'ブルーノイズモードが有効なとき、採用される散布点同士の最小ワールド空間距離です。重なりを減らし、より整った環境分布を作るために使います。', 'Neighborhood radius used by stability, saliency, and field-coherence approximations. Larger values produce broader, smoother masks; smaller values preserve sharp local details.': '安定性、注目度、フィールド整合性近似で使う近傍半径です。大きい値では広く滑らかなマスクになり、小さい値では鋭い局所ディテールを保ちます。', 'Number of deterministic branch splines created by the organic growth curve builder. More branches produce denser ivy, root, cable, vein, or trail-style guides.': '有機成長カーブビルダーが作成する決定論的な枝スプライン数です。多くすると蔦、根、ケーブル、葉脈、軌跡ガイドが密になります。', 'Number of deterministic water-drop walkers used by the terrain solver. Higher values carve cleaner channels, banks, deposition fields, and stream-order attributes, but increase generation time.': '地形ソルバーで使う決定論的な水滴ウォーカー数です。値を高くすると水路、河岸、堆積場、流路次数属性が整いますが、生成時間は増えます。', 'Number of grid points per side when generating precision terrain. Higher values create more vertices and richer terrain attributes but take longer to compute.': '高精度地形を生成するときの一辺あたりのグリッド点数です。値を高くすると頂点と地形属性が増えますが、計算時間も長くなります。', 'Number of lightweight quality analysis passes applied when refining selected meshes. Higher values improve smoothed fields and risk suppression at the cost of additional computation.': '選択メッシュを再構築するときに適用する軽量品質解析パス数です。値を高くすると平滑化フィールドとリスク抑制が改善しますが、計算量が増えます。', 'Number of post-placement relaxation passes for point distributions. This reduces residual clumping after blue-noise rejection and improves spacing regularity.': '点分布の配置後緩和パス数です。ブルーノイズ除外後に残る偏りを減らし、間隔の規則性を改善します。', 'Number of stable material-region IDs generated by the material composer. These IDs can drive procedural material masks and neutral export primvars.': 'マテリアルコンポーザーが生成する安定したマテリアル領域ID数です。これらのIDはプロシージャルマテリアルマスクや中立的な書き出しprimvarに利用できます。', 'Number of thermal relaxation passes used before hydraulic flow and sediment attributes are calculated. Increase for smoother eroded ridges; decrease for faster previews.': '水理フローと堆積属性を計算する前に行う熱緩和パス数です。滑らかな侵食稜線には増やし、高速プレビューには減らします。', 'Offsets generated scatter points along the sampled surface normal. Use a small positive value to keep preview points or instances above the source surface.': '生成した散布点をサンプル面の法線方向へずらします。小さな正の値を使うと、プレビュー点やインスタンスを元サーフェスより少し上に保てます。', 'Open the visual reference popup. It displays generated borderless custom icons and icon-only workflow diagrams so the command deck can be understood without copying another product UI.': 'ビジュアルリファレンスポップアップを開きます。生成済みの枠無しカスタムアイコンとアイコンのみのワークフロー図を表示し、他製品UIをコピーせずにコマンドデッキを理解できるようにします。', 'Optional feature ID to apply. Leave empty to use the active feature selected in the Smart Geometry panel.': '適用する任意の機能IDです。空欄の場合はSmart Geometryパネルで選択中のアクティブ機能を使います。', 'Optional lightweight hydraulic transport pass count used by precision terrain helpers. Higher values sharpen channels and sediment maps when helper functions use this control.': '高精度地形ヘルパーが使う任意の軽量水理輸送パス数です。この制御を使う補助関数では、値を高くすると水路と堆積マップが明瞭になります。', 'Optional pack ID to apply. Leave empty to use the active pack selected in the Smart Geometry panel.': '適用する任意のパックIDです。空欄の場合はSmart Geometryパネルで選択中のアクティブパックを使います。', 'Optional path to a CSV file containing x, y, z columns and optional id, scale, density, and custom numeric columns. The Import CSV Points operator also provides a file browser.': 'x、y、z列と任意のid、scale、density、カスタム数値列を含むCSVファイルのパスです。CSVポイント読み込みオペレーターではファイルブラウザーも使えます。', 'Pack ID': 'パックID', 'Parse the panel expression and write it to the sgs_selection attribute and SGS Selection vertex group on the active mesh. Supports index ranges, invert:, density/height/slope/curvature comparisons, boundary, interior, bands, ranks, grow, shrink, and boolean logic.': 'パネルの式を解析し、アクティブメッシュのsgs_selection属性とSGS Selection頂点グループへ書き込みます。インデックス範囲、invert:、density/height/slope/curvature比較、boundary、interior、band、rank、grow、shrink、論理演算に対応します。', 'Precision preset to apply: preview, production, or extreme. Leave empty to use the preset selected in the panel.': '適用する精度プリセットです。preview、production、extremeを指定できます。空欄の場合はパネルで選択中のプリセットを使います。', 'Prefix used for generated node groups, Geometry Nodes modifiers, helper objects, reports, and attributes. A unique prefix makes generated data easy to locate and remove.': '生成ノードグループ、Geometry Nodesモディファイア、補助オブジェクト、レポート、属性に使う接頭辞です。固有の接頭辞にすると生成データの検索と削除が容易になります。', 'Prefix used when Smart Geometry creates node groups, Geometry Nodes modifiers, generated objects, reports, and helper data. Keep this unique so generated data is easy to find and remove.': 'Smart Geometryがノードグループ、Geometry Nodesモディファイア、生成オブジェクト、レポート、補助データを作成するときに使う接頭辞です。生成データを見つけやすく削除しやすいよう、固有にしてください。', 'Preset ID': 'プリセットID', 'Prioritizes stable, visible, high-confidence regions when scoring distribution points. Increase when generated proxies or instancing should avoid risky surfaces.': '分布点を評価するとき、安定・可視・高信頼領域を優先します。生成プロキシやインスタンスをリスクのある面から避けたい場合に上げます。', 'Read a CSV file and create a point-cloud mesh from x, y, and z columns. Optional id, scale, density, and numeric custom columns are preserved as neutral named attributes for point-driven workflows.': 'CSVファイルを読み込み、x、y、z列から点群メッシュを作成します。任意のid、scale、density、数値カスタム列は、点駆動ワークフロー用の中立的な名前付き属性として保持されます。', 'Rebuild the hyper-precision attribute layer on the selected mesh objects, including topology, flow direction, channel, habitat, stability, cavity, occlusion, thickness, LOD, culling, material, and debug fields.': '選択メッシュオブジェクト上に、トポロジー、流向、水路、生息適性、安定性、窪み、遮蔽、厚み、LOD、カリング、マテリアル、デバッグフィールドを含むハイパープレシジョン属性レイヤーを再構築します。', 'Rejects scatter candidates that are too close to accepted points. This improves distribution quality and avoids obvious clumping at the cost of additional computation.': '採用済み点に近すぎる散布候補を拒否します。追加計算は必要ですが、分布品質を高め、目立つ塊を避けられます。', 'Reload the bundled custom preview icons used by the visual dashboard and large icon buttons.': 'ビジュアルダッシュボードと大型アイコンボタンで使う同梱カスタムプレビューアイコンを再読み込みします。', 'Remove node groups generated by Smart Geometry. This does not delete scene objects, meshes, or user-authored node groups that are not stamped with the suite marker.': 'Smart Geometryが生成したノードグループを削除します。シーンオブジェクト、メッシュ、またはツールセットマーカーのないユーザー作成ノードグループは削除しません。', 'Run a polished icon-driven workflow: scene refinement, environment generation, surface design, fragmentation, or diagnostics. The workflow uses independent Smart Geometry tools and avoids hidden persistent processing.': 'アイコン駆動の整理されたワークフローを実行します。シーン再構築、環境生成、表面設計、破片化、診断に対応します。ワークフローは独立したSmart Geometryツールを使い、隠れた常時処理を避けます。', 'Run the blue-noise and tangent relaxation pass on the active point-cloud mesh. This improves residual spacing after point import or surface distribution and writes sgs_relaxed and spacing diagnostics.': 'アクティブな点群メッシュにブルーノイズと接線緩和パスを実行します。点読み込み後や表面分布後に残る間隔を改善し、sgs_relaxedと間隔診断を書き込みます。', 'Run the operation-grade precision polish on selected mesh objects. It rebuilds dense SGS attributes and adds smoothed density, curvature coherence, contact score, material region, remesh size, quality grade, interaction score, artifact risk, and safety metadata.': '選択メッシュオブジェクトに操作品質精度ポリッシュを実行します。高密度SGS属性を再構築し、平滑密度、曲率整合性、接触スコア、マテリアル領域、リメッシュサイズ、品質グレード、操作スコア、アーティファクトリスク、安全性メタデータを追加します。', 'Selection expression for the precision selection engine. Supported forms include all, none, even, odd, active, ranges such as 2-15, invert:0-9, density>0.5, height:0.2-0.8, slope<0.4, boundary, interior, highest(density,0.25), lowest(), band(), rank(), grow(), shrink(), and boolean combinations with and/or/xor/except.': '高精度選択エンジンで使う選択式です。all、none、even、odd、active、2-15のような範囲、invert:0-9、density>0.5、height:0.2-0.8、slope<0.4、boundary、interior、highest(density,0.25)、lowest()、band()、rank()、grow()、shrink()、and/or/xor/exceptの論理結合に対応します。', 'Selects a predefined group of feature capsules. Packs are workflow stacks such as core attributes, environment generation, motion FX, architecture, interop, or precision-overdrive workflows.': '定義済みの機能カプセルグループを選択します。パックは、コア属性、環境生成、モーション表現、建築、外部連携、精度強化などのワークフロースタックです。', 'Selects the feature capsule to apply or inspect. Each item maps a researched functional requirement to an independent Blender-safe Geometry Nodes workflow with its own naming, metadata, and generated node group.': '適用または確認する機能カプセルを選択します。各項目は調査済みの機能要件を、独自名称、メタデータ、生成ノードグループを持つBlender安全なGeometry Nodesワークフローへ対応付けています。', 'Shows advanced controls, design coverage, requirement metadata, generated IDs, and technical diagnostics in the Smart Geometry panels.': 'Smart Geometryパネルに、詳細設定、設計カバー範囲、要件メタデータ、生成ID、技術診断を表示します。', 'Shows generated visual reference panels that explain the Smart Geometry workflow using icon-only diagrams rather than embedded text.': '埋め込み文字ではなくアイコンのみの図でSmart Geometryワークフローを説明する、生成済みビジュアルリファレンスパネルを表示します。', 'Shows large icon-only reference diagrams inside the Visual UI panel. The diagrams contain no embedded two-language text so the UI language remains controlled by Blender localization.': 'ビジュアルUIパネル内に、大型のアイコンのみリファレンス図を表示します。図には二言語併記の文字を埋め込まず、UI言語はBlenderのローカライズで制御します。', 'Shows the command dashboard with large custom preview icons. Icons are transparent, borderless image assets with their glyphs scaled close to the full canvas for maximum readability.': '大型カスタムプレビューアイコン付きのコマンドダッシュボードを表示します。アイコンは透明で枠無しの画像資産で、最大の読みやすさのため図形がキャンバス近くまで拡大されています。', 'Shows the command ribbon with very large borderless icon previews. Use it when you want fast one-click access to the main procedural workflows without scanning dense technical controls.': '非常に大きい枠無しアイコンプレビュー付きのコマンドリボンを表示します。密な技術設定を探さず、主要プロシージャルワークフローへワンクリックでアクセスしたいときに使います。', 'Strength of the hydraulic channel and deposition pass. Use values near 1 for natural terrain, lower values for subtle erosion, and higher values for stronger river cuts.': '水路と堆積パスの強度です。自然な地形には1付近、控えめな侵食には低い値、強い河川カットには高い値を使います。', 'Strength of the post-terrain fusion pass. Higher values reinforce channel, watershed, contour, patch, material, and distribution handoff attributes after terrain generation or precision refinement.': '地形後フィールド融合パスの強度です。値を高くすると、地形生成または精度再構築後の水路、流域、等高線、パッチ、マテリアル、分布受け渡し属性が強化されます。', 'Target amount used by surface distribution, helper blocks, growth curves, and visible proxy instances. Distribution may create fewer points when blue-noise spacing rejects overcrowded samples.': '表面分布、補助ブロック、成長カーブ、可視プロキシインスタンスで使う目標数です。ブルーノイズ間隔で過密サンプルが拒否される場合、生成点数が少なくなることがあります。', 'Target number of clustered mesh fragments created by the precision fragmentation builder. A value of zero chooses the amount automatically from the face count of the mesh.': '高精度破片化ビルダーが作成するクラスタメッシュ破片の目標数です。0の場合はメッシュの面数から自動で決めます。', 'Threshold used by density, selection, habitat, scatter, and visibility tools. Values below the threshold are treated as less likely to generate or be selected.': '密度、選択、生息環境、散布、可視性ツールで使うしきい値です。しきい値未満の値は、生成または選択されにくいものとして扱われます。', 'Type a feature name, design domain, keyword, category, or Japanese term to narrow the visible catalog. Leave empty to show all features matching the other filters.': '機能名、設計ドメイン、キーワード、カテゴリ、日本語語句を入力して表示カタログを絞り込みます。空欄の場合は他フィルターに一致する全機能を表示します。', 'Use Custom Icon Buttons': 'カスタムアイコンボタンを使用', 'Uses Blender borderless operator buttons where possible. The button area remains clickable, while the custom icon artwork itself contains no frame and occupies the maximum available figure size.': '可能な場合はBlenderの枠無しオペレーターボタンを使います。ボタン領域はクリック可能なまま、カスタムアイコン画像自体は枠を持たず、利用可能な図形サイズを最大限占めます。', 'Vertical scale used by the large visual command buttons. Increase this when using a high-DPI monitor or when the sidebar is wide enough for large icon-first operation.': '大型ビジュアルコマンドボタンで使う縦方向倍率です。高DPIモニターを使う場合や、サイドバー幅が十分ありアイコン優先操作を大きく見せたい場合に上げます。', 'When a scene camera exists, lowers or rejects distribution on surfaces outside the camera frustum by using the sgs_visibility attribute. Disable for full-world generation.': 'シーンカメラがある場合、sgs_visibility属性を使ってカメラ視錐台外のサーフェス上の分布を低評価または拒否します。ワールド全体を生成する場合は無効にします。', 'When enabled, newly generated Geometry Nodes node groups are marked as Blender assets so they can be reused through the Asset Browser or node group workflows when supported by the current Blender build.': '有効にすると、新規生成されたGeometry NodesノードグループをBlenderアセットとしてマークします。現在のBlenderが対応していれば、Asset Browserやノードグループワークフローで再利用できます。', 'When enabled, newly generated node groups are marked as Blender assets if the current Blender build supports asset marking. Disable this when creating temporary test groups.': '有効にすると、現在のBlenderがアセットマークに対応している場合、新規生成ノードグループをBlenderアセットとして登録します。一時テスト用グループを作るときは無効にします。', 'Workflow to run: refine, environment, surface, fragment, diagnose, or full_demo.': '実行するワークフローです。refine、environment、surface、fragment、diagnose、full_demoを指定できます。', 'World size of the generated terrain grid. Use larger values for landscape blockouts and smaller values for material or habitat tests.': '生成地形グリッドのワールドサイズです。景観ブロックアウトでは大きい値を、マテリアルや生息環境テストでは小さい値を使います。', 'Write a USD-oriented JSON sidecar manifest describing suggested primvars, Smart Geometry attributes, generated node groups, and neutral open-data metadata. This does not write a native USD stage.': '推奨primvar、Smart Geometry属性、生成ノードグループ、中立的な外部データメタデータを記述したUSD向けJSONサイドカーマニフェストを書き出します。ネイティブUSDステージは作成しません。', 'Write a neutral JSON manifest describing generated node groups, feature packs, design coverage, objects, attributes, and diagnostics for sharing or auditing suite-generated data.': '共有または監査用に、生成ノードグループ、機能パック、設計カバー範囲、オブジェクト、属性、診断を記述した中立JSONマニフェストを書き出します。', 'Write scene diagnostics including generated objects, mesh attributes, modifiers, node groups, and heat-map approximation scores to the extension user_default compatible reports folder.': '生成オブジェクト、メッシュ属性、モディファイア、ノードグループ、ヒートマップ近似スコアを含むシーン診断を、Extension user_default互換のレポートフォルダへ書き出します。', 'Write the complete Smart Geometry feature inventory to the extension user_default compatible reports folder. Use this to audit every independent feature capsule, native workflow, and design-domain mapping.': '完全なSmart Geometry機能インベントリを、Extension user_default互換のレポートフォルダへ書き出します。独自機能カプセル、ネイティブワークフロー、設計ドメイン対応の監査に使います。', 'Write the independent design coverage matrix extracted from the uploaded research document. This verifies that every listed requirement is represented by a uniquely named suite capsule.': 'アップロードされた調査資料から抽出した独自設計カバー行列を書き出します。リスト化された各要件が、独自名のツールセットカプセルとして表現されていることを確認できます。', 'apply': '適用', 'attributes': '属性', 'csv': 'CSV', 'dashboard': 'ダッシュボード', 'diagnostics': '診断', 'export': '書き出し', 'flow': 'フロー', 'fragment': '破片', 'greeble': 'グリーブル', 'growth': '成長', 'heatmap': 'ヒートマップ', 'help': 'ヘルプ', 'library': 'ライブラリ', 'overdrive': 'オーバードライブ', 'pack': 'パック', 'precision': '精度', 'reference': 'リファレンス', 'refine': '再構築', 'relax': '緩和', 'scatter': '散布', 'selection': '選択', 'settings': '設定', 'snapshot': 'スナップショット', 'structure': '構造', 'terrain': '地形', 'visual': 'ビジュアル'})

_STATIC.update({
    'Migrated Geometry-Node Generators': '移植済みジオメトリノード生成ツール',
    'These tools were moved from Smart Modeling Suite and are now owned by Smart Geometry Suite.': 'これらのツールは Smart Modeling Suite から移動し、現在は Smart Geometry Suite 側の機能として管理されます。',
    'Max Primitives': 'Maxプリミティブ',
    'Open Max Primitives Menu': 'Maxプリミティブメニューを開く',
    'Box': 'ボックス',
    'Sphere': '球',
    'Cylinder': '円柱',
    'Wall': '壁',
    'Install Assets': 'アセットをインストール',
    'Update All': '全て更新',
    'Grease Mesh': 'グリースメッシュ',
    'Create mesh or Geometry Nodes modifiers from Grease Pencil strokes.': 'Grease Pencil ストロークからメッシュまたはジオメトリノードモディファイアを作成します。',
    'Add GP': 'GP追加',
    'Apply Modifiers': 'モディファイア適用',
    'Solid Mesh': 'ソリッドメッシュ',
    'Mirror Mesh': 'ミラーメッシュ',
    'Path Mesh': 'パスメッシュ',
    'Wall Mesh': '壁メッシュ',
    'Scatter': '散布',
    'Array on Pencil': 'ペンシル上に配列',
    'Add New Grease Pencil': '新規グリースペンシルを追加',
    'Apply All Modifiers': '全モディファイアを適用',
    'Array on Curve': 'カーブ上に配列',
    'Bool Cut': 'ブールカット',
    'Mirror Mesh (GN)': 'ミラーメッシュ（GN）',
    'Path Mesh (GN)': 'パスメッシュ（GN）',
    'Solid Mesh (GN)': 'ソリッドメッシュ（GN）',
    'Wall Mesh (GN)': '壁メッシュ（GN）',
    'Knife Cut': 'ナイフカット',
    'Lattice Wrap': 'ラティスラップ',
    'Create Screw Mesh': 'スクリューメッシュを作成',
    'Stamp Scatter': 'スタンプ散布',
    'Create': '作成',
    'Mesh from GP': 'GPからメッシュ生成',
    'Solid': 'ソリッド',
    'Mirror': 'ミラー',
    'Path': 'パス',
    'Screw Mesh': 'スクリューメッシュ',
    'Screw': 'スクリュー',
    'Other': 'その他',
    'Experimental': '実験的',
    'Add a new Grease Pencil object for sketch-to-mesh generation. Use this first when you want to draw strokes that will later become mesh or Geometry Nodes generated geometry.': 'スケッチからメッシュ生成するための新規 Grease Pencil オブジェクトを追加します。後でメッシュまたは Geometry Nodes 生成形状に変換するストロークを描く時に最初に使います。',
    'Apply all modifiers on the active Grease Mesh result. Use this when the generated Geometry Nodes preview is final and you want real editable mesh data.': 'アクティブな Grease Mesh 結果にある全モディファイアを適用します。Geometry Nodes の生成プレビューが確定し、実際に編集できるメッシュデータにしたい時に使います。',
    'Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path. Select or create a Grease Pencil stroke before running this command.': 'Grease Pencil ストロークからカーブパス上の配列風 Geometry Nodes セットアップを作成します。実行前に Grease Pencil ストロークを選択または作成してください。',
    'Cut selected mesh geometry using Grease Pencil stroke shapes. Adjust depth and resolution to control the generated cutter thickness and smoothness.': 'Grease Pencil ストローク形状を使って選択メッシュをカットします。生成カッターの厚みや滑らかさは深度と解像度で調整します。',
    'Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh. Use this for symmetrical sketch-based mesh blocking.': 'Grease Pencil ストローク形状をメッシュとしてミラー生成する Geometry Nodes モディファイアを追加します。左右対称のスケッチベースブロックアウトに使います。',
    'Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes. Use this for pipes, trims, cables, and stroke-based strips.': 'Grease Pencil のパスストロークに沿ってメッシュ形状をスイープする Geometry Nodes モディファイアを追加します。パイプ、トリム、ケーブル、ストロークベースの帯に使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry. Use this for quick sketch-to-solid blocking.': 'Grease Pencil ストロークをソリッドなメッシュ形状へ変換する Geometry Nodes モディファイアを追加します。素早いスケッチからソリッド形状へのブロックアウトに使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry. Use this for quick architectural blocking.': 'Grease Pencil の平面図ストロークを壁状メッシュへ変換する Geometry Nodes モディファイアを追加します。素早い建築ブロックアウトに使います。',
    'Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing. Enable cut-through when the stroke should affect geometry behind the visible front surface.': 'Grease Pencil ストロークガイドを、メッシュ編集用のナイフカット補助として使います。見えている前面の奥にある形状も切る場合は貫通カットを有効にします。',
    'Create a lattice-based wrap helper around selected geometry. Use this for broad deformation after sketch or mesh generation.': '選択形状の周囲にラティスベースのラップ補助を作成します。スケッチ生成またはメッシュ生成後の大まかな変形に使います。',
    'Create lathe-style screw mesh geometry from a Grease Pencil profile. Use this for revolved forms such as knobs, cups, vases, and turned parts.': 'Grease Pencil の輪郭から旋盤風のスクリューメッシュ形状を作成します。ノブ、カップ、花瓶、旋削部品のような回転形状に使います。',
    'Scatter stamped mesh instances from Grease Pencil stroke input. Use this for quick distribution of repeated sketch-based elements.': 'Grease Pencil ストローク入力からスタンプ状のメッシュインスタンスを散布します。繰り返し配置するスケッチベース要素を素早く分布させる時に使います。',
})
_STATIC.update({
    'Terrain / Environment Generators': '地形 / 環境生成',
    'Distribution / Scatter Generators': '分布 / 散布生成',
    'Structure / Surface Generators': '構造 / 表面生成',
    'Organic / Stroke Generators': '有機 / ストローク生成',
    'Debris / Fragment Generators': 'デブリ / 破砕生成',
    'Primitive Generators': 'プリミティブ生成',
    'Settings': '設定',
    'Terrain Mesh': '地形メッシュ',
    'Drainage Flow Curves': '排水フローカーブ',
    'Surface Distribution Points': '表面分布ポイント',
    'Relax and Preview Instances': '緩和とプレビューインスタンス',
    'CSV Point Cloud': 'CSVポイントクラウド',
    'Surface Detail Blocks': '表面ディテールブロック',
    'Modular Structure': 'モジュラー構造',
    'Organic Growth Curves': '有機成長カーブ',
    'Grease Pencil Mesh Generators': 'Grease Pencilメッシュ生成',
    'Debris Module Generator': 'デブリモジュール生成',
    'Mesh Fragment Generator': 'メッシュ破砕生成',
    'Max Primitive Generators': 'Maxプリミティブ生成',
    'Interface': 'インターフェース',
    'Node Library and Assets': 'ノードライブラリとアセット',
    'Feature / Pack Apply': '機能 / パック適用',
    'Precision Attributes and Selection': '精度属性と選択',
    'Diagnostics and Cleanup': '診断とクリーンアップ',
    'Import / Export Manifests': '読み込み / 書き出しマニフェスト',
    'Debris Utility Settings': 'デブリ補助設定',
    'Visual Reference': 'ビジュアルリファレンス',
    'Coverage Summary': 'カバー範囲サマリー',
    'Creates a terrain mesh. The settings below are the values read by this generator.': '地形メッシュを作成します。下の設定はこの生成処理が実際に参照する値です。',
    'Creates downhill guide curves from the active mesh terrain attributes.': 'アクティブメッシュの地形属性から下り方向のガイドカーブを作成します。',
    'Creates a point-cloud mesh from the active surface or a fallback grid.': 'アクティブな表面またはフォールバックグリッドからポイントクラウドメッシュを作成します。',
    'Relaxes generated points or creates lightweight visible proxy instances for distribution checking.': '生成済みポイントを緩和するか、分布確認用の軽量な可視プロキシインスタンスを作成します。',
    'Imports x, y, z CSV columns as a generated point-cloud mesh.': 'CSVのx, y, z列を生成ポイントクラウドメッシュとして読み込みます。',
    'Creates density-ranked helper blocks on the active surface or fallback grid.': 'アクティブ表面またはフォールバックグリッド上に、密度順の補助ブロックを作成します。',
    'Generates a tiered modular structure mesh with Smart Geometry attributes.': 'Smart Geometry属性付きの階層型モジュラー構造メッシュを生成します。',
    'Creates procedural curves for ivy, roots, cables, veins, or trail guides.': '蔦、根、ケーブル、脈、軌跡ガイド用のプロシージャルカーブを作成します。',
    'Creates mesh or Geometry Nodes results from Grease Pencil strokes. These operators use the selected stroke/object context and do not require SGS numeric parameters.': 'Grease PencilストロークからメッシュまたはGeometry Nodes結果を作成します。これらの処理は選択中のストローク/オブジェクト状態を使用し、SGS数値パラメータは不要です。',
    "Choose one debris module; only that module's active settings are shown before generation.": 'デブリモジュールを1つ選ぶと、そのモジュールに必要な設定だけを表示して生成します。',
    'Creates clustered fragment helper objects from the active mesh faces.': 'アクティブメッシュの面からクラスタ化された破片補助オブジェクトを作成します。',
    'Creates primitive and AEC-style generator objects from the integrated Max Primitives toolset.': '統合されたMax Primitivesツールセットから、プリミティブやAEC系生成オブジェクトを作成します。',
    'Top-level generation sections stay separate; non-generation controls are consolidated here.': '最上層の生成セクションは分離し、生成以外の操作はここに集約しています。',
    'Use search to narrow the advanced feature list.': '詳細機能一覧は検索で絞り込んでください。',
    'Live sidebar buttons use Blender standard icons; visual reference output remains optional.': 'ライブサイドバーのボタンはBlender標準アイコンを使用し、ビジュアルリファレンス出力は任意機能として残します。',
    'Show Terrain and Environment Generators Section': '地形 / 環境生成セクションを表示',
    'Show Distribution and Scatter Generators Section': '分布 / 散布生成セクションを表示',
    'Show Structure and Surface Generators Section': '構造 / 表面生成セクションを表示',
    'Show Organic and Stroke Generators Section': '有機 / ストローク生成セクションを表示',
    'Show Debris and Fragment Generators Section': 'デブリ / 破砕生成セクションを表示',
    'Show Primitive Generators Section': 'プリミティブ生成セクションを表示',
    'Show Settings Section': '設定セクションを表示',
    'Expand or collapse the terrain and environment generator section. It contains only direct generation commands for terrain meshes and drainage flow curves, with the parameters those generators actually read.': '地形 / 環境生成セクションを開閉します。地形メッシュと排水フローカーブを直接生成するコマンドだけを含み、それらの生成処理が実際に参照するパラメータを表示します。',
    'Expand or collapse the distribution generator section. It contains point-cloud, scatter, relaxation, proxy instance, and CSV point generation controls with the relevant distribution settings.': '分布生成セクションを開閉します。ポイントクラウド、散布、緩和、プロキシインスタンス、CSVポイント生成の操作と関連する分布設定を含みます。',
    'Expand or collapse the structure and surface generator section. It contains direct generation tools for surface detail blocks and modular structures with their own settings.': '構造 / 表面生成セクションを開閉します。表面ディテールブロックとモジュラー構造を直接生成するツールを、それぞれの設定と一緒に表示します。',
    'Expand or collapse the organic and stroke generator section. It contains organic curve creation and Grease Pencil to mesh generation commands.': '有機 / ストローク生成セクションを開閉します。有機カーブ作成とGrease Pencilからメッシュへの生成コマンドを含みます。',
    'Expand or collapse the debris and fragment generator section. It contains the integrated debris module generator and mesh fragmentation generator with only their generation settings.': 'デブリ / 破砕生成セクションを開閉します。統合デブリモジュール生成とメッシュ破砕生成を、それぞれの生成設定だけと一緒に表示します。',
    'Expand or collapse the primitive generator section. It contains direct Max Primitive creation commands without unrelated asset maintenance controls.': 'プリミティブ生成セクションを開閉します。関係のないアセット管理操作を除き、Max Primitiveの直接作成コマンドだけを表示します。',
    'Expand or collapse the consolidated settings section at the bottom of the Smart Geometry panel. Non-generation controls, diagnostics, reports, visual reference options, and advanced feature application tools are grouped here.': 'Smart Geometryパネル最下部の統合設定セクションを開閉します。生成以外の操作、診断、レポート、ビジュアルリファレンス、詳細な機能適用ツールをここにまとめます。',
    'Show Terrain Mesh Generator Child Section': '地形メッシュ生成子セクションを表示',
    'Show Drainage Flow Generator Child Section': '排水フロー生成子セクションを表示',
    'Show Surface Distribution Generator Child Section': '表面分布生成子セクションを表示',
    'Show Distribution Relax and Proxy Child Section': '分布緩和 / プロキシ子セクションを表示',
    'Show CSV Point Cloud Generator Child Section': 'CSVポイントクラウド生成子セクションを表示',
    'Show Surface Detail Generator Child Section': '表面ディテール生成子セクションを表示',
    'Show Modular Structure Generator Child Section': 'モジュラー構造生成子セクションを表示',
    'Show Organic Growth Generator Child Section': '有機成長生成子セクションを表示',
    'Show Stroke Mesh Generator Child Section': 'ストロークメッシュ生成子セクションを表示',
    'Show Debris Module Generator Child Section': 'デブリモジュール生成子セクションを表示',
    'Show Mesh Fragment Generator Child Section': 'メッシュ破砕生成子セクションを表示',
    'Show Max Primitive Generator Child Section': 'Maxプリミティブ生成子セクションを表示',
    'Show Interface Settings Child Section': 'インターフェース設定子セクションを表示',
    'Show Node Library Settings Child Section': 'ノードライブラリ設定子セクションを表示',
    'Show Feature and Pack Apply Child Section': '機能 / パック適用子セクションを表示',
    'Show Precision Tools Child Section': '精度ツール子セクションを表示',
    'Show Diagnostics and Cleanup Child Section': '診断 / クリーンアップ子セクションを表示',
    'Show Manifest Report Child Section': 'マニフェストレポート子セクションを表示',
    'Show Debris Utility Settings Child Section': 'デブリ補助設定子セクションを表示',
    'Show Visual Reference Settings Child Section': 'ビジュアルリファレンス設定子セクションを表示',
    'Show Coverage Summary Child Section': 'カバー範囲サマリー子セクションを表示',
    'Show Storage Path Child Section': '保存先パス子セクションを表示',
})
_translations = {'ja_JP': {}}
for en, ja in _STATIC.items():
    _translations['ja_JP'][('*', en)] = ja
try:
    from . import always_on as _always_on
    for _feature in _always_on.feature_definitions():
        _translations['ja_JP'][('*', _feature.label_en)] = _feature.label_ja
        _translations['ja_JP'][('*', _feature.description_en)] = _feature.description_ja
except Exception:
    pass
for feature in catalog.FEATURES:
    for key in ('label', 'summary', 'tooltip'):
        en = str(feature.get(f'{key}_en') or '')
        ja = str(feature.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for category in catalog.CATEGORIES:
    for key in ('label', 'summary'):
        en = str(category.get(f'{key}_en') or '')
        ja = str(category.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for pack in catalog.PACKS:
    for key in ('label', 'description'):
        en = str(pack.get(f'{key}_en') or '')
        ja = str(pack.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for feature in catalog.FEATURES:
    en = str(feature.get('design_domain_en') or '')
    ja = str(feature.get('design_domain_ja') or '')
    if en and ja:
        _translations['ja_JP'][('*', en)] = ja
I18N_DICT = _translations


# exact visible-text translation supplement.
_STATIC.update({'Controls how strongly distribution diagnostics account for normal, tangent, flow, and slope direction. Higher values improve directional placement quality for terrain and architectural surfaces.': '分布診断が法線、接線、流れ、傾斜方向をどれだけ考慮するかを制御します。値を高くすると地形や建築面での方向性配置品質が向上します。', 'Convert active distribution points into lightweight visible proxy pyramids with density and biome attributes. This provides an immediate quality check for spacing, scale, LOD, and habitat distribution before final instancing.': 'アクティブな分布点を、密度とバイオーム属性を持つ軽量な可視プロキシピラミッドへ変換します。最終インスタンス化の前に、間隔、スケール、LOD、生息環境分布をすぐ確認できます。', 'Create a compact Smart Geometry demonstration: terrain, standard attributes, environment modifiers, scatter points, greeble blocks, ivy/root curve, building proxy, and reports-ready metadata.': 'Smart Geometryの小型デモを作成します。地形、標準属性、環境モディファイア、散布点、グリーブルブロック、蔦/根カーブ、建築プロキシ、レポート用メタデータを生成します。', 'Create a weighted surface point-cloud from the active mesh or a fallback grid. The generator uses face area, density, habitat, slope, blue-noise rejection, normal offsets, source-face IDs, normals, scale, variation, LOD, and culling attributes.': 'アクティブメッシュまたはフォールバックグリッドから重み付き表面点群を作成します。面積、密度、生息適性、傾斜、ブルーノイズ除外、法線オフセット、ソース面ID、法線、スケール、バリエーション、LOD、カリング属性を使います。', 'Create and update the dense Smart Geometry attribute layer on the active mesh: ID, density, mask, variation, height, slope, curvature, convexity, boundary, edge distance, wetness, flow, erosion, sediment, biome, LOD, culling, ambient, and selection. Use this before distribution, habitat, visibility, material, or diagnostic workflows.': 'アクティブメッシュ上の高密度Smart Geometry属性レイヤーを作成・更新します。ID、密度、マスク、バリエーション、高さ、傾斜、曲率、凸度、境界、エッジ距離、湿り、流れ、侵食、堆積、バイオーム、LOD、カリング、環境、選択を扱います。分布、生息環境、可視性、マテリアル、診断ワークフローの前に使います。', 'Create downhill flow curves from the active mesh using sgs_height, sgs_flow, and sgs_channel. Use this after terrain generation or precision attribute refinement to visualize erosion channels, wear paths, and water-flow guides.': 'sgs_height、sgs_flow、sgs_channelを使って、アクティブメッシュから下り方向フローカーブを作成します。地形生成または精度属性再構築後に、侵食水路、摩耗経路、水流ガイドを可視化するために使います。', 'Generate a tiered modular structure mesh with floor modules, facade protrusions, roof modules, module IDs, module kinds, and dense standard attributes. Use it for independent architecture and layout workflows.': '床モジュール、ファサード突起、屋上モジュール、モジュールID、モジュール種別、高密度標準属性を持つ段状モジュラー構造メッシュを生成します。独自建築やレイアウトワークフローに使います。', 'Generate an editable precision heightfield terrain mesh with deterministic multi-octave noise, thermal relaxation, flow accumulation, sediment, wetness, erosion, slope, convexity, habitat, density, and visibility attributes.': '決定論的マルチオクターブノイズ、熱緩和、流量蓄積、堆積、湿り、侵食、傾斜、凸度、生息環境、密度、可視性属性を持つ編集可能な高精度ハイトフィールド地形メッシュを生成します。', 'Parse the panel expression and write it to the sgs_selection attribute and SGS Selection vertex group on the active mesh. Supports index ranges, invert:, density/height/slope/curvature comparisons, attribute ranges, boundary/interior, highest()/lowest(), and and/or/except combinations.': 'パネルの式を解析し、アクティブメッシュのsgs_selection属性とSGS Selection頂点グループへ書き込みます。インデックス範囲、invert:、density/height/slope/curvature比較、属性範囲、boundary/interior、highest()/lowest()、and/or/exceptの組み合わせに対応します。', 'Prefix used when Smart Geometry creates node groups, Geometry Nodes modifiers, generated objects, reports, and helper data. Keep this unique so generated data is easy to audit and remove.': 'Smart Geometryがノードグループ、Geometry Nodesモディファイア、生成オブジェクト、レポート、補助データを作成するときに使う接頭辞です。監査と削除をしやすくするため固有にしてください。', 'Read a CSV file and create a point-cloud mesh from x, y, and z columns. Optional id, scale, density, and numeric custom columns are preserved as neutral named attributes for point-distribution and open-data exchange.': 'CSVファイルを読み込み、x、y、z列から点群メッシュを作成します。任意のid、scale、density、数値カスタム列は、点分布と外部データ交換用の中立的な名前付き属性として保持されます。', 'Rebuild the hyper-precision attribute layer on the selected mesh objects, including topology, flow direction, channel, habitat, stability, cavity, occlusion, thickness, LOD, culling, region, and quality attributes. Use this after editing meshes or before distribution, material, diagnostic, or export workflows.': '選択メッシュオブジェクト上に、トポロジー、流向、水路、生息適性、安定性、窪み、遮蔽、厚み、LOD、カリング、領域、品質属性を含むハイパープレシジョン属性レイヤーを再構築します。メッシュ編集後、または分布、マテリアル、診断、書き出しワークフローの前に使います。', 'Run a polished icon-driven workflow: scene refinement, environment generation, surface design, fragmentation, or diagnostics. The workflow uses independent Smart Geometry algorithms and writes SGS metadata.': 'アイコン駆動の整理されたワークフローを実行します。シーン再構築、環境生成、表面設計、破片化、診断に対応します。独自のSmart Geometryアルゴリズムを使い、SGSメタデータを書き込みます。', 'Run the blue-noise and tangent relaxation pass on the active point-cloud mesh. This improves residual spacing after point import or surface distribution and writes sgs_relaxed and sgs_quality attributes.': 'アクティブな点群メッシュにブルーノイズと接線緩和パスを実行します。点読み込み後または表面分布後に残る間隔を改善し、sgs_relaxedとsgs_quality属性を書き込みます。', 'Run the operation-grade precision polish on selected mesh objects. It rebuilds dense SGS attributes and adds smoothed density, curvature coherence, contact score, material region, distribution priority, remesh intent, stability rank, and quality grade fields.': '選択メッシュオブジェクトに操作品質精度ポリッシュを実行します。高密度SGS属性を再構築し、平滑密度、曲率整合性、接触スコア、マテリアル領域、分布優先度、リメッシュ意図、安定順位、品質グレードフィールドを追加します。', 'Selects the feature capsule to apply or inspect. Each item maps a researched functional requirement to an independent Blender-safe Geometry Nodes workflow with its own naming, metadata, and UI.': '適用または確認する機能カプセルを選択します。各項目は調査済みの機能要件を、独自名称、メタデータ、UIを持つBlender安全なGeometry Nodesワークフローへ対応付けています。', 'Uses Blender borderless operator buttons where possible. The button area remains clickable, while the custom icon artwork itself contains no frame and occupies the maximum available image area.': '可能な場合はBlenderの枠無しオペレーターボタンを使います。ボタン領域はクリック可能なまま、カスタムアイコン画像自体は枠を含まず、利用可能な画像領域を最大限占めます。', 'Write the complete Smart Geometry feature inventory to the extension user_default compatible reports folder. Use this to audit every independent feature capsule, native workflow, category, pack, and tooltip.': '完全なSmart Geometry機能インベントリを、Extension user_default互換のレポートフォルダへ書き出します。独自機能カプセル、ネイティブワークフロー、カテゴリ、パック、ツールチップの監査に使います。'})

_STATIC.update({
    'Migrated Geometry-Node Generators': '移植済みジオメトリノード生成ツール',
    'These tools were moved from Smart Modeling Suite and are now owned by Smart Geometry Suite.': 'これらのツールは Smart Modeling Suite から移動し、現在は Smart Geometry Suite 側の機能として管理されます。',
    'Max Primitives': 'Maxプリミティブ',
    'Open Max Primitives Menu': 'Maxプリミティブメニューを開く',
    'Box': 'ボックス',
    'Sphere': '球',
    'Cylinder': '円柱',
    'Wall': '壁',
    'Install Assets': 'アセットをインストール',
    'Update All': '全て更新',
    'Grease Mesh': 'グリースメッシュ',
    'Create mesh or Geometry Nodes modifiers from Grease Pencil strokes.': 'Grease Pencil ストロークからメッシュまたはジオメトリノードモディファイアを作成します。',
    'Add GP': 'GP追加',
    'Apply Modifiers': 'モディファイア適用',
    'Solid Mesh': 'ソリッドメッシュ',
    'Mirror Mesh': 'ミラーメッシュ',
    'Path Mesh': 'パスメッシュ',
    'Wall Mesh': '壁メッシュ',
    'Scatter': '散布',
    'Array on Pencil': 'ペンシル上に配列',
    'Add New Grease Pencil': '新規グリースペンシルを追加',
    'Apply All Modifiers': '全モディファイアを適用',
    'Array on Curve': 'カーブ上に配列',
    'Bool Cut': 'ブールカット',
    'Mirror Mesh (GN)': 'ミラーメッシュ（GN）',
    'Path Mesh (GN)': 'パスメッシュ（GN）',
    'Solid Mesh (GN)': 'ソリッドメッシュ（GN）',
    'Wall Mesh (GN)': '壁メッシュ（GN）',
    'Knife Cut': 'ナイフカット',
    'Lattice Wrap': 'ラティスラップ',
    'Create Screw Mesh': 'スクリューメッシュを作成',
    'Stamp Scatter': 'スタンプ散布',
    'Create': '作成',
    'Mesh from GP': 'GPからメッシュ生成',
    'Solid': 'ソリッド',
    'Mirror': 'ミラー',
    'Path': 'パス',
    'Screw Mesh': 'スクリューメッシュ',
    'Screw': 'スクリュー',
    'Other': 'その他',
    'Experimental': '実験的',
    'Add a new Grease Pencil object for sketch-to-mesh generation. Use this first when you want to draw strokes that will later become mesh or Geometry Nodes generated geometry.': 'スケッチからメッシュ生成するための新規 Grease Pencil オブジェクトを追加します。後でメッシュまたは Geometry Nodes 生成形状に変換するストロークを描く時に最初に使います。',
    'Apply all modifiers on the active Grease Mesh result. Use this when the generated Geometry Nodes preview is final and you want real editable mesh data.': 'アクティブな Grease Mesh 結果にある全モディファイアを適用します。Geometry Nodes の生成プレビューが確定し、実際に編集できるメッシュデータにしたい時に使います。',
    'Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path. Select or create a Grease Pencil stroke before running this command.': 'Grease Pencil ストロークからカーブパス上の配列風 Geometry Nodes セットアップを作成します。実行前に Grease Pencil ストロークを選択または作成してください。',
    'Cut selected mesh geometry using Grease Pencil stroke shapes. Adjust depth and resolution to control the generated cutter thickness and smoothness.': 'Grease Pencil ストローク形状を使って選択メッシュをカットします。生成カッターの厚みや滑らかさは深度と解像度で調整します。',
    'Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh. Use this for symmetrical sketch-based mesh blocking.': 'Grease Pencil ストローク形状をメッシュとしてミラー生成する Geometry Nodes モディファイアを追加します。左右対称のスケッチベースブロックアウトに使います。',
    'Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes. Use this for pipes, trims, cables, and stroke-based strips.': 'Grease Pencil のパスストロークに沿ってメッシュ形状をスイープする Geometry Nodes モディファイアを追加します。パイプ、トリム、ケーブル、ストロークベースの帯に使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry. Use this for quick sketch-to-solid blocking.': 'Grease Pencil ストロークをソリッドなメッシュ形状へ変換する Geometry Nodes モディファイアを追加します。素早いスケッチからソリッド形状へのブロックアウトに使います。',
    'Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry. Use this for quick architectural blocking.': 'Grease Pencil の平面図ストロークを壁状メッシュへ変換する Geometry Nodes モディファイアを追加します。素早い建築ブロックアウトに使います。',
    'Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing. Enable cut-through when the stroke should affect geometry behind the visible front surface.': 'Grease Pencil ストロークガイドを、メッシュ編集用のナイフカット補助として使います。見えている前面の奥にある形状も切る場合は貫通カットを有効にします。',
    'Create a lattice-based wrap helper around selected geometry. Use this for broad deformation after sketch or mesh generation.': '選択形状の周囲にラティスベースのラップ補助を作成します。スケッチ生成またはメッシュ生成後の大まかな変形に使います。',
    'Create lathe-style screw mesh geometry from a Grease Pencil profile. Use this for revolved forms such as knobs, cups, vases, and turned parts.': 'Grease Pencil の輪郭から旋盤風のスクリューメッシュ形状を作成します。ノブ、カップ、花瓶、旋削部品のような回転形状に使います。',
    'Scatter stamped mesh instances from Grease Pencil stroke input. Use this for quick distribution of repeated sketch-based elements.': 'Grease Pencil ストローク入力からスタンプ状のメッシュインスタンスを散布します。繰り返し配置するスケッチベース要素を素早く分布させる時に使います。',
})
_STATIC.update({
    'Terrain / Environment Generators': '地形 / 環境生成',
    'Distribution / Scatter Generators': '分布 / 散布生成',
    'Structure / Surface Generators': '構造 / 表面生成',
    'Organic / Stroke Generators': '有機 / ストローク生成',
    'Debris / Fragment Generators': 'デブリ / 破砕生成',
    'Primitive Generators': 'プリミティブ生成',
    'Settings': '設定',
    'Terrain Mesh': '地形メッシュ',
    'Drainage Flow Curves': '排水フローカーブ',
    'Surface Distribution Points': '表面分布ポイント',
    'Relax and Preview Instances': '緩和とプレビューインスタンス',
    'CSV Point Cloud': 'CSVポイントクラウド',
    'Surface Detail Blocks': '表面ディテールブロック',
    'Modular Structure': 'モジュラー構造',
    'Organic Growth Curves': '有機成長カーブ',
    'Grease Pencil Mesh Generators': 'Grease Pencilメッシュ生成',
    'Debris Module Generator': 'デブリモジュール生成',
    'Mesh Fragment Generator': 'メッシュ破砕生成',
    'Max Primitive Generators': 'Maxプリミティブ生成',
    'Interface': 'インターフェース',
    'Node Library and Assets': 'ノードライブラリとアセット',
    'Feature / Pack Apply': '機能 / パック適用',
    'Precision Attributes and Selection': '精度属性と選択',
    'Diagnostics and Cleanup': '診断とクリーンアップ',
    'Import / Export Manifests': '読み込み / 書き出しマニフェスト',
    'Debris Utility Settings': 'デブリ補助設定',
    'Visual Reference': 'ビジュアルリファレンス',
    'Coverage Summary': 'カバー範囲サマリー',
    'Creates a terrain mesh. The settings below are the values read by this generator.': '地形メッシュを作成します。下の設定はこの生成処理が実際に参照する値です。',
    'Creates downhill guide curves from the active mesh terrain attributes.': 'アクティブメッシュの地形属性から下り方向のガイドカーブを作成します。',
    'Creates a point-cloud mesh from the active surface or a fallback grid.': 'アクティブな表面またはフォールバックグリッドからポイントクラウドメッシュを作成します。',
    'Relaxes generated points or creates lightweight visible proxy instances for distribution checking.': '生成済みポイントを緩和するか、分布確認用の軽量な可視プロキシインスタンスを作成します。',
    'Imports x, y, z CSV columns as a generated point-cloud mesh.': 'CSVのx, y, z列を生成ポイントクラウドメッシュとして読み込みます。',
    'Creates density-ranked helper blocks on the active surface or fallback grid.': 'アクティブ表面またはフォールバックグリッド上に、密度順の補助ブロックを作成します。',
    'Generates a tiered modular structure mesh with Smart Geometry attributes.': 'Smart Geometry属性付きの階層型モジュラー構造メッシュを生成します。',
    'Creates procedural curves for ivy, roots, cables, veins, or trail guides.': '蔦、根、ケーブル、脈、軌跡ガイド用のプロシージャルカーブを作成します。',
    'Creates mesh or Geometry Nodes results from Grease Pencil strokes. These operators use the selected stroke/object context and do not require SGS numeric parameters.': 'Grease PencilストロークからメッシュまたはGeometry Nodes結果を作成します。これらの処理は選択中のストローク/オブジェクト状態を使用し、SGS数値パラメータは不要です。',
    "Choose one debris module; only that module's active settings are shown before generation.": 'デブリモジュールを1つ選ぶと、そのモジュールに必要な設定だけを表示して生成します。',
    'Creates clustered fragment helper objects from the active mesh faces.': 'アクティブメッシュの面からクラスタ化された破片補助オブジェクトを作成します。',
    'Creates primitive and AEC-style generator objects from the integrated Max Primitives toolset.': '統合されたMax Primitivesツールセットから、プリミティブやAEC系生成オブジェクトを作成します。',
    'Top-level generation sections stay separate; non-generation controls are consolidated here.': '最上層の生成セクションは分離し、生成以外の操作はここに集約しています。',
    'Use search to narrow the advanced feature list.': '詳細機能一覧は検索で絞り込んでください。',
    'Live sidebar buttons use Blender standard icons; visual reference output remains optional.': 'ライブサイドバーのボタンはBlender標準アイコンを使用し、ビジュアルリファレンス出力は任意機能として残します。',
    'Show Terrain and Environment Generators Section': '地形 / 環境生成セクションを表示',
    'Show Distribution and Scatter Generators Section': '分布 / 散布生成セクションを表示',
    'Show Structure and Surface Generators Section': '構造 / 表面生成セクションを表示',
    'Show Organic and Stroke Generators Section': '有機 / ストローク生成セクションを表示',
    'Show Debris and Fragment Generators Section': 'デブリ / 破砕生成セクションを表示',
    'Show Primitive Generators Section': 'プリミティブ生成セクションを表示',
    'Show Settings Section': '設定セクションを表示',
    'Expand or collapse the terrain and environment generator section. It contains only direct generation commands for terrain meshes and drainage flow curves, with the parameters those generators actually read.': '地形 / 環境生成セクションを開閉します。地形メッシュと排水フローカーブを直接生成するコマンドだけを含み、それらの生成処理が実際に参照するパラメータを表示します。',
    'Expand or collapse the distribution generator section. It contains point-cloud, scatter, relaxation, proxy instance, and CSV point generation controls with the relevant distribution settings.': '分布生成セクションを開閉します。ポイントクラウド、散布、緩和、プロキシインスタンス、CSVポイント生成の操作と関連する分布設定を含みます。',
    'Expand or collapse the structure and surface generator section. It contains direct generation tools for surface detail blocks and modular structures with their own settings.': '構造 / 表面生成セクションを開閉します。表面ディテールブロックとモジュラー構造を直接生成するツールを、それぞれの設定と一緒に表示します。',
    'Expand or collapse the organic and stroke generator section. It contains organic curve creation and Grease Pencil to mesh generation commands.': '有機 / ストローク生成セクションを開閉します。有機カーブ作成とGrease Pencilからメッシュへの生成コマンドを含みます。',
    'Expand or collapse the debris and fragment generator section. It contains the integrated debris module generator and mesh fragmentation generator with only their generation settings.': 'デブリ / 破砕生成セクションを開閉します。統合デブリモジュール生成とメッシュ破砕生成を、それぞれの生成設定だけと一緒に表示します。',
    'Expand or collapse the primitive generator section. It contains direct Max Primitive creation commands without unrelated asset maintenance controls.': 'プリミティブ生成セクションを開閉します。関係のないアセット管理操作を除き、Max Primitiveの直接作成コマンドだけを表示します。',
    'Expand or collapse the consolidated settings section at the bottom of the Smart Geometry panel. Non-generation controls, diagnostics, reports, visual reference options, and advanced feature application tools are grouped here.': 'Smart Geometryパネル最下部の統合設定セクションを開閉します。生成以外の操作、診断、レポート、ビジュアルリファレンス、詳細な機能適用ツールをここにまとめます。',
    'Show Terrain Mesh Generator Child Section': '地形メッシュ生成子セクションを表示',
    'Show Drainage Flow Generator Child Section': '排水フロー生成子セクションを表示',
    'Show Surface Distribution Generator Child Section': '表面分布生成子セクションを表示',
    'Show Distribution Relax and Proxy Child Section': '分布緩和 / プロキシ子セクションを表示',
    'Show CSV Point Cloud Generator Child Section': 'CSVポイントクラウド生成子セクションを表示',
    'Show Surface Detail Generator Child Section': '表面ディテール生成子セクションを表示',
    'Show Modular Structure Generator Child Section': 'モジュラー構造生成子セクションを表示',
    'Show Organic Growth Generator Child Section': '有機成長生成子セクションを表示',
    'Show Stroke Mesh Generator Child Section': 'ストロークメッシュ生成子セクションを表示',
    'Show Debris Module Generator Child Section': 'デブリモジュール生成子セクションを表示',
    'Show Mesh Fragment Generator Child Section': 'メッシュ破砕生成子セクションを表示',
    'Show Max Primitive Generator Child Section': 'Maxプリミティブ生成子セクションを表示',
    'Show Interface Settings Child Section': 'インターフェース設定子セクションを表示',
    'Show Node Library Settings Child Section': 'ノードライブラリ設定子セクションを表示',
    'Show Feature and Pack Apply Child Section': '機能 / パック適用子セクションを表示',
    'Show Precision Tools Child Section': '精度ツール子セクションを表示',
    'Show Diagnostics and Cleanup Child Section': '診断 / クリーンアップ子セクションを表示',
    'Show Manifest Report Child Section': 'マニフェストレポート子セクションを表示',
    'Show Debris Utility Settings Child Section': 'デブリ補助設定子セクションを表示',
    'Show Visual Reference Settings Child Section': 'ビジュアルリファレンス設定子セクションを表示',
    'Show Coverage Summary Child Section': 'カバー範囲サマリー子セクションを表示',
    'Show Storage Path Child Section': '保存先パス子セクションを表示',
})
_translations = {'ja_JP': {}}
for en, ja in _STATIC.items():
    _translations['ja_JP'][('*', en)] = ja
try:
    from . import always_on as _always_on
    for _feature in _always_on.feature_definitions():
        _translations['ja_JP'][('*', _feature.label_en)] = _feature.label_ja
        _translations['ja_JP'][('*', _feature.description_en)] = _feature.description_ja
except Exception:
    pass
for feature in catalog.FEATURES:
    for key in ('label', 'summary', 'tooltip'):
        en = str(feature.get(f'{key}_en') or '')
        ja = str(feature.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for category in catalog.CATEGORIES:
    for key in ('label', 'summary'):
        en = str(category.get(f'{key}_en') or '')
        ja = str(category.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for pack in catalog.PACKS:
    for key in ('label', 'description'):
        en = str(pack.get(f'{key}_en') or '')
        ja = str(pack.get(f'{key}_ja') or '')
        if en and ja:
            _translations['ja_JP'][('*', en)] = ja
for feature in catalog.FEATURES:
    en = str(feature.get('design_domain_en') or '')
    ja = str(feature.get('design_domain_ja') or '')
    if en and ja:
        _translations['ja_JP'][('*', en)] = ja
I18N_DICT = _translations


_STATIC.update({'Displays the bundled transparent 32 px custom icon artwork on command buttons. The icon images contain no frame and keep a large readable figure size while following the current bundled icon pack.': 'コマンドボタンに同梱の32px透過カスタムアイコンを表示します。アイコン画像には枠がなく、現在の同梱アイコンパックに合わせて読みやすい大きな図形サイズを保ちます。'})

for _config_en, _config_ja in {
    'Copy the bundled icon reference sheet to CONFIG/Smart_Geometry_Suite. The icons are suite-owned borderless high-fill images for readable large action buttons.': '同梱のアイコンリファレンスシートをCONFIG/Smart_Geometry_Suiteへコピーします。アイコンはツールセット所有の枠無し高充填画像で、大型操作ボタン用に視認性を高めています。',
    'Write the complete Smart Geometry feature inventory to the CONFIG/Smart_Geometry_Suite reports folder. Use this to audit every independent feature capsule, native workflow, category, pack, and tooltip.': '完全なSmart Geometry機能インベントリをCONFIG/Smart_Geometry_Suiteのレポートフォルダへ書き出します。独自機能カプセル、ネイティブワークフロー、カテゴリ、パック、ツールチップの監査に使います。',
    'Write scene diagnostics including generated objects, mesh attributes, modifiers, node groups, and heat-map approximation scores to the CONFIG/Smart_Geometry_Suite reports folder.': '生成オブジェクト、メッシュ属性、モディファイア、ノードグループ、ヒートマップ近似スコアを含むシーン診断をCONFIG/Smart_Geometry_Suiteのレポートフォルダへ書き出します。',
}.items():
    _STATIC[_config_en] = _config_ja
    I18N_DICT['ja_JP'][('*', _config_en)] = _config_ja


# 8.2.48 localization pass: user-visible strings confirmed missing from the
# registered ja_JP catalog (RNA labels/descriptions and layout fallback labels).
_USERFIX_8_2_48 = {
    'Creates a Max Primitive by 3ds Max style viewport dragging. Click-drag on the construction plane to set the base or radius; primitives with height use a second drag for height.':
        '3ds Maxスタイルのビューポートドラッグ操作でMaxプリミティブを作成します。作図平面上でクリック・ドラッグして基本サイズまたは半径を決め、高さを持つプリミティブは2回目のドラッグで高さを決めます。',
    'Creates a Max Primitive by 3ds Max style viewport dragging. Click-drag on the construction plane to set the base/radius; primitives with height use a second drag for height. The modifier parameters remain editable after creation.':
        '3ds Maxスタイルのビューポートドラッグ操作でMaxプリミティブを作成します。作図平面上でクリック・ドラッグして基本サイズまたは半径を決め、高さを持つプリミティブは2回目のドラッグで高さを決めます。作成後もモディファイアパラメーターを編集できます。',
    "Builds procedural primitive assets, writes them to the user asset library, and registers the library in Blender preferences. This external-file and Preferences operation is not placed on Blender's scene Undo stack.":
        '手続き型プリミティブアセットを生成し、ユーザーアセットライブラリへ書き込み、Blender設定にライブラリ登録します。この外部ファイルと設定の操作は、Blenderのシーン取り消し履歴には積まれません。',
    'Forces regeneration of the selected Max Primitive from the current Geometry Nodes modifier values.':
        '選択中のMaxプリミティブを、現在のジオメトリノード・モディファイア値から強制再生成します。',
    'Forces regeneration of every Max Primitive object in the current file.':
        '現在のファイル内にある全てのMaxプリミティブオブジェクトを強制再生成します。',
    'Max Primitive objects created as Blender Geometry Nodes modifier assets.':
        'Blenderのジオメトリノード・モディファイアアセットとして作成されるMaxプリミティブオブジェクトです。',
    'Refresh Max Primitive':
        'Maxプリミティブを更新',
    'Applies the current Max Primitive modifier values to the generated mesh immediately.':
        '現在のMaxプリミティブのモディファイア値を、生成メッシュへ直ちに適用します。',
    'Max Primitives Parameters':
        'Max Primitivesパラメーター',
    'Applies the current Max Primitives modifier values to the generated mesh immediately. Use this when automatic regeneration is delayed.':
        '現在のMax Primitivesモディファイア値を、生成メッシュへ直ちに適用します。自動再生成が遅れる場合に使用してください。',
    'Internal identifier of the procedural primitive generator to create by viewport drag.':
        'ビューポートドラッグで作成する手続き型プリミティブジェネレーターの内部識別子です。',
    'Add a new Grease Pencil object for sketch-to-mesh generation.':
        'スケッチからメッシュを生成するための新しいGrease Pencilオブジェクトを追加します。',
    'Add a Geometry Nodes modifier that converts Grease Pencil strokes into solid mesh geometry.':
        'Grease Pencilストロークをソリッドメッシュジオメトリへ変換するジオメトリノード・モディファイアを追加します。',
    'Add a Geometry Nodes modifier that mirrors Grease Pencil stroke geometry as mesh.':
        'Grease Pencilストロークのジオメトリをメッシュとしてミラーするジオメトリノード・モディファイアを追加します。',
    'Add a Geometry Nodes modifier that sweeps mesh geometry along Grease Pencil path strokes.':
        'Grease Pencilのパスストロークに沿ってメッシュジオメトリをスイープするジオメトリノード・モディファイアを追加します。',
    'Add a Geometry Nodes modifier that converts Grease Pencil floor-plan strokes into wall-like mesh geometry.':
        'Grease Pencilの平面図ストロークを壁状のメッシュジオメトリへ変換するジオメトリノード・モディファイアを追加します。',
    'Create lathe-style screw mesh geometry from a Grease Pencil profile.':
        'Grease Pencilの断面プロファイルから旋盤式のスクリューメッシュジオメトリを作成します。',
    'Create a lattice-based wrap helper around selected geometry.':
        '選択ジオメトリの周囲にラティスベースのラップ補助を作成します。',
    'Cut selected mesh geometry using Grease Pencil stroke shapes.':
        'Grease Pencilストロークの形状で選択メッシュジオメトリをカットします。',
    'Create an array-style Geometry Nodes setup from Grease Pencil strokes on a curve path.':
        'カーブパス上のGrease Pencilストロークから配列式のジオメトリノードセットアップを作成します。',
    'Apply all modifiers on the active Grease Mesh result to create editable mesh data.':
        'アクティブなグリースメッシュ結果の全モディファイアを適用し、編集可能なメッシュデータを作成します。',
    'Scatter stamped mesh instances from Grease Pencil stroke input.':
        'Grease Pencilストローク入力からスタンプ済みメッシュインスタンスを散布します。',
    'Use Grease Pencil stroke guides as a knife-style cut helper for mesh editing.':
        'Grease Pencilストロークのガイドを、メッシュ編集用のナイフ式カット補助として使用します。',
    'Cut Depth':
        'カット深度',
    'Thickness of the cutter volume — must exceed target mesh thickness':
        'カッターボリュームの厚みです。対象メッシュの厚みを超える必要があります',
    'Resolution':
        '解像度',
    'Number of points to resample the cut shape':
        'カット形状を再サンプルするポイント数です',
    'Cut Through':
        '貫通カット',
    'Cut through the entire mesh, not just the visible surface':
        '見えている表面だけでなく、メッシュ全体を貫通してカットします',
    'Resample strokes to this many points (0 = use original points)':
        'ストロークをこのポイント数へ再サンプルします(0で元のポイントを使用)',
    'Thickness of the cutter volume; it must exceed the target mesh thickness.':
        'カッターボリュームの厚みです。対象メッシュの厚みを超える必要があります。',
    'Number of points used to resample the cut shape.':
        'カット形状の再サンプルに使うポイント数です。',
    'Cut through the entire mesh instead of only the visible surface.':
        '見えている表面だけでなく、メッシュ全体を貫通してカットします。',
    'Resample strokes to this many points; zero uses the original points.':
        'ストロークをこのポイント数へ再サンプルします。0で元のポイントを使用します。',
    'Primitive definitions are unavailable.':
        'プリミティブ定義を利用できません。',
    'Smart Geometry command data is unavailable.':
        'Smart Geometryコマンドデータを利用できません。',
    'Validate bundled icon files. In Blender 5.1 crash-safe mode, live custom preview icon IDs are disabled and the UI uses Blender standard icons.':
        '同梱アイコンファイルを検証します。Blender 5.1クラッシュセーフモードでは、ライブカスタムプレビューアイコンIDは無効で、UIはBlender標準アイコンを使用します。',
    'CSV File Filter':
        'CSVファイルフィルター',
    'Limits the Blender file browser to CSV files containing point coordinates and optional attribute columns.':
        'Blenderのファイルブラウザを、ポイント座標と任意の属性列を含むCSVファイルに限定します。',
    'Blender 5.1 crash-safe mode keeps live custom preview icon IDs disabled. Command buttons use Blender standard icons; bundled 32 px transparent PNGs remain available as static reference/export assets.':
        'Blender 5.1クラッシュセーフモードでは、ライブカスタムプレビューアイコンIDを無効のまま維持します。コマンドボタンはBlender標準アイコンを使用し、同梱の32px透過PNGは静的な参照・書き出しアセットとして利用できます。',
    'Show Always-on Toggles Section':
        '常時機能切り替えセクションを表示',
    'Expand or collapse the Smart Geometry always-on toggle section in the compact grouped N-panel UI.':
        'コンパクトなグループ化NパネルUIで、Smart Geometryの常時機能切り替えセクションを開閉します。',
    'Show Suite Controls Section':
        'スイート操作セクションを表示',
    'Expand or collapse the active feature, active pack, apply, and library controls section.':
        'アクティブ機能、アクティブパック、適用、ライブラリ操作のセクションを開閉します。',
    'Show Visual Dashboard Section':
        'ビジュアルダッシュボードセクションを表示',
    'Expand or collapse the visual workflow dashboard section.':
        'ビジュアルワークフローダッシュボードセクションを開閉します。',
    'Show Quick Start Section':
        'クイック開始セクションを表示',
    'Expand or collapse the quick start setup and preset controls section.':
        'クイック開始のセットアップとプリセット操作のセクションを開閉します。',
    'Show Feature Catalog Section':
        '機能カタログセクションを表示',
    'Expand or collapse the filtered feature catalog section.':
        '絞り込み済み機能カタログセクションを開閉します。',
    'Show Procedural Builders Section':
        'プロシージャル生成セクションを表示',
    'Expand or collapse the procedural builders section.':
        'プロシージャル生成セクションを開閉します。',
    'Show Builder Controls Section':
        '生成コントロールセクションを表示',
    'Expand or collapse detailed terrain, scatter, drainage, growth, fragment, precision, and debug builder controls.':
        '地形、散布、排水、成長、破片、精度、デバッグの詳細生成コントロールを開閉します。',
    'Show Debris Generators Section':
        'デブリ生成セクションを表示',
    'Expand or collapse the integrated Smart Geometry debris generator controls inside the Procedural Builders section. These controls create procedural rubble, stones, vegetation, metal sheets, wood pieces, birds, snowflakes, and related scene debris from the selected module.':
        'プロシージャル生成セクション内の統合Smart Geometryデブリ生成コントロールを開閉します。これらのコントロールは、選択したモジュールから瓦礫、石、植生、金属板、木片、鳥、雪片などのシーンデブリを生成します。',
    'Show Interop and Manifests Section':
        '外部連携 / マニフェストセクションを表示',
    'Expand or collapse CSV, USD, bundle, and exchange manifest controls.':
        'CSV、USD、バンドル、交換マニフェストの操作を開閉します。',
    'Show Diagnostics Section':
        '診断セクションを表示',
    'Expand or collapse mesh diagnostics, generated node group reports, and diagnostic export commands.':
        'メッシュ診断、生成ノードグループレポート、診断書き出しコマンドを開閉します。',
    'Show Visual UI Section':
        'ビジュアルUIセクションを表示',
    'Expand or collapse visual UI, icon scale, precision, and custom icon reference controls.':
        'ビジュアルUI、アイコン倍率、精度、カスタムアイコンリファレンスの操作を開閉します。',
    'Show Design Coverage Section':
        '設計カバー範囲セクションを表示',
    'Expand or collapse design coverage and domain coverage reports.':
        '設計カバー範囲とドメインカバー範囲のレポートを開閉します。',
    'Show Attribute and Visualization Generators Section':
        '属性 / 可視化生成セクションを表示',
    'Expand or collapse the attribute and visualization generator section. It contains only direct commands that build precision attributes, procedural selection attributes, heatmap materials, and attribute snapshot meshes, with the exact settings those commands use.':
        '属性 / 可視化生成セクションを開閉します。高精度属性、プロシージャル選択属性、ヒートマップマテリアル、属性スナップショットメッシュを直接生成するコマンドと、それらが実際に使用する設定だけを含みます。',
    'Shows the command dashboard. In Blender 5.1 crash-safe mode, it uses Blender standard UI icons instead of live custom preview icon IDs.':
        'コマンドダッシュボードを表示します。Blender 5.1クラッシュセーフモードでは、ライブカスタムプレビューアイコンIDの代わりにBlender標準UIアイコンを使用します。',
    'Uses compact Blender operator button styling where possible. In Blender 5.1 crash-safe mode, buttons use standard icons and avoid live custom preview icon IDs.':
        '可能な場合、コンパクトなBlenderオペレーターボタンスタイルを使用します。Blender 5.1クラッシュセーフモードでは、ボタンは標準アイコンを使用し、ライブカスタムプレビューアイコンIDを避けます。',
    'Controls optional visual reference preview scale only. Sidebar operator buttons always use Blender normal button height.':
        '任意のビジュアルリファレンスプレビュー倍率のみを制御します。サイドバーのオペレーターボタンは常にBlender標準のボタン高さを使用します。',
    'Legacy compatibility value. Sidebar operator buttons always use Blender normal button height.':
        '旧版互換の値です。サイドバーのオペレーターボタンは常にBlender標準のボタン高さを使用します。',
    'Shows the command ribbon for fast one-click access to main procedural workflows. Blender 5.1 crash-safe mode uses standard UI icons.':
        '主要なプロシージャルワークフローへワンクリックでアクセスできるコマンドリボンを表示します。Blender 5.1クラッシュセーフモードでは標準UIアイコンを使用します。',
    'Controls the dashboard tile height. Increase this on high-DPI monitors; Blender 5.1 crash-safe mode keeps live custom preview icons disabled.':
        'ダッシュボードタイルの高さを制御します。高DPIモニターでは値を上げてください。Blender 5.1クラッシュセーフモードではライブカスタムプレビューアイコンを無効のまま維持します。',
    'Shows static bundled reference diagrams. The diagrams contain no embedded two-language text so the UI language remains controlled by Blender localization.':
        '同梱の静的リファレンス図を表示します。図には二言語併記の埋め込み文字が無いため、UI言語はBlenderのローカライズ設定で制御されます。',
    'N-panel State Save':
        'Nパネル状態保存',
    "Controls how Smart Geometry N-panel settings are written to Smart_Geometry_Suite/Smart_Geometry_Suite.json in Blender's versioned config directory. Enable for immediate save on every setting change. Disable to defer writing until a scene switch, explicit file save/load boundary, Manager transition, or Blender exit.":
        'Smart GeometryのNパネル設定を、Blenderのバージョン別設定ディレクトリのSmart_Geometry_Suite/Smart_Geometry_Suite.jsonへ書き込む方法を制御します。有効にすると設定変更のたびに即時保存します。無効にすると、シーン切り替え、明示的なファイル保存/読み込み、Manager移行、Blender終了まで書き込みを延期します。',
    'Shows or collapses the on-demand helper controls in the N-panel. These toggles no longer start recurring timers; they enable safe checks at UI, command, save, load, or setting-change boundaries.':
        'Nパネルのオンデマンド補助コントロールを表示または折りたたみます。これらの切り替えは繰り返しタイマーを開始せず、UI、コマンド、保存、読み込み、設定変更の境界で安全な確認を有効にします。',
    'Smart Geometry Suite Settings':
        'Smart Geometry Suite設定',
    'Stores Smart Geometry N-panel controls, section states, generator parameters, and always-on feature switches for the current Blender session.':
        '現在のBlenderセッションのSmart GeometryのNパネルコントロール、セクション状態、生成パラメータ、常時起動機能スイッチを保存します。',
    'Toggle Smart Geometry Section':
        'Smart Geometryセクションを切り替え',
    'Expand or collapse this Smart Geometry N-panel section.':
        'このSmart Geometry Nパネルセクションを開閉します。',
    'Refresh Diagnostics':
        '診断を更新',
    'Refresh the cached mesh and generated-node-group diagnostics on demand.':
        'キャッシュ済みのメッシュ診断と生成ノードグループ診断を必要な時に更新します。',
    'Section Property':
        'セクションプロパティ',
    'Internal settings property whose Boolean value is toggled to expand or collapse this Smart Geometry section.':
        'このSmart Geometryセクションの開閉のために真偽値を切り替える内部設定プロパティです。',
    'Section Label':
        'セクションラベル',
    'Localized section label used by the N-panel disclosure control and operator history.':
        'Nパネルの開閉コントロールとオペレーター履歴で使うローカライズ済みセクションラベルです。',
}
_STATIC.update(_USERFIX_8_2_48)
for _userfix_en, _userfix_ja in _USERFIX_8_2_48.items():
    I18N_DICT['ja_JP'][('*', _userfix_en)] = _userfix_ja

_CHILD_FOLDOUTS = {
    'Show N-Panel State Child Section':
        'Nパネル状態の子セクションを表示',
    'Opens or closes the child foldout that controls whether Smart Geometry remembers N-panel section states between Blender sessions. Use the triangle beside the label to keep this storage control visible or hidden.':
        'Smart GeometryがNパネルの開閉状態をBlenderの次回起動まで覚えておくかを決める子セクションを開閉します。見出し横の三角で、この保存の設定を表示または非表示にします。',
    'Show Background Helpers Child Section':
        '補助機能の子セクションを表示',
    'Opens or closes the child foldout containing lightweight always-on helper toggles such as mesh inspection, attribute guards, selection sync, visibility gates, and diagnostics snapshots.':
        'メッシュ検査、属性ガード、選択同期、可視性ゲート、診断スナップショットなど、軽い常時機能の切り替えをまとめた子セクションを開閉します。',
    'Show Suite Overview Child Section':
        'スイート概要の子セクションを表示',
    'Opens or closes the child foldout that shows the Smart Geometry Suite identity and version summary inside Suite Controls.':
        'スイート操作の中で、Smart Geometry Suiteの名前と版の概要を示す子セクションを開閉します。',
    'Show Active Targets Child Section':
        'アクティブ対象の子セクションを表示',
    'Opens or closes the child foldout for choosing the active feature and active pack before applying Smart Geometry operations.':
        'Smart Geometryの操作を適用する前に、アクティブ機能とアクティブパックを選ぶ子セクションを開閉します。',
    'Show Suite Actions Child Section':
        'スイート操作の子セクションを表示',
    'Opens or closes the child foldout that contains the main apply and node-library creation commands.':
        '主な適用コマンドとノードライブラリ作成コマンドをまとめた子セクションを開閉します。',
    'Show Storage Child Section':
        '保存先の子セクションを表示',
    'Opens or closes the advanced child foldout that displays the Smart Geometry external storage path used for generated reports, manifests, and persistent settings.':
        '生成したレポート、マニフェスト、保存された設定に使うSmart Geometryの外部保存先を示す詳細の子セクションを開閉します。',
    'Show Dashboard Preset Child Section':
        'ダッシュボードのプリセットの子セクションを表示',
    'Opens or closes the child foldout for selecting and applying the dashboard precision preset.':
        'ダッシュボードの精度プリセットを選んで適用する子セクションを開閉します。',
    'Show Dashboard Precision Child Section':
        'ダッシュボードの精度の子セクションを表示',
    'Opens or closes the child foldout containing the precision polish and refinement workflow tiles.':
        '精度ポリッシュと精度向上のワークフローのタイルをまとめた子セクションを開閉します。',
    'Show Dashboard Scene Workflows Child Section':
        'ダッシュボードのシーンワークフローの子セクションを表示',
    'Opens or closes the child foldout containing environment, surface, fragment, diagnostic, and full-demo workflow tiles.':
        '環境、表面、破片、診断、全機能デモのワークフローのタイルをまとめた子セクションを開閉します。',
    'Show Quick Start Actions Child Section':
        'クイックスタートの操作の子セクションを表示',
    'Opens or closes the child foldout for node-library setup, rebuild, demo-scene creation, full toolset application, and quick precision polish commands.':
        'ノードライブラリの準備と再構築、デモシーンの作成、ツール一式の適用、手早い精度ポリッシュのコマンドをまとめた子セクションを開閉します。',
    'Show Quick Start Presets Child Section':
        'クイックスタートのプリセットの子セクションを表示',
    'Opens or closes the child foldout for capsule prefix, asset marking, and precision preset settings used by quick-start commands.':
        'クイックスタートのコマンドで使うカプセル接頭辞、アセット化、精度プリセットの設定をまとめた子セクションを開閉します。',
    'Show Quick Start Display Child Section':
        'クイックスタートの表示の子セクションを表示',
    'Opens or closes the child foldout for quick-start display and advanced-view options.':
        'クイックスタートの表示と詳細表示の設定をまとめた子セクションを開閉します。',
    'Show Catalog Filters Child Section':
        'カタログの絞り込みの子セクションを表示',
    'Opens or closes the child foldout for filtering the feature catalog by category, design domain, and search text.':
        '機能カタログをカテゴリ、設計ドメイン、検索文字で絞り込む子セクションを開閉します。',
    'Show Catalog Results Child Section':
        'カタログの結果の子セクションを表示',
    'Opens or closes the child foldout that lists matching Smart Geometry features with apply and help buttons.':
        '条件に合うSmart Geometryの機能を、適用とヘルプのボタン付きで並べる子セクションを開閉します。',
    'Show Builder Precision Setup Child Section':
        '生成の精度設定の子セクションを表示',
    'Opens or closes the child foldout for standard attribute creation, scene precision refinement, and precision polish commands.':
        '標準属性の作成、シーンの精度向上、精度ポリッシュのコマンドをまとめた子セクションを開閉します。',
    'Show Builder Selection Child Section':
        '生成の選択の子セクションを表示',
    'Opens or closes the child foldout for entering and applying selection-string based procedural targeting.':
        '選択文字列を入力して、生成の対象を決める子セクションを開閉します。',
    'Show Terrain Builder Controls Child Section':
        '地形生成の設定の子セクションを表示',
    'Opens or closes the nested child foldout for terrain, erosion, hydrology, channel, ridge, and field-fusion builder parameters.':
        '地形、侵食、水理、水路、尾根、フィールド融合の生成設定をまとめた子セクションを開閉します。',
    'Show Distribution Builder Controls Child Section':
        '分布生成の設定の子セクションを表示',
    'Opens or closes the nested child foldout for scatter amount, spacing, relaxation, camera visibility, biome, fairness, anisotropy, and density controls.':
        '散布量、間隔、緩和、カメラ可視性、バイオーム、均等さ、異方性、密度の設定をまとめた子セクションを開閉します。',
    'Show Fragment Builder Controls Child Section':
        '破片生成の設定の子セクションを表示',
    'Opens or closes the nested child foldout for growth branch counts and fragmentation readability controls.':
        '成長の枝数と、破片の見やすさの設定をまとめた子セクションを開閉します。',
    'Show Precision Builder Controls Child Section':
        '精度生成の設定の子セクションを表示',
    'Opens or closes the nested child foldout for precision, stability, interlock, debug attribute, and random seed parameters.':
        '精度、安定性、かみ合わせ、デバッグ属性、乱数シードの設定をまとめた子セクションを開閉します。',
    'Show Migrated Generators Child Section':
        '移管された生成機能の子セクションを表示',
    'Opens or closes the child foldout containing Max Primitives and Grease Mesh tools that are now managed inside Smart Geometry Suite.':
        'Smart Geometry Suiteで管理するMax PrimitivesとGrease Meshのツールをまとめた子セクションを開閉します。',
    'Show Max Primitives Child Section':
        'Max Primitivesの子セクションを表示',
    'Opens or closes the nested child foldout for Max Primitives menu access, common primitive generators, asset installation, and update commands.':
        'Max Primitivesのメニュー、よく使うプリミティブの生成、アセットのインストール、更新のコマンドをまとめた子セクションを開閉します。',
    'Show Grease Mesh Child Section':
        'Grease Meshの子セクションを表示',
    'Opens or closes the nested child foldout for Grease Pencil to mesh and Geometry Nodes conversion tools.':
        'Grease Pencilをメッシュやジオメトリノードへ変換するツールをまとめた子セクションを開閉します。',
    'Show Scene Generators Child Section':
        'シーン生成の子セクションを表示',
    'Opens or closes the child foldout containing terrain, scatter, relaxation, flow, greeble, structure, growth, fragment, proxy, heatmap, and snapshot generation commands.':
        '地形、散布、緩和、フロー、ディテールブロック、構造、成長、破片、プロキシ、ヒートマップ、スナップショットの生成コマンドをまとめた子セクションを開閉します。',
    'Show Interop Paths Child Section':
        '受け渡しのパスの子セクションを表示',
    'Opens or closes the child foldout for file-path inputs used by CSV and manifest workflows.':
        'CSVとマニフェストの作業で使うファイルパスを入力する子セクションを開閉します。',
    'Show Interop Exports Child Section':
        '受け渡しの書き出しの子セクションを表示',
    'Opens or closes the child foldout for CSV import, USD sidecar manifest export, bundle manifest export, and design coverage JSON export commands.':
        'CSVの読み込み、USDサイドカーマニフェスト、バンドルマニフェスト、設計カバレッジJSONの書き出しコマンドをまとめた子セクションを開閉します。',
    'Show Interop Bridges Child Section':
        '受け渡しのブリッジの子セクションを表示',
    'Opens or closes the child foldout that lists feature-backed attribute, field, USD, and CSV exchange bridge tools.':
        '属性、フィールド、USD、CSVを受け渡すブリッジのツールを並べる子セクションを開閉します。',
    'Show Active Mesh Diagnostics Child Section':
        'アクティブメッシュの診断の子セクションを表示',
    'Opens or closes the child foldout that reports the selected mesh name, topology counts, attribute count, and modifier count.':
        '選択中のメッシュの名前、頂点・辺・面の数、属性数、モディファイアー数を示す子セクションを開閉します。',
    'Show Generated Node Groups Child Section':
        '生成済みノードグループの子セクションを表示',
    'Opens or closes the child foldout that counts and previews node groups generated by Smart Geometry Suite.':
        'Smart Geometry Suiteが生成したノードグループの数と名前を示す子セクションを開閉します。',
    'Show Diagnostics Export Child Section':
        '診断の書き出しの子セクションを表示',
    'Opens or closes the child foldout for exporting diagnostics and inventory JSON reports.':
        '診断とインベントリのJSONレポートを書き出す子セクションを開閉します。',
    'Show Diagnostics Maintenance Child Section':
        '診断の保守の子セクションを表示',
    'Opens or closes the advanced child foldout for destructive maintenance commands such as removing generated node groups.':
        '生成済みノードグループの削除など、データを消す保守コマンドをまとめた詳細の子セクションを開閉します。',
    'Show Visual UI Display Child Section':
        'ビジュアルUIの表示の子セクションを表示',
    'Opens or closes the child foldout for UI density, icon scale, dashboard tile scale, and reference strip display controls.':
        'UI密度、アイコン倍率、ダッシュボードタイル倍率、リファレンス帯の表示の設定をまとめた子セクションを開閉します。',
    'Show Visual UI Precision Child Section':
        'ビジュアルUIの精度の子セクションを表示',
    'Opens or closes the child foldout for precision preset and precision display parameter controls.':
        '精度プリセットと精度の表示の設定をまとめた子セクションを開閉します。',
    'Show Visual Reference Tools Child Section':
        'ビジュアルリファレンスの子セクションを表示',
    'Opens or closes the child foldout for opening the visual reference and exporting the icon reference sheet.':
        'ビジュアルリファレンスを開く操作と、アイコンリファレンスシートの書き出しをまとめた子セクションを開閉します。',
    'Show Coverage Categories Child Section':
        'カバレッジのカテゴリの子セクションを表示',
    'Opens or closes the child foldout that summarizes Smart Geometry feature coverage by category.':
        'Smart Geometryの機能の網羅をカテゴリごとにまとめた子セクションを開閉します。',
    'Show Coverage Domains Child Section':
        'カバレッジの設計ドメインの子セクションを表示',
    'Opens or closes the child foldout that summarizes Smart Geometry feature coverage by design domain.':
        'Smart Geometryの機能の網羅を設計ドメインごとにまとめた子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for the terrain mesh generator. It shows the seed, resolution, size, height, erosion, and hydraulic droplet settings used when creating a precision terrain mesh.':
        '地形メッシュ生成の子セクションを開閉します。高精度の地形メッシュを作る時のシード、解像度、サイズ、高さ、侵食、水滴の設定を表示します。',
    'Opens or closes the Blender-standard child foldout for drainage flow curve generation from the active mesh terrain attributes.':
        'アクティブメッシュの地形属性から排水フローカーブを作る子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for creating surface distribution point-cloud meshes, including amount, spacing, blue-noise, normal offset, biome bias, candidate multiplier, and density settings.':
        '表面分布のポイントクラウドメッシュを作る子セクションを開閉します。量、間隔、ブルーノイズ、法線オフセット、バイオーム偏り、候補倍率、密度の設定を含みます。',
    'Opens or closes the Blender-standard child foldout for relaxing generated distribution points and creating visible distribution proxy instances.':
        '生成済みの分布ポイントを緩和する操作と、確認用のプロキシインスタンスを作る操作の子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for importing CSV x/y/z data as a generated point-cloud mesh.':
        'CSVのx/y/zデータをポイントクラウドメッシュとして読み込む子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for generating surface detail blocks from the active mesh or fallback grid.':
        'アクティブメッシュまたは代わりのグリッドから表面ディテールブロックを作る子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for generating tiered modular structure meshes with Smart Geometry attributes.':
        'Smart Geometry属性付きの階層型モジュラー構造メッシュを作る子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for generating organic growth curves such as ivy, roots, cables, veins, and trail guides.':
        '蔦、根、ケーブル、脈、軌跡ガイドなどの有機成長カーブを作る子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for Grease Pencil to mesh and Geometry Nodes generation commands.':
        'Grease Pencilからメッシュやジオメトリノードの結果を作るコマンドの子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for the integrated debris module generator. The active module controls show only the settings for the selected debris generator.':
        'デブリモジュール生成の子セクションを開閉します。選んだモジュールに必要な設定だけを表示します。',
    'Opens or closes the Blender-standard child foldout for clustered mesh fragment generation using the active mesh faces.':
        'アクティブメッシュの面からクラスタ破片を作る子セクションを開閉します。',
    'Opens or closes the Blender-standard child foldout for direct Max Primitive generator commands such as box, sphere, cylinder, and wall.':
        'ボックス、球、円柱、壁などのMaxプリミティブを作るコマンドの子セクションを開閉します。',
    'Show Precision Attribute Generator Child Section':
        '精度属性の生成の子セクションを表示',
    'Opens or closes the Blender-standard child foldout for building and refining Smart Geometry precision attributes. It shows the preset, precision strength, quality pass, feature radius, material contrast, risk suppression, and debug attribute settings used by the attribute generators.':
        'Smart Geometryの精度属性を作成・向上する子セクションを開閉します。プリセット、精度強度、品質パス、特徴半径、マテリアルコントラスト、リスク抑制、デバッグ属性の設定を表示します。',
    'Show Procedural Selection Attribute Child Section':
        'プロシージャル選択属性の子セクションを表示',
    'Opens or closes the Blender-standard child foldout for writing a procedural selection attribute from the selection string and density threshold values.':
        '選択文字列と密度しきい値から選択属性を書き込む子セクションを開閉します。',
    'Show Attribute Visual Output Child Section':
        '属性の可視化の子セクションを表示',
    'Opens or closes the Blender-standard child foldout for generating attribute heatmap materials and attribute snapshot meshes from the selected debug attribute.':
        '選んだデバッグ属性からヒートマップマテリアルとスナップショットメッシュを作る子セクションを開閉します。',
    'Opens or closes the consolidated interface child foldout for UI density, icon scale, and advanced display controls.':
        'UI密度、アイコン倍率、詳細表示の設定をまとめた子セクションを開閉します。',
    'Opens or closes the consolidated node-library child foldout for capsule prefix, asset marking, and library creation or rebuild commands.':
        'カプセル接頭辞、アセット化、ライブラリの作成と再構築のコマンドをまとめた子セクションを開閉します。',
    'Opens or closes the consolidated feature and pack child foldout. Use it to choose an active feature or pack and apply it without the old standalone catalog section.':
        '機能とパックの子セクションを開閉します。アクティブな機能やパックを選んで適用します。',
    'Opens or closes the consolidated precision child foldout for attributes, presets, selection strings, heatmaps, snapshots, and precision-polish commands.':
        '属性、プリセット、選択文字列、ヒートマップ、スナップショット、精度ポリッシュのコマンドをまとめた子セクションを開閉します。',
    'Opens or closes the consolidated diagnostics child foldout for active mesh status, generated node group counts, diagnostic exports, inventory export, and cleanup.':
        'アクティブメッシュの状態、生成済みノードグループの数、診断とインベントリの書き出し、片付けをまとめた子セクションを開閉します。',
    'Opens or closes the consolidated import/export child foldout for USD sidecar manifests, toolset bundle manifests, and design coverage JSON exports.':
        'USDサイドカーマニフェスト、ツール一式のバンドルマニフェスト、設計カバレッジJSONの書き出しをまとめた子セクションを開閉します。',
    'Opens or closes the consolidated debris utility child foldout for module refresh and attribution information that are not direct generation controls.':
        'モジュールの更新と「このアドオンについて」をまとめた子セクションを開閉します。',
    'Opens or closes the consolidated visual reference child foldout for optional reference popups and icon reference sheet export.':
        'リファレンスのポップアップとアイコンリファレンスシートの書き出しをまとめた子セクションを開閉します。',
    'Opens or closes the advanced coverage child foldout that summarizes feature coverage by category and design domain.':
        '機能の網羅をカテゴリと設計ドメインごとにまとめた詳細の子セクションを開閉します。',
    'Opens or closes the advanced storage child foldout that displays the extension user-data folder used for generated reports, manifests, and persistent settings.':
        '生成したレポート、マニフェスト、保存された設定に使うユーザーデータフォルダーを示す詳細の子セクションを開閉します。',
}
_STATIC.update(_CHILD_FOLDOUTS)
for _foldout_en, _foldout_ja in _CHILD_FOLDOUTS.items():
    I18N_DICT['ja_JP'][('*', _foldout_en)] = _foldout_ja
for (_context, _en), _ja in tuple(I18N_DICT['ja_JP'].items()):
    if _context == '*':
        I18N_DICT['ja_JP'][('Operator', _en)] = _ja
