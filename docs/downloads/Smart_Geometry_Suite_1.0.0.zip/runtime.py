# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

"""Transactional lifecycle for Smart Geometry Suite 8.2.46.

Registration is a single dependency-ordered transaction.  A generation ledger in
``bpy.app.driver_namespace`` owns exact class, PointerProperty, handler, msgbus,
menu, timer, modal, translation, and lazy-module identities.  Reloaded Python code
never removes or replaces a live older generation; it adopts the published ledger
and delegates lifecycle requests to that generation's exact callbacks.
"""

from __future__ import annotations

import importlib
import sys
from typing import Any

import bpy

from . import ownership

_LEDGER: dict[str, Any] | None = None
_ADOPTED = False
_REGISTERING = False
_UNREGISTERING = False
_CORE_MODULES: dict[str, Any] = {}

_CORE_LEAVES = (
    'properties',
    'operators',
    'debris_generators',
    'integrated_bridges',
    'ui',
    'manager_compat',
    'translation',
    'status_runtime',
)

_LAZY_IMPLEMENTATION_SUFFIXES = (
    '.mesh_tools',
    '.node_factory',
    '.diagnostics',
    '.icons',
    '.sgs_debris_mesh_data',
    '.proxy_cleanup',
    '.transform_guard',
    '.max_procedural_primitives.asset_utils',
    '.max_procedural_primitives.mesh_generators',
    '.max_procedural_primitives.node_interface',
    '.max_procedural_primitives.operators',
    '.max_procedural_primitives.runtime',
    '.max_procedural_primitives.specs',
    '.max_procedural_primitives.teapot_data',
    '.max_procedural_primitives.modifier_ui',
    '.grease_mesh.panels',
    '.grease_mesh.operators',
)


def _package_name() -> str:
    return str(__package__ or __name__.rsplit('.', 1)[0])


def _core(leaf: str):
    module = _CORE_MODULES.get(leaf)
    full_name = f'{_package_name()}.{leaf}'
    if module is None or sys.modules.get(full_name) is not module:
        module = importlib.import_module(full_name)
        _CORE_MODULES[leaf] = module
    return module


def _load_core_modules() -> dict[str, Any]:
    return {leaf: _core(leaf) for leaf in _CORE_LEAVES}


def _class_registration_order(modules: dict[str, Any]) -> tuple[type, ...]:
    """Build one deterministic RNA plan and reject mixed duplicate identities."""
    properties = modules['properties']
    operators = modules['operators']
    debris = modules['debris_generators']
    bridges = modules['integrated_bridges']
    ui = modules['ui']

    result: list[type] = []
    seen_identity: set[int] = set()
    seen_names: dict[str, type] = {}
    seen_rna_ids: dict[str, type] = {}

    def add(cls: type) -> None:
        if not isinstance(cls, type):
            raise RuntimeError('Smart Geometry registration plan contains a non-class entry')
        identity = id(cls)
        if identity in seen_identity:
            return
        name = str(getattr(cls, '__name__', '') or '')
        previous_name = seen_names.get(name)
        if previous_name is not None and previous_name is not cls:
            raise RuntimeError(f'Smart Geometry registration plan mixes class identities named {name}')
        rna_id = vars(cls).get('bl_idname', '')
        if isinstance(rna_id, str) and rna_id:
            previous_rna = seen_rna_ids.get(rna_id)
            if previous_rna is not None and previous_rna is not cls:
                raise RuntimeError(f'Smart Geometry registration plan duplicates bl_idname {rna_id}')
            seen_rna_ids[rna_id] = cls
        seen_identity.add(identity)
        seen_names[name] = cls
        result.append(cls)

    # PropertyGroup dependencies are registered exactly once before every pointer
    # and before all Operators/Panels that reference their RNA fields.
    add(properties.SGS_Settings)
    add(debris.SGS_DebrisSettings)
    for group in (
        tuple(operators.CLASSES),
        tuple(cls for cls in debris.CLASSES if cls is not debris.SGS_DebrisSettings),
        tuple(bridges.CLASSES),
        tuple(ui.CLASSES),
    ):
        for cls in group:
            add(cls)
    return tuple(result)


def _preflight_class_plan(classes: tuple[type, ...], settings_cls: type) -> None:
    """Validate the entire plan before acquiring the first Blender resource."""
    if sum(cls is settings_cls for cls in classes) != 1 or not classes or classes[0] is not settings_cls:
        raise RuntimeError('SGS_Settings must be the single first RNA class in the registration plan')
    for cls in classes:
        # Blender validates concrete callback code objects at RNA registration.
        # Reject every invalid execute/invoke/modal/cancel signature before the
        # transaction acquires its first class or other Blender resource.
        ownership.validate_operator_method_signatures(cls)
        probe = ownership.class_registration_probe(cls)
        if probe.get('foreign_same_name'):
            raise RuntimeError(f'Foreign RNA class identity already uses this name: {cls.__name__}')
        if probe.get('exact_registered'):
            raise RuntimeError(f'RNA class was already registered before this transaction: {cls.__name__}')


def _set_ui_active(active: bool) -> None:
    try:
        _core('ui').set_runtime_active(bool(active))
    except Exception:
        pass


def _clear_core_caches() -> None:
    for leaf, function_name in (
        ('ui', 'clear_runtime_caches'),
        ('operators', 'release_lazy_modules'),
        ('integrated_bridges', 'release_lazy_implementations'),
        ('debris_generators', 'clear_runtime_caches'),
        ('manager_compat', 'unregister'),
        ('status_runtime', 'clear_all'),
    ):
        module = _CORE_MODULES.get(leaf)
        callback = getattr(module, function_name, None) if module is not None else None
        if callable(callback):
            try:
                callback()
            except Exception:
                pass


def _reset_unpublished_or_stopped_module_state() -> None:
    """Reset non-RNA module flags after an exact rollback or full stop."""
    properties = _CORE_MODULES.get('properties')
    if properties is not None:
        try:
            properties._mark_hooks_suspended()
            properties._SUSPEND_SETTINGS_SAVE = True
        except Exception:
            pass
    debris = _CORE_MODULES.get('debris_generators')
    callback = getattr(debris, 'unregister_runtime', None) if debris is not None else None
    if callable(callback):
        try:
            callback()
        except Exception:
            pass
    manager = _CORE_MODULES.get('manager_compat')
    callback = getattr(manager, 'unregister', None) if manager is not None else None
    if callable(callback):
        try:
            callback()
        except Exception:
            pass


def _disable_feature_runtimes() -> bool:
    """Stop only exact feature resources from modules that are already loaded."""
    ok = True
    package = _package_name()
    always_on = sys.modules.get(package + '.always_on')
    if always_on is not None:
        callback = getattr(always_on, 'disable_all_persistent_features', None)
        if callable(callback):
            try:
                result = callback(bpy.context)
                if result is False:
                    ok = False
            except Exception:
                ok = False
    # Exact fallback cleanups are called only on the known loaded module objects;
    # no sys.modules scan, suffix ownership guess, or foreign callback removal.
    for name, callback_name in (
        (package + '.proxy_cleanup', 'unregister'),
        (package + '.transform_guard', 'cancel_scheduled_restore'),
        (package + '.max_procedural_primitives.runtime', 'unregister_handlers'),
        (package + '.max_procedural_primitives.modifier_ui', 'suspend_runtime'),
    ):
        module = sys.modules.get(name)
        callback = getattr(module, callback_name, None) if module is not None else None
        if callable(callback):
            try:
                result = callback()
                if result is False:
                    ok = False
            except Exception:
                ok = False
    return ok


def _is_lazy_implementation_name(name: str) -> bool:
    package = _package_name()
    return any(name == package + suffix or name.startswith(package + suffix + '.') for suffix in _LAZY_IMPLEMENTATION_SUFFIXES)


def release_lazy_implementation_caches() -> bool:
    """Release only modules explicitly recorded by the exact generation ledger."""
    ledger = _LEDGER or ownership.shared_ledger()
    ok = _disable_feature_runtimes()
    _clear_core_caches()
    if ownership.ledger_is_exact(ledger):
        # ownership.release_lazy_modules checks exact module identity before removal.
        names = {
            str(record.get('name') or '')
            for record in tuple(ledger.get('lazy_modules', ()))
            if _is_lazy_implementation_name(str(record.get('name') or ''))
        }
        if names:
            ok = ownership.release_lazy_modules(ledger, include_names=names) and ok
    return ok


def _dynamic_cleanup(ledger: dict[str, Any]) -> bool:
    ok = release_lazy_implementation_caches()
    try:
        _core('properties')._mark_hooks_suspended()
    except Exception:
        ok = False
    try:
        _core('manager_compat').unregister()
    except Exception:
        ok = False
    return ok


def _register_dynamic_resources(ledger: dict[str, Any]) -> None:
    properties = _core('properties')
    debris = _core('debris_generators')
    bridges = _core('integrated_bridges')
    manager_compat = _core('manager_compat')

    # Install the rollback cleanup before the first dynamic acquisition.  Any
    # later Manager cache, handler, msgbus, or menu failure therefore resets the
    # module-local hook state as well as removing exact ledger receipts.
    ownership.add_dynamic_cleanup(
        ledger,
        lambda: _dynamic_cleanup(ledger),
        'release_feature_runtimes_and_core_caches',
    )

    manager_compat.register()
    properties.register_persistence_hooks(ledger)

    mesh_add = getattr(bpy.types, 'VIEW3D_MT_mesh_add', None)
    if mesh_add is not None:
        ownership.register_menu(ledger, mesh_add, debris.menu_func)
    object_add = getattr(bpy.types, 'VIEW3D_MT_add', None)
    if object_add is not None:
        ownership.register_menu(ledger, object_add, bridges.max_add_menu_draw)



def _register_translations(ledger: dict[str, Any]) -> None:
    package = _package_name()
    translation = _core('translation')
    debris = _core('debris_generators')
    ownership.register_translation(ledger, package, translation.I18N_DICT)
    debris_dict = getattr(debris, '_TRANSLATIONS', None)
    if isinstance(debris_dict, dict):
        ownership.register_translation(ledger, package + '.debris_generators', debris_dict)
    max_translations = _core('max_procedural_primitives.translations')
    max_dict = getattr(max_translations, 'TRANSLATIONS', None)
    if isinstance(max_dict, dict):
        ownership.register_translation(ledger, package + '.max_procedural_primitives', max_dict)


def _restore_initial_json() -> None:
    properties = _core('properties')
    previous = bool(getattr(properties, '_STARTUP_RESTORE_PENDING', False))
    properties._STARTUP_RESTORE_PENDING = True
    try:
        properties.apply_saved_settings(bpy.context, reconcile_runtime=False)
    finally:
        properties._STARTUP_RESTORE_PENDING = previous


def _reconcile_current_rna_features() -> None:
    if not ownership.runtime_active_for_generation():
        return
    try:
        always_on = importlib.import_module(f'{_package_name()}.always_on')
        ledger = _LEDGER or ownership.shared_ledger()
        if ownership.ledger_is_exact(ledger):
            ownership.record_lazy_module(ledger, always_on)
        always_on.apply_all_persistent_features(bpy.context)
    except Exception:
        # Optional feature reconciliation must not break Suite registration.
        pass


def _runtime_api() -> dict[str, Any]:
    return {
        'suspend': _suspend_owned_generation,
        'resume': _resume_owned_generation,
        'repair': _repair_owned_generation,
        'flush': _flush_owned_generation,
        'shutdown': _shutdown_owned_generation,
    }


def _flush_owned_generation(ledger: dict[str, Any] | None = None) -> bool:
    ledger = ledger or _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return False
    try:
        return bool(_core('properties').flush_deferred_settings(bpy.context, force=True))
    except Exception:
        return False


def _suspend_owned_generation(
    ledger: dict[str, Any] | None = None, *, reason: str = 'manager_suspend',
) -> bool:
    ledger = ledger or _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return False
    if ledger.get('status') == 'SUSPENDED' and not any(
        ledger.get(key) for key in ('handlers', 'timers', 'msgbus', 'menus', 'dynamic_cleanups')
    ):
        _set_ui_active(False)
        return True
    # Mandatory ordering: dirty RNA must reach disk before any runtime mutation.
    if not _flush_owned_generation(ledger):
        return False
    _set_ui_active(False)
    ok = ownership.remove_dynamic_resources(ledger, reason=reason)
    try:
        _core('properties')._mark_hooks_suspended()
        _core('properties')._SUSPEND_SETTINGS_SAVE = True
    except Exception:
        ok = False
    if not ok:
        ledger['status'] = 'SUSPENDED'
        ledger['runtime_active'] = False
        return False
    ledger['status'] = 'SUSPENDED'
    ledger['runtime_active'] = False
    ledger['shutting_down'] = False
    return True


def _resume_owned_generation(
    ledger: dict[str, Any] | None = None, *, reason: str = 'manager_resume',
) -> bool:
    del reason
    ledger = ledger or _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return False
    if ledger.get('status') == 'ACTIVE' and bool(ledger.get('runtime_active')):
        _set_ui_active(True)
        return True
    if ledger.get('status') != 'SUSPENDED':
        return False
    # Resume never reloads JSON.  It first atomically commits the current RNA
    # values; a failure leaves the suspended generation byte-for-byte intact.
    if not _flush_owned_generation(ledger):
        return False

    _set_ui_active(False)
    ledger['status'] = 'ACTIVE'
    ledger['runtime_active'] = True
    ledger['shutting_down'] = False
    try:
        _register_dynamic_resources(ledger)
        _core('properties')._SUSPEND_SETTINGS_SAVE = False
        _reconcile_current_rna_features()
    except Exception:
        cleanup_ok = ownership.remove_dynamic_resources(ledger, reason='resume_rollback')
        ledger['status'] = 'SUSPENDED'
        ledger['runtime_active'] = False
        ledger['shutting_down'] = not bool(cleanup_ok)
        _set_ui_active(False)
        return False
    _set_ui_active(True)
    return True


def _repair_owned_generation(ledger: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return a pure cached health snapshot; never mutate RNA, JSON, or runtime."""
    ledger = ledger or _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return {
            'result': 'NOT_REGISTERED',
            'mutation_free': True,
            'generation': '',
        }
    return {
        'result': 'ACTIVE' if ledger.get('status') == 'ACTIVE' else 'SUSPENDED',
        'mutation_free': True,
        'generation': str(ledger.get('generation') or ''),
        'revision': str(ledger.get('revision') or ''),
        'runtime_active': bool(ledger.get('runtime_active')),
        'class_count': len(ledger.get('classes', ())),
        'pointer_count': len(ledger.get('pointers', ())),
        'handler_count': len(ledger.get('handlers', ())),
        'timer_count': len(ledger.get('timers', ())),
        'msgbus_count': len(ledger.get('msgbus', ())),
        'menu_count': len(ledger.get('menus', ())),
        'modal_count': ownership.active_modal_count(ledger),
        'registration_failures': len(ledger.get('registration_failures', ())),
        'cleanup_failures': len(ledger.get('cleanup_failures', ())),
    }


def _shutdown_owned_generation(
    ledger: dict[str, Any] | None = None, *, reason: str = 'unregister',
) -> bool:
    global _LEDGER, _ADOPTED
    ledger = ledger or _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return True
    # A failed registration transaction has no authoritative settings boundary;
    # retry exact cleanup directly from its inert recovery ledger.
    if ledger.get('status') != 'RECOVERY_REQUIRED':
        # Preserve current RNA and the complete generation on persistence failure.
        if not _flush_owned_generation(ledger):
            return False
    _set_ui_active(False)
    ok = ownership.stop_generation(ledger, reason=reason)
    if ok:
        _LEDGER = None
        _ADOPTED = False
        _clear_core_caches()
        _reset_unpublished_or_stopped_module_state()
    return bool(ok)


def register() -> bool:
    """Register once or adopt an exact live older generation without mutation."""
    global _LEDGER, _ADOPTED, _REGISTERING
    if _REGISTERING or _UNREGISTERING:
        return False
    state, existing = ownership.registration_state()
    if state == 'CURRENT':
        _LEDGER = existing
        _ADOPTED = False
        return True
    if state == 'ADOPT_OLD':
        _LEDGER = existing
        _ADOPTED = True
        return True
    if state == 'BUSY':
        raise RuntimeError('Smart Geometry lifecycle transaction is already in progress')
    if state == 'FOREIGN':
        raise RuntimeError('Smart Geometry ownership ledger key is occupied by foreign data')

    _REGISTERING = True
    ledger = ownership.new_ledger()
    _set_ui_active(False)
    try:
        modules = _load_core_modules()
        class_plan = _class_registration_order(modules)
        _preflight_class_plan(class_plan, modules['properties'].SGS_Settings)
        for cls in class_plan:
            ownership.register_class(ledger, cls)

        modules['properties'].register_properties(
            ledger, register_hooks=False, restore_settings=False,
        )
        modules['debris_generators'].register_runtime(
            ledger=ledger, register_menu=False, register_translation=False,
        )
        _register_translations(ledger)
        _restore_initial_json()
        _register_dynamic_resources(ledger)

        ownership.publish_ledger(
            ledger,
            _shutdown_owned_generation,
            runtime_api=_runtime_api(),
        )
        _LEDGER = ledger
        _ADOPTED = False
        modules['properties']._SUSPEND_SETTINGS_SAVE = False
        _set_ui_active(True)
        _reconcile_current_rna_features()
        return True
    except Exception:
        _set_ui_active(False)
        rolled_back = ownership.rollback_registration(ledger)
        if rolled_back:
            _LEDGER = None
            _ADOPTED = False
            _clear_core_caches()
            _reset_unpublished_or_stopped_module_state()
        else:
            ownership.retain_failed_ledger(
                ledger, _shutdown_owned_generation, runtime_api=_runtime_api(),
            )
            _LEDGER = ledger
            _ADOPTED = False
        raise
    finally:
        _REGISTERING = False


def suspend() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        _set_ui_active(False)
        return True
    if str(ledger.get('generation') or '') != ownership.GENERATION_TOKEN:
        result = ownership.call_runtime_api(ledger, 'suspend', ledger, reason='manager_suspend')
        return bool(result)
    return _suspend_owned_generation(ledger, reason='manager_suspend')


def resume(*, repair: bool = False) -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    if repair:
        result = safe_reload()
        return bool(result.get('mutation_free')) if isinstance(result, dict) else bool(result)
    if not ownership.ledger_is_exact(ledger):
        return register()
    if str(ledger.get('generation') or '') != ownership.GENERATION_TOKEN:
        return bool(ownership.call_runtime_api(ledger, 'resume', ledger, reason='manager_resume'))
    return _resume_owned_generation(ledger, reason='manager_resume')


def safe_reload() -> dict[str, Any]:
    """Manager repair hook: a strictly mutation-free cached health query."""
    ledger = _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return _repair_owned_generation(None)
    if str(ledger.get('generation') or '') != ownership.GENERATION_TOKEN:
        result = ownership.call_runtime_api(ledger, 'repair', ledger)
        return result if isinstance(result, dict) else {
            'result': 'ADOPTED_GENERATION', 'mutation_free': True,
            'generation': str(ledger.get('generation') or ''),
        }
    return _repair_owned_generation(ledger)


def unregister() -> bool:
    global _LEDGER, _ADOPTED, _UNREGISTERING
    if _UNREGISTERING:
        return False
    ledger = _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return True
    _UNREGISTERING = True
    try:
        if str(ledger.get('generation') or '') != ownership.GENERATION_TOKEN:
            ok = bool(ownership.request_exact_shutdown(ledger, reason='extension_unregister'))
            if ok:
                _LEDGER = None
                _ADOPTED = False
                _clear_core_caches()
                _reset_unpublished_or_stopped_module_state()
            return ok
        return _shutdown_owned_generation(ledger, reason='extension_unregister')
    finally:
        _UNREGISTERING = False


def on_load_pre_boundary() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return True
    # The persistence handler remains installed across a file load.  Only modals,
    # feature runtimes, and heavy implementation caches are stopped here.
    ok = ownership.cancel_all_modals(ledger, 'load_pre')
    ok = release_lazy_implementation_caches() and ok
    ledger['shutting_down'] = False
    return ok and ownership.active_modal_count(ledger) == 0


def on_load_post_boundary() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return True
    ledger['shutting_down'] = False
    if ledger.get('status') == 'ACTIVE':
        ledger['runtime_active'] = True
    return True


def on_exit_pre_boundary() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    if not ownership.ledger_is_exact(ledger):
        return True
    ok = ownership.cancel_all_modals(ledger, 'exit_pre')
    ok = release_lazy_implementation_caches() and ok
    return ok and ownership.active_modal_count(ledger) == 0


def ensure_runtime_initialized() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    return bool(
        ownership.ledger_is_exact(ledger)
        and ledger.get('status') == 'ACTIVE'
        and bool(ledger.get('runtime_active'))
    )


def is_registered() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    return bool(ownership.ledger_is_exact(ledger) and ledger.get('status') in {'ACTIVE', 'SUSPENDED'})


def is_suspended() -> bool:
    ledger = _LEDGER or ownership.shared_ledger()
    return bool(ownership.ledger_is_exact(ledger) and ledger.get('status') == 'SUSPENDED')
