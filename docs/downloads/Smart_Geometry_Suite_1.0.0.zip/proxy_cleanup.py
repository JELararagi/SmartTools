# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default package

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import bpy


LEGACY_PROXY_KEYS = (
    'ms_shape_mesh_proxy_link_id',
    'ms_shape_mesh_proxy_source',
    'ms_shape_mesh_proxy_source_id',
    'ms_shape_mesh_proxy_object',
    'ms_shape_mesh_proxy_object_id',
    'ms_shape_proxy_internal',
)
LEGACY_INTERNAL_FLAG = 'ms_shape_proxy_internal'
LEGACY_NODE_KEYS = ('ms_shape_proxy_internal', 'ms_shape_curve_mesh_converter')
LEGACY_PROXY_OBJECT_NAME_TOKENS = ('_SMS_CurveMesh',)
LEGACY_PROXY_MESH_NAME_TOKENS = ('_SMS_MeshData',)
SGS_EPHEMERAL_PROXY_FLAG = 'sgs_ephemeral_proxy'
SGS_EPHEMERAL_PROXY_BUILDER = 'v5_visible_distribution_proxy_instances'
SGS_GENERATED_FLAG = 'smart_geometry_suite_generated'
SGS_OWNER_KEY = 'jelararagi_sgs_owner_suite'
SGS_OWNER_REVISION_KEY = 'jelararagi_sgs_owner_revision'
SGS_OWNER_GENERATION_KEY = 'jelararagi_sgs_owner_generation'
_TIMER_RUNNING = False
_TIMER_REMAINING_PASSES = 0
_TIMER_INTERVAL = 30.0
_MAX_TIMER_PASSES = 1
_LAST_REPORT: dict[str, int] = {}
_AUTOMATIC_ENABLED = False


@dataclass(slots=True)
class CleanupReport:
    legacy_internal_objects: int = 0
    legacy_source_links: int = 0
    legacy_node_groups: int = 0
    legacy_orphan_meshes: int = 0
    sgs_ephemeral_proxies: int = 0
    sgs_orphan_meshes: int = 0
    transform_snapshots: int = 0

    def as_dict(self) -> dict[str, int]:
        return {
            'legacy_internal_objects': int(self.legacy_internal_objects),
            'legacy_source_links': int(self.legacy_source_links),
            'legacy_node_groups': int(self.legacy_node_groups),
            'legacy_orphan_meshes': int(self.legacy_orphan_meshes),
            'sgs_ephemeral_proxies': int(self.sgs_ephemeral_proxies),
            'sgs_orphan_meshes': int(self.sgs_orphan_meshes),
            'transform_snapshots': int(self.transform_snapshots),
        }

    def total(self) -> int:
        return sum(self.as_dict().values())


def _idprop_bool(idblock: Any, key: str, default: bool = False) -> bool:
    try:
        return bool(idblock.get(key, default))
    except Exception:
        return bool(default)


def _idprop_str(idblock: Any, key: str) -> str:
    try:
        return str(idblock.get(key, '') or '')
    except Exception:
        return ''


def _has_idprop(idblock: Any, key: str) -> bool:
    try:
        return key in idblock.keys()
    except Exception:
        return False


def _delete_idprop(idblock: Any, key: str) -> bool:
    try:
        if key in idblock.keys():
            del idblock[key]
            return True
    except Exception:
        pass
    return False


def _name_contains_any(name: str, tokens: tuple[str, ...]) -> bool:
    text = str(name or '')
    return any(token in text for token in tokens)


def _is_exact_sgs_owned(idblock: Any) -> bool:
    try:
        from . import ownership
        ledger = ownership.shared_ledger()
        if not ownership.ledger_is_exact(ledger):
            return False
        generation = str(ledger.get('generation') or '')
        return bool(
            idblock is not None
            and idblock.get(SGS_OWNER_KEY) == ownership.SUITE_ID
            and idblock.get(SGS_OWNER_REVISION_KEY) == ownership.REVISION
            and idblock.get(SGS_OWNER_GENERATION_KEY) == generation
        )
    except Exception:
        return False


def _is_legacy_internal_proxy_object(obj: Any) -> bool:
    if obj is None or not _is_exact_sgs_owned(obj):
        return False
    try:
        if _idprop_bool(obj, LEGACY_INTERNAL_FLAG, False):
            return True
        if _name_contains_any(getattr(obj, 'name', ''), LEGACY_PROXY_OBJECT_NAME_TOKENS):
            return any(_has_idprop(obj, key) for key in LEGACY_PROXY_KEYS)
    except Exception:
        pass
    return False


def _is_legacy_internal_node_group(group: Any) -> bool:
    if group is None or not _is_exact_sgs_owned(group):
        return False
    try:
        if any(_idprop_bool(group, key, False) for key in LEGACY_NODE_KEYS):
            return True
        return str(getattr(group, 'name', '') or '').startswith('SMS Curve To Mesh -') and any(_has_idprop(group, key) for key in LEGACY_NODE_KEYS)
    except Exception:
        return False


def _is_legacy_proxy_mesh(mesh: Any) -> bool:
    if mesh is None or not _is_exact_sgs_owned(mesh):
        return False
    try:
        if any(_has_idprop(mesh, key) for key in LEGACY_PROXY_KEYS):
            return True
        return _name_contains_any(getattr(mesh, 'name', ''), LEGACY_PROXY_MESH_NAME_TOKENS)
    except Exception:
        return False


def _source_links_to_proxy(source: Any, proxy: Any) -> bool:
    if source is None or proxy is None:
        return False
    try:
        target_name = _idprop_str(source, 'ms_shape_mesh_proxy_object')
        if target_name and target_name == getattr(proxy, 'name', ''):
            return True
        source_link = _idprop_str(source, 'ms_shape_mesh_proxy_object_id') or _idprop_str(source, 'ms_shape_mesh_proxy_link_id')
        proxy_link = _idprop_str(proxy, 'ms_shape_mesh_proxy_link_id')
        return bool(source_link and proxy_link and source_link == proxy_link)
    except Exception:
        return False


def _legacy_proxy_is_stale(obj: Any, objects_by_name: dict[str, Any]) -> bool:
    if not _is_legacy_internal_proxy_object(obj):
        return False
    source_name = _idprop_str(obj, 'ms_shape_mesh_proxy_source')
    if not source_name:
        return True
    source = objects_by_name.get(source_name)
    if source is None:
        return True
    return not _source_links_to_proxy(source, obj)


def _remove_object_and_private_data(obj: Any, report: CleanupReport, counter_attr: str) -> None:
    data = None
    try:
        data = getattr(obj, 'data', None)
    except Exception:
        data = None
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
        setattr(report, counter_attr, getattr(report, counter_attr) + 1)
    except Exception:
        return
    if data is not None:
        try:
            if int(getattr(data, 'users', 0) or 0) == 0:
                if _is_legacy_proxy_mesh(data):
                    bpy.data.meshes.remove(data)
                    report.legacy_orphan_meshes += 1
                elif _is_exact_sgs_owned(data) and (_idprop_bool(data, SGS_EPHEMERAL_PROXY_FLAG, False) or _name_contains_any(getattr(data, 'name', ''), ('SGS_Distribution_Proxy_Instances_Mesh',))):
                    bpy.data.meshes.remove(data)
                    report.sgs_orphan_meshes += 1
        except Exception:
            pass


def _delete_legacy_source_links_for_missing_targets(objects_by_name: dict[str, Any], report: CleanupReport) -> None:
    for obj in tuple(objects_by_name.values()):
        try:
            if not _is_exact_sgs_owned(obj):
                continue
            target_name = _idprop_str(obj, 'ms_shape_mesh_proxy_object')
            has_legacy_link = any(_has_idprop(obj, key) for key in LEGACY_PROXY_KEYS if key != LEGACY_INTERNAL_FLAG)
            if not has_legacy_link:
                continue
            target_missing = bool(target_name and target_name not in objects_by_name)
            target_is_stale = False
            if target_name and target_name in objects_by_name:
                target_is_stale = _legacy_proxy_is_stale(objects_by_name[target_name], objects_by_name)
            if not target_name:
                # Link IDs without a target object are not actionable and should
                # not be kept as scene metadata.
                target_missing = True
            if not (target_missing or target_is_stale):
                continue
            changed = False
            for key in LEGACY_PROXY_KEYS:
                if key == LEGACY_INTERNAL_FLAG:
                    continue
                changed = _delete_idprop(obj, key) or changed
            if changed:
                report.legacy_source_links += 1
        except Exception:
            pass


def _remove_legacy_node_groups(report: CleanupReport) -> None:
    for group in tuple(getattr(bpy.data, 'node_groups', []) or []):
        if not _is_legacy_internal_node_group(group):
            continue
        try:
            if int(getattr(group, 'users', 0) or 0) > 0:
                continue
            bpy.data.node_groups.remove(group)
            report.legacy_node_groups += 1
        except Exception:
            pass


def _remove_orphan_legacy_meshes(report: CleanupReport) -> None:
    for mesh in tuple(getattr(bpy.data, 'meshes', []) or []):
        if not _is_legacy_proxy_mesh(mesh):
            continue
        try:
            if int(getattr(mesh, 'users', 0) or 0) == 0:
                bpy.data.meshes.remove(mesh)
                report.legacy_orphan_meshes += 1
        except Exception:
            pass


def _is_sgs_ephemeral_distribution_proxy(obj: Any) -> bool:
    if obj is None or not _is_exact_sgs_owned(obj):
        return False
    try:
        if _idprop_bool(obj, SGS_EPHEMERAL_PROXY_FLAG, False):
            return True
        if _idprop_str(obj, 'sgs_builder') == SGS_EPHEMERAL_PROXY_BUILDER:
            return True
        return False
    except Exception:
        return False


def cleanup_sgs_distribution_proxies(*, source_name: str | None = None, remove_all: bool = False) -> dict[str, int]:
    """Remove generated visible distribution proxy caches.

    When source_name is provided, old proxies for that source are replaced before
    a new proxy cache is generated.  Without source_name, only orphaned proxies
    whose source object no longer exists are removed.
    """
    report = CleanupReport()
    objects_by_name = {obj.name: obj for obj in tuple(getattr(bpy.data, 'objects', []) or [])}
    source_filter = str(source_name or '')
    for obj in tuple(objects_by_name.values()):
        if not _is_sgs_ephemeral_distribution_proxy(obj):
            continue
        try:
            obj_source = _idprop_str(obj, 'sgs_source_object')
            should_remove = bool(remove_all)
            if source_filter:
                should_remove = obj_source == source_filter
            elif not obj_source or obj_source not in objects_by_name:
                should_remove = True
            if not should_remove:
                continue
            _remove_object_and_private_data(obj, report, 'sgs_ephemeral_proxies')
        except Exception:
            pass
    return report.as_dict()


def cleanup_legacy_proxy_data() -> dict[str, int]:
    """Remove stale proxy data that does not participate in current behavior."""
    report = CleanupReport()
    objects_by_name = {obj.name: obj for obj in tuple(getattr(bpy.data, 'objects', []) or [])}

    for obj in tuple(objects_by_name.values()):
        try:
            if _legacy_proxy_is_stale(obj, objects_by_name):
                _remove_object_and_private_data(obj, report, 'legacy_internal_objects')
        except Exception:
            pass

    objects_by_name = {obj.name: obj for obj in tuple(getattr(bpy.data, 'objects', []) or [])}
    _delete_legacy_source_links_for_missing_targets(objects_by_name, report)
    _remove_legacy_node_groups(report)
    _remove_orphan_legacy_meshes(report)
    try:
        from . import transform_guard
        report.transform_snapshots += int(transform_guard.cleanup_scene_transform_snapshots() or 0)
    except Exception:
        pass
    return report.as_dict()


def cleanup_scene_proxy_data() -> dict[str, int]:
    report = CleanupReport()
    legacy = cleanup_legacy_proxy_data()
    sgs = cleanup_sgs_distribution_proxies()
    for key, value in legacy.items():
        if hasattr(report, key):
            setattr(report, key, getattr(report, key) + int(value or 0))
    for key, value in sgs.items():
        if hasattr(report, key):
            setattr(report, key, getattr(report, key) + int(value or 0))
    _store_last_report(report.as_dict())
    return report.as_dict()


def _store_last_report(report: dict[str, int]) -> None:
    global _LAST_REPORT
    _LAST_REPORT = dict(report)


def last_report() -> dict[str, int]:
    return dict(_LAST_REPORT)


_HANDLER_TAG = 'automatic_proxy_cleanup.handlers'
_TIMER_TAG = 'automatic_proxy_cleanup.timer'


def _cleanup_timer():
    global _TIMER_RUNNING, _TIMER_REMAINING_PASSES
    try:
        cleanup_scene_proxy_data()
    except Exception:
        pass
    _TIMER_REMAINING_PASSES = max(0, int(_TIMER_REMAINING_PASSES) - 1)
    _TIMER_RUNNING = False
    # Bounded one-shot only. No periodic continuation is permitted.
    return None


def _ledger():
    try:
        from . import ownership
        return ownership.shared_ledger()
    except Exception:
        return None


def schedule_cleanup(passes: int = _MAX_TIMER_PASSES, first_interval: float = 0.5) -> None:
    global _TIMER_RUNNING, _TIMER_REMAINING_PASSES
    if not _AUTOMATIC_ENABLED or _TIMER_RUNNING:
        return
    try:
        from . import ownership
        ledger = _ledger()
        if not ownership.runtime_active_for_generation() or not ownership.ledger_is_exact(ledger):
            return
        ownership.remove_tagged_dynamic_resources(ledger, _TIMER_TAG)
        _TIMER_REMAINING_PASSES = 1 if int(passes or 1) > 0 else 0
        if _TIMER_REMAINING_PASSES <= 0:
            return
        ownership.register_timer(
            ledger, _cleanup_timer, first_interval=max(0.1, float(first_interval)),
            persistent=False, tag=_TIMER_TAG,
        )
        _TIMER_RUNNING = True
    except Exception:
        _TIMER_RUNNING = False
        _TIMER_REMAINING_PASSES = 0


def _load_post_handler(*_args) -> None:
    schedule_cleanup(passes=1, first_interval=0.5)


def _save_pre_handler(*_args) -> None:
    try:
        cleanup_scene_proxy_data()
    except Exception:
        pass


def sync(enabled: bool) -> bool:
    """Reconcile exact generation-owned event hooks with the feature toggle."""
    global _AUTOMATIC_ENABLED
    enabled = bool(enabled)
    if not enabled:
        return unregister()
    try:
        from . import ownership
        ledger = _ledger()
        if not ownership.runtime_active_for_generation() or not ownership.ledger_is_exact(ledger):
            _AUTOMATIC_ENABLED = False
            return False
        existing = any(str(record.get('tag') or '') == _HANDLER_TAG for record in ledger.get('handlers', ()))
        if not existing:
            ownership.register_handler(
                ledger, bpy.app.handlers.load_post, _load_post_handler,
                persistent=True, tag=_HANDLER_TAG,
            )
            ownership.register_handler(
                ledger, bpy.app.handlers.save_pre, _save_pre_handler,
                persistent=True, tag=_HANDLER_TAG,
            )
        _AUTOMATIC_ENABLED = True
        # No startup scan and no idle timer. The first cleanup is triggered only by
        # a subsequent load event or an explicit schedule_cleanup call.
        return True
    except Exception:
        _AUTOMATIC_ENABLED = False
        return False


def register() -> None:
    try:
        from . import always_on
        sync(always_on.feature_value('automatic_proxy_cleanup', bpy.context))
    except Exception:
        sync(False)


def unregister() -> bool:
    global _TIMER_RUNNING, _TIMER_REMAINING_PASSES, _AUTOMATIC_ENABLED
    _AUTOMATIC_ENABLED = False
    ok = True
    try:
        from . import ownership
        ledger = _ledger()
        if ownership.ledger_is_exact(ledger):
            ok = ownership.remove_tagged_dynamic_resources(ledger, _TIMER_TAG) and ok
            ok = ownership.remove_tagged_dynamic_resources(ledger, _HANDLER_TAG) and ok
    except Exception:
        ok = False
    _TIMER_REMAINING_PASSES = 0
    _TIMER_RUNNING = False
    return ok


def clear_runtime_caches() -> None:
    global _LAST_REPORT
    _LAST_REPORT = {}
