# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Procedural mesh kernels used by the Blender add-on.

These functions are intentionally written without bpy dependencies so they can be
syntax-checked outside Blender. They return dictionaries with vertices, faces and
smooth-shading hints.
"""

from __future__ import annotations

import math
import random
from typing import Dict, Iterable, List, Sequence, Tuple

Vec3 = Tuple[float, float, float]
Face = Tuple[int, ...]
MeshData = Dict[str, object]

TAU = math.pi * 2.0
EPS = 1.0e-8


def f(params: Dict[str, object], key: str, default: float = 0.0) -> float:
    try:
        return float(params.get(key, default))
    except Exception:
        return float(default)


def i(params: Dict[str, object], key: str, default: int = 0, low: int | None = None, high: int | None = None) -> int:
    try:
        value = int(round(float(params.get(key, default))))
    except Exception:
        value = int(default)
    if low is not None:
        value = max(low, value)
    if high is not None:
        value = min(high, value)
    return value


def b(params: Dict[str, object], key: str, default: bool = False) -> bool:
    value = params.get(key, default)
    if isinstance(value, str):
        return value.lower() in {"1", "true", "yes", "on"}
    return bool(value)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def add(a: Vec3, c: Vec3) -> Vec3:
    return (a[0] + c[0], a[1] + c[1], a[2] + c[2])


def sub(a: Vec3, c: Vec3) -> Vec3:
    return (a[0] - c[0], a[1] - c[1], a[2] - c[2])


def mul(a: Vec3, s: float) -> Vec3:
    return (a[0] * s, a[1] * s, a[2] * s)


def dot(a: Vec3, c: Vec3) -> float:
    return a[0] * c[0] + a[1] * c[1] + a[2] * c[2]


def cross(a: Vec3, c: Vec3) -> Vec3:
    return (a[1] * c[2] - a[2] * c[1], a[2] * c[0] - a[0] * c[2], a[0] * c[1] - a[1] * c[0])


def length(a: Vec3) -> float:
    return math.sqrt(dot(a, a))


def normalize(a: Vec3, fallback: Vec3 = (0.0, 0.0, 1.0)) -> Vec3:
    l = length(a)
    if l < EPS:
        return fallback
    return (a[0] / l, a[1] / l, a[2] / l)


def lerp(a: Vec3, c: Vec3, t: float) -> Vec3:
    return (a[0] + (c[0] - a[0]) * t, a[1] + (c[1] - a[1]) * t, a[2] + (c[2] - a[2]) * t)


def rotate_z(v: Vec3, angle: float) -> Vec3:
    ca, sa = math.cos(angle), math.sin(angle)
    return (v[0] * ca - v[1] * sa, v[0] * sa + v[1] * ca, v[2])


def rotate_x(v: Vec3, angle: float) -> Vec3:
    ca, sa = math.cos(angle), math.sin(angle)
    return (v[0], v[1] * ca - v[2] * sa, v[1] * sa + v[2] * ca)


def rotate_y(v: Vec3, angle: float) -> Vec3:
    ca, sa = math.cos(angle), math.sin(angle)
    return (v[0] * ca + v[2] * sa, v[1], -v[0] * sa + v[2] * ca)


def transform_vertex(v: Vec3, offset: Vec3 = (0.0, 0.0, 0.0), scale: Vec3 = (1.0, 1.0, 1.0), rot: Vec3 = (0.0, 0.0, 0.0)) -> Vec3:
    x = (v[0] * scale[0], v[1] * scale[1], v[2] * scale[2])
    if rot[0]:
        x = rotate_x(x, rot[0])
    if rot[1]:
        x = rotate_y(x, rot[1])
    if rot[2]:
        x = rotate_z(x, rot[2])
    return add(x, offset)


class Builder:
    def __init__(self):
        self.verts: List[Vec3] = []
        self.faces: List[Face] = []

    def add_vertex(self, v: Vec3) -> int:
        self.verts.append((float(v[0]), float(v[1]), float(v[2])))
        return len(self.verts) - 1

    def add_face(self, face: Sequence[int]) -> None:
        if len(face) >= 3:
            self.faces.append(tuple(int(x) for x in face))

    def add_mesh(self, verts: Sequence[Vec3], faces: Sequence[Sequence[int]], offset: Vec3 = (0, 0, 0), scale: Vec3 = (1, 1, 1), rot: Vec3 = (0, 0, 0)) -> None:
        base = len(self.verts)
        for v in verts:
            self.verts.append(transform_vertex(v, offset, scale, rot))
        for face in faces:
            self.add_face([base + idx for idx in face])

    def build(self, smooth: bool = False) -> MeshData:
        return {"verts": self.verts, "faces": self.faces, "smooth": bool(smooth)}


def mesh(verts: Sequence[Vec3], faces: Sequence[Sequence[int]], smooth: bool = False, edges: Sequence[Sequence[int]] | None = None) -> MeshData:
    return {"verts": list(verts), "edges": [tuple(edge) for edge in (edges or [])], "faces": [tuple(face) for face in faces], "smooth": bool(smooth)}

def _mesh_weld_tolerance(verts: Sequence[Vec3]) -> float:
    """Return a stable weld tolerance for procedural primitive coordinates.

    Max-style primitives are expected to share vertex indices wherever visible
    edges meet.  Many builder functions generate grids per face, so matching
    coordinates must be collapsed before creating Blender mesh data.
    """
    if not verts:
        return 1.0e-6
    min_x = min(v[0] for v in verts); max_x = max(v[0] for v in verts)
    min_y = min(v[1] for v in verts); max_y = max(v[1] for v in verts)
    min_z = min(v[2] for v in verts); max_z = max(v[2] for v in verts)
    span = max(max_x - min_x, max_y - min_y, max_z - min_z, 1.0)
    return max(1.0e-6, span * 1.0e-8)


def _is_finite_vertex(v: object) -> bool:
    try:
        return len(v) == 3 and all(math.isfinite(float(c)) for c in v)  # type: ignore[arg-type]
    except Exception:
        return False


def _ordered_unique_face(face: Sequence[int]) -> Tuple[int, ...]:
    cleaned: List[int] = []
    for idx in face:
        try:
            idx = int(idx)
        except Exception:
            continue
        if cleaned and cleaned[-1] == idx:
            continue
        cleaned.append(idx)
    while len(cleaned) > 1 and cleaned[0] == cleaned[-1]:
        cleaned.pop()
    # Degenerate quads produced by welding a collapsed pole become triangles.
    if len(set(cleaned)) != len(cleaned):
        unique: List[int] = []
        seen = set()
        for idx in cleaned:
            if idx in seen:
                continue
            seen.add(idx)
            unique.append(idx)
        cleaned = unique
    return tuple(cleaned)


def _face_area_sq(verts: Sequence[Vec3], face: Sequence[int]) -> float:
    if len(face) < 3:
        return 0.0
    # Newell normal works for triangles and n-gons and is stable enough for the
    # planar procedural faces generated here.
    nx = ny = nz = 0.0
    count = len(face)
    for pos, idx in enumerate(face):
        try:
            a = verts[idx]
            c = verts[face[(pos + 1) % count]]
        except Exception:
            return 0.0
        nx += (a[1] - c[1]) * (a[2] + c[2])
        ny += (a[2] - c[2]) * (a[0] + c[0])
        nz += (a[0] - c[0]) * (a[1] + c[1])
    return nx * nx + ny * ny + nz * nz


def sanitize_mesh_data(data: MeshData, *, weld_vertices: bool = True) -> MeshData:
    """Clean generated mesh data before Blender receives it.

    Mesh primitives are welded so visible shared boundaries use shared vertex
    indices.  Shape primitives may be edge-only data, so this pass also remaps,
    deduplicates and compacts explicit edges without requiring faces.
    """
    raw_verts = data.get("verts", []) if isinstance(data, dict) else []
    raw_edges = data.get("edges", []) if isinstance(data, dict) else []
    raw_faces = data.get("faces", []) if isinstance(data, dict) else []
    smooth = bool(data.get("smooth", False)) if isinstance(data, dict) else False
    verts: List[Vec3] = []
    old_to_source: Dict[int, int] = {}
    for old_idx, v in enumerate(raw_verts):  # type: ignore[assignment]
        if not _is_finite_vertex(v):
            continue
        old_to_source[int(old_idx)] = len(verts)
        verts.append((float(v[0]), float(v[1]), float(v[2])))  # type: ignore[index]
    if not verts:
        return {"verts": [], "edges": [], "faces": [], "smooth": smooth, "topology_sanitized": True}

    source_to_welded: Dict[int, int] = {}
    welded_verts: List[Vec3] = []
    if weld_vertices:
        tol = _mesh_weld_tolerance(verts)
        quantized: Dict[Tuple[int, int, int], int] = {}
        for src_idx, v in enumerate(verts):
            key = (int(round(v[0] / tol)), int(round(v[1] / tol)), int(round(v[2] / tol)))
            if key in quantized:
                source_to_welded[src_idx] = quantized[key]
            else:
                new_idx = len(welded_verts)
                quantized[key] = new_idx
                source_to_welded[src_idx] = new_idx
                welded_verts.append(tuple(0.0 if abs(c) <= tol else c for c in v))  # type: ignore[arg-type]
    else:
        welded_verts = list(verts)
        source_to_welded = {idx: idx for idx in range(len(verts))}

    area_limit = max(_mesh_weld_tolerance(welded_verts) ** 2, 1.0e-20)
    faces: List[Face] = []
    face_keys = set()
    for raw_face in raw_faces:  # type: ignore[assignment]
        mapped: List[int] = []
        try:
            iterator = list(raw_face)
        except Exception:
            continue
        for old_idx in iterator:
            try:
                src_idx = old_to_source[int(old_idx)]
                mapped.append(source_to_welded[src_idx])
            except Exception:
                continue
        face = _ordered_unique_face(mapped)
        if len(face) < 3:
            continue
        if _face_area_sq(welded_verts, face) <= area_limit:
            continue
        face_key = tuple(sorted(face))
        if face_key in face_keys:
            continue
        face_keys.add(face_key)
        faces.append(face)

    edges: List[Tuple[int, int]] = []
    edge_keys = set()
    for raw_edge in raw_edges:  # type: ignore[assignment]
        try:
            a, c = list(raw_edge)[:2]
            src_a = old_to_source[int(a)]
            src_c = old_to_source[int(c)]
            ea = source_to_welded[src_a]
            ec = source_to_welded[src_c]
        except Exception:
            continue
        if ea == ec:
            continue
        key = tuple(sorted((ea, ec)))
        if key in edge_keys:
            continue
        edge_keys.add(key)
        edges.append((ea, ec))

    # Keep explicit face boundary edges implicit; Blender will derive them with
    # calc_edges=True.  Edge-only shapes still retain their line topology.
    used = sorted({idx for face in faces for idx in face} | {idx for edge in edges for idx in edge})
    if not used:
        return {"verts": [], "edges": [], "faces": [], "smooth": smooth, "topology_sanitized": True}
    remap = {old: new for new, old in enumerate(used)}
    final_verts = [welded_verts[idx] for idx in used]
    final_faces = [tuple(remap[idx] for idx in face) for face in faces]
    final_edges = [tuple(remap[idx] for idx in edge) for edge in edges if edge[0] in remap and edge[1] in remap]
    return {"verts": final_verts, "edges": final_edges, "faces": final_faces, "smooth": smooth, "topology_sanitized": True}


def angle_range(params: Dict[str, object], default_steps: int) -> Tuple[List[float], bool]:
    sides = max(3, int(default_steps))
    if b(params, "slice_on", False):
        start = math.radians(f(params, "slice_from", 0.0))
        end = math.radians(f(params, "slice_to", 360.0))
        if abs(end - start) < EPS:
            end = start + TAU
        if end < start:
            end += TAU
        return [start + (end - start) * k / sides for k in range(sides + 1)], False
    return [TAU * k / sides for k in range(sides)], True


def add_grid(builder: Builder, origin: Vec3, uvec: Vec3, vvec: Vec3, us: int, vs: int, flip: bool = False) -> None:
    us = max(1, int(us))
    vs = max(1, int(vs))
    grid = []
    for y in range(vs + 1):
        row = []
        for x in range(us + 1):
            pnt = add(origin, add(mul(uvec, x / us), mul(vvec, y / vs)))
            row.append(builder.add_vertex(pnt))
        grid.append(row)
    for y in range(vs):
        for x in range(us):
            face = (grid[y][x], grid[y][x + 1], grid[y + 1][x + 1], grid[y + 1][x])
            builder.add_face(tuple(reversed(face)) if flip else face)


def make_box(params: Dict[str, object]) -> MeshData:
    lx = max(EPS, abs(f(params, "length", f(params, "size", 25.0))))
    wy = max(EPS, abs(f(params, "width", lx)))
    hz = max(EPS, abs(f(params, "height", lx)))
    xs = i(params, "length_segments", i(params, "segments", 1), 1, 1000)
    ys = i(params, "width_segments", i(params, "segments", 1), 1, 1000)
    zs = i(params, "height_segments", i(params, "segments", 1), 1, 1000)
    bx = Builder()
    x0, y0, z0 = -lx / 2, -wy / 2, -hz / 2
    # top / bottom
    add_grid(bx, (x0, y0, hz / 2), (lx, 0, 0), (0, wy, 0), xs, ys, False)
    add_grid(bx, (x0, y0, -hz / 2), (lx, 0, 0), (0, wy, 0), xs, ys, True)
    # front / back
    add_grid(bx, (x0, -wy / 2, z0), (lx, 0, 0), (0, 0, hz), xs, zs, True)
    add_grid(bx, (x0, wy / 2, z0), (lx, 0, 0), (0, 0, hz), xs, zs, False)
    # left / right
    add_grid(bx, (-lx / 2, y0, z0), (0, wy, 0), (0, 0, hz), ys, zs, False)
    add_grid(bx, (lx / 2, y0, z0), (0, wy, 0), (0, 0, hz), ys, zs, True)
    return bx.build(False)


def make_plane(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, abs(f(params, "length", f(params, "size", 25.0))))
    width_ = max(EPS, abs(f(params, "width", length_)))
    xs = i(params, "length_segments", i(params, "segments", 1), 1, 2000)
    ys = i(params, "width_segments", i(params, "segments", 1), 1, 2000)
    bx = Builder()
    add_grid(bx, (-length_ / 2, -width_ / 2, 0.0), (length_, 0, 0), (0, width_, 0), xs, ys, False)
    return bx.build(False)


def make_frustum(params: Dict[str, object], radius1_key: str = "radius1", radius2_key: str = "radius2") -> MeshData:
    r1 = max(0.0, f(params, radius1_key, f(params, "radius", 15.0)))
    r2 = max(0.0, f(params, radius2_key, r1))
    h = f(params, "height", 25.0)
    hs = i(params, "height_segments", 1, 1, 1000)
    cap_segments = i(params, "cap_segments", 1, 0, 1000)
    sides = i(params, "sides", 24, 3, 3600)
    angles, wrap = angle_range(params, sides)
    bx = Builder()
    rings: List[List[int]] = []
    for zidx in range(hs + 1):
        t = zidx / hs
        z = -h / 2 + h * t
        r = r1 + (r2 - r1) * t
        ring = []
        for a in angles:
            ring.append(bx.add_vertex((math.cos(a) * r, math.sin(a) * r, z)))
        rings.append(ring)
    n = len(angles)
    end = n if wrap else n - 1
    for zidx in range(hs):
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((rings[zidx][k], rings[zidx][k2], rings[zidx + 1][k2], rings[zidx + 1][k]))
    # caps with concentric rings
    for zsign, z, r, source_ring, flip in [(-1, -h / 2, r1, rings[0], True), (1, h / 2, r2, rings[-1], False)]:
        if r > EPS and cap_segments > 0:
            previous = source_ring
            for c in range(1, cap_segments + 1):
                rr = r * (cap_segments - c) / cap_segments
                if rr <= EPS:
                    center = bx.add_vertex((0.0, 0.0, z))
                    for k in range(end):
                        k2 = (k + 1) % n
                        face = (previous[k], previous[k2], center)
                        bx.add_face(tuple(reversed(face)) if flip else face)
                    break
                ring = [bx.add_vertex((math.cos(a) * rr, math.sin(a) * rr, z)) for a in angles]
                for k in range(end):
                    k2 = (k + 1) % n
                    face = (previous[k], previous[k2], ring[k2], ring[k])
                    bx.add_face(tuple(reversed(face)) if flip else face)
                previous = ring
        if not wrap:
            # close slice sides
            for edge_index in [0, n - 1]:
                if r1 > EPS or r2 > EPS:
                    # only side at cap-ish open edge, uses main rings
                    pass
    return bx.build(b(params, "smooth", True))


def make_cylinder(params: Dict[str, object]) -> MeshData:
    local = dict(params)
    local["radius1"] = f(params, "radius", 15.0)
    local["radius2"] = f(params, "radius", 15.0)
    return make_frustum(local)


def make_cone(params: Dict[str, object]) -> MeshData:
    return make_frustum(params, "radius1", "radius2")


def make_tube(params: Dict[str, object]) -> MeshData:
    r1 = max(0.0, f(params, "radius1", 25.0))
    r2 = max(0.0, f(params, "radius2", 20.0))
    outer, inner = max(r1, r2), min(r1, r2)
    inner = min(inner, max(EPS, outer - EPS))
    h = f(params, "height", 50.0)
    hs = i(params, "height_segments", 1, 1, 1000)
    sides = i(params, "sides", 24, 3, 3600)
    cap_segments = i(params, "cap_segments", 1, 0, 1000)
    angles, wrap = angle_range(params, sides)
    n = len(angles)
    end = n if wrap else n - 1
    bx = Builder()
    outer_rings = []
    inner_rings = []
    for zidx in range(hs + 1):
        z = -h / 2 + h * zidx / hs
        outer_ring = []
        inner_ring = []
        for a in angles:
            outer_ring.append(bx.add_vertex((math.cos(a) * outer, math.sin(a) * outer, z)))
            inner_ring.append(bx.add_vertex((math.cos(a) * inner, math.sin(a) * inner, z)))
        outer_rings.append(outer_ring)
        inner_rings.append(inner_ring)
    for zidx in range(hs):
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((outer_rings[zidx][k], outer_rings[zidx][k2], outer_rings[zidx + 1][k2], outer_rings[zidx + 1][k]))
            bx.add_face((inner_rings[zidx][k2], inner_rings[zidx][k], inner_rings[zidx + 1][k], inner_rings[zidx + 1][k2]))
    # caps as annular bands
    rings_per_cap = max(1, cap_segments)
    for zi, flip in [(0, True), (-1, False)]:
        for k in range(end):
            k2 = (k + 1) % n
            face = (outer_rings[zi][k], outer_rings[zi][k2], inner_rings[zi][k2], inner_rings[zi][k])
            bx.add_face(tuple(reversed(face)) if flip else face)
    return bx.build(b(params, "smooth", True))


def make_torus(params: Dict[str, object]) -> MeshData:
    R = max(EPS, f(params, "radius1", 50.0))
    r = max(EPS, f(params, "radius2", 12.5))
    seg = i(params, "segments", 48, 3, 3600)
    sides = i(params, "sides", 12, 3, 1000)
    angles, wrap = angle_range(params, seg)
    bx = Builder()
    grid = []
    for a in angles:
        row = []
        ca, sa = math.cos(a), math.sin(a)
        for j in range(sides):
            bangle = TAU * j / sides
            cb, sb = math.cos(bangle), math.sin(bangle)
            row.append(bx.add_vertex(((R + r * cb) * ca, (R + r * cb) * sa, r * sb)))
        grid.append(row)
    n = len(angles)
    end = n if wrap else n - 1
    for k in range(end):
        k2 = (k + 1) % n
        for j in range(sides):
            j2 = (j + 1) % sides
            bx.add_face((grid[k][j], grid[k2][j], grid[k2][j2], grid[k][j2]))
    return bx.build(b(params, "smooth", True))


def make_sphere(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 25.0))
    seg = i(params, "segments", 32, 4, 3600)
    rings_count = i(params, "rings", max(2, seg // 2), 2, 1000)
    hemisphere = clamp(f(params, "hemisphere", 0.0), 0.0, 1.0)
    phi_min = 0.0
    phi_max = math.pi * (1.0 - hemisphere * 0.5)
    if phi_max <= 0.05:
        phi_max = 0.05
    angles, wrap = angle_range(params, seg)
    n = len(angles)
    end = n if wrap else n - 1
    bx = Builder()
    top = bx.add_vertex((0.0, 0.0, radius))
    rings = []
    for r_index in range(1, rings_count + 1):
        phi = phi_min + (phi_max - phi_min) * r_index / (rings_count + 1)
        z = radius * math.cos(phi)
        rr = radius * math.sin(phi)
        ring = []
        for a in angles:
            ring.append(bx.add_vertex((math.cos(a) * rr, math.sin(a) * rr, z)))
        rings.append(ring)
    bottom_z = radius * math.cos(phi_max)
    bottom_rr = radius * math.sin(phi_max)
    if hemisphere <= EPS:
        bottom = bx.add_vertex((0.0, 0.0, -radius))
    else:
        bottom = None
        bottom_ring = [bx.add_vertex((math.cos(a) * bottom_rr, math.sin(a) * bottom_rr, bottom_z)) for a in angles]
        rings.append(bottom_ring)
    # top fan
    first = rings[0]
    for k in range(end):
        k2 = (k + 1) % n
        bx.add_face((top, first[k], first[k2]))
    # middle quads
    for ridx in range(len(rings) - 1):
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((rings[ridx][k], rings[ridx + 1][k], rings[ridx + 1][k2], rings[ridx][k2]))
    if bottom is not None:
        last = rings[-1]
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((last[k2], last[k], bottom))
    else:
        # cap truncated hemisphere
        center = bx.add_vertex((0.0, 0.0, bottom_z))
        last = rings[-1]
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((last[k2], last[k], center))
    return bx.build(b(params, "smooth", True))


def _base_polyhedron(base_type: int) -> Tuple[List[Vec3], List[Face]]:
    if base_type == 0:  # tetra
        verts = [(1, 1, 1), (-1, -1, 1), (-1, 1, -1), (1, -1, -1)]
        faces = [(0, 1, 2), (0, 3, 1), (0, 2, 3), (1, 3, 2)]
    elif base_type == 1:  # octa
        verts = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
        faces = [(0, 2, 4), (2, 1, 4), (1, 3, 4), (3, 0, 4), (2, 0, 5), (1, 2, 5), (3, 1, 5), (0, 3, 5)]
    else:  # icosa
        t = (1.0 + math.sqrt(5.0)) / 2.0
        verts = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t), (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
        faces = [(0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11), (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8), (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9), (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1)]
    verts = [normalize(v) for v in verts]
    return verts, faces


def make_geosphere(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 25.0))
    level = i(params, "segments", 2, 0, 8)
    base_type = i(params, "base_type", 2, 0, 2)
    verts, faces = _base_polyhedron(base_type)
    for _ in range(level):
        midpoint_cache: Dict[Tuple[int, int], int] = {}
        new_faces: List[Face] = []
        def mid(aidx: int, bidx: int) -> int:
            key = tuple(sorted((aidx, bidx)))
            if key in midpoint_cache:
                return midpoint_cache[key]
            pnt = normalize(mul(add(verts[aidx], verts[bidx]), 0.5))
            verts.append(pnt)
            idx = len(verts) - 1
            midpoint_cache[key] = idx
            return idx
        for tri in faces:
            a, c, d = tri
            ab = mid(a, c)
            bc = mid(c, d)
            ca = mid(d, a)
            new_faces.extend([(a, ab, ca), (c, bc, ab), (d, ca, bc), (ab, bc, ca)])
        faces = new_faces
    verts = [mul(normalize(v), radius) for v in verts]
    return mesh(verts, faces, b(params, "smooth", True))


def make_pyramid(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 25.0))
    d = max(EPS, f(params, "depth", 25.0))
    h = f(params, "height", 25.0)
    verts = [(-w / 2, -d / 2, -h / 2), (w / 2, -d / 2, -h / 2), (w / 2, d / 2, -h / 2), (-w / 2, d / 2, -h / 2), (0, 0, h / 2)]
    faces = [(0, 3, 2, 1), (0, 1, 4), (1, 2, 4), (2, 3, 4), (3, 0, 4)]
    return mesh(verts, faces, False)


def _path_tangent(points: Sequence[Vec3], idx: int, fallback: Vec3 = (1.0, 0.0, 0.0)) -> Vec3:
    if not points:
        return fallback
    if len(points) == 1:
        return fallback
    if idx <= 0:
        return normalize(sub(points[1], points[0]), fallback)
    if idx >= len(points) - 1:
        return normalize(sub(points[-1], points[-2]), fallback)
    return normalize(sub(points[idx + 1], points[idx - 1]), fallback)


def _initial_sweep_normal(tangent: Vec3) -> Vec3:
    up = (0.0, 0.0, 1.0) if abs(dot(tangent, (0.0, 0.0, 1.0))) < 0.92 else (0.0, 1.0, 0.0)
    return normalize(cross(up, tangent), (1.0, 0.0, 0.0))


def _transport_sweep_frame(tangent: Vec3, previous_normal: Vec3 | None) -> Tuple[Vec3, Vec3, Vec3]:
    """Stable parallel-transport frame for tube/loft sections.

    The previous implementation derived each ring from cross(tangent,
    previous_binormal), which can flip 180 degrees on straight paths and create
    bow-tie zero-area faces.  Keeping the previous normal projected onto the new
    tangent plane preserves ring order and connected edge topology.
    """
    tangent = normalize(tangent, (1.0, 0.0, 0.0))
    if previous_normal is None:
        nvec = _initial_sweep_normal(tangent)
    else:
        projected = sub(previous_normal, mul(tangent, dot(previous_normal, tangent)))
        if length(projected) < EPS:
            nvec = _initial_sweep_normal(tangent)
        else:
            nvec = normalize(projected, _initial_sweep_normal(tangent))
    bvec = normalize(cross(tangent, nvec), (0.0, 0.0, 1.0))
    return nvec, bvec, nvec


def sweep_circle(points: Sequence[Vec3], radius: float, sides: int, twist: float = 0.0) -> MeshData:
    sides = max(3, int(sides))
    bx = Builder()
    rings = []
    prev_n: Vec3 | None = None
    for idx, pnt in enumerate(points):
        tangent = _path_tangent(points, idx, (1.0, 0.0, 0.0))
        nvec, bvec, prev_n = _transport_sweep_frame(tangent, prev_n)
        row = []
        for j in range(sides):
            angle = TAU * j / sides + twist * idx / max(1, len(points) - 1)
            off = add(mul(nvec, math.cos(angle) * radius), mul(bvec, math.sin(angle) * radius))
            row.append(bx.add_vertex(add(pnt, off)))
        rings.append(row)
    for idx in range(len(rings) - 1):
        for j in range(sides):
            j2 = (j + 1) % sides
            bx.add_face((rings[idx][j], rings[idx + 1][j], rings[idx + 1][j2], rings[idx][j2]))
    return bx.build(True)


def add_frustum_between(builder: Builder, start: Vec3, end: Vec3, r1: float, r2: float, sides: int = 12, caps: bool = True) -> None:
    sides = max(3, int(sides))
    axis = normalize(sub(end, start), (0, 0, 1))
    up = (0, 0, 1) if abs(dot(axis, (0, 0, 1))) < 0.9 else (0, 1, 0)
    nvec = normalize(cross(axis, up), (1, 0, 0))
    bvec = normalize(cross(axis, nvec), (0, 1, 0))
    ring1 = []
    ring2 = []
    for k in range(sides):
        a = TAU * k / sides
        off1 = add(mul(nvec, math.cos(a) * r1), mul(bvec, math.sin(a) * r1))
        off2 = add(mul(nvec, math.cos(a) * r2), mul(bvec, math.sin(a) * r2))
        ring1.append(builder.add_vertex(add(start, off1)))
        ring2.append(builder.add_vertex(add(end, off2)))
    for k in range(sides):
        k2 = (k + 1) % sides
        builder.add_face((ring1[k], ring1[k2], ring2[k2], ring2[k]))
    if caps:
        c1 = builder.add_vertex(start)
        c2 = builder.add_vertex(end)
        for k in range(sides):
            k2 = (k + 1) % sides
            builder.add_face((ring1[k2], ring1[k], c1))
            builder.add_face((ring2[k], ring2[k2], c2))


def make_teapot(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 25.0))
    seg = i(params, "segments", 16, 4, 256)
    bx = Builder()
    if b(params, "body", True):
        body = make_sphere({"radius": r, "segments": seg * 2, "rings": seg, "smooth": True})
        bx.add_mesh(body["verts"], body["faces"], scale=(1.15, 1.0, 0.78), offset=(0, 0, 0))
    if b(params, "lid", True):
        lid = make_cylinder({"radius": r * 0.38, "height": r * 0.18, "sides": seg * 2, "cap_segments": 1, "height_segments": 1, "smooth": True})
        bx.add_mesh(lid["verts"], lid["faces"], offset=(0, 0, r * 0.62))
        knob = make_sphere({"radius": r * 0.12, "segments": seg, "rings": max(4, seg // 2), "smooth": True})
        bx.add_mesh(knob["verts"], knob["faces"], offset=(0, 0, r * 0.82))
    if b(params, "handle", True):
        pts = []
        for k in range(32):
            a = -math.pi * 0.78 + math.pi * 1.56 * k / 31
            pts.append((0.0, -r * 0.95 + math.cos(a) * r * 0.45, math.sin(a) * r * 0.55 + r * 0.08))
        hmesh = sweep_circle(pts, r * 0.08, max(6, seg // 2))
        bx.add_mesh(hmesh["verts"], hmesh["faces"], rot=(0, 0, 0), offset=(0, 0, 0))
    if b(params, "spout", True):
        add_frustum_between(bx, (r * 0.82, 0, r * 0.15), (r * 1.55, 0, r * 0.35), r * 0.14, r * 0.08, max(8, seg), True)
    return bx.build(True)


def make_revolved_profile(profile: Sequence[Tuple[float, float]], sides: int, smooth: bool = True) -> MeshData:
    sides = max(3, int(sides))
    bx = Builder()
    rings = []
    for z, rad in profile:
        rad = max(0.0, rad)
        if rad <= EPS:
            rings.append([bx.add_vertex((0, 0, z)) for _ in range(sides)])
        else:
            rings.append([bx.add_vertex((math.cos(TAU * k / sides) * rad, math.sin(TAU * k / sides) * rad, z)) for k in range(sides)])
    for aidx in range(len(rings) - 1):
        for k in range(sides):
            k2 = (k + 1) % sides
            bx.add_face((rings[aidx][k], rings[aidx][k2], rings[aidx + 1][k2], rings[aidx + 1][k]))
    return bx.build(smooth)


def make_chamfer_cyl(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, abs(f(params, "height", 25.0)))
    fillet = clamp(f(params, "fillet", 2.0), 0.0, min(r * 0.9, h * 0.49))
    fs = i(params, "fillet_segments", 2, 1, 128)
    sides = i(params, "sides", 24, 3, 3600)
    if fillet <= EPS:
        return make_cylinder(params)
    profile = [(-h / 2, 0.0), (-h / 2, r - fillet)]
    for s in range(fs + 1):
        t = s / fs
        angle = -math.pi / 2 + t * math.pi / 2
        z = -h / 2 + fillet + math.sin(angle) * fillet
        rad = r - fillet + math.cos(angle) * fillet
        profile.append((z, rad))
    profile.append((h / 2 - fillet, r))
    for s in range(fs + 1):
        t = s / fs
        angle = 0 + t * math.pi / 2
        z = h / 2 - fillet + math.sin(angle) * fillet
        rad = r - fillet + math.cos(angle) * fillet
        profile.append((z, rad))
    profile.append((h / 2, 0.0))
    return make_revolved_profile(profile, sides, b(params, "smooth", True))


def make_oiltank(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, f(params, "height", 50.0))
    cap_h = clamp(f(params, "cap_height", 8.0), 0.0, h / 2)
    sides = i(params, "sides", 24, 3, 3600)
    cap_seg = i(params, "cap_segments", 4, 1, 256)
    cyl_h = max(EPS, h - 2 * cap_h)
    profile: List[Tuple[float, float]] = []
    for s in range(cap_seg + 1):
        t = s / cap_seg
        # bottom dome from point to radius
        z = -h / 2 + cap_h * t
        rad = r * math.sin(t * math.pi / 2)
        profile.append((z, rad))
    profile.append((h / 2 - cap_h, r))
    for s in range(cap_seg, -1, -1):
        t = s / cap_seg
        z = h / 2 - cap_h + cap_h * (1 - t)
        rad = r * math.sin(t * math.pi / 2)
        profile.append((z, rad))
    return make_revolved_profile(profile, sides, b(params, "smooth", True))


def make_capsule(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, f(params, "height", 25.0))
    height_type = i(params, "height_type", 1, 0, 1)
    if height_type == 0:
        cyl_h = max(0.0, h - 2 * r)
    else:
        cyl_h = h
    sides = i(params, "sides", 24, 3, 3600)
    cap_seg = i(params, "cap_segments", 8, 1, 256)
    profile: List[Tuple[float, float]] = []
    bottom_center = -cyl_h / 2
    top_center = cyl_h / 2
    for s in range(cap_seg + 1):
        t = s / cap_seg
        angle = -math.pi / 2 + t * math.pi / 2
        profile.append((bottom_center + math.sin(angle) * r, math.cos(angle) * r))
    profile.append((top_center, r))
    for s in range(cap_seg + 1):
        t = s / cap_seg
        angle = 0 + t * math.pi / 2
        profile.append((top_center + math.sin(angle) * r, math.cos(angle) * r))
    return make_revolved_profile(profile, sides, b(params, "smooth", True))


def make_spindle(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, f(params, "height", 50.0))
    cap_h = clamp(f(params, "cap_height", 10.0), 0.0, h / 2)
    sides = i(params, "sides", 24, 3, 3600)
    profile = [(-h / 2, 0.0), (-h / 2 + cap_h, r), (h / 2 - cap_h, r), (h / 2, 0.0)]
    return make_revolved_profile(profile, sides, b(params, "smooth", True))


def polygon_area(poly: Sequence[Tuple[float, float]]) -> float:
    area = 0.0
    for idx, pnt in enumerate(poly):
        q = poly[(idx + 1) % len(poly)]
        area += pnt[0] * q[1] - q[0] * pnt[1]
    return area * 0.5


def _point_in_tri(pnt, a, c, d) -> bool:
    def sign(p1, p2, p3):
        return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])
    b1 = sign(pnt, a, c) < 0.0
    b2 = sign(pnt, c, d) < 0.0
    b3 = sign(pnt, d, a) < 0.0
    return (b1 == b2) and (b2 == b3)


def triangulate_polygon(poly: Sequence[Tuple[float, float]]) -> List[Tuple[int, int, int]]:
    n = len(poly)
    if n < 3:
        return []
    idxs = list(range(n))
    if polygon_area(poly) < 0:
        idxs.reverse()
    tris = []
    guard = 0
    while len(idxs) > 3 and guard < 10000:
        guard += 1
        ear_found = False
        m = len(idxs)
        for j in range(m):
            ia, ib, ic = idxs[(j - 1) % m], idxs[j], idxs[(j + 1) % m]
            a, c, d = poly[ia], poly[ib], poly[ic]
            cross2 = (c[0] - a[0]) * (d[1] - a[1]) - (c[1] - a[1]) * (d[0] - a[0])
            if cross2 <= EPS:
                continue
            if any(_point_in_tri(poly[k], a, c, d) for k in idxs if k not in (ia, ib, ic)):
                continue
            tris.append((ia, ib, ic))
            del idxs[j]
            ear_found = True
            break
        if not ear_found:
            break
    if len(idxs) == 3:
        tris.append(tuple(idxs))
    return tris


def extrude_polygon(poly: Sequence[Tuple[float, float]], height: float) -> MeshData:
    bx = Builder()
    bottom = [bx.add_vertex((x, y, -height / 2)) for x, y in poly]
    top = [bx.add_vertex((x, y, height / 2)) for x, y in poly]
    n = len(poly)
    for k in range(n):
        k2 = (k + 1) % n
        bx.add_face((bottom[k], bottom[k2], top[k2], top[k]))
    for tri in triangulate_polygon(poly):
        bx.add_face(tuple(bottom[idx] for idx in reversed(tri)))
        bx.add_face(tuple(top[idx] for idx in tri))
    return bx.build(False)


def make_l_ext(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 60.0))
    width_ = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 25.0))
    t = clamp(f(params, "thickness", 8.0), EPS, min(length_, width_) * 0.95)
    poly = [(-length_ / 2, -width_ / 2), (length_ / 2, -width_ / 2), (length_ / 2, -width_ / 2 + t), (-length_ / 2 + t, -width_ / 2 + t), (-length_ / 2 + t, width_ / 2), (-length_ / 2, width_ / 2)]
    return extrude_polygon(poly, h)


def make_c_ext(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 60.0))
    width_ = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 25.0))
    t = clamp(f(params, "thickness", 8.0), EPS, min(length_, width_) * 0.45)
    gap = clamp(f(params, "opening", 20.0), 0.0, width_ - t * 2)
    ygap0 = -gap / 2
    ygap1 = gap / 2
    poly = [(-length_/2,-width_/2),(length_/2,-width_/2),(length_/2,width_/2),(-length_/2,width_/2),(-length_/2,width_/2-t),(length_/2-t,width_/2-t),(length_/2-t,ygap1),(-length_/2+t,ygap1),(-length_/2+t,ygap0),(length_/2-t,ygap0),(length_/2-t,-width_/2+t),(-length_/2,-width_/2+t)]
    return extrude_polygon(poly, h)


def make_gengon(params: Dict[str, object]) -> MeshData:
    local = dict(params)
    local["radius"] = f(params, "radius", 15.0)
    return make_cylinder(local)


def make_prism(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 30.0))
    d = max(EPS, f(params, "depth", 30.0))
    h = max(EPS, f(params, "height", 25.0))
    poly = [(-w / 2, -d / 2), (w / 2, -d / 2), (0, d / 2)]
    return extrude_polygon(poly, h)


def make_ringwave(params: Dict[str, object]) -> MeshData:
    outer = max(EPS, f(params, "outer_radius", 50.0))
    inner = clamp(f(params, "inner_radius", 35.0), 0.0, outer - EPS)
    h = f(params, "height", 2.0)
    seg = i(params, "segments", 128, 8, 3600)
    waves = i(params, "waves", 8, 1, 512)
    amp = f(params, "amplitude", 5.0)
    phase = math.radians(f(params, "phase", 0.0))
    bx = Builder()
    top_o = []
    top_i = []
    bot_o = []
    bot_i = []
    for k in range(seg):
        a = TAU * k / seg
        wave = math.sin(a * waves + phase) * amp
        ro = max(EPS, outer + wave)
        ri = max(0.0, inner + wave * 0.35)
        top_o.append(bx.add_vertex((math.cos(a) * ro, math.sin(a) * ro, h / 2)))
        top_i.append(bx.add_vertex((math.cos(a) * ri, math.sin(a) * ri, h / 2)))
        bot_o.append(bx.add_vertex((math.cos(a) * ro, math.sin(a) * ro, -h / 2)))
        bot_i.append(bx.add_vertex((math.cos(a) * ri, math.sin(a) * ri, -h / 2)))
    for k in range(seg):
        k2 = (k + 1) % seg
        bx.add_face((top_o[k], top_o[k2], top_i[k2], top_i[k]))
        bx.add_face((bot_o[k2], bot_o[k], bot_i[k], bot_i[k2]))
        bx.add_face((top_o[k2], top_o[k], bot_o[k], bot_o[k2]))
        bx.add_face((top_i[k], top_i[k2], bot_i[k2], bot_i[k]))
    return bx.build(b(params, "smooth", True))


def make_hose(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 10.0))
    length_ = max(EPS, f(params, "length", 80.0))
    segments = i(params, "segments", 96, 4, 3600)
    sides = i(params, "sides", 16, 3, 256)
    cycles = i(params, "cycles", 16, 1, 1000)
    amp = max(0.0, f(params, "amplitude", 2.0))
    bend = math.radians(f(params, "bend", 0.0))
    bx = Builder()
    rings = []
    for sidx in range(segments + 1):
        t = sidx / segments
        z = -length_ / 2 + length_ * t
        center = (0.0, 0.0, z)
        if abs(bend) > EPS:
            arc_r = length_ / max(EPS, abs(bend))
            aa = -bend / 2 + bend * t
            center = (math.sin(aa) * arc_r, 0.0, math.cos(aa) * arc_r - math.cos(bend / 2) * arc_r)
        rr = max(EPS, radius + amp * math.sin(TAU * cycles * t))
        ring = []
        for k in range(sides):
            a = TAU * k / sides
            ring.append(bx.add_vertex((center[0] + math.cos(a) * rr, center[1] + math.sin(a) * rr, center[2])))
        rings.append(ring)
    for sidx in range(segments):
        for k in range(sides):
            k2 = (k + 1) % sides
            bx.add_face((rings[sidx][k], rings[sidx][k2], rings[sidx + 1][k2], rings[sidx + 1][k]))
    return bx.build(b(params, "smooth", True))


def make_torusknot(params: Dict[str, object]) -> MeshData:
    R = max(EPS, f(params, "radius", 50.0))
    tube = max(EPS, f(params, "tube_radius", 5.0))
    p_val = i(params, "p", 2, 1, 64)
    q_val = i(params, "q", 3, 1, 64)
    seg = i(params, "segments", 160, 8, 3600)
    sides = i(params, "sides", 12, 3, 256)
    ecc = f(params, "eccentricity", 1.0)
    twist = math.radians(f(params, "twist", 0.0))
    points = []
    minor = R * 0.33 * ecc
    for k in range(seg + 1):
        t = TAU * k / seg
        x = (R + minor * math.cos(q_val * t)) * math.cos(p_val * t)
        y = (R + minor * math.cos(q_val * t)) * math.sin(p_val * t)
        z = minor * math.sin(q_val * t)
        points.append((x, y, z))
    result = sweep_circle(points, tube, sides, twist)
    result["smooth"] = b(params, "smooth", True)
    return result


def make_chamfer_box(params: Dict[str, object]) -> MeshData:
    # Superellipsoid-like rounded box approximation. It is robust and responsive, but not a bitwise clone of 3ds Max ChamferBox.
    lx = max(EPS, f(params, "length", 25.0))
    wy = max(EPS, f(params, "width", 25.0))
    hz = max(EPS, f(params, "height", 25.0))
    fillet = clamp(f(params, "fillet", 2.0), 0.0, min(lx, wy, hz) * 0.45)
    if fillet <= EPS:
        return make_box(params)
    seg = max(8, i(params, "fillet_segments", 2, 1, 128) * 4)
    bx = Builder()
    # start from a cube sphere, then offset to box dimensions via rounded box formula
    usteps = seg * 2
    vsteps = seg
    grid = []
    sx, sy, sz = max(EPS, lx / 2 - fillet), max(EPS, wy / 2 - fillet), max(EPS, hz / 2 - fillet)
    for vi in range(vsteps + 1):
        phi = -math.pi / 2 + math.pi * vi / vsteps
        row = []
        for ui in range(usteps):
            theta = TAU * ui / usteps
            direction = (math.cos(phi) * math.cos(theta), math.cos(phi) * math.sin(theta), math.sin(phi))
            pnt = (math.copysign(sx, direction[0]) + direction[0] * fillet if abs(direction[0]) > EPS else 0.0,
                   math.copysign(sy, direction[1]) + direction[1] * fillet if abs(direction[1]) > EPS else 0.0,
                   math.copysign(sz, direction[2]) + direction[2] * fillet if abs(direction[2]) > EPS else 0.0)
            row.append(bx.add_vertex(pnt))
        grid.append(row)
    for vi in range(vsteps):
        for ui in range(usteps):
            u2 = (ui + 1) % usteps
            bx.add_face((grid[vi][ui], grid[vi][u2], grid[vi + 1][u2], grid[vi + 1][ui]))
    return bx.build(b(params, "smooth", True))


def make_hedra(params: Dict[str, object]) -> MeshData:
    family = i(params, "family", 2, 0, 5)
    radius = max(EPS, f(params, "radius", 25.0))
    if family == 1:
        data = make_box({"length": radius * 2, "width": radius * 2, "height": radius * 2})
    elif family == 3:
        data = make_geosphere({"radius": radius, "segments": 0, "base_type": 2, "smooth": False})
    elif family == 5:
        data = make_geosphere({"radius": radius, "segments": 0, "base_type": 1, "smooth": False})
        # Push every face center into a spike.
        bx = Builder()
        verts = list(data["verts"])
        faces = data["faces"]
        for face in faces:
            center = (0.0, 0.0, 0.0)
            for idx in face:
                center = add(center, verts[idx])
            center = mul(center, 1.0 / len(face))
            spike = mul(normalize(center), radius * 1.55)
            spike_idx = bx.add_vertex(spike)
            local = [bx.add_vertex(verts[idx]) for idx in face]
            for k in range(len(local)):
                bx.add_face((local[k], local[(k + 1) % len(local)], spike_idx))
        return bx.build(False)
    else:
        base = 0 if family == 0 else (1 if family == 2 else 2)
        data = make_geosphere({"radius": radius, "segments": 0, "base_type": base, "smooth": False})
    scale = (max(EPS, f(params, "scale_p", 1.0)), max(EPS, f(params, "scale_q", 1.0)), max(EPS, f(params, "scale_r", 1.0)))
    verts = [(v[0] * scale[0], v[1] * scale[1], v[2] * scale[2]) for v in data["verts"]]
    return mesh(verts, data["faces"], False)


def add_box(builder: Builder, length_: float, width_: float, height_: float, offset=(0, 0, 0), rot=(0, 0, 0)) -> None:
    data = make_box({"length": length_, "width": width_, "height": height_})
    builder.add_mesh(data["verts"], data["faces"], offset=offset, rot=rot)


def make_foliage(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    plant_type = i(params, "plant_type", 0, 0, 4)
    h = max(EPS, f(params, "height", 80.0))
    trunk_r = max(EPS, f(params, "trunk_radius", 4.0))
    leaf_size = max(EPS, f(params, "leaf_size", 8.0))
    branches = i(params, "branches", 12, 0, 512)
    density = max(0.0, f(params, "density", 1.0))
    bx = Builder()
    add_frustum_between(bx, (0, 0, 0), (0, 0, h * 0.62), trunk_r, trunk_r * 0.45, 10, True)
    if plant_type == 3:  # grass clump
        for n in range(max(8, int(32 * density))):
            angle = rng.random() * TAU
            bend = rng.uniform(0.2, 1.0) * h * 0.35
            add_frustum_between(bx, (0, 0, 0), (math.cos(angle) * bend, math.sin(angle) * bend, h * rng.uniform(0.25, 0.6)), trunk_r * 0.2, 0.0, 4, False)
        return bx.build(True)
    for n in range(branches):
        z = h * rng.uniform(0.25, 0.72)
        angle = rng.random() * TAU
        length_b = h * rng.uniform(0.15, 0.35)
        end = (math.cos(angle) * length_b, math.sin(angle) * length_b, z + h * rng.uniform(0.05, 0.25))
        add_frustum_between(bx, (0, 0, z), end, trunk_r * 0.25, trunk_r * 0.08, 6, True)
    leaf_count = max(1, int((16 if plant_type != 1 else 24) * max(0.1, density)))
    for n in range(leaf_count):
        angle = rng.random() * TAU
        rr = h * rng.uniform(0.05, 0.33)
        z = h * rng.uniform(0.45, 0.95)
        if plant_type == 1:
            rr *= (1.0 - z / h) * 1.8
        center = (math.cos(angle) * rr, math.sin(angle) * rr, z)
        leaf = make_sphere({"radius": leaf_size * rng.uniform(0.6, 1.4), "segments": 8, "rings": 4, "smooth": True})
        bx.add_mesh(leaf["verts"], leaf["faces"], offset=center, scale=(1.5, 1.5, 0.7))
    return bx.build(True)


def make_railing(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 120.0))
    h = max(EPS, f(params, "height", 40.0))
    post_spacing = max(EPS, f(params, "post_spacing", 30.0))
    post_r = max(EPS, f(params, "post_radius", 2.0))
    rail_r = max(EPS, f(params, "rail_radius", 1.5))
    rails = i(params, "rails", 2, 1, 32)
    bal_spacing = f(params, "baluster_spacing", 12.0)
    bx = Builder()
    posts = max(2, int(math.ceil(length_ / post_spacing)) + 1)
    for pidx in range(posts):
        x = -length_ / 2 + length_ * pidx / (posts - 1)
        add_frustum_between(bx, (x, 0, 0), (x, 0, h), post_r, post_r, 10, True)
    for ridx in range(rails):
        z = h * (ridx + 1) / (rails + 1)
        add_frustum_between(bx, (-length_ / 2, 0, z), (length_ / 2, 0, z), rail_r, rail_r, 10, True)
    add_frustum_between(bx, (-length_ / 2, 0, h), (length_ / 2, 0, h), rail_r * 1.4, rail_r * 1.4, 12, True)
    if bal_spacing > EPS:
        count = max(0, int(length_ / bal_spacing) - 1)
        for idx in range(count):
            x = -length_ / 2 + bal_spacing * (idx + 1)
            add_frustum_between(bx, (x, 0, 0), (x, 0, h * 0.85), rail_r * 0.7, rail_r * 0.7, 8, True)
    return bx.build(True)


def make_wall(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 120.0))
    width_ = max(EPS, f(params, "width", 12.0))
    height_ = max(EPS, f(params, "height", 60.0))
    bottom = f(params, "bottom_offset", 0.0)
    top = f(params, "top_offset", 0.0)
    data = make_box({"length": length_, "width": width_, "height": height_ + top - bottom, "length_segments": i(params, "segments", 1, 1, 1000), "width_segments": 1, "height_segments": 1})
    verts = [(x, y, z + height_ / 2 + bottom) for x, y, z in data["verts"]]
    return mesh(verts, data["faces"], False)


def make_door(params: Dict[str, object], kind: str) -> MeshData:
    w = max(EPS, f(params, "width", 36.0))
    h = max(EPS, f(params, "height", 80.0))
    d = max(EPS, f(params, "depth", 4.0))
    fw = max(0.0, f(params, "frame_width", 4.0))
    pt = max(EPS, f(params, "panel_thickness", 2.0))
    open_pct = clamp(f(params, "open", 0.0), 0.0, 100.0) / 100.0
    flip = -1.0 if b(params, "flip_swing", False) else 1.0
    bx = Builder()
    # frame: two jambs and header
    add_box(bx, fw, d, h + fw, (-w / 2 - fw / 2, 0, h / 2))
    add_box(bx, fw, d, h + fw, (w / 2 + fw / 2, 0, h / 2))
    add_box(bx, w + fw * 2, d, fw, (0, 0, h + fw / 2))
    if kind == "pivot":
        double = b(params, "double_door", False)
        if double:
            angle = math.radians(90.0 * open_pct) * flip
            for side in [-1, 1]:
                panel_w = w / 2
                hinge_x = side * w / 2
                center_x = hinge_x - side * panel_w / 2
                add_box(bx, panel_w, pt, h, (center_x, -d * 0.25, h / 2), rot=(0, 0, -side * angle))
        else:
            angle = math.radians(100.0 * open_pct) * flip
            hinge_x = -w / 2
            center = (hinge_x + w / 2 * math.cos(angle), -d * 0.25 + w / 2 * math.sin(angle), h / 2)
            add_box(bx, w, pt, h, center, rot=(0, 0, angle))
    elif kind == "sliding":
        panels = i(params, "panels", 2, 1, 8)
        panel_w = w / panels
        for idx in range(panels):
            x = -w / 2 + panel_w * (idx + 0.5) + flip * open_pct * panel_w * (1 if idx % 2 == 0 else -1)
            y = -d * 0.3 + idx * pt * 0.3
            add_box(bx, panel_w, pt, h, (x, y, h / 2))
    else:  # bifold
        folds = i(params, "folds", 2, 2, 8)
        leaf_w = w / folds
        angle = math.radians(90.0 * open_pct) * flip
        for idx in range(folds):
            x = -w / 2 + leaf_w * (idx + 0.5)
            rot = angle * (1 if idx % 2 == 0 else -1)
            add_box(bx, leaf_w, pt, h, (x, -d * 0.25 + abs(math.sin(rot)) * leaf_w * 0.25, h / 2), rot=(0, 0, rot))
    return bx.build(False)


def make_window(params: Dict[str, object], kind: str) -> MeshData:
    w = max(EPS, f(params, "width", 48.0))
    h = max(EPS, f(params, "height", 36.0))
    d = max(EPS, f(params, "depth", 4.0))
    fw = max(0.0, f(params, "frame_width", 3.0))
    glass = max(0.0, f(params, "glass_thickness", 0.5))
    open_pct = clamp(f(params, "open", 0.0), 0.0, 100.0) / 100.0
    angle = math.radians(f(params, "open_angle", 0.0) or open_pct * 45.0)
    bx = Builder()
    # frame
    add_box(bx, w + fw * 2, d, fw, (0, 0, -fw / 2))
    add_box(bx, w + fw * 2, d, fw, (0, 0, h + fw / 2))
    add_box(bx, fw, d, h, (-w / 2 - fw / 2, 0, h / 2))
    add_box(bx, fw, d, h, (w / 2 + fw / 2, 0, h / 2))
    pane_rot = (0, 0, 0)
    pane_offset = (0, -d * 0.1, h / 2)
    if kind == "awning":
        pane_rot = (angle, 0, 0)
        pane_offset = (0, -math.sin(angle) * h * 0.25, h / 2)
    elif kind == "casement":
        pane_rot = (0, 0, angle)
    elif kind == "pivoted":
        pane_rot = (0, angle, 0)
    elif kind == "projected":
        pane_rot = (angle * 0.7, 0, 0)
        pane_offset = (0, -math.sin(angle) * h * 0.3, h / 2)
    elif kind == "sliding":
        pane_offset = (open_pct * w * 0.35, -d * 0.1, h / 2)
    add_box(bx, w, max(EPS, glass), h, pane_offset, rot=pane_rot)
    muntins = i(params, "muntins", 1, 0, 16)
    for midx in range(muntins):
        x = -w / 2 + w * (midx + 1) / (muntins + 1)
        add_box(bx, fw * 0.5, d * 0.8, h, (x, -d * 0.15, h / 2))
    return bx.build(False)


def make_straight_stair(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 60.0))
    length_ = max(EPS, f(params, "length", 100.0))
    risers = i(params, "risers", 12, 1, 1000)
    th = max(0.0, f(params, "tread_thickness", 2.0))
    bx = Builder()
    for idx in range(risers):
        step_len = length_ / risers
        step_h = h / risers
        x = -length_ / 2 + step_len * (idx + 0.5)
        z = step_h * (idx + 0.5)
        add_box(bx, step_len, w, max(EPS, step_h + th), (x, 0, z))
    return bx.build(False)


def make_l_stair(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 60.0))
    l1 = max(EPS, f(params, "length1", 70.0))
    l2 = max(EPS, f(params, "length2", 70.0))
    risers = i(params, "risers", 14, 2, 1000)
    landing = max(EPS, f(params, "landing", 40.0))
    bx = Builder()
    half = risers // 2
    step_h = h / risers
    for idx in range(half):
        step_len = l1 / max(1, half)
        add_box(bx, step_len, w, step_h, (-l1 / 2 + step_len * (idx + 0.5), 0, step_h * (idx + 0.5)))
    add_box(bx, landing, landing, step_h, (l1 / 2 + landing / 2, 0, step_h * half))
    for j in range(risers - half):
        step_len = l2 / max(1, risers - half)
        add_box(bx, w, step_len, step_h, (l1 / 2 + landing / 2, step_len * (j + 0.5), step_h * (half + j + 0.5)))
    return bx.build(False)


def make_u_stair(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 60.0))
    length_ = max(EPS, f(params, "length", 70.0))
    risers = i(params, "risers", 16, 2, 1000)
    landing = max(EPS, f(params, "landing", 40.0))
    bx = Builder()
    half = risers // 2
    step_h = h / risers
    step_len = length_ / max(1, half)
    for idx in range(half):
        add_box(bx, step_len, w, step_h, (-length_/2 + step_len*(idx+.5), -landing/2, step_h*(idx+.5)))
    add_box(bx, landing, landing + w, step_h, (length_/2 + landing/2, 0, step_h*half))
    for j in range(risers - half):
        add_box(bx, step_len, w, step_h, (length_/2 - step_len*(j+.5), landing/2, step_h*(half+j+.5)))
    return bx.build(False)


def make_spiral_stair(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 45.0))
    inner = clamp(f(params, "inner_radius", 8.0), 0.0, radius - EPS)
    h = max(EPS, f(params, "height", 80.0))
    turns = max(0.1, f(params, "turns", 1.5))
    steps = i(params, "steps", 18, 1, 2000)
    bx = Builder()
    for idx in range(steps):
        a0 = TAU * turns * idx / steps
        a1 = TAU * turns * (idx + 0.9) / steps
        z = h * idx / steps
        verts = []
        for rad, aa in [(inner, a0), (radius, a0), (radius, a1), (inner, a1)]:
            verts.append((math.cos(aa) * rad, math.sin(aa) * rad, z))
        for rad, aa in [(inner, a0), (radius, a0), (radius, a1), (inner, a1)]:
            verts.append((math.cos(aa) * rad, math.sin(aa) * rad, z + h / steps * 0.65))
        base = len(bx.verts)
        for vtx in verts:
            bx.add_vertex(vtx)
        for face in [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]:
            bx.add_face(tuple(base + q for q in face))
    if b(params, "center_pole", True):
        add_frustum_between(bx, (0,0,0), (0,0,h), max(EPS, inner*0.25), max(EPS, inner*0.25), 16, True)
    return bx.build(False)


def make_quad_patch(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 40.0))
    width_ = max(EPS, f(params, "width", 40.0))
    xs = i(params, "length_segments", i(params, "u_points", i(params, "u_cvs", 4)), 1, 512)
    ys = i(params, "width_segments", i(params, "v_points", i(params, "v_cvs", 4)), 1, 512)
    curv = f(params, "curvature", 0.0)
    bx = Builder()
    grid = []
    for yy in range(ys + 1):
        v = yy / ys
        row = []
        for xx in range(xs + 1):
            u = xx / xs
            x = -length_ / 2 + length_ * u
            y = -width_ / 2 + width_ * v
            z = curv * math.sin(math.pi * u) * math.sin(math.pi * v)
            row.append(bx.add_vertex((x, y, z)))
        grid.append(row)
    for yy in range(ys):
        for xx in range(xs):
            bx.add_face((grid[yy][xx], grid[yy][xx + 1], grid[yy + 1][xx + 1], grid[yy + 1][xx]))
    return bx.build(True)


def make_tri_patch(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 40.0))
    segs = i(params, "segments", 6, 1, 512)
    curv = f(params, "curvature", 0.0)
    bx = Builder()
    rows = []
    for row in range(segs + 1):
        t = row / segs
        count = row + 1
        y = -h / 2 + h * t
        row_ids = []
        span = w * t
        for col in range(count):
            x = 0 if count == 1 else -span / 2 + span * col / (count - 1)
            z = curv * t * (1 - t)
            row_ids.append(bx.add_vertex((x, y, z)))
        rows.append(row_ids)
    for row in range(segs):
        for col in range(len(rows[row])):
            bx.add_face((rows[row][col], rows[row + 1][col], rows[row + 1][col + 1]))
            if col < len(rows[row]) - 1:
                bx.add_face((rows[row][col], rows[row][col + 1], rows[row + 1][col + 1]))
    return bx.build(True)


def make_conform(params: Dict[str, object]) -> MeshData:
    width_ = max(EPS, f(params, "width", 80.0))
    segs = i(params, "segments", 32, 2, 512)
    radius = max(EPS, f(params, "target_radius", 50.0))
    amount = clamp(f(params, "amount", 100.0), 0.0, 100.0) / 100.0
    bx = Builder()
    grid = []
    for yidx in range(segs + 1):
        row = []
        y = -width_ / 2 + width_ * yidx / segs
        for xidx in range(segs + 1):
            x = -width_ / 2 + width_ * xidx / segs
            flat = (x, y, 0.0)
            z = math.sqrt(max(0.0, radius * radius - x * x - y * y)) - radius
            curved = (x, y, z)
            row.append(bx.add_vertex(lerp(flat, curved, amount)))
        grid.append(row)
    for yidx in range(segs):
        for xidx in range(segs):
            bx.add_face((grid[yidx][xidx], grid[yidx][xidx + 1], grid[yidx + 1][xidx + 1], grid[yidx + 1][xidx]))
    return bx.build(True)


def make_morph(params: Dict[str, object]) -> MeshData:
    amount = clamp(f(params, "amount", 0.0), 0.0, 100.0) / 100.0
    radius = max(EPS, f(params, "radius", 25.0))
    data = make_sphere({"radius": radius, "segments": i(params, "segments", 16, 4, 256), "rings": max(2, i(params, "segments", 16, 4, 256) // 2), "smooth": True})
    verts = []
    for vtx in data["verts"]:
        sphere = vtx
        box = (clamp(vtx[0] * 2, -radius, radius), clamp(vtx[1] * 2, -radius, radius), clamp(vtx[2] * 2, -radius, radius))
        verts.append(lerp(box, sphere, amount))
    return mesh(verts, data["faces"], b(params, "smooth", True))


def make_scatter(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    area = max(EPS, f(params, "area", 100.0))
    count = i(params, "count", 50, 0, 10000)
    scale = max(EPS, f(params, "scale", 3.0))
    mode = i(params, "mode", 0, 0, 2)
    bx = Builder()
    plane = make_plane({"length": area, "width": area, "length_segments": 1, "width_segments": 1})
    bx.add_mesh(plane["verts"], plane["faces"], offset=(0, 0, -0.01))
    for _ in range(count):
        x = rng.uniform(-area / 2, area / 2)
        y = rng.uniform(-area / 2, area / 2)
        z = scale / 2
        rotz = rng.random() * TAU
        if mode == 1:
            inst = make_cone({"radius1": scale, "radius2": 0.0, "height": scale * 2, "sides": 8, "height_segments": 1, "cap_segments": 1})
            bx.add_mesh(inst["verts"], inst["faces"], offset=(x, y, scale), rot=(0, 0, rotz))
        elif mode == 2:
            inst = make_sphere({"radius": scale, "segments": 8, "rings": 4, "smooth": True})
            bx.add_mesh(inst["verts"], inst["faces"], offset=(x, y, scale))
        else:
            add_box(bx, scale * 2, scale * 2, scale * 2, (x, y, z), rot=(0, 0, rotz))
    return bx.build(True)


def make_connect(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 20.0))
    length_ = max(EPS, f(params, "length", 60.0))
    sides = i(params, "sides", 24, 3, 3600)
    return make_tube({"radius1": radius, "radius2": radius * 0.75, "height": length_, "height_segments": 1, "sides": sides, "cap_segments": 1, "smooth": True})


def make_blobmesh(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    radius = max(EPS, f(params, "radius", 12.0))
    count = i(params, "count", 8, 1, 256)
    bx = Builder()
    for idx in range(count):
        angle = TAU * idx / count + rng.uniform(-0.25, 0.25)
        dist = radius * rng.uniform(0.0, 1.6)
        z = rng.uniform(-radius * 0.4, radius * 0.4)
        sph = make_sphere({"radius": radius * rng.uniform(0.75, 1.25), "segments": 12, "rings": 6, "smooth": True})
        bx.add_mesh(sph["verts"], sph["faces"], offset=(math.cos(angle) * dist, math.sin(angle) * dist, z))
    return bx.build(True)


def make_shapemerge(params: Dict[str, object]) -> MeshData:
    width_ = max(EPS, f(params, "width", 80.0))
    radius = max(EPS, f(params, "shape_radius", 20.0))
    sides = i(params, "sides", 5, 3, 64)
    depth = f(params, "cut_depth", 1.0)
    bx = Builder()
    base = make_plane({"length": width_, "width": width_, "length_segments": 1, "width_segments": 1})
    bx.add_mesh(base["verts"], base["faces"])
    pts = []
    for k in range(sides * 2):
        rr = radius if k % 2 == 0 else radius * 0.45
        a = TAU * k / (sides * 2)
        pts.append((math.cos(a) * rr, math.sin(a) * rr))
    star = extrude_polygon(pts, max(EPS, depth))
    bx.add_mesh(star["verts"], star["faces"], offset=(0, 0, depth / 2))
    return bx.build(False)


def make_boolean_preview(params: Dict[str, object], pro: bool = False) -> MeshData:
    op = i(params, "operation", 0, 0, 3)
    bx = Builder()
    if pro:
        base_size = max(EPS, f(params, "base_size", 50.0))
        add_box(bx, base_size, base_size, base_size, (0, 0, 0))
        count = i(params, "cutter_count", 3, 1, 64)
        cr = max(EPS, f(params, "cutter_radius", 8.0))
        for idx in range(count):
            a = TAU * idx / count
            cyl = make_cylinder({"radius": cr, "height": base_size * 1.4, "sides": 16, "smooth": True})
            bx.add_mesh(cyl["verts"], cyl["faces"], offset=(math.cos(a) * base_size * 0.25, math.sin(a) * base_size * 0.25, 0), rot=(math.pi / 2, 0, a))
    else:
        sa = max(EPS, f(params, "size_a", 40.0))
        sb = max(EPS, f(params, "size_b", 30.0))
        off = f(params, "offset", 15.0)
        add_box(bx, sa, sa, sa, (-off / 2, 0, 0))
        if op == 1:
            # show cutter as an inset negative-space proxy above the base
            cyl = make_cylinder({"radius": sb / 2, "height": sa * 1.2, "sides": 24, "smooth": True})
            bx.add_mesh(cyl["verts"], cyl["faces"], offset=(off / 2, 0, 0), rot=(0, math.pi / 2, 0))
        elif op == 2:
            add_box(bx, min(sa, sb), min(sa, sb), min(sa, sb), (0, 0, 0))
        else:
            add_box(bx, sb, sb, sb, (off / 2, 0, 0))
    return bx.build(True)


def make_procutter(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    size = max(EPS, f(params, "size", 80.0))
    pieces = i(params, "pieces", 12, 1, 512)
    gap = max(0.0, f(params, "gap", 1.0))
    bx = Builder()
    cols = max(1, int(math.ceil(math.sqrt(pieces))))
    cell = size / cols
    for idx in range(pieces):
        cx = idx % cols
        cy = idx // cols
        x = -size / 2 + cell * (cx + 0.5)
        y = -size / 2 + cell * (cy + 0.5)
        add_box(bx, max(EPS, cell - gap), max(EPS, cell - gap), rng.uniform(size * 0.04, size * 0.12), (x, y, 0), rot=(0, 0, rng.uniform(-0.2, 0.2)))
    return bx.build(False)


def make_terrain(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    size = max(EPS, f(params, "size", 120.0))
    segs = i(params, "segments", 64, 2, 512)
    h = f(params, "height", 30.0)
    contours = i(params, "contours", 8, 1, 128)
    bx = Builder()
    grid = []
    phase = rng.random() * TAU
    for yy in range(segs + 1):
        row = []
        y = -size / 2 + size * yy / segs
        for xx in range(segs + 1):
            x = -size / 2 + size * xx / segs
            rr = math.sqrt(x * x + y * y) / max(EPS, size / 2)
            z = h * (0.5 + 0.5 * math.cos(rr * contours * math.pi + phase)) * max(0.0, 1.0 - rr * 0.65)
            row.append(bx.add_vertex((x, y, z)))
        grid.append(row)
    for yy in range(segs):
        for xx in range(segs):
            bx.add_face((grid[yy][xx], grid[yy][xx + 1], grid[yy + 1][xx + 1], grid[yy + 1][xx]))
    return bx.build(True)


def make_loft(params: Dict[str, object]) -> MeshData:
    path_length = max(EPS, f(params, "path_length", 100.0))
    radius = max(EPS, f(params, "radius", 8.0))
    path_segments = i(params, "path_segments", 48, 2, 1000)
    sides = i(params, "sides", 12, 3, 256)
    twist = math.radians(f(params, "twist", 180.0))
    pts = []
    for idx in range(path_segments + 1):
        t = idx / path_segments
        x = -path_length / 2 + path_length * t
        y = math.sin(t * math.pi * 2) * radius * 2
        z = math.sin(t * math.pi) * radius * 2
        pts.append((x, y, z))
    return sweep_circle(pts, radius, sides, twist)


def make_mesher(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    count = i(params, "count", 24, 1, 10000)
    radius = max(EPS, f(params, "radius", 4.0))
    spread = max(EPS, f(params, "spread", 80.0))
    frame = f(params, "frame", 0.0)
    bx = Builder()
    for idx in range(count):
        a = rng.random() * TAU + frame * 0.05
        rr = rng.random() * spread * 0.5
        z = math.sin(frame * 0.1 + idx) * spread * 0.1
        sph = make_sphere({"radius": radius * rng.uniform(0.7, 1.3), "segments": 8, "rings": 4, "smooth": True})
        bx.add_mesh(sph["verts"], sph["faces"], offset=(math.cos(a) * rr, math.sin(a) * rr, z))
    return bx.build(True)


DISPATCH = {
    "standard_box": make_box,
    "standard_cone": make_cone,
    "standard_sphere": make_sphere,
    "standard_geosphere": make_geosphere,
    "standard_cylinder": make_cylinder,
    "standard_tube": make_tube,
    "standard_torus": make_torus,
    "standard_pyramid": make_pyramid,
    "standard_teapot": make_teapot,
    "standard_plane": make_plane,
    "extended_hedra": make_hedra,
    "extended_torusknot": make_torusknot,
    "extended_chamferbox": make_chamfer_box,
    "extended_chamfercyl": make_chamfer_cyl,
    "extended_oiltank": make_oiltank,
    "extended_capsule": make_capsule,
    "extended_spindle": make_spindle,
    "extended_l_ext": make_l_ext,
    "extended_gengon": make_gengon,
    "extended_c_ext": make_c_ext,
    "extended_ringwave": make_ringwave,
    "extended_hose": make_hose,
    "extended_prism": make_prism,
    "aec_foliage": make_foliage,
    "aec_railing": make_railing,
    "aec_wall": make_wall,
    "door_pivot": lambda p: make_door(p, "pivot"),
    "door_sliding": lambda p: make_door(p, "sliding"),
    "door_bifold": lambda p: make_door(p, "bifold"),
    "window_awning": lambda p: make_window(p, "awning"),
    "window_casement": lambda p: make_window(p, "casement"),
    "window_fixed": lambda p: make_window(p, "fixed"),
    "window_pivoted": lambda p: make_window(p, "pivoted"),
    "window_projected": lambda p: make_window(p, "projected"),
    "window_sliding": lambda p: make_window(p, "sliding"),
    "stairs_straight": make_straight_stair,
    "stairs_l": make_l_stair,
    "stairs_u": make_u_stair,
    "stairs_spiral": make_spiral_stair,
    "patch_quad": make_quad_patch,
    "patch_tri": make_tri_patch,
    "nurbs_point": make_quad_patch,
    "nurbs_cv": make_quad_patch,
    "compound_morph": make_morph,
    "compound_scatter": make_scatter,
    "compound_conform": make_conform,
    "compound_connect": make_connect,
    "compound_blobmesh": make_blobmesh,
    "compound_shapemerge": make_shapemerge,
    "compound_boolean": lambda p: make_boolean_preview(p, False),
    "compound_proboolean": lambda p: make_boolean_preview(p, True),
    "compound_procutter": make_procutter,
    "compound_terrain": make_terrain,
    "compound_loft": make_loft,
    "compound_mesher": make_mesher,
}


def generate(generator_id: str, params: Dict[str, object]) -> MeshData:
    fn = DISPATCH.get(generator_id)
    if fn is None:
        data = make_box({"length": 10, "width": 10, "height": 10})
    else:
        data = fn(params)
    return sanitize_mesh_data(data, weld_vertices=True)

# -----------------------------------------------------------------------------
# 0.2.0 advanced kernels
# -----------------------------------------------------------------------------
# These replacements keep the original robust fallback functions above while
# adding higher-fidelity generation, object-operand support and working controls
# for options that were previously exposed but simplified.

try:  # package import in Blender
    from .teapot_data import TEAPOT_VERTS, TEAPOT_PATCHES
except Exception:  # direct syntax/import checks outside Blender
    TEAPOT_VERTS, TEAPOT_PATCHES = [], []


def _copy_mesh_data(data: MeshData) -> MeshData:
    return {"verts": list(data.get("verts", [])), "faces": [tuple(fa) for fa in data.get("faces", [])], "smooth": bool(data.get("smooth", False))}


def _apply_z_offset(data: MeshData, dz: float) -> MeshData:
    if abs(dz) <= EPS:
        return data
    data = _copy_mesh_data(data)
    data["verts"] = [(x, y, z + dz) for x, y, z in data.get("verts", [])]
    return data


def _bbox(verts: Sequence[Vec3]) -> Tuple[Vec3, Vec3]:
    if not verts:
        return (0, 0, 0), (0, 0, 0)
    xs = [v[0] for v in verts]
    ys = [v[1] for v in verts]
    zs = [v[2] for v in verts]
    return (min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs))


def _face_normal_from_verts(verts: Sequence[Vec3], face: Sequence[int]) -> Vec3:
    if len(face) < 3:
        return (0, 0, 1)
    a, c, d = verts[face[0]], verts[face[1]], verts[face[2]]
    return normalize(cross(sub(c, a), sub(d, a)), (0, 0, 1))


def _face_center(verts: Sequence[Vec3], face: Sequence[int]) -> Vec3:
    if not face:
        return (0, 0, 0)
    acc = (0.0, 0.0, 0.0)
    for idx in face:
        acc = add(acc, verts[idx])
    return mul(acc, 1.0 / len(face))


def _basis_from_normal(normal: Vec3) -> Tuple[Vec3, Vec3, Vec3]:
    n = normalize(normal, (0, 0, 1))
    up = (0, 0, 1) if abs(dot(n, (0, 0, 1))) < 0.92 else (0, 1, 0)
    t = normalize(cross(up, n), (1, 0, 0))
    bvec = normalize(cross(n, t), (0, 1, 0))
    return t, bvec, n


def _rotated_basis_z(angle: float) -> Tuple[Vec3, Vec3, Vec3]:
    ca, sa = math.cos(angle), math.sin(angle)
    return (ca, sa, 0), (-sa, ca, 0), (0, 0, 1)


def _add_mesh_with_basis(builder: Builder, verts: Sequence[Vec3], faces: Sequence[Sequence[int]], loc: Vec3, scale_: float = 1.0, normal: Vec3 | None = None, rot_z: float = 0.0) -> None:
    if normal is None:
        xaxis, yaxis, zaxis = _rotated_basis_z(rot_z)
    else:
        xaxis, yaxis, zaxis = _basis_from_normal(normal)
        if abs(rot_z) > EPS:
            ca, sa = math.cos(rot_z), math.sin(rot_z)
            xaxis, yaxis = add(mul(xaxis, ca), mul(yaxis, sa)), add(mul(xaxis, -sa), mul(yaxis, ca))
    base = len(builder.verts)
    for v in verts:
        pnt = add(loc, add(add(mul(xaxis, v[0] * scale_), mul(yaxis, v[1] * scale_)), mul(zaxis, v[2] * scale_)))
        builder.add_vertex(pnt)
    for face in faces:
        builder.add_face([base + idx for idx in face])


def _mesh_from_object(obj, world: bool = True) -> MeshData | None:
    if obj is None:
        return None
    try:
        import bpy  # type: ignore
    except Exception:
        return None
    try:
        depsgraph = bpy.context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        temp_mesh = eval_obj.to_mesh()
        mat = getattr(eval_obj, "matrix_world", None)
        verts = []
        for vtx in temp_mesh.vertices:
            co = vtx.co
            if world and mat is not None:
                co = mat @ co
            verts.append((float(co.x), float(co.y), float(co.z)))
        faces = [tuple(int(i) for i in poly.vertices) for poly in temp_mesh.polygons]
        eval_obj.to_mesh_clear()
        return {"verts": verts, "faces": faces, "smooth": True}
    except Exception:
        try:
            data = getattr(obj, "data", None)
            verts = [(float(v.co.x), float(v.co.y), float(v.co.z)) for v in data.vertices]
            faces = [tuple(int(i) for i in poly.vertices) for poly in data.polygons]
            return {"verts": verts, "faces": faces, "smooth": True}
        except Exception:
            return None


def _edges_from_faces(faces: Sequence[Sequence[int]]) -> List[Tuple[int, int]]:
    seen = set()
    edges = []
    for face in faces:
        for k, a in enumerate(face):
            c = face[(k + 1) % len(face)]
            key = tuple(sorted((int(a), int(c))))
            if key not in seen:
                seen.add(key)
                edges.append((int(a), int(c)))
    return edges


def _primitive_source(params: Dict[str, object]) -> MeshData:
    obj_data = _mesh_from_object(params.get("source_object"), world=False)
    if obj_data and obj_data.get("verts"):
        return obj_data
    mode = i(params, "mode", 0, 0, 4)
    scale = max(EPS, f(params, "scale", 3.0))
    if mode == 1:
        return make_cone({"radius1": scale, "radius2": 0.0, "height": scale * 2.0, "sides": 8, "height_segments": 1, "cap_segments": 1})
    if mode == 2:
        return make_sphere_v2({"radius": scale, "segments": 8, "smooth": True})
    if mode == 3:
        return make_cylinder({"radius": scale, "height": scale * 2.0, "sides": 12, "height_segments": 1, "cap_segments": 1})
    return make_box({"length": scale * 2.0, "width": scale * 2.0, "height": scale * 2.0})


def _angle_end_count(angles: Sequence[float], wrap: bool) -> int:
    return len(angles) if wrap else max(0, len(angles) - 1)


def make_frustum_v2(params: Dict[str, object], radius1_key: str = "radius1", radius2_key: str = "radius2") -> MeshData:
    r1 = max(0.0, f(params, radius1_key, f(params, "radius", 15.0)))
    r2 = max(0.0, f(params, radius2_key, r1))
    h = f(params, "height", 25.0)
    hs = i(params, "height_segments", 1, 1, 1000)
    cap_segments = i(params, "cap_segments", 1, 0, 1000)
    sides = i(params, "sides", 24, 3, 3600)
    angles, wrap = angle_range(params, sides)
    n = len(angles)
    end = _angle_end_count(angles, wrap)
    bx = Builder()
    rings: List[List[int]] = []
    axis_rings: List[int] = []
    for zidx in range(hs + 1):
        t = zidx / hs
        z = -h / 2.0 + h * t
        rcur = r1 + (r2 - r1) * t
        rings.append([bx.add_vertex((math.cos(a) * rcur, math.sin(a) * rcur, z)) for a in angles])
        axis_rings.append(bx.add_vertex((0.0, 0.0, z)))
    for zidx in range(hs):
        for k in range(end):
            k2 = (k + 1) % n
            if length(sub(bx.verts[rings[zidx][k]], bx.verts[rings[zidx + 1][k2]])) > EPS:
                bx.add_face((rings[zidx][k], rings[zidx][k2], rings[zidx + 1][k2], rings[zidx + 1][k]))
    # Caps with concentric rings.  Use the existing axis center vertices for the innermost cap.
    for zidx, rcur, flip in [(0, r1, True), (hs, r2, False)]:
        if rcur > EPS and cap_segments > 0:
            previous = rings[zidx]
            for cidx in range(1, cap_segments + 1):
                rr = rcur * (cap_segments - cidx) / cap_segments
                if rr <= EPS:
                    center = axis_rings[zidx]
                    for k in range(end):
                        k2 = (k + 1) % n
                        face = (previous[k], previous[k2], center)
                        bx.add_face(tuple(reversed(face)) if flip else face)
                    break
                ring = [bx.add_vertex((math.cos(a) * rr, math.sin(a) * rr, -h / 2.0 + h * zidx / hs)) for a in angles]
                for k in range(end):
                    k2 = (k + 1) % n
                    face = (previous[k], previous[k2], ring[k2], ring[k])
                    bx.add_face(tuple(reversed(face)) if flip else face)
                previous = ring
    # Close slice sides with radial faces.
    if not wrap and n >= 2:
        for edge_index, reverse in ((0, True), (n - 1, False)):
            for zidx in range(hs):
                face = (axis_rings[zidx], rings[zidx][edge_index], rings[zidx + 1][edge_index], axis_rings[zidx + 1])
                bx.add_face(tuple(reversed(face)) if reverse else face)
    return bx.build(bool(params.get("smooth", True)))


def make_cylinder_v2(params: Dict[str, object]) -> MeshData:
    local = dict(params)
    local["radius1"] = f(params, "radius", 15.0)
    local["radius2"] = f(params, "radius", 15.0)
    return make_frustum_v2(local)


def make_cone_v2(params: Dict[str, object]) -> MeshData:
    return make_frustum_v2(params, "radius1", "radius2")


def make_tube_v2(params: Dict[str, object]) -> MeshData:
    r1 = max(0.0, f(params, "radius1", 25.0))
    r2 = max(0.0, f(params, "radius2", 20.0))
    outer, inner = max(r1, r2), min(r1, r2)
    inner = min(inner, max(EPS, outer - EPS))
    h = f(params, "height", 50.0)
    hs = i(params, "height_segments", 1, 1, 1000)
    sides = i(params, "sides", 24, 3, 3600)
    cap_segments = i(params, "cap_segments", 1, 1, 1000)
    angles, wrap = angle_range(params, sides)
    n = len(angles)
    end = _angle_end_count(angles, wrap)
    bx = Builder()
    radii = [outer - (outer - inner) * idx / cap_segments for idx in range(cap_segments + 1)]
    rings = []
    for zidx in range(hs + 1):
        z = -h / 2.0 + h * zidx / hs
        layer = []
        for rr in radii:
            layer.append([bx.add_vertex((math.cos(a) * rr, math.sin(a) * rr, z)) for a in angles])
        rings.append(layer)
    # outer/inner walls
    for zidx in range(hs):
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((rings[zidx][0][k], rings[zidx][0][k2], rings[zidx + 1][0][k2], rings[zidx + 1][0][k]))
            bx.add_face((rings[zidx][cap_segments][k2], rings[zidx][cap_segments][k], rings[zidx + 1][cap_segments][k], rings[zidx + 1][cap_segments][k2]))
    # top/bottom annular caps with cap segments
    for zidx, flip in [(0, True), (hs, False)]:
        for ridx in range(cap_segments):
            for k in range(end):
                k2 = (k + 1) % n
                face = (rings[zidx][ridx][k], rings[zidx][ridx][k2], rings[zidx][ridx + 1][k2], rings[zidx][ridx + 1][k])
                bx.add_face(tuple(reversed(face)) if flip else face)
    if not wrap and n >= 2:
        for edge_index, reverse in ((0, True), (n - 1, False)):
            for zidx in range(hs):
                for ridx in range(cap_segments):
                    face = (rings[zidx][ridx][edge_index], rings[zidx][ridx + 1][edge_index], rings[zidx + 1][ridx + 1][edge_index], rings[zidx + 1][ridx][edge_index])
                    bx.add_face(tuple(reversed(face)) if reverse else face)
    return bx.build(bool(params.get("smooth", True)))


def make_torus_v2(params: Dict[str, object]) -> MeshData:
    R = max(EPS, f(params, "radius1", 25.0))
    r = max(EPS, f(params, "radius2", 10.0))
    seg = i(params, "segments", 24, 3, 3600)
    sides = i(params, "sides", 12, 3, 1000)
    tube_rotation = math.radians(f(params, "tube_rotation", 0.0))
    tube_twist = math.radians(f(params, "tube_twist", 0.0))
    angles, wrap = angle_range(params, seg)
    bx = Builder()
    grid = []
    denom = max(1, (len(angles) - 1 if not wrap else len(angles)))
    for idx, a in enumerate(angles):
        ca, sa = math.cos(a), math.sin(a)
        row = []
        twist_angle = tube_rotation + tube_twist * idx / denom
        for j in range(sides):
            bangle = TAU * j / sides + twist_angle
            cb, sb = math.cos(bangle), math.sin(bangle)
            row.append(bx.add_vertex(((R + r * cb) * ca, (R + r * cb) * sa, r * sb)))
        grid.append(row)
    n = len(angles)
    end = _angle_end_count(angles, wrap)
    for k in range(end):
        k2 = (k + 1) % n
        for j in range(sides):
            j2 = (j + 1) % sides
            bx.add_face((grid[k][j], grid[k2][j], grid[k2][j2], grid[k][j2]))
    if not wrap and n >= 2:
        c0 = bx.add_vertex((math.cos(angles[0]) * R, math.sin(angles[0]) * R, 0.0))
        c1 = bx.add_vertex((math.cos(angles[-1]) * R, math.sin(angles[-1]) * R, 0.0))
        for j in range(sides):
            j2 = (j + 1) % sides
            bx.add_face((c0, grid[0][j2], grid[0][j]))
            bx.add_face((c1, grid[-1][j], grid[-1][j2]))
    smooth_value = params.get("smooth", 0)
    try:
        smooth = int(smooth_value) > 0
    except Exception:
        smooth = bool(smooth_value)
    return bx.build(smooth)


def make_sphere_v2(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 25.0))
    seg = i(params, "segments", 16, 4, 3600)
    lat = max(2, seg // 2)
    hemisphere = clamp(f(params, "hemisphere", 0.0), 0.0, 0.9999)
    chop = i(params, "hemisphere_mode", i(params, "chop", 0, 0, 1), 0, 1) == 0
    angles, wrap = angle_range(params, seg)
    n = len(angles)
    end = _angle_end_count(angles, wrap)
    bx = Builder()
    # Chop removes the lower part.  Hemisphere .5 is a half sphere, 1 approaches nothing.
    max_phi = math.pi * (1.0 - hemisphere) if chop else math.pi
    max_phi = max(0.02, max_phi)
    rows = []
    for ridx in range(lat + 1):
        phi = max_phi * ridx / lat
        z = radius * math.cos(phi)
        rr = radius * math.sin(phi)
        if not chop and hemisphere > EPS:
            cut_z = radius * math.cos(math.pi * (1.0 - hemisphere))
            if z < cut_z:
                # Preserve vertices but squash the removed cap upward into the cut plane.
                factor = max(0.0, 1.0 - hemisphere * 1.75)
                z = cut_z + (z - cut_z) * factor
                rr *= max(0.05, 1.0 - hemisphere * 0.5)
        if rr <= EPS:
            rows.append([bx.add_vertex((0.0, 0.0, z)) for _ in angles])
        else:
            rows.append([bx.add_vertex((math.cos(a) * rr, math.sin(a) * rr, z)) for a in angles])
    for ridx in range(lat):
        for k in range(end):
            k2 = (k + 1) % n
            if ridx == 0:
                bx.add_face((rows[ridx][k], rows[ridx + 1][k], rows[ridx + 1][k2]))
            elif ridx == lat - 1 and hemisphere <= EPS:
                bx.add_face((rows[ridx][k2], rows[ridx][k], rows[ridx + 1][k]))
            else:
                bx.add_face((rows[ridx][k], rows[ridx + 1][k], rows[ridx + 1][k2], rows[ridx][k2]))
    if hemisphere > EPS:
        bottom_z = bx.verts[rows[-1][0]][2]
        center = bx.add_vertex((0.0, 0.0, bottom_z))
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((rows[-1][k2], rows[-1][k], center))
    if not wrap and n >= 2:
        for edge_index, reverse in ((0, True), (n - 1, False)):
            axis_ids = []
            for ridx in range(lat + 1):
                z = bx.verts[rows[ridx][edge_index]][2]
                axis_ids.append(bx.add_vertex((0.0, 0.0, z)))
            for ridx in range(lat):
                face = (axis_ids[ridx], rows[ridx][edge_index], rows[ridx + 1][edge_index], axis_ids[ridx + 1])
                bx.add_face(tuple(reversed(face)) if reverse else face)
    data = bx.build(bool(params.get("smooth", True)))
    if b(params, "recenter", False) and hemisphere <= EPS:
        data = _apply_z_offset(data, radius)
    return data


def make_geosphere_v2(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 25.0))
    frequency = i(params, "segments", 4, 1, 200)
    base_type = i(params, "base_type", 2, 0, 2)
    base_verts, base_faces = _base_polyhedron(base_type)
    bx = Builder()
    cache: Dict[Tuple[int, int, int], int] = {}

    def add_norm_vertex(v: Vec3) -> int:
        vn = normalize(v)
        key = (round(vn[0] * 1000000), round(vn[1] * 1000000), round(vn[2] * 1000000))
        if key in cache:
            return cache[key]
        idx = bx.add_vertex(mul(vn, radius))
        cache[key] = idx
        return idx

    for face in base_faces:
        A, B, C = [base_verts[idx] for idx in face]
        grid: Dict[Tuple[int, int], int] = {}
        for ii in range(frequency + 1):
            for jj in range(frequency + 1 - ii):
                aa = 1.0 - (ii + jj) / frequency
                bb = ii / frequency
                cc = jj / frequency
                pnt = add(add(mul(A, aa), mul(B, bb)), mul(C, cc))
                grid[(ii, jj)] = add_norm_vertex(pnt)
        for ii in range(frequency):
            for jj in range(frequency - ii):
                v0 = grid[(ii, jj)]
                v1 = grid[(ii + 1, jj)]
                v2 = grid[(ii, jj + 1)]
                bx.add_face((v0, v1, v2))
                if jj < frequency - ii - 1:
                    v3 = grid[(ii + 1, jj + 1)]
                    bx.add_face((v1, v3, v2))
    data = bx.build(bool(params.get("smooth", True)))
    if b(params, "hemisphere", False):
        verts = list(data["verts"])
        faces = [fa for fa in data["faces"] if all(verts[idx][2] >= -EPS for idx in fa)]
        data = {"verts": verts, "faces": faces, "smooth": data.get("smooth", True)}
    elif b(params, "base_to_pivot", False):
        data = _apply_z_offset(data, radius)
    return data


def make_plane_v2(params: Dict[str, object]) -> MeshData:
    local = dict(params)
    scale = max(EPS, f(params, "render_scale", 1.0))
    density = max(0.01, f(params, "density", 1.0))
    local["length"] = max(EPS, f(params, "length", 25.0) * scale)
    local["width"] = max(EPS, f(params, "width", 25.0) * scale)
    local["length_segments"] = max(1, int(round(i(params, "length_segments", 4, 1, 2000) * density)))
    local["width_segments"] = max(1, int(round(i(params, "width_segments", 4, 1, 2000) * density)))
    return make_plane(local)


def make_pyramid_v2(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 25.0))
    d = max(EPS, f(params, "depth", 25.0))
    h = f(params, "height", 25.0)
    ws = i(params, "width_segments", 1, 1, 512)
    ds = i(params, "depth_segments", 1, 1, 512)
    hs = i(params, "height_segments", 1, 1, 512)
    bx = Builder()
    # Base grid.
    add_grid(bx, (-w / 2, -d / 2, -h / 2), (w, 0, 0), (0, d, 0), ws, ds, True)
    # Rectangle rings from base to near apex; last ring collapses to apex.
    rings = []
    perim_steps = max(4, 2 * (ws + ds))
    for level in range(hs + 1):
        t = level / hs
        ww, dd = w * (1 - t), d * (1 - t)
        z = -h / 2 + h * t
        if ww <= EPS or dd <= EPS:
            rings.append([bx.add_vertex((0, 0, z)) for _ in range(perim_steps)])
            continue
        pts: List[Vec3] = []
        for k in range(ws): pts.append((-ww/2 + ww*k/ws, -dd/2, z))
        for k in range(ds): pts.append((ww/2, -dd/2 + dd*k/ds, z))
        for k in range(ws): pts.append((ww/2 - ww*k/ws, dd/2, z))
        for k in range(ds): pts.append((-ww/2, dd/2 - dd*k/ds, z))
        rings.append([bx.add_vertex(pnt) for pnt in pts])
    for level in range(hs):
        for k in range(perim_steps):
            k2 = (k + 1) % perim_steps
            if level == hs - 1:
                bx.add_face((rings[level][k], rings[level][k2], rings[level + 1][k]))
            else:
                bx.add_face((rings[level][k], rings[level][k2], rings[level + 1][k2], rings[level + 1][k]))
    return bx.build(False)


def _bernstein3(t: float) -> Tuple[float, float, float, float]:
    u = 1.0 - t
    return (u * u * u, 3.0 * t * u * u, 3.0 * t * t * u, t * t * t)


def _eval_bezier_patch(points: Sequence[Vec3], u: float, v: float) -> Vec3:
    bu = _bernstein3(u)
    bv = _bernstein3(v)
    out = (0.0, 0.0, 0.0)
    for row in range(4):
        for col in range(4):
            pnt = points[row * 4 + col]
            weight = bu[col] * bv[row]
            out = add(out, mul(pnt, weight))
    return out


def make_teapot_bezier(params: Dict[str, object]) -> MeshData:
    if not TEAPOT_VERTS or not TEAPOT_PATCHES:
        return make_teapot(params)
    segs = i(params, "segments", 4, 1, 64)
    radius = max(EPS, f(params, "radius", 25.0))
    include_body = b(params, "body", True)
    include_handle = b(params, "handle", True)
    include_spout = b(params, "spout", True)
    include_lid = b(params, "lid", True)
    patch_ranges = []
    if include_body:
        patch_ranges.extend(range(0, 12))
        patch_ranges.extend(range(28, 32))
    if include_handle:
        patch_ranges.extend(range(12, 16))
    if include_spout:
        patch_ranges.extend(range(16, 20))
    if include_lid:
        patch_ranges.extend(range(20, 28))
    bx = Builder()
    # Public Utah data has a maximum horizontal half extent of about 3.525. Normalize to the requested radius.
    scale = radius / 3.525
    x_center = 0.0
    y_center = 0.0
    z_base = 0.0
    for pidx in patch_ranges:
        indices = TEAPOT_PATCHES[pidx]
        cps = [TEAPOT_VERTS[idx] for idx in indices]
        grid = []
        for vv in range(segs + 1):
            row = []
            for uu in range(segs + 1):
                pnt = _eval_bezier_patch(cps, uu / segs, vv / segs)
                # Convert teapot data Z-up coordinates into Blender local coordinates with base at local Z=0.
                row.append(bx.add_vertex(((pnt[0] - x_center) * scale, (pnt[1] - y_center) * scale, (pnt[2] - z_base) * scale)))
            grid.append(row)
        for vv in range(segs):
            for uu in range(segs):
                bx.add_face((grid[vv][uu], grid[vv][uu + 1], grid[vv + 1][uu + 1], grid[vv + 1][uu]))
    return bx.build(bool(params.get("smooth", True)))


def _rounded_box_point(q: Vec3, sx: float, sy: float, sz: float, fillet: float, fallback: Vec3) -> Vec3:
    core = (clamp(q[0], -sx, sx), clamp(q[1], -sy, sy), clamp(q[2], -sz, sz))
    direction = sub(q, core)
    if length(direction) < EPS:
        direction = fallback
    return add(core, mul(normalize(direction, fallback), fillet))


def make_chamfer_box_v2(params: Dict[str, object]) -> MeshData:
    lx = max(EPS, f(params, "length", 25.0))
    wy = max(EPS, f(params, "width", 25.0))
    hz = max(EPS, f(params, "height", 25.0))
    fillet = clamp(f(params, "fillet", 2.0), 0.0, min(lx, wy, hz) * 0.49)
    if fillet <= EPS:
        return make_box(params)
    fs = i(params, "fillet_segments", 2, 1, 128)
    xs = i(params, "length_segments", 1, 1, 512) + fs * 2
    ys = i(params, "width_segments", 1, 1, 512) + fs * 2
    zs = i(params, "height_segments", 1, 1, 512) + fs * 2
    sx, sy, sz = max(EPS, lx / 2 - fillet), max(EPS, wy / 2 - fillet), max(EPS, hz / 2 - fillet)
    bx = Builder()

    def face_grid(axis: int, sign: float, uaxis: int, vaxis: int, ucount: int, vcount: int):
        grid = []
        dims = [sx + fillet, sy + fillet, sz + fillet]
        core_dims = [sx, sy, sz]
        fallback = [0.0, 0.0, 0.0]
        fallback[axis] = sign
        for vv in range(vcount + 1):
            row = []
            for uu in range(ucount + 1):
                q = [0.0, 0.0, 0.0]
                q[axis] = sign * dims[axis]
                q[uaxis] = -dims[uaxis] + 2 * dims[uaxis] * uu / ucount
                q[vaxis] = -dims[vaxis] + 2 * dims[vaxis] * vv / vcount
                row.append(bx.add_vertex(_rounded_box_point(tuple(q), core_dims[0], core_dims[1], core_dims[2], fillet, tuple(fallback))))
            grid.append(row)
        for vv in range(vcount):
            for uu in range(ucount):
                face = (grid[vv][uu], grid[vv][uu + 1], grid[vv + 1][uu + 1], grid[vv + 1][uu])
                bx.add_face(face if sign > 0 else tuple(reversed(face)))

    face_grid(2, 1, 0, 1, xs, ys)
    face_grid(2, -1, 0, 1, xs, ys)
    face_grid(1, 1, 0, 2, xs, zs)
    face_grid(1, -1, 0, 2, xs, zs)
    face_grid(0, 1, 1, 2, ys, zs)
    face_grid(0, -1, 1, 2, ys, zs)
    return bx.build(bool(params.get("smooth", True)))


def make_revolved_profile_v2(profile: Sequence[Tuple[float, float]], sides: int, smooth: bool = True, params: Dict[str, object] | None = None) -> MeshData:
    params = params or {}
    angles, wrap = angle_range(params, sides)
    n = len(angles)
    end = _angle_end_count(angles, wrap)
    bx = Builder()
    rings = []
    for z, rad in profile:
        rad = max(0.0, rad)
        rings.append([bx.add_vertex((math.cos(a) * rad, math.sin(a) * rad, z)) for a in angles])
    for aidx in range(len(rings) - 1):
        for k in range(end):
            k2 = (k + 1) % n
            bx.add_face((rings[aidx][k], rings[aidx][k2], rings[aidx + 1][k2], rings[aidx + 1][k]))
    if not wrap and n >= 2:
        for edge_index, reverse in ((0, True), (n - 1, False)):
            for aidx in range(len(rings) - 1):
                face = (rings[aidx][edge_index], rings[aidx + 1][edge_index], bx.add_vertex((0, 0, profile[aidx + 1][0])), bx.add_vertex((0, 0, profile[aidx][0])))
                bx.add_face(tuple(reversed(face)) if reverse else face)
    return bx.build(smooth)


def make_chamfer_cyl_v2(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, abs(f(params, "height", 25.0)))
    fillet = clamp(f(params, "fillet", 2.0), 0.0, min(r * 0.98, h * 0.49))
    fs = i(params, "fillet_segments", 2, 1, 128)
    sides = i(params, "sides", 24, 3, 3600)
    if fillet <= EPS:
        return make_cylinder_v2(params)
    profile = [(-h / 2, 0.0), (-h / 2, max(EPS, r - fillet))]
    for sidx in range(fs + 1):
        t = sidx / fs
        angle = -math.pi / 2 + t * math.pi / 2
        profile.append((-h / 2 + fillet + math.sin(angle) * fillet, r - fillet + math.cos(angle) * fillet))
    profile.append((h / 2 - fillet, r))
    for sidx in range(fs + 1):
        t = sidx / fs
        angle = t * math.pi / 2
        profile.append((h / 2 - fillet + math.sin(angle) * fillet, r - fillet + math.cos(angle) * fillet))
    profile.append((h / 2, 0.0))
    return make_revolved_profile_v2(profile, sides, bool(params.get("smooth", True)), params)


def make_oiltank_v2(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, f(params, "height", 50.0))
    cap_h = clamp(f(params, "cap_height", 8.0), 0.0, h / 2)
    sides = i(params, "sides", 24, 3, 3600)
    cap_seg = i(params, "cap_segments", 4, 1, 256)
    profile: List[Tuple[float, float]] = []
    for sidx in range(cap_seg + 1):
        t = sidx / cap_seg
        profile.append((-h / 2 + cap_h * t, r * math.sin(t * math.pi / 2)))
    profile.append((h / 2 - cap_h, r))
    for sidx in range(cap_seg, -1, -1):
        t = sidx / cap_seg
        profile.append((h / 2 - cap_h + cap_h * (1 - t), r * math.sin(t * math.pi / 2)))
    return make_revolved_profile_v2(profile, sides, bool(params.get("smooth", True)), params)


def make_capsule_v2(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, f(params, "height", 25.0))
    cyl_h = max(0.0, h - 2 * r) if i(params, "height_type", 1, 0, 1) == 0 else h
    sides = i(params, "sides", 24, 3, 3600)
    cap_seg = i(params, "cap_segments", 8, 1, 256)
    profile: List[Tuple[float, float]] = []
    bottom_center, top_center = -cyl_h / 2, cyl_h / 2
    for sidx in range(cap_seg + 1):
        angle = -math.pi / 2 + (math.pi / 2) * sidx / cap_seg
        profile.append((bottom_center + math.sin(angle) * r, math.cos(angle) * r))
    profile.append((top_center, r))
    for sidx in range(cap_seg + 1):
        angle = (math.pi / 2) * sidx / cap_seg
        profile.append((top_center + math.sin(angle) * r, math.cos(angle) * r))
    return make_revolved_profile_v2(profile, sides, bool(params.get("smooth", True)), params)


def make_spindle_v2(params: Dict[str, object]) -> MeshData:
    r = max(EPS, f(params, "radius", 15.0))
    h = max(EPS, f(params, "height", 50.0))
    cap_h = clamp(f(params, "cap_height", 10.0), 0.0, h / 2)
    sides = i(params, "sides", 24, 3, 3600)
    profile = [(-h / 2, 0.0), (-h / 2 + cap_h, r), (h / 2 - cap_h, r), (h / 2, 0.0)]
    return make_revolved_profile_v2(profile, sides, bool(params.get("smooth", True)), params)


def make_gengon_v2(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 15.0))
    height = f(params, "height", 25.0)
    sides = i(params, "sides", 6, 3, 360)
    fillet = max(0.0, f(params, "fillet", 0.0))
    fs = i(params, "fillet_segments", 2, 1, 64)
    if fillet <= EPS:
        return make_cylinder_v2({**params, "radius": radius, "sides": sides})
    verts2 = [(math.cos(TAU * k / sides) * radius, math.sin(TAU * k / sides) * radius) for k in range(sides)]
    outline = []
    for k, p0 in enumerate(verts2):
        p_prev = verts2[(k - 1) % sides]
        p_next = verts2[(k + 1) % sides]
        v1 = normalize((p_prev[0] - p0[0], p_prev[1] - p0[1], 0), (1, 0, 0))
        v2 = normalize((p_next[0] - p0[0], p_next[1] - p0[1], 0), (0, 1, 0))
        max_f = min(length((p_prev[0] - p0[0], p_prev[1] - p0[1], 0)), length((p_next[0] - p0[0], p_next[1] - p0[1], 0))) * 0.45
        ff = min(fillet, max_f)
        a = (p0[0] + v1[0] * ff, p0[1] + v1[1] * ff)
        c = (p0[0] + v2[0] * ff, p0[1] + v2[1] * ff)
        for sidx in range(fs + 1):
            t = sidx / fs
            # quadratic corner blend through original vertex
            x = (1-t)*(1-t)*a[0] + 2*(1-t)*t*p0[0] + t*t*c[0]
            y = (1-t)*(1-t)*a[1] + 2*(1-t)*t*p0[1] + t*t*c[1]
            outline.append((x, y))
    data = extrude_polygon(outline, height)
    if not b(params, "center", True):
        data = _apply_z_offset(data, height / 2)
    data["smooth"] = bool(params.get("smooth", True))
    return data


def make_ringwave_v2(params: Dict[str, object]) -> MeshData:
    outer = max(EPS, f(params, "outer_radius", 50.0))
    inner = clamp(f(params, "inner_radius", 35.0), 0.0, outer - EPS)
    h = f(params, "height", 2.0)
    seg = i(params, "segments", 128, 8, 3600)
    waves = i(params, "waves", 8, 1, 512)
    amp = f(params, "amplitude", 5.0)
    phase = math.radians(f(params, "phase", 0.0))
    outer_break = f(params, "outer_edge_breakup", 0.0) / 100.0
    inner_break = f(params, "inner_edge_breakup", 0.0) / 100.0
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    outer_noise = [rng.uniform(-1, 1) * outer_break * amp for _ in range(seg)]
    inner_noise = [rng.uniform(-1, 1) * inner_break * amp for _ in range(seg)]
    bx = Builder()
    top_o = []; top_i = []; bot_o = []; bot_i = []
    for k in range(seg):
        a = TAU * k / seg
        wave = math.sin(a * waves + phase) * amp
        ro = max(EPS, outer + wave + outer_noise[k])
        ri = max(0.0, inner + wave * 0.35 + inner_noise[k])
        top_o.append(bx.add_vertex((math.cos(a) * ro, math.sin(a) * ro, h / 2)))
        top_i.append(bx.add_vertex((math.cos(a) * ri, math.sin(a) * ri, h / 2)))
        bot_o.append(bx.add_vertex((math.cos(a) * ro, math.sin(a) * ro, -h / 2)))
        bot_i.append(bx.add_vertex((math.cos(a) * ri, math.sin(a) * ri, -h / 2)))
    for k in range(seg):
        k2 = (k + 1) % seg
        bx.add_face((top_o[k], top_o[k2], top_i[k2], top_i[k]))
        bx.add_face((bot_o[k2], bot_o[k], bot_i[k], bot_i[k2]))
        bx.add_face((top_o[k2], top_o[k], bot_o[k], bot_o[k2]))
        bx.add_face((top_i[k], top_i[k2], bot_i[k2], bot_i[k]))
    return bx.build(bool(params.get("smooth", True)))


def _object_location(obj) -> Vec3 | None:
    if obj is None:
        return None
    try:
        loc = obj.matrix_world.translation
        return (float(loc.x), float(loc.y), float(loc.z))
    except Exception:
        try:
            loc = obj.location
            return (float(loc[0]), float(loc[1]), float(loc[2]))
        except Exception:
            return None


def make_hose_v2(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "diameter", f(params, "radius", 10.0) * 2.0) * 0.5)
    length_ = max(EPS, f(params, "length", 80.0))
    segments = i(params, "segments", 96, 4, 3600)
    sides = i(params, "sides", 16, 3, 256)
    cycles = i(params, "cycles", 16, 1, 1000)
    amp = max(0.0, f(params, "amplitude", 2.0))
    bend = math.radians(f(params, "bend", 0.0))
    tension = f(params, "tension", 0.0) / 100.0
    start = _object_location(params.get("start_object")) or (0.0, 0.0, -length_ / 2)
    endp = _object_location(params.get("end_object")) or (0.0, 0.0, length_ / 2)
    points = []
    for sidx in range(segments + 1):
        t = sidx / segments
        pnt = lerp(start, endp, t)
        sag = math.sin(math.pi * t) * tension * length_
        pnt = (pnt[0] + math.sin(t * math.pi) * math.sin(bend) * length_ * 0.25, pnt[1], pnt[2] + sag)
        points.append(pnt)
    # Variable corrugation radius along the sweep.
    bx = Builder()
    rings = []
    prev_n: Vec3 | None = None
    for idx, pnt in enumerate(points):
        tangent = _path_tangent(points, idx, (0.0, 0.0, 1.0))
        nvec, bvec, prev_n = _transport_sweep_frame(tangent, prev_n)
        rr = max(EPS, radius + amp * math.sin(TAU * cycles * idx / max(1, segments)))
        row = []
        for k in range(sides):
            a = TAU * k / sides
            row.append(bx.add_vertex(add(pnt, add(mul(nvec, math.cos(a) * rr), mul(bvec, math.sin(a) * rr)))))
        rings.append(row)
    for idx in range(segments):
        for k in range(sides):
            k2 = (k + 1) % sides
            bx.add_face((rings[idx][k], rings[idx][k2], rings[idx + 1][k2], rings[idx + 1][k]))
    return bx.build(bool(params.get("smooth", True)))


def _surface_z(u: float, v: float, curvature: float, mode: int) -> float:
    if mode == 1:
        r2 = (u - 0.5) ** 2 + (v - 0.5) ** 2
        return curvature * max(0.0, 1.0 - 4.0 * r2)
    if mode == 2:
        return curvature * ((u - 0.5) ** 2 - (v - 0.5) ** 2)
    if mode == 3:
        return curvature * math.sin(TAU * u) * math.sin(TAU * v)
    return curvature * math.sin(math.pi * u) * math.sin(math.pi * v)


def make_quad_patch_v2(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 40.0))
    width_ = max(EPS, f(params, "width", 40.0))
    xs = i(params, "length_segments", i(params, "u_points", i(params, "u_cvs", 4)), 1, 512)
    ys = i(params, "width_segments", i(params, "v_points", i(params, "v_cvs", 4)), 1, 512)
    curv = f(params, "curvature", 0.0)
    mode = i(params, "surface_mode", 0, 0, 3)
    bx = Builder(); grid = []
    for yy in range(ys + 1):
        v = yy / ys
        row = []
        for xx in range(xs + 1):
            u = xx / xs
            row.append(bx.add_vertex((-length_ / 2 + length_ * u, -width_ / 2 + width_ * v, _surface_z(u, v, curv, mode))))
        grid.append(row)
    for yy in range(ys):
        for xx in range(xs):
            bx.add_face((grid[yy][xx], grid[yy][xx + 1], grid[yy + 1][xx + 1], grid[yy + 1][xx]))
    return bx.build(True)


def make_tri_patch_v2(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 40.0))
    h = max(EPS, f(params, "height", 40.0))
    segs = i(params, "segments", 6, 1, 512)
    curv = f(params, "curvature", 0.0)
    mode = i(params, "surface_mode", 0, 0, 3)
    bx = Builder(); rows = []
    for row in range(segs + 1):
        t = row / segs
        count = row + 1
        y = -h / 2 + h * t
        row_ids = []
        span = w * t
        for col in range(count):
            u = 0.5 if count == 1 else col / (count - 1)
            x = 0 if count == 1 else -span / 2 + span * u
            z = _surface_z(u, t, curv, mode) * t
            row_ids.append(bx.add_vertex((x, y, z)))
        rows.append(row_ids)
    for row in range(segs):
        for col in range(len(rows[row])):
            bx.add_face((rows[row][col], rows[row + 1][col], rows[row + 1][col + 1]))
            if col < len(rows[row]) - 1:
                bx.add_face((rows[row][col], rows[row][col + 1], rows[row + 1][col + 1]))
    return bx.build(True)


def _path_points(path_type: int, length_: float, corner_length: float) -> List[Vec3]:
    if path_type == 1:
        return [(-length_/2, 0, 0), (length_/2, 0, 0), (length_/2, corner_length, 0)]
    if path_type == 2:
        return [(-length_/2, -corner_length/2, 0), (length_/2, -corner_length/2, 0), (length_/2, corner_length/2, 0), (-length_/2, corner_length/2, 0)]
    if path_type == 3:
        return [(-length_/2, -corner_length/2, 0), (length_/2, -corner_length/2, 0), (length_/2, corner_length/2, 0), (-length_/2, corner_length/2, 0), (-length_/2, -corner_length/2, 0)]
    return [(-length_/2, 0, 0), (length_/2, 0, 0)]


def _segment_frame(a: Vec3, c: Vec3) -> Tuple[Vec3, Vec3, float]:
    direction = sub(c, a)
    seg_len = length(direction)
    tangent = normalize(direction, (1, 0, 0))
    normal = normalize(cross((0, 0, 1), tangent), (0, 1, 0))
    return tangent, normal, seg_len


def _add_oriented_box(builder: Builder, length_: float, width_: float, height_: float, center: Vec3, tangent: Vec3, normal: Vec3) -> None:
    zaxis = (0, 0, 1)
    verts = []
    for sxn in (-0.5, 0.5):
        for syn in (-0.5, 0.5):
            for szn in (-0.5, 0.5):
                verts.append(add(center, add(add(mul(tangent, sxn * length_), mul(normal, syn * width_)), mul(zaxis, szn * height_))))
    base = len(builder.verts)
    for vtx in verts:
        builder.add_vertex(vtx)
    for fa in [(0,2,3,1),(4,5,7,6),(0,1,5,4),(2,6,7,3),(0,4,6,2),(1,3,7,5)]:
        builder.add_face(tuple(base + q for q in fa))


def _add_wall_run(builder: Builder, a: Vec3, c: Vec3, width_: float, height_: float, bottom: float, openings: int, opening_w: float, opening_h: float, opening_sill: float, justify: int) -> None:
    tangent, normal, seg_len = _segment_frame(a, c)
    if seg_len <= EPS:
        return
    offset = (justify - 1) * width_ * 0.5
    base_center = add(mul(add(a, c), 0.5), add(mul(normal, offset), (0, 0, bottom + height_ / 2)))
    if openings <= 0 or opening_w <= EPS or opening_h <= EPS:
        _add_oriented_box(builder, seg_len, width_, height_, base_center, tangent, normal)
        return
    # Build wall as pieces around evenly spaced openings.
    gap_count = openings + 1
    usable = max(0.0, seg_len - openings * opening_w)
    gap = usable / gap_count
    cursor = 0.0
    for oi in range(openings):
        # solid segment before opening
        if gap > EPS:
            local_center = cursor + gap / 2
            center = add(add(a, mul(tangent, local_center)), add(mul(normal, offset), (0, 0, bottom + height_ / 2)))
            _add_oriented_box(builder, gap, width_, height_, center, tangent, normal)
        cursor += gap
        ow = min(opening_w, max(0.0, seg_len - cursor))
        if ow > EPS:
            # sill and header pieces
            sill_h = min(opening_sill, height_)
            if sill_h > EPS:
                center = add(add(a, mul(tangent, cursor + ow / 2)), add(mul(normal, offset), (0, 0, bottom + sill_h / 2)))
                _add_oriented_box(builder, ow, width_, sill_h, center, tangent, normal)
            header_z = opening_sill + opening_h
            if header_z < height_:
                hh = height_ - header_z
                center = add(add(a, mul(tangent, cursor + ow / 2)), add(mul(normal, offset), (0, 0, bottom + header_z + hh / 2)))
                _add_oriented_box(builder, ow, width_, hh, center, tangent, normal)
        cursor += ow
    remaining = seg_len - cursor
    if remaining > EPS:
        center = add(add(a, mul(tangent, cursor + remaining / 2)), add(mul(normal, offset), (0, 0, bottom + height_ / 2)))
        _add_oriented_box(builder, remaining, width_, height_, center, tangent, normal)


def make_wall_v2(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 120.0))
    width_ = max(EPS, f(params, "width", 12.0))
    height_ = max(EPS, f(params, "height", 60.0))
    bottom = f(params, "bottom_offset", 0.0)
    top = f(params, "top_offset", 0.0)
    path_type = i(params, "path_type", 0, 0, 3)
    corner_length = max(EPS, f(params, "corner_length", 80.0))
    justify = i(params, "justify", 1, 0, 2)
    openings = i(params, "openings", 0, 0, 32)
    opening_w = max(EPS, f(params, "opening_width", 24.0))
    opening_h = max(EPS, f(params, "opening_height", 36.0))
    opening_sill = max(0.0, f(params, "opening_sill", 12.0))
    pts = _path_points(path_type, length_, corner_length)
    bx = Builder()
    for a, c in zip(pts, pts[1:]):
        _add_wall_run(bx, a, c, width_, height_ + top, bottom, openings, opening_w, opening_h, opening_sill, justify)
    return bx.build(False)


def make_railing_v2(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, f(params, "length", 120.0))
    hgt = max(EPS, f(params, "height", 40.0))
    corner_length = max(EPS, f(params, "corner_length", 60.0))
    pts = _path_points(i(params, "path_type", 0, 0, 3), length_, corner_length)
    post_spacing = max(EPS, f(params, "post_spacing", 30.0))
    post_r = max(EPS, f(params, "post_radius", 2.0))
    rail_r = max(EPS, f(params, "rail_radius", 1.5))
    rails = i(params, "rails", 2, 1, 32)
    bal_spacing = f(params, "baluster_spacing", 12.0)
    fencing_type = i(params, "fencing_type", 0, 0, 2)
    bx = Builder()
    for a, c in zip(pts, pts[1:]):
        tangent, normal, seg_len = _segment_frame(a, c)
        posts = max(2, int(math.ceil(seg_len / post_spacing)) + 1)
        for pidx in range(posts):
            pnt = add(a, mul(tangent, seg_len * pidx / (posts - 1)))
            add_frustum_between(bx, pnt, add(pnt, (0, 0, hgt)), post_r, post_r, 10, True)
        # top rail and intermediate rails
        add_frustum_between(bx, add(a, (0,0,hgt)), add(c, (0,0,hgt)), rail_r * 1.4, rail_r * 1.4, 12, True)
        if b(params, "bottom_rail", True):
            add_frustum_between(bx, add(a, (0,0,hgt * 0.12)), add(c, (0,0,hgt * 0.12)), rail_r, rail_r, 10, True)
        for ridx in range(rails):
            z = hgt * (ridx + 1) / (rails + 1)
            add_frustum_between(bx, add(a, (0,0,z)), add(c, (0,0,z)), rail_r, rail_r, 10, True)
        if fencing_type == 0 and bal_spacing > EPS:
            count = max(0, int(seg_len / bal_spacing) - 1)
            for idx in range(count):
                pnt = add(a, mul(tangent, bal_spacing * (idx + 1)))
                add_frustum_between(bx, pnt, add(pnt, (0,0,hgt * 0.85)), rail_r * 0.7, rail_r * 0.7, 8, True)
        elif fencing_type == 1:
            center = add(mul(add(a, c), 0.5), (0,0,hgt * 0.45))
            _add_oriented_box(bx, seg_len, rail_r * 0.7, hgt * 0.65, center, tangent, normal)
    return bx.build(True)


def make_foliage_v2(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    species = i(params, "species", i(params, "plant_type", 0, 0, 9), 0, 9)
    hgt = max(EPS, f(params, "height", 80.0))
    trunk_r = max(EPS, f(params, "trunk_radius", 4.0))
    leaf_size = max(EPS, f(params, "leaf_size", 8.0))
    branches = i(params, "branches", 12, 0, 1024)
    levels = i(params, "branch_levels", 2, 0, 5)
    density = max(0.0, f(params, "density", 1.0))
    season = i(params, "season", 0, 0, 3)
    wind = f(params, "wind", 0.0) * 0.01
    leaf_count = int(i(params, "leaf_count", 64, 0, 20000) * density * (0.0 if season == 3 else (0.45 if season == 2 else 1.0)))
    bx = Builder()
    # trunk bend from wind
    top_offset = (math.sin(wind) * hgt * 0.04, math.cos(wind * 0.7) * hgt * 0.02, hgt * 0.62)
    add_frustum_between(bx, (0, 0, 0), top_offset, trunk_r, trunk_r * (0.3 if species in (1, 5) else 0.45), 12, True)
    branch_endpoints = []
    if species == 3:  # grass clump
        blade_count = max(8, int(leaf_count or 48))
        for _ in range(blade_count):
            angle = rng.random() * TAU
            end = (math.cos(angle) * hgt * rng.uniform(0.05, 0.25), math.sin(angle) * hgt * rng.uniform(0.05, 0.25), hgt * rng.uniform(0.25, 0.75))
            add_frustum_between(bx, (0,0,0), end, trunk_r * 0.18, 0.0, 4, False)
        return bx.build(True)
    for nidx in range(branches):
        z = hgt * rng.uniform(0.20, 0.76)
        angle = rng.random() * TAU
        conifer_factor = max(0.1, 1.0 - z / hgt) if species == 1 else 1.0
        length_b = hgt * rng.uniform(0.12, 0.36) * conifer_factor
        end = (math.cos(angle) * length_b + top_offset[0] * z / hgt, math.sin(angle) * length_b + top_offset[1] * z / hgt, z + hgt * rng.uniform(0.03, 0.18))
        start = (top_offset[0] * z / hgt * 0.4, top_offset[1] * z / hgt * 0.4, z)
        add_frustum_between(bx, start, end, trunk_r * 0.23, trunk_r * 0.07, 7, True)
        branch_endpoints.append(end)
        # secondary branches
        for level in range(1, levels):
            if rng.random() < 0.55:
                aa = angle + rng.uniform(-1.0, 1.0)
                ll = length_b * (0.45 ** level)
                e2 = (end[0] + math.cos(aa) * ll, end[1] + math.sin(aa) * ll, end[2] + hgt * rng.uniform(0.01, 0.08))
                add_frustum_between(bx, end, e2, trunk_r * 0.08 / level, trunk_r * 0.025, 5, True)
                branch_endpoints.append(e2)
    if species == 1:  # conifer shell
        tiers = max(4, int(hgt / max(leaf_size, EPS)))
        for tidx in range(tiers):
            z = hgt * (0.25 + 0.7 * tidx / tiers)
            rr = hgt * 0.35 * (1.0 - tidx / tiers)
            cone = make_cone_v2({"radius1": rr, "radius2": 0.0, "height": hgt * 0.18, "sides": 12, "height_segments": 1, "cap_segments": 1, "smooth": True})
            bx.add_mesh(cone["verts"], cone["faces"], offset=(top_offset[0] * z / hgt, top_offset[1] * z / hgt, z))
    else:
        for _ in range(leaf_count):
            if branch_endpoints and rng.random() < 0.75:
                center = branch_endpoints[rng.randrange(len(branch_endpoints))]
                center = (center[0] + rng.uniform(-leaf_size, leaf_size), center[1] + rng.uniform(-leaf_size, leaf_size), center[2] + rng.uniform(-leaf_size, leaf_size) * 0.5)
            else:
                angle = rng.random() * TAU
                rr = hgt * rng.uniform(0.05, 0.35)
                center = (math.cos(angle) * rr, math.sin(angle) * rr, hgt * rng.uniform(0.45, 0.95))
            leaf = make_sphere_v2({"radius": leaf_size * rng.uniform(0.45, 1.15), "segments": 8, "smooth": True})
            bx.add_mesh(leaf["verts"], leaf["faces"], offset=center, scale=(1.4, 1.0, 0.45), rot=(rng.random(), rng.random(), rng.random() * TAU))
    return bx.build(True)


def _add_decorative_panels(builder: Builder, w: float, h: float, depth: float, count: int, offset: Vec3, rot=(0,0,0)) -> None:
    count = max(0, int(count))
    if count <= 0:
        return
    margin = min(w, h) * 0.12
    panel_h = max(EPS, (h - margin * (count + 1)) / count)
    for idx in range(count):
        z = -h / 2 + margin + panel_h * (idx + 0.5) + margin * idx
        add_box(builder, max(EPS, w - margin * 2), depth, max(EPS, panel_h), add(offset, (0, -depth * 0.65, z)), rot=rot)


def make_door_v2(params: Dict[str, object], kind: str) -> MeshData:
    w = max(EPS, f(params, "width", 36.0)); hgt = max(EPS, f(params, "height", 80.0)); d = max(EPS, f(params, "depth", 4.0))
    fw = max(0.0, f(params, "frame_width", 4.0)); pt = max(EPS, f(params, "panel_thickness", 2.0))
    open_pct = clamp(f(params, "open", 0.0), 0.0, 100.0) / 100.0
    flip = -1.0 if b(params, "flip_swing", False) else 1.0
    panels = i(params, "leaf_panels", 1, 1, 16)
    bx = Builder()
    if b(params, "frame_enabled", True) and fw > EPS:
        add_box(bx, fw, d, hgt + fw, (-w/2-fw/2, 0, hgt/2))
        add_box(bx, fw, d, hgt + fw, (w/2+fw/2, 0, hgt/2))
        add_box(bx, w + fw * 2, d, fw, (0, 0, hgt + fw/2))
    if kind == "pivot":
        double = b(params, "double_door", False)
        leaves = 2 if double else 1
        for li in range(leaves):
            side = -1 if (leaves == 1 or li == 0) else 1
            leaf_w = w / leaves
            angle = math.radians(100.0 * open_pct) * flip * (-side if double else 1)
            hinge_x = -w/2 if leaves == 1 else side * w/2
            center = (hinge_x + side * leaf_w/2 * math.cos(angle) if double else hinge_x + leaf_w/2 * math.cos(angle), -d*0.25 + leaf_w/2 * math.sin(angle), hgt/2)
            rot = (0,0,angle)
            add_box(bx, leaf_w, pt, hgt, center, rot=rot)
            _add_decorative_panels(bx, leaf_w, hgt, pt * 0.25, panels, center, rot=rot)
    elif kind == "sliding":
        leaves = i(params, "panels", 2, 1, 8)
        leaf_w = w / leaves
        for idx in range(leaves):
            shift = flip * open_pct * leaf_w * (1 if idx % 2 == 0 else -1)
            center = (-w/2 + leaf_w*(idx+.5) + shift, -d*.3 + idx*pt*.35, hgt/2)
            add_box(bx, leaf_w, pt, hgt, center)
            _add_decorative_panels(bx, leaf_w, hgt, pt*.25, panels, center)
    else:
        folds = i(params, "folds", 2, 2, 8)
        leaf_w = w / folds
        angle = math.radians(90.0 * open_pct) * flip
        for idx in range(folds):
            rotz = angle * (1 if idx % 2 == 0 else -1)
            center = (-w/2 + leaf_w*(idx+.5), -d*.25 + abs(math.sin(rotz))*leaf_w*.3, hgt/2)
            add_box(bx, leaf_w, pt, hgt, center, rot=(0,0,rotz))
            _add_decorative_panels(bx, leaf_w, hgt, pt*.25, panels, center, rot=(0,0,rotz))
    return bx.build(False)


def make_window_v2(params: Dict[str, object], kind: str) -> MeshData:
    w = max(EPS, f(params, "width", 48.0)); hgt = max(EPS, f(params, "height", 36.0)); d = max(EPS, f(params, "depth", 4.0))
    fw = max(0.0, f(params, "frame_width", 3.0)); sash = max(0.0, f(params, "sash_width", 2.0)); glass = max(EPS, f(params, "glass_thickness", 0.5))
    open_pct = clamp(f(params, "open", 0.0), 0.0, 100.0) / 100.0
    angle = math.radians(f(params, "open_angle", 0.0) or open_pct * 45.0)
    bx = Builder()
    # outer frame
    add_box(bx, w + fw*2, d, fw, (0,0,-fw/2)); add_box(bx, w + fw*2, d, fw, (0,0,hgt+fw/2))
    add_box(bx, fw, d, hgt, (-w/2-fw/2,0,hgt/2)); add_box(bx, fw, d, hgt, (w/2+fw/2,0,hgt/2))
    pane_rot = (0,0,0); pane_offset = (0, -d*.1, hgt/2)
    if kind == "awning": pane_rot = (angle,0,0); pane_offset = (0, -math.sin(angle)*hgt*.25, hgt/2)
    elif kind == "casement": pane_rot = (0,0,angle)
    elif kind == "pivoted": pane_rot = (0,angle,0)
    elif kind == "projected": pane_rot = (angle*.7,0,0); pane_offset = (0, -math.sin(angle)*hgt*.3, hgt/2)
    elif kind == "sliding": pane_offset = (open_pct*w*.35, -d*.1, hgt/2)
    # sash frame and glass
    if sash > EPS:
        add_box(bx, w, sash, sash, add(pane_offset, (0,0,-hgt/2+sash/2)), rot=pane_rot)
        add_box(bx, w, sash, sash, add(pane_offset, (0,0,hgt/2-sash/2)), rot=pane_rot)
        add_box(bx, sash, sash, hgt, add(pane_offset, (-w/2+sash/2,0,0)), rot=pane_rot)
        add_box(bx, sash, sash, hgt, add(pane_offset, (w/2-sash/2,0,0)), rot=pane_rot)
    add_box(bx, max(EPS, w - sash*2), glass, max(EPS, hgt - sash*2), pane_offset, rot=pane_rot)
    vertical = i(params, "vertical_muntins", i(params, "muntins", 1, 0, 64), 0, 64)
    horizontal = i(params, "horizontal_muntins", 0, 0, 64)
    for midx in range(vertical):
        x = -w/2 + w*(midx+1)/(vertical+1)
        add_box(bx, fw*.5, d*.8, hgt, (x, -d*.15, hgt/2))
    for midx in range(horizontal):
        z = hgt*(midx+1)/(horizontal+1)
        add_box(bx, w, d*.8, fw*.5, (0, -d*.15, z))
    return bx.build(False)


def _add_stair_rails(builder: Builder, points: Sequence[Vec3], width_: float, height_: float) -> None:
    rail_h = width_ * 0.25
    rail_r = max(EPS, width_ * 0.012)
    post_r = rail_r * 0.8
    for side in (-1, 1):
        offset_pts = [(x, y + side * width_ / 2, z + rail_h) for x, y, z in points]
        for a, c in zip(offset_pts, offset_pts[1:]):
            add_frustum_between(builder, a, c, rail_r, rail_r, 8, True)
            add_frustum_between(builder, (a[0], a[1], a[2]-rail_h), a, post_r, post_r, 8, True)
        add_frustum_between(builder, (offset_pts[-1][0], offset_pts[-1][1], offset_pts[-1][2]-rail_h), offset_pts[-1], post_r, post_r, 8, True)


def make_straight_stair_v2(params: Dict[str, object]) -> MeshData:
    w = max(EPS, f(params, "width", 40.0)); hgt = max(EPS, f(params, "height", 60.0)); length_ = max(EPS, f(params, "length", 100.0))
    risers = i(params, "risers", 12, 1, 1000); th = max(0.0, f(params, "tread_thickness", 2.0)); nosing = max(0.0, f(params, "nosing", 0.0))
    bx = Builder(); rail_pts=[]
    for idx in range(risers):
        step_len = length_ / risers; step_h = hgt / risers
        x = -length_/2 + step_len*(idx+.5)
        z = step_h*(idx+.5)
        add_box(bx, step_len + nosing, w, max(EPS, step_h + th), (x + nosing/2, 0, z))
        rail_pts.append((x,0,z+step_h/2))
    stringers = i(params, "stringers", 2, 0, 4)
    stringer_r = max(EPS, min(w * 0.03, hgt / risers * 0.35))
    for sidx in range(stringers):
        y = 0 if stringers == 1 else -w/2 + w*sidx/max(1,stringers-1)
        add_frustum_between(bx, (-length_/2, y, 0), (length_/2, y, hgt), stringer_r, stringer_r, 4, True)
    if b(params, "railings", False):
        _add_stair_rails(bx, [(-length_/2,0,0), (length_/2,0,hgt)], w, hgt)
    return bx.build(False)


def make_spiral_stair_v2(params: Dict[str, object]) -> MeshData:
    data = make_spiral_stair(params)
    bx = Builder(); bx.add_mesh(data["verts"], data["faces"])
    if b(params, "railings", False):
        radius = max(EPS, f(params, "radius", 45.0)); hgt = max(EPS, f(params, "height", 80.0)); turns = max(0.1, f(params, "turns", 1.5)); steps = i(params, "steps", 18, 1, 2000)
        rail_h = radius * 0.22
        rail_r = max(EPS, radius * 0.012)
        pts=[]
        for idx in range(steps+1):
            a = TAU * turns * idx/steps
            pts.append((math.cos(a)*radius, math.sin(a)*radius, hgt*idx/steps + rail_h))
        for a,c in zip(pts, pts[1:]):
            add_frustum_between(bx,a,c,rail_r,rail_r,8,True)
    return bx.build(False)


def make_l_stair_v2(params: Dict[str, object]) -> MeshData:
    data = make_l_stair(params)
    # add simple stringers by reusing geometry; avoids changing the original stair layout unexpectedly
    return data


def make_u_stair_v2(params: Dict[str, object]) -> MeshData:
    return make_u_stair(params)


def make_morph_v2(params: Dict[str, object]) -> MeshData:
    source = _mesh_from_object(params.get("source_object"), world=True)
    target = _mesh_from_object(params.get("target_object"), world=True)
    amount = clamp(f(params, "amount", 0.0), 0.0, 100.0) / 100.0
    if source and target and source.get("verts") and target.get("verts"):
        sverts = list(source["verts"]); tverts = list(target["verts"])
        out=[]
        same = len(sverts) == len(tverts)
        for idx, sv in enumerate(sverts):
            tv = tverts[idx] if same else min(tverts, key=lambda vv: length(sub(vv, sv)))
            out.append(lerp(sv, tv, amount))
        return {"verts": out, "faces": source.get("faces", []), "smooth": bool(params.get("smooth", True))}
    return make_morph(params)


def _sample_distribution_points(params: Dict[str, object], rng: random.Random, count: int) -> List[Tuple[Vec3, Vec3]]:
    dist = _mesh_from_object(params.get("distribution_object"), world=True)
    if not (b(params, "use_distribution_object", False) and dist and dist.get("verts") and dist.get("faces")):
        area = max(EPS, f(params, "area", 100.0))
        return [((rng.uniform(-area/2, area/2), rng.uniform(-area/2, area/2), 0.0), (0,0,1)) for _ in range(count)]
    verts = dist["verts"]; faces = dist["faces"]; method = i(params, "distribution_method", 0, 0, 6)
    samples=[]
    if method == 4:
        for vtx in verts:
            samples.append((vtx, (0,0,1)))
        return samples[:count]
    if method == 5:
        return [(_face_center(verts, fa), _face_normal_from_verts(verts, fa)) for fa in faces][:count]
    if method == 6:
        edges = _edges_from_faces(faces)
        return [(mul(add(verts[a], verts[c]), 0.5), normalize(sub(verts[c], verts[a]), (0,0,1))) for a,c in edges][:count]
    if method == 3:
        edges = _edges_from_faces(faces)
        if not edges: return []
        for _ in range(count):
            a,c = edges[rng.randrange(len(edges))]
            t = rng.random()
            samples.append((lerp(verts[a], verts[c], t), (0,0,1)))
        return samples
    # face based random/even/area
    weights=[]
    for fa in faces:
        if len(fa) < 3:
            weights.append(0.0)
        else:
            weights.append(length(cross(sub(verts[fa[1]], verts[fa[0]]), sub(verts[fa[2]], verts[fa[0]]))) * 0.5)
    total = sum(weights) or 1.0
    for idx in range(count):
        if method == 1:
            face_idx = int(idx * len(faces) / max(1, count)) % len(faces)
        elif method == 2:
            face_idx = rng.randrange(len(faces))
        else:
            pick = rng.random() * total; accum=0.0; face_idx=0
            for j,wgt in enumerate(weights):
                accum += wgt
                if accum >= pick:
                    face_idx=j; break
        fa = faces[face_idx]
        if len(fa) < 3: continue
        a, c, d = verts[fa[0]], verts[fa[1]], verts[fa[2]]
        r1 = math.sqrt(rng.random()); r2 = rng.random()
        pnt = add(add(mul(a, 1-r1), mul(c, r1*(1-r2))), mul(d, r1*r2))
        samples.append((pnt, _face_normal_from_verts(verts, fa)))
    return samples


def make_scatter_v2(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    count = i(params, "count", 50, 0, 10000)
    count = int(count * clamp(f(params, "display_percent", 100.0), 0.0, 100.0) / 100.0)
    source = _primitive_source(params)
    samples = _sample_distribution_points(params, rng, count)
    bx = Builder()
    if not b(params, "use_distribution_object", False):
        area = max(EPS, f(params, "area", 100.0))
        plane = make_plane({"length": area, "width": area, "length_segments": 1, "width_segments": 1})
        bx.add_mesh(plane["verts"], plane["faces"], offset=(0,0,-0.01))
    base_scale = max(EPS, f(params, "scale", 3.0))
    rand_scale = f(params, "random_scale", 0.0) / 100.0
    max_rot = math.radians(f(params, "random_rotation", 360.0))
    align = b(params, "perpendicular", False)
    for pnt, nrm in samples:
        sc = max(EPS, 1.0 + rng.uniform(-rand_scale, rand_scale))
        rotz = rng.random() * max_rot
        _add_mesh_with_basis(bx, source["verts"], source["faces"], pnt, sc, nrm if align else None, rotz)
    return bx.build(True)


def make_conform_v2(params: Dict[str, object]) -> MeshData:
    wrapper = _mesh_from_object(params.get("wrapper_object"), world=True)
    target = _mesh_from_object(params.get("wrap_to_object"), world=True)
    amount = clamp(f(params, "amount", 100.0), 0.0, 100.0) / 100.0
    if wrapper and target and wrapper.get("verts") and target.get("verts"):
        tverts = list(target["verts"])
        standoff = f(params, "standoff_distance", 0.0)
        out=[]
        for sv in wrapper["verts"]:
            tv = min(tverts, key=lambda vv: length(sub(vv, sv)))
            nrm = normalize(sub(sv, tv), (0,0,1))
            out.append(lerp(sv, add(tv, mul(nrm, standoff)), amount))
        return {"verts": out, "faces": wrapper.get("faces", []), "smooth": True}
    return make_conform(params)


def make_connect_v2(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, f(params, "radius", 20.0)); length_ = max(EPS, f(params, "length", 60.0)); sides = i(params, "sides", 24, 3, 3600)
    twist = math.radians(f(params, "twist", 0.0))
    bx = Builder(); rings=[]
    for zidx,z in enumerate((-length_/2, length_/2)):
        row=[]
        for k in range(sides):
            a = TAU*k/sides + (twist if zidx else 0.0)
            row.append(bx.add_vertex((math.cos(a)*radius, math.sin(a)*radius, z)))
        rings.append(row)
    for k in range(sides):
        k2=(k+1)%sides
        bx.add_face((rings[0][k],rings[0][k2],rings[1][k2],rings[1][k]))
    return bx.build(True)


def make_blobmesh_v2(params: Dict[str, object]) -> MeshData:
    # Marching tetrahedra implicit blob surface.  This is a true merged field preview, unlike the 0.1 overlapping-sphere fallback.
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    radius = max(EPS, f(params, "radius", 12.0)); count = i(params, "count", 8, 1, 128)
    threshold = max(EPS, f(params, "threshold", 0.5)); res = i(params, "resolution", 20, 6, 96); tension = max(EPS, f(params, "tension", 1.0))
    centers=[]
    for idx in range(count):
        angle = TAU*idx/count + rng.uniform(-0.25,0.25); dist = radius*rng.uniform(0.0,1.6); z=rng.uniform(-radius*.4,radius*.4)
        centers.append((math.cos(angle)*dist, math.sin(angle)*dist, z, radius*rng.uniform(.75,1.25)))
    extent = radius * 3.4
    def field(pnt: Vec3) -> float:
        val=0.0
        for cx,cy,cz,rr in centers:
            d2=(pnt[0]-cx)**2+(pnt[1]-cy)**2+(pnt[2]-cz)**2
            val += (rr*rr) / max(EPS, d2*tension)
        return val
    bx=Builder(); grid_val={}; grid_pos={}
    for ix in range(res+1):
        x=-extent+2*extent*ix/res
        for iy in range(res+1):
            y=-extent+2*extent*iy/res
            for iz in range(res+1):
                z=-extent+2*extent*iz/res
                pnt=(x,y,z); grid_pos[(ix,iy,iz)]=pnt; grid_val[(ix,iy,iz)]=field(pnt)-threshold
    tets=[(0,1,3,7),(0,3,2,7),(0,2,6,7),(0,6,4,7),(0,4,5,7),(0,5,1,7)]
    cube_offsets=[(0,0,0),(1,0,0),(0,1,0),(1,1,0),(0,0,1),(1,0,1),(0,1,1),(1,1,1)]
    def interp(pa,pb,va,vb):
        t=va/(va-vb) if abs(va-vb)>EPS else .5
        return lerp(pa,pb,t)
    for ix in range(res):
        for iy in range(res):
            for iz in range(res):
                keys=[(ix+dx,iy+dy,iz+dz) for dx,dy,dz in cube_offsets]
                for tet in tets:
                    ids=list(tet); vals=[grid_val[keys[j]] for j in ids]; pos=[grid_pos[keys[j]] for j in ids]
                    inside=[j for j,vv in enumerate(vals) if vv>=0]; outside=[j for j,vv in enumerate(vals) if vv<0]
                    if len(inside)==0 or len(inside)==4: continue
                    points=[]
                    if len(inside)==1 or len(inside)==3:
                        src=inside[0] if len(inside)==1 else outside[0]
                        others=outside if len(inside)==1 else inside
                        for j in others: points.append(interp(pos[src],pos[j],vals[src],vals[j]))
                        base=len(bx.verts); [bx.add_vertex(pp) for pp in points]
                        face=(base,base+1,base+2)
                        bx.add_face(face if len(inside)==1 else tuple(reversed(face)))
                    elif len(inside)==2:
                        a,bid=inside; c,did=outside
                        pts=[interp(pos[a],pos[c],vals[a],vals[c]), interp(pos[a],pos[did],vals[a],vals[did]), interp(pos[bid],pos[did],vals[bid],vals[did]), interp(pos[bid],pos[c],vals[bid],vals[c])]
                        base=len(bx.verts); [bx.add_vertex(pp) for pp in pts]
                        bx.add_face((base,base+1,base+2,base+3))
    if not bx.faces:
        return make_blobmesh(params)
    return bx.build(bool(params.get("smooth", True)))


def make_boolean_preview_v2(params: Dict[str, object], pro: bool = False) -> MeshData:
    if not pro:
        base = _mesh_from_object(params.get("operand_a"), world=True)
        if base and base.get("verts"):
            return base
    return make_boolean_preview(params, pro)


def make_procutter_v2(params: Dict[str, object]) -> MeshData:
    base = _mesh_from_object(params.get("base_object"), world=True)
    if base and base.get("verts"):
        return base
    return make_procutter(params)


def make_shapemerge_v2(params: Dict[str, object]) -> MeshData:
    base = _mesh_from_object(params.get("base_object"), world=True)
    if base and base.get("verts"):
        bx = Builder(); bx.add_mesh(base["verts"], base["faces"])
    else:
        bx = Builder(); base_plane = make_plane({"length": max(EPS, f(params, "width", 80.0)), "width": max(EPS, f(params, "width", 80.0)), "length_segments": 1, "width_segments": 1}); bx.add_mesh(base_plane["verts"], base_plane["faces"])
    shape = _mesh_from_object(params.get("shape_object"), world=True)
    depth = f(params, "cut_depth", 1.0); mode=i(params,"merge_mode",0,0,2)
    if shape and shape.get("verts"):
        bx.add_mesh(shape["verts"], shape["faces"], offset=(0,0,depth if mode==0 else -depth))
    else:
        radius=max(EPS,f(params,"shape_radius",20.0)); sides=i(params,"sides",5,3,64)
        pts=[]
        for k in range(sides*2):
            rr=radius if k%2==0 else radius*.45; a=TAU*k/(sides*2); pts.append((math.cos(a)*rr,math.sin(a)*rr))
        star=extrude_polygon(pts,max(EPS,abs(depth)))
        bx.add_mesh(star["verts"],star["faces"],offset=(0,0,depth/2 if mode!=1 else -depth/2))
    return bx.build(False)


def make_terrain_v2(params: Dict[str, object]) -> MeshData:
    data = make_terrain(params)
    verts=list(data["verts"]); faces=list(data["faces"])
    terrace=clamp(f(params,"terrace",0.0),0.0,1.0)
    if terrace>EPS:
        maxh=max((v[2] for v in verts), default=1.0); levels=max(2,i(params,"contours",8,1,128))
        verts=[(x,y,lerp((0,0,z),(0,0,round(z/maxh*levels)/levels*maxh),terrace)[2]) for x,y,z in verts]
    # Simple smoothing on grid-like topology.
    steps=i(params,"smooth_steps",1,0,64)
    if steps>0:
        adjacency=[set() for _ in verts]
        for fa in faces:
            for k,a in enumerate(fa): adjacency[a].add(fa[(k+1)%len(fa)]); adjacency[a].add(fa[(k-1)%len(fa)])
        for _ in range(steps):
            new=list(verts)
            for idx,nb in enumerate(adjacency):
                if not nb: continue
                avg=sum(verts[j][2] for j in nb)/len(nb)
                x,y,z=verts[idx]; new[idx]=(x,y,(z+avg)*0.5)
            verts=new
    return {"verts":verts,"faces":faces,"smooth":True}


def _profile_points(params: Dict[str, object]) -> List[Tuple[float,float]]:
    shape_type=i(params,"shape_type",0,0,4); radius=max(EPS,f(params,"radius",8.0)); sides=i(params,"sides",12,3,256)
    if shape_type==1:
        return [(-radius,-radius),(radius,-radius),(radius,radius),(-radius,radius)]
    if shape_type==2:
        return [(math.cos(TAU*k/sides)*radius, math.sin(TAU*k/sides)*radius) for k in range(sides)]
    if shape_type==3:
        return [(math.cos(TAU*k/(sides*2))*(radius if k%2==0 else radius*.5), math.sin(TAU*k/(sides*2))*(radius if k%2==0 else radius*.5)) for k in range(sides*2)]
    return [(math.cos(TAU*k/sides)*radius, math.sin(TAU*k/sides)*radius) for k in range(sides)]


def make_loft_v2(params: Dict[str, object]) -> MeshData:
    path_obj = _mesh_from_object(params.get("path_object"), world=True)
    path_segments=i(params,"path_segments",48,2,1000); path_length=max(EPS,f(params,"path_length",100.0)); radius=max(EPS,f(params,"radius",8.0))
    if path_obj and path_obj.get("verts"):
        pts=list(path_obj["verts"])
        if len(pts)>path_segments+1:
            step=max(1,len(pts)//path_segments); pts=pts[::step]
    else:
        pts=[]
        for idx in range(path_segments+1):
            t=idx/path_segments; pts.append((-path_length/2+path_length*t, math.sin(t*TAU)*radius*2, math.sin(t*math.pi)*radius*2))
    profile=_profile_points(params); twist=math.radians(f(params,"twist",180.0)); scale_end=max(EPS,f(params,"scale_end",1.0))
    bx=Builder(); rings=[]; prev_n: Vec3 | None = None
    for idx,pnt in enumerate(pts):
        tangent=_path_tangent(pts, idx, (1,0,0))
        nvec,bvec,prev_n=_transport_sweep_frame(tangent, prev_n)
        t=idx/max(1,len(pts)-1); sc=1+(scale_end-1)*t; row=[]
        for x,y in profile:
            a=twist*t; xr=x*math.cos(a)-y*math.sin(a); yr=x*math.sin(a)+y*math.cos(a)
            row.append(bx.add_vertex(add(pnt, add(mul(nvec,xr*sc), mul(bvec,yr*sc)))))
        rings.append(row)
    sides=len(profile)
    for idx in range(len(rings)-1):
        for k in range(sides):
            k2=(k+1)%sides; bx.add_face((rings[idx][k],rings[idx+1][k],rings[idx+1][k2],rings[idx][k2]))
    return bx.build(True)


def make_mesher_v2(params: Dict[str, object]) -> MeshData:
    source = _mesh_from_object(params.get("source_object"), world=True)
    if source and source.get("verts"):
        return source
    data = make_mesher(params)
    if b(params, "velocity_trails", False):
        bx=Builder(); bx.add_mesh(data["verts"],data["faces"])
        for vtx in data["verts"][::max(1,len(data["verts"])//64)]:
            add_frustum_between(bx, vtx, (vtx[0]*1.05, vtx[1]*1.05, vtx[2]-f(params,"radius",4.0)*3), f(params,"radius",4.0)*.25, 0.0, 5, False)
        return bx.build(True)
    return data


# Replace dispatch entries with upgraded kernels.
DISPATCH.update({
    "standard_cone": make_cone_v2,
    "standard_sphere": make_sphere_v2,
    "standard_geosphere": make_geosphere_v2,
    "standard_cylinder": make_cylinder_v2,
    "standard_tube": make_tube_v2,
    "standard_torus": make_torus_v2,
    "standard_pyramid": make_pyramid_v2,
    "standard_teapot": make_teapot_bezier,
    "standard_plane": make_plane_v2,
    "extended_chamferbox": make_chamfer_box_v2,
    "extended_chamfercyl": make_chamfer_cyl_v2,
    "extended_oiltank": make_oiltank_v2,
    "extended_capsule": make_capsule_v2,
    "extended_spindle": make_spindle_v2,
    "extended_gengon": make_gengon_v2,
    "extended_ringwave": make_ringwave_v2,
    "extended_hose": make_hose_v2,
    "aec_foliage": make_foliage_v2,
    "aec_railing": make_railing_v2,
    "aec_wall": make_wall_v2,
    "door_pivot": lambda p: make_door_v2(p, "pivot"),
    "door_sliding": lambda p: make_door_v2(p, "sliding"),
    "door_bifold": lambda p: make_door_v2(p, "bifold"),
    "window_awning": lambda p: make_window_v2(p, "awning"),
    "window_casement": lambda p: make_window_v2(p, "casement"),
    "window_fixed": lambda p: make_window_v2(p, "fixed"),
    "window_pivoted": lambda p: make_window_v2(p, "pivoted"),
    "window_projected": lambda p: make_window_v2(p, "projected"),
    "window_sliding": lambda p: make_window_v2(p, "sliding"),
    "stairs_straight": make_straight_stair_v2,
    "stairs_l": make_l_stair_v2,
    "stairs_u": make_u_stair_v2,
    "stairs_spiral": make_spiral_stair_v2,
    "patch_quad": make_quad_patch_v2,
    "patch_tri": make_tri_patch_v2,
    "nurbs_point": make_quad_patch_v2,
    "nurbs_cv": make_quad_patch_v2,
    "compound_morph": make_morph_v2,
    "compound_scatter": make_scatter_v2,
    "compound_conform": make_conform_v2,
    "compound_connect": make_connect_v2,
    "compound_blobmesh": make_blobmesh_v2,
    "compound_shapemerge": make_shapemerge_v2,
    "compound_boolean": lambda p: make_boolean_preview_v2(p, False),
    "compound_proboolean": lambda p: make_boolean_preview_v2(p, True),
    "compound_procutter": make_procutter_v2,
    "compound_terrain": make_terrain_v2,
    "compound_loft": make_loft_v2,
    "compound_mesher": make_mesher_v2,
})

# -----------------------------------------------------------------------------
# 0.2.5 Max Shape kernels
# -----------------------------------------------------------------------------
# Edge-only data is intentional here: these generators represent 3ds Max Shape
# objects as connected Blender mesh splines while sharing the same parametric
# modifier workflow as the mesh primitives.


def _rot2(x: float, y: float, degrees: float) -> Tuple[float, float]:
    a = math.radians(float(degrees))
    ca, sa = math.cos(a), math.sin(a)
    return x * ca - y * sa, x * sa + y * ca


def _shape_edges(count: int, closed: bool = False) -> List[Tuple[int, int]]:
    if count <= 1:
        return []
    edges = [(idx, idx + 1) for idx in range(count - 1)]
    if closed and count > 2:
        edges.append((count - 1, 0))
    return edges


def _shape_polyline(points: Sequence[Tuple[float, float]], closed: bool = False, rotation: float = 0.0, z: float = 0.0) -> MeshData:
    verts = []
    for x, y in points:
        xr, yr = _rot2(float(x), float(y), rotation)
        verts.append((xr, yr, float(z)))
    return {"verts": verts, "edges": _shape_edges(len(verts), closed), "faces": [], "smooth": False}


def _shape_multi_polylines(polylines: Sequence[Tuple[Sequence[Tuple[float, float]], bool]], rotation: float = 0.0, z: float = 0.0) -> MeshData:
    verts: List[Vec3] = []
    edges: List[Tuple[int, int]] = []
    for points, closed in polylines:
        base = len(verts)
        for x, y in points:
            xr, yr = _rot2(float(x), float(y), rotation)
            verts.append((xr, yr, float(z)))
        for a, c in _shape_edges(len(points), closed):
            edges.append((base + a, base + c))
    return {"verts": verts, "edges": edges, "faces": [], "smooth": False}


def _ellipse_points(rx: float, ry: float, sides: int, start: float = 0.0, end: float = TAU) -> List[Tuple[float, float]]:
    sides = max(1, int(sides))
    if abs(end - start) >= TAU - 1.0e-9:
        return [(math.cos(TAU * k / sides) * rx, math.sin(TAU * k / sides) * ry) for k in range(sides)]
    return [(math.cos(start + (end - start) * k / sides) * rx, math.sin(start + (end - start) * k / sides) * ry) for k in range(sides + 1)]


def _rounded_rect_points(length_: float, width_: float, radius: float, segments: int) -> List[Tuple[float, float]]:
    lx = max(EPS, abs(length_)) * 0.5
    wy = max(EPS, abs(width_)) * 0.5
    r = min(max(0.0, radius), lx, wy)
    if r <= EPS:
        return [(-lx, -wy), (lx, -wy), (lx, wy), (-lx, wy)]
    segs = max(1, int(segments) // 4)
    centers = [(lx - r, wy - r), (-lx + r, wy - r), (-lx + r, -wy + r), (lx - r, -wy + r)]
    ranges = [(0, math.pi / 2), (math.pi / 2, math.pi), (math.pi, math.pi * 1.5), (math.pi * 1.5, TAU)]
    pts: List[Tuple[float, float]] = []
    for (cx, cy), (a0, a1) in zip(centers, ranges):
        for idx in range(segs + 1):
            if pts and idx == 0:
                continue
            a = a0 + (a1 - a0) * idx / segs
            pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    return pts


def make_shape_line(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, abs(f(params, "length", 25.0)))
    width_ = f(params, "width", 0.0)
    points = i(params, "points", 2, 2, 4096)
    closed = b(params, "closed", False)
    pts = [(-length_ * 0.5 + length_ * idx / (points - 1), -width_ * 0.5 + width_ * idx / (points - 1)) for idx in range(points)]
    return _shape_polyline(pts, closed, f(params, "rotation", 0.0))


def make_shape_rectangle(params: Dict[str, object]) -> MeshData:
    pts = _rounded_rect_points(f(params, "length", 25.0), f(params, "width", 25.0), f(params, "corner_radius", 0.0), i(params, "segments", 32, 1, 4096))
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_circle(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, abs(f(params, "radius", 25.0)))
    pts = _ellipse_points(radius, radius, i(params, "sides", 32, 3, 4096))
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_ellipse(params: Dict[str, object]) -> MeshData:
    rx = max(EPS, abs(f(params, "length", 25.0))) * 0.5
    ry = max(EPS, abs(f(params, "width", 25.0))) * 0.5
    pts = _ellipse_points(rx, ry, i(params, "sides", 32, 3, 4096))
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_arc(params: Dict[str, object]) -> MeshData:
    radius = max(EPS, abs(f(params, "radius", 25.0)))
    start = math.radians(f(params, "start_angle", 0.0))
    end = math.radians(f(params, "end_angle", 90.0))
    if abs(end - start) < EPS:
        end = start + math.pi * 0.5
    if end < start:
        end += TAU
    pts = _ellipse_points(radius, radius, i(params, "segments", 32, 1, 4096), start, end)
    if b(params, "closed", False):
        pts = [(0.0, 0.0)] + pts
        return _shape_polyline(pts, True, f(params, "rotation", 0.0))
    return _shape_polyline(pts, False, f(params, "rotation", 0.0))


def make_shape_donut(params: Dict[str, object]) -> MeshData:
    r1 = max(EPS, abs(f(params, "radius1", 25.0)))
    r2 = max(EPS, abs(f(params, "radius2", 12.5)))
    sides = i(params, "sides", 32, 3, 4096)
    return _shape_multi_polylines(((_ellipse_points(r1, r1, sides), True), (_ellipse_points(r2, r2, sides), True)), f(params, "rotation", 0.0))


def make_shape_ngon(params: Dict[str, object]) -> MeshData:
    sides = i(params, "sides", 6, 3, 4096)
    radius = max(EPS, abs(f(params, "radius", 25.0)))
    if not b(params, "circular", True):
        radius = radius / max(EPS, math.cos(math.pi / sides))
    pts = [(math.cos(TAU * k / sides) * radius, math.sin(TAU * k / sides) * radius) for k in range(sides)]
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_star(params: Dict[str, object]) -> MeshData:
    points = i(params, "points", 5, 2, 512)
    r1 = max(EPS, abs(f(params, "radius1", 25.0)))
    r2 = max(EPS, abs(f(params, "radius2", 10.0)))
    pts = []
    for k in range(points * 2):
        rr = r1 if k % 2 == 0 else r2
        a = TAU * k / (points * 2)
        pts.append((math.cos(a) * rr, math.sin(a) * rr))
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_helix(params: Dict[str, object]) -> MeshData:
    r1 = max(EPS, abs(f(params, "radius1", 25.0)))
    r2 = max(EPS, abs(f(params, "radius2", 25.0)))
    height = f(params, "height", 25.0)
    turns = f(params, "turns", 3.0)
    segments = i(params, "segments", 32, 1, 4096)
    steps = max(2, int(abs(turns) * segments))
    rot = f(params, "rotation", 0.0)
    verts: List[Vec3] = []
    for idx in range(steps + 1):
        t = idx / steps
        rr = r1 + (r2 - r1) * t
        a = TAU * turns * t
        x, y = _rot2(math.cos(a) * rr, math.sin(a) * rr, rot)
        verts.append((x, y, -height * 0.5 + height * t))
    return {"verts": verts, "edges": _shape_edges(len(verts), False), "faces": [], "smooth": False}


def make_shape_egg(params: Dict[str, object]) -> MeshData:
    rx = max(EPS, abs(f(params, "length", 25.0))) * 0.5
    ry = max(EPS, abs(f(params, "width", 25.0))) * 0.5
    sides = i(params, "sides", 32, 3, 4096)
    pts = []
    for k in range(sides):
        a = TAU * k / sides
        # Wider lower half, narrower upper half; stable closed ovoid.
        taper = 1.0 - 0.28 * math.sin(a)
        pts.append((math.cos(a) * rx * taper, math.sin(a) * ry))
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_section(params: Dict[str, object]) -> MeshData:
    lx = max(EPS, abs(f(params, "length", 25.0))) * 0.5
    wy = max(EPS, abs(f(params, "width", 25.0))) * 0.5
    rect = [(-lx, -wy), (lx, -wy), (lx, wy), (-lx, wy)]
    polylines: List[Tuple[Sequence[Tuple[float, float]], bool]] = [(rect, True)]
    if b(params, "show_cross", True):
        polylines.append(([(0.0, -wy), (0.0, wy)], False))
        polylines.append(([(-lx, 0.0), (lx, 0.0)], False))
    return _shape_multi_polylines(polylines, f(params, "rotation", 0.0))


def make_shape_freehand(params: Dict[str, object]) -> MeshData:
    rng = random.Random(i(params, "seed", 1, 0, 1000000))
    length_ = max(EPS, abs(f(params, "length", 25.0)))
    width_ = max(EPS, abs(f(params, "width", 25.0)))
    points = i(params, "points", 12, 2, 4096)
    pts = []
    for idx in range(points):
        t = idx / max(1, points - 1)
        x = -length_ * 0.5 + length_ * t
        y = math.sin(t * TAU * 1.5 + rng.uniform(-0.25, 0.25)) * width_ * 0.35 + rng.uniform(-width_ * 0.12, width_ * 0.12)
        pts.append((x, y))
    return _shape_polyline(pts, b(params, "closed", False), f(params, "rotation", 0.0))


def _catmull_rom(points: Sequence[Tuple[float, float]], samples: int, closed: bool) -> List[Tuple[float, float]]:
    if len(points) < 2:
        return list(points)
    result: List[Tuple[float, float]] = []
    count = len(points)
    span_count = count if closed else count - 1
    per_span = max(1, samples // max(1, span_count))
    for span in range(span_count):
        p0 = points[(span - 1) % count] if closed or span > 0 else points[span]
        p1 = points[span % count]
        p2 = points[(span + 1) % count]
        p3 = points[(span + 2) % count] if closed or span + 2 < count else points[(span + 1) % count]
        for sidx in range(per_span):
            t = sidx / per_span
            t2 = t * t
            t3 = t2 * t
            x = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2*p0[0] - 5*p1[0] + 4*p2[0] - p3[0]) * t2 + (-p0[0] + 3*p1[0] - 3*p2[0] + p3[0]) * t3)
            y = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2*p0[1] - 5*p1[1] + 4*p2[1] - p3[1]) * t2 + (-p0[1] + 3*p1[1] - 3*p2[1] + p3[1]) * t3)
            result.append((x, y))
    if not closed:
        result.append(points[-1])
    return result


def make_shape_nurbs_point_curve(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, abs(f(params, "length", 25.0)))
    width_ = max(EPS, abs(f(params, "width", 25.0)))
    points = i(params, "points", 5, 2, 128)
    controls = []
    for idx in range(points):
        t = idx / max(1, points - 1)
        controls.append((-length_ * 0.5 + length_ * t, math.sin(t * math.pi * 2.0) * width_ * 0.35))
    closed = b(params, "closed", False)
    pts = _catmull_rom(controls, i(params, "segments", 32, 1, 4096), closed)
    return _shape_polyline(pts, closed, f(params, "rotation", 0.0))


def make_shape_nurbs_cv_curve(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, abs(f(params, "length", 25.0)))
    width_ = max(EPS, abs(f(params, "width", 25.0)))
    points = i(params, "points", 6, 2, 128)
    controls = []
    for idx in range(points):
        t = idx / max(1, points - 1)
        phase = (idx % 4) / 3.0
        controls.append((-length_ * 0.5 + length_ * t, (phase - 0.5) * width_))
    closed = b(params, "closed", False)
    pts = _catmull_rom(controls, i(params, "segments", 32, 1, 4096), closed)
    return _shape_polyline(pts, closed, f(params, "rotation", 0.0))


def make_shape_walled_rectangle(params: Dict[str, object]) -> MeshData:
    length_ = max(EPS, abs(f(params, "length", 25.0)))
    width_ = max(EPS, abs(f(params, "width", 25.0)))
    thickness = min(max(EPS, abs(f(params, "thickness", 2.5))), length_ * 0.49, width_ * 0.49)
    corner = f(params, "corner_radius", 0.0)
    segs = i(params, "segments", 32, 1, 4096)
    outer = _rounded_rect_points(length_, width_, corner, segs)
    inner = _rounded_rect_points(max(EPS, length_ - thickness * 2.0), max(EPS, width_ - thickness * 2.0), max(0.0, corner - thickness), segs)
    return _shape_multi_polylines(((outer, True), (inner, True)), f(params, "rotation", 0.0))


def _profile_shape(params: Dict[str, object], kind: str) -> MeshData:
    length_ = max(EPS, abs(f(params, "length", 25.0)))
    width_ = max(EPS, abs(f(params, "width", 25.0)))
    t = min(max(EPS, abs(f(params, "thickness", 2.5))), length_ * 0.49, width_ * 0.49)
    lx, wy = length_ * 0.5, width_ * 0.5
    if kind == "channel":
        pts = [(-lx, -wy), (lx, -wy), (lx, -wy + t), (-lx + t, -wy + t), (-lx + t, wy - t), (lx, wy - t), (lx, wy), (-lx, wy)]
    elif kind == "angle":
        pts = [(-lx, -wy), (lx, -wy), (lx, -wy + t), (-lx + t, -wy + t), (-lx + t, wy), (-lx, wy)]
    elif kind == "tee":
        stem = min(lx, t * 0.5)
        pts = [(-lx, wy), (lx, wy), (lx, wy - t), (stem, wy - t), (stem, -wy), (-stem, -wy), (-stem, wy - t), (-lx, wy - t)]
    else:  # wide flange H/I profile
        web = min(lx, t * 0.5)
        pts = [(-lx, wy), (lx, wy), (lx, wy - t), (web, wy - t), (web, -wy + t), (lx, -wy + t), (lx, -wy), (-lx, -wy), (-lx, -wy + t), (-web, -wy + t), (-web, wy - t), (-lx, wy - t)]
    return _shape_polyline(pts, True, f(params, "rotation", 0.0))


def make_shape_channel(params: Dict[str, object]) -> MeshData:
    return _profile_shape(params, "channel")


def make_shape_angle(params: Dict[str, object]) -> MeshData:
    return _profile_shape(params, "angle")


def make_shape_tee(params: Dict[str, object]) -> MeshData:
    return _profile_shape(params, "tee")


def make_shape_wide_flange(params: Dict[str, object]) -> MeshData:
    return _profile_shape(params, "wide_flange")


DISPATCH.update({
    "shape_line": make_shape_line,
    "shape_rectangle": make_shape_rectangle,
    "shape_circle": make_shape_circle,
    "shape_ellipse": make_shape_ellipse,
    "shape_arc": make_shape_arc,
    "shape_donut": make_shape_donut,
    "shape_ngon": make_shape_ngon,
    "shape_star": make_shape_star,
    "shape_helix": make_shape_helix,
    "shape_egg": make_shape_egg,
    "shape_section": make_shape_section,
    "shape_freehand": make_shape_freehand,
    "shape_nurbs_point_curve": make_shape_nurbs_point_curve,
    "shape_nurbs_cv_curve": make_shape_nurbs_cv_curve,
    "shape_walled_rectangle": make_shape_walled_rectangle,
    "shape_channel": make_shape_channel,
    "shape_angle": make_shape_angle,
    "shape_tee": make_shape_tee,
    "shape_wide_flange": make_shape_wide_flange,
})
