"""Architectural forms from dimensions, joints and hinge axes."""
from math import atan2, ceil, cos, pi, radians, sin, tau
from random import Random
from mathutils import Matrix, Vector
from ..mesh_form import MeshForm, profile_tube, rect_prism

def stick(mesh,a,b,r,sides=8):
    if (Vector(a)-Vector(b)).length > 1e-8:
        mesh.append(profile_tube([a,b],r,sides))

def frame(mesh,left,right,bottom,top,depth,bar,threshold=True):
    if right<=left or top<=bottom:return
    bar=min(bar,(right-left)/2,(top-bottom)/2)
    mesh.add_box(left,left+bar,-depth/2,depth/2,bottom,top)
    mesh.add_box(right-bar,right,-depth/2,depth/2,bottom,top)
    mesh.add_box(left+bar,right-bar,-depth/2,depth/2,top-bar,top)
    if threshold:mesh.add_box(left+bar,right-bar,-depth/2,depth/2,bottom,bottom+bar)

def opening(kind,p):
    out=MeshForm()
    window=kind.startswith('window')
    width,height,depth=p['width'],p['height'],p['depth']
    bar=p['frame_width'] if window or p['frame_enabled'] else 0
    bar=min(bar,width*.24,height*.24)
    if bar:frame(out,-width/2-bar,width/2+bar,-bar if window else -bar/2,height+bar,depth*(1.05 if window else 1),bar,window)
    bottom=0;top=height
    count=p.get('panels',p.get('folds',2 if p.get('double_door') else 1))
    count=max(1,min(int(count),128))
    span=width/count
    raw=p['open'];swing=radians(p.get('open_angle',0) or raw)
    if p.get('flip_swing'):swing=-swing
    for i in range(count):
        panel=MeshForm();left=-width/2+i*span;right=left+span
        if window:
            rail=min(p['sash_width'],span/3,(top-bottom)/3)
            frame(panel,left,right,bottom,top,depth*.72,rail)
            glass=p['glass_thickness']
            panel.add_box(left+rail,right-rail,-glass/2,glass/2,bottom+rail,top-rail)
            vertical=p.get('vertical_muntins',p['muntins']);horizontal=p.get('horizontal_muntins',0)
            for j in range(min(64,vertical)):
                x=left+(j+1)*span/(vertical+1);panel.add_box(x-rail/4,x+rail/4,-depth/5,depth/5,bottom,top)
            for j in range(min(64,horizontal)):
                z=bottom+(j+1)*(top-bottom)/(horizontal+1);panel.add_box(left,right,-depth/5,depth/5,z-rail/4,z+rail/4)
        else:
            thickness=p['panel_thickness'];panel.add_box(left,right,-thickness/2,thickness/2,bottom,top)
            for j in range(min(32,int(p['leaf_panels']))):
                inc=(top-bottom)/max(1,p['leaf_panels']);frame(panel,left+.12*span,right-.12*span,bottom+(j+.12)*inc,bottom+(j+.88)*inc,thickness*1.13,span*.025)
        if kind.endswith('fixed'):out.append(panel);continue
        if kind.endswith('sliding'):
            offset=min(1,abs(raw)/100)*span*(1 if i%2==0 else -1)
            out.append(panel,lambda co:co+Vector((offset,(i-(count-1)/2)*min(depth*.25,depth/max(1,count)),0)))
        else:
            axis='X' if kind.endswith(('awning','projected')) else 'Z'
            pivot=Vector((left if i%2==0 else right,0,top if kind.endswith('awning') else bottom))
            if kind.endswith('pivoted'):pivot.x=(left+right)/2
            rot=Matrix.Rotation(swing*(1 if i%2==0 else -1),3,axis)
            out.append(panel,lambda co: pivot+rot@(co-pivot))
    return out

def route(p):
    length=p['length'];pts=[Vector((-length/2,0,0)),Vector((length/2,0,0))]
    if p['path_type']:
        pts.append(pts[-1]+Vector((0,p['corner_length'],0)))
        if p['path_type']>1:pts.append(pts[-1]-Vector((length,0,0)))
    return zip(pts,pts[1:])

def along_route(kind,p):
    out=MeshForm()
    for a,b in route(p):
        length=(b-a).length;local=MeshForm();h=p['height']
        if kind=='aec_wall':
            z0=p['bottom_offset'];z1=max(z0+.001,h+p['top_offset'])
            w=p['width'];y=-w*p['justify']/2
            count=min(p['openings'],128);span=length/(count+1);holes=min(p['opening_width'],span*.9);cursor=0
            for i in range(1,count+1):
                low=i*span-holes/2;high=low+holes;sill=min(z1,z0+p['opening_sill']);head=min(z1,sill+p['opening_height'])
                local.add_box(cursor,low,y,y+w,z0,z1)
                if sill>z0:local.add_box(low,high,y,y+w,z0,sill)
                if head<z1:local.add_box(low,high,y,y+w,head,z1)
                cursor=high
            local.add_box(cursor,length,y,y+w,z0,z1)
        else:
            for spacing,r in ((p['post_spacing'],p['post_radius']),(p['baluster_spacing'],p['rail_radius']*.6)):
                n=max(1,min(1024,ceil(length/max(.001,spacing))))
                for i in range(n+1):stick(local,(length*i/n,0,0),(length*i/n,0,h),r)
            levels=max(1,min(128,p['rails']))
            for z in ([h*(i+1)/levels for i in range(levels)]+([.12*h] if p['bottom_rail'] else [])):stick(local,(0,0,z),(length,0,z),p['rail_radius'])
        rotation=Matrix.Rotation(atan2(b.y-a.y,b.x-a.x),3,'Z')
        out.append(local,lambda co:a+rotation@co)
    return out

def steps(kind,p):
    out=MeshForm();n=max(1,min(512,p.get('risers',p.get('steps',12))));h=p['height'];w=p.get('width',1)
    if kind=='stairs_spiral':
        r=p['radius'];inner=min(p['inner_radius'],r*.99);angle=tau*p['turns']/n
        for i in range(n):
            polygon=[(rad*cos(a),rad*sin(a)) for rad,a in ((inner,i*angle),(r,i*angle),(r,(i+1)*angle),(inner,(i+1)*angle))]
            out.append(rect_prism(polygon,h/n*.62),lambda co:co+Vector((0,0,i*h/n)))
        if p['center_pole']:stick(out,(0,0,0),(0,0,h),max(.01,inner*.28),16)
        if p['railings']:out.append(profile_tube([(r*cos(i*angle),r*sin(i*angle),h*i/n+w) for i in range(n+1)],w*.06,8))
        return out
    if kind=='stairs_straight':
        length=p['length'];thickness=min(p['tread_thickness'],h/n)
        for i in range(n):
            x=i*length/n;z=(i+1)*h/n;out.add_box(x-p['nosing'],(i+1)*length/n,-w/2,w/2,z-thickness,z)
        for i in range(min(32,p['stringers'])):
            y=w*((i+.5)/p['stringers']-.5);stick(out,(0,y,0),(length,y,h-thickness),max(.03,thickness/2),4)
        if p['railings']:
            for y in (-w/2,w/2):stick(out,(0,y,w*.25),(length,y,h+w*.25),w*.025)
        return out
    split=max(1,n//2);length=p.get('length1',p.get('length',1));other=p.get('length2',length);landing=p['landing']
    for i in range(n):
        z=(i+1)*h/n
        if i<split:out.add_box(i*length/split,(i+1)*length/split,0,w,z-h/n*.62,z)
        else:
            j=i-split;delta=other/max(1,n-split)
            if kind=='stairs_l':out.add_box(length,length+w,w+j*delta,w+(j+1)*delta,z-h/n*.62,z)
            else:out.add_box(length-(j+1)*delta,length-j*delta,w,2*w,z-h/n*.62,z)
    out.add_box(length,length+landing,0,2*w if kind=='stairs_u' else w,(split-.6)*h/n,split*h/n)
    return out

def foliage(p):
    rng=Random(p['seed']);h=p['height'];out=MeshForm();r=p['trunk_radius'];n=max(1,min(256,p['branches']))
    stick(out,(0,0,0),(0,0,h),r,12);ends=[]
    for i in range(n):
        z=h*(.22+.64*i/n);a=i*2.39996;rad=h*(.12+.18*(1-i/n));end=Vector((rad*cos(a),rad*sin(a),z+.12*h))
        stick(out,(0,0,z),end,r*(.55-.3*i/n),6);ends.append(end)
        for j in range(min(5,max(0,p['branch_levels']-1))):
            tip=end+Vector((cos(a+j+.8)*rad*.35,sin(a+j+.8)*rad*.35,h*.07))
            stick(out,end,tip,r*.12,5);ends.append(tip)
    season_density=(1.,1.,.65,.10)[p['season']];habit=(1.,.70,1.17,.82,.55)[p['plant_type']]
    for i in range(min(20000,int(p['leaf_count']*p['density']*season_density))):
        at=rng.choice(ends)+Vector((rng.uniform(-1,1),rng.uniform(-1,1),rng.uniform(-.5,.6)))*h*.06
        a=rng.uniform(0,tau);v=Vector((cos(a),sin(a),.15))*p['leaf_size'];side=Vector((-v.y,v.x,0))*.32
        out.face([at,at+v*.5+side,at+v,at+v*.5-side])
    direction=p['species']*.618;wind=p['wind']*.001
    out.vertices=[(habit*x+cos(direction)*wind*z*z/max(.001,h),habit*y+sin(direction)*wind*z*z/max(.001,h),z) for x,y,z in out.vertices]
    return out

def build(kind,p):
    if kind.startswith(('door_','window_')):return opening(kind,p)
    if kind.startswith('stairs_'):return steps(kind,p)
    return foliage(p) if kind=='aec_foliage' else along_route(kind,p)
