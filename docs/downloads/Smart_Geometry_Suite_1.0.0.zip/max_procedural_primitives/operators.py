# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Operators and Add menu integration."""

from __future__ import annotations

import math

import bpy
from mathutils import Matrix, Vector
from bpy_extras import view3d_utils

from .. import catalog
from .asset_utils import build_asset_library
from .runtime import create_parametric_object, regenerate_object, update_all, write_values, begin_interactive_drag, end_interactive_drag, is_owned_parametric_object
from .specs import CATEGORIES, GENERATOR_SPECS, localized, lang_code, specs_by_category


def _t(en: str, ja: str) -> str:
    return ja if lang_code() == "ja" else en




def _safe_float(value, default=0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _safe_param_default(spec, pid: str, default=0.0):
    for param in spec.get("params", []):
        if param.get("id") == pid:
            return param.get("default", default)
    return default


def _has_param(spec, pid: str) -> bool:
    return any(param.get("id") == pid for param in spec.get("params", []))


# Parameters controlled by the 3ds Max style viewport-drag workflow.
# At the first click they are initialized to their minimum construction value,
# so not-yet-measured dimensions do not appear as large default shapes.
# Non-drag parameters such as segment counts, smoothing and mapping options are
# intentionally excluded and keep their current defaults.
_DRAG_CONTROL_PARAM_IDS = frozenset({
    "length", "width", "height", "depth", "length1", "length2",
    "corner_length", "size_a", "size_b", "area",
    "radius", "radius1", "radius2", "outer_radius", "inner_radius",
    "target_radius", "shape_radius", "base_size", "size", "cutter_radius",
    "tube_radius", "diameter", "spread", "scale", "path_length",
    "cut_depth", "offset", "gap", "thickness", "opening",
    "post_spacing", "baluster_spacing", "leaf_size", "trunk_radius",
    "amplitude", "curvature", "cap_height", "fillet", "bevel",
    "bevel_depth", "frame_width", "panel_thickness", "sash_width",
    "glass_thickness", "tread_thickness", "nosing", "landing", "extrude",
})


def _param_by_id(spec, pid: str):
    for param in spec.get("params", []):
        if str(param.get("id") or "") == str(pid):
            return param
    return None


def _drag_min_value_for_param(param, fallback=0.0):
    """Return the minimum safe starting value for a drag-controlled parameter."""
    if not param:
        return fallback
    typ = str(param.get("type") or "FLOAT")
    if typ not in {"FLOAT", "INT"}:
        return None
    raw_min = param.get("min")
    try:
        value = float(raw_min if raw_min is not None else 0.0)
    except Exception:
        try:
            value = float(param.get("default", fallback))
        except Exception:
            value = float(fallback)
    # Some dimensions allow negative values for post-edit direction flips.
    # Before the user has supplied a drag distance, the practical minimum is zero
    # rather than a huge negative value.
    if value < 0.0:
        value = 0.0
    if typ == "INT":
        return int(round(value))
    return float(value)


def _drag_initial_values(spec) -> dict:
    values = {}
    for param in spec.get("params", []):
        pid = str(param.get("id") or "")
        if pid not in _DRAG_CONTROL_PARAM_IDS:
            continue
        value = _drag_min_value_for_param(param)
        if value is not None:
            values[pid] = value
    return values


def _drag_min_for(spec, pid: str, fallback=0.0):
    value = _drag_min_value_for_param(_param_by_id(spec, pid), fallback=fallback)
    return fallback if value is None else value



def _construction_plane_axes(context):
    """Return 3ds Max style construction-plane axes and origin.

    3ds Max creates primitives on the active construction grid, not on the 3D
    cursor.  In perspective/camera view this is the home-grid XY plane.  In
    orthographic Top/Front/Left style views it is the visible viewport grid
    plane: XY, XZ or YZ through the world origin.
    """
    origin = Vector((0.0, 0.0, 0.0))
    view_dir = Vector((0.0, 0.0, -1.0))
    view_perspective = "PERSP"
    try:
        rv3d = getattr(getattr(context, "space_data", None), "region_3d", None)
        if rv3d is not None:
            view_perspective = str(getattr(rv3d, "view_perspective", "PERSP") or "PERSP")
            view_dir = rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))
    except Exception:
        pass
    if view_perspective in {"PERSP", "CAMERA"}:
        return origin, Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))
    ax, ay, az = abs(view_dir.x), abs(view_dir.y), abs(view_dir.z)
    if az >= ax and az >= ay:
        return origin, Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))
    if ay >= ax and ay >= az:
        return origin, Vector((1.0, 0.0, 0.0)), Vector((0.0, 0.0, 1.0)), Vector((0.0, 1.0, 0.0))
    return origin, Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0)), Vector((1.0, 0.0, 0.0))


def _window_region_and_rv3d(context):
    """Return the actual 3D View WINDOW region and RegionView3D.

    When the drag operator is launched from the N-panel, context.region is the
    UI sidebar, not the 3D viewport window.  Using that sidebar region makes
    region_2d_to_* return an almost constant point, so drag dimensions appear
    locked at the minimum.  Store and reuse the WINDOW region instead.
    """
    area = getattr(context, "area", None)
    region = None
    try:
        for item in getattr(area, "regions", []):
            if getattr(item, "type", None) == "WINDOW":
                region = item
                break
    except Exception:
        region = None
    if region is None:
        region = getattr(context, "region", None)
    rv3d = getattr(getattr(context, "space_data", None), "region_3d", None)
    return region, rv3d


def _event_region_coord(event, region):
    # In modal events Blender normally reports mouse_region_* in the active
    # VIEW_3D WINDOW region.  Prefer those stable region coordinates.  Only
    # fall back to absolute window coordinates for events launched from another
    # region such as the N-panel.  This prevents intermittent projection jumps
    # that made the preview object flicker during drag creation.
    try:
        rx = float(getattr(event, "mouse_region_x"))
        ry = float(getattr(event, "mouse_region_y"))
        if region is None:
            return (rx, ry)
        rw = float(getattr(region, "width", 0.0))
        rh = float(getattr(region, "height", 0.0))
        if 0.0 <= rx < rw and 0.0 <= ry < rh:
            return (rx, ry)
    except Exception:
        pass
    if region is not None:
        try:
            mx = float(getattr(event, "mouse_x")) - float(getattr(region, "x", 0.0))
            my = float(getattr(event, "mouse_y")) - float(getattr(region, "y", 0.0))
            return (mx, my)
        except Exception:
            pass
    try:
        return (float(getattr(event, "mouse_region_x", 0.0)), float(getattr(event, "mouse_region_y", 0.0)))
    except Exception:
        return (0.0, 0.0)


def _event_is_inside_window_region(context, event, region) -> bool:
    """Return True when the mouse event is inside the 3D View WINDOW region."""
    if region is None:
        return True
    try:
        x, y = _event_region_coord(event, region)
        return 0.0 <= x < float(getattr(region, "width", 0.0)) and 0.0 <= y < float(getattr(region, "height", 0.0))
    except Exception:
        return True


def _event_to_construction_point(context, event, origin, normal, region=None, rv3d=None):
    if region is None or rv3d is None:
        auto_region, auto_rv3d = _window_region_and_rv3d(context)
        region = region or auto_region
        rv3d = rv3d or auto_rv3d
    if region is None or rv3d is None:
        return Vector(origin)
    coord = _event_region_coord(event, region)
    try:
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        ray_direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    except Exception:
        return Vector(origin)
    normal = Vector(normal).normalized()
    denom = float(ray_direction.dot(normal))
    if abs(denom) < 1.0e-8:
        try:
            return view3d_utils.region_2d_to_location_3d(region, rv3d, coord, Vector(origin))
        except Exception:
            return Vector(origin)
    t = float((Vector(origin) - ray_origin).dot(normal)) / denom
    if not math.isfinite(t):
        return Vector(origin)
    # Reject extremely distant intersections caused by near-parallel rays.
    # Keeping the last valid preview point avoids visible jumping/flicker.
    if abs(t) > 1.0e6:
        return Vector(origin)
    point = ray_origin + ray_direction * t
    if not all(math.isfinite(float(v)) for v in point):
        return Vector(origin)
    return point


def _positive(value, fallback=0.001):
    try:
        value = abs(float(value))
    except Exception:
        value = float(fallback)
    return max(value, float(fallback))


def _drag_height_from_pixels(base_size, dy_pixels):
    base = max(float(base_size), 0.001)
    return max(0.001, abs(float(dy_pixels)) * base / 120.0)


def _set_object_axes(obj, u_axis: Vector, v_axis: Vector, n_axis: Vector):
    try:
        mat = Matrix(((u_axis.x, v_axis.x, n_axis.x), (u_axis.y, v_axis.y, n_axis.y), (u_axis.z, v_axis.z, n_axis.z)))
        obj.rotation_euler = mat.to_euler()
    except Exception:
        pass


def _is_rectangular_footprint(spec) -> bool:
    return any(_has_param(spec, pid) for pid in ("length", "width", "depth", "length1", "length2", "size_a", "size_b", "area"))


def _apply_drag_values(obj, generator_id: str, spec, start: Vector, current: Vector, *, stage: str, height_pixels: float = 0.0, axes=None):
    if axes is None:
        _, u_axis, v_axis, n_axis = Vector((0, 0, 0)), Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))
    else:
        u_axis, v_axis, n_axis = axes
    u_axis = Vector(u_axis).normalized()
    v_axis = Vector(v_axis).normalized()
    n_axis = Vector(n_axis).normalized()
    delta = Vector(current) - Vector(start)
    du = float(delta.dot(u_axis))
    dv = float(delta.dot(v_axis))
    length = _positive(du)
    width = _positive(dv)
    dist = max(math.sqrt(du * du + dv * dv), 0.001)
    maxdim = max(length, width, dist, 0.001)
    min_dim = max(min(length, width), 0.001)
    values = {}
    rectangular = _is_rectangular_footprint(spec)
    if rectangular:
        if _has_param(spec, "length"):
            values["length"] = length
        if _has_param(spec, "width"):
            values["width"] = width
        if _has_param(spec, "depth"):
            values["depth"] = width
        if _has_param(spec, "length1"):
            values["length1"] = length
        if _has_param(spec, "length2"):
            values["length2"] = width
        if _has_param(spec, "corner_length"):
            values["corner_length"] = width
        if _has_param(spec, "size_a"):
            values["size_a"] = length
        if _has_param(spec, "size_b"):
            values["size_b"] = width
        if _has_param(spec, "area"):
            values["area"] = max(0.001, length * width)
        base_location = Vector(start) + u_axis * (du * 0.5) + v_axis * (dv * 0.5)
    else:
        base_location = Vector(start)
    radius_ids = ("radius", "radius1", "outer_radius", "target_radius", "shape_radius", "base_size", "size", "cutter_radius")
    for pid in radius_ids:
        if _has_param(spec, pid):
            values[pid] = dist
    if _has_param(spec, "radius2"):
        if generator_id == "standard_tube":
            values["radius2"] = max(0.001, dist * 0.78)
        elif generator_id == "standard_torus":
            values["radius2"] = max(0.001, dist * 0.22)
        elif generator_id == "standard_cone":
            values["radius2"] = max(0.0, _safe_float(_safe_param_default(spec, "radius2", 0.0), 0.0))
        else:
            values["radius2"] = max(0.001, dist * 0.5)
    if _has_param(spec, "tube_radius"):
        values["tube_radius"] = max(0.001, dist * 0.12)
    if _has_param(spec, "inner_radius"):
        values["inner_radius"] = max(0.001, dist * 0.35)
    if _has_param(spec, "diameter"):
        values["diameter"] = max(0.001, dist * 2.0)
    if _has_param(spec, "spread"):
        values["spread"] = maxdim
    if _has_param(spec, "scale"):
        values["scale"] = max(0.001, maxdim * 0.1)
    if _has_param(spec, "path_length"):
        values["path_length"] = maxdim
    if _has_param(spec, "cut_depth"):
        values["cut_depth"] = max(0.001, maxdim * 0.05)
    if _has_param(spec, "offset"):
        values["offset"] = max(0.001, maxdim * 0.35)
    if _has_param(spec, "gap"):
        values["gap"] = max(0.001, maxdim * 0.025)
    if _has_param(spec, "thickness"):
        values["thickness"] = max(0.001, min_dim * 0.2)
    if _has_param(spec, "opening"):
        values["opening"] = max(0.001, min_dim * 0.5)
    if _has_param(spec, "post_spacing"):
        values["post_spacing"] = max(0.001, maxdim * 0.25)
    if _has_param(spec, "baluster_spacing"):
        values["baluster_spacing"] = max(0.001, maxdim * 0.1)
    if _has_param(spec, "leaf_size"):
        values["leaf_size"] = max(0.001, dist * 0.1)
    if _has_param(spec, "trunk_radius"):
        values["trunk_radius"] = max(0.001, dist * 0.05)
    if _has_param(spec, "amplitude"):
        values["amplitude"] = max(0.0, maxdim * 0.05)
    height_value = None
    if _has_param(spec, "height"):
        if stage == "height":
            height_value = _drag_height_from_pixels(maxdim, height_pixels)
        else:
            height_value = _safe_float(_drag_min_for(spec, "height", 0.0), 0.0)
        values["height"] = height_value
    if _has_param(spec, "curvature"):
        if stage == "height":
            values["curvature"] = _drag_height_from_pixels(maxdim, height_pixels) * 0.25
        else:
            values["curvature"] = _safe_float(_drag_min_for(spec, "curvature", 0.0), 0.0)
    if _has_param(spec, "cap_height"):
        if stage == "height":
            values["cap_height"] = max(0.001, _safe_float(height_value if height_value is not None else maxdim, maxdim) * 0.2)
        else:
            values["cap_height"] = _safe_float(_drag_min_for(spec, "cap_height", 0.0), 0.0)
    if _has_param(spec, "fillet"):
        values["fillet"] = max(0.0, min(maxdim * 0.05, min_dim * 0.25))
    if _has_param(spec, "bevel"):
        values["bevel"] = max(0.0, maxdim * 0.02)
    if _has_param(spec, "bevel_depth"):
        values["bevel_depth"] = max(0.0, maxdim * 0.02)
    if _has_param(spec, "frame_width"):
        values["frame_width"] = max(0.001, maxdim * 0.06)
    if _has_param(spec, "panel_thickness"):
        values["panel_thickness"] = max(0.001, maxdim * 0.03)
    if _has_param(spec, "sash_width"):
        values["sash_width"] = max(0.001, maxdim * 0.04)
    if _has_param(spec, "glass_thickness"):
        values["glass_thickness"] = max(0.001, maxdim * 0.01)
    if _has_param(spec, "tread_thickness"):
        values["tread_thickness"] = max(0.001, maxdim * 0.02)
    if _has_param(spec, "nosing"):
        values["nosing"] = max(0.0, maxdim * 0.015)
    if _has_param(spec, "landing"):
        values["landing"] = max(0.001, width)
    if _has_param(spec, "extrude"):
        values["extrude"] = max(0.001, maxdim * 0.1)
    _set_object_axes(obj, u_axis, v_axis, n_axis)
    loc = Vector(base_location)
    if height_value is not None:
        loc = loc + n_axis * (float(height_value) * 0.5)
    obj.location = loc
    write_values(obj, values, regenerate=True)
    return values


def _needs_height_stage(spec) -> bool:
    return _has_param(spec, "height") or _has_param(spec, "curvature")


class JELMAX_OT_add_generator(bpy.types.Operator):
    bl_idname = "jel_max.add_generator"
    bl_label = "Add Max Primitive"
    bl_description = "Creates a parametric object with its controls exposed on a Geometry Nodes modifier. The object remains editable through the modifier properties."
    bl_options = {"UNDO"}

    generator_id: bpy.props.StringProperty(
        name="Generator ID",
        description="Internal identifier of the procedural primitive generator to create.",
        default="standard_box",
    )

    def execute(self, context):
        if self.generator_id not in GENERATOR_SPECS:
            self.report({"ERROR"}, _t("Unknown generator", "不明なジェネレーターです"))
            return {"CANCELLED"}
        obj = create_parametric_object(self.generator_id, link=True)
        try:
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            context.view_layer.objects.active = obj
        except Exception:
            pass
        return {"FINISHED"}



class JELMAX_OT_draw_generator(bpy.types.Operator):
    bl_idname = "jel_max.draw_generator"
    bl_label = "Drag Max Primitive"
    bl_description = "Creates a Max Primitive by 3ds Max style viewport dragging. Click-drag on the construction plane to set the base/radius; primitives with height use a second drag for height. The modifier parameters remain editable after creation."
    bl_options = {"UNDO"}

    generator_id: bpy.props.StringProperty(
        name="Generator ID",
        description="Internal identifier of the procedural primitive generator to create by viewport drag.",
        default="standard_box",
    )

    _obj = None
    _start = None
    _current = None
    _stage = "await"
    _plane_z = 0.0
    _height_start_y = 0.0
    _height_dragging = False
    _origin = None
    _u_axis = None
    _v_axis = None
    _n_axis = None
    _window_region = None
    _rv3d = None
    _last_valid_point = None
    _height_button_down = False
    _height_moved = False
    _sgs_modal_token = None
    _sgs_modal_context = None
    _sgs_draw_handle = None
    _sgs_event_timer = None
    _sgs_drag_active = False
    _sgs_pending_data = None
    _sgs_cleanup_ok = False

    def _project_event_point(self, context, event):
        point = _event_to_construction_point(context, event, self._origin, self._n_axis, self._window_region, self._rv3d)
        try:
            point = Vector(point)
            if self._last_valid_point is not None and (point - Vector(self._origin)).length > 1.0e5:
                return Vector(self._last_valid_point)
            self._last_valid_point = Vector(point)
            return point
        except Exception:
            return Vector(self._last_valid_point) if self._last_valid_point is not None else Vector(self._origin)

    def _end_drag_once(self):
        if not bool(getattr(self, "_sgs_drag_active", False)):
            return True
        try:
            end_interactive_drag()
        except Exception:
            return False
        self._sgs_drag_active = False
        return True

    def _remove_modal_resources(self, context=None):
        ok = True
        handle = getattr(self, "_sgs_draw_handle", None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, "WINDOW")
                self._sgs_draw_handle = None
            except Exception:
                ok = False
        timer = getattr(self, "_sgs_event_timer", None)
        if timer is not None:
            wm = getattr(context, "window_manager", None) or getattr(getattr(self, "_sgs_modal_context", None), "window_manager", None)
            try:
                if wm is None:
                    ok = False
                else:
                    wm.event_timer_remove(timer)
                    self._sgs_event_timer = None
            except Exception:
                ok = False
        return ok

    @staticmethod
    def _remove_generated_object(obj):
        if obj is None:
            return True
        if not is_owned_parametric_object(obj):
            return False
        data = getattr(obj, "data", None)
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            return False
        if data is None:
            return True
        try:
            if int(getattr(data, "users", 0)) != 0:
                return True
        except Exception:
            return False
        try:
            if isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)
            elif isinstance(data, bpy.types.Curve):
                bpy.data.curves.remove(data)
        except Exception:
            return False
        return True

    def _remove_generated_state(self):
        obj = getattr(self, "_obj", None)
        if obj is not None:
            data = getattr(obj, "data", None)
            if not self._remove_generated_object(obj):
                # If the object still exists, retain it for an exact retry.  If it
                # was removed but zero-user data cleanup failed, retain the data.
                try:
                    if bpy.data.objects.get(str(getattr(obj, "name", ""))) is obj:
                        return False
                except Exception:
                    return False
                self._obj = None
                self._sgs_pending_data = data
            else:
                self._obj = None
        data = getattr(self, "_sgs_pending_data", None)
        if data is None:
            return True
        try:
            if int(getattr(data, "users", 0)) != 0:
                return False
            if isinstance(data, bpy.types.Mesh):
                bpy.data.meshes.remove(data)
            elif isinstance(data, bpy.types.Curve):
                bpy.data.curves.remove(data)
            self._sgs_pending_data = None
            return True
        except Exception:
            return False

    def _finish(self, context):
        from .. import ownership
        resources_ok = bool(self._remove_modal_resources(context))
        drag_ok = bool(self._end_drag_once())
        obj = self._obj
        self._sgs_cleanup_ok = resources_ok and drag_ok and not bool(getattr(self, "_sgs_drag_active", False))
        if not self._sgs_cleanup_ok:
            object_ok = bool(self._remove_generated_state())
            self._sgs_cleanup_ok = self._sgs_cleanup_ok and object_ok
            return {"CANCELLED"}
        self._obj = None
        ownership.finish_modal(self)
        self._sgs_modal_token = None
        if obj is not None:
            try:
                bpy.ops.object.select_all(action="DESELECT")
                obj.select_set(True)
                context.view_layer.objects.active = obj
            except Exception:
                pass
        return {"FINISHED"}

    def _cancel(self, context, *, reason="cancelled"):
        del reason
        from .. import ownership
        resources_ok = bool(self._remove_modal_resources(context))
        drag_ok = bool(self._end_drag_once())
        object_ok = bool(self._remove_generated_state())
        self._sgs_cleanup_ok = resources_ok and drag_ok and object_ok and not bool(getattr(self, "_sgs_drag_active", False))
        if self._sgs_cleanup_ok:
            ownership.finish_modal(self)
            self._sgs_modal_token = None
        return {"CANCELLED"}

    def cancel(self, context):
        return self._cancel(context, reason="blender_cancel")

    def execute(self, context):
        # Scripted/non-view execution creates one fully editable primitive.
        if self.generator_id not in GENERATOR_SPECS:
            self.report({"ERROR"}, _t("Unknown generator", "不明なジェネレーターです"))
            return {"CANCELLED"}
        obj = None
        try:
            obj = create_parametric_object(self.generator_id, link=True)
            if obj is None:
                return {"CANCELLED"}
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            context.view_layer.objects.active = obj
        except Exception as exc:
            self._remove_generated_object(obj)
            self.report({"ERROR"}, catalog.failure_text('Primitive creation failed', 'プリミティブ生成に失敗しました', exc))
            return {"CANCELLED"}
        return {"FINISHED"}

    def invoke(self, context, event):
        from .. import ownership
        if self.generator_id not in GENERATOR_SPECS:
            self.report({"ERROR"}, _t("Unknown generator", "不明なジェネレーターです"))
            return {"CANCELLED"}
        if getattr(getattr(context, "area", None), "type", None) != "VIEW_3D":
            return self.execute(context)
        try:
            self._origin, self._u_axis, self._v_axis, self._n_axis = _construction_plane_axes(context)
            self._window_region, self._rv3d = _window_region_and_rv3d(context)
            self._plane_z = float(Vector(self._origin).z)
            self._stage = "await"
            self._obj = None
            self._sgs_pending_data = None
            self._sgs_cleanup_ok = False
            self._last_valid_point = None
            self._height_button_down = False
            self._height_moved = False
            self._sgs_modal_context = context
            begin_interactive_drag()
            self._sgs_drag_active = True
            token = ownership.begin_modal(
                self,
                context,
                lambda reason: (
                    self._cancel(self._sgs_modal_context or bpy.context, reason=reason),
                    bool(getattr(self, "_sgs_cleanup_ok", False)),
                )[1],
            )
            if token is None:
                return self._cancel(context, reason="generation_inactive")
            self._sgs_modal_token = token
            context.window_manager.modal_handler_add(self)
        except Exception as exc:
            self._cancel(context, reason="invoke_exception")
            self.report({"ERROR"}, catalog.failure_text('Viewport drag could not start', 'ビューポートドラッグを開始できませんでした', exc))
            return {"CANCELLED"}
        self.report({"INFO"}, _t("Click-drag in the viewport to create the primitive", "ビューポート上をクリック・ドラッグしてプリミティブを生成します"))
        return {"RUNNING_MODAL"}

    def _modal_impl(self, context, event):
        from .. import ownership
        if not ownership.modal_environment_valid(self._sgs_modal_token, context):
            return self._cancel(context, reason="environment_invalid")
        etype = str(getattr(event, "type", ""))
        value = str(getattr(event, "value", ""))
        spec = GENERATOR_SPECS.get(self.generator_id)
        if etype in {"ESC", "RIGHTMOUSE"}:
            return self._cancel(context, reason="user_cancel")
        if spec is None:
            return self._cancel(context, reason="generator_missing")
        if self._stage == "await":
            if etype == "LEFTMOUSE" and value == "PRESS":
                if not _event_is_inside_window_region(context, event, self._window_region):
                    return {"RUNNING_MODAL"}
                self._start = self._project_event_point(context, event)
                self._current = Vector(self._start)
                self._obj = create_parametric_object(
                    self.generator_id,
                    link=True,
                    location=self._start,
                    initial_values=_drag_initial_values(spec),
                )
                if self._obj is None:
                    return self._cancel(context, reason="object_creation_failed")
                self._stage = "base"
                return {"RUNNING_MODAL"}
            return {"RUNNING_MODAL"}
        if self._stage == "base":
            if etype == "MOUSEMOVE" and self._obj is not None:
                self._current = self._project_event_point(context, event)
                _apply_drag_values(self._obj, self.generator_id, spec, self._start, self._current, stage="base", axes=(self._u_axis, self._v_axis, self._n_axis))
                return {"RUNNING_MODAL"}
            if etype == "LEFTMOUSE" and value == "RELEASE":
                self._current = self._project_event_point(context, event)
                _apply_drag_values(self._obj, self.generator_id, spec, self._start, self._current, stage="base", axes=(self._u_axis, self._v_axis, self._n_axis))
                if _needs_height_stage(spec):
                    self._stage = "height"
                    self._height_start_y = float(getattr(event, "mouse_y", 0.0))
                    self._height_dragging = True
                    self._height_button_down = False
                    self._height_moved = False
                    self.report({"INFO"}, _t("Move or drag to set height, then click or release to finish", "続けて移動またはドラッグして高さを設定し、クリックまたは離して確定します"))
                    return {"RUNNING_MODAL"}
                return self._finish(context)
            return {"RUNNING_MODAL"}
        if self._stage == "height":
            if etype == "LEFTMOUSE" and value == "PRESS":
                if not self._height_moved:
                    self._height_start_y = float(getattr(event, "mouse_y", 0.0))
                self._height_dragging = True
                self._height_button_down = True
                return {"RUNNING_MODAL"}
            if etype == "MOUSEMOVE" and self._obj is not None and self._height_dragging:
                dy = float(getattr(event, "mouse_y", 0.0)) - float(self._height_start_y)
                _apply_drag_values(self._obj, self.generator_id, spec, self._start, self._current, stage="height", height_pixels=dy, axes=(self._u_axis, self._v_axis, self._n_axis))
                self._height_moved = True
                return {"RUNNING_MODAL"}
            if etype == "LEFTMOUSE" and value == "RELEASE":
                dy = float(getattr(event, "mouse_y", 0.0)) - float(self._height_start_y)
                if self._obj is not None and self._height_dragging:
                    _apply_drag_values(self._obj, self.generator_id, spec, self._start, self._current, stage="height", height_pixels=dy, axes=(self._u_axis, self._v_axis, self._n_axis))
                self._height_dragging = False
                self._height_button_down = False
                return self._finish(context)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        try:
            return self._modal_impl(context, event)
        except Exception as exc:
            self._cancel(context, reason="modal_exception")
            self.report({"ERROR"}, catalog.failure_text('Viewport drag cancelled safely', 'ビューポートドラッグを安全に中止しました', exc))
            return {"CANCELLED"}


class JELMAX_OT_install_assets(bpy.types.Operator):
    bl_idname = "jel_max.install_assets"
    bl_label = "Install Max Primitive Assets"
    bl_description = "Builds all procedural primitive assets, writes them to the user asset library, and registers the library in Blender preferences. Run again to refresh the asset file after updating the add-on."
    bl_options = set()

    def execute(self, context):
        try:
            path, count, registered = build_asset_library(save_preferences=True)
        except Exception as exc:
            self.report({"ERROR"}, catalog.failure_text('Asset install failed', 'アセットのインストールに失敗しました', exc))
            return {"CANCELLED"}
        status = _t("registered", "登録済み") if registered else _t("written", "書き込み済み")
        asset_label = _t("assets", "アセット")
        self.report({"INFO"}, f"{count} {asset_label} {status}: {path}")
        return {"FINISHED"}


class JELMAX_OT_update_selected(bpy.types.Operator):
    bl_idname = "jel_max.update_selected"
    bl_label = "Update Selected Max Primitive"
    bl_description = "Forces regeneration of the selected Max Primitives object from the current Geometry Nodes modifier values. Use this only if automatic update did not run after a property change."
    bl_options = {"UNDO"}

    def execute(self, context):
        obj = context.object
        if not obj or obj.get("jel_max_generator_id") not in GENERATOR_SPECS:
            self.report({"WARNING"}, _t("No Max Primitive object selected", "Max Primitives オブジェクトが選択されていません"))
            return {"CANCELLED"}
        regenerate_object(obj, force=True)
        self.report({"INFO"}, _t("Updated", "更新しました"))
        return {"FINISHED"}


class JELMAX_OT_update_all(bpy.types.Operator):
    bl_idname = "jel_max.update_all"
    bl_label = "Update All Max Primitives"
    bl_description = "Forces regeneration of every Max Primitives object in the current file. This is useful after loading a file or changing animated modifier values."
    bl_options = {"UNDO"}

    def execute(self, context):
        count = update_all(force=True)
        self.report({"INFO"}, _t(f"Updated {count} objects", f"{count} 個のオブジェクトを更新しました"))
        return {"FINISHED"}


def draw_category(layout, category_id: str):
    lang = lang_code()
    by_category = specs_by_category()
    for generator_id, spec in by_category.get(category_id, []):
        op = layout.operator(JELMAX_OT_draw_generator.bl_idname, text=localized(spec["name"], lang), icon="MOUSE_LMB_DRAG")
        op.generator_id = generator_id


def make_category_menu(category_id: str):
    class _CategoryMenu(bpy.types.Menu):
        bl_idname = f"JELMAX_MT_{category_id}"
        bl_label = CATEGORIES[category_id]["en"]
        bl_description = CATEGORIES[category_id]["en"]

        def draw(self, context):
            draw_category(self.layout, category_id)

    _CategoryMenu.__name__ = f"JELMAX_MT_{category_id}"
    return _CategoryMenu


CATEGORY_MENU_CLASSES = [make_category_menu(cat_id) for cat_id in CATEGORIES]
CATEGORY_MENU_BY_ID = {cls.bl_idname.replace("JELMAX_MT_", ""): cls for cls in CATEGORY_MENU_CLASSES}


class JELMAX_MT_add_root(bpy.types.Menu):
    bl_idname = "JELMAX_MT_add_root"
    bl_label = "Max Primitives"
    bl_description = "Max Primitive objects created as Blender Geometry Nodes modifier assets."

    def draw(self, context):
        lang = lang_code()
        layout = self.layout
        for category_id, category in CATEGORIES.items():
            cls = CATEGORY_MENU_BY_ID.get(category_id)
            if cls:
                layout.menu(cls.bl_idname, text=localized(category, lang))
        layout.separator()
        layout.operator(JELMAX_OT_install_assets.bl_idname, text=localized({"en": "Install Max Primitive Assets", "ja": "Max Primitives アセットをインストール"}, lang))
        layout.operator(JELMAX_OT_update_selected.bl_idname, text=localized({"en": "Update Selected Max Primitive", "ja": "選択中の Max Primitives オブジェクトを更新"}, lang))
        layout.operator(JELMAX_OT_update_all.bl_idname, text=localized({"en": "Update All Max Primitives", "ja": "全ての Max Primitives オブジェクトを更新"}, lang))


def add_menu_draw(self, context):
    self.layout.separator()
    self.layout.menu(JELMAX_MT_add_root.bl_idname, text=bpy.app.translations.pgettext_iface("Max Primitives"))


CLASSES = [
    JELMAX_OT_add_generator,
    JELMAX_OT_draw_generator,
    JELMAX_OT_install_assets,
    JELMAX_OT_update_selected,
    JELMAX_OT_update_all,
    *CATEGORY_MENU_CLASSES,
    JELMAX_MT_add_root,
]

_ADD_MENU_CALLBACK_KEY = 'SMART_GEOMETRY_SUITE_MAX_PRIMITIVES_ADD_MENU_CALLBACK'
_REGISTERED = False


def _jelmax_class_owned_by_suite(cls) -> bool:
    """Compatibility query using only the exact current-generation token."""
    try:
        from .. import ownership
        ledger = ownership.shared_ledger()
        return ownership.ledger_is_exact(ledger) and ownership.class_identity_matches(cls, ledger)
    except Exception:
        return False


def _jelmax_registered_rna_class(cls):
    """Do not discover or adopt RNA through bpy.types name lookup."""
    del cls
    return None


def _prepare_operator_options(cls) -> None:
    """Retain each operator's explicit mutation-based Undo classification."""
    del cls


def _jelmax_safe_register_class(cls) -> bool:
    """Legacy compatibility no-op; bridge RNA is centrally transaction-owned."""
    del cls
    return False


def _menu_callback_candidates():
    """No runtime callback discovery; the central ledger stores exact identities."""
    return ()


def _remove_add_menu_entry() -> None:
    """Compatibility no-op; only the central ledger removes its exact menu lease."""
    return None


def _remember_add_menu_callback() -> None:
    """Compatibility no-op; no alternate driver_namespace token is published."""
    return None


def _unregister_owned_class(cls) -> None:
    """Legacy compatibility no-op; exact generation teardown owns bridge RNA."""
    del cls
    return None

def register() -> None:
    """Compatibility no-op; Smart Geometry registers lightweight bridge RNA."""
    global _REGISTERED
    _REGISTERED = True
    return None

def unregister() -> None:
    """Compatibility no-op; the Suite generation transaction owns teardown."""
    global _REGISTERED
    _REGISTERED = False
    return None
