"""Persistent models can be re-evaluated without moving the object or discarding its materials."""
import json
from uuid import uuid4
import bpy
from bpy.app.handlers import persistent
from . import solids, architectural, compounds, curves
from .specs import GENERATOR_SPECS, NAMES
GENERATION=uuid4().hex
_drag=False
_running=False
_attached=False
SOCKET={'FLOAT':'NodeSocketFloat','INT':'NodeSocketInt','BOOL':'NodeSocketBool','STRING':'NodeSocketString','OBJECT':'NodeSocketObject'}

def is_owned_parametric_object(obj):
    return bool(obj and obj.get('jel_max_author')=='JELararagi' and obj.get('jel_max_generator_id') in GENERATOR_SPECS and not obj.library)
def begin_interactive_drag():
    global _drag
    _drag=True
def end_interactive_drag():
    global _drag
    _drag=False
def is_interactive_drag_active():return _drag

def modifier(obj):
    kind=obj.get('jel_max_generator_id')
    exact=next((m for m in obj.modifiers if m.type=='NODES' and m.get('jel_max_generator_id')==kind),None)
    if exact:return exact
    ports=set(decode(obj,'jel_max_socket_map').values())
    if not ports:return None
    # Blender can reconstruct modifier properties from its node interface on file open.
    return next((m for m in obj.modifiers if m.type=='NODES' and m.node_group and m.name.startswith('Max Primitives') and ports.issubset({s.identifier for s in m.node_group.interface.items_tree if s.item_type=='SOCKET' and s.in_out=='INPUT'})),None)
def encode(values):
    return json.dumps({k:v.name if isinstance(v,bpy.types.Object) else v for k,v in values.items()},sort_keys=True)
def decode(obj,key):
    try:return json.loads(obj.get(key,'{}'))
    except (TypeError,ValueError):return {}
def read_values(obj):
    if not is_owned_parametric_object(obj):return {}
    m=modifier(obj);sockets=decode(obj,'jel_max_socket_map');stored=decode(obj,'jel_max_stored_values');result={}
    for spec in GENERATOR_SPECS[obj['jel_max_generator_id']]['params']:
        k=spec['id'];port=sockets.get(k)
        val=m.get(port,stored.get(k,spec['default'])) if m and port else stored.get(k,spec['default'])
        if spec['type']=='OBJECT' and isinstance(val,str):val=bpy.data.objects.get(val)
        result[k]=val
    return result

def new_group(kind):
    grp=next((g for g in bpy.data.node_groups if g.get('jel_max_generator_id')==kind and g.get('sgs_native_contract')==1),None)
    if grp:return grp
    grp=bpy.data.node_groups.new('Max Primitives '+NAMES[kind],'GeometryNodeTree')
    grp['jel_max_generator_id']=kind;grp['sgs_native_contract']=1;grp.is_modifier=True
    for direction in ('INPUT','OUTPUT'):grp.interface.new_socket(name='Geometry',in_out=direction,socket_type='NodeSocketGeometry')
    for p in GENERATOR_SPECS[kind]['params']:
        item=grp.interface.new_socket(name=p['id'].replace('_',' ').title(),in_out='INPUT',socket_type=SOCKET[p['type']])
        if p['type']!='OBJECT':
            if p['type'] in ('FLOAT','INT') and p['min'] is not None:item.min_value=p['min'];item.max_value=p['max']
            item.default_value=p['default']
    a=grp.nodes.new('NodeGroupInput');b=grp.nodes.new('NodeGroupOutput');b.location.x=250;grp.links.new(a.outputs['Geometry'],b.inputs['Geometry'])
    return grp

def mesh_shape(kind,values):
    if kind.startswith('shape_'):shape=curves.outline(kind,values)
    elif kind.startswith(('door_','window_','aec_','stairs_')):shape=architectural.build(kind,values)
    elif kind.startswith('compound_'):shape=compounds.build(kind,values)
    else:shape=solids.build(kind,values)
    centered={'standard_box','standard_cone','standard_cylinder','standard_tube','standard_pyramid','extended_chamferbox','extended_chamfercyl','extended_oiltank','extended_capsule','extended_spindle','extended_l_ext','extended_gengon','extended_c_ext','extended_ringwave','extended_hose','extended_prism','compound_connect','shape_helix'}
    if kind in centered and shape.vertices and not (values.get('start_object') or values.get('end_object')):
        low=min(p[2] for p in shape.vertices);high=max(p[2] for p in shape.vertices);shift=(high+low)*.5
        shape.vertices=[(x,y,z-shift) for x,y,z in shape.vertices]
    return shape

def fill_text(data,p):
    data.body=p['text'];data.size=p['size'];data.extrude=p['extrude'];data.bevel_depth=p['bevel_depth'];data.bevel_resolution=p['bevel_segments'];data.resolution_u=p['resolution']
    data.align_x=('LEFT','CENTER','RIGHT')[min(2,p['align'])];data.space_character=p['tracking'];data.space_line=p['line_spacing'];data.shear=p.get('shear',0);data.offset_x=p.get('offset_x',0);data.offset_y=p.get('offset_y',0)
    for char in data.body_format:
        char.use_bold=p.get('font_style',0) in (1,3);char.use_italic=p.get('font_style',0) in (2,3)

def regenerate_object(obj,force=False):
    global _running
    if _running or not is_owned_parametric_object(obj) or obj.mode!='OBJECT' or not modifier(obj):return False
    p=read_values(obj);stamp=encode(p)
    if not force and obj.get('jel_max_last_hash')==stamp:return False
    _running=True
    try:
        kind=obj['jel_max_generator_id'];data=obj.data
        if data.users>1:data=data.copy();obj.data=data
        if obj.type=='FONT':fill_text(data,p)
        else:
            shape=mesh_shape(kind,p);data.clear_geometry();data.from_pydata(shape.vertices,shape.edges,shape.faces);data.update()
            if p.get('smooth'):
                for face in data.polygons:face.use_smooth=True
            if p.get('map_coords') and data.loops:
                uv=data.uv_layers.new(name='UVMap') if not data.uv_layers else data.uv_layers[0]
                xmin=min(v.co.x for v in data.vertices);xmax=max(v.co.x for v in data.vertices);ymin=min(v.co.y for v in data.vertices);ymax=max(v.co.y for v in data.vertices)
                for l in data.loops:
                    v=data.vertices[l.vertex_index].co;uv.uv[l.index].vector=(v.x,v.y) if p.get('real_world_map_size') else ((v.x-xmin)/max(.0001,xmax-xmin),(v.y-ymin)/max(.0001,ymax-ymin))
            obj['jel_max_mesh_state']=f'{len(data.vertices)}:{len(data.polygons)}'
        obj['jel_max_stored_values']=stamp;obj['jel_max_last_hash']=stamp
        return True
    finally:_running=False
def create_parametric_object(generator_id,*,link=True,name=None,collection=None,location=None,values=None):
    spec=GENERATOR_SPECS[generator_id];label=name or NAMES[generator_id];font=generator_id in ('standard_textplus','shape_text')
    data=bpy.data.curves.new(label,'FONT') if font else bpy.data.meshes.new(label)
    ob=bpy.data.objects.new(label,data)
    try:
        if link:(collection or bpy.context.collection or bpy.context.scene.collection).objects.link(ob)
        ob.location=location if location is not None else bpy.context.scene.cursor.location
        ob['jel_max_generator_id']=generator_id;ob['jel_max_generator_category']=spec['category'];ob['jel_max_author']='JELararagi';ob['smart_geometry_suite_generated']=True
        ob['jelararagi_sgs_owner_suite']='smart_geometry_suite';ob['jelararagi_sgs_owner_revision']='1.0.0';ob['jelararagi_sgs_owner_generation']=GENERATION
        group=new_group(generator_id);mod=ob.modifiers.new('Max Primitives','NODES');mod.node_group=group;mod['jel_max_generator_id']=generator_id
        inputs=[i for i in group.interface.items_tree if i.item_type=='SOCKET' and i.in_out=='INPUT' and i.socket_type!='NodeSocketGeometry'];ob['jel_max_socket_map']=json.dumps({p['id']:s.identifier for p,s in zip(spec['params'],inputs)})
        if values:write_values(ob,values,regenerate=False)
        regenerate_object(ob,True);return ob
    except Exception:
        bpy.data.objects.remove(ob,do_unlink=True)
        if not data.users:(bpy.data.curves if font else bpy.data.meshes).remove(data)
        raise

def write_values(obj,values,*,regenerate=True):
    if not is_owned_parametric_object(obj):return False
    m=modifier(obj);ports=decode(obj,'jel_max_socket_map')
    if not m:return False
    for p in GENERATOR_SPECS[obj['jel_max_generator_id']]['params']:
        k=p['id']
        if k not in values or k not in ports:continue
        v=values[k]
        if p['type'] in ('FLOAT','INT'):v=max(p['min'],min(p['max'],v));v=float(v) if p['type']=='FLOAT' else int(v)
        if p['type']=='OBJECT' and isinstance(v,str):v=bpy.data.objects.get(v)
        m[ports[k]]=v
    obj.update_tag()
    if regenerate:regenerate_object(obj,True)
    return True
def iter_parametric_objects():return (o for o in bpy.data.objects if is_owned_parametric_object(o))
def update_all(force=False):return sum(regenerate_object(o,force) for o in tuple(iter_parametric_objects()))

@persistent
def depsgraph_handler(scene,depsgraph=None):
    if _drag or _running:return
    prefs=getattr(bpy.context.window_manager,'smart_geometry_suite_settings',None)
    if prefs and prefs.always_on_parametric_primitive_auto_update:
        objects=[u.id.original for u in depsgraph.updates if isinstance(u.id,bpy.types.Object)] if depsgraph else []
        for o in objects:
            if is_owned_parametric_object(o):regenerate_object(o)
def register_handlers():
    if depsgraph_handler not in bpy.app.handlers.depsgraph_update_post:bpy.app.handlers.depsgraph_update_post.append(depsgraph_handler)
def unregister_handlers():
    if depsgraph_handler in bpy.app.handlers.depsgraph_update_post:bpy.app.handlers.depsgraph_update_post.remove(depsgraph_handler)
