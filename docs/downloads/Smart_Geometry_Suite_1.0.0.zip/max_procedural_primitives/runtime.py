# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Runtime object creation and parametric regeneration."""

from __future__ import annotations

from array import array
import json
import time
import zlib
from typing import Dict, Iterable, Optional

import bpy
import bmesh

from .. import ownership
from .mesh_generators import generate
from .node_interface import MODIFIER_NAME, LEGACY_MODIFIER_NAMES, ensure_modifier, enforce_modifier_socket_visibility, is_owned_modifier
from .specs import GENERATOR_SPECS, localized, lang_code

_UPDATING = False
_PENDING_UPDATE_TIMER = False
_LAST_UPDATE_AT = 0.0
_BOOLEAN_PREFIX = "Max Primitives Boolean"
_LEGACY_BOOLEAN_PREFIXES = ("JEL Max Boolean",)
_STORED_VALUES_PROP = "jel_max_stored_values"
_RUNTIME_PROPS = (
    "jel_max_generator_id",
    "jel_max_generator_category",
    "jel_max_socket_map",
    "jel_max_last_hash",
    "jel_max_mesh_state",
    _STORED_VALUES_PROP,
)
_LIVE_MODIFIER_OBJECTS: set[int] = set()
_UI_GUARD_TIMER_RUNNING = False
_LAST_FULL_ATTRIBUTE_SCAN = 0.0
_INTERACTIVE_DRAG_ACTIVE = False
_SHUTTING_DOWN = False
_PARAMETRIC_RUNTIME_ACTIVE = False
_LAST_PARAMETRIC_RUNTIME_SCAN_AT = 0.0
_PARAMETRIC_RUNTIME_SCAN_INTERVAL = 5.0
_HANDLER_TAG = 'max_primitives.automatic_handlers'
_UPDATE_TIMER_TAG = 'max_primitives.update_timer'


def _ledger():
    ledger = ownership.shared_ledger()
    return ledger if ownership.ledger_is_exact(ledger) else None


_OWNER_SUITE_KEY = 'jelararagi_sgs_owner_suite'
_OWNER_REVISION_KEY = 'jelararagi_sgs_owner_revision'
_OWNER_GENERATION_KEY = 'jelararagi_sgs_owner_generation'


def _mark_owned(value) -> bool:
    ledger = _ledger()
    if value is None or ledger is None:
        return False
    try:
        value[_OWNER_SUITE_KEY] = ownership.SUITE_ID
        value[_OWNER_REVISION_KEY] = ownership.REVISION
        value[_OWNER_GENERATION_KEY] = str(ledger.get('generation') or '')
        value['smart_geometry_suite_generated'] = True
        return True
    except Exception:
        return False


def _is_owned(value) -> bool:
    return _ledger() is not None and ownership.saved_data_is_owned(value)


def is_owned_parametric_object(obj) -> bool:
    if not _is_owned(obj):
        return False
    try:
        return obj.get('jel_max_generator_id') in GENERATOR_SPECS
    except Exception:
        return False


def _remove_created_object(obj) -> None:
    if obj is None or not is_owned_parametric_object(obj):
        return
    data = getattr(obj, 'data', None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        return
    if data is None:
        return
    try:
        if int(getattr(data, 'users', 0)) != 0:
            return
        if isinstance(data, bpy.types.Mesh):
            bpy.data.meshes.remove(data)
        elif isinstance(data, bpy.types.Curve):
            bpy.data.curves.remove(data)
    except Exception:
        pass


def _automatic_updates_enabled() -> bool:
    try:
        from .. import always_on
        return bool(always_on.feature_value('parametric_primitive_auto_update', bpy.context))
    except Exception:
        return False


def _is_runtime_shutting_down() -> bool:
    return bool(_SHUTTING_DOWN or not ownership.runtime_active_for_generation())


def begin_interactive_drag() -> None:
    """Suspend background refresh while viewport drag creation is previewing."""
    global _INTERACTIVE_DRAG_ACTIVE
    if _is_runtime_shutting_down():
        return
    _INTERACTIVE_DRAG_ACTIVE = True


def end_interactive_drag() -> None:
    """Resume background refresh after viewport drag creation finishes."""
    global _INTERACTIVE_DRAG_ACTIVE
    _INTERACTIVE_DRAG_ACTIVE = False


def is_interactive_drag_active() -> bool:
    return bool(_INTERACTIVE_DRAG_ACTIVE)


def _default_params(spec: Dict[str, object]) -> Dict[str, object]:
    return {param["id"]: param.get("default") for param in spec.get("params", [])}


def _read_socket_map(obj: bpy.types.Object) -> Dict[str, str]:
    try:
        return json.loads(obj.get("jel_max_socket_map", "{}"))
    except Exception:
        return {}


def _find_max_modifier(obj: bpy.types.Object):
    if obj is None:
        return None
    try:
        mod = obj.modifiers.get(MODIFIER_NAME)
        if mod and is_owned_modifier(mod):
            return mod
        for legacy_name in LEGACY_MODIFIER_NAMES:
            mod = obj.modifiers.get(legacy_name)
            if mod and is_owned_modifier(mod):
                return mod
    except Exception:
        return None
    return None


def _disable_modifier_attribute_mode(mod, identifier: str) -> None:
    if mod is None or not identifier:
        return
    for suffix, value in (("_use_attribute", False), ("_attribute_name", "")):
        try:
            key = f"{identifier}{suffix}"
            if key in mod:
                mod[key] = value
        except Exception:
            pass


def _force_modifier_value_inputs_active(mod, socket_map: Optional[Dict[str, str]] = None) -> int:
    """Keep native Geometry Nodes modifier rows in direct value mode."""
    if mod is None:
        return 0
    identifiers = []
    if socket_map:
        try:
            identifiers.extend(str(v) for v in socket_map.values() if v)
        except Exception:
            pass
    try:
        for key in list(mod.keys()):
            key = str(key)
            if key.endswith("_use_attribute"):
                identifiers.append(key[:-14])
    except Exception:
        pass
    changed = 0
    seen = set()
    for identifier in identifiers:
        if not identifier or identifier in seen:
            continue
        seen.add(identifier)
        use_key = f"{identifier}_use_attribute"
        name_key = f"{identifier}_attribute_name"
        try:
            if use_key in mod and bool(mod[use_key]):
                mod[use_key] = False
                changed += 1
        except Exception:
            pass
        try:
            if name_key in mod and str(mod[name_key] or ""):
                mod[name_key] = ""
                changed += 1
        except Exception:
            pass
    return changed


def _pack_value(value: object) -> object:
    try:
        if value is None:
            return None
        if hasattr(value, "as_pointer") and hasattr(value, "name"):
            return {"__id_type__": "OBJECT", "name": str(value.name)}
        if isinstance(value, (bool, int, float, str)):
            return value
        return str(value)
    except Exception:
        return None


def _unpack_value(param: Dict[str, object], value: object) -> object:
    if param.get("type") == "OBJECT":
        if isinstance(value, dict):
            name = value.get("name")
            if name:
                try:
                    return bpy.data.objects.get(str(name))
                except Exception:
                    return None
        if isinstance(value, str):
            try:
                return bpy.data.objects.get(value)
            except Exception:
                return None
        return None
    return _coerce_value_for_param(param, value)


def _store_values(obj: bpy.types.Object, spec: Dict[str, object], values: Dict[str, object]) -> None:
    if obj is None or not spec:
        return
    packed: Dict[str, object] = {}
    for param in spec.get("params", []):
        pid = param.get("id")
        if not pid or pid not in values:
            continue
        packed[str(pid)] = _pack_value(values.get(pid))
    try:
        obj[_STORED_VALUES_PROP] = json.dumps(packed, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        pass


def _read_stored_values(obj: bpy.types.Object, spec: Dict[str, object]) -> tuple[Dict[str, object], bool]:
    if obj is None or not spec:
        return {}, False
    raw = None
    try:
        raw = obj.get(_STORED_VALUES_PROP)
    except Exception:
        raw = None
    if raw is None:
        return {}, False
    try:
        stored = json.loads(raw) if isinstance(raw, str) else dict(raw)
    except Exception:
        return {}, False
    values: Dict[str, object] = {}
    for param in spec.get("params", []):
        pid = param.get("id")
        if not pid or pid not in stored:
            continue
        try:
            values[str(pid)] = _unpack_value(param, stored.get(pid))
        except Exception:
            continue
    return values, bool(values)


def _clear_runtime_metadata(obj: bpy.types.Object) -> None:
    if obj is None:
        return
    for key in _RUNTIME_PROPS:
        try:
            if key in obj:
                del obj[key]
        except Exception:
            pass


def read_values(obj: bpy.types.Object) -> Dict[str, object]:
    generator_id = obj.get("jel_max_generator_id")
    spec = GENERATOR_SPECS.get(generator_id)
    if not spec:
        return {}
    values = _default_params(spec)
    stored_values, _ = _read_stored_values(obj, spec)
    values.update(stored_values)
    mod = _find_max_modifier(obj)
    socket_map = _read_socket_map(obj)
    if not mod:
        return values
    _force_modifier_value_inputs_active(mod, socket_map)
    for param in spec.get("params", []):
        identifier = socket_map.get(param["id"])
        if not identifier:
            continue
        try:
            if param.get("type") != "OBJECT":
                _disable_modifier_attribute_mode(mod, identifier)
            if identifier in mod:
                values[param["id"]] = mod[identifier]
        except Exception:
            continue
    _store_values(obj, spec, values)
    return values




def _coerce_value_for_param(param: Dict[str, object], value: object) -> object:
    typ = str(param.get("type") or "FLOAT")
    try:
        if typ == "INT":
            value = int(round(float(value)))
            if param.get("min") is not None:
                value = max(int(param.get("min")), value)
            if param.get("max") is not None:
                value = min(int(param.get("max")), value)
            return value
        if typ == "FLOAT":
            value = float(value)
            if param.get("min") is not None:
                value = max(float(param.get("min")), value)
            if param.get("max") is not None:
                value = min(float(param.get("max")), value)
            return value
        if typ == "BOOL":
            return bool(value)
        if typ == "STRING":
            return str(value)
    except Exception:
        return value
    return value


def write_values(obj: bpy.types.Object, values: Dict[str, object], *, regenerate: bool = True) -> bool:
    """Write Max Primitives public modifier values and optionally rebuild.

    This uses the same exposed modifier sockets users edit in Blender.  It is
    used by the viewport drag creation tool and by verification tests so every
    primitive remains editable after creation.
    """
    if obj is None:
        return False
    generator_id = obj.get("jel_max_generator_id")
    spec = GENERATOR_SPECS.get(generator_id)
    if not spec:
        return False
    mod = _find_max_modifier(obj)
    if not mod:
        return False
    socket_map = _read_socket_map(obj)
    _force_modifier_value_inputs_active(mod, socket_map)
    changed = False
    for param in spec.get("params", []):
        pid = param.get("id")
        if pid not in values:
            continue
        identifier = socket_map.get(pid)
        if not identifier:
            continue
        value = _coerce_value_for_param(param, values.get(pid))
        if param.get("type") != "OBJECT":
            _disable_modifier_attribute_mode(mod, identifier)
        try:
            mod[identifier] = value
            if param.get("type") != "OBJECT":
                _disable_modifier_attribute_mode(mod, identifier)
            changed = True
        except Exception:
            try:
                setattr(mod, identifier, value)
                changed = True
            except Exception:
                continue
    if changed:
        try:
            current = read_values(obj)
            _store_values(obj, spec, current)
        except Exception:
            pass
    if changed and regenerate:
        try:
            regenerate_object(obj, force=True)
        except Exception:
            return False
    return changed


def _hash_values(values: Dict[str, object]) -> str:
    try:
        packed = {}
        for key, value in values.items():
            if hasattr(value, "name") and hasattr(value, "as_pointer"):
                packed[key] = {"name": value.name, "pointer": int(value.as_pointer())}
            else:
                packed[key] = value
        return json.dumps(packed, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        return repr(sorted((str(k), str(v)) for k, v in values.items()))


def _clear_boolean_modifiers(obj: bpy.types.Object) -> None:
    prefixes = (_BOOLEAN_PREFIX, *_LEGACY_BOOLEAN_PREFIXES)
    for mod in list(obj.modifiers):
        # Boolean modifiers cannot hold ID properties, so the reserved name identifies them.
        if mod.type == "BOOLEAN" and any(mod.name.startswith(prefix) for prefix in prefixes):
            try:
                obj.modifiers.remove(mod)
            except Exception:
                pass


def _boolean_operation(code: object) -> str:
    try:
        value = int(code)
    except Exception:
        value = 0
    if value == 1:
        return "DIFFERENCE"
    if value == 2:
        return "INTERSECT"
    return "UNION"


def _valid_operand(obj: bpy.types.Object, operand: object) -> bool:
    return bool(operand and hasattr(operand, "type") and getattr(operand, "type", None) in {"MESH", "CURVE", "SURFACE", "FONT", "META"} and operand != obj)


def _add_boolean_modifier(obj: bpy.types.Object, name: str, operand: object, operation: str) -> None:
    if not _valid_operand(obj, operand):
        return
    try:
        mod = obj.modifiers.new(name, "BOOLEAN")
        mod.operation = operation
        mod.object = operand
        if hasattr(mod, "solver"):
            mod.solver = "EXACT"
    except Exception:
        pass


def _sync_boolean_modifiers(obj: bpy.types.Object, generator_id: str, values: Dict[str, object]) -> None:
    _clear_boolean_modifiers(obj)
    if generator_id == "compound_boolean":
        _add_boolean_modifier(obj, f"{_BOOLEAN_PREFIX} B", values.get("operand_b"), _boolean_operation(values.get("operation", 0)))
        return
    if generator_id == "compound_proboolean":
        for idx in range(1, 5):
            op = values.get(f"operation_{idx}", values.get("operation", 0))
            if int(op) == 3:
                operation = "UNION"
            else:
                operation = _boolean_operation(op)
            _add_boolean_modifier(obj, f"{_BOOLEAN_PREFIX} Pro {idx}", values.get(f"operand_{idx}"), operation)
        return
    if generator_id == "compound_procutter":
        for idx in range(1, 5):
            _add_boolean_modifier(obj, f"{_BOOLEAN_PREFIX} Cutter {idx}", values.get(f"cutter_{idx}"), "DIFFERENCE")


def _apply_uv_map(mesh: bpy.types.Mesh, values: Dict[str, object]) -> None:
    if not bool(values.get("map_coords", False)):
        return
    if not mesh.vertices or not mesh.polygons:
        return
    try:
        uv_layer = mesh.uv_layers.get("Map") or mesh.uv_layers.new(name="Map")
    except Exception:
        return
    xs = [v.co.x for v in mesh.vertices]
    ys = [v.co.y for v in mesh.vertices]
    zs = [v.co.z for v in mesh.vertices]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    min_z, max_z = min(zs), max(zs)
    range_x = max(max_x - min_x, 1.0e-9)
    range_y = max(max_y - min_y, 1.0e-9)
    range_z = max(max_z - min_z, 1.0e-9)
    real_world = bool(values.get("real_world_map_size", False))
    scale = max(float(values.get("map_scale", 1.0) or 1.0), 1.0e-9)
    for poly in mesh.polygons:
        n = poly.normal
        # Planar axis selection keeps UVs stable for caps and sides without requiring generated UV topology.
        use_xz = abs(n.y) >= abs(n.x) and abs(n.y) >= abs(n.z)
        use_yz = abs(n.x) >= abs(n.y) and abs(n.x) >= abs(n.z)
        for loop_index in poly.loop_indices:
            co = mesh.vertices[mesh.loops[loop_index].vertex_index].co
            if use_yz:
                u, v = co.y, co.z
                du, dv = range_y, range_z
                ou, ov = min_y, min_z
            elif use_xz:
                u, v = co.x, co.z
                du, dv = range_x, range_z
                ou, ov = min_x, min_z
            else:
                u, v = co.x, co.y
                du, dv = range_x, range_y
                ou, ov = min_x, min_y
            if real_world:
                uv_layer.data[loop_index].uv = (u / scale, v / scale)
            else:
                uv_layer.data[loop_index].uv = ((u - ou) / du, (v - ov) / dv)


def _mesh_state(mesh: bpy.types.Mesh) -> str:
    """Fingerprint of the vertex positions and topology of a generated mesh."""
    coords = array("f", [0.0]) * (len(mesh.vertices) * 3)
    mesh.vertices.foreach_get("co", coords)
    return f"{len(mesh.vertices)}:{len(mesh.polygons)}:{zlib.crc32(coords.tobytes())}"


def _can_rebuild_without_modifier(obj: bpy.types.Object) -> bool:
    """Allow the one rebuild only for a modifier just lost under the live hooks.

    The object must have been seen with its modifier in this session, and its mesh
    must still be the generated one.  Anything else is the user's own mesh now.
    """
    if obj.type != "MESH":
        return True
    try:
        return (
            obj.session_uid in _LIVE_MODIFIER_OBJECTS
            and obj.get("jel_max_mesh_state") == _mesh_state(obj.data)
        )
    except Exception:
        return False


def _recalculate_normals_outward(mesh: bpy.types.Mesh) -> None:
    """Recalculate procedural mesh normals so closed primitives face outward.

    Blender/3ds Max style primitives should have clean external normals after
    generation, modifier application and object conversion.  The generator code
    may create faces from several construction paths, so normalize orientation
    through BMesh immediately before UV creation.
    """
    if mesh is None:
        return
    try:
        if not mesh.polygons:
            return
    except Exception:
        return
    bm = None
    try:
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        faces = list(bm.faces)
        if not faces:
            return
        bmesh.ops.recalc_face_normals(bm, faces=faces)
        signed_volume = 0.0
        for face in faces:
            verts = list(face.verts)
            if len(verts) < 3:
                continue
            v0 = verts[0].co
            for idx in range(1, len(verts) - 1):
                v1 = verts[idx].co
                v2 = verts[idx + 1].co
                signed_volume += float(v0.dot(v1.cross(v2))) / 6.0
        # For closed convex and concave shells, a negative signed volume means
        # the component is inside-out. Open shapes usually have near-zero volume
        # and are left as the generated/recalculated orientation.
        if signed_volume < -1.0e-9:
            bmesh.ops.reverse_faces(bm, faces=faces)
        bm.to_mesh(mesh)
    except Exception:
        pass
    finally:
        try:
            if bm is not None:
                bm.free()
        except Exception:
            pass


def _apply_mesh(obj: bpy.types.Object, mesh_data: Dict[str, object], values: Optional[Dict[str, object]] = None) -> None:
    if obj.type != "MESH":
        return
    mesh = obj.data
    mesh.clear_geometry()
    mesh.from_pydata(mesh_data.get("verts", []), mesh_data.get("edges", []), mesh_data.get("faces", []))
    mesh.update(calc_edges=True)
    _recalculate_normals_outward(mesh)
    mesh.update(calc_edges=True)
    if mesh_data.get("smooth"):
        for poly in mesh.polygons:
            poly.use_smooth = True
    if values:
        _apply_uv_map(mesh, values)
    mesh.update()


def _apply_text(obj: bpy.types.Object, values: Dict[str, object]) -> None:
    if obj.type != "FONT":
        return
    curve = obj.data
    curve.body = str(values.get("text", "TextPlus"))
    curve.size = float(values.get("size", 10.0))
    curve.extrude = float(values.get("extrude", 1.0))
    curve.bevel_depth = float(values.get("bevel_depth", 0.0))
    curve.bevel_resolution = int(values.get("bevel_segments", 0))
    curve.resolution_u = int(values.get("resolution", 12))
    align = int(values.get("align", 0))
    curve.align_x = "LEFT" if align <= 0 else ("CENTER" if align == 1 else "RIGHT")
    if hasattr(curve, "space_character"):
        curve.space_character = float(values.get("tracking", 1.0))
    if hasattr(curve, "space_line"):
        curve.space_line = float(values.get("line_spacing", 1.0))
    if hasattr(curve, "shear"):
        curve.shear = float(values.get("shear", 0.0))
    if hasattr(curve, "offset_x"):
        curve.offset_x = float(values.get("offset_x", 0.0))
    if hasattr(curve, "offset_y"):
        curve.offset_y = float(values.get("offset_y", 0.0))


def regenerate_object(obj: bpy.types.Object, force: bool = False) -> bool:
    if not is_owned_parametric_object(obj):
        return False
    generator_id = obj.get("jel_max_generator_id")
    if not generator_id or generator_id not in GENERATOR_SPECS:
        return False
    spec = GENERATOR_SPECS.get(generator_id)
    mod = _find_max_modifier(obj)
    if mod is not None:
        try:
            ensure_modifier(obj, generator_id, spec, initialize_values=False)
            mod = _find_max_modifier(obj)
            _force_modifier_value_inputs_active(mod, _read_socket_map(obj))
        except Exception:
            pass
    stored_values, has_stored_values = _read_stored_values(obj, spec)
    if mod is None and not has_stored_values:
        # A mesh converted by Blender may keep stale custom properties but no
        # editable Max Primitives modifier.  Without a stored snapshot there is
        # no reliable non-destructive state to restore, so make it a plain mesh
        # rather than regenerating defaults over the user's result.
        _clear_runtime_metadata(obj)
        return False
    if mod is None and not _can_rebuild_without_modifier(obj):
        _clear_runtime_metadata(obj)
        return False
    values = read_values(obj)
    value_hash = _hash_values(values)
    if mod is not None and not force and obj.get("jel_max_last_hash") == value_hash:
        return False
    if obj.type == "FONT" or (spec and spec.get("object_type") == "FONT"):
        _apply_text(obj, values)
        if mod is not None:
            _clear_boolean_modifiers(obj)
    else:
        data = generate(generator_id, values)
        _apply_mesh(obj, data, values)
        if mod is not None:
            _sync_boolean_modifiers(obj, generator_id, values)
            if obj.type == "MESH":
                obj["jel_max_mesh_state"] = _mesh_state(obj.data)
    _store_values(obj, spec, values)
    if mod is None:
        # Native Apply Modifier / Convert to Mesh removes the public parameter
        # modifier before Python can intercept the operation.  Rebuild once from
        # the last socket snapshot and then remove runtime metadata so the mesh
        # stays fixed at the adjusted shape.
        _clear_runtime_metadata(obj)
    else:
        obj["jel_max_last_hash"] = value_hash
    return True


def create_parametric_object(generator_id: str, *, link: bool = True, name: Optional[str] = None, collection: Optional[bpy.types.Collection] = None, location=None, initial_values: Optional[Dict[str, object]] = None) -> bpy.types.Object:
    if generator_id not in GENERATOR_SPECS:
        raise ValueError(f"Unknown generator id: {generator_id}")
    if not ownership.runtime_active_for_generation():
        raise RuntimeError("Smart Geometry runtime is not active")
    spec = GENERATOR_SPECS[generator_id]
    lang = lang_code()
    obj_name = name or localized(spec["name"], lang)
    obj = None
    try:
        if spec.get("object_type") == "FONT":
            data = bpy.data.curves.new(obj_name + " Curve", "FONT")
            obj = bpy.data.objects.new(obj_name, data)
        else:
            data = bpy.data.meshes.new(obj_name + " Mesh")
            obj = bpy.data.objects.new(obj_name, data)
        if not (_mark_owned(obj) and _mark_owned(data)):
            raise RuntimeError("Max Primitive ownership tagging failed")
        obj["jel_max_generator_id"] = generator_id
        obj["jel_max_generator_category"] = spec["category"]
        obj["jel_max_author"] = "JELararagi"
        ensure_modifier(obj, generator_id, spec, initialize_values=True)
        try:
            ensure_modifier_inputs_active((obj,))
            register_ui_guard()
        except Exception:
            pass
        if initial_values:
            write_values(obj, dict(initial_values), regenerate=False)
        regenerate_object(obj, force=True)
        if link:
            target_collection = collection or bpy.context.collection
            target_collection.objects.link(obj)
            try:
                obj.location = location if location is not None else bpy.context.scene.cursor.location
            except Exception:
                pass
        register_handlers()
        return obj
    except Exception:
        _remove_created_object(obj)
        raise


def iter_parametric_objects() -> Iterable[bpy.types.Object]:
    for obj in bpy.data.objects:
        if is_owned_parametric_object(obj):
            yield obj


def _refresh_parametric_runtime_state(force: bool = False) -> bool:
    global _PARAMETRIC_RUNTIME_ACTIVE, _LAST_PARAMETRIC_RUNTIME_SCAN_AT
    now = time.monotonic()
    if not force and (now - _LAST_PARAMETRIC_RUNTIME_SCAN_AT) < _PARAMETRIC_RUNTIME_SCAN_INTERVAL:
        return bool(_PARAMETRIC_RUNTIME_ACTIVE)
    _LAST_PARAMETRIC_RUNTIME_SCAN_AT = now
    try:
        _PARAMETRIC_RUNTIME_ACTIVE = next(iter_parametric_objects(), None) is not None
    except Exception:
        _PARAMETRIC_RUNTIME_ACTIVE = False
    return bool(_PARAMETRIC_RUNTIME_ACTIVE)


def ensure_modifier_inputs_active(objects: Optional[Iterable[bpy.types.Object]] = None) -> int:
    """Restore direct-value mode for Max Primitives modifier inputs."""
    if _is_runtime_shutting_down():
        return 0
    changed = 0
    seq = objects if objects is not None else iter_parametric_objects()
    for obj in list(seq):
        try:
            if obj is None or obj.get("jel_max_generator_id") not in GENERATOR_SPECS:
                continue
            mod = _find_max_modifier(obj)
            if mod is None:
                continue
            socket_map = _read_socket_map(obj)
            changed += _force_modifier_value_inputs_active(mod, socket_map)
            try:
                spec = GENERATOR_SPECS.get(obj.get("jel_max_generator_id"))
                changed += enforce_modifier_socket_visibility(obj=obj, tree=getattr(mod, "node_group", None), spec=spec, socket_map=socket_map)
            except Exception:
                pass
        except Exception:
            continue
    if changed:
        try:
            screen = getattr(bpy.context, "screen", None)
            for area in getattr(screen, "areas", []):
                if getattr(area, "type", None) == "PROPERTIES":
                    area.tag_redraw()
        except Exception:
            pass
    return changed


def _modifier_ui_guard_timer():
    """Removed compatibility callback; no watchdog is ever scheduled."""
    global _UI_GUARD_TIMER_RUNNING
    _UI_GUARD_TIMER_RUNNING = False
    return None


def register_ui_guard() -> None:
    """Compatibility no-op: modifier UI is normalized only at command/draw boundaries."""
    global _UI_GUARD_TIMER_RUNNING, _SHUTTING_DOWN
    _SHUTTING_DOWN = False
    _UI_GUARD_TIMER_RUNNING = False


def unregister_ui_guard() -> None:
    global _UI_GUARD_TIMER_RUNNING
    _UI_GUARD_TIMER_RUNNING = False


def update_all(force: bool = False) -> int:
    global _UPDATING
    if _is_runtime_shutting_down():
        return 0
    if _UPDATING:
        return 0
    _UPDATING = True
    count = 0
    try:
        for obj in iter_parametric_objects():
            try:
                if regenerate_object(obj, force=force):
                    count += 1
            except Exception:
                # Avoid breaking Blender's depsgraph handler if one procedural object fails.
                continue
    finally:
        _UPDATING = False
    return count


def snapshot_live_values() -> int:
    if _is_runtime_shutting_down():
        return 0
    count = 0
    for obj in iter_parametric_objects():
        try:
            if _find_max_modifier(obj) is not None:
                _LIVE_MODIFIER_OBJECTS.add(obj.session_uid)
                values = read_values(obj)
                if values:
                    count += 1
        except Exception:
            continue
    return count


def finalize_modifierless_objects() -> int:
    global _UPDATING
    if _is_runtime_shutting_down():
        return 0
    if _UPDATING:
        return 0
    _UPDATING = True
    count = 0
    try:
        for obj in list(iter_parametric_objects()):
            try:
                if _find_max_modifier(obj) is None and regenerate_object(obj, force=True):
                    count += 1
            except Exception:
                continue
    finally:
        _UPDATING = False
    return count


def _timer_update_all():
    global _PENDING_UPDATE_TIMER, _LAST_UPDATE_AT
    try:
        if _is_runtime_shutting_down():
            return None
        update_all(False)
        _LAST_UPDATE_AT = time.monotonic()
        return None
    finally:
        _PENDING_UPDATE_TIMER = False


def _schedule_update_all(delay: float = 0.05) -> None:
    global _PENDING_UPDATE_TIMER
    if _is_runtime_shutting_down() or _PENDING_UPDATE_TIMER:
        return
    ledger = _ledger()
    if ledger is None:
        return
    _PENDING_UPDATE_TIMER = True
    try:
        ownership.register_timer(
            ledger, _timer_update_all, first_interval=max(0.01, float(delay)),
            persistent=False, tag=_UPDATE_TIMER_TAG,
        )
    except Exception:
        _PENDING_UPDATE_TIMER = False


def depsgraph_pre_handler(scene, depsgraph=None):
    if _is_runtime_shutting_down() or _UPDATING or _INTERACTIVE_DRAG_ACTIVE:
        return
    if not _refresh_parametric_runtime_state():
        return
    try:
        snapshot_live_values()
    except Exception:
        pass


def depsgraph_handler(scene, depsgraph=None):
    if _is_runtime_shutting_down() or _INTERACTIVE_DRAG_ACTIVE:
        return
    if not _refresh_parametric_runtime_state():
        return
    try:
        if _UPDATING:
            return
        snapshot_live_values()
        finalize_modifierless_objects()
        if (time.monotonic() - _LAST_UPDATE_AT) < 0.10:
            return
    except Exception:
        pass
    _schedule_update_all(0.05)


def frame_change_handler(scene, depsgraph=None):
    if _is_runtime_shutting_down() or _INTERACTIVE_DRAG_ACTIVE:
        return
    if not _refresh_parametric_runtime_state():
        return
    _schedule_update_all(0.01)


def register_handlers() -> bool:
    global _SHUTTING_DOWN
    _SHUTTING_DOWN = False
    register_ui_guard()
    if not _automatic_updates_enabled():
        return _remove_live_hooks(mark_shutdown=False)
    ledger = _ledger()
    if ledger is None or not ownership.runtime_active_for_generation():
        return False
    # The handlers stop early while the file has no primitive, and they must also
    # be present for primitives that arrive later from an opened or appended file.
    _refresh_parametric_runtime_state(force=True)
    if not any(str(record.get('tag') or '') == _HANDLER_TAG for record in ledger.get('handlers', ())):
        ownership.register_handler(
            ledger, bpy.app.handlers.depsgraph_update_pre, depsgraph_pre_handler,
            persistent=True, tag=_HANDLER_TAG,
        )
        ownership.register_handler(
            ledger, bpy.app.handlers.depsgraph_update_post, depsgraph_handler,
            persistent=True, tag=_HANDLER_TAG,
        )
        ownership.register_handler(
            ledger, bpy.app.handlers.frame_change_post, frame_change_handler,
            persistent=True, tag=_HANDLER_TAG,
        )
    return True


def _remove_live_hooks(*, mark_shutdown: bool) -> bool:
    global _SHUTTING_DOWN, _PENDING_UPDATE_TIMER, _INTERACTIVE_DRAG_ACTIVE
    _SHUTTING_DOWN = bool(mark_shutdown)
    _PENDING_UPDATE_TIMER = False
    _INTERACTIVE_DRAG_ACTIVE = False
    unregister_ui_guard()
    ledger = _ledger()
    if ledger is None:
        return True
    ok = ownership.remove_tagged_dynamic_resources(ledger, _UPDATE_TIMER_TAG)
    ok = ownership.remove_tagged_dynamic_resources(ledger, _HANDLER_TAG) and ok
    return ok


def sync_automatic_updates(enabled: bool | None = None) -> bool:
    """Install or remove exact generation-owned hooks without global scans."""
    if enabled is None:
        enabled = _automatic_updates_enabled()
    return register_handlers() if bool(enabled) else _remove_live_hooks(mark_shutdown=False)


def unregister_handlers() -> bool:
    return _remove_live_hooks(mark_shutdown=True)


def clear_runtime_caches() -> None:
    global _PARAMETRIC_RUNTIME_ACTIVE, _LAST_PARAMETRIC_RUNTIME_SCAN_AT
    _PARAMETRIC_RUNTIME_ACTIVE = False
    _LAST_PARAMETRIC_RUNTIME_SCAN_AT = 0.0
