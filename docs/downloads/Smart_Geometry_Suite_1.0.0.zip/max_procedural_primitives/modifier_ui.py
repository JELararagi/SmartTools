# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Active Max Primitives controls in Properties > Modifiers.

The native Geometry Nodes modifier input rows can be drawn as dimmed field rows
on Blender 5.1 even when direct value mode is forced.  This panel draws the
same modifier ID-property values as ordinary active properties and leaves the
runtime regeneration path unchanged.
"""

from __future__ import annotations

import json
import bpy

from .node_interface import MODIFIER_NAME
from .specs import GENERATOR_SPECS, localized, lang_code

_PANEL_RUNTIME_ENABLED = False
_REGISTERED = False


def _is_suite_shutting_down() -> bool:
    try:
        ns = getattr(getattr(bpy, "app", None), "driver_namespace", None)
        return isinstance(ns, dict) and bool(ns.get("SMART_GEOMETRY_SUITE_SHUTTING_DOWN"))
    except Exception:
        return False


def _t(en: str, ja: str) -> str:
    return ja if lang_code() == "ja" else en


def _active_max_object(context):
    obj = getattr(context, "object", None)
    try:
        if obj is not None and obj.get("jel_max_generator_id") in GENERATOR_SPECS:
            return obj
    except Exception:
        pass
    return None


def _socket_map(obj) -> dict:
    try:
        return json.loads(obj.get("jel_max_socket_map", "{}"))
    except Exception:
        return {}


def _max_modifier(obj):
    try:
        return obj.modifiers.get(MODIFIER_NAME)
    except Exception:
        return None


class JELMAX_OT_refresh_selected(bpy.types.Operator):
    bl_idname = "jel_max.refresh_selected"
    bl_label = "Refresh Max Primitive"
    bl_description = "Applies the current Max Primitives modifier values to the generated mesh immediately. Use this when automatic regeneration is delayed."
    bl_options = {"UNDO"}

    def execute(self, context):
        obj = _active_max_object(context)
        if obj is None:
            return {"CANCELLED"}
        try:
            from .runtime import regenerate_object
            regenerate_object(obj, force=True)
        except Exception:
            return {"CANCELLED"}
        return {"FINISHED"}


class JELMAX_PT_modifier_active_controls(bpy.types.Panel):
    bl_idname = "JELMAX_PT_modifier_active_controls"
    bl_label = "Max Primitives Parameters"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "modifier"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        if _is_suite_shutting_down() or not _PANEL_RUNTIME_ENABLED:
            return False
        return _active_max_object(context) is not None

    def draw_header(self, context):
        try:
            self.layout.label(icon="GEOMETRY_NODES")
        except Exception:
            pass

    def draw(self, context):
        layout = self.layout
        obj = _active_max_object(context)
        if obj is None:
            return
        generator_id = obj.get("jel_max_generator_id")
        spec = GENERATOR_SPECS.get(generator_id)
        mod = _max_modifier(obj)
        if spec is None or mod is None:
            layout.label(text=_t("No editable Max Primitives modifier.", "編集可能な Max Primitives モディファイアーがありません。"))
            return
        # Socket activation/visibility repair belongs to the explicit Refresh
        # operator and generator lifecycle.  Merely drawing Properties must not
        # mutate the modifier or node group.
        lang = lang_code()
        box = layout.box()
        box.label(text=localized(spec.get("name", {}), lang), icon="GEOMETRY_NODES")
        box.operator(JELMAX_OT_refresh_selected.bl_idname, text=_t("Refresh Max Primitive", "Maxプリミティブを更新"), icon="FILE_REFRESH")

        socket_map = _socket_map(obj)
        for param in spec.get("params", []):
            pid = str(param.get("id") or "")
            identifier = socket_map.get(pid)
            if not identifier:
                continue
            try:
                if identifier not in mod:
                    continue
            except Exception:
                continue
            row = box.row(align=True)
            row.enabled = True
            label = localized(param, lang)
            try:
                row.prop(mod, f'["{identifier}"]', text=label)
            except Exception:
                try:
                    row.label(text=label)
                    row.prop(mod, f'["{identifier}"]', text="")
                except Exception:
                    row.label(text=label, icon="DOT")


CLASSES = (
    JELMAX_OT_refresh_selected,
    JELMAX_PT_modifier_active_controls,
)



def _class_owned_by_suite(cls) -> bool:
    """Compatibility query using only the exact current-generation token."""
    try:
        from .. import ownership
        ledger = ownership.shared_ledger()
        return ownership.ledger_is_exact(ledger) and ownership.class_identity_matches(cls, ledger)
    except Exception:
        return False


def _registered_class(cls):
    """Do not discover or adopt RNA through bpy.types name lookup."""
    del cls
    return None


def _set_registered_panel_runtime(enabled: bool) -> None:
    """Never mutate an older module or third-party Panel class."""
    del enabled
    return None


def _register_class_once(cls) -> bool:
    """Legacy compatibility no-op; bridge RNA is centrally owned."""
    del cls
    return False

def _unregister_owned_class(cls) -> None:
    """Legacy compatibility no-op; central teardown owns bridge RNA."""
    del cls
    return None

def suspend_runtime() -> None:
    global _PANEL_RUNTIME_ENABLED
    _PANEL_RUNTIME_ENABLED = False
    _set_registered_panel_runtime(False)


def resume_runtime() -> None:
    global _PANEL_RUNTIME_ENABLED
    _PANEL_RUNTIME_ENABLED = True
    _set_registered_panel_runtime(True)


def register() -> None:
    """Compatibility no-op; the integrated bridge panel is centrally owned."""
    global _PANEL_RUNTIME_ENABLED, _REGISTERED
    _PANEL_RUNTIME_ENABLED = True
    _REGISTERED = True
    return None

def unregister() -> None:
    """Compatibility no-op; the Suite transaction owns bridge panel teardown."""
    global _PANEL_RUNTIME_ENABLED, _REGISTERED
    _PANEL_RUNTIME_ENABLED = False
    _REGISTERED = False
    return None
