# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Geometry Nodes interface helpers.

The generated node group acts as the public non-destructive modifier interface.
A runtime handler reads the modifier socket values and rebuilds the procedural
mesh. This keeps all user-facing controls on the Geometry Nodes modifier.
"""

from __future__ import annotations

import json
from typing import Dict, Tuple

import bpy

from .. import ownership
from .specs import localized, lang_code, is_distance_param


MODIFIER_NAME = "Max Primitives"
LEGACY_MODIFIER_NAMES = ("JEL Max Procedural",)
GROUP_PREFIX = "Max Primitives - "
RENAMED_GROUP_PREFIX = "Max Primitives_GN_v21_"
LEGACY_GROUP_PREFIXES = ("Max Primitives_GN_", "Max Primitives_GN_v20_", "JEL_Max_GN_")
SOCKET_PREFIX = "JEL_"
INTERFACE_BUILD_VERSION = 22
_OWNER_SUITE_KEY = 'jelararagi_sgs_owner_suite'
_OWNER_REVISION_KEY = 'jelararagi_sgs_owner_revision'
_OWNER_GENERATION_KEY = 'jelararagi_sgs_owner_generation'


def _ledger():
    ledger = ownership.shared_ledger()
    return ledger if ownership.ledger_is_exact(ledger) else None


def _is_owned(value) -> bool:
    return _ledger() is not None and ownership.saved_data_is_owned(value)


def is_owned_modifier(mod) -> bool:
    # Assigning or updating a node group rebuilds a Geometry Nodes modifier's
    # ID properties and drops the owner tags, so the owned node group counts too.
    return _is_owned(mod) or bool(getattr(mod, 'type', None) == 'NODES' and _is_owned(getattr(mod, 'node_group', None)))


def _mark_owned(value) -> bool:
    ledger = _ledger()
    if value is None or ledger is None:
        return False
    try:
        value[_OWNER_SUITE_KEY] = ownership.SUITE_ID
        value[_OWNER_REVISION_KEY] = ownership.REVISION
        value[_OWNER_GENERATION_KEY] = str(ledger.get('generation') or '')
        value['smart_geometry_suite_generated'] = True
        return True
    except Exception:
        return False


def _iter_interface_sockets(tree):
    """Yield Geometry Nodes interface sockets without touching panel custom data."""
    try:
        items_tree = getattr(getattr(tree, "interface", None), "items_tree", None)
        if items_tree is not None:
            for item in items_tree:
                try:
                    if getattr(item, "item_type", None) == "SOCKET":
                        yield item
                except Exception:
                    continue
            return
    except Exception:
        pass
    try:
        items = getattr(tree.interface, "items", None)
        if callable(items):
            for item in items():
                try:
                    if getattr(item, "item_type", None) == "SOCKET":
                        yield item
                except Exception:
                    continue
    except Exception:
        return


def _find_socket_by_identifier(tree, identifier: str):
    if not identifier:
        return None
    for sock in _iter_interface_sockets(tree):
        try:
            if str(getattr(sock, "identifier", "") or "") == str(identifier):
                return sock
        except Exception:
            continue
    return None


def enforce_modifier_socket_visibility(obj: bpy.types.Object | None = None, tree: bpy.types.NodeTree | None = None, spec: Dict[str, object] | None = None, socket_map: Dict[str, str] | None = None) -> int:
    """Force Max Primitive inputs into the intended editable UI state.

    Blender 5.1 can keep old Geometry Nodes interface display flags alive on
    reused node groups.  The native GN socket rows are hidden to avoid dimmed
    field-style controls, while the companion modifier parameter panel draws
    the same ID-properties as normal active controls.
    """
    changed = 0
    if obj is not None:
        try:
            if tree is None:
                mod = obj.modifiers.get(MODIFIER_NAME)
                tree = getattr(mod, "node_group", None)
        except Exception:
            pass
        if socket_map is None:
            try:
                socket_map = json.loads(obj.get("jel_max_socket_map", "{}")) if obj.get("jel_max_socket_map") else {}
            except Exception:
                socket_map = {}
    if tree is None:
        return 0
    spec_params = []
    if spec is not None:
        try:
            spec_params = list(spec.get("params", []))
        except Exception:
            spec_params = []
    param_by_ident = {}
    if socket_map and spec_params:
        for param in spec_params:
            try:
                ident = socket_map.get(param.get("id"))
                if ident:
                    param_by_ident[str(ident)] = param
            except Exception:
                pass
    for sock in _iter_interface_sockets(tree):
        try:
            if getattr(sock, "in_out", None) != "INPUT":
                continue
            if getattr(sock, "bl_socket_idname", "") == "NodeSocketGeometry":
                continue
        except Exception:
            pass
        try:
            ident = str(getattr(sock, "identifier", "") or "")
        except Exception:
            ident = ""
        param = param_by_ident.get(ident, {})
        before = []
        for attr, value in (
            ("hide_value", False),
            ("hide_in_modifier", True),
            ("force_non_field", True),
            ("structure_type", "SINGLE"),
            ("default_input", "VALUE"),
        ):
            try:
                before_value = getattr(sock, attr)
                if before_value != value:
                    setattr(sock, attr, value)
                    changed += 1
            except Exception:
                pass
        try:
            subtype = "DISTANCE" if _is_distance_param(param) else "NONE"
            if getattr(sock, "subtype", None) != subtype:
                sock.subtype = subtype
                changed += 1
        except Exception:
            pass
    try:
        tree["jel_max_interface_build"] = int(INTERFACE_BUILD_VERSION)
    except Exception:
        pass
    return changed


def _socket_type(param_type: str) -> str:
    if param_type == "BOOL":
        return "NodeSocketBool"
    if param_type == "INT":
        return "NodeSocketInt"
    if param_type == "STRING":
        return "NodeSocketString"
    if param_type == "OBJECT":
        return "NodeSocketObject"
    return "NodeSocketFloat"


# Float parameters that represent real model dimensions.  These are tagged as
# Blender distance inputs so the Modifier properties UI follows the scene unit
# setting (m / cm / mm, etc.) without changing the stored numeric value.
_DISTANCE_PARAM_IDS = {
    "length", "length1", "length2", "width", "depth", "height",
    "radius", "radius1", "radius2", "tube_radius", "inner_radius", "outer_radius",
    "target_radius", "shape_radius", "diameter", "size", "size_a", "size_b",
    "base_size", "cutter_radius", "corner_radius", "corner_length",
    "fillet", "bevel", "bevel_depth", "extrude", "cap_height", "thickness",
    "opening", "opening_width", "opening_height", "opening_sill",
    "bottom_offset", "top_offset", "offset", "offset_x", "offset_y",
    "frame_width", "panel_thickness", "sash_width", "glass_thickness",
    "post_spacing", "post_radius", "rail_radius", "baluster_spacing",
    "tread_thickness", "landing", "nosing", "spread", "path_length",
    "cut_depth", "gap", "trunk_radius", "leaf_size", "amplitude",
    "standoff_distance", "default_projection_distance", "curvature",
    "inner_edge_breakup", "outer_edge_breakup",
}
_DISTANCE_PARAM_SUFFIXES = (
    "_length", "_width", "_height", "_depth", "_radius", "_size",
    "_spacing", "_offset", "_thickness", "_distance", "_gap",
)
_DIMENSIONLESS_FLOAT_PARAM_IDS = {
    "density", "display_percent", "random_rotation", "eccentricity", "p", "q",
    "twist", "tube_twist", "tube_rotation", "phase", "turns", "wind", "season",
    "frame", "hemisphere", "amount", "threshold", "tension", "open",
    "open_angle", "shear", "tracking", "line_spacing", "slice_from", "slice_to",
    "bend", "scale_p", "scale_q", "scale_r", "scale_end",
    "render_scale", "random_scale",
}


def _is_distance_param(param) -> bool:
    try:
        if (param or {}).get("type") != "FLOAT":
            return False
        pid = str((param or {}).get("id") or "")
        if not pid or pid in _DIMENSIONLESS_FLOAT_PARAM_IDS:
            return False
        return pid in _DISTANCE_PARAM_IDS or pid.endswith(_DISTANCE_PARAM_SUFFIXES)
    except Exception:
        return False


def _configure_modifier_socket(socket, param) -> None:
    # Keep every exposed parameter as a direct single value.  Blender 5.1 can
    # still draw native Geometry Nodes modifier sockets as dimmed/field-style
    # rows even when *_use_attribute is false.  The suite therefore hides the
    # native GN socket rows and draws the same modifier ID-property values in
    # a dedicated Properties > Modifiers panel where they are normal active
    # controls.  The sockets remain public, stored on the modifier, and are
    # still used by the runtime regeneration path.
    for attr, value in (
        ("hide_value", False),
        ("hide_in_modifier", True),
        ("force_non_field", True),
        ("structure_type", "SINGLE"),
        ("default_input", "VALUE"),
    ):
        try:
            setattr(socket, attr, value)
        except Exception:
            pass
    try:
        socket.subtype = "DISTANCE" if _is_distance_param(param) else "NONE"
    except Exception:
        pass


def _set_socket_defaults(socket, param) -> None:
    _configure_modifier_socket(socket, param)
    default = param.get("default")
    if param.get("type") != "OBJECT":
        for attr in ("default_value",):
            try:
                setattr(socket, attr, default)
            except Exception:
                pass
    if param.get("min") is not None:
        for attr in ("min_value", "soft_min"):
            try:
                setattr(socket, attr, param["min"])
            except Exception:
                pass
    if param.get("max") is not None:
        for attr in ("max_value", "soft_max"):
            try:
                setattr(socket, attr, param["max"])
            except Exception:
                pass
    desc = param.get("desc_ja") if lang_code() == "ja" else param.get("desc_en")
    try:
        socket.description = desc
    except Exception:
        pass


def _new_socket(tree, name: str, in_out: str, socket_type: str):
    try:
        return tree.interface.new_socket(name=name, in_out=in_out, socket_type=socket_type)
    except TypeError:
        return tree.interface.new_socket(name, in_out, socket_type)


def _socket_from_node_collection(collection, identifier: str, name: str = ""):
    if collection is None:
        return None
    try:
        sock = collection.get(identifier)
        if sock is not None:
            return sock
    except Exception:
        pass
    if name:
        try:
            sock = collection.get(name)
            if sock is not None:
                return sock
        except Exception:
            pass
    try:
        for sock in collection:
            try:
                if str(getattr(sock, "identifier", "") or "") == str(identifier):
                    return sock
            except Exception:
                continue
    except Exception:
        pass
    return None


def _safe_link(links, a, b) -> bool:
    if a is None or b is None:
        return False
    try:
        links.new(a, b)
        return True
    except Exception:
        return False


def _node_input(node, name: str, index: int = 0):
    # Many Geometry Nodes sockets share the same display name, e.g. Math
    # node inputs are all named "Value" and Boolean Math inputs are both
    # named "Boolean".  Blender's collection.get(name) always returns the
    # first one, so callers that request input 1/2 must be able to address by
    # index.  Without this, only the last public modifier input participates in
    # the output dependency chain and the other rows can appear dimmed/inactive
    # in the native Modifier properties panel.
    try:
        if index is not None and int(index) > 0:
            return node.inputs[int(index)]
    except Exception:
        pass
    try:
        sock = node.inputs.get(name)
        if sock is not None:
            return sock
    except Exception:
        pass
    try:
        return node.inputs[index]
    except Exception:
        return None


def _node_output(node, name: str, index: int = 0):
    try:
        return node.outputs.get(name)
    except Exception:
        pass
    try:
        return node.outputs[index]
    except Exception:
        return None


def _append_value_dependency(nodes, links, acc, value_socket, *, y_offset: int) -> object:
    """Append a socket to a numeric dependency chain and return the new output."""
    if value_socket is None:
        return acc
    try:
        add = nodes.new("ShaderNodeMath")
        add.operation = "ADD"
        add.location = (-650, y_offset)
        _safe_link(links, acc, _node_input(add, "Value", 0))
        _safe_link(links, value_socket, _node_input(add, "Value", 1))
        return _node_output(add, "Value", 0) or acc
    except Exception:
        return acc


def _socket_value_dependency(nodes, links, out, param, *, index: int):
    """Return a numeric socket that depends on one exposed modifier input.

    The value is later multiplied by zero, so the dependency never changes the
    generated shape.  It only makes Blender treat every public input as an
    active value input in the native Geometry Nodes modifier UI.
    """
    if out is None:
        return None
    typ = str((param or {}).get("type") or "FLOAT")
    try:
        if typ in {"FLOAT", "INT"}:
            return out
        if typ == "BOOL":
            sw = nodes.new("GeometryNodeSwitch")
            sw.location = (-820, -360 - index * 32)
            try:
                sw.input_type = "FLOAT"
            except Exception:
                pass
            try:
                false_in = _node_input(sw, "False", 1)
                true_in = _node_input(sw, "True", 2)
                if false_in is not None:
                    false_in.default_value = 0.0
                if true_in is not None:
                    true_in.default_value = 1.0
            except Exception:
                pass
            _safe_link(links, out, _node_input(sw, "Switch", 0))
            return _node_output(sw, "Output", 0)
        if typ == "STRING":
            sl = nodes.new("FunctionNodeStringLength")
            sl.location = (-820, -520 - index * 32)
            _safe_link(links, out, _node_input(sl, "String", 0))
            return _node_output(sl, "Length", 0)
        if typ == "OBJECT":
            oi = nodes.new("GeometryNodeObjectInfo")
            vm = nodes.new("ShaderNodeVectorMath")
            oi.location = (-980, -680 - index * 32)
            vm.location = (-760, -680 - index * 32)
            try:
                oi.inputs[1].default_value = False
            except Exception:
                pass
            try:
                vm.operation = "LENGTH"
            except Exception:
                pass
            _safe_link(links, out, _node_input(oi, "Object", 0))
            _safe_link(links, _node_output(oi, "Location", 1), _node_input(vm, "Vector", 0))
            return _node_output(vm, "Value", 1)
    except Exception:
        return None
    return None


def _ensure_modifier_graph(tree: bpy.types.NodeTree, spec: Dict[str, object], socket_map: Dict[str, str]) -> None:
    """Pass geometry through unchanged while every public input stays active.

    Blender 5.1 dims Geometry Nodes modifier inputs that are not part of the
    evaluated node graph.  Earlier builds linked several inputs only to loose
    reroutes, and duplicate socket names on Math / Boolean Math meant only one
    input actually reached the output.  This graph feeds every exposed Max
    Primitive parameter into a numeric no-op chain, multiplies the result by
    zero, and uses it as a Set Position offset.  The final geometry is bit-for-
    bit unchanged, but all modifier rows remain ordinary editable value fields.
    """
    if tree is None:
        return
    try:
        nodes = tree.nodes
        links = tree.links
        nodes.clear()
    except Exception:
        return
    try:
        gi = nodes.new("NodeGroupInput")
        go = nodes.new("NodeGroupOutput")
        sp = nodes.new("GeometryNodeSetPosition")
        zero = nodes.new("ShaderNodeValue")
        mul = nodes.new("ShaderNodeMath")
        cx = nodes.new("ShaderNodeCombineXYZ")
        gi.location = (-1050, 220)
        zero.location = (-1050, -180)
        mul.location = (-240, -40)
        cx.location = (-60, -40)
        sp.location = (160, 120)
        go.location = (440, 120)
        try:
            zero.outputs[0].default_value = 0.0
        except Exception:
            pass
        try:
            mul.operation = "MULTIPLY"
            _node_input(mul, "Value", 1).default_value = 0.0
        except Exception:
            pass
        _safe_link(links, _socket_from_node_collection(gi.outputs, "Socket_0", "Geometry"), _node_input(sp, "Geometry", 0))
        _safe_link(links, _node_output(sp, "Geometry", 0), _socket_from_node_collection(go.inputs, "Socket_1", "Geometry"))
        try:
            sel = _node_input(sp, "Selection", 1)
            if sel is not None:
                sel.default_value = True
        except Exception:
            pass
        acc = _node_output(zero, "Value", 0)
        lang = lang_code()
        dep_index = 0
        for param in spec.get("params", []):
            pid = str(param.get("id") or "")
            ident = socket_map.get(pid)
            if not ident:
                continue
            out = _socket_from_node_collection(gi.outputs, ident, localized(param, lang))
            if out is None:
                continue
            dep = _socket_value_dependency(nodes, links, out, param, index=dep_index)
            if dep is not None:
                acc = _append_value_dependency(nodes, links, acc, dep, y_offset=-40 - dep_index * 32)
                dep_index += 1
        _safe_link(links, acc, _node_input(mul, "Value", 0))
        _safe_link(links, _node_output(mul, "Value", 0), _node_input(cx, "X", 0))
        _safe_link(links, _node_output(zero, "Value", 0), _node_input(cx, "Y", 1))
        _safe_link(links, _node_output(zero, "Value", 0), _node_input(cx, "Z", 2))
        _safe_link(links, _node_output(cx, "Vector", 0), _node_input(sp, "Offset", 3))
    except Exception:
        pass

def _extend_existing_interface(tree: bpy.types.NodeTree, spec: Dict[str, object], socket_map: Dict[str, str]) -> Dict[str, str]:
    lang = lang_code()
    changed = False
    for param in spec.get("params", []):
        if param["id"] in socket_map:
            existing = _find_socket_by_identifier(tree, socket_map.get(param["id"]))
            if existing is not None:
                try:
                    existing.name = localized(param, lang)
                except Exception:
                    pass
                _set_socket_defaults(existing, param)
            continue
        sock = _new_socket(tree, localized(param, lang), "INPUT", _socket_type(param.get("type", "FLOAT")))
        _set_socket_defaults(sock, param)
        identifier = getattr(sock, "identifier", None) or f"{SOCKET_PREFIX}{param['id']}"
        socket_map[param["id"]] = identifier
        changed = True
    if changed:
        tree["jel_socket_map"] = json.dumps(socket_map, ensure_ascii=False)
    enforce_modifier_socket_visibility(tree=tree, spec=spec, socket_map=socket_map)
    return socket_map


def group_name_for(generator_id: str) -> str:
    return GROUP_PREFIX + str(generator_id).replace("_", " ").title()


def rename_saved_groups() -> int:
    """Give groups saved under the earlier name the current one. Sockets and values stay."""
    renamed = 0
    for tree in list(bpy.data.node_groups):
        if not tree.name.startswith(RENAMED_GROUP_PREFIX) or tree.library is not None or not _is_owned(tree):
            continue
        generator_id = tree.get("jel_max_generator_id")
        if not generator_id or group_name_for(generator_id) in bpy.data.node_groups:
            continue
        tree.name = group_name_for(generator_id)
        renamed += 1
    return renamed


def create_or_update_group(generator_id: str, spec: Dict[str, object]) -> Tuple[bpy.types.NodeTree, Dict[str, str]]:
    lang = lang_code()
    rename_saved_groups()
    group_name = group_name_for(generator_id)
    tree = bpy.data.node_groups.get(group_name)
    if tree is not None and not _is_owned(tree):
        # Never rename, rebuild, or adopt a same-name user/foreign tree.
        tree = None
    if tree is not None and tree.bl_idname == "GeometryNodeTree":
        try:
            socket_map = json.loads(tree.get("jel_socket_map", "{}")) if tree.get("jel_socket_map") else {}
        except Exception:
            socket_map = {}
        socket_map = _extend_existing_interface(tree, spec, socket_map)
        _ensure_modifier_graph(tree, spec, socket_map)
        tree["jel_max_interface_build"] = int(INTERFACE_BUILD_VERSION)
        enforce_modifier_socket_visibility(tree=tree, spec=spec, socket_map=socket_map)
        return tree, socket_map

    tree = bpy.data.node_groups.new(group_name, "GeometryNodeTree")
    if not _mark_owned(tree):
        try:
            bpy.data.node_groups.remove(tree)
        except Exception:
            pass
        raise RuntimeError("Max Primitive node-group ownership tagging failed")
    try:
        tree.is_modifier = True
    except Exception:
        pass
    tree["jel_max_generator_id"] = generator_id
    tree["jel_max_generator_name"] = localized(spec["name"], lang)
    tree["jel_max_interface_build"] = int(INTERFACE_BUILD_VERSION)

    geom_in = _new_socket(tree, "Geometry", "INPUT", "NodeSocketGeometry")
    geom_out = _new_socket(tree, "Geometry", "OUTPUT", "NodeSocketGeometry")
    try:
        if lang == "ja":
            geom_in.description = "入力ジオメトリをそのまま通過させます。既存メッシュ上へモディファイアとして置く場合の入力です。"
            geom_out.description = "生成された手続き型プリミティブのジオメトリ出力です。"
        else:
            geom_in.description = "Input geometry pass-through for objects that use this modifier on existing geometry."
            geom_out.description = "Generated procedural primitive geometry output."
    except Exception:
        pass

    socket_map: Dict[str, str] = {}
    for param in spec.get("params", []):
        name = localized(param, lang)
        sock = _new_socket(tree, name, "INPUT", _socket_type(param.get("type", "FLOAT")))
        _set_socket_defaults(sock, param)
        identifier = getattr(sock, "identifier", None) or f"{SOCKET_PREFIX}{param['id']}"
        socket_map[param["id"]] = identifier

    tree["jel_socket_map"] = json.dumps(socket_map, ensure_ascii=False)
    _ensure_modifier_graph(tree, spec, socket_map)
    return tree, socket_map


def _disable_attribute_mode(mod: bpy.types.Modifier, identifier: str) -> None:
    if mod is None or not identifier:
        return
    # Numeric Geometry Nodes modifier inputs can be switched into attribute
    # mode by Blender, which disables the normal value field in the Modifier
    # properties UI.  Max Primitives is parameter-driven, so always keep these
    # public sockets in direct value mode.
    for suffix, value in (("_use_attribute", False), ("_attribute_name", "")):
        key = f"{identifier}{suffix}"
        try:
            mod[key] = value
        except Exception:
            pass


def ensure_modifier(obj: bpy.types.Object, generator_id: str, spec: Dict[str, object], *, initialize_values: bool = False) -> bpy.types.Modifier:
    tree, socket_map = create_or_update_group(generator_id, spec)
    mod = obj.modifiers.get(MODIFIER_NAME)
    if mod is not None and (getattr(mod, 'type', None) != 'NODES' or not is_owned_modifier(mod)):
        mod = None
    if mod is None:
        mod = obj.modifiers.new(MODIFIER_NAME, "NODES")
        if not _mark_owned(mod):
            try:
                obj.modifiers.remove(mod)
            except Exception:
                pass
            raise RuntimeError("Max Primitive modifier ownership tagging failed")
    mod.node_group = tree
    obj["jel_max_socket_map"] = json.dumps(socket_map, ensure_ascii=False)

    # Initialize exposed modifier socket values.
    for param in spec.get("params", []):
        identifier = socket_map.get(param["id"])
        if not identifier:
            continue
        if param.get("type") != "OBJECT":
            try:
                if initialize_values or identifier not in mod:
                    mod[identifier] = param.get("default")
            except Exception:
                pass
            _disable_attribute_mode(mod, identifier)
        # Rich ID property UI metadata for builds where modifier socket metadata is mirrored through ID props.
        try:
            ui = mod.id_properties_ui(identifier)
            kwargs = {"description": param.get("desc_ja") if lang_code() == "ja" else param.get("desc_en")}
            if _is_distance_param(param):
                kwargs["subtype"] = "DISTANCE"
                kwargs["precision"] = 4
            elif param.get("type") == "FLOAT":
                kwargs["subtype"] = "NONE"
            if param.get("min") is not None:
                kwargs["min"] = param.get("min")
                kwargs["soft_min"] = param.get("min")
            if param.get("max") is not None:
                kwargs["max"] = param.get("max")
                kwargs["soft_max"] = param.get("max")
            ui.update(**kwargs)
        except Exception:
            pass
    try:
        mod["jel_max_generator_id"] = generator_id
    except Exception:
        pass
    try:
        enforce_modifier_socket_visibility(obj=obj, tree=tree, spec=spec, socket_map=socket_map)
    except Exception:
        pass
    return mod
