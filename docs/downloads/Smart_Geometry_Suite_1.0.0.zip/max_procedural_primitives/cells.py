"""Convex Voronoi cells for planar fracture and the closed prisms extruded from them."""
from mathutils import Vector
from random import Random
from ..mesh_form import MeshForm,rect_prism
def clip(polygon,normal,limit):
    if not polygon:return []
    result=[];previous=polygon[-1];d0=previous.dot(normal)-limit
    for current in polygon:
        d1=current.dot(normal)-limit
        if (d0<=0)!=(d1<=0):result.append(previous.lerp(current,d0/(d0-d1)))
        if d1<=0:result.append(current)
        previous=current;d0=d1
    return result
def fracture(size,count,gap,seed):
    rng=Random(seed);corners=[Vector((x*size,y*size)) for x,y in ((-.5,-.38),(.5,-.38),(.5,.38),(-.5,.38))]
    sites=[Vector((rng.uniform(-.49,.49)*size,rng.uniform(-.37,.37)*size)) for _ in range(count)]
    for site in sites:
        polygon=corners[:]
        for neighbor in sites:
            if neighbor is site:continue
            direction=neighbor-site;polygon=clip(polygon,direction,(site+neighbor).dot(direction)*.5)
            if len(polygon)<3:break
        if len(polygon)<3:continue
        center=sum(polygon,Vector((0.,0.)))/len(polygon);radius=max((v-center).length for v in polygon)
        shrink=max(.1,1-gap/max(.0001,radius));coords=[center+(v-center)*shrink for v in polygon];depth=size*rng.uniform(.075,.12)
        cell=rect_prism([tuple(v) for v in coords],depth);cell.vertices=[(x,y,z-depth*.5) for x,y,z in cell.vertices];yield cell

