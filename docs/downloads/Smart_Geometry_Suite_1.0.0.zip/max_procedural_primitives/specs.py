# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Generator specifications for Max Primitives.

The schema intentionally stores English and Japanese strings separately.
Runtime code chooses one language according to Blender's UI language.
"""

from __future__ import annotations


CATEGORIES = {
    "standard": {"en": "Standard Primitives", "ja": "標準プリミティブ"},
    "extended": {"en": "Extended Primitives", "ja": "拡張プリミティブ"},
    "aec": {"en": "AEC Extended", "ja": "AEC 拡張"},
    "doors": {"en": "Doors", "ja": "ドア"},
    "windows": {"en": "Windows", "ja": "窓"},
    "stairs": {"en": "Stairs", "ja": "階段"},
    "patch_nurbs": {"en": "Patch / NURBS Surfaces", "ja": "パッチ / NURBS サーフェス"},
    "compound": {"en": "Compound Objects", "ja": "合成オブジェクト"},
}


def p(identifier, en, ja, typ, default, min_value=None, max_value=None, desc_en="", desc_ja="", enum=None):
    return {
        "id": identifier,
        "en": en,
        "ja": ja,
        "type": typ,
        "default": default,
        "min": min_value,
        "max": max_value,
        "desc_en": desc_en or en,
        "desc_ja": desc_ja or ja,
        "enum": enum or [],
    }


def localized(value, lang="en"):
    if isinstance(value, dict):
        return value.get("ja") if lang == "ja" else value.get("en")
    return value


def is_japanese_ui():
    try:
        import bpy
        return bpy.app.translations.locale.startswith("ja") or bpy.context.preferences.view.language.startswith("ja")
    except Exception:
        return False


def lang_code():
    return "ja" if is_japanese_ui() else "en"


P_BOOL_MAP = p(
    "map_coords", "Generate Mapping Coordinates", "マッピング座標を生成", "BOOL", False,
    desc_en="Creates UV coordinates for material mapping. This mirrors the 3ds Max mapCoords option where applicable.",
    desc_ja="マテリアルの貼り付けに使うUV座標を作成します。該当する 3ds Max の mapCoords と同等の項目です。",
)
P_BOOL_REALWORLD = p(
    "real_world_map_size", "Real-World Map Size", "実寸マップサイズ", "BOOL", False,
    desc_en="Uses real-world texture scale metadata where the material pipeline supports it.",
    desc_ja="マテリアル側が対応している場合に、実寸基準のテクスチャスケール情報として扱う項目です。",
)
P_SMOOTH = p(
    "smooth", "Smooth", "スムーズ", "BOOL", True,
    desc_en="Sets generated polygons to smooth shading where the shape supports rounded surfaces.",
    desc_ja="曲面を持つ形状で、生成ポリゴンをスムーズシェーディングにします。",
)
P_SLICE = p(
    "slice_on", "Slice On", "スライス有効", "BOOL", False,
    desc_en="Limits the circular sweep to Slice From and Slice To angles. Turn this on to create an open arc section.",
    desc_ja="円周方向の生成範囲を[スライス開始]と[スライス終了]で制限します。開いた扇形形状を作るときに有効にします。",
)
P_SLICE_FROM = p(
    "slice_from", "Slice From", "スライス開始", "FLOAT", 0.0, -360.0, 360.0,
    desc_en="Start angle in degrees for sliced circular primitives.",
    desc_ja="スライス形状の開始角度です。単位は度です。",
)
P_SLICE_TO = p(
    "slice_to", "Slice To", "スライス終了", "FLOAT", 360.0, -360.0, 360.0,
    desc_en="End angle in degrees for sliced circular primitives.",
    desc_ja="スライス形状の終了角度です。単位は度です。",
)


def circular_common(default_sides=24, include_caps=True):
    items = [
        p("sides", "Sides", "側面数", "INT", default_sides, 3, 3600,
          desc_en="Number of radial sides. Higher values approximate a circle more closely; low values create polygonal forms.",
          desc_ja="円周方向の分割数です。値を上げると円に近づき、低い値では多角形状になります。"),
        P_SMOOTH, P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP, P_BOOL_REALWORLD,
    ]
    if include_caps:
        items.insert(1, p("cap_segments", "Cap Segments", "キャップ セグメント", "INT", 1, 0, 1000,
                          desc_en="Number of concentric cap subdivisions.",
                          desc_ja="上下キャップ面の同心円状分割数です。"))
    return items


def seg(name_id, en, ja, default=1, maximum=1000):
    return p(name_id, en, ja, "INT", default, 1, maximum,
             desc_en=f"Number of subdivisions for {en.lower()}.",
             desc_ja=f"{ja}の分割数です。")


GENERATOR_SPECS = {
    # Standard Primitives
    "standard_box": {
        "category": "standard", "name": {"en": "Box", "ja": "ボックス"},
        "description": {"en": "Parametric rectangular box with length, width, height and segment controls.", "ja": "長さ・幅・高さと各方向の分割数を調整できる直方体です。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 25.0, 0.001, 100000.0, "Dimension along local X.", "ローカルX方向の寸法です。"),
            p("width", "Width", "幅", "FLOAT", 25.0, 0.001, 100000.0, "Dimension along local Y.", "ローカルY方向の寸法です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Dimension along local Z.", "ローカルZ方向の寸法です。"),
            seg("length_segments", "Length Segments", "長さセグメント"),
            seg("width_segments", "Width Segments", "幅セグメント"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_cone": {
        "category": "standard", "name": {"en": "Cone", "ja": "円錐"},
        "description": {"en": "Cone or truncated cone with radius, height, cap, side, smooth and slice controls.", "ja": "上下半径、高さ、キャップ、側面数、スムーズ、スライスを調整できる円錐または切頭円錐です。"},
        "params": [
            p("radius1", "Radius 1", "半径 1", "FLOAT", 15.0, 0.0, 100000.0, "Bottom radius.", "下側の半径です。"),
            p("radius2", "Radius 2", "半径 2", "FLOAT", 0.0, 0.0, 100000.0, "Top radius. Set to zero for a pointed cone.", "上側の半径です。0にすると先端が尖った円錐になります。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, -100000.0, 100000.0, "Height along the local Z axis.", "ローカルZ軸方向の高さです。"),
            seg("height_segments", "Height Segments", "高さセグメント", 5),
        ] + circular_common(24),
    },
    "standard_sphere": {
        "category": "standard", "name": {"en": "Sphere", "ja": "球"},
        "description": {"en": "Pole-based UV sphere matching the standard 3ds Max sphere workflow.", "ja": "上下に極点を持つ、3ds Max の標準球に近いUV球です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 25.0, 0.001, 100000.0, "Sphere radius.", "球の半径です。"),
            p("segments", "Segments", "セグメント", "INT", 32, 4, 3600, "Number of longitudinal divisions.", "経度方向の分割数です。"),
            p("rings", "Rings", "リング", "INT", 16, 2, 1000, "Number of latitude divisions excluding poles.", "極点を除いた緯度方向の分割数です。"),
            P_SMOOTH,
            p("hemisphere", "Hemisphere", "半球", "FLOAT", 0.0, 0.0, 1.0, "Amount of upper hemisphere clipping: 0 is full sphere, 1 is upper half only.", "上半球側の切り詰め量です。0で完全な球、1で上半球のみになります。"),
            p("hemisphere_mode", "Hemisphere Mode", "半球モード", "INT", 0, 0, 1, "0=Chop, 1=Squash. Chop removes the missing part; Squash compresses it.", "0=切り取り、1=押しつぶし。切り取りは欠落部を除去し、押しつぶしは圧縮します。"),
            P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_geosphere": {
        "category": "standard", "name": {"en": "GeoSphere", "ja": "ジオスフィア"},
        "description": {"en": "Triangulated geodesic sphere based on tetrahedron, octahedron or icosahedron subdivisions.", "ja": "四面体・八面体・二十面体を分割して作る三角ポリゴン球です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 25.0, 0.001, 100000.0, "GeoSphere radius.", "ジオスフィアの半径です。"),
            p("segments", "Segments", "セグメント", "INT", 2, 0, 8, "Subdivision level. Higher values increase triangle density.", "三角形の再分割レベルです。値を上げると密度が増えます。"),
            p("base_type", "Base Type", "基本タイプ", "INT", 2, 0, 2, "0=Tetra, 1=Octa, 2=Icosa. Selects the starting polyhedron.", "0=四面体、1=八面体、2=二十面体。開始多面体を選びます。"),
            P_SMOOTH, P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_cylinder": {
        "category": "standard", "name": {"en": "Cylinder", "ja": "円柱"},
        "description": {"en": "Standard cylinder with radius, height, height segment, cap segment, side, smooth and slice controls.", "ja": "半径、高さ、高さ分割、キャップ分割、側面数、スムーズ、スライスを調整できる円柱です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 15.0, 0.001, 100000.0, "Cylinder radius.", "円柱の半径です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, -100000.0, 100000.0, "Height along the local Z axis.", "ローカルZ軸方向の高さです。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
        ] + circular_common(24),
    },
    "standard_tube": {
        "category": "standard", "name": {"en": "Tube", "ja": "チューブ"},
        "description": {"en": "Hollow cylinder with independent outer and inner radii.", "ja": "外半径と内半径を個別に設定できる中空円柱です。"},
        "params": [
            p("radius1", "Radius 1", "半径 1", "FLOAT", 25.0, 0.001, 100000.0, "First radius. The larger radius is treated as the outside radius.", "1つ目の半径です。大きい方が外半径として扱われます。"),
            p("radius2", "Radius 2", "半径 2", "FLOAT", 20.0, 0.0, 100000.0, "Second radius. The smaller radius is treated as the inside radius.", "2つ目の半径です。小さい方が内半径として扱われます。"),
            p("height", "Height", "高さ", "FLOAT", 50.0, -100000.0, 100000.0, "Tube height along local Z.", "ローカルZ方向のチューブ高さです。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
        ] + circular_common(24),
    },
    "standard_torus": {
        "category": "standard", "name": {"en": "Torus", "ja": "トーラス"},
        "description": {"en": "Donut-shaped torus with major/minor radius and segment controls.", "ja": "主半径・副半径と分割数を調整できるドーナツ形状です。"},
        "params": [
            p("radius1", "Radius 1", "半径 1", "FLOAT", 50.0, 0.001, 100000.0, "Major radius from center to tube center.", "中心からチューブ中心までの主半径です。"),
            p("radius2", "Radius 2", "半径 2", "FLOAT", 12.5, 0.001, 100000.0, "Tube radius.", "チューブ部分の半径です。"),
            p("segments", "Segments", "セグメント", "INT", 48, 3, 3600, "Number of divisions around the torus ring.", "トーラス円周方向の分割数です。"),
            p("sides", "Sides", "側面数", "INT", 12, 3, 1000, "Number of divisions around the tube cross-section.", "チューブ断面の分割数です。"),
            P_SMOOTH, P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_pyramid": {
        "category": "standard", "name": {"en": "Pyramid", "ja": "ピラミッド"},
        "description": {"en": "Four-sided pyramid with width, depth, height and segment controls.", "ja": "幅・奥行き・高さと分割数を調整できる四角錐です。"},
        "params": [
            p("width", "Width", "幅", "FLOAT", 25.0, 0.001, 100000.0, "Base width along local X.", "ローカルX方向の底面幅です。"),
            p("depth", "Depth", "奥行き", "FLOAT", 25.0, 0.001, 100000.0, "Base depth along local Y.", "ローカルY方向の底面奥行きです。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, -100000.0, 100000.0, "Pyramid height.", "ピラミッドの高さです。"),
            seg("width_segments", "Width Segments", "幅セグメント"),
            seg("depth_segments", "Depth Segments", "奥行きセグメント"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_teapot": {
        "category": "standard", "name": {"en": "Teapot", "ja": "ティーポット"},
        "description": {"en": "Procedural test teapot proxy with body, handle, spout and lid toggles.", "ja": "本体・取っ手・注ぎ口・蓋を切り替えられる、テスト用ティーポット近似形状です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 25.0, 0.001, 100000.0, "Overall teapot size.", "ティーポット全体のサイズです。"),
            p("segments", "Segments", "セグメント", "INT", 16, 4, 256, "Resolution used for rounded parts.", "丸いパーツに使う解像度です。"),
            P_SMOOTH,
            p("body", "Body", "本体", "BOOL", True, desc_en="Generate the teapot body.", desc_ja="本体を生成します。"),
            p("handle", "Handle", "取っ手", "BOOL", True, desc_en="Generate the handle.", desc_ja="取っ手を生成します。"),
            p("spout", "Spout", "注ぎ口", "BOOL", True, desc_en="Generate the spout.", desc_ja="注ぎ口を生成します。"),
            p("lid", "Lid", "蓋", "BOOL", True, desc_en="Generate the lid.", desc_ja="蓋を生成します。"),
            P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_plane": {
        "category": "standard", "name": {"en": "Plane", "ja": "平面"},
        "description": {"en": "Rectangular grid plane with editable subdivisions.", "ja": "分割数を後から調整できる長方形グリッド平面です。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 25.0, 0.001, 100000.0, "Plane length along local X.", "ローカルX方向の平面長さです。"),
            p("width", "Width", "幅", "FLOAT", 25.0, 0.001, 100000.0, "Plane width along local Y.", "ローカルY方向の平面幅です。"),
            seg("length_segments", "Length Segments", "長さセグメント", 1),
            seg("width_segments", "Width Segments", "幅セグメント", 1),
            P_BOOL_MAP, P_BOOL_REALWORLD,
        ],
    },
    "standard_textplus": {
        "category": "standard", "name": {"en": "TextPlus", "ja": "テキストプラス"},
        "description": {"en": "3D text object with size, extrusion, bevel and resolution controls.", "ja": "サイズ、押し出し、ベベル、解像度を調整できる3Dテキストです。"},
        "object_type": "FONT",
        "params": [
            p("text", "Text", "テキスト", "STRING", "TextPlus", desc_en="Text string to display.", desc_ja="表示する文字列です。"),
            p("size", "Size", "サイズ", "FLOAT", 10.0, 0.001, 100000.0, "Font size.", "フォントサイズです。"),
            p("extrude", "Extrude", "押し出し", "FLOAT", 1.0, 0.0, 100000.0, "Depth extrusion amount.", "奥行き方向の押し出し量です。"),
            p("bevel_depth", "Bevel Depth", "ベベル深度", "FLOAT", 0.0, 0.0, 100000.0, "Rounded bevel depth around text outlines.", "文字輪郭に付けるベベルの深さです。"),
            p("bevel_segments", "Bevel Segments", "ベベル セグメント", "INT", 0, 0, 64, "Number of bevel subdivisions.", "ベベル部分の分割数です。"),
            p("resolution", "Resolution", "解像度", "INT", 12, 1, 64, "Curve resolution for round outlines.", "丸い文字輪郭の曲線解像度です。"),
            p("align", "Alignment", "配置", "INT", 0, 0, 2, "0=Left, 1=Center, 2=Right.", "0=左、1=中央、2=右。"),
        ],
    },
}

# Extended Primitives
GENERATOR_SPECS.update({
    "extended_hedra": {
        "category": "extended", "name": {"en": "Hedra", "ja": "面分割"},
        "description": {"en": "Parametric polyhedron family including tetrahedron, octahedron, icosahedron and star variants.", "ja": "四面体、八面体、二十面体、星型などの多面体ファミリーです。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 25.0, 0.001, 100000.0, "Base radius of the polyhedron.", "多面体の基準半径です。"),
            p("family", "Family", "ファミリー", "INT", 2, 0, 5, "0=Tetra, 1=Cube, 2=Octa, 3=Dodeca, 4=Icosa, 5=Star.", "0=四面体、1=立方体、2=八面体、3=十二面体、4=二十面体、5=星型。"),
            p("p", "P", "P", "FLOAT", 0.5, 0.0, 1.0, "Shape blend control P.", "形状ブレンド用のP値です。"),
            p("q", "Q", "Q", "FLOAT", 0.5, 0.0, 1.0, "Shape blend control Q.", "形状ブレンド用のQ値です。"),
            p("scale_p", "Scale P", "スケール P", "FLOAT", 1.0, 0.001, 1000.0, "Scale factor for P-axis vertices.", "P軸頂点のスケール係数です。"),
            p("scale_q", "Scale Q", "スケール Q", "FLOAT", 1.0, 0.001, 1000.0, "Scale factor for Q-axis vertices.", "Q軸頂点のスケール係数です。"),
            p("scale_r", "Scale R", "スケール R", "FLOAT", 1.0, 0.001, 1000.0, "Scale factor for R-axis vertices.", "R軸頂点のスケール係数です。"),
            P_BOOL_MAP,
        ],
    },
    "extended_torusknot": {
        "category": "extended", "name": {"en": "Torus Knot", "ja": "トーラス ノット"},
        "description": {"en": "Tubular torus knot with P/Q winding controls.", "ja": "P/Qの巻き数を持つチューブ状トーラスノットです。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 50.0, 0.001, 100000.0, "Major knot radius.", "ノット全体の主半径です。"),
            p("tube_radius", "Tube Radius", "チューブ半径", "FLOAT", 5.0, 0.001, 100000.0, "Radius of the generated tube.", "生成チューブの半径です。"),
            p("p", "P", "P", "INT", 2, 1, 64, "Longitudinal winding count.", "長手方向の巻き数です。"),
            p("q", "Q", "Q", "INT", 3, 1, 64, "Meridional winding count.", "子午線方向の巻き数です。"),
            p("segments", "Segments", "セグメント", "INT", 160, 8, 3600, "Curve subdivisions around the knot.", "ノット曲線の分割数です。"),
            p("sides", "Sides", "側面数", "INT", 12, 3, 256, "Tube cross-section subdivisions.", "チューブ断面の分割数です。"),
            p("eccentricity", "Eccentricity", "偏心", "FLOAT", 1.0, 0.0, 10.0, "Scales the minor knot displacement.", "ノットの副方向変位をスケールします。"),
            p("twist", "Twist", "ツイスト", "FLOAT", 0.0, -3600.0, 3600.0, "Additional tube twist in degrees.", "チューブ断面に追加するねじれ角です。"),
            P_SMOOTH, P_BOOL_MAP,
        ],
    },
    "extended_chamferbox": {
        "category": "extended", "name": {"en": "ChamferBox", "ja": "面取りボックス"},
        "description": {"en": "Box with chamfered or rounded edges.", "ja": "エッジに面取りまたは丸みを付けたボックスです。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 25.0, 0.001, 100000.0, "Dimension along X.", "X方向寸法です。"),
            p("width", "Width", "幅", "FLOAT", 25.0, 0.001, 100000.0, "Dimension along Y.", "Y方向寸法です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Dimension along Z.", "Z方向寸法です。"),
            p("fillet", "Fillet", "フィレット", "FLOAT", 2.0, 0.0, 100000.0, "Amount removed from each edge for chamfering.", "エッジから切り取る面取り量です。"),
            seg("length_segments", "Length Segments", "長さセグメント"),
            seg("width_segments", "Width Segments", "幅セグメント"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            p("fillet_segments", "Fillet Segments", "フィレット セグメント", "INT", 2, 1, 128, "Subdivisions used to round the fillet.", "フィレットを丸める分割数です。"),
            P_SMOOTH, P_BOOL_MAP,
        ],
    },
    "extended_chamfercyl": {
        "category": "extended", "name": {"en": "ChamferCyl", "ja": "面取り円柱"},
        "description": {"en": "Cylinder with filleted top and bottom rim edges.", "ja": "上下リムにフィレットを持つ円柱です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 15.0, 0.001, 100000.0, "Cylinder radius.", "円柱半径です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, -100000.0, 100000.0, "Cylinder height.", "円柱高さです。"),
            p("fillet", "Fillet", "フィレット", "FLOAT", 2.0, 0.0, 100000.0, "Rim chamfer amount.", "リムの面取り量です。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            p("fillet_segments", "Fillet Segments", "フィレット セグメント", "INT", 2, 1, 128, "Subdivisions used for the rounded rim.", "丸いリムに使う分割数です。"),
            p("cap_segments", "Cap Segments", "キャップ セグメント", "INT", 1, 0, 1000, "Concentric cap subdivisions.", "キャップ面の同心円分割数です。"),
            p("sides", "Sides", "側面数", "INT", 24, 3, 3600, "Number of radial sides.", "円周方向の分割数です。"),
            P_SMOOTH, P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP,
        ],
    },
    "extended_oiltank": {
        "category": "extended", "name": {"en": "OilTank", "ja": "オイル タンク"},
        "description": {"en": "Cylinder with domed caps at both ends.", "ja": "両端がドーム状になった円柱タンクです。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 15.0, 0.001, 100000.0, "Tank radius.", "タンク半径です。"),
            p("height", "Height", "高さ", "FLOAT", 50.0, 0.001, 100000.0, "Overall tank height.", "タンク全体の高さです。"),
            p("cap_height", "Cap Height", "キャップ高さ", "FLOAT", 8.0, 0.0, 100000.0, "Height of each domed cap.", "各ドームキャップの高さです。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            p("cap_segments", "Cap Segments", "キャップ セグメント", "INT", 4, 1, 256, "Segments used for each dome.", "各ドームに使う分割数です。"),
            p("sides", "Sides", "側面数", "INT", 24, 3, 3600, "Radial sides around the tank.", "タンク円周方向の分割数です。"),
            P_SMOOTH, P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP,
        ],
    },
    "extended_capsule": {
        "category": "extended", "name": {"en": "Capsule", "ja": "カプセル"},
        "description": {"en": "Cylinder with hemispherical caps.", "ja": "両端が半球になった円柱です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 15.0, 0.001, 100000.0, "Capsule radius.", "カプセル半径です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Capsule height. Interpreted according to Height Type.", "高さタイプに従って解釈されるカプセル高さです。"),
            p("height_type", "Height Type", "高さタイプ", "INT", 1, 0, 1, "0=Overall, 1=Centers. Overall includes caps; Centers measures the straight body between cap centers.", "0=全体、1=中心間。全体はキャップ込み、中心間はキャップ中心同士の距離です。"),
            p("sides", "Sides", "側面数", "INT", 24, 3, 3600, "Radial sides.", "円周方向分割数です。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            p("cap_segments", "Cap Segments", "キャップ セグメント", "INT", 8, 1, 256, "Segments per hemispherical cap.", "半球キャップごとの分割数です。"),
            P_SMOOTH, P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP,
        ],
    },
    "extended_spindle": {
        "category": "extended", "name": {"en": "Spindle", "ja": "スピンドル"},
        "description": {"en": "Cylinder with conical caps at both ends.", "ja": "両端が円錐になった円柱です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 15.0, 0.001, 100000.0, "Body radius.", "本体半径です。"),
            p("height", "Height", "高さ", "FLOAT", 50.0, 0.001, 100000.0, "Overall spindle height.", "スピンドル全体の高さです。"),
            p("cap_height", "Cap Height", "キャップ高さ", "FLOAT", 10.0, 0.0, 100000.0, "Cone height at each end.", "各端の円錐高さです。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            p("sides", "Sides", "側面数", "INT", 24, 3, 3600, "Radial sides.", "円周方向分割数です。"),
            P_SMOOTH, P_SLICE, P_SLICE_FROM, P_SLICE_TO, P_BOOL_MAP,
        ],
    },
    "extended_l_ext": {
        "category": "extended", "name": {"en": "L-Ext", "ja": "L-Ext"},
        "description": {"en": "L-shaped extruded wall profile.", "ja": "L字断面を高さ方向に押し出す壁形状です。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 60.0, 0.001, 100000.0, "Long leg length.", "長い辺の長さです。"),
            p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Short leg length.", "短い辺の長さです。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Extrusion height.", "押し出し高さです。"),
            p("thickness", "Thickness", "厚み", "FLOAT", 8.0, 0.001, 100000.0, "Wall thickness.", "壁の厚みです。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            P_BOOL_MAP,
        ],
    },
    "extended_gengon": {
        "category": "extended", "name": {"en": "Gengon", "ja": "ジェンゴン"},
        "description": {"en": "Regular polygonal column with optional edge fillet.", "ja": "エッジの面取りが可能な正多角形柱です。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 15.0, 0.001, 100000.0, "Circumradius of the polygon.", "多角形の外接円半径です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Column height.", "柱の高さです。"),
            p("sides", "Sides", "側面数", "INT", 6, 3, 3600, "Number of polygon sides.", "多角形の辺数です。"),
            p("fillet", "Fillet", "フィレット", "FLOAT", 0.0, 0.0, 100000.0, "Edge chamfer amount.", "エッジ面取り量です。"),
            p("fillet_segments", "Fillet Segments", "フィレット セグメント", "INT", 1, 1, 128, "Fillet subdivisions.", "フィレット分割数です。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            p("cap_segments", "Cap Segments", "キャップ セグメント", "INT", 1, 0, 1000, "Cap subdivisions.", "キャップ分割数です。"),
            P_SMOOTH, P_BOOL_MAP,
        ],
    },
    "extended_c_ext": {
        "category": "extended", "name": {"en": "C-Ext", "ja": "C-Ext"},
        "description": {"en": "C-shaped extruded wall profile.", "ja": "C字断面を高さ方向に押し出す壁形状です。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 60.0, 0.001, 100000.0, "Outer length.", "外形の長さです。"),
            p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Outer width.", "外形の幅です。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Extrusion height.", "押し出し高さです。"),
            p("thickness", "Thickness", "厚み", "FLOAT", 8.0, 0.001, 100000.0, "Wall thickness.", "壁の厚みです。"),
            p("opening", "Opening", "開口", "FLOAT", 20.0, 0.0, 100000.0, "Opening size on one side of the C profile.", "C字形状の開口幅です。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            P_BOOL_MAP,
        ],
    },
    "extended_ringwave": {
        "category": "extended", "name": {"en": "RingWave", "ja": "リングウェーブ"},
        "description": {"en": "Animated wave ring with controllable amplitude, cycles and phase.", "ja": "振幅、波数、位相を調整できる波打つリング形状です。"},
        "params": [
            p("outer_radius", "Outer Radius", "外半径", "FLOAT", 50.0, 0.001, 100000.0, "Outer ring radius.", "リングの外半径です。"),
            p("inner_radius", "Inner Radius", "内半径", "FLOAT", 35.0, 0.0, 100000.0, "Inner ring radius.", "リングの内半径です。"),
            p("height", "Height", "高さ", "FLOAT", 2.0, 0.0, 100000.0, "Ring thickness along Z.", "Z方向のリング厚みです。"),
            p("segments", "Segments", "セグメント", "INT", 128, 8, 3600, "Radial wave subdivisions.", "波形円周方向の分割数です。"),
            p("waves", "Waves", "波数", "INT", 8, 1, 512, "Number of wave peaks around the ring.", "リング円周上の波の数です。"),
            p("amplitude", "Amplitude", "振幅", "FLOAT", 5.0, -100000.0, 100000.0, "Wave height amplitude.", "波の高さ振幅です。"),
            p("phase", "Phase", "位相", "FLOAT", 0.0, -36000.0, 36000.0, "Wave phase in degrees. Animate this to move the wave.", "波の位相です。単位は度です。アニメーションさせると波が動きます。"),
            P_SMOOTH, P_BOOL_MAP,
        ],
    },
    "extended_hose": {
        "category": "extended", "name": {"en": "Hose", "ja": "ホース"},
        "description": {"en": "Corrugated hose tube with length, radius and cycle controls.", "ja": "長さ、半径、蛇腹周期を調整できる蛇腹状チューブです。"},
        "params": [
            p("radius", "Radius", "半径", "FLOAT", 10.0, 0.001, 100000.0, "Base hose radius.", "ホースの基準半径です。"),
            p("length", "Length", "長さ", "FLOAT", 80.0, 0.001, 100000.0, "Hose length along local Z.", "ローカルZ方向のホース長です。"),
            p("segments", "Segments", "セグメント", "INT", 96, 4, 3600, "Lengthwise subdivisions.", "長さ方向の分割数です。"),
            p("sides", "Sides", "側面数", "INT", 16, 3, 256, "Radial side count.", "円周方向分割数です。"),
            p("cycles", "Cycles", "サイクル", "INT", 16, 1, 1000, "Number of corrugation cycles.", "蛇腹の繰り返し数です。"),
            p("amplitude", "Amplitude", "振幅", "FLOAT", 2.0, 0.0, 100000.0, "Corrugation radius variation.", "蛇腹による半径変化量です。"),
            p("bend", "Bend", "曲げ", "FLOAT", 0.0, -360.0, 360.0, "Simple arc bend angle in degrees.", "単純な円弧曲げ角です。単位は度です。"),
            P_SMOOTH, P_BOOL_MAP,
        ],
    },
    "extended_prism": {
        "category": "extended", "name": {"en": "Prism", "ja": "プリズム"},
        "description": {"en": "Triangular prism with width, depth and height controls.", "ja": "幅、奥行き、高さを調整できる三角柱です。"},
        "params": [
            p("width", "Width", "幅", "FLOAT", 30.0, 0.001, 100000.0, "Triangle base width.", "三角形底辺の幅です。"),
            p("depth", "Depth", "奥行き", "FLOAT", 30.0, 0.001, 100000.0, "Triangle depth/height in cross-section.", "断面三角形の奥行き高さです。"),
            p("height", "Height", "高さ", "FLOAT", 25.0, 0.001, 100000.0, "Extrusion height.", "押し出し高さです。"),
            seg("height_segments", "Height Segments", "高さセグメント"),
            P_BOOL_MAP,
        ],
    },
})

# AEC, Doors, Windows, Stairs, Patch/NURBS and Compound Objects
GENERATOR_SPECS.update({
    "aec_foliage": {
        "category": "aec", "name": {"en": "Foliage", "ja": "植物"},
        "description": {"en": "Procedural plant/tree generator with deterministic seed and density controls.", "ja": "シードと密度で制御できる簡易植物・樹木ジェネレーターです。"},
        "params": [
            p("plant_type", "Plant Type", "植物タイプ", "INT", 0, 0, 4, "0=Broadleaf Tree, 1=Conifer, 2=Shrub, 3=Grass, 4=Palm.", "0=広葉樹、1=針葉樹、2=低木、3=草、4=ヤシ。"),
            p("height", "Height", "高さ", "FLOAT", 80.0, 0.001, 100000.0, "Overall plant height.", "植物全体の高さです。"),
            p("density", "Density", "密度", "FLOAT", 1.0, 0.0, 10.0, "Leaf and branch density multiplier.", "葉と枝の密度倍率です。"),
            p("seed", "Seed", "シード", "INT", 1, 0, 1000000, "Deterministic random seed.", "同じ値で同じランダム配置になるシードです。"),
            p("trunk_radius", "Trunk Radius", "幹半径", "FLOAT", 4.0, 0.001, 100000.0, "Trunk radius.", "幹の半径です。"),
            p("leaf_size", "Leaf Size", "葉サイズ", "FLOAT", 8.0, 0.001, 100000.0, "Generated leaf cluster size.", "生成される葉クラスタのサイズです。"),
            p("branches", "Branches", "枝数", "INT", 12, 0, 512, "Number of primary branches.", "主枝の本数です。"),
            P_BOOL_MAP,
        ],
    },
    "aec_railing": {
        "category": "aec", "name": {"en": "Railing", "ja": "手すり"},
        "description": {"en": "Straight railing/fence generator with posts, rails and balusters.", "ja": "親柱、手すり、手すり子を生成する直線手すり・フェンスです。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 120.0, 0.001, 100000.0, "Railing run length.", "手すりの直線長さです。"),
            p("height", "Height", "高さ", "FLOAT", 40.0, 0.001, 100000.0, "Railing height.", "手すりの高さです。"),
            p("post_spacing", "Post Spacing", "親柱間隔", "FLOAT", 30.0, 0.001, 100000.0, "Distance between posts.", "親柱同士の間隔です。"),
            p("post_radius", "Post Radius", "親柱半径", "FLOAT", 2.0, 0.001, 100000.0, "Post radius.", "親柱の半径です。"),
            p("rail_radius", "Rail Radius", "手すり半径", "FLOAT", 1.5, 0.001, 100000.0, "Rail tube radius.", "手すりチューブの半径です。"),
            p("rails", "Rails", "横桟数", "INT", 2, 1, 32, "Number of horizontal rails.", "横方向のレール本数です。"),
            p("baluster_spacing", "Baluster Spacing", "手すり子間隔", "FLOAT", 12.0, 0.0, 100000.0, "Distance between balusters. Set 0 to disable.", "手すり子の間隔です。0で無効です。"),
            P_BOOL_MAP,
        ],
    },
    "aec_wall": {
        "category": "aec", "name": {"en": "Wall", "ja": "壁"},
        "description": {"en": "Parametric straight wall with height, thickness and segmentation controls.", "ja": "高さ、厚み、分割数を調整できる直線壁です。"},
        "params": [
            p("length", "Length", "長さ", "FLOAT", 120.0, 0.001, 100000.0, "Wall length.", "壁の長さです。"),
            p("width", "Width", "幅", "FLOAT", 12.0, 0.001, 100000.0, "Wall thickness/width.", "壁の厚み・幅です。"),
            p("height", "Height", "高さ", "FLOAT", 60.0, 0.001, 100000.0, "Wall height.", "壁の高さです。"),
            seg("segments", "Segments", "セグメント", 1),
            p("bottom_offset", "Bottom Offset", "下オフセット", "FLOAT", 0.0, -100000.0, 100000.0, "Vertical offset at wall bottom.", "壁下端の垂直オフセットです。"),
            p("top_offset", "Top Offset", "上オフセット", "FLOAT", 0.0, -100000.0, 100000.0, "Vertical offset at wall top.", "壁上端の垂直オフセットです。"),
            P_BOOL_MAP,
        ],
    },
})


def door_params(kind):
    common = [
        p("width", "Width", "幅", "FLOAT", 36.0, 0.001, 100000.0, "Door width.", "ドア幅です。"),
        p("height", "Height", "高さ", "FLOAT", 80.0, 0.001, 100000.0, "Door height.", "ドア高さです。"),
        p("depth", "Depth", "奥行き", "FLOAT", 4.0, 0.001, 100000.0, "Door and frame depth.", "ドアと枠の奥行きです。"),
        p("frame_width", "Frame Width", "枠幅", "FLOAT", 4.0, 0.0, 100000.0, "Frame border width.", "枠の幅です。"),
        p("panel_thickness", "Panel Thickness", "パネル厚み", "FLOAT", 2.0, 0.001, 100000.0, "Door panel thickness.", "ドアパネルの厚みです。"),
        p("open", "Open", "開き", "FLOAT", 0.0, 0.0, 100.0, "Open amount in percent.", "開き量です。単位はパーセントです。"),
        p("flip_swing", "Flip Swing", "開き方向反転", "BOOL", False, desc_en="Flips hinge or sliding direction.", desc_ja="蝶番方向またはスライド方向を反転します。"),
        P_BOOL_MAP,
    ]
    if kind == "pivot":
        common.insert(6, p("double_door", "Double Door", "両開き", "BOOL", False, desc_en="Generates two mirrored pivot panels.", desc_ja="左右対称の2枚扉を生成します。"))
    if kind == "sliding":
        common.insert(6, p("panels", "Panels", "パネル数", "INT", 2, 1, 8, "Number of sliding panels.", "スライド扉のパネル数です。"))
    if kind == "bifold":
        common.insert(6, p("folds", "Folds", "折り数", "INT", 2, 2, 8, "Number of folding leaves.", "折りたたみ扉の枚数です。"))
    return common

GENERATOR_SPECS.update({
    "door_pivot": {"category": "doors", "name": {"en": "Pivot Door", "ja": "ピボット ドア"}, "description": {"en": "Swinging pivot door with adjustable opening.", "ja": "開き量を調整できるピボット式ドアです。"}, "params": door_params("pivot")},
    "door_sliding": {"category": "doors", "name": {"en": "Sliding Door", "ja": "スライディング ドア"}, "description": {"en": "Sliding panel door with percent open control.", "ja": "開き率を調整できるスライディング式ドアです。"}, "params": door_params("sliding")},
    "door_bifold": {"category": "doors", "name": {"en": "BiFold Door", "ja": "バイフォールド ドア"}, "description": {"en": "Folding door with multiple hinged leaves.", "ja": "複数の折りたたみパネルを持つバイフォールド式ドアです。"}, "params": door_params("bifold")},
})


def window_params(kind):
    common = [
        p("width", "Width", "幅", "FLOAT", 48.0, 0.001, 100000.0, "Window width.", "窓幅です。"),
        p("height", "Height", "高さ", "FLOAT", 36.0, 0.001, 100000.0, "Window height.", "窓高さです。"),
        p("depth", "Depth", "奥行き", "FLOAT", 4.0, 0.001, 100000.0, "Frame depth.", "枠の奥行きです。"),
        p("frame_width", "Frame Width", "枠幅", "FLOAT", 3.0, 0.0, 100000.0, "Frame border width.", "枠の幅です。"),
        p("muntins", "Muntins", "桟数", "INT", 1, 0, 16, "Number of interior divider bars.", "内側の仕切り桟数です。"),
        p("open", "Open", "開き", "FLOAT", 0.0, 0.0, 100.0, "Open amount in percent.", "開き量です。単位はパーセントです。"),
        p("glass_thickness", "Glass Thickness", "ガラス厚み", "FLOAT", 0.5, 0.0, 100000.0, "Glass pane thickness.", "ガラス板の厚みです。"),
        P_BOOL_MAP,
    ]
    if kind in {"casement", "pivoted", "projected", "awning"}:
        common.insert(6, p("open_angle", "Open Angle", "開き角度", "FLOAT", 0.0, -180.0, 180.0, "Opening angle in degrees.", "開き角度です。単位は度です。"))
    if kind == "sliding":
        common.insert(6, p("panels", "Panels", "パネル数", "INT", 2, 1, 8, "Number of sliding panels.", "スライド窓のパネル数です。"))
    return common

GENERATOR_SPECS.update({
    "window_awning": {"category": "windows", "name": {"en": "Awning Window", "ja": "オーニング窓"}, "description": {"en": "Top-hinged awning window.", "ja": "上部を軸に開くオーニング窓です。"}, "params": window_params("awning")},
    "window_casement": {"category": "windows", "name": {"en": "Casement Window", "ja": "ケースメント窓"}, "description": {"en": "Side-hinged casement window.", "ja": "側面蝶番で開くケースメント窓です。"}, "params": window_params("casement")},
    "window_fixed": {"category": "windows", "name": {"en": "Fixed Window", "ja": "固定窓"}, "description": {"en": "Non-opening fixed window.", "ja": "開閉しない固定窓です。"}, "params": window_params("fixed")},
    "window_pivoted": {"category": "windows", "name": {"en": "Pivoted Window", "ja": "ピボット窓"}, "description": {"en": "Window rotating around a central pivot.", "ja": "中央軸を中心に回転するピボット窓です。"}, "params": window_params("pivoted")},
    "window_projected": {"category": "windows", "name": {"en": "Projected Window", "ja": "プロジェクト窓"}, "description": {"en": "Projected window with tilted sash.", "ja": "サッシが外側に傾くプロジェクト窓です。"}, "params": window_params("projected")},
    "window_sliding": {"category": "windows", "name": {"en": "Sliding Window", "ja": "スライディング窓"}, "description": {"en": "Sliding panel window.", "ja": "横方向にスライドする窓です。"}, "params": window_params("sliding")},
})

GENERATOR_SPECS.update({
    "stairs_straight": {"category": "stairs", "name": {"en": "Straight Stair", "ja": "ストレート階段"}, "description": {"en": "Straight run stair generator.", "ja": "直線状の階段ジェネレーターです。"}, "params": [
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Stair width.", "階段幅です。"),
        p("height", "Height", "高さ", "FLOAT", 60.0, 0.001, 100000.0, "Total stair height.", "階段全体の高さです。"),
        p("length", "Length", "長さ", "FLOAT", 100.0, 0.001, 100000.0, "Total stair run length.", "階段全体の踏み方向長さです。"),
        p("risers", "Risers", "蹴上数", "INT", 12, 1, 1000, "Number of risers/steps.", "蹴上または段数です。"),
        p("tread_thickness", "Tread Thickness", "踏板厚み", "FLOAT", 2.0, 0.0, 100000.0, "Thickness of each tread block.", "各踏板ブロックの厚みです。"),
        p("stringers", "Stringers", "側板", "BOOL", False, desc_en="Adds side stringer boards.", desc_ja="左右の側板を追加します。"),
        P_BOOL_MAP,
    ]},
    "stairs_l": {"category": "stairs", "name": {"en": "L Type Stair", "ja": "L型階段"}, "description": {"en": "Stair with a quarter-turn landing.", "ja": "踊り場で90度曲がるL型階段です。"}, "params": [
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Stair width.", "階段幅です。"),
        p("height", "Height", "高さ", "FLOAT", 60.0, 0.001, 100000.0, "Total stair height.", "階段全体の高さです。"),
        p("length1", "Length 1", "長さ 1", "FLOAT", 70.0, 0.001, 100000.0, "First run length.", "1本目の階段長さです。"),
        p("length2", "Length 2", "長さ 2", "FLOAT", 70.0, 0.001, 100000.0, "Second run length.", "2本目の階段長さです。"),
        p("risers", "Risers", "蹴上数", "INT", 14, 2, 1000, "Number of risers/steps.", "蹴上または段数です。"),
        p("landing", "Landing Size", "踊り場サイズ", "FLOAT", 40.0, 0.001, 100000.0, "Landing size at the turn.", "曲がり部分の踊り場サイズです。"),
        P_BOOL_MAP,
    ]},
    "stairs_u": {"category": "stairs", "name": {"en": "U Type Stair", "ja": "U型階段"}, "description": {"en": "Stair with a half-turn landing.", "ja": "踊り場で180度折り返すU型階段です。"}, "params": [
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Stair width.", "階段幅です。"),
        p("height", "Height", "高さ", "FLOAT", 60.0, 0.001, 100000.0, "Total stair height.", "階段全体の高さです。"),
        p("length", "Length", "長さ", "FLOAT", 70.0, 0.001, 100000.0, "Each run length.", "各階段ランの長さです。"),
        p("risers", "Risers", "蹴上数", "INT", 16, 2, 1000, "Number of risers/steps.", "蹴上または段数です。"),
        p("landing", "Landing Size", "踊り場サイズ", "FLOAT", 40.0, 0.001, 100000.0, "Landing size between runs.", "折り返し踊り場のサイズです。"),
        P_BOOL_MAP,
    ]},
    "stairs_spiral": {"category": "stairs", "name": {"en": "Spiral Stair", "ja": "スパイラル階段"}, "description": {"en": "Spiral stair with radius, turns and step count controls.", "ja": "半径、回転数、段数を調整できる螺旋階段です。"}, "params": [
        p("radius", "Radius", "半径", "FLOAT", 45.0, 0.001, 100000.0, "Outer stair radius.", "階段外周半径です。"),
        p("inner_radius", "Inner Radius", "内半径", "FLOAT", 8.0, 0.0, 100000.0, "Central clear radius.", "中央の空き半径です。"),
        p("height", "Height", "高さ", "FLOAT", 80.0, 0.001, 100000.0, "Total stair height.", "階段全体の高さです。"),
        p("turns", "Turns", "回転数", "FLOAT", 1.5, 0.1, 1000.0, "Number of spiral turns.", "螺旋の回転数です。"),
        p("steps", "Steps", "段数", "INT", 18, 1, 2000, "Number of steps.", "段数です。"),
        p("center_pole", "Center Pole", "中心柱", "BOOL", True, desc_en="Adds a central pole.", desc_ja="中央柱を追加します。"),
        P_BOOL_MAP,
    ]},
})

GENERATOR_SPECS.update({
    "patch_quad": {"category": "patch_nurbs", "name": {"en": "Quad Patch", "ja": "クアッド パッチ"}, "description": {"en": "Editable quad patch grid approximation.", "ja": "編集可能なクアッドパッチ近似グリッドです。"}, "params": [
        p("length", "Length", "長さ", "FLOAT", 40.0, 0.001, 100000.0, "Patch length.", "パッチ長さです。"),
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Patch width.", "パッチ幅です。"),
        p("length_segments", "Length Segments", "長さセグメント", "INT", 4, 1, 256, "Subdivisions along length.", "長さ方向の分割数です。"),
        p("width_segments", "Width Segments", "幅セグメント", "INT", 4, 1, 256, "Subdivisions along width.", "幅方向の分割数です。"),
        p("curvature", "Curvature", "曲率", "FLOAT", 0.0, -100000.0, 100000.0, "Simple center bulge amount.", "中央の膨らみ量です。"),
    ]},
    "patch_tri": {"category": "patch_nurbs", "name": {"en": "Tri Patch", "ja": "トライ パッチ"}, "description": {"en": "Triangular patch grid approximation.", "ja": "三角パッチ近似グリッドです。"}, "params": [
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Triangle width.", "三角形の幅です。"),
        p("height", "Height", "高さ", "FLOAT", 40.0, 0.001, 100000.0, "Triangle height.", "三角形の高さです。"),
        p("segments", "Segments", "セグメント", "INT", 6, 1, 256, "Triangular subdivision level.", "三角形分割レベルです。"),
        p("curvature", "Curvature", "曲率", "FLOAT", 0.0, -100000.0, 100000.0, "Simple center bulge amount.", "中央の膨らみ量です。"),
    ]},
    "nurbs_point": {"category": "patch_nurbs", "name": {"en": "Point Surf", "ja": "ポイント サーフェス"}, "description": {"en": "Point-controlled NURBS surface approximation.", "ja": "ポイント制御NURBSサーフェス近似です。"}, "params": [
        p("length", "Length", "長さ", "FLOAT", 40.0, 0.001, 100000.0, "Surface length.", "サーフェス長さです。"),
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Surface width.", "サーフェス幅です。"),
        p("u_points", "U Points", "Uポイント", "INT", 4, 2, 64, "Control points in U direction.", "U方向の制御点数です。"),
        p("v_points", "V Points", "Vポイント", "INT", 4, 2, 64, "Control points in V direction.", "V方向の制御点数です。"),
        p("curvature", "Curvature", "曲率", "FLOAT", 8.0, -100000.0, 100000.0, "Analytic surface curvature amount.", "解析的な曲面変形量です。"),
    ]},
    "nurbs_cv": {"category": "patch_nurbs", "name": {"en": "CV Surf", "ja": "CV サーフェス"}, "description": {"en": "CV-controlled NURBS surface approximation.", "ja": "CV制御NURBSサーフェス近似です。"}, "params": [
        p("length", "Length", "長さ", "FLOAT", 40.0, 0.001, 100000.0, "Surface length.", "サーフェス長さです。"),
        p("width", "Width", "幅", "FLOAT", 40.0, 0.001, 100000.0, "Surface width.", "サーフェス幅です。"),
        p("u_cvs", "U CVs", "U CV", "INT", 4, 2, 64, "CV count in U direction.", "U方向のCV数です。"),
        p("v_cvs", "V CVs", "V CV", "INT", 4, 2, 64, "CV count in V direction.", "V方向のCV数です。"),
        p("degree", "Degree", "次数", "INT", 3, 1, 5, "NURBS degree hint.", "NURBS次数の目安です。"),
        p("curvature", "Curvature", "曲率", "FLOAT", 8.0, -100000.0, 100000.0, "Analytic CV surface curvature amount.", "解析的なCV曲面変形量です。"),
    ]},
})

# Compound objects. These are represented as self-contained procedural equivalents because Blender Geometry Nodes modifier assets cannot import arbitrary 3ds Max operands automatically.
GENERATOR_SPECS.update({
    "compound_morph": {"category": "compound", "name": {"en": "Morph", "ja": "モーフ"}, "description": {"en": "Interpolates between a box-like and sphere-like form.", "ja": "ボックス状形状と球状形状を補間するモーフ近似です。"}, "params": [
        p("radius", "Radius", "半径", "FLOAT", 25.0, 0.001, 100000.0, "Base radius.", "基準半径です。"),
        p("amount", "Amount", "量", "FLOAT", 0.0, 0.0, 100.0, "Morph amount in percent.", "モーフ量です。単位はパーセントです。"),
        p("segments", "Segments", "セグメント", "INT", 16, 4, 256, "Shape resolution.", "形状解像度です。"), P_SMOOTH]},
    "compound_scatter": {"category": "compound", "name": {"en": "Scatter", "ja": "スキャッタ"}, "description": {"en": "Scatters simple instances over a plane using deterministic seed.", "ja": "平面上に簡易インスタンスを決定的シードで散布します。"}, "params": [
        p("area", "Area", "範囲", "FLOAT", 100.0, 0.001, 100000.0, "Scatter square area size.", "散布する正方形範囲のサイズです。"),
        p("count", "Count", "数", "INT", 50, 0, 10000, "Number of generated instances.", "生成インスタンス数です。"),
        p("scale", "Scale", "スケール", "FLOAT", 3.0, 0.001, 100000.0, "Instance size.", "インスタンスサイズです。"),
        p("seed", "Seed", "シード", "INT", 1, 0, 1000000, "Random seed.", "ランダムシードです。"),
        p("mode", "Mode", "モード", "INT", 0, 0, 2, "0=Box, 1=Cone, 2=Sphere.", "0=ボックス、1=円錐、2=球。") ]},
    "compound_conform": {"category": "compound", "name": {"en": "Conform", "ja": "コンフォーム"}, "description": {"en": "Projects a grid onto a spherical target approximation.", "ja": "グリッドを球状ターゲット近似へ投影します。"}, "params": [
        p("width", "Width", "幅", "FLOAT", 80.0, 0.001, 100000.0, "Grid width.", "グリッド幅です。"),
        p("segments", "Segments", "セグメント", "INT", 32, 2, 512, "Grid subdivisions.", "グリッド分割数です。"),
        p("target_radius", "Target Radius", "ターゲット半径", "FLOAT", 50.0, 0.001, 100000.0, "Radius of the conform target.", "コンフォーム先球面の半径です。"),
        p("amount", "Amount", "量", "FLOAT", 100.0, 0.0, 100.0, "Projection blend amount.", "投影ブレンド量です。") ]},
    "compound_connect": {"category": "compound", "name": {"en": "Connect", "ja": "コネクト"}, "description": {"en": "Bridges two circular openings with a tube.", "ja": "2つの円形開口をチューブでブリッジします。"}, "params": [
        p("radius", "Radius", "半径", "FLOAT", 20.0, 0.001, 100000.0, "Opening radius.", "開口半径です。"),
        p("length", "Length", "長さ", "FLOAT", 60.0, 0.001, 100000.0, "Bridge length.", "ブリッジ長さです。"),
        p("sides", "Sides", "側面数", "INT", 24, 3, 3600, "Tube sides.", "チューブ側面数です。"),
        p("twist", "Twist", "ツイスト", "FLOAT", 0.0, -360.0, 360.0, "Rotates the second ring before bridging.", "ブリッジ前に2つ目のリングを回転します。") ]},
    "compound_blobmesh": {"category": "compound", "name": {"en": "BlobMesh", "ja": "ブロブメッシュ"}, "description": {"en": "Metaball-like overlapping sphere cluster approximation.", "ja": "メタボールに近い重なり球クラスタ近似です。"}, "params": [
        p("radius", "Radius", "半径", "FLOAT", 12.0, 0.001, 100000.0, "Blob radius.", "ブロブ半径です。"),
        p("count", "Count", "数", "INT", 8, 1, 256, "Number of blobs.", "ブロブ数です。"),
        p("threshold", "Threshold", "しきい値", "FLOAT", 0.5, 0.0, 10.0, "Metaball threshold hint.", "メタボールしきい値の目安です。"),
        p("seed", "Seed", "シード", "INT", 1, 0, 1000000, "Random seed.", "ランダムシードです。"), P_SMOOTH]},
    "compound_shapemerge": {"category": "compound", "name": {"en": "ShapeMerge", "ja": "シェイプ マージ"}, "description": {"en": "Projects a 2D spline-like star onto a base plane.", "ja": "2Dスプライン風の星形をベース平面へ投影します。"}, "params": [
        p("width", "Width", "幅", "FLOAT", 80.0, 0.001, 100000.0, "Base plane width.", "ベース平面幅です。"),
        p("shape_radius", "Shape Radius", "形状半径", "FLOAT", 20.0, 0.001, 100000.0, "Projected shape radius.", "投影形状の半径です。"),
        p("sides", "Sides", "側面数", "INT", 5, 3, 64, "Star side count.", "星形の角数です。"),
        p("cut_depth", "Cut Depth", "カット深度", "FLOAT", 1.0, 0.0, 100000.0, "Raised/cut preview depth.", "カット表示用の深さです。") ]},
    "compound_boolean": {"category": "compound", "name": {"en": "Boolean", "ja": "ブーリアン"}, "description": {"en": "Boolean-style primitive preview using union/subtract/intersect modes.", "ja": "合成・差分・交差モードのブーリアン風プレビューです。"}, "params": [
        p("operation", "Operation", "演算", "INT", 0, 0, 2, "0=Union, 1=Subtract, 2=Intersect.", "0=和、1=差、2=交差。"),
        p("size_a", "Size A", "サイズ A", "FLOAT", 40.0, 0.001, 100000.0, "First operand size.", "第1オペランドサイズです。"),
        p("size_b", "Size B", "サイズ B", "FLOAT", 30.0, 0.001, 100000.0, "Second operand size.", "第2オペランドサイズです。"),
        p("offset", "Offset", "オフセット", "FLOAT", 15.0, -100000.0, 100000.0, "Offset between operands.", "オペランド同士のオフセットです。") ]},
    "compound_proboolean": {"category": "compound", "name": {"en": "ProBoolean", "ja": "プロブーリアン"}, "description": {"en": "Advanced boolean-style preview with multiple operands.", "ja": "複数オペランドを想定した高度ブーリアン風プレビューです。"}, "params": [
        p("operation", "Operation", "演算", "INT", 0, 0, 3, "0=Union, 1=Subtract, 2=Intersect, 3=Merge.", "0=和、1=差、2=交差、3=マージ。"),
        p("base_size", "Base Size", "ベースサイズ", "FLOAT", 50.0, 0.001, 100000.0, "Base operand size.", "ベースオペランドサイズです。"),
        p("cutter_count", "Cutter Count", "カッター数", "INT", 3, 1, 64, "Number of cutter preview objects.", "カッタープレビューオブジェクト数です。"),
        p("cutter_radius", "Cutter Radius", "カッター半径", "FLOAT", 8.0, 0.001, 100000.0, "Cutter radius.", "カッター半径です。") ]},
    "compound_procutter": {"category": "compound", "name": {"en": "ProCutter", "ja": "プロカッター"}, "description": {"en": "Fragmentation preview using deterministic cracked panels.", "ja": "決定的な割れパネルによる分割・粉砕プレビューです。"}, "params": [
        p("size", "Size", "サイズ", "FLOAT", 80.0, 0.001, 100000.0, "Object size.", "オブジェクトサイズです。"),
        p("pieces", "Pieces", "破片数", "INT", 12, 1, 512, "Number of generated fragments.", "生成破片数です。"),
        p("gap", "Gap", "隙間", "FLOAT", 1.0, 0.0, 100000.0, "Gap between fragments.", "破片同士の隙間です。"),
        p("seed", "Seed", "シード", "INT", 1, 0, 1000000, "Random seed.", "ランダムシードです。") ]},
    "compound_terrain": {"category": "compound", "name": {"en": "Terrain", "ja": "テレイン"}, "description": {"en": "Terrain generated from contour-like rings.", "ja": "等高線風リングから生成する地形です。"}, "params": [
        p("size", "Size", "サイズ", "FLOAT", 120.0, 0.001, 100000.0, "Terrain size.", "地形サイズです。"),
        p("segments", "Segments", "セグメント", "INT", 64, 2, 512, "Grid resolution.", "グリッド解像度です。"),
        p("height", "Height", "高さ", "FLOAT", 30.0, -100000.0, 100000.0, "Maximum terrain height.", "地形の最大高さです。"),
        p("contours", "Contours", "等高線数", "INT", 8, 1, 128, "Contour frequency.", "等高線風の周波数です。"),
        p("seed", "Seed", "シード", "INT", 1, 0, 1000000, "Noise seed.", "ノイズシードです。") ]},
    "compound_loft": {"category": "compound", "name": {"en": "Loft", "ja": "ロフト"}, "description": {"en": "Extrudes a cross-section along a curved path.", "ja": "断面形状を曲線パスに沿って押し出します。"}, "params": [
        p("path_length", "Path Length", "パス長", "FLOAT", 100.0, 0.001, 100000.0, "Loft path length.", "ロフトパスの長さです。"),
        p("radius", "Radius", "半径", "FLOAT", 8.0, 0.001, 100000.0, "Cross-section radius.", "断面半径です。"),
        p("path_segments", "Path Segments", "パス セグメント", "INT", 48, 2, 1000, "Path subdivisions.", "パス分割数です。"),
        p("sides", "Sides", "側面数", "INT", 12, 3, 256, "Cross-section sides.", "断面の側面数です。"),
        p("twist", "Twist", "ツイスト", "FLOAT", 180.0, -3600.0, 3600.0, "Cross-section twist along path.", "パスに沿った断面ツイスト量です。") ]},
    "compound_mesher": {"category": "compound", "name": {"en": "Mesher", "ja": "メッシャー"}, "description": {"en": "Particle-like dynamic result converted to mesh preview.", "ja": "パーティクル風の動的結果をメッシュに変換したプレビューです。"}, "params": [
        p("count", "Count", "数", "INT", 24, 1, 10000, "Particle mesh count.", "メッシュ化する粒子数です。"),
        p("radius", "Radius", "半径", "FLOAT", 4.0, 0.001, 100000.0, "Particle radius.", "粒子半径です。"),
        p("spread", "Spread", "広がり", "FLOAT", 80.0, 0.001, 100000.0, "Particle spread.", "粒子の広がりです。"),
        p("frame", "Frame", "フレーム", "FLOAT", 0.0, -100000.0, 100000.0, "Simulation frame preview. Animate this for motion.", "シミュレーションフレーム相当のプレビュー値です。アニメーションで動かせます。"),
        p("seed", "Seed", "シード", "INT", 1, 0, 1000000, "Random seed.", "ランダムシードです。"), P_SMOOTH]},
})


def all_specs():
    return GENERATOR_SPECS


def specs_by_category():
    out = {cat: [] for cat in CATEGORIES}
    for gid, spec in GENERATOR_SPECS.items():
        out.setdefault(spec["category"], []).append((gid, spec))
    return out

# -----------------------------------------------------------------------------
# 0.2.0 compatibility expansion
# -----------------------------------------------------------------------------
# The original 0.1.0 tables intentionally stayed compact.  The following update
# block expands the public modifier interface to cover the missing 3ds Max style
# controls and adds upper-compatible Blender object operand sockets where 3ds Max
# compound objects expect picked operands.


def _param_index(params, identifier):
    for idx, item in enumerate(params):
        if item.get("id") == identifier:
            return idx
    return -1


def _upsert_param(generator_id, param, after=None):
    spec = GENERATOR_SPECS.get(generator_id)
    if not spec:
        return
    params = spec.setdefault("params", [])
    idx = _param_index(params, param["id"])
    if idx >= 0:
        merged = dict(params[idx])
        merged.update(param)
        params[idx] = merged
        return
    insert_at = len(params)
    if after:
        aidx = _param_index(params, after)
        if aidx >= 0:
            insert_at = aidx + 1
    params.insert(insert_at, param)


def _remove_param(generator_id, identifier):
    spec = GENERATOR_SPECS.get(generator_id)
    if spec:
        spec["params"] = [item for item in spec.get("params", []) if item.get("id") != identifier]


def _set_description(generator_id, en, ja):
    if generator_id in GENERATOR_SPECS:
        GENERATOR_SPECS[generator_id]["description"] = {"en": en, "ja": ja}


def object_param(identifier, en, ja, desc_en, desc_ja):
    return p(identifier, en, ja, "OBJECT", None, desc_en=desc_en, desc_ja=desc_ja)


def _int_mode(identifier, en, ja, default, low, high, desc_en, desc_ja):
    return p(identifier, en, ja, "INT", default, low, high, desc_en=desc_en, desc_ja=desc_ja)


# Standard primitive fidelity fixes.
_upsert_param("standard_sphere", p("segments", "Segments", "セグメント", "INT", 16, 4, 3600,
    "3ds Max segs value. It controls both longitudinal and derived latitude resolution.",
    "3ds Max の segs 値です。経度方向と派生する緯度方向の解像度を制御します。"))
_remove_param("standard_sphere", "rings")
_upsert_param("standard_sphere", p("hemisphere_mode", "Chop / Squash", "切り取り / 押しつぶし", "INT", 0, 0, 1,
    "0=Chop removes vertices as Hemisphere increases. 1=Squash preserves the original vertex count and compresses the remaining surface.",
    "0=切り取りは Hemisphere 増加に合わせて頂点を削除します。1=押しつぶしは元の頂点数を維持して表面を圧縮します。"), after="hemisphere")
_upsert_param("standard_sphere", p("recenter", "Base To Pivot", "底面をピボットへ", "BOOL", False,
    desc_en="Moves the generated sphere upward so the local pivot/origin sits at the base, matching the 3ds Max recenter option.",
    desc_ja="ローカル原点が底面に来るよう球を上方向へ移動します。3ds Max の recenter オプションに相当します。"), after="hemisphere_mode")

_upsert_param("standard_geosphere", p("segments", "Segments", "セグメント", "INT", 4, 1, 200,
    "3ds Max geosphere frequency. Face count equals base polyhedron face count multiplied by segments squared.",
    "3ds Max のジオスフィア周波数です。面数は基本多面体の面数×セグメント数の2乗になります。"))
_upsert_param("standard_geosphere", p("hemisphere", "Hemisphere", "半球", "BOOL", False,
    desc_en="Creates a half geosphere. When enabled, Base To Pivot is ignored as in 3ds Max.",
    desc_ja="半球ジオスフィアを作成します。有効時は 3ds Max と同様に[底面をピボットへ]は無視されます。"), after="smooth")
_upsert_param("standard_geosphere", p("base_to_pivot", "Base To Pivot", "底面をピボットへ", "BOOL", False,
    desc_en="Moves the full geosphere upward so the local pivot/origin is at the bottom of the sphere.",
    desc_ja="完全なジオスフィアを上方向へ移動し、ローカル原点を球の底面に置きます。"), after="hemisphere")

_upsert_param("standard_torus", p("radius1", "Radius 1", "半径 1", "FLOAT", 25.0, 0.001, 100000.0,
    "3ds Max torus major radius: distance from object center to tube center.",
    "3ds Max トーラスの主半径です。オブジェクト中心からチューブ中心までの距離です。"))
_upsert_param("standard_torus", p("radius2", "Radius 2", "半径 2", "FLOAT", 10.0, 0.001, 100000.0,
    "3ds Max torus tube radius.", "3ds Max トーラスのチューブ半径です。"))
_upsert_param("standard_torus", p("segments", "Segments", "セグメント", "INT", 24, 3, 3600,
    "Number of radial divisions around the torus ring.", "トーラスリング周方向の分割数です。"))
_upsert_param("standard_torus", p("smooth", "Smooth Level", "スムーズ レベル", "INT", 0, 0, 3,
    "3ds Max smoothing level: 0=None, 1=Sides, 2=All, 3=Segments. Blender applies compatible smooth shading for levels above 0.",
    "3ds Max のスムーズレベルです。0=なし、1=側面、2=全体、3=セグメント。Blender では 0 より大きい場合に互換スムーズ表示を行います。"))
_upsert_param("standard_torus", p("tube_rotation", "Tube Rotation", "チューブ回転", "FLOAT", 0.0, -3600.0, 3600.0,
    "Rotates all tube cross-section vertices around their local cross-section center.",
    "チューブ断面の全頂点を断面中心の周りに回転します。"), after="radius2")
_upsert_param("standard_torus", p("tube_twist", "Tube Twist", "チューブ ツイスト", "FLOAT", 0.0, -3600.0, 3600.0,
    "Progressively twists tube cross sections along the torus ring, matching the 3ds Max Twist control.",
    "トーラスリングに沿って断面を段階的にねじります。3ds Max の Twist 制御に相当します。"), after="tube_rotation")

_upsert_param("standard_plane", p("length_segments", "Length Segments", "長さセグメント", "INT", 4, 1, 2000,
    "Number of divisions along plane length.", "平面の長さ方向分割数です。"))
_upsert_param("standard_plane", p("width_segments", "Width Segments", "幅セグメント", "INT", 4, 1, 2000,
    "Number of divisions along plane width.", "平面の幅方向分割数です。"))
_upsert_param("standard_plane", p("density", "Density", "密度", "FLOAT", 1.0, 0.01, 100.0,
    "Render/display density multiplier. In this implementation it multiplies the editable segment counts directly.",
    "表示・レンダー密度の倍率です。この実装では編集可能なセグメント数へ直接乗算します。"), after="width_segments")
_upsert_param("standard_plane", p("render_scale", "Render Scale", "レンダースケール", "FLOAT", 1.0, 0.001, 1000.0,
    "Scales length and width from the center, matching the 3ds Max Render Scale concept.",
    "中心から長さと幅を拡大縮小します。3ds Max の Render Scale の考え方に相当します。"), after="density")

# TextPlus upper-compatible text controls.
_upsert_param("standard_textplus", p("font_style", "Font Style", "フォントスタイル", "INT", 0, 0, 3,
    "Style hint: 0=Regular, 1=Bold, 2=Italic, 3=Bold Italic. Blender applies this only when the active font supports the style.",
    "スタイルの目安です。0=標準、1=太字、2=斜体、3=太字斜体。Blender 側のフォントが対応する場合のみ反映されます。"), after="text")
_upsert_param("standard_textplus", p("tracking", "Tracking", "字間", "FLOAT", 1.0, 0.0, 100.0,
    "Character spacing multiplier for the TextPlus curve.", "TextPlus カーブの文字間隔倍率です。"), after="size")
_upsert_param("standard_textplus", p("line_spacing", "Line Spacing", "行間", "FLOAT", 1.0, 0.0, 100.0,
    "Line spacing multiplier for multiline text.", "複数行テキストの行間倍率です。"), after="tracking")
_upsert_param("standard_textplus", p("shear", "Shear", "シアー", "FLOAT", 0.0, -10.0, 10.0,
    "Slants the text curve for an italic-like effect when no italic font is available.",
    "斜体フォントが無い場合でも文字カーブを傾けて斜体風にします。"), after="line_spacing")
_upsert_param("standard_textplus", p("offset_x", "Offset X", "オフセット X", "FLOAT", 0.0, -100000.0, 100000.0,
    "Horizontal text offset in local units.", "ローカル単位での水平方向オフセットです。"), after="align")
_upsert_param("standard_textplus", p("offset_y", "Offset Y", "オフセット Y", "FLOAT", 0.0, -100000.0, 100000.0,
    "Vertical text offset in local units.", "ローカル単位での垂直方向オフセットです。"), after="offset_x")

# Extended primitive upgrades.
_upsert_param("extended_hedra", p("family", "Family", "ファミリー", "INT", 2, 0, 8,
    "Polyhedron family selector: tetra, cube/octa, dodeca/icosa, star and dual variants. Extra values expose Blender-only compatible variants.",
    "多面体ファミリーを選びます。四面体、立方体/八面体、十二面体/二十面体、星型、双対系を含みます。追加値は Blender 上位互換バリエーションです。"))
_upsert_param("extended_hedra", p("stellation", "Stellation", "星型化", "FLOAT", 0.0, 0.0, 3.0,
    "Pushes face centers outward to form star-like hedra. 0 keeps the base polyhedron.",
    "面中心を外側へ押し出して星型のヘドラを作ります。0 では基本多面体のままです。"), after="family")
_upsert_param("extended_hedra", p("dual", "Dual", "双対", "BOOL", False,
    desc_en="Builds the dual polyhedron from face centers when supported by the selected family.",
    desc_ja="選択ファミリーが対応する場合、面中心から双対多面体を生成します。"), after="stellation")

_upsert_param("extended_chamferbox", p("fillet", "Fillet", "フィレット", "FLOAT", 2.0, 0.0, 100000.0,
    "3ds Max ChamferBox fillet amount. It is clamped to the current dimensions.",
    "3ds Max ChamferBox のフィレット量です。現在の寸法に合わせて自動制限されます。"))
_upsert_param("extended_chamferbox", p("fillet_segments", "Fillet Segments", "フィレット セグメント", "INT", 2, 1, 128,
    "Number of segments used by each rounded edge.", "各丸めエッジに使用する分割数です。"))

_upsert_param("extended_gengon", p("fillet", "Fillet", "フィレット", "FLOAT", 0.0, 0.0, 100000.0,
    "Rounds the vertical edges of the regular polygon column. Set to 0 for a hard Gengon.",
    "正多角形柱の縦エッジを丸めます。0 で硬いジェンゴンになります。"))
_upsert_param("extended_gengon", p("center", "Center", "中心", "BOOL", True,
    desc_en="Keeps the Gengon centered on the local origin. Disable to place the base on the origin like 3ds Max type-in creation.",
    desc_ja="ジェンゴンをローカル原点中心に配置します。無効にすると 3ds Max のタイプ入力作成に近い底面原点配置になります。"), after="height")

_upsert_param("extended_ringwave", p("outer_edge_breakup", "Outer Edge Breakup", "外側エッジの崩し", "FLOAT", 0.0, 0.0, 100.0,
    "Adds deterministic irregularity to the outer wave edge.", "外側の波形エッジへ決定的な揺らぎを追加します。"), after="amplitude")
_upsert_param("extended_ringwave", p("inner_edge_breakup", "Inner Edge Breakup", "内側エッジの崩し", "FLOAT", 0.0, 0.0, 100.0,
    "Adds deterministic irregularity to the inner wave edge.", "内側の波形エッジへ決定的な揺らぎを追加します。"), after="outer_edge_breakup")
_upsert_param("extended_ringwave", p("seed", "Seed", "シード", "INT", 1, 0, 1000000,
    "Random seed for RingWave breakup.", "リングウェーブの崩し用ランダムシードです。"), after="inner_edge_breakup")

_upsert_param("extended_hose", p("start_object", "Start Object", "開始オブジェクト", "OBJECT", None,
    desc_en="Optional Blender object used as the start anchor. When set, the hose reads its world location for the first endpoint.",
    desc_ja="開始アンカーとして使う任意の Blender オブジェクトです。設定するとホースの始点にワールド位置を使用します。"), after="length")
_upsert_param("extended_hose", p("end_object", "End Object", "終了オブジェクト", "OBJECT", None,
    desc_en="Optional Blender object used as the end anchor. When set, the hose connects between Start Object and End Object.",
    desc_ja="終了アンカーとして使う任意の Blender オブジェクトです。設定すると開始オブジェクトから終了オブジェクトへ接続します。"), after="start_object")
_upsert_param("extended_hose", p("diameter", "Diameter", "直径", "FLOAT", 20.0, 0.001, 100000.0,
    "3ds Max style hose diameter control. Radius remains available for backward compatibility; Diameter takes priority when edited.",
    "3ds Max 風のホース直径制御です。後方互換のため半径も残しますが、編集時は直径が優先されます。"), after="radius")
_upsert_param("extended_hose", p("tension", "Tension", "張力", "FLOAT", 0.0, -100.0, 100.0,
    "Controls sag or upward tension between the two hose endpoints.", "2つのホース端点間のたるみまたは持ち上がり具合を制御します。"), after="bend")

# AEC/architectural controls.
_upsert_param("aec_foliage", p("species", "Species", "樹種", "INT", 0, 0, 9,
    "Species preset: broadleaf, conifer, palm, grass, shrub, dead tree and Blender-only variants.",
    "樹種プリセットです。広葉樹、針葉樹、ヤシ、草、低木、枯れ木、Blender 上位互換バリエーションを含みます。"), after="plant_type")
_upsert_param("aec_foliage", p("leaf_count", "Leaf Count", "葉の数", "INT", 64, 0, 20000,
    "Maximum generated leaf clusters. Density multiplies this value.", "生成する葉クラスタの最大数です。密度がこの値に乗算されます。"), after="leaf_size")
_upsert_param("aec_foliage", p("branch_levels", "Branch Levels", "枝レベル", "INT", 2, 0, 5,
    "Recursive branch depth. Higher values create secondary branches.", "再帰的な枝の深さです。値を上げると二次枝を生成します。"), after="branches")
_upsert_param("aec_foliage", p("season", "Season", "季節", "INT", 0, 0, 3,
    "Season hint: 0=Summer/full leaves, 1=Spring, 2=Autumn/thinned, 3=Winter/no leaves.",
    "季節の目安です。0=夏/葉多め、1=春、2=秋/葉少なめ、3=冬/葉なし。"), after="branch_levels")
_upsert_param("aec_foliage", p("wind", "Wind", "風", "FLOAT", 0.0, -1000.0, 1000.0,
    "Animatable wind phase that bends foliage deterministically.", "アニメーション可能な風位相です。植物を決定的に曲げます。"), after="season")

_upsert_param("aec_railing", p("path_type", "Path Type", "パスタイプ", "INT", 0, 0, 3,
    "0=Straight, 1=L-shaped, 2=U-shaped, 3=Closed rectangle. This adds Blender upper-compatible path presets.",
    "0=直線、1=L字、2=U字、3=閉じた矩形。Blender 上位互換のパスプリセットです。"), after="length")
_upsert_param("aec_railing", p("corner_length", "Corner Length", "コーナー長", "FLOAT", 60.0, 0.001, 100000.0,
    "Secondary run length for L/U/rectangle railing paths.", "L字/U字/矩形手すりパスの副走行長です。"), after="path_type")
_upsert_param("aec_railing", p("fencing_type", "Fencing Type", "フェンス種類", "INT", 0, 0, 2,
    "0=Pickets, 1=Solid panel, 2=None. Controls the fill between posts.",
    "0=縦桟、1=ソリッドパネル、2=なし。支柱間の充填方式を制御します。"), after="baluster_spacing")
_upsert_param("aec_railing", p("bottom_rail", "Bottom Rail", "下段レール", "BOOL", True,
    desc_en="Adds a bottom rail below the pickets or solid panel.", desc_ja="縦桟またはソリッドパネルの下に下段レールを追加します。"), after="fencing_type")

_upsert_param("aec_wall", p("path_type", "Path Type", "パスタイプ", "INT", 0, 0, 3,
    "0=Straight, 1=L-shaped, 2=U-shaped, 3=Closed rectangle wall path.",
    "0=直線、1=L字、2=U字、3=閉じた矩形壁パスです。"), after="length")
_upsert_param("aec_wall", p("corner_length", "Corner Length", "コーナー長", "FLOAT", 80.0, 0.001, 100000.0,
    "Secondary segment length for non-straight wall paths.", "直線以外の壁パスで使う副セグメント長です。"), after="path_type")
_upsert_param("aec_wall", p("justify", "Justify", "位置合わせ", "INT", 1, 0, 2,
    "0=Left, 1=Center, 2=Right wall thickness justification relative to the path.",
    "パスに対する壁厚の位置合わせです。0=左、1=中央、2=右。"), after="width")
_upsert_param("aec_wall", p("openings", "Openings", "開口数", "INT", 0, 0, 32,
    "Number of evenly spaced rectangular door/window openings cut into each straight wall run.",
    "各直線壁ランへ等間隔に入れる矩形ドア/窓開口の数です。"), after="segments")
_upsert_param("aec_wall", p("opening_width", "Opening Width", "開口幅", "FLOAT", 24.0, 0.001, 100000.0,
    "Width of each wall opening.", "各壁開口の幅です。"), after="openings")
_upsert_param("aec_wall", p("opening_height", "Opening Height", "開口高さ", "FLOAT", 36.0, 0.001, 100000.0,
    "Height of each wall opening.", "各壁開口の高さです。"), after="opening_width")
_upsert_param("aec_wall", p("opening_sill", "Opening Sill", "開口下端", "FLOAT", 12.0, 0.0, 100000.0,
    "Distance from the wall base to the bottom of each opening.", "壁の底面から各開口下端までの距離です。"), after="opening_height")

# Door/window controls.
for _gid in ("door_pivot", "door_sliding", "door_bifold"):
    _upsert_param(_gid, p("leaf_panels", "Leaf Panels", "扉パネル数", "INT", 1, 1, 16,
        "Number of visible decorative panels per door leaf.", "各扉リーフに表示する装飾パネル数です。"), after="panel_thickness")
    _upsert_param(_gid, p("bevel", "Bevel", "ベベル", "FLOAT", 0.0, 0.0, 1000.0,
        "Small bevel/trim amount added around frames and panels.", "枠とパネル周りへ追加する小さなベベル/トリム量です。"), after="leaf_panels")
    _upsert_param(_gid, p("frame_enabled", "Frame", "枠", "BOOL", True,
        desc_en="Enables the generated outer frame.", desc_ja="生成される外枠を有効にします。"), after="depth")

for _gid in ("window_awning", "window_casement", "window_fixed", "window_pivoted", "window_projected", "window_sliding"):
    _upsert_param(_gid, p("vertical_muntins", "Vertical Muntins", "縦桟", "INT", 1, 0, 64,
        "Number of vertical muntins inside the sash.", "サッシ内の縦桟数です。"), after="muntins")
    _upsert_param(_gid, p("horizontal_muntins", "Horizontal Muntins", "横桟", "INT", 0, 0, 64,
        "Number of horizontal muntins inside the sash.", "サッシ内の横桟数です。"), after="vertical_muntins")
    _upsert_param(_gid, p("sash_width", "Sash Width", "サッシ幅", "FLOAT", 2.0, 0.0, 100000.0,
        "Width of the moving sash frame around the glass.", "ガラス周囲に生成する可動サッシ枠の幅です。"), after="frame_width")
    _upsert_param(_gid, p("bevel", "Bevel", "ベベル", "FLOAT", 0.0, 0.0, 1000.0,
        "Small bevel/trim amount for window parts.", "窓部品に追加する小さなベベル/トリム量です。"), after="glass_thickness")

# Stair controls.
for _gid in ("stairs_straight", "stairs_spiral"):
    _upsert_param(_gid, p("railings", "Railings", "手すり", "BOOL", False,
        desc_en="Adds simple generated railings to the stair object.", desc_ja="階段オブジェクトへ簡易生成の手すりを追加します。"), after="map_coords")
_upsert_param("stairs_straight", p("stringers", "Stringers", "桁", "INT", 2, 0, 4,
    "Number of beams generated along the stair sides and center.", "階段の側面と中央に沿って通す桁の数です。"), after="railings")
_upsert_param("stairs_straight", p("nosing", "Nosing", "段鼻", "FLOAT", 0.0, 0.0, 100000.0,
    "Extra tread overhang at the front of each step.", "各段の前側に追加する踏み板の張り出しです。"), after="stringers")

# Patch/NURBS controls.
for _gid in ("patch_quad", "patch_tri", "nurbs_point", "nurbs_cv"):
    _upsert_param(_gid, p("surface_mode", "Surface Mode", "サーフェスモード", "INT", 0, 0, 3,
        "0=Flat/analytic, 1=Dome, 2=Saddle, 3=Wave. Adds Blender upper-compatible surface presets.",
        "0=平面/解析、1=ドーム、2=鞍型、3=波。Blender 上位互換のサーフェスプリセットです。"), after="curvature")
    _upsert_param(_gid, p("u_degree", "U Degree", "U 次数", "INT", 3, 1, 5,
        "NURBS degree hint in the U direction.", "U方向のNURBS次数の目安です。"), after="surface_mode")
    _upsert_param(_gid, p("v_degree", "V Degree", "V 次数", "INT", 3, 1, 5,
        "NURBS degree hint in the V direction.", "V方向のNURBS次数の目安です。"), after="u_degree")

# Compound object operand sockets and compatibility controls.
_upsert_param("compound_morph", object_param("source_object", "Source Object", "ソースオブジェクト",
    "Optional source operand. If set with a target object, the add-on morphs source vertices toward target vertices or nearest points.",
    "任意のソースオペランドです。ターゲットオブジェクトと一緒に設定すると、ソース頂点をターゲット頂点または最近傍点へモーフします。"), after="segments")
_upsert_param("compound_morph", object_param("target_object", "Target Object", "ターゲットオブジェクト",
    "Optional target operand for the Morph object.", "モーフオブジェクト用の任意ターゲットオペランドです。"), after="source_object")

_upsert_param("compound_scatter", object_param("source_object", "Source Object", "ソースオブジェクト",
    "Mesh object to duplicate. If empty, the built-in primitive selected by Mode is scattered.",
    "複製するメッシュオブジェクトです。未設定の場合は Mode で選んだ内蔵プリミティブを散布します。"), after="mode")
_upsert_param("compound_scatter", object_param("distribution_object", "Distribution Object", "分布オブジェクト",
    "Optional mesh object whose surface, vertices, edges or face centers are used for distribution.",
    "分布に使う任意のメッシュオブジェクトです。表面、頂点、エッジ、面中心を利用できます。"), after="source_object")
_upsert_param("compound_scatter", p("use_distribution_object", "Use Distribution Object", "分布オブジェクトを使用", "BOOL", False,
    desc_en="When enabled and a distribution object is assigned, duplicates are placed on that object's geometry.",
    desc_ja="有効にして分布オブジェクトを指定すると、そのオブジェクトのジオメトリ上に複製を配置します。"), after="distribution_object")
_upsert_param("compound_scatter", p("distribution_method", "Distribution Method", "分布方法", "INT", 0, 0, 6,
    "0=Area, 1=Even Faces, 2=Random Faces, 3=Along Edges, 4=All Vertices, 5=Face Centers, 6=Edge Midpoints.",
    "0=面積、1=均等面、2=ランダム面、3=エッジ沿い、4=全頂点、5=面中心、6=エッジ中点。"), after="use_distribution_object")
_upsert_param("compound_scatter", p("perpendicular", "Perpendicular", "垂直配置", "BOOL", False,
    desc_en="Aligns scattered duplicates to the sampled normal when a distribution object is used.",
    desc_ja="分布オブジェクト使用時に、サンプルした法線へ複製を整列します。"), after="distribution_method")
_upsert_param("compound_scatter", p("display_percent", "Display Percent", "表示パーセント", "FLOAT", 100.0, 0.0, 100.0,
    "Percentage of duplicates generated for viewport preview.", "ビューポートプレビューで生成する複製の割合です。"), after="perpendicular")
_upsert_param("compound_scatter", p("random_rotation", "Random Rotation", "ランダム回転", "FLOAT", 360.0, 0.0, 3600.0,
    "Maximum random Z rotation in degrees.", "Z方向ランダム回転の最大角度です。単位は度です。"), after="display_percent")
_upsert_param("compound_scatter", p("random_scale", "Random Scale", "ランダムスケール", "FLOAT", 0.0, 0.0, 100.0,
    "Random scale variation percentage around Scale.", "Scale を中心にしたランダムスケール変化率です。"), after="random_rotation")

_upsert_param("compound_conform", object_param("wrapper_object", "Wrapper Object", "ラッパーオブジェクト",
    "Optional wrapper mesh whose vertices are projected.", "投影される任意のラッパーメッシュです。"), after="amount")
_upsert_param("compound_conform", object_param("wrap_to_object", "Wrap-To Object", "投影先オブジェクト",
    "Optional target mesh onto which wrapper vertices are projected.", "ラッパー頂点の投影先となる任意ターゲットメッシュです。"), after="wrapper_object")
_upsert_param("compound_conform", p("projection_direction", "Projection Direction", "投影方向", "INT", 0, 0, 6,
    "0=Active Z/Top, 1=Along Vertex Normals, 2=Towards Wrapper Center, 3=Towards Wrapper Pivot, 4=Towards Wrap-To Center, 5=Towards Wrap-To Pivot, 6=Nearest Surface.",
    "0=Z/トップ、1=頂点法線沿い、2=ラッパー中心へ、3=ラッパーピボットへ、4=投影先中心へ、5=投影先ピボットへ、6=最近傍サーフェス。"), after="wrap_to_object")
_upsert_param("compound_conform", p("standoff_distance", "Standoff Distance", "スタンドオフ距離", "FLOAT", 0.0, -100000.0, 100000.0,
    "Distance maintained from the target surface after projection.", "投影後にターゲットサーフェスから維持する距離です。"), after="projection_direction")
_upsert_param("compound_conform", p("default_projection_distance", "Default Projection Distance", "既定投影距離", "FLOAT", 1000.0, 0.0, 1000000.0,
    "Fallback projection distance when no target hit is found.", "ターゲットへのヒットが無い場合に使用する既定投影距離です。"), after="standoff_distance")

_upsert_param("compound_boolean", object_param("operand_a", "Operand A", "オペランド A",
    "Optional first Boolean operand. When assigned, the generated object uses this mesh as the base.",
    "任意の第1ブーリアンオペランドです。設定すると生成オブジェクトのベースメッシュとして使用します。"), after="offset")
_upsert_param("compound_boolean", object_param("operand_b", "Operand B", "オペランド B",
    "Optional second Boolean operand. Blender's exact Boolean modifier is synchronized non-destructively when assigned.",
    "任意の第2ブーリアンオペランドです。設定すると Blender の正確なブーリアンモディファイアを非破壊で同期します。"), after="operand_a")

for _idx in range(1, 5):
    _upsert_param("compound_proboolean", object_param(f"operand_{_idx}", f"Operand {_idx}", f"オペランド {_idx}",
        f"Optional ProBoolean operand {_idx}. Assigned operands are processed by synchronized Blender Boolean modifiers.",
        f"任意の ProBoolean オペランド {_idx} です。設定したオペランドは同期された Blender ブーリアンモディファイアで処理されます。"), after="cutter_radius" if _idx == 1 else f"operand_{_idx-1}")
    _upsert_param("compound_proboolean", p(f"operation_{_idx}", f"Operation {_idx}", f"演算 {_idx}", "INT", 0 if _idx == 1 else 1, 0, 3,
        "Per-operand operation: 0=Union, 1=Subtract, 2=Intersect, 3=Merge/Join.",
        "オペランド別の演算です。0=和、1=差、2=交差、3=マージ/結合。"), after=f"operand_{_idx}")

_upsert_param("compound_procutter", object_param("base_object", "Base Object", "ベースオブジェクト",
    "Optional object to fragment. If empty, the procedural block is fragmented.",
    "分割する任意オブジェクトです。未設定の場合は手続き型ブロックを分割します。"), after="seed")
for _idx in range(1, 5):
    _upsert_param("compound_procutter", object_param(f"cutter_{_idx}", f"Cutter {_idx}", f"カッター {_idx}",
        f"Optional cutter object {_idx}; used for non-destructive exact cut previews through Boolean difference modifiers.",
        f"任意のカッターオブジェクト {_idx} です。非破壊の正確なカットプレビュー用ブーリアン差分モディファイアで使用します。"), after="base_object" if _idx == 1 else f"cutter_{_idx-1}")

_upsert_param("compound_blobmesh", p("resolution", "Resolution", "解像度", "INT", 20, 6, 96,
    "Implicit field grid resolution. Higher values produce a smoother BlobMesh but are slower.",
    "陰関数フィールドのグリッド解像度です。値を上げると滑らかな BlobMesh になりますが処理は重くなります。"), after="threshold")
_upsert_param("compound_blobmesh", p("tension", "Tension", "張力", "FLOAT", 1.0, 0.01, 10.0,
    "Field falloff/tension controlling how blobs merge.", "ブロブ同士の融合具合を制御するフィールド減衰/張力です。"), after="resolution")

_upsert_param("compound_shapemerge", object_param("shape_object", "Shape Object", "シェイプオブジェクト",
    "Optional curve or mesh object projected onto the base preview.", "ベースプレビューへ投影する任意のカーブまたはメッシュオブジェクトです。"), after="cut_depth")
_upsert_param("compound_shapemerge", object_param("base_object", "Base Object", "ベースオブジェクト",
    "Optional base mesh object for projection. If empty, a generated plane is used.", "投影先の任意ベースメッシュです。未設定の場合は生成平面を使用します。"), after="shape_object")
_upsert_param("compound_shapemerge", p("merge_mode", "Merge Mode", "マージモード", "INT", 0, 0, 2,
    "0=Imprint/raise, 1=Cut recess, 2=Extract shape preview.", "0=刻印/盛り上げ、1=切り込み、2=形状抽出プレビュー。"), after="base_object")

_upsert_param("compound_terrain", object_param("contour_object", "Contour Object", "等高線オブジェクト",
    "Optional curve/mesh object used as a contour source. If empty, analytic contour rings are used.",
    "等高線ソースとして使う任意のカーブ/メッシュオブジェクトです。未設定の場合は解析的な等高線リングを使用します。"), after="seed")
_upsert_param("compound_terrain", p("smooth_steps", "Smooth Steps", "スムーズ回数", "INT", 1, 0, 64,
    "Laplacian smoothing passes applied to the generated terrain.", "生成地形に適用するラプラシアンスムージング回数です。"), after="contour_object")
_upsert_param("compound_terrain", p("terrace", "Terrace", "段丘", "FLOAT", 0.0, 0.0, 1.0,
    "Quantizes elevation toward contour terraces. 0 is smooth, 1 is strongly terraced.",
    "標高を等高線段丘へ量子化します。0=滑らか、1=強い段丘です。"), after="smooth_steps")

_upsert_param("compound_loft", object_param("path_object", "Path Object", "パスオブジェクト",
    "Optional curve/mesh object used as a loft path when available.", "使用可能な場合にロフトパスとして使う任意カーブ/メッシュオブジェクトです。"), after="twist")
_upsert_param("compound_loft", object_param("shape_object", "Shape Object", "断面オブジェクト",
    "Optional curve/mesh object used as a loft cross-section profile.", "ロフト断面プロファイルとして使う任意カーブ/メッシュオブジェクトです。"), after="path_object")
_upsert_param("compound_loft", p("shape_type", "Shape Type", "断面タイプ", "INT", 0, 0, 4,
    "0=Circle, 1=Rectangle, 2=NGon, 3=Star, 4=Use Shape Object.",
    "0=円、1=矩形、2=多角形、3=星形、4=断面オブジェクト使用。"), after="shape_object")
_upsert_param("compound_loft", p("scale_end", "Scale End", "終端スケール", "FLOAT", 1.0, 0.001, 1000.0,
    "Scale multiplier at the end of the loft path.", "ロフトパス終端でのスケール倍率です。"), after="shape_type")

_upsert_param("compound_mesher", object_param("source_object", "Source Object", "ソースオブジェクト",
    "Optional object whose evaluated mesh is copied as the Mesher result. If empty, particles are generated procedurally.",
    "Mesher 結果として評価済みメッシュをコピーする任意オブジェクトです。未設定の場合は粒子風メッシュを手続き生成します。"), after="smooth")
_upsert_param("compound_mesher", p("velocity_trails", "Velocity Trails", "速度トレイル", "BOOL", False,
    desc_en="Adds stretched trail geometry to procedural particles for dynamic previews.",
    desc_ja="動的プレビュー用に、手続き型粒子へ伸びたトレイルジオメトリを追加します。"), after="source_object")

# Updated descriptions for advanced object categories.
_set_description("standard_teapot",
    "Bezier Utah Teapot primitive using the public 32-patch control model with 3ds Max radius, segment, smooth and component toggles.",
    "公開されている32パッチ制御モデルを使用した Bezier Utah Teapot プリミティブです。3ds Max の半径、セグメント、スムーズ、部品切り替えに対応します。")
_set_description("compound_boolean",
    "Boolean object with procedural fallback preview and optional exact Blender Boolean modifier synchronization through operand sockets.",
    "手続き型フォールバックプレビューと、オペランドソケット経由の正確な Blender ブーリアンモディファイア同期に対応するブーリアンオブジェクトです。")
_set_description("compound_scatter",
    "Scatter object supporting built-in source primitives, source object operands, distribution object operands, distribution modes and random transforms.",
    "内蔵ソースプリミティブ、ソースオブジェクト、分布オブジェクト、分布方法、ランダム変換に対応するスキャッタオブジェクトです。")



# -----------------------------------------------------------------------------
# 3ds Max Shape generators
# -----------------------------------------------------------------------------
# Autodesk documents standard spline shapes, two NURBS curve types, and the five
# Extended Splines.  These entries add them as Max Primitives-compatible,
# non-destructive generators exposed through the same modifier socket workflow.
CATEGORIES.update({
    "shape_splines": {"en": "Shapes / Splines", "ja": "シェイプ / スプライン"},
    "shape_nurbs": {"en": "Shapes / NURBS Curves", "ja": "シェイプ / NURBS カーブ"},
    "shape_extended": {"en": "Shapes / Extended Splines", "ja": "シェイプ / 拡張スプライン"},
})

P_SHAPE_SEGMENTS = p(
    "segments", "Segments", "セグメント", "INT", 32, 1, 4096,
    desc_en="Number of generated points or interpolation segments used to approximate the spline in Blender. Increase this for smoother curves.",
    desc_ja="Blender上でスプラインを近似するための生成点数または補間分割数です。値を上げると曲線が滑らかになります。",
)
P_SHAPE_SIDES = p(
    "sides", "Sides", "辺数", "INT", 32, 3, 4096,
    desc_en="Number of sides used for circular or polygonal spline shapes.",
    desc_ja="円形または多角形シェイプに使用する辺数です。",
)
P_SHAPE_LENGTH = p(
    "length", "Length", "長さ", "FLOAT", 25.0, 0.001, 100000.0,
    desc_en="Primary horizontal size of the shape on the construction plane.",
    desc_ja="作図平面上の主方向サイズです。",
)
P_SHAPE_WIDTH = p(
    "width", "Width", "幅", "FLOAT", 25.0, 0.001, 100000.0,
    desc_en="Secondary horizontal size of the shape on the construction plane.",
    desc_ja="作図平面上の副方向サイズです。",
)
P_SHAPE_RADIUS = p(
    "radius", "Radius", "半径", "FLOAT", 25.0, 0.001, 100000.0,
    desc_en="Radius of the generated spline shape.",
    desc_ja="生成するスプラインシェイプの半径です。",
)
P_SHAPE_THICKNESS = p(
    "thickness", "Thickness", "厚み", "FLOAT", 2.5, 0.001, 100000.0,
    desc_en="Profile wall or flange thickness. Keep it smaller than the length and width to avoid self-intersection.",
    desc_ja="断面の壁またはフランジの厚みです。自己交差を避けるため、長さや幅より小さい値にしてください。",
)
P_SHAPE_ROTATION = p(
    "rotation", "Rotation", "回転", "FLOAT", 0.0, -360.0, 360.0,
    desc_en="Rotates the generated spline around its local center in degrees.",
    desc_ja="生成するスプラインをローカル中心で回転します。単位は度です。",
)

GENERATOR_SPECS.update({
    "shape_line": {
        "category": "shape_splines", "name": {"en": "Line", "ja": "ライン"},
        "description": {"en": "3ds Max style Line spline represented as an editable parametric polyline.", "ja": "3ds Max の Line に相当する、編集可能な手続き型ポリラインです。"},
        "params": [
            P_SHAPE_LENGTH, p("width", "End Y Offset", "終点Yオフセット", "FLOAT", 0.0, -100000.0, 100000.0,
                "Y offset from start to end. Use zero for a straight horizontal line.", "始点から終点までのY方向オフセットです。0で水平線になります。"),
            p("points", "Points", "点数", "INT", 2, 2, 4096, "Number of polyline vertices along the line.", "ライン上のポリライン頂点数です。"),
            p("closed", "Closed", "閉じる", "BOOL", False, "Connects the last point back to the first point.", "最後の点を最初の点へ接続します。"),
        ],
    },
    "shape_rectangle": {
        "category": "shape_splines", "name": {"en": "Rectangle", "ja": "長方形"},
        "description": {"en": "Parametric Rectangle spline with optional rounded corners.", "ja": "角丸を設定できる長方形スプラインです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, p("corner_radius", "Corner Radius", "角丸半径", "FLOAT", 0.0, 0.0, 100000.0,
            "Radius for rounded corners. Set to zero for sharp 3ds Max rectangle corners.", "角丸の半径です。0にすると3ds Maxの通常長方形と同じ鋭角になります。"), P_SHAPE_SEGMENTS, P_SHAPE_ROTATION],
    },
    "shape_circle": {
        "category": "shape_splines", "name": {"en": "Circle", "ja": "円"},
        "description": {"en": "Closed Circle spline with adjustable radius and side count.", "ja": "半径と辺数を調整できる閉じた円スプラインです。"},
        "params": [P_SHAPE_RADIUS, P_SHAPE_SIDES, P_SHAPE_ROTATION],
    },
    "shape_ellipse": {
        "category": "shape_splines", "name": {"en": "Ellipse", "ja": "楕円"},
        "description": {"en": "Closed Ellipse spline with independent length and width.", "ja": "長さと幅を個別に設定できる閉じた楕円スプラインです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_SIDES, P_SHAPE_ROTATION],
    },
    "shape_arc": {
        "category": "shape_splines", "name": {"en": "Arc", "ja": "円弧"},
        "description": {"en": "Open or closed Arc spline with start and end angles.", "ja": "開始角度と終了角度を持つ円弧スプラインです。"},
        "params": [P_SHAPE_RADIUS, p("start_angle", "Start Angle", "開始角度", "FLOAT", 0.0, -360.0, 360.0,
            "Arc start angle in degrees.", "円弧の開始角度です。単位は度です。"), p("end_angle", "End Angle", "終了角度", "FLOAT", 90.0, -360.0, 720.0,
            "Arc end angle in degrees.", "円弧の終了角度です。単位は度です。"), P_SHAPE_SEGMENTS, p("closed", "Closed Sector", "扇形として閉じる", "BOOL", False,
            "Adds center edges to close the arc as a sector outline.", "中心への辺を追加し、扇形のアウトラインとして閉じます。"), P_SHAPE_ROTATION],
    },
    "shape_donut": {
        "category": "shape_splines", "name": {"en": "Donut", "ja": "ドーナツ"},
        "description": {"en": "Donut spline made from two concentric closed circles.", "ja": "2つの同心円からなるドーナツスプラインです。"},
        "params": [p("radius1", "Radius 1", "半径 1", "FLOAT", 25.0, 0.001, 100000.0,
            "First donut circle radius.", "1つ目の円の半径です。"), p("radius2", "Radius 2", "半径 2", "FLOAT", 12.5, 0.001, 100000.0,
            "Second donut circle radius.", "2つ目の円の半径です。"), P_SHAPE_SIDES, P_SHAPE_ROTATION],
    },
    "shape_ngon": {
        "category": "shape_splines", "name": {"en": "NGon", "ja": "NGon"},
        "description": {"en": "Regular polygon spline equivalent to 3ds Max NGon.", "ja": "3ds Max の NGon に相当する正多角形スプラインです。"},
        "params": [P_SHAPE_RADIUS, p("sides", "Sides", "辺数", "INT", 6, 3, 4096,
            "Number of polygon sides.", "多角形の辺数です。"), p("circular", "Circular", "円形基準", "BOOL", True,
            "Uses the radius as a circumscribed circle radius. Turn off to use an inscribed radius.", "半径を外接円として扱います。無効にすると内接円基準になります。"), P_SHAPE_ROTATION],
    },
    "shape_star": {
        "category": "shape_splines", "name": {"en": "Star", "ja": "星形"},
        "description": {"en": "Star spline with independent outer and inner radii.", "ja": "外半径と内半径を個別に指定できる星形スプラインです。"},
        "params": [p("radius1", "Radius 1", "外半径", "FLOAT", 25.0, 0.001, 100000.0,
            "Outer radius of the star points.", "星形の外側頂点の半径です。"), p("radius2", "Radius 2", "内半径", "FLOAT", 10.0, 0.001, 100000.0,
            "Inner radius between star points.", "星形の谷部分の半径です。"), p("points", "Points", "ポイント数", "INT", 5, 2, 512,
            "Number of star points.", "星形の突起数です。"), P_SHAPE_ROTATION],
    },
    "shape_text": {
        "category": "shape_splines", "object_type": "FONT", "name": {"en": "Text", "ja": "テキスト"},
        "description": {"en": "3ds Max style Text shape using Blender font data while retaining Max Primitives modifier controls.", "ja": "Blenderのフォントデータを使い、Max Primitivesのモディファイア操作を保持するテキストシェイプです。"},
        "params": [
            p("text", "Text", "文字", "STRING", "Text", desc_en="Text displayed by the shape.", desc_ja="シェイプとして表示する文字列です。"),
            p("size", "Size", "サイズ", "FLOAT", 25.0, 0.001, 100000.0, "Text size.", "文字サイズです。"),
            p("extrude", "Extrude", "押し出し", "FLOAT", 0.0, 0.0, 100000.0, "Optional text extrusion depth.", "必要に応じた文字の押し出し量です。"),
            p("bevel_depth", "Bevel Depth", "ベベル深度", "FLOAT", 0.0, 0.0, 100000.0, "Optional bevel depth for rendered text outlines.", "文字アウトラインに付ける任意のベベル深度です。"),
            p("bevel_segments", "Bevel Segments", "ベベルセグメント", "INT", 0, 0, 32, "Number of bevel subdivisions.", "ベベルの分割数です。"),
            p("resolution", "Resolution", "解像度", "INT", 12, 1, 64, "Curve resolution of the font.", "フォントカーブの解像度です。"),
            p("align", "Alignment", "整列", "INT", 0, 0, 2, "0=Left, 1=Center, 2=Right.", "0=左、1=中央、2=右です。"),
            p("tracking", "Tracking", "字間", "FLOAT", 1.0, 0.01, 100.0, "Character spacing multiplier.", "文字間隔の倍率です。"),
            p("line_spacing", "Line Spacing", "行間", "FLOAT", 1.0, 0.01, 100.0, "Line spacing multiplier.", "行間の倍率です。"),
        ],
    },
    "shape_helix": {
        "category": "shape_splines", "name": {"en": "Helix", "ja": "ヘリックス"},
        "description": {"en": "3D Helix spline with radius, height and turn controls.", "ja": "半径、高さ、巻き数を調整できる3Dヘリックススプラインです。"},
        "params": [p("radius1", "Radius 1", "開始半径", "FLOAT", 25.0, 0.001, 100000.0,
            "Start radius of the helix.", "ヘリックス開始側の半径です。"), p("radius2", "Radius 2", "終了半径", "FLOAT", 25.0, 0.001, 100000.0,
            "End radius of the helix.", "ヘリックス終了側の半径です。"), p("height", "Height", "高さ", "FLOAT", 25.0, -100000.0, 100000.0,
            "Height along the local Z axis.", "ローカルZ軸方向の高さです。"), p("turns", "Turns", "巻き数", "FLOAT", 3.0, -100.0, 100.0,
            "Number of turns. Negative values reverse winding direction.", "巻き数です。負の値で巻き方向を反転します。"), P_SHAPE_SEGMENTS, P_SHAPE_ROTATION],
    },
    "shape_egg": {
        "category": "shape_splines", "name": {"en": "Egg", "ja": "エッグ"},
        "description": {"en": "Egg-shaped closed spline with adjustable length and width.", "ja": "長さと幅を調整できる卵形の閉じたスプラインです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_SIDES, P_SHAPE_ROTATION],
    },
    "shape_section": {
        "category": "shape_splines", "name": {"en": "Section", "ja": "セクション"},
        "description": {"en": "Section helper outline used as a 2D cutting/section reference shape.", "ja": "断面参照として使う2Dセクション補助アウトラインです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, p("show_cross", "Show Cross", "十字を表示", "BOOL", True,
            "Adds center cross lines to the section outline.", "セクションアウトラインに中心十字線を追加します。"), P_SHAPE_ROTATION],
    },
    "shape_freehand": {
        "category": "shape_splines", "name": {"en": "Freehand", "ja": "フリーハンド"},
        "description": {"en": "Deterministic freehand spline preview with seed and point count controls.", "ja": "シードと点数で制御できる決定論的なフリーハンドスプラインです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, p("points", "Points", "点数", "INT", 12, 2, 4096,
            "Number of sampled freehand points.", "フリーハンド曲線のサンプル点数です。"), p("seed", "Seed", "シード", "INT", 1, 0, 1000000,
            "Random seed for the freehand curve.", "フリーハンド曲線の乱数シードです。"), p("closed", "Closed", "閉じる", "BOOL", False,
            "Connects the freehand curve back to its first point.", "フリーハンド曲線を始点へ接続して閉じます。"), P_SHAPE_ROTATION],
    },
    "shape_nurbs_point_curve": {
        "category": "shape_nurbs", "name": {"en": "Point Curve", "ja": "ポイント カーブ"},
        "description": {"en": "NURBS Point Curve style parametric curve preview.", "ja": "NURBS ポイントカーブ風の手続き型カーブプレビューです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, p("points", "Points", "ポイント数", "INT", 5, 2, 128,
            "Number of defining points.", "定義ポイント数です。"), P_SHAPE_SEGMENTS, p("closed", "Closed", "閉じる", "BOOL", False,
            "Closes the approximated curve.", "近似カーブを閉じます。"), P_SHAPE_ROTATION],
    },
    "shape_nurbs_cv_curve": {
        "category": "shape_nurbs", "name": {"en": "CV Curve", "ja": "CV カーブ"},
        "description": {"en": "NURBS CV Curve style parametric curve preview.", "ja": "NURBS CVカーブ風の手続き型カーブプレビューです。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, p("points", "CVs", "CV数", "INT", 6, 2, 128,
            "Number of control vertices.", "制御頂点数です。"), P_SHAPE_SEGMENTS, p("closed", "Closed", "閉じる", "BOOL", False,
            "Closes the approximated curve.", "近似カーブを閉じます。"), P_SHAPE_ROTATION],
    },
    "shape_walled_rectangle": {
        "category": "shape_extended", "name": {"en": "WalledRectangle", "ja": "壁付き長方形"},
        "description": {"en": "Extended Spline WalledRectangle profile with outer and inner rectangular outlines.", "ja": "外形と内形を持つ拡張スプラインの壁付き長方形です。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_THICKNESS, p("corner_radius", "Corner Radius", "角丸半径", "FLOAT", 0.0, 0.0, 100000.0,
            "Rounded-corner radius for both wall outlines.", "外内の壁アウトラインに使う角丸半径です。"), P_SHAPE_SEGMENTS, P_SHAPE_ROTATION],
    },
    "shape_channel": {
        "category": "shape_extended", "name": {"en": "Channel", "ja": "チャンネル"},
        "description": {"en": "Extended Spline Channel C-profile.", "ja": "C字型断面の拡張スプライン Channel です。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_THICKNESS, P_SHAPE_ROTATION],
    },
    "shape_angle": {
        "category": "shape_extended", "name": {"en": "Angle", "ja": "アングル"},
        "description": {"en": "Extended Spline Angle L-profile.", "ja": "L字型断面の拡張スプライン Angle です。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_THICKNESS, P_SHAPE_ROTATION],
    },
    "shape_tee": {
        "category": "shape_extended", "name": {"en": "Tee", "ja": "T字"},
        "description": {"en": "Extended Spline Tee T-profile.", "ja": "T字型断面の拡張スプライン Tee です。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_THICKNESS, P_SHAPE_ROTATION],
    },
    "shape_wide_flange": {
        "category": "shape_extended", "name": {"en": "WideFlange", "ja": "ワイドフランジ"},
        "description": {"en": "Extended Spline WideFlange H/I-profile.", "ja": "H形/I形断面の拡張スプライン WideFlange です。"},
        "params": [P_SHAPE_LENGTH, P_SHAPE_WIDTH, P_SHAPE_THICKNESS, P_SHAPE_ROTATION],
    },
})

# -----------------------------------------------------------------------------
# Smart Geometry Suite size normalization
# -----------------------------------------------------------------------------
# Max Primitives exposes 3ds Max style dimensions, but the original defaults were
# too large for the Suite workflow.  The following pass scales only dimensional
# and explicit scale-like defaults to one tenth.  Angle, percentage, density,
# segment, shape-family and boolean parameters are intentionally unchanged.
_SMS_SIZE_DEFAULT_PARAM_IDS = {
    "length", "length1", "length2", "width", "depth", "height",
    "radius", "radius1", "radius2", "tube_radius", "inner_radius", "outer_radius",
    "target_radius", "shape_radius", "diameter",
    "size", "size_a", "size_b", "base_size", "cutter_radius",
    "fillet", "bevel", "bevel_depth", "extrude", "cap_height", "thickness",
    "opening", "opening_width", "opening_height", "opening_sill",
    "bottom_offset", "top_offset", "offset", "offset_x", "offset_y",
    "frame_width", "panel_thickness", "sash_width", "glass_thickness",
    "post_spacing", "post_radius", "rail_radius", "baluster_spacing", "corner_length",
    "tread_thickness", "landing", "nosing",
    "area", "spread", "scale", "scale_p", "scale_q", "scale_r", "scale_end", "render_scale", "random_scale", "path_length", "cut_depth", "gap",
    "trunk_radius", "leaf_size", "amplitude", "standoff_distance", "default_projection_distance",
    "curvature",
}
_SMS_SIZE_DEFAULT_SUFFIXES = (
    "_length", "_width", "_height", "_depth", "_radius", "_size", "_spacing",
    "_offset", "_thickness", "_distance", "_depth", "_gap",
)
_SMS_DIMENSIONLESS_DEFAULT_PARAM_IDS = {
    "density",
    "display_percent", "random_rotation", "eccentricity", "p", "q",
    "twist", "tube_twist", "tube_rotation", "phase", "turns", "wind", "season", "frame",
    "hemisphere", "amount", "threshold", "tension", "open", "open_angle", "shear",
    "tracking", "line_spacing", "slice_from", "slice_to", "bend",
}


def _sms_is_size_default_param(param):
    pid = str((param or {}).get("id") or "")
    if not pid or pid in _SMS_DIMENSIONLESS_DEFAULT_PARAM_IDS:
        return False
    if (param or {}).get("type") != "FLOAT":
        return False
    return pid in _SMS_SIZE_DEFAULT_PARAM_IDS or pid.endswith(_SMS_SIZE_DEFAULT_SUFFIXES)


# Parameters that should be presented with Blender distance-unit editing in the
# Geometry Nodes modifier UI.  This deliberately excludes scale multipliers,
# rotations, percentages and segment counts while keeping every true size,
# radius, offset, thickness and distance field unit-aware.
_SMS_DISTANCE_PARAM_IDS = {
    "length", "length1", "length2", "width", "depth", "height",
    "radius", "radius1", "radius2", "tube_radius", "inner_radius", "outer_radius",
    "target_radius", "shape_radius", "diameter",
    "size", "size_a", "size_b", "base_size", "cutter_radius",
    "fillet", "bevel", "bevel_depth", "extrude", "cap_height", "thickness",
    "opening", "opening_width", "opening_height", "opening_sill",
    "bottom_offset", "top_offset", "offset", "offset_x", "offset_y",
    "frame_width", "panel_thickness", "sash_width", "glass_thickness",
    "post_spacing", "post_radius", "rail_radius", "baluster_spacing", "corner_length",
    "tread_thickness", "landing", "nosing",
    "area", "spread", "scale", "path_length", "cut_depth", "gap",
    "trunk_radius", "leaf_size", "amplitude", "standoff_distance", "default_projection_distance",
    "curvature",
}
_SMS_DISTANCE_PARAM_SUFFIXES = (
    "_length", "_width", "_height", "_depth", "_radius", "_size", "_spacing",
    "_offset", "_thickness", "_distance", "_gap",
)
_SMS_FORCE_DIMENSIONLESS_PARAM_IDS = _SMS_DIMENSIONLESS_DEFAULT_PARAM_IDS | {
    "scale_p", "scale_q", "scale_r", "scale_end", "render_scale", "random_scale",
    "map_scale", "resolution", "segments", "sides", "rings", "steps",
}


def is_distance_param(param):
    """Return True for float parameters that should use Blender distance units."""
    pid = str((param or {}).get("id") or "")
    if not pid or pid in _SMS_FORCE_DIMENSIONLESS_PARAM_IDS:
        return False
    if (param or {}).get("type") != "FLOAT":
        return False
    return pid in _SMS_DISTANCE_PARAM_IDS or pid.endswith(_SMS_DISTANCE_PARAM_SUFFIXES)


def _sms_scale_max_primitive_size_defaults(factor=0.1):
    # Several shape specs intentionally reuse shared parameter dictionaries so
    # labels and tooltips stay consistent.  Scale each dictionary object only
    # once; otherwise shared radius/length defaults would be multiplied again
    # for every generator using the same parameter instance.
    _seen_param_objects = set()
    for _generator_id, _spec in GENERATOR_SPECS.items():
        for _param in _spec.get("params", []):
            if id(_param) in _seen_param_objects:
                continue
            _seen_param_objects.add(id(_param))
            if not _sms_is_size_default_param(_param):
                continue
            try:
                _param["default"] = float(_param.get("default", 0.0)) * float(factor)
            except Exception:
                pass


_sms_scale_max_primitive_size_defaults(0.1)
