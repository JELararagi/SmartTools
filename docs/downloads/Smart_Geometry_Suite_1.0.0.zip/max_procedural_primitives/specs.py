"""Saved generator identifiers and native modifier control defaults."""
from ..catalog import CATALOG, PUBLIC
GENERATOR_SPECS=CATALOG['primitives']
NAMES=PUBLIC['primitives']

