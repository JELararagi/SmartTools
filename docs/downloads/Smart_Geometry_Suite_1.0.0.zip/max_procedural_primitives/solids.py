"""Parametric solid, patch and spline surfaces derived from their public dimensions."""
from math import sin,cos,pi,tau,radians,sqrt
import bmesh
from mathutils import Vector
from ..mesh_form import MeshForm,around,lathe,rect_prism,profile_tube,capped_count
from .teapot_surfaces import component_patches
from .curves import section_points

def cuboid(p):
    a,b,c=p['length'],p['width'],p['height'];nx=capped_count(p.get('length_segments',1));ny=capped_count(p.get('width_segments',1));nz=capped_count(p.get('height_segments',1))
    mesh=MeshForm()
    for top in (False,True):
        mesh.grid(nx,ny,lambda u,v:(a*(u-.5),b*(v-.5 if top else .5-v),c if top else 0))
    for plus in (False,True):
        mesh.grid(nx,nz,lambda u,v:(a*(.5-u if plus else u-.5),b*(.5 if plus else -.5),c*v))
        mesh.grid(ny,nz,lambda u,v:(a*(.5 if plus else -.5),b*(u-.5 if plus else .5-u),c*v))
    return mesh.merge_seams()

def geodesic(radius,n,half,raised):
    bm=bmesh.new();bmesh.ops.create_icosphere(bm,subdivisions=1,radius=1);mesh=MeshForm()
    for face in bm.faces:
        p,q,r=[v.co.copy() for v in face.verts];levels=[]
        for j in range(n+1):
            pts=[]
            for i in range(n-j+1):
                co=(p+(q-p)*(i/n)+(r-p)*(j/n)).normalized()*radius
                if raised:co.z+=radius
                pts.append(mesh.vertex(co))
            levels.append(pts)
        for row,nextrow in zip(levels,levels[1:]):
            for i in range(len(nextrow)):
                mesh.faces.append((row[i],row[i+1],nextrow[i]))
                if i+1<len(nextrow):mesh.faces.append((row[i+1],nextrow[i+1],nextrow[i]))
    bm.free()
    if half:
        plane=radius if raised else 0
        mesh.faces[:]=[f for f in mesh.faces if all(mesh.vertices[i][2]>=plane-1e-8 for i in f)]
        used=sorted({i for f in mesh.faces for i in f});mapping={a:i for i,a in enumerate(used)};mesh.vertices=[mesh.vertices[i] for i in used];mesh.faces=[tuple(mapping[i] for i in f) for f in mesh.faces]
    return mesh.merge_seams()

def teapot(p):
    m=MeshForm();n=capped_count(p['segments'],1,96)
    def weights(t):return ((1-t)**3,3*t*(1-t)**2,3*t*t*(1-t),t**3)
    for part,patches in component_patches().items():
        if not p.get(part,True):continue
        for patch in patches:
            def sample(u,v):
                a,b=weights(u),weights(v)
                return tuple(p['radius']*sum(a[i]*b[j]*patch[i*4+j][axis] for i in range(4) for j in range(4)) for axis in range(3))
            m.grid(n,n,sample)
    return m.merge_seams()

def patch(k,p):
    m=MeshForm();w=p.get('length',p.get('width',4));d=p.get('height',p.get('width',4));h=p.get('curvature',0)
    if k=='patch_tri':
        n=capped_count(p.get('segments',6))
        rows=[[m.vertex((w*(i/n+j/(2*n)-.5),d*(j/n-.5),h*sin(pi*i/n)*sin(pi*j/n))) for i in range(n-j+1)] for j in range(n+1)]
        for a,b in zip(rows,rows[1:]):
            for i in range(len(b)):
                m.faces.append((a[i],a[i+1],b[i]))
                if i+1<len(b):m.faces.append((a[i+1],b[i+1],b[i]))
    else:
        n=capped_count(p.get('length_segments',p.get('u_points',p.get('u_cvs',4))));t=capped_count(p.get('width_segments',p.get('v_points',p.get('v_cvs',4))))
        factor=p.get('render_scale',1);m.grid(n,t,lambda u,v:((u-.5)*w*factor,(v-.5)*d*factor,h*sin(pi*u)*sin(pi*v)))
    return m

def beveled(mesh,amount,segments):
    if amount<=0:return mesh
    bm=bmesh.new();verts=[bm.verts.new(v) for v in mesh.vertices]
    for face in mesh.faces:bm.faces.new([verts[i] for i in face])
    bmesh.ops.bevel(bm,geom=list(bm.edges),offset=amount,segments=capped_count(segments,1,24),affect='EDGES',clamp_overlap=True)
    bm.verts.index_update();out=MeshForm();out.vertices=[tuple(v.co) for v in bm.verts];out.faces=[tuple(v.index for v in f.verts) for f in bm.faces];bm.free();return out

def build(k,p):
    name=k.split('_',1)[-1];n=capped_count(p.get('sides',24),3,1024);z=p.get('height',2.5);r=p.get('radius',1.5)
    start=radians(p.get('slice_from',0)) if p.get('slice_on') else 0
    sweep=radians(p.get('slice_to',360))-start if p.get('slice_on') else tau
    if abs(sweep)<1e-7:sweep=tau
    if name in ('box','chamferbox'):
        mesh=cuboid(p);return beveled(mesh,p['fillet'],p['fillet_segments']) if name=='chamferbox' else mesh
    if name in ('plane','quad','tri','point','cv'):return patch(k,p)
    if name=='geosphere':return geodesic(r,capped_count(p['segments'],1,32),p['hemisphere'],p['base_to_pivot'])
    if name=='sphere':
        n=capped_count(p['segments'],3,512);v=max(2,n//2);lower=-pi/2+pi*p['hemisphere']
        rows=[(r*cos(a),r*sin(a)) for a in (lower+(pi/2-lower)*j/v for j in range(v+1))]
        if p['recenter']:rows=[(rad,h-rows[0][1]) for rad,h in rows]
        return lathe(rows,n,start,sweep,caps=p['hemisphere']>1e-8)
    if name=='tube':
        a,b=p['radius1'],p['radius2'];nh=capped_count(p['height_segments']);nc=capped_count(p['cap_segments'])
        profile=[(a,z*j/nh) for j in range(nh)]+[(a+(b-a)*i/nc,z) for i in range(nc)]+[(b,z*(1-j/nh)) for j in range(nh)]+[(b+(a-b)*i/nc,0) for i in range(nc+1)]
        return lathe(profile,n,start,sweep).merge_seams()
    if name in ('cylinder','cone','chamfercyl','spindle','oiltank','capsule','gengon'):
        a=p.get('radius1',r);b=p.get('radius2',r);h=capped_count(p.get('height_segments',1));profile=[(a+(b-a)*i/h,z*i/h) for i in range(h+1)]
        if name=='spindle':
            cap=min(z/2,p['cap_height']);profile=[(0,0),(r,cap),(r,z-cap),(0,z)]
        if name in ('capsule','oiltank'):
            cap=r if name=='capsule' else p['cap_height'];m=capped_count(p['cap_segments']);mid=max(0,z-2*cap) if name=='oiltank' or not p.get('height_type',True) else z
            profile=[(r*sin(pi*i/(2*m)),cap*(1-cos(pi*i/(2*m)))) for i in range(m+1)]+[(r,cap+mid*i/h) for i in range(1,h+1)]+[(r*cos(pi*i/(2*m)),cap+mid+cap*sin(pi*i/(2*m))) for i in range(1,m+1)]
        mesh=lathe(profile,n,start,sweep,caps=True)
        if name=='chamfercyl':
            fillet=min(abs(r),abs(z)*.5,p['fillet']);steps=capped_count(p['fillet_segments'],1,64)
            edge=[(r-fillet+fillet*sin(.5*pi*i/steps),fillet*(1-cos(.5*pi*i/steps))) for i in range(steps+1)]
            profile=edge+[(rad,z-hh) for rad,hh in reversed(edge)]
            return lathe(profile,n,start,sweep,caps=True)
        if name=='gengon' and p.get('fillet',0)>0:mesh=beveled(mesh,p['fillet'],p['fillet_segments'])
        return mesh
    if name in ('torus','torusknot','hose'):
        count=capped_count(p.get('segments',32),3,1024)
        if name=='torus':
            a,b=p['radius1'],p['radius2'];mesh=MeshForm()
            rings=mesh.rings([[((a+b*cos(phi))*cos(theta),(a+b*cos(phi))*sin(theta),b*sin(phi)) for phi in [tau*j/n+radians(p['tube_rotation'])+radians(p['tube_twist'])*i/count for j in range(n)]] for i,theta in enumerate([start+sweep*t/count for t in range(count+(abs(sweep-tau)>1e-6))])])
            if abs(sweep-tau)<1e-6:mesh.bridge(rings[-1],rings[0])
            else:mesh.faces.extend((tuple(rings[0][::-1]),tuple(rings[-1])))
            return mesh
        if name=='torusknot':
            def position(t):
                big=r*(1+.33*p['eccentricity']*cos(p['q']*t))
                return big*cos(p['p']*t),big*sin(p['p']*t),r*.33*sin(p['q']*t)
            return profile_tube([position(tau*i/count) for i in range(count)],p['tube_radius'],n,True)
        base=p.get('start_object');tip=p.get('end_object')
        start=base.matrix_world.translation.copy() if base else Vector()
        end=tip.matrix_world.translation.copy() if tip else start+Vector((0,0,p['length']))
        delta=end-start;side=delta.orthogonal().normalized() if delta.length else Vector((1,0,0));path=[]
        for i in range(count+1):
            t=i/count;smooth=t*t*(3-2*t);point=start+delta*(t+(smooth-t)*max(-1,min(1,p['tension'])))+side*p.get('bend',0)*sin(pi*t)
            path.append(point-start)
        return profile_tube(path,lambda i:p.get('diameter',r)/2*(1+p['amplitude']*sin(tau*p['cycles']*i/count)),n)
    if name in ('pyramid','prism'):
        m=MeshForm();w,d=p['width']/2,p['depth']/2
        if name=='prism':return rect_prism([(-w,-d),(w,-d),(0,d)],z)
        ids=m.rings([[(-w,-d,0),(w,-d,0),(w,d,0),(-w,d,0)],[(0,0,z)]]);m.faces.append(tuple(reversed(ids[0])));return m
    if name=='hedra':
        family=int(p['family']);rz=r*p['scale_r'];scale_x=r*p['scale_p'];scale_y=r*p['scale_q']
        if family==2:m=lathe([(0,-1),(1,0),(0,1)],4)
        elif family==0:m=rect_prism([(cos(tau*j/3),sin(tau*j/3)) for j in range(3)],1)
        elif family==1:m=MeshForm().add_box(-1,1,-1,1,-1,1)
        else:m=geodesic(1,1,False,False)
        if p['dual']:
            centers=[sum((Vector(m.vertices[i]) for i in face),Vector())/len(face) for face in m.faces];dual=MeshForm();dual.vertices=[tuple(v) for v in centers]
            from math import atan2
            for i,vertex in enumerate(m.vertices):
                linked=[j for j,f in enumerate(m.faces) if i in f];normal=Vector(vertex).normalized();u=normal.orthogonal().normalized();v=normal.cross(u)
                if len(linked)>=3:dual.faces.append(tuple(sorted(linked,key=lambda j:atan2(centers[j].dot(v),centers[j].dot(u)))))
            m=dual
        if p['stellation']:
            faces=m.faces;m.faces=[]
            for face in faces:
                center=sum((Vector(m.vertices[i]) for i in face),Vector())/len(face);tip=m.vertex(center+center.normalized()*p['stellation'])
                m.faces.extend((a,b,tip) for a,b in zip(face,face[1:]+face[:1]))
        m.vertices=[(x*scale_x*(.5+p['p']),y*scale_y*(.5+p['q']),zz*rz) for x,y,zz in m.vertices];return m
    if name in ('l_ext','c_ext'):return rect_prism(section_points('angle' if name=='l_ext' else 'channel',p['length'],p['width'],p['thickness']),z)
    if name=='ringwave':
        count=capped_count(p['segments'],3,2048);m=MeshForm()
        loops=[[((rr+p['amplitude']*sin(p['waves']*t+radians(p['phase'])))*cos(t),(rr+p['amplitude']*sin(p['waves']*t+radians(p['phase'])))*sin(t),h) for t in [tau*i/count for i in range(count)]] for rr,h in ((p['outer_radius'],0),(p['outer_radius'],z),(p['inner_radius'],z),(p['inner_radius'],0))]
        rows=m.rings(loops);m.bridge(rows[-1],rows[0]);return m
    if name=='teapot':return teapot(p)
    raise ValueError(k)
