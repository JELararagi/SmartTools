from math import cos,sin,tau,pi,radians
from random import Random
from .splines import bspline, cardinal
from ..mesh_form import MeshForm,capped_count

def section_points(shape,w,h,t):
    x,y=w/2,h/2;t=min(t,w/2,h/2)
    if shape=='angle':return [(-x,-y),(x,-y),(x,-y+t),(-x+t,-y+t),(-x+t,y),(-x,y)]
    if shape=='channel':return [(-x,-y),(x,-y),(x,-y+t),(-x+t,-y+t),(-x+t,y-t),(x,y-t),(x,y),(-x,y)]
    if shape=='tee':return [(-x,y),(x,y),(x,y-t),(t/2,y-t),(t/2,-y),(-t/2,-y),(-t/2,y-t),(-x,y-t)]
    if shape=='wide_flange':return [(-x,-y),(x,-y),(x,-y+t),(t/2,-y+t),(t/2,y-t),(x,y-t),(x,y),(-x,y),(-x,y-t),(-t/2,y-t),(-t/2,-y+t),(-x,-y+t)]
    return [(-x,-y),(x,-y),(x,y),(-x,y)]

def outline(k,p):
    m=MeshForm();name=k.removeprefix('shape_');angle=radians(p.get('rotation',0));ca,sa=cos(angle),sin(angle)
    def add(coords,closed=True):
        m.line([(a*ca-b*sa,a*sa+b*ca,z) for a,b,z in (tuple(v) if len(v)==3 else (*v,0) for v in coords)],closed)
    w=p.get('length',2.5);h=p.get('width',2.5);n=capped_count(p.get('sides',p.get('segments',32)),3,2048)
    r=p.get('radius',2.5)
    def arc(rx,ry,n,start=0,sweep=tau,closed=True):add([(rx*cos(start+sweep*i/n),ry*sin(start+sweep*i/n)) for i in range(n if closed else n+1)],closed)
    if name in ('line','freehand','nurbs_point_curve','nurbs_cv_curve'):
        if name=='line':n=capped_count(p['points'],2);a=[(w*(i/(n-1)-.5),h*i/(n-1)) for i in range(n)]
        elif name=='freehand':
            rng=Random(p.get('seed',1));n=capped_count(p['points'],2);a=[(w*(i/(n-1)-.5),h*(rng.random()-.5)) for i in range(n)]
        else:
            n=capped_count(p['segments']+1,2,2048);count=capped_count(p['points'],2,256)
            amplitude=.35 if name=='nurbs_point_curve' else .83
            controls=[(w*(j/(count-1)-.5),h*amplitude*sin(tau*j/(count-1)),0) for j in range(count)]
            if name=='nurbs_point_curve':
                closed=p.get('closed',False)
                # A closed ring joins the last sample to the first with an edge.
                # Sample the endpoint only on an open curve, where it is distinct.
                steps=n-1
                a=[cardinal(controls,i/steps,closed) for i in range(steps if closed else n)]
            else:a=[bspline(controls,i/(n-1),3) for i in range(n)]
        add(a,p.get('closed',False))
    elif name=='helix':
        n=capped_count(p['segments'],3,2048);add([((p['radius1']+(p['radius2']-p['radius1'])*i/n)*cos(tau*p['turns']*i/n),(p['radius1']+(p['radius2']-p['radius1'])*i/n)*sin(tau*p['turns']*i/n),p['height']*i/n) for i in range(n+1)],False)
    elif name in ('circle','ngon'):
        if name=='ngon':
            n=capped_count(p['sides'],3,4096)
            if not p['circular']:
                # Radius here measures centre to edge. Convert to vertex radius.
                r/=cos(pi/n)
        arc(r,r,n)
    elif name=='ellipse':arc(w/2,h/2,n)
    elif name=='rectangle' and p.get('corner_radius',0)>0:
        r=min(w/2,h/2,p['corner_radius']);quarter=max(2,n//4);coords=[]
        for x,y,angle in ((w/2-r,h/2-r,0),(-w/2+r,h/2-r,pi/2),(-w/2+r,-h/2+r,pi),(w/2-r,-h/2+r,1.5*pi)):
            coords.extend((x+r*cos(angle+pi*j/(2*quarter)),y+r*sin(angle+pi*j/(2*quarter))) for j in range(quarter+1))
        add(coords)
    elif name=='arc':
        a,b=radians(p['start_angle']),radians(p['end_angle']);coords=[(r*cos(a+(b-a)*i/n),r*sin(a+(b-a)*i/n)) for i in range(n+1)]
        if p['closed']:coords.append((0,0))
        add(coords,p['closed'])
    elif name=='egg':add([(.5*w*cos(t)*(1-.22*sin(t)),.5*h*sin(t)) for t in [tau*i/n for i in range(n)]])
    elif name=='donut':
        for rr in (p['radius1'],p['radius2']):arc(rr,rr,n)
    elif name=='star':
        sides=capped_count(p['points'],2);add([(p['radius1' if i%2==0 else 'radius2']*cos(pi*i/sides),p['radius1' if i%2==0 else 'radius2']*sin(pi*i/sides)) for i in range(2*sides)])
    else:
        add(section_points(name,w,h,p.get('thickness',.1)))
        if name=='walled_rectangle':add(section_points('rectangle',max(0,w-2*p['thickness']),max(0,h-2*p['thickness']),0))
        if name=='section' and p.get('show_cross'):
            add([(-w/2,0),(w/2,0)],False);add([(0,-h/2),(0,h/2)],False)
    return m
