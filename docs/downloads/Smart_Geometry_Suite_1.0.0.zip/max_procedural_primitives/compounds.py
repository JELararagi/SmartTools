"""Independent compound tools operating on source meshes in local coordinates."""
from contextlib import ExitStack
from math import cos, sin, pi, tau, exp, sqrt, radians
from random import Random
import bpy
from mathutils import Matrix, Vector, noise
from ..mesh_form import MeshForm, profile_tube, lathe, rect_prism, capped_count

def capture(obj):
    out=MeshForm()
    if not obj:return out
    evaluated=obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
    data=evaluated.to_mesh()
    if data:
        try:
            out.vertices=[tuple(v.co) for v in data.vertices]
            out.faces=[tuple(f.vertices) for f in data.polygons]
            out.edges=[tuple(e.vertices) for e in data.edges if e.is_loose]
        finally:evaluated.to_mesh_clear()
    return out

def boolean(a,b,operation):
    def temporary(shape,stack):
        data=bpy.data.meshes.new('SGS Boolean Working Mesh')
        stack.callback(bpy.data.meshes.remove,data);data.from_pydata(shape.vertices,shape.edges,shape.faces);data.update()
        ob=bpy.data.objects.new('SGS Boolean Working Object',data);stack.callback(bpy.data.objects.remove,ob,do_unlink=True)
        bpy.context.scene.collection.objects.link(ob)
        return ob
    with ExitStack() as stack:
        left=temporary(a,stack);right=temporary(b,stack)
        mod=left.modifiers.new('Volume operation','BOOLEAN');mod.operation=('UNION','DIFFERENCE','INTERSECT')[min(2,max(0,int(operation)))];mod.object=right;mod.solver='EXACT'
        bpy.context.view_layer.update()
        return capture(left)

def sphere(r,n=12):
    return lathe([(r*sin(pi*i/n),-r*cos(pi*i/n)) for i in range(n+1)],n*2)

def cube(r):
    return MeshForm().add_box(-r/2,r/2,-r/2,r/2,-r/2,r/2)

def get_shape(obj,alternative):
    return capture(obj) if obj else alternative()

def build(k,p):
    key=k.removeprefix('compound_');out=MeshForm();rng=Random(p.get('seed',1));n=capped_count(p.get('segments',12),2,256);r=p.get('radius',1)
    if key in ('boolean','proboolean'):
        if key=='boolean':
            a=get_shape(p['operand_a'],lambda:cube(p['size_a']))
            b=get_shape(p['operand_b'],lambda:cube(p['size_b']));offset=Vector((p['offset'],0,0)) if not p['operand_b'] else p['operand_b'].location-(p['operand_a'].location if p['operand_a'] else Vector())
            moved=MeshForm().append(b,lambda x:x+offset);return boolean(a,moved,p['operation'])
        a=cube(p['base_size']);operands=[p['operand_'+str(i)] for i in range(1,5)]
        if any(operands):
            for i,o in enumerate(operands):
                if o:a=boolean(a,MeshForm().append(capture(o),lambda x:o.matrix_world@x),p['operation_'+str(i+1)])
        else:
            count=capped_count(p['cutter_count'],1,32);radius=p['cutter_radius'];size=p['base_size']
            for i in range(count):
                angle=tau*i/count;at=Vector((.28*size*cos(angle),.28*size*sin(angle),size*.43));a=boolean(a,MeshForm().append(sphere(radius,8),lambda co:co+at),p['operation'])
        return a
    if key=='procutter':
        size=p['size'];n=capped_count(p['pieces'],1,512);cuts=[p['cutter_'+str(i)] for i in range(1,5)]
        if any(cuts):
            out=get_shape(p['base_object'],lambda:cube(size))
            for cut in filter(None,cuts):out=boolean(out,MeshForm().append(capture(cut),lambda x:cut.matrix_world@x),1)
            return out
        from .cells import fracture
        base=capture(p['base_object']) if p['base_object'] else None
        for piece in fracture(size,n,p['gap'],p['seed']):
            if base and base.vertices:
                lo=min(v[2] for v in base.vertices)-.01;hi=max(v[2] for v in base.vertices)+.01;piece.vertices=[(x,y,lo if z<0 else hi) for x,y,z in piece.vertices]
                out.append(boolean(base,piece,2))
            else:out.append(piece)
        return out
    if key=='morph':
        base=get_shape(p['source_object'],lambda:sphere(r,n));target=capture(p['target_object']);a=p['amount']/100
        if target.vertices and len(target.vertices)==len(base.vertices):ends=target.vertices
        else:ends=[Vector(v)*(r/max(max(abs(c) for c in v),.0001)) for v in base.vertices]
        base.vertices=[tuple(Vector(v).lerp(Vector(end),a)) for v,end in zip(base.vertices,ends)];return base
    if key=='conform':
        obj=p['wrap_to_object'];radius=p['target_radius'];w=p['width'];a=p['amount']/100
        base=get_shape(p['wrapper_object'],lambda:MeshForm().grid(n,n,lambda u,v:((u-.5)*w,(v-.5)*w,0)))
        points=[]
        for co in map(Vector,base.vertices):
            hit=None
            if obj:
                ok,at,normal,_=obj.closest_point_on_mesh(co,distance=p['default_projection_distance'])
                if ok:hit=at+normal*p['standoff_distance']
            else:hit=Vector((co.x,co.y,sqrt(max(0,radius*radius-co.x**2-co.y**2))-radius+p['standoff_distance']))
            points.append(tuple(co.lerp(hit,a)) if hit is not None else tuple(co))
        base.vertices=points;return base
    if key=='connect':
        sides=capped_count(p['sides'],3,512);dz=p['length'];rot=radians(p['twist'])
        ids=out.rings([[(r*cos(tau*j/sides+i*rot),r*sin(tau*j/sides+i*rot),i*dz) for j in range(sides)] for i in (0,1)])
        out.faces.extend((tuple(ids[0][::-1]),tuple(ids[-1])));return out
    if key=='terrain':
        span=p['size'];coords=capture(p['contour_object']).vertices if p['contour_object'] else []
        def sample(u,v):
            x,y=(u-.5)*span,(v-.5)*span
            if coords:
                nearest=sorted(coords,key=lambda q:(x-q[0])**2+(y-q[1])**2)[:4];weights=[1/(.01+(x-q[0])**2+(y-q[1])**2) for q in nearest];z=sum(q[2]*w for q,w in zip(nearest,weights))/sum(weights)
            else:z=.5*p['height']*(1+noise.fractal(Vector((u*3,v*3,p['seed']*.171)),1,2,4))
            if p['terrace']:
                step=p['height']/max(1,p['contours']);z+=p['terrace']*(round(z/max(.001,step))*step-z)
            return x,y,z
        return out.grid(n,n,sample)
    if key=='loft':
        segments=capped_count(p['path_segments'],2,768);sides=capped_count(p['sides'],3,256);ln=p['path_length'];path=capture(p['path_object']).vertices if p['path_object'] else []
        path=path or [(ln*(i/segments-.5),r*sin(tau*i/segments),r*(1-cos(tau*i/segments))) for i in range(segments+1)]
        profile=capture(p['shape_object']).vertices if p['shape_object'] else [(r*cos(tau*j/sides),r*sin(tau*j/sides),0) for j in range(sides)]
        rings=[]
        for i,center in enumerate(map(Vector,path)):
            t=i/max(1,len(path)-1);tangent=Vector(path[min(i+1,len(path)-1)])-Vector(path[max(i-1,0)]);orient=tangent.to_track_quat('Z','Y');twist=Matrix.Rotation(radians(p['twist'])*t,3,'Z');s=1+(p['scale_end']-1)*t
            rings.append([center+orient@(twist@Vector(v)*s) for v in profile])
        ids=out.rings(rings);out.faces.extend((tuple(ids[0][::-1]),tuple(ids[-1])));return out
    if key=='shapemerge':
        base=get_shape(p['base_object'],lambda:MeshForm().add_box(-p['width']/2,p['width']/2,-p['width']/2,p['width']/2,-max(.001,p['cut_depth']),0));depth=max(.001,p['cut_depth']);sides=capped_count(p['sides'],3,512)
        coords=capture(p['shape_object']).vertices if p['shape_object'] else [(p['shape_radius']*cos(tau*j/sides),p['shape_radius']*sin(tau*j/sides),0) for j in range(sides)]
        cutter=rect_prism([v[:2] for v in coords],depth+.01)
        return boolean(base,MeshForm().append(cutter,lambda v:v-Vector((0,0,depth))),2 if p['merge_mode']==2 else 1)
    if key=='blobmesh':
        metaballs=bpy.data.metaballs.new('SGS Blob Field');ob=bpy.data.objects.new('SGS Blob Sampling',metaballs);bpy.context.scene.collection.objects.link(ob)
        try:
            metaballs.resolution=max(.04,r*3/max(4,p['resolution']));metaballs.threshold=p['threshold']
            for _ in range(capped_count(p['count'],1,128)):
                e=metaballs.elements.new();e.co=[rng.uniform(-r*1.4,r*1.4) for _ in range(3)];e.radius=r;e.stiffness=min(10,max(.01,p['tension']))
            bpy.context.view_layer.update();return capture(ob)
        finally:bpy.data.objects.remove(ob,do_unlink=True);bpy.data.metaballs.remove(metaballs)
    if key in ('scatter','mesher'):
        obj=p.get('source_object');template=get_shape(obj,lambda:sphere(1,4));dist=p.get('distribution_object');samples=capture(dist).vertices if dist and p.get('use_distribution_object') else [];extent=p.get('area',p.get('spread',8));scale=p.get('scale',r)
        count=capped_count(int(p['count']*p.get('display_percent',100)/100),0,25000)
        for j in range(count):
            at=Vector(rng.choice(samples)) if samples else Vector((rng.uniform(-.5,.5)*extent,rng.uniform(-.5,.5)*extent,rng.uniform(-.12,.12)*extent if key=='mesher' else 0))
            if key=='mesher':at.z+=p['frame']*.03
            angle=radians(p.get('random_rotation',360))*rng.random();rot=Matrix.Rotation(angle,3,'Z');s=scale*(1+rng.uniform(-1,1)*p.get('random_scale',0)/100)
            out.append(template,lambda co:at+rot@co*s)
            if p.get('velocity_trails'):out.append(profile_tube([at,at-Vector((0,0,r*2))],r*.15,5))
        return out
    raise ValueError(key)
