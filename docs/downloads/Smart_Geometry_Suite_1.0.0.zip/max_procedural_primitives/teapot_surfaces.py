# SPDX-License-Identifier: GPL-3.0-or-later
"""Original bicubic surface construction for a four-part tea vessel."""
from math import tau, tan, hypot


def quarter(direction):
    # Integer quadrant endpoints give neighboring patches byte-identical seams.
    axis = ((1,0),(0,1),(-1,0),(0,-1))
    x,y = axis[direction]
    u,v = axis[(direction+1)%4]
    k = 4*tan(tau/16)/3
    return ((x,y),(x-k*y,y+k*x),(u+k*v,v-k*u),(u,v))


def lathe(profile):
    return [[(r*x,r*y,z) for r,z in profile for x,y in quarter(side)] for side in range(4)]


def tube(sections):
    """Cross-section normals follow the handle or spout centerline in the XZ plane."""
    patches = []
    for side in range(4):
        patch = []
        for index,(x,z,minor,major) in enumerate(sections):
            before = sections[max(0,index-1)]
            after = sections[min(len(sections)-1,index+1)]
            dx,dz = after[0]-before[0],after[1]-before[1]
            length = hypot(dx,dz)
            for c,s in quarter(side):
                patch.append((x-major*s*dz/length,minor*c,z+major*s*dx/length))
        patches.append(patch)
    return patches


def component_patches():
    # Each profile segment carries its own tangents through its two inner controls.
    lower = ((0.35,0.04),(0.44,0.04),(0.56,0.15),(0.57,0.34))
    waist = ((0.57,0.34),(0.59,0.48),(0.55,0.58),(0.49,0.65))
    shoulder = ((0.49,0.65),(0.45,0.70),(0.34,0.73),(0.32,0.74))
    foot = ((0.0,0.0),(0.14,0.0),(0.32,0.0),(0.35,0.04))
    crown = ((0.32,0.74),(0.31,0.77),(0.17,0.83),(0.08,0.83))
    finial = ((0.08,0.83),(0.055,0.87),(0.14,0.91),(0.0,0.93))
    handle = ((-0.44,0.60,0.07,0.068),(-1.12,0.97,0.058,0.06),
              (-1.18,0.10,0.065,0.06),(-0.47,0.20,0.079,0.085))
    spout = ((0.42,0.30,0.17,0.16),(0.75,0.32,0.11,0.13),
             (0.78,0.68,0.072,0.07),(0.98,0.71,0.086,0.058))
    return {'body':lathe(foot)+lathe(lower)+lathe(waist)+lathe(shoulder),
            'handle':tube(handle),'spout':tube(spout),'lid':lathe(crown)+lathe(finial)}
