"""Clamped non-rational B-splines and cardinal interpolation on 3D control points."""
from mathutils import Vector
def bspline(points,u,degree):
    coords=[Vector(p) for p in points];last=len(coords)-1
    if not coords:raise ValueError('A spline needs control points')
    if last==0:return coords[0]
    d=max(1,min(last,int(degree)));u=max(0,min(1,u))
    if u>=1:return coords[-1]
    span_count=last+1-d;knots=[0.]*(d+1)+[i/span_count for i in range(1,span_count)]+[1.]*(d+1)
    k=next(i for i in range(d,last+1) if knots[i]<=u<knots[i+1]);work=coords[k-d:k+1]
    for level in range(1,d+1):
        for j in range(d,level-1,-1):
            left=k-d+j;den=knots[left+d+1-level]-knots[left];alpha=(u-knots[left])/den if den>0 else 0
            work[j]=work[j-1].lerp(work[j],alpha)
    return work[-1]
def cardinal(points,u,cyclic=False):
    data=[Vector(p) for p in points];n=len(data);span=n if cyclic else n-1
    t=max(0,min(1,u))*span;i=min(span-1,int(t));t-=i
    def at(k):return data[k%n if cyclic else max(0,min(n-1,k))]
    a,b,c,d=at(i-1),at(i),at(i+1),at(i+2)
    return ((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)*.5

