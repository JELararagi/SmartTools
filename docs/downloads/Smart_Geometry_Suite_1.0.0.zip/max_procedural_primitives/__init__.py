"""Parametric objects driven by native modifier input values."""
