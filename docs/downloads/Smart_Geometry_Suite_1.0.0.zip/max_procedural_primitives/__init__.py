# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Lazy integrated Max Primitives package.

Importing this package does not import specifications, mesh data, handlers, RNA
classes, or UI modules.  Smart Geometry registers lightweight bridge classes and
loads individual implementation modules only when a Max command is invoked.
"""

from __future__ import annotations

import importlib

bl_info = {
    'name': 'Max Primitives',
    'author': 'JELararagi',
    'version': (0, 2, 22),
    'blender': (5, 1, 0),
    'location': 'View3D > Add > Max Primitives / Sidebar > Smart Geometry',
    'description': 'Lazy Max-style procedural primitive implementations integrated into Smart Geometry Suite.',
    'category': 'Add Mesh',
    'support': 'COMMUNITY',
}

_REGISTERED = False


def _module(leaf: str):
    return importlib.import_module(f'{__name__}.{leaf}')


def register() -> None:
    """Compatibility no-op; Max implementation RNA is owned by Smart Geometry bridges."""
    global _REGISTERED
    _REGISTERED = True
    return None


def unregister() -> None:
    """Compatibility no-op; central exact-generation teardown owns resources."""
    global _REGISTERED
    _REGISTERED = False
    return None
