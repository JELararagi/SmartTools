# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Non-invasive Smart Paint status registry.

This module stores status text only.  It never patches Operator methods,
Property callbacks, handlers, ``bpy.app.timers``, draw-handler APIs, Panel.poll,
or any other Blender/global API.  Operator instrumentation is intentionally a
registration-time concern of each static class definition, not a runtime
monkeypatch.
"""
from __future__ import annotations

from contextlib import contextmanager
import threading
import time
from typing import Any, Iterator

_LOCK = threading.RLock()
_ENTRIES: dict[str, dict[str, Any]] = {}


def _prune(now: float | None = None) -> None:
    current = time.monotonic() if now is None else float(now)
    expired = [key for key, value in _ENTRIES.items() if value.get("expires", 0.0) and value["expires"] <= current]
    for key in expired:
        _ENTRIES.pop(key, None)


def set_transient(owner: str, text: str, *, duration: float = 1.5, **_kwargs) -> None:
    with _LOCK:
        _prune()
        _ENTRIES[str(owner)] = {
            "owner": str(owner), "text": str(text), "kind": "transient",
            "updated": time.monotonic(), "expires": time.monotonic() + max(0.0, float(duration)),
        }


def set_service(owner: str, text: str, **_kwargs) -> None:
    with _LOCK:
        _prune()
        _ENTRIES[str(owner)] = {
            "owner": str(owner), "text": str(text), "kind": "service",
            "updated": time.monotonic(), "expires": 0.0,
        }


def begin_task(owner: str, text: str, **_kwargs) -> str:
    set_service(owner, text)
    return str(owner)


def update_task(owner: str, text: str, **_kwargs) -> None:
    set_service(owner, text)


def finish_task(owner: str, text: str = "", *, duration: float = 1.5, **_kwargs) -> None:
    if text:
        set_transient(owner, text, duration=duration)
    else:
        clear(owner)


def clear(owner: str) -> None:
    with _LOCK:
        _ENTRIES.pop(str(owner), None)


def clear_prefix(prefix: str) -> None:
    value = str(prefix)
    with _LOCK:
        for key in tuple(_ENTRIES):
            if key.startswith(value):
                _ENTRIES.pop(key, None)


def clear_all() -> None:
    with _LOCK:
        _ENTRIES.clear()


def snapshot() -> dict[str, Any]:
    with _LOCK:
        _prune()
        values = sorted(_ENTRIES.values(), key=lambda value: float(value.get("updated", 0.0)), reverse=True)
        return {
            "entries": [dict(value) for value in values],
            "top": dict(values[0]) if values else None,
            "count": len(values),
        }


@contextmanager
def task_scope(owner: str, text: str, *, completed_text: str = "", failed_text: str = "", **_kwargs) -> Iterator[None]:
    begin_task(owner, text)
    try:
        yield
    except Exception:
        if failed_text:
            finish_task(owner, failed_text)
        else:
            clear(owner)
        raise
    else:
        finish_task(owner, completed_text)


__all__ = (
    "begin_task", "clear", "clear_all", "clear_prefix", "finish_task",
    "set_service", "set_transient", "snapshot", "task_scope", "update_task",
)
