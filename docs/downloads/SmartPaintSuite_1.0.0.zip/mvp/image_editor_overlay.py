# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Optional full-stack display overlay for native Image Editor painting.

The Image Editor and ``image_paint.canvas`` remain bound to the active private
PSD layer. This module draws the same current live-stack inputs over that
canvas, so native Blender brush events still write only to the active layer.
It owns no timer, modal operator, keymap, pixel readback, or background scan.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any

import bpy
import gpu as _gpu

from .. import manager_rule_api as _manager_rule_api


PROPERTY = "sps_mvp_image_editor_composite_paint"
ERROR_PROPERTY = "sps_mvp_image_editor_overlay_error"
_HANDLE = None
_DRAW_SNAPSHOT = None
_SNAPSHOT_SERIAL = 0
_EPSILON = 1.0e-8


@dataclass(frozen=True, slots=True)
class _DrawSnapshot:
    serial: int
    material_name: str
    canvas_name: str
    width: int
    height: int
    signature: str
    shader: Any
    batch: Any
    textures: tuple[Any, ...]


_MODE_IDS = {
    "MIX": 0,
    "PASS_THROUGH": 0,
    "ADD": 1,
    "LINEAR_DODGE": 1,
    "MULTIPLY": 2,
    "SCREEN": 3,
    "OVERLAY": 4,
    "SOFT_LIGHT": 5,
    "HARD_LIGHT": 6,
    "COLOR_DODGE": 7,
    "COLOR_BURN": 8,
    "LINEAR_BURN": 9,
    "VIVID_LIGHT": 10,
    "LINEAR_LIGHT": 11,
    "PIN_LIGHT": 12,
    "SUBTRACT": 13,
    "INVERSE_SUBTRACT": 14,
    "DIVIDE": 15,
    "INVERSE_DIVIDE": 16,
    "SIGNED_ADD": 17,
    "DIFFERENCE": 18,
    "EXCLUSION": 19,
    "DARKEN": 20,
    "LIGHTEN": 21,
    "TINT": 22,
    "HUE": 22,
    "SATURATION": 23,
    "COLOR": 24,
    "VALUE": 25,
    "LUMINOSITY": 25,
    "NORMAL_MAP_COMBINE": 26,
    "NORMAL_MAP_DETAIL": 26,
    "NORMAL_MAP_INVERSE_DETAIL": 27,
    "REPLACE": 28,
    "DISABLE": 29,
}

_BLEND_GLSL = r"""
const float SPS_EPS = 0.00000001;
vec3 spsSat(vec3 value) { return clamp(value, vec3(0.0), vec3(1.0)); }
vec3 spsColorDodge(vec3 dst, vec3 src) {
    vec3 raw = min(vec3(1.0), dst / max(vec3(0.000001), 1.0 - src));
    return mix(raw, vec3(1.0), step(vec3(0.999999), src));
}
vec3 spsColorBurn(vec3 dst, vec3 src) {
    vec3 raw = 1.0 - min(vec3(1.0), (1.0 - dst) / max(src, vec3(0.000001)));
    return mix(raw, vec3(0.0), 1.0 - step(vec3(0.000001), src));
}
vec3 spsSoftLight(vec3 dst, vec3 src) {
    vec3 curve = mix(
        ((16.0 * dst - 12.0) * dst + 4.0) * dst,
        sqrt(max(dst, vec3(0.0))),
        step(vec3(0.2500001), dst)
    );
    vec3 low = dst - (1.0 - 2.0 * src) * dst * (1.0 - dst);
    vec3 high = dst + (2.0 * src - 1.0) * (curve - dst);
    return mix(low, high, step(vec3(0.5000001), src));
}
vec3 spsRgbToHsv(vec3 color) {
    float maximum = max(max(color.r, color.g), color.b);
    float minimum = min(min(color.r, color.g), color.b);
    float delta = maximum - minimum;
    float hue = 0.0;
    if (delta > 0.000001) {
        if (maximum == color.r) hue = mod((color.g - color.b) / delta, 6.0);
        if (maximum == color.g) hue = ((color.b - color.r) / delta) + 2.0;
        if (maximum == color.b) hue = ((color.r - color.g) / delta) + 4.0;
        hue = mod(hue / 6.0, 1.0);
    }
    float saturation = maximum <= 0.000001 ? 0.0 : delta / maximum;
    return vec3(hue, saturation, maximum);
}
vec3 spsHsvToRgb(vec3 hsv) {
    float hue = mod(hsv.x, 1.0) * 6.0;
    float saturation = clamp(hsv.y, 0.0, 1.0);
    float value = clamp(hsv.z, 0.0, 1.0);
    int sector = int(floor(hue));
    float fraction = hue - float(sector);
    float p = value * (1.0 - saturation);
    float q = value * (1.0 - saturation * fraction);
    float t = value * (1.0 - saturation * (1.0 - fraction));
    int wrapped = sector - (sector / 6) * 6;
    if (wrapped == 0) return vec3(value, t, p);
    if (wrapped == 1) return vec3(q, value, p);
    if (wrapped == 2) return vec3(p, value, t);
    if (wrapped == 3) return vec3(p, q, value);
    if (wrapped == 4) return vec3(t, p, value);
    return vec3(value, p, q);
}
vec3 spsHsvReplace(vec3 dst, vec3 src, int hue, int saturation, int value) {
    vec3 dstHsv = spsRgbToHsv(clamp(dst, 0.0, 1.0));
    vec3 srcHsv = spsRgbToHsv(clamp(src, 0.0, 1.0));
    if (hue != 0) dstHsv.x = srcHsv.x;
    if (saturation != 0) dstHsv.y = srcHsv.y;
    if (value != 0) dstHsv.z = srcHsv.z;
    return clamp(spsHsvToRgb(dstHsv), 0.0, 1.0);
}
vec3 spsNormalWhiteout(vec3 dst, vec3 src, bool inverse) {
    vec3 dstNormal = clamp(dst * 2.0 - 1.0, -1.0, 1.0);
    vec3 srcNormal = clamp(src * 2.0 - 1.0, -1.0, 1.0);
    if (inverse) srcNormal.xy *= -1.0;
    vec3 result = vec3(
        dstNormal.x + srcNormal.x,
        dstNormal.y + srcNormal.y,
        dstNormal.z * srcNormal.z
    );
    result /= max(length(result), 0.000001);
    return clamp(result * 0.5 + 0.5, 0.0, 1.0);
}
vec3 spsPureBlend(vec3 dst, vec3 src, int mode) {
    if (mode == 1) return spsSat(dst + src);
    if (mode == 2) return dst * src;
    if (mode == 3) return 1.0 - (1.0 - dst) * (1.0 - src);
    if (mode == 4) return mix(
        2.0 * dst * src,
        1.0 - 2.0 * (1.0 - dst) * (1.0 - src),
        step(vec3(0.5000001), dst)
    );
    if (mode == 5) return spsSoftLight(dst, src);
    if (mode == 6) return mix(
        2.0 * dst * src,
        1.0 - 2.0 * (1.0 - dst) * (1.0 - src),
        step(vec3(0.5000001), src)
    );
    if (mode == 7) return spsColorDodge(dst, src);
    if (mode == 8) return spsColorBurn(dst, src);
    if (mode == 9) return spsSat(dst + src - 1.0);
    if (mode == 10) return mix(
        spsColorBurn(dst, 2.0 * src),
        spsColorDodge(dst, 2.0 * (src - 0.5)),
        step(vec3(0.5000001), src)
    );
    if (mode == 11) return spsSat(dst + 2.0 * src - 1.0);
    if (mode == 12) return mix(
        min(dst, 2.0 * src),
        max(dst, 2.0 * (src - 0.5)),
        step(vec3(0.5000001), src)
    );
    if (mode == 13) return spsSat(dst - src);
    if (mode == 14) return spsSat(src - dst);
    if (mode == 15) return spsSat(dst / max(src, vec3(0.000001)));
    if (mode == 16) return spsSat(src / max(dst, vec3(0.000001)));
    if (mode == 17) return spsSat(dst + (src - 0.5) * 2.0);
    if (mode == 18) return abs(dst - src);
    if (mode == 19) return dst + src - 2.0 * dst * src;
    if (mode == 20) return min(dst, src);
    if (mode == 21) return max(dst, src);
    if (mode == 22) return spsHsvReplace(dst, src, 1, 0, 0);
    if (mode == 23) return spsHsvReplace(dst, src, 0, 1, 0);
    if (mode == 24) return spsHsvReplace(dst, src, 1, 1, 0);
    if (mode == 25) return spsHsvReplace(dst, src, 0, 0, 1);
    if (mode == 26) return spsNormalWhiteout(dst, src, false);
    if (mode == 27) return spsNormalWhiteout(dst, src, true);
    if (mode == 29) return dst;
    return src;
}
vec4 spsBlend(vec4 dst, vec4 src, float opacity, float clipAlpha, int mode) {
    float coverage = clamp(opacity * clipAlpha, 0.0, 1.0);
    if (mode == 29) return dst;
    if (mode == 28) {
        float outAlpha = clamp(dst.a * (1.0 - coverage) + src.a * coverage, 0.0, 1.0);
        vec3 numerator = src.rgb * src.a * coverage
            + dst.rgb * dst.a * (1.0 - coverage);
        vec3 outColor = outAlpha > SPS_EPS ? numerator / outAlpha : src.rgb;
        return vec4(clamp(outColor, 0.0, 1.0), outAlpha);
    }
    float effective = clamp(src.a * coverage, 0.0, 1.0);
    float inverse = 1.0 - effective;
    float outAlpha = clamp(effective + dst.a * inverse, 0.0, 1.0);
    vec3 pure = spsPureBlend(dst.rgb, src.rgb, mode);
    vec3 numerator = dst.rgb * dst.a * inverse
        + src.rgb * effective * (1.0 - dst.a)
        + pure * effective * dst.a;
    vec3 outColor = outAlpha > SPS_EPS ? numerator / outAlpha : pure;
    return vec4(clamp(outColor, 0.0, 1.0), outAlpha);
}
vec4 spsGroupMix(vec4 before, vec4 effected, float factor) {
    factor = clamp(factor, 0.0, 1.0);
    vec3 premultiplied = before.rgb * before.a * (1.0 - factor)
        + effected.rgb * effected.a * factor;
    float alpha = clamp(before.a * (1.0 - factor) + effected.a * factor, 0.0, 1.0);
    return vec4(alpha > SPS_EPS ? premultiplied / alpha : vec3(0.0), alpha);
}
vec3 spsLinearToSrgb(vec3 value) {
    value = max(value, vec3(0.0));
    vec3 low = value * 12.92;
    vec3 high = 1.055 * pow(value, vec3(1.0 / 2.4)) - 0.055;
    return mix(high, low, step(value, vec3(0.0031308)));
}
vec3 spsSrgbToLinear(vec3 value) {
    value = clamp(value, vec3(0.0), vec3(1.0));
    vec3 low = value / 12.92;
    vec3 high = pow((value + 0.055) / 1.055, vec3(2.4));
    return mix(high, low, step(value, vec3(0.04045)));
}
"""


_ADJUSTMENT_GLSL_BASE = r"""
vec3 spsRgbToHsl(vec3 color) {
    color = clamp(color, 0.0, 1.0);
    float minimum = min(min(color.r, color.g), color.b);
    float maximum = max(max(color.r, color.g), color.b);
    float delta = maximum - minimum;
    float lightness = (maximum + minimum) * 0.5;
    float saturation = 0.0;
    float hue = 0.0;
    if (delta > 0.000000001) {
        saturation = lightness <= 0.5
            ? delta / max(maximum + minimum, 0.000000001)
            : delta / max(2.0 - maximum - minimum, 0.000000001);
        if (color.r >= maximum - 0.0000001) {
            hue = mod((color.g - color.b) / delta, 6.0);
        } else if (color.g >= maximum - 0.0000001) {
            hue = (color.b - color.r) / delta + 2.0;
        } else {
            hue = (color.r - color.g) / delta + 4.0;
        }
        hue = mod(hue / 6.0, 1.0);
    }
    return vec3(hue, clamp(saturation, 0.0, 1.0), clamp(lightness, 0.0, 1.0));
}
vec3 spsHslToRgb(vec3 hsl) {
    float hue = mod(hsl.x, 1.0) * 6.0;
    float saturation = clamp(hsl.y, 0.0, 1.0);
    float lightness = clamp(hsl.z, 0.0, 1.0);
    float chroma = (1.0 - abs(2.0 * lightness - 1.0)) * saturation;
    float secondary = chroma * (1.0 - abs(mod(hue, 2.0) - 1.0));
    int sector = int(floor(hue));
    vec3 result = vec3(0.0);
    if (sector == 0) result = vec3(chroma, secondary, 0.0);
    else if (sector == 1) result = vec3(secondary, chroma, 0.0);
    else if (sector == 2) result = vec3(0.0, chroma, secondary);
    else if (sector == 3) result = vec3(0.0, secondary, chroma);
    else if (sector == 4) result = vec3(secondary, 0.0, chroma);
    else result = vec3(chroma, 0.0, secondary);
    return clamp(result + vec3(lightness - chroma * 0.5), 0.0, 1.0);
}
"""


def _float(value: Any) -> str:
    number = float(value)
    if abs(number) < 0.00000005:
        number = 0.0
    return f"{number:.8f}"


def _resolve_material(context=None):
    ctx = context or getattr(bpy, "context", None)
    try:
        material = getattr(getattr(ctx, "object", None), "active_material", None)
        if material is not None:
            return material
    except Exception:
        pass
    try:
        active = getattr(getattr(ctx, "view_layer", None), "objects", None)
        active = getattr(active, "active", None)
        return getattr(active, "active_material", None)
    except Exception:
        return None


def enabled(material) -> bool:
    try:
        return bool(material.get(PROPERTY, False)) and str(
            material.get("sps_lightweight_display_mode", "") or ""
        ) == "LIVE_COMPOSITE"
    except Exception:
        return False


def requested(material) -> bool:
    try:
        return bool(material.get(PROPERTY, False))
    except Exception:
        return False


def _mask_expression(mask_specs, sampler_for) -> str:
    expressions = []
    channel_ids = {"R": 1, "G": 2, "B": 3, "A": 4, "ALPHA": 4}
    for mask in list(mask_specs or []):
        sampler = sampler_for(str(mask.get("image", "") or ""))
        channel = channel_ids.get(str(mask.get("channel", "LUMA") or "LUMA").upper(), 0)
        threshold = _float(mask.get("threshold", 0.5))
        strength = _float(max(0.0, min(2.0, float(mask.get("strength", 1.0) or 0.0))))
        invert = "true" if bool(mask.get("invert", False)) else "false"
        expressions.append(
            f"spsMaskFactor({sampler}, uv_interp, {channel}, {threshold}, {strength}, {invert})"
        )
    return " * ".join(expressions) if expressions else "1.0"



def _lut_adjustment_glsl(index: int, luts) -> tuple[str, str]:
    array_name = f"spsAdjustmentLut{index}"
    function_name = f"spsAdjustment{index}"
    rows = []
    for position in range(256):
        rows.append(
            "vec3("
            + ", ".join(
                _float(float(luts[channel][position])) for channel in range(3)
            )
            + ")"
        )
    declaration = (
        f"const vec3 {array_name}[256] = vec3[256](\n    "
        + ",\n    ".join(rows)
        + "\n);\n"
    )
    function = f"""
vec3 {function_name}(vec3 color) {{
    vec3 position = clamp(color, 0.0, 1.0) * 255.0;
    ivec3 lowerIndex = ivec3(floor(position));
    ivec3 upperIndex = min(lowerIndex + ivec3(1), ivec3(255));
    vec3 fraction = fract(position);
    return clamp(vec3(
        mix({array_name}[lowerIndex.r].r, {array_name}[upperIndex.r].r, fraction.r),
        mix({array_name}[lowerIndex.g].g, {array_name}[upperIndex.g].g, fraction.g),
        mix({array_name}[lowerIndex.b].b, {array_name}[upperIndex.b].b, fraction.b)
    ), 0.0, 1.0);
}}
"""
    return declaration + function, function_name


def _adjustment_glsl(index: int, adjustment_state: dict[str, Any]) -> tuple[str, str]:
    from . import adjustments

    state = dict(adjustment_state or {})
    state["_native_units"] = True
    adjustment_type = str(state.get("adjustment_type", "NONE") or "NONE").upper()
    function_name = f"spsAdjustment{index}"
    if adjustment_type == "BRIGHTNESS_CONTRAST":
        lut = adjustments._brightness_contrast_lut(
            int(state.get("adj_brightness", 0)),
            int(state.get("adj_contrast", 0)),
        )
        return _lut_adjustment_glsl(index, (lut, lut, lut))
    if adjustment_type == "LEVELS":
        lut = adjustments._levels_transfer_lut(state)
        return _lut_adjustment_glsl(index, (lut, lut, lut))
    if adjustment_type == "COLOR_BALANCE":
        return _lut_adjustment_glsl(
            index, adjustments._color_balance_transfer_luts(state)
        )
    if adjustment_type == "INVERT":
        body = "return vec3(1.0) - clamp(color, 0.0, 1.0);"
    elif adjustment_type == "POSTERIZE":
        levels = max(2, min(256, int(state.get("adj_posterize_levels", 4))))
        body = (
            "return clamp(floor((255.0 / 256.0) * clamp(color, 0.0, 1.0) * "
            f"{_float(levels)}) / {_float(levels - 1)}, 0.0, 1.0);"
        )
    elif adjustment_type == "THRESHOLD":
        threshold = float(state.get("adj_threshold", 128))
        boundary = (threshold - 1.0 / 255.0) * (255.0 / 256.0)
        body = f"""
    float luminance = round(dot(clamp(color, 0.0, 1.0), vec3(0.30, 0.59, 0.11)) * 255.0);
    float value = luminance > {_float(boundary)} ? 1.0 : 0.0;
    return vec3(value);"""
    elif adjustment_type == "HUE_SATURATION":
        hue = float(state.get("adj_hue", 0)) / 360.0
        saturation = float(state.get("adj_saturation", 0)) / 100.0
        lightness = float(state.get("adj_lightness", 0)) / 100.0
        if lightness > 0.0:
            lightness_line = (
                f"working = working * {_float(1.0 - lightness)} "
                f"+ vec3({_float(lightness)});"
            )
        elif lightness < 0.0:
            lightness_line = f"working *= {_float(1.0 + lightness)};"
        else:
            lightness_line = ""
        if saturation > 0.0:
            saturation_line = (
                "hsl.y = clamp(hsl.y / "
                f"{_float(1.0 - saturation + 0.01)}, 0.0, 1.0);"
            )
        elif saturation < 0.0:
            saturation_line = (
                f"hsl.y = clamp(hsl.y * {_float(1.0 + saturation)}, 0.0, 1.0);"
            )
        else:
            saturation_line = ""
        body = f"""
    vec3 working = clamp(color, 0.0, 1.0);
    {lightness_line}
    vec3 hsl = spsRgbToHsl(working);
    hsl.x = mod(hsl.x + {_float(hue)}, 1.0);
    {saturation_line}
    return spsHslToRgb(hsl);"""
    elif adjustment_type == "GRADIENT_MAP":
        dark = [
            float(value) / 65535.0
            for value in list(state.get("adj_gradient_dark", (0, 0, 0)))[:3]
        ]
        light = [
            float(value) / 65535.0
            for value in list(
                state.get("adj_gradient_light", (65535, 65535, 65535))
            )[:3]
        ]
        body = f"""
    float position = pow(
        clamp((color.r + color.g + color.b) / 3.0, 0.0, 1.0),
        0.625
    );
    return clamp(mix(
        vec3({', '.join(_float(value) for value in dark)}),
        vec3({', '.join(_float(value) for value in light)}),
        position
    ), 0.0, 1.0);"""
    else:
        raise ValueError(f"unsupported adjustment type: {adjustment_type}")
    return f"\nvec3 {function_name}(vec3 color) {{\n    {body}\n}}\n", function_name

def _build_shader_source(contract: dict[str, Any], *, output_mode: str = "IMAGE_EDITOR"):
    image_names: list[str] = []
    image_slots: dict[str, str] = {}

    def sampler_for(image_name: str) -> str:
        if not image_name:
            raise ValueError("overlay texture image is missing")
        sampler = image_slots.get(image_name)
        if sampler is None:
            sampler = f"image_{len(image_names)}"
            image_slots[image_name] = sampler
            image_names.append(image_name)
        return sampler

    layers = list(contract.get("layers", []) or [])
    groups = dict(contract.get("groups", {}) or {})
    adjustment_rows = dict(contract.get("adjustments", {}) or {})
    layer_by_key = {
        str(layer.get("stack_key", "") or ""): layer
        for layer in layers
    }
    layer_var: dict[str, str] = {}
    clip_var: dict[str, str] = {}
    adjustment_function: dict[str, str] = {}
    adjustment_definitions: list[str] = []
    adjustment_mask_expression: dict[str, str] = {}
    body: list[str] = []
    for index, layer in enumerate(layers):
        stack_key = str(layer.get("stack_key", "") or "")
        sampler = sampler_for(str(layer.get("image", "") or ""))
        variable = f"layer_{index}"
        if bool(layer.get("scene_linear", False)):
            body.append(f"vec4 {variable} = spsSampleActive({sampler}, uv_interp);")
        else:
            body.append(f"vec4 {variable} = spsSamplePremultiplied({sampler}, uv_interp);")
        mask_expression = _mask_expression(layer.get("masks", []), sampler_for)
        if mask_expression != "1.0":
            body.append(f"{variable}.a *= clamp({mask_expression}, 0.0, 1.0);")
        layer_var[stack_key] = variable
        opacity = float(layer.get("opacity", 1.0) or 0.0) if bool(layer.get("enabled", True)) else 0.0
        clip_name = f"clip_base_{index}"
        body.append(f"float {clip_name} = clamp({variable}.a * {_float(opacity)}, 0.0, 1.0);")
        clip_var[stack_key] = clip_name

    for index, (stack_key, adjustment) in enumerate(adjustment_rows.items()):
        definition, function_name = _adjustment_glsl(
            index,
            dict(adjustment.get("adjustment_state", {}) or {}),
        )
        adjustment_definitions.append(definition)
        adjustment_function[str(stack_key)] = function_name
        adjustment_mask_expression[str(stack_key)] = _mask_expression(
            adjustment.get("masks", []), sampler_for
        )

    counter = [0]

    def compose(nodes, destination: str, indent: str = "    "):
        statements: list[str] = []
        for node in list(nodes or []):
            kind = str(node.get("kind", "") or "")
            stack_key = str(node.get("stack_key", "") or "")
            if kind == "layer":
                layer = layer_by_key.get(stack_key)
                source = layer_var.get(stack_key)
                if layer is None or source is None:
                    raise ValueError("composition tree references a missing layer")
                opacity = float(layer.get("opacity", 1.0) or 0.0) if bool(layer.get("enabled", True)) else 0.0
                clip = "1.0"
                if bool(layer.get("clip_to_below", False)):
                    clip = clip_var.get(str(layer.get("clip_base_key", "") or ""), "")
                    if not clip:
                        raise ValueError("clipping base is missing")
                mode = _MODE_IDS.get(str(layer.get("blend_mode", "MIX") or "MIX").upper())
                if mode is None:
                    raise ValueError("unsupported layer blend mode")
                statements.append(
                    f"{indent}{destination} = spsBlend({destination}, {source}, "
                    f"{_float(opacity)}, {clip}, {mode});"
                )
                continue
            if kind == "adjustment":
                adjustment = adjustment_rows.get(stack_key)
                function_name = adjustment_function.get(stack_key, "")
                if adjustment is None or not function_name:
                    raise ValueError(
                        "composition tree references a missing adjustment"
                    )
                serial = counter[0]
                counter[0] += 1
                opacity = (
                    float(adjustment.get("opacity", 1.0) or 0.0)
                    if bool(adjustment.get("enabled", True))
                    else 0.0
                )
                mask_expression = adjustment_mask_expression.get(stack_key, "1.0")
                factor_expression = _float(opacity)
                if mask_expression != "1.0":
                    factor_expression = (
                        f"clamp({_float(opacity)} * ({mask_expression}), 0.0, 1.0)"
                    )
                if bool(adjustment.get("clip_to_below", False)):
                    clip = clip_var.get(
                        str(adjustment.get("clip_base_key", "") or ""), ""
                    )
                    if not clip:
                        raise ValueError("adjustment clipping base is missing")
                    factor_expression = (
                        f"clamp(({factor_expression}) * {clip}, 0.0, 1.0)"
                    )
                factor_name = f"adjustment_factor_{serial}"
                statements.append(
                    f"{indent}float {factor_name} = clamp({factor_expression}, 0.0, 1.0);"
                )
                statements.append(
                    f"{indent}{destination}.rgb = mix("
                    f"{destination}.rgb, {function_name}({destination}.rgb), "
                    f"{factor_name});"
                )
                if not bool(adjustment.get("clip_to_below", False)):
                    clip_name = f"clip_adjustment_{serial}"
                    statements.append(
                        f"{indent}float {clip_name} = clamp("
                        f"{destination}.a * {factor_name}, 0.0, 1.0);"
                    )
                    clip_var[stack_key] = clip_name
                continue
            group = groups.get(stack_key)
            if group is None:
                raise ValueError("composition tree references a missing group")
            serial = counter[0]
            counter[0] += 1
            group_factor = (
                float(group.get("opacity", 1.0) or 0.0)
                if bool(group.get("enabled", True))
                else 0.0
            )
            mask_expression = _mask_expression(group.get("masks", []), sampler_for)
            factor_expression = _float(group_factor)
            if mask_expression != "1.0":
                factor_expression = f"clamp({_float(group_factor)} * ({mask_expression}), 0.0, 1.0)"
            if bool(group.get("pass_through", False)):
                before = f"group_before_{serial}"
                effected = f"group_effected_{serial}"
                statements.append(f"{indent}vec4 {before} = {destination};")
                statements.append(f"{indent}vec4 {effected} = {destination};")
                statements.extend(compose(node.get("children", []), effected, indent))
                statements.append(
                    f"{indent}{destination} = spsGroupMix({before}, {effected}, {factor_expression});"
                )
                continue
            isolated = f"group_isolated_{serial}"
            statements.append(f"{indent}vec4 {isolated} = vec4(0.0);")
            statements.extend(compose(node.get("children", []), isolated, indent))
            if mask_expression != "1.0":
                statements.append(
                    f"{indent}{isolated}.a *= clamp({mask_expression}, 0.0, 1.0);"
                )
            mode = _MODE_IDS.get(str(group.get("blend_mode", "MIX") or "MIX").upper())
            if mode is None:
                raise ValueError("unsupported group blend mode")
            clip = "1.0"
            if bool(group.get("clip_to_below", False)):
                clip = clip_var.get(str(group.get("clip_base_key", "") or ""), "")
                if not clip:
                    raise ValueError("group clipping base is missing")
            statements.append(
                f"{indent}{destination} = spsBlend({destination}, {isolated}, "
                f"{_float(group_factor)}, {clip}, {mode});"
            )
        return statements

    compose_body = compose(contract.get("nodes", []), "composite")
    helper = r"""
vec4 spsSamplePremultiplied(sampler2D image, vec2 uv) {
    vec4 sampleValue = texture(image, uv);
    vec3 straight = sampleValue.a > SPS_EPS
        ? sampleValue.rgb / sampleValue.a
        : vec3(0.0);
    return vec4(clamp(straight, 0.0, 1.0), clamp(sampleValue.a, 0.0, 1.0));
}
vec4 spsSampleActive(sampler2D image, vec2 uv) {
    vec4 alphaSample = texture(image, uv);
    ivec2 sizeValue = textureSize(image, 0);
    ivec2 pixel = clamp(
        ivec2(floor(uv * vec2(sizeValue))),
        ivec2(0),
        sizeValue - ivec2(1)
    );
    vec4 colorSample = texelFetch(image, pixel, 0);
    // STRAIGHT sRGB canvases sample as straight scene-linear RGB.
    return vec4(
        clamp(spsLinearToSrgb(colorSample.rgb), 0.0, 1.0),
        clamp(alphaSample.a, 0.0, 1.0)
    );
}
float spsMaskFactor(
    sampler2D image,
    vec2 uv,
    int channel,
    float threshold,
    float strength,
    bool invertValue
) {
    vec4 sampleValue = texture(image, uv);
    float factor = dot(sampleValue.rgb, vec3(0.2126, 0.7152, 0.0722));
    if (channel == 1) factor = sampleValue.r;
    if (channel == 2) factor = sampleValue.g;
    if (channel == 3) factor = sampleValue.b;
    if (channel == 4) factor = sampleValue.a;
    factor = clamp(factor + (0.5 - threshold) * 2.0, 0.0, 1.0);
    factor = clamp(factor * strength, 0.0, 1.0);
    if (invertValue) factor = 1.0 - factor;
    return factor;
}
"""
    if output_mode == "IMAGE_EDITOR":
        final_output = r"""
    float checkerIndex = mod(
        floor(gl_FragCoord.x / 12.0) + floor(gl_FragCoord.y / 12.0),
        2.0
    );
    vec3 checkerSrgb = mix(vec3(0.36), vec3(0.50), checkerIndex);
    vec3 compositeLinear = spsSrgbToLinear(composite.rgb);
    vec3 checkerLinear = spsSrgbToLinear(checkerSrgb);
    vec3 displayColor = compositeLinear * composite.a
        + checkerLinear * (1.0 - composite.a);
    frag_color = vec4(clamp(displayColor, 0.0, 1.0), 1.0);
}
"""
    elif output_mode == "VIEW_3D":
        final_output = r"""
    float displayAlpha = clamp(composite.a, 0.0, 1.0);
    vec3 compositeLinear = clamp(spsSrgbToLinear(composite.rgb), 0.0, 1.0);
    vec3 displayColor = compositeLinear * displayAlpha
        + clamp(solid_backing_color.rgb, 0.0, 1.0) * (1.0 - displayAlpha);
    frag_color = vec4(clamp(displayColor, 0.0, 1.0), 1.0);
}
"""
    else:
        raise ValueError(f"unsupported overlay output mode: {output_mode}")
    fragment = (
        _BLEND_GLSL
        + _ADJUSTMENT_GLSL_BASE
        + "\n".join(adjustment_definitions)
        + helper
        + "\nvoid main() {\n"
        + "\n".join(f"    {line}" for line in body)
        + "\n    vec4 composite = vec4(0.0);\n"
        + "\n".join(compose_body)
        + final_output
    )
    return fragment, image_names


def _shader_for_contract(contract: dict[str, Any], *, output_mode: str = "IMAGE_EDITOR"):
    """Compile one operation-owned shader and immutable unit-quad batch.

    There is intentionally no GPU-object cache: the enabled overlay owns one
    completed snapshot and releases it at disable/load/unregister boundaries.
    """
    from gpu_extras.batch import batch_for_shader

    gpu = _gpu
    fragment, image_names = _build_shader_source(contract, output_mode=output_mode)
    payload = {
        "contract": str(contract.get("signature", "") or ""),
        "output_mode": output_mode,
        "images": image_names,
        "fragment": fragment,
    }
    signature = hashlib.sha1(
        json.dumps(payload, sort_keys=True, ensure_ascii=True).encode("utf-8")
    ).hexdigest()
    interface = gpu.types.GPUStageInterfaceInfo(f"sps_ie_overlay_{signature[:10]}")
    interface.smooth("VEC2", "uv_interp")
    info = gpu.types.GPUShaderCreateInfo()
    info.vertex_in(0, "VEC2", "pos")
    info.vertex_in(1, "VEC2", "uv")
    info.vertex_out(interface)
    # POST_VIEW provides the Image Editor view transform through gpu.matrix.
    # The draw callback therefore needs no Area/Space/Region/Image RNA reads.
    info.push_constant("MAT4", "view_projection")
    for slot, _image_name in enumerate(image_names):
        info.sampler(slot, "FLOAT_2D", f"image_{slot}")
    info.fragment_out(0, "VEC4", "frag_color")
    info.vertex_source(
        "void main() {\n"
        "  uv_interp = uv;\n"
        "  gl_Position = view_projection * vec4(pos, 0.0, 1.0);\n"
        "}\n"
    )
    info.fragment_source(fragment)
    shader = gpu.shader.create_from_info(info)
    batch = batch_for_shader(
        shader,
        "TRI_FAN",
        {
            "pos": ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),
            "uv": ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),
        },
    )
    return {
        "signature": signature,
        "shader": shader,
        "batch": batch,
        "image_names": tuple(image_names),
    }


def _contract(material):
    try:
        from . import live_composite
        contract = live_composite.image_editor_overlay_contract(material)
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        contract = None
    if not isinstance(contract, dict):
        return None, "live_overlay_contract_missing"
    if not bool(contract.get("direct_display_stack", False)):
        return None, "saved_composite_peel_overlay_unsupported"
    if not list(contract.get("layers", []) or []):
        return None, "live_overlay_layers_missing"
    return contract, ""


def _clear_snapshot() -> None:
    global _DRAW_SNAPSHOT
    _DRAW_SNAPSHOT = None


def prepare(material) -> dict[str, Any]:
    """Build and atomically publish the complete immutable draw snapshot."""
    global _DRAW_SNAPSHOT, _SNAPSHOT_SERIAL
    if material is None:
        return {"ok": False, "reason": "material_missing"}
    contract, reason = _contract(material)
    if contract is None:
        return {"ok": False, "reason": reason}
    try:
        gpu = _gpu
        from . import live_composite

        runtime = _shader_for_contract(contract)
        textures = []
        missing = []
        for image_name in runtime["image_names"]:
            image = live_composite.resolve_display_image(material, str(image_name or ""))
            if image is None:
                missing.append(str(image_name or ""))
                continue
            textures.append(gpu.texture.from_image(image))
        if missing:
            return {
                "ok": False,
                "reason": "overlay_texture_missing",
                "missing": missing[:8],
            }
        width = int(contract.get("width", 0) or 0)
        height = int(contract.get("height", 0) or 0)
        canvas_name = str(contract.get("active_canvas", "") or "")
        if width <= 0 or height <= 0 or not canvas_name:
            return {"ok": False, "reason": "overlay_canvas_contract_invalid"}
        candidate = _DrawSnapshot(
            serial=_SNAPSHOT_SERIAL + 1,
            material_name=str(getattr(material, "name", "") or ""),
            canvas_name=canvas_name,
            width=width,
            height=height,
            signature=str(runtime["signature"]),
            shader=runtime["shader"],
            batch=runtime["batch"],
            textures=tuple(textures),
        )
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
        return {
            "ok": False,
            "reason": "overlay_snapshot_build_failed",
            "error": f"{type(exc).__name__}:{exc}"[:512],
        }
    _SNAPSHOT_SERIAL = candidate.serial
    _DRAW_SNAPSHOT = candidate
    return {
        "ok": True,
        "reason": "image_editor_live_overlay_ready",
        "signature": candidate.signature,
        "texture_count": len(candidate.textures),
        "layer_count": len(list(contract.get("layers", []) or [])),
        "snapshot_serial": candidate.serial,
    }


def _image_bounds(context, width: int, height: int):
    """Read only the current region transform; no datablock scan/build occurs."""
    region = getattr(context, "region", None)
    if region is None or str(getattr(region, "type", "") or "") != "WINDOW":
        return None
    view2d = getattr(region, "view2d", None)
    if view2d is None:
        return None
    mode = "NORMALIZED"
    try:
        # Blender 5.1 exposes the View2D transform through conversion methods,
        # not a public ``cur`` rectangle.  Sampling the region corners yields
        # the same visible-view span without relying on an unavailable RNA
        # member, preserving both normalized and pixel-space image contracts.
        view_min = view2d.region_to_view(0.0, 0.0)
        view_max = view2d.region_to_view(float(region.width), float(region.height))
        span_x = abs(float(view_max[0]) - float(view_min[0]))
        span_y = abs(float(view_max[1]) - float(view_min[1]))
        if span_x > max(512.0, float(width) * 0.75) or span_y > max(512.0, float(height) * 0.75):
            mode = "PIXEL"
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return None
    x1 = float(width) if mode == "PIXEL" else 1.0
    y1 = float(height) if mode == "PIXEL" else 1.0
    try:
        lower = view2d.view_to_region(0.0, 0.0, clip=False)
        upper = view2d.view_to_region(x1, y1, clip=False)
        return ((float(lower[0]), float(lower[1])), (float(upper[0]), float(upper[1])))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _capture_gpu_state(gpu_module) -> tuple[tuple[str, Any], ...]:
    state = gpu_module.state
    captured = []
    for name in (
        "blend", "depth_test", "depth_mask", "face_culling", "line_width",
        "point_size", "scissor_test", "scissor", "viewport", "color_mask",
    ):
        getter = getattr(state, f"{name}_get", None)
        if not callable(getter):
            continue
        try:
            captured.append((name, getter()))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            continue
    return tuple(captured)


def _restore_gpu_state(gpu_module, captured: tuple[tuple[str, Any], ...]) -> None:
    state = gpu_module.state
    for name, value in reversed(captured):
        setter = getattr(state, f"{name}_set", None)
        if not callable(setter):
            continue
        try:
            if name in {"scissor", "viewport", "color_mask"} and isinstance(value, (tuple, list)):
                setter(*value)
            else:
                setter(value)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            continue


def _draw_overlay():
    """Replay one completed GPU snapshot in an allowed target workspace.

    The handler is installed as ``POST_VIEW``.  Image Editor pan/zoom is already
    represented by ``gpu.matrix``; only GPU state and immutable snapshot objects
    are touched after one memory-only target-context Manager query. Shader,
    batch, texture, image lookup, material state and error/property writes are
    all completed outside draw; no window scan occurs here.
    """
    if not _manager_rule_api.workspace_runtime_allowed(getattr(bpy, "context", None)):
        return
    snapshot = _DRAW_SNAPSHOT
    if snapshot is None:
        return
    gpu = _gpu
    captured = _capture_gpu_state(gpu)
    try:
        projection = gpu.matrix.get_projection_matrix()
        model_view = gpu.matrix.get_model_view_matrix()
        shader = snapshot.shader
        shader.bind()
        shader.uniform_float("view_projection", projection @ model_view)
        for slot, texture in enumerate(snapshot.textures):
            shader.uniform_sampler(f"image_{slot}", texture)
        gpu.state.blend_set("NONE")
        snapshot.batch.draw(shader)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        # Explicit prepare/toggle operators publish one structured error; draw
        # never mutates state or emits a repeating console traceback.
        return
    finally:
        _restore_gpu_state(gpu, captured)

def _tag_image_editors() -> None:
    try:
        windows = tuple(getattr(getattr(bpy.context, "window_manager", None), "windows", ()) or ())
    except (AttributeError, ReferenceError, TypeError):
        windows = ()
    for window in windows:
        if not _manager_rule_api.workspace_runtime_allowed(
            getattr(bpy, "context", None),
            workspace=getattr(window, "workspace", None),
        ):
            continue
        try:
            areas = tuple(getattr(getattr(window, "screen", None), "areas", ()) or ())
        except (AttributeError, ReferenceError, TypeError):
            continue
        for area in areas:
            try:
                if str(getattr(area, "type", "") or "") == "IMAGE_EDITOR":
                    area.tag_redraw()
            except (AttributeError, ReferenceError, RuntimeError):
                continue


def _should_register() -> bool:
    return _DRAW_SNAPSHOT is not None


def _ensure_handler() -> None:
    global _HANDLE
    if _HANDLE is not None:
        return
    from .. import runtime_registry

    handle = bpy.types.SpaceImageEditor.draw_handler_add(
        _draw_overlay, (), "WINDOW", "POST_VIEW"
    )
    try:
        runtime_registry.track_draw_handler(
            bpy.types.SpaceImageEditor.draw_handler_remove,
            handle,
            "WINDOW",
            label="image_editor_overlay",
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        bpy.types.SpaceImageEditor.draw_handler_remove(handle, "WINDOW")
        raise
    _HANDLE = handle


def _remove_handler() -> None:
    global _HANDLE
    handle = _HANDLE
    _HANDLE = None
    if handle is None:
        return
    from .. import runtime_registry
    runtime_registry.untrack_draw_handler(handle, remove=True)


def sync_handler_state(context=None) -> None:
    """Restore only the active requested overlay at explicit lifecycle boundaries."""
    if _DRAW_SNAPSHOT is None:
        material = _resolve_material(context)
        if material is not None and requested(material):
            result = prepare(material)
            if not bool(result.get("ok", False)):
                try:
                    material[ERROR_PROPERTY] = str(result.get("reason", "") or "")[:512]
                except (AttributeError, ReferenceError, RuntimeError, TypeError):
                    pass
    if _should_register():
        from .. import runtime_registry
        if not runtime_registry.ensure_runtime_ready():
            # Legitimately dormant registry (mid-teardown / failed enable):
            # skip quietly instead of raising RegistrationError into the
            # lifecycle callbacks and save/restore paths that call this.
            _tag_image_editors()
            return
        _ensure_handler()
    else:
        _remove_handler()
    _tag_image_editors()


def set_enabled(material, value: bool) -> dict[str, Any]:
    if material is None:
        return {"ok": False, "reason": "material_missing"}
    if value:
        result = prepare(material)
        if not bool(result.get("ok", False)):
            _clear_snapshot()
            material[PROPERTY] = False
            material[ERROR_PROPERTY] = str(result.get("reason", "") or "")[:512]
            _remove_handler()
            _tag_image_editors()
            return result
        from .. import runtime_registry
        if not runtime_registry.ensure_runtime_ready():
            # USER-WORK-FIRST: an overlay is decoration.  When the registry
            # owns no READY generation the toggle reports a structured,
            # actionable failure; it never raises RegistrationError into the
            # PSD save / preview operators that drive it.
            _clear_snapshot()
            material[PROPERTY] = False
            material[ERROR_PROPERTY] = "smart_paint_runtime_not_ready"
            _remove_handler()
            _tag_image_editors()
            return {"ok": False, "reason": "smart_paint_runtime_not_ready"}
        material[PROPERTY] = True
        material[ERROR_PROPERTY] = ""
        _ensure_handler()
        _tag_image_editors()
        return result
    material[PROPERTY] = False
    material[ERROR_PROPERTY] = ""
    _clear_snapshot()
    _remove_handler()
    _tag_image_editors()
    return {"ok": True, "reason": "image_editor_live_overlay_disabled"}


def register_runtime(transaction) -> None:
    # Dormant registration owns no draw callback. Explicit enable/load restore
    # acquires an exact journal row after the root transaction reaches READY.
    transaction.add_cleanup(unregister_runtime, label="image_editor_overlay.reset")


def unregister_runtime() -> None:
    _remove_handler()
    _clear_snapshot()
    _tag_image_editors()
