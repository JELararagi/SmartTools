# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Native Photoshop/CSP adjustment-layer data shared by the MVP runtime.

The functions in this module are deliberately independent from Blender so the
PSD payload contract and color math can be tested without starting Blender.
Only adjustment formats authored by both Photoshop and Clip Studio Paint are
generated. Unknown formats remain preserve-only in the PSD reader/writer.
"""

from __future__ import annotations

import json
import math
import struct
from typing import Any, Iterable

from . import adjustment_calibration


ADJUSTMENT_MATH_VERSION = (
    f"p2_native_adjustment_math_v2_{adjustment_calibration.CALIBRATION_VERSION}"
)
SUPPORTED_TYPES = (
    "BRIGHTNESS_CONTRAST",
    "LEVELS",
    "HUE_SATURATION",
    "COLOR_BALANCE",
    "INVERT",
    "POSTERIZE",
    "THRESHOLD",
    "GRADIENT_MAP",
)

TYPE_TAGS = {
    "BRIGHTNESS_CONTRAST": ("brit", "CgEd"),
    "LEVELS": ("levl",),
    "HUE_SATURATION": ("hue2",),
    "COLOR_BALANCE": ("blnc",),
    "INVERT": ("nvrt",),
    "POSTERIZE": ("post",),
    "THRESHOLD": ("thrs",),
    "GRADIENT_MAP": ("grdm",),
}

SEMANTIC_TAGS = frozenset(
    tag for tags in TYPE_TAGS.values() for tag in tags
)

TYPE_LABELS_JA = {
    "BRIGHTNESS_CONTRAST": "明るさ・コントラスト",
    "LEVELS": "レベル補正",
    "HUE_SATURATION": "色相・彩度",
    "COLOR_BALANCE": "カラーバランス",
    "INVERT": "階調の反転",
    "POSTERIZE": "ポスタリゼーション",
    "THRESHOLD": "2階調化",
    "GRADIENT_MAP": "グラデーションマップ",
}

_NEUTRAL_LEVEL = (0, 255, 0, 255, 100)
_HUE_RANGES = (
    ((315, 345, 15, 45), (0, 0, 0)),
    ((15, 45, 75, 105), (0, 0, 0)),
    ((75, 105, 135, 165), (0, 0, 0)),
    ((135, 165, 195, 225), (0, 0, 0)),
    ((195, 225, 255, 285), (0, 0, 0)),
    ((255, 285, 315, 345), (0, 0, 0)),
)

_STATE_FIELDS = (
    "adjustment_type",
    "adj_brightness",
    "adj_contrast",
    "adj_hue",
    "adj_saturation",
    "adj_lightness",
    "adj_posterize_levels",
    "adj_threshold",
    "adj_levels_input_black",
    "adj_levels_input_white",
    "adj_levels_gamma",
    "adj_levels_output_black",
    "adj_levels_output_white",
    "adj_color_balance_shadows",
    "adj_color_balance_midtones",
    "adj_color_balance_highlights",
    "adj_preserve_luminosity",
    "adj_gradient_dark",
    "adj_gradient_light",
)


def _clamp(value: Any, low: float, high: float, default: float) -> float:
    try:
        number = float(value)
    except Exception:
        number = float(default)
    if not math.isfinite(number):
        number = float(default)
    return max(float(low), min(float(high), number))


def _int(value: Any, low: int, high: int, default: int) -> int:
    return int(round(_clamp(value, low, high, default)))


def _vector(value: Any, size: int, default: Iterable[float]) -> tuple[float, ...]:
    try:
        values = tuple(value)
    except Exception:
        values = tuple(default)
    fallback = tuple(default)
    return tuple(
        _clamp(
            values[index] if index < len(values) else fallback[index],
            -1.0 if index < 3 else 0.0,
            1.0,
            fallback[index],
        )
        for index in range(size)
    )


def layer_state(layer: Any) -> dict[str, Any]:
    """Return a stable, quantized adjustment state for save/change detection."""
    typ = str(getattr(layer, "adjustment_type", "NONE") or "NONE").upper()
    state: dict[str, Any] = {
        "adjustment_type": typ,
        "_native_units": True,
    }
    if typ == "BRIGHTNESS_CONTRAST":
        state.update(
            adj_brightness=_int(
                _clamp(getattr(layer, "adj_brightness", 0.0), -1.0, 1.0, 0.0)
                * 100.0,
                -100,
                100,
                0,
            ),
            adj_contrast=_int(
                _clamp(getattr(layer, "adj_contrast", 0.0), -1.0, 1.0, 0.0)
                * 100.0,
                -100,
                100,
                0,
            ),
        )
    elif typ == "LEVELS":
        black = _int(
            _clamp(getattr(layer, "adj_levels_input_black", 0.0), 0.0, 1.0, 0.0)
            * 255.0,
            0,
            253,
            0,
        )
        white = _int(
            _clamp(getattr(layer, "adj_levels_input_white", 1.0), 0.0, 1.0, 1.0)
            * 255.0,
            black + 2,
            255,
            255,
        )
        state.update(
            adj_levels_input_black=black,
            adj_levels_input_white=white,
            adj_levels_gamma=_int(
                _clamp(getattr(layer, "adj_levels_gamma", 1.0), 0.1, 9.99, 1.0)
                * 100.0,
                10,
                999,
                100,
            ),
            adj_levels_output_black=_int(
                _clamp(getattr(layer, "adj_levels_output_black", 0.0), 0.0, 1.0, 0.0)
                * 255.0,
                0,
                255,
                0,
            ),
            adj_levels_output_white=_int(
                _clamp(getattr(layer, "adj_levels_output_white", 1.0), 0.0, 1.0, 1.0)
                * 255.0,
                0,
                255,
                255,
            ),
        )
    elif typ == "HUE_SATURATION":
        state.update(
            adj_hue=_int(
                _clamp(getattr(layer, "adj_hue", 0.0), -1.0, 1.0, 0.0) * 180.0,
                -180,
                180,
                0,
            ),
            adj_saturation=_int(
                _clamp(getattr(layer, "adj_saturation", 0.0), -1.0, 1.0, 0.0)
                * 100.0,
                -100,
                100,
                0,
            ),
            adj_lightness=_int(
                _clamp(getattr(layer, "adj_lightness", 0.0), -1.0, 1.0, 0.0)
                * 100.0,
                -100,
                100,
                0,
            ),
        )
    elif typ == "COLOR_BALANCE":
        for key in (
            "adj_color_balance_shadows",
            "adj_color_balance_midtones",
            "adj_color_balance_highlights",
        ):
            state[key] = [
                _int(component * 100.0, -100, 100, 0)
                for component in _vector(getattr(layer, key, (0.0, 0.0, 0.0)), 3, (0.0, 0.0, 0.0))
            ]
        state["adj_preserve_luminosity"] = bool(
            getattr(layer, "adj_preserve_luminosity", True)
        )
    elif typ == "POSTERIZE":
        state["adj_posterize_levels"] = _int(
            getattr(layer, "adj_posterize_levels", 4), 2, 256, 4
        )
    elif typ == "THRESHOLD":
        state["adj_threshold"] = _int(
            _clamp(getattr(layer, "adj_threshold", 0.5), 0.0, 1.0, 0.5)
            * 255.0,
            0,
            255,
            128,
        )
    elif typ == "GRADIENT_MAP":
        state["adj_gradient_dark"] = [
            _int(component * 65535.0, 0, 65535, 0)
            for component in _vector(
                getattr(layer, "adj_gradient_dark", (0.0, 0.0, 0.0, 1.0)),
                4,
                (0.0, 0.0, 0.0, 1.0),
            )[:3]
        ]
        state["adj_gradient_light"] = [
            _int(component * 65535.0, 0, 65535, 65535)
            for component in _vector(
                getattr(layer, "adj_gradient_light", (1.0, 1.0, 1.0, 1.0)),
                4,
                (1.0, 1.0, 1.0, 1.0),
            )[:3]
        ]
    return state


def _unicode_string(value: str) -> bytes:
    text = str(value or "")
    return struct.pack(">I", len(text)) + text.encode("utf-16-be", "replace")


def _descriptor_id(value: bytes) -> bytes:
    raw = bytes(value or b"null")
    if len(raw) == 4:
        return struct.pack(">I", 0) + raw
    return struct.pack(">I", len(raw)) + raw


def _descriptor_key(value: bytes) -> bytes:
    return _descriptor_id(value)


def _brightness_descriptor(brightness: int, contrast: int) -> bytes:
    entries = (
        (b"Vrsn", b"long", struct.pack(">i", 1)),
        (b"Brgh", b"long", struct.pack(">i", int(brightness))),
        (b"Cntr", b"long", struct.pack(">i", int(contrast))),
        (b"means", b"long", struct.pack(">i", 127)),
        (b"Lab ", b"bool", b"\x00"),
        (b"useLegacy", b"bool", b"\x00"),
        (b"Auto", b"bool", b"\x00"),
    )
    payload = bytearray()
    payload += struct.pack(">I", 16)
    payload += _unicode_string("\x00")
    payload += _descriptor_id(b"null")
    payload += struct.pack(">I", len(entries))
    for key, value_type, value in entries:
        payload += _descriptor_key(key)
        payload += value_type
        payload += value
    while len(payload) % 4:
        payload += b"\x00"
    return bytes(payload)


def _levels_payload(state: dict[str, Any]) -> bytes:
    first = (
        int(state["adj_levels_input_black"]),
        int(state["adj_levels_input_white"]),
        int(state["adj_levels_output_black"]),
        int(state["adj_levels_output_white"]),
        int(state["adj_levels_gamma"]),
    )
    records = [first] + [_NEUTRAL_LEVEL] * 61
    payload = bytearray(struct.pack(">H", 2))
    for record in records[:29]:
        payload += struct.pack(">5H", *record)
    payload += b"Lvls" + struct.pack(">HH", 3, len(records))
    for record in records[29:]:
        payload += struct.pack(">5H", *record)
    while len(payload) % 4:
        payload += b"\x00"
    return bytes(payload)


def _hue_payload(state: dict[str, Any]) -> bytes:
    payload = bytearray(struct.pack(">HBx", 2, 0))
    payload += struct.pack(">3h", -60, 25, 0)
    payload += struct.pack(
        ">3h",
        int(state["adj_hue"]),
        int(state["adj_saturation"]),
        int(state["adj_lightness"]),
    )
    for range_values, settings_values in _HUE_RANGES:
        payload += struct.pack(">4h", *range_values)
        payload += struct.pack(">3h", *settings_values)
    return bytes(payload)


def _gradient_payload(state: dict[str, Any]) -> bytes:
    # Photoshop's native two-stop RGB gradient map. The fourth color value is
    # the PSD color-space padding component, not alpha.
    dark = tuple(int(value) for value in state["adj_gradient_dark"]) + (0,)
    light = tuple(int(value) for value in state["adj_gradient_light"]) + (0,)
    payload = bytearray(struct.pack(">HBB4s", 3, 0, 0, b"Smoo"))
    payload += _unicode_string("\u63cf\u753b\u8272\u304b\u3089\u80cc\u666f\u8272\u3078\x00")
    payload += struct.pack(">H", 2)
    payload += struct.pack(">IIH4H2x", 0, 50, 0, *dark)
    payload += struct.pack(">IIH4H2x", 4096, 50, 0, *light)
    payload += struct.pack(">H", 2)
    payload += struct.pack(">IIH", 0, 50, 255)
    payload += struct.pack(">IIH", 4096, 50, 255)
    payload += struct.pack(
        ">4HI2HIH",
        2,
        4096,
        32,
        0,
        0,
        0,
        1,
        2048,
        3,
    )
    payload += struct.pack(">4H", 0, 0, 0, 0)
    payload += struct.pack(">4H", 32768, 32768, 32768, 32768)
    payload += b"\x00\x00"
    while len(payload) % 4:
        payload += b"\x00"
    return bytes(payload)


def native_tag_payloads(layer: Any) -> list[tuple[bytes, bytes]]:
    """Encode Photoshop/CSP-native adjustment tagged-layer payloads."""
    state = layer_state(layer)
    typ = str(state.get("adjustment_type", "NONE") or "NONE")
    if typ == "BRIGHTNESS_CONTRAST":
        return [
            (b"brit", b"\x00" * 8),
            (
                b"CgEd",
                _brightness_descriptor(
                    int(state["adj_brightness"]),
                    int(state["adj_contrast"]),
                ),
            ),
        ]
    if typ == "LEVELS":
        return [(b"levl", _levels_payload(state))]
    if typ == "HUE_SATURATION":
        return [(b"hue2", _hue_payload(state))]
    if typ == "COLOR_BALANCE":
        values: list[int] = []
        for key in (
            "adj_color_balance_shadows",
            "adj_color_balance_midtones",
            "adj_color_balance_highlights",
        ):
            values.extend(int(value) for value in state[key])
        payload = struct.pack(
            ">9hB",
            *values[:9],
            1 if bool(state["adj_preserve_luminosity"]) else 0,
        )
        return [(b"blnc", payload + b"\x00")]
    if typ == "INVERT":
        return [(b"nvrt", b"")]
    if typ == "POSTERIZE":
        return [(b"post", struct.pack(">H2x", int(state["adj_posterize_levels"])))]
    if typ == "THRESHOLD":
        return [(b"thrs", struct.pack(">H2x", int(state["adj_threshold"])))]
    if typ == "GRADIENT_MAP":
        return [(b"grdm", _gradient_payload(state))]
    return []


def _read_descriptor_id(payload: bytes, offset: int) -> tuple[bytes, int]:
    if offset + 4 > len(payload):
        raise ValueError("descriptor id is truncated")
    length = struct.unpack_from(">I", payload, offset)[0]
    offset += 4
    size = int(length) if int(length) > 0 else 4
    if offset + size > len(payload):
        raise ValueError("descriptor id payload is truncated")
    return bytes(payload[offset : offset + size]), offset + size


def _descriptor_values(payload: bytes) -> dict[str, Any]:
    values: dict[str, Any] = {}
    try:
        offset = 0
        if len(payload) < 8:
            return values
        _version = struct.unpack_from(">I", payload, offset)[0]
        offset += 4
        count = struct.unpack_from(">I", payload, offset)[0]
        offset += 4 + int(count) * 2
        _class_id, offset = _read_descriptor_id(payload, offset)
        item_count = struct.unpack_from(">I", payload, offset)[0]
        offset += 4
        for _ in range(int(item_count)):
            key, offset = _read_descriptor_id(payload, offset)
            if offset + 4 > len(payload):
                break
            value_type = bytes(payload[offset : offset + 4])
            offset += 4
            if value_type == b"long":
                value = struct.unpack_from(">i", payload, offset)[0]
                offset += 4
            elif value_type == b"bool":
                value = bool(payload[offset])
                offset += 1
            else:
                break
            values[key.decode("latin1", "replace")] = value
    except Exception:
        return {}
    return values


def decode_tag_payload(key: bytes | str, payload: bytes) -> dict[str, Any]:
    """Decode one native adjustment block into normalized Blender properties."""
    key_bytes = key.encode("latin1", "replace") if isinstance(key, str) else bytes(key)
    block = bytes(payload or b"")
    try:
        if key_bytes == b"CgEd":
            values = _descriptor_values(block)
            if "Brgh" in values or "Cntr" in values:
                return {
                    "adjustment_type": "BRIGHTNESS_CONTRAST",
                    "adj_brightness": _clamp(values.get("Brgh", 0), -100, 100, 0) / 100.0,
                    "adj_contrast": _clamp(values.get("Cntr", 0), -100, 100, 0) / 100.0,
                }
        if key_bytes == b"brit" and len(block) >= 6:
            brightness, contrast = struct.unpack_from(">hh", block, 0)
            return {
                "adjustment_type": "BRIGHTNESS_CONTRAST",
                "adj_brightness": _clamp(brightness, -100, 100, 0) / 100.0,
                "adj_contrast": _clamp(contrast, -100, 100, 0) / 100.0,
            }
        if key_bytes == b"levl" and len(block) >= 12:
            version = struct.unpack_from(">H", block, 0)[0]
            offset = 2 if version == 2 else 0
            black, white, out_black, out_white, gamma = struct.unpack_from(
                ">5H", block, offset
            )
            return {
                "adjustment_type": "LEVELS",
                "adj_levels_input_black": _clamp(black, 0, 255, 0) / 255.0,
                "adj_levels_input_white": _clamp(white, 0, 255, 255) / 255.0,
                "adj_levels_gamma": _clamp(gamma, 10, 999, 100) / 100.0,
                "adj_levels_output_black": _clamp(out_black, 0, 255, 0) / 255.0,
                "adj_levels_output_white": _clamp(out_white, 0, 255, 255) / 255.0,
            }
        if key_bytes in {b"hue2", b"hue "} and len(block) >= 16:
            hue, saturation, lightness = struct.unpack_from(">3h", block, 10)
            return {
                "adjustment_type": "HUE_SATURATION",
                "adj_hue": _clamp(hue, -180, 180, 0) / 180.0,
                "adj_saturation": _clamp(saturation, -100, 100, 0) / 100.0,
                "adj_lightness": _clamp(lightness, -100, 100, 0) / 100.0,
            }
        if key_bytes == b"blnc" and len(block) >= 19:
            values = struct.unpack_from(">9h", block, 0)
            return {
                "adjustment_type": "COLOR_BALANCE",
                "adj_color_balance_shadows": [
                    _clamp(value, -100, 100, 0) / 100.0 for value in values[0:3]
                ],
                "adj_color_balance_midtones": [
                    _clamp(value, -100, 100, 0) / 100.0 for value in values[3:6]
                ],
                "adj_color_balance_highlights": [
                    _clamp(value, -100, 100, 0) / 100.0 for value in values[6:9]
                ],
                "adj_preserve_luminosity": bool(block[18]),
            }
        if key_bytes == b"nvrt":
            return {"adjustment_type": "INVERT"}
        if key_bytes == b"post" and len(block) >= 2:
            return {
                "adjustment_type": "POSTERIZE",
                "adj_posterize_levels": _int(
                    struct.unpack_from(">H", block, 0)[0], 2, 256, 4
                ),
            }
        if key_bytes == b"thrs" and len(block) >= 2:
            return {
                "adjustment_type": "THRESHOLD",
                "adj_threshold": _clamp(
                    struct.unpack_from(">H", block, 0)[0], 0, 255, 128
                )
                / 255.0,
            }
        if key_bytes == b"grdm" and len(block) >= 24:
            offset = 0
            version, _reversed, _dithered = struct.unpack_from(">HBB", block, offset)
            offset += 4
            if version == 3:
                offset += 4
            name_count = struct.unpack_from(">I", block, offset)[0]
            offset += 4 + int(name_count) * 2
            stop_count = struct.unpack_from(">H", block, offset)[0]
            offset += 2
            colors = []
            for _ in range(int(stop_count)):
                _location, _midpoint, _mode, c0, c1, c2, _pad = struct.unpack_from(
                    ">IIH4H", block, offset
                )
                offset += 20
                colors.append((c0, c1, c2))
            if len(colors) >= 2:
                return {
                    "adjustment_type": "GRADIENT_MAP",
                    "adj_gradient_dark": [
                        colors[0][0] / 65535.0,
                        colors[0][1] / 65535.0,
                        colors[0][2] / 65535.0,
                        1.0,
                    ],
                    "adj_gradient_light": [
                        colors[-1][0] / 65535.0,
                        colors[-1][1] / 65535.0,
                        colors[-1][2] / 65535.0,
                        1.0,
                    ],
                }
    except Exception:
        return {}
    return {}


def decode_tag_mapping(mapping: dict[str, Any]) -> dict[str, Any]:
    """Decode raw tag hex/bytes, honoring companion descriptors by order."""
    result: dict[str, Any] = {}
    for key, value in dict(mapping or {}).items():
        if str(key) not in SEMANTIC_TAGS:
            continue
        try:
            payload = bytes.fromhex(str(value or "")) if isinstance(value, str) else bytes(value)
        except Exception:
            continue
        decoded = decode_tag_payload(str(key), payload)
        if decoded:
            result.update(decoded)
    return result


def raw_tag_mapping(layer: Any) -> dict[str, bytes]:
    """Merge imported raw layer/adjustment JSON while preserving PSD tag order."""
    result: dict[str, bytes] = {}
    for attribute in ("psd_raw_layer_tags", "psd_raw_adjustment_tags"):
        try:
            value = getattr(layer, attribute, "") or ""
            mapping = json.loads(value) if isinstance(value, str) and value else value
        except Exception:
            mapping = {}
        if not isinstance(mapping, dict):
            continue
        for key, payload in mapping.items():
            if str(key) not in SEMANTIC_TAGS or str(key) in result:
                continue
            try:
                result[str(key)] = (
                    bytes.fromhex(str(payload or ""))
                    if isinstance(payload, str)
                    else bytes(payload)
                )
            except Exception:
                continue
    return result


def raw_tags_match_layer(layer: Any) -> bool:
    raw = raw_tag_mapping(layer)
    if not raw:
        return False
    decoded = decode_tag_mapping(raw)
    if not decoded:
        return False
    current = layer_state(layer)
    proxy = type("_AdjustmentStateProxy", (), {})()
    for key, value in decoded.items():
        setattr(proxy, key, value)
    decoded_state = layer_state(proxy)
    return decoded_state == current


def preferred_tag_payloads(layer: Any) -> list[tuple[bytes, bytes]]:
    """Preserve exact imported native blocks until their parameters change."""
    raw = raw_tag_mapping(layer)
    if raw and raw_tags_match_layer(layer):
        return [
            (key.encode("latin1", "replace")[:4].ljust(4, b" "), payload)
            for key, payload in raw.items()
        ]
    return native_tag_payloads(layer)


def metadata_state(layer: Any) -> dict[str, Any]:
    """JSON-safe state used by the lightweight metadata dirty detector."""
    state = layer_state(layer)
    return {
        key: value
        for key, value in state.items()
        if key in _STATE_FIELDS
    }



def _state(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        state = dict(value)
        if bool(state.get("_native_units", False)):
            return state
        proxy = type("_AdjustmentStateProxy", (), {})()
        for key, item in state.items():
            setattr(proxy, key, item)
        return layer_state(proxy)
    return layer_state(value)


def _natural_cubic_spline(x, y, samples):
    import numpy as np

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    samples = np.asarray(samples, dtype=np.float64)
    widths = np.diff(x)
    matrix = np.array(
        [
            [2.0 * (widths[0] + widths[1]), widths[1]],
            [widths[1], 2.0 * (widths[1] + widths[2])],
        ],
        dtype=np.float64,
    )
    rhs = np.array(
        [
            6.0 * ((y[2] - y[1]) / widths[1] - (y[1] - y[0]) / widths[0]),
            6.0 * ((y[3] - y[2]) / widths[2] - (y[2] - y[1]) / widths[1]),
        ],
        dtype=np.float64,
    )
    second = np.concatenate(
        (
            np.zeros(1, dtype=np.float64),
            np.linalg.solve(matrix, rhs),
            np.zeros(1, dtype=np.float64),
        )
    )
    result = np.empty_like(samples, dtype=np.float64)
    for index in range(3):
        if index == 2:
            selected = (samples >= x[index]) & (samples <= x[index + 1])
        else:
            selected = (samples >= x[index]) & (samples < x[index + 1])
        current = samples[selected]
        width = widths[index]
        result[selected] = (
            second[index] * (x[index + 1] - current) ** 3 / (6.0 * width)
            + second[index + 1] * (current - x[index]) ** 3 / (6.0 * width)
            + (y[index] - second[index] * width * width / 6.0)
            * (x[index + 1] - current)
            / width
            + (y[index + 1] - second[index + 1] * width * width / 6.0)
            * (current - x[index])
            / width
        )
    return result.astype(np.float32)


_PS_CURVE_KNOT_X = (0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 148, 152, 156, 160, 164, 168, 172, 176, 180, 184, 188, 192, 196, 200, 204, 208, 212, 216, 220, 224, 228, 232, 236, 240, 244, 248, 252, 255)
_PS_BRIGHTNESS_CURVE_KNOTS = {
    -100: (0, 2, 4, 6, 9, 11, 13, 15, 17, 19, 21, 23, 26, 28, 30, 32, 34, 36, 38, 40, 43, 45, 47, 49, 51, 53, 55, 58, 60, 62, 64, 66, 68, 70, 73, 75, 77, 79, 82, 84, 87, 90, 92, 95, 98, 101, 104, 108, 111, 115, 118, 122, 127, 131, 136, 141, 147, 153, 160, 168, 177, 189, 204, 227, 255),
    -75: (0, 2, 5, 7, 10, 12, 15, 17, 20, 22, 25, 27, 30, 32, 35, 37, 40, 42, 45, 47, 50, 52, 55, 57, 60, 62, 65, 67, 70, 72, 75, 77, 80, 82, 85, 88, 90, 93, 96, 99, 102, 105, 108, 111, 114, 118, 122, 125, 129, 133, 137, 142, 146, 151, 156, 162, 168, 174, 181, 189, 197, 207, 220, 236, 255),
    -50: (0, 3, 6, 9, 12, 15, 18, 20, 23, 26, 29, 32, 35, 38, 41, 44, 47, 50, 53, 55, 58, 61, 64, 67, 70, 73, 76, 79, 82, 85, 88, 90, 93, 96, 99, 102, 105, 109, 112, 115, 118, 122, 125, 129, 132, 136, 140, 144, 148, 152, 156, 161, 165, 170, 175, 180, 186, 192, 198, 205, 212, 220, 230, 242, 255),
    -40: (0, 3, 6, 9, 12, 16, 19, 22, 25, 28, 31, 34, 37, 40, 44, 47, 50, 53, 56, 59, 62, 65, 68, 72, 75, 78, 81, 84, 87, 90, 93, 96, 99, 103, 106, 109, 112, 116, 119, 122, 126, 129, 133, 136, 140, 144, 147, 151, 155, 159, 164, 168, 172, 177, 182, 187, 192, 198, 204, 210, 217, 224, 233, 244, 255),
    -25: (0, 3, 7, 10, 14, 17, 21, 24, 27, 31, 34, 38, 41, 44, 48, 51, 55, 58, 62, 65, 68, 72, 75, 79, 82, 85, 89, 92, 96, 99, 103, 106, 109, 113, 116, 120, 123, 127, 130, 134, 137, 141, 144, 148, 152, 155, 159, 163, 167, 171, 175, 179, 183, 188, 192, 197, 202, 207, 212, 218, 224, 231, 238, 247, 255),
    0: (0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 148, 152, 156, 160, 164, 168, 172, 176, 180, 184, 188, 192, 196, 200, 204, 208, 212, 216, 220, 224, 228, 232, 236, 240, 244, 248, 252, 255),
    25: (0, 5, 9, 14, 19, 23, 28, 33, 37, 42, 47, 52, 56, 61, 66, 70, 75, 80, 84, 89, 94, 98, 103, 108, 112, 117, 122, 126, 131, 136, 140, 145, 150, 154, 159, 163, 168, 172, 176, 181, 185, 189, 193, 197, 201, 205, 209, 212, 216, 219, 222, 226, 229, 232, 235, 237, 240, 242, 245, 247, 249, 251, 252, 254, 255),
    50: (0, 5, 11, 16, 22, 27, 33, 38, 44, 49, 55, 60, 66, 71, 77, 82, 88, 93, 99, 104, 110, 115, 121, 126, 132, 137, 142, 147, 152, 157, 162, 167, 171, 176, 180, 184, 188, 192, 196, 200, 203, 207, 210, 214, 217, 220, 223, 226, 228, 231, 233, 236, 238, 240, 242, 244, 246, 247, 249, 250, 251, 253, 254, 254, 255),
    60: (0, 6, 12, 18, 23, 29, 35, 41, 47, 53, 58, 64, 70, 76, 82, 88, 93, 99, 105, 111, 117, 123, 128, 134, 140, 145, 150, 156, 161, 166, 170, 175, 179, 184, 188, 192, 196, 199, 203, 207, 210, 213, 216, 219, 222, 225, 227, 230, 232, 235, 237, 239, 241, 242, 244, 246, 247, 249, 250, 251, 252, 253, 254, 255, 255),
    75: (0, 6, 13, 19, 26, 32, 38, 45, 51, 58, 64, 71, 77, 83, 90, 96, 103, 109, 115, 122, 128, 135, 141, 147, 152, 158, 163, 168, 173, 178, 182, 187, 191, 195, 199, 203, 206, 209, 213, 216, 219, 222, 224, 227, 229, 232, 234, 236, 238, 239, 241, 243, 244, 246, 247, 248, 249, 250, 251, 252, 253, 253, 254, 255, 255),
    100: (0, 8, 15, 23, 30, 38, 45, 53, 60, 68, 75, 83, 90, 98, 105, 113, 120, 128, 135, 142, 149, 155, 161, 167, 173, 178, 184, 188, 193, 197, 202, 205, 209, 213, 216, 219, 222, 225, 227, 230, 232, 234, 236, 238, 240, 241, 243, 244, 245, 246, 247, 248, 249, 250, 250, 251, 252, 252, 253, 253, 253, 254, 254, 255, 255),
}
_PS_CONTRAST_CURVE_KNOTS = {
    -50: (0, 5, 11, 16, 21, 26, 31, 36, 41, 46, 50, 55, 59, 64, 68, 72, 76, 80, 84, 88, 91, 95, 98, 102, 105, 108, 111, 114, 117, 120, 123, 125, 128, 130, 133, 136, 139, 141, 144, 148, 151, 154, 157, 161, 165, 168, 172, 176, 180, 184, 188, 192, 197, 201, 206, 210, 215, 220, 225, 230, 235, 240, 245, 251, 255),
    -25: (0, 5, 9, 14, 19, 23, 28, 32, 37, 41, 45, 49, 54, 58, 62, 66, 70, 74, 78, 82, 86, 89, 93, 97, 101, 104, 108, 111, 115, 118, 121, 125, 128, 131, 134, 138, 141, 145, 148, 152, 155, 159, 163, 166, 170, 174, 178, 182, 186, 190, 194, 198, 202, 207, 211, 215, 220, 224, 228, 233, 237, 242, 247, 251, 255),
    0: (0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 148, 152, 156, 160, 164, 168, 172, 176, 180, 184, 188, 192, 196, 200, 204, 208, 212, 216, 220, 224, 228, 232, 236, 240, 244, 248, 252, 255),
    25: (0, 3, 7, 10, 13, 17, 20, 24, 27, 31, 35, 39, 42, 46, 50, 54, 58, 62, 66, 70, 74, 79, 83, 87, 91, 96, 100, 105, 109, 114, 119, 123, 128, 133, 138, 142, 147, 151, 156, 160, 165, 169, 173, 178, 182, 186, 190, 194, 198, 202, 206, 210, 214, 217, 221, 225, 228, 232, 236, 239, 243, 246, 249, 253, 255),
    50: (0, 3, 5, 8, 11, 14, 17, 20, 23, 26, 30, 33, 37, 40, 44, 48, 52, 56, 60, 64, 69, 73, 78, 82, 87, 92, 97, 102, 107, 112, 117, 123, 128, 134, 139, 144, 149, 155, 160, 164, 169, 174, 179, 183, 187, 192, 196, 200, 204, 208, 212, 216, 219, 223, 226, 230, 233, 236, 239, 242, 245, 248, 251, 253, 255),
    75: (0, 2, 4, 6, 8, 10, 13, 16, 18, 21, 24, 28, 31, 34, 38, 42, 46, 50, 54, 59, 63, 68, 72, 77, 82, 88, 93, 99, 104, 110, 116, 122, 128, 134, 141, 146, 152, 158, 163, 169, 174, 179, 184, 189, 193, 198, 202, 206, 210, 214, 218, 221, 225, 228, 231, 234, 237, 240, 243, 245, 248, 250, 252, 254, 255),
    100: (0, 1, 2, 4, 5, 7, 9, 11, 14, 16, 19, 22, 25, 29, 32, 36, 40, 44, 48, 53, 57, 62, 67, 73, 78, 84, 89, 95, 102, 108, 115, 121, 128, 135, 142, 149, 155, 161, 167, 173, 178, 184, 189, 194, 199, 203, 208, 212, 216, 220, 224, 227, 231, 234, 237, 239, 242, 244, 246, 248, 250, 252, 253, 254, 255),
}

def _interpolated_ps_curve(value: float, anchors: dict[int, tuple[int, ...]]):
    import numpy as np

    keys = sorted(int(key) for key in anchors)
    amount = max(float(keys[0]), min(float(keys[-1]), float(value)))
    lower = max(key for key in keys if float(key) <= amount)
    upper = min(key for key in keys if float(key) >= amount)
    lower_values = np.asarray(anchors[lower], dtype=np.float32)
    if lower == upper:
        values = lower_values
    else:
        upper_values = np.asarray(anchors[upper], dtype=np.float32)
        factor = np.float32((amount - float(lower)) / float(upper - lower))
        values = lower_values * (np.float32(1.0) - factor) + upper_values * factor
    return np.interp(
        np.arange(256, dtype=np.float32),
        np.asarray(_PS_CURVE_KNOT_X, dtype=np.float32),
        values,
    ).astype(np.float32) / np.float32(255.0)


def _brightness_contrast_lut(brightness: int, contrast: int):
    """Photoshop 2026 non-legacy byte-domain Brightness/Contrast curve."""
    import numpy as np

    brightness_curve = _interpolated_ps_curve(
        int(brightness), _PS_BRIGHTNESS_CURVE_KNOTS
    )
    contrast_curve = _interpolated_ps_curve(
        max(-50, int(contrast)), _PS_CONTRAST_CURVE_KNOTS
    )
    domain = np.linspace(0.0, 1.0, 256, dtype=np.float32)
    return np.interp(brightness_curve, domain, contrast_curve).astype(np.float32)


def _rgb_to_hsl(rgb):
    import numpy as np

    source = np.asarray(rgb, dtype=np.float32)
    minimum = np.min(source, axis=-1)
    maximum = np.max(source, axis=-1)
    delta = maximum - minimum
    lightness = (maximum + minimum) * np.float32(0.5)
    saturation = np.zeros_like(lightness)
    valid = delta > np.float32(1.0e-9)
    dark = valid & (lightness <= np.float32(0.5))
    light = valid & ~dark
    saturation[dark] = delta[dark] / np.maximum(
        maximum[dark] + minimum[dark], np.float32(1.0e-9)
    )
    saturation[light] = delta[light] / np.maximum(
        np.float32(2.0) - maximum[light] - minimum[light],
        np.float32(1.0e-9),
    )
    hue = np.zeros_like(lightness)
    red = valid & (source[..., 0] >= maximum - np.float32(1.0e-7))
    green = valid & ~red & (source[..., 1] >= maximum - np.float32(1.0e-7))
    blue = valid & ~red & ~green
    hue[red] = (
        (source[..., 1] - source[..., 2])[red] / delta[red]
    ) % np.float32(6.0)
    hue[green] = (
        (source[..., 2] - source[..., 0])[green] / delta[green]
        + np.float32(2.0)
    )
    hue[blue] = (
        (source[..., 0] - source[..., 1])[blue] / delta[blue]
        + np.float32(4.0)
    )
    hue = (hue / np.float32(6.0)) % np.float32(1.0)
    return np.stack((hue, saturation, lightness), axis=-1)


def _hsl_to_rgb(hsl):
    import numpy as np

    source = np.asarray(hsl, dtype=np.float32)
    hue = (source[..., 0] % np.float32(1.0)) * np.float32(6.0)
    saturation = np.clip(source[..., 1], 0.0, 1.0)
    lightness = np.clip(source[..., 2], 0.0, 1.0)
    chroma = (
        np.float32(1.0) - np.abs(np.float32(2.0) * lightness - np.float32(1.0))
    ) * saturation
    secondary = chroma * (
        np.float32(1.0) - np.abs((hue % np.float32(2.0)) - np.float32(1.0))
    )
    zero = np.zeros_like(hue)
    conditions = (
        hue < 1.0,
        (hue >= 1.0) & (hue < 2.0),
        (hue >= 2.0) & (hue < 3.0),
        (hue >= 3.0) & (hue < 4.0),
        (hue >= 4.0) & (hue < 5.0),
        hue >= 5.0,
    )
    choices = (
        np.stack((chroma, secondary, zero), axis=-1),
        np.stack((secondary, chroma, zero), axis=-1),
        np.stack((zero, chroma, secondary), axis=-1),
        np.stack((zero, secondary, chroma), axis=-1),
        np.stack((secondary, zero, chroma), axis=-1),
        np.stack((chroma, zero, secondary), axis=-1),
    )
    result = np.select(
        tuple(condition[..., None] for condition in conditions), choices
    )
    return result + (lightness - chroma * np.float32(0.5))[..., None]


def _levels_transfer_lut(state: dict[str, Any]):
    import numpy as np

    input_black = float(state.get("adj_levels_input_black", 0)) / 255.0
    input_white = float(state.get("adj_levels_input_white", 255)) / 255.0
    output_black = float(state.get("adj_levels_output_black", 0)) / 255.0
    output_white = float(state.get("adj_levels_output_white", 255)) / 255.0
    gamma = float(state.get("adj_levels_gamma", 100)) / 100.0
    domain = np.linspace(0.0, 1.0, 256, dtype=np.float32)
    normalized = np.clip(
        (domain - np.float32(input_black))
        / np.float32(max(input_white - input_black, 1.0e-9)),
        0.0,
        1.0,
    )
    gamma_lut = adjustment_calibration.levels_gamma_lut(gamma)
    adjusted = np.interp(normalized, domain, gamma_lut).astype(np.float32)
    return np.clip(
        adjusted * np.float32(output_white - output_black)
        + np.float32(output_black),
        0.0,
        1.0,
    )


def _color_balance_transfer_luts(state: dict[str, Any]):
    return adjustment_calibration.transfer_luts(state)


def apply_rgb(rgb, adjustment: Any):
    """Apply one native adjustment to encoded-sRGB float RGB values."""
    import numpy as np

    original = np.asarray(rgb, dtype=np.float32)
    if original.shape[-1] < 3:
        raise ValueError("adjustment input must contain RGB channels")
    source = np.clip(original[..., :3], 0.0, 1.0)
    state = _state(adjustment)
    adjustment_type = str(state.get("adjustment_type", "NONE") or "NONE").upper()
    if adjustment_type not in SUPPORTED_TYPES:
        return source.copy()

    if adjustment_type == "INVERT":
        return np.float32(1.0) - source

    if adjustment_type == "THRESHOLD":
        threshold = float(state.get("adj_threshold", 128))
        luminance = np.round(
            (
                source[..., 0] * np.float32(0.30)
                + source[..., 1] * np.float32(0.59)
                + source[..., 2] * np.float32(0.11)
            )
            * np.float32(255.0)
        )
        boundary = (
            np.float32(threshold) - np.float32(1.0 / 255.0)
        ) * np.float32(255.0 / 256.0)
        result = (luminance > boundary).astype(np.float32)
        return np.repeat(result[..., None], 3, axis=-1)

    if adjustment_type == "POSTERIZE":
        levels = max(2, min(256, int(state.get("adj_posterize_levels", 4))))
        return np.floor(
            np.float32(255.0 / 256.0) * source * np.float32(levels)
        ) / np.float32(levels - 1)

    if adjustment_type == "LEVELS":
        lut = _levels_transfer_lut(state)
        domain = np.linspace(0.0, 1.0, 256, dtype=np.float32)
        return np.stack(
            tuple(
                np.interp(source[..., channel], domain, lut).astype(np.float32)
                for channel in range(3)
            ),
            axis=-1,
        )

    if adjustment_type == "HUE_SATURATION":
        hue = float(state.get("adj_hue", 0))
        saturation = float(state.get("adj_saturation", 0))
        lightness = float(state.get("adj_lightness", 0))
        result = source.copy()
        lightness /= 100.0
        if lightness > 0.0:
            result = result * np.float32(1.0 - lightness) + np.float32(lightness)
        elif lightness < 0.0:
            result = result * np.float32(1.0 + lightness)
        hsl = _rgb_to_hsl(result)
        hsl[..., 0] = (
            hsl[..., 0] + np.float32(hue / 360.0)
        ) % np.float32(1.0)
        saturation /= 100.0
        if saturation > 0.0:
            hsl[..., 1] = hsl[..., 1] / np.float32(1.0 - saturation + 0.01)
        elif saturation < 0.0:
            hsl[..., 1] = hsl[..., 1] * np.float32(1.0 + saturation)
        hsl[..., 1] = np.clip(hsl[..., 1], 0.0, 1.0)
        return np.clip(_hsl_to_rgb(hsl), 0.0, 1.0)

    if adjustment_type == "BRIGHTNESS_CONTRAST":
        brightness = float(state.get("adj_brightness", 0))
        contrast = float(state.get("adj_contrast", 0))
        lut = _brightness_contrast_lut(int(round(brightness)), int(round(contrast)))
        domain = np.linspace(0.0, 1.0, 256, dtype=np.float32)
        return np.stack(
            tuple(
                np.interp(source[..., channel], domain, lut).astype(np.float32)
                for channel in range(3)
            ),
            axis=-1,
        )

    if adjustment_type == "COLOR_BALANCE":
        luts = _color_balance_transfer_luts(state)
        domain = np.linspace(0.0, 1.0, 256, dtype=np.float32)
        return np.stack(
            tuple(
                np.interp(source[..., channel], domain, luts[channel]).astype(
                    np.float32
                )
                for channel in range(3)
            ),
            axis=-1,
        )

    if adjustment_type == "GRADIENT_MAP":
        dark = np.asarray(
            state.get("adj_gradient_dark", (0, 0, 0)),
            dtype=np.float32,
        )[:3] / np.float32(65535.0)
        light = np.asarray(
            state.get("adj_gradient_light", (65535, 65535, 65535)),
            dtype=np.float32,
        )[:3] / np.float32(65535.0)
        luminance = np.mean(source, axis=-1)
        position = np.power(np.clip(luminance, 0.0, 1.0), np.float32(0.625))
        return np.clip(
            dark * (np.float32(1.0) - position[..., None])
            + light * position[..., None],
            0.0,
            1.0,
        )

    return source.copy()
