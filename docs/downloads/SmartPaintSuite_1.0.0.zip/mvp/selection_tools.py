# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Event-driven texture selections for the lightweight PSD workflow.

Selections are process-local application state. They never become PSD records.
While a selection is active, a temporary Image Paint keymap wraps Blender's
native brush and clips each completed stroke back to the captured selection.
A second event-bound keymap refreshes live mask GPU textures once after each
native mask stroke. Neither path performs idle polling.
"""


from dataclasses import dataclass
import json
import math
import time
from typing import Any

import bpy
from ..constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty

from .. import manager_rule_api as _manager_rule_api
from .. import runtime_registry
from . import image_editor_overlay as _image_editor_overlay


_SELECTIONS: dict[str, dict[str, Any]] = {}
_KEYMAP_ITEMS: list[tuple[Any, Any]] = []
_MASK_REFRESH_KEYMAP_ITEMS: list[tuple[Any, Any]] = []
_MASK_REFRESH_PENDING: set[str] = set()
_CLIP_PENDING = False
_OVERLAY_HANDLE = None
_OVERLAY_SHADER = None
_OVERLAY_SNAPSHOT = None
_GPU_MODULE = None
_OVERLAY_REDRAW_PENDING = False
_DRAG_GUIDE: dict[str, Any] | None = None
_MAX_BOUNDARY_SEGMENTS = 60000


MODE_ITEMS = (
    ("REPLACE", "置換", "現在の選択範囲を置き換えます"),
    ("ADD", "追加", "現在の選択範囲へ追加します"),
    ("SUBTRACT", "削除", "現在の選択範囲から削除します"),
    ("INTERSECT", "交差", "現在の選択範囲との共通部分を残します"),
)

SHAPE_ITEMS = (
    ("RECT", "矩形", "矩形の選択範囲を作成します"),
    ("ELLIPSE", "楕円", "楕円の選択範囲を作成します"),
    ("LASSO", "投げ縄", "自由形状の選択範囲を作成します"),
    ("POLYGON", "多角形", "クリックした頂点から多角形の選択範囲を作成します"),
)

_POLYGON_CLOSE_RADIUS = 8.0


def _material_key(material) -> str:
    return str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")


def _resolve_material(context=None):
    try:
        from .. import lightweight_mvp

        return lightweight_mvp._resolve_material(context)
    except Exception:
        return None


def _active_canvas(context=None, material=None):
    ctx = context or bpy.context
    paint = getattr(getattr(ctx, "scene", None), "tool_settings", None)
    image_paint = getattr(paint, "image_paint", None) if paint is not None else None
    image = getattr(image_paint, "canvas", None) if image_paint is not None else None
    if image is None:
        return None
    if material is not None:
        try:
            owner = str(image.get("smart_paint_suite_material", "") or "")
            if owner and owner != str(getattr(material, "name", "") or ""):
                return None
        except Exception:
            pass
    try:
        if int(image.size[0]) <= 1 or int(image.size[1]) <= 1:
            return None
    except Exception:
        return None
    return image


def _operator_canvas(context=None, material=None):
    """Canvas for an explicit operator: the active layer of this material, reconnected if needed."""
    try:
        from .. import lightweight_mvp

        lightweight_mvp.ensure_material_canvas(context or bpy.context, material)
    except Exception:
        pass
    return _active_canvas(context, material)


def _state(material) -> dict[str, Any] | None:
    return _SELECTIONS.get(_material_key(material))


def is_active(material) -> bool:
    value = _state(material)
    return bool(value and value.get("mask") is not None)


def mask_array(material, width: int = 0, height: int = 0):
    """Return the current selection as float32 values in [0, 1]."""
    value = _state(material)
    if not value:
        return None
    try:
        import numpy as np

        mask = np.asarray(value.get("mask"), dtype=np.uint8)
        stored_h, stored_w = mask.shape
        width = int(width or stored_w)
        height = int(height or stored_h)
        if (stored_w, stored_h) != (width, height):
            return None
        return np.ascontiguousarray(mask, dtype=np.float32) * np.float32(1.0 / 255.0)
    except Exception:
        return None


def selection_bbox(material):
    value = _state(material)
    if not value:
        return None
    cached = value.get("bbox")
    if cached is not None:
        return tuple(int(v) for v in cached)
    try:
        import numpy as np

        mask = np.asarray(value.get("mask"), dtype=np.uint8)
        ys, xs = np.nonzero(mask)
        bbox = (
            int(xs.min()),
            int(ys.min()),
            int(xs.max()) + 1,
            int(ys.max()) + 1,
        ) if xs.size else (0, 0, 0, 0)
        value["bbox"] = bbox
        return bbox
    except Exception:
        return None


def summary(material) -> dict[str, Any]:
    value = _state(material)
    if not value:
        return {"active": False, "pixels": 0, "bbox": None, "version": 0}
    try:
        import numpy as np

        mask = np.asarray(value.get("mask"), dtype=np.uint8)
        return {
            "active": True,
            "pixels": int((mask > 0).sum()),
            "bbox": selection_bbox(material),
            "version": int(value.get("version", 0) or 0),
            "width": int(mask.shape[1]),
            "height": int(mask.shape[0]),
        }
    except Exception:
        return {"active": True, "pixels": 0, "bbox": None, "version": 0}


def _write_stencil(material, value: dict[str, Any]) -> bool:
    """Sync SmartPaint-owned selection resources without touching Blender's stencil."""
    del material
    value["image"] = ""
    _request_overlay_redraw()
    return True


def sync_for_material(material) -> bool:
    value = _state(material)
    if value is None:
        if not _SELECTIONS:
            _remove_selection_keymaps()
        return False
    _write_stencil(material, value)
    _install_selection_keymaps()
    return True

def _tag_redraw() -> None:
    try:
        wm = bpy.context.window_manager
        for window in list(getattr(wm, "windows", ()) or ()):
            if not _manager_rule_api.workspace_runtime_allowed(
                bpy.context,
                workspace=getattr(window, "workspace", None),
            ):
                continue
            for area in list(getattr(getattr(window, "screen", None), "areas", ()) or ()):
                if str(getattr(area, "type", "") or "") in {"IMAGE_EDITOR", "VIEW_3D"}:
                    area.tag_redraw()
    except Exception:
        pass


def _request_overlay_redraw() -> None:
    """Tag now and once on the next event-loop turn, without idle polling."""
    global _OVERLAY_REDRAW_PENDING
    _tag_redraw()
    if _OVERLAY_REDRAW_PENDING:
        return
    _OVERLAY_REDRAW_PENDING = True

    def redraw_once():
        global _OVERLAY_REDRAW_PENDING
        _OVERLAY_REDRAW_PENDING = False
        _tag_redraw()
        return None

    try:
        runtime_registry.register_timer(
            redraw_once, first_interval=0.0, persistent=False, label="selection_overlay_redraw"
        )
    except Exception:
        _OVERLAY_REDRAW_PENDING = False


def _is_mask_canvas(image) -> bool:
    try:
        return bool(image is not None and image.get("sps_mvp_mask_canvas", False))
    except Exception:
        return False


def _refresh_mask_gpu(material_name: str, image_name: str) -> None:
    """Publish one completed native mask stroke to shared GPU textures."""
    started = time.perf_counter()
    material = bpy.data.materials.get(str(material_name or ""))
    image = bpy.data.images.get(str(image_name or ""))
    try:
        if image is None or not _is_mask_canvas(image):
            return
        image.update()
        try:
            image.gl_free()
        except Exception:
            pass
        try:
            image.update_tag()
        except Exception:
            pass
        publish = {"ok": True, "reason": "live_composite_inactive"}
        if (
            material is not None
            and str(material.get("sps_lightweight_display_mode", "") or "")
            == "LIVE_COMPOSITE"
        ):
            from . import live_composite

            publish = live_composite.publish_mask_display_proxy(
                material,
                image,
                bpy.context,
            )
            if not bool(publish.get("ok", False)):
                raise RuntimeError(str(publish.get("reason", "mask_proxy_publish_failed")))
        if material is not None:
            material["sps_mask_gpu_refresh_count"] = (
                int(material.get("sps_mask_gpu_refresh_count", 0) or 0) + 1
            )
            material["sps_mask_gpu_refresh_ms"] = round(
                (time.perf_counter() - started) * 1000.0,
                3,
            )
            material["sps_mask_gpu_refresh_proxy"] = str(
                publish.get("proxy", "") or ""
            )
            material["sps_mask_gpu_refresh_copy_ms"] = float(
                publish.get("read_ms", 0.0) or 0.0
            ) + float(publish.get("write_ms", 0.0) or 0.0)
            material["sps_mask_gpu_refresh_rebound_nodes"] = int(
                publish.get("rebound_nodes", 0) or 0
            )
            material["sps_mask_gpu_refresh_error"] = ""
        _request_overlay_redraw()
    except Exception as exc:
        if material is not None:
            material["sps_mask_gpu_refresh_error"] = repr(exc)[:300]


def _schedule_mask_gpu_refresh(material_name: str, image_name: str) -> None:
    image_name = str(image_name or "")
    if not image_name or image_name in _MASK_REFRESH_PENDING:
        return
    _MASK_REFRESH_PENDING.add(image_name)
    state = {
        "released_at": None,
        "deadline": time.perf_counter() + 60.0,
    }

    def wait_for_release():
        if image_name not in _MASK_REFRESH_PENDING:
            return None
        now = time.perf_counter()
        if now < float(state["deadline"]) and _left_mouse_down():
            state["released_at"] = None
            return 0.02
        released_at = state.get("released_at")
        if released_at is None:
            state["released_at"] = now
            return 0.06
        if now - float(released_at) < 0.05:
            return 0.02
        _MASK_REFRESH_PENDING.discard(image_name)
        _refresh_mask_gpu(material_name, image_name)
        return None

    try:
        runtime_registry.register_timer(
            wait_for_release, first_interval=0.02, persistent=False, label="mask_stroke_release"
        )
    except Exception:
        _MASK_REFRESH_PENDING.discard(image_name)
        _refresh_mask_gpu(material_name, image_name)


@dataclass(frozen=True, slots=True)
class _SelectionDrawSnapshot:
    material_name: str
    canvas_name: str
    canvas_pointer: int
    width: int
    height: int
    shader: Any
    selection_batch: Any
    guide_batch: Any
    guide_color_a: tuple[float, float, float, float]
    guide_color_b: tuple[float, float, float, float]
    full_overlay_active: bool


def _overlay_shader():
    global _OVERLAY_SHADER, _GPU_MODULE
    if _OVERLAY_SHADER is not None:
        return _OVERLAY_SHADER
    import gpu

    _GPU_MODULE = gpu
    info = gpu.types.GPUShaderCreateInfo()
    info.vertex_in(0, "VEC2", "pos")
    info.push_constant("VEC2", "image_min")
    info.push_constant("VEC2", "image_max")
    info.push_constant("VEC2", "viewport_size")
    info.push_constant("VEC4", "color_a")
    info.push_constant("VEC4", "color_b")
    info.fragment_out(0, "VEC4", "frag_color")
    info.vertex_source(
        "void main() {\n"
        "  vec2 region_pos = mix(image_min, image_max, pos);\n"
        "  vec2 ndc = (region_pos / viewport_size) * 2.0 - 1.0;\n"
        "  gl_Position = vec4(ndc, 0.0, 1.0);\n"
        "}\n"
    )
    info.fragment_source(
        "void main() {\n"
        "  float dash = mod(floor((gl_FragCoord.x + gl_FragCoord.y) / 4.0), 2.0);\n"
        "  frag_color = mix(color_a, color_b, dash);\n"
        "}\n"
    )
    _OVERLAY_SHADER = gpu.shader.create_from_info(info)
    return _OVERLAY_SHADER


def _batch_for_positions(shader, positions):
    if not positions:
        return None
    from gpu_extras.batch import batch_for_shader

    return batch_for_shader(shader, "LINES", {"pos": tuple(positions)})


def _gpu_state_capture(gpu_module):
    values = []
    state = gpu_module.state
    for getter_name, setter_name in (
        ("blend_get", "blend_set"),
        ("depth_test_get", "depth_test_set"),
        ("face_culling_get", "face_culling_set"),
        ("line_width_get", "line_width_set"),
        ("point_size_get", "point_size_set"),
        ("depth_mask_get", "depth_mask_set"),
        ("color_mask_get", "color_mask_set"),
        ("scissor_get", "scissor_set"),
        ("viewport_get", "viewport_set"),
    ):
        getter = getattr(state, getter_name, None)
        setter = getattr(state, setter_name, None)
        if not callable(getter) or not callable(setter):
            continue
        try:
            values.append((setter, getter()))
        except (RuntimeError, TypeError, ValueError, AttributeError):
            continue
    return tuple(values)


def _gpu_state_restore(values) -> None:
    for setter, value in reversed(tuple(values)):
        try:
            if isinstance(value, tuple):
                setter(*value)
            else:
                setter(value)
        except (RuntimeError, TypeError, ValueError, AttributeError):
            continue


def _prepare_overlay_snapshot() -> bool:
    """Build immutable GPU resources outside the draw callback."""
    global _OVERLAY_SNAPSHOT
    context = getattr(bpy, "context", None)
    material = _resolve_material(context)
    if material is None:
        _OVERLAY_SNAPSHOT = None
        return False
    material_name = _material_key(material)
    value = _state(material)
    guide = _DRAG_GUIDE
    guide_matches = bool(guide and str(guide.get("material", "") or "") == material_name)
    if value is None and not guide_matches:
        _OVERLAY_SNAPSHOT = None
        return False
    image = _active_canvas(context, material)
    if image is None:
        _OVERLAY_SNAPSHOT = None
        return False
    try:
        width, height = int(image.size[0]), int(image.size[1])
        pointer = int(image.as_pointer())
        shader = _overlay_shader()
        selection_batch = _batch_for_positions(
            shader, tuple(value.get("boundary_segments", ())) if value is not None else ()
        )
        guide_batch = _batch_for_positions(
            shader, tuple(guide.get("positions", ())) if guide_matches else ()
        )
        _OVERLAY_SNAPSHOT = _SelectionDrawSnapshot(
            material_name=material_name,
            canvas_name=str(image.name),
            canvas_pointer=pointer,
            width=width,
            height=height,
            shader=shader,
            selection_batch=selection_batch,
            guide_batch=guide_batch,
            guide_color_a=tuple(guide.get("color_a", (0.03, 0.03, 0.03, 1.0))) if guide_matches else (0.03, 0.03, 0.03, 1.0),
            guide_color_b=tuple(guide.get("color_b", (0.95, 0.95, 0.95, 1.0))) if guide_matches else (0.95, 0.95, 0.95, 1.0),
            full_overlay_active=bool(_image_editor_overlay._HANDLE is not None and _image_editor_overlay.enabled(material)),
        )
        return True
    except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError) as exc:
        _OVERLAY_SNAPSHOT = None
        runtime_registry.component_state("selection_overlay", "FAILED", f"{type(exc).__name__}:{exc}")
        return False


def set_drag_guide(
    material,
    width: int,
    height: int,
    points,
    *,
    closed: bool = False,
    color_a=(0.03, 0.03, 0.03, 1.0),
    color_b=(0.95, 0.95, 0.95, 1.0),
) -> None:
    global _DRAG_GUIDE
    sequence = [(float(x), float(y)) for x, y in points]
    positions = []
    pairs = list(zip(sequence, sequence[1:]))
    if closed and len(sequence) > 2:
        pairs.append((sequence[-1], sequence[0]))
    for start, end in pairs:
        positions.append((start[0] / max(1, width), start[1] / max(1, height)))
        positions.append((end[0] / max(1, width), end[1] / max(1, height)))
    _DRAG_GUIDE = {
        "material": _material_key(material),
        "width": int(width),
        "height": int(height),
        "positions": tuple(positions),
        "color_a": tuple(float(v) for v in color_a),
        "color_b": tuple(float(v) for v in color_b),
    }
    _sync_overlay_handler()
    _tag_redraw()


def clear_drag_guide() -> None:
    global _DRAG_GUIDE
    _DRAG_GUIDE = None
    _sync_overlay_handler()
    _request_overlay_redraw()


def _set_shape_drag_guide(operator, current) -> None:
    material = bpy.data.materials.get(str(getattr(operator, "_material_name", "") or ""))
    if material is None:
        return
    start = tuple(getattr(operator, "_start", current))
    shape = str(getattr(operator, "shape", "RECT") or "RECT").upper()
    if shape == "ELLIPSE":
        x0, x1 = float(start[0]), float(current[0])
        y0, y1 = float(start[1]), float(current[1])
        cx, cy = (x0 + x1) * 0.5, (y0 + y1) * 0.5
        rx, ry = abs(x1 - x0) * 0.5, abs(y1 - y0) * 0.5
        points = [
            (
                cx + math.cos(index * math.tau / 64.0) * rx,
                cy + math.sin(index * math.tau / 64.0) * ry,
            )
            for index in range(64)
        ]
        closed = True
    elif shape == "LASSO":
        points = list(getattr(operator, "_points", ()) or ()) + [current]
        closed = False
    elif shape == "POLYGON":
        points = list(getattr(operator, "_points", ()) or ()) + [current]
        closed = False
    else:
        points = [start, (current[0], start[1]), current, (start[0], current[1])]
        closed = True
    set_drag_guide(
        material,
        int(getattr(operator, "_width", 1) or 1),
        int(getattr(operator, "_height", 1) or 1),
        points,
        closed=closed,
    )


def _draw_selection_overlay(force: bool = False):
    del force
    context = getattr(bpy, "context", None)
    if not _manager_rule_api.workspace_runtime_allowed(context):
        return
    snapshot = _OVERLAY_SNAPSHOT
    gpu_module = _GPU_MODULE
    if snapshot is None or gpu_module is None:
        return
    area = getattr(context, "area", None)
    space = getattr(context, "space_data", None)
    region = getattr(context, "region", None)
    if (
        area is None
        or str(getattr(area, "type", "") or "") != "IMAGE_EDITOR"
        or space is None
        or str(getattr(space, "type", "") or "") != "IMAGE_EDITOR"
        or region is None
        or str(getattr(region, "type", "") or "") != "WINDOW"
    ):
        return
    current = getattr(space, "image", None)
    if current is None:
        return
    try:
        if int(current.as_pointer()) != snapshot.canvas_pointer:
            return
    except (ReferenceError, AttributeError, TypeError, ValueError):
        return
    # The full-stack image overlay ownership decision is captured while the
    # immutable snapshot is prepared; draw performs no datablock lookup/import.
    if snapshot.full_overlay_active:
        return
    bounds = _image_editor_overlay._image_bounds(context, snapshot.width, snapshot.height)
    if bounds is None:
        return
    (x0, y0), (x1, y1) = bounds
    previous = _gpu_state_capture(gpu_module)
    try:
        shader = snapshot.shader
        shader.bind()
        shader.uniform_float("image_min", (float(x0), float(y0)))
        shader.uniform_float("image_max", (float(x1), float(y1)))
        shader.uniform_float(
            "viewport_size",
            (max(1.0, float(region.width)), max(1.0, float(region.height))),
        )
        gpu_module.state.blend_set("ALPHA")
        gpu_module.state.line_width_set(1.5)
        if snapshot.selection_batch is not None:
            shader.uniform_float("color_a", (0.02, 0.02, 0.02, 1.0))
            shader.uniform_float("color_b", (0.95, 0.95, 0.95, 1.0))
            snapshot.selection_batch.draw(shader)
        if snapshot.guide_batch is not None:
            shader.uniform_float("color_a", snapshot.guide_color_a)
            shader.uniform_float("color_b", snapshot.guide_color_b)
            snapshot.guide_batch.draw(shader)
    except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError) as exc:
        runtime_registry.component_state("selection_overlay_draw", "FAILED", f"{type(exc).__name__}:{exc}")
    finally:
        _gpu_state_restore(previous)


def _ensure_overlay_handler() -> None:
    global _OVERLAY_HANDLE
    if _OVERLAY_HANDLE is not None:
        return
    if not _prepare_overlay_snapshot():
        return
    handle = bpy.types.SpaceImageEditor.draw_handler_add(
        _draw_selection_overlay,
        (),
        "WINDOW",
        "POST_PIXEL",
    )
    try:
        runtime_registry.track_draw_handler(
            bpy.types.SpaceImageEditor.draw_handler_remove,
            handle,
            "WINDOW",
            label="selection_overlay",
        )
    except BaseException:
        bpy.types.SpaceImageEditor.draw_handler_remove(handle, "WINDOW")
        raise
    _OVERLAY_HANDLE = handle


def _remove_overlay_handler() -> None:
    global _OVERLAY_HANDLE, _OVERLAY_SHADER, _OVERLAY_SNAPSHOT, _GPU_MODULE
    handle = _OVERLAY_HANDLE
    _OVERLAY_HANDLE = None
    if handle is not None:
        runtime_registry.untrack_draw_handler(handle, remove=True)
    _OVERLAY_SHADER = None
    _OVERLAY_SNAPSHOT = None
    _GPU_MODULE = None


def _sync_overlay_handler() -> None:
    if _SELECTIONS or _DRAG_GUIDE is not None:
        prepared = _prepare_overlay_snapshot()
        if prepared:
            _ensure_overlay_handler()
        else:
            _remove_overlay_handler()
    else:
        _remove_overlay_handler()


def clear(material, *, remove_image: bool = True) -> bool:
    del remove_image
    key = _material_key(material)
    value = _SELECTIONS.pop(key, None)
    if value is None:
        return False
    if not _SELECTIONS:
        _remove_selection_keymaps()
    _sync_overlay_handler()
    _request_overlay_redraw()
    return True


def clear_all() -> None:
    for material_name in list(_SELECTIONS):
        material = bpy.data.materials.get(material_name)
        if material is not None:
            clear(material)
        else:
            _SELECTIONS.pop(material_name, None)
    _remove_selection_keymaps()
    # A removed material takes the direct-pop branch above and never calls
    # clear(), so aggregate teardown owns its handler/redraw transition.
    _sync_overlay_handler()
    _request_overlay_redraw()


def shutdown() -> None:
    global _OVERLAY_REDRAW_PENDING
    _OVERLAY_REDRAW_PENDING = True
    clear_all()
    clear_drag_guide()
    _remove_mask_refresh_keymaps()
    try:
        from . import live_composite

        live_composite.clear_mask_display_proxies()
    except Exception:
        pass
    _remove_overlay_handler()
    _OVERLAY_REDRAW_PENDING = False


def _boundary_segments(mask_u8):
    """Return a bounded normalized edge list without scanning during redraw."""
    import numpy as np

    inside = np.asarray(mask_u8, dtype=np.uint8) >= np.uint8(128)
    if inside.ndim != 2 or not bool(np.any(inside)):
        return ()
    height, width = int(inside.shape[0]), int(inside.shape[1])
    vertical_count = int(inside[:, 0].sum()) + int(inside[:, -1].sum())
    if width > 1:
        vertical_count += int(np.count_nonzero(inside[:, :-1] != inside[:, 1:]))
    horizontal_count = int(inside[0, :].sum()) + int(inside[-1, :].sum())
    if height > 1:
        horizontal_count += int(np.count_nonzero(inside[:-1, :] != inside[1:, :]))
    total = vertical_count + horizontal_count
    if total <= 0:
        return ()
    stride = max(1, int(math.ceil(total / float(_MAX_BOUNDARY_SEGMENTS))))
    positions = []
    ordinal = 0

    for y in range(height):
        row = inside[y]
        edges = []
        if bool(row[0]):
            edges.append(0)
        if width > 1:
            edges.extend((np.flatnonzero(row[:-1] != row[1:]) + 1).tolist())
        if bool(row[-1]):
            edges.append(width)
        for x in edges:
            if ordinal % stride == 0:
                positions.append((float(x) / width, float(y) / height))
                positions.append((float(x) / width, float(y + 1) / height))
            ordinal += 1

    for y in range(height + 1):
        if y == 0:
            edges = np.flatnonzero(inside[0])
        elif y == height:
            edges = np.flatnonzero(inside[-1])
        else:
            edges = np.flatnonzero(inside[y - 1] != inside[y])
        for x_value in edges:
            x = int(x_value)
            if ordinal % stride == 0:
                positions.append((float(x) / width, float(y) / height))
                positions.append((float(x + 1) / width, float(y) / height))
            ordinal += 1
    return tuple(positions)

def _combine_mask(material, new_mask, mode: str) -> tuple[bool, dict[str, Any]]:
    try:
        import numpy as np

        candidate = np.clip(np.asarray(new_mask, dtype=np.float32), 0.0, 1.0)
        if candidate.ndim != 2:
            return False, {"reason": "selection_mask_shape"}
        height, width = int(candidate.shape[0]), int(candidate.shape[1])
        previous = _state(material)
        old = None
        if previous is not None:
            old_u8 = np.asarray(previous.get("mask"), dtype=np.uint8)
            if tuple(old_u8.shape) == tuple(candidate.shape):
                old = old_u8.astype(np.float32) * np.float32(1.0 / 255.0)
        operation = str(mode or "REPLACE").upper()
        if old is None or operation == "REPLACE":
            combined = candidate
        elif operation == "ADD":
            combined = np.maximum(old, candidate)
        elif operation == "SUBTRACT":
            combined = old * (np.float32(1.0) - candidate)
        elif operation == "INTERSECT":
            combined = np.minimum(old, candidate)
        else:
            return False, {"reason": "selection_mode", "mode": operation}
        mask_u8 = np.ascontiguousarray(
            np.clip(np.floor(combined * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        version = int((previous or {}).get("version", 0) or 0) + 1
        value = {
            "mask": mask_u8,
            "width": width,
            "height": height,
            "version": version,
            "bbox": None,
            "image": str((previous or {}).get("image", "") or ""),
            "boundary_segments": _boundary_segments(mask_u8),
        }
        _SELECTIONS[_material_key(material)] = value
        _sync_overlay_handler()
        # The boundary handler is owned by selection state, not optional
        # stencil I/O. A failed stencil write must not defer visual update.
        _request_overlay_redraw()
        ok = _write_stencil(material, value)
        if ok:
            _install_selection_keymaps()
        info = summary(material)
        info["stencil_ok"] = bool(ok)
        info["mode"] = operation
        return bool(ok), info
    except Exception as exc:
        return False, {"reason": "selection_exception", "error": repr(exc)[:300]}


def _rect_mask(width: int, height: int, p0, p1, feather: float):
    import numpy as np

    x0, x1 = sorted((int(p0[0]), int(p1[0])))
    y0, y1 = sorted((int(p0[1]), int(p1[1])))
    x0 = max(0, min(width - 1, x0))
    x1 = max(0, min(width - 1, x1))
    y0 = max(0, min(height - 1, y0))
    y1 = max(0, min(height - 1, y1))
    mask = np.zeros((height, width), dtype=np.float32)
    if x1 < x0 or y1 < y0:
        return mask
    radius = max(0.0, float(feather))
    if radius <= 0.0:
        mask[y0 : y1 + 1, x0 : x1 + 1] = 1.0
        return mask
    yy, xx = np.mgrid[y0 : y1 + 1, x0 : x1 + 1]
    distance = np.minimum.reduce((xx - x0, x1 - xx, yy - y0, y1 - yy)).astype(np.float32)
    mask[y0 : y1 + 1, x0 : x1 + 1] = np.clip(
        (distance + np.float32(1.0)) / np.float32(max(1.0, radius)),
        0.0,
        1.0,
    )
    return mask


def _ellipse_mask(width: int, height: int, p0, p1, feather: float):
    import numpy as np

    x0, x1 = sorted((float(p0[0]), float(p1[0])))
    y0, y1 = sorted((float(p0[1]), float(p1[1])))
    cx, cy = (x0 + x1) * 0.5, (y0 + y1) * 0.5
    rx, ry = max(0.5, (x1 - x0) * 0.5), max(0.5, (y1 - y0) * 0.5)
    ix0 = max(0, int(math.floor(x0)))
    ix1 = min(width - 1, int(math.ceil(x1)))
    iy0 = max(0, int(math.floor(y0)))
    iy1 = min(height - 1, int(math.ceil(y1)))
    mask = np.zeros((height, width), dtype=np.float32)
    if ix1 < ix0 or iy1 < iy0:
        return mask
    yy, xx = np.mgrid[iy0 : iy1 + 1, ix0 : ix1 + 1]
    norm = np.sqrt(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2)
    radius = max(0.0, float(feather))
    if radius <= 0.0:
        local = (norm <= 1.0).astype(np.float32)
    else:
        edge = max(1.0 / max(rx, ry), radius / max(rx, ry))
        local = np.clip((1.0 - norm) / edge, 0.0, 1.0).astype(np.float32)
    mask[iy0 : iy1 + 1, ix0 : ix1 + 1] = local
    return mask


def _lasso_mask(width: int, height: int, points, feather: float):
    import numpy as np

    pts = [(float(x), float(y)) for x, y in points]
    mask = np.zeros((height, width), dtype=np.float32)
    if len(pts) < 3:
        return mask
    min_y = max(0, int(math.floor(min(y for _x, y in pts))))
    max_y = min(height - 1, int(math.ceil(max(y for _x, y in pts))))
    edges = []
    for index, (x0, y0) in enumerate(pts):
        x1, y1 = pts[(index + 1) % len(pts)]
        if abs(y1 - y0) <= 1.0e-8:
            continue
        if y0 > y1:
            x0, x1 = x1, x0
            y0, y1 = y1, y0
        edges.append((x0, y0, x1, y1))
    for y in range(min_y, max_y + 1):
        scan = float(y) + 0.5
        intersections = []
        for x0, y0, x1, y1 in edges:
            if y0 <= scan < y1:
                factor = (scan - y0) / (y1 - y0)
                intersections.append(x0 + (x1 - x0) * factor)
        intersections.sort()
        for left, right in zip(intersections[0::2], intersections[1::2]):
            xa = max(0, int(math.ceil(left)))
            xb = min(width - 1, int(math.floor(right)))
            if xb >= xa:
                mask[y, xa : xb + 1] = 1.0
    radius = max(0, int(round(float(feather))))
    if radius > 0:
        # A bounded box blur provides a smooth edge without a scipy dependency.
        for _ in range(min(radius, 32)):
            padded = np.pad(mask, ((1, 1), (1, 1)), mode="edge")
            mask = (
                padded[:-2, 1:-1]
                + padded[2:, 1:-1]
                + padded[1:-1, :-2]
                + padded[1:-1, 2:]
                + padded[1:-1, 1:-1] * 4.0
            ) * np.float32(0.125)
    return np.clip(mask, 0.0, 1.0)


def _window_region(context):
    area = getattr(context, "area", None)
    if getattr(area, "type", None) != "IMAGE_EDITOR":
        return None
    for region in list(getattr(area, "regions", ()) or ()):
        if str(getattr(region, "type", "") or "") == "WINDOW":
            return region
    return None


def _event_region_xy(context, event):
    region = _window_region(context)
    if region is None:
        return None
    context_region = getattr(context, "region", None)
    if context_region is region:
        mouse_region_x = getattr(event, "mouse_region_x", None)
        mouse_region_y = getattr(event, "mouse_region_y", None)
        if mouse_region_x is not None and mouse_region_y is not None:
            return float(mouse_region_x), float(mouse_region_y)
    # Region coordinates and event.mouse_x/y share window space. Subtracting
    # area.x/y as well offsets tools whenever the Image Editor is not at (0, 0).
    return (
        float(getattr(event, "mouse_x", 0) or 0)
        - float(getattr(region, "x", 0) or 0),
        float(getattr(event, "mouse_y", 0) or 0)
        - float(getattr(region, "y", 0) or 0),
    )


def _inside_image_window(context, event) -> bool:
    region = _window_region(context)
    point = _event_region_xy(context, event)
    if region is None or point is None:
        return False
    return (
        0.0 <= point[0] < float(getattr(region, "width", 0) or 0)
        and 0.0 <= point[1] < float(getattr(region, "height", 0) or 0)
    )


def _event_image_xy(context, event, width: int, height: int):
    region = _window_region(context)
    point = _event_region_xy(context, event)
    if region is None or point is None:
        return 0, 0
    try:
        vx, vy = region.view2d.region_to_view(float(point[0]), float(point[1]))
        x = int(round(float(vx) * float(max(1, width - 1))))
        y = int(round(float(vy) * float(max(1, height - 1))))
    except Exception:
        x = int(round(point[0] / max(1.0, float(region.width)) * max(1, width - 1)))
        y = int(round(point[1] / max(1.0, float(region.height)) * max(1, height - 1)))
    return max(0, min(width - 1, x)), max(0, min(height - 1, y))


def _shape_mask(shape: str, width: int, height: int, p0, p1, points, feather: float):
    kind = str(shape or "RECT").upper()
    if kind == "ELLIPSE":
        return _ellipse_mask(width, height, p0, p1, feather)
    if kind in {"LASSO", "POLYGON"}:
        return _lasso_mask(width, height, points, feather)
    return _rect_mask(width, height, p0, p1, feather)


def _install_selection_keymaps() -> bool:
    if _KEYMAP_ITEMS:
        return True
    try:
        wm = bpy.context.window_manager
        config = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        if config is None:
            return False
        keymap = config.keymaps.get("Image Paint")
        if keymap is None:
            keymap = config.keymaps.new(name="Image Paint", space_type="EMPTY", region_type="WINDOW")
        item = keymap.keymap_items.new(
            SPS_OT_lightweight_selection_paint.bl_idname,
            type="LEFTMOUSE",
            value="PRESS",
        )
        item.active = True
        _KEYMAP_ITEMS.append((keymap, item))
        return True
    except Exception:
        _remove_selection_keymaps()
        return False


def _remove_selection_keymaps() -> None:
    for keymap, item in reversed(list(_KEYMAP_ITEMS)):
        try:
            keymap.keymap_items.remove(item)
        except Exception:
            pass
    _KEYMAP_ITEMS.clear()


def ensure_mask_refresh_keymap() -> bool:
    if _MASK_REFRESH_KEYMAP_ITEMS:
        return True
    try:
        wm = bpy.context.window_manager
        config = getattr(getattr(wm, "keyconfigs", None), "addon", None)
        if config is None:
            return False
        keymap = config.keymaps.get("Image Paint")
        if keymap is None:
            keymap = config.keymaps.new(
                name="Image Paint",
                space_type="EMPTY",
                region_type="WINDOW",
            )
        item = keymap.keymap_items.new(
            SPS_OT_lightweight_mask_paint_refresh.bl_idname,
            type="LEFTMOUSE",
            value="PRESS",
        )
        item.active = True
        _MASK_REFRESH_KEYMAP_ITEMS.append((keymap, item))
        return True
    except Exception:
        _remove_mask_refresh_keymaps()
        return False


def _remove_mask_refresh_keymaps() -> None:
    for keymap, item in reversed(list(_MASK_REFRESH_KEYMAP_ITEMS)):
        try:
            keymap.keymap_items.remove(item)
        except Exception:
            pass
    _MASK_REFRESH_KEYMAP_ITEMS.clear()
    _MASK_REFRESH_PENDING.clear()


def _capture_canvas_u8(image):
    import numpy as np

    width, height = int(image.size[0]), int(image.size[1])
    flat = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(flat)
    pixels = np.ascontiguousarray(
        np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
        dtype=np.uint8,
    )
    del flat
    return width, height, pixels


def _finish_selection_stroke(
    material_name: str,
    image_name: str,
    baseline,
    selection,
    capture_ms: float,
):
    global _CLIP_PENDING
    started = time.perf_counter()
    try:
        import numpy as np

        material = bpy.data.materials.get(str(material_name or ""))
        image = bpy.data.images.get(str(image_name or ""))
        if material is None or image is None:
            return None
        width, height = int(image.size[0]), int(image.size[1])
        base = np.asarray(baseline, dtype=np.uint8)
        mask = np.asarray(selection, dtype=np.uint8)
        if tuple(base.shape) != (height, width, 4) or tuple(mask.shape) != (height, width):
            material["sps_selection_last_clip_error"] = "selection_size_changed"
            return None
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        current = np.ascontiguousarray(
            np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        del flat
        native_changed = np.any(current != base, axis=2)
        native_pixels = int(native_changed.sum())
        if native_pixels <= 0:
            material["sps_selection_last_clip_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
            material["sps_selection_last_capture_ms"] = round(float(capture_ms), 3)
            material["sps_selection_last_native_pixels"] = 0
            material["sps_selection_last_final_pixels"] = 0
            material["sps_selection_last_outside_pixels"] = 0
            material["sps_selection_last_clip_ok"] = True
            return None
        # Blend in bounded row chunks to keep peak memory stable on 4K/8K maps.
        for y0 in range(0, height, 128):
            y1 = min(height, y0 + 128)
            weight = mask[y0:y1].astype(np.uint16)[:, :, None]
            source = current[y0:y1].astype(np.uint16)
            original = base[y0:y1].astype(np.uint16)
            current[y0:y1] = (
                (source * weight + original * (np.uint16(255) - weight) + np.uint16(127))
                // np.uint16(255)
            ).astype(np.uint8)
        final_changed = np.any(current != base, axis=2)
        outside = mask == 0
        outside_changed = int((final_changed & outside).sum())
        write = current.astype(np.float32)
        write *= np.float32(1.0 / 255.0)
        image.pixels.foreach_set(write.reshape((-1,)))
        image.update()
        if _is_mask_canvas(image):
            _refresh_mask_gpu(_material_key(material), str(image.name))
        del write
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        material["sps_selection_last_clip_ms"] = round(elapsed_ms, 3)
        material["sps_selection_last_capture_ms"] = round(float(capture_ms), 3)
        material["sps_selection_last_native_pixels"] = native_pixels
        material["sps_selection_last_final_pixels"] = int(final_changed.sum())
        material["sps_selection_last_outside_pixels"] = outside_changed
        material["sps_selection_last_clip_ok"] = bool(outside_changed == 0 and elapsed_ms < 10000.0)
        try:
            from .. import lightweight_mvp

            lightweight_mvp._tag_redraw(bpy.context)
        except Exception:
            _tag_redraw()
        return None
    except Exception as exc:
        try:
            material = bpy.data.materials.get(str(material_name or ""))
            if material is not None:
                material["sps_selection_last_clip_error"] = repr(exc)[:300]
                material["sps_selection_last_clip_ok"] = False
        except Exception:
            pass
        return None
    finally:
        _CLIP_PENDING = False
        try:
            del baseline
            del selection
        except Exception:
            pass


def _left_mouse_down() -> bool:
    try:
        import ctypes

        return bool(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)
    except Exception:
        return False


def _schedule_selection_clip(
    material_name: str,
    image_name: str,
    baseline,
    selection,
    capture_ms: float,
) -> None:
    state = {"released_at": None, "deadline": time.perf_counter() + 60.0}

    def wait_for_release():
        if not _CLIP_PENDING:
            return None
        now = time.perf_counter()
        if now < float(state["deadline"]) and _left_mouse_down():
            state["released_at"] = None
            return 0.02
        released_at = state.get("released_at")
        if released_at is None:
            state["released_at"] = now
            return 0.06
        if now - float(released_at) < 0.05:
            return 0.02
        return _finish_selection_stroke(
            material_name,
            image_name,
            baseline,
            selection,
            capture_ms,
        )

    try:
        runtime_registry.register_timer(
            wait_for_release, first_interval=0.02, persistent=False, label="selection_stroke_release"
        )
    except Exception:
        _finish_selection_stroke(
            material_name,
            image_name,
            baseline,
            selection,
            capture_ms,
        )


class SPS_OT_lightweight_mask_paint_refresh(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_mask_paint_refresh"
    bl_label = "マスク描画をライブ表示へ反映"
    bl_description = "Blender標準ブラシのマスク描画をストローク終了時にライブ表示へ反映します"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        del event
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"PASS_THROUGH"}
        material = _resolve_material(context)
        image = _active_canvas(context, material)
        if material is None or not _is_mask_canvas(image):
            return {"PASS_THROUGH"}
        if _state(material) is not None:
            return {"PASS_THROUGH"}
        native = bpy.ops.paint.image_paint("INVOKE_DEFAULT")
        if not ({"RUNNING_MODAL", "FINISHED"} & set(native)):
            return {"CANCELLED"}
        _schedule_mask_gpu_refresh(_material_key(material), str(image.name))
        return {"FINISHED"}


class SPS_OT_lightweight_selection_paint(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_selection_paint"
    bl_label = "\u9078\u629e\u7bc4\u56f2\u5185\u3078\u30da\u30a4\u30f3\u30c8"
    bl_description = "Blender\u6a19\u6e96\u30d6\u30e9\u30b7\u306e\u63cf\u753b\u3092\u73fe\u5728\u306e\u9078\u629e\u7bc4\u56f2\u5185\u3078\u5236\u9650\u3057\u307e\u3059"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        global _CLIP_PENDING
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"PASS_THROUGH"}
        material = _resolve_material(context)
        image = _active_canvas(context, material)
        state = _state(material) if material is not None else None
        if material is None or image is None or state is None:
            return {"PASS_THROUGH"}
        if _CLIP_PENDING:
            self.report({"WARNING"}, _rpt("前のストロークを選択範囲へ反映しています。"))
            return {"CANCELLED"}
        try:
            import numpy as np

            width, height = int(image.size[0]), int(image.size[1])
            mask = np.ascontiguousarray(state.get("mask"), dtype=np.uint8)
            if tuple(mask.shape) != (height, width):
                return {"CANCELLED"}
            if not bool(np.any(mask)):
                material["sps_selection_last_capture_ms"] = 0.0
                material["sps_selection_last_clip_ms"] = 0.0
                material["sps_selection_last_native_pixels"] = 0
                material["sps_selection_last_final_pixels"] = 0
                material["sps_selection_last_outside_pixels"] = 0
                material["sps_selection_last_clip_ok"] = True
                material["sps_selection_last_clip_error"] = ""
                return {"FINISHED"}
            if bool(np.all(mask == np.uint8(255))):
                native = bpy.ops.paint.image_paint("INVOKE_DEFAULT")
                if not ({"RUNNING_MODAL", "FINISHED"} & set(native)):
                    return {"CANCELLED"}
                if _is_mask_canvas(image):
                    _schedule_mask_gpu_refresh(_material_key(material), str(image.name))
                material["sps_selection_last_capture_ms"] = 0.0
                material["sps_selection_last_clip_ms"] = 0.0
                material["sps_selection_last_clip_ok"] = True
                material["sps_selection_last_clip_error"] = ""
                return {"FINISHED"}
            started = time.perf_counter()
            width, height, baseline = _capture_canvas_u8(image)
            capture_ms = (time.perf_counter() - started) * 1000.0
            native = bpy.ops.paint.image_paint("INVOKE_DEFAULT")
            if not ({"RUNNING_MODAL", "FINISHED"} & set(native)):
                return {"CANCELLED"}
            _CLIP_PENDING = True
            material["sps_selection_last_capture_ms"] = round(float(capture_ms), 3)
            material["sps_selection_last_clip_ms"] = -1.0
            material["sps_selection_last_clip_error"] = ""
            _schedule_selection_clip(
                _material_key(material),
                str(image.name),
                baseline,
                mask.copy(),
                float(capture_ms),
            )
            return {"FINISHED"}
        except Exception as exc:
            try:
                material["sps_selection_last_clip_error"] = repr(exc)[:300]
            except Exception:
                pass
            _CLIP_PENDING = False
            return {"CANCELLED"}


class SPS_OT_lightweight_selection_shape(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_selection_shape"
    bl_label = "選択範囲を作成"
    bl_description = "画像ビューでブラシと編集操作を制限する選択範囲を作成します"
    bl_options = set()

    shape: EnumProperty(items=SHAPE_ITEMS, default="RECT", options={"SKIP_SAVE"})
    mode: EnumProperty(items=MODE_ITEMS, default="REPLACE", options={"SKIP_SAVE"})
    feather: FloatProperty(default=0.0, min=0.0, max=512.0, options={"SKIP_SAVE"})
    use_coordinates: BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    x0: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    y0: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    x1: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    y1: IntProperty(default=0, options={"HIDDEN", "SKIP_SAVE"})
    points_json: StringProperty(default="", options={"HIDDEN", "SKIP_SAVE"})

    def _target(self, context):
        material = _resolve_material(context)
        image = _operator_canvas(context, material)
        if material is None or image is None:
            return None, None, 0, 0
        return material, image, int(image.size[0]), int(image.size[1])

    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        started = time.perf_counter()
        material, _image, width, height = self._target(context)
        if material is None or width <= 1 or height <= 1:
            self.report({"WARNING"}, _rpt("編集可能なアクティブレイヤーがありません。"))
            return {"CANCELLED"}
        if not bool(self.use_coordinates):
            self.report({"WARNING"}, _rpt("画像ビュー上でドラッグしてください。"))
            return {"CANCELLED"}
        points = []
        if str(self.shape).upper() in {"LASSO", "POLYGON"}:
            try:
                points = [
                    (int(item[0]), int(item[1]))
                    for item in json.loads(str(self.points_json or "[]"))
                    if isinstance(item, (list, tuple)) and len(item) >= 2
                ]
            except Exception:
                points = []
        p0, p1 = (int(self.x0), int(self.y0)), (int(self.x1), int(self.y1))
        if not points:
            points = [p0, p1]
        mask = _shape_mask(self.shape, width, height, p0, p1, points, self.feather)
        ok, info = _combine_mask(material, mask, self.mode)
        elapsed = time.perf_counter() - started
        if elapsed >= 10.0:
            self.report({"ERROR"}, _rpt("選択範囲の作成が遅すぎます ({:.2f}s)。", elapsed))
            return {"CANCELLED"}
        if not ok:
            self.report({"ERROR"}, _rpt_fail("選択範囲をステンシルへ反映できません", info.get("reason", "")))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("選択範囲 {:,} px ({:.2f}s)", int(info.get('pixels', 0)), elapsed))
        return {"FINISHED"}

    def invoke(self, context, event):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        material, _image, width, height = self._target(context)
        if material is None or width <= 1 or height <= 1 or _window_region(context) is None:
            self.report({"WARNING"}, _rpt("画像ビューから選択ツールを開始してください。"))
            return {"CANCELLED"}
        self._material_name = _material_key(material)
        self._width = int(width)
        self._height = int(height)
        self._waiting = True
        self._dragging = False
        self._start = (0, 0)
        self._points = []
        if str(self.shape).upper() == "POLYGON":
            self._waiting = False
        context.window_manager.modal_handler_add(self)
        try:
            context.window.cursor_modal_set("CROSSHAIR")
            if str(self.shape).upper() == "POLYGON":
                context.area.header_text_set(_rpt("クリックで頂点追加。Enter/Space/ダブルクリックで確定。Escで取消"))
            else:
                context.area.header_text_set(_rpt("画像上をドラッグして選択。Escで取消"))
        except Exception:
            pass
        return {"RUNNING_MODAL"}

    def _finish_modal(self, context):
        clear_drag_guide()
        try:
            context.window.cursor_modal_restore()
            context.area.header_text_set(None)
        except Exception:
            pass

    def _commit_polygon(self, context):
        points = list(getattr(self, "_points", ()) or ())
        if len(points) < 3:
            return {"RUNNING_MODAL"}
        material = bpy.data.materials.get(str(getattr(self, "_material_name", "") or ""))
        if material is None:
            self._finish_modal(context)
            return {"CANCELLED"}
        mask = _shape_mask(
            "POLYGON",
            self._width,
            self._height,
            points[0],
            points[-1],
            points,
            self.feather,
        )
        ok, info = _combine_mask(material, mask, self.mode)
        self._finish_modal(context)
        if not ok:
            self.report({"ERROR"}, _rpt_fail("選択範囲を反映できません", info.get("reason", "")))
            return {"CANCELLED"}
        return {"FINISHED"}

    def modal(self, context, event):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            self._finish_modal(context)
            return {"CANCELLED"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._finish_modal(context)
            return {"CANCELLED"}
        if str(self.shape).upper() == "POLYGON":
            if event.type in {"RET", "NUMPAD_ENTER", "SPACE"} and event.value == "PRESS":
                return self._commit_polygon(context)
            if event.type == "MOUSEMOVE" and _inside_image_window(context, event):
                point = _event_image_xy(context, event, self._width, self._height)
                self._current = point
                if self._points:
                    _set_shape_drag_guide(self, point)
                return {"RUNNING_MODAL"}
            if event.type == "LEFTMOUSE" and event.value in {"PRESS", "DOUBLE_CLICK"}:
                if not _inside_image_window(context, event):
                    return {"RUNNING_MODAL"}
                point = _event_image_xy(context, event, self._width, self._height)
                close_to_first = len(self._points) >= 3 and math.dist(point, self._points[0]) <= _POLYGON_CLOSE_RADIUS
                double_click = event.value == "DOUBLE_CLICK" and len(self._points) >= 2
                if close_to_first:
                    return self._commit_polygon(context)
                if not self._points or math.dist(point, self._points[-1]) >= 2.0:
                    self._points.append(point)
                self._current = point
                _set_shape_drag_guide(self, point)
                if double_click and len(self._points) >= 3:
                    return self._commit_polygon(context)
                return {"RUNNING_MODAL"}
            return {"RUNNING_MODAL"}
        if bool(getattr(self, "_waiting", False)):
            if event.type == "LEFTMOUSE" and event.value == "PRESS" and _inside_image_window(context, event):
                self._waiting = False
                self._dragging = True
                self._start = _event_image_xy(context, event, self._width, self._height)
                self._current = self._start
                self._points = [self._start]
                _set_shape_drag_guide(self, self._current)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE" and bool(getattr(self, "_dragging", False)):
            if _inside_image_window(context, event):
                point = _event_image_xy(context, event, self._width, self._height)
                self._current = point
                if str(self.shape).upper() == "LASSO":
                    if not self._points or math.dist(point, self._points[-1]) >= 2.0:
                        self._points.append(point)
                _set_shape_drag_guide(self, point)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE" and bool(getattr(self, "_dragging", False)):
            end = _event_image_xy(context, event, self._width, self._height)
            points = list(self._points) + [end]
            material = bpy.data.materials.get(str(getattr(self, "_material_name", "") or ""))
            if material is None:
                self._finish_modal(context)
                return {"CANCELLED"}
            mask = _shape_mask(
                self.shape,
                self._width,
                self._height,
                self._start,
                end,
                points,
                self.feather,
            )
            ok, info = _combine_mask(material, mask, self.mode)
            self._finish_modal(context)
            if not ok:
                self.report({"ERROR"}, _rpt_fail("選択範囲を反映できません", info.get("reason", "")))
                return {"CANCELLED"}
            return {"FINISHED"}
        return {"RUNNING_MODAL"}


class SPS_OT_lightweight_selection_all(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_selection_all"
    bl_label = "すべて選択"
    bl_description = "アクティブテクスチャ全体を選択します"
    bl_options = set()

    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        import numpy as np

        material = _resolve_material(context)
        image = _operator_canvas(context, material)
        if material is None or image is None:
            return {"CANCELLED"}
        width, height = int(image.size[0]), int(image.size[1])
        ok, _info = _combine_mask(material, np.ones((height, width), dtype=np.float32), "REPLACE")
        return {"FINISHED"} if ok else {"CANCELLED"}


class SPS_OT_lightweight_selection_invert(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_selection_invert"
    bl_label = "選択範囲を反転"
    bl_description = "選択範囲と非選択範囲を反転します"
    bl_options = set()

    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        import numpy as np

        material = _resolve_material(context)
        image = _operator_canvas(context, material)
        if material is None or image is None:
            return {"CANCELLED"}
        current = mask_array(material, int(image.size[0]), int(image.size[1]))
        if current is None:
            current = np.zeros((int(image.size[1]), int(image.size[0])), dtype=np.float32)
        ok, _info = _combine_mask(material, np.float32(1.0) - current, "REPLACE")
        return {"FINISHED"} if ok else {"CANCELLED"}


class SPS_OT_lightweight_selection_clear(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_selection_clear"
    bl_label = "選択を解除"
    bl_description = "選択範囲を解除し、ブラシと編集操作をレイヤー全体へ戻します"
    bl_options = set()

    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            return {"CANCELLED"}
        clear(material)
        return {"FINISHED"}


class SPS_OT_lightweight_selection_alpha(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_selection_alpha"
    bl_label = "不透明部分を選択"
    bl_description = "アクティブレイヤーのアルファ値から選択範囲を作成します"
    bl_options = set()

    threshold: FloatProperty(default=0.0039, min=0.0, max=1.0, options={"SKIP_SAVE"})
    mode: EnumProperty(items=MODE_ITEMS, default="REPLACE", options={"SKIP_SAVE"})

    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        import numpy as np

        started = time.perf_counter()
        material = _resolve_material(context)
        image = _operator_canvas(context, material)
        if material is None or image is None:
            return {"CANCELLED"}
        width, height = int(image.size[0]), int(image.size[1])
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        alpha = flat.reshape((height, width, 4))[:, :, 3]
        mask = (alpha >= float(self.threshold)).astype(np.float32)
        ok, info = _combine_mask(material, mask, self.mode)
        elapsed = time.perf_counter() - started
        if elapsed >= 10.0:
            self.report({"ERROR"}, _rpt("アルファ選択が遅すぎます ({:.2f}s)。", elapsed))
            return {"CANCELLED"}
        if not ok:
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("不透明部分 {:,} pxを選択", int(info.get('pixels', 0))))
        return {"FINISHED"}


def draw_toolbar(layout, context, material, *, show_header: bool = True) -> None:
    settings = getattr(material, "smart_paint_suite", None)
    if settings is None:
        return
    state = summary(material)
    bbox = state.get("bbox") if state.get("active") else None
    if show_header:
        layout.separator()
        header = layout.row(align=True)
        header.label(text="選択範囲", icon="RESTRICT_SELECT_OFF")
        if state.get("active"):
            header.label(text=f"{int(state.get('pixels', 0)):,} px", icon="CHECKMARK")
            if bbox:
                header.label(text=f"{bbox[2] - bbox[0]} x {bbox[3] - bbox[1]}", translate=False)
    elif state.get("active"):
        status = layout.row(align=True)
        status.label(text=f"{int(state.get('pixels', 0)):,} px", icon="CHECKMARK")
        if bbox:
            status.label(text=f"{bbox[2] - bbox[0]} x {bbox[3] - bbox[1]}", translate=False)
    mode = layout.row(align=True)
    mode.prop(settings, "selection_mode", expand=True)
    tools = layout.row(align=True)
    for shape, icon in (("RECT", "SELECT_SET"), ("ELLIPSE", "MESH_CIRCLE"), ("LASSO", "MOD_MASK"), ("POLYGON", "MOD_TRIANGULATE")):
        op = tools.operator(
            SPS_OT_lightweight_selection_shape.bl_idname,
            text="",
            icon=icon,
        )
        op.shape = shape
        op.mode = str(getattr(settings, "selection_mode", "REPLACE") or "REPLACE")
        op.feather = float(getattr(settings, "selection_feather", 0.0) or 0.0)
    tools.separator()
    tools.operator(SPS_OT_lightweight_selection_all.bl_idname, text="", icon="CHECKBOX_HLT")
    alpha = tools.operator(SPS_OT_lightweight_selection_alpha.bl_idname, text="", icon="IMAGE_ALPHA")
    alpha.mode = str(getattr(settings, "selection_mode", "REPLACE") or "REPLACE")
    tools.operator(SPS_OT_lightweight_selection_invert.bl_idname, text="", icon="ARROW_LEFTRIGHT")
    tools.operator(SPS_OT_lightweight_selection_clear.bl_idname, text="", icon="X")
    layout.prop(settings, "selection_feather", text="ぼかし")


CLASSES = (
    SPS_OT_lightweight_mask_paint_refresh,
    SPS_OT_lightweight_selection_paint,
    SPS_OT_lightweight_selection_shape,
    SPS_OT_lightweight_selection_all,
    SPS_OT_lightweight_selection_invert,
    SPS_OT_lightweight_selection_clear,
    SPS_OT_lightweight_selection_alpha,
)
