# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Flat image document I/O for the lightweight Smart Paint workflow.

This module deliberately owns only operation-boundary work. It registers no
handlers or timers, and never leaves a file-backed Blender Image as a paint
canvas. PSD/PSB routing remains in the native layered document path.
"""

from __future__ import annotations

import hashlib
import os
import struct
import time
import uuid
from pathlib import Path
from typing import Any

import bpy


PSD_EXTENSIONS = frozenset({".psd", ".pdd"})
PSB_EXTENSIONS = frozenset({".psb"})
LAYERED_EXTENSIONS = PSD_EXTENSIONS | PSB_EXTENSIONS

# Blender can decode more formats than it can encode. Generic open always asks
# Blender itself; this table is only the set of still-image encoders exposed by
# Image.file_format in supported Blender builds.
FORMAT_BY_EXTENSION = {
    ".avif": "AVIF",
    ".bmp": "BMP",
    ".bw": "IRIS",
    ".cin": "CINEON",
    ".dpx": "DPX",
    ".exr": "OPEN_EXR",
    ".hdr": "HDR",
    ".j2c": "JPEG2000",
    ".jp2": "JPEG2000",
    ".jpeg": "JPEG",
    ".jpg": "JPEG",
    ".png": "PNG",
    ".rgb": "IRIS",
    ".rgba": "IRIS",
    ".sgi": "IRIS",
    ".tga": "TARGA",
    ".tif": "TIFF",
    ".tiff": "TIFF",
    ".webp": "WEBP",
}

# Blender 5.1 writes BMP as 32-bit BGRA and preserves alpha. Only formats
# whose Blender encoders actually discard alpha receive the explicit white matte.
ALPHALESS_FORMATS = frozenset({"CINEON", "DPX", "HDR", "JPEG"})
FALLBACK_ENCODER_BY_EXTENSION = {
    ".avif": "OPENIMAGEIO_AVIF",
    ".dds": "PILLOW_DDS",
    ".j2c": "PILLOW_JPEG2000",
    ".jp2": "PILLOW_JPEG2000",
    ".tx": "OPENIMAGEIO_TX",
    ".webp": "PILLOW_WEBP_LOSSLESS",
}


def layered_extension_matches_signature(path: str | Path, signature: str) -> bool:
    extension = Path(path).suffix.lower()
    if str(signature or "").upper() == "PSB":
        return extension in PSB_EXTENSIONS
    if str(signature or "").upper() == "PSD":
        return extension in PSD_EXTENSIONS
    return False


def image_filter_glob() -> str:
    extensions = set()
    try:
        extensions.update(str(value).lower() for value in bpy.path.extensions_image)
    except Exception:
        extensions.update(FORMAT_BY_EXTENSION)
    extensions.update(LAYERED_EXTENSIONS)
    return ";".join(f"*{value}" for value in sorted(extensions) if value.startswith("."))


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def pixels_sha256(pixels_u8) -> str:
    try:
        import numpy as np

        pixels = np.ascontiguousarray(np.asarray(pixels_u8, dtype=np.uint8))
        return hashlib.sha256(pixels.tobytes()).hexdigest().upper()
    except Exception:
        return ""


def sniff_layered_signature(path: str | Path) -> str:
    try:
        with Path(path).open("rb") as handle:
            header = handle.read(8)
        if len(header) >= 6 and header[:4] == b"8BPS":
            version = struct.unpack_from(">H", header, 4)[0]
            if version == 1:
                return "PSD"
            if version == 2:
                return "PSB"
            return "8BPS"
    except Exception:
        pass
    return ""


def has_photoshop_layer_tiff_tag(path: str | Path) -> bool:
    """Return True when a classic TIFF IFD exposes Photoshop ImageSourceData."""
    try:
        source = Path(path)
        file_size = int(source.stat().st_size)
        with source.open("rb") as handle:
            header = handle.read(16)
            if len(header) < 8:
                return False
            if header[:2] == b"II":
                endian = "<"
            elif header[:2] == b"MM":
                endian = ">"
            else:
                return False
            magic = struct.unpack_from(endian + "H", header, 2)[0]
            if magic == 43:
                # BigTIFF is protected conservatively because its offsets are 64-bit.
                return True
            if magic != 42:
                return False
            ifd = struct.unpack_from(endian + "I", header, 4)[0]
            visited = set()
            while ifd and ifd not in visited and len(visited) < 32:
                if ifd < 8 or ifd + 2 > file_size:
                    return False
                visited.add(ifd)
                handle.seek(ifd)
                count_data = handle.read(2)
                if len(count_data) != 2:
                    return False
                count = int(struct.unpack(endian + "H", count_data)[0])
                # A normal TIFF has tens of tags. Bound corrupt input before
                # allocating or reading an attacker-sized IFD table.
                if count > 4096:
                    return False
                table_size = count * 12 + 4
                if ifd + 2 + table_size > file_size:
                    return False
                table = handle.read(table_size)
                if len(table) != table_size:
                    return False
                for index in range(count):
                    tag = struct.unpack_from(endian + "H", table, index * 12)[0]
                    if tag == 37724:
                        return True
                ifd = struct.unpack_from(endian + "I", table, count * 12)[0]
            return False
    except Exception:
        return False


def load_flat_pixels(path: str | Path) -> dict[str, Any]:
    """Decode one still image through Blender and return encoded-domain RGBA8."""
    started = time.perf_counter()
    source = Path(path).resolve()
    if not source.is_file():
        return {"ok": False, "reason": "image_missing", "path": str(source)}
    layered = sniff_layered_signature(source)
    if layered:
        return {
            "ok": False,
            "reason": "layered_signature_requires_native_path",
            "path": str(source),
            "signature": layered,
        }
    image = None
    try:
        import numpy as np

        image = bpy.data.images.load(str(source), check_existing=False)
        source_kind = str(getattr(image, "source", "") or "")
        if source_kind not in {"FILE", "GENERATED"}:
            return {
                "ok": False,
                "reason": "image_source_not_still",
                "path": str(source),
                "source": source_kind,
            }
        width, height = int(image.size[0]), int(image.size[1])
        if width <= 0 or height <= 0:
            return {"ok": False, "reason": "image_size_invalid", "path": str(source)}
        try:
            image.alpha_mode = "STRAIGHT"
        except Exception:
            pass
        source_colorspace = ""
        try:
            source_colorspace = str(image.colorspace_settings.name or "")
            # Read stored encoded samples without the source color transform.
            image.colorspace_settings.name = "Non-Color"
        except Exception:
            pass
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        pixels = np.ascontiguousarray(
            np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        detected_format = FORMAT_BY_EXTENSION.get(source.suffix.lower(), "")
        if not detected_format:
            detected_format = {
                ".dds": "DDS",
                ".tx": "TX",
            }.get(source.suffix.lower(), "")
        if not detected_format:
            detected_format = str(getattr(image, "file_format", "") or "")
        depth = int(getattr(image, "depth", 0) or 0)
        return {
            "ok": True,
            "reason": "flat_image_decoded",
            "path": str(source),
            "width": width,
            "height": height,
            "pixels": pixels,
            "format": detected_format,
            "depth": depth,
            "source_colorspace": source_colorspace,
            "photoshop_layer_tiff": bool(
                source.suffix.lower() in {".tif", ".tiff"}
                and has_photoshop_layer_tiff_tag(source)
            ),
            "file_sha256": file_sha256(source),
            "pixel_sha256": pixels_sha256(pixels),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except Exception as exc:
        return {
            "ok": False,
            "reason": "corrupt_or_unsupported_image",
            "path": str(source),
            "error": repr(exc)[:512],
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    finally:
        if image is not None:
            try:
                bpy.data.images.remove(image, do_unlink=True)
            except Exception:
                pass


def _resolved_write_format(path: Path, preferred_format: str = "") -> str:
    extension_format = FORMAT_BY_EXTENSION.get(path.suffix.lower(), "")
    if extension_format:
        return extension_format
    # Never place bytes for one codec under an unrelated read-only extension
    # (for example PNG bytes in a .dds file). Preferred format is only valid
    # when the destination has no extension and the caller supplies one.
    return str(preferred_format or "").upper() if not path.suffix else ""


def _enable_optional_user_site() -> None:
    """Expose optional binary codecs only when an operation requests them."""
    try:
        import site

        paths = site.getusersitepackages()
        if isinstance(paths, str):
            paths = [paths]
        for path in list(paths or []):
            if path and Path(path).is_dir():
                site.addsitedir(str(path))
    except Exception:
        pass


def _write_fallback_pixels(path: Path, pixels_u8, encoder: str) -> None:
    import numpy as np

    _enable_optional_user_site()
    top_pixels = np.ascontiguousarray(np.asarray(pixels_u8, dtype=np.uint8)[::-1, :, :])
    if encoder == "PILLOW_DDS":
        from PIL import Image

        Image.fromarray(top_pixels, "RGBA").save(str(path), format="DDS")
        return
    if encoder == "PILLOW_JPEG2000":
        from PIL import Image

        Image.fromarray(top_pixels, "RGBA").save(
            str(path),
            format="JPEG2000",
            irreversible=False,
            no_jp2=path.suffix.lower() == ".j2c",
        )
        return
    if encoder == "PILLOW_WEBP_LOSSLESS":
        from PIL import Image

        Image.fromarray(top_pixels, "RGBA").save(
            str(path),
            format="WEBP",
            lossless=True,
            quality=70,
            method=0,
        )
        return
    if encoder in {"OPENIMAGEIO_AVIF", "OPENIMAGEIO_TX"}:
        import OpenImageIO as oiio

        height, width = int(top_pixels.shape[0]), int(top_pixels.shape[1])
        output = oiio.ImageOutput.create(str(path))
        if output is None:
            raise RuntimeError(str(oiio.geterror() or "OpenImageIO writer unavailable"))
        opened = False
        try:
            spec = oiio.ImageSpec(width, height, 4, oiio.UINT8)
            spec.attribute("oiio:UnassociatedAlpha", 1)
            if encoder == "OPENIMAGEIO_AVIF":
                spec.attribute("compression", "avif:100")
            opened = bool(output.open(str(path), spec))
            if not opened or not bool(output.write_image(top_pixels)):
                raise RuntimeError(str(oiio.geterror() or "OpenImageIO write failed"))
        finally:
            closed = bool(output.close())
        if not closed:
            raise RuntimeError(str(oiio.geterror() or "OpenImageIO TX close failed"))
        return
    raise RuntimeError(f"Unsupported fallback encoder: {encoder}")


def _white_matte_encoded(pixels_u8):
    import numpy as np

    pixels = np.ascontiguousarray(np.asarray(pixels_u8, dtype=np.uint8))
    output = pixels.copy()
    alpha = pixels[:, :, 3].astype(np.uint16)
    inverse = 255 - alpha
    for channel in range(3):
        source = pixels[:, :, channel].astype(np.uint16)
        output[:, :, channel] = ((source * alpha + 255 * inverse + 127) // 255).astype(np.uint8)
    output[:, :, 3] = 255
    return output


def write_flat_pixels_atomic(
    path: str | Path,
    pixels_u8,
    *,
    preferred_format: str = "",
) -> dict[str, Any]:
    """Encode a current composite with Blender, then atomically replace target."""
    started = time.perf_counter()
    destination = Path(path).resolve()
    image = None
    tmp_path = destination.with_name(
        f".{destination.stem}.sps-{uuid.uuid4().hex[:8]}{destination.suffix}"
    )
    try:
        import numpy as np

        pixels = np.ascontiguousarray(np.asarray(pixels_u8, dtype=np.uint8))
        if pixels.ndim != 3 or int(pixels.shape[2]) != 4:
            return {"ok": False, "reason": "composite_shape_invalid", "path": str(destination)}
        height, width = int(pixels.shape[0]), int(pixels.shape[1])
        if width <= 0 or height <= 0:
            return {"ok": False, "reason": "composite_size_invalid", "path": str(destination)}
        file_format = _resolved_write_format(destination, preferred_format)
        fallback_encoder = FALLBACK_ENCODER_BY_EXTENSION.get(destination.suffix.lower(), "")
        if not file_format and not fallback_encoder:
            return {
                "ok": False,
                "reason": "format_read_only_or_unknown",
                "path": str(destination),
                "extension": destination.suffix.lower(),
            }
        encode_pixels = _white_matte_encoded(pixels) if file_format in ALPHALESS_FORMATS else pixels
        destination.parent.mkdir(parents=True, exist_ok=True)
        used_encoder = file_format
        if fallback_encoder:
            try:
                _write_fallback_pixels(tmp_path, encode_pixels, fallback_encoder)
                used_encoder = fallback_encoder
            except Exception:
                if not file_format:
                    raise
                try:
                    if tmp_path.is_file():
                        tmp_path.unlink()
                except Exception:
                    pass
                fallback_encoder = ""
        if not fallback_encoder:
            image = bpy.data.images.new(
                name=f"SPS_FlatSave_{uuid.uuid4().hex[:10]}",
                width=width,
                height=height,
                alpha=True,
                float_buffer=file_format in {"HDR", "OPEN_EXR"},
            )
            image.generated_color = (0.0, 0.0, 0.0, 0.0)
            image.alpha_mode = "STRAIGHT"
            try:
                image.colorspace_settings.name = "Non-Color"
            except Exception:
                pass
            float_pixels = np.empty(encode_pixels.shape, dtype=np.float32)
            np.multiply(encode_pixels, np.float32(1.0 / 255.0), out=float_pixels, casting="unsafe")
            image.pixels.foreach_set(float_pixels.reshape((-1,)))
            image.update()
            try:
                image.file_format = file_format
            except Exception as exc:
                return {
                    "ok": False,
                    "reason": "format_encoder_unavailable",
                    "path": str(destination),
                    "format": file_format,
                    "error": repr(exc)[:300],
                }
            image.filepath_raw = str(tmp_path)
            image.save()
        if not tmp_path.is_file() or tmp_path.stat().st_size <= 0:
            return {
                "ok": False,
                "reason": "flat_encoder_produced_no_file",
                "path": str(destination),
                "format": file_format or fallback_encoder,
            }
        os.replace(str(tmp_path), str(destination))
        return {
            "ok": True,
            "reason": "flat_image_saved",
            "path": str(destination),
            "format": file_format or used_encoder,
            "encoder": used_encoder,
            "width": width,
            "height": height,
            "pixel_sha256": pixels_sha256(pixels),
            "file_sha256": file_sha256(destination),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except PermissionError as exc:
        recovery = destination.with_name(
            f"{destination.stem}_SPS_recovery_{int(time.time())}{destination.suffix}"
        )
        try:
            if tmp_path.is_file():
                os.replace(str(tmp_path), str(recovery))
        except Exception:
            recovery = Path("")
        return {
            "ok": False,
            "reason": "destination_locked",
            "path": str(destination),
            "recovery_path": str(recovery) if str(recovery) else "",
            "error": repr(exc)[:300],
        }
    except Exception as exc:
        return {
            "ok": False,
            "reason": "flat_save_exception",
            "path": str(destination),
            "error": repr(exc)[:512],
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    finally:
        if image is not None:
            try:
                bpy.data.images.remove(image, do_unlink=True)
            except Exception:
                pass
        try:
            if tmp_path.is_file():
                tmp_path.unlink()
        except Exception:
            pass


def _additional_block(key: bytes, payload: bytes) -> bytes:
    block = b"8BIM" + bytes(key[:4]).ljust(4, b" ") + struct.pack(">I", len(payload)) + payload
    if len(payload) % 2:
        block += b"\x00"
    return block


def _layer_name_extra(name: str, layer_id: int) -> bytes:
    encoded = str(name or "Layer").encode("macroman", errors="replace")[:255]
    pascal = bytes([len(encoded)]) + encoded
    pascal += b"\x00" * ((4 - (len(pascal) % 4)) % 4)
    unicode_name = str(name or "Layer").encode("utf-16-be", errors="replace")
    luni = struct.pack(">I", len(unicode_name) // 2) + unicode_name
    return (
        struct.pack(">I", 0)
        + struct.pack(">I", 0)
        + pascal
        + _additional_block(b"luni", luni)
        + _additional_block(b"lyid", struct.pack(">I", max(1, int(layer_id))))
    )


def write_minimal_psd_template(
    path: str | Path,
    layer_pixels_u8,
    merged_pixels_u8,
    *,
    layer_name: str,
    layer_id: int,
) -> dict[str, Any]:
    """Write one valid 8-bit PSD-v1 record used to bootstrap flat promotion."""
    started = time.perf_counter()
    destination = Path(path).resolve()
    try:
        import numpy as np

        layer = np.ascontiguousarray(np.asarray(layer_pixels_u8, dtype=np.uint8))
        merged = np.ascontiguousarray(np.asarray(merged_pixels_u8, dtype=np.uint8))
        if layer.ndim != 3 or merged.ndim != 3 or layer.shape != merged.shape or int(layer.shape[2]) != 4:
            return {"ok": False, "reason": "psd_template_shape_invalid", "path": str(destination)}
        height, width = int(layer.shape[0]), int(layer.shape[1])
        if width <= 0 or height <= 0 or width > 30000 or height > 30000:
            return {"ok": False, "reason": "psd_template_size_unsupported", "path": str(destination)}
        top_layer = layer[::-1, :, :]
        top_merged = merged[::-1, :, :]
        layer_planes = [bytes(top_layer[:, :, channel].tobytes()) for channel in (0, 1, 2, 3)]
        main_planes = [bytes(top_merged[:, :, channel].tobytes()) for channel in (0, 1, 2, 3)]
        compression = "RAW"
        try:
            _enable_optional_user_site()
            from psd_tools.compression import encode_rle

            channel_payloads = [
                b"\x00\x01" + encode_rle(plane, width, height, 8, 1)
                for plane in layer_planes
            ]
            main_payload = b"\x00\x01" + encode_rle(
                b"".join(main_planes),
                width,
                height * 4,
                8,
                1,
            )
            compression = "RLE"
        except (ImportError, RuntimeError, ValueError, OverflowError):
            channel_payloads = [b"\x00\x00" + plane for plane in layer_planes]
            main_payload = b"\x00\x00" + b"".join(main_planes)
        record = bytearray()
        record.extend(struct.pack(">iiiiH", 0, 0, height, width, 4))
        for channel_id, payload in zip((0, 1, 2, -1), channel_payloads):
            record.extend(struct.pack(">hI", channel_id, len(payload)))
        record.extend(b"8BIMnorm" + bytes([255, 0, 0, 0]))
        extra = _layer_name_extra(layer_name, layer_id)
        record.extend(struct.pack(">I", len(extra)))
        record.extend(extra)
        layer_info = struct.pack(">h", -1) + bytes(record) + b"".join(channel_payloads)
        if len(layer_info) % 2:
            layer_info += b"\x00"
        layer_mask = struct.pack(">I", len(layer_info)) + layer_info + struct.pack(">I", 0)
        header = (
            b"8BPS"
            + struct.pack(">H", 1)
            + b"\x00" * 6
            + struct.pack(">HIIHH", 4, height, width, 8, 3)
        )
        payload = (
            header
            + struct.pack(">I", 0)
            + struct.pack(">I", 0)
            + struct.pack(">I", len(layer_mask))
            + layer_mask
            + main_payload
        )
        destination.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = destination.with_name(f".{destination.stem}.template-{uuid.uuid4().hex[:8]}.psd")
        try:
            tmp_path.write_bytes(payload)
            os.replace(str(tmp_path), str(destination))
        finally:
            try:
                if tmp_path.is_file():
                    tmp_path.unlink()
            except Exception:
                pass
        return {
            "ok": True,
            "reason": "psd_template_written",
            "path": str(destination),
            "width": width,
            "height": height,
            "bytes": len(payload),
            "compression": compression,
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except Exception as exc:
        return {
            "ok": False,
            "reason": "psd_template_exception",
            "path": str(destination),
            "error": repr(exc)[:512],
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }


def write_minimal_psb_template(
    path: str | Path,
    layer_pixels_u8,
    merged_pixels_u8,
    *,
    layer_name: str,
    layer_id: int,
) -> dict[str, Any]:
    """Write one valid PSB-v2 record used to bootstrap flat promotion."""
    started = time.perf_counter()
    destination = Path(path).resolve()
    tmp_path = destination.with_name(
        f".{destination.stem}.template-{uuid.uuid4().hex[:8]}.psb"
    )
    try:
        import numpy as np
        _enable_optional_user_site()
        from PIL import Image
        from psd_tools import PSDImage
        from psd_tools.api.layers import PixelLayer
        from psd_tools.constants import Compression

        layer = np.ascontiguousarray(np.asarray(layer_pixels_u8, dtype=np.uint8))
        merged = np.ascontiguousarray(np.asarray(merged_pixels_u8, dtype=np.uint8))
        if (
            layer.ndim != 3
            or merged.ndim != 3
            or layer.shape != merged.shape
            or int(layer.shape[2]) != 4
        ):
            return {"ok": False, "reason": "psb_template_shape_invalid", "path": str(destination)}
        height, width = int(layer.shape[0]), int(layer.shape[1])
        if width <= 0 or height <= 0 or width > 300000 or height > 300000:
            return {"ok": False, "reason": "psb_template_size_unsupported", "path": str(destination)}

        # Smart Paint canvases are bottom-up; PIL and layered-file records are top-down.
        top_layer = np.ascontiguousarray(layer[::-1, :, :])
        top_merged = np.ascontiguousarray(merged[::-1, :, :])
        document = PSDImage.new("RGBA", (width, height), color=(0, 0, 0, 0))
        document._record.header.version = 2
        pixel_layer = PixelLayer.frompil(
            Image.fromarray(top_layer, "RGBA"),
            document,
            name=str(layer_name or "Layer"),
            compression=Compression.RLE,
        )
        try:
            pixel_layer._record.tagged_blocks.set_data(
                b"lyid",
                max(1, int(layer_id)),
            )
        except Exception:
            pass
        document._record.image_data.compression = Compression.RLE
        document._record.image_data.set_data(
            [bytes(top_merged[:, :, channel].tobytes()) for channel in range(4)],
            document._record.header,
        )
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tmp_path.open("wb") as handle:
            document._record.write(handle)
        os.replace(str(tmp_path), str(destination))
        return {
            "ok": True,
            "reason": "psb_template_written",
            "path": str(destination),
            "width": width,
            "height": height,
            "bytes": int(destination.stat().st_size),
            "compression": "RLE",
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    except ImportError as exc:
        return {
            "ok": False,
            "reason": "psb_template_dependency_missing",
            "path": str(destination),
            "error": repr(exc)[:512],
        }
    except Exception as exc:
        return {
            "ok": False,
            "reason": "psb_template_exception",
            "path": str(destination),
            "error": repr(exc)[:512],
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    finally:
        try:
            if tmp_path.is_file():
                tmp_path.unlink()
        except Exception:
            pass
