# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Explicit external-document validation and master refresh adapter."""
from __future__ import annotations


def validate_and_refresh_master(material, channel: str = "BASE_COLOR", *, reason: str = "save", write_master: bool = False) -> bool:
    del reason
    from . import bodypaint_core
    if not bodypaint_core.ensure_source_psd_stack_loaded(material, channel):
        return False
    if write_master:
        return bodypaint_core.write_composite_to_master(material, channel, force=True) is not None
    return bodypaint_core.ensure_layer_stack_display_matches(
        material, channel, None,
        commit_pending=False,
        switch_to_paint=False,
        force_recompose=False,
        commit_untracked=False,
    ) is not None


__all__ = ("validate_and_refresh_master",)
