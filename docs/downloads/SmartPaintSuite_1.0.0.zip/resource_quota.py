# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Strict shared memory and managed-disk quotas for Smart Paint Suite.

Every retained pixel/document cache shares one count limit and one *actual
retained-byte* budget.  A payload is data-only: Blender RNA/ID/Image values,
modules, classes, callables and object arrays are rejected.  Array buffers are
accounted once across cache namespaces, so two metadata entries referring to the
same pixel allocation do not pretend to consume two allocations and no array is
copied merely to enter the cache.

Bridge files live below owner/schema/document/session manifests.  Deletion is
allowed only when the complete manifest row (owner, runtime generation,
document key, session generation, process lease UUID, SHA-256 and native file
identity) matches.  Links and Windows reparse points are always rejected.
"""
from __future__ import annotations

from collections import OrderedDict
from collections.abc import Iterator, MutableMapping
from contextlib import contextmanager
from functools import wraps
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import shutil
import threading
import time
import types
import uuid
from typing import Any, Iterable

SUITE_OWNER = "JELararagi:smart_paint_suite"
SUITE_OWNER_UUID = "a57946f8-8f20-4e88-b304-6d6fc0e3ee7a"
MANIFEST_SCHEMA = 4
OWNER_FILE = ".sps_managed_root.json"
CLEANUP_LEDGER_FILE = ".sps_cleanup_ledger.json"

# One shared budget replaces the historical 256+512+1152+768+256 MiB limits.
GLOBAL_MEMORY_CACHE_COUNT = 32
GLOBAL_MEMORY_CACHE_BYTES = 192 * 1024 * 1024
GLOBAL_MEMORY_CACHE_MAX_ITEM_BYTES = 72 * 1024 * 1024
MEMORY_PRESSURE_FREE_BYTES = 768 * 1024 * 1024

SESSION_COUNT_LIMIT = 4
SESSION_FILE_LIMIT = 192
SESSION_BYTE_LIMIT = 384 * 1024 * 1024
SESSION_TTL_SECONDS = 12 * 60 * 60
SESSION_HEARTBEAT_LEASE_SECONDS = 12 * 60 * 60
PENDING_COUNT_LIMIT = 24
PENDING_BYTE_LIMIT = 96 * 1024 * 1024
RESULT_COUNT_LIMIT = 16
RESULT_BYTE_LIMIT = 128 * 1024 * 1024
TEMP_COUNT_LIMIT = 24
TEMP_BYTE_LIMIT = 128 * 1024 * 1024
CACHE_COUNT_LIMIT = 16
CACHE_BYTE_LIMIT = 64 * 1024 * 1024
IMAGE_COUNT_LIMIT = 12
IMAGE_BYTE_LIMIT = 128 * 1024 * 1024
LOG_FILE_BYTES = 1024 * 1024
LOG_BACKUPS = 4

_LOCK = threading.RLock()
_MEMORY: "OrderedDict[tuple[str, Any], _CacheEntry]" = OrderedDict()
_MEMORY_BYTES = 0
_BUFFER_REFS: dict[tuple[Any, ...], int] = {}
_BUFFER_SIZES: dict[tuple[Any, ...], int] = {}
_CACHE_LEASES: dict[str, str] = {}
_SESSION_LRU: "OrderedDict[str, tuple[int, int]]" = OrderedDict()
_OPERATION_LOCAL = threading.local()


class CachePolicyError(ValueError):
    """A value is not eligible for the Suite-wide data-only cache."""


@dataclass
class _CacheEntry:
    value: Any
    logical_bytes: int
    metadata_bytes: int
    buffers: tuple[tuple[tuple[Any, ...], int], ...]
    lease: str
    owner_uuid: str
    document_generation: str
    created: float
    last_used: float


# ---------------------------------------------------------------------------
# Data-only validation and real retained-byte accounting
# ---------------------------------------------------------------------------
def _is_rna_like(value: Any) -> bool:
    if value is None or isinstance(value, (bool, int, float, str, bytes, bytearray, memoryview)):
        return False
    if isinstance(value, (types.ModuleType, type)) or callable(value):
        return True
    value_type = type(value)
    module_name = str(getattr(value_type, "__module__", "") or "")
    if module_name == "bpy" or module_name.startswith(("bpy_", "bpy.")):
        return True
    return any(hasattr(value, attr) for attr in ("bl_rna", "id_data", "as_pointer"))


def _normalized_key(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str, bytes)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, tuple):
        return tuple(_normalized_key(item) for item in value)
    if isinstance(value, list):
        return tuple(_normalized_key(item) for item in value)
    raise CachePolicyError(f"cache_key_not_data_only:{type(value).__name__}")


def _array_root(value: Any) -> Any:
    root = value
    seen: set[int] = set()
    while True:
        identity = id(root)
        if identity in seen:
            return root
        seen.add(identity)
        base = getattr(root, "base", None)
        if base is None or base is root:
            return root
        root = base


def _array_account(value: Any) -> tuple[tuple[Any, ...], int] | None:
    nbytes = getattr(value, "nbytes", None)
    dtype = getattr(value, "dtype", None)
    if nbytes is None or dtype is None:
        return None
    try:
        if bool(getattr(dtype, "hasobject", False)):
            raise CachePolicyError("object_array_not_allowed")
        root = _array_root(value)
        root_nbytes = max(0, int(getattr(root, "nbytes", nbytes)))
        interface = getattr(root, "__array_interface__", {}) or {}
        data = interface.get("data", (0, False))
        address = int(data[0] or 0) if isinstance(data, (tuple, list)) and data else 0
        token = ("array", id(root), address, root_nbytes)
        return token, root_nbytes
    except (TypeError, ValueError, OverflowError, AttributeError) as exc:
        raise CachePolicyError("invalid_array_buffer") from exc


def _buffer_account(value: Any) -> tuple[tuple[Any, ...], int] | None:
    array = _array_account(value)
    if array is not None:
        return array
    if isinstance(value, bytes):
        return ("bytes", id(value), len(value)), len(value)
    if isinstance(value, bytearray):
        return ("bytearray", id(value), len(value)), len(value)
    if isinstance(value, memoryview):
        root = value.obj if value.obj is not None else value
        return ("memoryview", id(root), int(value.nbytes)), int(value.nbytes)
    return None


def _payload_account(value: Any) -> tuple[int, dict[tuple[Any, ...], int]]:
    """Return metadata bytes and unique buffer tokens for one payload."""
    seen: set[int] = set()
    buffers: dict[tuple[Any, ...], int] = {}

    def walk(item: Any) -> int:
        if item is None:
            return 0
        if _is_rna_like(item):
            raise CachePolicyError(f"cache_value_not_data_only:{type(item).__name__}")
        if isinstance(item, bool):
            return 1
        if isinstance(item, int):
            return 8
        if isinstance(item, float):
            return 8
        if isinstance(item, str):
            return len(item.encode("utf-8"))
        buffer = _buffer_account(item)
        if buffer is not None:
            token, size = buffer
            buffers[token] = max(int(size), int(buffers.get(token, 0)))
            return 0
        identity = id(item)
        if identity in seen:
            return 0
        seen.add(identity)
        if isinstance(item, dict):
            total = 0
            for key, child in item.items():
                _normalized_key(key)
                total += walk(key)
                total += walk(child)
            return total
        if isinstance(item, (tuple, list, set, frozenset)):
            return sum(walk(child) for child in item)
        try:
            view = memoryview(item)
        except TypeError as exc:
            raise CachePolicyError(f"unsupported_cache_value:{type(item).__name__}") from exc
        if view.format == "O":
            raise CachePolicyError("object_buffer_not_allowed")
        root = view.obj if view.obj is not None else item
        token = ("buffer", id(root), int(view.nbytes))
        buffers[token] = max(int(view.nbytes), int(buffers.get(token, 0)))
        return 0

    metadata = int(walk(value))
    return metadata, buffers


def data_byte_size(value: Any, *, _seen: set[int] | None = None) -> int:
    """Logical payload size, validating the same data-only contract.

    ``_seen`` is accepted for compatibility with older callers; accounting is
    local to this invocation and shared buffer identity is handled globally by
    the cache itself.
    """
    del _seen
    metadata, buffers = _payload_account(value)
    return int(metadata + sum(buffers.values()))


def _infer_document_generation(key: Any, value: Any) -> str:
    """Infer a stable data-only document generation without retaining RNA.

    Cache callers created before the shared quota API often use ``cache[key] =
    value``.  This helper extracts an existing generation/document identity from
    their data-only key/metadata so every retained entry still carries the
    required document-generation field.  It never inspects Blender objects.
    """
    preferred = (
        "document_generation", "generation", "document_key",
        "session_generation", "source_generation",
    )

    def inspect(item: Any, depth: int = 0) -> str:
        if depth > 4 or item is None:
            return ""
        if isinstance(item, str):
            return item if item and len(item) <= 512 else ""
        if isinstance(item, dict):
            for name in preferred:
                candidate = item.get(name)
                if isinstance(candidate, (str, int)) and str(candidate):
                    return str(candidate)[:512]
            for child in item.values():
                result = inspect(child, depth + 1)
                if result:
                    return result
            return ""
        if isinstance(item, (tuple, list)):
            # Prefer explicit string tokens over numeric dimensions/indices.
            for child in item:
                if isinstance(child, str) and child and len(child) <= 512:
                    return child
            for child in item:
                result = inspect(child, depth + 1)
                if result:
                    return result
        return ""

    return inspect(value) or inspect(key) or "global"


def _available_memory_bytes() -> int:
    if os.name == "nt":
        try:
            import ctypes

            class _MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = (
                    ("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                )

            status = _MEMORYSTATUSEX()
            status.dwLength = ctypes.sizeof(status)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return max(0, int(status.ullAvailPhys))
        except (AttributeError, OSError, TypeError, ValueError):
            pass
    try:
        return max(0, int(os.sysconf("SC_PAGE_SIZE")) * int(os.sysconf("SC_AVPHYS_PAGES")))
    except (AttributeError, OSError, ValueError):
        return 2 * 1024 * 1024 * 1024


def _remove_accounting_locked(entry: _CacheEntry) -> None:
    global _MEMORY_BYTES
    _MEMORY_BYTES = max(0, _MEMORY_BYTES - int(entry.metadata_bytes))
    for token, size in entry.buffers:
        count = int(_BUFFER_REFS.get(token, 0)) - 1
        if count <= 0:
            _BUFFER_REFS.pop(token, None)
            retained = int(_BUFFER_SIZES.pop(token, size))
            _MEMORY_BYTES = max(0, _MEMORY_BYTES - retained)
        else:
            _BUFFER_REFS[token] = count


def _add_accounting_locked(entry: _CacheEntry) -> None:
    global _MEMORY_BYTES
    _MEMORY_BYTES += int(entry.metadata_bytes)
    for token, size in entry.buffers:
        count = int(_BUFFER_REFS.get(token, 0))
        if count <= 0:
            _BUFFER_SIZES[token] = int(size)
            _MEMORY_BYTES += int(size)
        _BUFFER_REFS[token] = count + 1


def _evict_locked() -> None:
    while _MEMORY and (len(_MEMORY) > GLOBAL_MEMORY_CACHE_COUNT or _MEMORY_BYTES > GLOBAL_MEMORY_CACHE_BYTES):
        _key, entry = _MEMORY.popitem(last=False)
        _remove_accounting_locked(entry)


def clear_for_memory_pressure() -> bool:
    if _available_memory_bytes() >= MEMORY_PRESSURE_FREE_BYTES:
        return False
    clear_all_memory(reason="memory_pressure")
    return True


def _current_operation_lease() -> str:
    stack = getattr(_OPERATION_LOCAL, "stack", ())
    return str(stack[-1]) if stack else ""


def current_operation_lease() -> str:
    """Return the active explicit-operation lease without creating state."""
    return _current_operation_lease()


def end_operation_lease(lease: str) -> int:
    """Release every namespace entry created by one explicit operation."""
    target = str(lease or "")
    if not target:
        return 0
    with _LOCK:
        keys = [key for key, entry in _MEMORY.items() if entry.lease == target]
        for key in keys:
            _remove_accounting_locked(_MEMORY.pop(key))
        return len(keys)


@contextmanager
def operation_cache_scope(label: str = "operation"):
    """Tag temporary cache entries and release them on success/cancel/error."""
    token = f"operation:{str(label or 'operation')}:{uuid.uuid4()}"
    previous = list(getattr(_OPERATION_LOCAL, "stack", ()))
    _OPERATION_LOCAL.stack = [*previous, token]
    try:
        yield token
    finally:
        end_operation_lease(token)
        _OPERATION_LOCAL.stack = previous


def operation_boundary(label: str = "operation"):
    """Decorate an Operator ``execute(self, context)`` method statically.

    Blender validates the *actual code-object arity* during RNA registration;
    ``functools.wraps`` metadata is not sufficient.  Keep the wrapper's native
    signature at exactly two positional arguments instead of using
    ``*args, **kwargs``.  The decorator is intentionally limited to execute
    methods and is applied while the class is defined, never after registration.
    """
    def decorate(function):
        @wraps(function)
        def wrapped(self, context):
            with operation_cache_scope(label or getattr(function, "__qualname__", "operation")):
                return function(self, context)
        return wrapped
    return decorate


def cache_put(
    cache_name: str,
    key: Any,
    value: Any,
    *,
    lease: str = "",
    owner_uuid: str = SUITE_OWNER_UUID,
    document_generation: str = "",
) -> bool:
    """Retain a payload by reference; no pixel/array copy is made."""
    namespace = str(cache_name or "default")
    normalized = _normalized_key(key)
    if str(owner_uuid or "") != SUITE_OWNER_UUID:
        raise CachePolicyError("cache_owner_uuid_mismatch")
    metadata, buffer_map = _payload_account(value)
    logical = int(metadata + sum(buffer_map.values()))
    if logical > GLOBAL_MEMORY_CACHE_MAX_ITEM_BYTES:
        return False
    if clear_for_memory_pressure() and logical > GLOBAL_MEMORY_CACHE_BYTES // 8:
        return False
    composite = (namespace, normalized)
    now = time.monotonic()
    entry = _CacheEntry(
        value=value,
        logical_bytes=logical,
        metadata_bytes=int(metadata),
        buffers=tuple(sorted(buffer_map.items(), key=lambda item: repr(item[0]))),
        lease=str(lease or _current_operation_lease() or _CACHE_LEASES.get(namespace, "") or ""),
        owner_uuid=SUITE_OWNER_UUID,
        document_generation=str(document_generation or _infer_document_generation(normalized, value)),
        created=now,
        last_used=now,
    )
    with _LOCK:
        previous = _MEMORY.pop(composite, None)
        if previous is not None:
            _remove_accounting_locked(previous)
        _MEMORY[composite] = entry
        _add_accounting_locked(entry)
        _evict_locked()
        return composite in _MEMORY


def cache_get(cache_name: str, key: Any, default: Any = None) -> Any:
    composite = (str(cache_name or "default"), _normalized_key(key))
    with _LOCK:
        entry = _MEMORY.pop(composite, None)
        if entry is None:
            return default
        entry.last_used = time.monotonic()
        _MEMORY[composite] = entry
        return entry.value


def cache_reaccount(cache_name: str, key: Any) -> bool:
    """Recompute bytes after in-place metadata-container mutation."""
    namespace = str(cache_name or "default")
    composite = (namespace, _normalized_key(key))
    with _LOCK:
        previous = _MEMORY.get(composite)
        if previous is None:
            return False
        value = previous.value
        lease = previous.lease
        owner_uuid = previous.owner_uuid
        document_generation = previous.document_generation
    retained = cache_put(
        namespace, key, value, lease=lease, owner_uuid=owner_uuid,
        document_generation=document_generation,
    )
    # Recounting bytes must not change who owns the entry: an empty lease means
    # "outlives every operation", not "belongs to the operation running now".
    with _LOCK:
        current = _MEMORY.get(composite)
        if current is not None:
            current.lease = lease
    return retained


def cache_pop(cache_name: str, key: Any, default: Any = None) -> Any:
    composite = (str(cache_name or "default"), _normalized_key(key))
    with _LOCK:
        entry = _MEMORY.pop(composite, None)
        if entry is None:
            return default
        _remove_accounting_locked(entry)
        return entry.value


def cache_contains(cache_name: str, key: Any) -> bool:
    composite = (str(cache_name or "default"), _normalized_key(key))
    with _LOCK:
        return composite in _MEMORY


def cache_keys(cache_name: str) -> tuple[Any, ...]:
    namespace = str(cache_name or "default")
    with _LOCK:
        return tuple(key[1] for key in _MEMORY if key[0] == namespace)


def clear_cache(cache_name: str) -> int:
    namespace = str(cache_name or "default")
    with _LOCK:
        keys = [key for key in _MEMORY if key[0] == namespace]
        for key in keys:
            _remove_accounting_locked(_MEMORY.pop(key))
        _CACHE_LEASES.pop(namespace, None)
        return len(keys)


def clear_document_generation(document_generation: str, *, owner_uuid: str = SUITE_OWNER_UUID) -> int:
    target = str(document_generation or "")
    with _LOCK:
        keys = [
            key for key, entry in _MEMORY.items()
            if entry.owner_uuid == str(owner_uuid) and entry.document_generation == target
        ]
        for key in keys:
            _remove_accounting_locked(_MEMORY.pop(key))
        return len(keys)


def begin_cache_lease(cache_name: str, lease: str) -> str:
    namespace = str(cache_name or "default")
    lease_id = str(lease or f"lease:{uuid.uuid4()}")
    with _LOCK:
        _CACHE_LEASES[namespace] = lease_id
    return lease_id


def end_cache_lease(cache_name: str, lease: str = "") -> int:
    namespace = str(cache_name or "default")
    with _LOCK:
        expected = str(lease or _CACHE_LEASES.get(namespace, "") or "")
        keys = [
            key for key, entry in _MEMORY.items()
            if key[0] == namespace and (not expected or entry.lease == expected)
        ]
        for key in keys:
            _remove_accounting_locked(_MEMORY.pop(key))
        if not lease or _CACHE_LEASES.get(namespace) == lease:
            _CACHE_LEASES.pop(namespace, None)
        return len(keys)


def clear_all_memory(*, reason: str = "") -> int:
    del reason
    global _MEMORY_BYTES
    with _LOCK:
        count = len(_MEMORY)
        _MEMORY.clear()
        _CACHE_LEASES.clear()
        _BUFFER_REFS.clear()
        _BUFFER_SIZES.clear()
        _MEMORY_BYTES = 0
        return count


def memory_stats() -> dict[str, Any]:
    with _LOCK:
        per_cache: dict[str, dict[str, int]] = {}
        generations: dict[str, int] = {}
        for (namespace, _key), entry in _MEMORY.items():
            row = per_cache.setdefault(namespace, {"entries": 0, "logical_bytes": 0})
            row["entries"] += 1
            row["logical_bytes"] += int(entry.logical_bytes)
            if entry.document_generation:
                generations[entry.document_generation] = generations.get(entry.document_generation, 0) + 1
        return {
            "entries": len(_MEMORY),
            "retained_bytes": int(_MEMORY_BYTES),
            "bytes": int(_MEMORY_BYTES),
            "logical_bytes": int(sum(entry.logical_bytes for entry in _MEMORY.values())),
            "unique_buffers": len(_BUFFER_REFS),
            "entry_limit": GLOBAL_MEMORY_CACHE_COUNT,
            "byte_limit": GLOBAL_MEMORY_CACHE_BYTES,
            "max_item_bytes": GLOBAL_MEMORY_CACHE_MAX_ITEM_BYTES,
            "owner_uuid": SUITE_OWNER_UUID,
            "document_generations": generations,
            "per_cache": per_cache,
        }


def memory_entry_snapshot() -> tuple[dict[str, Any], ...]:
    """Return data-only cache metadata for audits and diagnostics."""
    with _LOCK:
        return tuple(
            {
                "cache": namespace,
                "key": repr(key)[:512],
                "logical_bytes": int(entry.logical_bytes),
                "metadata_bytes": int(entry.metadata_bytes),
                "buffer_count": len(entry.buffers),
                "lease": str(entry.lease),
                "owner_uuid": str(entry.owner_uuid),
                "document_generation": str(entry.document_generation),
                "created": float(entry.created),
                "last_used": float(entry.last_used),
            }
            for (namespace, key), entry in _MEMORY.items()
        )


class SharedDataCache(MutableMapping):
    """Dict-compatible namespace backed by the shared count+byte LRU."""
    __slots__ = ("name",)

    def __init__(self, name: str):
        self.name = str(name)

    def __getitem__(self, key):
        sentinel = object()
        value = cache_get(self.name, key, sentinel)
        if value is sentinel:
            raise KeyError(key)
        return value

    def __setitem__(self, key, value) -> None:
        # Cache retention is optional.  Oversized 4K/8K payloads remain local to
        # the explicit operation instead of aborting otherwise valid work.
        cache_put(self.name, key, value, document_generation="")

    def put(
        self,
        key,
        value,
        *,
        lease: str = "",
        document_generation: str = "",
        owner_uuid: str = SUITE_OWNER_UUID,
    ) -> bool:
        return cache_put(
            self.name,
            key,
            value,
            lease=lease,
            document_generation=document_generation,
            owner_uuid=owner_uuid,
        )

    def __delitem__(self, key) -> None:
        sentinel = object()
        if cache_pop(self.name, key, sentinel) is sentinel:
            raise KeyError(key)

    def __iter__(self) -> Iterator[Any]:
        return iter(cache_keys(self.name))

    def __len__(self) -> int:
        return len(cache_keys(self.name))

    def get(self, key, default=None):
        return cache_get(self.name, key, default)

    def pop(self, key, default=...):
        sentinel = object()
        result = cache_pop(self.name, key, sentinel)
        if result is sentinel:
            if default is ...:
                raise KeyError(key)
            return default
        return result

    def clear(self) -> None:
        clear_cache(self.name)

    def reaccount(self, key) -> bool:
        return cache_reaccount(self.name, key)


def cache(name: str) -> SharedDataCache:
    return SharedDataCache(str(name))


# ---------------------------------------------------------------------------
# Managed disk roots, process leases and quotas
# ---------------------------------------------------------------------------
def _is_reparse_or_symlink(path: Path) -> bool:
    try:
        if path.is_symlink():
            return True
        stat = path.stat(follow_symlinks=False)
        return bool(int(getattr(stat, "st_file_attributes", 0) or 0) & 0x400)
    except OSError:
        return True


def _safe_size(path: Path) -> int:
    try:
        if _is_reparse_or_symlink(path):
            return 0
        if path.is_file():
            return int(path.stat(follow_symlinks=False).st_size)
        total = 0
        for child in path.rglob("*"):
            if child.is_file() and not _is_reparse_or_symlink(child):
                total += int(child.stat(follow_symlinks=False).st_size)
        return total
    except (OSError, ValueError):
        return 0


def _safe_file_count(path: Path) -> int:
    try:
        if not path.is_dir() or _is_reparse_or_symlink(path):
            return 0
        return sum(1 for child in path.rglob("*") if child.is_file() and not _is_reparse_or_symlink(child))
    except OSError:
        return 0


def file_identity(path: Path) -> dict[str, Any]:
    if _is_reparse_or_symlink(path):
        raise OSError("file_identity_reparse_rejected")
    stat = path.stat(follow_symlinks=False)
    return {
        "device": int(getattr(stat, "st_dev", 0) or 0),
        "inode": int(getattr(stat, "st_ino", 0) or 0),
        "size": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
    }


def file_sha256(path: Path, *, chunk_size: int = 1024 * 1024) -> str:
    if _is_reparse_or_symlink(path):
        raise OSError("file_hash_reparse_rejected")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(max(4096, int(chunk_size)))
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _fsync_directory(path: Path) -> None:
    if os.name == "nt":
        return
    try:
        fd = os.open(str(path), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if _is_reparse_or_symlink(path) and path.exists():
        raise OSError("atomic_json_reparse_rejected")
    temp = path.with_name(path.name + f".{os.getpid()}.{time.monotonic_ns()}.tmp")
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode("utf-8") + b"\n"
    try:
        with temp.open("xb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        _fsync_directory(path.parent)
        if path.read_bytes() != encoded:
            raise OSError("atomic_json_readback_mismatch")
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def process_creation_time(pid: int) -> str:
    """Stable process-start identity used to distinguish PID reuse."""
    value = int(pid)
    if value <= 0:
        return ""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, value)
            if not handle:
                return ""
            try:
                creation = wintypes.FILETIME(); exit_time = wintypes.FILETIME()
                kernel = wintypes.FILETIME(); user = wintypes.FILETIME()
                if not ctypes.windll.kernel32.GetProcessTimes(
                    handle, ctypes.byref(creation), ctypes.byref(exit_time),
                    ctypes.byref(kernel), ctypes.byref(user),
                ):
                    return ""
                ticks = (int(creation.dwHighDateTime) << 32) | int(creation.dwLowDateTime)
                return f"win:{ticks}"
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        except (AttributeError, OSError, TypeError, ValueError):
            return ""
    proc = Path(f"/proc/{value}/stat")
    try:
        text = proc.read_text(encoding="utf-8")
        close = text.rfind(")")
        fields = text[close + 2:].split()
        # /proc/<pid>/stat field 22; fields starts at original field 3.
        return f"proc:{fields[19]}"
    except (OSError, UnicodeError, IndexError, ValueError):
        return ""


def process_lease_identity(*, lease_uuid: str = "") -> dict[str, Any]:
    pid = int(os.getpid())
    creation = process_creation_time(pid)
    if not creation:
        creation = f"local:{pid}:{time.time_ns()}"
    now = time.time()
    return {
        "schema": 1,
        "owner_uuid": SUITE_OWNER_UUID,
        "pid": pid,
        "process_creation_time": creation,
        "uuid": str(lease_uuid or uuid.uuid4()),
        "active": True,
        "created_at": now,
        "last_event_at": now,
        "heartbeat_deadline": now + SESSION_HEARTBEAT_LEASE_SECONDS,
    }


def _valid_process_lease(lease: Any) -> bool:
    return bool(
        isinstance(lease, dict)
        and int(lease.get("schema", -1)) == 1
        and str(lease.get("owner_uuid", "")) == SUITE_OWNER_UUID
        and int(lease.get("pid", 0) or 0) > 0
        and str(lease.get("process_creation_time", ""))
        and str(lease.get("uuid", ""))
    )


def session_lease_active(manifest_or_path: dict[str, Any] | Path, *, now: float | None = None) -> bool:
    manifest = read_managed_manifest(manifest_or_path) if isinstance(manifest_or_path, Path) else manifest_or_path
    if not isinstance(manifest, dict):
        return False
    lease = manifest.get("process_lease")
    if not _valid_process_lease(lease) or not bool(lease.get("active", False)):
        return False
    current = time.time() if now is None else float(now)
    if float(lease.get("heartbeat_deadline", 0.0) or 0.0) <= current:
        return False
    pid = int(lease.get("pid", 0) or 0)
    return process_creation_time(pid) == str(lease.get("process_creation_time", ""))


def mark_session(
    path: Path,
    *,
    generation: str,
    document_key: str,
    session_generation: str = "",
    process_lease: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if path.exists() and _is_reparse_or_symlink(path):
        raise OSError("managed_root_reparse_rejected")
    path.mkdir(parents=True, exist_ok=True)
    lease = dict(process_lease or process_lease_identity())
    if not _valid_process_lease(lease):
        raise OSError("managed_process_lease_invalid")
    payload = {
        "schema": MANIFEST_SCHEMA,
        "owner": SUITE_OWNER,
        "owner_uuid": SUITE_OWNER_UUID,
        "generation": str(generation),
        "session_generation": str(session_generation or generation),
        "document_key": str(document_key),
        "process_lease": lease,
        "created_at": time.time(),
        "updated_at": time.time(),
        "files": {},
    }
    _atomic_json(path / OWNER_FILE, payload)
    return payload


def read_managed_manifest(path: Path) -> dict[str, Any] | None:
    root = Path(path)
    owner = root / OWNER_FILE
    if _is_reparse_or_symlink(root) or _is_reparse_or_symlink(owner):
        return None
    try:
        payload = json.loads(owner.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict):
        return None
    if (
        payload.get("owner") != SUITE_OWNER
        or payload.get("owner_uuid") != SUITE_OWNER_UUID
        or int(payload.get("schema", -1)) != MANIFEST_SCHEMA
        or not payload.get("generation")
        or not payload.get("session_generation")
        or not payload.get("document_key")
        or not _valid_process_lease(payload.get("process_lease"))
        or not isinstance(payload.get("files", {}), dict)
    ):
        return None
    return payload


def renew_session_lease(path: Path, *, lease_uuid: str, event_time: float | None = None) -> bool:
    manifest = read_managed_manifest(Path(path))
    if manifest is None:
        return False
    lease = dict(manifest.get("process_lease", {}) or {})
    if (
        str(lease.get("uuid", "")) != str(lease_uuid or "")
        or int(lease.get("pid", 0) or 0) != os.getpid()
        or str(lease.get("process_creation_time", "")) != process_creation_time(os.getpid())
    ):
        return False
    now = time.time() if event_time is None else float(event_time)
    lease["active"] = True
    lease["last_event_at"] = now
    lease["heartbeat_deadline"] = now + SESSION_HEARTBEAT_LEASE_SECONDS
    manifest["process_lease"] = lease
    manifest["updated_at"] = now
    _atomic_json(Path(path) / OWNER_FILE, manifest)
    return True


def release_session_lease(path: Path, *, lease_uuid: str) -> bool:
    manifest = read_managed_manifest(Path(path))
    if manifest is None:
        return False
    lease = dict(manifest.get("process_lease", {}) or {})
    if (
        str(lease.get("uuid", "")) != str(lease_uuid or "")
        or int(lease.get("pid", 0) or 0) != os.getpid()
        or str(lease.get("process_creation_time", "")) != process_creation_time(os.getpid())
    ):
        return False
    now = time.time()
    lease["active"] = False
    lease["released_at"] = now
    lease["heartbeat_deadline"] = now
    manifest["process_lease"] = lease
    manifest["updated_at"] = now
    _atomic_json(Path(path) / OWNER_FILE, manifest)
    return True


def register_managed_file(root: Path, file_path: Path, *, document_key: str, session_generation: str) -> dict[str, Any]:
    root = Path(root); file_path = Path(file_path)
    manifest = read_managed_manifest(root)
    if manifest is None:
        raise OSError("managed_root_manifest_invalid")
    if str(manifest.get("document_key")) != str(document_key):
        raise OSError("managed_document_mismatch")
    if str(manifest.get("session_generation")) != str(session_generation):
        raise OSError("managed_session_generation_mismatch")
    root_resolved = root.resolve(strict=True)
    candidate = file_path.resolve(strict=True)
    if _is_reparse_or_symlink(file_path) or root_resolved not in candidate.parents:
        raise OSError("managed_file_escape_or_reparse")
    relative = candidate.relative_to(root_resolved).as_posix()
    lease = dict(manifest.get("process_lease", {}) or {})
    row = {
        "owner": SUITE_OWNER,
        "owner_uuid": SUITE_OWNER_UUID,
        "schema": MANIFEST_SCHEMA,
        "generation": str(manifest.get("generation", "")),
        "document_key": str(document_key),
        "session_generation": str(session_generation),
        "process_lease_uuid": str(lease.get("uuid", "")),
        "sha256": file_sha256(candidate),
        "identity": file_identity(candidate),
    }
    files = dict(manifest.get("files", {}) or {})
    files[relative] = row
    manifest["files"] = files
    manifest["updated_at"] = time.time()
    _atomic_json(root / OWNER_FILE, manifest)
    return row


def _manifest_row_matches(root: Path, manifest: dict[str, Any], path: Path) -> bool:
    try:
        root_resolved = root.resolve(strict=True)
        candidate = path.resolve(strict=True)
        if _is_reparse_or_symlink(path) or root_resolved not in candidate.parents or not candidate.is_file():
            return False
        relative = candidate.relative_to(root_resolved).as_posix()
        row = dict((manifest.get("files", {}) or {}).get(relative, {}) or {})
        lease = dict(manifest.get("process_lease", {}) or {})
        return bool(
            row.get("owner") == SUITE_OWNER
            and row.get("owner_uuid") == SUITE_OWNER_UUID
            and int(row.get("schema", -1)) == MANIFEST_SCHEMA
            and str(row.get("generation", "")) == str(manifest.get("generation", ""))
            and str(row.get("document_key", "")) == str(manifest.get("document_key", ""))
            and str(row.get("session_generation", "")) == str(manifest.get("session_generation", ""))
            and str(row.get("process_lease_uuid", "")) == str(lease.get("uuid", ""))
            and str(row.get("sha256", "")) == file_sha256(candidate)
            and dict(row.get("identity", {}) or {}) == file_identity(candidate)
        )
    except (OSError, ValueError, TypeError):
        return False


def managed_file_matches(
    root: Path,
    file_path: Path,
    *,
    document_key: str,
    session_generation: str,
    process_lease_uuid: str = "",
    generation: str = "",
    expected_sha256: str = "",
    expected_identity: dict[str, Any] | None = None,
) -> bool:
    """Verify the complete managed-file identity without mutating the manifest."""
    root = Path(root)
    file_path = Path(file_path)
    manifest = read_managed_manifest(root)
    if manifest is None:
        return False
    if str(manifest.get("document_key", "")) != str(document_key):
        return False
    if str(manifest.get("session_generation", "")) != str(session_generation):
        return False
    if generation and str(manifest.get("generation", "")) != str(generation):
        return False
    lease = dict(manifest.get("process_lease", {}) or {})
    if process_lease_uuid and str(lease.get("uuid", "")) != str(process_lease_uuid):
        return False
    if not _manifest_row_matches(root, manifest, file_path):
        return False
    try:
        relative = file_path.resolve(strict=True).relative_to(root.resolve(strict=True)).as_posix()
        row = dict((manifest.get("files", {}) or {}).get(relative, {}) or {})
        if expected_sha256 and str(row.get("sha256", "")) != str(expected_sha256):
            return False
        if expected_identity is not None and dict(row.get("identity", {}) or {}) != dict(expected_identity):
            return False
        return True
    except (OSError, ValueError, TypeError):
        return False


def remove_managed_file(root: Path, file_path: Path, *, document_key: str, session_generation: str) -> bool:
    root = Path(root); file_path = Path(file_path)
    manifest = read_managed_manifest(root)
    if manifest is None:
        return False
    if str(manifest.get("document_key")) != str(document_key) or str(manifest.get("session_generation")) != str(session_generation):
        return False
    if not _manifest_row_matches(root, manifest, file_path):
        return False
    candidate = file_path.resolve(strict=True)
    relative = candidate.relative_to(root.resolve(strict=True)).as_posix()
    candidate.unlink()
    files = dict(manifest.get("files", {}) or {})
    files.pop(relative, None)
    manifest["files"] = files
    manifest["updated_at"] = time.time()
    _atomic_json(root / OWNER_FILE, manifest)
    return True


def _owned_session(path: Path) -> bool:
    return read_managed_manifest(path) is not None


def touch_session(path: Path) -> None:
    key = str(Path(path).resolve())
    value = (_safe_size(Path(path)), _safe_file_count(Path(path)))
    with _LOCK:
        _SESSION_LRU.pop(key, None)
        _SESSION_LRU[key] = value
        while len(_SESSION_LRU) > SESSION_COUNT_LIMIT * 4:
            _SESSION_LRU.popitem(last=False)


def _files_oldest_first(root: Path) -> list[Path]:
    if not root.is_dir() or _is_reparse_or_symlink(root):
        return []
    values = [
        path for path in root.rglob("*")
        if path.is_file() and path.name != OWNER_FILE and not _is_reparse_or_symlink(path)
    ]
    values.sort(key=lambda path: (path.stat(follow_symlinks=False).st_mtime_ns, str(path)))
    return values


def _managed_root_for(path: Path) -> tuple[Path, dict[str, Any]] | None:
    candidate = path.resolve() if path.exists() else path.absolute()
    for root in (candidate, *candidate.parents):
        manifest = read_managed_manifest(root)
        if manifest is not None:
            return root, manifest
        if len(root.parts) < 2:
            break
    return None


def _remove_exact_manifest_file(path: Path) -> bool:
    found = _managed_root_for(path.parent)
    if found is None:
        return False
    root, manifest = found
    return remove_managed_file(
        root, path,
        document_key=str(manifest.get("document_key", "")),
        session_generation=str(manifest.get("session_generation", "")),
    )


def _managed_tree_exact(root: Path) -> bool:
    manifest = read_managed_manifest(root)
    if manifest is None or _is_reparse_or_symlink(root):
        return False
    expected = dict(manifest.get("files", {}) or {})
    actual: set[str] = set()
    try:
        resolved = root.resolve(strict=True)
        for path in root.rglob("*"):
            if _is_reparse_or_symlink(path):
                return False
            if path.is_file() and path.name != OWNER_FILE:
                relative = path.resolve(strict=True).relative_to(resolved).as_posix()
                if not _manifest_row_matches(root, manifest, path):
                    return False
                actual.add(relative)
        return actual == set(expected)
    except (OSError, ValueError):
        return False


def enforce_directory(root: Path, *, count_limit: int, byte_limit: int, preserve: Iterable[Path] = ()) -> dict[str, int]:
    preserve_set = {str(Path(path).resolve()) for path in preserve if path is not None and Path(path).exists()}
    files = _files_oldest_first(Path(root))
    total = sum(_safe_size(path) for path in files)
    remaining_count = len(files)
    removed = removed_bytes = 0
    for path in files:
        if remaining_count <= int(count_limit) and total - removed_bytes <= int(byte_limit):
            break
        try:
            if str(path.resolve()) in preserve_set:
                continue
            size = _safe_size(path)
            if not _remove_exact_manifest_file(path):
                continue
            removed += 1; remaining_count -= 1; removed_bytes += size
        except OSError:
            continue
    return {
        "removed": removed, "removed_bytes": removed_bytes,
        "remaining": max(0, remaining_count), "remaining_bytes": max(0, total - removed_bytes),
    }


def _cleanup_ledger_payload(root: Path, sessions: list[Path]) -> dict[str, Any]:
    rows = []
    for path in sessions:
        manifest_path = path / OWNER_FILE
        manifest = read_managed_manifest(path)
        if manifest is None:
            continue
        try:
            rows.append({
                "path": str(path.resolve(strict=True)),
                "owner": str(manifest.get("owner", "")),
                "owner_uuid": str(manifest.get("owner_uuid", "")),
                "schema": int(manifest.get("schema", -1)),
                "generation": str(manifest.get("generation", "")),
                "document_key": str(manifest.get("document_key", "")),
                "session_generation": str(manifest.get("session_generation", "")),
                "process_lease_uuid": str((manifest.get("process_lease", {}) or {}).get("uuid", "")),
                "manifest_sha256": file_sha256(manifest_path),
                "manifest_identity": file_identity(manifest_path),
            })
        except OSError:
            continue
    return {
        "schema": 2,
        "owner": SUITE_OWNER,
        "owner_uuid": SUITE_OWNER_UUID,
        "root": str(root.resolve(strict=True)),
        "created_at": time.time(),
        "sessions": rows,
    }


def _cleanup_ledger_row_matches(row: dict[str, Any], path: Path) -> bool:
    manifest = read_managed_manifest(path)
    if manifest is None:
        return False
    manifest_path = path / OWNER_FILE
    lease = dict(manifest.get("process_lease", {}) or {})
    try:
        return bool(
            str(path.resolve(strict=True)) == str(row.get("path", ""))
            and str(row.get("owner", "")) == SUITE_OWNER
            and str(row.get("owner_uuid", "")) == SUITE_OWNER_UUID
            and int(row.get("schema", -1)) == MANIFEST_SCHEMA
            and str(row.get("generation", "")) == str(manifest.get("generation", ""))
            and str(row.get("document_key", "")) == str(manifest.get("document_key", ""))
            and str(row.get("session_generation", "")) == str(manifest.get("session_generation", ""))
            and str(row.get("process_lease_uuid", "")) == str(lease.get("uuid", ""))
            and str(row.get("manifest_sha256", "")) == file_sha256(manifest_path)
            and dict(row.get("manifest_identity", {}) or {}) == file_identity(manifest_path)
        )
    except (OSError, ValueError, TypeError):
        return False


def _discover_owned_sessions(root: Path) -> list[Path]:
    """Return exact managed session roots anywhere below the shared bridge root.

    Discovery is manifest based, never name/mtime based.  Both the shared root
    and every ancestor from a candidate session back to that root are resolved
    and checked without following links/reparse points.  This prevents a
    relative-root comparison from walking above the managed tree and prevents a
    junction from redirecting quota cleanup into foreign data.
    """
    result: dict[str, Path] = {}
    try:
        root = Path(root)
        if not root.is_dir() or _is_reparse_or_symlink(root):
            return []
        root_resolved = root.resolve(strict=True)
        owners = tuple(root_resolved.rglob(OWNER_FILE))
    except OSError:
        return []
    for owner_file in owners:
        session = owner_file.parent
        try:
            if _is_reparse_or_symlink(owner_file) or _is_reparse_or_symlink(session):
                continue
            resolved = session.resolve(strict=True)
            if resolved == root_resolved or root_resolved not in resolved.parents:
                continue
            cursor = resolved
            unsafe = False
            while cursor != root_resolved:
                if _is_reparse_or_symlink(cursor):
                    unsafe = True
                    break
                parent = cursor.parent
                if parent == cursor:
                    unsafe = True
                    break
                cursor = parent
            if unsafe or not _owned_session(resolved):
                continue
            result[str(resolved)] = resolved
        except (OSError, ValueError):
            continue
    return list(result.values())


def enforce_session_root(root: Path, *, active_session: Path | None = None) -> dict[str, int]:
    root = Path(root)
    if not root.is_dir() or _is_reparse_or_symlink(root):
        return {"removed": 0, "removed_bytes": 0, "removed_files": 0}
    sessions = _discover_owned_sessions(root)
    sessions.sort(key=lambda path: float((read_managed_manifest(path) or {}).get("updated_at", 0.0)))
    total_bytes = sum(_safe_size(path) for path in sessions)
    total_files = sum(_safe_file_count(path) for path in sessions)
    active_key = str(active_session.resolve()) if active_session is not None and active_session.exists() else ""
    now = time.time()
    candidates: list[Path] = []
    remain_count = len(sessions)
    remain_bytes = total_bytes
    remain_files = total_files
    for path in sessions:
        over = (
            remain_count > SESSION_COUNT_LIMIT
            or remain_bytes > SESSION_BYTE_LIMIT
            or remain_files > SESSION_FILE_LIMIT
        )
        manifest = read_managed_manifest(path)
        if manifest is None:
            continue
        if active_key and str(path.resolve()) == active_key:
            continue
        if session_lease_active(manifest, now=now):
            # Never touch another live Blender process/session, even under
            # pressure.  The caller receives the still-over-budget counters.
            continue
        age = now - float(manifest.get("updated_at", manifest.get("created_at", now)) or now)
        if not over and age < SESSION_TTL_SECONDS:
            continue
        if _managed_tree_exact(path):
            candidates.append(path)
            remain_count -= 1
            remain_bytes -= _safe_size(path)
            remain_files -= _safe_file_count(path)
    if not candidates:
        return {
            "removed": 0,
            "removed_bytes": 0,
            "removed_files": 0,
            "remaining": len(sessions),
            "remaining_bytes": total_bytes,
            "remaining_files": total_files,
        }
    ledger_path = root / CLEANUP_LEDGER_FILE
    payload = _cleanup_ledger_payload(root, candidates)
    _atomic_json(ledger_path, payload)
    verified = json.loads(ledger_path.read_text(encoding="utf-8"))
    rows = {
        str(row.get("path", "")): dict(row)
        for row in verified.get("sessions", ())
        if isinstance(row, dict)
    }
    removed = removed_bytes = removed_files = 0
    try:
        for path in candidates:
            try:
                key = str(path.resolve(strict=True))
            except OSError:
                continue
            row = rows.get(key)
            manifest = read_managed_manifest(path)
            if (
                row is None
                or manifest is None
                or session_lease_active(manifest)
                or not _managed_tree_exact(path)
                or not _cleanup_ledger_row_matches(row, path)
            ):
                continue
            size = _safe_size(path)
            file_count = _safe_file_count(path)
            shutil.rmtree(path)
            removed += 1
            removed_bytes += size
            removed_files += file_count
            # Remove only now-empty document-hash directories inside the managed
            # root.  No foreign file or non-empty directory is touched.
            parent = path.parent
            try:
                if parent != root and parent.parent == root and not any(parent.iterdir()):
                    parent.rmdir()
            except OSError:
                pass
    finally:
        try:
            ledger_path.unlink()
            _fsync_directory(root)
        except FileNotFoundError:
            pass
    return {
        "removed": removed,
        "removed_bytes": removed_bytes,
        "removed_files": removed_files,
        "remaining": max(0, len(sessions) - removed),
        "remaining_bytes": max(0, total_bytes - removed_bytes),
        "remaining_files": max(0, total_files - removed_files),
    }


def _write_managed_bytes(root: Path, manifest: dict[str, Any], path: Path, payload: bytes) -> None:
    if path.exists() and _is_reparse_or_symlink(path):
        raise OSError("managed_log_reparse_rejected")
    path.parent.mkdir(parents=True, exist_ok=True)
    root_resolved = root.resolve(strict=True)
    parent_resolved = path.parent.resolve(strict=True)
    if root_resolved != parent_resolved and root_resolved not in parent_resolved.parents:
        raise OSError("managed_log_escape")
    temp = path.with_name(path.name + f".{os.getpid()}.{time.monotonic_ns()}.tmp")
    try:
        with temp.open("xb") as handle:
            handle.write(payload); handle.flush(); os.fsync(handle.fileno())
        os.replace(temp, path)
        register_managed_file(
            root, path,
            document_key=str(manifest.get("document_key", "")),
            session_generation=str(manifest.get("session_generation", "")),
        )
    finally:
        try:
            temp.unlink()
        except FileNotFoundError:
            pass


def rotate_log(path: Path, *, max_bytes: int = LOG_FILE_BYTES, backups: int = LOG_BACKUPS) -> bool:
    try:
        path = Path(path)
        if not path.is_file() or _is_reparse_or_symlink(path) or path.stat(follow_symlinks=False).st_size <= int(max_bytes):
            return False
        found = _managed_root_for(path.parent)
        if found is None:
            return False
        root, manifest = found
        if not _manifest_row_matches(root, manifest, path):
            return False
        payloads: list[bytes] = [path.read_bytes()]
        sources: list[Path] = [path]
        for index in range(1, max(0, int(backups))):
            candidate = path.with_name(path.name + f".{index}")
            current = read_managed_manifest(root)
            if not candidate.exists() or current is None or not _manifest_row_matches(root, current, candidate):
                break
            payloads.append(candidate.read_bytes()); sources.append(candidate)
        document_key = str(manifest.get("document_key", ""))
        session_generation = str(manifest.get("session_generation", ""))
        for source in reversed(sources):
            remove_managed_file(root, source, document_key=document_key, session_generation=session_generation)
        for index, payload in enumerate(payloads[:max(0, int(backups))], 1):
            current = read_managed_manifest(root)
            if current is None:
                raise OSError("managed_manifest_lost_during_log_rotation")
            _write_managed_bytes(root, current, path.with_name(path.name + f".{index}"), payload)
        return True
    except (OSError, ValueError, TypeError):
        return False


def _remove_managed_session_with_ledger(path: Path) -> bool:
    """Remove one inactive exact session through a read-back cleanup ledger."""
    path = Path(path)
    if not path.is_dir() or not _managed_tree_exact(path):
        return False
    manifest = read_managed_manifest(path)
    if manifest is None or session_lease_active(manifest):
        return False
    bridge_root = path.parent.parent if path.parent != path else path.parent
    try:
        bridge_root_resolved = bridge_root.resolve(strict=True)
        path_resolved = path.resolve(strict=True)
        if bridge_root_resolved not in path_resolved.parents:
            return False
    except OSError:
        return False
    ledger_path = bridge_root / CLEANUP_LEDGER_FILE
    payload = _cleanup_ledger_payload(bridge_root, [path])
    if len(payload.get("sessions", ())) != 1:
        return False
    _atomic_json(ledger_path, payload)
    try:
        verified = json.loads(ledger_path.read_text(encoding="utf-8"))
        row = next(iter(verified.get("sessions", ())), None)
        if not isinstance(row, dict) or not _cleanup_ledger_row_matches(row, path):
            return False
        if session_lease_active(path) or not _managed_tree_exact(path):
            return False
        shutil.rmtree(path)
        parent = path.parent
        try:
            if parent != bridge_root and not any(parent.iterdir()):
                parent.rmdir()
        except OSError:
            pass
        return True
    finally:
        try:
            ledger_path.unlink()
            _fsync_directory(bridge_root)
        except FileNotFoundError:
            pass


def cleanup_session(path: Path, *, remove_session: bool = False) -> dict[str, Any]:
    path = Path(path)
    result: dict[str, Any] = {
        "pending": enforce_directory(path / "pending", count_limit=PENDING_COUNT_LIMIT, byte_limit=PENDING_BYTE_LIMIT),
        "results": enforce_directory(path / "results", count_limit=RESULT_COUNT_LIMIT, byte_limit=RESULT_BYTE_LIMIT),
        "temp": enforce_directory(path / "temp", count_limit=TEMP_COUNT_LIMIT, byte_limit=TEMP_BYTE_LIMIT),
        "cache": enforce_directory(path / "cache", count_limit=CACHE_COUNT_LIMIT, byte_limit=CACHE_BYTE_LIMIT),
        "images": enforce_directory(path / "images", count_limit=IMAGE_COUNT_LIMIT, byte_limit=IMAGE_BYTE_LIMIT),
    }
    logs = path / "logs"
    for log in logs.glob("*.log") if logs.is_dir() else ():
        rotate_log(log)
    manifest = read_managed_manifest(path)
    if (
        remove_session
        and manifest is not None
        and not session_lease_active(manifest)
        and not _is_reparse_or_symlink(path)
        and _managed_tree_exact(path)
    ):
        try:
            result["session_removed"] = _remove_managed_session_with_ledger(path)
        except OSError:
            result["session_removed"] = False
    elif path.exists():
        touch_session(path)
    return result


__all__ = (
    "CACHE_BYTE_LIMIT", "CACHE_COUNT_LIMIT", "CLEANUP_LEDGER_FILE", "CachePolicyError",
    "GLOBAL_MEMORY_CACHE_BYTES", "GLOBAL_MEMORY_CACHE_COUNT", "GLOBAL_MEMORY_CACHE_MAX_ITEM_BYTES",
    "IMAGE_BYTE_LIMIT", "IMAGE_COUNT_LIMIT", "LOG_BACKUPS", "LOG_FILE_BYTES",
    "MANIFEST_SCHEMA", "MEMORY_PRESSURE_FREE_BYTES", "OWNER_FILE", "PENDING_BYTE_LIMIT",
    "PENDING_COUNT_LIMIT", "RESULT_BYTE_LIMIT", "RESULT_COUNT_LIMIT", "SESSION_BYTE_LIMIT",
    "SESSION_COUNT_LIMIT", "SESSION_FILE_LIMIT", "SESSION_HEARTBEAT_LEASE_SECONDS",
    "SESSION_TTL_SECONDS", "SUITE_OWNER", "SUITE_OWNER_UUID", "SharedDataCache",
    "TEMP_BYTE_LIMIT", "TEMP_COUNT_LIMIT", "begin_cache_lease", "cache", "cache_contains",
    "cache_get", "cache_keys", "cache_pop", "cache_put", "cache_reaccount", "cleanup_session",
    "clear_all_memory", "current_operation_lease", "clear_cache", "clear_document_generation", "clear_for_memory_pressure",
    "end_operation_lease",
    "data_byte_size", "end_cache_lease", "enforce_directory", "enforce_session_root",
    "file_identity", "file_sha256", "managed_file_matches", "mark_session",
    "memory_entry_snapshot", "memory_stats", "operation_boundary", "operation_cache_scope", "process_creation_time",
    "process_lease_identity", "read_managed_manifest", "register_managed_file",
    "release_session_lease", "remove_managed_file", "renew_session_lease", "rotate_log",
    "session_lease_active", "touch_session",
)
