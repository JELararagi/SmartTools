# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.

"""Minimal local layered/flat image paint product surface.

This module intentionally registers no keymaps, modal operators, persistent
timers, worker processes, or automatic compositors.  Its sole application handler is a
    bounded ``load_post`` repair that restores the active SPS document once after a
``.blend`` is opened; it never runs during ordinary Blender interaction.
"""


import hashlib
import json
import os
import shutil
import time
import uuid
from pathlib import Path

import re
import bpy
from .constants import report_fail as _rpt_fail, report_fmt as _rpt, report_msg as _rpt_msg
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from .constants import ADJUSTMENT_TYPE_ITEMS as _ALL_ADJUSTMENT_TYPE_ITEMS
from . import manager_rule_api as _manager_rule_api
from . import resource_quota as _resource_quota
from .mvp import adjustments as _mvp_adjustments
from .mvp import image_document_io as _image_io
from .mvp import state as _mvp_state


CHANNEL = "BASE_COLOR"
_ADJUSTMENT_ADD_ITEMS = tuple(
    item for item in _ALL_ADJUSTMENT_TYPE_ITEMS
    if str(item[0]) in set(_mvp_adjustments.SUPPORTED_TYPES)
)
_ACTIVATED_LAYERS = _mvp_state.ACTIVATED_LAYERS
_COMPOSITE_BASE_CACHE = _resource_quota.cache("lightweight.composite_base")
_DOCUMENT_COMPOSITE_CACHE = _resource_quota.cache("lightweight.document_composite")
_REVIEW_SAVE_PAYLOAD_CACHE = _resource_quota.cache("lightweight.review_save_payload")
_FORCED_REVIEW_EDITOR_MODES: dict[int, str] = {}
_FORCED_MATERIAL_VIEW_SHADING: dict[int, str] = {}
_METADATA_BASELINE_KEY = "sps_lightweight_metadata_baseline_BASE_COLOR"
_SOURCE_PATH_KEYS = (
    "sps_texture_path_BASE_COLOR",
    "sps_bodypaint_source_stack_path_BASE_COLOR",
    "sps_source_psd_path_BASE_COLOR",
    "sps_texture_source_path_BASE_COLOR",
    "sps_document_file_path_BASE_COLOR",
)
_SOURCE_PATH_HINT_KEYS = _SOURCE_PATH_KEYS + (
    "sps_new_layer_master_source_path_BASE_COLOR",
    "sps_last_psd_splice_source_BASE_COLOR",
)
_LAYERED_RECOVERY_CACHE = _resource_quota.cache("lightweight.layered_recovery")
_MANUAL_COMPOSITE_NODE = "SPS_LIGHTWEIGHT_MANUAL_COMPOSITE"
_LOAD_POST_RUNNING = False
_SESSION_SOURCE_PATHS: dict[str, str] = {}
_PROPERTY_REFRESH_PENDING: dict[str, float] = {}
_DRAW_BRUSH_UI = None
_DRAW_PALETTE_UI = None
_DRAW_PAINT_PREPARATION = None
_DRAW_IMAGE_UTILITIES = None
_DRAW_PAINT_WORKSPACE = None
_DRAW_IMAGE_EDITOR_OVERLAY = None
_DRAW_SELECTION_TOOLS = None
_DRAW_EDITING_TOOLS = None
_RUNTIME_MVP_MODULES: tuple[object, ...] = ()
_THUMBNAIL_MODULE = None
_LIVE_COMPOSITE_MODULE = None
_IMAGE_FILTER_GLOB = _image_io.image_filter_glob()
_DOCUMENT_KIND_KEY = "sps_lightweight_document_kind"
_DOCUMENT_WIDTH_KEY = "sps_lightweight_document_width"
_DOCUMENT_HEIGHT_KEY = "sps_lightweight_document_height"


def _cache_store(cache, key, value, *, document_generation: str = "global") -> bool:
    """Best-effort data-only cache insert under the shared aggregate budget."""
    try:
        return bool(cache.put(key, value, document_generation=document_generation))
    except (_resource_quota.CachePolicyError, TypeError, ValueError):
        return False


def _bind_explicit_psd_api(psd_module) -> None:
    """Expose PSD callables to the lightweight canvas only from explicit work."""
    try:
        from .mvp import paint_target
        paint_target.configure_psd_api(psd_module)
    except (ImportError, AttributeError, TypeError):
        return


def _trace_lightweight(event: str, *, material=None, **payload) -> None:
    try:
        from . import save_trace

        save_trace.emit(str(event or ""), material=material, channel=CHANNEL, **payload)
    except Exception:
        pass


def _resolve_material(context=None):
    ctx = context or getattr(bpy, "context", None)
    candidates = []
    try:
        candidates.append(getattr(getattr(ctx, "object", None), "active_material", None))
    except Exception:
        pass
    try:
        active = getattr(getattr(ctx, "view_layer", None), "objects", None)
        active = getattr(active, "active", None)
        candidates.append(getattr(active, "active_material", None))
    except Exception:
        pass
    for material in candidates:
        if material is not None:
            return material
    return None


def _settings(material):
    try:
        return getattr(material, "smart_paint_suite", None)
    except Exception:
        return None


def _source_path(material) -> str:
    if material is None:
        return ""
    values = []
    for key in _SOURCE_PATH_KEYS:
        try:
            value = str(material.get(key, "") or "")
        except Exception:
            value = ""
        if value:
            try:
                value = str(Path(bpy.path.abspath(value)).resolve())
            except Exception:
                value = str(value)
            if value not in values:
                values.append(value)
    for value in values:
        try:
            if Path(value).is_file():
                return value
        except Exception:
            pass
    return values[0] if values else ""



def _source_path_for_draw(material) -> str:
    """Return stored document metadata without touching the filesystem.

    Panel.draw must remain a pure RNA/UI read.  Existence, signature and access
    checks are performed only by explicit Open/Save operators.
    """
    if material is None:
        return ""
    for key in _SOURCE_PATH_KEYS:
        try:
            value = str(material.get(key, "") or "")
        except (AttributeError, ReferenceError, TypeError):
            value = ""
        if value:
            return value
    return ""

def _set_source_path(material, path: str) -> None:
    value = str(Path(path).resolve()) if path else ""
    for key in _SOURCE_PATH_KEYS:
        try:
            material[key] = value
        except Exception:
            pass


def _stored_source_hints(material) -> list[str]:
    values = []
    if material is None:
        return values
    for key in _SOURCE_PATH_HINT_KEYS:
        try:
            value = str(material.get(key, "") or "")
        except Exception:
            value = ""
        if not value:
            continue
        try:
            value = str(Path(bpy.path.abspath(value)).resolve())
        except Exception:
            value = str(value)
        if value not in values:
            values.append(value)
    return values


def _layered_signature_matches(path: str) -> bool:
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix not in _image_io.LAYERED_EXTENSIONS:
        return False
    try:
        with source.open("rb") as handle:
            header = handle.read(6)
    except Exception:
        return False
    if len(header) != 6 or header[:4] != b"8BPS":
        return False
    version = int.from_bytes(header[4:6], "big")
    return bool((suffix == ".psd" and version == 1) or (suffix == ".psb" and version == 2))


def _resolve_layered_source_path(material) -> dict[str, object]:
    hints = _stored_source_hints(material)
    candidates = []
    for value in hints:
        if value not in candidates:
            candidates.append(value)
    basenames = []
    for value in hints:
        try:
            source = Path(value)
            if source.suffix.lower() in _image_io.LAYERED_EXTENSIONS and source.name not in basenames:
                basenames.append(source.name)
        except Exception:
            pass
    try:
        raw_blend_path = str(getattr(bpy.data, "filepath", "") or "")
        blend_parent = Path(raw_blend_path).resolve().parent if raw_blend_path else None
    except Exception:
        blend_parent = None
    if blend_parent is not None:
        for basename in basenames:
            for candidate in (
                blend_parent / "texture" / basename,
                blend_parent / basename,
            ):
                value = str(candidate)
                if value not in candidates:
                    candidates.append(value)
    rejected = []
    for value in candidates:
        try:
            source = Path(value)
            if not source.is_file():
                continue
            if not _layered_signature_matches(str(source)):
                rejected.append(str(source))
                continue
            return {
                "ok": True,
                "reason": "source_resolved",
                "path": str(source.resolve()),
                "stored_hints": hints,
            }
        except Exception:
            continue
    return {
        "ok": False,
        "reason": "source_psd_missing",
        "path": str(hints[0] if hints else ""),
        "stored_hints": hints,
        "rejected_candidates": rejected,
    }


def _layered_metadata_document(path: str) -> dict[str, object]:
    source = Path(path)
    try:
        stat = source.stat()
        signature = (int(stat.st_size), int(stat.st_mtime_ns))
    except Exception as exc:
        return {"ok": False, "reason": "source_psd_stat_failed", "error": repr(exc)[:300]}
    cache_key = str(source.resolve())
    cached = _LAYERED_RECOVERY_CACHE.get(cache_key)
    if isinstance(cached, dict) and tuple(cached.get("signature", ())) == signature:
        document = cached.get("document")
        if isinstance(document, dict):
            return {"ok": True, "reason": "metadata_cache_hit", "document": document}
    try:
        from . import psd_io
        _bind_explicit_psd_api(psd_io)

        document = psd_io.read_layered_psd_lazy(
            cache_key,
            decode_merged=False,
            metadata_only=True,
        )
    except Exception as exc:
        return {"ok": False, "reason": "source_psd_metadata_failed", "error": repr(exc)[:300]}
    if not isinstance(document, dict) or not list(document.get("layers", ()) or ()):
        return {"ok": False, "reason": "source_psd_layers_missing"}
    _LAYERED_RECOVERY_CACHE.clear()
    _cache_store(_LAYERED_RECOVERY_CACHE, cache_key, {
        "signature": signature,
        "document": document,
    })
    return {"ok": True, "reason": "metadata_read", "document": document}


def _durable_source_record_index(owner) -> int:
    if owner is None:
        return -1
    try:
        value = int(getattr(owner, "psd_source_record_index", -1))
        if value >= 0:
            return value
    except Exception:
        pass
    for key in (
        "psd_source_record_index",
        "sps_psd_source_order",
        "sps_psd_source_ordinal",
        "sps_psd_source_layer_index",
    ):
        try:
            value = int(owner.get(key, -1))
            if value >= 0:
                return value
        except Exception:
            pass
    return -1


def _record_is_group(record: dict[str, object]) -> bool:
    return bool(
        record.get("is_group", False)
        or int(record.get("section_type", 0) or 0) in {1, 2}
    )


def _record_is_adjustment(record: dict[str, object]) -> bool:
    return bool(
        record.get("is_adjustment", False)
        or dict(record.get("adjustment", {}) or {})
        or dict(record.get("raw_adjustment_tag_payloads", {}) or {})
    )


def _row_original_name(layer) -> str:
    try:
        original = str(layer.get("sps_psd_original_name", "") or "")
    except Exception:
        original = ""
    return original or str(getattr(layer, "name", "") or "")


def _recovery_display_name(value) -> str:
    """Remove only the exact external-exchange record marker."""
    text = str(value or "")
    marker_prefix = "SPSREC_"
    marker_separator = " | "
    marker_length = len(marker_prefix) + 5
    if (
        len(text) >= marker_length + len(marker_separator)
        and text.startswith(marker_prefix)
        and text[len(marker_prefix):marker_length].isdigit()
        and text[marker_length:marker_length + len(marker_separator)]
        == marker_separator
    ):
        return text[marker_length + len(marker_separator):]
    return text


def _recovery_name_key(value) -> str:
    """Normalize application-inserted whitespace for unique recovery only."""
    return "".join(_recovery_display_name(value).split())


def _row_matches_recovery_record(layer, record: dict[str, object]) -> bool:
    record_index = int(record.get("record_index", -1))
    row_record = _durable_source_record_index(layer)
    if row_record >= 0:
        return row_record == record_index
    if _recovery_name_key(_row_original_name(layer)) != _recovery_name_key(
        record.get("name", "")
    ):
        return False
    row_group = bool(getattr(layer, "is_group", False)) or str(
        getattr(layer, "layer_kind", "") or ""
    ).upper() == "GROUP"
    if row_group != _record_is_group(record):
        return False
    row_adjustment = str(getattr(layer, "layer_kind", "") or "").upper() == "ADJUSTMENT"
    try:
        row_adjustment = bool(
            row_adjustment
            or str(getattr(layer, "adjustment_type", "NONE") or "NONE").upper() != "NONE"
        )
    except Exception:
        pass
    return row_adjustment == _record_is_adjustment(record)


def _unique_record_row_mapping(material, records) -> dict[str, object]:
    settings = _settings(material)
    rows = list(getattr(settings, "layers", ()) or ()) if settings is not None else []
    source_indices = [int(record.get("record_index", -1)) for record in records]
    if not rows or not records or any(value < 0 for value in source_indices):
        return {"ok": False, "reason": "source_record_mapping_incomplete"}
    source_set = set(source_indices)
    existing = {}
    for row_index, row in enumerate(rows):
        record_index = _durable_source_record_index(row)
        if record_index < 0:
            continue
        if record_index not in source_set or record_index in existing:
            return {
                "ok": False,
                "reason": "source_record_mapping_ambiguous",
                "record_index": int(record_index),
            }
        existing[record_index] = int(row_index)
    if len(existing) == len(records):
        return {
            "ok": True,
            "reason": "source_record_mapping_existing",
            "mapping": [
                (record, int(existing[int(record.get("record_index", -1))]))
                for record in records
            ],
        }

    # A user deleting a layer this session leaves the remaining rows durably
    # bound while one source record legitimately has no row any more.  That is
    # an intentional structure edit, not a lost identity: requiring every
    # source record to map made ANY delete+save abort with
    # 'source_record_mapping_incomplete'.  Accept the subset when every row
    # that ever carried source identity is still uniquely bound; the
    # name-based recovery below stays reserved for rows that actually lost
    # their binding (sps_psd_original_name present but no record index).
    if existing:
        unbound_source_rows = []
        for row in rows:
            if _durable_source_record_index(row) >= 0:
                continue
            try:
                had_source_identity = bool(str(row.get("sps_psd_original_name", "") or ""))
            except Exception:
                had_source_identity = False
            if had_source_identity:
                unbound_source_rows.append(row)
        if not unbound_source_rows:
            return {
                "ok": True,
                "reason": "source_record_mapping_subset",
                "mapping": [
                    (record, int(existing[int(record.get("record_index", -1))]))
                    for record in records
                    if int(record.get("record_index", -1)) in existing
                ],
            }

    memo = {}

    def solve(record_position: int, row_start: int):
        key = (int(record_position), int(row_start))
        if key in memo:
            return memo[key]
        if record_position >= len(records):
            memo[key] = (1, ())
            return memo[key]
        count = 0
        first_path = ()
        record = records[record_position]
        for row_index in range(row_start, len(rows)):
            if not _row_matches_recovery_record(rows[row_index], record):
                continue
            child_count, child_path = solve(record_position + 1, row_index + 1)
            if child_count <= 0:
                continue
            if count == 0:
                first_path = (int(row_index),) + tuple(child_path)
            count = min(2, count + int(child_count))
            if count >= 2:
                break
        memo[key] = (count, first_path)
        return memo[key]

    solution_count, row_path = solve(0, 0)
    if solution_count != 1 or len(row_path) != len(records):
        return {
            "ok": False,
            "reason": (
                "source_record_mapping_ambiguous"
                if solution_count > 1
                else "source_record_mapping_incomplete"
            ),
            "solution_count": int(solution_count),
        }
    # A marker-only difference is exact after stripping. Whitespace
    # normalization is accepted only when that key is unique on both sides;
    # otherwise two intentionally distinct names could be silently swapped.
    record_keys = [
        _recovery_name_key(record.get("name", ""))
        for record in records
    ]
    row_keys = [
        _recovery_name_key(_row_original_name(row))
        for row in rows
    ]
    for record, row_index in zip(records, row_path):
        record_name = _recovery_display_name(record.get("name", ""))
        row_name = _recovery_display_name(_row_original_name(rows[int(row_index)]))
        if record_name == row_name:
            continue
        key = _recovery_name_key(record_name)
        if record_keys.count(key) != 1 or row_keys.count(key) != 1:
            return {
                "ok": False,
                "reason": "source_record_mapping_ambiguous",
                "solution_count": int(solution_count),
                "normalized_name": key,
            }
    return {
        "ok": True,
        "reason": "source_record_mapping_recovered",
        "mapping": list(zip(records, row_path)),
    }


def _bind_recovered_record_identity(layer, record, source: str, width: int, height: int) -> None:
    record_index = int(record.get("record_index", -1))
    if layer is None or record_index < 0:
        return
    record_name = _recovery_display_name(record.get("name", ""))
    row_name = str(getattr(layer, "name", "") or "")
    display_name = (
        row_name
        if row_name and _recovery_name_key(row_name) == _recovery_name_key(record_name)
        else record_name
    )
    try:
        layer.psd_source_record_index = record_index
    except Exception:
        pass
    for key, value in (
        ("psd_source_record_index", record_index),
        ("sps_psd_source_order", record_index),
        ("sps_psd_source_ordinal", record_index),
        ("sps_psd_source_layer_index", record_index),
        ("sps_psd_original_name", display_name),
        ("smart_paint_suite_source_file", source),
        ("smart_paint_suite_layered_source_path", source),
        ("smart_paint_suite_lazy_psd_key", f"{source}|{record_index}"),
    ):
        try:
            layer[key] = value
        except Exception:
            pass
    for image_attr, mask_image in (
        ("base_color_image", False),
        ("mask_image", True),
    ):
        image_name = str(getattr(layer, image_attr, "") or "")
        image = bpy.data.images.get(image_name) if image_name else None
        if image is None:
            continue
        for key, value in (
            ("smart_paint_suite_source_file", source),
            ("smart_paint_suite_layered_source_path", source),
            ("sps_psd_source_order", record_index),
            ("sps_psd_source_ordinal", record_index),
            ("sps_psd_source_layer_index", record_index),
            ("sps_psd_original_name", display_name),
            ("smart_paint_suite_lazy_psd_key", f"{source}|{record_index}"),
        ):
            try:
                image[key] = value
            except Exception:
                pass
        try:
            is_proxy = int(image.size[0]) <= 1 or int(image.size[1]) <= 1
        except Exception:
            is_proxy = False
        if is_proxy:
            try:
                image["smart_paint_suite_lazy_width"] = int(width)
                image["smart_paint_suite_lazy_height"] = int(height)
                image[
                    "smart_paint_suite_lazy_psd_mask_pending"
                    if mask_image
                    else "smart_paint_suite_lazy_psd_pending"
                ] = True
            except Exception:
                pass


def _store_recovered_source_baseline(material, records, mapping) -> bool:
    try:
        raw = str(material.get(_METADATA_BASELINE_KEY, "") or "")
        previous = json.loads(raw) if raw else None
    except Exception:
        previous = None
    if isinstance(previous, list):
        return False
    current = _metadata_state(material)
    settings = _settings(material)
    by_row = {int(row_index): dict(current[int(row_index)]) for _record, row_index in mapping}
    baseline = []
    for record, row_index in mapping:
        item = dict(by_row[int(row_index)])
        is_group = _record_is_group(record)
        is_adjustment = _record_is_adjustment(record)
        item.update({
            "record_index": int(record.get("record_index", -1)),
            "layer_kind": "GROUP" if is_group else ("ADJUSTMENT" if is_adjustment else "PAINT"),
            "name": _row_original_name(settings.layers[int(row_index)]),
            "enabled": bool(record.get("enabled", True)),
            "opacity": int(max(0, min(255, round(float(record.get("opacity", 1.0) or 0.0) * 255.0)))),
            "blend_mode": str(record.get("blend_mode", "MIX") or "MIX").upper(),
            "clip_to_below": bool(
                record.get("clip_to_below", int(record.get("clipping", 0) or 0) > 0)
            ),
            "is_group": bool(is_group),
            "group_depth": max(0, int(record.get("group_depth", 0) or 0)),
        })
        meta = dict(record.get("sps_layer_info", {}) or {})
        for key in (
            "mask_mode",
            "mask_channel",
            "invert_mask",
            "mask_strength",
            "mask_threshold",
        ):
            if key in meta:
                item[key] = meta[key]
        baseline.append(item)
    try:
        material[_METADATA_BASELINE_KEY] = json.dumps(
            baseline,
            ensure_ascii=False,
            separators=(",", ":"),
        )
        return True
    except Exception:
        return False


def _ensure_layered_document_ready(material, context=None, *, reason: str = "operation") -> dict[str, object]:
    started = time.perf_counter()
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    source_result = _resolve_layered_source_path(material)
    if not bool(source_result.get("ok", False)):
        return source_result
    source = str(source_result.get("path", "") or "")
    metadata_result = _layered_metadata_document(source)
    if not bool(metadata_result.get("ok", False)):
        return {**metadata_result, "path": source}
    document = dict(metadata_result.get("document", {}) or {})
    records = list(document.get("layers", ()) or ())
    mapping_result = _unique_record_row_mapping(material, records)
    if not bool(mapping_result.get("ok", False)):
        return {**mapping_result, "path": source}
    mapping = list(mapping_result.get("mapping", ()) or ())
    try:
        from .properties import suspend_layer_rebuilds

        old_suspend = suspend_layer_rebuilds(True)
    except Exception:
        suspend_layer_rebuilds = None
        old_suspend = False
    try:
        for record, row_index in mapping:
            settings = _settings(material)
            layer = settings.layers[int(row_index)]
            _bind_recovered_record_identity(
                layer,
                record,
                source,
                int(document.get("width", 0) or 0),
                int(document.get("height", 0) or 0),
            )
        _set_document_identity(
            material,
            kind="LAYERED",
            path=source,
            width=int(document.get("width", 0) or 0),
            height=int(document.get("height", 0) or 0),
            file_format="PSB" if bool(document.get("psb", False)) else "PSD",
            depth=int(document.get("depth", 0) or 0),
        )
        baseline_created = _store_recovered_source_baseline(material, records, mapping)
        _remember_session_source_path(material, source)
    finally:
        try:
            if suspend_layer_rebuilds is not None:
                suspend_layer_rebuilds(bool(old_suspend))
        except Exception:
            pass
    result = {
        "ok": True,
        "reason": str(mapping_result.get("reason", "source_record_mapping_ready") or ""),
        "path": source,
        "record_count": len(records),
        "row_count": len(getattr(_settings(material), "layers", ()) or ()),
        "mapping": [
            {
                "record_index": int(record.get("record_index", -1)),
                "row_index": int(row_index),
                "name": str(record.get("name", "") or ""),
            }
            for record, row_index in mapping
        ],
        "baseline_created": bool(baseline_created),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }
    _trace_lightweight(
        "lightweight_layered_identity_ready",
        material=material,
        operation_reason=str(reason or "operation"),
        **result,
    )
    return result


def _document_kind(material) -> str:
    try:
        value = str(material.get(_DOCUMENT_KIND_KEY, "") or "").upper()
    except Exception:
        value = ""
    if value in {"FLAT", "LAYERED"}:
        return value
    return "LAYERED" if Path(_source_path(material)).suffix.lower() in _image_io.LAYERED_EXTENSIONS else "FLAT"


def _set_document_identity(
    material,
    *,
    kind: str,
    path: str,
    width: int,
    height: int,
    file_format: str = "",
    depth: int = 0,
) -> None:
    if material is None:
        return
    _set_source_path(material, path)
    try:
        material[_DOCUMENT_KIND_KEY] = str(kind or "").upper()
        material[_DOCUMENT_WIDTH_KEY] = max(0, int(width))
        material[_DOCUMENT_HEIGHT_KEY] = max(0, int(height))
        material["sps_lightweight_document_format"] = str(file_format or "").upper()
        material["sps_lightweight_document_depth"] = max(0, int(depth))
        material["sps_lightweight_document_token"] = uuid.uuid4().hex
    except Exception:
        pass


def _clear_flat_document_markers(material) -> None:
    if material is None:
        return
    for key in (
        "sps_lightweight_flat_open_file_sha256",
        "sps_lightweight_flat_open_pixel_sha256",
        "sps_lightweight_flat_last_saved_file_sha256",
        "sps_lightweight_flat_last_saved_pixel_sha256",
        "sps_lightweight_flat_last_saved_path",
        "sps_lightweight_flat_photoshop_layer_tiff",
        "sps_lightweight_flat_source_colorspace",
    ):
        try:
            if key in material:
                del material[key]
        except Exception:
            pass


def _normalized_psd_path(path: str) -> str:
    try:
        return str(Path(bpy.path.abspath(str(path or ""))).resolve()) if path else ""
    except Exception:
        return str(path or "")


def _session_material_key(material) -> str:
    try:
        return str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")
    except Exception:
        return ""


def _remember_session_source_path(material, path: str) -> str:
    """Remember the document actually opened in this process, outside undo."""
    key = _session_material_key(material)
    value = _normalized_psd_path(path)
    if key and value:
        _SESSION_SOURCE_PATHS[key] = value
    return value


def _session_source_path(material) -> str:
    return str(_SESSION_SOURCE_PATHS.get(_session_material_key(material), "") or "")


def _rebind_source_path_only(material, path: str) -> None:
    """Repair undo-rolled-back path identity without touching pixels or dirty state."""
    source = _normalized_psd_path(path)
    if material is None or not source:
        return
    _set_source_path(material, source)
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    owners = []
    image_names = set()
    for layer in layers:
        record_index = _source_record_index(layer)
        if record_index < 0:
            continue
        owners.append((layer, record_index))
        image_name = str(getattr(layer, "base_color_image", "") or "")
        if image_name:
            image_names.add(image_name)
    for entry in (_ACTIVATED_LAYERS.get(_session_material_key(material), {}) or {}).values():
        if not isinstance(entry, dict):
            continue
        image_name = str(entry.get("image", "") or "")
        if image_name:
            image_names.add(image_name)
    for image_name in image_names:
        image = bpy.data.images.get(image_name)
        if image is None:
            continue
        try:
            record_index = int(image.get("sps_psd_source_order", -1))
        except Exception:
            record_index = -1
        if record_index >= 0:
            owners.append((image, record_index))
    for owner, record_index in owners:
        for key, value in (
            ("smart_paint_suite_source_file", source),
            ("smart_paint_suite_layered_source_path", source),
            ("smart_paint_suite_lazy_psd_key", f"{source}|{int(record_index)}"),
        ):
            try:
                owner[key] = value
            except Exception:
                pass


def _source_record_index(layer) -> int:
    return _durable_source_record_index(layer)


def _metadata_state(material) -> list[dict[str, object]]:
    """Return the small PSD metadata state; never read image pixels here."""
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    try:
        from .mvp import adjustments as adjustment_module
    except Exception:
        adjustment_module = None
    state: list[dict[str, object]] = []
    for index, layer in enumerate(layers):
        state.append({
            "layer_id": _layer_id(layer, index),
            "record_index": _source_record_index(layer),
            "layer_kind": str(getattr(layer, "layer_kind", "PAINT") or "PAINT").upper(),
            "adjustment": adjustment_module.metadata_state(layer) if adjustment_module else {},
            "name": str(getattr(layer, "name", "") or ""),
            "enabled": bool(getattr(layer, "enabled", True)),
            "opacity": int(max(0, min(255, round(float(getattr(layer, "opacity", 1.0) or 0.0) * 255.0)))),
            "blend_mode": str(getattr(layer, "blend_mode", "MIX") or "MIX").upper(),
            "clip_to_below": bool(getattr(layer, "clip_to_below", False)),
            "is_group": bool(getattr(layer, "is_group", False)),
            "group_expanded": bool(getattr(layer, "group_expanded", True)),
            "group_depth": max(0, int(getattr(layer, "group_depth", 0) or 0)),
            "mask_mode": str(getattr(layer, "mask_mode", "NONE") or "NONE").upper(),
            "mask_image": str(getattr(layer, "mask_image", "") or ""),
            "mask_channel": str(getattr(layer, "mask_channel", "LUMA") or "LUMA").upper(),
            "invert_mask": bool(getattr(layer, "invert_mask", False)),
            "mask_strength": round(float(getattr(layer, "mask_strength", 1.0) or 0.0), 6),
            "mask_threshold": round(float(getattr(layer, "mask_threshold", 0.5) or 0.0), 6),
        })
    return state


def _store_metadata_baseline(material) -> None:
    try:
        material[_METADATA_BASELINE_KEY] = json.dumps(
            _metadata_state(material), ensure_ascii=False, separators=(",", ":")
        )
    except Exception:
        pass


def _mask_images_requiring_write(material) -> list[str]:
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    names: list[str] = []
    for layer in layers:
        try:
            if str(getattr(layer, "mask_mode", "NONE") or "NONE").upper() in {"", "NONE", "OFF"}:
                continue
            name = str(getattr(layer, "mask_image", "") or "")
            image = bpy.data.images.get(name) if name else None
            if image is None:
                continue
            if bool(image.get("sps_lightweight_mask_write_required", False)) or bool(
                getattr(image, "is_dirty", False)
            ):
                names.append(name)
        except Exception:
            continue
    return names


def _commit_saved_mask_images(material, image_names) -> None:
    """Make a successful PSD mask write the next Blender dirty boundary."""
    started = time.perf_counter()
    committed = []
    for name in dict.fromkeys(str(value or "") for value in (image_names or ())):
        image = bpy.data.images.get(name) if name else None
        if image is None:
            continue
        packed = False
        try:
            image.pack()
            packed = True
        except Exception:
            packed = False
        try:
            image["sps_lightweight_mask_write_required"] = False
        except Exception:
            pass
        committed.append({
            "image": name,
            "packed": bool(packed),
            "dirty": bool(getattr(image, "is_dirty", False)),
        })
    if committed:
        _trace_lightweight(
            "lightweight_mask_save_boundary_committed",
            material=material,
            images=committed,
            elapsed_ms=round((time.perf_counter() - started) * 1000.0, 3),
        )


def _metadata_changes(material) -> dict[str, object]:
    current = _metadata_state(material)
    try:
        raw = str(material.get(_METADATA_BASELINE_KEY, "") or "")
        previous = json.loads(raw) if raw else None
    except Exception:
        previous = None
    if not isinstance(previous, list):
        _store_metadata_baseline(material)
        return {
            "dirty": False,
            "metadata": False,
            "structure": False,
            "order": False,
            "mask": False,
            "intent_known": False,
            "previous": current,
            "changed_fields": {},
            "added_identities": [],
            "removed_identities": [],
            "mask_dirty_identities": [],
            "current": current,
        }

    def identity(item: dict[str, object]) -> str:
        try:
            record_index = int(item.get("record_index", -1))
        except Exception:
            record_index = -1
        if record_index >= 0:
            # Existing PSD rows keep their raw record identity across Blender
            # memfile undo even when RNA layer_id values are regenerated.
            return "record:" + str(record_index)
        lid = str(item.get("layer_id", "") or "")
        if lid:
            return "id:" + lid
        return "new-row"

    previous_ids = [identity(item) for item in previous if isinstance(item, dict)]
    current_ids = [identity(item) for item in current]
    structure = bool(len(previous_ids) != len(current_ids) or set(previous_ids) != set(current_ids))
    order = bool(previous_ids != current_ids)
    previous_by_id = {
        identity(item): item for item in previous if isinstance(item, dict)
    }
    metadata = False
    mask = False
    changed_fields: dict[str, list[str]] = {}
    mask_dirty_identities: set[str] = set()
    for item in current:
        item_identity = identity(item)
        old = previous_by_id.get(item_identity)
        if old is None:
            structure = True
            order = True
            continue
        if (
            bool(old.get("is_group", False)) != bool(item.get("is_group", False))
            or bool(old.get("group_expanded", True)) != bool(item.get("group_expanded", True))
            or int(old.get("group_depth", 0) or 0) != int(item.get("group_depth", 0) or 0)
        ):
            structure = True
            order = True
            changed_fields.setdefault(item_identity, []).extend(
                key
                for key in ("is_group", "group_expanded", "group_depth")
                if old.get(key) != item.get(key)
            )
        for key in ("name", "enabled", "opacity", "blend_mode", "clip_to_below", "layer_kind", "adjustment"):
            if old.get(key) != item.get(key):
                metadata = True
                changed_fields.setdefault(item_identity, []).append(key)
        for key in ("mask_mode", "mask_image", "mask_channel", "invert_mask", "mask_strength", "mask_threshold"):
            if old.get(key) != item.get(key):
                metadata = True
                mask = True
                changed_fields.setdefault(item_identity, []).append(key)
                mask_dirty_identities.add(item_identity)
    mask_write_images = _mask_images_requiring_write(material)
    if mask_write_images:
        metadata = True
        mask = True
        mask_write_set = set(str(name or "") for name in mask_write_images)
        for item in current:
            if str(item.get("mask_image", "") or "") in mask_write_set:
                item_identity = identity(item)
                mask_dirty_identities.add(item_identity)
                changed_fields.setdefault(item_identity, []).append("mask_pixels")
    previous_id_set = set(previous_ids)
    current_id_set = set(current_ids)
    added_identities = [value for value in current_ids if value not in previous_id_set]
    removed_identities = [value for value in previous_ids if value not in current_id_set]
    return {
        "dirty": bool(metadata or structure or order or mask),
        "metadata": bool(metadata),
        "structure": bool(structure),
        "order": bool(order),
        "mask": bool(mask),
        "intent_known": True,
        "previous": previous,
        "changed_fields": {
            key: sorted(set(str(value) for value in values))
            for key, values in changed_fields.items()
        },
        "added_identities": added_identities,
        "removed_identities": removed_identities,
        "mask_dirty_identities": sorted(mask_dirty_identities),
        "mask_write_images": mask_write_images,
        "current": current,
    }


def _new_orphan_clipping_rows(metadata_changes: dict[str, object]) -> list[dict[str, object]]:
    """Return clipping rows made invalid by the current unsaved stack edit."""
    if not bool(metadata_changes.get("intent_known", False)):
        return []

    def identity(item: dict[str, object], index: int) -> str:
        try:
            record_index = int(item.get("record_index", -1))
        except Exception:
            record_index = -1
        if record_index >= 0:
            return "record:" + str(record_index)
        layer_id = str(item.get("layer_id", "") or "")
        return "id:" + layer_id if layer_id else "row:" + str(index)

    def orphan_rows(raw_rows) -> dict[str, dict[str, object]]:
        rows = [row for row in list(raw_rows or ()) if isinstance(row, dict)]
        result: dict[str, dict[str, object]] = {}
        for index, row in enumerate(rows):
            if not bool(row.get("clip_to_below", False)):
                continue
            depth = max(0, int(row.get("group_depth", 0) or 0))
            has_base = False
            for lower_index in range(index - 1, -1, -1):
                lower = rows[lower_index]
                lower_depth = max(0, int(lower.get("group_depth", 0) or 0))
                if lower_depth < depth:
                    break
                if lower_depth > depth or bool(lower.get("clip_to_below", False)):
                    continue
                has_base = True
                break
            if not has_base:
                row_identity = identity(row, index)
                try:
                    record_index = int(row.get("record_index", -1))
                except Exception:
                    record_index = -1
                result[row_identity] = {
                    "identity": row_identity,
                    "index": int(index),
                    "record_index": int(record_index),
                    "layer_id": str(row.get("layer_id", "") or ""),
                    "name": str(row.get("name", "") or ""),
                    "group_depth": int(depth),
                }
        return result

    previous_orphans = orphan_rows(metadata_changes.get("previous"))
    current_orphans = orphan_rows(metadata_changes.get("current"))
    return [
        current_orphans[row_identity]
        for row_identity in current_orphans
        if row_identity not in previous_orphans
    ]


def _mark_structure_dirty(
    material,
    *,
    reason: str,
    order: bool = False,
    mask: bool = False,
) -> None:
    settings = _settings(material)
    owners = [owner for owner in (material, settings) if owner is not None]
    for owner in owners:
        try:
            owner["sps_psd_structure_dirty"] = True
            owner["sps_psd_structure_dirty_BASE_COLOR"] = True
            owner["sps_psd_structure_dirty_reason_BASE_COLOR"] = str(reason or "lightweight_metadata")[:128]
            if order:
                owner["sps_psd_layer_order_dirty"] = True
                owner["sps_psd_layer_order_dirty_BASE_COLOR"] = True
            if mask:
                owner["sps_psd_mask_structure_dirty"] = True
                owner["sps_psd_mask_structure_dirty_BASE_COLOR"] = True
        except Exception:
            pass


def _workspace_screen_records(context=None):
    """Yield each visible screen with its owning workspace outside draw/poll."""
    ctx = context or getattr(bpy, "context", None)
    seen = set()
    screen = getattr(ctx, "screen", None)
    workspace = getattr(ctx, "workspace", None)
    if workspace is None:
        workspace = getattr(getattr(ctx, "window", None), "workspace", None)
    if screen is not None:
        seen.add(id(screen))
        yield screen, workspace
    try:
        wm = getattr(ctx, "window_manager", None)
        for window in getattr(wm, "windows", ()) if wm is not None else ():
            screen = getattr(window, "screen", None)
            if screen is None or id(screen) in seen:
                continue
            seen.add(id(screen))
            yield screen, getattr(window, "workspace", None)
    except Exception:
        return


def _tag_redraw(context=None) -> None:
    ctx = context or getattr(bpy, "context", None)
    try:
        for screen, workspace in _workspace_screen_records(ctx):
            if not _manager_rule_api.workspace_runtime_allowed(ctx, workspace=workspace):
                continue
            for area in getattr(screen, "areas", ()) or ():
                if str(getattr(area, "type", "") or "") in {"VIEW_3D", "IMAGE_EDITOR"}:
                    area.tag_redraw()
    except Exception:
        pass


def _view3d_areas(context=None, *, include_inactive: bool = False):
    ctx = context or getattr(bpy, "context", None)
    for screen, workspace in _workspace_screen_records(ctx):
        if (
            not include_inactive
            and not _manager_rule_api.workspace_runtime_allowed(ctx, workspace=workspace)
        ):
            continue
        for area in getattr(screen, "areas", ()) or ():
            if str(getattr(area, "type", "") or "") == "VIEW_3D":
                yield area


def _sync_paint_workspace_uv(context=None, material=None) -> dict[str, object]:
    try:
        from .mvp import paint_workspace

        return dict(paint_workspace.synchronize(context, material) or {})
    except Exception as exc:
        return {"ok": False, "reason": "paint_workspace_uv_sync_failed", "error": repr(exc)[:300]}


def _ensure_material_display_shading(context=None) -> int:
    """Keep Solid shading when the operation-bound GPU overlay is available."""
    if not _manager_rule_api.workspace_runtime_allowed(context):
        return 0
    material = _resolve_material(context)
    _sync_paint_workspace_uv(context, material)
    solid_ready = False
    try:
        from .mvp import solid_view_overlay

        result = solid_view_overlay.prepare(material, context)
        solid_ready = bool(result.get("ok", False))
        if material is not None:
            material[solid_view_overlay.ERROR_PROPERTY] = (
                "" if solid_ready else str(result.get("reason", "") or "")
            )
        solid_view_overlay.sync_handler_state()
    except Exception:
        solid_ready = False
    changed = 0
    for area in _view3d_areas(context):
        try:
            key = int(area.as_pointer())
            space = area.spaces.active
            current = str(space.shading.type or "")
            if current in {"MATERIAL", "RENDERED"}:
                continue
            if current == "SOLID" and solid_ready:
                area.tag_redraw()
                continue
            _FORCED_MATERIAL_VIEW_SHADING.setdefault(key, current or "SOLID")
            space.shading.type = "MATERIAL"
            area.tag_redraw()
            changed += 1
        except Exception:
            continue
    return int(changed)


def _restore_material_display_shading(context=None) -> int:
    restored = 0
    for area in _view3d_areas(context, include_inactive=True):
        try:
            key = int(area.as_pointer())
            previous = _FORCED_MATERIAL_VIEW_SHADING.pop(key, "")
            if not previous:
                continue
            space = area.spaces.active
            # Respect a manual user change made while review mode was active.
            if str(space.shading.type or "") == "MATERIAL":
                space.shading.type = previous
                area.tag_redraw()
                restored += 1
        except Exception:
            continue
    return int(restored)


def _layer_id(layer, index: int) -> str:
    try:
        value = str(getattr(layer, "layer_id", "") or "")
    except Exception:
        value = ""
    return value or f"layer_{int(index) + 1}"


def _set_active_indices(settings, index: int) -> None:
    """Keep UI highlighting synchronized with the authoritative engine index."""
    if settings is None:
        return
    value = max(0, int(index))
    try:
        settings.active_layer_index = value
    except Exception:
        pass
    # Set the engine index first. The UI-only property's update callback then
    # sees equality and cannot recursively invoke the selection operator.
    try:
        settings.lightweight_ui_layer_index = value
    except Exception:
        pass


def _thumbnail_module(*, import_if_missing: bool = False):
    global _THUMBNAIL_MODULE
    if _THUMBNAIL_MODULE is not None or not import_if_missing:
        return _THUMBNAIL_MODULE
    try:
        from .mvp import layer_thumbnails
        _THUMBNAIL_MODULE = layer_thumbnails
    except (ImportError, AttributeError, RuntimeError):
        _THUMBNAIL_MODULE = None
    return _THUMBNAIL_MODULE


def _live_composite_module(*, import_if_missing: bool = False):
    global _LIVE_COMPOSITE_MODULE
    if _LIVE_COMPOSITE_MODULE is not None or not import_if_missing:
        return _LIVE_COMPOSITE_MODULE
    try:
        from .mvp import live_composite
        _LIVE_COMPOSITE_MODULE = live_composite
    except (ImportError, AttributeError, RuntimeError):
        _LIVE_COMPOSITE_MODULE = None
    return _LIVE_COMPOSITE_MODULE


def _thumbnails_enabled(material) -> bool:
    try:
        return bool(material.get("sps_lightweight_thumbnails_enabled", False))
    except Exception:
        return False


def _materialized_layer_image(material, layer, index: int):
    """Resolve an existing full-size image without decoding or materializing."""
    names: list[str] = []
    layer_id = _layer_id(layer, index)
    try:
        entry = (_ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}).get(layer_id, {}) or {}
        names.append(str(entry.get("image", "") or ""))
    except Exception:
        pass
    try:
        names.append(str(getattr(layer, "base_color_image", "") or ""))
    except Exception:
        pass
    for name in names:
        image = bpy.data.images.get(name) if name else None
        try:
            if image is not None and int(image.size[0]) > 1 and int(image.size[1]) > 1:
                return image
        except Exception:
            continue
    return None


def _ensure_layer_thumbnail(material, layer, index: int, image=None, *, force: bool = False) -> dict[str, object]:
    module = _thumbnail_module(import_if_missing=True)
    if module is None:
        return {"ok": False, "reason": "thumbnail_module_unavailable"}
    target = image or _materialized_layer_image(material, layer, index)
    if target is None:
        return {"ok": False, "reason": "image_not_materialized"}
    try:
        return dict(module.ensure(
            material,
            _layer_id(layer, index),
            _source_record_index(layer),
            target,
            force=bool(force),
        ) or {})
    except Exception as exc:
        return {"ok": False, "reason": "thumbnail_exception", "error": repr(exc)[:300]}


def _layer_is_paintable(layer) -> bool:
    if layer is None:
        return False
    try:
        if bool(getattr(layer, "is_group", False)):
            return False
    except Exception:
        pass
    try:
        if str(getattr(layer, "layer_kind", "PAINT") or "PAINT").upper() in {"GROUP", "ADJUSTMENT"}:
            return False
    except Exception:
        pass
    try:
        if str(getattr(layer, "adjustment_type", "NONE") or "NONE").upper() != "NONE":
            return False
    except Exception:
        pass
    # Photoshop/CSP allow a hidden pixel layer to stay selected and editable.
    # Visibility is PSD metadata only in lightweight mode and must not make the
    # native Texture Paint target disappear.
    return True


def _stamp_imported_source_identity(owner, source_path: str, record_index: int) -> None:
    """Make an explicit PSD-open operation authoritative over stale datablocks."""
    if owner is None or int(record_index) < 0:
        return
    source = str(Path(source_path).resolve()) if source_path else ""
    for key, value in (
        ("smart_paint_suite_source_file", source),
        ("smart_paint_suite_layered_source_path", source),
        ("sps_psd_source_order", int(record_index)),
        ("sps_psd_source_ordinal", int(record_index)),
        ("sps_psd_source_layer_index", int(record_index)),
        ("smart_paint_suite_lazy_psd_key", f"{source}|{int(record_index)}"),
        ("smart_paint_suite_lazy_psd_pending", True),
    ):
        try:
            owner[key] = value
        except Exception:
            pass
    # An image datablock can outlive a previous document/open cycle.  These
    # markers describe its old in-memory pixels and must not suppress decoding
    # the record selected by the new explicit Open command.
    for key in (
        "smart_paint_suite_psd_materialized_clean",
        "smart_paint_suite_internal_clean_write",
        "smart_paint_suite_internal_write_reason",
        "smart_paint_suite_saved_psd_clean_boundary",
        "smart_paint_suite_direct_layer_dirty",
        "smart_paint_suite_bodypaint_direct_authoritative",
        "smart_paint_suite_painted_since_last_projection",
        "smart_paint_suite_user_edited",
        "sps_v2_native_paint_dirty",
        "smart_paint_suite_dirty_bbox",
        "smart_paint_suite_dirty_rects_json",
        "smart_paint_suite_sparse_rgba_patch_bbox",
        "smart_paint_suite_sparse_rgba_patch_b64",
        "smart_paint_suite_authoritative_sparse_rgba_patch",
    ):
        try:
            if key in owner:
                del owner[key]
        except Exception:
            pass


def _prepare_imported_source_layers(material, source_path: str) -> int:
    """Invalidate stale canvases before the first activation of a loaded PSD."""
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    prepared = 0
    for layer in layers:
        if not _layer_is_paintable(layer):
            continue
        record_index = _source_record_index(layer)
        if record_index < 0:
            continue
        _stamp_imported_source_identity(layer, source_path, record_index)
        image_name = str(getattr(layer, "base_color_image", "") or "")
        image = bpy.data.images.get(image_name) if image_name else None
        if image is not None:
            _stamp_imported_source_identity(image, source_path, record_index)
        prepared += 1
    _trace_lightweight(
        "lightweight_source_layers_prepared",
        material=material,
        source=str(source_path or ""),
        layer_count=int(prepared),
    )
    return int(prepared)


def _active_layer(material):
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    if not layers:
        return None, -1
    try:
        index = max(0, min(int(getattr(settings, "active_layer_index", 0) or 0), len(layers) - 1))
    except Exception:
        index = 0
    return layers[index], int(index)


def _principled_nodes(material):
    try:
        if not bool(getattr(material, "use_nodes", False)):
            material.use_nodes = True
        tree = getattr(material, "node_tree", None)
        if tree is None:
            return None, []
        nodes = [node for node in tree.nodes if str(getattr(node, "type", "") or "") == "BSDF_PRINCIPLED"]
        return tree, nodes
    except Exception:
        return None, []


def _bind_active_layer_display(material, image, context=None) -> bool:
    """Show only the current paint canvas; no stack composition is performed."""
    if material is None or image is None:
        return False
    try:
        from .mvp import paint_target
        layer_id = str(image.get("smart_paint_suite_layer_id", "") or "")
        node = paint_target._ensure_write_node(material, layer_id, image)
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        node = None
    if node is None:
        return False
    try:
        node.hide = False
        node.label = "Smart Paint Active PSD Layer"
        node.interpolation = "Linear"
        node["sps_lightweight_active_display"] = True
    except Exception:
        pass
    tree, principled = _principled_nodes(material)
    if tree is not None:
        for bsdf in principled:
            try:
                socket = bsdf.inputs.get("Base Color")
                output = node.outputs.get("Color")
                if socket is None or output is None:
                    continue
                for link in list(getattr(socket, "links", ()) or ()):
                    tree.links.remove(link)
                tree.links.new(output, socket)
            except Exception:
                continue
            try:
                alpha_socket = bsdf.inputs.get("Alpha")
                alpha_output = node.outputs.get("Alpha")
                if alpha_socket is not None and alpha_output is not None:
                    for link in list(getattr(alpha_socket, "links", ()) or ()):
                        tree.links.remove(link)
                    tree.links.new(alpha_output, alpha_socket)
            except Exception:
                pass
        try:
            tree.nodes.active = node
            material.update_tag()
            tree.update_tag()
        except Exception:
            pass
    try:
        material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
        material["sps_lightweight_active_image"] = str(getattr(image, "name", "") or "")
    except Exception:
        pass
    try:
        paint = getattr(getattr((context or bpy.context), "tool_settings", None), "image_paint", None)
        if paint is not None:
            paint.canvas = image
    except Exception:
        pass
    try:
        from .mvp import solid_view_overlay

        solid_view_overlay.sync_handler_state()
    except Exception:
        pass
    _restore_material_display_shading(context)
    _sync_paint_workspace_uv(context, material)
    _show_image_in_editors(image, context)
    return True


def _show_image_in_editors(image, context=None, *, read_only: bool = False) -> None:
    """Show an image without ever making a review image paintable.

    In Blender's Image Editor the displayed image is the paint destination,
    independently of ``tool_settings.image_paint.canvas``.  A composite review
    must therefore switch paint-capable editors to VIEW before showing its
    display-only image.  Restoring a layer image restores the previous editor
    mode.  UV editors are deliberately left untouched.
    """
    ctx = context or getattr(bpy, "context", None)
    if read_only and not _manager_rule_api.workspace_runtime_allowed(ctx):
        return
    for screen, workspace in _workspace_screen_records(ctx):
        allowed = _manager_rule_api.workspace_runtime_allowed(ctx, workspace=workspace)
        if read_only and not allowed:
            continue
        for area in getattr(screen, "areas", ()) or ():
            if str(getattr(area, "type", "") or "") != "IMAGE_EDITOR":
                continue
            if str(getattr(area, "ui_type", "") or "") == "UV":
                continue
            try:
                space = area.spaces.active
                try:
                    editor_key = int(area.as_pointer())
                except Exception:
                    editor_key = id(area)
                # Inactive workspaces are never activated or rebound. The only
                # exception is exact cleanup of a mode this Suite previously
                # forced while that workspace was active.
                if not allowed and not read_only and editor_key not in _FORCED_REVIEW_EDITOR_MODES:
                    continue
                if read_only:
                    previous_mode = str(getattr(space, "mode", "") or "")
                    if previous_mode != "VIEW":
                        _FORCED_REVIEW_EDITOR_MODES[editor_key] = previous_mode
                        space.mode = "VIEW"
                    if str(getattr(space, "mode", "") or "") != "VIEW":
                        _FORCED_REVIEW_EDITOR_MODES.pop(editor_key, None)
                        continue
                    space.image = image
                else:
                    space.image = image
                    previous_mode = _FORCED_REVIEW_EDITOR_MODES.pop(editor_key, "")
                    if previous_mode and str(getattr(space, "mode", "") or "") == "VIEW":
                        space.mode = previous_mode
                area.tag_redraw()
            except Exception:
                pass


def _manual_composite_signature(path: str) -> str:
    try:
        resolved = Path(path).resolve()
        stat = resolved.stat()
        return f"{resolved}|{int(stat.st_size)}|{int(stat.st_mtime_ns)}"
    except Exception:
        return ""


def _payload_sha256_u8(payload) -> str:
    if not isinstance(payload, tuple) or len(payload) != 3:
        return ""
    try:
        import numpy as np

        width, height, pixels = payload
        width = int(width); height = int(height)
        data = np.ascontiguousarray(np.asarray(pixels, dtype=np.uint8).reshape((height, width, 4)))
        return hashlib.sha256(memoryview(data).cast("B")).hexdigest()
    except Exception:
        return ""


def _mask_pixel_digests(material, identities=None) -> dict[str, str]:
    """Hash only save-invalidated masks so a Review proof cannot go stale."""
    targets = {str(value) for value in list(identities or []) if str(value)}
    if identities is None:
        try:
            raw = str(material.get("sps_psd_save_intent_BASE_COLOR", "") or "")
            intent = json.loads(raw) if raw else {}
            targets = {
                str(value)
                for value in list((intent or {}).get("mask_dirty_identities", []) or [])
                if str(value)
            }
        except Exception:
            targets = set()
    if not targets:
        return {}
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    digests: dict[str, str] = {}
    for index, layer in enumerate(layers):
        record_index = _source_record_index(layer)
        layer_id = _layer_id(layer, index)
        identity = "record:" + str(record_index) if record_index >= 0 else "id:" + str(layer_id)
        if identity not in targets:
            continue
        mask_name = str(getattr(layer, "mask_image", "") or "")
        mask = bpy.data.images.get(mask_name) if mask_name else None
        payload = None
        try:
            from .mvp import live_composite

            cached = live_composite.cached_image_u8_payload(
                mask, int(mask.size[0]), int(mask.size[1])
            ) if mask is not None else None
            if cached is not None:
                payload = (int(mask.size[0]), int(mask.size[1]), cached)
        except Exception:
            payload = None
        if payload is None:
            payload = _read_image_pixels_u8(mask)
        digest = _payload_sha256_u8(payload)
        if digest:
            digests[identity] = digest
    return digests

def _review_save_fingerprint(material) -> dict[str, object]:
    """Small proof that a Review image represents the current editable stack."""
    source = _session_source_path(material) or _source_path(material)
    bucket = _ACTIVATED_LAYERS.get(_session_material_key(material), {}) or {}
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    metadata_changes = _metadata_changes(material)
    current_metadata = list(metadata_changes.get("current") or _metadata_state(material))
    mask_dirty_identities = list(metadata_changes.get("mask_dirty_identities") or [])
    pixel_digests: dict[str, str] = {}
    for index, layer in enumerate(layers):
        if not _layer_is_paintable(layer):
            continue
        layer_id = _layer_id(layer, index)
        entry = bucket.get(layer_id, {}) or {}
        digest = _payload_sha256_u8(entry.get("current_payload"))
        if not digest:
            continue
        record_index = _source_record_index(layer)
        identity = "record:" + str(record_index) if record_index >= 0 else "id:" + str(layer_id)
        pixel_digests[identity] = digest
    return {
        "version": 1,
        "source_path": str(source or ""),
        "source_signature": _manual_composite_signature(source),
        "metadata": current_metadata,
        "pixel_digests": pixel_digests,
        "mask_pixel_digests": _mask_pixel_digests(material, mask_dirty_identities),
    }


def _stamp_review_save_fingerprint(material, image, result) -> None:
    if material is None or image is None or not isinstance(result, dict):
        return
    try:
        proof = _review_save_fingerprint(material)
        proof["exact"] = bool(
            result.get("ok", False)
            and not list(result.get("fallback_layers", []) or [])
            and int(result.get("fallback_changed_pixels", 0) or 0) == 0
            and int(result.get("unrecoverable_pixels", 0) or 0) == 0
        )
        proof["width"] = int(result.get("width", image.size[0]) or image.size[0])
        proof["height"] = int(result.get("height", image.size[1]) or image.size[1])
        image["sps_lightweight_composite_save_fingerprint"] = json.dumps(
            proof, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        )
    except Exception:
        try:
            if "sps_lightweight_composite_save_fingerprint" in image:
                del image["sps_lightweight_composite_save_fingerprint"]
        except Exception:
            pass

def _cache_review_save_payload_u8(material, image, pixels) -> None:
    """Cache one contiguous 8-bit RGBA payload; component planes remain zero-copy views."""
    key = _session_material_key(material)
    if not key or image is None:
        return
    try:
        import numpy as np

        width, height = int(image.size[0]), int(image.size[1])
        proof = str(image.get("sps_lightweight_composite_save_fingerprint", "") or "")
        if not proof or width <= 1 or height <= 1:
            _REVIEW_SAVE_PAYLOAD_CACHE.pop(key, None)
            return
        rgba = np.asarray(pixels)
        if rgba.dtype == np.uint8 and rgba.flags.c_contiguous:
            encoded = rgba.reshape((height, width, 4))
        else:
            source = np.asarray(pixels, dtype=np.float32).reshape((height, width, 4))
            encoded = np.empty((height, width, 4), dtype=np.uint8)
            rows_per_chunk = max(1, min(128, (4 * 1024 * 1024) // max(1, width * 16)))
            for row in range(0, height, rows_per_chunk):
                row_end = min(height, row + rows_per_chunk)
                scaled = np.empty_like(source[row:row_end], dtype=np.float32)
                np.multiply(source[row:row_end], 255.0, out=scaled)
                np.add(scaled, 0.5, out=scaled)
                np.clip(scaled, 0.0, 255.0, out=scaled)
                encoded[row:row_end] = scaled.astype(np.uint8, copy=False)
        # PSD rows are top-to-bottom.  One row-reversed contiguous allocation is
        # retained instead of four independent full-document planes.
        rgba_top_down = np.ascontiguousarray(encoded[::-1])
        _REVIEW_SAVE_PAYLOAD_CACHE.clear()
        stored = _cache_store(
            _REVIEW_SAVE_PAYLOAD_CACHE,
            key,
            {
                "image": str(getattr(image, "name", "") or ""),
                "proof": proof,
                "width": width,
                "height": height,
                "rgba_top_down": rgba_top_down,
            },
            document_generation=str(material.get("sps_document_generation", "global") or "global"),
        )
        image["sps_lightweight_review_payload_cached"] = bool(stored)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError, MemoryError):
        _REVIEW_SAVE_PAYLOAD_CACHE.pop(key, None)
        try:
            image["sps_lightweight_review_payload_cached"] = False
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass



def _cached_review_save_main_planes(material, image):
    """Return four zero-copy component views while the exact proof still matches."""
    key = _session_material_key(material)
    cached = _REVIEW_SAVE_PAYLOAD_CACHE.get(key, {}) or {}
    if not cached or image is None:
        return None
    try:
        import numpy as np

        proof = str(image.get("sps_lightweight_composite_save_fingerprint", "") or "")
        width, height = int(image.size[0]), int(image.size[1])
        if (
            str(cached.get("image", "") or "") != str(getattr(image, "name", "") or "")
            or str(cached.get("proof", "") or "") != proof
            or int(cached.get("width", 0) or 0) != width
            or int(cached.get("height", 0) or 0) != height
        ):
            return None
        rgba = np.asarray(cached.get("rgba_top_down"))
        if rgba.dtype != np.uint8 or rgba.shape != (height, width, 4):
            return None
        return tuple(rgba[:, :, component] for component in range(4))
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return None


def _read_image_pixels_u8(image):
    if image is None:
        return None
    try:
        import numpy as np

        width, height = int(image.size[0]), int(image.size[1])
        if width <= 1 or height <= 1:
            return None
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        return (
            width,
            height,
            np.ascontiguousarray(
                np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
                dtype=np.uint8,
            ),
        )
    except Exception:
        return None


def _payload_pixels_u8(payload, width: int, height: int):
    if not isinstance(payload, tuple) or len(payload) != 3:
        return None
    try:
        import numpy as np

        payload_width, payload_height, pixels = payload
        if int(payload_width) != int(width) or int(payload_height) != int(height):
            return None
        return np.asarray(pixels, dtype=np.uint8).reshape((int(height), int(width), 4))
    except Exception:
        return None


def _saved_composite_base(material, *, force: bool = False):
    """Return the exact Photoshop-rendered merged image as an immutable base."""
    path = _source_path(material)
    if not path or not Path(path).is_file():
        return None, {"ok": False, "reason": "source_psd_missing"}
    signature = _manual_composite_signature(path)
    material_name = str(getattr(material, "name", "") or "")
    cached = _COMPOSITE_BASE_CACHE.get(material_name, {}) or {}
    if (
        not force
        and str(cached.get("signature", "") or "") == signature
        and cached.get("pixels") is not None
    ):
        return cached, {"ok": True, "cached": True, "elapsed_ms": 0.0, "path": path}
    start = time.perf_counter()
    try:
        import numpy as np

        decode_backend = "psd_io"
        pillow_error = ""
        pixels = None
        width = 0
        height = 0
        try:
            from PIL import Image as PILImage

            with PILImage.open(path) as pil_image:
                if str(getattr(pil_image, "format", "") or "").upper() != "PSD":
                    raise ValueError("pillow_not_psd")
                width, height = (int(value) for value in pil_image.size)
                if width <= 1 or height <= 1:
                    raise ValueError("pillow_dimensions_invalid")
                merged_array = np.asarray(pil_image.convert("RGBA"), dtype=np.uint8)
                if merged_array.shape != (height, width, 4):
                    raise ValueError("pillow_rgba_shape_invalid")
                # Pillow rows are top-to-bottom; Blender Image.pixels and the
                # existing PSD decoder use bottom-to-top rows.
                pixels = np.ascontiguousarray(merged_array[::-1])
                decode_backend = "pillow_exact_rgba_v267"
        except Exception as exc:
            pillow_error = repr(exc)[:256]
            from . import psd_io
            _bind_explicit_psd_api(psd_io)

            document = psd_io.read_psd_merged_preview_u8(path)
            width = int(document.get("width", 0) or 0)
            height = int(document.get("height", 0) or 0)
            merged = document.get("merged")
            if width <= 1 or height <= 1 or merged is None:
                return None, {"ok": False, "reason": "embedded_composite_unavailable", "path": path}
            merged_array = np.asarray(merged)
            if merged_array.dtype == np.uint8:
                pixels = np.ascontiguousarray(merged_array.reshape((height, width, 4)))
            else:
                pixels = np.ascontiguousarray(
                    np.clip(
                        np.floor(merged_array.astype(np.float32, copy=False).reshape((height, width, 4)) * 255.0 + 0.5),
                        0.0,
                        255.0,
                    ),
                    dtype=np.uint8,
                )
        cached = {
            "signature": signature,
            "path": str(path),
            "width": int(width),
            "height": int(height),
            "pixels": pixels,
            "decode_backend": decode_backend,
        }
        # A merged PSD base can be hundreds of MiB.  Retain only the current
        # document; other materials are decoded again on their next explicit
        # operation instead of accumulating an unbounded process cache.
        _COMPOSITE_BASE_CACHE.clear()
        _cache_store(_COMPOSITE_BASE_CACHE, material_name, cached)
        elapsed_ms = round((time.perf_counter() - start) * 1000.0, 3)
        return cached, {
            "ok": True,
            "cached": False,
            "elapsed_ms": elapsed_ms,
            "path": path,
            "width": width,
            "height": height,
            "decode_backend": decode_backend,
            "pillow_error": pillow_error,
        }
    except Exception as exc:
        return None, {
            "ok": False,
            "reason": "embedded_composite_exception",
            "error": repr(exc)[:512],
            "path": path,
        }


def _payloads_match_exactly(left, right) -> bool:
    if left is right and left is not None:
        return True
    if (
        not isinstance(left, tuple)
        or not isinstance(right, tuple)
        or len(left) != 3
        or len(right) != 3
    ):
        return False
    try:
        import numpy as np

        left_width, left_height, left_pixels = left
        right_width, right_height, right_pixels = right
        if (
            int(left_width) != int(right_width)
            or int(left_height) != int(right_height)
        ):
            return False
        return bool(
            np.array_equal(
                np.asarray(left_pixels, dtype=np.uint8),
                np.asarray(right_pixels, dtype=np.uint8),
            )
        )
    except Exception:
        return False


def _review_matches_saved_psd(material) -> tuple[bool, dict[str, object]]:
    """Conservatively prove that the embedded PSD composite is still current."""
    if material is None or _document_kind(material) != "LAYERED":
        return False, {"reason": "not_layered_document"}
    try:
        raw_baseline = str(material.get(_METADATA_BASELINE_KEY, "") or "")
    except Exception:
        raw_baseline = ""
    if not raw_baseline:
        return False, {"reason": "metadata_baseline_missing"}
    metadata = _metadata_changes(material)
    if bool(metadata.get("dirty", False)):
        return False, {
            "reason": "metadata_changed",
            "metadata": bool(metadata.get("metadata", False)),
            "structure": bool(metadata.get("structure", False)),
            "order": bool(metadata.get("order", False)),
            "mask": bool(metadata.get("mask", False)),
        }

    settings = _settings(material)
    layers = list(
        getattr(settings, "layers", ()) if settings is not None else ()
    )
    if not layers:
        return False, {"reason": "layer_stack_missing"}
    current_ids = {
        _layer_id(layer, index)
        for index, layer in enumerate(layers)
    }
    for index, layer in enumerate(layers):
        if _layer_is_paintable(layer) and _source_record_index(layer) < 0:
            return False, {
                "reason": "recordless_layer_present",
                "layer_id": _layer_id(layer, index),
            }

    bucket = (
        _ACTIVATED_LAYERS.get(
            str(getattr(material, "name", "") or ""),
            {},
        )
        or {}
    )
    checked = 0
    for layer_id, entry in bucket.items():
        if str(layer_id or "") not in current_ids or not isinstance(entry, dict):
            continue
        if list(entry.get("external_dirty_rects") or ()):
            return False, {
                "reason": "external_pixels_pending",
                "layer_id": str(layer_id or ""),
            }
        baseline = (
            entry.get("preview_baseline_payload")
            or entry.get("baseline_payload")
        )
        current = entry.get("current_payload")
        if current is not None:
            checked += 1
            if baseline is None or not _payloads_match_exactly(baseline, current):
                return False, {
                    "reason": "layer_pixels_changed",
                    "layer_id": str(layer_id or ""),
                }
            continue
        image = bpy.data.images.get(str(entry.get("image", "") or ""))
        if image is None:
            continue
        for key in (
            "smart_paint_suite_direct_layer_dirty",
            "smart_paint_suite_bodypaint_direct_authoritative",
            "smart_paint_suite_painted_since_last_projection",
            "smart_paint_suite_user_edited",
            "sps_v2_native_paint_dirty",
        ):
            try:
                if bool(image.get(key, False)):
                    return False, {
                        "reason": "layer_dirty_marker",
                        "layer_id": str(layer_id or ""),
                        "marker": key,
                    }
            except Exception:
                continue
    return True, {
        "reason": "saved_psd_exact",
        "checked_materialized_layers": int(checked),
    }


def _saved_psd_review_image(material, base, base_result, started_at):
    """Upload or reuse the embedded merged preview without recomposing rows."""
    try:
        import numpy as np

        width = int(base["width"])
        height = int(base["height"])
        signature = str(base.get("signature", "") or "")
        preview_name = (
            f"SPS_{str(getattr(material, 'name', '') or 'Material')}"
            "_CurrentComposite"
        )
        image = bpy.data.images.get(preview_name)
        # A generated image can be serialized into the .blend after a stale or
        # failed preview. Its custom signature survives even when its pixels are
        # later restored as opaque black. Re-uploading 4K RGBA costs only a few
        # hundred milliseconds and keeps explicit Review deterministic.
        cached_image = False
        upload_started = time.perf_counter()
        if not cached_image:
            if image is None:
                image = bpy.data.images.new(
                    preview_name,
                    width=width,
                    height=height,
                    alpha=True,
                    float_buffer=False,
                )
            elif int(image.size[0]) != width or int(image.size[1]) != height:
                image.scale(width, height)
            # Mutating generated-image display metadata after foreach_set makes
            # Blender reinitialize its storage to opaque black. Configure the
            # display interpretation first, then make pixel upload the last write.
            image.alpha_mode = "STRAIGHT"
            image.colorspace_settings.name = "sRGB"
            pixels = np.asarray(base["pixels"], dtype=np.uint8).reshape(
                (height, width, 4)
            )
            rgba = np.ascontiguousarray(
                pixels.astype(np.float32) * (1.0 / 255.0),
                dtype=np.float32,
            )
            image.pixels.foreach_set(rgba.reshape((-1,)))
            image.update()
        image["smart_paint_suite_lightweight_manual_composite"] = True
        image["sps_lightweight_composite_signature"] = signature
        image["sps_lightweight_composite_source"] = str(
            base.get("path", "") or ""
        )
        image["sps_lightweight_composite_saved_only"] = True
        image["sps_lightweight_composite_exact_changed_pixels"] = 0
        image["sps_lightweight_composite_fallback_changed_pixels"] = 0
        finished_at = time.perf_counter()
        result = {
            "ok": True,
            "saved_source_exact": True,
            "cached_base": bool(base_result.get("cached", False)),
            "cached_image": bool(cached_image),
            "elapsed_ms": round((finished_at - started_at) * 1000.0, 3),
            "path": str(base.get("path", "") or ""),
            "width": width,
            "height": height,
            "exact_layers": [],
            "exact_changed_pixels": 0,
            "fallback_layers": [],
            "fallback_changed_pixels": 0,
            "unrecoverable_pixels": 0,
            "direct_stack": False,
            "direct_stack_elapsed_ms": 0.0,
            "exact_reordered_top_chain": False,
            "exact_recordless_layers": [],
            "exact_source_records": [],
            "phase_ms": {
                "base": float(base_result.get("elapsed_ms", 0.0) or 0.0),
                "image_upload": round(
                    (finished_at - upload_started) * 1000.0,
                    3,
                ),
            },
        }
        _stamp_review_save_fingerprint(material, image, result)
        _trace_lightweight(
            "lightweight_current_composite_saved_source",
            material=material,
            **result,
        )
        return image, result
    except Exception as exc:
        return None, {
            "ok": False,
            "reason": "saved_source_preview_exception",
            "error": repr(exc)[:512],
            "path": str(base.get("path", "") or ""),
        }


def _preview_layer_state(material, layer, index: int, entry):
    if not isinstance(entry, dict):
        return None
    image = bpy.data.images.get(str(entry.get("image", "") or ""))
    # The active canvas is snapshotted once at preview entry, and inactive
    # canvases are snapshotted when switching away. Reuse those payloads to
    # avoid a second 64 MiB foreach_get on every explicit review click.
    current_payload = entry.get("current_payload")
    if current_payload is None:
        current_payload = _read_image_pixels_u8(image)
    if not isinstance(current_payload, tuple) or len(current_payload) != 3:
        return None
    width, height = int(current_payload[0]), int(current_payload[1])
    baseline_payload = entry.get("preview_baseline_payload") or entry.get("baseline_payload")
    baseline = _payload_pixels_u8(baseline_payload, width, height)
    current = _payload_pixels_u8(current_payload, width, height)
    if baseline is None or current is None:
        return None
    entry["current_payload"] = current_payload
    return {
        "layer": layer,
        "index": int(index),
        "layer_id": _layer_id(layer, index),
        "record_index": int(entry.get("record_index", _source_record_index(layer))),
        "baseline": baseline,
        "current": current,
        "old_enabled": bool(entry.get("preview_enabled", True)),
        "old_opacity": float(entry.get("preview_opacity", 1.0) or 0.0),
        "enabled": bool(getattr(layer, "enabled", True)),
        "opacity": float(getattr(layer, "opacity", 1.0) or 0.0),
    }


def _source_review_layer_state(material, layer, index: int, entry, record, document, live_composite):
    """Return current state, decoding an untouched imported row only on review."""
    current = _preview_layer_state(material, layer, index, entry)
    if current is not None:
        return current
    if not isinstance(record, dict) or not isinstance(document, dict):
        return None
    pixels = live_composite._decode_record_u8(record, document)
    if pixels is None:
        return None
    return {
        "layer": layer,
        "index": int(index),
        "layer_id": _layer_id(layer, index),
        "record_index": int(record.get("record_index", _source_record_index(layer))),
        "baseline": pixels,
        "current": pixels,
        "old_enabled": bool(record.get("enabled", True)),
        "old_opacity": float(record.get("opacity", 1.0) or 0.0),
        "enabled": bool(getattr(layer, "enabled", True)),
        "opacity": float(getattr(layer, "opacity", 1.0) or 0.0),
    }


def _state_change_mask(state):
    import numpy as np

    baseline = state["baseline"]
    current = state["current"]
    metadata_changed = (
        bool(state["old_enabled"]) != bool(state["enabled"])
        or abs(float(state["old_opacity"]) - float(state["opacity"])) > 1.0e-6
    )
    if metadata_changed:
        return np.ones(baseline.shape[:2], dtype=bool)
    if baseline is current:
        return None
    return np.any(current != baseline, axis=2)


def _apply_top_normal_chain(output, states, changed_mask, *, apply_states=None):
    """Peel the saved top chain, then apply its current order plus new rows."""
    import numpy as np

    peel_states = list(states or ())
    current_states = list(apply_states if apply_states is not None else peel_states)
    current_by_id = {
        str(state.get("layer_id", "") or ""): state
        for state in current_states
    }
    changed_rows = np.flatnonzero(np.any(changed_mask, axis=1))
    changed_columns = np.flatnonzero(np.any(changed_mask, axis=0))
    if changed_rows.size <= 0 or changed_columns.size <= 0:
        return 0, 0
    x0, x1 = int(changed_columns[0]), int(changed_columns[-1]) + 1
    y0, y1 = int(changed_rows[0]), int(changed_rows[-1]) + 1
    epsilon = 1.0 / 1024.0
    exact_pixels = 0
    unrecoverable_pixels = 0
    tile_size = 512

    for tile_y0 in range(y0, y1, tile_size):
        tile_y1 = min(y1, tile_y0 + tile_size)
        for tile_x0 in range(x0, x1, tile_size):
            tile_x1 = min(x1, tile_x0 + tile_size)
            tile_changed = changed_mask[tile_y0:tile_y1, tile_x0:tile_x1]
            if not np.any(tile_changed):
                continue
            local_y, local_x = np.nonzero(tile_changed)
            global_y = local_y + tile_y0
            global_x = local_x + tile_x0
            saved = output[global_y, global_x].copy()
            out_a = saved[:, 3].copy()
            out_p = saved[:, :3] * out_a[:, None]
            unrecoverable = np.zeros(local_y.shape, dtype=bool)
            current_pixels = {}
            baseline_pixels = {}

            def selected_current(state):
                layer_id = str(state.get("layer_id", "") or "")
                pixels = current_pixels.get(layer_id)
                if pixels is None:
                    pixels = state["current"][global_y, global_x].astype(np.float32)
                    pixels *= 1.0 / 255.0
                    current_pixels[layer_id] = pixels
                return pixels

            def selected_baseline(state):
                layer_id = str(state.get("layer_id", "") or "")
                pixels = baseline_pixels.get(layer_id)
                if pixels is None:
                    if state["baseline"] is state["current"]:
                        pixels = selected_current(state)
                    else:
                        pixels = state["baseline"][global_y, global_x].astype(np.float32)
                        pixels *= 1.0 / 255.0
                    baseline_pixels[layer_id] = pixels
                return pixels

            for state in peel_states:
                old = selected_baseline(state)
                old_alpha = old[:, 3] * (
                    float(state["old_opacity"]) if state["old_enabled"] else 0.0
                )
                replacement = current_by_id.get(str(state.get("layer_id", "") or ""))
                if replacement is None:
                    new_alpha = 0.0
                else:
                    new = selected_current(replacement)
                    new_alpha = new[:, 3] * (
                        float(replacement["opacity"]) if replacement["enabled"] else 0.0
                    )
                denom = 1.0 - old_alpha
                opaque = denom <= epsilon
                unrecoverable |= opaque & (new_alpha < (1.0 - epsilon))
                safe = np.where(opaque, 1.0, denom)
                out_p = (out_p - old[:, :3] * old_alpha[:, None]) / safe[:, None]
                out_a = (out_a - old_alpha) / safe
                out_p[opaque] = 0.0
                out_a[opaque] = 0.0
                np.clip(out_p, 0.0, 1.0, out=out_p)
                np.clip(out_a, 0.0, 1.0, out=out_a)

            clip_base_alpha = {}
            for state in reversed(current_states):
                current = selected_current(state)
                source_alpha = current[:, 3] * (
                    float(state["opacity"]) if state["enabled"] else 0.0
                )
                mask_coverage = state.get("mask_coverage")
                if mask_coverage is not None:
                    source_alpha *= (
                        mask_coverage[global_y, global_x].astype(np.float32)
                        * (1.0 / 255.0)
                    )
                stack_key = str(state.get("stack_key", "") or "")
                if bool(state.get("clip_to_below", False)):
                    clip_base_key = str(state.get("clip_base_key", "") or "")
                    base_alpha = clip_base_alpha.get(clip_base_key)
                    if base_alpha is None:
                        unrecoverable |= source_alpha > epsilon
                        source_alpha = np.zeros_like(source_alpha)
                    else:
                        source_alpha *= base_alpha
                elif stack_key:
                    # Every consecutive clipped row keeps the same nearest
                    # non-clipped base, matching the Live shader contract.
                    clip_base_alpha[stack_key] = source_alpha.copy()
                source_p = current[:, :3] * source_alpha[:, None]
                out_p = source_p + out_p * (1.0 - source_alpha[:, None])
                out_a = source_alpha + out_a * (1.0 - source_alpha)

            rebuilt = np.zeros_like(saved)
            rebuilt[:, 3] = np.clip(out_a, 0.0, 1.0)
            nonzero = rebuilt[:, 3] > epsilon
            rebuilt[nonzero, :3] = np.clip(
                out_p[nonzero] / rebuilt[nonzero, 3, None],
                0.0,
                1.0,
            )
            apply = ~unrecoverable
            output[global_y[apply], global_x[apply]] = rebuilt[apply]
            exact_pixels += int(np.count_nonzero(apply))
            unrecoverable_pixels += int(np.count_nonzero(unrecoverable))

    return exact_pixels, unrecoverable_pixels


def _apply_approximate_layer_delta(output, state, changed_mask):
    """Best-effort fallback for an edited layer below unsupported effects."""
    import numpy as np

    if changed_mask is None:
        return 0
    changed_rows = np.flatnonzero(np.any(changed_mask, axis=1))
    changed_columns = np.flatnonzero(np.any(changed_mask, axis=0))
    if changed_rows.size <= 0 or changed_columns.size <= 0:
        return 0
    x0, x1 = int(changed_columns[0]), int(changed_columns[-1]) + 1
    y0, y1 = int(changed_rows[0]), int(changed_rows[-1]) + 1
    mask = changed_mask[y0:y1, x0:x1]
    saved = output[y0:y1, x0:x1].copy()
    old = state["baseline"][y0:y1, x0:x1].astype(np.float32) * (1.0 / 255.0)
    new = state["current"][y0:y1, x0:x1].astype(np.float32) * (1.0 / 255.0)
    old_a = old[:, :, 3] * (float(state["old_opacity"]) if state["old_enabled"] else 0.0)
    new_a = new[:, :, 3] * (float(state["opacity"]) if state["enabled"] else 0.0)
    saved_p = saved[:, :, :3] * saved[:, :, 3, None]
    out_p = np.clip(saved_p + new[:, :, :3] * new_a[:, :, None] - old[:, :, :3] * old_a[:, :, None], 0.0, 1.0)
    out_a = np.clip(saved[:, :, 3] + new_a - old_a, 0.0, 1.0)
    rebuilt = np.zeros_like(saved)
    rebuilt[:, :, 3] = out_a
    nonzero = out_a > (1.0 / 1024.0)
    rebuilt[:, :, :3][nonzero] = np.clip(out_p[nonzero] / out_a[nonzero, None], 0.0, 1.0)
    region = output[y0:y1, x0:x1]
    region[mask] = rebuilt[mask]
    output[y0:y1, x0:x1] = region
    return int(mask.sum())


def _sparse_saved_merge_review_supported(material) -> bool:
    """Return whether saved-merge peeling is exact for this flat stack."""
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    if not layers:
        return False
    for layer in layers:
        if not (
            _layer_is_paintable(layer)
            and _source_record_index(layer) >= 0
            and not bool(getattr(layer, "is_group", False))
            and str(getattr(layer, "layer_kind", "") or "").upper() != "GROUP"
            and str(getattr(layer, "blend_mode", "MIX") or "MIX").upper() in {"MIX", "NORMAL"}
            and not bool(getattr(layer, "clip_to_below", False))
            and str(getattr(layer, "mask_mode", "NONE") or "NONE").upper() == "NONE"
            and not str(getattr(layer, "mask_image", "") or "")
        ):
            return False
    return True


def _build_current_psd_composite_preview(material, *, force: bool = False):
    """Build an explicit, temporary review image from saved merged + live edits.

    Photoshop's embedded merged image remains the exact base for unsupported
    adjustment/fill layers. Only current session pixel changes are evaluated,
    and the common top NORMAL paint-layer chain is replaced exactly in a small
    changed region. No source PSD or paint canvas is modified.
    """
    start = time.perf_counter()
    _snapshot_canvas_before_layer_switch(material, "")
    if not force:
        saved_exact, saved_state = _review_matches_saved_psd(material)
        if saved_exact:
            saved_base, saved_result = _saved_composite_base(
                material,
                force=False,
            )
            if saved_base is not None and bool(saved_result.get("ok", False)):
                image, result = _saved_psd_review_image(
                    material,
                    saved_base,
                    saved_result,
                    start,
                )
                if image is not None and bool(result.get("ok", False)):
                    result["saved_source_reason"] = str(
                        saved_state.get("reason", "") or ""
                    )
                    result["checked_materialized_layers"] = int(
                        saved_state.get(
                            "checked_materialized_layers",
                            0,
                        )
                        or 0
                    )
                    return image, result
    direct_pixels = None
    if _sparse_saved_merge_review_supported(material):
        direct_result = {
            "ok": False,
            "reason": "sparse_saved_merge_review",
        }
    else:
        direct_result = {}
        try:
            from .mvp import live_composite

            direct_pixels, direct_result = live_composite.compose_current_stack_pixels(material, bpy.context)
        except Exception as exc:
            direct_result = {
                "ok": False,
                "reason": "current_direct_stack_exception",
                "error": repr(exc)[:300],
            }
    if direct_pixels is not None:
        base = {
            "signature": _manual_composite_signature(_source_path(material)),
            "path": _source_path(material),
            "width": int(direct_result.get("width", 0) or 0),
            "height": int(direct_result.get("height", 0) or 0),
            "pixels": direct_pixels,
            "base_kind": "current_direct_stack",
        }
        base_result = {"ok": True, "cached": False, "direct_stack": True}
    else:
        settings = _settings(material)
        has_isolated_group = any(
            (
                bool(getattr(layer, "is_group", False))
                or str(getattr(layer, "layer_kind", "") or "").upper() == "GROUP"
            )
            and str(getattr(layer, "blend_mode", "PASS_THROUGH") or "PASS_THROUGH").upper()
            != "PASS_THROUGH"
            for layer in (getattr(settings, "layers", ()) if settings is not None else ())
        )
        if has_isolated_group:
            # A saved-merge peel treats group children as flat rows.  Once an
            # isolated group cannot be evaluated exactly, that fallback would
            # apply folder opacity/masks per child and falsely claim a current
            # composite. Keep the restored visible layer instead.
            result = dict(direct_result or {})
            result["ok"] = False
            result["fail_closed"] = True
            result["reason"] = str(result.get("reason", "") or "isolated_group_review_unsupported")
            return None, result
        base, base_result = _saved_composite_base(material, force=force)
        if base is None:
            result = dict(base_result or {})
            result["direct_stack_reason"] = str(direct_result.get("reason", "") or "")
            return None, result
    base_ready_at = time.perf_counter()
    try:
        import numpy as np

        width, height = int(base["width"]), int(base["height"])
        output = np.asarray(base["pixels"], dtype=np.float32).reshape((height, width, 4)).copy() * (1.0 / 255.0)
        direct_stack = str(base.get("base_kind", "") or "") == "current_direct_stack"
        prepare_started_at = time.perf_counter()
        exact_apply_ms = 0.0
        fallback_apply_ms = 0.0
        if direct_stack:
            chain = []
            exact_layer_names = list(direct_result.get("layer_names", []) or [])
            exact_pixels = int(width * height)
            unrecoverable_pixels = 0
            fallback_layers = []
            fallback_pixels = 0
            exact_reordered = False
            exact_recordless_layers = []
            exact_source_records = list(direct_result.get("chain_records", []) or [])
        else:
            settings = _settings(material)
            layers = list(getattr(settings, "layers", ()) if settings is not None else ())
            bucket = _ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}
            try:
                from . import psd_io
                _bind_explicit_psd_api(psd_io)
                from .mvp import live_composite

                document = base.get("review_document")
                if not isinstance(document, dict):
                    document = psd_io.read_layered_psd_lazy(_source_path(material), decode_merged=False)
                records = {
                    int(record.get("record_index", -1)): record
                    for record in list(document.get("layers", []) or [])
                    if int(record.get("record_index", -1)) >= 0
                }
            except Exception:
                document = {}
                records = {}

            live_chain, live_chain_reason = live_composite._live_paint_chain(material)
            live_by_id = {
                str(item.get("layer_id", "") or ""): item
                for item in live_chain
            }

            def peel_row_supported(layer) -> bool:
                return bool(
                    _layer_is_paintable(layer)
                    and str(getattr(layer, "blend_mode", "MIX") or "MIX").upper() in {"MIX", "NORMAL"}
                    and not bool(getattr(layer, "clip_to_below", False))
                    and str(getattr(layer, "mask_mode", "NONE") or "NONE").upper() == "NONE"
                    and not str(getattr(layer, "mask_image", "") or "")
                )

            def recordless_review_row_supported(layer, index: int) -> bool:
                return bool(
                    _layer_is_paintable(layer)
                    and int(_source_record_index(layer)) < 0
                    and str(getattr(layer, "blend_mode", "MIX") or "MIX").upper() in {"MIX", "NORMAL"}
                    and _layer_id(layer, index) in live_by_id
                )

            def current_mask_coverage(layer, record_index: int, live_spec):
                coverage = None
                mask_sources = [(layer, int(record_index))] + [
                    (group.get("layer"), int(group.get("record_index", -1)))
                    for group in (live_spec or {}).get("ancestor_groups", ())
                ]
                for owner, owner_record_index in mask_sources:
                    owner_record = records.get(owner_record_index) if owner_record_index >= 0 else None
                    descriptor, mask_reason = live_composite._mask_descriptor_for_owner(
                        owner,
                        owner_record,
                        document,
                    )
                    if descriptor is None:
                        if mask_reason:
                            return None, str(mask_reason)
                        continue
                    if not bool(descriptor.get("active", False)):
                        continue
                    one = live_composite._decode_mask_descriptor_u8(descriptor, document)
                    if one is None:
                        return None, "review_mask_decode_failed"
                    if coverage is None:
                        coverage = one
                    else:
                        coverage = (
                            coverage.astype(np.uint16) * one.astype(np.uint16) + 127
                        ) // 255
                        coverage = np.ascontiguousarray(coverage, dtype=np.uint8)
                return coverage, ""

            source_rows = sorted(
                [
                    (int(_source_record_index(layer)), int(index), layer)
                    for index, layer in enumerate(layers)
                    if int(_source_record_index(layer)) >= 0
                ],
                key=lambda item: item[0],
                reverse=True,
            )
            peel_rows = []
            expected = source_rows[0][0] if source_rows else -1
            for record_index, index, layer in source_rows:
                if int(record_index) != int(expected):
                    break
                if not peel_row_supported(layer):
                    break
                peel_rows.append((record_index, index, layer))
                expected -= 1

            peel_states = []
            for record_index, index, layer in peel_rows:
                layer_id = _layer_id(layer, index)
                state = _source_review_layer_state(
                    material,
                    layer,
                    index,
                    bucket.get(layer_id),
                    records.get(record_index),
                    document,
                    live_composite,
                )
                if state is None:
                    break
                peel_states.append(state)

            peel_ids = [str(state["layer_id"] or "") for state in peel_states]
            peel_records = [int(state["record_index"]) for state in peel_states]
            peel_id_set = set(peel_ids)
            current_rows = []
            if peel_states and len(peel_states) == len(peel_rows):
                for index in range(len(layers) - 1, -1, -1):
                    layer = layers[index]
                    record_index = int(_source_record_index(layer))
                    layer_id = _layer_id(layer, index)
                    if record_index >= 0:
                        if not peel_row_supported(layer) or layer_id not in peel_id_set:
                            break
                    elif not recordless_review_row_supported(layer, index):
                        break
                    current_rows.append((record_index, index, layer))

            current_source_ids = [
                _layer_id(layer, index)
                for record_index, index, layer in current_rows
                if int(record_index) >= 0
            ]
            exact_current_top = bool(
                peel_states
                and len(current_source_ids) == len(peel_ids)
                and set(current_source_ids) == peel_id_set
            )
            peel_by_id = {str(state["layer_id"] or ""): state for state in peel_states}
            current_states = []
            if exact_current_top:
                for record_index, index, layer in current_rows:
                    layer_id = _layer_id(layer, index)
                    state = peel_by_id.get(layer_id)
                    if state is None:
                        state = _preview_layer_state(material, layer, index, bucket.get(layer_id))
                    if state is None:
                        exact_current_top = False
                        current_states = []
                        break
                    state = dict(state)
                    live_spec = live_by_id.get(layer_id)
                    if live_spec is None:
                        exact_current_top = False
                        current_states = []
                        break
                    state["stack_key"] = str(live_spec.get("stack_key", "") or "")
                    state["clip_to_below"] = bool(live_spec.get("clip_to_below", False))
                    state["clip_base_key"] = str(live_spec.get("clip_base_key", "") or "")
                    enabled = bool(state.get("enabled", True))
                    opacity = float(state.get("opacity", 1.0) or 0.0)
                    for group in live_spec.get("ancestor_groups", ()):
                        group_layer = group.get("layer")
                        enabled = enabled and bool(getattr(group_layer, "enabled", True))
                        opacity *= float(getattr(group_layer, "opacity", 1.0) or 0.0)
                    state["enabled"] = bool(enabled)
                    state["opacity"] = max(0.0, min(1.0, float(opacity)))
                    coverage, mask_reason = current_mask_coverage(
                        layer,
                        record_index,
                        live_spec,
                    )
                    if mask_reason:
                        exact_current_top = False
                        current_states = []
                        break
                    state["mask_coverage"] = coverage
                    current_states.append(state)
            if exact_current_top:
                current_stack_keys = {
                    str(state.get("stack_key", "") or "")
                    for state in current_states
                }
                if any(
                    bool(state.get("clip_to_below", False))
                    and str(state.get("clip_base_key", "") or "") not in current_stack_keys
                    for state in current_states
                ):
                    exact_current_top = False
                    current_states = []
            if not exact_current_top:
                current_states = list(peel_states)

            chain = list(current_states)

            changed_mask = np.zeros((height, width), dtype=bool)
            unique_states = {
                str(state["layer_id"] or ""): state
                for state in list(peel_states) + list(current_states)
            }
            for state in unique_states.values():
                if state["baseline"].shape[:2] != (height, width):
                    continue
                state["changed_mask"] = _state_change_mask(state)
                if state["changed_mask"] is not None:
                    changed_mask |= state["changed_mask"]
            exact_reordered = bool(exact_current_top and current_source_ids != peel_ids)
            if exact_reordered:
                for state in peel_states:
                    if bool(state["old_enabled"]) and float(state["old_opacity"]) > 0.0:
                        changed_mask |= state["baseline"][:, :, 3] > 0
                for state in current_states:
                    if bool(state["enabled"]) and float(state["opacity"]) > 0.0:
                        changed_mask |= state["current"][:, :, 3] > 0
            exact_apply_started_at = time.perf_counter()
            exact_pixels, unrecoverable_pixels = _apply_top_normal_chain(
                output,
                peel_states,
                changed_mask,
                apply_states=current_states,
            )
            exact_apply_ms = round((time.perf_counter() - exact_apply_started_at) * 1000.0, 3)

            exact_ids = {
                str(state["layer_id"] or "")
                for state in list(peel_states) + list(current_states)
            }
            fallback_layers = []
            fallback_pixels = 0
            fallback_started_at = time.perf_counter()
            for index, layer in enumerate(layers):
                lid = _layer_id(layer, index)
                if lid in exact_ids or lid not in bucket or not _layer_is_paintable(layer):
                    continue
                state = _preview_layer_state(material, layer, index, bucket.get(lid))
                if state is None or state["baseline"].shape[:2] != (height, width):
                    continue
                mask = _state_change_mask(state)
                count = _apply_approximate_layer_delta(output, state, mask)
                if count > 0:
                    fallback_layers.append(str(getattr(layer, "name", "") or lid))
                    fallback_pixels += int(count)
            fallback_apply_ms = round((time.perf_counter() - fallback_started_at) * 1000.0, 3)
            exact_layer_names = [
                str(getattr(state["layer"], "name", "") or "")
                for state in current_states
            ]
            exact_recordless_layers = [
                str(getattr(state["layer"], "name", "") or state["layer_id"])
                for state in current_states
                if int(state.get("record_index", -1)) < 0
            ]
            exact_source_records = peel_records

        prepare_done_at = time.perf_counter()
        preview_name = f"SPS_{str(getattr(material, 'name', '') or 'Material')}_CurrentComposite"
        image = bpy.data.images.get(preview_name)
        if image is None:
            image = bpy.data.images.new(preview_name, width=width, height=height, alpha=True, float_buffer=False)
        elif int(image.size[0]) != width or int(image.size[1]) != height:
            image.scale(width, height)
        image.alpha_mode = "STRAIGHT"
        image.colorspace_settings.name = "sRGB"
        image.pixels.foreach_set(np.ascontiguousarray(np.clip(output, 0.0, 1.0).reshape((-1,)), dtype=np.float32))
        image.update()
        image["smart_paint_suite_lightweight_manual_composite"] = True
        image["sps_lightweight_composite_signature"] = str(base.get("signature", "") or "")
        image["sps_lightweight_composite_source"] = str(base.get("path", "") or "")
        image["sps_lightweight_composite_saved_only"] = False
        image["sps_lightweight_composite_exact_changed_pixels"] = int(exact_pixels)
        image["sps_lightweight_composite_fallback_changed_pixels"] = int(fallback_pixels)
        finished_at = time.perf_counter()
        elapsed_ms = round((finished_at - start) * 1000.0, 3)
        result = {
            "ok": True,
            "cached_base": bool(base_result.get("cached", False)),
            "elapsed_ms": elapsed_ms,
            "path": str(base.get("path", "") or ""),
            "width": width,
            "height": height,
            "exact_layers": exact_layer_names,
            "exact_changed_pixels": int(exact_pixels),
            "fallback_layers": fallback_layers,
            "fallback_changed_pixels": int(fallback_pixels),
            "unrecoverable_pixels": int(unrecoverable_pixels),
            "direct_stack": bool(direct_stack),
            "direct_stack_elapsed_ms": float(direct_result.get("elapsed_ms", 0.0) or 0.0),
            "exact_reordered_top_chain": bool(exact_reordered),
            "exact_recordless_layers": exact_recordless_layers,
            "exact_source_records": exact_source_records,
            "phase_ms": {
                "base": round((base_ready_at - start) * 1000.0, 3),
                "output_convert": round((prepare_started_at - base_ready_at) * 1000.0, 3),
                "prepare_and_apply": round((prepare_done_at - prepare_started_at) * 1000.0, 3),
                "exact_apply": float(exact_apply_ms),
                "fallback_apply": float(fallback_apply_ms),
                "image_upload": round((finished_at - prepare_done_at) * 1000.0, 3),
            },
        }
        _stamp_review_save_fingerprint(material, image, result)
        _cache_review_save_payload_u8(material, image, output)
        _trace_lightweight("lightweight_current_composite_built", material=material, **result)
        return image, result
    except Exception as exc:
        return None, {
            "ok": False,
            "reason": "current_composite_exception",
            "error": repr(exc)[:512],
            "path": str(base.get("path", "") or ""),
        }


def _bind_manual_composite_display(material, image, context=None) -> bool:
    """Bind a read-only review texture without changing the paint canvas."""
    if material is None or image is None:
        return False
    tree, principled = _principled_nodes(material)
    if tree is None:
        return False
    try:
        node = tree.nodes.get(_MANUAL_COMPOSITE_NODE)
        if node is None or str(getattr(node, "type", "") or "") != "TEX_IMAGE":
            node = tree.nodes.new("ShaderNodeTexImage")
            node.name = _MANUAL_COMPOSITE_NODE
            node.location = (-260.0, 220.0)
        node.label = "Smart Paint Current Composite Review"
        node.image = image
        node.interpolation = "Linear"
        node.hide = False
        node["sps_lightweight_manual_composite_display"] = True
        for bsdf in principled:
            color_socket = bsdf.inputs.get("Base Color")
            color_output = node.outputs.get("Color")
            if color_socket is not None and color_output is not None:
                for link in list(getattr(color_socket, "links", ()) or ()):
                    tree.links.remove(link)
                tree.links.new(color_output, color_socket)
            alpha_socket = bsdf.inputs.get("Alpha")
            alpha_output = node.outputs.get("Alpha")
            if alpha_socket is not None and alpha_output is not None:
                for link in list(getattr(alpha_socket, "links", ()) or ()):
                    tree.links.remove(link)
                tree.links.new(alpha_output, alpha_socket)
        material["sps_lightweight_display_mode"] = "COMPOSITE_PREVIEW"
        material["sps_lightweight_composite_image"] = str(getattr(image, "name", "") or "")
        # Material Output may show the review image, but Blender's native Image
        # Paint target is also influenced by the active Image Texture node. Keep
        # that ownership on the exact canvas node; making the review node active
        # can project a GUI stroke through the wrong image slot even when
        # tool_settings.image_paint.canvas still reports the layer image.
        try:
            paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
            canvas = getattr(paint, "canvas", None) if paint is not None else None
            canvas_node = next(
                (
                    candidate
                    for candidate in tree.nodes
                    if candidate is not node
                    and str(getattr(candidate, "type", "") or "") == "TEX_IMAGE"
                    and getattr(candidate, "image", None) is canvas
                ),
                None,
            )
            if canvas_node is not None:
                tree.nodes.active = canvas_node
        except Exception:
            pass
        material.update_tag()
        tree.update_tag()
    except Exception:
        return False
    # Review images are display-only.  The native Image Paint canvas must stay
    # on the selected PSD layer so a preview can never become a save source.
    _ensure_material_display_shading(context)
    _show_image_in_editors(image, context, read_only=True)
    _tag_redraw(context)
    return True


def _restore_active_layer_display(material, context=None) -> bool:
    try:
        paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
        current = getattr(paint, "canvas", None) if paint is not None else None
        if (
            current is not None
            and str(current.get("smart_paint_suite_material", "") or "") == str(getattr(material, "name", "") or "")
            and bool(current.get("sps_mvp_native_canvas", False))
        ):
            return bool(_bind_active_layer_display(material, current, context))
    except Exception:
        pass
    try:
        image_name = str(material.get("sps_lightweight_active_image", "") or "")
    except Exception:
        image_name = ""
    image = bpy.data.images.get(image_name) if image_name else None
    if image is not None:
        return bool(_bind_active_layer_display(material, image, context))
    layer, index = _active_layer(material)
    if layer is None or index < 0 or not _layer_is_paintable(layer):
        return False
    result = activate_layer(context, material, index)
    return bool(result.get("ok", False))


def _live_composite_requested(material) -> bool:
    try:
        return str(material.get("sps_lightweight_display_mode", "") or "") == "LIVE_COMPOSITE"
    except Exception:
        return False


def _refresh_live_composite_if_enabled(material, context=None):
    if material is None or not _live_composite_requested(material):
        return None
    try:
        live_composite = _live_composite_module(import_if_missing=True)
        if live_composite is None:
            return {"ok": False, "reason": "live_composite_unavailable"}
        result = dict(live_composite.refresh(material, context) or {})
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError) as exc:
        result = {"ok": False, "reason": "live_composite_exception", "error": repr(exc)[:300]}
    if bool(result.get("ok", False)):
        _ensure_material_display_shading(context)
        _tag_redraw(context)
        return result
    try:
        live_composite = _live_composite_module(import_if_missing=False)
        if live_composite is not None:
            live_composite.disable(material)
            live_composite.clear_material_cache(material, remove_unused_images=False)
        material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return result


def _capture_psd_save_display_state(material, context=None) -> dict[str, object]:
    """Capture the requested display contract before a PSD save target sync."""
    try:
        mode = str(material.get("sps_lightweight_display_mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
    except Exception:
        mode = "ACTIVE_LAYER"
    image_overlay_requested = False
    try:
        from .mvp import image_editor_overlay

        image_overlay_requested = bool(image_editor_overlay.requested(material))
    except Exception:
        image_overlay_requested = False
    try:
        paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
        canvas = getattr(paint, "canvas", None) if paint is not None else None
        canvas_name = str(getattr(canvas, "name", "") or "") if canvas is not None else ""
    except Exception:
        canvas_name = ""
    return {
        "mode": mode,
        "image_overlay_requested": image_overlay_requested,
        "canvas_name": canvas_name,
    }


def _restore_psd_save_display_state(material, context=None, state=None, *, reason: str = "psd_save") -> dict[str, object]:
    """Restore the exact display request after PSD save success, cancel, or handled error."""
    state = dict(state or {})
    mode = str(state.get("mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
    ctx = context or getattr(bpy, "context", None)
    result: dict[str, object] = {"ok": True, "mode": mode, "reason": str(reason or "psd_save")}
    try:
        if material is None:
            return {"ok": False, "mode": mode, "reason": "material_missing"}
        if mode == "LIVE_COMPOSITE":
            material["sps_lightweight_display_mode"] = "LIVE_COMPOSITE"
            refreshed = _refresh_live_composite_if_enabled(material, ctx)
            result.update({
                "ok": bool(isinstance(refreshed, dict) and refreshed.get("ok", False)),
                "display_reason": str(
                    (refreshed or {}).get("reason", "live_composite_refresh_failed")
                    if isinstance(refreshed, dict)
                    else "live_composite_refresh_failed"
                ),
            })
        elif mode == "COMPOSITE_PREVIEW":
            material["sps_lightweight_display_mode"] = "COMPOSITE_PREVIEW"
            image, refreshed = _build_current_psd_composite_preview(material, force=True)
            rebound = bool(
                image is not None
                and isinstance(refreshed, dict)
                and refreshed.get("ok", False)
                and _bind_manual_composite_display(material, image, ctx)
            )
            result.update({
                "ok": rebound,
                "display_reason": str(
                    (refreshed or {}).get("reason", "composite_preview_refresh_failed")
                    if isinstance(refreshed, dict)
                    else "composite_preview_refresh_failed"
                ),
            })
        else:
            material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
            result["ok"] = bool(_restore_active_layer_display(material, ctx))
        try:
            from .mvp import image_editor_overlay

            if bool(state.get("image_overlay_requested", False)) and mode == "LIVE_COMPOSITE":
                overlay = image_editor_overlay.set_enabled(material, True)
                result["image_overlay_ok"] = bool(overlay.get("ok", False))
                result["image_overlay_reason"] = str(overlay.get("reason", "") or "")
            else:
                image_editor_overlay.set_enabled(material, False)
                result["image_overlay_ok"] = not bool(state.get("image_overlay_requested", False))
        except Exception as exc:
            result["image_overlay_ok"] = False
            result["image_overlay_reason"] = repr(exc)[:256]
        try:
            from .mvp import solid_view_overlay

            solid_view_overlay.sync_handler_state(ctx)
        except Exception:
            pass
        _tag_redraw(ctx)
        return result
    except Exception as exc:
        return {"ok": False, "mode": mode, "reason": "psd_save_display_restore_exception", "error": repr(exc)[:300]}


# 1.9.295: the layered save path had no display contract of its own.  Every PSD
# save entry point either dropped the requested drawing mode silently (panel
# save / save-as / Manager batch save) or actively demoted `Confirm` back to
# `Individual`, so `Live`, `Live: Image Composite` and `Confirm` stopped
# rendering after a save even though the enum value survived.  The capture and
# restore pair already existed for the BodyPaint writer in `psd_io`; the two
# functions below make it the boundary contract of the layered save itself so
# every caller inherits it exactly once.
_PSD_SAVE_DISPLAY_DEPTH = 0


def _begin_psd_save_display_contract(material, context=None):
    """Capture the requested display contract once per outermost layered save."""
    global _PSD_SAVE_DISPLAY_DEPTH
    depth = int(_PSD_SAVE_DISPLAY_DEPTH or 0)
    _PSD_SAVE_DISPLAY_DEPTH = depth + 1
    if depth:
        return None
    try:
        return _capture_psd_save_display_state(material, context)
    except Exception:
        return None


def _end_psd_save_display_contract(material, context, state, ok: bool):
    """Restore the captured contract after success, cancel, or handled error."""
    global _PSD_SAVE_DISPLAY_DEPTH
    _PSD_SAVE_DISPLAY_DEPTH = max(0, int(_PSD_SAVE_DISPLAY_DEPTH or 0) - 1)
    if state is None or _PSD_SAVE_DISPLAY_DEPTH:
        return None
    # Individual is an intentionally inert save contract.  In particular, an
    # ACTIVE_LAYER request with no Image Editor overlay must not rebind the
    # canvas, retarget an editor, relink nodes, toggle an overlay, or tag a
    # redraw merely because a PSD save completed.  The remaining display modes
    # have explicit restoration work below.
    try:
        captured_mode = str(state.get("mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
        captured_overlay = bool(state.get("image_overlay_requested", False))
    except Exception:
        captured_mode = "ACTIVE_LAYER"
        captured_overlay = False
    if captured_mode == "ACTIVE_LAYER" and not captured_overlay:
        return {
            "ok": bool(ok),
            "mode": "ACTIVE_LAYER",
            "reason": "psd_save_active_layer_noop",
        }
    try:
        return _restore_psd_save_display_state(
            material,
            context,
            state,
            reason="psd_save_success" if bool(ok) else "psd_save_not_completed",
        )
    except Exception:
        return None


def handle_layer_property_update(layer, context=None) -> None:
    """Record metadata dirtiness only; never schedule or compose from an update callback."""
    material = None
    try:
        owner = getattr(layer, "id_data", None)
        if isinstance(owner, bpy.types.Material):
            material = owner
    except (AttributeError, ReferenceError, TypeError):
        material = None
    if material is None:
        material = _resolve_material(context)
    if material is None:
        return None
    _mark_structure_dirty(material, reason="lightweight_layer_property_update")
    try:
        material["sps_explicit_composite_required"] = True
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    _tag_redraw(context)
    return None



def _store_exact_pixel_baseline(image):
    """Capture an independent 8-bit canvas baseline for PSD save decisions."""
    if image is None:
        return None
    try:
        import numpy as np

        width, height = int(image.size[0]), int(image.size[1])
        if width <= 1 or height <= 1:
            return None
        flat = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(flat)
        return (
            width,
            height,
            np.ascontiguousarray(
                np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
                dtype=np.uint8,
            ),
        )
    except Exception:
        return None


def _remember_activation(material, layer, index: int, image) -> None:
    material_name = str(getattr(material, "name", "") or "")
    lid = _layer_id(layer, index)
    try:
        record_index = int(getattr(layer, "psd_source_record_index", -1))
    except Exception:
        record_index = -1
    bucket = _ACTIVATED_LAYERS.setdefault(material_name, {})
    image_name = str(getattr(image, "name", "") or "")
    # Blender can reuse a materialized image datablock when another PSD with
    # the same layer names is opened.  Drop the old document identity before
    # this canvas can be considered by the dirty-only writer.
    for stale_lid, stale_entry in list(bucket.items()):
        if str(stale_lid or "") == lid:
            continue
        try:
            same_image = str((stale_entry or {}).get("image", "") or "") == image_name
            same_record = (
                int(record_index) >= 0
                and int((stale_entry or {}).get("record_index", -1)) == int(record_index)
            )
        except Exception:
            same_image = False
            same_record = False
        if same_image or same_record:
            bucket.pop(stale_lid, None)
            _ACTIVATED_LAYERS.reaccount(material_name)
    previous = dict(bucket.get(lid, {}) or {})
    try:
        image["smart_paint_suite_layer_id"] = lid
        image["smart_paint_suite_material"] = material_name
        if int(record_index) >= 0:
            image["sps_psd_source_order"] = int(record_index)
            image["sps_psd_source_ordinal"] = int(record_index)
            image["sps_psd_source_layer_index"] = int(record_index)
    except Exception:
        pass
    needs_post_bind_baseline = bool(previous.get("needs_post_bind_baseline", False))
    baseline_payload = previous.get("baseline_payload")
    baseline_exact = bool(
        previous.get("baseline_exact", False)
        and str(previous.get("image", "") or "") == image_name
        and baseline_payload is not None
    )
    if needs_post_bind_baseline:
        # Texture Paint binding can normalize a freshly assigned byte image.
        # Anchor the save baseline after every binding/display step, but only
        # for a newly materialized canvas. Re-activation must retain the old
        # baseline so genuine user paint remains detectable.
        post_bind_payload = _store_exact_pixel_baseline(image)
        if post_bind_payload is not None:
            baseline_payload = post_bind_payload
            baseline_exact = True
    elif not baseline_exact:
        baseline_payload = _store_exact_pixel_baseline(image)
        baseline_exact = baseline_payload is not None
    preview_baseline_payload = (
        baseline_payload if needs_post_bind_baseline else previous.get("preview_baseline_payload")
    )
    if preview_baseline_payload is None:
        # This anchor intentionally survives successful v11 saves. The PSD
        # merged preview is not regenerated by the splice writer, so the manual
        # current-state review must continue applying every edit made since the
        # document was explicitly opened.
        preview_baseline_payload = baseline_payload
    bucket[lid] = {
        "layer_id": lid,
        "image": image_name,
        "record_index": int(record_index),
        "baseline_exact": bool(baseline_exact),
        "baseline_payload": baseline_payload,
        "preview_baseline_payload": preview_baseline_payload,
        "preview_enabled": bool(previous.get("preview_enabled", getattr(layer, "enabled", True))),
        "preview_opacity": float(previous.get("preview_opacity", getattr(layer, "opacity", 1.0)) or 0.0),
        "current_payload": previous.get("current_payload"),
        "current_payload_revision": previous.get("current_payload_revision"),
        "current_dirty_rect": list(previous.get("current_dirty_rect") or []),
        "current_dirty_pixels": int(previous.get("current_dirty_pixels", 0) or 0),
        "current_pixel_sha256": str(previous.get("current_pixel_sha256", "") or ""),
        "push_baseline_payload": previous.get("push_baseline_payload"),
        "external_dirty_rects": list(previous.get("external_dirty_rects") or []),
        "external_import_token": previous.get("external_import_token"),
        "external_import_generation": previous.get("external_import_generation"),
        "external_import_undo_guards": list(previous.get("external_import_undo_guards") or []),
        "external_import_baseline_payload": previous.get("external_import_baseline_payload"),
        "needs_post_bind_baseline": False,
    }
    _ACTIVATED_LAYERS.reaccount(material_name)


def _snapshot_canvas_before_layer_switch(material, target_layer_id: str):
    """Retain the current GENERATED canvas before target activation.

    Blender can rebuild the paint slot even when the user re-selects the same
    layer.  Snapshotting only cross-layer switches allowed that rebuild to
    replace a materialized PSD layer with its transparent generated buffer.
    """
    try:
        import numpy as np

        canvas = getattr(getattr(bpy.context.tool_settings, "image_paint", None), "canvas", None)
        if canvas is None:
            return None
        if str(canvas.get("smart_paint_suite_material", "") or "") != str(getattr(material, "name", "") or ""):
            return None
        if bool(canvas.get("sps_mvp_mask_canvas", False)):
            payload = _read_image_pixels_u8(canvas)
            cached = False
            if payload is not None:
                try:
                    from .mvp import live_composite

                    cached = bool(live_composite.cache_image_u8_payload(material, canvas, payload))
                except Exception:
                    cached = False
            _trace_lightweight(
                "lightweight_mask_canvas_snapshotted",
                material=material,
                image=str(getattr(canvas, "name", "") or ""),
                cached=bool(cached),
            )
            return None
        current_layer_id = str(canvas.get("smart_paint_suite_layer_id", "") or "")
        material_name = str(getattr(material, "name", "") or "")
        bucket = _ACTIVATED_LAYERS.get(material_name, {}) or {}
        if current_layer_id not in bucket:
            image_name = str(getattr(canvas, "name", "") or "")
            matches = [
                str(lid or "")
                for lid, entry in bucket.items()
                if str((entry or {}).get("image", "") or "") == image_name
            ]
            if len(matches) != 1:
                # A canvas left by another document/session is not an outgoing
                # MVP edit and must never enter this PSD's save set.
                return None
            current_layer_id = matches[0]
            try:
                canvas["smart_paint_suite_layer_id"] = current_layer_id
            except Exception:
                pass
        if not current_layer_id:
            return None
        width, height = int(canvas.size[0]), int(canvas.size[1])
        if width <= 1 or height <= 1:
            return None
        flat = np.empty(width * height * 4, dtype=np.float32)
        canvas.pixels.foreach_get(flat)
        pixels = np.ascontiguousarray(
            np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        bucket = _ACTIVATED_LAYERS.setdefault(material_name, {})
        previous = dict(bucket.get(current_layer_id, {}) or {})
        reference_payload = previous.get("current_payload")
        if reference_payload is None:
            reference_payload = previous.get("baseline_payload")
        reference_pixels = _payload_pixels_u8(reference_payload, width, height)
        pixels_changed = bool(
            reference_pixels is not None
            and not np.array_equal(pixels, reference_pixels)
        )
        cached_dirty_rect = list(previous.get("current_dirty_rect") or [])
        cached_dirty_pixels = int(previous.get("current_dirty_pixels", 0) or 0)
        cached_pixel_sha256 = str(previous.get("current_pixel_sha256", "") or "")
        try:
            blank_recordless = bool(
                int(previous.get("record_index", -1) or -1) < 0
                and bool(canvas.get("sps_lightweight_new_blank_layer", False))
            )
            baseline_pixels = _payload_pixels_u8(
                previous.get("baseline_payload"), width, height
            )
            if blank_recordless and baseline_pixels is not None and not bool(
                np.any(baseline_pixels[:, :, 3])
            ):
                alpha_changed = pixels[:, :, 3] != baseline_pixels[:, :, 3]
                changed_count = int(np.count_nonzero(alpha_changed))
                threshold = max(65536, (width * height) // 100)
                if 0 < changed_count <= threshold:
                    ys, xs = np.nonzero(alpha_changed)
                    cached_dirty_rect = [
                        int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1,
                    ]
                    cached_dirty_pixels = changed_count
                    cached_pixel_sha256 = hashlib.sha256(
                        memoryview(pixels).cast("B")
                    ).hexdigest()
                elif changed_count == 0:
                    cached_dirty_rect = []
                    cached_dirty_pixels = 0
                    cached_pixel_sha256 = ""
                else:
                    cached_dirty_rect = []
                    cached_dirty_pixels = 0
                    cached_pixel_sha256 = ""
        except Exception:
            cached_dirty_rect = []
            cached_dirty_pixels = 0
            cached_pixel_sha256 = ""
        if pixels_changed:
            # Native Texture Paint does not reliably stamp an Image ID property.
            # The live shader streams the active canvas directly, but once that
            # layer becomes inactive its premultiplied display proxy must receive
            # a new revision before the graph is rebuilt.
            try:
                canvas["smart_paint_suite_pixel_revision"] = int(
                    canvas.get("smart_paint_suite_pixel_revision", 0) or 0
                ) + 1
            except (AttributeError, KeyError, ReferenceError, RuntimeError, TypeError, ValueError):
                pass
            for key in (
                "smart_paint_suite_direct_layer_dirty",
                "smart_paint_suite_painted_since_last_projection",
                "smart_paint_suite_user_edited",
                "sps_v2_native_paint_dirty",
            ):
                try:
                    canvas[key] = True
                except Exception:
                    pass
        previous.update({
            "layer_id": current_layer_id,
            "image": str(getattr(canvas, "name", "") or ""),
            "current_payload": (width, height, pixels),
            "current_payload_revision": int(
                canvas.get("smart_paint_suite_pixel_revision", 0) or 0
            ),
            "current_dirty_rect": cached_dirty_rect,
            "current_dirty_pixels": int(cached_dirty_pixels),
            "current_pixel_sha256": cached_pixel_sha256,
            "live_display_pixels_changed": bool(pixels_changed),
        })
        bucket[current_layer_id] = previous
        _ACTIVATED_LAYERS.reaccount(material_name)
        return {
            "image": canvas,
            "pixels": pixels,
            "size": (width, height),
            "layer_id": current_layer_id,
            "pixels_changed": bool(pixels_changed),
            "started": time.perf_counter(),
        }
    except Exception:
        return None


def _restore_canvas_after_layer_switch(snapshot, material) -> None:
    if not isinstance(snapshot, dict):
        return
    image = snapshot.get("image")
    pixels = snapshot.get("pixels")
    if image is None or pixels is None:
        return
    try:
        width, height = map(int, snapshot.get("size", (0, 0)))
        if int(image.size[0]) != width or int(image.size[1]) != height:
            return
        import numpy as np

        rgba = np.asarray(pixels, dtype=np.float32).reshape((height, width, 4)) * (1.0 / 255.0)
        image.pixels.foreach_set(rgba.reshape((-1,)))
        image.update()
        _trace_lightweight(
            "lightweight_previous_canvas_restored",
            material=material,
            layer_id=str(snapshot.get("layer_id", "") or ""),
            image=str(getattr(image, "name", "") or ""),
            pixel_count=int(width * height),
            elapsed_ms=round((time.perf_counter() - float(snapshot.get("started", time.perf_counter()))) * 1000.0, 3),
        )
    except Exception as exc:
        _trace_lightweight(
            "lightweight_previous_canvas_restored",
            material=material,
            ok=False,
            layer_id=str(snapshot.get("layer_id", "") or ""),
            image=str(getattr(image, "name", "") or ""),
            error=repr(exc)[:300],
        )


def _restore_selected_canvas_snapshot(material, layer_id: str, image) -> bool:
    material_name = str(getattr(material, "name", "") or "")
    entry = (_ACTIVATED_LAYERS.get(material_name, {}) or {}).get(str(layer_id or ""), {}) or {}
    payload = entry.get("current_payload")
    if image is None or not isinstance(payload, tuple) or len(payload) != 3:
        return False
    try:
        import numpy as np

        width, height, pixels = payload
        width, height = int(width), int(height)
        if int(image.size[0]) != width or int(image.size[1]) != height:
            return False
        rgba = np.asarray(pixels, dtype=np.float32).reshape((height, width, 4)) * (1.0 / 255.0)
        image.pixels.foreach_set(rgba.reshape((-1,)))
        image.update()
        _trace_lightweight(
            "lightweight_selected_canvas_snapshot_restored",
            material=material,
            layer_id=str(layer_id or ""),
            image=str(getattr(image, "name", "") or ""),
            pixel_count=int(width * height),
        )
        return True
    except Exception as exc:
        _trace_lightweight(
            "lightweight_selected_canvas_snapshot_restored",
            material=material,
            ok=False,
            layer_id=str(layer_id or ""),
            image=str(getattr(image, "name", "") or ""),
            error=repr(exc)[:300],
        )
        return False


def activate_layer(context, material, layer_index: int) -> dict[str, object]:
    # Existing user/native keymaps are never searched or modified. Runtime
    # selection keymaps are exact add-on-keyconfig objects owned by the current
    # feature lease and are removed by their stored object identities only.
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    if not layers or not (0 <= int(layer_index) < len(layers)):
        return {"ok": False, "reason": "layer_not_found"}
    layer = layers[int(layer_index)]
    if not _layer_is_paintable(layer):
        return {"ok": False, "reason": "layer_not_paintable", "layer": str(getattr(layer, "name", "") or "")}
    layer_id = _layer_id(layer, int(layer_index))
    # Binding a different GENERATED image can make Blender recreate the
    # outgoing byte buffer.  Keep the exact pixels process-local and restore
    # both sides of the switch before rebuilding the live display graph.
    switch_snapshot = _snapshot_canvas_before_layer_switch(material, layer_id)
    try:
        settings.active_paint_channel = CHANNEL
    except Exception:
        pass
    start = time.perf_counter()
    try:
        from .mvp import paint_target

        result = dict(paint_target.activate(
            material=material,
            layer_index=int(layer_index),
            context=context,
            switch_to_paint=True,
        ) or {})
    except Exception as exc:
        return {"ok": False, "reason": "activation_exception", "error": repr(exc)[:512]}
    if not bool(result.get("ok", False)):
        return result
    _set_active_indices(settings, int(layer_index))
    image = bpy.data.images.get(str(result.get("image", "") or ""))
    if image is None:
        return {"ok": False, "reason": "activation_image_missing"}
    _restore_canvas_after_layer_switch(switch_snapshot, material)
    _restore_selected_canvas_snapshot(material, layer_id, image)
    live_requested = _live_composite_requested(material)
    live_result = None
    if live_requested:
        try:
            from .mvp import live_composite

            live_result = dict(live_composite.refresh(material, context) or {})
        except Exception as exc:
            live_result = {"ok": False, "reason": "live_composite_exception", "error": repr(exc)[:300]}
        display_ok = bool(live_result.get("ok", False))
        if not display_ok:
            try:
                live_composite.disable(material)
                live_composite.clear_material_cache(material, remove_unused_images=False)
            except Exception:
                pass
            display_ok = _bind_active_layer_display(material, image, context)
        else:
            try:
                material["sps_lightweight_active_image"] = str(getattr(image, "name", "") or "")
            except Exception:
                pass
            _ensure_material_display_shading(context)
    else:
        display_ok = _bind_active_layer_display(material, image, context)
    _remember_activation(material, layer, int(layer_index), image)
    retired_source_image = str(result.get("retired_source_image", "") or "")
    if retired_source_image:
        release_result = _release_retired_document_images(
            material,
            [retired_source_image],
            context,
        )
        result["retired_source_release"] = dict(release_result or {})
        _trace_lightweight(
            "lightweight_retired_lazy_proxy_released",
            material=material,
            source_image=retired_source_image,
            removed=int((release_result or {}).get("removed", 0) or 0),
            removed_pixels=int(
                (release_result or {}).get("removed_pixels", 0) or 0
            ),
        )
    try:
        from .mvp import selection_tools

        selection_tools.sync_for_material(material)
    except Exception:
        pass
    if _thumbnails_enabled(material):
        thumbnail_module = _thumbnail_module(import_if_missing=False)
        if thumbnail_module is not None:
            thumbnail_result = _ensure_layer_thumbnail(
                material, layer, int(layer_index), image=image, force=False
            )
            _trace_lightweight(
                "lightweight_thumbnail_generated",
                material=material,
                layer_id=_layer_id(layer, int(layer_index)),
                record_index=_source_record_index(layer),
                ok=bool(thumbnail_result.get("ok", False)),
                reason=str(thumbnail_result.get("reason", "") or ""),
                icon_id=int(thumbnail_result.get("icon_id", 0) or 0),
            )
    try:
        material["sps_lightweight_mode"] = True
        material["sps_lightweight_last_activation_ms"] = round((time.perf_counter() - start) * 1000.0, 3)
    except Exception:
        pass
    result["display_ok"] = bool(display_ok)
    if live_result is not None:
        result["live_composite_ok"] = bool(live_result.get("ok", False))
        result["live_composite_reason"] = str(live_result.get("reason", "") or "")
    result["elapsed_ms"] = round((time.perf_counter() - start) * 1000.0, 3)
    return result


def _first_paintable_index(material) -> int:
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    for index in range(len(layers) - 1, -1, -1):
        if _layer_is_paintable(layers[index]):
            return int(index)
    return -1


def _first_visible_paintable_index(material) -> int:
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    for index in range(len(layers) - 1, -1, -1):
        layer = layers[index]
        if _layer_is_paintable(layer) and bool(
            getattr(layer, "enabled", True)
        ):
            return int(index)
    return -1


def _resolved_layer_index(settings, requested: int = -1) -> int:
    try:
        count = len(settings.layers)
    except Exception:
        return -1
    if count <= 0:
        return -1
    try:
        index = int(requested)
    except Exception:
        index = -1
    if 0 <= index < count:
        return int(index)
    try:
        return max(0, min(int(getattr(settings, "active_layer_index", 0) or 0), count - 1))
    except Exception:
        return 0


def _unique_layer_name(settings, base: str) -> str:
    existing = {str(getattr(layer, "name", "") or "") for layer in getattr(settings, "layers", ()) or ()}
    stem = str(base or "Layer")
    if stem not in existing:
        return stem
    for number in range(2, 10000):
        candidate = f"{stem} {number}"
        if candidate not in existing:
            return candidate
    return f"{stem} {uuid.uuid4().hex[:6]}"


def _document_size(material) -> tuple[int, int]:
    settings = _settings(material)
    try:
        active_index = _resolved_layer_index(settings)
        active = settings.layers[active_index] if active_index >= 0 else None
        image = bpy.data.images.get(str(getattr(active, "base_color_image", "") or "")) if active is not None else None
        if image is not None and int(image.size[0]) > 1 and int(image.size[1]) > 1:
            return int(image.size[0]), int(image.size[1])
    except Exception:
        pass
    for entry in (_ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}).values():
        try:
            image = bpy.data.images.get(str((entry or {}).get("image", "") or ""))
            if image is not None and int(image.size[0]) > 1 and int(image.size[1]) > 1:
                return int(image.size[0]), int(image.size[1])
        except Exception:
            pass
    return 2048, 2048


def _configure_new_image(image, material, layer_id: str) -> None:
    if image is None:
        return
    try:
        image.generated_color = (1.0, 1.0, 1.0, 0.0)
    except Exception:
        pass
    for key, value in (
        ("smart_paint_suite_layer_image", True),
        ("smart_paint_suite_material", str(getattr(material, "name", "") or "")),
        ("smart_paint_suite_layer_id", str(layer_id or "")),
        ("smart_paint_suite_channel", CHANNEL),
        ("smart_paint_suite_clear_color", (1.0, 1.0, 1.0, 0.0)),
        ("smart_paint_suite_initialized_clear_color", (1.0, 1.0, 1.0, 0.0)),
        ("smart_paint_suite_intentionally_empty", True),
    ):
        try:
            image[key] = value
        except Exception:
            pass
    for key in (
        "smart_paint_suite_source_file",
        "smart_paint_suite_layered_source_path",
        "smart_paint_suite_raw_psd_layer",
        "smart_paint_suite_psd_layer",
        "smart_paint_suite_lazy_psd_pending",
        "smart_paint_suite_psd_materialized_clean",
        "smart_paint_suite_saved_psd_clean_boundary",
        "psd_source_record_index",
        "sps_psd_source_order",
        "sps_psd_source_ordinal",
        "sps_psd_source_layer_index",
    ):
        try:
            if key in image:
                del image[key]
        except Exception:
            pass


def _initialize_paint_layer(layer, *, name: str, layer_id: str, image_name: str, depth: int = 0) -> None:
    values = {
        "name": str(name or "Paint"),
        "layer_id": str(layer_id or ""),
        "psd_source_record_index": -1,
        "enabled": True,
        "layer_kind": "PAINT",
        "opacity": 1.0,
        "blend_mode": "MIX",
        "clip_to_below": False,
        "is_group": False,
        "group_depth": max(0, int(depth)),
        "base_color_image": str(image_name or ""),
        "mask_mode": "NONE",
        "mask_image": "",
    }
    for key, value in values.items():
        try:
            setattr(layer, key, value)
        except Exception:
            pass


def _initialize_adjustment_layer(
    layer,
    *,
    name: str,
    layer_id: str,
    adjustment_type: str,
    depth: int = 0,
) -> None:
    try:
        layer["sps_layer_stack_bulk_edit_in_progress"] = True
    except Exception:
        pass
    values = {
        "name": str(name or "Adjustment"),
        "layer_id": str(layer_id or ""),
        "psd_source_record_index": -1,
        "enabled": True,
        "layer_kind": "ADJUSTMENT",
        "adjustment_type": str(adjustment_type or "INVERT").upper(),
        "opacity": 1.0,
        "blend_mode": "MIX",
        "clip_to_below": False,
        "is_group": False,
        "group_depth": max(0, int(depth)),
        "base_color_image": "",
        "mask_mode": "NONE",
        "mask_image": "",
        "psd_raw_adjustment_tags": "",
        "psd_raw_layer_tags": "",
    }
    try:
        for key, value in values.items():
            setattr(layer, key, value)
    finally:
        try:
            del layer["sps_layer_stack_bulk_edit_in_progress"]
        except Exception:
            pass


def _move_layer_block(settings, index: int, direction: str) -> bool:
    """Move one row/folder block without importing the legacy operator module."""
    try:
        layers = settings.layers
        count = len(layers)
        index = _resolved_layer_index(settings, index)
        if count <= 0 or index < 0:
            return False

        def depth_at(pos: int) -> int:
            return max(0, int(getattr(layers[pos], "group_depth", 0) or 0))

        def is_group(pos: int) -> bool:
            layer = layers[pos]
            return bool(getattr(layer, "is_group", False)) or str(getattr(layer, "layer_kind", "") or "").upper() == "GROUP"

        start = index
        group_depth = depth_at(index)
        end = index + 1
        if is_group(index):
            while end < count and depth_at(end) > group_depth:
                end += 1

        if str(direction or "UP").upper() == "UP":
            if end >= count:
                return False
            next_depth = depth_at(end)
            if next_depth != group_depth:
                return False
            next_end = end + 1
            if is_group(end):
                while next_end < count and depth_at(next_end) > next_depth:
                    next_end += 1
            block_len = end - start
            for _ in range(block_len):
                layers.move(start, next_end - 1)
            _set_active_indices(settings, next_end - block_len)
            return True
        if start <= 0:
            return False
        target_start = start - 1
        while target_start > 0 and depth_at(target_start) > group_depth:
            target_start -= 1
        if depth_at(target_start) != group_depth:
            return False
        block_len = end - start
        for offset in range(block_len):
            layers.move(start + offset, target_start + offset)
        _set_active_indices(settings, target_start)
        return True
    except Exception:
        return False


def _display_layer_indices(settings) -> list[int]:
    """Top-to-bottom layer order with UI-only collapsed-folder filtering."""
    try:
        layers = settings.layers
    except Exception:
        return []
    count = len(layers)

    def depth_at(index: int, fallback: int = 0) -> int:
        try:
            return max(0, int(getattr(layers[int(index)], "group_depth", fallback) or fallback))
        except Exception:
            return int(fallback)

    def is_group(index: int) -> bool:
        try:
            layer = layers[int(index)]
            return bool(getattr(layer, "is_group", False)) or str(
                getattr(layer, "layer_kind", "") or ""
            ).upper() == "GROUP"
        except Exception:
            return False

    def scope_blocks(start: int, end: int, depth: int):
        blocks = []
        index = int(start)
        while index < int(end):
            row_depth = depth_at(index, depth)
            if row_depth < depth:
                break
            if row_depth > depth:
                blocks.append(("leaf", index, index + 1, index + 1))
                index += 1
                continue
            if is_group(index):
                child_start = index + 1
                child_end = child_start
                while child_end < int(end) and depth_at(child_end, depth) > row_depth:
                    child_end += 1
                blocks.append(("group", index, child_start, child_end))
                index = child_end
            else:
                blocks.append(("leaf", index, index + 1, index + 1))
                index += 1
        return blocks

    def emit_scope(start: int, end: int, depth: int) -> list[int]:
        result: list[int] = []
        for kind, index, child_start, child_end in reversed(scope_blocks(start, end, depth)):
            result.append(int(index))
            if kind == "group" and bool(getattr(layers[index], "group_expanded", True)):
                result.extend(emit_scope(child_start, child_end, depth + 1))
        return result

    return emit_scope(0, count, 0)


def _dirty_entries_for_save(material) -> list[dict[str, object]]:
    entries = []
    try:
        canvas = getattr(getattr(getattr(bpy.context, "tool_settings", None), "image_paint", None), "canvas", None)
    except Exception:
        canvas = None
    try:
        canvas_is_mask = bool(canvas is not None and canvas.get("sps_mvp_mask_canvas", False))
    except Exception:
        canvas_is_mask = False
    if canvas is not None and not canvas_is_mask:
        try:
            if str(canvas.get("smart_paint_suite_material", "") or "") == str(getattr(material, "name", "") or ""):
                lid = str(canvas.get("smart_paint_suite_layer_id", "") or "")
                record_index = int(canvas.get("sps_psd_source_order", -1))
                _mvp_state.adopt_canvas(material, lid, record_index, canvas)
        except Exception:
            pass
    known = dict(_ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {})
    if canvas is not None and not canvas_is_mask:
        try:
            if str(canvas.get("smart_paint_suite_material", "") or "") == str(getattr(material, "name", "") or ""):
                lid = str(canvas.get("smart_paint_suite_layer_id", "") or "")
                if lid:
                    current_entry = dict(known.get(lid, {}) or {})
                    current_entry.update({
                        "layer_id": lid,
                        "image": str(canvas.name),
                        "record_index": int(canvas.get("sps_psd_source_order", -1)),
                    })
                    # Preserve the activation-time baseline when the active
                    # canvas is refreshed into the candidate list.
                    known[lid] = current_entry
        except Exception:
            pass
    for lid, entry in known.items():
        image = bpy.data.images.get(str(entry.get("image", "") or ""))
        if image is None:
            continue
        try:
            if bool(image.get("sps_mvp_mask_canvas", False)):
                continue
        except Exception:
            pass
        try:
            entry_record_index = int(entry.get("record_index", -1))
        except Exception:
            entry_record_index = -1
        repair = _mvp_state.repair_external_import_baseline(
            material,
            str(lid or entry.get("layer_id", "") or ""),
            entry_record_index,
            image,
        )
        if bool(repair.get("repaired", False)):
            _trace_lightweight(
                "lightweight_import_undo_repaired_before_save",
                material=material,
                layer_id=str(lid or entry.get("layer_id", "") or ""),
                record_index=entry_record_index,
                image=str(getattr(image, "name", "") or ""),
                rects=[list(rect) for rect in repair.get("rects", [])],
            )
        item = dict(entry)
        item["layer_id"] = str(lid or entry.get("layer_id", "") or "")
        item["image_ref"] = image
        item["current_payload_reusable"] = bool(image is not canvas)
        entries.append(item)
    return entries


def _record_index_list(values) -> list[int]:
    result: set[int] = set()
    for value in values or ():
        try:
            index = int(value)
        except (TypeError, ValueError):
            continue
        if index >= 0:
            result.add(index)
    return sorted(result)


def _save_write_coverage(expected, replaced, written, preseeded=()) -> dict[str, object]:
    expected_records = _record_index_list(expected)
    replaced_records = _record_index_list(replaced)
    written_records = _record_index_list(written)
    preseeded_records = _record_index_list(preseeded)
    effective_written_records = sorted(set(written_records) | set(preseeded_records))
    missing_replace = sorted(set(expected_records) - set(replaced_records))
    missing_write = sorted(set(expected_records) - set(effective_written_records))
    unexpected_write = sorted(set(written_records) - set(expected_records))
    unexpected_preseeded = sorted(set(preseeded_records) - set(expected_records))
    ok = (
        not missing_replace
        and not missing_write
        and not unexpected_write
        and not unexpected_preseeded
    )
    return {
        "ok": bool(ok),
        "warning": "" if ok else "dirty_record_write_coverage_mismatch",
        "expected_records": expected_records,
        "replaced_records": replaced_records,
        "written_records": written_records,
        "preseeded_records": preseeded_records,
        "effective_written_records": effective_written_records,
        "missing_replace": missing_replace,
        "missing_write": missing_write,
        "unexpected_write": unexpected_write,
        "unexpected_preseeded": unexpected_preseeded,
    }


def _derive_native_dirty_rect(entry: dict[str, object]) -> tuple[int, int, int, int] | None:
    """Compare the native canvas with its materialize-time baseline.

    This runs only when Save is clicked.  It replaces the old always-running
    brush router while retaining an exact sparse rectangle for the v11 writer.
    """
    image = entry.get("image_ref")
    if image is None:
        return None
    try:
        import numpy as np
        payload = entry.get("baseline_payload")
        if payload is None:
            entry["dirty_probe"] = "baseline_missing"
            _trace_lightweight(
                "lightweight_dirty_decision",
                layer_id=str(entry.get("layer_id", "") or ""),
                image=str(getattr(image, "name", "") or ""),
                reason="baseline_missing",
            )
            return None
        width, height = int(image.size[0]), int(image.size[1])
        base_width, base_height, baseline = payload
        if int(base_width) != width or int(base_height) != height:
            entry["dirty_probe"] = "baseline_size_mismatch"
            _trace_lightweight(
                "lightweight_dirty_decision",
                layer_id=str(entry.get("layer_id", "") or ""),
                image=str(getattr(image, "name", "") or ""),
                reason="baseline_size_mismatch",
                image_size=[width, height],
                baseline_size=[int(base_width), int(base_height)],
            )
            return None
        current = None
        current_source = "image"
        if bool(entry.get("current_payload_reusable", False)):
            try:
                cached_revision = entry.get("current_payload_revision")
                image_revision = int(image.get("smart_paint_suite_pixel_revision", 0) or 0)
                cached_current = _payload_pixels_u8(
                    entry.get("current_payload"), width, height
                )
                cached_rect = [int(value) for value in list(entry.get("current_dirty_rect") or [])[:4]]
                cached_pixels = int(entry.get("current_dirty_pixels", 0) or 0)
                cached_sha256 = str(entry.get("current_pixel_sha256", "") or "")
                recordless_blank = bool(
                    int(entry.get("record_index", -1) or -1) < 0
                    and bool(image.get("sps_lightweight_new_blank_layer", False))
                )
                cache_current = bool(
                    recordless_blank
                    and cached_revision is not None
                    and image_revision == int(cached_revision)
                    and cached_current is not None
                )
                if cache_current and len(cached_rect) == 4 and cached_pixels > 0 and cached_sha256:
                    rect = tuple(cached_rect)
                    if 0 <= rect[0] < rect[2] <= width and 0 <= rect[1] < rect[3] <= height:
                        current = np.asarray(cached_current, dtype=np.uint8).reshape((height, width, 4))
                        entry["save_current_payload"] = (width, height, current)
                        entry["current_pixel_sha256"] = cached_sha256
                        entry["dirty_probe"] = "switch_snapshot_dirty_rect"
                        entry["dirty_rect"] = rect
                        entry["dirty_pixels"] = cached_pixels
                        _trace_lightweight(
                            "lightweight_dirty_decision",
                            layer_id=str(entry.get("layer_id", "") or ""),
                            record_index=int(entry.get("record_index", -1) or -1),
                            image=str(getattr(image, "name", "") or ""),
                            reason="switch_snapshot_dirty_rect",
                            dirty_rect=list(rect),
                            dirty_pixels=cached_pixels,
                            image_size=[width, height],
                        )
                        return rect
                # An empty cached rect also means "too wide to measure at the switch",
                # so it proves nothing unless the snapshot still equals the baseline.
                if cache_current and not cached_rect and cached_pixels == 0 and np.array_equal(
                    np.asarray(cached_current, dtype=np.uint8).reshape((height, width, 4)),
                    np.asarray(baseline, dtype=np.uint8).reshape((height, width, 4)),
                ):
                    entry["save_current_payload"] = (
                        width, height, np.asarray(cached_current, dtype=np.uint8).reshape((height, width, 4))
                    )
                    entry["dirty_probe"] = "unchanged"
                    return None
            except Exception:
                pass
        if bool(entry.get("current_payload_reusable", False)):
            cached_revision = entry.get("current_payload_revision")
            try:
                image_revision = int(image.get("smart_paint_suite_pixel_revision", 0) or 0)
            except Exception:
                image_revision = None
            if cached_revision is not None and image_revision == int(cached_revision):
                cached = _payload_pixels_u8(entry.get("current_payload"), width, height)
                if cached is not None:
                    current = np.asarray(cached, dtype=np.uint8).reshape((height, width, 4))
                    current_source = "switch_snapshot"
        if current is None:
            flat = np.empty(width * height * 4, dtype=np.float32)
            image.pixels.foreach_get(flat)
            current = np.ascontiguousarray(
                np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
                dtype=np.uint8,
            )
        previous = np.asarray(baseline, dtype=np.uint8).reshape((height, width, 4))
        entry["save_current_payload"] = (width, height, current)
        if current.shape == previous.shape and np.array_equal(current, previous):
            try:
                verified_empty = bool(
                    int(entry.get("record_index", -1) or -1) < 0
                    and bool(image.get("sps_lightweight_new_blank_layer", False))
                    and not bool(np.any(current[:, :, 3]))
                )
                if verified_empty:
                    image["sps_lightweight_save_baseline_verified_empty"] = True
                elif "sps_lightweight_save_baseline_verified_empty" in image:
                    del image["sps_lightweight_save_baseline_verified_empty"]
            except Exception:
                pass
            entry["dirty_probe"] = "unchanged"
            _trace_lightweight(
                "lightweight_dirty_decision",
                layer_id=str(entry.get("layer_id", "") or ""),
                image=str(getattr(image, "name", "") or ""),
                reason="unchanged",
                image_size=[width, height],
                current_source=current_source,
                exact_equal_fast_path=True,
                global_alpha_artifact=False,
                ignored_transparent_alpha_pixels=0,
            )
            return None
        global_alpha_artifact_threshold = max(65536, (width * height) // 100)
        alpha_changed = current[:, :, 3] != previous[:, :, 3]
        alpha_changed_pixels = int(np.count_nonzero(alpha_changed))
        recordless_blank_alpha_fast = False
        try:
            recordless_blank_alpha_fast = bool(
                0 < alpha_changed_pixels <= global_alpha_artifact_threshold
                and int(entry.get("record_index", -1) or -1) < 0
                and bool(image.get("sps_lightweight_new_blank_layer", False))
                and not bool(np.any(previous[:, :, 3]))
            )
        except Exception:
            recordless_blank_alpha_fast = False
        if recordless_blank_alpha_fast:
            # A newly-created blank row has no prior visible content. Its exact
            # non-zero alpha delta is therefore the visible authored region. The
            # full RGBA payload is still retained for straight-alpha PSD output.
            changed = alpha_changed
            rgb_changed = None
            rgb_changed_pixels = -1
            transparent_alpha_only_count = 0
            global_alpha_artifact = False
        else:
            rgb_changed = np.any(current[:, :, :3] != previous[:, :, :3], axis=2)
            rgb_changed_pixels = int(np.count_nonzero(rgb_changed))
            transparent_alpha_only = alpha_changed & (previous[:, :, 3] == 0) & ~rgb_changed
            transparent_alpha_only_count = int(np.count_nonzero(transparent_alpha_only))
            # The artifact is global and opaque; a wide white stroke only raises alpha
            # too, but it stays local to its islands and has soft edges.
            global_alpha_artifact = bool(
                transparent_alpha_only_count > max(global_alpha_artifact_threshold, (width * height) // 2)
                and not bool(image.get("sps_lightweight_explicit_alpha_edit", False))
                and not bool(np.any(current[:, :, 3][transparent_alpha_only] < 255))
            )
            if global_alpha_artifact:
                # The cached switch snapshot may be shared with the runtime registry.
                # Copy only in this repair branch before normalizing its alpha plane.
                current = np.ascontiguousarray(current, dtype=np.uint8).copy()
                # Blender's first projected stroke can promote millions of otherwise
                # untouched transparent pixels from alpha 0 to 255. Ignore only that
                # global alpha-only pattern; local alpha-only brush edits remain valid.
                current[:, :, 3][transparent_alpha_only] = previous[:, :, 3][transparent_alpha_only]
                changed = rgb_changed | (alpha_changed & ~transparent_alpha_only)
                try:
                    repaired = np.ascontiguousarray(current.astype(np.float32) / 255.0, dtype=np.float32)
                    image.pixels.foreach_set(repaired.reshape((-1,)))
                    image.update()
                except Exception:
                    pass
            else:
                changed = rgb_changed | alpha_changed
        entry["save_current_payload"] = (width, height, current)
        try:
            entry["current_pixel_sha256"] = hashlib.sha256(
                memoryview(np.ascontiguousarray(current, dtype=np.uint8)).cast("B")
            ).hexdigest()
        except Exception:
            entry["current_pixel_sha256"] = ""
        ys, xs = np.nonzero(changed)
        if xs.size <= 0 or ys.size <= 0:
            try:
                verified_empty = bool(
                    int(entry.get("record_index", -1) or -1) < 0
                    and bool(image.get("sps_lightweight_new_blank_layer", False))
                    and not bool(np.any(current[:, :, 3]))
                )
                if verified_empty:
                    image["sps_lightweight_save_baseline_verified_empty"] = True
                elif "sps_lightweight_save_baseline_verified_empty" in image:
                    del image["sps_lightweight_save_baseline_verified_empty"]
            except Exception:
                pass
            entry["dirty_probe"] = "unchanged"
            _trace_lightweight(
                "lightweight_dirty_decision",
                layer_id=str(entry.get("layer_id", "") or ""),
                image=str(getattr(image, "name", "") or ""),
                reason="unchanged",
                image_size=[width, height],
                current_source=current_source,
                global_alpha_artifact=bool(global_alpha_artifact),
                ignored_transparent_alpha_pixels=int(transparent_alpha_only_count if global_alpha_artifact else 0),
            )
            return None
        try:
            for key in (
                "sps_lightweight_save_baseline_verified_empty",
                "sps_lightweight_new_blank_layer",
            ):
                if key in image:
                    del image[key]
        except Exception:
            pass
        rect = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
        if rgb_changed_pixels < 0:
            x0, y0, x1, y1 = rect
            rgb_changed_pixels = int(np.count_nonzero(np.any(
                current[y0:y1, x0:x1, :3] != previous[y0:y1, x0:x1, :3],
                axis=2,
            )))
        dirty_pixels = int(np.count_nonzero(changed))
        entry["dirty_probe"] = "native_baseline_delta"
        entry["dirty_rect"] = rect
        entry["dirty_pixels"] = dirty_pixels
        _trace_lightweight(
            "lightweight_dirty_decision",
            layer_id=str(entry.get("layer_id", "") or ""),
            record_index=int(entry.get("record_index", -1) or -1),
            image=str(getattr(image, "name", "") or ""),
            reason="native_baseline_delta",
            dirty_rect=[int(v) for v in rect],
            dirty_pixels=dirty_pixels,
            image_size=[width, height],
            current_source=current_source,
            rgb_changed_pixels=rgb_changed_pixels,
            alpha_changed_pixels=alpha_changed_pixels,
            global_alpha_artifact=bool(global_alpha_artifact),
            ignored_transparent_alpha_pixels=int(transparent_alpha_only_count if global_alpha_artifact else 0),
        )
        return rect
    except Exception as exc:
        entry["dirty_probe"] = "exception"
        entry["dirty_probe_error"] = repr(exc)[:300]
        return None


def _mark_entries_for_v11(material, entries: list[dict[str, object]]) -> None:
    from .mvp import save_adapter

    save_adapter.apply_v11_markers(material, entries)
    bucket = _ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}
    for entry in entries:
        layer_id = str(entry.get("layer_id", "") or "")
        activated = bucket.get(layer_id)
        payload = entry.get("save_current_payload")
        if isinstance(activated, dict) and isinstance(payload, tuple) and len(payload) == 3:
            activated["save_current_payload"] = payload
    return

    layer_ids = []
    image_names = []
    source_indices = []
    try:
        from . import v2_paint_target as _v2_target
    except Exception:
        _v2_target = None
    # Native GUI paint may leave broad legacy runtime coverage behind even
    # though lightweight Save has just measured an exact canvas delta. Do not
    # merge those stale rectangles back into the explicit save plan.
    if _v2_target is not None:
        try:
            snapshot_key = getattr(_v2_target, "_snapshot_key", None)
            dirty_sets = getattr(_v2_target, "_DIRTY_SETS", None)
            layer_sets = getattr(_v2_target, "_DIRTY_LAYER_SETS", None)
            material_name = str(getattr(material, "name", "") or "")
            pre_layer_sets = []
            if isinstance(layer_sets, dict):
                for key, value in list(layer_sets.items()):
                    try:
                        if str(key[0]) == material_name and str(key[1]) == CHANNEL:
                            pre_layer_sets.append({
                                "key": [str(v) for v in key],
                                "dirty_rects": list((value or {}).get("dirty_rects", []) or []),
                            })
                    except Exception:
                        pass
            _trace_lightweight(
                "lightweight_runtime_reset",
                material=material,
                phase="before",
                aggregate_present=bool(callable(snapshot_key) and isinstance(dirty_sets, dict) and snapshot_key(material, CHANNEL) in dirty_sets),
                layer_sets=pre_layer_sets,
            )
            if callable(snapshot_key) and isinstance(dirty_sets, dict):
                dirty_sets.pop(snapshot_key(material, CHANNEL), None)
            if isinstance(layer_sets, dict):
                for key in list(layer_sets):
                    try:
                        if str(key[0]) == material_name and str(key[1]) == CHANNEL:
                            layer_sets.pop(key, None)
                    except Exception:
                        pass
        except Exception:
            pass
    for entry in entries:
        image = entry.get("image_ref")
        if image is None:
            continue
        lid = str(entry.get("layer_id", "") or "")
        layer_ids.append(lid)
        image_names.append(str(getattr(image, "name", "") or ""))
        try:
            source_index = int(entry.get("record_index", -1))
        except Exception:
            source_index = -1
        if source_index >= 0:
            source_indices.append(source_index)
        for key, value in (
            ("smart_paint_suite_direct_layer_dirty", True),
            ("smart_paint_suite_bodypaint_direct_authoritative", True),
            ("smart_paint_suite_user_edited", True),
            ("smart_paint_suite_painted_since_last_projection", True),
            ("smart_paint_suite_last_brush_color", (1.0, 1.0, 1.0, 1.0)),
            ("smart_paint_suite_alpha_authoritative", True),
            ("sps_v2_native_paint_dirty", True),
            ("sps_v2_native_paint_target", True),
            ("smart_paint_suite_layer_id", lid),
        ):
            try:
                image[key] = value
            except Exception:
                pass
        # The rect is derived from the materialize-time baseline only when Save
        # is clicked. No input event is intercepted during normal Blender use.
        try:
            image["sps_lightweight_source_materialized_authoritative"] = True
            image["sps_lightweight_bounds_authoritative"] = True
            image["smart_paint_suite_psd_materialized_clean"] = True
            for key in (
                "smart_paint_suite_dirty_bbox",
                "smart_paint_suite_dirty_rects_json",
                "sps_phase2_runtime_dirty_bbox",
                "sps_phase2_runtime_dirty_rects_json",
            ):
                if key in image:
                    del image[key]
            dirty_rect = entry.get("dirty_rect")
            if dirty_rect is not None:
                rect = [int(v) for v in tuple(dirty_rect)[:4]]
                image["smart_paint_suite_dirty_bbox"] = tuple(rect)
                image["smart_paint_suite_dirty_rects_json"] = json.dumps([rect], separators=(",", ":"))
        except Exception:
            pass
        try:
            record_dirty = getattr(_v2_target, "_record_dirty_runtime", None) if _v2_target is not None else None
            if callable(record_dirty):
                record_dirty(
                    material,
                    CHANNEL,
                    image,
                    lid,
                    reason="lightweight_explicit_save",
                )
            stored_rects = []
            if _v2_target is not None:
                layer_key_fn = getattr(_v2_target, "_dirty_layer_key", None)
                layer_sets = getattr(_v2_target, "_DIRTY_LAYER_SETS", None)
                if callable(layer_key_fn) and isinstance(layer_sets, dict):
                    stored = dict(layer_sets.get(layer_key_fn(material, CHANNEL, lid)) or {})
                    stored_rects = list(stored.get("dirty_rects", []) or [])
            _trace_lightweight(
                "lightweight_runtime_register",
                material=material,
                layer_id=lid,
                record_index=int(entry.get("record_index", -1) or -1),
                image=str(getattr(image, "name", "") or ""),
                measured_rect=list(entry.get("dirty_rect") or []),
                image_rects_json=str(image.get("smart_paint_suite_dirty_rects_json", "") or ""),
                image_native_bbox=list(image.get("smart_paint_suite_native_stroke_dirty_bbox", []) or []),
                stored_rects=stored_rects,
            )
        except Exception:
            pass
    try:
        material["sps_v2_dirty_only_save_BASE_COLOR"] = True
        material["sps_v2_dirty_layer_ids_BASE_COLOR"] = json.dumps(layer_ids, ensure_ascii=False)
        material["sps_v2_dirty_images_BASE_COLOR"] = json.dumps(image_names, ensure_ascii=False)
        material["sps_v2_dirty_source_indices_BASE_COLOR"] = json.dumps(source_indices)
        if layer_ids:
            material["sps_v2_dirty_layer_id_BASE_COLOR"] = str(layer_ids[-1])
        if image_names:
            material["sps_v2_dirty_image_BASE_COLOR"] = str(image_names[-1])
    except Exception:
        pass


def _commit_saved_baselines(material, entries: list[dict[str, object]]) -> None:
    """Make the successful PSD save the next native-paint comparison baseline."""
    from .mvp import save_adapter

    save_adapter.commit_saved(material, entries)
    return

    try:
        import numpy as np
        from . import v2_paint_target
    except Exception:
        return
    for entry in entries:
        image = entry.get("image_ref")
        if image is None:
            continue
        try:
            width, height = int(image.size[0]), int(image.size[1])
            flat = np.empty(width * height * 4, dtype=np.float32)
            image.pixels.foreach_get(flat)
            registry_payload = (
                int(width),
                int(height),
                np.ascontiguousarray(
                    np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
                    dtype=np.uint8,
                ),
            )
            material_name = str(getattr(material, "name", "") or "")
            layer_id = str(entry.get("layer_id", "") or "")
            activated = _ACTIVATED_LAYERS.get(material_name, {}).get(layer_id)
            if isinstance(activated, dict):
                activated["baseline_payload"] = registry_payload
                activated["baseline_exact"] = True
                activated["current_payload"] = registry_payload
        except Exception:
            pass
        for key in (
            "smart_paint_suite_direct_layer_dirty",
            "smart_paint_suite_bodypaint_direct_authoritative",
            "smart_paint_suite_user_edited",
            "smart_paint_suite_painted_since_last_projection",
            "smart_paint_suite_last_brush_color",
            "sps_v2_native_paint_dirty",
            "smart_paint_suite_dirty_bbox",
            "smart_paint_suite_dirty_rects_json",
        ):
            try:
                if key in image:
                    del image[key]
            except Exception:
                pass
        try:
            image["smart_paint_suite_psd_materialized_clean"] = True
            image["smart_paint_suite_saved_psd_clean_boundary"] = True
        except Exception:
            pass
    try:
        material_name = str(getattr(material, "name", "") or "")
        snapshot_key = getattr(v2_paint_target, "_snapshot_key", None)
        dirty_sets = getattr(v2_paint_target, "_DIRTY_SETS", None)
        if callable(snapshot_key) and isinstance(dirty_sets, dict):
            dirty_sets.pop(snapshot_key(material, CHANNEL), None)
        layer_sets = getattr(v2_paint_target, "_DIRTY_LAYER_SETS", None)
        if isinstance(layer_sets, dict):
            for key in list(layer_sets):
                try:
                    if str(key[0]) == material_name and str(key[1]) == CHANNEL:
                        layer_sets.pop(key, None)
                except Exception:
                    pass
    except Exception:
        pass
    for key in (
        "sps_v2_dirty_layer_ids_BASE_COLOR",
        "sps_v2_dirty_images_BASE_COLOR",
        "sps_v2_dirty_source_indices_BASE_COLOR",
        "sps_v2_dirty_layer_id_BASE_COLOR",
        "sps_v2_dirty_image_BASE_COLOR",
    ):
        try:
            if key in material:
                del material[key]
        except Exception:
            pass


def save_psd(material, context=None, *, destination_path: str = "") -> dict[str, object]:
    """Public layered save boundary.

    The write is `_save_psd_document`; this boundary only guarantees that the
    drawing mode the user selected before the save is the drawing mode both the
    3D View and the Image Editor render after it.
    """
    state = _begin_psd_save_display_contract(material, context)
    ok = False
    try:
        result = _save_psd_document(material, context, destination_path=destination_path)
        ok = bool(result.get("ok", False))
        return result
    finally:
        _end_psd_save_display_contract(material, context, state, ok)


def _save_psd_document(material, context=None, *, destination_path: str = "") -> dict[str, object]:
    # USER-WORK-FIRST: Blender replaces bpy.app.driver_namespace on every file
    # load, which used to leave the runtime registry dormant and able to refuse
    # save-adjacent acquisitions with RegistrationError (1.9.289 defect).
    # Re-arm the resource-owning generation at the save entry; if the registry
    # still owns no READY generation the save proceeds regardless -- exporting
    # the user's document must never depend on overlay/registry state.
    try:
        from . import runtime_registry as _sps_registry
        _sps_registry.ensure_runtime_ready()
    except Exception:
        pass
    ready = _ensure_layered_document_ready(
        material,
        context,
        reason="save_psd",
    )
    if not bool(ready.get("ok", False)):
        return {
            **ready,
            "error": str(ready.get("reason", "source_psd_missing") or ""),
        }
    stored_path = _normalized_psd_path(_source_path(material))
    session_path = _session_source_path(material)
    explicit_destination = _normalized_psd_path(destination_path)
    path = explicit_destination or session_path or stored_path
    if not path or Path(path).suffix.lower() not in _image_io.LAYERED_EXTENSIONS:
        return {"ok": False, "reason": "source_psd_missing", "path": path}
    expected_path = explicit_destination or session_path
    path_match = bool(expected_path) and Path(path) == Path(expected_path)
    if not path_match:
        _trace_lightweight(
            "lightweight_save_path_assertion",
            material=material,
            ok=False,
            session_open_path=session_path,
            stored_material_path=stored_path,
            requested_write_path=path,
            explicit_destination=explicit_destination,
            reason="session_open_identity_missing_or_mismatch",
        )
        return {
            "ok": False,
            "reason": "save_path_identity_mismatch",
            "path": path,
            "session_open_path": session_path,
            "stored_material_path": stored_path,
        }
    # Native undo can roll Material custom properties back to a path embedded
    # in the .blend. Rebind only path identity from the process-local explicit
    # open session; never touch image pixels, baselines, or dirty markers here.
    _rebind_source_path_only(material, path)
    _trace_lightweight(
        "lightweight_save_path_assertion",
        material=material,
        ok=True,
        session_open_path=session_path,
        stored_material_path=stored_path,
        requested_write_path=path,
        explicit_destination=explicit_destination,
        material_path_rebound=bool(stored_path and Path(stored_path) != Path(path)),
    )
    try:
        from . import save_trace

        trace_id = save_trace.new_trace_id("lightweight")
        save_trace.set_trace_id(material, CHANNEL, trace_id)
    except Exception:
        trace_id = ""
    metadata_changes = _metadata_changes(material)
    orphan_clipping_rows = _new_orphan_clipping_rows(metadata_changes)
    if orphan_clipping_rows:
        _trace_lightweight(
            "lightweight_save_rejected_orphan_clipping",
            material=material,
            trace_id=trace_id,
            rows=orphan_clipping_rows,
        )
        return {
            "ok": False,
            "reason": "orphan_clipping",
            "path": path,
            "elapsed_ms": 0.0,
            "layer_count": 0,
            "error": "クリッピング先となる下位レイヤーがありません。レイヤー構造は変更せず保存を中止しました。",
            "orphan_clipping_rows": orphan_clipping_rows,
        }
    candidates = _dirty_entries_for_save(material)
    entries = []
    for entry in candidates:
        rect = _derive_native_dirty_rect(entry)
        external_rects = [
            tuple(int(value) for value in tuple(item)[:4])
            for item in list(entry.get("external_dirty_rects") or [])
            if item is not None and len(tuple(item)) >= 4
        ]
        if external_rects:
            all_rects = list(external_rects)
            if rect is not None:
                all_rects.append(tuple(rect))
            rect = (
                min(item[0] for item in all_rects),
                min(item[1] for item in all_rects),
                max(item[2] for item in all_rects),
                max(item[3] for item in all_rects),
            )
            entry["dirty_rect"] = rect
            entry["dirty_probe"] = "external_import_dirty"
        if rect is not None:
            entries.append(entry)
            continue
        # A missing baseline is unusual but must fail toward preserving edits,
        # not silently dropping them. The writer's source delta probe handles it.
        if str(entry.get("dirty_probe", "") or "") != "unchanged":
            entries.append(entry)
    _trace_lightweight(
        "lightweight_save_plan",
        material=material,
        trace_id=trace_id,
        path=path,
        session_open_path=session_path,
        stored_material_path=stored_path,
        path_assertion_ok=True,
        candidate_count=len(candidates),
        dirty_count=len(entries),
        candidates=[{
            "layer_id": str(entry.get("layer_id", "") or ""),
            "record_index": int(entry.get("record_index", -1) or -1),
            "image": str(getattr(entry.get("image_ref"), "name", "") or ""),
            "dirty_probe": str(entry.get("dirty_probe", "") or ""),
            "dirty_rect": list(entry.get("dirty_rect") or []),
            "dirty_pixels": int(entry.get("dirty_pixels", 0) or 0),
        } for entry in candidates],
    )
    if not entries and not bool(metadata_changes.get("dirty", False)):
        return {"ok": True, "reason": "no_pixel_changes", "path": path, "elapsed_ms": 0.0, "layer_count": 0, "error": ""}
    if bool(metadata_changes.get("dirty", False)):
        _mark_structure_dirty(
            material,
            reason="lightweight_metadata_save",
            order=bool(metadata_changes.get("order", False) or metadata_changes.get("structure", False)),
            mask=bool(metadata_changes.get("mask", False)),
        )
    if entries:
        _mark_entries_for_v11(material, entries)
    else:
        # A metadata-only write must not inherit an earlier dirty-only pixel
        # scope. The source-order writer will patch raw record metadata only.
        for key in (
            "sps_v2_dirty_only_save_BASE_COLOR",
            "sps_v2_dirty_layer_ids_BASE_COLOR",
            "sps_v2_dirty_images_BASE_COLOR",
            "sps_v2_dirty_source_indices_BASE_COLOR",
            "sps_v2_dirty_layer_id_BASE_COLOR",
            "sps_v2_dirty_image_BASE_COLOR",
        ):
            try:
                if key in material:
                    del material[key]
            except Exception:
                pass
    start = time.perf_counter()
    if not bool(metadata_changes.get("dirty", False)):
        _trace_lightweight(
            "lightweight_source_stack_reused",
            material=material,
            reason="metadata_rows_already_loaded",
        )
    else:
        _trace_lightweight(
            "lightweight_source_reload_skipped_for_metadata",
            material=material,
            metadata=bool(metadata_changes.get("metadata", False)),
            structure=bool(metadata_changes.get("structure", False)),
            order=bool(metadata_changes.get("order", False)),
            mask=bool(metadata_changes.get("mask", False)),
        )
    ok = False
    error = ""
    for key in (
        "sps_last_psd_replaced_record_indices_BASE_COLOR",
        "sps_last_psd_written_record_indices_BASE_COLOR",
        "sps_lightweight_last_save_write_coverage_warning",
        "sps_last_psd_save_preview_warning_BASE_COLOR",
    ):
        try:
            if key in material:
                del material[key]
        except Exception:
            pass
    intent_key = "sps_psd_save_intent_BASE_COLOR"

    def _save_entry_identity(entry) -> str:
        try:
            raw_index = entry.get("record_index", -1)
            record_index = -1 if raw_index in {None, ""} else int(raw_index)
        except Exception:
            record_index = -1
        if record_index >= 0:
            return "record:" + str(record_index)
        layer_id = str(entry.get("layer_id", "") or "")
        return "id:" + layer_id if layer_id else "new-row"

    save_intent = {
        "version": 1,
        "intent_known": bool(metadata_changes.get("intent_known", False)),
        "previous": list(metadata_changes.get("previous") or []),
        "current": list(metadata_changes.get("current") or []),
        "changed_fields": dict(metadata_changes.get("changed_fields") or {}),
        "added_identities": list(metadata_changes.get("added_identities") or []),
        "removed_identities": list(metadata_changes.get("removed_identities") or []),
        "mask_dirty_identities": list(metadata_changes.get("mask_dirty_identities") or []),
        "mask_pixel_digests": _mask_pixel_digests(
            material, metadata_changes.get("mask_dirty_identities") or [],
        ),
        "structure": bool(metadata_changes.get("structure", False)),
        "order": bool(metadata_changes.get("order", False)),
        "mask": bool(metadata_changes.get("mask", False)),
        "dirty_identities": sorted(set(_save_entry_identity(entry) for entry in entries)),
        "pixel_digests": {
            _save_entry_identity(entry): str(entry.get("current_pixel_sha256", "") or "")
            for entry in entries
            if str(entry.get("current_pixel_sha256", "") or "")
        },
        "dirty_record_indices": sorted(set(
            int(entry.get("record_index", -1))
            for entry in entries
            if entry.get("record_index", -1) not in {None, ""}
            and int(entry.get("record_index", -1)) >= 0
        )),
        "destination_path": str(path),
    }
    try:
        material[intent_key] = json.dumps(save_intent, ensure_ascii=False, separators=(",", ":"))
    except Exception:
        pass
    try:
        from . import clean_layer_stack_engine as clean

        writer = getattr(clean, "write_layered_psd", None)
        if not callable(writer):
            return {"ok": False, "reason": "transactional_writer_missing", "path": path}
        material["sps_explicit_psd_write_active_BASE_COLOR"] = True
        material["sps_explicit_psd_write_active_time_BASE_COLOR"] = float(time.time())
        material["sps_lightweight_save_active"] = True
        ok = bool(writer(material, CHANNEL, path))
    except Exception as exc:
        error = repr(exc)[:1024]
        ok = False
    finally:
        bucket = _ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}
        for entry in entries:
            activated = bucket.get(str(entry.get("layer_id", "") or ""))
            if isinstance(activated, dict):
                activated.pop("save_current_payload", None)
        for key in ("sps_explicit_psd_write_active_BASE_COLOR", "sps_lightweight_save_active", intent_key):
            try:
                if key in material:
                    del material[key]
            except Exception:
                pass
    elapsed_ms = round((time.perf_counter() - start) * 1000.0, 3)
    try:
        material["sps_lightweight_last_save_ok"] = bool(ok)
        material["sps_lightweight_last_save_ms"] = float(elapsed_ms)
        material["sps_lightweight_last_save_path"] = str(path)
    except Exception:
        pass
    if ok:
        _commit_saved_mask_images(
            material,
            list(metadata_changes.get("mask_write_images") or []),
        )
        if bool(metadata_changes.get("order", False) or metadata_changes.get("structure", False)):
            try:
                refresh = getattr(clean, "_refresh_lazy_psd_payloads_from_saved_document", None)
                if callable(refresh):
                    refreshed = int(refresh(material, CHANNEL, path) or 0)
                    _trace_lightweight(
                        "lightweight_structure_identity_refreshed",
                        material=material,
                        trace_id=trace_id,
                        refreshed_images=refreshed,
                        path=path,
                    )
            except Exception as exc:
                _trace_lightweight(
                    "lightweight_structure_identity_refresh_failed",
                    material=material,
                    trace_id=trace_id,
                    path=path,
                    error=repr(exc)[:512],
                )
        expected_values = [entry.get("record_index", -1) for entry in entries]
        try:
            replaced_values = json.loads(
                str(material.get("sps_last_psd_replaced_record_indices_BASE_COLOR", "[]") or "[]")
            )
        except Exception:
            replaced_values = []
        try:
            written_values = json.loads(
                str(material.get("sps_last_psd_written_record_indices_BASE_COLOR", "[]") or "[]")
            )
        except Exception:
            written_values = []
        promotion_template_preseeded = (
            ".sps-promote-" in Path(explicit_destination or path).name
        )
        coverage = _save_write_coverage(
            expected_values,
            replaced_values,
            written_values,
            preseeded=replaced_values if promotion_template_preseeded else (),
        )
        coverage.update({
            "requested_write_path": str(path),
            "session_open_path": str(session_path),
            "stored_material_path": str(stored_path),
            "path_assertion_ok": True,
            "explicit_destination": str(explicit_destination),
            "promotion_template_preseeded": bool(promotion_template_preseeded),
        })
        warning = str(coverage["warning"])
        try:
            material["sps_lightweight_last_save_write_coverage_warning"] = warning
        except Exception:
            pass
        _trace_lightweight(
            "lightweight_save_write_coverage",
            material=material,
            trace_id=trace_id,
            **coverage,
        )
        _commit_saved_baselines(material, entries)
        for candidate in candidates:
            image = candidate.get("image_ref")
            if image is None:
                continue
            for key in (
                "sps_lightweight_save_baseline_verified_empty",
                "sps_lightweight_new_blank_layer",
                "sps_lightweight_explicit_alpha_edit",
            ):
                try:
                    if key in image:
                        del image[key]
                except Exception:
                    pass
        _store_metadata_baseline(material)
        if entries or bool(metadata_changes.get("dirty", False)):
            try:
                material["sps_lightweight_composite_review_stale"] = True
                material["sps_lightweight_composite_review_stale_reason"] = "v11_preserves_source_merged_preview"
                preview_name = str(material.get("sps_lightweight_composite_image", "") or "")
                preview_image = bpy.data.images.get(preview_name) if preview_name else None
                if preview_image is not None and "sps_lightweight_composite_signature" in preview_image:
                    del preview_image["sps_lightweight_composite_signature"]
            except Exception:
                pass
        # The optional bridge owns all external I/O.  This callback only marks
        # a source refresh request and returns immediately; no bridge import is
        # required for the core add-on.
        try:
            callback = bpy.app.driver_namespace.get("sps_external_bridge_on_core_save")
            if callable(callback) and not bool(material.get("sps_lightweight_defer_external_save_notify", False)):
                callback(material=material, path=str(path), trace_id=str(trace_id or ""))
        except Exception as exc:
            _trace_lightweight(
                "lightweight_external_bridge_notify_failed",
                material=material,
                trace_id=trace_id,
                path=path,
                error=repr(exc)[:384],
            )
    _trace_lightweight(
        "lightweight_writer_result",
        material=material,
        trace_id=trace_id,
        ok=bool(ok),
        elapsed_ms=float(elapsed_ms),
        layer_count=len(entries),
        metadata_changes={
            key: bool(metadata_changes.get(key, False))
            for key in ("metadata", "structure", "order", "mask")
        },
        algorithm=str(material.get("sps_last_psd_save_algorithm_BASE_COLOR", "") or ""),
        requested_write_path=str(path),
        session_open_path=str(session_path),
        path_assertion_ok=True,
        error=error,
    )
    if not ok and not error:
        try:
            error = str(material.get("sps_last_psd_save_error_BASE_COLOR", "") or material.get("sps_last_texture_save_error_BASE_COLOR", "") or "v11_writer_failed")
        except Exception:
            error = "v11_writer_failed"
    # 1.9.291: a merged-preview refresh failure no longer aborts the save.
    # The engine records it as a warning; surface it so operators can report
    # "saved with warning" instead of silently claiming a clean save.
    preview_warning = ""
    if ok:
        try:
            preview_warning = str(material.get("sps_last_psd_save_preview_warning_BASE_COLOR", "") or "")
        except Exception:
            preview_warning = ""
    return {
        "ok": bool(ok),
        "reason": "saved" if ok else "writer_failed",
        "path": path,
        "elapsed_ms": elapsed_ms,
        "layer_count": len(entries),
        "metadata_changed": bool(metadata_changes.get("dirty", False)),
        "error": error,
        "preview_warning": preview_warning,
    }


def _reset_runtime_for_document_open(material) -> None:
    """Clear process-local state that must never cross a document boundary."""
    if material is None:
        return
    try:
        from .mvp import selection_tools

        selection_tools.clear(material)
    except Exception:
        pass
    try:
        from .mvp import editing_tools

        editing_tools.clear_document_state(material)
    except Exception:
        pass
    material_name = str(getattr(material, "name", "") or "")
    _mvp_state.clear_document(material)
    _COMPOSITE_BASE_CACHE.pop(material_name, None)
    _DOCUMENT_COMPOSITE_CACHE.pop(_session_material_key(material), None)
    _REVIEW_SAVE_PAYLOAD_CACHE.pop(_session_material_key(material), None)
    thumbnail_module = _thumbnail_module(import_if_missing=False)
    if thumbnail_module is not None:
        try:
            thumbnail_module.clear_material(material)
        except Exception:
            pass
    live_module = _live_composite_module(import_if_missing=False)
    if live_module is not None:
        try:
            live_module.disable(material, remove_nodes=True)
            live_module.clear_material_cache(material, remove_unused_images=True)
            live_module.clear_explicit_image_u8_cache(material)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    try:
        from .mvp import image_editor_overlay

        image_editor_overlay.disable(material)
    except Exception:
        pass
    try:
        from .mvp import solid_view_overlay

        solid_view_overlay.sync_handler_state()
    except Exception:
        pass
    for key in (
        "sps_lightweight_active_image",
        "sps_lightweight_composite_image",
        "sps_lightweight_mask_owner_layer_id",
        "sps_lightweight_mask_target_image",
        "sps_lightweight_active_target",
        "sps_active_private_layer_image_BASE_COLOR",
        "sps_native_write_image_BASE_COLOR",
        "sps_v2_native_paint_target_image_BASE_COLOR",
        "sps_v2_native_paint_target_layer_id_BASE_COLOR",
        "sps_v2_dirty_layer_ids_BASE_COLOR",
        "sps_v2_dirty_images_BASE_COLOR",
        "sps_v2_dirty_source_indices_BASE_COLOR",
    ):
        try:
            if key in material:
                del material[key]
        except Exception:
            pass


def _document_owned_image_names(material, context=None) -> set[str]:
    """Return images that belong to the material's current SPS document."""
    if material is None:
        return set()
    names: set[str] = set()
    settings = _settings(material)
    for layer in list(getattr(settings, "layers", ()) or ()):
        for attribute in ("base_color_image", "mask_image"):
            try:
                name = str(getattr(layer, attribute, "") or "")
            except Exception:
                name = ""
            if name:
                names.add(name)
    try:
        for entry in _mvp_state.layer_bucket(material, create=False).values():
            name = str((entry or {}).get("image", "") or "")
            if name:
                names.add(name)
    except Exception:
        pass
    for key in (
        "sps_lightweight_active_image",
        "sps_lightweight_composite_image",
        "sps_lightweight_mask_target_image",
        "sps_active_private_layer_image_BASE_COLOR",
        "sps_native_write_image_BASE_COLOR",
        "sps_v2_native_paint_target_image_BASE_COLOR",
    ):
        try:
            name = str(material.get(key, "") or "")
        except Exception:
            name = ""
        if name:
            names.add(name)
    try:
        paint = getattr(
            getattr(context or bpy.context, "tool_settings", None),
            "image_paint",
            None,
        )
        canvas = getattr(paint, "canvas", None) if paint is not None else None
        if (
            canvas is not None
            and str(canvas.get("smart_paint_suite_material", "") or "")
            == str(getattr(material, "name", "") or "")
        ):
            names.add(str(canvas.name))
    except Exception:
        pass
    return names


def _release_retired_document_images(
    material,
    retired_names,
    context=None,
) -> dict[str, object]:
    """Release outgoing private images after a replacement document is active."""
    candidates = {
        str(name or "")
        for name in (retired_names or ())
        if str(name or "")
    }
    if material is None or not candidates:
        return {"removed": 0, "removed_pixels": 0, "names": []}
    candidates.difference_update(_document_owned_image_names(material, context))
    material_name = str(getattr(material, "name", "") or "")
    removed: list[str] = []
    removed_pixels = 0
    for name in sorted(candidates):
        image = bpy.data.images.get(name)
        if image is None:
            continue
        try:
            owner_matches = (
                str(image.get("smart_paint_suite_material", "") or "")
                == material_name
            )
            private_image = bool(
                image.get("sps_mvp_native_canvas", False)
                or image.get("sps_mvp_mask_canvas", False)
                or image.get("smart_paint_suite_layer_image", False)
                or image.get("smart_paint_suite_mask_image", False)
                or image.get("sps_lightweight_flat_import_base", False)
            )
        except Exception:
            owner_matches = False
            private_image = False
        if not owner_matches or not private_image:
            continue
        try:
            removed_pixels += (
                max(0, int(image.size[0]))
                * max(0, int(image.size[1]))
            )
        except Exception:
            pass
        try:
            image.use_fake_user = False
        except Exception:
            pass
        try:
            bpy.data.images.remove(image, do_unlink=True)
            removed.append(name)
        except Exception:
            pass
    result = {
        "removed": len(removed),
        "removed_pixels": int(removed_pixels),
        "names": removed[:12],
    }
    if removed:
        _trace_lightweight(
            "lightweight_retired_document_images_released",
            material=material,
            **result,
        )
    return result


def _load_flat_image_for_material(context, material, path: str, *, reason: str) -> dict[str, object]:
    """Open one Blender-readable still as a detached, recordless paint layer."""
    if material is None:
        return {"ok": False, "reason": "material_missing"}
    started = time.perf_counter()
    decoded = dict(_image_io.load_flat_pixels(path) or {})
    if not bool(decoded.get("ok", False)):
        return decoded
    source = str(decoded.get("path", "") or "")
    width = int(decoded.get("width", 0) or 0)
    height = int(decoded.get("height", 0) or 0)
    pixels = decoded.get("pixels")
    settings = _settings(material)
    if settings is None or width <= 0 or height <= 0 or pixels is None:
        return {"ok": False, "reason": "flat_document_initialization_failed", "path": source}

    retired_images = _document_owned_image_names(material, context)
    _reset_runtime_for_document_open(material)
    detached = None
    try:
        import numpy as np

        settings.layers.clear()
        layer_id = uuid.uuid4().hex[:8]
        layer_name = Path(source).stem or "Image"
        detached = bpy.data.images.new(
            name=f"SPS_FlatImport_{getattr(material, 'name', 'Material')}_{layer_id}",
            width=width,
            height=height,
            alpha=True,
            float_buffer=False,
        )
        _configure_new_image(detached, material, layer_id)
        detached.alpha_mode = "STRAIGHT"
        try:
            detached.colorspace_settings.name = "sRGB"
        except Exception:
            pass
        float_pixels = np.empty(np.asarray(pixels).shape, dtype=np.float32)
        np.multiply(pixels, np.float32(1.0 / 255.0), out=float_pixels, casting="unsafe")
        detached.pixels.foreach_set(float_pixels.reshape((-1,)))
        detached.update()
        for key in (
            "smart_paint_suite_intentionally_empty",
            "smart_paint_suite_clear_color",
            "smart_paint_suite_initialized_clear_color",
        ):
            try:
                if key in detached:
                    del detached[key]
            except Exception:
                pass
        detached["sps_lightweight_flat_import_source"] = source
        detached["sps_lightweight_flat_import_base"] = True
        layer = settings.layers.add()
        _initialize_paint_layer(
            layer,
            name=layer_name,
            layer_id=layer_id,
            image_name=detached.name,
            depth=0,
        )
        _set_active_indices(settings, 0)
        material.smart_paint_suite.managed = True
        material["sps_lightweight_mode"] = True
        material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
        material["sps_lightweight_composite_review_stale"] = False
        material["sps_lightweight_thumbnails_enabled"] = False
        _set_document_identity(
            material,
            kind="FLAT",
            path=source,
            width=width,
            height=height,
            file_format=str(decoded.get("format", "") or ""),
            depth=int(decoded.get("depth", 0) or 0),
        )
        material["sps_lightweight_flat_open_file_sha256"] = str(decoded.get("file_sha256", "") or "")
        material["sps_lightweight_flat_open_pixel_sha256"] = str(decoded.get("pixel_sha256", "") or "")
        material["sps_lightweight_flat_last_saved_file_sha256"] = str(decoded.get("file_sha256", "") or "")
        material["sps_lightweight_flat_last_saved_pixel_sha256"] = str(decoded.get("pixel_sha256", "") or "")
        material["sps_lightweight_flat_last_saved_path"] = source
        material["sps_lightweight_flat_photoshop_layer_tiff"] = bool(decoded.get("photoshop_layer_tiff", False))
        material["sps_lightweight_flat_source_colorspace"] = str(decoded.get("source_colorspace", "") or "")
        activation = activate_layer(context, material, 0)
        if not bool(activation.get("ok", False)):
            return {
                "ok": False,
                "reason": "activation_failed",
                "activation_reason": str(activation.get("reason", "") or ""),
                "path": source,
            }
        canvas = bpy.data.images.get(str(activation.get("image", "") or ""))
        canvas_pixel_hash = str(decoded.get("pixel_sha256", "") or "")
        if canvas is not None:
            canvas["sps_lightweight_flat_import_source"] = source
            canvas["sps_lightweight_flat_import_base"] = True
            actual_payload = _read_image_pixels_u8(canvas)
            if actual_payload is not None:
                canvas_pixel_hash = _image_io.pixels_sha256(actual_payload[2])
        material["sps_lightweight_flat_open_pixel_sha256"] = canvas_pixel_hash
        material["sps_lightweight_flat_last_saved_pixel_sha256"] = canvas_pixel_hash
        _remember_session_source_path(material, source)
        _store_metadata_baseline(material)
        retired_release = _release_retired_document_images(
            material,
            retired_images,
            context,
        )
        result = {
            "ok": True,
            "reason": str(reason or "explicit_open"),
            "document_kind": "FLAT",
            "path": source,
            "format": str(decoded.get("format", "") or ""),
            "depth": int(decoded.get("depth", 0) or 0),
            "width": width,
            "height": height,
            "layer_count": 1,
            "active_layer_index": 0,
            "active_layer_name": layer_name,
            "active_record_index": -1,
            "image": str(activation.get("image", "") or ""),
            "photoshop_layer_tiff": bool(decoded.get("photoshop_layer_tiff", False)),
            "retired_images_released": int(retired_release.get("removed", 0) or 0),
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
        _trace_lightweight("lightweight_flat_image_loaded", material=material, **result)
        return result
    except Exception as exc:
        return {
            "ok": False,
            "reason": "flat_document_initialization_exception",
            "path": source,
            "error": repr(exc)[:512],
            "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
    finally:
        if detached is not None:
            try:
                still_used = any(
                    str(getattr(layer, "base_color_image", "") or "") == str(detached.name)
                    for layer in getattr(settings, "layers", ())
                )
                if not still_used:
                    bpy.data.images.remove(detached, do_unlink=True)
            except Exception:
                pass


def _load_psd_for_material(context, material, path: str, *, reason: str) -> dict[str, object]:
    """Shared explicit/load-post PSD import with one deterministic activation."""
    if material is None:
        return {"ok": False, "reason": "material_missing"}
    try:
        source = str(Path(bpy.path.abspath(str(path or ""))).resolve())
    except Exception:
        source = str(path or "")
    if not source or Path(source).suffix.lower() not in _image_io.LAYERED_EXTENSIONS or not Path(source).is_file():
        return {"ok": False, "reason": "source_psd_missing", "path": source}
    signature = _image_io.sniff_layered_signature(source)
    if signature not in {"PSD", "PSB"}:
        return {"ok": False, "reason": "source_layered_signature_invalid", "path": source}
    if not _image_io.layered_extension_matches_signature(source, signature):
        return {
            "ok": False,
            "reason": "source_layered_extension_mismatch",
            "path": source,
            "signature": signature,
        }
    try:
        from .mvp import selection_tools

        selection_tools.clear(material)
    except Exception:
        pass
    try:
        from .mvp import editing_tools

        editing_tools.clear_document_state(material)
    except Exception:
        pass

    old_layer, old_index = _active_layer(material)
    preferred_record = _source_record_index(old_layer) if old_layer is not None else -1
    preferred_name = str(getattr(old_layer, "name", "") or "") if old_layer is not None else ""
    retired_images = _document_owned_image_names(material, context)
    started = time.perf_counter()
    try:
        # Explicit Open is the only boundary that binds the heavyweight PSD
        # decoder into the otherwise lightweight paint-target module.
        from . import psd_io
        _bind_explicit_psd_api(psd_io)
        from . import clean_layer_stack_engine as clean

        ok, imported = clean.import_layered_psd_to_stack(
            material,
            CHANNEL,
            source,
            context=context,
            replace=True,
            rebuild_display=False,
            metadata_only=True,
        )
    except Exception as exc:
        return {
            "ok": False,
            "reason": "psd_import_exception",
            "error": repr(exc)[:512],
            "path": source,
        }
    if not ok:
        return {"ok": False, "reason": "psd_import_failed", "path": source}

    material_name = str(getattr(material, "name", "") or "")
    try:
        material.smart_paint_suite.managed = True
        _set_source_path(material, source)
        material["sps_lightweight_mode"] = True
        # Opening a document is a paint-target operation, not an implicit
        # request to rebuild the previous document's optional GPU review.
        # Leaving LIVE_COMPOSITE latched made activation synchronously rebuild
        # the 4K graph and pushed an otherwise bounded reopen over ten seconds.
        material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
        material["sps_lightweight_composite_review_stale"] = False
        material["sps_lightweight_composite_review_stale_reason"] = ""
    except Exception:
        pass
    _ACTIVATED_LAYERS.pop(material_name, None)
    _COMPOSITE_BASE_CACHE.pop(material_name, None)
    _REVIEW_SAVE_PAYLOAD_CACHE.pop(_session_material_key(material), None)
    try:
        material["sps_lightweight_thumbnails_enabled"] = False
    except Exception:
        pass
    thumbnail_module = _thumbnail_module(import_if_missing=False)
    if thumbnail_module is not None:
        try:
            thumbnail_module.clear_material(material)
        except Exception:
            pass
    live_module = _live_composite_module(import_if_missing=False)
    if live_module is not None:
        try:
            live_module.disable(material, remove_nodes=True)
            live_module.clear_material_cache(material, remove_unused_images=True)
            live_module.clear_explicit_image_u8_cache(material)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    _prepare_imported_source_layers(material, source)

    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    target_index = -1
    target_reason = ""
    if preferred_record >= 0:
        for index, layer in enumerate(layers):
            if _layer_is_paintable(layer) and _source_record_index(layer) == int(preferred_record):
                target_index = int(index)
                target_reason = "source_record"
                break
    if target_index < 0 and preferred_name:
        for index, layer in enumerate(layers):
            if (
                _layer_is_paintable(layer)
                and bool(getattr(layer, "enabled", True))
                and str(getattr(layer, "name", "") or "") == preferred_name
            ):
                target_index = int(index)
                target_reason = "visible_name"
                break
    if target_index < 0:
        target_index = _first_visible_paintable_index(material)
        if target_index >= 0:
            target_reason = "visible_paintable"
    if target_index < 0:
        target_index = _first_paintable_index(material)
        if target_index >= 0:
            target_reason = "paintable_fallback"
    if target_index < 0:
        return {"ok": False, "reason": "paintable_layer_missing", "path": source}

    activation = activate_layer(context, material, target_index)
    if not bool(activation.get("ok", False)):
        return {
            "ok": False,
            "reason": "activation_failed",
            "activation_reason": str(activation.get("reason", "") or ""),
            "path": source,
        }
    width, height = _document_size(material)
    _set_document_identity(
        material,
        kind="LAYERED",
        path=source,
        width=width,
        height=height,
        file_format="PSB" if signature == "PSB" else "PSD",
        depth=8,
    )
    _clear_flat_document_markers(material)
    _remember_session_source_path(material, source)
    _store_metadata_baseline(material)
    retired_release = _release_retired_document_images(
        material,
        retired_images,
        context,
    )
    live_cache_result = {"ok": False, "reason": "not_requested", "elapsed_ms": 0.0}
    if str(reason or "") == "explicit_open":
        cache_started = time.perf_counter()
        try:
            from .mvp import live_composite

            _cache, prepared = live_composite._prepare_cache(material, force=True)
            live_cache_result = dict(prepared or {})
        except Exception as exc:
            live_cache_result = {
                "ok": False,
                "reason": "live_cache_prepare_exception",
                "error": repr(exc)[:300],
            }
        live_cache_result["elapsed_ms"] = round(
            (time.perf_counter() - cache_started) * 1000.0,
            3,
        )
    layer_count = int((imported or {}).get("layer_count", len(layers)) or len(layers))
    result = {
        "ok": True,
        "reason": str(reason or "explicit_open"),
        "path": source,
        "layer_count": int(layer_count),
        "active_layer_index": int(target_index),
        "active_layer_name": str(getattr(layers[target_index], "name", "") or ""),
        "active_record_index": int(_source_record_index(layers[target_index])),
        "active_selection_reason": str(target_reason or ""),
        "image": str(activation.get("image", "") or ""),
        "live_cache_prepared": bool(live_cache_result.get("ok", False)),
        "live_cache_reason": str(live_cache_result.get("reason", "") or ""),
        "live_cache_elapsed_ms": float(live_cache_result.get("elapsed_ms", 0.0) or 0.0),
        "retired_images_released": int(retired_release.get("removed", 0) or 0),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }
    _trace_lightweight("lightweight_psd_loaded", material=material, **result)
    return result


def _restore_flat_document_after_load(context, material, source: str) -> dict[str, object]:
    """Restore generated flat-document canvases saved inside the .blend."""
    started = time.perf_counter()
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    if not layers:
        return _load_flat_image_for_material(
            context,
            material,
            source,
            reason="load_post_restore",
        )
    _reset_runtime_for_document_open(material)
    target = _resolved_layer_index(settings)
    if target < 0 or not _layer_is_paintable(layers[target]):
        target = _first_paintable_index(material)
    if target < 0:
        return {"ok": False, "reason": "paintable_layer_missing", "path": source}
    activation = activate_layer(context, material, target)
    if not bool(activation.get("ok", False)):
        return {
            "ok": False,
            "reason": "activation_failed",
            "activation_reason": str(activation.get("reason", "") or ""),
            "path": source,
        }
    width, height = _document_size(material)
    try:
        file_format = str(material.get("sps_lightweight_document_format", "") or "")
        depth = int(material.get("sps_lightweight_document_depth", 0) or 0)
    except Exception:
        file_format, depth = "", 0
    _set_document_identity(
        material,
        kind="FLAT",
        path=source,
        width=width,
        height=height,
        file_format=file_format,
        depth=depth,
    )
    _remember_session_source_path(material, source)
    _store_metadata_baseline(material)
    return {
        "ok": True,
        "reason": "load_post_restore",
        "document_kind": "FLAT",
        "path": source,
        "layer_count": len(layers),
        "active_layer_index": int(target),
        "active_layer_name": str(getattr(layers[target], "name", "") or ""),
        "active_record_index": -1,
        "image": str(activation.get("image", "") or ""),
        "elapsed_ms": round((time.perf_counter() - started) * 1000.0, 3),
    }


def _is_sourceless_document(material) -> bool:
    try:
        if str(material.get(_DOCUMENT_KIND_KEY, "") or "").upper() != "FLAT" or _source_path(material):
            return False
    except Exception:
        return False
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    return bool(len(layers)) and not any(_source_record_index(layer) >= 0 for layer in layers)


def _persist_layer_pixels(material, layer, index: int) -> set[str]:
    """Copy one layer's current pixels into its durable image and pack it into the .blend."""
    import numpy as np

    pixels = _current_layer_pixels(material, layer, index)
    image = bpy.data.images.get(str(getattr(layer, "base_color_image", "") or ""))
    if image is None or pixels is None:
        return set()
    pixels = np.asarray(pixels, dtype=np.uint8)
    height, width = int(pixels.shape[0]), int(pixels.shape[1])
    if int(image.size[0]) != width or int(image.size[1]) != height:
        image.scale(width, height)
    image.use_fake_user = True
    if image.packed_file is None and not bool(np.any(pixels[:, :, 3])):
        return {str(image.name)}
    digest = hashlib.sha256(memoryview(np.ascontiguousarray(pixels)).cast("B")).hexdigest()
    if image.packed_file is None or str(image.get("sps_saved_pixel_sha256", "") or "") != digest:
        rgba = np.ascontiguousarray(pixels, dtype=np.float32) * (1.0 / 255.0)
        image.pixels.foreach_set(rgba.reshape((-1,)))
        image.update()
        image.pack()
        image["sps_saved_pixel_sha256"] = digest
    return {str(image.name)}


@persistent
def _lightweight_save_pre(_unused) -> None:
    """Keep the paint of a document without a file: Blender drops GENERATED pixels on save."""
    durable: set[str] = set()
    for material in bpy.data.materials:
        settings = _settings(material)
        if settings is None or not _is_sourceless_document(material):
            continue
        try:
            _snapshot_canvas_before_layer_switch(material, "")
            for index, layer in enumerate(settings.layers):
                if _layer_is_paintable(layer):
                    durable |= _persist_layer_pixels(material, layer, index)
                mask = bpy.data.images.get(str(getattr(layer, "mask_image", "") or ""))
                if mask is not None:
                    mask.use_fake_user = True
                    if bool(mask.is_dirty):
                        mask.pack()
                    durable.add(str(mask.name))
            # The node of the displayed layer shows its session canvas until the
            # next activation, so that one image has to keep its pixels as well.
            shown = bpy.data.images.get(str(material.get("sps_lightweight_active_image", "") or ""))
            if shown is not None and shown.name not in durable and bool(shown.is_dirty):
                shown.pack()
        except Exception as exc:
            _trace_lightweight(
                "lightweight_sourceless_save_failed",
                material=material,
                error=repr(exc)[:300],
            )
    # A layer image whose layer is gone must not stay in the file.
    for image in bpy.data.images:
        try:
            if (
                bool(image.get("smart_paint_suite_layer_image", False))
                and image.get("sps_saved_pixel_sha256") is not None
                and image.use_fake_user
                and image.name not in durable
            ):
                image.use_fake_user = False
        except Exception:
            continue


def _restore_sourceless_document_after_load(context, material) -> dict[str, object]:
    """Reconnect the active layer of a document kept only inside the .blend, keeping the mode."""
    if not _is_sourceless_document(material):
        return {"ok": False, "reason": "not_sourceless"}
    settings = _settings(material)
    target = _resolved_layer_index(settings)
    if target < 0 or not _layer_is_paintable(settings.layers[target]):
        target = _first_paintable_index(material)
    if target < 0:
        return {"ok": False, "reason": "paintable_layer_missing"}
    obj = getattr(context, "object", None)
    mode = str(getattr(obj, "mode", "OBJECT") or "OBJECT")
    # Every layer gets its session canvas, or the composite would miss the inactive ones.
    for index, layer in enumerate(settings.layers):
        if index != target and _layer_is_paintable(layer):
            activate_layer(context, material, index)
    result = dict(activate_layer(context, material, target) or {})
    if obj is not None and str(getattr(obj, "mode", "OBJECT") or "OBJECT") != mode:
        try:
            bpy.ops.object.mode_set(mode=mode)
        except Exception:
            pass
    return result


def ensure_material_canvas(context, material) -> bool:
    """Reconnect this material's active layer when the paint canvas belongs to something else."""
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    if not len(layers):
        return False
    paint = getattr(getattr(getattr(context, "scene", None), "tool_settings", None), "image_paint", None)
    canvas = getattr(paint, "canvas", None) if paint is not None else None
    material_name = str(getattr(material, "name", "") or "")
    owner = str(canvas.get("smart_paint_suite_material", "") or "") if canvas is not None else ""
    if owner == material_name:
        return False
    index = _resolved_layer_index(settings)
    if index < 0 or not _layer_is_paintable(layers[index]):
        return False
    owner_material = bpy.data.materials.get(owner) if owner else None
    if owner_material is not None:
        _snapshot_canvas_before_layer_switch(owner_material, "")
    return bool((activate_layer(context, material, index) or {}).get("ok", False))


@persistent
def _lightweight_load_post(_unused) -> None:
    """Repair only the active SPS material once after a .blend file load."""
    # Runtime identities belong to the previously loaded document. Keeping a
    # material-name-only source entry across File > Open can redirect bridge
    # and save operations to an unrelated PSD with the same material name.
    _SESSION_SOURCE_PATHS.clear()
    _resource_quota.clear_all_memory(reason="load_post")
    _mvp_state.clear_all()
    try:
        from .mvp import live_composite

        live_composite.clear_runtime_caches(remove_unused_owned_data=True)
    except (ImportError, AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    try:
        from . import external_bridge

        external_bridge.restore_after_load()
    except (ImportError, AttributeError, OSError, RuntimeError, TimeoutError):
        pass
    global _LOAD_POST_RUNNING
    if _LOAD_POST_RUNNING:
        return
    material = _resolve_material(getattr(bpy, "context", None))
    if material is None:
        return
    settings = _settings(material)
    try:
        managed = bool(getattr(settings, "managed", False)) if settings is not None else False
        lightweight = bool(material.get("sps_lightweight_mode", False))
        has_sps_layers = bool(len(getattr(settings, "layers", ()) or ())) if settings is not None else False
    except Exception:
        managed = False
        lightweight = False
        has_sps_layers = False
    if not (managed or lightweight or has_sps_layers):
        return
    _LOAD_POST_RUNNING = True
    try:
        # The lightweight namespace markers are acquired during register() and
        # owned by the active generation journal.  load_post is read/repair only
        # and must not create process-global state outside that transaction.
        source = _source_path(material)
        if _document_kind(material) == "FLAT":
            if not source:
                _restore_sourceless_document_after_load(bpy.context, material)
                return
            if not Path(source).is_file():
                return
            result = _restore_flat_document_after_load(bpy.context, material, source)
        else:
            # A layered PSD can be hundreds of MiB.  File-load recovery records
            # identity only; parsing, compositing and canvas materialization are
            # deferred to the user's next explicit layer/review/save operation.
            # This makes load_post finite and prevents ordinary UI callbacks from
            # importing psd_io/bodypaint_core/clean_layer_stack_engine.
            layers = list(getattr(settings, "layers", ()) or ()) if settings is not None else []
            try:
                target = int(getattr(settings, "active_layer_index", -1)) if settings is not None else -1
            except (AttributeError, ReferenceError, TypeError, ValueError):
                target = -1
            if target < 0 or target >= len(layers):
                target = _first_paintable_index(material)
            if source:
                _remember_session_source_path(material, source)
            result = {
                "ok": True,
                "reason": "layered_restore_deferred_to_explicit_operation",
                "document_kind": "LAYERED",
                "path": source,
                "layer_count": len(layers),
                "active_layer_index": int(target),
                "active_layer_name": str(getattr(layers[target], "name", "") or "") if 0 <= target < len(layers) else "",
                "active_record_index": _source_record_index(layers[target]) if 0 <= target < len(layers) else -1,
                "image": "",
                "elapsed_ms": 0.0,
            }
        _trace_lightweight(
            "lightweight_load_post_restore",
            material=material,
            ok=bool(result.get("ok", False)),
            reason=str(result.get("reason", "") or ""),
            active_layer_name=str(result.get("active_layer_name", "") or ""),
            active_record_index=int(result.get("active_record_index", -1) or -1),
            image=str(result.get("image", "") or ""),
            layer_count=int(result.get("layer_count", 0) or 0),
            elapsed_ms=float(result.get("elapsed_ms", 0.0) or 0.0),
        )
        try:
            from .mvp import image_editor_overlay

            image_editor_overlay.sync_handler_state()
        except Exception:
            pass
        try:
            from .mvp import solid_view_overlay

            solid_view_overlay.sync_handler_state()
        except Exception:
            pass
    finally:
        _LOAD_POST_RUNNING = False


def _plain_document_composite_signature(material) -> str:
    """Return a cheap exact-invalidation key for a simple flat paint stack."""
    if material is None or _document_kind(material) != "FLAT":
        return ""
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    if not layers:
        return ""
    material_name = str(getattr(material, "name", "") or "")
    bucket = _ACTIVATED_LAYERS.get(material_name, {}) or {}
    layer_pixels = []
    for index, layer in enumerate(layers):
        if (
            not _layer_is_paintable(layer)
            or bool(getattr(layer, "is_group", False))
            or str(getattr(layer, "layer_kind", "PAINT") or "PAINT").upper() != "PAINT"
            or str(getattr(layer, "mask_mode", "NONE") or "NONE").upper() not in {"", "NONE", "OFF"}
            or bool(str(getattr(layer, "mask_image", "") or ""))
        ):
            return ""
        layer_id = _layer_id(layer, index)
        entry = bucket.get(layer_id, {}) or {}
        image_name = str(
            entry.get("image", "")
            or getattr(layer, "base_color_image", "")
            or ""
        )
        image = bpy.data.images.get(image_name) if image_name else None
        try:
            image_pointer = int(image.as_pointer()) if image is not None else 0
        except Exception:
            image_pointer = 0
        try:
            image_revision = int(image.get("smart_paint_suite_pixel_revision", 0) or 0) if image is not None else 0
        except Exception:
            image_revision = 0
        try:
            authoritative_revision = int(
                image.get("smart_paint_suite_layer_authoritative_revision", 0) or 0
            ) if image is not None else 0
        except Exception:
            authoritative_revision = 0
        layer_pixels.append(
            (
                str(layer_id),
                image_name,
                image_pointer,
                image_revision,
                authoritative_revision,
                int(entry.get("current_payload_revision", 0) or 0),
            )
        )
    try:
        material_pointer = int(material.as_pointer())
    except Exception:
        material_pointer = 0
    payload = {
        "material": material_name,
        "material_pointer": material_pointer,
        "source": _session_source_path(material) or _source_path(material),
        "size": list(_document_size(material)),
        "metadata": _metadata_state(material),
        "pixels": layer_pixels,
    }
    try:
        encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except Exception:
        return ""
    return hashlib.sha256(encoded.encode("utf-8", errors="surrogatepass")).hexdigest()


def _compose_document_pixels(material, context=None) -> tuple[object | None, dict[str, object]]:
    """Return the current visible stack, independent of the selected display mode."""
    snapshot = _snapshot_canvas_before_layer_switch(material, "")
    cache_signature = _plain_document_composite_signature(material) if isinstance(snapshot, dict) else ""
    cache_key = _session_material_key(material)
    cached = _DOCUMENT_COMPOSITE_CACHE.get(cache_key, {}) if cache_signature else {}
    if (
        cache_signature
        and str(cached.get("signature", "") or "") == cache_signature
        and cached.get("pixels") is not None
    ):
        pixels = cached.get("pixels")
        try:
            height, width = int(pixels.shape[0]), int(pixels.shape[1])
        except Exception:
            width = height = 0
        if width > 0 and height > 0:
            return pixels, {
                "ok": True,
                "reason": "current_composite_cache_hit",
                "width": width,
                "height": height,
                "cached": True,
            }
    direct_pixels = None
    direct_result: dict[str, object] = {}
    try:
        from .mvp import live_composite

        direct_pixels, direct_result = live_composite.compose_current_stack_pixels(
            material,
            context or bpy.context,
        )
    except Exception as exc:
        direct_result = {
            "ok": False,
            "reason": "document_composite_exception",
            "error": repr(exc)[:400],
        }
    if direct_pixels is not None and bool(direct_result.get("ok", False)):
        if cache_signature:
            _DOCUMENT_COMPOSITE_CACHE.clear()
            _cache_store(_DOCUMENT_COMPOSITE_CACHE, cache_key, {
                "signature": cache_signature,
                "pixels": direct_pixels,
            })
        return direct_pixels, direct_result
    if _document_kind(material) == "FLAT":
        return None, dict(direct_result or {})
    image, review = _build_current_psd_composite_preview(material, force=True)
    payload = _read_image_pixels_u8(image)
    if image is None or not bool(review.get("ok", False)) or payload is None:
        result = dict(review or direct_result or {})
        result["direct_reason"] = str(direct_result.get("reason", "") or "")
        return None, result
    width, height, pixels = payload
    result = dict(review)
    result.update({"ok": True, "width": int(width), "height": int(height)})
    return pixels, result


def _flat_save_needs_confirmation(material) -> bool:
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    if len(layers) > 1:
        return True
    for layer in layers:
        try:
            if bool(getattr(layer, "is_group", False)):
                return True
            if str(getattr(layer, "layer_kind", "PAINT") or "PAINT").upper() != "PAINT":
                return True
            if str(getattr(layer, "mask_mode", "NONE") or "NONE").upper() not in {"", "NONE", "OFF"}:
                return True
            if str(getattr(layer, "mask_image", "") or ""):
                return True
        except Exception:
            return True
    return False


def save_flat_document(
    material,
    context=None,
    *,
    destination_path: str = "",
    confirm_flatten: bool = False,
) -> dict[str, object]:
    """Save the exact current stack to a non-layered image without flattening state."""
    started = time.perf_counter()
    # User-work-first re-arm; see save_psd.
    try:
        from . import runtime_registry as _sps_registry
        _sps_registry.ensure_runtime_ready()
    except Exception:
        pass
    source = _session_source_path(material) or _source_path(material)
    try:
        destination = str(Path(bpy.path.abspath(destination_path or source)).resolve())
    except Exception:
        destination = str(destination_path or source or "")
    if not destination:
        return {"ok": False, "reason": "flat_destination_missing"}
    path = Path(destination)
    if path.suffix.lower() in _image_io.LAYERED_EXTENSIONS:
        return {"ok": False, "reason": "layered_destination_requires_psd_save", "path": destination}
    if _flat_save_needs_confirmation(material) and not bool(confirm_flatten):
        return {"ok": False, "reason": "flatten_confirmation_required", "path": destination}
    try:
        protected = bool(material.get("sps_lightweight_flat_photoshop_layer_tiff", False))
    except Exception:
        protected = False
    try:
        same_source = bool(source and Path(source).resolve() == path.resolve())
    except Exception:
        same_source = False
    if protected and same_source:
        return {"ok": False, "reason": "ps_layer_tiff_protected", "path": destination}

    pixels, composite_result = _compose_document_pixels(material, context)
    if pixels is None or not bool(composite_result.get("ok", False)):
        return {
            "ok": False,
            "reason": "current_composite_unavailable",
            "path": destination,
            "composite_reason": str(composite_result.get("reason", "") or ""),
            "error": str(composite_result.get("error", "") or ""),
        }
    pixel_hash = _image_io.pixels_sha256(pixels)
    try:
        last_path = str(material.get("sps_lightweight_flat_last_saved_path", "") or "")
        last_pixel_hash = str(material.get("sps_lightweight_flat_last_saved_pixel_sha256", "") or "")
        last_file_hash = str(material.get("sps_lightweight_flat_last_saved_file_sha256", "") or "")
    except Exception:
        last_path = last_pixel_hash = last_file_hash = ""
    unchanged = False
    if last_path and pixel_hash and pixel_hash == last_pixel_hash and path.is_file():
        try:
            unchanged = Path(last_path).resolve() == path.resolve() and (
                not last_file_hash or _image_io.file_sha256(path) == last_file_hash
            )
        except Exception:
            unchanged = False
    if unchanged:
        return {
            "ok": True,
            "reason": "no_changes",
            "path": destination,
            "pixel_sha256": pixel_hash,
            "elapsed_ms": 0.0,
        }
    try:
        preferred_format = str(material.get("sps_lightweight_document_format", "") or "")
    except Exception:
        preferred_format = ""
    result = dict(
        _image_io.write_flat_pixels_atomic(
            destination,
            pixels,
            preferred_format=preferred_format if same_source else "",
        )
        or {}
    )
    result["composite_reason"] = str(composite_result.get("reason", "") or "")
    if bool(result.get("ok", False)):
        try:
            material["sps_lightweight_flat_last_saved_path"] = destination
            material["sps_lightweight_flat_last_saved_pixel_sha256"] = pixel_hash
            material["sps_lightweight_flat_last_saved_file_sha256"] = str(result.get("file_sha256", "") or "")
            material["sps_lightweight_last_save_ok"] = True
            material["sps_lightweight_last_save_ms"] = float(result.get("elapsed_ms", 0.0) or 0.0)
            material["sps_lightweight_last_save_path"] = destination
        except Exception:
            pass
    result["elapsed_total_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
    _trace_lightweight("lightweight_flat_document_save", material=material, **result)
    return result


def _save_psd_as_document(material, context, destination: str) -> dict[str, object]:
    """Save-As layered boundary; same display contract as `save_psd`."""
    state = _begin_psd_save_display_contract(material, context)
    ok = False
    try:
        result = _save_psd_as_document_impl(material, context, destination)
        ok = bool(result.get("ok", False))
        return result
    finally:
        _end_psd_save_display_contract(material, context, state, ok)


def _save_psd_as_document_impl(material, context, destination: str) -> dict[str, object]:
    # Same user-work-first re-arm as save_psd: Save As must never be refused
    # by registry dormancy after a file-load boundary.
    try:
        from . import runtime_registry as _sps_registry
        _sps_registry.ensure_runtime_ready()
    except Exception:
        pass
    source = _session_source_path(material) or _source_path(material)
    if material is None or not source or not Path(source).is_file():
        return {"ok": False, "reason": "source_psd_missing", "path": source}
    signature = _image_io.sniff_layered_signature(source)
    if signature not in {"PSD", "PSB"}:
        return {"ok": False, "reason": "source_layered_signature_invalid", "path": source}
    target = Path(destination)
    if target.suffix.lower() not in _image_io.LAYERED_EXTENSIONS:
        target = target.with_suffix(Path(source).suffix.lower() or ".psd")
    if not _image_io.layered_extension_matches_signature(target, signature):
        return {
            "ok": False,
            "reason": "layered_cross_format_conversion_unsupported",
            "path": str(target.resolve()),
            "source_format": signature,
        }
    destination = str(target.resolve())
    final_destination = destination
    atomic_temporary = ""
    if Path(destination) != Path(source):
        try:
            Path(destination).parent.mkdir(parents=True, exist_ok=True)
            atomic_temporary = str(Path(destination).with_name(
                f".{Path(destination).stem}.sps-saveas-{uuid.uuid4().hex[:8]}{Path(destination).suffix}"
            ))
            shutil.copy2(source, atomic_temporary)
            destination = atomic_temporary
        except Exception as exc:
            if atomic_temporary:
                try:
                    Path(atomic_temporary).unlink(missing_ok=True)
                except Exception:
                    pass
            return {"ok": False, "reason": "psd_copy_failed", "error": repr(exc)[:300], "path": destination}
    old_source = source
    image_paths = []
    if atomic_temporary:
        try:
            material["sps_lightweight_defer_external_save_notify"] = True
        except Exception:
            pass
    try:
        for entry in (_ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}).values():
            image = bpy.data.images.get(str((entry or {}).get("image", "") or ""))
            if image is None:
                continue
            old_file = str(image.get("smart_paint_suite_source_file", "") or "")
            old_layered = str(image.get("smart_paint_suite_layered_source_path", "") or "")
            image_paths.append((image, old_file, old_layered))
            image["smart_paint_suite_source_file"] = destination
            image["smart_paint_suite_layered_source_path"] = destination
        _set_source_path(material, destination)
        result = save_psd(material, context, destination_path=destination)
    except Exception as exc:
        result = {"ok": False, "reason": "psd_save_as_exception", "error": repr(exc)[:400]}
    if atomic_temporary:
        try:
            if "sps_lightweight_defer_external_save_notify" in material:
                del material["sps_lightweight_defer_external_save_notify"]
        except Exception:
            pass
    if not bool(result.get("ok", False)):
        _rebind_source_path_only(material, old_source)
        for image, old_file, old_layered in image_paths:
            try:
                image["smart_paint_suite_source_file"] = old_file
                image["smart_paint_suite_layered_source_path"] = old_layered
            except Exception:
                pass
        if atomic_temporary:
            try:
                Path(atomic_temporary).unlink(missing_ok=True)
            except Exception:
                pass
        try:
            result["path"] = final_destination
        except Exception:
            pass
        return result
    if atomic_temporary:
        try:
            os.replace(destination, final_destination)
        except Exception as exc:
            _rebind_source_path_only(material, old_source)
            try:
                Path(atomic_temporary).unlink(missing_ok=True)
            except Exception:
                pass
            return {
                "ok": False,
                "reason": "psd_save_as_promote_failed",
                "error": repr(exc)[:300],
                "path": final_destination,
            }
        destination = final_destination
        _rebind_source_path_only(material, destination)
        try:
            callback = bpy.app.driver_namespace.get("sps_external_bridge_on_core_save")
            if callable(callback):
                callback(material=material, path=destination, trace_id="")
        except Exception as exc:
            _trace_lightweight(
                "lightweight_external_bridge_notify_failed",
                material=material,
                trace_id="",
                path=destination,
                error=repr(exc)[:384],
            )
    width, height = _document_size(material)
    _set_document_identity(
        material,
        kind="LAYERED",
        path=destination,
        width=width,
        height=height,
        file_format="PSB" if signature == "PSB" else "PSD",
        depth=8,
    )
    _remember_session_source_path(material, destination)
    result["path"] = destination
    return result


def _owner_props_snapshot(owner, keys) -> dict[str, tuple[bool, object]]:
    snapshot = {}
    for key in keys:
        try:
            snapshot[str(key)] = (bool(key in owner), owner.get(key, None))
        except Exception:
            snapshot[str(key)] = (False, None)
    return snapshot


def _restore_owner_props(owner, snapshot) -> None:
    for key, (present, value) in dict(snapshot or {}).items():
        try:
            if present:
                owner[key] = value
            elif key in owner:
                del owner[key]
        except Exception:
            pass


def _current_layer_pixels(material, layer, index: int):
    """Return layer pixels after the caller has snapshotted the paint canvas."""
    layer_id = _layer_id(layer, index)
    entry = _mvp_state.get_layer(material, layer_id) or {}
    width, height = _document_size(material)
    pixels = _payload_pixels_u8(entry.get("current_payload"), width, height)
    if pixels is not None:
        return pixels
    image = _mvp_state.matching_canvas(material, layer_id, _source_record_index(layer))
    if image is None:
        image = bpy.data.images.get(str(getattr(layer, "base_color_image", "") or ""))
    payload = _read_image_pixels_u8(image)
    if payload is None:
        return None
    return payload[2]


def _rebind_promoted_runtime(material, destination: str) -> None:
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    bucket = _ACTIVATED_LAYERS.get(str(getattr(material, "name", "") or ""), {}) or {}
    for index, layer in enumerate(layers):
        record_index = _source_record_index(layer)
        if record_index < 0:
            continue
        layer_id = _layer_id(layer, index)
        _stamp_imported_source_identity(layer, destination, record_index)
        entry = bucket.get(layer_id)
        if isinstance(entry, dict):
            entry["record_index"] = int(record_index)
            image = bpy.data.images.get(str(entry.get("image", "") or ""))
            if image is not None:
                _stamp_imported_source_identity(image, destination, record_index)


def promote_flat_document_to_psd(material, context, destination: str) -> dict[str, object]:
    """Bootstrap one PSD/PSB source record, then reuse the structure writer."""
    started = time.perf_counter()
    target = Path(destination).resolve()
    if target.suffix.lower() not in _image_io.LAYERED_EXTENSIONS:
        target = target.with_suffix(".psd")
    settings = _settings(material)
    layers = list(getattr(settings, "layers", ()) if settings is not None else ())
    anchor_index = next((index for index, layer in enumerate(layers) if _layer_is_paintable(layer)), -1)
    if anchor_index < 0:
        return {"ok": False, "reason": "paintable_layer_missing", "path": str(target)}
    merged, composite_result = _compose_document_pixels(material, context)
    anchor = layers[anchor_index]
    # _compose_document_pixels() above already captured the active paint canvas.
    # Repeating that 4096px readback here adds seconds to flat-to-PSD promotion.
    anchor_pixels = _current_layer_pixels(material, anchor, anchor_index)
    if merged is None or anchor_pixels is None:
        return {
            "ok": False,
            "reason": "promotion_pixels_unavailable",
            "path": str(target),
            "composite_reason": str(composite_result.get("reason", "") or ""),
        }
    suffix = target.suffix.lower()
    work = target.with_name(f".{target.stem}.sps-promote-{uuid.uuid4().hex[:8]}{suffix}")
    template_writer = (
        _image_io.write_minimal_psb_template
        if suffix in _image_io.PSB_EXTENSIONS
        else _image_io.write_minimal_psd_template
    )
    template = template_writer(
        work,
        anchor_pixels,
        merged,
        layer_name=str(getattr(anchor, "name", "") or "Layer"),
        layer_id=int(hashlib.sha1(_layer_id(anchor, anchor_index).encode("utf-8")).hexdigest()[:8], 16) & 0x7FFFFFFF,
    )
    if not bool(template.get("ok", False)):
        return dict(template)
    old_source = _source_path(material)
    old_session = _session_source_path(material)
    old_kind = _document_kind(material)
    old_record_index = _source_record_index(anchor)
    anchor_id = _layer_id(anchor, anchor_index)
    old_entry = dict(_mvp_state.get_layer(material, anchor_id) or {})
    canvas = _mvp_state.matching_canvas(material, anchor_id, old_record_index)
    changed_keys = (
        "smart_paint_suite_source_file",
        "smart_paint_suite_layered_source_path",
        "sps_psd_source_order",
        "sps_psd_source_ordinal",
        "sps_psd_source_layer_index",
        "smart_paint_suite_lazy_psd_key",
        "smart_paint_suite_lazy_psd_pending",
    )
    anchor_props = _owner_props_snapshot(anchor, changed_keys)
    canvas_props = _owner_props_snapshot(canvas, changed_keys) if canvas is not None else {}
    succeeded = False
    try:
        anchor.psd_source_record_index = 0
        _stamp_imported_source_identity(anchor, str(work), 0)
        if canvas is not None:
            _stamp_imported_source_identity(canvas, str(work), 0)
        promoted_entry = dict(old_entry)
        promoted_entry.update({"layer_id": anchor_id, "record_index": 0})
        if canvas is not None:
            promoted_entry["image"] = str(canvas.name)
        _mvp_state.put_layer(material, anchor_id, promoted_entry)
        _set_source_path(material, str(work))
        _SESSION_SOURCE_PATHS[_session_material_key(material)] = str(work)
        _mark_structure_dirty(material, reason="flat_document_psd_promotion", order=True)
        result = save_psd(material, context, destination_path=str(work))
        if not bool(result.get("ok", False)):
            return result
        try:
            os.replace(str(work), str(target))
        except PermissionError as exc:
            recovery = target.with_name(
                f"{target.stem}_SPS_recovery_{int(time.time())}{target.suffix}"
            )
            try:
                os.replace(str(work), str(recovery))
            except Exception:
                recovery = Path("")
            return {
                "ok": False,
                "reason": "destination_locked",
                "path": str(target),
                "recovery_path": str(recovery) if str(recovery) else "",
                "error": repr(exc)[:300],
            }
        _rebind_source_path_only(material, str(target))
        _rebind_promoted_runtime(material, str(target))
        width, height = _document_size(material)
        _set_document_identity(
            material,
            kind="LAYERED",
            path=str(target),
            width=width,
            height=height,
            file_format="PSB" if suffix == ".psb" else "PSD",
            depth=8,
        )
        _clear_flat_document_markers(material)
        _remember_session_source_path(material, str(target))
        _store_metadata_baseline(material)
        result.update({
            "ok": True,
            "reason": "flat_document_promoted_to_psd",
            "path": str(target),
            "template_elapsed_ms": float(template.get("elapsed_ms", 0.0) or 0.0),
            "elapsed_total_ms": round((time.perf_counter() - started) * 1000.0, 3),
        })
        succeeded = True
        return result
    except Exception as exc:
        return {
            "ok": False,
            "reason": "flat_psd_promotion_exception",
            "path": str(target),
            "error": repr(exc)[:512],
        }
    finally:
        if not succeeded:
            try:
                anchor.psd_source_record_index = int(old_record_index)
            except Exception:
                pass
            _restore_owner_props(anchor, anchor_props)
            if canvas is not None:
                _restore_owner_props(canvas, canvas_props)
            if old_entry:
                _mvp_state.put_layer(material, anchor_id, old_entry)
            else:
                _mvp_state.remove_layer(material, anchor_id)
            _set_source_path(material, old_source)
            try:
                material[_DOCUMENT_KIND_KEY] = old_kind
            except Exception:
                pass
            key = _session_material_key(material)
            if old_session:
                _SESSION_SOURCE_PATHS[key] = old_session
            else:
                _SESSION_SOURCE_PATHS.pop(key, None)
        try:
            if work.is_file():
                work.unlink()
        except Exception:
            pass


class SPS_OT_lightweight_open_image(bpy.types.Operator, ImportHelper):
    bl_idname = "smart_paint_suite.lightweight_open_image"
    bl_label = "画像を開く"
    bl_description = "PSD/PSBは構造を保持し、その他の画像は1枚のペイントレイヤーとして開きます"
    bl_options = set()

    filename_ext = ""
    filter_glob: StringProperty(default=_IMAGE_FILTER_GLOB, options={"HIDDEN"})

    @_resource_quota.operation_boundary("lightweight.open_image")
    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなメッシュのマテリアルがありません。"))
            return {"CANCELLED"}
        try:
            path = str(Path(bpy.path.abspath(self.filepath)).resolve())
        except Exception:
            path = str(self.filepath or "")
        if not path or not Path(path).is_file():
            self.report({"ERROR"}, _rpt("画像ファイルが見つかりません。"))
            return {"CANCELLED"}
        extension = Path(path).suffix.lower()
        signature = _image_io.sniff_layered_signature(path)
        if signature and not _image_io.layered_extension_matches_signature(path, signature):
            self.report({"ERROR"}, _rpt("PSD/PSBの内容と拡張子が一致しないため、安全のため読込を中止しました。"))
            return {"CANCELLED"}
        if extension in _image_io.LAYERED_EXTENSIONS:
            result = _load_psd_for_material(context, material, path, reason="explicit_open")
        else:
            result = _load_flat_image_for_material(context, material, path, reason="explicit_open")
        if not bool(result.get("ok", False)):
            self.report(
                {"ERROR"},
                _rpt_fail("画像読込に失敗しました", result.get("activation_reason", result.get("error", result.get("reason", "")))),
            )
            return {"CANCELLED"}
        kind = str(result.get("document_kind", "LAYERED" if extension in _image_io.LAYERED_EXTENSIONS else "FLAT"))
        if kind == "FLAT":
            self.report(
                {"INFO"},
                _rpt("{} を1レイヤーで読込 ({:.0f} ms)", Path(path).name, float(result.get('elapsed_ms', 0.0) or 0.0)),
            )
        else:
            self.report(
                {"INFO"},
                _rpt("PSD {}層を読込 ({:.0f} ms)", int(result.get('layer_count', 0) or 0), float(result.get('elapsed_ms', 0.0) or 0.0)),
            )
        return {"FINISHED"}


# 1.9.291: user-facing "saved, but merged preview kept as-is" warning.
# English is the catalog source; the Japanese entry lives in
# translation.BASE_TRANSLATIONS and resolves through constants.report_text.
_PSD_PREVIEW_WARNING_REPORT_EN = (
    "Save completed (merged preview refresh failed). Layers were saved and validated; "
    "the PSD keeps its existing merged preview."
)


def _psd_preview_warning_report_text(context) -> str:
    try:
        from .constants import report_text

        return str(report_text(_PSD_PREVIEW_WARNING_REPORT_EN, context) or _PSD_PREVIEW_WARNING_REPORT_EN)
    except Exception:
        return _PSD_PREVIEW_WARNING_REPORT_EN


def _rejected_copy_report_text(context, material) -> str:
    """USER-WORK-FIRST: when the postcondition refused the save but the engine
    parked the finished file beside the source, tell the user where it is."""
    try:
        rejected = str(material.get("sps_last_psd_rejected_copy_BASE_COLOR", "") or "")
    except Exception:
        rejected = ""
    if not rejected:
        return ""
    source = f"Save aborted (validation diff). A verification copy was saved to '{rejected}'."
    try:
        from .constants import report_text

        return str(report_text(source, context) or source)
    except Exception:
        return source


def _report_preview_warning_if_any(operator, context, result) -> bool:
    try:
        warning = str((result or {}).get("preview_warning", "") or "")
    except Exception:
        warning = ""
    if not warning:
        return False
    try:
        operator.report({"WARNING"}, _psd_preview_warning_report_text(context))
    except Exception:
        pass
    return True


class SPS_OT_lightweight_save_image(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_save_image"
    bl_label = "画像を保存"
    bl_description = "PSD/PSBはレイヤー構造を保持し、その他の形式は現在の全レイヤー合成を保存します"
    bl_options = set()

    confirm_flatten: BoolProperty(default=False, options={"SKIP_SAVE"})

    def invoke(self, context, event):
        material = _resolve_material(context)
        if material is not None and _document_kind(material) == "FLAT" and _flat_save_needs_confirmation(material):
            self.confirm_flatten = True
            return context.window_manager.invoke_props_dialog(self, width=420)
        return self.execute(context)

    def draw(self, context):
        if not bool(self.confirm_flatten):
            return
        column = self.layout.column(align=True)
        column.label(text="この形式はレイヤー構造を保存できません。", icon="ERROR")
        column.label(text="表示中の全レイヤー合成を画像へ保存します。")
        column.label(text="Smart Paint内のレイヤースタックは維持されます。")

    @_resource_quota.operation_boundary("lightweight.save_image")
    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        if _document_kind(material) == "LAYERED":
            result = save_psd(material, context)
        else:
            result = save_flat_document(
                material,
                context,
                confirm_flatten=bool(self.confirm_flatten),
            )
        if not bool(result.get("ok", False)):
            rejected_text = _rejected_copy_report_text(context, material) if _document_kind(material) == "LAYERED" else ""
            if rejected_text:
                self.report({"ERROR"}, rejected_text[:512])
            else:
                reason = str(result.get("error") or result.get("reason") or "")
                self.report({"ERROR"}, _rpt_fail("保存を中止しました", reason))
            return {"CANCELLED"}
        if str(result.get("reason", "")) == "no_changes":
            self.report({"INFO"}, _rpt("変更がないため再圧縮せず保存を省略しました。"))
        elif _report_preview_warning_if_any(self, context, result):
            pass
        else:
            elapsed = float(result.get("elapsed_total_ms", result.get("elapsed_ms", 0.0)) or 0.0)
            self.report({"INFO"}, _rpt("保存: {} ({:.0f} ms)", Path(str(result.get('path', '') or '')).name, elapsed))
        return {"FINISHED"}


class SPS_OT_lightweight_save_image_as(bpy.types.Operator, ExportHelper):
    bl_idname = "smart_paint_suite.lightweight_save_image_as"
    bl_label = "画像を別名保存"
    bl_description = "PSD/PSBはレイヤー構造を保持し、非レイヤー形式は現在の合成をコピーとして保存します"
    bl_options = set()

    filename_ext = ""
    # The generic dialog intentionally switches between layered and flat
    # destinations. ExportHelper.check() otherwise strips the user's suffix
    # when filename_ext is empty, making a typed `.psd` fall back to the
    # source `.png` in execute().
    check_extension = None
    filter_glob: StringProperty(default=_IMAGE_FILTER_GLOB, options={"HIDDEN"})

    def invoke(self, context, event):
        material = _resolve_material(context)
        source = _session_source_path(material) or _source_path(material)
        if source and not self.filepath:
            source_path = Path(source)
            self.filepath = str(source_path.with_name(source_path.stem + "_copy" + source_path.suffix))
        return super().invoke(context, event)

    @_resource_quota.operation_boundary("lightweight.save_image_as")
    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        source = _session_source_path(material) or _source_path(material)
        try:
            destination = Path(bpy.path.abspath(self.filepath)).resolve()
        except Exception:
            destination = Path(self.filepath)
        if not destination.suffix:
            destination = destination.with_suffix(Path(source).suffix if source else ".png")
        if destination.suffix.lower() in _image_io.LAYERED_EXTENSIONS:
            if _document_kind(material) == "FLAT":
                result = promote_flat_document_to_psd(material, context, str(destination))
            else:
                result = _save_psd_as_document(material, context, str(destination))
        else:
            result = save_flat_document(
                material,
                context,
                destination_path=str(destination),
                confirm_flatten=True,
            )
        if not bool(result.get("ok", False)):
            reason = str(result.get("error") or result.get("reason") or "")
            self.report({"ERROR"}, _rpt_fail("別名保存を中止しました", reason))
            return {"CANCELLED"}
        if not _report_preview_warning_if_any(self, context, result):
            elapsed = float(result.get("elapsed_total_ms", result.get("elapsed_ms", 0.0)) or 0.0)
            self.report({"INFO"}, _rpt("別名保存: {} ({:.0f} ms)", Path(str(result.get('path', destination))).name, elapsed))
        return {"FINISHED"}


class SPS_OT_lightweight_open_psd(bpy.types.Operator, ImportHelper):
    bl_idname = "smart_paint_suite.lightweight_open_psd"
    bl_label = "PSDを開く"
    bl_description = "PSDのレイヤーメタデータを読み込み、選択レイヤーだけをテクスチャペイントへ接続します"
    bl_options = set()

    filename_ext = ".psd"
    filter_glob: StringProperty(default="*.psd;*.psb;*.pdd", options={"HIDDEN"})

    @_resource_quota.operation_boundary("lightweight.open_psd")
    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなメッシュのマテリアルがありません。"))
            return {"CANCELLED"}
        path = str(Path(bpy.path.abspath(self.filepath)).resolve())
        if not Path(path).is_file():
            self.report({"ERROR"}, _rpt("PSDファイルが見つかりません。"))
            return {"CANCELLED"}
        result = _load_psd_for_material(context, material, path, reason="explicit_open")
        if not bool(result.get("ok", False)):
            self.report(
                {"ERROR"},
                _rpt_fail("PSD読込に失敗しました", result.get("activation_reason", result.get("error", result.get("reason", "")))),
            )
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            _rpt("PSD {}層を読込 ({:.0f} ms)", int(result.get('layer_count', 0) or 0), float(result.get('elapsed_ms', 0.0) or 0.0)),
        )
        return {"FINISHED"}


class SPS_OT_lightweight_activate_layer(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_activate_layer"
    bl_label = "描画レイヤーを選択"
    bl_description = "このレイヤーだけをBlender標準のテクスチャペイントの画像として表示・接続します"
    bl_options = set()

    layer_index: IntProperty(default=-1)

    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        result = activate_layer(context, material, int(self.layer_index))
        if not bool(result.get("ok", False)):
            self.report({"WARNING"}, _rpt_fail("描画できないレイヤーです", result.get("reason", "")))
            return {"CANCELLED"}
        self.report({"INFO"}, f"{result.get('layer_name', '')} ({result.get('elapsed_ms', 0):.0f} ms)")
        return {"FINISHED"}


class SPS_OT_lightweight_save_psd(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_save_psd"
    bl_label = "PSDを保存"
    bl_description = "描画したレイヤーだけを差し替え、元のPSDレイヤー構造を維持して保存します"
    bl_options = set()

    @_resource_quota.operation_boundary("lightweight.save_psd")
    def execute(self, context):
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        result = save_psd(material, context)
        if not bool(result.get("ok", False)):
            rejected_text = _rejected_copy_report_text(context, material)
            if rejected_text:
                self.report({"ERROR"}, rejected_text[:512])
            else:
                self.report({"ERROR"}, _rpt_fail("PSD保存を中止しました", result.get("error", result.get("reason", ""))))
            return {"CANCELLED"}
        if not _report_preview_warning_if_any(self, context, result):
            self.report({"INFO"}, _rpt("PSD保存: {}層 ({:.0f} ms)", result.get('layer_count', 0), result.get('elapsed_ms', 0)))
        return {"FINISHED"}


class SPS_OT_lightweight_save_psd_as(bpy.types.Operator, ExportHelper):
    bl_idname = "smart_paint_suite.lightweight_save_psd_as"
    bl_label = "PSDを別名保存"
    bl_description = "元PSDを複製し、現在のレイヤー構造と編集を別ファイルへ保存します"
    bl_options = set()

    filename_ext = ".psd"
    filter_glob: StringProperty(default="*.psd;*.psb;*.pdd", options={"HIDDEN"})

    def invoke(self, context, event):
        material = _resolve_material(context)
        source = _session_source_path(material) or _source_path(material)
        if source and not self.filepath:
            self.filepath = str(Path(source).with_name(Path(source).stem + "_copy" + Path(source).suffix))
        return super().invoke(context, event)

    @_resource_quota.operation_boundary("lightweight.save_psd_as")
    def execute(self, context):
        material = _resolve_material(context)
        source = _session_source_path(material) or _source_path(material)
        if material is None or not source or not Path(source).is_file():
            self.report({"ERROR"}, _rpt("元PSDがありません。"))
            return {"CANCELLED"}
        destination = str(Path(bpy.path.abspath(self.filepath)).resolve())
        if Path(destination).suffix.lower() not in _image_io.LAYERED_EXTENSIONS:
            destination += Path(source).suffix.lower() or ".psd"
        signature = _image_io.sniff_layered_signature(source)
        if signature not in {"PSD", "PSB"}:
            self.report({"ERROR"}, _rpt("元PSDがありません。"))
            return {"CANCELLED"}
        if not _image_io.layered_extension_matches_signature(destination, signature):
            self.report({"ERROR"}, _rpt("PSD/PSB間の拡張子だけの変換はできません。"))
            return {"CANCELLED"}
        result = _save_psd_as_document(material, context, destination)
        if not bool(result.get("ok", False)):
            rejected_text = _rejected_copy_report_text(context, material)
            if rejected_text:
                self.report({"ERROR"}, rejected_text[:512])
            else:
                self.report({"ERROR"}, _rpt_fail("PSD Save As failed", result.get("error", result.get("reason", ""))))
            return {"CANCELLED"}
        destination = str(result.get("path", destination) or destination)
        if not _report_preview_warning_if_any(self, context, result):
            self.report({"INFO"}, _rpt("PSD Save As: {} ({:.0f} ms)", Path(destination).name, result.get('elapsed_ms', 0)))
        return {"FINISHED"}


class SPS_OT_lightweight_select_layer(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_select_layer"
    bl_label = "レイヤーを選択"
    bl_description = "レイヤーを選択します。ピクセルレイヤーはテクスチャペイント対象にもなります"
    bl_options = set()

    layer_index: IntProperty(default=-1)

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings, self.layer_index) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        layer = settings.layers[index]
        try:
            _set_active_indices(settings, int(index))
        except Exception:
            pass
        if _layer_is_paintable(layer):
            result = activate_layer(context, material, index)
            if not bool(result.get("ok", False)):
                self.report({"WARNING"}, _rpt_fail("描画対象へ接続できません", result.get("reason", "")))
                return {"CANCELLED"}
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_show_composite(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_show_composite"
    bl_label = "現在の全体合成を確認"
    bl_description = "現在の可視レイヤースタックと未保存描画を正確に合成した一時確認画像を作ります"
    bl_options = set()

    force_refresh: BoolProperty(default=False, options={"SKIP_SAVE"})

    @_resource_quota.operation_boundary("lightweight.review_composite")
    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        material = _resolve_material(context)
        if material is None:
            ready = {"ok": False, "reason": "smart_paint_material_not_found"}
        elif _document_kind(material) == "LAYERED":
            ready = _ensure_layered_document_ready(
                material,
                context,
                reason="show_composite",
            )
        else:
            ready = {"ok": True, "reason": "flat_document_ready"}
        if not bool(ready.get("ok", False)):
            self.report({"ERROR"}, _ui_fmt("合成を確認できません: {}", _ui_fmt(_document_refusal_text(ready))))
            return {"CANCELLED"}
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        material_name = str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")
        if material_name:
            _PROPERTY_REFRESH_PENDING.pop(material_name, None)
        # Each segmented display button owns one explicit mode. Reusing a
        # cached live graph here left LIVE_COMPOSITE selected forever, so the
        # user could not activate the requested read-only full review. Remove
        # the live graph and its large source cache before allocating the CPU
        # snapshot; the native layer canvas remains the paint target.
        try:
            from .mvp import live_composite

            live_composite.disable(material, remove_nodes=True)
            live_composite.clear_material_cache(material, remove_unused_images=True)
        except Exception:
            pass
        try:
            material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
        except Exception:
            pass
        try:
            from .mvp import image_editor_overlay

            image_editor_overlay.sync_handler_state()
        except Exception:
            pass
        try:
            from .mvp import solid_view_overlay

            solid_view_overlay.sync_handler_state()
        except Exception:
            pass
        _restore_active_layer_display(material, context)
        image, result = _build_current_psd_composite_preview(material, force=bool(self.force_refresh))
        if image is None or not bool(result.get("ok", False)):
            self.report({"ERROR"}, _rpt_fail("全体合成を取得できません", result.get("reason", "")))
            return {"CANCELLED"}
        if not _bind_manual_composite_display(material, image, context):
            self.report({"ERROR"}, _rpt("全体合成を表示できませんでした。"))
            return {"CANCELLED"}
        try:
            material["sps_lightweight_last_composite_ms"] = float(result.get("elapsed_ms", 0.0) or 0.0)
        except Exception:
            pass
        suffix = f"{float(result.get('elapsed_ms', 0.0) or 0.0):.0f} ms"
        fallback = list(result.get("fallback_layers", []) or [])
        unrecoverable = int(result.get("unrecoverable_pixels", 0) or 0)
        if fallback or unrecoverable:
            self.report({"WARNING"}, _rpt("現在の全体合成を表示（一部の深い効果層は近似） ({})", suffix))
        else:
            self.report({"INFO"}, _rpt("現在の全体合成を表示 ({})", suffix))
        _tag_redraw(context)
        return {"FINISHED"}


_LIVE_COMPOSITE_REFUSAL_TEXT = {
    "source_psd_missing": "開いたファイルが見つかりません",
    "source_records_missing": "描けるレイヤーがありません",
    "paint_source_records_missing": "描けるレイヤーがありません",
    "paint_blend_mode_unsupported": "対応していない合成モードのレイヤーがあります",
    "source_blend_mode_unsupported": "対応していない合成モードのレイヤーがあります",
    "paint_clipping_base_unsupported": "クリッピング先に使えないレイヤーがあります",
    "adjustment_clipping_base_unsupported": "クリッピング先に使えないレイヤーがあります",
    "paint_layer_limit_exceeded": "レイヤーが多すぎます",
    "fragment_sampler_budget_exceeded": "レイヤーやマスクが多すぎます",
}


def _document_refusal_text(ready) -> str:
    reason = str((ready or {}).get("reason", "") or "")
    if reason == "smart_paint_material_not_found":
        return "アクティブなマテリアルがありません。"
    if reason in {"source_psd_missing", "source_psd_stat_failed"}:
        return "開いたファイルが見つかりません"
    if reason.startswith("source_psd_"):
        return "開いたファイルを読み取れません"
    return "開いたファイルとレイヤーの対応が取れません"


class SPS_OT_lightweight_show_live_composite(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_show_live_composite"
    bl_label = "ライブ合成"
    bl_description = "3Dビューはレイヤー全体をGPU合成し、画像エディターとブラシは選択レイヤーを維持します"
    bl_options = set()

    force_rebuild: BoolProperty(default=False, options={"SKIP_SAVE"})

    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        material = _resolve_material(context)
        if material is None:
            ready = {"ok": False, "reason": "smart_paint_material_not_found"}
        elif _document_kind(material) == "LAYERED":
            ready = _ensure_layered_document_ready(
                material,
                context,
                reason="show_live_composite",
            )
        else:
            ready = {"ok": True, "reason": "flat_document_ready"}
        if not bool(ready.get("ok", False)):
            self.report({"ERROR"}, _ui_fmt("ライブ合成を使えません: {}", _ui_fmt(_document_refusal_text(ready))))
            return {"CANCELLED"}
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        try:
            from .mvp import live_composite

            result = dict(live_composite.build(material, context, force_cache=bool(self.force_rebuild)) or {})
        except Exception as exc:
            result = {"ok": False, "reason": "live_composite_exception", "error": repr(exc)[:300]}
        if not bool(result.get("ok", False)):
            try:
                live_composite.disable(material)
                live_composite.clear_material_cache(material, remove_unused_images=False)
                material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
            except Exception:
                pass
            _restore_active_layer_display(material, context)
            reason = str(result.get("reason", "") or "unsupported_stack")
            self.report(
                {"WARNING"},
                _ui_fmt("ライブ合成を使えません: {}", _ui_fmt(_LIVE_COMPOSITE_REFUSAL_TEXT.get(reason, "このレイヤー構成には対応していません"))),
            )
            return {"CANCELLED"}
        try:
            paint = getattr(getattr(context, "tool_settings", None), "image_paint", None)
            canvas = getattr(paint, "canvas", None) if paint is not None else None
            if canvas is not None:
                _show_image_in_editors(canvas, context)
        except Exception:
            pass
        try:
            from .mvp import image_editor_overlay

            if image_editor_overlay.requested(material):
                overlay_result = image_editor_overlay.set_enabled(material, True)
                if not bool(overlay_result.get("ok", False)):
                    self.report(
                        {"WARNING"},
                        _rpt_fail("画像の合成表示を無効化", overlay_result.get("reason", "") or "overlay_failed"),
                    )
            else:
                image_editor_overlay.sync_handler_state()
        except Exception:
            pass
        _ensure_material_display_shading(context)
        layer_count = int(result.get("chain_layer_count", 0) or 0)
        skipped_count = int(result.get("skipped_row_count", 0) or 0)
        elapsed = float(result.get("elapsed_ms", 0.0) or 0.0)
        if skipped_count > 0:
            self.report(
                {"WARNING"},
                _rpt("ライブ合成 {}描画層: 3Dは全描画レイヤー / 使用不可・構造行 {}件は透明 ({:.0f} ms)", layer_count, skipped_count, elapsed),
            )
        elif (
            int(result.get("opaque_source_pixels", 0) or 0) > 0
            and not bool(result.get("direct_full_stack", False))
        ):
            self.report(
                {"WARNING"},
                _rpt("ライブ合成 {}層 ({:.0f} ms)。不透明部の消去は保存済み表示を維持します", layer_count, elapsed),
            )
        else:
            self.report(
                {"INFO"},
                _rpt("ライブ合成 {}層: 3Dは全体 / 画像は選択レイヤー ({:.0f} ms)", layer_count, elapsed),
            )
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_toggle_image_composite(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_toggle_image_composite"
    bl_label = "画像も合成表示"
    bl_description = "画像エディターは全レイヤー合成を表示し、Blender標準ブラシは選択レイヤーだけへ描画します"
    bl_options = set()

    def execute(self, context):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        material = _resolve_material(context)
        if material is None:
            self.report({"ERROR"}, _rpt("アクティブなマテリアルがありません。"))
            return {"CANCELLED"}
        if not _live_composite_requested(material):
            self.report({"WARNING"}, _rpt("先に「ライブ合成」を有効にしてください。"))
            return {"CANCELLED"}
        try:
            from .mvp import image_editor_overlay

            turn_on = not image_editor_overlay.requested(material)
            result = dict(image_editor_overlay.set_enabled(material, turn_on) or {})
        except Exception as exc:
            result = {
                "ok": False,
                "reason": "image_editor_overlay_exception",
                "error": repr(exc)[:300],
            }
            turn_on = True
        if not bool(result.get("ok", False)):
            self.report(
                {"WARNING"},
                _rpt_fail("画像の合成表示を開始できません", result.get("reason", "") or "overlay_failed"),
            )
            return {"CANCELLED"}
        if turn_on:
            self.report(
                {"INFO"},
                _rpt("画像も全体合成表示（{}層）。描画先は選択レイヤーのままです", int(result.get('layer_count', 0) or 0)),
            )
        else:
            self.report({"INFO"}, _rpt("画像表示を選択レイヤーへ戻しました。"))
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_show_active(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_show_active"
    bl_label = "アクティブレイヤー表示へ戻る"
    bl_description = "3Dビューと画像エディターを選択レイヤーだけの表示へ戻します"
    bl_options = set()

    def execute(self, context):
        material = _resolve_material(context)
        try:
            from .mvp import live_composite

            live_composite.disable(material)
            material["sps_lightweight_display_mode"] = "ACTIVE_LAYER"
        except Exception:
            pass
        try:
            from .mvp import image_editor_overlay

            image_editor_overlay.sync_handler_state()
        except Exception:
            pass
        if material is None or not _restore_active_layer_display(material, context):
            self.report({"ERROR"}, _rpt("描画レイヤー表示へ戻せませんでした。"))
            return {"CANCELLED"}
        self.report({"INFO"}, _rpt("アクティブレイヤー表示へ戻しました。"))
        return {"FINISHED"}


class SPS_OT_lightweight_toggle_visibility(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_toggle_visibility"
    bl_label = "レイヤー表示切替"
    bl_description = "レイヤーの表示状態を切り替え、合成と保存へ反映します"
    bl_options = {"UNDO"}
    layer_index: IntProperty(default=-1)

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings, self.layer_index) if settings is not None else -1
        if index < 0:
            return {"CANCELLED"}
        layer = settings.layers[index]
        try:
            layer.enabled = not bool(getattr(layer, "enabled", True))
        except Exception:
            return {"CANCELLED"}
        _refresh_live_composite_if_enabled(material, context)
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_toggle_group(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_toggle_group"
    bl_label = "グループを展開/折りたたみ"
    bl_description = "レイヤーグループの表示だけを展開または折りたたみます"
    bl_options = set()

    layer_index: IntProperty(default=-1)

    def execute(self, context):
        settings = _settings(_resolve_material(context))
        index = _resolved_layer_index(settings, self.layer_index) if settings is not None else -1
        if index < 0:
            return {"CANCELLED"}
        layer = settings.layers[index]
        if not bool(getattr(layer, "is_group", False)):
            return {"CANCELLED"}
        try:
            layer.group_expanded = not bool(getattr(layer, "group_expanded", True))
        except Exception:
            return {"CANCELLED"}
        _tag_redraw(context)
        return {"FINISHED"}


def add_paint_layer(context, material) -> dict[str, object]:
    """Add one transparent paint layer above the active layer and make it the paint target."""
    settings = _settings(material)
    width, height = _document_size(material)
    if not len(settings.layers) and not _source_path(material):
        # The first layer of a document without a file: mark it as a sourceless
        # flat document so that saving and compositing do not look for a source.
        _set_document_identity(material, kind="FLAT", path="", width=int(width), height=int(height))
    active_index = _resolved_layer_index(settings)
    depth = max(0, int(getattr(settings.layers[active_index], "group_depth", 0) or 0)) if active_index >= 0 else 0
    name = _unique_layer_name(settings, "ペイント" if _ui_language_is_japanese(context) else "Paint")
    layer_id = uuid.uuid4().hex[:8]
    image = bpy.data.images.new(
        name=f"SPS_{getattr(material, 'name', 'Material')}_{name}_BASE_COLOR",
        width=int(width),
        height=int(height),
        alpha=True,
        float_buffer=False,
    )
    _configure_new_image(image, material, layer_id)
    layer = settings.layers.add()
    _initialize_paint_layer(layer, name=name, layer_id=layer_id, image_name=image.name, depth=depth)
    insert_index = min(len(settings.layers) - 1, active_index + 1) if active_index >= 0 else len(settings.layers) - 1
    if insert_index != len(settings.layers) - 1:
        settings.layers.move(len(settings.layers) - 1, insert_index)
    _set_active_indices(settings, int(insert_index))
    _mark_structure_dirty(material, reason="lightweight_add_layer", order=True)
    return dict(activate_layer(context, material, insert_index) or {})


class SPS_OT_lightweight_add_layer(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_add_layer"
    bl_label = "ペイントレイヤーを追加"
    bl_description = "アクティブレイヤーの上に透明なペイントレイヤーを追加します"
    bl_options = {"UNDO"}
    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        if material is None or settings is None:
            return {"CANCELLED"}
        try:
            result = add_paint_layer(context, material)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("レイヤー追加に失敗しました", exc))
            return {"CANCELLED"}
        if not bool(result.get("ok", False)):
            self.report({"ERROR"}, _rpt("追加レイヤーを描画対象へ接続できません。"))
            return {"CANCELLED"}
        return {"FINISHED"}


class SPS_OT_lightweight_add_adjustment(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_add_adjustment"
    bl_label = "\u8abf\u6574\u30ec\u30a4\u30e4\u30fc\u3092\u8ffd\u52a0"
    bl_description = (
        "Photoshop / Clip Studio Paint compatible native adjustment layer"
    )
    bl_options = {"UNDO"}
    adjustment_type: EnumProperty(
        name="\u7a2e\u985e",
        items=_ADJUSTMENT_ADD_ITEMS,
        default="BRIGHTNESS_CONTRAST",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        self.layout.prop(self, "adjustment_type", text="\u7a2e\u985e")

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        if material is None or settings is None:
            return {"CANCELLED"}
        active_index = _resolved_layer_index(settings)
        depth = (
            max(
                0,
                int(getattr(settings.layers[active_index], "group_depth", 0) or 0),
            )
            if active_index >= 0
            else 0
        )
        adjustment_type = str(self.adjustment_type or "BRIGHTNESS_CONTRAST").upper()
        base_name = _rpt(_mvp_adjustments.TYPE_LABELS_JA.get(adjustment_type, "\u8abf\u6574"))
        name = _unique_layer_name(settings, base_name)
        try:
            layer = settings.layers.add()
            _initialize_adjustment_layer(
                layer,
                name=name,
                layer_id=uuid.uuid4().hex[:8],
                adjustment_type=adjustment_type,
                depth=depth,
            )
            insert_index = (
                min(len(settings.layers) - 1, active_index + 1)
                if active_index >= 0
                else len(settings.layers) - 1
            )
            if insert_index != len(settings.layers) - 1:
                settings.layers.move(len(settings.layers) - 1, insert_index)
            _set_active_indices(settings, int(insert_index))
            _mark_structure_dirty(material, reason="lightweight_add_adjustment", order=True)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("調整レイヤーを追加できません", exc))
            return {"CANCELLED"}
        _refresh_live_composite_if_enabled(material, context)
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_delete_layer(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_delete_layer"
    bl_label = "レイヤーを削除"
    bl_description = "アクティブなレイヤー（ペイント・調整）をレイヤースタックから削除します"
    bl_options = {"UNDO"}
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        layer = settings.layers[index]
        if bool(getattr(layer, "is_group", False)):
            self.report({"WARNING"}, _rpt("グループ削除は軽量モードでは行いません。"))
            return {"CANCELLED"}
        paintable = [i for i, item in enumerate(settings.layers) if _layer_is_paintable(item)]
        if _layer_is_paintable(layer) and len(paintable) <= 1:
            self.report({"WARNING"}, _rpt("最後のペイントレイヤーは削除できません。"))
            return {"CANCELLED"}
        layer_id = _layer_id(layer, index)
        try:
            settings.layers.remove(index)
            material_name = str(getattr(material, "name", "") or "")
            (_ACTIVATED_LAYERS.get(material_name, {}) or {}).pop(layer_id, None)
            _ACTIVATED_LAYERS.reaccount(material_name)
            thumbnail_module = _thumbnail_module(import_if_missing=False)
            if thumbnail_module is not None:
                thumbnail_module.clear_material(material)
            _mark_structure_dirty(material, reason="lightweight_delete_layer", order=True)
            target = min(index, len(settings.layers) - 1)
            candidates = sorted(
                (i for i, item in enumerate(settings.layers) if _layer_is_paintable(item)),
                key=lambda i: abs(i - target),
            )
            if candidates:
                _set_active_indices(settings, int(candidates[0]))
                activate_layer(context, material, int(candidates[0]))
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("削除に失敗しました", exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SPS_OT_lightweight_move_layer(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_move_layer"
    bl_label = "レイヤーを移動"
    bl_description = "アクティブレイヤーまたはグループを一段上下へ移動します"
    bl_options = {"UNDO"}
    direction: EnumProperty(items=(("UP", "上", "上へ移動"), ("DOWN", "下", "下へ移動")), default="UP")

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        active_id = _layer_id(settings.layers[index], index)
        if not _move_layer_block(settings, index, self.direction):
            self.report({"INFO"}, _rpt("これ以上移動できません。"))
            return {"CANCELLED"}
        for new_index, layer in enumerate(settings.layers):
            if _layer_id(layer, new_index) == active_id:
                _set_active_indices(settings, int(new_index))
                break
        _mark_structure_dirty(material, reason="lightweight_move_layer", order=True)
        _refresh_live_composite_if_enabled(material, context)
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_drag_layer(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_drag_layer"
    bl_label = "Drag Layer"
    bl_description = "Hold and drag to reorder this layer or folder within its current group"
    bl_options = {"UNDO", "INTERNAL"}
    layer_index: IntProperty(default=-1)

    def _finish_cursor(self, context) -> None:
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass

    def _restore_original_order(self, settings) -> None:
        try:
            layers = settings.layers
            for target_index, wanted_id in enumerate(self._original_order):
                current_index = next(
                    (
                        index
                        for index, candidate in enumerate(layers)
                        if _layer_id(candidate, index) == wanted_id
                    ),
                    -1,
                )
                if current_index >= 0 and current_index != target_index:
                    layers.move(current_index, target_index)
        except Exception:
            pass

    def invoke(self, context, event):
        if not _manager_rule_api.workspace_runtime_allowed(context):
            return {"CANCELLED"}
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings, self.layer_index) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        self._material_name = str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")
        self._drag_layer_id = _layer_id(settings.layers[index], index)
        self._last_mouse_y = int(getattr(event, "mouse_y", 0) or 0)
        self._changed = False
        self._original_order = [
            _layer_id(layer, layer_index)
            for layer_index, layer in enumerate(settings.layers)
        ]
        _set_active_indices(settings, index)
        try:
            context.window.cursor_modal_set("SCROLL_Y")
        except Exception:
            pass
        context.window_manager.modal_handler_add(self)
        _tag_redraw(context)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        material = bpy.data.materials.get(str(getattr(self, "_material_name", "") or ""))
        settings = _settings(material)
        if material is None or settings is None:
            self._finish_cursor(context)
            return {"CANCELLED"}
        if not _manager_rule_api.workspace_runtime_allowed(context):
            self._restore_original_order(settings)
            self._finish_cursor(context)
            _tag_redraw(context)
            return {"CANCELLED"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._restore_original_order(settings)
            self._finish_cursor(context)
            _tag_redraw(context)
            return {"CANCELLED"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            self._finish_cursor(context)
            if bool(getattr(self, "_changed", False)):
                _mark_structure_dirty(material, reason="lightweight_drag_layer", order=True)
                _refresh_live_composite_if_enabled(material, context)
            _tag_redraw(context)
            return {"FINISHED"}
        if event.type != "MOUSEMOVE":
            return {"RUNNING_MODAL"}

        mouse_y = int(getattr(event, "mouse_y", self._last_mouse_y) or self._last_mouse_y)
        delta = mouse_y - int(self._last_mouse_y)
        while abs(delta) >= 18:
            direction = "UP" if delta > 0 else "DOWN"
            current_index = next(
                (
                    index
                    for index, candidate in enumerate(settings.layers)
                    if _layer_id(candidate, index) == str(self._drag_layer_id)
                ),
                -1,
            )
            if current_index < 0 or not _move_layer_block(settings, current_index, direction):
                self._last_mouse_y = mouse_y
                break
            self._changed = True
            self._last_mouse_y += 18 if delta > 0 else -18
            delta = mouse_y - int(self._last_mouse_y)
            _tag_redraw(context)
        return {"RUNNING_MODAL"}


class SPS_OT_lightweight_group_active(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_group_active"
    bl_label = "グループ化"
    bl_description = "アクティブレイヤーを新しいレイヤーグループへ入れます"
    bl_options = {"UNDO"}
    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        active = settings.layers[index]
        if bool(getattr(active, "is_group", False)):
            self.report({"WARNING"}, _rpt("グループ内へ入れるピクセルレイヤーを選択してください。"))
            return {"CANCELLED"}
        try:
            base_depth = max(0, int(getattr(active, "group_depth", 0) or 0))
            active.group_depth = base_depth + 1
            group = settings.layers.add()
            group.name = _unique_layer_name(settings, "グループ" if _ui_language_is_japanese(context) else "Group")
            group.layer_id = uuid.uuid4().hex[:8]
            group.psd_source_record_index = -1
            group.is_group = True
            group.group_depth = base_depth
            group.group_expanded = True
            group.enabled = True
            group.opacity = 1.0
            group.blend_mode = "PASS_THROUGH"
            # A folder row precedes its contiguous children in the engine
            # collection. Insert the folder at the active row and let the
            # selected pixel layer shift to index + 1 as its first child.
            insert_index = int(index)
            settings.layers.move(len(settings.layers) - 1, insert_index)
            _set_active_indices(settings, int(insert_index + 1))
            _mark_structure_dirty(material, reason="lightweight_group_active", order=True)
        except Exception as exc:
            self.report({"ERROR"}, _rpt_fail("グループ化に失敗しました", exc))
            return {"CANCELLED"}
        _refresh_live_composite_if_enabled(material, context)
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_activate_mask(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_activate_mask"
    bl_label = "レイヤーマスクを編集"
    bl_description = "選択レイヤーまたはグループのマスクを作成／展開し、Blender標準ブラシの描画先にします"
    bl_options = set()

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        layer = settings.layers[index]
        is_group = bool(getattr(layer, "is_group", False)) or str(
            getattr(layer, "layer_kind", "") or ""
        ).upper() == "GROUP"
        if not is_group and not _layer_is_paintable(layer):
            self.report({"WARNING"}, _rpt("マスクを編集できるのはペイントレイヤーとグループだけです。"))
            return {"CANCELLED"}
        candidates = sorted(
            (i for i, item in enumerate(settings.layers) if _layer_is_paintable(item)),
            key=lambda value: abs(int(value) - int(index)),
        )
        if _layer_is_paintable(layer):
            return_index = int(index)
        elif candidates:
            return_index = int(candidates[0])
        else:
            self.report({"ERROR"}, _rpt("戻り先となるペイントレイヤーがありません。"))
            return {"CANCELLED"}
        try:
            material["sps_lightweight_mask_return_layer_index"] = int(return_index)
        except Exception:
            pass
        try:
            from .mvp import live_composite, paint_target

            result = dict(
                paint_target.activate_mask(
                    material,
                    int(index),
                    context,
                    switch_to_paint=True,
                )
                or {}
            )
        except Exception as exc:
            result = {"ok": False, "reason": "mask_target_exception", "error": repr(exc)[:300]}
        if not bool(result.get("ok", False)):
            self.report({"ERROR"}, _rpt_fail("マスク描画先を開けません", result.get("reason", "")))
            return {"CANCELLED"}
        try:
            mask_image = bpy.data.images.get(str(result.get("image", "") or ""))
            live_composite.invalidate_image_u8_payload(mask_image)
        except Exception:
            pass
        _mark_structure_dirty(material, reason="lightweight_mask_target", mask=True)
        try:
            # Keep decoded layer/display assets and rebuild only mask metadata.
            # Clearing the cache here made a new 4K recordless mask re-decode the
            # complete PSD and pushed this single UI operation past 10 seconds.
            live_result = dict(
                live_composite.build(
                    material,
                    context,
                    force_cache=False,
                    refresh_metadata=True,
                )
                or {}
            )
        except Exception as exc:
            live_result = {"ok": False, "reason": "mask_live_exception", "error": repr(exc)[:300]}
        if not bool(live_result.get("ok", False)):
            try:
                activate_layer(context, material, return_index)
            except Exception:
                pass
            self.report({"ERROR"}, _rpt_fail("マスクのライブ合成を開始できません", live_result.get("reason", "")))
            return {"CANCELLED"}
        image = bpy.data.images.get(str(result.get("image", "") or ""))
        if image is not None:
            _show_image_in_editors(image, context)
        _ensure_material_display_shading(context)
        _tag_redraw(context)
        elapsed = float(result.get("elapsed_ms", 0.0) or 0.0) + float(live_result.get("elapsed_ms", 0.0) or 0.0)
        self.report({"INFO"}, _rpt("マスク描画: {} ({:.0f} ms)", result.get('layer_name', ''), elapsed))
        return {"FINISHED"}


class SPS_OT_lightweight_activate_pixels(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_activate_pixels"
    bl_label = "レイヤー描画へ戻る"
    bl_description = "マスク描画を終了し、直前のペイントレイヤーをBlender標準ブラシの描画先へ戻します"
    bl_options = set()

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        if material is None or settings is None or not len(settings.layers):
            return {"CANCELLED"}
        try:
            index = int(material.get("sps_lightweight_mask_return_layer_index", -1))
        except Exception:
            index = -1
        if not (0 <= index < len(settings.layers)) or not _layer_is_paintable(settings.layers[index]):
            current = _resolved_layer_index(settings)
            candidates = sorted(
                (i for i, item in enumerate(settings.layers) if _layer_is_paintable(item)),
                key=lambda value: abs(int(value) - int(current)),
            )
            index = int(candidates[0]) if candidates else -1
        if index < 0:
            self.report({"ERROR"}, _rpt("ペイントレイヤーがありません。"))
            return {"CANCELLED"}
        result = activate_layer(context, material, int(index))
        if not bool(result.get("ok", False)):
            self.report({"ERROR"}, _rpt_fail("レイヤー描画へ戻せません", result.get("reason", "")))
            return {"CANCELLED"}
        image = bpy.data.images.get(str(result.get("image", "") or ""))
        if image is not None:
            _show_image_in_editors(image, context)
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_toggle_thumbnails(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_toggle_thumbnails"
    bl_label = "レイヤーサムネイル"
    bl_description = "レイヤーサムネイルを切り替えます。生成は明示操作時だけで、常駐更新は行いません"
    bl_options = set()

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        if material is None or settings is None:
            return {"CANCELLED"}
        enabled = not _thumbnails_enabled(material)
        try:
            material["sps_lightweight_thumbnails_enabled"] = bool(enabled)
        except Exception:
            return {"CANCELLED"}
        if enabled:
            index = _resolved_layer_index(settings)
            result = {"ok": False, "reason": "active_layer_missing"}
            if index >= 0:
                result = _ensure_layer_thumbnail(material, settings.layers[index], index, force=False)
            if not bool(result.get("ok", False)):
                self.report({"INFO"}, _rpt("サムネイルON。未実体化レイヤーは選択後に生成されます。"))
        else:
            module = _thumbnail_module(import_if_missing=False)
            if module is not None:
                try:
                    module.clear_material(material)
                except Exception:
                    pass
        _trace_lightweight(
            "lightweight_thumbnails_toggled",
            material=material,
            enabled=bool(enabled),
        )
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_OT_lightweight_refresh_thumbnail(bpy.types.Operator):
    bl_idname = "smart_paint_suite.lightweight_refresh_thumbnail"
    bl_label = "アクティブサムネイルを更新"
    bl_description = "現在の描画レイヤーだけのサムネイルを明示更新します"
    bl_options = set()

    def execute(self, context):
        material = _resolve_material(context)
        settings = _settings(material)
        index = _resolved_layer_index(settings) if settings is not None else -1
        if material is None or settings is None or index < 0:
            return {"CANCELLED"}
        try:
            material["sps_lightweight_thumbnails_enabled"] = True
        except Exception:
            pass
        result = _ensure_layer_thumbnail(material, settings.layers[index], index, force=True)
        _trace_lightweight(
            "lightweight_thumbnail_refreshed",
            material=material,
            layer_id=_layer_id(settings.layers[index], index),
            record_index=_source_record_index(settings.layers[index]),
            ok=bool(result.get("ok", False)),
            reason=str(result.get("reason", "") or ""),
            icon_id=int(result.get("icon_id", 0) or 0),
        )
        if not bool(result.get("ok", False)):
            self.report({"WARNING"}, _rpt_fail("サムネイルを生成できません", result.get("reason", "")))
            return {"CANCELLED"}
        _tag_redraw(context)
        return {"FINISHED"}


class SPS_UL_lightweight_layers(bpy.types.UIList):
    """Compact PSD tree. Drawing is cache-only and never touches pixels."""

    bl_idname = "SPS_UL_lightweight_layers"

    def filter_items(self, context, data, propname):
        try:
            count = len(getattr(data, propname))
        except Exception:
            return [], []
        visible = [int(index) for index in _display_layer_indices(data)]
        if not visible:
            return [], []
        visible_set = set(visible)
        bit = int(self.bitflag_filter_item)
        flags = [bit if index in visible_set else 0 for index in range(count)]
        full_order = visible + [index for index in range(count) if index not in visible_set]
        new_order = [0] * count
        for new_index, old_index in enumerate(full_order):
            new_order[int(old_index)] = int(new_index)
        return flags, new_order

    def draw_item(
        self, context, layout, data, item, icon, active_data,
        active_propname, index, flt_flag,
    ):
        material = _resolve_material(context)
        settings = data
        layer = item
        row = layout.row(align=True)
        if self.layout_type == "GRID":
            row.alignment = "CENTER"
            row.label(text="", icon="IMAGE_DATA")
            return

        eye = row.operator(
            SPS_OT_lightweight_toggle_visibility.bl_idname,
            text="",
            icon="HIDE_OFF" if bool(getattr(layer, "enabled", True)) else "HIDE_ON",
            emboss=False,
        )
        eye.layer_index = int(index)
        depth = max(0, int(getattr(layer, "group_depth", 0) or 0))
        for _ in range(min(depth, 8)):
            row.label(text="", icon="BLANK1")
        is_group = bool(getattr(layer, "is_group", False)) or str(
            getattr(layer, "layer_kind", "") or ""
        ).upper() == "GROUP"
        if is_group:
            fold = row.operator(
                SPS_OT_lightweight_toggle_group.bl_idname,
                text="",
                icon="DOWNARROW_HLT" if bool(getattr(layer, "group_expanded", True)) else "RIGHTARROW",
                emboss=False,
            )
            fold.layer_index = int(index)
        else:
            row.label(text="", icon="BLANK1")

        thumbnail_icon = 0
        if material is not None and _thumbnails_enabled(material):
            module = _thumbnail_module(import_if_missing=False)
            image = _materialized_layer_image(material, layer, int(index))
            if module is not None and image is not None:
                try:
                    thumbnail_icon = int(module.cached_icon_id(
                        material,
                        _layer_id(layer, int(index)),
                        _source_record_index(layer),
                        image,
                    ) or 0)
                except Exception:
                    thumbnail_icon = 0
        if thumbnail_icon > 0:
            row.label(text="", icon_value=thumbnail_icon)
        else:
            is_adjustment = str(
                getattr(layer, "layer_kind", "") or ""
            ).upper() == "ADJUSTMENT"
            fallback_icon = (
                "FILE_FOLDER"
                if is_group
                else "COLOR" if is_adjustment else "IMAGE_DATA" if _layer_is_paintable(layer) else "MODIFIER"
            )
            row.label(text="", icon=fallback_icon)

        active_index = int(getattr(settings, "active_layer_index", 0) or 0)
        is_active = int(index) == active_index
        row.label(text="", icon="RADIOBUT_ON" if is_active else "BLANK1")
        row.label(text=_layer_display_name(layer, index), translate=False)
        if bool(getattr(layer, "clip_to_below", False)):
            row.label(text="", icon="LINKED")
        if str(getattr(layer, "mask_mode", "NONE") or "NONE").upper() != "NONE" or str(
            getattr(layer, "mask_image", "") or ""
        ):
            row.label(text="", icon="MOD_MASK")
        if not _layer_is_paintable(layer) and not is_group:
            row.label(text="", icon="LOCKED")
        blend = str(getattr(layer, "blend_mode", "MIX") or "MIX").upper()
        if not is_group and blend not in {"MIX", "NORMAL"}:
            row.label(text=blend.replace("_", " ").title())
        drag = row.operator(
            SPS_OT_lightweight_drag_layer.bl_idname,
            text="",
            icon="GRIP",
            emboss=False,
        )
        drag.layer_index = int(index)


def _draw_adjustment_settings(layout, layer) -> None:
    typ = str(getattr(layer, "adjustment_type", "NONE") or "NONE").upper()
    layout.prop(layer, "adjustment_type", text="\u8abf\u6574")
    controls = layout.column(align=True)
    if typ == "BRIGHTNESS_CONTRAST":
        controls.prop(layer, "adj_brightness", text="\u660e\u308b\u3055", slider=True)
        controls.prop(layer, "adj_contrast", text="\u30b3\u30f3\u30c8\u30e9\u30b9\u30c8", slider=True)
    elif typ == "LEVELS":
        row = controls.row(align=True)
        row.prop(layer, "adj_levels_input_black", text="\u5165\u529b\u9ed2")
        row.prop(layer, "adj_levels_input_white", text="\u5165\u529b\u767d")
        controls.prop(layer, "adj_levels_gamma", text="\u4e2d\u9593\u8abf")
        row = controls.row(align=True)
        row.prop(layer, "adj_levels_output_black", text="\u51fa\u529b\u9ed2")
        row.prop(layer, "adj_levels_output_white", text="\u51fa\u529b\u767d")
    elif typ == "HUE_SATURATION":
        controls.prop(layer, "adj_hue", text="\u8272\u76f8", slider=True)
        controls.prop(layer, "adj_saturation", text="\u5f69\u5ea6", slider=True)
        controls.prop(layer, "adj_lightness", text="\u660e\u5ea6", slider=True)
    elif typ == "COLOR_BALANCE":
        labels = (
            ("adj_color_balance_shadows", "\u30b7\u30e3\u30c9\u30a6"),
            ("adj_color_balance_midtones", "\u4e2d\u9593\u8abf"),
            ("adj_color_balance_highlights", "\u30cf\u30a4\u30e9\u30a4\u30c8"),
        )
        for prop_name, label in labels:
            box = controls.box()
            box.label(text=label)
            row = box.row(align=True)
            row.prop(layer, prop_name, index=0, text="C/R")
            row.prop(layer, prop_name, index=1, text="M/G")
            row.prop(layer, prop_name, index=2, text="Y/B")
        controls.prop(
            layer,
            "adj_preserve_luminosity",
            text="\u8f1d\u5ea6\u3092\u4fdd\u6301",
        )
    elif typ == "POSTERIZE":
        controls.prop(layer, "adj_posterize_levels", text="\u968e\u8abf\u6570")
    elif typ == "THRESHOLD":
        controls.prop(layer, "adj_threshold", text="\u3057\u304d\u3044\u5024", slider=True)
    elif typ == "GRADIENT_MAP":
        controls.prop(layer, "adj_gradient_dark", text="\u6697\u90e8")
        controls.prop(layer, "adj_gradient_light", text="\u660e\u90e8")
    elif typ == "INVERT":
        controls.label(
            text="\u4e0b\u306e\u5408\u6210\u7d50\u679c\u306eRGB\u3092\u53cd\u8ee2",
            icon="CHECKMARK",
        )
    else:
        warning = controls.row()
        warning.alert = True
        warning.label(
            text="Photoshop/CSP\u306e\u30cd\u30a4\u30c6\u30a3\u30d6\u8a18\u9332\u3092\u4fdd\u6301",
            icon="LOCKED",
        )


def _draw_panel(layout, context) -> None:
    material = _resolve_material(context)
    if material is None:
        layout.label(text="メッシュのマテリアルを選択")
        return
    row = layout.row(align=True)
    row.operator(SPS_OT_lightweight_open_image.bl_idname, text="開く", icon="FILE_FOLDER")
    row.operator(SPS_OT_lightweight_save_image.bl_idname, text="保存", icon="FILE_TICK")
    row.operator(SPS_OT_lightweight_save_image_as.bl_idname, text="", icon="DUPLICATE")
    path = _source_path(material)
    if path:
        layout.label(translate=False, text=Path(path).name, icon="FILE")
    settings = _settings(material)
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    if not layers:
        layout.label(text="画像を開くとレイヤーが表示されます", icon="IMAGE_DATA")
        return
    active_index = _resolved_layer_index(settings)
    active_name = ""
    if active_index >= 0:
        active_name = str(getattr(layers[active_index], "name", "") or f"Layer {active_index + 1}")
    try:
        display_mode = str(material.get("sps_lightweight_display_mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
    except Exception:
        display_mode = "ACTIVE_LAYER"
    overlay_requested = False
    overlay_error = ""
    image_editor_overlay = _DRAW_IMAGE_EDITOR_OVERLAY
    overlay_query = getattr(image_editor_overlay, "requested", None)
    if callable(overlay_query):
        try:
            overlay_requested = bool(overlay_query(material))
            overlay_error = str(material.get(str(getattr(image_editor_overlay, "ERROR_PROPERTY", "")), "") or "")
        except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError):
            pass

    display = layout.row(align=True)
    display.operator(
        SPS_OT_lightweight_show_active.bl_idname,
        text="個別",
        icon="BRUSH_DATA",
        depress=(display_mode == "ACTIVE_LAYER"),
    )
    live = display.operator(
        SPS_OT_lightweight_show_live_composite.bl_idname,
        text="ライブ合成",
        icon="NODE_MATERIAL",
        depress=(display_mode == "LIVE_COMPOSITE"),
    )
    live.force_rebuild = False
    preview = display.operator(
        SPS_OT_lightweight_show_composite.bl_idname,
        text="全体確認",
        icon="IMAGE_DATA",
        depress=(display_mode == "COMPOSITE_PREVIEW"),
    )
    preview.force_refresh = False
    if display_mode == "COMPOSITE_PREVIEW":
        refresh = display.operator(SPS_OT_lightweight_show_composite.bl_idname, text="", icon="FILE_REFRESH")
        refresh.force_refresh = True
    if display_mode == "LIVE_COMPOSITE":
        image_display = layout.row(align=True)
        image_display.operator(
            SPS_OT_lightweight_toggle_image_composite.bl_idname,
            text="画像も合成表示",
            icon="IMAGE_DATA",
            depress=bool(overlay_requested),
        )
        image_display.label(translate=False, text=_ui_fmt("描画先: {}", active_name), icon="BRUSH_DATA")

    info = layout.row(align=True)
    try:
        active_target = str(material.get("sps_lightweight_active_target", "PIXELS") or "PIXELS").upper()
        mask_owner_id = str(material.get("sps_lightweight_mask_owner_layer_id", "") or "")
    except Exception:
        active_target = "PIXELS"
        mask_owner_id = ""
    if active_target == "MASK":
        info.label(text=_ui_fmt("マスク描画中: {} / 3Dはライブ合成", active_name), icon="MOD_MASK")
    elif display_mode == "COMPOSITE_PREVIEW":
        info.label(text="現在の一時合成を確認中", icon="HIDE_OFF")
    elif display_mode == "LIVE_COMPOSITE":
        try:
            chain_count = len(json.loads(str(material.get("sps_mvp_live_composite_chain", "[]") or "[]")))
        except Exception:
            chain_count = 0
        try:
            mask_count = int(material.get("sps_mvp_live_composite_mask_count", 0) or 0)
        except Exception:
            mask_count = 0
        mask_text = _rpt(" / マスク {}", mask_count) if mask_count > 0 else ""
        if overlay_requested:
            info.label(
                text=_ui_fmt("3D・画像: 全体GPU {}層{} / 描画: {}", chain_count, mask_text, active_name),
                icon="NODE_MATERIAL",
            )
        else:
            info.label(text=_ui_fmt("3D: 全体GPU {}層{} / 画像: {}", chain_count, mask_text, active_name), icon="NODE_MATERIAL")
    else:
        info.label(text=_ui_fmt("描画中: {}", active_name), icon="RADIOBUT_ON")
    try:
        last_ms = float(material.get("sps_lightweight_last_save_ms", 0.0) or 0.0)
    except Exception:
        last_ms = 0.0
    if last_ms > 0.0:
        info.label(text=_ui_fmt("前回 {:.1f}s", last_ms / 1000.0))
    if display_mode == "COMPOSITE_PREVIEW":
        notice = layout.column(align=True)
        notice.alert = True
        notice.label(text="全体確認は閲覧専用です", icon="ERROR")
        notice.label(text="描画は「個別」か「ライブ合成」で", icon="BLANK1")
    elif display_mode == "LIVE_COMPOSITE":
        try:
            warning = str(material.get("sps_mvp_live_composite_warning", "") or "")
        except Exception:
            warning = ""
        if warning:
            notice = layout.row()
            notice.alert = True
            notice.label(text="不透明部の消去は全体確認で確定", icon="ERROR")
        if overlay_requested and overlay_error:
            notice = layout.row()
            notice.alert = True
            notice.label(text=_rpt_fail("画像合成表示エラー", overlay_error), icon="ERROR")

    tools = layout.row(align=True)
    tools.operator(SPS_OT_lightweight_add_layer.bl_idname, text="", icon="ADD")
    tools.operator(SPS_OT_lightweight_add_adjustment.bl_idname, text="", icon="COLOR")
    tools.operator(SPS_OT_lightweight_group_active.bl_idname, text="", icon="FILE_FOLDER")
    mask_tool = tools.row(align=True)
    mask_tool.enabled = bool(
        active_index >= 0
        and (
            _layer_is_paintable(layers[active_index])
            or bool(getattr(layers[active_index], "is_group", False))
        )
    )
    if active_target == "MASK":
        mask_tool.operator(SPS_OT_lightweight_activate_pixels.bl_idname, text="", icon="BRUSH_DATA")
    else:
        mask_tool.operator(SPS_OT_lightweight_activate_mask.bl_idname, text="", icon="MOD_MASK")
    tools.separator()
    move_up = tools.operator(SPS_OT_lightweight_move_layer.bl_idname, text="", icon="TRIA_UP")
    move_up.direction = "UP"
    move_down = tools.operator(SPS_OT_lightweight_move_layer.bl_idname, text="", icon="TRIA_DOWN")
    move_down.direction = "DOWN"
    tools.operator(SPS_OT_lightweight_delete_layer.bl_idname, text="", icon="REMOVE")
    tools.separator()
    thumbnails_on = _thumbnails_enabled(material)
    tools.operator(
        SPS_OT_lightweight_toggle_thumbnails.bl_idname,
        text="",
        icon="IMAGE_DATA",
        depress=bool(thumbnails_on),
    )
    refresh_thumbnail = tools.row(align=True)
    refresh_thumbnail.enabled = bool(thumbnails_on)
    refresh_thumbnail.operator(SPS_OT_lightweight_refresh_thumbnail.bl_idname, text="", icon="FILE_REFRESH")

    visible_count = len(_display_layer_indices(settings))
    layout.template_list(
        SPS_UL_lightweight_layers.bl_idname,
        "main",
        settings,
        "layers",
        settings,
        "lightweight_ui_layer_index",
        rows=max(4, min(12, visible_count)),
    )

    try:
        from .mvp import selection_tools

        selection_tools.draw_toolbar(layout, context, material)
    except Exception:
        pass
    try:
        from .mvp import editing_tools

        editing_tools.draw_toolbar(layout, context, material)
    except Exception:
        pass

    active_index = _resolved_layer_index(settings)
    if active_index >= 0:
        active = settings.layers[active_index]
        layout.separator()
        detail = layout.column(align=True)
        header = detail.row(align=True)
        header.label(text="レイヤー設定", icon="OPTIONS")
        header.prop(active, "enabled", text="", icon="HIDE_OFF" if bool(getattr(active, "enabled", True)) else "HIDE_ON")
        detail.prop(active, "name", text="名前")
        detail.prop(active, "opacity", text="不透明度", slider=True)
        is_adjustment = bool(
            str(getattr(active, "layer_kind", "") or "").upper() == "ADJUSTMENT"
            or str(getattr(active, "adjustment_type", "NONE") or "NONE").upper()
            != "NONE"
        )
        active_layer_id = _layer_id(active, active_index)
        mask_mode = str(getattr(active, "mask_mode", "NONE") or "NONE").upper()
        has_mask = bool(mask_mode != "NONE" or str(getattr(active, "mask_image", "") or ""))
        can_mask = bool(
            _layer_is_paintable(active)
            or getattr(active, "is_group", False)
            or is_adjustment
        )
        if can_mask:
            mask_row = detail.row(align=True)
            if active_target == "MASK" and mask_owner_id == active_layer_id:
                mask_row.operator(SPS_OT_lightweight_activate_pixels.bl_idname, text="ピクセルへ戻る", icon="BRUSH_DATA")
            else:
                mask_row.operator(
                    SPS_OT_lightweight_activate_mask.bl_idname,
                    text="マスクを編集" if has_mask else "マスクを追加",
                    icon="MOD_MASK",
                )
        if is_adjustment:
            _draw_adjustment_settings(detail, active)
        if not bool(getattr(active, "is_group", False)):
            detail.prop(active, "blend_mode", text="合成")
            detail.prop(active, "clip_to_below", text="下のレイヤーでクリッピング")
            if has_mask:
                detail.label(text=_ui_fmt("マスク: {}", _mask_mode_text(mask_mode)), icon="MOD_MASK")
        else:
            detail.prop(active, "blend_mode", text="Group Blend")
            if has_mask:
                detail.label(text=_ui_fmt("グループマスク: {}", _mask_mode_text(mask_mode)), icon="MOD_MASK")


def _mask_mode_text(mask_mode: str) -> str:
    """Display name of a mask mode, not its identifier."""
    from .constants import MASK_MODE_ITEMS

    names = {item[0]: item[1] for item in MASK_MODE_ITEMS}
    return _rpt(names.get(str(mask_mode), "Image"))


def _layer_display_name(layer, index) -> str:
    """Layer name for the list, with the unavailable mark in the active language."""
    name = str(getattr(layer, "name", "") or "")
    if not name:
        return _rpt("レイヤー {}", int(index) + 1)
    if "\u4f7f\u7528\u4e0d\u53ef" not in name:
        return name
    # '<JA> / <EN>' labels written into the name when an unsupported PSD row was read.
    japanese = _ui_language_is_japanese(bpy.context)
    name = re.sub(r"([^:\s/（(]+) / ([A-Za-z][A-Za-z ]*)", (lambda m: m.group(1)) if japanese else (lambda m: m.group(2)), name)
    return name.replace("\u4f7f\u7528\u4e0d\u53ef", _rpt("使用不可"))


def _ui_fmt(template: str, *values) -> str:
    return bpy.app.translations.pgettext_iface(template).format(*values)


def _compact_panel_state(context):
    material = _resolve_material(context)
    settings = _settings(material) if material is not None else None
    layers = getattr(settings, "layers", ()) if settings is not None else ()
    active_index = _resolved_layer_index(settings) if layers else -1
    return material, settings, layers, active_index


def _draw_workspace_header(layout, context) -> None:
    paint_workspace = _DRAW_PAINT_WORKSPACE
    draw_controls = getattr(paint_workspace, "draw_controls", None)
    if callable(draw_controls):
        try:
            draw_controls(layout, context)
            layout.separator()
        except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError):
            pass
    material, settings, layers, active_index = _compact_panel_state(context)
    if material is None:
        layout.label(text="メッシュのマテリアルを選択")
        return

    path = _source_path_for_draw(material)
    document = layout.row(align=True)
    document.operator(SPS_OT_lightweight_open_image.bl_idname, text="", icon="FILE_FOLDER")
    save = document.row(align=True)
    save.enabled = bool(path)
    save.operator(SPS_OT_lightweight_save_image.bl_idname, text="", icon="FILE_TICK")
    save_as = document.row(align=True)
    save_as.enabled = bool(path or layers)
    save_as.operator(SPS_OT_lightweight_save_image_as.bl_idname, text="", icon="DUPLICATE")
    document.label(translate=False, text=Path(path).name if path else _rpt("画像"), icon="FILE")

    if not layers:
        layout.label(text="画像を開く", icon="IMAGE_DATA")
        return

    active = layers[active_index] if active_index >= 0 else None
    active_name = str(getattr(active, "name", "") or _rpt("レイヤー"))
    try:
        display_mode = str(material.get("sps_lightweight_display_mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
    except Exception:
        display_mode = "ACTIVE_LAYER"
    try:
        active_target = str(material.get("sps_lightweight_active_target", "PIXELS") or "PIXELS").upper()
    except Exception:
        active_target = "PIXELS"
    overlay_requested = False
    overlay_error = ""
    image_editor_overlay = _DRAW_IMAGE_EDITOR_OVERLAY
    overlay_query = getattr(image_editor_overlay, "requested", None)
    if callable(overlay_query):
        try:
            overlay_requested = bool(overlay_query(material))
            overlay_error = str(material.get(str(getattr(image_editor_overlay, "ERROR_PROPERTY", "")), "") or "")
        except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError):
            pass

    display = layout.row(align=True)
    display.operator(
        SPS_OT_lightweight_show_active.bl_idname,
        text="個別",
        icon="BRUSH_DATA",
        depress=(display_mode == "ACTIVE_LAYER"),
    )
    live = display.operator(
        SPS_OT_lightweight_show_live_composite.bl_idname,
        text="ライブ",
        icon="NODE_MATERIAL",
        depress=(display_mode == "LIVE_COMPOSITE"),
    )
    live.force_rebuild = False
    preview = display.operator(
        SPS_OT_lightweight_show_composite.bl_idname,
        text="確認",
        icon="IMAGE_DATA",
        depress=(display_mode == "COMPOSITE_PREVIEW"),
    )
    preview.force_refresh = False
    if display_mode == "COMPOSITE_PREVIEW":
        refresh = display.operator(
            SPS_OT_lightweight_show_composite.bl_idname,
            text="",
            icon="FILE_REFRESH",
        )
        refresh.force_refresh = True

    if display_mode == "LIVE_COMPOSITE":
        image_display = layout.row(align=True)
        image_display.operator(
            SPS_OT_lightweight_toggle_image_composite.bl_idname,
            text="画像合成",
            icon="IMAGE_DATA",
            depress=bool(overlay_requested),
        )
        image_display.label(translate=False, text=active_name, icon="BRUSH_DATA")

    status = layout.row(align=True)
    if active_target == "MASK":
        status.label(translate=False, text=_ui_fmt("マスク: {}", active_name), icon="MOD_MASK")
    elif display_mode == "COMPOSITE_PREVIEW":
        status.alert = True
        status.label(text="全体確認（閲覧専用）", icon="HIDE_OFF")
    elif display_mode == "LIVE_COMPOSITE":
        try:
            chain_count = len(json.loads(str(material.get("sps_mvp_live_composite_chain", "[]") or "[]")))
        except Exception:
            chain_count = 0
        status.label(text=_ui_fmt("GPU {}層 / {}", chain_count, active_name), icon="NODE_MATERIAL")
    else:
        status.label(translate=False, text=active_name, icon="RADIOBUT_ON")
    try:
        last_ms = float(material.get("sps_lightweight_last_save_ms", 0.0) or 0.0)
    except Exception:
        last_ms = 0.0
    if last_ms > 0.0:
        status.label(text=f"{last_ms / 1000.0:.1f}s")

    if display_mode == "LIVE_COMPOSITE":
        try:
            warning = str(material.get("sps_mvp_live_composite_warning", "") or "")
        except Exception:
            warning = ""
        if warning:
            notice = layout.row()
            notice.alert = True
            notice.label(text="消去結果は確認モードで確定", icon="ERROR")
        if overlay_requested and overlay_error:
            notice = layout.row()
            notice.alert = True
            notice.label(text=_rpt_msg(overlay_error)[:80], icon="ERROR")


def _draw_layers_workspace(layout, context) -> None:
    material, settings, layers, active_index = _compact_panel_state(context)
    if material is None or settings is None or not layers:
        layout.label(text="画像を開く", icon="IMAGE_DATA")
        return
    try:
        active_target = str(material.get("sps_lightweight_active_target", "PIXELS") or "PIXELS").upper()
    except Exception:
        active_target = "PIXELS"

    visible_count = len(_display_layer_indices(settings))
    layout.template_list(
        SPS_UL_lightweight_layers.bl_idname,
        "main_compact",
        settings,
        "layers",
        settings,
        "lightweight_ui_layer_index",
        rows=max(5, min(10, visible_count)),
    )

    actions = layout.row(align=True)
    actions.operator(SPS_OT_lightweight_add_layer.bl_idname, text="", icon="ADD")
    actions.operator(SPS_OT_lightweight_add_adjustment.bl_idname, text="", icon="COLOR")
    actions.operator(SPS_OT_lightweight_group_active.bl_idname, text="", icon="FILE_FOLDER")
    mask = actions.row(align=True)
    active = layers[active_index] if active_index >= 0 else None
    mask.enabled = bool(
        active is not None
        and (_layer_is_paintable(active) or bool(getattr(active, "is_group", False)))
    )
    if active_target == "MASK":
        mask.operator(SPS_OT_lightweight_activate_pixels.bl_idname, text="", icon="BRUSH_DATA")
    else:
        mask.operator(SPS_OT_lightweight_activate_mask.bl_idname, text="", icon="MOD_MASK")
    actions.separator()
    move_up = actions.operator(SPS_OT_lightweight_move_layer.bl_idname, text="", icon="TRIA_UP")
    move_up.direction = "UP"
    move_down = actions.operator(SPS_OT_lightweight_move_layer.bl_idname, text="", icon="TRIA_DOWN")
    move_down.direction = "DOWN"
    actions.operator(SPS_OT_lightweight_delete_layer.bl_idname, text="", icon="REMOVE")
    actions.separator()
    thumbnails_on = _thumbnails_enabled(material)
    actions.operator(
        SPS_OT_lightweight_toggle_thumbnails.bl_idname,
        text="",
        icon="IMAGE_DATA",
        depress=bool(thumbnails_on),
    )
    refresh = actions.row(align=True)
    refresh.enabled = bool(thumbnails_on)
    refresh.operator(SPS_OT_lightweight_refresh_thumbnail.bl_idname, text="", icon="FILE_REFRESH")


def _draw_selection_workspace(layout, context) -> None:
    material, _settings_value, layers, _active_index = _compact_panel_state(context)
    if material is None or not layers:
        layout.label(text="画像を開く", icon="IMAGE_DATA")
        return
    selection_tools = _DRAW_SELECTION_TOOLS
    drawer = getattr(selection_tools, "draw_toolbar", None)
    if callable(drawer):
        drawer(layout, context, material, show_header=False)
    else:
        _draw_disabled_capability(layout, context, text_en="Selection controls are unavailable", text_ja="選択範囲機能を使用できません")


def _draw_paint_workspace(layout, context) -> None:
    material, _settings_value, layers, _active_index = _compact_panel_state(context)
    if material is None or not layers:
        layout.label(text="画像を開く", icon="IMAGE_DATA")
        return
    editing_tools = _DRAW_EDITING_TOOLS
    drawer = getattr(editing_tools, "draw_paint_toolbar", None)
    if callable(drawer):
        drawer(layout, context, material, show_header=False)
    else:
        _draw_disabled_capability(layout, context, text_en="Paint controls are unavailable", text_ja="描画機能を使用できません")


def _draw_transform_workspace(layout, context) -> None:
    material, _settings_value, layers, _active_index = _compact_panel_state(context)
    if material is None or not layers:
        layout.label(text="画像を開く", icon="IMAGE_DATA")
        return
    editing_tools = _DRAW_EDITING_TOOLS
    drawer = getattr(editing_tools, "draw_transform_toolbar", None)
    if callable(drawer):
        drawer(layout, context, material, show_header=False)
    else:
        _draw_disabled_capability(layout, context, text_en="Transform controls are unavailable", text_ja="変形機能を使用できません")

def _draw_layer_properties_workspace(layout, context) -> None:
    material, settings, layers, active_index = _compact_panel_state(context)
    if material is None or settings is None or active_index < 0:
        layout.label(text="レイヤーを選択")
        return
    active = layers[active_index]
    try:
        active_target = str(material.get("sps_lightweight_active_target", "PIXELS") or "PIXELS").upper()
        mask_owner_id = str(material.get("sps_lightweight_mask_owner_layer_id", "") or "")
    except Exception:
        active_target = "PIXELS"
        mask_owner_id = ""

    header = layout.row(align=True)
    header.prop(active, "name", text="")
    header.prop(
        active,
        "enabled",
        text="",
        icon="HIDE_OFF" if bool(getattr(active, "enabled", True)) else "HIDE_ON",
    )
    layout.prop(active, "opacity", text="不透明度", slider=True)
    is_adjustment = bool(
        str(getattr(active, "layer_kind", "") or "").upper() == "ADJUSTMENT"
        or str(getattr(active, "adjustment_type", "NONE") or "NONE").upper() != "NONE"
    )
    active_layer_id = _layer_id(active, active_index)
    mask_mode = str(getattr(active, "mask_mode", "NONE") or "NONE").upper()
    has_mask = bool(mask_mode != "NONE" or str(getattr(active, "mask_image", "") or ""))
    can_mask = bool(_layer_is_paintable(active) or getattr(active, "is_group", False) or is_adjustment)
    if can_mask:
        mask_row = layout.row(align=True)
        if active_target == "MASK" and mask_owner_id == active_layer_id:
            mask_row.operator(SPS_OT_lightweight_activate_pixels.bl_idname, text="ピクセル", icon="BRUSH_DATA")
        else:
            mask_row.operator(
                SPS_OT_lightweight_activate_mask.bl_idname,
                text="マスク編集" if has_mask else "マスク追加",
                icon="MOD_MASK",
            )
    if is_adjustment:
        _draw_adjustment_settings(layout, active)
    if bool(getattr(active, "is_group", False)):
        layout.prop(active, "blend_mode", text="グループ合成")
        if has_mask:
            layout.label(text=_ui_fmt("グループマスク: {}", _mask_mode_text(mask_mode)), icon="MOD_MASK")
    else:
        layout.prop(active, "blend_mode", text="合成")
        layout.prop(active, "clip_to_below", text="下のレイヤーでクリッピング")
        if has_mask:
            layout.label(text=_ui_fmt("マスク: {}", _mask_mode_text(mask_mode)), icon="MOD_MASK")


def _draw_external_workspace(layout, context) -> None:
    try:
        from . import external_bridge

        external_bridge.draw_panel(layout, context)
    except Exception:
        notice = layout.row()
        notice.alert = True
        notice.label(text="外部ペイントを表示できません", icon="ERROR")


# -----------------------------------------------------------------------------
# Unified SmartTools N-panel contract
# -----------------------------------------------------------------------------
_SECTION_HELP = {
    "always_on": (
        "Controls Smart Paint services that may remain available between explicit button operations. Disable every item for an idle runtime with no repeating work.",
        "ボタン実行以外でも待機できるSmart Paintの常時処理を管理します。すべてOFFにすると反復処理のない待機状態になります。",
    ),
    "document": (
        "Open, save, switch, and inspect the active layered or flat paint document without changing the user's original material graph. Switching to the paint material prepares one plain paint layer, so you can paint right away. A document without a file is kept inside the .blend when you save it, and Save As writes it to an image or PSD.",
        "ユーザーの元マテリアルノードを変更せず、レイヤー／フラット画像ドキュメントの読込、保存、表示切替、状態確認を行います。ペイント用マテリアルへ切り替えると、無地のペイントレイヤーが1枚用意され、そのまま描けます。元のファイルがない文書は .blend の保存で中に残り、「別名保存」で画像や PSD に書き出せます。",
    ),
    "layers": ("Adds, removes, reorders, groups, masks, and activates paint or adjustment layers.", "ペイント／調整レイヤーの追加、削除、並べ替え、グループ化、マスク、アクティブ切替を行います。"),
    "selection": ("Uses Smart Paint selection tools while preserving Blender's native selection context.", "Blender標準の選択コンテキストを維持しながらSmart Paintの選択範囲ツールを使用します。"),
    "paint": ("Shows the paint controls that operate through Blender's native Texture Paint system.", "Blender標準のテクスチャペイントを使用する描画コントロールを表示します。"),
    "transform": ("Transforms the active paint content with explicit confirmation and non-destructive document state handling.", "確認可能な操作と非破壊ドキュメント状態を維持して、アクティブな描画内容を変形します。"),
    "properties": ("Edits the active layer, mask, blend, opacity, clipping, group, and adjustment properties.", "アクティブレイヤー、マスク、合成、不透明度、クリッピング、グループ、調整設定を編集します。"),
    "brush_assets": ("Chooses Blender brush assets and imports GBR brushes without replacing the native paint shelf. Painting itself uses Blender's standard Texture Paint.", "Blender標準ブラシ資産を選択し、標準ペイント棚を置き換えずにGBRブラシを読み込みます。描画はBlender標準のテクスチャペイントで行います。"),
    "palette": ("Creates and imports palettes and exposes the active unified primary and secondary colors.", "パレットの作成・読込と、統合された主色／副色の編集を行います。"),
    "paint_preparation": ("Prepares UV or mesh island face masks, boundary selections, checkers, and texel-density measurements.", "UV島／メッシュ島の面マスク、境界選択、チェッカー、テクセル密度計測を準備します。"),
    "image_utilities": ("Runs explicit image utilities such as channel split/pack, mirror, rotate, padding, conversion, and SDF generation. Results always go to new images: the source image and the image being painted are not changed. Map Conversion accepts Non-Color images only.", "チャンネル分解・合成、反転、回転、パディング、マップ変換、SDF生成などの画像処理を明示実行します。結果は常に新しい画像へ出力し、元の画像と描画中の画像は変更しません。マップ変換の入力は Non-Color の画像だけです。"),
    "external": ("Prepares and synchronizes explicit external-paint exchanges. No background bridge starts merely by opening this section.", "外部ペイント交換の準備と明示同期を行います。このセクションを開くだけでバックグラウンド連携は開始しません。"),
}


def _ui_language_is_japanese(context) -> bool:
    """Read Blender's active translation locale without touching enum RNA."""
    try:
        from .constants import is_japanese_runtime

        return bool(is_japanese_runtime(context))
    except Exception:
        return False


def _runtime_ui_preferences(context):
    try:
        return getattr(context.window_manager, "smart_paint_suite_runtime_preferences", None)
    except Exception:
        return None


def _section_state_property(key: str) -> str:
    """Map a unified N-panel section key to its persisted RNA property."""
    normalized = str(key or "").strip().lower()
    if normalized == "always_on":
        return "show_always_on_toggles"
    return "ui_section_" + normalized


class SPS_OT_toggle_ui_section(bpy.types.Operator):
    bl_idname = "smart_paint_suite.toggle_ui_section"
    bl_label = "Toggle Smart Paint Section"
    bl_description = "Open or close one Smart Paint N-panel section without changing Blender data"
    bl_options = set()
    _sms_no_undo = True

    section: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        prefs = _runtime_ui_preferences(context)
        prop = _section_state_property(self.section)
        if prefs is None or not hasattr(prefs, prop):
            return {"CANCELLED"}
        try:
            setattr(prefs, prop, not bool(getattr(prefs, prop)))
        except Exception:
            return {"CANCELLED"}
        return {"FINISHED"}


class SPS_OT_show_section_help(bpy.types.Operator):
    bl_idname = "smart_paint_suite.show_section_help"
    bl_label = "Smart Paint Help"
    bl_description = "Show detailed usage for this Smart Paint section"
    bl_options = set()
    _sms_no_undo = True

    topic: StringProperty(options={"HIDDEN"})

    def invoke(self, context, _event):
        return context.window_manager.invoke_props_dialog(self, width=460)

    def draw(self, context):
        en, ja = _SECTION_HELP.get(str(self.topic or ""), ("Smart Paint section.", "Smart Paintのセクションです。"))
        text = ja if _ui_language_is_japanese(context) else en
        col = self.layout.column(align=True)
        words = str(text).split()
        if _ui_language_is_japanese(context):
            # Japanese help has no reliable spaces. Wrap by character count.
            lines = [text[i:i + 46] for i in range(0, len(text), 46)] or [text]
        else:
            lines, current = [], []
            for word in words:
                if len(" ".join(current + [word])) > 72 and current:
                    lines.append(" ".join(current)); current = [word]
                else:
                    current.append(word)
            if current: lines.append(" ".join(current))
        for line in lines:
            col.label(text=line)

    def execute(self, _context):
        return {"FINISHED"}


def _prepare_top_section(layout, context, key: str, title_en: str, title_ja: str, icon: str, drawer, *, default_open: bool = False, container=None):
    prefs = _runtime_ui_preferences(context)
    prop = _section_state_property(key)
    expanded = bool(getattr(prefs, prop, default_open)) if prefs is not None else bool(default_open)
    box = container if container is not None else layout.box()
    split = box.split(factor=0.88, align=True)
    left = split.row(align=True)
    op = left.operator(
        SPS_OT_toggle_ui_section.bl_idname,
        text="",
        icon="TRIA_DOWN" if expanded else "TRIA_RIGHT",
        emboss=True,
        depress=expanded,
    )
    op.section = key
    title = title_ja if _ui_language_is_japanese(context) else title_en
    title_op = left.operator(
        SPS_OT_toggle_ui_section.bl_idname,
        text=title,
        icon=icon if icon else "NONE",
        emboss=False,
        depress=expanded,
    )
    title_op.section = key
    right = split.row(align=True)
    right.alignment = "RIGHT"
    help_op = right.operator(SPS_OT_show_section_help.bl_idname, text="", icon="QUESTION", emboss=False)
    help_op.topic = key
    return {
        "box": box,
        "context": context,
        "expanded": bool(expanded),
        "drawer": drawer,
    }


def _populate_top_section(prepared):
    if not isinstance(prepared, dict) or not prepared.get("expanded"):
        return
    box = prepared.get("box")
    if box is None:
        return
    body = box.column(align=False)
    body.use_property_split = False
    body.use_property_decorate = False
    drawer = prepared.get("drawer")
    if callable(drawer):
        drawer(body, prepared.get("context"))


def _draw_top_section(layout, context, key: str, title_en: str, title_ja: str, icon: str, drawer, *, default_open: bool = False):
    _populate_top_section(
        _prepare_top_section(
            layout,
            context,
            key,
            title_en,
            title_ja,
            icon,
            drawer,
            default_open=default_open,
        )
    )


def _draw_always_on_body(layout, context) -> None:
    prefs = _runtime_ui_preferences(context)
    if prefs is None:
        layout.label(text="Smart Paint settings are unavailable.", icon="ERROR")
        return
    japanese = _ui_language_is_japanese(context)
    layout.label(text="設定項目" if japanese else "Settings")
    layout.prop(prefs, "n_panel_state_save", text="Nパネルの状態を保存" if japanese else "Save N-Panel State")
    layout.separator(factor=0.15)
    layout.prop(prefs, "suite_animated_brush_enabled", text="アニメーションブラシ" if japanese else "Animated Brush")
    layout.prop(prefs, "suite_texture_save_hook_enabled", text="テクスチャ保存フック" if japanese else "Texture Save Hook")
    layout.prop(prefs, "suite_brush_save_hook_enabled", text="ブラシ保存フック" if japanese else "Brush Save Hook")


def _draw_document_body(layout, context) -> None:
    _draw_workspace_header(layout, context)


def _draw_brush_assets_body(layout, context) -> None:
    module = _DRAW_BRUSH_UI
    callback = getattr(module, "_draw_brush_assets", None)
    if callable(callback):
        callback(layout, context)
    else:
        _draw_disabled_capability(layout, context, text_en="Brush Assets are unavailable", text_ja="ブラシ資産を使用できません")


def _draw_palette_body(layout, context) -> None:
    module = _DRAW_PALETTE_UI
    callback = getattr(module, "_draw_palette", None)
    if callable(callback):
        callback(layout, context)
    else:
        _draw_disabled_capability(layout, context, text_en="Color Palette is unavailable", text_ja="カラーパレットを使用できません")


class _SPSPanelDrawProxy:
    """Stable non-RNA proxy used to reuse legacy panel drawer functions."""

    __slots__ = ("layout",)

    def __init__(self, layout):
        self.layout = layout


def _draw_paint_preparation_body(layout, context) -> None:
    module = _DRAW_PAINT_PREPARATION
    panel = getattr(module, "SPS_PT_paint_preparation", None)
    drawer = getattr(panel, "draw", None)
    if callable(drawer):
        drawer(_SPSPanelDrawProxy(layout), context)
    else:
        _draw_disabled_capability(layout, context, text_en="Paint Preparation is unavailable", text_ja="ペイント準備を使用できません")


def _draw_image_utilities_body(layout, context) -> None:
    module = _DRAW_IMAGE_UTILITIES
    panel = getattr(module, "SPS_PT_image_utilities_image_editor", None)
    drawer = getattr(panel, "draw", None)
    if callable(drawer):
        drawer(_SPSPanelDrawProxy(layout), context)
    else:
        _draw_disabled_capability(layout, context, text_en="Image Utilities are unavailable", text_ja="画像ユーティリティを使用できません")


def _draw_disabled_capability(layout, context, *, text_en: str, text_ja: str) -> None:
    row = layout.column(align=True)
    row.enabled = False
    row.label(text=text_ja if _ui_language_is_japanese(context) else text_en)


def _draw_unified_smart_paint_root(layout, context, *, editor_key: str) -> None:
    """One complete body shared by all eleven static physical roots.

    Every root exposes the same top/child section contract.  Functions that
    require a paint-capable editor are represented by stable disabled controls
    in other editors rather than disappearing or waiting for a context anchor.
    """
    root = layout
    key = str(editor_key or "").upper()
    image_editor = key in {"IMAGE_EDITOR", "UV_EDITOR"}
    paint_capable = key in {"VIEW_3D", "IMAGE_EDITOR", "UV_EDITOR"}

    if paint_capable:
        layers_draw = _draw_layers_workspace
        selection_draw = _draw_selection_workspace
        paint_draw = _draw_paint_workspace
        transform_draw = _draw_transform_workspace
        properties_draw = _draw_layer_properties_workspace
    else:
        def _paint_unavailable(layout, draw_context):
            _draw_disabled_capability(
                layout, draw_context,
                text_en="Use in the 3D View, Image or UV Editor",
                text_ja="3Dビュー・画像・UVエディターで使えます",
            )
        layers_draw = selection_draw = paint_draw = transform_draw = properties_draw = _paint_unavailable

    def _prep_unavailable(layout, draw_context):
        _draw_disabled_capability(
            layout, draw_context, text_en="Use in the 3D View",
            text_ja="3Dビューで使えます",
        )
    def _image_unavailable(layout, draw_context):
        _draw_disabled_capability(
            layout, draw_context, text_en="Use in the Image or UV Editor",
            text_ja="画像・UVエディターで使えます",
        )
    prep_draw = _draw_paint_preparation_body if key == "VIEW_3D" else _prep_unavailable
    image_draw = _draw_image_utilities_body if image_editor else _image_unavailable
    section_specs = (
        ("always_on", "Resident Feature Toggles", "常時機能切り替え", "TIME", _draw_always_on_body, False),
        ("document", "Document", "ドキュメント", "FILE_IMAGE", _draw_document_body, True),
        ("layers", "Layers", "レイヤー", "RENDERLAYERS", layers_draw, True),
        ("selection", "Selection", "選択範囲", "RESTRICT_SELECT_OFF", selection_draw, False),
        ("paint", "Paint", "描画", "BRUSH_DATA", paint_draw, False),
        ("transform", "Transform", "変形", "ORIENTATION_GLOBAL", transform_draw, False),
        ("properties", "Properties", "プロパティ", "PROPERTIES", properties_draw, False),
        ("brush_assets", "Brush Assets", "ブラシ資産", "ASSET_MANAGER", _draw_brush_assets_body, False),
        ("palette", "Color Palette", "カラーパレット", "COLOR", _draw_palette_body, False),
        ("paint_preparation", "Paint Preparation", "ペイント準備", "UV", prep_draw, False),
        ("image_utilities", "Image Utilities", "画像ユーティリティ", "IMAGE_DATA", image_draw, False),
        ("external", "External Paint", "外部ペイント", "EXPORT", _draw_external_workspace, False),
    )
    top_slots = tuple(root.row(align=False) for _unused in section_specs)
    top_boxes = tuple(slot.box() for slot in top_slots)
    prepared_sections = tuple(
        _prepare_top_section(
            slot,
            context,
            section_key,
            title_en,
            title_ja,
            icon,
            drawer,
            default_open=default_open,
            container=box,
        )
        for slot, box, (section_key, title_en, title_ja, icon, drawer, default_open)
        in zip(top_slots, top_boxes, section_specs)
    )
    for prepared in prepared_sections:
        _populate_top_section(prepared)


def _draw_cross_editor_root(layout, context, editor_key: str) -> None:
    """Compatibility wrapper retained for callers from earlier 1.9.x builds."""
    _draw_unified_smart_paint_root(layout, context, editor_key=editor_key)


# The pre-1.9.277 per-section child Panel declarations were never part of
# CLASSES and therefore could not be registered.  The two historical roots and
# nine cross-editor roots now exclusively render the shared full body.


class SPS_PT_lightweight_view3d(bpy.types.Panel):
    def draw_header_preset(self, context):
        op = self.layout.operator(SPS_OT_show_section_help.bl_idname, text='', icon='QUESTION')
        op.topic = 'document'

    bl_idname = "SPS_PT_lightweight_view3d"
    bl_label = "Smart Paint"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("VIEW_3D",)

    @classmethod
    def poll(cls, context):
        return _manager_rule_api.panel_allowed_current(
            context,
            cls.bl_space_type,
            cls._smart_tools_manager_editor_keys,
        )

    def draw(self, context):
        _draw_unified_smart_paint_root(self.layout, context, editor_key="VIEW_3D")
        return None













class SPS_PT_lightweight_image_editor(bpy.types.Panel):
    def draw_header_preset(self, context):
        op = self.layout.operator(SPS_OT_show_section_help.bl_idname, text='', icon='QUESTION')
        op.topic = 'document'

    bl_idname = "SPS_PT_lightweight_image_editor"
    bl_label = "Smart Paint"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("IMAGE_EDITOR", "UV_EDITOR")

    @classmethod
    def poll(cls, context):
        return _manager_rule_api.panel_allowed_current(
            context,
            cls.bl_space_type,
            cls._smart_tools_manager_editor_keys,
        )

    def draw(self, context):
        _draw_unified_smart_paint_root(
            self.layout,
            context,
            editor_key=_manager_rule_api.current_logical_editor(context),
        )
        return None













CLASSES = (
    SPS_OT_lightweight_open_image,
    SPS_OT_lightweight_save_image,
    SPS_OT_lightweight_save_image_as,
    SPS_OT_lightweight_open_psd,
    SPS_OT_lightweight_activate_layer,
    SPS_OT_lightweight_save_psd,
    SPS_OT_lightweight_save_psd_as,
    SPS_OT_lightweight_select_layer,
    SPS_OT_lightweight_show_composite,
    SPS_OT_lightweight_show_live_composite,
    SPS_OT_lightweight_toggle_image_composite,
    SPS_OT_lightweight_show_active,
    SPS_OT_lightweight_toggle_visibility,
    SPS_OT_lightweight_toggle_group,
    SPS_OT_lightweight_add_layer,
    SPS_OT_lightweight_add_adjustment,
    SPS_OT_lightweight_delete_layer,
    SPS_OT_lightweight_move_layer,
    SPS_OT_lightweight_drag_layer,
    SPS_OT_lightweight_group_active,
    SPS_OT_lightweight_activate_mask,
    SPS_OT_lightweight_activate_pixels,
    SPS_OT_lightweight_toggle_thumbnails,
    SPS_OT_lightweight_refresh_thumbnail,
    SPS_UL_lightweight_layers,
    SPS_OT_toggle_ui_section,
    SPS_OT_show_section_help,
    SPS_PT_lightweight_view3d,
    SPS_PT_lightweight_image_editor,
)



def _translation_registry_key() -> str:
    return str(__package__ or "smart_paint_suite")


def _cleanup_runtime_state() -> None:
    """Release only non-RNA state owned by the active journal generation."""
    global _DRAW_BRUSH_UI, _DRAW_PALETTE_UI, _DRAW_PAINT_PREPARATION, _DRAW_IMAGE_UTILITIES
    global _DRAW_PAINT_WORKSPACE, _DRAW_IMAGE_EDITOR_OVERLAY, _DRAW_SELECTION_TOOLS, _DRAW_EDITING_TOOLS
    global _RUNTIME_MVP_MODULES, _THUMBNAIL_MODULE, _LIVE_COMPOSITE_MODULE
    cleanup_errors: list[str] = []
    cleanup_names = (
        "shutdown", "shutdown", "unregister_runtime", "unregister_runtime",
        "clear_runtime_caches", "shutdown",
    )
    for module, function_name in zip(_RUNTIME_MVP_MODULES, cleanup_names):
        try:
            callback = getattr(module, function_name, None)
            if callable(callback):
                callback()
        except (AttributeError, RuntimeError, ReferenceError, OSError) as exc:
            cleanup_errors.append(f"{getattr(module, '__name__', 'module')}.{function_name}:{type(exc).__name__}:{exc}")
    try:
        from . import resource_quota
        from .mvp import paint_target
        paint_target.clear_psd_api()
        resource_quota.clear_all_memory(reason="suite_unregister")
    except (ImportError, AttributeError, RuntimeError) as exc:
        cleanup_errors.append(f"resource_quota:{type(exc).__name__}:{exc}")
    try:
        from . import status_runtime
        status_runtime.clear_prefix("smart_paint_suite")
    except (ImportError, AttributeError, RuntimeError):
        pass
    try:
        _restore_material_display_shading(getattr(bpy, "context", None))
    except (RuntimeError, ReferenceError, AttributeError) as exc:
        cleanup_errors.append(f"display_shading:{type(exc).__name__}:{exc}")
    _ACTIVATED_LAYERS.clear()
    _COMPOSITE_BASE_CACHE.clear()
    _DOCUMENT_COMPOSITE_CACHE.clear()
    _REVIEW_SAVE_PAYLOAD_CACHE.clear()
    _FORCED_REVIEW_EDITOR_MODES.clear()
    _FORCED_MATERIAL_VIEW_SHADING.clear()
    _SESSION_SOURCE_PATHS.clear()
    _LAYERED_RECOVERY_CACHE.clear()
    _PROPERTY_REFRESH_PENDING.clear()
    _DRAW_BRUSH_UI = None
    _DRAW_PALETTE_UI = None
    _DRAW_PAINT_PREPARATION = None
    _DRAW_IMAGE_UTILITIES = None
    _DRAW_PAINT_WORKSPACE = None
    _DRAW_IMAGE_EDITOR_OVERLAY = None
    _DRAW_SELECTION_TOOLS = None
    _DRAW_EDITING_TOOLS = None
    _RUNTIME_MVP_MODULES = ()
    _THUMBNAIL_MODULE = None
    _LIVE_COMPOSITE_MODULE = None
    if cleanup_errors:
        raise RuntimeError("; ".join(cleanup_errors))


def register(transaction) -> None:
    """Acquire the complete Suite through one exact-identity transaction.

    Every registered class is preflighted before the first Blender-global
    mutation.  PropertyGroups are then materialized and registered in explicit
    dependency order; PointerProperties are created only after their target
    class has an exact registered ``bl_rna`` identity.
    """
    from . import (
        common,
        editor_panels,
        external_bridge,
        manager_rule_api,
        properties,
        suite_features,
        translation,
    )
    from .mvp import editing_tools, image_editor_overlay, paint_workspace, selection_tools, solid_view_overlay
    from .extras import brush_ui, image_utilities, paint_preparation, palette_ui

    extra_operator_classes = tuple(
        cls
        for cls in (
            *brush_ui.CLASSES,
            *palette_ui.CLASSES,
            *image_utilities.CLASSES,
            *paint_preparation.CLASSES,
        )
        if not issubclass(cls, bpy.types.Panel)
    )
    property_group_plan = (
        (properties.SPSBrushstrokeStyleItem, ()),
        (properties.SPSBrushstrokeToolPreferences, (properties.SPSBrushstrokeStyleItem,)),
        (properties.SPSGreasePencilTimelineSettings, ()),
        (properties.SPSGreasePencilLayerNavigatorSettings, ()),
        (
            properties.SPSGreasePencilToolPreferences,
            (
                properties.SPSGreasePencilTimelineSettings,
                properties.SPSGreasePencilLayerNavigatorSettings,
            ),
        ),
        (properties.SPSPaintSystemToolPreferences, ()),
        (properties.SPSTexturesAutosaveToolPreferences, ()),
        (properties.SPSUcupaintToolPreferences, ()),
        (
            properties.SPSAddonPreferences,
            (
                properties.SPSBrushstrokeToolPreferences,
                properties.SPSGreasePencilToolPreferences,
                properties.SPSPaintSystemToolPreferences,
                properties.SPSTexturesAutosaveToolPreferences,
                properties.SPSUcupaintToolPreferences,
            ),
        ),
        (properties.SPSLayerItem, ()),
        (properties.SPSMaterialSettings, (properties.SPSLayerItem,)),
        (properties.SPSSceneSettings, ()),
    )
    registration_manifest = (
        *(cls for cls, _dependencies in property_group_plan),
        *paint_workspace.CLASSES,
        *CLASSES,
        *editor_panels.CLASSES,
        *selection_tools.CLASSES,
        *editing_tools.CLASSES,
        *extra_operator_classes,
        *external_bridge.CLASSES,
    )
    preflight = transaction.preflight_classes(registration_manifest)
    if int(preflight.get("operator_count", 0)) != 72:
        raise RuntimeError(
            f"Smart Paint Operator inventory mismatch: {preflight.get('operator_count')} != 72"
        )

    global _DRAW_BRUSH_UI, _DRAW_PALETTE_UI, _DRAW_PAINT_PREPARATION, _DRAW_IMAGE_UTILITIES
    global _DRAW_PAINT_WORKSPACE, _DRAW_IMAGE_EDITOR_OVERLAY, _DRAW_SELECTION_TOOLS, _DRAW_EDITING_TOOLS
    global _RUNTIME_MVP_MODULES

    def _reset_registration_guard() -> None:
        common._APPLYING_PERSISTENT_SETTINGS = False

    # Install cleanup callbacks before mutating module-local registration state,
    # so any fault-injection point remains re-enable safe.
    transaction.add_cleanup(_reset_registration_guard, label="lightweight.persistence_guard_reset")
    transaction.add_cleanup(_cleanup_runtime_state, label="lightweight.runtime_cleanup")

    common._APPLYING_PERSISTENT_SETTINGS = True
    _DRAW_BRUSH_UI = brush_ui
    _DRAW_PALETTE_UI = palette_ui
    _DRAW_PAINT_PREPARATION = paint_preparation
    _DRAW_IMAGE_UTILITIES = image_utilities
    _DRAW_PAINT_WORKSPACE = paint_workspace
    _DRAW_IMAGE_EDITOR_OVERLAY = image_editor_overlay
    _DRAW_SELECTION_TOOLS = selection_tools
    _DRAW_EDITING_TOOLS = editing_tools
    from .mvp import layer_thumbnails, live_composite
    _RUNTIME_MVP_MODULES = (
        editing_tools,
        selection_tools,
        image_editor_overlay,
        solid_view_overlay,
        live_composite,
        layer_thumbnails,
    )

    try:
        for cls, dependencies in property_group_plan:
            transaction.register_property_group(cls, dependencies=dependencies)
        transaction.add_pointer_property(
            bpy.types.Material,
            "smart_paint_suite",
            properties.SPSMaterialSettings,
        )
        transaction.add_pointer_property(
            bpy.types.Scene,
            "smart_paint_suite",
            properties.SPSSceneSettings,
        )
        transaction.add_pointer_property(
            bpy.types.WindowManager,
            "smart_paint_suite_runtime_preferences",
            properties.SPSAddonPreferences,
        )
        transaction.component("rna_properties", "READY")

        for marker_name, marker_value in (
            ("SPS_LIGHTWEIGHT_MODE", True),
            ("SPS_LIGHTWEIGHT_GLOBAL_INPUT_HOOKS", 0),
            ("SPS_LIGHTWEIGHT_LOAD_POST_HANDLERS", 1),
        ):
            transaction.add_namespace_entry(
                bpy.app.driver_namespace,
                marker_name,
                marker_value,
                adopt_existing_exact=True,
            )

        common.register_persistence(transaction)
        manager_rule_api.register_public_lifecycle(transaction)
        suite_features.register(transaction)
        paint_workspace.register(transaction)
        transaction.component("persistence_and_services", "READY")

        editor_panels.bind_root_drawer(_draw_unified_smart_paint_root)
        transaction.add_cleanup(
            lambda: editor_panels.bind_root_drawer(None),
            label="editor_panels.unbind_root_drawer",
        )

        for cls in CLASSES:
            transaction.register_class(cls)
        for cls in editor_panels.CLASSES:
            transaction.register_class(cls)
        for cls in (*selection_tools.CLASSES, *editing_tools.CLASSES):
            transaction.register_class(cls)
        for cls in extra_operator_classes:
            transaction.register_class(cls)
        transaction.component("operators_and_panels", "READY")

        external_bridge.register(transaction)
        transaction.component("external_bridge", "READY")

        transaction.add_handler(
            bpy.app.handlers.load_post,
            _lightweight_load_post,
            label="lightweight.load_post_restore",
        )
        transaction.add_handler(
            bpy.app.handlers.save_pre,
            _lightweight_save_pre,
            label="lightweight.save_pre_sourceless",
        )
        image_editor_overlay.register_runtime(transaction)
        solid_view_overlay.register_runtime(transaction)
        transaction.component("overlays", "READY")

        catalog = getattr(translation, "TRANSLATIONS", None)
        if not isinstance(catalog, dict):
            catalog = translation.build_translations()
        transaction.add_translation(_translation_registry_key(), catalog)
        transaction.component("translations_and_cleanup", "READY")
    finally:
        # A RestrictBlend registration context has no Scene.  Keep the write
        # barrier active until common's owned one-shot callback restores both
        # persistence roots under a usable main-loop context.
        if common._INITIAL_RESTORE_COMPLETE:
            common._APPLYING_PERSISTENT_SETTINGS = False


def unregister() -> None:
    """Compatibility entry; root ``__init__.unregister`` owns journal teardown."""
    from . import runtime_registry
    result = runtime_registry.unregister(timeout=10.0)
    if not bool(result.get("ok", False)):
        raise RuntimeError("; ".join(str(value) for value in result.get("cleanup_errors", ())))
