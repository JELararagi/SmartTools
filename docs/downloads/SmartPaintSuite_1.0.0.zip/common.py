# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Event-driven Smart Paint N-panel persistence.

Only global N-panel preferences and scene-level Smart Paint settings are stored
in Blender's CONFIG directory.  Material/layer data remains in the .blend file
where Blender already owns its lifetime.  No polling timer is used.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import time
import warnings
from typing import Any

import bpy
from bpy.app.handlers import persistent

SUITE_ID = "smart_paint_suite"
SUITE_LABEL = "Smart Paint Suite"
SCHEMA_VERSION = 3
_APPLYING_PERSISTENT_SETTINGS = False
_DIRTY = False
_REGISTERED = False
_MSGBUS_OWNER = None
_REVISION = 0
_INITIAL_RESTORE_COMPLETE = False
_WRITES_ENABLED = True
_LAST_ERROR = ""
_REGISTERING_TRANSACTION = None
_MSGBUS_SUBSCRIBED = False
_OFF_COMMIT_CAPABILITY = None
_OFF_COMMIT_ACTIVE = False
_STARTUP_RESTORE_CALLBACK = None
_STARTUP_RESTORE_TOKEN = None


def config_directory() -> Path:
    base = Path(bpy.utils.user_resource("CONFIG", create=True))
    path = base / "Smart_Paint_Suite"
    path.mkdir(parents=True, exist_ok=True)
    return path


def settings_path() -> Path:
    return config_directory() / "Smart_Paint_Suite.json"


def _prop_is_skipped(prop) -> bool:
    identifier = str(getattr(prop, "identifier", "") or "")
    if not identifier or identifier in {"rna_type", "scene_settings_json"}:
        return True
    try:
        if bool(getattr(prop, "is_readonly", False)):
            return True
    except Exception:
        pass
    try:
        options = set(getattr(prop, "options", set()) or set())
        if "SKIP_SAVE" in options:
            return True
    except Exception:
        pass
    return False


def _id_reference(value) -> dict[str, str] | None:
    if value is None:
        return None
    try:
        if not isinstance(value, bpy.types.ID):
            return None
        return {
            "__id_type__": str(value.bl_rna.identifier or type(value).__name__),
            "name": str(value.name_full or value.name or ""),
        }
    except Exception:
        return None


def _serialize_value(value, prop=None, *, depth=0):
    if depth > 8:
        return None
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    ref = _id_reference(value)
    if ref is not None:
        return ref
    try:
        if isinstance(value, bpy.types.PropertyGroup):
            return _serialize_group(value, depth=depth + 1)
    except Exception:
        pass
    try:
        if prop is not None and str(getattr(prop, "type", "")) == "COLLECTION":
            return [_serialize_group(item, depth=depth + 1) for item in value]
    except Exception:
        return []
    try:
        if hasattr(value, "to_list"):
            return list(value.to_list())
    except Exception:
        pass
    try:
        if hasattr(value, "__iter__") and not isinstance(value, (bytes, bytearray)):
            return [item for item in value]
    except Exception:
        pass
    return None


def _serialize_group(group, *, depth=0) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if group is None or depth > 8:
        return payload
    try:
        properties = group.bl_rna.properties
    except Exception:
        return payload
    for prop in properties:
        if _prop_is_skipped(prop):
            continue
        name = str(prop.identifier)
        try:
            value = getattr(group, name)
        except Exception:
            continue
        serialized = _serialize_value(value, prop, depth=depth)
        if serialized is not None:
            payload[name] = serialized
    return payload


_SCENE_OUTPUT_PREFIXES = ("last_", "measured_")
_SCENE_OUTPUT_NAMES = {
    "projection_previous_image_name",
    "projection_source_image_name",
    "projection_target_layer_id",
    "projection_previous_enabled",
    "projection_previous_mode",
    "projection_previous_layer_kind",
    "snapshot_text_name",
    "smart_2d_last_manifest_path",
    "smart_quality_score",
    "smart_quality_grade",
    "smart_last_quality_report",
    "smart_last_quality_report_path",
    "smart_last_report_text_name",
    "smart_last_bridge_path",
}


def _serialize_scene_preferences(group) -> dict[str, Any]:
    """Serialize only scalar N-panel choices, never scene/document objects."""
    if group is None:
        return {}
    try:
        from .properties import SCENE_SETTINGS_PERSIST_PROPS
        properties = {str(prop.identifier): prop for prop in group.bl_rna.properties}
    except Exception:
        return {}
    payload: dict[str, Any] = {}
    for name in SCENE_SETTINGS_PERSIST_PROPS:
        if name.startswith(_SCENE_OUTPUT_PREFIXES) or name in _SCENE_OUTPUT_NAMES:
            continue
        prop = properties.get(name)
        if prop is None or _prop_is_skipped(prop):
            continue
        if str(getattr(prop, "type", "")) in {"POINTER", "COLLECTION"}:
            continue
        try:
            value = _serialize_value(getattr(group, name), prop)
        except Exception:
            continue
        if value is not None:
            payload[name] = value
    return payload


def _deep_overlay(base: Any, current: Any) -> Any:
    """Overlay owned dictionaries while retaining unknown nested keys."""
    if not isinstance(base, dict) or not isinstance(current, dict):
        return current
    merged = dict(base)
    for key, value in current.items():
        merged[key] = _deep_overlay(merged.get(key), value)
    return merged


def _id_collection(identifier: str):
    key = str(identifier or "").upper()
    mapping = {
        "IMAGE": "images",
        "OBJECT": "objects",
        "MATERIAL": "materials",
        "TEXTURE": "textures",
        "COLLECTION": "collections",
        "NODETREE": "node_groups",
        "SCENE": "scenes",
        "WORLD": "worlds",
        "BRUSH": "brushes",
        "TEXT": "texts",
        "CAMERA": "cameras",
        "MESH": "meshes",
    }
    attr = mapping.get(key)
    return getattr(bpy.data, attr, None) if attr else None


def _resolve_id_reference(data):
    if not isinstance(data, dict) or "__id_type__" not in data:
        return None
    collection = _id_collection(str(data.get("__id_type__", "")))
    name = str(data.get("name", "") or "")
    if collection is None or not name:
        return None
    try:
        return collection.get(name)
    except Exception:
        return None


def _assign_scalar(group, name: str, value) -> None:
    try:
        current = getattr(group, name)
    except Exception:
        current = None
    try:
        current_cmp = list(current) if hasattr(current, "__iter__") and not isinstance(current, (str, bytes)) else current
    except Exception:
        current_cmp = current
    if current_cmp == value:
        return
    try:
        # Blender warns for legacy blend-relative paths on a few extension-only
        # properties.  The value remains valid for the add-on, so suppress only
        # that assignment warning while preserving the user's exact string.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            setattr(group, name, value)
    except Exception:
        pass


def _apply_group(group, payload: dict[str, Any], *, depth=0) -> None:
    if group is None or not isinstance(payload, dict) or depth > 8:
        return
    try:
        rna_props = {str(prop.identifier): prop for prop in group.bl_rna.properties}
    except Exception:
        return
    for name, value in payload.items():
        prop = rna_props.get(str(name))
        if prop is None or _prop_is_skipped(prop):
            continue
        ptype = str(getattr(prop, "type", ""))
        if ptype == "POINTER":
            try:
                target = getattr(group, name)
            except Exception:
                target = None
            resolved = _resolve_id_reference(value)
            if resolved is not None or (isinstance(value, dict) and "__id_type__" in value):
                try:
                    setattr(group, name, resolved)
                except Exception:
                    pass
            elif isinstance(value, dict) and target is not None:
                _apply_group(target, value, depth=depth + 1)
            continue
        if ptype == "COLLECTION":
            try:
                collection = getattr(group, name)
            except Exception:
                continue
            if not isinstance(value, list) or not hasattr(collection, "add"):
                continue
            try:
                collection.clear()
            except Exception:
                while len(collection):
                    try:
                        collection.remove(len(collection) - 1)
                    except Exception:
                        break
            for item_payload in value:
                try:
                    item = collection.add()
                except Exception:
                    break
                if isinstance(item_payload, dict):
                    _apply_group(item, item_payload, depth=depth + 1)
            continue
        _assign_scalar(group, name, value)


def _runtime_preferences(context=None):
    try:
        ctx = context or bpy.context
        return getattr(ctx.window_manager, "smart_paint_suite_runtime_preferences", None)
    except Exception:
        return None


_RUNTIME_PREFERENCES_RNA_IDENTIFIER = "SPSAddonPreferences"


def _live_runtime_preferences_identity(value):
    """Return the authenticated native identity for a live preferences wrapper."""
    if value is None:
        return None
    try:
        pointer = int(value.as_pointer())
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError, OverflowError):
        return None
    if pointer <= 0:
        return None
    try:
        identifier = str(value.bl_rna.identifier)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None
    if identifier != _RUNTIME_PREFERENCES_RNA_IDENTIFIER:
        return None
    return pointer


def _same_runtime_preferences_owner(owner, expected_owner) -> bool:
    """Accept separate Python wrappers only when they address one live RNA struct."""
    if owner is None or expected_owner is None:
        return False
    if type(owner) is not type(expected_owner):
        return False
    owner_pointer = _live_runtime_preferences_identity(owner)
    if owner_pointer is None:
        return False
    expected_pointer = _live_runtime_preferences_identity(expected_owner)
    return expected_pointer is not None and owner_pointer == expected_pointer


def _scene_settings(context=None):
    try:
        ctx = context or bpy.context
        scene = getattr(ctx, "scene", None)
        return getattr(scene, "smart_paint_suite", None) if scene is not None else None
    except Exception:
        return None


def _initial_restore_context_ready(context=None) -> bool:
    """Require both persistence roots before releasing the startup barrier."""
    return _runtime_preferences(context) is not None and _scene_settings(context) is not None


def _cancel_startup_restore() -> None:
    """Cancel only this generation's exact deferred restore callback."""
    global _STARTUP_RESTORE_CALLBACK, _STARTUP_RESTORE_TOKEN
    callback = _STARTUP_RESTORE_CALLBACK
    _STARTUP_RESTORE_CALLBACK = None
    _STARTUP_RESTORE_TOKEN = None
    if callback is None:
        return
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    try:
        if timers is not None and timers.is_registered(callback):
            timers.unregister(callback)
    except (AttributeError, ReferenceError, RuntimeError, ValueError):
        pass


def _complete_initial_restore(context=None, *, sync_runtime: bool) -> bool:
    """Apply both roots atomically, then enable only the restored resource set."""
    global _APPLYING_PERSISTENT_SETTINGS, _INITIAL_RESTORE_COMPLETE, _WRITES_ENABLED
    if not _REGISTERED or _INITIAL_RESTORE_COMPLETE or not _initial_restore_context_ready(context):
        return False
    _APPLYING_PERSISTENT_SETTINGS = True
    load_persistent_settings(context)
    _INITIAL_RESTORE_COMPLETE = True
    _WRITES_ENABLED = _immediate_save_enabled(context)
    _APPLYING_PERSISTENT_SETTINGS = False
    _sync_persistence_resources(context)
    if sync_runtime:
        try:
            from . import suite_features
            suite_features.sync_runtime(context)
        except (ImportError, RuntimeError, AttributeError, ReferenceError):
            pass
    return True


def _schedule_initial_restore(transaction) -> None:
    """Schedule one owned main-loop opportunity; never poll or repeat."""
    global _STARTUP_RESTORE_CALLBACK, _STARTUP_RESTORE_TOKEN
    global _LAST_ERROR
    _cancel_startup_restore()
    token = object()

    def _restore_once(token=token):
        global _STARTUP_RESTORE_CALLBACK, _STARTUP_RESTORE_TOKEN, _LAST_ERROR
        if token is not _STARTUP_RESTORE_TOKEN or not _REGISTERED:
            return None
        _STARTUP_RESTORE_CALLBACK = None
        try:
            if not _initial_restore_context_ready(None):
                _LAST_ERROR = "initial_restore_context_unavailable"
                return None
            if not _complete_initial_restore(None, sync_runtime=True):
                _LAST_ERROR = "initial_restore_not_completed"
        except Exception as exc:
            _LAST_ERROR = f"initial_restore_failed:{type(exc).__name__}"
        finally:
            if token is _STARTUP_RESTORE_TOKEN:
                _STARTUP_RESTORE_TOKEN = None
        return None

    _STARTUP_RESTORE_TOKEN = token
    _STARTUP_RESTORE_CALLBACK = _restore_once
    transaction.add_cleanup(_cancel_startup_restore, label="persistence.startup_restore")
    bpy.app.timers.register(_restore_once, first_interval=0.0, persistent=False)


def backup_settings_path() -> Path:
    return settings_path().with_suffix(settings_path().suffix + ".bak")


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def _payload_checksum(data: dict[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(data)).hexdigest()


def _current_payload(context=None, existing: dict[str, Any] | None = None) -> dict[str, Any]:
    global _REVISION
    existing = existing if isinstance(existing, dict) else {}
    existing_data = existing.get("data") if isinstance(existing.get("data"), dict) else {}
    owned_data = {
        "runtime_preferences": _serialize_group(_runtime_preferences(context)),
        "scene_settings": _serialize_scene_preferences(_scene_settings(context)),
    }
    data = _deep_overlay(existing_data, owned_data)
    root = dict(existing)
    _REVISION = max(int(_REVISION) + 1, int(existing.get("revision", 0) or 0) + 1, int(time.time_ns()))
    root.update({
        "schema_version": SCHEMA_VERSION,
        "suite": SUITE_ID,
        "revision": int(_REVISION),
        "saved_at": time.time(),
        "data": data,
        "checksum": _payload_checksum(data),
    })
    return root


def _validate_payload(value: Any) -> tuple[bool, dict[str, Any], str]:
    if not isinstance(value, dict):
        return False, {}, "settings_not_object"
    schema = int(value.get("schema_version", -1) or -1)
    if schema == 2 and str(value.get("suite", SUITE_ID) or SUITE_ID) == SUITE_ID:
        # One-time compatibility migration from 1.9.273.
        data = {
            "runtime_preferences": dict(value.get("runtime_preferences", {}) or {}),
            "scene_settings": dict(value.get("scene_settings", {}) or {}),
        }
        migrated = {
            "schema_version": SCHEMA_VERSION,
            "suite": SUITE_ID,
            "revision": int(float(value.get("saved_at", 0.0) or 0.0) * 1_000_000_000),
            "saved_at": float(value.get("saved_at", 0.0) or 0.0),
            "data": data,
            "checksum": _payload_checksum(data),
        }
        return True, migrated, "migrated_schema_2"
    if schema != SCHEMA_VERSION or str(value.get("suite", "") or "") != SUITE_ID:
        return False, {}, "settings_schema_or_owner_invalid"
    data = value.get("data")
    if not isinstance(data, dict):
        return False, {}, "settings_data_invalid"
    checksum = str(value.get("checksum", "") or "")
    if len(checksum) != 64 or checksum != _payload_checksum(data):
        return False, {}, "settings_checksum_invalid"
    try:
        revision = int(value.get("revision", 0) or 0)
        saved_at = float(value.get("saved_at", 0.0) or 0.0)
    except (TypeError, ValueError):
        return False, {}, "settings_revision_invalid"
    if revision < 0 or saved_at < 0.0:
        return False, {}, "settings_revision_invalid"
    normalized = dict(value)
    normalized["revision"] = revision
    normalized["saved_at"] = saved_at
    return True, normalized, "ok"


def _read_valid_payload(path: Path) -> tuple[dict[str, Any] | None, str]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return None, f"settings_read_failed:{type(exc).__name__}"
    ok, value, reason = _validate_payload(raw)
    return (value if ok else None), reason


def _atomic_bytes(path: Path, encoded: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
        try:
            directory_fd = os.open(str(path.parent), os.O_RDONLY)
        except (AttributeError, OSError):
            directory_fd = None
        if directory_fd is not None:
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
    finally:
        try:
            if os.path.exists(temp_name):
                os.remove(temp_name)
        except OSError:
            pass


def _atomic_write(path: Path, payload: dict[str, Any]) -> None:
    ok, normalized, reason = _validate_payload(payload)
    if not ok:
        raise ValueError(reason)
    encoded = json.dumps(normalized, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8") + b"\n"
    current, _current_reason = _read_valid_payload(path) if path.is_file() else (None, "missing")
    if current is not None:
        _atomic_bytes(backup_settings_path(), path.read_bytes())
    _atomic_bytes(path, encoded)
    check, check_reason = _read_valid_payload(path)
    if check is None or int(check.get("revision", -1)) != int(normalized.get("revision", -2)):
        raise OSError(f"settings_readback_failed:{check_reason}")

def _immediate_save_enabled(context=None) -> bool:
    prefs = _runtime_preferences(context)
    try:
        return bool(getattr(prefs, "n_panel_state_save", True)) if prefs is not None else True
    except Exception:
        return True


def _save_persistent_settings(context=None, *, capability=None) -> bool:
    global _DIRTY, _LAST_ERROR
    # Restore/startup and the writer state are checked before context, RNA, or
    # path access.  The only exception is the exact live one-shot OFF capability.
    if _APPLYING_PERSISTENT_SETTINGS or not _INITIAL_RESTORE_COMPLETE:
        return False
    if capability is None:
        if not _WRITES_ENABLED:
            _DIRTY = True
            return False
    elif not (
        _OFF_COMMIT_ACTIVE
        and capability is _OFF_COMMIT_CAPABILITY
        and _WRITES_ENABLED
    ):
        _DIRTY = True
        return False
    if _runtime_preferences(context) is None and _scene_settings(context) is None:
        return False
    path = settings_path()
    existing = None
    if path.exists():
        existing, read_reason = _read_valid_payload(path)
        if existing is None:
            _LAST_ERROR = read_reason
            _DIRTY = True
            return False
    try:
        payload = _current_payload(context, existing)
        if existing is not None and existing.get("data") == payload.get("data"):
            _DIRTY = False
            _LAST_ERROR = ""
            return True
        _atomic_write(path, payload)
    except (OSError, ValueError, TypeError, UnicodeError) as exc:
        _LAST_ERROR = f"settings_write_failed:{type(exc).__name__}"
        _DIRTY = True
        return False
    _DIRTY = False
    _LAST_ERROR = ""
    return True


def save_persistent_settings(context=None, *, force=False, reason="") -> bool:
    # ``force`` is retained only for source compatibility.  It never grants a
    # transition or bypasses restore/OFF.  No transition token is public.
    del force, reason
    return _save_persistent_settings(context)


def request_persistent_settings_save(context=None, *, force=False) -> bool:
    return save_persistent_settings(context, force=force, reason="property_update")


def commit_state_save_toggle(owner, context=None, *, enabled: bool) -> bool:
    """Accept one actual RNA ON/OFF edge and retire its OFF capability."""
    global _WRITES_ENABLED, _OFF_COMMIT_CAPABILITY, _OFF_COMMIT_ACTIVE
    if _APPLYING_PERSISTENT_SETTINGS or not _INITIAL_RESTORE_COMPLETE:
        return False
    enabled = bool(enabled)
    # Repeated callbacks are rejected before context/RNA/path access.
    if enabled == _WRITES_ENABLED:
        return False
    expected_owner = _runtime_preferences(context)
    if not _same_runtime_preferences_owner(owner, expected_owner):
        return False
    try:
        actual_enabled = bool(getattr(owner, "n_panel_state_save"))
    except Exception:
        return False
    if actual_enabled != enabled:
        return False
    if enabled:
        _WRITES_ENABLED = True
        saved = _save_persistent_settings(context)
    else:
        capability = object()
        _OFF_COMMIT_CAPABILITY = capability
        _OFF_COMMIT_ACTIVE = True
        try:
            saved = _save_persistent_settings(context, capability=capability)
        finally:
            _OFF_COMMIT_ACTIVE = False
            _OFF_COMMIT_CAPABILITY = None
            _WRITES_ENABLED = False
    _sync_persistence_resources(context)
    return saved


def load_persistent_settings(context=None) -> bool:
    global _APPLYING_PERSISTENT_SETTINGS, _DIRTY, _REVISION, _LAST_ERROR, _WRITES_ENABLED
    candidates = []
    diagnostics = []
    for candidate in (settings_path(), backup_settings_path()):
        if not candidate.is_file():
            continue
        payload, reason = _read_valid_payload(candidate)
        diagnostics.append((candidate, reason))
        if payload is not None:
            candidates.append((int(payload.get("revision", 0)), float(payload.get("saved_at", 0.0)), candidate, payload))
    if not candidates:
        # Preserve invalid files for diagnosis; never overwrite them with defaults.
        if diagnostics:
            _LAST_ERROR = diagnostics[0][1]
        return False
    _revision, _saved_at, source, payload = max(candidates, key=lambda item: (item[0], item[1]))
    data = dict(payload.get("data", {}) or {})
    outer_applying = _APPLYING_PERSISTENT_SETTINGS
    _APPLYING_PERSISTENT_SETTINGS = True
    try:
        _apply_group(_runtime_preferences(context), dict(data.get("runtime_preferences", {}) or {}))
        scene_payload = dict(data.get("scene_settings", {}) or {})
        allowed_scene = _serialize_scene_preferences(_scene_settings(context))
        _apply_group(
            _scene_settings(context),
            {key: value for key, value in scene_payload.items() if key in allowed_scene},
        )
    finally:
        _APPLYING_PERSISTENT_SETTINGS = outer_applying
    _REVISION = max(int(_REVISION), int(payload.get("revision", 0) or 0))
    _DIRTY = False
    _LAST_ERROR = ""
    if _INITIAL_RESTORE_COMPLETE:
        _WRITES_ENABLED = _immediate_save_enabled(context)
        _sync_persistence_resources(context)
    if not outer_applying:
        try:
            from . import suite_features
            suite_features.sync_runtime(context)
        except (ImportError, RuntimeError, AttributeError):
            pass
    return True


@persistent
def _load_pre(_filepath=None):
    # The current scene is about to be replaced.  When immediate saving is OFF,
    # this is the requested scene-close boundary.  Cache release is deliberately
    # exact and data-only; no Blender datablock is removed here.
    try:
        from .mvp import editing_tools, live_composite

        editing_tools.shutdown()
        live_composite.clear_runtime_caches(remove_unused_owned_data=True)
    except (ImportError, RuntimeError, AttributeError, ReferenceError):
        pass
    try:
        from . import resource_quota

        resource_quota.clear_all_memory(reason="load_pre")
    except (ImportError, RuntimeError, AttributeError):
        pass


@persistent
def _load_post(_filepath=None):
    try:
        from . import status_runtime
        with status_runtime.task_scope(
            "smart_paint_suite.handler.load_post",
            "Smart Paint Suite: Restoring settings…",
            completed_text="Smart Paint Suite: Settings restored",
        ):
            load_persistent_settings(None)
    except Exception:
        load_persistent_settings(None)


@persistent
def _save_pre(_filepath=None):
    return None


@persistent
def _exit_pre(_unused=None):
    return None


def _scene_changed():
    # Window.scene msgbus is event driven and adds no polling load.  When
    # immediate persistence is disabled, WindowManager preferences already
    # carry the live state and must not be overwritten by an older JSON.
    if _immediate_save_enabled(None):
        load_persistent_settings(None)
    try:
        from . import suite_features
        suite_features.sync_runtime(getattr(bpy, "context", None))
    except Exception:
        pass


def _append_handler(name: str, callback) -> None:
    handlers = getattr(bpy.app.handlers, name, None)
    if handlers is not None and callback not in handlers:
        handlers.append(callback)


def _remove_handler(name: str, callback) -> None:
    handlers = getattr(bpy.app.handlers, name, None)
    if handlers is None:
        return
    while callback in handlers:
        handlers.remove(callback)


def _persistence_handler_specs():
    return (
        (bpy.app.handlers.load_pre, _load_pre, "persistence.load_pre"),
        (bpy.app.handlers.load_post, _load_post, "persistence.load_post"),
    )


def _remove_persistence_resources() -> None:
    global _MSGBUS_SUBSCRIBED
    from . import runtime_registry
    for handler_list, callback, _label in _persistence_handler_specs():
        runtime_registry.remove_handler(handler_list, callback)
    if _MSGBUS_OWNER is not None:
        try:
            bpy.msgbus.clear_by_owner(_MSGBUS_OWNER)
        except Exception:
            pass
    _MSGBUS_SUBSCRIBED = False


def _sync_persistence_resources(context=None) -> None:
    """Own exactly one event-driven resource set while state saving is ON."""
    del context
    global _MSGBUS_OWNER, _MSGBUS_SUBSCRIBED
    from . import runtime_registry
    if not _WRITES_ENABLED:
        _remove_persistence_resources()
        return
    transaction = _REGISTERING_TRANSACTION
    for handler_list, callback, label in _persistence_handler_specs():
        if callback in handler_list:
            continue
        if transaction is not None and getattr(transaction, "state", "") == "REGISTERING":
            transaction.add_handler(handler_list, callback, label=label)
        else:
            runtime_registry.add_handler(handler_list, callback, label=label)
    if _MSGBUS_OWNER is None:
        _MSGBUS_OWNER = object()
    if not _MSGBUS_SUBSCRIBED:
        if transaction is not None and getattr(transaction, "state", "") == "REGISTERING":
            transaction.add_msgbus(
                key=(bpy.types.Window, "scene"), owner=_MSGBUS_OWNER, args=(),
                notify=_scene_changed, options={"PERSISTENT"},
            )
        else:
            bpy.msgbus.subscribe_rna(
                key=(bpy.types.Window, "scene"), owner=_MSGBUS_OWNER, args=(),
                notify=_scene_changed, options={"PERSISTENT"},
            )
        _MSGBUS_SUBSCRIBED = True


def register_persistence(transaction, context=None) -> None:
    global _REGISTERED, _APPLYING_PERSISTENT_SETTINGS, _MSGBUS_OWNER
    global _INITIAL_RESTORE_COMPLETE, _WRITES_ENABLED, _REGISTERING_TRANSACTION
    if _REGISTERED:
        raise RuntimeError("Smart Paint persistence already registered")
    _MSGBUS_OWNER = object()
    transaction.add_cleanup(_remove_persistence_resources, label="persistence.resources")
    transaction.add_cleanup(_reset_registration_state, label="persistence.reset")
    _REGISTERED = True
    _REGISTERING_TRANSACTION = transaction
    _INITIAL_RESTORE_COMPLETE = False
    _WRITES_ENABLED = False
    _APPLYING_PERSISTENT_SETTINGS = True
    try:
        if _initial_restore_context_ready(context):
            _complete_initial_restore(context, sync_runtime=False)
        else:
            _schedule_initial_restore(transaction)
    finally:
        _REGISTERING_TRANSACTION = None


def _reset_registration_state() -> None:
    global _REGISTERED, _MSGBUS_OWNER, _APPLYING_PERSISTENT_SETTINGS
    global _INITIAL_RESTORE_COMPLETE, _WRITES_ENABLED, _REGISTERING_TRANSACTION
    global _OFF_COMMIT_CAPABILITY, _OFF_COMMIT_ACTIVE
    _cancel_startup_restore()
    _REGISTERED = False
    _MSGBUS_OWNER = None
    _APPLYING_PERSISTENT_SETTINGS = False
    _INITIAL_RESTORE_COMPLETE = False
    _WRITES_ENABLED = True
    _REGISTERING_TRANSACTION = None
    _OFF_COMMIT_CAPABILITY = None
    _OFF_COMMIT_ACTIVE = False


def unregister_persistence(context=None) -> None:
    """Compatibility surface; exact resource removal is owned by the journal."""
    del context
    return None


__all__ = (
    "_APPLYING_PERSISTENT_SETTINGS", "backup_settings_path", "config_directory", "load_persistent_settings",
    "commit_state_save_toggle", "register_persistence", "request_persistent_settings_save", "save_persistent_settings",
    "settings_path", "unregister_persistence",
)
