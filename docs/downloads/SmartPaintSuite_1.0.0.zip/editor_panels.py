# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Ten additional static roots for the supported editors.

VIEW_3D and IMAGE_EDITOR retain their historical RNA identities in
``lightweight_mvp``.  Shared regions use one fixed Panel and resolve
logical subtypes in read-only ``poll``/``draw`` code; no dynamic class creation,
Panel metadata mutation, or context-wait anchor is used.
"""
from __future__ import annotations

import bpy

from .manager_rule_api import current_logical_editor, panel_allowed_current

_ROOT_DRAWER = None

def bind_root_drawer(drawer) -> None:
    """Bind the already-imported shared body before Panel registration."""
    global _ROOT_DRAWER
    _ROOT_DRAWER = drawer if callable(drawer) else None



class _SPSPhysicalRootMixin:
    def draw_header_preset(self, context):
        op = self.layout.operator('smart_paint_suite.show_section_help', text='', icon='QUESTION')
        op.topic = 'document'

    bl_label = "Smart Paint"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys: tuple[str, ...] = ()

    @classmethod
    def poll(cls, context):
        return panel_allowed_current(
            context,
            cls.bl_space_type,
            cls._smart_tools_manager_editor_keys,
        )

    def draw(self, context):
        drawer = _ROOT_DRAWER
        if callable(drawer):
            drawer(
                self.layout,
                context,
                editor_key=current_logical_editor(context),
            )
        else:
            row = self.layout.row()
            row.enabled = False
            row.label(text="Smart Paint")
        return None


class SPS_PT_root_node_editor(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_node_editor"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("SHADER_EDITOR", "COMPOSITOR", "GEOMETRY_NODE_EDITOR", "TEXTURE_NODE_EDITOR")


class SPS_PT_root_video_sequencer(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_video_sequencer"
    bl_space_type = "SEQUENCE_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("VIDEO_SEQUENCER",)


class SPS_PT_root_movie_clip_editor(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_movie_clip_editor"
    bl_space_type = "CLIP_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("MOVIE_CLIP_EDITOR",)


class SPS_PT_root_dope_sheet(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_dope_sheet"
    bl_space_type = "DOPESHEET_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("DOPE_SHEET",)


class SPS_PT_root_graph_editor(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_graph_editor"
    bl_space_type = "GRAPH_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("GRAPH_EDITOR", "DRIVERS")


class SPS_PT_root_nla_editor(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_nla_editor"
    bl_space_type = "NLA_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("NLA_EDITOR",)


class SPS_PT_root_text_editor(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_text_editor"
    bl_space_type = "TEXT_EDITOR"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("TEXT_EDITOR",)


class SPS_PT_root_file_browser(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_file_browser"
    bl_space_type = "FILE_BROWSER"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("FILE_BROWSER",)


class SPS_PT_root_asset_browser(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_asset_browser"
    bl_space_type = "FILE_BROWSER"
    bl_region_type = "TOOL_PROPS"
    bl_category = "Smart Paint"
    _smart_tools_manager_editor_keys = ("ASSET_BROWSER",)


class SPS_PT_root_spreadsheet(_SPSPhysicalRootMixin, bpy.types.Panel):
    bl_idname = "SPS_PT_root_spreadsheet"
    bl_space_type = "SPREADSHEET"
    bl_region_type = "UI"
    bl_category = "Smart Paint"
    _smart_tools_manager_tool_key = "SMART_PAINT"
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_editor_keys = ("SPREADSHEET",)


__all__ = ("CLASSES", "bind_root_drawer")


CLASSES = (
    SPS_PT_root_node_editor,
    SPS_PT_root_video_sequencer,
    SPS_PT_root_movie_clip_editor,
    SPS_PT_root_dope_sheet,
    SPS_PT_root_graph_editor,
    SPS_PT_root_nla_editor,
    SPS_PT_root_text_editor,
    SPS_PT_root_file_browser,
    SPS_PT_root_asset_browser,
    SPS_PT_root_spreadsheet,
)

__all__ = ("CLASSES",) + tuple(cls.__name__ for cls in CLASSES)
