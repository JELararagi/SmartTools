# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Event-driven Photoshop layer-metadata commands for an active bridge lease.

No resident command history is retained: the active session owns the finite
command transaction and acknowledgement.  OFF/disconnected/idle therefore
keeps zero queue bytes, timers, workers and periodic writes.
"""
from __future__ import annotations

import time


def is_running_for_context(_context=None) -> bool:
    from .external_bridge import session

    state = session.snapshot()
    return bool(state.get("connected") and state.get("backend") == "PHOTOSHOP")


def queue_layer_command(context, command_type: str, *, layer_id: str, **payload):
    del context
    from .external_bridge import session

    if not is_running_for_context(None):
        return False, "photoshop_bridge_not_connected"
    command = {
        "type": str(command_type or ""),
        "layer_id": str(layer_id or ""),
        "payload": {
            str(key): value
            for key, value in payload.items()
            if isinstance(value, (str, bool, int, float, type(None)))
        },
        "created_at": time.time(),
    }
    if not command["type"] or not command["layer_id"]:
        return False, "invalid_layer_command"
    result = session.queue_layer_command(command)
    return bool(result.get("ok")), str(result.get("reason", "") or "")


def clear_commands() -> None:
    """Compatibility no-op: commands are never retained outside the session."""
    return None


__all__ = ("clear_commands", "is_running_for_context", "queue_layer_command")
