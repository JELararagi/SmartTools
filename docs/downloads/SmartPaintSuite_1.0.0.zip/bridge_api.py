# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Explicit, non-resident API for optional external paint bridges.

Importing this module registers no Blender classes, handlers, timers, keymaps,
or workers. All record identities are 0-based raw PSD layer-record indices.
"""

from __future__ import annotations

import hashlib
import time
import uuid
from pathlib import Path
from typing import Any

import bpy

from . import resource_quota, runtime_registry
from .mvp import paint_target, state


API_VERSION = 2
CHANNEL = "BASE_COLOR"
PAYLOAD_DTYPE = "<f4"
PAYLOAD_ORDER = "PSD_TOP_DOWN_RGBA"

__all__ = (
    "API_VERSION",
    "CHANNEL",
    "PAYLOAD_DTYPE",
    "PAYLOAD_ORDER",
    "document_snapshot",
    "resolve_record_canvas",
    "psd_rect_to_blender",
    "blender_rect_to_psd",
    "apply_external_batch",
    "external_batch_matches_current",
    "invalidate_external_import_token",
    "cleanup_retired_external_images",
    "apply_external_patch",
    "collect_local_patches",
    "prime_local_push_baseline",
    "mark_pushed",
    "conflict_snapshot",
    "clear_conflicts",
    "clear_runtime_state",
)

# All bridge metadata caches participate in the Suite-wide count+real-byte LRU.
# Keys and values are data-only; no Blender RNA/Image/module/callable is retained.
_APPLIED_IMPORT_TOKENS = resource_quota.cache("bridge.applied_import_tokens")
_COLLECTIONS = resource_quota.cache("bridge.local_collections")
_PUSHED_TOKENS = resource_quota.cache("bridge.pushed_tokens")
_CONFLICTS = resource_quota.cache("bridge.conflicts")
_FINGERPRINT_CACHE = resource_quota.cache("bridge.file_fingerprints")
_RETIRED_IMPORT_IMAGES = resource_quota.cache("bridge.retired_import_images")
_IMPORT_REFRESH_SKIP_REPAIR_IMAGES: set[int] = set()
_MAX_CONFLICTS_PER_DOCUMENT = 128
_SUITE_IMAGE_SCHEMA = 1


def _trace(event: str, *, material=None, **payload) -> None:
    try:
        from . import save_trace

        save_trace.emit(str(event or ""), material=material, channel=CHANNEL, **payload)
    except Exception:
        pass

def _refresh_display_after_external_import(material, context=None) -> dict[str, Any]:
    """Rebind only the currently requested display after an external rebase."""
    started = time.perf_counter()
    ctx = context or getattr(bpy, "context", None)
    try:
        mode = str(material.get("sps_lightweight_display_mode", "ACTIVE_LAYER") or "ACTIVE_LAYER")
    except Exception:
        mode = "ACTIVE_LAYER"
    result: dict[str, Any] = {
        "ok": True,
        "mode": mode,
        "reason": "display_redraw_tagged",
    }
    try:
        from . import lightweight_mvp

        if mode == "LIVE_COMPOSITE":
            refreshed = lightweight_mvp._refresh_live_composite_if_enabled(material, ctx)
            result.update({
                "ok": bool(isinstance(refreshed, dict) and refreshed.get("ok", False)),
                "reason": str(
                    (refreshed or {}).get("reason", "live_composite_refresh_failed")
                    if isinstance(refreshed, dict)
                    else "live_composite_refresh_failed"
                ),
            })
        elif mode == "COMPOSITE_PREVIEW":
            image, refreshed = lightweight_mvp._build_current_psd_composite_preview(
                material,
                force=True,
            )
            preview_ok = bool(
                image is not None
                and isinstance(refreshed, dict)
                and refreshed.get("ok", False)
                and lightweight_mvp._bind_manual_composite_display(material, image, ctx)
            )
            if preview_ok:
                lightweight_mvp._ensure_material_display_shading(ctx)
                lightweight_mvp._tag_redraw(ctx)
            else:
                lightweight_mvp._restore_active_layer_display(material, ctx)
            result.update({
                "ok": preview_ok,
                "reason": str(
                    (refreshed or {}).get("reason", "composite_preview_refresh_failed")
                    if isinstance(refreshed, dict)
                    else "composite_preview_refresh_failed"
                ),
            })
        else:
            paint = getattr(getattr(ctx, "tool_settings", None), "image_paint", None)
            canvas = getattr(paint, "canvas", None) if paint is not None else None
            rebound = bool(
                canvas is not None
                and lightweight_mvp._bind_active_layer_display(material, canvas, ctx)
            )
            if not rebound:
                material.update_tag()
                tree = getattr(material, "node_tree", None)
                if tree is not None:
                    tree.update_tag()
                lightweight_mvp._tag_redraw(ctx)
            result.update({
                "ok": bool(rebound or canvas is None),
                "reason": "active_layer_rebound" if rebound else "display_redraw_tagged",
            })
    except Exception as exc:
        result.update({
            "ok": False,
            "reason": "display_refresh_exception",
            "error": repr(exc)[:256],
        })
    result["elapsed_ms"] = round((time.perf_counter() - started) * 1000.0, 3)
    _trace("bridge_api_external_display_refreshed", material=material, **result)
    return result

def _bounded_put(mapping, key, value) -> None:
    """Insert metadata into the Suite-wide byte/count bounded LRU."""
    try:
        mapping[key] = value
    except resource_quota.CachePolicyError:
        # A metadata cache must never retain a value that breaches the shared
        # budget.  Clear only this namespace and leave the core operation valid.
        mapping.clear()


def _material(context=None):
    ctx = context or getattr(bpy, "context", None)
    candidates = []
    try:
        candidates.append(getattr(getattr(ctx, "object", None), "active_material", None))
    except Exception:
        pass
    try:
        active = getattr(getattr(ctx, "view_layer", None), "objects", None)
        candidates.append(getattr(getattr(active, "active", None), "active_material", None))
    except Exception:
        pass
    for material in candidates:
        settings = getattr(material, "smart_paint_suite", None) if material is not None else None
        if settings is not None and len(getattr(settings, "layers", ()) or ()):
            return material
    matches = []
    for material in getattr(bpy.data, "materials", ()):
        settings = getattr(material, "smart_paint_suite", None)
        if settings is not None and len(getattr(settings, "layers", ()) or ()):
            matches.append(material)
    return matches[0] if len(matches) == 1 else None


def _source_path(material) -> str:
    try:
        from . import lightweight_mvp

        value = str(lightweight_mvp._session_source_path(material) or "")
        if value:
            return value
        return str(lightweight_mvp._source_path(material) or "")
    except Exception:
        return ""


def _record_row(material, record_index: int):
    try:
        record = int(record_index)
    except Exception:
        return -1, None
    if record < 0:
        return -1, None
    settings = getattr(material, "smart_paint_suite", None)
    rows = getattr(settings, "layers", ()) if settings is not None else ()
    matches = []
    for index, layer in enumerate(rows or ()):
        try:
            if int(getattr(layer, "psd_source_record_index", -1)) == record:
                matches.append((int(index), layer))
        except Exception:
            continue
    return matches[0] if len(matches) == 1 else (-1, None)


def _pixel_editable(layer) -> bool:
    return str(getattr(layer, "layer_kind", "") or "").upper() == "PAINT"


def _layer_id(layer, row_index: int) -> str:
    value = str(getattr(layer, "layer_id", "") or "")
    return value or f"layer_{int(row_index) + 1}"


def _file_fingerprint(path: str) -> dict[str, Any]:
    source = Path(path)
    stat = source.stat()
    key = (str(source.resolve()), int(stat.st_size), int(stat.st_mtime_ns))
    digest = _FINGERPRINT_CACHE.get(key)
    if not digest:
        hasher = hashlib.sha256()
        with source.open("rb") as handle:
            for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b""):
                hasher.update(chunk)
        digest = hasher.hexdigest()
        _FINGERPRINT_CACHE.clear()
        _FINGERPRINT_CACHE[key] = digest
    return {
        "path": key[0],
        "size": key[1],
        "mtime_ns": key[2],
        "sha256": digest,
        "generation": f"{key[1]}:{key[2]}:{digest}",
    }


def _document_key(material) -> str:
    source = _source_path(material)
    if not source:
        return str(getattr(material, "name_full", "") or getattr(material, "name", "") or "")
    try:
        return str(Path(source).resolve())
    except Exception:
        return source


def _validate_expected_document(
    document: dict[str, Any],
    expected_document_key: str,
    expected_generation: str,
) -> dict[str, Any] | None:
    expected_key = str(expected_document_key or "").strip()
    expected_gen = str(expected_generation or "").strip()
    if not expected_key or not expected_gen:
        return {
            "ok": False,
            "reason": "document_identity_required",
            "document_key": str(document.get("document_key", "") or ""),
            "generation": str(document.get("generation", "") or ""),
        }
    actual_key = str(document.get("document_key", "") or "")
    actual_gen = str(document.get("generation", "") or "")
    if expected_key != actual_key:
        return {
            "ok": False,
            "reason": "document_mismatch",
            "expected_document_key": expected_key,
            "document_key": actual_key,
        }
    if expected_gen != actual_gen:
        return {
            "ok": False,
            "reason": "stale_generation",
            "expected_generation": expected_gen,
            "generation": actual_gen,
            "document_key": actual_key,
        }
    return None


def _document_size(material) -> tuple[int, int]:
    settings = getattr(material, "smart_paint_suite", None)
    for layer in getattr(settings, "layers", ()) or ():
        image = bpy.data.images.get(str(getattr(layer, "base_color_image", "") or ""))
        if image is None:
            continue
        try:
            width = int(image.get("smart_paint_suite_lazy_width", 0) or image.size[0])
            height = int(image.get("smart_paint_suite_lazy_height", 0) or image.size[1])
            if width > 1 and height > 1:
                return width, height
        except Exception:
            pass
    return 0, 0


def ensure_visible_paint_target(context=None) -> dict[str, Any]:
    """Keep external applications on a visible, pixel-editable PSD row."""
    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    try:
        from . import lightweight_mvp

        ready = lightweight_mvp._ensure_layered_document_ready(
            material,
            context or bpy.context,
            reason="external_visible_target",
        )
    except Exception as exc:
        ready = {"ok": False, "reason": "source_recovery_exception", "error": repr(exc)[:384]}
    if not bool(ready.get("ok", False)):
        return ready
    settings = getattr(material, "smart_paint_suite", None)
    rows = getattr(settings, "layers", ()) if settings is not None else ()
    try:
        active_index = int(getattr(settings, "active_layer_index", -1))
    except Exception:
        active_index = -1

    def usable(index: int) -> bool:
        if index < 0 or index >= len(rows):
            return False
        row = rows[index]
        return bool(
            str(getattr(row, "layer_kind", "") or "").upper() == "PAINT"
            and not bool(getattr(row, "is_group", False))
            and bool(getattr(row, "enabled", True))
            and int(getattr(row, "psd_source_record_index", -1)) >= 0
        )

    if usable(active_index):
        row = rows[active_index]
        return {
            "ok": True,
            "reason": "active_target_visible",
            "changed": False,
            "active_layer_index": int(active_index),
            "active_record_index": int(
                getattr(row, "psd_source_record_index", -1)
            ),
            "active_layer_name": str(getattr(row, "name", "") or ""),
        }

    target_index = next(
        (
            index
            for index in range(len(rows) - 1, -1, -1)
            if usable(index)
        ),
        -1,
    )
    if target_index < 0:
        return {"ok": False, "reason": "visible_paint_target_missing"}
    try:
        from . import lightweight_mvp

        activation = lightweight_mvp.activate_layer(
            context or bpy.context,
            material,
            target_index,
        )
    except Exception as exc:
        return {
            "ok": False,
            "reason": "visible_paint_target_activation_exception",
            "error": repr(exc)[:384],
        }
    if not bool(activation.get("ok", False)):
        return {
            "ok": False,
            "reason": "visible_paint_target_activation_failed",
            "activation_reason": str(activation.get("reason", "") or ""),
        }
    row = rows[target_index]
    result = {
        "ok": True,
        "reason": "visible_paint_target_selected",
        "changed": True,
        "active_layer_index": int(target_index),
        "active_record_index": int(
            getattr(row, "psd_source_record_index", -1)
        ),
        "active_layer_name": str(getattr(row, "name", "") or ""),
    }
    _trace(
        "bridge_api_visible_paint_target_selected",
        material=material,
        **result,
    )
    return result


def document_snapshot(context=None) -> dict[str, Any]:
    """Return the explicit-open PSD identity and its addressable raw records.

    ``record_index`` values are 0-based raw PSD record identities. Names and
    UI row indices are diagnostic only and must never be used for matching.
    """
    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    try:
        from . import lightweight_mvp

        ready = lightweight_mvp._ensure_layered_document_ready(
            material,
            context or bpy.context,
            reason="external_document_snapshot",
        )
    except Exception as exc:
        ready = {"ok": False, "reason": "source_recovery_exception", "error": repr(exc)[:384]}
    if not bool(ready.get("ok", False)):
        return ready
    source = _source_path(material)
    if not source or not Path(source).is_file():
        return {"ok": False, "reason": "source_psd_missing", "path": source}
    fingerprint = _file_fingerprint(source)
    width, height = _document_size(material)
    if width <= 1 or height <= 1:
        return {
            "ok": False,
            "reason": "document_size_unresolved",
            "path": fingerprint["path"],
            "width": int(width),
            "height": int(height),
        }
    settings = getattr(material, "smart_paint_suite", None)
    records = []
    record_counts: dict[int, int] = {}
    for row_index, layer in enumerate(getattr(settings, "layers", ()) or ()):
        try:
            record_index = int(getattr(layer, "psd_source_record_index", -1))
        except Exception:
            record_index = -1
        if record_index < 0:
            continue
        try:
            original_name = str(layer.get("sps_psd_original_name", "") or "")
        except Exception:
            original_name = ""
        record_counts[record_index] = int(record_counts.get(record_index, 0)) + 1
        kind = str(getattr(layer, "layer_kind", "") or "")
        records.append({
            "record_index": record_index,
            "ui_row_index": int(row_index),
            "layer_id": _layer_id(layer, row_index),
            "name": original_name or str(getattr(layer, "name", "") or ""),
            "kind": kind,
            "pixel_editable": kind.upper() == "PAINT",
            "depth": int(getattr(layer, "group_depth", 0) or 0),
            "enabled": bool(getattr(layer, "enabled", True)),
        })
    records.sort(key=lambda item: int(item["record_index"]))
    try:
        active_index = int(getattr(settings, "active_layer_index", -1))
        active_layer = (
            settings.layers[active_index]
            if 0 <= active_index < len(settings.layers)
            else None
        )
    except Exception:
        active_index = -1
        active_layer = None
    try:
        active_original_name = str(
            active_layer.get("sps_psd_original_name", "") or ""
        ) if active_layer is not None else ""
    except Exception:
        active_original_name = ""
    active_record_index = int(
        getattr(active_layer, "psd_source_record_index", -1)
    ) if active_layer is not None else -1
    active_layer_name = active_original_name or (
        str(getattr(active_layer, "name", "") or "")
        if active_layer is not None
        else ""
    )
    active_enabled = bool(
        getattr(active_layer, "enabled", False)
    ) if active_layer is not None else False
    active_pixel_editable = bool(
        active_layer is not None
        and str(getattr(active_layer, "layer_kind", "") or "").upper()
        == "PAINT"
        and not bool(getattr(active_layer, "is_group", False))
    )
    duplicates = sorted(index for index, count in record_counts.items() if count != 1)
    if duplicates:
        result = {
            "ok": False,
            "reason": "ambiguous_record_identity",
            "document_key": _document_key(material),
            "material_name": str(getattr(material, "name_full", "") or material.name),
            "material_pointer": int(material.as_pointer()),
            "generation": fingerprint["generation"],
            "duplicate_record_indices": duplicates,
            "records": records,
        }
        _trace(
            "bridge_api_document_snapshot_rejected",
            material=material,
            reason=result["reason"],
            duplicate_record_indices=duplicates,
        )
        return result
    result = {
        "ok": True,
        "api_version": API_VERSION,
        "channel": CHANNEL,
        "path": fingerprint["path"],
        "document_key": _document_key(material),
        "material_name": str(getattr(material, "name_full", "") or material.name),
        "material_pointer": int(material.as_pointer()),
        "width": int(width),
        "height": int(height),
        "generation": fingerprint["generation"],
        "fingerprint": fingerprint,
        "records": records,
        "active_layer_index": int(active_index),
        "active_record_index": int(active_record_index),
        "active_layer_name": str(active_layer_name or ""),
        "active_enabled": bool(active_enabled),
        "active_pixel_editable": bool(active_pixel_editable),
    }
    _trace("bridge_api_document_snapshot", material=material, record_count=len(records))
    return result


def _rebind_record_canvas(material, layer, layer_id: str, record_index: int, image, context=None) -> None:
    """Repair exact record bindings after Blender memfile undo."""
    if image is None or layer is None:
        return
    try:
        from . import psd_io

        node = psd_io._ensure_layer_paint_node(material, layer_id, CHANNEL, image)
        if node is not None:
            node.image = image
    except Exception:
        pass
    try:
        layer.base_color_image = str(image.name)
    except Exception:
        pass
    settings = getattr(material, "smart_paint_suite", None)
    rows = getattr(settings, "layers", ()) if settings is not None else ()
    try:
        active_index = int(getattr(settings, "active_layer_index", -1))
        active_record = (
            int(getattr(rows[active_index], "psd_source_record_index", -1))
            if 0 <= active_index < len(rows)
            else -1
        )
    except Exception:
        active_record = -1
    if active_record != int(record_index):
        return
    try:
        ctx = context or bpy.context
        paint = getattr(getattr(ctx, "tool_settings", None), "image_paint", None)
        if paint is not None:
            paint.canvas = image
    except Exception:
        pass
    for key in (
        "sps_active_private_layer_image_BASE_COLOR",
        "sps_native_write_image_BASE_COLOR",
        "sps_v2_native_paint_target_image_BASE_COLOR",
        "sps_lightweight_active_image",
    ):
        try:
            material[key] = str(image.name)
        except Exception:
            pass
    try:
        material["sps_active_recording_layer_id_BASE_COLOR"] = str(layer_id or "")
        material["sps_v2_native_paint_target_layer_id_BASE_COLOR"] = str(layer_id or "")
    except Exception:
        pass


def _ensure_record_canvas(
    material,
    record_index: int,
    context=None,
    *,
    capture_u8: bool = False,
):
    row_index, layer = _record_row(material, record_index)
    if layer is None or not _pixel_editable(layer):
        return None
    layer_id = _layer_id(layer, row_index)
    _resolved_id, process_entry = state.find_layer(material, layer_id, int(record_index))
    process_entry = dict(process_entry or {})
    guards = list(process_entry.get("external_import_undo_guards") or [])
    image = state.matching_canvas(material, layer_id, int(record_index))
    if image is None:
        source_name = str(getattr(layer, "base_color_image", "") or "")
        source_image = bpy.data.images.get(source_name) if source_name else None
        source_path = paint_target._source_path(material, layer, source_image)
        image, _restored = paint_target._new_canvas(
            material, layer, layer_id, int(record_index), source_image, source_path
        )
        # If undo removed the staged datablock, rebuild it from the process-local
        # imported baseline instead of decoding the pre-import source record.
        payload_source = "current_payload"
        payload = process_entry.get(payload_source)
        if guards:
            import_baseline = process_entry.get("external_import_baseline_payload")
            if isinstance(import_baseline, tuple) and len(import_baseline) == 3:
                payload_source = "external_import_baseline_payload"
                payload = import_baseline
        if guards and isinstance(payload, tuple) and len(payload) == 3:
            try:
                import numpy as np

                width, height, pixels = payload
                if int(image.size[0]) == int(width) and int(image.size[1]) == int(height):
                    rgba = np.asarray(pixels, dtype=np.float32).reshape(
                        (int(height), int(width), 4)
                    ) * (1.0 / 255.0)
                    image.pixels.foreach_set(np.ascontiguousarray(rgba).reshape((-1,)))
                    image.update()
                    paint_target._stamp_canvas(
                        image, material, layer, layer_id, int(record_index), source_path
                    )
                    process_entry.update({
                        "layer_id": str(layer_id or ""),
                        "record_index": int(record_index),
                        "image": str(image.name),
                    })
                    state.put_layer(material, layer_id, process_entry)
                    _trace(
                        "bridge_api_import_undo_rehydrated",
                        material=material,
                        record_index=int(record_index),
                        layer_id=str(layer_id or ""),
                        image=str(getattr(image, "name", "") or ""),
                        payload_source=payload_source,
                    )
            except Exception:
                pass
    image_pointer = int(image.as_pointer()) if image is not None else 0
    skip_repair = image_pointer in _IMPORT_REFRESH_SKIP_REPAIR_IMAGES
    repair = (
        {
            "ok": True,
            "repaired": False,
            "reason": "staged_import_refresh",
            "payload_source": "current_payload",
        }
        if skip_repair
        else state.repair_external_import_baseline(
            material, layer_id, int(record_index), image
        )
    )
    repair_current = repair.pop("current_u8", None)
    if bool(repair.get("repaired", False)):
        _trace(
            "bridge_api_import_undo_repaired",
            material=material,
            record_index=int(record_index),
            layer_id=str(layer_id or ""),
            image=str(getattr(image, "name", "") or ""),
            rects=[list(rect) for rect in repair.get("rects", [])],
        )
    elif guards and not skip_repair:
        _trace(
            "bridge_api_import_undo_repair_probe",
            material=material,
            record_index=int(record_index),
            layer_id=str(layer_id or ""),
            image=str(getattr(image, "name", "") or ""),
            reason=str(repair.get("reason", "") or ""),
            ok=bool(repair.get("ok", False)),
            payload_source=str(repair.get("payload_source", "") or ""),
        )
    _rebind_record_canvas(material, layer, layer_id, int(record_index), image, context)
    entry = dict(state.get_layer(material, layer_id) or {})
    if entry.get("push_baseline_payload") is None:
        entry["push_baseline_payload"] = entry.get("baseline_payload")
        state.put_layer(material, layer_id, entry)
    if capture_u8:
        if repair_current is None:
            repair_current = _read_canvas_u8(image)
        return image, repair_current
    return image


def resolve_record_canvas(context, record_index: int):
    """Return or materialize one exact record canvas without making it active."""
    material = _material(context)
    if material is None:
        return None
    return _ensure_record_canvas(material, int(record_index), context)


def psd_rect_to_blender(rect_psd, document_height: int) -> tuple[int, int, int, int]:
    """Convert a PSD top-origin half-open rect to Blender bottom-origin space."""
    left, top, right, bottom = (int(value) for value in tuple(rect_psd)[:4])
    height = int(document_height)
    return left, height - bottom, right, height - top


def blender_rect_to_psd(rect_blender, document_height: int) -> tuple[int, int, int, int]:
    """Convert a Blender bottom-origin half-open rect to PSD top-origin space."""
    left, bottom, right, top = (int(value) for value in tuple(rect_blender)[:4])
    height = int(document_height)
    return left, height - top, right, height - bottom


def _valid_rect(rect, width: int, height: int) -> tuple[int, int, int, int] | None:
    try:
        x0, y0, x1, y1 = (int(value) for value in tuple(rect)[:4])
    except Exception:
        return None
    if x0 < 0 or y0 < 0 or x1 > int(width) or y1 > int(height):
        return None
    return (x0, y0, x1, y1) if x1 > x0 and y1 > y0 else None


def _rgba_array(rgba, width: int, height: int):
    import numpy as np

    if isinstance(rgba, (bytes, bytearray, memoryview)):
        values = np.frombuffer(rgba, dtype=np.dtype(PAYLOAD_DTYPE))
    else:
        values = np.asarray(rgba, dtype=np.float32)
    if values.size != int(width) * int(height) * 4:
        raise ValueError("RGBA payload size does not match rect")
    values = np.ascontiguousarray(values.reshape((int(height), int(width), 4)), dtype=np.float32)
    if not np.all(np.isfinite(values)) or float(values.min()) < 0.0 or float(values.max()) > 1.0:
        raise ValueError("RGBA payload must contain finite straight-alpha values in 0..1")
    return values


def _read_canvas_u8(image):
    import numpy as np

    width, height = int(image.size[0]), int(image.size[1])
    flat = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(flat)
    pixels = np.ascontiguousarray(
        np.clip(np.floor(flat.reshape((height, width, 4)) * 255.0 + 0.5), 0.0, 255.0),
        dtype=np.uint8,
    )
    return width, height, pixels


def _visible_changed(current, baseline):
    import numpy as np

    current16 = np.asarray(current, dtype=np.uint16)
    baseline16 = np.asarray(baseline, dtype=np.uint16)
    current_pm = (current16[:, :, :3] * current16[:, :, 3:4] + 127) // 255
    baseline_pm = (baseline16[:, :, :3] * baseline16[:, :, 3:4] + 127) // 255
    return np.any(current_pm != baseline_pm, axis=2) | (
        current16[:, :, 3] != baseline16[:, :, 3]
    )


def _rect_overlap(a, b) -> bool:
    ax0, ay0, ax1, ay1 = (int(value) for value in a)
    bx0, by0, bx1, by1 = (int(value) for value in b)
    return max(ax0, bx0) < min(ax1, bx1) and max(ay0, by0) < min(ay1, by1)


def _union_rects(rects) -> tuple[int, int, int, int] | None:
    values = [tuple(int(value) for value in rect[:4]) for rect in rects or () if rect]
    if not values:
        return None
    return (
        min(rect[0] for rect in values),
        min(rect[1] for rect in values),
        max(rect[2] for rect in values),
        max(rect[3] for rect in values),
    )


def _remember_conflict(document_key: str, conflict: dict[str, Any]) -> None:
    cache_key = str(document_key or "")
    values = list(_CONFLICTS.get(cache_key, ()) or ())
    identity = (
        int(conflict.get("record_index", -1)),
        tuple(conflict.get("local_rect_psd", ())),
        tuple(conflict.get("external_rect_psd", ())),
        str(conflict.get("token", "")),
        str(conflict.get("generation", "")),
    )
    for existing in values:
        existing_identity = (
            int(existing.get("record_index", -1)),
            tuple(existing.get("local_rect_psd", ())),
            tuple(existing.get("external_rect_psd", ())),
            str(existing.get("token", "")),
            str(existing.get("generation", "")),
        )
        if existing_identity == identity:
            return
    values.append(dict(conflict))
    values = values[-_MAX_CONFLICTS_PER_DOCUMENT:]
    _bounded_put(_CONFLICTS, cache_key, values)


def _entry_for_record(material, record_index: int, image=None):
    row_index, layer = _record_row(material, record_index)
    if layer is None:
        return "", None
    layer_id = _layer_id(layer, row_index)
    entry = dict(state.get_layer(material, layer_id) or {})
    if image is not None:
        entry["image"] = str(getattr(image, "name", "") or "")
    entry["layer_id"] = layer_id
    entry["record_index"] = int(record_index)
    return layer_id, entry


def _local_patch(
    material,
    record_index: int,
    *,
    include_payload: bool,
    materialize: bool = True,
    initialize_missing_baseline: bool = True,
    current_u8=None,
):
    import numpy as np

    row_index, layer = _record_row(material, int(record_index))
    if layer is None or not _pixel_editable(layer):
        return None
    layer_id = _layer_id(layer, row_index)
    image = (
        _ensure_record_canvas(material, int(record_index))
        if materialize
        else state.matching_canvas(material, layer_id, int(record_index))
    )
    if image is None:
        return None
    layer_id, entry = _entry_for_record(material, int(record_index), image)
    if current_u8 is None:
        width, height, current = _read_canvas_u8(image)
    else:
        width, height, current = current_u8
        width, height = int(width), int(height)
        current = np.asarray(current, dtype=np.uint8).reshape((height, width, 4))
        if (width, height) != (int(image.size[0]), int(image.size[1])):
            return None
    payload = entry.get("push_baseline_payload") or entry.get("baseline_payload")
    if payload is None:
        if initialize_missing_baseline:
            entry["push_baseline_payload"] = (width, height, current.copy())
            state.put_layer(material, layer_id, entry)
        return None
    base_width, base_height, baseline = payload
    if int(base_width) != width or int(base_height) != height:
        return None
    baseline = np.asarray(baseline, dtype=np.uint8).reshape((height, width, 4))
    if np.array_equal(current, baseline):
        return None
    changed = _visible_changed(current, baseline)
    ys, xs = np.nonzero(changed)
    if not xs.size:
        return None
    rect_blender = (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)
    x0, y0, x1, y1 = rect_blender
    rect_psd = blender_rect_to_psd(rect_blender, height)
    result = {
        "record_index": int(record_index),
        "layer_id": layer_id,
        "rect_psd": rect_psd,
        "rect_blender": rect_blender,
        "changed_pixels": int(changed.sum()),
        "width": x1 - x0,
        "height": y1 - y0,
        "dtype": PAYLOAD_DTYPE,
        "order": PAYLOAD_ORDER,
    }
    if include_payload:
        rgba = np.ascontiguousarray(current[y0:y1, x0:x1][::-1], dtype=np.float32) / 255.0
        result["rgba"] = rgba.astype(np.dtype(PAYLOAD_DTYPE), copy=False).tobytes()
        result["payload_sha256"] = hashlib.sha256(result["rgba"]).hexdigest()
    return result


def _tag_suite_import_image(
    image,
    *,
    generation: str,
    token: str,
    owner_generation: str = "",
) -> dict[str, str]:
    """Assign exact Suite/runtime/document ownership to a staged import Image."""
    image_uuid = str(uuid.uuid4())
    runtime_generation = str(
        owner_generation
        or runtime_registry.snapshot().get("generation", "")
        or generation
    )
    values = {
        "sps_suite_owner": resource_quota.SUITE_OWNER,
        "sps_suite_owner_uuid": resource_quota.SUITE_OWNER_UUID,
        "sps_suite_image_uuid": image_uuid,
        "sps_suite_runtime_generation": runtime_generation,
        "sps_suite_document_generation": str(generation),
        "sps_suite_import_token": str(token),
        "sps_suite_image_schema": _SUITE_IMAGE_SCHEMA,
        "sps_suite_owned_image": True,
        "sps_suite_canonical_source": False,
    }
    for key, value in values.items():
        image[key] = value
    return {key: str(value) for key, value in values.items()}



def _captured_suite_image_identity(image) -> dict[str, Any]:
    if image is None:
        return {}
    try:
        return {
            "name": str(image.name),
            "pointer": int(image.as_pointer()),
            "owner": str(image.get("sps_suite_owner", "") or ""),
            "owner_uuid": str(image.get("sps_suite_owner_uuid", "") or ""),
            "image_uuid": str(image.get("sps_suite_image_uuid", "") or ""),
            "runtime_generation": str(image.get("sps_suite_runtime_generation", "") or ""),
            "document_generation": str(image.get("sps_suite_document_generation", "") or ""),
            "schema": int(image.get("sps_suite_image_schema", -1) or -1),
            "owned": bool(image.get("sps_suite_owned_image", False)),
            "canonical": bool(image.get("sps_suite_canonical_source", False)),
            "source_file": str(image.get("smart_paint_suite_source_file", "") or ""),
            "layered_source": str(image.get("smart_paint_suite_layered_source_path", "") or ""),
            "master": bool(image.get("smart_paint_suite_master_texture", False)),
        }
    except (AttributeError, KeyError, TypeError, ValueError, ReferenceError):
        return {}


def _remove_retired_suite_image(image, captured: dict[str, Any]) -> bool:
    """Remove only the exact, unused Suite import Image captured pre-commit."""
    if image is None or not captured:
        return False
    try:
        current = _captured_suite_image_identity(image)
        exact = (
            current.get("pointer") == captured.get("pointer")
            and current.get("name") == captured.get("name")
            and current.get("owner") == resource_quota.SUITE_OWNER
            and current.get("owner_uuid") == resource_quota.SUITE_OWNER_UUID
            and current.get("owner_uuid") == captured.get("owner_uuid")
            and bool(current.get("image_uuid"))
            and current.get("image_uuid") == captured.get("image_uuid")
            and current.get("runtime_generation") == captured.get("runtime_generation")
            and current.get("document_generation") == captured.get("document_generation")
            and int(current.get("schema", -1)) == _SUITE_IMAGE_SCHEMA
            and bool(current.get("owned"))
            and not bool(current.get("canonical"))
            and not current.get("source_file")
            and not current.get("layered_source")
            and not bool(current.get("master"))
            and int(getattr(image, "users", 0) or 0) == 0
        )
        if not exact:
            return False
        bpy.data.images.remove(image)
        return True
    except (RuntimeError, ReferenceError, AttributeError, KeyError, TypeError, ValueError):
        return False



def cleanup_retired_external_images(
    *,
    document_key: str = "",
    token: str = "",
) -> dict[str, int]:
    """Finalize post-ACK image retirement using stored exact identities only."""
    target_document = str(document_key or "")
    target_token = str(token or "")
    removed = retained = examined = 0
    for key in tuple(_RETIRED_IMPORT_IMAGES.keys()):
        try:
            key_document, key_token = tuple(key)[:2]
        except (TypeError, ValueError, IndexError):
            _RETIRED_IMPORT_IMAGES.pop(key, None)
            continue
        if target_document and str(key_document) != target_document:
            continue
        if target_token and str(key_token) != target_token:
            continue
        rows = list(_RETIRED_IMPORT_IMAGES.get(key, ()) or ())
        keep: list[dict[str, Any]] = []
        for captured in rows:
            if not isinstance(captured, dict):
                continue
            examined += 1
            name = str(captured.get("name", "") or "")
            image = getattr(getattr(bpy, "data", None), "images", None)
            image = image.get(name) if image is not None and name else None
            if image is None:
                continue
            if _remove_retired_suite_image(image, captured):
                removed += 1
            else:
                keep.append(dict(captured))
                retained += 1
        if keep:
            _RETIRED_IMPORT_IMAGES.put(
                key,
                keep,
                document_generation=str(key_document or "global"),
            )
        else:
            _RETIRED_IMPORT_IMAGES.pop(key, None)
    return {"examined": examined, "removed": removed, "retained": retained}


def invalidate_external_import_token(document_key: str, token: str) -> bool:
    """Forget a token only after an ACK retry detects that Undo reverted data."""
    key = (str(document_key or ""), str(token or ""))
    existed = key in _APPLIED_IMPORT_TOKENS
    _APPLIED_IMPORT_TOKENS.pop(key, None)
    return bool(existed)


def clear_runtime_state(reason: str = "") -> dict[str, int]:
    """Clear bounded metadata and exact unused Suite import Images."""
    del reason
    retired = cleanup_retired_external_images()
    counts = {"retired_examined": retired["examined"], "retired_removed": retired["removed"]}
    for name, cache in (
        ("applied", _APPLIED_IMPORT_TOKENS),
        ("collections", _COLLECTIONS),
        ("pushed", _PUSHED_TOKENS),
        ("conflicts", _CONFLICTS),
        ("fingerprints", _FINGERPRINT_CACHE),
        ("retired", _RETIRED_IMPORT_IMAGES),
    ):
        counts[name] = len(cache)
        cache.clear()
    _IMPORT_REFRESH_SKIP_REPAIR_IMAGES.clear()
    removed = 0
    # Explicit disconnect/load/unregister boundary only.  Every candidate must
    # carry the complete Suite owner UUID and exact image UUID/generations.
    for image in tuple(getattr(getattr(bpy, "data", None), "images", ()) or ()):
        captured = _captured_suite_image_identity(image)
        if (
            captured.get("owner_uuid") == resource_quota.SUITE_OWNER_UUID
            and captured.get("image_uuid")
            and _remove_retired_suite_image(image, captured)
        ):
            removed += 1
    counts["unused_suite_images"] = removed
    return counts



def _rollback_external_import(material, paint, committed) -> list[int]:
    """Restore every binding/state mutation and remove staged Images."""
    failures: list[int] = []
    for canvas in reversed(list(committed or ())):
        record_index = int(canvas.get("record_index", -1))
        try:
            canvas["layer"].base_color_image = canvas.get("old_layer_image", "")
            canvas["node"].image = canvas.get("old_node_image")
            if canvas.get("paint_was_old") and paint is not None:
                paint.canvas = canvas.get("image")
            for key, value in dict(canvas.get("old_material_props", {}) or {}).items():
                if value is None:
                    if key in material:
                        del material[key]
                else:
                    material[key] = value
            if canvas.get("previous_entry") is None:
                state.remove_layer(material, canvas.get("layer_id", ""))
            else:
                state.put_layer(material, canvas.get("layer_id", ""), canvas["previous_entry"])
        except (RuntimeError, ReferenceError, AttributeError, KeyError, TypeError, ValueError):
            failures.append(record_index)
    for canvas in reversed(list(committed or ())):
        image = canvas.get("new_image")
        if image is None:
            continue
        try:
            bpy.data.images.remove(image)
        except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError):
            failures.append(int(canvas.get("record_index", -1)))
    return sorted({value for value in failures if value >= 0})


def apply_external_batch(
    context,
    patches,
    token: str,
    *,
    expected_document_key: str = "",
    expected_generation: str = "",
    owner_generation: str = "",
) -> dict[str, Any]:
    """Apply one immutable external result as an all-or-nothing canvas rebase.

    The expected document identity is mandatory. Payloads are staged into new
    byte-backed canvases, so native paint undo history tied to the old canvases
    cannot restore pre-import pixels. Nothing visible is rebound until every
    patch, canvas, overlap, baseline, and staged image has succeeded.
    """
    import numpy as np

    batch_started = time.perf_counter()
    phase_started = batch_started
    phase_ms: dict[str, float] = {}

    def _phase(name: str) -> None:
        nonlocal phase_started
        now = time.perf_counter()
        phase_ms[str(name)] = round((now - phase_started) * 1000.0, 3)
        phase_started = now

    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    import_token = str(token or "").strip()
    if not import_token:
        return {"ok": False, "reason": "import_token_required"}
    document = document_snapshot(context)
    if not document.get("ok"):
        return document
    identity_error = _validate_expected_document(
        document, expected_document_key, expected_generation
    )
    if identity_error is not None:
        return identity_error
    document_key = str(document["document_key"])
    generation = str(document["generation"])
    token_key = (document_key, import_token)
    if token_key in _APPLIED_IMPORT_TOKENS:
        return {
            "ok": True,
            "reason": "duplicate_token_noop",
            "token": import_token,
            "document_key": document_key,
            "generation": generation,
            "duplicate": True,
            "results": [],
        }
    try:
        raw_patches = list(patches or ())
    except Exception:
        raw_patches = []
    if not raw_patches:
        return {"ok": False, "reason": "patches_required", "token": import_token}
    _phase("document")

    doc_width = int(document["width"])
    doc_height = int(document["height"])
    record_map = {int(item["record_index"]): item for item in document["records"]}
    parsed = []
    total_values = 0
    for offset, item in enumerate(raw_patches):
        if not isinstance(item, dict):
            return {"ok": False, "reason": "patch_not_object", "patch_index": int(offset)}
        try:
            record_index = int(item.get("record_index", -1))
        except Exception:
            record_index = -1
        record = record_map.get(record_index)
        if record is None:
            return {
                "ok": False,
                "reason": "unknown_record",
                "record_index": record_index,
                "patch_index": int(offset),
            }
        if not bool(record.get("pixel_editable")):
            return {
                "ok": False,
                "reason": "record_not_pixel_editable",
                "record_index": record_index,
                "kind": str(record.get("kind", "")),
                "patch_index": int(offset),
            }
        rect_top = _valid_rect(item.get("rect_psd"), doc_width, doc_height)
        if rect_top is None:
            return {
                "ok": False,
                "reason": "rect_out_of_bounds",
                "record_index": record_index,
                "patch_index": int(offset),
            }
        rect_blender = psd_rect_to_blender(rect_top, doc_height)
        x0, y0, x1, y1 = rect_blender
        total_values += (x1 - x0) * (y1 - y0) * 4
        if total_values > doc_width * doc_height * 4 * 4:
            return {"ok": False, "reason": "batch_payload_budget_exceeded"}
        try:
            patch = _rgba_array(item.get("rgba"), x1 - x0, y1 - y0)
        except (TypeError, ValueError) as exc:
            result = {
                "ok": False,
                "reason": "invalid_rgba_payload",
                "record_index": record_index,
                "rect_psd": tuple(rect_top),
                "patch_index": int(offset),
                "error": str(exc),
            }
            _trace("bridge_api_external_batch_rejected", material=material, **result)
            return result
        parsed.append({
            "patch_index": int(offset),
            "record_index": record_index,
            "rect_psd": tuple(rect_top),
            "rect_blender": tuple(rect_blender),
            "rgba": patch,
        })
    _phase("parse")

    canvases: dict[int, dict[str, Any]] = {}
    record_canvases: dict[int, tuple[Any, tuple[int, int, Any]]] = {}
    try:
        from . import psd_io
    except Exception as exc:
        return {"ok": False, "reason": "paint_node_api_unavailable", "error": repr(exc)[:256]}
    for item in parsed:
        record_index = int(item["record_index"])
        resolved = record_canvases.get(record_index)
        if resolved is None:
            captured = _ensure_record_canvas(
                material,
                record_index,
                capture_u8=True,
            )
            if captured is None:
                image, current_read = None, None
            else:
                image, current_read = captured
                record_canvases[record_index] = (image, current_read)
        else:
            image, current_read = resolved
        if image is None:
            return {"ok": False, "reason": "record_canvas_not_found", "record_index": record_index}
        if bool(getattr(image, "is_float", False)):
            return {"ok": False, "reason": "float_canvas_unsupported", "record_index": record_index}
        width, height = int(image.size[0]), int(image.size[1])
        if (width, height) != (doc_width, doc_height):
            return {
                "ok": False,
                "reason": "record_canvas_size_mismatch",
                "record_index": record_index,
                "size": (width, height),
                "document_size": (doc_width, doc_height),
            }
        image_key = int(image.as_pointer())
        local = _local_patch(
            material,
            record_index,
            include_payload=False,
            materialize=False,
            initialize_missing_baseline=False,
            current_u8=current_read,
        )
        if local is not None and _rect_overlap(local["rect_blender"], item["rect_blender"]):
            conflict = {
                "record_index": record_index,
                "local_rect_psd": tuple(local["rect_psd"]),
                "external_rect_psd": tuple(item["rect_psd"]),
                "token": import_token,
                "generation": generation,
            }
            _remember_conflict(document_key, conflict)
            _trace("bridge_api_import_conflict", material=material, **conflict)
            return {"ok": False, "reason": "same_record_rect_overlap", "conflict": conflict}
        canvas = canvases.get(image_key)
        if canvas is None:
            row_index, layer = _record_row(material, record_index)
            layer_id = _layer_id(layer, row_index) if layer is not None else ""
            if not layer_id:
                return {"ok": False, "reason": "layer_identity_missing", "record_index": record_index}
            node = psd_io._ensure_layer_paint_node(material, layer_id, CHANNEL, image)
            if node is None:
                return {"ok": False, "reason": "paint_node_missing", "record_index": record_index}
            _w, _h, before = current_read
            previous_entry = state.get_layer(material, layer_id)
            canvas = {
                "image": image,
                "old_image_identity": _captured_suite_image_identity(image),
                "node": node,
                "layer": layer,
                "layer_id": layer_id,
                "record_index": record_index,
                "width": width,
                "height": height,
                "before": before,
                "planned": before.copy(),
                "previous_entry": dict(previous_entry) if previous_entry is not None else None,
                "items": [],
            }
            canvases[image_key] = canvas
        elif int(canvas["record_index"]) != record_index:
            return {"ok": False, "reason": "records_share_canvas", "record_index": record_index}
        x0, y0, x1, y1 = item["rect_blender"]
        # Intra-record overlap is explicitly list-order last-wins.
        canvas["planned"][y0:y1, x0:x1] = np.ascontiguousarray(
            np.clip(np.floor(item["rgba"][::-1] * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        canvas["items"].append(item)
    _phase("canvas_prepare")

    staged = []
    staged_images = []
    try:
        for canvas in canvases.values():
            old_image = canvas["image"]
            # Image.copy() can retain lazy generated backing storage. After a
            # later Texture Paint/live-display bind Blender may expose that
            # stale backing again, silently discarding the imported pixels.
            # Allocate an independent native canvas and configure every
            # storage-affecting property before the final pixel upload.
            new_image = bpy.data.images.new(
                name=f"{old_image.name}_IMPORT_{import_token[:8]}",
                width=int(canvas["width"]),
                height=int(canvas["height"]),
                alpha=True,
                float_buffer=False,
            )
            # Track the image immediately. Any later pixel, update, stamp, or
            # baseline exception must not leak a document-sized image.
            staged_images.append(new_image)
            try:
                new_image.generated_color = (1.0, 1.0, 1.0, 0.0)
                new_image.alpha_mode = "STRAIGHT"
                new_image.colorspace_settings.name = old_image.colorspace_settings.name
            except Exception:
                pass
            planned = np.ascontiguousarray(canvas["planned"], dtype=np.uint8)
            display_pixels = np.ascontiguousarray(
                planned.astype(np.float32) * (1.0 / 255.0),
                dtype=np.float32,
            )
            new_image.pixels.foreach_set(display_pixels.reshape((-1,)))
            del display_pixels
            new_image.update()
            paint_target._stamp_canvas(
                new_image,
                material,
                canvas["layer"],
                canvas["layer_id"],
                canvas["record_index"],
                paint_target._source_path(material, canvas["layer"], old_image),
            )
            _tag_suite_import_image(
                new_image, generation=generation, token=import_token
            )
            new_image["sps_bridge_external_import_authoritative"] = True
            new_image["sps_bridge_external_import_token"] = import_token
            layer_id, entry = _entry_for_record(
                material, canvas["record_index"], new_image
            )
            # Full Review is anchored to the PSD's saved merged preview. Keep
            # its original layer baseline while save/conflict baselines advance.
            preview_payload = entry.get("preview_baseline_payload")
            preview_valid = bool(
                isinstance(preview_payload, tuple)
                and len(preview_payload) == 3
                and int(preview_payload[0]) == int(canvas["width"])
                and int(preview_payload[1]) == int(canvas["height"])
            )
            if not preview_valid:
                source_payload = entry.get("baseline_payload")
                source_valid = bool(
                    isinstance(source_payload, tuple)
                    and len(source_payload) == 3
                    and int(source_payload[0]) == int(canvas["width"])
                    and int(source_payload[1]) == int(canvas["height"])
                )
                entry["preview_baseline_payload"] = (
                    source_payload
                    if source_valid
                    else (
                        canvas["width"],
                        canvas["height"],
                        np.asarray(canvas["before"], dtype=np.uint8).copy(),
                    )
                )
            baseline_copies = {}
            for key in ("baseline_payload", "push_baseline_payload"):
                existing = entry.get(key) or entry.get("baseline_payload")
                if existing is None or int(existing[0]) != canvas["width"] or int(existing[1]) != canvas["height"]:
                    source_pixels = canvas["before"]
                else:
                    source_pixels = existing[2]
                source_key = id(source_pixels)
                baseline = baseline_copies.get(source_key)
                if baseline is None:
                    baseline = np.asarray(source_pixels, dtype=np.uint8).reshape(
                        (canvas["height"], canvas["width"], 4)
                    ).copy()
                    for patch in canvas["items"]:
                        x0, y0, x1, y1 = patch["rect_blender"]
                        baseline[y0:y1, x0:x1] = planned[y0:y1, x0:x1]
                    baseline_copies[source_key] = baseline
                entry[key] = (canvas["width"], canvas["height"], baseline)
            # Keep the external-import lower undo baseline independent from
            # current_payload. Native paint snapshots legitimately advance
            # current_payload, but one subsequent Blender undo must still land
            # on the imported bytes rather than the pre-import canvas. This is
            # an alias of the exact baseline array, not another 4K allocation.
            entry["external_import_baseline_payload"] = entry.get("baseline_payload")
            dirty_rects = list(entry.get("external_dirty_rects") or [])
            undo_guards = [
                dict(value)
                for value in list(entry.get("external_import_undo_guards") or [])
                if isinstance(value, dict)
            ]
            for patch in canvas["items"]:
                x0, y0, x1, y1 = patch["rect_blender"]
                before_region = np.ascontiguousarray(
                    canvas["before"][y0:y1, x0:x1], dtype=np.uint8
                )
                after_region = np.ascontiguousarray(
                    planned[y0:y1, x0:x1], dtype=np.uint8
                )
                changed_y, changed_x = np.nonzero(
                    np.any(before_region != after_region, axis=2)
                )
                if not changed_x.size:
                    patch["_changed_pixels"] = 0
                    continue
                local_x0 = int(changed_x.min())
                local_y0 = int(changed_y.min())
                local_x1 = int(changed_x.max()) + 1
                local_y1 = int(changed_y.max()) + 1
                guard_rect = (
                    int(x0 + local_x0),
                    int(y0 + local_y0),
                    int(x0 + local_x1),
                    int(y0 + local_y1),
                )
                before_guard = np.ascontiguousarray(
                    before_region[local_y0:local_y1, local_x0:local_x1],
                    dtype=np.uint8,
                )
                after_guard = np.ascontiguousarray(
                    after_region[local_y0:local_y1, local_x0:local_x1],
                    dtype=np.uint8,
                )
                before_hash = hashlib.sha256(before_guard.tobytes()).hexdigest()
                after_hash = hashlib.sha256(after_guard.tobytes()).hexdigest()
                patch["_changed_pixels"] = int(
                    _visible_changed(after_guard, before_guard).sum()
                )
                changed_positions = np.flatnonzero(
                    np.any(before_guard != after_guard, axis=2)
                )
                probe_values = []
                if changed_positions.size:
                    selected = np.linspace(
                        0,
                        changed_positions.size - 1,
                        num=min(8, int(changed_positions.size)),
                        dtype=np.intp,
                    )
                    region_width = int(local_x1 - local_x0)
                    for position in changed_positions[selected]:
                        py, px = divmod(int(position), region_width)
                        probe_values.append([
                            int(px),
                            int(py),
                            *[int(value) for value in before_guard[py, px]],
                        ])
                guard = {
                    "record_index": int(canvas["record_index"]),
                    "rect_blender": guard_rect,
                    "before_sha256": before_hash,
                    "after_sha256": after_hash,
                    "before_probes": probe_values,
                    "token": import_token,
                }
                dirty_rects.append(guard_rect)
                identity = (guard["rect_blender"], before_hash, after_hash)
                undo_guards = [
                    old for old in undo_guards
                    if (
                        tuple(old.get("rect_blender", ())),
                        str(old.get("before_sha256", "") or ""),
                        str(old.get("after_sha256", "") or ""),
                    ) != identity
                ]
                undo_guards.append(guard)
            undo_guards = undo_guards[-128:]
            import_baseline = entry.get("external_import_baseline_payload")
            if isinstance(import_baseline, tuple) and len(import_baseline) == 3:
                baseline_pixels = np.asarray(import_baseline[2], dtype=np.uint8).reshape(
                    (canvas["height"], canvas["width"], 4)
                )
                for guard in undo_guards:
                    try:
                        gx0, gy0, gx1, gy1 = (
                            int(value) for value in tuple(guard.get("rect_blender", ()))[:4]
                        )
                    except Exception:
                        continue
                    if (
                        gx0 < 0 or gy0 < 0
                        or gx1 > canvas["width"] or gy1 > canvas["height"]
                        or gx1 <= gx0 or gy1 <= gy0
                    ):
                        continue
                    restore_region = np.ascontiguousarray(
                        baseline_pixels[gy0:gy1, gx0:gx1], dtype=np.uint8
                    )
                    guard["restore_sha256"] = hashlib.sha256(
                        restore_region.tobytes()
                    ).hexdigest()
            entry.update({
                "image": str(new_image.name),
                "external_dirty_rects": dirty_rects,
                "external_import_token": import_token,
                "external_import_generation": generation,
                "external_import_undo_guards": undo_guards,
                "current_payload": (canvas["width"], canvas["height"], planned),
                "baseline_exact": True,
            })
            canvas.update({"new_image": new_image, "planned": planned, "entry": entry})
            staged.append(canvas)
    except Exception as exc:
        for image in staged_images:
            try:
                bpy.data.images.remove(image)
            except Exception:
                pass
        result = {"ok": False, "reason": "batch_image_stage_failed", "error": repr(exc)[:256]}
        _trace("bridge_api_external_batch_rejected", material=material, **result)
        return result
    _phase("stage")

    paint = getattr(getattr(context or bpy.context, "tool_settings", None), "image_paint", None)
    material_props = (
        "sps_active_private_layer_image_BASE_COLOR",
        "sps_native_write_image_BASE_COLOR",
        "sps_v2_native_paint_target_image_BASE_COLOR",
        "sps_lightweight_active_image",
    )
    committed = []
    rollback_failures = []
    try:
        for canvas in staged:
            old_image = canvas["image"]
            new_image = canvas["new_image"]
            canvas["old_layer_image"] = str(getattr(canvas["layer"], "base_color_image", "") or "")
            canvas["old_node_image"] = getattr(canvas["node"], "image", None)
            canvas["paint_was_old"] = paint is not None and getattr(paint, "canvas", None) == old_image
            canvas["old_material_props"] = {
                key: material.get(key) if key in material else None for key in material_props
            }
            # Include the currently attempted record in rollback even when a
            # later binding/state operation raises after an earlier mutation.
            committed.append(canvas)
            canvas["layer"].base_color_image = str(new_image.name)
            canvas["node"].image = new_image
            if canvas["paint_was_old"]:
                paint.canvas = new_image
            for key, value in canvas["old_material_props"].items():
                if str(value or "") == str(old_image.name):
                    material[key] = str(new_image.name)
            state.put_layer(material, canvas["layer_id"], canvas["entry"])
    except (RuntimeError, ReferenceError, AttributeError, KeyError, TypeError, ValueError) as exc:
        rollback_failures.extend(_rollback_external_import(material, paint, committed))
        # Images staged after the failing record were never rebound; remove them
        # separately so a partial commit cannot leak document-sized datablocks.
        for canvas in staged:
            if canvas in committed:
                continue
            try:
                bpy.data.images.remove(canvas["new_image"])
            except (RuntimeError, ReferenceError, AttributeError, TypeError, ValueError):
                rollback_failures.append(int(canvas["record_index"]))
        result = {
            "ok": False,
            "reason": "batch_commit_failed",
            "error": repr(exc)[:256],
            "rollback_failed_records": sorted(set(rollback_failures)),
        }
        _trace("bridge_api_external_batch_rejected", material=material, **result)
        return result
    _phase("commit")

    results = []
    for canvas in staged:
        for item in canvas["items"]:
            x0, y0, x1, y1 = item["rect_blender"]
            results.append({
                "record_index": int(item["record_index"]),
                "rect_psd": tuple(item["rect_psd"]),
                "rect_blender": tuple(item["rect_blender"]),
                "changed_pixels": int(item.get("_changed_pixels", 0) or 0),
                "image": str(canvas["new_image"].name),
            })
    results.sort(key=lambda item: (int(item["record_index"]), tuple(item["rect_psd"])))
    _phase("results")
    refresh_images = {
        int(canvas["new_image"].as_pointer()) for canvas in staged
    }
    _IMPORT_REFRESH_SKIP_REPAIR_IMAGES.update(refresh_images)
    try:
        display_sync = _refresh_display_after_external_import(material, context)
    except (RuntimeError, ReferenceError, AttributeError, KeyError, TypeError, ValueError) as exc:
        display_sync = {"ok": False, "reason": "display_refresh_exception", "error": repr(exc)[:256]}
    finally:
        _IMPORT_REFRESH_SKIP_REPAIR_IMAGES.difference_update(refresh_images)
    _phase("display")
    if not bool(display_sync.get("ok", False)):
        rollback_failures = _rollback_external_import(material, paint, committed)
        # Rebind the restored old canvas/display on a best-effort path; the
        # transaction remains failed regardless of this diagnostic refresh.
        try:
            _refresh_display_after_external_import(material, context)
        except (RuntimeError, ReferenceError, AttributeError, KeyError, TypeError, ValueError):
            pass
        result = {
            "ok": False,
            "reason": "batch_display_commit_failed",
            "display_sync": display_sync,
            "rollback_failed_records": rollback_failures,
        }
        _trace("bridge_api_external_batch_rejected", material=material, **result)
        return result

    retired_rows = [
        dict(canvas.get("old_image_identity", {}) or {})
        for canvas in staged
        if dict(canvas.get("old_image_identity", {}) or {}).get("image_uuid")
    ]
    if retired_rows:
        _RETIRED_IMPORT_IMAGES.put(
            token_key, retired_rows, document_generation=generation
        )
    _APPLIED_IMPORT_TOKENS.put(
        token_key, {"committed": True, "token": import_token},
        document_generation=generation,
    )
    result = {
        "ok": True,
        "reason": "batch_applied",
        "duplicate": False,
        "token": import_token,
        "document_key": document_key,
        "generation": generation,
        "results": results,
        "record_count": len({int(item["record_index"]) for item in results}),
        "patch_count": len(results),
        "display_sync": display_sync,
        "retired_suite_images": 0,
        "retired_suite_images_deferred": len(retired_rows),
    }
    _trace(
        "bridge_api_external_batch_applied",
        material=material,
        token=import_token,
        document_key=document_key,
        generation=generation,
        record_count=result["record_count"],
        patch_count=result["patch_count"],
        display_mode=str(display_sync.get("mode", "") or ""),
        display_ok=bool(display_sync.get("ok", False)),
        display_elapsed_ms=float(display_sync.get("elapsed_ms", 0.0) or 0.0),
        phase_ms=dict(phase_ms),
        elapsed_ms=round((time.perf_counter() - batch_started) * 1000.0, 3),
    )
    return result


def apply_external_patch(
    context,
    record_index: int,
    rect_psd,
    rgba,
    token: str,
    *,
    expected_document_key: str = "",
    expected_generation: str = "",
) -> dict[str, Any]:
    """Compatibility wrapper for one external patch."""
    result = apply_external_batch(
        context,
        [{"record_index": int(record_index), "rect_psd": rect_psd, "rgba": rgba}],
        token,
        expected_document_key=expected_document_key,
        expected_generation=expected_generation,
    )
    if not result.get("ok"):
        if result.get("reason") == "unknown_record":
            result = dict(result)
            result["reason"] = "record_canvas_not_found"
        return result
    if result.get("duplicate"):
        return result
    item = dict(result["results"][0])
    item.update({
        "ok": True,
        "reason": "applied",
        "duplicate": False,
        "token": str(token or ""),
    })
    _trace("bridge_api_external_patch_applied", material=_material(context), **item)
    return item


def external_batch_matches_current(
    context,
    patches,
    *,
    expected_document_key: str = "",
    expected_generation: str = "",
) -> dict[str, Any]:
    """Check an external batch without replacing canvases or display bindings."""
    import numpy as np

    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    document = document_snapshot(context)
    if not document.get("ok"):
        return document
    identity_error = _validate_expected_document(
        document,
        expected_document_key,
        expected_generation,
    )
    if identity_error is not None:
        return identity_error
    try:
        raw_patches = list(patches or ())
    except Exception:
        raw_patches = []
    if not raw_patches:
        return {"ok": False, "reason": "patches_required"}

    width = int(document["width"])
    height = int(document["height"])
    record_map = {
        int(record["record_index"]): record for record in document["records"]
    }
    canvas_cache = {}
    compared_pixels = 0
    for offset, item in enumerate(raw_patches):
        if not isinstance(item, dict):
            return {
                "ok": False,
                "reason": "patch_not_object",
                "patch_index": int(offset),
            }
        try:
            record_index = int(item.get("record_index", -1))
        except Exception:
            record_index = -1
        record = record_map.get(record_index)
        if record is None:
            return {
                "ok": False,
                "reason": "unknown_record",
                "record_index": record_index,
                "patch_index": int(offset),
            }
        if not bool(record.get("pixel_editable")):
            return {
                "ok": False,
                "reason": "record_not_pixel_editable",
                "record_index": record_index,
                "patch_index": int(offset),
            }
        rect_psd = _valid_rect(item.get("rect_psd"), width, height)
        if rect_psd is None:
            return {
                "ok": False,
                "reason": "rect_out_of_bounds",
                "record_index": record_index,
                "patch_index": int(offset),
            }
        x0, y0, x1, y1 = psd_rect_to_blender(rect_psd, height)
        try:
            rgba = _rgba_array(item.get("rgba"), x1 - x0, y1 - y0)
        except (TypeError, ValueError) as exc:
            return {
                "ok": False,
                "reason": "invalid_rgba_payload",
                "record_index": record_index,
                "patch_index": int(offset),
                "error": str(exc),
            }
        current_read = canvas_cache.get(record_index)
        if current_read is None:
            captured = _ensure_record_canvas(
                material,
                record_index,
                capture_u8=True,
            )
            if captured is None:
                return {
                    "ok": False,
                    "reason": "record_canvas_not_found",
                    "record_index": record_index,
                }
            _image, current_read = captured
            canvas_cache[record_index] = current_read
        current_width, current_height, current = current_read
        if (int(current_width), int(current_height)) != (width, height):
            return {
                "ok": False,
                "reason": "record_canvas_size_mismatch",
                "record_index": record_index,
            }
        expected = np.ascontiguousarray(
            np.clip(np.floor(rgba[::-1] * 255.0 + 0.5), 0.0, 255.0),
            dtype=np.uint8,
        )
        compared_pixels += int((x1 - x0) * (y1 - y0))
        if not np.array_equal(current[y0:y1, x0:x1], expected):
            return {
                "ok": True,
                "reason": "pixel_mismatch",
                "matches": False,
                "record_index": record_index,
                "rect_psd": tuple(rect_psd),
                "compared_pixels": compared_pixels,
            }
    return {
        "ok": True,
        "reason": "exact_match",
        "matches": True,
        "compared_pixels": compared_pixels,
        "record_count": len(canvas_cache),
    }


def prime_local_push_baseline(
    context,
    record_index: int = -1,
    *,
    expected_document_key: str = "",
    expected_generation: str = "",
) -> dict[str, Any]:
    """Capture a pre-stroke baseline without scanning unrelated canvases."""
    started = time.perf_counter()
    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    snapshot = document_snapshot(context)
    if not snapshot.get("ok"):
        return snapshot
    identity_error = _validate_expected_document(
        snapshot,
        expected_document_key,
        expected_generation,
    )
    if identity_error is not None:
        return identity_error
    selected_record = int(record_index)
    if selected_record < 0:
        selected_record = int(snapshot.get("active_record_index", -1))
    record = next(
        (
            item
            for item in snapshot.get("records", ())
            if int(item.get("record_index", -1)) == selected_record
        ),
        None,
    )
    if record is None:
        return {
            "ok": False,
            "reason": "unknown_record",
            "record_index": selected_record,
        }
    if not bool(record.get("pixel_editable")):
        return {
            "ok": False,
            "reason": "record_not_pixel_editable",
            "record_index": selected_record,
        }
    image = _ensure_record_canvas(material, selected_record)
    if image is None:
        return {
            "ok": False,
            "reason": "record_canvas_not_found",
            "record_index": selected_record,
        }
    layer_id, entry = _entry_for_record(
        material,
        selected_record,
        image,
    )
    width = int(image.size[0])
    height = int(image.size[1])
    existing = (
        entry.get("push_baseline_payload")
        or entry.get("baseline_payload")
    )
    if (
        existing is not None
        and int(existing[0]) == width
        and int(existing[1]) == height
    ):
        return {
            "ok": True,
            "reason": "push_baseline_ready",
            "record_index": selected_record,
            "captured": False,
            "elapsed_ms": round(
                (time.perf_counter() - started) * 1000.0,
                3,
            ),
        }
    width, height, current = _read_canvas_u8(image)
    entry["push_baseline_payload"] = (width, height, current)
    state.put_layer(material, layer_id, entry)
    result = {
        "ok": True,
        "reason": "push_baseline_captured",
        "record_index": selected_record,
        "captured": True,
        "elapsed_ms": round(
            (time.perf_counter() - started) * 1000.0,
            3,
        ),
    }
    _trace("bridge_api_push_baseline_primed", material=material, **result)
    return result


def collect_local_patches(
    context,
    since_token: str = "",
    *,
    record_indices=None,
) -> dict[str, Any]:
    """Collect immutable changed-record payloads without materializing others.

    ``record_indices`` bounds connected live-sync work to the canvas that just
    received a stroke.  Omitting it preserves the explicit full-document API.
    """
    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    snapshot = document_snapshot(context)
    if not snapshot.get("ok"):
        return snapshot
    try:
        wanted_records = (
            {int(value) for value in record_indices}
            if record_indices is not None
            else None
        )
    except (TypeError, ValueError):
        return {"ok": False, "reason": "invalid_record_selection"}
    patches = []
    for record in snapshot["records"]:
        if not bool(record.get("pixel_editable")):
            continue
        if (
            wanted_records is not None
            and int(record["record_index"]) not in wanted_records
        ):
            continue
        patch = _local_patch(
            material,
            int(record["record_index"]),
            include_payload=True,
            materialize=False,
        )
        if patch is not None:
            patches.append(patch)
    digest = hashlib.sha256()
    document_key = str(snapshot["document_key"])
    digest.update(document_key.encode("utf-8"))
    digest.update(str(snapshot["generation"]).encode("utf-8"))
    for patch in patches:
        digest.update(str(patch["record_index"]).encode("ascii"))
        digest.update(str(tuple(patch["rect_psd"])).encode("ascii"))
        digest.update(str(patch.get("payload_sha256", "")).encode("ascii"))
    token = digest.hexdigest()
    stored_patches = [
        {key: value for key, value in patch.items() if key != "rgba"}
        for patch in patches
    ]
    collection = {
        "document_key": document_key,
        "generation": str(snapshot["generation"]),
        "patches": stored_patches,
    }
    collection_key = (document_key, token)
    _bounded_put(_COLLECTIONS, collection_key, collection)
    response_patches = [] if str(since_token or "") == token else patches
    result = {
        "ok": True,
        "reason": "ok",
        "token": token,
        "document_key": document_key,
        "generation": str(snapshot["generation"]),
        "patches": response_patches,
        "count": len(response_patches),
    }
    _trace(
        "bridge_api_local_patches_collected",
        material=material,
        token=token,
        record_indices=[int(item["record_index"]) for item in response_patches],
    )
    return result


def mark_pushed(
    context,
    token: str,
    records=None,
    rects=None,
    *,
    expected_document_key: str = "",
    expected_generation: str = "",
) -> dict[str, Any]:
    """Acknowledge an unchanged collection token and advance push baselines."""
    import numpy as np

    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    snapshot = document_snapshot(context)
    if not snapshot.get("ok"):
        return snapshot
    identity_error = _validate_expected_document(
        snapshot, expected_document_key, expected_generation
    )
    if identity_error is not None:
        return identity_error
    document_key = str(snapshot["document_key"])
    generation = str(snapshot["generation"])
    push_token = str(token or "").strip()
    collection_key = (document_key, push_token)
    collection = _COLLECTIONS.get(collection_key)
    if collection is None:
        return {"ok": False, "reason": "collection_token_unknown", "token": push_token}
    if str(collection.get("document_key", "")) != document_key:
        return {"ok": False, "reason": "document_mismatch", "token": push_token}
    if str(collection.get("generation", "")) != generation:
        return {
            "ok": False,
            "reason": "stale_generation",
            "token": push_token,
            "expected_generation": str(collection.get("generation", "")),
            "generation": generation,
        }
    try:
        requested_records = {int(value) for value in (records or [])}
        requested_rects = {
            (int(record), tuple(int(value) for value in rect[:4]))
            for record, rect in (rects or [])
        }
    except Exception:
        return {"ok": False, "reason": "invalid_ack_selection", "token": push_token}
    pushed_key = (document_key, push_token)
    already_acknowledged = set(_PUSHED_TOKENS.get(pushed_key) or ())
    selected = []
    for patch in collection.get("patches", []):
        record_index = int(patch["record_index"])
        rect_psd = tuple(int(value) for value in patch["rect_psd"])
        if requested_records and record_index not in requested_records:
            continue
        if requested_rects and (record_index, rect_psd) not in requested_rects:
            continue
        selected.append(((record_index, rect_psd), patch))
    if not selected:
        return {
            "ok": False,
            "reason": "no_matching_patches",
            "token": push_token,
            "acknowledged": [],
        }
    pending = [item for item in selected if item[0] not in already_acknowledged]
    if not pending:
        return {
            "ok": True,
            "reason": "duplicate_token_noop",
            "token": push_token,
            "duplicate": True,
            "acknowledged": [],
        }

    prepared = []
    stale = []
    for key, patch in pending:
        record_index = int(patch["record_index"])
        rect_psd = tuple(int(value) for value in patch["rect_psd"])
        image = _ensure_record_canvas(material, record_index)
        if image is None:
            stale.append(record_index)
            continue
        width, height, current = _read_canvas_u8(image)
        x0, y0, x1, y1 = tuple(int(value) for value in patch["rect_blender"])
        rgba = np.ascontiguousarray(current[y0:y1, x0:x1][::-1], dtype=np.float32) / 255.0
        payload_hash = hashlib.sha256(
            rgba.astype(np.dtype(PAYLOAD_DTYPE), copy=False).tobytes()
        ).hexdigest()
        if payload_hash != str(patch.get("payload_sha256", "")):
            stale.append(record_index)
            continue
        layer_id, entry = _entry_for_record(material, record_index, image)
        prepared.append((key, patch, layer_id, entry, width, height, current))
    if stale:
        return {
            "ok": False,
            "reason": "payload_changed_since_collection",
            "token": push_token,
            "acknowledged": [],
            "stale_records": sorted(set(stale)),
        }

    acknowledged = []
    for key, patch, layer_id, entry, width, height, current in prepared:
        record_index = int(patch["record_index"])
        rect_psd = tuple(int(value) for value in patch["rect_psd"])
        x0, y0, x1, y1 = tuple(int(value) for value in patch["rect_blender"])
        existing = entry.get("push_baseline_payload") or entry.get("baseline_payload")
        baseline = (
            np.asarray(existing[2], dtype=np.uint8).reshape((height, width, 4)).copy()
            if existing is not None and int(existing[0]) == width and int(existing[1]) == height
            else current.copy()
        )
        baseline[y0:y1, x0:x1] = current[y0:y1, x0:x1]
        entry["push_baseline_payload"] = (width, height, baseline)
        entry["last_push_token"] = push_token
        state.put_layer(material, layer_id, entry)
        acknowledged.append({"record_index": record_index, "rect_psd": rect_psd})
        already_acknowledged.add(key)
    _bounded_put(_PUSHED_TOKENS, pushed_key, already_acknowledged)
    result = {
        "ok": True,
        "reason": "acknowledged",
        "token": push_token,
        "document_key": document_key,
        "generation": generation,
        "duplicate": False,
        "acknowledged": acknowledged,
    }
    _trace("bridge_api_push_acknowledged", material=material, **result)
    return result


def conflict_snapshot(context=None) -> dict[str, Any]:
    """Return current local dirty rectangles and held external conflicts."""
    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    snapshot = document_snapshot(context)
    if not snapshot.get("ok"):
        return snapshot
    local = []
    for record in snapshot["records"]:
        if not bool(record.get("pixel_editable")):
            continue
        patch = _local_patch(
            material,
            int(record["record_index"]),
            include_payload=False,
            materialize=False,
        )
        if patch is not None:
            local.append({
                "record_index": int(patch["record_index"]),
                "rect_psd": tuple(patch["rect_psd"]),
                "changed_pixels": int(patch["changed_pixels"]),
            })
    document_key = str(snapshot["document_key"])
    generation = str(snapshot["generation"])
    conflicts = [
        item
        for item in _CONFLICTS.get(document_key, [])
        if str(item.get("generation", "")) == generation
    ]
    _CONFLICTS[document_key] = conflicts
    return {
        "ok": True,
        "document_key": document_key,
        "generation": generation,
        "local": local,
        "conflicts": list(conflicts),
    }


def clear_conflicts(context=None, *, token: str = "", records=None) -> dict[str, Any]:
    """Explicitly clear held conflicts for the current exact document."""
    material = _material(context)
    if material is None:
        return {"ok": False, "reason": "smart_paint_material_not_found"}
    snapshot = document_snapshot(context)
    if not snapshot.get("ok"):
        return snapshot
    document_key = str(snapshot["document_key"])
    generation = str(snapshot["generation"])
    wanted_token = str(token or "")
    try:
        wanted_records = {int(value) for value in (records or [])}
    except Exception:
        return {"ok": False, "reason": "invalid_conflict_selection"}
    before = list(_CONFLICTS.get(document_key, []))
    kept = []
    cleared = []
    for item in before:
        matches = str(item.get("generation", "")) == generation
        if wanted_token:
            matches = matches and str(item.get("token", "")) == wanted_token
        if wanted_records:
            matches = matches and int(item.get("record_index", -1)) in wanted_records
        (cleared if matches else kept).append(item)
    _CONFLICTS[document_key] = kept[-_MAX_CONFLICTS_PER_DOCUMENT:]
    return {
        "ok": True,
        "reason": "cleared",
        "document_key": document_key,
        "generation": generation,
        "cleared": len(cleared),
        "remaining": len(_CONFLICTS[document_key]),
    }
