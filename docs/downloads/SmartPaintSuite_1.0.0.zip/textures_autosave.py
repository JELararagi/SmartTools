# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Explicit-save preference adapter.

Smart Paint Suite does not install an idle autosave timer.  These callbacks only
record the requested policy; actual writes occur at explicit save boundaries.
"""
from __future__ import annotations
import bpy

def _store(owner) -> None:
    bpy.app.driver_namespace["SPS_TEXTURE_AUTOSAVE_POLICY"] = {
        "timer_enabled": bool(getattr(owner, "textures_autosave_timer_enabled", False)),
        "handler_enabled": bool(getattr(owner, "textures_autosave_handler_enabled", False)),
    }

def textures_autosave_timer_update(owner, _context):
    _store(owner)
    return None

def textures_autosave_handler_update(owner, _context):
    _store(owner)
    return None
