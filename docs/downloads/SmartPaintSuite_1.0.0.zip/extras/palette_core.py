# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Clean-room palette parsing and bounded color extraction helpers."""

from __future__ import annotations

import colorsys


def _srgb_channel_to_linear(value: float) -> float:
    value = min(1.0, max(0.0, float(value)))
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


def srgb8_to_linear(rgb) -> tuple[float, float, float]:
    values = tuple(int(value) for value in rgb)
    if len(values) != 3:
        raise ValueError("RGB requires exactly three values")
    return tuple(_srgb_channel_to_linear(value / 255.0) for value in values)


def _linear_channel_to_srgb(value: float) -> float:
    value = min(1.0, max(0.0, float(value)))
    if value <= 0.0031308:
        return value * 12.92
    return (1.055 * (value ** (1.0 / 2.4))) - 0.055


def harmony_colors_linear(rgb, mode: str) -> list[tuple[float, float, float]]:
    base = tuple(min(1.0, max(0.0, float(value))) for value in rgb)
    if len(base) != 3:
        raise ValueError("RGB requires exactly three values")
    srgb = tuple(_linear_channel_to_srgb(value) for value in base)
    hue, saturation, value = colorsys.rgb_to_hsv(*srgb)
    if saturation <= 1e-4:
        raise ValueError("color harmony requires a color with visible saturation")
    offsets = {
        "COMPLEMENTARY": (0.0, 0.5),
        "ANALOGOUS": (-1.0 / 12.0, 0.0, 1.0 / 12.0),
        "TRIADIC": (0.0, 1.0 / 3.0, 2.0 / 3.0),
        "SPLIT_COMPLEMENTARY": (0.0, 5.0 / 12.0, 7.0 / 12.0),
    }.get(str(mode or "").upper())
    if offsets is None:
        raise ValueError(f"unsupported harmony mode: {mode}")
    result = []
    for offset in offsets:
        if offset == 0.0:
            result.append(base)
            continue
        rotated = colorsys.hsv_to_rgb((hue + offset) % 1.0, saturation, value)
        result.append(tuple(_srgb_channel_to_linear(channel) for channel in rotated))
    return result


def parse_gpl(text: str, *, max_colors: int = 256) -> list[dict[str, object]]:
    lines = str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    first = next((line.strip() for line in lines if line.strip()), "")
    if first != "GIMP Palette":
        raise ValueError("missing GIMP Palette header")
    limit = max(1, min(int(max_colors), 4096))
    colors: list[dict[str, object]] = []
    for raw in lines[1:]:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        first_token = line.split(maxsplit=1)[0]
        if ":" in first_token:
            continue
        parts = line.split(maxsplit=3)
        if len(parts) < 3:
            continue
        try:
            rgb = tuple(int(parts[index], 10) for index in range(3))
        except ValueError:
            continue
        if any(value < 0 or value > 255 for value in rgb):
            continue
        name = parts[3].strip() if len(parts) > 3 else f"Color {len(colors) + 1}"
        colors.append({
            "name": name or f"Color {len(colors) + 1}",
            "srgb8": rgb,
            "linear": srgb8_to_linear(rgb),
        })
        if len(colors) >= limit:
            break
    if not colors:
        raise ValueError("palette contains no valid colors")
    return colors


def quantize_linear_rgba(
    pixels,
    *,
    max_colors: int = 16,
    alpha_threshold: float = 0.05,
    max_samples: int = 65536,
) -> list[dict[str, object]]:
    import numpy as np

    rgba = np.asarray(pixels, dtype=np.float32).reshape((-1, 4))
    if rgba.shape[0] > max(1, int(max_samples)):
        step = int(np.ceil(rgba.shape[0] / max(1, int(max_samples))))
        rgba = rgba[::step]
    rgba = rgba[np.isfinite(rgba).all(axis=1)]
    rgba = rgba[rgba[:, 3] >= float(alpha_threshold)]
    if rgba.size == 0:
        raise ValueError("image contains no visible colors")
    linear = np.clip(rgba[:, :3], 0.0, 1.0)
    srgb = np.where(
        linear <= 0.0031308,
        linear * 12.92,
        1.055 * np.power(linear, 1.0 / 2.4) - 0.055,
    )
    bins = np.clip(np.floor(srgb * 31.0 + 0.5), 0, 31).astype(np.int32)
    packed = bins[:, 0] | (bins[:, 1] << 5) | (bins[:, 2] << 10)
    unique, inverse, counts = np.unique(packed, return_inverse=True, return_counts=True)
    order = sorted(range(len(unique)), key=lambda index: (-int(counts[index]), int(unique[index])))
    colors: list[dict[str, object]] = []
    limit = max(1, min(int(max_colors), 256))
    for rank, bucket_index in enumerate(order[:limit]):
        average = linear[inverse == int(bucket_index)].mean(axis=0)
        colors.append({
            "name": f"Extracted {rank + 1}",
            "linear": tuple(float(value) for value in average),
            "count": int(counts[bucket_index]),
        })
    return colors


__all__ = (
    "harmony_colors_linear",
    "parse_gpl",
    "quantize_linear_rgba",
    "srgb8_to_linear",
)
