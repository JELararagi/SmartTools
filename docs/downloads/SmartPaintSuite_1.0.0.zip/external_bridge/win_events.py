# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Windows event-driven file/process lease for Smart Paint Suite.

The Connect lease blocks on native Windows objects only: cancellation,
``ReadDirectoryChangesW`` completion, the external application's process handle,
and one finite lease deadline.  There is no interval poll, heartbeat writer, or
periodic wakeup.  The directory/process handles remain owned until I/O is
cancelled, the wait thread joins, and the handles are closed.
"""
from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import threading
import time
from typing import Callable


class WinEventError(RuntimeError):
    pass


if os.name == "nt":
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    shell32 = ctypes.WinDLL("shell32", use_last_error=True)

    INVALID_HANDLE_VALUE = wintypes.HANDLE(-1).value
    FILE_LIST_DIRECTORY = 0x0001
    FILE_SHARE_READ = 0x00000001
    FILE_SHARE_WRITE = 0x00000002
    FILE_SHARE_DELETE = 0x00000004
    OPEN_EXISTING = 3
    FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
    FILE_FLAG_OVERLAPPED = 0x40000000
    FILE_NOTIFY_CHANGE_FILE_NAME = 0x00000001
    FILE_NOTIFY_CHANGE_SIZE = 0x00000008
    FILE_NOTIFY_CHANGE_LAST_WRITE = 0x00000010
    WAIT_OBJECT_0 = 0
    WAIT_TIMEOUT = 0x00000102
    WAIT_FAILED = 0xFFFFFFFF
    ERROR_OPERATION_ABORTED = 995
    SEE_MASK_NOCLOSEPROCESS = 0x00000040
    SW_SHOWNORMAL = 1

    class OVERLAPPED(ctypes.Structure):
        _fields_ = (
            ("Internal", ctypes.c_size_t),
            ("InternalHigh", ctypes.c_size_t),
            ("Offset", wintypes.DWORD),
            ("OffsetHigh", wintypes.DWORD),
            ("hEvent", wintypes.HANDLE),
        )

    class SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = (
            ("cbSize", wintypes.DWORD),
            ("fMask", wintypes.ULONG),
            ("hwnd", wintypes.HWND),
            ("lpVerb", wintypes.LPCWSTR),
            ("lpFile", wintypes.LPCWSTR),
            ("lpParameters", wintypes.LPCWSTR),
            ("lpDirectory", wintypes.LPCWSTR),
            ("nShow", ctypes.c_int),
            ("hInstApp", wintypes.HINSTANCE),
            ("lpIDList", wintypes.LPVOID),
            ("lpClass", wintypes.LPCWSTR),
            ("hkeyClass", wintypes.HANDLE),
            ("dwHotKey", wintypes.DWORD),
            ("hIconOrMonitor", wintypes.HANDLE),
            ("hProcess", wintypes.HANDLE),
        )

    kernel32.CreateFileW.argtypes = (
        wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
        wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE,
    )
    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.CreateEventW.argtypes = (wintypes.LPVOID, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR)
    kernel32.CreateEventW.restype = wintypes.HANDLE
    kernel32.SetEvent.argtypes = (wintypes.HANDLE,)
    kernel32.SetEvent.restype = wintypes.BOOL
    kernel32.ResetEvent.argtypes = (wintypes.HANDLE,)
    kernel32.ResetEvent.restype = wintypes.BOOL
    kernel32.ReadDirectoryChangesW.argtypes = (
        wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD, wintypes.BOOL,
        wintypes.DWORD, ctypes.POINTER(wintypes.DWORD),
        ctypes.POINTER(OVERLAPPED), wintypes.LPVOID,
    )
    kernel32.ReadDirectoryChangesW.restype = wintypes.BOOL
    kernel32.WaitForMultipleObjects.argtypes = (
        wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE), wintypes.BOOL, wintypes.DWORD,
    )
    kernel32.WaitForMultipleObjects.restype = wintypes.DWORD
    kernel32.GetOverlappedResult.argtypes = (
        wintypes.HANDLE, ctypes.POINTER(OVERLAPPED), ctypes.POINTER(wintypes.DWORD), wintypes.BOOL,
    )
    kernel32.GetOverlappedResult.restype = wintypes.BOOL
    kernel32.CancelIoEx.argtypes = (wintypes.HANDLE, ctypes.POINTER(OVERLAPPED))
    kernel32.CancelIoEx.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL
    shell32.ShellExecuteExW.argtypes = (ctypes.POINTER(SHELLEXECUTEINFOW),)
    shell32.ShellExecuteExW.restype = wintypes.BOOL


def _last_error(label: str) -> WinEventError:
    return WinEventError(f"{label}:winerror={ctypes.get_last_error()}")


def close_native_handle(handle: int | None) -> None:
    value = int(handle or 0)
    if os.name == "nt" and value:
        kernel32.CloseHandle(wintypes.HANDLE(value))


def launch_with_process_handle(path: str | Path) -> int:
    """Open *path* through its registered application and retain a wait handle."""
    if os.name != "nt":
        raise WinEventError("windows_shell_launch_unavailable")
    target = Path(path)
    if not target.is_file() or target.is_symlink():
        raise WinEventError("exchange_missing_or_link")
    info = SHELLEXECUTEINFOW()
    info.cbSize = ctypes.sizeof(info)
    info.fMask = SEE_MASK_NOCLOSEPROCESS
    info.lpVerb = "open"
    info.lpFile = str(target)
    info.lpDirectory = str(target.parent)
    info.nShow = SW_SHOWNORMAL
    if not shell32.ShellExecuteExW(ctypes.byref(info)):
        raise _last_error("ShellExecuteExW")
    handle = int(info.hProcess or 0)
    if not handle:
        raise WinEventError("ShellExecuteExW:no_process_handle")
    return handle


class DirectoryChangeLease:
    """One exact Connect-session Windows notification/process lease."""

    def __init__(
        self,
        directory: str | Path,
        target_name: str,
        on_change: Callable[[], None],
        *,
        on_process_exit: Callable[[], None] | None = None,
        on_deadline: Callable[[], None] | None = None,
        on_terminated: Callable[[str], None] | None = None,
        process_handle: int | None = None,
        owns_process_handle: bool = False,
        root_cancel: threading.Event | None = None,
        deadline_seconds: float = 12.0 * 60.0 * 60.0,
    ):
        if os.name != "nt":
            raise WinEventError("windows_notifications_unavailable")
        self.directory = Path(directory).resolve()
        self.target_name = str(target_name).casefold()
        self.on_change = on_change
        self.on_process_exit = on_process_exit
        self.on_deadline = on_deadline
        self.on_terminated = on_terminated
        self.process_handle = int(process_handle or 0)
        self.owns_process_handle = bool(owns_process_handle)
        self.root_cancel = root_cancel
        self.deadline_seconds = max(1.0, float(deadline_seconds))
        self._deadline = time.monotonic() + self.deadline_seconds
        self._lock = threading.RLock()
        self._directory_handle = 0
        self._cancel_handle = 0
        self._change_handle = 0
        self._thread: threading.Thread | None = None
        self._stopped = threading.Event()
        self.error = ""
        self.termination_reason = ""

    @property
    def thread(self) -> threading.Thread | None:
        return self._thread

    @property
    def directory_handle(self) -> int:
        return int(self._directory_handle or 0)

    def renew_deadline(self) -> None:
        """Renew in memory only after a real external change; no disk write."""
        with self._lock:
            self._deadline = time.monotonic() + self.deadline_seconds

    def start(self) -> threading.Thread:
        with self._lock:
            if self._thread is not None:
                raise WinEventError("notification_lease_already_started")
            handle = kernel32.CreateFileW(
                str(self.directory), FILE_LIST_DIRECTORY,
                FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                None, OPEN_EXISTING,
                FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED, None,
            )
            if int(handle or 0) == int(INVALID_HANDLE_VALUE):
                raise _last_error("CreateFileW")
            cancel = kernel32.CreateEventW(None, True, False, None)
            change = kernel32.CreateEventW(None, True, False, None)
            if not cancel or not change:
                if change:
                    kernel32.CloseHandle(change)
                if cancel:
                    kernel32.CloseHandle(cancel)
                kernel32.CloseHandle(handle)
                raise _last_error("CreateEventW")
            self._directory_handle = int(handle)
            self._cancel_handle = int(cancel)
            self._change_handle = int(change)
            thread = threading.Thread(
                target=self._run,
                name="SPS-Bridge-WindowsEvent",
                daemon=False,
            )
            self._thread = thread
            thread.start()
            return thread

    def stop(self) -> None:
        with self._lock:
            cancel = int(self._cancel_handle or 0)
            directory = int(self._directory_handle or 0)
        if cancel:
            kernel32.SetEvent(wintypes.HANDLE(cancel))
        if directory:
            kernel32.CancelIoEx(wintypes.HANDLE(directory), None)

    def close_io(self) -> None:
        """Cancel and close blocking directory I/O before joining the thread."""
        self.stop()
        with self._lock:
            directory = int(self._directory_handle or 0)
            self._directory_handle = 0
        if directory:
            kernel32.CloseHandle(wintypes.HANDLE(directory))

    def join(self, timeout: float = 8.0) -> bool:
        thread = self._thread
        if thread is not None and thread is not threading.current_thread() and thread.is_alive():
            thread.join(max(0.0, float(timeout)))
        return bool(thread is None or not thread.is_alive())

    def _parse_names(self, buffer, byte_count: int) -> tuple[str, ...]:
        names: list[str] = []
        offset = 0
        raw = bytes(buffer[: max(0, int(byte_count))])
        while offset + 12 <= len(raw):
            next_offset = int.from_bytes(raw[offset:offset + 4], "little")
            name_bytes = int.from_bytes(raw[offset + 8:offset + 12], "little")
            end = offset + 12 + name_bytes
            if end > len(raw):
                break
            try:
                names.append(raw[offset + 12:end].decode("utf-16-le", errors="strict"))
            except UnicodeError:
                pass
            if not next_offset:
                break
            offset += next_offset
        return tuple(names)

    def _wait_timeout_ms(self) -> int:
        with self._lock:
            remaining = max(0.0, self._deadline - time.monotonic())
        return min(0xFFFFFFFE, max(0, int(remaining * 1000.0)))

    def _run(self) -> None:
        buffer = (ctypes.c_ubyte * 65536)()
        overlapped = OVERLAPPED()
        try:
            while True:
                if self.root_cancel is not None and self.root_cancel.is_set():
                    self.termination_reason = "suite_cancelled"
                    break
                with self._lock:
                    directory = int(self._directory_handle or 0)
                    cancel = int(self._cancel_handle or 0)
                    change = int(self._change_handle or 0)
                if not directory or not cancel or not change:
                    self.termination_reason = "io_closed"
                    break
                kernel32.ResetEvent(wintypes.HANDLE(change))
                overlapped = OVERLAPPED()
                overlapped.hEvent = wintypes.HANDLE(change)
                returned = wintypes.DWORD(0)
                ok = kernel32.ReadDirectoryChangesW(
                    wintypes.HANDLE(directory), ctypes.byref(buffer), len(buffer), False,
                    FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE,
                    ctypes.byref(returned), ctypes.byref(overlapped), None,
                )
                if not ok:
                    code = ctypes.get_last_error()
                    if code == ERROR_OPERATION_ABORTED:
                        self.termination_reason = "io_cancelled"
                        break
                    raise _last_error("ReadDirectoryChangesW")
                handles = [wintypes.HANDLE(cancel), wintypes.HANDLE(change)]
                if self.process_handle:
                    handles.append(wintypes.HANDLE(self.process_handle))
                wait_array = (wintypes.HANDLE * len(handles))(*handles)
                result = int(kernel32.WaitForMultipleObjects(
                    len(handles), wait_array, False, self._wait_timeout_ms()
                ))
                if result == WAIT_FAILED:
                    raise _last_error("WaitForMultipleObjects")
                if result == WAIT_TIMEOUT:
                    self.termination_reason = "lease_deadline"
                    if callable(self.on_deadline):
                        self.on_deadline()
                    break
                index = result - WAIT_OBJECT_0
                if index == 0:
                    self.termination_reason = "cancelled"
                    break
                if index == 2 and self.process_handle:
                    self.termination_reason = "external_process_exit"
                    if callable(self.on_process_exit):
                        self.on_process_exit()
                    break
                transferred = wintypes.DWORD(0)
                if not kernel32.GetOverlappedResult(
                    wintypes.HANDLE(directory), ctypes.byref(overlapped), ctypes.byref(transferred), False
                ):
                    code = ctypes.get_last_error()
                    if code == ERROR_OPERATION_ABORTED:
                        self.termination_reason = "io_cancelled"
                        break
                    raise _last_error("GetOverlappedResult")
                names = self._parse_names(buffer, int(transferred.value))
                if any(Path(name).name.casefold() == self.target_name for name in names):
                    self.renew_deadline()
                    self.on_change()
        except BaseException as exc:
            self.error = f"{type(exc).__name__}:{exc}"
            self.termination_reason = "exception"
        finally:
            self.close_io()
            with self._lock:
                cancel = int(self._cancel_handle or 0)
                change = int(self._change_handle or 0)
                process = int(self.process_handle or 0) if self.owns_process_handle else 0
                self._cancel_handle = 0
                self._change_handle = 0
                if self.owns_process_handle:
                    self.process_handle = 0
            if change:
                kernel32.CloseHandle(wintypes.HANDLE(change))
            if cancel:
                kernel32.CloseHandle(wintypes.HANDLE(cancel))
            if process:
                kernel32.CloseHandle(wintypes.HANDLE(process))
            self._stopped.set()
            if callable(self.on_terminated):
                try:
                    self.on_terminated(str(self.error or self.termination_reason or ""))
                except Exception:
                    pass


__all__ = (
    "DirectoryChangeLease", "WinEventError", "close_native_handle",
    "launch_with_process_handle",
)
