# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Pure PSD scanner for the T5.1 CSP prototype.

No Blender or Smart Paint module may be imported from this file.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from PIL import Image
from psd_tools import PSDImage
from psd_tools.compression import decompress

from .exchange_manifest import (
    HASH_SPACE,
    RECORD_INDEX_SPACE,
    SCHEMA_VERSION,
    file_fingerprint,
    marker_for_record,
    structural_signature,
    validate_manifest,
)


def _safe_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _record_name(record) -> str:
    try:
        value = record.tagged_blocks.get_data(b"luni", None)
        if value is not None:
            return str(value)
    except Exception:
        pass
    return str(getattr(record, "name", "") or "")


def _section_type(record) -> int:
    for key in (b"lsct", b"lsdk"):
        try:
            value = record.tagged_blocks.get_data(key, None)
            if value is None:
                continue
            return _safe_int(getattr(value, "kind", value), 0)
        except Exception:
            continue
    return 0


def _channel_ids(record) -> list[int]:
    out = []
    for channel in list(getattr(record, "channel_info", ()) or ()):
        value = getattr(channel, "id", getattr(channel, "channel_id", None))
        if value is None:
            continue
        out.append(_safe_int(value))
    return out


def _record_bbox(record) -> list[int]:
    return [
        _safe_int(getattr(record, "left", 0)),
        _safe_int(getattr(record, "top", 0)),
        _safe_int(getattr(record, "right", 0)),
        _safe_int(getattr(record, "bottom", 0)),
    ]


def _visible_mapping(psd) -> tuple[dict[int, Any], list[dict[str, Any]]]:
    raw = list(psd._record.layer_and_mask_information.layer_info.layer_records or ())
    raw_by_object = {id(record): index for index, record in enumerate(raw)}
    mapping: dict[int, Any] = {}
    missing: list[dict[str, Any]] = []

    def walk(items: Iterable[Any], depth: int = 0) -> None:
        for layer in list(items or ()):
            record = getattr(layer, "_record", None)
            index = raw_by_object.get(id(record)) if record is not None else None
            if index is None:
                missing.append({"name": str(getattr(layer, "name", "")), "depth": int(depth)})
            else:
                mapping[int(index)] = layer
            if bool(layer.is_group()):
                walk(list(layer), depth + 1)

    walk(list(psd))
    return mapping, missing


def _layer_depths(psd) -> dict[int, int]:
    raw = list(psd._record.layer_and_mask_information.layer_info.layer_records or ())
    raw_by_object = {id(record): index for index, record in enumerate(raw)}
    depths: dict[int, int] = {}

    def walk(items: Iterable[Any], depth: int = 0) -> None:
        for layer in list(items or ()):
            record = getattr(layer, "_record", None)
            index = raw_by_object.get(id(record)) if record is not None else None
            if index is not None:
                depths[int(index)] = int(depth)
            if bool(layer.is_group()):
                walk(list(layer), depth + 1)

    walk(list(psd))
    return depths


def premultiplied_rgba_u8(image: Image.Image) -> np.ndarray:
    rgba = np.asarray(image.convert("RGBA"), dtype=np.uint16)
    alpha = rgba[..., 3:4]
    rgb = (rgba[..., :3] * alpha + 127) // 255
    return np.concatenate((rgb, alpha), axis=2).astype(np.uint8, copy=False)


def visible_pixel_hash(image: Image.Image) -> str:
    digest = hashlib.sha256()
    width, height = image.size
    digest.update(f"{width}x{height}\0{HASH_SPACE}\0".encode("ascii"))
    rgba_image = image if image.mode == "RGBA" else image.convert("RGBA")
    for top in range(0, height, 128):
        bottom = min(height, top + 128)
        block = np.asarray(
            rgba_image.crop((0, top, width, bottom)),
            dtype=np.uint16,
        )
        alpha = block[..., 3:4]
        visible = np.empty(block.shape, dtype=np.uint8)
        visible[..., :3] = ((block[..., :3] * alpha + 127) // 255).astype(
            np.uint8,
            copy=False,
        )
        visible[..., 3] = alpha[..., 0].astype(np.uint8, copy=False)
        digest.update(visible.tobytes(order="C"))
    return digest.hexdigest()


def visible_diff_dense_oracle(before: Image.Image, after: Image.Image) -> dict[str, Any]:
    """Reference implementation retained for exact sparse-diff validation."""
    if before.size != after.size:
        return {
            "same_size": False,
            "meaningful": True,
            "reason": "size_changed",
            "before_size": list(before.size),
            "after_size": list(after.size),
        }
    lhs = premultiplied_rgba_u8(before)
    rhs = premultiplied_rgba_u8(after)
    changed = np.any(lhs != rhs, axis=2)
    count = int(np.count_nonzero(changed))
    if count == 0:
        bbox = [0, 0, 0, 0]
        max_abs = 0
    else:
        ys, xs = np.nonzero(changed)
        bbox = [int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1]
        delta = np.abs(lhs.astype(np.int16) - rhs.astype(np.int16))
        max_abs = int(delta[changed].max())
    return {
        "same_size": True,
        "compare_space": HASH_SPACE,
        "meaningful": bool(count),
        "reason": "visible_pixels_changed" if count else "visible_hash_unchanged",
        "count": count,
        "bbox": bbox,
        "max_abs": max_abs,
    }


def visible_diff(before: Image.Image, after: Image.Image) -> dict[str, Any]:
    """Compare visible pixels without premultiplying unchanged image regions."""
    if before.size != after.size:
        return {
            "same_size": False,
            "meaningful": True,
            "reason": "size_changed",
            "before_size": list(before.size),
            "after_size": list(after.size),
        }

    width, height = before.size
    lhs_image = before if before.mode == "RGBA" else before.convert("RGBA")
    rhs_image = after if after.mode == "RGBA" else after.convert("RGBA")
    count = 0
    min_x = width
    min_y = height
    max_x = -1
    max_y = -1
    max_abs = 0
    for top in range(0, height, 128):
        bottom = min(height, top + 128)
        lhs = np.asarray(lhs_image.crop((0, top, width, bottom)), dtype=np.uint8)
        rhs = np.asarray(rhs_image.crop((0, top, width, bottom)), dtype=np.uint8)
        lhs_alpha = lhs[..., 3]
        rhs_alpha = rhs[..., 3]
        alpha_changed = lhs_alpha != rhs_alpha
        rgb_changed = np.any(lhs[..., :3] != rhs[..., :3], axis=2)
        candidate = alpha_changed | (
            rgb_changed & ((lhs_alpha != 0) | (rhs_alpha != 0))
        )
        if not bool(np.any(candidate)):
            continue
        ys, xs = np.nonzero(candidate)
        lhs_pixels = lhs[candidate].astype(np.uint16, copy=False)
        rhs_pixels = rhs[candidate].astype(np.uint16, copy=False)
        lhs_visible = np.empty_like(lhs_pixels)
        rhs_visible = np.empty_like(rhs_pixels)
        lhs_visible[:, :3] = (
            lhs_pixels[:, :3] * lhs_pixels[:, 3:4] + 127
        ) // 255
        rhs_visible[:, :3] = (
            rhs_pixels[:, :3] * rhs_pixels[:, 3:4] + 127
        ) // 255
        lhs_visible[:, 3] = lhs_pixels[:, 3]
        rhs_visible[:, 3] = rhs_pixels[:, 3]
        exact = np.any(lhs_visible != rhs_visible, axis=1)
        exact_count = int(np.count_nonzero(exact))
        if exact_count == 0:
            continue
        changed_xs = xs[exact]
        changed_ys = ys[exact] + top
        count += exact_count
        min_x = min(min_x, int(changed_xs.min()))
        min_y = min(min_y, int(changed_ys.min()))
        max_x = max(max_x, int(changed_xs.max()))
        max_y = max(max_y, int(changed_ys.max()))
        delta = np.abs(
            lhs_visible[exact].astype(np.int16)
            - rhs_visible[exact].astype(np.int16)
        )
        max_abs = max(max_abs, int(delta.max()))
    bbox = [0, 0, 0, 0] if count == 0 else [min_x, min_y, max_x + 1, max_y + 1]
    return {
        "same_size": True,
        "compare_space": HASH_SPACE,
        "meaningful": bool(count),
        "reason": "visible_pixels_changed" if count else "visible_hash_unchanged",
        "count": count,
        "bbox": bbox,
        "max_abs": max_abs,
    }


def record_image(path: str | Path, record_index: int) -> tuple[Image.Image, list[int]]:
    """Decode one visible raw record by object identity, never by name."""
    source = Path(path).resolve()
    psd = PSDImage.open(source)
    raw = list(psd._record.layer_and_mask_information.layer_info.layer_records or ())
    index = int(record_index)
    if index < 0 or index >= len(raw):
        raise ValueError("record_index_out_of_range")
    target_record = raw[index]
    target = None

    def walk(items: Iterable[Any]) -> None:
        nonlocal target
        for layer in list(items or ()):
            if getattr(layer, "_record", None) is target_record:
                target = layer
                return
            if bool(layer.is_group()):
                walk(list(layer))
                if target is not None:
                    return

    walk(list(psd))
    if target is None or bool(target.is_group()):
        raise ValueError("record_not_pixel_visible")
    image = target.topil()
    if image is None:
        raise ValueError("record_pixels_unavailable")
    return image.convert("RGBA"), [int(value) for value in target.bbox]


def record_image_fast(path: str | Path, record_index: int) -> tuple[Image.Image, list[int]]:
    """Decode one 8-bit RGB raw record without compositing or visible-tree lookup."""
    source = Path(path).resolve()
    psd = PSDImage.open(source)
    return record_image_fast_from_document(psd, record_index)


def record_image_fast_from_document(
    psd: PSDImage,
    record_index: int,
) -> tuple[Image.Image, list[int]]:
    """Decode one raw record from an already opened, read-only PSD document."""
    header = psd._record.header
    if int(header.depth) != 8 or int(header.color_mode) != 3:
        raise ValueError("unsupported_psd_pixel_format")
    layer_info = psd._record.layer_and_mask_information.layer_info
    records = list(layer_info.layer_records or ())
    channels_by_record = list(layer_info.channel_image_data or ())
    index = int(record_index)
    if index < 0 or index >= len(records):
        raise ValueError("record_index_out_of_range")
    record = records[index]
    channel_data = channels_by_record[index]
    bbox = _record_bbox(record)
    width = int(bbox[2] - bbox[0])
    height = int(bbox[3] - bbox[1])
    if width <= 0 or height <= 0:
        raise ValueError("record_pixels_unavailable")

    rgba = np.empty((height, width, 4), dtype=np.uint8)
    rgba[..., :3] = 0
    rgba[..., 3] = 255
    seen = set()
    for info, channel in zip(list(record.channel_info or ()), list(channel_data or ())):
        channel_id = _safe_int(getattr(info, "id", 999), 999)
        target = 3 if channel_id == -1 else channel_id
        if target not in (0, 1, 2, 3):
            continue
        raw = decompress(
            channel.data,
            channel.compression,
            width,
            height,
            int(header.depth),
            int(header.version),
        )
        plane = np.frombuffer(raw, dtype=np.uint8).reshape(height, width)
        rgba[..., target] = plane
        seen.add(target)
    if not {0, 1, 2}.issubset(seen):
        raise ValueError("rgb_channels_missing")
    return Image.fromarray(rgba, mode="RGBA"), bbox


def align_record_images(
    before: Image.Image,
    before_bbox,
    after: Image.Image,
    after_bbox,
) -> tuple[Image.Image, Image.Image, list[int]]:
    """Place two cropped record images in their shared PSD-coordinate bounds."""
    lhs_bbox = [int(value) for value in list(before_bbox or ())]
    rhs_bbox = [int(value) for value in list(after_bbox or ())]
    if len(lhs_bbox) != 4 or len(rhs_bbox) != 4:
        raise ValueError("record_bounds_invalid")
    union = [
        min(lhs_bbox[0], rhs_bbox[0]),
        min(lhs_bbox[1], rhs_bbox[1]),
        max(lhs_bbox[2], rhs_bbox[2]),
        max(lhs_bbox[3], rhs_bbox[3]),
    ]
    width = int(union[2] - union[0])
    height = int(union[3] - union[1])
    if width <= 0 or height <= 0:
        raise ValueError("record_bounds_empty")

    def positioned(image: Image.Image, bbox: list[int]) -> Image.Image:
        expected = (int(bbox[2] - bbox[0]), int(bbox[3] - bbox[1]))
        if tuple(image.size) != expected:
            raise ValueError("record_image_size_mismatch")
        canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        rgba = image if image.mode == "RGBA" else image.convert("RGBA")
        canvas.paste(rgba, (int(bbox[0] - union[0]), int(bbox[1] - union[1])))
        return canvas

    return positioned(before, lhs_bbox), positioned(after, rhs_bbox), union

def diff_record(before_path: str | Path, after_path: str | Path, record_index: int) -> dict[str, Any]:
    before, before_bbox = record_image(before_path, record_index)
    after, after_bbox = record_image(after_path, record_index)
    before_compare, after_compare, compare_bbox = align_record_images(
        before,
        before_bbox,
        after,
        after_bbox,
    )
    stats = visible_diff(before_compare, after_compare)
    local = list(stats.get("bbox", (0, 0, 0, 0)))
    if len(local) != 4 or local[2] <= local[0] or local[3] <= local[1]:
        rect_psd = [0, 0, 0, 0]
    else:
        rect_psd = [
            int(compare_bbox[0] + local[0]),
            int(compare_bbox[1] + local[1]),
            int(compare_bbox[0] + local[2]),
            int(compare_bbox[1] + local[3]),
        ]
    return {
        "ok": True,
        "reason": "ok",
        "record_index": int(record_index),
        "record_bbox": compare_bbox,
        "before_bbox": before_bbox,
        "after_bbox": after_bbox,
        "bounds_changed": bool(before_bbox != after_bbox),
        "rect_psd": rect_psd,
        "diff": stats,
    }


def _record_kind(record, layer, section_type: int) -> str:
    if section_type == 3:
        return "DIVIDER"
    if layer is not None:
        if bool(layer.is_group()):
            return "GROUP"
        return str(getattr(layer, "kind", "UNKNOWN") or "UNKNOWN").upper()
    return "RAW"


def _has_mask(record) -> bool:
    mask = getattr(record, "mask_data", None)
    if mask is None:
        return False
    try:
        return bool(_safe_int(getattr(mask, "right", 0)) > _safe_int(getattr(mask, "left", 0))
                    and _safe_int(getattr(mask, "bottom", 0)) > _safe_int(getattr(mask, "top", 0)))
    except Exception:
        return False


def _raw_payload_signature(layer) -> list[list[Any]]:
    """Hash compressed channels without rasterizing a layer."""
    parts: list[list[Any]] = []
    record = getattr(layer, "_record", None)
    infos = list(getattr(record, "channel_info", ()) or ())
    channels = list(getattr(layer, "_channels", ()) or ())
    for offset, channel in enumerate(channels):
        info = infos[offset] if offset < len(infos) else None
        channel_id = getattr(info, "id", offset) if info is not None else offset
        data = getattr(channel, "data", b"") or b""
        if not isinstance(data, (bytes, bytearray, memoryview)):
            data = bytes(data)
        raw = bytes(data)
        parts.append([
            _safe_int(channel_id, offset),
            str(getattr(channel, "compression", "") or ""),
            _safe_int(getattr(info, "length", len(raw)), len(raw)) if info is not None else len(raw),
            len(raw),
            hashlib.sha256(raw).hexdigest(),
        ])
    return parts


def scan_document(
    path: str | Path,
    *,
    include_pixels: bool = True,
    include_raw_signatures: bool = True,
) -> dict[str, Any]:
    source = Path(path).resolve()
    psd = PSDImage.open(source)
    raw = list(psd._record.layer_and_mask_information.layer_info.layer_records or ())
    visible, missing = _visible_mapping(psd)
    depths = _layer_depths(psd)
    records = []

    for record_index, record in enumerate(raw):
        layer = visible.get(int(record_index))
        section_type = _section_type(record)
        kind = _record_kind(record, layer, section_type)
        channel_ids = _channel_ids(record)
        entry = {
            "record_index": int(record_index),
            "marker": marker_for_record(record_index),
            "legacy_name": str(getattr(record, "name", "") or ""),
            "display_name": _record_name(record),
            "kind": kind,
            "depth": int(depths.get(int(record_index), 0)),
            "section_type": int(section_type),
            "channel_ids": channel_ids,
            "has_mask": _has_mask(record),
            "bbox": _record_bbox(record),
            "editable": bool(layer is not None and kind == "PIXEL" and section_type == 0),
        }
        if include_raw_signatures and entry["editable"]:
            entry["raw_payload_signature"] = _raw_payload_signature(layer)
        if include_pixels and entry["editable"]:
            image = layer.topil()
            if image is None:
                entry["editable"] = False
                entry["pixel_reason"] = "topil_unavailable"
            else:
                entry["pixel_size"] = [int(image.size[0]), int(image.size[1])]
                entry["visible_pixel_hash"] = visible_pixel_hash(image)
        records.append(entry)

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "record_index_space": RECORD_INDEX_SPACE,
        "hash_space": HASH_SPACE,
        "canonical": file_fingerprint(source),
        "document": {"width": int(psd.width), "height": int(psd.height)},
        "record_count": int(len(records)),
        "visible_mapping_complete": not missing,
        "visible_mapping_missing": missing,
        "records": records,
    }
    manifest["structural_signature"] = structural_signature(records)
    return validate_manifest(manifest)


def candidate_records(baseline: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
    """Return raw records whose compressed payloads need visible decoding."""
    validate_manifest(baseline)
    validate_manifest(current)
    if baseline["structural_signature"] != current["structural_signature"]:
        return {
            "ok": False,
            "reason": "structural_signature_mismatch",
            "candidate_records": [],
        }
    before = {int(item["record_index"]): item for item in baseline["records"]}
    after = {int(item["record_index"]): item for item in current["records"]}
    candidates = []
    for record_index in sorted(before):
        lhs = before[record_index]
        rhs = after[record_index]
        if not bool(lhs.get("editable", False)):
            continue
        if lhs.get("raw_payload_signature") != rhs.get("raw_payload_signature"):
            candidates.append(int(record_index))
    return {"ok": True, "reason": "ok", "candidate_records": candidates}


def compare_manifests(baseline: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
    validate_manifest(baseline)
    validate_manifest(current)
    if baseline["structural_signature"] != current["structural_signature"]:
        return {
            "ok": False,
            "reason": "structural_signature_mismatch",
            "changed_records": [],
        }
    before = {int(item["record_index"]): item for item in baseline["records"]}
    after = {int(item["record_index"]): item for item in current["records"]}
    changed = []
    for record_index in sorted(before):
        lhs = str(before[record_index].get("visible_pixel_hash", ""))
        rhs = str(after[record_index].get("visible_pixel_hash", ""))
        if lhs and rhs and lhs != rhs:
            changed.append(int(record_index))
    return {"ok": True, "reason": "ok", "changed_records": changed}
