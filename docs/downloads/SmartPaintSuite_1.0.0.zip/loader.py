# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
"""Static optional-tool inventory; no delayed imports or background loaders."""
from __future__ import annotations

_RECORDS = {
    "brushstroke_tools": {"status": "loaded", "module": "brushstroke_tools.preferences"},
    "grease_pencil_tools": {"status": "loaded", "module": "grease_pencil_tools.preferences"},
    "textures_autosave": {"status": "loaded", "module": "textures_autosave"},
    "ucupaint": {"status": "loaded", "module": "ucupaint.preferences"},
}


def get_record(alias: str):
    value = _RECORDS.get(str(alias or ""))
    return dict(value) if isinstance(value, dict) else None


__all__ = ("get_record",)
