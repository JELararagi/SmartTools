# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

'Crash-safe N-panel UI for UV Suite.\n\nThis module draws a single, stable, icon-driven N-panel layout.  It avoids the\nlegacy full UI draw path and keeps heavyweight integrated tools collapsed until\nthe user explicitly opens them.\n'

from __future__ import annotations

from pathlib import Path
from types import MappingProxyType
from typing import Iterable, Sequence
import hashlib
import re
import sys

import bpy

from .icon_aliases import canonical_icon_path
from . import controls as _controls
from . import npanel_persistence as _npanel_store
from . import text_translation as _text_translation
from . import uv_map_channels as _uv_map_channels

try:
    import bpy.utils.previews as _previews
except Exception:  # pragma: no cover - Blender-only module
    _previews = None

_ICON_COLLECTION = None
_ICON_CACHE: dict[str, int] = {}

# Viewport navigation can redraw open N-panels very frequently.  Keep expensive
# Blender RNA lookups and static operator catalog grouping out of per-frame draw
# hot paths.  These caches are invalidated on add-on register/unregister and can
# be cleared from outside this module without changing UI content.
_OPERATOR_RNA_CACHE: MappingProxyType = MappingProxyType({})
_OPERATOR_PROP_CACHE: MappingProxyType = MappingProxyType({})
_UI_OPERATOR_PROP_CACHE: MappingProxyType = MappingProxyType({})
_MAPPED_CATEGORIES_CACHE: tuple[tuple, MappingProxyType] = ((), MappingProxyType({}))
_LIVE_OPERATOR_CATALOG_CACHE: tuple[tuple[str, str, str], ...] = ()
_LOCALE_MOD_CACHE = None
_DRAW_TR_CACHE: dict[tuple[bool, str, str], str] = {}
_DRAW_IS_JA: bool = False
_DRAW_LANGUAGE = None
_PUBLIC_KEYMAP_ROWS_SNAPSHOT: tuple[MappingProxyType, ...] = ()

# Help popup scope registry.  The visible N-panel is drawn from many compact
# helper functions; this lightweight registry records which buttons and
# properties were drawn after each help header so the lazy popup can describe
# the actual item that owns the Help icon instead of showing a broad overview.
_HELP_SCOPE_REGISTRY: MappingProxyType = MappingProxyType({})
_HELP_SCOPE_ACTIVE: str = ''

_ICON_CACHE_LIMIT = 512
_OPERATOR_CACHE_LIMIT = 1024
_UI_OPERATOR_PROP_CACHE_LIMIT = 512
_DRAW_TRANSLATION_CACHE_LIMIT = 2048
_HELP_SCOPE_LIMIT = 256
_HELP_SCOPE_ITEM_LIMIT = 256

_STATIC_UI_OPERATOR_IDS = (
    'mesh.suv_bake_uv_prep',
    'mesh.suv_clear_seams',
    'mesh.suv_native_stage_mesh',
    'mesh.suv_native_stage_uvmap',
    'mesh.suv_uvmap_add',
    'mesh.suv_uvmap_duplicate',
    'mesh.suv_uvmap_remove',
    'mesh.suv_uvmap_rename_active',
    'mesh.suv_uvmap_reorder',
    'mesh.suv_uvmap_set_active',
    'mesh.suv_uvmap_set_render',
    'object.suv_clear_stretch_heatmap',
    'object.suv_native_stage_bake',
    'object.suv_native_stage_preview',
    'object.suv_visualize_stretch_heatmap',
    'smart_uv_suite.align_edges',
    'smart_uv_suite.align_islands',
    'smart_uv_suite.align_normalize',
    'smart_uv_suite.align_orient',
    'smart_uv_suite.align_relax',
    'smart_uv_suite.align_straight_line',
    'smart_uv_suite.align_stretch',
    'smart_uv_suite.align_uv_axis',
    'smart_uv_suite.align_uv_circle',
    'smart_uv_suite.align_uv_straighten',
    'smart_uv_suite.atlas_bake_multi',
    'smart_uv_suite.atlas_build_mat_apply_multi',
    'smart_uv_suite.auto_seam_advanced',
    'smart_uv_suite.auto_unwrap_pro',
    'smart_uv_suite.checker_create',
    'smart_uv_suite.checker_delete',
    'smart_uv_suite.checker_map',
    'smart_uv_suite.checker_map_cleanup',
    'smart_uv_suite.checker_map_clear',
    'smart_uv_suite.checker_material_toggle',
    'smart_uv_suite.cockpit_analyze',
    'smart_uv_suite.cockpit_apply_profile',
    'smart_uv_suite.cockpit_run',
    'smart_uv_suite.consolidated_builtin_uv_action',
    'smart_uv_suite.consolidated_flatten_to_uv_shape_key',
    'smart_uv_suite.consolidated_select_udim_islands',
    'smart_uv_suite.consolidated_select_uv_issue',
    'smart_uv_suite.consolidated_snap_uv',
    'smart_uv_suite.consolidated_texel_density_report',
    'smart_uv_suite.consolidated_uv_map_action',
    'smart_uv_suite.copy_operator_id',
    'smart_uv_suite.cursor_to_hover_uv_vertex',
    'smart_uv_suite.direction_align',
    'smart_uv_suite.direction_align_action',
    'smart_uv_suite.direction_align_mode',
    'smart_uv_suite.excellence_action',
    'smart_uv_suite.export_uv_layout',
    'smart_uv_suite.gridify',
    'smart_uv_suite.inspect_clear_all_reports',
    'smart_uv_suite.inspect_cockpit_analyze',
    'smart_uv_suite.inspect_external_report',
    'smart_uv_suite.inspect_fix_all_issues',
    'smart_uv_suite.inspect_inspector_clear_cache',
    'smart_uv_suite.inspect_inspector_scan',
    'smart_uv_suite.inspect_inspector_select',
    'smart_uv_suite.inspect_inspector_select_all',
    'smart_uv_suite.inspect_inspector_write_report',
    'smart_uv_suite.inspect_layout_preflight_audit',
    'smart_uv_suite.inspect_orient_world',
    'smart_uv_suite.inspect_quality_audit_suite',
    'smart_uv_suite.inspect_quality_cleanup_generated_data',
    'smart_uv_suite.inspect_quality_open_doctor_report',
    'smart_uv_suite.inspect_set_library_io',
    'smart_uv_suite.inspect_set_recall',
    'smart_uv_suite.inspect_set_save',
    'smart_uv_suite.inspect_set_update',
    'smart_uv_suite.inspect_unstack_overlapped',
    'smart_uv_suite.inspect_wand_bridge',
    'smart_uv_suite.inspect_workspace_auto_repair',
    'smart_uv_suite.inspect_workspace_validate',
    'smart_uv_suite.island_direction_align',
    'smart_uv_suite.island_distribute',
    'smart_uv_suite.island_flip',
    'smart_uv_suite.island_flip_rotate_uv',
    'smart_uv_suite.island_rotate',
    'smart_uv_suite.island_rotate_transform',
    'smart_uv_suite.island_stretch_uv_toggle',
    'smart_uv_suite.island_uvmesh',
    'smart_uv_suite.island_uvmesh_clear',
    'smart_uv_suite.island_uvmesh_control',
    'smart_uv_suite.keymap_info_action',
    'smart_uv_suite.map_channel_add',
    'smart_uv_suite.map_channel_move',
    'smart_uv_suite.map_channel_object_select',
    'smart_uv_suite.map_channel_remove',
    'smart_uv_suite.map_channel_rename',
    'smart_uv_suite.map_channel_toggle_unify_check',
    'smart_uv_suite.map_channel_unify_checked',
    'smart_uv_suite.native_align_action',
    'smart_uv_suite.native_bake_action',
    'smart_uv_suite.native_basic_action',
    'smart_uv_suite.native_cleanup_action',
    'smart_uv_suite.native_id_action',
    'smart_uv_suite.native_io_action',
    'smart_uv_suite.native_seam_action',
    'smart_uv_suite.pack',
    'smart_uv_suite.pack_crop',
    'smart_uv_suite.pack_layout_action',
    'smart_uv_suite.pack_layout_set_library_io',
    'smart_uv_suite.pack_load_id_map',
    'smart_uv_suite.pack_load_trim_preset',
    'smart_uv_suite.pack_load_uv_list_file',
    'smart_uv_suite.pack_pro',
    'smart_uv_suite.pack_save_trim_preset',
    'smart_uv_suite.preset_library_io',
    'smart_uv_suite.projection_gizmo_action',
    'smart_uv_suite.seam_boundary',
    'smart_uv_suite.seam_clear_pins',
    'smart_uv_suite.seam_clear_seams',
    'smart_uv_suite.seam_merge',
    'smart_uv_suite.seam_mirror_uv',
    'smart_uv_suite.seam_pin',
    'smart_uv_suite.seam_rectify',
    'smart_uv_suite.seam_set_library_io',
    'smart_uv_suite.seam_settings_action',
    'smart_uv_suite.seam_smart_seams',
    'smart_uv_suite.seam_snapshot_action',
    'smart_uv_suite.seam_stack_pro',
    'smart_uv_suite.seam_symmetry_snap',
    'smart_uv_suite.select_border',
    'smart_uv_suite.select_by_area',
    'smart_uv_suite.select_by_cursor',
    'smart_uv_suite.select_division',
    'smart_uv_suite.select_edge',
    'smart_uv_suite.select_flipped_faces',
    'smart_uv_suite.select_fragmented_islands',
    'smart_uv_suite.select_half',
    'smart_uv_suite.select_identical_islands',
    'smart_uv_suite.select_island_active',
    'smart_uv_suite.select_linked_select',
    'smart_uv_suite.select_mirror3d',
    'smart_uv_suite.select_mode',
    'smart_uv_suite.select_pick',
    'smart_uv_suite.select_similar',
    'smart_uv_suite.select_similar_islands',
    'smart_uv_suite.select_similar_select',
    'smart_uv_suite.select_square_island',
    'smart_uv_suite.select_stacked',
    'smart_uv_suite.select_texel_density',
    'smart_uv_suite.select_udim_crossing',
    'smart_uv_suite.select_uv_boundary',
    'smart_uv_suite.select_uv_select_flipped',
    'smart_uv_suite.select_uv_select_overlapped',
    'smart_uv_suite.select_zero',
    'smart_uv_suite.select_zero_islands',
    'smart_uv_suite.show_help',
    'smart_uv_suite.smart_uv_smart_action',
    'smart_uv_suite.smart_uv_smart_feature',
    'smart_uv_suite.smart_uv_smart_write_matrix',
    'smart_uv_suite.stitch',
    'smart_uv_suite.stitch_action',
    'smart_uv_suite.texel_bake_trim_id_map',
    'smart_uv_suite.texel_bake_uv_prep',
    'smart_uv_suite.texel_calc_uv_area',
    'smart_uv_suite.texel_density_coverage',
    'smart_uv_suite.texel_density_from_texture',
    'smart_uv_suite.texel_density_get',
    'smart_uv_suite.texel_density_set',
    'smart_uv_suite.texel_density_tools',
    'smart_uv_suite.texel_get',
    'smart_uv_suite.texel_layers_manager',
    'smart_uv_suite.texel_normalize',
    'smart_uv_suite.texel_set',
    'smart_uv_suite.texel_stage_bake',
    'smart_uv_suite.texel_stage_uvmap',
    'smart_uv_suite.texel_uvmap_add',
    'smart_uv_suite.texel_uvmap_duplicate',
    'smart_uv_suite.texel_uvmap_remove',
    'smart_uv_suite.texel_uvmap_rename_active',
    'smart_uv_suite.texel_uvmap_reorder',
    'smart_uv_suite.texel_uvmap_set_active',
    'smart_uv_suite.texel_uvmap_set_render',
    'smart_uv_suite.toggle_ui_foldout',
    'smart_uv_suite.unified_auto_pack',
    'smart_uv_suite.unwrap',
    'smart_uv_suite.unwrap_auto_action',
    'smart_uv_suite.unwrap_auto_run',
    'smart_uv_suite.unwrap_body_preset',
    'smart_uv_suite.unwrap_box_project',
    'smart_uv_suite.unwrap_constraint',
    'smart_uv_suite.unwrap_projection',
    'smart_uv_suite.unwrap_smart_project',
    'smart_uv_suite.unwrap_texture_projection_project',
    'smart_uv_suite.unwrap_unfoldify',
    'smart_uv_suite.unwrap_view_project',
    'smart_uv_suite.uv_element_select_action',
    'smart_uv_suite.uv_layout_action',
    'smart_uv_suite.vertex_align_action',
    'smart_uv_suite.vertex_even_straighten_selected',
    'smart_uv_suite.vertex_set_flow_selected',
    'smart_uv_suite.vertex_straighten_selected',
    'smart_uv_suite.view_create_checker_material',
    'smart_uv_suite.view_fit_to_bounds',
    'smart_uv_suite.view_focus',
    'smart_uv_suite.view_histogram_tools',
    'smart_uv_suite.view_remove_checker_materials',
    'smart_uv_suite.view_set_cursor_2d',
    'smart_uv_suite.view_stage_color',
    'smart_uv_suite.view_stage_preview',
    'smart_uv_suite.view_texture_projection',
    'smart_uv_suite.view_upgrade_write_validation_report',
    'smart_uv_suite.weld',
    'smart_uv_suite.workflow_collect_support_bundle',
    'smart_uv_suite.workflow_open_diagnostics_text',
    'smart_uv_suite.workflow_open_smart_tools',
    'smart_uv_suite.workflow_preserve_uv_aspect',
    'smart_uv_suite.workflow_show_addon_preferences',
    'smart_uv_suite.workflow_show_help',
    'smart_uv_suite.workflow_texture_lock_lock',
    'smart_uv_suite.workflow_texture_lock_unlock',
    'smart_uv_suite.workflow_workspace_reset',
    'smart_uv_suite.workflow_workspace_settings_io',
    'smart_uv_suite.workflow_write_support_bundle',
    'smart_uv_suite.settings_save',
    'smart_uv_suite.settings_load',
    'smart_uv_suite.seams_save',
    'smart_uv_suite.seams_load',
    'smart_uv_suite.layout_save',
    'smart_uv_suite.layout_load',
    'smart_uv_suite.selection_save',
    'smart_uv_suite.selection_load',
    'smart_uv_suite.diagnostics_save',
    'suv.constraint_unwrap',
    'uv.suv_align_islands',
    'uv.suv_apply_display_preset',
    'uv.suv_apply_workflow_preset',
    'uv.suv_atlas_bake_multi',
    'uv.suv_atlas_build_mat_apply_multi',
    'uv.suv_atlas_build_uv_multi',
    'uv.suv_atlas_run_all_multi',
    'uv.suv_auto_seam_advanced',
    'uv.suv_auto_unwrap_pro',
    'uv.suv_batch_match_stitch_active_preserve',
    'uv.suv_centralize_islands',
    'uv.suv_cleanup_bridge',
    'uv.suv_clear_all_reports',
    'uv.suv_clear_batch_report',
    'uv.suv_clear_pins',
    'uv.suv_clear_tool_runtime_log',
    'uv.suv_collect_support_bundle',
    'uv.suv_constraint_relax_preserve',
    'uv.suv_copy_diagnostics_text',
    'uv.suv_crop_tile',
    'uv.suv_density_guard_normalize',
    'uv.suv_distribute_islands',
    'uv.suv_explode_islands',
    'uv.suv_fill_tile',
    'uv.suv_fit_to_bounds',
    'uv.suv_flip_islands',
    'uv.suv_group_normalize_layout',
    'uv.suv_groups_to_tiles',
    'uv.suv_hair_card_uv_tools',
    'uv.suv_histogram_tools',
    'uv.suv_hotspot_cell_refill',
    'uv.suv_hotspot_cell_tools',
    'uv.suv_hotspot_grid_layout',
    'uv.suv_hotspot_symmetry_refill',
    'uv.suv_hs_gridify',
    'uv.suv_hs_orthogonalize',
    'uv.suv_hs_rectify_fit',
    'uv.suv_hs_squareify',
    'uv.suv_inspector_clear_cache',
    'uv.suv_inspector_fix_flipped',
    'uv.suv_inspector_rescan',
    'uv.suv_inspector_scan',
    'uv.suv_inspector_select',
    'uv.suv_inspector_select_all',
    'uv.suv_inspector_write_report',
    'uv.suv_issue_audit_tools',
    'uv.suv_layout_autoheal',
    'uv.suv_layout_preflight_audit',
    'uv.suv_match_active_preserve',
    'uv.suv_match_stitch_active_preserve',
    'uv.suv_native_projection',
    'uv.suv_native_stage_layout',
    'uv.suv_native_stage_select',
    'uv.suv_native_stage_workflow',
    'uv.suv_native_uv_action',
    'uv.suv_open_diagnostics_text',
    'uv.suv_orient_groups_advanced',
    'uv.suv_orient_to_edge',
    'uv.suv_pack_pro',
    'uv.suv_precision_uv_tools',
    'uv.suv_priority_density_pack',
    'uv.suv_procedural_uv_tools',
    'uv.suv_projection_bridge',
    'uv.suv_quality_audit_suite',
    'uv.suv_quality_cleanup_generated_data',
    'uv.suv_quality_scan_context_readiness',
    'uv.suv_quality_write_operator_catalog',
    'uv.suv_quality_write_ui_map',
    'uv.suv_randomize_islands',
    'uv.suv_reload_custom_icons',
    'uv.suv_repair_flipped_islands',
    'uv.suv_rotate_islands',
    'uv.suv_select_fragmented_islands',
    'uv.suv_select_identical_islands',
    'uv.suv_select_island_active',
    'uv.suv_select_similar_islands',
    'uv.suv_select_udim_crossing',
    'uv.suv_select_uv_boundary',
    'uv.suv_select_zero_islands',
    'uv.suv_set_flow',
    'uv.suv_similarity_bridge',
    'uv.suv_smart_3d_transfer',
    'uv.suv_smart_seams',
    'uv.suv_stack_grouped',
    'uv.suv_stack_symmetry_topology',
    'uv.suv_stack_topology_groups',
    'uv.suv_straight_line',
    'uv.suv_sym_detect_pairs',
    'uv.suv_sym_mirror_uv',
    'uv.suv_sym_seams',
    'uv.suv_sym_stack',
    'uv.suv_texel_get',
    'uv.suv_texel_normalize',
    'uv.suv_texel_set',
    'uv.suv_trim_band_layout',
    'uv.suv_trim_band_refill',
    'uv.suv_trim_strip_layout',
    'uv.suv_udim_step',
    'uv.suv_udim_tile_tools',
    'uv.suv_unstack_groups',
    'uv.suv_unstack_overlapped',
    'uv.suv_uv_brush_compat',
    'uv.suv_uv_edit_compat_tools',
    'uv.suv_uv_lattice_compat',
    'uv.suv_workspace_auto_repair',
    'uv.suv_workspace_reset',
    'uv.suv_workspace_settings_io',
    'uv.suv_workspace_validate',
    'uv.suv_write_support_bundle',
    'uv.suv_write_tool_runtime_snapshot',
)



def _bounded_cache_set(cache: dict, key, value, limit: int) -> None:
    """Store one value while keeping insertion-ordered caches bounded."""
    try:
        if key in cache:
            cache.pop(key, None)
        target = max(1, int(limit))
        while len(cache) >= target:
            try:
                cache.pop(next(iter(cache)))
            except (StopIteration, KeyError):
                break
        cache[key] = value
    except Exception:
        try:
            cache.clear()
            cache[key] = value
        except Exception:
            pass


def _help_scope_entry(key: str, title_en: str = '', title_ja: str = '') -> dict:
    del title_en, title_ja
    value = _HELP_SCOPE_REGISTRY.get(str(key or '').strip(), {})
    return dict(value) if isinstance(value, dict) else {}


def _help_scope_begin(help_id: str, title_en: str = '', title_ja: str = '') -> None:
    # Help scope is materialized at register time.  Panel.draw never mutates it.
    del help_id, title_en, title_ja
    return None


def _help_scope_current() -> str:
    return ''


def _help_scope_register_operator(op_id: str, label_en: str = '', label_ja: str = '', props: dict | None = None, *, symbol: str | None = None) -> None:
    del op_id, label_en, label_ja, props, symbol
    return None


def _help_scope_register_property(owner, prop_name: str, label: str | None = None) -> None:
    del owner, prop_name, label
    return None


def help_scope_snapshot() -> dict:
    return {
        str(key): {
            'help_id': str(value.get('help_id') or key),
            'title_en': str(value.get('title_en') or key),
            'title_ja': str(value.get('title_ja') or value.get('title_en') or key),
            'operators': tuple(dict(item) for item in tuple(value.get('operators') or ())),
            'properties': tuple(dict(item) for item in tuple(value.get('properties') or ())),
        }
        for key, value in _HELP_SCOPE_REGISTRY.items()
        if isinstance(value, dict)
    }

def invalidate_runtime_caches(*, icons: bool = False) -> None:
    """Clear lifecycle snapshots without touching persisted N-panel state."""
    global _OPERATOR_RNA_CACHE, _OPERATOR_PROP_CACHE, _UI_OPERATOR_PROP_CACHE
    global _MAPPED_CATEGORIES_CACHE, _LIVE_OPERATOR_CATALOG_CACHE
    global _HELP_SCOPE_REGISTRY, _LOCALE_MOD_CACHE, _DRAW_IS_JA, _PUBLIC_KEYMAP_ROWS_SNAPSHOT
    _OPERATOR_RNA_CACHE = MappingProxyType({})
    _OPERATOR_PROP_CACHE = MappingProxyType({})
    _UI_OPERATOR_PROP_CACHE = MappingProxyType({})
    _MAPPED_CATEGORIES_CACHE = ((), MappingProxyType({}))
    _LIVE_OPERATOR_CATALOG_CACHE = ()
    _HELP_SCOPE_REGISTRY = MappingProxyType({})
    _LOCALE_MOD_CACHE = None
    _DRAW_TR_CACHE.clear()
    _DRAW_IS_JA = False
    _PUBLIC_KEYMAP_ROWS_SNAPSHOT = ()
    if icons:
        _ICON_CACHE.clear()

def _begin_draw_cache(context=None) -> None:
    del context
    return None


def _end_draw_cache() -> None:
    return None

_ICON_FILES = {
    "logo": "sus_logo.png",
    "quick": "sus_quick.png",
    "settings": "sus_settings.png",
    "unwrap": "sus_unwrap.png",
    "seam": "sus_seam.png",
    "project": "sus_project.png",
    "align": "sus_align.png",
    "straight": "sus_straight.png",
    "transform": "sus_transform.png",
    "pack": "sus_pack.png",
    "layout": "sus_layout.png",
    "stack": "sus_stack.png",
    "select": "sus_select.png",
    "inspect": "sus_inspect.png",
    "density": "sus_density.png",
    "checker": "sus_checker.png",
    "uvmap": "sus_uvmap.png",
    "symmetry": "sus_symmetry.png",
    "atlas": "sus_atlas.png",
    "bake": "sus_bake.png",
    "report": "sus_report.png",
    "integrated": "sus_integrated.png",
    "tool": "sus_integrated.png",
    "help": "sus_help.png",
    "repair": "sus_repair.png",
    "magic": "sus_magic.png",
    "bridge": "sus_bridge.png",
    "preset": "sus_preset.png",
    "cleanup": "sus_cleanup.png",
    "hotspot": "sus_hotspot.png",
    "udim": "sus_udim.png",
    "pin": "sus_pin.png",
    "flip": "sus_flip.png",
    "rotate": "sus_rotate.png",
    "scale": "sus_scale.png",
    "transfer": "sus_transfer.png",
    "quality": "sus_quality.png",
    "native": "sus_native.png",
    "layout_board": "sus_layout_board.png",
    "crop": "sus_crop.png",
    "fill": "sus_fill.png",
    "fit": "sus_fit.png",
    "align_tl": "sus_align_tl.png",
    "align_top": "sus_align_top.png",
    "align_tr": "sus_align_tr.png",
    "align_left": "sus_align_left.png",
    "align_center": "sus_align_center.png",
    "align_right": "sus_align_right.png",
    "align_bl": "sus_align_bl.png",
    "align_bottom": "sus_align_bottom.png",
    "align_br": "sus_align_br.png",
    "align_h": "sus_align_h.png",
    "align_v": "sus_align_v.png",
    "sort_h": "sus_sort_h.png",
    "sort_v": "sus_sort_v.png",
    "distribute_h": "sus_distribute_h.png",
    "distribute_v": "sus_distribute_v.png",
    "rotate_ccw": "sus_rotate_ccw.png",
    "rotate_cw": "sus_rotate_cw.png",
    "mirror_h": "sus_mirror_h.png",
    "mirror_v": "sus_mirror_v.png",
    "orient_bbox": "sus_orient_bbox.png",
    "orient_edge": "sus_orient_edge.png",
    "rectify": "sus_rectify.png",
    "gridify": "sus_gridify.png",
    "squareify": "sus_squareify.png",
    "relax": "sus_relax.png",
    "stitch": "sus_stitch.png",
    "weld": "sus_weld.png",
    "unpin": "sus_unpin.png",
    "select_similar": "sus_select_similar.png",
    "select_identical": "sus_select_identical.png",
    "select_overlap": "sus_select_overlap.png",
    "select_zero": "sus_select_zero.png",
    "select_flipped": "sus_select_flipped.png",
    "select_bounds": "sus_select_bounds.png",
    "density_pick": "sus_density_pick.png",
    "density_apply": "sus_density_apply.png",
    "density_normalize": "sus_density_normalize.png",
    "unwrap_abf": "sus_unwrap_abf.png",
    "unwrap_lscm": "sus_unwrap_lscm.png",
    "follow_quads": "sus_follow_quads.png",
    "smart_project": "sus_smart_project.png",
    "excellence": "sus_excellence.png",
    "command": "sus_command.png",
    "advisor": "sus_advisor.png",
    "grade": "sus_grade.png",
    "candidate": "sus_candidate.png",
    "organic": "sus_organic.png",
    "hard_surface": "sus_hard_surface.png",
    "game": "sus_game.png",
    "scan": "sus_scan.png",
    "trimsheet": "sus_trimsheet.png",
    "cockpit": "sus_cockpit.png",
    "hero": "sus_hero.png",
    "lightmap": "sus_lightmap.png",
    "visual_reference": "sus_visual_reference.png",
    "ref_flow": "sus_ref_flow.png",
    "ref_score": "sus_ref_score.png",
    "uv_bbox": "sus_uv_bbox.png",
    "group_center_h": "sus_group_center_h.png",
    "group_center_v": "sus_group_center_v.png",
    "dist_h": "sus_dist_h.png",
    "dist_v": "sus_dist_v.png",
    "unwrap_planar": "sus_unwrap_planar.png",
    "unwrap_cylinder": "sus_unwrap_cylinder.png",
    "unwrap_sphere": "sus_unwrap_sphere.png",
    "unwrap_flatten": "sus_unwrap_flatten.png",
    "unwrap_pelt": "sus_unwrap_pelt.png",
    "ref_density": "sus_ref_density.png",
    "uv_bbox": "sus_uv_bbox.png",
    "group_center_h": "sus_group_center_h.png",
    "group_center_v": "sus_group_center_v.png",
    "dist_h": "sus_dist_h.png",
    "dist_v": "sus_dist_v.png",
    "unwrap_planar": "sus_unwrap_planar.png",
    "unwrap_cylinder": "sus_unwrap_cylinder.png",
    "unwrap_sphere": "sus_unwrap_sphere.png",
    "unwrap_pelt": "sus_unwrap_pelt.png",
    "unwrap_peel": "sus_unwrap_peel.png",
    "unwrap_flatten": "sus_unwrap_flatten.png",
    "unwrap_normal": "sus_unwrap_normal.png",
}


_STANDARD_ICON_BY_KEY = {
    "logo": "UV",
    "quick": "PLAY",
    "settings": "PREFERENCES",
    "unwrap": "UV",
    "seam": "MOD_EDGESPLIT",
    "project": "MOD_UVPROJECT",
    "align": "PIVOT_BOUNDBOX",
    "straight": "ORIENTATION_GLOBAL",
    "transform": "ORIENTATION_GLOBAL",
    "pack": "PACKAGE",
    "layout": "UV",
    "stack": "MOD_MULTIRES",
    "select": "RESTRICT_SELECT_OFF",
    "inspect": "VIEWZOOM",
    "density": "SEQ_HISTOGRAM",
    "checker": "TEXTURE",
    "uvmap": "GROUP_UVS",
    "symmetry": "MOD_MIRROR",
    "atlas": "TEXTURE",
    "bake": "RESTRICT_RENDER_OFF",
    "report": "TEXT",
    "integrated": "TOOL_SETTINGS",
    "tool": "TOOL_SETTINGS",
    "help": "QUESTION",
    "repair": "FILE_REFRESH",
    "magic": "LIGHT",
    "bridge": "LINK_BLEND",
    "preset": "PRESET",
    "cleanup": "BRUSH_DATA",
    "hotspot": "UV",
    "udim": "UV",
    "pin": "PINNED",
    "flip": "ARROW_LEFTRIGHT",
    "rotate": "LOOP_BACK",
    "scale": "FULLSCREEN_ENTER",
    "transfer": "LINK_BLEND",
    "quality": "CHECKMARK",
    "native": "TOOL_SETTINGS",
    "layout_board": "WINDOW",
    "crop": "FULLSCREEN_EXIT",
    "fill": "SHADING_BBOX",
    "fit": "FULLSCREEN_ENTER",
    "align_top": "TRIA_UP",
    "align_bottom": "TRIA_DOWN",
    "align_left": "TRIA_LEFT",
    "align_right": "TRIA_RIGHT",
    "align_center": "PIVOT_BOUNDBOX",
    "align_h": "ARROW_LEFTRIGHT",
    "align_v": "EMPTY_SINGLE_ARROW",
    "distribute_h": "ARROW_LEFTRIGHT",
    "distribute_v": "EMPTY_SINGLE_ARROW",
    "rotate_ccw": "LOOP_BACK",
    "rotate_cw": "LOOP_FORWARDS",
    "mirror_h": "MOD_MIRROR",
    "mirror_v": "MOD_MIRROR",
    "orient_bbox": "PIVOT_BOUNDBOX",
    "orient_edge": "ORIENTATION_GLOBAL",
    "rectify": "ORIENTATION_GLOBAL",
    "gridify": "MESH_GRID",
    "squareify": "SHADING_BBOX",
    "relax": "MOD_SMOOTH",
    "stitch": "AUTOMERGE_ON",
    "weld": "AUTOMERGE_ON",
    "select_similar": "RESTRICT_SELECT_OFF",
    "select_identical": "SELECT_INTERSECT",
    "select_overlap": "SELECT_INTERSECT",
    "select_zero": "SELECT_INTERSECT",
    "select_flipped": "FACESEL",
    "select_bounds": "FULLSCREEN_EXIT",
    "density_pick": "EYEDROPPER",
    "density_apply": "FILE_TICK",
    "density_normalize": "SEQ_HISTOGRAM",
    "unwrap_abf": "UV",
    "unwrap_lscm": "UV",
    "follow_quads": "MOD_UVPROJECT",
    "smart_project": "MOD_UVPROJECT",
    "uv_bbox": "PIVOT_BOUNDBOX",
    "group_center_h": "ARROW_LEFTRIGHT",
    "group_center_v": "EMPTY_SINGLE_ARROW",
    "dist_h": "ARROW_LEFTRIGHT",
    "dist_v": "EMPTY_SINGLE_ARROW",
    "unwrap_planar": "MESH_PLANE",
    "unwrap_cylinder": "MESH_CYLINDER",
    "unwrap_sphere": "MESH_UVSPHERE",
    "unwrap_flatten": "MOD_UVPROJECT",
    "unwrap_pelt": "UV",
    "candidate": "FILE_TICK",
    "grade": "CHECKMARK",
    "organic": "MOD_SMOOTH",
    "hard_surface": "MESH_CUBE",
    "game": "LIGHT",
    "scan": "VIEWZOOM",
    "trimsheet": "SEQ_STRIP_DUPLICATE",
    "hero": "SOLO_ON",
    "lightmap": "LIGHT",
    "uv_bbox": "PIVOT_BOUNDBOX",
    "group_center_h": "ARROW_LEFTRIGHT",
    "group_center_v": "EMPTY_SINGLE_ARROW",
    "dist_h": "ARROW_LEFTRIGHT",
    "dist_v": "EMPTY_SINGLE_ARROW",
    "unwrap_planar": "UV",
    "unwrap_cylinder": "MESH_CYLINDER",
    "unwrap_sphere": "MESH_UVSPHERE",
    "unwrap_pelt": "MOD_CLOTH",
    "unwrap_peel": "MOD_EDGESPLIT",
    "unwrap_flatten": "MESH_PLANE",
    "unwrap_normal": "ORIENTATION_NORMAL",
}



_CUSTOM_ICON_KEYS = {
    "uv_bbox", "group_center_h", "group_center_v", "dist_h", "dist_v",
    "unwrap_planar", "unwrap_cylinder", "unwrap_sphere", "unwrap_flatten",
    "unwrap_pelt", "unwrap_peel", "unwrap_normal",
}

def _standard_icon(name: str, fallback: str = 'DOT') -> str:
    raw = str(name or '').strip()
    key = raw.lower()
    if key in _STANDARD_ICON_BY_KEY:
        return _STANDARD_ICON_BY_KEY.get(key, fallback)
    # Allow direct Blender icon enum identifiers such as MOD_UVPROJECT,
    # ORIENTATION_GLOBAL, PACKAGE, VIEWZOOM, and TEXTURE.
    if raw and raw.upper() == raw and raw != 'NONE':
        return raw
    return fallback



def unregister() -> None:
    global _ICON_COLLECTION, _LOCALE_MOD_CACHE
    if _ICON_COLLECTION is not None:
        try:
            from . import ownership_runtime_18168 as _ownership
            _ownership.unregister_preview_collection(_ICON_COLLECTION)
        except Exception:
            pass
    _ICON_COLLECTION = None
    _LOCALE_MOD_CACHE = _text_translation
    invalidate_runtime_caches(icons=True)


def _ensure_icons():
    global _ICON_COLLECTION
    if _previews is None:
        return None
    if _ICON_COLLECTION is None:
        try:
            from . import ownership_runtime_18168 as _ownership
            _ICON_COLLECTION = _ownership.register_preview_collection(_previews)
        except Exception:
            _ICON_COLLECTION = None
    return _ICON_COLLECTION


def _load_icon_value(name: str) -> int:
    """Load one preview icon at registration time, never from Panel.draw()."""
    key = str(name or "").strip().lower()
    if not key:
        return 0
    if key in _STANDARD_ICON_BY_KEY and key not in _CUSTOM_ICON_KEYS:
        return 0
    if key in _ICON_CACHE:
        return int(_ICON_CACHE.get(key, 0) or 0)
    collection = _ensure_icons()
    if collection is None:
        _bounded_cache_set(_ICON_CACHE, key, 0, _ICON_CACHE_LIMIT)
        return 0
    filename = _ICON_FILES.get(key) or f"sus_{key}.png"
    path = canonical_icon_path(filename)
    if path is None:
        _bounded_cache_set(_ICON_CACHE, key, 0, _ICON_CACHE_LIMIT)
        return 0
    try:
        preview_key = f"uv_suite_{key}"
        try:
            preview = collection.get(preview_key)
        except Exception:
            preview = None
        if preview is None:
            preview = collection.load(preview_key, str(path), 'IMAGE')
        value = int(getattr(preview, "icon_id", 0) or 0)
    except Exception:
        value = 0
    _bounded_cache_set(_ICON_CACHE, key, value, _ICON_CACHE_LIMIT)
    return value


def _operator_proxy_lifecycle(op_id: str):
    try:
        group, name = str(op_id or '').split('.', 1)
        op_group = getattr(getattr(bpy, 'ops', None), group, None)
        return getattr(op_group, name, None) if op_group is not None else None
    except Exception:
        return None


def _prepare_operator_snapshot() -> None:
    """Resolve known operator RNA exactly once at the lifecycle boundary."""
    global _OPERATOR_RNA_CACHE, _OPERATOR_PROP_CACHE, _LIVE_OPERATOR_CATALOG_CACHE
    rna_map: dict[str, object | None] = {}
    prop_map: dict[str, frozenset[str]] = {}
    catalog: dict[str, tuple[str, str, str]] = {}
    classes = ()
    try:
        from . import ownership_runtime_18168 as _ownership
        classes = _ownership.registered_classes()
    except Exception:
        classes = ()
    for cls in classes:
        try:
            if not isinstance(cls, type) or not issubclass(cls, bpy.types.Operator):
                continue
            op_id = str(getattr(cls, 'bl_idname', '') or '').strip()
        except Exception:
            continue
        if not op_id:
            continue
        rna = getattr(cls, 'bl_rna', None)
        if not _rna_identifier_is_real_operator(getattr(rna, 'identifier', '')):
            rna = None
        if rna is None:
            proxy = _operator_proxy_lifecycle(op_id)
            try:
                get_rna = getattr(proxy, 'get_rna_type', None)
                candidate = get_rna() if callable(get_rna) else None
                if _rna_identifier_is_real_operator(getattr(candidate, 'identifier', '')):
                    rna = candidate
            except Exception:
                rna = None
        rna_map[op_id] = rna
        prop_map[op_id] = frozenset(_rna_property_names_from_container(getattr(rna, 'properties', None))) if rna is not None else frozenset()
        label = str(getattr(cls, 'bl_label', '') or op_id.rsplit('.', 1)[-1])
        desc = str(getattr(cls, 'bl_description', '') or '')
        catalog[op_id] = (op_id, label, desc)
    # UI/native IDs are an explicit build-time literal inventory.  Their RNA is
    # queried here, never from draw/poll.
    for op_id in _STATIC_UI_OPERATOR_IDS:
        # Always prefer the live bpy.ops RNA for the UI inventory.  The owned
        # class ledger can legitimately contain a retired generation with the
        # same bl_idname during an in-place package upgrade; its class RNA may
        # be non-null while exposing no properties for the active operator.
        proxy = _operator_proxy_lifecycle(op_id)
        rna = None
        try:
            get_rna = getattr(proxy, 'get_rna_type', None)
            candidate = get_rna() if callable(get_rna) else None
            if _rna_identifier_is_real_operator(getattr(candidate, 'identifier', '')):
                rna = candidate
        except Exception:
            rna = None
        rna_map[op_id] = rna
        prop_map[op_id] = frozenset(_rna_property_names_from_container(getattr(rna, 'properties', None))) if rna is not None else frozenset()
    _OPERATOR_RNA_CACHE = MappingProxyType(dict(rna_map))
    _OPERATOR_PROP_CACHE = MappingProxyType(dict(prop_map))
    _LIVE_OPERATOR_CATALOG_CACHE = tuple(sorted(catalog.values(), key=lambda item: (item[0].split('.', 1)[0], item[1].lower(), item[0])))


def _prepare_mapped_categories_snapshot() -> None:
    global _MAPPED_CATEGORIES_CACHE
    try:
        from . import rename_catalog as _catalog
        categories = tuple(dict(item) for item in tuple(getattr(_catalog, 'CATEGORY_DEFS', ()) or ()))
        grouped_fn = getattr(_catalog, 'operators_by_category', None)
        raw = grouped_fn() if callable(grouped_fn) else {}
        grouped = {
            str(key): tuple((str(op_id), dict(data)) for op_id, data in tuple(value or ()))
            for key, value in dict(raw or {}).items()
        }
        _MAPPED_CATEGORIES_CACHE = (categories, MappingProxyType(grouped))
    except Exception:
        _MAPPED_CATEGORIES_CACHE = ((), MappingProxyType({}))


def _prepare_help_snapshot() -> None:
    global _HELP_SCOPE_REGISTRY
    items = {}
    for key, en, ja in (
        ('category_workflow', 'Basic Settings', '基本設定'),
        ('category_unwrap', 'UV Unwrap', 'UV展開'),
        ('category_align', 'UV Align', 'UV整列'),
        ('category_pack', 'Packing', 'パッキング'),
        ('category_texel', 'Bake', 'ベイク'),
        ('category_operation', 'Operation', '操作'),
        ('keymap_info', 'Keymap Information', 'キーマップ情報'),
        ('all_tools', 'All Tools', '全ツール'),
    ):
        items[key] = {
            'help_id': key,
            'title_en': en,
            'title_ja': ja,
            'operators': (),
            'properties': (),
        }
    _HELP_SCOPE_REGISTRY = MappingProxyType(items)


def _prepare_public_keymap_rows_snapshot() -> None:
    global _PUBLIC_KEYMAP_ROWS_SNAPSHOT
    rows = []
    try:
        from . import ownership_runtime_18168 as _ownership
        owned = {}
        for km, kmi in _ownership.owned_keymap_items():
            kid = str(getattr(kmi, 'idname', '') or '')
            owned.setdefault(kid, []).append((km, kmi))
        specs = (
            ('INSTANT_SELECT', 'Instant Select Drag Move', '即時選択ドラッグ移動', 'smart_uv_suite.instant_select_drag_move', 'Image Editor / UV Editor tool maps', '画像エディター / UVエディター系ツールマップ'),
            ('UV_GIZMO_GRIP', 'UV Gizmo Grip Assist', 'UVギズモつかみ補助', 'smart_uv_suite.uv_gizmo_grip_fix_grab', 'Image Editor tool maps', '画像エディター系ツールマップ'),
            ('SCALE_BG_SELECT', 'Scale Tool Background Select', 'スケールツール背景選択', 'smart_uv_suite.scale_tool_background_select', 'Image Editor Scale tool maps', '画像エディターのスケールツール系マップ'),
        )
        for key, en, ja, op_id, loc_en, loc_ja in specs:
            exact = tuple(owned.get(op_id, ()))
            active = sum(1 for _km, kmi in exact if bool(getattr(kmi, 'active', False)))
            count = len(exact)
            rows.append(MappingProxyType({
                'id': key,
                'feature_en': en,
                'feature_ja': ja,
                'operator': op_id,
                'location_en': loc_en,
                'location_ja': loc_ja,
                'detail_en': 'Exact Smart UV-owned KeyMapItem identities only.',
                'detail_ja': 'Smart UVが生成した完全一致KeyMapItemのみを管理します。',
                'status_en': f'Registered {count} / Enabled {active}',
                'status_ja': f'登録 {count} / 有効 {active}',
            }))
    except Exception:
        rows = []
    _PUBLIC_KEYMAP_ROWS_SNAPSHOT = tuple(rows)


def register() -> None:
    """Prepare every finite UI resource and immutable draw snapshot."""
    global _LOCALE_MOD_CACHE, _DRAW_IS_JA
    _LOCALE_MOD_CACHE = _text_translation
    invalidate_runtime_caches(icons=False)
    _DRAW_IS_JA = _detect_is_ja(getattr(bpy, 'context', None))
    required = sorted(key for key in _ICON_FILES if key in _CUSTOM_ICON_KEYS or key not in _STANDARD_ICON_BY_KEY)
    for key in required:
        _load_icon_value(key)
    _prepare_operator_snapshot()
    _prepare_mapped_categories_snapshot()
    _prepare_help_snapshot()
    _prepare_public_keymap_rows_snapshot()


def refresh_event_snapshot(context=None) -> None:
    """Refresh finite language/keymap snapshots outside Panel.draw/poll."""
    global _DRAW_IS_JA
    _DRAW_IS_JA = _detect_is_ja(context or getattr(bpy, 'context', None))
    _prepare_public_keymap_rows_snapshot()


def _icon_value(name: str) -> int:
    """Read a preloaded icon id; redraw never loads files or creates previews."""
    key = str(name or "").strip().lower()
    if not key:
        return 0
    if key in _STANDARD_ICON_BY_KEY and key not in _CUSTOM_ICON_KEYS:
        return 0
    return int(_ICON_CACHE.get(key, 0) or 0)


def _locale_mod():
    return _text_translation


def _detect_is_ja(context=None) -> bool:
    """Resolve the Smart UV language, including its FORCE_JA/FORCE_EN setting."""
    try:
        resolver = getattr(_text_translation, 'is_japanese', None)
        if callable(resolver):
            return bool(resolver(context or getattr(bpy, 'context', None)))
    except Exception:
        pass
    try:
        prefs = getattr(context, 'preferences', None) if context is not None else None
        if prefs is None:
            prefs = getattr(getattr(bpy, 'context', None), 'preferences', None)
        view = getattr(prefs, 'view', None)
        lang = str(getattr(view, 'language', '') or '')
    except Exception:
        lang = ''
    normalized = lang.replace('-', '_').lower()
    return normalized.startswith('ja') or normalized.startswith('jp') or normalized == 'default_japanese'



def _sync_draw_language() -> bool:
    """Follow a Blender language change without a file read or a redraw walk."""
    global _DRAW_IS_JA, _DRAW_LANGUAGE
    try:
        language = bpy.context.preferences.view.language
    except Exception:
        return bool(_DRAW_IS_JA)
    if language != _DRAW_LANGUAGE:
        _DRAW_LANGUAGE = language
        _DRAW_IS_JA = _detect_is_ja(bpy.context)
    return bool(_DRAW_IS_JA)


def _is_ja(context=None) -> bool:
    del context
    return _sync_draw_language()



def _tr(context, en: str, ja: str) -> str:
    del context
    return str(ja or '') if _sync_draw_language() else str(en or '')



def _one_line(value: object, limit: int = 80) -> str:
    """Return one-line UI text without applying an artificial character limit."""
    del limit
    return " ".join(str(value or "").translate({13: 32, 10: 32}).split())


def _rna_identifier_is_real_operator(identifier: object) -> bool:
    text = str(identifier or "").strip()
    return bool(text) and text not in {"Operator", "OperatorProperties", "UnknownType", "bpy_struct"}


def _operator_proxy(op_id: str):
    # Draw/poll never resolves bpy.ops dynamically.  This compatibility helper
    # returns the lifecycle-precomputed RNA object instead.
    return _OPERATOR_RNA_CACHE.get(str(op_id or '').strip())


def _operator_rna(op_id: str):
    return _OPERATOR_RNA_CACHE.get(str(op_id or '').strip())


def _operator_exists(op_id: str) -> bool:
    return _operator_rna(op_id) is not None


def _rna_property_names_from_container(prop_defs) -> set[str]:
    names: set[str] = set()
    if prop_defs is None:
        return names
    try:
        names.update(str(key) for key in prop_defs.keys())
    except Exception:
        pass
    try:
        for prop in prop_defs:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if identifier:
                names.add(identifier)
    except Exception:
        pass
    return names


def _operator_property_names(op_id: str) -> set[str]:
    return set(_OPERATOR_PROP_CACHE.get(str(op_id or '').strip(), frozenset()))


def _operator_has_property(op_id: str, prop_name: str) -> bool:
    return str(prop_name or '') in _OPERATOR_PROP_CACHE.get(str(op_id or '').strip(), frozenset())

def _ui_operator_property_names(op) -> set[str]:
    # Operator button properties are validated against the immutable ID snapshot
    # before UILayout.operator is called.  No live RNA cache is built in draw.
    del op
    return set()


def _set_props(op, props: dict | None) -> None:
    if op is None or not props:
        return
    for key, value in dict(props).items():
        try:
            setattr(op, str(key), value)
        except Exception:
            continue

def _draw_help_button(layout, context, help_id: str, title_en: str = '', title_ja: str = '', *, emboss: bool = True):
    """Draw an icon-only lazy help button.

    The actual help module stays unloaded until ``smart_uv_suite.show_help`` is
    clicked, so normal N-panel drawing remains lightweight.
    """
    if not help_id:
        return None
    if not _operator_exists("smart_uv_suite.show_help") or not _operator_has_property("smart_uv_suite.show_help", "help_id"):
        return None
    try:
        try:
            row = layout.row(align=True)
            row.scale_x = 0.82
            row.scale_y = 1.0
        except Exception:
            row = layout
        _help_scope_begin(str(help_id or ''), str(title_en or ''), str(title_ja or ''))
        op = row.operator("smart_uv_suite.show_help", text="", icon='QUESTION', emboss=emboss)
        _set_props(op, {"help_id": str(help_id or ''), "title_en": str(title_en or ''), "title_ja": str(title_ja or '')})
        return op
    except Exception:
        return None


def _box_header(layout, context, label_en: str, label_ja: str, icon: str, help_id: str = ''):
    """Draw a compact group header with a Smart Rig-style Help icon."""
    try:
        row = layout.row(align=True)
        value = _icon_value(icon)
        if value:
            row.label(text=_tr(context, label_en, label_ja), icon_value=value)
        else:
            row.label(text=_tr(context, label_en, label_ja), icon=_standard_icon(icon))
        _draw_help_button(row, context, help_id or '', label_en, label_ja)
        if help_id:
            _help_scope_begin(str(help_id or ''), label_en, label_ja)
        return row
    except Exception:
        try:
            layout.label(text=_tr(context, label_en, label_ja))
        except Exception:
            pass
        return None


def _op(layout, context, op_id: str, label_en: str, label_ja: str, icon: str, props: dict | None = None, *, enabled: bool = True):
    if not _operator_exists(op_id):
        return None
    if props:
        available = _operator_property_names(op_id)
        # If a stale or partially registered operator exists without the required
        # RNA properties, skip the button instead of drawing a command that cannot
        # receive its mode/action/issue settings.  This prevents Blender from
        # printing property-missing warnings and prevents silent wrong-mode runs.
        if not available or any(str(key) not in available for key in dict(props).keys()):
            return None
    row = layout.row(align=True)
    row.enabled = bool(enabled)
    value = _icon_value(icon)
    text = _tr(context, label_en, label_ja)
    try:
        if value:
            op = row.operator(op_id, text=text, icon_value=value)
        else:
            op = row.operator(op_id, text=text, icon=_standard_icon(icon))
        _set_props(op, props)
        _help_scope_register_operator(op_id, label_en, label_ja, props)
        return op
    except Exception:
        return None




def _layout_action(layout, context, action: str, label_en: str = "", label_ja: str = "", icon: str = "layout", *, text: str | None = None, scale_y: float = 1.0):
    row = layout.row(align=True)
    try:
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        pass
    value = _icon_value(icon)
    label = _tr(context, label_en, label_ja) if (label_en or label_ja) else ""
    draw_text = label if text is None else str(text)
    if not _operator_exists("smart_uv_suite.uv_layout_action") or not _operator_has_property("smart_uv_suite.uv_layout_action", "action"):
        return None
    try:
        if value:
            op = row.operator("smart_uv_suite.uv_layout_action", text=draw_text, icon_value=value)
        else:
            op = row.operator("smart_uv_suite.uv_layout_action", text=draw_text, icon=_standard_icon(icon))
        _set_props(op, {"action": str(action or '')})
        _help_scope_register_operator("smart_uv_suite.uv_layout_action", label_en or str(action or ''), label_ja or label_en or str(action or ''), {"action": str(action or '')})
        return op
    except Exception as exc:
        try:
            row.label(text=_one_line(f"{label or action}: {exc}", 72), icon='ERROR')
        except Exception:
            pass
        return None


def _icon_action_row(layout, context, actions: Sequence[tuple], *, scale_y: float = 1.35) -> None:
    row = layout.row(align=True)
    try:
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        pass
    for action, icon, symbol in actions:
        value = _icon_value(icon)
        try:
            if _operator_exists("smart_uv_suite.uv_layout_action") and _operator_has_property("smart_uv_suite.uv_layout_action", "action"):
                if value:
                    op = row.operator("smart_uv_suite.uv_layout_action", text=str(symbol or ""), icon_value=value)
                else:
                    op = row.operator("smart_uv_suite.uv_layout_action", text=str(symbol or ""), icon=_standard_icon(icon))
                _set_props(op, {"action": str(action or '')})
                _help_scope_register_operator("smart_uv_suite.uv_layout_action", str(symbol or action or ''), str(symbol or action or ''), {"action": str(action or '')}, symbol=str(symbol or ''))
            else:
                continue
        except Exception:
            try:
                row.label(text=str(symbol or ""), icon='ERROR')
            except Exception:
                pass

def _grid(layout, context, actions: Sequence[tuple], columns: int = 2) -> None:
    columns = max(1, int(columns or 1))
    index = 0
    while index < len(actions):
        row = layout.row(align=True)
        for _ in range(columns):
            if index >= len(actions):
                try:
                    row.label(text="")
                except Exception:
                    pass
                continue
            action = actions[index]
            index += 1
            try:
                op_id, en, ja, icon, props = action
            except Exception:
                continue
            _op(row, context, op_id, en, ja, icon, props)


def _prop(layout, owner, prop: str, *, text: str | None = None) -> bool:
    if owner is None:
        return False
    try:
        if text is None:
            layout.prop(owner, prop)
        else:
            # Labels passed through _tr() are already resolved to the active UI language.
            # Disable Blender's secondary translation pass so Japanese labels such as
            # 「展開モード」 are not remapped to unrelated catalog phrases.
            layout.prop(owner, prop, text=text, translate=False)
        return True
    except Exception:
        return False


_GRID_FULL_ROW_PROP_TYPES = frozenset({'ENUM', 'POINTER', 'STRING'})


def _grid_prop_needs_full_row(owner, prop: str) -> bool:
    """Return True for a property drawn as ``label: field`` inside one cell.

    Without property split Blender gives such a label only a third of its cell,
    so in a multi-column grid labels like "Margin Method" are cut to
    "Margin Meth…".  These properties get a full-width row instead.
    """
    try:
        rna = owner.bl_rna.properties.get(str(prop))
    except Exception:
        return False
    if rna is None:
        return False
    return str(getattr(rna, 'type', '') or '') in _GRID_FULL_ROW_PROP_TYPES


def _props_two_columns(layout, owner, props: Sequence[str]) -> None:
    pair: list[str] = []
    for prop in props:
        if not prop:
            continue
        if _grid_prop_needs_full_row(owner, prop):
            for p in pair:
                _prop(layout.row(align=True), owner, p)
            pair.clear()
            _prop(layout.row(align=True), owner, prop)
            continue
        pair.append(prop)
        if len(pair) < 2:
            continue
        row = layout.row(align=True)
        for p in pair:
            col = row.column(align=True)
            _prop(col, owner, p)
        pair.clear()
    if pair:
        row = layout.row(align=True)
        for p in pair:
            col = row.column(align=True)
            _prop(col, owner, p)
        try:
            row.label(text="")
        except Exception:
            pass


def _ws(context):
    try:
        scene = getattr(context, "scene", None)
        return getattr(scene, "suv_workspace", None)
    except Exception:
        return None


def _foldout_state(context, key: str, default: bool) -> bool:
    del context
    try:
        fn = getattr(_npanel_store, "peek_foldout", None)
        if callable(fn):
            return bool(fn(str(key), bool(default)))
    except Exception:
        pass
    return bool(default)


def _draw_smart_modeling_section_header(box, context, key: str, label_en: str, label_ja: str, icon: str, *, default: bool = True, help_id: str = ''):
    expanded = _foldout_state(context, key, default)
    title = _tr(context, label_en, label_ja)
    fold_op = "smart_uv_suite.toggle_ui_foldout"
    can_toggle = _operator_exists(fold_op) and _operator_has_property(fold_op, "key") and _operator_has_property(fold_op, "default_open")
    try:
        main = box.row(align=True)
        main.use_property_split = False
        main.use_property_decorate = False
    except Exception:
        main = box
    try:
        if can_toggle:
            op = main.operator(fold_op, text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT', emboss=True, depress=bool(expanded))
            _set_props(op, {"key": str(key), "default_open": bool(default)})
        else:
            main.label(text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
    except Exception:
        try:
            main.label(text='', icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT')
        except Exception:
            pass
    try:
        split = main.split(factor=0.86, align=True)
        title_area = split.row(align=True)
        help_area = split.row(align=True)
        help_area.alignment = 'RIGHT'
        help_area.scale_x = 0.82
        help_area.scale_y = 1.0
    except Exception:
        title_area = main
        help_area = main
    icon_value = _icon_value(icon)
    try:
        if can_toggle:
            if icon_value:
                op = title_area.operator(fold_op, text=title, icon_value=icon_value, emboss=False, depress=bool(expanded))
            else:
                op = title_area.operator(fold_op, text=title, icon=_standard_icon(icon), emboss=False, depress=bool(expanded))
            _set_props(op, {"key": str(key), "default_open": bool(default)})
        else:
            if icon_value:
                title_area.label(text=title, icon_value=icon_value)
            else:
                title_area.label(text=title, icon=_standard_icon(icon))
    except Exception:
        try:
            title_area.label(text=title)
        except Exception:
            pass
    if help_id:
        _draw_help_button(help_area, context, help_id or '', label_en, label_ja)
    return expanded


def _foldout(layout, context, key: str, label_en: str, label_ja: str, icon: str, *, default: bool = True, help_id: str = "", hint_en: str = "", hint_ja: str = "") -> bool:
    try:
        section_layout = layout.column(align=True)
        section_layout.use_property_split = False
        section_layout.use_property_decorate = False
        header_box = section_layout.box()
    except Exception:
        section_layout = layout
        header_box = section_layout
    expanded = _draw_smart_modeling_section_header(header_box, context, key, label_en, label_ja, icon, default=default, help_id=help_id or "")
    del hint_en, hint_ja
    return bool(expanded)


def _top_level_foldout(layout, context, key: str, label_en: str, label_ja: str, icon: str, *, default: bool = True, help_id: str = ""):
    """Draw one shared SmartTools top section and return (box, body, expanded)."""
    try:
        box = layout.box()
        box.use_property_split = False
        box.use_property_decorate = False
    except Exception:
        box = layout
    expanded = _draw_smart_modeling_section_header(
        box,
        context,
        key,
        label_en,
        label_ja,
        icon,
        default=bool(default),
        help_id=help_id or "",
    )
    if not expanded:
        return box, None, False
    try:
        body = box.column(align=True)
        body.use_property_split = False
        body.use_property_decorate = False
        body.separator(factor=0.25)
    except Exception:
        body = box
    return box, body, True


def _section_box(layout):
    # Stateless body layout: draw never writes module/global state.
    try:
        body = layout.column(align=True)
        body.separator(factor=0.25)
        return body
    except Exception:
        return layout


def _draw_workspace_status(layout, context) -> None:
    ws = _ws(context)
    box = _section_box(layout)
    try:
        obj = getattr(context, "active_object", None)
        mesh_state = _tr(context, "No active mesh", "アクティブメッシュなし")
        if obj is not None and getattr(obj, "type", "") == 'MESH':
            data = getattr(obj, "data", None)
            uv_count = len(getattr(data, "uv_layers", []) or []) if data is not None else 0
            mesh_state = _tr(context, f"Active mesh: {obj.name} / UV maps: {uv_count}", f"アクティブメッシュ: {obj.name} / UVマップ: {uv_count}")
        box.label(text=mesh_state, icon='MESH_DATA')
    except Exception:
        pass
    try:
        row = box.row(align=True)
        _op(row, context, "uv.suv_workspace_validate", "Validate", "検証", "quality", None)
        _op(row, context, "uv.suv_workspace_auto_repair", "Auto Repair", "自動修復", "repair", None)
    except Exception:
        pass
    if ws is not None:
        try:
            row = box.row(align=True)
            _prop(row, ws, "show_dashboard")
        except Exception:
            pass


def _draw_always_on(layout, context, always_on_draw) -> None:
    # The authoritative N-panel does not call back into the layered __init__.py
    # draw helpers.  Keeping this dependency explicit at module load makes the
    # complete draw call graph finite and prevents deferred import/registration
    # side effects during sidebar redraw.
    del always_on_draw
    try:
        _controls.draw_top_group(layout, context)
    except Exception as exc:
        try:
            layout.label(text=_one_line(exc), icon='ERROR')
        except Exception:
            pass




def _smart_uv_excellence_module():
    try:
        from . import smart_uv_excellence as _excellence
        return _excellence
    except Exception:
        return None


def _excellence_label(action: str, context) -> str:
    mod = _smart_uv_excellence_module()
    if mod is not None:
        label_fn = getattr(mod, "action_label", None)
        if callable(label_fn):
            try:
                return str(label_fn(action, context) or action)
            except Exception:
                pass
    return str(action or "")


def _excellence_action_button(layout, context, action: str, *, text: str | None = None, icon: str = "excellence", scale_y: float = 1.22) -> bool:
    op_id = "smart_uv_suite.excellence_action"
    if not _operator_exists(op_id) or not _operator_has_property(op_id, "action"):
        return False
    row = layout.row(align=True)
    try:
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        pass
    label = str(text if text is not None else _excellence_label(action, context))
    try:
        iv = _icon_value(icon)
        if iv:
            op = row.operator(op_id, text=label, icon_value=iv)
        else:
            op = row.operator(op_id, text=label, icon=_standard_icon(icon))
        _set_props(op, {"action": str(action or "")})
        _help_scope_register_operator(op_id, label, label, {"action": str(action or "")})
        return True
    except Exception:
        return False


def _draw_excellence_command_deck(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_excellence_deck", 'UV Suite Command Deck', 'UV Suite コマンドデッキ', "excellence",
        default=True,
        help_id="smart_uv_excellence",
        hint_en="High-precision, asset-specific one-click routes.  Use Director Auto first, then refine with asset buttons or run a score report.",
        hint_ja="高精度・アセット別のワンクリック入口です。まず統合ディレクターを使い、必要に応じてアセット別ボタンやスコアレポートで詰めます。",
    ):
        return
    box = _section_box(layout)
    try:
        report = {}
        mod = _smart_uv_excellence_module()
        if mod is not None and callable(getattr(mod, "last_report", None)):
            report = mod.last_report() or {}
        grade = ((report.get('after_grade') or {}) if isinstance(report, dict) else {})
        if grade:
            row = box.row(align=True)
            row.label(text=_tr(context, f"Last score: {grade.get('grade', '-')} / {grade.get('score', '-')}", f"直近スコア: {grade.get('grade', '-')} / {grade.get('score', '-')}") , icon=_standard_icon('grade'))
    except Exception:
        pass

    hero = box.box()
    try:
        _box_header(hero, context, "One-click production", "ワンクリック制作", "command", "excellence_one_click")
    except Exception:
        pass
    row = hero.row(align=True)
    _excellence_action_button(row, context, "DIRECTOR_AUTO", text=_tr(context, "Director Auto", "統合ディレクター"), icon="excellence", scale_y=1.45)
    _excellence_action_button(row, context, "PACK_SUPREME", text=_tr(context, "Supreme Pack", "最高密度パック"), icon="candidate", scale_y=1.45)
    _excellence_action_button(row, context, "REPORT_SCORE", text=_tr(context, "Score", "スコア"), icon="grade", scale_y=1.45)

    asset = box.box()
    try:
        _box_header(asset, context, "Asset route", "アセット別ルート", "advisor", "excellence_asset_routes")
    except Exception:
        pass
    rows = (
        (("ORGANIC_UNWRAP", "Organic", "有機", "organic"), ("HARD_SURFACE", "Hard Surface", "ハードサーフェス", "hard_surface"), ("TRIM_PREP", "Trim Prep", "トリム準備", "trimsheet")),
        (("UDIM_PRODUCTION", "UDIM", "UDIM", "udim"), ("GAME_LIGHTMAP", "Lightmap", "ライトマップ", "game"), ("SCAN_CLEANUP", "Scan Clean", "スキャン修復", "scan")),
        (("DENSITY_AUDIT", "Density", "密度", "density"), ("DISTORTION_AUDIT", "Distortion", "歪み", "inspect"), ("ADAPTIVE_AUTO", "Safe Auto", "安全自動", "quality")),
    )
    for defs in rows:
        r = asset.row(align=True)
        for action, en, ja, icon in defs:
            _excellence_action_button(r, context, action, text=_tr(context, en, ja), icon=icon, scale_y=1.18)

    # Detailed improvement notes are available from the Help icon.


def _smart_uv_smart_module():
    try:
        from . import smart_uv_smart as _smart
        return _smart
    except Exception:
        return None


def _smart_uv_smart_action_button(layout, context, action: str, *, text: str | None = None, icon: str = "magic", scale_y: float = 1.15) -> bool:
    op_id = "smart_uv_suite.smart_uv_smart_action"
    if not _operator_exists(op_id) or not _operator_has_property(op_id, "action"):
        return False
    smart = _smart_uv_smart_module()
    label = str(text if text is not None else (smart.get_action_label(action, context) if smart and hasattr(smart, "get_action_label") else action))
    row = layout.row(align=True)
    try:
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        pass
    try:
        value = _icon_value(icon)
        if value:
            op = row.operator(op_id, text=label, icon_value=value)
        else:
            op = row.operator(op_id, text=label, icon=_standard_icon(icon))
        _set_props(op, {"action": str(action or "")})
        _help_scope_register_operator(op_id, label, label, {"action": str(action or "")})
        return True
    except Exception:
        return False


def _smart_uv_smart_action_grid(layout, context, actions: Sequence[str], *, columns: int = 2, icon: str = "magic") -> None:
    smart = _smart_uv_smart_module()
    actions = [str(a or "") for a in actions if str(a or "").strip()]
    columns = max(1, int(columns or 1))
    index = 0
    while index < len(actions):
        row = layout.row(align=True)
        for _ in range(columns):
            if index >= len(actions):
                try:
                    row.label(text="")
                except Exception:
                    pass
                continue
            action = actions[index]
            index += 1
            label = action
            if smart and hasattr(smart, "get_action_label"):
                try:
                    label = str(smart.get_action_label(action, context) or action)
                except Exception:
                    label = action
            _smart_uv_smart_action_button(row, context, action, text=label, icon=icon, scale_y=1.05)


def _smart_uv_smart_feature_button(layout, context, entry: dict) -> bool:
    op_id = "smart_uv_suite.smart_uv_smart_feature"
    if not _operator_exists(op_id) or not _operator_has_property(op_id, "feature_key"):
        return False
    key = str((entry or {}).get("key") or "")
    if not key:
        return False
    feature = str((entry or {}).get("feature") or key)
    tool = str((entry or {}).get("tool") or "")
    label_en = _one_line(f"{feature} — {tool}" if tool else feature, 64)
    label_ja = label_en
    try:
        row = layout.row(align=True)
        value = _icon_value("tool")
        op = row.operator(op_id, text=label_en, icon_value=value) if value else row.operator(op_id, text=label_en, icon=_standard_icon('tool'))
        _set_props(op, {"feature_key": key, "label_en": label_en, "label_ja": label_ja})
        _help_scope_register_operator(op_id, label_en, label_ja, {"feature_key": key, "label_en": label_en, "label_ja": label_ja})
        return True
    except Exception:
        return False




def _draw_visual_reference_deck(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_visual_reference_deck", "Visual Workflow Reference", "視覚ワークフローリファレンス", "visual_reference",
        default=True,
        help_id="visual_reference_deck",
        hint_en="Large, frame-free reference cards for the intended UV flow: analyze -> repair -> density -> pack -> inspect.",
        hint_ja="解析 → 修復 → 密度 → パック → 検査のUVフローを、枠無しの大きな参照カードで確認できます。",
    ):
        return
    box = _section_box(layout)
    row = box.row(align=True)
    refs = (("ref_flow", "Analyze→Repair→Pack", "解析→修復→パック"), ("ref_score", "Score / Grade", "スコア / グレード"), ("ref_density", "Density / Stretch", "密度 / 歪み"))
    for icon, en, ja in refs:
        col = row.column(align=True)
        iv = _icon_value(icon)
        try:
            if iv:
                col.label(text="", icon_value=iv)
            else:
                col.label(text="", icon=_standard_icon(icon, 'DOT'))
            col.label(text=_tr(context, en, ja))
        except Exception:
            try:
                col.label(text=_tr(context, en, ja), icon=_standard_icon(icon, 'DOT'))
            except Exception:
                pass
    quick = box.row(align=True)
    try:
        quick.scale_y = 1.35
    except Exception:
        pass
    if _operator_exists("smart_uv_suite.cockpit_run") and _operator_has_property("smart_uv_suite.cockpit_run", "intent"):
        for intent, en, ja, icon in (("PRODUCTION_FINISH", "Finish", "仕上げ", "cockpit"), ("HERO_ASSET", "Hero", "ヒーロー", "hero"), ("REPAIR_PACK", "Repair Pack", "修復パック", "repair")):
            try:
                iv = _icon_value(icon)
                op = quick.operator("smart_uv_suite.cockpit_run", text=_tr(context, en, ja), icon_value=iv) if iv else quick.operator("smart_uv_suite.cockpit_run", text=_tr(context, en, ja), icon=_standard_icon(icon))
                _set_props(op, {"intent": intent})
                _help_scope_register_operator("smart_uv_suite.cockpit_run", en, ja, {"intent": intent})
            except Exception:
                pass

def _draw_smart_uv_cockpit(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_smart_uv_cockpit", 'UV Suite Cockpit', 'UV Suiteコックピット', "quality",
        default=True,
        help_id="smart_uv_cockpit",
        hint_en="Production-oriented control center: apply quality profiles, run short intent routes, check score, and tune precision without opening Preferences.",
        hint_ja="制作向けの操作センターです。品質プロファイル適用、目的別ルート実行、スコア確認、精度調整をプリファレンスなしで行います。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            status = box.box()
            row = status.row(align=True)
            _box_header(status, context, "Quality Score", "品質スコア", "quality", "cockpit_quality_score")
            score = getattr(ws, "smart_last_score", 0.0)
            grade = getattr(ws, "smart_last_grade", "N/A")
            action = getattr(ws, "smart_last_action", "")
            row.label(text=f"{float(score):.1f} / 100  {grade}")
            if action:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        try:
            cfg = box.box()
            _box_header(cfg, context, "Saved precision controls", "保存される精度設定", "settings", "cockpit_precision_controls")
            _props_two_columns(cfg, ws, (
                "smart_relax_iterations", "smart_pack_candidates",
                "smart_margin_strategy", "smart_lock_overlaps", "smart_sliver_protection", "smart_ui_density",
            ))
        except Exception:
            pass
    if _operator_exists("smart_uv_suite.cockpit_analyze"):
        top = box.row(align=True)
        try:
            top.scale_y = 1.25
        except Exception:
            pass
        value = _icon_value("inspect")
        try:
            if value:
                top.operator("smart_uv_suite.cockpit_analyze", text=_tr(context, "Analyze", "解析"), icon_value=value)
            else:
                top.operator("smart_uv_suite.cockpit_analyze", text=_tr(context, "Analyze", "解析"), icon='VIEWZOOM')
            _help_scope_register_operator("smart_uv_suite.cockpit_analyze", "Analyze", "解析", {})
        except Exception:
            pass
    if _operator_exists("smart_uv_suite.cockpit_run") and _operator_has_property("smart_uv_suite.cockpit_run", "intent"):
        runbox = box.box()
        _box_header(runbox, context, "Intent routes", "目的別ルート", "magic", "cockpit_intent_routes")
        intents = (
            ("PRODUCTION_FINISH", "Finish", "仕上げ", "quality"),
            ("HERO_ASSET", "Hero", "ヒーロー", "density"),
            ("HARD_SURFACE", "Hard Surface", "ハードサーフェス", "rectify"),
            ("ORGANIC", "Organic", "有機形状", "relax"),
            ("LIGHTMAP", "Lightmap", "ライトマップ", "bake"),
            ("UDIM_MASTER", "UDIM", "UDIM", "udim"),
            ("REPAIR_PACK", "Repair + Pack", "修復+パック", "repair"),
            ("ONLY_ANALYZE", "Score Only", "スコアのみ", "report"),
        )
        index = 0
        while index < len(intents):
            row = runbox.row(align=True)
            try:
                row.scale_y = 1.18
            except Exception:
                pass
            for _ in range(2):
                if index >= len(intents):
                    try: row.label(text="")
                    except Exception: pass
                    continue
                intent, en, ja, icon = intents[index]; index += 1
                iv = _icon_value(icon)
                try:
                    op = row.operator("smart_uv_suite.cockpit_run", text=_tr(context, en, ja), icon_value=iv) if iv else row.operator("smart_uv_suite.cockpit_run", text=_tr(context, en, ja), icon=_standard_icon(icon))
                    _set_props(op, {"intent": intent})
                    _help_scope_register_operator("smart_uv_suite.cockpit_run", en, ja, {"intent": intent})
                except Exception:
                    pass
    if _operator_exists("smart_uv_suite.cockpit_apply_profile") and _operator_has_property("smart_uv_suite.cockpit_apply_profile", "profile"):
        prof = box.box()
        _box_header(prof, context, "Quality profiles", "品質プロファイル", "preset", "cockpit_quality_profiles")
        profiles = (
            ("PRODUCTION", "Production", "制作標準"), ("HERO", "Hero", "ヒーロー"),
            ("HARD_SURFACE", "Hard", "ハード"), ("ORGANIC", "Organic", "有機"),
            ("LIGHTMAP", "Lightmap", "ライト"), ("UDIM", "UDIM", "UDIM"),
            ("TRIM", "Trim", "トリム"),
        )
        row = None
        for i, (profile, en, ja) in enumerate(profiles):
            if i % 3 == 0:
                row = prof.row(align=True)
            try:
                op = row.operator("smart_uv_suite.cockpit_apply_profile", text=_tr(context, en, ja), icon=_standard_icon('preset'))
                _set_props(op, {"profile": profile})
                _help_scope_register_operator("smart_uv_suite.cockpit_apply_profile", en, ja, {"profile": profile})
            except Exception:
                pass

def _draw_smart_uv_smart(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_smart_uv_smart", 'UV Suite Smart', 'UV Suite Smart', "magic",
        default=True,
        help_id="smart_uv_smart",
        hint_en='Document-synced upper-integrated UV layer.  It maps features from the attached research lists to local UV Suite routes without copying third-party code.',
        hint_ja='添付調査リスト同期の上位互換UVレイヤーです。第三者コードをコピーせず、各機能をUV Suite内の互換ルートへ割り当てます。',
    ):
        return
    smart = _smart_uv_smart_module()
    box = _section_box(layout)
    top = box.row(align=True)
    _smart_uv_smart_action_button(top, context, "SUPER_AUTO", text=_tr(context, "Supreme", "最高精度"), icon="quality", scale_y=1.2)
    _smart_uv_smart_action_button(top, context, "FULL_AUTO", text=_tr(context, "Full Auto", "全自動"), icon="magic", scale_y=1.2)
    _smart_uv_smart_action_button(top, context, "PACK_HEURISTIC", text=_tr(context, "Dense Pack", "高密度パック"), icon="pack", scale_y=1.2)
    if _operator_exists("smart_uv_suite.smart_uv_smart_write_matrix"):
        try:
            value = _icon_value("report")
            if value:
                top.operator("smart_uv_suite.smart_uv_smart_write_matrix", text=_tr(context, "Matrix", "対応表"), icon_value=value)
            else:
                top.operator("smart_uv_suite.smart_uv_smart_write_matrix", text=_tr(context, "Matrix", "対応表"), icon='TEXT')
            _help_scope_register_operator("smart_uv_suite.smart_uv_smart_write_matrix", "Matrix", "対応表", {})
        except Exception:
            pass

    try:
        groups = list(smart.get_quick_groups() if smart and hasattr(smart, "get_quick_groups") else [])
    except Exception:
        groups = []
    if not groups:
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return

    for group in groups:
        try:
            key = str(group.get("key") or "smart_uv_smart_group")
            title_en = str(group.get("title_en") or key)
            title_ja = str(group.get("title_ja") or title_en)
            icon = str(group.get("icon") or "magic")
            actions = list(group.get("actions") or [])
        except Exception:
            continue
        if not actions:
            continue
        if not _foldout(box, context, key, title_en, title_ja, icon, default=key.endswith("auto"), help_id="smart_uv_smart"):
            continue
        sub = box.box()
        _smart_uv_smart_action_grid(sub, context, actions, columns=2, icon=icon)

    if _foldout(box, context, "smart_uv_smart_document_matrix", "Document Feature Matrix", "文書機能マトリクス", "report", default=False, help_id="smart_uv_smart"):
        try:
            doc_groups = list(smart.document_feature_groups() if smart and hasattr(smart, "document_feature_groups") else [])
        except Exception:
            doc_groups = []
        if not doc_groups:
            try:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            except Exception:
                pass
        for group in doc_groups:
            try:
                category = str(group.get("category") or "Other")
                items = list(group.get("items") or [])
            except Exception:
                continue
            if not items:
                continue
            if not _foldout(box, context, f"smart_uv_smart_doc_{category}", f"{category} ({len(items)})", f"{category} ({len(items)})", "tool", default=False, help_id="smart_uv_smart"):
                continue
            sub = box.box()
            for entry in items[:80]:
                _smart_uv_smart_feature_button(sub, context, entry)
            if len(items) > 80:
                try:
                    pass  # INFO-note moved to Help; no in-section info-icon explanation.
                except Exception:
                    pass

def _draw_uv_layout_board(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_uv_layout_board", "UV Layout Board", "UVレイアウトボード", "layout_board",
        default=True,
        help_id="uv_layout_board",
        hint_en="Smart UV compact compact layout buttons for the UV operations used most often: crop, fill, align, rotate, mirror, straighten, density, and issue selection.",
        hint_ja="よく使うUV操作をスマートUVにまとめたコンパクトボードです。クロップ、フィル、整列、回転、反転、直線化、密度、問題選択を素早く実行できます。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            cfg = box.row(align=True)
            _prop(cfg, ws, "canvas_size", text=_tr(context, "Size", "サイズ"))
            _prop(cfg, ws, "fit_padding_px", text=_tr(context, 'Padding Panel', "余白"))
        except Exception:
            pass

    primary = box.box()
    _box_header(primary, context, "Tile Frame / Sort", "タイル収め / 並べ替え", "fit", "uv_layout_tile_sort")
    row = primary.row(align=True)
    _layout_action(row, context, "CROP", "Crop", "クロップ", "crop", scale_y=1.35)
    _layout_action(row, context, "FILL", "Fill", "フィル", "fill", scale_y=1.35)
    _layout_action(row, context, "FIT", "Fit", "フィット", "fit", scale_y=1.35)
    _op(row, context, "uv.suv_pack_pro", "Pack", "パック", "pack", None)
    row = primary.row(align=True)
    _layout_action(row, context, "SORT_H", "Sort H", "横整列", "sort_h")
    _layout_action(row, context, "SORT_V", "Sort V", "縦整列", "sort_v")
    _layout_action(row, context, "DISTRIBUTE_H", "Spread H", "横均等", "distribute_h")
    _layout_action(row, context, "DISTRIBUTE_V", "Spread V", "縦均等", "distribute_v")

    align_box = box.box()
    _box_header(align_box, context, "Align Pad", "整列パッド", "align", "uv_layout_align_pad")
    pad_row = align_box.row(align=True)
    pad = pad_row.column(align=True)
    _icon_action_row(pad, context, (("ALIGN_TL", "align_tl", ""), ("ALIGN_TOP", "align_top", ""), ("ALIGN_TR", "align_tr", "")), scale_y=1.28)
    _icon_action_row(pad, context, (("ALIGN_LEFT", "align_left", ""), ("ALIGN_CENTER", "align_center", ""), ("ALIGN_RIGHT", "align_right", "")), scale_y=1.28)
    _icon_action_row(pad, context, (("ALIGN_BL", "align_bl", ""), ("ALIGN_BOTTOM", "align_bottom", ""), ("ALIGN_BR", "align_br", "")), scale_y=1.28)
    axis_col = pad_row.column(align=True)
    _layout_action(axis_col, context, "ALIGN_H", "Horizontal Center", "横中心", "align_h", text="H")
    _layout_action(axis_col, context, "ALIGN_V", "Vertical Center", "縦中心", "align_v", text="V")

    transform = box.box()
    _box_header(transform, context, "Transform / Clean Shape", "変形 / 形状整理", "transform", "uv_layout_transform_clean")
    row = transform.row(align=True)
    _layout_action(row, context, "ROTATE_CCW", "90° CCW", "90°左", "rotate_ccw")
    _layout_action(row, context, "ROTATE_CW", "90° CW", "90°右", "rotate_cw")
    _layout_action(row, context, "MIRROR_H", "Mirror H", "左右反転", "mirror_h")
    _layout_action(row, context, "MIRROR_V", "Mirror V", "上下反転", "mirror_v")
    row = transform.row(align=True)
    _layout_action(row, context, "ORIENT_BBOX", "Orient", "方向補正", "orient_bbox")
    _layout_action(row, context, "ORIENT_EDGE", "Edge", "辺基準", "orient_edge")
    _layout_action(row, context, "STRAIGHT", "Straight", "直線化", "straight")
    _layout_action(row, context, "RECTIFY", "Rectify", "矩形化", "rectify")
    row = transform.row(align=True)
    _layout_action(row, context, "GRIDIFY", "Grid", "グリッド", "gridify")
    _layout_action(row, context, "SQUAREIFY", "Square", "正方形", "squareify")
    _layout_action(row, context, "RELAX", "Relax", "リラックス", "relax")
    _layout_action(row, context, "STITCH", 'Stitch UVs', "ステッチ", "stitch")
    row = transform.row(align=True)
    _layout_action(row, context, "WELD", "Weld", "ウェルド", "weld")
    _layout_action(row, context, "PIN", "Pin", "ピン", "pin")
    _layout_action(row, context, "UNPIN", "Unpin", "ピン解除", "unpin")
    _op(row, context, "uv.suv_clear_pins", "Clear Pins", "全ピン解除", "pin", None)

    unwrap = box.box()
    _box_header(unwrap, context, 'Unfold Trim', "展開 / 投影", "unwrap", "uv_layout_unwrap_projection")
    row = unwrap.row(align=True)
    _op(row, context, "uv.suv_auto_unwrap_pro", "Smart Unwrap", 'スマート展開', "unwrap", None)
    _op(row, context, "uv.suv_native_projection", "Best Fit", "最適投影", "project", {"mode": "BEST_FIT"})
    _op(row, context, "uv.suv_native_projection", "Quads", "四角面", "follow_quads", {"mode": "FOLLOW_QUADS"})
    _op(row, context, "uv.suv_native_projection", "Lightmap", "ライトマップ", "pack", {"mode": "LIGHTMAP"})

    density = box.box()
    _box_header(density, context, "Texel / Select", "密度 / 選択", "density", "uv_layout_texel_select")
    row = density.row(align=True)
    _op(row, context, "uv.suv_texel_get", "Pick", "取得", "density_pick", None)
    _op(row, context, "uv.suv_texel_set", "Apply", "適用", "density_apply", None)
    _op(row, context, "uv.suv_texel_normalize", 'Normalize Texel Density', "正規化", "density_normalize", None)
    _op(row, context, "smart_uv_suite.checker_create", "Checker", "チェッカー", "checker", None)
    row = density.row(align=True)
    _op(row, context, "uv.suv_select_similar_islands", "Similar", "類似", "select_similar", None)
    _op(row, context, "uv.suv_select_identical_islands", "Identical", "同一", "select_identical", None)
    _op(row, context, "uv.suv_inspector_select", "Overlap", "重なり", "select_overlap", {"issue": "OVERLAP", "auto_scan": True, "apply_mode": "REPLACE"})
    _op(row, context, "uv.suv_select_zero_islands", "Zero", "ゼロ", "select_zero", None)
    row = density.row(align=True)
    _op(row, context, "uv.suv_inspector_select", 'Check Flipped', "反転", "select_flipped", {"issue": "FLIPPED", "auto_scan": True, "apply_mode": "REPLACE"})
    _op(row, context, "uv.suv_select_uv_boundary", "Bounds", "境界", "select_bounds", None)
    _op(row, context, "uv.suv_select_udim_crossing", "UDIM", "UDIM", "udim", None)
    _op(row, context, "uv.suv_inspector_scan", "Scan", "検査", "inspect", None)

def _draw_settings(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_settings", "Panel Settings / Shared Values", "パネル設定 / 共通値", "settings",
        default=True,
        help_id="settings",
        hint_en="These values are stored from the N-panel and reused by projection, packing, checker, density, and report tools.",
        hint_ja="ここで設定した値はNパネルから保存され、投影・パック・チェッカー・密度・レポートで共通利用されます。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is None:
        try:
            box.label(text=_tr(context, "Workspace settings are not registered yet.", "ワークスペース設定がまだ登録されていません。"), icon='ERROR')
        except Exception:
            pass
        return
    _props_two_columns(box, ws, (
        "canvas_size", "workflow_density",
        "fit_padding_px", "uv_new_name",
        "checker_size_width", "checker_size_height",
        "checker_tile_count_u", "checker_tile_count_v",
        "checker_image_name", "checker_material_name", "scan_report_name",
        "heatmap_max", "stretch_threshold",
    ))
    try:
        sub = box.box()
        _box_header(sub, context, "Layout grouping", "レイアウトのグループ設定", "layout", "settings_layout_grouping")
        _props_two_columns(sub, ws, ("pack_group_mode", "pack_group_layout", "stack_group_mode", "similarity_area_tol", "similarity_aspect_tol"))
    except Exception:
        pass
    _grid(box, context, (
        ("uv.suv_workspace_settings_io", "Import / Export Settings", "設定の入出力", "preset", {"mode": "EXPORT_TEXT"}),
        ("uv.suv_workspace_reset", "Reset Workspace", "ワークスペース初期化", "cleanup", None),
        ("uv.suv_apply_workflow_preset", "Workflow Preset", "ワークフロープリセット", "preset", None),
        ("uv.suv_apply_display_preset", "Display Preset", "表示プリセット", "preset", None),
    ), columns=2)


def _draw_quick(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_quick", "Quick Start", "クイック開始", "quick",
        default=True,
        help_id="quick_start",
        hint_en="Most common start-to-finish UV operations are grouped here.",
        hint_ja="よく使う開始から仕上げまでのUV操作をまとめています。",
    ):
        return
    box = _section_box(layout)
    _grid(box, context, (
        ("uv.suv_auto_unwrap_pro", "Smart Unwrap Pro", "スマート展開 Pro", "unwrap", None),
        ("uv.suv_pack_pro", "Pack Pro", "パック Pro", "pack", None),
        ("uv.suv_inspector_scan", "Scan UV", "UV検査", "inspect", None),
        ("smart_uv_suite.checker_create", "Create Checker", "チェッカー作成", "checker", None),
        ("uv.suv_texel_get", "Get Density", "密度取得", "density", None),
        ("uv.suv_texel_set", "Set Density", "密度適用", "density", None),
    ), columns=2)


def _draw_cut_unwrap(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_cut_unwrap", "Cut / Unwrap / Projection", "カット / 展開 / 投影", "unwrap",
        default=True,
        help_id="cut_unwrap",
        hint_en="Create seams, unwrap with Blender-native methods, and choose projection types by shape.",
        hint_ja="シーム作成、Blender標準展開、形状別の投影方式をまとめています。",
    ):
        return
    box = _section_box(layout)
    seam = box.box(); _box_header(seam, context, "Seams", "シーム", "seam", "cut_unwrap_seams")
    _grid(seam, context, (
        ("uv.suv_smart_seams", "Smart Seams", "スマートシーム", "seam", None),
        ("uv.suv_auto_seam_advanced", "Auto Seam: Angle", "自動シーム: 角度", "seam", {"mode": "ANGLE"}),
        ("uv.suv_auto_seam_advanced", "Auto Seam: Sharp", "自動シーム: シャープ", "seam", {"mode": "SHARP"}),
        ("uv.suv_auto_seam_advanced", "Auto Seam: Material", "自動シーム: マテリアル", "seam", {"mode": "MATERIAL"}),
        ("uv.suv_native_uv_action", "Mark Seam", "シーム付与", "seam", {"mode": "MARK_SEAM"}),
        ("uv.suv_native_uv_action", "Clear Seam", "シーム解除", "seam", {"mode": "CLEAR_SEAM"}),
        ("uv.suv_native_uv_action", "Seams From Islands", "アイランドからシーム", "seam", {"mode": "SEAMS_FROM_ISLANDS"}),
        ("mesh.suv_clear_seams", "Clear Mesh Seams", "メッシュシーム全解除", "cleanup", None),
    ), columns=2)
    unwrap = box.box(); _box_header(unwrap, context, 'Unfold Trim', "展開 / 投影", "project", "cut_unwrap_projection")
    _grid(unwrap, context, (
        ("uv.suv_auto_unwrap_pro", "Smart Unwrap", "スマート展開", "unwrap", None),
        ("uv.suv_native_projection", "Best Fit Projection", "最適投影", "project", {"mode": "BEST_FIT"}),
        ("uv.suv_native_projection", "Follow Quads", "四角面に追従", "unwrap", {"mode": "FOLLOW_QUADS"}),
        ("uv.suv_native_projection", "Lightmap Pack", "ライトマップパック", "pack", {"mode": "LIGHTMAP"}),
        ("uv.suv_projection_bridge", "Camera Planar", "カメラ平面", "bridge", {"mode": "CAMERA_PLANAR"}),
        ("uv.suv_projection_bridge", "Normal Auto", "法線自動", "bridge", {"mode": "NORMAL_AUTO"}),
        ("suv.constraint_unwrap", "Constraint Unwrap", "拘束展開", "unwrap", None),
        ("uv.suv_constraint_relax_preserve", "Relax Preserve", "保持リラックス", "straight", None),
    ), columns=2)


def _draw_transform(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_transform", "Align / Straighten / Transform", "整列 / 直線化 / 変形", "transform",
        default=False,
        help_id="transform",
        hint_en="Use these after unwrapping to make UVs readable, straight, centered, and consistent.",
        hint_ja="展開後のUVを読みやすく、直線的に、中央揃えで、一貫した配置に整えます。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            cfg = box.box(); _box_header(cfg, context, "Line / Flow settings", "ライン / フロー設定", "straight", "transform_line_flow_settings")
            _props_two_columns(cfg, ws, ("uv_chain_group_mode", "uv_chain_axis_mode", "uv_chain_endpoint_mode", "uv_flow_strength"))
        except Exception:
            pass
    _grid(box, context, (
        ("uv.suv_align_islands", "Align Islands", "アイランド整列", "align", None),
        ("uv.suv_centralize_islands", 'Center Islands', "中央配置", "align", None),
        ("uv.suv_orient_to_edge", "Orient to Edge", "辺に向ける", "rotate", None),
        ("uv.suv_distribute_islands", "Distribute", "均等配置", "layout", None),
        ("uv.suv_straight_line", 'Straighten Line', "直線化", "straight", None),
        ("uv.suv_set_flow", "Set Flow", "フロー設定", "straight", None),
        ("uv.suv_hs_orthogonalize", 'Orthogonalize UVs', "直交化", "straight", None),
        ("uv.suv_hs_gridify", "Gridify", "グリッド化", "layout", None),
        ("uv.suv_hs_squareify", "Squareify", "正方形化", "scale", None),
        ("uv.suv_hs_rectify_fit", 'Fit Rectified Shape', "矩形化フィット", "scale", None),
        ("uv.suv_rotate_islands", "Rotate", "回転", "rotate", None),
        ("uv.suv_flip_islands", "Flip", "反転", "flip", None),
        ("uv.suv_randomize_islands", "Randomize", "ランダム化", "magic", None),
        ("uv.suv_explode_islands", "Explode", "展開表示", "transform", None),
        ("uv.suv_crop_tile", "Crop to Tile", "タイルにクロップ", "scale", None),
        ("uv.suv_fill_tile", "Fill Tile", "タイルにフィル", "scale", None),
    ), columns=2)


def _draw_layout_pack(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_layout_pack", "Packing / Layout / Stack / UDIM", "パック / 配置 / スタック / UDIM", "pack",
        default=False,
        help_id="layout_pack",
        hint_en="Pack islands, stack matching shapes, distribute groups, and move layouts across UDIM tiles.",
        hint_ja="アイランドのパック、同形状スタック、グループ配置、UDIM移動をまとめています。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            cfg = box.box(); _box_header(cfg, context, "Packing settings", "パック設定", "pack", "layout_pack_settings")
            _props_two_columns(cfg, ws, ("pack_group_mode", "pack_group_layout", "stack_group_mode", "fit_padding_px"))
        except Exception:
            pass
    _grid(box, context, (
        ("uv.suv_pack_pro", "Pack Pro", "パック Pro", "pack", None),
        ("uv.suv_priority_density_pack", "Priority Density Pack", "優先密度パック", "pack", None),
        ("uv.suv_density_guard_normalize", "Density Guard", "密度ガード", "density", None),
        ("uv.suv_fit_to_bounds", "Fit to Bounds", "範囲にフィット", "scale", None),
        ("uv.suv_layout_autoheal", "Layout Autoheal", "配置自動修復", "repair", None),
        ("uv.suv_layout_preflight_audit", "Layout Preflight", "配置事前検査", "inspect", None),
        ("uv.suv_stack_grouped", "Stack Grouped", "グループスタック", "stack", None),
        ("uv.suv_stack_topology_groups", "Stack Topology", "トポロジースタック", "stack", None),
        ("uv.suv_stack_symmetry_topology", "Stack Symmetry", "対称スタック", "symmetry", None),
        ("uv.suv_unstack_groups", "Unstack Groups", "グループ解除", "stack", None),
        ("uv.suv_unstack_overlapped", "Unstack Overlap", "重なり解除", "stack", None),
        ("uv.suv_groups_to_tiles", 'Move Groups to Tiles', "グループをタイルへ", "udim", None),
        ("uv.suv_group_normalize_layout", "Normalize Groups", "グループ正規化", "layout", None),
        ("uv.suv_orient_groups_advanced", "Orient Groups", "グループ向き補正", "rotate", None),
        ("uv.suv_udim_step", "Move by Tile", "タイル単位移動", "udim", None),
        ("uv.suv_udim_tile_tools", "UDIM Tile Tools", "UDIMタイルツール", "udim", None),
    ), columns=2)
    if _foldout(box, context, "stable_hotspot_trim", "Hotspot / Trim", "ホットスポット / トリム", "hotspot", default=False, help_id="hotspot_trim"):
        hot = box.box()
        if ws is not None:
            _props_two_columns(hot, ws, ("hotspot_cols", "hotspot_rows", "hotspot_keep_aspect", "hotspot_sort", "hotspot_fill_order"))
        _grid(hot, context, (
            ("uv.suv_hotspot_grid_layout", "Hotspot Grid", "ホットスポットグリッド", "hotspot", None),
            ("uv.suv_hotspot_cell_tools", "Cell Tools", "セルツール", "hotspot", None),
            ("uv.suv_hotspot_cell_refill", "Cell Refill", "セル再充填", "hotspot", None),
            ("uv.suv_hotspot_symmetry_refill", "Symmetry Refill", "対称再充填", "symmetry", None),
            ("uv.suv_trim_strip_layout", "Trim Strip", "トリムストリップ", "hotspot", None),
            ("uv.suv_trim_band_layout", "Trim Band", "トリム帯", "hotspot", None),
            ("uv.suv_trim_band_refill", "Trim Refill", "トリム再充填", "hotspot", None),
        ), columns=2)


def _draw_select_inspect(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_select_inspect", "Selection / Inspector / Repair", "選択 / 検査 / 修復", "inspect",
        default=True,
        help_id="select_inspect",
        hint_en="Find island groups, zero-area UVs, flipped islands, UDIM crossings, and other layout problems.",
        hint_ja="アイランドグループ、面積ゼロUV、反転、UDIM越え、その他の配置問題を検出します。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            status = box.box(); _box_header(status, context, "Last scan", "直近の検査", "report", "select_inspect_last_scan")
            status.label(text=_tr(context, f"Flipped: {getattr(ws, 'scan_flipped', 0)} / Zero: {getattr(ws, 'scan_zero', 0)} / Overlap: {getattr(ws, 'scan_overlap', 0)}", f"反転: {getattr(ws, 'scan_flipped', 0)} / ゼロ: {getattr(ws, 'scan_zero', 0)} / 重なり: {getattr(ws, 'scan_overlap', 0)}"))
            _props_two_columns(status, ws, ("scan_report_name", "stretch_threshold", "heatmap_max"))
        except Exception:
            pass
    _grid(box, context, (
        ("uv.suv_inspector_scan", "Scan", "検査", "inspect", None),
        ("uv.suv_inspector_select", "Select Issues", "問題を選択", "select", None),
        ("uv.suv_inspector_fix_flipped", "Fix Flipped", "反転修正", "repair", None),
        ("uv.suv_repair_flipped_islands", "Repair Flipped Islands", "反転アイランド修復", "repair", None),
        ("uv.suv_inspector_rescan", "Rescan", "再検査", "inspect", None),
        ("uv.suv_inspector_clear_cache", "Clear Scan Cache", "検査キャッシュ消去", "cleanup", None),
        ("uv.suv_inspector_select_all", "Select All Issues", "全問題を選択", "select", None),
        ("uv.suv_inspector_write_report", "Write Report", "レポート作成", "report", None),
        ("uv.suv_select_island_active", "Active Island", "アクティブアイランド", "select", None),
        ("uv.suv_select_similar_islands", "Similar Islands", "類似アイランド", "select", None),
        ("uv.suv_select_identical_islands", "Identical Islands", "同一アイランド", "select", None),
        ("uv.suv_select_fragmented_islands", "Fragmented Islands", "断片アイランド", "select", None),
        ("uv.suv_select_uv_boundary", "UV Boundary", "UV境界", "select", None),
        ("uv.suv_select_zero_islands", "Zero-Area Islands", "面積ゼロアイランド", "select", None),
        ("uv.suv_select_udim_crossing", "UDIM Crossing", "UDIM越え", "udim", None),
    ), columns=2)


def _draw_density_preview_maps(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_density_preview", 'Density Panel', "テクセル密度 / プレビュー / UVマップ", "density",
        default=True,
        help_id="density_preview_maps",
        hint_en="Control texel density, generate checker previews, show heatmaps, and maintain UV map slots.",
        hint_ja="テクセル密度、チェッカープレビュー、ヒートマップ表示、UVマップ管理をまとめています。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            cfg = box.box(); _box_header(cfg, context, "Preview settings", "プレビュー設定", "checker", "density_preview_settings")
            _props_two_columns(cfg, ws, ("canvas_size", "checker_size_width", "checker_size_height", "checker_tile_count_u", "checker_tile_count_v", "checker_image_name", "checker_material_name", "uv_new_name", "heatmap_attr_name", "heatmap_material_name"))
        except Exception:
            pass
    _grid(box, context, (
        ("uv.suv_texel_get", "Get Density", "密度取得", "density", None),
        ("uv.suv_texel_set", "Set Density", "密度適用", "density", None),
        ("uv.suv_texel_normalize", "Normalize Density", "密度正規化", "density", None),
        ("smart_uv_suite.texel_density_tools", "Density Workflow Hub", "密度ツールキット", "density", {"mode": "SET_WORKFLOW"}),
        ("smart_uv_suite.checker_create", "Create Checker", "チェッカー作成", "checker", None),
        ("smart_uv_suite.checker_delete", "Delete Checker", "チェッカー削除", "cleanup", None),
        ("object.suv_visualize_stretch_heatmap", "Show Stretch Heatmap", "ストレッチ表示", "inspect", None),
        ("object.suv_clear_stretch_heatmap", "Clear Heatmap", "ヒートマップ消去", "cleanup", None),
        ("uv.suv_histogram_tools", "UV Histogram", "UVヒストグラム", "report", None),
        ("uv.suv_issue_audit_tools", "Issue Audit", "問題監査", "inspect", None),
    ), columns=2)
    uvmap = box.box(); _box_header(uvmap, context, "UV Maps", "UVマップ", "uvmap", "density_uv_maps")
    _grid(uvmap, context, (
        ("mesh.suv_uvmap_add", "Add UV Map", "UVマップ追加", "uvmap", None),
        ("mesh.suv_uvmap_duplicate", "Duplicate UV Map", "UVマップ複製", "uvmap", None),
        ("mesh.suv_uvmap_remove", "Remove UV Map", "UVマップ削除", "cleanup", None),
        ("mesh.suv_uvmap_rename_active", "Rename Active", "アクティブ名変更", "uvmap", None),
        ("mesh.suv_uvmap_set_active", "Set Active", "アクティブ指定", "uvmap", None),
        ("mesh.suv_uvmap_set_render", "Set Render", "レンダー指定", "uvmap", None),
        ("mesh.suv_uvmap_reorder", "Reorder UV Maps", "UVマップ並べ替え", "uvmap", None),
        ("mesh.suv_native_stage_uvmap", "UV Map Assist Tools", "標準UVマップツール", "native", None),
    ), columns=2)


def _draw_symmetry_atlas(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_symmetry_atlas", "Symmetry / Transfer / Atlas / Bake", "対称 / 転送 / アトラス / ベイク", "symmetry",
        default=True,
        help_id="symmetry_atlas",
        hint_en="Mirror UVs, transfer layouts, build multi-object atlases, and prepare bake workflows.",
        hint_ja="UVミラー、レイアウト転送、複数オブジェクトアトラス、ベイク準備をまとめています。",
    ):
        return
    box = _section_box(layout)
    _grid(box, context, (
        ("uv.suv_sym_detect_pairs", "Detect Symmetry", "対称検出", "symmetry", None),
        ("uv.suv_sym_mirror_uv", "Mirror UV", "UVミラー", "symmetry", None),
        ("uv.suv_sym_seams", "Mirror Seams", "シーム対称", "seam", None),
        ("uv.suv_sym_stack", "Symmetry Stack", "対称スタック", "stack", None),
        ("uv.suv_match_active_preserve", "Match Active", "アクティブに一致", "transfer", None),
        ("uv.suv_match_stitch_active_preserve", "Match + Stitch", "一致 + ステッチ", "transfer", None),
        ("uv.suv_batch_match_stitch_active_preserve", "Batch Match + Stitch", "一括一致 + ステッチ", "transfer", None),
        ("uv.suv_smart_3d_transfer", "Smart 3D Transfer", "スマート3D転送", "transfer", None),
        ("uv.suv_atlas_build_uv_multi", "Build Atlas UV", "アトラスUV構築", "atlas", None),
        ("uv.suv_atlas_build_mat_apply_multi", "Build Atlas Materials", "アトラスマテリアル構築", "atlas", None),
        ("uv.suv_atlas_bake_multi", "Bake Atlas", "アトラスベイク", "bake", None),
        ("uv.suv_atlas_run_all_multi", "Run Atlas All", "アトラス一括実行", "atlas", None),
        ("mesh.suv_bake_uv_prep", "Bake UV Prep", "ベイクUV準備", "bake", None),
        ("object.suv_native_stage_bake", "Bake Assist Stage", "標準ベイク段階", "bake", None),
    ), columns=2)


def _draw_native_bridge(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_native_bridge", "Standard Integration", "標準連携", "bridge",
        default=False,
        help_id="native_bridge",
        hint_en="Standard integration commands are kept collapsed until needed.",
        hint_ja="Blender標準コマンド互換やルート系ワークフローは、必要な時だけ開けるよう折りたたんでいます。",
    ):
        return
    box = _section_box(layout)
    _grid(box, context, (
        ("uv.suv_native_stage_workflow", "Workflow Assist", "標準ワークフロー", "native", None),
        ("uv.suv_native_stage_layout", "Layout Assist", "標準レイアウト", "native", None),
        ("uv.suv_native_stage_select", "Selection Assist", "標準選択", "native", None),
        ("object.suv_native_stage_preview", "Preview Assist", "標準プレビュー", "native", None),
        ("mesh.suv_native_stage_mesh", "Mesh Assist", "標準メッシュ", "native", None),
        ("uv.suv_uv_edit_compat_tools", "UV Edit Assist", "UV編集補助", "bridge", None),
        ("uv.suv_uv_brush_compat", "UV Brush Assist", "UVブラシ補助", "bridge", None),
        ("uv.suv_uv_lattice_compat", "UV Lattice Assist", "UVラティス補助", "bridge", None),
        ("uv.suv_cleanup_bridge", "Cleanup Route", "クリーンアップルート", "cleanup", None),
        ("uv.suv_similarity_bridge", "Similar Select Route", "類似選択ルート", "magic", None),
        ("uv.suv_precision_uv_tools", "Precision UV Tools", "精密UVツール", "quality", None),
        ("uv.suv_procedural_uv_tools", "Procedural UV Tools", "プロシージャルUVツール", "project", None),
        ("uv.suv_hair_card_uv_tools", "Hair Card UV Tools", "ヘアカードUVツール", "unwrap", None),
    ), columns=2)


def _draw_reports(layout, context) -> None:
    if not _foldout(
        layout, context, "stable_reports", "Reports / Diagnostics / Maintenance", "レポート / 診断 / メンテナンス", "report",
        default=False,
        help_id="reports",
        hint_en="Use these when checking installation health, writing reports, or cleaning generated support data.",
        hint_ja="インストール状態確認、レポート作成、生成サポートデータ整理に使います。",
    ):
        return
    ws = _ws(context)
    box = _section_box(layout)
    if ws is not None:
        try:
            cfg = box.box(); _box_header(cfg, context, "Report destinations", "レポート出力先", "report", "reports_destinations")
            _props_two_columns(cfg, ws, ("tool_runtime_log_name", "batch_report_name", "support_bundle_name", "validation_report_name", "batch_error_policy", "batch_snapshot_policy"))
        except Exception:
            pass
    _grid(box, context, (
        ("uv.suv_write_tool_runtime_snapshot", "Write Runtime Snapshot", "実行状態を書き出し", "report", None),
        ("uv.suv_clear_tool_runtime_log", "Clear Runtime Log", "実行ログ消去", "cleanup", None),
        ("uv.suv_clear_batch_report", "Clear Batch Report", "バッチレポート消去", "cleanup", None),
        ("uv.suv_open_diagnostics_text", "Open Diagnostics", "診断を開く", "report", None),
        ("uv.suv_write_support_bundle", "Write Support Bundle", "サポートバンドル作成", "report", None),
        ("uv.suv_collect_support_bundle", "Collect Support Bundle", "サポート情報収集", "report", None),
        ("uv.suv_copy_diagnostics_text", "Copy Diagnostics", "診断をコピー", "report", None),
        ("uv.suv_clear_all_reports", "Clear All Reports", "全レポート消去", "cleanup", None),
        ("uv.suv_reload_custom_icons", "Reload Custom Icons", "カスタムアイコン再読込", "settings", None),
        ("uv.suv_quality_audit_suite", "Quality Audit", "品質監査", "quality", None),
        ("uv.suv_quality_scan_context_readiness", "Context Readiness", "コンテキスト確認", "quality", None),
        ("uv.suv_quality_cleanup_generated_data", "Clean Generated Data", "生成データ整理", "cleanup", None),
        ("uv.suv_quality_write_operator_catalog", "Write Operator Catalog", "オペレーター一覧作成", "report", None),
        ("uv.suv_quality_write_ui_map", "Write UI Map", "UIマップ作成", "report", None),
    ), columns=2)


def _icon_for_op(op_id: str, label: str = "") -> str:
    text = f"{op_id} {label}".lower()
    rules = (
        (("checker",), "checker"),
        (("uvmap", "uv_map", "uv map"), "uvmap"),
        (("density", "texel", "world_scale"), "density"),
        (("pack",), "pack"),
        (("stack",), "stack"),
        (("udim", "tile"), "udim"),
        (("hotspot", "trim"), "hotspot"),
        (("atlas",), "atlas"),
        (("bake",), "bake"),
        (("sym", "mirror"), "symmetry"),
        (("transfer", "copy", "paste"), "transfer"),
        (("seam",), "seam"),
        (("unwrap", "projection", "project", "pelt", "peel"), "unwrap"),
        (("align", "central", "orient"), "align"),
        (("straight", "flow", "rect", "grid"), "straight"),
        (("rotate",), "rotate"),
        (("flip",), "flip"),
        (("scale", "fit", "fill", "crop"), "scale"),
        (("select",), "select"),
        (("inspect", "scan", "audit", "issue", "quality", "doctor"), "inspect"),
        (("repair", "fix", "heal", "cleanup", "clear"), "repair"),
        (("preset", "profile", "recipe", "library"), "preset"),
        (("native", "compat", "bridge"), "bridge"),
        (("magic",), "magic"),
        (("report", "log", "diagnostic", "snapshot", "bundle"), "report"),
    )
    for keys, icon in rules:
        if any(k in text for k in keys):
            return icon
    return "integrated"


def _category_for_op(op_id: str, label: str = "") -> str:
    icon = _icon_for_op(op_id, label)
    mapping = {
        "unwrap": "cut_unwrap", "seam": "cut_unwrap", "project": "cut_unwrap",
        "align": "transform", "straight": "transform", "rotate": "transform", "flip": "transform", "scale": "transform",
        "pack": "layout", "stack": "layout", "udim": "layout", "hotspot": "layout",
        "select": "select", "inspect": "select", "repair": "select",
        "density": "density", "checker": "density", "uvmap": "density",
        "symmetry": "symmetry", "transfer": "symmetry", "atlas": "symmetry", "bake": "symmetry",
        "bridge": "native", "native": "native", "magic": "native",
        "report": "reports", "quality": "reports", "preset": "reports", "cleanup": "reports",
    }
    return mapping.get(icon, "other")


def _iter_operator_subclasses(base):
    # Retained for API compatibility; broad Blender class traversal is forbidden.
    del base
    return iter(())


def _is_smart_uv_operator_class(cls: type) -> bool:
    try:
        module = str(getattr(cls, '__module__', '') or '')
    except Exception:
        return False
    package = str(__package__ or 'smart_uv_suite')
    return module == package or module.startswith(package + '.')


def _iter_operator_classes(core_module) -> list[tuple[str, str, str]]:
    del core_module
    return list(_LIVE_OPERATOR_CATALOG_CACHE)

def _draw_catalog(layout, context, core_module) -> None:
    ops = _iter_operator_classes(core_module)
    count = len(ops)
    if not _foldout(
        layout, context, "stable_all_tools", f'All Registered UV Suite Operators ({count})', f'登録済みUV Suite全オペレーター ({count})', "integrated",
        default=False,
        help_id="all_tools",
        hint_en="This catalog is generated from registered operator classes. It is collapsed by default to keep the main UI readable.",
        hint_ja="登録済みオペレータークラスから生成した一覧です。通常UIを見やすく保つため初期状態では折りたたみます。",
    ):
        return
    if not ops:
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return
    categories = {
        "cut_unwrap": ("Cut / Unwrap", "カット / 展開", "unwrap"),
        "transform": ("Align / Transform", "整列 / 変形", "transform"),
        "layout": ('Layout Panel', "配置 / スタック / UDIM", "layout"),
        "select": ("Selection / Inspection", "選択 / 検査", "inspect"),
        "density": ("Density / Preview / UV Maps", "密度 / プレビュー / UVマップ", "density"),
        "symmetry": ("Symmetry / Atlas / Bake", "対称 / アトラス / ベイク", "symmetry"),
        "native": ("Standard Integration", "標準連携", "bridge"),
        "reports": ("Reports / Quality", "レポート / 品質", "report"),
        "other": ("Other", "その他", "integrated"),
    }
    grouped: dict[str, list[tuple[str, str, str]]] = {key: [] for key in categories}
    for item in ops:
        grouped.setdefault(_category_for_op(item[0], item[1]), []).append(item)
    for key, (en, ja, icon) in categories.items():
        items = grouped.get(key) or []
        if not items:
            continue
        if not _foldout(layout, context, f"stable_catalog_{key}", f"{en} ({len(items)})", f"{ja} ({len(items)})", icon, default=False, help_id="all_tools"):
            continue
        box = _section_box(layout)
        for op_id, label, _desc in items:
            _op(box, context, op_id, _one_line(label, 38), _one_line(label, 38), _icon_for_op(op_id, label), None)


def _draw_native_tool_catalog_access(layout, context) -> None:
    """Expose the explicit native tool catalog without drawing it at startup."""
    try:
        from . import native_tool_catalog as catalog
        items = tuple(getattr(catalog, "ALL_NATIVE_OPERATOR_CATALOG", ()) or ())
    except Exception:
        catalog = None
        items = ()
    count = len(items)
    if not _foldout(
        layout, context, "stable_native_tool_catalog",
        f'Native UV Tool Catalog ({count})', f'標準UVツール一覧 ({count})', "native",
        default=False,
        help_id="native_tools",
        hint_en="Every explicit native UV tool entry is kept here so compact workflow sections never hide a feature.",
        hint_ja="コンパクトな作業セクションで機能が隠れないよう、明示的な標準UVツールをすべてここに保持します。",
    ):
        return
    body = _section_box(layout)
    if catalog is None:
        try:
            body.label(text=_tr(context, 'Native tool catalog could not be loaded.', '標準ツール一覧を読み込めませんでした。'), icon='ERROR')
        except Exception:
            pass
        return
    try:
        drawn = int(catalog.draw_native_tool_catalog(body, context) or 0)
    except Exception as exc:
        drawn = 0
        try:
            body.label(text=_one_line(exc, 100), icon='ERROR')
        except Exception:
            pass
    if count and drawn == 0:
        # Namespace foldouts are collapsed by default.  This is not a missing
        # feature condition, so keep the main UI silent and compact.
        return



_STABLE_TAB_DEFS = (
    ('WORKFLOW', 'Start / Unwrap', '開始 / 展開', 'MOD_UVPROJECT'),
    ('TRANSFORM', 'Shape / Select', '整形 / 選択', 'ORIENTATION_GLOBAL'),
    ('LAYOUT', 'Layout Panel', '配置 / 密度', 'PACKAGE'),
    ('ANALYZE', 'Smart / Inspect', 'スマート / 検査', 'VIEWZOOM'),
    ('ATLAS', 'Symmetry / Output', '対称 / 出力', 'TEXTURE'),
)
_STABLE_TAB_ALIASES = {
    'ALL': 'WORKFLOW',
    'MAPS': 'LAYOUT',
    'SYMMETRY': 'ATLAS',
    '': 'WORKFLOW',
}
_STABLE_TAB_VALUES = {item[0] for item in _STABLE_TAB_DEFS}


def _stable_tab_value(context) -> str:
    ws = _ws(context)
    if ws is None:
        return 'WORKFLOW'
    try:
        current = str(getattr(ws, 'main_tab', 'WORKFLOW') or 'WORKFLOW').upper()
    except Exception:
        current = 'WORKFLOW'
    current = _STABLE_TAB_ALIASES.get(current, current)
    if current not in _STABLE_TAB_VALUES:
        current = 'WORKFLOW'
    try:
        if str(getattr(ws, 'main_tab', '') or '').upper() != current:
            ws.main_tab = current
    except Exception:
        pass
    return current


def _draw_stable_tabs(layout, context) -> str:
    current = _stable_tab_value(context)
    ws = _ws(context)
    try:
        box = layout.box()
        col = box.column(align=True)
        col.label(text=_tr(context, 'Workflow Tabs', 'ワークフロータブ'), icon='BOOKMARKS')
        rows = (_STABLE_TAB_DEFS[:3], _STABLE_TAB_DEFS[3:])
        for defs in rows:
            row = col.row(align=True)
            row.scale_y = 1.0
            for value, en, ja, icon in defs:
                if ws is not None:
                    try:
                        row.prop_enum(ws, 'main_tab', value, text=_tr(context, en, ja), icon=icon)
                        continue
                    except Exception:
                        pass
                # Emergency fallback: keep a visible label if RNA enum drawing fails.
                label = _tr(context, en, ja)
                row.label(text=label, icon=icon)
        try:
            col.separator(factor=0.12)
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
    except Exception:
        pass
    return current


def _draw_stable_tab_body(root, context, *args, **kwargs):
    """Removed legacy route; only the canonical eight-section body is public."""
    del root, context, args, kwargs
    return None




def _draw_stable_workflow_group(root, context, *args, **kwargs):
    """Removed legacy route; only the canonical eight-section body is public."""
    del root, context, args, kwargs
    return None


def _draw_stable_transform_group(root, context, *args, **kwargs):
    """Removed legacy route; only the canonical eight-section body is public."""
    del root, context, args, kwargs
    return None


def _draw_stable_layout_group(root, context, *args, **kwargs):
    """Removed legacy route; only the canonical eight-section body is public."""
    del root, context, args, kwargs
    return None


def _draw_stable_analyze_group(root, context, *args, **kwargs):
    """Removed legacy route; only the canonical eight-section body is public."""
    del root, context, args, kwargs
    return None


def _draw_stable_output_group(root, context, *args, **kwargs):
    """Removed legacy route; only the canonical eight-section body is public."""
    del root, context, args, kwargs
    return None




def _draw_placeholder_operator(layout, context, label_en: str, label_ja: str, icon: str, *, reason_en: str = '', reason_ja: str = ''):
    try:
        row = layout.row(align=True)
        row.enabled = False
        value = _icon_value(icon)
        text = _tr(context, label_en, label_ja)
        if value:
            row.label(text=text, icon_value=value)
        else:
            row.label(text=text, icon=_standard_icon(icon))
        reason = _tr(context, reason_en or 'Operator is not registered in this context.', reason_ja or 'このコンテキストではオペレーターが未登録です。')
        if reason:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass


def _mapped_category_icon(category_key: str, label: str = '') -> str:
    key = str(category_key or '').lower()
    if key == 'unwrap':
        return 'unwrap'
    if key == 'align':
        return 'align'
    if key == 'island':
        return 'transform'
    if key == 'seam':
        return 'seam'
    if key == 'pack':
        return 'pack'
    if key == 'texel':
        return 'density'
    if key == 'inspect':
        return 'inspect'
    if key == 'view':
        return 'visual_reference'
    if key == 'workflow':
        return 'settings'
    text = str(label or '').lower()
    for token, icon in (
        ('unwrap', 'unwrap'), ('project', 'project'), ('align', 'align'), ('seam', 'seam'), ('stitch', 'stitch'),
        ('pack', 'pack'), ('udim', 'uv'), ('atlas', 'atlas'), ('density', 'density'), ('bake', 'bake'),
        ('select', 'select'), ('inspect', 'inspect'), ('quality', 'quality'), ('checker', 'checker'), ('preview', 'visual_reference'),
        ('workflow', 'settings'), ('preset', 'preset'), ('setting', 'settings'),
    ):
        if token in text:
            return icon
    return 'tool'



def _mapped_item_text(data: dict) -> str:
    return " ".join(
        str(data.get(key) or "")
        for key in ("new_id", "original_id", "en", "ja", "source_file", "class_name")
    ).lower()


def _mapped_item_icon(category_key: str, data: dict) -> str:
    text = _mapped_item_text(data)
    rules = (
        (("crop",), "crop"), (("fill",), "fill"), (("fit",), "fit"), (("pack", "atlas"), "atlas"),
        (("pack",), "pack"), (("udim",), "udim"), (("atlas",), "atlas"), (("layout",), "layout"),
        (("trim",), "trimsheet"), (("hotspot",), "hotspot"), (("sort",), "sort_h"),
        (("distribute",), "distribute_h"), (("rotate",), "rotate"), (("mirror",), "mirror_h"),
        (("flip",), "flip"), (("scale",), "scale"), (("align",), "align"), (("axis",), "align_h"),
        (("circle",), "circle"), (("grid",), "gridify"), (("rect",), "rectify"), (("straight",), "straight"),
        (("relax",), "relax"), (("seam",), "seam"), (("stitch",), "stitch"), (("weld",), "weld"),
        (("stack",), "stack"), (("pin",), "pin"), (("copy",), "transfer"), (("paste",), "transfer"),
        (("transfer",), "transfer"), (("select", "flipped"), "select_flipped"), (("flipped",), "select_flipped"),
        (("overlap",), "select_overlap"), (("zero",), "select_zero"), (("identical",), "select_identical"),
        (("similar",), "select_similar"), (("boundary",), "select_bounds"), (("scan",), "scan"),
        (("inspect",), "inspect"), (("audit",), "quality"), (("quality",), "quality"), (("repair",), "repair"),
        (("checker",), "checker"), (("preview",), "visual_reference"), (("view",), "visual_reference"),
        (("cursor",), "PIVOT_CURSOR"), (("density",), "density"), (("texel",), "density"), (("bake",), "bake"),
        (("uvmap",), "uvmap"), (("uv_map",), "uvmap"), (("report",), "report"), (("write",), "report"),
        (("preset",), "preset"), (("profile",), "preset"), (("workflow",), "settings"),
        (("setting",), "settings"), (("diagnostic",), "report"), (("help",), "help"),
        (("unwrap",), "unwrap"), (("project",), "project"), (("texture",), "TEXTURE"),
    )
    for tokens, icon in rules:
        try:
            if all(str(t).lower() in text for t in tokens):
                return icon
        except Exception:
            continue
    return _mapped_category_icon(category_key, str(data.get('en') or ''))


def _mapped_item_id(data: dict) -> str:
    return str(data.get('new_id') or '')


def _mapped_find_item(items: Sequence[tuple[str, dict]], op_id: str):
    op_id = str(op_id or '')
    if not op_id:
        return None
    for item in items:
        try:
            if _mapped_item_id(item[1]) == op_id:
                return item
        except Exception:
            pass
    return None


def _mapped_draw_button(layout, context, data: dict, category_key: str, *, text_en: str | None = None, text_ja: str | None = None,
                        icon: str | None = None, props: dict | None = None, symbol: str | None = None,
                        scale_y: float = 1.0, emboss: bool = True, enabled: bool = True):
    op_id = _mapped_item_id(data)
    label_en = str(text_en if text_en is not None else (data.get('en') or op_id))
    label_ja = str(text_ja if text_ja is not None else (data.get('ja') or label_en))
    draw_text = str(symbol) if symbol is not None else _tr(context, label_en, label_ja)
    icon_name = str(icon or _mapped_item_icon(category_key, data) or _mapped_category_icon(category_key))
    try:
        row = layout.row(align=True)
        row.enabled = bool(enabled)
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        row = layout
    if _operator_exists(op_id):
        try:
            row.operator_context = 'INVOKE_DEFAULT'
        except Exception:
            pass
        if props:
            available = _operator_property_names(op_id)
            if not available or any(str(k) not in available for k in dict(props).keys()):
                # If the canonical wrapper does not expose the requested property yet,
                # show a disabled cell rather than emitting Blender RNA warnings.
                try:
                    row.enabled = False
                    value = _icon_value(icon_name)
                    if value:
                        row.label(text=draw_text, icon_value=value)
                    else:
                        row.label(text=draw_text, icon=_standard_icon(icon_name))
                except Exception:
                    pass
                return None
        try:
            value = _icon_value(icon_name)
            try:
                row.operator_context = 'INVOKE_DEFAULT'
            except Exception:
                pass
            if value:
                op = row.operator(op_id, text=draw_text, icon_value=value, emboss=emboss)
            else:
                op = row.operator(op_id, text=draw_text, icon=_standard_icon(icon_name), emboss=emboss)
            _set_props(op, props)
            _help_scope_register_operator(op_id, label_en, label_ja, props, symbol=symbol)
            return op
        except Exception:
            pass
    try:
        row.enabled = False
        value = _icon_value(icon_name)
        if value:
            row.label(text=draw_text, icon_value=value)
        else:
            row.label(text=draw_text, icon=_standard_icon(icon_name))
    except Exception:
        pass
    return None


def _mapped_draw_spec_button(layout, context, items: Sequence[tuple[str, dict]], category_key: str, used: set[str], spec, *, scale_y: float = 1.0):
    if not isinstance(spec, dict):
        spec = {'id': str(spec)}
    op_id = str(spec.get('id') or spec.get('new_id') or '')
    item = _mapped_find_item(items, op_id)
    if item is None:
        return False
    data = item[1]
    mark = spec.get('mark_used', True)
    if mark:
        used.add(_mapped_item_id(data))
    _mapped_draw_button(
        layout,
        context,
        data,
        category_key,
        text_en=spec.get('en'),
        text_ja=spec.get('ja'),
        icon=spec.get('icon'),
        props=spec.get('props'),
        symbol=spec.get('symbol'),
        scale_y=float(spec.get('scale_y', scale_y) or scale_y),
    )
    return True


def _mapped_draw_spec_row(layout, context, items: Sequence[tuple[str, dict]], category_key: str, used: set[str], specs: Sequence, *, scale_y: float = 1.0) -> bool:
    present = []
    for spec in specs:
        op_id = str((spec.get('id') if isinstance(spec, dict) else spec) or '')
        if _mapped_find_item(items, op_id) is not None:
            present.append(spec)
    if not present:
        return False
    row = layout.row(align=True)
    try:
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        pass
    for spec in present:
        col = row.column(align=True)
        _mapped_draw_spec_button(col, context, items, category_key, used, spec, scale_y=scale_y)
    return True


class _ClosedUILayout:
    """No-op layout used when a child foldout is closed.

    Child drawing code can continue to call row/column/operator safely while the
    actual UI stays collapsed.
    """
    def __bool__(self):
        return False

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return self

    def operator_menu_enum(self, *args, **kwargs):
        return self

    def menu(self, *args, **kwargs):
        return self

    def prop(self, *args, **kwargs):
        return self

    def label(self, *args, **kwargs):
        return self

    def separator(self, *args, **kwargs):
        return self

    def __getattr__(self, _name):
        def _noop(*args, **kwargs):
            return self
        return _noop


_CLOSED_UI_LAYOUT = _ClosedUILayout()


def _child_foldout_key(prefix: str, help_id: str = '', label_en: str = '', label_ja: str = '') -> str:
    raw = str(help_id or label_en or label_ja or 'child_group')
    raw = re.sub(r'[^0-9A-Za-z_]+', '_', raw).strip('_').lower()
    if not raw:
        raw = 'child_group'
    return f"{prefix}_{raw}"


def _child_foldout_group(layout, context, key: str, label_en: str, label_ja: str, icon: str, help_id: str = '', *, default: bool = True):
    body = _curated_foldout_group(layout, context, key, label_en, label_ja, icon, help_id, default=default)
    return body if body is not None else _CLOSED_UI_LAYOUT


def _mapped_group_box(layout, context, title_en: str, title_ja: str, icon: str, help_id: str = ''):
    key = _child_foldout_key('mapped_child', help_id, title_en, title_ja)
    return _child_foldout_group(layout, context, key, title_en, title_ja, icon, help_id or '', default=True)


def _mapped_draw_visual_grid(layout, context, items: Sequence[tuple[str, dict]], category_key: str, used: set[str], *, columns: int = 2, scale_y: float = 1.0) -> None:
    records = []
    seen: set[str] = set()
    for _old_id, data in items:
        op_id = _mapped_item_id(data)
        if not op_id or op_id in used or op_id in seen:
            continue
        seen.add(op_id)
        records.append(data)
    columns = max(1, int(columns or 1))
    index = 0
    while index < len(records):
        row = layout.row(align=True)
        for _ in range(columns):
            if index >= len(records):
                try:
                    row.label(text="")
                except Exception:
                    pass
                continue
            data = records[index]
            index += 1
            cell = row.column(align=True)
            _mapped_draw_button(cell, context, data, category_key, scale_y=scale_y)


def _mapped_bucket_rules(category_key: str):
    rules = {
        'unwrap': (
            ('Projection', '投影', 'project', ('project', 'projection', 'normal', 'box', 'view', 'texture')),
            ('Unwrap / Unfold', '展開 / 展開補助', 'unwrap', ('unwrap', 'unfold', 'body')),
            ('Live / Utility', '常時処理 / 補助', 'quick', ('live', 'toggle', 'profile')),
        ),
        'align': (
            ('Snap / Target', 'スナップ / ターゲット', 'align', ('snap', 'target', 'point', 'vertex')),
            ('Shape Adjustment', '形状調整', 'rectify', ('grid', 'circle', 'straight', 'smooth', 'relax', 'normalize', 'stretch')),
            ('Workflow Apply', 'ワークフロー適用', 'preset', ('workflow', 'recipe', 'preset', 'compat')),
        ),
        'island': (
            ('Mesh UV', 'UVメッシュ', 'uvmap', ('uvmesh', 'mesh')),
            ('Transform', '変形', 'transform', ('rotate', 'flip', 'distribute', 'stretch')),
        ),
        'seam': (
            ('Copy / Paste / Transfer', 'コピー / 貼り付け / 転送', 'transfer', ('copy', 'paste', 'transfer')),
            ('Stack / Stitch / Weld', 'スタック / スティッチ / ウェルド', 'stitch', ('stack', 'stitch', 'weld', 'merge', 'mirror', 'symmetr')),
            ('Seam Sets', 'シームセット', 'preset', ('set_', 'library', 'save', 'recall', 'update', 'delete')),
            ('Pins / Boundary', 'ピン / 境界', 'pin', ('pin', 'boundary', 'border', 'angle', 'cut')),
        ),
        'pack': (
            ('Trim / UV List', 'トリム / UVリスト', 'trimsheet', ('trim', 'division', 'uv_list', 'trimsheet')),
            ('UDIM / Atlas / Symmetry', 'UDIM・アトラス・対称', 'atlas', ('udim', 'atlas', 'sym', 'tile')),
            ('Layout Sets', 'レイアウトセット', 'preset', ('layout_set', 'library', 'save', 'recall', 'transfer', 'update', 'delete')),
            ('Hotspot / Groups', 'ホットスポット / グループ', 'hotspot', ('hotspot', 'group')),
        ),
        'texel': (
            ('Density', '密度', 'density', ('density', 'texel', 'td')),
            ('UV Maps', 'UVマップ', 'uvmap', ('uvmap', 'layers', 'uv_map')),
            ('Bake Prep', 'ベイク準備', 'bake', ('bake', 'atlas')),
            ('Scale / Area', 'スケール / 面積', 'scale', ('scale', 'area', 'normalize', 'coverage')),
        ),
        'inspect': (
            ('Selection', '選択', 'select', ('select', 'similar', 'linked', 'border', 'grow', 'pick')),
            ('Issue Checks', '問題検査', 'inspect', ('check', 'zero', 'overlap', 'flipped', 'issue', 'audit', 'scan')),
            ('Repair / Validate', '修復 / 検証', 'repair', ('repair', 'fix', 'heal', 'validate', 'cleanup')),
            ('Reports / Upgrade', 'レポート / 更新', 'report', ('report', 'write', 'open', 'quality', 'upgrade')),
        ),
        'view': (
            ('Checker / Preview', 'チェッカー / プレビュー', 'checker', ('checker', 'preview', 'texture')),
            ('Overlay / Visual Controls', 'オーバーレイ / 表示制御', 'visual_reference', ('overlay', 'visual', 'focus', 'cursor', 'histogram')),
            ('Reports', 'レポート', 'report', ('report', 'write', 'open', 'map')),
        ),
        'workflow': (
            ('Panel / Preferences', 'パネル / 設定', 'settings', ('panel', 'preference', 'toggle', 'workspace', 'setting')),
            ('Texture / Wrap / Scale', 'テクスチャ / ラップ / スケール', 'TEXTURE', ('texture', 'wrap', 'scale', 'world')),
            ('Diagnostics / Support', '診断 / サポート', 'report', ('diagnostic', 'support', 'runtime', 'snapshot', 'log')),
            ('Smart Routes', 'スマートルート', 'magic', ('smart', 'integrated', 'route')),
        ),
    }
    return rules.get(str(category_key or ''), ())


def _mapped_bucket_for_item(category_key: str, data: dict):
    text = _mapped_item_text(data)
    for title_en, title_ja, icon, tokens in _mapped_bucket_rules(category_key):
        try:
            if any(str(token).lower() in text for token in tokens):
                return title_en, title_ja, icon
        except Exception:
            continue
    return 'More Controls', '追加操作', _mapped_category_icon(category_key)


def _mapped_draw_remaining_buckets(layout, context, category_key: str, items: Sequence[tuple[str, dict]], used: set[str]) -> None:
    buckets: dict[tuple[str, str, str], list[tuple[str, dict]]] = {}
    seen: set[str] = set()
    for item in items:
        try:
            data = item[1]
            op_id = _mapped_item_id(data)
            if not op_id or op_id in used or op_id in seen:
                continue
            seen.add(op_id)
            bucket = _mapped_bucket_for_item(category_key, data)
            buckets.setdefault(bucket, []).append(item)
        except Exception:
            continue
    for (title_en, title_ja, icon), group_items in buckets.items():
        if not group_items:
            continue
        box = _mapped_group_box(layout, context, f"{title_en} ({len(group_items)})", f"{title_ja}（{len(group_items)}）", icon)
        columns = 2
        if category_key in {'inspect', 'pack'} and len(group_items) <= 12:
            columns = 2
        _mapped_draw_visual_grid(box, context, group_items, category_key, used, columns=columns, scale_y=1.0)


def _draw_compact_alignment_pad(layout, context, items: Sequence[tuple[str, dict]], used: set[str]) -> bool:
    layout_action = _mapped_find_item(items, 'smart_uv_suite.pack_layout_action')
    align_op = _mapped_find_item(items, 'smart_uv_suite.align_islands')
    # In the Pack category, the canonical layout-action wrapper can draw the same
    # Smart UV compact 3x3 pad as multiple action variants. In other categories it
    # will simply be absent.
    if layout_action is None and align_op is None:
        return False
    used.add('smart_uv_suite.pack_layout_action')
    used.add('smart_uv_suite.align_islands')
    pad_box = _mapped_group_box(layout, context, 'Align Pad', '整列パッド', 'align', 'uv_layout_align_pad')
    pad_row = pad_box.row(align=True)
    pad = pad_row.column(align=True)
    rows = (
        (("ALIGN_TL", "align_tl", "↖"), ("ALIGN_TOP", "align_top", "↑"), ("ALIGN_TR", "align_tr", "↗")),
        (("ALIGN_LEFT", "align_left", "←"), ("ALIGN_CENTER", "align_center", "+"), ("ALIGN_RIGHT", "align_right", "→")),
        (("ALIGN_BL", "align_bl", "↙"), ("ALIGN_BOTTOM", "align_bottom", "↓"), ("ALIGN_BR", "align_br", "↘")),
    )
    for row_defs in rows:
        row = pad.row(align=True)
        for action, icon, symbol in row_defs:
            col = row.column(align=True)
            if layout_action is not None:
                _mapped_draw_button(col, context, layout_action[1], 'pack', text_en='', text_ja='', icon=icon, props={'action': action}, symbol=symbol, scale_y=1.22)
            else:
                _mapped_draw_button(col, context, align_op[1], 'inspect', text_en='', text_ja='', icon=icon, symbol=symbol, scale_y=1.22)
    axis_col = pad_row.column(align=True)
    if layout_action is not None:
        _mapped_draw_button(axis_col, context, layout_action[1], 'pack', text_en='Horizontal Center', text_ja='横中心', icon='align_h', props={'action': 'ALIGN_H'}, symbol='H', scale_y=1.05)
        _mapped_draw_button(axis_col, context, layout_action[1], 'pack', text_en='Vertical Center', text_ja='縦中心', icon='align_v', props={'action': 'ALIGN_V'}, symbol='V', scale_y=1.05)
    return True


def _mapped_draw_category_quick_board(layout, context, category: dict, items: Sequence[tuple[str, dict]], used: set[str]) -> None:
    key = str(category.get('key') or '')
    if key == 'unwrap':
        box = _mapped_group_box(layout, context, 'Unwrap / Projection Quick Board', '展開 / 投影クイックボード', 'unwrap', 'category_unwrap_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.unwrap', 'icon': 'unwrap', 'scale_y': 1.35},
            {'id': 'smart_uv_suite.auto_unwrap_pro', 'icon': 'smart_project', 'scale_y': 1.35},
            {'id': 'smart_uv_suite.unwrap_projection', 'icon': 'project', 'scale_y': 1.35},
        ), scale_y=1.32)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.unwrap_smart_project', 'icon': 'smart_project'},
            {'id': 'smart_uv_suite.unwrap_box_project', 'icon': 'box'},
            {'id': 'smart_uv_suite.unwrap_view_project', 'icon': 'camera'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.unwrap_texture_projection_project', 'icon': 'TEXTURE'},
            {'id': 'smart_uv_suite.unwrap_body_preset', 'icon': 'body'},
            {'id': 'smart_uv_suite.unwrap_unfoldify', 'icon': 'unwrap'},
        ))
    elif key == 'align':
        box = _mapped_group_box(layout, context, 'Shape Adjustment Board', '形状調整ボード', 'align', 'category_align_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.align_uv_axis', 'icon': 'align_h', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.align_uv_circle', 'icon': 'circle', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.gridify', 'icon': 'gridify', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.align_straight_line', 'icon': 'straight'},
            {'id': 'smart_uv_suite.align_uv_straighten', 'icon': 'straight'},
            {'id': 'smart_uv_suite.align_normalize', 'icon': 'fit'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.align_relax', 'icon': 'relax'},
            {'id': 'smart_uv_suite.align_stretch', 'icon': 'scale'},
            {'id': 'smart_uv_suite.align_orient', 'icon': 'orient_bbox'},
        ))
    elif key == 'island':
        box = _mapped_group_box(layout, context, 'Island Transform Board', 'アイランド変形ボード', 'transform', 'category_island_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.island_rotate', 'icon': 'rotate', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.island_rotate_transform', 'icon': 'rotate_cw', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.island_flip', 'icon': 'flip', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.island_flip_rotate_uv', 'icon': 'rotate'},
            {'id': 'smart_uv_suite.island_distribute', 'icon': 'distribute_h'},
            {'id': 'smart_uv_suite.island_stretch_uv_toggle', 'icon': 'scale'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.island_uvmesh', 'icon': 'uvmap'},
            {'id': 'smart_uv_suite.island_uvmesh_control', 'icon': 'settings'},
            {'id': 'smart_uv_suite.island_uvmesh_clear', 'icon': 'cleanup'},
        ))
    elif key == 'seam':
        box = _mapped_group_box(layout, context, 'Seam / Stitch Board', 'シーム / スティッチボード', 'seam', 'category_seam_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.auto_seam_advanced', 'icon': 'seam', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.seam_smart_seams', 'icon': 'candidate', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.seam_clear_seams', 'icon': 'cleanup', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.stitch', 'icon': 'stitch'},
            {'id': 'smart_uv_suite.weld', 'icon': 'weld'},
            {'id': 'smart_uv_suite.seam_stack_pro', 'icon': 'stack'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.seam_pin', 'icon': 'pin'},
            {'id': 'smart_uv_suite.seam_clear_pins', 'icon': 'unpin'},
            {'id': 'smart_uv_suite.seam_boundary', 'icon': 'select_bounds'},
        ))
    elif key == 'pack':
        top = _mapped_group_box(layout, context, 'Smart UV compact Layout Board', 'スマートUVレイアウトボード', 'layout_board', 'category_pack_quick')
        layout_action = _mapped_find_item(items, 'smart_uv_suite.pack_layout_action')
        if layout_action is not None:
            used.add('smart_uv_suite.pack_layout_action')
            row = top.row(align=True)
            for action, en, ja, icon in (
                ('CROP', 'Crop', 'クロップ', 'crop'), ('FILL', 'Fill', 'フィル', 'fill'), ('FIT', 'Fit', 'フィット', 'fit'),
            ):
                _mapped_draw_button(row.column(align=True), context, layout_action[1], key, text_en=en, text_ja=ja, icon=icon, props={'action': action}, scale_y=1.35)
        _mapped_draw_spec_row(top, context, items, key, used, (
            {'id': 'smart_uv_suite.pack_pro', 'icon': 'pack', 'scale_y': 1.3},
            {'id': 'smart_uv_suite.pack', 'icon': 'pack', 'scale_y': 1.3},
            {'id': 'smart_uv_suite.pack_crop', 'icon': 'crop', 'scale_y': 1.3},
        ), scale_y=1.22)
        _draw_compact_alignment_pad(layout, context, items, used)
        if layout_action is not None:
            trans = _mapped_group_box(layout, context, 'Rotate / Mirror / Sort', '回転 / 反転 / 並べ替え', 'transform', 'category_pack_transform')
            row = trans.row(align=True)
            for action, en, ja, icon in (
                ('ROTATE_CCW', '90° CCW', '90°左', 'rotate_ccw'), ('ROTATE_CW', '90° CW', '90°右', 'rotate_cw'),
                ('MIRROR_H', 'Mirror H', '左右反転', 'mirror_h'), ('MIRROR_V', 'Mirror V', '上下反転', 'mirror_v'),
            ):
                _mapped_draw_button(row.column(align=True), context, layout_action[1], key, text_en=en, text_ja=ja, icon=icon, props={'action': action})
            row = trans.row(align=True)
            for action, en, ja, icon in (
                ('SORT_H', 'Sort H', '横整列', 'sort_h'), ('SORT_V', 'Sort V', '縦整列', 'sort_v'),
                ('DISTRIBUTE_H', 'Spread H', '横均等', 'distribute_h'), ('DISTRIBUTE_V', 'Spread V', '縦均等', 'distribute_v'),
            ):
                _mapped_draw_button(row.column(align=True), context, layout_action[1], key, text_en=en, text_ja=ja, icon=icon, props={'action': action})
    elif key == 'texel':
        box = _mapped_group_box(layout, context, 'Texel Density Board', 'テクセル密度ボード', 'density', 'category_texel_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.texel_get', 'icon': 'density_pick', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.texel_set', 'icon': 'density_apply', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.texel_normalize', 'icon': 'density_normalize', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.texel_density_get', 'icon': 'density_pick'},
            {'id': 'smart_uv_suite.texel_density_set', 'icon': 'density_apply'},
            {'id': 'smart_uv_suite.texel_density_coverage', 'icon': 'area'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.texel_uvmap_add', 'icon': 'uvmap'},
            {'id': 'smart_uv_suite.texel_uvmap_duplicate', 'icon': 'SEQ_STRIP_DUPLICATE'},
            {'id': 'smart_uv_suite.texel_bake_uv_prep', 'icon': 'bake'},
        ))
    elif key == 'inspect':
        box = _mapped_group_box(layout, context, 'Select / Inspect Board', '選択 / 検査ボード', 'inspect', 'category_inspect_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.select_similar_islands', 'icon': 'select_similar', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.select_identical_islands', 'icon': 'select_identical', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.select_zero_islands', 'icon': 'select_zero', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.select_uv_select_overlapped', 'icon': 'select_overlap'},
            {'id': 'smart_uv_suite.select_uv_select_flipped', 'icon': 'select_flipped'},
            {'id': 'smart_uv_suite.select_uv_boundary', 'icon': 'select_bounds'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.inspect_inspector_scan', 'icon': 'scan'},
            {'id': 'smart_uv_suite.inspect_fix_all_issues', 'icon': 'repair'},
            {'id': 'smart_uv_suite.inspect_layout_preflight_audit', 'icon': 'quality'},
        ))
    elif key == 'view':
        box = _mapped_group_box(layout, context, 'Preview / Visual Board', 'プレビュー / 可視化ボード', 'visual_reference', 'category_view_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.checker_map', 'icon': 'checker', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.checker_map_clear', 'icon': 'cleanup', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.view_texture_projection', 'icon': 'TEXTURE', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.view_create_checker_material', 'icon': 'checker'},
            {'id': 'smart_uv_suite.view_remove_checker_materials', 'icon': 'cleanup'},
            {'id': 'smart_uv_suite.view_fit_to_bounds', 'icon': 'fit'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.view_focus', 'icon': 'VIEWZOOM'},
            {'id': 'smart_uv_suite.view_set_cursor_2d', 'icon': 'PIVOT_CURSOR'},
            {'id': 'smart_uv_suite.view_histogram_tools', 'icon': 'SEQ_HISTOGRAM'},
        ))
    elif key == 'workflow':
        box = _mapped_group_box(layout, context, 'Workflow / Settings Board', 'ワークフロー / 設定ボード', 'settings', 'category_workflow_quick')
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.workflow_open_smart_tools', 'icon': 'FILE_REFRESH', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.workflow_show_help', 'icon': 'help', 'scale_y': 1.25},
            {'id': 'smart_uv_suite.workflow_show_addon_preferences', 'icon': 'settings', 'scale_y': 1.25},
        ), scale_y=1.18)
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.workflow_collect_support_bundle', 'icon': 'report'},
            {'id': 'smart_uv_suite.workflow_open_diagnostics_text', 'icon': 'TEXT'},
            {'id': 'smart_uv_suite.workflow_workspace_reset', 'icon': 'cleanup'},
        ))
        _mapped_draw_spec_row(box, context, items, key, used, (
            {'id': 'smart_uv_suite.workflow_texture_lock_lock', 'icon': 'LOCKED'},
            {'id': 'smart_uv_suite.workflow_texture_lock_unlock', 'icon': 'UNLOCKED'},
            {'id': 'smart_uv_suite.workflow_preserve_uv_aspect', 'icon': 'FULLSCREEN_ENTER'},
        ))


def _draw_renamed_operator_button(layout, context, op_id: str, label_en: str, label_ja: str, icon: str):
    data = {'new_id': str(op_id or ''), 'en': str(label_en or op_id), 'ja': str(label_ja or label_en)}
    return _mapped_draw_button(layout, context, data, '', icon=icon)


def _draw_mapped_category_body(body, context, category: dict, items: Sequence[tuple[str, dict]]) -> None:
    if not items:
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass
        return
    cat_key = str(category.get('key') or '')
    try:
        summary = body.row(align=True)
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass
    used: set[str] = set()
    _mapped_draw_category_quick_board(body, context, category, items, used)
    _mapped_draw_remaining_buckets(body, context, cat_key, items, used)




def _load_mapped_categories():
    # Immutable lifecycle snapshot; no import or catalog construction in draw.
    return _MAPPED_CATEGORIES_CACHE



_CURATED_SECTIONS = (
    ('basic', 'Basic Settings', '基本設定', 'settings', 'category_workflow', True),
    ('unwrap', 'UV Unwrap', 'UV展開', 'unwrap', 'category_unwrap', True),
    ('align', 'UV Align', 'UV整列', 'align', 'category_align', True),
    ('pack', 'Packing', 'パッキング', 'pack', 'category_pack', True),
    ('bake', 'Bake', 'ベイク', 'bake', 'category_texel', True),
    ('operation', 'Operation', '操作', 'tool', 'category_operation', True),
    ('manage', 'Management', '管理', 'settings', 'category_workflow', True),
    ('keymap_info', 'Keymap Information', 'キーマップ情報', 'keyboard', 'keymap_info', True),
)


def _curated_operator_can_draw(op_id: str, props: dict | None = None) -> bool:
    if not _operator_exists(op_id):
        return False
    if props:
        available = _operator_property_names(op_id)
        if not available or any(str(k) not in available for k in dict(props).keys()):
            return False
    return True


_CURATED_SHORT_LABELS = {
    'Export UV Layout': ('Export UV Layout', 'UV配置の書き出し'),
    'Run Selected Unwrap': ('Run', '実行'),
    'Run': ('Run', '実行'),
    'Run Unwrap': ('Run Auto Unwrap', '自動展開実行'),
    'Connected Island → Selected': ('C→S', '島→選'),
    'Selected Island → Connected': ('S→C', '選→島'),
    'Both Islands → Middle': ('Mid', '島中間'),
    'Connected Edge → Selected': ('C Edge', '辺→選'),
    'Selected Edge → Connected': ('S Edge', '選→辺'),
    'Both Edges → Middle': ('E Mid', '辺中間'),
    'Horizontal Center by Group': ('H Group', '横G'),
    'Vertical Center by Group': ('V Group', '縦G'),
    'Distribute Horizontal by Group': ('Spread H G', '横均G'),
    'Distribute Vertical by Group': ('Spread V G', '縦均G'),
    'Selection Mode': ('Mode', 'モード'),
    'Select by Area': ('Area', '面積'),
    'Active Island': ('Active', 'アクティブ'),
    'Similar Islands': ('Similar', '類似島'),
    'Identical Islands': ('Identical', '同一島'),
    'Directional Edges': ('Dir Edge', '方向辺'),
    'Fragmented Islands': ('Split', '分断'),
    'Similarity Wand': ('Wand', 'ワンド'),
    'Issue Select': ('Issue', '問題'),
    'All Issues': ('All Issues', '全問題'),
}


def _curated_compact_label(context, label_en: str, label_ja: str) -> tuple[str, str]:
    """Return full button labels without Smart UV Suite-side character trimming."""
    del context
    en = str(label_en or '')
    ja = str(label_ja or en)
    return en, ja


def _curated_button(layout, context, op_id: str, label_en: str, label_ja: str, icon: str = 'tool', props: dict | None = None, *, scale_y: float = 1.0) -> bool:
    op_id = str(op_id or '')
    if not _curated_operator_can_draw(op_id, props):
        return False
    compact_en, compact_ja = _curated_compact_label(context, str(label_en or op_id), str(label_ja or label_en or op_id))
    data = {'new_id': op_id, 'en': compact_en, 'ja': compact_ja}
    try:
        _mapped_draw_button(layout, context, data, '', icon=icon, props=props, scale_y=scale_y)
        return True
    except Exception:
        return False

def _curated_row(layout, context, specs: Sequence[dict], *, scale_y: float = 1.0) -> bool:
    drawable = []
    for spec in specs:
        if not isinstance(spec, dict):
            continue
        op_id = str(spec.get('id') or '')
        props = spec.get('props')
        if _curated_operator_can_draw(op_id, props):
            drawable.append(spec)
    if not drawable:
        return False
    try:
        row = layout.row(align=True)
        row.scale_y = float(scale_y or 1.0)
    except Exception:
        row = layout
    for spec in drawable:
        try:
            col = row.column(align=True)
        except Exception:
            col = row
        _curated_button(
            col,
            context,
            str(spec.get('id') or ''),
            str(spec.get('en') or ''),
            str(spec.get('ja') or spec.get('en') or ''),
            str(spec.get('icon') or 'tool'),
            spec.get('props'),
            scale_y=float(spec.get('scale_y', scale_y) or scale_y),
        )
    return True


def _curated_group(layout, context, label_en: str, label_ja: str, icon: str, help_id: str = ''):
    key = _child_foldout_key('curated_child', help_id, label_en, label_ja)
    return _child_foldout_group(layout, context, key, label_en, label_ja, icon, help_id or '', default=True)


def _standard_child_panel_id(key: str, label_en: str = '', label_ja: str = '', depth: int = 0) -> str:
    """Return a stable, collision-resistant id for Blender's native panel state."""
    source = f"{key}\x1f{label_en}\x1f{label_ja}\x1f{max(0, int(depth or 0))}"
    raw = re.sub(r'[^0-9A-Za-z_]+', '_', str(key or label_en or 'child')).strip('_')
    if not raw:
        raw = 'child'
    digest = hashlib.blake2s(source.encode('utf-8'), digest_size=8).hexdigest()
    return f"SUS_CHILD_{raw[:32]}_{digest}"


class _SUSSectionLayoutProxy:
    """Small wrapper that remembers child-section nesting depth.

    Blender's native UILayout.panel() provides the correct 5.1 disclosure UI,
    but when panels are nested their disclosure triangles can appear on the same
    visual column.  The proxy lets this module indent only grandchild-or-deeper
    standard panels without changing the top-level Smart UV Suite ``▶`` rows.
    """

    __slots__ = ('_sus_layout', '_sus_section_depth')

    def __init__(self, layout, depth: int = 0):
        self._sus_layout = layout
        self._sus_section_depth = max(0, int(depth or 0))

    def __bool__(self):
        return True

    def __getattr__(self, name):
        return getattr(self._sus_layout, name)


def _sus_base_layout(layout):
    return getattr(layout, '_sus_layout', layout)


def _sus_section_depth(layout) -> int:
    try:
        return max(0, int(getattr(layout, '_sus_section_depth', 0) or 0))
    except Exception:
        return 0


def _sus_wrap_section_layout(layout, depth: int):
    if layout is None or layout is _CLOSED_UI_LAYOUT:
        return layout
    return _SUSSectionLayoutProxy(layout, depth)


def _sus_indented_panel_layout(layout, depth: int):
    """Inset each native descendant disclosure by one constant UI step."""
    base = _sus_base_layout(layout)
    try:
        depth = max(0, int(depth or 0))
    except Exception:
        depth = 0
    if depth == 0:
        return base

    # ``UILayout.panel()`` still owns the chevron and per-region open state.
    # A horizontal spacer only scopes its full remaining-width column, so every
    # extra hierarchy level advances by the same small logical UI distance.
    row = base.row(align=True)
    for _index in range(depth):
        row.separator(factor=0.50)
    panel_layout = row.column(align=True)
    try:
        panel_layout.use_property_split = False
        panel_layout.use_property_decorate = False
    except Exception:
        pass
    return panel_layout

def _curated_foldout_group(layout, context, key: str, label_en: str, label_ja: str, icon: str, help_id: str = '', *, default: bool = True):
    """Draw one child or grandchild with Blender's native disclosure panel."""
    title = _tr(context, label_en, label_ja)
    parent_depth = _sus_section_depth(layout)
    panel_layout = _sus_indented_panel_layout(layout, parent_depth)

    # Existing JSON foldout state is read-only migration input for the first
    # native panel instance.  Thereafter Blender owns the per-region disclosure
    # state; draw never writes JSON, RNA, handlers, timers, or registration data.
    default_open = _foldout_state(context, key, bool(default))
    panel_id = _standard_child_panel_id(key, label_en, label_ja, parent_depth)
    try:
        header, body = panel_layout.panel(
            panel_id,
            default_closed=not bool(default_open),
        )
    except Exception:
        # Blender 5.1 provides UILayout.panel().  A failed native-panel call must
        # not fall back to an icon-mimic toggle or mutate runtime registration.
        return None

    try:
        header.use_property_split = False
        header.use_property_decorate = False
    except Exception:
        pass
    try:
        icon_value = _icon_value(icon)
        if icon_value:
            header.label(text=title, icon_value=icon_value)
        else:
            header.label(text=title, icon=_standard_icon(icon))
    except Exception:
        try:
            header.label(text=title)
        except Exception:
            pass
    if help_id:
        try:
            header.separator(factor=0.30)
        except Exception:
            pass
        _draw_help_button(header, context, help_id or '', label_en, label_ja, emboss=False)

    if body is None:
        return None
    try:
        body.use_property_split = False
        body.use_property_decorate = False
        content = body.column(align=True)
        content.use_property_split = False
        content.use_property_decorate = False
    except Exception:
        content = body
    return _sus_wrap_section_layout(content, parent_depth + 1)

def _curated_props_grid(layout, owner, props: Sequence[tuple[str, str, str] | str], *, columns: int = 2) -> None:
    if owner is None:
        return
    normalized = []
    for item in props:
        if isinstance(item, tuple):
            prop, en, ja = item
        else:
            prop, en, ja = str(item), '', ''
        if str(prop) in {'suv_native_target_density', 'suv_native_uv_name'}:
            try:
                if getattr(getattr(owner, 'bl_rna', None), 'properties', {}).get(str(prop)) is None:
                    continue
            except Exception:
                continue
        normalized.append((str(prop), str(en or ''), str(ja or '')))
    columns = max(1, int(columns or 1))

    def _draw_cells(cells, *, fill: bool) -> None:
        try:
            row = layout.row(align=True)
        except Exception:
            row = layout
        for prop, en, ja in cells:
            try:
                col = row.column(align=True)
            except Exception:
                col = row
            text = _tr(bpy.context, en, ja) if (en or ja) else None
            _prop(col, owner, prop, text=text)
        if fill:
            for _ in range(columns - len(cells)):
                try:
                    row.label(text='')
                except Exception:
                    pass

    pending: list[tuple[str, str, str]] = []
    for item in normalized:
        # ``label: field`` properties (enum / pointer / string) keep only about a
        # third of a grid cell for the label, which truncates text such as
        # "Margin Method" in the sidebar.  Give them a full-width row.
        if columns > 1 and _grid_prop_needs_full_row(owner, item[0]):
            if len(pending) == 1:
                _draw_cells(pending, fill=False)
            elif pending:
                _draw_cells(pending, fill=True)
            pending.clear()
            _draw_cells([item], fill=False)
            continue
        pending.append(item)
        if len(pending) >= columns:
            _draw_cells(pending, fill=False)
            pending.clear()
    if pending:
        _draw_cells(pending, fill=True)


def _draw_curated_align_pad(layout, context, *, op_id: str = 'smart_uv_suite.island_direction_align') -> bool:
    """Draw Direction Align.

    1.8.111 consolidates the former separate Vertex / Island direction-align
    pads.  In the UV Align section the same button matrix is drawn once; the
    workspace radio switch decides whether buttons run the vertex backend or the
    island backend.  Legacy direct calls still keep their original labels.
    """
    requested_op_id = str(op_id or '')
    unified = requested_op_id in {'smart_uv_suite.direction_align', 'smart_uv_suite.direction_align_action'}
    if not _curated_operator_can_draw(requested_op_id, {'action': 'ALIGN_CENTER'}):
        return False

    ws = _ws(context)
    target = 'VERTEX'
    if ws is not None:
        try:
            target = str(getattr(ws, 'uv_direction_align_target', 'VERTEX') or 'VERTEX')
        except Exception:
            target = 'VERTEX'
    if target not in {'VERTEX', 'ISLAND'}:
        target = 'VERTEX'

    if unified:
        is_vertex = target == 'VERTEX'
        label_en = 'Direction Align'
        label_ja = '方向整列'
        group_key = 'uv_direction_align_unified_pad'
    else:
        is_vertex = requested_op_id == 'smart_uv_suite.vertex_align_action'
        label_en = 'Direction Align (Vertices)' if is_vertex else 'Direction Align (Islands)'
        label_ja = '方向整列（頂点）' if is_vertex else '方向整列（アイランド）'
        group_key = 'uv_layout_align_pad' if not is_vertex else 'uv_vertex_align_pad'

    pad_box = _curated_group(layout, context, label_en, label_ja, 'uv_bbox', group_key)
    if pad_box is None:
        return False

    if unified and ws is not None:
        try:
            switch = pad_box.row(align=True)
            switch.label(text=_tr(context, 'Target', '対象'))
            target_row = switch.row(align=True)
            try:
                op = target_row.operator(
                    'smart_uv_suite.direction_align_mode',
                    text=_tr(context, 'Vertex', '頂点'),
                    depress=(target == 'VERTEX'),
                )
            except TypeError:
                op = target_row.operator('smart_uv_suite.direction_align_mode', text=_tr(context, 'Vertex', '頂点'))
            op.target = 'VERTEX'
            _help_scope_register_operator('smart_uv_suite.direction_align_mode', 'Vertex', '頂点', {'target': 'VERTEX'})
            try:
                op = target_row.operator(
                    'smart_uv_suite.direction_align_mode',
                    text=_tr(context, 'Island', 'アイランド'),
                    depress=(target == 'ISLAND'),
                )
            except TypeError:
                op = target_row.operator('smart_uv_suite.direction_align_mode', text=_tr(context, 'Island', 'アイランド'))
            op.target = 'ISLAND'
            _help_scope_register_operator('smart_uv_suite.direction_align_mode', 'Island', 'アイランド', {'target': 'ISLAND'})
        except Exception:
            pass

    columns = (
        (("ALIGN_TL", "align_tl", "↖"), ("ALIGN_LEFT", "align_left", "←"), ("ALIGN_BL", "align_bl", "↙")),
        (("ALIGN_TOP", "align_top", "↑"), ("ALIGN_CENTER", "align_center", "+"), ("ALIGN_BOTTOM", "align_bottom", "↓")),
        (("ALIGN_TR", "align_tr", "↗"), ("ALIGN_RIGHT", "align_right", "→"), ("ALIGN_BR", "align_br", "↘")),
    )
    try:
        board = pad_box.row(align=True)
        for column_defs in columns:
            col = board.column(align=True)
            for action, icon, symbol in column_defs:
                data = {'new_id': requested_op_id, 'en': symbol, 'ja': symbol}
                _mapped_draw_button(col, context, data, '', icon=icon, props={'action': action}, symbol=symbol, scale_y=1.05)
    except Exception:
        pass

    try:
        axis = pad_box.row(align=True)
        data = {'new_id': requested_op_id, 'en': 'Horizontal Center', 'ja': '横中央'}
        _mapped_draw_button(axis.column(align=True), context, data, '', icon='group_center_h', props={'action': 'ALIGN_H'}, symbol='—', scale_y=1.0)
        data = {'new_id': requested_op_id, 'en': 'Vertical Center', 'ja': '縦中央'}
        _mapped_draw_button(axis.column(align=True), context, data, '', icon='group_center_v', props={'action': 'ALIGN_V'}, symbol='|', scale_y=1.0)
    except Exception:
        pass

    show_group_buttons = is_vertex
    if show_group_buttons:
        try:
            group_axis = pad_box.row(align=True)
            data = {'new_id': requested_op_id, 'en': 'Horizontal Center by Group', 'ja': '横中央 グループ'}
            _mapped_draw_button(group_axis.column(align=True), context, data, '', icon='group_center_h', props={'action': 'ALIGN_H_GROUP'}, symbol='G—', scale_y=1.0)
            data = {'new_id': requested_op_id, 'en': 'Vertical Center by Group', 'ja': '縦中央 グループ'}
            _mapped_draw_button(group_axis.column(align=True), context, data, '', icon='group_center_v', props={'action': 'ALIGN_V_GROUP'}, symbol='G|', scale_y=1.0)
        except Exception:
            pass

    try:
        dist = pad_box.row(align=True)
        data = {'new_id': requested_op_id, 'en': 'Distribute Horizontal', 'ja': '横均等'}
        _mapped_draw_button(dist.column(align=True), context, data, '', icon='dist_h', props={'action': 'DISTRIBUTE_H'}, symbol='┉', scale_y=1.0)
        data = {'new_id': requested_op_id, 'en': 'Distribute Vertical', 'ja': '縦均等'}
        _mapped_draw_button(dist.column(align=True), context, data, '', icon='dist_v', props={'action': 'DISTRIBUTE_V'}, symbol='┋', scale_y=1.0)
    except Exception:
        pass

    if show_group_buttons:
        try:
            dist_g = pad_box.row(align=True)
            data = {'new_id': requested_op_id, 'en': 'Distribute Horizontal by Group', 'ja': '横均等 グループ'}
            _mapped_draw_button(dist_g.column(align=True), context, data, '', icon='dist_h', props={'action': 'DISTRIBUTE_H_GROUP'}, symbol='G┉', scale_y=1.0)
            data = {'new_id': requested_op_id, 'en': 'Distribute Vertical by Group', 'ja': '縦均等 グループ'}
            _mapped_draw_button(dist_g.column(align=True), context, data, '', icon='dist_v', props={'action': 'DISTRIBUTE_V_GROUP'}, symbol='G┋', scale_y=1.0)
        except Exception:
            pass

    try:
        transform = pad_box.row(align=True)
        data = {'new_id': requested_op_id, 'en': 'Flip Horizontal', 'ja': '左右反転'}
        transform_h_action = 'FLIP_H' if (is_vertex or unified) else 'MIRROR_H'
        _mapped_draw_button(transform.column(align=True), context, data, '', icon='mirror_h', props={'action': transform_h_action}, symbol='↔', scale_y=1.0)
        data = {'new_id': requested_op_id, 'en': 'Flip Vertical', 'ja': '上下反転'}
        transform_v_action = 'FLIP_V' if (is_vertex or unified) else 'MIRROR_V'
        _mapped_draw_button(transform.column(align=True), context, data, '', icon='mirror_v', props={'action': transform_v_action}, symbol='↕', scale_y=1.0)
    except Exception:
        pass

    try:
        rotate = pad_box.row(align=True)
        data = {'new_id': requested_op_id, 'en': 'Rotate 90° CCW', 'ja': '90°左'}
        _mapped_draw_button(rotate.column(align=True), context, data, '', icon='rotate_ccw', props={'action': 'ROTATE_CCW'}, symbol='90L', scale_y=1.0)
        data = {'new_id': requested_op_id, 'en': 'Rotate 90° CW', 'ja': '90°右'}
        _mapped_draw_button(rotate.column(align=True), context, data, '', icon='rotate_cw', props={'action': 'ROTATE_CW'}, symbol='90R', scale_y=1.0)
    except Exception:
        pass
    return True

def _draw_curated_vertex_align_sibling_sections(layout, context) -> None:
    """Draw former Direction Align (Vertices) grandchild tools as sibling sections."""
    try:
        line_flow = _curated_group(layout, context, 'Line / Flow', 'ライン・フロー', 'straight', 'uv_vertex_line_flow')
        if line_flow is not None:
            _curated_row(line_flow, context, (
                {'id': 'smart_uv_suite.align_edges', 'en': 'Align Edge', 'ja': '辺を整列', 'icon': 'align'},
                {'id': 'smart_uv_suite.inspect_orient_world', 'en': 'World Align', 'ja': 'ワールド軸整列', 'icon': 'orient_edge'},
                {'id': 'smart_uv_suite.vertex_straighten_selected', 'en': 'Straighten', 'ja': '直線化', 'icon': 'straight'},
                {'id': 'smart_uv_suite.vertex_even_straighten_selected', 'en': 'Even Straighten', 'ja': '均等直線化', 'icon': 'straight'},
            ), scale_y=1.08)
            _curated_row(line_flow, context, (
                {'id': 'smart_uv_suite.seam_rectify', 'en': 'Rectify', 'ja': '矩形補正', 'icon': 'rectify'},
                {'id': 'smart_uv_suite.align_uv_circle', 'en': 'Circularize', 'ja': '円形化', 'icon': 'circle'},
                {'id': 'smart_uv_suite.align_normalize', 'en': 'Normalize', 'ja': '正規化', 'icon': 'fit'},
            ))
            ws = _ws(context)
            relax_row = line_flow.row(align=True)
            data = {'new_id': 'smart_uv_suite.align_relax', 'id': 'smart_uv_suite.align_relax', 'en': 'Relax', 'ja': 'リラックス', 'icon': 'relax'}
            _mapped_draw_button(relax_row.column(align=True), context, data, '', icon='relax', symbol=None, scale_y=1.0)
            if ws is not None and hasattr(ws, 'smart_relax_iterations'):
                _prop(relax_row, ws, 'smart_relax_iterations', text=_tr(context, 'Relax Iterations', 'リラックス反復'))
            flow_row = line_flow.row(align=True)
            data = {'new_id': 'smart_uv_suite.vertex_set_flow_selected', 'id': 'smart_uv_suite.vertex_set_flow_selected', 'en': 'Set Flow', 'ja': 'フロー設定', 'icon': 'ref_flow'}
            _mapped_draw_button(flow_row.column(align=True), context, data, '', icon='ref_flow', symbol=None, scale_y=1.0)
            if ws is not None and hasattr(ws, 'uv_flow_strength'):
                _prop(flow_row, ws, 'uv_flow_strength', text=_tr(context, 'Flow Strength', 'フロー強度'))
    except Exception:
        pass
    try:
        mirror_ops = _curated_group(layout, context, 'Mirror', 'ミラー', 'mirror_h', 'uv_vertex_mirror_ops')
        if mirror_ops is not None:
            _curated_row(mirror_ops, context, (
                {'id': 'smart_uv_suite.seam_mirror_uv', 'en': 'Mirror UV', 'ja': 'UVミラー', 'icon': 'mirror_h'},
                {'id': 'smart_uv_suite.seam_symmetry_snap', 'en': 'Symmetry Snap', 'ja': '対称スナップ', 'icon': 'symmetry'},
            ), scale_y=1.08)
    except Exception:
        pass
    try:
        join_ops = _curated_group(layout, context, 'Combine', '結合', 'stack', 'uv_vertex_combine_ops')
        if join_ops is not None:
            _curated_row(join_ops, context, (
                {'id': 'smart_uv_suite.seam_stack_pro', 'en': 'Smart Stack', 'ja': 'スマートスタック', 'icon': 'stack'},
                {'id': 'smart_uv_suite.weld', 'en': 'Weld', 'ja': 'ウェルド', 'icon': 'weld'},
                {'id': 'smart_uv_suite.seam_merge', 'en': 'Merge Vertices', 'ja': '頂点マージ', 'icon': 'merge'},
            ), scale_y=1.08)
    except Exception:
        pass
    try:
        snap_ops = _curated_group(layout, context, 'Snap', '吸着', 'snap', 'uv_vertex_snap_ops')
        if snap_ops is not None:
            try:
                _prop(snap_ops, getattr(context, 'scene', None), 'suv_consolidated_snap_vertex_distance', text=_tr(context, 'Distance', '距離'))
            except Exception:
                pass
            _curated_row(snap_ops, context, (
                {'id': 'smart_uv_suite.consolidated_snap_uv', 'en': 'Grid', 'ja': 'グリッド', 'icon': 'snap', 'props': {'mode': 'GRID'}},
                {'id': 'smart_uv_suite.consolidated_snap_uv', 'en': 'Pixel', 'ja': 'ピクセル', 'icon': 'snap', 'props': {'mode': 'PIXEL'}},
                {'id': 'smart_uv_suite.consolidated_snap_uv', 'en': 'Vertex', 'ja': '頂点', 'icon': 'snap', 'props': {'mode': 'VERTEX'}},
            ))
    except Exception:
        pass




def _active_uv_editor(context):
    try:
        space = getattr(context, 'space_data', None)
        if getattr(space, 'type', '') == 'IMAGE_EDITOR':
            return getattr(space, 'uv_editor', None), space
    except Exception:
        pass
    return None, None

def _draw_uv_editor_aspect_ratio_after_grid(layout, context, space) -> None:
    """Draw the UV/Image Editor display-aspect control directly below Grid Subdivisions.

    Blender's native Image Editor sidebar exposes this value as
    View > Display > Aspect Ratio when an image is assigned.  The Smart UV Suite
    basic-settings panel mirrors that native control under Canvas / Grid so the
    guide-overlay controls stay in the same order requested for UV editing.
    """
    del space
    ws = _ws(context)
    if ws is not None and hasattr(ws, 'native_image_display_aspect'):
        try:
            row = layout.row(align=True)
            _prop(row, ws, 'native_image_display_aspect', text=_tr(context, 'Aspect Ratio', 'アスペクト比'))
            return
        except Exception:
            pass
    try:
        row = layout.row(align=True)
        row.enabled = False
        row.label(text=_tr(context, 'Aspect Ratio', 'アスペクト比'), icon='IMAGE_DATA')
    except Exception:
        pass



def _draw_selected_object_map_channel_rows(list_box, context, ws, rows=None) -> None:
    """Compatibility wrapper: always draw map channels as a dropdown.

    Older injected routes may still call this function name, but the visible UI
    must not expand into one row per UV map when many map channels exist.
    """
    try:
        _draw_selected_object_map_channel_dropdown(list_box, context, ws, rows)
    except Exception:
        pass



def _draw_selected_object_map_channel_dropdown(list_box, context, ws, channels=None) -> None:
    """Compatibility wrapper for older callers.

    The visible map-channel UI is now multi-object aware.  Older injected routes
    may call this function directly, so draw the same object list and selected
    object controls instead of the previous single-object dropdown.
    """
    del channels
    _uvc = _uv_map_channels
    if _uvc is None or ws is None:
        return
    try:
        _draw_map_channel_object_list(list_box, context, ws, _uvc)
        _draw_map_channel_selected_object_controls(list_box, context, ws, _uvc)
    except Exception:
        pass


def _draw_map_channel_object_list(layout, context, ws, _uvc) -> None:
    try:
        rows = _uvc.map_channel_object_rows(context, ws)
    except Exception:
        rows = []
    try:
        box = layout.box()
    except Exception:
        box = layout
    try:
        header = box.row(align=True)
        header.label(text=_tr(context, 'Selected Objects / Unwrap Map Channel', '選択中オブジェクト / 展開使用マップチャンネル'), icon='OBJECT_DATA')
    except Exception:
        pass
    if not rows:
        try:
            box.label(text=_tr(context, 'No selected mesh object.', '選択中のメッシュオブジェクトがありません。'), icon='NONE')
        except Exception:
            pass
        return
    for item in rows:
        try:
            obj_name = str(item.get('object_name', '') or '')
            target_index = int(item.get('target_index', -1))
            target_name = str(item.get('target_name', '') or '')
            selected = bool(item.get('selected', False))
            checked = bool(item.get('checked', False))
            channel_count = int(item.get('channel_count', 0) or 0)
            if channel_count > 0 and target_index >= 0:
                channel_label = f'{target_index}: {target_name}'
            else:
                channel_label = target_name or _tr(context, 'No UV map', 'UVマップなし')
            prefix = '▶ ' if selected else '  '
            row = box.row(align=True)
            try:
                chk = row.operator(
                    'smart_uv_suite.map_channel_toggle_unify_check',
                    text='',
                    icon='CHECKBOX_HLT' if checked else 'CHECKBOX_DEHLT',
                    emboss=True,
                )
                chk.object_name = obj_name
                _help_scope_register_operator('smart_uv_suite.map_channel_toggle_unify_check', 'Unify Check', '統一チェック', {'object_name': obj_name})
            except Exception:
                pass
            op = row.operator(
                'smart_uv_suite.map_channel_object_select',
                text=f'{prefix}{obj_name}    {channel_label}',
                icon='RADIOBUT_ON' if selected else 'RADIOBUT_OFF',
                emboss=True,
            )
            op.object_name = obj_name
            _help_scope_register_operator('smart_uv_suite.map_channel_object_select', 'Object Row', 'オブジェクト行', {'object_name': obj_name})
        except Exception:
            pass
    try:
        if len(rows) > 1:
            unify_row = box.row(align=True)
            unify_row.operator('smart_uv_suite.map_channel_unify_checked', text=_tr(context, 'Unify Checked', 'チェック対象を統一'), icon='LINKED')
            _help_scope_register_operator('smart_uv_suite.map_channel_unify_checked', 'Unify Checked', 'チェック対象を統一', {})
    except Exception:
        pass


def _draw_map_channel_selected_object_controls(layout, context, ws, _uvc) -> None:
    try:
        # Panel drawing is read-only.  The object-row operator establishes the
        # persistent editing target; never repair that target or mirror its UV
        # channel back into Scene RNA merely because Blender redraws the panel.
        obj = _uvc.map_channel_object_from_context(context, ws, fallback=False)
    except Exception:
        obj = None
    if obj is None:
        return
    try:
        layers = _uvc.uv_layers(obj)
        channel_count = len(layers) if layers is not None else 0
    except Exception:
        layers = None
        channel_count = 0
    try:
        target_index = _uvc.selected_index(context, ws, obj, create=False)
        target_index = int(target_index) if target_index is not None else 0
    except Exception:
        target_index = 0
    if channel_count > 0:
        try:
            target_index = max(0, min(int(target_index), int(channel_count) - 1))
        except Exception:
            target_index = 0
    try:
        layout.separator(factor=0.20)
    except Exception:
        pass
    try:
        box = layout.box()
    except Exception:
        box = layout
    try:
        box.label(text=_tr(context, 'Selected Object Controls', 'リスト選択オブジェクトの操作'), icon='PROPERTIES')
        box.label(text=str(getattr(obj, 'name', '') or ''), icon='OBJECT_DATA', translate=False)
    except Exception:
        pass
    try:
        row = box.row(align=True)
        row.enabled = channel_count > 0
        row.prop(ws, 'unwrap_map_channel', text=_tr(context, 'Unwrap Map Channel', '展開使用マップチャンネル'), translate=False)
    except Exception:
        try:
            _curated_props_grid(box, ws, (('unwrap_map_channel', 'Unwrap Map Channel', '展開使用マップチャンネル'),), columns=1)
        except Exception:
            pass
    if channel_count <= 0:
        try:
            box.label(text=_tr(context, 'No UV map channel exists. Use Add to create the first map channel.', 'UVマップチャンネルがありません。「追加」で最初のマップチャンネルを作成してください。'), icon='ADD')
        except Exception:
            pass
    else:
        try:
            active_index = int(getattr(layers, 'active_index', 0) or 0)
        except Exception:
            active_index = target_index
        try:
            layer = layers[target_index] if layers is not None and 0 <= target_index < channel_count else None
            layer_name = _uvc._safe_layer_name(layer, f'UVMap.{target_index + 1:03d}') if layer is not None else ''
        except Exception:
            layer_name = ''
        try:
            status = _tr(context, 'Active, Target', 'アクティブ・展開対象') if int(active_index) == int(target_index) else _tr(context, 'Target', '展開対象')
            state = box.row(align=True)
            state.label(text=f'{status} / ' + _tr(context, f'Index {target_index}', f'インデックス {target_index}') + (f' / {layer_name}' if layer_name else ''), icon='RADIOBUT_ON')
        except Exception:
            pass
    try:
        op_row = box.row(align=True)
        rename_cell = op_row.row(align=True)
        rename_cell.enabled = channel_count > 0
        rename_cell.operator('smart_uv_suite.map_channel_rename', text=_tr(context, 'Rename Channel', 'チャンネル名変更'), icon='GREASEPENCIL')
        _help_scope_register_operator('smart_uv_suite.map_channel_rename', 'Rename Channel', 'チャンネル名変更', {})
        add_op = op_row.operator('smart_uv_suite.map_channel_add', text=_tr(context, 'Add', '追加'), icon='ADD')
        _help_scope_register_operator('smart_uv_suite.map_channel_add', 'Add', '追加', {})
    except Exception:
        pass
    try:
        remove_row = box.row(align=True)
        remove_row.enabled = channel_count > 0
        remove_row.operator('smart_uv_suite.map_channel_remove', text=_tr(context, 'Remove Target', '展開対象を削除'), icon='REMOVE')
        _help_scope_register_operator('smart_uv_suite.map_channel_remove', 'Remove Target', '展開対象を削除', {})
    except Exception:
        pass
    try:
        move_row = box.row(align=True)
        up_cell = move_row.row(align=True)
        up_cell.enabled = channel_count > 1 and target_index > 0
        up_op = up_cell.operator('smart_uv_suite.map_channel_move', text=_tr(context, 'Move Up', '上へ移動'), icon='SORT_ASC')
        up_op.direction = -1
        _help_scope_register_operator('smart_uv_suite.map_channel_move', 'Move Up', '上へ移動', {'direction': '-1'})
        down_cell = move_row.row(align=True)
        down_cell.enabled = channel_count > 1 and target_index < max(0, channel_count - 1)
        down_op = down_cell.operator('smart_uv_suite.map_channel_move', text=_tr(context, 'Move Down', '下へ移動'), icon='SORT_DESC')
        down_op.direction = 1
        _help_scope_register_operator('smart_uv_suite.map_channel_move', 'Move Down', '下へ移動', {'direction': '1'})
    except Exception:
        pass


def _draw_map_channel_basic_settings(layout, context, ws) -> None:
    """Compatibility entry: draw the consolidated map-channel settings group."""
    _draw_map_channel_settings(layout, context, ws, 'basic_map_channels')



def _draw_map_channel_settings(layout, context, ws, storage_key='basic_map_channels') -> None:
    channels = _curated_foldout_group(
        layout, context, storage_key,
        'Map Channels', 'マップチャンネル', 'GROUP_UVS', storage_key, default=True,
    )
    if channels is None:
        return
    _uvc = _uv_map_channels
    if _uvc is None or ws is None:
        return
    try:
        _draw_map_channel_object_list(channels, context, ws, _uvc)
    except Exception:
        pass
    try:
        _draw_map_channel_selected_object_controls(channels, context, ws, _uvc)
    except Exception:
        pass


def _sus_1659_apply_dynamic_grid_subdivisions(context, ws=None, uv=None) -> None:
    """Mirror the Smart UV single-value dynamic grid subdivision setting to the active UV Editor guide grid."""
    try:
        value = int(getattr(ws, 'canvas_grid_dynamic_subdivisions', 10) if ws is not None else 10)
    except Exception:
        value = 10
    value = max(1, min(value, 5000))
    targets = []
    try:
        if uv is not None:
            targets.append(uv)
    except Exception:
        pass
    try:
        for area in getattr(getattr(context, 'screen', None), 'areas', []) or []:
            if getattr(area, 'type', '') != 'IMAGE_EDITOR':
                continue
            for space in getattr(area, 'spaces', []) or []:
                if getattr(space, 'type', '') == 'IMAGE_EDITOR' and getattr(space, 'uv_editor', None) is not None:
                    targets.append(getattr(space, 'uv_editor', None))
    except Exception:
        pass
    seen = set()
    for target in targets:
        try:
            key = id(target)
            if key in seen:
                continue
            seen.add(key)
            if target is None or not hasattr(target, 'custom_grid_subdivisions'):
                continue
            current = getattr(target, 'custom_grid_subdivisions')
            try:
                current[0] = value
                current[1] = value
            except Exception:
                setattr(target, 'custom_grid_subdivisions', (value, value))
        except Exception:
            pass

def _draw_basic_settings_section(body, context) -> None:
    ws = _ws(context)
    uv, space = _active_uv_editor(context)

    # Keep the top-level section unchanged, but split the inside into practical
    # UI blocks: UV map/channel management, canvas guides, editor display,
    # preview assets, and analysis/view tools.
    _draw_map_channel_settings(body, context, ws, 'basic_map_channels')

    canvas = _curated_foldout_group(
        body, context, 'basic_canvas_grid',
        'Canvas / Grid', 'キャンパス/グリッド', 'settings', 'basic_canvas_grid', default=True,
    )
    if canvas is not None:
        if ws is not None:
            try:
                _curated_props_grid(canvas, ws, (
                    ('native_uv_show_grid_over_image', 'Grid Over Image', '画像上にグリッド'),
                    ('native_uv_grid_shape_source', 'Grid Source', 'グリッド基準'),
                    ('native_uv_tile_grid_shape', 'Tile Grid', 'タイルグリッド'),
                ), columns=1)
                try:
                    grid_source = str(getattr(ws, 'native_uv_grid_shape_source', '') or '').upper()
                    # Blender 5.1's Dynamic/Pixel grid modes calculate their own
                    # visible guide cadence.  The previous Smart UV single-value
                    # subdivision control did not reliably map to those modes, so
                    # do not show or mirror it there.  Keep Blender's native custom
                    # subdivision control only for fixed/custom grid sources.
                    if grid_source not in {'DYNAMIC', 'PIXEL'}:
                        _curated_props_grid(canvas, ws, (
                            ('native_uv_custom_grid_subdivisions', 'Grid Subdivisions', 'グリッド分割'),
                        ), columns=1)
                except Exception:
                    pass
                _curated_props_grid(canvas, ws, (
                    ('native_uv_show_pixel_coords', 'Pixel Coordinates', 'ピクセル座標'),
                ), columns=1)
                try:
                    theme = getattr(getattr(getattr(context, 'preferences', None), 'themes', [None])[0], 'image_editor', None)
                    if theme is not None and hasattr(theme, 'grid'):
                        canvas.prop(theme, 'grid', text=_tr(context, 'Grid Color', 'グリッドカラー'))
                except Exception:
                    pass
                _draw_uv_editor_aspect_ratio_after_grid(canvas, context, space)
            except Exception:
                pass
        else:
            try:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            except Exception:
                pass
        _curated_row(canvas, context, (
            {'id': 'smart_uv_suite.export_uv_layout', 'en': 'Export UV Layout', 'ja': 'UV配置の書き出し', 'icon': 'EXPORT', 'scale_y': 1.18},
        ), scale_y=1.1)

    display = _curated_foldout_group(
        body, context, 'basic_uv_editor_view_display',
        'UV Editor Display', 'UVエディター表示', 'visual_reference', 'basic_uv_display', default=True,
    )
    if display is not None:
        if ws is not None:
            try:
                _curated_props_grid(display, ws, (
                    ('native_uv_show_uv', 'Display UVs', 'UVを表示'),
                    ('native_uv_show_faces', 'Display Faces', '面を表示'),
                    ('native_uv_edge_display_type', 'Edge Display', 'エッジ表示'),
                    ('native_uv_show_modified_edges', 'Modified Edges', '変更後エッジ'),
                    ('native_uv_show_stretch', 'Stretch Display', '歪み表示'),
                    ('native_uv_display_stretch_type', 'Stretch Type', '歪み種類'),
                    ('native_uv_uv_opacity', 'UV Opacity', 'UV不透明度'),
                    ('native_uv_uv_face_opacity', 'Face Opacity', '面不透明度'),
                    ('native_uv_uv_edge_opacity', 'Edge Opacity', 'エッジ不透明度'),
                    ('native_uv_stretch_opacity', 'Stretch Opacity', '歪み不透明度'),
                    ('native_uv_pixel_round_mode', 'Pixel Rounding', 'ピクセル丸め'),
                    ('native_uv_lock_bounds', 'Lock Bounds', '画像範囲固定'),
                ), columns=1)
                try:
                    if hasattr(ws, 'native_space_show_repeat'):
                        _curated_props_grid(display, ws, (
                            ('native_space_show_repeat', 'Repeat Image', '画像を反復表示'),
                        ), columns=1)
                except Exception:
                    pass
            except Exception:
                pass
        else:
            try:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            except Exception:
                pass

    preview = _curated_foldout_group(
        body, context, 'basic_preview_checker',
        'Preview / Checker', 'プレビュー/チェッカー', 'checker', 'basic_preview_checker', default=True,
    )
    if preview is not None:
        _curated_props_grid(preview, ws, (
            ('checker_size_width', 'Image Resolution Width', '画像解像度 横'),
            ('checker_size_height', 'Image Resolution Height', '画像解像度 縦'),
            ('checker_tile_count_u', 'Checker Tiles U', 'チェックサイズ 横'),
            ('checker_tile_count_v', 'Checker Tiles V', 'チェックサイズ 縦'),
            ('checker_color_a', 'Checker Color 1', 'チェックカラー1'),
            ('checker_color_b', 'Checker Color 2', 'チェックカラー2'),
            ('checker_image_name', 'Image Name', '画像名'),
            ('checker_material_name', 'Material Name', 'マテリアル名'),
        ), columns=1)
        _curated_row(preview, context, (
            {'id': 'smart_uv_suite.checker_create', 'en': 'Create Checker', 'ja': 'チェッカー作成', 'icon': 'checker'},
            {'id': 'smart_uv_suite.checker_delete', 'en': 'Delete Checker', 'ja': 'チェッカー削除', 'icon': 'cleanup'},
        ), scale_y=1.15)
        try:
            active = False
            for _obj in getattr(context, 'selected_objects', []) or []:
                if getattr(_obj, 'type', None) == 'MESH' and bool(_obj.get('suv_checker_material_preview_active', False)):
                    active = True
                    break
            txt = _tr(context, 'Restore Materials', 'マテリアルを元に戻す') if active else _tr(context, 'Apply to Materials', 'マテリアルに反映')
            if _operator_exists('smart_uv_suite.checker_material_toggle'):
                row = preview.row(align=True)
                row.scale_y = 1.12
                row.operator('smart_uv_suite.checker_material_toggle', text=txt, icon=_standard_icon('checker'))
                _help_scope_register_operator('smart_uv_suite.checker_material_toggle', 'Restore Materials' if active else 'Apply to Materials', 'マテリアルを元に戻す' if active else 'マテリアルに反映', {})
        except Exception:
            pass

    # 解析/表示ツールは仕様変更により基本設定から完全に削除。

def _suv_smart_standard_core_resolved_mode_for_ui(ws):
    actual_modes = {'SMART_STANDARD_HARD', 'SMART_STANDARD_ORGANIC', 'SMART', 'NORMAL'}
    mode_map = {
        'STANDARD_KEEP': 'SMART_STANDARD_HARD',
        'BALANCED': 'SMART_STANDARD_HARD',
        'LOW_STRETCH': 'SMART_STANDARD_ORGANIC',
        'LOOP_SAFE': 'SMART_STANDARD_HARD',
        'AREA_ACCURATE': 'SMART',
        'QUALITY_OPTIMIZE': 'SMART_STANDARD_ORGANIC',
        'CLEAN_MERGE': 'SMART_STANDARD_ORGANIC',
        'PACK_STABLE': 'SMART',
    }
    try:
        raw = str(getattr(ws, 'smart_standard_core_unwrap_mode', 'SMART_STANDARD_HARD') or 'SMART_STANDARD_HARD').upper()
    except Exception:
        raw = 'SMART_STANDARD_HARD'
    if raw in actual_modes:
        return raw
    if raw in {'CUSTOM', 'SINGLE_ISLAND'}:
        for attr in ('smart_standard_core_resolved_unwrap_mode', 'smart_standard_core_last_actual_unwrap_mode'):
            try:
                value = str(getattr(ws, attr, '') or '').upper()
            except Exception:
                value = ''
            if value in actual_modes:
                return value
    return mode_map.get(raw, 'SMART_STANDARD_HARD')


def _draw_smart_standard_core_unwrap_settings(parent, context, ws, storage_key='smart_standard_core_settings'):
    smart = _curated_foldout_group(parent, context, storage_key, 'Smart UV Standard Core', 'スマート展開設定', 'smart', 'unwrap_auto', default=True)
    if smart is None or ws is None:
        return

    # The Smart method uses one unified control surface.  Changing 展開モード only
    # changes the stored numeric values/preset; it must not hide or show a
    # different set of controls because that makes Custom settings unreliable and
    # difficult to compare between presets.
    core = _curated_foldout_group(smart, context, storage_key + '_core', 'Unwrap Core', '展開コア', 'UV', 'unwrap_auto', default=True)
    if core is not None:
        _curated_props_grid(core, ws, (
            ('smart_standard_core_unwrap_mode', 'Unwrap Mode', '展開モード'),
            ('smart_standard_core_unwrap_math', 'Unwrap Math', '計算方式'),
            ('smart_standard_core_smart_angle', 'Angle Limit', '角度制限'),
            ('smart_standard_core_smart_area_weight', 'Area Weight', '面積ウェイト'),
        ), columns=1)

    reference = _curated_foldout_group(smart, context, storage_key + '_reference', 'Reference Tool Precision', '高精度チャート解析', 'quality', 'unwrap_auto', default=True)
    if reference is not None:
        _curated_props_grid(reference, ws, (
            ('smart_standard_core_reference_refine_enabled', 'Enable', '有効'),
            ('smart_standard_core_reference_profile', 'Profile', 'プロファイル'),
            ('smart_standard_core_reference_strength', 'Strength', '解析強度'),
            ('smart_standard_core_reference_allowed_stretch', 'Allowed Stretch', '許容ストレッチ'),
            ('smart_standard_core_reference_concave_angle', 'Concave Angle', '凹角度シーム'),
            ('smart_standard_core_reference_convex_angle', 'Convex Angle', '凸角度シーム'),
            ('smart_standard_core_reference_existing_seam_weight', 'Existing Seams', '既存シーム保持'),
            ('smart_standard_core_reference_fewer_charts', 'Fewer Charts', '少チャート優先'),
            ('smart_standard_core_reference_loop_weight', 'Loop Boundary', 'ループ境界維持'),
            ('smart_standard_core_reference_triangle_border', 'Triangle Border', '三角境界許容'),
            ('smart_standard_core_reference_cylindrical_loop', 'Cylindrical Loop', '筒状ループ補助'),
        ), columns=1)

    seam = _curated_foldout_group(smart, context, storage_key + '_single_seam', 'Single Island Seam Analysis', 'Singleアイランド・シーム解析', 'seam', 'unwrap_auto', default=True)
    if seam is not None:
        _curated_props_grid(seam, ws, (
            ('smart_standard_core_seam_merge_strength', 'Island Merge', 'アイランド結合率'),
            ('smart_standard_core_single_angle_weight', 'Edge Angle Keep', '辺角度維持'),
            ('smart_standard_core_single_stretch_weight', 'Stretch Prediction', '引張予測'),
            ('smart_standard_core_single_loop_weight', 'Loop Preserve', 'ループ辺維持'),
            ('smart_standard_core_single_planarity_weight', 'Planarity Keep', '平面性維持'),
            ('smart_standard_core_single_density_weight', 'Density Keep', '面積密度維持'),
            ('smart_standard_core_single_user_seam_weight', 'Existing Seam Keep', '既存シーム維持'),
            ('smart_standard_core_single_boundary_weight', 'Boundary Continuity', '境界連続性'),
            ('smart_standard_core_single_small_island_merge', 'Small Island Merge', '小島統合'),
        ), columns=1)

    quality = _curated_foldout_group(smart, context, storage_key + '_quality', 'Quality Optimization', '品質最適化', 'quality', 'unwrap_auto', default=True)
    if quality is not None:
        _curated_props_grid(quality, ws, (
            ('smart_standard_core_quality_strength', 'Quality Blend', '高品質最適化'),
            ('smart_standard_core_area_preserve_strength', 'Area Preserve', '面積維持'),
            ('smart_standard_core_shape_preserve_strength', 'Shape Preserve', '形状維持'),
            ('smart_standard_core_native_result_preserve', 'Native Result Keep', '標準結果維持'),
            ('smart_standard_core_quality_iterations', 'Iterations', '反復'),
        ), columns=1)

    stretch = _curated_foldout_group(smart, context, storage_key + '_stretch', 'Stretch Minimization', 'ストレッチ軽減', 'MODIFIER_ON', 'unwrap_auto', default=True)
    if stretch is not None:
        _curated_props_grid(stretch, ws, (
            ('smart_standard_core_stretch_iterations', 'Iterations', '反復'),
            ('smart_standard_core_stretch_blend', 'Blend Strength', 'ブレンド強度'),
        ), columns=1)

    base = _curated_foldout_group(smart, context, storage_key + '_baseline', 'Baseline Pinning', '基準直線化', 'PINNED', 'unwrap_auto', default=True)
    if base is not None:
        _curated_props_grid(base, ws, (
            ('smart_standard_core_baseline_axis', 'Local Axis', 'ローカル軸'),
            ('smart_standard_core_baseline_threshold', 'Threshold', 'しきい値'),
        ), columns=1)

    pack = _curated_foldout_group(smart, context, storage_key + '_pack', 'Packing Options', 'パッキング設定', 'UV_ISLANDSEL', 'unwrap_auto', default=True)
    if pack is not None:
        _curated_props_grid(pack, ws, (
            ('smart_standard_core_auto_pack', 'Enable Auto Pack', '自動パック'),
            ('smart_standard_core_pack_margin', 'Margin', '余白'),
            ('smart_standard_core_pack_margin_method', 'Margin Method', '余白方式'),
            ('smart_standard_core_pack_rotate_method', 'Rotation', '回転'),
        ), columns=1)
        if str(getattr(ws, 'smart_standard_core_baseline_axis', 'NONE') or 'NONE').upper() != 'NONE':
            try:
                pass  # INFO-note moved to Help; no in-section info-icon explanation.
            except Exception:
                pass

    prep = _curated_foldout_group(smart, context, storage_key + '_prep', 'Mesh Pre-Processing', 'メッシュ前処理', 'MESH_DATA', 'unwrap_auto', default=True)
    if prep is not None:
        _curated_props_grid(prep, ws, (
            ('smart_standard_core_pre_fix_mesh', 'Auto Fix Mesh', 'メッシュ自動修正'),
            ('smart_standard_core_merge_distance', 'Merge Dist', '結合距離'),
        ), columns=1)


def _draw_blender_native_operator_settings(parent, context, ws, current_method: str, storage_prefix: str) -> None:
    """Draw Blender native UV operator popup settings as persistent Smart UV fields."""
    if ws is None:
        return
    method = str(current_method or '').upper()
    native_methods = {
        'BLENDER_ANGLE_BASED', 'BLENDER_CONFORMAL', 'BLENDER_MIN_STRETCH',
        'BLENDER_SMART_PROJECT', 'BLENDER_LIGHTMAP_PACK', 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'BOX_PROJECT', 'CYLINDRICAL', 'SPHERICAL',
    }
    if method not in native_methods:
        return
    native = _curated_foldout_group(parent, context, storage_prefix + '_native_popup', 'Blender Native Operator Settings', 'Blender標準ポップアップ設定', 'UV', 'unwrap_auto', default=True)
    if native is None:
        return
    if method in {'BLENDER_ANGLE_BASED', 'BLENDER_CONFORMAL', 'BLENDER_MIN_STRETCH'}:
        unwrap_box = _curated_foldout_group(native, context, storage_prefix + '_native_unwrap', 'Unwrap Popup', 'Unwrapポップアップ', 'UV', 'unwrap_auto', default=True)
        if unwrap_box is not None:
            _curated_props_grid(unwrap_box, ws, (
                ('native_unwrap_fill_holes', 'Fill Holes', '穴を埋める'),
                ('native_unwrap_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
                ('native_unwrap_use_subsurf_data', 'Use Subsurf Data', 'サブサーフデータ使用'),
                ('native_unwrap_margin_method', 'Margin Method', '余白方式'),
                ('native_unwrap_margin', 'Margin', '余白'),
                ('native_unwrap_no_flip', 'No Flip', '反転防止'),
                ('native_unwrap_iterations', 'Iterations', '反復'),
                ('native_unwrap_use_weights', 'Use Weights', 'ウェイト使用'),
                ('native_unwrap_weight_group', 'Weight Group', 'ウェイトグループ'),
                ('native_unwrap_weight_factor', 'Weight Factor', 'ウェイト係数'),
            ), columns=2)
        if method == 'BLENDER_MIN_STRETCH':
            minimize_box = _curated_foldout_group(native, context, storage_prefix + '_native_minimize', 'Minimize Stretch Popup', '最小ストレッチポップアップ', 'MOD_SMOOTH', 'unwrap_auto', default=True)
            if minimize_box is not None:
                _curated_props_grid(minimize_box, ws, (
                    ('native_minimize_stretch_after', 'Run After Unwrap', '展開後に実行'),
                    ('native_minimize_stretch_fill_holes', 'Fill Holes', '穴を埋める'),
                    ('native_minimize_stretch_blend', 'Blend', 'ブレンド'),
                    ('native_minimize_stretch_iterations', 'Iterations', '反復'),
                ), columns=2)
    elif method == 'BLENDER_SMART_PROJECT':
        smart_box = _curated_foldout_group(native, context, storage_prefix + '_native_smart_project', 'Smart UV Project Settings', '詳細投影設定', 'MOD_UVPROJECT', 'unwrap_auto', default=True)
        if smart_box is not None:
            _curated_props_grid(smart_box, ws, (
                ('native_smart_project_angle_limit', 'Angle Limit', '角度制限'),
                ('native_smart_project_margin_method', 'Margin Method', '余白方式'),
                ('native_smart_project_rotate_method', 'Rotate Method', '回転方式'),
                ('native_smart_project_island_margin', 'Island Margin', 'アイランド余白'),
                ('native_smart_project_area_weight', 'Area Weight', '面積ウェイト'),
                ('native_smart_project_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
                ('native_smart_project_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
            ), columns=1)
    elif method == 'BLENDER_LIGHTMAP_PACK':
        lightmap_box = _curated_foldout_group(native, context, storage_prefix + '_native_lightmap', 'Lightmap Pack Popup', 'ライトマップパックポップアップ', 'LIGHT', 'unwrap_auto', default=True)
        if lightmap_box is not None:
            _curated_props_grid(lightmap_box, ws, (
                ('native_lightmap_context', 'Context', '対象'),
                ('native_lightmap_pack_in_one', 'Pack In One', '1つにパック'),
                ('native_lightmap_new_uvlayer', 'New UV Layer', '新規UVレイヤー'),
                ('native_lightmap_box_div', 'Box Divisions', 'ボックス分割'),
                ('native_lightmap_margin_div', 'Margin Division', '余白分割'),
            ), columns=1)
    elif method == 'BLENDER_FOLLOW_ACTIVE_QUADS':
        follow_box = _curated_foldout_group(native, context, storage_prefix + '_native_follow_quads', 'Follow Active Quads Popup', 'アクティブ四角形面に追従ポップアップ', 'MOD_UVPROJECT', 'unwrap_auto', default=True)
        if follow_box is not None:
            _curated_props_grid(follow_box, ws, (
                ('native_follow_quads_mode', 'Mode', 'モード'),
            ), columns=1)
    elif method == 'BOX_PROJECT':
        cube_box = _curated_foldout_group(native, context, storage_prefix + '_native_cube', 'Cube Projection Popup', 'キューブ投影ポップアップ', 'MESH_CUBE', 'unwrap_auto', default=True)
        if cube_box is not None:
            _curated_props_grid(cube_box, ws, (
                ('native_cube_size', 'Cube Size', 'キューブサイズ'),
                ('native_cube_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
                ('native_cube_clip_to_bounds', 'Clip To Bounds', '境界でクリップ'),
                ('native_cube_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
            ), columns=2)
    elif method == 'CYLINDRICAL':
        cyl_box = _curated_foldout_group(native, context, storage_prefix + '_native_cylinder', 'Cylindrical Projection Popup', '円筒状投影ポップアップ', 'MESH_CYLINDER', 'unwrap_auto', default=True)
        if cyl_box is not None:
            _curated_props_grid(cyl_box, ws, (
                ('native_cylinder_direction', 'Direction', '方向'),
                ('native_cylinder_align', 'Align', '整列'),
                ('native_cylinder_pole', 'Pole', '極'),
                ('native_cylinder_seam', 'Seam', 'シーム'),
                ('native_cylinder_radius', 'Radius', '半径'),
                ('native_cylinder_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
                ('native_cylinder_clip_to_bounds', 'Clip To Bounds', '境界でクリップ'),
                ('native_cylinder_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
            ), columns=2)
    elif method == 'SPHERICAL':
        sph_box = _curated_foldout_group(native, context, storage_prefix + '_native_sphere', 'Spherical Projection Popup', '球状投影ポップアップ', 'MESH_UVSPHERE', 'unwrap_auto', default=True)
        if sph_box is not None:
            _curated_props_grid(sph_box, ws, (
                ('native_sphere_direction', 'Direction', '方向'),
                ('native_sphere_align', 'Align', '整列'),
                ('native_sphere_pole', 'Pole', '極'),
                ('native_sphere_seam', 'Seam', 'シーム'),
                ('native_sphere_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
                ('native_sphere_clip_to_bounds', 'Clip To Bounds', '境界でクリップ'),
                ('native_sphere_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
            ), columns=2)
    try:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass

def _draw_global_baseline_straightening_settings(parent, context, ws, storage_key='global_baseline_straightening') -> None:
    """Draw the shared Baseline Straightening controls for every unwrap method.

    The properties live in the Smart Standard core namespace because the Smart
    route introduced them first, but the executor now applies the same values
    after all destructive UV unwrap/projection modes before the selected-face
    pack.  This panel is intentionally shown for non-Smart methods so users do
    not have to switch to Smart just to configure 基準直線化.
    """
    if ws is None:
        return
    base = _curated_foldout_group(parent, context, storage_key, 'Baseline Straightening', '基準直線化', 'PINNED', 'unwrap_auto', default=True)
    if base is None:
        return
    _curated_props_grid(base, ws, (
        ('smart_standard_core_baseline_axis', 'Baseline Target', '基準対象'),
        ('smart_standard_core_baseline_threshold', 'Axis Threshold', '軸しきい値'),
    ), columns=1)
    try:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass



def _suv_direct_settings_label(layout, context, label_en: str, label_ja: str, icon: str = 'PREFERENCES') -> None:
    """Draw a plain non-foldout label inside Method Settings.

    The top-level and child section formats are kept unchanged.  This helper is
    used only inside UV展開 > 方式別設定 so the many per-method fields sit
    directly under that single section instead of being hidden in additional
    nested subsections.
    """
    try:
        row = layout.row(align=True)
        row.label(text=_tr(context, label_en, label_ja), icon=_standard_icon(icon))
    except Exception:
        try:
            layout.label(text=_tr(context, label_en, label_ja))
        except Exception:
            pass


def _draw_smart_standard_core_unwrap_settings_direct(parent, context, ws) -> None:
    if ws is None:
        return
    _suv_direct_settings_label(parent, context, 'Smart UV Standard Core', 'スマート展開設定', 'UV')
    _curated_props_grid(parent, ws, (
        ('smart_standard_core_unwrap_mode', 'Unwrap Mode', '展開モード'),
        ('smart_standard_core_unwrap_math', 'Unwrap Math', '計算方式'),
        ('smart_standard_core_smart_angle', 'Angle Limit', '角度制限'),
        ('smart_standard_core_smart_area_weight', 'Area Weight', '面積ウェイト'),
    ), columns=2)
    try: parent.separator(factor=0.2)
    except Exception: pass

    _suv_direct_settings_label(parent, context, 'High Precision Chart Analysis', '高精度チャート解析', 'QUALITY_HIGH')
    _curated_props_grid(parent, ws, (
        ('smart_standard_core_reference_refine_enabled', 'Enable', '有効'),
        ('smart_standard_core_reference_profile', 'Profile', 'プロファイル'),
        ('smart_standard_core_reference_strength', 'Strength', '解析強度'),
        ('smart_standard_core_reference_allowed_stretch', 'Allowed Stretch', '許容ストレッチ'),
        ('smart_standard_core_reference_concave_angle', 'Concave Angle', '凹角度シーム'),
        ('smart_standard_core_reference_convex_angle', 'Convex Angle', '凸角度シーム'),
        ('smart_standard_core_reference_existing_seam_weight', 'Existing Seams', '既存シーム保持'),
        ('smart_standard_core_reference_fewer_charts', 'Fewer Charts', '少チャート優先'),
        ('smart_standard_core_reference_loop_weight', 'Loop Boundary', 'ループ境界維持'),
        ('smart_standard_core_reference_triangle_border', 'Triangle Border', '三角境界許容'),
        ('smart_standard_core_reference_cylindrical_loop', 'Cylindrical Loop', '筒状ループ補助'),
    ), columns=2)
    try: parent.separator(factor=0.2)
    except Exception: pass

    _suv_direct_settings_label(parent, context, 'Single Island Seam Analysis', 'Singleアイランド・シーム解析', 'MOD_EDGESPLIT')
    _curated_props_grid(parent, ws, (
        ('smart_standard_core_seam_merge_strength', 'Island Merge', 'アイランド結合率'),
        ('smart_standard_core_single_angle_weight', 'Edge Angle Keep', '辺角度維持'),
        ('smart_standard_core_single_stretch_weight', 'Stretch Prediction', '引張予測'),
        ('smart_standard_core_single_loop_weight', 'Loop Preserve', 'ループ辺維持'),
        ('smart_standard_core_single_planarity_weight', 'Planarity Keep', '平面性維持'),
        ('smart_standard_core_single_density_weight', 'Density Keep', '面積密度維持'),
        ('smart_standard_core_single_user_seam_weight', 'Existing Seam Keep', '既存シーム維持'),
        ('smart_standard_core_single_boundary_weight', 'Boundary Continuity', '境界連続性'),
        ('smart_standard_core_single_small_island_merge', 'Small Island Merge', '小島統合'),
    ), columns=2)
    try: parent.separator(factor=0.2)
    except Exception: pass

    _suv_direct_settings_label(parent, context, 'Quality Optimization', '品質最適化', 'MOD_SMOOTH')
    _curated_props_grid(parent, ws, (
        ('smart_standard_core_quality_strength', 'Quality Blend', '高品質最適化'),
        ('smart_standard_core_area_preserve_strength', 'Area Preserve', '面積維持'),
        ('smart_standard_core_shape_preserve_strength', 'Shape Preserve', '形状維持'),
        ('smart_standard_core_native_result_preserve', 'Native Result Keep', '標準結果維持'),
        ('smart_standard_core_quality_iterations', 'Iterations', '反復'),
    ), columns=2)
    try: parent.separator(factor=0.2)
    except Exception: pass

    _suv_direct_settings_label(parent, context, 'Stretch / Baseline / Packing / Mesh', 'ストレッチ / 基準直線化 / パック / メッシュ', 'PREFERENCES')
    _curated_props_grid(parent, ws, (
        ('smart_standard_core_stretch_iterations', 'Stretch Iterations', 'ストレッチ反復'),
        ('smart_standard_core_stretch_blend', 'Stretch Blend', 'ストレッチ強度'),
        ('smart_standard_core_baseline_axis', 'Baseline Target', '基準対象'),
        ('smart_standard_core_baseline_threshold', 'Axis Threshold', '軸しきい値'),
        ('smart_standard_core_auto_pack', 'Enable Auto Pack', '自動パック'),
        ('smart_standard_core_pack_margin', 'Pack Margin', 'パック余白'),
        ('smart_standard_core_pack_margin_method', 'Margin Method', '余白方式'),
        ('smart_standard_core_pack_rotate_method', 'Rotation', '回転'),
        ('smart_standard_core_pre_fix_mesh', 'Auto Fix Mesh', 'メッシュ自動修正'),
        ('smart_standard_core_merge_distance', 'Merge Distance', '結合距離'),
    ), columns=2)


def _draw_blender_native_operator_settings_direct(parent, context, ws, current_method: str) -> None:
    """Draw native popup settings directly under UV展開 > 方式別設定."""
    if ws is None:
        return
    method = str(current_method or '').upper()
    native_methods = {
        'BLENDER_ANGLE_BASED', 'BLENDER_CONFORMAL', 'BLENDER_MIN_STRETCH',
        'BLENDER_SMART_PROJECT', 'BLENDER_LIGHTMAP_PACK', 'BLENDER_FOLLOW_ACTIVE_QUADS',
        'BOX_PROJECT', 'CYLINDRICAL', 'SPHERICAL',
    }
    if method not in native_methods:
        return
    _suv_direct_settings_label(parent, context, 'Blender Native Operator Settings', 'Blender標準ポップアップ設定', 'UV')
    if method in {'BLENDER_ANGLE_BASED', 'BLENDER_CONFORMAL', 'BLENDER_MIN_STRETCH'}:
        _curated_props_grid(parent, ws, (
            ('native_unwrap_fill_holes', 'Fill Holes', '穴を埋める'),
            ('native_unwrap_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
            ('native_unwrap_use_subsurf_data', 'Use Subsurf Data', 'サブサーフデータ使用'),
            ('native_unwrap_margin_method', 'Margin Method', '余白方式'),
            ('native_unwrap_margin', 'Margin', '余白'),
            ('native_unwrap_no_flip', 'No Flip', '反転防止'),
            ('native_unwrap_iterations', 'Iterations', '反復'),
            ('native_unwrap_use_weights', 'Use Weights', 'ウェイト使用'),
            ('native_unwrap_weight_group', 'Weight Group', 'ウェイトグループ'),
            ('native_unwrap_weight_factor', 'Weight Factor', 'ウェイト係数'),
        ), columns=2)
        if method == 'BLENDER_MIN_STRETCH':
            try: parent.separator(factor=0.2)
            except Exception: pass
            _suv_direct_settings_label(parent, context, 'Minimize Stretch', '最小ストレッチ', 'MOD_SMOOTH')
            _curated_props_grid(parent, ws, (
                ('native_minimize_stretch_after', 'Run After Unwrap', '展開後に実行'),
                ('native_minimize_stretch_fill_holes', 'Fill Holes', '穴を埋める'),
                ('native_minimize_stretch_blend', 'Blend', 'ブレンド'),
                ('native_minimize_stretch_iterations', 'Iterations', '反復'),
            ), columns=2)
    elif method == 'BLENDER_SMART_PROJECT':
        _curated_props_grid(parent, ws, (
            ('native_smart_project_angle_limit', 'Angle Limit', '角度制限'),
            ('native_smart_project_margin_method', 'Margin Method', '余白方式'),
            ('native_smart_project_rotate_method', 'Rotate Method', '回転方式'),
            ('native_smart_project_island_margin', 'Island Margin', 'アイランド余白'),
            ('native_smart_project_area_weight', 'Area Weight', '面積ウェイト'),
            ('native_smart_project_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
            ('native_smart_project_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
        ), columns=2)
    elif method == 'BLENDER_LIGHTMAP_PACK':
        _curated_props_grid(parent, ws, (
            ('native_lightmap_context', 'Context', '対象'),
            ('native_lightmap_pack_in_one', 'Pack In One', '1つにパック'),
            ('native_lightmap_new_uvlayer', 'New UV Layer', '新規UVレイヤー'),
            ('native_lightmap_box_div', 'Box Divisions', 'ボックス分割'),
            ('native_lightmap_margin_div', 'Margin Division', '余白分割'),
        ), columns=2)
    elif method == 'BLENDER_FOLLOW_ACTIVE_QUADS':
        _curated_props_grid(parent, ws, (('native_follow_quads_mode', 'Mode', 'モード'),), columns=1)
    elif method == 'BOX_PROJECT':
        _curated_props_grid(parent, ws, (
            ('native_cube_size', 'Cube Size', 'キューブサイズ'),
            ('native_cube_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
            ('native_cube_clip_to_bounds', 'Clip To Bounds', '境界でクリップ'),
            ('native_cube_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
        ), columns=2)
    elif method == 'CYLINDRICAL':
        _curated_props_grid(parent, ws, (
            ('native_cylinder_direction', 'Direction', '方向'),
            ('native_cylinder_align', 'Align', '整列'),
            ('native_cylinder_pole', 'Pole', '極'),
            ('native_cylinder_seam', 'Seam', 'シーム'),
            ('native_cylinder_radius', 'Radius', '半径'),
            ('native_cylinder_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
            ('native_cylinder_clip_to_bounds', 'Clip To Bounds', '境界でクリップ'),
            ('native_cylinder_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
        ), columns=2)
    elif method == 'SPHERICAL':
        _curated_props_grid(parent, ws, (
            ('native_sphere_direction', 'Direction', '方向'),
            ('native_sphere_align', 'Align', '整列'),
            ('native_sphere_pole', 'Pole', '極'),
            ('native_sphere_seam', 'Seam', 'シーム'),
            ('native_sphere_correct_aspect', 'Correct Aspect', 'アスペクト補正'),
            ('native_sphere_clip_to_bounds', 'Clip To Bounds', '境界でクリップ'),
            ('native_sphere_scale_to_bounds', 'Scale To Bounds', '境界へスケール'),
        ), columns=2)
    try:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass


def _draw_global_baseline_straightening_settings_direct(parent, context, ws) -> None:
    if ws is None:
        return
    _suv_direct_settings_label(parent, context, 'Baseline Straightening', '基準直線化', 'PINNED')
    _curated_props_grid(parent, ws, (
        ('smart_standard_core_baseline_axis', 'Baseline Target', '基準対象'),
        ('smart_standard_core_baseline_threshold', 'Axis Threshold', '軸しきい値'),
    ), columns=2)


def _draw_shape_projection_settings_direct(parent, context, ws, current_method: str) -> None:
    if ws is None:
        return
    method = str(current_method or '').upper()
    if method in {'SMART_SQUARE', 'SMART_CIRCLE'}:
        _suv_direct_settings_label(parent, context, 'Shape Method Settings', '形状方式設定', 'MOD_UVPROJECT')
        strength_prop = 'smart_unwrap_spring_strength' if method == 'SMART_SQUARE' else 'smart_unwrap_pull_distance'
        _curated_props_grid(parent, ws, ((strength_prop, 'Strength', '強度'), ('smart_unwrap_orientation_angle', 'Orientation', '向き')), columns=2)
    elif method == 'FLAT_MAPPING':
        _suv_direct_settings_label(parent, context, 'Flat Mapping Settings', 'フラット専用設定', 'MOD_UVPROJECT')
        _curated_props_grid(parent, ws, (
            ('flat_mapping_angle_threshold', 'Flat Angle', 'フラット角度'),
            ('flat_mapping_spacing', 'Spacing', '余白'),
            ('flat_mapping_area_weight', 'Area Weight', '面積ウェイト'),
            ('flat_mapping_pack_after', 'Pack', 'パック'),
        ), columns=2)
    elif method in {'QUICK_PLANAR', 'VIEW_PROJECT'}:
        _suv_direct_settings_label(parent, context, 'Projection Gizmo', '投影ギズモ', 'ORIENTATION_GIMBAL')
        _curated_props_grid(parent, ws, (
            ('projection_gizmo_use', 'Use Gizmo', 'ギズモ使用'),
            ('projection_gizmo_object_name', 'Gizmo Object', 'ギズモ名'),
            ('projection_gizmo_fit_to_selection', 'Fit To Selection', '選択へ合わせる'),
            ('projection_gizmo_auto_create', 'Auto Create', '自動作成'),
            ('projection_gizmo_normalize', 'Normalize', '正規化'),
            ('projection_gizmo_tile_scale', 'Tile Scale', 'タイル倍率'),
            ('projection_gizmo_cylinder_offset', 'Seam Offset', 'シーム角度'),
        ), columns=2)
        try:
            row = parent.row(align=True)
            _curated_button(row, context, 'smart_uv_suite.projection_gizmo_action', 'Create / Update', '作成/更新', 'ADD', props={'action': 'CREATE'}, scale_y=1.0)
            _curated_button(row, context, 'smart_uv_suite.projection_gizmo_action', 'Fit', 'フィット', 'PIVOT_BOUNDBOX', props={'action': 'FIT'}, scale_y=1.0)
            _curated_button(row, context, 'smart_uv_suite.projection_gizmo_action', 'Remove', '削除', 'X', props={'action': 'REMOVE'}, scale_y=1.0)
        except Exception:
            pass

# ---------------------------------------------------------------------------
# Smart UV Suite 1.8.241 - Execute Unwrap button row
# Execute Unwrap used to share the Method / Live Unwrap ``row(align=True)``.  In
# one aligned row an enum, a checkbox and an operator compete for the same width,
# and ``_curated_button`` returns without drawing anything when the operator RNA
# snapshot has no entry for this draw, so the action could be missing or show as a
# dead label.  Draw it on its own full-width row directly below Method and Live
# Unwrap, using the same plain ``row(align=True)`` + ``row.operator`` shape as UV
# Layout Export and Apply to Materials, so the button is always present and always
# dispatches ``smart_uv_suite.unwrap_auto_run``.
# ---------------------------------------------------------------------------
_SUV_UNWRAP_EXECUTE_OPERATOR = 'smart_uv_suite.unwrap_auto_run'


def _draw_unwrap_execute_row(parent, context) -> bool:
    if parent is None:
        return False
    label = _tr(context, 'Run Unwrap', '展開実行')
    try:
        row = parent.row(align=True)
        row.scale_y = 1.18
    except Exception:
        return False
    try:
        value = _icon_value('unwrap')
        if value:
            row.operator(_SUV_UNWRAP_EXECUTE_OPERATOR, text=label, icon_value=value)
        else:
            row.operator(_SUV_UNWRAP_EXECUTE_OPERATOR, text=label, icon=_standard_icon('unwrap'))
        _help_scope_register_operator(_SUV_UNWRAP_EXECUTE_OPERATOR, 'Run Unwrap', '展開実行', {})
        return True
    except Exception:
        pass
    try:
        row.enabled = False
        row.label(text=label, icon=_standard_icon('unwrap'))
    except Exception:
        pass
    return False


def _draw_public_unwrap_section(body, context) -> None:
    ws = _ws(context)
    guide = _curated_group(body, context, 'Smart Unwrap', 'スマートUV展開', 'unwrap', 'unwrap_auto')
    try:
        if ws is not None and hasattr(ws, 'auto_unwrap_mode'):
            method = guide.row(align=True)
            _prop(method, ws, 'auto_unwrap_mode', text=_tr(context, 'Method', '方式'))
            _prop(method, ws, 'smart_unwrap_realtime_preview', text=_tr(context, 'Live Unwrap', 'ライブ展開'))
    except Exception:
        pass
    _draw_unwrap_execute_row(guide, context)

    try:
        current_method = str(getattr(ws, 'auto_unwrap_mode', 'BLENDER_ANGLE_BASED') or 'BLENDER_ANGLE_BASED') if ws is not None else 'BLENDER_ANGLE_BASED'
    except Exception:
        current_method = 'BLENDER_ANGLE_BASED'
    if current_method == 'SMART' and ws is not None:
        _draw_smart_standard_core_unwrap_settings(guide, context, ws, 'smart_standard_core_unwrap_settings')
    if ws is not None:
        _draw_blender_native_operator_settings(guide, context, ws, current_method, 'blender_native_unwrap_settings')
        if current_method != 'SMART':
            _draw_global_baseline_straightening_settings(guide, context, ws, 'global_baseline_unwrap_settings')

    if current_method in {'SMART_SQUARE', 'SMART_CIRCLE'} and ws is not None:
        shape_group = _curated_foldout_group(guide, context, 'smart_shape_method_settings', 'Shape Method Settings', '形状方式設定', 'smart', 'unwrap_auto', default=True)
        if shape_group is not None:
            strength_prop = 'smart_unwrap_spring_strength' if current_method == 'SMART_SQUARE' else 'smart_unwrap_pull_distance'
            _curated_props_grid(shape_group, ws, (
                (strength_prop, 'Strength', '強度'),
                ('smart_unwrap_orientation_angle', 'Orientation', '向き'),
            ), columns=1)
    if current_method == 'FLAT_MAPPING' and ws is not None:
        flat = _curated_foldout_group(guide, context, 'flat_mapping_settings', 'Flat Mapping Settings', 'フラット専用設定', 'unwrap_flatten', 'unwrap_auto', default=True)
        if flat is not None:
            _curated_props_grid(flat, ws, (
                ('flat_mapping_angle_threshold', 'Flat Angle', 'フラット角度'),
                ('flat_mapping_spacing', 'Spacing', '余白'),
                ('flat_mapping_area_weight', 'Area Weight', '面積ウェイト'),
                ('flat_mapping_pack_after', 'Pack', 'パック'),
            ), columns=2)
    if current_method in {'QUICK_PLANAR', 'VIEW_PROJECT'} and ws is not None:
        gizmo = _curated_foldout_group(guide, context, 'projection_gizmo_settings', 'Projection Gizmo', '投影ギズモ', 'ORIENTATION_GIMBAL', 'unwrap_auto', default=True)
        if gizmo is not None:
            _curated_props_grid(gizmo, ws, (
                ('projection_gizmo_use', 'Use Gizmo', 'ギズモ使用'),
                ('projection_gizmo_object_name', 'Object', 'オブジェクト'),
                ('projection_gizmo_normalize', 'Normalize', '正規化'),
                ('projection_gizmo_tile_scale', 'Tile Scale', 'タイル倍率'),
                ('projection_gizmo_cylinder_offset', 'Seam Offset', 'シーム角度'),
            ), columns=1)
            row = gizmo.row(align=True)
            _curated_button(row, context, 'smart_uv_suite.projection_gizmo_action', 'Create', '作成', 'EMPTY_AXIS', props={'action': 'CREATE'}, scale_y=1.0)
            _curated_button(row, context, 'smart_uv_suite.projection_gizmo_action', 'Reset', '選択に合わせる', 'FILE_REFRESH', props={'action': 'RESET'}, scale_y=1.0)
            _curated_button(row, context, 'smart_uv_suite.projection_gizmo_action', 'Remove', '削除', 'TRASH', props={'action': 'REMOVE'}, scale_y=1.0)
    try:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass

    native_assist = _curated_group(body, context, 'Native Assist / Flatten', '標準補助 / 平面化', 'unwrap', 'unwrap_native_assist')
    _curated_row(native_assist, context, (
        {'id': 'smart_uv_suite.consolidated_builtin_uv_action', 'en': 'Pack Native', 'ja': '標準パック', 'icon': 'pack', 'props': {'action': 'PACK'}},
        {'id': 'smart_uv_suite.consolidated_builtin_uv_action', 'en': 'Average Scale', 'ja': '平均スケール', 'icon': 'density', 'props': {'action': 'AVERAGE_SCALE'}},
        {'id': 'smart_uv_suite.unwrap_auto_action', 'en': 'Min Stretch', 'ja': '最小ストレッチで展開', 'icon': 'relax', 'props': {'mode': 'BLENDER_MIN_STRETCH'}},
    ))
    _curated_row(native_assist, context, (
        {'id': 'smart_uv_suite.unwrap_auto_action', 'en': 'Follow Quads', 'ja': 'アクティブ四角形面に追従', 'icon': 'follow_quads', 'props': {'mode': 'BLENDER_FOLLOW_ACTIVE_QUADS'}},
        {'id': 'smart_uv_suite.consolidated_flatten_to_uv_shape_key', 'en': 'UV Shape Key', 'ja': 'UVシェイプキー', 'icon': 'unwrap_flatten'},
    ))

    seam = _curated_group(body, context, 'Seam / Pin', 'シーム/ピン', 'seam', 'seam_settings')
    if ws is not None:
        seam_core = _curated_foldout_group(seam, context, 'seam_pin_core_settings', 'Seam Compliance / Storage', 'シーム準拠/保存', 'seam', 'seam_settings', default=True)
        if seam_core is not None:
            _curated_props_grid(seam_core, ws, (
                ('suv_seam_mark_compliance', 'Use Mark Seam Before Unwrap', '展開前シーム準拠'),
                ('seam_snapshot_name', 'Scene Save Name', 'シーン内保存名'),
                ('seam_snapshot_filepath', 'External JSON', '外部JSON'),
            ), columns=1)
            _curated_row(seam_core, context, (
                {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Save Scene', 'ja': 'シーン保存', 'icon': 'FILE_TICK', 'props': {'action': 'SAVE_SCENE'}},
                {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Load Scene', 'ja': 'シーン読込', 'icon': 'FILE_REFRESH', 'props': {'action': 'LOAD_SCENE'}},
            ))
            _curated_row(seam_core, context, (
                {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Save JSON', 'ja': '外部保存', 'icon': 'EXPORT', 'props': {'action': 'SAVE_FILE'}},
                {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Load JSON', 'ja': '外部読込', 'icon': 'IMPORT', 'props': {'action': 'LOAD_FILE'}},
            ))
    _curated_row(seam, context, (
        {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Mark Seam', 'ja': 'シームをマーク', 'icon': 'seam', 'props': {'action': 'MARK_SELECTED'}, 'scale_y': 1.25},
        {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Clear Seam', 'ja': 'シームをクリア', 'icon': 'cleanup', 'props': {'action': 'CLEAR_SELECTED'}, 'scale_y': 1.25},
    ), scale_y=1.15)
    crease_seam = _curated_foldout_group(seam, context, 'crease_value_seam_settings', 'Crease Value Seam', 'クリース値シーム', 'MOD_EDGESPLIT', 'crease_value_seam_settings', default=True)
    if crease_seam is not None and ws is not None:
        _curated_props_grid(crease_seam, ws, (
            ('suv_crease_seam_value', 'Crease Value', 'クリース値'),
            ('suv_crease_seam_tolerance', 'Tolerance', '許容差'),
            ('suv_crease_seam_apply_mode', 'Apply Mode', '適用方式'),
        ), columns=1)
        _curated_row(crease_seam, context, (
            {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Mark Crease Value', 'ja': 'クリース値でシーム化', 'icon': 'seam', 'props': {'action': 'CREASE_VALUE'}, 'scale_y': 1.15},
        ), scale_y=1.1)
    _curated_row(seam, context, (
        {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Pin', 'ja': 'ピン', 'icon': 'pin', 'props': {'action': 'PIN'}},
        {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Unpin', 'ja': 'ピン解除', 'icon': 'unpin', 'props': {'action': 'CLEAR_PINS'}},
        {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Invert Pins', 'ja': 'ピン反転', 'icon': 'ARROW_LEFTRIGHT', 'props': {'action': 'INVERT_PINS'}},
    ))
    auto_seam = _curated_foldout_group(seam, context, 'auto_seam_advanced_settings', 'Auto Seam Advanced', '自動シーム詳細', 'seam', 'seam_settings', default=True)
    if auto_seam is not None and ws is not None:
        _curated_props_grid(auto_seam, ws, (
            ('suv_auto_seam_profile', 'Auto Seam Preset', '自動シーム設定'),
            ('suv_auto_seam_min_score', 'Min Score', '採用スコア'),
            ('suv_auto_seam_angle_threshold', 'Angle Limit', '角度しきい値'),
            ('suv_auto_seam_angle_weight', 'Angle', '辺角度'),
            ('suv_auto_seam_stretch_weight', 'Stretch', '引張予測'),
            ('suv_auto_seam_loop_weight', 'Loop', 'ループ維持'),
            ('suv_auto_seam_tube_weight', 'Tube Loop', '筒状ループ'),
            ('suv_auto_seam_tube_angle_window', 'Tube Width', '筒状角度幅'),
            ('suv_auto_seam_tube_axis', 'Tube Axis', '筒状軸'),
            ('suv_auto_seam_tube_cut_count', 'Tube Cuts', '筒状カット本数'),
            ('suv_auto_seam_boundary_weight', 'Boundary', '境界'),
            ('suv_auto_seam_material_weight', 'Material', 'マテリアル'),
            ('suv_auto_seam_sharp_weight', 'Sharp', 'シャープ'),
            ('suv_auto_seam_clear_existing', 'Clear First', '先にクリア'),
            ('suv_auto_seam_mark_boundaries', 'Open Borders', '開口境界'),
        ), columns=2)
        _curated_row(auto_seam, context, (
            {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Auto Seam', 'ja': '自動シーム', 'icon': 'seam', 'props': {'action': 'AUTO'}, 'scale_y': 1.25},
            {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Smart Seam', 'ja': 'スマートシーム', 'icon': 'candidate', 'props': {'action': 'SMART'}},
            {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Angle Seam', 'ja': '角度シーム', 'icon': 'seam', 'props': {'action': 'ANGLE'}},
            {'id': 'smart_uv_suite.seam_settings_action', 'en': 'Boundary Seam', 'ja': '境界シーム', 'icon': 'select_bounds', 'props': {'action': 'BOUNDARY'}},
        ))
    _curated_row(seam, context, (
        {'id': 'smart_uv_suite.unwrap_constraint', 'en': 'Constraint Unwrap', 'ja': '制約展開', 'icon': 'unwrap'},
    ))
    native_extra = _curated_foldout_group(
        seam,
        context,
        'seam_native_unique_actions',
        'Native Seam Extras',
        '標準シーム補助',
        'MOD_EDGESPLIT',
        'seam_settings',
        default=False,
    )
    if native_extra is not None:
        _native_row(native_extra, context, 'smart_uv_suite.native_seam_action', (
            {'en': 'From Islands', 'ja': '島からシーム', 'icon': 'MOD_EDGESPLIT', 'action': 'SEAMS_FROM_ISLANDS'},
            {'en': 'From Sharp', 'ja': 'シャープからシーム', 'icon': 'SHARPCURVE', 'action': 'SHARP_FROM_UV'},
            {'en': 'Material', 'ja': '材質境界シーム', 'icon': 'MATERIAL', 'action': 'SEAM_MATERIAL'},
        ))



def _draw_align_section(body, context) -> None:
    ws = _ws(context)
    select = _curated_group(body, context, 'Selection', '選択', 'select', 'align_selection')
    basic = _curated_foldout_group(select, context, 'align_select_basic_ops', 'Basic Selection', '基本選択', 'select', 'align_selection', default=True)
    if basic is not None:
        _curated_row(basic, context, (
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Grow', 'ja': 'グロー選択', 'icon': 'grow', 'props': {'action': 'GROW'}, 'scale_y': 1.15},
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Shrink', 'ja': 'シュリンク選択', 'icon': 'remove', 'props': {'action': 'SHRINK'}, 'scale_y': 1.15},
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Loop', 'ja': 'ループ選択', 'icon': 'loop_select', 'props': {'action': 'LOOP'}, 'scale_y': 1.15},
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Ring', 'ja': 'リング選択', 'icon': 'select_bounds', 'props': {'action': 'RING'}, 'scale_y': 1.15},
        ), scale_y=1.1)
        _curated_row(basic, context, (
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Linked', 'ja': '連結選択', 'icon': 'linked', 'props': {'action': 'LINKED'}},
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Border', 'ja': '境界選択', 'icon': 'select_bounds', 'props': {'action': 'BORDER'}},
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'All', 'ja': '全選択', 'icon': 'select', 'props': {'action': 'ALL'}},
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Clear', 'ja': '選択解除', 'icon': 'remove', 'props': {'action': 'NONE'}},
        ))
        _curated_row(basic, context, (
            {'id': 'smart_uv_suite.uv_element_select_action', 'en': 'Invert', 'ja': '反転選択', 'icon': 'flip', 'props': {'action': 'INVERT'}},
            {'id': 'smart_uv_suite.select_pick', 'en': 'Pick', 'ja': 'ピック選択', 'icon': 'cursor'},
            {'id': 'smart_uv_suite.select_mode', 'en': 'Selection Mode', 'ja': '選択モード', 'icon': 'select'},
        ))
    island = _curated_foldout_group(select, context, 'align_select_island_similarity', 'Island / Similarity Selection', '島/類似選択', 'linked', 'align_selection', default=True)
    if island is not None:
        _curated_row(island, context, (
            {'id': 'smart_uv_suite.select_island_active', 'en': 'Active Island', 'ja': 'アクティブ島', 'icon': 'linked'},
            {'id': 'smart_uv_suite.select_stacked', 'en': 'Stacked', 'ja': 'スタック', 'icon': 'stack'},
            {'id': 'smart_uv_suite.select_square_island', 'en': 'Square Island', 'ja': '矩形アイランド', 'icon': 'square'},
        ))
        _curated_row(island, context, (
            {'id': 'smart_uv_suite.select_similar_islands', 'en': 'Similar Islands', 'ja': '類似アイランド', 'icon': 'select_similar'},
            {'id': 'smart_uv_suite.select_identical_islands', 'en': 'Identical Islands', 'ja': '同一アイランド', 'icon': 'select_identical'},
        ))
    filters = _curated_foldout_group(select, context, 'align_select_filters_issues', 'Filters / Issue Selection', '条件/問題選択', 'inspect', 'align_selection', default=True)
    if filters is not None:
        _curated_row(filters, context, (
            {'id': 'smart_uv_suite.select_by_area', 'en': 'Select by Area', 'ja': '面積で選択', 'icon': 'area'},
            {'id': 'smart_uv_suite.select_texel_density', 'en': 'Texel Density', 'ja': '密度で選択', 'icon': 'density'},
            {'id': 'smart_uv_suite.select_by_cursor', 'en': 'By Cursor', 'ja': 'カーソルで選択', 'icon': 'cursor'},
            {'id': 'smart_uv_suite.select_mirror3d', 'en': 'Mirrored 3D', 'ja': '3Dミラー選択', 'icon': 'symmetry'},
        ))
        _curated_row(filters, context, (
            {'id': 'smart_uv_suite.select_uv_select_overlapped', 'en': 'Overlap', 'ja': '重なり', 'icon': 'select_overlap'},
            {'id': 'smart_uv_suite.select_uv_select_flipped', 'en': 'Flipped', 'ja': '反転UV', 'icon': 'select_flipped'},
            {'id': 'smart_uv_suite.select_zero_islands', 'en': 'Zero Area', 'ja': 'ゼロ面積', 'icon': 'select_zero'},
            {'id': 'smart_uv_suite.select_uv_boundary', 'en': 'UV Boundary', 'ja': 'UV境界', 'icon': 'select_bounds'},
        ))
        _curated_row(filters, context, (
            {'id': 'smart_uv_suite.select_edge', 'en': 'Directional Edges', 'ja': '方向エッジ', 'icon': 'edge_grow'},
            {'id': 'smart_uv_suite.select_half', 'en': 'Half', 'ja': '半分選択', 'icon': 'select'},
            {'id': 'smart_uv_suite.select_flipped_faces', 'en': 'Flipped Faces', 'ja': '反転面', 'icon': 'select_flipped'},
        ))
        _curated_row(filters, context, (
            {'id': 'smart_uv_suite.select_fragmented_islands', 'en': 'Fragmented Islands', 'ja': '分断アイランド', 'icon': 'select_bounds'},
            {'id': 'smart_uv_suite.select_zero', 'en': 'Zero Region', 'ja': 'ゼロ領域', 'icon': 'select_zero'},
            {'id': 'smart_uv_suite.select_udim_crossing', 'en': 'UDIM Crossing', 'ja': 'UDIM跨ぎ', 'icon': 'udim'},
        ))
        _curated_row(filters, context, (
            {'id': 'smart_uv_suite.inspect_inspector_select_all', 'en': 'All Issues', 'ja': '全問題選択', 'icon': 'quality'},
        ))

    _draw_curated_align_pad(body, context, op_id='smart_uv_suite.direction_align_action')
    _draw_curated_vertex_align_sibling_sections(body, context)
    stitch = _curated_group(body, context, 'Stitch', 'スティッチ', 'stitch', 'align_stitch_suite')
    island_stitch = _curated_foldout_group(stitch, context, 'align_stitch_island_ops', 'Island Stitch', 'アイランドスティッチ', 'stitch', 'align_stitch_suite', default=True)
    if island_stitch is not None:
        _curated_row(island_stitch, context, (
            {'id': 'smart_uv_suite.stitch_action', 'en': 'Connected Island → Selected', 'ja': '島→選', 'icon': 'stitch', 'props': {'mode': 'ISLAND_CONNECTED_TO_SELECTED'}, 'scale_y': 1.18},
            {'id': 'smart_uv_suite.stitch_action', 'en': 'Selected Island → Connected', 'ja': '選→島', 'icon': 'stitch', 'props': {'mode': 'ISLAND_SELECTED_TO_CONNECTED'}, 'scale_y': 1.18},
            {'id': 'smart_uv_suite.stitch_action', 'en': 'Both Islands → Middle', 'ja': '島中間', 'icon': 'merge', 'props': {'mode': 'ISLAND_AVERAGE'}, 'scale_y': 1.18},
        ), scale_y=1.12)
    edge_stitch = _curated_foldout_group(stitch, context, 'align_stitch_edge_ops', 'Edge Stitch', '辺スティッチ', 'stitch', 'align_stitch_suite', default=True)
    if edge_stitch is not None:
        _curated_row(edge_stitch, context, (
            {'id': 'smart_uv_suite.stitch_action', 'en': 'Connected Edge → Selected', 'ja': '辺→選', 'icon': 'stitch', 'props': {'mode': 'EDGE_CONNECTED_TO_SELECTED'}},
            {'id': 'smart_uv_suite.stitch_action', 'en': 'Selected Edge → Connected', 'ja': '選→辺', 'icon': 'stitch', 'props': {'mode': 'EDGE_SELECTED_TO_CONNECTED'}},
            {'id': 'smart_uv_suite.stitch_action', 'en': 'Both Edges → Middle', 'ja': '辺中間', 'icon': 'merge', 'props': {'mode': 'EDGE_AVERAGE'}},
        ))


def _draw_auto_pack_run_button_suv43(layout, context) -> None:
    if _curated_row(layout, context, (
        {'id': 'smart_uv_suite.unified_auto_pack', 'en': 'Run Auto Pack', 'ja': '自動パック実行', 'icon': 'pack', 'scale_y': 1.45},
    ), scale_y=1.35):
        return
    try:
        row = layout.row(align=True)
        row.scale_y = 1.35
        row.operator('smart_uv_suite.unified_auto_pack', text=_tr(context, 'Run Auto Pack', '自動パック実行'), icon='UV_ISLANDSEL')
        _help_scope_register_operator('smart_uv_suite.unified_auto_pack', 'Run Auto Pack', '自動パック実行', {})
    except Exception:
        pass


def _draw_auto_pack_settings_suv43(auto, context, ws, key_prefix: str) -> None:
    """Draw Auto Packing as preset + all editable settings in simple groups."""
    if auto is None or ws is None:
        return
    preset = _curated_foldout_group(auto, context, key_prefix + '_preset', 'Preset / Run', 'プリセット / 実行', 'pack', 'pack_auto_preset', default=True)
    if preset is not None:
        _curated_props_grid(preset, ws, (
            ('unified_auto_pack_mode', 'Preset', 'プリセット'),
        ), columns=1)
        _draw_auto_pack_run_button_suv43(preset, context)

    basic = _curated_foldout_group(auto, context, key_prefix + '_basic', 'Basic Packing', '基本パック設定', 'settings', 'pack_auto_basic', default=True)
    if basic is not None:
        _curated_props_grid(basic, ws, (
            ('unified_pack_merge_overlap', 'Treat Overlaps as One Island', '重なり島を複合島にする'),
            ('unified_pack_lock_pinned', 'Lock Pinned', 'ピン固定'),
            ('unified_pack_rotate', 'Allow Rotation', '回転を許可'),
            ('unified_pack_rotation_step', 'Rotation Step', '回転刻み'),
            ('unified_pack_scale', 'Allow Scale', 'スケールを許可'),
            ('unified_pack_shape_method', 'Shape Method', '形状方式'),
        ), columns=2)

    margin = _curated_foldout_group(auto, context, key_prefix + '_margin', 'Margin / Search', '余白 / 探索', 'uv_margin', 'pack_auto_margin', default=True)
    if margin is not None:
        _curated_props_grid(margin, ws, (
            ('unified_pack_margin_px', 'Margin px', '余白px'),
            ('unified_pack_margin', 'Native Margin', '標準余白'),
            ('unified_pack_margin_method', 'Margin Method', '余白方式'),
            ('unified_pack_use_seed', 'Seed Search', 'Seed探索'),
            ('unified_pack_seed', 'Seed', 'Seed'),
        ), columns=2)

    tile = _curated_foldout_group(auto, context, key_prefix + '_tile', 'Tile / UDIM / Size', 'タイル・UDIM・サイズ', 'udim', 'pack_auto_tile', default=False)
    if tile is not None:
        _curated_props_grid(tile, ws, (
            ('unified_pack_target_tile', 'Target Tile', '配置タイル'),
            ('unified_pack_tile_u', 'Tile U', 'タイルU'),
            ('unified_pack_tile_v', 'Tile V', 'タイルV'),
            ('unified_pack_tile_columns', 'UDIM Columns', 'UDIM列数'),
            ('unified_pack_tile_fill', 'UDIM Fill', 'UDIM埋め順'),
            ('unified_pack_target_width', 'Pack Width', 'パック幅'),
            ('unified_pack_target_height', 'Pack Height', 'パック高さ'),
        ), columns=2)

    group = _curated_foldout_group(auto, context, key_prefix + '_group', 'Groups / Density', 'グループ / 密度', 'stack', 'pack_auto_group', default=False)
    if group is not None:
        _curated_props_grid(group, ws, (
            ('pack_group_mode', 'Group Mode', 'グループ方式'),
            ('pack_group_layout', 'Group Layout', 'グループ配置'),
            ('similarity_area_tol', 'Area Tolerance', '面積許容差'),
            ('similarity_aspect_tol', 'Aspect Tolerance', '比率許容差'),
            ('unified_pack_stack_identical', 'Stack Identical', '同一島を重ねる'),
            ('unified_pack_chart_rescale', 'Chart Rescale', 'チャート密度再正規化'),
        ), columns=2)

    hotspot = _curated_foldout_group(auto, context, key_prefix + '_hotspot', 'Bake / Hotspot', 'ベイク / ホットスポット', 'grid', 'pack_auto_hotspot', default=False)
    if hotspot is not None:
        _curated_props_grid(hotspot, ws, (
            ('unified_pack_bake_padding_px', 'Bake Padding', 'ベイク安全余白'),
            ('hotspot_cols', 'Columns', '列数'),
            ('hotspot_rows', 'Rows', '行数'),
            ('hotspot_keep_aspect', 'Keep Aspect', '縦横比を保持'),
            ('hotspot_sort', 'Sort Rule', 'ソート規則'),
            ('hotspot_fill_order', 'Fill Order', '埋め順'),
        ), columns=2)


def _draw_packing_section(body, context) -> None:
    ws = _ws(context)
    auto = _curated_group(body, context, 'Auto Packing', '自動パッキング', 'pack', 'pack_auto_packing')
    if auto is None:
        return

    preset = _curated_foldout_group(auto, context, 'pack_auto_preset_execute', 'Preset / Execute', 'プリセット / 実行', 'pack', 'pack_auto_packing', default=True)
    if preset is not None:
        _curated_props_grid(preset, ws, (
            ('unified_auto_pack_mode', 'Packing Preset', 'パッキングプリセット'),
        ), columns=1)
        if not _curated_row(preset, context, (
            {'id': 'smart_uv_suite.unified_auto_pack', 'en': 'Run Auto Pack', 'ja': '自動パック実行', 'icon': 'pack', 'scale_y': 1.45},
        ), scale_y=1.35):
            try:
                row = preset.row(align=True)
                row.scale_y = 1.35
                row.operator('smart_uv_suite.unified_auto_pack', text=_tr(context, 'Run Auto Pack', '自動パック実行'), icon='UV_ISLANDSEL')
                _help_scope_register_operator('smart_uv_suite.unified_auto_pack', 'Run Auto Pack', '自動パック実行', {})
            except Exception:
                pass

    basic = _curated_foldout_group(auto, context, 'pack_auto_basic_settings', 'Basic Packing', '基本設定', 'pack', 'pack_auto_packing', default=True)
    if basic is not None:
        _curated_props_grid(basic, ws, (
            ('unified_pack_merge_overlap', 'Treat Overlaps as One Island', '重なり島を複合島にする'),
            ('unified_pack_margin_px', 'Margin px', '余白px'),
            ('unified_pack_margin', 'Native Margin', '標準余白'),
            ('unified_pack_margin_method', 'Margin Method', '余白方式'),
            ('unified_pack_shape_method', 'Shape Method', '形状方式'),
        ), columns=2)

    transform = _curated_foldout_group(auto, context, 'pack_auto_transform_settings', 'Transform', '変形設定', 'transform', 'pack_auto_packing', default=True)
    if transform is not None:
        _curated_props_grid(transform, ws, (
            ('unified_pack_rotate', 'Allow Rotation', '回転を許可'),
            ('unified_pack_rotation_step', 'Rotation Step', '回転刻み'),
            ('unified_pack_scale', 'Allow Scale', 'スケールを許可'),
            ('unified_pack_lock_pinned', 'Lock Pinned', 'ピン固定'),
            ('unified_pack_use_seed', 'Seed Search', 'Seed探索'),
            ('unified_pack_seed', 'Seed', 'Seed'),
        ), columns=2)

    grouping = _curated_foldout_group(auto, context, 'pack_auto_group_settings', 'Grouping / Similarity', 'グループ / 類似判定', 'group', 'pack_auto_packing', default=True)
    if grouping is not None:
        _curated_props_grid(grouping, ws, (
            ('pack_group_mode', 'Group Mode', 'グループ方式'),
            ('pack_group_layout', 'Group Layout', 'グループ配置'),
            ('unified_pack_stack_identical', 'Stack Identical', '同一島を重ねる'),
            ('unified_pack_chart_rescale', 'Chart Rescale', 'チャート密度再正規化'),
            ('similarity_area_tol', 'Area Tolerance', '面積許容差'),
            ('similarity_aspect_tol', 'Aspect Tolerance', '比率許容差'),
        ), columns=2)

    tile = _curated_foldout_group(auto, context, 'pack_auto_tile_settings', 'Tile / UDIM', 'タイル / UDIM', 'udim', 'pack_auto_packing', default=True)
    if tile is not None:
        _curated_props_grid(tile, ws, (
            ('unified_pack_target_tile', 'Target Tile', '配置タイル'),
            ('unified_pack_tile_u', 'Tile U', 'タイルU'),
            ('unified_pack_tile_v', 'Tile V', 'タイルV'),
            ('unified_pack_tile_columns', 'UDIM Columns', 'UDIM列数'),
            ('unified_pack_tile_fill', 'UDIM Fill', 'UDIM埋め順'),
        ), columns=2)

    output = _curated_foldout_group(auto, context, 'pack_auto_output_settings', 'Size / Hotspot', 'サイズ / ホットスポット', 'layout', 'pack_auto_packing', default=False)
    if output is not None:
        _curated_props_grid(output, ws, (
            ('unified_pack_target_width', 'Pack Width', 'パック幅'),
            ('unified_pack_target_height', 'Pack Height', 'パック高さ'),
            ('unified_pack_bake_padding_px', 'Bake Padding', 'ベイク安全余白'),
            ('hotspot_cols', 'Columns', '列数'),
            ('hotspot_rows', 'Rows', '行数'),
            ('hotspot_keep_aspect', 'Keep Aspect', '縦横比を保持'),
            ('hotspot_sort', 'Sort Rule', 'ソート規則'),
            ('hotspot_fill_order', 'Fill Order', '埋め順'),
        ), columns=2)

    # Island direction alignment is now unified under UV Align > Direction Align.

def _draw_bake_section(body, context) -> None:
    ws = _ws(context)
    prep = _curated_group(body, context, 'Bake Preparation', 'ベイク準備', 'bake', 'bake_prepare')
    _curated_props_grid(prep, ws, (
        ('canvas_size', 'Texture Size', 'テクスチャサイズ'),
        ('fit_padding_px', 'Bake Padding', 'ベイク余白'),
        ('workflow_density', 'Target Density', '目標密度'),
        ('smart_margin_strategy', 'Margin Strategy', '余白方針'),
    ), columns=2)
    _curated_row(prep, context, (
        {'id': 'smart_uv_suite.texel_bake_uv_prep', 'en': 'Prepare Bake UV', 'ja': 'ベイクUV準備', 'icon': 'bake', 'scale_y': 1.25},
        {'id': 'smart_uv_suite.texel_stage_bake', 'en': 'Create Bake Image', 'ja': 'ベイク画像作成', 'icon': 'bake', 'scale_y': 1.25},
    ), scale_y=1.15)
    _curated_row(prep, context, (
        {'id': 'smart_uv_suite.atlas_bake_multi', 'en': 'Bake Atlas', 'ja': 'アトラスベイク', 'icon': 'atlas', 'scale_y': 1.25},
        {'id': 'smart_uv_suite.atlas_build_mat_apply_multi', 'en': 'Build Material', 'ja': 'マテリアル作成', 'icon': 'MATERIAL', 'scale_y': 1.25},
    ), scale_y=1.15)
    texel = _curated_group(body, context, 'Texel / Map Generation', 'テクセル / マップ生成', 'density', 'bake_texel')
    _curated_row(texel, context, (
        {'id': 'smart_uv_suite.texel_get', 'en': 'Get Density', 'ja': '密度取得', 'icon': 'density_pick'},
        {'id': 'smart_uv_suite.texel_set', 'en': 'Set Density', 'ja': '密度設定', 'icon': 'density_apply'},
        {'id': 'smart_uv_suite.texel_normalize', 'en': 'Normalize Density', 'ja': '密度正規化', 'icon': 'density_normalize'},
    ))
    _curated_row(texel, context, (
        {'id': 'smart_uv_suite.texel_density_coverage', 'en': 'Coverage', 'ja': 'カバー率', 'icon': 'area'},
        {'id': 'smart_uv_suite.texel_calc_uv_area', 'en': 'UV Area', 'ja': 'UV面積', 'icon': 'area'},
        {'id': 'smart_uv_suite.texel_density_from_texture', 'en': 'Density from Texture', 'ja': 'テクスチャから密度', 'icon': 'TEXTURE'},
    ))
    _curated_row(texel, context, (
        {'id': 'smart_uv_suite.consolidated_texel_density_report', 'en': 'Density Report', 'ja': '密度レポート', 'icon': 'density'},
    ))
    maps = _curated_group(body, context, 'Texture / ID Maps', 'テクスチャ / IDマップ', 'color_grid', 'bake_maps')
    _curated_row(maps, context, (
        {'id': 'smart_uv_suite.texel_bake_trim_id_map', 'en': 'Bake ID Map', 'ja': 'IDマップベイク', 'icon': 'color_grid'},
        {'id': 'smart_uv_suite.view_stage_preview', 'en': 'Preview Texture', 'ja': 'テクスチャ確認', 'icon': 'visual_reference'},
        {'id': 'smart_uv_suite.checker_map_cleanup', 'en': 'Clean Map Preview', 'ja': 'マップ表示整理', 'icon': 'cleanup'},
    ))
    _native_row(maps, context, 'smart_uv_suite.native_bake_action', (
        {'en': 'Create Checker', 'ja': 'チェッカー作成', 'icon': 'checker', 'action': 'CHECKER_CREATE'},
        {'en': 'Reload Textures', 'ja': 'テクスチャ再読込', 'icon': 'FILE_REFRESH', 'action': 'TEXTURE_RELOAD'},
        {'en': 'Save Textures', 'ja': 'テクスチャ保存', 'icon': 'FILE_TICK', 'action': 'TEXTURE_SAVE'},
    ))
    _native_row(maps, context, 'smart_uv_suite.native_bake_action', (
        {'en': 'Object IDs', 'ja': 'オブジェクトID', 'icon': 'color_grid', 'action': 'COLOR_ID_OBJECTS'},
        {'en': 'Face IDs', 'ja': '面ID', 'icon': 'color_grid', 'action': 'COLOR_ID_FACES'},
    ))


def _draw_id_section(body, context) -> None:
    ws = _ws(context)
    uvmap = _curated_group(body, context, 'UV Map Channels', 'UVマップチャンネル', 'uvmap', 'id_uvmaps')
    _curated_props_grid(uvmap, ws, (
        ('uv_new_name', 'New UV Name', '新規UV名'),
    ), columns=1)
    _curated_row(uvmap, context, (
        {'id': 'smart_uv_suite.texel_uvmap_add', 'en': 'Add UV', 'ja': 'UV追加', 'icon': 'uvmap'},
        {'id': 'smart_uv_suite.texel_uvmap_duplicate', 'en': 'Duplicate UV', 'ja': 'UV複製', 'icon': 'SEQ_STRIP_DUPLICATE'},
        {'id': 'smart_uv_suite.texel_uvmap_remove', 'en': 'Remove UV', 'ja': 'UV削除', 'icon': 'remove'},
    ), scale_y=1.1)
    _curated_row(uvmap, context, (
        {'id': 'smart_uv_suite.texel_uvmap_rename_active', 'en': 'Rename UV', 'ja': 'UV名変更', 'icon': 'settings'},
        {'id': 'smart_uv_suite.texel_uvmap_set_active', 'en': 'Set Work UV', 'ja': '作業UVに設定', 'icon': 'FILE_TICK'},
        {'id': 'smart_uv_suite.texel_uvmap_set_render', 'en': 'Set Render UV', 'ja': 'レンダーUVに設定', 'icon': 'RESTRICT_RENDER_OFF'},
    ))
    _curated_row(uvmap, context, (
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Add Managed', 'ja': '管理版追加', 'icon': 'uvmap', 'props': {'action': 'ADD'}},
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Duplicate Managed', 'ja': '管理版複製', 'icon': 'SEQ_STRIP_DUPLICATE', 'props': {'action': 'DUPLICATE'}},
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Remove Managed', 'ja': '管理版削除', 'icon': 'remove', 'props': {'action': 'REMOVE'}},
    ))
    _curated_row(uvmap, context, (
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Render UV', 'ja': 'レンダーUV', 'icon': 'RESTRICT_RENDER_OFF', 'props': {'action': 'SET_RENDER'}},
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Copy to Selected', 'ja': '選択へコピー', 'icon': 'transfer', 'props': {'action': 'COPY_TO_SELECTED'}},
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Move Up', 'ja': '上へ移動', 'icon': 'TRIA_UP', 'props': {'action': 'MOVE_UP'}},
        {'id': 'smart_uv_suite.consolidated_uv_map_action', 'en': 'Move Down', 'ja': '下へ移動', 'icon': 'TRIA_DOWN', 'props': {'action': 'MOVE_DOWN'}},
    ))
    _native_row(uvmap, context, 'smart_uv_suite.native_id_action', (
        {'en': 'Transfer', 'ja': '転送', 'icon': 'transfer', 'action': 'UVMAP_TRANSFER'},
        {'en': 'Copy UV', 'ja': 'UVコピー', 'icon': 'copy', 'action': 'UV_COPY'},
        {'en': 'Paste UV', 'ja': 'UV貼付', 'icon': 'paste', 'action': 'UV_PASTE'},
    ))
    ids = _curated_group(body, context, 'Material / Selection IDs', 'マテリアル / 選択ID', 'color_grid', 'id_materials')
    _curated_row(ids, context, (
        {'id': 'smart_uv_suite.inspect_set_save', 'en': 'Save Selection Set', 'ja': 'セット保存', 'icon': 'save'},
        {'id': 'smart_uv_suite.inspect_set_recall', 'en': 'Recall Selection Set', 'ja': 'セット読込', 'icon': 'preset'},
        {'id': 'smart_uv_suite.inspect_set_update', 'en': 'Update Selection Set', 'ja': 'セット更新', 'icon': 'FILE_REFRESH'},
    ))


def _draw_cleanup_section(body, context) -> None:
    ws = _ws(context)
    status = _curated_group(body, context, 'Status / Repair', '状況確認 / 修復', 'inspect', 'cleanup_status')
    _curated_props_grid(status, ws, (
        ('stretch_threshold', 'Stretch Limit', '歪み許容値'),
        ('scan_report_name', 'Report Name', 'レポート名'),
        ('smart_sliver_protection', 'Sliver Protection', '細片保護'),
        ('smart_lock_overlaps', 'Preserve Overlap', '重なり保持'),
    ), columns=2)
    _curated_row(status, context, (
        {'id': 'smart_uv_suite.inspect_workspace_validate', 'en': 'Validate', 'ja': '検証', 'icon': 'quality', 'scale_y': 1.25},
        {'id': 'smart_uv_suite.inspect_fix_all_issues', 'en': 'Fix Issues', 'ja': '問題修復', 'icon': 'repair', 'scale_y': 1.25},
        {'id': 'smart_uv_suite.inspect_inspector_select_all', 'en': 'Select Issues', 'ja': '問題を選択', 'icon': 'select', 'scale_y': 1.25},
    ), scale_y=1.15)
    select = _curated_group(body, context, 'Final Selection Checks', '仕上げ選択チェック', 'select', 'cleanup_select')
    _curated_row(select, context, (
        {'id': 'smart_uv_suite.select_uv_select_overlapped', 'en': 'Overlap', 'ja': '重なり', 'icon': 'select_overlap'},
        {'id': 'smart_uv_suite.select_uv_select_flipped', 'en': 'Flipped', 'ja': '反転', 'icon': 'select_flipped'},
        {'id': 'smart_uv_suite.select_zero_islands', 'en': 'Zero Area', 'ja': 'ゼロ面積', 'icon': 'select_zero'},
    ))
    _curated_row(select, context, (
        {'id': 'smart_uv_suite.consolidated_select_uv_issue', 'en': 'Zero Area Managed', 'ja': '管理版ゼロ', 'icon': 'select_zero', 'props': {'action': 'ZERO_AREA'}},
        {'id': 'smart_uv_suite.consolidated_select_uv_issue', 'en': 'Flipped Managed', 'ja': '管理版反転', 'icon': 'select_flipped', 'props': {'action': 'FLIPPED'}},
        {'id': 'smart_uv_suite.consolidated_select_uv_issue', 'en': 'UDIM Crossing', 'ja': 'UDIM跨ぎ', 'icon': 'udim', 'props': {'action': 'UDIM_CROSSING'}},
    ))
    _curated_row(select, context, (
        {'id': 'smart_uv_suite.consolidated_select_udim_islands', 'en': 'Active UDIM', 'ja': 'アクティブUDIM', 'icon': 'udim', 'props': {'mode': 'ACTIVE'}},
        {'id': 'smart_uv_suite.consolidated_select_udim_islands', 'en': 'Manual UDIM', 'ja': '手動UDIM', 'icon': 'udim', 'props': {'mode': 'MANUAL'}},
    ))
    _curated_row(select, context, (
        {'id': 'smart_uv_suite.select_fragmented_islands', 'en': 'Shattered', 'ja': '断片化', 'icon': 'select_bounds'},
        {'id': 'smart_uv_suite.select_identical_islands', 'en': 'Identical', 'ja': '同一形状', 'icon': 'select_identical'},
        {'id': 'smart_uv_suite.inspect_unstack_overlapped', 'en': 'Unstack Overlap', 'ja': '重なり分離', 'icon': 'stack'},
    ))
    _native_row(select, context, 'smart_uv_suite.native_cleanup_action', (
        {'en': 'Border', 'ja': '境界', 'icon': 'select_bounds', 'action': 'SELECT_BORDER'},
        {'en': 'Invert', 'ja': '反転選択', 'icon': 'select', 'action': 'SELECT_INVERT'},
    ))
    data = _curated_group(body, context, 'Data Cleanup', 'データ整理', 'cleanup', 'cleanup_data')
    _curated_row(data, context, (
        {'id': 'smart_uv_suite.inspect_quality_cleanup_generated_data', 'en': 'Clean Generated Data', 'ja': '生成データ整理', 'icon': 'cleanup'},
        {'id': 'smart_uv_suite.inspect_clear_all_reports', 'en': 'Clear Reports', 'ja': 'レポート削除', 'icon': 'TRASH'},
    ))


def _draw_io_section(body, context) -> None:
    settings = _curated_group(body, context, 'Settings', '設定', 'preset', 'io_settings')
    _curated_row(settings, context, (
        {'id': 'smart_uv_suite.settings_save', 'en': 'Save Settings', 'ja': '設定書き出し', 'icon': 'settings', 'scale_y': 1.2},
        {'id': 'smart_uv_suite.settings_load', 'en': 'Load Settings', 'ja': '設定読み込み', 'icon': 'import_settings', 'scale_y': 1.2},
        {'id': 'smart_uv_suite.workflow_workspace_reset', 'en': 'Reset Settings', 'ja': '設定リセット', 'icon': 'reset', 'scale_y': 1.2},
    ), scale_y=1.1)
    sets = _curated_group(body, context, 'Set Libraries', 'セットライブラリ', 'save', 'io_sets')
    _curated_row(sets, context, (
        {'id': 'smart_uv_suite.seams_save', 'en': 'Save Seams', 'ja': 'シーム書き出し', 'icon': 'seam'},
        {'id': 'smart_uv_suite.seams_load', 'en': 'Load Seams', 'ja': 'シーム読み込み', 'icon': 'seam'},
    ))
    _curated_row(sets, context, (
        {'id': 'smart_uv_suite.layout_save', 'en': 'Save Layout', 'ja': '配置書き出し', 'icon': 'layout'},
        {'id': 'smart_uv_suite.layout_load', 'en': 'Load Layout', 'ja': '配置読み込み', 'icon': 'layout'},
    ))
    _curated_row(sets, context, (
        {'id': 'smart_uv_suite.selection_save', 'en': 'Save Selection', 'ja': '選択書き出し', 'icon': 'select'},
        {'id': 'smart_uv_suite.selection_load', 'en': 'Load Selection', 'ja': '選択読み込み', 'icon': 'select'},
    ))
    support = _curated_group(body, context, 'Reports / Support', 'レポート / サポート', 'report', 'io_reports')
    _curated_row(support, context, (
        {'id': 'smart_uv_suite.workflow_open_diagnostics_text', 'en': 'Open Diagnostics', 'ja': '診断を開く', 'icon': 'TEXT'},
        {'id': 'smart_uv_suite.diagnostics_save', 'en': 'Save Diagnostics', 'ja': '診断を保存', 'icon': 'save'},
        {'id': 'smart_uv_suite.inspect_inspector_write_report', 'en': 'Write Inspection', 'ja': '検査レポート', 'icon': 'report'},
    ))
    native_output = _curated_foldout_group(
        support,
        context,
        'native_output_unique_actions',
        'Native Output Shortcuts',
        '標準出力ショートカット',
        'OUTPUT',
        'io_reports',
        default=False,
    )
    if native_output is not None:
        _native_row(native_output, context, 'smart_uv_suite.native_io_action', (
            {'en': 'Focus View', 'ja': '表示へフォーカス', 'icon': 'VIEWZOOM', 'action': 'FOCUS_VIEW'},
            {'en': 'Quick Report', 'ja': '簡易レポート', 'icon': 'report', 'action': 'WRITE_REPORT'},
            {'en': 'Export Settings', 'ja': '設定出力', 'icon': 'settings', 'action': 'EXPORT_SETTINGS'},
        ))




# --- JELararagi native compact hub UI START ---
def _native_menu(layout, context, op_id: str, label_en: str, label_ja: str, icon: str = 'tool') -> bool:
    op_id = str(op_id or '')
    if not _operator_exists(op_id) or not _operator_has_property(op_id, 'action'):
        return False
    try:
        row = layout.row(align=True)
        row.scale_y = 1.12
        row.operator_menu_enum(op_id, 'action', text=_tr(context, label_en, label_ja), icon=_standard_icon(icon))
        return True
    except Exception:
        return False


def _native_row(layout, context, op_id: str, specs: Sequence[dict], *, scale_y: float = 1.08) -> bool:
    normalized = []
    for spec in specs:
        if not isinstance(spec, dict):
            continue
        data = dict(spec)
        data.setdefault('id', op_id)
        if 'props' not in data and data.get('action'):
            data['props'] = {'action': str(data.get('action'))}
        normalized.append(data)
    return _curated_row(layout, context, tuple(normalized), scale_y=scale_y)


def _draw_native_compact_basic_section(body, context) -> None:
    ws = _ws(context)
    settings = _curated_group(body, context, 'Core Settings', '基本設定', 'settings', 'native_basic_settings')
    _draw_map_channel_settings(settings, context, ws, 'native_basic_map_channels')
    _curated_props_grid(settings, ws, (
        ('canvas_size', 'Texture Size', 'テクスチャサイズ'),
        ('fit_padding_px', 'Fit Padding', 'フィット余白'),
        ('checker_size_width', 'Checker Width', '画像解像度 横'),
        ('checker_size_height', 'Checker Height', '画像解像度 縦'),
        ('checker_tile_count_u', 'Checker Tiles U', 'チェックサイズ 横'),
        ('checker_tile_count_v', 'Checker Tiles V', 'チェックサイズ 縦'),
        ('suv_native_grid_divisions', 'Grid Divisions', 'グリッド分割'),
    ), columns=2)
    _native_menu(settings, context, 'smart_uv_suite.native_basic_action', 'Basic Action Menu', '基本アクションメニュー', 'tool')
    _native_row(settings, context, 'smart_uv_suite.native_basic_action', (
        {'en': 'Checker', 'ja': 'チェッカー', 'icon': 'checker', 'action': 'CHECKER_CREATE'},
        {'en': 'Focus', 'ja': '表示調整', 'icon': 'VIEWZOOM', 'action': 'FOCUS_VIEW'},
        {'en': 'Snap Grid', 'ja': 'グリッド吸着', 'icon': 'snap', 'action': 'SNAP_GRID'},
    ), scale_y=1.14)
    try:
        pass  # INFO-note moved to Help; no in-section info-icon explanation.
    except Exception:
        pass



def _draw_native_compact_unwrap_section(body, context) -> None:
    ws = _ws(context)
    guide = _curated_group(body, context, 'Smart Unwrap Hub', 'スマート展開ハブ', 'unwrap', 'native_unwrap_hub')

    method_box = _curated_foldout_group(guide, context, 'native_unwrap_method_execute', 'Method / Execute', '方式/実行', 'unwrap', 'native_unwrap_hub', default=True)
    if method_box is not None:
        try:
            method_row = method_box.row(align=True)
            _prop(method_row, ws, 'auto_unwrap_mode', text=_tr(context, 'Method', '方式'))
            _prop(method_row, ws, 'smart_unwrap_realtime_preview', text=_tr(context, 'Live Unwrap', 'ライブ展開'))
        except Exception:
            pass
        _draw_unwrap_execute_row(method_box, context)
    try:
        current_method = str(getattr(ws, 'auto_unwrap_mode', 'BLENDER_ANGLE_BASED') or 'BLENDER_ANGLE_BASED') if ws is not None else 'BLENDER_ANGLE_BASED'
    except Exception:
        current_method = 'BLENDER_ANGLE_BASED'

    if ws is not None:
        settings_box = _curated_foldout_group(guide, context, 'native_unwrap_method_settings', 'Method Settings', '方式別設定', 'settings', 'native_unwrap_hub', default=True)
        if settings_box is not None:
            # Keep every per-method control directly under this single Method Settings
            # section.  With many unwrap methods, nested child panels make the target
            # settings hard to find and were explicitly removed here.
            if current_method == 'SMART':
                _draw_smart_standard_core_unwrap_settings_direct(settings_box, context, ws)
            else:
                _draw_blender_native_operator_settings_direct(settings_box, context, ws, current_method)
                _draw_global_baseline_straightening_settings_direct(settings_box, context, ws)
                _draw_shape_projection_settings_direct(settings_box, context, ws, current_method)

    quick = _curated_group(body, context, 'Seam / Pin', 'シーム/ピン', 'seam', 'native_unwrap_quick')
    seam_ops = _curated_foldout_group(quick, context, 'native_seam_pin_ops', 'Seam Operations', 'シーム操作', 'seam', 'native_unwrap_quick', default=True)
    if seam_ops is not None:
        _native_row(seam_ops, context, 'smart_uv_suite.native_seam_action', (
            {'en': 'Mark Seam', 'ja': 'シームをマーク', 'icon': 'EDGESEL', 'action': 'MARK_SEAM'},
            {'en': 'Clear Seam', 'ja': 'シームをクリア', 'icon': 'X', 'action': 'CLEAR_SEAM'},
            {'en': 'Seams from Islands', 'ja': '島からシーム', 'icon': 'MOD_EDGESPLIT', 'action': 'SEAMS_FROM_ISLANDS'},
        ), scale_y=1.08)
        if ws is not None:
            _curated_props_grid(seam_ops, ws, (
                ('suv_crease_seam_value', 'Crease Value', 'クリース値'),
                ('suv_crease_seam_tolerance', 'Tolerance', '許容差'),
                ('suv_crease_seam_apply_mode', 'Apply Mode', '適用方式'),
            ), columns=1)
            _native_row(seam_ops, context, 'smart_uv_suite.native_seam_action', (
                {'en': 'Mark Crease Value', 'ja': 'クリース値でシーム化', 'icon': 'MOD_EDGESPLIT', 'action': 'CREASE_VALUE'},
            ), scale_y=1.08)
    pin_ops = _curated_foldout_group(quick, context, 'native_seam_pin_pin_ops', 'Pin Operations', 'ピン操作', 'pin', 'native_unwrap_quick', default=True)
    if pin_ops is not None:
        _native_row(pin_ops, context, 'smart_uv_suite.native_seam_action', (
            {'en': 'Pin', 'ja': 'ピン', 'icon': 'pin', 'action': 'PIN'},
            {'en': 'Unpin', 'ja': 'ピン解除', 'icon': 'UNPINNED', 'action': 'UNPIN'},
            {'en': 'Invert Pins', 'ja': 'ピン反転', 'icon': 'ARROW_LEFTRIGHT', 'action': 'PIN_INVERT'},
        ), scale_y=1.08)
    storage = _curated_foldout_group(quick, context, 'native_seam_pin_storage', 'Seam Storage', 'シーム保存/読込', 'save', 'native_unwrap_quick', default=True)
    if storage is not None:
        if ws is not None:
            _curated_props_grid(storage, ws, (
                ('suv_seam_mark_compliance', 'Use Mark Seam Before Unwrap', '展開前シーム準拠'),
                ('seam_snapshot_name', 'Scene Save Name', 'シーン内保存名'),
                ('seam_snapshot_filepath', 'External JSON', '外部JSON'),
            ), columns=1)
        _curated_row(storage, context, (
            {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Save Scene', 'ja': 'シーン保存', 'icon': 'FILE_TICK', 'props': {'action': 'SAVE_SCENE'}},
            {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Load Scene', 'ja': 'シーン読込', 'icon': 'FILE_REFRESH', 'props': {'action': 'LOAD_SCENE'}},
        ))
        _curated_row(storage, context, (
            {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Save JSON', 'ja': '外部保存', 'icon': 'EXPORT', 'props': {'action': 'SAVE_FILE'}},
            {'id': 'smart_uv_suite.seam_snapshot_action', 'en': 'Load JSON', 'ja': '外部読込', 'icon': 'IMPORT', 'props': {'action': 'LOAD_FILE'}},
        ))
    seam_cfg = _curated_foldout_group(quick, context, 'native_seam_pin_advanced_settings', 'Auto Seam Advanced', '自動シーム詳細', 'seam', 'native_unwrap_quick', default=False)
    if seam_cfg is not None and ws is not None:
        _curated_props_grid(seam_cfg, ws, (
            ('suv_auto_seam_profile', 'Preset', 'プリセット'),
            ('suv_auto_seam_angle_threshold', 'Angle Limit', '角度しきい値'),
            ('suv_auto_seam_min_score', 'Score Threshold', '採用スコア'),
            ('suv_auto_seam_angle_weight', 'Edge Angle', '辺角度'),
            ('suv_auto_seam_stretch_weight', 'Stretch', '引張予測'),
            ('suv_auto_seam_loop_weight', 'Loop', 'ループ維持'),
            ('suv_auto_seam_tube_weight', 'Tube Cut', '筒状ループ'),
            ('suv_auto_seam_tube_angle_window', 'Tube Width', '筒状角度幅'),
            ('suv_auto_seam_tube_axis', 'Tube Axis', '筒状軸'),
            ('suv_auto_seam_tube_cut_count', 'Tube Cuts', '筒状カット本数'),
            ('suv_auto_seam_boundary_weight', 'Boundary', '境界'),
            ('suv_auto_seam_sharp_weight', 'Sharp', 'シャープ'),
            ('suv_auto_seam_material_weight', 'Material', '材質境界'),
            ('suv_auto_seam_clear_existing', 'Clear First', '先に解除'),
            ('suv_auto_seam_mark_boundaries', 'Open Borders', '開口境界'),
        ), columns=2)
        _native_row(seam_cfg, context, 'smart_uv_suite.native_seam_action', (
            {'en': 'Auto Seam', 'ja': '自動シーム', 'icon': 'seam', 'action': 'AUTO_SEAM'},
        ), scale_y=1.05)

def _draw_native_compact_align_section(body, context) -> None:
    ws = _ws(context)
    hub = _curated_group(body, context, 'Alignment / Shape Hub', '整列/形状調整ハブ', 'align', 'native_align_hub')
    _curated_props_grid(hub, ws, (
        ('uv_chain_axis_mode', 'Axis Basis', '軸基準'),
        ('uv_chain_group_mode', 'Scope', '対象範囲'),
        ('uv_flow_strength', 'Flow', 'フロー'),
        ('smart_relax_iterations', 'Relax', 'リラックス回数'),
    ), columns=2)
    _native_menu(hub, context, 'smart_uv_suite.native_align_action', 'Align / Transform Menu', '整列/変形メニュー', 'align')
    _native_row(hub, context, 'smart_uv_suite.native_align_action', (
        {'en': 'Fit', 'ja': 'フィット', 'icon': 'fit', 'action': 'FIT'},
        {'en': 'Straight', 'ja': '直線化', 'icon': 'straight', 'action': 'STRAIGHTEN'},
        {'en': 'Grid', 'ja': 'グリッド化', 'icon': 'gridify', 'action': 'GRIDIFY'},
        {'en': 'Relax', 'ja': 'リラックス', 'icon': 'relax', 'action': 'RELAX'},
    ), scale_y=1.15)
    _native_row(hub, context, 'smart_uv_suite.native_align_action', (
        {'en': 'Rotate', 'ja': '回転', 'icon': 'rotate', 'action': 'ROTATE_90'},
        {'en': 'Flip U', 'ja': 'U反転', 'icon': 'mirror_h', 'action': 'FLIP_U'},
        {'en': 'Flip V', 'ja': 'V反転', 'icon': 'mirror_v', 'action': 'FLIP_V'},
        {'en': 'Snap', 'ja': '吸着', 'icon': 'snap', 'action': 'SNAP_PIXEL'},
    ))
    stitch = _curated_group(body, context, 'Stitch / Weld', 'スティッチ/ウェルド', 'stitch', 'native_align_stitch')
    _native_row(stitch, context, 'smart_uv_suite.native_align_action', (
        {'en': 'Stitch/Weld', 'ja': '結合', 'icon': 'stitch', 'action': 'STITCH_WELD'},
        {'en': 'Pin', 'ja': 'ピン', 'icon': 'pin', 'id': 'smart_uv_suite.native_seam_action', 'action': 'PIN'},
        {'en': 'Unpin', 'ja': 'ピン解除', 'icon': 'unpin', 'id': 'smart_uv_suite.native_seam_action', 'action': 'UNPIN'},
    ))



def _draw_native_compact_pack_section(body, context) -> None:
    ws = _ws(context)
    auto = _curated_group(body, context, 'Auto Packing', '自動パッキング', 'pack', 'native_auto_packing')
    if auto is None:
        return
    _draw_auto_pack_settings_suv43(auto, context, ws, 'native_auto')
    # Island direction alignment is unified under UV Align > Direction Align.

def _draw_native_compact_bake_section(body, context) -> None:
    ws = _ws(context)
    hub = _curated_group(body, context, 'Bake / Texel Hub', 'ベイク/テクセルハブ', 'bake', 'native_bake_hub')
    settings = _curated_foldout_group(hub, context, 'native_bake_settings', 'Bake / Texel Settings', 'ベイク/テクセル設定', 'settings', 'native_bake_hub', default=True)
    if settings is not None:
        _curated_props_grid(settings, ws, (
            ('canvas_size', 'Texture Size', 'テクスチャサイズ'),
            ('fit_padding_px', 'Padding', '余白'),
            ('workflow_density', 'Target Density', '目標密度'),
            ('suv_native_target_density', 'Native Density', '統合密度'),
        ), columns=2)
    bake_ops = _curated_foldout_group(hub, context, 'native_bake_density_ops', 'Bake / Density', 'ベイク/密度', 'bake', 'native_bake_hub', default=True)
    if bake_ops is not None:
        _native_menu(bake_ops, context, 'smart_uv_suite.native_bake_action', 'Bake / Texel / Checker Menu', 'ベイク/テクセル/チェッカーメニュー', 'bake')
        _native_row(bake_ops, context, 'smart_uv_suite.native_bake_action', (
            {'en': 'Bake Prep', 'ja': 'ベイク準備', 'icon': 'bake', 'action': 'BAKE_PREP'},
            {'en': 'Density', 'ja': '密度取得', 'icon': 'density_pick', 'action': 'DENSITY_GET'},
            {'en': 'Normalize', 'ja': '密度正規化', 'icon': 'density_normalize', 'action': 'DENSITY_NORMALIZE'},
        ), scale_y=1.18)
    preview_ops = _curated_foldout_group(hub, context, 'native_bake_checker_id_ops', 'Checker / ID Maps', 'チェッカー/IDマップ', 'checker', 'native_bake_hub', default=True)
    if preview_ops is not None:
        _native_row(preview_ops, context, 'smart_uv_suite.native_bake_action', (
            {'en': 'Checker', 'ja': 'チェッカー', 'icon': 'checker', 'action': 'CHECKER_CREATE'},
            {'en': 'Object IDs', 'ja': 'オブジェクトID', 'icon': 'color_grid', 'action': 'COLOR_ID_OBJECTS'},
            {'en': 'Face IDs', 'ja': '面ID', 'icon': 'color_grid', 'action': 'COLOR_ID_FACES'},
        ))


def _draw_native_compact_id_section(body, context) -> None:
    ws = _ws(context)
    hub = _curated_group(body, context, 'UV Map / Transfer Hub', 'UVマップ/転送ハブ', 'uvmap', 'native_id_hub')
    settings = _curated_foldout_group(hub, context, 'native_id_channel_settings', 'UV Map Settings', 'UVマップ設定', 'settings', 'native_id_hub', default=True)
    if settings is not None:
        _curated_props_grid(settings, ws, (
            ('uv_new_name', 'UV Name', 'UV名'),
            ('suv_native_uv_name', 'Native UV Name', '統合UV名'),
        ), columns=1)
    map_ops = _curated_foldout_group(hub, context, 'native_id_map_ops', 'Add / Remove UV Maps', 'UVマップ追加/削除', 'uvmap', 'native_id_hub', default=True)
    if map_ops is not None:
        _native_menu(map_ops, context, 'smart_uv_suite.native_id_action', 'UV Map / Copy / ID Menu', 'UVマップ/コピー/IDメニュー', 'uvmap')
        _native_row(map_ops, context, 'smart_uv_suite.native_id_action', (
            {'en': 'Add', 'ja': '追加', 'icon': 'uvmap', 'action': 'UVMAP_ADD'},
            {'en': 'Duplicate', 'ja': '複製', 'icon': 'SEQ_STRIP_DUPLICATE', 'action': 'UVMAP_DUPLICATE'},
            {'en': 'Remove', 'ja': '削除', 'icon': 'remove', 'action': 'UVMAP_REMOVE'},
        ), scale_y=1.14)
    copy_ops = _curated_foldout_group(hub, context, 'native_id_transfer_ops', 'Transfer / Clipboard', '転送/クリップボード', 'transfer', 'native_id_hub', default=True)
    if copy_ops is not None:
        _native_row(copy_ops, context, 'smart_uv_suite.native_id_action', (
            {'en': 'Transfer', 'ja': '転送', 'icon': 'transfer', 'action': 'UVMAP_TRANSFER'},
            {'en': 'Copy UV', 'ja': 'UVコピー', 'icon': 'copy', 'action': 'UV_COPY'},
            {'en': 'Paste UV', 'ja': 'UV貼付', 'icon': 'paste', 'action': 'UV_PASTE'},
        ))


def _draw_native_compact_cleanup_section(body, context) -> None:
    ws = _ws(context)
    hub = _curated_group(body, context, 'Inspection / Repair Hub', '検査/修復ハブ', 'inspect', 'native_cleanup_hub')
    settings = _curated_foldout_group(hub, context, 'native_cleanup_scan_settings', 'Scan / Repair Settings', '検査/修復設定', 'settings', 'native_cleanup_hub', default=True)
    if settings is not None:
        _curated_props_grid(settings, ws, (
            ('stretch_threshold', 'Stretch Limit', '歪み許容値'),
            ('scan_report_name', 'Report Name', 'レポート名'),
            ('smart_sliver_protection', 'Sliver Protection', '細片保護'),
            ('smart_lock_overlaps', 'Preserve Overlap', '重なり保持'),
        ), columns=2)
    select_ops = _curated_foldout_group(hub, context, 'native_cleanup_select_ops', 'Issue Selection', '問題選択', 'select', 'native_cleanup_hub', default=True)
    if select_ops is not None:
        _native_menu(select_ops, context, 'smart_uv_suite.native_cleanup_action', 'Inspection / Cleanup Menu', '検査/整理メニュー', 'inspect')
        _native_row(select_ops, context, 'smart_uv_suite.native_cleanup_action', (
            {'en': 'Zero', 'ja': 'ゼロ', 'icon': 'select_zero', 'action': 'SELECT_ZERO'},
            {'en': 'Flipped', 'ja': '反転', 'icon': 'select_flipped', 'action': 'SELECT_FLIPPED'},
            {'en': 'Overlap', 'ja': '重なり', 'icon': 'select_overlap', 'action': 'SELECT_OVERLAP'},
            {'en': 'UDIM', 'ja': 'UDIM', 'icon': 'udim', 'action': 'SELECT_UDIM'},
        ), scale_y=1.14)
    repair_ops = _curated_foldout_group(hub, context, 'native_cleanup_repair_ops', 'Repair / Data Cleanup', '修復/データ整理', 'repair', 'native_cleanup_hub', default=True)
    if repair_ops is not None:
        _native_row(repair_ops, context, 'smart_uv_suite.native_cleanup_action', (
            {'en': 'Auto Repair', 'ja': '自動修復', 'icon': 'repair', 'action': 'AUTO_REPAIR'},
            {'en': 'Invert', 'ja': '反転選択', 'icon': 'select', 'action': 'SELECT_INVERT'},
            {'en': 'Clean Data', 'ja': 'データ整理', 'icon': 'cleanup', 'action': 'CLEAN_GENERATED'},
        ))


def _draw_native_compact_io_section(body, context) -> None:
    hub = _curated_group(body, context, 'Output / Support Hub', '出力/サポートハブ', 'report', 'native_io_hub')
    output_ops = _curated_foldout_group(hub, context, 'native_io_output_ops', 'Settings / Reports', '設定/レポート', 'report', 'native_io_hub', default=True)
    if output_ops is not None:
        _native_menu(output_ops, context, 'smart_uv_suite.native_io_action', 'I/O / Report Menu', '入出力/レポートメニュー', 'report')
        _native_row(output_ops, context, 'smart_uv_suite.native_io_action', (
            {'en': 'Settings', 'ja': '設定出力', 'icon': 'settings', 'action': 'EXPORT_SETTINGS'},
            {'en': 'Report', 'ja': 'レポート', 'icon': 'report', 'action': 'WRITE_REPORT'},
            {'en': 'Clean', 'ja': '整理', 'icon': 'cleanup', 'action': 'CLEAN_GENERATED'},
        ), scale_y=1.15)
    support = _curated_foldout_group(hub, context, 'native_io_support_note', 'Output Note', '出力メモ', 'report', 'native_io_hub', default=False)
    if support is not None:
        try:
            pass  # INFO-note moved to Help; no in-section info-icon explanation.
        except Exception:
            pass




def _draw_manual_keymap_registration(layout, context, *, recommended_place_en: str, recommended_place_ja: str, operator_id: str, input_en: str = '', input_ja: str = '') -> None:
    """Draw copyable manual-keymap information without registering keymaps."""
    try:
        box = layout.box()
    except Exception:
        box = layout
    try:
        box.label(text=_tr(context, 'Keymap Registration Reference', 'キーマップ登録情報'))
    except Exception:
        pass
    try:
        box.label(text=_tr(context, 'Recommended location:', '推奨登録場所:'))
        box.label(text=_tr(context, recommended_place_en, recommended_place_ja))
    except Exception:
        pass
    if input_en or input_ja:
        try:
            box.label(text=_tr(context, 'Recommended input:', '推奨入力:'))
            box.label(text=_tr(context, input_en, input_ja))
        except Exception:
            pass
    try:
        row = box.row(align=True)
    except Exception:
        row = box
    try:
        row.label(text=_tr(context, 'Keymap Registration', 'キーマップ登録'))
    except Exception:
        pass
    try:
        if _curated_operator_can_draw('smart_uv_suite.copy_operator_id', {'text': str(operator_id or '')}):
            op = row.operator('smart_uv_suite.copy_operator_id', text=_tr(context, 'Copy ID', 'IDコピー'), icon='COPYDOWN')
            op.text = str(operator_id or '')
            _help_scope_register_operator('smart_uv_suite.copy_operator_id', 'Copy ID', 'IDコピー', {'text': str(operator_id or '')})
    except Exception:
        pass

def _draw_operations_section(body, context) -> None:
    ws = _ws(context)
    instant = _curated_group(body, context, 'Immediate Select / Drag Move', '即時選択', 'select', 'operation_immediate_select')
    if ws is not None:
        _curated_props_grid(instant, ws, (
            ('operation_instant_select_enabled', 'Enable Instant Select Drag Move', '即時選択ドラッグ移動'),
        ), columns=1)
    axis_memory = _curated_group(body, context, 'Axis Constraint Memory', '軸拘束の記憶', 'axis', 'operation_axis_constraint_memory')
    if ws is not None:
        _curated_props_grid(axis_memory, ws, (
            ('operation_axis_constraint_memory_enabled', 'Remember Axis Constraint', '軸拘束の記憶'),
        ), columns=1)

    cursor_hover = _curated_group(body, context, '2D Cursor to Hover Vertex', 'ホバー頂点へ2Dカーソル', 'cursor', 'operation_cursor_to_hover_vertex')
    _draw_manual_keymap_registration(
        cursor_hover, context,
        recommended_place_en='Preferences > Keymap > Image Editor > UV Editor',
        recommended_place_ja='プリファレンス > キーマップ > 画像エディター > UVエディター',
        operator_id='smart_uv_suite.cursor_to_hover_uv_vertex',
        input_en='',
        input_ja='',
    )

    gizmo_grip = _curated_group(body, context, 'UV Gizmo Grip Fix', 'UVギズモつかみ補助', 'gizmo', 'operation_uv_gizmo_grip_fix')
    if ws is not None:
        _curated_props_grid(gizmo_grip, ws, (
            ('operation_uv_gizmo_grip_fix_enabled', 'Enable UV Gizmo Grip Fix', 'UVギズモつかみ補助'),
        ), columns=1)

    uv_ownership = _curated_group(body, context, 'UV Editor Ownership', 'UVエディター操作の管理', 'tool', 'operation_uv_editor_ownership')
    if ws is not None:
        _curated_props_grid(uv_ownership, ws, (
            ('operation_uv_crossing_select_edges_enabled', 'Crossing Selection: Edges', '交差選択：辺'),
            ('operation_uv_crossing_select_faces_enabled', 'Crossing Selection: Faces', '交差選択：面'),
            ('operation_uv_proportional_cursor_keymap_enabled', 'UV Proportional Cursor Entry', 'UVプロポーショナル編集カーソル入力'),
        ), columns=1)
    # U7: the recommended manual-registration target for the proportional
    # cursor entry.  Verified live on 5.1.2: the dispatching keymap is
    # 'UV Editor' (space EMPTY, region WINDOW), shown in the keymap editor
    # under the 'Image' category node.  The built-in suite rows use
    # Page Up / Page Down with delta +0.1 / -0.1.
    _draw_manual_keymap_registration(
        uv_ownership, context,
        recommended_place_en='Preferences > Keymap > Image > UV Editor',
        recommended_place_ja='プリファレンス > キーマップ > 画像 > UVエディター',
        operator_id='image.smart_uv_proportional_size_cursor',
        input_en='Page Up / Page Down (Delta 0.1 / -0.1)',
        input_ja='Page Up / Page Down（Delta 0.1 / -0.1）',
    )


def _draw_keymap_info_section(body, context) -> None:
    rows = _PUBLIC_KEYMAP_ROWS_SNAPSHOT
    if not rows:
        box = _curated_group(body, context, 'Keymap Entries', 'キーマップ登録一覧', 'keyboard', 'keymap_info_entries')
        box.label(text=_tr(context, 'No Smart UV Suite keymap entries are active.', '有効なSmart UV Suiteキーマップ登録はありません。'))
        return
    for item in rows:
        target = str(item.get('id') or '')
        title_en = str(item.get('feature_en') or target)
        title_ja = str(item.get('feature_ja') or title_en)
        box = _curated_group(body, context, title_en, title_ja, 'keyboard', 'keymap_info_' + target.lower())
        status_ja = str(item.get('status_ja') or '')
        status_en = str(item.get('status_en') or '')
        if status_ja or status_en:
            box.label(text=_tr(context, status_en or status_ja, status_ja or status_en), icon='KEYINGSET')
        location = str(item.get('location_ja') if _DRAW_IS_JA else item.get('location_en') or '')
        if location:
            box.label(text=_tr(context, 'Location: ', '登録場所: ') + location)
        operator_id = str(item.get('operator') or '')
        if operator_id:
            row = box.row(align=True)
            row.label(text=_tr(context, 'Keymap Registration', 'キーマップ登録'))
            if _curated_operator_can_draw('smart_uv_suite.copy_operator_id', {'text': operator_id}):
                op = row.operator('smart_uv_suite.copy_operator_id', text=_tr(context, 'Copy', 'コピー'), icon='COPYDOWN')
                op.text = operator_id



def _draw_management_section(body, context) -> None:
    id_group = _curated_group(body, context, 'ID Management', 'ID管理', 'uvmap', 'manage_id')
    _draw_id_section(id_group, context)
    cleanup_group = _curated_group(body, context, 'Cleanup', '整理', 'cleanup', 'manage_cleanup')
    _draw_cleanup_section(cleanup_group, context)
    io_group = _curated_group(body, context, 'I/O', '入出力', 'transfer', 'manage_io')
    _draw_io_section(io_group, context)


def _draw_curated_section_body(body, context, key: str) -> None:
    # 1.5.24: Basic Settings and UV Align are restored to the 1.5.3 UI/function
    # bodies.  Other top-level section headers keep the compact integrated hub.
    if key == 'basic':
        _draw_basic_settings_section(body, context)
    elif key == 'unwrap':
        _draw_public_unwrap_section(body, context)
    elif key == 'align':
        _draw_align_section(body, context)
    elif key == 'pack':
        _draw_native_compact_pack_section(body, context)
    elif key == 'bake':
        _draw_bake_section(body, context)
    elif key == 'operation':
        _draw_operations_section(body, context)
    elif key == 'manage':
        _draw_management_section(body, context)
    elif key == 'keymap_info':
        _draw_keymap_info_section(body, context)


def _draw_grouped_stable_sections(root, context, *, core_module=None, integrated_draw=None):
    del core_module, integrated_draw
    area = getattr(context, "area", None)
    compact_file_browser = getattr(area, "ui_type", None) == "FILES"
    fold_prefix = "stable_files_curated_" if compact_file_browser else "stable_curated_"

    def _top_slot():
        try:
            slot = root.column(align=True)
            slot.use_property_split = False
            slot.use_property_decorate = False
            return slot
        except Exception:
            return root

    for key, label_en, label_ja, icon, help_id, default_open in _CURATED_SECTIONS:
        fold_key = fold_prefix + str(key)
        _box, body, expanded = _top_level_foldout(
            _top_slot(),
            context,
            fold_key,
            label_en,
            label_ja,
            icon,
            default=bool(default_open) and not compact_file_browser,
            help_id=help_id,
        )
        if expanded and body is not None:
            try:
                _draw_curated_section_body(body, context, str(key))
            except Exception as exc:
                try:
                    body.label(text=_one_line(exc, 90), icon='ERROR')
                except Exception:
                    pass

def draw_canonical_fallback(layout, context) -> bool:
    """Render all canonical bodies without persistence or runtime mutation."""
    if layout is None:
        return False
    try:
        _draw_always_on(layout, context, None)
    except Exception:
        pass
    rendered = 0
    for key, label_en, label_ja, icon, _help_id, _default_open in _CURATED_SECTIONS:
        try:
            section = layout.column(align=True)
            box = section.box()
            _box_header(box, context, label_en, label_ja, icon, '')
            body = box.column(align=True)
            _draw_curated_section_body(body, context, str(key))
            rendered += 1
        except Exception:
            continue
    return rendered == len(_CURATED_SECTIONS)


def draw(layout, context, *, core_module=None, always_on_draw=None, integrated_draw=None, native_draw=None) -> bool:
    del integrated_draw, native_draw
    if layout is None:
        return False
    _begin_draw_cache(context)
    try:
        try:
            layout.use_property_split = False
            layout.use_property_decorate = False
        except Exception:
            pass
        # Draw the canonical box directly into the panel layout.  Creating a
        # wrapper column first made the Always-on group cease to be the first
        # top-level boxed section in Blender's UI structure.
        root = layout
        try:
            # The always-on controls stay fixed at the top.  The remaining tools use
            # Smart Modeling-style collapsible section groups to keep the N-panel short.
            _draw_always_on(root, context, always_on_draw)
            _draw_grouped_stable_sections(root, context, core_module=core_module, integrated_draw=None)

            # Diagnostic catalogs and source-tool integration remain internal.
            # They are not user-requested N-panel sections and therefore are not
            # appended to the canonical Smart UV Suite body.
            return True
        except Exception as exc:
            try:
                root.label(text=_one_line(exc, 90), icon='ERROR')
            except Exception:
                pass
            return False
    finally:
        _end_draw_cache()

# -----------------------------------------------------------------------------
# Smart UV Suite 1.6.15 final UI guard
# Keep every UV-unwrapping entry point on the same Standard/Square/Circle-split UI.
# This prevents older Shape foldout code paths from being shown by fallback panels.
# -----------------------------------------------------------------------------
def _draw_unwrap_section(body, context) -> None:
    return _draw_native_compact_unwrap_section(body, context)

# Smart UV Suite 1.8.169 draw-safe icon lookup: lifecycle code may populate any
# existing icon cache, while draw only reads an already materialized value.
def _icon_value(icon_name, *args, **kwargs):  # type: ignore[no-redef]
    del args, kwargs
    key = str(icon_name or "")
    for cache_name in ("_ICON_VALUE_CACHE", "_ICON_CACHE", "_ICON_VALUES", "_CUSTOM_ICON_VALUES"):
        cache = globals().get(cache_name)
        if isinstance(cache, dict):
            try:
                value = cache.get(key, 0)
                if isinstance(value, int):
                    return int(value)
                icon_id = getattr(value, "icon_id", 0)
                if icon_id:
                    return int(icon_id)
            except Exception:
                continue
    return 0
