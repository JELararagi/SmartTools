# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

'UV Suite Smart: document-synced upper-compatible UV feature layer.\n\nThis module does not copy third-party tools.  It exposes a local UV Suite route for each documented UV function by chaining Blender-native\noperators and UV Suite compatibility bridges.\n'
from . import resource_api_18168 as _suv_resource

import json
import os
import math
from pathlib import Path
from typing import Any

import bpy


def _is_ja(context=None) -> bool:
    try:
        lang = str(getattr(getattr(context, "preferences", None).view, "language", "") or "")
    except Exception:
        lang = ""
    return lang.startswith("ja") or lang.startswith("jp") or lang == "DEFAULT_JAPANESE"


def _tr(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _data_path(name: str) -> Path:
    return Path(__file__).resolve().parent / "data" / str(name)


def _load_json(name: str, default: Any) -> Any:
    try:
        path = _data_path(name)
        if not path.exists():
            return default
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception:
        return default


def _native_feature_entries() -> list[dict[str, Any]]:
    # 外部の参照データ（external_feature_reference.json）は同梱されない。同梱の data/jel_native_feature_matrix.json の
    # families を機能の一覧にし、各 native action を smart_uv_suite.native_hub_action で実行する（PD34C v2）。
    raw = _load_json("jel_native_feature_matrix.json", {})
    families = raw.get("families") if isinstance(raw, dict) else None
    if not isinstance(families, list):
        return []
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for family in families:
        if not isinstance(family, dict):
            continue
        fam = str(family.get("key") or "").strip()
        for action in list(family.get("native_actions") or []):
            key = str(action or "").strip().upper()
            if not key or key in seen:
                continue
            seen.add(key)
            out.append({
                "key": key,
                "native": True,
                "family": fam,
                "category": fam,
                "feature": key.replace("_", " ").title(),
                "tool": "Smart UV native",
                "actions": [{"type": "operator", "idname": "smart_uv_suite.native_hub_action", "kwargs": {"action": key}}],
            })
    return out


def _feature_entries() -> list[dict[str, Any]]:
    raw = _load_json("external_feature_reference.json", {})
    entries = raw.get("entries") if isinstance(raw, dict) else None
    if not isinstance(entries, list):
        return _native_feature_entries()
    out: list[dict[str, Any]] = []
    for entry in entries:
        if isinstance(entry, dict) and str(entry.get("key") or "").strip():
            out.append(dict(entry))
    return out


def _feature_map() -> dict[str, dict[str, Any]]:
    return {str(entry.get("key") or "").strip(): entry for entry in _feature_entries()}


def find_feature(key: str) -> dict[str, Any] | None:
    key = str(key or "").strip()
    if not key:
        return None
    table = _feature_map()
    if key in table:
        return table[key]
    upper = key.upper()
    for candidate, entry in table.items():
        if candidate.upper() == upper:
            return entry
    return None


def _document_tools() -> list[dict[str, Any]]:
    raw = _load_json("document_sync_matrix.json", {})
    tools = raw.get("tools") if isinstance(raw, dict) else None
    if not isinstance(tools, list):
        return []
    out = []
    for tool in tools:
        if isinstance(tool, dict):
            out.append(dict(tool))
    return out


def _target_entries() -> dict[str, dict[str, Any]]:
    raw = _load_json("external_compat_targets.json", {})
    targets = raw.get("targets") if isinstance(raw, dict) else None
    if not isinstance(targets, dict):
        return {}
    return {str(k).upper(): dict(v) for k, v in targets.items() if isinstance(v, dict)}


_PROFILE_BY_TARGET = {
    "BLENDER_NATIVE": "BLENDER_NATIVE",
    "MAYA": "MAYA_CUTSEW",
    "BONUS_TOOLS": "BONUS_TOOLS_AUTO",
    "MAX": "MAX_PEEL_RELAX",
    "MAX_UVTOOLS": "MAX_UVTOOLS",
    "HOUDINI": "HOUDINI_LABS",
    "DCC Reference": "DCC_REFERENCE_MOF",
    "MODO": "MODO_PEEL",
    "LIGHTWAVE": "LIGHTWAVE_HEAL",
    "THREEDCOAT": "COAT3D_GU",
    "ZBRUSH": "ZBRUSH_MASTER",
    "SUBSTANCE_PAINTER": "SUBSTANCE_AUTO",
    "SUBSTANCE_DESIGNER": "SUBSTANCE_AUTO",
    "UNREAL": "UNREAL_LIGHTMAP",
    "UNITY": "UNITY_PROBUILDER",
    "DCC_LAYOUT_REFERENCE": "RIZOM_HARD",
    "HEADUS": "HEADUS_RELAX",
    "UVPACKMASTER": "UVPACKMASTER_DENSE",
    "UV_PACKER": "UVPACKMASTER_DENSE",
    "SMART_CHECKER": "ZEN_UV_TRIM",
    "SMART_TEXTURE": "SMART_TEXTURE_BRIDGE",
    "SMART_EDIT": "SMART_EDIT_EDIT",
    "SMART_SURFACE": "SMART_SURFACE_SURFACE",
    "SMART_PRECISION": "SMART_PRECISION_PRECISION",
    "UVFACTORY": "UVFACTORY_PROCEDURAL",
    "HAIR_TOOL": "HAIR_CARD_LAYOUT",
    "MARMOSET": "MARMOSET_BAKE",
    "SMART_STANDARD": "SMART_STANDARD_GAME",
    "MINISTRY_OF_FLAT": "DCC_REFERENCE_MOF",
    "TRIPO_AI": "SUBSTANCE_AUTO",
    "SLOYD": "UNITY_PROBUILDER",
    "DCC_LAYOUT_REFERENCE_MAYA_BRIDGE": "DCC_LAYOUT_REFERENCE_MAYA_BRIDGE",
    "RS_UV_KIT": "RS_UV_KIT",
    "MALCOLM341_SMART_EDIT": "SMART_EDIT_REFERENCE",
}


def _rna_identifier_is_real_operator(identifier: object) -> bool:
    text = str(identifier or "").strip()
    return bool(text) and text not in {"Operator", "OperatorProperties", "UnknownType", "bpy_struct"}


def _operator_proxy(op_id: str):
    text = str(op_id or "").strip()
    if "." not in text:
        return None
    group, name = text.split(".", 1)
    try:
        ops_group = getattr(getattr(bpy, "ops", None), group, None)
        return getattr(ops_group, name, None) if ops_group is not None else None
    except Exception:
        return None


def _operator_rna(op_id: str):
    op = _operator_proxy(op_id)
    if op is None:
        return None
    try:
        rna = op.get_rna_type()
        if not _rna_identifier_is_real_operator(getattr(rna, "identifier", "")):
            return None
        return rna
    except Exception:
        return None


def operator_exists(op_id: str) -> bool:
    return _operator_rna(op_id) is not None


def _property_names(op_id: str) -> set[str]:
    rna = _operator_rna(op_id)
    names: set[str] = set()
    if rna is None:
        return names
    try:
        props = getattr(rna, "properties", None)
        try:
            names.update(str(k) for k in props.keys())
        except Exception:
            pass
        try:
            for prop in props:
                ident = str(getattr(prop, "identifier", "") or "")
                if ident:
                    names.add(ident)
        except Exception:
            pass
    except Exception:
        pass
    return names


def _filtered_kwargs(op_id: str, kwargs: dict[str, Any] | None) -> dict[str, Any]:
    if not kwargs:
        return {}
    names = _property_names(op_id)
    if not names:
        return {}
    out = {}
    for key, value in dict(kwargs).items():
        key = str(key)
        if key in names:
            out[key] = value
    return out


def _call_operator(op_id: str, **kwargs) -> bool:
    op = _operator_proxy(op_id)
    if op is None or not operator_exists(op_id):
        return False
    safe_kwargs = _filtered_kwargs(op_id, kwargs)
    try:
        result = op("EXEC_DEFAULT", **safe_kwargs)
    except Exception:
        return False
    try:
        return "CANCELLED" not in set(result or set())
    except Exception:
        return True


def _workspace_values(context) -> tuple[int, int, float]:
    ws = None
    try:
        ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
    except Exception:
        ws = None
    try:
        texture_size = int(getattr(ws, "canvas_size", 2048) or 2048)
    except Exception:
        texture_size = 2048
    try:
        margin_px = int(getattr(ws, "fit_padding_px", 8) or 8)
    except Exception:
        margin_px = 8
    try:
        density = float(getattr(ws, "workflow_density", 1024.0) or 1024.0)
    except Exception:
        density = 1024.0
    return max(128, texture_size), max(0, min(512, margin_px)), max(1.0, density)


def _ensure_mesh_context(context) -> bool:
    try:
        obj = getattr(context, "active_object", None)
        if obj is None or getattr(obj, "type", "") != "MESH":
            return False
        if getattr(obj, "mode", "") != "EDIT":
            try:
                bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass
        return True
    except Exception:
        return False


def _native_unwrap(mode: str = "ANGLE_BASED", margin: float = 0.01) -> bool:
    candidates = [
        ("uv.unwrap", {"method": mode, "margin": margin}),
        ("uv.unwrap", {"method": mode}),
        ("uv.unwrap", {}),
    ]
    return _run_first(candidates)


def _run_first(candidates: list[tuple[str, dict[str, Any]]]) -> bool:
    for op_id, kwargs in candidates:
        if _call_operator(op_id, **dict(kwargs or {})):
            return True
    return False


def _run_all(groups: list[list[tuple[str, dict[str, Any]]]], *, require_each: bool = False) -> bool:
    any_ok = False
    for group in groups:
        ok = _run_first(group)
        any_ok = any_ok or ok
        if require_each and not ok:
            return False
    return any_ok


def _profile_action(profile: str, context, *, apply_density: bool = True) -> bool:
    tex, margin, density = _workspace_values(context)
    return _call_operator(
        "uv.suv_auto_uv_profile",
        profile=str(profile or "ORGANIC"),
        apply_density=bool(apply_density),
        target_density=float(density),
        texture_size=int(tex),
        margin_px=int(margin),
    )


def _target_action(target: str, context) -> bool:
    target = str(target or "").upper().strip()
    if target and _call_operator(
        "uv.suv_apply_external_compat_target",
        target=target,
        execution_mode="AUTO",
        validate_before_run=True,
        write_report=False,
        allow_fallback_paths=True,
        restore_workspace_on_error=True,
        restore_selection_on_error=True,
        restore_selection_on_finish=True,
    ):
        return True
    profile = _PROFILE_BY_TARGET.get(target)
    if profile:
        return _profile_action(profile, context)
    return False


def _texel(action: str, context) -> bool:
    tex, _margin, density = _workspace_values(context)
    if action == "GET":
        return _call_operator("uv.suv_texel_get", scope="SELECTED", texture_size=tex, use_world_scale=True)
    if action == "NORMALIZE":
        return _call_operator("uv.suv_texel_normalize", mode="AVERAGE", value_density=density, texture_size=tex, use_world_scale=True, skip_pinned=True)
    return _call_operator("uv.suv_texel_set", scope="SELECTED", target_density=density, texture_size=tex, use_world_scale=True, skip_pinned=True, keep_tile=True)


_ACTION_ITEMS = [
    ("SUPER_AUTO", "Supreme Auto", "Maximum-precision auto seam, unwrap, relax, density, pack, and inspection route."),
    ("SUPER_SAFE_AUTO", "Safe Supreme Auto", "High-precision automatic route that avoids aggressive seam changes when possible."),
    ("SUPER_UNWRAP", "Supreme Unwrap", "Maximum-precision unwrap and relax route with preflight and postflight checks."),
    ("SUPER_PACK", "Supreme Pack", "Density-aware deterministic pack route with candidate audit and native fallback."),
    ("SUPER_DENSITY", "Supreme Density", "Measure, normalize, checker, and post-scan density route."),
    ("SUPER_REPAIR", "Supreme Repair", "Flipped, overlap, density, and layout auto-heal route."),
    ("SUPER_ANALYZE", "Precision Analyze", "Write a UV precision metric report without changing the layout."),
    ("FULL_AUTO", 'Full Auto UV Suite', "One-click auto seam, unwrap, relax, density, pack, and scan."),
    ("AUTO_UV_SAFE", "Safe Auto UV", "Rule-based auto UV route for general production meshes."),
    ("UVMASTER_LOCAL", "UV Master Local", "ZBrush UV Master style local automatic unwrap route."),
    ("MINISTRY_FLAT_LOCAL", "Ministry of Flat Local", 'Fully automatic unwrap approximation using local Blender and UV Suite routes.'),
    ("SUBSTANCE_AUTO_PREP", "Smart UVテクスチャ参照 Auto Prep", "Texture-set friendly Auto UV and pack preparation."),
    ("UE_LIGHTMAP", "Game Engine Lightmap", "Overlap-safe lightmap layout and scan."),
    ("UNITY_PROBUILDER", "Game Engine ProBuilder", "Smart projection, fit, pack and density route for engine-style geometry."),
    ("AUTO_SEAM_ANGLE", "Auto Seam Angle", "Generate seams from mesh angles."),
    ("AUTO_SEAM_SHARP", "Auto Seam Sharp", "Generate seams from sharp edges."),
    ("AUTO_SEAM_MATERIAL", "Auto Seam Material", "Generate seams from material boundaries."),
    ("CUT_SELECTED", "Cut Selected", "Mark selected edges as seams."),
    ("SEW_SELECTED", "Sew Selected", "Clear selected seams or sew UV boundaries."),
    ("STITCH_SELECTED", 'Stitch UVs', "Stitch nearby selected UV boundaries."),
    ("UNWRAP_ABF", "ABF Unwrap", "Angle-based unwrap route."),
    ("UNWRAP_LSCM", "LSCM Unwrap", "Conformal/LSCM unwrap route."),
    ("UNWRAP_SLIM", "Minimum Stretch", "Blender minimum-stretch/SLIM-like route with fallback."),
    ("OPTIMIZE_RELAX", "Optimize Relax", "Real-time optimize / relax approximation."),
    ("RELAX_PRESERVE", "Relax Preserve", "Relax UVs while preserving the current shell structure."),
    ("PELT_UNWRAP", "Pelt / Peel", "Pelt/peel-style unwrap route."),
    ("LIVE_UNWRAP_TOGGLE", "Live Unwrap", "Toggle Blender live unwrap when available."),
    ("PIN", "Pin", "Pin selected UV vertices."),
    ("UNPIN", "Unpin", "Unpin selected UV vertices."),
    ("CLEAR_PINS", "Clear Pins", "Remove all UV pins."),
    ("SMART_PROJECT", "Smart Project", 'UV Suite projection.'),
    ("LIGHTMAP_PACK", "Lightmap Pack", "Lightmap-safe projection and packing."),
    ("PROJECT_VIEW", "Project from View", "Project UVs from the current 3D view."),
    ("PROJECT_VIEW_BOUNDS", "Project View Bounds", "Project from view and fit to bounds."),
    ("CUBE_PROJECT", "Cube Projection", "Cube projection."),
    ("CYLINDER_PROJECT", "Cylinder Projection", "Cylinder projection."),
    ("SPHERE_PROJECT", "Sphere Projection", "Sphere projection."),
    ("PLANAR_NORMAL", "Normal / Planar", "Normal or planar based projection route."),
    ("STABLE_PROJECTION", "Stable Projection", "Smart UV手続き補助-style stable projection approximation."),
    ("SPLINE_MAPPING_APPROX", "Spline Mapping", "Spline/strip mapping approximation for tubes and strips."),
    ("HAIR_CARDS_UV", "Hair Cards UV", "Hair-card strip layout and bake-prep approximation."),
    ("PACK_HEURISTIC", "Heuristic Pack", 'Dense pack using deterministic/heuristic UV Suite settings.'),
    ("PACK_EXACT", "Exact Pack", "Pack with exact/boundary-aware shape when available."),
    ("PACK_BBOX", "BBox Pack", "Bounding-box-oriented pack fallback."),
    ("PRIORITY_DENSITY_PACK", "Priority Density Pack", "Density-priority pack route."),
    ("GROUPS_TO_UDIM", "Groups to UDIM", "Distribute groups across UDIM tiles."),
    ("MATERIAL_TO_TILES", "Material to Tiles", "Split layout into tiles by material."),
    ("OBJECT_TO_TILES", "Objects to Tiles", "Batch object-to-UDIM tile layout."),
    ("LOCK_OVERLAP_PACK", "Lock Overlap Pack", "Pack while preserving pinned/overlapped groups when possible."),
    ("STACK_SIMILAR", "Stack Similar", "Stack visually similar islands."),
    ("STACK_IDENTICAL", "Stack Identical", "Stack identical islands."),
    ("STACK_TOPOLOGY", 'Stack Topology Groups', "Stack repeated topology groups."),
    ("UNSTACK", "Unstack", "Move stacked/overlapped islands apart."),
    ("ORIENT_3D", "Orient to 3D", "Orient UV shells to nearest 3D/world axes."),
    ("ORIENT_BBOX", "Orient BBox", "Orient shells by compact bounding box."),
    ("RANDOMIZE", "Randomize", "Randomize selected islands for texture variation."),
    ("EXPLODE", "Explode", "Separate islands for inspection or manual cleanup."),
    ("CROP", "Crop", "Crop into current tile."),
    ("FILL", "Fill", "Fill current tile."),
    ("FIT", "Fit", "Fit selected islands into bounds."),
    ("ALIGN_PAD", "Align Pad Center", "Center with the 3x3 alignment route."),
    ("ALIGN_EDGE", "Align Edge", "Align to selected edge."),
    ("SORT_H", "Sort H", "Sort islands horizontally."),
    ("SORT_V", "Sort V", "Sort islands vertically."),
    ("DISTRIBUTE_H", "Distribute H", "Distribute horizontally."),
    ("DISTRIBUTE_V", "Distribute V", "Distribute vertically."),
    ("RECTIFY", "Rectify", "Rectify shells into cleaner rectangles."),
    ("GRIDIFY", "Gridify", "Regularize into a grid."),
    ("QUADRIFY", "Quadrify", "Quadrify selected UVs."),
    ("SQUAREIFY", "Squareify", "Squareify selected UVs."),
    ("IRON_FACES", "Iron Faces", "Iron/straighten faces into a single readable layout."),
    ("UNITIZE", "Unitize", "Unitize faces into UV cells."),
    ("BOUNDARY_CIRCLE", "Boundary Circle", "Force boundary toward circular layout."),
    ("BOUNDARY_QUAD", "Boundary Quad", "Force boundary toward quad/rect layout."),
    ("QUICK_SNAP", "Quick Snap", "Snap selected UVs or boundaries precisely."),
    ("TD_GET", "Get Density", "Measure texel density."),
    ("TD_SET", "Set Density", "Apply saved workflow density."),
    ("TD_NORMALIZE", "Normalize TD", "Normalize selected islands to saved density."),
    ("TD_WORLD_SCALE", 'World Scale UV Menu', "Smart UV Suite surface-lock world scale density route."),
    ("CHECKER", "Checker", "Create or assign checker material."),
    ("STRETCH_HEATMAP", "Stretch Heatmap", "Visualize stretch/distortion."),
    ("DISTORTION_SHADER", "Distortion Shader", "Smart UV標準DCC-style distortion display approximation."),
    ("HISTOGRAM", "Histogram", "Open UV histogram/gradient tools."),
    ("INSPECT_SCAN", "Scan", "Scan UV issues."),
    ("SELECT_OVERLAP", "Select Overlap", "Select overlapping UVs."),
    ("SELECT_FLIPPED", "Select Flipped", "Select flipped UVs."),
    ("SELECT_ZERO", "Select Zero", "Select zero-area UV islands."),
    ("SELECT_UNMAPPED", "Select Unmapped", "Select unmapped or fragmented UV content."),
    ("SELECT_BACKFACING", "Select Back-facing", "Back-facing selection approximation using flipped inspection."),
    ("SELECT_SIMILAR", "Select Similar", "Select similar islands."),
    ("SELECT_IDENTICAL", "Select Identical", "Select identical islands."),
    ("SIMILARITY_SELECTOR", "Smart Similarity", "Similarity/smart-similarity bridge."),
    ("FIX_ALL", "Fix All", "Run automatic issue repair helpers."),
    ("UV_MAP_ADD", "Add UV Map", "Add a UV layer."),
    ("UV_MAP_DUP", "Duplicate UV Map", "Duplicate the active UV layer."),
    ("UV_MAP_RENAME", "Rename UV Map", "Rename the active UV layer using N-panel name."),
    ("UV_MAP_SYNC", "UV Map Sync", "Open native UV-map channel workflow_hub."),
    ("ATLAS_BUILD", "Build Atlas", "Build atlas UVs."),
    ("ATLAS_BAKE", "Atlas Bake", "Prepare/run atlas baking route."),
    ("BAKE_PREP", "Bake Prep", "Prepare UVs for texture baking."),
    ("MULTI_OBJECT_BATCH", "Multi Object Batch", "Batch layout selected objects."),
    ("RIZOM_BRIDGE", "Reference Layout Bridge", "Smart UV高精度参照-compatible route."),
    ("HEADUS_BRIDGE", "Smart UV展開参照 Bridge", "Smart UV展開参照-compatible route."),
    ("UVPACKMASTER_BRIDGE", "Smart UV高密度パック Bridge", "Smart UV高密度パック-compatible route."),
    ("SMART_CHECKER_BRIDGE", "Smart UVレイアウト参照 Bridge", "Smart UVレイアウト参照-compatible route."),
    ("SMART_TEXTURE_BRIDGE", "Smart UV Suite reference Bridge", "Smart UV Suite reference-compatible route."),
    ("SMART_PRECISION_BRIDGE", "Smart UV Precision Bridge", "Smart UV Precision-compatible route."),
    ("SMART_SURFACE_BRIDGE", "Smart UV Suite Bridge", "Smart UV Suite-compatible route."),
    ("HOUDINI_BRIDGE", "DCC Reference Bridge", "DCC Reference-compatible route."),
    ("REPORT_MATRIX", "Write Matrix", 'Write the UV Suite Smart coverage matrix to CONFIG/Smart_UV_Suite.'),
]

_ACTION_LABELS = {key: label for key, label, _desc in _ACTION_ITEMS}
_ACTION_DESC = {key: desc for key, _label, desc in _ACTION_ITEMS}

_ACTION_JA = {
    "SUPER_AUTO": "最高精度自動",
    "SUPER_SAFE_AUTO": "安全最高精度",
    "SUPER_UNWRAP": "最高精度展開",
    "SUPER_PACK": "最高精度パック",
    "SUPER_DENSITY": "最高精度密度",
    "SUPER_REPAIR": "最高精度修復",
    "SUPER_ANALYZE": "精度解析",
    "FULL_AUTO": '全自動 UV Suite',
    "AUTO_UV_SAFE": "安全自動UV",
    "UVMASTER_LOCAL": "UV Master風",
    "MINISTRY_FLAT_LOCAL": "完全自動展開風",
    "SUBSTANCE_AUTO_PREP": "Smart UVテクスチャ参照準備",
    "UE_LIGHTMAP": "Game Engineライトマップ",
    "UNITY_PROBUILDER": "Game Engine ProBuilder",
    "AUTO_SEAM_ANGLE": "角度自動シーム",
    "AUTO_SEAM_SHARP": "シャープ自動シーム",
    "AUTO_SEAM_MATERIAL": "材質自動シーム",
    "CUT_SELECTED": "カット",
    "SEW_SELECTED": "縫合/解除",
    "STITCH_SELECTED": "ステッチ",
    "UNWRAP_ABF": "ABF展開",
    "UNWRAP_LSCM": "LSCM展開",
    "UNWRAP_SLIM": "最小歪み",
    "OPTIMIZE_RELAX": "最適化リラックス",
    "RELAX_PRESERVE": "保持リラックス",
    "PELT_UNWRAP": "ペルト/ピール",
    "LIVE_UNWRAP_TOGGLE": "ライブ展開",
    "PIN": "ピン",
    "UNPIN": "ピン解除",
    "CLEAR_PINS": "全ピン解除",
    "SMART_PROJECT": "スマート投影",
    "LIGHTMAP_PACK": "ライトマップ",
    "PROJECT_VIEW": "ビュー投影",
    "PROJECT_VIEW_BOUNDS": "ビュー範囲投影",
    "CUBE_PROJECT": "立方体投影",
    "CYLINDER_PROJECT": "円柱投影",
    "SPHERE_PROJECT": "球投影",
    "PLANAR_NORMAL": "法線/平面投影",
    "STABLE_PROJECTION": "安定投影",
    "SPLINE_MAPPING_APPROX": "スプライン風",
    "HAIR_CARDS_UV": "ヘアカードUV",
    "PACK_HEURISTIC": "高密度探索パック",
    "PACK_EXACT": "精密パック",
    "PACK_BBOX": "外接矩形パック",
    "PRIORITY_DENSITY_PACK": "密度優先パック",
    "GROUPS_TO_UDIM": "グループUDIM",
    "MATERIAL_TO_TILES": "材質別タイル",
    "OBJECT_TO_TILES": "オブジェクト別タイル",
    "LOCK_OVERLAP_PACK": "重なり保持パック",
    "STACK_SIMILAR": "類似スタック",
    "STACK_IDENTICAL": "同一スタック",
    "STACK_TOPOLOGY": "トポロジースタック",
    "UNSTACK": "スタック解除",
    "ORIENT_3D": "3D方向整列",
    "ORIENT_BBOX": "外接方向整列",
    "RANDOMIZE": "ランダム化",
    "EXPLODE": "分離表示",
    "ALIGN_PAD": "中央整列",
    "ALIGN_EDGE": "辺基準整列",
    "RECTIFY": "矩形化",
    "GRIDIFY": "グリッド化",
    "QUADRIFY": "四角形化",
    "SQUAREIFY": "正方形化",
    "IRON_FACES": "面アイロン",
    "UNITIZE": "ユニタイズ",
    "BOUNDARY_CIRCLE": "境界円形化",
    "BOUNDARY_QUAD": "境界四角化",
    "QUICK_SNAP": "精密スナップ",
    "TD_GET": "密度取得",
    "TD_SET": "密度適用",
    "TD_NORMALIZE": "密度正規化",
    "TD_WORLD_SCALE": "ワールドスケールUV",
    "CHECKER": "チェッカー",
    "STRETCH_HEATMAP": "歪みヒートマップ",
    "DISTORTION_SHADER": "歪み表示",
    "HISTOGRAM": "ヒストグラム",
    "INSPECT_SCAN": "検査",
    "SELECT_OVERLAP": "重なり選択",
    "SELECT_FLIPPED": "反転選択",
    "SELECT_ZERO": "ゼロ選択",
    "SELECT_UNMAPPED": "未展開選択",
    "SELECT_BACKFACING": "裏向き選択",
    "SELECT_SIMILAR": "類似選択",
    "SELECT_IDENTICAL": "同一選択",
    "SIMILARITY_SELECTOR": "類似判定",
    "FIX_ALL": "一括修復",
    "UV_MAP_ADD": "UV追加",
    "UV_MAP_DUP": "UV複製",
    "UV_MAP_RENAME": "UV改名",
    "UV_MAP_SYNC": "UVマップ同期",
    "ATLAS_BUILD": "アトラス作成",
    "ATLAS_BAKE": "アトラスベイク",
    "BAKE_PREP": "ベイク準備",
    "MULTI_OBJECT_BATCH": "複数オブジェクト一括",
    "RIZOM_BRIDGE": "Reference Layout互換",
    "HEADUS_BRIDGE": "Smart UV展開参照互換",
    "UVPACKMASTER_BRIDGE": "Smart UV高密度パック互換",
    "SMART_CHECKER_BRIDGE": "Smart UVレイアウト参照互換",
    "SMART_TEXTURE_BRIDGE": "Smart UV Suite reference互換",
    "SMART_PRECISION_BRIDGE": "Smart UV Precision互換",
    "SMART_SURFACE_BRIDGE": "Smart UV Suite互換",
    "HOUDINI_BRIDGE": "DCC Reference互換",
    "REPORT_MATRIX": "対応表を書き出し",
}


def _label(context, action: str) -> str:
    return _tr(context, _ACTION_LABELS.get(action, action), _ACTION_JA.get(action, _ACTION_LABELS.get(action, action)))


def _desc(context, action: str) -> str:
    en = _ACTION_DESC.get(action, 'Run this UV Suite Smart compatibility action.')
    ja = '添付リストの機能に最も近い UV Suite 内蔵互換ルートを実行します。'
    return _tr(context, en, ja)


def _groups_for_ui() -> list[dict[str, Any]]:
    return [
        {"key": "smart_uv_smart_supreme", "title_en": "Supreme Precision", "title_ja": "最高精度", "icon": "quality", "actions": ["SUPER_AUTO", "SUPER_SAFE_AUTO", "SUPER_UNWRAP", "SUPER_PACK", "SUPER_DENSITY", "SUPER_REPAIR", "SUPER_ANALYZE"]},
        {"key": "smart_uv_smart_auto", "title_en": "Auto / DCC One-click", "title_ja": "自動 / DCCワンクリック", "icon": "magic", "actions": ["FULL_AUTO", "AUTO_UV_SAFE", "UVMASTER_LOCAL", "MINISTRY_FLAT_LOCAL", "SUBSTANCE_AUTO_PREP", "UE_LIGHTMAP", "UNITY_PROBUILDER"]},
        {"key": "smart_uv_smart_unwrap", "title_en": "Seam / Unwrap / Projection", "title_ja": "シーム / 展開 / 投影", "icon": "unwrap", "actions": ["AUTO_SEAM_ANGLE", "AUTO_SEAM_SHARP", "AUTO_SEAM_MATERIAL", "CUT_SELECTED", "SEW_SELECTED", "STITCH_SELECTED", "UNWRAP_ABF", "UNWRAP_LSCM", "UNWRAP_SLIM", "OPTIMIZE_RELAX", "RELAX_PRESERVE", "PELT_UNWRAP", "SMART_PROJECT", "PROJECT_VIEW", "CUBE_PROJECT", "CYLINDER_PROJECT", "SPHERE_PROJECT", "STABLE_PROJECTION", "HAIR_CARDS_UV"]},
        {"key": "smart_uv_smart_pack", "title_en": "Pack / UDIM / Stack", "title_ja": "パック / UDIM / スタック", "icon": "pack", "actions": ["PACK_HEURISTIC", "PACK_EXACT", "PACK_BBOX", "PRIORITY_DENSITY_PACK", "GROUPS_TO_UDIM", "MATERIAL_TO_TILES", "OBJECT_TO_TILES", "LOCK_OVERLAP_PACK", "STACK_SIMILAR", "STACK_IDENTICAL", "STACK_TOPOLOGY", "UNSTACK", "ORIENT_3D", "ORIENT_BBOX", "RANDOMIZE", "EXPLODE"]},
        {"key": "smart_uv_smart_precision", "title_en": "Smart UV Suite reference / Precision Shape", "title_ja": "Smart UV Suite reference / 精密整形", "icon": "rectify", "actions": ["CROP", "FILL", "FIT", "ALIGN_PAD", "ALIGN_EDGE", "SORT_H", "SORT_V", "DISTRIBUTE_H", "DISTRIBUTE_V", "RECTIFY", "GRIDIFY", "QUADRIFY", "SQUAREIFY", "IRON_FACES", "UNITIZE", "BOUNDARY_CIRCLE", "BOUNDARY_QUAD", "QUICK_SNAP"]},
        {"key": "smart_uv_smart_density", "title_en": "Texel / Inspect / Repair", "title_ja": "密度 / 検査 / 修復", "icon": "density", "actions": ["TD_GET", "TD_SET", "TD_NORMALIZE", "TD_WORLD_SCALE", "CHECKER", "STRETCH_HEATMAP", "DISTORTION_SHADER", "HISTOGRAM", "INSPECT_SCAN", "SELECT_OVERLAP", "SELECT_FLIPPED", "SELECT_ZERO", "SELECT_UNMAPPED", "SELECT_BACKFACING", "SELECT_SIMILAR", "SELECT_IDENTICAL", "SIMILARITY_SELECTOR", "FIX_ALL"]},
        {"key": "smart_uv_smart_pipeline", "title_en": "Pipeline / External-equivalent Bridges", "title_ja": "パイプライン / 外部互換ブリッジ", "icon": "bridge", "actions": ["UV_MAP_ADD", "UV_MAP_DUP", "UV_MAP_RENAME", "UV_MAP_SYNC", "ATLAS_BUILD", "ATLAS_BAKE", "BAKE_PREP", "MULTI_OBJECT_BATCH", "RIZOM_BRIDGE", "HEADUS_BRIDGE", "UVPACKMASTER_BRIDGE", "SMART_CHECKER_BRIDGE", "SMART_TEXTURE_BRIDGE", "SMART_PRECISION_BRIDGE", "SMART_SURFACE_BRIDGE", "HOUDINI_BRIDGE", "REPORT_MATRIX"]},
    ]


def get_quick_groups() -> list[dict[str, Any]]:
    return _groups_for_ui()


def get_action_label(action: str, context=None) -> str:
    return _label(context, str(action or ""))


def get_action_description(action: str, context=None) -> str:
    return _desc(context, str(action or ""))


def document_feature_groups() -> list[dict[str, Any]]:
    entries = _feature_entries()
    grouped: dict[str, list[dict[str, Any]]] = {}
    for entry in entries:
        category = str(entry.get("category") or "Other")
        grouped.setdefault(category, []).append(entry)
    order = ["DCC", "Plugin", "Plugin/Add-on", "Reference Add-on", "Standalone UV", "Texture/Sculpt", "Blender Add-on", "Game Engine", "Other"]
    result = []
    for category in order + sorted(set(grouped) - set(order)):
        items = grouped.get(category) or []
        if not items:
            continue
        items.sort(key=lambda e: (str(e.get("tool") or ""), str(e.get("feature") or ""), str(e.get("key") or "")))
        result.append({"category": category, "items": items})
    return result




def _local_uv_map_action(action: str, context) -> bool:
    try:
        obj = getattr(context, "active_object", None)
        mesh = getattr(obj, "data", None) if obj is not None else None
        layers = getattr(mesh, "uv_layers", None) if mesh is not None else None
        if layers is None:
            return False
        action = str(action or "").upper()
        if action == "UV_MAP_ADD":
            name = "Smart UV Suite"
            try:
                ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
                name = str(getattr(ws, "uv_new_name", "Smart_UV_Suite") or "Smart_UV_Suite")
            except Exception:
                pass
            layers.new(name=name, do_init=True)
            return True
        if action == "UV_MAP_DUP":
            active = getattr(layers, "active", None)
            if active is None:
                layers.new(name="Smart_UV_Suite_Copy", do_init=True)
            else:
                new_name = f"{getattr(active, 'name', 'UVMap')}_Copy"
                layers.new(name=new_name, do_init=True)
            return True
        if action == "UV_MAP_RENAME":
            active = getattr(layers, "active", None)
            if active is None:
                return False
            name = "Smart UV Suite"
            try:
                ws = getattr(getattr(context, "scene", None), "suv_workspace", None)
                name = str(getattr(ws, "uv_new_name", "Smart_UV_Suite") or "Smart_UV_Suite")
            except Exception:
                pass
            try:
                active.name = name
                return True
            except Exception:
                return False
    except Exception:
        return False
    return False


def _local_report_or_uv_fallback(action: str, context) -> bool:
    action = str(action or "").upper().strip()
    if action in {"UV_MAP_ADD", "UV_MAP_DUP", "UV_MAP_RENAME"}:
        return _local_uv_map_action(action, context)
    return False

def _layout_route(action: str, context) -> bool:
    tex, margin, density = _workspace_values(context)
    common = {"scope": "SELECTED"}
    routes: dict[str, list[list[tuple[str, dict[str, Any]]]]] = {
        "FULL_AUTO": [[("uv.suv_auto_uv_profile", {"profile": "HARDSURFACE", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})], [("uv.suv_inspector_scan", {"scope": "ALL"})]],
        "AUTO_UV_SAFE": [[("uv.suv_auto_uv_profile", {"profile": "ORGANIC", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "UVMASTER_LOCAL": [[("uv.suv_auto_uv_profile", {"profile": "ZBRUSH_MASTER", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "MINISTRY_FLAT_LOCAL": [[("uv.suv_auto_uv_profile", {"profile": "DCC_REFERENCE_MOF", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "SUBSTANCE_AUTO_PREP": [[("uv.suv_auto_uv_profile", {"profile": "SUBSTANCE_AUTO", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "UE_LIGHTMAP": [[("uv.suv_auto_uv_profile", {"profile": "UNREAL_LIGHTMAP", "apply_density": False, "texture_size": tex, "margin_px": margin}), ("uv.suv_native_projection", {"mode": "LIGHTMAP", "pack_after": True})]],
        "UNITY_PROBUILDER": [[("uv.suv_auto_uv_profile", {"profile": "UNITY_PROBUILDER", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "AUTO_SEAM_ANGLE": [[("uv.suv_auto_seam_advanced", {"mode": "ANGLE", "angle_threshold": math.radians(55.0), "scope": "ALL"})]],
        "AUTO_SEAM_SHARP": [[("uv.suv_auto_seam_advanced", {"mode": "SHARP", "scope": "ALL"})]],
        "AUTO_SEAM_MATERIAL": [[("uv.suv_auto_seam_advanced", {"mode": "MATERIAL", "scope": "ALL"})]],
        "CUT_SELECTED": [[("uv.suv_native_uv_action", {"mode": "MARK_SEAM"}), ("mesh.mark_seam", {"clear": False})]],
        "SEW_SELECTED": [[("uv.suv_native_uv_action", {"mode": "CLEAR_SEAM"}), ("mesh.mark_seam", {"clear": True})]],
        "STITCH_SELECTED": [[("uv.suv_native_uv_action", {"mode": "STITCH"}), ("uv.stitch", {})]],
        "UNWRAP_ABF": [[("uv.suv_native_projection", {"mode": "UNWRAP_ABF", "relax_after": False, "pack_after": False, "apply_density": False}), ("uv.unwrap", {"method": "ANGLE_BASED", "margin": max(0.001, margin / tex)})]],
        "UNWRAP_LSCM": [[("uv.suv_native_projection", {"mode": "UNWRAP_LSCM", "relax_after": False, "pack_after": False, "apply_density": False}), ("uv.unwrap", {"method": "CONFORMAL", "margin": max(0.001, margin / tex)})]],
        "UNWRAP_SLIM": [[("uv.suv_native_projection", {"mode": "MIN_STRETCH", "pack_after": False, "apply_density": False}), ("uv.minimize_stretch", {"iterations": 32}), ("uv.unwrap", {"method": "ANGLE_BASED"})]],
        "OPTIMIZE_RELAX": [[("uv.suv_cleanup_bridge", {"mode": "OPTIMIZE_REALTIME", "iterations": 48}), ("uv.minimize_stretch", {"iterations": 32})]],
        "RELAX_PRESERVE": [[("uv.suv_constraint_relax_preserve", {"iterations": 64, "pack_after": False}), ("uv.minimize_stretch", {"iterations": 32})]],
        "PELT_UNWRAP": [[("uv.suv_projection_bridge", {"mode": "PEEL", "pack_after": False}), ("uv.suv_auto_uv_profile", {"profile": "MAX_PEEL_RELAX", "apply_density": False, "texture_size": tex, "margin_px": margin})]],
        "LIVE_UNWRAP_TOGGLE": [[("suv.toggle_live_unwrap", {})]],
        "PIN": [[("uv.suv_native_uv_action", {"mode": "PIN"}), ("uv.pin", {"clear": False})]],
        "UNPIN": [[("uv.suv_native_uv_action", {"mode": "UNPIN"}), ("uv.pin", {"clear": True})]],
        "CLEAR_PINS": [[("uv.suv_clear_pins", {}), ("uv.pin", {"clear": True})]],
        "SMART_PROJECT": [[("uv.suv_native_projection", {"mode": "SMART_PROJECT", "angle_limit": math.radians(66.0), "island_margin": max(0.001, margin / tex)}), ("uv.smart_project", {"angle_limit": math.radians(66.0), "island_margin": max(0.001, margin / tex)})]],
        "LIGHTMAP_PACK": [[("uv.suv_native_projection", {"mode": "LIGHTMAP", "pack_after": True}), ("uv.lightmap_pack", {"PREF_MARGIN_DIV": max(0.001, margin / tex)})]],
        "PROJECT_VIEW": [[("uv.suv_native_projection", {"mode": "VIEW"}), ("uv.project_from_view", {"scale_to_bounds": False})]],
        "PROJECT_VIEW_BOUNDS": [[("uv.suv_native_projection", {"mode": "VIEW_BOUNDS"}), ("uv.project_from_view", {"scale_to_bounds": True})]],
        "CUBE_PROJECT": [[("uv.suv_native_projection", {"mode": "CUBE"}), ("uv.cube_project", {"cube_size": 1.0})]],
        "CYLINDER_PROJECT": [[("uv.suv_native_projection", {"mode": "CYLINDER"}), ("uv.cylinder_project", {})]],
        "SPHERE_PROJECT": [[("uv.suv_native_projection", {"mode": "SPHERE"}), ("uv.sphere_project", {})]],
        "PLANAR_NORMAL": [[("uv.suv_projection_bridge", {"mode": "NORMAL_PROJECT"}), ("smart_uv_suite.native_hub_action", {}), ("uv.project_from_view", {"scale_to_bounds": True})]],
        "STABLE_PROJECTION": [[("uv.suv_auto_uv_profile", {"profile": "UVFACTORY_PROCEDURAL", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin}), ("uv.suv_projection_bridge", {"mode": "STABLE_PROJECTION"})]],
        "SPLINE_MAPPING_APPROX": [[("uv.suv_auto_uv_profile", {"profile": "MAX_PEEL_RELAX", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "HAIR_CARDS_UV": [[("uv.suv_auto_uv_profile", {"profile": "HAIR_CARD_LAYOUT", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin})]],
        "PACK_HEURISTIC": [[("uv.suv_pack_pro", {"engine": "DETERMINISTIC", "scope": "SELECTED", "udim_mode": "SINGLE", "margin_px": margin, "texture_size": tex, "rotation_step": "15", "group_mode": "SIMILAR"}), ("uv.pack_islands", {"margin": max(0.001, margin / tex)})]],
        "PACK_EXACT": [[("uv.suv_pack_pro", {"engine": "DETERMINISTIC", "shape_method": "EXACT", "scope": "SELECTED", "udim_mode": "SINGLE", "margin_px": margin, "texture_size": tex})]],
        "PACK_BBOX": [[("uv.suv_pack_pro", {"engine": "DETERMINISTIC", "shape_method": "BBOX", "scope": "SELECTED", "udim_mode": "SINGLE", "margin_px": margin, "texture_size": tex})]],
        "PRIORITY_DENSITY_PACK": [[("uv.suv_priority_density_pack", {"texture_size": tex, "margin_px": margin, "target_density": density, "scope": "SELECTED"}), ("uv.suv_pack_pro", {"margin_px": margin, "texture_size": tex})]],
        "GROUPS_TO_UDIM": [[("uv.suv_groups_to_tiles", {"mode": "SIMILAR", "scope": "SELECTED", "texture_size": tex, "margin_px": margin}), ("uv.suv_auto_uv_profile", {"profile": "UDIM", "texture_size": tex, "margin_px": margin})]],
        "MATERIAL_TO_TILES": [[("uv.suv_groups_to_tiles", {"mode": "MATERIAL", "scope": "SELECTED", "texture_size": tex, "margin_px": margin})]],
        "OBJECT_TO_TILES": [[("uv.suv_batch_object_to_udim_tiles", {"texture_size": tex, "margin_px": margin}), ("uv.suv_auto_uv_profile", {"profile": "UDIM", "texture_size": tex, "margin_px": margin})]],
        "LOCK_OVERLAP_PACK": [[("uv.suv_pack_pro", {"lock_pinned": True, "lock_overlapping": True, "scope": "SELECTED", "margin_px": margin, "texture_size": tex})]],
        "STACK_SIMILAR": [[("uv.suv_stack_grouped", {"mode": "SIMILAR"}), ("uv.suv_stack_pro", {"mode": "SIMILAR"}), ("smart_uv_suite.native_hub_action", {})]],
        "STACK_IDENTICAL": [[("uv.suv_stack_grouped", {"mode": "IDENTICAL"}), ("uv.suv_stack_pro", {"mode": "IDENTICAL"})]],
        "STACK_TOPOLOGY": [[("uv.suv_stack_topology_groups", {}), ("uv.suv_stack_symmetry_topology", {})]],
        "UNSTACK": [[("uv.suv_unstack_groups", {}), ("uv.suv_unstack_overlapped", {})]],
        "ORIENT_3D": [[("uv.suv_orient_groups_advanced", {"target_mode": "NEAREST_WORLD", "scope": "SELECTED"}), ("uv.suv_orient_islands", {"mode": "WORLD", "scope": "SELECTED"})]],
        "ORIENT_BBOX": [[("uv.suv_orient_islands", {"mode": "MIN_BBOX", "step_deg": 15, "scope": "SELECTED"})]],
        "RANDOMIZE": [[("uv.suv_randomize_islands", {"scope": "SELECTED"}), ("smart_uv_suite.native_hub_action", {})]],
        "EXPLODE": [[("uv.suv_explode_islands", {"scope": "SELECTED", "gap_px": margin, "texture_size": tex})]],
        "CROP": [[("uv.suv_crop_tile", {"padding_px": margin, "texture_size": tex, "keep_tile": True, **common}), ("smart_uv_suite.native_hub_action", {})]],
        "FILL": [[("uv.suv_fill_tile", {"padding_px": margin, "texture_size": tex, "keep_tile": True, **common}), ("smart_uv_suite.native_hub_action", {})]],
        "FIT": [[("uv.suv_fit_to_bounds", {"padding_px": margin, "texture_size": tex, "keep_tile": True, **common}), ("smart_uv_suite.native_hub_action", {})]],
        "ALIGN_PAD": [[("uv.suv_centralize_islands", common), ("smart_uv_suite.uv_layout_action", {"action": "ALIGN_CENTER"})]],
        "ALIGN_EDGE": [[("uv.suv_orient_to_edge", common), ("smart_uv_suite.native_hub_action", {}), ("smart_uv_suite.native_hub_action", {})]],
        "SORT_H": [[("uv.suv_sort_islands", {"axis": "H", "gap_px": margin, "texture_size": tex, **common})]],
        "SORT_V": [[("uv.suv_sort_islands", {"axis": "V", "gap_px": margin, "texture_size": tex, **common})]],
        "DISTRIBUTE_H": [[("uv.suv_distribute_islands", {"axis": "H", "auto_gap": True, "texture_size": tex, **common})]],
        "DISTRIBUTE_V": [[("uv.suv_distribute_islands", {"axis": "V", "auto_gap": True, "texture_size": tex, **common})]],
        "RECTIFY": [[("uv.suv_hs_rectify_fit", {"scope": "SELECTED", "padding_px": margin, "texture_size": tex, "keep_tile": True}), ("smart_uv_suite.native_hub_action", {}), ("smart_uv_suite.native_hub_action", {})]],
        "GRIDIFY": [[("uv.suv_hs_gridify", {}), ("smart_uv_suite.native_hub_action", {}), ("smart_uv_suite.native_hub_action", {})]],
        "QUADRIFY": [[("uv.suv_hs_quad_flow", {"fit_after": True}), ("smart_uv_suite.native_hub_action", {}), ("smart_uv_suite.native_hub_action", {})]],
        "SQUAREIFY": [[("uv.suv_hs_squareify", {}), ("uv.suv_hs_rectify_fit", {"scope": "SELECTED"})]],
        "IRON_FACES": [[("uv.suv_hs_orthogonalize", {}), ("uv.suv_hs_rectify_fit", {"scope": "SELECTED"}), ("uv.suv_hs_quad_flow", {"fit_after": True})]],
        "UNITIZE": [[("suv.face_unitize", {}), ("uv.suv_native_uv_action", {"mode": "UNITIZE"})]],
        "BOUNDARY_CIRCLE": [[("suv.boundary_to_shape", {"shape": "CIRCLE"}), ("smart_uv_suite.native_hub_action", {})]],
        "BOUNDARY_QUAD": [[("suv.boundary_to_shape", {"shape": "QUAD"}), ("uv.suv_hs_rectify_fit", {"scope": "SELECTED"})]],
        "QUICK_SNAP": [[("smart_uv_suite.native_hub_action", {}), ("smart_uv_suite.native_hub_action", {}), ("uv.suv_orient_to_edge", {})]],
        "TD_GET": [[("uv.suv_texel_get", {"scope": "SELECTED", "texture_size": tex})]],
        "TD_SET": [[("uv.suv_texel_set", {"scope": "SELECTED", "target_density": density, "texture_size": tex})]],
        "TD_NORMALIZE": [[("uv.suv_texel_normalize", {"value_density": density, "texture_size": tex})]],
        "TD_WORLD_SCALE": [[("uv.suv_auto_uv_profile", {"profile": "SMART_SURFACE_SURFACE", "apply_density": True, "target_density": density, "texture_size": tex, "margin_px": margin}), ("smart_uv_suite.native_hub_action", {})]],
        "CHECKER": [[("object.suv_create_checker_material", {})]],
        "STRETCH_HEATMAP": [[("object.suv_visualize_stretch_heatmap", {}), ("uv.suv_inspector_scan", {"check_stretch": True})]],
        "DISTORTION_SHADER": [[("object.suv_visualize_stretch_heatmap", {}), ("uv.suv_inspector_scan", {"check_stretch": True})]],
        "HISTOGRAM": [[("uv.suv_histogram_tools", {}), ("uv.suv_issue_audit_tools", {})]],
        "INSPECT_SCAN": [[("uv.suv_inspector_scan", {"scope": "ALL", "check_overlap": True, "check_stretch": True, "check_out_of_tile": True})]],
        "SELECT_OVERLAP": [[("uv.suv_inspector_select", {"issue": "OVERLAP", "auto_scan": True, "apply_mode": "REPLACE"}), ("smart_uv_suite.native_hub_action", {})]],
        "SELECT_FLIPPED": [[("uv.suv_inspector_select", {"issue": "FLIPPED", "auto_scan": True, "apply_mode": "REPLACE"}), ("smart_uv_suite.native_hub_action", {})]],
        "SELECT_ZERO": [[("uv.suv_select_zero_islands", {}), ("smart_uv_suite.native_hub_action", {})]],
        "SELECT_UNMAPPED": [[("uv.suv_select_fragmented_islands", {}), ("uv.suv_inspector_select", {"issue": "UNMAPPED", "auto_scan": True})]],
        "SELECT_BACKFACING": [[("uv.suv_inspector_select", {"issue": "FLIPPED", "auto_scan": True}), ("smart_uv_suite.native_hub_action", {})]],
        "SELECT_SIMILAR": [[("uv.suv_select_similar_islands", {}), ("smart_uv_suite.native_hub_action", {}), ("smart_uv_suite.native_hub_action", {})]],
        "SELECT_IDENTICAL": [[("uv.suv_select_identical_islands", {}), ("smart_uv_suite.native_hub_action", {})]],
        "SIMILARITY_SELECTOR": [[("uv.suv_similarity_bridge", {}), ("uv.suv_select_similar_islands", {})]],
        "FIX_ALL": [[("uv.suv_fix_all_issues", {}), ("uv.suv_layout_autoheal", {})]],
        "UV_MAP_ADD": [[("mesh.suv_uvmap_add", {})]],
        "UV_MAP_DUP": [[("mesh.suv_uvmap_duplicate", {})]],
        "UV_MAP_RENAME": [[("mesh.suv_uvmap_rename_active", {})]],
        "UV_MAP_SYNC": [[("mesh.suv_native_stage_uvmap", {}), ("smart_uv_suite.native_hub_action", {})]],
        "ATLAS_BUILD": [[("uv.suv_atlas_build_uv_multi", {})]],
        "ATLAS_BAKE": [[("uv.suv_atlas_run_all_multi", {}), ("uv.suv_atlas_bake_multi", {})]],
        "BAKE_PREP": [[("mesh.suv_bake_uv_prep", {}), ("object.suv_native_stage_bake", {})]],
        "MULTI_OBJECT_BATCH": [[("uv.suv_batch_layout_profile", {"profile": "RIZOM_QUALITY", "target_mode": "SELECTED", "texture_size": tex, "margin_px": margin}), ("uv.suv_batch_object_to_udim_tiles", {"texture_size": tex, "margin_px": margin})]],
    }
    bridge_targets = {
        "RIZOM_BRIDGE": "DCC_LAYOUT_REFERENCE",
        "HEADUS_BRIDGE": "HEADUS",
        "UVPACKMASTER_BRIDGE": "UVPACKMASTER",
        "SMART_CHECKER_BRIDGE": "SMART_CHECKER",
        "SMART_TEXTURE_BRIDGE": "SMART_TEXTURE",
        "SMART_PRECISION_BRIDGE": "SMART_PRECISION",
        "SMART_SURFACE_BRIDGE": "SMART_SURFACE",
        "HOUDINI_BRIDGE": "HOUDINI",
    }
    if action in bridge_targets:
        return _target_action(bridge_targets[action], context)
    groups = routes.get(action)
    if not groups:
        return False
    return _run_all(groups, require_each=False)


def _precision_enhance_action(action: str, context) -> bool:
    # Excellence Engine gets the first chance for high-value production routes.
    # It writes measurable quality reports and then falls back to the existing
    # Precision Engine if the action is outside its route map.
    try:
        from . import smart_uv_excellence as _excellence
        enhance = getattr(_excellence, "enhance_action", None)
        if callable(enhance) and enhance(action, context):
            return True
    except Exception:
        pass
    try:
        from . import smart_uv_precision as _precision
        enhance = getattr(_precision, "enhance_action", None)
        if callable(enhance):
            return bool(enhance(action, context))
    except Exception:
        return False
    return False


def run_action(action: str, context) -> bool:
    action = str(action or "").strip().upper()
    if action == "REPORT_MATRIX":
        return write_matrix(context)
    _ensure_mesh_context(context)
    precision_first = {
        "SUPER_AUTO", "SUPER_SAFE_AUTO", "SUPER_UNWRAP", "SUPER_PACK", "SUPER_DENSITY", "SUPER_REPAIR", "SUPER_ANALYZE",
        "FULL_AUTO", "AUTO_UV_SAFE", "UVMASTER_LOCAL", "MINISTRY_FLAT_LOCAL", "SUBSTANCE_AUTO_PREP",
        "UNWRAP_SLIM", "OPTIMIZE_RELAX", "PACK_HEURISTIC", "PACK_EXACT", "PACK_BBOX", "PRIORITY_DENSITY_PACK",
        "LOCK_OVERLAP_PACK", "TD_WORLD_SCALE", "FIX_ALL", "INSPECT_SCAN", "STRETCH_HEATMAP", "DISTORTION_SHADER",
        "UVPACKMASTER_BRIDGE", "RIZOM_BRIDGE", "HEADUS_BRIDGE",
    }
    if action in precision_first and _precision_enhance_action(action, context):
        return True
    if action in {"TD_GET", "TD_SET", "TD_NORMALIZE"}:
        if _precision_enhance_action(action, context):
            return True
        return _texel({"TD_GET": "GET", "TD_NORMALIZE": "NORMALIZE"}.get(action, "SET"), context)
    ok = _layout_route(action, context)
    if ok:
        return True
    if _precision_enhance_action(action, context):
        return True
    return _local_report_or_uv_fallback(action, context)


def run_feature(feature_key: str, context) -> bool:
    entry = find_feature(feature_key)
    if not entry:
        return False
    _ensure_mesh_context(context)
    if entry.get("native"):
        # 同梱の native action は、その action だけを実行する（語の一致で別の精密ルートへ流さない）
        for action in list(entry.get("actions") or []):
            op_id = str(action.get("idname") or "").strip()
            if op_id and _call_operator(op_id, **dict(action.get("kwargs") or {})):
                return True
        return False
    try:
        from . import smart_uv_precision as _precision
        enhance_feature = getattr(_precision, "enhance_feature", None)
        if callable(enhance_feature) and enhance_feature(entry, context):
            return True
    except Exception:
        pass
    for action in list(entry.get("actions") or []):
        if not isinstance(action, dict):
            continue
        if str(action.get("type") or "operator") != "operator":
            continue
        op_id = str(action.get("idname") or "").strip()
        kwargs = dict(action.get("kwargs") or {})
        if op_id and _call_operator(op_id, **kwargs):
            return True
    for target in list(entry.get("compat_targets") or []):
        if _target_action(str(target or ""), context):
            return True
    tool = str(entry.get("tool") or "").upper().replace(" ", "_").replace("/", "_").replace("-", "_")
    for target, profile in _PROFILE_BY_TARGET.items():
        if target in tool:
            return _profile_action(profile, context)
    return False


def _matrix_payload(entries: list[dict[str, Any]], context=None) -> dict[str, Any]:
    tools = _document_tools()
    targets = _target_entries()
    precision_metrics = {}
    try:
        from . import smart_uv_precision as _precision
        collect = getattr(_precision, "collect_metrics", None)
        if callable(collect):
            precision_metrics = collect(context)
    except Exception:
        precision_metrics = {}
    categories: dict[str, int] = {}
    for entry in entries:
        category = str(entry.get("category") or "Other")
        categories[category] = categories.get(category, 0) + 1
    return {
        "schema": "smart_uv_smart_coverage_matrix_v2",
        "addon": 'Smart UV',
        "module": 'UV Suite Smart',
        "precision_engine": 'UV Suite Precision Engine',
        "precision_metrics": precision_metrics,
        "feature_entries": len(entries),
        "document_tools": len(tools),
        "compat_targets": len(targets),
        "categories": categories,
        "tools": tools,
        "features": entries,
    }


def write_matrix(context=None, report=None) -> bool:
    entries = _feature_entries()
    if not entries:
        if report is not None:
            report({"WARNING"}, _tr(context,
                "The UV feature reference data is missing, unreadable, or empty. The coverage matrix was not written.",
                "UV機能の参照データがないか、読み込めないか、空です。対応マトリクスは書き出されませんでした。"))
        return False
    payload = _matrix_payload(entries, context)
    try:
        from . import storage
        path = Path(storage.runtime_file("smart_uv_smart_coverage_matrix.json", "reports", create=True))
    except Exception:
        path = (Path(os.environ.get('APPDATA')) / 'Blender Foundation' / 'Blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / 'smart_uv_smart_coverage_matrix.json') if os.environ.get('APPDATA') else (Path.home() / '.config' / 'blender' / '5.1' / 'config' / 'Smart_UV_Suite' / 'user_data' / 'runtime' / 'reports' / 'smart_uv_smart_coverage_matrix.json')
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            text = bpy.data.texts.get("Smart_UV_Suite_Smart_Coverage_Matrix") or bpy.data.texts.new("Smart_UV_Suite_Smart_Coverage_Matrix")
            text.clear()
            text.write(json.dumps({k: payload[k] for k in ("schema", "feature_entries", "document_tools", "compat_targets", "categories")}, ensure_ascii=False, indent=2))
        except Exception:
            pass
        return True
    except Exception:
        if report is not None:
            report({"WARNING"}, _tr(context,
                'Could not write the UV Suite Smart coverage matrix.',
                'UV Suite Smart対応マトリクスを書き出せませんでした。'))
        return False


def _execute_matrix(context, report):
    if not write_matrix(context, report):
        return {"CANCELLED"}
    report({"INFO"}, _tr(context,
        'UV Suite Smart coverage matrix written.', 'UV Suite Smart対応マトリクスを書き出しました。'))
    return {"FINISHED"}


class SMARTUVSMART_OT_action(bpy.types.Operator):
    bl_idname = "smart_uv_suite.smart_uv_smart_action"
    bl_label = 'Smart Action'
    bl_description = 'Run an upgraded UV Suite Smart compatibility action based on the attached UV feature research list.'
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(name="Action", items=_ACTION_ITEMS, default="FULL_AUTO", options={"SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):  # type: ignore[override]
        action = str(getattr(properties, "action", "") or "")
        return _desc(context, action)

    def execute(self, context):
        action = str(getattr(self, "action", "") or "").strip().upper()
        if action == "REPORT_MATRIX":
            return _execute_matrix(context, self.report)
        ok = run_action(action, context)
        if ok:
            self.report({"INFO"}, _tr(context, f"UV Suite Smart: {_ACTION_LABELS.get(action, action)}", f"UV Suite Smart: {_ACTION_JA.get(action, action)}"))
            return {"FINISHED"}
        self.report({"WARNING"}, _tr(context, 'UV Suite Smart route could not complete. Check mesh selection, edit mode, and available UV Suite runtime operators.', 'UV Suite Smart ルートを完了できませんでした。メッシュ選択、編集モード、UV Suiteランタイムの読み込み状態を確認してください。'))
        return {"CANCELLED"}


class SMARTUVSMART_OT_feature(bpy.types.Operator):
    bl_idname = "smart_uv_suite.smart_uv_smart_feature"
    bl_label = 'Smart Feature'
    bl_description = 'Run the closest UV Suite upper-compatible route for one feature from the attached UV research list.'
    bl_options = {'UNDO'}

    feature_key: bpy.props.StringProperty(name="Feature Key", default="", options={"HIDDEN", "SKIP_SAVE"})
    label_en: bpy.props.StringProperty(name="Label EN", default="", options={"HIDDEN", "SKIP_SAVE"})
    label_ja: bpy.props.StringProperty(name="Label JA", default="", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):  # type: ignore[override]
        key = str(getattr(properties, "feature_key", "") or "")
        entry = find_feature(key) if key else None
        if entry:
            tool = str(entry.get("tool") or "")
            feat = str(entry.get("feature") or key)
            detail_en = str(entry.get("detail_en") or entry.get("detail") or 'Run the mapped UV Suite route for this researched UV feature.')
            detail_ja = str(entry.get("detail_ja") or 'この調査済みUV機能に最も近いUV Suite互換ルートを実行します。')
            return _tr(context, f"{feat} — {tool}\nFunction: {detail_en}\nUsage: Click to run the closest built-in UV Suite Smart route.", f"{feat} — {tool}\n機能: {detail_ja}\n使い方: クリックすると、最も近い内蔵UV Suite Smartルートを実行します。")
        return _tr(context, 'Run one documented UV feature through UV Suite Smart.', '文書化されたUV機能をUV Suite Smartで実行します。')

    def execute(self, context):
        key = str(getattr(self, "feature_key", "") or "").strip()
        if not key:
            self.report({"WARNING"}, _tr(context, "No document feature key was provided.", "文書機能キーが指定されていません。"))
            return {"CANCELLED"}
        ok = run_feature(key, context)
        if ok:
            label = str(getattr(self, "label_ja" if _is_ja(context) else "label_en", "") or key)
            self.report({"INFO"}, _tr(context, f"UV Suite Smart feature launched: {label}", f"UV Suite Smart機能を起動しました: {label}"))
            return {"FINISHED"}
        self.report({"WARNING"}, _tr(context, "No executable route completed for this documented feature.", "この文書機能に対して完了できる実行ルートがありませんでした。"))
        return {"CANCELLED"}


class SMARTUVSMART_OT_tool(bpy.types.Operator):
    bl_idname = "smart_uv_suite.smart_uv_smart_tool"
    bl_label = 'Smart Tool Route'
    bl_description = 'Run the closest upper-compatible UV Suite route for one documented external UV tool family.'
    bl_options = {'UNDO'}

    target: bpy.props.StringProperty(name="Target", default="", options={"HIDDEN", "SKIP_SAVE"})
    label_en: bpy.props.StringProperty(name="Label EN", default="", options={"HIDDEN", "SKIP_SAVE"})
    label_ja: bpy.props.StringProperty(name="Label JA", default="", options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):  # type: ignore[override]
        label_en = str(getattr(properties, "label_en", "") or getattr(properties, "target", "") or "Tool")
        label_ja = str(getattr(properties, "label_ja", "") or label_en)
        target = str(getattr(properties, "target", "") or "")
        return _tr(context, f"Run the UV Suite Smart route for {label_en}. Target: {target}.", f"{label_ja}向けのUV Suite Smartルートを実行します。ターゲット: {target}。")

    def execute(self, context):
        target = str(getattr(self, "target", "") or "").strip().upper()
        if not target:
            self.report({"WARNING"}, _tr(context, "No target was provided.", "ターゲットが指定されていません。"))
            return {"CANCELLED"}
        if _target_action(target, context):
            label = str(getattr(self, "label_ja" if _is_ja(context) else "label_en", "") or target)
            self.report({"INFO"}, _tr(context, f"UV Suite Smart tool route launched: {label}", f"UV Suite Smartツールルートを起動しました: {label}"))
            return {"FINISHED"}
        self.report({"WARNING"}, _tr(context, "Tool route could not complete.", "ツールルートを完了できませんでした。"))
        return {"CANCELLED"}


class SMARTUVSMART_OT_write_matrix(bpy.types.Operator):
    bl_idname = "smart_uv_suite.smart_uv_smart_write_matrix"
    bl_label = 'Write Smart Matrix'
    bl_description = 'Write the full UV Suite Smart feature coverage matrix into CONFIG/Smart_UV_Suite/reports.'
    bl_options = set()

    def execute(self, context):
        return _execute_matrix(context, self.report)


_CLASSES = (
    SMARTUVSMART_OT_action,
    SMARTUVSMART_OT_feature,
    SMARTUVSMART_OT_tool,
    SMARTUVSMART_OT_write_matrix,
)

_REGISTERED: list[type] = []


def register() -> None:
    try:
        from . import smart_uv_excellence as _excellence
        register_excellence = getattr(_excellence, "register", None)
        if callable(register_excellence):
            register_excellence()
    except Exception:
        pass
    try:
        from . import smart_uv_precision as _precision
        register_precision = getattr(_precision, "register", None)
        if callable(register_precision):
            register_precision()
    except Exception:
        pass
    try:
        from .bootstrap_common import safe_register_class
    except Exception:
        safe_register_class = None
    for cls in _CLASSES:
        ok = False
        if callable(safe_register_class):
            try:
                ok = bool(safe_register_class(cls))
            except Exception:
                ok = False
        if not ok:
            try:
                _suv_resource.register_class(cls)
                ok = True
            except Exception:
                ok = False
        if ok and cls not in _REGISTERED:
            _REGISTERED.append(cls)


def unregister() -> None:
    for cls in reversed(_REGISTERED or list(_CLASSES)):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()
    try:
        from . import smart_uv_precision as _precision
        unregister_precision = getattr(_precision, "unregister", None)
        if callable(unregister_precision):
            unregister_precision()
    except Exception:
        pass
    try:
        from . import smart_uv_excellence as _excellence
        unregister_excellence = getattr(_excellence, "unregister", None)
        if callable(unregister_excellence):
            unregister_excellence()
    except Exception:
        pass


__all__ = [
    "register",
    "unregister",
    "get_quick_groups",
    "get_action_label",
    "get_action_description",
    "document_feature_groups",
    "operator_exists",
    "_precision_enhance_action",
]
