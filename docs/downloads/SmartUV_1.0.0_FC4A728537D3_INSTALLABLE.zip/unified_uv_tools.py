# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""JELararagi native integrated UV operators.

This module replaces load-on-demand third-party UV tool folders with direct
Smart UV Suite operators.  It intentionally does not import or register the
reference add-ons.  The operators below implement common UV operations with
Blender's own API and small in-package helpers, then expose them only through
``smart_uv_suite.*`` IDs so the N-panel remains a single Smart UV Suite surface.
"""

from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .text_translation import materialize_class_property_annotations

import math
import random
import re
from dataclasses import dataclass
from typing import Any, Callable, Iterable

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty
from mathutils import Vector

_REGISTERED: list[type] = []
_DYNAMIC_CLASSES: list[type] = []
_UV_COPY_BUFFER: list[tuple[float, float]] = []
_LAST_DENSITY: float = 1.0

# These operators have dedicated implementations in the package registration
# chain.  Registering catalog fallbacks first gives two Python classes the same
# Blender operator identifier and makes enable/disable nondeterministic.
_DEDICATED_OVERRIDE_IDS = frozenset({
    'smart_uv_suite.align_edges',
    'smart_uv_suite.inspect_orient_world',
    'smart_uv_suite.seam_rectify',
    'smart_uv_suite.align_uv_circle',
    'smart_uv_suite.align_normalize',
    'smart_uv_suite.align_relax',
})

_LEGACY_SOURCE_ROOTS: frozenset[str] = frozenset()


def _is_ja(context=None) -> bool:
    try:
        view = getattr(getattr(context or bpy.context, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        lang = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or lang).lower()
        return raw.startswith('ja') or raw == 'default_japanese'
    except Exception:
        return False


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _message(context, operator, en: str, ja: str, level: str = 'INFO') -> None:
    try:
        operator.report({level}, _t(context, en, ja))
    except Exception:
        pass


def _safe_op_exists(op_idname: str) -> bool:
    text = str(op_idname or '').strip()
    if '.' not in text:
        return False
    head, tail = text.split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, head), tail)
        rna = op.get_rna_type()
        ident = str(getattr(rna, 'identifier', '') or '')
        return bool(ident) and ident not in {'Operator', 'OperatorProperties', 'UnknownType', 'bpy_struct'}
    except Exception:
        return False


def _safe_call(op_idname: str, *args, **kwargs) -> bool:
    text = str(op_idname or '').strip()
    if '.' not in text:
        return False
    if not _safe_op_exists(text):
        return False
    head, tail = text.split('.', 1)
    try:
        op = getattr(getattr(bpy.ops, head), tail)
    except Exception:
        return False
    attempts = []
    if args:
        attempts.append((args, kwargs))
    attempts.append((('EXEC_DEFAULT',), kwargs))
    attempts.append((tuple(), kwargs))
    attempts.append((('EXEC_DEFAULT',), {}))
    attempts.append((tuple(), {}))
    for a, kw in attempts:
        try:
            result = op(*a, **kw)
            if isinstance(result, set):
                return 'FINISHED' in result or not ('CANCELLED' in result)
            return True
        except Exception:
            continue
    return False


def _mesh_object(context=None):
    ctx = context or bpy.context
    obj = getattr(ctx, 'edit_object', None) or getattr(ctx, 'active_object', None) or getattr(ctx, 'object', None)
    if obj is not None and getattr(obj, 'type', '') == 'MESH':
        return obj
    try:
        for candidate in getattr(ctx, 'selected_objects', ()) or ():
            if getattr(candidate, 'type', '') == 'MESH':
                return candidate
    except Exception:
        pass
    return None


@dataclass
class _UVState:
    obj: Any
    bm: Any
    uv_layer: Any
    loops: list[Any]
    faces: list[Any]
    mode_switched: bool = False


def _ensure_edit_uv_state(context=None, *, all_if_empty: bool = True) -> _UVState | None:
    obj = _mesh_object(context)
    if obj is None:
        return None
    mode_switched = False
    try:
        if getattr(obj, 'mode', '') != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='EDIT')
                mode_switched = True
            except Exception:
                return None
        import bmesh
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            uv_layer = bm.loops.layers.uv.verify()
        try:
            bm.faces.ensure_lookup_table()
        except Exception:
            pass
        loops = []
        faces = []
        try:
            uv_sync = bool(bpy.context.scene.tool_settings.use_uv_select_sync)
        except Exception:
            uv_sync = True
        for face in bm.faces:
            if getattr(face, 'hide', False):
                continue
            if uv_sync:
                selected_loops = [
                    loop for loop in face.loops
                    if face.select or loop.vert.select or loop.edge.select
                ]
            else:
                selected_loops = [
                    loop for loop in face.loops
                    if face.select and (loop.uv_select_vert or loop.uv_select_edge)
                ]
            if selected_loops:
                faces.append(face)
                loops.extend(selected_loops)
        if all_if_empty and not loops:
            for face in bm.faces:
                faces.append(face)
                loops.extend(list(face.loops))
        return _UVState(obj=obj, bm=bm, uv_layer=uv_layer, loops=loops, faces=faces, mode_switched=mode_switched)
    except Exception:
        return None


def _finish_state(state: _UVState | None, *, restore_mode: bool = False) -> None:
    if state is None:
        return
    try:
        import bmesh
        bmesh.update_edit_mesh(state.obj.data, loop_triangles=False, destructive=False)
    except Exception:
        try:
            state.obj.data.update()
        except Exception:
            pass
    if restore_mode and state.mode_switched:
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass



def _uv_sticky_select_mode(context=None) -> str:
    try:
        ctx = context or bpy.context
        tool_settings = getattr(ctx, 'tool_settings', None) or getattr(getattr(ctx, 'scene', None), 'tool_settings', None)
        mode = str(getattr(tool_settings, 'uv_sticky_select_mode', 'DISABLED') or 'DISABLED').upper()
    except Exception:
        mode = 'DISABLED'
    return {'SAME_LOCATION': 'SHARED_LOCATION', 'SAME_POSITION': 'SHARED_LOCATION', 'LOCATION': 'SHARED_LOCATION', 'VERTEX': 'SHARED_VERTEX', 'SHARED_VERT': 'SHARED_VERTEX'}.get(mode, mode)


def _state_loop_groups(state: _UVState) -> list[list[Any]]:
    loops = list(getattr(state, 'loops', []) or [])
    mode = _uv_sticky_select_mode()
    if mode not in {'SHARED_LOCATION', 'SHARED_VERTEX'}:
        return [[loop] for loop in loops]
    buckets: dict[tuple, list[Any]] = {}
    ordered: list[tuple] = []
    for index, loop in enumerate(loops):
        try:
            if mode == 'SHARED_VERTEX':
                key = ('vert', int(getattr(loop.vert, 'index', -1)))
            else:
                uv = loop[state.uv_layer].uv
                key = ('uv', round(float(uv.x), 6), round(float(uv.y), 6))
        except Exception:
            key = ('loop', index)
        if key not in buckets:
            ordered.append(key)
            buckets[key] = []
        buckets[key].append(loop)
    return [buckets[key] for key in ordered if buckets.get(key)]


def _group_uv_center(group: list[Any], uv_layer) -> Vector | None:
    pts = []
    for loop in group:
        try:
            pts.append(loop[uv_layer].uv.copy())
        except Exception:
            pass
    if not pts:
        return None
    return Vector((sum(float(p.x) for p in pts) / len(pts), sum(float(p.y) for p in pts) / len(pts)))


def _uv_points(state: _UVState) -> list[Vector]:
    pts = []
    for group in _state_loop_groups(state):
        center = _group_uv_center(group, state.uv_layer)
        if center is not None:
            pts.append(center)
    return pts

def _bbox(points: Iterable[Vector]) -> tuple[float, float, float, float] | None:
    pts = list(points)
    if not pts:
        return None
    min_u = min(float(p.x) for p in pts)
    max_u = max(float(p.x) for p in pts)
    min_v = min(float(p.y) for p in pts)
    max_v = max(float(p.y) for p in pts)
    return min_u, min_v, max_u, max_v


def _apply_uv_transform(state: _UVState, transform: Callable[[Vector], Vector]) -> int:
    count = 0
    for group in _state_loop_groups(state):
        center = _group_uv_center(group, state.uv_layer)
        if center is None:
            continue
        try:
            new_uv = transform(center.copy())
        except Exception:
            continue
        for loop in group:
            try:
                loop[state.uv_layer].uv = new_uv.copy()
                count += 1
            except Exception:
                pass
    return count


def _fit_uvs(context, *, padding: float = 0.01, preserve: bool = False, fill: bool = False) -> int:
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    width = max(1.0e-8, max_u - min_u)
    height = max(1.0e-8, max_v - min_v)
    pad = max(0.0, min(0.49, float(padding)))
    target_w = max(1.0e-8, 1.0 - pad * 2.0)
    target_h = max(1.0e-8, 1.0 - pad * 2.0)
    sx = target_w / width
    sy = target_h / height
    if preserve:
        s = max(sx, sy) if fill else min(sx, sy)
        sx = sy = s
    center_u = (min_u + max_u) * 0.5
    center_v = (min_v + max_v) * 0.5
    target_cu = 0.5
    target_cv = 0.5

    def transform(uv: Vector) -> Vector:
        return Vector(((uv.x - center_u) * sx + target_cu, (uv.y - center_v) * sy + target_cv))

    count = _apply_uv_transform(state, transform)
    _finish_state(state)
    return count


def _align_uvs(context, direction: str = 'CENTER') -> int:
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    cu, cv = (min_u + max_u) * 0.5, (min_v + max_v) * 0.5
    direction = str(direction or 'CENTER').upper()

    def transform(uv: Vector) -> Vector:
        u, v = uv.x, uv.y
        if direction in {'LEFT', 'ALIGN_LEFT'}:
            u = min_u
        elif direction in {'RIGHT', 'ALIGN_RIGHT'}:
            u = max_u
        elif direction in {'H', 'CENTER_H', 'ALIGN_H', 'HORIZONTAL', 'CENTER'}:
            u = cu
        if direction in {'BOTTOM', 'ALIGN_BOTTOM'}:
            v = min_v
        elif direction in {'TOP', 'ALIGN_TOP'}:
            v = max_v
        elif direction in {'V', 'CENTER_V', 'ALIGN_V', 'VERTICAL', 'CENTER'}:
            v = cv
        return Vector((u, v))

    count = _apply_uv_transform(state, transform)
    _finish_state(state)
    return count


def _flip_rotate_uvs(context, *, rotate: float = 0.0, flip_u: bool = False, flip_v: bool = False) -> int:
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    center = Vector(((min_u + max_u) * 0.5, (min_v + max_v) * 0.5))
    angle = math.radians(float(rotate))
    cos_v, sin_v = math.cos(angle), math.sin(angle)

    def transform(uv: Vector) -> Vector:
        x, y = uv.x - center.x, uv.y - center.y
        if flip_u:
            x = -x
        if flip_v:
            y = -y
        if rotate:
            x, y = x * cos_v - y * sin_v, x * sin_v + y * cos_v
        return Vector((center.x + x, center.y + y))

    count = _apply_uv_transform(state, transform)
    _finish_state(state)
    return count


def _straighten_uvs(context, *, axis: str = 'AUTO') -> int:
    state = _ensure_edit_uv_state(context)
    if state is None or len(state.loops) < 2:
        return 0
    pts = _uv_points(state)
    box = _bbox(pts)
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    axis = str(axis or 'AUTO').upper()
    if axis == 'AUTO':
        axis = 'U' if (max_u - min_u) >= (max_v - min_v) else 'V'
    if axis in {'U', 'X', 'HORIZONTAL'}:
        mid = (min_v + max_v) * 0.5
        count = _apply_uv_transform(state, lambda uv: Vector((uv.x, mid)))
    else:
        mid = (min_u + max_u) * 0.5
        count = _apply_uv_transform(state, lambda uv: Vector((mid, uv.y)))
    _finish_state(state)
    return count


def _snap_grid_uvs(context, *, divisions: int = 16) -> int:
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    div = max(1, int(divisions or 16))

    def transform(uv: Vector) -> Vector:
        return Vector((round(uv.x * div) / div, round(uv.y * div) / div))

    count = _apply_uv_transform(state, transform)
    _finish_state(state)
    return count


def _randomize_uvs(context, *, amount: float = 0.05) -> int:
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    amount = max(0.0, float(amount or 0.05))
    du = random.uniform(-amount, amount)
    dv = random.uniform(-amount, amount)
    rot = random.choice((0.0, math.pi * 0.5, math.pi, math.pi * 1.5))
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    center = Vector(((min_u + max_u) * 0.5, (min_v + max_v) * 0.5))
    cos_v, sin_v = math.cos(rot), math.sin(rot)

    def transform(uv: Vector) -> Vector:
        x, y = uv.x - center.x, uv.y - center.y
        x, y = x * cos_v - y * sin_v, x * sin_v + y * cos_v
        return Vector((center.x + x + du, center.y + y + dv))

    count = _apply_uv_transform(state, transform)
    _finish_state(state)
    return count


def _pin_uvs(context, value: bool | None = True) -> int:
    state = _ensure_edit_uv_state(context)
    if state is None:
        return 0
    count = 0
    for loop in state.loops:
        try:
            luv = loop[state.uv_layer]
            current = bool(getattr(luv, 'pin_uv', False))
            luv.pin_uv = (not current) if value is None else bool(value)
            count += 1
        except Exception:
            pass
    _finish_state(state)
    return count


def _clear_pins(context) -> int:
    state = _ensure_edit_uv_state(context, all_if_empty=True)
    if state is None:
        return 0
    count = 0
    for face in state.bm.faces:
        for loop in face.loops:
            try:
                loop[state.uv_layer].pin_uv = False
                count += 1
            except Exception:
                pass
    _finish_state(state)
    return count


def _mark_seams(context, *, mode: str = 'SELECTED') -> int:
    state = _ensure_edit_uv_state(context)
    if state is None:
        return 0
    mode = str(mode or 'SELECTED').upper()
    count = 0
    for edge in state.bm.edges:
        selected = bool(getattr(edge, 'select', False))
        if mode == 'BOUNDARY':
            selected = len(getattr(edge, 'link_faces', ()) or ()) <= 1
        elif mode == 'ANGLE':
            try:
                if len(edge.link_faces) == 2:
                    angle = edge.calc_face_angle(0.0)
                    selected = angle > math.radians(50.0)
            except Exception:
                selected = bool(getattr(edge, 'select', False))
        if selected:
            try:
                edge.seam = True
                count += 1
            except Exception:
                pass
    _finish_state(state)
    return count


def _clear_seams(context) -> int:
    state = _ensure_edit_uv_state(context, all_if_empty=True)
    if state is None:
        return 0
    count = 0
    for edge in state.bm.edges:
        try:
            if bool(getattr(edge, 'seam', False)):
                edge.seam = False
                count += 1
        except Exception:
            pass
    _finish_state(state)
    return count


def _face_uv_area(face, uv_layer) -> float:
    try:
        loops = list(face.loops)
        if len(loops) < 3:
            return 0.0
        pts = [loop[uv_layer].uv.copy() for loop in loops]
        area = 0.0
        for i, p in enumerate(pts):
            q = pts[(i + 1) % len(pts)]
            area += p.x * q.y - q.x * p.y
        return area * 0.5
    except Exception:
        return 0.0


def _set_face_uv_selected(context, face, state: bool) -> None:
    """Select a face in the UV editor: the mesh selection with UV Sync, the UV flags without it."""
    if bool(getattr(context.tool_settings, "use_uv_select_sync", False)):
        face.select = bool(state)
        return
    face.uv_select_set(bool(state))
    for loop in face.loops:
        loop.uv_select_vert = bool(state)
        loop.uv_select_edge = bool(state)


def _select_faces_by_issue(context, issue: str = 'ZERO') -> int:
    state = _ensure_edit_uv_state(context, all_if_empty=True)
    if state is None:
        return 0
    issue = str(issue or 'ZERO').upper()
    count = 0
    for face in state.bm.faces:
        _set_face_uv_selected(context, face, False)
    for face in state.bm.faces:
        select = False
        area = _face_uv_area(face, state.uv_layer)
        if issue in {'ZERO', 'DEGENERATE', 'NO_REGION'}:
            select = abs(area) <= 1.0e-8
        elif issue in {'FLIPPED', 'FLIP'}:
            select = area < -1.0e-8
        elif issue in {'UDIM', 'UDIM_CROSSING'}:
            tiles = set()
            try:
                for loop in face.loops:
                    uv = loop[state.uv_layer].uv
                    tiles.add((math.floor(float(uv.x)), math.floor(float(uv.y))))
            except Exception:
                tiles = set()
            select = len(tiles) > 1 or any(t != (0, 0) for t in tiles)
        elif issue in {'BOUNDARY', 'BORDER'}:
            try:
                select = any(len(loop.edge.link_faces) <= 1 for loop in face.loops)
            except Exception:
                select = False
        elif issue in {'OVERLAP', 'OVERLAPPED'}:
            # Conservative overlap approximation: select duplicate UV-centroid faces.
            try:
                c = sum((loop[state.uv_layer].uv for loop in face.loops), Vector((0.0, 0.0))) / max(1, len(face.loops))
                key = (round(c.x, 4), round(c.y, 4), len(face.loops))
                seen = getattr(_select_faces_by_issue, '_seen', set())
                select = key in seen
                seen.add(key)
                setattr(_select_faces_by_issue, '_seen', seen)
            except Exception:
                select = False
        if select:
            _set_face_uv_selected(context, face, True)
            count += 1
    try:
        setattr(_select_faces_by_issue, '_seen', set())
    except Exception:
        pass
    _finish_state(state)
    return count


def _copy_uvs(context) -> int:
    global _UV_COPY_BUFFER
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    _UV_COPY_BUFFER = []
    for loop in state.loops:
        try:
            uv = loop[state.uv_layer].uv
            _UV_COPY_BUFFER.append((float(uv.x), float(uv.y)))
        except Exception:
            pass
    _finish_state(state)
    return len(_UV_COPY_BUFFER)


def _paste_uvs(context) -> int:
    if not _UV_COPY_BUFFER:
        return 0
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    count = 0
    for i, loop in enumerate(state.loops):
        try:
            u, v = _UV_COPY_BUFFER[i % len(_UV_COPY_BUFFER)]
            loop[state.uv_layer].uv = Vector((u, v))
            count += 1
        except Exception:
            pass
    _finish_state(state)
    return count


def _uv_map_action(context, action: str, name: str = '') -> int:
    obj = _mesh_object(context)
    if obj is None:
        return 0
    old_mode = str(getattr(obj, 'mode', '') or 'OBJECT')
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass
    try:
        return _uv_map_action_in_object_mode(context, obj, action, name)
    finally:
        try:
            if old_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=old_mode)
        except Exception:
            pass


def _uv_map_action_in_object_mode(context, obj, action: str, name: str = '') -> int:
    action = str(action or '').upper()
    if not name and action in {'ADD', 'CREATE', 'RENAME'}:
        try:
            name = str(getattr(context.scene.suv_workspace, 'uv_new_name', '') or '')
        except Exception:
            name = ''
    maps = getattr(obj.data, 'uv_layers', None)
    if maps is None:
        return 0
    try:
        if action in {'ADD', 'CREATE'}:
            maps.new(name=str(name or f'SmartUV_{len(maps)+1:02d}'))
            return 1
        if action == 'DUPLICATE':
            src = maps.active
            new = maps.new(name=str(name or ((src.name if src else 'SmartUV') + '_Copy')))
            if src is not None:
                for s, d in zip(src.data, new.data):
                    d.uv = s.uv
            return 1
        if action in {'REMOVE', 'DELETE'} and maps.active is not None and len(maps) > 0:
            maps.remove(maps.active)
            return 1
        if action == 'RENAME' and maps.active is not None:
            maps.active.name = str(name or 'SmartUV')
            return 1
        if action == 'SET_RENDER' and maps.active is not None:
            try:
                maps.active.active_render = True
            except Exception:
                pass
            return 1
    except Exception:
        return 0
    return 0


def _create_checker_material(context, *, cleanup: bool = False) -> int:
    from . import native_stage as _native_stage
    obj = _mesh_object(context)
    if cleanup:
        count = 0
        for candidate in bpy.data.objects:
            if candidate.type == 'MESH':
                _native_stage._suv_restore_material_state(candidate, '_suv_checker_restore')
        try:
            for mat in list(bpy.data.materials):
                if str(getattr(mat, 'name', '')).startswith('Smart UV Checker'):
                    bpy.data.materials.remove(mat)
                    count += 1
        except Exception:
            pass
        return count
    mat = bpy.data.materials.get('Smart UV Checker')
    if mat is None:
        mat = bpy.data.materials.new('Smart UV Checker')
    try:
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        bsdf = nodes.get('Principled BSDF')
        checker = nodes.get('Smart UV Checker Node') or nodes.new(type='ShaderNodeTexChecker')
        checker.name = 'Smart UV Checker Node'
        try:
            checker.inputs['Scale'].default_value = 16.0
        except Exception:
            pass
        if bsdf is not None:
            try:
                mat.node_tree.links.new(checker.outputs.get('Color'), bsdf.inputs.get('Base Color'))
            except Exception:
                pass
    except Exception:
        pass
    if obj is not None:
        try:
            _native_stage._suv_show_preview_material(obj, mat, '_suv_checker_restore')
        except Exception:
            pass
    return 1


def _density_action(context, action: str, operator=None) -> int:
    global _LAST_DENSITY
    state = _ensure_edit_uv_state(context, all_if_empty=True)
    if state is None:
        return 0
    uv_area = 0.0
    mesh_area = 0.0
    for face in state.faces or list(state.bm.faces):
        try:
            uv_area += abs(_face_uv_area(face, state.uv_layer))
            mesh_area += float(face.calc_area())
        except Exception:
            pass
    density = math.sqrt(max(0.0, uv_area) / max(1.0e-8, mesh_area)) if mesh_area > 0 else 0.0
    if action == 'GET':
        _LAST_DENSITY = density or _LAST_DENSITY
        _finish_state(state)
        return 1
    if action in {'SET', 'NORMALIZE'}:
        target = max(1.0e-8, _LAST_DENSITY if action == 'SET' else 1.0)
        if density <= 1.0e-8:
            _finish_state(state)
            return 0
        scale = target / density
        box = _bbox(_uv_points(state))
        if box is None:
            _finish_state(state)
            return 0
        min_u, min_v, max_u, max_v = box
        center = Vector(((min_u + max_u) * 0.5, (min_v + max_v) * 0.5))
        count = _apply_uv_transform(state, lambda uv: center + (uv - center) * scale)
        _finish_state(state)
        return count
    _finish_state(state)
    return 1


def _atlas_snap(context, *, columns: int = 4, rows: int = 4, cell_index: int = 0, padding: float = 0.01) -> int:
    columns = max(1, int(columns or 4))
    rows = max(1, int(rows or 4))
    cell_index = max(0, min(columns * rows - 1, int(cell_index or 0)))
    col = cell_index % columns
    row = cell_index // columns
    state = _ensure_edit_uv_state(context)
    if state is None or not state.loops:
        return 0
    box = _bbox(_uv_points(state))
    if box is None:
        return 0
    min_u, min_v, max_u, max_v = box
    width = max(1.0e-8, max_u - min_u)
    height = max(1.0e-8, max_v - min_v)
    pad = max(0.0, min(0.20, float(padding or 0.0)))
    cell_w = 1.0 / columns
    cell_h = 1.0 / rows
    target_min_u = col * cell_w + pad * cell_w
    target_min_v = row * cell_h + pad * cell_h
    target_w = cell_w * (1.0 - pad * 2.0)
    target_h = cell_h * (1.0 - pad * 2.0)
    sx = target_w / width
    sy = target_h / height

    def transform(uv: Vector) -> Vector:
        return Vector((target_min_u + (uv.x - min_u) * sx, target_min_v + (uv.y - min_v) * sy))

    count = _apply_uv_transform(state, transform)
    _finish_state(state)
    return count


def _run_unwrap(context, mode: str = 'ANGLE_BASED', *, native_defaults=False) -> bool:
    obj = _mesh_object(context)
    if obj is None:
        return False
    try:
        if getattr(obj, 'mode', '') != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
    except Exception:
        pass
    mode = str(mode or 'ANGLE_BASED').upper()
    if mode in {'SMART', 'SMART_PROJECT'}:
        kwargs = {} if native_defaults else {'island_margin': 0.01}
        return _safe_call('uv.smart_project', **kwargs)
    if mode in {'VIEW', 'VIEW_PROJECT'}:
        return _safe_call('uv.project_from_view', correct_aspect=True)
    if mode in {'CUBE', 'BOX', 'BOX_PROJECT'}:
        kwargs = {} if native_defaults else {'cube_size': 1.0}
        return _safe_call('uv.cube_project', **kwargs)
    if mode in {'CYLINDER'}:
        return _safe_call('uv.cylinder_project')
    if mode in {'SPHERE'}:
        return _safe_call('uv.sphere_project')
    method = 'CONFORMAL' if mode == 'CONFORMAL' else 'ANGLE_BASED'
    return _safe_call('uv.unwrap', method=method, margin=0.001)


def _focus_view(context) -> bool:
    screen = getattr(context, 'screen', None)
    for area_type, ops in (('IMAGE_EDITOR', ('image.view_selected', 'image.view_all')), ('VIEW_3D', ('view3d.view_selected', 'view3d.view_all'))):
        for area in getattr(screen, 'areas', []) or []:
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if area.type != area_type or region is None:
                continue
            with context.temp_override(area=area, region=region):
                if any(_safe_call(op_id) for op_id in ops):
                    return True
    return False


def _infer_action(op_id: str, label: str = '', category: str = '', original: str = '') -> str:
    if op_id == 'smart_uv_suite.density_get_native':
        return 'DENSITY_GET'
    if op_id == 'smart_uv_suite.density_normalize_native':
        return 'DENSITY_NORMALIZE'
    if op_id == 'smart_uv_suite.uvmap_add_native':
        return 'UVMAP_ADD'
    if op_id == 'smart_uv_suite.uvmap_duplicate_native':
        return 'UVMAP_DUPLICATE'
    text = ' '.join([str(op_id or ''), str(label or ''), str(category or ''), str(original or '')]).lower()
    if any(t in text for t in ('checker_cleanup', 'remove_checker', 'clear checker', 'cleanup all checker', 'checker_map_clear')):
        return 'CHECKER_CLEAR'
    if 'checker' in text or 'texture preview' in text:
        return 'CHECKER_CREATE'
    if any(t in text for t in ('uvmap_add', 'uv_channel_add', 'create_new_uv_layer', 'add uv', 'new uv')):
        return 'UVMAP_ADD'
    if any(t in text for t in ('uvmap_duplicate', 'uv_channel_swap', 'duplicate uv')):
        return 'UVMAP_DUPLICATE'
    if any(t in text for t in ('uvmap_remove', 'uv_channel_remove', 'delete_uv', 'remove active uv')):
        return 'UVMAP_REMOVE'
    if 'rename' in text and 'uv' in text:
        return 'UVMAP_RENAME'
    if 'set_render' in text or 'render uv' in text:
        return 'UVMAP_SET_RENDER'
    # Catalog aliases may contain "copy_paste" in both operation names.
    if op_id.endswith(('_paste_uv', '_paste_uv_island')):
        return 'PASTE_UV'
    if 'copy' in text and 'uv' in text:
        return 'COPY_UV'
    if 'paste' in text and 'uv' in text:
        return 'PASTE_UV'
    if op_id == 'smart_uv_suite.pin_clear_native' or 'clear_pins' in text or 'clear all pins' in text:
        return 'PIN_CLEAR'
    if 'unpin' in text:
        return 'UNPIN'
    if 'pin' in text:
        return 'PIN'
    if op_id == 'smart_uv_suite.seam_clear_native' or 'clear_seams' in text or 'clear all seams' in text:
        return 'SEAM_CLEAR'
    if 'seam_boundary' in text or 'border_seam' in text or ('boundary' in text and 'seam' in text):
        return 'SEAM_BOUNDARY'
    if 'seam' in text or 'sharp edges' in text:
        return 'SEAM_MARK'
    if any(t in text for t in ('select_udim', 'udim_cross', 'equal_udim')):
        return 'SELECT_UDIM'
    if op_id in {'smart_uv_suite.inspect_inspector_fix_flipped', 'smart_uv_suite.inspect_repair_flipped_islands'}:
        return 'REPAIR_FLIPPED'
    if 'select' in text and 'flipped' in text:
        return 'SELECT_FLIPPED'
    if 'select' in text and any(t in text for t in ('zero', 'degenerate', 'no region')):
        return 'SELECT_ZERO'
    if 'select' in text and ('overlap' in text or 'overlapped' in text):
        return 'SELECT_OVERLAP'
    if 'select' in text and any(t in text for t in ('border', 'boundary', 'outline')):
        return 'SELECT_BOUNDARY'
    if 'select' in text:
        return 'SELECT_BOUNDARY'
    if any(t in text for t in ('density_get', 'texel_get', 'get texel')):
        return 'DENSITY_GET'
    if any(t in text for t in ('density_set', 'texel_set', 'set texel')):
        return 'DENSITY_SET'
    if 'density' in text or 'texel' in text or 'coverage' in text:
        return 'DENSITY_NORMALIZE'
    if 'snap' in text and ('atlas' in text or 'uv' in text):
        return 'ATLAS_SNAP'
    if 'fit' in text or 'resize' in text:
        return 'FIT'
    if 'crop' in text:
        return 'CROP'
    if 'fill' in text:
        return 'FILL'
    if 'pack' in text or 'layout' in text or 'hotspot' in text or 'trim' in text:
        return 'PACK'
    if 'rotate' in text and ('90' in text or 'cw' in text):
        return 'ROTATE_CW'
    if 'rotate' in text:
        return 'ROTATE_CW'
    if 'mirror' in text or 'flip' in text or 'symmetr' in text:
        return 'FLIP_U'
    if 'random' in text or 'shuffle' in text:
        return 'RANDOMIZE'
    if any(t in text for t in ('straight', 'align_edge', 'edge_loop')):
        return 'STRAIGHTEN'
    if 'circle' in text:
        return 'CIRCLE'
    if 'grid' in text or 'rect' in text or 'quad' in text or 'normalize' in text:
        return 'GRIDIFY'
    if 'relax' in text or 'smooth' in text or 'minimize' in text:
        return 'RELAX'
    if 'align' in text or 'orient' in text or 'centralize' in text or 'center' in text:
        return 'ALIGN_CENTER'
    if 'view' in text or 'focus' in text or 'cursor' in text:
        return 'VIEW_FOCUS'
    if 'unwrap' in text or 'project' in text or 'unfold' in text or 'body' in text or 'flatten' in text or 'iron' in text:
        if 'box' in text:
            return 'PROJECT_BOX'
        if 'view' in text or 'camera' in text:
            return 'PROJECT_VIEW'
        if 'smart' in text:
            return 'SMART_PROJECT'
        return 'UNWRAP'
    if 'stitch' in text or 'weld' in text or 'merge' in text:
        return 'WELD'
    return 'FIT'


def _execute_action(context, operator, action: str, inferred_label: str = '') -> set[str]:
    raw_action = str(getattr(operator, 'action', '') or action or '').strip().upper()
    mode = str(getattr(operator, 'mode', '') or '').strip().upper()
    if mode and raw_action in {'', 'FIT'}:
        raw_action = mode
    if raw_action in {'ALIGN_TL', 'ALIGN_TOP', 'ALIGN_TR'}:
        direction = 'TOP'
    elif raw_action in {'ALIGN_BL', 'ALIGN_BOTTOM', 'ALIGN_BR'}:
        direction = 'BOTTOM'
    elif raw_action in {'ALIGN_LEFT'}:
        direction = 'LEFT'
    elif raw_action in {'ALIGN_RIGHT'}:
        direction = 'RIGHT'
    elif raw_action in {'ALIGN_H'}:
        direction = 'CENTER_H'
    elif raw_action in {'ALIGN_V'}:
        direction = 'CENTER_V'
    else:
        direction = 'CENTER'
    padding = float(getattr(operator, 'padding', 0.01) or 0.01)
    amount = float(getattr(operator, 'amount', 0.05) or 0.05)
    name = str(getattr(operator, 'name', '') or '')
    count = 0
    ok = False
    if raw_action == 'UNWRAP_LSCM':
        ok = _run_unwrap(context, 'CONFORMAL')
    elif raw_action in {'UNWRAP', 'UNWRAP_ABF', 'CONSTRAINT_UNWRAP'}:
        ok = _run_unwrap(context, 'ANGLE_BASED')
    elif raw_action in {'SMART_PROJECT'}:
        ok = _run_unwrap(context, 'SMART_PROJECT')
    elif raw_action in {'PROJECT_BOX', 'BOX_PROJECT'}:
        ok = _run_unwrap(context, 'BOX_PROJECT')
    elif raw_action in {'PROJECT_VIEW', 'VIEW_PROJECT', 'TEXTURE_PROJECT'}:
        ok = _run_unwrap(context, 'VIEW_PROJECT')
    elif raw_action in {'PROJECT_CYLINDER'}:
        ok = _run_unwrap(context, 'CYLINDER')
    elif raw_action in {'PROJECT_SPHERE'}:
        ok = _run_unwrap(context, 'SPHERE')
    elif raw_action in {'FIT'}:
        count = _fit_uvs(context, padding=padding, preserve=True, fill=False); ok = count > 0
    elif raw_action in {'CROP'}:
        count = _fit_uvs(context, padding=0.0, preserve=False, fill=False); ok = count > 0
    elif raw_action == 'PACK':
        from .unified_packing import run_auto_pack

        ok = run_auto_pack(context)
    elif raw_action == 'FILL':
        count = _fit_uvs(context, padding=padding, preserve=True, fill=True); ok = count > 0
    elif raw_action.startswith('ALIGN'):
        count = _align_uvs(context, direction); ok = count > 0
    elif raw_action in {'FLIP_U', 'MIRROR_H', 'FLIP_H'}:
        count = _flip_rotate_uvs(context, flip_u=True); ok = count > 0
    elif raw_action in {'FLIP_V', 'MIRROR_V'}:
        count = _flip_rotate_uvs(context, flip_v=True); ok = count > 0
    elif raw_action in {'ROTATE_CW', 'ROTATE_90', 'ROTATE_RIGHT'}:
        count = _flip_rotate_uvs(context, rotate=-90.0); ok = count > 0
    elif raw_action in {'ROTATE_CCW', 'ROTATE_LEFT'}:
        count = _flip_rotate_uvs(context, rotate=90.0); ok = count > 0
    elif raw_action in {'STRAIGHTEN', 'STRAIGHT'}:
        count = _straighten_uvs(context); ok = count > 0
    elif raw_action in {'GRIDIFY', 'RECTIFY', 'CIRCLE'}:
        count = _snap_grid_uvs(context, divisions=max(2, int(getattr(operator, 'columns', 16) or 16))); ok = count > 0
    elif raw_action in {'RELAX'}:
        ok = _safe_call('uv.minimize_stretch', iterations=10) or _safe_call('uv.unwrap', method='ANGLE_BASED')
    elif raw_action == 'RANDOMIZE':
        count = _randomize_uvs(context, amount=amount); ok = count > 0
    elif raw_action == 'PIN':
        count = _pin_uvs(context, True); ok = count > 0
    elif raw_action == 'UNPIN':
        count = _pin_uvs(context, False); ok = count > 0
    elif raw_action == 'PIN_CLEAR':
        count = _clear_pins(context); ok = count >= 0
    elif raw_action == 'SEAM_MARK':
        count = _mark_seams(context, mode='ANGLE'); ok = count >= 0
    elif raw_action == 'SEAM_BOUNDARY':
        count = _mark_seams(context, mode='BOUNDARY'); ok = count >= 0
    elif raw_action == 'SEAM_CLEAR':
        count = _clear_seams(context); ok = count >= 0
    elif raw_action == 'REPAIR_FLIPPED':
        ok = _safe_call('uv.suv_repair_flipped_islands')
    elif raw_action.startswith('SELECT_'):
        issue = raw_action.replace('SELECT_', '')
        count = _select_faces_by_issue(context, issue); ok = count >= 0
    elif raw_action == 'COPY_UV':
        count = _copy_uvs(context); ok = count > 0
    elif raw_action == 'PASTE_UV':
        count = _paste_uvs(context); ok = count > 0
    elif raw_action.startswith('UVMAP_'):
        count = _uv_map_action(context, raw_action.replace('UVMAP_', ''), name=name); ok = count > 0
    elif raw_action == 'CHECKER_CREATE':
        count = _create_checker_material(context, cleanup=False); ok = count > 0
    elif raw_action == 'CHECKER_CLEAR':
        count = _create_checker_material(context, cleanup=True); ok = True
    elif raw_action == 'DENSITY_GET':
        count = _density_action(context, 'GET', operator); ok = count > 0
    elif raw_action == 'DENSITY_SET':
        count = _density_action(context, 'SET', operator); ok = count > 0
    elif raw_action == 'DENSITY_NORMALIZE':
        count = _density_action(context, 'NORMALIZE', operator); ok = count > 0
    elif raw_action == 'ATLAS_SNAP':
        count = _atlas_snap(context, columns=int(getattr(operator, 'columns', 4) or 4), rows=int(getattr(operator, 'rows', 4) or 4), cell_index=int(getattr(operator, 'cell_index', 0) or 0), padding=padding); ok = count > 0
    elif raw_action in {'VIEW_FOCUS'}:
        ok = _focus_view(context)
    elif raw_action in {'WELD'}:
        # A UV stitch must never fall back to merging mesh vertices: that destroys the geometry.
        ok = _safe_call('smart_uv_suite.stitch_action', mode='ISLAND_CONNECTED_TO_SELECTED')
    else:
        count = _fit_uvs(context, padding=padding, preserve=True, fill=False); ok = count > 0
    if ok:
        _message(context, operator,
                 f'Smart UV Suite executed {inferred_label or raw_action}.',
                 f'Smart UV Suite の「{inferred_label or raw_action}」を実行しました。')
        return {'FINISHED'}
    _message(context, operator,
             f'{inferred_label or raw_action} could not run in the current context. Select a mesh with UVs and use Edit Mode or the UV Editor.',
             f'現在のコンテキストでは「{inferred_label or raw_action}」を実行できません。UV付きメッシュを選択し、編集モードまたはUVエディターで実行してください。', 'WARNING')
    return {'CANCELLED'}


def _operator_prop_annotations() -> dict[str, Any]:
    opts = hidden = {'HIDDEN', 'SKIP_SAVE'}
    return {
        'action': StringProperty(default='', options=opts),
        'mode': StringProperty(default='', options=opts),
        'scope': StringProperty(default='', options=hidden),
        'axis': StringProperty(default='', options=opts),
        'direction': StringProperty(default='', options=opts),
        'issue': StringProperty(default='', options=opts),
        'apply_mode': StringProperty(default='', options=hidden),
        'select_type': StringProperty(default='', options=hidden),
        'select_set': StringProperty(default='', options=hidden),
        'profile': StringProperty(default='', options=hidden),
        'preset': StringProperty(default='', options=hidden),
        'feature_id': StringProperty(default='', options=hidden),
        'key': StringProperty(default='', options=hidden),
        'title_en': StringProperty(default='', options=hidden),
        'title_ja': StringProperty(default='', options=hidden),
        'name': StringProperty(default='', options=opts),
        'filepath': StringProperty(default='', options=hidden, subtype='FILE_PATH'),
        'filter_glob': StringProperty(default='*.json;*.txt', options=hidden),
        'auto_scan': BoolProperty(default=False, options=hidden),
        'default_open': BoolProperty(default=False, options=hidden),
        'is_vertical': BoolProperty(default=False, options=hidden),
        'is_stack': BoolProperty(default=False, options=hidden),
        'use_checker': BoolProperty(default=False, options=hidden),
        'angle': FloatProperty(default=0.0, options=opts),
        'padding': FloatProperty(default=0.01, min=0.0, max=0.49, options=opts),
        'value': FloatProperty(default=0.0, options=opts),
        'amount': FloatProperty(default=0.05, min=0.0, max=10.0, options=opts),
        'index': IntProperty(default=0, options=opts),
        'source_index': IntProperty(default=0, options=hidden),
        'target_index': IntProperty(default=0, options=hidden),
        'columns': IntProperty(default=4, min=1, max=64, options=opts),
        'rows': IntProperty(default=4, min=1, max=64, options=opts),
        'cell_index': IntProperty(default=0, min=0, max=4095, options=opts),
        'texture_size': IntProperty(default=1024, min=1, max=65536, options=hidden),
        'margin_px': IntProperty(default=8, min=0, max=4096, options=hidden),
        'band_count': IntProperty(default=4, min=1, max=128, options=hidden),
    }


class SMARTUV_OT_integrated_uv_action(bpy.types.Operator):
    bl_idname = 'smart_uv_suite.integrated_uv_action'
    bl_label = 'Integrated UV Action'
    bl_options = {'UNDO'}

    action: StringProperty(default='FIT')
    mode: StringProperty(default='')
    axis: StringProperty(default='')
    direction: StringProperty(default='')
    issue: StringProperty(default='')
    name: StringProperty(default='')
    padding: FloatProperty(default=0.01, min=0.0, max=0.49)
    amount: FloatProperty(default=0.05, min=0.0, max=10.0)
    columns: IntProperty(default=4, min=1, max=64)
    rows: IntProperty(default=4, min=1, max=64)
    cell_index: IntProperty(default=0, min=0, max=4095)

    @classmethod
    def poll(cls, context):
        return _mesh_object(context) is not None

    @classmethod
    def description(cls, context, properties):
        return _t(
            context,
            'Function: Executes a native Smart UV Suite integrated UV operation such as unwrap, align, pack, seam, checker, UV-map, density, or atlas snap. How to use: select mesh/UV elements, choose the action variant from the button, then run it. The operator uses Blender-native data access and does not load third-party add-on modules.',
            '機能: 展開、整列、パック、シーム、チェッカー、UVマップ、密度、アトラススナップなどを Smart UV Suite 独自の統合UV処理として実行します。使い方: メッシュまたはUV要素を選択し、ボタン側の処理種別を指定して実行します。Blender標準データへ直接処理するため、外部アドオンモジュールは読み込みません。',
        )

    def execute(self, context):
        return _execute_action(context, self, str(getattr(self, 'action', '') or 'FIT'), self.bl_label)


_DYNAMIC_ACTION_DESC = {
    "CHECKER_CREATE": ("Create and assign the managed checker material for visual UV distortion and scale checks.", "UVの歪みやスケール確認用に、管理対象のチェッカー材質を作成して割り当てます。"),
    "CHECKER_CLEAR": ("Remove Smart UV checker materials, images, and generated checker helper data.", "Smart UVが生成したチェッカー材質、画像、補助データを削除します。"),
    "AUTO_UNWRAP": ("Run the automatic unwrap workflow using the current Smart UV cut, relax, scale, and pack settings.", "現在のSmart UVのカット、リラックス、スケール、パック設定を使って自動展開を実行します。"),
    "SMART_UNWRAP": ("Run the Smart unwrap workflow and preserve connected no-seam meshes where possible.", "Smart展開ワークフローを実行し、可能な範囲でシームなし連結メッシュを維持します。"),
    "PACK": ("Pack selected UV islands into the active tile using the configured margin and rotation settings.", "設定された余白と回転設定に従って、選択UVアイランドをアクティブタイル内へパックします。"),
    "PACK_PRECISION": ("Run the exact-margin precision packer on selected UV islands.", "選択UVアイランドに対して、正確余白の精密パッカーを実行します。"),
    "DENSITY_GET": ("Measure texel density from the active mesh and UV selection.", "アクティブメッシュとUV選択からテクセル密度を測定します。"),
    "DENSITY_NORMALIZE": ("Scale the selected UVs toward the configured target texel density.", "選択UVを設定された目標テクセル密度へ近づけるようにスケールします。"),
    "SELECT_OVERLAP": ("Select UV faces that are likely overlapping based on UV position and area checks.", "UV位置と面積チェックを基準に、重なりが疑われるUV面を選択します。"),
    "REPAIR_FLIPPED": ("Correct flipped UV island winding.", "反転したUVアイランドの巻き方向を修正します。"),
    "SELECT_FLIPPED": ("Select faces whose UV winding is flipped.", "UVの巻き方向が反転している面を選択します。"),
    "SELECT_ZERO": ("Select degenerate or zero-area UV faces.", "縮退またはゼロ面積のUV面を選択します。"),
    "SNAP_GRID": ("Snap selected UVs to the current UV grid, including visible fine subdivisions when the UV Editor is zoomed in.", "選択UVを現在のUVグリッドへ吸着します。UVエディター拡大時は、表示されている薄い細分グリッドも対象に含めます。"),
    "SNAP_PIXEL": ("Snap selected UVs to texture pixel positions using the current image or texture size settings.", "現在の画像またはテクスチャサイズ設定を使って、選択UVをピクセル位置へ吸着します。"),
    "SNAP_VERTEX": ("Move selected UV vertices within the distance setting to their shared midpoint.", "距離設定内にある選択UV頂点を検出し、対象グループの中点へ揃えます。"),
    "ALIGN_CENTER": ("Move the current UV selection to the center of the active bounds or tile.", "現在のUV選択を、対象範囲またはタイルの中央へ移動します。"),
    "FIT": ("Fit the selected UV bounds inside the target tile or area with the configured padding.", "選択UVの外接範囲を、設定余白付きで対象タイルまたは領域内へ収めます。"),
    "FILL": ("Scale the selected UV bounds until they fill the target tile or area.", "選択UVの外接範囲が対象タイルまたは領域を満たすまでスケールします。"),
    "GRIDIFY": ("Place selected UV elements on a grid according to the current grid settings.", "現在のグリッド設定に従って、選択UVエレメントをグリッド上へ配置します。"),
    "RELAX": ("Relax selected UVs to reduce stretch while respecting the current selection and pinned UVs.", "現在の選択とピン留めUVを考慮しながら、選択UVの伸びを緩和します。"),
    "STRAIGHTEN": ("Straighten selected UV elements along the dominant direction or selected chain.", "選択UVエレメントを、主方向または選択チェーンに沿って直線化します。"),
    "UV_COPY": ("Copy the selected UV coordinates into the Smart UV clipboard.", "選択UV座標をSmart UVのクリップボードへコピーします。"),
    "UV_PASTE": ("Paste Smart UV clipboard coordinates into the current UV selection.", "Smart UVのクリップボード座標を現在のUV選択へ貼り付けます。"),
}


def _dynamic_action_from_properties(properties, default_action: str = '') -> str:
    for key in ('action', 'mode', 'issue', 'target', 'preset', 'operation'):
        try:
            value = str(getattr(properties, key) or '').strip().upper()
            if value:
                return value
        except Exception:
            pass
    return str(default_action or '').strip().upper()


def _dynamic_action_tooltip(context, action: str, label_en: str, label_ja: str, category_en: str, category_ja: str, source_key: str) -> str:
    key = str(action or '').strip().upper()
    if key in _DYNAMIC_ACTION_DESC:
        en, ja = _DYNAMIC_ACTION_DESC[key]
        return _t(
            context,
            f'{label_en}: {en} This button executes only the {key} function assigned to this UI item.',
            f'{label_ja}: {ja} このボタンは、このUI項目に割り当てられた {key} 機能だけを実行します。',
        )
    return _t(
        context,
        f'{label_en}: run the {source_key} tool in the {category_en} category. This generated button executes only its assigned action or mode, using the current mesh, UV selection, and saved Smart UV settings.',
        f'{label_ja}: {category_ja} カテゴリの {source_key} ツールを実行します。この生成ボタンは割り当てられたアクションまたはモードだけを、現在のメッシュ、UV選択、保存済みSmart UV設定に基づいて実行します。',
    )


def _safe_class_name(op_id: str) -> str:
    text = re.sub(r'[^0-9A-Za-z_]+', '_', str(op_id or '')).strip('_').upper()
    if not text:
        text = 'INTEGRATED_UV_ACTION'
    if text[0].isdigit():
        text = 'OP_' + text
    return ('SMARTUV_OT_' + text)[:120]


def _panel_handler(op_id: str):
    from . import panel_tools
    return panel_tools.HANDLERS.get(op_id)


_REFERENCE_ROUTE_DESCRIPTIONS = {
    'smart_uv_suite.inspect_apply_feature_bridge': (
        'Run the mapped UV bridge for the supplied reference feature key.',
        '指定した参照機能キーに対応する UV ブリッジを実行します。',
    ),
    'smart_uv_suite.inspect_smart_uv_smart_write_matrix': (
        'Write the UV Suite Smart feature coverage matrix from the reference data.',
        '参照データから UV Suite Smart の機能対応表を書き出します。',
    ),
    'smart_uv_suite.workflow_smart_uv_smart_feature': (
        'Run the UV Suite Smart route for the supplied documented feature key.',
        '指定した文書機能キーに対応する UV Suite Smart のルートを実行します。',
    ),
}


def _make_dynamic_operator(op_id: str, label_en: str, label_ja: str, category_en: str, category_ja: str, source_key: str) -> type:
    action = _infer_action(op_id, label_en, category_en, source_key)
    tooltip_en = (
        f'Function: Runs {label_en or op_id} as a Smart UV Suite native integrated operation. '
        'How to use: select the target mesh or UV elements, then execute this command from the Smart UV N-panel. '
        'This command is implemented under the JELararagi Smart UV Suite namespace and does not load the reference add-on IDs.'
    )
    tooltip_ja = (
        f'機能: 「{label_ja or label_en or op_id}」を Smart UV Suite 独自の統合UV処理として実行します。'
        '使い方: 対象のメッシュまたはUV要素を選択し、Smart UV Nパネルから実行します。'
        'JELararagi名義の Smart UV Suite 名前空間で実装されており、参照元アドオンのIDは読み込みません。'
    )

    class SMARTUV_OT_dynamic_integrated(bpy.types.Operator):
        bl_idname = op_id
        bl_label = label_en or op_id
        bl_options = {'UNDO'}

        @classmethod
        def poll(cls, context):
            # View/help/workflow commands may run without a mesh, but mesh-aware
            # commands are more common. Keep the button visible and let execute
            # report a context-specific warning if no mesh is available.
            return True

        @classmethod
        def description(cls, context, properties):
            handler = _panel_handler(op_id)
            if handler is not None:
                return _t(context, handler.tip_en, handler.tip_ja)
            if op_id in _REFERENCE_ROUTE_DESCRIPTIONS:
                return _t(context, *_REFERENCE_ROUTE_DESCRIPTIONS[op_id])
            chosen = _dynamic_action_from_properties(properties, action)
            return _dynamic_action_tooltip(context, chosen, label_en, label_ja, category_en, category_ja, source_key)

        def execute(self, context):
            handler = _panel_handler(op_id)
            if handler is not None:
                from . import panel_tools
                return panel_tools.run_handler(handler, context, self)
            if op_id == 'smart_uv_suite.inspect_apply_feature_bridge':
                return bpy.ops.uv.suv_apply_feature_bridge(
                    feature_key=self.feature_key or self.feature_id or self.key, strict=self.strict,
                )
            if op_id == 'smart_uv_suite.inspect_smart_uv_smart_write_matrix':
                from .smart_uv_smart import _execute_matrix
                return _execute_matrix(context, self.report)
            if op_id == 'smart_uv_suite.workflow_smart_uv_smart_feature':
                return bpy.ops.smart_uv_suite.smart_uv_smart_feature(
                    feature_key=self.feature_key or self.feature_id or self.key,
                    label_en=self.title_en, label_ja=self.title_ja,
                )
            if op_id == 'smart_uv_suite.view_quality_set_focus_mode':
                mode = str(self.mode or 'AUTO').upper()
                return bpy.ops.uv.suv_quality_set_focus_mode(mode=mode)
            if op_id == 'smart_uv_suite.view_quality_cycle_focus_mode':
                return bpy.ops.uv.suv_quality_cycle_focus_mode()
            if op_id == 'smart_uv_suite.inspect_quality_set_density_mode':
                mode = str(self.mode or 'AUTO').upper()
                return bpy.ops.uv.suv_quality_set_density_mode(mode=mode)
            if op_id == 'smart_uv_suite.inspect_quality_write_doctor_report':
                return bpy.ops.uv.suv_quality_write_doctor_report(open_after_write=False)
            if op_id == 'smart_uv_suite.workflow_write_tool_runtime_snapshot':
                return bpy.ops.uv.suv_write_tool_runtime_snapshot()
            chosen = str(getattr(self, 'action', '') or action)
            if chosen in {'', 'FIT'}:
                # Buttons that pass a mode/action property should control the
                # generic dispatcher without needing one-off operators.
                for attr in ('mode', 'axis', 'direction', 'issue'):
                    try:
                        value = str(getattr(self, attr, '') or '').strip()
                    except Exception:
                        value = ''
                    if value:
                        chosen = value
                        break
            return _execute_action(context, self, chosen, label_en or op_id)

    handler = _panel_handler(op_id)
    if handler is not None and handler.invoke is not None:
        def invoke(self, context, event):
            # A set picked from the popup menu arrives with its name filled in.
            if self.name and handler.draw is None and op_id.endswith(('_recall', '_update')):
                return self.execute(context)
            return handler.invoke(context, self, event)
        SMARTUV_OT_dynamic_integrated.invoke = invoke
    if handler is not None and handler.draw is not None:
        def draw(self, context):
            handler.draw(self, context)
        SMARTUV_OT_dynamic_integrated.draw = draw

    SMARTUV_OT_dynamic_integrated.__name__ = _safe_class_name(op_id)
    SMARTUV_OT_dynamic_integrated.__qualname__ = SMARTUV_OT_dynamic_integrated.__name__
    SMARTUV_OT_dynamic_integrated.__annotations__ = _operator_prop_annotations()
    if op_id == 'smart_uv_suite.texel_density_from_physical_size':
        SMARTUV_OT_dynamic_integrated.__annotations__.update(
            physical_width_m=FloatProperty(
                name='Width (m)', description='Physical width in metres', min=0.0, precision=4,
                options={'SKIP_SAVE'}),
            physical_height_m=FloatProperty(
                name='Height (m)', description='Physical height in metres, or zero if equal to width',
                min=0.0, precision=4, options={'SKIP_SAVE'}),
        )
    if op_id in {'smart_uv_suite.inspect_apply_feature_bridge', 'smart_uv_suite.workflow_smart_uv_smart_feature'}:
        SMARTUV_OT_dynamic_integrated.__annotations__['feature_key'] = StringProperty(
            name='Feature Key', default='', options={'HIDDEN', 'SKIP_SAVE'},
        )
    if op_id == 'smart_uv_suite.inspect_apply_feature_bridge':
        SMARTUV_OT_dynamic_integrated.__annotations__['strict'] = BoolProperty(
            name='Strict', default=False, options={'HIDDEN', 'SKIP_SAVE'},
        )
    if op_id == 'smart_uv_suite.pack_constraint_relax_preserve':
        from .flow import SUV_OT_constraint_relax_preserve
        native_properties = SUV_OT_constraint_relax_preserve.__annotations__
        for name in ('anchor_mode', 'temporary_anchors', 'preserve_position', 'preserve_area',
                     'preserve_rotation', 'keep_tile', 'average_scale_each_pass', 'iterations', 'passes', 'pack_after'):
            SMARTUV_OT_dynamic_integrated.__annotations__[name] = native_properties[name]
    if op_id == 'smart_uv_suite.workflow_smart_uv_smart_tool':
        SMARTUV_OT_dynamic_integrated.__annotations__['target'] = StringProperty(
            default='', options={'HIDDEN', 'SKIP_SAVE'}
        )
    try:
        SMARTUV_OT_dynamic_integrated._smart_uv_unified_source_key = str(source_key or '')
        SMARTUV_OT_dynamic_integrated._smart_uv_unified_action = action
    except Exception:
        pass
    return SMARTUV_OT_dynamic_integrated


def _should_dynamic_register(data: dict) -> bool:
    source = str(data.get('source_file') or '').replace('\\', '/').strip()
    source_root = source.split('/', 1)[0]
    # Native section hub operators are registered by native_unified_tools.py.
    # The dynamic compatibility table must not register the same bl_idname first,
    # otherwise Blender reports duplicate class registration on enable.
    if source == 'native_unified_tools.py' or source_root == 'native_unified_tools.py':
        return False
    if source_root == 'unified_uv_tools.py' or source == 'unified_uv_tools.py':
        return True
    if str(data.get('original_id') or '') == str(data.get('new_id') or '') and str(data.get('note') or '').startswith('JEL'):
        return True
    return False


def _register_class(cls: type) -> bool:
    op_id = str(getattr(cls, 'bl_idname', '') or '')
    if op_id and _safe_op_exists(op_id):
        # The legacy public surface can already own this exact Smart UV
        # operator when the integrated catalog is finalized. Treat only a
        # proven same-package Python class as an idempotent success; foreign or
        # unresolved conflicts remain fail-closed.
        try:
            group, name = op_id.split('.', 1)
            proxy = getattr(getattr(bpy.ops, group), name)
            rna = proxy.get_rna_type()
            identifier = str(getattr(rna, 'identifier', '') or '')
            lookup = getattr(bpy.types.Operator, 'bl_rna_get_subclass_py', None)
            existing = lookup(identifier) if callable(lookup) and identifier else None
            module_name = str(getattr(existing, '__module__', '') or '')
            package_name = str(__package__ or '')
            return bool(
                isinstance(existing, type)
                and package_name
                and (module_name == package_name or module_name.startswith(package_name + '.'))
            )
        except Exception:
            return False
    try:
        materialize_class_property_annotations(cls)
        if not _suv_resource.register_class(cls):
            return False
        _REGISTERED.append(cls)
        return True
    except Exception:
        return False


def register() -> None:
    if _REGISTERED:
        return
    if not _register_class(SMARTUV_OT_integrated_uv_action):
        raise RuntimeError('Required Smart UV integrated action registration failed')
    try:
        from . import rename_catalog
        items = list(getattr(rename_catalog, 'OPERATOR_RENAMES', {}).items())
    except Exception:
        items = []
    seen: set[str] = set()
    for source_key, data in items:
        try:
            if not isinstance(data, dict) or not _should_dynamic_register(data):
                continue
            op_id = str(data.get('new_id') or source_key or '').strip()
            if not op_id.startswith('smart_uv_suite.') or op_id in seen:
                continue
            if op_id in _DEDICATED_OVERRIDE_IDS:
                continue
            seen.add(op_id)
            if _safe_op_exists(op_id):
                continue
            cls = _make_dynamic_operator(
                op_id,
                str(data.get('en') or op_id),
                str(data.get('ja') or data.get('en') or op_id),
                str(data.get('category_en') or ''),
                str(data.get('category_ja') or data.get('category_en') or ''),
                str(source_key or ''),
            )
            _DYNAMIC_CLASSES.append(cls)
            _register_class(cls)
        except Exception:
            continue
    from . import panel_tools
    for op_id, label_en, label_ja in panel_tools.FILE_BUTTONS:
        cls = _make_dynamic_operator(op_id, label_en, label_ja, '', '', op_id)
        _DYNAMIC_CLASSES.append(cls)
        _register_class(cls)


def unregister() -> None:
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED.clear()
    _DYNAMIC_CLASSES.clear()


__all__ = ['register', 'unregister']
