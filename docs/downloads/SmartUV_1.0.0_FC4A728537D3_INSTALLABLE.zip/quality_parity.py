from __future__ import annotations
from . import resource_api_18168 as _suv_resource
from .text_translation import is_japanese
from .quality_class_inventory import iter_suite_classes

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover
    bpy = None

_NAMESPACE = {}
_REGISTERED = []
_PARITY_REPORT_SUFFIX = '_External_Feature_Parity'


def _empty_parity_data() -> dict:
    return {
        'summary': {'total': 0, 'direct': 0, 'bridge': 0, 'partial': 0, 'missing': 0},
        'categories': [],
        'entries': [],
    }


def _refresh_parity_cache() -> dict:
    try:
        data = scan_external_feature_parity(_NAMESPACE)
    except Exception:
        data = _empty_parity_data()
        _NAMESPACE['_suv_external_feature_parity_last'] = data
    try:
        _NAMESPACE['_suv_external_feature_parity_favorites'] = tuple(_favorite_targets())
    except Exception:
        _NAMESPACE['_suv_external_feature_parity_favorites'] = ()
    return data


def _is_ja(context) -> bool:
    fn = _NAMESPACE.get('_lang_is_ja')
    if callable(fn):
        try:
            return bool(fn(context))
        except Exception:
            pass
    return is_japanese(context)


def _tr(context, key: str, en: str, ja: str, **fmt) -> str:
    text = None
    fn = _NAMESPACE.get('tr')
    if callable(fn):
        try:
            text = fn(context, key, **fmt)
        except Exception:
            text = None
    if not text or text == key:
        text = ja if _is_ja(context) else en
    try:
        return str(text).format(**fmt)
    except Exception:
        return str(text)


def _safe_set_operator_props(op, props):
    try:
        if op is None or not props:
            return
        names = set()
        rna_props = getattr(getattr(op, 'bl_rna', None), 'properties', None)
        try:
            names.update(str(k) for k in rna_props.keys())
        except Exception:
            pass
        try:
            for prop in rna_props:
                ident = str(getattr(prop, 'identifier', '') or '')
                if ident:
                    names.add(ident)
        except Exception:
            pass
        for key, value in dict(props).items():
            if str(key) not in names:
                continue
            try:
                setattr(op, str(key), value)
            except Exception:
                pass
    except Exception:
        pass


def _data_entries():
    loader = _NAMESPACE.get('_suv_load_json_data')
    if callable(loader):
        try:
            data = loader('external_feature_reference.json', fallback=[], root_key='entries')
            if isinstance(data, list):
                rows = [row for row in data if isinstance(row, dict)]
                if rows:
                    return rows
        except Exception:
            pass
    # external_feature_reference.json は同梱されない。その時は同梱の data/jel_native_feature_matrix.json から
    # 作る native の機能行（smart_uv_smart._native_feature_entries）を使う。第三者の行は足さない（PD34C v2）
    try:
        from . import smart_uv_smart
        return [dict(row) for row in smart_uv_smart._native_feature_entries()]
    except Exception:
        return []


def _compat_targets():
    fn = _NAMESPACE.get('_suv_external_compat_target_data')
    if callable(fn):
        try:
            data = fn()
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def _bridge_engine():
    module = _NAMESPACE.get('_upgrade_bridge_engine_module')
    return module if module is not None else None


def _operator_index():
    rows = {}
    for name, value in iter_suite_classes(_NAMESPACE):
        if not (name.startswith('SUV_OT_') and isinstance(value, type)):
            continue
        try:
            idname = str(getattr(value, 'bl_idname', '') or '').strip()
            if not idname:
                continue
            rows[idname] = {
                'class_name': name,
                'label': str(getattr(value, 'bl_label', '') or name).strip(),
                'description': str(getattr(value, 'bl_description', '') or '').strip(),
            }
        except Exception:
            continue
    return rows


def _entry_actions(entry: dict):
    engine = _bridge_engine()
    if engine is not None and hasattr(engine, 'entry_actions'):
        try:
            return list(engine.entry_actions(dict(entry) or {}))
        except Exception:
            pass
    actions = list(entry.get('actions') or [])
    if actions:
        return [row for row in actions if isinstance(row, dict)]
    targets = list(entry.get('compat_targets') or [])
    if targets:
        return [{'type': 'compat_target', 'target': str(targets[0]), 'execution_mode': 'AUTO'}]
    return []


def _coverage_state(entry: dict, ops: dict, targets: dict):
    engine = _bridge_engine()
    if engine is not None and hasattr(engine, 'coverage_state'):
        try:
            return str(engine.coverage_state(_NAMESPACE, dict(entry) or {}))
        except Exception:
            pass
    direct = False
    bridge = False
    partial = False
    for action in _entry_actions(entry):
        typ = str(action.get('type', '') or '').strip().lower()
        if typ == 'operator':
            if str(action.get('idname', '') or '').strip() in ops:
                direct = True
            else:
                partial = True
        elif typ == 'compat_target':
            if str(action.get('target', '') or '').strip() in targets:
                bridge = True
            else:
                partial = True
        elif typ == 'workflow_recipe':
            bridge = True
        elif typ == 'workflow_bundle':
            bridge = True
        elif typ == 'auto_uv_profile':
            bridge = True
        else:
            partial = True
    if direct:
        return 'direct'
    if bridge:
        return 'bridge'
    if partial:
        return 'partial'
    return 'missing'


def scan_external_feature_parity(namespace: dict) -> dict:
    global _NAMESPACE
    _NAMESPACE = namespace or {}
    entries = _data_entries()
    targets = _compat_targets()
    ops = _operator_index()
    rows = []
    counts = {'total': 0, 'direct': 0, 'bridge': 0, 'partial': 0, 'missing': 0}
    category_summary = {}
    tool_summary = {}
    for raw in entries:
        entry = dict(raw)
        state = _coverage_state(entry, ops, targets)
        entry['resolved_coverage_state'] = state
        counts['total'] += 1
        counts[state] = counts.get(state, 0) + 1
        cat = str(entry.get('category', 'Other') or 'Other')
        tool = str(entry.get('tool', 'Unknown') or 'Unknown')
        cat_row = category_summary.setdefault(cat, {'total': 0, 'direct': 0, 'bridge': 0, 'partial': 0, 'missing': 0})
        tool_row = tool_summary.setdefault(tool, {'total': 0, 'direct': 0, 'bridge': 0, 'partial': 0, 'missing': 0})
        cat_row['total'] += 1
        cat_row[state] += 1
        tool_row['total'] += 1
        tool_row[state] += 1
        rows.append(entry)
    order = ['DCC', 'Texture / Sculpt', 'Engine', 'Dedicated', 'Plugin', 'AI', 'Reference Add-on', 'Other']
    ordered_categories = []
    for key in order + sorted([k for k in category_summary.keys() if k not in order]):
        if key in category_summary:
            row = dict(category_summary[key])
            row['category'] = key
            ordered_categories.append(row)
    ordered_tools = []
    for key, row in sorted(tool_summary.items(), key=lambda item: (item[1]['direct'], item[1]['bridge'], item[1]['total'], item[0]), reverse=True):
        payload = dict(row)
        payload['tool'] = key
        ordered_tools.append(payload)
    result = {
        'summary': counts,
        'categories': ordered_categories,
        'tools': ordered_tools,
        'rows': rows,
    }
    namespace['_suv_external_feature_parity_last'] = result
    return result


def _text_name(context) -> str:
    ws_fn = _NAMESPACE.get('_suv_ws')
    ws = ws_fn(context) if callable(ws_fn) else None
    base = getattr(ws, 'support_bundle_name', '') if ws else ''
    base = str(base).strip() or 'SUV_Support_Bundle'
    return base + _PARITY_REPORT_SUFFIX


def _text_block(name: str, clear=False):
    textio = _NAMESPACE.get('_quality_textio_module')
    if textio is not None and hasattr(textio, 'ensure_report_text'):
        try:
            return textio.ensure_report_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if textio is not None and hasattr(textio, 'ensure_namespace_text'):
        try:
            return textio.ensure_namespace_text(_NAMESPACE, name, clear=clear)
        except Exception:
            pass
    if bpy is None:
        return None
    txt = bpy.data.texts.get(name)
    if txt is None:
        if not clear:
            return None
        txt = bpy.data.texts.new(name)
    elif clear:
        txt.clear()
    return txt


def _result_has_cancelled(result) -> bool:
    checker = _NAMESPACE.get('_suv_result_has')
    if callable(checker):
        try:
            return bool(checker(result, 'CANCELLED'))
        except Exception:
            pass
    try:
        return 'CANCELLED' in set(result)
    except Exception:
        return False


def _call_action(action: dict):
    caller = _NAMESPACE.get('_suv_call_op')
    if not callable(caller):
        # 報告用の名前空間（quality_runtime_access._report_namespace）には _suv_call_op が入らないので、
        # 定義元の native_stage から引く。入っていないと bridge の全 action が CANCELLED になっていた（PD34C v2）
        try:
            from .native_stage import _suv_call_op as caller
        except Exception:
            return {'CANCELLED'}
    typ = str(action.get('type', '') or '').strip().lower()
    if typ == 'operator':
        return caller(str(action.get('idname', '') or ''), **dict(action.get('kwargs') or {}))
    if typ == 'compat_target':
        kwargs = {
            'target': str(action.get('target', '') or ''),
            'execution_mode': str(action.get('execution_mode', 'AUTO') or 'AUTO'),
        }
        return caller('uv.suv_apply_external_compat_target', **kwargs)
    if typ == 'workflow_recipe':
        return caller('uv.suv_apply_workflow_recipe', profile=str(action.get('profile', '') or ''))
    if typ == 'workflow_bundle':
        return caller('uv.suv_apply_workflow_bundle', profile=str(action.get('profile', '') or ''), use_bundle_actions=bool(action.get('use_bundle_actions', True)))
    if typ == 'auto_uv_profile':
        return caller('uv.suv_auto_uv_profile', profile=str(action.get('profile', '') or ''))
    return {'CANCELLED'}


def _favorite_targets():
    engine = _bridge_engine()
    if engine is not None and hasattr(engine, 'favorite_targets'):
        try:
            return list(engine.favorite_targets(_NAMESPACE) or [])
        except Exception:
            pass
    data = _compat_targets()
    fav = []
    for key in ('BLENDER_NATIVE', 'MAYA', 'DCC_LAYOUT_REFERENCE', 'UVPACKMASTER', 'SMART_CHECKER', 'SMART_TEXTURE', 'SMART_EDIT'):
        if key in data:
            fav.append((key, data[key]))
    return fav


def draw_external_feature_parity(layout, context):
    # Full parity/reference scans are performed at registration or by the
    # explicit report action. N-panel redraw consumes only the cached snapshot.
    data = _NAMESPACE.get('_suv_external_feature_parity_last')
    if not isinstance(data, dict):
        data = _empty_parity_data()
    summary = dict(data.get('summary') or {})
    box = layout.box()
    col = box.column(align=True)
    col.label(text=_tr(context, 'ui.parity_board.title', 'Parity Board', '上位互換ボード'), icon='BOOKMARKS')
    info = _tr(
        context,
        'ui.parity_board.info',
        'A compact coverage view of industry tools and the attached reference add-ons. Use the report to audit direct bridges, compatibility bridges, and still-partial areas.',
        '業界ツールと添付参照アドオンの対応状況をコンパクトに見られる一覧です。レポートを使うと、直接ブリッジ・互換ブリッジ・部分対応の残りを監査できます。'
    )
    info_row = col.row(align=True)
    info_row.scale_y = 0.9
    pass  # INFO-note moved to Help; no in-section info-icon explanation.
    summary_row = col.row(align=True)
    summary_row.label(text=f"D {int(summary.get('direct', 0))}", icon='CHECKMARK')
    summary_row.label(text=f"B {int(summary.get('bridge', 0))}", icon='PRESET')
    pass  # INFO-note moved to Help; no in-section info-icon explanation.
    summary_row.label(text=f"M {int(summary.get('missing', 0))}", icon='ERROR')
    btn = col.row(align=True)
    btn.operator(SUV_OT_quality_write_external_feature_parity.bl_idname, text=_tr(context, 'ui.parity_board.write', 'Write Report', 'レポート作成'), icon='TEXT')
    btn.operator(SUV_OT_quality_open_external_feature_parity.bl_idname, text=_tr(context, 'ui.parity_board.open', 'Open Report', 'レポートを開く'), icon='TEXT')
    grid = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
    for row in list(data.get('categories') or [])[:6]:
        sub = grid.box()
        scol = sub.column(align=True)
        scol.label(text=str(row.get('category', 'Other')), icon='UV')
        detail = f"Total {int(row.get('total', 0))} | D {int(row.get('direct', 0))} | B {int(row.get('bridge', 0))}"
        scol.label(text=detail, icon='DOT')
        extra = f"P {int(row.get('partial', 0))} | M {int(row.get('missing', 0))}"
        scol.label(text=extra, icon='DOT')
    fav = list(_NAMESPACE.get('_suv_external_feature_parity_favorites') or ())
    if fav:
        col.separator(factor=0.15)
        head = col.row(align=True)
        head.label(text=_tr(context, 'ui.parity_board.quick', 'Quick Compatibility Targets', '主要互換ターゲット'), icon='PRESET')
        quick = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False, align=True)
        for key, entry in fav:
            label = str(entry.get('label_ja') or entry.get('label') or key) if _is_ja(context) else str(entry.get('label') or entry.get('label_ja') or key)
            op = quick.operator('uv.suv_apply_external_compat_target', text=label, icon='PRESET')
            _safe_set_operator_props(op, {'target': key, 'execution_mode': 'AUTO'})
    return box


class SUV_OT_apply_feature_bridge(bpy.types.Operator):
    bl_idname = 'uv.suv_apply_feature_bridge'
    bl_label = 'Apply Feature Bridge'
    bl_description = 'Run the mapped UV Suite bridge for one reference feature row. This lets you launch a direct internal operator when available, or fall back to the nearest compatibility target for that tool family. / 参照機能1行に対応付けた UV Suite ブリッジを実行します。直接オペレーターがある場合はそれを、無い場合は近い互換ターゲットへフォールバックします。'
    bl_options = {'UNDO'}

    feature_key: bpy.props.StringProperty(
        name='Feature Key',
        description='Internal key of the reference feature entry to bridge / ブリッジ対象の参照機能キー',
        default='',
        options={'HIDDEN'},
    )
    strict: bpy.props.BoolProperty(
        name='Strict',
        description='Cancel the full run if any step in the mapped bridge sequence cancels / シーケンス中のいずれかが中断したら全体を中断扱いにします',
        default=False,
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        engine = _bridge_engine()
        if engine is not None and hasattr(engine, 'execute_feature_key'):
            result = engine.execute_feature_key(_NAMESPACE, str(self.feature_key or '').strip(), context=context, strict=bool(self.strict))
            if str(result.get('reason', '')) == 'missing_entry':
                self.report({'WARNING'}, _tr(context, 'msg.parity_entry_missing', 'Reference feature entry was not found.', '参照機能エントリが見つかりませんでした。'))
                return {'CANCELLED'}
            if str(result.get('reason', '')) == 'no_action':
                self.report({'WARNING'}, _tr(context, 'msg.parity_no_action', 'No mapped action exists for this feature row yet.', 'この機能行にはまだ実行アクションがありません。'))
                return {'CANCELLED'}
            if 'CANCELLED' in set(result.get('status', [])) and int(result.get('cancelled_steps', 0)):
                self.report({'WARNING'}, _tr(context, 'msg.parity_bridge_partial', 'Feature bridge finished with partial fallback or cancellation: {feature}', '機能ブリッジは一部フォールバックまたは中断を含みました: {feature}', feature=str(result.get('feature', '') or 'Feature')))
                return {'CANCELLED'} if self.strict else {'FINISHED'}
            self.report({'INFO'}, _tr(context, 'msg.parity_bridge_done', 'Feature bridge executed: {feature}', '機能ブリッジを実行しました: {feature}', feature=str(result.get('feature', '') or 'Feature')))
            return {'FINISHED'}
        entries = {str(row.get('key', '') or ''): dict(row) for row in _data_entries()}
        entry = entries.get(str(self.feature_key or '').strip(), None)
        if not entry:
            self.report({'WARNING'}, _tr(context, 'msg.parity_entry_missing', 'Reference feature entry was not found.', '参照機能エントリが見つかりませんでした。'))
            return {'CANCELLED'}
        actions = _entry_actions(entry)
        if not actions:
            self.report({'WARNING'}, _tr(context, 'msg.parity_no_action', 'No mapped action exists for this feature row yet.', 'この機能行にはまだ実行アクションがありません。'))
            return {'CANCELLED'}
        failed = []
        for action in actions:
            result = _call_action(action)
            if _result_has_cancelled(result):
                failed.append(action)
                if self.strict:
                    break
        if failed:
            self.report({'WARNING'}, _tr(context, 'msg.parity_bridge_partial', 'Feature bridge finished with partial fallback or cancellation: {feature}', '機能ブリッジは一部フォールバックまたは中断を含みました: {feature}', feature=str(entry.get('feature', '') or 'Feature')))
            return {'CANCELLED'} if self.strict else {'FINISHED'}
        self.report({'INFO'}, _tr(context, 'msg.parity_bridge_done', 'Feature bridge executed: {feature}', '機能ブリッジを実行しました: {feature}', feature=str(entry.get('feature', '') or 'Feature')))
        return {'FINISHED'}


class SUV_OT_quality_write_external_feature_parity(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_write_external_feature_parity'
    bl_label = 'Write External Feature Parity'
    bl_description = 'Write a coverage-style report for industry tools and the attached reference add-ons, including direct bridges, compatibility bridges, and still-partial rows. / 業界ツールと添付参照アドオンの対応状況を、直接ブリッジ・互換ブリッジ・部分対応を含めてレポート化します。'
    bl_options = set()

    open_after_write: bpy.props.BoolProperty(
        name='Open After Write',
        description='Open the written parity report in Blender Text Editor when possible / 可能なら書き出した上位互換レポートを Blender テキストエディタで開きます',
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        data = _refresh_parity_cache()
        summary = dict(data.get('summary') or {})
        lines = [
            'UV Suite External Feature Parity',
            f"Total reference rows: {int(summary.get('total', 0))}",
            f"Direct bridges: {int(summary.get('direct', 0))}",
            f"Compatibility bridges: {int(summary.get('bridge', 0))}",
            f"Partial rows: {int(summary.get('partial', 0))}",
            f"Missing rows: {int(summary.get('missing', 0))}",
            '',
            '[Category Summary]',
        ]
        for row in list(data.get('categories') or []):
            lines.append(
                f"- {row.get('category', 'Other')}: total={int(row.get('total', 0))} direct={int(row.get('direct', 0))} bridge={int(row.get('bridge', 0))} partial={int(row.get('partial', 0))} missing={int(row.get('missing', 0))}"
            )
        lines.extend(['', '[Feature Rows]'])
        sorted_rows = sorted(
            list(data.get('rows') or []),
            key=lambda row: (
                str(row.get('category', '') or ''),
                str(row.get('tool', '') or ''),
                str(row.get('feature', '') or ''),
            ),
        )
        for row in sorted_rows:
            actions = _entry_actions(row)
            action_desc = []
            for action in actions:
                typ = str(action.get('type', '') or '')
                if typ == 'operator':
                    action_desc.append('operator:' + str(action.get('idname', '') or ''))
                elif typ == 'compat_target':
                    action_desc.append('compat:' + str(action.get('target', '') or ''))
                elif typ == 'workflow_recipe':
                    action_desc.append('recipe:' + str(action.get('profile', '') or ''))
                elif typ == 'workflow_bundle':
                    action_desc.append('bundle:' + str(action.get('profile', '') or ''))
                elif typ == 'auto_uv_profile':
                    action_desc.append('profile:' + str(action.get('profile', '') or ''))
            lines.append(
                f"- [{str(row.get('resolved_coverage_state', 'missing') or 'missing').upper()}] {row.get('tool', 'Unknown')} :: {row.get('feature', 'Feature')}"
            )
            lines.append(f"  source={row.get('source_title_en', row.get('source', 'reference'))} | category={row.get('category', 'Other')} | key={row.get('key', '-')}")
            if action_desc:
                lines.append(f"  actions={', '.join(action_desc)}")
            suggestions = list(row.get('suggested_ops') or [])
            if suggestions:
                preview = ', '.join([str(s.get('idname', '') or '') for s in suggestions[:3] if str(s.get('idname', '') or '')])
                if preview:
                    lines.append(f"  suggestions={preview}")
            detail = str(row.get('detail_ja', '') or '').strip()
            if detail:
                lines.append(f"  detail_ja={detail}")
        textio = _NAMESPACE.get('_quality_textio_module')
        writer = getattr(textio, 'write_report_lines_consistent', None) if textio is not None else None
        if callable(writer):
            txt = writer(
                _NAMESPACE, context, _text_name, lines, _text_block, self,
                open_after_write=self.open_after_write,
                failed_key='msg.parity_open_failed',
                failed_en='Could not open external parity report: {name}',
                failed_ja='外部対応レポートを開けませんでした: {name}',
            )
            if txt is None:
                return {'CANCELLED'}
        else:
            txt = _text_block(_text_name(context), clear=True)
            if txt is None:
                return {'CANCELLED'}
            txt.write('\n'.join(lines))
        self.report({'INFO'}, _tr(context, 'msg.parity_written', 'External parity report written: {name}', '外部対応レポートを書き出しました: {name}', name=txt.name))
        return {'FINISHED'}


class SUV_OT_quality_open_external_feature_parity(bpy.types.Operator):
    bl_idname = 'uv.suv_quality_open_external_feature_parity'
    bl_label = 'Open External Feature Parity'
    bl_description = 'Open the latest external feature parity report in Blender Text Editor. / 最新の外部対応レポートを Blender のテキストエディタで開きます。'
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return bpy is not None and context is not None

    def execute(self, context):
        if bpy is None:
            return {'CANCELLED'}
        textio = _NAMESPACE.get('_quality_textio_module')
        if textio is not None and hasattr(textio, 'open_named_report_text_or_fallback'):
            return textio.open_named_report_text_or_fallback(
                _NAMESPACE, context, _text_name, self, _text_block,
                missing_key='msg.parity_missing',
                missing_en='No external parity report exists yet.',
                missing_ja='外部対応レポートはまだ作成されていません。',
                opened_key='msg.parity_opened',
                opened_en='Opened external parity report: {name}',
                opened_ja='外部対応レポートを開きました: {name}',
                failed_key='msg.parity_open_failed',
                failed_en='Could not open external parity report: {name}',
                failed_ja='外部対応レポートを開けませんでした: {name}',
            )
        txt = _text_block(_text_name(context), clear=False)
        if txt is None:
            self.report({'WARNING'}, _tr(context, 'msg.parity_missing', 'No external parity report exists yet.', '外部対応レポートはまだ作成されていません。'))
            return {'CANCELLED'}
        opener = _NAMESPACE.get('_suv_open_text_in_editor')
        if callable(opener):
            try:
                opener(context, txt)
                self.report({'INFO'}, _tr(context, 'msg.parity_opened', 'Opened external parity report: {name}', '外部対応レポートを開きました: {name}', name=txt.name))
                return {'FINISHED'}
            except Exception:
                pass
        self.report({'WARNING'}, _tr(context, 'msg.parity_open_failed', 'Could not open external parity report: {name}', '外部対応レポートを開けませんでした: {name}', name=getattr(txt, 'name', '-')))
        return {'CANCELLED'}


def register(namespace: dict):
    global _NAMESPACE, _REGISTERED
    _NAMESPACE = namespace or {}
    if bpy is None:
        return []
    classes = [
        SUV_OT_apply_feature_bridge,
        SUV_OT_quality_write_external_feature_parity,
        SUV_OT_quality_open_external_feature_parity,
    ]
    registered = []
    for cls in classes:
        try:
            _suv_resource.register_class(cls)
            registered.append(cls)
        except Exception:
            pass
    _REGISTERED = registered
    _refresh_parity_cache()
    return registered


def unregister(namespace: dict):
    global _NAMESPACE, _REGISTERED
    _NAMESPACE = namespace or {}
    removed = []
    if bpy is None:
        _REGISTERED = []
        return removed
    for cls in reversed(_REGISTERED):
        try:
            _suv_resource.unregister_class(cls)
            removed.append(cls)
        except Exception:
            pass
    _REGISTERED = []
    return removed
