# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi.
"""Smart Rig preferences implemented from the observable RNA/UI contract.

This module stores only the Smart Rig configuration interface. It delegates
ownership, persistence, and optional Proxy Picker guarding to the suite's
existing services. It neither imports nor distributes external rigging tools.
"""

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, StringProperty

from . import generation
from .i18n import ui_tr as _translate_ui
from .lifecycle import register_classes, unregister_owned_classes

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()
ADDON_ID = __package__ or "smart_rig_suite"
CLASSES = ()
_REGISTERED = False
_TRANSLATIONS_REGISTERED = False

# English RNA declarations are translated by Blender when its UI locale is ja_JP.
# Only one language is shown at a time. Drawn headings use the suite's UI locale.
_JAPANESE = {
    "AI Runtime Path": "AIランタイムのフォルダー",
    "Synchronize validated AI path automatically": "確認済みAIパスを自動同期",
    "Proxy Bone Prefix": "プロキシボーンの接頭辞",
    "Target Bone Prefix": "対象ボーンの接頭辞",
    "Report Text Name": "レポートのテキスト名",
    "Weight Sum Tolerance": "ウェイト合計の許容差",
    "Maximum Influences": "最大ウェイト影響数",
    "Tiny Weight Threshold": "微小ウェイトのしきい値",
    "Guard Proxy Picker restricted contexts": "Proxy Pickerの制限コンテキストを保護",
    "Select the installed AI_win runtime folder containing info.dat and inference files. The folder must already exist; this setting does not download, install, or copy any AI executable or model.":
        "別途導入済みのAI_winランタイムのフォルダーを指定します。info.datとinference内の実行ファイル・モデルが必要です。この設定ではダウンロード、インストール、コピーは行いません。",
    "When enabled, a valid installed AI runtime path is passed to Auto-Rig Pro before an AI operation. Turn it off to keep Auto-Rig Pro's stored path unchanged.":
        "有効にすると、検証できたAIランタイムのパスをAI操作の直前にAuto-Rig Proへ渡します。Auto-Rig Pro側の設定を変更したくない場合は無効にしてください。",
    "Prefix used to find proxy bones when pairing by name. For example, proxy_arm.L has the prefix proxy_.":
        "名前による一括ペア設定で、プロキシボーンを見分ける文字列です。例：proxy_arm.L の接頭辞は proxy_ です。",
    "Prefix identifying the target bones paired with each proxy bone. For example, c_arm.L uses c_.":
        "プロキシボーンに対応させる対象ボーンの接頭辞です。例：c_arm.L の接頭辞は c_ です。",
    "Name of the Blender Text data block that receives audit and integration reports. Choose a distinct name to avoid mixing reports with unrelated text.":
        "監査・外部連携の結果を保存するBlenderのテキストデータ名です。別のテキストと混ざらないよう固有の名前を指定します。",
    "Maximum deviation from a total vertex weight of 1.0 before a normalization warning is reported. Smaller values make the audit stricter.":
        "頂点のウェイト合計が1.0からどれだけずれたら警告するかを設定します。値を小さくするほど厳密に検査します。",
    "Maximum number of nonzero deform-bone weights allowed on one vertex before reporting it. Four is a common target for real-time rigs.":
        "1頂点に許可する変形ボーンの有効ウェイト数です。この数を超える頂点を報告します。リアルタイム用途では4が一般的な目安です。",
    "Weights smaller than this threshold are reported as tiny influences. Set 0 to disable this particular check.":
        "この値より小さいウェイトを微小な影響として報告します。0にすると微小ウェイトの検査だけを無効にします。",
    "Enable only if a separately installed Proxy Picker reports errors in restricted Blender contexts. It guards the external callback without changing its files. Turn off to remove the optional Smart Rig guard.":
        "別途導入したProxy Pickerが制限されたBlenderコンテキストでエラーを出す場合だけ有効にします。外部ファイルを変更せずにコールバックを保護し、無効にするとSmart Rig側の追加ガードを解除します。",
}
_TRANSLATIONS = {"ja_JP": {("*", english): japanese for english, japanese in _JAPANESE.items()}}


def get_preferences(context=None):
    """Resolve preferences in native, user_default Extension, and nested packages."""
    try:
        scope = bpy.context if context is None else context
        installed = scope.preferences.addons
    except Exception:
        return None
    names = (ADDON_ID, "smart_rig_suite", "bl_ext.user_default.smart_rig_suite")
    for name in dict.fromkeys(names):
        try:
            registration = installed.get(name)
            if registration is not None:
                value = getattr(registration, "preferences", None)
                if value is not None:
                    return value
        except Exception:
            continue
    return None


def _changed(owner, context):
    """Notify the existing persistence service without introducing a watcher."""
    try:
        from . import persistence
        persistence.property_updated(owner, context)
    except Exception:
        # UI property edits must remain possible if persistence is unloading.
        pass


def _guard_changed(owner, context):
    _changed(owner, context)
    try:
        from . import compatibility
        compatibility.set_guard_enabled(bool(owner.guard_proxy_picker_context))
    except Exception:
        # This optional adapter may be absent during add-on shutdown.
        pass


def _heading(layout, english, japanese, topic):
    row = layout.row(align=True)
    halves = row.split(factor=0.84, align=True)
    halves.label(text=_translate_ui(english, japanese))
    help_button = halves.row(align=True).operator(
        "srs.show_section_help", text="", icon="QUESTION", emboss=False
    )
    help_button.topic = topic


class SRS_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID

    ai_runtime_path: StringProperty(
        name="AI Runtime Path",
        description="Select the installed AI_win runtime folder containing info.dat and inference files. The folder must already exist; this setting does not download, install, or copy any AI executable or model.",
        subtype="DIR_PATH", default="", update=_changed,
    )
    auto_sync_ai_path: BoolProperty(
        name="Synchronize validated AI path automatically",
        description="When enabled, a valid installed AI runtime path is passed to Auto-Rig Pro before an AI operation. Turn it off to keep Auto-Rig Pro's stored path unchanged.",
        default=True, update=_changed,
    )
    proxy_prefix: StringProperty(
        name="Proxy Bone Prefix",
        description="Prefix used to find proxy bones when pairing by name. For example, proxy_arm.L has the prefix proxy_.",
        default="proxy_", update=_changed,
    )
    target_prefix: StringProperty(
        name="Target Bone Prefix",
        description="Prefix identifying the target bones paired with each proxy bone. For example, c_arm.L uses c_.",
        default="c_", update=_changed,
    )
    report_text_name: StringProperty(
        name="Report Text Name",
        description="Name of the Blender Text data block that receives audit and integration reports. Choose a distinct name to avoid mixing reports with unrelated text.",
        default="Smart Rig Suite Report", update=_changed,
    )
    weight_sum_tolerance: FloatProperty(
        name="Weight Sum Tolerance",
        description="Maximum deviation from a total vertex weight of 1.0 before a normalization warning is reported. Smaller values make the audit stricter.",
        default=0.001, min=0.000001, max=0.25, precision=6, update=_changed,
    )
    maximum_influences: IntProperty(
        name="Maximum Influences",
        description="Maximum number of nonzero deform-bone weights allowed on one vertex before reporting it. Four is a common target for real-time rigs.",
        default=4, min=1, max=32, update=_changed,
    )
    tiny_weight_threshold: FloatProperty(
        name="Tiny Weight Threshold",
        description="Weights smaller than this threshold are reported as tiny influences. Set 0 to disable this particular check.",
        default=0.0001, min=0.0, max=0.1, precision=6, update=_changed,
    )
    guard_proxy_picker_context: BoolProperty(
        name="Guard Proxy Picker restricted contexts",
        description="Enable only if a separately installed Proxy Picker reports errors in restricted Blender contexts. It guards the external callback without changing its files. Turn off to remove the optional Smart Rig guard.",
        default=False, update=_guard_changed,
    )

    def draw(self, context):
        column = self.layout
        section = column.box()
        _heading(section, "External AI Runtime", "外部AIランタイム", "ai")
        section.prop(self, "ai_runtime_path")
        section.prop(self, "auto_sync_ai_path")

        section = column.box()
        _heading(section, "Proxy Picker Batch Pairing", "Proxy Picker一括ペア設定", "proxy_roles")
        pair = section.row(align=True)
        pair.prop(self, "proxy_prefix")
        pair.prop(self, "target_prefix")

        section = column.box()
        _heading(section, "Audit and Weight Quality", "監査・ウェイト品質", "prefs_audit")
        section.prop(self, "report_text_name")
        audit = section.row(align=True)
        audit.prop(self, "weight_sum_tolerance")
        audit.prop(self, "maximum_influences")
        section.prop(self, "tiny_weight_threshold")


CLASSES = (SRS_AddonPreferences,)


def _enable_translations():
    global _TRANSLATIONS_REGISTERED
    if _TRANSLATIONS_REGISTERED:
        return
    bpy.app.translations.register(__name__, _TRANSLATIONS)
    _TRANSLATIONS_REGISTERED = True


def _disable_translations():
    global _TRANSLATIONS_REGISTERED
    if _TRANSLATIONS_REGISTERED:
        bpy.app.translations.unregister(__name__)
        _TRANSLATIONS_REGISTERED = False


def register():
    """Register exactly one owned RNA class using the existing lifecycle API."""
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        return False
    register_classes(
        CLASSES, module_name=__name__, revision=__srs_revision__,
        module_marker=__srs_module_generation_marker__,
    )
    try:
        _enable_translations()
    except Exception:
        # Roll back our class if the localization contract cannot be installed.
        unregister_owned_classes(module_name=__name__, attempts=2)
        raise
    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    return True


def unregister():
    """Leave other registered classes and external add-ons untouched."""
    global _REGISTERED
    report = unregister_owned_classes(module_name=__name__, attempts=2)
    if report.get("all_removed", False):
        _disable_translations()
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return report
