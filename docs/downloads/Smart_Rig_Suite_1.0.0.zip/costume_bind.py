# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Bind a costume to a rig by inheriting the skin's own weights, not by proximity.

Every part of a costume lies on a body that is already bound and already tuned.
Heat-mapping the part against the armature throws that away and produces a second,
independent solve that disagrees with the skin at every joint; copying the skin's
weights keeps the two in step by construction.

It also settles the questions proximity cannot. Measured on this character: the
twelve fingernail islands vote 100 per cent unanimously for index3 twice, thumb3
twice, ring3 four times and pinky3 four times, and give the middle finger nothing
at all, although c_middle3 exists 3.6mm from c_index3. A nearest-bone verdict can
be unanimous, confident and anatomically wrong. The body's own finger weights are
not a vote -- they are where that geometry actually goes when the hand closes.

What this module adds on top of the transfer:

* ``islands`` and ``collapse_rigid_islands`` -- a nail, a zip tooth or a stud is
  one solid piece and should ride one bone. After the transfer, an island whose
  dominant group already holds most of its weight is collapsed to that bone at
  1.0, which is decided by the transfer rather than by distance.
* ``follow_quality`` -- the acceptance test that matters for a garment. Not "did
  it move", which any binding passes, but "did it keep its place on the body":
  each vertex is tied to a spot on the donor surface at rest and the drift from
  that spot is measured under pose. A sleeve bound to the wrong side of a joint
  still moves; it stops shadowing the arm.
* ``rigidity`` -- for a solid part, how much its own edges stretch under pose. A
  nail that shears is a nail bound to two fingers.
"""

import bpy
import mathutils
import mathutils.kdtree

from .i18n import tr_format

AXIS = {"X": 0, "Y": 1, "Z": 2}
RIGID_DOMINANCE = 0.85
# Set on a mesh Bind Costume Part has bound, so that it is not taken for the skin later.
COSTUME_PART_KEY = "srs_costume_part"
# A mesh on fewer than this share of the richest mesh's bones is an accessory, not a body.
# Low because a body and a face rig differ a lot in bone count, and both are skin.
SKIN_MIN_BONE_SHARE = 0.25
# Below this a part is not solid enough to justify throwing its other influences
# away. Measured: a fingernail reads 0.99 and a shoe sole 0.42.


def islands(mesh_object):
    """Connected components as lists of vertex indices."""
    import bmesh

    if mesh_object is None or mesh_object.type != "MESH":
        return []
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh_object.data)
        bm.verts.ensure_lookup_table()
        seen = set()
        groups = []
        for vertex in bm.verts:
            if vertex.index in seen:
                continue
            stack = [vertex]
            found = set()
            while stack:
                current = stack.pop()
                if current.index in found:
                    continue
                found.add(current.index)
                for edge in current.link_edges:
                    other = edge.other_vert(current)
                    if other.index not in found:
                        stack.append(other)
            seen |= found
            groups.append(sorted(found))
        return groups
    finally:
        bm.free()


def _weights(mesh_object):
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    out = {}
    for vertex in mesh_object.data.vertices:
        row = {}
        for entry in vertex.groups:
            if entry.weight > 0.0:
                row[names[entry.group]] = entry.weight
        out[vertex.index] = row
    return out


def collapse_candidates(mesh_object, armature):
    """Bones a solid part may be collapsed onto.

    The additive rig's blockers are excluded, and they have to be: they carry MORE
    weight on the skin than the bones that move it. Measured on this character,
    the first pass collapsed the ring onto ``hand_bend.l``, both shoe zips onto
    ``c_leg_bend_02``, and the collar, the headset and every piercing onto
    ``epaules_bend.x`` -- all of them rig_add-only bones that exist to STOP the
    additive bend from reaching skin, and none of which moves. Every one of those
    parts then sat perfectly still while the body turned, and the drift measured
    exactly the body's own motion: 230mm on the collar, 106mm on the face studs.

    A part keeps those groups from the transfer -- that is how the additive rig is
    meant to work -- but it must never be collapsed ONTO one.
    """
    from . import weight_tools

    if mesh_object is None or armature is None:
        return set()
    return weight_tools.main_rig_bones(mesh_object, armature)


def island_dominance(mesh_object, parts=None, allowed=None):
    """For each island, which bone holds how much of its weight. ``(rows, error)``."""
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    weights = _weights(mesh_object)
    permitted = None if allowed is None else set(allowed)
    rows = []
    for part in (parts if parts is not None else islands(mesh_object)):
        totals = {}
        for index in part:
            for name, value in weights.get(index, {}).items():
                if permitted is not None and name not in permitted:
                    continue
                totals[name] = totals.get(name, 0.0) + value
        total = sum(totals.values())
        if not totals or total <= 0.0:
            rows.append({"verts": len(part), "dominant": "", "share": 0.0,
                         "bones": 0, "indices": part})
            continue
        best = max(totals.items(), key=lambda kv: kv[1])
        rows.append({"verts": len(part), "dominant": best[0],
                     "share": round(best[1] / total, 4),
                     "bones": len(totals), "indices": part,
                     "runner_up": sorted(totals.items(),
                                         key=lambda kv: -kv[1])[1:3]})
    return rows, ""


def collapse_rigid_islands(mesh_object, threshold=RIGID_DOMINANCE, parts=None,
                           force_bone=None, always=False, armature=None,
                           allowed=None):
    """Give each solid island one bone at 1.0. ``(report, error)``.

    By default only islands whose dominant group already holds ``threshold`` of
    the island's weight are collapsed, so the decision comes from the transfer
    rather than from a distance.

    ``always`` collapses every island to whichever bone the transfer ranked first,
    whatever its share. That is for a part the modeller built as one solid piece:
    a ring transferred from the hand reads only 0.5-0.6 dominance because the skin
    under it genuinely deforms, and left that way the ring stretched its own edges
    by 74.5 per cent when the finger curled. The share is still reported, because
    a low share on a part declared solid is worth reading.

    ``force_bone`` overrides the choice for every island, for the cases where a
    human has to say which bone a part belongs to.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    permitted = allowed
    if permitted is None and armature is not None:
        permitted = collapse_candidates(mesh_object, armature)
    rows, error = island_dominance(mesh_object, parts, allowed=permitted)
    if error:
        return None, error
    collapsed, left = [], []
    for row in rows:
        bone = force_bone or row["dominant"]
        if not bone or (force_bone is None and not always
                        and row["share"] < threshold):
            left.append({"verts": row["verts"], "dominant": row["dominant"],
                         "share": row["share"], "bones": row["bones"]})
            continue
        group = mesh_object.vertex_groups.get(bone)
        if group is None:
            group = mesh_object.vertex_groups.new(name=bone)
        for other in mesh_object.vertex_groups:
            if other.name != bone:
                other.remove(row["indices"])
        group.add(row["indices"], 1.0, "REPLACE")
        collapsed.append({"verts": row["verts"], "bone": bone,
                          "share": row["share"]})
    return {"mesh": mesh_object.name, "islands": len(rows),
            "collapsed": collapsed, "collapsed_count": len(collapsed),
            "left_deforming": left, "threshold": threshold,
            "candidates": 0 if permitted is None else len(permitted)}, ""


def _evaluated_world(mesh_object, use_modifiers=True):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    if use_modifiers:
        data = mesh_object.evaluated_get(depsgraph).data
    else:
        data = mesh_object.data
    matrix = mesh_object.matrix_world
    return [matrix @ v.co for v in data.vertices]


def _surface_tree(mesh_object):
    from mathutils.bvhtree import BVHTree

    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = mesh_object.evaluated_get(depsgraph)
    matrix = mesh_object.matrix_world
    points = [matrix @ v.co for v in evaluated.data.vertices]
    polygons = [list(p.vertices) for p in evaluated.data.polygons]
    if not polygons:
        return None, None
    return BVHTree.FromPolygons(points, polygons, all_triangles=False,
                                epsilon=0.0), points


def follow_quality(target, donor, armature, poses, sample=None,
                   contact_mm=None):
    """Does the part keep its place on the body when the body moves?

    ``(report, error)``. Each target vertex is tied to the donor triangle it sits
    over at rest, with its offset stored in that triangle's own frame; posed, the
    same triangle says where the vertex should be. The drift from that spot is the
    number, in millimetres.

    This is the acceptance test a garment needs. "It moved" is passed by any
    binding at all, including one that took its weights from the wrong side of a
    joint -- that sleeve still moves, it just stops following the arm. Nearest-
    point distance is not usable either: on a folded surface the nearest point
    jumps across the fold and the metric reports a change that is not there.

    ``contact_mm`` restricts the measurement to the vertices that actually touch
    the donor at rest. A SOLID part must be judged that way: a stud is meant to
    stay rigid while the skin under it stretches, so measuring its far face
    against the skin penalises it for doing exactly what it should. What has to
    hold is that the part stays ATTACHED where it meets the body.
    """
    from . import corrective
    from . import face_regions

    if target is None or donor is None or armature is None:
        return None, "Need the part, the donor and the armature"
    # None means the whole evaluated mesh. Passing the BASE vertex count here
    # silently sampled the first N vertices of a subdivided mesh, which are not
    # the original ones.
    # The measurement must not depend on the user's visibility state: an object
    # in an excluded collection is not evaluated at all, so its posed positions
    # come back equal to its rest positions and the drift reads as the donor's
    # whole motion. That is how a correctly bound collar measured 229mm.
    shown = visible_for_edit([target, donor])
    indices = sample
    if contact_mm is not None:
        tree, _points = _surface_tree(donor)
        if tree is None:
            return None, "The donor evaluates to no faces"
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = target.evaluated_get(depsgraph)
        matrix = target.matrix_world
        indices = []
        for vertex in evaluated.data.vertices:
            hit = tree.find_nearest(matrix @ vertex.co)
            if hit[0] is not None and ((matrix @ vertex.co) - hit[0]).length \
                    * 1000 <= contact_mm:
                indices.append(vertex.index)
        if not indices:
            return None, ("no vertex of %s comes within %.2fmm of %s, so there "
                          "is no contact patch to judge"
                          % (target.name, contact_mm, donor.name))
    mapping, error = corrective.surface_correspondence(target, donor, indices)
    if error:
        return None, error
    saved = face_regions._pose_snapshot(armature)
    try:
        face_regions.apply_pose(armature, poses)
        bpy.context.view_layer.update()
        wanted = corrective.reconstruct_on_surface(donor, mapping)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = target.evaluated_get(depsgraph)
        matrix = target.matrix_world
        drift = []
        for index, spot in wanted.items():
            if index < len(evaluated.data.vertices):
                point = matrix @ evaluated.data.vertices[index].co
                drift.append(((point - spot).length * 1000, index))
    finally:
        face_regions._pose_restore(saved)
        bpy.context.view_layer.update()
        restore_visibility(shown)
    if not drift:
        return None, "No vertex could be tied to the donor surface"
    drift.sort()
    values = [d for d, _i in drift]
    return {"target": target.name, "donor": donor.name,
            "vertices": len(values),
            "contact_mm": contact_mm,
            "worst_mm": round(values[-1], 4),
            "worst_vertex": drift[-1][1],
            "p95_mm": round(values[int(0.95 * (len(values) - 1))], 4),
            "median_mm": round(values[len(values) // 2], 4)}, ""


def rigidity(mesh_object, armature, poses, indices=None):
    """How much a part's own edges stretch under pose, as a percentage.

    A solid part -- a nail, a stud, a zip tooth -- should read near zero. A part
    bound across two bones shears, and the shear shows here long before it shows
    in a screenshot.
    """
    from . import face_regions

    if mesh_object is None or armature is None:
        return None, "Need the mesh and the armature"
    scope = None if indices is None else set(indices)
    edges = [tuple(e.vertices) for e in mesh_object.data.edges
             if scope is None or (e.vertices[0] in scope and e.vertices[1] in scope)]
    if not edges:
        return None, "No edge in the region"
    shown = visible_for_edit([mesh_object])
    saved = face_regions._pose_snapshot(armature)
    try:
        rest = _evaluated_world(mesh_object)
        face_regions.apply_pose(armature, poses)
        bpy.context.view_layer.update()
        posed = _evaluated_world(mesh_object)
    finally:
        face_regions._pose_restore(saved)
        bpy.context.view_layer.update()
        restore_visibility(shown)
    if len(rest) != len(posed):
        return None, "The part evaluates to a different vertex count when posed"
    changes = []
    for a, b in edges:
        if a >= len(rest) or b >= len(rest):
            continue
        before = (rest[a] - rest[b]).length
        if before < 1.0e-6:
            continue
        after = (posed[a] - posed[b]).length
        changes.append(abs(after - before) / before * 100.0)
    if not changes:
        return None, "Every edge in the region is degenerate"
    changes.sort()
    return {"mesh": mesh_object.name, "edges": len(changes),
            "worst_pct": round(changes[-1], 3),
            "p95_pct": round(changes[int(0.95 * (len(changes) - 1))], 3),
            "median_pct": round(changes[len(changes) // 2], 3)}, ""


def hanging_islands(mesh_object, axis="Z", span_mm=300.0, min_verts=200):
    """Islands long enough to need a chain of their own. ``(rows, error)``.

    A part that hangs cannot be bound by proximity at all: the two belt straps on
    this character reach 450mm from the nearest skin and their vertices name
    fifteen different nearest bones, the best of which claims 24 per cent. There
    is nothing to transfer from and nothing to be rigid to; what they need is
    bones of their own.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    index = {"X": 0, "Y": 1, "Z": 2}[axis.upper()]
    matrix = mesh_object.matrix_world
    rows = []
    for part in islands(mesh_object):
        if len(part) < min_verts:
            continue
        values = [(matrix @ mesh_object.data.vertices[i].co)[index]
                  for i in part]
        span = (max(values) - min(values)) * 1000
        if span < span_mm:
            continue
        rows.append({"verts": part, "count": len(part),
                     "span_mm": round(span, 1),
                     "top": max(values), "bottom": min(values)})
    return rows, ""


def _centreline(mesh_object, indices, axis="Z", bins=24):
    import mathutils

    index = {"X": 0, "Y": 1, "Z": 2}[axis.upper()]
    matrix = mesh_object.matrix_world
    points = [matrix @ mesh_object.data.vertices[i].co for i in indices]
    top = max(p[index] for p in points)
    bottom = min(p[index] for p in points)
    if abs(top - bottom) < 1.0e-6:
        return [points[0].copy()]
    buckets = [[] for _ in range(max(2, bins))]
    for point in points:
        t = (top - point[index]) / (top - bottom)
        slot = min(len(buckets) - 1, max(0, int(t * len(buckets))))
        buckets[slot].append(point)
    line = []
    for bucket in buckets:
        if bucket:
            total = mathutils.Vector((0.0, 0.0, 0.0))
            for point in bucket:
                total += point
            line.append(total / len(bucket))
    return line if len(line) >= 2 else [points[0].copy(), points[-1].copy()]


# A hanging part should not hang from a finger. Measured: the nearest bone to
# the top of the belt straps is c_index1_base, 35.6mm away, so curling one finger
# would swing a metre of ribbon. These names are penalised, not banned -- if a
# part really does hang from a finger, nothing else will be closer even doubled.
ANCHOR_PENALISED = ("thumb", "index", "middle", "ring", "pinky", "toe",
                    "eyelid", "eyebrow", "lips", "tong", "teeth")
ANCHOR_PENALTY = 2.5
# Chain bones hang from the body; nothing new should be weighted to them for being near.
ANCHOR_NOT_FROM = ("hair_", "srs_chain_")


def anchor_bone(mesh_object, armature, indices, axis="Z", top_fraction=0.08,
                penalise=ANCHOR_PENALISED, penalty=ANCHOR_PENALTY):
    """The deform bone a hanging part should hang FROM. ``(name, error)``.

    Chosen from the part's top edge only. Its whole-object nearest bone is
    useless for this: the belt reads c_spine_02_bend.x at 4.3mm although its two
    straps start at the wrist and end at the shin.
    """
    from . import weight_tools

    if mesh_object is None or armature is None:
        return "", "Need the mesh and the armature"
    allowed = weight_tools.main_rig_bones(mesh_object, armature)
    if not allowed:
        allowed = {b.name for b in armature.data.bones if b.use_deform}
    allowed = {n for n in allowed if not n.startswith(ANCHOR_NOT_FROM)}
    index = {"X": 0, "Y": 1, "Z": 2}[axis.upper()]
    matrix = mesh_object.matrix_world
    points = [matrix @ mesh_object.data.vertices[i].co for i in indices]
    top = max(p[index] for p in points)
    bottom = min(p[index] for p in points)
    cut = top - (top - bottom) * top_fraction
    head_points = [p for p in points if p[index] >= cut] or points
    rig_matrix = armature.matrix_world
    best, best_score, best_distance = "", None, None
    ranked = []
    for name in allowed:
        bone = armature.data.bones.get(name)
        if bone is None:
            continue
        head = rig_matrix @ bone.head_local
        tail = rig_matrix @ bone.tail_local
        axis_vector = tail - head
        length_sq = axis_vector.length_squared
        nearest = None
        for point in head_points:
            if length_sq > 1.0e-18:
                t = max(0.0, min(1.0, (point - head).dot(axis_vector) / length_sq))
                distance = (point - (head + axis_vector * t)).length
            else:
                distance = (point - head).length
            if nearest is None or distance < nearest:
                nearest = distance
        if nearest is None:
            continue
        score = nearest
        if any(word in name for word in (penalise or ())):
            score *= float(penalty)
        ranked.append((round(nearest * 1000, 2), round(score * 1000, 2), name))
        if best_score is None or score < best_score:
            best, best_score, best_distance = name, score, nearest
    ranked.sort()
    return best, "" if best else "No deform bone is near the top of the part"


def division_rings(mesh_object, indices=None, seed=None, axis="Z",
                   from_top=True, per_island=False):
    """The part's own polygon divisions, found by topology. ``(rings, error)``.

    Each ring is ``{"hop", "indices", "centre", "span_mm"}``, ordered from the
    seed outward. A ring is the set of vertices the same number of edge hops from
    the seed, which is what a division is on a tube: clustering by coordinate
    instead fails the moment the part hangs at an angle. Measured on this
    character's belt strap, a 0.8mm coordinate cluster produced "rings" of 1 to 9
    vertices spaced 1-2mm apart -- noise, not divisions, because the strap is a
    tube that leans.

    ``seed`` is the vertex the walk starts from; without one the extreme along
    ``axis`` is used (the top, with ``from_top``), which is where a hanging part
    attaches.

    ``per_island`` returns one entry per connected piece. An object that holds
    several strands is the normal case here, not the exception: one hair object
    of 2218 vertices walked from a single seed reached 292 of them and left 1926
    behind, because the other strands are not joined to the first. A walk that
    silently covers one piece of a mesh is worse than one that refuses.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    mesh = mesh_object.data
    scope = set(indices) if indices is not None else {v.index
                                                     for v in mesh.vertices}
    if not scope:
        return None, "No vertices were given"
    axis_index = AXIS.get(str(axis).upper())
    if axis_index is None:
        return None, "Axis must be X, Y or Z"
    matrix = mesh_object.matrix_world
    world = {i: matrix @ mesh.vertices[i].co for i in scope}

    links = {}
    for edge in mesh.edges:
        a, b = edge.vertices
        if a in scope and b in scope:
            links.setdefault(a, []).append(b)
            links.setdefault(b, []).append(a)

    if per_island:
        pieces = []
        left = set(scope)
        while left:
            start = next(iter(left))
            piece, front = {start}, [start]
            while front:
                nxt = []
                for index in front:
                    for other in links.get(index, ()):
                        if other not in piece:
                            piece.add(other)
                            nxt.append(other)
                front = nxt
            left -= piece
            pieces.append(sorted(piece))
        rows = []
        for piece in sorted(pieces, key=len, reverse=True):
            report, error = division_rings(mesh_object, indices=piece,
                                           axis=axis, from_top=from_top)
            if error:
                continue
            report["island"] = len(rows)
            rows.append(report)
        return {"islands": rows, "count": len(rows),
                "rings": rows[0]["rings"] if rows else []}, ""

    def walk(start):
        hop = {i: 0 for i in start}
        front = list(start)
        while front:
            nxt = []
            for index in front:
                for other in links.get(index, ()):
                    if other not in hop:
                        hop[other] = hop[index] + 1
                        nxt.append(other)
            front = nxt
        return hop

    if seed is None:
        ordered = sorted(scope, key=lambda i: world[i][axis_index],
                         reverse=from_top)
        seed = ordered[0]
        start = [i for i in scope
                 if abs(world[i][axis_index]
                        - world[seed][axis_index]) < 0.0015]
        hop = walk(start)
        # A seed that is a corner rather than a cross-section makes the front
        # grow before it settles: measured on the belt strap, rings of 2, 6, 10,
        # 14, 18 before stabilising at 20, and the first five centroids sit
        # nowhere on the part. Find the first full cross-section and walk again
        # from there, so every ring reported is a real division.
        sizes = {}
        for index, level in hop.items():
            sizes[level] = sizes.get(level, 0) + 1
        if len(sizes) > 4:
            median = sorted(sizes.values())[len(sizes) // 2]
            full = None
            for level in sorted(sizes):
                if sizes[level] >= 0.6 * median:
                    full = level
                    break
            if full:
                start = [i for i, level in hop.items() if level == full]
                hop = walk(start)
    else:
        start = [seed]
        hop = walk(start)

    buckets = {}
    for index, level in hop.items():
        buckets.setdefault(level, []).append(index)
    rings = []
    for level in sorted(buckets):
        members = buckets[level]
        points = [world[i] for i in members]
        centre = sum(points, mathutils.Vector((0.0, 0.0, 0.0))) / len(points)
        spread = max((p - centre).length for p in points) if points else 0.0
        rings.append({"hop": level, "indices": sorted(members),
                      "centre": centre, "verts": len(members),
                      "span_mm": round(spread * 2000.0, 2)})
    missed = len(scope) - len(hop)
    return {"rings": rings, "seed": seed, "unreached": missed,
            "count": len(rings)}, ""


def rigid_spans(mesh_object=None, objects=(), axis="Z", match="metal",
                threshold=0.95):
    """Where a pivot must not fall. ``(spans, error)``.

    A span is ``(high, low, name)`` in millimetres on ``axis``. Two sources, both
    of which occur on this character: separate objects whose name says what they
    are (the hair's ``*_metalA``..``*_metalJ``), and material islands inside one
    mesh (the costume's metal faces). A rigid element must keep its shape, so a
    joint inside one bends something that cannot bend.
    """
    axis_index = AXIS.get(str(axis).upper())
    if axis_index is None:
        return None, "Axis must be X, Y or Z"
    spans = []
    for obj in objects or ():
        if obj is None or obj.type != "MESH" or not obj.data.vertices:
            continue
        matrix = obj.matrix_world
        values = [(matrix @ v.co)[axis_index] for v in obj.data.vertices]
        spans.append((round(max(values) * 1000.0, 2),
                      round(min(values) * 1000.0, 2), obj.name))
    if mesh_object is not None:
        groups, error = material_islands(mesh_object, match=match,
                                         threshold=threshold)
        if error:
            return None, error
        matrix = mesh_object.matrix_world
        for n, row in enumerate(groups or ()):
            # material_islands yields {"indices", "share"}, not bare lists
            group = row["indices"] if isinstance(row, dict) else row
            values = [(matrix @ mesh_object.data.vertices[i].co)[axis_index]
                      for i in group]
            if not values:
                continue
            spans.append((round(max(values) * 1000.0, 2),
                          round(min(values) * 1000.0, 2),
                          "%s island %d" % (match, n)))
    spans.sort(reverse=True)
    return spans, ""


def plan_pivots(rings, spans=(), axis="Z", every=1, budget=0, margin_mm=0.3,
                max_gap_mm=0.0):
    """Choose which divisions become joints. ``(plan, error)``.

    Rules, in order:

    * **Never inside a rigid element.** A division that falls between a span's
      high and low is dropped, and the element's own two boundaries are added
      instead -- the top and the bottom of a metal part are exactly where a hair
      strand is free to bend.
    * **Keep the spacing even.** ``max_gap_mm`` is the way to ask for that and
      should normally be what you use: every element boundary becomes a joint,
      and the soft stretches between them are then filled from their own
      divisions until no gap is wider than that. A ``budget`` instead forces a
      count, and a count fights the boundaries -- measured on a braid with nine
      metal elements, a budget of 14 produced gaps from 7.8mm to 395.5mm, which
      is the finely-cut-and-coarse mixture this is meant to avoid.
    * ``every`` thins before anything else: 2 means one joint per two divisions.

    An element's boundary is inserted at its own coordinate, not snapped to the
    nearest division. Snapping put a joint 849.5mm up inside metalF because the
    nearest ring available there belonged to a strand, not to the element.
    """
    axis_index = AXIS.get(str(axis).upper())
    if axis_index is None:
        return None, "Axis must be X, Y or Z"
    rows = list(rings or ())
    if len(rows) < 2:
        return None, "Need at least two divisions"

    # Elements that overlap on the axis cannot each have their own bone: one's
    # boundary falls inside the other. Measured on a braid whose ornaments sit
    # side by side rather than stacked -- metalB 1535.1..1503.1, metalC
    # 1514.3..1489.1, metalD 1500.0..1468.0 -- four "boundary" joints landed
    # inside a neighbour. Merged, the group rides one bone, which keeps every
    # piece in it rigid, which is the point.
    ordered = sorted(spans or (), key=lambda s: -s[0])
    spans = []
    for high, low, name in ordered:
        if spans and low <= spans[-1][0] and high >= spans[-1][1]:
            top, bottom, label = spans[-1]
            spans[-1] = (max(top, high), min(bottom, low),
                         label if name in label else "%s+%s" % (label, name))
            continue
        spans.append((high, low, name))
    keep = []
    for n, ring in enumerate(rows):
        if n % max(1, int(every)) and 0 < n < len(rows) - 1:
            continue
        keep.append(ring)

    def position(ring):
        return ring["centre"][axis_index] * 1000.0

    inside = []
    for ring in keep:
        at = position(ring)
        hit = None
        for high, low, name in spans or ():
            if low + margin_mm < at < high - margin_mm:
                hit = name
                break
        inside.append(hit)
    free = [ring for ring, hit in zip(keep, inside) if hit is None]
    dropped = [(round(position(r), 2), hit)
               for r, hit in zip(keep, inside) if hit is not None]

    # the boundaries of every element the part passes through are joints, placed
    # at the element's own coordinate
    lo_at = min(position(r) for r in rows)
    hi_at = max(position(r) for r in rows)

    def synth(at, label):
        """A joint at an exact coordinate, interpolated between the two rings
        that straddle it so it carries a real position in all three axes."""
        before = None
        after = None
        for ring in sorted(rows, key=position):
            if position(ring) <= at:
                before = ring
            elif after is None:
                after = ring
        if before is None and after is None:
            return None
        if before is None:
            return dict(after, hop=after["hop"] - 0.5, edge=label)
        if after is None:
            return dict(before, hop=before["hop"] + 0.5, edge=label)
        a, b = position(before), position(after)
        span = (at - a) / (b - a) if abs(b - a) > 1e-9 else 0.0
        centre = before["centre"] + (after["centre"] - before["centre"]) * span
        return {"hop": before["hop"] + span, "indices": [], "centre": centre,
                "verts": 0, "span_mm": 0.0, "edge": label}

    wanted = []
    for high, low, name in spans or ():
        for edge_at in (high, low):
            if not (lo_at - 1.0 <= edge_at <= hi_at + 1.0):
                continue
            made = synth(edge_at, name)
            if made is not None:
                wanted.append(made)

    seen = set()
    merged = []
    for ring in free + wanted:
        key = round(float(ring["hop"]), 3)
        if key in seen:
            continue
        seen.add(key)
        merged.append(ring)
    merged.sort(key=lambda r: float(r["hop"]))

    if max_gap_mm:
        # keep every boundary, then fill each stretch from its own divisions
        anchors = [r for r in merged if r.get("edge")] or []
        keys = {round(float(r["hop"]), 3) for r in anchors}
        ends = [merged[0], merged[-1]]
        for ring in ends:
            if round(float(ring["hop"]), 3) not in keys:
                anchors.append(ring)
                keys.add(round(float(ring["hop"]), 3))
        anchors.sort(key=lambda r: float(r["hop"]))
        filled = []
        for a, b in zip(anchors, anchors[1:]):
            filled.append(a)
            width = abs(position(b) - position(a))
            if width <= max_gap_mm:
                continue
            need = int(width // max_gap_mm)
            inner = [r for r in merged
                     if float(a["hop"]) < float(r["hop"]) < float(b["hop"])]
            if not inner or need < 1:
                continue
            step = len(inner) / float(need + 1)
            for n in range(1, need + 1):
                at = min(len(inner) - 1, int(round(n * step)))
                filled.append(inner[at])
        filled.append(anchors[-1])
        seen = set()
        merged = []
        for ring in filled:
            key = round(float(ring["hop"]), 3)
            if key in seen:
                continue
            seen.add(key)
            merged.append(ring)
        merged.sort(key=lambda r: float(r["hop"]))

    if budget and len(merged) > int(budget):
        step = len(merged) / float(int(budget))
        picked, taken = [], set()
        for n in range(int(budget)):
            at = min(len(merged) - 1, int(round(n * step)))
            while at in taken and at + 1 < len(merged):
                at += 1
            taken.add(at)
            picked.append(merged[at])
        if merged[-1]["hop"] not in {r["hop"] for r in picked}:
            picked[-1] = merged[-1]
        merged = picked

    # Order by position on the axis, not by hop. A synthesised boundary carries an
    # interpolated hop, and for interleaved elements that order is not the order
    # down the part -- a chain built through it zigzags.
    merged.sort(key=position, reverse=True)
    gaps = [round(abs(position(b) - position(a)), 2)
            for a, b in zip(merged, merged[1:])]
    return {"pivots": merged, "count": len(merged),
            "dropped_inside": dropped,
            "gaps_mm": gaps,
            "gap_min": min(gaps) if gaps else 0.0,
            "gap_max": max(gaps) if gaps else 0.0,
            "positions_mm": [round(position(r), 2) for r in merged]}, ""


def deform_bone_for(armature, bone_name):
    """The bone that carries weights for ``bone_name``: itself, or the nearest deform bone.

    A weight on a bone that does not deform moves nothing, and a control's parents are
    no guide to what it drives (c_head.x has no deforming ancestor; head.x, lying on top
    of it, does the work), so a control is matched by where it lies, not by the hierarchy.
    """
    bone = armature.data.bones.get(bone_name) if bone_name else None
    if bone is None:
        return ""
    if bone.use_deform:
        return bone.name
    best, best_distance = "", None
    for other in armature.data.bones:
        if not other.use_deform or other.name.startswith(ANCHOR_NOT_FROM):
            continue
        distance = (other.head_local - bone.head_local).length + (other.tail_local - bone.tail_local).length
        if best_distance is None or distance < best_distance:
            best, best_distance = other.name, distance
    return best


def _rest_world(mesh_object):
    """Where a part parented to a bone sits with the rig at rest, whatever the pose now."""
    parent = mesh_object.parent
    bone = parent.data.bones.get(mesh_object.parent_bone) \
        if mesh_object.parent_type == "BONE" and parent.type == "ARMATURE" else None
    if bone is None:
        return mesh_object.matrix_world.copy()
    local = mesh_object.matrix_parent_inverse @ mesh_object.matrix_basis
    if bone.use_relative_parent:
        return parent.matrix_world @ local
    return parent.matrix_world @ bone.matrix_local \
        @ mathutils.Matrix.Translation((0.0, bone.length, 0.0)) @ local


def tie_unbound_part(mesh_object, armature, parent_bone=""):
    """Tie a part the rig does not fully deform yet to the rig. ``(tie, error)``.

    A chain grown on a mesh with no Armature modifier has bones that move nothing,
    and every chain builder leaves the root of the part on the weights it already
    had, which on an unweighted mesh is none. So the modifier goes on if it is missing,
    and the vertices with no deform weight go on the bone the chain hangs from, before
    the chain is built. A part hung from a bone or a vertex would then move twice, once
    by the parent and once by the modifier, so that link gives way to the rig, keeping
    the part where it is. ``tie`` is None when there was nothing to do, otherwise what
    :func:`untie_part` needs to take this back if the build is refused.
    """
    from . import bind_common

    modifiers = [m for m in mesh_object.modifiers if m.type == "ARMATURE" and m.object is not None]
    bound = any(m.object == armature for m in modifiers)
    if modifiers and not bound:
        return None, tr_format(
            "%(part)s is bound to another armature (%(other)s), so a chain on %(rig)s would not move it.",
            part=mesh_object.name, other=modifiers[0].object.name, rig=armature.name)
    deform = {b.name for b in armature.data.bones if b.use_deform}
    deforming = {g.index for g in mesh_object.vertex_groups if g.name in deform}
    loose = [v.index for v in mesh_object.data.vertices
             if not any(e.group in deforming and e.weight > 0.0 for e in v.groups)]
    if bound and not loose:
        return None, ""
    tie = {"anchor": "", "loose": loose, "group_created": False, "modifiers": [],
           "parented": False, "link": "", "hung_from": "", "before": None}
    parent = mesh_object.parent
    if parent is not None and not bound and mesh_object.parent_type != "OBJECT":
        if parent == armature and mesh_object.parent_type == "BONE":
            tie["hung_from"] = mesh_object.parent_bone
        tie["link"] = mesh_object.parent_bone or parent.name
        tie["before"] = (parent, mesh_object.parent_type, mesh_object.parent_bone,
                         mesh_object.matrix_parent_inverse.copy(), mesh_object.matrix_basis.copy())
        world = _rest_world(mesh_object)
        mesh_object.parent = None
        mesh_object.parent_type = "OBJECT"
        mesh_object.parent_bone = ""
        mesh_object.matrix_parent_inverse.identity()
        mesh_object.matrix_world = world
    anchor = deform_bone_for(armature, parent_bone or tie["hung_from"])
    if not anchor:
        anchor = anchor_bone(mesh_object, armature, [v.index for v in mesh_object.data.vertices])[0]
    tie["anchor"] = anchor
    if anchor and loose:
        group = mesh_object.vertex_groups.get(anchor)
        if group is None:
            group = mesh_object.vertex_groups.new(name=anchor)
            tie["group_created"] = True
        group.add(loose, 1.0, "REPLACE")
    if not bound:
        tie["modifiers"] = bind_common.ensure_modifier_pair(mesh_object, armature)["created"]
        if mesh_object.parent is None:
            tie["parented"] = bind_common.parent_to_rig(mesh_object, armature)
    return tie, ""


def untie_part(mesh_object, tie):
    """Take back :func:`tie_unbound_part` after the chain was refused."""
    group = mesh_object.vertex_groups.get(tie["anchor"]) if tie["anchor"] else None
    if group is not None:
        if tie["group_created"]:
            mesh_object.vertex_groups.remove(group)
        elif tie["loose"]:
            group.remove(tie["loose"])
    for name in tie["modifiers"]:
        modifier = mesh_object.modifiers.get(name)
        if modifier is not None:
            mesh_object.modifiers.remove(modifier)
    if tie["before"] is not None:
        mesh_object.parent, mesh_object.parent_type, mesh_object.parent_bone, inverse, basis = tie["before"]
        mesh_object.matrix_parent_inverse = inverse
        mesh_object.matrix_basis = basis
    elif tie["parented"]:
        world = mesh_object.matrix_world.copy()
        mesh_object.parent = None
        mesh_object.matrix_parent_inverse.identity()
        mesh_object.matrix_world = world


def carries_rig_weights(mesh_object, armature):
    """Whether any vertex of the mesh has a weight on a deform bone of the rig."""
    return bool(_weighted_bones(mesh_object, armature))


def _weighted_bones(mesh_object, armature):
    """The names of the rig's deform bones that some vertex of the mesh has a weight on."""
    bones = armature.data.bones
    names = {g.index: g.name for g in mesh_object.vertex_groups
             if bones.get(g.name) is not None and bones[g.name].use_deform}
    found = set()
    if names:
        for vertex in mesh_object.data.vertices:
            for entry in vertex.groups:
                if entry.weight > 0.0 and entry.group in names:
                    found.add(entry.group)
    return {names[i] for i in found}


def find_skin(parts, armature, scene, samples=200):
    """The mesh a costume part should copy its weights from, or None.

    Of the visible meshes the rig already deforms, the nearest one that reads as a
    body. A garment Bind Costume Part made never qualifies. Neither does a mesh on far
    fewer bones than the richest one: a buckle on the head bone lies closer to a hat
    than the head does, and has nothing to give it. A mesh that carries chain bones
    comes second, so that its swing does not spread to the part.
    """
    candidates = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj in parts or COSTUME_PART_KEY in obj.keys() \
                or not obj.visible_get() or not len(obj.data.vertices) \
                or not any(m.type == "ARMATURE" and m.object == armature for m in obj.modifiers):
            continue
        bones = _weighted_bones(obj, armature)
        body_bones = {n for n in bones if not n.startswith(ANCHOR_NOT_FROM)}
        if body_bones:
            candidates.append((obj, len(body_bones), len(bones) != len(body_bones)))
    if not candidates:
        return None
    floor = max(c[1] for c in candidates) * SKIN_MIN_BONE_SHARE
    candidates = [c for c in candidates if c[1] >= floor]
    if any(not c[2] for c in candidates):
        candidates = [c for c in candidates if not c[2]]
    points = []
    for part in parts:
        vertices = part.data.vertices
        step = max(1, len(vertices) // max(1, samples))
        matrix = part.matrix_world
        points.extend(matrix @ vertices[i].co for i in range(0, len(vertices), step))
    best, best_distance = None, None
    for obj, _count, _chained in candidates:
        tree = mathutils.kdtree.KDTree(len(obj.data.vertices))
        matrix = obj.matrix_world
        for vertex in obj.data.vertices:
            tree.insert(matrix @ vertex.co, vertex.index)
        tree.balance()
        distance = sum(tree.find(p)[2] for p in points) / max(1, len(points))
        if best_distance is None or distance < best_distance:
            best, best_distance = obj, distance
    return best


def chain_part(mesh_object, armature, indices, bones=10, key="strap",
               prefix="srs_chain", parent_bone="", axis="Z",
               bone_collection="", takeover=1.0, jiggle=None):
    """Grow a bone chain down a hanging part and weight the part onto it.

    ``(report, error)``. The chain is built from the part's own centreline, so it
    follows a strap that curves; the weighting is the same two-nearest-bone blend
    the hair chains use, which keeps the part smooth across the joints instead of
    segmenting it.

    ``takeover`` is how much of the part the chain takes: 1.0 clears whatever the
    vertices carried and puts them entirely on the chain, which is right for a
    strap that hangs free. ``"ramp"`` hands over gradually along the chain, so the
    root of the part still follows the body it grows out of and only the far end
    swings -- that is what a coat hem needs, and clearing it outright there
    detaches the hem from the waist.

    ``jiggle`` is a ``{"stiffness", "damping", "gravity"}`` dict written onto the
    first bone, where :mod:`jiggle` looks for it.
    """
    from . import hair_chain

    if mesh_object is None or armature is None:
        return None, "Need the mesh and the armature"
    if not indices:
        return None, "No vertex was given to chain"
    line = _centreline(mesh_object, indices, axis=axis)
    points = hair_chain._resample(line, int(bones))
    anchor = parent_bone
    if not anchor:
        anchor, error = anchor_bone(mesh_object, armature, indices, axis=axis)
        if error:
            return None, error
    plan = [{"key": key, "group": key, "side": "", "points": points,
             "bone_length": (sum((b - a).length for a, b in zip(points,
                                                               points[1:]))
                             / max(1, int(bones)))}]
    report, error = hair_chain.build(armature, plan, parent_bone=anchor,
                                     prefix=prefix, master=False, deform=True,
                                     bone_collection=bone_collection)
    if error:
        return None, error
    names = ["%s_%s_%02d" % (prefix, key, i + 1) for i in range(len(points) - 1)]
    mids = [(points[i] + points[i + 1]) * 0.5 for i in range(len(points) - 1)]
    matrix = mesh_object.matrix_world
    span = max((points[-1] - points[0]).length, 1.0e-9)
    direction = (points[-1] - points[0]) / span

    def authority(point):
        if takeover == "ramp":
            along = (point - points[0]).dot(direction) / span
            t = max(0.0, min(1.0, along))
            return t * t * (3.0 - 2.0 * t)
        return max(0.0, min(1.0, float(takeover)))

    # 帯の頂点からは、もとの（体から写した）重みを外す。ここは体ではない。
    # ramp のときは裾の上端を残す ── 体から生えている所は体が持つ。
    keep_share = {}
    for index in indices:
        point = matrix @ mesh_object.data.vertices[index].co
        keep_share[index] = 1.0 - authority(point)
    for group in mesh_object.vertex_groups:
        if group.name.startswith(prefix + "_"):
            continue
        for index in indices:
            share = keep_share[index]
            if share >= 0.999:
                continue
            if share <= 0.001:
                group.remove([index])
                continue
            current = None
            for entry in mesh_object.data.vertices[index].groups:
                if entry.group == group.index:
                    current = entry.weight
                    break
            if current is None:
                continue
            group.add([index], current * share, "REPLACE")
    made = {}
    for index in indices:
        point = matrix @ mesh_object.data.vertices[index].co
        scale = authority(point)
        if scale <= 0.001:
            continue
        order = sorted(range(len(mids)), key=lambda i: (mids[i] - point).length)
        if len(order) == 1:
            made.setdefault(names[order[0]], []).append((index, scale))
            continue
        first, second = order[0], order[1]
        d1 = max((mids[first] - point).length, 1.0e-6)
        d2 = max((mids[second] - point).length, 1.0e-6)
        share = (1.0 / d1) / ((1.0 / d1) + (1.0 / d2))
        made.setdefault(names[first], []).append((index, share * scale))
        made.setdefault(names[second], []).append((index, (1.0 - share) * scale))
    for name, pairs in made.items():
        group = (mesh_object.vertex_groups.get(name)
                 or mesh_object.vertex_groups.new(name=name))
        for index, weight in pairs:
            group.add([index], weight, "REPLACE")
    if jiggle:
        root = armature.pose.bones.get(names[0])
        if root is not None:
            root["srs_jiggle_stiffness"] = float(jiggle.get("stiffness", 0.4))
            root["srs_jiggle_damping"] = float(jiggle.get("damping", 0.25))
            root["srs_jiggle_gravity"] = float(jiggle.get("gravity", 0.0))
            # drag belongs with the other three: leaving it off means a re-bake
            # falls back to the button's default and does not reproduce the
            # settings this chain was tuned and measured with
            root["srs_jiggle_inertia"] = float(jiggle.get("inertia", 0.5))
    return {"mesh": mesh_object.name, "key": key, "anchor": anchor,
            "anchor_note": ("chosen from the part's top edge, with finger and "
                            "facial bones penalised"),
            "bones": names, "bone_count": len(names),
            "vertices": len(indices),
            "length_mm": round(sum((b - a).length for a, b in zip(points,
                                                                 points[1:]))
                               * 1000, 1),
            "build": report}, ""


def chain_on_divisions(mesh_object, armature, indices, key="part",
                       prefix="srs_chain", parent_bone="", axis="Z",
                       every=1, budget=0, spans=(), bone_collection="",
                       jiggle=None, head=None, blend=1, seed=None):
    """Chain a part on its own polygon divisions. ``(report, error)``.

    Two things this does that an evenly-spaced chain cannot.

    **A rigid element keeps its shape, by construction.** Weight is assigned by
    division index, not by distance: every ring between one joint and the next
    goes entirely on that one bone. An element whose rings all lie between two
    joints therefore rides a single bone at 1.0 and cannot bend. Nothing has to
    be detected afterwards and nothing can leak across the boundary. Measured on
    this character before: three of a hair chain's twelve joints sat INSIDE
    metalF, metalH and metalI, at a spacing of exactly 117.0mm -- evenly placed,
    and the metal was being bent.

    **The joints land where the artist put the divisions.** ``every`` thins them
    (2 for one joint per two divisions), ``budget`` caps the count while keeping
    the spacing even, and ``spans`` from :func:`rigid_spans` forbids the inside
    of an element while forcing its two boundaries to be joints -- the top and
    the bottom of a metal part are exactly where a strand is free to bend.

    ``blend`` smooths the weights across the soft joints afterwards, and never
    across an element boundary, so hair bends smoothly while metal stays solid.
    ``head`` overrides where the first bone starts, for a part whose attachment
    is not its own top.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    scope = sorted(set(indices or ()))
    if len(scope) < 4:
        return None, "Too few vertices to chain"

    walk, error = division_rings(mesh_object, indices=scope, axis=axis,
                                 seed=seed)
    if error:
        return None, error
    rings = walk["rings"]
    plan, error = plan_pivots(rings, spans=spans, axis=axis, every=every,
                              budget=budget)
    if error:
        return None, error
    pivots = plan["pivots"]
    if len(pivots) < 2:
        return None, "Fewer than two usable divisions"

    points = [r["centre"].copy() for r in pivots]
    if head is not None:
        points[0] = mathutils.Vector(head)
    for n in range(1, len(points)):
        if (points[n] - points[n - 1]).length < 1.0e-5:
            points[n] = points[n - 1] + mathutils.Vector((0.0, 0.0, -0.002))

    view = bpy.context.view_layer
    previous = view.objects.active
    names = []
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        ebs = armature.data.edit_bones
        anchor = ebs.get(parent_bone) if parent_bone else None
        matrix = armature.matrix_world.inverted()
        last = anchor
        for n in range(len(points) - 1):
            name = "%s_%s_%02d" % (prefix, key, n + 1)
            if name in ebs:
                ebs.remove(ebs[name])
            bone = ebs.new(name)
            bone.head = matrix @ points[n]
            bone.tail = matrix @ points[n + 1]
            bone.parent = last
            bone.use_connect = n > 0
            bone.use_deform = True
            names.append(name)
            last = bone
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = previous
    if not names:
        return None, "No bone was made"

    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for name in names:
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)

    # weight by division index: every ring between two joints rides one bone
    edges = [r["hop"] for r in pivots]
    groups = {}
    for name in names:
        groups[name] = mesh_object.vertex_groups.get(name) \
            or mesh_object.vertex_groups.new(name=name)
    existing = {g.index: g.name for g in mesh_object.vertex_groups}
    owner = {}
    for ring in rings:
        hop = ring["hop"]
        slot = 0
        for n in range(len(edges) - 1):
            if hop >= edges[n]:
                slot = n
        if hop < edges[0]:
            slot = 0
        for index in ring["indices"]:
            owner[index] = slot
    for index, slot in owner.items():
        for name in existing.values():
            group = mesh_object.vertex_groups.get(name)
            if group is not None and name not in groups:
                try:
                    group.remove([index])
                except RuntimeError:
                    pass
        groups[names[slot]].add([index], 1.0, "REPLACE")

    # smooth across the soft joints only -- never across an element boundary
    blended = 0
    if blend:
        hard = set()
        for high, low, _name in spans or ():
            for n, ring in enumerate(pivots):
                at = ring["centre"][AXIS[str(axis).upper()]] * 1000.0
                if abs(at - high) < 1.0 or abs(at - low) < 1.0:
                    hard.add(n)
        soft = [names[n] for n in range(len(names))
                if n not in hard and n + 1 not in hard]
        if soft:
            smooth_groups(mesh_object, sorted(owner), soft, factor=0.5,
                          repeat=int(blend))
            blended = len(soft)
    from . import rig_hygiene
    rig_hygiene.normalise_deform(mesh_object, armature)

    if jiggle:
        root = armature.pose.bones.get(names[0])
        if root is not None:
            root["srs_jiggle_stiffness"] = float(jiggle.get("stiffness", 0.5))
            root["srs_jiggle_damping"] = float(jiggle.get("damping", 0.3))
            root["srs_jiggle_gravity"] = float(jiggle.get("gravity", 0.0))
            root["srs_jiggle_inertia"] = float(jiggle.get("inertia", 0.45))

    return {"mesh": mesh_object.name, "key": key, "bones": names,
            "bone_count": len(names), "vertices": len(owner),
            "divisions": len(rings), "pivots": plan["positions_mm"],
            "gap_min_mm": plan["gap_min"], "gap_max_mm": plan["gap_max"],
            "dropped_inside": plan["dropped_inside"],
            "blended_groups": blended,
            "length_mm": round(sum((b - a).length
                                   for a, b in zip(points, points[1:]))
                               * 1000, 1)}, ""


def sheet_chains(mesh_object, armature, indices, columns=3, bones=2,
                 key="sheet", prefix="srs_chain", parent_bone="", axis="Z",
                 across="X", bone_collection="", takeover="ramp", jiggle=None,
                 blend_columns=3):
    """Chain a hanging SHEET by splitting it into columns first.

    ``blend_columns`` smooths the generated groups across the column boundaries
    afterwards, and is not optional in practice. Each column is built on its own
    and owns its vertices at 1.0, so without it two neighbouring columns meet at
    an edge whose ends are entirely on different bones -- measured on this coat's
    hem, a weight gap of 2.000 across 40 edges, which tears the moment the two
    columns move apart. Set it to 0 only when the panels really are separate
    pieces of cloth.

    ``(report, error)``. A fringe is not a strand: one island spans the whole
    forehead, so a single centreline through it runs sideways and the chain comes
    out lying across the hair instead of down it. Cutting the sheet into
    ``columns`` along ``across`` first gives each lock its own centreline, and
    each gets its own short chain.

    Stray vertices -- the three- and four-vertex fragments a hair sheet carries at
    its cap ends -- are handed to the column they fall in rather than chained, so
    they travel with their lock instead of becoming chains of their own.

    ``across="ANGLE"`` splits by bearing around the part's own centre instead of
    along a straight axis. A coat hem or a skirt wraps all the way round, so a
    split on X puts the front and the back panels in the same column and the
    chain that comes out runs through the body.
    """
    if mesh_object is None or armature is None:
        return None, "Need the mesh and the armature"
    scope = sorted(set(indices))
    if not scope:
        return None, "No vertex was given"
    if len(scope) < 4:
        return None, "Too few vertices to chain"
    columns = max(1, int(columns))
    matrix = mesh_object.matrix_world
    spots = {i: matrix @ mesh_object.data.vertices[i].co for i in scope}
    lanes = {}
    if str(across).upper() == "ANGLE":
        import math

        centre = sum(spots.values(), mathutils.Vector((0.0, 0.0, 0.0)))             / len(spots)
        for index in scope:
            offset = spots[index] - centre
            bearing = (math.atan2(offset.y, offset.x) + math.pi)                 / (2.0 * math.pi)
            n = min(columns - 1, int(bearing * columns))
            lanes.setdefault(n, []).append(index)
    else:
        lane = AXIS.get(str(across).upper(), 0)
        low = min(p[lane] for p in spots.values())
        high = max(p[lane] for p in spots.values())
        width = max(high - low, 1.0e-9)
        for index in scope:
            n = min(columns - 1,
                    int((spots[index][lane] - low) / width * columns))
            lanes.setdefault(n, []).append(index)
    rows = []
    # Fold first, build second. Folding inside the build loop hands vertices to
    # a lane whose chain is already made -- and for the highest lane it always
    # does, every other lane being below it -- so those vertices end up on no
    # chain at all while the report says they were folded in.
    for n in sorted(lanes):
        if len(lanes[n]) >= 8:
            continue
        other = min((m for m in lanes if m != n and len(lanes[m]) >= 8),
                    key=lambda m: abs(m - n), default=None)
        if other is None:
            continue
        lanes[other].extend(lanes[n])
        rows.append({"column": n, "verts": len(lanes[n]),
                     "folded_into": other})
        lanes[n] = []
    for n in sorted(lanes):
        group = lanes[n]
        if not group:
            continue
        report, error = chain_part(mesh_object, armature, group, bones=bones,
                                   key="%s_%02d" % (key, n + 1), prefix=prefix,
                                   parent_bone=parent_bone, axis=axis,
                                   bone_collection=bone_collection,
                                   takeover=takeover, jiggle=jiggle)
        if error:
            rows.append({"column": n, "verts": len(group), "error": error})
            continue
        rows.append({"column": n, "verts": len(group),
                     "bones": report["bone_count"],
                     "bone_names": report["bones"],
                     "length_mm": report["length_mm"],
                     "anchor": report["anchor"]})
    made = []
    for row in rows:
        made.extend(row.get("bone_names") or [])
    blended = 0
    if blend_columns and made:
        names = sorted({n for n in made
                        if n in {g.name for g in mesh_object.vertex_groups}})
        if names:
            _report, _error = smooth_groups(mesh_object, sorted(set(indices)),
                                            names, factor=0.5,
                                            repeat=int(blend_columns))
            blended = len(names)
            from . import rig_hygiene
            rig_hygiene.normalise_deform(mesh_object, armature)
    return {"mesh": mesh_object.name, "key": key, "columns": len(lanes),
            "blended_groups": blended, "rows": rows, "bone_count": len(made), "bones": made,
            "length_mm": max((row.get("length_mm", 0.0) for row in rows), default=0.0)}, ""


def link_chain(mesh_object, armature, groups, parent_bone="", key="links",
               prefix="srs_chain", bone_collection="", jiggle=None,
               head=None):
    """Hang rigid links off one another as a chain. ``(report, error)``.

    ``groups`` is the links in order from the anchored end outward, each a list
    of vertex indices. One bone is made per link, running from the previous
    link's centre to this one's, and the link is put ENTIRELY on its own bone --
    so it swings about the link above it and keeps its shape exactly, which is
    what a metal link does.

    The links do not have to touch. An earring drawn as three separate rings
    that read as threaded together has no geometry joining them, and a binder
    that works from connectivity leaves the lower rings behind on whatever bone
    happened to be nearest. Order is the only thing this needs, and the artist
    already expressed it in the shape.

    ``head`` overrides where the first bone starts; without it the top of the
    first link is used, which is where it hangs from.
    """
    from . import hair_chain

    if mesh_object is None or armature is None:
        return None, "Need the mesh and the armature"
    rows = [sorted(set(g)) for g in groups if g]
    if not rows:
        return None, "No link was given"
    matrix = mesh_object.matrix_world
    centres = []
    for group in rows:
        points = [matrix @ mesh_object.data.vertices[i].co for i in group]
        centres.append(sum(points, mathutils.Vector((0.0, 0.0, 0.0)))
                       / len(points))
    if head is not None:
        start = mathutils.Vector(head)
    else:
        first = [matrix @ mesh_object.data.vertices[i].co for i in rows[0]]
        start = mathutils.Vector((centres[0].x, centres[0].y,
                                  max(p.z for p in first)))
    points = [start] + centres
    for n in range(1, len(points)):
        if (points[n] - points[n - 1]).length < 1.0e-5:
            points[n] = points[n - 1] + mathutils.Vector((0.0, 0.0, -0.002))
    plan = [{"key": key, "group": key, "side": "", "points": points,
             "bone_length": (sum((b - a).length
                                 for a, b in zip(points, points[1:]))
                             / max(1, len(points) - 1))}]
    anchor = parent_bone
    if not anchor:
        anchor, error = anchor_bone(mesh_object, armature, rows[0], axis="Z")
        if error:
            return None, error
    report, error = hair_chain.build(armature, plan, parent_bone=anchor,
                                     prefix=prefix, master=False, deform=True,
                                     bone_collection=bone_collection)
    if error:
        return None, error
    names = ["%s_%s_%02d" % (prefix, key, i + 1) for i in range(len(rows))]
    deform = {b.name for b in armature.data.bones if b.use_deform}
    for name, group in zip(names, rows):
        for vertex_group in mesh_object.vertex_groups:
            if vertex_group.name in deform or \
                    vertex_group.name.startswith(prefix + "_"):
                try:
                    vertex_group.remove(group)
                except RuntimeError:
                    pass
        target = (mesh_object.vertex_groups.get(name)
                  or mesh_object.vertex_groups.new(name=name))
        target.add(group, 1.0, "REPLACE")
    if jiggle:
        root = armature.pose.bones.get(names[0])
        if root is not None:
            root["srs_jiggle_stiffness"] = float(jiggle.get("stiffness", 0.5))
            root["srs_jiggle_damping"] = float(jiggle.get("damping", 0.3))
            root["srs_jiggle_gravity"] = float(jiggle.get("gravity", 0.0))
            root["srs_jiggle_inertia"] = float(jiggle.get("inertia", 0.45))
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "key": key, "anchor": anchor,
            "links": len(rows), "bones": names,
            "length_mm": round(sum((b - a).length
                                   for a, b in zip(points, points[1:]))
                               * 1000, 1),
            "verts": [len(g) for g in rows]}, ""


def stack_islands(mesh_object, indices=None, axis="Z", side_axis="X",
                  side=None, min_verts=8):
    """Islands sorted from the top down, optionally one side only.

    ``(rows, error)``. Feeding these straight into :func:`link_chain` is the
    usual way to rig a pendant: the order along ``axis`` IS the order of the
    chain, and ``side`` splits a mirrored pair into its two ears before that.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    matrix = mesh_object.matrix_world
    lane = AXIS.get(str(side_axis).upper(), 0)
    down = AXIS.get(str(axis).upper(), 2)
    scope = set(indices) if indices is not None else None
    rows = []
    for group in islands(mesh_object):
        if scope is not None and not (set(group) & scope):
            continue
        if len(group) < min_verts:
            continue
        points = [matrix @ mesh_object.data.vertices[i].co for i in group]
        centre = sum(points, mathutils.Vector((0.0, 0.0, 0.0))) / len(points)
        if side == "+" and centre[lane] <= 0.0:
            continue
        if side == "-" and centre[lane] >= 0.0:
            continue
        rows.append({"indices": group, "top": max(p[down] for p in points),
                     "centre": [round(c * 1000, 1) for c in centre],
                     "verts": len(group)})
    rows.sort(key=lambda r: -r["top"])
    return rows, ""


def proxy_without_roll(armature, sources, key="noroll", prefix="srs_noroll",
                       parent_bone="", bone_collection="", roll_axis="Y"):
    """Copy a twist chain into bones that bend with it but do not roll.

    ``(report, error)``. One new deform bone per source, sitting exactly where
    the source sits, parented to ``parent_bone`` (or the source's first
    non-twisting ancestor), carrying a Copy Rotation from the source with the
    roll axis switched off.

    This is the answer to "the sleeve must not turn with the wrist". Taking the
    twist bones off the sleeve instead looks like the same thing and is not: the
    twist chain is what spreads the forearm's rotation ALONG the forearm, so
    without it the cloth has to get from the forearm to the hand in one step.
    Measured, deleting them took the coat from 7.5% of its vertices collapsing
    under a motion capture clip to 19.2%, and drove the arm bands 42mm into the
    sleeve. Keeping the distribution and dropping only the roll is what was
    wanted.

    In Blender a bone's local Y runs along it, so Y is the roll -- which is why
    ``roll_axis`` defaults to it.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    names = [n for n in sources if armature.data.bones.get(n) is not None]
    if not names:
        return None, "None of those source bones exist"
    axis = str(roll_axis).upper()
    if axis not in ("X", "Y", "Z"):
        return None, "roll_axis must be X, Y or Z"

    def ancestor(name):
        bone = armature.data.bones.get(name)
        while bone is not None:
            bone = bone.parent
            if bone is not None and "twist" not in bone.name.lower():
                return bone.name
        return ""

    view = bpy.context.view_layer
    previous = view.objects.active
    made = []
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        ebs = armature.data.edit_bones
        for n, source in enumerate(names):
            origin = ebs.get(source)
            if origin is None:
                continue
            name = "%s_%s_%02d" % (prefix, key, n + 1)
            if name in ebs:
                ebs.remove(ebs[name])
            bone = ebs.new(name)
            bone.head = origin.head.copy()
            bone.tail = origin.tail.copy()
            bone.roll = origin.roll
            anchor = parent_bone or ancestor(source)
            bone.parent = ebs.get(anchor) if anchor else None
            bone.use_connect = False
            bone.use_deform = True
            # Inherit scale exactly as the source does, NOT as the new parent
            # would impose. A stretch bone scales along its length for IK, and a
            # proxy parented to one silently inherits that: measured, the proxy
            # squashed edges to 0.069 of their rest length with both ends on the
            # same bone, which no rotation can do and which read as the sleeve
            # collapsing at the cuff.
            bone.inherit_scale = origin.inherit_scale
            bone.use_inherit_rotation = origin.use_inherit_rotation
            made.append((name, source))
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = previous
    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for name, _source in made:
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)
    for name, source in made:
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is None:
            continue
        for existing in list(pose_bone.constraints):
            pose_bone.constraints.remove(existing)
        con = pose_bone.constraints.new("COPY_ROTATION")
        con.target = armature
        con.subtarget = source
        con.target_space = "LOCAL"
        con.owner_space = "LOCAL"
        con.mix_mode = "REPLACE"
        con.use_x = axis != "X"
        con.use_y = axis != "Y"
        con.use_z = axis != "Z"
    return {"armature": armature.name, "key": key, "roll_axis": axis,
            "pairs": [[a, b] for a, b in made], "count": len(made)}, ""


def offset_bones(armature, mesh_object, sources, indices=None, key="offset",
                 prefix="srs_offset", parent_bone="", bone_collection="",
                 jiggle=None):
    """Give a region its own bone on top of the one that already drives it.

    ``(report, error)``. For a garment that must travel with the body and still
    be adjustable by hand: the coat's chest follows ``spine_02.x`` and the arm
    bands follow the twist bones, and an animator has no way to nudge either
    without moving the body.

    Each new bone is created **exactly where its source is** -- same head, tail
    and roll -- and parented to it. So it contributes nothing at rest, the region
    keeps following the body exactly, and rotating it turns the region about the
    same pivot the body used, which is what "add to it" means. The region's
    weight is moved off the source onto the new bone, because a bone with no
    weight has nothing to add to.

    ``indices`` limits the move to a region; without it the whole mesh's weight
    on those sources is redirected. Only this mesh is touched -- other meshes
    keep following the source bone as before.

    Scale is inherited from the SOURCE, not imposed by the new parent: an ARP
    stretch bone scales along its length for IK, and a child that inherits that
    squashes its region. Measured on this rig when that was got wrong: edges at
    0.069 of rest length with both ends on one bone.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    names = [n for n in (sources or ()) if n in armature.data.bones]
    if not names:
        return None, "None of those bones exist on this rig"

    view = bpy.context.view_layer
    previous = view.objects.active
    made = {}
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        ebs = armature.data.edit_bones
        for n, source in enumerate(sorted(names)):
            origin = ebs.get(source)
            if origin is None:
                continue
            name = "%s_%s_%02d" % (prefix, key, n + 1)
            if name in ebs:
                ebs.remove(ebs[name])
            bone = ebs.new(name)
            bone.head = origin.head.copy()
            bone.tail = origin.tail.copy()
            bone.roll = origin.roll
            bone.parent = ebs.get(parent_bone) if parent_bone else origin
            bone.use_connect = False
            bone.use_deform = True
            bone.inherit_scale = origin.inherit_scale
            bone.use_inherit_rotation = origin.use_inherit_rotation
            made[source] = name
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = previous

    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for name in made.values():
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)

    report, error = redirect_bones(mesh_object, made, indices=indices)
    if error:
        return None, error
    if jiggle:
        for name in made.values():
            pose_bone = armature.pose.bones.get(name)
            if pose_bone is None:
                continue
            pose_bone["srs_jiggle_stiffness"] = float(jiggle.get("stiffness", 0.5))
            pose_bone["srs_jiggle_damping"] = float(jiggle.get("damping", 0.3))
            pose_bone["srs_jiggle_gravity"] = float(jiggle.get("gravity", 0.0))
            pose_bone["srs_jiggle_inertia"] = float(jiggle.get("inertia", 0.45))
    return {"mesh": mesh_object.name, "made": made,
            "bones": sorted(made.values()),
            "moved": report.get("moved"),
            "vertices": report.get("vertices")}, ""


def redirect_bones(mesh_object, mapping, indices=None, additive=False):
    """Move weight from one vertex group to another, keeping the amounts.

    ``(report, error)``. ``mapping`` is ``{from_name: to_name}``.

    This is what to reach for instead of deleting a family: the distribution a
    transfer produced along a chain is information, and a chain of four twist
    bones spreads a rotation in a way one bone cannot. Pointing that same
    distribution at bones which bend but do not roll keeps the smoothness and
    removes only the motion that was unwanted.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    groups = {g.name: g for g in mesh_object.vertex_groups}
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}
    live = {a: b for a, b in mapping.items() if a in groups}
    if not live:
        return {"mesh": mesh_object.name, "moved": 0.0, "vertices": 0,
                "pairs": []}, ""
    for target in set(live.values()):
        if target not in groups:
            groups[target] = mesh_object.vertex_groups.new(name=target)
    scope = sorted(set(indices)) if indices is not None else \
        [v.index for v in mesh_object.data.vertices]
    moved = 0.0
    touched = set()
    plan = {}
    for index in scope:
        for entry in mesh_object.data.vertices[index].groups:
            name = by_index.get(entry.group)
            if name not in live or entry.weight <= 0.0:
                continue
            plan[(index, live[name])] = plan.get((index, live[name]),
                                                 0.0) + entry.weight
            moved += entry.weight
            touched.add(index)
    if not additive:
        for name in live:
            try:
                groups[name].remove(scope)
            except RuntimeError:
                pass
    for (index, target), weight in plan.items():
        current = 0.0
        for entry in mesh_object.data.vertices[index].groups:
            if entry.group == groups[target].index:
                current = entry.weight
                break
        groups[target].add([index], min(1.0, current + weight), "REPLACE")
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "moved": round(moved, 3),
            "vertices": len(touched),
            "pairs": sorted(live.items())}, ""


def clear_bone_parent(obj):
    """Undo a bone parenting without moving the object. ``(report, error)``."""
    if obj is None:
        return None, "No object"
    if obj.parent is None:
        return {"object": obj.name, "was": None}, ""
    before = obj.matrix_world.copy()
    was = [obj.parent.name, obj.parent_type, obj.parent_bone]
    obj.parent = None
    obj.matrix_world = before
    bpy.context.view_layer.update()
    moved = (obj.matrix_world.translation - before.translation).length * 1000
    return {"object": obj.name, "was": was, "moved_mm": round(moved, 5)}, ""


def visible_for_edit(objects):
    """Make objects reachable by operators, and hand back how to put them back.

    An object in a collection whose viewport flag is off, or that is excluded from
    the view layer, cannot be selected at all: ``select_set(True)`` is a silent
    no-op, so a transfer over it writes nothing and the next operator fails with
    "Object has no vertex groups" three steps away from the cause. Every costume
    part on this character is hidden, so this is the normal case, not the edge one.
    """
    saved = []
    view_layer = bpy.context.view_layer
    for obj in objects:
        if obj is None:
            continue
        saved.append(("object", obj, obj.hide_viewport, None))
        obj.hide_viewport = False
        try:
            saved.append(("hide_get", obj, obj.hide_get(), None))
            obj.hide_set(False)
        except RuntimeError:
            pass
        for collection in obj.users_collection:
            saved.append(("collection", collection, collection.hide_viewport,
                          None))
            collection.hide_viewport = False

    def walk(layer):
        yield layer
        for child in layer.children:
            for item in walk(child):
                yield item

    names = {c.name for obj in objects if obj is not None
             for c in obj.users_collection}
    # A collection inside an excluded or hidden parent is just as unreachable, and
    # its own flags say nothing about it -- open the whole chain down to it.
    root = view_layer.layer_collection

    def chains(layer, chain):
        chain = chain + [layer]
        if layer.collection.name in names:
            yield chain
        for child in layer.children:
            for found in chains(child, chain):
                yield found

    opened = set()
    for chain in list(chains(root, [])):
        for layer in chain:
            if layer is root or id(layer) in opened:
                continue
            opened.add(id(layer))
            saved.append(("layer", layer, layer.exclude, layer.hide_viewport))
            layer.exclude = False
            layer.hide_viewport = False
            saved.append(("collection", layer.collection,
                          layer.collection.hide_viewport, None))
            layer.collection.hide_viewport = False
    bpy.context.view_layer.update()
    return saved


def restore_visibility(saved):
    for kind, item, first, second in reversed(saved):
        if kind == "object":
            item.hide_viewport = first
        elif kind == "hide_get":
            try:
                item.hide_set(first)
            except RuntimeError:
                pass
        elif kind == "collection":
            item.hide_viewport = first
        elif kind == "layer":
            item.exclude = first
            item.hide_viewport = second
    bpy.context.view_layer.update()


def bind_part(target, donor, rig, mapping="POLYINTERP_NEAREST",
              collapse=True, threshold=RIGID_DOMINANCE, force_bone=None,
              mute_donor_keys=False, suspend_modifiers=("MIRROR",),
              rigid=False):
    """Transfer a donor's weights onto one part and finish the binding.

    ``(report, error)``. ``mute_donor_keys`` transfers in the donor's BASE shape
    instead of its evaluated one, which is correct only when the part shares the
    donor's shape key -- then both sit in the same space and the correspondence is
    exact. ``suspend_modifiers`` turns off the named modifier types on both meshes
    for the length of the transfer: a Mirror on the target makes the transfer map
    onto geometry that does not exist in the source.
    """
    from . import bind_common

    if target is None or donor is None or rig is None:
        return None, "Need the part, the donor and the rig"
    shown = visible_for_edit([target, donor])
    suspended = []
    for obj in (target, donor):
        for modifier in obj.modifiers:
            if modifier.type in (suspend_modifiers or ()) and modifier.show_viewport:
                modifier.show_viewport = False
                suspended.append(modifier)
    muted = []
    if mute_donor_keys and donor.data.shape_keys:
        for block in donor.data.shape_keys.key_blocks:
            if not block.mute:
                block.mute = True
                muted.append(block)
    bpy.context.view_layer.update()
    try:
        report, error = bind_common.transfer_weights([target], donor, rig,
                                                     mapping=mapping)
    finally:
        for modifier in suspended:
            modifier.show_viewport = True
        for block in muted:
            block.mute = False
        restore_visibility(shown)
        bpy.context.view_layer.update()
    if report is None:
        return None, error
    out = {"transfer": report, "transfer_warning": error}
    if collapse or rigid:
        collapsed, collapse_error = collapse_rigid_islands(
            target, threshold=threshold, force_bone=force_bone, always=rigid,
            armature=rig)
        if collapse_error:
            return out, collapse_error
        out["collapse"] = collapsed
    reached = 0
    for vertex in target.data.vertices:
        if any(entry.weight > 0.0 for entry in vertex.groups):
            reached += 1
    out["coverage"] = round(reached / max(1, len(target.data.vertices)), 4)
    out["unreached"] = len(target.data.vertices) - reached
    return out, ""



def assign_rigid(mesh_object, armature, bone_name, indices=None):
    """Put the given vertices entirely on one bone. ``(report, error)``.

    For a part that is a solid object -- a metal stud, an earphone shell, a
    microphone. Every other deform group is cleared off those vertices, so the
    result is exactly rigid rather than nearly rigid, and no later normalise pass
    can reintroduce a neighbour's influence.

    This is the per-island counterpart to :func:`rig_hygiene.bind_rigid`, which
    parents a whole OBJECT to a bone. An object that holds several separate studs
    cannot be bone-parented, because each stud follows a different bone.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if armature.data.bones.get(bone_name) is None:
        return None, "%s has no bone %s" % (armature.name, bone_name)
    scope = sorted(set(indices)) if indices is not None else \
        [v.index for v in mesh_object.data.vertices]
    if not scope:
        return None, "No vertex given"
    target = mesh_object.vertex_groups.get(bone_name) or \
        mesh_object.vertex_groups.new(name=bone_name)
    deform = {b.name for b in armature.data.bones if b.use_deform}
    cleared = []
    for group in mesh_object.vertex_groups:
        if group.name == bone_name or group.name not in deform:
            continue
        try:
            group.remove(scope)
            cleared.append(group.name)
        except RuntimeError:
            pass
    target.add(scope, 1.0, "REPLACE")
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "bone": bone_name,
            "vertices": len(scope), "cleared_groups": len(cleared)}, ""


def order_loop(mesh_object, loop):
    """Put an unordered loop of vertices into walking order. ``[] `` if it is not
    a loop.

    A set of indices is not a curve, and interpolating between "the two nearest"
    vertices of a set gives the two nearest in SPACE, which across a narrow eye
    opening are on opposite lids. The order has to come from the edges.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return []
    want = set(loop)
    table = {}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        if a in want and b in want:
            table.setdefault(a, []).append(b)
            table.setdefault(b, []).append(a)
    if not table:
        return []
    start = min(table, key=lambda i: (len(table[i]), i))
    order = [start]
    seen = {start}
    while True:
        nxt = [j for j in table.get(order[-1], ()) if j not in seen]
        if not nxt:
            break
        order.append(nxt[0])
        seen.add(nxt[0])
    return order if len(order) == len(want) else []


def bind_to_loop(part, donor, armature, loop, indices=None, keep_bones=None,
                 drop_bones=(), flatten_mm=2.0):
    """Carry a strip on one loop of the donor so it cannot stretch across itself.

    ``(report, error)``. Every vertex of the part takes the donor's weights at the
    point of ``loop`` nearest to it -- interpolated between the two loop vertices
    it falls between -- and nothing else. The weights then depend only on the
    position ALONG the loop, so the vertices of one cross-section of the strip
    carry the same weight vector and therefore undergo the same affine transform:
    the strip rides the loop, and its width cannot change.

    That is the difference from a nearest-surface transfer. An eyelash sits a few
    millimetres off the lid, so a transfer gives its root and its tip different
    weights -- measured on the reference character, the tip picked up the skin
    ABOVE the crease -- and the lid closing then pulls the two apart, which is the
    lash splaying and stretching lengthwise rather than travelling with the margin.

    ``keep_bones`` restricts the copied weights to a family (a tuple of name
    prefixes) and renormalises what is left. Use it when the part must follow one
    mechanism and nothing else; leave it out to inherit the margin's own mixture,
    which is what makes the part sit still relative to the skin it grows from.

    Give it the ARC the part grows from, not the whole eye opening. The nearest
    point of a closed aperture loop to the tip of an upper lash can lie on the
    LOWER lid -- millimetres away through the air, the far side of the opening
    along the surface -- and a lid that closes then drags that tip down while the
    root goes up. Measured that way, upper-lash edges stretched to 6.1x.

    ``flatten_mm`` makes the "no stretch across the width" exact. Each vertex takes
    the position along the loop of the nearest vertex that is within ``flatten_mm``
    of it -- its root -- rather than its own, so a whole cross-section shares one
    position and therefore one weight vector, and the width cannot change at all
    rather than nearly not. Set it to 0 to use each vertex's own position.
    """
    if part is None or part.type != "MESH":
        return None, "Select the part"
    if donor is None or donor.type != "MESH":
        return None, "No donor"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    order = order_loop(donor, loop)
    if not order:
        return None, ("those %d donor vertices are not a single edge loop"
                      % len(set(loop)))
    deform = {b.name for b in armature.data.bones if b.use_deform}
    donor_groups = {g.index: g.name for g in donor.vertex_groups}
    at_loop = []
    for index in order:
        row = {}
        for entry in donor.data.vertices[index].groups:
            name = donor_groups.get(entry.group)
            if name in deform and entry.weight > 0.0:
                row[name] = entry.weight
        at_loop.append(row)
    matrix = donor.matrix_world
    points = [matrix @ donor.data.vertices[i].co for i in order]
    segments = [(n, n + 1) for n in range(len(points) - 1)]
    ends = {order[0], order[-1]}
    closed = len(points) > 2 and any(
        set(e.vertices) == ends for e in donor.data.edges)
    if closed:
        segments.append((len(points) - 1, 0))

    scope = sorted(set(indices)) if indices is not None else \
        [v.index for v in part.data.vertices]
    if not scope:
        return None, "No vertex given"
    part_matrix = part.matrix_world
    assigned = {}
    drift = []
    where = {}
    for index in scope:
        point = part_matrix @ part.data.vertices[index].co
        best = None
        for a, b in segments:
            head, tail = points[a], points[b]
            span = tail - head
            length = span.length_squared
            t = 0.0 if length <= 1.0e-12 else \
                max(0.0, min(1.0, (point - head).dot(span) / length))
            spot = head + span * t
            gap = (point - spot).length
            if best is None or gap < best[0]:
                best = (gap, a, b, t)
        where[index] = best
        drift.append(best[0] * 1000)

    if flatten_mm and flatten_mm > 0.0:
        roots = [i for i in scope
                 if where[i][0] * 1000 <= float(flatten_mm)]
        if roots:
            spots = {i: part_matrix @ part.data.vertices[i].co for i in scope}
            for index in scope:
                if index in roots:
                    continue
                near = min(roots,
                           key=lambda r: (spots[index] - spots[r]).length)
                where[index] = (where[index][0],) + where[near][1:]

    for index in scope:
        gap, a, b, t = where[index]
        row = {}
        for name, weight in at_loop[a].items():
            row[name] = row.get(name, 0.0) + weight * (1.0 - t)
        for name, weight in at_loop[b].items():
            row[name] = row.get(name, 0.0) + weight * t
        if keep_bones:
            row = {n: w for n, w in row.items()
                   if any(n.startswith(p) for p in keep_bones)}
        for name in drop_bones:
            row.pop(name, None)
        total = sum(row.values())
        if total <= 1.0e-9:
            return None, ("the loop carries no weight the filter keeps, at part "
                          "vertex %d" % index)
        assigned[index] = {n: w / total for n, w in row.items()}

    wanted = sorted({n for row in assigned.values() for n in row})
    for name in wanted:
        if part.vertex_groups.get(name) is None:
            part.vertex_groups.new(name=name)
    table = {g.name: g for g in part.vertex_groups}
    for group in part.vertex_groups:
        if group.name in deform:
            try:
                group.remove(scope)
            except RuntimeError:
                pass
    for index, row in assigned.items():
        for name, weight in row.items():
            table[name].add([index], weight, "REPLACE")
    part.data.update()
    drift.sort()
    return {"part": part.name, "donor": donor.name, "loop": len(order),
            "vertices": len(scope), "bones": wanted,
            "to_loop_mm": [round(drift[0], 3),
                           round(drift[len(drift) // 2], 3),
                           round(drift[-1], 3)]}, ""


def assign_blend(mesh_object, donor, armature, indices, drop_bones=(),
                 keep_bones=None, contact_mm=2.0, bias_mm=0.2):
    """Put a whole island on ONE weight vector, taken from the skin under it.

    ``(report, error)``. Every vertex of the island gets the same weights, so
    linear blend skinning maps the island by a single affine transform: it stays
    rigid, the way a metal stud has to, but the transform is the one the skin under
    it actually undergoes instead of one bone's.

    A stud does not sink into the skin because it is loose -- it sinks because the
    skin moves and it does not. Measured on the reference character, the nose studs
    sat 0.14mm clear of the skin at rest and 1.47mm INSIDE it with an eye closed,
    while being exactly rigid on the nose bone the whole time: the skin there is
    within four loops of the eye opening, so it rose and the stud did not.

    The weights are averaged over the CONTACT patch -- the island vertices that
    touch the donor -- not over the whole island. The far face of a stud is
    millimetres off the surface and its nearest skin can be a different part of the
    face entirely.

    Within that patch the samples are weighted by ``1 / (gap + bias_mm)``, so the
    part of the island that is closest to breaking the surface decides. A plain
    mean does not keep a stud out: measured, averaging over the patch left the
    skin under the deepest corner moving further than the island did, and the
    penetration got WORSE than leaving the stud on one bone. Raise ``bias_mm`` to
    flatten the weighting towards a mean.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the part"
    if donor is None or donor.type != "MESH":
        return None, "No donor"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    scope = sorted(set(indices))
    if not scope:
        return None, "No vertex given"
    tree, _points = _surface_tree(donor)
    if tree is None:
        return None, "The donor evaluates to no faces"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    donor_groups = {g.index: g.name for g in donor.vertex_groups}
    depsgraph = bpy.context.evaluated_depsgraph_get()
    donor_eval = donor.evaluated_get(depsgraph)
    polygons = [list(p.vertices) for p in donor_eval.data.polygons]
    matrix = mesh_object.matrix_world
    donor_matrix = donor.matrix_world

    def weights_at(point):
        loc, _nor, index, dist = tree.find_nearest(point)
        if loc is None or index is None or index >= len(polygons):
            return None, None
        corners = polygons[index]
        pick = min(corners,
                   key=lambda i: (donor_matrix
                                  @ donor_eval.data.vertices[i].co - point).length)
        if pick >= len(donor.data.vertices):
            return None, None
        row = {}
        for entry in donor.data.vertices[pick].groups:
            name = donor_groups.get(entry.group)
            if name in deform and entry.weight > 0.0:
                row[name] = entry.weight
        return row, dist * 1000

    gaps = []
    contact = []
    for index in scope:
        row, gap = weights_at(matrix @ mesh_object.data.vertices[index].co)
        if row is None:
            continue
        gaps.append(gap)
        if gap <= contact_mm:
            contact.append((index, row, 1.0 / (max(gap, 0.0) + max(bias_mm,
                                                                  1.0e-6))))
    if not contact:
        # Nothing touches: judge the island by the vertex that comes closest
        # rather than refusing, because a stud can sit proud of the surface.
        best = None
        for index in scope:
            row, gap = weights_at(matrix @ mesh_object.data.vertices[index].co)
            if row and (best is None or gap < best[0]):
                best = (gap, index, row)
        if best is None:
            return None, "no island vertex finds the donor surface"
        contact = [(best[1], best[2], 1.0)]
    blended = {}
    for _index, row, bias in contact:
        total = sum(row.values()) or 1.0
        for name, weight in row.items():
            blended[name] = blended.get(name, 0.0) + bias * weight / total
    if keep_bones:
        blended = {n: w for n, w in blended.items()
                   if any(n.startswith(p) for p in keep_bones)}
    for name in drop_bones:
        blended.pop(name, None)
    total = sum(blended.values())
    if total <= 1.0e-9:
        return None, "the skin under the island carries no weight the filter keeps"
    blended = {n: w / total for n, w in blended.items()}

    for name in sorted(blended):
        if mesh_object.vertex_groups.get(name) is None:
            mesh_object.vertex_groups.new(name=name)
    table = {g.name: g for g in mesh_object.vertex_groups}
    for group in mesh_object.vertex_groups:
        if group.name in deform and group.name not in blended:
            try:
                group.remove(scope)
            except RuntimeError:
                pass
    for name, weight in blended.items():
        table[name].add(scope, weight, "REPLACE")
    mesh_object.data.update()
    gaps.sort()
    return {"part": mesh_object.name, "donor": donor.name,
            "vertices": len(scope), "contact": len(contact),
            "gap_mm": [round(gaps[0], 3), round(gaps[-1], 3)] if gaps else None,
            "weights": sorted(([n, round(w, 4)] for n, w in blended.items()),
                              key=lambda r: -r[1])}, ""


def material_islands(mesh_object, match="metal", threshold=0.95):
    """Islands whose faces are (almost) all one material. ``(rows, error)``.

    ``match`` is matched case-insensitively against the material name, so
    ``"metal"`` catches ``MIK_mtl_metal`` and ``metal_trim`` alike. An island is
    returned when at least ``threshold`` of its vertices sit on faces of that
    material, which tolerates a seam row shared with the neighbouring material
    without letting a mostly-fabric island through.

    This is how a wardrobe states its own hardness. The artist already decided
    what is metal when they assigned the material; reading that is more reliable
    than guessing from island size, and it survives the model being re-exported.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    slots = [s.material.name if s.material else "" for s in mesh_object.material_slots]
    wanted = {n for n, name in enumerate(slots) if match.lower() in name.lower()}
    if not wanted:
        return [], ""
    hit = set()
    for polygon in mesh_object.data.polygons:
        if polygon.material_index in wanted:
            for index in polygon.vertices:
                hit.add(index)
    rows = []
    for group in islands(mesh_object):
        share = len([i for i in group if i in hit]) / float(len(group))
        if share >= threshold:
            rows.append({"indices": group, "share": round(share, 3)})
    return rows, ""


def rigidify_by_material(mesh_object, armature, donor=None, match="metal",
                         threshold=0.95, contact_mm=8.0, bias_mm=0.5,
                         keep_bones=None, drop_bones=()):
    """Make every island of one material exactly rigid. ``(report, error)``.

    Metal does not bend. An island of it must come out of the rig as a single
    affine transform, and the honest way to get that is to give every vertex of
    the island the SAME weight vector -- see :func:`assign_blend` for where that
    vector comes from and why the closest contact decides it.

    With ``donor`` the vector is read from the surface the part sits on, so the
    stud travels with the skin or the garment under it. Without one, each island
    keeps its own dominant bone and simply stops blending: use that when the part
    hangs on a chain of its own, where the surface underneath is not what it
    follows.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    rows, error = material_islands(mesh_object, match=match, threshold=threshold)
    if error:
        return None, error
    if not rows:
        return {"mesh": mesh_object.name, "match": match, "islands": 0,
                "made_rigid": 0, "by_donor": 0, "by_dominant": 0}, ""
    deform = {b.name for b in armature.data.bones if b.use_deform}
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}
    made, by_donor, by_dominant, failed = 0, 0, 0, []
    for row in rows:
        group = row["indices"]
        if donor is not None:
            report, problem = assign_blend(mesh_object, donor, armature, group,
                                           contact_mm=contact_mm,
                                           bias_mm=bias_mm,
                                           keep_bones=keep_bones,
                                           drop_bones=drop_bones)
            if not problem:
                made += 1
                by_donor += 1
                continue
            failed.append(problem)
        # No donor, or the donor could not be reached: keep the island's own
        # dominant bone. A ring threaded on a hair chain has no surface under it.
        acc = {}
        for index in group:
            for entry in mesh_object.data.vertices[index].groups:
                name = by_index.get(entry.group)
                if name in deform and entry.weight > 0.0:
                    acc[name] = acc.get(name, 0.0) + entry.weight
        if not acc:
            failed.append("island of %d vertices carries no deform weight"
                          % len(group))
            continue
        total = sum(acc.values())
        blended = {n: w / total for n, w in acc.items()}
        table = {g.name: g for g in mesh_object.vertex_groups}
        for name in sorted(blended):
            if name not in table:
                table[name] = mesh_object.vertex_groups.new(name=name)
        for vertex_group in mesh_object.vertex_groups:
            if vertex_group.name in deform and vertex_group.name not in blended:
                try:
                    vertex_group.remove(group)
                except RuntimeError:
                    pass
        for name, weight in blended.items():
            table[name].add(group, weight, "REPLACE")
        made += 1
        by_dominant += 1
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "match": match, "islands": len(rows),
            "made_rigid": made, "by_donor": by_donor,
            "by_dominant": by_dominant, "failed": failed[:4]}, ""


def drop_bone_families(mesh_object, armature, patterns, indices=None,
                       give_to=None):
    """Take a family of bones off a part and give the weight somewhere sane.

    ``(report, error)``. ``patterns`` are name fragments -- ``("twist",)`` takes
    every twist bone off, ``("thumb", "index")`` the fingers.

    A sleeve must not spin with the wrist, and a coat must not hang off a finger,
    but both happen by themselves: a nearest-surface transfer reads whatever bone
    the skin under the cloth happens to carry, and in an A-pose the cuff is next
    to the hand. Clearing the family and handing the weight to ``give_to`` -- or,
    with none given, to the family member's own parent chain -- keeps the part
    where it was without the motion it should not have.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    groups = {g.name: g for g in mesh_object.vertex_groups}
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}
    hit = sorted(n for n in groups
                 if n in deform and any(p.lower() in n.lower() for p in patterns))
    if not hit:
        return {"mesh": mesh_object.name, "dropped": [], "vertices": 0,
                "moved": 0.0}, ""

    def heir(name):
        if give_to:
            return give_to if give_to in groups or give_to in deform else None
        bone = armature.data.bones.get(name)
        while bone is not None:
            bone = bone.parent
            if bone is not None and bone.name in deform \
                    and not any(p.lower() in bone.name.lower() for p in patterns):
                return bone.name
        return None

    scope = sorted(set(indices)) if indices is not None else \
        [v.index for v in mesh_object.data.vertices]
    moved = 0.0
    touched = set()
    handover = {}
    for index in scope:
        for entry in mesh_object.data.vertices[index].groups:
            name = by_index.get(entry.group)
            if name not in hit or entry.weight <= 0.0:
                continue
            target = heir(name)
            moved += entry.weight
            touched.add(index)
            if target:
                handover[(index, target)] = handover.get((index, target),
                                                         0.0) + entry.weight
    for name in hit:
        try:
            groups[name].remove(scope)
        except RuntimeError:
            pass
    for (index, target), weight in handover.items():
        group = groups.get(target) or mesh_object.vertex_groups.new(name=target)
        groups[target] = group
        current = 0.0
        for entry in mesh_object.data.vertices[index].groups:
            if entry.group == group.index:
                current = entry.weight
                break
        group.add([index], min(1.0, current + weight), "REPLACE")
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "dropped": hit,
            "vertices": len(touched), "moved": round(moved, 3),
            "handed_to": sorted({t for _i, t in handover})}, ""


HAND_FAMILY = ("hand", "forearm_twist", "thumb", "index", "middle", "ring",
               "pinky", "fingers")
FOOT_FAMILY = ("toes", "foot", "leg_twist")


def name_tokens(name):
    """``"c_index1_base.l"`` -> ``["c", "index", "base", "l"]``.

    Letters run together into a token; digits and punctuation end one. Matching
    a bone family by naked substring is what this exists to prevent: ``"ring"``
    is inside ``"srs_chain_earring.l"`` and inside ``"srs_chain_fringe_01"``, so
    a substring rule sweeps a character's earrings and fringe into the hand
    family and hands them to the forearm. Measured on this character before the
    fix: 71 % of the ear piercing's weight and 45 % of the front hair's matched
    the hand family.
    """
    out, buf = [], ""
    for char in name:
        if char.isalpha():
            buf += char.lower()
            continue
        if buf:
            out.append(buf)
            buf = ""
    if buf:
        out.append(buf)
    return out


def matches_family(name, patterns):
    """Does this bone belong to one of the named families?

    A pattern is matched as a run of whole tokens, so ``"forearm_twist"`` hits
    ``forearm_twist_2.l`` but not ``arm_twist_2.l``, and ``"ring"`` hits
    ``ring1.l`` but not ``srs_chain_earring.l``.
    """
    tokens = name_tokens(name)
    for pattern in patterns:
        want = name_tokens(pattern)
        if not want:
            continue
        span = len(want)
        for start in range(len(tokens) - span + 1):
            if tokens[start:start + span] == want:
                return True
    return False


def side_of(name):
    """Which side a bone name belongs to -- ``"l"``, ``"r"`` or ``""``."""
    low = name.lower()
    for suffix in (".l", "_l"):
        if low.endswith(suffix) or (suffix + ".") in low or (suffix + "_") in low:
            return "l"
    for suffix in (".r", "_r"):
        if low.endswith(suffix) or (suffix + ".") in low or (suffix + "_") in low:
            return "r"
    return ""


def follow_only(mesh_object, armature, give_to, drop=HAND_FAMILY,
                indices=None, keep=(), remove_empty=True):
    """Send a whole family of bones to one heir per side. ``(report, error)``.

    For the part that must stop following a joint: a coat sleeve that spins with
    the wrist, a cuff that hangs off a finger. ``give_to`` names the heir and may
    carry ``{side}`` -- ``"forearm_stretch.{side}"`` sends the left family to
    ``forearm_stretch.l`` and the right to ``forearm_stretch.r``.

    **Drop the whole family or none of it.** Taking the twist bones off a sleeve
    and leaving the hand and fingers behind is worse than leaving everything
    alone: the twist bones were the graded blend between forearm and hand, and
    without them the cuff becomes a hard seam between the two. Measured on a
    coat, under 240 frames of capture -- twist left in place 8.32 % collapsed
    vertices; twist sent to the forearm with the fingers left on the hand
    17.52 %; hand, fingers and twist sent to the forearm together **8.19 %**,
    and the arm accessories went from 15.81 % to nothing at all.

    Weights are renormalised per vertex afterwards, because merging several
    groups into one and leaving the sum short pulls those vertices toward rest.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if not give_to:
        return None, "Name the bone the weight goes to"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    patterns = tuple(p.lower() for p in drop if p)
    if not patterns:
        return None, "Name at least one bone family to take off"
    spared = tuple(k.lower() for k in keep)

    wanted = {}
    if "{side}" in give_to:
        for side in ("l", "r"):
            name = give_to.replace("{side}", side)
            if name in deform:
                wanted[side] = name
    elif give_to in deform:
        wanted["l"] = wanted["r"] = wanted[""] = give_to
    if not wanted:
        return None, "%s is not a deforming bone" % give_to

    groups = {g.name: g for g in mesh_object.vertex_groups}
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}

    def is_family(name):
        if spared and matches_family(name, spared):
            return False
        if name.lower() in {n.lower() for n in wanted.values()}:
            return False
        return matches_family(name, patterns)

    hit = sorted(n for n in groups if n in deform and is_family(n))
    if not hit:
        return {"mesh": mesh_object.name, "dropped": [], "vertices": 0,
                "moved": 0.0, "handed_to": []}, ""

    for side, name in wanted.items():
        if name not in groups:
            groups[name] = mesh_object.vertex_groups.new(name=name)
            by_index[groups[name].index] = name

    scope = sorted(set(indices)) if indices is not None else \
        [v.index for v in mesh_object.data.vertices]
    moved = 0.0
    touched = set()
    handed = set()
    unsided = []
    for index in scope:
        rows = []
        for entry in mesh_object.data.vertices[index].groups:
            name = by_index.get(entry.group)
            if name in deform and entry.weight > 0.0:
                rows.append((name, entry.weight))
        if not rows:
            continue
        pot = {}
        shifted = 0.0
        for name, weight in rows:
            heir = None
            if name in hit:
                # never guess a side: handing a left bone's weight to the right
                # arm is silent and catastrophic, and leaving it alone is not
                heir = wanted.get(side_of(name))
                if heir is None:
                    unsided.append(name)
            if heir is not None:
                pot[heir] = pot.get(heir, 0.0) + weight
                shifted += weight
                handed.add(heir)
            else:
                pot[name] = pot.get(name, 0.0) + weight
        total = sum(pot.values())
        if total <= 1e-9:
            continue
        if shifted <= 0.0:
            continue
        for name, _weight in rows:
            if name not in pot:
                groups[name].add([index], 0.0, "REPLACE")
        for name, weight in pot.items():
            group = groups.get(name)
            if group is None:
                group = mesh_object.vertex_groups.new(name=name)
                groups[name] = group
                by_index[group.index] = name
            group.add([index], weight / total, "REPLACE")
        moved += shifted
        touched.add(index)

    skipped = set(unsided)
    emptied = []
    if remove_empty:
        # by NAME, not by index: VertexGroup.index is read-only and derived from
        # the group's position, so every removal renumbers the ones after it and
        # a set of indices taken beforehand stops meaning anything
        by_index = {g.index: g.name for g in mesh_object.vertex_groups}
        used = set()
        for vertex in mesh_object.data.vertices:
            for entry in vertex.groups:
                if entry.weight > 1e-9:
                    used.add(by_index.get(entry.group))
        for group in list(mesh_object.vertex_groups):
            if group.name in hit and group.name not in skipped \
                    and group.name not in used:
                emptied.append(group.name)
                mesh_object.vertex_groups.remove(group)
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "dropped": hit,
            "vertices": len(touched), "moved": round(moved, 3),
            "handed_to": sorted(handed), "removed": emptied,
            "no_side": sorted(set(unsided))}, ""


def bind_over(part, donor, armature, keep_prefix="srs_chain",
              keep_bones=(), mapping="POLYINTERP_NEAREST", indices=None):
    """Bind a part to the garment underneath it, keeping the part's own chains.

    ``(report, error)``. A belt wrapped round a sleeve is bound from the *skin*
    by default, like every other piece, and then it and the sleeve solve the
    same joint two different ways and slide through one another.

    **Measured on this character it was the wrong trade.** 1509 of the belt's
    8156 vertices crossed into the sleeve, up to 63mm deep around the elbow;
    reading the sleeve's weights instead brought that to 1202 and took the
    belt's own stretched vertices from 0.15 % to 10.96 %. The donor has to be a
    surface whose nearest point is stable -- the body is a closed volume, a
    sleeve is a thin shell that folds onto itself at the elbow, and near the
    fold a nearest-surface read lands on the far side. Prefer a donor that does
    not fold where the part sits, and check the part's own stretch afterwards.

    The part's own chain bones are the reason this is not just ``bind_part``:
    a plain transfer wipes them, and with them the hand-keyable straps and their
    jiggle. Any vertex that carries chain weight is recorded **whole** and put
    back whole afterwards, so only the wrapped band is re-bound. Keeping just
    the chain's share and letting the transfer fill the remainder is not enough:
    a link chain puts each link entirely on its own bone to keep its shape, and
    replacing a neighbouring link's share with the garment's field took the
    belt's stretch from 0.15 % of its vertices to 10.96 %.
    """
    if part is None or part.type != "MESH":
        return None, "Select the part"
    if donor is None or donor.type != "MESH":
        return None, "Name the garment underneath"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if part is donor:
        return None, "A part cannot be bound over itself"

    deform = {b.name for b in armature.data.bones if b.use_deform}
    prefixes = tuple(p for p in (keep_prefix,) if p) if isinstance(
        keep_prefix, str) else tuple(keep_prefix or ())
    spared = {n for n in keep_bones or ()}

    def is_kept(name):
        if name in spared:
            return True
        return any(name.startswith(p) for p in prefixes)

    by_index = {g.index: g.name for g in part.vertex_groups}
    held = {}
    for vertex in part.data.vertices:
        rows = {}
        touched = False
        for entry in vertex.groups:
            name = by_index.get(entry.group)
            if name not in deform or entry.weight <= 0.0:
                continue
            rows[name] = entry.weight
            if is_kept(name):
                touched = True
        if touched and rows:
            held[vertex.index] = rows

    # Only the given vertices are re-bound (a coat's chest over a sleeveless top --
    # the sleeves must not read the top). Every other vertex is recorded whole,
    # every armature's groups included, and written back exactly.
    outside = {}
    if indices is not None:
        scope = set(indices)
        for vertex in part.data.vertices:
            if vertex.index in scope:
                continue
            outside[vertex.index] = {by_index.get(e.group): e.weight for e in vertex.groups
                                     if e.group in by_index}

    report, error = bind_part(part, donor, armature, mapping=mapping,
                              collapse=False)
    if error:
        return None, error

    groups = {g.name: g for g in part.vertex_groups}
    by_index = {g.index: g.name for g in part.vertex_groups}
    # Data Transfer replaces weights only for groups present on the donor.
    # Remove old deform weights from the rebound vertices before normalization.
    donor_groups = {g.name for g in donor.vertex_groups}
    rebound = [v.index for v in part.data.vertices
               if v.index not in held and v.index not in outside]
    if rebound:
        for name in (deform - donor_groups) & groups.keys():
            groups[name].remove(rebound)
    for index, rows in outside.items():
        for entry in list(part.data.vertices[index].groups):
            name = by_index.get(entry.group)
            if name is not None and name not in rows and name in groups:
                groups[name].remove([index])
        for name, weight in rows.items():
            group = groups.get(name) or part.vertex_groups.new(name=name)
            groups[name] = group
            group.add([index], weight, "REPLACE")
    restored = 0
    for index, rows in held.items():
        raw = sum(rows.values())
        if raw <= 0.0:
            continue
        # clear whatever the transfer put here, then write the original vector
        # back untouched -- this vertex belongs to the part's own chain
        for entry in list(part.data.vertices[index].groups):
            name = by_index.get(entry.group)
            if name in deform and name not in rows and name in groups:
                groups[name].add([index], 0.0, "REPLACE")
        for name, weight in rows.items():
            group = groups.get(name)
            if group is None:
                group = part.vertex_groups.new(name=name)
                groups[name] = group
                by_index[group.index] = name
            group.add([index], weight / raw, "REPLACE")
        restored += 1
    part.data.update()
    return {"part": part.name, "donor": donor.name,
            "chain_vertices": restored, "kept_outside": len(outside),
            "chains": sorted({n for rows in held.values() for n in rows}),
            "transfer": report}, ""


def additive_bones(mesh_object, armature, sources, indices=None,
                   prefix="srs_add", bone_collection="", share=1.0,
                   suffix_from_source=True):
    """Give a part its own adjustable copy of the bones that carry it.

    ``(report, error)``. For each bone in ``sources`` a child bone of the same
    shape is made under it, and the part's weight on the source is moved to the
    child -- entirely with ``share=1.0``, or split with the source for a softer
    hand-off. Because the child is parented to the source and starts at rest, the
    body animation reaches the part unchanged and an animator adding rotation to
    the child adds to it rather than replacing it.

    This is what a costume needs that a body does not. A coat's chest has to
    follow the spine, but the coat is a separate surface and no spine rotation
    is ever exactly right for both; a jacket strapped over a sleeve has to follow
    the arm, and the places it fouls the sleeve are not the same places the arm
    bends. Driving the garment through a child leaves somewhere to put the
    correction without touching the body's curves.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the part"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    wanted = [n for n in (sources or ()) if armature.data.bones.get(n)]
    if not wanted:
        return None, "None of those bones exist on this rig"
    take = max(0.0, min(1.0, float(share)))

    pairs = {}
    previous = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        for name in wanted:
            source = edit.get(name)
            if source is None:
                continue
            child_name = "%s_%s" % (prefix, name) if suffix_from_source \
                else "%s_%d" % (prefix, len(pairs) + 1)
            child = edit.get(child_name) or edit.new(child_name)
            child.head = source.head
            child.tail = source.tail
            child.roll = source.roll
            child.parent = source
            child.use_connect = False
            child.use_deform = True
            child.inherit_scale = source.inherit_scale
            child.use_inherit_rotation = True
            pairs[name] = child_name
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous

    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for child_name in pairs.values():
            bone = armature.data.bones.get(child_name)
            if bone is not None:
                target.assign(bone)

    scope = sorted(set(indices)) if indices is not None else \
        [v.index for v in mesh_object.data.vertices]
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}
    groups = {g.name: g for g in mesh_object.vertex_groups}
    for child_name in pairs.values():
        if child_name not in groups:
            groups[child_name] = mesh_object.vertex_groups.new(name=child_name)
    moved = 0.0
    touched = set()
    for index in scope:
        rows = []
        for entry in mesh_object.data.vertices[index].groups:
            name = by_index.get(entry.group)
            if name in pairs and entry.weight > 0.0:
                rows.append((name, entry.weight))
        if not rows:
            continue
        for name, weight in rows:
            child = pairs[name]
            current = 0.0
            for entry in mesh_object.data.vertices[index].groups:
                if by_index.get(entry.group) == child:
                    current = entry.weight
                    break
            groups[child].add([index], min(1.0, current + weight * take),
                              "REPLACE")
            if take >= 1.0:
                groups[name].add([index], 0.0, "REPLACE")
            else:
                groups[name].add([index], weight * (1.0 - take), "REPLACE")
            moved += weight * take
            touched.add(index)
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "pairs": pairs,
            "vertices": len(touched), "moved": round(moved, 3),
            "share": take}, ""


def clear_chain(armature, key, prefix="srs_chain", meshes=None):
    """Take a generated chain out again, bones and groups. ``(report, error)``.

    Rebuilding over a chain that is still there leaves the old bones owning
    vertices nobody looks at any more, and two chains under one name is a rig
    where half the control works.
    """
    import re

    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    pattern = re.compile(r"^%s_%s_(\d{2,3})$"
                         % (re.escape(prefix), re.escape(key)))
    names = sorted(b.name for b in armature.data.bones if pattern.match(b.name))
    if not names:
        return {"key": key, "bones": [], "groups": 0}, ""
    follower = "%s_%s_root" % (prefix, key)
    if armature.data.bones.get(follower) is not None:
        names.append(follower)
    cleared = 0
    targets = list(meshes) if meshes is not None else [
        o for o in bpy.data.objects
        if o.type == "MESH" and (
            o.parent == armature or any(
                m.type == "ARMATURE" and m.object == armature
                for m in o.modifiers))]
    for obj in targets:
        for name in names:
            group = obj.vertex_groups.get(name)
            if group is not None:
                obj.vertex_groups.remove(group)
                cleared += 1
    previous = bpy.context.view_layer.objects.active
    mode = armature.mode
    bpy.context.view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        for name in names:
            bone = edit.get(name)
            if bone is not None:
                edit.remove(bone)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous
        if mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=mode)
            except RuntimeError:
                pass
    return {"key": key, "bones": names, "groups": cleared}, ""


def chain_on_pivots(parts, armature, pivots, key, prefix="srs_chain",
                    parent_bone="", axis="Z", bone_collection="",
                    rigid_spans=(), jiggle=None, blend_mm=0.0,
                    connected=True, takeover=1.0):
    """Build a chain whose joints are GIVEN, not computed. ``(report, error)``.

    ``parts`` is ``[(mesh_object, indices)]`` or a list of meshes; ``pivots`` is
    the joint positions along ``axis``, top first, in metres -- what
    :func:`pivot_plan` returns. Each bone runs from one pivot to the next, and
    its head and tail sit at the centre of the part's own vertices at those
    heights, so the chain follows the shape instead of a straight line.

    Weighting follows the pivots too. A vertex belongs to the bone whose span
    contains it; within ``blend_mm`` of a shared joint it is shared with the
    neighbour, which is what keeps a soft part from creasing at the joint.
    A vertex inside one of ``rigid_spans`` is given 1.0 on the single bone that
    spans that piece and is never blended -- that is what "rigid" means, and a
    piece whose two boundaries are both pivots has exactly one such bone.

    ``takeover`` is the same contract :func:`chain_part` carries: 1.0 clears
    whatever the vertices held before and puts them entirely on the chain, which
    is right for anything that hangs free, because the chain's root bone is
    parented to the part it hangs from and carries it from there. Skipping it is
    not harmless -- the vertex then holds the body's 1.0 and the chain's 1.0 at
    once, and the caller's renormalisation splits the difference, so the swing
    comes out at half strength with the other half welded to the body.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    lane = AXIS.get(str(axis).upper())
    if lane is None:
        return None, "Axis must be X, Y or Z"
    rows = []
    for entry in parts or ():
        if isinstance(entry, (tuple, list)):
            obj, indices = entry[0], entry[1]
        else:
            obj, indices = entry, None
        if obj is None or obj.type != "MESH":
            continue
        scope = sorted(set(indices)) if indices is not None else \
            [v.index for v in obj.data.vertices]
        if scope:
            rows.append((obj, scope))
    if not rows:
        return None, "No mesh was given"
    joints = sorted({round(float(z), 7) for z in pivots or ()}, reverse=True)
    if len(joints) < 2:
        return None, "A chain needs at least two joints"

    # where the part actually is at each joint height
    samples = []
    for obj, scope in rows:
        matrix = obj.matrix_world
        for index in scope:
            samples.append(matrix @ obj.data.vertices[index].co)
    centres = []
    for n, z in enumerate(joints):
        lo = joints[n + 1] if n + 1 < len(joints) else z - 0.001
        hi = joints[n - 1] if n else z + 0.001
        near = [p for p in samples if min(z - (z - lo) * 0.5, z) - 1e-9
                <= p[lane] <= max(z + (hi - z) * 0.5, z) + 1e-9]
        if not near:
            near = sorted(samples, key=lambda p: abs(p[lane] - z))[:8]
        point = mathutils.Vector((0.0, 0.0, 0.0))
        for p in near:
            point = point + p
        point = point / len(near)
        point[lane] = z
        centres.append(point)

    names = ["%s_%s_%02d" % (prefix, key, n + 1) for n in range(len(joints) - 1)]
    previous = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        parent = edit.get(parent_bone) if parent_bone else None
        made = []
        to_rig = armature.matrix_world.inverted()
        for n, name in enumerate(names):
            bone = edit.get(name) or edit.new(name)
            # world -> the rig's own space: a rig that is not at the origin (a
            # character lifted onto its soles) got its chain h too high
            bone.head = to_rig @ centres[n]
            bone.tail = to_rig @ centres[n + 1]
            bone.use_deform = True
            bone.parent = made[-1] if made else parent
            bone.use_connect = bool(connected) and bool(made)
            made.append(bone)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous

    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for name in names:
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)

    hard = []
    for span in rigid_spans or ():
        hi, lo = float(span["hi"]), float(span["lo"])
        owner = None
        for n in range(len(joints) - 1):
            if joints[n] >= hi - 1.0e-5 and joints[n + 1] <= lo + 1.0e-5:
                owner = n
                break
        hard.append((hi, lo, owner, set(span.get("indices") or ())))

    blend = float(blend_mm) / 1000.0
    # 鎖が受け取る頂点から、もとの（体から写した）重みを外す。
    # ここを飛ばすと頂点は体の 1.0 と鎖の 1.0 を両方持ったまま正規化へ回り、
    # 0.5/0.5 になる ── 揺れが半分になり、残り半分は体に溶接されたまま残る。
    # 根元が落ちる心配はない。鎖の先頭ボーンは ``parent_bone`` の子で、
    # 体の動きはそこから入る。
    held = max(0.0, min(1.0, 1.0 - float(takeover)))
    if held < 0.999:
        for obj, scope in rows:
            for group in obj.vertex_groups:
                if group.name.startswith(prefix + "_"):
                    continue
                for index in scope:
                    if held <= 0.001:
                        group.remove([index])
                        continue
                    current = None
                    for entry in obj.data.vertices[index].groups:
                        if entry.group == group.index:
                            current = entry.weight
                            break
                    if current is None:
                        continue
                    group.add([index], current * held, "REPLACE")
    touched = 0
    for obj, scope in rows:
        groups = {}
        for name in names:
            groups[name] = obj.vertex_groups.get(name) \
                or obj.vertex_groups.new(name=name)
        matrix = obj.matrix_world
        for index in scope:
            z = (matrix @ obj.data.vertices[index].co)[lane]
            fixed = None
            for hi, lo, owner, members in hard:
                if owner is None:
                    continue
                if members and index not in members:
                    continue
                if lo - 1.0e-5 <= z <= hi + 1.0e-5:
                    fixed = owner
                    break
            share = {}
            if fixed is not None:
                share[fixed] = 1.0
            else:
                slot = len(names) - 1
                for n in range(len(names)):
                    if joints[n] >= z >= joints[n + 1]:
                        slot = n
                        break
                else:
                    slot = 0 if z > joints[0] else len(names) - 1
                share[slot] = 1.0
                if blend > 0.0:
                    above = joints[slot] - z
                    below = z - joints[slot + 1]
                    if slot > 0 and above < blend:
                        take = 0.5 * (1.0 - above / blend)
                        share[slot] = 1.0 - take
                        share[slot - 1] = take
                    elif slot + 1 < len(names) and below < blend:
                        take = 0.5 * (1.0 - below / blend)
                        share[slot] = 1.0 - take
                        share[slot + 1] = take
            total = sum(share.values()) or 1.0
            for name in names:
                groups[name].add([index], 0.0, "REPLACE")
            for slot, weight in share.items():
                groups[names[slot]].add([index], weight / total, "REPLACE")
            touched += 1
        obj.data.update()

    if jiggle:
        root = armature.pose.bones.get(names[0])
        if root is not None:
            root["srs_jiggle_stiffness"] = float(jiggle.get("stiffness", 0.5))
            root["srs_jiggle_damping"] = float(jiggle.get("damping", 0.3))
            root["srs_jiggle_gravity"] = float(jiggle.get("gravity", 0.0))
            root["srs_jiggle_inertia"] = float(jiggle.get("inertia", 0.45))
    lengths = [round((centres[n] - centres[n + 1]).length * 1000.0, 2)
               for n in range(len(centres) - 1)]
    return {"key": key, "bones": names, "bone_count": len(names),
            "vertices": touched,
            "rigid_bones": sorted({owner for _h, _l, owner, _m in hard
                                   if owner is not None}),
            "length_mm": round(sum(lengths), 1),
            "segment_mm": {"min": min(lengths), "max": max(lengths),
                           "mean": round(sum(lengths) / len(lengths), 2)}}, ""


def edge_rings(mesh_object, indices=None, min_vertices=1):
    """The part's own edge loops, island by island. ``(rows, error)``.

    A loop here is what it is in the viewport: a RING OF CONNECTED VERTICES
    around the strand, not a cluster of vertices that happen to share a
    coordinate. Taking it as the latter is wrong in two directions at once --
    it merges unrelated rings that cross the same height and splits one ring
    that is tilted -- and on the fringe it reported 7 loops on a strand that
    has 37.

    The walk is an edge-hop field from the ring at one end: every vertex one
    edge further in is the next ring, and so on to the other end. Each row
    reports ``rings`` root-end first as the walk found them, their ``centres``,
    whether the island ``crosses`` the mirror line, and ``middle`` -- the ring
    nearest that line, which is where a strand that runs over the crown and
    down both sides has to be cut in two.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    mesh = mesh_object.data
    scope = set(indices) if indices is not None else \
        {v.index for v in mesh.vertices}
    if not scope:
        return None, "No vertices"
    matrix = mesh_object.matrix_world
    links = [[] for _v in mesh.vertices]
    for edge in mesh.edges:
        a, b = edge.vertices
        links[a].append(b)
        links[b].append(a)
    faces = {}
    for poly in mesh.polygons:
        verts = list(poly.vertices)
        for n in range(len(verts)):
            pair = tuple(sorted((verts[n], verts[(n + 1) % len(verts)])))
            faces[pair] = faces.get(pair, 0) + 1
    border = set()
    for pair, count in faces.items():
        if count == 1:
            border.update(pair)

    rows = []
    groups = [g for g in islands(mesh_object) if set(g) & scope]
    for number, group in enumerate(sorted(groups, key=lambda g: -len(g))):
        inside = set(group) & scope
        if len(inside) < max(1, int(min_vertices)):
            continue
        points = {i: matrix @ mesh.vertices[i].co for i in inside}
        ends = [i for i in inside if i in border] or sorted(inside)
        # start from the lowest open end and walk inwards
        seed = {min(ends, key=lambda i: points[i].z)}
        front = list(seed)
        while front:
            step = []
            for i in front:
                for j in links[i]:
                    if j in inside and j in border and j not in seed:
                        seed.add(j)
                        step.append(j)
            front = step
        rings, seen, level = [], set(seed), sorted(seed)
        while level:
            rings.append(level)
            step = set()
            for i in level:
                for j in links[i]:
                    if j in inside and j not in seen:
                        seen.add(j)
                        step.add(j)
            level = sorted(step)
        covered = sum(len(r) for r in rings)
        centres = [_ring_centre(r, points) for r in rings]
        across = [c.x for c in centres]
        crosses = min(across) < 0.0 < max(across)
        middle = min(range(len(centres)), key=lambda n: abs(centres[n].x))
        rows.append({"island": number, "vertices": sorted(inside),
                     "rings": rings, "centres": centres,
                     "ring_count": len(rings),
                     "ring_sizes": sorted({len(r) for r in rings}),
                     "covered": covered, "complete": covered == len(inside),
                     "crosses": crosses, "middle": middle})
    if not rows:
        return None, "Nothing in that selection forms a strand"
    return rows, ""


def _ring_centre(ring, points):
    total = mathutils.Vector((0.0, 0.0, 0.0))
    for index in ring:
        total = total + points[index]
    return total / len(ring)


def ring_strands(mesh_object, indices=None, split=True, min_loops=4,
                 min_mm=5.0):
    """One row per piece, rings ordered ROOT FIRST. ``(rows, error)``.

    An island is not a strand. On the fringe, five of the seven ribbons run up
    from one side's tip, over the crown and back down to the other side's tip --
    every one of them reports a centre on the mirror line and spans 150 to
    230mm across it. Counting islands gives 7 strands; cutting each of those
    five at the ring nearest the mirror line gives 12, six a side, which is
    what the hair actually is.

    The cut is at that ring, NOT at the highest ring. The crest of the arch sits
    a ring or two to one side of the centre, so splitting by height hands two of
    one side's rings to the other side -- measured on the fringe it made halves
    of 17 and 21 rings out of 37, and the sixth ring of the long half was still
    2mm from the crown instead of down at the brow.

    Not every piece is a strand, and the ones that are not have to be named
    rather than dropped. The fringe carries 8 four-vertex islands sitting
    exactly at the tips of four of the ribbons, 0.0mm long, plus 6 stray
    vertices: loose caps. Each row says whether it is a ``strand``; only those
    are keyed ``l1``..``ln`` / ``r1``..``rn``, and the rest carry ``why`` so the
    caller can weld them to the nearest bone instead of chaining them.
    """
    rows, error = edge_rings(mesh_object, indices=indices)
    if error:
        return None, error
    out = []
    for row in rows:
        rings, centres, middle = row["rings"], row["centres"], row["middle"]
        if split and row["crosses"] and 1 < middle < len(rings) - 2:
            halves = [(list(reversed(rings[:middle + 1])),
                       list(reversed(centres[:middle + 1]))),
                      (rings[middle:], centres[middle:])]
        else:
            if centres[0].z > centres[-1].z:
                halves = [(rings, centres)]
            else:
                halves = [(list(reversed(rings)), list(reversed(centres)))]
        for half_rings, half_centres in halves:
            tip = half_centres[-1]
            run = 0.0
            for n in range(len(half_centres) - 1):
                run += (half_centres[n + 1] - half_centres[n]).length
            out.append({"island": row["island"],
                        "side": "l" if tip.x > 0.0 else "r",
                        "rings": half_rings, "centres": half_centres,
                        "ring_count": len(half_rings),
                        "split": len(halves) > 1,
                        "length_mm": round(run * 1000.0, 1),
                        "root": half_centres[0], "tip": tip})
    for row in out:
        why = ""
        if row["ring_count"] < max(2, int(min_loops)):
            why = "only %d loop(s)" % row["ring_count"]
        elif row["length_mm"] < float(min_mm):
            why = "%.1fmm long" % row["length_mm"]
        row["strand"] = not why
        row["why"] = why
        row["key_hint"] = None
    out.sort(key=lambda r: (r["side"], -r["length_mm"], r["island"]))
    for side in ("l", "r"):
        same = [r for r in out if r["side"] == side and r["strand"]]
        for n, row in enumerate(same):
            row["key_hint"] = "%s%d" % (side, n + 1)
    return out, ""


def attach_strays(mesh_object, indices, pool=None):
    """Give loose vertices whatever their NEAREST NEIGHBOUR carries.

    ``(report, error)``. A cap that is not a strand still has to follow the
    strand it caps -- leaving it on the scalp is the visible failure, the tip
    swings and the cap stays. But choosing the nearest BONE is the mistake this
    project has already paid for: measured on the fringe, 32 tip caps went to
    the right strand's last bone and 6 degenerate doubles on the crown centre
    line went to the LEFT brow hair's first bone 11mm away, because the loops
    they really belong to are in the skipped root stretch and own no bone.

    Copying the nearest real vertex's groups gets both right with one rule: the
    cap's neighbour is the tip ring, so it follows the tip; the crown double's
    neighbour is a skipped root loop, so it stays on the head. ``pool`` is the
    vertices allowed to be copied FROM; the default is everything that is not
    itself loose.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    loose = sorted(set(indices or ()))
    if not loose:
        return {"welded": 0, "sources": []}, ""
    mesh = mesh_object.data
    if pool is None:
        pool = [v.index for v in mesh.vertices if v.index not in set(loose)]
    pool = [i for i in pool if i not in set(loose)]
    if not pool:
        return None, "Nothing to copy from: every vertex is loose"
    matrix = mesh_object.matrix_world
    points = {i: matrix @ mesh.vertices[i].co for i in pool}
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    groups = {}
    welded, sources, worst = 0, {}, 0.0
    for index in loose:
        point = matrix @ mesh.vertices[index].co
        near, gap = None, None
        for other in pool:
            step = (point - points[other]).length
            if gap is None or step < gap:
                gap, near = step, other
        carried = [(names[e.group], e.weight)
                   for e in mesh.vertices[near].groups if e.weight > 0.0]
        if not carried:
            continue
        for group in mesh_object.vertex_groups:
            group.remove([index])
        for name, weight in carried:
            if name not in groups:
                groups[name] = mesh_object.vertex_groups.get(name) \
                    or mesh_object.vertex_groups.new(name=name)
            groups[name].add([index], weight, "REPLACE")
        top = max(carried, key=lambda row: row[1])[0]
        sources[top] = sources.get(top, 0) + 1
        worst = max(worst, gap * 1000.0)
        welded += 1
    mesh_object.data.update()
    return {"welded": welded, "loose": len(loose),
            "furthest_mm": round(worst, 2),
            "sources": sorted(sources.items(), key=lambda row: -row[1])}, ""


def edge_layers(mesh_object, indices):
    """The selection's loops, root first, by connectivity from its top edge. ``(layers, error)``.

    The root loop is the selected vertices that touch an unselected vertex of the same
    mesh; each next loop is everything selected one edge further away.
    """
    chosen = set(indices or ())
    if not chosen:
        return [], "Select the strap's vertices in Edit Mode, from the loop where it should start."
    adjacent = {}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        adjacent.setdefault(a, set()).add(b)
        adjacent.setdefault(b, set()).add(a)
    root = {i for i in chosen if any(j not in chosen for j in adjacent.get(i, ()))}
    if not root:
        return [], "The selection is a whole piece; select from the loop where the strap should start."
    layers, seen, layer = [], set(root), set(root)
    while layer:
        layers.append(sorted(layer))
        layer = {j for i in layer for j in adjacent.get(i, ()) if j in chosen and j not in seen}
        seen |= layer
    if len(layers) < 2:
        return [], "The selection has fewer than two loops."
    return layers, ""


def chain_on_rings(mesh_object, armature, rings, key, prefix="srs_chain",
                   parent_bone="", bone_collection="", first_ring=0,
                   blend_rings=2, jiggle=None, takeover=1.0, connected=True,
                   indices=None, min_mm=0.0, root_follow=False):
    """One bone per edge loop, each pivot at that loop's own centre.

    ``rings`` is the strand's loops ROOT FIRST -- what :func:`ring_strands`
    returns. Bone ``n`` runs from the centre of ring ``first_ring + n`` to the
    centre of the next one, and that ring's vertices are weighted to it, so the
    joint sits exactly where the geometry already divides and the artist can
    turn one loop at a time. The last bone carries the tip ring and is extended
    along the strand so the very end stays posable.

    ``first_ring`` skips the root: hair that grows out of the scalp barely moves
    there, and a bone per loop through the first few loops is just clutter the
    animator has to step over. ``blend_rings`` shares the first bones with
    whatever was deforming those vertices, so the handover is not a hard edge --
    both ends of one quad on different bones at 1.0 is the seam defect this
    project keeps measuring. The share goes to the vertex's own heaviest
    existing group, NOT to ``parent_bone``: the chain hangs off a controller
    here and the deformer is a different bone, and weight in a group no bone
    uses is weight lost.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    rings = [list(r) for r in rings or ()]
    first = max(0, int(first_ring))
    if len(rings) - first < 2:
        return None, ("That strand has %d loop(s) past the %dth; a chain needs "
                      "two" % (max(0, len(rings) - first), first))
    matrix = mesh_object.matrix_world
    points = {}
    for ring in rings:
        for index in ring:
            points[index] = matrix @ mesh_object.data.vertices[index].co
    centres = [_ring_centre(r, points) for r in rings][first:]
    taken = rings[first:]
    # the strand's own loop number of every vertex, before any merging
    loop_of = {}
    for k, ring in enumerate(taken):
        for index in ring:
            loop_of.setdefault(index, k)
    if float(min_mm) > 0.0 and len(taken) > 2:
        # Never a bone shorter than min_mm: a metal tip or a curl divided every
        # 2mm made 2.4mm links that thrashed in the bake and tore the strap
        # (MIK_128, 2026-10-03: 154x, 337mm). Consecutive loops closer than that
        # are carried by one bone, which still starts on a loop.
        merged_rings, merged_centres = [list(taken[0])], [centres[0]]
        for ring, centre in zip(taken[1:], centres[1:]):
            if (centre - merged_centres[-1]).length * 1000.0 < float(min_mm):
                merged_rings[-1].extend(ring)
            else:
                merged_rings.append(list(ring))
                merged_centres.append(centre)
        if len(merged_rings) < 2:
            # the whole strand is shorter than min_mm: two halves, not a bone per
            # loop (a 30 mm buckle tip fell back to five 2-8 mm links that spun)
            half = max(1, len(taken) // 2)
            first = [i for ring in taken[:half] for i in ring]
            second = [i for ring in taken[half:] for i in ring]
            merged_rings = [first, second]
            merged_centres = [centres[0], centres[half]]
        taken, centres = merged_rings, merged_centres

    heads, tails = [], []
    for n in range(len(centres)):
        head = centres[n]
        if n + 1 < len(centres):
            tail = centres[n + 1]
        else:
            step = centres[n] - centres[n - 1]
            if step.length <= 1.0e-6:
                step = mathutils.Vector((0.0, 0.0, -0.005))
            tail = centres[n] + step
        if (tail - head).length <= 1.0e-6:
            tail = head + mathutils.Vector((0.0, 0.0, -0.002))
        heads.append(head)
        tails.append(tail)

    follow = {}
    if root_follow:
        # the surface next to the chain: vertices joined to its first loop and not in it
        neighbours_ = {}
        for edge in mesh_object.data.edges:
            a_, b_ = edge.vertices
            neighbours_.setdefault(a_, []).append(b_)
            neighbours_.setdefault(b_, []).append(a_)
        inside = set(loop_of)
        rim = {j for i, k in loop_of.items() if k == 0 for j in neighbours_.get(i, ()) if j not in inside}
        deform_ = {b.name for b in armature.data.bones if b.use_deform}
        for i in rim:
            row = {}
            for entry in mesh_object.data.vertices[i].groups:
                name = mesh_object.vertex_groups[entry.group].name
                if name in deform_ and entry.weight > 0.0:
                    row[name] = entry.weight
            total = sum(row.values())
            for name, w in row.items():
                follow[name] = follow.get(name, 0.0) + w / total / len(rim)
        follow = {n: w for n, w in follow.items() if w > 0.005}
    names = ["%s_%s_%02d" % (prefix, key, n + 1) for n in range(len(heads))]
    previous = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        parent = edit.get(parent_bone) if parent_bone else None
        made = []
        to_rig = armature.matrix_world.inverted()
        for n, name in enumerate(names):
            bone = edit.get(name) or edit.new(name)
            # world -> the rig's own space: a rig that is not at the origin (a
            # character lifted onto its soles) got its chain h too high
            bone.head = to_rig @ heads[n]
            bone.tail = to_rig @ tails[n]
            bone.use_deform = True
            bone.parent = made[-1] if made else parent
            bone.use_connect = bool(connected) and bool(made)
            made.append(bone)
        follower = None
        if root_follow and follow:
            follower = edit.get("%s_%s_root" % (prefix, key)) or edit.new("%s_%s_root" % (prefix, key))
            follower.head, follower.tail, follower.roll = made[0].head.copy(), made[0].tail.copy(), made[0].roll
            follower.parent = None
            follower.use_deform = False
            made[0].parent = follower
            made[0].use_connect = False
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous
    if root_follow and follow:
        pose_bone = armature.pose.bones["%s_%s_root" % (prefix, key)]
        for con in list(pose_bone.constraints):
            pose_bone.constraints.remove(con)
        con = pose_bone.constraints.new("ARMATURE")
        con.name = "SRS follow the surface"
        con.use_deform_preserve_volume = any(
            m.type == "ARMATURE" and m.object == armature and m.use_deform_preserve_volume
            for m in mesh_object.modifiers)
        for name, w in sorted(follow.items(), key=lambda kv: -kv[1]):
            target_ = con.targets.new()
            target_.target = armature
            target_.subtarget = name
            target_.weight = w
        mch = armature.data.collections_all.get("SRS Chain MCH") or armature.data.collections.new("SRS Chain MCH")
        mch.is_visible = False
        mch.assign(armature.data.bones["%s_%s_root" % (prefix, key)])

    if bone_collection:
        target = armature.data.collections_all.get(bone_collection)
        if target is None:
            target = armature.data.collections.new(bone_collection)
        for name in names:
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)

    groups = {}
    for name in names:
        groups[name] = mesh_object.vertex_groups.get(name) \
            or mesh_object.vertex_groups.new(name=name)

    # 馴染ませる分は「その頂点をそれまで動かしていたボーン」へ返す。
    # 親ボーンの名前では足りない ── この鎖は c_head.x から下がるが、頂点を
    # 変形させているのは head.x で、制御ボーンのグループへ入れた重みは
    # 誰も使わないので消える。実測で 800 頂点のうち 96 が合計 0.5 になった。
    blend = max(0, int(blend_rings))
    mine = set(names)
    held = {}
    # Only groups that are BONES of an armature deforming this mesh are weights.
    # Anything else is a mask or a tool's own data -- the arm belt carries
    # SRS_band_width, which routes each vertex through one of two Armature
    # modifiers. Blending a chain into that mask, or stripping it, put a buckle
    # tip's root through both passes at once: 199 mm of stretch with the bake muted.
    rigs = [m.object for m in mesh_object.modifiers
            if m.type == "ARMATURE" and m.object is not None and m.object.type == "ARMATURE"]
    if armature not in rigs:
        rigs.append(armature)

    def is_weight(name):
        return any(r_.data.bones.get(name) is not None for r_ in rigs)

    def heaviest(index):
        """The vertex's own weight mix on bones outside the chain, normalised, or None."""
        mix = {}
        for entry in mesh_object.data.vertices[index].groups:
            name = mesh_object.vertex_groups[entry.group].name
            if name in mine or name.startswith(prefix + "_") or not is_weight(name):
                continue
            if entry.weight > 0.0:
                mix[name] = entry.weight
        total = sum(mix.values())
        if total <= 1.0e-9:
            return None
        return {n: w / total for n, w in mix.items()}

    blending = [i for i, k in loop_of.items() if k < blend]
    for index in blending:
        owner = heaviest(index)
        if owner is not None:
            held[index] = owner
    orphans = [i for i in blending if i not in held]
    if orphans:
        # A chain rebuilt after Clear Chain leaves its first loops with no group
        # at all. Take the owner of the nearest vertex OUTSIDE the chain, through
        # the mesh -- for a strap, the wrap it hangs from.
        chain_vertices = set(loop_of)
        neighbours = {}
        for edge in mesh_object.data.edges:
            a, b = edge.vertices
            neighbours.setdefault(a, []).append(b)
            neighbours.setdefault(b, []).append(a)
        reached, frontier = {}, []
        for index in chain_vertices:
            for other in neighbours.get(index, ()):
                if other not in chain_vertices and other not in reached:
                    owner = heaviest(other)
                    if owner is not None:
                        reached[other] = owner
                        frontier.append(other)
        while frontier:
            step = []
            for index in frontier:
                for other in neighbours.get(index, ()):
                    if other in chain_vertices and other not in reached:
                        reached[other] = reached[index]
                        step.append(other)
            frontier = step
        for index in orphans:
            if index in reached:
                held[index] = reached[index]

    # 鎖が受け取る頂点から、もとの重みを外す。残すと体の 1.0 と鎖の 1.0 を
    # 両方持ったまま正規化へ回り、揺れが半分になって残り半分は溶接される。
    strip = max(0.0, min(1.0, 1.0 - float(takeover)))
    covered = sorted({i for ring in taken for i in ring})
    if strip < 0.999:
        for group in mesh_object.vertex_groups:
            if group.name in mine or not is_weight(group.name):
                continue
            if strip <= 0.001:
                group.remove(covered)
                continue
            for index in covered:
                current = None
                for entry in mesh_object.data.vertices[index].groups:
                    if entry.group == group.index:
                        current = entry.weight
                        break
                if current is None:
                    continue
                group.add([index], current * strip, "REPLACE")

    touched, blended = 0, 0
    for n, ring in enumerate(taken):
        for index in ring:
            for name in names:
                groups[name].add([index], 0.0, "REPLACE")
            # a ramp that continues the outside: the loop next to it keeps
            # blend/(blend+1) of the owner, the last blended loop 1/(blend+1)
            k = loop_of.get(index, blend)
            want = float(blend - k) / float(blend + 1) if blend and k < blend else 0.0
            share = want if index in held else 0.0
            groups[names[n]].add([index], 1.0 - share, "REPLACE")
            if share > 0.0:
                # the whole mix the surface had there, not one bone of it
                for owner, part in held[index].items():
                    group = mesh_object.vertex_groups.get(owner) or mesh_object.vertex_groups.new(name=owner)
                    group.add([index], share * part, "REPLACE")
                blended += 1
            touched += 1
    mesh_object.data.update()

    if jiggle:
        root = armature.pose.bones.get(names[0])
        if root is not None:
            root["srs_jiggle_stiffness"] = float(jiggle.get("stiffness", 0.5))
            root["srs_jiggle_damping"] = float(jiggle.get("damping", 0.3))
            root["srs_jiggle_gravity"] = float(jiggle.get("gravity", 0.0))
            root["srs_jiggle_inertia"] = float(jiggle.get("inertia", 0.45))

    gaps = [round((tails[n] - heads[n]).length * 1000.0, 2)
            for n in range(len(heads))]
    return {"key": key, "bones": names, "bone_count": len(names),
            "vertices": touched, "rings_used": len(taken),
            "rings_skipped": first, "blended_vertices": blended,
            "handover": sorted({n for mix in held.values() for n in mix}),
            "parent": parent_bone, "blend_rings": blend,
            "segment_mm": {"min": min(gaps), "max": max(gaps)},
            "root": [round(v * 1000.0, 1) for v in heads[0]],
            "root_follows": {n: round(w, 3) for n, w in follow.items()} if root_follow else {},
            "tip": [round(v * 1000.0, 1) for v in tails[-1]]}, ""


def loop_positions(mesh_object, indices=None, axis="Z", tol_mm=1.5):
    """The mesh's own divisions along an axis. ``[(position, vertex count)]``.

    A ring of a tube, a row of a ribbon: the vertices sitting at the same height
    are one division, and a joint belongs on one of these and nowhere else -- a
    joint between two rings has no vertices of its own to rotate about, so the
    ring above and the ring below share it and the surface creases between them.

    Cluster against the group's OWN start, never against the previous value: a
    dense run of vertices each less than the tolerance from the last merges into
    one cluster spanning the whole strand. Measured while getting this wrong, a
    464mm hair element reported 7 divisions, one of them holding 2434 vertices.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return []
    lane = AXIS.get(str(axis).upper())
    if lane is None:
        return []
    matrix = mesh_object.matrix_world
    scope = sorted(set(indices)) if indices is not None else \
        range(len(mesh_object.data.vertices))
    values = sorted((matrix @ mesh_object.data.vertices[i].co)[lane]
                    for i in scope)
    if not values:
        return []
    tol = float(tol_mm) / 1000.0
    out, start, group = [], values[0], [values[0]]
    for value in values[1:]:
        if value - start <= tol:
            group.append(value)
            continue
        out.append((sum(group) / len(group), len(group)))
        start, group = value, [value]
    out.append((sum(group) / len(group), len(group)))
    return out


def element_spans(objects, axis="Z", rigid_match="metal", by_material=False):
    """Each piece's extent along the axis, top first, with its hardness.

    ``[{"name", "lo", "hi", "rigid", "verts", "indices", "object"}]`` in metres.
    A hair tail is modelled as separate objects, so the pieces are objects; a
    costume mixes them inside one mesh, so ``by_material`` splits the islands of
    one mesh by whether they carry the rigid material instead.
    """
    lane = AXIS.get(str(axis).upper())
    if lane is None:
        return [], "Axis must be X, Y or Z"
    rows = []
    for obj in objects or ():
        if obj is None or obj.type != "MESH":
            continue
        matrix = obj.matrix_world
        if by_material:
            hard = set()
            slots = [n for n, slot in enumerate(obj.material_slots)
                     if slot.material
                     and rigid_match.lower() in slot.material.name.lower()]
            for poly in obj.data.polygons:
                if poly.material_index in slots:
                    hard.update(poly.vertices)
            for group in islands(obj):
                values = [(matrix @ obj.data.vertices[i].co)[lane]
                          for i in group]
                if not values:
                    continue
                share = len(set(group) & hard) / float(len(group))
                rows.append({"name": "%s#%d" % (obj.name, group[0]),
                             "object": obj, "indices": sorted(group),
                             "lo": min(values), "hi": max(values),
                             "rigid": share >= 0.5, "verts": len(group)})
            continue
        values = [(matrix @ v.co)[lane] for v in obj.data.vertices]
        if not values:
            continue
        rows.append({"name": obj.name, "object": obj,
                     "indices": list(range(len(obj.data.vertices))),
                     "lo": min(values), "hi": max(values),
                     "rigid": rigid_match.lower() in obj.name.lower(),
                     "verts": len(values)})
    rows.sort(key=lambda r: -r["hi"])
    return rows, ""


def pivot_plan(spans, loops, target_mm=0.0, every=1, root_mm=0.0,
               root_span_mm=0.0, min_gap_mm=3.0, top=None, bottom=None):
    """Where the joints go. ``(positions, report)``, top down, in metres.

    Three rules, in this order:

    * **A rigid piece gets its two boundaries and nothing between them.** A joint
      inside a solid element bends what cannot bend; measured on one hair tail,
      even division put 6 of its 13 joints inside rigid metal.
    * **Every other joint sits on one of the mesh's own divisions.** The
      positions are chosen from ``loops``, never computed.
    * **The spacing does not jump.** With ``target_mm`` the nearest division to
      each step is taken, so a part whose divisions are 2mm apart does not get a
      joint every 2mm; with ``every`` each Nth division is taken instead, which
      is right when the divisions are already the spacing you want. ``root_mm``
      over ``root_span_mm`` from the top asks for a finer target there, for a
      part whose root is the part that fouls something.
    """
    rails = sorted({round(float(z), 7) for z, _n in loops or ()}, reverse=True)
    if not rails:
        return [], {"error": "the mesh has no divisions along that axis"}
    hard = [(s["hi"], s["lo"]) for s in spans or () if s.get("rigid")]
    # the caller may know the ends better than the spans do: a strap's wrapped
    # part and its hanging part are one island, so the island's extent is not
    # where the hanging part starts
    top = float(top) if top is not None else         max([s["hi"] for s in spans or ()] + [rails[0]])
    bottom = float(bottom) if bottom is not None else         min([s["lo"] for s in spans or ()] + [rails[-1]])
    rails = [z for z in rails if bottom - 1.0e-6 <= z <= top + 1.0e-6]
    if not rails:
        return [], {"error": "no division lies between the given ends"}

    def inside_hard(z):
        return any(lo + 1.0e-5 < z < hi - 1.0e-5 for hi, lo in hard)

    forced = {round(top, 7), round(bottom, 7)}
    for hi, lo in hard:
        for edge in (hi, lo):
            if not inside_hard(edge):
                forced.add(round(edge, 7))
    free = [z for z in rails if not inside_hard(z) and z not in forced]
    pool = sorted(forced | set(free), reverse=True)

    step = float(target_mm) / 1000.0 if target_mm else 0.0
    fine = float(root_mm) / 1000.0 if root_mm else step
    edge_z = top - float(root_span_mm) / 1000.0 if root_span_mm else bottom
    floor = float(min_gap_mm) / 1000.0

    def wanted_step(z):
        use = fine if z > edge_z else step
        return max(use, floor)

    if step <= 0.0 and not root_mm:
        keep = max(1, int(every))
        out = [pool[0]]
        seen = 0
        for z in pool[1:]:
            if z in forced:
                if (out[-1] - z) * 1000.0 >= 0.5:
                    out.append(z)
                seen = 0
                continue
            seen += 1
            if seen % keep:
                continue
            if (out[-1] - z) >= floor:
                out.append(z)
    else:
        out = [pool[0]]
        for z in pool[1:]:
            gap = out[-1] - z
            if z in forced:
                if gap * 1000.0 >= 0.5:
                    out.append(z)
                continue
            if gap >= wanted_step(out[-1]) * 0.6:
                out.append(z)
        # a gap much wider than asked for is split with the divisions inside it,
        # so a sparse stretch does not end up as one long rigid paddle
        again = [out[0]]
        for z in out[1:]:
            room = again[-1] - z
            want = wanted_step(again[-1])
            if want > 0.0 and room > want * 1.8:
                count = int(room / want)
                for n in range(1, count + 1):
                    aim = again[-1] - room * n / float(count + 1)
                    pick = None
                    best = None
                    for rail in free:
                        if not (z < rail < again[-1]):
                            continue
                        delta = abs(rail - aim)
                        if best is None or delta < best:
                            pick, best = rail, delta
                    if pick is not None and (again[-1] - pick) >= floor \
                            and (pick - z) >= floor:
                        again.append(pick)
            again.append(z)
        out = again

    out = sorted({round(z, 7) for z in out}, reverse=True)
    gaps = [round((out[i] - out[i + 1]) * 1000.0, 2)
            for i in range(len(out) - 1)]
    on_rail = sum(1 for v in out if any(abs(v - r) < 1.0e-6 for r in rails))
    return out, {"joints": len(out), "bones": max(0, len(out) - 1),
                 "on_division": on_rail,
                 "rigid_pieces": len(hard),
                 "inside_rigid": sum(1 for v in out if inside_hard(v)),
                 "gap_mm": {"min": min(gaps) if gaps else 0.0,
                            "max": max(gaps) if gaps else 0.0,
                            "mean": round(sum(gaps) / len(gaps), 2)
                            if gaps else 0.0},
                 "gaps_mm": gaps}


def clear_contact(part, donor, clearance_mm=1.5, indices=None,
                  rest_pose=True, max_push_mm=10.0):
    """Lift only the vertices that graze the layer beneath. ``(report, error)``.

    Not a clamp and not a re-bind: this edits the stored mesh once, moving each
    vertex that sits closer than ``clearance_mm`` outward along the surface
    normal until it reaches that standoff, and leaving every other vertex exactly
    where it was modelled.

    It exists because the obvious diagnosis was wrong. A belt wrapped round a
    sleeve read 2079 intersecting triangle pairs at rest, which looks like a part
    modelled inside another; measured per vertex, the bands sit a median 6.68mm
    OUTSIDE the sleeve, with 5 % of them grazing it between -0.12mm and -6.02mm
    and only two vertices deeper than 5mm. The pairs come from contact, not from
    embedding, and contact is what a belt does. So the whole part must not be
    moved -- only the few that touch.

    ``max_push_mm`` refuses a vertex that would have to travel further than that,
    because such a vertex is not grazing: it is behind a fold, or the nearest
    surface it found is the wrong side of one, and pushing it "out" would put it
    somewhere the artist never intended.
    """
    if part is None or part.type != "MESH":
        return None, "Select the part"
    if donor is None or donor.type != "MESH":
        return None, "Name the part underneath"
    if part is donor:
        return None, "A part cannot be cleared of itself"
    armature = None
    for modifier in part.modifiers:
        if modifier.type == "ARMATURE" and modifier.object is not None:
            armature = modifier.object
    saved_pose = None
    hidden = []
    moved, refused, worst = 0, 0, 0.0
    try:
        if rest_pose and armature is not None:
            saved_pose = armature.data.pose_position
            armature.data.pose_position = "REST"
        for obj in (part, donor):
            for modifier in obj.modifiers:
                if modifier.type != "ARMATURE" and modifier.show_viewport:
                    modifier.show_viewport = False
                    hidden.append(modifier)
        bpy.context.view_layer.update()
        tree, _points, polygons = _world_faces(donor)
        if tree is None or not polygons:
            return None, "The part underneath has no faces"
        matrix = part.matrix_world
        inverse = matrix.inverted()
        want = float(clearance_mm) / 1000.0
        cap = float(max_push_mm) / 1000.0
        scope = sorted(set(indices)) if indices is not None else \
            [v.index for v in part.data.vertices]
        shifts = []
        for index in scope:
            world = matrix @ part.data.vertices[index].co
            hit = tree.find_nearest(world)
            if hit is None or hit[0] is None:
                continue
            location, normal, _face, _distance = hit
            offset = (world - location).dot(normal)
            if offset >= want:
                continue
            push = want - offset
            if push > cap:
                refused += 1
                continue
            shifts.append((index, normal * push))
            worst = max(worst, push)
        for index, delta in shifts:
            vertex = part.data.vertices[index]
            vertex.co = inverse @ ((matrix @ vertex.co) + delta)
            moved += 1
        part.data.update()
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
        if saved_pose is not None:
            armature.data.pose_position = saved_pose
        bpy.context.view_layer.update()
    return {"part": part.name, "donor": donor.name,
            "clearance_mm": round(float(clearance_mm), 3),
            "moved": moved, "refused": refused,
            "considered": len(scope),
            "worst_push_mm": round(worst * 1000.0, 3)}, ""


KEEP_OUTSIDE = "SRS keep outside"


KEEP_GROUP = "SRS outside at rest"


def rest_outside_group(part, donor, name=KEEP_GROUP, slack_mm=0.0):
    """Mark the vertices that are OUTSIDE the layer beneath at the current frame.

    ``(report, error)``. A costume is authored with parts overlapping -- this
    character's belt hangs 53mm inside the sleeve in the rest pose, by design --
    so a clamp that pushes everything inside back out moves that geometry 53mm
    and destroys the shape. Measured: clamping the whole part took the belt's
    crossings from 1509 vertices to 459 and its stretched vertices from 0.15 %
    to 43.31 %, with an edge at 170 times its rest length.

    The vertices worth clamping are exactly the ones that start outside, which
    is what this records.
    """
    if part is None or part.type != "MESH":
        return None, "Select the part"
    if donor is None or donor.type != "MESH":
        return None, "Name the part underneath"
    hidden = []
    for obj in (part, donor):
        for modifier in obj.modifiers:
            if modifier.type != "ARMATURE" and modifier.show_viewport:
                modifier.show_viewport = False
                hidden.append(modifier)
    try:
        bpy.context.view_layer.update()
        offsets = _signed_offsets(part, donor)
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
    if offsets is None:
        return None, "The part underneath has no faces"
    if len(offsets) != len(part.data.vertices):
        return None, ("The evaluated mesh has %d vertices and the stored one "
                      "%d, so the mark cannot be written back"
                      % (len(offsets), len(part.data.vertices)))
    group = part.vertex_groups.get(name) or part.vertex_groups.new(name=name)
    limit = float(slack_mm) / 1000.0
    outside = []
    inside = []
    for index, value in enumerate(offsets):
        if value is not None and value >= -limit:
            outside.append(index)
        else:
            inside.append(index)
    if outside:
        group.add(outside, 1.0, "REPLACE")
    if inside:
        group.add(inside, 0.0, "REPLACE")
    return {"part": part.name, "group": name, "outside": len(outside),
            "inside": len(inside)}, ""


def keep_outside(part, donor, offset_mm=1.5, vertex_group="", invert=False,
                 name=KEEP_OUTSIDE, only_rest_outside=True):
    """Stop a part from sinking into the one underneath it. ``(report, error)``.

    Weights cannot always do this. A belt wrapped round a sleeve has to cross the
    sleeve's surface when the elbow folds, because both are thin shells and the
    fold closes on itself; measured here, sharing the sleeve's weight field took
    the belt's crossings from 1509 vertices to 1202 and no further, while making
    the belt's own edges five times worse -- reading a folded shell's weights by
    nearest surface picks up the far side of the fold.

    A Shrinkwrap in ``OUTSIDE`` mode leaves every vertex that is already outside
    where the armature put it and moves only the ones that went in. It is added
    after the armature, so it clamps the deformed result rather than the rest
    shape.

    ``only_rest_outside`` limits it to the vertices that start outside, through a
    vertex group, so the geometry the artist deliberately tucked underneath is
    not dragged out with the rest -- see :func:`rest_outside_group`.

    **This is for a solid part resting on a smooth surface, not for a band
    wrapped round a joint.** Measured on this character's belt and sleeve with
    every modifier live, over 240 frames of capture, as
    crossings / worst edge ratio / broken edges:

    ==================  ===================  ==========================
    part                without              with the clamp
    ==================  ===================  ==========================
    belt on sleeve      5958 / 1.94 / 4      1334 / **1190.6** / 3261
    sleeve on body      1496 / 5.49 / 403    216 / **52.6** / 1186
    arm band on sleeve  42 / 1.06 / 0        168 / **59.7** / 448
    ==================  ===================  ==========================

    It buys the clearance by dragging vertices along the surface, and a band that
    has to cross a folding elbow gets dragged a long way -- on the arm bands even
    the crossing got worse. Read ``edge_ratio`` from :func:`penetration` with
    ``full_stack=True`` before keeping it. Where the crossing is a fold closing
    on itself, cloth with collision is the tool and skinning is not.
    """
    if part is None or part.type != "MESH":
        return None, "Select the part"
    if donor is None or donor.type != "MESH":
        return None, "Name the part underneath"
    if part is donor:
        return None, "A part cannot be kept outside itself"
    marked = None
    if only_rest_outside and not vertex_group:
        existing = part.modifiers.get(name)
        was = existing.show_viewport if existing is not None else None
        if existing is not None:
            existing.show_viewport = False
        try:
            marked, error = rest_outside_group(part, donor)
        finally:
            if existing is not None and was is not None:
                existing.show_viewport = was
        if error:
            return None, error
        vertex_group = marked["group"]
    modifier = part.modifiers.get(name)
    if modifier is None:
        modifier = part.modifiers.new(name=name, type="SHRINKWRAP")
    if modifier is None:
        return None, "Blender refused the modifier"
    modifier.wrap_method = "NEAREST_SURFACEPOINT"
    modifier.wrap_mode = "OUTSIDE"
    modifier.target = donor
    modifier.offset = float(offset_mm) / 1000.0
    modifier.vertex_group = vertex_group or ""
    modifier.invert_vertex_group = bool(invert)
    # after the armature or it clamps the rest shape, which does nothing
    order = [m.name for m in part.modifiers]
    armature_at = max([i for i, n in enumerate(order)
                       if part.modifiers[n].type == "ARMATURE"] or [-1])
    moved = False
    if armature_at >= 0 and order.index(name) < armature_at:
        part.modifiers.move(order.index(name), armature_at)
        moved = True
    return {"part": part.name, "target": donor.name,
            "offset_mm": round(float(offset_mm), 3),
            "modifier": name, "reordered": moved,
            "group": vertex_group,
            "outside": (marked or {}).get("outside"),
            "inside": (marked or {}).get("inside"),
            "after_armature": armature_at >= 0}, ""


def drop_keep_outside(part, name=KEEP_OUTSIDE):
    """Take the clamp off again. ``(report, error)``."""
    if part is None or part.type != "MESH":
        return None, "Select the part"
    modifier = part.modifiers.get(name)
    if modifier is None:
        return {"part": part.name, "removed": False}, ""
    part.modifiers.remove(modifier)
    return {"part": part.name, "removed": True}, ""


def _evaluated_edges(obj):
    """``(lengths, keys)`` for the evaluated mesh's own edges, in its own order."""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    matrix = obj.matrix_world
    data = evaluated.data
    points = [matrix @ v.co for v in data.vertices]
    out = []
    for edge in data.edges:
        a, b = edge.vertices
        if max(a, b) < len(points):
            out.append((points[a] - points[b]).length)
    return out


def _signed_offsets(outer, inner):
    """How far each of the outer part's vertices sits outside the inner surface.

    Negative is inside. Both meshes are read evaluated, so the armature is in
    play; the caller is responsible for having suspended anything else.
    """
    from mathutils.bvhtree import BVHTree

    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = inner.evaluated_get(depsgraph)
    matrix = inner.matrix_world
    points = [matrix @ v.co for v in evaluated.data.vertices]
    polygons = [list(p.vertices) for p in evaluated.data.polygons]
    if not polygons:
        return None
    tree = BVHTree.FromPolygons(points, polygons, all_triangles=False,
                                epsilon=0.0)
    outer_eval = outer.evaluated_get(depsgraph)
    outer_matrix = outer.matrix_world
    out = []
    for vertex in outer_eval.data.vertices:
        point = outer_matrix @ vertex.co
        hit = tree.find_nearest(point)
        if hit is None or hit[0] is None:
            out.append(None)
            continue
        location, normal, _face, _distance = hit
        out.append((point - location).dot(normal))
    return out


def _world_faces(mesh_object):
    """``(BVHTree, points, polygons)`` for the evaluated mesh, in world space."""
    from mathutils.bvhtree import BVHTree

    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = mesh_object.evaluated_get(depsgraph)
    matrix = mesh_object.matrix_world
    points = [matrix @ v.co for v in evaluated.data.vertices]
    polygons = [list(p.vertices) for p in evaluated.data.polygons]
    if not polygons:
        return None, points, polygons
    return (BVHTree.FromPolygons(points, polygons, all_triangles=False,
                                 epsilon=0.0), points, polygons)


def penetration(outer, inner, armature=None, frame_start=1, frame_end=0,
                step=8, rest_frame=None, keep_modifiers=(), full_stack=False):
    """Does the outer part sink into the inner one when the character moves?

    ``(report, error)``. The stretch check cannot see this at all -- two meshes
    pass straight through one another with every edge keeping its length.

    **Intersecting triangles, not distances.** A nearest-point test on a folded
    surface reports the fold rather than the breach, and the sleeve folds at the
    elbow, which is exactly where the belt is. The primary number is therefore
    the count of triangle pairs of the two meshes that actually intersect, the
    same test :func:`rig_hygiene.penetration` uses for a single pose.

    **Measured against rest, not against zero.** A costume is modelled with
    parts already overlapping: on this character the belt's dangling strap sits
    inside the sleeve in the rest pose, by design, and its triangles intersect
    there too. What the eye catches is a part that goes *further in than it
    was*, so the rest frame's own pair count is the baseline and what is
    reported is the excess over it.

    ``full_stack`` leaves every modifier on, which is the only way to judge a
    clamp that sits behind a Subdivision: with the Subdivision suspended the
    clamp snaps the coarse cage rather than the surface, and the numbers then
    describe a stack that never exists. In that mode the report also carries
    ``edge_ratio`` -- the worst length change among the outer part's own
    evaluated edges against their rest lengths -- because a clamp buys its
    clearance by dragging vertices along the surface, and that cost has to be
    read from the same evaluation. Bone attribution is dropped, the evaluated
    vertices no longer being the stored ones.
    """
    if outer is None or outer.type != "MESH":
        return None, "Select the outer part"
    if inner is None or inner.type != "MESH":
        return None, "Name the part underneath"
    scene = bpy.context.scene
    end = int(frame_end) if int(frame_end) > 0 else int(scene.frame_end)
    start = int(frame_start)
    if end < start:
        return None, "The frame range is empty"
    base_frame = int(rest_frame) if rest_frame is not None else start

    spare = {"ARMATURE"} | {str(t).upper() for t in keep_modifiers or ()}
    hidden = []
    if not full_stack:
        for obj in (outer, inner):
            for modifier in obj.modifiers:
                if modifier.type not in spare and modifier.show_viewport:
                    modifier.show_viewport = False
                    hidden.append(modifier)

    dominant = []
    if armature is not None and armature.type == "ARMATURE":
        deform = {b.name for b in armature.data.bones if b.use_deform}
        by_index = {g.index: g.name for g in outer.vertex_groups}
        for vertex in outer.data.vertices:
            best, weight = None, 0.0
            for entry in vertex.groups:
                name = by_index.get(entry.group)
                if name in deform and entry.weight > weight:
                    best, weight = name, entry.weight
            dominant.append(best or "?")

    saved = scene.frame_current
    worst_sink, worst_frame, worst_index = 0.0, base_frame, -1
    worst_crossed, crossed_frame = 0, base_frame
    by_bone = {}
    # the modifiers are the caller's, not ours: an exception in the middle of
    # the walk must not leave a character with its modifiers switched off
    try:
        scene.frame_set(base_frame)
        bpy.context.view_layer.update()
        rest = _signed_offsets(outer, inner)
        if rest is None:
            return None, "The part underneath has no faces"
        rest_edges = _evaluated_edges(outer) if full_stack else []
        worst_ratio, ratio_frame = 1.0, base_frame
        broken_edges = 0
        tree_a, _pts_a, polys_a = _world_faces(outer)
        tree_b, _pts_b, _polys_b = _world_faces(inner)
        rest_pairs = len(tree_a.overlap(tree_b)) if (tree_a and tree_b) else 0
        worst_pairs, pairs_frame = rest_pairs, base_frame
        face_owner = []
        if dominant and polys_a:
            for face in polys_a:
                names = [dominant[i] for i in face
                         if i < len(dominant)]
                face_owner.append(max(set(names), key=names.count)
                                  if names else "?")
        by_face = {}
        for frame in range(start, end + 1, max(1, int(step))):
            scene.frame_set(frame)
            bpy.context.view_layer.update()
            now = _signed_offsets(outer, inner)
            if now is None or len(now) != len(rest):
                continue
            crossed = 0
            for index, value in enumerate(now):
                was = rest[index]
                if value is None or was is None:
                    continue
                sink = was - value
                if was >= 0.0 > value:
                    crossed += 1
                    bone = dominant[index] if index < len(dominant) else "?"
                    row = by_bone.setdefault(bone, [0, 0.0])
                    row[0] += 1
                    row[1] = max(row[1], sink)
                if sink > worst_sink:
                    worst_sink, worst_frame, worst_index = sink, frame, index
            if crossed > worst_crossed:
                worst_crossed, crossed_frame = crossed, frame
            tree_a, _pts, _polys = _world_faces(outer)
            tree_b, _pts2, _polys2 = _world_faces(inner)
            if tree_a is not None and tree_b is not None:
                hits = tree_a.overlap(tree_b)
                if len(hits) > worst_pairs:
                    worst_pairs, pairs_frame = len(hits), frame
                for face_index, _other in hits:
                    if face_index < len(face_owner):
                        name = face_owner[face_index]
                        by_face[name] = by_face.get(name, 0) + 1
            if rest_edges:
                now_edges = _evaluated_edges(outer)
                if len(now_edges) == len(rest_edges):
                    bad = 0
                    for was, is_now in zip(rest_edges, now_edges):
                        if was * 1000.0 < 0.5:
                            continue
                        ratio = is_now / was
                        if ratio < 0.5 or ratio > 2.0:
                            bad += 1
                        if abs(ratio - 1.0) > abs(worst_ratio - 1.0):
                            worst_ratio, ratio_frame = ratio, frame
                    broken_edges = max(broken_edges, bad)
    finally:
        scene.frame_set(saved)
        for modifier in hidden:
            modifier.show_viewport = True

    bone = dominant[worst_index] if 0 <= worst_index < len(dominant) else "?"
    rows = sorted(by_bone.items(), key=lambda kv: -kv[1][0])[:8]
    return {"outer": outer.name, "inner": inner.name,
            "frames": [start, end, int(step)], "rest_frame": base_frame,
            "worst_sink_mm": round(worst_sink * 1000.0, 2),
            "worst_frame": worst_frame, "worst_vertex": worst_index,
            "worst_bone": bone,
            "crossed": worst_crossed, "crossed_frame": crossed_frame,
            "vertices": len(rest),
            "by_bone": [{"bone": name, "crossed": row[0],
                         "sink_mm": round(row[1] * 1000.0, 2)}
                        for name, row in rows],
            "pairs_rest": rest_pairs, "pairs_worst": worst_pairs,
            "pairs_excess": max(0, worst_pairs - rest_pairs),
            "pairs_frame": pairs_frame,
            "by_face": [{"bone": name, "hits": count}
                        for name, count in
                        sorted(by_face.items(), key=lambda kv: -kv[1])[:8]],
            "full_stack": bool(full_stack),
            "edge_ratio": round(worst_ratio, 4) if rest_edges else None,
            "edge_ratio_frame": ratio_frame if rest_edges else None,
            "edges_broken": broken_edges if rest_edges else None,
            "edges": len(rest_edges) if rest_edges else None,
            "clean": worst_pairs <= rest_pairs and worst_crossed == 0}, ""


def smooth_band(mesh_object, indices, factor=0.5, repeat=6):
    """Average the deform weights over a band of vertices. ``(report, error)``.

    For the seam where a rigid part meets a deforming one: without it the faces
    that bridge the two stretch across a single edge. The selection is cleared
    from inside Edit Mode first, because a selection written in Object Mode does
    not survive an edit-mesh left over from a previous call -- a second band then
    smooths the union of both, which is silent and cumulative.

    Smoothing is NOT idempotent, so callers that might run twice should guard.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    scope = set(indices or ())
    if not scope:
        return None, "No vertex given"
    view = bpy.context.view_layer
    previous_active = view.objects.active
    previous_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
    mirror_x = getattr(mesh_object.data, "use_mirror_x", False)
    mirror_groups = getattr(mesh_object.data, "use_mirror_vertex_groups", False)
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh_object.data.use_mirror_x = False
        mesh_object.data.use_mirror_vertex_groups = False
        view.objects.active = mesh_object
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        for vertex in mesh_object.data.vertices:
            vertex.select = vertex.index in scope
        mesh_object.data.update()
        bpy.ops.object.mode_set(mode="EDIT")
        last = ""
        for mode in ("BONE_DEFORM", "ALL", None):
            kwargs = {"factor": float(factor), "repeat": int(max(1, repeat)),
                      "expand": 0.0}
            if mode:
                kwargs["group_select_mode"] = mode
            try:
                bpy.ops.object.vertex_group_smooth(**kwargs)
                last = ""
                break
            except (RuntimeError, TypeError) as exc:
                last = str(exc)
        if last:
            return None, "Weight smoothing was refused. Check the mode and selection."
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh_object.data.use_mirror_x = mirror_x
        mesh_object.data.use_mirror_vertex_groups = mirror_groups
        view.objects.active = previous_active
        if previous_active is not None and previous_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=previous_mode)
            except RuntimeError:
                pass
    return {"mesh": mesh_object.name, "vertices": len(scope),
            "factor": factor, "repeat": repeat}, ""

def smooth_groups(mesh_object, indices, group_names, factor=0.5, repeat=2):
    """Smooth NAMED vertex groups only, over the given vertices.

    ``(report, error)``. :func:`smooth_band` smooths every deform group at once,
    which is wrong whenever some of them have just been set deliberately. Measured
    on the reference character: smoothing all groups to take the faceting out of
    the brow also smoothed the eyelid's weights, and the eye stopped closing --
    102% of the way shut down to 12.5%. The lid weights ARE the closure.

    Blender's smoothing is per-active-group in ACTIVE mode, so this walks the list
    and makes each one active in turn. Only groups that actually carry weight on
    the selection are worth visiting, and the caller is expected to have filtered.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    scope = set(indices or ())
    if not scope:
        return None, "No vertex given"
    wanted = [n for n in (group_names or ()) if n in mesh_object.vertex_groups]
    if not wanted:
        return {"mesh": mesh_object.name, "groups": 0, "vertices": len(scope)}, ""

    view = bpy.context.view_layer
    previous_active = view.objects.active
    previous_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
    previous_group = mesh_object.vertex_groups.active_index
    mirror_x = getattr(mesh_object.data, "use_mirror_x", False)
    mirror_groups = getattr(mesh_object.data, "use_mirror_vertex_groups", False)
    done = 0
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh_object.data.use_mirror_x = False
        mesh_object.data.use_mirror_vertex_groups = False
        view.objects.active = mesh_object
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        for vertex in mesh_object.data.vertices:
            vertex.select = vertex.index in scope
        mesh_object.data.update()
        bpy.ops.object.mode_set(mode="EDIT")
        for name in wanted:
            mesh_object.vertex_groups.active_index =                 mesh_object.vertex_groups[name].index
            try:
                bpy.ops.object.vertex_group_smooth(
                    group_select_mode="ACTIVE", factor=float(factor),
                    repeat=int(max(1, repeat)), expand=0.0)
                done += 1
            except (RuntimeError, TypeError):
                continue
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh_object.data.use_mirror_x = mirror_x
        mesh_object.data.use_mirror_vertex_groups = mirror_groups
        mesh_object.vertex_groups.active_index = previous_group
        view.objects.active = previous_active
        if previous_active is not None and previous_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=previous_mode)
            except RuntimeError:
                pass
    return {"mesh": mesh_object.name, "groups": done, "vertices": len(scope),
            "factor": factor, "repeat": repeat}, ""



def smooth_region(mesh_object, indices, protect=(), factor=0.5, repeat=6,
                  rounds=1):
    """Relax the deform weights over a region while holding some vertices fixed.

    ``(report, error)``. ``protect`` names vertices that must keep their weights
    exactly: they are simply not selected, so Blender's smoothing reads them as
    boundary values and the region blends into them.

    This is the flow pass. Smoothing everything instead is what breaks a rig --
    the eyelid's own weights ARE the closure, and averaging them away took the eye
    from 102 per cent shut to 12.5. Protecting the lid margin and relaxing only
    the skin above it keeps the closure and still takes the faceting out of the
    surface between the eye and the brow.
    """
    scope = set(indices or ()) - set(protect or ())
    if not scope:
        return None, "Nothing left to smooth once the protected set is removed"
    done = 0
    for _round in range(int(max(1, rounds))):
        report, error = smooth_band(mesh_object, scope, factor=factor,
                                    repeat=repeat)
        if error:
            return None, error
        done += 1
    return {"mesh": mesh_object.name, "smoothed": len(scope),
            "protected": len(set(protect or ())), "rounds": done}, ""

def register() -> bool:
    return True


def unregister() -> dict:
    return {}
