# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import bpy
import sys
from bpy.props import StringProperty

from .external_tools import (
    clear_ui_status_cache,
    get_ui_status,
    missing_markers,
    refresh_ui_status,
)
from .i18n import report_ja, ui_tr as tr
from .preferences import get_preferences
from .legacy_cleanup import migration_status
from . import generation
from . import cloth_setup
from . import shoulder_lift
from . import compare
from .lifecycle import register_classes, unregister_classes, unregister_owned_classes


# Every explanation of the Smart Rig panel lives here and is shown by the "?" at the right end of
# each section header (SmartTools common rule 2026-10-17: help popups only, no INFO notes in the
# panel).  Each entry is key -> (title_en, title_ja, six English parts, six Japanese parts); the six
# parts follow _HELP_HEADINGS.  Lines inside a part are separated by "\n"; a line starting with
# "1. ", "- " or "・" is wrapped with a hanging indent.
_HELP_HEADINGS = (
    ("What it does", "何をする機能か"),
    ("Before you start", "使う前の準備"),
    ("Steps", "操作の手順"),
    ("Buttons and settings (recommended values in brackets)", "各ボタン・設定の意味（かっこ内は既定・おすすめの値）"),
    ("How to check the result", "結果の確かめ方"),
    ("Undo, cautions and limits", "元に戻す方法・注意・限界"),
)

# Popup width in unscaled pixels (Blender multiplies it by the UI scale, and the text grows with
# the same scale, so the wrap below holds at every scale).  Text is wrapped conservatively: a
# Latin character counts 1 unit and a CJK one 2 units of 7.5 px, wider than the 5.1 UI font draws
# them, so a wrapped line never reaches the dialog edge.
_HELP_WIDTH = 820
_HELP_UNIT_PX = 7.5
_HELP_MARGIN_PX = 60
_HELP_LIMIT = int((_HELP_WIDTH - _HELP_MARGIN_PX) / _HELP_UNIT_PX)

_SECTION_HELP = {}
_SECTION_HELP.update({
"overview": (
    "Smart Rig", "Smart Rig",
    (
        "Smart Rig is a companion for rigging a character with the separately installed Auto-Rig Pro (with its Rig Tools), AI_win and Proxy Picker. It calls those products safely, adds the finishing tools they do not have (joints, face, hair and costume chains, swing baking, checks), and keeps every step in one ordered panel.",
        "Install and enable Auto-Rig Pro 3.78.25 or newer. Proxy Picker 1.1.11+ and AI_win 1.20+ are optional. Their code and binaries are not bundled. The panel is in the 3D Viewport sidebar (N key), tab Smart Rig.",
        "1. Setup and Parts\n"
        "2. Body Rig (Auto-Rig Pro)\n"
        "3. Face and Eyes\n"
        "4. Hair, Costume & Hard Parts\n"
        "5. Jiggle, Collision & Cloth\n"
        "6. Animation\n"
        "Work from top to bottom. Open a section with the triangle on the left of its header.",
        "- Every header has a ? at its right end: it opens the detailed help of that section (what it does, preparation, steps, every button and setting with recommended values, how to check, how to undo and the limits).\n"
        "- Always-on Toggles: automatic saving of the panel settings.\n"
        "- Display, Selection & Rig UI, AI Runtime Integration, Data, Validation & Settings: tools used when needed.\n"
        "- Hovering a button shows its tooltip.",
        "Each section's help tells how to check its own result. For the whole rig: 6. Animation > Check Motion, and Data > Full Rig Workflow Audit.",
        "- Almost every button can be undone with Ctrl+Z right after it; save the file before large steps.\n"
        "- After any change of the rig structure, bind again and re-check the weights.\n"
        "- On a finished character do not run Match to Rig: it rebuilds the generated bones and removes the fixes made on them.",
    ),
    (
        "Smart Rigは、別に導入したAuto-Rig Pro（とそのリグツール）、AI_win、Proxy Pickerでキャラクターにリグを組むための連携アドオンです。それらを安全に呼び出し、足りない仕上げの道具（関節、顔、髪と衣装の鎖、揺れの焼き込み、検査）を加え、全ての手順を順番に並べた1つのパネルにまとめます。",
        "Auto-Rig Pro 3.78.25以降を導入して有効にします。Proxy Picker 1.1.11以降とAI_win 1.20以降は任意です。それらのコードやバイナリは同梱しません。パネルは3Dビューポートのサイドバー（Nキー）の「Smart Rig」タブにあります。",
        "1. 準備とパーツ\n"
        "2. 体のリグ（ARP）\n"
        "3. 顔と目\n"
        "4. 髪・衣装・固い部品\n"
        "5. 揺れ・当たり判定・クロス\n"
        "6. アニメーション\n"
        "上から順に進めます。見出しの左の三角でセクションを開きます。",
        "・全ての見出しの右端に？があります。押すとそのセクションの詳しい説明（何をするか、準備、手順、全てのボタンと設定の意味とおすすめの値、確かめ方、戻し方と限界）が開きます。\n"
        "・常時機能切り替え：パネルの設定の自動保存。\n"
        "・表示・選択・リグUI、AIランタイム連携、データ・検証・設定：必要な時に使う道具。\n"
        "・ボタンにマウスを乗せると、そのボタンの説明（ツールチップ）が出ます。",
        "各セクションのヘルプに、その結果の確かめ方があります。リグ全体は、6章の「動きを検査」と、データの「リグワークフロー総合監査」で確かめます。",
        "・ほとんどのボタンは、直後ならCtrl+Zで戻せます。大きな手順の前にはファイルを保存してください。\n"
        "・リグの構造を変えたら、バインドし直してウェイトを確認します。\n"
        "・仕上がったキャラクターにMatch to Rigを使わないでください。生成された骨を作り直し、そこへの手直しを消します。",
    ),
),
"always_on": (
    "Always-on Toggles", "常時機能切り替え",
    (
        "Decides which Smart Rig features keep working in the background, and whether the N-panel settings are saved automatically.",
        "Nothing to select. The Proxy Picker guard only matters when the separate Proxy Picker add-on is installed.",
        "1. Open the section with the triangle on the left of its header.\n"
        "2. Check that N-panel State Save is on (normal use).\n"
        "3. Turn on the Proxy Picker guard only if Proxy Picker prints restricted-context errors.",
        "- N-panel State Save: writes every Smart Rig panel and add-on setting at once to config/Smart_Rig_Suite/Smart_Rig_Suite.json of Blender 5.1 and restores them after a restart, when a file is opened and when the scene changes. Recommended: on.\n"
        "- Guard Proxy Picker restricted contexts: wraps only the separately installed Proxy Picker depsgraph callback so it does not raise missing-scene errors in restricted contexts. External files are never changed. Recommended: off; on only when those errors appear.",
        "Change a value, restart Blender and see that it is still there. For the guard, watch that the errors in the system console stop.",
        "- Untick either option to go back.\n"
        "- While saving is on, millimetre settings are also loaded into other files you open; a value the file has set itself keeps the file's value.\n"
        "- A line saying the guard is unavailable until preferences are registered means the add-on has not finished starting: restart Blender once.",
    ),
    (
        "Smart Rigの常時働く仕組みと、Nパネルの設定を自動で保存するかを決めます。",
        "選ぶ物はありません。Proxy Pickerの保護は、別に導入したProxy Pickerアドオンがある時だけ意味があります。",
        "1. 見出しの左の三角を押して開きます。\n"
        "2. 「Nパネル状態保存」がオンかを確かめます（普段はオン）。\n"
        "3. Proxy Pickerが制限コンテキストのエラーを出す時だけ、「Proxy Pickerの制限コンテキストを保護」をオンにします。",
        "・Nパネル状態保存：Smart Rigのパネルとアドオン設定の全ての値を、Blender 5.1のconfig/Smart_Rig_Suite/Smart_Rig_Suite.jsonへすぐ保存し、再起動・ファイルを開いた時・シーンを切り替えた時に戻します。おすすめ：オン。\n"
        "・Proxy Pickerの制限コンテキストを保護：別に導入したProxy Pickerのdepsgraph処理だけを包み、制限された場面で「シーンが無い」エラーが出ないようにします。外部のファイルは変えません。おすすめ：オフ（エラーが出る時だけオン）。",
        "値を変えてBlenderを再起動し、値が残っていれば保存は働いています。保護は、システムコンソールのエラーが止まるかで確かめます。",
        "・どちらもチェックを外せば元に戻ります。\n"
        "・保存がオンの間、mmの設定などは他のファイルを開いた時にも読み込まれます。ファイル自身が設定済みの値は、ファイルの値が残ります。\n"
        "・「プリファレンス登録完了まで…利用できません」と出る時は、アドオンの起動が終わっていません。Blenderを一度再起動してください。",
    ),
),
"setup": (
    "1. Setup and Parts", "1. 準備とパーツ",
    (
        "Step 1 of rigging a character. Checks that the external tools are ready, sets which rig and body mesh Smart Rig works on, and splits the character into parts (collections) so a costume can be shown, hidden or removed on its own.",
        "Install and enable Auto-Rig Pro (3.78.25 or newer). Proxy Picker and AI_win are optional. Smart Rig only detects and calls these products; their code is not bundled.",
        "Whole order for a new character:\n"
        "1. Setup: the targets, then the character marker for the parts.\n"
        "2. Body: reference rig, markers, Match to Rig, bind, auxiliary bones.\n"
        "3. Face: eye references, eyeballs, eyelid pivot, reach, correctives.\n"
        "4. Hair and costume: chains, costume binding, bands, hard parts.\n"
        "5. Jiggle: colliders first, then bake the jiggle; cloth for the skirt.\n"
        "6. Animation: IK/FK, motion capture, Check Motion.\n"
        "After any change to the rig structure, bind again and re-check the weights.",
        "- Status rows: Auto-Rig Pro, Rig Tools, Proxy Picker and AI_win show Available or Unavailable with the version.\n"
        "- Workflow Targets and Parts and costumes: each has its own ? help.\n"
        "- Refresh External Status: scans the external tools again after you install or enable one.",
        "All four status rows show a check mark (AI_win and Proxy Picker may stay Unavailable if you do not use them). Run Preflight in Workflow Targets for a full check.",
        "- Nothing here changes the scene except the target and part buttons.\n"
        "- An 'External integration conflict' box means two copies of a tool are loaded: follow the line under it (for example disable the standalone Rig Tools) and restart Blender.",
    ),
    (
        "キャラクターにリグを組む手順1です。外部ツールの準備ができているかを確かめ、Smart Rigが扱うリグと素体メッシュを決め、キャラクターをパーツ（コレクション）に分けて衣装ごとに表示・非表示・削除できるようにします。",
        "Auto-Rig Pro（3.78.25以降）を導入して有効にします。Proxy PickerとAI_winは任意です。Smart Rigはこれらを検出して呼び出すだけで、コードは同梱しません。",
        "新しいキャラクターの全体の順番：\n"
        "1. 準備：対象を設定し、パーツの識別名を決める。\n"
        "2. 体：参照リグ、マーカー、Match to Rig、バインド、補助ボーン。\n"
        "3. 顔：目の参照、眼球、瞼のピボット、効き範囲、補正キー。\n"
        "4. 髪と衣装：鎖、衣装の結合、帯、固い部品。\n"
        "5. 揺れ：当たり判定を先に作り、その後に揺れを焼く。スカートはクロス。\n"
        "6. アニメーション：IK/FK、モーキャップ、動きを検査。\n"
        "リグの構造を変えたら、バインドし直してウェイトを確認します。",
        "・状態の行：Auto-Rig Pro、リグツール、Proxy Picker、AI_winが「利用可能／利用不可」と版を表示します。\n"
        "・ワークフロー対象、パーツ・衣装：それぞれの見出しの？に詳しい説明があります。\n"
        "・外部ツール状態を再検出：外部ツールを導入・有効化した後に、もう一度調べ直します。",
        "4つの状態の行にチェックが付けば準備完了です（使わないならAI_winとProxy Pickerは利用不可のままで構いません）。総合的な確認は、ワークフロー対象の「事前検証を実行」で行います。",
        "・対象とパーツのボタン以外は、シーンを変えません。\n"
        "・「外部連携の競合を検出しました」の枠は、同じツールが二重に読み込まれている印です。その下の行の指示（例：単体Rig Toolsを無効化）に従い、Blenderを再起動してください。",
    ),
),
"setup_targets": (
    "Workflow Targets", "ワークフロー対象",
    (
        "Tells Smart Rig which armature is the rig and which mesh is the body, so every later button works on the right objects instead of guessing.",
        "The character's armature and body mesh exist in the scene. Object Mode is easiest.",
        "1. Select the rig armature and the body mesh in the viewport.\n"
        "2. Press Use Current Selection (or pick them in the two fields).\n"
        "3. Press Run Preflight and read the report.",
        "- Target Rig Armature: the rig used for context preparation, external tool calls, Proxy Picker audits and validation. Empty = automatic detection.\n"
        "- Target Body Mesh: the mesh activated before body-marker estimation and preferred by the audits. Empty = the active or selected mesh.\n"
        "- Use Current Selection: stores the selected armature and mesh in the two fields.\n"
        "- Run Preflight: checks external tool registration, the AI runtime version, the targets, required markers, duplicate registrations and obsolete embedded modules.",
        "Both fields show your objects, and the preflight reports no problem in the status bar / report.",
        "- Clear a field with its X to return to automatic detection.\n"
        "- Only the object names are stored in the Smart Rig JSON; renaming an object later empties the field.",
    ),
    (
        "どのアーマチュアがリグで、どのメッシュが素体かをSmart Rigに教えます。以後のボタンは推測ではなく、ここで決めた物に働きます。",
        "キャラクターのアーマチュアと素体メッシュがシーンにある事。オブジェクトモードが扱いやすいです。",
        "1. ビューポートでリグのアーマチュアと素体メッシュを選びます。\n"
        "2. 「現在の選択を使用」を押します（2つの欄で直接選んでも構いません）。\n"
        "3. 「事前検証を実行」を押し、報告を読みます。",
        "・対象リグアーマチュア：文脈の準備、外部ツールの呼び出し、Proxy Pickerの監査、リグ検証に使うリグ。空なら自動で探します。\n"
        "・対象ボディメッシュ：ボディマーカー推定の前に有効にするメッシュ。監査でも優先します。空ならアクティブか選択中のメッシュ。\n"
        "・現在の選択を使用：選んだアーマチュアとメッシュを2つの欄に入れます。\n"
        "・事前検証を実行：外部ツールの登録、AIランタイムの版、対象、必須マーカー、二重登録、古い内蔵モジュールを調べます。",
        "2つの欄に自分のオブジェクトが入り、事前検証の報告に問題が出なければ完了です。",
        "・欄の×で空にすると自動検出に戻ります。\n"
        "・Smart RigのJSONに残るのは名前だけです。後でオブジェクトの名前を変えると欄は空になります。",
    ),
),
"setup_parts": (
    "Parts and costumes", "パーツ・衣装",
    (
        "Rigs the character one collection at a time, so each costume (a part) can be shown, hidden or removed on its own together with its bones, and a shape key can follow a part.",
        "Put each costume piece in its own collection, and give every collection that belongs to the character a common text in its name (the character marker, for example MIK). Collections without the marker (cameras, lights, reference models) are left alone.",
        "1. Type the marker in Marker.\n"
        "2. Press Audit Parts to see which collections are parts and which bones belong to no part.\n"
        "3. Pick a collection in Part and press Show or Hide to switch it with its bones.\n"
        "4. To make an under-layer slim down only while this part is worn: choose the Mesh, its Key, then Link to Part.\n"
        "5. To take a costume out completely: choose it in Part and press Remove Part.",
        "- Marker (default MIK): text every one of the character's collections carries.\n"
        "- Part: the collection handled as one unit.\n"
        "- Show / Hide: switches the part's meshes and bones together (hiding only meshes would leave its controls floating).\n"
        "- Mesh / Key / Link to Part: the key is 1 while the part is shown and 0 while hidden. The unlink button removes the link. Linked keys are listed above as mesh : key (shown / hidden).\n"
        "- With Meshes (default on) + Remove Part: removes the part's meshes, its generated bones and the vertex groups they left on the other meshes. Turn With Meshes off to strip only the rig.\n"
        "- Audit Parts: lists parts, the collections left out and why, and bones that belong to no part.",
        "Hide a part: its meshes and its controls disappear together, and a linked key goes to 0. Audit Parts lists no orphan bones.",
        "- Show / Hide is undone by pressing the other button.\n"
        "- Remove Part deletes data: save first. Undo (Ctrl+Z) works right after it.\n"
        "- A bone that belongs to no part cannot be hidden or removed with a part.",
    ),
    (
        "キャラクターをコレクション単位でリグにします。衣装（パーツ）ごとに、ボーンと一緒に表示・非表示・削除ができ、シェイプキーをパーツの表示に連動させられます。",
        "衣装の部品ごとにコレクションを分け、キャラクターのコレクションの名前に共通の文字（識別名。例：MIK）を入れておきます。識別名の無いコレクション（カメラ、照明、参考モデル）は触りません。",
        "1. 「識別名」に共通の文字を入れます。\n"
        "2. 「パーツを監査」で、どのコレクションがパーツか、どのパーツにも属さないボーンがあるかを見ます。\n"
        "3. 「パーツ」でコレクションを選び、「表示」「非表示」でボーンと一緒に切り替えます。\n"
        "4. このパーツを着ている間だけ下の層を細くしたい時：「連動」にメッシュ、「キー」にシェイプキーを選び、「パーツに連動」。\n"
        "5. 衣装を丸ごと外す時：「パーツ」で選んで「パーツを削除」。",
        "・識別名（既定MIK）：キャラクターのコレクションが全て持つ文字。\n"
        "・パーツ：1つのまとまりとして扱うコレクション。\n"
        "・表示／非表示：パーツのメッシュとボーンを一緒に切り替えます（メッシュだけ隠すと操作用の骨が宙に残るため）。\n"
        "・連動／キー／パーツに連動：表示中は1、非表示中は0になります。鎖が切れたボタンで連動を外します。連動中のキーは上に「メッシュ : キー（表示値 / 非表示値）」と並びます。\n"
        "・メッシュも（既定オン）＋パーツを削除：パーツのメッシュ、そのために作ったボーン、残るメッシュに付いた頂点グループを消します。オフならリグだけを外し、形は残します。\n"
        "・パーツを監査：パーツの一覧、外したコレクションとその理由、どのパーツにも属さないボーンを報告します。",
        "パーツを非表示にすると、メッシュと操作用の骨が一緒に消え、連動したキーが0になります。「パーツを監査」で孤立したボーンが出なければ完了です。",
        "・表示／非表示は、もう一方のボタンで戻ります。\n"
        "・パーツを削除はデータを消します。先に保存してください。直後ならCtrl+Zで戻せます。\n"
        "・どのパーツにも属さないボーンは、パーツと一緒に隠したり消したりできません。",
    ),
),
"body": (
    "2. Body Rig (Auto-Rig Pro)", "2. 体のリグ（ARP）",
    (
        "Step 2. Builds and finishes the body rig with Auto-Rig Pro: reference rig, markers, Match to Rig, bind, then the joint treatments (elbows, knees, wrists), weight editing and rig hygiene.",
        "Auto-Rig Pro must be enabled (otherwise this section shows a red line and its buttons are greyed out). Set the targets in 1. Setup first.",
        "1. Reference Rig & Markers: add the reference rig, place or estimate the markers, Match Reference to Rig.\n"
        "2. Binding: select the meshes and Bind.\n"
        "3. Auxiliary bones: Set Up All for elbows and knees, then Knee Split, Knee Angle Profile and Wrist fold as needed.\n"
        "4. Check with Rig hygiene and the Weight tool.\n"
        "Shoe Sole Lift and Character Size can be used at any time after binding.",
        "Each subsection has its own ? help with every button explained:\n"
        "- Reference Rig & Markers, Binding, Shoe Sole Lift, Character Size\n"
        "- Auxiliary bones, Knee Split, Knee Angle Profile, Wrist fold\n"
        "- Weight tool, Rig hygiene",
        "Pose the arms and legs: the skin follows without tearing. Use the audit buttons of each subsection for numbers.",
        "- After any change to the rig structure (Match to Rig, adding limbs), bind again and re-check the weights.\n"
        "- Match to Rig regenerates bones from the references: hand fixes made on the generated bones (eyelid pivot, for example) come back broken and must be applied again.",
    ),
    (
        "手順2です。Auto-Rig Proで体のリグを組んで仕上げます。参照リグ、マーカー、Match to Rig、バインドの後、関節の処理（肘・膝・手首）、ウェイトの編集、リグの衛生を行います。",
        "Auto-Rig Proが有効である事（無効ならこのセクションに赤い行が出て、ボタンが灰色になります）。先に「1. 準備とパーツ」で対象を決めておきます。",
        "1. 参照リグとマーカー：参照リグを追加し、マーカーを置くか推定して、「参照ボーンをリグへ適合」。\n"
        "2. バインド：メッシュを選んで「バインド」。\n"
        "3. 補助ボーン：肘と膝を「一括設定」し、必要に応じて膝の分離・膝の角度プロファイル・手首の潰れを設定。\n"
        "4. リグの衛生とウェイトツールで確かめます。\n"
        "靴底の持ち上げとキャラクターのサイズ変更は、バインド後いつでも使えます。",
        "各サブセクションの見出しの？に、全てのボタンの説明があります：\n"
        "・参照リグとマーカー、バインド、靴底の持ち上げ、キャラクターのサイズ変更\n"
        "・補助ボーンの一括設定、膝の分離、膝の角度プロファイル、手首の潰れ\n"
        "・ウェイトツール、リグの衛生",
        "腕と脚を動かして、肌が裂けずについて来れば良好です。数値は各サブセクションの監査ボタンで見ます。",
        "・リグの構造を変えたら（Match to Rig、リムの追加など）、バインドし直してウェイトを確認します。\n"
        "・Match to Rigは参照ボーンから骨を作り直します。生成された骨への手直し（例：瞼のピボット）は元に戻るので、当て直しが必要です。",
    ),
),
"body_reference": (
    "Reference Rig & Markers", "参照リグとマーカー",
    (
        "Starts the Auto-Rig Pro rig safely: adds the reference rig and limbs, estimates the body markers, runs detection and Match to Rig, each only after its preconditions are checked so Auto-Rig Pro does not fail with a traceback.",
        "Auto-Rig Pro enabled. The body mesh set as Target Body Mesh. For marker estimation the AI_win runtime must be valid (see AI Runtime Integration).",
        "1. Choose the preset (Human for a person) and press Add Reference Rig.\n"
        "2. Optional: choose a limb and press Add Reference Limb (Prepare Edit Context first if needed).\n"
        "3. Press Estimate Body Markers (AI) or place the markers with Auto-Rig Pro.\n"
        "4. When the status shows Required markers ready, press Run Detection.\n"
        "5. Adjust the reference bones, then press Match Reference to Rig.",
        "- Preset + Add Reference Rig: Human, Free Form, Dog, Horse, Bird or Custom Skeleton.\n"
        "- Prepare Object Context / Prepare Edit Context: selects and activates the most likely rig and enters the mode, keeping the previous selection.\n"
        "- Limb + Add Reference Limb: arm, leg, spine, head, ears, breast and more, added in Armature Edit Mode.\n"
        "- Status row: Required markers ready, or the list of missing markers.\n"
        "- Estimate Body Markers: checks the AI runtime and the markers, then starts Auto-Rig Pro's own estimation.\n"
        "- Run Detection: checks all required markers first, then runs Auto-Rig Pro detection.\n"
        "- Match Reference to Rig: runs Auto-Rig Pro's Match to Rig once a compatible reference armature is found.",
        "After Match to Rig the real rig appears and its bones sit inside the body where the references were.",
        "- Each step can be undone with Ctrl+Z right after it.\n"
        "- Match to Rig rebuilds the generated bones and removes hand fixes on them. On a finished character do not run it; see that character's own notes.",
    ),
    (
        "Auto-Rig Proのリグ作りを安全に始めます。参照リグとリムの追加、ボディマーカーの推定、検出、Match to Rigを、それぞれ前提を確かめてから呼ぶので、Auto-Rig Proがエラーで止まりません。",
        "Auto-Rig Proが有効。素体メッシュを「対象ボディメッシュ」に設定。マーカーの推定にはAI_winランタイムが有効である事（「AIランタイム連携」を参照）。",
        "1. プリセット（人なら「人型」）を選び、「参照リグを追加」。\n"
        "2. 必要なら、リムを選んで「参照リムを追加」（先に「編集操作を準備」）。\n"
        "3. 「ボディマーカーを推定」（AI）か、Auto-Rig Proで手でマーカーを置きます。\n"
        "4. 状態に「必須マーカー準備済み」と出たら「検出を実行」。\n"
        "5. 参照ボーンを整えてから「参照ボーンをリグへ適合」。",
        "・プリセット＋参照リグを追加：人型、自由形式、犬、馬、鳥、カスタムスケルトン。\n"
        "・オブジェクト操作を準備／編集操作を準備：一番それらしいリグを選んで有効にし、そのモードに入ります。前の選択は覚えておきます。\n"
        "・リム＋参照リムを追加：腕、脚、背骨、頭、耳、胸など。アーマチュアの編集モードで追加します。\n"
        "・状態の行：「必須マーカー準備済み」か、足りないマーカーの一覧。\n"
        "・ボディマーカーを推定：AIランタイムとマーカーを確かめてから、Auto-Rig Pro自身の推定を始めます。\n"
        "・検出を実行：必須マーカーを全て確かめてから、Auto-Rig Proの検出を実行します。\n"
        "・参照ボーンをリグへ適合：合う参照アーマチュアが見つかった時だけ、Auto-Rig ProのMatch to Rigを実行します。",
        "Match to Rigの後に本番のリグが現れ、参照ボーンの位置で体の中に骨が並べば完了です。",
        "・どの手順も、直後ならCtrl+Zで戻せます。\n"
        "・Match to Rigは生成された骨を作り直し、そこへの手直しを消します。仕上がったキャラクターには使わないでください。そのキャラクターの手引きに従います。",
    ),
),
"body_bind": (
    "Binding", "バインド",
    (
        "Binds the meshes to the rig with Auto-Rig Pro's own bind, unbind or scale-fix rebind. Smart Rig only prepares the selection and the rig; it does not have a second bind system.",
        "Auto-Rig Pro enabled. Match to Rig done. Select the meshes to bind (Object Mode) and set the rig as the target.",
        "1. Select the meshes.\n"
        "2. Press Bind.\n"
        "3. Pose the rig to check, then fix weights with the Weight tool if needed.",
        "- Bind: Auto-Rig Pro Bind to Rig on the selected meshes.\n"
        "- Unbind: removes the binding from the selected meshes.\n"
        "- Scale-fix Rebind: Auto-Rig Pro's rebind for meshes whose scale was changed.",
        "Rotate an arm or a leg in Pose Mode: the mesh follows.",
        "- Unbind is the way back from Bind.\n"
        "- After a rig change, bind again and re-check the weights (hand-painted weights are replaced).\n"
        "- Costumes are better bound with Costume parts in section 4, which copies the skin's weights.",
    ),
    (
        "Auto-Rig Pro自身のバインド・解除・スケール修正リバインドで、メッシュをリグに結び付けます。Smart Rigは選択とリグを準備するだけで、別のバインドの仕組みは持ちません。",
        "Auto-Rig Proが有効。Match to Rigが済んでいる事。バインドするメッシュを選び（オブジェクトモード）、リグを対象に設定しておきます。",
        "1. メッシュを選びます。\n"
        "2. 「バインド」を押します。\n"
        "3. リグを動かして確かめ、必要ならウェイトツールで直します。",
        "・バインド：選んだメッシュにAuto-Rig ProのBind to Rigを行います。\n"
        "・解除：選んだメッシュのバインドを外します。\n"
        "・スケール修正リバインド：スケールを変えたメッシュ用の、Auto-Rig Proのリバインドです。",
        "ポーズモードで腕や脚を回し、メッシュがついて来れば完了です。",
        "・バインドの取り消しは「解除」です。\n"
        "・リグを変えたら、バインドし直してウェイトを確認します（手で塗ったウェイトは置き換わります）。\n"
        "・衣装は、肌のウェイトを受け継ぐ4章の「衣装パーツ」で結合する方が揃います。",
    ),
),
"body_shoe_lift": (
    "Shoe Sole Lift", "靴底の持ち上げ",
    (
        "The character is modelled barefoot at Z = 0, so shoe soles sit under the floor. This raises the whole character by the sole's height with a driver on the rig's parent, without adding bones or moving any rest pose.",
        "An Auto-Rig Pro rig selected (or set as the target). Select the shoe meshes before Measure. Do the binding, parenting, costume transfer and collider fitting with the lift cleared.",
        "1. Select the shoe meshes and press Measure.\n"
        "2. Press Lift.\n"
        "3. Before rig work, press Clear; lift again afterwards.",
        "- Status row: Lifted (height), Cleared (measured value) or Not set up.\n"
        "- Measure: how far the selected shoes reach under the floor, at rest and with no lift; stored on the rig's parent. Nothing moves.\n"
        "- Lift: raises everything by the measured sole through a driver on the rig's parent.\n"
        "- Margin mm (0), Height mm (-1), Lift Projectors (on): extra height added at Measure; the height Lift uses (below 0 uses the measured sole); whether UV Project projectors outside the rig's parent rise too.\n"
        "- Clear: puts the character back on bare feet (lift 0), keeping the drivers and the measured value.\n"
        "- Remove: takes the drivers and properties away and puts every object back.\n"
        "- The list below names objects outside the rig: lifted too, not needed, or not judged.",
        "With Lift, the soles touch Z = 0. With Clear, the bare feet are at Z = 0 again.",
        "- Clear or Remove return to the original state.\n"
        "- Red lines are problems found before lifting; fix them first.\n"
        "- Binding or fitting colliders while lifted bakes the lift into the setup.",
    ),
    (
        "キャラクターは素足でZ＝0に作るので、靴底は床の下にあります。これはリグの親にドライバーを付けて、キャラクター全体を靴底の高さだけ持ち上げます。ボーンを足さず、レストポーズも動かしません。",
        "Auto-Rig Proのリグを選ぶか対象に設定。「測る」の前に靴のメッシュを選びます。バインド・親付け・衣装の移し替え・当たり判定の作成は、解除した状態で行います。",
        "1. 靴のメッシュを選び、「測る」。\n"
        "2. 「上げる」。\n"
        "3. リグの作業をする前は「解除」し、作業の後でもう一度上げます。",
        "・状態の行：持ち上げ中（高さ）、解除中（測定値）、未設定。\n"
        "・測る：選んだ靴が床の下へどこまで出ているかを、レストで持ち上げなしで測り、リグの親に覚えます。何も動きません。\n"
        "・上げる：測った靴底の分だけ、リグの親のドライバーで全体を上げます。\n"
        "・余白 mm（0）、高さ mm（-1）、投影元も上げる（オン）：「測る」で足す高さ、「上げる」で使う高さ（0より小さいと測った靴底）、リグの親の外のUV投影の投影元も上げるか。\n"
        "・解除：素足の位置（持ち上げ0）へ戻します。ドライバーと測定値は残ります。\n"
        "・取り外す：ドライバーとプロパティを外し、全てのオブジェクトを元の位置へ戻します。\n"
        "・下の一覧は、リグの外のオブジェクトの扱いです：一緒に上げる、不要、未判定。",
        "「上げる」で靴底がZ＝0に接し、「解除」で素足がZ＝0に戻れば正しく動いています。",
        "・「解除」か「取り外す」で元に戻ります。\n"
        "・赤い行は持ち上げ前に見つかった問題です。先に直してください。\n"
        "・持ち上げたままバインドや当たり判定を作ると、持ち上げ分が設定に焼き込まれます。",
    ),
),
"body_rescale": (
    "Character Size", "キャラクターのサイズ変更",
    (
        "Resizes a finished, rigged character about the world origin without redoing any rig work: every modifier, weight, driver, constraint and Smart Rig setup is kept.",
        "Choose the Auto-Rig Pro rig (the status row shows Rig: name; only a rig with the c_pos and c_traj bones can be resized, and for anything else the row says why and the buttons are off). Save the file first. For Target Height, select the character's meshes to measure.",
        "1. Choose Factor, or Target Height.\n"
        "2. Factor: type the factor. Target Height: choose Height Is, select the meshes, press Measure, then type the Target Height.\n"
        "3. Choose the options below.\n"
        "4. Press Check and read the report: it names what would change and what stops the resize.\n"
        "5. Press Resize.",
        "- Factor: multiplies every length (1.0 = no change).\n"
        "- Height Is: Lowest to Highest or Top Above Floor (highest point above Z = 0). Measure fills Current Height; the factor is shown.\n"
        "- Whole Scene (off): every object in the scene, not only the character.\n"
        "- Lights and Cameras (off): moves and resizes them too; brightness is not changed.\n"
        "- Material Lengths (on): bump distance, subsurface scale, object-mapped textures.\n"
        "- Panel Lengths (on): this panel's millimetre settings and the floor height.\n"
        "- Rebind Bound Modifiers (off): unbinds and binds again Corrective Smooth, Surface Deform, Mesh Deform and Laplacian Deform.",
        "Measure again after the resize: Current Height equals the target. Pose the rig: everything moves as before.",
        "- Undo with Ctrl+Z right after, or resize again by 1/factor.\n"
        "- Modifiers are not applied. Meshes and armatures end at scale 1 except those named in the notes.\n"
        "- Bound deform modifiers stop the resize unless Rebind Bound Modifiers is on.\n"
        "- A red line saying the value was measured on another rig or with the other Height Is: measure again.",
    ),
    (
        "仕上がったリグ付きキャラクターの大きさを、リグを作り直さずに世界の原点を中心に変えます。モディファイア、ウェイト、ドライバー、拘束、Smart Rigの設定は全て残ります。",
        "Auto-Rig Proのリグを選びます（状態の行に「リグ：名前」と出ます。c_pos・c_trajの骨を持つリグだけが対象で、それ以外の時は行に理由が出てボタンが押せません）。先にファイルを保存します。目標の高さで使う時は、キャラクターのメッシュを選んで測ります。",
        "1. 「倍率」か「目標の高さ」を選びます。\n"
        "2. 倍率：倍率を入れます。目標の高さ：「高さの測り方」を選び、メッシュを選んで「測る」、「目標の高さ」を入れます。\n"
        "3. 下のオプションを選びます。\n"
        "4. 「確認」を押して報告を読みます。変わる物と、実行を止める物が出ます。\n"
        "5. 「サイズを変更」。",
        "・倍率：全ての長さに掛けます（1.0で変化なし）。\n"
        "・高さの測り方：上端から下端まで、または床からの頭頂（Z＝0からの最高点）。「測る」で今の高さが入り、倍率が表示されます。\n"
        "・シーン全体（オフ）：キャラクター以外も含め、シーンの全てのオブジェクト。\n"
        "・照明とカメラも（オフ）：一緒に動かして大きさを変えます。明るさは変えません。\n"
        "・マテリアルの長さ（オン）：バンプの距離、サブサーフェスのスケール、オブジェクト座標のテクスチャ。\n"
        "・パネルの長さ設定（オン）：このパネルのmmの設定と床の高さ。\n"
        "・バインドを掛け直す（オフ）：補正スムーズ・サーフェス変形・メッシュ変形・ラプラシアン変形を外して掛け直します。",
        "変更後にもう一度測り、今の高さが目標と一致すれば完了です。ポーズを付け、以前と同じに動く事を確かめます。",
        "・直後ならCtrl+Z、または1/倍率でもう一度変更すると戻ります。\n"
        "・原点を中心に変えます。モディファイアは適用せず、注意に出た物を除き、メッシュとアーマチュアのスケールは1になります。\n"
        "・バインド済みの補正スムーズ・サーフェス変形・メッシュ変形・ラプラシアン変形は、「バインドを掛け直す」がオンでなければ実行を止めます。\n"
        "・「別のリグで測った値」「別の測り方で測った値」と赤く出たら、測り直してください。",
    ),
),
"body_aux": (
    "Auxiliary Bones (All)", "補助ボーンの一括設定",
    (
        "Finds every auxiliary bone Auto-Rig Pro added past its defaults (the bend controllers and fans of the elbows and knees), groups them by joint, and applies the fan profile, the split and the weight smoothing to each in one pass.",
        "A bound Auto-Rig Pro rig with its auxiliary (secondary) bones enabled. Set the targets.",
        "1. Choose Knees and/or Elbows.\n"
        "2. Leave Scale To Joint and Smooth Weights on.\n"
        "3. Press Set Up All.\n"
        "4. Press Audit Auxiliary Bones, then Mirror Fan Setup if the two sides differ.",
        "- Knees / Elbows (both on): which joints are included.\n"
        "- Scale To Joint (on): rescales the approved knee amounts to each joint's own segment length so the angles match. Off = the same millimetres everywhere.\n"
        "- Smooth Weights (on): also averages the deform weights around each joint. This edits the mesh.\n"
        "- Set Up All / Remove: installs, or removes the drivers and restores Auto-Rig Pro's own Bulge values.\n"
        "- Audit Auxiliary Bones: lists the bones by joint, whether each is set up, and fan pairs that are not mirror images.\n"
        "- Mirror Fan Setup: makes the right side's fans the mirror of the left's.",
        "Bend an elbow and a knee to about 90 and 140 degrees: the inside does not collapse and both sides look the same. The audit shows every joint as set up.",
        "- Remove takes the drivers off; the weight smoothing is a mesh edit and is not undone by Remove (use Ctrl+Z, or keep a saved copy).\n"
        "- After a rig change, run Set Up All again.",
    ),
    (
        "Auto-Rig Proが標準の後に足した補助ボーン（肘と膝の曲げ用コントローラーと扇）を全て見つけ、関節ごとにまとめて、扇のプロファイル・分離・ウェイトの均しを一度に設定します。",
        "補助（セカンダリー）ボーンを有効にしたAuto-Rig Proのリグがバインド済みである事。対象を設定しておきます。",
        "1. 「膝」「肘」を選びます。\n"
        "2. 「関節に合わせる」と「ウェイトも均す」はオンのままにします。\n"
        "3. 「一括設定」。\n"
        "4. 「補助ボーンを監査」を押し、左右が違えば「扇の設定を左右で揃える」。",
        "・膝／肘（両方オン）：含める関節。\n"
        "・関節に合わせる（オン）：膝で決めた量を各関節の長さに合わせて縮め、角度を揃えます。オフなら全関節に同じmmを使います。\n"
        "・ウェイトも均す（オン）：関節の周りのウェイトも平均化します。メッシュを書き換えます。\n"
        "・一括設定／解除：設定するか、ドライバーを外してAuto-Rig ProのBulgeの値に戻します。\n"
        "・補助ボーンを監査：関節ごとの骨、設定済みか、左右が鏡像でない扇の組を報告します。\n"
        "・扇の設定を左右で揃える：右の扇を左の鏡像にします。",
        "肘を約90度、膝を約140度に曲げ、内側が潰れず左右が同じに見えれば良好です。監査で全ての関節が設定済みと出ます。",
        "・「解除」はドライバーを外します。ウェイトの均しはメッシュの編集なので「解除」では戻りません（Ctrl+Zか、保存した控えを使います）。\n"
        "・リグを変えたら、もう一度「一括設定」します。",
    ),
),
"body_knee_split": (
    "Knee Split", "膝の分離",
    (
        "Past the onset angle the thigh side and the calf side of the knee slide apart instead of folding as one hinge, so a deep bend does not crush into itself. Poses below the onset angle are left exactly as Auto-Rig Pro made them.",
        "An Auto-Rig Pro rig with the knee's secondary controllers. Usually installed by Set Up All; use this for fine tuning.",
        "1. Set Onset and End.\n"
        "2. Set the four slide / apart amounts.\n"
        "3. Press Install Knee Split, then Audit Knee Split.\n"
        "4. Bend the knee fully to judge; change the values and install again.",
        "- Onset (90 deg): angle where the sides start to slide apart.\n"
        "- End (170 deg): angle where the full amount is reached.\n"
        "- Thigh Slide (20 mm): the thigh's knee end slides toward the hip.\n"
        "- Thigh Apart (0 mm): moves the knee cap forward; leave 0 unless wanted.\n"
        "- Calf Slide (0 mm): the calf's knee start slides toward the ankle.\n"
        "- Calf Apart (89 mm): moves the calf away from the thigh; this is what stops the crush.\n"
        "- Ramp Curve (empty): optional angle:factor pairs (factor 0 to 1), e.g. 90:0, 120:0.25, 150:0.7, 170:1. Empty = straight ramp.\n"
        "- Install / Remove / Audit Knee Split: Remove returns the controllers to zero.",
        "Bend the knee past 150 degrees: the back of the knee opens instead of folding flat. The audit lists the driven controllers and anything blocking them.",
        "- Remove takes the drivers off and returns the controllers to zero.\n"
        "- Too large amounts tear the skin at the back of the knee; check at full bend.",
    ),
    (
        "始動角を超えると、膝の太もも側とふくらはぎ側が一つの蝶番ではなく分離して動き、深く曲げても潰れません。始動角より浅い姿勢は、Auto-Rig Proが作ったままで変えません。",
        "膝のセカンダリーコントローラーがあるAuto-Rig Proのリグ。普通は「補助ボーンの一括設定」で入ります。ここは細かい調整用です。",
        "1. 「始動角」と「終端角」を決めます。\n"
        "2. スライドと離す量の4つを決めます。\n"
        "3. 「膝の分離を設定」、続けて「膝の分離を監査」。\n"
        "4. 膝を深く曲げて判断し、値を変えてもう一度設定します。",
        "・始動角（90度）：分離が始まる角度。\n"
        "・終端角（170度）：分離が最大になる角度。\n"
        "・太もも スライド（20mm）：太ももの膝側の端を股の方へ滑らせます。\n"
        "・太もも 離す（0mm）：膝の皿を前へ出します。意図しない限り0。\n"
        "・ふくらはぎ スライド（0mm）：ふくらはぎの膝側の端を足首の方へ滑らせます。\n"
        "・ふくらはぎ 離す（89mm）：ふくらはぎを太ももから離します。潰れを止める主な値です。\n"
        "・ランプ曲線（空）：任意。角度:割合（0〜1）の組。例：90:0, 120:0.25, 150:0.7, 170:1。空なら始動角から終端角まで直線。\n"
        "・膝の分離を設定／解除／監査：解除でコントローラーは0に戻ります。",
        "膝を150度より深く曲げ、膝の裏が平たく潰れずに開けば良好です。監査に、動かしているコントローラーと邪魔している物が出ます。",
        "・「解除」でドライバーを外し、コントローラーを0に戻します。\n"
        "・量が大き過ぎると膝の裏の肌が裂けます。深く曲げて確かめてください。",
    ),
),
"body_knee_smooth": (
    "Knee weight smoothing", "膝まわりのウェイトを均す",
    (
        "Averages the deform weights in a ball around each knee. The crease behind a moderately bent knee comes from the thigh-to-shin weight change happening over too few edge loops; widening it removes the crease and lets a deep bend separate without tearing.",
        "A bound rig with knees. Save first: this edits the mesh weights.",
        "1. Set Radius, Factor and Repeat.\n"
        "2. Press Smooth Knee Weights.\n"
        "3. Bend the knee to judge.",
        "- Radius (115 mm): the ball around each knee in which weights are averaged.\n"
        "- Factor (0.6): how strongly each pass pulls a vertex toward its neighbours.\n"
        "- Repeat (8): how many passes.\n"
        "- Smooth Knee Weights: runs it on the knees.",
        "Bend the knee to about 90 degrees: no sharp fold line behind it.",
        "- Not undone by Remove buttons: use Ctrl+Z right after or a saved copy.\n"
        "- A very large radius blurs the thigh and calf shapes.",
    ),
    (
        "膝の周りの球の中で、変形のウェイトを平均化します。少し曲げた膝の裏のしわは、太ももからすねへのウェイトの変わり目が少ないエッジループに詰まっている事が原因です。広げるとしわが消え、深く曲げても裂けずに分離できます。",
        "膝のあるバインド済みのリグ。メッシュのウェイトを書き換えるので、先に保存します。",
        "1. 「半径」「強さ」「回数」を決めます。\n"
        "2. 「膝のウェイトを均す」。\n"
        "3. 膝を曲げて判断します。",
        "・半径（115mm）：ウェイトを平均化する、膝の周りの球の大きさ。\n"
        "・強さ（0.6）：1回ごとに頂点を周りへ寄せる強さ。\n"
        "・回数（8）：繰り返す回数。\n"
        "・膝のウェイトを均す：膝に実行します。",
        "膝を約90度に曲げ、裏に鋭い折れ線が出なければ良好です。",
        "・「解除」のボタンでは戻りません。直後のCtrl+Zか、保存した控えを使います。\n"
        "・半径が大き過ぎると、太ももとふくらはぎの形がぼやけます。",
    ),
),
"body_knee_profile": (
    "Knee Angle Profile", "膝の角度プロファイル",
    (
        "Shapes the knee at each bend angle. Auto-Rig Pro's Bulge can only change along one straight line; this drives the knee fans from a curve of angle against millimetres, so the knee cap and the hollow behind the knee can be set separately at every angle.",
        "An Auto-Rig Pro rig with knee fans (auxiliary bones set up).",
        "1. Edit Front and Back (or keep the defaults).\n"
        "2. Press Install Profile.\n"
        "3. Press Audit Profile and bend the knee to judge.",
        "- Front: angle:mm pairs for the front fans. Positive pushes the knee cap out, negative draws it back. Default 45:3.3, 60:-36.6, 75:-30, 90:-24.5, 95:-20.8, 170:-180.\n"
        "- Back: angle:mm pairs for the back fan. Positive fills the hollow behind the knee. Default 45:39.7, 60:44, 75:30, 90:13.5, 95:13.5, 110:54, 170:94.\n"
        "- Install Profile / Remove: Remove leaves the fans as plain linear constraints.\n"
        "- Audit Profile: shows which fans are driven and reads both curves back at several angles.",
        "Bend the knee step by step: the knee cap stays steady and the back does not cave in at moderate bends.",
        "- Remove returns to Auto-Rig Pro's straight-line behaviour.\n"
        "- Write pairs as angle:mm separated by commas; a typing error is reported and nothing is installed.",
    ),
    (
        "曲げる角度ごとに膝の形を決めます。Auto-Rig ProのBulgeは一本の直線でしか変えられません。これは角度とmmの曲線で膝の扇を動かすので、膝の皿と膝の裏のくぼみを、角度ごとに別々に決められます。",
        "膝の扇があるAuto-Rig Proのリグ（補助ボーンを設定済み）。",
        "1. 「前面」「後面」を書き換えます（既定のままでも構いません）。\n"
        "2. 「プロファイルを設定」。\n"
        "3. 「プロファイルを監査」を押し、膝を曲げて判断します。",
        "・前面：前の扇の角度:mmの組。正で膝の皿を外へ押し出し、負で引っ込めます。既定 45:3.3, 60:-36.6, 75:-30, 90:-24.5, 95:-20.8, 170:-180。\n"
        "・後面：後ろの扇の角度:mmの組。正で膝の裏のくぼみを埋めます。既定 45:39.7, 60:44, 75:30, 90:13.5, 95:13.5, 110:54, 170:94。\n"
        "・プロファイルを設定／解除：解除すると扇はふつうの直線の拘束に戻ります。\n"
        "・プロファイルを監査：どの扇を動かしているかと、いくつかの角度での両方の曲線の値を報告します。",
        "膝を少しずつ曲げ、膝の皿がぶれず、中くらいの曲げで裏がへこまなければ良好です。",
        "・「解除」でAuto-Rig Proの直線の動きに戻ります。\n"
        "・組は「角度:mm」をカンマで区切って書きます。書き間違いは報告され、何も設定しません。",
    ),
),
"body_wrist": (
    "Wrist fold", "手首の潰れ",
    (
        "Auto-Rig Pro gives the wrist one bone with nothing driving it. That holds to about 50 degrees, then the crease meets itself and the faces fold flat. This pushes that bone out of the crease by an amount that is zero until the wrist is past the angle where it still behaved, so nothing below that changes.",
        "A bound Auto-Rig Pro rig with hands.",
        "1. Press Open The Fold.\n"
        "2. Press Check.\n"
        "3. Bend the wrist to judge.",
        "- Open The Fold: installs the drivers on both wrists.\n"
        "- Check: measures the skin around both wrists through flexion, extension, both deviations and twist (the fix aims at flexion only; this proves the others are not damaged).\n"
        "- Remove: takes the drivers off and puts the bone back at zero.",
        "Bend the wrist past 60 degrees: the inside crease stays open. Check reports no damage on the other movements.",
        "- Remove returns to the original wrist.\n"
        "- Up to about 50 degrees nothing changes, by design.",
    ),
    (
        "Auto-Rig Proは手首に、何にも動かされない骨を1本だけ付けます。50度あたりまでは無傷ですが、その先でしわが重なって面が潰れます。これはその骨を、うまく動いていた角度を超えるまでは0の量でしわの外へ押し出すので、それ以下の角度では何も変わりません。",
        "手のあるバインド済みのAuto-Rig Proのリグ。",
        "1. 「襞を開く」。\n"
        "2. 「確認」。\n"
        "3. 手首を曲げて判断します。",
        "・襞を開く：両手首にドライバーを付けます。\n"
        "・確認：両手首の周りの肌を、掌屈・背屈・左右の傾き・ねじりで測ります（直しは掌屈だけが狙いで、他を壊していない事を確かめます）。\n"
        "・外す：ドライバーを外し、骨を0に戻します。",
        "手首を60度より深く曲げ、内側のしわが潰れなければ良好です。「確認」で他の動きに傷が出ません。",
        "・「外す」で元の手首に戻ります。\n"
        "・約50度までは、意図して何も変えません。",
    ),
),
"body_weight_tool": (
    "Weight tool", "ウェイトツール",
    (
        "Edits vertex weights precisely: set, add, subtract, scale, normalize, clean and limit, copy and paste between vertices, a table of every weight, and a quality audit. It is independent of Auto-Rig Pro's binding.",
        "Select a bound mesh. In Edit Mode select the vertices and make the vertex group to edit active (Object Data > Vertex Groups).",
        "1. Enter Edit Mode and select vertices.\n"
        "2. Set Weight, then press Set, + or -, or a preset (0 to 1).\n"
        "3. Use Scale, Normalize, Clean or Limit as needed.\n"
        "4. Open Skin Weight Table to read or edit single values.\n"
        "5. Run Weight Quality Audit at the end.",
        "- Weight (0.5) with Set / + / -: sets, adds or subtracts on the active group.\n"
        "- Preset buttons 0 ... 1: set that value directly.\n"
        "- Scale (1.0) with Scale: multiplies the weight.\n"
        "- Normalize: totals become 1. Clean: removes weights below Clean Threshold (0.0001). Limit: limits the number of influences.\n"
        "- Selected Vertices Only (on): off = every vertex of the mesh.\n"
        "- Normalize After Edit (on): keeps the edited value and shares the rest among the other unlocked groups.\n"
        "- Copy / Paste: copies all weights of the first selected vertex to the selected vertices.\n"
        "- Skin Weight Table / Export Table: popup table by vertex and group; export to a Text.\n"
        "- Weight Quality Audit: unweighted vertices, non-normalized totals, too many influences, tiny weights, groups that match no bone.",
        "Pose the rig and look; the audit reports zero problems or names them.",
        "- Ctrl+Z undoes each edit.\n"
        "- Weight edits are lost if you bind again with Auto-Rig Pro.",
    ),
    (
        "頂点のウェイトを正確に編集します。設定・加算・減算・スケール・正規化・クリーン・影響数制限、頂点間のコピーと貼り付け、全ウェイトの表、品質の監査ができます。Auto-Rig Proのバインドとは別の機能です。",
        "バインド済みのメッシュを選びます。編集モードで頂点を選び、編集する頂点グループをアクティブにします（オブジェクトデータ＞頂点グループ）。",
        "1. 編集モードで頂点を選びます。\n"
        "2. 「ウェイト」を決めて、「設定」「＋」「－」かプリセット（0〜1）を押します。\n"
        "3. 必要に応じて「スケール」「正規化」「クリーン」「影響数制限」。\n"
        "4. 1つずつの値は「スキンウェイトテーブル」で読み書きします。\n"
        "5. 最後に「ウェイト品質監査」。",
        "・ウェイト（0.5）＋設定／＋／－：アクティブなグループに設定・加算・減算します。\n"
        "・0〜1のプリセット：その値をそのまま設定します。\n"
        "・スケール（1.0）＋スケール：ウェイトに掛けます。\n"
        "・正規化：合計を1にします。クリーン：クリーンしきい値（0.0001）未満を消します。影響数制限：影響の数を絞ります。\n"
        "・選択頂点のみ（オン）：オフならメッシュの全頂点。\n"
        "・編集後に正規化（オン）：編集した値を保ち、残りを他のロックされていないグループに分けます。\n"
        "・コピー／貼り付け：最初に選んだ頂点の全ウェイトを、選んだ頂点へ写します。\n"
        "・スキンウェイトテーブル／テーブル書き出し：頂点とグループの表を開きます。Textへ書き出せます。\n"
        "・ウェイト品質監査：ウェイト無しの頂点、合計が1でない頂点、影響数の超過、極小ウェイト、骨と合わないグループを調べます。",
        "ポーズを付けて見た目を確かめ、監査で問題0か、問題の場所が出ます。",
        "・どの編集もCtrl+Zで戻せます。\n"
        "・Auto-Rig Proでバインドし直すと、ここでの編集は消えます。",
    ),
),
"body_hygiene": (
    "Rig hygiene", "リグの衛生",
    (
        "Finds what the weight checks cannot see: channels offered to the animator that move nothing, controls with no ceiling that push teeth or tongue through the skin, geometry bound to a bone that does not deform or to nothing, drivers that do not evaluate, and centre-line weight problems. Each fix button repairs one kind.",
        "A bound Auto-Rig Pro rig as the target. For the weight buttons, select the meshes (none selected = every bound mesh where stated). Save first.",
        "1. Press Audit Rig Hygiene and read the report.\n"
        "2. Press only the fix buttons for the problems it names.\n"
        "3. Audit again.",
        "- Audit Rig Hygiene: reports every kind below.\n"
        "- Lock Dead Channels: locks channels measured to move nothing (options you turned off in Auto-Rig Pro are only reported).\n"
        "- Clamp Jaw and Teeth: limits the jaw, teeth and tongue to the travel where they still clear the skin.\n"
        "- Bind What Is Not Bound: re-binds geometry that only looks bound; parents loose props to the head or neck.\n"
        "- Repair Dead Drivers: adds the missing properties drivers read, at zero (today's behaviour is kept).\n"
        "- Drop Faint Weights: removes lone weights under 0.05 that tear the mesh.\n"
        "- Symmetrize Mirror: makes mirrored vertex pairs mirror images.\n"
        "- Centre band mm (80) + Share Legs Across Centre: splits left/right leg weights by position near x = 0 (for skirts).",
        "The second audit reports zero for the kinds you fixed.",
        "- Ctrl+Z right after each fix; keep a saved copy.\n"
        "- Clamp Jaw and Teeth sets no new limit on a part with almost no clearance between it and the skin, and reports that. A limit set earlier stays.",
    ),
    (
        "ウェイトの検査では見えない問題を探します。アニメーターに見せているのに何も動かさないチャンネル、天井が無く歯や舌が肌を突き抜ける操作、変形しない骨や何にも結ばれていない形、評価されないドライバー、中心線のウェイトの問題です。直すボタンは種類ごとに1つです。",
        "バインド済みのAuto-Rig Proのリグを対象に設定。ウェイトのボタンはメッシュを選びます（書いてある物は、未選択なら全てのバインド済みメッシュ）。先に保存します。",
        "1. 「リグの衛生を監査」を押して報告を読みます。\n"
        "2. 報告に出た問題のボタンだけを押します。\n"
        "3. もう一度監査します。",
        "・リグの衛生を監査：下の全ての種類を報告します。\n"
        "・死んだチャンネルを閉じる：何も動かさないと測ったチャンネルをロックします（Auto-Rig Proで自分が切ったオプションのせいの物は報告だけ）。\n"
        "・顎と歯に天井を付ける：顎・歯・舌を、肌に当たらない範囲に制限します。\n"
        "・未接続を接続する：結ばれているように見えるだけの形を結び直し、親の無い小物を頭か首の骨に付けます。\n"
        "・死んだドライバーを直す：ドライバーが読む無いプロパティを0で足します（今の動きは変わりません）。\n"
        "・微小な重みを消す：肌を裂く、0.05未満の孤立した重みを消します。\n"
        "・左右対称に：左右で対になる頂点の重みを鏡像にします。\n"
        "・中心の帯mm（80）＋中心で脚の重みを分ける：x＝0付近の左右の脚の重みを位置で分けます（スカート用）。",
        "2回目の監査で、直した種類が0になれば完了です。",
        "・各直しの直後ならCtrl+Zで戻せます。保存した控えも残してください。\n"
        "・「顎と歯に天井を付ける」は、歯と肌の隙間がほとんど無い部位には新しい上限を付けず、そのことを報告します。前に付けた上限があれば、そのまま残ります。",
    ),
),
})

_SECTION_HELP.update({
"face": (
    "3. Face and Eyes", "3. 顔と目",
    (
        "Step 3. Finishes the face of an Auto-Rig Pro rig: eye references on the eyeball pivots, eyeballs bound in two parts (pupil follows the gaze, rim stays in the socket), eyelid pivot and range, facial weight reach, corrective shape keys and the eyelid cast shadow.",
        "The body is rigged and the face mesh is bound (section 2). Auto-Rig Pro's facial rig is set up.",
        "1. Eye rig: choose the eyeballs, Snap Eye References, then Match Reference to Rig.\n"
        "2. Eyeball Binding: Bind Eyeballs, Verify Eyeballs.\n"
        "3. Eyelid pivot: Audit, Correct Eyelid Pivot, Clamp Eyelid Range.\n"
        "4. Face weights and Facial weight reach: measure, then Trim The Reach.\n"
        "5. Corrective shape keys and Eyelid cast shadow as needed.",
        "Each subsection has its own ? help:\n"
        "- Eye rig, Eyeball Binding, Eyelid pivot\n"
        "- Face weights, Facial weight reach\n"
        "- Corrective shape keys, Eyelid cast shadow",
        "Look left and right with the eye target, blink, open the jaw: the eyes stay in the sockets, the lids close fully, the brow does not move with the eye.",
        "- Match to Rig or a facial re-setup in Auto-Rig Pro regenerates the face bones: the eyelid pivot fix must then be applied again.\n"
        "- Each button can be undone with Ctrl+Z right after it.",
    ),
    (
        "手順3です。Auto-Rig Proのリグの顔を仕上げます。目の参照を眼球のピボットに置き、眼球を2つに分けて結合し（瞳は視線に、縁は眼窩に）、瞼のピボットと可動域、顔のウェイトの効き範囲、補正シェイプキー、瞼の落ち影を設定します。",
        "体のリグができて、顔のメッシュがバインド済みである事（2章）。Auto-Rig Proのフェイシャルを設定済み。",
        "1. 目のリグ：眼球を選び、「目の参照をスナップ」の後で「参照ボーンをリグへ適合」。\n"
        "2. 眼球の結合：「眼球を結合」「眼球を検証」。\n"
        "3. 瞼のピボット：「監査」「瞼のピボットを補正」「瞼の可動域をクランプ」。\n"
        "4. 顔のウェイトと顔の効き範囲：測ってから「効き範囲を詰める」。\n"
        "5. 必要に応じて補正シェイプキーと瞼の落ち影。",
        "各サブセクションの見出しの？に説明があります：\n"
        "・目のリグ、眼球の結合、瞼のピボット\n"
        "・顔のウェイト、顔の効き範囲\n"
        "・補正シェイプキー、瞼の落ち影",
        "目のターゲットで左右を見て、瞬きをし、顎を開けます。眼球が眼窩に収まり、瞼が閉じきり、眉が目と一緒に動かなければ良好です。",
        "・Auto-Rig ProのMatch to Rigやフェイシャルの作り直しは顔の骨を作り直すので、瞼のピボットの補正は当て直しが必要です。\n"
        "・どのボタンも、直後ならCtrl+Zで戻せます。",
    ),
),
"face_eye_ref": (
    "Eye rig", "目のリグ",
    (
        "Auto-Rig Pro does not place its eye reference bones automatically. This puts them on the eyeball objects so the eye rotates about the eyeball's centre and looks out of the face, then audits the generated eye rig.",
        "The eyeballs are separate mesh objects. The Auto-Rig Pro reference rig with facial bones exists.",
        "1. Choose Left Eye and Right Eye.\n"
        "2. Choose the pivot source and Spec Dist.\n"
        "3. Press Snap Eye References.\n"
        "4. Run Match Reference to Rig (section 2), then Audit Eye Rig.",
        "- Left Eye / Right Eye: eyeball meshes. Leave one empty to skip that side.\n"
        "- Pivot source: Object Origin (default; use it when the origin was made the rotation centre, common for stylised eyes) or Bounding Box Centre.\n"
        "- Spec Dist. (1.0): length of the eye reference bone as a multiple of the eyeball radius; Auto-Rig Pro puts the Eye Spec controller at twice this in front, so this is the only way to move it.\n"
        "- Snap Eye References: places the reference bones.\n"
        "- Audit Eye Rig: pivot accuracy, eye target behind the face, broken reference bones, leftover vertex groups or empty UV projectors.",
        "After Match to Rig, rotate the eye controller: the eyeball turns in place. The audit reports no pivot error.",
        "- Ctrl+Z after snapping, or snap again with other settings.\n"
        "- Run Match Reference to Rig after snapping; until then the real rig is unchanged.",
    ),
    (
        "Auto-Rig Proは目の参照ボーンを自動では置きません。これは参照ボーンを眼球のオブジェクトに合わせて置き、眼球の中心で回って顔の外を見るようにし、作られた目のリグを監査します。",
        "眼球が別のメッシュオブジェクトである事。顔の骨を含むAuto-Rig Proの参照リグがある事。",
        "1. 「左目」「右目」を選びます。\n"
        "2. ピボットの取り方と「スペック距離」を決めます。\n"
        "3. 「目の参照をスナップ」。\n"
        "4. 2章の「参照ボーンをリグへ適合」を実行し、「目のリグを監査」。",
        "・左目／右目：眼球のメッシュ。片方を空にすると、その側は飛ばします。\n"
        "・ピボットの取り方：オブジェクトの原点（既定。原点を回転の中心に作った時。デフォルメの目に多い）か、バウンディングボックスの中心。\n"
        "・スペック距離（1.0）：目の参照ボーンの長さを眼球の半径の何倍にするか。Auto-Rig ProはEye Specのコントローラーをその2倍前に置くので、動かす方法はこれだけです。\n"
        "・目の参照をスナップ：参照ボーンを置きます。\n"
        "・目のリグを監査：ピボットの精度、目のターゲットが顔の後ろにないか、壊れた参照ボーン、残った頂点グループや空のUV投影を調べます。",
        "Match to Rigの後、目のコントローラーを回し、眼球がその場で回れば完了です。監査でピボットの誤差が出ません。",
        "・スナップの後はCtrl+Zか、設定を変えてもう一度スナップします。\n"
        "・スナップの後に「参照ボーンをリグへ適合」を実行するまで、本番のリグは変わりません。",
    ),
),
"face_eye_bind": (
    "Eyeball Binding", "眼球の結合",
    (
        "Binds each eyeball in two parts: the pupil to its own eye control so it follows the look-at target, and the outer rim to the face's eye socket so it travels with the lid. An eyeball bound rigidly to one bone drags its rim out of the socket as soon as the character looks sideways.",
        "The face mesh is bound before the eyes. The eye rig is set up (Eye rig). Choose Left Eye / Right Eye in Eye rig.",
        "1. Choose the Face Mesh.\n"
        "2. Press Bind Eyeballs.\n"
        "3. Set Test mm and press Verify Eyeballs.\n"
        "4. If you used a throwaway eye armature, press Remove Placeholder.",
        "- Face Mesh: the head mesh whose eye socket holds the rim. The rim gets no bone: it takes the weights of the face vertex it sits on.\n"
        "- Bind Eyeballs: binds pupil and rim.\n"
        "- Test mm (40): how far the look-at control is nudged for the test.\n"
        "- Verify Eyeballs: poses the look-at control and measures: the pupil must move and the seam with the face must hold.\n"
        "- Remove Placeholder: deletes a temporary eye armature (refuses while anything still uses it).",
        "Verify Eyeballs reports that the pupil moved and the seam held. Move the eye target by hand to see it.",
        "- Ctrl+Z right after binding.\n"
        "- At rest a correct bind and a wrong one look the same; only Verify proves it.",
    ),
    (
        "眼球を2つに分けて結合します。瞳は自分の目のコントロールに結び、視線のターゲットを追います。外側の縁は顔の眼窩に結び、瞼と一緒に動きます。1本の骨に固く結んだ眼球は、横を見た途端に縁が眼窩から出てしまいます。",
        "目より先に顔のメッシュをバインドしておきます。目のリグを設定済み（「目のリグ」）。「目のリグ」で左目・右目を選んでおきます。",
        "1. 「顔メッシュ」を選びます。\n"
        "2. 「眼球を結合」。\n"
        "3. 「検証 mm」を決めて「眼球を検証」。\n"
        "4. 仮の目のアーマチュアを使った時は「仮リグを削除」。",
        "・顔メッシュ：縁を収める眼窩を持つ頭のメッシュ。縁は骨を持たず、その上の顔の頂点のウェイトを受け継ぎます。\n"
        "・眼球を結合：瞳と縁を結合します。\n"
        "・検証 mm（40）：検証で視線のコントロールを動かす距離。\n"
        "・眼球を検証：視線のコントロールを動かして測ります。瞳は動き、顔との継ぎ目は離れない事。\n"
        "・仮リグを削除：仮の目のアーマチュアを消します（まだ使われている間は断ります）。",
        "「眼球を検証」で、瞳が動き継ぎ目が保たれたと出れば完了です。目のターゲットを手で動かしても確かめます。",
        "・結合の直後ならCtrl+Zで戻せます。\n"
        "・静止では正しい結合も間違った結合も同じに見えます。検証だけが証明です。",
    ),
),
"face_lid": (
    "Eyelid pivot", "瞼のピボット",
    (
        "Auto-Rig Pro places the eyelid base bones on the eye pivot but the bones that actually rotate somewhere else, so the lid swings away from the eyeball and cannot shut. This measures it, moves the rotating bones onto the eye pivot, stops the lid controls running past closed, and prepares Auto-Rig Pro's Blink Pose.",
        "Auto-Rig Pro facial rig with eyelids, eyes set up.",
        "1. Set Test Pull mm and press Audit.\n"
        "2. If the pivot is off, press Correct Eyelid Pivot.\n"
        "3. Press Clamp Eyelid Range.\n"
        "4. If the closed shape is still wrong: Prepare Blink Pose (or Lower), then press Auto-Rig Pro's Add Blink Pose as told.",
        "- Test Pull mm (16): how far the top-lid control is pulled for the test; reported as a percentage of the socket height (under 100% = cannot close).\n"
        "- Audit: distance between each lid pivot and the eye pivot, and how far the eye shuts.\n"
        "- Correct Eyelid Pivot: moves the rotating lid bones onto the eye pivot (no weight change).\n"
        "- Clamp Eyelid Range: ends the lid control's travel where the eye actually shuts.\n"
        "- Prepare Blink Pose / Lower: checks the pivot and closing, enters Pose Mode with the lid control selected and held closed.",
        "Pull the lid control down fully: the lid closes over the eyeball and stops there. Audit shows 100% or more.",
        "- Ctrl+Z right after each step.\n"
        "- Correct Eyelid Pivot is a patch: Match to Rig or a facial re-setup brings the fault back; apply it again afterwards.\n"
        "- Blink Pose itself is pressed in Auto-Rig Pro (GUI).",
    ),
    (
        "Auto-Rig Proは瞼の土台の骨を眼球のピボットに置きますが、実際に回る骨は別の場所に置くので、瞼が眼球から離れて回り、閉じきりません。これはそれを測り、回る骨を眼球のピボットへ移し、瞼のコントロールが閉じた位置を超えないようにし、Auto-Rig ProのBlink Poseを準備します。",
        "瞼のあるAuto-Rig Proのフェイシャルで、目を設定済み。",
        "1. 「検証の引き量mm」を決めて「監査」。\n"
        "2. ピボットがずれていれば「瞼のピボットを補正」。\n"
        "3. 「瞼の可動域をクランプ」。\n"
        "4. まだ閉じた形がおかしい時：「Blink Pose の準備」（または「下瞼」）を押し、案内の通りにAuto-Rig ProのAdd Blink Poseを押します。",
        "・検証の引き量mm（16）：検証で上瞼のコントロールを引く量。眼窩の高さに対する割合で報告します（100%未満は閉じられません）。\n"
        "・監査：瞼のピボットと眼球のピボットの距離、目がどこまで閉じるか。\n"
        "・瞼のピボットを補正：回る瞼の骨を眼球のピボットへ移します（ウェイトは変えません）。\n"
        "・瞼の可動域をクランプ：瞼のコントロールの動きを、実際に目が閉じる所で止めます。\n"
        "・Blink Pose の準備／下瞼：ピボットと閉じ方を確かめ、ポーズモードで瞼のコントロールを選んで閉じた状態にします。",
        "瞼のコントロールを下まで引き、瞼が眼球を覆って閉じ、そこで止まれば完了です。監査で100%以上と出ます。",
        "・各手順の直後ならCtrl+Zで戻せます。\n"
        "・瞼のピボットの補正は応急処置です。Match to Rigやフェイシャルの作り直しで元に戻るので、その後に当て直します。\n"
        "・Blink Pose自体はAuto-Rig Proのボタンを画面で押します。",
    ),
),
"face_weight": (
    "Face weights", "顔のウェイト",
    (
        "Answers 'the face weights are loose' with numbers: weight per vertex summed over the main rig's bones only, the spread of influence counts, how far each bone reaches against its length, and the left-to-right difference.",
        "A bound face mesh. Select it (or set the targets).",
        "1. Press Audit Face Weights.\n"
        "2. Read the report in the status bar and the report Text.",
        "- Audit Face Weights: counts over the main rig only. The additive rig's blocker bones are excluded, because one of them holds weight on every face vertex and would make the whole mesh look broken.",
        "The report gives the numbers; compare them before and after a weight change.",
        "- Changes nothing; nothing to undo.",
    ),
    (
        "「顔のウェイトが緩い」を数で答えます。本体リグの骨だけで集計した頂点ごとの合計、影響数のばらつき、骨の長さに対する効きの届く距離、左右の差です。",
        "バインド済みの顔メッシュ。それを選びます（または対象を設定）。",
        "1. 「顔のウェイトを監査」。\n"
        "2. ステータスバーとレポートのTextで報告を読みます。",
        "・顔のウェイトを監査：本体リグの骨だけで集計します。追加リグのブロッカーの骨は除きます。その1本が顔の全頂点にウェイトを持つので、含めるとメッシュ全体が壊れて見えるためです。",
        "報告の数を、ウェイトを変える前と後で比べます。",
        "・何も変えないので、戻す物はありません。",
    ),
),
"face_falloff": (
    "Facial weight reach", "顔の効き範囲",
    (
        "Keeps each facial bone inside its own feature: an eye control should not move the brow, a brow control should not move the eye, and the jaw should not pull the middle of the upper lip. Also stops lid correctives from moving the brow.",
        "A bound face with Auto-Rig Pro facial bones. Save first: this edits weights and shape keys.",
        "1. Press Measure.\n"
        "2. Press Trim The Reach.\n"
        "3. Press Measure again.\n"
        "4. If a blink moves the brow, press Confine The Lid Correctives.",
        "- Measure: how far each facial bone's influence travels and how much of it lands in a feature it does not belong to (judged against the spacing to the nearest sibling bone).\n"
        "- Trim The Reach: clears eye and lid bones out of the brow and lips, brow and nose bones out of the eye, and the jaw out of the middle of the upper lip; the fade happens outside the region. Runs twice by default.\n"
        "- Confine The Lid Correctives: fades the lid-closure shape keys to zero outside the lid region.",
        "Measure again: the foreign weight drops. Blink and raise the brow: each moves only its own feature.",
        "- Ctrl+Z right after, or a saved copy.\n"
        "- Run it again after rebinding the face.",
    ),
    (
        "顔の骨を、それぞれ自分の部位に収めます。目のコントロールで眉が動かず、眉のコントロールで目が動かず、顎が上唇の真ん中を引かないようにします。瞼の補正キーで眉が動くのも止めます。",
        "Auto-Rig Proの顔の骨でバインドした顔。ウェイトとシェイプキーを書き換えるので、先に保存します。",
        "1. 「測る」。\n"
        "2. 「効き範囲を詰める」。\n"
        "3. もう一度「測る」。\n"
        "4. 瞬きで眉が動く時は「瞼の補正キーを閉じ込める」。",
        "・測る：顔の骨ごとの効きの届く距離と、そのうち別の部位に入っている量を報告します（一番近い隣の骨との間隔で判断します）。\n"
        "・効き範囲を詰める：目と瞼の骨を眉と唇から、眉と鼻の骨を目から、顎を上唇の真ん中から外します。減衰は部位の外側で行います。既定で2回走ります。\n"
        "・瞼の補正キーを閉じ込める：瞼を閉じる補正キーを、瞼の部位の外では0へ減らします。",
        "もう一度測り、別の部位への効きが減れば完了です。瞬きと眉上げで、それぞれ自分の部位だけが動きます。",
        "・直後のCtrl+Zか、保存した控えで戻します。\n"
        "・顔をバインドし直したら、もう一度実行します。",
    ),
),
"face_corrective": (
    "Corrective shape keys", "補正シェイプキー",
    (
        "For what weights cannot do: a folded, faceted closed eyelid, and an upper lip dragged down by the jaw. Each button builds a shape key and drives it from the control.",
        "A bound face with the lid and jaw controls. Eyelid pivot corrected first.",
        "1. Press Correct Closed Eyelid.\n"
        "2. Press Hold Upper Lip.\n"
        "3. Blink and open the jaw to judge.",
        "- Correct Closed Eyelid: a shape key that takes the faceting out of the closed lid, driven by the lid control.\n"
        "- Hold Upper Lip: a shape key that keeps the upper lip from following the jaw down, fading toward the lip crevice so the lips still meet.",
        "Close the eye: the lid surface is smooth. Open the jaw: the upper lip stays, the lips still meet when closed.",
        "- Delete the generated shape key (Object Data > Shape Keys) or Ctrl+Z to undo.\n"
        "- If the brow moves on a blink afterwards, use Confine The Lid Correctives (Facial weight reach).",
    ),
    (
        "ウェイトでは表せない所のためです。閉じた時に折れて角張る瞼と、顎に引かれて下がる上唇。それぞれシェイプキーを作り、コントロールで動かします。",
        "瞼と顎のコントロールがあるバインド済みの顔。先に瞼のピボットを補正しておきます。",
        "1. 「閉じた瞼を補正」。\n"
        "2. 「上唇を保持」。\n"
        "3. 瞬きと口を開けて判断します。",
        "・閉じた瞼を補正：閉じた瞼の角張りを取るシェイプキーを作り、瞼のコントロールで動かします。\n"
        "・上唇を保持：顎と一緒に上唇が下がらないようにするシェイプキー。唇の合わせ目へ向かって弱めるので、唇は閉じられます。",
        "目を閉じて瞼の面が滑らか、口を開けて上唇が残り、閉じた時に唇が合えば完了です。",
        "・作られたシェイプキーを消す（オブジェクトデータ＞シェイプキー）かCtrl+Zで戻します。\n"
        "・その後に瞬きで眉が動くなら、「顔の効き範囲」の「瞼の補正キーを閉じ込める」を使います。",
    ),
),
"face_shadow": (
    "Eyelid cast shadow", "瞼の落ち影",
    (
        "A shadow painted into the eyeball's UVs stays put when the eye closes. This makes the cast-shadow map slide with the upper lid: a UV Project projector is built and its height is driven by how far the lid margin really travels (measured). "
        "The projector is bone-parented to the eye socket -- the bone the eyeball and the upper-lid control both hang from (c_eye_offset.l/.r on Auto-Rig Pro) -- so the shadow follows the head, the neck and the body. It does not turn with the gaze: the shadow belongs to the lid, not to the pupil.",
        "Eyeballs with a cast-shadow texture on their own UV map, a bound face with lid controls. Nothing extra is needed with a shoe lift: the projector is inside the rig and rises with it.",
        "1. Press Follow The Lid.\n"
        "2. Press Check.\n"
        "3. Blink, and turn the head, to judge.\n"
        "4. Pressing Follow The Lid again later is safe (see below).",
        "- Follow The Lid: builds the projector and the UV Project setup, driven from the upper lid. At rest the projector stays exactly where it was in the world; it is moved under the socket bone, and the lid moves it in that bone's coordinates, by the same amount in the same direction.\n"
        "- Follow The Lid again: an existing projector keeps its rest placement and its lid expression (also one with different coefficients for opening and closing) and is only re-parented. One with no parent (older-format files) is moved under the socket bone; one already parented is rebuilt in the bone's coordinates, which gives the same result.\n"
        "- Follow (1.0), Closed At mm (8.38), Distance mm (200): how much of the lid's travel the shadow takes, how far the lid control is pulled when measuring, and how far in front of the eye the projector sits.\n"
        "- Measure Again (off): places the projector from the eyeball's own UV layer and measures the lid again, as a first build does. Follow, Distance mm and Closed At mm only apply then.\n"
        "- Check: proves the lid half works (the projector moves when the lid closes, and the generated UVs move with it), then turns the head hard with the gaze held: the eyeball's UVs must stay as at rest. Above 0.001 it reports NOT FOLLOWING.\n"
        "- Remove: takes the projector out and puts the UV Project modifier back as found (an existing one is switched off, not deleted).",
        "Check reports both moved, and a head-move UV change near 0 (about 0.00001). Close the eye in Material Preview: the shadow moves down with the lid. Turn the head and the body: the white of the eye stays white.",
        "- Remove returns to the original state.\n"
        "- A projector it cannot read (a constraint, an animation, a location driver in a form it does not know) is refused before anything changes.\n"
        "- The shoe lift adds no driver to a projector inside the rig. A driver left there would lift it twice; the shoe lift's Lift and Remove take it off.\n"
        "- A projector that moves while the modifier is off changes nothing on screen; use Check, not the modifier panel.",
    ),
    (
        "眼球のUVに描いた落ち影は、目を閉じてもその場に残ります。これは落ち影のマップを上瞼と一緒に滑らせます。UV投影の投影機を作り、その高さを瞼の縁が実際に動く距離（測った値）で動かします。"
        "投影機は目の窪みの骨（眼球と上瞼のコントロールの両方がぶら下がる骨。Auto-Rig Pro では c_eye_offset.l/.r）にボーン親で付くので、影は頭・首・体の動きに追従します。視線では回りません。影は瞼が落とす物で、瞳の物ではないからです。",
        "落ち影のテクスチャを自分のUVマップに持つ眼球と、瞼のコントロールがあるバインド済みの顔。靴底の高さを使っていても追加の準備は要りません。投影機はリグの中にあり、一緒に上がります。",
        "1. 「瞼に追従させる」。\n"
        "2. 「確認」。\n"
        "3. 瞬きと、頭を動かして判断します。\n"
        "4. 後でもう一度「瞼に追従させる」を押しても壊れません（下を参照）。",
        "・瞼に追従させる：投影機とUV投影の設定を作り、上瞼で動かします。静止の姿勢では、投影機はワールドの同じ場所のままです。目の窪みの骨の下へ移し、瞼はその骨の座標で、同じ向きに同じだけ動かします。\n"
        "・もう一度押した時：既にある投影機は、静止の置き場所と瞼の式（開く時と閉じる時で係数が違う式も）をそのまま使い、親だけを付け直します。親のない投影機（旧形式のファイル）は目の窪みの骨の下へ移し、既に親がある物は骨の座標で作り直します。結果は同じです。\n"
        "・追従（1.0）、閉じる位置 mm（8.38）、距離 mm（200）：瞼の移動のうち影が動く割合、測る時に瞼のコントロールを引く量、投影機を目の前のどこに置くか。\n"
        "・測り直す（オフ）：眼球自身のUVレイヤーから投影機を置き直し、瞼の動きを測り直します（初めて作る時と同じ）。「追従」「距離 mm」「閉じる位置 mm」はこの時だけ効きます。\n"
        "・確認：瞼を閉じると投影機が動く事と、作られたUVが一緒に動く事を確かめ、続けて視線を止めたまま頭を大きく動かします。眼球のUVが静止の時と同じなら追従しています。0.001 を超えると「NOT FOLLOWING」と出ます。\n"
        "・外す：投影機を取り除き、UV投影のモディファイアを元の状態に戻します（元からあった物は消さずにオフにします）。",
        "「確認」で両方が動いたと出て、頭を動かした時のUVの差が 0 に近い（0.00001 程度）事。マテリアルプレビューで目を閉じると影が瞼と一緒に下がり、頭や体を動かしても白目が白いままなら完了です。",
        "・「外す」で元に戻ります。\n"
        "・読めない投影機（拘束・アニメーション・知らない形の位置のドライバーがある物）は、何も変えずに断ります。\n"
        "・靴底の高さは、リグの中にある投影機にはドライバーを足しません。2 重に上げるドライバーが残っている時は、靴底の「上げる」と「取り外す」で取り除きます。\n"
        "・モディファイアがオフのまま投影機が動いても画面は変わりません。モディファイアのパネルではなく「確認」で判断します。",
    ),
),
})

_SECTION_HELP.update({
"hair": (
    "4. Hair, Costume & Hard Parts", "4. 髪・衣装・固い部品",
    (
        "Step 4. Gives hair and hanging parts bone chains with joints on the mesh divisions, binds costume parts from the skin, keeps bands round a limb at their width, makes metal parts rigid, stops sleeves following the wrist, and keeps layers from passing through each other.",
        "The body is rigged and bound (section 2). Each hair or costume part is a separate mesh or collection (section 1, Parts).",
        "1. Hair: Hair & Dangling Parts (many strands at once) or Chain on Selected Part (one part).\n"
        "2. Costume: Bind Costume Part, then Strip bones for skirts and coats.\n"
        "3. Bands, hard parts and layers as needed.\n"
        "4. Then go to 5. Jiggle to bake the motion.",
        "Each subsection has its own ? help:\n"
        "- Hair & Dangling Parts, Costume parts, Chain on Selected Part\n"
        "- Strip bones (ARP Kilt) with its two groups\n"
        "- Band Round a Limb, Hard Parts & Bones, Layers & Penetration",
        "Pose the rig and play the animation: hair and costume follow without passing into the body.",
        "- Each build button has a matching remove button; Ctrl+Z works right after each step.\n"
        "- After changing the body rig, rebind costumes and rebuild chains.",
    ),
    (
        "手順4です。髪や垂れる部品に、メッシュの区切りに関節を置いたボーンの鎖を作り、衣装パーツを肌から結合し、腕や脚に巻いた帯の幅を保ち、金具を剛体にし、袖が手首に追従しないようにし、重ね着がすり抜けないようにします。",
        "体のリグとバインドが済んでいる事（2章）。髪や衣装の部品は別のメッシュかコレクションに分けておきます（1章のパーツ）。",
        "1. 髪：「髪・垂れ下がるパーツ」（多くの房をまとめて）か「選択パーツに鎖を作る」（1つずつ）。\n"
        "2. 衣装：「衣装パーツを結合」の後、スカートや上着には「短冊ボーン」。\n"
        "3. 必要に応じて帯、固い部品、重ね着。\n"
        "4. その後、5章で揺れを焼きます。",
        "各サブセクションの見出しの？に説明があります：\n"
        "・髪・垂れ下がるパーツ、衣装パーツ、選択パーツに鎖を作る\n"
        "・短冊ボーン（ARPのKilt）と、その中の2つのまとまり\n"
        "・腕や脚に巻かれた帯、固い部品・骨の族、重ね着・めり込み",
        "ポーズを付けてアニメーションを再生し、髪と衣装が体に入り込まずについて来れば良好です。",
        "・作るボタンには対応する外すボタンがあります。各手順の直後はCtrl+Zで戻せます。\n"
        "・体のリグを変えたら、衣装を結合し直し、鎖を作り直します。",
    ),
),
"hair_hair": (
    "Hair & Dangling Parts", "髪・垂れ下がるパーツ",
    (
        "Builds chains for a whole set of hair strands at once. Every long strand gets the same number of bones spaced along its own centreline, so all strands can be posed together by one master chain; short pieces get a few bones, pieces on the head are pinned, and metal ornaments stay rigid.",
        "Hair meshes bound or ready to bind; strands in their own collections (By Collection) or named by a pattern. The rig set as the target.",
        "1. Turn By Collection on (recommended) or off, and enter a Pattern that fits the strands' names.\n"
        "2. Set Bones, Parent and Prefix.\n"
        "3. Press Build Hair Chains.\n"
        "4. Press Audit Hair Chains.",
        "- Pattern ((tail[A-Z])): regular expression that finds the strands. With By Collection on it is matched against collection names (only those that also contain the Marker) and each collection is a strand group; off, against mesh names, and its first capture is the group. Whatever does not match gets no chain.\n"
        "- Bones (10): bones per long strand; every strand gets the same count.\n"
        "- Parent (c_head.x): bone the strands hang from and loose pieces are pinned to.\n"
        "- Prefix (hair): prefix of the new bones and vertex groups.\n"
        "- Rigid Materials (MIK_mtl_metal): comma separated materials bound whole to their nearest bone.\n"
        "- Master Chain (on): one master chain drives every strand; lowering one constraint lets that strand depart.\n"
        "- Pin Loose (on): meshes that match no strand are pinned rigidly to the parent.\n"
        "- By Collection (on), Long From mm (300): shorter groups are short pieces; Short Piece Bones (2), 0 = rigid.\n"
        "- Build / Remove / Audit Hair Chains: Audit lists bone count, mean bone length, master driving.",
        "Rotate the master chain: every strand bends the same way. The audit shows the same bone count for all long strands.",
        "- Remove deletes the generated bones and their vertex groups.\n"
        "- Ten bones down a short clump is not a chain: keep Long From mm sensible.",
    ),
    (
        "髪の房をまとめて鎖にします。長い房は全て、自分の中心線に沿って同じ本数のボーンを持つので、1本のマスターで全部を一緒に動かせます。短いピースは少ない本数、頭に乗った物は固定、金具は曲がりません。",
        "髪のメッシュがバインド済みか、バインドできる状態。房は自分のコレクションに分けるか（コレクション単位）、名前のパターンで分かる事。リグを対象に設定。",
        "1. 「コレクション単位」（おすすめ）をオンかオフにし、房の名前に合う「名前パターン」を入れます。\n"
        "2. 「ボーン数」「親ボーン」「接頭辞」を決めます。\n"
        "3. 「髪チェーンを生成」。\n"
        "4. 「髪チェーンを監査」。",
        "・名前パターン（(tail[A-Z])）：房を見分ける正規表現。コレクション単位がオンならコレクションの名前に当て（識別名も名前に含むコレクションだけ）、コレクションごとに房をまとめます。オフならメッシュの名前に当て、最初のカッコが房のまとまりになります。合わない物は鎖になりません。\n"
        "・ボーン数（10）：長い房1本あたりのボーン。全ての房が同じ本数です。\n"
        "・親ボーン（c_head.x）：房をぶら下げ、残りのピースを固定する骨。\n"
        "・接頭辞（hair）：新しいボーンと頂点グループの名前の頭。\n"
        "・硬い材質（MIK_mtl_metal）：カンマ区切り。その材質の島は丸ごと一番近い骨に結びます。\n"
        "・マスター（オン）：1本のマスターが全ての房を動かします。1つの拘束の影響を下げると、その房だけ離れます。\n"
        "・残りを固定（オン）：どの房にも合わないメッシュを親に固く結びます。\n"
        "・コレクション単位（オン）、長い房の下限mm（300）：それより短いまとまりは短いピース。短いピースのボーン数（2）、0なら固定。\n"
        "・生成／解除／監査：監査はボーン数、平均の長さ、マスターが動かしているかを報告します。",
        "マスターを回すと全ての房が同じに曲がり、監査で長い房が全て同じ本数なら完了です。",
        "・「解除」で作ったボーンとその頂点グループを消します。\n"
        "・短い房に10本は鎖になりません。「長い房の下限mm」を適切に。",
    ),
),
"hair_costume": (
    "Costume parts", "衣装パーツ",
    (
        "Binds the selected costume parts by inheriting the skin's own weights instead of picking bones by distance. The body is already tuned, so copying it keeps the garment in step with the skin at every joint. Swing is solved once later and kept as keyframes.",
        "The body mesh is bound and tuned. Select the costume meshes (Object Mode). The skin is found for you: Target Body Mesh if it is set, otherwise the nearest visible mesh bound to the rig that reads as a body (not a bound costume part, not an accessory on a few bones). To choose it yourself, also Ctrl-click the skin last so that it is active. When no skin was chosen, a selected mesh that already has weights is left alone, and the Target Body Mesh is never written to.",
        "1. Select the costume parts.\n"
        "2. Press Bind Costume Part.\n"
        "3. Pose the rig to check.",
        "- Copy Weights From: the mesh to copy from. Empty finds the skin by itself. Target Body Mesh is never written over, and neither is a mesh with weights of its own that this button did not bind.\n"
        "- Solid Part: for a nail, a stud or a zip tooth; each separate piece follows one bone.\n"
        "- Before Keys: copies against the source's shape before its shape keys. Only for a part that shares them.\n"
        "- Bind Costume Part: copies the skin's weights onto the selected parts. The report names the mesh they were copied from.",
        "Bend elbows and knees: the garment moves with the skin and does not pass through it.",
        "- Ctrl+Z right after.\n"
        "- A garment worn over another garment is better bound with Layers & Penetration > Bind Over Layer.",
    ),
    (
        "選んだ衣装パーツを、距離で骨を選ぶのではなく、肌のウェイトを受け継いで結合します。体は調整済みなので、写すと全ての関節で衣装が肌と揃って動きます。揺れは後で一度解いて、キーとして持ちます。",
        "素体メッシュがバインドと調整済み。衣装のメッシュを選びます（オブジェクトモード）。肌は自動で探します：「対象ボディメッシュ」があればそれ、無ければリグに結び付いた見えているメッシュのうち、体らしい物（結合済みの衣装や、少ない骨だけの小物を除く）で一番近い物です。自分で決める時は、最後に肌をCtrlクリックしてアクティブにします。肌を決めていない時は、既にウェイトのあるメッシュは変更せず、「対象ボディメッシュ」には書き込みません。",
        "1. 衣装パーツを選びます。\n"
        "2. 「衣装パーツを結合」。\n"
        "3. ポーズを付けて確かめます。",
        "・ウェイトの写し元：写す元のメッシュ。空なら肌を自動で探します。ボディメッシュに指定した物と、この押し方で結合していないウェイトのあるメッシュには書きません。\n"
        "・固い部品：爪・鋲・ファスナーの歯などに使います。離れた塊ごとに 1 本の骨で動きます。\n"
        "・キー前の形から：写し元のシェイプキーを効かせる前の形で写します。同じシェイプキーを持つ部品だけに使います。\n"
        "・衣装パーツを結合：肌のウェイトを、選んだパーツに写します。どのメッシュから写したかは報告に出ます。",
        "肘と膝を曲げ、衣装が肌と一緒に動き、突き抜けなければ完了です。",
        "・直後ならCtrl+Zで戻せます。\n"
        "・別の衣装の上に着る物は、「重ね着・めり込み」の「下に合わせる」で結合する方が揃います。",
    ),
),
"hair_chain": (
    "Chain on Selected Part", "選択パーツに鎖を作る",
    (
        "Grows a bone chain down one selected part (a strap, a braid, a hem, a charm), weights the part onto it, and stores the swing settings on the chain's root so a re-bake repeats itself. Joints are placed on the mesh's own divisions, never inside a rigid piece.",
        "Select the part's mesh. In Edit Mode select vertices to chain only that area (nothing selected = whole mesh). Set the target rig. A mesh not yet bound to the rig is bound by Build Chain: it gets the Armature modifier, its vertices with no weight follow From (a control that does not deform: the deform bone nearest to it; From empty: the bone nearest the top of the part; the report names the bone), and a link to a parent bone is replaced so that it does not move twice.",
        "1. Choose the shape (Strand, Sheet or Links) and type a unique chain name.\n"
        "2. Set Bones, From (parent bone) and the swing type.\n"
        "3. Choose where the joints go and its values.\n"
        "4. Press Build Chain.\n"
        "5. Optional: Add Adjust Bones, or group several chains with Pose Selected Chains Together.",
        "- Shape: Strand (one line), Sheet (wide, split into Columns, Straight or Around), Links (separate solid pieces).\n"
        "- Name (part): goes into srs_chain_<name>_01; give each chain its own name.\n"
        "- Bones (3), From (empty = the part's top edge chooses), swing: Long hair, Fringe, Short hair (default), Earring, Zip pull, Hem, Strap, None.\n"
        "- Joints: Spacing (Spacing 60 mm, Root finer spacing, Over 200 mm), Every division, Every edge loop (Skip 5 loops, Blend 2, Above 80 mm, loops from Hair Strands or the selection's top edge, Min mm, Root follows the surface), Even.\n"
        "- Rigid (metal): pieces with this in their name or material get one bone spanning them.\n"
        "- Remove Chain: removes this name's bones and vertex groups.\n"
        "- Add Adjust Bones: a child bone for hand corrections on top of the body motion. Only Bones Above (0.30): a bone the part barely uses gets none.\n"
        "- Group name (braids) + Pose Selected Chains Together / X: one swing and one curl control for the selected chains.",
        "Rotate the chain's bones: the part bends at its own divisions and rigid pieces stay straight.",
        "- Remove Chain before building again under the same name.\n"
        "- Two chains under one name leave the first attached to nothing usable.",
    ),
    (
        "選んだ1つのパーツ（ストラップ、三つ編み、裾、チャーム）に沿ってボーンの鎖を伸ばし、ウェイトを付け、揺れの設定を鎖の根元に覚えます（焼き直しても同じ結果）。関節はメッシュの区切りに置き、固い部品の中には置きません。",
        "パーツのメッシュを選びます。編集モードで頂点を選べばその部分だけ（未選択ならメッシュ全体）。リグを対象に設定。リグに結び付いていないメッシュは「鎖を作る」が結び付けます。アーマチュアモディファイアを付け、ウェイトの無い頂点は「親」の骨に付きます（親が変形しない制御骨なら一番近い変形骨、空ならパーツの上端に近い骨。どの骨かは報告に出ます）。骨への親子付けは、動きが二重にならないよう外します。",
        "1. 形（ストランド・シート・リンク）を選び、他と重ならない鎖の名前を入れます。\n"
        "2. 「本数」「親」（親ボーン）と揺れの種類を決めます。\n"
        "3. 関節の置き方とその値を選びます。\n"
        "4. 「鎖を作る」。\n"
        "5. 必要なら「加算ボーンを追加」や、「選んだ鎖をまとめて動かす」で複数の鎖をまとめます。",
        "・形：ストランド（1本の線）、シート（幅広。「列」で分け、まっすぐか周りで）、リンク（離れた固い部品）。\n"
        "・名前（part）：srs_chain_<名前>_01になります。鎖ごとに別の名前に。\n"
        "・本数（3）、親（空なら上端が選ぶ）、揺れ：長い髪、前髪、短い髪（既定）、耳飾り、ジップの引き手、裾、垂れる帯、なし。\n"
        "・関節：間隔（間隔60mm、根元は細かい間隔、範囲200mm）、分割ごと、辺ループごと（飛ばす5輪、馴染ませ2、長さ超80mm、輪の取り方は房か選択の上端、最短mm、根元を周りの面に沿わせる）、均一。\n"
        "・剛体（metal）：名前か材質にこれを含む部品は、1本の骨で丸ごと運びます。\n"
        "・鎖を消す：その名前のボーンと頂点グループを消します。\n"
        "・加算ボーンを追加：体の動きの上に手で直しを足す子の骨を作ります。「対象ボーンの下限」（0.30）より使われ方の少ない骨には付けません。\n"
        "・グループ名（braids）＋選んだ鎖をまとめて動かす／×：選んだ鎖に、振りと巻きのコントロールを1組付けます。",
        "鎖の骨を回し、パーツが自分の区切りで曲がり、固い部品がまっすぐなら完了です。",
        "・同じ名前で作り直す前に「鎖を消す」。\n"
        "・1つの名前に2本作ると、最初の方は使える物に何も結ばれなくなります。",
    ),
),
"hair_strip": (
    "Strip bones (ARP Kilt)", "短冊ボーン（ARP の Kilt）",
    (
        "Gives a skirt, coat tail or cuff strip bones with Auto-Rig Pro's Kilt and weights it onto them. Each strip is a column of controllers kept off the legs (or the hand) by Auto-Rig Pro's own constraints; keys on the controllers add on top. Match to Rig is not run, so nothing else on the rig changes.",
        "Select the part's vertices in Edit Mode first. Auto-Rig Pro enabled, the rig set as the target.",
        "1. Type the Name and choose the layout.\n"
        "2. Set Strips and Bones, the bones to keep off, and the options.\n"
        "3. Press Build Strip Bones.\n"
        "4. If strips stand up in front of a raised thigh, use the group below (its own ?).",
        "- Name (skirt) and layout: Left and right (mirrored halves), Full Ring, Left only, Right only.\n"
        "- Strips (6, per side when mirrored), Bones (3 controllers per strip).\n"
        "- Keep off (thigh.l, thigh.r): bones the strips avoid.\n"
        "- On the pleats (off): one strip per pleat panel read from the folds (needs Full Ring).\n"
        "- Collide on Z (off): also avoid along Z, for legs that rotate far.\n"
        "- Angles (empty = even): where the strips sit, degrees (0 = +X, -90 = front).\n"
        "- Top blend mm (40): how far down the part passes from its weights onto the strips.\n"
        "- Top from underneath + garment: the top blend takes the weights of the garment underneath.",
        "Raise a leg: the strips swing away from the thigh instead of passing through it.",
        "- Ctrl+Z right after building.\n"
        "- Strips that stand up toward the chest: Strips Lie on a Raised Thigh.",
    ),
    (
        "スカート、上着の裾、袖口に、Auto-Rig ProのKiltで短冊ボーンを付けてウェイトを結びます。短冊はコントローラーの列で、Auto-Rig Pro自身の拘束で脚（や手）を避けます。コントローラーに打ったキーは上に足されます。Match to Rigは実行しないので、リグの他の部分は変わりません。",
        "先に編集モードで部品の頂点を選びます。Auto-Rig Proが有効で、リグを対象に設定。",
        "1. 「名前」を入れ、配置を選びます。\n"
        "2. 「列」「段」、避ける骨、オプションを決めます。\n"
        "3. 「短冊ボーンを作る」。\n"
        "4. 上げた太ももの前で短冊が立つ時は、下のまとまり（そこの？）を使います。",
        "・名前（skirt）と配置：左右対称（鏡の半分ずつ）、1 周、左だけ、右だけ。\n"
        "・列（6。左右対称なら片側の数）、段（1列のコントローラー数3）。\n"
        "・避ける（thigh.l、thigh.r）：短冊が避ける骨。\n"
        "・ひだに沿わせる（オフ）：服のひだを読み、ひだ1枚に1列（1 周の時だけ）。\n"
        "・Zでも避ける（オフ）：脚を大きく回す時に、Z方向でも避けます。\n"
        "・角度（空なら等間隔）：短冊を置く角度（0＝＋X、－90＝前）。\n"
        "・上端のつなぎmm（40）：上から何mmで、部品のウェイトから短冊へ移すか。\n"
        "・上端は下の服から＋服：上端のつなぎを、下の服のウェイトから取ります。",
        "脚を上げ、短冊が太ももを突き抜けずに外へ逃げれば完了です。",
        "・作った直後ならCtrl+Zで戻せます。\n"
        "・胸の方へ立ち上がる短冊には「上げた太ももに短冊を乗せる」。",
    ),
),
"hair_kilt_push": (
    "Strips on a raised thigh", "上げた太ももの短冊",
    (
        "When strips stand up in front of a raised thigh, this sets how far an existing kilt's strips are kept off the legs and eases that push off as a leg rises, so the front strips lie on the thigh. It works on a kilt that is already built.",
        "A kilt built with Build Strip Bones. The Name field above holds its name.",
        "1. Set Push Distance, Push Left, Ease From and Ease To.\n"
        "2. Press Strips Lie on a Raised Thigh.\n"
        "3. Raise a leg to judge; change the values and press it again.",
        "- Push Distance (0.25): how far the strips are kept off the leg (Auto-Rig Pro's Collide Distance).\n"
        "- Ease From (60 deg) / Ease To (90 deg): the leg swing where the push starts and finishes easing off.\n"
        "- Push Left (0.35): share of the push left at the end angle; 1 keeps Auto-Rig Pro's push.",
        "Raise a thigh to 90 degrees: the front strips rest on it instead of standing toward the chest.",
        "- Only Auto-Rig Pro's own drivers (or ones set here) change; run again with Push Left 1 to go back.",
    ),
    (
        "上げた太ももの前で短冊が立ち上がる時に、作ってあるKiltの短冊を脚からどれだけ離すかを決め、脚が上がるにつれて押しを弱めます。前の短冊が太ももに乗るようになります。作ってあるKiltに使います。",
        "「短冊ボーンを作る」で作ったKilt。上の「名前」にその名前が入っている事。",
        "1. 「押しの距離」「残す押し」「弱め始め」「弱め終わり」を決めます。\n"
        "2. 「上げた太ももに短冊を乗せる」。\n"
        "3. 脚を上げて判断します。値を変えてもう一度押すとやり直せます。",
        "・押しの距離（0.25）：短冊を脚からどれだけ離すか（Auto-Rig ProのCollide Distance）。\n"
        "・弱め始め（60度）／弱め終わり（90度）：押しを弱め始める・弱め終わる脚の振り角。\n"
        "・残す押し（0.35）：終わりの角度で残す押しの割合。1ならAuto-Rig Proの押しのまま。",
        "太ももを90度上げ、前の短冊が胸の方へ立たずに太ももに乗れば完了です。",
        "・変えるのはAuto-Rig Pro自身のドライバー（かここで付けた物）だけです。残す押し1でもう一度実行すると戻ります。",
    ),
),
"hair_follow_strips": (
    "Strips Over a Garment", "別の服に重なる短冊",
    (
        "For a garment lying over another (a coat over a top): strips of controllers that move like the layer underneath and add their own rotation on top, so the coat bends with the top instead of sinking into it. Also makes a cuff follow the wrist bend but not its twist.",
        "Select the part's vertices in Edit Mode. Choose the garment Underneath.",
        "1. Choose Underneath.\n"
        "2. Set Name, Bones, Angles and Top blend mm.\n"
        "3. Press Build Follow Strips.\n"
        "4. For cuffs: select the cuff and press Cuff L Follows the Bend or Cuff R.",
        "- Underneath: the garment this part is worn over.\n"
        "- Name (coat), Bones (2 per strip), Angles (-60, 0, 45, 90, 135, 180, -120; 0 = +X, 90 = back, -90 = front), Top blend mm (40).\n"
        "- Build Follow Strips: each strip bone follows the layer underneath with an Armature constraint weighted like that layer.\n"
        "- Cuff L Follows the Bend / Cuff R: a bend-only bone at the wrist carries the cuff's edge, fading up the sleeve. Share at the Edge (1.0) and Fade mm (140) sit above the buttons.",
        "Bend the torso: the coat follows the top without sinking. Twist the wrist: the cuff stays; bend it: the cuff follows.",
        "- Ctrl+Z right after building.\n"
        "- Keys on the strip controllers add on top of the follow motion.",
    ),
    (
        "別の服の上に重なる服（トップスの上の上着）用です。下の服と同じように動き、その上に自分の回転を足す短冊を作るので、上着は下に沈まずトップスと一緒に曲がります。袖口を手首の曲げには追従させ、ねじりには追従させない事もできます。",
        "編集モードで部品の頂点を選びます。「下の服」を選びます。",
        "1. 「下の服」を選びます。\n"
        "2. 「名前」「段」「角度」「上端のつなぎmm」を決めます。\n"
        "3. 「下に沿う短冊を作る」。\n"
        "4. 袖口：袖口を選び、「左袖口を曲げに沿わせる」か「右袖口」。",
        "・下の服：この部品の下にある服。\n"
        "・名前（coat）、段（1列2個）、角度（-60, 0, 45, 90, 135, 180, -120。0＝＋X、90＝背中、－90＝前）、上端のつなぎmm（40）。\n"
        "・下に沿う短冊を作る：短冊の骨は、下の服と同じウェイトのアーマチュア拘束で下の服に従います。\n"
        "・左袖口を曲げに沿わせる／右袖口：手首に曲げだけの骨を置き、袖口の縁を運んで袖の上へ弱めます。「端の割合」（1.0）と「弱める長さ mm」（140）はボタンの上にあります。",
        "体を曲げて上着がトップスに沈まず、手首をねじって袖口が残り、曲げて袖口がついて来れば完了です。",
        "・作った直後ならCtrl+Zで戻せます。\n"
        "・短冊のコントローラーに打ったキーは、追従の動きの上に足されます。",
    ),
),
"hair_band": (
    "Band Round a Limb", "腕や脚に巻かれた帯",
    (
        "Keeps a band (a belt round a sleeve, a garter) at its width when the elbow or knee bends: every cross row of the band gets the row's average weights and a dual-quaternion Armature modifier. Can also mirror band weights to the other side.",
        "The band is unwrapped as a straight strip in UV. In Edit Mode select one vertex of each band.",
        "1. Choose the UV row direction and Min width mm.\n"
        "2. Press Keep Band Width.\n"
        "3. To copy to the other side: select one vertex of the band on each side, choose the direction, press Mirror Band Weights.",
        "- Band rows: Rows along V (default), Rows along U, or Guess per band.\n"
        "- Min width mm (25): narrower rows (holes, cut ends) join the nearest full row.\n"
        "- Hard parts rigid (on) + material (metal): buckles and studs each locked rigid.\n"
        "- Keep Band Width: averages each row and sets dual quaternion.\n"
        "- Mirror source (Left to right / Right to left) + Mirror Band Weights: copies rows across X = 0, then keeps the width again. Missing mirror bones are reported (add them with Add Adjust Bones).",
        "Bend the elbow: the band keeps its width and does not pinch.",
        "- Ctrl+Z right after.\n"
        "- It does not stop the band from touching the sleeve: use Layers & Penetration for that.",
    ),
    (
        "腕や脚に巻かれた帯（袖のベルト、ガーター）を、肘や膝を曲げても同じ幅に保ちます。帯の横の列ごとに列の平均のウェイトを与え、デュアルクォータニオンのアーマチュアで変形します。帯の重みを反対側へ写す事もできます。",
        "帯はUVでまっすぐな帯に展開しておきます。編集モードで、帯ごとに頂点を1つ選びます。",
        "1. UVの列の向きと「最小幅mm」を選びます。\n"
        "2. 「帯の幅を保つ」。\n"
        "3. 反対側へ写す時：左右それぞれの帯の頂点を1つずつ選び、向きを選んで「帯の重みを左右反転」。",
        "・列の向き：Vで断面（既定）、Uで断面、帯ごとに推定。\n"
        "・最小幅mm（25）：これより狭い列（穴、切れ端）は近くの列にまとめます。\n"
        "・金具は剛体（オン）＋材質（metal）：バックルや鋲を1つずつ固くします。\n"
        "・帯の幅を保つ：列ごとに平均化し、デュアルクォータニオンにします。\n"
        "・写す向き（左から右へ／右から左へ）＋帯の重みを左右反転：X＝0で列を写し、もう一度幅を保ちます。無い鏡の骨は報告します（「加算ボーンを追加」で先に作ります）。",
        "肘を曲げ、帯が細くならず潰れなければ完了です。",
        "・直後ならCtrl+Zで戻せます。\n"
        "・帯が袖に触れるのは止めません。それは「重ね着・めり込み」で行います。",
    ),
),
"hair_hard": (
    "Hard Parts & Bones", "固い部品・骨の族",
    (
        "Makes metal and other hard parts move as one piece, takes bone families (twist, fingers) off a part, and stops a sleeve following the wrist's spin while keeping the arm's bend.",
        "A bound part selected (Object Mode).",
        "1. Hard parts: type the material, optionally the donor surface, press Rigid by Material.\n"
        "2. Families: type the families, press Drop.\n"
        "3. Sleeves: choose Wrist (or Custom) and press Stop Following.",
        "- Material (metal) + Donor (empty) + Rigid by Material: every island of that material gets one weight set, taken from the donor at the contact point (empty for a part on its own chain).\n"
        "- Families (twist) + Drop: takes those bones off and hands the weight up the chain. 'thumb,index,middle,ring,pinky' stops a coat hanging off a finger.\n"
        "- Stop Following: Wrist gives hand, fingers and forearm twist to the forearm. Custom uses the families and the heir bone you type ({side} = l and r).",
        "Pose the wrist and fingers: studs keep their shape, the sleeve keeps the arm's bend without spinning.",
        "- Ctrl+Z right after.\n"
        "- Dropping only part of a family is worse than none: the twist bones blend forearm and hand.",
    ),
    (
        "金具など固い部品を1つの塊として動かし、骨の族（ねじり、指）を部品から外し、袖が手首の回転には追従せず腕の曲げだけ保つようにします。",
        "バインド済みの部品を選びます（オブジェクトモード）。",
        "1. 固い部品：材質を入れ、必要なら土台の面を選び、「材質で剛体化」。\n"
        "2. 族：族の名前を入れ、「外す」。\n"
        "3. 袖：手首（かカスタム）を選び、「追従を切る」。",
        "・材質（metal）＋土台（空）＋材質で剛体化：その材質の島ごとに1つのウェイトを与えます。土台を選べば接点での土台のウェイト（自分の鎖に通した部品なら空）。\n"
        "・族（twist）＋外す：その骨を外し、ウェイトを鎖の上へ渡します。「thumb,index,middle,ring,pinky」で上着が指に引っ掛かるのを止めます。\n"
        "・追従を切る：手首なら手・指・前腕のねじりを前腕へ渡します。カスタムなら入力した族と受け取る骨（{side}はlとr）。",
        "手首と指を動かし、鋲が形を保ち、袖が回転せず腕の曲げを保てば完了です。",
        "・直後ならCtrl+Zで戻せます。\n"
        "・族の一部だけを外すと、外さない時より悪くなります。ねじりの骨は前腕と手のつなぎです。",
    ),
),
"hair_layers": (
    "Layers & Penetration", "重ね着・めり込み",
    (
        "Stops one garment passing through the layer underneath it: binds a part from the layer below, measures how far it sinks during the animation, lifts touching vertices once, or holds the part outside while it deforms.",
        "Select the outer part, choose the layer underneath in the field at the top. For checks, the animation is in place.",
        "1. Press Bind Over Layer.\n"
        "2. Press Check Penetration.\n"
        "3. If it still touches: Clear Contact (once, in the mesh) or Keep Outside (while deforming).",
        "- Underneath field: the layer this part is worn over.\n"
        "- Bind Over Layer: reads the weights of the garment underneath, keeping this part's own chains.\n"
        "- Check Penetration: how far the part sinks into the layer underneath during the animation.\n"
        "- Clearance (1.5 mm) + Clear Contact: lifts only grazing vertices out, once, in the stored mesh.\n"
        "- Keep Outside / X: holds the part outside the layer underneath while it deforms; X removes it.",
        "Check Penetration reports small or no sinking. Play the animation and look at the elbow and hip.",
        "- Ctrl+Z right after; X removes Keep Outside.\n"
        "- Clear Contact changes the modelled shape permanently; save a copy first.",
    ),
    (
        "ある服が下の層をすり抜けないようにします。部品を下の層から結合し、アニメーション中にどれだけ沈むかを測り、触れている頂点を一度だけ持ち上げ、または変形の間ずっと外に保ちます。",
        "外側の部品を選び、一番上の欄で下の層を選びます。検査の時はアニメーションを入れておきます。",
        "1. 「下に合わせる」。\n"
        "2. 「めり込み検査」。\n"
        "3. まだ触れるなら：「接触を逃がす」（メッシュに一度だけ）か「外に保つ」（変形の間ずっと）。",
        "・一番上の欄：この部品の下にある層。\n"
        "・下に合わせる：肌ではなく下の服のウェイトを読み、この部品自身の鎖は残します。\n"
        "・めり込み検査：アニメーション中に下の層へどれだけ沈むかを測ります。\n"
        "・隙間（1.5mm）＋接触を逃がす：かすっている頂点だけを、保存されたメッシュで一度だけ外へ出します。\n"
        "・外に保つ／×：変形の間、下の層の外に保ちます。×で外します。",
        "「めり込み検査」で沈みが小さいか0と出て、アニメーションで肘と腰を見て問題なければ完了です。",
        "・直後のCtrl+Z、「外に保つ」は×で外せます。\n"
        "・「接触を逃がす」は作った形を変えます。先に控えを保存してください。",
    ),
),
})

_SECTION_HELP.update({
"physics": (
    "5. Jiggle, Collision & Cloth", "5. 揺れ・当たり判定・クロス",
    (
        "Step 5. Fits collision capsules to the dressed body, bakes the swing of every chain into ordinary keyframes (each chain keeps the settings it was built with), and adds a cloth alternative for the skirt.",
        "Chains built (section 4) and the body animation in place. The rig set as the target.",
        "1. Collision: choose the outer surfaces and press Fit Capsules.\n"
        "2. Bake Jiggle: press Bake Jiggle.\n"
        "3. Cloth Simulation for the skirt if wanted.\n"
        "4. Check with 6. Animation > Check Motion.",
        "Each subsection has its own ? help:\n"
        "- Collision\n"
        "- Bake Jiggle, with the selected-chain box and the Parts box\n"
        "- Cloth Simulation",
        "Play the animation: hair and straps swing and settle without entering the body.",
        "- Clear Jiggle removes the baked keys; the capsules have their own remove buttons.\n"
        "- Bake again after changing the body animation.",
    ),
    (
        "手順5です。着た状態の体に当たり判定のカプセルを合わせ、全ての鎖の揺れをふつうのキーフレームに焼き（鎖ごとに作った時の設定を使います）、スカートにはクロスの選択肢を付けます。",
        "鎖ができていて（4章）、体のアニメーションが入っている事。リグを対象に設定。",
        "1. 当たり判定：外側の面を選び、「カプセルを合わせる」。\n"
        "2. 揺れを焼く：「揺れを焼く」。\n"
        "3. 必要ならスカートのクロスの選択肢。\n"
        "4. 6章の「動きを検査」で確かめます。",
        "各サブセクションの見出しの？に説明があります：\n"
        "・当たり判定\n"
        "・揺れを焼く（選んだ鎖の枠と、部品の枠を含む）\n"
        "・クロスの選択肢",
        "アニメーションを再生し、髪やストラップが揺れて落ち着き、体に入らなければ良好です。",
        "・「揺れを消す」で焼いたキーを消します。カプセルにはそれぞれ消すボタンがあります。\n"
        "・体のアニメーションを変えたら焼き直します。",
    ),
),
"physics_collide": (
    "Collision", "当たり判定",
    (
        "Fits a light collision capsule to each body part, as bones you can see and drag. The swing bake pushes chains out of them and the cloth lands on the meshes built from them. Fit them to the DRESSED silhouette: capsules fitted to the bare body sit inside the coat, and hair then hangs inside the coat.",
        "Bound body and costumes. Choose up to five outermost surfaces: skin or body, face, coat, top, trousers or skirt.",
        "1. Choose the outer surfaces in the five fields.\n"
        "2. Keep Radius % 90 and Grow 1.05 at first.\n"
        "3. Press Fit Capsules.\n"
        "4. Press Build Meshes if you use cloth.\n"
        "5. Hide the colliders before posing and rendering.",
        "- Outer surfaces 1-5: the fitted shape is read from these.\n"
        "- Radius % (90): which percentile of the skin's distance from the bone becomes the radius (the maximum balloons on one stray vertex).\n"
        "- Grow (1.05): multiplies the fitted radius; below 1 sits inside the skin.\n"
        "- Split Wide (1.25): a part wider than deep by this factor gets two capsules side by side.\n"
        "- Toes (off): capsules on the toes too.\n"
        "- Fit Capsules / X: fit, or delete every capsule.\n"
        "- Part + Fit Without Part: also stores the size without that part; while the part is hidden the capsules switch to it.\n"
        "- Show / Hide Colliders: the bake reads them either way.\n"
        "- Sides (12) + Build Meshes / X: low-poly collision meshes for cloth (more sides = closer to the capsule).\n"
        "- Collide (on), Thickness (4 mm), Quality (2): the chain's own collision in the bake.",
        "Show the colliders: each capsule sits just inside the clothes. After a bake, hair rests on the coat surface.",
        "- X buttons delete the capsules or the meshes.\n"
        "- Fit with the shoe lift cleared.\n"
        "- After changing the costume, fit again.",
    ),
    (
        "体の部位ごとに軽い当たり判定のカプセルを合わせます。カプセルは見えて動かせる骨です。揺れの焼きは鎖をこれから押し出し、クロスはこれから作ったメッシュに当たります。着た状態の外形に合わせてください。裸の体に合わせると上着の内側に入り、髪が上着の中に垂れます。",
        "体と衣装がバインド済み。一番外側の面を5つまで選びます：肌か体、顔、上着、トップス、ズボンかスカート。",
        "1. 5つの欄に外側の面を選びます。\n"
        "2. 最初は「半径%」90、「膨らませ」1.05のままにします。\n"
        "3. 「カプセルを合わせる」。\n"
        "4. クロスを使うなら「判定メッシュ」。\n"
        "5. ポーズ付けやレンダーの前は判定を隠します。",
        "・外側の面1〜5：合わせる形をここから読みます。\n"
        "・半径%（90）：骨から肌までの距離の何パーセンタイルを半径にするか（最大値は外れた1頂点で膨らみます）。\n"
        "・膨らませ（1.05）：合わせた半径に掛けます。1未満なら肌の内側に収まります。\n"
        "・幅広を分割（1.25）：奥行きよりこの倍以上幅のある部位は、カプセルを2つ並べます。\n"
        "・足指（オフ）：足の指にもカプセルを付けます。\n"
        "・カプセルを合わせる／×：合わせる、または全てのカプセルを消します。\n"
        "・部品＋部品を外した判定：その部品を外した時の大きさも覚えます。部品を隠している間はそちらに切り替わります。\n"
        "・判定を表示／判定を隠す：焼きはどちらでも読みます。\n"
        "・面数（12）＋判定メッシュ／×：クロス用の軽い判定メッシュ（面数が多いほどカプセルに近い）。\n"
        "・判定する（オン）、太さ（4mm）、品質（2）：焼きでの鎖自身の当たり。",
        "判定を表示し、各カプセルが服のすぐ内側にあれば完了です。焼いた後、髪が上着の表面に乗ります。",
        "・×ボタンでカプセルやメッシュを消します。\n"
        "・靴底の持ち上げを解除してから合わせます。\n"
        "・衣装を変えたら合わせ直します。",
    ),
),
"physics_jiggle": (
    "Bake Jiggle", "揺れを焼く",
    (
        "Solves the secondary motion of the chains and writes it as ordinary keyframes. It is not a live simulation: the file ends up with bone animation that plays without this add-on, exports anywhere and can be edited by hand. Each chain is baked with the swing settings stored when it was built.",
        "The body animation is in place, the capsules fitted (Collision), the rig set as the target. In Pose Mode select bones of the chains to bake only those; with none selected every chain in the bake is baked over the scene's frame range.",
        "1. Choose Include Selected / Leave Out Selected for chains as needed.\n"
        "2. Set Floor and Height.\n"
        "3. Press Bake Jiggle.\n"
        "4. Play; use Stop Swing / Play Swing to compare.",
        "- Selected-chain box and Parts box: see their own ? help.\n"
        "- Chains (empty): chains by name, separated by commas (*tail* allowed), for the buttons below that say Selected, Swing and Clear. While it is filled, Include Selected and Leave Out Selected become Include Named and Exclude Named. Empty uses the selected bones. It stays in this file and does not carry over to a new one.\n"
        "- Include Selected / Leave Out Selected: whether the selected chains are in the bake.\n"
        "- Stop Swing / Play Swing: switches a baked swing off or on without deleting it.\n"
        "- Arms (Auto), Body + Roll: Open as a Ring / Away from Body: rolls the selected bones so one positive X rotation opens them outward (rest shape and motion unchanged).\n"
        "- Centre on the Midline (on), Along Chains (on): Ring puts its axis on the rig's centre plane; a bone whose parent is selected too carries its parent's outward.\n"
        "- Switch (srs_sim_mode), Value (1) + Add / Remove Swing Layer: the bake writes onto hidden swing bones on top of hand keys, played only while the switch equals Value.\n"
        "- Floor (on), Height (0): keeps every chain above the floor; a chain coming down on it lies along the floor. The parts of the mesh that still follow the parent bone go with the body. A chain already well below the Height at the first frame of the bake is left alone, and the report says so.\n"
        "- Bake Jiggle / Clear Jiggle: bake the scene's frame range, or remove the baked keys. Each chain swings with the Swing setting it was built with.\n"
        "- Clear Prefix (empty), Use Selection (on), Only Baked Keys (on): for Clear Jiggle: which family of chains it looks at; off acts only on Chains above (it is greyed out while Chains is filled); off also removes hand-keyed rotations on the bones the bake writes.",
        "Play the animation: chains swing and settle; they stop at the capsules and the floor.",
        "- Clear Jiggle removes the baked keys (the rig is meant to ship without them unless baked for a shot).\n"
        "- Bake again after any change of the body animation.\n"
        "- Long animations take time; do not touch Blender while it bakes.",
    ),
    (
        "鎖の二次的な動きを解き、ふつうのキーフレームとして書きます。その場のシミュレーションではありません。ファイルに残るのは骨のアニメーションなので、このアドオン無しで再生でき、どこへでも書き出せ、手で直せます。鎖ごとに、作った時に覚えた揺れの設定で焼きます。",
        "体のアニメーションが入り、カプセルを合わせ（当たり判定）、リグを対象に設定。ポーズモードで鎖の骨を選べばその鎖だけ、未選択なら焼きに含まれる全ての鎖を、シーンのフレーム範囲で焼きます。",
        "1. 必要なら「選択を含める」「選択を外す」で鎖を選びます。\n"
        "2. 「床で止める」と「高さ」を決めます。\n"
        "3. 「揺れを焼く」。\n"
        "4. 再生します。「揺れを止める」「揺れを戻す」で比べます。",
        "・選んだ鎖の枠と部品の枠：それぞれの？を見てください。\n"
        "・鎖の名前（空）：コンマ区切りの名前で鎖を指定します（*tail* も可）。下の含める・外す、揺れの止め戻し、揺れの層、揺れを消すに効きます。入力がある間は「選択を含める」「選択を外す」が「名前で含める」「名前で外す」に変わります。空なら選択中の骨を使います。このファイルにだけ残り、新しいファイルへは持ち越しません。\n"
        "・選択を含める／選択を外す：選んだ鎖を焼きに入れるか外すか。\n"
        "・揺れを止める／揺れを戻す：焼いた揺れを、消さずにオフ・オンします。\n"
        "・腕（自動）、体＋向き：輪で外へ／体から外へ：選んだ骨のロールを、X軸の正の回転で外へ開くように直します（静止の形と動きは変わりません）。\n"
        "・体の中心面に置く（オン）、鎖に沿って（オン）：輪の軸をリグの中心面に置く、親も選ばれている骨は親の外向きを受け継ぐ。\n"
        "・切替（srs_sim_mode）、値（1）＋揺れの層を付ける／外す：焼きを隠れた揺れの骨に書き、手のキーの上に足します。切替がその値の時だけ再生します。\n"
        "・床で止める（オン）、高さ（0）：全ての鎖を床より上に保ちます。床に着いた鎖は床に沿って横たわります。メッシュのうち親の骨の重みが残る部分は体と一緒に動きます。焼きの最初のフレームで既に「高さ」より大きく下にある鎖には効かず、そのことを報告します。\n"
        "・揺れを焼く／揺れを消す：シーンのフレーム範囲を焼く、または焼いたキーを消します。揺れ方は、鎖を作った時の「揺れ」の設定に従います。\n"
        "・消す鎖の接頭辞（空）、選択を使う（オン）、焼いたキーだけ（オン）：「揺れを消す」の設定です。見る鎖の系統、オフなら上の「鎖の名前」だけに働く（「鎖の名前」に入力がある時は灰色になります）、オフなら焼きが書く骨の手付けの回転も消す。",
        "アニメーションを再生し、鎖が揺れて落ち着き、カプセルと床で止まれば完了です。",
        "・「揺れを消す」で焼いたキーを消します。\n"
        "・体のアニメーションを変えたら焼き直します。\n"
        "・長いアニメーションは時間が掛かります。焼いている間はBlenderを触らないでください。",
    ),
),
"physics_jiggle_chain": (
    "Selected chain", "選んだ鎖",
    (
        "Shows and changes the swing settings of the one chain whose bone is active, stored on its root bone so every re-bake repeats them.",
        "Pose Mode, an active bone of a built chain on the target rig. The box appears only then.",
        "1. Click a bone of the chain.\n"
        "2. Change the values and the toggles.\n"
        "3. Bake again (Bake Jiggle).",
        "- Stiffness, Damping, Weight, Drag: the stored swing values of this chain.\n"
        "- In the bake / Baked swing / Collision / Swing layer: status lines of this chain.\n"
        "- Gravity: From Rest Shape (keeps the modelled curl when still) or Straight Down.\n"
        "- Thickness: Percentile (0.90), then Measure (collide at the thickness of the mesh it carries; Percentile is the share of its vertices inside) or Clear (back to a line).\n"
        "- Entry: Push on Entry (a fast body cannot sink in) or Ease Out.\n"
        "- Capsules: Keep Rest Clear (shrink capsules for this chain just enough to clear its rest pose) or Full Size.\n"
        "- Collision: Panel (follow the panel), On, Off.",
        "Bake again and play: the chain behaves with the new values.",
        "- Each toggle has its opposite button; values can be typed back.\n"
        "- Changes act only at the next bake.",
    ),
    (
        "アクティブな骨が属する1本の鎖の揺れの設定を表示・変更します。設定は根元の骨に覚えるので、焼き直しても同じになります。",
        "ポーズモードで、対象リグの作った鎖の骨がアクティブな事。その時だけこの枠が出ます。",
        "1. 鎖の骨をクリックします。\n"
        "2. 値と切り替えを変えます。\n"
        "3. もう一度焼きます（揺れを焼く）。",
        "・剛性、減衰、重さ、ドラッグ：この鎖に覚えた揺れの値。\n"
        "・焼きに含める／焼いた揺れ／判定／揺れの層：この鎖の状態の行。\n"
        "・重力：静止の形から（止まっている時に作った巻きを保つ）か真下へ。\n"
        "・太さ：割合（0.90）、測る（運ぶメッシュの太さで当たる。割合はその内側に入れる頂点の割合）か消す（線に戻す）。\n"
        "・入り込み：すぐ押し出す（速い体が入り込まない）かゆっくり抜く。\n"
        "・カプセル：静止を避ける（この鎖のためだけに、静止の形が当たらない分だけ縮める）かそのまま。\n"
        "・判定：パネル（パネルの設定に従う）、する、しない。",
        "焼き直して再生し、新しい値で動けば完了です。",
        "・切り替えには反対のボタンがあり、値は入れ直せます。\n"
        "・変更は次に焼いた時に効きます。",
    ),
),
"physics_parts": (
    "Parts: Sim or Hand", "部品：シミュか手付けか",
    (
        "Switches named parts between simulation (the baked swing plays on top of any hand keys) and hand animation (the links show only their own keys), and bakes a part with its chains' stored settings. The choice is saved with the file.",
        "The chains of the part already built. The rig is set as the target.",
        "1. Name the chains in Chains below, or select a bone of each in Pose Mode.\n"
        "2. Type a Part Name and press Register: the part gets its own row.\n"
        "3. Press the key button to bake that part and switch it to Sim.\n"
        "4. Press Sim or Hand to switch.",
        "- Part Name + Register: makes the part switchable. Its chains get a swing layer on one switch on the rig, and a bake they already have moves onto it. Registering the same name again replaces it: a chain left out loses its layer and baked swing. A chain held by another part moves to this one.\n"
        "- Sim / Hand: the motion source of the part.\n"
        "- X: takes the part off the rig: its row, its switch, its swing layers and the baked swing. Hand keys stay.\n"
        "- Key button: Bake Part (with each chain's stored settings). Bake Start / Bake End (0): the frames; 0 uses the scene's.\n"
        "- A red line 'Action slot unknown' means nothing can be switched: assign the rig's action first.",
        "Play: a Sim part swings, a Hand part shows only your keys.",
        "- Press the other button to switch back; hand keys are never overwritten.",
    ),
    (
        "名前の付いた部品を、シミュレーション（焼いた揺れを手のキーの上で再生）と手付け（リンクは自分のキーだけ）の間で切り替え、部品を鎖の設定で焼きます。選択はファイルに保存されます。",
        "部品の鎖を作ってあること。リグを対象に設定します。",
        "1. 下の「鎖の名前」に鎖を入れるか、ポーズモードで各鎖の骨を選びます。\n"
        "2. 「部品名」を入れて「登録」を押すと、部品の行ができます。\n"
        "3. キーのボタンで、その部品を焼いてシミュに切り替えます。\n"
        "4. 「シミュ」か「手付け」で切り替えます。",
        "・部品名＋登録：部品を切り替えられるようにします。鎖に揺れの層が付き、リグに切替のプロパティが 1 つできます。先に焼いた揺れは、そのまま層へ移ります。同じ名前で押すと置き換わり、入れなかった鎖の層と焼いた揺れは消えます。別の部品の鎖を入れると、こちらへ移ります。\n"
        "・シミュ／手付け：部品の動きの元。\n"
        "・×：部品をリグから外します。行、切替、揺れの層、焼いた揺れが消えます。手のキーは残ります。\n"
        "・キーのボタン：部品を焼く（鎖ごとに覚えた設定で）。焼きの開始／終了（0）：フレーム。0ならシーンの範囲。\n"
        "・「アクションのスロットが不明」と赤く出たら切り替えられません。先にリグのアクションを割り当てます。",
        "再生して、シミュの部品が揺れ、手付けの部品は自分のキーだけで動けば完了です。",
        "・もう一方のボタンで戻ります。手のキーは上書きされません。",
    ),
),
"physics_cloth": (
    "Cloth Simulation", "クロスの選択肢",
    (
        "Gives the selected garment (the skirt) a cloth solver as well as its skin weights, and one property on the rig to choose between them. Only the skirt switches between bones and cloth; everything else swings on bones. The cloth comes after the Armature modifier, pinned at the waistband, so it inherits the bone motion.",
        "Select the skirt mesh (bound). Optionally choose the meshes it lands on.",
        "1. Set Pinned mm and Fade mm.\n"
        "2. Choose Lands On (usually the body) and Also Lands On (for example shorts).\n"
        "3. Press Add Cloth Alternative.\n"
        "4. Press a Skirt button: 0 bones, 1 cloth.",
        "- Pinned mm (45): how far down from the top edge stays pinned to the bones.\n"
        "- Fade mm (35): how far the pin fades out (a hard edge creases the waistband).\n"
        "- Lands On / Also Lands On: meshes the cloth collides with (empty = none).\n"
        "- Only These (on): collide only with these, not with the hair capsules.\n"
        "- Skirt buttons: one per state of the switch on the rig (or its c_traj bone); the pressed one is the current state. Shown once the cloth is set up (0 bones / 1 cloth), or when the rig already has its own skirt_mode, such as MIK's 0 5-H / 1 cloth P2 / 2 bone gravity swing; the names come from that property's description. A button writes the value and updates the drivers at once.\n"
        "- Remove Cloth: takes the solver and switch off; the weights and the pin group stay.",
        "Set the switch to 1 and play from the first frame: the skirt falls and drapes; at 0 it is exactly the bone result.",
        "- Remove Cloth returns to the bone-driven result exactly.\n"
        "- Cloth needs a cache and plays from the start frame; it is heavier than bones.",
    ),
    (
        "選んだ服（スカート）に、肌のウェイトに加えてクロスのソルバーを付け、リグに両者を選ぶプロパティを1つ付けます。ボーンとクロスを切り替えるのはスカートだけで、他は全てボーンで揺らします。クロスはアーマチュアの後に置き、腰帯で固定するので、ボーンの動きを受け継ぎます。",
        "バインド済みのスカートのメッシュを選びます。必要なら当たる相手のメッシュも選びます。",
        "1. 「固定mm」と「減衰mm」を決めます。\n"
        "2. 「当たる相手」（普通は体）と「もう一つの相手」（例：スカートの下のショーツ）を選びます。\n"
        "3. 「クロスの選択肢を追加」。\n"
        "4. スカートのボタンを押します。0がボーン、1がクロス。",
        "・固定mm（45）：上端から何mmまでボーンに固定するか。\n"
        "・減衰mm（35）：固定を弱めていく距離（急に切ると腰帯にしわが出ます）。\n"
        "・当たる相手／もう一つの相手：クロスが当たるメッシュ（空なら無し）。\n"
        "・この相手だけ（オン）：髪のカプセルには当たらず、ここで選んだ物だけに当たります。\n"
        "・スカートのボタン：リグ（か c_traj ボーン）の切り替えの状態ごとに 1 つ。押されているのが今の状態です。クロスを設定した後（0 ボーン／1 クロス）か、リグが自分の skirt_mode を持つ時（MIK なら 0 5-H／1 クロス P2／2 骨の重力揺れ）に出ます。名前はそのプロパティの説明から取ります。押すと値を書き、ドライバーをすぐ更新します。\n"
        "・クロスを外す：ソルバーと切り替えを外します。ウェイトと固定のグループは残ります。",
        "切り替えを1にして最初のフレームから再生し、スカートが落ちて垂れれば完了です。0ではボーンの結果と全く同じです。",
        "・「クロスを外す」でボーンの結果へ正確に戻ります。\n"
        "・クロスはキャッシュが要り、開始フレームから再生します。ボーンより重いです。",
    ),
),
"animation": (
    "6. Animation", "6. アニメーション",
    (
        "Step 6. Switches arms and legs between IK and FK while keeping the pose (switch keys are steps), runs Auto-Rig Pro's snap and pose utilities, and loads motion capture to test the rig. Run Check Motion after every rig change.",
        "A finished rig. Auto-Rig Pro's rig tools available for IK/FK and snapping.",
        "1. IK/FK and snapping while animating.\n"
        "2. Motion Capture: Load & Bake a test clip.\n"
        "3. Check Motion and fix where it points.",
        "Each subsection has its own ? help:\n"
        "- IK/FK and snapping\n"
        "- Motion Capture",
        "Check Motion names no collapsed or stretched vertex group, and switching IK/FK does not move the hand or foot.",
        "- Ctrl+Z after each operation; a loaded clip can be removed with its action.",
    ),
    (
        "手順6です。姿勢を保ったまま腕と脚のIKとFKを切り替え（切替キーは段階補間）、Auto-Rig Proのスナップとポーズの道具を使い、モーションキャプチャーを読み込んでリグを試します。リグを変えるたびに「動きを検査」を実行します。",
        "仕上がったリグ。IK/FKとスナップには、Auto-Rig Proのリグツールが使える事。",
        "1. アニメーション中にIK/FKとスナップ。\n"
        "2. モーションキャプチャー：試しのクリップを「読込んで焼く」。\n"
        "3. 「動きを検査」で、出た場所を直します。",
        "各サブセクションの見出しの？に説明があります：\n"
        "・IK/FKとスナップ\n"
        "・モーションキャプチャー",
        "「動きを検査」で潰れ・伸びの頂点グループが出ず、IK/FKを切り替えても手足が動かなければ良好です。",
        "・各操作の後はCtrl+Zで戻せます。読み込んだクリップは、そのアクションを消せば外れます。",
    ),
),
"anim_ikfk": (
    "IK/FK and snapping", "IK/FKとスナップ",
    (
        "Switches the selected arms and legs between IK and FK with Auto-Rig Pro's own snap, keeping the pose, and keys the switch as a step so the limb is never half IK and half FK between keys. Also runs Auto-Rig Pro's snaps, pose reset and root-motion tools safely.",
        "Pose Mode with a controller of the limb selected. Auto-Rig Pro's rig tools available (otherwise a red line appears).",
        "1. Select the limb's controller.\n"
        "2. Press Switch IK/FK (keep pose).\n"
        "3. Once per shot, press Make IK/FK Keys Steps.",
        "- Switch IK/FK (keep pose) + Key (off): off keys only with Auto Keying, like Auto-Rig Pro; on always keys the current frame.\n"
        "- Make IK/FK Keys Steps: makes every existing switch key a step.\n"
        "- Operation + Run IK/FK: Arm FK to IK, Arm IK to FK, Leg FK to IK, Leg IK to FK.\n"
        "- Snap + Run Snap: Head Lock, Pole Control, Pin Control, Reversed Spine.\n"
        "- Reset Pose, Extract Root Motion, Clear Root Motion: Auto-Rig Pro utilities.",
        "After switching, the hand or foot stays exactly where it was; between keys the limb never blends.",
        "- Ctrl+Z right after.\n"
        "- A smooth switch key blends IK and FK between keys and drags the hand off its animation; that is why steps are used.",
    ),
    (
        "選んだ腕と脚を、Auto-Rig Pro自身のスナップで姿勢を保ったままIKとFKの間で切り替え、切替キーを段階補間で打つので、キーの間で半分IK・半分FKになりません。Auto-Rig Proのスナップ、ポーズのリセット、ルートモーションの道具も安全に呼びます。",
        "ポーズモードで、その手足のコントローラーを選びます。Auto-Rig Proのリグツールが使える事（無い時は赤い行が出ます）。",
        "1. 手足のコントローラーを選びます。\n"
        "2. 「IK/FKを切り替え（姿勢を保つ）」。\n"
        "3. ショットごとに一度「IK/FKの切替キーを段階補間にする」。",
        "・IK/FKを切り替え（姿勢を保つ）＋キー（オフ）：オフなら自動キーの時だけ打ちます（Auto-Rig Proと同じ）。オンなら必ず今のフレームに打ちます。\n"
        "・IK/FKの切替キーを段階補間にする：今ある切替キーを全て段階補間にします。\n"
        "・操作＋IK/FKを実行：腕 FKからIK、腕 IKからFK、脚 FKからIK、脚 IKからFK。\n"
        "・スナップ＋スナップを実行：ヘッドロック、ポール、ピン、逆背骨。\n"
        "・ポーズをリセット、ルートモーション抽出、ルートモーションをクリア：Auto-Rig Proの道具。",
        "切り替えた後も手や足が全く同じ場所にあり、キーの間で混ざらなければ完了です。",
        "・直後ならCtrl+Zで戻せます。\n"
        "・滑らかな切替キーはキーの間でIKとFKを混ぜ、手をアニメーションから外します。段階補間にするのはそのためです。",
    ),
),
"anim_shoulder_limit": (
    "Shoulder Limit", "肩の上がりを制限",
    (
        "Keeps each shoulder (c_shoulder) at or below its default pose while the FK arm is at or below the horizontal T-pose line, and lets it rise only in proportion once the arm goes above that line. It is built into the rig, so motion capture and hand keys both obey it; forward and back swing and twist of the shoulder are left as they are.",
        "An Auto-Rig Pro rig with c_shoulder and c_arm_fk on each side, arms in FK (motion capture bakes onto FK). Pick the rig in the panel or make it the active object.",
        "1. Set Lift Per Degree and Soft Start if the defaults do not suit.\n"
        "2. Press Limit The Shoulders.\n"
        "3. Play the shot and look at the shoulders from the front.",
        "- Lift Per Degree (0.5): how many degrees the shoulder may rise per degree the arm is above the horizontal.\n"
        "- Soft Start (10 degrees): the limit grows from zero over this many degrees, so the motion does not jump at the line.\n"
        "- Limit The Shoulders: adds one Limit Rotation (SRS Shoulder Limit) per c_shoulder, driven by the arm. Pressing it again replaces it with the current settings.\n"
        "- Remove: takes the limits and their drivers off. The shoulder keys are untouched.",
        "The line under the buttons reads On with both shoulders. With the arms below the horizontal the shoulders no longer ride above their default height.",
        "- Ctrl+Z right after, or Remove.\n"
        "- IK arms: the limit switches itself off while the arm is in IK (it follows the IK/FK switch), because reading an IK arm's direction would make a dependency cycle.\n"
        "- The rig's bones and weights are not changed; only a constraint is added, so no reweighting is needed.",
    ),
    (
        "腕（FK）が水平なTポーズの線以下にある間は、肩（c_shoulder）をデフォルトの姿勢より上に上げず、腕が線より上へ上がった時だけ、上がった分に比例して上げてよいことにします。リグに組み込むので、モーションキャプチャーにも手付けのキーにも効きます。肩の前後の振りとねじりはそのまま残します。",
        "左右に c_shoulder と c_arm_fk がある Auto-Rig Pro のリグで、腕がFKである事（モーションキャプチャーはFKに焼きます）。リグはパネルで選ぶか、アクティブにします。",
        "1. 既定が合わなければ「腕1度あたりの上がり」と「なめらかな立ち上がり」を変えます。\n"
        "2. 「肩を制限」を押します。\n"
        "3. ショットを再生し、正面から肩を見ます。",
        "・腕1度あたりの上がり（0.5）：腕が水平より1度上がるごとに、肩が上がってよい角度です。\n"
        "・なめらかな立ち上がり（10度）：制限がこの角度をかけて0から増えるので、線の所で動きが跳ねません。\n"
        "・肩を制限：c_shoulder ごとに回転制限（SRS Shoulder Limit）を1つ足し、腕の角度で動かします。もう一度押すと今の設定で入れ直します。\n"
        "・外す：制限とそのドライバーを外します。肩のキーはそのままです。",
        "ボタンの下の行に「入」と左右の肩が出て、腕が水平より下の間は肩がデフォルトの高さより上がらなければ完了です。",
        "・直後ならCtrl+Z、または「外す」で戻せます。\n"
        "・IKの腕：IK/FKの切り替えに合わせ、腕がIKの間は制限が切れます。IKの腕の向きを読むと依存の循環になるためです。\n"
        "・リグの骨とウェイトは変えず、コンストレイントを足すだけなので、ウェイトの再設定は要りません。",
    ),
),
"anim_mocap": (
    "Motion Capture", "モーションキャプチャー",
    (
        "Loads a .bvh or .fbx motion clip and bakes it onto this rig's controllers in one step with a written-out bone map, then measures every bound mesh across the motion and names the vertex groups whose edges collapse or stretch: that is where the rig is actually wrong.",
        "A finished rig as the target. A clip file: CMU (BVH) or HumanIK / Mixamo naming. The CMU database is free for any use and its range-of-motion clips test a rig hard.",
        "1. Choose the file.\n"
        "2. Choose the skeleton preset and To (last frame, 0 = whole clip).\n"
        "3. Press Load & Bake.\n"
        "4. Set Every and press Check Motion.",
        "- File: the .bvh / .fbx clip.\n"
        "- Skeleton: CMU (BVH, default), HumanIK / Mixamo (prefixes like mixamorig: are ignored), Auto (guess; not recommended, guesses go silently wrong).\n"
        "- To (0): last frame to bake.\n"
        "- Fingers (off): map finger channels too (two-joint captures bend full finger rigs).\n"
        "- Load & Bake: import and bake onto the controllers.\n"
        "- Every (8) + Check Motion: samples every Nth frame and reports collapsing or stretching groups.",
        "Play the clip: the rig moves like the capture. Check Motion lists few or no bad groups; fix those areas first.",
        "- Ctrl+Z right after loading, or delete the created action.\n"
        "- Check Motion changes nothing.",
    ),
    (
        ".bvhか.fbxのモーションを読み込み、書き出したボーンの対応表で、このリグのコントローラーへ一度に焼きます。その後、動きの間の全てのバインド済みメッシュを測り、辺が潰れる・伸びる頂点グループの名前を出します。そこが本当にリグの悪い所です。",
        "仕上がったリグを対象に設定。クリップのファイル：CMU（BVH）か、HumanIK／Mixamoの名前。CMUのデータベースは自由に使え、可動域のクリップはリグをよく試せます。",
        "1. ファイルを選びます。\n"
        "2. 骨格のプリセットと「終」（最後のフレーム。0で全体）を選びます。\n"
        "3. 「読込んで焼く」。\n"
        "4. 「間隔」を決めて「動きを検査」。",
        "・ファイル：.bvh／.fbxのクリップ。\n"
        "・骨格：CMU（BVH、既定）、HumanIK／Mixamo（mixamorig:などの頭は無視）、自動（推測。名前の推測は黙って間違うので非推奨）。\n"
        "・終（0）：焼く最後のフレーム。\n"
        "・指も（オフ）：指のチャンネルも対応させます（2関節の収録は指のリグを曲げてしまいます）。\n"
        "・読込んで焼く：読み込んでコントローラーへ焼きます。\n"
        "・間隔（8）＋動きを検査：Nフレームごとに測り、潰れ・伸びのグループを報告します。",
        "クリップを再生し、リグが収録と同じに動けば読み込み完了です。「動きを検査」の悪いグループが少ないか0なら良好です。出た所から直します。",
        "・読み込みの直後はCtrl+Zか、作られたアクションを消して戻します。\n"
        "・「動きを検査」は何も変えません。",
    ),
),
"proxy": (
    "Display, Selection & Rig UI", "表示・選択・リグUI",
    (
        "Works with the separately installed Proxy Picker: assigns proxy bones, adds script and bone-collection buttons, pairs proxies by name, and backs up, checks and repairs the mappings.",
        "Proxy Picker installed and enabled (otherwise a red line appears and the assignment buttons are greyed out). The rig with proxy bones.",
        "1. Proxy Picker Workflow: assign or batch pair.\n"
        "2. Mapping Backup & Check: audit, repair, export a backup.",
        "Each subsection has its own ? help:\n"
        "- Proxy Picker Workflow\n"
        "- Mapping Backup & Check",
        "Click a proxy in the viewport: the target bones are selected. The audit finds no issue.",
        "- Smart Rig calls Proxy Picker's own operators; it does not replace them.",
    ),
    (
        "別に導入したProxy Pickerと連携します。プロキシの骨の割り当て、スクリプトとボーンコレクションのボタンの追加、名前での一括ペア、対応のバックアップ・検証・修復を行います。",
        "Proxy Pickerを導入して有効にする事（無い時は赤い行が出て、割り当てのボタンが灰色になります）。プロキシの骨のあるリグ。",
        "1. Proxy Pickerワークフロー：割り当てか一括ペア。\n"
        "2. 対応のバックアップ・検証：監査、修復、バックアップの書き出し。",
        "各サブセクションの見出しの？に説明があります：\n"
        "・Proxy Pickerワークフロー\n"
        "・対応のバックアップ・検証",
        "ビューポートでプロキシをクリックし、対象の骨が選ばれれば良好です。監査で問題が出ません。",
        "・Smart RigはProxy Pickerの自分の操作を呼ぶだけで、置き換えません。",
    ),
),
"proxy_roles": (
    "Proxy Picker Workflow", "Proxy Pickerワークフロー",
    (
        "Assigns Proxy Picker roles from Smart Rig with the context checked first: a proxy bone that selects target bones, a script button, a bone-collection toggle, or many proxy pairs at once by name.",
        "Pose Mode. For Assign Proxy: the proxy bone active and the target bones selected. Proxy Picker enabled.",
        "1. Select targets, then the proxy (active).\n"
        "2. Press Assign Proxy (or Add Script Button).\n"
        "3. For many pairs: set Proxy and Target prefixes, press Batch Pair by Name.",
        "- Assign Proxy / Add Script Button / Delete Role: Proxy Picker's own operators for the active bone.\n"
        "- Set Bone Collection Button: the active pose bone toggles a named Bone Collection (Blender 5.1).\n"
        "- Proxy (proxy_) / Target (c_): prefixes used to pair proxy_arm.L with c_arm.L.\n"
        "- Batch Pair by Name: pairs every valid proxy with its target.",
        "Click the proxy: its targets are selected (or the collection toggles).",
        "- Delete Role removes the role from the active bone; Ctrl+Z also works.\n"
        "- The Proxy Picker runtime guard is switched in Always-on Toggles of the N-panel, not in the preferences.",
    ),
    (
        "文脈を先に確かめてから、Smart RigからProxy Pickerの役割を割り当てます。対象の骨を選ぶプロキシ、スクリプトのボタン、ボーンコレクションの切り替え、名前による多数のペアを一度に。",
        "ポーズモード。「プロキシ割り当て」では、プロキシの骨をアクティブにし、対象の骨を選びます。Proxy Pickerが有効。",
        "1. 対象を選び、最後にプロキシを選びます（アクティブ）。\n"
        "2. 「プロキシ割り当て」（か「スクリプトボタン追加」）。\n"
        "3. 多数のペア：「プロキシ」「ターゲット」の接頭辞を入れ、「名前規則で一括ペア設定」。",
        "・プロキシ割り当て／スクリプトボタン追加／役割を削除：アクティブな骨に、Proxy Pickerの操作を行います。\n"
        "・ボーンコレクションボタン設定：アクティブなポーズボーンで、名前のボーンコレクションを切り替えます（Blender 5.1）。\n"
        "・プロキシ（proxy_）／ターゲット（c_）：proxy_arm.Lとc_arm.Lを組にする接頭辞。\n"
        "・名前規則で一括ペア設定：有効なプロキシを全て対象と組にします。",
        "プロキシをクリックし、対象が選ばれれば（かコレクションが切り替われば）完了です。",
        "・「役割を削除」でアクティブな骨の役割を外します。Ctrl+Zでも戻せます。\n"
        "・Proxy Pickerランタイム保護は、プリファレンスではなくNパネルの「常時機能切り替え」で切り替えます。",
    ),
),
"proxy_audit": (
    "Mapping Backup & Check", "対応のバックアップ・検証",
    (
        "Checks the Proxy Picker mappings for missing bones, texts and collections, malformed lists and conflicting roles; repairs only broken references; and exports or imports the mappings as JSON for backup or transfer.",
        "The rig with Proxy Picker mappings active.",
        "1. Press Audit.\n"
        "2. Press Repair Stale if broken references are reported.\n"
        "3. Press Export Proxy Map to keep a backup.",
        "- Audit: lists missing target bones, missing text blocks or collections, malformed lists and conflicting roles.\n"
        "- Repair Stale: removes only broken references; valid mappings stay.\n"
        "- Proxy Map Text (Smart Rig Proxy Map): the Text used for export and import.\n"
        "- Export / Import Proxy Map: write the mapping to JSON, or apply one to matching bones (missing bones are reported).",
        "A second Audit reports 0 issues.",
        "- Import a previous export to go back; Ctrl+Z after Repair.",
    ),
    (
        "Proxy Pickerの対応を、無い骨・Text・コレクション、壊れたリスト、役割の競合について調べ、壊れた参照だけを直し、バックアップや移し替えのためにJSONで書き出し・読み込みます。",
        "Proxy Pickerの対応を持つリグをアクティブにします。",
        "1. 「監査」。\n"
        "2. 壊れた参照が出たら「古い参照を修復」。\n"
        "3. 「プロキシ対応を書き出し」でバックアップを残します。",
        "・監査：無い対象の骨、無いTextやコレクション、壊れたリスト、役割の競合を報告します。\n"
        "・古い参照を修復：壊れた参照だけを消します。有効な対応は残ります。\n"
        "・プロキシ対応Text（Smart Rig Proxy Map）：書き出しと読み込みに使うText。\n"
        "・プロキシ対応を書き出し／読み込み：対応をJSONへ書くか、合う骨に当てます（無い骨は報告）。",
        "2回目の監査で問題0なら完了です。",
        "・前に書き出した物を読み込めば戻ります。修復の後はCtrl+Zでも戻せます。",
    ),
),
"ai": (
    "AI Runtime Integration", "AIランタイム連携",
    (
        "Sets up and checks the external AI_win runtime that Auto-Rig Pro uses for marker estimation, gives its folder to Auto-Rig Pro, and starts the body, finger and facial marker estimation.",
        "AI_win 1.20 or newer extracted to its own folder (containing info.dat and inference). Windows x64 to run it. Auto-Rig Pro enabled.",
        "1. Choose the AI Runtime Path, or press Auto-detect.\n"
        "2. Press Validate.\n"
        "3. Press Synchronize to Auto-Rig Pro.\n"
        "4. Select the body mesh and press Body, Fingers or Facial.",
        "- AI Runtime Path: the AI_win root folder.\n"
        "- Status row: version, runtime valid, older than 1.20, or incomplete.\n"
        "- Auto-detect: searches the path and Auto-Rig Pro preferences.\n"
        "- Validate: checks info.dat, the inference folder, executables and models.\n"
        "- Synchronize to Auto-Rig Pro: sets Auto-Rig Pro's AI path preference.\n"
        "- Open Folder: opens the runtime folder.\n"
        "- Synchronize validated AI path automatically (on): before each AI run.\n"
        "- Body / Fingers / Facial: start Auto-Rig Pro's marker estimation.",
        "The status shows the version with a check mark, and markers appear after estimation.",
        "- Nothing is extracted or copied; only Auto-Rig Pro's path preference is changed.",
    ),
    (
        "Auto-Rig Proがマーカー推定に使う外部のAI_winランタイムを設定・検証し、そのフォルダーをAuto-Rig Proへ渡し、体・指・顔のマーカー推定を始めます。",
        "AI_win 1.20以降を自分のフォルダーに展開しておきます（info.datとinferenceを含む）。実行はWindows x64。Auto-Rig Proが有効。",
        "1. 「AIランタイムパス」を選ぶか「自動検出」。\n"
        "2. 「検証」。\n"
        "3. 「Auto-Rig Proへ同期」。\n"
        "4. 素体メッシュを選び、「ボディ」「指」「フェイシャル」。",
        "・AIランタイムパス：AI_winの一番上のフォルダー。\n"
        "・状態の行：版、ランタイム有効、1.20未満、または不完全。\n"
        "・自動検出：パスとAuto-Rig Proの設定から探します。\n"
        "・検証：info.dat、inferenceフォルダー、実行ファイル、モデルを調べます。\n"
        "・Auto-Rig Proへ同期：Auto-Rig ProのAIパスの設定を書き換えます。\n"
        "・フォルダーを開く：ランタイムのフォルダーを開きます。\n"
        "・検証済みAIパスを自動同期（オン）：AIを動かす直前に同期します。\n"
        "・ボディ／指／フェイシャル：Auto-Rig Proのマーカー推定を始めます。",
        "状態に版とチェックが出て、推定の後にマーカーが現れれば完了です。",
        "・展開やコピーはしません。変えるのはAuto-Rig ProのAIパスの設定だけです。",
    ),
),
"data": (
    "Data, Validation & Settings", "データ・検証・設定",
    (
        "Runs the complete workflow audit, exports a JSON report of the external tools and the scene, and cleans data left by old Smart Rig Suite 1.x builds.",
        "Open the file with the character. For the cleanup, only files made with Smart Rig Suite 1.x need it.",
        "1. Press Full Rig Workflow Audit and read the Text named in Last report.\n"
        "2. Optional: set JSON Report Path and press Export Integration Report.\n"
        "3. Old files only: Clean Legacy Embedded Data.",
        "- Full Rig Workflow Audit: a Text report on external tools, AI runtime, markers, armatures, invalid drivers, broken constraints, Proxy Picker mappings and mesh weights.\n"
        "- Last report: the Text of the latest report.\n"
        "- JSON Report Path (//smart_rig_suite_report.json): // is the .blend's folder.\n"
        "- Export Integration Report: versions, paths and an audit summary as UTF-8 JSON.\n"
        "- Clean Legacy Embedded Data: removes only Smart Rig Suite 1.x helper objects and obsolete scene properties. It never removes external Auto-Rig Pro or Proxy Picker data.",
        "The report Text opens in the Text Editor; the JSON file exists at the path.",
        "- Reports change nothing. The cleanup can be undone with Ctrl+Z right after.",
    ),
    (
        "ワークフローの総合監査を行い、外部ツールとシーンのJSONレポートを書き出し、古いSmart Rig Suite 1.xが残したデータを整理します。",
        "キャラクターのファイルを開きます。整理は、Smart Rig Suite 1.xで作ったファイルにだけ必要です。",
        "1. 「リグワークフロー総合監査」を押し、「最新レポート」に出たTextを読みます。\n"
        "2. 必要なら「JSONレポートパス」を決めて「連携レポートを書き出し」。\n"
        "3. 古いファイルだけ：「旧内蔵版データを整理」。",
        "・リグワークフロー総合監査：外部ツール、AIランタイム、マーカー、アーマチュア、無効なドライバー、壊れた拘束、Proxy Pickerの対応、メッシュのウェイトのTextレポート。\n"
        "・最新レポート：最新のレポートのText。\n"
        "・JSONレポートパス（//smart_rig_suite_report.json）：//は.blendのフォルダー。\n"
        "・連携レポートを書き出し：版、パス、監査の要約をUTF-8のJSONで書きます。\n"
        "・旧内蔵版データを整理：Smart Rig Suite 1.xの補助オブジェクトと古いシーンのプロパティだけを消します。外部のAuto-Rig ProやProxy Pickerのデータは消しません。",
        "レポートのTextがテキストエディターで開け、パスにJSONファイルがあれば完了です。",
        "・レポートは何も変えません。整理は直後ならCtrl+Zで戻せます。",
    ),
),
"data_compare": (
    "Compare Two", "2 つを比べる",
    (
        "Compares two states of a scene and counts what differs: every ID (objects, meshes, armatures, actions, materials, node groups, the scene itself and the rest) property by property, and the evaluated shape of the meshes in millimetres. The comparison runs in a separate background Blender, so this one stays usable, and your .blend is never saved or changed.",
        "Either take a snapshot before you change the scene, or have the other .blend at hand. To measure the shape of particular meshes, select them; with nothing selected, every mesh bound to an armature is measured. Both sides are compared at the current frame.",
        "1. Before the change: press Take A Snapshot.\n"
        "2. Make the change. To compare with another file instead, choose it in Other File.\n"
        "3. Press Compare. The line under the button shows how far it has got; press the button again to stop.\n"
        "4. Read the line, then press Write The Result for the full list.",
        "- Take A Snapshot: saves a copy of the scene as it is now into the add-on's own folder. The next snapshot replaces it.\n"
        "- Other File (empty): a .blend to compare against. Empty: the snapshot (first) against this scene now (second). Chosen: this scene now (first) against that file (second).\n"
        "- Compare / Stop: starts the comparison; while it runs the same button stops it.\n"
        "- Skip (14 names): property names left out because Blender rewrites them by itself, such as session_uid and is_dirty.\n"
        "- Digits (7): decimal places a number is rounded to before comparing, so float noise is not counted as an edit.\n"
        "- Result Folder (//): where the files go; // is the folder of this .blend.\n"
        "- Write The Result: srs_compare_<date>_<time>.json with every differing row, and a .md of the same name to read.",
        "The line reads Changed IDs with the three commonest types, Added (only in the second) and Removed (only in the first), the largest shape difference in mm and the evaluated pose rows with their largest difference. With nothing changed it reads No difference with the number of IDs compared. In the Markdown file each changed ID lists its rows as first -> second: constraint:<bone> counts the constraint rows of one bone, runtime_pose_eval the evaluated bone matrices that follow from other changes.",
        "- Nothing to undo: no data is written into the scene.\n"
        "- The snapshot and the run files live in the extension's user folder (extensions\\.user\\...\\compare); deleting that folder removes them.\n"
        "- Collections over 4000 items, such as vertices, are counted rather than listed. Mesh positions, UVs, weights, shape keys and animation curves are compared by a hash of their contents: the rows say that they differ, the shape line says by how much.\n"
        "- A struct kept somewhere else (a bone's parent, a custom shape transform, a link's node) is written as REF: with its path instead of being compared twice, so each change is listed once, under its owner. Lists Blender works out by itself (every object of the scene, the dependency graph) are left out.\n"
        "- The shape is measured with Subdivision Surface and Multires off (in the background copy only). A mesh whose vertex count differs is reported, not measured.\n"
        "- The background Blender runs no scripts: Python expression drivers stay off on both sides alike, so a shape that depends on them is compared without them.\n"
        "- A large character takes minutes. The run stops by itself after 60 minutes, when this Blender closes, or when free memory runs low.",
    ),
    (
        "シーンの 2 つの状態を比べ、違う所を数えます。オブジェクト・メッシュ・アーマチュア・アクション・マテリアル・ノードグループ・シーンそのものなど全部の ID をプロパティごとに比べ、メッシュの評価後の形をミリで比べます。比べる作業は別に起動する背景の Blender が行うので、今の Blender はそのまま使え、.blend は保存も変更もしません。",
        "シーンを変える前に控えを取っておくか、比べる相手の .blend を用意します。形を測るメッシュを決めたい時は、そのメッシュを選びます。何も選ばなければ、アーマチュアに付いた全部のメッシュを測ります。両側とも今のフレームで比べます。",
        "1. 変える前に「控えを取る」を押します。\n"
        "2. シーンを変えます。別のファイルと比べる時は、代わりに「比べる相手のファイル」でそのファイルを選びます。\n"
        "3. 「比べる」を押します。ボタンの下の行に進み具合が出ます。止める時はもう一度押します。\n"
        "4. 行の数を読み、全部の一覧が要る時は「結果を書き出す」を押します。",
        "・控えを取る：今のシーンの写しをアドオン専用のフォルダーに保存します。次に取ると置き換わります。\n"
        "・比べる相手のファイル（空）：比べる .blend です。空なら控え（1 つ目）と今のシーン（2 つ目）、選べば今のシーン（1 つ目）とそのファイル（2 つ目）を比べます。\n"
        "・比べる／止める：比べ始めます。動いている間は同じボタンで止めます。\n"
        "・除く項目（14 個）：Blender が自分で書き換えるので比べない名前です（session_uid・is_dirty など）。\n"
        "・桁数（7）：比べる前に数を丸める小数の桁です。小数の誤差を変更と数えないためです。\n"
        "・結果の書き出し先（//）：ファイルを書く場所です。// はこの .blend のフォルダーです。\n"
        "・結果を書き出す：違う項目を全部入れた srs_compare_<日付>_<時刻>.json と、読むための同じ名前の .md を書きます。",
        "行には、変わった ID の数と多い型の上位 3 つ、増（2 つ目だけにある）と減（1 つ目だけにある）、形の最大差（mm）、評価後の姿勢の項目数とその最大差が出ます。何も変わっていなければ「違いはありません」と比べた ID の数が出ます。.md では、変わった ID ごとに項目を「1 つ目 → 2 つ目」で並べます。constraint:<骨> は 1 本の骨のコンストレイントの項目、runtime_pose_eval はほかの変更に連れて変わった評価後の骨の行列です。",
        "・シーンにデータを書かないので、元に戻す物はありません。\n"
        "・控えと作業ファイルは拡張機能のユーザーフォルダー（extensions\\.user\\…\\compare）にあり、そのフォルダーを消せば消えます。\n"
        "・頂点など 4000 個を超える集まりは、数だけを比べて並べません。メッシュの位置・UV・ウェイト・シェイプキーとアニメーションのカーブは中身のハッシュで比べるので、項目は「違う」ことだけを示し、どれだけ違うかは形の行で見ます。\n"
        "・ほかの場所にある物（骨の親・カスタムシェイプの変形・リンクのノードなど）は二度は比べず、REF: とその道で書きます。変更は持ち主の下に 1 回だけ並びます。Blender が自分で作る一覧（シーンの全オブジェクト・依存グラフ）は比べません。\n"
        "・形はサブディビジョンサーフェスとマルチレゾリューションを切って測ります（背景の写しの中だけ）。頂点数が違うメッシュは測らずにそう出します。\n"
        "・背景の Blender はスクリプトを動かしません。Python 式のドライバーは両側とも止まった状態で比べるので、それに頼る形はそれ抜きで比べます。\n"
        "・大きなキャラクターでは数分かかります。60 分を超えた時、今の Blender を閉じた時、空きメモリが少なくなった時は自分で止まります。",
    ),
),
"prefs_audit": (
    "Audit and Weight Quality", "監査・ウェイト品質",
    (
        "Sets the thresholds the audits use and the name of the report Text.",
        "Edit > Preferences > Add-ons > Smart Rig.",
        "1. Change a value.\n"
        "2. Run the audit again (Data section or Weight tool).",
        "- Report Text Name (Smart Rig Suite Report): Text used for audit reports.\n"
        "- Weight Sum Tolerance (0.001): allowed difference from a total of 1.0.\n"
        "- Maximum Influences (4): deform groups per vertex before it is reported.\n"
        "- Tiny Weight Threshold (0.0001): weights below are reported as tiny; 0 turns it off.",
        "The next audit uses the new values.",
        "- Type the default values back to return.",
    ),
    (
        "監査が使うしきい値と、レポートのTextの名前を決めます。",
        "編集＞プリファレンス＞アドオン＞Smart Rig。",
        "1. 値を変えます。\n"
        "2. もう一度監査します（データのセクションかウェイトツール）。",
        "・レポートText名（Smart Rig Suite Report）：監査レポートのText。\n"
        "・ウェイト合計許容差（0.001）：合計1.0からの許す差。\n"
        "・最大影響数（4）：これを超えると報告する、1頂点の変形グループ数。\n"
        "・極小ウェイトしきい値（0.0001）：これ未満を極小として報告。0で無効。",
        "次の監査から新しい値が使われます。",
        "・既定の値を入れ直せば戻ります。",
    ),
),
})


def help_keys():
    """Every help key, in panel order (used by the runtime help check)."""
    return tuple(_SECTION_HELP)


def _help_units(text: str) -> int:
    return sum(2 if ord(ch) > 0x2E80 else 1 for ch in text)


def _help_wrap(line: str, limit: int):
    """Wrap one help line to ``limit`` units, with a hanging indent for list items."""
    indent = ""
    for marker, pad in (("・", "　"), ("- ", "  ")):
        if line.startswith(marker):
            indent = pad
            break
    else:
        head = line.split(" ", 1)[0]
        if len(head) >= 2 and head[:-1].isdigit() and head[-1] == ".":
            indent = " " * (len(head) + 1)
    out, current = [], ""
    for ch in line:
        candidate = current + ch
        if current and _help_units(candidate) > limit and ch not in "。、，．）」』,.)：:":
            cut = len(current)
            if ch.isascii() and ch.isalnum():
                # never inside a Latin word: back up to its start
                while cut > 0 and current[cut - 1].isascii() and current[cut - 1].isalnum():
                    cut -= 1
                if cut <= len(current) // 2:
                    cut = len(current)
            out.append(current[:cut].rstrip())
            current = indent + current[cut:].lstrip()
            if ch == " " and current == indent:
                continue
        current += ch
    if current.strip():
        out.append(current)
    return out


def help_lines(topic: str, japanese: bool):
    """The rows the help popup draws for ``topic``: a list of (kind, text) with kind 'heading' or 'text'."""
    entry = _SECTION_HELP.get(str(topic or ""))
    if entry is None:
        return [("text", "Smart Rigのセクションです。" if japanese else "Smart Rig section.")]
    parts = entry[3] if japanese else entry[2]
    rows = []
    for (heading_en, heading_ja), part in zip(_HELP_HEADINGS, parts):
        rows.append(("heading", heading_ja if japanese else heading_en))
        for line in str(part).split("\n"):
            for wrapped in _help_wrap(line, _HELP_LIMIT - 4):
                rows.append(("text", wrapped))
    return rows


def help_title(topic: str, japanese: bool) -> str:
    entry = _SECTION_HELP.get(str(topic or ""))
    if entry is None:
        return "Smart Rigヘルプ" if japanese else "Smart Rig Help"
    return entry[1] if japanese else entry[0]


def _help_is_japanese() -> bool:
    # the same rule as every other caption of this panel (language + Translate Interface)
    return tr("en", "ja") == "ja"


class SRS_OT_show_section_help(bpy.types.Operator):
    bl_idname = "srs.show_section_help"
    bl_label = "Smart Rig Help"
    bl_description = "Show detailed help for this Smart Rig section"
    bl_options = set()
    _sms_no_undo = True

    topic: StringProperty(options={"HIDDEN"})
    text: StringProperty(options={"HIDDEN"})

    def invoke(self, context, _event):
        japanese = _help_is_japanese()
        return context.window_manager.invoke_props_dialog(
            self,
            width=_HELP_WIDTH,
            title=(tr("Details", "詳細") if self.text else help_title(self.topic, japanese)),
            confirm_text=tr("Close", "閉じる"),
            translate=False,
        )

    def draw(self, context):
        japanese = _help_is_japanese()
        col = self.layout.column(align=True)
        body = None
        rows = ([("text", w) for w in _help_wrap(self.text, _HELP_LIMIT - 4)] if self.text
                else help_lines(self.topic, japanese))
        for kind, text in rows:
            if kind == "heading":
                col.separator(factor=0.6)
                col.label(text=text, icon="DISCLOSURE_TRI_RIGHT", translate=False)
                body = col.column(align=True)
                body.scale_y = 0.85
            else:
                (body or col).label(text=text, translate=False)

    def execute(self, _context):
        return {"FINISHED"}


def _help_header(row, en: str, ja: str, icon: str, topic: str):
    """Title on the left, the section's "?" help at the right end of the same row."""
    split = row.split(factor=0.9, align=True)
    split.label(text=tr(en, ja), icon=icon, translate=False)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    op = right.operator(SRS_OT_show_section_help.bl_idname, text="", icon="QUESTION", emboss=False)
    op.topic = topic


def _group(layout, en: str, ja: str, icon: str, topic: str):
    """A titled group of buttons inside a subsection; its explanation is in its own "?" help."""
    _help_header(layout.row(align=True), en, ja, icon, topic)


def _section(layout, settings, prop_name: str, en: str, ja: str, *, icon: str = "TOOL_SETTINGS", topic: str = "", container=None):
    box = container if container is not None else layout.box()
    expanded = bool(getattr(settings, prop_name))
    header = box.row(align=True)
    # Shared Smart Tools section header: triangle, borderless icon+title, small gap, compact help.
    header.prop(settings, prop_name, text="", icon="TRIA_DOWN" if expanded else "TRIA_RIGHT", emboss=True)
    header.prop(settings, prop_name, text=tr(en, ja), icon=icon, emboss=False, translate=False)
    try:
        header.separator(factor=0.35)
    except Exception:
        pass
    help_row = header.row(align=True)
    help_row.scale_x = 0.82
    op = help_row.operator(SRS_OT_show_section_help.bl_idname, text="", icon="QUESTION")
    op.topic = topic or prop_name
    return box if expanded else None


_SECTION_BOX_UNSET = object()


def _child(layout, settings, prop_name: str, en: str, ja: str, *, icon: str = "TOOL_SETTINGS", topic: str):
    """A native child section (UILayout.panel_prop) whose open state is ``prop_name``; "?" opens ``topic``."""
    header, body = layout.panel_prop(settings, prop_name)
    _help_header(header, en, ja, icon, topic)
    return body


def _panel_width():
    ctx = bpy.context
    region = ctx.region
    scale = ctx.preferences.system.ui_scale or 1.0
    if region is not None and region.type in {"UI", "TOOL_PROPS"} and region.width > 0:
        return region.width / scale
    # Call Panel draws a narrow popup within the editor's much wider region.
    return 170


def _narrow_panel():
    return _panel_width() <= 170


def _wrap_lines(text: str, *, padding=56):
    """Split a sentence to the available panel width."""
    limit = max(12, int((_panel_width() - padding) / 7.5))
    lines, line = [], ""

    def units(s):
        return sum(2 if ord(c) > 0x2E80 else 1 for c in s)

    for ch in text:
        # closing punctuation never starts a line
        if line and units(line + ch) > limit and ch not in "。、，．）」』,.)":
            cut = len(line)
            if ch.isascii() and ch.isalnum():
                # never inside a Latin word: back up to its start
                while cut > 0 and line[cut - 1].isascii() and line[cut - 1].isalnum():
                    cut -= 1
                if not cut:
                    cut = len(line)
            lines.append(line[:cut].rstrip())
            line = line[cut:].lstrip()
            if ch == " " and not line:
                continue
        line += ch
    if line:
        lines.append(line)
    return lines


def _msg(layout, text: str, icon: str = "NONE"):
    """One short line; a longer message is cut and its full text opens from the row's "?" help."""
    text = str(text)
    short = text
    if _help_units(short) > 38:
        short = ""
        for ch in text:
            if _help_units(short + ch) > 36:
                break
            short += ch
        short = short.rstrip() + "…"
    row = layout.row(align=True)
    row.label(text=short, icon=icon, translate=False)
    if short != text:
        op = row.operator(SRS_OT_show_section_help.bl_idname, text="", icon="QUESTION", emboss=False)
        op.text = text


def _note(layout, en: str, ja: str):
    _msg(layout, tr(en, ja))


def _warn_note(layout, en: str, ja: str):
    _msg(layout, tr(en, ja), "ERROR")



def _always_on_row(layout, owner, prop_name: str, label: str):
    """Shared Smart Tools always-on row: label on the left, right-aligned Enabled/Disabled toggle."""
    enabled = bool(getattr(owner, prop_name, False))
    state_text = tr("On", "有効") if enabled else tr("Off", "無効")
    state_icon = "CHECKBOX_HLT" if enabled else "CHECKBOX_DEHLT"
    row = layout.row(align=True)
    row.scale_y = 0.95
    split = row.split(factor=0.72, align=True)
    left = split.row(align=True)
    left.label(text=label, translate=False)
    right = split.row(align=True)
    right.alignment = "RIGHT"
    right.use_property_split = False
    right.use_property_decorate = False
    right.row(align=True).prop(owner, prop_name, text=state_text, icon=state_icon, toggle=True, translate=False)


def _draw_always_on(layout, context, settings, *, section_box=_SECTION_BOX_UNSET):
    box = _section(layout, settings, "ui_section_always_on", "Always-on Toggles", "常時機能切り替え", icon="TIME", topic="always_on") if section_box is _SECTION_BOX_UNSET else section_box
    if box is None:
        return
    box.use_property_split = False
    box.use_property_decorate = False
    # The persistence policy is always the first row in every SmartTools suite.
    col = box.column(align=True)
    _always_on_row(col, settings, "n_panel_state_save", tr("N-panel State Save", "Nパネル状態保存"))
    col.separator(factor=0.5)
    preferences = get_preferences(context)
    if preferences is not None:
        _always_on_row(col, preferences, "guard_proxy_picker_context", tr("Guard Proxy Picker restricted contexts", "Proxy Pickerの制限コンテキストを保護"))
    else:
        row = col.row(align=True)
        row.enabled = False
        _msg(row, tr("Proxy Picker guard is unavailable until preferences are registered.", "プリファレンス登録完了までProxy Picker保護を利用できません。"))


def _localized_conflict(message: str) -> str:
    if message.startswith("The full Auto-Rig Pro add-on and standalone Rig Tools"):
        return tr(
            "Full Auto-Rig Pro and standalone Rig Tools are both enabled; disable standalone Rig Tools.",
            "Auto-Rig Pro本体と単体Rig Toolsが同時に有効です。単体Rig Toolsを無効化してください。",
        )
    if "is still loaded from inside the Smart Rig Suite folder" in message:
        product = message.split(" is still", 1)[0]
        return tr(
            f"{product} is still loaded from the Smart Rig Suite folder; reinstall it as an external add-on.",
            f"{product}がSmart Rig Suite内から読み込まれています。外部アドオンとして再インストールしてください。",
        )
    if "obsolete embedded RNA registration" in message:
        count = message.split(" ", 1)[0]
        return tr(
            f"{count} obsolete embedded RNA registrations remain; restart Blender after updating.",
            f"旧内蔵版のRNA登録が{count}件残っています。更新後にBlenderを再起動してください。",
        )
    if "is enabled but its expected operator is unavailable" in message:
        product = message.split(" is enabled", 1)[0]
        return tr(
            f"{product} is enabled but its operator registration is unavailable. Restart Blender once after upgrading from an embedded 1.x build.",
            f"{product}は有効ですがオペレーター登録を利用できません。旧内蔵版1.xから更新した場合はBlenderを一度再起動してください。",
        )
    return tr("External integration conflict detected.", "外部連携の競合を検出しました。")

def _status_row(layout, label: str, available: bool, detail: str = ""):
    detail = detail or (tr("Available", "利用可能") if available else tr("Unavailable", "利用不可"))
    icon = "CHECKMARK" if available else "ERROR"
    col = layout.column(align=True)
    col.label(text=label)
    _msg(col, detail, icon)



def _setup_child(layout, settings, prop_name, en, ja, *, icon, topic):
    if _narrow_panel():
        _note(layout, en, ja)
        en = ja = ""
    return _child(layout, settings, prop_name, en, ja, icon=icon, topic=topic)


def _draw_setup(box, context, settings, snapshot):
    status = snapshot.status
    _status_row(
        box,
        "Auto-Rig Pro",
        status.auto_rig_pro.available,
        status.auto_rig_pro.version or tr("Enabled" if status.auto_rig_pro.enabled else "Not enabled", "有効" if status.auto_rig_pro.enabled else "未有効"),
    )
    _status_row(
        box,
        tr("Rig Tools", "リグツール"),
        status.rig_tools.available,
        status.rig_tools.version or (tr("Provided by Auto-Rig Pro", "Auto-Rig Proから提供") if status.rig_tools.operator_available else tr("Not available", "利用不可")),
    )
    _status_row(
        box,
        "Proxy Picker",
        status.proxy_picker.available,
        status.proxy_picker.version or tr("Not enabled", "未有効"),
    )
    _status_row(
        box,
        "AI_win",
        status.ai_runtime.valid,
        (f"v{status.ai_runtime.version}" if status.ai_runtime.version else (tr("Valid", "有効") if status.ai_runtime.valid else tr("Not configured", "未設定"))),
    )
    for warning in snapshot.conflicts:
        warning_box = box.box()
        warning_box.label(text=tr("External integration conflict detected", "外部連携の競合を検出しました"), icon="ERROR")
        warning_box.label(text=_localized_conflict(warning))

    target_box = _setup_child(box, settings, "show_c_targets", "Workflow Targets", "ワークフロー対象", icon="RESTRICT_SELECT_OFF", topic="setup_targets")
    if target_box is not None:
        target_box.label(text=tr("Target Rig Armature", "対象リグアーマチュア"))
        target_box.prop(settings, "target_armature", text="")
        target_box.label(text=tr("Target Body Mesh", "対象ボディメッシュ"))
        target_box.prop(settings, "target_body_mesh", text="")
        col = target_box.column(align=True)
        col.operator("srs.assign_workflow_targets", text=tr("Use Current Selection", "現在の選択を使用"), icon="RESTRICT_SELECT_OFF")
        col.operator("srs.workflow_preflight", text=tr("Run Preflight", "事前検証を実行"), icon="VIEWZOOM")

    part_box = _setup_child(box, settings, "show_c_parts", "Parts and costumes", "パーツ・衣装", icon="OUTLINER_COLLECTION", topic="setup_parts")
    if part_box is not None:
        part_box.prop(settings, "part_marker", text=tr("Marker", "識別名"))
        part_box.prop_search(settings, "part_name", bpy.data, "collections", text=tr("Part", "パーツ"))
        row = part_box.row(align=True)
        row.operator("srs.part_visibility", text=tr("Show", "表示"), icon="HIDE_OFF").visible = True
        row.operator("srs.part_visibility", text=tr("Hide", "非表示"), icon="HIDE_ON").visible = False
        from . import part_rig
        links = part_rig.linked_keys(str(settings.part_name).strip()) if settings.part_name else []
        for obj_name, key_name, shown, hidden in links:
            part_box.label(text="%s : %s  (%g / %g)" % (obj_name, key_name, shown, hidden), icon="SHAPEKEY_DATA", translate=False)
        part_box.prop(settings, "part_key_object", text=tr("Mesh", "連動"))
        keyed = settings.part_key_object
        if keyed is not None and getattr(keyed.data, "shape_keys", None) is not None:
            part_box.prop_search(settings, "part_key_name", keyed.data.shape_keys, "key_blocks", text=tr("Key", "キー"))
        row = part_box.row(align=True)
        row.operator("srs.part_link_key", text=tr("Link to Part", "パーツに連動"), icon="LINKED").remove = False
        row.operator("srs.part_link_key", text="", icon="UNLINKED").remove = True
        row = part_box.row(align=True)
        row.prop(settings, "part_delete_meshes", text=tr("With Meshes", "メッシュも"))
        row.operator("srs.part_delete", text=tr("Remove Part", "パーツを削除"), icon="TRASH")
        part_box.operator("srs.part_audit", text=tr("Audit Parts", "パーツを監査"), icon="ZOOM_SELECTED")

    refresh_en, refresh_ja = "Refresh External Status", "外部ツール状態を再検出"
    if _narrow_panel():
        _note(box, refresh_en, refresh_ja)
        refresh_en, refresh_ja = "Refresh", "再検出"
    box.operator("srs.refresh_external_status", text=tr(refresh_en, refresh_ja), icon="FILE_REFRESH")


def _draw_character_size(size_box, context, settings):
    """Character resize subsection. Nothing heavy here: the scope is only worked out by Check and Resize."""
    from . import character_rescale
    from .i18n import tr_format
    rig, problem = character_rescale.find_rig(context)
    if rig is None:
        if problem is not None and problem[0] != character_rescale.MSG_NO_RIG:
            _note(size_box, problem[0] % problem[1], tr_format(problem[0], **problem[1]))
        else:
            _note(size_box, "Choose an Auto-Rig Pro rig.", "Auto-Rig Pro のリグを選んでください。")
    else:
        size_box.label(text=tr("Rig: %s", "リグ：%s") % rig.name, icon="ARMATURE_DATA")
    row = size_box.row(align=True)
    # the tab captions are explicit: Blender's own catalog would show "Factor" as a different word
    row.prop_enum(settings, "rescale_mode", "FACTOR", text=tr("Factor", "倍率"))
    row.prop_enum(settings, "rescale_mode", "HEIGHT", text=tr("Target Height", "目標の高さ"))
    if settings.rescale_mode == "HEIGHT":
        size_box.label(text=tr("Height Is", "高さの測り方"))
        size_box.prop(settings, "rescale_height_basis", text="")
        size_box.label(text=tr("Current Height (mm)", "今の高さ（mm）"))
        row = size_box.row(align=True)
        row.prop(settings, "rescale_current_height_mm", text="")
        sub = row.row(align=True)
        sub.enabled = rig is not None
        sub.operator("srs.character_rescale_measure", text=tr("Measure", "測る"), icon="DRIVER_DISTANCE")
        top, bottom = settings.rescale_measured_top_mm, settings.rescale_measured_bottom_mm
        if top != 0.0 or bottom != 0.0:
            size_box.label(text=tr("Top %.1f mm, bottom %.1f mm", "上端 %.1f mm、下端 %.1f mm") % (top, bottom))
        measured_on = settings.rescale_measured_rig
        if measured_on and rig is not None and measured_on != rig.name:
            size_box.label(text=tr("Measured on %s", "%s で測った値です") % measured_on, icon="ERROR")
        measured_basis = settings.rescale_measured_basis
        if measured_basis and measured_basis != settings.rescale_height_basis:
            _msg(size_box, tr("Measured with the other Height Is; measure again",
                              "別の「高さの測り方」で測った値です。測り直してください"), "ERROR")
        size_box.prop(settings, "rescale_target_height_mm", text=tr("Target Height (mm)", "目標の高さ（mm）"))
        current, target = settings.rescale_current_height_mm, settings.rescale_target_height_mm
        if current > 0.0 and target > 0.0:
            size_box.label(text=tr("Factor: %.6f", "倍率：%.6f") % (target / current))
    else:
        size_box.prop(settings, "rescale_factor", text=tr("Factor", "倍率"))
    col = size_box.column(align=True)
    col.prop(settings, "rescale_include_all_scene", text=tr("Whole Scene", "シーン全体"))
    col.prop(settings, "rescale_include_staging", text=tr("Lights and Cameras", "照明とカメラも"))
    col.prop(settings, "rescale_scale_materials", text=tr("Material Lengths", "マテリアルの長さ"))
    col.prop(settings, "rescale_scale_panel_lengths", text=tr("Panel Lengths", "パネルの長さ設定"))
    col.prop(settings, "rescale_rebind_bound", text=tr("Rebind Bound Modifiers", "バインドを掛け直す"))
    row = size_box.row(align=True)
    row.enabled = rig is not None
    row.operator("srs.character_rescale_check", text=tr("Check", "確認"), icon="VIEWZOOM")
    row.operator("srs.character_rescale", text=tr("Resize", "サイズを変更"), icon="FULLSCREEN_EXIT")


def _draw_body(box, context, settings, snapshot):
    external_ok = snapshot.operator_available("arp.append_arp")
    ref = _child(box, settings, "show_c_reference", "Reference Rig & Markers", "参照リグとマーカー", icon="ARMATURE_DATA", topic="body_reference")
    if ref is not None:
        col = ref.column(align=True)
        col.enabled = external_ok
        row = col.column(align=True)
        row.prop(settings, "rig_preset", text="")
        row.operator("srs.arp_add_reference", text=tr("Add Reference Rig", "参照リグを追加"), icon="ARMATURE_DATA")
        row = col.column(align=True)
        op = row.operator("srs.arp_prepare_context", text=tr("Prepare Object Context", "オブジェクト操作を準備"))
        op.target_mode = "OBJECT"
        op = row.operator("srs.arp_prepare_context", text=tr("Prepare Edit Context", "編集操作を準備"))
        op.target_mode = "EDIT"
        row = col.column(align=True)
        row.prop(settings, "limb_preset", text="")
        row.operator("srs.arp_add_limb_safe", text=tr("Add Reference Limb", "参照リムを追加"), icon="BONE_DATA")
        missing = missing_markers("required_body")
        col = ref.column(align=True)
        marker_text = tr("Required markers ready", "必須マーカー準備済み") if not missing else tr("Missing markers: ", "不足マーカー: ") + ", ".join(missing)
        _msg(col, marker_text, "CHECKMARK" if not missing else "ERROR")
        row = ref.column(align=True)
        row.enabled = snapshot.operator_available("arp.guess_markers")
        op = row.operator("srs.arp_marker_ai", text=tr("Estimate Body Markers", "ボディマーカーを推定"), icon="PLAY")
        op.kind = "BODY"
        row.operator("srs.arp_smart_detect", text=tr("Run Detection", "検出を実行"), icon="PLAY")
        ref.operator("srs.arp_match_to_rig", text=tr("Match Reference to Rig", "参照ボーンをリグへ適合"), icon="MOD_ARMATURE")

    bind_box = _child(box, settings, "show_c_bind", "Binding", "バインド", icon="MOD_ARMATURE", topic="body_bind")
    if bind_box is not None:
        row = bind_box.column(align=True)
        row.enabled = snapshot.operator_available("arp.bind_to_rig")
        op = row.operator("srs.arp_bind_workflow", text=tr("Bind", "バインド"), icon="MOD_ARMATURE")
        op.mode = "BIND"
        op = row.operator("srs.arp_bind_workflow", text=tr("Unbind", "解除"))
        op.mode = "UNBIND"
        op = row.operator("srs.arp_bind_workflow", text=tr("Scale-fix Rebind", "スケール修正リバインド"))
        op.mode = "REBIND"

    lift_box = _child(box, settings, "show_c_shoe_lift", "Shoe Sole Lift", "靴底の持ち上げ", icon="TRIA_UP_BAR", topic="body_shoe_lift")
    if lift_box is not None:
        from . import shoe_lift
        rig = shoe_lift.arp_rig(context.active_object) or shoe_lift.arp_rig(settings.target_armature)
        if rig is None:
            _note(lift_box, "Choose an Auto-Rig Pro rig.", "Auto-Rig Pro のリグを選んでください。")
        else:
            kind, h, measured = shoe_lift.state(rig)
            if kind == "lifted":
                lift_box.label(text=tr("Lifted: %.1f mm", "持ち上げ中：%.1f mm") % (h * 1000.0), icon="TRIA_UP")
            elif kind == "cleared":
                lift_box.label(text=tr("Cleared (measured %.1f mm)", "解除中（測定値 %.1f mm）") % (measured * 1000.0), icon="TRIA_DOWN")
            else:
                lift_box.label(text=tr("Not set up", "未設定") + ("" if measured <= 0.0 else
                               tr(" (measured %.1f mm)", "（測定値 %.1f mm）") % (measured * 1000.0)), icon="DOT")
            for problem in shoe_lift.preflight(rig):
                col = lift_box.column(align=True)
                _msg(col, report_ja(problem), "ERROR")
            col = lift_box.column(align=True)
            col.prop(settings, "shoe_lift_margin_mm", text=tr("Margin mm", "余白 mm"))
            col.prop(settings, "shoe_lift_height_mm", text=tr("Height mm", "高さ mm"))
            lift_box.prop(settings, "shoe_lift_projectors", text=tr("Lift Projectors", "投影元も上げる"))
            row = lift_box.row(align=True)
            row.operator("srs.shoe_lift_measure", text=tr("Measure", "測る"), icon="DRIVER_DISTANCE").margin_mm = settings.shoe_lift_margin_mm
            op = row.operator("srs.shoe_lift_apply", text=tr("Lift", "上げる"), icon="TRIA_UP")
            op.height_mm, op.include_projectors = settings.shoe_lift_height_mm, settings.shoe_lift_projectors
            row = lift_box.row(align=True)
            row.operator("srs.shoe_lift_clear", text=tr("Clear", "解除"), icon="TRIA_DOWN")
            row.operator("srs.shoe_lift_remove", text=tr("Remove", "取り外す"), icon="X")
            for name, _mesh, kind_, action in shoe_lift.outside(rig):
                lift_box.label(text="%s: %s" % (name, {"lift": tr("lifted too", "一緒に上げる"),
                                                       "none": tr("not needed", "不要"),
                                                       "unjudged": tr("not judged", "未判定")}[action]),
                               icon="OBJECT_DATA", translate=False)

    size_box = _child(box, settings, "show_c_rescale", "Character Size", "キャラクターのサイズ変更", icon="CON_SIZELIKE", topic="body_rescale")
    if size_box is not None:
        _draw_character_size(size_box, context, settings)

    aux_box = _child(box, settings, "show_c_aux", "Auxiliary Bones (All)", "補助ボーンの一括設定", icon="GROUP_BONE", topic="body_aux")
    if aux_box is not None:
        row = aux_box.row(align=True)
        row.prop(settings, "joint_setup_knees", text=tr("Knees", "膝"), toggle=True)
        row.prop(settings, "joint_setup_elbows", text=tr("Elbows", "肘"), toggle=True)
        row = aux_box.row(align=True)
        row.prop(settings, "joint_setup_scale_preset", text=tr("Scale To Joint", "関節に合わせる"))
        row.prop(settings, "joint_setup_smooth", text=tr("Smooth Weights", "ウェイトも均す"))
        row = aux_box.row(align=True)
        row.operator("srs.joint_setup_all", text=tr("Set Up All", "一括設定"), icon="CHECKMARK")
        row.operator("srs.joint_setup_remove", text=tr("Remove", "解除"), icon="X")
        aux_box.operator("srs.joint_audit", text=tr("Audit Auxiliary Bones", "補助ボーンを監査"), icon="ZOOM_SELECTED")
        aux_box.operator("srs.joint_mirror_fans", text=tr("Mirror Fan Setup", "扇の設定を左右で揃える"), icon="MOD_MIRROR")

    knee_box = _child(box, settings, "show_c_knee_split", "Knee Split", "膝の分離", icon="CONSTRAINT_BONE", topic="body_knee_split")
    if knee_box is not None:
        row = knee_box.row(align=True)
        row.prop(settings, "knee_split_onset_deg", text=tr("Onset", "始動角"))
        row.prop(settings, "knee_split_end_deg", text=tr("End", "終端角"))
        row = knee_box.column(align=True)
        row.prop(settings, "knee_split_thigh_slide_mm", text=tr("Thigh Slide", "太もも スライド"))
        row.prop(settings, "knee_split_thigh_apart_mm", text=tr("Thigh Apart", "太もも 離す"))
        row = knee_box.column(align=True)
        row.prop(settings, "knee_split_calf_slide_mm", text=tr("Calf Slide", "ふくらはぎ スライド"))
        row.prop(settings, "knee_split_calf_apart_mm", text=tr("Calf Apart", "ふくらはぎ 離す"))
        row = knee_box.column(align=True)
        row.operator("srs.knee_split_install", text=tr("Install Knee Split", "膝の分離を設定"), icon="CON_TRANSLIKE")
        row.operator("srs.knee_split_remove", text=tr("Remove", "解除"), icon="X")
        knee_box.operator("srs.knee_split_audit", text=tr("Audit Knee Split", "膝の分離を監査"), icon="ZOOM_SELECTED")
        knee_box.label(text=tr("Ramp Curve", "ランプ曲線"))
        knee_box.prop(settings, "knee_split_ramp_curve", text="")
        knee_box.separator()
        _group(knee_box, "Knee weight smoothing", "膝まわりのウェイトを均す", "MOD_SMOOTH", "body_knee_smooth")
        row = knee_box.column(align=True)
        row.prop(settings, "knee_smooth_radius_mm", text=tr("Radius", "半径"))
        row.prop(settings, "knee_smooth_factor", text=tr("Factor", "強さ"))
        row.prop(settings, "knee_smooth_repeat", text=tr("Repeat", "回数"))
        knee_box.operator("srs.knee_smooth_weights", text=tr("Smooth Knee Weights", "膝のウェイトを均す"), icon="MOD_VERTEX_WEIGHT")

    prof_box = _child(box, settings, "show_c_knee_profile", "Knee Angle Profile", "膝の角度プロファイル", icon="FCURVE", topic="body_knee_profile")
    if prof_box is not None:
        prof_box.prop(settings, "knee_profile_front", text=tr("Front", "前面"))
        prof_box.prop(settings, "knee_profile_back", text=tr("Back", "後面"))
        row = prof_box.column(align=True)
        row.operator("srs.knee_profile_install", text=tr("Install Profile", "プロファイルを設定"), icon="FCURVE")
        row.operator("srs.knee_profile_remove", text=tr("Remove", "解除"), icon="X")
        prof_box.operator("srs.knee_profile_audit", text=tr("Audit Profile", "プロファイルを監査"), icon="ZOOM_SELECTED")

    wrist_box = _child(box, settings, "show_c_wrist", "Wrist fold", "手首の潰れ", icon="CON_KINEMATIC", topic="body_wrist")
    if wrist_box is not None:
        row = wrist_box.row(align=True)
        row.operator("srs.wrist_fold_install", text=tr("Open The Fold", "襞を開く"), icon="CON_KINEMATIC")
        row.operator("srs.wrist_fold_verify", text=tr("Check", "確認"), icon="CHECKMARK")
        wrist_box.operator("srs.wrist_fold_remove", text=tr("Remove", "外す"), icon="TRASH")

    tool = _child(box, settings, "show_c_weight_tool", "Weight tool", "ウェイトツール", icon="MOD_VERTEX_WEIGHT", topic="body_weight_tool")
    if tool is not None:
        tool.prop(settings, "weight_value")
        row = tool.row(align=True)
        op = row.operator("srs.weight_apply", text=tr("Set", "設定"))
        op.operation = "SET"
        op = row.operator("srs.weight_apply", text="+")
        op.operation = "ADD"
        op = row.operator("srs.weight_apply", text="-")
        op.operation = "SUBTRACT"
        presets = tool.row(align=True)
        for value in (0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0):
            op = presets.operator("srs.weight_apply", text=f"{value:g}")
            op.operation = "SET"
            op.preset_value = value
        row = tool.column(align=True)
        row.prop(settings, "weight_scale")
        op = row.operator("srs.weight_apply", text=tr("Scale", "スケール"))
        op.operation = "SCALE"
        op = row.operator("srs.weight_apply", text=tr("Normalize", "正規化"))
        op.operation = "NORMALIZE"
        op = row.operator("srs.weight_apply", text=tr("Clean", "クリーン"))
        op.operation = "CLEAN"
        op = row.operator("srs.weight_apply", text=tr("Limit", "影響数制限"))
        op.operation = "LIMIT"
        row = tool.column(align=True)
        row.prop(settings, "weight_selected_only")
        row.prop(settings, "weight_normalize_after")
        tool.prop(settings, "weight_clean_threshold")
        row = tool.column(align=True)
        row.operator("srs.weight_copy", text=tr("Copy", "コピー"))
        row.operator("srs.weight_paste", text=tr("Paste", "貼り付け"))
        row.operator("srs.weight_table_open", text=tr("Skin Weight Table", "スキンウェイトテーブル"), icon="WINDOW")
        row.operator("srs.weight_table_export", text=tr("Export Table", "テーブル書き出し"), icon="TEXT")
        tool.operator("srs.weight_quality_audit", text=tr("Weight Quality Audit", "ウェイト品質監査"), icon="VIEWZOOM")

    hyg_box = _child(box, settings, "show_c_hygiene", "Rig hygiene", "リグの衛生", icon="CHECKMARK", topic="body_hygiene")
    if hyg_box is not None:
        hyg_box.operator("srs.hygiene_audit", text=tr("Audit Rig Hygiene", "リグの衛生を監査"), icon="ZOOM_SELECTED")
        row = hyg_box.column(align=True)
        row.operator("srs.hygiene_lock_dead", text=tr("Lock Dead Channels", "死んだチャンネルを閉じる"), icon="LOCKED")
        row.operator("srs.hygiene_clamp_face", text=tr("Clamp Jaw and Teeth", "顎と歯に天井を付ける"), icon="CON_LOCLIMIT")
        row = hyg_box.column(align=True)
        row.operator("srs.hygiene_bind_loose", text=tr("Bind What Is Not Bound", "未接続を接続する"), icon="MOD_ARMATURE")
        row.operator("srs.hygiene_repair_drivers", text=tr("Repair Dead Drivers", "死んだドライバーを直す"), icon="DRIVER")
        row = hyg_box.column(align=True)
        row.operator("srs.hygiene_drop_faint", text=tr("Drop Faint Weights", "微小な重みを消す"), icon="MOD_VERTEX_WEIGHT")
        row.operator("srs.hygiene_symmetrize_midline", text=tr("Symmetrize Mirror", "左右対称に"), icon="MOD_MIRROR")
        row = hyg_box.column(align=True)
        row.prop(settings, "midline_band_mm", text=tr("Centre band mm", "中心の帯 mm"))
        row.operator("srs.hygiene_blend_midline", text=tr("Share Legs Across Centre", "中心で脚の重みを分ける"), icon="MOD_SMOOTH")
    if not external_ok:
        _warn_note(box, "Enable the external Auto-Rig Pro add-on to use this section.", "このセクションを使うには外部Auto-Rig Proアドオンを有効化してください。")


def _draw_face(box, context, settings, snapshot):
    eye_box = _child(box, settings, "show_c_eye_ref", "Eye rig", "目のリグ", icon="HIDE_OFF", topic="face_eye_ref")
    if eye_box is not None:
        col = eye_box.column(align=True)
        col.prop(settings, "eye_object_l", text=tr("Left Eye", "左目"))
        col.prop(settings, "eye_object_r", text=tr("Right Eye", "右目"))
        row = eye_box.column(align=True)
        row.prop(settings, "eye_pivot_source", text="")
        row.prop(settings, "eye_spec_distance", text=tr("Spec Dist.", "スペック距離"))
        row = eye_box.column(align=True)
        row.operator("srs.eye_snap_references", text=tr("Snap Eye References", "目の参照をスナップ"), icon="SNAP_ON")
        row.operator("srs.eye_audit", text=tr("Audit Eye Rig", "目のリグを監査"), icon="ZOOM_SELECTED")

    eye_bind_box = _child(box, settings, "show_c_eye_bind", "Eyeball Binding", "眼球の結合", icon="HIDE_OFF", topic="face_eye_bind")
    if eye_bind_box is not None:
        eye_bind_box.label(text=tr("Face Mesh", "顔メッシュ"))
        eye_bind_box.prop(settings, "eye_face_object", text="")
        eye_bind_box.operator("srs.eye_bind", text=tr("Bind Eyeballs", "眼球を結合"), icon="CONSTRAINT_BONE")
        eye_bind_box.prop(settings, "eye_verify_offset_mm", text=tr("Test mm", "検証 mm"))
        row = eye_bind_box.column(align=True)
        row.operator("srs.eye_verify", text=tr("Verify Eyeballs", "眼球を検証"), icon="ZOOM_SELECTED")
        row.operator("srs.eye_dispose_temp", text=tr("Remove Placeholder", "仮リグを削除"), icon="TRASH")

    lid_box = _child(box, settings, "show_c_lid", "Eyelid pivot", "瞼のピボット", icon="CON_ROTLIKE", topic="face_lid")
    if lid_box is not None:
        row = lid_box.column(align=True)
        row.prop(settings, "lid_pull_mm", text=tr("Test Pull mm", "検証の引き量mm"))
        row.operator("srs.lid_pivot_audit", text=tr("Audit", "監査"), icon="ZOOM_SELECTED")
        lid_box.operator("srs.lid_pivot_fix", text=tr("Correct Eyelid Pivot", "瞼のピボットを補正"), icon="CON_TRANSFORM")
        lid_box.operator("srs.lid_range_clamp", text=tr("Clamp Eyelid Range", "瞼の可動域をクランプ"), icon="CON_DISTLIMIT")
        row = lid_box.column(align=True)
        row.operator("srs.blink_pose_prepare", text=tr("Prepare Blink Pose", "Blink Pose の準備"), icon="POSE_HLT").lower = False
        row.operator("srs.blink_pose_prepare", text=tr("Lower", "下瞼"), icon="POSE_HLT").lower = True

    weight_box = _child(box, settings, "show_c_face_weight", "Face weights", "顔のウェイト", icon="MOD_VERTEX_WEIGHT", topic="face_weight")
    if weight_box is not None:
        weight_box.operator("srs.face_weight_audit", text=tr("Audit Face Weights", "顔のウェイトを監査"), icon="ZOOM_SELECTED")

    fall_box = _child(box, settings, "show_c_falloff", "Facial weight reach", "顔の効き範囲", icon="MOD_VERTEX_WEIGHT", topic="face_falloff")
    if fall_box is not None:
        row = fall_box.column(align=True)
        row.operator("srs.face_falloff_trim", text=tr("Trim The Reach", "効き範囲を詰める"), icon="MOD_VERTEX_WEIGHT")
        row.operator("srs.face_falloff_audit", text=tr("Measure", "測る"), icon="DRIVER_DISTANCE")
        fall_box.operator("srs.corrective_confine", text=tr("Confine The Lid Correctives", "瞼の補正キーを閉じ込める"), icon="SHAPEKEY_DATA")

    corr_box = _child(box, settings, "show_c_corrective", "Corrective shape keys", "補正シェイプキー", icon="SHAPEKEY_DATA", topic="face_corrective")
    if corr_box is not None:
        row = corr_box.column(align=True)
        row.operator("srs.corrective_lid", text=tr("Correct Closed Eyelid", "閉じた瞼を補正"), icon="SHAPEKEY_DATA")
        row.operator("srs.corrective_lip", text=tr("Hold Upper Lip", "上唇を保持"), icon="SHAPEKEY_DATA")

    shadow_box = _child(box, settings, "show_c_shadow", "Eyelid cast shadow", "瞼の落ち影", icon="SHADING_RENDERED", topic="face_shadow")
    if shadow_box is not None:
        col = shadow_box.column(align=True)
        col.prop(settings, "lid_shadow_follow", text=tr("Follow", "追従"))
        col.prop(settings, "lid_shadow_pull_mm", text=tr("Closed At mm", "閉じる位置 mm"))
        col.prop(settings, "lid_shadow_distance_mm", text=tr("Distance mm", "距離 mm"))
        shadow_box.prop(settings, "lid_shadow_remeasure", text=tr("Measure Again", "測り直す"))
        row = shadow_box.row(align=True)
        op = row.operator("srs.lid_shadow_build", text=tr("Follow The Lid", "瞼に追従させる"), icon="MOD_UVPROJECT")
        op.follow, op.distance_mm = settings.lid_shadow_follow, settings.lid_shadow_distance_mm
        op.pull_mm, op.remeasure = settings.lid_shadow_pull_mm, settings.lid_shadow_remeasure
        row.operator("srs.lid_shadow_verify", text=tr("Check", "確認"), icon="CHECKMARK")
        shadow_box.operator("srs.lid_shadow_remove", text=tr("Remove", "外す"), icon="TRASH")


def _draw_hair(box, context, settings, snapshot):
    hair_box = _child(box, settings, "show_c_hair", "Hair & Dangling Parts", "髪・垂れ下がるパーツ", icon="OUTLINER_OB_CURVES", topic="hair_hair")
    if hair_box is not None:
        hair_box.label(text=tr("Pattern", "名前パターン"))
        hair_box.prop(settings, "hair_name_pattern", text="")
        hair_box.prop(settings, "hair_bones_per_chain", text=tr("Bones", "ボーン数"))
        hair_box.prop(settings, "hair_parent_bone", text=tr("Parent", "親ボーン"))
        hair_box.prop(settings, "hair_prefix", text=tr("Prefix", "接頭辞"))
        hair_box.label(text=tr("Rigid Materials", "硬い材質"))
        hair_box.prop(settings, "hair_rigid_materials", text="")
        row = hair_box.row(align=True)
        row.prop(settings, "hair_use_master", text=tr("Master Chain", "マスター"))
        row.prop(settings, "hair_pin_loose", text=tr("Pin Loose", "残りを固定"))
        col = hair_box.column(align=True)
        col.operator("srs.hair_build", text=tr("Build Hair Chains", "髪チェーンを生成"), icon="CONSTRAINT_BONE")
        col.operator("srs.hair_remove", text=tr("Remove", "解除"), icon="X")
        hair_box.operator("srs.hair_audit", text=tr("Audit Hair Chains", "髪チェーンを監査"), icon="ZOOM_SELECTED")
        hair_box.prop(settings, "hair_group_by_collection", text=tr("By Collection", "コレクション単位"))
        hair_box.prop(settings, "hair_min_span_mm", text=tr("Long From mm", "長い房の下限mm"))
        hair_box.prop(settings, "hair_short_bones", text=tr("Short Piece Bones", "短いピースのボーン数"))

    cos_box = _child(box, settings, "show_c_costume", "Costume parts", "衣装パーツ", icon="MOD_CLOTH", topic="hair_costume")
    if cos_box is not None:
        cos_box.label(text=tr("Copy Weights From", "ウェイトの写し元"))
        cos_box.prop(settings, "costume_donor", text="")
        row = cos_box.row(align=True)
        row.prop(settings, "costume_rigid", text=tr("Solid Part", "固い部品"))
        row.prop(settings, "costume_base_space", text=tr("Before Keys", "キー前の形から"))
        op = cos_box.operator("srs.costume_bind", text=tr("Bind Costume Part", "衣装パーツを結合"), icon="MOD_ARMATURE")
        op.donor = settings.costume_donor.name if settings.costume_donor is not None else ""
        op.rigid, op.base_space = settings.costume_rigid, settings.costume_base_space

    chain_box = _child(box, settings, "show_c_chain", "Chain on Selected Part", "選択パーツに鎖を作る", icon="BONE_DATA", topic="hair_chain")
    if chain_box is not None:
        row = chain_box.row(align=True)
        row.prop(settings, "chain_mode", text="")
        row.prop(settings, "chain_key", text="")
        row = chain_box.row(align=True)
        row.prop(settings, "chain_bones", text=tr("Bones", "本数"))
        if settings.chain_mode == 'SHEET':
            row.prop(settings, "chain_columns", text=tr("Columns", "列"))
            row.prop(settings, "chain_across", text="")
        row = chain_box.row(align=True)
        armature_for_chain = settings.target_armature
        if armature_for_chain is not None and armature_for_chain.type == "ARMATURE":
            row.prop_search(settings, "chain_parent", armature_for_chain.data, "bones", text=tr("From", "親"))
        else:
            row.prop(settings, "chain_parent", text=tr("From", "親"))
        row.prop(settings, "chain_feel", text="")
        row = chain_box.row(align=True)
        row.prop(settings, "chain_pivots", text="")
        if settings.chain_pivots == 'TARGET':
            row.prop(settings, "chain_target_mm", text=tr("Spacing", "間隔"))
            row.prop(settings, "chain_root_mm", text=tr("Root", "根元"))
        if settings.chain_pivots == 'RINGS':
            row.prop(settings, "chain_first_ring", text=tr("Skip", "飛ばす"))
            row = chain_box.row(align=True)
            row.prop(settings, "chain_ring_blend", text=tr("Blend", "馴染ませ"))
            row.prop(settings, "chain_ring_min_mm", text=tr("Above", "長さ超"))
            row = chain_box.row(align=True)
            row.prop(settings, "chain_ring_source", text="")
            row.prop(settings, "chain_ring_spacing_mm", text=tr("Min mm", "最短 mm"))
            chain_box.prop(settings, "chain_root_follow", text=tr("Root follows the surface", "根元を周りの面に沿わせる"))
        if settings.chain_pivots not in {'EVEN', 'RINGS'}:
            chain_box.prop(settings, "chain_rigid_match", text=tr("Rigid", "剛体"))
            if settings.chain_pivots == 'TARGET':
                chain_box.prop(settings, "chain_root_span_mm", text=tr("Over", "範囲"))
        chain_box.operator("srs.build_chain", text=tr("Build Chain", "鎖を作る"), icon="BONE_DATA")
        chain_box.prop(settings, "adjust_bones_threshold", text=tr("Only Bones Above", "対象ボーンの下限"))
        col = chain_box.column(align=True)
        col.operator("srs.clear_chain", text=tr("Remove Chain", "鎖を消す"), icon="X")
        col.operator("srs.additive_bones", text=tr("Add Adjust Bones", "加算ボーンを追加"), icon="CON_TRANSLIKE").threshold = settings.adjust_bones_threshold
        chain_box.operator("srs.chain_group_build", text=tr("Pose Selected Chains Together", "選んだ鎖をまとめて動かす"), icon="GROUP_BONE")
        row = chain_box.row(align=True)
        row.prop(settings, "group_key", text="")
        row.operator("srs.chain_group_remove", text="", icon="X")

    strip_box = _child(box, settings, "show_c_strip", "Strip bones (ARP Kilt)", "短冊ボーン（ARP の Kilt）", icon="OUTLINER_DATA_ARMATURE", topic="hair_strip")
    if strip_box is not None:
        row = strip_box.row(align=True)
        row.prop(settings, "strip_name", text=tr("Name", "名前"))
        row.prop(settings, "strip_type_side", text="")
        row = strip_box.row(align=True)
        row.prop(settings, "strip_count", text=tr("Strips", "列"))
        row.prop(settings, "strip_subdiv", text=tr("Bones", "段"))
        strip_box.label(text=tr("Keep off", "避ける"))
        row = strip_box.row(align=True)
        row.prop(settings, "strip_collide_a", text="")
        row.prop(settings, "strip_collide_b", text="")
        row = strip_box.row(align=True)
        row.prop(settings, "strip_on_pleats", text=tr("On the pleats", "ひだに沿わせる"))
        row.prop(settings, "strip_collide_z", text=tr("Collide on Z", "Z でも避ける"))
        sub = strip_box.row(align=True)
        sub.enabled = not settings.strip_on_pleats
        sub.prop(settings, "strip_angles", text=tr("Angles", "角度"))
        strip_box.prop(settings, "strip_blend_mm", text=tr("Top blend mm", "上端のつなぎ mm"))
        strip_box.prop(settings, "strip_top_from_under", text=tr("Top from underneath", "上端は下の服から"))
        sub = strip_box.row(align=True)
        sub.enabled = settings.strip_top_from_under
        sub.prop(settings, "under_part", text="")
        strip_box.operator("srs.strip_rig_build", text=tr("Build Strip Bones", "短冊ボーンを作る"), icon="OUTLINER_DATA_ARMATURE")
        _group(strip_box, "Strips on a raised thigh", "上げた太ももの短冊", "MOD_CLOTH", "hair_kilt_push")
        col = strip_box.column(align=True)
        col.prop(settings, "kilt_push_distance", text=tr("Push Distance", "押しの距離"))
        col.prop(settings, "kilt_push_keep", text=tr("Push Left", "残す押し"))
        col.prop(settings, "kilt_ease_start", text=tr("Ease From", "弱め始め"))
        col.prop(settings, "kilt_ease_end", text=tr("Ease To", "弱め終わり"))
        op = strip_box.operator("srs.kilt_leg_push", text=tr("Strips Lie on a Raised Thigh", "上げた太ももに短冊を乗せる"), icon="MOD_CLOTH")
        op.kilt = str(settings.strip_name).strip() or "kilt"
        op.collide_dist, op.keep = settings.kilt_push_distance, settings.kilt_push_keep
        op.ease_start, op.ease_end = settings.kilt_ease_start, settings.kilt_ease_end
        strip_box.separator()
        _group(strip_box, "Strips Over a Garment", "別の服に重なる短冊", "MOD_ARMATURE", "hair_follow_strips")
        strip_box.label(text=tr("Underneath", "下の服"))
        strip_box.prop(settings, "under_part", text="")
        row = strip_box.row(align=True)
        row.prop(settings, "fstrip_name", text=tr("Name", "名前"))
        row.prop(settings, "fstrip_segments", text=tr("Bones", "段"))
        strip_box.prop(settings, "fstrip_angles", text=tr("Angles", "角度"))
        strip_box.prop(settings, "fstrip_blend_mm", text=tr("Top blend mm", "上端のつなぎ mm"))
        strip_box.operator("srs.follow_strips_build", text=tr("Build Follow Strips", "下に沿う短冊を作る"), icon="MOD_ARMATURE")
        col = strip_box.column(align=True)
        col.prop(settings, "cuff_share", text=tr("Share at the Edge", "端の割合"))
        col.prop(settings, "cuff_fade_mm", text=tr("Fade mm", "弱める長さ mm"))
        col = strip_box.column(align=True)
        op = col.operator("srs.cuff_swing_build", text=tr("Cuff L Follows the Bend", "左袖口を曲げに沿わせる"), icon="CON_TRACKTO")
        op.forearm, op.hand = "forearm_stretch.l", "hand.l"
        op.share, op.fade_mm = settings.cuff_share, settings.cuff_fade_mm
        op = col.operator("srs.cuff_swing_build", text=tr("Cuff R", "右袖口"), icon="CON_TRACKTO")
        op.forearm, op.hand = "forearm_stretch.r", "hand.r"
        op.share, op.fade_mm = settings.cuff_share, settings.cuff_fade_mm

    band_box = _child(box, settings, "show_c_band", "Band Round a Limb", "腕や脚に巻かれた帯", icon="MOD_SIMPLEDEFORM", topic="hair_band")
    if band_box is not None:
        row = band_box.column(align=True)
        row.prop(settings, "band_uv_axis", text="")
        row.prop(settings, "band_min_width_mm", text=tr("Min width mm", "最小幅 mm"))
        row = band_box.row(align=True)
        row.prop(settings, "band_lock_hard", text=tr("Hard parts rigid", "金具は剛体"))
        row.prop(settings, "rigid_material", text="")
        band_box.operator("srs.band_width_lock", text=tr("Keep Band Width", "帯の幅を保つ"), icon="MOD_EDGESPLIT")
        row = band_box.column(align=True)
        row.prop(settings, "band_mirror_source", text="")
        row.operator("srs.band_mirror", text=tr("Mirror Band Weights", "帯の重みを左右反転"), icon="MOD_MIRROR")

    hard_box = _child(box, settings, "show_c_hard", "Hard Parts & Bones", "固い部品・骨の族", icon="MOD_MASK", topic="hair_hard")
    if hard_box is not None:
        row = hard_box.row(align=True)
        row.prop(settings, "rigid_material", text="")
        row.prop(settings, "rigid_donor", text="")
        hard_box.operator("srs.rigidify_material", text=tr("Rigid by Material", "材質で剛体化"), icon="SNAP_VERTEX")
        row = hard_box.row(align=True)
        row.prop(settings, "drop_families", text="")
        row.operator("srs.drop_families", text=tr("Drop", "外す"), icon="X")
        row = hard_box.column(align=True)
        row.prop(settings, "follow_only_joint", text="")
        if settings.follow_only_joint == 'CUSTOM':
            row.prop(settings, "follow_only_family", text="")
            row.prop(settings, "follow_only_heir", text="")
        row.operator("srs.follow_only", text=tr("Stop Following", "追従を切る"), icon="UNLINKED")

    layer_box = _child(box, settings, "show_c_layers", "Layers & Penetration", "重ね着・めり込み", icon="MOD_CLOTH", topic="hair_layers")
    if layer_box is not None:
        layer_box.prop(settings, "under_part", text="")
        row = layer_box.column(align=True)
        row.operator("srs.bind_over", text=tr("Bind Over Layer", "下に合わせる"), icon="MOD_DATA_TRANSFER")
        row.operator("srs.penetration_check", text=tr("Check Penetration", "めり込み検査"), icon="MOD_MASK")
        row = layer_box.column(align=True)
        row.prop(settings, "keep_outside_mm", text=tr("Clearance", "隙間"))
        row.operator("srs.clear_contact", text=tr("Clear Contact", "接触を逃がす"), icon="MOD_NORMALEDIT")
        row = layer_box.row(align=True)
        row.operator("srs.keep_outside", text=tr("Keep Outside", "外に保つ"), icon="MOD_SHRINKWRAP")
        row.operator("srs.keep_outside", text="", icon="X").remove = True


def _draw_physics(box, context, settings, snapshot):
    col_box = _child(box, settings, "show_c_collide", "Collision", "当たり判定", icon="MOD_PHYSICS", topic="physics_collide")
    if col_box is not None:
        row = col_box.row(align=True)
        row.prop(settings, "collide_skin", text="")
        row.prop(settings, "collide_face", text="")
        row = col_box.column(align=True)
        row.prop(settings, "collide_mesh_c", text="")
        row.prop(settings, "collide_mesh_d", text="")
        row.prop(settings, "collide_mesh_e", text="")
        row = col_box.row(align=True)
        row.prop(settings, "collide_percentile", text=tr("Radius %", "半径%"))
        row.prop(settings, "collide_inset", text=tr("Grow", "膨らませ"))
        row = col_box.column(align=True)
        row.prop(settings, "collide_split", text=tr("Split Wide", "幅広を分割"))
        row.prop(settings, "collide_toes", text=tr("Toes", "足指"))
        row = col_box.row(align=True)
        row.operator("srs.fit_colliders", text=tr("Fit Capsules", "カプセルを合わせる"), icon="META_CAPSULE")
        row.operator("srs.clear_colliders", text="", icon="X")
        row = col_box.column(align=True)
        row.prop(settings, "part_name", text=tr("Part", "部品"))
        row.operator("srs.colliders_fit_without", text=tr("Fit Without Part", "部品を外した判定"), icon="MOD_PHYSICS")
        row = col_box.column(align=True)
        _rig = settings.target_armature
        row.enabled = bool(bpy.data.collections.get("SRS Collision Proxy")) or bool(
            _rig is not None and _rig.type == "ARMATURE" and _rig.data.collections_all.get("SRS Colliders"))
        row.operator("srs.colliders_display", text=tr("Show Colliders", "判定を表示"), icon="HIDE_OFF").show = True
        row.operator("srs.colliders_display", text=tr("Hide Colliders", "判定を隠す"), icon="HIDE_ON").show = False
        col_box.prop(settings, "collide_sides", text=tr("Sides", "面数"))
        row = col_box.row(align=True)
        row.operator("srs.collision_proxy", text=tr("Build Meshes", "判定メッシュ"), icon="MESH_CAPSULE")
        row.operator("srs.clear_collision_proxy", text="", icon="X")
        col_box.prop(settings, "chain_collide", text=tr("Collide", "判定する"))
        sub = col_box.column(align=True)
        sub.enabled = settings.chain_collide
        sub.prop(settings, "chain_collide_mm", text=tr("Thickness", "太さ"))
        sub.prop(settings, "chain_collide_sweeps", text=tr("Quality", "品質"))

    jig_box = _child(box, settings, "show_c_jiggle", "Bake Jiggle", "揺れを焼く", icon="PHYSICS", topic="physics_jiggle")
    if jig_box is not None:
        from . import jiggle
        rig = settings.target_armature
        bone = getattr(context, "active_pose_bone", None)
        root = None
        if rig is not None and bone is not None and bone.id_data == rig:
            root = jiggle.chain_root(rig, bone.name)
        if root is not None:
            chain_box = jig_box.box()
            _group(chain_box, root.name[:-3], root.name[:-3], "BONE_DATA", "physics_jiggle_chain")
            for key, en, ja in ((jiggle.CHAIN_STIFFNESS, "Stiffness", "剛性"),
                                (jiggle.CHAIN_DAMPING, "Damping", "減衰"),
                                (jiggle.CHAIN_GRAVITY, "Weight", "重さ"),
                                (jiggle.CHAIN_INERTIA, "Drag", "ドラッグ")):
                if key in root.keys():
                    chain_box.prop(root, '["%s"]' % key, text=tr(en, ja))
            if bool(root.get(jiggle.CHAIN_BAKE, True)):
                chain_box.label(text=tr("In the bake: yes", "焼きに含める：はい"), icon="CHECKBOX_HLT")
            else:
                chain_box.label(text=tr("In the bake: no", "焼きに含める：いいえ"), icon="CHECKBOX_DEHLT")
            if bool(root.get(jiggle.CHAIN_MUTED, False)):
                chain_box.label(text=tr("Baked swing: off", "焼いた揺れ：止めている"), icon="MUTE_IPO_ON")
            if "srs_jiggle_collide" in root.keys():
                chain_box.label(text=tr("Collision: on", "判定：する") if root["srs_jiggle_collide"]
                                else tr("Collision: off", "判定：しない"), icon="MOD_PHYSICS")
            if jiggle.CHAIN_SWING in root.keys():
                chain_box.label(text=tr("Swing layer: on", "揺れの層：あり"), icon="CON_ROTLIKE")
                switch = str(root.get(jiggle.CHAIN_SWING_SWITCH, ""))
                if switch and switch in rig.keys():
                    chain_box.prop(rig, '["%s"]' % switch, text=tr("Switch", "切替"))
            chain_box.label(text=tr("Gravity", "重力"))
            row = chain_box.row(align=True)
            on = bool(root.get(jiggle.CHAIN_GRAVITY_REST, False))
            row.operator("srs.jiggle_chain_gravity_rest", text=tr("From Rest Shape", "静止の形から"),
                         depress=on).state = 'ON'
            row.operator("srs.jiggle_chain_gravity_rest", text=tr("Straight Down", "真下へ"),
                         depress=not on).state = 'OFF'
            chain_box.prop(settings, "chain_thickness_percentile", text=tr("Percentile", "割合"))
            radii = root.get(jiggle.CHAIN_LINK_RADII)
            chain_box.label(text=(tr("Thickness: up to %.0f mm", "太さ：最大 %.0f mm") % (max(radii) * 1000)) if radii
                            else tr("Thickness: a line", "太さ：線"))
            row = chain_box.row(align=True)
            op = row.operator("srs.jiggle_chain_thickness", text=tr("Measure", "測る"))
            op.action, op.percentile = 'MEASURE', settings.chain_thickness_percentile
            row.operator("srs.jiggle_chain_thickness", text=tr("Clear", "消す")).action = 'CLEAR'
            chain_box.label(text=tr("Entry", "入り込み"))
            row = chain_box.row(align=True)
            push = bool(root.get(jiggle.CHAIN_ENTRY_PUSH, False))
            row.operator("srs.jiggle_chain_entry_push", text=tr("Push on Entry", "すぐ押し出す"), depress=push).state = 'ON'
            row.operator("srs.jiggle_chain_entry_push", text=tr("Ease Out", "ゆっくり抜く"), depress=not push).state = 'OFF'
            chain_box.label(text=tr("Capsules", "カプセル"))
            row = chain_box.row(align=True)
            clear = bool(root.get(jiggle.CHAIN_REST_CLEAR, False))
            row.operator("srs.jiggle_chain_rest_clear", text=tr("Keep Rest Clear", "静止を避ける"),
                         depress=clear).state = 'ON'
            row.operator("srs.jiggle_chain_rest_clear", text=tr("Full Size", "そのまま"),
                         depress=not clear).state = 'OFF'
            row = chain_box.row(align=True)
            row.label(text=tr("Collision", "判定"))
            row.operator("srs.jiggle_chain_collide", text=tr("Panel", "パネル")).state = 'DEFAULT'
            row.operator("srs.jiggle_chain_collide", text=tr("On", "する")).state = 'ON'
            row.operator("srs.jiggle_chain_collide", text=tr("Off", "しない")).state = 'OFF'
        parts = jiggle.part_motion_state(rig) if rig is not None and rig.type == "ARMATURE" else []
        if rig is not None and rig.type == "ARMATURE":
            part_box = jig_box.box()
            _group(part_box, "Parts: Sim or Hand", "部品：シミュか手付けか", "GROUP_BONE", "physics_parts")
            row = part_box.row(align=True)
            row.prop(settings, "part_motion_name", text=tr("Part Name", "部品名"))
            sub = row.row(align=True)
            sub.enabled = bool(settings.part_motion_name.strip())
            op = sub.operator("srs.part_motion_register", text=tr("Register", "登録"), icon="ADD")
            op.part, op.chains = settings.part_motion_name.strip(), settings.jiggle_named_chains
            if parts and parts[0].get("state") == "unknown":
                _msg(part_box, tr("Action slot unknown: nothing can be switched", "アクションのスロットが不明：切り替えできません"), "ERROR")
                parts = []
            for state in parts:
                row = part_box.row(align=True)
                row.label(text=state["label"], translate=False)
                for mode in state["modes"]:
                    text = {"sim": tr("Sim", "シミュ"), "hand": tr("Hand", "手付け")}.get(mode, mode)
                    icon = {"sim": "PHYSICS", "hand": "HAND"}.get(mode, "NONE")
                    op = row.operator("srs.part_motion", text=text, icon=icon, depress=(state["mode"] == mode), translate=False)
                    op.part, op.mode = state["part"], mode
                op = row.operator("srs.part_bake", text="", icon="KEYFRAME")
                op.part, op.frame_start, op.frame_end = state["part"], settings.part_bake_start, settings.part_bake_end
                row.operator("srs.part_motion_unregister", text="", icon="X").part = state["part"]
            if parts:
                row = part_box.column(align=True)
                row.prop(settings, "part_bake_start", text=tr("Bake Start", "焼きの開始"))
                row.prop(settings, "part_bake_end", text=tr("Bake End", "焼きの終了"))
        named = settings.jiggle_named_chains
        jig_box.prop(settings, "jiggle_named_chains", text=tr("Chains", "鎖の名前"))
        by_name = bool(named.strip())
        row = jig_box.column(align=True)
        op = row.operator("srs.jiggle_chain_include", text=tr("Include Named", "名前で含める") if by_name else tr("Include Selected", "選択を含める"), icon="CHECKBOX_HLT")
        op.include, op.chains = True, named
        op = row.operator("srs.jiggle_chain_include", text=tr("Exclude Named", "名前で外す") if by_name else tr("Leave Out Selected", "選択を外す"), icon="CHECKBOX_DEHLT")
        op.include, op.chains = False, named
        row = jig_box.row(align=True)
        op = row.operator("srs.jiggle_mute", text=tr("Stop Swing", "揺れを止める"), icon="MUTE_IPO_ON")
        op.mute, op.chains = True, named
        op = row.operator("srs.jiggle_mute", text=tr("Play Swing", "揺れを戻す"), icon="MUTE_IPO_OFF")
        op.mute, op.chains = False, named
        row = jig_box.row(align=True)
        row.prop(settings, "roll_arms", text=tr("Arms", "腕"))
        row.prop(settings, "roll_body_bones", text=tr("Body", "体"))
        jig_box.prop(settings, "roll_midline", text=tr("Centre on the Midline", "体の中心面に置く"))
        jig_box.prop(settings, "roll_along_chains", text=tr("Along Chains", "鎖に沿って"))
        col = jig_box.column(align=True)
        op = col.operator("srs.umbrella_rolls", text=tr("Roll: Open as a Ring", "向き：輪で外へ"), icon="ORIENTATION_GIMBAL")
        op.centre, op.arms, op.body_bones = 'ring', settings.roll_arms, settings.roll_body_bones
        op.midline, op.along_chains = settings.roll_midline, settings.roll_along_chains
        op = col.operator("srs.umbrella_rolls", text=tr("Roll: Away from Body", "向き：体から外へ"), icon="ORIENTATION_NORMAL")
        op.centre, op.arms, op.body_bones = 'body', settings.roll_arms, settings.roll_body_bones
        op.midline, op.along_chains = settings.roll_midline, settings.roll_along_chains
        col = jig_box.column(align=True)
        col.prop(settings, "swing_switch", text=tr("Switch", "切替"))
        col.prop(settings, "swing_value", text=tr("Value", "値"))
        col = jig_box.column(align=True)
        op = col.operator("srs.jiggle_swing_layer", text=tr("Add Swing Layer", "揺れの層を付ける"), icon="CON_ROTLIKE")
        op.switch, op.value, op.remove, op.chains = settings.swing_switch, settings.swing_value, False, named
        op = col.operator("srs.jiggle_swing_layer", text=tr("Remove Swing Layer", "揺れの層を外す"), icon="X")
        op.remove, op.chains = True, named
        row = jig_box.row(align=True)
        row.prop(settings, "chain_floor", text=tr("Floor", "床で止める"))
        sub = row.row(align=True)
        sub.enabled = settings.chain_floor
        sub.prop(settings, "chain_floor_z", text=tr("Height", "高さ"))
        jig_box.label(text=tr("Clear Prefix", "消す鎖の接頭辞"))
        jig_box.prop(settings, "jiggle_clear_prefix", text="")
        row = jig_box.row(align=True)
        sub = row.row(align=True)
        sub.enabled = not by_name
        sub.prop(settings, "jiggle_clear_use_selection", text=tr("Use Selection", "選択を使う"))
        row.prop(settings, "jiggle_clear_only_baked", text=tr("Only Baked Keys", "焼いたキーだけ"))
        row = jig_box.row(align=True)
        row.operator("srs.jiggle_bake", text=tr("Bake Jiggle", "揺れを焼く"), icon="PHYSICS")
        op = row.operator("srs.jiggle_clear", text=tr("Clear Jiggle", "揺れを消す"), icon="X")
        op.chains, op.prefix = named, settings.jiggle_clear_prefix
        op.use_selection, op.only_baked = settings.jiggle_clear_use_selection, settings.jiggle_clear_only_baked

    cloth_box = _child(box, settings, "show_c_cloth", "Cloth Simulation", "クロスの選択肢", icon="MOD_CLOTH", topic="physics_cloth")
    if cloth_box is not None:
        row = cloth_box.column(align=True)
        row.prop(settings, "cloth_band_mm", text=tr("Pinned mm", "固定 mm"))
        row.prop(settings, "cloth_feather_mm", text=tr("Fade mm", "減衰 mm"))
        cloth_box.label(text=tr("Lands On", "当たる相手"))
        cloth_box.prop(settings, "cloth_collider", text="")
        cloth_box.label(text=tr("Also Lands On", "もう一つの相手"))
        cloth_box.prop(settings, "cloth_collider_2", text="")
        cloth_box.prop(settings, "cloth_only_listed", text=tr("Only These (not the hair capsules)", "この相手だけ（髪のカプセルなし）"))
        op = cloth_box.operator("srs.cloth_setup", text=tr("Add Cloth Alternative", "クロスの選択肢を追加"), icon="MOD_CLOTH")
        op.band_mm = settings.cloth_band_mm
        op.feather_mm = settings.cloth_feather_mm
        op.collide_with = settings.cloth_collider.name if settings.cloth_collider is not None else ""
        op.collide_with_2 = settings.cloth_collider_2.name if settings.cloth_collider_2 is not None else ""
        op.only_these = settings.cloth_only_listed
        rig = _skirt_switch_rig(context, settings)
        owner, switch_name = cloth_setup.find_switch(rig)
        if owner is not None:
            current = cloth_setup.switch_value(owner, switch_name)
            cloth_box.label(text=tr("Skirt", "スカート") + " (" + switch_name + ")", translate=False)
            col = cloth_box.column(align=True)
            built_in = {0: tr("Bones", "ボーン"), 1: tr("Cloth", "クロス")}
            for value, label in cloth_setup.switch_states(owner, switch_name):
                if switch_name == cloth_setup.SWITCH_PROPERTY:
                    label = built_in.get(value, label)
                text = "%d: %s" % (value, label) if label else str(value)
                op = col.operator("srs.skirt_mode_set", text=text, translate=False, depress=(current == value))
                op.armature = rig.name
                op.property_name = switch_name
                op.value = value
        cloth_box.operator("srs.cloth_remove", text=tr("Remove Cloth", "クロスを外す"), icon="X")


def _skirt_switch_rig(context, settings):
    """The rig whose skirt switch the cloth section shows: the panel's rig, else the active
    armature, else the armature that deforms the active mesh. Cheap enough for draw()."""
    rig = settings.target_armature
    if rig is not None and rig.type == "ARMATURE":
        return rig
    obj = getattr(context, "active_object", None)
    if obj is None:
        return None
    if obj.type == "ARMATURE":
        return obj
    try:
        return obj.find_armature()
    except (AttributeError, RuntimeError):
        return None


def _draw_animation(box, context, settings, snapshot):
    available = snapshot.operator_available("pose.arp_arm_fk_to_ik_")
    ik_box = _child(box, settings, "show_c_ikfk", "IK/FK and snapping", "IK/FKとスナップ", icon="ARROW_LEFTRIGHT", topic="anim_ikfk")
    if ik_box is not None:
        col = ik_box.column(align=True)
        col.enabled = available
        col.operator("srs.ikfk_switch", text=tr("Switch IK/FK (keep pose)", "IK/FKを切り替え（姿勢を保つ）"), icon="ARROW_LEFTRIGHT")
        col.prop(settings, "ikfk_key_switch", text=tr("Key", "キー"))
        col.operator("srs.ikfk_step_keys", text=tr("Make IK/FK Keys Steps", "IK/FKの切替キーを段階補間にする"), icon="IPO_CONSTANT")
        row = col.row(align=True)
        row.prop(settings, "ikfk_mode", text="")
        row.operator("srs.arp_ikfk_safe", text=tr("Run IK/FK", "IK/FKを実行"), icon="PLAY")
        row = col.row(align=True)
        row.prop(settings, "snap_mode", text="")
        row.operator("srs.arp_snap_safe", text=tr("Run Snap", "スナップを実行"), icon="SNAP_ON")
        row = col.column(align=True)
        op = row.operator("srs.arp_pose_utility", text=tr("Reset Pose", "ポーズをリセット"))
        op.mode = "RESET"
        op = row.operator("srs.arp_pose_utility", text=tr("Extract Root Motion", "ルートモーション抽出"))
        op.mode = "EXTRACT_ROOT"
        op = row.operator("srs.arp_pose_utility", text=tr("Clear Root Motion", "ルートモーションをクリア"))
        op.mode = "CLEAR_ROOT"
        if not available:
            ik_box.label(text=tr("External rig tools are not available.", "外部リグツールを利用できません。"), icon="ERROR")

    mocap_box = _child(box, settings, "show_c_mocap", "Motion Capture", "モーションキャプチャー", icon="ARMATURE_DATA", topic="anim_mocap")
    if mocap_box is not None:
        mocap_box.prop(settings, "mocap_file", text="")
        row = mocap_box.row(align=True)
        row.prop(settings, "mocap_preset", text="")
        row.prop(settings, "mocap_frame_end", text=tr("To", "終"))
        row = mocap_box.row(align=True)
        row.prop(settings, "mocap_fingers", text=tr("Fingers", "指も"))
        row.operator("srs.mocap_load", text=tr("Load & Bake", "読込んで焼く"), icon="IMPORT")
        row = mocap_box.row(align=True)
        row.prop(settings, "mocap_check_step", text=tr("Every", "間隔"))
        row.operator("srs.mocap_check", text=tr("Check Motion", "動きを検査"), icon="CHECKMARK")

    shoulder_box = _child(box, settings, "show_c_shoulder_limit", "Shoulder Limit", "肩の上がりを制限",
                          icon="CON_ROTLIMIT", topic="anim_shoulder_limit")
    if shoulder_box is not None:
        col = shoulder_box.column(align=True)
        col.prop(settings, "shoulder_lift_per_degree", text=tr("Lift Per Degree", "腕1度あたりの上がり"))
        col.prop(settings, "shoulder_soft_deg", text=tr("Soft Start", "なめらかな立ち上がり"))
        row = shoulder_box.row(align=True)
        row.operator("srs.shoulder_limit_install", text=tr("Limit The Shoulders", "肩を制限"), icon="CON_ROTLIMIT")
        row.operator("srs.shoulder_limit_remove", text=tr("Remove", "外す"), icon="TRASH")
        info = shoulder_lift.state(_skirt_switch_rig(context, settings))
        if info is None:
            shoulder_box.label(text=tr("Not set on this rig.", "このリグには入っていません。"))
        else:
            sides = ", ".join("c_shoulder" + side for side in info["sides"])
            shoulder_box.label(text=tr("On: ", "入：") + sides, icon="CHECKMARK")


def _draw_proxy(layout, context, settings, snapshot, *, section_box=_SECTION_BOX_UNSET):
    box = _section(layout, settings, "show_proxy", "Display, Selection & Rig UI", "表示・選択・リグUI", icon="RESTRICT_SELECT_OFF", topic="proxy") if section_box is _SECTION_BOX_UNSET else section_box
    if box is None:
        return
    available = snapshot.operator_available("pp.auto_proxy")
    role_box = _child(box, settings, "show_c_proxy_roles", "Proxy Picker Workflow",
                      "Proxy Pickerワークフロー", icon="RESTRICT_SELECT_OFF", topic="proxy_roles")
    if role_box is not None:
        _draw_proxy_roles(role_box, context, settings, available)
    if not available:
        _warn_note(box, "Enable the external Proxy Picker add-on to use assignment operations.", "割り当て操作を使うには外部Proxy Pickerアドオンを有効化してください。")
    audit_box = _child(box, settings, "show_c_proxy_audit", "Mapping Backup & Check",
                       "対応のバックアップ・検証", icon="CHECKMARK", topic="proxy_audit")
    if audit_box is not None:
        _draw_proxy_audit(audit_box, settings)


def _draw_proxy_roles(role_box, context, settings, available):
    role_box.enabled = available
    row = role_box.column(align=True)
    op = row.operator("srs.proxy_external_action", text=tr("Assign Proxy", "プロキシ割り当て"), icon="BONE_DATA")
    op.action = "AUTO_PROXY"
    op = row.operator("srs.proxy_external_action", text=tr("Add Script Button", "スクリプトボタン追加"))
    op.action = "BUTTON"
    op = row.operator("srs.proxy_external_action", text=tr("Delete Role", "役割を削除"), icon="TRASH")
    op.action = "DELETE"
    role_box.operator("srs.proxy_set_collection_button", text=tr("Set Bone Collection Button", "ボーンコレクションボタン設定"))
    preferences = get_preferences(context)
    if preferences is not None:
        row = role_box.column(align=True)
        row.prop(preferences, "proxy_prefix", text=tr("Proxy", "プロキシ"))
        row.prop(preferences, "target_prefix", text=tr("Target", "ターゲット"))
    role_box.operator("srs.proxy_batch_pair", text=tr("Batch Pair by Name", "名前規則で一括ペア設定"), icon="PLAY")


def _draw_proxy_audit(audit_box, settings):
    row = audit_box.row(align=True)
    row.operator("srs.proxy_audit", text=tr("Audit", "監査"), icon="VIEWZOOM")
    row.operator("srs.proxy_repair", text=tr("Repair Stale", "古い参照を修復"))
    audit_box.label(text=tr("Proxy Map Text", "プロキシ対応Text"))
    audit_box.prop(settings, "proxy_text_name", text="")
    row = audit_box.column(align=True)
    row.operator("srs.proxy_export", text=tr("Export Proxy Map", "プロキシ対応を書き出し"), icon="EXPORT")
    row.operator("srs.proxy_import", text=tr("Import Proxy Map", "プロキシ対応を読み込み"), icon="IMPORT")


def _draw_ai(layout, context, settings, snapshot, *, section_box=_SECTION_BOX_UNSET):
    box = _section(layout, settings, "show_ai", "AI Runtime Integration", "AIランタイム連携", icon="SYSTEM", topic="ai") if section_box is _SECTION_BOX_UNSET else section_box
    if box is None:
        return
    preferences = get_preferences(context)
    if preferences is None:
        _msg(box, tr("Smart Rig Suite preferences are unavailable.", "Smart Rig Suite設定を取得できません。"), "ERROR")
        return
    box.label(text=tr("AI Runtime Path", "AIランタイムパス"))
    box.prop(preferences, "ai_runtime_path", text="")
    status = snapshot.status.ai_runtime
    if status.valid:
        runtime_label = f"v{status.version}" if status.version else tr("Runtime valid", "ランタイム有効")
    elif status.version and not status.version_ok:
        runtime_label = tr("Runtime version is older than 1.20", "ランタイムのバージョンが1.20未満です")
    else:
        runtime_label = tr("Runtime incomplete", "ランタイム不完全")
    box.label(text=runtime_label, icon="CHECKMARK" if status.valid else "ERROR")
    if status.valid and not status.platform_compatible:
        _msg(box, tr("AI_win execution is available on Windows x64.", "AI_winの実行はWindows x64で利用できます。"))
    row = box.row(align=True)
    row.operator("srs.ai_auto_detect", text=tr("Auto-detect", "自動検出"), icon="VIEWZOOM")
    row.operator("srs.ai_validate", text=tr("Validate", "検証"))
    row = box.column(align=True)
    row.operator("srs.ai_sync_arp", text=tr("Synchronize to Auto-Rig Pro", "Auto-Rig Proへ同期"))
    row.operator("srs.ai_open_folder", text=tr("Open Folder", "フォルダーを開く"), icon="FILE_FOLDER")
    box.prop(preferences, "auto_sync_ai_path")
    box.separator()
    row = box.row(align=True)
    op = row.operator("srs.arp_marker_ai", text=tr("Body", "ボディ"), icon="PLAY")
    op.kind = "BODY"
    op = row.operator("srs.arp_marker_ai", text=tr("Fingers", "指"), icon="PLAY")
    op.kind = "FINGERS"
    op = row.operator("srs.arp_marker_ai", text=tr("Facial", "フェイシャル"), icon="PLAY")
    op.kind = "FACIAL"


def _draw_data(layout, context, settings, *, section_box=_SECTION_BOX_UNSET):
    box = _section(layout, settings, "show_data", "Data, Validation & Settings", "データ・検証・設定", icon="CHECKMARK", topic="data") if section_box is _SECTION_BOX_UNSET else section_box
    if box is None:
        return
    box.operator("srs.full_audit", text=tr("Full Rig Workflow Audit", "リグワークフロー総合監査"), icon="VIEWZOOM")
    if settings.last_report_text:
        box.label(text=tr("Last report: ", "最新レポート: ") + settings.last_report_text, icon="TEXT")
    box.label(text=tr("JSON Report Path", "JSONレポートパス"))
    box.prop(settings, "export_report_path", text="")
    box.operator("srs.export_integration_report", text=tr("Export Integration Report", "連携レポートを書き出し"), icon="EXPORT")
    box.separator()
    migration = migration_status()
    runtime_removed = sum(migration["runtime"].values())
    payload_removed = sum(migration["payload"].values())
    if runtime_removed or payload_removed:
        _msg(box, tr("Previous embedded runtime was removed during startup.", "起動時に旧内蔵ランタイムを除去しました。"), "CHECKMARK")
    box.operator("srs.clean_legacy_scene_data", text=tr("Clean Legacy Embedded Data", "旧内蔵版データを整理"), icon="TRASH")
    compare_box = _child(box, settings, "show_c_compare", "Compare Two", "2 つを比べる",
                         icon="ARROW_LEFTRIGHT", topic="data_compare")
    if compare_box is not None:
        _draw_compare(compare_box, settings)


def _compare_line(info) -> tuple[str, str]:
    """The one line under Compare: (text, icon)."""
    state = info["state"]
    if state == "running":
        phase = {"first": tr("first", "1 つ目"), "second": tr("second", "2 つ目"),
                 "shape": tr("shape", "形")}.get(info["phase"]) or tr("starting", "起動中")
        text = tr("Comparing: ", "比較中：") + phase
        if info["total"]:
            text += " %d/%d" % (info["done"], info["total"])
        return text + tr(" · %d s", "・%d 秒") % info["seconds"], "TIME"
    if state == "failed":
        return report_ja(info["error"]), "ERROR"
    if state == "done":
        numbers = compare.summary(info["result"])
        shape = "-" if numbers["shape_mm"] is None else "%.3f mm" % numbers["shape_mm"]
        if not (numbers["changed"] or numbers["only_a"] or numbers["only_b"]):
            return tr("No difference (ID %d · shape %s)", "違いはありません（ID %d・形の最大差 %s）") % (numbers["ids"], shape), "CHECKMARK"
        types = ", ".join("%s %d" % item for item in numbers["types"][:3]) or "-"
        text = tr("Changed IDs %d (%s) · added %d · removed %d · shape %s",
                  "変わった ID %d（%s）・増 %d・減 %d・形の最大差 %s") % (
            numbers["changed"], types, numbers["only_b"], numbers["only_a"], shape)
        if numbers["runtime_items"]:
            largest = "-" if numbers["runtime_max"] is None else "%.3g" % numbers["runtime_max"]
            text += tr(" · evaluated pose %d (largest %s)", "・評価後の姿勢 %d 項目（最大差 %s）") % (numbers["runtime_items"], largest)
        return text, "ERROR"
    if state == "snapshot":
        return tr("Snapshot %s · frame %s", "控え %s・フレーム %s") % (info["time"], info["frame"]), "FILE_BLEND"
    return tr("No snapshot of this file yet.", "このファイルの控えはまだありません。"), "BLANK1"


def _draw_compare(box, settings):
    running = compare.is_running()
    row = box.row(align=True)
    row.enabled = not running
    row.operator("srs.compare_snapshot_take", text=tr("Take A Snapshot", "控えを取る"), icon="FILE_BLEND")
    box.label(text=tr("Other File (empty: the snapshot)", "比べる相手のファイル（空なら控え）"))
    row = box.row(align=True)
    row.enabled = not running
    row.prop(settings, "compare_file", text="")
    if running:
        box.operator("srs.compare_with_file", text=tr("Stop", "止める"), icon="CANCEL")
    else:
        box.operator("srs.compare_with_file", text=tr("Compare", "比べる"), icon="ARROW_LEFTRIGHT")
    text, icon = _compare_line(compare.status())
    box.label(text=text, icon=icon)
    col = box.column(align=True)
    col.enabled = not running
    col.prop(settings, "compare_skip", text=tr("Skip", "除く項目"))
    col.prop(settings, "compare_digits", text=tr("Digits", "桁数"))
    box.label(text=tr("Result Folder", "結果の書き出し先"))
    box.prop(settings, "compare_export_dir", text="")
    box.operator("srs.compare_export", text=tr("Write The Result", "結果を書き出す"), icon="EXPORT")


def _manager_allows(context) -> bool:
    # The Manager owns the 11-physical/17-logical editor classification. These
    # fixed module lookups never import, scan, or mutate another add-on.
    for module_name in (
        "bl_ext.user_default.smart_tools_manager",
        "smart_tools_manager",
    ):
        manager = sys.modules.get(module_name)
        callback = getattr(manager, "placement_allowed", None)
        if not callable(callback):
            continue
        try:
            return bool(callback("SMART_RIG", context))
        except Exception:
            return True
    return True


def _root_header_help(self, _context):
    # the panel's own header: "?" at its right end opens the Smart Rig overview
    op = self.layout.operator(SRS_OT_show_section_help.bl_idname, text="", icon="QUESTION", emboss=False)
    op.topic = "overview"


class SRS_PT_smart_rig(bpy.types.Panel):
    bl_idname = "SRS_PT_smart_rig"
    bl_label = "Smart Rig"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Smart Rig"
    bl_options = set()

    # The Manager may evaluate this panel with no active object. Keeping the
    # source panel eligible avoids proxy/category reconstruction during reload.
    _smart_tools_manager_native_npanel_root = True
    _smart_tools_manager_tool_key = "SMART_RIG"
    _smart_tools_manager_no_active_object_required = True

    @classmethod
    def poll(cls, context):
        area = getattr(context, "area", None)
        if str(getattr(area, "type", "") or "") != cls.bl_space_type:
            return False
        return _manager_allows(context)

    draw_header_preset = _root_header_help

    def draw(self, context):
        layout = self.layout
        scene = getattr(context, "scene", None)
        settings = getattr(scene, "srs_settings", None) if scene is not None else None
        if settings is None:
            _msg(
                layout,
                tr(
                    "Smart Rig Suite settings are not registered.",
                    "Smart Rig Suite設定が登録されていません。",
                ),
                "ERROR",
            )
            return

        preferences = get_preferences(context)
        configured_ai = str(getattr(preferences, "ai_runtime_path", "") or "") if preferences else ""
        snapshot = get_ui_status(configured_ai)

        section_specs = (
            ("ui_section_always_on", "Always-on Toggles", "常時機能切り替え", "TIME", "always_on", lambda box: _draw_always_on(None, context, settings, section_box=box)),
            ("show_external", "1. Setup and Parts", "1. 準備とパーツ", "PLUGIN", "setup", lambda box: _draw_setup(box, context, settings, snapshot)),
            ("show_body", "2. Body Rig (Auto-Rig Pro)", "2. 体のリグ（ARP）", "ARMATURE_DATA", "body", lambda box: _draw_body(box, context, settings, snapshot)),
            ("show_face", "3. Face and Eyes", "3. 顔と目", "HIDE_OFF", "face", lambda box: _draw_face(box, context, settings, snapshot)),
            ("show_hair", "4. Hair, Costume & Hard Parts", "4. 髪・衣装・固い部品", "OUTLINER_OB_CURVES", "hair", lambda box: _draw_hair(box, context, settings, snapshot)),
            ("show_physics", "5. Jiggle, Collision & Cloth", "5. 揺れ・当たり判定・クロス", "PHYSICS", "physics", lambda box: _draw_physics(box, context, settings, snapshot)),
            ("show_animation", "6. Animation", "6. アニメーション", "ACTION", "animation", lambda box: _draw_animation(box, context, settings, snapshot)),
            ("show_proxy", "Display, Selection & Rig UI", "表示・選択・リグUI", "RESTRICT_SELECT_OFF", "proxy", lambda box: _draw_proxy(None, context, settings, snapshot, section_box=box)),
            ("show_ai", "AI Runtime Integration", "AIランタイム連携", "SYSTEM", "ai", lambda box: _draw_ai(None, context, settings, snapshot, section_box=box)),
            ("show_data", "Data, Validation & Settings", "データ・検証・設定", "CHECKMARK", "data", lambda box: _draw_data(None, context, settings, section_box=box)),
        )
        top_slots = tuple(layout.row(align=False) for _unused in section_specs)
        top_boxes = tuple(slot.box() for slot in top_slots)
        prepared_sections = tuple(
            (
                _section(
                    slot,
                    settings,
                    prop_name,
                    title_en,
                    title_ja,
                    icon=icon,
                    topic=topic,
                    container=box,
                ),
                draw_body,
            )
            for slot, box, (prop_name, title_en, title_ja, icon, topic, draw_body)
            in zip(top_slots, top_boxes, section_specs)
        )
        for section_box, draw_body in prepared_sections:
            if section_box is not None:
                draw_body(section_box)


def _make_editor_root(class_name: str, space_type: str, region_type="UI", editor_keys=()) -> type:
    @classmethod
    def poll(cls, context):
        area = getattr(context, "area", None)
        if str(getattr(area, "type", "") or "") != cls.bl_space_type:
            return False
        if editor_keys:
            space = getattr(context, "space_data", None) or getattr(getattr(area, "spaces", None), "active", None)
            is_asset = any(value in {"ASSETS", "ASSET_BROWSER"} for value in (
                getattr(area, "ui_type", None), getattr(space, "browse_mode", None)
            ))
            if ("ASSET_BROWSER" if is_asset else "FILE_BROWSER") not in editor_keys:
                return False
        return _manager_allows(context)

    def draw(self, context):
        return SRS_PT_smart_rig.draw(self, context)

    return type(
        class_name,
        (bpy.types.Panel,),
        {
            "__module__": __name__,
            "bl_idname": class_name,
            "bl_label": "Smart Rig",
            "bl_space_type": space_type,
            "bl_region_type": region_type,
            "bl_category": "Smart Rig",
            "bl_options": set(),
            "_smart_tools_manager_native_npanel_root": True,
            "_smart_tools_manager_tool_key": "SMART_RIG",
            "_smart_tools_manager_no_active_object_required": True,
            "_smart_tools_manager_editor_keys": editor_keys,
            "poll": poll,
            "draw_header_preset": _root_header_help,
            "draw": draw,
        },
    )


_EDITOR_ROOT_SPECS = (
    ("IMAGE_PT_smart_rig_root", "IMAGE_EDITOR"),
    ("NODE_PT_smart_rig_root", "NODE_EDITOR"),
    ("SEQUENCER_PT_smart_rig_root", "SEQUENCE_EDITOR"),
    ("CLIP_PT_smart_rig_root", "CLIP_EDITOR"),
    ("DOPESHEET_PT_smart_rig_root", "DOPESHEET_EDITOR"),
    ("GRAPH_PT_smart_rig_root", "GRAPH_EDITOR"),
    ("NLA_PT_smart_rig_root", "NLA_EDITOR"),
    ("TEXT_PT_smart_rig_root", "TEXT_EDITOR"),
    ("FILEBROWSER_PT_smart_rig_root", "FILE_BROWSER", "UI", ("FILE_BROWSER",)),
    ("SPREADSHEET_PT_smart_rig_root", "SPREADSHEET"),
    ("FILEBROWSER_PT_smart_rig_asset_root", "FILE_BROWSER", "TOOL_PROPS", ("ASSET_BROWSER",)),
)
EDITOR_ROOT_CLASSES = tuple(
    _make_editor_root(*spec)
    for spec in _EDITOR_ROOT_SPECS
)


CLASSES = (
    SRS_OT_show_section_help,
    SRS_PT_smart_rig,
    *EDITOR_ROOT_CLASSES,
)
_REGISTERED = False


def register() -> bool:
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False
    registered_now = ()
    try:
        registered_now = register_classes(
            CLASSES,
            module_name=__name__,
            revision=__srs_revision__,
            module_marker=__srs_module_generation_marker__,
        )
        generation.track_cleanup(
            clear_ui_status_cache,
            module_name=__name__,
            label="bounded UI status cache",
        )
        generation.mark_module_registered(__name__, True)
        _REGISTERED = True
    except Exception:
        # register_classes already rolls back its own partial work. This exact
        # tuple prevents a re-executed module from deleting retained old RNA.
        unregister_classes(registered_now, attempts=2)
        raise
    try:
        preferences = get_preferences(getattr(bpy, "context", None))
        configured_ai = str(getattr(preferences, "ai_runtime_path", "") or "") if preferences else ""
        refresh_ui_status(configured_ai, getattr(bpy, "context", None))
    except Exception:
        # External tools are optional. A failed status probe must never make the
        # N-panel registration fail or trigger a PanelType rebuild.
        clear_ui_status_cache()
    return True


def unregister() -> dict:
    global _REGISTERED
    report = unregister_owned_classes(module_name=__name__, attempts=2)
    try:
        clear_ui_status_cache()
    except Exception:
        pass
    panel_remaining = any(
        item.get("kind") == "Panel" and item.get("remaining")
        for item in report.get("results", ())
    )
    report["panel_remaining"] = panel_remaining
    if report.get("all_removed"):
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return report
