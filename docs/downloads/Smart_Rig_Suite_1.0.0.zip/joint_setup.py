# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""One place to set up every auxiliary bone an external rig adds past its defaults.

Auto-Rig Pro's standard setup gives a limb two segments and a hinge. Everything
that makes the joint deform well is added on top: secondary "bend" controllers
along each segment, and "joint fan" half bones carrying a Bulge constraint at the
joint itself. A finished character carries dozens of them -- on the reference rig,
39 bend bones and 14 fans -- and they are scattered across the armature under
names that do not agree between limbs. This module finds them, groups them by the
joint they serve, reports what is and is not set up, and applies the knee
treatments to any joint of the same shape.

Discovery is by POSITION, never by name or parent. Two measurements force that:

* The bone that carries a joint's name does not sit on the same segment from limb
  to limb. ``c_knee_bend`` is parented to the shin (distal) while ``c_elbow_bend``
  is parented to the upper arm (proximal), yet both belong to the distal side of
  their joint. Classifying by parent gets one of them wrong every time;
  classifying by where the bone's midpoint projects onto each segment axis gets
  both right (measured: c_knee_bend distal station +0.059, c_elbow_bend +0.113).
* The "in" / "out" naming of the fans is not used consistently between sides, so
  it cannot say which fan faces forward. The pole bone can: projecting a fan's
  midpoint onto the pole direction separates them cleanly (measured on the knee,
  +36mm and +40mm for the two front fans against -44mm for the back one).

A bone's HEAD is useless for this -- every fan and every joint-side bend bone has
its head exactly at the joint, so all of them measure zero. The midpoint is what
carries the information.
"""

import math

import bpy
from mathutils import Vector

from . import knee_profile
from . import knee_split

SIDES = (".l", ".r")
BULGE = "Bulge"
# Past this station a bone belongs to the joint at the segment's far end.
# c_thigh_bend_contact sits at 0.79 and c_ankle_bend at 0.91, so both stay;
# the hip fans at 1.00 and the thumb past the wrist are excluded.
FAR_END_STATION = 0.95

# The joints this module knows how to treat. Everything else is still inventoried
# and audited; only the treatments need a pole and two clean segments.
JOINT_SPECS = (
    {
        "key": "knee",
        "label_en": "Knee",
        "label_ja": "膝",
        "proximal": "thigh_stretch{side}",
        "distal": "leg_stretch{side}",
        "prox_anchor": ("thigh_twist{side}", "thigh{side}"),
        "dist_anchor": ("foot{side}",),
        "poles": ("c_leg_pole{side}", "leg_fk_pole{side}", "foot_pole{side}"),
    },
    {
        "key": "elbow",
        "label_en": "Elbow",
        "label_ja": "肘",
        "proximal": "arm_stretch{side}",
        "distal": "forearm_stretch{side}",
        "prox_anchor": ("arm_twist{side}", "arm{side}"),
        "dist_anchor": ("hand{side}",),
        "poles": ("c_arms_pole{side}", "arm_fk_pole{side}"),
    },
)

# The knee's measured-and-approved settings. Everything with a length unit is
# scaled to another joint by that joint's own distal segment, so the CHAIN'S TILT
# stays the same rather than the absolute millimetres -- the tilt is
# atan(offset / length), so holding offset/length constant is what makes the
# shape change similar instead of merely equal.
REFERENCE_DISTAL_MM = 446.0
PRESET = {
    "front_curve": "45:3.3, 60:-36.6, 75:-33, 90:-29.2, 95:-25.5, 170:-209",
    "back_curve": "45:39.7, 60:44, 75:30, 90:13.5, 95:13.5, 110:54, 170:94",
    "onset_deg": 90.0,
    "end_deg": 170.0,
    "prox_slide_mm": 20.0,
    "prox_apart_mm": 0.0,
    "dist_slide_mm": 0.0,
    "dist_apart_mm": 100.0,
    "smooth_radius_mm": 115.0,
    "smooth_factor": 0.6,
    "smooth_repeat": 8,
}


# Scaling the knee's numbers by segment length gets the SPLIT right but not the
# fan curves: the fans are a fixed-length half bone, not a chain, so their travel
# does not follow the segment. Measured on the elbow, the scaled curve let the
# elbow point run to 76.6mm at 150 degrees against 33.1mm untreated, while the
# values below hold it to 26.3mm and keep the fold clean (dihedral p95 51, eight
# edges past 40 degrees, against 137 and 46 untreated). Given in absolute
# millimetres, so they are used as-is rather than rescaled.
PRESET_OVERRIDES = {
    "elbow": {
        "front_curve": "45:1.7, 60:-18.5, 75:-16.6, 90:-14.7, 95:-12.9, 170:-300",
        "dist_apart_mm": 30.0,
    },
}


def _fmt(name, side):
    return name.format(side=side)


def _first(armature, names, side):
    for n in names:
        full = _fmt(n, side)
        if full in armature.data.bones:
            return full
    return None


def _mid(armature, bone):
    mw = armature.matrix_world
    return (mw @ bone.head_local + mw @ bone.tail_local) * 0.5


def is_fan(armature, name):
    """The Bulge constraint is what makes a bone a joint fan, not its name."""
    pb = armature.pose.bones.get(name)
    if pb is None:
        return None
    return pb.constraints.get(BULGE)


def auxiliary_bones(armature):
    """Every bone the external rig added past its defaults, by our two markers."""
    out = []
    for b in armature.data.bones:
        if is_fan(armature, b.name) is not None or "bend" in b.name:
            out.append(b.name)
    return sorted(out)


def _frames(armature, sides):
    """Per joint: the joint centre and the two segment axes, from the rest pose."""
    frames = []
    for spec in JOINT_SPECS:
        for side in sides:
            distal = _fmt(spec["distal"], side)
            if distal not in armature.data.bones:
                continue
            prox_anchor = _first(armature, spec["prox_anchor"], side)
            dist_anchor = _first(armature, spec["dist_anchor"], side)
            if prox_anchor is None or dist_anchor is None:
                continue
            mw = armature.matrix_world
            joint = mw @ armature.data.bones[distal].head_local
            p = mw @ armature.data.bones[prox_anchor].head_local
            d = mw @ armature.data.bones[dist_anchor].head_local
            vp, vd = p - joint, d - joint
            if vp.length < 1e-6 or vd.length < 1e-6:
                continue
            pole = None
            pole_name = None
            for cand in spec["poles"]:
                n = _fmt(cand, side)
                if n in armature.data.bones:
                    v = (mw @ armature.data.bones[n].head_local) - joint
                    v = v - vd.normalized() * v.dot(vd.normalized())
                    if v.length > 1e-4:
                        pole = v.normalized()
                        pole_name = n
                        break
            frames.append({
                "key": spec["key"], "side": side, "spec": spec,
                "label_en": spec["label_en"], "label_ja": spec["label_ja"],
                "joint": joint, "distal_bone": distal,
                "proximal_bone": _fmt(spec["proximal"], side),
                "prox_anchor": prox_anchor, "dist_anchor": dist_anchor,
                "u_prox": vp.normalized(), "u_dist": vd.normalized(),
                "len_prox": vp.length, "len_dist": vd.length,
                "anterior": pole, "pole": pole_name,
            })
    return frames


def discover(armature, sides=SIDES):
    """Group every auxiliary bone under the joint it actually serves.

    Returns ``(joints, error)``. Each auxiliary bone is assigned to the NEAREST
    joint centre; without that, a thigh bone lands in the elbow's lists simply
    because it happens to project onto the arm's axis (measured: the knee fans
    showed up under the elbow at station 0.93 before this was added).
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    frames = _frames(armature, sides)
    if not frames:
        return None, "No treatable joints were found on this armature"
    unassigned = []
    for f in frames:
        f.update({"prox_bend": [], "dist_bend": [], "front_fan": [],
                  "back_fan": [], "unjudged": []})

    for name in auxiliary_bones(armature):
        bone = armature.data.bones[name]
        mid = _mid(armature, bone)
        best = None
        for f in frames:
            reach = max(f["len_prox"], f["len_dist"])
            d = (mid - f["joint"]).length
            if d > reach * 1.05:
                continue
            if best is None or d < best[0]:
                best = (d, f)
        if best is None:
            unassigned.append({"bone": name,
                               "why": "not near any treatable joint"})
            continue
        f = best[1]
        rel = mid - f["joint"]
        s_prox = rel.dot(f["u_prox"]) / f["len_prox"]
        s_dist = rel.dot(f["u_dist"]) / f["len_dist"]
        item = {"bone": name, "s_prox": round(s_prox, 3), "s_dist": round(s_dist, 3)}
        # A bone sitting at a segment's FAR end serves the joint at that end, not
        # this one. Measured: the hip fans c_thigh_in/out_01 land at station 1.000
        # and thumb_bend_all past the wrist, and without this bound they would be
        # driven by the knee's and the elbow's curves respectively.
        if max(s_prox, s_dist) > FAR_END_STATION:
            con = is_fan(armature, name)
            if con is not None:
                item["to_min_y"] = round(con.to_min_y, 6)
            unassigned.append(dict(item, joint="%s%s" % (f["key"], f["side"]),
                                   why="sits at the far end of the segment"))
            continue
        con = is_fan(armature, name)
        if con is not None:
            item["to_min_y"] = round(con.to_min_y, 6)
            item["influence"] = round(con.influence, 3)
            if f["anterior"] is None:
                item["why"] = "no pole bone, so front and back cannot be told apart"
                f["unjudged"].append(item)
                continue
            a = rel.dot(f["anterior"])
            item["anterior_mm"] = round(a * 1000.0, 1)
            (f["front_fan"] if a > 0.0 else f["back_fan"]).append(item)
        else:
            (f["prox_bend"] if s_prox >= s_dist else f["dist_bend"]).append(item)
    for f in frames:
        f["unassigned"] = unassigned
    return frames, ""


def scaled_preset(frame, preset=None):
    """The knee's approved numbers, rescaled to this joint's own size."""
    base = dict(PRESET if preset is None else preset)
    factor = (frame["len_dist"] * 1000.0) / REFERENCE_DISTAL_MM
    out = dict(base)
    for key in ("prox_slide_mm", "prox_apart_mm", "dist_slide_mm", "dist_apart_mm",
                "smooth_radius_mm"):
        out[key] = round(base[key] * factor, 2)
    for key in ("front_curve", "back_curve"):
        try:
            pts = knee_profile.parse_curve(base[key])
        except ValueError:
            continue
        out[key] = knee_profile.format_curve(
            [(a, round(v * factor, 3)) for a, v in pts])
    out["scale_factor"] = round(factor, 4)
    # Per-joint measured overrides win over the scaled numbers.
    out.update(PRESET_OVERRIDES.get(frame["key"], {}))
    return out


def _fan_state(armature, name):
    con = is_fan(armature, name)
    rest, flex, _f = knee_profile.fan_ends(con)
    ad = armature.animation_data
    drv = ad.drivers.find(knee_profile._constraint_path(name, flex)) if ad else None
    return {"rest": float(getattr(con, rest)),
            "rest_driven": bool(ad and ad.drivers.find(knee_profile._constraint_path(name, rest)) is not None),
            "flex": None if drv is not None else float(getattr(con, flex)),
            "keys": [(round(k.co[0], 4), float(k.co[1])) for k in drv.keyframe_points] if drv is not None else None}


def physical_mirror_report(armature):
    """Fan pairs that move with the limb straight, or that do not mirror by knee_profile.mirror_factor."""
    issues, checked = [], 0
    for name in auxiliary_bones(armature):
        if not name.endswith(".l") or is_fan(armature, name) is None:
            continue
        other = name[:-2] + ".r"
        if is_fan(armature, other) is None:
            continue
        checked += 1
        a, b = _fan_state(armature, name), _fan_state(armature, other)
        for bone, st in ((name, a), (other, b)):
            if abs(st["rest"]) > 1.0e-6 or st["rest_driven"]:
                issues.append({"pair": [name, other], "bone": bone, "rest_end_mm": round(st["rest"] * 1000.0, 2),
                               "message": "the fan moves with the limb straight (its rest end is not zero)"})
        factor = knee_profile.mirror_factor(armature, name, other)
        ok = factor is not None
        if ok and a["keys"] is not None and b["keys"] is not None and len(a["keys"]) == len(b["keys"]):
            for (xa, ya), (xb, yb) in zip(a["keys"], b["keys"]):
                if abs(xa - xb) > 1.0e-3 or abs(yb - ya * factor) > max(abs(ya), 1.0e-6) * 0.05:
                    ok = False
                    break
        elif ok and a["keys"] is None and b["keys"] is None:
            ok = abs(b["flex"] - a["flex"] * factor) <= max(abs(a["flex"]), 1.0e-6) * 0.05
        else:
            ok = False
        if not ok:
            issues.append({"pair": [name, other], "factor": factor,
                           "message": ("the two sides are not mirror images, so the left and right joints "
                                       "bulge differently")})
    return {"pairs_checked": checked, "asymmetric": issues, "rule": "knee_profile.mirror_factor"}


def mirror_report(joints, armature=None):
    """Flag fans whose two sides are not set up as mirror images.

    With ``armature`` the test is the physical one (physical_mirror_report). The
    signed-sum test below is the older convention and is kept for callers without
    the armature; it is right only for pairs whose input ranges run the same way.

    The convention on a correctly built pair is that the two sides carry the SAME
    magnitude with OPPOSITE sign, so their sum is zero. Measured on the reference
    rig: knee back fan -0.0397 / +0.0397 and knee front fans -0.0033 / +0.0033 both
    sum to zero, while the elbow's carry +0.0135 / 0.0000 and the thighs'
    +0.0090 / 0.0000 -- one side of each pair does nothing, so the two arms bulge on
    OPPOSITE faces of the joint. Comparing magnitudes with abs() would pass that
    broken pair, which is exactly why the test is on the signed sum.
    """
    by_bone = {}
    for f in joints:
        for group in ("front_fan", "back_fan", "unjudged", "unassigned"):
            for item in f.get(group, []):
                if "to_min_y" in item:
                    by_bone[item["bone"]] = item["to_min_y"]
    issues = []
    checked = 0
    seen = set()
    for name, value in sorted(by_bone.items()):
        if not name.endswith(".l"):
            continue
        other = name[:-2] + ".r"
        if other not in by_bone:
            continue
        seen.add(name)
        checked += 1
        total = value + by_bone[other]
        scale = max(abs(value), abs(by_bone[other]), 1e-9)
        if abs(total) > scale * 0.05:
            issues.append({
                "pair": [name, other],
                "to_min_y": [value, by_bone[other]],
                "signed_sum": round(total, 6),
                "message": ("the two sides are not mirror images, so the left and "
                            "right joints bulge on different faces"),
            })
    return {"pairs_checked": checked, "asymmetric": issues}


def audit(armature, sides=SIDES):
    """What is present, what is driven, and what disagrees between sides."""
    joints, err = discover(armature, sides)
    if joints is None:
        return {"error": err, "joints": [], "mirror": {}}
    ad = armature.animation_data
    driven = set()
    if ad:
        for fc in ad.drivers:
            driven.add(fc.data_path)
    rows = []
    for f in joints:
        n_driven = 0
        total = 0
        for group in ("prox_bend", "dist_bend"):
            for item in f[group]:
                total += 1
                for chan in ("location", "rotation_euler", "rotation_quaternion"):
                    if 'pose.bones["%s"].%s' % (item["bone"], chan) in driven:
                        n_driven += 1
                        break
        fans = len(f["front_fan"]) + len(f["back_fan"])
        fans_driven = 0
        for group in ("front_fan", "back_fan"):
            for item in f[group]:
                path = ('pose.bones["%s"].constraints["%s"].to_min_y'
                        % (item["bone"], BULGE))
                if path in driven:
                    fans_driven += 1
        if n_driven == 0 and fans_driven == 0:
            state = "untouched"
        elif n_driven == total and fans_driven == fans:
            state = "set up"
        else:
            state = "partial"
        rows.append({
            "key": f["key"], "side": f["side"], "state": state,
            "pole": f["pole"],
            "prox_bend": len(f["prox_bend"]), "dist_bend": len(f["dist_bend"]),
            "front_fan": len(f["front_fan"]), "back_fan": len(f["back_fan"]),
            "unjudged": len(f["unjudged"]),
            "bend_driven": "%d/%d" % (n_driven, total),
            "fans_driven": "%d/%d" % (fans_driven, fans),
            "distal_mm": round(f["len_dist"] * 1000.0, 1),
        })
    return {"joints": rows, "mirror": physical_mirror_report(armature),
            "auxiliary_total": len(auxiliary_bones(armature))}


def joint_spec(frame):
    """The plain dict the treatment modules take, built from a discovered joint."""
    return {
        "proximal": frame["proximal_bone"],
        "distal": frame["distal_bone"],
        "prox_anchor": frame["prox_anchor"],
        "dist_anchor": frame["dist_anchor"],
        "pole": frame["pole"],
        "prox_bend": [i["bone"] for i in frame["prox_bend"]],
        "dist_bend": [i["bone"] for i in frame["dist_bend"]],
        "front_fan": [i["bone"] for i in frame["front_fan"]],
        "back_fan": [i["bone"] for i in frame["back_fan"]],
    }


def apply_joint(armature, frame, settings):
    """Run the fan profile and the split on one joint.

    Weight smoothing is deliberately NOT done here; it is run once for all
    joints together by :func:`apply_all` so no vertex is smoothed twice.
    """
    key = frame["key"]
    side = frame["side"]
    report = {"key": key, "side": side, "steps": []}
    spec = joint_spec(frame)
    if spec["front_fan"] or spec["back_fan"]:
        rep, err = knee_profile.install(
            armature, sides=(side,),
            front_curve=settings.get("front_curve", ""),
            back_curve=settings.get("back_curve", ""),
            joint=spec)
        report["steps"].append({"step": "profile", "error": err,
                                "bones": len((rep or {}).get("bones", []))})
    if spec["prox_bend"] or spec["dist_bend"]:
        rep, err = knee_split.install(
            armature, sides=(side,),
            onset_deg=settings.get("onset_deg", PRESET["onset_deg"]),
            end_deg=settings.get("end_deg", PRESET["end_deg"]),
            thigh_slide_mm=settings.get("prox_slide_mm", 0.0),
            thigh_apart_mm=settings.get("prox_apart_mm", 0.0),
            calf_slide_mm=settings.get("dist_slide_mm", 0.0),
            calf_apart_mm=settings.get("dist_apart_mm", 0.0),
            ramp_curve=settings.get("ramp_curve", ""),
            joint=spec)
        report["steps"].append({"step": "split", "error": err,
                                "bones": len((rep or {}).get("bones", []))})
    return report


def apply_all(armature, keys=None, sides=SIDES, mesh=None, overrides=None):
    """Set up every discovered joint in one pass. Returns ``(report, error)``."""
    joints, err = discover(armature, sides)
    if joints is None:
        return None, err
    wanted = set(keys) if keys else {s["key"] for s in JOINT_SPECS}
    done = []
    smooth_jobs = []
    for f in joints:
        if f["key"] not in wanted:
            continue
        settings = scaled_preset(f)
        if overrides and f["key"] in overrides:
            settings.update(overrides[f["key"]])
        done.append(apply_joint(armature, f, settings))
        smooth_jobs.append((f, settings))
    if not done:
        return {"joints": []}, "Nothing matched the requested joints"

    # Smoothing runs ONCE over every joint's vertices together. Called per joint it
    # would pass over a vertex more than once -- with the mesh's X-mirror on,
    # smoothing one knee writes the mirrored result onto the other, so treating
    # both gave each of them two passes and cost the knee cap 6mm of definition at
    # deep flexion (measured against the hand-tuned reference).
    smoothed = {"selected": 0, "runs": 0}
    if mesh is not None and smooth_jobs:
        by_params = {}
        for f, st in smooth_jobs:
            if not st.get("smooth_repeat", 0):
                continue
            key = (round(st.get("smooth_radius_mm", PRESET["smooth_radius_mm"]), 3),
                   round(st.get("smooth_factor", PRESET["smooth_factor"]), 4),
                   int(st.get("smooth_repeat", PRESET["smooth_repeat"])))
            by_params.setdefault(key, []).append(f)
        for (radius, factor, repeat), frames in by_params.items():
            specs = [joint_spec(f) for f in frames]
            rep, err = knee_split.smooth_knee_weights(
                armature, mesh, sides=tuple(f["side"] for f in frames),
                radius_mm=radius, factor=factor, repeat=repeat,
                joints=specs)
            smoothed["runs"] += 1
            smoothed["selected"] += (rep or {}).get("selected", 0)
            if err:
                smoothed.setdefault("errors", []).append(err)
    return {"joints": done, "smooth": smoothed}, ""


def remove_all(armature, sides=SIDES):
    """Take every treatment back out."""
    n = knee_split.remove(armature, sides=sides)
    n += knee_profile.remove(armature, sides=sides)
    joints, _err = discover(armature, sides)
    for f in joints or []:
        spec = joint_spec(f)
        n += knee_split.remove(armature, sides=(f["side"],), joint=spec)
        n += knee_profile.remove(armature, sides=(f["side"],), joint=spec)
    return n


def _driver_keys(armature, name):
    """Every driver key on a fan's Bulge, rounded, so a re-run that changes nothing reports nothing."""
    ad = armature.animation_data
    out = []
    for attr in ("to_min_y", "to_max_y"):
        drv = ad.drivers.find(knee_profile._constraint_path(name, attr)) if ad else None
        if drv is not None:
            out.append((attr, [(round(k.co[0], 4), round(k.co[1], 7)) for k in drv.keyframe_points]))
    return out


def mirror_fans(armature, sides=SIDES, source=".l"):
    """Make each fan pair a true mirror of the chosen side, and both still at rest.

    Each fan's rest end (the input rotation of zero) is set to zero and its driver or
    value kept on the flexed end (knee_profile.repair_rest_end); then the other side's
    flexed end becomes the source's times knee_profile.mirror_factor, a driver copied
    with its keys scaled and its flexion bones renamed.

    History, measured on MIK. The first version copied ``to_min_y`` as a plain
    negation. That is right for the knees, whose two fans share the same input range,
    and wrong for the elbows and hips, whose left and right ranges run opposite ways:
    the right fans got the left's flexed value on their rest ends, so they sat 8.62 to
    12.93 mm off with the limb straight and bent the other way round (the right elbow
    38 mm from the left's mirror at 140 degrees). By the rule the elbows match to 0.01
    mm, every fan rests at zero, and the knees are unchanged.

    Returns ``(report, error)``.
    """
    from . import knee_profile
    from .rig_hygiene import mirror_group_name
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    other = ".r" if source == ".l" else ".l"
    fixed = []
    skipped = []
    for name in auxiliary_bones(armature):
        if not name.endswith(source):
            continue
        con = is_fan(armature, name)
        if con is None:
            continue
        twin = name[:-len(source)] + other
        tcon = is_fan(armature, twin)
        if tcon is None:
            skipped.append({"bone": name, "why": "no matching bone on the other side"})
            continue
        before = (round(tcon.to_min_y, 6), round(tcon.to_max_y, 6))
        before_keys = _driver_keys(armature, twin)
        repaired = knee_profile.repair_rest_end(armature, name)
        factor = knee_profile.mirror_factor(armature, name, twin)
        if factor is None:
            skipped.append({"bone": name, "why": "no flexed end to mirror"})
            continue
        _rest, flex, _f = knee_profile.fan_ends(con)
        trest, tflex, _tf = knee_profile.fan_ends(tcon)
        ad = armature.animation_data
        for attr in ("to_min_y", "to_max_y"):
            old = ad.drivers.find(knee_profile._constraint_path(twin, attr)) if ad else None
            if old is not None:
                ad.drivers.remove(old)
        setattr(tcon, trest, 0.0)
        source_driver = ad.drivers.find(knee_profile._constraint_path(name, flex)) if ad else None
        if source_driver is not None:
            copy = ad.drivers.from_existing(src_driver=source_driver)
            copy.data_path = knee_profile._constraint_path(twin, tflex)
            for key in copy.keyframe_points:
                key.co[1] *= factor
                key.handle_left[1] *= factor
                key.handle_right[1] *= factor
            for variable in copy.driver.variables:
                for target in variable.targets:
                    if target.bone_target:
                        target.bone_target = mirror_group_name(target.bone_target) or target.bone_target
            copy.update()
        else:
            setattr(tcon, tflex, getattr(con, flex) * factor)
        tcon.influence = con.influence
        after = (round(tcon.to_min_y, 6), round(tcon.to_max_y, 6))
        if before != after or repaired or _driver_keys(armature, twin) != before_keys:
            fixed.append({"bone": twin, "from": before, "to": after, "factor": round(factor, 3),
                          "source": name, "source_repaired": repaired,
                          "driver_copied": source_driver is not None})
    return {"fixed": fixed, "skipped": skipped, "source_side": source}, ""
