# Smart Rig 1.0.0

Blender 5.1.2 用のリグ作成・衣装作業ツールです。
インストールと操作例は SmartRig の解説書を参照してください。

Rigging and costume tools for Blender 5.1.2.
See the SmartRig guide for installation and worked examples.
