# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Fix, with a shape key, what linear skinning cannot do with weights.

Some of what a face does is not a weighting problem at all. A closed eyelid folds
the surface over itself, and linear blend skinning averages matrices rather than
following a fold, so the lid facets no matter how the weights are painted --
measured on the reference character, smoothing the lid weights took the surface
degradation from p95 +39 to +22 and then stopped improving, while the fold stayed.
Auto-Rig Pro's own answer to this is a blink pose, and the general answer is a
corrective shape key.

What this module does is compute that corrective rather than sculpt it. It poses
the rig, reads the surface the rig produces, smooths that surface inside the
region that is faulting, and stores the difference as a shape key driven by the
same control. The user is free to sculpt a better target afterwards -- the key is
an ordinary shape key -- but they no longer have to sculpt one to remove faceting.

The one subtlety worth stating, because getting it wrong produces a key that looks
right in the shape-key editor and wrong on the posed character: a shape key is
applied BEFORE the armature, so a displacement measured on the posed surface has
to be carried back through the skinning matrix before it is stored. For a vertex
whose skinned transform is ``M``, a posed displacement ``d`` corresponds to a rest
displacement of ``M^-1 d``. Storing ``d`` directly gives a correction that is
rotated and scaled by however much that vertex's bones moved.
"""

import bpy
from mathutils import Vector


def _armature_only(mesh_object):
    hidden = []
    for modifier in mesh_object.modifiers:
        if modifier.type != "ARMATURE" and modifier.show_viewport:
            modifier.show_viewport = False
            hidden.append(modifier)
    if hidden:
        bpy.context.view_layer.update()
    return hidden


def _restore(hidden):
    for modifier in hidden:
        modifier.show_viewport = True
    if hidden:
        bpy.context.view_layer.update()


def _evaluated_world(mesh_object):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = mesh_object.evaluated_get(depsgraph)
    matrix = mesh_object.matrix_world
    return [matrix @ v.co for v in evaluated.data.vertices]


def skin_matrices(mesh_object, armature, indices):
    """The blended skinning transform per vertex, in world space.

    This is what carries a correction measured on the posed surface back to the
    rest surface where a shape key lives.
    """
    out = {}
    if mesh_object is None or armature is None:
        return out
    world = armature.matrix_world
    world_inverse = world.inverted()
    cache = {}
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    for index in indices:
        vertex = mesh_object.data.vertices[index]
        total = 0.0
        accumulated = None
        for entry in vertex.groups:
            if entry.weight <= 0.0:
                continue
            name = names.get(entry.group)
            bone = armature.data.bones.get(name) if name else None
            pose_bone = armature.pose.bones.get(name) if name else None
            if bone is None or pose_bone is None or not bone.use_deform:
                continue
            matrix = cache.get(name)
            if matrix is None:
                matrix = (world @ pose_bone.matrix
                          @ bone.matrix_local.inverted() @ world_inverse)
                cache[name] = matrix
            contribution = matrix.to_3x3() * entry.weight
            accumulated = contribution if accumulated is None else (
                accumulated + contribution)
            total += entry.weight
        if accumulated is None or total <= 0.0:
            continue
        out[index] = accumulated * (1.0 / total)
    return out


def smoothed_positions(mesh_object, positions, indices, factor=0.5, repeat=4):
    """Laplacian-smooth a set of world positions inside a region.

    Only the region moves; everything around it holds the boundary still, so the
    correction fades out instead of shifting the whole surface.
    """
    scope = set(indices)
    neighbours = {i: set() for i in scope}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        if a in scope:
            neighbours[a].add(b)
        if b in scope:
            neighbours[b].add(a)
    current = dict(positions)
    for _ in range(max(1, int(repeat))):
        updated = {}
        for index in scope:
            linked = neighbours.get(index)
            if not linked:
                continue
            average = Vector()
            for other in linked:
                average += current.get(other, positions[other])
            average /= len(linked)
            updated[index] = current[index].lerp(average, max(0.0, min(1.0, factor)))
        current.update(updated)
    return current


def _triangle_frame(a, b, c):
    """An orthonormal-ish frame for a triangle, used to carry an offset along it."""
    edge1 = b - a
    edge2 = c - a
    normal = edge1.cross(edge2)
    if normal.length <= 1.0e-12:
        return None
    return edge1, edge2, normal.normalized()


def surface_correspondence(rider, donor, indices=None):
    """Tie each rider vertex to a spot on the donor's surface. ``(map, error)``.

    For every vertex it records which donor triangle it sits over, where in that
    triangle, and its offset expressed in that triangle's own frame. Posed, the
    same triangle gives the spot back, so the rider can be reconstructed onto a
    surface that has moved and folded.

    This is what a strip lying on another surface needs and what skin weights
    cannot give it: the eyelashes follow the lid margin at about half rate however
    their weights are transferred, because the far end of the strip is anchored
    while the margin travels -- measured, the lash-to-lid distance changes by
    4.89mm through a full close even after the lid itself was corrected.
    """
    from mathutils.bvhtree import BVHTree

    if rider is None or donor is None:
        return None, "Need both meshes"
    depsgraph = bpy.context.evaluated_depsgraph_get()
    donor_eval = donor.evaluated_get(depsgraph)
    donor_matrix = donor.matrix_world
    points = [donor_matrix @ v.co for v in donor_eval.data.vertices]
    polygons = [list(p.vertices) for p in donor_eval.data.polygons]
    if not polygons:
        return None, "%s evaluates to no faces" % donor.name
    tree = BVHTree.FromPolygons(points, polygons, all_triangles=False, epsilon=0.0)

    rider_eval = rider.evaluated_get(depsgraph)
    rider_matrix = rider.matrix_world
    chosen = (range(len(rider_eval.data.vertices)) if indices is None
              else [i for i in indices if i < len(rider_eval.data.vertices)])
    mapping = {}
    for index in chosen:
        point = rider_matrix @ rider_eval.data.vertices[index].co
        location, normal, face_index, _distance = tree.find_nearest(point)
        if location is None or face_index is None or face_index >= len(polygons):
            continue
        corners = polygons[face_index]
        if len(corners) < 3:
            continue
        a, b, c = (points[corners[0]], points[corners[1]], points[corners[2]])
        frame = _triangle_frame(a, b, c)
        if frame is None:
            continue
        edge1, edge2, unit = frame
        offset = point - location
        # The offset is stored in the triangle's own coordinates, so it rotates
        # and stretches with the triangle instead of staying in world space.
        try:
            basis = __import__("mathutils").Matrix((edge1, edge2, unit)).transposed()
            local = basis.inverted() @ offset
            surface = basis.inverted() @ (location - a)
        except ValueError:
            continue
        mapping[index] = {"face": face_index, "corners": corners[:3],
                          "local_offset": tuple(local), "surface_uv": tuple(surface)}
    if not mapping:
        return None, "No rider vertex could be tied to the donor surface"
    return mapping, ""


def reconstruct_on_surface(donor, mapping):
    """Where each rider vertex should be, given the donor's current shape."""
    import mathutils

    depsgraph = bpy.context.evaluated_depsgraph_get()
    donor_eval = donor.evaluated_get(depsgraph)
    donor_matrix = donor.matrix_world
    points = [donor_matrix @ v.co for v in donor_eval.data.vertices]
    out = {}
    for index, record in mapping.items():
        corners = record["corners"]
        if max(corners) >= len(points):
            continue
        a, b, c = points[corners[0]], points[corners[1]], points[corners[2]]
        frame = _triangle_frame(a, b, c)
        if frame is None:
            continue
        edge1, edge2, unit = frame
        basis = mathutils.Matrix((edge1, edge2, unit)).transposed()
        surface = a + basis @ mathutils.Vector(record["surface_uv"])
        out[index] = surface + basis @ mathutils.Vector(record["local_offset"])
    return out


def graph_falloff(mesh_object, region, seed, hops=4):
    """A 0-to-1 weight per vertex that is 0 at ``seed`` and 1 far from it.

    A correction that switches on at full strength next to vertices it does not
    touch makes a step, and a step in a face reads as a tear. Measured: holding
    the upper lip against the jaw at strength 0.75 cut its unwanted follow from
    24.28 per cent to 6.05, and simultaneously took the worst jaw-follow jump
    across a single edge from 3.787mm to 16.232mm because the held vertices sat
    directly against unheld ones at the lip crevice. Fading the correction out
    over a few edges removes the step without giving back much of the gain.

    Distance is counted in edges rather than millimetres so the falloff follows
    the surface around a fold instead of cutting across it.
    """
    scope = set(region)
    frontier = {i for i in seed if i in scope}
    if not frontier:
        return {i: 1.0 for i in scope}
    neighbours = {i: set() for i in scope}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        if a in scope and b in scope:
            neighbours[a].add(b)
            neighbours[b].add(a)
    distance = {i: 0 for i in frontier}
    current = set(frontier)
    for step_index in range(1, max(1, int(hops)) + 1):
        nxt = set()
        for index in current:
            for other in neighbours.get(index, ()):  # noqa: B007
                if other not in distance:
                    distance[other] = step_index
                    nxt.add(other)
        current = nxt
        if not current:
            break
    limit = float(max(1, int(hops)))
    out = {}
    for index in scope:
        hop = distance.get(index)
        if hop is None:
            out[index] = 1.0
        else:
            t = min(1.0, hop / limit)
            # Smoothstep, so the correction has no visible edge where it starts.
            out[index] = t * t * (3.0 - 2.0 * t)
    return out


def build_corrective(mesh_object, armature, poses, indices, name,
                     factor=0.5, repeat=6, driver=None, mode="SMOOTH",
                     strength=1.0, strength_map=None, donor=None):
    """Make a shape key that fixes what a pose does to a region. ``(report, error)``.

    ``poses`` is a list of ``(bone, (x, y, z) in mm)``. ``driver`` is an optional
    ``{"bone", "transform_type", "full_mm"}`` which wires the key's value to that
    control so the correction comes in with the pose and is absent at rest.

    Two kinds of fault, two modes.

    ``SMOOTH`` takes the surface the rig produces and smooths it inside the
    region. That is for faceting -- a fold linear skinning cannot follow. Measured
    on the reference eyelid it took the surface degradation from p95 +22.7 to +2.0
    and left fewer edges bent past 40 degrees when closed than the mesh has at
    rest.

    ``RIDE`` needs a ``donor`` mesh and keeps the region sitting on that surface,
    by tying each vertex to a spot on a donor triangle at rest and putting it back
    on that spot once the donor has moved. That is for a part lying on another --
    eyelashes on an eyelid -- where skinning cannot keep the contact because the
    strip is anchored at one end while the surface it rests on travels.

    ``HOLD`` pulls the region back towards where it sits at rest, by ``strength``.
    That is for a region being dragged by something it should not follow -- the
    upper lip going down with the jaw. A strength of 1.0 pins it completely, which
    is usually wrong: a lip that ignores the jaw entirely reads as badly as one
    that follows it, so the useful values are partial.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    region = sorted(set(indices or ()))
    if not region:
        return None, "No region given"
    if mesh_object.data.shape_keys is not None:
        if mesh_object.data.shape_keys.key_blocks.get(name) is not None:
            return None, ("%s already carries a shape key called %r; remove it "
                          "first rather than stacking two corrections"
                          % (mesh_object.name, name))

    hidden = _armature_only(mesh_object)
    saved = []
    try:
        for bone_name, _value in poses or ():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                return None, "The armature has no bone called %r" % bone_name
            saved.append((pose_bone, tuple(pose_bone.location)))

        rest_world = _evaluated_world(mesh_object)
        if str(mode).upper() != "RIDE":
            for bone_name, value in poses or ():
                pose_bone = armature.pose.bones.get(bone_name)
                pose_bone.location = (value[0] * 0.001, value[1] * 0.001,
                                      value[2] * 0.001)
            bpy.context.view_layer.update()
            posed = _evaluated_world(mesh_object)
            posed_map = {i: posed[i] for i in range(len(posed))}
        if str(mode).upper() == "RIDE":
            if donor is None:
                return None, "RIDE needs a donor mesh to ride on"
            mapping, map_error = surface_correspondence(mesh_object, donor, region)
            if map_error:
                return None, map_error
            for bone_name, value in poses or ():
                pose_bone = armature.pose.bones.get(bone_name)
                pose_bone.location = (value[0] * 0.001, value[1] * 0.001,
                                      value[2] * 0.001)
            bpy.context.view_layer.update()
            posed = _evaluated_world(mesh_object)
            posed_map = {i: posed[i] for i in range(len(posed))}
            rebuilt = reconstruct_on_surface(donor, mapping)
            blend = max(0.0, min(1.0, float(strength)))
            target = {}
            for i in region:
                wanted = rebuilt.get(i)
                if wanted is None:
                    continue
                scale = blend
                if strength_map is not None:
                    scale *= max(0.0, min(1.0, float(strength_map.get(i, 1.0))))
                target[i] = posed_map[i].lerp(wanted, scale)
        elif str(mode).upper() == "HOLD":
            base_blend = max(0.0, min(1.0, float(strength)))
            target = {}
            for i in region:
                scale = base_blend
                if strength_map is not None:
                    scale *= max(0.0, min(1.0, float(strength_map.get(i, 1.0))))
                target[i] = posed_map[i].lerp(rest_world[i], scale)
        else:
            smoothed = smoothed_positions(mesh_object, posed_map, region,
                                          factor=factor, repeat=repeat)
            if strength_map is None:
                target = smoothed
            else:
                # Smoothing the whole of a part costs contact everywhere to fix a
                # spike in one place: on the eyelashes it took the worst edge
                # strain from +1164 to +202 per cent and simultaneously pulled the
                # strip up to 5.1mm off the lid. A map confines it to where the
                # spike is.
                blend = max(0.0, min(1.0, float(strength)))
                target = {}
                for i in region:
                    scale = blend * max(0.0, min(1.0,
                                                 float(strength_map.get(i, 1.0))))
                    target[i] = posed_map[i].lerp(smoothed[i], scale)
        matrices = skin_matrices(mesh_object, armature, region)
    finally:
        for pose_bone, value in saved:
            pose_bone.location = value
        bpy.context.view_layer.update()
        _restore(hidden)

    object_inverse = mesh_object.matrix_world.to_3x3().inverted()
    if mesh_object.data.shape_keys is None:
        mesh_object.shape_key_add(name="Basis", from_mix=False)
    key = mesh_object.shape_key_add(name=name, from_mix=False)
    key.value = 0.0
    key.slider_min = 0.0
    key.slider_max = 1.0

    moved = 0
    worst = 0.0
    for index in region:
        matrix = matrices.get(index)
        if matrix is None:
            continue
        delta_posed = target[index] - posed_map[index]
        if delta_posed.length <= 1.0e-9:
            continue
        try:
            delta_rest = matrix.inverted() @ delta_posed
        except ValueError:
            continue
        local = object_inverse @ delta_rest
        key.data[index].co = key.data[index].co + local
        moved += 1
        worst = max(worst, delta_posed.length * 1000.0)

    report = {"mesh": mesh_object.name, "key": name, "region": len(region),
              "vertices_moved": moved,
              "largest_correction_mm": round(worst, 4),
              "mode": str(mode).upper(), "strength": strength,
              "feathered": strength_map is not None,
              "factor": factor, "repeat": repeat}

    if driver:
        bone_name = driver.get("bone", "")
        full = abs(float(driver.get("full_mm", 1.0))) * 0.001
        transform = driver.get("transform_type", "LOC_Z")
        if full <= 0.0:
            return report, "The driver's full-value distance must be non-zero"
        curve = key.driver_add("value")
        variable = curve.driver.variables.new()
        variable.name = "ctrl"
        variable.type = "TRANSFORMS"
        target_slot = variable.targets[0]
        target_slot.id = armature
        target_slot.bone_target = bone_name
        target_slot.transform_type = transform
        target_slot.transform_space = "LOCAL_SPACE"
        sign = -1.0 if float(driver.get("full_mm", 1.0)) < 0 else 1.0
        curve.driver.type = "SCRIPTED"
        # Clamped on purpose: past the control's own limit the correction should
        # hold, not keep growing.
        curve.driver.expression = "max(0.0, min(1.0, %f * ctrl / %f))" % (
            sign, full)
        # Calibrate the divisor against what the variable ACTUALLY reads at the
        # pose the key was sculpted at. A Transform Channel variable in Local
        # Space reports the bone's local translation, which is not
        # pose_bone.location unless the bone's rest axes happen to line up:
        # measured, 24mm of location on c_jawbone.x reads 21.74mm, so the key
        # reached only 0.9057 at its own sculpt pose and kept climbing for
        # another 2.5mm of input after a Limit Location constraint had already
        # stopped the bone. The skin crept on past the ceiling and put the lower
        # teeth back through it. One linear step is exact.
        pose_snapshot = [(pose_bone, tuple(pose_bone.location))
                         for pose_bone in armature.pose.bones]
        try:
            for bone, value in poses or ():
                other = armature.pose.bones.get(bone)
                if other is not None:
                    other.location = (value[0] * 0.001, value[1] * 0.001,
                                      value[2] * 0.001)
            bpy.context.view_layer.update()
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated = mesh_object.evaluated_get(depsgraph)
            reached = 1.0
            if evaluated.data.shape_keys:
                block = evaluated.data.shape_keys.key_blocks.get(name)
                if block is not None:
                    reached = float(block.value)
        finally:
            for pose_bone, value in pose_snapshot:
                pose_bone.location = value
            bpy.context.view_layer.update()
        calibrated = full
        if 0.02 < reached < 0.99:
            calibrated = full * reached
            curve.driver.expression = "max(0.0, min(1.0, %f * ctrl / %f))" % (
                sign, calibrated)
        report["driver"] = {"bone": bone_name, "transform": transform,
                            "full_mm": driver.get("full_mm"),
                            "reached_at_sculpt_pose": round(reached, 4),
                            "calibrated_mm": round(calibrated * 1000, 4),
                            "expression": curve.driver.expression}
    return report, ""


def remove_corrective(mesh_object, name):
    """Delete a corrective key and its driver. ``(report, error)``."""
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    keys = mesh_object.data.shape_keys
    if keys is None or keys.key_blocks.get(name) is None:
        return {"removed": False, "key": name}, ""
    # Remove ONLY this key's driver. Clearing the whole animation data takes
    # every other corrective's driver with it, which is silent: the keys survive,
    # they simply stop being driven, and the correction is absent exactly when it
    # is needed. That happened here -- rebuilding the lip key wiped the two lid
    # keys' drivers and the eyelid faceting came straight back.
    removed_driver = False
    animation = getattr(keys, "animation_data", None)
    if animation is not None:
        wanted = 'key_blocks["%s"].value' % name
        for curve in list(animation.drivers):
            if curve.data_path == wanted:
                animation.drivers.remove(curve)
                removed_driver = True
    mesh_object.shape_key_remove(keys.key_blocks[name])
    return {"removed": True, "key": name, "driver_removed": removed_driver}, ""


def confine(mesh_object, names, keep, taper_hops=3, epsilon_mm=0.001):
    """Pull a corrective's displacement back inside the region it was sculpted for.

    ``(report, error)``. ``keep`` is the set of vertices the key is allowed to
    move; everything else is faded to zero over ``taper_hops`` rings so no seam is
    introduced where the key is cut off.

    A corrective is sculpted in a viewport, and a sculpt does not stop neatly at a
    vertex set. Measured on the reference character: the two lid-closure
    correctives each displaced 31 vertices INSIDE the brow's footprint by up to
    3.049mm, so the brow area moved on every blink even though no bone moves there
    -- the eyebrow bones were checked and none of them is driven by the lid. That
    is invisible in a weight audit and invisible in a bone-motion audit, because
    it is neither.

    It only became visible once the brow card was re-bound to follow the skin: the
    card then inherited the motion and slid 2.81mm on a blink. Before that the
    card was rigid on the brow bones and simply ignored it, which is why a
    penetration was seen instead of a slide.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    keys = mesh_object.data.shape_keys
    if keys is None:
        return None, "%s has no shape keys" % mesh_object.name
    basis = keys.key_blocks.get("Basis")
    if basis is None:
        return None, "%s has no Basis" % mesh_object.name
    allowed = set(keep or ())
    if not allowed:
        return None, "No vertex given to keep"

    neighbours = {}
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        neighbours.setdefault(a, []).append(b)
        neighbours.setdefault(b, []).append(a)
    # Ring distance outward from the allowed set, so the fade is measured in the
    # mesh's own connectivity rather than through space.
    ring = {v: 0 for v in allowed}
    frontier = list(allowed)
    for step in range(1, int(max(1, taper_hops)) + 1):
        nxt = []
        for vertex in frontier:
            for other in neighbours.get(vertex, ()):
                if other not in ring:
                    ring[other] = step
                    nxt.append(other)
        frontier = nxt

    span = float(max(1, taper_hops)) + 1.0
    rows = []
    for name in names or ():
        block = keys.key_blocks.get(name)
        if block is None:
            rows.append({"key": name, "error": "absent"})
            continue
        touched = 0
        worst = 0.0
        for vertex in mesh_object.data.vertices:
            index = vertex.index
            if index in allowed:
                continue
            offset = block.data[index].co - basis.data[index].co
            length = offset.length * 1000.0
            if length <= epsilon_mm:
                continue
            distance = ring.get(index)
            factor = 0.0 if distance is None else                 max(0.0, 1.0 - float(distance) / span)
            if factor >= 0.999:
                continue
            block.data[index].co = basis.data[index].co + offset * factor
            touched += 1
            worst = max(worst, length * (1.0 - factor))
        rows.append({"key": name, "vertices_pulled_in": touched,
                     "largest_removed_mm": round(worst, 4)})
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "keys": rows,
            "kept": len(allowed), "taper_hops": taper_hops}, ""




def split_by_side(mesh_object, name, margin_mm=0.0):
    """Turn one two-sided corrective into a left one and a right one.

    ``(report, error)``. Each half keeps only its own side's displacement, and
    each gets a copy of the original's driver with the bone target's side suffix
    swapped to match. The original key is removed.

    A key that covers both sides but is driven by ONE side's controller fires the
    whole thing from half the rig. Measured on the reference character: the merged
    upper-eyelash mesh carried a single ``SRS lash ride`` driven by
    ``c_eyelid_top.l``, so closing the LEFT lid moved the RIGHT eyelashes 9.238mm.
    It is invisible to a weight audit -- the right lashes carry no left-side bone
    at all -- and invisible to a bone audit, because no bone moves either.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    keys = mesh_object.data.shape_keys
    if keys is None:
        return None, "%s has no shape keys" % mesh_object.name
    source = keys.key_blocks.get(name)
    basis = keys.key_blocks.get("Basis")
    if source is None or basis is None:
        return None, "%s has no key called %r" % (mesh_object.name, name)
    if name.endswith((".l", ".r")):
        return None, "%r is already sided" % name

    matrix = mesh_object.matrix_world
    stored = [source.data[v.index].co.copy() for v in mesh_object.data.vertices]
    value = source.value
    recipe = []
    if keys.animation_data:
        for curve in list(keys.animation_data.drivers):
            if '"%s"' % name not in curve.data_path:
                continue
            recipe.append({
                "type": curve.driver.type,
                "expression": curve.driver.expression,
                "variables": [
                    {"name": variable.name, "type": variable.type,
                     "targets": [{"id": slot.id, "bone": slot.bone_target or "",
                                  "path": slot.data_path or "",
                                  "transform": slot.transform_type,
                                  "space": slot.transform_space}
                                 for slot in variable.targets]}
                    for variable in curve.driver.variables]})

    made = []
    for suffix, sign in ((".l", 1.0), (".r", -1.0)):
        block = mesh_object.shape_key_add(name=name + suffix, from_mix=False)
        block.value = value
        moved = 0
        for vertex in mesh_object.data.vertices:
            index = vertex.index
            across = (matrix @ vertex.co).x * 1000.0
            if across * sign > margin_mm:
                block.data[index].co = stored[index]
                if (stored[index] - basis.data[index].co).length > 1.0e-6:
                    moved += 1
            else:
                block.data[index].co = basis.data[index].co
        made.append({"key": block.name, "vertices": moved})

        for entry in recipe:
            curve = keys.driver_add('key_blocks["%s"].value' % (name + suffix))
            driver = curve.driver
            driver.type = entry["type"]
            driver.expression = entry["expression"]
            for existing in list(driver.variables):
                driver.variables.remove(existing)
            for source_variable in entry["variables"]:
                variable = driver.variables.new()
                variable.name = source_variable["name"]
                variable.type = source_variable["type"]
                for slot, origin in zip(variable.targets,
                                        source_variable["targets"]):
                    slot.id = origin["id"]
                    bone = origin["bone"]
                    # The whole point: the left half is driven by the left
                    # controller and the right half by the right one.
                    if bone.endswith((".l", ".r")):
                        bone = bone[:-2] + suffix
                    slot.bone_target = bone
                    if origin["path"]:
                        slot.data_path = origin["path"]
                    slot.transform_type = origin["transform"]
                    slot.transform_space = origin["space"]

    if keys.animation_data:
        for curve in list(keys.animation_data.drivers):
            if '"%s"' % name in curve.data_path:
                try:
                    keys.animation_data.drivers.remove(curve)
                except (RuntimeError, ReferenceError):
                    pass
    index = mesh_object.data.shape_keys.key_blocks.find(name)
    if index >= 0:
        previous = mesh_object.active_shape_key_index
        mesh_object.active_shape_key_index = index
        try:
            bpy.ops.object.shape_key_remove()
        except RuntimeError:
            mesh_object.active_shape_key_index = previous
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "from": name, "made": made,
            "drivers_per_side": len(recipe)}, ""

def confine_by_plane(mesh_object, names, limits, epsilon_mm=0.001):
    """Fade a corrective to EXACTLY zero past a plane. ``(report, error)``.

    ``limits`` takes the same entries as :func:`face_falloff.plane_trim`, so the
    key and the weights are cut on the same boundary with the same smoothstep --
    if they disagree, the surface pulls apart at the seam.

    :func:`confine` fades over RINGS of vertices instead, and a ring fade cannot
    reach zero at a boundary that is defined by a coordinate: measured, it still
    moved the far side of the midline by 4.54mm, because the fade was only part way
    through when it crossed. "No influence at all past this plane" is a statement
    about a coordinate, so the fade has to be a function of that coordinate.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    keys = mesh_object.data.shape_keys
    if keys is None:
        return None, "%s has no shape keys" % mesh_object.name
    basis = keys.key_blocks.get("Basis")
    if basis is None:
        return None, "%s has no Basis" % mesh_object.name

    def ease(t):
        t = max(0.0, min(1.0, t))
        return t * t * (3.0 - 2.0 * t)

    matrix = mesh_object.matrix_world
    world = [matrix @ v.co for v in mesh_object.data.vertices]
    rows = []
    for name in names or ():
        block = keys.key_blocks.get(name)
        if block is None:
            rows.append({"key": name, "error": "absent"})
            continue
        side = ".l" if name.endswith(".l") else (
            ".r" if name.endswith(".r") else None)
        touched = 0
        worst = 0.0
        for vertex in mesh_object.data.vertices:
            index = vertex.index
            offset = block.data[index].co - basis.data[index].co
            length = offset.length * 1000.0
            if length <= epsilon_mm:
                continue
            factor = 1.0
            for limit in limits:
                if limit["kind"] == "side":
                    if side is None:
                        continue
                    axis = 0
                    keep = "above" if side == ".l" else "below"
                    at = 0.0
                else:
                    axis, keep, at = limit["axis"], limit["keep"], limit["at"]
                taper = max(float(limit["taper_mm"]) * 0.001, 1.0e-6)
                value = world[index][axis]
                inside = (at - value) if keep == "below" else (value - at)
                factor = min(factor,
                             ease(inside / taper) if inside > 0.0 else 0.0)
            if factor >= 0.999:
                continue
            block.data[index].co = basis.data[index].co + offset * factor
            touched += 1
            worst = max(worst, length * (1.0 - factor))
        rows.append({"key": name, "vertices_pulled_in": touched,
                     "largest_removed_mm": round(worst, 4)})
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "keys": rows}, ""


def loop_scale_roughness(mesh_object, armature, poses, indices):
    """How unevenly the edge loops stretch under a pose. ``(report, error)``.

    For every interior edge in the region, the ratio of its posed length to its
    rest length; then the spread of that ratio between edges that SHARE a vertex.
    A deformation that reads as clean has neighbouring edges scaling by nearly the
    same amount; a dirty one has them disagreeing, and that is loops bunching
    against loops that spread.

    This is a different question from the angle between faces, and it is the one
    that matches "the polygon flow is dirty". A surface can hold every dihedral
    angle it had at rest and still look wrong because the loops stopped running
    evenly -- which is why a dihedral-only gate reported a region as smoother than
    rest while it still read as juddering.
    """
    from . import face_regions

    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    scope = set(indices or ())
    if not scope:
        return None, "No region given"
    edges = [tuple(e.vertices) for e in mesh_object.data.edges
             if e.vertices[0] in scope and e.vertices[1] in scope]
    if not edges:
        return None, "No interior edge in the region"
    hidden = [m for m in mesh_object.modifiers
              if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    saved = face_regions._pose_snapshot(armature)

    def lengths():
        bpy.context.view_layer.update()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = mesh_object.evaluated_get(depsgraph)
        matrix = evaluated.matrix_world
        coords = [matrix @ v.co for v in evaluated.data.vertices]
        return [(coords[a] - coords[b]).length for a, b in edges]

    try:
        face_regions._pose_neutral(saved)
        rest = lengths()
        face_regions.apply_pose(armature, poses)
        posed = lengths()
    finally:
        face_regions._pose_restore(saved)
        bpy.context.view_layer.update()
        for modifier in hidden:
            modifier.show_viewport = True

    ratio = {}
    for index in range(len(edges)):
        if rest[index] > 1.0e-9:
            ratio[index] = posed[index] / rest[index]
    touching = {}
    for index, (a, b) in enumerate(edges):
        if index not in ratio:
            continue
        touching.setdefault(a, []).append(index)
        touching.setdefault(b, []).append(index)
    spread = []
    for _vertex, group in touching.items():
        values = [ratio[i] for i in group]
        if len(values) > 1:
            spread.append(max(values) - min(values))
    if not spread:
        return None, "Not enough shared edges to compare"
    spread.sort(reverse=True)
    return {"edges": len(ratio), "vertices": len(spread),
            "p95": round(spread[int(0.05 * (len(spread) - 1))], 5),
            "max": round(spread[0], 5),
            "median": round(spread[len(spread) // 2], 5),
            "stretch_range": [round(min(ratio.values()), 4),
                              round(max(ratio.values()), 4)]}, ""


def fade_across_midline(mesh_object, names, band_mm=6.0):
    """Make a sided corrective die at the centre line. ``(report, error)``.

    Each named key's displacement is scaled by how far the vertex is onto the
    key's OWN side -- zero at the centre, full by ``band_mm`` -- and set to zero
    on the other side outright.

    :func:`confine` fades OUTWARD from the region it keeps, which is right for a
    region with an interior but wrong for a side: the first rings across the
    centre line keep most of their displacement. Measured on the reference
    character, a strictly-sided confine still left the right half of the face
    moving 3.387mm when the LEFT lower-lid control was used, because the key's
    right-side vertices sat within the fade. Scaling by distance onto the own side
    leaves nothing at all on the far side, and no step at the centre either.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    keys = mesh_object.data.shape_keys
    if keys is None:
        return None, "%s has no shape keys" % mesh_object.name
    basis = keys.key_blocks.get("Basis")
    if basis is None:
        return None, "%s has no Basis" % mesh_object.name
    matrix = mesh_object.matrix_world
    span = max(band_mm, 1.0e-6)
    rows = []
    for name in names or ():
        block = keys.key_blocks.get(name)
        if block is None:
            rows.append({"key": name, "error": "absent"})
            continue
        if name.endswith(".l"):
            sign = 1.0
        elif name.endswith(".r"):
            sign = -1.0
        else:
            rows.append({"key": name, "error": "not sided"})
            continue
        touched = 0
        worst = 0.0
        for vertex in mesh_object.data.vertices:
            index = vertex.index
            offset = block.data[index].co - basis.data[index].co
            length = offset.length * 1000.0
            if length <= 0.001:
                continue
            across = (matrix @ vertex.co).x * 1000.0 * sign
            factor = max(0.0, min(1.0, across / span))
            factor = factor * factor * (3.0 - 2.0 * factor)
            if factor >= 0.999:
                continue
            block.data[index].co = basis.data[index].co + offset * factor
            touched += 1
            worst = max(worst, length * (1.0 - factor))
        rows.append({"key": name, "faded": touched,
                     "largest_removed_mm": round(worst, 4)})
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "keys": rows, "band_mm": band_mm}, ""
