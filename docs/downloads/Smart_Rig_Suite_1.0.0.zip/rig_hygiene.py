# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""What a rig still needs after it deforms correctly.

Deformation gates -- weight sums, surface quality, closure, follow -- cannot see
any of the defects in here, and every one of them was found on a rig that passed
all of them:

* Twenty-four channels measured dead and left unlocked. All three scale channels
  on the four eyelid controllers move nothing at all, because nothing downstream
  copies scale, yet they are offered to the animator; a rig that offers a dead
  channel teaches the animator that it works.
* Controllers with no ceiling. 1mm of forward travel on a teeth controller -- less
  than anyone would call a pose -- puts the row through the lip, and the tongue
  leaves the face at 2.6mm. No weight or surface metric can see it, because the
  teeth and the tongue carry no weight on the face at all.
* Geometry bound to a bone that does not deform. Five hair meshes carried exactly
  one vertex group, ``c_head.x``, whose bone has ``use_deform`` False, so the
  armature modifier ignored it: a 30 degree head turn left the hair behind and
  pushed the skull 35mm through the cap.
* Geometry bound to nothing. Five head props had no parent, no armature modifier
  and no vertex group.
* Drivers that silently do not evaluate. Two lip offsets read a custom property
  that does not exist, so they alone ignore the jaw-retain slider -- invisible
  while the slider is at zero, wrong the moment it is touched.

Nothing here writes to the user's Blender or to a live scene; every function
takes the objects it is given and reports what it measured.
"""

import bpy

# A channel is a (kind, axis) pair. Scale is swept both ways because a shrink and
# a stretch can damage differently.
CHANNEL_KINDS = ("location", "rotation", "scale")
AXES = (0, 1, 2)

# Below this a channel moved nothing we can see. It is not zero: floating point
# and constraint re-solving produce a few ten-thousandths of a millimetre on
# channels that are genuinely ignored.
DEAD_FLOOR_MM = 0.002

# Channels that read dead only because an Auto-Rig Pro option is switched off or
# a target mode is on. These are NOT locked -- locking them would hide the option
# rather than the defect, and the option is the user's to change. Each entry says
# which property decides, so a report can name it.
OPTION_GATED = (
    (("c_eye.l", "c_eye.r", "c_eye_target.l", "c_eye_target.r", "c_eye_target.x"),
     "rotation",
     "the eye-target mode: c_eye_target.x['eye_target'] is on, so the eye is "
     "aimed by its target and its own rotation is overridden by a Damped Track"),
)

# Matched by exact name, never by prefix: "c_eye" as a prefix also catches every
# c_eyelid_* bone, and their rotation channels are live (rot Z on c_eyelid_top
# closes the aperture from 17.5 to 13.2mm), so a prefix match would quietly
# excuse a live channel from being judged.


def _set_channel(pose_bone, kind, axis, amount):
    """Write one channel, in millimetres / degrees / factor. Returns a restore."""
    import math

    if kind == "location":
        before = tuple(pose_bone.location)
        value = list(before)
        value[axis] = amount * 0.001
        pose_bone.location = value
        return ("location", before)
    if kind == "rotation":
        if pose_bone.rotation_mode == "QUATERNION":
            import mathutils
            before = tuple(pose_bone.rotation_quaternion)
            euler = [0.0, 0.0, 0.0]
            euler[axis] = math.radians(amount)
            pose_bone.rotation_quaternion = mathutils.Euler(
                euler, "XYZ").to_quaternion()
            return ("rotation_quaternion", before)
        before = tuple(pose_bone.rotation_euler)
        value = list(before)
        value[axis] = math.radians(amount)
        pose_bone.rotation_euler = value
        return ("rotation_euler", before)
    before = tuple(pose_bone.scale)
    value = list(before)
    value[axis] = amount
    pose_bone.scale = value
    return ("scale", before)


def _restore(pose_bone, saved):
    setattr(pose_bone, saved[0], saved[1])


def _world_positions(mesh_object):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = mesh_object.evaluated_get(depsgraph)
    matrix = mesh_object.matrix_world
    return [matrix @ v.co for v in evaluated.data.vertices]


def _lock_attribute(kind):
    return {"location": "lock_location", "rotation": "lock_rotation",
            "scale": "lock_scale"}[kind]


def channel_sweep(armature, bone_names, meshes, location_mm=5.0,
                  rotation_deg=15.0, scale_factor=1.25,
                  floor_mm=DEAD_FLOOR_MM):
    """What each channel of each controller actually moves. ``(report, error)``.

    For every unlocked channel it poses the bone both ways and reports the largest
    displacement over every mesh given. A channel under ``floor_mm`` on all of
    them is dead; the rest are reported with their gain so an undesigned channel
    at full gain can be seen next to the one the control was built for.

    Only unlocked channels are swept: a locked channel is already unavailable, and
    sweeping it would report motion the animator cannot reach.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    targets = [m for m in (meshes or ()) if m is not None and m.type == "MESH"]
    if not targets:
        return None, "No mesh to measure the motion on"

    hidden = [m for obj in targets for m in obj.modifiers
              if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    bpy.context.view_layer.update()
    try:
        rest = {obj.name: _world_positions(obj) for obj in targets}
        rows = []
        for bone_name in bone_names or ():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue
            for kind in CHANNEL_KINDS:
                locks = getattr(pose_bone, _lock_attribute(kind))
                for axis in AXES:
                    if bool(locks[axis]):
                        continue
                    amounts = ((location_mm, -location_mm) if kind == "location"
                               else (rotation_deg, -rotation_deg)
                               if kind == "rotation"
                               else (scale_factor, 1.0 / scale_factor))
                    worst = 0.0
                    worst_mesh = ""
                    for amount in amounts:
                        saved = _set_channel(pose_bone, kind, axis, amount)
                        bpy.context.view_layer.update()
                        try:
                            for obj in targets:
                                now = _world_positions(obj)
                                base = rest[obj.name]
                                if len(now) != len(base):
                                    continue
                                moved = max(((a - b).length * 1000)
                                            for a, b in zip(now, base))
                                if moved > worst:
                                    worst, worst_mesh = moved, obj.name
                        finally:
                            _restore(pose_bone, saved)
                            bpy.context.view_layer.update()
                    rows.append({"bone": bone_name, "kind": kind, "axis": axis,
                                 "moved_mm": round(worst, 4),
                                 "on": worst_mesh,
                                 "dead": worst <= floor_mm})
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
        bpy.context.view_layer.update()

    dead = [r for r in rows if r["dead"]]
    gated = []
    for row in dead:
        for names, kind, why in OPTION_GATED:
            if row["bone"] in names and row["kind"] == kind:
                gated.append(dict(row, gated_by=why))
                break
    gated_keys = {(r["bone"], r["kind"], r["axis"]) for r in gated}
    return {
        "channels": len(rows), "rows": rows,
        "dead": [r for r in dead
                 if (r["bone"], r["kind"], r["axis"]) not in gated_keys],
        "dead_count": len([r for r in dead
                           if (r["bone"], r["kind"], r["axis"])
                           not in gated_keys]),
        # Reported, never locked: these are inert because of an option, and the
        # option belongs to the user.
        "inert_by_option": gated,
        "floor_mm": floor_mm,
        "live": sorted((r for r in rows if not r["dead"]),
                       key=lambda r: -r["moved_mm"])[:24],
    }, ""


def lock_channels(armature, channels):
    """Set the lock flag on each ``(bone, kind, axis)``. ``(report, error)``.

    Lock flags do not survive an Auto-Rig Pro match-to-rig regeneration, so the
    report is the record that says which pass to re-apply.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    done, missing = [], []
    for bone_name, kind, axis in channels or ():
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None or kind not in CHANNEL_KINDS:
            missing.append([bone_name, kind, axis])
            continue
        attribute = _lock_attribute(kind)
        locks = list(getattr(pose_bone, attribute))
        if locks[axis]:
            continue
        locks[axis] = True
        setattr(pose_bone, attribute, locks)
        done.append([bone_name, kind, axis])
    return {"locked": done, "locked_count": len(done), "missing": missing}, ""


SRS_LIMIT_LOCATION = "SRS Limit Location"
SRS_LIMIT_ROTATION = "SRS Limit Rotation"


def clamp_controller(armature, bone_name, location=None, rotation=None):
    """Give a controller a ceiling. ``(report, error)``.

    ``location`` is ``{axis: (min_mm, max_mm)}`` and ``rotation``
    ``{axis: (min_deg, max_deg)}``; ``None`` for a bound leaves that side open.
    The constraints are LOCAL space, so the numbers are the ones the animator sees
    in the N panel, and they are named so a later pass can find and re-tune them
    instead of stacking a second copy.

    ``use_transform_limit`` is on deliberately: without it the limit is applied
    after the transform is read, so the control keeps sliding while the bone stops
    moving -- the animator sees a dead control rather than a limit.
    """
    import math

    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None, "%s has no bone %s" % (armature.name, bone_name)
    out = {"bone": bone_name}

    def ensure(kind, name):
        existing = pose_bone.constraints.get(name)
        if existing is not None:
            return existing, False
        made = pose_bone.constraints.new(kind)
        made.name = name
        return made, True

    if location:
        constraint, created = ensure("LIMIT_LOCATION", SRS_LIMIT_LOCATION)
        constraint.owner_space = "LOCAL"
        constraint.use_transform_limit = True
        for axis, bounds in location.items():
            letter = "xyz"[int(axis)]
            low, high = bounds
            setattr(constraint, "use_min_" + letter, low is not None)
            setattr(constraint, "use_max_" + letter, high is not None)
            if low is not None:
                setattr(constraint, "min_" + letter, low * 0.001)
            if high is not None:
                setattr(constraint, "max_" + letter, high * 0.001)
        out["location"] = {"created": created,
                           "bounds_mm": {str(k): list(v)
                                         for k, v in location.items()}}
    if rotation:
        constraint, created = ensure("LIMIT_ROTATION", SRS_LIMIT_ROTATION)
        constraint.owner_space = "LOCAL"
        constraint.use_transform_limit = True
        for axis, bounds in rotation.items():
            letter = "xyz"[int(axis)]
            low, high = bounds
            setattr(constraint, "use_limit_" + letter, True)
            setattr(constraint, "min_" + letter,
                    math.radians(-360.0 if low is None else low))
            setattr(constraint, "max_" + letter,
                    math.radians(360.0 if high is None else high))
        out["rotation"] = {"created": created,
                           "bounds_deg": {str(k): list(v)
                                          for k, v in rotation.items()}}
    if not location and not rotation:
        return None, "Nothing to clamp was given"
    return out, ""


def _world_tree(mesh_object, polygon_indices=None):
    from mathutils.bvhtree import BVHTree

    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated = mesh_object.evaluated_get(depsgraph)
    matrix = mesh_object.matrix_world
    points = [matrix @ v.co for v in evaluated.data.vertices]
    wanted = None if polygon_indices is None else set(polygon_indices)
    polygons = [list(p.vertices) for p in evaluated.data.polygons
                if wanted is None or p.index in wanted]
    if not polygons:
        return None
    return BVHTree.FromPolygons(points, polygons, all_triangles=False,
                                epsilon=0.0)


def outer_skin_polygons(face_object, epsilon_mm=0.05, reach_mm=500.0):
    """The polygons of a face that are on the OUTSIDE. ``(indices, error)``.

    A face mesh with an open crown and a modelled mouth bag is not watertight, so
    no parity or signed-distance test on it is valid -- which is exactly the test
    a "did the teeth come through the skin" check needs. This is the test that
    does work: a polygon is outside if nothing of the same mesh stands in front of
    it. The mouth bag fails that immediately, because every polygon inside a
    closed mouth faces another one across the cavity.

    Suppression rule that ships with it: a polygon at the bottom of a deep crease
    -- a nostril, an ear canal -- can see the opposite wall of its own crease and
    is reported as inner. That is conservative for a penetration test (fewer
    polygons to hit, never a false breach), and the count is returned so a caller
    can see how much was excluded rather than assume.
    """
    if face_object is None or face_object.type != "MESH":
        return None, "No face mesh"
    # The indices are read back by scan_travel, which measures with these modifiers
    # hidden. Taken with a Subdivision on, they name other polygons there: the mouth bag
    # counted as skin, the teeth "breached" it at rest and the jaw ceiling came out 0mm.
    hidden = [m for m in face_object.modifiers if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    bpy.context.view_layer.update()
    try:
        tree = _world_tree(face_object)
        if tree is None:
            return None, "%s evaluates to no faces" % face_object.name
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = face_object.evaluated_get(depsgraph)
        matrix = face_object.matrix_world
        normal_matrix = matrix.to_3x3().inverted().transposed()
        outer = []
        for polygon in evaluated.data.polygons:
            centre = matrix @ polygon.center
            normal = (normal_matrix @ polygon.normal).normalized()
            origin = centre + normal * (epsilon_mm * 0.001)
            hit = tree.ray_cast(origin, normal, reach_mm * 0.001)
            if hit[0] is None:
                outer.append(polygon.index)
        count = len(evaluated.data.polygons)
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
        bpy.context.view_layer.update()
    return {"outer": outer, "outer_count": len(outer),
            "polygons": count,
            "inner_count": count - len(outer)}, ""


def penetration(moving, static, static_polygons=None):
    """Triangle pairs where one mesh is inside the other. ``(report, error)``.

    Intersecting triangles, not distances: a signed-distance test needs a
    watertight surface and a nearest-point test on a folded one reports the fold,
    not the breach.
    """
    if moving is None or static is None:
        return None, "Need both meshes"
    a = _world_tree(moving)
    b = _world_tree(static, static_polygons)
    if a is None or b is None:
        return None, "One of the meshes evaluates to no faces"
    pairs = a.overlap(b)
    nearest = None
    for vertex in _world_positions(moving):
        hit = b.find_nearest(vertex)
        if hit[0] is not None:
            distance = (vertex - hit[0]).length * 1000
            if nearest is None or distance < nearest:
                nearest = distance
    return {"moving": moving.name, "static": static.name,
            "pairs": len(pairs),
            "nearest_mm": None if nearest is None else round(nearest, 4)}, ""


def rest_penetration(moving, static, static_polygons):
    """:func:`penetration` with the modifiers hidden, as the polygon indices of
    :func:`outer_skin_polygons` and the travel scans are. With a Subdivision on,
    those indices name other polygons and a real breach reads as none."""
    hidden = [m for obj in (moving, static) if obj is not None
              for m in obj.modifiers if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    bpy.context.view_layer.update()
    try:
        return penetration(moving, static, static_polygons)
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
        bpy.context.view_layer.update()


def safe_travel(armature, bone_name, kind, axis, moving, static,
                static_polygons=None, limit=40.0, tolerance=0.1,
                baseline_pairs=None, extra_poses=()):
    """The largest travel on one channel that does not breach. ``(report, error)``.

    Bisects between zero and ``limit`` for the last value whose penetration count
    is no worse than at rest. ``baseline_pairs`` is that rest count: pass it in
    when the mesh is already interpenetrating at rest, so the search reports the
    travel that adds no NEW breach rather than refusing everything.

    A limit derived this way is only as good as the rest clearance. Where that
    clearance is a hundredth of a millimetre the honest answer is "no travel", and
    the caller should be told to fix the model rather than given a number that
    pretends the control works.
    """
    if armature is None:
        return None, "No armature"
    if kind == "scale":
        return None, ("Scale has no zero to bisect from -- sweep it with "
                      "channel_sweep and lock it, or clamp it by hand")
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None, "%s has no bone %s" % (armature.name, bone_name)
    hidden = [m for obj in (moving, static) if obj is not None
              for m in obj.modifiers if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    saved_extra = []
    for name, value in extra_poses or ():
        other = armature.pose.bones.get(name)
        if other is not None:
            saved_extra.append((other, tuple(other.location)))
    bpy.context.view_layer.update()

    def pairs_at(amount):
        saved = _set_channel(pose_bone, kind, axis, amount)
        bpy.context.view_layer.update()
        try:
            report, error = penetration(moving, static, static_polygons)
            return (None if error else report["pairs"],
                    None if error else report["nearest_mm"])
        finally:
            _restore(pose_bone, saved)
            bpy.context.view_layer.update()

    try:
        for name, value in extra_poses or ():
            other = armature.pose.bones.get(name)
            if other is not None:
                other.location = (value[0] * 0.001, value[1] * 0.001,
                                  value[2] * 0.001)
        bpy.context.view_layer.update()
        rest_pairs, rest_gap = pairs_at(0.0)
        if rest_pairs is None:
            return None, "Could not measure the rest state"
        allowed = rest_pairs if baseline_pairs is None else baseline_pairs
        top_pairs, _gap = pairs_at(limit)
        if top_pairs is not None and top_pairs <= allowed:
            return {"bone": bone_name, "kind": kind, "axis": axis,
                    "safe_mm": round(limit, 3), "rest_pairs": rest_pairs,
                    "rest_gap_mm": rest_gap, "at_limit_pairs": top_pairs,
                    "note": "clean to the whole range asked for"}, ""
        low, high = 0.0, limit
        while high - low > tolerance:
            middle = 0.5 * (low + high)
            count, _g = pairs_at(middle)
            if count is not None and count <= allowed:
                low = middle
            else:
                high = middle
        breach_pairs, breach_gap = pairs_at(high)
    finally:
        for other, value in saved_extra:
            other.location = value
        bpy.context.view_layer.update()
        for modifier in hidden:
            modifier.show_viewport = True
    return {"bone": bone_name, "kind": kind, "axis": axis,
            "safe_mm": round(low, 3), "breach_mm": round(high, 3),
            "rest_pairs": rest_pairs, "rest_gap_mm": rest_gap,
            "breach_pairs": breach_pairs, "breach_gap_mm": breach_gap,
            "note": ("the rest clearance is what limits this, not the control"
                     if rest_gap is not None and rest_gap < 0.5 else "")}, ""


def scan_travel(armature, bone_name, kind, axis, moving, static,
                static_polygons=None, limit=40.0, step=1.0, baseline_pairs=None,
                meshes=(), min_gap_mm=0.0):
    """Walk a channel out in fixed steps and report where it first breaches.

    Use this, not :func:`safe_travel`, to derive a limit. Bisection assumes the
    breach count only ever grows with travel, and it does not: a bisection put the
    ceiling at 27.1mm on a channel that already breached at 27.0, because the
    three points it happened to sample were all clean. A scan cannot be fooled
    that way, and 40 penetration tests cost seconds.

    ``meshes`` is an optional list of ``(mesh, baseline_pairs)`` to test together,
    for a control that can push more than one thing through the skin.

    ``min_gap_mm`` is what makes the answer stable, and on a model with a tight
    interior it is not optional. Counting triangle pairs alone put the jaw ceiling
    at a pose where the teeth stood 0.0005mm from the skin: the same clamped pose
    then reported a breach or no breach depending on floating-point noise in the
    evaluation. Requiring a real gap gives a ceiling that means something, and when
    the gap it finds is far below the rest clearance the answer to report is that
    the model has no room to spend, not a number.

    The gap is asked of the ceiling, not of the road to it: the gap rises and falls
    along the travel. Teeth that passed the lip at 0.09mm one step out and stayed
    clear for another 24mm would otherwise have put the jaw's ceiling at 0.5mm. So
    the walk goes on to the first real breach, and the ceiling is the highest clean
    step before it that has the gap.
    """
    if armature is None:
        return None, "No armature"
    if kind == "scale":
        return None, "Scale has no zero to scan from"
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None, "%s has no bone %s" % (armature.name, bone_name)
    pairs = list(meshes) if meshes else [(moving, baseline_pairs)]
    watched = [m for m, _b in pairs if m is not None]
    hidden = [m for obj in watched + [static] if obj is not None
              for m in obj.modifiers if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    bpy.context.view_layer.update()
    rows = []
    try:
        floors = []
        for mesh, given in pairs:
            if given is not None:
                floors.append(given)
                continue
            report, error = penetration(mesh, static, static_polygons)
            floors.append(0 if error else report["pairs"])
        steps = int(max(1, round(abs(limit) / float(step))))
        sign = 1.0 if limit >= 0 else -1.0
        first_breach = None
        safe = 0.0
        for index in range(1, steps + 1):
            amount = sign * index * float(step)
            saved = _set_channel(pose_bone, kind, axis, amount)
            bpy.context.view_layer.update()
            counts, gaps = [], []
            try:
                for (mesh, _given), floor in zip(pairs, floors):
                    report, error = penetration(mesh, static, static_polygons)
                    counts.append(None if error else report["pairs"] - floor)
                    gaps.append(None if error else report["nearest_mm"])
            finally:
                _restore(pose_bone, saved)
                bpy.context.view_layer.update()
            tight = [g for g in gaps if g is not None and g < min_gap_mm]
            rows.append({"mm": round(amount, 3), "new_pairs": counts,
                         "gap_mm": gaps})
            if any(c is None or c > 0 for c in counts):
                first_breach = amount
                break
            if not tight:
                safe = amount
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
        bpy.context.view_layer.update()
    return {"bone": bone_name, "kind": kind, "axis": axis,
            "safe_mm": round(safe, 3),
            "first_breach_mm": None if first_breach is None else round(first_breach, 3),
            "step_mm": step, "min_gap_mm": min_gap_mm, "rest_pairs": floors,
            "scan": rows}, ""


DRIVER_BACKUP_KEY = "srs_driver_expression_backup"


def clamp_driver_reads(armature, bone_name, axis, low_mm, high_mm,
                       kind="location"):
    """Make drivers that read a control's RAW channel respect its limit.

    A Limit Location constraint bounds the bone. It does not bound a driver that
    reads ``pose.bones["<bone>"].location[<axis>]``, because a Single Property
    variable reads the stored channel, not the constrained result. Auto-Rig Pro's
    lip-retain mechanism does exactly that -- ``jaw_ret_bone.x``'s scale is
    ``max(0.05, 1 - (jaw_rot / 0.0556) * stretch_value)`` with ``jaw_rot`` reading
    the raw jaw channel -- so past a 24mm jaw ceiling the jaw stopped while the
    lips kept being pulled in, 4.16mm at the mouth corner, until the lower teeth
    touched the skin again. Every "the clamp does not hold" reading came from
    this.

    Each affected expression is wrapped, not rewritten: the variable ``v`` becomes
    ``min(max(v, low), high)``. The original is stored on the armature under
    ``srs_driver_expression_backup`` so the change can be undone, and an
    Auto-Rig Pro regeneration will replace these drivers, so the report is the
    record of which pass to repeat.
    """
    import re

    if armature is None or armature.animation_data is None:
        return None, "No armature with drivers"
    target_path = 'pose.bones["%s"].%s[%d]' % (bone_name, kind, int(axis))
    low, high = float(low_mm) * 0.001, float(high_mm) * 0.001
    backup = dict(armature.get(DRIVER_BACKUP_KEY) or {})
    changed = []
    for curve in armature.animation_data.drivers:
        driver = curve.driver
        names = []
        for variable in driver.variables:
            if variable.type != "SINGLE_PROP":
                continue
            for slot in variable.targets:
                if (slot.data_path or "") == target_path:
                    names.append(variable.name)
        if not names:
            continue
        key = "%s|%d" % (curve.data_path, curve.array_index)
        expression = driver.expression
        if key in backup:
            expression = backup[key]
        wrapped = expression
        for name in sorted(set(names)):
            if "max(%s," % name in wrapped or "min(max(%s" % name in wrapped:
                continue
            wrapped = re.sub(r"\b%s\b" % re.escape(name),
                             "min(max(%s, %r), %r)" % (name, low, high),
                             wrapped)
        if wrapped == expression:
            continue
        backup[key] = expression
        driver.expression = wrapped
        changed.append({"path": curve.data_path, "index": curve.array_index,
                        "was": expression, "now": wrapped,
                        "variables": sorted(set(names))})
    if changed:
        armature[DRIVER_BACKUP_KEY] = backup
        armature.data.update_tag()
        bpy.context.view_layer.update()
    return {"bone": bone_name, "channel": "%s[%d]" % (kind, int(axis)),
            "bounds_mm": [low_mm, high_mm], "changed": changed,
            "changed_count": len(changed)}, ""


def restore_clamped_drivers(armature):
    """Put every expression clamp_driver_reads touched back the way it was."""
    if armature is None:
        return None, "No armature"
    backup = dict(armature.get(DRIVER_BACKUP_KEY) or {})
    if not backup or armature.animation_data is None:
        return {"restored": 0}, ""
    restored = 0
    for curve in armature.animation_data.drivers:
        key = "%s|%d" % (curve.data_path, curve.array_index)
        if key in backup:
            curve.driver.expression = backup[key]
            restored += 1
    del armature[DRIVER_BACKUP_KEY]
    armature.data.update_tag()
    bpy.context.view_layer.update()
    return {"restored": restored}, ""


def nondeform_groups(armature, meshes):
    """Meshes bound to a bone the armature modifier ignores. ``(report, error)``.

    A vertex group naming a bone with ``use_deform`` False is skinning that does
    nothing, and it looks bound from every angle: the modifier is there, the group
    is there, the name matches a real bone. The suggestion is that bone's nearest
    deforming relative with the same stem -- ``c_head.x`` suggests ``head.x`` --
    and it is a suggestion, not an edit.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    bones = armature.data.bones

    def deform_names(mesh):
        """Deform bones of EVERY armature modifier on this mesh, not just one.

        Measured the hard way, twice: bodyA carries c_thigh_bend_*, c_waist_bend.x
        and c_arm_bend.r, which deform on the ADDITIVE rig rig_add and not on rig,
        and comparing against one armature reported six correctly-weighted groups
        as orphans and then a whole mesh as mis-bound.
        """
        names = set()
        for modifier in mesh.modifiers:
            if modifier.type != "ARMATURE" or modifier.object is None:
                continue
            names |= {b.name for b in modifier.object.data.bones if b.use_deform}
        return names

    all_deforming = {b.name for b in bones if b.use_deform}

    def suggest(name):
        stem = name[2:] if name.startswith("c_") else name
        for candidate in (stem, "def_" + stem, stem.replace("c_", "")):
            if candidate in all_deforming:
                return candidate
        bone = bones.get(name)
        if bone is not None:
            for child in bone.children_recursive:
                if child.use_deform:
                    return child.name
        return ""

    rows = []
    for mesh in meshes or ():
        if mesh is None or mesh.type != "MESH":
            continue
        if not any(m.type == "ARMATURE" and m.object is armature
                   for m in mesh.modifiers):
            continue
        # An EMPTY group naming a control bone is what Auto-Rig Pro leaves behind
        # everywhere and is not a defect; only a group that carries weight the
        # modifier then ignores is. Reporting both buried the five meshes that
        # were genuinely bound to nothing under thirteen rows.
        carried = set()
        for vertex in mesh.data.vertices:
            for entry in vertex.groups:
                if entry.weight > 0.0:
                    carried.add(entry.group)
        deforming = deform_names(mesh)
        dead = [g.name for g in mesh.vertex_groups
                if g.name in bones.keys() and g.name not in deforming
                and g.index in carried]
        live = [g.name for g in mesh.vertex_groups
                if g.name in deforming and g.index in carried]
        if dead and not live:
            rows.append({"mesh": mesh.name, "groups": dead,
                         "suggest": {n: suggest(n) for n in dead},
                         "severity": "bound to nothing"})
        elif dead:
            rows.append({"mesh": mesh.name, "groups": dead,
                         "suggest": {n: suggest(n) for n in dead},
                         "severity": "part of the weight is ignored"})
    return {"rows": rows, "count": len(rows)}, ""


def retarget_group(mesh, old_name, new_name):
    """Rename a vertex group, merging into the target if it already exists."""
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    source = mesh.vertex_groups.get(old_name)
    if source is None:
        return None, "%s has no group %s" % (mesh.name, old_name)
    target = mesh.vertex_groups.get(new_name)
    if target is None:
        source.name = new_name
        return {"mesh": mesh.name, "renamed": [old_name, new_name],
                "merged": 0}, ""
    merged = 0
    for vertex in mesh.data.vertices:
        for entry in vertex.groups:
            if entry.group == source.index and entry.weight > 0.0:
                target.add([vertex.index], entry.weight, "REPLACE")
                merged += 1
    mesh.vertex_groups.remove(source)
    return {"mesh": mesh.name, "renamed": [old_name, new_name],
            "merged": merged}, ""


def bind_rigid(obj, armature, bone_name):
    """Parent a prop to one bone without moving it. ``(report, error)``.

    For something that should ride a bone as a solid piece -- a headset, a
    piercing. Bone parenting rather than an armature modifier plus a full-weight
    group: it is one relationship instead of two, and there is no weight to
    normalise or to lose in a later pass.
    """
    if obj is None or armature is None:
        return None, "Need the object and the armature"
    if armature.data.bones.get(bone_name) is None:
        return None, "%s has no bone %s" % (armature.name, bone_name)
    before = obj.matrix_world.copy()
    obj.parent = armature
    obj.parent_type = "BONE"
    obj.parent_bone = bone_name
    # Setting the world matrix back is what keeps the prop where the modeller put
    # it: bone parenting puts the child at the bone's TAIL otherwise.
    obj.matrix_world = before
    bpy.context.view_layer.update()
    moved = (obj.matrix_world.translation - before.translation).length * 1000
    return {"object": obj.name, "bone": bone_name,
            "moved_mm": round(moved, 5)}, ""


def invalid_drivers(armature):
    """Drivers that do not evaluate, and why. ``(report, error)``."""
    if armature is None:
        return None, "No armature"
    animation = armature.animation_data
    if animation is None:
        return {"rows": [], "count": 0}, ""
    rows = []
    for curve in animation.drivers:
        driver = curve.driver
        if driver.is_valid:
            continue
        missing = []
        for variable in driver.variables:
            for target in variable.targets:
                path = target.data_path or ""
                if not path:
                    continue
                # A single-property driver target reads
                # pose.bones["<bone>"]["<property>"], so the bracketed strings
                # are what identifies it. Stripping brackets off the whole path
                # produced 'pose.bones["c_jawbone.x"]["lips_retain' and reported
                # a property that exists as missing.
                import re

                quoted = re.findall(r'\["([^"]+)"\]', path)
                if not quoted:
                    continue
                key = quoted[-1]
                bone_name = ""
                if path.startswith("pose.bones[") and len(quoted) >= 2:
                    bone_name = quoted[0]
                elif target.bone_target:
                    bone_name = target.bone_target
                holder = (armature.pose.bones.get(bone_name) if bone_name
                          else (target.id if target.id is not None else None))
                if holder is not None and key not in holder.keys():
                    missing.append({"variable": variable.name,
                                    "bone": bone_name,
                                    "property": key})
        rows.append({"data_path": curve.data_path,
                     "array_index": curve.array_index,
                     "expression": driver.expression,
                     "missing_properties": missing})
    return {"rows": rows, "count": len(rows)}, ""


def repair_invalid_drivers(armature, value=0.0):
    """Add the custom properties invalid drivers are reading. ``(report, error)``.

    ``value`` defaults to 0.0 because that is the value that preserves today's
    behaviour exactly: the driver was evaluating as if the term were absent. Any
    other value changes how the rig moves, so it is the caller's to choose.
    """
    report, error = invalid_drivers(armature)
    if error:
        return None, error
    added, still = [], []
    for row in report["rows"]:
        for missing in row["missing_properties"]:
            bone_name = missing.get("bone")
            holder = (armature.pose.bones.get(bone_name) if bone_name
                      else armature)
            if holder is None:
                continue
            key = missing["property"]
            if key in holder.keys():
                continue
            holder[key] = float(value)
            added.append({"bone": bone_name, "property": key, "value": value})
    # is_valid is cached on the curve and adding a property does not invalidate
    # that cache. Re-assigning the expression forces Blender to rebuild the
    # driver, which is what actually clears the flag -- without this the repair
    # looks like it failed and the influence stays at its last stored value.
    for curve in (armature.animation_data.drivers
                  if armature.animation_data else ()):
        if not curve.driver.is_valid:
            curve.driver.expression = curve.driver.expression
    armature.data.update_tag()
    bpy.context.view_layer.update()
    for curve in (armature.animation_data.drivers
                  if armature.animation_data else ()):
        if not curve.driver.is_valid:
            still.append(curve.data_path)
    return {"added": added, "added_count": len(added),
            "still_invalid": still}, ""


def normalise_deform(mesh_object, armature, indices=None, keep=()):
    """Make each vertex's MAIN-rig deform weights sum to one. ``(report, error)``.

    A weight transfer does not leave normalised weights. Measured: transferring
    the face's weights onto a 52-vertex brow card left 6 of those 52 vertices
    summing to one, and onto the headset left 1108 of 1407 -- and the card then
    moved 3.84mm where the skin under it moved 4.54mm, which is exactly the
    "deviates from the surrounding polygons" complaint the transfer was meant to
    cure.

    Only bones of the given armature that actually deform are counted, so the
    additive rig's inert blocker bones are neither counted nor touched. Groups
    named in ``keep`` are held at their current value and the rest are scaled
    into whatever room is left, which is how a vertex that must stay rigid on one
    bone survives a normalise pass.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    groups = {g.name: g for g in mesh_object.vertex_groups}
    by_index = {g.index: g.name for g in mesh_object.vertex_groups}
    held = set(keep or ())
    scope = sorted(set(indices)) if indices is not None else         [v.index for v in mesh_object.data.vertices]
    fixed = 0
    empty = []
    worst = 0.0
    for vertex_index in scope:
        locked = 0.0
        loose = 0.0
        rows = []
        for entry in mesh_object.data.vertices[vertex_index].groups:
            name = by_index.get(entry.group)
            if name not in deform:
                continue
            if name in held:
                locked += entry.weight
            else:
                loose += entry.weight
                rows.append((name, entry.weight))
        total = locked + loose
        if total <= 1.0e-9:
            empty.append(vertex_index)
            continue
        worst = max(worst, abs(1.0 - total))
        if abs(1.0 - total) <= 1.0e-6:
            continue
        headroom = max(0.0, 1.0 - locked)
        if loose <= 1.0e-9 or headroom <= 1.0e-9:
            continue
        factor = headroom / loose
        for name, weight in rows:
            groups[name].add([vertex_index], weight * factor, "REPLACE")
        fixed += 1
    mesh_object.data.update()
    return {"mesh": mesh_object.name, "vertices": len(scope),
            "renormalised": fixed, "worst_sum_error": round(worst, 5),
            "unweighted": empty[:20], "unweighted_count": len(empty)}, ""


def drop_wrong_side(mesh_object, armature, families=(), band_mm=6.0,
                    midline_mm=1.0):
    """Take a sided bone's weight off the other half of a part. ``(report, error)``.

    For an accessory that spans both sides as one mesh -- a brow card, a merged
    eyelash strip, a row of piercings. Weight is scaled by how far the vertex is
    onto the bone's own side, zero at the centre line, full by ``band_mm``, and
    the vertex is renormalised afterwards.

    An accessory inherits this the moment its weights are transferred from skin
    that has it. Measured on the reference character: six vertices of the brow
    card's RIGHT island carried c_eyebrow_01_end.l at 0.0767, so the right brow
    moved 1.53mm whenever the left brow was raised.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "Select the mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    deform = {b.name for b in armature.data.bones if b.use_deform}
    wanted = [g.name for g in mesh_object.vertex_groups
              if g.name in deform and g.name.endswith((".l", ".r"))
              and (not families
                   or any(g.name.startswith(f) for f in families))]
    if not wanted:
        return {"mesh": mesh_object.name, "groups": 0, "vertices": 0}, ""
    matrix = mesh_object.matrix_world
    span = max(band_mm, 1.0e-6)
    groups = {g.name: g for g in mesh_object.vertex_groups}
    touched = set()
    worst = 0.0
    for name in wanted:
        sign = 1.0 if name.endswith(".l") else -1.0
        group = groups[name]
        for vertex in mesh_object.data.vertices:
            index = vertex.index
            weight = None
            for entry in vertex.groups:
                if entry.group == group.index:
                    weight = entry.weight
                    break
            if weight is None or weight <= 0.0005:
                continue
            across = (matrix @ vertex.co).x * 1000.0 * sign
            if across >= span:
                continue
            factor = max(0.0, min(1.0, (across - (-midline_mm))
                                  / (span + midline_mm)))
            factor = factor * factor * (3.0 - 2.0 * factor)
            if factor >= 0.999:
                continue
            fresh = weight * factor
            worst = max(worst, weight - fresh)
            if fresh <= 0.0005:
                group.remove([index])
            else:
                group.add([index], fresh, "REPLACE")
            touched.add(index)
    report = {"mesh": mesh_object.name, "groups": len(wanted),
              "vertices": len(touched),
              "largest_removed": round(worst, 4)}
    if touched:
        fixed, error = normalise_deform(mesh_object, armature,
                                        indices=sorted(touched))
        report["renormalised"] = error or fixed.get("renormalised")
    mesh_object.data.update()
    return report, ""


def faint_modifier_weights(mesh_object, threshold=0.05):
    """Vertices whose weight for one Armature modifier's bones is a trace.

    An Armature modifier without Multi Modifier divides by the weight its own
    armature's groups hold on the vertex. A vertex with 0.01 on one bone of the
    additive rig and nothing else of that rig therefore follows that bone 100 %
    through that modifier. Measured on MIK (Claude fork 16, 2026-10-02): the right
    wrist accessory had 47 such vertices on rig_add bend bones and its edges
    stretched up to 84 % at a 90-degree elbow (700 % over the 79_22 clip) while
    its mirror twin, with none, stayed under 1.3 %.

    Only vertices that ALSO belong to another Armature modifier are reported:
    there the trace is noise next to the real binding. Returns
    ``{modifier name: {vertex index: [group index, ...]}}``.
    """
    mods = [m for m in mesh_object.modifiers
            if m.type == "ARMATURE" and m.object is not None and m.object.type == "ARMATURE"
            and not m.use_multi_modifier and m.use_vertex_groups]
    if len(mods) < 2:
        return {}
    groups_of = {}
    for m in mods:
        names = {b.name for b in m.object.data.bones if b.use_deform}
        groups_of[m.name] = {g.index for g in mesh_object.vertex_groups if g.name in names}
    out = {}
    for v in mesh_object.data.vertices:
        sums = {}
        for m in mods:
            own = groups_of[m.name]
            sums[m.name] = sum(g.weight for g in v.groups if g.group in own and g.weight > 0.0)
        for m in mods:
            s = sums[m.name]
            if 0.0 < s < threshold and any(sums[o.name] >= threshold for o in mods if o is not m):
                out.setdefault(m.name, {})[v.index] = [g.group for g in v.groups
                                                       if g.group in groups_of[m.name] and g.weight > 0.0]
    return out


def drop_faint_modifier_weights(mesh_object, threshold=0.05):
    """Remove the traces found by :func:`faint_modifier_weights`. ``(report, error)``."""
    found = faint_modifier_weights(mesh_object, threshold=threshold)
    removed = 0
    for rows in found.values():
        for index, groups in rows.items():
            for gi in groups:
                mesh_object.vertex_groups[gi].remove([index])
                removed += 1
    return {"vertices": sum(len(r) for r in found.values()), "weights_removed": removed,
            "by_modifier": {k: len(v) for k, v in found.items()}}, ""


_SIDE_PAIRS = ((".l", ".r"), (".L", ".R"), ("_l", "_r"), ("_L", "_R"))


_SIDE_INFIXES = (("_L_", "_R_"), ("_l_", "_r_"), (".L.", ".R."), (".l.", ".r."))


def mirror_group_name(name):
    for a, b in _SIDE_PAIRS:
        if name.endswith(a):
            return name[: -len(a)] + b
        if name.endswith(b):
            return name[: -len(b)] + a
    # a side tag inside the name, once: "hair_MIK_geo_hairA_tailA_L_23"
    for a, b in _SIDE_INFIXES:
        if name.count(a) == 1 and name.count(b) == 0:
            return name.replace(a, b)
        if name.count(b) == 1 and name.count(a) == 0:
            return name.replace(b, a)
    return None


def group_side(name):
    """'L', 'R' or None for a group name, by the same tags as :func:`mirror_group_name`."""
    for a, b in _SIDE_PAIRS:
        if name.endswith(a):
            return "L"
        if name.endswith(b):
            return "R"
    for a, b in _SIDE_INFIXES:
        if a in name and b not in name:
            return "L"
        if b in name and a not in name:
            return "R"
    return None


def symmetrize_midline(mesh_object, tolerance_mm=0.5, indices=None):
    """Give every vertex on the mirror plane the same weight on each left/right pair.

    A vertex at x = 0 that leans on the left leg pulls the middle of a skirt
    sideways when both legs move the same way. Measured on MIK (Claude fork 16,
    2026-10-02): 13 of the skirt's 15 centre vertices leaned left (worst
    .l 1.782 / .r 0.090) and its front centre slid 55 mm sideways with both legs
    raised; the bottoms leaned on 7 of 30 and slid 9 mm. Averaging each pair
    keeps every vertex's total weight. ``(report, error)``.
    """
    return symmetrize_mirror(mesh_object, tolerance_mm=tolerance_mm, midline_only=True, indices=indices)


def blend_across_midline(mesh_object, band_mm=80.0, families=("thigh", "leg", "c_thigh", "c_leg"), indices=None):
    """Share each left/right pair across x = 0 by position instead of by nearest surface.

    A skirt bound from the body takes each vertex's weights from the nearest skin.
    A front panel that hangs between the legs lands on one thigh, so its middle
    follows one leg: on MIK (2026-10-02) the skirt's front centre slid 83.5 mm
    sideways with both legs raised, and averaging mirror pairs could not fix it
    because the skirt itself is not symmetric (37 of 1845 vertices have a mirror
    partner within 1 mm). Here, inside ``band_mm`` of the mirror plane, every
    left/right pair whose name starts with one of ``families`` keeps its combined
    weight and splits it by a smoothstep of x: 50/50 on the plane, all on the near
    side at the band's edge. +x is the ARP left (.l) side. ``indices`` limits it to those
    vertices (one part of a mesh that also carries parts to leave alone). ``(report, error)``.
    """
    mw = mesh_object.matrix_world
    band = band_mm / 1000.0
    only = set(indices) if indices is not None else None
    groups = {g.index: g.name for g in mesh_object.vertex_groups}
    index_of = {n: i for i, n in groups.items()}
    pairs = set()
    for i, name in groups.items():
        if not name.startswith(tuple(families)):
            continue
        for a, b in _SIDE_PAIRS:
            if name.endswith(a):
                left, right = name, name[: -len(a)] + b
            elif name.endswith(b):
                left, right = name[: -len(b)] + a, name
            else:
                continue
            for n in (left, right):
                if n not in index_of:
                    index_of[n] = mesh_object.vertex_groups.new(name=n).index
            pairs.add((index_of[left], index_of[right]))
            break
    pairs = sorted(pairs)
    changed = 0
    for v in mesh_object.data.vertices:
        if only is not None and v.index not in only:
            continue
        x = (mw @ v.co).x
        if abs(x) >= band:
            continue
        t = (x + band) / (2.0 * band)
        left_share = t * t * (3.0 - 2.0 * t)
        weights = {g.group: g.weight for g in v.groups}
        for li, ri in pairs:
            s = weights.get(li, 0.0) + weights.get(ri, 0.0)
            if s <= 0.0:
                continue
            wl, wr = s * left_share, s * (1.0 - left_share)
            if abs(wl - weights.get(li, 0.0)) < 1e-6 and abs(wr - weights.get(ri, 0.0)) < 1e-6:
                continue
            for gi, w in ((li, wl), (ri, wr)):
                if w > 0.0:
                    mesh_object.vertex_groups[gi].add([v.index], w, "REPLACE")
                else:
                    mesh_object.vertex_groups[gi].remove([v.index])
            changed += 1
    return {"pairs_shared": changed, "band_mm": band_mm}, ""


def copy_mirror(mesh_object, source="R", tolerance_mm=0.3, armature=None, groups=None):
    """Copy the ``source`` side's weights onto the other side's mirror vertices. ``(report, error)``.

    A vertex's side is the side of its heaviest sided group (``groups``, a name
    filter, limits which groups decide it); its partner is the vertex at -x within
    ``tolerance_mm``. The partner gets every group of the source vertex, with side
    tags flipped, and loses the groups the source does not have. Where the two
    disagree on which bone a vertex belongs to -- the heaviest groups are not each
    other's mirror -- and ``armature`` is given, the side whose heaviest bone is the
    nearer bone segment is copied instead: that pair is a segment error, not a
    missing blend.
    """
    from mathutils import Vector
    from mathutils.geometry import intersect_point_line
    from mathutils.kdtree import KDTree

    if source not in ("L", "R"):
        return None, "source must be 'L' or 'R'"
    mw = mesh_object.matrix_world
    tol = tolerance_mm / 1000.0
    verts = mesh_object.data.vertices
    world = [mw @ v.co for v in verts]
    kd = KDTree(len(verts))
    for i, co in enumerate(world):
        kd.insert(co, i)
    kd.balance()
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    index_of = {n: i for i, n in names.items()}
    weights = [{names[g.group]: g.weight for g in v.groups if g.weight > 0.0} for v in verts]

    def deciding(w):
        rows = [(x, n) for n, x in w.items() if group_side(n) and (groups is None or groups(n))]
        return max(rows)[1] if rows else None

    def segment_distance(point, bone_name):
        bone = armature.data.bones.get(bone_name) if armature is not None else None
        if bone is None:
            return None
        am = armature.matrix_world
        h, t_ = am @ bone.head_local, am @ bone.tail_local
        q, pct = intersect_point_line(point, h, t_)
        q = h if pct < 0 else t_ if pct > 1 else q
        return (point - q).length

    copied, by_bone, unpaired, done = 0, 0, 0, set()
    disputed = []
    for i, w in enumerate(weights):
        top = deciding(w)
        if top is None or group_side(top) != source or i in done:
            continue
        _co, j, dist = kd.find(Vector((-world[i].x, world[i].y, world[i].z)))
        if j is None or dist > tol or j == i:
            unpaired += 1
            continue
        src, dst = i, j
        other_top = deciding(weights[j])
        if armature is not None and other_top is not None and mirror_group_name(top) != other_top:
            di = segment_distance(world[i], top)
            dj = segment_distance(world[j], other_top)
            if di is not None and dj is not None and dj < di:
                src, dst = j, i
                by_bone += 1
            disputed.append({"vertices": [i, j], "bones": [top, other_top],
                             "segment_mm": [round(di * 1000, 2) if di is not None else None,
                                            round(dj * 1000, 2) if dj is not None else None],
                             "copied_from": "source" if src == i else "other side"})
        done.update((i, j))
        new = {}
        for n, x in weights[src].items():
            m = mirror_group_name(n) or n
            new[m] = x
        for n in list(weights[dst]):
            if n not in new:
                mesh_object.vertex_groups[index_of[n]].remove([dst])
        for n, x in new.items():
            if n not in index_of:
                index_of[n] = mesh_object.vertex_groups.new(name=n).index
            mesh_object.vertex_groups[index_of[n]].add([dst], x, "REPLACE")
        copied += 1
    return {"copied": copied, "copied_from_nearer_bone_side": by_bone, "unpaired": unpaired,
            "disputed": disputed, "source": source}, ""


def symmetrize_mirror(mesh_object, tolerance_mm=1.0, midline_only=False, indices=None):
    """Make the weights of every mirrored vertex pair mirror images of each other.

    Only vertices whose reflection across x = 0 lands on another vertex of the
    same mesh (within ``tolerance_mm``) are touched, so a one-sided buckle or a
    wrap that overlaps on one side keeps its own weights. A vertex on the mirror
    plane is its own partner. For a pair (v, m) every left/right group pair is set
    to the mean of v's weight on it and m's weight on its mirror, and a centre
    group to the mean of both, which keeps each vertex's total. Measured on MIK
    (2026-10-02): averaging the skirt's 15 centre vertices alone cut the sideways
    slide of its front with both legs raised from 83.5 to 23.6 mm -- the
    neighbours still leaned. ``indices`` limits it to pairs inside those vertices.
    ``(report, error)``.
    """
    only = set(indices) if indices is not None else None
    from mathutils import Vector
    from mathutils.kdtree import KDTree

    mw = mesh_object.matrix_world
    tol = tolerance_mm / 1000.0
    verts = mesh_object.data.vertices
    world = [mw @ v.co for v in verts]
    kd = KDTree(len(verts))
    for i, co in enumerate(world):
        kd.insert(co, i)
    kd.balance()
    index_of = {g.name: g.index for g in mesh_object.vertex_groups}
    mirror_of = {}
    for g in list(mesh_object.vertex_groups):
        other = mirror_group_name(g.name)
        if other is None:
            mirror_of[g.index] = g.index
            continue
        if other not in index_of:
            index_of[other] = mesh_object.vertex_groups.new(name=other).index
        mirror_of[g.index] = index_of[other]
        mirror_of[index_of[other]] = g.index
    partner = {}
    for i, co in enumerate(world):
        if midline_only and abs(co.x) > tol:
            continue
        if only is not None and i not in only:
            continue
        _co, j, dist = kd.find(Vector((-co.x, co.y, co.z)))
        if j is not None and dist <= tol and (only is None or j in only):
            partner[i] = j
    weights = [{g.group: g.weight for g in v.groups} for v in verts]
    new = {}
    for i, j in partner.items():
        if (j, i) in new or (i, j) in new:
            continue
        wi, wj = weights[i], weights[j]
        out_i, out_j = {}, {}
        for gi in set(wi) | {mirror_of.get(g, g) for g in wj}:
            gm = mirror_of.get(gi, gi)
            avg = (wi.get(gi, 0.0) + wj.get(gm, 0.0)) / 2.0
            out_i[gi] = avg
            out_j[gm] = avg
        new[(i, j)] = (out_i, out_j)
    changed, worst = 0, 0.0
    for (i, j), (out_i, out_j) in new.items():
        for vi, out in ((i, out_i), (j, out_j)):
            for gi, w in out.items():
                old = weights[vi].get(gi, 0.0)
                if abs(old - w) < 1e-6:
                    continue
                worst = max(worst, abs(old - w))
                if w > 0.0:
                    mesh_object.vertex_groups[gi].add([vi], w, "REPLACE")
                else:
                    mesh_object.vertex_groups[gi].remove([vi])
                changed += 1
    return {"pairs_averaged": changed, "worst_difference": worst,
            "mirrored_vertices": len(partner), "vertices": len(verts)}, ""


# The deforming body of an Auto-Rig Pro character: what "away from the body" is measured from.
# Names that a rig does not have are skipped.
BODY_AXES = ("root.x", "spine_01.x", "spine_02.x", "spine_03.x", "subneck_twist_1.x", "neck.x", "head.x",
             "shoulder.l", "shoulder.r",
             "arm_stretch.l", "arm_stretch.r", "arm_twist_2.l", "arm_twist_2.r", "arm_twist_3.l", "arm_twist_3.r",
             "arm_twist_4.l", "arm_twist_4.r",
             "forearm_stretch.l", "forearm_stretch.r", "forearm_twist.l", "forearm_twist.r",
             "forearm_twist_2.l", "forearm_twist_2.r", "forearm_twist_3.l", "forearm_twist_3.r",
             "forearm_twist_4.l", "forearm_twist_4.r", "hand.l", "hand.r",
             "thigh_stretch.l", "thigh_stretch.r", "thigh_twist.l", "thigh_twist.r", "thigh_twist_2.l", "thigh_twist_2.r",
             "thigh_twist_3.l", "thigh_twist_3.r", "thigh_twist_4.l", "thigh_twist_4.r",
             "leg_stretch.l", "leg_stretch.r", "leg_twist.l", "leg_twist.r", "leg_twist_2.l", "leg_twist_2.r",
             "leg_twist_3.l", "leg_twist_3.r", "leg_twist_4.l", "leg_twist_4.r",
             "foot.l", "foot.r", "toes_01.l", "toes_01.r")
# A bone named with one of these belongs to an arm. At rest the arms hang beside the hips, so a
# strap on the belt would otherwise measure "outward" from a forearm.
ARM_TOKENS = ("arm", "hand", "shoulder")


def is_arm_bone(name):
    return any(t in name for t in ARM_TOKENS)


def umbrella_rolls(armature, bones, centre="ring", body=BODY_AXES, rotate_deg=15.0, midline=True,
                   along_chains=False, arms="AUTO", restart_deg=45.0):
    """Roll every bone so that one positive rotation about local X opens all their tips outward. ``(report, error)``.

    The convention (user instruction, 2026-10-04): Y along the bone, Z outward -- away
    from the group's centre the way a surface normal points away from a surface -- and X
    along the ring. A rotation of +theta about X carries Y towards Z, so selecting a
    whole skirt and turning it about X opens it like an umbrella, and a tail turned the
    same way lifts off the back.

    ``centre`` "ring": the vertical line through the mean of the bones' heads (a skirt,
    a coat's strips) -- with ``midline``, moved sideways onto the rig's own centre plane
    (armature X = 0), so a left bone and its right partner open as mirror images even
    when the ring has a gap and its mean sits off-centre (MIK's skirt: 27.7 mm). "body": the axis of the nearest of the armature's bones named in
    ``body`` (tails, straps, zips, the tips of arm bands). A bone whose outward direction
    runs along its own length keeps its roll. The rest shape does not change -- a roll
    is part of the rest matrix, and a pose with no rotation deforms nothing -- and the
    motion does not either: a chain's swing bones roll with their links, and the pose
    and every key on the rolled bones (in the rig's own Action slot) are re-expressed in
    the new axes. Constraints and drivers that read these bones in LOCAL space cannot be
    converted; they are listed in ``local_space_users``.

    ``along_chains``: a bone whose parent is also in the group carries the parent's outward
    (its Z, kept perpendicular to its own length) instead of measuring its own, so a hanging
    chain opens one way all the way down. Per bone, "nearest body bone" jumps where the
    nearest bone changes (MIK's tail A: 57.9 deg between two links). The chain starts again
    from the centre rule where it bends more than ``restart_deg`` or where the carried outward
    would face the body (MIK's tail B past the hair tie, a 69 deg bend: +X moved it inward).

    ``arms`` (centre "body"): which body bones count for a bone. "AUTO": arm bones only for a
    bone that hangs from an arm -- an arm bone among its ancestors, or an Armature constraint
    (on it or an ancestor) mostly on arm bones, or a Child Of / Copy Transforms on one: an arm
    band's tips, a strap sewn to a sleeve; for every other bone the torso, head and legs.
    "INCLUDE": always. "EXCLUDE": never.

    The report checks the result: with every bone turned ``rotate_deg`` about +X, how
    many tips moved outward.
    """
    from mathutils import Vector, Matrix

    from . import jiggle

    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    names = [n for n in bones or () if armature.data.bones.get(n) is not None]
    if not names:
        return None, "None of those bones is on this armature"
    # keys are converted below, so the rig's own slot has to be known before anything changes
    bag, error = jiggle.rig_channelbag(armature)
    if error:
        return None, error
    swing_of = {n: jiggle.SWING_PREFIX + n for n in names
                if armature.data.bones.get(jiggle.SWING_PREFIX + n) is not None}
    touched = names + list(swing_of.values())
    old_rest = {n: armature.data.bones[n].matrix_local.to_3x3() for n in touched}

    def acts(con):
        return (not con.mute and con.influence > 0.0 and getattr(con, "is_valid", True)
                and getattr(con, "enabled", True))

    def real_bone(target, subtarget):
        return target == armature and bool(subtarget) and armature.data.bones.get(subtarget) is not None

    def attached_to_arm(name):
        pose_bone = armature.pose.bones.get(name)
        for con in (pose_bone.constraints if pose_bone is not None else ()):
            if not acts(con):
                continue
            if con.type == "ARMATURE":
                live = [t for t in con.targets if t.weight > 0.0 and real_bone(t.target, t.subtarget)]
                total = sum(t.weight for t in live)
                arm = sum(t.weight for t in live if is_arm_bone(t.subtarget))
                if total > 0.0 and arm / total > 0.5:
                    return True
            elif con.type in ("CHILD_OF", "COPY_TRANSFORMS"):
                if real_bone(con.target, con.subtarget) and is_arm_bone(con.subtarget):
                    return True
        return False

    def on_arm(name):
        # a parent, or the surface a root is attached to: an arm band's tips, a strap sewn to a sleeve
        b = armature.data.bones.get(name)
        while b is not None:
            if b.name != name and is_arm_bone(b.name):
                return True
            if attached_to_arm(b.name):
                return True
            b = b.parent
        return False

    hangs = {n: on_arm(n) for n in names}
    if centre == "body":
        present = [b for b in body or () if armature.data.bones.get(b) is not None]
        if not present:
            return None, "None of the body bones is on this armature. Nothing was changed."
        if not [b for b in present if not is_arm_bone(b)]:
            needs = [n for n in names if arms == "EXCLUDE" or (arms == "AUTO" and not hangs[n])]
            if needs:
                return None, ("No body bone is left once the arm bones are left out (%s). Nothing was changed."
                              % needs[0])
    up = (armature.matrix_world.inverted().to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
    previous = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = armature
    mode = armature.mode
    import math
    rolled, kept, changes = [], [], []
    outward = {}
    restarts = 0
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        heads = [edit[n].head.copy() for n in names]
        middle = sum(heads, Vector()) / len(heads)
        if midline:
            middle.x = 0.0
        used_body = [b for b in body or () if edit.get(b) is not None]
        segments = [(edit[b].head.copy(), edit[b].tail.copy(), is_arm_bone(b)) for b in used_body]


        def depth(n):
            d, p = 0, edit[n].parent
            while p is not None:
                d, p = d + 1, p.parent
            return d

        ordered = sorted(names, key=depth) if along_chains else names
        for n in ordered:
            eb = edit[n]
            y = eb.tail - eb.head
            if y.length <= 1.0e-9:
                kept.append(n)
                continue
            y.normalize()
            carried = None
            if along_chains and eb.parent is not None and eb.parent.name in outward:
                carried = eb.parent.z_axis.copy()
                carried = carried - y * carried.dot(y)
                if carried.length <= 1.0e-6:
                    carried = None
            if centre == "body" and segments:
                best = None
                allow_arms = arms == "INCLUDE" or (arms == "AUTO" and hangs[n])
                usable = [(a, b) for a, b, arm in segments if allow_arms or not arm]
                for a, b in usable:
                    ab = b - a
                    t = 0.0 if ab.length_squared <= 1.0e-12 else max(0.0, min(1.0, (eb.head - a).dot(ab) / ab.length_squared))
                    q = a + ab * t
                    d = (eb.head - q).length
                    if best is None or d < best[0]:
                        best = (d, q)
                out = eb.head - best[1]
            else:
                out = eb.head - middle
                out = out - up * out.dot(up)
            out = out - y * out.dot(y)
            if carried is not None:
                bend = math.degrees(eb.parent.y_axis.angle(y)) if eb.parent.y_axis.length > 1.0e-9 else 0.0
                if bend <= restart_deg and (out.length <= 1.0e-6 or carried.dot(out) >= 0.0):
                    out = carried
                else:
                    restarts += 1
            if out.length <= 1.0e-6:
                kept.append(n)
                continue
            out.normalize()
            before = eb.roll
            eb.align_roll(out)
            changes.append(abs(((eb.roll - before + 3.14159265) % 6.2831853) - 3.14159265))
            rolled.append(n)
            outward[n] = out.copy()
            # the swing bone adds its LOCAL rotation onto the link's: it has to share the link's axes
            swing = edit.get(swing_of.get(n, ""))
            if swing is not None:
                swing.align_roll(out)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        if mode == "POSE":
            bpy.ops.object.mode_set(mode="POSE")
        bpy.context.view_layer.objects.active = previous
    # nothing moves: the pose and every key on a rolled bone are re-expressed in its new axes.
    # A bone's contribution to the pose is R B R^-1 (R its rest), so B' = D^-1 B D with D = R_old^-1 R_new.
    turned = [n for n in rolled] + [swing_of[n] for n in rolled if n in swing_of]
    deltas = {}
    for n in turned:
        d = old_rest[n].inverted() @ armature.data.bones[n].matrix_local.to_3x3()
        if max(abs(d[i][j] - (1.0 if i == j else 0.0)) for i in range(3) for j in range(3)) > 1.0e-7:
            deltas[n] = d
    keys = _convert_keys(armature, bag, deltas)
    for n, d in deltas.items():
        pose_bone = armature.pose.bones[n]
        d4 = d.to_4x4()
        pose_bone.matrix_basis = d4.inverted() @ pose_bone.matrix_basis @ d4
    local_users = _local_space_users(armature, set(deltas))
    # self-check: turn every rolled bone +X and see each tip move outward (rest frame, no parent motion)
    opened = 0
    import math
    turn = Matrix.Rotation(math.radians(rotate_deg), 4, "X")
    for n in rolled:
        bone = armature.data.bones[n]
        rest = bone.matrix_local
        tail_after = rest @ turn @ Vector((0.0, bone.length, 0.0))
        if (tail_after - bone.tail_local).dot(outward[n]) > 0.0:
            opened += 1
    return {"rolled": len(rolled), "kept": kept, "opened_by_plus_x": opened,
            "max_roll_change_deg": round(max(changes) * 57.29578, 1) if changes else 0.0, "centre": centre,
            "swing_rolled": sum(1 for n in rolled if n in swing_of), "keys": keys,
            "body_used": len(used_body) if centre == "body" else 0, "arms": arms, "restarts": restarts,
            "local_space_users": local_users}, ""


_TRANSFORM = ("location", "rotation_quaternion", "rotation_euler", "rotation_axis_angle", "scale")


def _convert_keys(armature, bag, deltas):
    """Re-express every transform key on the re-rolled bones so the pose they give stays put.

    The new values are exact where a key is; between two keys a re-rolled Euler or a
    clamped handle does not interpolate the way the old one did (measured: up to 0.4
    in a deform matrix between keys three frames apart). So a gap between keys is
    filled with a key on every whole frame, and the motion stays exactly as it was
    on every frame -- ``added`` counts those keys (a bake already keys every frame
    and gets none). Non-uniform scale across the bone's X and Z cannot be carried
    by a roll; those bones are counted in ``scale_unjudged`` and left as they are.
    """
    out = {"bones": 0, "curves": 0, "keys": 0, "added": 0, "scale_unjudged": []}
    if bag is None or not deltas:
        return out
    import math
    from mathutils import Matrix, Quaternion, Euler, Vector
    by_path = {}
    for curve in bag.fcurves:
        by_path.setdefault(curve.data_path, {})[curve.array_index] = curve
    for n, d in deltas.items():
        pose_bone = armature.pose.bones[n]
        curves = {prop: by_path.get('pose.bones["%s"].%s' % (n, prop), {}) for prop in _TRANSFORM}
        if not any(curves.values()):
            continue
        keyed = {round(p.co[0], 4) for group in curves.values() for c in group.values()
                 for p in c.keyframe_points}
        frames = sorted(keyed | set(range(int(math.ceil(min(keyed))), int(math.floor(max(keyed))) + 1)))
        out["added"] += sum(1 for f in frames if f not in keyed)
        rest_values = {prop: list(getattr(pose_bone, prop)) for prop in _TRANSFORM}
        d_inv = d.inverted()
        dq = d.to_quaternion()
        dq_inv = dq.inverted()
        mode = pose_bone.rotation_mode
        compat = None
        written = []
        for f in frames:
            val = {prop: [curves[prop][i].evaluate(f) if i in curves[prop] else rest_values[prop][i]
                          for i in range(len(rest_values[prop]))] for prop in _TRANSFORM}
            new = {}
            if curves["location"]:
                new["location"] = list(d_inv @ Vector(val["location"]))
            if curves["rotation_quaternion"]:
                new["rotation_quaternion"] = list(dq_inv @ Quaternion(val["rotation_quaternion"]) @ dq)
            if curves["rotation_euler"]:
                rot_mode = mode if mode in ("XYZ", "XZY", "YXZ", "YZX", "ZXY", "ZYX") else "XYZ"
                m = d_inv @ Euler(val["rotation_euler"], rot_mode).to_matrix() @ d
                e = m.to_euler(rot_mode, compat) if compat is not None else m.to_euler(rot_mode)
                compat = e
                new["rotation_euler"] = list(e)
            if curves["rotation_axis_angle"]:
                a = val["rotation_axis_angle"]
                q = Quaternion(Vector(a[1:4]), a[0]) if Vector(a[1:4]).length > 1.0e-12 else Quaternion()
                axis, angle = (dq_inv @ q @ dq).to_axis_angle()
                new["rotation_axis_angle"] = [angle, axis[0], axis[1], axis[2]]
            if curves["scale"]:
                s = val["scale"]
                if abs(s[0] - s[2]) > 1.0e-6 and n not in out["scale_unjudged"]:
                    out["scale_unjudged"].append(n)
            written.append((f, new))
        for f, new in written:
            for prop, values in new.items():
                for i, v in enumerate(values):
                    curve = curves[prop].get(i)
                    if curve is None:
                        curve = bag.fcurves.new('pose.bones["%s"].%s' % (n, prop), index=i)
                        curves[prop][i] = curve
                    point = next((p for p in curve.keyframe_points if abs(p.co[0] - f) < 1.0e-3), None)
                    if point is None:
                        curve.keyframe_points.insert(f, v)
                    else:
                        dy = v - point.co[1]
                        point.co[1] = v
                        point.handle_left[1] += dy
                        point.handle_right[1] += dy
                    out["keys"] += 1
        for group in curves.values():
            for curve in group.values():
                curve.update()
                out["curves"] += 1
        out["bones"] += 1
    return out


def _local_space_users(armature, names):
    """Constraints and drivers that read or write these bones in their LOCAL axes -- a roll changes them."""
    from . import jiggle

    users = []
    for pose_bone in armature.pose.bones:
        for con in pose_bone.constraints:
            if con.name == jiggle.SWING_CONSTRAINT:
                continue
            if pose_bone.name in names and getattr(con, "owner_space", "WORLD") in ("LOCAL", "LOCAL_WITH_PARENT"):
                users.append("%s: %s (owner local)" % (pose_bone.name, con.name))
            if getattr(con, "subtarget", "") in names and getattr(con, "target_space", "WORLD") in (
                    "LOCAL", "LOCAL_WITH_PARENT", "LOCAL_OWNER_ORIENT"):
                users.append("%s: %s (reads %s local)" % (pose_bone.name, con.name, con.subtarget))
    ad = armature.animation_data
    for curve in (ad.drivers if ad is not None else ()):
        if any(curve.data_path == 'pose.bones["%s"].%s' % (n, prop) for n in names for prop in _TRANSFORM):
            users.append("driven: %s[%d]" % (curve.data_path, curve.array_index))
            continue
        for var in curve.driver.variables:
            for target in var.targets:
                if getattr(target, "bone_target", "") in names and var.type in ("TRANSFORMS",) and \
                        target.transform_space in ("LOCAL_SPACE", "TRANSFORM_SPACE"):
                    users.append("driver %s reads %s local" % (curve.data_path, target.bone_target))
    return users


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
