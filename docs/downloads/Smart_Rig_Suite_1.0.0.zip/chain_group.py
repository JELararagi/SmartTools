# SPDX-License-Identifier: GPL-3.0-or-later
"""Pose multiple deform chains using common swing and curl controls."""

from collections import defaultdict
from contextlib import contextmanager
import re

import bpy
from mathutils import Vector

from . import costume_bind


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()
CON_PREFIX = "SRS group "
COLLECTION = "SRS Controls"
_KINDS = ("swing", "curl")
_LINK = re.compile(r"^(.*)_(\d+)$")


def _ordered_links(armature):
    by_chain = defaultdict(list)
    for bone in armature.data.bones:
        if match := _LINK.fullmatch(bone.name):
            by_chain[match[1]].append((int(match[2]), bone.name))
    return {prefix: [name for _, name in sorted(by_chain[prefix])] for prefix in by_chain}


def chain_links(armature, prefix):
    return _ordered_links(armature).get(prefix, [])


def chain_prefixes_from_bones(names):
    return list(dict.fromkeys(match[1] for name in names if (match := _LINK.fullmatch(name))))


def _control_names(key):
    return tuple(f"srs_ctl_{key}_{kind}" for kind in _KINDS)


def _ensure_mode(armature, mode):
    context = bpy.context
    if context.view_layer.objects.active is not armature:
        if context.object and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        context.view_layer.objects.active = armature
    if armature.mode != mode:
        bpy.ops.object.mode_set(mode=mode)


@contextmanager
def _editable_bones(armature):
    visibility = costume_bind.visible_for_edit([armature])
    try:
        _ensure_mode(armature, "EDIT")
        yield armature.data.edit_bones
    finally:
        try:
            if armature.mode == "EDIT":
                bpy.ops.object.mode_set(mode="OBJECT")
        finally:
            costume_bind.restore_visibility(visibility)


def _bind_rotation(bone, armature, control, label, amount):
    constraint = bone.constraints.new("COPY_ROTATION")
    constraint.name = label
    constraint.target = armature
    constraint.subtarget = control
    constraint.owner_space = constraint.target_space = "LOCAL"
    constraint.mix_mode = "ADD"
    constraint.influence = amount


def build(armature, prefixes, key="braids", size=0.06):
    indexed = _ordered_links(armature)
    chains = {prefix: indexed[prefix] for prefix in prefixes if prefix in indexed}
    if not chains:
        return None, "No chain found for the given names."
    remove(armature, key)
    bones = armature.data.bones
    root_bones = [bones[links[0]] for links in chains.values()]
    parent = root_bones[0].parent
    parent_name = parent.name if parent else ""
    center = sum((root.head_local for root in root_bones), Vector((0, 0, 0))) / len(root_bones)
    swing, curl = _control_names(key)

    with _editable_bones(armature) as editable:
        for control, offset in ((swing, 0.6), (curl, 1.5)):
            bone = editable.new(control)
            bone.head = center + Vector((0, 0, size * offset))
            bone.tail = bone.head + Vector((0, 0, size * 0.75))
            bone.use_deform = False
            if parent_name:
                bone.parent = editable.get(parent_name)

    collection = armature.data.collections_all.get(COLLECTION)
    if collection is None:
        collection = armature.data.collections.new(COLLECTION)
    for name in (swing, curl):
        collection.assign(bones[name])
        pose = armature.pose.bones[name]
        pose.rotation_mode = "XYZ"
        pose.lock_location = pose.lock_scale = (True,) * 3

    label = f"{CON_PREFIX}{key} "
    for links in chains.values():
        _bind_rotation(armature.pose.bones[links[0]], armature, swing, label + "swing", 1.0)
        lengths = [bones[name].length for name in links]
        total = sum(lengths) or 1.0
        for name, length in zip(links, lengths):
            _bind_rotation(armature.pose.bones[name], armature, curl, label + "curl", length / total)
    return {
        "key": key, "chains": {name: len(links) for name, links in chains.items()},
        "controls": [swing, curl], "constraints": sum(len(links) + 1 for links in chains.values()),
        "parent": parent_name,
    }, ""


def remove(armature, key):
    names = _control_names(key)
    label = f"{CON_PREFIX}{key} "
    removed = 0
    for pose in armature.pose.bones:
        for constraint in tuple(pose.constraints):
            if constraint.name.startswith(label):
                pose.constraints.remove(constraint)
                removed += 1
    if any(name in armature.data.bones for name in names):
        with _editable_bones(armature) as editable:
            for name in names:
                if (bone := editable.get(name)) is not None:
                    editable.remove(bone)
                    removed += 1
    return removed
