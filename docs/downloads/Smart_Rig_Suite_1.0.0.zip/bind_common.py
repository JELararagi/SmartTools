# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Make a bind safe, correct, and checkable -- the parts every binder shares.

Three things live here because every binding path needs all three and none of
them belongs to one caller.

**The modifier pair.** Auto-Rig Pro's ADDITIVE secondary mode gives a mesh TWO
armature modifiers: the additive rig first, then the main rig. The bend bones
that carry a joint's shape work deform through the additive one. A mesh given
only the main rig is not slightly wrong, it is deaf: measured on the reference
character, a mesh with a ``c_knee_bend`` group at weight 1.0 and only the main
modifier does not move one micron when that bone is driven, while the same mesh
with the pair moves as the body does. Both look identical at rest, so no
screenshot and no weight report distinguishes them -- only a posed measurement
does. That is why creating the pair is a function and not a line of caller code.

**The bone set a mesh is really bound to.** Resolving vertex groups against the
main armature alone mislabels the additive rig's own bones as groups no bone
matches. Six deform bones exist only on the additive rig here, and they carry
real weight -- ``hand_bend.l`` averages 0.841 over 1317 vertices. An audit that
reports those as defects gets switched off, so the union is computed once, here.

**The pre-flight gate.** The ADDITIVE flag is the linchpin of the whole scheme
and it is Auto-Rig Pro registered RNA, so it reads as absent unless ARP is
loaded -- silence is not a passing answer. Worse, ARP's Match to Rig branches on
that same flag and its other branch deletes the additive rig outright, which
would orphan the second modifier on every mesh already bound. The gate refuses
rather than guesses.
"""

import bpy

PAIR_ADDITIVE = "rig_add"
PAIR_MAIN = "rig"

# A bind is only as trustworthy as the state it started from, and these are the
# bones whose presence says "this armature really is an Auto-Rig Pro rig". The
# poll on ARP's own bind accepts any armature, and the secondary-type property is
# registered on every Object with a default, so a plain armature sails past both
# and fails much later and much deeper.
ARP_SIGNATURE_BONES = ("c_traj", "head_ref.x")


def rig_add_for(rig):
    """Auto-Rig Pro's additive armature for ``rig``, or None."""
    if rig is None:
        return None
    found = bpy.data.objects.get(rig.name + "_add")
    if found is not None and found.type == "ARMATURE":
        return found
    return None


def deform_bone_names(mesh):
    """Every deform bone the mesh is actually bound to, across ALL armatures.

    The union is the point. See the module docstring.
    """
    names = set()
    if mesh is None:
        return names
    for mod in mesh.modifiers:
        if mod.type != "ARMATURE":
            continue
        obj = mod.object
        if obj is None or obj.type != "ARMATURE":
            continue
        names.update(b.name for b in obj.data.bones if b.use_deform)
    return names


def is_arp_rig(rig):
    """Whether this armature carries Auto-Rig Pro's own signature bones."""
    if rig is None or rig.type != "ARMATURE":
        return False
    return any(n in rig.data.bones for n in ARP_SIGNATURE_BONES)


def secondary_type(rig):
    """``(value, readable)``. Unreadable is NOT the same as wrong.

    The property is ARP-registered RNA on Object. Without ARP loaded the
    attribute is missing entirely, and a gate that treated that as a pass would
    be guessing about the one fact the whole binding scheme rests on.
    """
    if rig is None:
        return "", False
    value = getattr(rig, "arp_secondary_type", None)
    if value is None:
        return "", False
    return str(value), True


def is_facial_enabled(rig):
    """Whether ARP's facial rig is on, by ARP's own two-branch test."""
    if rig is None or rig.type != "ARMATURE":
        return False
    head = rig.data.bones.get("head_ref.x")
    if head is not None:
        flag = head.get("facial")
        if flag is not None:
            return bool(flag)
    return rig.data.bones.get("jaw_ref.x") is not None


def ensure_modifier_pair(mesh, rig, preserve=True, name_hint=""):
    """Give ``mesh`` Auto-Rig Pro's exact two-modifier state. Returns a report.

    Order is additive first, main second, with any Mirror above both -- the order
    ARP itself produces. The main modifier carries the cage and edit-mode display
    and the volume preservation; the additive one carries none of them.
    """
    report = {"mesh": getattr(mesh, "name", ""), "created": [], "reordered": False,
              "additive": False, "error": ""}
    if mesh is None or mesh.type != "MESH":
        report["error"] = "Not a mesh"
        return report
    if rig is None or rig.type != "ARMATURE":
        report["error"] = "No armature to bind to"
        return report
    add = rig_add_for(rig)

    def modifier_for(armature, wanted):
        for mod in mesh.modifiers:
            if mod.type == "ARMATURE" and mod.object == armature:
                if mod.name != wanted:
                    mod.name = wanted
                return mod
        mod = mesh.modifiers.new(name=wanted, type="ARMATURE")
        mod.object = armature
        report["created"].append(wanted)
        return mod

    main = modifier_for(rig, name_hint or PAIR_MAIN)
    main.show_in_editmode = True
    main.show_on_cage = True
    main.use_deform_preserve_volume = bool(preserve)
    main.use_multi_modifier = False

    if add is not None:
        report["additive"] = True
        extra = modifier_for(add, PAIR_ADDITIVE)
        extra.show_in_editmode = False
        extra.show_on_cage = False
        extra.use_deform_preserve_volume = False
        extra.use_multi_modifier = False

    # Deformation is stack order, so the pair has to sit at the top. Mirror goes
    # above them both, the way ARP leaves it.
    def move_to_front(mod):
        index = list(mesh.modifiers).index(mod)
        if index != 0:
            mesh.modifiers.move(index, 0)
            report["reordered"] = True

    move_to_front(main)
    if add is not None:
        move_to_front(mesh.modifiers[PAIR_ADDITIVE])
    for mod in list(mesh.modifiers):
        if mod.type == "MIRROR":
            move_to_front(mod)
            break
    report["stack"] = [m.name for m in mesh.modifiers]
    return report


def parent_to_rig(mesh, rig):
    """Parent without moving the mesh. Auto-Rig Pro parents bound meshes too."""
    if mesh is None or rig is None:
        return False
    mesh.parent = rig
    mesh.parent_type = "OBJECT"
    mesh.parent_bone = ""
    mesh.matrix_parent_inverse = rig.matrix_world.inverted()
    return True


def assign_whole(mesh, bone, clear_existing=True):
    """One group, that bone, weight 1.0 on every vertex. Returns the count.

    ``clear_existing`` removes the mesh's other groups, which is what makes this
    usable on a mesh carrying leftovers from a throwaway rig. It is destructive on
    purpose and never the default for a mesh that already has real weights --
    callers decide.
    """
    if mesh is None or mesh.type != "MESH" or not mesh.data.vertices:
        return 0
    if clear_existing:
        for group in list(mesh.vertex_groups):
            if not group.lock_weight:
                mesh.vertex_groups.remove(group)
    group = mesh.vertex_groups.get(bone) or mesh.vertex_groups.new(name=bone)
    indices = [v.index for v in mesh.data.vertices]
    group.add(indices, 1.0, "REPLACE")
    return len(indices)


def weighted_vertex_count(mesh, bone):
    """Vertices carrying NON-ZERO weight in ``bone``'s group.

    Never count groups instead. Blender's automatic-weight parenting creates a
    group for every deform bone whether or not any vertex lands in it, so "the
    group exists" is not evidence that anything is bound -- measured, a bone
    placed far from the mesh still produced a group of total weight zero.
    """
    if mesh is None or mesh.type != "MESH":
        return 0
    group = mesh.vertex_groups.get(bone)
    if group is None:
        return 0
    index = group.index
    total = 0
    for vert in mesh.data.vertices:
        for entry in vert.groups:
            if entry.group == index and entry.weight > 0.0:
                total += 1
                break
    return total


def _evaluated_centroid(mesh, depsgraph, indices=None):
    evaluated = mesh.evaluated_get(depsgraph)
    data = evaluated.data
    if not data.vertices:
        return None
    total = mesh.matrix_world.copy()
    if indices is None:
        chosen = range(len(data.vertices))
    else:
        # Only meaningful while the generating modifiers are off -- see
        # displacement_under_pose.
        limit = len(data.vertices)
        chosen = [i for i in indices if 0 <= i < limit]
        if not chosen:
            return None
    acc = [0.0, 0.0, 0.0]
    for index in chosen:
        world = total @ data.vertices[index].co
        acc[0] += world.x
        acc[1] += world.y
        acc[2] += world.z
    count = len(chosen) if indices is not None else len(data.vertices)
    return [c / count for c in acc]


def displacement_under_pose(mesh, rig, bone, offset=(0.0, 0.0, 0.0),
                            rotation=None, indices=None, armature_only=False):
    """How far the mesh actually moves when ``bone`` is posed, in millimetres.

    This is the only check that separates a bound mesh from a deaf one. A mesh
    with the right groups and the wrong modifier stack reads zero here and looks
    perfect everywhere else.

    ``indices`` measures one region instead of the whole mesh, which is what a
    part with two jobs needs -- an eyeball whose pupil must follow the gaze while
    its rim must not. Region measurement requires ``armature_only``, because a
    Subdivision or Mirror modifier changes the evaluated vertex count and the
    indices would no longer mean anything; those modifiers are switched off for
    the measurement and put back afterwards.
    """
    if mesh is None or rig is None:
        return None, "Need both a mesh and an armature"
    pose_bone = rig.pose.bones.get(bone)
    if pose_bone is None:
        return None, "The armature has no bone called %r" % bone
    if indices is not None and not armature_only:
        return None, ("Measuring one region needs armature_only, or the "
                      "generating modifiers renumber the vertices")

    hidden = []
    if armature_only:
        for mod in mesh.modifiers:
            if mod.type != "ARMATURE" and mod.show_viewport:
                mod.show_viewport = False
                hidden.append(mod)
        if hidden:
            bpy.context.view_layer.update()

    depsgraph = bpy.context.evaluated_depsgraph_get()
    before = _evaluated_centroid(mesh, depsgraph, indices)
    if before is None:
        for mod in hidden:
            mod.show_viewport = True
        return None, "The mesh evaluates to no geometry"

    saved_location = tuple(pose_bone.location)
    saved_quat = tuple(pose_bone.rotation_quaternion)
    saved_euler = tuple(pose_bone.rotation_euler)
    try:
        pose_bone.location = (offset[0] * 0.001, offset[1] * 0.001,
                              offset[2] * 0.001)
        if rotation is not None:
            pose_bone.rotation_mode = "XYZ"
            pose_bone.rotation_euler = rotation
        bpy.context.view_layer.update()
        depsgraph = bpy.context.evaluated_depsgraph_get()
        after = _evaluated_centroid(mesh, depsgraph, indices)
    finally:
        pose_bone.location = saved_location
        pose_bone.rotation_quaternion = saved_quat
        pose_bone.rotation_euler = saved_euler
        for mod in hidden:
            mod.show_viewport = True
        bpy.context.view_layer.update()
    if after is None:
        return None, "The mesh evaluated to no geometry while posed"
    moved = sum((a - b) ** 2 for a, b in zip(after, before)) ** 0.5
    return round(moved * 1000.0, 4), ""


def per_vertex_displacement(mesh, rig, bone, offset=(0.0, 0.0, 0.0),
                            rotation=None, indices=None, armature_only=True):
    """How far each vertex moves under a pose, in millimetres. ``(report, error)``.

    A centroid hides the thing that matters. The reference face's upper lip drops
    an average that looks tolerable while one vertex falls 11.12mm and tears the
    mouth open, so a fix has to be judged on the worst vertex, and the vertices
    have to be named so the same ones can be re-measured afterwards. This is also
    the arbiter for which vertices are actually mis-weighted: a classifier can
    only nominate candidates, and how far a vertex travels under the pose that
    reproduces the complaint is what decides.
    """
    if mesh is None or rig is None:
        return None, "Need both a mesh and an armature"
    pose_bone = rig.pose.bones.get(bone)
    if pose_bone is None:
        return None, "The armature has no bone called %r" % bone

    hidden = []
    if armature_only:
        for mod in mesh.modifiers:
            if mod.type != "ARMATURE" and mod.show_viewport:
                mod.show_viewport = False
                hidden.append(mod)
        if hidden:
            bpy.context.view_layer.update()

    def sample():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = mesh.evaluated_get(depsgraph)
        matrix = mesh.matrix_world
        verts = evaluated.data.vertices
        chosen = range(len(verts)) if indices is None else [
            i for i in indices if 0 <= i < len(verts)]
        return {i: matrix @ verts[i].co for i in chosen}

    saved_location = tuple(pose_bone.location)
    saved_euler = tuple(pose_bone.rotation_euler)
    saved_quat = tuple(pose_bone.rotation_quaternion)
    saved_mode = pose_bone.rotation_mode
    try:
        before = sample()
        pose_bone.location = (offset[0] * 0.001, offset[1] * 0.001,
                              offset[2] * 0.001)
        if rotation is not None:
            pose_bone.rotation_mode = "XYZ"
            pose_bone.rotation_euler = rotation
        bpy.context.view_layer.update()
        after = sample()
    finally:
        pose_bone.location = saved_location
        pose_bone.rotation_euler = saved_euler
        pose_bone.rotation_quaternion = saved_quat
        pose_bone.rotation_mode = saved_mode
        for mod in hidden:
            mod.show_viewport = True
        bpy.context.view_layer.update()

    rows = {}
    for index, start in before.items():
        end = after.get(index)
        if end is None:
            continue
        delta = end - start
        rows[index] = {"moved_mm": round(delta.length * 1000, 4),
                       "dz_mm": round(delta.z * 1000, 4),
                       "dy_mm": round(delta.y * 1000, 4)}
    if not rows:
        return None, "Nothing evaluated"
    moved = sorted(rows.items(), key=lambda kv: -kv[1]["moved_mm"])
    dropped = sorted(rows.items(), key=lambda kv: kv[1]["dz_mm"])
    total = sum(r["moved_mm"] for r in rows.values())
    return {
        "bone": bone, "vertices": len(rows),
        "mean_moved_mm": round(total / len(rows), 4),
        "worst_moved": [{"vertex": i, **r} for i, r in moved[:12]],
        "worst_dropped": [{"vertex": i, **r} for i, r in dropped[:12]],
        "over_0_5mm": sum(1 for r in rows.values() if r["moved_mm"] > 0.5),
        "per_vertex": {str(i): r["moved_mm"] for i, r in rows.items()},
        "per_vertex_dz": {str(i): r["dz_mm"] for i, r in rows.items()},
    }, ""


def transfer_weights(targets, donor, rig, mapping="POLYINTERP_NEAREST",
                     limit=0.01, preserve=True, drop_groups=()):
    """Copy a donor's deform weights onto meshes that shadow its surface.

    Returns ``(report, error)``.

    For a part that lies on another surface -- eyelashes on a lid, a sock on a
    calf -- copying the surface's own weights is both more accurate and far
    cheaper than heat-mapping the part against the whole armature, and it is the
    same sequence Auto-Rig Pro runs internally. ``BONE_DEFORM`` keeps non-deform
    groups from being dragged across, and the clean pass afterwards removes the
    dust that interpolation leaves behind.

    The donor has to be the ACTIVE object: Blender's transfer reads from the
    active and writes to the rest of the selection, so getting this backwards
    silently overwrites the donor instead.
    """
    meshes = [m for m in (targets or ()) if m is not None and m.type == "MESH"]
    if not meshes:
        return None, "No mesh to transfer onto"
    if donor is None or donor.type != "MESH":
        return None, "No donor mesh"
    if not len(donor.vertex_groups):
        return None, ("%s carries no weights, so there is nothing to copy"
                      % donor.name)
    empty = [m.name for m in (donor, *meshes) if not len(m.data.vertices)]
    if empty:
        return None, "%s has no vertices" % ", ".join(empty)

    view = bpy.context.view_layer
    previous_active = view.objects.active
    previous_selection = [o for o in bpy.context.selected_objects]
    if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")

    report = {"donor": donor.name, "meshes": [], "mapping": mapping}
    try:
        bpy.ops.object.select_all(action="DESELECT")
        for mesh in meshes:
            mesh.hide_viewport = False
            try:
                mesh.hide_set(False)
            except RuntimeError:
                pass
            mesh.select_set(True)
        donor.select_set(True)
        view.objects.active = donor
        # layers_select_src is a DYNAMIC enum. "BONE_DEFORM" is listed in the
        # API dump, but in a live context where the donor already carries weights
        # the enum becomes ('ACTIVE', 'ALL', <every group name>) and the constant
        # is rejected outright -- a shape of failure that a symbol index cannot
        # catch, only a run. "ALL" is always present and means the same thing
        # here, because every group on an Auto-Rig Pro bound mesh is a bone group.
        result = None
        chosen_layers = ""
        last = None
        for candidate in ("BONE_DEFORM", "ALL"):
            try:
                result = bpy.ops.object.data_transfer(
                    use_reverse_transfer=False, data_type="VGROUP_WEIGHTS",
                    vert_mapping=mapping, layers_select_src=candidate,
                    layers_select_dst="NAME", mix_mode="REPLACE")
                chosen_layers = candidate
                break
            except TypeError as exc:
                last = exc
        if result is None:
            return None, ("The weight transfer would not accept a source-layer "
                          "setting: %r" % last)
        report["transfer_result"] = str(result)
        report["layers_select_src"] = chosen_layers

        for mesh in meshes:
            for name in drop_groups or ():
                group = mesh.vertex_groups.get(name)
                if group is not None:
                    mesh.vertex_groups.remove(group)
            view.objects.active = mesh
            bpy.ops.object.select_all(action="DESELECT")
            mesh.select_set(True)
            if not len(mesh.vertex_groups):
                # The transfer wrote nothing. The usual cause is that the target
                # could not be selected because its collection is hidden or
                # excluded, and the next operator would otherwise fail three
                # steps away from that cause.
                return report, ("%s received no weights at all -- check that it "
                                "and its collections are visible and selectable"
                                % mesh.name)
            if limit > 0.0:
                bpy.ops.object.vertex_group_clean(group_select_mode="ALL",
                                                  limit=limit)
            ensure_modifier_pair(mesh, rig, preserve=preserve)
            parent_to_rig(mesh, rig)
            reached = 0
            for vert in mesh.data.vertices:
                if any(e.weight > 0.0 for e in vert.groups):
                    reached += 1
            report["meshes"].append({
                "mesh": mesh.name,
                "groups": len(mesh.vertex_groups),
                "vertices": len(mesh.data.vertices),
                "vertices_reached": reached,
                "coverage": round(reached / max(1, len(mesh.data.vertices)), 4),
                "stack": [m.name for m in mesh.modifiers],
            })
    finally:
        bpy.ops.object.select_all(action="DESELECT")
        for obj in previous_selection:
            try:
                obj.select_set(True)
            except RuntimeError:
                pass
        view.objects.active = previous_active

    starved = [r["mesh"] for r in report["meshes"] if r["coverage"] < 1.0]
    if starved:
        return report, ("%s did not reach every vertex, so part of it would stay "
                        "behind when the rig moves" % ", ".join(starved))
    return report, ""


def pin_gap_change(mesh, donor, pins, rig, bone, offset=(0.0, 0.0, 0.0)):
    """How much a pinned seam opens or closes when ``bone`` is posed, in mm.

    Returns ``(stats, error)``.

    This, not absolute motion, is what a pinned seam has to satisfy. Measured on
    the reference character, swinging the gaze moves the face's own eye socket rim
    0.139mm and the eyeball's rim 0.142mm -- the socket itself travels, because
    the whole rig shifts a little, and the face rim carries no weight from any eye
    bone at all. Judging the rim by how far it moves would therefore reject a
    correct bind. Judging it by whether it stays with the face accepts it, and is
    the stricter test: the reference bind holds the gap to 0.0000mm.
    """
    if mesh is None or donor is None or rig is None:
        return None, "Need the mesh, the donor and the armature"
    pose_bone = rig.pose.bones.get(bone)
    if pose_bone is None:
        return None, "The armature has no bone called %r" % bone

    hidden = []
    for obj in (mesh, donor):
        for mod in obj.modifiers:
            if mod.type != "ARMATURE" and mod.show_viewport:
                mod.show_viewport = False
                hidden.append(mod)
    if hidden:
        bpy.context.view_layer.update()

    def gaps():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        mesh_eval = mesh.evaluated_get(depsgraph)
        donor_eval = donor.evaluated_get(depsgraph)
        mm = mesh.matrix_world
        dm = donor.matrix_world
        out = {}
        for index, pin in pins.items():
            other = pin["donor_vertex"]
            if index >= len(mesh_eval.data.vertices):
                continue
            if other >= len(donor_eval.data.vertices):
                continue
            out[index] = ((mm @ mesh_eval.data.vertices[index].co)
                          - (dm @ donor_eval.data.vertices[other].co)).length
        return out

    saved_location = tuple(pose_bone.location)
    try:
        before = gaps()
        pose_bone.location = (offset[0] * 0.001, offset[1] * 0.001,
                              offset[2] * 0.001)
        bpy.context.view_layer.update()
        after = gaps()
    finally:
        pose_bone.location = saved_location
        for mod in hidden:
            mod.show_viewport = True
        bpy.context.view_layer.update()

    shared = [i for i in before if i in after]
    if not shared:
        return None, "No pinned vertex could be evaluated"
    changes = sorted(abs(after[i] - before[i]) * 1000.0 for i in shared)
    rest = sorted(before[i] * 1000.0 for i in shared)
    return {"pins": len(shared),
            "gap_median_mm": round(rest[len(rest) // 2], 4),
            "gap_max_mm": round(rest[-1], 4),
            "change_median_mm": round(changes[len(changes) // 2], 4),
            "change_max_mm": round(changes[-1], 4)}, ""


def suppress_arp_popups():
    """Silence Auto-Rig Pro's popups. Returns what to pass back to restore.

    ARP routes internal failures into a window-manager popup. In background
    Blender that call takes the whole process down with a return code instead of
    raising, so the first failure yields no traceback at all -- reproduced
    repeatedly. Anything that drives an ARP operator from a script installs this
    first.
    """
    import sys
    import types

    saved = []
    for name, module in list(sys.modules.items()):
        if "auto_rig_pro" not in name or not isinstance(module, types.ModuleType):
            continue
        original = getattr(module, "display_popup_message", None)
        if original is None:
            continue
        saved.append((module, original))
        module.display_popup_message = (
            lambda *a, **k: print("[SRS] ARP popup suppressed:", a, k))
    return saved


def restore_arp_popups(saved):
    """Put Auto-Rig Pro's popups back, whether or not the bind succeeded."""
    for module, original in saved or ():
        module.display_popup_message = original


def preflight(rig, meshes=(), require_facial=False):
    """Everything that must hold before a bind. Returns ``(report, error)``.

    A non-empty error means do not bind.
    """
    report = {"rig": getattr(rig, "name", ""), "checks": [], "warnings": []}

    def check(name, ok, detail=""):
        report["checks"].append({"check": name, "ok": bool(ok),
                                 "detail": str(detail)})
        return bool(ok)

    if rig is None or rig.type != "ARMATURE":
        return report, "No armature was given"

    if not check("is an Auto-Rig Pro rig", is_arp_rig(rig),
                 "looked for " + " / ".join(ARP_SIGNATURE_BONES)):
        return report, ("%s does not carry Auto-Rig Pro's signature bones, so it "
                        "is not the rig this expects" % rig.name)

    value, readable = secondary_type(rig)
    if not check("secondary type is readable", readable,
                 "arp_secondary_type is Auto-Rig Pro registered RNA"):
        return report, ("The rig's secondary type cannot be read, which means "
                        "Auto-Rig Pro is not loaded. It is the one fact this "
                        "whole scheme rests on, so it is refused rather than "
                        "assumed. Enable Auto-Rig Pro and run this again")
    if not check("secondary type is ADDITIVE", value == "ADDITIVE", value):
        return report, (
            "The rig's secondary type is %r, not ADDITIVE. Binding would create "
            "only one armature modifier and every new mesh would silently stop "
            "bending at the joints. Auto-Rig Pro's Match to Rig would also "
            "delete the additive rig on this setting, orphaning the second "
            "modifier on every mesh already bound" % value)

    add = rig_add_for(rig)
    if not check("additive rig exists", add is not None, rig.name + "_add"):
        return report, ("The rig is set to ADDITIVE but %s_add does not exist, "
                        "so the modifier pair cannot be built" % rig.name)
    bones = list(add.data.bones)
    check("additive bones all deform",
          bool(bones) and all(b.use_deform for b in bones),
          "%d bones, %d deform" % (len(bones),
                                   sum(1 for b in bones if b.use_deform)))
    report["additive_only_bones"] = sorted(
        {b.name for b in bones} - {b.name for b in rig.data.bones})

    facial = is_facial_enabled(rig)
    check("facial rig enabled", facial or not require_facial, str(facial))
    report["facial_enabled"] = facial
    if require_facial and not facial:
        return report, ("This pass needs Auto-Rig Pro's facial rig, and it is "
                        "not enabled on this armature")

    # Hidden objects cannot be selected, and select_set on one is simply ignored
    # -- so a bind driven through a selection would quietly touch fewer meshes
    # than asked. Report it as a fact the caller has to deal with.
    for mesh in meshes or ():
        if mesh is None or mesh.type != "MESH":
            continue
        if mesh.hide_viewport or mesh.hide_get():
            report["warnings"].append(
                "%s is hidden, so it cannot be selected and any "
                "selection-driven bind would skip it" % mesh.name)
        groups = len(mesh.vertex_groups)
        if groups > 8:
            report["warnings"].append(
                "%s already carries %d vertex groups. Auto-Rig Pro's bind "
                "removes existing groups, so do not put this mesh in an ARP "
                "bind selection" % (mesh.name, groups))
    return report, ""
