# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Matched bone chains for hair, braids and other hanging pieces.

A character's hair is usually modelled as many separate pieces rather than one
strand: on the reference character, four braids are spread over 42 mesh objects,
and each object holds the LEFT and the RIGHT copy of one segment as two islands
of the same mesh. Rigging that by hand means finding which island belongs to
which braid, laying a chain down each one, and then keeping the chains
interchangeable so the braids can be posed together.

This module does that from the geometry.

Discovery
    Meshes are grouped by a name pattern, split into connected islands, and each
    island is assigned to a braid by which side of the mirror plane its centre
    falls on. The braid's centreline is the islands' centres ordered along the
    hanging axis. Measured on the reference character this recovers exactly four
    braids -- two groups of 62 islands and two of 45 -- with the two sides
    matching island for island.

Matched chains
    Every braid in a set gets the SAME number of bones, resampled at equal arc
    length along its own centreline, so a braid that is 8 percent longer simply
    gets 8 percent longer bones. Each chain's bones are given the same roll, and
    a master chain is created whose bone *k* drives bone *k* of every braid
    through a local-space Copy Rotation. Posing the master therefore moves all
    braids identically, which is what keeps them from drifting apart; lowering a
    constraint's influence lets one braid depart from the others.

Rigid versus soft
    Hair bends and its metal ornaments do not. An island whose material is listed
    as rigid is bound whole to the single nearest bone, so it travels without
    deforming; every other island is bound smoothly across the two nearest bones
    so it bends. Both rules are per-island, which is why the ornaments keep their
    shape even though they sit in the middle of a bending braid.
"""

import math
import re
import json
import uuid

_OWNER = "_srs_hair_owner_v1"
_PREFIX = "_srs_hair_prefix_v1"
_BINDINGS = "_srs_hair_bindings_v1"


def _owned(bone, armature, prefix):
    token = armature.data.get(_OWNER)
    return bool(token and bone.get(_OWNER) == token and bone.get(_PREFIX) == prefix)


def _bindings(obj):
    try:
        data = json.loads(obj.get(_BINDINGS, "{}"))
        return data if isinstance(data, dict) else {}
    except (TypeError, ValueError):
        return {}


def _binding_key(armature, prefix):
    return json.dumps([armature.data.get(_OWNER, ""), prefix])


def binding_conflict(armature, braids, plan, prefix):
    """Check foreign group collisions before the public build mutates bones."""
    plans = {p["key"]: p for p in plan}
    for braid in braids:
        p = plans.get(braid["key"])
        if p is None:
            continue
        names = ["%s_%s_%02d" % (prefix, braid["key"], i + 1)
                 for i in range(len(p["points"]) - 1)]
        for island in braid["islands"]:
            obj = bpy.data.objects.get(island["object"])
            if obj is None:
                continue
            owned = _bindings(obj).get(_binding_key(armature, prefix), {}).get("groups", [])
            for name in names:
                if obj.vertex_groups.get(name) is not None and name not in owned:
                    return "An existing user vertex group conflicts with hair binding: " + name
    return ""

import bpy
from mathutils import Vector

from . import part_rig

AXIS_INDEX = {"X": 0, "Y": 1, "Z": 2}


# An island this share of its braid's height or more is a strand in its own right, not one
# segment of a stack: its centre says nothing about where the strand runs.
LONG_ISLAND_SHARE = 2.0 / 24.0
PATH_BANDS = 24


def _path_down(cos, axis):
    """The middle of a piece of mesh, band by band along ``axis``, highest first."""
    top = max(p[axis] for p in cos)
    bottom = min(p[axis] for p in cos)
    height = top - bottom
    if height < 1e-6:
        return []
    bands = [[] for _ in range(PATH_BANDS)]
    for p in cos:
        k = min(PATH_BANDS - 1, int((top - p[axis]) / height * PATH_BANDS))
        bands[k].append(p)
    return [sum(b, Vector()) / len(b) for b in bands if b]


def _islands(obj, hang=2):
    """Connected components of a mesh, in world space."""
    me = obj.data
    n = len(me.vertices)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for e in me.edges:
        ra, rb = find(e.vertices[0]), find(e.vertices[1])
        if ra != rb:
            parent[rb] = ra
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    mw = obj.matrix_world
    out = []
    for idx in groups.values():
        cos = [mw @ me.vertices[i].co for i in idx]
        centre = sum(cos, Vector()) / len(cos)
        low = Vector((min(p.x for p in cos), min(p.y for p in cos),
                      min(p.z for p in cos)))
        high = Vector((max(p.x for p in cos), max(p.y for p in cos),
                       max(p.z for p in cos)))
        out.append({"verts": idx, "centre": centre, "low": low, "high": high,
                    "path": _path_down(cos, hang),
                    "radius": max((p - centre).length for p in cos)})
    return out


def discover_braids(objects, pattern=r"(tail[A-Z])", side_axis="X",
                    hang_axis="Z", rigid_materials=(), min_verts=4,
                    group_by_collection=False, marker="", min_span=0.0,
                    max_span=0.0):
    """Group mesh islands into braids. Returns ``(braids, error)``.

    ``pattern`` picks the braid group out of the object's name; the side comes
    from the sign of the island's centre on ``side_axis``, which is what
    separates the left and right copy that share one mesh.
    """
    if not objects:
        return None, "No meshes were given"
    si = AXIS_INDEX.get(side_axis.upper())
    hi = AXIS_INDEX.get(hang_axis.upper())
    if si is None or hi is None:
        return None, "Axis must be X, Y or Z"
    rigid = {m.lower() for m in rigid_materials}
    rx = re.compile(pattern)
    braids = {}
    for obj in objects:
        if obj is None or obj.type != "MESH":
            continue
        if group_by_collection:
            # The character keeps each strand group in its own collection, which is
            # a far steadier grouping than a name pattern: the reference character's
            # braids sit in MIK_geo_hairA_tailA and _tailB while their meshes carry
            # a dozen different suffixes.
            group = None
            for c in obj.users_collection:
                if marker and marker not in c.name:
                    continue
                group = c.name
                break
            if group is None:
                continue
        else:
            m = rx.search(obj.name)
            if m is None:
                continue
            # a pattern without a capture group names the group by its whole match
            group = m.group(1) if rx.groups else m.group(0)
        mats = [s.name if s else "" for s in obj.data.materials]
        kind = "rigid" if (mats and mats[0].lower() in rigid) else "soft"
        for isl in _islands(obj, hi):
            if len(isl["verts"]) < min_verts:
                continue
            side = "L" if isl["centre"][si] >= 0.0 else "R"
            key = "%s_%s" % (group, side)
            braids.setdefault(key, {"key": key, "group": group, "side": side,
                                    "islands": []})
            braids[key]["islands"].append({
                "object": obj.name, "kind": kind,
                "centre": isl["centre"], "radius": isl["radius"],
                "low": isl.get("low"), "high": isl.get("high"),
                "path": isl.get("path") or [],
                "verts": isl["verts"]})
    if not braids:
        return None, "No islands matched the pattern"
    out = []
    for key in sorted(braids):
        b = braids[key]
        b["islands"].sort(key=lambda p: -p["centre"][hi])
        hs = [p["centre"][hi] for p in b["islands"]]
        b["top"] = hs[0]
        b["bottom"] = hs[-1]
        # `bottom` is the lowest island's CENTRE, and a chain that stops there
        # leaves everything below it riding one bone -- a stiff paddle rather
        # than a strand. Measured on this character before the fix: the tail
        # chains ended 230mm and 167mm above the hair. `tip` is the geometry's
        # own end, so the chain can be taken all the way down.
        ends = [p["low"][hi] for p in b["islands"] if p.get("low") is not None]
        b["tip"] = min(ends) if ends else hs[-1]
        # The length is the geometry's, top to tip. Between island centres, one strand
        # modelled as a single connected tube measures zero however long it is.
        heads = [p["high"][hi] for p in b["islands"] if p.get("high") is not None]
        b["crown"] = max(heads) if heads else hs[0]
        b["span"] = max(abs(hs[0] - hs[-1]), b["crown"] - b["tip"])
        # A cap of hair and a long braid want different chains: ten bones down a
        # 1.2m braid is right, ten down a 48mm clump is not. The span window lets
        # the caller take one tier at a time -- min_span for the long strands,
        # max_span for the short pieces -- so a short group is handled on its own
        # terms rather than dropped. Grouping by collection is what makes the
        # short ones visible at all, and on the reference character one came out
        # as a 4mm group of two islands, which no chain belongs on.
        if min_span and b["span"] < min_span:
            continue
        if max_span and b["span"] >= max_span:
            continue
        out.append(b)
    if not out:
        return None, ("No group's length falls inside the requested span window"
                      if (min_span or max_span) else
                      "No mesh matched, so there is nothing to chain")
    return out, ""


def centreline(braid, hang_axis="Z", bins=24):
    """A smooth path down the braid, from the islands' centres.

    The centres are noisy -- an ornament ring sits off the strand's middle -- so
    they are averaged in bands along the hanging axis before being joined up.
    """
    hi = AXIS_INDEX[hang_axis.upper()]
    # A long connected island gives its own path; a segment of a stack gives its centre.
    long_from = braid.get("span", 0.0) * LONG_ISLAND_SHARE
    samples = []
    long_top = False
    for number, isl in enumerate(braid["islands"]):
        high, low = isl.get("high"), isl.get("low")
        path = isl.get("path") or []
        if path and high is not None and low is not None and high[hi] - low[hi] >= long_from:
            samples.extend(path)
            long_top = long_top or number == 0
        else:
            samples.append(isl["centre"])
    heights = [p[hi] for p in samples]
    top, bottom = max(heights), min(heights)
    if abs(top - bottom) < 1e-6:
        return [braid["islands"][0]["centre"].copy()]
    buckets = [[] for _ in range(max(2, bins))]
    for point in samples:
        t = (top - point[hi]) / (top - bottom)
        k = min(len(buckets) - 1, max(0, int(t * len(buckets))))
        buckets[k].append(point)
    pts = []
    for b in buckets:
        if b:
            pts.append(sum(b, Vector()) / len(b))
    if len(pts) < 2:
        pts = [braid["islands"][0]["centre"].copy(),
               braid["islands"][-1]["centre"].copy()]
    crown = braid.get("crown")
    if long_top and crown is not None and pts and crown > pts[0][hi] + 1e-6:
        start = pts[0].copy()
        start[hi] = crown
        pts.insert(0, start)
    tip = braid.get("tip")
    if tip is not None and pts and tip < pts[-1][hi] - 1e-6:
        end = pts[-1].copy()
        end[hi] = tip
        pts.append(end)
    return pts


def _resample(points, count):
    """``count`` + 1 positions spaced at equal arc length along a polyline."""
    if count < 1:
        count = 1
    segs = []
    total = 0.0
    for a, b in zip(points, points[1:]):
        d = (b - a).length
        segs.append((a, b, d))
        total += d
    if total < 1e-9:
        return [points[0].copy() for _ in range(count + 1)]
    out = [points[0].copy()]
    step = total / count
    walked = 0.0
    i = 0
    acc = 0.0
    for k in range(1, count):
        target = k * step
        while i < len(segs) and acc + segs[i][2] < target:
            acc += segs[i][2]
            i += 1
        if i >= len(segs):
            out.append(points[-1].copy())
            continue
        a, b, d = segs[i]
        t = (target - acc) / max(d, 1e-9)
        out.append(a.lerp(b, t))
    out.append(points[-1].copy())
    return out


def plan_chains(braids, count, hang_axis="Z"):
    """Bone head/tail positions for every braid. Pure computation, no edits."""
    plan = []
    for b in braids:
        pts = _resample(centreline(b, hang_axis=hang_axis), count)
        plan.append({"key": b["key"], "group": b["group"], "side": b["side"],
                     "points": pts,
                     "bone_length": (sum((y - x).length
                                         for x, y in zip(pts, pts[1:])) / count)})
    return plan


def build(armature, plan, parent_bone="", prefix="hair", master=True,
          roll_target=(0.0, -1.0, 0.0), deform=True, bone_collection=""):
    """Create the chains and, optionally, the master that drives them.

    Returns ``(report, error)``.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if not plan:
        return None, "Nothing to build"
    counts = {len(p["points"]) for p in plan}
    if len(counts) != 1:
        return None, "The chains do not all have the same bone count"
    count = counts.pop() - 1
    planned_names = ([prefix + "_master_%02d" % (i + 1) for i in range(count)] if master else [])
    planned_names += ["%s_%s_%02d" % (prefix, p["key"], i + 1)
                      for p in plan for i in range(count)]
    for name in planned_names:
        bone = armature.data.bones.get(name)
        if bone is not None and not _owned(bone, armature, prefix):
            return None, "An existing user bone conflicts with hair generation: " + name
    mw = armature.matrix_world
    try:
        inv = mw.inverted()
    except ValueError:
        return None, "The armature's transform cannot be inverted"

    view = bpy.context.view_layer
    prev_active = view.objects.active
    prev_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
    made = []
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        ebs = armature.data.edit_bones
        roll_v = Vector(roll_target)
        if not armature.data.get(_OWNER):
            armature.data[_OWNER] = uuid.uuid4().hex

        def chain(name_fmt, points, parent_name, is_deform):
            names = []
            prev = ebs.get(parent_name) if parent_name else None
            connect = False
            for i in range(count):
                nm = name_fmt % (i + 1)
                if nm in ebs:
                    ebs.remove(ebs[nm])
                b = ebs.new(nm)
                b[_OWNER] = armature.data[_OWNER]
                b[_PREFIX] = prefix
                b.head = inv @ points[i]
                b.tail = inv @ points[i + 1]
                if (b.tail - b.head).length < 1e-5:
                    b.tail = b.head + Vector((0.0, 0.0, -0.01))
                try:
                    b.align_roll(roll_v)
                except (AttributeError, TypeError):
                    pass
                b.use_deform = bool(is_deform)
                if prev is not None:
                    b.parent = prev
                    b.use_connect = connect
                prev = b
                connect = True
                names.append(nm)
            return names

        master_names = []
        if master:
            ref = plan[0]["points"]
            master_names = chain(prefix + "_master_%02d", ref, parent_bone, False)
            made.append({"chain": "master", "bones": master_names})
        for p in plan:
            fmt = "%s_%s_%%02d" % (prefix, p["key"])
            names = chain(fmt, p["points"], parent_bone, deform)
            made.append({"chain": p["key"], "bones": names,
                         "bone_length_mm": round(p["bone_length"] * 1000.0, 2)})
        bpy.ops.object.mode_set(mode="POSE")
        if master and master_names:
            for entry in made:
                if entry["chain"] == "master":
                    continue
                for i, nm in enumerate(entry["bones"]):
                    pb = armature.pose.bones.get(nm)
                    if pb is None or i >= len(master_names):
                        continue
                    for c in list(pb.constraints):
                        if c.name == "SRS Hair Master":
                            pb.constraints.remove(c)
                    con = pb.constraints.new("COPY_ROTATION")
                    con.name = "SRS Hair Master"
                    con.target = armature
                    con.subtarget = master_names[i]
                    con.target_space = "LOCAL"
                    con.owner_space = "LOCAL"
                    con.mix_mode = "ADD"
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = prev_active
        if prev_active is not None and prev_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except RuntimeError:
                pass
    # File the new bones so the part can be hidden or deleted as a unit. Left
    # loose they belong to no bone collection and cannot be managed per costume.
    filed = 0
    for entry in made:
        target = bone_collection
        if not target:
            key = entry["chain"]
            if key == "master":
                target = prefix + "_master"
            else:
                # Strip the side suffix so both sides of a part share one bone
                # collection -- the unit the user hides or deletes is the costume
                # part, not a single strand.
                target = key[:-2] if key.endswith(("_L", "_R")) else key
        filed += part_rig.assign_bones(armature, entry["bones"], target)
    return {"chains": made, "bones_per_chain": count,
            "master": bool(master), "filed_bones": filed}, ""


def extend_chain(armature, prefix, points, bone_collection="",
                 master_prefix="", jiggle_from_root=True):
    """Add bones to the end of a chain that stops short. ``(report, error)``.

    ``points`` starts at the existing tip and lists each new joint, so three
    points add two bones. The new bones inherit the chain's parenting, its
    connection, its deform flag and its bone collection, and with
    ``master_prefix`` they copy rotation from the matching new master bone the
    same way the existing ones do.

    A chain that ends before its hair does is not obviously broken -- the mesh
    still moves, because the last bone carries everything past its own tip. It
    reads as a stiff paddle on the end of a soft rope. Measured on the reference
    character, the tail chains stopped at z=366mm and z=303mm while the hair
    reached z=136mm, so the bottom 230mm and 167mm were one rigid piece.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if len(points) < 2:
        return None, "Give the tip and at least one new joint"
    existing = sorted(b.name for b in armature.data.bones
                      if b.name.startswith(prefix + "_")
                      and b.name[len(prefix) + 1:].isdigit()
                      and _owned(b, armature, b.get(_PREFIX, "")))
    if not existing:
        return None, "No chain called %r" % prefix
    last = existing[-1]
    start = int(last[len(prefix) + 1:])
    template = armature.data.bones[last]
    owner_prefix = template.get(_PREFIX, "")
    if not _owned(template, armature, owner_prefix):
        return None, "The existing chain has no verified hair ownership"
    for n in range(len(points) - 1):
        name = "%s_%02d" % (prefix, start + n + 1)
        bone = armature.data.bones.get(name)
        if bone is not None and not _owned(bone, armature, owner_prefix):
            return None, "An existing user bone conflicts with hair extension: " + name
    collection = bone_collection or (template.collections[0].name
                                     if template.collections else "")
    deform = template.use_deform
    mw = armature.matrix_world
    try:
        inv = mw.inverted()
    except ValueError:
        return None, "The armature's transform cannot be inverted"

    view = bpy.context.view_layer
    previous = view.objects.active
    made = []
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        ebs = armature.data.edit_bones
        parent = ebs.get(last)
        roll = parent.roll if parent else 0.0
        for n in range(len(points) - 1):
            name = "%s_%02d" % (prefix, start + n + 1)
            if name in ebs:
                ebs.remove(ebs[name])
            bone = ebs.new(name)
            bone[_OWNER] = armature.data[_OWNER]
            bone[_PREFIX] = owner_prefix
            bone.head = inv @ points[n]
            bone.tail = inv @ points[n + 1]
            if (bone.tail - bone.head).length < 1.0e-5:
                bone.tail = bone.head + Vector((0.0, 0.0, -0.01))
            bone.roll = roll
            bone.parent = parent
            bone.use_connect = True
            bone.use_deform = deform
            made.append(name)
            parent = bone
        bpy.ops.object.mode_set(mode="OBJECT")
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = previous
    if collection:
        target = armature.data.collections_all.get(collection)
        if target is None:
            target = armature.data.collections.new(collection)
        for name in made:
            bone = armature.data.bones.get(name)
            if bone is not None:
                target.assign(bone)
    if master_prefix:
        for n, name in enumerate(made):
            pose_bone = armature.pose.bones.get(name)
            master = "%s_%02d" % (master_prefix, start + n + 1)
            if pose_bone is None or armature.pose.bones.get(master) is None:
                continue
            con = pose_bone.constraints.new("COPY_ROTATION")
            con.target = armature
            con.subtarget = master
            con.mix_mode = "ADD"
            con.target_space = "LOCAL"
            con.owner_space = "LOCAL"
    carried = {}
    if jiggle_from_root:
        # A longer chain is a different spring: twelve links' worth of rotation
        # at the settings that suited eight never settles. Report what the chain
        # is carrying so the caller can retune it, rather than pretending the
        # appended bones need a copy -- jiggle.settings_for reads the root.
        root = armature.pose.bones.get("%s_01" % prefix)
        if root is not None:
            for key in ("srs_jiggle_stiffness", "srs_jiggle_damping",
                        "srs_jiggle_gravity", "srs_jiggle_inertia"):
                if key in root.keys():
                    carried[key] = root[key]
    return {"chain": prefix, "added": made, "after": last,
            "collection": collection, "jiggle": carried,
            "retune_note": ("the chain is longer now; the stored settings were "
                            "chosen for its old length"),
            "length_mm": round(sum((points[i + 1] - points[i]).length
                                   for i in range(len(points) - 1)) * 1000, 1)}, ""


def _generated_name(prefix):
    """Names ``build`` writes: <prefix>_<key>_NN, master included.

    A hand-made ``hair_01`` shares the prefix but has no key, and is not ours to delete.
    """
    return re.compile(r"^%s_(.+)_(\d{2,})$" % re.escape(prefix))


def bind(objects, armature, braids, plan, prefix="hair", clear=True):
    """Weight every island: rigid ones whole, soft ones across two bones.

    Returns ``(report, error)``.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    by_key = {p["key"]: p for p in plan}
    report = {"objects": [], "rigid_islands": 0, "soft_islands": 0}
    touched = {}
    for b in braids:
        p = by_key.get(b["key"])
        if p is None:
            continue
        pts = p["points"]
        n = len(pts) - 1
        names = ["%s_%s_%02d" % (prefix, b["key"], i + 1) for i in range(n)]
        mids = [(pts[i] + pts[i + 1]) * 0.5 for i in range(n)]
        for isl in b["islands"]:
            obj = bpy.data.objects.get(isl["object"])
            if obj is None:
                continue
            groups = touched.setdefault(obj.name, {})
            me = obj.data
            mw = obj.matrix_world
            if isl["kind"] == "rigid":
                k = min(range(n), key=lambda i: (mids[i] - isl["centre"]).length)
                for vi in isl["verts"]:
                    groups.setdefault(names[k], []).append((vi, 1.0))
                report["rigid_islands"] += 1
            else:
                for vi in isl["verts"]:
                    co = mw @ me.vertices[vi].co
                    d = sorted(range(n), key=lambda i: (mids[i] - co).length)[:2]
                    if len(d) == 1:
                        groups.setdefault(names[d[0]], []).append((vi, 1.0))
                        continue
                    a, c = d
                    da = max((mids[a] - co).length, 1e-6)
                    dc = max((mids[c] - co).length, 1e-6)
                    wa = (1.0 / da) / ((1.0 / da) + (1.0 / dc))
                    groups.setdefault(names[a], []).append((vi, wa))
                    groups.setdefault(names[c], []).append((vi, 1.0 - wa))
                report["soft_islands"] += 1

    # Validate every destination before clearing or assigning any weights.
    binding_key = _binding_key(armature, prefix)
    for obj_name, groups in touched.items():
        obj = bpy.data.objects.get(obj_name)
        if obj is None:
            continue
        owned_groups = _bindings(obj).get(binding_key, {}).get("groups", [])
        for name in groups:
            bone = armature.data.bones.get(name)
            if bone is None or not _owned(bone, armature, prefix):
                return None, "No verified generated hair bone: " + name
            if obj.vertex_groups.get(name) is not None and name not in owned_groups:
                return None, "An existing user vertex group conflicts with hair binding: " + name

    for obj_name, groups in touched.items():
        obj = bpy.data.objects.get(obj_name)
        if obj is None:
            continue
        bindings = _bindings(obj)
        owned = bindings.get(binding_key, {"groups": [], "modifiers": []})
        if clear:
            for vg in list(obj.vertex_groups):
                if vg.name in owned["groups"]:
                    obj.vertex_groups.remove(vg)
        for gname, pairs in groups.items():
            vg = obj.vertex_groups.get(gname) or obj.vertex_groups.new(name=gname)
            for vi, w in pairs:
                vg.add([vi], w, "REPLACE")
        if not any(m.type == "ARMATURE" and m.object == armature
                   for m in obj.modifiers):
            mod = obj.modifiers.new(name="SRS Hair", type="ARMATURE")
            mod.object = armature
            owned["modifiers"].append(mod.name)
        owned["groups"] = sorted(set(groups) | (set() if clear else set(owned["groups"])))
        bindings[binding_key] = owned
        obj[_BINDINGS] = json.dumps(bindings)
        if obj.parent is None:
            obj.parent = armature
            obj.matrix_parent_inverse = armature.matrix_world.inverted()
        report["objects"].append({"object": obj_name, "groups": len(groups)})
    return report, ""


def audit(armature, prefix="hair"):
    """What chains exist, and whether the master actually drives them."""
    out = {"chains": {}, "issues": []}
    if armature is None or armature.type != "ARMATURE":
        return {"error": "No armature", "chains": {}, "issues": []}
    rx = re.compile(r"^%s_(.+)_(\d{2})$" % re.escape(prefix))
    for pb in armature.pose.bones:
        m = rx.match(pb.name)
        if not m:
            continue
        key = m.group(1)
        rec = out["chains"].setdefault(key, {"bones": 0, "driven": 0,
                                             "lengths_mm": []})
        rec["bones"] += 1
        rec["lengths_mm"].append(round(pb.bone.length * 1000.0, 2))
        if any(c.name == "SRS Hair Master" for c in pb.constraints):
            rec["driven"] += 1
    # Compare within a family, not across the whole prefix. Under "hair" every
    # chain is one braid and they should match; under "srs_chain" a zip pull is
    # one bone, a hem column two, a fringe three and a belt strap ten, and
    # saying so as an issue is noise that trains the reader to ignore the list.
    counts = {k: v["bones"] for k, v in out["chains"].items() if k != "master"}
    families = {}
    for name, count in counts.items():
        stem = re.sub(r"[_.]\d+$", "", name)
        stem = re.sub(r"[_.][lrLR]$", "", stem)
        families.setdefault(stem, {})[name] = count
    for stem, rows in sorted(families.items()):
        if len(rows) > 1 and len(set(rows.values())) != 1:
            out["issues"].append(
                "chains of %r have different bone counts: %s" % (stem, rows))
    # A control that works on part of a chain is worse than no control: extend a
    # chain past the masters that exist and the first links follow while the new
    # ones sit still, which reads as a broken rig rather than a missing feature.
    masters = out["chains"].get("master", {}).get("bones", 0)
    for key, rec in sorted(out["chains"].items()):
        if key == "master" or not rec["driven"]:
            continue
        if rec["driven"] != rec["bones"]:
            out["issues"].append(
                "chain %r is driven on %d of its %d bones, so the master moves "
                "part of it" % (key, rec["driven"], rec["bones"]))
        if masters and rec["bones"] > masters:
            out["issues"].append(
                "chain %r has %d bones but only %d masters exist"
                % (key, rec["bones"], masters))
    for k, v in out["chains"].items():
        if v["lengths_mm"]:
            v["mean_length_mm"] = round(sum(v["lengths_mm"]) / len(v["lengths_mm"]), 2)
            v["lengths_mm"] = v["lengths_mm"][:4]
    return out


def bind_rigid(objects, armature, bone, group_prefix="hair"):
    """Attach whole meshes to one bone, unbent.

    Not every hair piece hangs. The pieces sitting on the head -- the cap of hair
    and its ornaments -- only need to travel with the skull, and on the reference
    character five of the forty-two objects are of that kind: they carry no braid
    name and so are left out of the chains. Binding them rigidly to the head bone
    finishes the coverage without inventing a chain for geometry that never bends.

    Returns ``(report, error)``.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if bone not in armature.pose.bones:
        return None, "The armature has no bone called %r" % bone
    done = []
    for obj in objects:
        if obj is None or obj.type != "MESH" or not obj.data.vertices:
            continue
        vg = obj.vertex_groups.get(bone) or obj.vertex_groups.new(name=bone)
        vg.add([v.index for v in obj.data.vertices], 1.0, "REPLACE")
        if not any(m.type == "ARMATURE" and m.object == armature
                   for m in obj.modifiers):
            mod = obj.modifiers.new(name="SRS Hair", type="ARMATURE")
            mod.object = armature
        if obj.parent is None:
            obj.parent = armature
            obj.matrix_parent_inverse = armature.matrix_world.inverted()
        done.append(obj.name)
    return {"bone": bone, "objects": done}, ""


def unchained(objects, braids):
    """The meshes discovery did not place on any braid."""
    used = set()
    for b in braids or []:
        for isl in b["islands"]:
            used.add(isl["object"])
    return [o for o in objects
            if o is not None and o.type == "MESH" and o.name not in used]


def remove(armature, objects=(), prefix="hair"):
    """Delete the generated chains and the groups they bound. Returns count."""
    if armature is None or armature.type != "ARMATURE":
        return 0
    binding_key = _binding_key(armature, prefix)
    view = bpy.context.view_layer
    prev_active = view.objects.active
    prev_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
    n = 0
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        for b in list(armature.data.edit_bones):
            if _owned(b, armature, prefix):
                armature.data.edit_bones.remove(b)
                n += 1
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = prev_active
        if prev_active is not None and prev_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except RuntimeError:
                pass
    for obj in objects or []:
        if obj is None or obj.type != "MESH":
            continue
        bindings = _bindings(obj)
        owned = bindings.pop(binding_key, {})
        for vg in list(obj.vertex_groups):
            if vg.name in owned.get("groups", []):
                obj.vertex_groups.remove(vg)
        for m in list(obj.modifiers):
            if (m.type == "ARMATURE" and m.object == armature
                    and m.name in owned.get("modifiers", [])):
                obj.modifiers.remove(m)
        if bindings:
            obj[_BINDINGS] = json.dumps(bindings)
        elif _BINDINGS in obj:
            del obj[_BINDINGS]
    return n
