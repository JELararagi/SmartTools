# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()


import json
import os
from collections import OrderedDict
import re
import subprocess
import sys
from contextlib import nullcontext
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable

import addon_utils
import bpy

try:
    import tomllib
except Exception:  # pragma: no cover - Blender 5.1 ships Python with tomllib
    tomllib = None


ARP_SUFFIXES = ("auto_rig_pro",)
RIG_TOOLS_SUFFIXES = ("ARP_rig_tools", "rig_tools")
PROXY_SUFFIXES = ("proxy_picker",)
AI_MINIMUM_VERSION = "1.20"
AI_REQUIRED = (
    "inference/inference_front.exe",
    "inference/inference_side.exe",
    "inference/inference_top.exe",
    "inference/inference_fingers.exe",
    "inference/inference_facial.exe",
    "inference/front_model.pth",
    "inference/side_model.pth",
    "inference/top_model.pth",
    "inference/fingers_model.pth",
    "inference/facial_model.pth",
)
AI_OPTIONAL = ("inference/fingers4_model.pth",)
_PACKAGE_DIR = Path(__file__).resolve().parent
_EMBEDDED_MODULE_TOKENS = (
    "smart_rig_suite.smart_rig_core",
    "smart_rig_suite.smart_rig_motion_tools",
    "smart_rig_suite.smart_rig_ai_runtime",
    "smart_rig_suite.auto_rig_pro",
    "smart_rig_suite.arp_rig_tools",
    "smart_rig_suite.proxy_picker",
    "smart_rig_suite.srs_proxy_picker",
    "smart_rig_suite.arp_bridge",
    "smart_rig_suite.core",
    "smart_rig_suite.cloudrig",
    "smart_rig_suite.easyweight",
)


@dataclass(frozen=True)
class AddonStatus:
    key: str = ""
    enabled: bool = False
    operator_available: bool = False
    version: str = ""
    path: str = ""
    external: bool = True
    embedded: bool = False

    @property
    def available(self) -> bool:
        return self.enabled and self.operator_available and self.external and not self.embedded


@dataclass(frozen=True)
class AIRuntimeStatus:
    root: str = ""
    valid: bool = False
    version: str = ""
    version_ok: bool = False
    platform_compatible: bool = False
    missing: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExternalStatus:
    auto_rig_pro: AddonStatus
    rig_tools: AddonStatus
    proxy_picker: AddonStatus
    ai_runtime: AIRuntimeStatus

    def to_dict(self) -> dict[str, Any]:
        return {
            "auto_rig_pro": asdict(self.auto_rig_pro),
            "rig_tools": asdict(self.rig_tools),
            "proxy_picker": asdict(self.proxy_picker),
            "ai_runtime": asdict(self.ai_runtime),
        }


_UI_OPERATOR_IDS = (
    "arp.append_arp",
    "arp.guess_markers",
    "pose.arp_arm_fk_to_ik_",
    "arp.bind_to_rig",
    "pp.auto_proxy",
)
_UI_STATUS_CACHE_LIMIT = 4


@dataclass(frozen=True)
class UIStatusSnapshot:
    configured_ai_path: str
    status: ExternalStatus
    conflicts: tuple[str, ...] = ()
    operator_states: tuple[tuple[str, bool], ...] = ()
    scanned: bool = False

    def operator_available(self, operator_id: str) -> bool:
        return any(name == operator_id and available for name, available in self.operator_states)


_UI_STATUS_CACHE: OrderedDict[str, UIStatusSnapshot] = OrderedDict()


def _safe_resolve(path: str | os.PathLike[str]) -> Path:
    try:
        return Path(path).resolve()
    except Exception:
        return Path(path).absolute()


def _path_inside(path_value: str, parent: Path) -> bool:
    if not path_value:
        return False
    try:
        child = _safe_resolve(path_value)
        child.relative_to(parent)
        return True
    except Exception:
        return False


def _enabled_addon_keys(context: bpy.types.Context | None = None) -> list[str]:
    try:
        prefs = (context or bpy.context).preferences
        return [str(item.module) for item in prefs.addons]
    except Exception:
        return []


def _matches_suffix(key: str, suffixes: Iterable[str]) -> bool:
    lower = key.lower()
    for suffix in suffixes:
        suffix_lower = str(suffix).lower()
        if lower == suffix_lower or lower.endswith("." + suffix_lower):
            return True
    return False


def find_enabled_addon_key(suffixes: Iterable[str], context: bpy.types.Context | None = None) -> str:
    matches = [key for key in _enabled_addon_keys(context) if _matches_suffix(key, suffixes)]
    if not matches:
        return ""
    # Prefer a separately installed extension over classic aliases and avoid
    # accidentally selecting a former Smart Rig Suite embedded module.
    matches.sort(
        key=lambda value: (
            "smart_rig_suite" in value.lower(),
            "user_default" not in value.lower(),
            len(value),
            value.lower(),
        )
    )
    return matches[0]


def get_addon_preferences(suffixes: Iterable[str], context: bpy.types.Context | None = None) -> Any | None:
    ctx = context or bpy.context
    key = find_enabled_addon_key(suffixes, ctx)
    if not key:
        return None
    try:
        addon = ctx.preferences.addons.get(key)
        return addon.preferences if addon is not None else None
    except Exception:
        return None


def operator_callable(operator_id: str) -> Any | None:
    try:
        namespace, name = operator_id.split(".", 1)
    except ValueError:
        return None
    try:
        op = getattr(getattr(bpy.ops, namespace), name)
        # bpy.ops hands out a wrapper for any name; only a registered operator has an RNA type
        op.get_rna_type()
        return op
    except Exception:
        return None


def operator_exists(operator_id: str) -> bool:
    op = operator_callable(operator_id)
    if op is None:
        return False
    try:
        op.get_rna_type()
        return True
    except Exception:
        return False


def operator_poll(operator_id: str) -> tuple[bool, str]:
    op = operator_callable(operator_id)
    if op is None:
        return False, f"Operator not registered: {tool_label(operator_id)}"
    try:
        return bool(op.poll()), ""
    except Exception:
        return False, f"Operator poll failed: {tool_label(operator_id)}"


def _filter_operator_kwargs(operator_id: str, kwargs: dict[str, Any]) -> dict[str, Any]:
    op = operator_callable(operator_id)
    if op is None:
        return {}
    try:
        properties = op.get_rna_type().properties
        allowed = {prop.identifier for prop in properties if prop.identifier != "rna_type"}
        return {key: value for key, value in kwargs.items() if key in allowed}
    except Exception:
        return dict(kwargs)


def find_view3d_override(context: bpy.types.Context | None = None) -> dict[str, Any] | None:
    ctx = context or bpy.context
    try:
        window = getattr(ctx, "window", None)
        screen = getattr(window, "screen", None) if window is not None else None
        if screen is not None:
            for area in tuple(screen.areas):
                if area.type != "VIEW_3D":
                    continue
                region = next((region for region in area.regions if region.type == "WINDOW"), None)
                if region is not None:
                    return {"window": window, "screen": screen, "area": area, "region": region}
    except Exception:
        pass
    try:
        wm = getattr(ctx, "window_manager", None)
        for window in tuple(getattr(wm, "windows", ())):
            screen = window.screen
            for area in tuple(screen.areas):
                if area.type != "VIEW_3D":
                    continue
                region = next((region for region in area.regions if region.type == "WINDOW"), None)
                if region is not None:
                    return {"window": window, "screen": screen, "area": area, "region": region}
    except Exception:
        pass
    return None


TOOL_STOPPED = "The external tool stopped with an error. Check the selection and mode, then run it again."


def tool_label(operator_id: str) -> str:
    """The add-on an external operator belongs to, as people know it. Operator ids stay off the screen."""
    text = str(operator_id)
    if text.startswith("pp."):
        return "Proxy Picker"
    if text.startswith("arp.") or ".arp_" in text:
        return "Auto-Rig Pro"
    return "the external tool"


def call_operator(
    operator_id: str,
    *,
    execution: str = "EXEC_DEFAULT",
    kwargs: dict[str, Any] | None = None,
    use_view3d_override: bool = True,
) -> tuple[set[str], str]:
    """Call an already registered external operator without importing its code."""
    op = operator_callable(operator_id)
    if op is None:
        return {"CANCELLED"}, f"Operator not registered: {tool_label(operator_id)}"
    filtered = _filter_operator_kwargs(operator_id, kwargs or {})
    override = find_view3d_override() if use_view3d_override else None
    if use_view3d_override and override is None and bpy.app.background:
        return {"CANCELLED"}, f"A 3D View context is required: {tool_label(operator_id)}"
    manager = bpy.context.temp_override(**override) if override else nullcontext()
    try:
        with manager:
            try:
                if not op.poll():
                    return {"CANCELLED"}, f"Operator context is not valid: {tool_label(operator_id)}"
            except Exception:
                return {"CANCELLED"}, f"Operator poll failed: {tool_label(operator_id)}"
            try:
                return set(op(execution, **filtered)), ""
            except TypeError:
                try:
                    return set(op(**filtered)), ""
                except Exception:
                    return {"CANCELLED"}, TOOL_STOPPED
            except Exception:
                return {"CANCELLED"}, TOOL_STOPPED
    except Exception:
        return {"CANCELLED"}, "Could not prepare a 3D View for the external tool."


def _module_without_import(key: str):
    module = sys.modules.get(key)
    if module is not None:
        return module
    try:
        for candidate in addon_utils.modules(refresh=False):
            if str(getattr(candidate, "__name__", "")) == key:
                return candidate
    except Exception:
        pass
    return None


def _module_version_and_path(key: str) -> tuple[str, str]:
    if not key:
        return "", ""
    module = _module_without_import(key)
    version = ""
    path = ""
    if module is not None:
        try:
            path = str(Path(module.__file__).resolve().parent)
        except Exception:
            path = ""
        try:
            info = getattr(module, "bl_info", {}) or {}
            raw = info.get("version")
            if isinstance(raw, (tuple, list)):
                version = ".".join(str(part) for part in raw)
            elif raw:
                version = str(raw)
        except Exception:
            pass
    if path and tomllib is not None:
        manifest = Path(path) / "blender_manifest.toml"
        if manifest.is_file():
            try:
                data = tomllib.loads(manifest.read_text(encoding="utf-8"))
                version = str(data.get("version") or version)
            except Exception:
                pass
    return version, path


def addon_status(
    suffixes: Iterable[str],
    representative_operator: str,
    context: bpy.types.Context | None = None,
) -> AddonStatus:
    key = find_enabled_addon_key(suffixes, context)
    version, path = _module_version_and_path(key)
    embedded = bool(path and _path_inside(path, _PACKAGE_DIR)) or "smart_rig_suite" in key.lower()
    return AddonStatus(
        key=key,
        enabled=bool(key),
        operator_available=operator_exists(representative_operator),
        version=version,
        path=path,
        external=not embedded,
        embedded=embedded,
    )


def _decimal_version(value: str) -> Decimal | None:
    cleaned = re.search(r"\d+(?:\.\d+)?", str(value or ""))
    if cleaned is None:
        return None
    try:
        return Decimal(cleaned.group(0))
    except InvalidOperation:
        return None


def normalize_ai_root(path_value: str | os.PathLike[str] | None) -> Path | None:
    if not path_value:
        return None
    try:
        raw = bpy.path.abspath(str(path_value))
    except Exception:
        raw = str(path_value)
    raw = os.path.expandvars(os.path.expanduser(raw.strip().strip('"')))
    if not raw or raw in {".", "./", ".\\"}:
        return None
    candidate = _safe_resolve(raw)
    if candidate.is_file() and candidate.suffix.lower() == ".zip":
        # External companion mode never extracts archives.  The user must point
        # to the already installed runtime folder.
        return candidate
    if candidate.name.lower() == "inference" and (candidate.parent / "info.dat").is_file():
        candidate = candidate.parent
    if (candidate / "inference" / "inference_front.exe").is_file():
        return candidate
    nested = candidate / "AI_win_1.20"
    if (nested / "inference" / "inference_front.exe").is_file():
        return nested
    return candidate


def _parse_ai_version(root: Path) -> str:
    info = root / "info.dat"
    if not info.is_file():
        return ""
    try:
        text = info.read_text(encoding="utf-8-sig", errors="replace")
    except Exception:
        return ""
    match = re.search(r"version\s*=\s*([^\s]+)", text, re.IGNORECASE)
    return match.group(1).strip() if match else (text.strip().splitlines()[0].strip() if text.strip() else "")


def validate_ai_runtime(path_value: str | os.PathLike[str] | None) -> AIRuntimeStatus:
    root = normalize_ai_root(path_value)
    if root is None:
        return AIRuntimeStatus(
            platform_compatible=sys.platform.startswith("win"),
            missing=("AI runtime path",),
        )
    missing: list[str] = []
    if root.is_file():
        missing.append("Extract the external AI runtime ZIP before selecting it")
    else:
        if not (root / "info.dat").is_file():
            missing.append("info.dat")
        for relative in AI_REQUIRED:
            if not (root / relative).is_file():
                missing.append(relative)
    version = _parse_ai_version(root) if root.is_dir() else ""
    current = _decimal_version(version)
    required = _decimal_version(AI_MINIMUM_VERSION)
    version_ok = bool(current is not None and required is not None and current >= required)
    if not version_ok and not any(item.startswith("Extract ") for item in missing):
        missing.append(f"AI runtime version {AI_MINIMUM_VERSION} or newer")
    return AIRuntimeStatus(
        root=str(root),
        valid=not missing,
        version=version,
        version_ok=version_ok,
        platform_compatible=sys.platform.startswith("win"),
        missing=tuple(missing),
    )


def arp_ai_path(context: bpy.types.Context | None = None) -> str:
    prefs = get_addon_preferences(ARP_SUFFIXES, context)
    if prefs is None:
        return ""
    try:
        return str(getattr(prefs, "ai_presets_path", "") or "")
    except Exception:
        return ""


def set_arp_ai_path(path_value: str, context: bpy.types.Context | None = None) -> tuple[bool, str]:
    prefs = get_addon_preferences(ARP_SUFFIXES, context)
    if prefs is None:
        return False, "Auto-Rig Pro preferences were not found."
    status = validate_ai_runtime(path_value)
    if not status.valid:
        return False, "The external AI runtime is incomplete or older than version 1.20."
    try:
        prefs.ai_presets_path = status.root
    except Exception:
        return False, "Failed to update Auto-Rig Pro AI path."
    try:
        scene = (context or bpy.context).scene
        if hasattr(scene, "arp_smart_AI_is_installed"):
            scene.arp_smart_AI_is_installed = True
    except Exception:
        pass
    return True, ""


def discover_ai_runtime(configured_path: str, context: bpy.types.Context | None = None) -> AIRuntimeStatus:
    candidates: list[str] = []
    for environment_name in ("SRS_AI_RUNTIME", "ARP_AI_RUNTIME"):
        environment_value = os.environ.get(environment_name, "")
        if environment_value:
            candidates.append(environment_value)
    if configured_path:
        candidates.append(configured_path)
    arp_path = arp_ai_path(context)
    if arp_path:
        candidates.append(arp_path)
    home = Path.home()
    candidates.extend(
        [
            str(home / "Documents" / "Auto-Rig Pro" / "AI"),
            str(home / "Documents" / "AutoRigPro" / "AI"),
            str(home / "Documents" / "AI_win_1.20"),
        ]
    )
    seen: set[str] = set()
    best = AIRuntimeStatus(platform_compatible=sys.platform.startswith("win"))
    for value in candidates:
        root = normalize_ai_root(value)
        if root is None:
            continue
        key = os.path.normcase(str(root))
        if key in seen:
            continue
        seen.add(key)
        status = validate_ai_runtime(root)
        if status.valid:
            return status
        if not best.root:
            best = status
    return best if best.root else validate_ai_runtime(configured_path)


def _is_obsolete_embedded_module(module_name: str) -> bool:
    lower = str(module_name or "").lower()
    if not any(token in lower for token in _EMBEDDED_MODULE_TOKENS):
        return False
    module = sys.modules.get(module_name)
    if module is not None:
        try:
            return _path_inside(str(module.__file__), _PACKAGE_DIR)
        except Exception:
            pass
    # A stale RNA class can outlive its Python module during a live update.
    # In that case the explicit Smart Rig Suite namespace is sufficient; a
    # separately installed external module such as
    # ``bl_ext.user_default.auto_rig_pro`` does not match these tokens.
    return "smart_rig_suite" in lower


def embedded_registration_conflicts() -> list[str]:
    conflicts: list[str] = []
    base_types: tuple[type, ...] = (bpy.types.Operator, bpy.types.Panel, bpy.types.Menu, bpy.types.UIList)
    for name in tuple(dir(bpy.types)):
        try:
            cls = getattr(bpy.types, name)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        try:
            if not issubclass(cls, base_types):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, "__module__", ""))
        if _is_obsolete_embedded_module(module_name):
            conflicts.append(f"{name} ({module_name})")
    return sorted(set(conflicts))


def external_status(configured_ai_path: str, context: bpy.types.Context | None = None) -> ExternalStatus:
    arp = addon_status(ARP_SUFFIXES, "arp.append_arp", context)
    rig = addon_status(RIG_TOOLS_SUFFIXES, "pose.arp_arm_fk_to_ik_", context)
    # The full package normally supplies the rig-tools operators.  Treat those
    # operators as available from the external Auto-Rig Pro installation when
    # no standalone Rig Tools add-on is enabled.
    if rig.operator_available and not rig.enabled and arp.available:
        rig = AddonStatus(
            key=arp.key,
            enabled=True,
            operator_available=True,
            version=arp.version,
            path=arp.path,
            external=True,
            embedded=False,
        )
    return ExternalStatus(
        auto_rig_pro=arp,
        rig_tools=rig,
        proxy_picker=addon_status(PROXY_SUFFIXES, "pp.auto_proxy", context),
        ai_runtime=discover_ai_runtime(configured_ai_path, context),
    )


def external_conflicts(
    context: bpy.types.Context | None = None,
    *,
    status: ExternalStatus | None = None,
) -> list[str]:
    warnings: list[str] = []
    arp_key = find_enabled_addon_key(ARP_SUFFIXES, context)
    rig_key = find_enabled_addon_key(RIG_TOOLS_SUFFIXES, context)
    if arp_key and rig_key and arp_key != rig_key:
        warnings.append(
            "The full Auto-Rig Pro add-on and standalone Rig Tools are both enabled. Disable the standalone "
            "package because the full package already registers the same RNA classes."
        )
    current = status if status is not None else external_status("", context)
    for label, addon in (
        ("Auto-Rig Pro", current.auto_rig_pro),
        ("Rig Tools", current.rig_tools),
        ("Proxy Picker", current.proxy_picker),
    ):
        if addon.embedded:
            warnings.append(f"{label} is still loaded from inside the Smart Rig Suite folder instead of externally.")
        elif addon.enabled and not addon.operator_available:
            warnings.append(
                f"{label} is enabled but its expected operator is unavailable. Restart Blender after removing "
                "an older embedded Smart Rig Suite build."
            )
    embedded = embedded_registration_conflicts()
    if embedded:
        warnings.append(f"{len(embedded)} obsolete embedded RNA registration(s) remain in the current Blender process.")
    return warnings


def _ui_status_key(configured_ai_path: str) -> str:
    return os.path.normcase(os.path.normpath(str(configured_ai_path or "").strip()))


def _empty_ui_status(configured_ai_path: str) -> UIStatusSnapshot:
    return UIStatusSnapshot(
        configured_ai_path=str(configured_ai_path or ""),
        status=ExternalStatus(
            auto_rig_pro=AddonStatus(),
            rig_tools=AddonStatus(),
            proxy_picker=AddonStatus(),
            ai_runtime=AIRuntimeStatus(platform_compatible=sys.platform.startswith("win")),
        ),
        operator_states=tuple((operator_id, False) for operator_id in _UI_OPERATOR_IDS),
        scanned=False,
    )


def get_ui_status(configured_ai_path: str) -> UIStatusSnapshot:
    """Return a draw-safe cached snapshot without scanning add-ons or files."""
    key = _ui_status_key(configured_ai_path)
    exact = _UI_STATUS_CACHE.get(key)
    if exact is not None:
        return exact
    if not _UI_STATUS_CACHE:
        return _empty_ui_status(configured_ai_path)

    # An edited AI path invalidates only the AI result. External add-on and
    # operator availability remains valid until the explicit Refresh action.
    latest_key = next(reversed(_UI_STATUS_CACHE))
    latest = _UI_STATUS_CACHE[latest_key]
    return UIStatusSnapshot(
        configured_ai_path=str(configured_ai_path or ""),
        status=ExternalStatus(
            auto_rig_pro=latest.status.auto_rig_pro,
            rig_tools=latest.status.rig_tools,
            proxy_picker=latest.status.proxy_picker,
            ai_runtime=AIRuntimeStatus(platform_compatible=sys.platform.startswith("win")),
        ),
        conflicts=latest.conflicts,
        operator_states=latest.operator_states,
        scanned=False,
    )


def refresh_ui_status(
    configured_ai_path: str,
    context: bpy.types.Context | None = None,
) -> UIStatusSnapshot:
    """Refresh the bounded UI snapshot from an explicit activation/action path."""
    configured = str(configured_ai_path or "")
    status = external_status(configured, context)
    snapshot = UIStatusSnapshot(
        configured_ai_path=configured,
        status=status,
        conflicts=tuple(external_conflicts(context, status=status)),
        operator_states=tuple((operator_id, operator_exists(operator_id)) for operator_id in _UI_OPERATOR_IDS),
        scanned=True,
    )
    key = _ui_status_key(configured)
    _UI_STATUS_CACHE[key] = snapshot
    while len(_UI_STATUS_CACHE) > _UI_STATUS_CACHE_LIMIT:
        _UI_STATUS_CACHE.popitem(last=False)
    return snapshot


def clear_ui_status_cache() -> None:
    _UI_STATUS_CACHE.clear()


def _scene_settings(context: bpy.types.Context | None = None):
    try:
        scene = (context or bpy.context).scene
        return getattr(scene, "srs_settings", None)
    except Exception:
        return None


def configured_armature(context: bpy.types.Context | None = None) -> bpy.types.Object | None:
    settings = _scene_settings(context)
    try:
        obj = settings.target_armature if settings is not None else None
    except Exception:
        obj = None
    return obj if obj is not None and obj.type == "ARMATURE" else None


def configured_body_mesh(context: bpy.types.Context | None = None) -> bpy.types.Object | None:
    settings = _scene_settings(context)
    try:
        obj = settings.target_body_mesh if settings is not None else None
    except Exception:
        obj = None
    return obj if obj is not None and obj.type == "MESH" else None


def select_only(
    objects: Iterable[bpy.types.Object],
    active: bpy.types.Object | None = None,
    context: bpy.types.Context | None = None,
) -> None:
    ctx = context or bpy.context
    try:
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode="OBJECT")
    except Exception:
        pass
    for obj in tuple(getattr(ctx, "selected_objects", ())):
        try:
            obj.select_set(False)
        except Exception:
            pass
    selected = [obj for obj in objects if obj is not None]
    for obj in selected:
        try:
            obj.select_set(True)
        except Exception:
            pass
    target = active or (selected[0] if selected else None)
    try:
        ctx.view_layer.objects.active = target
    except Exception:
        try:
            bpy.context.view_layer.objects.active = target
        except Exception:
            pass


def likely_armature(context: bpy.types.Context | None = None) -> bpy.types.Object | None:
    ctx = context or bpy.context
    configured = configured_armature(ctx)
    if configured is not None:
        return configured
    obj = getattr(ctx, "active_object", None)
    if obj is not None and obj.type == "ARMATURE":
        return obj
    for candidate in getattr(ctx, "selected_objects", ()):
        if candidate.type == "ARMATURE":
            return candidate
    priorities = ("rig", "rig_ui", "rig_add", "reference", "metarig")
    for name in priorities:
        candidate = bpy.data.objects.get(name)
        if candidate is not None and candidate.type == "ARMATURE":
            return candidate
    compatible: list[bpy.types.Object] = []
    all_armatures: list[bpy.types.Object] = []
    for candidate in bpy.data.objects:
        if candidate.type != "ARMATURE":
            continue
        all_armatures.append(candidate)
        bone_names = {bone.name for bone in candidate.data.bones}
        if (
            "arp_rig_type" in candidate
            or "arp_rig_name" in candidate
            or candidate.name.lower().startswith(("rig", "reference"))
            or "c_pos" in bone_names
            or "c_root_master.x" in bone_names
        ):
            compatible.append(candidate)
    if compatible:
        compatible.sort(key=lambda obj: (-len(obj.data.bones), obj.name.lower()))
        return compatible[0]
    # An arbitrary armature is unsafe when several unrelated armatures are in
    # the scene (for example separate eye rigs).  A single armature is still a
    # useful fallback, while multiple candidates require explicit selection.
    return all_armatures[0] if len(all_armatures) == 1 else None


def selected_meshes(context: bpy.types.Context | None = None) -> list[bpy.types.Object]:
    ctx = context or bpy.context
    result: list[bpy.types.Object] = []
    configured = configured_body_mesh(ctx)
    if configured is not None:
        result.append(configured)
    for obj in getattr(ctx, "selected_objects", ()):
        if obj.type == "MESH" and obj not in result:
            result.append(obj)
    active = getattr(ctx, "active_object", None)
    if active is not None and active.type == "MESH" and active not in result:
        result.append(active)
    return result


def prepare_body_mesh(context: bpy.types.Context | None = None) -> tuple[bpy.types.Object | None, str]:
    ctx = context or bpy.context
    body = configured_body_mesh(ctx)
    if body is None:
        active = getattr(ctx, "active_object", None)
        if active is not None and active.type == "MESH":
            body = active
    if body is None:
        body = next((obj for obj in getattr(ctx, "selected_objects", ()) if obj.type == "MESH"), None)
    if body is None:
        return None, "No body mesh was found."
    select_only([body], body, ctx)
    return body, ""


def prepare_armature_mode(
    mode: str = "POSE", context: bpy.types.Context | None = None
) -> tuple[bpy.types.Object | None, str]:
    ctx = context or bpy.context
    armature = likely_armature(ctx)
    if armature is None:
        return None, "No armature was found."
    select_only([armature], armature, ctx)
    try:
        if mode and bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode=mode)
        elif mode and armature.mode != mode:
            return armature, f"Could not enter {mode.title()} mode in the current context."
    except Exception:
        return armature, f"Could not enter {mode.title()} mode in the current context."
    if mode and armature.mode != mode:
        return armature, f"The armature did not enter {mode.title()} mode."
    return armature, ""


def prepare_bind_selection(
    context: bpy.types.Context | None = None,
) -> tuple[bpy.types.Object | None, list[bpy.types.Object], str]:
    ctx = context or bpy.context
    # What the user selected is what gets bound. The configured body joins only when
    # nothing is selected: Auto-Rig Pro's bind and unbind replace the weights of every
    # mesh they are given, so adding it silently wiped the body's weights.
    meshes = [obj for obj in getattr(ctx, "selected_objects", ()) if obj.type == "MESH"]
    active = getattr(ctx, "active_object", None)
    if active is not None and active.type == "MESH" and active not in meshes:
        meshes.append(active)
    if not meshes:
        meshes = selected_meshes(ctx)
    armature = likely_armature(ctx)
    if armature is None:
        return None, meshes, "No armature was found."
    if not meshes:
        for obj in bpy.data.objects:
            if obj.type == "MESH" and any(
                modifier.type == "ARMATURE" and modifier.object == armature for modifier in obj.modifiers
            ):
                meshes.append(obj)
    if not meshes:
        return armature, [], "No mesh object is selected, configured, or already bound to the rig."
    select_only([*meshes, armature], armature, ctx)
    return armature, meshes, ""


def marker_names() -> dict[str, tuple[str, ...]]:
    return {
        "required_body": (
            "root_loc",
            "neck_loc",
            "chin_loc",
            "shoulder_loc",
            "hand_loc",
            "foot_loc",
        ),
        "optional_body": (
            "head_tip_loc",
            "hand_tip_loc",
            "elbow_loc",
            "thigh_loc",
            "knee_loc",
        ),
        "fingers": ("hand_tip_loc",),
        "facial": ("chin_loc", "head_tip_loc"),
    }


def missing_markers(kind: str = "required_body") -> list[str]:
    return [name for name in marker_names().get(kind, ()) if bpy.data.objects.get(name) is None]


def text_block_write(name: str, text: str) -> bpy.types.Text:
    block = bpy.data.texts.get(name) or bpy.data.texts.new(name)
    block.clear()
    block.write(text)
    return block


def open_folder(path_value: str) -> tuple[bool, str]:
    root = Path(path_value)
    if not root.is_dir():
        return False, "Folder does not exist."
    try:
        if sys.platform.startswith("win"):
            os.startfile(str(root))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(root)])
        else:
            subprocess.Popen(["xdg-open", str(root)])
        return True, ""
    except Exception:
        return False, "Could not open folder."


def dump_json(path: str, payload: Any) -> tuple[bool, str]:
    try:
        output = Path(bpy.path.abspath(path)).expanduser()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return True, str(output)
    except Exception:
        return False, "Could not write JSON. Check the output path."
