# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Eye reference placement for externally installed Auto-Rig Pro rigs.

Auto-Rig Pro derives the whole eye rig from a single reference bone per side,
``eye_offset_ref.l`` / ``eye_offset_ref.r``:

    head              the eyeball's rotation pivot
    head -> tail      the gaze direction; it decides where ``c_eye_target`` is placed
    length            the Eye Spec distance; ``c_eye_ref`` lands at length x 2 in front

Auto-Rig Pro's marker estimation does not place that bone, so it is always positioned
by hand, and three mistakes are common enough to be worth designing out:

    1. the tail ends up pointing backwards, which puts ``c_eye_target`` behind the head
    2. the head does not sit on the eyeball's rotation centre, so the eye leaves its socket
    3. world coordinates are typed in while the rig object's scale is not 1.0

This module removes all three by deriving every value from the eyeball objects at run
time and converting through the armature's own matrix, so the result does not depend on
the rig's object scale.

No Auto-Rig Pro code is imported or re-registered here; only its bone naming is relied on.
"""

import bpy
from mathutils import Vector

from . import bind_common

# Auto-Rig Pro bone names this module relies on.
REF_FMT = "eye_offset_ref{side}"
CTRL_EYE_FMT = "c_eye{side}"
CTRL_SPEC_FMT = "c_eye_ref{side}"
CTRL_TARGET_X = "c_eye_target.x"

PIVOT_ORIGIN = "ORIGIN"
PIVOT_BBOX = "BBOX_CENTER"

# Reference bones consulted, in order, when guessing which way the face points.
_FORWARD_HINT_BONES = ("nose_03_ref.x", "nose_01_ref.x", "jaw_ref.x", "chin_01_ref.x")

_SIDES = (".l", ".r")


def _pivot_world(eye_object, pivot_source):
    """World-space rotation pivot taken from an eyeball object."""
    if pivot_source == PIVOT_BBOX:
        coords = [eye_object.matrix_world @ vertex.co for vertex in eye_object.data.vertices]
        if not coords:
            return None
        return Vector((
            (min(c.x for c in coords) + max(c.x for c in coords)) * 0.5,
            (min(c.y for c in coords) + max(c.y for c in coords)) * 0.5,
            (min(c.z for c in coords) + max(c.z for c in coords)) * 0.5,
        ))
    return eye_object.matrix_world.translation.copy()


def guess_forward(armature):
    """World-space unit vector for the direction the face looks, or None.

    Taken from the facial reference bones rather than from any global assumption, so a
    character built facing +Y is handled the same as one facing -Y. The vertical
    component is discarded because a nose bone usually slopes downward.
    """
    if armature is None or armature.type != "ARMATURE":
        return None
    rotation = armature.matrix_world.to_3x3()
    for name in _FORWARD_HINT_BONES:
        bone = armature.data.bones.get(name)
        if bone is None:
            continue
        direction = rotation @ (bone.tail_local - bone.head_local)
        direction.z = 0.0
        if direction.length > 1e-6:
            return direction.normalized()
    return None


def _reach_to_surface(eye_object, pivot_world, forward):
    """Distance from the pivot to the frontmost vertex of the eyeball, along forward."""
    reach = 0.0
    matrix = eye_object.matrix_world
    for vertex in eye_object.data.vertices:
        distance = (matrix @ vertex.co - pivot_world).dot(forward)
        if distance > reach:
            reach = distance
    return reach


def resolve_eye_objects(context, settings):
    """Return (eye_l, eye_r, error). Explicit settings win; otherwise nothing is guessed."""
    eye_l = getattr(settings, "eye_object_l", None)
    eye_r = getattr(settings, "eye_object_r", None)
    for candidate in (eye_l, eye_r):
        if candidate is not None and candidate.type != "MESH":
            return None, None, "Eye objects must be meshes."
    if eye_l is None and eye_r is None:
        return None, None, "Select at least one eyeball object first."
    return eye_l, eye_r, ""


def snap_eye_references(armature, eye_l, eye_r=None, pivot_source=PIVOT_ORIGIN,
                        forward=None, spec_distance_factor=1.0):
    """Place ``eye_offset_ref.l`` / ``.r`` from the eyeball objects.

    Returns (applied, error). ``applied`` maps bone name to the values written.
    The caller is responsible for putting the armature into Edit Mode and for running
    Auto-Rig Pro's match-to-rig afterwards.
    """
    if armature is None or armature.type != "ARMATURE":
        return {}, "Select the Auto-Rig Pro rig armature first."
    if armature.mode != "EDIT":
        return {}, "The armature must be in Edit Mode."

    if forward is None:
        forward = guess_forward(armature)
        if forward is None:
            return {}, "Could not determine which way the face points from the reference bones."
    forward = Vector(forward)
    if forward.length <= 1e-6:
        return {}, "The forward direction is zero length."
    forward = forward.normalized()

    try:
        factor = float(spec_distance_factor)
    except (TypeError, ValueError):
        factor = 1.0
    if factor <= 0.0:
        factor = 1.0

    pairs = [(side, eye) for side, eye in zip(_SIDES, (eye_l, eye_r)) if eye is not None]
    if not pairs:
        return {}, "No eyeball object was supplied."

    matrix = armature.matrix_world
    inverse = matrix.inverted()
    applied = {}
    for side, eye_object in pairs:
        name = REF_FMT.format(side=side)
        edit_bone = armature.data.edit_bones.get(name)
        if edit_bone is None:
            return applied, (
                f"{name} was not found. Enable Facial in the external Limb Options first."
            )
        pivot = _pivot_world(eye_object, pivot_source)
        if pivot is None:
            return applied, f"{eye_object.name} has no vertices."
        reach = _reach_to_surface(eye_object, pivot, forward)
        if reach <= 1e-6:
            return applied, (
                f"{eye_object.name} has no depth along the facing direction; "
                "the forward direction is probably reversed."
            )
        length = reach * factor

        # Assembled in world space and converted back through the armature matrix, so the
        # rig object's scale never leaks into the typed-in numbers.
        edit_bone.head = inverse @ pivot
        edit_bone.tail = inverse @ (pivot + forward * length)
        edit_bone.roll = 0.0

        applied[name] = {
            "eye_object": eye_object.name,
            "pivot_source": pivot_source,
            "head_world": tuple(round(v, 6) for v in pivot),
            "length_world": round(length, 6),
            "spec_distance_world": round(length * 2.0, 6),
        }
    return applied, ""


# How far a pinned seam may drift before it counts as coming apart. The reference
# bind holds it to 0.0000mm, so anything above a rounding wobble means the rim is
# following something the face is not.
SEAM_TOLERANCE_MM = 0.01


def eye_side_by_measurement(armature, eye_object):
    """Which of ``c_eye.l`` / ``c_eye.r`` this eyeball belongs to, by position.

    Never by the object's own ``_L`` / ``_R`` suffix. On the reference character
    two other left/right pairs are named the opposite way round from Auto-Rig
    Pro's ``.l`` / ``.r``, and a swapped eye crosses the character's gaze the
    moment the look-at controls move while every weight and modifier check still
    passes. The mistake is invisible at rest, so the side comes from geometry:
    whichever eye control the eyeball actually sits at.
    """
    if armature is None or eye_object is None:
        return "", "Need both an armature and an eyeball"
    matrix = armature.matrix_world
    centre = eye_object.matrix_world.translation
    best = ""
    best_distance = None
    for side in _SIDES:
        bone = armature.data.bones.get(CTRL_EYE_FMT.format(side=side))
        if bone is None:
            continue
        distance = ((matrix @ bone.head_local) - centre).length
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best = side
    if not best:
        return "", "Neither %s nor %s exists on %s" % (
            CTRL_EYE_FMT.format(side=".l"), CTRL_EYE_FMT.format(side=".r"),
            armature.name)
    return best, ""


def boundary_rings(mesh_object):
    """The mesh's open boundary loops, as lists of vertex indices."""
    import bmesh

    bm = bmesh.new()
    try:
        bm.from_mesh(mesh_object.data)
        bm.verts.ensure_lookup_table()
        on_edge = {v.index for v in bm.verts if v.is_boundary}
        seen = set()
        rings = []
        for index in sorted(on_edge):
            if index in seen:
                continue
            stack = [index]
            seen.add(index)
            ring = []
            while stack:
                current = stack.pop()
                ring.append(current)
                for edge in bm.verts[current].link_edges:
                    other = edge.other_vert(bm.verts[current]).index
                    if other in on_edge and other not in seen:
                        seen.add(other)
                        stack.append(other)
            rings.append(sorted(ring))
        return rings
    finally:
        bm.free()


def eye_regions(eye_object, donor, socket_ring_size=0):
    """Split an eyeball into the rim that pins to the lid and the part that looks.

    Returns ``(regions, error)``.

    This character's eyeballs are not rigid spheres and must not be bound as
    though they were. Each is 218 vertices in two islands with two open boundary
    rings of 24, and the two rings belong to different jobs: one sits in the
    face's eye hole and has to travel with the lid margin, the other rotates with
    the gaze. Measured, the rim ring lies 0.463mm from the face's own 24-vertex
    socket loop (0.35 to 0.59mm) while the other ring is 3.681mm away and eight
    times more scattered, so the two are told apart by how closely they follow
    the face rather than by index or island order.

    Weighting every vertex to the eye control -- the obvious reading of "an
    eyeball is rigid" -- would drag the rim out of the socket every time the
    character looked sideways.
    """
    if eye_object is None or eye_object.type != "MESH":
        return None, "The eyeball is not a mesh"
    if donor is None or donor.type != "MESH":
        return None, ("The face mesh is needed to find the eye socket, because "
                      "the rim is identified by how closely it follows the face")
    rings = boundary_rings(eye_object)
    if len(rings) < 2:
        return None, ("%s has %d open boundary ring(s). This eyeball is expected "
                      "to have two -- a rim that pins to the lid and a ring that "
                      "follows the gaze -- so it is not the construction this "
                      "handles" % (eye_object.name, len(rings)))

    donor_rings = [r for r in boundary_rings(donor)
                   if not socket_ring_size or len(r) == socket_ring_size]
    if not donor_rings:
        return None, "%s has no open boundary loop to use as an eye socket" % donor.name

    dm = donor.matrix_world
    em = eye_object.matrix_world
    donor_points = []
    for ring in donor_rings:
        donor_points.append([(dm @ donor.data.vertices[i].co, i) for i in ring])

    scored = []
    for ring in rings:
        points = [em @ eye_object.data.vertices[i].co for i in ring]
        best = None
        for candidates in donor_points:
            distances = sorted(min((p - q).length for q, _ in candidates)
                               for p in points)
            median = distances[len(distances) // 2]
            if best is None or median < best[0]:
                best = (median, candidates)
        scored.append({"ring": ring, "median": best[0], "donor": best[1]})
    scored.sort(key=lambda r: r["median"])

    rim = scored[0]
    other = scored[1]
    # Refuse a coin toss. If the rim is not clearly the closer of the two, the
    # split is guesswork and a wrong guess pins the pupil to the lid.
    if rim["median"] > 0.0 and other["median"] < rim["median"] * 2.0:
        return None, (
            "The two boundary rings of %s are %.3fmm and %.3fmm from the face's "
            "socket, which is too close to call. The rim has to be unmistakably "
            "the nearer one -- on the reference character the figures are 0.463mm "
            "and 3.681mm" % (eye_object.name, rim["median"] * 1000.0, other["median"] * 1000.0))

    rim_set = set(rim["ring"])
    gaze = [v.index for v in eye_object.data.vertices if v.index not in rim_set]
    # Each rim vertex keeps the donor vertex it pins to, so the weights can be
    # copied across verbatim later -- the only way the two surfaces cannot part.
    pins = {}
    for index in rim["ring"]:
        point = em @ eye_object.data.vertices[index].co
        nearest = min(rim["donor"], key=lambda pair: (point - pair[0]).length)
        pins[index] = {"donor_vertex": nearest[1],
                       "distance_mm": round((point - nearest[0]).length * 1000, 4)}
    return {
        "rim": sorted(rim["ring"]),
        "rim_median_mm": round(rim["median"] * 1000, 3),
        "gaze": gaze,
        "gaze_ring_median_mm": round(other["median"] * 1000, 3),
        "pins": pins,
        "separation_ratio": round(other["median"] / rim["median"], 2)
        if rim["median"] > 0 else None,
    }, ""


def bind_eyes(armature, eye_l, eye_r=None, donor=None, preserve=True):
    """Bind the eyeballs: pupil to the gaze control, rim to the lid. ``(report, error)``.

    The gaze bone is ``c_eye.<side>`` and nothing else. Measured on this rig,
    offsetting ``c_eye_target.l`` by 40mm rotates ``c_eye.l`` by 5.49 degrees and
    moves the eyeball 2.37mm, while ``c_eye_offset.l``, ``c_eye_ref_track.l`` and
    ``head.x`` all rotate exactly 0.0000 degrees. An eyeball weighted to the
    offset bone is completely inert to the look-at controls -- and because
    ``c_eye`` and ``c_eye_offset`` share head and tail position to the micron
    here, no amount of measuring where a bone sits can tell them apart.
    ``c_eye_ref`` is worse than inert: ``use_deform`` is off, so weights there are
    discarded in silence.

    The rim does not get a bone. It gets the weights of the face vertex it sits
    on, copied across, so the eye's edge and the lid margin move as one surface
    and cannot part on a blink. That requires the face to be bound already; this
    refuses rather than write a bind that tears, because a pupil bound without
    its rim looks right at rest and splits open on the first glance sideways.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    eyes = [eye for eye in (eye_l, eye_r) if eye is not None]
    if not eyes:
        return None, "No eyeball object was given."
    if donor is None:
        return None, ("The face mesh is required: the eyeball rim is pinned to "
                      "the face's eye socket, not to a bone.")
    donor_bones = bind_common.deform_bone_names(donor)
    if not donor_bones or not len(donor.vertex_groups):
        return None, (
            "%s carries no weights yet, so there is nothing for the eyeball rim "
            "to follow. Bind the face first, then the eyes -- in that order. "
            "Binding the pupil on its own would leave the rim behind and tear "
            "the eye open the first time the character looks sideways."
            % donor.name)

    # Everything is validated before anything is written. A half-applied eye bind
    # is worse than none: it looks correct at rest.
    planned = []
    sides_used = []
    for eye_object in eyes:
        if eye_object.type != "MESH":
            return None, "%s is not a mesh." % eye_object.name
        side, error = eye_side_by_measurement(armature, eye_object)
        if error:
            return None, error
        bone = CTRL_EYE_FMT.format(side=side)
        target = armature.data.bones.get(bone)
        if target is None:
            return None, "%s has no bone called %s." % (armature.name, bone)
        if not target.use_deform:
            return None, ("%s has use_deform switched off, so weights there "
                          "would be ignored." % bone)
        if side in sides_used:
            return None, ("Both eyeballs measure closest to %s, so one of them "
                          "is out of place. Binding both would cross the gaze."
                          % bone)
        sides_used.append(side)
        regions, error = eye_regions(eye_object, donor)
        if error:
            return None, error
        planned.append((eye_object, side, bone, regions))

    report = {"armature": armature.name, "donor": donor.name, "eyes": []}
    for eye_object, side, bone, regions in planned:
        before = sorted(group.name for group in eye_object.vertex_groups)
        for group in list(eye_object.vertex_groups):
            if not group.lock_weight:
                eye_object.vertex_groups.remove(group)

        # The part that looks.
        gaze_group = eye_object.vertex_groups.new(name=bone)
        gaze_group.add(regions["gaze"], 1.0, "REPLACE")

        # The rim, taking the face's own weights vertex by vertex.
        copied = {}
        for index, pin in regions["pins"].items():
            donor_vertex = donor.data.vertices[pin["donor_vertex"]]
            for entry in donor_vertex.groups:
                name = donor.vertex_groups[entry.group].name
                if entry.weight <= 0.0:
                    continue
                group = (eye_object.vertex_groups.get(name)
                         or eye_object.vertex_groups.new(name=name))
                group.add([index], entry.weight, "REPLACE")
                copied[name] = copied.get(name, 0) + 1

        stack = bind_common.ensure_modifier_pair(eye_object, armature,
                                                 preserve=preserve)
        bind_common.parent_to_rig(eye_object, armature)
        unfollowed = sorted(
            index for index in regions["rim"]
            if not any(entry.weight > 0.0
                       for entry in eye_object.data.vertices[index].groups))
        report["eyes"].append({
            "object": eye_object.name,
            "gaze_bone": bone,
            "gaze_vertices": len(regions["gaze"]),
            "gaze_weighted": bind_common.weighted_vertex_count(eye_object, bone),
            "rim_vertices": len(regions["rim"]),
            "rim_median_mm": regions["rim_median_mm"],
            "separation_ratio": regions["separation_ratio"],
            "rim_bones": sorted(copied),
            "rim_unfollowed": unfollowed,
            "groups_removed": [n for n in before if n != bone],
            "groups_now": sorted(g.name for g in eye_object.vertex_groups),
            "stack": stack.get("stack", []),
            "additive_present": stack.get("additive", False),
            "parent": eye_object.parent.name if eye_object.parent else "",
        })
        if unfollowed:
            return report, ("%d rim vertices of %s found no weight on the face "
                            "vertex they pin to, so they would be left behind."
                            % (len(unfollowed), eye_object.name))
    return report, ""


def verify_eyes(armature, eye_l, eye_r=None, donor=None,
                offset_mm=(40.0, 0.0, 20.0)):
    """Prove the eyes do what was asked. Returns ``(report, error)``.

    Structure is not proof: the groups can be right, the modifiers can be right,
    and the eye can still hang off a bone nothing drives -- which measures exactly
    0.000mm and is indistinguishable from a correct rig at rest. So this poses the
    look-at control and measures both halves separately, because this eyeball has
    two jobs and the requirement is that they differ: the pupil must follow the
    gaze and the rim must NOT.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    rows = []
    issues = []
    for eye_object in (eye for eye in (eye_l, eye_r) if eye is not None):
        side, error = eye_side_by_measurement(armature, eye_object)
        if error:
            return None, error
        bone = CTRL_EYE_FMT.format(side=side)
        target = "c_eye_target" + side
        row = {"object": eye_object.name, "gaze_bone": bone, "target": target,
               "groups": sorted(g.name for g in eye_object.vertex_groups),
               "stack": [m.name for m in eye_object.modifiers]}

        regions = None
        if donor is not None:
            regions, region_error = eye_regions(eye_object, donor)
            if region_error:
                issues.append("%s: %s" % (eye_object.name, region_error))

        row["gaze_weighted"] = bind_common.weighted_vertex_count(eye_object, bone)
        if regions:
            row["gaze_vertices"] = len(regions["gaze"])
            row["rim_vertices"] = len(regions["rim"])
            gaze_moved, gaze_error = bind_common.displacement_under_pose(
                eye_object, armature, target, offset=offset_mm,
                indices=regions["gaze"], armature_only=True)
            rim_moved, rim_error = bind_common.displacement_under_pose(
                eye_object, armature, target, offset=offset_mm,
                indices=regions["rim"], armature_only=True)
            seam, seam_error = bind_common.pin_gap_change(
                eye_object, donor, regions["pins"], armature, target,
                offset=offset_mm)
            row["gaze_moved_mm"] = gaze_moved
            row["rim_moved_mm"] = rim_moved
            row["seam"] = seam
            row["error"] = gaze_error or rim_error or seam_error
            if gaze_error or rim_error or seam_error:
                issues.append("%s: %s" % (eye_object.name,
                                          gaze_error or rim_error or seam_error))
            else:
                if not gaze_moved:
                    issues.append(
                        "%s: the pupil does not move at all when %s is posed. "
                        "That zero is the signature of the wrong bone, and it "
                        "looks correct at rest." % (eye_object.name, target))
                # The rim is judged against the FACE, not against zero. The socket
                # itself travels a little when the rig moves -- measured, the
                # face's own rim shifts 0.139mm under this pose while carrying no
                # weight from any eye bone -- so an absolute threshold would
                # reject a correct bind. What must not change is the seam.
                if seam and seam["change_max_mm"] > SEAM_TOLERANCE_MM:
                    issues.append(
                        "%s: the seam with %s opens by %.4fmm when %s is posed "
                        "(the rim moved %.4fmm, and it should be moving with the "
                        "face). The rim is pinned to the socket and has to travel "
                        "with it."
                        % (eye_object.name, donor.name, seam["change_max_mm"],
                           target, rim_moved or 0.0))
            if row["gaze_weighted"] != len(regions["gaze"]):
                issues.append(
                    "%s: %d of %d pupil vertices carry weight in %s."
                    % (eye_object.name, row["gaze_weighted"],
                       len(regions["gaze"]), bone))
            stranded = sorted(
                index for index in regions["rim"]
                if not any(e.weight > 0.0
                           for e in eye_object.data.vertices[index].groups))
            row["rim_unfollowed"] = stranded
            if stranded:
                issues.append("%s: %d rim vertices carry no weight at all, so "
                              "they stay behind when the head moves."
                              % (eye_object.name, len(stranded)))
        armature_mods = [m.name for m in eye_object.modifiers
                         if m.type == "ARMATURE"]
        if bind_common.PAIR_ADDITIVE not in armature_mods:
            issues.append("%s has no additive armature modifier, so it is deaf "
                          "to every bend bone." % eye_object.name)
        offered = bind_common.deform_bone_names(eye_object)
        if bone not in offered:
            issues.append("%s is weighted to %s but no armature modifier on it "
                          "offers that bone as a deform bone."
                          % (eye_object.name, bone))
        rows.append(row)
    return {"eyes": rows, "issues": issues, "ok": not issues}, ""


# The bones that actually rotate to close a lid, and the bone whose head they
# should share. Auto-Rig Pro's own chain is what names them: c_eyelid_top.<side>
# is the elliptical control the animator moves, a Transform constraint on
# eyelid_top.<side> maps that control's LOCATION to eyelid_top's ROTATION, and the
# three deform bones hang off eyelid_top as children. So eyelid_top's head is the
# pivot the lid sweeps about.
LID_ROTATORS = ("eyelid_top", "eyelid_bot")
LID_BASES = ("eyelid_base_top", "eyelid_base_bot")


def lid_pivot_report(armature):
    """How far each lid's rotation pivot sits from the eye pivot. ``(report, error)``.

    Auto-Rig Pro places eyelid_base_top/bot exactly on the eye control's head and
    then places eyelid_top/bot, which are the bones that actually rotate,
    somewhere else. On the reference character the bases measured 0.000mm from the
    eye pivot while the rotators measured 24.016mm, and the consequence is not
    subtle: pulling the top-lid control to the end of its useful range closed the
    eye only 48.9 per cent. It cannot shut. With the rotators moved onto the eye
    pivot the same pull closes it 103.7 per cent, and the rest pose is unchanged to
    within a micron.

    Nothing here writes. Run it before and after a correction.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    bones = armature.data.bones
    matrix = armature.matrix_world
    rows = []
    for side in _SIDES:
        eye = bones.get(CTRL_EYE_FMT.format(side=side))
        if eye is None:
            continue
        pivot = matrix @ eye.head_local
        entry = {"side": side, "eye_bone": eye.name,
                 "eye_pivot_mm": [round(c * 1000, 3) for c in pivot],
                 "rotators": [], "bases": []}
        for stem in LID_ROTATORS:
            bone = bones.get(stem + side)
            if bone is None:
                continue
            head = matrix @ bone.head_local
            entry["rotators"].append({
                "bone": bone.name,
                "head_mm": [round(c * 1000, 3) for c in head],
                "offset_mm": round((head - pivot).length * 1000, 3)})
        for stem in LID_BASES:
            bone = bones.get(stem + side)
            if bone is None:
                continue
            head = matrix @ bone.head_local
            entry["bases"].append({
                "bone": bone.name,
                "offset_mm": round((head - pivot).length * 1000, 3)})
        rows.append(entry)
    if not rows:
        return None, ("No eye control was found, so this armature has no Auto-Rig "
                      "Pro eye rig to inspect.")
    worst = max((r["offset_mm"] for row in rows for r in row["rotators"]),
                default=0.0)
    return {"sides": rows, "worst_offset_mm": worst,
            "needs_fix": worst > LID_PIVOT_TOLERANCE_MM}, ""


# How far a lid rotator may sit from the eye pivot before the lid stops being able
# to shut. Auto-Rig Pro puts the bases at exactly 0.000mm, so anything beyond a
# rounding wobble is a placement fault rather than a design choice.
LID_PIVOT_TOLERANCE_MM = 0.5


def fix_lid_pivot(armature, tolerance_mm=LID_PIVOT_TOLERANCE_MM):
    """Move each lid rotator's head onto the eye pivot. ``(report, error)``.

    The tail is left alone, so the bone becomes a radius of the eye and the lid
    sweeps across the eyeball instead of swinging away from it.

    This is safe on a rig that is already bound: eyelid_top and eyelid_bot are
    NOT deform bones, so no vertex group refers to them and no weight changes --
    verified by comparing every lid group's vertex count and weight sum across the
    edit, which came out bit-identical. The rest pose does not move either, since
    the deform children keep their own head and tail.

    It is a patch, not a cure. Auto-Rig Pro regenerates these bones from its
    reference bones, so anything that re-derives the rig -- Match to Rig, a facial
    re-setup -- puts the fault back and this has to be run again. The report says
    so, and the audit will catch it.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    before, error = lid_pivot_report(armature)
    if error:
        return None, error

    context_object = bpy.context.object
    previous_mode = context_object.mode if context_object else "OBJECT"
    previous_active = bpy.context.view_layer.objects.active
    moved = []
    try:
        if context_object is not None and context_object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode="EDIT")
        edit_bones = armature.data.edit_bones
        for side in _SIDES:
            eye = edit_bones.get(CTRL_EYE_FMT.format(side=side))
            if eye is None:
                continue
            target = eye.head.copy()
            for stem in LID_ROTATORS:
                bone = edit_bones.get(stem + side)
                if bone is None:
                    continue
                offset = (bone.head - target).length
                if offset * 1000.0 <= tolerance_mm:
                    continue
                previous = bone.head.copy()
                bone.head = target
                moved.append({
                    "bone": bone.name,
                    "moved_mm": round(offset * 1000, 3),
                    "head_before_mm": [round(c * 1000, 3) for c in previous],
                    "head_after_mm": [round(c * 1000, 3) for c in bone.head],
                    "length_mm": round((bone.tail - bone.head).length * 1000, 3)})
    finally:
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        bpy.context.view_layer.objects.active = previous_active
        if previous_active is not None and previous_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=previous_mode)
            except RuntimeError:
                pass

    after, error = lid_pivot_report(armature)
    if error:
        return None, error
    return {"moved": moved,
            "worst_offset_before_mm": before["worst_offset_mm"],
            "worst_offset_after_mm": after["worst_offset_mm"],
            "note": ("Auto-Rig Pro regenerates these bones from its reference "
                     "bones, so Match to Rig or a facial re-setup will put the "
                     "fault back and this has to be run again.")}, ""


def measure_aperture(armature, face_object, pull_mm=16.0, steps=4):
    """How far the eye actually shuts when the top-lid control is pulled.

    Returns ``(report, error)``.

    This is the only criterion that settles whether a lid works, and two more
    obvious ones do not. Measuring the socket rim's distance from the eye pivot is
    circular -- a rim rotating about any point keeps a constant distance from that
    same point. Measuring the gap between the socket rim and the eyeball surface is
    no better here, because the eyeball's rim is weighted to follow the socket, so
    that gap is built to be constant and stays constant however badly the lid
    swings. What discriminates is the aperture: the vertical distance between the
    upper and lower halves of the socket ring, as a percentage of its resting
    height. A lid that cannot reach 100 per cent cannot shut.
    """
    import bmesh

    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    if face_object is None or face_object.type != "MESH":
        return None, "The face mesh is needed: the aperture is its socket ring."

    matrix = armature.matrix_world
    mesh_matrix = face_object.matrix_world

    bm = bmesh.new()
    try:
        bm.from_mesh(face_object.data)
        bm.verts.ensure_lookup_table()
        on_edge = {v.index for v in bm.verts if v.is_boundary}
        seen = set()
        rings = []
        for index in sorted(on_edge):
            if index in seen:
                continue
            stack = [index]
            seen.add(index)
            ring = []
            while stack:
                current = stack.pop()
                ring.append(current)
                for edge in bm.verts[current].link_edges:
                    other = edge.other_vert(bm.verts[current]).index
                    if other in on_edge and other not in seen:
                        seen.add(other)
                        stack.append(other)
            rings.append(sorted(ring))
    finally:
        bm.free()

    hidden = [m for m in face_object.modifiers
              if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    if hidden:
        bpy.context.view_layer.update()

    rows = []
    try:
        for side in _SIDES:
            eye = armature.data.bones.get(CTRL_EYE_FMT.format(side=side))
            control = armature.pose.bones.get("c_eyelid_top" + side)
            if eye is None or control is None:
                continue
            pivot = matrix @ eye.head_local
            best = None
            for ring in rings:
                centre = sum((mesh_matrix @ face_object.data.vertices[i].co
                              for i in ring), Vector()) / len(ring)
                distance = (centre - pivot).length
                if best is None or distance < best[0]:
                    best = (distance, ring)
            if best is None:
                continue
            ring = best[1]
            heights = {i: (mesh_matrix @ face_object.data.vertices[i].co).z
                       for i in ring}
            middle = sorted(heights.values())[len(heights) // 2]
            upper = [i for i in ring if heights[i] >= middle]
            lower = [i for i in ring if heights[i] < middle]

            saved = tuple(control.location)
            samples = []
            try:
                for step in range(steps + 1):
                    pull = -abs(pull_mm) * step / max(1, steps)
                    control.location = (0.0, 0.0, pull * 0.001)
                    bpy.context.view_layer.update()
                    depsgraph = bpy.context.evaluated_depsgraph_get()
                    evaluated = face_object.evaluated_get(depsgraph)
                    verts = evaluated.data.vertices
                    up = [(mesh_matrix @ verts[i].co).z for i in upper
                          if i < len(verts)]
                    low = [(mesh_matrix @ verts[i].co).z for i in lower
                           if i < len(verts)]
                    if not up or not low:
                        continue
                    samples.append({
                        "pull_mm": round(pull, 3),
                        "aperture_mm": round((sum(up) / len(up)
                                              - sum(low) / len(low)) * 1000, 3)})
            finally:
                control.location = saved
                bpy.context.view_layer.update()
            if not samples:
                continue
            rest = samples[0]["aperture_mm"]
            for sample in samples:
                sample["closed_pct"] = round(
                    100.0 * (rest - sample["aperture_mm"]) / rest, 2) if rest else None
            rows.append({"side": side, "ring": len(ring),
                         "rest_aperture_mm": rest, "samples": samples,
                         "closed_pct_at_full_pull": samples[-1]["closed_pct"]})
    finally:
        for modifier in hidden:
            modifier.show_viewport = True
        bpy.context.view_layer.update()

    if not rows:
        return None, "No eye socket ring could be measured on " + face_object.name
    return {"sides": rows,
            "worst_closed_pct": min(r["closed_pct_at_full_pull"] for r in rows),
            "ok": all((r["closed_pct_at_full_pull"] or 0) >= 100.0
                      for r in rows)}, ""



def lid_transform_constraints(armature):
    """The Transformation constraints that turn lid-control motion into rotation."""
    out = []
    if armature is None or armature.type != "ARMATURE":
        return out
    for stem in LID_ROTATORS:
        for side in _SIDES:
            pose_bone = armature.pose.bones.get(stem + side)
            if pose_bone is None:
                continue
            for constraint in pose_bone.constraints:
                if (constraint.type == "TRANSFORM"
                        and getattr(constraint, "map_from", "") == "LOCATION"
                        and getattr(constraint, "map_to", "") == "ROTATION"):
                    out.append((pose_bone, constraint))
    return out


def tune_lid_range(armature, close_at_mm=8.0):
    """Make the lid controls stop at closed instead of running past it.

    Returns ``(report, error)``.

    Auto-Rig Pro maps the control's travel to lid rotation linearly and leaves
    ``use_motion_extrapolate`` on, so the mapping never saturates: measured on
    this character the eye is shut at 8mm of drag, 125 per cent closed at 10mm and
    150 per cent at 12mm, with the two margins driving 15.6mm past each other. The
    shape does not break because the weights are wrong; it breaks because nothing
    stops the control.

    So the mapped range is compressed to end exactly where the eye shuts, keeping
    the same slope up to that point -- the feel of the control is unchanged over
    its useful travel -- and extrapolation is switched off so dragging further
    does nothing. The range is made symmetric about zero, because the control
    closes by moving in NEGATIVE local Z: a range of [0, target] would clamp every
    closing input to zero and the eye would stop closing altogether. No weight and
    no bone is touched.

    Like the pivot correction this is a patch: Auto-Rig Pro rewrites the gain from
    the bone's length on every Match to Rig, so it has to be applied again after.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    target = abs(float(close_at_mm)) * 0.001
    if target <= 0.0:
        return None, "The closing distance must be greater than zero"
    pairs = lid_transform_constraints(armature)
    if not pairs:
        return None, ("No lid Transformation constraint was found, so there is "
                      "no mapping to tune")
    rows = []
    for pose_bone, constraint in pairs:
        span = float(getattr(constraint, "from_max_z", 0.0))
        if span <= 0.0:
            rows.append({"bone": pose_bone.name, "skipped": "from_max_z is zero"})
            continue
        # The control CLOSES by moving in negative local Z, so the mapped range
        # has to straddle zero. Setting it to [0, target] instead clamps every
        # closing input to zero the moment extrapolation is switched off, which
        # measured as the eye closing 44 per cent instead of 100.
        slope = float(constraint.to_max_x_rot) / span
        before = {
            "from_min_z": round(float(constraint.from_min_z), 6),
            "from_max_z": round(span, 6),
            "to_min_x_rot": round(float(constraint.to_min_x_rot), 6),
            "to_max_x_rot": round(float(constraint.to_max_x_rot), 6),
            "extrapolate": bool(constraint.use_motion_extrapolate)}
        constraint.from_min_z = -target
        constraint.from_max_z = target
        constraint.to_min_x_rot = -slope * target
        constraint.to_max_x_rot = slope * target
        constraint.use_motion_extrapolate = False
        rows.append({
            "bone": pose_bone.name, "before": before,
            "after": {"from_min_z": round(float(constraint.from_min_z), 6),
                      "from_max_z": round(float(constraint.from_max_z), 6),
                      "to_min_x_rot": round(float(constraint.to_min_x_rot), 6),
                      "to_max_x_rot": round(float(constraint.to_max_x_rot), 6),
                      "extrapolate": bool(constraint.use_motion_extrapolate)},
            "slope_per_metre": round(slope, 4)})
    return {"close_at_mm": close_at_mm, "constraints": rows,
            "note": ("Auto-Rig Pro recomputes this gain from the bone length on "
                     "every Match to Rig, so re-apply it afterwards.")}, ""


def blink_pose_readiness(armature, face_object, side=".l", level="top",
                         pull_mm=16.0):
    """Check what Auto-Rig Pro's Add Blink Pose needs, and pose the lid for it.

    Returns ``(report, error)``.

    Auto-Rig Pro's own remedy for a lid whose shape does not come out right is a
    blink pose: "A blink pose can be added to blend eyelids into a predefined
    closed pose. This allows better eyelids contact, shape, in case the default
    rotation doesn't fit." It is the right answer to what is left here -- measured,
    the upper lash holds its distance to the lid to 0.54mm through a gentle close
    and only drifts to 5.71mm at full closure, which is a linear-skinning fold, not
    a weight error.

    It is also inherently a hands-on step. ``arp.add_blink_pose`` does all of its
    setup in ``invoke``, which a script never reaches, and it then opens a dialog;
    so this prepares the state and hands over rather than pretending to automate
    it. What it checks is what ARP does not: that the lid can actually reach a
    closed pose at all, that the pivot is not the fault first, and that a blink
    action is not already in place.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Select the Auto-Rig Pro rig armature first."
    if level not in ("top", "bot"):
        return None, "level must be 'top' or 'bot'"
    control_name = "c_eyelid_%s%s" % (level, side)
    control = armature.pose.bones.get(control_name)
    if control is None:
        return None, "%s has no bone called %s" % (armature.name, control_name)

    report = {"control": control_name, "blockers": [], "notes": []}

    pivot, error = lid_pivot_report(armature)
    if error:
        report["blockers"].append(error)
    elif pivot.get("needs_fix"):
        report["blockers"].append(
            "The lid pivot is %.3fmm off the eye centre. Fix that first -- a blink "
            "pose authored against a wrong arc has to be redone afterwards."
            % pivot["worst_offset_mm"])
    report["lid_pivot_worst_mm"] = None if error else pivot["worst_offset_mm"]

    if face_object is not None:
        aperture, error = measure_aperture(armature, face_object,
                                           pull_mm=pull_mm)
        report["closed_pct"] = None if error else aperture["worst_closed_pct"]
        if error:
            report["blockers"].append(error)
        elif not aperture["ok"]:
            report["blockers"].append(
                "The eye only closes %.1f%% at %.0fmm of pull, so there is no "
                "closed pose to capture yet."
                % (aperture["worst_closed_pct"] or 0.0, pull_mm))
    else:
        report["notes"].append(
            "No face mesh was given, so closure could not be confirmed.")

    existing = [a.name for a in bpy.data.actions if "rig_blink_" in a.name]
    report["existing_blink_actions"] = existing
    if existing:
        report["notes"].append(
            "A blink action already exists (%s). Adding another as an in-between "
            "is fine; replacing it is not, and ARP will not warn you."
            % ", ".join(existing))

    if report["blockers"]:
        return report, "; ".join(report["blockers"])

    # Put the rig in the state ARP's operator expects, then stop.
    view = bpy.context.view_layer
    try:
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view.objects.active = armature
        bpy.ops.object.mode_set(mode="POSE")
        # Selection lives on the POSE bone, not on the Bone: on this build
        # Bone has no `select` at all and writing it raises. Confirmed against
        # the installed API rather than assumed.
        for pose_bone in armature.pose.bones:
            pose_bone.select = False
        control.select = True
        armature.data.bones.active = armature.data.bones[control_name]
        control.location = (0.0, 0.0, -abs(pull_mm) * 0.001)
        bpy.context.view_layer.update()
    except RuntimeError:
        return report, "Could not pose the lid for capture."

    report["posed_to_mm"] = -abs(pull_mm)
    report["ready"] = True
    report["next"] = (
        "The rig is in Pose Mode with %s selected and held at the closed pose. "
        "In Auto-Rig Pro's panel press Add Blink Pose, then Add Default Blink "
        "Pose, then OK. Repeat for the lower lid. Clear the pose afterwards."
        % control_name)
    return report, ""

def dispose_temporary_armature(armature_object, keep_collection=False):
    """Delete a throwaway eye armature, but only once nothing needs it.

    Order matters and getting it wrong is silent. The eyeballs are parented to
    the throwaway rig, so removing it before they are bound leaves them with no
    parent and no armature modifier -- unrigged, and still sitting in exactly the
    right place at rest. Every reference is therefore checked first and the call
    refuses rather than warns.
    """
    if armature_object is None or armature_object.type != "ARMATURE":
        return None, "That is not an armature."
    blockers = []
    for obj in bpy.data.objects:
        if obj is armature_object:
            continue
        if obj.parent is armature_object:
            blockers.append("%s is parented to it" % obj.name)
        for mod in obj.modifiers:
            if mod.type == "ARMATURE" and mod.object is armature_object:
                blockers.append("%s has an armature modifier on it" % obj.name)
        for con in obj.constraints:
            if getattr(con, "target", None) is armature_object:
                blockers.append("%s has a constraint targeting it" % obj.name)
        if obj.type == "ARMATURE" and obj.pose:
            for pose_bone in obj.pose.bones:
                for con in pose_bone.constraints:
                    if getattr(con, "target", None) is armature_object:
                        blockers.append("%s/%s has a constraint targeting it"
                                        % (obj.name, pose_bone.name))
    if blockers:
        return None, ("%s is still in use, so it was not removed: %s"
                      % (armature_object.name, "; ".join(blockers[:4])))

    name = armature_object.name
    emptied = []
    homes = list(armature_object.users_collection)
    bpy.data.objects.remove(armature_object, do_unlink=True)
    if not keep_collection:
        for collection in homes:
            if not collection.objects and not collection.children:
                emptied.append(collection.name)
                bpy.data.collections.remove(collection)
    return {"removed": name, "collections_removed": emptied}, ""


def audit_eye_rig(armature, eye_l, eye_r=None):
    """Return a list of human-readable problems with the eye rig. Empty means healthy."""
    issues = []
    if armature is None or armature.type != "ARMATURE":
        return ["Select the Auto-Rig Pro rig armature first."]

    matrix = armature.matrix_world
    bones = armature.data.bones
    pairs = [(side, eye) for side, eye in zip(_SIDES, (eye_l, eye_r)) if eye is not None]

    for side, eye_object in pairs:
        reference = bones.get(REF_FMT.format(side=side))
        if reference is None:
            issues.append(f"{REF_FMT.format(side=side)} is missing.")
            continue
        if reference.length < 1e-4:
            issues.append(
                f"{reference.name} is almost zero length, which breaks the bones derived from it."
            )
        control = bones.get(CTRL_EYE_FMT.format(side=side))
        if control is not None:
            error = ((matrix @ control.head_local) - eye_object.matrix_world.translation).length
            if error > 0.001:
                issues.append(
                    f"{control.name} sits {error * 1000:.1f} mm away from "
                    f"{eye_object.name}'s origin."
                )

    target = bones.get(CTRL_TARGET_X)
    forward = guess_forward(armature)
    if target is not None and forward is not None:
        references = [bones.get(REF_FMT.format(side=s)) for s in _SIDES]
        references = [r for r in references if r is not None]
        if references:
            centre = Vector()
            for reference in references:
                centre += matrix @ reference.head_local
            centre /= len(references)
            if ((matrix @ target.head_local) - centre).dot(forward) <= 0.0:
                issues.append(
                    f"{CTRL_TARGET_X} is behind the face; the eye reference bones point backwards."
                )

    # The lid pivot is part of the eye rig's health and was previously invisible
    # here: the reference rig audited clean while the bones that actually rotate
    # sat 24.016mm off the eye centre and the eye could not shut past half way.
    pivot, pivot_error = lid_pivot_report(armature)
    if pivot_error:
        issues.append(pivot_error)
    elif pivot.get("needs_fix"):
        for entry in pivot["sides"]:
            for rotator in entry["rotators"]:
                if rotator["offset_mm"] > LID_PIVOT_TOLERANCE_MM:
                    issues.append(
                        f"{rotator['bone']} sits {rotator['offset_mm']}mm from the "
                        f"eye pivot; it is the bone the lid rotates about, so the "
                        f"lid swings away from the eyeball instead of closing over "
                        f"it. Run Correct Eyelid Pivot."
                    )

    for _side, eye_object in pairs:
        # Resolve against every armature the mesh is bound to, not just the main
        # rig. Auto-Rig Pro's ADDITIVE mode gives a mesh two armature modifiers,
        # and six deform bones live only on the additive one -- measured on the
        # reference character, hand_bend.l carries mean 0.841 over 1317 vertices
        # and exists on rig_add alone. Checking the main rig by itself reports
        # those as groups no bone matches, and an audit that cries wolf gets
        # switched off.
        known = bind_common.deform_bone_names(eye_object)
        known.update(bone.name for bone in bones)
        stray = [group.name for group in eye_object.vertex_groups
                 if group.name not in known]
        if stray:
            issues.append(
                f"{eye_object.name} still carries vertex groups that no bone matches: "
                + ", ".join(stray[:6])
            )
        for modifier in eye_object.modifiers:
            if modifier.type != "UV_PROJECT":
                continue
            empty = sum(1 for projector in modifier.projectors if projector.object is None)
            if empty:
                issues.append(
                    f"{eye_object.name}: UV Project modifier '{modifier.name}' has "
                    f"{empty} projector slot(s) with no object, so it does nothing."
                )
    return issues
