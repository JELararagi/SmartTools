# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Secondary motion for a bone chain, solved once and written as keyframes.

Hair, straps and tails have to lag behind the body and settle after it stops. The
usual ways to get that are a cloth or soft-body simulation driving the bones, or
an add-on that integrates a spring every time the frame changes. Neither suits
this rig:

* The brief is explicit that everything that dangles except the skirt is
  bone-driven. A simulation that has to run to see the motion is not.
* A frame-change handler is a resident process. This project has a measured
  defect class for those -- three suites shipped modal operators that were
  misclassified as inert -- and a rig that only moves while an add-on is
  installed does not export and does not open correctly on another machine.

So the spring is integrated HERE, over a frame range, and the result is written
onto the chain's own rotation channels. What the file then contains is ordinary
bone animation: it plays without this add-on, it exports through any pipeline
that carries bone F-curves, and it can be edited by hand afterwards.

The model is a chain of rigid links. Each frame, the chain is first read in its
CARRIED configuration -- every jiggle rotation cleared, so the links sit where the
head simply drags them -- and that is the goal the spring pulls towards. Each link
tip then integrates

    velocity += (goal - position) * stiffness + gravity
    velocity *= (1 - damping)
    position += velocity

and is pushed back onto the sphere of its own length so the link cannot stretch.
Stiffness near 1 gives a stiff braid that barely lags; low stiffness with low
damping gives a long, loose swing.
"""

import math

import bpy
import mathutils

CHAIN_STIFFNESS = "srs_jiggle_stiffness"
CHAIN_DAMPING = "srs_jiggle_damping"
CHAIN_GRAVITY = "srs_jiggle_gravity"
CHAIN_INERTIA = "srs_jiggle_inertia"
# optional, on the root: how many steps a colliding chain is solved in per frame
# (1 = the single step of 2.61 and earlier)
CHAIN_SUBSTEPS = "srs_jiggle_substeps"
# optional, on the root: how this one chain meets the capsules (absent = the
# CONTACT default). A heavy strap hanging from a capsule needs all three; the
# hair tails were tuned without them and keep that tuning, and the earrings got
# worse with them (05_17: 5.2 -> 10.9 faces crossing the coat a frame). Measured
# on the MIK belt straps at True / 0.5 / 7.0 (05_17, 131_10, 61_04): the strap
# faces crossing the coat 40.0/42.2/30.0 -> 21.5/27.9/25.0 a frame, crossing
# the body 4.1/10.3/15.2 -> 2.0/8.0/10.3, tip acceleration p99 within 8mm of
# before on 05_17 and lower on 131_10; 61_04 L rises 124 -> 142 (off: 198).
CHAIN_REST_CONTACT = "srs_jiggle_rest_contact"   # bool
CHAIN_EXIT_SLOPE = "srs_jiggle_exit_slope"       # float, 0 = off
CHAIN_TIP_MM = "srs_jiggle_tip_mm"               # millimetres per frame
# True on the root: the chain's rest shape is taken to be the shape gravity already holds (a styled
# fringe, a curled tail). The bake then applies only gravity minus gravity turned with the chain's
# root: nothing at the rest orientation -- no sag, the curl kept -- and the difference when the head
# tilts or swings. Off (absent), gravity pulls straight down at all times.
CHAIN_GRAVITY_REST = "srs_jiggle_gravity_rest"   # bool
# True on the root: no capsule may push the chain out of its own rest pose. A capsule fitted to the
# dressed body is round where the body is not; MIK's twin tails rest up to 31 mm inside the waist
# capsule, so 62% of their waist contacts existed before anything moved and the solver fought the
# rest pose on every frame. With this on, each capsule holding one of the chain's links at rest is
# shrunk for this chain only, just enough to clear it; the other chains keep it at full size.
CHAIN_REST_CLEAR = "srs_jiggle_rest_clear"       # bool
# On the root, one value per link (metres): how thick the mesh around that link is. Without it a
# chain collides as a thin line (the chain radius); MIK's tail bundles are tens of millimetres
# thick, so the line stayed clear while the hair went 40-80 mm into the body.
CHAIN_LINK_RADII = "srs_jiggle_link_radii"       # float array, metres
# True on the root: a link meeting a capsule it was NOT touching last frame is pushed out at once
# (no tip_mm cap); one already in contact keeps easing out at the cap. The cap exists to stop deep
# contacts popping, but it also let the MIK tails sink 10 mm a frame into a body moving faster.
CHAIN_ENTRY_PUSH = "srs_jiggle_entry_push"       # bool
# False on the root bone leaves the chain out of every bake. A chain that is
# only there to be posed by hand (a fringe) is otherwise baked by the
# no-selection default along with everything else.
CHAIN_BAKE = "srs_jiggle_bake"
# True on the root bone: the bake's curves are muted, so the chain follows the
# body; unmuting brings the same bake back. A selector reads it as the real state.
CHAIN_MUTED = "srs_jiggle_muted"
# A chain whose bones do not follow a builder's naming (an ARP Kilt's c_kilt_*, a
# coat's strips, anything rigged by hand) is marked on its root: the key it is
# called by and its bones, root first, separated by ";".
CHAIN_KEY = "srs_chain_key"
CHAIN_BONES = "srs_chain_bones"
MARK = "mark"
# A chain may carry a SWING LAYER: one non-deforming bone per link, with the link's rest, that a
# Copy Rotation on the link applies after the link's own rotation (LOCAL to LOCAL, mix AFTER, so
# the link turns by own @ swing). The bake then writes onto the swing bones and never onto the
# links, so hand keys on the links survive a bake, stay live while it plays and add before it.
# The constraint's influence is driven by one switch property on the armature: the swing plays
# only while the switch holds the value stored with the layer. Root bone: the swing bone names.
CHAIN_SWING = "srs_chain_swing"
CHAIN_SWING_SWITCH = "srs_chain_swing_switch"
SWING_PREFIX = "srs_swing_"
SWING_CONSTRAINT = "SRS swing"
SWING_COLLECTION = "SRS Swing"
# every curve the bake writes lands in this F-curve group, so a clear can take
# exactly those and leave a hand-keyed curve on the same bone alone
BAKE_GROUP = "SRS Jiggle"
# a Damped Track whose name starts with this is a link's goal: on while the chain
# is not baked (the link follows it), off while a bake plays (the keys carry it)
GOAL_PREFIX = "SRS goal"
# A link whose goal must not swallow the animator's rotation hangs from a hidden AIM bone with the
# same rest: the goal turns the aim, the link's own rotation applies after it.
AIM_PREFIX = "srs_aim_"


def goal_holders(pose_bone):
    """The bones whose goal constraints steer ``pose_bone``: itself, and its aim parent if it has one."""
    out = [pose_bone]
    parent = pose_bone.parent
    if parent is not None and parent.name.startswith(AIM_PREFIX):
        out.append(parent)
    return out


def goal_constraints(armature, bones):
    """Every goal constraint on ``bones``. ``[(pose_bone, constraint)]``."""
    out = []
    for name in bones or ():
        pose_bone = armature.pose.bones.get(name) if armature is not None else None
        if pose_bone is None:
            continue
        for holder in goal_holders(pose_bone):
            for con in holder.constraints:
                if con.type == "DAMPED_TRACK" and con.name.startswith(GOAL_PREFIX):
                    out.append((holder, con))
    return out


def set_goals(armature, bones, on):
    """Switch the chain's goal constraints on (follow) or off (a bake plays). Returns how many."""
    found = goal_constraints(armature, bones)
    for _pose_bone, con in found:
        con.mute = not on
    return len(found)


def _goal_point(armature, con):
    """World point a goal constraint aims at, from the target's evaluated pose."""
    target = con.target
    if target is None:
        return None
    if target.type == "ARMATURE" and con.subtarget:
        pose_bone = target.pose.bones.get(con.subtarget)
        if pose_bone is None:
            return None
        local = pose_bone.head.lerp(pose_bone.tail, con.head_tail)
        return target.matrix_world @ local
    return target.matrix_world.translation.copy()
# how far under the floor a link's anchor may be and still be lifted back onto it
FLOOR_REACH = 0.05
# The floor never turns a link up further than this. With no bound a link whose
# anchor was carried down to the floor was stood up to clear its mesh: on the
# MIK straps 61 of 617 lifts ended above 80 degrees and one turned 162 (Claude
# fork 14's subagent, 2026-10-03). A strap lies on the floor; it does not stand.
FLOOR_MAX_RISE = 0.7071067811865476  # sin 45 degrees
# below this horizontal share a link has no heading of its own: it hangs nearly
# straight down, and what is left is noise that changes sign from frame to frame
FLOOR_HEADING_MIN = 0.05
# A chain that starts a bake this far under the floor, as a share of its length,
# belongs to a model that does not stand on that floor. A little less is a hem
# brushing the ground, and the floor still holds it.
FLOOR_START_SHARE = 0.1


def chains_named(armature, prefix="hair"):
    """Every chain built under ``prefix``, root first. ``{key: [bone names]}``."""
    import re

    if armature is None or armature.type != "ARMATURE":
        return {}
    pattern = re.compile(r"^%s_(.+)_(\d{2})$" % re.escape(prefix))
    found = {}
    for bone in armature.data.bones:
        match = pattern.match(bone.name)
        if match:
            found.setdefault(match.group(1), []).append(
                (int(match.group(2)), bone.name))
    return {key: [name for _n, name in sorted(rows)]
            for key, rows in found.items()}


CHAIN_PREFIXES = ("hair", "srs_chain")

# The values a chain of each kind ended up with on MIK, after the chains were
# rebuilt on the geometry (38-41 link braids, 12 fringe strands of 9-14 links,
# 15-link straps) and gravity was weighted by the hanging length instead of
# divided by the link length (MIK_RIG_PLAN §42, §43). They are what a second
# character gets from the preset, so a re-rig starts where MIK finished rather
# than at the twelve-link numbers the first presets were measured on.
# Gravity is the §43 unit: per hanging length, normalised to a mean of 1.0.
FEEL = {
    "LONG": {"stiffness": 0.90, "damping": 0.62, "gravity": 60.0,
             "inertia": 0.24},
    "FRINGE": {"stiffness": 0.92, "damping": 0.70, "gravity": 0.0,
               "inertia": 0.22},
    "SHORT": {"stiffness": 0.55, "damping": 0.22, "gravity": 0.0,
              "inertia": 0.50},
    "METAL": {"stiffness": 0.70, "damping": 0.45, "gravity": 3.0,
              "inertia": 0.30},
    "ZIP": {"stiffness": 0.45, "damping": 0.25, "gravity": 9.0,
            "inertia": 0.45},
    "HEM": {"stiffness": 0.40, "damping": 0.30, "gravity": 4.0,
            "inertia": 0.45},
    "STRAP": {"stiffness": 0.70, "damping": 0.72, "gravity": 160.0,
              "inertia": 0.20},
}


def all_chains(armature, prefixes=CHAIN_PREFIXES):
    """Every generated chain, whatever it was built for.

    ``{(prefix, key): [bone names]}``. One prefix is not enough. The hair
    builder names its chains ``hair_*``; every costume, piercing, zip and hem
    chain is named ``srs_chain_*``. A bake wired to a single prefix can only
    ever reach the hair -- on this character 4 chains of 22, with the other 18
    unreachable from the interface entirely.
    """
    out = {}
    for prefix in prefixes:
        if prefix == MARK:
            continue
        for key, bones in chains_named(armature, prefix=prefix).items():
            out[(prefix, key)] = bones
    if MARK in prefixes or tuple(prefixes) == tuple(CHAIN_PREFIXES):
        taken = {bones[0] for bones in out.values() if bones}
        for key, bones in marked_chains(armature).items():
            if bones[0] not in taken:
                out[(MARK, key)] = bones
    return out


def marked_chains(armature):
    """Chains marked on their root bone. ``{key: [bone names, root first]}``."""
    out = {}
    if armature is None or armature.type != "ARMATURE" or armature.pose is None:
        return out
    for pose_bone in armature.pose.bones:
        if CHAIN_BONES not in pose_bone.keys():
            continue
        names = [n for n in str(pose_bone[CHAIN_BONES]).split(";") if n]
        names = [n for n in names if armature.pose.bones.get(n) is not None]
        if names and names[0] == pose_bone.name:
            out[str(pose_bone.get(CHAIN_KEY, pose_bone.name))] = names
    return out


def mark_chain(armature, key, bones):
    """Mark ``bones`` (root first) as the chain ``key``. ``(report, error)``."""
    names = [n for n in bones or () if armature.pose.bones.get(n) is not None]
    if not names:
        return None, "None of those bones is on this armature"
    if not key:
        return None, "Name the chain"
    root = armature.pose.bones[names[0]]
    root[CHAIN_KEY] = str(key)
    root[CHAIN_BONES] = ";".join(names)
    return {"key": str(key), "bones": names}, ""


def unmark_chain(armature, root_name):
    root = armature.pose.bones.get(root_name) if armature is not None else None
    if root is None:
        return False
    gone = False
    for prop in (CHAIN_KEY, CHAIN_BONES):
        if prop in root.keys():
            del root[prop]
            gone = True
    return gone


def parse_keys(text):
    """``"a, b  c"`` -> ``["a", "b", "c"]``: commas, semicolons or whitespace between keys."""
    import re
    return [k for k in re.split(r"[,;\s]+", str(text or "")) if k]


def chains_by_keys(armature, keys, prefixes=CHAIN_PREFIXES):
    """The chains named by ``keys``. ``(chains, missing)``.

    A key is the string a chain was built under and every one of its bones carries
    (``belt_strap_l`` for ``srs_chain_belt_strap_l_01``...), so it is a stable id: it
    does not depend on what is selected or on a label's language. ``fnmatch``
    patterns are allowed (``*tail*``), and ``prefix/key`` limits a key to one prefix.
    ``missing`` lists every key that matched nothing, so a caller can refuse instead
    of reporting success on nothing.
    """
    import fnmatch
    every = {k: v for k, v in all_chains(armature, prefixes).items() if k[1] != "master"}
    found, missing = {}, []
    for raw in keys or ():
        key = str(raw).strip()
        if not key:
            continue
        prefix = None
        if "/" in key:
            prefix, key = key.split("/", 1)
        hits = {k: v for k, v in every.items()
                if (prefix is None or k[0] == prefix) and fnmatch.fnmatchcase(k[1], key)}
        if not hits:
            missing.append(str(raw).strip())
        found.update(hits)
    return found, missing


def chain_root(armature, bone_name):
    """The root pose bone of the generated chain ``bone_name`` belongs to, or None."""
    import re

    if armature is None or armature.type != "ARMATURE" or armature.pose is None or not bone_name:
        return None
    for prefix in CHAIN_PREFIXES:
        match = re.match(r"^%s_(.+)_(\d{2})$" % re.escape(prefix), bone_name)
        if match:
            return armature.pose.bones.get("%s_%s_01" % (prefix, match.group(1)))
    for bones in marked_chains(armature).values():
        if bone_name in bones:
            return armature.pose.bones.get(bones[0])
    return None


def _directions(count=64):
    """``count`` unit vectors spread evenly over the sphere (Fibonacci lattice)."""
    out = []
    golden = 3.883222077450933  # pi * (3 - sqrt(5))
    for k in range(count):
        z = 1.0 - 2.0 * (k + 0.5) / count
        ring = max(0.0, 1.0 - z * z) ** 0.5
        out.append(mathutils.Vector((ring * math.cos(golden * k), ring * math.sin(golden * k), z)))
    return out


def chain_reach(armature, bones, threshold=0.5, directions=64):
    """The mesh each link carries, as bone-local points. ``{bone: {"lift": [...], "own": [...]}}``.

    A vertex belongs to a link when the link's group holds at least ``threshold``
    of it, on any mesh an Armature modifier binds to ``armature``. A link answers
    for its outer half and for the inner half of the next link: the loop at a
    joint is carried by the link that starts there, but only the link that ENDS
    there can lift it -- leaving it to the first measured the joint loop of a
    20mm tube 15.6mm under the floor with every link "clear". The points
    are in the bone's rest space (armature units, head at the origin), reduced to
    the extremes along ``directions`` evenly spread directions: the lowest point of
    a turned link is always one of those, so the floor test reads a few dozen
    points instead of every vertex.
    """
    wanted = set(bones or ())
    if armature is None or not wanted:
        return {}
    to_bone = {}
    for name in wanted:
        bone = armature.data.bones.get(name)
        if bone is not None:
            to_bone[name] = bone.matrix_local.inverted()
    world_to_arm = armature.matrix_world.inverted()
    points = {name: [] for name in to_bone}
    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        if not any(m.type == "ARMATURE" and m.object == armature for m in obj.modifiers):
            continue
        index_of = {g.index: g.name for g in obj.vertex_groups if g.name in to_bone}
        if not index_of:
            continue
        to_arm = world_to_arm @ obj.matrix_world
        for vertex in obj.data.vertices:
            for entry in vertex.groups:
                name = index_of.get(entry.group)
                if name is not None and entry.weight >= threshold:
                    points[name].append(to_bone[name] @ (to_arm @ vertex.co))
    order = [n for n in bones if n in to_bone]
    probes = _directions(directions)

    def extremes(cloud):
        keep = {}
        for probe in probes:
            best = max(range(len(cloud)), key=lambda i: cloud[i].dot(probe))
            keep[best] = cloud[best]
        return list(keep.values())

    out = {}
    for k, name in enumerate(order):
        length = armature.data.bones[name].length
        lift = [p for p in points[name] if p.y >= 0.5 * length]
        if k + 1 < len(order):
            child = order[k + 1]
            child_length = armature.data.bones[child].length
            into_mine = to_bone[name] @ armature.data.bones[child].matrix_local
            lift += [into_mine @ p for p in points[child] if p.y < 0.5 * child_length]
        if lift or points[name]:
            out[name] = {"lift": extremes(lift) if lift else [],
                         "own": extremes(points[name]) if points[name] else []}
    return out


def _lowest(entry, direction, anchor, points):
    """World Z of the lowest of ``points`` with the link pointing along ``direction``.

    The link's world orientation after the bake is the minimal turn from its
    carried direction to the solved one, applied to its carried frame -- what
    :func:`_local_turn` writes -- so the points are turned the same way.
    """
    frame = entry["matrix"].to_3x3()
    carried = (frame @ mathutils.Vector((0.0, 1.0, 0.0)))
    if carried.length <= 1.0e-12 or direction.length <= 1.0e-12:
        return anchor.z
    turn = carried.normalized().rotation_difference(direction.normalized()).to_matrix()
    return anchor.z + min((turn @ (frame @ p)).z for p in points)


def starts_under_floor(carried, floor, reach):
    """True when the links or their mesh start too far under ``floor`` (see FLOOR_START_SHARE)."""
    if not carried:
        return False
    lowest = min(entry["tail"].z for entry in carried)
    for entry in carried:
        info = (reach or {}).get(entry["bone"].name)
        if info and info["own"]:
            frame = entry["matrix"].to_3x3()
            lowest = min(lowest, entry["head"].z + min((frame @ p).z for p in info["own"]))
    total = sum(entry["length"] for entry in carried)
    return floor - lowest > FLOOR_START_SHARE * total


def _floor_heading(state, index, direction, goal):
    """Which way the link points along the floor: unit, horizontal.

    A link already lying on the floor stays on its way: it never jumps round
    because a link before it has lifted off and swung past the vertical. A link
    coming down runs on the way the link before it was going, as a rope does. One
    that hangs straight down has no heading of its own, and taking its noise
    folded the chain into a zigzag that changed every frame.
    """
    own = mathutils.Vector((direction.x, direction.y, 0.0))
    strong = own.length >= FLOOR_HEADING_MIN
    kept = state.get("floor_heading", {}).get(index)
    if kept is not None and kept[1] >= state.get("floor_step", 0) - 1:
        if strong and own.dot(kept[0]) > 0.0:
            return own.normalized()
        return kept[0].copy()
    before = None
    if index > 0:
        before = mathutils.Vector((state["directions"][index - 1].x, state["directions"][index - 1].y, 0.0))
        if before.length < FLOOR_HEADING_MIN:
            before = None
    if strong and (before is None or own.dot(before) >= 0.0):
        return own.normalized()
    if before is not None:
        return before.normalized()
    # the first of the chain to come down hanging straight picks the way, and the
    # others that come down after it take the same one
    way = state.get("floor_way")
    if way is None:
        flat = mathutils.Vector((goal.x, goal.y, 0.0))
        if own.length > 1.0e-9:
            way = own.normalized()
        elif flat.length > 1.0e-9:
            way = flat.normalized()
        else:
            way = mathutils.Vector((1.0, 0.0, 0.0))
        state["floor_way"] = way
    return way.copy()


def _rest_on_floor(state, index, heading):
    """The link now lies along ``heading``: take out the rates that would undo it.

    The spring keeps pulling a resting link towards its goal under the anchor.
    Left in the rate, that pull passes through the anchor within a few frames and
    the floor throws the link out the other side. A link lying on the floor has
    no swing to keep: it moves only as its anchor and its spring move it.
    """
    state.setdefault("floor_heading", {})[index] = (heading.copy(), state.get("floor_step", 0))
    state["rates"][index].zero()
    state["floor_hits"] = state.get("floor_hits", 0) + 1


def _lift_to_floor(entry, direction, heading, anchor, length, floor, mesh_floor, points):
    """Turn the link up about its anchor, along ``heading``, until its bone line
    clears ``floor`` and its mesh ``points`` clear ``mesh_floor``. ``None`` when it
    already does."""
    def clear(d):
        return (anchor.z + d.z * length >= floor - 1.0e-6
                and _lowest(entry, d, anchor, points) >= mesh_floor - 1.0e-6)

    if clear(direction):
        return None
    flat = heading
    low = math.asin(max(-1.0, min(1.0, direction.normalized().z)))
    # never above what the mesh needs -- not "straight up until clear". The
    # nearest of the link's points to its anchor has to rise by its own radius
    # over its own distance along the link; sizing the turn by the tip instead
    # left the middle of a 17mm strap up to 10.8mm under the floor on 79_22.
    frame = entry["matrix"].to_3x3()
    radial = max((frame @ mathutils.Vector((p.x, 0.0, p.z))).length for p in points)
    near = min((frame @ mathutils.Vector((0.0, p.y, 0.0))).length for p in points if p.y > 0.0)         if any(p.y > 0.0 for p in points) else length
    rise = max(floor - anchor.z, mesh_floor + radial - anchor.z)
    reach_along = min(length, max(near, 1.0e-6)) if mesh_floor + radial - anchor.z > floor - anchor.z else length
    high = math.asin(max(0.0, min(FLOOR_MAX_RISE, rise / max(reach_along, 1.0e-9))))
    if high <= low:
        return None

    def at(angle):
        return (flat * math.cos(angle) + mathutils.Vector((0.0, 0.0, math.sin(angle)))).normalized()

    if not clear(at(high)):
        return at(high)
    for _step in range(14):
        middle = 0.5 * (low + high)
        if clear(at(middle)):
            high = middle
        else:
            low = middle
    return at(high)


def swing_bones(armature, bones):
    """The swing bones of a chain (one per link, root first), or None when it has no swing layer."""
    root = armature.pose.bones.get(bones[0]) if armature is not None and bones else None
    if root is None or CHAIN_SWING not in root.keys():
        return None
    names = [n for n in str(root[CHAIN_SWING]).split(";") if n]
    if len(names) != len(bones) or any(armature.pose.bones.get(n) is None for n in names):
        return None
    return names


def add_swing_layer(armature, bones, switch="srs_sim_mode", value=1):
    """Give a chain a swing layer. ``(report, error)``.

    One bone per link (``srs_swing_<link>``, the link's rest, the link's parent, not
    deforming, in a hidden bone collection), a Copy Rotation on the link that applies it
    after the link's own rotation, and that constraint's influence driven by ``switch`` on
    the armature: 1 while the switch is ``value``, 0 otherwise. The switch is created if
    missing (an integer property, 0 = no simulation). Running it again repairs the layer.
    A bake already on the links moves onto the swing bones, so the switch governs it.
    """
    names = [n for n in bones or () if armature.pose.bones.get(n) is not None]
    if not names:
        return None, "None of those bones is on this armature"
    # the slot says which keys are this rig's: with it unknown, nothing is changed
    _bag, error = rig_channelbag(armature)
    if error:
        return None, error
    if switch not in armature.keys():
        armature[switch] = 0
        try:
            armature.id_properties_ui(switch).update(
                min=0, max=2, description="0 = no simulation, 1 = baked bone swing, 2 = cloth")
        except (AttributeError, TypeError):
            pass
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    made = []
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        coll = armature.data.collections_all.get(SWING_COLLECTION) or armature.data.collections.new(SWING_COLLECTION)
        coll.is_visible = False
        for name in names:
            link = edit[name]
            swing_name = SWING_PREFIX + name
            sb = edit.get(swing_name) or edit.new(swing_name)
            sb.head, sb.tail, sb.roll = link.head.copy(), link.tail.copy(), link.roll
            sb.parent = link.parent
            sb.use_connect = False
            sb.use_deform = False
            coll.assign(sb)
            made.append(swing_name)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
    for name, swing_name in zip(names, made):
        pose_bone = armature.pose.bones[name]
        swing = armature.pose.bones[swing_name]
        swing.rotation_mode = "QUATERNION"
        swing.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
        con = pose_bone.constraints.get(SWING_CONSTRAINT) or pose_bone.constraints.new("COPY_ROTATION")
        con.name = SWING_CONSTRAINT
        con.target = armature
        con.subtarget = swing_name
        con.target_space = "LOCAL"
        con.owner_space = "LOCAL"
        con.mix_mode = "AFTER"
        path = 'pose.bones["%s"].constraints["%s"].influence' % (name, SWING_CONSTRAINT)
        if armature.animation_data is not None:
            for curve in list(armature.animation_data.drivers):
                if curve.data_path == path:
                    armature.animation_data.drivers.remove(curve)
        curve = con.driver_add("influence")
        driver = curve.driver
        driver.type = "SCRIPTED"
        var = driver.variables.new()
        var.name = "mode"
        var.type = "SINGLE_PROP"
        var.targets[0].id = armature
        var.targets[0].data_path = '["%s"]' % switch
        # a simple expression: evaluated without Python, so the switch works with scripts off
        driver.expression = "abs(mode - %d) < 0.5" % int(value)
    root = armature.pose.bones[names[0]]
    root[CHAIN_SWING] = ";".join(made)
    root[CHAIN_SWING_SWITCH] = str(switch)
    view_layer.objects.active = previous
    moved = _move_bake_to_swing(armature, names, made)
    return {"chain": names, "swing": made, "switch": switch, "value": int(value), "moved_bake": moved}, ""


def _move_bake_to_swing(armature, names, swing):
    """Hand the bake on these links over to their swing bones. The number of curves moved.

    A curve left on a link writes the link's own rotation whatever the switch says, and a
    new bake would add on top of it. On the swing bone the same rotation plays after the
    link's own, so nothing changes until the switch does. Hand keys stay on the links.
    """
    bag, _error = rig_channelbag(armature)
    if bag is None:
        return 0
    taken = {(c.data_path, c.array_index) for c in bag.fcurves}
    moved = 0
    for name, swing_name in zip(names, swing):
        emptied = False
        for prop in ("rotation_quaternion", "rotation_euler"):
            path = 'pose.bones["%s"].%s' % (name, prop)
            target = 'pose.bones["%s"].%s' % (swing_name, prop)
            for curve in [c for c in bag.fcurves if c.data_path == path and _is_baked(c)]:
                emptied = True
                if (target, curve.array_index) in taken:
                    bag.fcurves.remove(curve)
                    continue
                taken.add((target, curve.array_index))
                curve.data_path = target
                moved += 1
        # no curve writes the link any more: it would hold the last evaluated frame
        if emptied and not hand_curves(bag, [name]):
            clear_pose(armature, [name])
    return moved


def remove_swing_layer(armature, bones):
    """Take a chain's swing layer off: constraints, drivers, swing bones and keys. ``(report, error)``."""
    swing = swing_bones(armature, bones)
    if not swing:
        return {"removed": 0}, ""
    # the swing bones go, so every curve on them goes -- in this rig's slot only
    _report, error = clear_bake(armature, bones, only_baked=False)
    if error:
        return None, error
    for name in bones:
        pose_bone = armature.pose.bones.get(name)
        con = pose_bone.constraints.get(SWING_CONSTRAINT) if pose_bone is not None else None
        if con is not None:
            con.driver_remove("influence")
            pose_bone.constraints.remove(con)
    root = armature.pose.bones[bones[0]]
    del root[CHAIN_SWING]
    if CHAIN_SWING_SWITCH in root.keys():
        del root[CHAIN_SWING_SWITCH]
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        for name in swing:
            eb = armature.data.edit_bones.get(name)
            if eb is not None:
                armature.data.edit_bones.remove(eb)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous
    return {"removed": len(swing)}, ""


# Parts that switch between simulation and hand animation, by name: on the armature, a JSON
# object {part: {"chains": [chain keys], "switch": property, "values": {mode: value}, "label": ..}}.
# A browser selector reads it and calls srs.part_motion(part=.., mode=..).
PARTS_MOTION = "srs_parts_motion"
DEFAULT_MODES = {"hand": 0, "sim": 1}


def parts_motion(armature):
    """The rig's registered parts. ``{part: entry}``; empty when none or unreadable."""
    import json
    if armature is None or PARTS_MOTION not in armature.keys():
        return {}
    try:
        data = json.loads(str(armature[PARTS_MOTION]))
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def _chain_by_key(armature, key):
    every = all_chains(armature)
    for (_prefix, name), bones in every.items():
        if name == key:
            return bones
    return None


def register_part_motion(armature, part, chains, switch="", values=None, label=""):
    """Make ``part`` switchable by name. ``(report, error)``.

    Each chain (by the key it was built or marked under) gets a swing layer on the
    part's switch property -- the bake writes the swing bones, the links keep their
    hand keys, and the switch decides whether the swing plays on top. ``values``
    maps a mode name to the switch value; "sim" is the value the swing plays at and
    every other mode turns it off (0 = hand keys only). A chain already swinging on
    another switch is moved to this one, and leaves any other part that held it.
    Registering again replaces the entry: a chain it no longer names loses its swing
    layer and baked swing, as if the part's X had been pressed for that chain alone.
    """
    import json
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    part = str(part or "").strip()
    if not part:
        return None, "Name the part"
    values = dict(values or DEFAULT_MODES)
    if "sim" not in values:
        return None, "The modes need a 'sim' value: the value the swing plays at"
    switch = str(switch or "").strip() or ("srs_sim_" + part)
    found, missing = {}, []
    for key in chains or ():
        bones = _chain_by_key(armature, key)
        if bones:
            found[key] = bones
        else:
            missing.append(key)
    if missing:
        return None, "No chain under: %s" % ", ".join(missing)
    if not found:
        return None, "Give the part's chains"
    # with the slot unknown nothing can be taken apart or moved safely
    _bag, error = rig_channelbag(armature)
    if error:
        return None, error
    data = parts_motion(armature)
    earlier = data.get(part) or {}
    held_elsewhere = {k for name, e in data.items() if name != part for k in e.get("chains", ())}
    for key in earlier.get("chains", ()):
        bones = _chain_by_key(armature, key)
        if key in found or key in held_elsewhere or not bones:
            continue
        _report, error = remove_swing_layer(armature, bones)
        if error:
            return None, error
    existed = switch in armature.keys()
    for key, bones in found.items():
        _report, error = add_swing_layer(armature, bones, switch=switch, value=int(values["sim"]))
        if error:
            return None, error
    if not existed:
        armature[switch] = int(values["sim"])
    try:
        armature.id_properties_ui(switch).update(
            min=min(values.values()), max=max(values.values()),
            description="%s: %s" % (label or part, ", ".join("%d = %s" % (v, k) for k, v in
                                                           sorted(values.items(), key=lambda kv: kv[1]))))
    except (AttributeError, TypeError):
        pass
    data[part] = {"chains": sorted(found), "switch": switch, "values": values, "label": label or part}
    if earlier.get("switch") not in (None, switch):
        _forget_switch(armature, data, earlier["switch"])
    taken_from = _release_chains(armature, data, found, keep=part)
    armature[PARTS_MOTION] = json.dumps(data, ensure_ascii=False, sort_keys=True)
    return {"part": part, "chains": len(found), "switch": switch, "values": values, "taken_from": taken_from}, ""


def _forget_switch(armature, data, switch):
    if switch in armature.keys() and not any(e.get("switch") == switch for e in data.values()):
        del armature[switch]


def _release_chains(armature, data, keys, keep=None):
    """Take chains out of every part in ``data`` but ``keep``; a part left with none goes. The parts touched."""
    touched = []
    for name, entry in list(data.items()):
        chains = list(entry.get("chains", ()))
        left = [k for k in chains if k not in keys]
        if name == keep or len(left) == len(chains):
            continue
        touched.append(name)
        if left:
            entry["chains"] = left
        else:
            del data[name]
            _forget_switch(armature, data, entry.get("switch", ""))
    return touched


def release_chain_from_parts(armature, key, keep_switch=None):
    """A chain whose swing layer was taken off, or put on another switch, leaves its part."""
    import json
    data = parts_motion(armature)
    keep = next((name for name, e in data.items() if keep_switch and e.get("switch") == keep_switch), None)
    touched = _release_chains(armature, data, {key}, keep=keep)
    if touched:
        if data:
            armature[PARTS_MOTION] = json.dumps(data, ensure_ascii=False, sort_keys=True)
        else:
            del armature[PARTS_MOTION]
    return touched


def unregister_part_motion(armature, part):
    """Take ``part`` off the rig: its swing layers, its switch and its entry. ``(report, error)``.

    Hand keys on the links stay; only the swing bones, which hold the bake, go.
    """
    import json
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    data = parts_motion(armature)
    entry = data.get(str(part))
    if entry is None:
        return None, "No part called %s on this rig" % part
    # with the slot unknown nothing can be taken apart safely
    _bag, error = rig_channelbag(armature)
    if error:
        return None, error
    switch = entry.get("switch", "")
    for key in entry.get("chains", ()):
        bones = _chain_by_key(armature, key)
        if not bones:
            continue
        _report, error = remove_swing_layer(armature, bones)
        if error:
            return None, error
    del data[str(part)]
    if data:
        armature[PARTS_MOTION] = json.dumps(data, ensure_ascii=False, sort_keys=True)
    else:
        del armature[PARTS_MOTION]
    if switch in armature.keys() and not any(e.get("switch") == switch for e in data.values()):
        del armature[switch]
    return {"part": str(part), "chains": len(entry.get("chains", ()))}, ""


def set_part_motion(armature, part, mode):
    """Switch a registered part to ``mode`` ("sim", "hand", or the part's own). ``(report, error)``."""
    entry = parts_motion(armature).get(str(part))
    if entry is None:
        return None, "No part called %s on this rig" % part
    values = entry.get("values") or DEFAULT_MODES
    if mode not in values:
        return None, "%s has no mode %s (it has %s)" % (part, mode, ", ".join(sorted(values)))
    # whether a goal chain follows its goals depends on what is baked in the rig's own slot:
    # with the slot unknown, nothing is written -- not the switch, not a goal
    bag, error = rig_channelbag(armature)
    if error:
        return None, error
    armature[entry["switch"]] = int(values[mode])
    # a chain that follows goals (Damped Tracks to guides) follows them whenever its swing is not
    # playing -- in hand mode, or in sim with nothing baked -- exactly as Stop / Play Swing do
    for key in entry.get("chains", ()):
        bones = _chain_by_key(armature, key) or []
        if not bones or not goal_constraints(armature, bones):
            continue
        written = written_bones(armature, bones)
        baked = bag is not None and any(c.data_path in _rotation_paths(written) and _is_baked(c) for c in bag.fcurves)
        set_goals(armature, bones, on=not (mode == "sim" and baked))
    return {"part": part, "mode": mode, "switch": entry["switch"], "value": int(values[mode])}, ""


def part_motion_state(armature, part=None):
    """Every registered part (or one): its mode now, its chains, and what the bake left in the rig's slot.

    ``state`` is "ok", or "unknown" when the rig's Action slot cannot be resolved: then the bake counts
    are None and ``reason`` says why -- a selector must not show that as a part that is simply not baked.
    """
    out = []
    bag, error = rig_channelbag(armature)
    for name, entry in sorted(parts_motion(armature).items()):
        if part and name != part:
            continue
        values = entry.get("values") or DEFAULT_MODES
        value = armature.get(entry.get("switch", ""), None)
        mode = next((k for k, v in values.items() if value is not None and int(v) == int(value)), None)
        baked = hand = (None if error else 0)
        for key in entry.get("chains", ()):
            bones = _chain_by_key(armature, key) or []
            written = written_bones(armature, bones)
            if bag is not None:
                wanted = _rotation_paths(written)
                baked += sum(1 for c in bag.fcurves if c.data_path in wanted and _is_baked(c))
                hand += len(hand_curves(bag, bones))
        out.append({"part": name, "label": entry.get("label", name), "mode": mode, "value": value,
                    "switch": entry.get("switch"), "modes": sorted(values, key=lambda k: values[k]),
                    "chains": list(entry.get("chains", ())), "baked_curves": baked, "hand_curves": hand,
                    "state": "unknown" if error else "ok", "reason": error})
    return out


def written_bones(armature, bones):
    """The bones a bake of this chain keys: its swing bones if it has a swing layer, else its links."""
    return swing_bones(armature, bones) or list(bones)


def in_bake(armature, bones):
    """False when the chain's root says it stays out of the bake."""
    root = armature.pose.bones.get(bones[0]) if armature is not None and bones else None
    return root is None or bool(root.get(CHAIN_BAKE, True))


def _carried(armature, bones):
    """Where the links sit with no jiggle at all, at the current frame."""
    out = []
    for name in bones:
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is None:
            continue
        matrix = armature.matrix_world @ pose_bone.matrix
        head = matrix.translation.copy()
        # length in WORLD metres. bone.length is armature-local, and head is
        # already world, so composing the two is a unit mismatch -- it is what
        # every length-divided term in the solver then inherits, including the
        # push-out's lever arm. The axis vector's own length is the world units
        # per armature unit along the bone's Y, so it is the conversion.
        direction = (matrix.to_3x3() @ mathutils.Vector((0.0, 1.0, 0.0)))
        scale = direction.length
        if scale <= 1.0e-12:
            continue
        length = pose_bone.bone.length * scale
        aim = direction.normalized()
        # a goal: the spring pulls the link towards its goal, not along its frame
        goal = next((con for holder in goal_holders(pose_bone) for con in holder.constraints
                     if con.type == "DAMPED_TRACK" and con.name.startswith(GOAL_PREFIX)), None)
        if goal is not None:
            point = _goal_point(armature, goal)
            if point is not None and (point - head).length > 1.0e-9:
                aim = (point - head).normalized()
        out.append({"bone": pose_bone, "head": head,
                    "tail": head + aim * length,
                    "length": length, "matrix": matrix.copy()})
    return out


def _local_turn(entry, head, target, parent_turn):
    """The rotation to write on one link, given what its parent was turned by.

    Deliberately NOT via ``pose_bone.matrix``: that setter has to invert the
    parent chain and the armature's own transform, and on this rig it produced
    positions kilometres away on the very first frame -- where the answer is
    exactly the carried pose and the rotation is the identity.

    With ``F`` the link's carried world orientation, ``P`` the world rotation its
    parent already received and ``T`` the world rotation this link needs, writing
    ``L`` on the link gives it ``(P F) L``, so ``L = F' P' T F``. Leaving ``P``
    out is the mistake that matters: it is only correct for the root link, and
    down ten links the error compounds into the chain flying apart. Because the
    formula is closed, nothing here needs a depsgraph update, which is also what
    makes the bake fast enough to run over a shot.
    """
    matrix = entry["matrix"]
    rest_direction = (matrix.to_3x3() @ mathutils.Vector((0.0, 1.0, 0.0)))
    wanted = target - head
    if rest_direction.length <= 1.0e-9 or wanted.length <= 1.0e-9:
        return mathutils.Quaternion(), mathutils.Quaternion()
    turn = rest_direction.normalized().rotation_difference(wanted.normalized())
    frame = matrix.to_quaternion()
    local = frame.inverted() @ (parent_turn.inverted() @ turn) @ frame
    return local, turn


def clear_pose(armature, bones):
    for name in bones:
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is None:
            continue
        pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
        pose_bone.rotation_euler = (0.0, 0.0, 0.0)
        pose_bone.location = (0.0, 0.0, 0.0)


def action_channelbags(action):
    """Every channelbag of a layered action.

    Blender 5.1 has no ``Action.fcurves``: an action holds layers, each layer
    holds strips and each strip holds one channelbag per slot. Reaching for the
    old flat collection raises AttributeError, which is how a bake that otherwise
    worked failed at the very last step.
    """
    bags = []
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            for bag in getattr(strip, "channelbags", ()):
                bags.append(bag)
    return bags


def ensure_local_action(armature):
    """Make the rig's Action local when it is linked from a library. ``(note, error)``.

    A linked Action is read-only: every keyframe_insert on it is skipped with only a console
    warning ("Inserting keys ... skipped because they are not editable"), so a bake reports its
    keys and writes none, and a mute changes nothing. SmartSelector's external Action catalog
    links its Actions, so this is the normal case for an Action taken from the library. The
    local copy keeps the same slot (by identifier); the library file is not touched.
    """
    ad = armature.animation_data if armature is not None else None
    act = ad.action if ad is not None else None
    if act is None or (act.library is None and getattr(act, "override_library", None) is None):
        return "", ""
    slot_id = ad.action_slot.identifier if ad.action_slot is not None else ""
    name = act.name
    try:
        local = act.make_local()
    except Exception:  # noqa: BLE001 -- reported, nothing else changed
        return "", "The rig's Action %s is linked and could not be made local. Nothing was changed." % name
    if local is None:
        local = act
    if ad.action != local:
        ad.action = local
    if slot_id and (ad.action_slot is None or ad.action_slot.identifier != slot_id):
        slot = next((s for s in local.slots if s.identifier == slot_id), None)
        if slot is not None:
            ad.action_slot = slot
    if ad.action is None or ad.action.library is not None:
        return "", "The rig's Action %s is linked and could not be made local. Nothing was changed." % name
    return "The rig's Action %s was linked from a library; it was made local so the keys can be written." % name, ""


def rig_channelbag(armature):
    """The channelbag the rig plays: its own Action, through its own slot. ``(bag, error)``.

    ``(None, "")`` when nothing is keyed there yet. A layered Action can hold several
    rigs' keys, one slot each, under the same bone names, so the slot -- not a bone
    name and not the bake's group name -- is what says which keys are this rig's. An
    Action with no slot assigned, or a slot with keys on more than one strip, is an
    error, and every caller then changes nothing.
    """
    ad = armature.animation_data if armature is not None else None
    if ad is None or ad.action is None:
        return None, ""
    slot = getattr(ad, "action_slot", None)
    if slot is None:
        return None, ("The rig's Action has no slot assigned, so its keys cannot be told from another rig's. "
                      "Nothing was changed.")
    bags = [bag for bag in action_channelbags(ad.action) if bag.slot == slot]
    if not bags:
        return None, ""
    if len(bags) > 1:
        return None, "The rig's Action slot has keys on more than one layer. Nothing was changed."
    return bags[0], ""


def _rotation_paths(names):
    paths = {'pose.bones["%s"].rotation_quaternion' % n for n in names}
    paths |= {'pose.bones["%s"].rotation_euler' % n for n in names}
    return paths


def _is_baked(curve):
    return curve.group is not None and curve.group.name == BAKE_GROUP


def hand_curves(bag, names):
    """Rotation curves on ``names`` in ``bag`` that the bake did not write."""
    if bag is None:
        return []
    wanted = _rotation_paths(names)
    return [c for c in bag.fcurves if c.data_path in wanted and not _is_baked(c)]


def clear_bake(armature, bones, only_baked=True):
    """Remove the keyframes this module wrote on those bones. ``(report, error)``.

    Only the rig's own Action slot is touched (:func:`rig_channelbag`); another
    rig sharing the Action keeps its keys even under the same bone names.
    ``only_baked`` (the default) keeps every curve that is not in the bake's
    F-curve group, so a hand-keyed rotation on a chain bone survives (bakes before
    2.62.0 wrote no group and are then left alone too). Off, every rotation curve
    on the bones the bake writes goes -- in this rig's slot only.
    """
    if armature is None or armature.animation_data is None:
        return {"removed": 0, "kept": 0}, ""
    bag, error = rig_channelbag(armature)
    if error:
        return None, error
    swing = swing_bones(armature, bones)
    keyed = swing or bones
    removed = kept = 0
    if bag is not None:
        wanted = _rotation_paths(keyed)
        for curve in list(bag.fcurves):
            if curve.data_path in wanted:
                if only_baked and not _is_baked(curve):
                    kept += 1
                    continue
                bag.fcurves.remove(curve)
                removed += 1
    # no bake left: a chain with goals follows them again
    set_goals(armature, bones, on=True)
    if swing:
        clear_pose(armature, swing)
    elif removed:
        # a removed curve no longer writes: without this the bones would hold whatever
        # the last evaluated frame left on them. A link with hand keys keeps its pose:
        # those keys still write it.
        clear_pose(armature, [n for n in keyed if not hand_curves(bag, [n])])
    return {"removed": removed, "kept": kept}, ""


def mute_bake(armature, bones, mute):
    """Mute or unmute the bake's curves on ``bones``. ``(report, error)``.

    Muted, the chain follows the body exactly -- the curves stay, so unmuting
    brings back the same bake rather than a new one. A muted curve no longer
    writes, so the bones are also put back to the carried pose; otherwise they
    would hold whatever the last evaluated frame left on them. Only the bake's
    own curves in the rig's own slot change: hand keys on the same bones, and
    another rig's slot, keep playing (``kept`` counts the hand-keyed ones).
    """
    if armature is None or not bones:
        return None, "No chain"
    bag, error = rig_channelbag(armature)
    if error:
        return None, error
    curves = kept = 0
    swing = swing_bones(armature, bones)
    keyed = swing or bones
    if bag is not None:
        wanted = _rotation_paths(keyed)
        for curve in bag.fcurves:
            if curve.data_path not in wanted:
                continue
            if not _is_baked(curve):
                kept += 1
                continue
            curve.mute = bool(mute)
            curves += 1
    if mute and curves:
        # a swing chain's links keep their own (hand) pose; only the swing goes.
        # A link with hand keys keeps its pose too: those keys still write it.
        clear_pose(armature, swing or [n for n in keyed if not hand_curves(bag, [n])])
    # muted, a chain with goals follows them again; playing, the keys carry it
    set_goals(armature, bones, on=bool(mute) or curves == 0)
    root = armature.pose.bones.get(bones[0])
    if root is not None:
        root[CHAIN_MUTED] = bool(mute)
    return {"curves": curves, "kept": kept}, ""

COLLIDER_PREFIX = "srs_col_"

# Measured defaults. See the module docstring for where each came from.
CONTACT = {
    "radius": 0.004,        # the chain's own half-thickness, world metres
    "margin": 0.002,        # resolve to R + r + margin
    # Measured on this character: at relax 0.35 with a 14 deg/frame ceiling the
    # push-out is OUTRUN -- these tails sweep about 20mm a frame while a 32mm
    # link escapes about 8mm, and the residual stuck at 70mm. Full relaxation
    # with a 26 deg ceiling took it to 60mm and halved the unresolvable
    # contacts, and the velocity projection keeps it stable at full strength.
    "relax": 1.0,
    "sweeps": 3,            # Blender cloth's collision_quality idea
    "friction": 0.2,        # there is no friction in _advance otherwise
    "clamp": 0.5,           # direction space; atan(0.5) = 26.57 deg a frame
    "clamp_mm": 0.150,      # so a short link in a deep contact still escapes
    "lever_floor": 0.15,    # a contact at the anchor belongs to the parent
    # Measured on MIK's hair tails: with one solve per frame the positional and
    # goal resolves each turned a link up to 26.57 deg per sweep (53 deg a
    # frame at 2 sweeps), mostly against capsules that were barely moving, and
    # the 0.9 spring threw it back the next frame -- tip acceleration p99
    # 100mm (05_17) and 156mm (79_22) against 40/62mm with collision off, 11
    # and 31 frames over 100mm. Solving a colliding chain in substeps and
    # capping how far a contact may move a link's TIP per frame (a
    # depenetration speed, as PhysX's maxDepenetrationVelocity) gave 54/68mm,
    # no frame over 100mm, mean penetration 14.5/13.0mm (was 14.7/5.4mm, 68/47
    # with collision off). tip_mm is the trade: 0.020 keeps 7mm but 4/20 pops.
    "substeps": 4,
    "tip_mm": 0.010,        # metres per frame, split across the substeps
    # With entry push, a contact that is new this frame is pushed out at up to this much a frame
    # instead of tip_mm. Unlimited cut MIK's tail penetration 12% more than the cap alone but
    # popped 2 frames of 79_22 that had none.
    "entry_mm": 0.030,
    # A link whose anchor sits inside a capsule is allowed to stay as deep as
    # that anchor, which is right at the anchor and wrong at its tip: the MIK
    # belt straps hang from a forearm wrap 31mm inside the forearm capsule, and
    # the first two links slid along the inside of it, through the sleeve and
    # its cuff, in 101 and 72 of 103 frames (05_17). With a slope the TIP may
    # be no deeper than the anchor's allowance minus slope x link length, so
    # the link has to climb out within its own length. 0 keeps the old rule.
    "exit_slope": 0.0,
    # Resting contact. The push-out is capped per frame (tip_mm), and a heavy
    # chain's weight re-enters the capsule faster than that cap lets it out --
    # the strap's gravity of 160 adds about 0.3 per substep to its upper links
    # (direction units) against a push-out of about 0.04 per sweep -- so the
    # strap settled INSIDE the leg and forearm capsules. With this on, the
    # contact normal that held a link last step takes the inbound part out of
    # its rate BEFORE it moves, the way a normal force cancels weight, instead
    # of after the cap has been outrun.
    "rest": False,
}


def _any_perp(vector):
    """Some unit vector perpendicular to ``vector``, never a zero vector."""
    seed = mathutils.Vector((0.0, 0.0, 1.0))
    if abs(vector.normalized().dot(seed)) > 0.9:
        seed = mathutils.Vector((1.0, 0.0, 0.0))
    out = vector.normalized().cross(seed)
    return out.normalized() if out.length > 1.0e-9 else seed


def _closest_pair(p0, p1, q0, q1):
    """``(s, cp, cq)`` -- closest points between two segments, degenerate-safe.

    ``s`` is where along ``p0->p1`` the contact sits, which becomes the lever
    arm. Testing the link as a segment rather than as its tip is what makes a
    head-on contact resolvable and what lets the shaft rest on a shoulder.
    """
    d1 = p1 - p0
    d2 = q1 - q0
    r = p0 - q0
    a = d1.dot(d1)
    e = d2.dot(d2)
    f = d2.dot(r)
    if a <= 1.0e-12 and e <= 1.0e-12:
        return 0.0, p0.copy(), q0.copy()
    if a <= 1.0e-12:
        s = 0.0
        t = min(1.0, max(0.0, f / e))
    elif e <= 1.0e-12:
        t = 0.0
        s = min(1.0, max(0.0, -d1.dot(r) / a))
    else:
        c = d1.dot(r)
        b = d1.dot(d2)
        denom = a * e - b * b
        s = min(1.0, max(0.0, (b * f - c * e) / denom)) \
            if denom > 1.0e-12 else 0.0
        t = (b * s + f) / e
        if t < 0.0:
            t = 0.0
            s = min(1.0, max(0.0, -c / a))
        elif t > 1.0:
            t = 1.0
            s = min(1.0, max(0.0, (b - c) / a))
    return s, p0 + d1 * s, q0 + d2 * t


def _probe(collider, anchor, tip, radius, margin):
    """``(depth, normal, s)`` in world metres; ``depth > 0`` is penetrating.

    A sphere is the capsule with ``a == b``; ``_closest_pair`` handles that
    without a separate branch. Never divides by an untested length, and never
    takes a silent no-op branch -- a point exactly on the axis is pushed along
    the collider's precomputed fallback instead of being left stuck forever,
    which is the trap in the shipping implementations that return early there.
    """
    s, cp, cq = _closest_pair(anchor, tip, collider["a"], collider["b"])
    gap = cp - cq
    squared = gap.dot(gap)
    if collider["inside"]:
        want = max(collider["r"] - radius - margin, 0.0)
        if squared <= want * want:
            return 0.0, None, s
        length = squared ** 0.5
        if length > 1.0e-9 and want > 1.0e-9:
            return length - want, -gap / length, s
        return length - want, collider["fallback"], s
    want = collider["r"] + radius + margin
    if squared >= want * want:
        return 0.0, None, s
    length = squared ** 0.5
    if length > 1.0e-9:
        return want - length, gap / length, s
    return want, collider["fallback"], s


def _to_direction_space(normal, direction, depth, s, length, contact):
    """A world correction in metres, as a change to a UNIT direction vector.

    Returns ``None`` when the contact cannot be resolved by turning THIS link
    -- a contact at the anchor belongs to the parent, and as ``s -> 0`` the
    required change goes to infinity.
    """
    along = normal.dot(direction)
    tangent = normal - direction * along
    if tangent.length > 1.0e-6:
        tangent = tangent.normalized()
    else:
        # head-on: the radial part is normalised away, so pick any escape
        # perpendicular to the link
        tangent = contact["fallback_perp"](direction)
    lever = s * length
    if lever < contact["lever_floor"] * length or lever <= 1.0e-9:
        return None
    limit = min(contact["clamp"], contact["clamp_mm"] / lever)
    if contact.get("tip_mm"):
        cap = contact.get("entry_mm") if contact.get("entering") else contact["tip_mm"]
        if cap:
            limit = min(limit, max(cap, contact["tip_mm"]) / length)
    # every limit above is per FRAME; a substep gets its share of it
    limit *= contact.get("share", 1.0)
    size = depth * contact["relax"] / lever
    if size > limit:
        size = limit
    return tangent * size


def _contact_sweeps(direction, anchor, length, contact):
    """Turn ``direction`` until the link clears every collider.

    ``(direction, normal_sum, hits, deepest)``. Jacobi over colliders -- the
    corrections are averaged and scaled by the length of the COMBINED normal,
    so a link squeezed between two colliders settles instead of thrashing.
    """
    total = mathutils.Vector((0.0, 0.0, 0.0))
    hits, deepest = 0, 0.0
    for _sweep in range(max(1, int(contact["sweeps"]))):
        add = mathutils.Vector((0.0, 0.0, 0.0))
        acc = mathutils.Vector((0.0, 0.0, 0.0))
        touching = 0
        tip = anchor + direction * length
        for collider in contact["colliders"]:
            depth, normal, s = _probe(collider, anchor, tip,
                                      contact["radius"], contact["margin"])
            if normal is None:
                continue
            touching += 1
            acc = acc + normal
            if depth > deepest:
                deepest = depth
            if depth > contact["deepest"][0]:
                contact["deepest"][0] = depth
                contact["worst"].clear()
                contact["worst"].update({
                    "collider": collider["bone"], "group": collider["group"],
                    "link": contact["link"][0], "frame": contact["frame"][0],
                    "along": round(s, 3), "depth_mm": round(depth * 1000, 2)})
            if contact.get("measure"):
                continue
            # Keep raw depth for reporting, but turn only for penetration that
            # the chain can reach from its true root. A later link can move its
            # anchor by the world length of every preceding link; treating its
            # full current-anchor depth as fixed overstates the floor.
            anchor_depth, _, _ = _probe(collider, anchor, anchor,
                                        contact["radius"], contact["margin"])
            root = contact.get("chain_root", anchor)
            root_depth, _, _ = _probe(collider, root, root,
                                      contact["radius"], contact["margin"])
            fixed_floor = min(
                max(0.0, anchor_depth),
                max(0.0, root_depth - contact.get("prefix_length", 0.0)))
            possible_depth = max(0.0, depth - fixed_floor)
            pair = (contact["link"][0], collider["bone"])
            if contact.get("entry_push"):
                contact.setdefault("touch_now", set()).add(pair)
                contact["entering"] = pair not in contact.get("touch_prev", ())
            delta = (None if possible_depth <= 1.0e-9 else
                     _to_direction_space(normal, direction, possible_depth,
                                         s, length, contact))
            contact["entering"] = False
            slope = contact.get("exit_slope") or 0.0
            if slope > 0.0 and anchor_depth > 0.0:
                # the closest point of a link lying along the capsule axis is
                # degenerate (lever 0, "unresolvable"); the tip is not
                tip_depth, tip_normal, _tip_s = _probe(
                    collider, tip, tip, contact["radius"], contact["margin"])
                allowed = max(0.0, fixed_floor - slope * length)
                if tip_normal is not None and tip_depth - allowed > 1.0e-9:
                    out = _to_direction_space(tip_normal, direction,
                                              tip_depth - allowed, 1.0,
                                              length, contact)
                    if out is not None and (delta is None
                                            or out.length > delta.length):
                        delta = out
            if delta is None:
                contact["unresolved"][0] += 1
                key = contact["link"][0]
                stuck = contact["stuck"]
                if depth > stuck.get(key, 0.0):
                    stuck[key] = depth
                continue
            add = add + delta
        if not touching:
            break
        hits = touching
        total = acc.copy()
        if contact.get("measure"):
            break
        acc = acc / touching
        add = add / touching
        moved = direction + add * min(acc.length, 1.0)
        if moved.length > 1.0e-9:
            direction = moved.normalized()
    return direction, total, hits, deepest


def _deepest(direction, anchor, length, contact):
    """How far inside any collider the link still is, in world metres."""
    tip = anchor + direction * length
    worst = 0.0
    for collider in contact["colliders"]:
        depth, normal, _s = _probe(collider, anchor, tip, contact["radius"],
                                   contact["margin"])
        if normal is not None and depth > worst:
            worst = depth
    return worst


def sample_colliders(armature, groups=None):
    """The ``srs_col_*`` bones as plain world-space capsules, this frame.

    Read once per frame and shared by every chain: the body moves, but it moves
    the same way for all of them. A collider is a BONE, so it follows the rig
    with no mesh evaluation and there is no per-object visibility flag that can
    silently freeze it -- but the ARMATURE still has to be evaluable, which
    :func:`bake_many` asserts.
    """
    out = []
    if armature is None or armature.type != "ARMATURE":
        return out
    wanted = set(groups) if groups else None
    axis_y = mathutils.Vector((0.0, 1.0, 0.0))
    for pose_bone in armature.pose.bones:
        if not pose_bone.name.startswith(COLLIDER_PREFIX):
            continue
        if pose_bone.get("srs_col_enable", True) is False:
            continue
        group = str(pose_bone.get("srs_col_group", ""))
        if wanted is not None and group not in wanted:
            continue
        matrix = armature.matrix_world @ pose_bone.matrix
        axis = matrix.to_3x3() @ axis_y
        scale = axis.length
        if scale <= 1.0e-9:
            continue
        head = matrix.translation.copy()
        tail = head + axis.normalized() * (pose_bone.bone.length * scale)
        span = tail - head
        bone = pose_bone.bone
        radius = max(bone.head_radius, bone.tail_radius) * scale
        if radius <= 1.0e-9:
            continue
        out.append({
            "bone": pose_bone.name, "group": group,
            "a": head, "b": tail,
            "r": radius,
            "inside": bool(pose_bone.get("srs_col_inside", False)),
            "fallback": _any_perp(span) if span.length > 1.0e-9
            else mathutils.Vector((0.0, 0.0, 1.0)),
        })
    return out


def rest_colliders(armature):
    """The capsules as :func:`sample_colliders` builds them, but at the rig's REST pose."""
    out = []
    axis_y = mathutils.Vector((0.0, 1.0, 0.0))
    for pose_bone in armature.pose.bones:
        if not pose_bone.name.startswith(COLLIDER_PREFIX) or pose_bone.get("srs_col_enable", True) is False:
            continue
        bone = pose_bone.bone
        matrix = armature.matrix_world @ bone.matrix_local
        axis = matrix.to_3x3() @ axis_y
        scale = axis.length
        if scale <= 1.0e-9:
            continue
        head = matrix.translation.copy()
        out.append({"bone": pose_bone.name, "a": head, "b": head + axis.normalized() * (bone.length * scale),
                    "r": max(bone.head_radius, bone.tail_radius) * scale})
    return out


def _segment_distance(p0, p1, q0, q1):
    """Shortest distance between segments p0-p1 and q0-q1."""
    d1, d2, r = p1 - p0, q1 - q0, p0 - q0
    a, e, f = d1.dot(d1), d2.dot(d2), d2.dot(r)
    if a <= 1.0e-12 and e <= 1.0e-12:
        return r.length
    if a <= 1.0e-12:
        s, t = 0.0, max(0.0, min(1.0, f / e))
    else:
        c = d1.dot(r)
        if e <= 1.0e-12:
            s, t = max(0.0, min(1.0, -c / a)), 0.0
        else:
            b = d1.dot(d2)
            denom = a * e - b * b
            s = max(0.0, min(1.0, (b * f - c * e) / denom)) if denom > 1.0e-12 else 0.0
            t = (b * s + f) / e
            if t < 0.0:
                s, t = max(0.0, min(1.0, -c / a)), 0.0
            elif t > 1.0:
                s, t = max(0.0, min(1.0, (b - c) / a)), 1.0
    return ((p0 + d1 * s) - (q0 + d2 * t)).length


def measure_link_radii(armature, bones, percentile=0.9, min_weight=0.5):
    """Each link's half-thickness from the meshes it deforms, at rest. ``(radii, report)``.

    The vertices weighted to a link at ``min_weight`` or more, on every mesh with an Armature
    modifier on this rig, measured from the link's segment; the ``percentile`` of those distances
    (a stray vertex does not set the size). A link with no such vertices takes its neighbour's.
    """
    mw = armature.matrix_world
    segs = {}
    for name in bones:
        bone = armature.data.bones.get(name)
        if bone is not None:
            segs[name] = (mw @ bone.head_local, mw @ bone.tail_local)
    found = {name: [] for name in segs}
    meshes = []
    for obj in bpy.data.objects:
        if obj.type != "MESH" or not any(m.type == "ARMATURE" and m.object == armature for m in obj.modifiers):
            continue
        index = {g.index: g.name for g in obj.vertex_groups if g.name in segs}
        if not index:
            continue
        meshes.append(obj.name)
        for v in obj.data.vertices:
            for g in v.groups:
                name = index.get(g.group)
                if name is not None and g.weight >= min_weight:
                    a, b = segs[name]
                    p = obj.matrix_world @ v.co
                    ab = b - a
                    t = 0.0 if ab.length_squared <= 1.0e-12 else max(0.0, min(1.0, (p - a).dot(ab) / ab.length_squared))
                    found[name].append((p - (a + ab * t)).length)
    radii, last = [], None
    for name in bones:
        d = sorted(found.get(name) or ())
        value = d[min(len(d) - 1, int(percentile * (len(d) - 1)))] if d else None
        radii.append(value)
        if value is not None and last is None:
            last = value
    # gaps take the previous link's value (the first ones the first measured)
    filled, prev = [], last
    for value in radii:
        prev = value if value is not None else prev
        filled.append(prev if prev is not None else 0.0)
    return filled, {"meshes": meshes, "measured": sum(1 for v in radii if v is not None), "links": len(radii),
                    "max_mm": round(max(filled) * 1000, 1) if filled else 0.0}


def _link_radius(contact, index):
    radii = contact.get("radii")
    if radii:
        contact["radius"] = radii[min(index, len(radii) - 1)]


def rest_clearance(armature, bones, link_radius, margin, capsules=None):
    """``{capsule: scale}`` for every capsule that holds one of ``bones`` at rest: the factor on its
    radius that leaves the chain's rest pose clear by ``link_radius + margin``. 0 drops the capsule
    for this chain (a link lies on its axis)."""
    capsules = rest_colliders(armature) if capsules is None else capsules
    mw = armature.matrix_world
    links = []
    for k, name in enumerate(bones):
        bone = armature.data.bones.get(name)
        if bone is not None:
            radius = link_radius[min(k, len(link_radius) - 1)] if isinstance(link_radius, (list, tuple)) else link_radius
            links.append((mw @ bone.head_local, mw @ bone.tail_local, float(radius)))
    out = {}
    for c in capsules:
        if c["r"] <= 1.0e-9:
            continue
        worst = 1.0
        for a, b, rad in links:
            d = _segment_distance(a, b, c["a"], c["b"])
            if d < c["r"] + rad + margin:
                worst = min(worst, max(0.0, d - rad - margin) / c["r"])
        if worst < 1.0:
            out[c["bone"]] = round(worst, 4)
    return out


def contact_set(colliders, radius=None, **options):
    """Bundle colliders and the measured defaults into one plain dict."""
    out = dict(CONTACT)
    out.update({k: v for k, v in options.items() if v is not None})
    if radius is not None:
        out["radius"] = float(radius)
    out["colliders"] = list(colliders or ())
    out["unresolved"] = [0]
    out["deepest"] = [0.0]
    out["worst"] = {}
    out["stuck"] = {}
    out["link"] = [-1]
    out["frame"] = [-1]
    out.setdefault("measure", False)
    out["fallback_perp"] = _any_perp
    return out


def _spring_state(carried, contact=None):
    """Everything one chain carries between frames.

    ``loads`` is how hard gravity pulls at each joint: the length still hanging
    BELOW it, rescaled so the profile's MEAN is exactly 1.0. NOT divided by the
    joint's own link length -- that made the droop go as 1/L, and once the joints
    sat on polygon loops and element boundaries instead of an even division, one
    gravity value meant 47 different things inside one chain (measured on this
    character: a hair tail runs 1.73mm to 81.67mm). Rescaling by a constant 2.0
    would be right only for a long chain, because the mean of that is (n+1)/n --
    a two-bone hem would quietly get 1.5x its old pull and a one-bone zip 2x.
    """
    spans = [entry["length"] for entry in carried]
    total_span = sum(spans) or 1.0
    mean_span = max(total_span / len(spans), 1.0e-6)
    loads, hanging = [], total_span
    for span in spans:
        loads.append(hanging / total_span)
        hanging -= span
    scale = len(loads) / (sum(loads) or 1.0)
    state = {
        "directions": [(entry["tail"] - entry["head"]).normalized()
                       for entry in carried],
        "rates": [mathutils.Vector((0.0, 0.0, 0.0)) for _e in carried],
        "anchors": [entry["head"].copy() for entry in carried],
        "positions": [entry["tail"].copy() for entry in carried],
        "loads": [load * scale for load in loads],
        "mean_span": mean_span,
    }
    if contact is not None and contact.get("colliders"):
        # Frame frame_start never runs _advance -- bake_many seeds the state
        # instead -- so without this the first frame is keyed penetrating and
        # frame 2 jumps the tip out by the whole depth, measured 18-59mm.
        anchor = carried[0]["head"].copy()
        true_root = anchor.copy()
        prefix_length = 0.0
        for index, entry in enumerate(carried):
            length = max(entry["length"], 1.0e-6)
            direction = state["directions"][index]
            contact["link"][0] = index
            _link_radius(contact, index)
            contact["chain_root"] = true_root
            contact["prefix_length"] = prefix_length
            if direction.length <= 1.0e-9:
                state["anchors"][index] = anchor.copy()
                state["positions"][index] = anchor.copy()
                prefix_length += length
                continue
            direction, _n, _hits, _deep = _contact_sweeps(
                direction, anchor, length, contact)
            state["directions"][index] = direction
            state["anchors"][index] = anchor.copy()
            state["positions"][index] = anchor + direction * length
            anchor = state["positions"][index].copy()
            prefix_length += length
    state["previous"] = _frame_inputs(carried, contact)
    return state


def _frame_inputs(carried, contact):
    """This frame's carried links and capsules, kept for the next frame's substeps."""
    links = [(entry["head"].copy(), entry["tail"].copy()) for entry in carried]
    shapes = {}
    if contact is not None:
        shapes = {c["bone"]: c for c in contact.get("colliders") or ()}
    return links, shapes


def _lerp_capsule(old, new, t):
    if old is None:
        return new
    out = dict(new)
    out["a"] = old["a"].lerp(new["a"], t)
    out["b"] = old["b"].lerp(new["b"], t)
    return out


def _advance(state, carried, stiffness, damping, inertia, pull,
             contact=None, floor=None, mesh_floor=None, reach=None):
    """One frame; a colliding chain is solved in ``contact["substeps"]`` steps.

    With one step per frame a capsule is met only where the frame lands, so a
    whole contact is resolved in one turn of up to 53 degrees and the spring
    throws the link back the frame after. The substeps walk the carried links
    and the capsules linearly from last frame to this one. Rates stay in
    per-FRAME units between frames, and the per-step constants keep the
    frame's: damping compounds to the same per-frame loss, stiffness and pull
    scale with the step squared, drag with the step (the sideways shift it
    multiplies is already per step). Measured on the 05_17 tails with collision
    off: drag left unscaled moved the tip 80-95mm (mean) off the one-step solve
    and cut its acceleration p99 from 40 to 13mm, a different feel; scaled,
    12-13mm and 39mm. A chain that does not collide keeps the single step bit
    for bit.
    """
    if contact is not None and contact.get("entry_push"):
        # a new frame: what touched at the end of the last one is "already in contact"
        contact["touch_prev"] = contact.get("touch_now") or set()
        contact["touch_now"] = set()
    previous = state.get("previous")
    state["previous"] = _frame_inputs(carried, contact)
    count = int(contact.get("substeps") or 1) if contact is not None else 1
    if count <= 1 or not contact.get("colliders") or previous is None \
            or len(previous[0]) != len(carried):
        _advance_step(state, carried, stiffness, damping, inertia, pull,
                      contact=contact, floor=floor, mesh_floor=mesh_floor,
                      reach=reach)
        return
    old_links, old_shapes = previous
    shapes = contact["colliders"]
    rates = state["rates"]
    for index in range(len(rates)):
        rates[index] = rates[index] / count
    damping = 1.0 - (1.0 - damping) ** (1.0 / count)
    stiffness = stiffness / (count * count)
    pull = pull / (count * count)
    inertia = inertia / count
    # the report describes frames: what the steps in between record is dropped
    kept = (contact["unresolved"][0], contact["deepest"][0],
            dict(contact["worst"]), dict(contact["stuck"]),
            state.get("floor_hits"))
    contact["share"] = 1.0 / count
    try:
        for step in range(1, count):
            t = step / float(count)
            contact["colliders"] = [
                _lerp_capsule(old_shapes.get(c["bone"]), c, t) for c in shapes]
            between = [dict(entry, head=head.lerp(entry["head"], t),
                            tail=tail.lerp(entry["tail"], t))
                       for (head, tail), entry in zip(old_links, carried)]
            # the bone line keeps to the floor in every step; the mesh lift,
            # which also turns the link BEFORE, is a once-a-frame correction --
            # run every substep it set the belt straps bouncing (05_17: 9 and
            # 11 frames over 100mm became 52 and 41)
            _advance_step(state, between, stiffness, damping, inertia, pull,
                          contact=contact, floor=floor)
        contact["colliders"] = shapes
        contact["unresolved"][0], contact["deepest"][0] = kept[0], kept[1]
        contact["worst"].clear()
        contact["worst"].update(kept[2])
        contact["stuck"].clear()
        contact["stuck"].update(kept[3])
        if kept[4] is None:
            state.pop("floor_hits", None)
        else:
            state["floor_hits"] = kept[4]
        _advance_step(state, carried, stiffness, damping, inertia, pull,
                      contact=contact, floor=floor, mesh_floor=mesh_floor,
                      reach=reach)
    finally:
        contact["colliders"] = shapes
        contact["share"] = 1.0
        for index in range(len(rates)):
            rates[index] = rates[index] * count


def _advance_step(state, carried, stiffness, damping, inertia, pull,
                  contact=None, floor=None, mesh_floor=None, reach=None):
    """One step of the spring -- a frame, or a substep of one -- in DIRECTION space.

    World-space inertia counts the anchor's own motion as the link's velocity,
    and because each link's anchor is the previous link's tip, that error is
    amplified once per link: measured down ten links the tip orbited at 300mm a
    frame and never settled with the head already still.
    """
    directions = state["directions"]
    rates = state["rates"]
    anchors = state["anchors"]
    positions = state["positions"]
    loads = state["loads"]
    mean_span = state["mean_span"]
    state["floor_step"] = state.get("floor_step", 0) + 1
    anchor = carried[0]["head"].copy()
    true_root = anchor.copy()
    prefix_length = 0.0
    for index, entry in enumerate(carried):
        length = max(entry["length"], 1.0e-6)
        if contact is not None:
            contact["link"][0] = index
            _link_radius(contact, index)
            contact["chain_root"] = true_root
            contact["prefix_length"] = prefix_length
        goal = (entry["tail"] - entry["head"])
        if goal.length <= 1.0e-9:
            # Do NOT just skip: positions[index] would keep LAST frame's world
            # point and bake_many reads it unconditionally, pointing the link
            # at a stale target and carrying the error to every link below.
            # Collapsing it onto the anchor makes _local_turn return identity
            # and leaves parent_turn untouched. The guard is reachable from a
            # singular pose matrix (a zero scale on an axis), not only from a
            # zero-length bone -- 5.1.2 clamps Bone.length to 2e-06.
            anchors[index] = anchor.copy()
            positions[index] = anchor.copy()
            prefix_length += length
            continue
        goal = goal.normalized()
        shift = anchor - anchors[index]
        sideways = shift - directions[index] * shift.dot(directions[index])
        rates[index] *= (1.0 - damping)
        if contact is not None and contact.get("colliders") \
                and not contact.get("measure"):
            # (1) resolve the GOAL, so the spring's equilibrium sits on the
            #     surface instead of inside it. On its own this is not enough
            #     -- the spring overshoots past it -- but without it the spring
            #     pulls back in every frame.
            goal, _n, _hits, _deep = _contact_sweeps(goal, anchor, length,
                                                     contact)
        rates[index] += (goal - directions[index]) * stiffness
        # the /length here is exact kinematics and must stay: the unit direction
        # of a short link really does swing more for the same anchor shift
        rates[index] -= sideways / length * inertia
        rates[index] += pull * loads[index] / mean_span
        held = None
        if contact is not None and contact.get("rest"):
            held = state.setdefault("held", {}).get(index)
            if held is not None:
                inbound = rates[index].dot(held)
                if inbound < 0.0:
                    rates[index] -= held * inbound
        moved = directions[index] + rates[index]
        if moved.length > 1.0e-9:
            directions[index] = moved.normalized()
        if contact is not None and contact.get("colliders"):
            # (2) positional resolve, AFTER the normalise, so what is written to
            #     positions is already clear; and (3) take the inbound rate out,
            #     or stiffness keeps topping it up and the link buzzes.
            directions[index], total, hits, deep = _contact_sweeps(
                directions[index], anchor, length, contact)
            if deep > contact["deepest"][0]:
                contact["deepest"][0] = deep
            if contact.get("rest"):
                # only a contact made THIS step holds the link next step
                state.setdefault("held", {}).pop(index, None)
            if hits and total.length > 1.0e-9 \
                    and not contact.get("measure"):
                normal = total.normalized()
                tangential = normal - directions[index] * normal.dot(
                    directions[index])
                if tangential.length > 1.0e-6:
                    normal = tangential.normalized()
                    if contact.get("rest"):
                        state["held"][index] = normal.copy()
                    inbound = rates[index].dot(normal)
                    if inbound < 0.0:
                        rates[index] -= normal * inbound
                    slide = rates[index] - normal * rates[index].dot(normal)
                    rates[index] -= slide * contact["friction"]
        if floor is not None and anchor.z > floor - FLOOR_REACH:
            # The floor is a plane, not a capsule: a link whose tip would end
            # below it is turned about its own anchor until the tip rests on it,
            # keeping its heading, and its downward rate is dropped so the spring
            # does not push it back through next frame. The anchor of the link
            # after a resting one sits ON the floor, so "above" must include it:
            # a strict test let every link after the first one fall through
            # (measured, 79_22: the strap still 73mm under). An anchor deeper than
            # FLOOR_REACH is the body under the floor, which turning cannot fix.
            info = (reach or {}).get(entry["bone"].name) if mesh_floor is not None else None
            points = own = None
            if info is not None:
                points, own = info["lift"], info["own"]
                # once per link: how far any of its points can be from its head
                bounds = state.setdefault("reach_bound", {})
                bound = bounds.get(entry["bone"].name)
                if bound is None:
                    frame = entry["matrix"].to_3x3()
                    bound = bounds[entry["bone"].name] = max(
                        [(frame @ p).length for p in list(points) + list(own)] or [0.0])
                if anchor.z - bound >= mesh_floor and anchor.z - length >= floor:
                    points, own = (), ()
            if points:
                # the mesh, not only the bone line: a strap 17mm wider than its
                # bone went 13mm under the floor with the line resting on it
                heading = _floor_heading(state, index, directions[index], goal)
                lifted = _lift_to_floor(entry, directions[index], heading, anchor,
                                        length, floor, mesh_floor, points)
                if lifted is not None:
                    directions[index] = lifted
                    _rest_on_floor(state, index, heading)
            if own and index > 0:
                # The loop at this link's head leans with THIS link, so the link
                # before had to guess it. If it guessed low, turn that link up by
                # the shortfall and place this one again.
                dip = mesh_floor - _lowest(entry, directions[index], anchor, own)
                if dip > 1.0e-4:
                    before = carried[index - 1]
                    before_length = max(before["length"], 1.0e-6)
                    base = anchors[index - 1]
                    wanted = max(-1.0, min(FLOOR_MAX_RISE, (anchor.z + dip - base.z) / before_length))
                    if wanted > directions[index - 1].z:
                        heading = _floor_heading(state, index - 1, directions[index - 1], goal)
                        along = heading * max(0.0, 1.0 - wanted * wanted) ** 0.5
                        directions[index - 1] = mathutils.Vector((along.x, along.y, wanted)).normalized()
                        _rest_on_floor(state, index - 1, heading)
                        positions[index - 1] = base + directions[index - 1] * before_length
                        anchor = positions[index - 1].copy()
                        if points:
                            heading = _floor_heading(state, index, directions[index], goal)
                            lifted = _lift_to_floor(entry, directions[index], heading, anchor,
                                                    length, floor, mesh_floor, points)
                            if lifted is not None:
                                directions[index] = lifted
                                _rest_on_floor(state, index, heading)
            tip_z = anchor.z + directions[index].z * length
            if not points and tip_z < floor:
                dz = max(-1.0, min(FLOOR_MAX_RISE, (floor - anchor.z) / length))
                heading = _floor_heading(state, index, directions[index], goal)
                flat = heading * max(0.0, 1.0 - dz * dz) ** 0.5
                directions[index] = mathutils.Vector((flat.x, flat.y, dz)).normalized()
                _rest_on_floor(state, index, heading)
        anchors[index] = anchor.copy()
        positions[index] = anchor + directions[index] * length
        anchor = positions[index].copy()
        prefix_length += length


def row_ready(row, placed):
    return all(k in placed for k in row["after"])


def bake_many(armature, jobs, frame_start, frame_end, step=1,
              collide=None):
    """Bake several chains with ONE scene evaluation per frame.

    ``(reports, error)`` where ``reports`` is a list in the order of ``jobs``.
    Each job is ``{"bones": [...], "stiffness": .., "damping": .., "gravity":
    .., "inertia": ..}``; anything missing takes :func:`bake`'s default.

    Baking one chain at a time re-evaluates the whole scene once per chain per
    frame, and on a heavy rig that IS the cost -- measured on this character,
    1.37 seconds per evaluated frame, so 17 chains over 505 frames spent 3.7
    hours doing the same 505 evaluations seventeen times. Every chain hangs off
    a body bone and none reads another chain's jiggle, so one cleared pose
    serves all of them.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    rows = []
    for job in jobs or ():
        chain = [n for n in job.get("bones") or ()
                 if armature.pose.bones.get(n) is not None]
        if not chain:
            continue
        rows.append({
            "job_index": len(rows),
            "chain": chain,
            "stiffness": max(0.0, min(1.0, float(job.get("stiffness", 0.35)))),
            "damping": max(0.0, min(1.0, float(job.get("damping", 0.15)))),
            "inertia": float(job.get("inertia", 0.6)),
            "gravity": float(job.get("gravity", 0.0)),
            "pull": mathutils.Vector(
                (0.0, 0.0, -abs(float(job.get("gravity", 0.0))) * 0.001)),
            "gravity_rest": bool(job.get("gravity_rest", False)),
            "rest_clear": bool(job.get("rest_clear", False)),
            "link_radii": [float(x) for x in job.get("link_radii") or ()] or None,
            "state": None, "solved": [], "travelled": [], "keyed": 0,
            "moved": [], "previous": None,
            "collide": job.get("collide"),
            "floor": (float(job["floor"]) if job.get("floor") is not None else None),
            "mesh_floor": (float(job["mesh_floor"]) if job.get("mesh_floor") is not None else None),
            "reach": job.get("reach"),
            "write": written_bones(armature, chain),
        })
    if not rows:
        return None, "None of those bones is on this armature"
    # the keys land in the rig's own slot, and never on top of hand keys: a chain
    # without a swing layer writes its links, so hand keys there would be overwritten
    bag, error = rig_channelbag(armature)
    if error:
        return None, error
    for row in rows:
        if swing_bones(armature, row["chain"]):
            continue
        hand = hand_curves(bag, row["write"])
        if hand:
            return None, ("Chain %s has hand keys on its links (%d curves). Give it a swing layer, or clear "
                          "them, before baking -- the bake would write over them. Nothing was changed."
                          % (row["chain"][0], len(hand)))

    # A chain hanging off another baked chain (a zip slider on a hem) has to read
    # its parent's SOLVED pose of the same frame, not the cleared one: solve the
    # parent first and re-evaluate before the child is read.
    owner = {name: k for k, row in enumerate(rows) for name in row["chain"]}
    for k, row in enumerate(rows):
        row["after"] = set()
        bone = armature.data.bones.get(row["chain"][0])
        parent = bone.parent if bone is not None else None
        while parent is not None:
            if parent.name in owner and owner[parent.name] != k:
                row["after"].add(owner[parent.name])
            parent = parent.parent
    ordered, placed = [], set()
    while len(ordered) < len(rows):
        ready = [k for k in range(len(rows)) if k not in placed and row_ready(rows[k], placed)]
        if not ready:
            # a cycle cannot be solved in order; keep the rest as they were
            ready = [k for k in range(len(rows)) if k not in placed]
        for k in ready:
            ordered.append(k)
            placed.add(k)
    order_back = {k: n for n, k in enumerate(ordered)}
    rows = [rows[k] for k in ordered]
    for row in rows:
        row["after"] = {order_back[k] for k in row["after"]}
    nested = any(row["after"] for row in rows)
    everything = [name for row in rows for name in row["chain"]]
    # what the bake turns and keys: the links, or a swing chain's swing bones. Only these are
    # cleared each frame, so a swing chain's links keep their hand keys in the carried pose.
    writable = [name for row in rows for name in row["write"]]
    scene = bpy.context.scene
    saved_frame = scene.frame_current
    goals = goal_constraints(armature, everything)
    goals_before = [(con, con.mute) for _pb, con in goals]
    for _pb, con in goals:
        con.mute = True
    baked_ok = False

    # A hide_viewport-hidden armature hands back the PREVIOUSLY evaluated pose
    # from pose_bone.matrix, even after view_layer.update(), so the whole solve
    # runs against a frozen body and reads perfectly green on every other gate.
    # is_evaluated is False in exactly that case; hide_set, hide_render and
    # collection-exclude all stay live.
    evaluated = armature.evaluated_get(bpy.context.evaluated_depsgraph_get())
    if not getattr(evaluated, "is_evaluated", True):
        return None, ("The rig is hidden from the viewport, so its pose cannot "
                      "be evaluated and the solve would run against a frozen "
                      "body. Un-hide %s (the monitor icon) and bake again."
                      % armature.name)
    # a linked Action takes no keys (keyframe_insert skips it with a console warning only), so the
    # bake would report keys and write none: make it local, now that nothing else refuses
    _note, error = ensure_local_action(armature)
    if error:
        for con, was in goals_before:
            con.mute = was
        return None, error
    wants_contact = bool(collide) or any(
        isinstance(row["collide"], dict) for row in rows)
    if wants_contact and any(row["rest_clear"] for row in rows):
        at_rest = rest_colliders(armature)
        for row in rows:
            settings = row["collide"] if row["collide"] is not None else collide
            if not row["rest_clear"] or not settings:
                continue
            own = settings if isinstance(settings, dict) else {}
            row["rest_scale"] = rest_clearance(
                armature, row["chain"], row["link_radii"] or float(own.get("radius") or CONTACT["radius"]),
                float(own.get("margin") or CONTACT["margin"]), capsules=at_rest)
    for name in writable:
        pose_bone = armature.pose.bones[name]
        if pose_bone.rotation_mode != "QUATERNION":
            pose_bone.rotation_mode = "QUATERNION"

    # Solve first, key afterwards. Keying inside the loop feeds the result back:
    # the next scene.frame_set re-evaluates the curves just written, so the
    # "carried" reading is the previous frame's jiggle rather than the carried
    # configuration, and the chain compounds its own rotation. Measured that way
    # the tip ran 1020mm out on a 1174mm braid and never came back.
    try:
        for frame in range(int(frame_start), int(frame_end) + 1,
                           max(1, int(step))):
            scene.frame_set(frame)
            clear_pose(armature, writable)
            bpy.context.view_layer.update()
            # once per frame, shared by every chain: the body moves, but it
            # moves the same way for all of them
            shapes = sample_colliders(armature) if wants_contact else []
            stale = False
            for row_index, row in enumerate(rows):
                if nested and row["after"] and stale:
                    bpy.context.view_layer.update()
                    stale = False
                carried = _carried(armature, row["chain"])
                if not carried:
                    continue
                contact = None
                if shapes:
                    # None means INHERIT the call's setting; False means off.
                    # `x or y or {}` turned "off" into "every default, no group
                    # filter", and a chain that had been switched off kept
                    # colliding with all 25 capsules.
                    settings = row["collide"]
                    if settings is None:
                        settings = collide
                    if settings is not None and settings is not False:
                        contact = row.get("contact")
                        if contact is None:
                            contact = contact_set(
                                shapes,
                                radius=settings.get("radius"),
                                margin=settings.get("margin"),
                                relax=settings.get("relax"),
                                sweeps=settings.get("sweeps"),
                                friction=settings.get("friction"),
                                clamp=settings.get("clamp"),
                                clamp_mm=settings.get("clamp_mm"),
                                lever_floor=settings.get("lever_floor"),
                                substeps=settings.get("substeps"),
                                tip_mm=settings.get("tip_mm"),
                                exit_slope=settings.get("exit_slope"),
                                rest=settings.get("rest"),
                                entry_push=settings.get("entry_push"),
                                measure=settings.get("measure"),
                                radii=row.get("link_radii"))
                            row["contact"] = contact
                        groups = settings.get("groups")
                        if groups:
                            wanted = set(groups)
                            contact["colliders"] = [
                                c for c in shapes if c["group"] in wanted]
                        else:
                            contact["colliders"] = shapes
                        scale = row.get("rest_scale")
                        if scale:
                            # this chain's own capsules: shrunk until its rest pose is clear
                            contact["colliders"] = [
                                dict(c, r=c["r"] * scale[c["bone"]]) if c["bone"] in scale else c
                                for c in contact["colliders"]
                                if scale.get(c["bone"], 1.0) > 0.0]
                if contact is not None:
                    contact["frame"][0] = frame
                pull = row["pull"]
                if row["gravity_rest"] and carried and pull.length > 0.0:
                    # gravity the rest shape already carries, turned with the root: the turn
                    # since rest is the root's carried rotation against its rest rotation
                    root_bone = carried[0]["bone"].bone
                    if "rest_rot" not in row:
                        row["rest_rot"] = (armature.matrix_world @ root_bone.matrix_local).to_3x3().normalized()
                    turn = carried[0]["matrix"].to_3x3().normalized() @ row["rest_rot"].inverted()
                    pull = pull - turn @ pull
                if row["state"] is None:
                    row["state"] = _spring_state(carried, contact=contact)
                    if row["floor"] is not None and starts_under_floor(
                            carried, row["floor"] if row["mesh_floor"] is None else row["mesh_floor"],
                            row["reach"]):
                        # this model does not stand on that floor: read at the first
                        # frame of the bake, so the frame the bake is started from
                        # changes nothing
                        row["floor"] = row["mesh_floor"] = row["reach"] = None
                        row["under_floor"] = True
                else:
                    _advance(row["state"], carried, row["stiffness"],
                             row["damping"], row["inertia"], pull,
                             contact=contact, floor=row["floor"],
                             mesh_floor=row["mesh_floor"], reach=row["reach"])
                positions = row["state"]["positions"]
                # how far the furthest link moved since last frame. The tip
                # alone cannot see a mid-chain link resting on a shoulder.
                if row["previous"] is not None:
                    # per FRAME, not per solved sample: at step 16 the raw
                    # figure read 938.87mm for every fit in a sweep, which is
                    # the step and not the chain
                    row["moved"].append(round(max(
                        (positions[n] - row["previous"][n]).length * 1000.0
                        for n in range(len(positions))) / float(
                            max(1, int(step))), 5))
                row["previous"] = [p.copy() for p in positions]
                head = carried[0]["head"].copy()
                parent_turn = mathutils.Quaternion()
                targets = {n: armature.pose.bones[w] for n, w in zip(row["chain"], row["write"])}
                for index, entry in enumerate(carried):
                    local, parent_turn = _local_turn(entry, head,
                                                     positions[index],
                                                     parent_turn)
                    # a swing bone applies after the link's own rotation, which the carried
                    # frame already holds, so the same closed-form turn is right for both
                    targets[entry["bone"].name].rotation_quaternion = local
                    head = positions[index].copy()
                stale = True
                row["solved"].append(
                    (frame, [tuple(targets[entry["bone"].name].rotation_quaternion)
                             for entry in carried]))
                row["solved_names"] = [targets[entry["bone"].name].name for entry in carried]
                row["travelled"].append(
                    round((positions[-1] - carried[-1]["tail"]).length * 1000,
                          4))
        # Nothing below reads the evaluated pose, so writing the curves here
        # cannot disturb the solve.
        for row in rows:
            for frame, rotations in row["solved"]:
                for name, rotation in zip(row.get("solved_names") or row["write"], rotations):
                    pose_bone = armature.pose.bones.get(name)
                    if pose_bone is None:
                        continue
                    pose_bone.rotation_quaternion = rotation
                    pose_bone.keyframe_insert("rotation_quaternion",
                                              frame=frame, group=BAKE_GROUP)
                    row["keyed"] += 1
        baked_ok = True
    finally:
        if not baked_ok:
            for con, was in goals_before:
                con.mute = was
        scene.frame_set(saved_frame)
        for name in writable:
            pose_bone = armature.pose.bones.get(name)
            if pose_bone is not None:
                pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
        bpy.context.view_layer.update()

    reports = []
    for row in sorted(rows, key=lambda r: r["job_index"]):
        travelled = row["travelled"]
        moved = row["moved"]
        tail = moved[-20:] if moved else []
        contact = row.get("contact")
        report = {
            "bones": len(row["chain"]), "frames": len(travelled),
            "keys": row["keyed"], "stiffness": row["stiffness"],
            "damping": row["damping"], "gravity": row["gravity"],
            "inertia": row["inertia"],
            # NOT "settled": this is displacement from the CARRIED pose, and
            # gravity alone makes it large for a chain that has fully settled
            # (235.17mm at METAL with the tip moving 0.00000000mm a frame).
            "lag_mm": {"max": max(travelled) if travelled else 0.0,
                       "final": travelled[-1] if travelled else 0.0},
            # this is the one that means settled, over ALL links
            "settle_mm_per_frame": {
                "max": max(moved) if moved else 0.0,
                "last20": max(tail) if tail else 0.0},
            "collided": bool(contact),
            "floor_contacts": (row["state"] or {}).get("floor_hits", 0),
            "under_floor": bool(row.get("under_floor")),
        }
        if contact is not None:
            report["penetration_mm"] = round(contact["deepest"][0] * 1000.0, 4)
            if row.get("rest_scale"):
                report["rest_clear"] = dict(row["rest_scale"])
            report["unresolved_contacts"] = contact["unresolved"][0]
            report["colliders"] = len(contact["colliders"])
            report["worst_contact"] = dict(contact["worst"])
            # a contact at a link's own anchor cannot be resolved by rotating
            # that link -- it belongs to the parent, and the chain's root
            # belongs to the body
            stuck = contact["stuck"]
            report["stuck_links"] = sorted(
                ({"link": k, "depth_mm": round(v * 1000.0, 2)}
                 for k, v in stuck.items()),
                key=lambda row: -row["depth_mm"])[:6]
        reports.append(report)
    return reports, ""


def bake(armature, bones, frame_start, frame_end, stiffness=0.35, damping=0.15,
         gravity=0.0, inertia=0.6, step=1, collide=None):
    """Integrate the spring over a frame range and key the result.

    ``(report, error)``. The chain starts exactly where the head carries it, so
    nothing snaps into place on the first frame.

    ``stiffness`` is how hard each link is pulled back to where the head carries
    it, per frame; ``damping`` bleeds off the rate of turn. ``inertia`` is how
    much the link resists being dragged sideways, which is what makes hair swing
    when the head TRANSLATES rather than turns. ``gravity`` is in millimetres per
    frame squared down world Z, weighted at each joint by the length still
    hanging below it so that a chain hangs root-first and a finely divided root
    does not droop harder than a coarse tip -- a strand of hair does not need
    it, a heavy ornament does.

    One chain. For more than one, call :func:`bake_many` instead: it evaluates
    each frame once for all of them rather than once per chain, which on a heavy
    rig is the whole cost of a bake.
    """
    reports, error = bake_many(
        armature,
        [{"bones": bones, "stiffness": stiffness, "damping": damping,
          "gravity": gravity, "inertia": inertia, "collide": collide}],
        frame_start, frame_end, step=step)
    if error:
        return None, error
    return reports[0], ""

def _root_of(armature, key, prefix):
    if prefix == MARK:
        bones = marked_chains(armature).get(key)
        return armature.pose.bones.get(bones[0]) if bones else None
    return armature.pose.bones.get("%s_%s_01" % (prefix, key))


def settings_for(armature, key, prefix="hair"):
    """Per-chain stiffness stored on the chain's root bone, if it is set."""
    if armature is None:
        return {}
    root = _root_of(armature, key, prefix)
    if root is None:
        return {}
    return {name: root[prop] for name, prop in
            (("stiffness", CHAIN_STIFFNESS), ("damping", CHAIN_DAMPING),
             ("gravity", CHAIN_GRAVITY), ("inertia", CHAIN_INERTIA))
            if prop in root.keys()}


def store_settings(armature, key, prefix="hair", stiffness=None, damping=None,
                   gravity=None, inertia=None):
    """Keep a chain's spring settings on the rig, so a re-bake repeats itself.

    ``inertia`` belongs here as much as the other three. A long chain needs a
    different one from a short chain, and leaving it to the caller means the
    setting that made the braid settle is not in the file. Measured on a
    1.4m twelve-bone braid with the head swinging 38 degrees: at the 0.32/0.14/0.6
    default the tip ran 1085mm out and was still 157mm from rest when the motion
    stopped, which is a braid that never settles. At 0.80/0.50/0.30 it swings
    231mm and comes back to 2.7mm.
    """
    if armature is None:
        return None, "No armature"
    root = _root_of(armature, key, prefix)
    if root is None:
        return None, "No chain called %r under %r" % (key, prefix)
    if stiffness is not None:
        root[CHAIN_STIFFNESS] = float(stiffness)
    if damping is not None:
        root[CHAIN_DAMPING] = float(damping)
    if gravity is not None:
        root[CHAIN_GRAVITY] = float(gravity)
    if inertia is not None:
        root[CHAIN_INERTIA] = float(inertia)
    return {"chain": key, "stored": settings_for(armature, key, prefix)}, ""


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
