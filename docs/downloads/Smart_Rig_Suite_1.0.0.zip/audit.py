# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()


from datetime import datetime, timezone
from typing import Any, Iterable

import bpy

from .external_tools import (
    configured_body_mesh,
    embedded_registration_conflicts,
    external_conflicts,
    external_status,
    likely_armature,
    marker_names,
    selected_meshes,
)
from .preferences import get_preferences


def _armatures(scope: str = "ACTIVE") -> list[bpy.types.Object]:
    if scope == "ALL":
        return [obj for obj in bpy.data.objects if obj.type == "ARMATURE"]
    target = likely_armature()
    return [target] if target is not None else []


def proxy_mapping_audit(armatures: Iterable[bpy.types.Object] | None = None) -> dict[str, Any]:
    armatures = list(armatures) if armatures is not None else _armatures("ALL")
    issues: list[dict[str, str]] = []
    mappings = 0
    role_keys = ("proxy", "proxy_list", "button", "collec", "layer")
    for armature in armatures:
        if armature.pose is None:
            continue
        bone_names = {bone.name for bone in armature.pose.bones}
        collections = set()
        try:
            collections = {collection.name for collection in armature.data.collections_all}
        except Exception:
            try:
                collections = {collection.name for collection in armature.data.collections}
            except Exception:
                collections = set()
        for pose_bone in armature.pose.bones:
            roles = [key for key in role_keys if key in pose_bone.keys()]
            if not roles:
                continue
            mappings += 1
            if len(roles) > 1:
                issues.append(
                    {
                        "armature": armature.name,
                        "bone": pose_bone.name,
                        "type": "conflicting_roles",
                        "detail": ", ".join(roles),
                    }
                )
            proxy = str(pose_bone.get("proxy", "") or "").strip()
            if "proxy" in pose_bone.keys() and (not proxy or proxy not in bone_names):
                issues.append(
                    {
                        "armature": armature.name,
                        "bone": pose_bone.name,
                        "type": "missing_proxy_target",
                        "detail": proxy or "<empty>",
                    }
                )
            proxy_list = str(pose_bone.get("proxy_list", "") or "")
            if "proxy_list" in pose_bone.keys():
                names = [value.strip() for value in proxy_list.split(",") if value.strip()]
                if not names:
                    issues.append(
                        {
                            "armature": armature.name,
                            "bone": pose_bone.name,
                            "type": "empty_proxy_list",
                            "detail": "",
                        }
                    )
                for name in names:
                    if name not in bone_names:
                        issues.append(
                            {
                                "armature": armature.name,
                                "bone": pose_bone.name,
                                "type": "missing_proxy_list_target",
                                "detail": name,
                            }
                        )
            button = str(pose_bone.get("button", "") or "").strip()
            if "button" in pose_bone.keys() and (not button or bpy.data.texts.get(button) is None):
                issues.append(
                    {
                        "armature": armature.name,
                        "bone": pose_bone.name,
                        "type": "missing_button_text",
                        "detail": button or "<empty>",
                    }
                )
            collection = str(pose_bone.get("collec", "") or "").strip()
            if "collec" in pose_bone.keys() and (not collection or collection not in collections):
                issues.append(
                    {
                        "armature": armature.name,
                        "bone": pose_bone.name,
                        "type": "missing_bone_collection",
                        "detail": collection or "<empty>",
                    }
                )
    return {"mappings": mappings, "issues": issues, "issue_count": len(issues)}


def repair_stale_proxy_mappings(armature: bpy.types.Object) -> dict[str, int]:
    if armature.type != "ARMATURE" or armature.pose is None:
        return {"removed": 0, "pruned": 0}
    bone_names = {bone.name for bone in armature.pose.bones}
    collections = set()
    try:
        collections = {collection.name for collection in armature.data.collections_all}
    except Exception:
        try:
            collections = {collection.name for collection in armature.data.collections}
        except Exception:
            collections = set()
    removed = 0
    pruned = 0
    for pose_bone in armature.pose.bones:
        proxy = str(pose_bone.get("proxy", "") or "").strip()
        if "proxy" in pose_bone.keys() and (not proxy or proxy not in bone_names):
            try:
                del pose_bone["proxy"]
                removed += 1
            except Exception:
                pass
        if "proxy_list" in pose_bone.keys():
            names = [value.strip() for value in str(pose_bone.get("proxy_list", "") or "").split(",") if value.strip()]
            valid = [name for name in names if name in bone_names]
            if valid != names:
                if valid:
                    pose_bone["proxy_list"] = ",".join(valid)
                    pruned += len(names) - len(valid)
                else:
                    try:
                        del pose_bone["proxy_list"]
                        removed += 1
                    except Exception:
                        pass
        button = str(pose_bone.get("button", "") or "").strip()
        if "button" in pose_bone.keys() and (not button or bpy.data.texts.get(button) is None):
            try:
                del pose_bone["button"]
                removed += 1
            except Exception:
                pass
        collection = str(pose_bone.get("collec", "") or "").strip()
        if "collec" in pose_bone.keys() and (not collection or collection not in collections):
            try:
                del pose_bone["collec"]
                removed += 1
            except Exception:
                pass
    return {"removed": removed, "pruned": pruned}


def driver_constraint_audit(armatures: Iterable[bpy.types.Object] | None = None) -> dict[str, Any]:
    armatures = list(armatures) if armatures is not None else _armatures("ALL")
    invalid_drivers: list[dict[str, str]] = []
    broken_constraints: list[dict[str, str]] = []
    target_constraints = {
        "COPY_LOCATION",
        "COPY_ROTATION",
        "COPY_SCALE",
        "COPY_TRANSFORMS",
        "LIMIT_DISTANCE",
        "TRACK_TO",
        "DAMPED_TRACK",
        "LOCKED_TRACK",
        "STRETCH_TO",
        "CHILD_OF",
        "ARMATURE",
        "IK",
        "SPLINE_IK",
        "ACTION",
        "TRANSFORM",
        "SHRINKWRAP",
    }
    for armature in armatures:
        animation_data = armature.animation_data
        if animation_data is not None:
            for fcurve in animation_data.drivers:
                try:
                    valid = bool(fcurve.is_valid)
                except Exception:
                    valid = True
                if not valid:
                    invalid_drivers.append(
                        {
                            "object": armature.name,
                            "data_path": fcurve.data_path,
                            "array_index": str(fcurve.array_index),
                        }
                    )
        if armature.pose is None:
            continue
        for pose_bone in armature.pose.bones:
            for constraint in pose_bone.constraints:
                if constraint.type not in target_constraints or not hasattr(constraint, "target"):
                    continue
                try:
                    target = constraint.target
                except Exception:
                    target = None
                # Spline IK can validly use a curve target but not None.
                if target is None:
                    broken_constraints.append(
                        {
                            "object": armature.name,
                            "bone": pose_bone.name,
                            "constraint": constraint.name,
                            "type": constraint.type,
                        }
                    )
    return {
        "invalid_drivers": invalid_drivers,
        "invalid_driver_count": len(invalid_drivers),
        "broken_constraints": broken_constraints,
        "broken_constraint_count": len(broken_constraints),
    }


def _deform_bone_names_for_mesh(mesh: bpy.types.Object) -> set[str]:
    names: set[str] = set()
    for modifier in mesh.modifiers:
        if modifier.type != "ARMATURE" or modifier.object is None or modifier.object.type != "ARMATURE":
            continue
        names.update(bone.name for bone in modifier.object.data.bones if bone.use_deform)
    return names


def weight_quality_audit(
    meshes: Iterable[bpy.types.Object] | None = None,
    *,
    tolerance: float = 0.001,
    maximum_influences: int = 4,
    tiny_threshold: float = 0.0001,
) -> dict[str, Any]:
    meshes = list(meshes) if meshes is not None else selected_meshes()
    if not meshes:
        meshes = [obj for obj in bpy.data.objects if obj.type == "MESH"]
    result: dict[str, Any] = {"meshes": {}, "summary": {}}
    total_unweighted = 0
    total_non_normalized = 0
    total_over_limit = 0
    total_tiny = 0
    for mesh in meshes:
        if mesh.type != "MESH":
            continue
        group_names = {group.index: group.name for group in mesh.vertex_groups}
        deform_bones = _deform_bone_names_for_mesh(mesh)
        unweighted: list[int] = []
        non_normalized: list[int] = []
        over_limit: list[int] = []
        tiny: list[dict[str, Any]] = []
        for vertex in mesh.data.vertices:
            weights = [(group_names.get(item.group, ""), float(item.weight)) for item in vertex.groups if item.weight > 0.0]
            deform_weights = weights
            if deform_bones:
                deform_weights = [(name, weight) for name, weight in weights if name in deform_bones]
            if not deform_weights:
                unweighted.append(vertex.index)
                continue
            total = sum(weight for _, weight in deform_weights)
            if abs(total - 1.0) > tolerance:
                non_normalized.append(vertex.index)
            if len(deform_weights) > maximum_influences:
                over_limit.append(vertex.index)
            for name, weight in deform_weights:
                if 0.0 < weight < tiny_threshold:
                    tiny.append({"vertex": vertex.index, "group": name, "weight": weight})
        unknown_groups = sorted(
            group.name for group in mesh.vertex_groups if deform_bones and group.name not in deform_bones
        )
        result["meshes"][mesh.name] = {
            "vertices": len(mesh.data.vertices),
            "unweighted": unweighted,
            "non_normalized": non_normalized,
            "over_influence_limit": over_limit,
            "tiny_weights": tiny,
            "groups_without_deform_bones": unknown_groups,
        }
        total_unweighted += len(unweighted)
        total_non_normalized += len(non_normalized)
        total_over_limit += len(over_limit)
        total_tiny += len(tiny)
    result["summary"] = {
        "mesh_count": len(result["meshes"]),
        "unweighted_vertices": total_unweighted,
        "non_normalized_vertices": total_non_normalized,
        "vertices_over_influence_limit": total_over_limit,
        "tiny_weight_entries": total_tiny,
    }
    return result


def marker_audit() -> dict[str, Any]:
    groups = marker_names()
    return {
        key: {
            "present": [name for name in names if bpy.data.objects.get(name) is not None],
            "missing": [name for name in names if bpy.data.objects.get(name) is None],
        }
        for key, names in groups.items()
    }



def build_workflow_preflight(configured_ai_path: str) -> dict[str, Any]:
    """Return a compact go/no-go report before an external rig workflow."""
    status = external_status(configured_ai_path)
    armature = likely_armature()
    body = configured_body_mesh()
    if body is None:
        active = getattr(bpy.context, "active_object", None)
        body = active if active is not None and active.type == "MESH" else None
    markers = marker_audit()
    conflicts = external_conflicts()
    embedded = embedded_registration_conflicts()
    checks = {
        "auto_rig_pro_external": status.auto_rig_pro.available,
        "rig_tools_external": status.rig_tools.available,
        "proxy_picker_external": status.proxy_picker.available,
        "ai_runtime_valid": status.ai_runtime.valid,
        "target_armature": armature is not None,
        "target_body_mesh": body is not None,
        "required_body_markers": not markers["required_body"]["missing"],
        "no_external_conflicts": not conflicts,
        "no_embedded_registrations": not embedded,
    }
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "ready_for_reference_rig": checks["auto_rig_pro_external"] and checks["no_embedded_registrations"],
        "ready_for_body_ai": checks["auto_rig_pro_external"] and checks["ai_runtime_valid"] and checks["target_body_mesh"],
        "ready_for_detection": checks["auto_rig_pro_external"] and checks["required_body_markers"],
        "ready_for_animation_tools": checks["rig_tools_external"] and checks["target_armature"],
        "ready_for_proxy_picker": checks["proxy_picker_external"] and checks["target_armature"],
        "checks": checks,
        "target_armature": armature.name if armature is not None else "",
        "target_body_mesh": body.name if body is not None else "",
        "external_tools": status.to_dict(),
        "marker_state": markers,
        "warnings": conflicts,
        "embedded_registrations": embedded,
    }

def build_full_report(configured_ai_path: str) -> dict[str, Any]:
    preferences = get_preferences()
    tolerance = float(getattr(preferences, "weight_sum_tolerance", 0.001) if preferences else 0.001)
    influence_limit = int(getattr(preferences, "maximum_influences", 4) if preferences else 4)
    tiny_threshold = float(getattr(preferences, "tiny_weight_threshold", 0.0001) if preferences else 0.0001)
    status = external_status(configured_ai_path)
    armatures = _armatures("ALL")
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "blender_version": ".".join(str(part) for part in bpy.app.version),
        "external_tools": {**status.to_dict(), "warnings": external_conflicts()},
        "scene": {
            "name": bpy.context.scene.name if getattr(bpy.context, "scene", None) else "",
            "filepath": bpy.data.filepath,
            "object_count": len(bpy.data.objects),
            "armature_count": len(armatures),
        },
        "markers": marker_audit(),
        "proxy_picker": proxy_mapping_audit(armatures),
        "rig_health": driver_constraint_audit(armatures),
        "weights": weight_quality_audit(
            tolerance=tolerance,
            maximum_influences=influence_limit,
            tiny_threshold=tiny_threshold,
        ),
    }
