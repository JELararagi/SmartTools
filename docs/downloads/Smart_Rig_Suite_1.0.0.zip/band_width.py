# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Keep a fabric band's width while the limb under it bends.

A band wrapped round a sleeve (denim-like, it must not stretch across its width)
gets pulled wider and narrower by ordinary skin weights at the elbow. Measured on
MIK, 2026-10-02 (Codex trial, accepted by the user as "かなりよくなりました"):
giving every vertex of one cross-section the section's average weights, and
deforming those vertices with a dual-quaternion Armature modifier masked to them,
kept the cross-width within 0.001043 % over 14 elbow angles. The same measurement
on the previous weights reached 400.303 % at 145 degrees.

What the method does not do: it does not stop the band from intersecting the
sleeve (the left-arm trial went from 430 to 792 sleeve/band triangle pairs at
90 degrees), and it says nothing about the band's length or the subdivided surface.

A *section* is one row of the band across its width. Rows come from the UV layout,
so the band must be unwrapped as a strip whose width runs along one UV axis.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import collections
import heapq

import bpy
from mathutils import Matrix

MASK_PREFIX = "SRS_band_width"
DQ_PREFIX = "SRS band width DQ "
# Groups of a follower that moves only part of a sleeve (cuff_push.swing_follow). A locked
# section that carries some of it takes the weights of its vertex that carries the most --
# see lock_width.
FOLLOW_PREFIXES = ("cuff_swing",)


def island_vertices(mesh_object, seeds):
    """Every vertex connected to any vertex in ``seeds``."""
    me = mesh_object.data
    parent = list(range(len(me.vertices)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for e in me.edges:
        a, b = find(e.vertices[0]), find(e.vertices[1])
        if a != b:
            parent[a] = b
    roots = {find(i) for i in seeds}
    return [i for i in range(len(me.vertices)) if find(i) in roots]


def uv_sections(mesh_object, ids, axis="V", min_verts=7, min_width=0.025):
    """Split the band vertices ``ids`` into cross-width rows using the active UV map.

    A UV seam stores one vertex in two rows, so rows that share a vertex are merged
    first; a vertex must belong to exactly one section. Rows narrower than
    ``min_width`` (object units) or with fewer than ``min_verts`` vertices are
    holes/ends and are folded into the nearest real row.
    """
    me = mesh_object.data
    if me.uv_layers.active is None:
        return [], "The band has no UV map."
    k = 1 if axis == "V" else 0
    ss = set(ids)
    uv = collections.defaultdict(list)
    data = me.uv_layers.active.data
    for f in me.polygons:
        if f.vertices[0] in ss:
            for vi, li in zip(f.vertices, f.loop_indices):
                uv[vi].append(round(data[li].uv[k], 5))
    rows = collections.defaultdict(set)
    for i, coords in uv.items():
        for c in coords:
            rows[c].add(i)
    keys = list(rows)
    parent = {key: key for key in keys}

    def root(key):
        while parent[key] != key:
            key = parent[key]
        return key

    seen = {}
    for key in keys:
        for i in rows[key]:
            if i in seen:
                parent[root(key)] = root(seen[i])
            else:
                seen[i] = key
    merged = collections.defaultdict(set)
    values = collections.defaultdict(list)
    for key in keys:
        merged[root(key)].update(rows[key])
        values[root(key)].append(key)
    co = [v.co for v in me.vertices]
    good = []
    for key, vs in sorted(merged.items()):
        if len(vs) < min_verts:
            continue
        a, z = max(((a, z) for a in vs for z in vs), key=lambda az: (co[az[0]] - co[az[1]]).length)
        if (co[a] - co[z]).length > min_width:
            good.append((key, a, z))
    out, used = [], set()
    for key, a, z in good:
        pair = tuple(sorted((a, z)))
        if pair in used:
            continue
        used.add(pair)
        out.append({"key": key, "values": values[key], "a": a, "b": z, "ids": sorted(merged[key])})
    if not out:
        return [], "No cross-width rows found; check the UV axis."
    assigned = {i for g in out for i in g["ids"]}
    for i, coords in uv.items():
        if i in assigned:
            continue
        g = min(out, key=lambda g: min(abs(c - vv) for c in coords for vv in g["values"]))
        g["ids"].append(i)
        assigned.add(i)
    return out, ""


def width_paths(mesh_object, sections, rest):
    """Shortest edge path a->b inside each section, with its rest length."""
    sections = [g for g in sections if "a" in g and "b" in g]
    allowed_all = {i for g in sections for i in g["ids"]}
    adj = {i: [] for i in allowed_all}
    for e in mesh_object.data.edges:
        a, b = e.vertices
        if a in adj and b in adj:
            d = (rest[a] - rest[b]).length
            adj[a].append((b, d))
            adj[b].append((a, d))
    paths = []
    for g in sections:
        allowed = set(g["ids"])
        a, b = g["a"], g["b"]
        queue, dist, prev = [(0.0, a)], {a: 0.0}, {}
        while queue:
            cost, v = heapq.heappop(queue)
            if v == b:
                break
            if cost != dist[v]:
                continue
            for t, d in adj[v]:
                if t not in allowed:
                    continue
                nc = cost + d
                if nc < dist.get(t, float("inf")):
                    dist[t], prev[t] = nc, v
                    heapq.heappush(queue, (nc, t))
        if b not in dist:
            continue
        path = [b]
        while path[-1] != a:
            path.append(prev[path[-1]])
        path.reverse()
        paths.append({"vertices": path, "rest_length": dist[b]})
    return paths


def measure_width(positions, paths):
    ratios = []
    for p in paths:
        ids = p["vertices"]
        length = sum((positions[a] - positions[b]).length for a, b in zip(ids, ids[1:]))
        if p["rest_length"] > 0:
            ratios.append(length / p["rest_length"])
    if not ratios:
        return {"sections": 0, "maximum_error_percent": 0.0}
    return {"sections": len(ratios), "minimum_ratio": min(ratios), "maximum_ratio": max(ratios),
            "maximum_error_percent": max(abs(r - 1.0) for r in ratios) * 100.0}


def evaluated_positions(mesh_object):
    deps = bpy.context.evaluated_depsgraph_get()
    ev = mesh_object.evaluated_get(deps)
    me = ev.to_mesh()
    mw = mesh_object.matrix_world
    pos = [mw @ v.co for v in me.vertices]
    ev.to_mesh_clear()
    return pos


class NeutralPose:
    """Put every armature in its neutral pose (no action, identity pose) and restore it.

    The neutral rebind compares the band before and after the new modifiers, so it
    must run where the old weights left the band where the modeller put it.
    """

    def __enter__(self):
        self.saved = []
        for ob in bpy.data.objects:
            if ob.type != "ARMATURE":
                continue
            ad = ob.animation_data
            rec = {"ob": ob, "action": ad.action if ad else None,
                   "nla": [t.mute for t in ad.nla_tracks] if ad else [],
                   "pose": {pb.name: pb.matrix_basis.copy() for pb in ob.pose.bones}}
            if ad:
                ad.action = None
                for t in ad.nla_tracks:
                    t.mute = True
            for pb in ob.pose.bones:
                pb.matrix_basis = Matrix.Identity(4)
            ob.update_tag()
            self.saved.append(rec)
        bpy.context.view_layer.update()
        return self

    def __exit__(self, *exc):
        for rec in self.saved:
            ob = rec["ob"]
            for name, m in rec["pose"].items():
                pb = ob.pose.bones.get(name)
                if pb is not None:
                    pb.matrix_basis = m
            ad = ob.animation_data
            if ad:
                ad.action = rec["action"]
                for t, mute in zip(ad.nla_tracks, rec["nla"]):
                    t.mute = mute
            ob.update_tag()
        bpy.context.view_layer.update()
        return False


def lock_width(mesh_object, sections, rebind_iterations=3, lead=FOLLOW_PREFIXES, rest=None):
    """Apply the section skin to ``sections`` of ``mesh_object``.

    Idempotent per vertex: a second call extends the same mask and reuses the same
    DQ modifiers. Returns (report, error).

    A section is given its vertices' average weights -- except a section that carries
    some of a follower whose group starts with one of ``lead`` (a cuff that follows the
    hand's bend). That one takes the weights of its vertex carrying the most of it. The
    follower fades up the sleeve, so the average moves a rigid section less than the
    cuff end of the sleeve under it, and the band sinks in when the wrist bends back.
    Measured on MIK_131's arm bands, new band/coat crossings at 60 degrees of
    dorsiflexion: 23 / 14 with per-vertex shares (which tore the band: width error
    45 %, edges stretched 8.5 times), 79 / 77 with the average, 35 / 33 with the
    leading vertex, the width held to 0.001 % in every pose.

    The band is rebound so that it sits, in the neutral pose, where it sat before the
    call -- or at ``rest`` (world positions per vertex, from :func:`neutral_positions`)
    when the weights were already changed before it, as :func:`mirror_sections` does.
    That matters because a rig's helper bones need not be at their rest in the neutral
    pose: MIK's c_elbow_in_01.r sits 13.5 mm off it, and moving the right arm band's
    weight off that helper shifted the band 3.4 mm, which rebinding to the shape after
    the change kept. Only the Armature modifiers are evaluated, so every position lines
    up with the base mesh (a Subdivision modifier would renumber the vertices).
    """
    if not sections:
        return None, "No sections to lock."
    arm_mods = [m for m in mesh_object.modifiers if m.type == "ARMATURE" and not m.name.startswith(DQ_PREFIX)]
    if not arm_mods:
        return None, "The band has no Armature modifier."
    mask_name = MASK_PREFIX
    for m in arm_mods:
        if m.vertex_group and m.vertex_group != mask_name:
            return None, "Armature modifier '%s' already uses vertex group '%s'." % (m.name, m.vertex_group)
    ids = sorted({i for g in sections for i in g["ids"]})
    from . import costume_bind
    saved = costume_bind.visible_for_edit([mesh_object] + [m.object for m in arm_mods if m.object])
    others = _armature_only(mesh_object)
    try:
        return _lock_width(mesh_object, sections, arm_mods, mask_name, ids, rebind_iterations, lead, rest)
    finally:
        _restore_modifiers(others)
        costume_bind.restore_visibility(saved)


def _armature_only(mesh_object):
    hidden = [m for m in mesh_object.modifiers if m.type != "ARMATURE" and m.show_viewport]
    for m in hidden:
        m.show_viewport = False
    if hidden:
        bpy.context.view_layer.update()
    return hidden


def _restore_modifiers(hidden):
    for m in hidden:
        m.show_viewport = True
    if hidden:
        bpy.context.view_layer.update()


def neutral_positions(mesh_object):
    """World positions of every base vertex in the neutral pose, Armature modifiers only. For ``lock_width(rest=)``."""
    others = _armature_only(mesh_object)
    try:
        with NeutralPose():
            return evaluated_positions(mesh_object)
    finally:
        _restore_modifiers(others)


def _lock_width(mesh_object, sections, arm_mods, mask_name, ids, rebind_iterations, lead=FOLLOW_PREFIXES,
                target=None):
    bone_names = {b.name for o in bpy.data.objects if o.type == "ARMATURE" for b in o.data.bones}
    deps = bpy.context.evaluated_depsgraph_get()
    if not mesh_object.evaluated_get(deps).is_evaluated:
        # A hidden object is never evaluated: rest and posed positions would be
        # identical and every check below would pass while measuring nothing.
        return None, "The band is not evaluated by the view layer (hidden collection?)."
    with NeutralPose():
        rest = list(target) if target is not None else evaluated_positions(mesh_object)
        names = {g.index: g.name for g in mesh_object.vertex_groups}
        me = mesh_object.data
        leading = {index for index, name in names.items() if lead and name.startswith(tuple(lead))}
        for g in sections:
            avg = collections.defaultdict(float)
            n = float(len(g["ids"]))
            carried = {i: sum(vg.weight for vg in me.vertices[i].groups if vg.group in leading)
                       for i in g["ids"]} if leading else {}
            first = max(carried, key=carried.get) if carried else None
            if first is not None and carried[first] > 0.0:
                for vg in me.vertices[first].groups:
                    if names.get(vg.group) in bone_names:
                        avg[vg.group] = vg.weight
            else:
                for i in g["ids"]:
                    for vg in me.vertices[i].groups:
                        if names.get(vg.group) in bone_names:
                            avg[vg.group] += vg.weight / n
            for vg in mesh_object.vertex_groups:
                if vg.name in bone_names:
                    vg.remove(g["ids"])
            for index, w in avg.items():
                if w > 0.0:
                    mesh_object.vertex_groups[index].add(g["ids"], w, "REPLACE")
        mask = mesh_object.vertex_groups.get(mask_name) or mesh_object.vertex_groups.new(name=mask_name)
        mask.add(ids, 1.0, "REPLACE")
        for old in arm_mods:
            old.vertex_group = mask_name
            old.invert_vertex_group = True
            dq_name = DQ_PREFIX + old.name
            new = mesh_object.modifiers.get(dq_name)
            if new is None:
                new = mesh_object.modifiers.new(dq_name, "ARMATURE")
            new.object = old.object
            new.vertex_group = mask_name
            new.invert_vertex_group = False
            new.use_deform_preserve_volume = True
            new.use_vertex_groups = old.use_vertex_groups
            new.use_bone_envelopes = old.use_bone_envelopes
            mods = list(mesh_object.modifiers)
            want = mods.index(old) + 1
            have = mods.index(new)
            if have != want:
                mesh_object.modifiers.move(have, want if want < have else want - 1)
        bpy.context.view_layer.update()
        after = evaluated_positions(mesh_object)
        inv = mesh_object.matrix_world.inverted().to_3x3()
        delta = {i: inv @ (rest[i] - after[i]) for i in ids}
        for _ in range(rebind_iterations):
            keys = me.shape_keys.key_blocks if me.shape_keys else None
            for i, d in delta.items():
                if keys:
                    for kb in keys:
                        kb.data[i].co += d
                else:
                    me.vertices[i].co += d
            me.update()
            bpy.context.view_layer.update()
            after = evaluated_positions(mesh_object)
            delta = {i: inv @ (rest[i] - after[i]) for i in ids}
        residual_mm = max((d.length for d in delta.values()), default=0.0) * 1000.0
        paths = width_paths(mesh_object, sections, rest)
        width = measure_width(evaluated_positions(mesh_object), paths)
    return {"sections": len(sections), "vertices": len(ids), "rebind_residual_mm": residual_mm,
            "rest_width": width, "paths": len(paths)}, ""


CHAIN_PREFIXES = ("srs_chain", "hair_")


def material_island_sections(mesh_object, match="metal", threshold=0.95, ids=None,
                             skip_prefixes=CHAIN_PREFIXES):
    """Whole islands made of a hard material, each as one rigid 'section'.

    A buckle that shares one weight vector across two bones is still bent by
    linear blending at an elbow (MIK_124, 145 degrees: belt metal stretched up to
    38 %). Locked as one section it is deformed by a single dual quaternion, which
    is rigid.
    """
    me = mesh_object.data
    parent = list(range(len(me.vertices)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for e in me.edges:
        a, b = find(e.vertices[0]), find(e.vertices[1])
        if a != b:
            parent[a] = b
    face_total = collections.Counter()
    face_hard = collections.Counter()
    mats = [m.name.lower() if m else "" for m in me.materials]
    key = match.lower()
    for f in me.polygons:
        r = find(f.vertices[0])
        face_total[r] += 1
        if f.material_index < len(mats) and key in mats[f.material_index]:
            face_hard[r] += 1
    allowed = None if ids is None else set(ids)
    groups = collections.defaultdict(list)
    for i in range(len(me.vertices)):
        groups[find(i)].append(i)
    chain_groups = {g.index for g in mesh_object.vertex_groups if g.name.startswith(tuple(skip_prefixes))}
    out = []
    for r, verts in groups.items():
        if face_total[r] and face_hard[r] / face_total[r] >= threshold:
            if allowed is not None and not allowed.intersection(verts):
                continue
            # A piece hanging on a swing chain must keep swinging; never lock it.
            if chain_groups and any(vg.group in chain_groups and vg.weight > 0.0
                                    for i in verts for vg in me.vertices[i].groups):
                continue
            out.append({"key": "island_%d" % r, "ids": verts})
    return out


def _islands(mesh_object):
    me = mesh_object.data
    parent = list(range(len(me.vertices)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for e in me.edges:
        a, b = find(e.vertices[0]), find(e.vertices[1])
        if a != b:
            parent[a] = b
    return find


def island_sections(mesh_object, verts, axis="V", min_width=0.025):
    """Sections of one island. ``axis`` 'AUTO' takes the UV axis whose rows are shorter.

    ``(sections, axis used, error)``. Rows across a band's width are about as long as
    the band is wide; rows along it run round the limb. On MIK's six arm bands the
    shorter rows picked the axis the bands had been locked with on every one.
    """
    if axis != "AUTO":
        secs, err = uv_sections(mesh_object, verts, axis=axis, min_width=min_width)
        return secs, axis, err
    co = [v.co for v in mesh_object.data.vertices]
    best, last = None, ""
    for candidate in ("V", "U"):
        secs, err = uv_sections(mesh_object, verts, axis=candidate, min_width=min_width)
        if err or not secs:
            last = err or last
            continue
        lengths = sorted((co[g["a"]] - co[g["b"]]).length for g in secs)
        middle = lengths[len(lengths) // 2]
        if best is None or middle < best[0]:
            best = (middle, candidate, secs)
    if best is None:
        return [], None, last or "No cross-width rows found."
    return best[2], best[1], ""


def guess_sections(mesh_object, ids, min_width=0.025, match="metal", hard=True):
    """Sections for the band vertices ``ids`` without being told the UV axis. ``(sections, report)``.

    Hard-material islands are one section each (:func:`material_island_sections`);
    every other island is split by :func:`island_sections` with the axis guessed.
    """
    hard_sections = material_island_sections(mesh_object, match=match, ids=ids) if hard else []
    hard_ids = {i for s in hard_sections for i in s["ids"]}
    find = _islands(mesh_object)
    soft = collections.defaultdict(list)
    for i in ids:
        if i not in hard_ids:
            soft[find(i)].append(i)
    out, axes, failed = list(hard_sections), collections.Counter(), 0
    for verts in soft.values():
        secs, used, err = island_sections(mesh_object, verts, axis="AUTO", min_width=min_width)
        if err:
            failed += 1
            continue
        out.extend(secs)
        axes[used] += 1
    return out, {"hard": len(hard_sections), "axes": dict(axes), "islands_without_rows": failed}


def mirror_sections(mesh_object, sections, source="L", tolerance_mm=6.0):
    """Give each section on the other side the weights of its mirror section. ``(report, error)``.

    A band modelled by hand is rarely vertex-symmetric -- on MIK's arm bands 182 of
    2949 vertices had a partner within 0.5 mm -- but its sections are: each section is
    matched by its centre reflected across x = 0, within ``tolerance_mm`` (+x is the
    left, ARP's .l). The source section's average weights are copied with the side
    tags flipped. Refuses when a flipped bone is on none of the mesh's armatures: that
    group would deform nothing. Lock the width again afterwards, rebinding to where
    the band sat before: ``before = neutral_positions(mesh)`` first, then
    ``lock_width(mesh, sections, rest=before)``.
    """
    from mathutils import Vector
    from mathutils.kdtree import KDTree
    from .rig_hygiene import mirror_group_name

    if source not in ("L", "R"):
        return None, "source must be 'L' or 'R'"
    me = mesh_object.data
    mw = mesh_object.matrix_world
    bone_names = set()
    for m in mesh_object.modifiers:
        if m.type == "ARMATURE" and m.object is not None and m.object.type == "ARMATURE":
            bone_names |= {b.name for b in m.object.data.bones}
    names = {g.index: g.name for g in mesh_object.vertex_groups}

    def centre(ids):
        total = Vector()
        for i in ids:
            total += mw @ me.vertices[i].co
        return total / len(ids)

    sign = 1.0 if source == "L" else -1.0
    centres = [centre(g["ids"]) for g in sections]
    tol = tolerance_mm / 1000.0
    src = [k for k, c in enumerate(centres) if sign * c.x > tol]
    dst = [k for k, c in enumerate(centres) if -sign * c.x > tol]
    if not src or not dst:
        return None, "Need band sections on both sides."
    kd = KDTree(len(src))
    for k in src:
        kd.insert(centres[k], k)
    kd.balance()
    plan, missing, far = [], set(), 0
    for k in dst:
        c = centres[k]
        _co, j, d = kd.find(Vector((-c.x, c.y, c.z)))
        if j is None or d > tol:
            far += 1
            continue
        avg = collections.defaultdict(float)
        n = float(len(sections[j]["ids"]))
        for i in sections[j]["ids"]:
            for vg in me.vertices[i].groups:
                name = names.get(vg.group)
                if name in bone_names:
                    avg[mirror_group_name(name) or name] += vg.weight / n
        missing |= {name for name in avg if name not in bone_names}
        plan.append((sections[k]["ids"], dict(avg), d))
    if missing:
        return None, "Add the mirror bones first: %s." % ", ".join(sorted(missing)[:6])
    groups = {g.name: g for g in mesh_object.vertex_groups}
    for ids, avg, _d in plan:
        for g in mesh_object.vertex_groups:
            if g.name in bone_names:
                g.remove(ids)
        for name, w in avg.items():
            if w <= 1.0e-5:
                continue
            if name not in groups:
                groups[name] = mesh_object.vertex_groups.new(name=name)
            groups[name].add(ids, w, "REPLACE")
    return {"mirrored": len(plan), "unmatched": far, "source": source,
            "worst_match_mm": round(max((d for _i, _a, d in plan), default=0.0) * 1000.0, 2)}, ""


def selected_band_sections(mesh_object, axis="V", min_width=0.025):
    """Sections of every island that has a selected vertex."""
    seeds = [v.index for v in mesh_object.data.vertices if v.select]
    if not seeds:
        return [], "Select at least one vertex of each band (Edit Mode), then run in Object Mode."
    ids = island_vertices(mesh_object, seeds)
    parts = collections.defaultdict(list)
    # Rows are found per island so two bands never share a section.
    islands = {}
    me = mesh_object.data
    parent = list(range(len(me.vertices)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for e in me.edges:
        a, b = find(e.vertices[0]), find(e.vertices[1])
        if a != b:
            parent[a] = b
    for i in ids:
        islands.setdefault(find(i), []).append(i)
    out = []
    for verts in islands.values():
        secs, _used, err = island_sections(mesh_object, verts, axis=axis, min_width=min_width)
        if err:
            return [], err
        out.extend(secs)
    return out, ""
