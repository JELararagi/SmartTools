# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

from . import generation
from .lifecycle import (
    RegistrationConflict,
    register_classes,
    register_pointer_property,
    unregister_classes,
    unregister_owned_classes,
    unregister_owned_pointer_properties,
)


RIG_PRESETS = (
    ("human", "Human", "Add the external human reference rig"),
    ("free", "Free Form", "Add the external free-form reference rig"),
    ("dog", "Dog", "Add the external dog reference rig"),
    ("horse", "Horse", "Add the external horse reference rig"),
    ("bird", "Bird", "Add the external bird reference rig"),
    ("cs", "Custom Skeleton", "Add the external custom-skeleton reference rig"),
)

LIMB_PRESETS = (
    ("arm.l", "Arm (Left)", "Add the external left-arm reference limb"),
    ("arm.r", "Arm (Right)", "Add the external right-arm reference limb"),
    ("leg.l", "Leg (Left)", "Add the external left-leg reference limb"),
    ("leg.r", "Leg (Right)", "Add the external right-leg reference limb"),
    ("spine", "Spine", "Add the external FK spine reference limb"),
    ("head", "Head Limb", "Add the external head reference limb"),
    ("ears", "Ears", "Add the external ears reference limb"),
    ("breast", "Breast", "Add the external breast reference limb"),
    ("tail", "Tail Limb", "Add the external tail reference limb"),
    ("spline_ik", "Spline IK Chain", "Add the external spline-IK reference chain"),
    ("bbones", "Bendy Bone Chain", "Add the external bendy-bone reference chain"),
    ("kilt", "Kilt", "Add the external kilt reference module"),
)

IKFK_MODES = (
    ("ARM_FK_TO_IK", "Arm FK to IK", "Snap the active arm from FK to IK using the external rig tools"),
    ("ARM_IK_TO_FK", "Arm IK to FK", "Snap the active arm from IK to FK using the external rig tools"),
    ("LEG_FK_TO_IK", "Leg FK to IK", "Snap the active leg from FK to IK using the external rig tools"),
    ("LEG_IK_TO_FK", "Leg IK to FK", "Snap the active leg from IK to FK using the external rig tools"),
)

SNAP_MODES = (
    ("HEAD", "Head Lock", "Run the external head-lock snap on the selected compatible controller"),
    ("POLE", "Pole Control", "Run the external pole-controller snap on the selected compatible controller"),
    ("PIN", "Pin Control", "Run the external pin snap on the selected compatible controller"),
    ("REVERSED_SPINE", "Reversed Spine", "Run the external reversed-spine snap"),
)


RESCALE_MODES = (
    ("FACTOR", "Resize Factor", "Multiply every length by the factor"),
    ("HEIGHT", "Target Height", "Work the factor out from the current and the target height"),
)

RESCALE_BASES = (
    ("EXTENT", "Lowest to Highest", "From the lowest to the highest point of the selected meshes"),
    ("TOP", "Top Above Floor", "The highest point above the floor (world Z = 0)"),
)


def _poll_armature(_self, obj):
    return obj is not None and obj.type == "ARMATURE"


def _poll_mesh(_self, obj):
    return obj is not None and obj.type == "MESH"


def _persist_update(self, context) -> None:
    try:
        from . import persistence
        persistence.property_updated(self, context)
    except Exception:
        pass


def _state_save_update(self, context) -> None:
    try:
        from . import persistence
        persistence.property_updated(self, context, force=True)
    except Exception:
        pass


EYE_PIVOT_SOURCES = (
    ("ORIGIN", "Object Origin", "Use the eyeball object's own origin as the rotation pivot"),
    ("BBOX_CENTER", "Bounding Box Centre", "Use the centre of the eyeball mesh's bounding box"),
)


def _mesh_poll(_self, obj):
    return getattr(obj, "type", None) == "MESH"


class SRS_SceneSettings(bpy.types.PropertyGroup):
    ui_section_always_on: BoolProperty(
        name="Always-on Toggles",
        description=(
            "Open or close the top-level Always-on Toggles section. This changes only the N-panel fold state; "
            "it does not start any background feature by itself"
        ),
        default=False,
        update=_persist_update,
    )
    n_panel_state_save: BoolProperty(
        name="N-panel State Save",
        description=(
            "Function: save every editable Smart Rig N-panel and add-on setting immediately to "
            "Blender 5.1 config/Smart_Rig_Suite/Smart_Rig_Suite.json. The values are restored after Blender restarts, "
            "after a file is opened, and when the active scene changes. How to use: leave enabled for automatic "
            "preservation; disable it only when you intentionally want temporary unsaved panel changes"
        ),
        default=True,
        update=_state_save_update,
    )
    show_external: BoolProperty(
        name="External Tools Section",
        description="Open or close the External Tools section. This changes only the N-panel display state and does not scan or modify external add-on files",
        default=True,
        update=_persist_update,
    )
    show_build: BoolProperty(
        name="Rig Generation and Setup Section",
        description="Open or close the Rig Generation and Setup section. Expand it to prepare contexts and call separately installed rigging tools",
        default=True,
        update=_persist_update,
    )
    show_animation: BoolProperty(
        name="Rig Operation and Animation Section",
        description="Open or close the Rig Operation and Animation section. Expand it to access validated IK/FK, snap, and pose utility dispatch",
        default=False,
        update=_persist_update,
    )
    show_weight: BoolProperty(
        name="Skinning and Weight Section",
        description="Open or close the Skinning, Weight and Deformation section. Expand it to edit and audit vertex-group weights",
        default=False,
        update=_persist_update,
    )
    show_proxy: BoolProperty(
        name="Display, Selection and Rig UI Section",
        description="Open or close the Proxy Picker and rig-interface section. Expand it to audit or dispatch separately installed Proxy Picker functions",
        default=False,
        update=_persist_update,
    )
    show_ai: BoolProperty(
        name="AI Runtime Integration Section",
        description="Open or close the AI Runtime Integration section. Expand it to validate an external AI_win installation and dispatch supported workflows",
        default=False,
        update=_persist_update,
    )
    show_data: BoolProperty(
        name="Data, Validation and Settings Section",
        description="Open or close the Data, Validation and Settings section. Expand it to run audits, export reports, and clean only obsolete Smart Rig helper data",
        default=False,
        update=_persist_update,
    )
    show_body: BoolProperty(
        name='Body Rig Section',
        description='Open or close section 2, the body rig built with Auto-Rig Pro',
        default=False,
        update=_persist_update,
    )
    show_face: BoolProperty(
        name='Face and Eyes Section',
        description='Open or close section 3, the face and the eyes',
        default=False,
        update=_persist_update,
    )
    show_hair: BoolProperty(
        name='Hair, Costume and Hard Parts Section',
        description='Open or close section 4, hair, costume parts and hard parts',
        default=False,
        update=_persist_update,
    )
    show_physics: BoolProperty(
        name='Swing, Collision and Cloth Section',
        description='Open or close section 5, swing, collision and cloth',
        default=False,
        update=_persist_update,
    )
    show_c_steps: BoolProperty(
        name='Steps For A New Character',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_targets: BoolProperty(
        name='Workflow Targets Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_parts: BoolProperty(
        name='Parts Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_reference: BoolProperty(
        name='Reference Rig Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_shoe_lift: BoolProperty(
        name='Shoe Sole Lift Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_rescale: BoolProperty(
        name='Character Size Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_bind: BoolProperty(
        name='Binding Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_aux: BoolProperty(
        name='Auxiliary Bones Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_knee_split: BoolProperty(
        name='Knee Split Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_knee_profile: BoolProperty(
        name='Knee Profile Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_wrist: BoolProperty(
        name='Wrist Fold Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_weight_tool: BoolProperty(
        name='Weight Tool Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_hygiene: BoolProperty(
        name='Rig Hygiene Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_eye_ref: BoolProperty(
        name='Eye Rig Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_eye_bind: BoolProperty(
        name='Eyeball Binding Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_lid: BoolProperty(
        name='Eyelid Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_face_weight: BoolProperty(
        name='Face Weights Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_falloff: BoolProperty(
        name='Facial Reach Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_corrective: BoolProperty(
        name='Corrective Shape Keys Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_shadow: BoolProperty(
        name='Eyelid Shadow Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_hair: BoolProperty(
        name='Hair Chains Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_costume: BoolProperty(
        name='Costume Binding Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_chain: BoolProperty(
        name='Chain Builder Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_strip: BoolProperty(
        name='Strip Bones Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    fstrip_name: StringProperty(
        name="Follow Strip Name",
        description="Name used in the strip bones (c_<name>_NN_SS)",
        default="coat", update=_persist_update,
    )
    fstrip_angles: StringProperty(
        name="Follow Strip Angles",
        description="Where the strips sit around the part, in degrees (0 = +X, 90 = the back, -90 = the front), separated by commas",
        default="-60, 0, 45, 90, 135, 180, -120", update=_persist_update,
    )
    fstrip_segments: IntProperty(
        name="Bones per Follow Strip",
        description="How many controllers down each strip",
        default=2, min=1, max=8, update=_persist_update,
    )
    fstrip_blend_mm: FloatProperty(
        name="Follow Strip Top Blend",
        description="How far down from the top of each strip the part passes from its own weights onto the strips",
        default=40.0, min=0.0, soft_max=300.0, update=_persist_update,
    )
    strip_name: StringProperty(
        name="Strip Name",
        description="Name of the strip rig, used in its bone names (skirt, coat, cuff ...)",
        default="skirt", update=_persist_update,
    )
    strip_count: IntProperty(
        name="Strips",
        description="How many strips. For a left/right symmetrical set this is per side",
        default=6, min=1, max=64, update=_persist_update,
    )
    strip_subdiv: IntProperty(
        name="Bones per Strip",
        description="How many controllers down each strip",
        default=3, min=1, max=16, update=_persist_update,
    )
    strip_type_side: EnumProperty(
        name="Layout",
        description="Left and right halves, one full ring, or one side only",
        items=[
            ('SYMMETRICAL', "Left and right", "Mirrored left and right halves (a skirt)"),
            ('.x', "Full Ring", "One ring all the way round (a coat with an odd number of strips)"),
            ('.l', "Left only", "Only on the left (a left cuff)"),
            ('.r', "Right only", "Only on the right (a right cuff)"),
        ],
        default='SYMMETRICAL', update=_persist_update,
    )
    strip_collide_a: StringProperty(
        name="Keep Off",
        description="Bone the strips are kept off (a thigh, or the hand for a cuff). Empty for none",
        default="thigh.l", update=_persist_update,
    )
    strip_collide_b: StringProperty(
        name="Keep Off (2)",
        description="Second bone the strips are kept off. Empty uses the first one",
        default="thigh.r", update=_persist_update,
    )
    strip_angles: StringProperty(
        name="Strip Angles",
        description="Optional: where the strips sit around the part, in degrees (0 = +X, -90 = the front), separated "
                    "by commas. Empty spreads them evenly",
        default="", update=_persist_update,
    )
    strip_blend_mm: FloatProperty(
        name="Top Blend",
        description="How far down from the top of each strip the part passes from its own weights onto the strips",
        default=40.0, min=0.0, soft_max=300.0, update=_persist_update,
    )
    strip_on_pleats: BoolProperty(
        name="Columns on the Pleats",
        description="Read the strips off the garment's own folds: one strip per pleat panel, from the middle of its "
                    "top to the middle of its hem, round the body's axis. The count follows the garment. Needs the "
                    "Ring layout",
        default=False, update=_persist_update,
    )
    strip_collide_z: BoolProperty(
        name="Collide on Z",
        description="Auto-Rig Pro's Collide on Z: the strips also keep off the bones along Z, which helps when a "
                    "leg rotates far",
        default=False, update=_persist_update,
    )
    strip_top_from_under: BoolProperty(
        name="Top From Underneath",
        description="The top blend takes its weights from the garment underneath (both Armature stages) instead of "
                    "the part's own, so a skirt's top moves with the shorts' hip crease under it instead of being "
                    "pushed through by it",
        default=False, update=_persist_update,
    )
    lid_shadow_follow: FloatProperty(
        name="Follow",
        description=(
            "How much of the lid's travel the shadow takes. One slides it exactly as far as the lid "
            "margin goes; lower holds the shadow back"
        ),
        default=1.0, min=0.0, max=2.0, update=_persist_update,
    )
    lid_shadow_distance_mm: FloatProperty(
        name="Projector Distance",
        description="How far in front of the eye the projector sits. Orthographic, so this does not change the size",
        default=200.0, min=10.0, soft_max=2000.0, update=_persist_update,
    )
    lid_shadow_pull_mm: FloatProperty(
        name="Closed At",
        description="How far the lid control is pulled when the travel is measured",
        default=8.38, min=0.5, soft_max=40.0, update=_persist_update,
    )
    lid_shadow_remeasure: BoolProperty(
        name="Measure Again",
        description=(
            "Off: an existing projector keeps its rest placement and its lid expression and is only "
            "re-parented to the eye socket. On: place it from the eyeball's own UV layer and measure the "
            "lid again, as a first build does (Follow, Distance and Closed At only apply then)"
        ),
        default=False, update=_persist_update,
    )
    adjust_bones_threshold: FloatProperty(
        name="Only Bones Above",
        description="Ignore a bone the part barely uses",
        default=0.3, min=0.0, max=1.0, update=_persist_update,
    )
    roll_midline: BoolProperty(
        name="Centre on the Midline",
        description="Ring: put the axis on the rig's centre plane, so left and right bones open alike",
        default=True, update=_persist_update,
    )
    roll_along_chains: BoolProperty(
        name="Along Chains",
        description="A bone whose parent is selected too carries its parent's outward, so a chain opens as one",
        default=True, update=_persist_update,
    )
    jiggle_named_chains: StringProperty(
        name="Chains",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
        default="", update=_persist_update,
    )
    jiggle_clear_prefix: StringProperty(
        name="Chain Prefix",
        description="Leave empty to clear whichever chains the selection touches",
        default="", update=_persist_update,
    )
    jiggle_clear_use_selection: BoolProperty(
        name="Use Selection",
        description="Off: act only on the named chains whatever is selected",
        default=True, update=_persist_update,
    )
    jiggle_clear_only_baked: BoolProperty(
        name="Only Baked Keys",
        description=(
            "Remove only the curves the bake wrote (its F-curve group), keeping hand keys on the same bones. "
            "Off also removes hand-keyed rotations on the bones the bake writes. Either way only this rig's "
            "Action slot is touched"
        ),
        default=True, update=_persist_update,
    )
    chain_thickness_percentile: FloatProperty(
        name="Percentile",
        description="Which share of the link's vertices lies inside the measured thickness",
        default=0.9, min=0.5, max=1.0, update=_persist_update,
    )
    part_motion_name: StringProperty(
        name="Part Name",
        description="The name to register a part under. Its chains come from the Chains field, or the selected bones",
        default="", update=_persist_update,
    )
    part_bake_start: IntProperty(
        name="Start",
        description="0 uses the scene's start",
        default=0, update=_persist_update,
    )
    part_bake_end: IntProperty(
        name="End",
        description="0 uses the scene's end",
        default=0, update=_persist_update,
    )
    cuff_share: FloatProperty(
        name="Share at the Edge",
        description="How much of the bend the cuff's edge takes",
        default=1.0, min=0.0, max=1.0, update=_persist_update,
    )
    cuff_fade_mm: FloatProperty(
        name="Fade",
        description="How far up the sleeve the share fades to nothing, in millimetres",
        default=140.0, min=1.0, soft_max=400.0, update=_persist_update,
    )
    shoe_lift_margin_mm: FloatProperty(
        name="Margin",
        description="Extra height above the floor, in millimetres",
        default=0.0, soft_min=-10.0, soft_max=10.0, update=_persist_update,
    )
    shoe_lift_height_mm: FloatProperty(
        name="Height",
        description="Below 0 uses the measured sole",
        default=-1.0, update=_persist_update,
    )
    shoe_lift_projectors: BoolProperty(
        name="Lift Projectors",
        description="Lift UV Project projectors outside the rig's parent too",
        default=True, update=_persist_update,
    )
    kilt_push_distance: FloatProperty(
        name="Push Distance",
        description="How far the strips are kept off the leg (Auto-Rig Pro's Collide Distance)",
        default=0.25, min=0.0, soft_max=1.0, update=_persist_update,
    )
    kilt_ease_start: FloatProperty(
        name="Ease From (deg)",
        description="Leg swing at which the push starts to ease off",
        default=60.0, min=0.0, max=180.0, update=_persist_update,
    )
    kilt_ease_end: FloatProperty(
        name="Ease To (deg)",
        description="Leg swing at which the push has eased off fully",
        default=90.0, min=0.0, max=180.0, update=_persist_update,
    )
    kilt_push_keep: FloatProperty(
        name="Push Left",
        description="The share of the push left at the end angle. 1 keeps Auto-Rig Pro's push unchanged",
        default=0.35, min=0.0, max=1.0, subtype="FACTOR", update=_persist_update,
    )
    roll_arms: EnumProperty(
        name="Arms",
        description="Roll away from the body: whether the arms count when measuring away from the body",
        items=[('AUTO', "Auto", "Arm bones count only for bones that hang from an arm (an arm band's tips)"),
               ('INCLUDE', "Count In", "Arm bones always count as body"),
               ('EXCLUDE', "Leave Out", "Arm bones never count as body")],
        default='AUTO', update=_persist_update,
    )
    roll_body_bones: StringProperty(
        name="Body Bones",
        description="Roll away from the body: the bones to measure from, separated by commas. Empty uses the "
                    "Auto-Rig Pro deform body",
        default="", update=_persist_update,
    )
    swing_switch: StringProperty(
        name="Swing Switch",
        description="Custom property on the rig that turns a swing layer on: the swing plays while it equals Value",
        default="srs_sim_mode", update=_persist_update,
    )
    swing_value: IntProperty(
        name="Swing Value",
        description="The switch value that plays this swing layer (0 is always no simulation)",
        default=1, min=1, max=9, update=_persist_update,
    )
    show_c_band: BoolProperty(
        name='Band Width Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_hard: BoolProperty(
        name='Hard Parts Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_layers: BoolProperty(
        name='Layers Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_collide: BoolProperty(
        name='Collision Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_jiggle: BoolProperty(
        name='Swing Bake Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_cloth: BoolProperty(
        name='Cloth Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_ikfk: BoolProperty(
        name='IK/FK Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_mocap: BoolProperty(
        name='Motion Capture Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_proxy_roles: BoolProperty(
        name='Proxy Picker Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )
    show_c_proxy_audit: BoolProperty(
        name='Proxy Mapping Subsection',
        description="Open or close this subsection. Only the N-panel display changes",
        default=False,
        update=_persist_update,
    )

    target_armature: PointerProperty(
        name="Target Rig Armature",
        description=(
            "Armature used by Smart Rig Suite context preparation, external rig-tool dispatch, Proxy Picker audits, "
            "and rig validation. Leave empty to use automatic detection. The datablock name is stored in the Smart Rig JSON"
        ),
        type=bpy.types.Object,
        poll=_poll_armature,
        update=_persist_update,
    )
    target_body_mesh: PointerProperty(
        name="Target Body Mesh",
        description=(
            "Body mesh activated before external body-marker estimation and used as the preferred mesh in audits. "
            "Leave empty to use the active or selected mesh. The datablock name is stored in the Smart Rig JSON"
        ),
        type=bpy.types.Object,
        poll=_poll_mesh,
        update=_persist_update,
    )
    eye_object_l: PointerProperty(
        name="Left Eyeball",
        description=(
            "Left eyeball mesh. Its origin (or bounding-box centre) becomes the rotation pivot of the "
            "external rig's eye reference bone. Leave empty to skip the left side"
        ),
        type=bpy.types.Object,
        poll=_poll_mesh,
        update=_persist_update,
    )
    eye_object_r: PointerProperty(
        name="Right Eyeball",
        description=(
            "Right eyeball mesh. Its origin (or bounding-box centre) becomes the rotation pivot of the "
            "external rig's eye reference bone. Leave empty to skip the right side"
        ),
        type=bpy.types.Object,
        poll=_poll_mesh,
        update=_persist_update,
    )
    eye_face_object: PointerProperty(
        name="Face Mesh",
        description=(
            "The head mesh whose eye socket the eyeball rim is pinned to. The rim does not get a "
            "bone: it takes the weights of the face vertex it sits on, so the two surfaces move as "
            "one and cannot part on a blink. The face must be bound before the eyes"
        ),
        type=bpy.types.Object,
        poll=lambda self, obj: obj is not None and obj.type == "MESH",
        update=_persist_update,
    )
    lid_pull_mm: FloatProperty(
        name="Lid Test Pull",
        description=(
            "How far the top-lid control is pulled when measuring whether the eye can actually shut. "
            "The result is reported as a percentage of the socket's resting height: a lid that cannot "
            "reach 100 per cent cannot close, however far the control is dragged"
        ),
        default=16.0, min=1.0, soft_max=40.0,
        update=_persist_update,
    )
    eye_verify_offset_mm: FloatProperty(
        name="Gaze Test Offset",
        description=(
            "How far the look-at control is nudged when proving the eyes work. The pupil must move "
            "and the seam with the face must not, and only a posed measurement can tell a correct "
            "bind from an eye hung off a bone nothing drives -- both look identical at rest"
        ),
        default=40.0, min=1.0, soft_max=200.0,
        update=_persist_update,
    )
    eye_pivot_source: EnumProperty(
        name="Eye Pivot Source",
        description=(
            "Where the eye rotation pivot is taken from. Use Object Origin when the eyeball's origin was "
            "authored as its rotation centre, which is common for stylised eyes that pivot deep inside the head"
        ),
        items=EYE_PIVOT_SOURCES,
        default="ORIGIN",
        update=_persist_update,
    )
    eye_spec_distance: FloatProperty(
        name="Eye Spec Distance",
        description=(
            "Length of the eye reference bone as a multiple of the eyeball radius. The external rig places its "
            "Eye Spec controller at twice this length in front of the pivot, so this is the only way to move it"
        ),
        default=1.0,
        min=0.1,
        max=5.0,
        soft_max=3.0,
        update=_persist_update,
    )
    knee_split_onset_deg: FloatProperty(
        name="Knee Split Onset",
        description=(
            "Flexion angle at which the two knee sides start to slide apart. Below this the pose is "
            "left exactly as the external rig produced it"
        ),
        default=90.0,
        min=0.0,
        max=175.0,
        soft_min=60.0,
        update=_persist_update,
    )
    knee_split_end_deg: FloatProperty(
        name="Knee Split End",
        description="Flexion angle at which the split reaches its full amount",
        default=170.0,
        min=5.0,
        max=180.0,
        update=_persist_update,
    )
    knee_split_thigh_slide_mm: FloatProperty(
        name="Thigh Slide",
        description=(
            "How far the thigh's knee end slides toward the hip at the end angle, in millimetres. "
            "This is the patella-like double-joint slide and does not push the knee cap forward"
        ),
        default=20.0, min=0.0, max=200.0, soft_max=60.0, update=_persist_update,
    )
    knee_split_thigh_apart_mm: FloatProperty(
        name="Thigh Apart",
        description=(
            "How far the thigh's knee end moves anteriorly at the end angle, in millimetres. "
            "Leave at zero unless the knee cap should deliberately come forward"
        ),
        default=0.0, min=0.0, max=200.0, soft_max=40.0, update=_persist_update,
    )
    knee_split_calf_slide_mm: FloatProperty(
        name="Calf Slide",
        description="How far the calf's knee start slides toward the ankle at the end angle, in millimetres",
        default=0.0, min=0.0, max=200.0, soft_max=60.0, update=_persist_update,
    )
    knee_split_calf_apart_mm: FloatProperty(
        name="Calf Apart",
        description=(
            "How far the calf's knee start moves away from the thigh at the end angle, in millimetres. "
            "This is what stops the fold from crushing into itself"
        ),
        default=89.0, min=0.0, max=200.0, soft_max=120.0, update=_persist_update,
    )
    knee_split_ramp_curve: StringProperty(
        name="Split Ramp Curve",
        description=(
            "Optional shaping curve for the split, written as angle:factor pairs with the factor running 0 to 1, "
            "for example 90:0, 120:0.25, 150:0.7, 170:1. Leave empty to ramp straight from the onset angle to the "
            "end angle"
        ),
        default="",
        update=_persist_update,
    )
    hair_name_pattern: StringProperty(
        name="Hair Group Pattern",
        description=(
            "Regular expression picking the strand group out of a mesh's name. Its first capture "
            "becomes the group, and the left and right copies that share one mesh are told apart by "
            "which side of the mirror plane each island sits on"
        ),
        default=r"(tail[A-Z])",
        update=_persist_update,
    )
    hair_rigid_materials: StringProperty(
        name="Rigid Materials",
        description=(
            "Comma separated material names whose islands must not bend. An island of one of these "
            "is bound whole to its nearest bone, so an ornament keeps its shape in the middle of a "
            "bending strand"
        ),
        default="MIK_mtl_metal",
        update=_persist_update,
    )
    hair_bones_per_chain: IntProperty(
        name="Bones Per Strand",
        description=(
            "How many bones each strand gets. Every strand in the set gets the SAME number, spaced "
            "at equal arc length along its own centreline, so strands of different length stay "
            "interchangeable and can be posed together"
        ),
        default=10, min=1, max=64, soft_max=24, update=_persist_update,
    )
    hair_parent_bone: StringProperty(
        name="Hair Parent Bone",
        description="Bone the strands hang from, and the one loose pieces are pinned to",
        default="c_head.x",
        update=_persist_update,
    )
    hair_prefix: StringProperty(
        name="Hair Bone Prefix",
        description="Prefix for the generated bones and vertex groups",
        default="hair",
        update=_persist_update,
    )
    hair_use_master: BoolProperty(
        name="Master Chain",
        description=(
            "Build a master chain whose bone N drives bone N of every strand through a local-space "
            "Copy Rotation. Posing the master moves all strands identically; lowering one "
            "constraint's influence lets that strand depart"
        ),
        default=True,
        update=_persist_update,
    )
    hair_pin_loose: BoolProperty(
        name="Pin Loose Pieces",
        description=(
            "Bind meshes that matched no strand rigidly to the parent bone. These are the pieces "
            "sitting on the head, which travel with the skull and never bend"
        ),
        default=True,
        update=_persist_update,
    )
    part_marker: StringProperty(
        name="Character Marker",
        description=(
            "Text every one of the character's own collections carries in its name. Collections "
            "without it are left alone, which is what keeps cameras, lights and reference models "
            "out of the rig"
        ),
        default="MIK",
        update=_persist_update,
    )
    part_name: StringProperty(
        name="Part",
        description="The collection to show, hide or remove as one unit",
        default="",
        update=_persist_update,
    )
    part_key_object: PointerProperty(
        name="Linked Mesh",
        description="A mesh whose shape key follows the part's Show / Hide",
        type=bpy.types.Object,
        poll=_mesh_poll,
    )
    part_key_name: StringProperty(
        name="Linked Shape Key",
        description="The shape key set to 1 while the part is shown and to 0 while it is hidden",
        default="",
        update=_persist_update,
    )
    part_delete_meshes: BoolProperty(
        name="Delete Meshes Too",
        description=(
            "Remove the part's meshes along with its bones. Turn this off to strip a costume's rig "
            "while keeping the geometry"
        ),
        default=True,
        update=_persist_update,
    )
    hair_group_by_collection: BoolProperty(
        name="Group By Collection",
        description=(
            "Take each strand group from its own collection instead of from mesh names. This is the "
            "steadier grouping when a character keeps its parts in collections, because the meshes "
            "inside one strand carry a dozen different suffixes"
        ),
        default=True,
        update=_persist_update,
    )
    hair_min_span_mm: FloatProperty(
        name="Long Strand From",
        description=(
            "Groups at least this long get the full bone count and the master chain. Shorter groups "
            "are handled as short pieces instead, because ten bones down a 48mm clump of hair is "
            "not a chain"
        ),
        default=300.0, min=0.0, soft_max=1000.0,
        update=_persist_update,
    )
    hair_short_bones: IntProperty(
        name="Short Piece Bones",
        description=(
            "Bones given to each short group. Two is enough to let a fringe swing without the piece "
            "folding; set it to zero to leave short pieces rigid"
        ),
        default=2, min=0, max=8,
        update=_persist_update,
    )
    joint_setup_knees: BoolProperty(
        name="Knees",
        description="Include both knees when setting up or auditing the auxiliary bones",
        default=True,
        update=_persist_update,
    )
    joint_setup_elbows: BoolProperty(
        name="Elbows",
        description="Include both elbows when setting up or auditing the auxiliary bones",
        default=True,
        update=_persist_update,
    )
    joint_setup_smooth: BoolProperty(
        name="Smooth Weights Too",
        description=(
            "Also average the deform weights around each joint. This edits the mesh, so it is "
            "reported separately and is the one step that is not undone by removing the drivers"
        ),
        default=True,
        update=_persist_update,
    )
    joint_setup_scale_preset: BoolProperty(
        name="Scale To Joint",
        description=(
            "Rescale the knee's approved amounts to each joint's own segment length, so the chain's "
            "tilt angle matches rather than the raw millimetres. Turn off to apply the same numbers "
            "to every joint"
        ),
        default=True,
        update=_persist_update,
    )
    knee_smooth_radius_mm: FloatProperty(
        name="Knee Smooth Radius",
        description=(
            "Radius around each knee, in millimetres, within which the deform weights are averaged. "
            "The fold behind a bent knee comes from the primary thigh-to-shin weight transition changing "
            "over too few edge loops, not from the secondary controllers; widening it there removes the "
            "crease and lets the knee-cap correction run harder without faceting a coarse cage"
        ),
        default=115.0, min=10.0, max=400.0, soft_max=200.0, update=_persist_update,
    )
    knee_smooth_factor: FloatProperty(
        name="Knee Smooth Factor",
        description="How strongly each averaging pass pulls a vertex toward its neighbours",
        default=0.6, min=0.0, max=1.0, update=_persist_update,
    )
    knee_smooth_repeat: IntProperty(
        name="Knee Smooth Repeat",
        description="How many averaging passes to run",
        default=8, min=1, max=60, soft_max=20, update=_persist_update,
    )
    knee_profile_front: StringProperty(
        name="Knee Front Profile",
        description=(
            "Flexion angle to millimetres for the knee's front fans, written as angle:mm pairs. A positive amount "
            "pushes the knee cap outward and a negative one draws it back. Auto-Rig Pro's Bulge can only vary this "
            "along one straight line, which cannot hold the knee cap steady across the whole bend"
        ),
        default="45:3.3, 60:-36.6, 75:-30, 90:-24.5, 95:-20.8, 170:-180",
        update=_persist_update,
    )
    knee_profile_back: StringProperty(
        name="Knee Back Profile",
        description=(
            "Flexion angle to millimetres for the knee's back fan, written as angle:mm pairs. A positive amount "
            "fills the popliteal hollow so it does not cave in at moderate flexion; reduce it where the crease "
            "should fold sharply"
        ),
        default="45:39.7, 60:44, 75:30, 90:13.5, 95:13.5, 110:54, 170:94",
        update=_persist_update,
    )
    mocap_file: StringProperty(
        name="Motion File",
        description=(
            "A .bvh or .fbx motion capture clip to put on the rig. The CMU "
            "Graphics Lab database is free for any use and its Range of Motion "
            "clips exercise a rig harder than hand-made test poses do"
        ),
        default="", subtype="FILE_PATH", update=_persist_update,
    )
    mocap_preset: EnumProperty(
        name="Skeleton",
        description=(
            "Which naming the motion file uses. The presets are written out in "
            "full because guessing by name fragment goes wrong silently: on a "
            "CMU skeleton the guesser put LHipJoint on the lower lip and the "
            "left thumb on the right hand"
        ),
        items=(
            ("CMU", "CMU (BVH)", "The skeleton the CMU mocap database ships"),
            ("MIXAMO", "HumanIK / Mixamo", "HumanIK bone names (Hips, Spine2, LeftArm, LeftHandIndex1 ...): MotionBuilder, Mixamo, Rokoko. Prefixes such as mixamorig: or Character1_ are ignored"),
            ("AUTO", "Auto (guess)", "Keep whatever the rig tool guessed"),
        ),
        default="CMU", update=_persist_update,
    )
    mocap_frame_end: IntProperty(
        name="Bake To",
        description="Last frame to bake; 0 bakes the whole clip",
        default=0, min=0, max=100000, update=_persist_update,
    )
    mocap_fingers: BoolProperty(
        name="Include Fingers",
        description=(
            "Map the clip's finger channels too. Off by default: a two-joint "
            "capture pointed at a full finger rig imposes the difference "
            "between their rest orientations as a constant bend, which measured "
            "four times the collapsed vertices on the arm accessories"
        ),
        default=False, update=_persist_update,
    )
    mocap_check_step: IntProperty(
        name="Check Every",
        description="Sample every Nth frame when checking the motion",
        default=8, min=1, max=120, update=_persist_update,
    )
    rigid_material: StringProperty(
        name="Rigid Material",
        description=(
            "Any material whose name contains this is treated as a hard part: "
            "every island of it is put on a single weight vector, so it travels "
            "with what it is attached to and cannot bend. Metal does not bend, "
            "and the artist already said which material is metal"
        ),
        default="metal", update=_persist_update,
    )
    costume_donor: PointerProperty(
        name="Copy Weights From",
        description=(
            "The mesh to copy weights from. Empty finds the skin by itself: the active bound mesh, "
            "then Target Body Mesh, then the nearest mesh bound to the rig"
        ),
        type=bpy.types.Object, poll=_mesh_poll,
    )
    costume_rigid: BoolProperty(
        name="Solid Part",
        description=(
            "For a part built as one solid piece, such as a nail, a stud or a zip tooth. "
            "Each island follows the single bone it is weighted to most"
        ),
        default=False, update=_persist_update,
    )
    costume_base_space: BoolProperty(
        name="Before Shape Keys",
        description=(
            "Copy against the source mesh's shape before its shape keys. "
            "Only for a part that shares the source's shape keys"
        ),
        default=False, update=_persist_update,
    )
    rigid_donor: PointerProperty(
        name="Rigid Donor",
        description=(
            "The surface a hard part sits on. Its weights at the contact point "
            "become the part's. Leave empty for a part threaded on a chain of "
            "its own, where there is no surface underneath to follow"
        ),
        type=bpy.types.Object, poll=_mesh_poll,
    )
    under_part: PointerProperty(
        name="Garment Underneath",
        description=(
            "The layer this part is worn over -- the sleeve under a belt, the "
            "body under a sleeve. Binding a part to the layer beneath it makes "
            "the two solve the same joint the same way, which is what stops "
            "them sliding through one another"
        ),
        type=bpy.types.Object, poll=_mesh_poll,
    )
    drop_families: StringProperty(
        name="Drop Bone Families",
        description=(
            "Comma separated name fragments to take off the selected mesh, with "
            "the weight handed up the chain. 'twist' stops a sleeve spinning "
            "with the wrist; 'thumb,index,middle,ring,pinky' stops a coat "
            "hanging off a finger"
        ),
        default="twist", update=_persist_update,
    )
    follow_only_joint: EnumProperty(
        name="Stop Following",
        description=(
            "Which joint the selected part should stop following. 'Wrist' takes "
            "the hand, the fingers and the forearm twist bones off together and "
            "gives the weight to the forearm, so a coat sleeve keeps the bend of "
            "the arm without the spin of the wrist"
        ),
        items=[
            ('WRIST', "Wrist", "Hand, fingers and forearm twist go to the forearm"),
            ('CUSTOM', "Custom", "Use the families and the heir named below"),
        ],
        default='WRIST', update=_persist_update,
    )
    keep_outside_mm: FloatProperty(
        name="Clearance",
        description=(
            "How far outside the layer underneath the part is held, in "
            "millimetres. Only vertices that went inside are moved; anything "
            "already outside stays exactly where the armature put it"
        ),
        default=1.5, min=0.0, soft_max=20.0, update=_persist_update,
    )
    collide_skin: PointerProperty(
        name="Outer Surface 1",
        description=(
            "Fit the capsules against the OUTERMOST surfaces -- the clothed "
            "silhouette, not the naked body. Measured on this character: "
            "capsules fitted to the body sit 30-50mm inside the coat the hair "
            "actually hangs on, so clearing them leaves the hair inside the "
            "coat, and collision made real mesh intersections 11% WORSE. "
            "Fitted to the dressed silhouette the same scene improved 80%"
        ),
        type=bpy.types.Object, poll=_poll_mesh,
    )
    collide_face: PointerProperty(
        name="Outer Surface 2",
        description="Another surface to include -- the face, for the head and neck capsules",
        type=bpy.types.Object, poll=_poll_mesh,
    )
    collide_mesh_c: PointerProperty(
        name="Outer Surface 3",
        description="Another surface to include -- the coat or jacket",
        type=bpy.types.Object, poll=_poll_mesh,
    )
    collide_mesh_d: PointerProperty(
        name="Outer Surface 4",
        description="Another surface to include -- the top",
        type=bpy.types.Object, poll=_poll_mesh,
    )
    collide_mesh_e: PointerProperty(
        name="Outer Surface 5",
        description="Another surface to include -- the trousers or skirt",
        type=bpy.types.Object, poll=_poll_mesh,
    )
    collide_split: FloatProperty(
        name="Split Wide Parts",
        description=(
            "Split a part into two capsules when its cross-section is wider "
            "than it is deep by more than this factor. A torso is about 140mm "
            "across and 100mm deep, and one circular capsule cannot be both: "
            "measured, a single capsule big enough to stop the hair passing "
            "through held it 44mm off the coat, while two side by side held it "
            "within 13mm for the same scene"
        ),
        default=1.25, min=1.0, soft_max=3.0, update=_persist_update,
    )
    collide_percentile: IntProperty(
        name="Radius Percentile",
        description=(
            "Which percentile of the skin's distance from the bone becomes the "
            "capsule radius. The maximum is unusable -- it balloons on one "
            "stray vertex, 238mm against a 94mm median on this character's "
            "head -- and the mean under-fits a chest by 25mm"
        ),
        default=90, min=50, max=99, update=_persist_update,
    )
    collide_inset: FloatProperty(
        name="Inset",
        description=(
            "Shrink the fitted radius by this factor, so the capsule sits just "
            "inside the skin and hair resting on the surface starts outside it"
        ),
        default=1.05, min=0.85, max=1.40, update=_persist_update,
    )
    collide_toes: BoolProperty(
        name="Include Toes", default=False,
        description="Fit capsules to the toes as well", update=_persist_update,
    )
    collide_sides: IntProperty(
        name="Proxy Sides",
        description=(
            "How many sides each generated low-poly collision mesh has. A "
            "coarse barrel's facets sit inside the capsule by "
            "r*(1-cos(pi/n)) -- 3.4mm on a 100mm limb at 12 sides, 17mm on a "
            "500mm torso -- so this is a real accuracy control, not a cosmetic "
            "one"
        ),
        default=12, min=6, max=32, update=_persist_update,
    )
    chain_collide: BoolProperty(
        name="Collide", default=True,
        description=(
            "Push this chain out of the collision capsules while baking the "
            "swing"
        ),
        update=_persist_update,
    )
    chain_collide_mm: FloatProperty(
        name="Thickness",
        description=(
            "The chain's own half-thickness. The contact is resolved to the "
            "capsule radius plus this plus a margin"
        ),
        default=4.0, min=0.0, soft_max=50.0, update=_persist_update,
    )
    chain_floor: BoolProperty(
        name="Floor",
        description="Keep every chain above the floor while baking, whether it collides with the capsules or not. A chain that starts the bake well below the floor height is left alone",
        default=True, update=_persist_update,
    )
    chain_floor_z: FloatProperty(
        name="Floor Height",
        description="Height of the floor the chains rest on",
        default=0.0, subtype='DISTANCE', update=_persist_update,
    )
    chain_collide_sweeps: IntProperty(
        name="Quality",
        description=(
            "How many times each link is re-checked against every capsule per "
            "frame. Blender's cloth has the same idea under Collision Quality"
        ),
        default=2, min=1, max=20, update=_persist_update,
    )
    chain_pivots: EnumProperty(
        name="Joints From",
        description=(
            "Where the joints go. 'Even' divides the length, which is what the "
            "mesh is not divided into; 'Divisions' puts one on every division "
            "of the part; 'Spacing' aims at a distance and takes the nearest "
            "division to it. Either of the last two keeps every joint out of a "
            "rigid piece and puts one on each of its boundaries"
        ),
        items=[
            ('TARGET', "Spacing", "Aim at a spacing, snap to the divisions"),
            ('DIVISIONS', "Every division", "One joint per division"),
            ('RINGS', "Every edge loop",
             "One bone per ring-shaped edge loop, pivot at the loop's centre"),
            ('EVEN', "Even", "Divide the length, ignoring the mesh"),
        ],
        default='TARGET', update=_persist_update,
    )
    chain_ring_source: EnumProperty(
        name="Loops From",
        description="Where Every edge loop finds its loops",
        items=[
            ('STRANDS', "Hair Strands", "Find the hair strands in the selection (U-shaped fringe strands split in two)"),
            ('EDGE', "Selection's top edge", "One strap, loops counted by connectivity from where the selection meets the rest of the piece"),
        ],
        default='STRANDS', update=_persist_update,
    )
    chain_root_follow: BoolProperty(
        name="Root Follows the Surface",
        description=("The chain hangs from a hidden bone that follows the surface around its root (the surface's own "
                     "weights), not from one bone. For a tip on a strip skinned to several bones"),
        default=False, update=_persist_update,
    )
    chain_ring_spacing_mm: FloatProperty(
        name="Shortest Bone",
        description="Loops closer than this are carried by one bone. 0 puts a bone on every loop",
        default=0.0, min=0.0, soft_max=100.0, update=_persist_update,
    )
    chain_first_ring: IntProperty(
        name="Skip Loops",
        description=(
            "How many loops at the root to leave on the body. Hair growing out "
            "of the scalp barely moves there, and a bone per loop through that "
            "stretch is clutter the animator has to step over. Counted from "
            "the strand's own root loop"
        ),
        default=5, min=0, soft_max=20, update=_persist_update,
    )
    chain_ring_blend: IntProperty(
        name="Blend Loops",
        description=(
            "How many of the first bones share their loop with the parent, so "
            "the handover is not a hard edge. Both ends of one face on "
            "different bones at full weight is what makes a seam"
        ),
        default=2, min=0, soft_max=8, update=_persist_update,
    )
    chain_ring_min_mm: FloatProperty(
        name="Skip Above",
        description=(
            "Only skip root loops on a strand longer than this. A short strand "
            "-- the thin hairs over the brow -- is posed from its root, "
            "because that is where it moves"
        ),
        default=80.0, min=0.0, soft_max=500.0, update=_persist_update,
    )
    chain_target_mm: FloatProperty(
        name="Spacing",
        description=(
            "How far apart the joints should be, in millimetres. The nearest "
            "division to each step is taken, so a part divided every 2mm does "
            "not get a joint every 2mm"
        ),
        default=60.0, min=1.0, soft_max=300.0, update=_persist_update,
    )
    chain_root_mm: FloatProperty(
        name="Root Spacing",
        description=(
            "A finer spacing for the first stretch, for a part whose root is "
            "the part that fouls something. 0 uses the same spacing throughout"
        ),
        default=0.0, min=0.0, soft_max=300.0, update=_persist_update,
    )
    chain_root_span_mm: FloatProperty(
        name="Root Length",
        description="How far down the root spacing applies, in millimetres",
        default=200.0, min=0.0, soft_max=1000.0, update=_persist_update,
    )
    chain_rigid_match: StringProperty(
        name="Rigid Material",
        description=(
            "A piece whose name or material contains this is solid: it gets one "
            "bone spanning it, a joint on each of its boundaries and none "
            "inside. Clear it to treat everything as soft"
        ),
        default="metal", update=_persist_update,
    )
    chain_mode: EnumProperty(
        name="Chain Shape",
        description=(
            "What the selected part is. A strand hangs in one line; a sheet is "
            "wide and has to be split into columns first, or one centreline runs "
            "sideways across it; links are separate solid pieces that read as "
            "threaded together"
        ),
        items=[
            ('STRAND', "Strand", "One chain down a hanging strand or strap"),
            ('SHEET', "Sheet", "A wide hem or fringe, split into columns first"),
            ('LINKS', "Links", "Separate solid pieces, one bone each, in order"),
        ],
        default='STRAND', update=_persist_update,
    )
    chain_key: StringProperty(
        name="Chain Name",
        description=(
            "Goes into the bone names, as srs_chain_<name>_01. Give each chain "
            "its own: building two chains under one name leaves the second "
            "owning the bones and the first part attached to nothing it can use"
        ),
        default="part", update=_persist_update,
    )
    chain_bones: IntProperty(
        name="Bones",
        description=(
            "How many bones down the chain. Ten down a 1.2m tail is right, ten "
            "down a 48mm clump is not"
        ),
        default=3, min=1, max=32, update=_persist_update,
    )
    chain_columns: IntProperty(
        name="Columns",
        description=(
            "How many chains across a sheet. A fringe spans the whole forehead, "
            "so a single centreline down it runs sideways through the hair"
        ),
        default=3, min=1, max=16, update=_persist_update,
    )
    chain_across: EnumProperty(
        name="Split By",
        description=(
            "How the sheet is cut into columns -- straight across for a fringe, "
            "by bearing from the centre for a hem or a skirt that wraps round"
        ),
        items=[
            ('X', "Straight", "Split along X, for a flat sheet"),
            ('ANGLE', "Around", "Split by bearing, for a hem that wraps"),
        ],
        default='X', update=_persist_update,
    )
    chain_parent: StringProperty(
        name="Hangs From",
        description=(
            "The bone the chain hangs off. Leave it empty to let the part's own "
            "top edge choose, which penalises finger and facial bones"
        ),
        default="", update=_persist_update,
    )
    chain_feel: EnumProperty(
        name="Swing",
        description=(
            "Stored on the chain's root bone so a re-bake repeats itself. The "
            "numbers are measured, not guessed: a long chain has to be stiffer "
            "than a short one or twelve links' worth of rotation never settles"
        ),
        items=[
            ('LONG', "Long hair", "0.90/0.62, gravity 60 -- 1.5m braids, 38-41 links"),
            ('FRINGE', "Fringe", "0.92/0.70, no gravity -- fringe strands, one link per edge loop"),
            ('SHORT', "Short hair", "0.55/0.22/0.50 -- a short clump"),
            ('METAL', "Earring", "0.70/0.45, gravity 3 -- a hanging earring"),
            ('ZIP', "Zip pull", "0.45/0.25, gravity 9 -- a zip pull or a small charm"),
            ('HEM', "Hem", "0.40/0.30/0.45 with some weight -- a coat hem"),
            ('STRAP', "Strap", "0.70/0.72, gravity 160 -- a hanging belt strap"),
            ('NONE', "None", "No swing settings; the chain is posed by hand"),
        ],
        default='SHORT', update=_persist_update,
    )
    follow_only_family: StringProperty(
        name="Bone Families",
        description=(
            "Comma separated bone families to take off together, used when Stop "
            "Following is set to Custom. Name the whole family: dropping the "
            "twist bones and leaving the hand and fingers behind measured worse "
            "than changing nothing, because the twist bones are the graded blend "
            "between the two"
        ),
        default="hand, forearm_twist, thumb, index, middle, ring, pinky",
        update=_persist_update,
    )
    follow_only_heir: StringProperty(
        name="Give Weight To",
        description=(
            "The bone that inherits the whole family, with {side} standing for "
            "l and r. Only used when Stop Following is set to Custom"
        ),
        default="forearm_stretch.{side}", update=_persist_update,
    )
    rig_preset: EnumProperty(
        name="Reference Rig Preset",
        description=(
            "Preset identifier passed to the separately installed Auto-Rig Pro reference-rig operator after the "
            "value has been validated"
        ),
        items=RIG_PRESETS,
        default="human",
        update=_persist_update,
    )
    limb_preset: EnumProperty(
        name="Reference Limb Preset",
        description=(
            "Limb identifier passed to the separately installed Auto-Rig Pro add-limb operator after an armature "
            "Edit Mode context has been prepared"
        ),
        items=LIMB_PRESETS,
        default="arm.l",
        update=_persist_update,
    )
    ikfk_mode: EnumProperty(
        name="IK/FK Operation",
        description="External rig-tools operation to run from the active compatible pose controller",
        items=IKFK_MODES,
        default="ARM_FK_TO_IK",
        update=_persist_update,
    )
    ikfk_key_switch: BoolProperty(
        name="Key the Switch",
        description=(
            "Always key the switch on the current frame, even with Auto Keying off. Off (default): key only "
            "when Auto Keying is on, like Auto-Rig Pro. Every switch key is made a step either way, so the "
            "limb is never half IK and half FK between two keys"
        ),
        default=False,
        update=_persist_update,
    )
    band_mirror_source: EnumProperty(
        name="Mirror From",
        description="The side whose band weights are copied onto the other side",
        items=[
            ('L', "Left to right", "Copy the left (+X, .l) band rows onto the right"),
            ('R', "Right to left", "Copy the right (-X, .r) band rows onto the left"),
        ],
        default='L', update=_persist_update,
    )
    band_uv_axis: EnumProperty(
        name="Band Rows",
        description=(
            "Which UV axis runs along the band. Rows across the band's width are read from the UV map, "
            "so the band must be unwrapped as a straight strip"
        ),
        items=[
            ('V', "Rows along V", "The band runs along U; each cross row has one V value"),
            ('U', "Rows along U", "The band runs along V; each cross row has one U value"),
            ('AUTO', "Guess per band", "Each band's rows run along whichever UV axis gives the shorter rows"),
        ],
        default='V',
        update=_persist_update,
    )
    band_min_width_mm: FloatProperty(
        name="Narrowest Row",
        description="Rows narrower than this (holes, cut ends) are folded into the nearest full row",
        default=25.0, min=1.0, soft_max=200.0,
        update=_persist_update,
    )
    band_lock_hard: BoolProperty(
        name="Hard Parts Stay Rigid",
        description=(
            "Also lock every island of the rigid material (buckles, studs) on this mesh with one dual quaternion "
            "each. One shared weight vector is not enough: linear blending still bends it at a joint"
        ),
        default=True,
        update=_persist_update,
    )
    midline_band_mm: FloatProperty(
        name="Centre Band",
        description=(
            "Half width of the band around x = 0 in which leg weights are shared by position. Measured on "
            "a skirt: 80 mm took the front's sideways slide from 23.6 to 7.5 mm and its worst edge "
            "stretch from 635 to 91 %; 120 mm slid less but stretched more"
        ),
        default=80.0, min=5.0, soft_max=200.0,
        update=_persist_update,
    )
    cloth_band_mm: FloatProperty(
        name="Pinned Band",
        description="How far down from the garment's top edge stays pinned to the bones",
        default=45.0, min=0.0, soft_max=200.0,
        update=_persist_update,
    )
    cloth_feather_mm: FloatProperty(
        name="Pin Fade",
        description="How far the pinning fades out. A hard edge creases the waistband",
        default=35.0, min=1.0, soft_max=200.0,
        update=_persist_update,
    )
    cloth_collider: PointerProperty(
        name="Cloth Lands On",
        description="A mesh for the cloth to land on, usually the body. Empty adds none",
        type=bpy.types.Object,
        poll=_mesh_poll,
    )
    cloth_collider_2: PointerProperty(
        name="Cloth Also Lands On",
        description="A second mesh for the cloth to land on, such as shorts worn under a skirt. Empty adds none",
        type=bpy.types.Object,
        poll=_mesh_poll,
    )
    cloth_only_listed: BoolProperty(
        name="Only These",
        description=(
            "The cloth collides with the meshes chosen here and nothing else, not with "
            "collision capsules made for swinging hair"
        ),
        default=True,
    )
    group_key: StringProperty(
        name="Group Name",
        description=(
            "Name of the control pair that poses the selected chains together "
            "(srs_ctl_<name>_swing and srs_ctl_<name>_curl)"
        ),
        default="braids",
        update=_persist_update,
    )
    snap_mode: EnumProperty(
        name="Snap Operation",
        description="External rig-tools snap operation to run from the active compatible pose controller",
        items=SNAP_MODES,
        default="HEAD",
        update=_persist_update,
    )
    weight_value: FloatProperty(
        name="Weight",
        description="Weight used by Set, Add, and Subtract operations. Enter a value from 0 to 1, then run the desired edit command",
        default=0.5,
        min=0.0,
        max=1.0,
        precision=4,
        update=_persist_update,
    )
    weight_scale: FloatProperty(
        name="Scale",
        description="Multiplier used by the Scale Weight operation. Values above 1 increase and values below 1 reduce the current weight",
        default=1.0,
        min=0.0,
        max=10.0,
        precision=4,
        update=_persist_update,
    )
    weight_selected_only: BoolProperty(
        name="Selected Vertices Only",
        description="Use selected mesh vertices in Edit Mode; disable it to process all vertices in the active mesh",
        default=True,
        update=_persist_update,
    )
    weight_normalize_after: BoolProperty(
        name="Normalize After Edit",
        description="Preserve the edited group value and redistribute the remaining weight across other unlocked groups after a cell or weight operation",
        default=True,
        update=_persist_update,
    )
    weight_clean_threshold: FloatProperty(
        name="Clean Threshold",
        description="Remove weights below this threshold when Clean is executed. Use a small value to remove only negligible influences",
        default=0.0001,
        min=0.0,
        max=1.0,
        precision=6,
        update=_persist_update,
    )
    weight_table_rows: IntProperty(
        name="Rows",
        description="Maximum number of mesh vertices displayed in one weight-table page. Reduce it when the popup becomes too tall",
        default=12,
        min=1,
        max=100,
        update=_persist_update,
    )
    weight_table_columns: IntProperty(
        name="Columns",
        description="Maximum number of vertex groups displayed in one weight-table page. Reduce it when the popup becomes too wide",
        default=6,
        min=1,
        max=32,
        update=_persist_update,
    )
    weight_table_row_page: IntProperty(
        name="Vertex Page",
        description="Current vertex-row page shown by the weight table. Use the previous and next row buttons to change it",
        default=0,
        min=0,
        update=_persist_update,
    )
    weight_table_group_page: IntProperty(
        name="Vertex Group Page",
        description="Current vertex-group column page shown by the weight table. Use the previous and next group buttons to change it",
        default=0,
        min=0,
        update=_persist_update,
    )
    weight_table_include_zero: BoolProperty(
        name="Show Zero Columns",
        description="Include vertex groups that have no weight on the displayed vertices. Disable it to keep the table compact",
        default=False,
        update=_persist_update,
    )
    proxy_text_name: StringProperty(
        name="Proxy Map Text",
        description="Blender Text datablock used to export or import Proxy Picker mappings. Enter an existing name or let the export command create it",
        default="Smart Rig Proxy Map",
        update=_persist_update,
    )
    export_report_path: StringProperty(
        name="JSON Report Path",
        description="Optional file path used by Export Integration Report. Relative paths beginning with // are resolved from the current .blend file",
        subtype="FILE_PATH",
        options={"PATH_SUPPORTS_BLEND_RELATIVE"},
        default="//smart_rig_suite_report.json",
        update=_persist_update,
    )
    # The factor, the target height and the measured values describe this file's character: they are never
    # saved to or loaded from the shared JSON (persistence._TRANSIENT_SCENE_NAMES), only kept in the .blend.
    rescale_mode: EnumProperty(
        name="Resize By",
        description="Give the factor directly, or work it out from the current and the target height",
        items=RESCALE_MODES,
        default="FACTOR",
        update=_persist_update,
    )
    rescale_factor: FloatProperty(
        name="Resize Factor",
        description="Multiply every length by the factor",
        default=1.0, min=0.0, soft_min=0.1, soft_max=10.0, precision=6,
        update=_persist_update,
    )
    rescale_target_height_mm: FloatProperty(
        name="Target Height",
        description="The height the character should have afterwards, in millimetres, measured the same way as the current height",
        default=0.0, min=0.0, precision=2,
        update=_persist_update,
    )
    rescale_current_height_mm: FloatProperty(
        name="Current Height",
        description="The character's height now, in millimetres. Measure fills it from the selected meshes; you can also type it",
        default=0.0, min=0.0, precision=3,
        update=_persist_update,
    )
    rescale_height_basis: EnumProperty(
        name="Height Is",
        description="How the height is measured",
        items=RESCALE_BASES,
        default="EXTENT",
        update=_persist_update,
    )
    rescale_measured_top_mm: FloatProperty(default=0.0, options={"HIDDEN"})
    rescale_measured_bottom_mm: FloatProperty(default=0.0, options={"HIDDEN"})
    rescale_measured_rig: StringProperty(default="", options={"HIDDEN"})
    # the Height Is value the current height was measured with (EXTENT / TOP); the panel flags a mismatch
    rescale_measured_basis: StringProperty(default="", options={"HIDDEN"})
    rescale_include_all_scene: BoolProperty(
        name="Whole Scene",
        description=(
            "Resize every object in the scene, not only this character. Lights and cameras still follow Lights "
            "and Cameras"
        ),
        default=False,
        update=_persist_update,
    )
    rescale_include_staging: BoolProperty(
        name="Lights and Cameras",
        description=(
            "Also move and resize lights and cameras with the character; their brightness is not changed. Light "
            "probes and speakers cannot be resized and stop the resize"
        ),
        default=False,
        update=_persist_update,
    )
    rescale_scale_materials: BoolProperty(
        name="Material Lengths",
        description="Scale lengths inside the materials (bump distance, subsurface scale, object-mapped textures)",
        default=True,
        update=_persist_update,
    )
    rescale_scale_panel_lengths: BoolProperty(
        name="Panel Lengths",
        description=(
            "Also scale this panel's millimetre settings and the floor height for this file. While N-panel State "
            "Save is on they are also written to the shared panel state that other files load"
        ),
        default=True,
        update=_persist_update,
    )
    # Off by default and per file (persistence._TRANSIENT_SCENE_NAMES): rebinding changes bind data, so it is never
    # carried to other files through the shared JSON.
    rescale_rebind_bound: BoolProperty(
        name="Rebind Bound Modifiers",
        description=(
            "Unbind Corrective Smooth (bind rest), Surface Deform, Mesh Deform and Laplacian Deform before the "
            "resize and bind them again afterwards with Blender's own Bind, at rest pose and, if that does not "
            "match, at the current pose. The result is compared with the original and a difference is reported as "
            "an error"
        ),
        default=False,
        update=_persist_update,
    )
    last_status: StringProperty(default="", options={"HIDDEN"})
    last_report_text: StringProperty(default="", options={"HIDDEN"})
    last_preflight_text: StringProperty(default="", options={"HIDDEN"})


CLASSES = (SRS_SceneSettings,)
_REGISTERED = False


def register() -> bool:
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False

    registered_now = ()
    try:
        registered_now = register_classes(
            CLASSES,
            module_name=__name__,
            revision=__srs_revision__,
            module_marker=__srs_module_generation_marker__,
        )
        register_pointer_property(
            bpy.types.Scene,
            "srs_settings",
            SRS_SceneSettings,
            module_name=__name__,
            revision=__srs_revision__,
            module_marker=__srs_module_generation_marker__,
        )
    except Exception:
        # Never remove a pointer or PropertyGroup retained by an older module
        # execution. The lifecycle helpers roll back only identities created here.
        unregister_classes(registered_now, attempts=2)
        raise

    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    return True


def unregister() -> dict:
    global _REGISTERED
    if generation.live_resource_summary().get("panels", 0):
        return {
            "protected": True,
            "reason": "live Panel dependency",
            "pointer": {"all_removed": False, "remaining": ["Scene.srs_settings"]},
            "classes": {"all_removed": False, "remaining": ["SRS_SceneSettings"]},
            "all_removed": False,
            "errors": [],
        }
    pointer_report = unregister_owned_pointer_properties(module_name=__name__)
    if pointer_report.get("all_removed"):
        class_report = unregister_owned_classes(module_name=__name__, attempts=2)
    else:
        # A PointerProperty that could not be proven/removed still references the
        # exact PropertyGroup class. Preserve that class until a later safe retry.
        class_report = {
            "protected": True,
            "all_removed": False,
            "remaining": ["SRS_SceneSettings protected by Scene.srs_settings"],
            "errors": [],
        }
    all_removed = bool(pointer_report.get("all_removed") and class_report.get("all_removed"))
    if all_removed:
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return {
        "protected": bool(class_report.get("protected")),
        "pointer": pointer_report,
        "classes": class_report,
        "all_removed": all_removed,
        "errors": list(pointer_report.get("errors", ())) + list(class_report.get("errors", ())),
    }
