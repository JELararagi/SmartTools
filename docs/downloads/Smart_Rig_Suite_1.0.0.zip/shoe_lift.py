# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Shoe sole lift: raise the whole character by its sole's height without touching the rig.

A character modelled barefoot at Z = 0 wears shoes whose soles sit under the floor;
changing shoes changes the sole. The lift is a driver on the rig's PARENT object's Z
(an Empty in Auto-Rig Pro's character group), reading a custom property on that same
object. No bone is added and no rest pose moves, so nothing Auto-Rig Pro resets or
recomputes can bake the lift in. Measured on MIK (Claude fork 18, 2026-10-03): with the
lift on, ARP's internal reset, IK/FK snapping, Reset All and the mocap remap all kept it,
while a bone inserted under c_pos had the lift baked into the IK and look-at Child Of
inverses by the internal reset (c_foot_ik 188.8 -> 66.1 mm, sole -25.6 mm, not undone by
setting the lift back to 0).

Objects that deform the rig's meshes from OUTSIDE the parent move with it too: a UV
Project's projector gets a driver on ``delta_location[2]`` reading the same property
(its ``location`` may already carry an eyelid driver). A Data Transfer that does not use
the object transform does not depend on position and is left alone. Anything else is
reported and left alone.

An object that already descends from the parent -- the eyelid-shadow projector since
2.62.33 is bone-parented to the eye socket inside the rig -- is lifted by the parent and
never gets the driver: a second lift would raise it twice (MIK_194, 2026-10-17: measured
with the lift +30 mm, the rig rose 30 mm and the projector with it, UV change 1.9e-6). A
driver left on such an object by an older run is removed by Apply and by Remove
(``stale()``), with its delta reset to 0.

Writing the property from Python does not re-evaluate the drivers by itself: every
write here is followed by ``update_tag()`` on the parent and the projectors.

Bind, parent, transfer and fit colliders with the lift at 0: they read world
positions and would bake the lift into the result.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import bpy

PROP = "srs_shoe_lift"
MEASURED = "srs_shoe_lift_measured"
EPS = 1.0e-9


def arp_rig(obj):
    """``obj`` if it is an Auto-Rig Pro rig (an armature with c_pos and c_traj), else None."""
    if obj is None or obj.type != "ARMATURE" or obj.pose is None:
        return None
    bones = obj.pose.bones
    return obj if bones.get("c_pos") is not None and bones.get("c_traj") is not None else None


def holder(rig):
    """The object the lift is applied to: the rig's parent."""
    return rig.parent if rig is not None else None


def lift(rig):
    parent = holder(rig)
    return float(parent.get(PROP, 0.0)) if parent is not None else 0.0


def lifted(rig):
    return abs(lift(rig)) > EPS


def guard_message(rig):
    """Why a world-space setup step must not run now, or ''."""
    if rig is not None and lifted(rig):
        return ("The character is lifted by its shoe sole (%.1f mm). Clear the lift first, run this, then lift again."
                % (lift(rig) * 1000.0))
    return ""


def _descends(obj, ancestor):
    while obj is not None:
        if obj == ancestor:
            return True
        obj = obj.parent
    return False


def rig_meshes(rig):
    return [o for o in bpy.data.objects if o.type == "MESH"
            and any(m.type == "ARMATURE" and m.object == rig for m in o.modifiers)]


def outside(rig):
    """Objects the rig's meshes depend on that do not move with the parent.

    ``[(object name, used by, kind, action)]`` with action ``lift`` (a projector),
    ``none`` (position-free) or ``unjudged``.
    """
    parent = holder(rig)
    rows, seen = [], set()
    for mesh in rig_meshes(rig):
        for mod in mesh.modifiers:
            refs = []
            if mod.type == "UV_PROJECT":
                refs = [(p.object, "projector", "lift") for p in mod.projectors if p.object is not None]
            elif mod.type == "DATA_TRANSFER":
                if mod.object is not None:
                    refs = [(mod.object, "data transfer",
                             "unjudged" if mod.use_object_transform else "none")]
            elif mod.type != "ARMATURE":
                target = getattr(mod, "object", None) or getattr(mod, "target", None)
                if isinstance(target, bpy.types.Object):
                    refs = [(target, mod.type.lower(), "unjudged")]
            for obj, kind, action in refs:
                if parent is not None and _descends(obj, parent):
                    continue
                key = (obj.name, action)
                if key in seen:
                    continue
                seen.add(key)
                rows.append((obj.name, mesh.name, kind, action))
    return rows


def stale(rig):
    """Projectors of the rig's meshes that descend from the parent AND still carry this
    module's ``delta_location`` driver: they would be lifted twice. ``[object]``."""
    parent = holder(rig)
    if parent is None:
        return []
    found, seen = [], set()
    for mesh in rig_meshes(rig):
        for mod in mesh.modifiers:
            if mod.type != "UV_PROJECT":
                continue
            for slot in mod.projectors:
                obj = slot.object
                if obj is None or obj.name in seen or not _descends(obj, parent):
                    continue
                seen.add(obj.name)
                if _driver(obj, "delta_location", 2) is not None:
                    found.append(obj)
    return found


def _unlift_stale(rig):
    names = []
    for obj in stale(rig):
        obj.driver_remove("delta_location", 2)
        obj.delta_location[2] = 0.0
        obj.update_tag()
        names.append(obj.name)
    return names


def preflight(rig):
    """What stops the lift from being set up. A list of sentences; empty means ready."""
    problems = []
    parent = holder(rig)
    if rig is None:
        return ["Choose an Auto-Rig Pro rig (an armature with c_pos and c_traj)."]
    if parent is None:
        return ["The rig has no parent object to lift. Parent it to an Empty first; nothing is created for you."]
    ours = _driver(parent, "location", 2) is not None
    if not ours and abs(parent.location[2]) > EPS:
        problems.append("%s is not at Z = 0 (%.4f)." % (parent.name, parent.location[2]))
    ad = parent.animation_data
    if ad is not None:
        if ad.action is not None:
            problems.append("%s is animated; its location would fight the lift." % parent.name)
        for fc in ad.drivers:
            if fc.data_path == "location" and fc.array_index == 2 and not _is_ours(fc):
                problems.append("%s already has another driver on its Z." % parent.name)
    add = bpy.data.objects.get(rig.name + "_add")
    if add is not None and add.parent != parent:
        problems.append("%s is not under %s, so its helper bones would stay down." % (add.name, parent.name))
    stray = [m.name for m in rig_meshes(rig) if not _descends(m, parent)]
    if stray:
        problems.append("Not under %s: %s." % (parent.name, ", ".join(stray[:5])))
    return problems


def _driver(obj, path, index):
    ad = obj.animation_data
    if ad is None:
        return None
    for fc in ad.drivers:
        if fc.data_path == path and fc.array_index == index and _is_ours(fc):
            return fc
    return None


def _is_ours(fc):
    drv = fc.driver
    return any(v.name == "h" and v.targets[0].data_path == '["%s"]' % PROP for v in drv.variables)


def _make_driver(obj, path, index, source):
    fc = _driver(obj, path, index)
    if fc is None:
        fc = obj.driver_add(path, index)
        # driver_add can hand back a curve with a Generator; the plain driver value is wanted
        for mod in list(fc.modifiers):
            fc.modifiers.remove(mod)
    drv = fc.driver
    drv.type = "SCRIPTED"
    for var in list(drv.variables):
        drv.variables.remove(var)
    var = drv.variables.new()
    var.name = "h"
    var.type = "SINGLE_PROP"
    var.targets[0].id_type = "OBJECT"
    var.targets[0].id = source
    var.targets[0].data_path = '["%s"]' % PROP
    drv.expression = "h"
    return fc


def _refresh(rig):
    parent = holder(rig)
    if parent is not None:
        parent.update_tag()
    for name, _mesh, _kind, action in outside(rig):
        obj = bpy.data.objects.get(name)
        if obj is not None and action == "lift":
            obj.update_tag()
    bpy.context.view_layer.update()


def _write(rig, value):
    parent = holder(rig)
    parent[PROP] = float(value)
    _refresh(rig)


def measure(rig, meshes, margin_mm=0.0):
    """The sole's height: minus the lowest Z of ``meshes`` at rest with no lift. ``(report, error)``."""
    problems = preflight(rig)
    if problems:
        return None, " ".join(problems)
    if not meshes:
        return None, "Select the shoe (and foot) meshes to measure."
    parent = holder(rig)
    before = lift(rig)
    had = PROP in parent.keys()
    poses = []
    for arm in (rig, bpy.data.objects.get(rig.name + "_add")):
        if arm is not None and arm.type == "ARMATURE":
            poses.append((arm, arm.data.pose_position))
            arm.data.pose_position = "REST"
    try:
        if had:
            _write(rig, 0.0)
        else:
            bpy.context.view_layer.update()
        deps = bpy.context.evaluated_depsgraph_get()
        low = None
        for mesh in meshes:
            ev = mesh.evaluated_get(deps)
            data = ev.to_mesh()
            mw = ev.matrix_world
            for v in data.vertices:
                z = (mw @ v.co).z
                low = z if low is None or z < low else low
            ev.to_mesh_clear()
    finally:
        for arm, mode in poses:
            arm.data.pose_position = mode
        if had:
            _write(rig, before)
        else:
            bpy.context.view_layer.update()
    if low is None:
        return None, "The selected meshes have no vertices."
    height = max(0.0, -low + float(margin_mm) / 1000.0)
    parent[MEASURED] = height
    return {"lowest_mm": round(low * 1000.0, 3), "height_mm": round(height * 1000.0, 3),
            "meshes": [m.name for m in meshes]}, ""


def apply(rig, height=None, include_projectors=True):
    """Lift by ``height`` (default the measured one). ``(report, error)``."""
    problems = preflight(rig)
    if problems:
        return None, " ".join(problems)
    parent = holder(rig)
    if height is None or height < 0.0:
        if MEASURED not in parent.keys():
            return None, "Measure the sole first."
        height = float(parent[MEASURED])
    if PROP not in parent.keys():
        parent[PROP] = 0.0
    _make_driver(parent, "location", 2, parent)
    lifted_with = []
    if include_projectors:
        for name, _mesh, _kind, action in outside(rig):
            obj = bpy.data.objects.get(name)
            if obj is not None and action == "lift":
                _make_driver(obj, "delta_location", 2, parent)
                lifted_with.append(name)
    # inside the parent already (a bone-parented projector): the parent lifts it; an old driver would lift it twice
    unlifted = _unlift_stale(rig)
    _write(rig, height)
    return {"height_mm": round(height * 1000.0, 3), "holder": parent.name, "with": lifted_with,
            "double_lift_removed": unlifted,
            "left_alone": [r for r in outside(rig) if r[3] != "lift"]}, ""


def clear(rig):
    parent = holder(rig)
    if parent is None or PROP not in parent.keys():
        return None, "There is no lift on this rig."
    _write(rig, 0.0)
    return {"holder": parent.name}, ""


def remove(rig):
    """Take the drivers and properties away and put every object back where it was."""
    parent = holder(rig)
    if parent is None:
        return None, "The rig has no parent object."
    removed = 0
    targets = [(parent, "location")] + [(bpy.data.objects.get(r[0]), "delta_location") for r in outside(rig) if r[3] == "lift"]
    for obj, path in targets:
        if obj is None:
            continue
        fc = _driver(obj, path, 2)
        if fc is not None:
            obj.driver_remove(path, 2)
            getattr(obj, path)[2] = 0.0
            obj.update_tag()
            removed += 1
    removed += len(_unlift_stale(rig))
    for prop in (PROP, MEASURED):
        if prop in parent.keys():
            del parent[prop]
    bpy.context.view_layer.update()
    return {"drivers_removed": removed}, ""


def state(rig):
    """'none', 'lifted' or 'cleared', with the numbers, for the panel."""
    parent = holder(rig)
    if parent is None or PROP not in parent.keys():
        return "none", 0.0, float(parent.get(MEASURED, 0.0)) if parent is not None else 0.0
    h = float(parent.get(PROP, 0.0))
    return ("lifted" if abs(h) > EPS else "cleared"), h, float(parent.get(MEASURED, 0.0))


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
