# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import json
import re
from typing import Any

import bpy
from bpy.props import EnumProperty, StringProperty

from . import audit
from . import eye_setup
from . import knee_profile
from . import knee_split
from . import joint_setup
from . import hair_chain
from . import part_rig
from . import bind_common
from . import face_regions
from . import corrective
from . import rig_hygiene
from . import costume_bind
from . import jiggle
from . import collide
from . import cloth_setup
from . import shoe_lift
from . import character_rescale
from . import cuff_push
from . import eye_shadow
from . import wrist_fold
from . import shoulder_lift
from . import compare
from . import face_falloff
from . import mocap
from . import band_width
from . import kilt_strips
from . import follow_strips
from . import ikfk
from . import chain_group
from .external_tools import (
    tool_label,
    call_operator,
    discover_ai_runtime,
    dump_json,
    likely_armature,
    missing_markers,
    open_folder,
    operator_exists,
    prepare_armature_mode,
    prepare_bind_selection,
    prepare_body_mesh,
    refresh_ui_status,
    selected_meshes,
    select_only,
    set_arp_ai_path,
    text_block_write,
    validate_ai_runtime,
)
from .legacy_cleanup import clean_legacy_scene_data, legacy_scene_candidates
from .preferences import get_preferences
from .i18n import _JA, is_japanese, report_ja, report_value, tr, tr_format
from .properties import RESCALE_BASES, RESCALE_MODES
from . import generation
from .lifecycle import register_classes, unregister_owned_classes


def _settings(context):
    return context.scene.srs_settings


def _prefs(context):
    return get_preferences(context)


_REPORT_JA_EXACT = {
    "External operator cancelled.": "外部オペレーターはキャンセルされました。",
    "External tool status refreshed.": "外部ツールの状態を再検出しました。",
    "Select an armature and/or body mesh first.": "先にアーマチュアまたはボディメッシュを選択してください。",
    "Auto-Rig Pro add-limb operator is not available.": "Auto-Rig Proのリム追加オペレーターを利用できません。",
    "No reference armature was found.": "参照アーマチュアが見つかりません。",
    "The selected reference-limb preset is not valid.": "選択した参照リムプリセットは無効です。",
    "No rig armature was found.": "リグアーマチュアが見つかりません。",
    "This rig has no animation, so there is no root motion to process.": "このリグには動作（アクション）がないため、処理するルートモーションがありません。",
    "This rig has no reversed spine, so there is nothing to snap.": "このリグには逆方向の背骨がないため、スナップできません。",
    "Select a compatible pose controller first.": "先に互換性のあるポーズコントローラーを選択してください。",
    "Auto-Rig Pro is not enabled.": "Auto-Rig Proが有効になっていません。",
    "No armature found.": "アーマチュアが見つかりません。",
    "No armature was found.": "アーマチュアが見つかりません。",
    "No body mesh was found.": "ボディメッシュが見つかりません。",
    "Select the body mesh before running body marker AI.": "ボディマーカーAIを実行する前にボディメッシュを選択してください。",
    "Missing required marker: hand_tip_loc": "必須マーカーがありません: hand_tip_loc",
    "Auto-Rig Pro smart detection is not enabled.": "Auto-Rig Proのスマート検出を利用できません。",
    "No complete external AI runtime was found.": "完全な外部AIランタイムが見つかりません。",
    "Missing: AI runtime path": "AIランタイムパスが設定されていません。",
    "AI_win inference executables can only run on Windows x64.": "AI_winの推論実行ファイルはWindows x64環境でのみ実行できます。",
    "External Proxy Picker action completed.": "外部Proxy Pickerの処理が完了しました。",
    "AI runtime path synchronized to Auto-Rig Pro.": "AIランタイムパスをAuto-Rig Proへ同期しました。",
    "Configure a valid external AI runtime first.": "先に有効な外部AIランタイムを設定してください。",
    "Select an active pose bone.": "アクティブなポーズボーンを選択してください。",
    "Proxy Picker is not enabled.": "Proxy Pickerが有効になっていません。",
    "Select the proxy bone and at least one target bone.": "プロキシボーンと1本以上のターゲットボーンを選択してください。",
    "The named Bone Collection does not exist.": "指定したボーンコレクションは存在しません。",
    "Bone Collection button assigned.": "ボーンコレクション切り替えボタンを設定しました。",
    "No matching proxy/target bone pairs were found.": "名前規則に一致するプロキシ/ターゲットボーンのペアが見つかりません。",
    "No legacy embedded Smart Rig Suite data was found.": "旧内蔵版Smart Rig Suiteのデータは見つかりませんでした。",
    "Shared Actions are not changed by IK/FK switch.": "共有ActionはIK/FK切り替えで変更できません。",
    "Contributing NLA strips are not changed by IK/FK switch.": "現在のポーズに寄与するNLAストリップがあるため、IK/FK切り替えを中止しました。",
    "Subframe IK/FK switching is rejected before mutation.": "サブフレームでのIK/FK切り替えは変更前に中止しました。",
    "An unambiguous Action slot is required before IK/FK switch.": "IK/FK切り替えには一意に決まるActionスロットが必要です。",
    "The assigned Action slot is ambiguous.": "割り当てられたActionスロットを一意に特定できません。",
    "NLA tweak mode is not supported by IK/FK switch.": "NLA調整モード中はIK/FK切り替えを実行できません。",
    "Scene unit scale_length must be finite and positive.": "シーンの単位スケールには有限の正の値が必要です。",
    "Auto-Rig Pro preferences were not found.": "Auto-Rig Proの設定が見つかりません。",
    "The external AI runtime is incomplete or older than version 1.20.": "外部AIランタイムが不完全か、バージョン1.20未満です。",
    "Folder does not exist.": "フォルダーが存在しません。",
    "No mesh object is selected, configured, or already bound to the rig.": "選択済み、設定済み、またはリグへバインド済みのメッシュがありません。",
    "Select the part, with a rig set.": "パーツを選び、リグを設定してください。",
    "That mesh has no vertices.": "そのメッシュには頂点がありません。",
    "No deform bone is near the top of the part": "パーツの上端の近くに変形する骨がありません。",
    "Need the mesh and the armature": "メッシュとアーマチュアが必要です。",
    "Axis must be X, Y or Z": "軸は X・Y・Z のどれかです。",
    "Need at least two divisions": "区切りが 2 つ以上必要です。",
    "No vertex was given to chain": "鎖にする頂点がありません。",
    "No vertex was given": "頂点がありません。",
    "No vertices were given": "頂点がありません。",
    "No link was given": "リンクがありません。",
    "Select the mesh": "メッシュを選んでください。",
    "Need the part, the donor and the rig": "パーツ、写し元、リグが必要です。",
    "No armature": "アーマチュアがありません。",
    "No mesh": "メッシュがありません。",
    "No mesh was given": "メッシュがありません。",
    "A chain needs at least two joints": "鎖には関節が 2 つ以上必要です。",
    "Nothing to copy from: every vertex is loose": "写し元がありません。すべての頂点が離れています。",
    "Select the strap's vertices in Edit Mode, from the loop where it should start.": "編集モードで、始めたいループからストラップの頂点を選んでください。",
    "The selection is a whole piece; select from the loop where the strap should start.": "選択が部品全体です。ストラップを始めたいループから選んでください。",
    "The selection has fewer than two loops.": "選択のループが 2 つ未満です。",
    "the mesh has no divisions along that axis": "メッシュにその軸に沿った区切りがありません。",
    "no division lies between the given ends": "指定した両端の間に区切りがありません。",
    "Nothing to build": "作る物がありません。",
    "The chains do not all have the same bone count": "鎖の骨の本数が揃っていません。",
    "The armature's transform cannot be inverted": "アーマチュアのトランスフォームの逆行列を求められません。",
    "No mesh to transfer onto": "写し先のメッシュがありません。",
    "No donor mesh": "写し元のメッシュがありません。",
}


def _localize_ai_runtime_items(items: str) -> str:
    # Known sentence-like entries of AIRuntimeStatus.missing.  File names such
    # as info.dat or inference executables are technical identifiers and are
    # intentionally preserved as-is.
    items = items.replace(
        "Extract the external AI runtime ZIP before selecting it",
        "選択前に外部AIランタイムのZIPを展開してください",
    )
    items = re.sub(
        r"AI runtime version ([0-9.]+) or newer",
        lambda m: f"AIランタイムバージョン{m.group(1)}以上",
        items,
    )
    items = items.replace("AI runtime path", "AIランタイムパス")
    return items


def _tool_ja(label: str) -> str:
    return "外部ツール" if label == "the external tool" else label + " "


def _mode_ja(mode: str) -> str:
    return {"pose": "ポーズ", "edit": "編集", "object": "オブジェクト"}.get(mode.lower(), mode)


def _localized_report_message(message: str) -> str:
    if not is_japanese():
        return message
    exact = _REPORT_JA_EXACT.get(message)
    if exact is not None:
        return exact

    patterns = (
        # the chains: swing, parts and the capsules they stop at
        (r"^Removed (\d+) curve\(s\) from (\d+) chain\(s\)\.(?: Left alone, not in the bake: (.+)\.)?$", lambda m: f"{m.group(2)} 本の鎖から {m.group(1)} 本のカーブを消しました。" + (f"焼きに入っていないので残した鎖：{m.group(3)}。" if m.group(3) else "")),
        (r"^The rig's Action (.+) was linked from a library; it was made local so the keys can be written\.$", lambda m: f"リグのアクション {m.group(1)} はライブラリからのリンクだったので、キーを書くためにローカルにしました。"),
        (r"^The rig's Action (.+) is linked and could not be made local(?: \(.+\))?\. Nothing was changed\.$", lambda m: f"リグのアクション {m.group(1)} はリンクされていて、ローカルにできませんでした。何も変更していません。"),
        (r"^(\d+) chains put into the bake\.$", lambda m: f"{m.group(1)} 本の鎖を焼きに入れました。"),
        (r"^(\d+) chains left out of the bake\.$", lambda m: f"{m.group(1)} 本の鎖を焼きから外しました。"),
        (r"^(\d+) chains muted \((\d+) curves\)\.$", lambda m: f"{m.group(1)} 本の鎖の揺れを止めました（カーブ {m.group(2)} 本）。"),
        (r"^(\d+) chains playing their bake \((\d+) curves\)\.$", lambda m: f"{m.group(1)} 本の鎖の揺れを戻しました（カーブ {m.group(2)} 本）。"),
        (r"^(\d+) chains: collision (on|off)\.$", lambda m: f"{m.group(1)} 本の鎖：当たり判定を{ {'on': 'オン', 'off': 'オフ'}[m.group(2)] }にしました。"),
        (r"^(\d+) chains: gravity from the rest shape\.$", lambda m: f"{m.group(1)} 本の鎖：重力を静止の形からにしました。"),
        (r"^(\d+) chains: gravity straight down\.$", lambda m: f"{m.group(1)} 本の鎖：重力を真下にしました。"),
        (r"^(\d+) chains: capsules keep the rest pose clear\.$", lambda m: f"{m.group(1)} 本の鎖：カプセルが静止の姿勢を避けるようにしました。"),
        (r"^(\d+) chains: capsules at full size\.$", lambda m: f"{m.group(1)} 本の鎖：カプセルを元の大きさにしました。"),
        (r"^(.+) carries no mesh to measure\.$", lambda m: f"{m.group(1)} には測るメッシュがありません。"),
        (r"^(\d+) chains: thickness cleared\.$", lambda m: f"{m.group(1)} 本の鎖：太さを消しました。"),
        (r"^(\d+) chains: thickness measured, up to ([\d.]+) mm\.$", lambda m: f"{m.group(1)} 本の鎖：太さを測りました（最大 {m.group(2)} mm）。"),
        (r"^(\d+) chains: pushed out on entry\.$", lambda m: f"{m.group(1)} 本の鎖：入った時に押し出すようにしました。"),
        (r"^(\d+) chains: every contact eases out\.$", lambda m: f"{m.group(1)} 本の鎖：当たりをゆっくり抜けるようにしました。"),
        (r"^(\d+) chains: swing layer removed\.$", lambda m: f"{m.group(1)} 本の鎖：揺れの層を外しました。"),
        (r"^(\d+) chains: swing layer on switch (.+) = (\d+)\.$", lambda m: f"{m.group(1)} 本の鎖：揺れの層を付けました（切替 {m.group(2)} = {m.group(3)}）。"),
        (r"^Part (.+) removed\.$", lambda m: f"部品 {m.group(1)} を外しました。"),
        (r"^Taken from part: (.+)\.$", lambda m: f"次の部品から鎖を移しました：{m.group(1)}。"),
        (r"^Part (.+): (\d+) chains on (.+)\.$", lambda m: f"部品 {m.group(1)}：{m.group(2)} 本の鎖を {m.group(3)} に登録しました。"),
        (r"^No part (.+) with a mode (.+)\.$", lambda m: f"モード {m.group(2)} を持つパーツ {m.group(1)} はありません。"),
        (r"^(\d+) part\(s\) on (.+)\.$", lambda m: f"{m.group(1)} 個の部品を {dict(hand='手付け', sim='シミュ').get(m.group(2), m.group(2))} にしました。"),
        (r"^Clamped: (.+)\.$", lambda m: "制限しました：" + "／".join(_localized_report_message(p) for p in m.group(1).split("; ")) + "。"),
        (r"^No part called (.+?)(?: on this rig)?\.?$", lambda m: f"{m.group(1)} というパーツはありません。"),
        (r"^(.+) has no mode (.+) \(it has (.+)\)$", lambda m: f"{m.group(1)} にモード {m.group(2)} はありません（あるモード：{m.group(3)}）。"),
        (r"^Baked (\d+) part\(s\), (\d+) chain\(s\)\.$", lambda m: f"{m.group(1)} 個の部品、{m.group(2)} 本の鎖を焼きました。"),
        (r"^No bone called: (.+)\.$", lambda m: f"次の名前の骨がありません：{m.group(1)}。"),
        (r"^Mark removed from (.+)\.$", lambda m: f"{m.group(1)} から鎖の印を外しました。"),
        (r"^(.+): (\d+) bones marked as a chain\.$", lambda m: f"{m.group(1)}：{m.group(2)} 本の骨を鎖として印を付けました。"),
        (r"^No chain under: (.+?)\.?$", lambda m: f"次の名前の鎖がありません：{m.group(1)}。"),
        (r"^No chain called '(.+)' under '(.+)'$", lambda m: f"{m.group(2)} の下に {m.group(1)} という鎖はありません。"),
        (r"^Chain (.+) has hand keys on its links \((\d+) curves\)\. Give it a swing layer, or clear them, before baking -- the bake would write over them\. Nothing was changed\.$", lambda m: f"鎖 {m.group(1)} には手で打ったキーがあります（カーブ {m.group(2)} 本）。焼くと上書きするので、先に揺れの層を付けるか、キーを消してください。何も変更していません。"),
        (r"^The rig is hidden from the viewport, so its pose cannot be evaluated and the solve would run against a frozen body\. Un-hide (.+) \(the monitor icon\) and bake again\.$", lambda m: f"リグがビューポートで隠れているので、ポーズを評価できず、止まった体を相手に解くことになります。{m.group(1)} を表示して（モニターのアイコン）、もう一度焼いてください。"),
        (r"^Colliders (shown|hidden)\.$", lambda m: f"カプセルを{ {'shown': '表示', 'hidden': '非表示'}[m.group(1)] }にしました。"),
        (r"^Removed (\d+) capsule bone\(s\)\.$", lambda m: f"カプセルの骨を {m.group(1)} 本消しました。"),
        (r"^(\d+) bones rolled; (\d+) open outward under \+X\.$", lambda m: f"{m.group(1)} 本の骨のロールを直しました。X の正の回転で外へ開く骨は {m.group(2)} 本です。"),
        (r"^(\d+) of (\d+) capsules are smaller without (.+)\.$", lambda m: f"{m.group(2)} 個のカプセルのうち {m.group(1)} 個は、{m.group(3)} を除くと小さくなります。"),
        (r"^Removed (\d+) collision mesh\(es\)\.$", lambda m: f"当たりのメッシュを {m.group(1)} 個消しました。"),
        (r"^(.+) carries no weights, so there is nothing to copy$", lambda m: f"{m.group(1)} にはウェイトが無いので、写す物がありません。"),
        (r"^(.+) has no vertices$", lambda m: f"{m.group(1)} には頂点がありません。"),
        (r"^(.+) did not reach every vertex, so part of it would stay behind when the rig moves$",
         lambda m: f"{m.group(1)} の全部の頂点には届かなかったので、リグを動かすと一部が取り残されます。"),
        (r"^(.+) received no weights at all -- check that it and its collections are visible and selectable$",
         lambda m: f"{m.group(1)} にウェイトが全く写りませんでした。そのメッシュとコレクションが見えていて選択できるかを確かめてください。"),
        (r"^The weight transfer would not accept a source-layer setting: (.+)$",
         lambda m: "ウェイトの転送が転送元レイヤーの設定を受け付けませんでした。"),
        (r"^That strand has (\d+) loop\(s\) past the (\d+)th; a chain needs two$",
         lambda m: f"この毛束は {m.group(2)} 番目より先のループが {m.group(1)} 個です。鎖には 2 個必要です。"),
        (r"^Chain (.+) has hand keys on its links \((\d+) curves\)\. Give it a swing layer, or clear them, before baking -- the bake would write over them\. Nothing was changed\.$",
         lambda m: f"鎖 {m.group(1)} の骨に手付けのキー（{m.group(2)} 本の曲線）があります。焼くと上書きになるので何も変えませんでした。揺れの層を付けるか、そのキーを消してから焼いてください（同梱の Action なら、統合で直した版を使ってください）。"),
        (r"^The rig's Action (.+) was linked from a library; it was made local so the keys can be written\.$",
         lambda m: f"rig の Action「{m.group(1)}」はライブラリからのリンクだったので、キーを書けるようにローカルにしました。"),
        (r"^The rig's Action (.+) is linked and could not be made local(.*)\. Nothing was changed\.$",
         lambda m: f"rig の Action「{m.group(1)}」はリンクのままローカルにできませんでした{m.group(2)}。何も変えていません。"),
        (r"^The bake did not run; see the report above\.$", lambda m: "焼きは実行されませんでした。理由は直前の報告を見てください。"),
        (r"^Workflow targets updated: armature=(.*), body=(.*)$", lambda m: f"ワークフロー対象を更新しました: アーマチュア={m.group(1)}, ボディ={m.group(2)}"),
        (r"^Workflow preflight completed: (\d+)/(\d+) checks passed\.$", lambda m: f"ワークフロー事前検証が完了しました: {m.group(1)}/{m.group(2)}項目に合格しました。"),
        (r"^External reference limb added: (.+)$", lambda m: f"外部ツールで参照リムを追加しました: {m.group(1)}"),
        (r"^External snap operator is unavailable: (.+)$", lambda m: f"外部スナップオペレーターを利用できません: {m.group(1)}"),
        (r"^External controller snap completed\.$", lambda m: "外部ツールのコントローラースナップが完了しました。"),
        (r"^Reference rig preset '(.+)' launched\.$", lambda m: f"参照リグプリセット「{m.group(1)}」を開始しました。"),
        (r"^Prepared armature: (.+)$", lambda m: f"アーマチュアを準備しました: {m.group(1)}"),
        (r"^Required external operator is unavailable: (.+)$", lambda m: f"必要な外部オペレーターを利用できません: {m.group(1)}"),
        (r"^Missing required markers?: (.+)$", lambda m: f"必須マーカーがありません: {m.group(1)}"),
        (r"^External (body|fingers|facial) marker AI started\.$", lambda m: {"body": "外部ボディマーカーAIを開始しました。", "fingers": "外部指マーカーAIを開始しました。", "facial": "外部フェイシャルマーカーAIを開始しました。"}[m.group(1)]),
        (r"^Missing markers: (.+)$", lambda m: f"不足しているマーカー: {m.group(1)}"),
        (r"^External smart detection started\.$", lambda m: "外部ツールのスマート検出を開始しました。"),
        (r"^External match-to-rig started\.$", lambda m: "外部ツールのリグ適合処理を開始しました。"),
        (r"^External operator is unavailable: (.+)$", lambda m: f"外部オペレーターを利用できません: {m.group(1)}"),
        (r"^External (bind|unbind|rebind) started for (\d+) mesh object\(s\)\.$", lambda m: f"外部ツールの{ {'bind': 'バインド', 'unbind': 'バインド解除', 'rebind': 'リバインド'}[m.group(1)] }を{m.group(2)}個のメッシュで開始しました。"),
        (r"^External rig-tools operator is unavailable: (.+)$", lambda m: f"外部リグツールのオペレーターを利用できません: {m.group(1)}"),
        (r"^External IK/FK operation completed\.$", lambda m: "外部ツールのIK/FK操作が完了しました。"),
        (r"^External pose utility completed: (.+)$", lambda m: f"外部ツールのポーズ操作が完了しました: {_JA.get(m.group(1), m.group(1))}"),
        (r"^AI runtime detected: (.+)$", lambda m: f"AIランタイムを検出しました: {m.group(1)}"),
        (r"^Missing: (.+)$", lambda m: f"不足ファイル: {_localize_ai_runtime_items(m.group(1))}"),
        (r"^External AI runtime is incomplete: (.+)$", lambda m: f"外部AIランタイムが不完全です: {_localize_ai_runtime_items(m.group(1))}"),
        (r"^AI runtime valid\. Version: (.+)$", lambda m: f"AIランタイムは有効です。バージョン: {m.group(1)}"),
        (r"^Assigned (\d+) proxy pair\(s\) through Proxy Picker\.$", lambda m: f"Proxy Pickerで{m.group(1)}組のプロキシペアを設定しました。"),
        (r"^Proxy audit completed with (\d+) issue\(s\)\.$", lambda m: f"プロキシ監査が完了しました。検出問題数: {m.group(1)}"),
        (r"^Removed (\d+) role\(s\), pruned (\d+) target\(s\)\.$", lambda m: f"{m.group(1)}件の役割を削除し、{m.group(2)}件の存在しないターゲットを除外しました。"),
        (r"^Exported (\d+) proxy mapping\(s\)\.$", lambda m: f"{m.group(1)}件のプロキシ対応を書き出しました。"),
        (r"^Text datablock not found: (.+)$", lambda m: f"Textデータブロックが見つかりません: {m.group(1)}"),
        (r"^Invalid proxy-map JSON\. Check its format\.$", lambda m: "プロキシ対応の JSON を読めませんでした。形式を確かめてください。"),
        (r"^Imported (\d+) mapping\(s\); (\d+) bone\(s\) missing\.$", lambda m: f"{m.group(1)}件の対応を読み込みました。存在しないボーン: {m.group(2)}本"),
        (r"^Weight audit: (\d+) unweighted, (\d+) non-normalized\.$", lambda m: f"ウェイト監査: 未ウェイト{m.group(1)}頂点、非正規化{m.group(2)}頂点。"),
        (r"^Full audit written to Text datablock: (.+)$", lambda m: f"総合監査をTextデータブロックへ書き出しました: {m.group(1)}"),
        (r"^Removed (\d+) legacy object\(s\) and (\d+) scene property value\(s\)\.$", lambda m: f"旧内蔵版オブジェクト{m.group(1)}個とシーンプロパティ値{m.group(2)}件を削除しました。"),
        (r"^Integration report written: (.+)$", lambda m: f"連携レポートを書き出しました: {m.group(1)}"),
        (r"^Operator not registered: (.+)$", lambda m: f"{_tool_ja(m.group(1))}の機能が登録されていません。有効になっているかを確かめてください。"),
        (r"^A 3D View context is required: (.+)$", lambda m: f"{_tool_ja(m.group(1))}の機能は、3D ビューのある画面で実行してください。"),
        (r"^Operator context is not valid: (.+)$", lambda m: f"今の状態では{_tool_ja(m.group(1))}の機能を実行できません。選択とモードを確かめてください。"),
        (r"^Operator poll failed: (.+)$", lambda m: f"{_tool_ja(m.group(1))}の機能を実行できるかを確かめられませんでした。選択とモードを確かめてください。"),
        (r"^The external tool stopped with an error\..*$", lambda m: "外部ツールがエラーで止まりました。選択とモードを確かめて、もう一度実行してください。"),
        (r"^Could not prepare a 3D View for the external tool\.$", lambda m: "3D ビューを一時的に使う準備ができませんでした。"),
        (r"^Could not enter (.+) mode in the current context\.$", lambda m: f"今の状態では{_mode_ja(m.group(1))}モードにできません。"),
        (r"^The armature did not enter (.+) mode\.$", lambda m: f"アーマチュアを{_mode_ja(m.group(1))}モードにできませんでした。"),
        (r"^Failed to update Auto-Rig Pro AI path\.$", lambda m: "Auto-Rig Pro の AI パスを更新できませんでした。"),
        (r"^Could not open folder\.$", lambda m: "フォルダーを開けませんでした。"),
        (r"^Could not write JSON\. Check the output path\.$", lambda m: "JSON を書き出せませんでした。書き出し先を確かめてください。"),
        (r"^(.+) Rollback failed\.$", lambda m: _localized_report_message(m.group(1)) + "元に戻すのにも失敗しました。"),
    )
    for pattern, formatter in patterns:
        match = re.match(pattern, message, re.S)
        if match:
            return formatter(match)
    return _JA.get(message) or report_ja(message, _localized_report_message)


def _report_list(items, separator: str) -> str:
    """Items of a report, each translated by itself so the list cannot run together."""
    items = [str(item) for item in items]
    if is_japanese():
        return "／".join(_localized_report_message(item) for item in items)
    return separator.join(items)


def _ascii_report(operator: bpy.types.Operator, level: set[str], message: str) -> None:
    # Reports follow Blender's selected UI language.  Technical identifiers and
    # external exception details are preserved when no safe translation exists.
    operator.report(level, _localized_report_message(str(message)))


def _external_result(operator: bpy.types.Operator, result: set[str], error: str, success: str) -> set[str]:
    if any(state in result for state in ("FINISHED", "RUNNING_MODAL", "INTERFACE", "PASS_THROUGH")):
        _ascii_report(operator, {"INFO"}, success)
        return result
    _ascii_report(operator, {"WARNING"}, error or "External operator cancelled.")
    return {"CANCELLED"}


def _configured_ai_path(context) -> str:
    preferences = _prefs(context)
    return str(getattr(preferences, "ai_runtime_path", "") or "") if preferences else ""


def _validated_ai(context) -> tuple[bool, str]:
    preferences = _prefs(context)
    status = discover_ai_runtime(_configured_ai_path(context), context)
    if not status.valid:
        missing = ", ".join(status.missing[:6]) if status.missing else "runtime path"
        return False, f"External AI runtime is incomplete: {missing}"
    if not status.platform_compatible:
        return False, "AI_win inference executables can only run on Windows x64."
    if preferences is not None and not preferences.ai_runtime_path:
        preferences.ai_runtime_path = status.root
    if preferences is not None and preferences.auto_sync_ai_path:
        ok, error = set_arp_ai_path(status.root, context)
        if not ok:
            return False, error
    return True, status.root


class SRS_OT_refresh_external_status(bpy.types.Operator):
    bl_idname = "srs.refresh_external_status"
    bl_label = "Refresh External Status"
    bl_description = (
        "Re-scan separately installed external tools and update the status shown in the Smart Rig panel. "
        "No external add-on files are changed."
    )

    def execute(self, context):
        try:
            from .compatibility import install_proxy_picker_context_guard
            install_proxy_picker_context_guard()
        except Exception:
            pass
        snapshot = refresh_ui_status(_configured_ai_path(context), context)
        status = snapshot.status
        _settings(context).last_status = json.dumps(status.to_dict(), ensure_ascii=False)
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
        _ascii_report(self, {"INFO"}, "External tool status refreshed.")
        return {"FINISHED"}


class SRS_OT_assign_workflow_targets(bpy.types.Operator):
    bl_idname = "srs.assign_workflow_targets"
    bl_label = "Assign Workflow Targets"
    bl_description = (
        "Store the active or selected armature and body mesh as explicit Smart Rig Suite workflow targets. "
        "These pointers are used to prepare external tool contexts without copying external functionality."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = None
        body = None
        active = context.active_object
        if active is not None:
            if active.type == "ARMATURE":
                armature = active
            elif active.type == "MESH":
                body = active
        for obj in context.selected_objects:
            if armature is None and obj.type == "ARMATURE":
                armature = obj
            if body is None and obj.type == "MESH":
                body = obj
        if armature is None:
            armature = likely_armature(context)
        if body is None:
            meshes = selected_meshes(context)
            body = meshes[0] if meshes else None
        if armature is None and body is None:
            _ascii_report(self, {"WARNING"}, "Select an armature and/or body mesh first.")
            return {"CANCELLED"}
        if armature is not None:
            settings.target_armature = armature
        if body is not None:
            settings.target_body_mesh = body
        _ascii_report(
            self,
            {"INFO"},
            f"Workflow targets updated: armature={armature.name if armature else '-'}, body={body.name if body else '-'}",
        )
        return {"FINISHED"}


class SRS_OT_workflow_preflight(bpy.types.Operator):
    bl_idname = "srs.workflow_preflight"
    bl_label = "Workflow Preflight"
    bl_description = (
        "Check external tool registration, AI runtime version, explicit workflow targets, required markers, "
        "duplicate RNA registrations, and obsolete embedded modules before starting a rigging workflow."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        report = audit.build_workflow_preflight(_configured_ai_path(context))
        preferences = _prefs(context)
        base_name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        name = base_name + " - Preflight"
        text_block_write(name, json.dumps(report, ensure_ascii=False, indent=2))
        _settings(context).last_preflight_text = name
        _settings(context).last_report_text = name
        ready = sum(1 for value in report["checks"].values() if value)
        total = len(report["checks"])
        level = {"INFO"} if ready == total else {"WARNING"}
        _ascii_report(self, level, f"Workflow preflight completed: {ready}/{total} checks passed.")
        return {"FINISHED"}


class SRS_OT_arp_add_limb_safe(bpy.types.Operator):
    bl_idname = "srs.arp_add_limb_safe"
    bl_label = "Add Reference Limb Safely"
    bl_description = (
        "Activate the configured reference armature, enter Armature Edit Mode, validate the selected limb preset, "
        "and then call the separately installed Auto-Rig Pro add-limb operator."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        if not operator_exists("arp.add_limb"):
            _ascii_report(self, {"WARNING"}, "Auto-Rig Pro add-limb operator is not available.")
            return {"CANCELLED"}
        armature, error = prepare_armature_mode("EDIT", context)
        if armature is None or error:
            _ascii_report(self, {"WARNING"}, error or "No reference armature was found.")
            return {"CANCELLED"}
        preset = str(_settings(context).limb_preset or "arm.l")
        allowed = {
            "arm.l", "arm.r", "leg.l", "leg.r", "spine", "head", "ears", "breast",
            "tail", "spline_ik", "bbones", "kilt",
        }
        if preset not in allowed:
            _ascii_report(self, {"WARNING"}, "The selected reference-limb preset is not valid.")
            return {"CANCELLED"}
        result, op_error = call_operator(
            "arp.add_limb",
            execution="EXEC_DEFAULT",
            kwargs={"limbs_presets": preset},
        )
        return _external_result(self, result, op_error, f"External reference limb added: {preset}")


_ARP_ARM_CONTROLLERS = frozenset({
    "c_arm_fk", "c_forearm_fk", "c_hand_fk", "arm_fk_pole", "arm_ik", "forearm_ik", "c_hand_ik",
    "c_arms_pole", "c_arm_ik", "c_hand_ik_offset", "c_hand_ik_pivot",
})
_ARP_LEG_CONTROLLERS = frozenset({
    "c_thigh_fk", "c_leg_fk", "c_foot_fk", "c_toes_fk", "leg_fk_pole", "c_thigh_b_fk", "thigh_ik", "leg_ik",
    "c_foot_ik", "c_leg_pole", "c_toes_ik", "c_foot_01", "c_foot_roll_cursor", "foot_snap_fk", "c_thigh_ik",
    "c_toes_pivot", "c_foot_ik_offset", "c_thigh_b", "c_leg_ik3", "c_foot_ik_pivot",
})


def _arp_limb_snap_target(armature, bone_name, operator_id):
    """Return the arguments for a limb snap, or None when the bone has no limb to snap.

    ARP works out the side and limb in the pole operator's invoke, so a direct call has to supply them.
    """
    side = bone_name[-12:] if "_dupli_" in bone_name else bone_name[-2:]
    base = bone_name[:-len(side)]
    bones = armature.pose.bones
    if base in _ARP_ARM_CONTROLLERS:
        limb = "arm"
    elif base in _ARP_LEG_CONTROLLERS:
        limb = "leg"
    else:
        return None
    if operator_id == "pose.arp_snap_pin":
        stretch = bones.get(f"c_stretch_{limb}{side}")
        pin = bones.get(f"c_stretch_{limb}_pin{side}")
        prop = "leg_pin" if limb == "leg" else "elbow_pin"
        return {} if stretch is not None and pin is not None and prop in stretch.keys() else None
    bone_type = "leg" if limb == "leg" else "arms"
    pole = bones.get(f"c_{bone_type}_pole{side}")
    if pole is None or "pole_parent" not in pole.keys():
        return None
    target = {"side": side, "bone_type": bone_type}
    if limb == "leg" and len(pole.constraints) > 2:
        # Same choice ARP preselects in its dialog: leave for the other space.
        target["multi_cns"] = True
        target["space_target"] = "GLOBAL" if pole["pole_parent"] == 2 else "SMART"
    return target


class SRS_OT_arp_snap_safe(bpy.types.Operator):
    bl_idname = "srs.arp_snap_safe"
    bl_label = "Safe Controller Snap"
    bl_description = (
        "Prepare the configured rig in Pose Mode, require an active pose controller, and dispatch the selected "
        "snap operation to the separately installed rig tools."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        armature, error = prepare_armature_mode("POSE", context)
        if armature is None or error:
            _ascii_report(self, {"WARNING"}, error or "No rig armature was found.")
            return {"CANCELLED"}
        if context.active_pose_bone is None:
            _ascii_report(self, {"WARNING"}, "Select a compatible pose controller first.")
            return {"CANCELLED"}
        # ARP shows this button only when the root master carries the switch, and its operator
        # reads the switch unconditionally; the mode list here offers it on every rig.
        if _settings(context).snap_mode == "REVERSED_SPINE":
            name = context.active_pose_bone.name
            side = name[name.find("."):] if "." in name else ""
            master = armature.pose.bones.get("c_root_master" + side)
            if master is None or "reverse_spine" not in master.keys():
                _ascii_report(self, {"WARNING"}, "This rig has no reversed spine, so there is nothing to snap.")
                return {"CANCELLED"}
        operator_id = {
            "HEAD": "arp.snap_head",
            "POLE": "pose.arp_snap_pole",
            "PIN": "pose.arp_snap_pin",
            "REVERSED_SPINE": "pose.arp_snap_reversed_spine",
        }[_settings(context).snap_mode]
        if not operator_exists(operator_id):
            _ascii_report(self, {"WARNING"}, f"External snap operator is unavailable: {tool_label(operator_id)}")
            return {"CANCELLED"}
        # Both limb snaps act on the limb of the selected controller and quietly do nothing for any
        # other bone, which would otherwise be reported as a completed snap.
        call_kwargs = {}
        if operator_id in {"pose.arp_snap_pole", "pose.arp_snap_pin"}:
            # The pin operator reads the first selected bone, not the active one.
            selected = context.selected_pose_bones or []
            bone = context.active_pose_bone if operator_id == "pose.arp_snap_pole" else (selected[0] if selected else None)
            target = _arp_limb_snap_target(armature, bone.name, operator_id) if bone is not None else None
            if target is None:
                _ascii_report(self, {"WARNING"}, "Select a compatible pose controller first.")
                return {"CANCELLED"}
            call_kwargs = target
        result, op_error = call_operator(operator_id, execution="EXEC_DEFAULT", kwargs=call_kwargs)
        return _external_result(self, result, op_error, "External controller snap completed.")


class SRS_OT_arp_add_reference(bpy.types.Operator):
    bl_idname = "srs.arp_add_reference"
    bl_label = "Auto-Rig Pro Reference Rig"
    bl_description = (
        "Add a reference rig through the separately installed Auto-Rig Pro operator. Smart Rig Suite validates "
        "the preset and prevents an empty preset path from being passed."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        if not operator_exists("arp.append_arp"):
            _ascii_report(self, {"WARNING"}, "Auto-Rig Pro is not enabled.")
            return {"CANCELLED"}
        preset = str(_settings(context).rig_preset or "human").strip() or "human"
        if preset not in {"human", "free", "dog", "horse", "bird", "cs"}:
            preset = "human"
        result, error = call_operator("arp.append_arp", execution="EXEC_DEFAULT", kwargs={"rig_preset": preset})
        return _external_result(self, result, error, f"Reference rig preset '{preset}' launched.")


class SRS_OT_arp_prepare_context(bpy.types.Operator):
    bl_idname = "srs.arp_prepare_context"
    bl_label = "Prepare Rig Context"
    bl_description = (
        "Select and activate the most likely rig armature, enter the required mode when possible, and preserve "
        "the previous selection for safer external operator execution."
    )
    bl_options = {'UNDO'}
    target_mode: EnumProperty(
        items=(
            ("OBJECT", "Object", "Prepare Object Mode"),
            ("POSE", "Pose", "Prepare Pose Mode"),
            ("EDIT", "Edit", "Prepare Armature Edit Mode"),
        ),
        default="POSE",
    )

    def execute(self, context):
        armature, error = prepare_armature_mode(self.target_mode, context)
        if armature is None or error:
            _ascii_report(self, {"WARNING"}, error or "No armature found.")
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, f"Prepared armature: {armature.name}")
        return {"FINISHED"}


class SRS_OT_arp_marker_ai(bpy.types.Operator):
    bl_idname = "srs.arp_marker_ai"
    bl_label = "Body Marker AI"
    bl_description = (
        "Validate the external AI runtime, marker prerequisites, and Auto-Rig Pro availability, then start "
        "Auto-Rig Pro's own marker estimation."
    )
    bl_options = {'UNDO'}

    kind: EnumProperty(
        items=(
            ("BODY", "Body", "Run body-marker estimation"),
            ("FINGERS", "Fingers", "Run finger-marker estimation"),
            ("FACIAL", "Facial", "Run facial-marker estimation"),
        ),
        default="BODY",
    )

    def execute(self, context):
        op_map = {"BODY": "arp.guess_markers", "FINGERS": "arp.guess_fingers", "FACIAL": "arp.guess_facial"}
        operator_id = op_map[self.kind]
        if not operator_exists(operator_id):
            _ascii_report(self, {"WARNING"}, f"Required external operator is unavailable: {tool_label(operator_id)}")
            return {"CANCELLED"}
        ok, detail = _validated_ai(context)
        if not ok:
            _ascii_report(self, {"WARNING"}, detail)
            return {"CANCELLED"}
        if self.kind == "BODY":
            body, body_error = prepare_body_mesh(context)
            if body is None:
                _ascii_report(self, {"WARNING"}, body_error or "Select the body mesh before running body marker AI.")
                return {"CANCELLED"}
        elif self.kind == "FINGERS":
            missing = missing_markers("fingers")
            if missing:
                _ascii_report(self, {"WARNING"}, "Missing required marker: hand_tip_loc")
                return {"CANCELLED"}
        elif self.kind == "FACIAL":
            missing = missing_markers("facial")
            if missing:
                _ascii_report(self, {"WARNING"}, "Missing required markers: " + ", ".join(missing))
                return {"CANCELLED"}
        result, error = call_operator(operator_id, execution="INVOKE_DEFAULT")
        return _external_result(self, result, error, f"External {self.kind.lower()} marker AI started.")


class SRS_OT_arp_smart_detect(bpy.types.Operator):
    bl_idname = "srs.arp_smart_detect"
    bl_label = "Run Smart Detection"
    bl_description = (
        "Check all required body markers before launching Auto-Rig Pro's detection operator. Missing markers "
        "are listed instead of allowing an external traceback."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        if not operator_exists("id.go_detect"):
            _ascii_report(self, {"WARNING"}, "Auto-Rig Pro smart detection is not enabled.")
            return {"CANCELLED"}
        missing = missing_markers("required_body")
        if missing:
            _ascii_report(self, {"WARNING"}, "Missing markers: " + ", ".join(missing))
            return {"CANCELLED"}
        result, error = call_operator("id.go_detect", execution="INVOKE_DEFAULT")
        return _external_result(self, result, error, "External smart detection started.")


class SRS_OT_arp_match_to_rig(bpy.types.Operator):
    bl_idname = "srs.arp_match_to_rig"
    bl_label = "Match Reference to Rig"
    bl_description = (
        "Launch Auto-Rig Pro's match-to-rig operation only after a compatible reference armature has been "
        "found and activated."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        if not operator_exists("arp.match_to_rig"):
            _ascii_report(self, {"WARNING"}, "Auto-Rig Pro is not enabled.")
            return {"CANCELLED"}
        armature = likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        try:
            if armature.mode != "OBJECT" and bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode="OBJECT")
            context.view_layer.objects.active = armature
            armature.select_set(True)
        except Exception:
            pass
        result, error = call_operator("arp.match_to_rig", execution="INVOKE_DEFAULT")
        return _external_result(self, result, error, "External match-to-rig started.")


class SRS_OT_arp_bind_workflow(bpy.types.Operator):
    bl_idname = "srs.arp_bind_workflow"
    bl_label = "Bind Selected Meshes"
    bl_description = (
        "Prepare the selected meshes and target armature, then call Auto-Rig Pro's own bind, unbind, or scale-fix "
        "rebind operation. Smart Rig Suite does not implement a second bind system."
    )
    bl_options = {'UNDO'}

    mode: EnumProperty(
        items=(
            ("BIND", "Bind", "Bind selected meshes using Auto-Rig Pro"),
            ("UNBIND", "Unbind", "Unbind selected meshes using Auto-Rig Pro"),
            ("REBIND", "Rebind", "Run Auto-Rig Pro scale-fix rebind"),
        ),
        default="BIND",
    )

    def execute(self, context):
        if self.mode != "UNBIND":
            _lift_rig = shoe_lift.arp_rig(_settings(context).target_armature) or shoe_lift.arp_rig(likely_armature(context))
            if shoe_lift.guard_message(_lift_rig):
                _ascii_report(self, {"WARNING"}, shoe_lift.guard_message(_lift_rig))
                return {"CANCELLED"}
        operator_id = {
            "BIND": "arp.bind_to_rig",
            "UNBIND": "arp.unbind_to_rig",
            "REBIND": "arp.rebind_scale_fix",
        }[self.mode]
        if not operator_exists(operator_id):
            _ascii_report(self, {"WARNING"}, f"External operator is unavailable: {tool_label(operator_id)}")
            return {"CANCELLED"}
        armature, meshes, error = prepare_bind_selection(context)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if self.mode == "UNBIND":
            # The external unbind operator polls for an active mesh, while bind
            # and scale-fix rebind poll for an active armature.
            select_only([*meshes, armature], meshes[0], context)
        result, op_error = call_operator(operator_id, execution="INVOKE_DEFAULT")
        return _external_result(
            self,
            result,
            op_error,
            f"External {self.mode.lower()} started for {len(meshes)} mesh object(s).",
        )


class SRS_OT_arp_ikfk_safe(bpy.types.Operator):
    bl_idname = "srs.arp_ikfk_safe"
    bl_label = "Safe IK/FK Operation"
    bl_description = (
        "Use the active pose bone to call the corresponding operator supplied by the external rig tools. "
        "Smart Rig Suite only validates context and dispatches the operation."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        armature, error = prepare_armature_mode("POSE", context)
        if armature is None or error:
            _ascii_report(self, {"WARNING"}, error or "No armature found.")
            return {"CANCELLED"}
        if context.active_pose_bone is None:
            _ascii_report(self, {"WARNING"}, "Select a compatible pose controller first.")
            return {"CANCELLED"}
        operator_id = {
            "ARM_FK_TO_IK": "pose.arp_arm_fk_to_ik_",
            "ARM_IK_TO_FK": "pose.arp_arm_ik_to_fk_",
            "LEG_FK_TO_IK": "pose.arp_leg_fk_to_ik_",
            "LEG_IK_TO_FK": "pose.arp_leg_ik_to_fk_",
        }[_settings(context).ikfk_mode]
        if not operator_exists(operator_id):
            _ascii_report(self, {"WARNING"}, f"External rig-tools operator is unavailable: {tool_label(operator_id)}")
            return {"CANCELLED"}
        result, op_error = call_operator(operator_id, execution="EXEC_DEFAULT")
        return _external_result(self, result, op_error, "External IK/FK operation completed.")


POSE_UTILITY_LABELS = {"RESET": "Reset Pose", "EXTRACT_ROOT": "Extract Root Motion", "CLEAR_ROOT": "Clear Root Motion"}


class SRS_OT_arp_pose_utility(bpy.types.Operator):
    bl_idname = "srs.arp_pose_utility"
    bl_label = "Safe Pose Reset"
    bl_description = "Validate and prepare the pose context before calling an external rig-tools pose utility."
    bl_options = {'UNDO'}

    mode: EnumProperty(
        items=(
            ("RESET", "Reset Pose", "Call the external reset-pose operator"),
            ("EXTRACT_ROOT", "Extract Root Motion", "Call the external root-motion extraction operator"),
            ("CLEAR_ROOT", "Clear Root Motion", "Call the external root-motion cleanup operator"),
        ),
        default="RESET",
    )

    def execute(self, context):
        armature, error = prepare_armature_mode("POSE", context)
        if armature is None or error:
            _ascii_report(self, {"WARNING"}, error or "No armature found.")
            return {"CANCELLED"}
        operator_id = {
            "RESET": "arp.reset_pose",
            "EXTRACT_ROOT": "arp.extract_root_motion",
            "CLEAR_ROOT": "arp.clear_root_motion",
        }[self.mode]
        if not operator_exists(operator_id):
            _ascii_report(self, {"WARNING"}, f"External rig-tools operator is unavailable: {tool_label(operator_id)}")
            return {"CANCELLED"}
        # ARP takes the range from the action in its invoke; called directly it stays on frames 0-10.
        call_kwargs = {}
        if self.mode in {"EXTRACT_ROOT", "CLEAR_ROOT"}:
            action = armature.animation_data.action if armature.animation_data else None
            if action is None:
                _ascii_report(self, {"WARNING"}, "This rig has no animation, so there is no root motion to process.")
                return {"CANCELLED"}
            call_kwargs = {"frame_start": int(action.frame_range[0]), "frame_end": int(action.frame_range[1])}
        result, op_error = call_operator(operator_id, execution="EXEC_DEFAULT", kwargs=call_kwargs)
        return _external_result(self, result, op_error, f"External pose utility completed: {POSE_UTILITY_LABELS[self.mode]}")


class SRS_OT_ai_auto_detect(bpy.types.Operator):
    bl_idname = "srs.ai_auto_detect"
    bl_label = "Auto-detect AI Runtime"
    bl_description = (
        "Search the configured path and Auto-Rig Pro preferences for an external AI_win runtime. No archive "
        "is extracted and no binary is copied."
    )

    def execute(self, context):
        preferences = _prefs(context)
        if preferences is None:
            return {"CANCELLED"}
        status = discover_ai_runtime(preferences.ai_runtime_path, context)
        if not status.valid:
            _ascii_report(self, {"WARNING"}, "No complete external AI runtime was found.")
            return {"CANCELLED"}
        preferences.ai_runtime_path = status.root
        refresh_ui_status(status.root, context)
        _ascii_report(self, {"INFO"}, f"AI runtime detected: {status.root}")
        return {"FINISHED"}


class SRS_OT_ai_validate(bpy.types.Operator):
    bl_idname = "srs.ai_validate"
    bl_label = "Validate AI Runtime"
    bl_description = (
        "Check info.dat, the inference folder, required executables, and model files in the externally installed "
        "AI runtime."
    )

    def execute(self, context):
        configured = _configured_ai_path(context)
        status = validate_ai_runtime(configured)
        refresh_ui_status(configured, context)
        if not status.valid:
            _ascii_report(self, {"WARNING"}, "Missing: " + ", ".join(status.missing[:10]))
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, f"AI runtime valid. Version: {status.version or 'unknown'}")
        return {"FINISHED"}


class SRS_OT_ai_sync_arp(bpy.types.Operator):
    bl_idname = "srs.ai_sync_arp"
    bl_label = "Synchronize AI Path to Auto-Rig Pro"
    bl_description = (
        "Set Auto-Rig Pro's AI path preference to the validated external runtime folder. This changes only the "
        "preference value and does not modify Auto-Rig Pro files."
    )

    def execute(self, context):
        ok, error = set_arp_ai_path(_configured_ai_path(context), context)
        if not ok:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        refresh_ui_status(_configured_ai_path(context), context)
        _ascii_report(self, {"INFO"}, "AI runtime path synchronized to Auto-Rig Pro.")
        return {"FINISHED"}


class SRS_OT_ai_open_folder(bpy.types.Operator):
    bl_idname = "srs.ai_open_folder"
    bl_label = "Open AI Runtime Folder"
    bl_description = "Open the validated external AI runtime directory in the operating system file browser."

    def execute(self, context):
        status = validate_ai_runtime(_configured_ai_path(context))
        if not status.valid:
            _ascii_report(self, {"WARNING"}, "Configure a valid external AI runtime first.")
            return {"CANCELLED"}
        ok, error = open_folder(status.root)
        if not ok:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        return {"FINISHED"}


def _pose_selected(pose_bone) -> bool:
    try:
        return bool(pose_bone.select)
    except Exception:
        return bool(pose_bone.bone.select)


def _set_pose_selected(pose_bone, state: bool) -> None:
    try:
        pose_bone.select = state
    except Exception:
        pose_bone.bone.select = state


class SRS_OT_proxy_external_action(bpy.types.Operator):
    bl_idname = "srs.proxy_external_action"
    bl_label = "External Proxy Assignment"
    bl_description = (
        "Validate the active proxy bone and selected target bones, then call the separately installed Proxy Picker operator."
    )
    bl_options = {'UNDO'}

    action: EnumProperty(
        items=(
            ("AUTO_PROXY", "Assign Proxy", "Call Proxy Picker Auto Proxy"),
            ("BUTTON", "Add Script Button", "Call Proxy Picker Add Button"),
            ("DELETE", "Delete Role", "Call Proxy Picker Delete Proxy"),
        ),
        default="AUTO_PROXY",
    )

    def execute(self, context):
        operator_id = {"AUTO_PROXY": "pp.auto_proxy", "BUTTON": "pp.add_button", "DELETE": "pp.delete_proxy"}[self.action]
        if not operator_exists(operator_id):
            _ascii_report(self, {"WARNING"}, "Proxy Picker is not enabled.")
            return {"CANCELLED"}
        armature, error = prepare_armature_mode("POSE", context)
        if armature is None or error or context.active_pose_bone is None:
            _ascii_report(self, {"WARNING"}, error or "Select an active pose bone.")
            return {"CANCELLED"}
        if self.action == "AUTO_PROXY" and len(context.selected_pose_bones or ()) < 2:
            _ascii_report(self, {"WARNING"}, "Select the proxy bone and at least one target bone.")
            return {"CANCELLED"}
        kwargs = {"mode": "button"} if self.action == "BUTTON" else {}
        result, op_error = call_operator(operator_id, execution="EXEC_DEFAULT", kwargs=kwargs)
        return _external_result(self, result, op_error, "External Proxy Picker action completed.")


class SRS_OT_proxy_set_collection_button(bpy.types.Operator):
    bl_idname = "srs.proxy_set_collection_button"
    bl_label = "Set Bone Collection Button"
    bl_description = (
        "Extend Proxy Picker for Blender 5.1 by assigning the active pose bone to toggle a named Bone Collection. "
        "The external Proxy Picker handler performs the toggle."
    )
    bl_options = {'UNDO'}

    collection_name: StringProperty(name="Bone Collection", description="Bone Collection name toggled by this button")

    def invoke(self, context, event):
        armature = likely_armature(context)
        if armature is not None:
            try:
                visible = [collection.name for collection in armature.data.collections_all]
                if visible and not self.collection_name:
                    self.collection_name = visible[0]
            except Exception:
                pass
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        if not operator_exists("pp.auto_proxy"):
            _ascii_report(self, {"WARNING"}, "Proxy Picker is not enabled.")
            return {"CANCELLED"}
        armature, error = prepare_armature_mode("POSE", context)
        pose_bone = context.active_pose_bone
        if armature is None or pose_bone is None:
            _ascii_report(self, {"WARNING"}, error or "Select an active pose bone.")
            return {"CANCELLED"}
        try:
            collections = {collection.name for collection in armature.data.collections_all}
        except Exception:
            collections = {collection.name for collection in armature.data.collections}
        if self.collection_name not in collections:
            _ascii_report(self, {"WARNING"}, "The named Bone Collection does not exist.")
            return {"CANCELLED"}
        for key in ("proxy", "proxy_list", "button", "layer"):
            if key in pose_bone.keys():
                del pose_bone[key]
        pose_bone["collec"] = self.collection_name
        _ascii_report(self, {"INFO"}, "Bone Collection button assigned.")
        return {"FINISHED"}


class SRS_OT_proxy_batch_pair(bpy.types.Operator):
    bl_idname = "srs.proxy_batch_pair"
    bl_label = "Batch Pair by Name"
    bl_description = (
        "Find proxy and target bones from the configured prefixes and call Proxy Picker's own assignment operator "
        "for every valid pair. Existing external behavior is reused rather than reimplemented."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        if not operator_exists("pp.auto_proxy"):
            _ascii_report(self, {"WARNING"}, "Proxy Picker is not enabled.")
            return {"CANCELLED"}
        armature, error = prepare_armature_mode("POSE", context)
        if armature is None or armature.pose is None:
            _ascii_report(self, {"WARNING"}, error or "No armature found.")
            return {"CANCELLED"}
        preferences = _prefs(context)
        proxy_prefix = str(getattr(preferences, "proxy_prefix", "proxy_") if preferences else "proxy_")
        target_prefix = str(getattr(preferences, "target_prefix", "c_") if preferences else "c_")
        pose_bones = armature.pose.bones
        pairs = []
        for proxy in pose_bones:
            if not proxy.name.startswith(proxy_prefix):
                continue
            target_name = target_prefix + proxy.name[len(proxy_prefix) :]
            target = pose_bones.get(target_name)
            if target is not None and target != proxy:
                pairs.append((proxy, target))
        if not pairs:
            _ascii_report(self, {"WARNING"}, "No matching proxy/target bone pairs were found.")
            return {"CANCELLED"}
        selected_names = [bone.name for bone in pose_bones if _pose_selected(bone)]
        active_name = armature.data.bones.active.name if armature.data.bones.active else ""
        completed = 0
        try:
            for proxy, target in pairs:
                for bone in pose_bones:
                    _set_pose_selected(bone, False)
                _set_pose_selected(proxy, True)
                _set_pose_selected(target, True)
                armature.data.bones.active = armature.data.bones.get(proxy.name)
                result, _ = call_operator("pp.auto_proxy", execution="EXEC_DEFAULT")
                if "FINISHED" in result:
                    completed += 1
        finally:
            for bone in pose_bones:
                _set_pose_selected(bone, bone.name in selected_names)
            armature.data.bones.active = armature.data.bones.get(active_name) if active_name else None
        _ascii_report(self, {"INFO"}, f"Assigned {completed} proxy pair(s) through Proxy Picker.")
        return {"FINISHED"}


class SRS_OT_proxy_audit(bpy.types.Operator):
    bl_idname = "srs.proxy_audit"
    bl_label = "Proxy Mapping Audit"
    bl_description = (
        "Inspect Proxy Picker custom properties for missing target bones, missing text blocks, missing bone "
        "collections, malformed lists, and conflicting roles."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        preferences = _prefs(context)
        name = str(getattr(preferences, "report_text_name", "Smart Rig Suite Report") if preferences else "Smart Rig Suite Report")
        report = audit.proxy_mapping_audit()
        text_block_write(name, json.dumps(report, ensure_ascii=False, indent=2))
        _settings(context).last_report_text = name
        _ascii_report(self, {"INFO"}, f"Proxy audit completed with {report['issue_count']} issue(s).")
        return {"FINISHED"}


class SRS_OT_proxy_repair(bpy.types.Operator):
    bl_idname = "srs.proxy_repair"
    bl_label = "Repair Stale Proxy Mappings"
    bl_description = (
        "Remove only broken Proxy Picker references and prune missing names from proxy lists. Valid external mappings are preserved."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        armature = likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No armature found.")
            return {"CANCELLED"}
        result = audit.repair_stale_proxy_mappings(armature)
        _ascii_report(self, {"INFO"}, f"Removed {result['removed']} role(s), pruned {result['pruned']} target(s).")
        return {"FINISHED"}


class SRS_OT_proxy_export(bpy.types.Operator):
    bl_idname = "srs.proxy_export"
    bl_label = "Export Proxy Map"
    bl_description = (
        "Write the active armature's Proxy Picker mapping to a JSON Text datablock for backup, review, or transfer."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        armature = likely_armature(context)
        if armature is None or armature.pose is None:
            _ascii_report(self, {"WARNING"}, "No armature found.")
            return {"CANCELLED"}
        roles = ("proxy", "proxy_list", "button", "collec", "layer", "normal_shape", "select_shape")
        payload: dict[str, Any] = {"format": 1, "armature": armature.name, "bones": {}}
        for pose_bone in armature.pose.bones:
            data = {key: pose_bone.get(key) for key in roles if key in pose_bone.keys()}
            if data:
                payload["bones"][pose_bone.name] = data
        name = _settings(context).proxy_text_name or "Smart Rig Proxy Map"
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        _ascii_report(self, {"INFO"}, f"Exported {len(payload['bones'])} proxy mapping(s).")
        return {"FINISHED"}


class SRS_OT_proxy_import(bpy.types.Operator):
    bl_idname = "srs.proxy_import"
    bl_label = "Import Proxy Map"
    bl_description = (
        "Apply a previously exported JSON mapping to matching pose bones. Missing bones are reported and existing "
        "unrelated custom properties are not changed."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        if not operator_exists("pp.auto_proxy"):
            _ascii_report(self, {"WARNING"}, "Proxy Picker is not enabled.")
            return {"CANCELLED"}
        armature = likely_armature(context)
        if armature is None or armature.pose is None:
            _ascii_report(self, {"WARNING"}, "No armature found.")
            return {"CANCELLED"}
        name = _settings(context).proxy_text_name or "Smart Rig Proxy Map"
        text = bpy.data.texts.get(name)
        if text is None:
            _ascii_report(self, {"WARNING"}, f"Text datablock not found: {name}")
            return {"CANCELLED"}
        try:
            payload = json.loads(text.as_string())
            bones = payload.get("bones", {})
        except Exception:
            _ascii_report(self, {"WARNING"}, "Invalid proxy-map JSON. Check its format.")
            return {"CANCELLED"}
        applied = 0
        missing = 0
        allowed = {"proxy", "proxy_list", "button", "collec", "layer", "normal_shape", "select_shape"}
        for bone_name, values in bones.items():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                missing += 1
                continue
            for key, value in values.items():
                if key in allowed:
                    pose_bone[key] = value
            applied += 1
        _ascii_report(self, {"INFO"}, f"Imported {applied} mapping(s); {missing} bone(s) missing.")
        return {"FINISHED"}


class SRS_OT_weight_quality_audit(bpy.types.Operator):
    bl_idname = "srs.weight_quality_audit"
    bl_label = "Weight Quality Audit"
    bl_description = (
        "Scan selected meshes for unweighted vertices, non-normalized totals, excessive influences, very small "
        "weights, and vertex groups that do not match rig bones."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        preferences = _prefs(context)
        report = audit.weight_quality_audit(
            selected_meshes(context),
            tolerance=float(getattr(preferences, "weight_sum_tolerance", 0.001) if preferences else 0.001),
            maximum_influences=int(getattr(preferences, "maximum_influences", 4) if preferences else 4),
            tiny_threshold=float(getattr(preferences, "tiny_weight_threshold", 0.0001) if preferences else 0.0001),
        )
        name = str(getattr(preferences, "report_text_name", "Smart Rig Suite Report") if preferences else "Smart Rig Suite Report")
        text_block_write(name, json.dumps(report, ensure_ascii=False, indent=2))
        _settings(context).last_report_text = name
        summary = report["summary"]
        _ascii_report(
            self,
            {"INFO"},
            f"Weight audit: {summary['unweighted_vertices']} unweighted, "
            f"{summary['non_normalized_vertices']} non-normalized.",
        )
        return {"FINISHED"}


class SRS_OT_full_audit(bpy.types.Operator):
    bl_idname = "srs.full_audit"
    bl_label = "Full Rig Workflow Audit"
    bl_description = (
        "Generate a detailed Text report covering external tool status, AI runtime, markers, armatures, invalid "
        "drivers, broken constraints, Proxy Picker mappings, and mesh weights."
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        report = audit.build_full_report(_configured_ai_path(context))
        preferences = _prefs(context)
        name = str(getattr(preferences, "report_text_name", "Smart Rig Suite Report") if preferences else "Smart Rig Suite Report")
        text_block_write(name, json.dumps(report, ensure_ascii=False, indent=2))
        _settings(context).last_report_text = name
        _ascii_report(self, {"INFO"}, f"Full audit written to Text datablock: {name}")
        return {"FINISHED"}


class SRS_OT_clean_legacy_scene_data(bpy.types.Operator):
    bl_idname = "srs.clean_legacy_scene_data"
    bl_label = "Clean Legacy Embedded Data"
    bl_description = (
        "Remove only Smart Rig Suite 1.x helper objects and obsolete scene properties that belonged to the former "
        "embedded-tool architecture. External add-on data is not deleted."
    )
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        candidates = legacy_scene_candidates()
        count = len(candidates["objects"]) + len(candidates["scene_properties"])
        if not count:
            _ascii_report(self, {"INFO"}, "No legacy embedded Smart Rig Suite data was found.")
            return {"CANCELLED"}
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        result = clean_legacy_scene_data()
        _ascii_report(
            self,
            {"INFO"},
            f"Removed {result['objects']} legacy object(s) and {result['scene_properties']} scene property value(s).",
        )
        return {"FINISHED"}


class SRS_OT_export_integration_report(bpy.types.Operator):
    bl_idname = "srs.export_integration_report"
    bl_label = "Export Integration Report"
    bl_description = (
        "Write the current external-tool status, versions, paths, and scene audit summary to a UTF-8 JSON file."
    )

    def execute(self, context):
        report = audit.build_full_report(_configured_ai_path(context))
        path = _settings(context).export_report_path
        ok, detail = dump_json(path, report)
        if not ok:
            _ascii_report(self, {"WARNING"}, detail)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, f"Integration report written: {detail}")
        return {"FINISHED"}


class SRS_OT_eye_snap_references(bpy.types.Operator):
    bl_idname = "srs.eye_snap_references"
    bl_label = "Snap Eye References"
    bl_description = (
        "Place the external rig's eye reference bones from the chosen eyeball objects, so the pivot lands on "
        "the eyeball and the gaze points out of the face. Run the external match-to-rig afterwards"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        eye_l, eye_r, error = eye_setup.resolve_eye_objects(context, settings)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        prepared, mode_error = prepare_armature_mode("EDIT", context)
        if prepared is None or mode_error:
            _ascii_report(self, {"WARNING"}, mode_error or "Could not enter armature Edit Mode.")
            return {"CANCELLED"}
        armature = prepared
        applied, error = eye_setup.snap_eye_references(
            armature,
            eye_l,
            eye_r,
            pivot_source=settings.eye_pivot_source,
            spec_distance_factor=settings.eye_spec_distance,
        )
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            f"Eye references placed: {len(applied)}. Run the external match-to-rig to apply.",
        )
        return {"FINISHED"}


def _knee_sides(settings):
    return knee_split.SIDES


class SRS_OT_mocap_load(bpy.types.Operator):
    bl_idname = "srs.mocap_load"
    bl_label = "Load Motion Capture"
    bl_description = (
        "Import a .bvh or .fbx motion clip and bake it onto this rig's controllers in one step, using a written-out "
        "bone map instead of a guessed one"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        path = bpy.path.abspath(str(settings.mocap_file or "").strip())
        if not path:
            _ascii_report(self, {"WARNING"}, "Choose a motion file first.")
            return {"CANCELLED"}
        report, error = mocap.load(
            path, armature,
            preset=str(settings.mocap_preset),
            frame_end=int(settings.mocap_frame_end),
            fingers=bool(settings.mocap_fingers),
        )
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            f"{report['file']}: {report['mapped']} bones mapped, baked frames "
            f"{report['frames'][0]}-{report['frames'][1]}.",
        )
        if report.get("reference_frame_skipped"):
            _ascii_report(
                self,
                {"INFO"},
                tr_format(
                    "The clip opens on a reference pose: the scene now starts at frame %(start)d "
                    "(the body jumps %(jump)d mm into frame %(start)d, then %(next)d mm). The key is kept.",
                    start=int(report["frames"][0]),
                    jump=int(round(report["start_jump_mm"][0])),
                    next=int(round(report["start_jump_mm"][1])),
                ),
            )
        return {"FINISHED"}


class SRS_OT_mocap_check(bpy.types.Operator):
    bl_idname = "srs.mocap_check"
    bl_label = "Check Motion"
    bl_description = (
        "Measure every bound mesh against its rest shape across the baked motion and name the vertex groups whose "
        "edges collapse or stretch, which is where the rig is actually wrong"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        report, error = mocap.check(armature, step=int(settings.mocap_check_step))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        broken = [name for name, row in report["per_mesh"].items()
                  if row["samples"]]
        if not broken:
            _ascii_report(self, {"INFO"},
                          "No mesh leaves the half-to-double band (rest taken "
                          "from the %s)."
                          % report["rest"])
            return {"FINISHED"}
        worst = report["worst_pairs"][0]
        _ascii_report(
            self,
            {"WARNING"},
            f"{len(broken)} of {report['meshes']} meshes break; worst "
            f"{worst['mesh']} on {worst['bone_a']} (ratio {worst['min']}).",
        )
        return {"FINISHED"}


class SRS_OT_rigidify_material(bpy.types.Operator):
    bl_idname = "srs.rigidify_material"
    bl_label = "Rigid by Material"
    bl_description = (
        "Put every island of the chosen material on one weight vector so it travels with what it is attached to and "
        "cannot bend. A stud sinks into the skin because the skin moves and it does not, never because it is too stiff"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        if armature is None or mesh is None or mesh.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the part, with a rig set.")
            return {"CANCELLED"}
        report, error = costume_bind.rigidify_by_material(
            mesh, armature, donor=settings.rigid_donor,
            match=str(settings.rigid_material or "metal"),
        )
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            f"{report['made_rigid']} of {report['islands']} islands made rigid "
            f"({report['by_donor']} from the donor).",
        )
        return {"FINISHED"}


class SRS_OT_drop_families(bpy.types.Operator):
    bl_idname = "srs.drop_families"
    bl_label = "Drop Bone Families"
    bl_description = (
        "Take a family of bones off the selected part and hand the weight up the chain, so a sleeve stops spinning "
        "with the wrist and a coat stops hanging off a finger"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" \
            and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        if armature is None or mesh is None or mesh.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the part, with a rig set.")
            return {"CANCELLED"}
        patterns = [p.strip() for p in str(settings.drop_families).split(",")
                    if p.strip()]
        if not patterns:
            _ascii_report(self, {"WARNING"}, "Name at least one fragment.")
            return {"CANCELLED"}
        report, error = costume_bind.drop_bone_families(mesh, armature, patterns)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        rig_hygiene.normalise_deform(mesh, armature)
        _ascii_report(
            self,
            {"INFO"},
            f"{len(report['dropped'])} groups dropped from {report['vertices']} "
            f"vertices.",
        )
        return {"FINISHED"}


class SRS_OT_follow_only(bpy.types.Operator):
    bl_idname = "srs.follow_only"
    bl_label = "Stop Following Joint"
    bl_description = (
        "Take a whole family of bones off the selected part at once and give the weight to one bone per side, so a "
        "sleeve keeps the bend of the arm without the spin of the wrist. Dropping only part of a family is worse "
        "than dropping none: the twist bones are the blend between forearm and hand, and without them the cuff "
        "becomes a hard seam"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" \
            and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        if armature is None or mesh is None or mesh.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the part, with a rig set.")
            return {"CANCELLED"}
        if settings.follow_only_joint == 'WRIST':
            family = costume_bind.HAND_FAMILY
            heir = "forearm_stretch.{side}"
        else:
            family = tuple(p.strip() for p in
                           str(settings.follow_only_family).split(",")
                           if p.strip())
            heir = str(settings.follow_only_heir).strip()
            if not family:
                _ascii_report(self, {"WARNING"}, "Name at least one fragment.")
                return {"CANCELLED"}
        report, error = costume_bind.follow_only(mesh, armature, heir, drop=family)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if not report["dropped"] or not report["vertices"]:
            _ascii_report(self, {"INFO"},
                          "Nothing of that family carries weight on this part."
                          if report["dropped"] else
                          "Nothing of that family is on this part.")
            return {"FINISHED"}
        if report.get("no_side"):
            _ascii_report(self, {"WARNING"},
                          "Left alone, having no side in the name: %s."
                          % ", ".join(report["no_side"][:6]))
        _ascii_report(
            self,
            {"INFO"},
            f"{len(report['dropped'])} groups moved to "
            f"{', '.join(report['handed_to'])} on {report['vertices']} vertices.",
        )
        return {"FINISHED"}


class SRS_OT_bind_over(bpy.types.Operator):
    bl_idname = "srs.bind_over"
    bl_label = "Bind Over Layer"
    bl_description = (
        "Read the weights of the garment underneath instead of the skin, keeping this part's own chains. A belt "
        "wrapped round a sleeve is otherwise bound from the body, so the two solve the elbow differently and slide "
        "through one another"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" \
            and context.mode == "OBJECT"

    def execute(self, context):
        _lift_rig = shoe_lift.arp_rig(_settings(context).target_armature) or shoe_lift.arp_rig(likely_armature(context))
        if shoe_lift.guard_message(_lift_rig):
            _ascii_report(self, {"WARNING"}, shoe_lift.guard_message(_lift_rig))
            return {"CANCELLED"}
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        part = context.active_object
        donor = settings.under_part
        if armature is None or part is None or part.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the part, with a rig set.")
            return {"CANCELLED"}
        if donor is None:
            _ascii_report(self, {"WARNING"}, "Set the garment underneath.")
            return {"CANCELLED"}
        chosen = [v.index for v in part.data.vertices if v.select]
        report, error = costume_bind.bind_over(part, donor, armature, indices=chosen or None)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        rig_hygiene.normalise_deform(part, armature)
        _ascii_report(
            self,
            {"INFO"},
            f"Bound to {report['donor']}; {len(report['chains'])} chains kept "
            f"on {report['chain_vertices']} vertices.",
        )
        return {"FINISHED"}


class SRS_OT_penetration_check(bpy.types.Operator):
    bl_idname = "srs.penetration_check"
    bl_label = "Check Penetration"
    bl_description = (
        "How far the selected part sinks into the layer underneath while the animation runs, measured against its "
        "own rest offset. The stretch check cannot see this: two meshes pass through one another with every edge "
        "keeping its length"
    )
    bl_options = set()

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" \
            and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        outer = context.active_object
        inner = settings.under_part
        if outer is None or outer.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the outer part.")
            return {"CANCELLED"}
        if inner is None:
            _ascii_report(self, {"WARNING"}, "Set the garment underneath.")
            return {"CANCELLED"}
        report, error = costume_bind.penetration(
            outer, inner, armature,
            frame_start=context.scene.frame_start,
            frame_end=int(settings.mocap_frame_end) or context.scene.frame_end,
            step=int(settings.mocap_check_step))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if report["clean"]:
            _ascii_report(self, {"INFO"},
                          f"{outer.name} stays outside {inner.name}.")
            return {"FINISHED"}
        worst = report["by_bone"][0] if report["by_bone"] else None
        where = f" worst at {worst['bone']}" if worst else ""
        _ascii_report(
            self,
            {"WARNING"},
            f"{report['crossed']} of {report['vertices']} vertices sink in at "
            f"frame {report['crossed_frame']}, up to "
            f"{report['worst_sink_mm']}mm.{where}",
        )
        return {"FINISHED"}


class SRS_OT_knee_profile_install(bpy.types.Operator):
    bl_idname = "srs.knee_profile_install"
    bl_label = "Install Knee Profile"
    bl_description = (
        "Drive the external rig's knee fan bulges from a piecewise curve of flexion angle against millimetres, so "
        "the knee cap and the popliteal hollow can be dialled separately at each angle instead of sharing one "
        "straight line"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        report, error = knee_profile.install(
            armature,
            front_curve=str(settings.knee_profile_front).strip(),
            back_curve=str(settings.knee_profile_back).strip(),
        )
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            f"Knee profile installed on {len(report['bones'])} fan bones.",
        )
        return {"FINISHED"}


class SRS_OT_knee_profile_remove(bpy.types.Operator):
    bl_idname = "srs.knee_profile_remove"
    bl_label = "Remove Knee Profile"
    bl_description = "Remove the knee profile drivers and leave the fan bulges as plain linear constraints"
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        n = knee_profile.remove(armature)
        _ascii_report(self, {"INFO"}, f"Knee profile removed: {n} drivers.")
        return {"FINISHED"}


class SRS_OT_knee_profile_audit(bpy.types.Operator):
    bl_idname = "srs.knee_profile_audit"
    bl_label = "Audit Knee Profile"
    bl_description = "Report which knee fans are driven, and read both curves back at a set of flexion angles"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        payload = knee_profile.audit(armature)
        payload["armature"] = armature.name
        payload["curves"] = knee_profile.sample(
            front_curve=str(settings.knee_profile_front).strip(),
            back_curve=str(settings.knee_profile_back).strip(),
        )
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        _ascii_report(
            self,
            {"INFO"},
            f"Knee profile: {payload['driven_count']} of {payload['total']} fans driven.",
        )
        return {"FINISHED"}


class SRS_OT_knee_split_install(bpy.types.Operator):
    bl_idname = "srs.knee_split_install"
    bl_label = "Install Knee Split"
    bl_description = (
        "Drive the external rig's secondary knee controllers so the thigh and calf sides slide apart past "
        "the onset angle, instead of folding as one hinge. Poses below the onset angle are untouched"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        report, error = knee_split.install(
            armature,
            sides=_knee_sides(settings),
            onset_deg=float(settings.knee_split_onset_deg),
            end_deg=float(settings.knee_split_end_deg),
            thigh_slide_mm=float(settings.knee_split_thigh_slide_mm),
            thigh_apart_mm=float(settings.knee_split_thigh_apart_mm),
            calf_slide_mm=float(settings.knee_split_calf_slide_mm),
            calf_apart_mm=float(settings.knee_split_calf_apart_mm),
            ramp_curve=str(settings.knee_split_ramp_curve).strip(),
        )
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            f"Knee split installed on {len(report['bones'])} controllers.",
        )
        return {"FINISHED"}


class SRS_OT_knee_split_remove(bpy.types.Operator):
    bl_idname = "srs.knee_split_remove"
    bl_label = "Remove Knee Split"
    bl_description = "Remove the knee split drivers and return the secondary controllers to zero"
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        n = knee_split.remove(armature, sides=_knee_sides(settings))
        _ascii_report(self, {"INFO"}, f"Knee split removed: {n} drivers.")
        return {"FINISHED"}


def _joint_keys(settings):
    keys = []
    if getattr(settings, "joint_setup_knees", True):
        keys.append("knee")
    if getattr(settings, "joint_setup_elbows", True):
        keys.append("elbow")
    return keys


def _joint_mesh(context, settings):
    mesh = settings.target_body_mesh
    if mesh is not None:
        return mesh
    active = context.active_object
    if active is not None and active.type == "MESH":
        return active
    meshes = selected_meshes(context)
    return meshes[0] if meshes else None


def _hair_meshes(context, settings):
    """The meshes a hair pass should look at, or None if the pattern is broken.

    Grouping by collection changes what the pattern is matched against: the
    collection's name, not the mesh's. That is the point of the collection route
    -- one strand's meshes are named a dozen different ways, while the collection
    holding them is named once and named well.
    """
    import re as _re
    try:
        rx = _re.compile(str(settings.hair_name_pattern))
    except _re.error:
        return None
    sel = [o for o in context.selected_objects if o.type == "MESH"]
    pool = [o for o in (sel if sel else bpy.data.objects) if o.type == "MESH"]
    if not settings.hair_group_by_collection:
        return [o for o in pool if rx.search(o.name)]
    marker = str(settings.part_marker)
    out = []
    for obj in pool:
        for c in obj.users_collection:
            if marker and marker not in c.name:
                continue
            if rx.search(c.name):
                out.append(obj)
                break
    return out


class SRS_OT_hair_build(bpy.types.Operator):
    bl_idname = "srs.hair_build"
    bl_label = "Build Hair Chains"
    bl_description = (
        "Find each strand from the geometry, give every strand the same number of bones spaced "
        "along its own centreline, drive them all from one master, and bind rigid materials whole "
        "while the rest bends"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        _lift_rig = shoe_lift.arp_rig(_settings(context).target_armature) or shoe_lift.arp_rig(likely_armature(context))
        if shoe_lift.guard_message(_lift_rig):
            _ascii_report(self, {"WARNING"}, shoe_lift.guard_message(_lift_rig))
            return {"CANCELLED"}
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        meshes = _hair_meshes(context, settings)
        if meshes is None:
            _ascii_report(self, {"WARNING"}, "The hair pattern is not a valid expression.")
            return {"CANCELLED"}
        if not meshes:
            _ascii_report(self, {"WARNING"}, "No meshes matched the hair pattern.")
            return {"CANCELLED"}
        rigid = tuple(m.strip() for m in
                      str(settings.hair_rigid_materials).split(",") if m.strip())
        pattern = str(settings.hair_name_pattern)
        prefix = str(settings.hair_prefix)
        by_collection = bool(settings.hair_group_by_collection)
        marker = str(settings.part_marker) if by_collection else ""
        limit = max(0.0, float(settings.hair_min_span_mm)) * 0.001
        parent = str(settings.hair_parent_bone).strip()
        if parent and parent not in armature.pose.bones:
            parent = ""

        def pass_over(min_span, max_span, count, master, tier):
            """One tier of strands: discover, lay bones, bind. Returns a summary."""
            found, err = hair_chain.discover_braids(
                meshes, pattern=pattern, rigid_materials=rigid,
                group_by_collection=by_collection, marker=marker,
                min_span=min_span, max_span=max_span)
            if found is None:
                return {"strands": 0, "bones": 0, "why": err}, found
            plan = hair_chain.plan_chains(found, count)
            err = hair_chain.binding_conflict(armature, found, plan, prefix + tier)
            if err:
                return {"strands": 0, "bones": 0, "why": err}, found
            rep, err = hair_chain.build(
                armature, plan, parent_bone=parent, prefix=prefix + tier,
                master=master)
            if err:
                return {"strands": 0, "bones": 0, "why": err}, found
            _, err = hair_chain.bind(meshes, armature, found, plan, prefix=prefix + tier)
            if err:
                return {"strands": 0, "bones": 0, "why": err}, found
            # A chain without stored settings is baked with the operator's fallback numbers,
            # not the ones the preset was measured with -- store them now.
            feel = jiggle.FEEL["SHORT" if tier else "LONG"]
            for key in jiggle.chains_named(armature, prefix=prefix + tier):
                if not jiggle.settings_for(armature, key, prefix=prefix + tier):
                    jiggle.store_settings(armature, key, prefix=prefix + tier, **feel)
            return {"strands": len(found), "bones": rep["bones_per_chain"],
                    "filed": rep.get("filed_bones", 0), "why": ""}, found

        # The long strands are one interchangeable set: same bone count, driven by
        # one master, so they pose together. Short pieces are a separate tier,
        # because the ten bones that suit a 1.2m braid would fold a fringe.
        long_sum, long_found = pass_over(
            limit, 0.0, int(settings.hair_bones_per_chain),
            bool(settings.hair_use_master), "")
        short_sum = {"strands": 0, "bones": 0, "why": "skipped"}
        short_found = None
        short_n = int(settings.hair_short_bones)
        if limit > 0.0 and short_n > 0:
            short_sum, short_found = pass_over(0.0, limit, short_n, False, "_tip")
        if not long_sum["strands"] and not short_sum["strands"]:
            _ascii_report(self, {"WARNING"},
                          long_sum["why"] or "No strand was found.")
            return {"CANCELLED"}

        covered = list(long_found or []) + list(short_found or [])
        pinned = 0
        if settings.hair_pin_loose and parent:
            loose = hair_chain.unchained(meshes, covered)
            if loose:
                rep, err = hair_chain.bind_rigid(loose, armature, parent,
                                                 group_prefix=prefix)
                if not err:
                    pinned = len((rep or {}).get("objects", []))
        _ascii_report(
            self,
            {"INFO"},
            "%d long strands at %d bones, %d short at %d; %d pinned." % (
                long_sum["strands"], long_sum["bones"],
                short_sum["strands"], short_sum["bones"], pinned),
        )
        return {"FINISHED"}


class SRS_OT_hair_remove(bpy.types.Operator):
    bl_idname = "srs.hair_remove"
    bl_label = "Remove Hair Chains"
    bl_description = "Delete the generated hair bones and the vertex groups they bound"
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        meshes = _hair_meshes(context, settings) or []
        n = hair_chain.remove(armature, meshes, prefix=str(settings.hair_prefix))
        n += hair_chain.remove(armature, meshes, prefix=str(settings.hair_prefix) + "_tip")
        _ascii_report(self, {"INFO"}, f"Removed {n} hair bones.")
        return {"FINISHED"}


class SRS_OT_hair_audit(bpy.types.Operator):
    bl_idname = "srs.hair_audit"
    bl_label = "Audit Hair Chains"
    bl_description = "Report each strand's bone count, mean bone length and whether the master drives it"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        payload = hair_chain.audit(armature, prefix=str(settings.hair_prefix))
        payload["armature"] = armature.name
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        bad = len(payload.get("issues", []))
        _ascii_report(
            self,
            {"WARNING"} if bad else {"INFO"},
            f"{len(payload.get('chains', {}))} chains; {bad} issues.",
        )
        return {"FINISHED"}


class SRS_OT_part_audit(bpy.types.Operator):
    bl_idname = "srs.part_audit"
    bl_label = "Audit Parts"
    bl_description = (
        "List the character's collections, say which ones were left out of the rig and why, and "
        "report any bone that belongs to no part and so cannot be hidden or removed with one"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        payload = part_rig.audit(armature, marker=str(settings.part_marker))
        payload["armature"] = armature.name if armature else ""
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        bad = len(payload.get("issues", []))
        _ascii_report(
            self,
            {"WARNING"} if bad else {"INFO"},
            "%d parts, %d skipped, %d loose bones." % (
                len(payload.get("parts", [])), len(payload.get("skipped", [])),
                payload.get("loose_bones", 0)),
        )
        return {"FINISHED"}


class SRS_OT_part_visibility(bpy.types.Operator):
    bl_idname = "srs.part_visibility"
    bl_label = "Show or Hide Part"
    bl_description = (
        "Show or hide a part's meshes and its bones together. Hiding only the meshes would leave "
        "the part's controls floating in the viewport"
    )
    bl_options = {'UNDO'}

    visible: bpy.props.BoolProperty(
        name="Visible",
        description="Show the part when on, hide it when off",
        default=True,
    )

    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    part: bpy.props.StringProperty(
        name="Part", default="",
        description="The part by name. Empty uses the panel's part",
    )
    mode: bpy.props.EnumProperty(
        name="Mode", default='VISIBLE',
        items=[('VISIBLE', "By Visible", "Follow the Visible switch"), ('SHOW', "Show", "Show the part"),
               ('HIDE', "Hide", "Hide the part")],
    )

    def execute(self, context):
        settings = _settings(context)
        part = str(self.part).strip() or str(settings.part_name).strip()
        if not part:
            _ascii_report(self, {"WARNING"}, "Choose a part first.")
            return {"CANCELLED"}
        armature = _rig(self, context, settings)
        if str(self.armature).strip() and armature is None:
            _ascii_report(self, {"WARNING"}, "No armature called %s." % self.armature)
            return {"CANCELLED"}
        visible = bool(self.visible) if self.mode == 'VISIBLE' else self.mode == 'SHOW'
        touched = part_rig.set_part_visible(part, armature=armature,
                                           visible=visible)
        if not touched["collection"] and not touched["bones"]:
            _ascii_report(self, {"WARNING"},
                          "Nothing called %s was found." % part)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            "%s %s%s." % (part, "shown" if visible else "hidden",
                          " with its bones" if touched["bones"] else ""),
        )
        return {"FINISHED"}


class SRS_OT_part_delete(bpy.types.Operator):
    bl_idname = "srs.part_delete"
    bl_label = "Remove Part"
    bl_description = (
        "Remove a part completely: its meshes, the bones generated for it, and the vertex groups "
        "those bones left behind on the meshes that stay"
    )
    bl_options = {'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        settings = _settings(context)
        part = str(settings.part_name).strip()
        if not part:
            _ascii_report(self, {"WARNING"}, "Choose a part first.")
            return {"CANCELLED"}
        armature = settings.target_armature or likely_armature(context)
        report, error = part_rig.delete_part(
            part, armature=armature,
            delete_meshes=bool(settings.part_delete_meshes))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            "%s removed: %d meshes, %d bones, %d stale groups." % (
                part, report["objects"], report["bones"],
                report["vertex_groups"]),
        )
        return {"FINISHED"}


class SRS_OT_joint_setup_all(bpy.types.Operator):
    bl_idname = "srs.joint_setup_all"
    bl_label = "Set Up Auxiliary Bones"
    bl_description = (
        "Find every auxiliary bone the external rig added past its defaults, group them by the joint "
        "they serve, and apply the fan profile, the split and the weight smoothing to each in one pass"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        keys = _joint_keys(settings)
        if not keys:
            _ascii_report(self, {"WARNING"}, "Select at least one joint family.")
            return {"CANCELLED"}
        mesh = _joint_mesh(context, settings) if settings.joint_setup_smooth else None
        overrides = None
        if not settings.joint_setup_scale_preset:
            overrides = {k: dict(joint_setup.PRESET) for k in keys}
        report, error = joint_setup.apply_all(
            armature, keys=keys, mesh=mesh, overrides=overrides)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        joints = report.get("joints", [])
        done = sum(1 for joint in joints
                   if any(step.get("bones") for step in joint.get("steps", ())))
        step_errors = [step["error"] for joint in joints for step in joint.get("steps", ())
                       if step.get("error")]
        smooth = report.get("smooth", {})
        problems = [*step_errors, *smooth.get("errors", ())]
        if not done:
            # A joint without fan or bend bones is discovered but gets no step at all.
            if not problems:
                problems = [
                    f"{len(joints)} joints were found, but none has the fan or bend bones this needs. "
                    "Nothing was set up."
                ]
        else:
            _ascii_report(self, {"INFO"}, f"Auxiliary bones set up on {done} joints.")
        if problems:
            _ascii_report(self, {"WARNING"}, problems[0])
        return {"FINISHED"} if done or smooth.get("selected") else {"CANCELLED"}


class SRS_OT_joint_setup_remove(bpy.types.Operator):
    bl_idname = "srs.joint_setup_remove"
    bl_label = "Remove Auxiliary Setup"
    bl_description = (
        "Remove the drivers this add-on installed on every discovered joint and put the external "
        "rig's own Bulge values back. Weight smoothing is a mesh edit and is not undone here"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        n = joint_setup.remove_all(armature)
        _ascii_report(self, {"INFO"}, f"Removed {n} drivers.")
        return {"FINISHED"}


class SRS_OT_joint_mirror_fans(bpy.types.Operator):
    bl_idname = "srs.joint_mirror_fans"
    bl_label = "Mirror Fan Setup"
    bl_description = (
        "Make the right side's joint fans the mirror of the left's: every fan stays still with the limb "
        "straight, and the right fans copy the left's amounts and angle curves so both limbs bulge the same "
        "way. Fans whose two sides turn the opposite way round are carried across correctly"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        report, error = joint_setup.mirror_fans(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        n = len(report.get("fixed", []))
        _ascii_report(self, {"INFO"}, f"Mirrored {n} fan bones.")
        return {"FINISHED"}


class SRS_OT_joint_audit(bpy.types.Operator):
    bl_idname = "srs.joint_audit"
    bl_label = "Audit Auxiliary Bones"
    bl_description = (
        "Report every auxiliary bone by joint, whether each joint is set up, and any fan pair whose "
        "two sides are not mirror images of each other"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        payload = joint_setup.audit(armature)
        payload["armature"] = armature.name
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        bad = len(payload.get("mirror", {}).get("asymmetric", []))
        total = payload.get("auxiliary_total", 0)
        _ascii_report(
            self,
            {"WARNING"} if bad else {"INFO"},
            f"{total} auxiliary bones; {bad} fan pairs are not mirrored.",
        )
        return {"FINISHED"}


class SRS_OT_knee_smooth_weights(bpy.types.Operator):
    bl_idname = "srs.knee_smooth_weights"
    bl_label = "Smooth Knee Weights"
    bl_description = (
        "Average the deform weights in a ball around each knee. This targets the primary thigh-to-shin "
        "transition, which is what creases a moderately bent knee, and it is also what lets deep flexion "
        "separate without tearing the surface"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        mesh = settings.target_body_mesh
        if mesh is None:
            active = context.active_object
            if active is not None and active.type == "MESH":
                mesh = active
            else:
                meshes = selected_meshes(context)
                mesh = meshes[0] if meshes else None
        if mesh is None:
            _ascii_report(self, {"WARNING"}, "Select the deformed body mesh first.")
            return {"CANCELLED"}
        report, error = knee_split.smooth_knee_weights(
            armature, mesh,
            sides=_knee_sides(settings),
            radius_mm=float(settings.knee_smooth_radius_mm),
            factor=float(settings.knee_smooth_factor),
            repeat=int(settings.knee_smooth_repeat),
        )
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            f"Knee weights smoothed over {report['selected']} vertices.",
        )
        return {"FINISHED"}


class SRS_OT_knee_split_audit(bpy.types.Operator):
    bl_idname = "srs.knee_split_audit"
    bl_label = "Audit Knee Split"
    bl_description = "Report which knee controllers are driven and whether anything blocks them"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        payload = knee_split.audit(armature, sides=_knee_sides(settings))
        payload["armature"] = armature.name
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        _ascii_report(
            self,
            {"INFO"},
            f"Knee split: {payload['driven_count']} of {payload['total']} controllers driven.",
        )
        return {"FINISHED"}


def _eye_face(context, settings):
    """The face mesh to pin the eyeball rims to."""
    chosen = getattr(settings, "eye_face_object", None)
    if chosen is not None and chosen.type == "MESH":
        return chosen
    return None


def _face_family(context, settings):
    """The face and the parts a hygiene pass has to measure against it."""
    face = _eye_face(context, settings)
    if face is None:
        return None, {}
    family = {}
    for key, suffix in (("teeth_upper", "_teeth_upper"),
                        ("teeth_lower", "_teeth_lower"),
                        ("tongue", "_tongue"),
                        ("eyebrows", "_eyebrows"),
                        ("lash_upper", "_eyelashes_upper"),
                        ("lash_lower", "_eyelashes_lower")):
        family[key] = bpy.data.objects.get(face.name + suffix)
    return face, family


class SRS_OT_lid_shadow_build(bpy.types.Operator):
    bl_idname = "srs.lid_shadow_build"
    bl_label = "Make The Lid Shadow Follow The Lid"
    bl_description = (
        "Drive the eyeball's cast-shadow map from the upper eyelid. A shadow painted into the "
        "eyeball's own UVs is fixed: the eye closes and the shadow stays exactly where it was, which "
        "is the one moment it should move. A UV Project modifier generates those UVs from a projector "
        "each frame, so this builds the projector and drives its height from the lid -- by the "
        "distance the lid margin ACTUALLY travels, which is measured, not assumed, because the "
        "controller moves 8.38mm while the margin moves 10.5. The projector is bone-parented to the "
        "eye socket so the shadow follows the head; running it again keeps an existing projector's "
        "placement and lid expression and only re-parents it"
    )
    bl_options = {'UNDO'}

    follow: bpy.props.FloatProperty(
        name="Follow",
        description=(
            "How much of the lid's travel the shadow takes. One slides it exactly as far as the lid "
            "margin goes; lower holds the shadow back"
        ),
        default=1.0, min=0.0, max=2.0,
    )
    distance_mm: bpy.props.FloatProperty(
        name="Projector Distance",
        description="How far in front of the eye the projector sits. Orthographic, so this does not change the size",
        default=200.0, min=10.0, soft_max=2000.0,
    )
    pull_mm: bpy.props.FloatProperty(
        name="Closed At",
        description="How far the lid control is pulled when the travel is measured",
        default=8.38, min=0.5, soft_max=40.0,
    )
    remeasure: bpy.props.BoolProperty(
        name="Measure Again",
        description=(
            "Off: an existing projector keeps its rest placement and its lid expression and is only "
            "re-parented to the eye socket. On: place it from the eyeball's own UV layer and measure the "
            "lid again, as a first build does (Follow, Distance and Closed At only apply then)"
        ),
        default=False,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face = _eye_face(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        pairs = []
        for side, suffix in ((".l", "_L"), (".r", "_R")):
            eyeball = (getattr(settings, "eye_object_l", None) if side == ".l"
                       else getattr(settings, "eye_object_r", None))
            if eyeball is None:
                eyeball = bpy.data.objects.get(face.name.replace("faceA", "eyeA")
                                               + suffix)
            if eyeball is None:
                for obj in context.selected_objects:
                    if obj.type == "MESH" and obj.name.endswith(suffix):
                        eyeball = obj
                        break
            if eyeball is not None:
                pairs.append((side, eyeball))
        if not pairs:
            _ascii_report(self, {"WARNING"},
                          "Could not find the eyeball meshes -- set them in the "
                          "eye fields or select them.")
            return {"CANCELLED"}
        done, failed = [], []
        for side, eyeball in pairs:
            report, error = eye_shadow.build(
                eyeball, face, armature, side, pull_mm=self.pull_mm,
                distance_mm=self.distance_mm, follow=self.follow,
                collection=(eyeball.users_collection[0]
                            if eyeball.users_collection else None),
                remeasure=self.remeasure)
            if error:
                failed.append("%s (%s)" % (eyeball.name, error))
                continue
            if report["travel"] is not None:
                lid = "%.3fmm of lid travel" % report["travel"]["margin_travel_mm"]
            else:
                lid = "its existing lid expression"
            done.append("%s follows %s through %s, %s on %s (%s)"
                        % (eyeball.name, lid, report["projector"], report["mode"],
                           report["parent_bone"], report["parent"]))
        _ascii_report(self, {"INFO"} if not failed else {"WARNING"},
                      "%s.%s" % ("; ".join(done) or "nothing built",
                                 (" Refused: " + "; ".join(failed))
                                 if failed else ""))
        return {"FINISHED"}


class SRS_OT_lid_shadow_verify(bpy.types.Operator):
    bl_idname = "srs.lid_shadow_verify"
    bl_label = "Check The Lid Shadow"
    bl_description = (
        "Prove both halves actually work: that the projector moves when the lid closes, AND that the "
        "generated UVs move with it. A projector that slides while the modifier is switched off "
        "changes nothing on screen, and that is not visible from the modifier panel. Then turn the head "
        "hard with the gaze held: the UVs on the eyeball must stay as at rest, or the shadow is not "
        "following the head"
    )
    bl_options = set()

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        rows = []
        for obj in bpy.data.objects:
            if obj.type != "MESH" or not eye_shadow.read_state(obj):
                continue
            side = eye_shadow.read_state(obj).get("side", ".l")
            report, error = eye_shadow.verify(obj, armature, side)
            if error:
                rows.append("%s: %s" % (obj.name, error))
                continue
            follow = report["follow"]
            if follow["judged"]:
                head = "head move UV %.6f%s" % (follow["uv_maxdiff"],
                                                "" if report["follows_head"] else " NOT FOLLOWING")
            else:
                head = "head move not judged"
            rows.append("%s: projector %.3fmm, UVs %.5f in V, %s%s"
                        % (obj.name, report["projector_moved_mm"],
                           report["uv_v_shift"], head,
                           "" if report["ok"] else " -- NOT WORKING"))
        if not rows:
            _ascii_report(self, {"WARNING"},
                          "No eyeball on this file has a lid-shadow setup yet.")
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "; ".join(rows))
        return {"FINISHED"}


class SRS_OT_lid_shadow_remove(bpy.types.Operator):
    bl_idname = "srs.lid_shadow_remove"
    bl_label = "Remove The Lid Shadow Rig"
    bl_description = (
        "Take the projector back out and put the UV Project modifier back the way it was found. A "
        "modifier that was already on the mesh is switched off rather than deleted, because it is the "
        "artist's, not ours"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        removed = []
        for obj in bpy.data.objects:
            if obj.type != "MESH" or not eye_shadow.read_state(obj):
                continue
            report, error = eye_shadow.remove(obj)
            if not error:
                removed.append("%s (%s)" % (obj.name,
                                            ", ".join(report["removed"]) or "-"))
        _ascii_report(self, {"INFO"},
                      "Removed from %s." % ("; ".join(removed) or "nothing"))
        return {"FINISHED"}


class SRS_OT_wrist_fold_install(bpy.types.Operator):
    bl_idname = "srs.wrist_fold_install"
    bl_label = "Stop The Wrist Crushing"
    bl_description = (
        "Auto-Rig Pro gives the knee and the elbow two bend controllers and a pair of fans each, and "
        "gives the wrist one bone with nothing driving it. That holds out to about 50 degrees and then "
        "falls off a cliff -- the crease meets itself and the faces fold flat. This pushes that one "
        "bone out of the crease, by an amount that is zero until the joint is already past the angle "
        "where it still behaved, so the usable range does not change at all"
    )
    bl_options = {'UNDO'}

    onset_deg: bpy.props.FloatProperty(
        name="Starts At",
        description=(
            "Below this angle nothing happens. Leave it at the angle the wrist still deforms cleanly "
            "at, so the range people actually animate in is untouched"
        ),
        default=wrist_fold.ONSET_DEG, min=5.0, max=89.0,
    )
    full_deg: bpy.props.FloatProperty(
        name="Full By",
        description="The angle at which the correction reaches full strength",
        default=wrist_fold.FULL_DEG, min=10.0, max=120.0,
    )
    strength: bpy.props.FloatProperty(
        name="Strength",
        description="Scales the measured offset. One is what was measured on the reference character",
        default=1.0, min=0.0, max=3.0,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = wrist_fold.install(
            armature,
            flex_n_mm=wrist_fold.FLEX_N_MM * self.strength,
            flex_u_mm=wrist_fold.FLEX_U_MM * self.strength,
            ext_n_mm=wrist_fold.EXT_N_MM * self.strength,
            ext_u_mm=wrist_fold.EXT_U_MM * self.strength,
            onset_deg=self.onset_deg,
            full_deg=max(self.full_deg, self.onset_deg + 1.0),
            limit_deg=max(self.full_deg, self.onset_deg + 1.0) + 10.0)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        done = [r["bone"] for r in report["sides"] if "bone" in r]
        refused = ["%s: %s" % (r["side"], r["error"])
                   for r in report["sides"] if "error" in r]
        _ascii_report(self, {"INFO"} if done else {"WARNING"},
                      "Driven from %g degrees: %s.%s"
                      % (report["onset_deg"], ", ".join(done) or "nothing",
                         (" Refused: " + "; ".join(refused)) if refused else ""))
        return {"FINISHED"}


class SRS_OT_wrist_fold_verify(bpy.types.Operator):
    bl_idname = "srs.wrist_fold_verify"
    bl_label = "Check The Wrist"
    bl_description = (
        "Measure the skin around both wrists through flexion, extension, both deviations and twist. "
        "Deviation and twist are in there on purpose: the fix is aimed at flexion only, and a "
        "correction that quietly damaged one of the others would not show up any other way"
    )
    bl_options = set()

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = _joint_mesh(context, settings)
        if armature is None or mesh is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and select the body mesh.")
            return {"CANCELLED"}
        report, error = wrist_fold.verify(armature, mesh)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"},
                      "Worst %s edges over 70 degrees, worst angle %s. %s"
                      % (report["worst_over_70"], report["worst_max"],
                         "Treated." if report["installed"] else "Not treated."))
        return {"FINISHED"}


class SRS_OT_wrist_fold_remove(bpy.types.Operator):
    bl_idname = "srs.wrist_fold_remove"
    bl_label = "Remove The Wrist Treatment"
    bl_description = "Take the drivers off both wrists and put the bone back at zero"
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = wrist_fold.remove(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"},
                      "Cleared %s." % (", ".join(report["cleared"]) or "nothing"))
        return {"FINISHED"}


class SRS_OT_shoulder_limit_install(bpy.types.Operator):
    bl_idname = "srs.shoulder_limit_install"
    bl_label = "Limit The Shoulder Rise"
    bl_description = (
        "Keep each shoulder at or below its default pose unless the FK arm is raised above its T-pose line, "
        "and then let it rise only in proportion. One limit constraint per c_shoulder, driven by the arm, so "
        "motion capture and hand keys both obey it; forward swing and twist are left alone"
    )
    bl_options = {'UNDO'}

    armature: bpy.props.StringProperty(
        name="Armature", default="", description="The rig by its object name. Empty uses the panel's rig",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = shoulder_lift.install(
            armature, lift_per_degree=settings.shoulder_lift_per_degree, soft_deg=settings.shoulder_soft_deg)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        done = [r["bone"] for r in report["sides"] if "bone" in r]
        refused = [r["error"] for r in report["sides"] if "error" in r]
        valid = report.get("drivers_valid", True)
        message = "Shoulder rise limited on %s." % ", ".join(done)
        if refused:
            message += " Refused: %s." % ", ".join(refused)
        if not valid:
            message += " A limit driver does not evaluate. Check the arm's rotation mode."
        _ascii_report(self, {"INFO"} if valid and not refused else {"WARNING"}, message)
        return {"FINISHED"}


class SRS_OT_shoulder_limit_remove(bpy.types.Operator):
    bl_idname = "srs.shoulder_limit_remove"
    bl_label = "Remove The Shoulder Limit"
    bl_description = "Take the shoulder limit constraints and their drivers off. The shoulders' keys are untouched"
    bl_options = {'UNDO'}

    armature: bpy.props.StringProperty(
        name="Armature", default="", description="The rig by its object name. Empty uses the panel's rig",
    )

    def execute(self, context):
        armature = _rig(self, context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = shoulder_lift.remove(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Cleared %s." % (", ".join(report["cleared"]) or "nothing"))
        return {"FINISHED"}


def _compare_numbers_report(operator, result) -> None:
    numbers = compare.summary(result)
    shape = "-" if numbers["shape_mm"] is None else "%.4f" % numbers["shape_mm"]
    if numbers["changed"] or numbers["only_a"] or numbers["only_b"]:
        _ascii_report(operator, {"INFO"}, "%d IDs changed, %d only in the first, %d only in the second. Largest shape difference %s mm." % (
            numbers["changed"], numbers["only_a"], numbers["only_b"], shape))
    else:
        _ascii_report(operator, {"INFO"}, "No difference (%d IDs compared). Largest shape difference %s mm." % (numbers["ids"], shape))


class SRS_OT_compare_snapshot_take(bpy.types.Operator):
    bl_idname = "srs.compare_snapshot_take"
    bl_label = "Take A Snapshot"
    bl_description = (
        "Save a copy of this scene as it is now into the add-on's own folder, to compare against later. "
        "Your .blend is neither saved nor marked as changed; the next snapshot replaces this one"
    )
    bl_options = set()

    def execute(self, context):
        info, error = compare.take_snapshot(context)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Snapshot taken at frame %d (%s)." % (info["frame"], info["time"][11:]))
        return {"FINISHED"}


class SRS_OT_compare_with_file(bpy.types.Operator):
    bl_idname = "srs.compare_with_file"
    bl_label = "Compare"
    bl_description = (
        "Compare in a separate background Blender, property by property for every ID, and the evaluated "
        "shape of the selected meshes in millimetres. With no file chosen: the snapshot against this scene "
        "now. With a file chosen: this scene now against that file. Press again while it runs to stop it"
    )
    bl_options = set()

    def execute(self, context):
        if compare.is_running():
            compare.stop("Stopped.")
            _ascii_report(self, {"INFO"}, "Comparison stopped.")
            return {"FINISHED"}
        state, error = compare.start(context, _settings(context), wait=bool(bpy.app.background))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if state == "started":
            _ascii_report(self, {"INFO"}, "Comparing in the background. Press again to stop.")
            return {"FINISHED"}
        _compare_numbers_report(self, compare.last_result())
        return {"FINISHED"}


class SRS_OT_compare_export(bpy.types.Operator):
    bl_idname = "srs.compare_export"
    bl_label = "Write The Result"
    bl_description = (
        "Write the last comparison into the chosen folder: a JSON file with every differing row and a "
        "Markdown file to read. Nothing is written into the .blend"
    )
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return compare.last_result() is not None

    def execute(self, context):
        paths, error = compare.export(_settings(context).compare_export_dir, tr)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Written: %s" % paths[1])
        return {"FINISHED"}


class SRS_OT_face_falloff_audit(bpy.types.Operator):
    bl_idname = "srs.face_falloff_audit"
    bl_label = "Measure The Facial Weight Reach"
    bl_description = (
        "Report how far each facial bone's influence travels and how much of it has landed in a "
        "feature it does not belong to. Reach is judged against the spacing to the nearest sibling, "
        "not against the bone's own length -- every eyebrow bone on a generated rig is the same 4.9mm "
        "default, so dividing by length inflates some findings and hides others"
    )
    bl_options = set()

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face = _eye_face(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        family = _face_family(context, settings)[1]
        report, error = face_falloff.audit(
            face, armature, bpy.data.objects.get(face.name + "_eyebrows"),
            family.get("teeth_upper"), family.get("teeth_lower"))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        rows = ["%s: %s pairs, %s weight" % (r["rule"], r["vertex_bone_pairs"],
                                             r["weight_in_region"])
                for r in report["rules"] if r.get("vertex_bone_pairs")]
        worst = report["reach"][0] if report["reach"] else None
        _ascii_report(self, {"INFO"},
                      "%s. Furthest: %s"
                      % ("; ".join(rows) or "nothing out of place",
                         ("%s reaches %smm, %sx its sibling spacing"
                          % (worst[0], worst[3], worst[4])) if worst else "-"))
        return {"FINISHED"}


class SRS_OT_face_falloff_trim(bpy.types.Operator):
    bl_idname = "srs.face_falloff_trim"
    bl_label = "Keep Each Facial Bone In Its Own Feature"
    bl_description = (
        "Pull the eye and lid bones out of the brow and the lips, the brow and nose bones out of the "
        "eye, and the jaw out of the middle of the upper lip. Each region is cleared outright and the "
        "falloff happens OUTSIDE it: tapering inward instead leaves the foreign bone wherever the "
        "region is thinner than the taper, which halved the defect rather than removing it. Runs "
        "twice by default, because the first pass's normalise can inflate a weight that started under "
        "the threshold"
    )
    bl_options = {'UNDO'}

    taper_mm: bpy.props.FloatProperty(
        name="Falloff",
        description=(
            "How far outside each region the influence fades back in. Nothing inside the region "
            "keeps any of it"
        ),
        default=face_falloff.TAPER_MM, min=0.5, soft_max=30.0,
    )
    passes: bpy.props.IntProperty(
        name="Passes",
        description="Two catches what the first normalise moved",
        default=2, min=1, max=4,
    )
    dry_run: bpy.props.BoolProperty(
        name="Measure Only",
        description="Report what would change without changing it",
        default=False,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face = _eye_face(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        family = _face_family(context, settings)[1]
        brow = bpy.data.objects.get(face.name + "_eyebrows")
        report, error = face_falloff.trim(
            face, armature, brow, family.get("teeth_upper"),
            family.get("teeth_lower"), taper_mm=self.taper_mm,
            passes=self.passes, dry_run=self.dry_run)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        gained = report.get("largest_weight_gain_per_bone") or []
        _ascii_report(self, {"INFO"},
                      "%s vertices, %s handed to a named bone, %s rebalanced. "
                      "Biggest gain: %s"
                      % (report.get("vertices_touched"), report.get("donated"),
                         report.get("rebalanced_without_headroom", 0),
                         ("%s +%s" % (gained[0][0], gained[0][1]))
                         if gained else "none"))
        return {"FINISHED"}


class SRS_OT_corrective_confine(bpy.types.Operator):
    bl_idname = "srs.corrective_confine"
    bl_label = "Confine The Lid Correctives"
    bl_description = (
        "A corrective is sculpted in a viewport and a sculpt does not stop at a vertex set. On the "
        "reference character both lid-closure correctives moved 31 vertices inside the brow, so the "
        "brow shifted on every blink even though no bone moves there -- invisible to a weight audit "
        "and to a bone-motion audit, because it is neither. This fades each key back to zero outside "
        "the lid region"
    )
    bl_options = {'UNDO'}

    taper_hops: bpy.props.IntProperty(
        name="Fade Rings",
        description="How many rings of vertices the key fades out over",
        default=3, min=1, max=10,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face = _eye_face(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        keys = [b.name for b in (face.data.shape_keys.key_blocks
                                 if face.data.shape_keys else ())
                if b.name.startswith("SRS lid")]
        if not keys:
            _ascii_report(self, {"WARNING"},
                          "This face carries no lid correctives.")
            return {"CANCELLED"}
        keep = set()
        for side in (".l", ".r"):
            region, error = face_regions.lid_region(face, armature, side)
            if error or not region:
                continue
            for value in region.get("vertices") or ():
                if isinstance(value, int):
                    keep.add(value)
        brow = bpy.data.objects.get(face.name + "_eyebrows")
        if brow is not None:
            footprint, error = face_regions.brow_footprint(face, brow)
            if not error and footprint:
                keep -= set(x for x in (footprint.get("footprint_vertices") or ())
                            if isinstance(x, int))
        if not keep:
            _ascii_report(self, {"WARNING"},
                          "Could not work out the lid region to keep.")
            return {"CANCELLED"}
        report, error = corrective.confine(face, keys, keep,
                                           taper_hops=self.taper_hops)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        rows = ["%s: %s verts, %smm removed"
                % (r["key"], r.get("vertices_pulled_in"),
                   r.get("largest_removed_mm"))
                for r in report["keys"] if r.get("vertices_pulled_in")]
        _ascii_report(self, {"INFO"},
                      "; ".join(rows) or "nothing was outside its region")
        return {"FINISHED"}


class SRS_OT_costume_bind(bpy.types.Operator):
    bl_idname = "srs.costume_bind"
    bl_label = "Bind Costume Part"
    bl_description = (
        "Bind the selected parts by inheriting the skin's own weights instead of picking bones by "
        "distance. The body is already bound and already tuned, so copying it keeps the garment in "
        "step with the skin at every joint; a proximity solve produces a second opinion that "
        "disagrees. It also settles what proximity cannot: the twelve fingernail islands vote "
        "unanimously for the wrong fingers and give the middle one nothing"
    )
    bl_options = {'UNDO'}

    donor: bpy.props.StringProperty(
        name="Donor",
        description=(
            "The mesh to copy weights from -- the body for a garment, the face for anything on the "
            "head. Leave empty to use the active object"
        ),
        default="",
    )
    rigid: bpy.props.BoolProperty(
        name="Solid Part",
        description=(
            "For a part the modeller built as one solid piece: a nail, a stud, a zip tooth. Each "
            "island is collapsed onto the single bone the transfer ranked first. Left deforming, a "
            "ring stretched its own edges 74.5 per cent when the finger curled"
        ),
        default=False,
    )
    base_space: bpy.props.BoolProperty(
        name="Donor's Base Shape",
        description=(
            "Transfer against the donor's unshaped mesh. Correct only when the part shares the "
            "donor's shape key, and then decisive: the boot sits 0.00mm from the body's base "
            "surface and 0.50mm from its evaluated one"
        ),
        default=False,
    )

    def execute(self, context):
        _lift_rig = shoe_lift.arp_rig(_settings(context).target_armature) or shoe_lift.arp_rig(likely_armature(context))
        if shoe_lift.guard_message(_lift_rig):
            _ascii_report(self, {"WARNING"}, shoe_lift.guard_message(_lift_rig))
            return {"CANCELLED"}
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, tr_format("Choose the rig first."))
            return {"CANCELLED"}
        named = bpy.data.objects.get(self.donor)
        donor = named
        active = context.active_object
        selected = [o for o in context.selected_objects if o.type == "MESH"]
        # 衣装だけを選んで押した時は、衣装を写し元にせず、肌を探して写す
        if donor is None and active is not None and active.type == "MESH" \
                and any(o is not active for o in selected) \
                and costume_bind.carries_rig_weights(active, armature):
            donor = active
        body = settings.target_body_mesh
        # 体は写し先にしない。調整済みのウェイトが衣装のもので上書きされる
        targets = [o for o in selected if o is not donor and o is not body]
        kept, kept_message = [], ""
        body_message = ""
        if named is not None and body in selected and body is not donor:
            body_message = tr_format("%(body)s is the Target Body Mesh, so its weights were left alone.", body=body.name)
        if donor is None:
            if body is not None and body.type == "MESH" and costume_bind.carries_rig_weights(body, armature):
                donor = body
            else:
                # 写し元を誰も決めていない時は、ウェイトのあるメッシュ（体かもしれない）に書かない
                kept = [o for o in targets if costume_bind.carries_rig_weights(o, armature)]
                targets = [o for o in targets if o not in kept]
        if kept:
            kept_message = tr_format(
                "%(parts)s already has weights on %(rig)s, so it was left alone. To copy over them, set Target Body Mesh or Ctrl-click the skin last.",
                parts=", ".join(o.name for o in kept), rig=armature.name)
        if named is not None:
            # 写し元の欄を埋めていても、この押し方で結合した物以外（体かもしれない）には書かない
            kept = [o for o in targets if not o.get(costume_bind.COSTUME_PART_KEY)
                    and costume_bind.carries_rig_weights(o, armature)]
            targets = [o for o in targets if o not in kept]
            if kept:
                kept_message = tr_format(
                    "%(parts)s already has its own weights on %(rig)s, so it was left alone. To copy over them, empty Copy Weights From and Ctrl-click the source last.",
                    parts=", ".join(o.name for o in kept), rig=armature.name)
        if not targets:
            _ascii_report(self, {"WARNING"}, body_message or kept_message or tr_format("Select the costume parts to bind."))
            return {"CANCELLED"}
        if donor is None:
            donor = costume_bind.find_skin(targets, armature, context.scene)
        if donor is None:
            _ascii_report(self, {"WARNING"}, tr_format(
                "No skin to copy weights from: no visible mesh is bound to %(rig)s. Bind the body first.",
                rig=armature.name))
            return {"CANCELLED"}
        done, failed = [], []
        for target in targets:
            report, error = costume_bind.bind_part(
                target, donor, armature, collapse=False, rigid=self.rigid,
                mute_donor_keys=self.base_space)
            if report is None:
                failed.append("%s: %s" % (target.name, _localized_report_message(error)))
                continue
            target[costume_bind.COSTUME_PART_KEY] = True
            done.append(tr_format("%(part)s (%(percent).0f%% reached)", part=target.name,
                                  percent=report["coverage"] * 100.0))
        if failed and not done:
            _ascii_report(self, {"WARNING"}, tr_format("Nothing was bound. Refused: %(refused)s",
                                                       refused="; ".join(failed)))
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, tr_format("Copied the weights of %(donor)s onto: %(parts)s",
                                                donor=donor.name, parts="; ".join(done)))
        if failed:
            _ascii_report(self, {"WARNING"}, tr_format("Refused: %(refused)s", refused="; ".join(failed)))
        if kept:
            _ascii_report(self, {"WARNING"}, kept_message)
        if body_message:
            _ascii_report(self, {"WARNING"}, body_message)
        return {"FINISHED"}


class SRS_OT_clear_contact(bpy.types.Operator):
    bl_idname = "srs.clear_contact"
    bl_label = "Clear Contact"
    bl_description = (
        "Lift only the vertices that graze the layer underneath out to the clearance, once, in the stored mesh, and "
        "leave every other vertex where it was modelled. For a belt whose bands sit clear of the sleeve except where "
        "they touch: the few that touch are what become intersecting triangles"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"             and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        part = context.active_object
        donor = settings.under_part
        if part is None or part.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the outer part.")
            return {"CANCELLED"}
        if donor is None:
            _ascii_report(self, {"WARNING"}, "Set the garment underneath.")
            return {"CANCELLED"}
        chosen = [v.index for v in part.data.vertices if v.select]
        report, error = costume_bind.clear_contact(
            part, donor, clearance_mm=float(settings.keep_outside_mm),
            indices=chosen or None)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self, {"INFO"},
            "%d of %d vertices lifted to %.1fmm, worst push %.2fmm%s."
            % (report["moved"], report["considered"], report["clearance_mm"],
               report["worst_push_mm"],
               ", %d refused as too deep to be contact" % report["refused"]
               if report["refused"] else ""))
        return {"FINISHED"}


class SRS_OT_keep_outside(bpy.types.Operator):
    bl_idname = "srs.keep_outside"
    bl_label = "Keep Outside Layer"
    bl_description = (
        "Hold the selected part outside the layer underneath it, clamping the deformed result rather than the rest "
        "shape. Weights cannot always do this: a belt wrapped round a sleeve has to cross the sleeve when the elbow "
        "folds, because both are thin shells and the fold closes on itself. Only vertices that went inside are moved"
    )
    bl_options = {'UNDO'}

    remove: bpy.props.BoolProperty(
        name="Remove", default=False,
        description="Take the clamp off instead of adding it",
    )

    def execute(self, context):
        settings = _settings(context)
        part = context.active_object
        donor = settings.under_part
        if part is None or part.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the outer part.")
            return {"CANCELLED"}
        if self.remove:
            report, error = costume_bind.drop_keep_outside(part)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            _ascii_report(self, {"INFO"},
                          "Clamp removed." if report["removed"]
                          else "There was no clamp on this part.")
            return {"FINISHED"}
        if donor is None:
            _ascii_report(self, {"WARNING"}, "Set the garment underneath.")
            return {"CANCELLED"}
        report, error = costume_bind.keep_outside(
            part, donor, offset_mm=float(settings.keep_outside_mm))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self, {"INFO"},
            "%s held %.1fmm outside %s%s."
            % (report["part"], report["offset_mm"], report["target"],
               ", moved after the armature" if report["reordered"] else ""))
        return {"FINISHED"}


class SRS_OT_clear_chain(bpy.types.Operator):
    bl_idname = "srs.clear_chain"
    bl_label = "Remove Chain"
    bl_description = (
        "Take the chain of the given name off this rig, bones and vertex groups together. Rebuilding over a chain "
        "that is still there leaves the old bones owning vertices nobody looks at, and two chains under one name is "
        "a rig where half the control works"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        key = str(settings.chain_key).strip()
        if not key:
            _ascii_report(self, {"WARNING"}, "Name the chain to remove.")
            return {"CANCELLED"}
        total = 0
        for prefix in jiggle.CHAIN_PREFIXES:
            report, error = costume_bind.clear_chain(armature, key,
                                                     prefix=prefix)
            if error:
                continue
            total += len(report["bones"])
        _ascii_report(self, {"INFO"},
                      "%d bone(s) removed under %r." % (total, key))
        return {"FINISHED"}


class SRS_OT_additive_bones(bpy.types.Operator):
    bl_idname = "srs.additive_bones"
    bl_label = "Add Adjust Bones"
    bl_description = (
        "Give the selected part its own adjustable copy of the bones that carry it: a child of each, with the part's "
        "weight moved to the child. The body animation reaches the part unchanged because the parent carries it, and "
        "an animator rotating the child adds a correction on top instead of replacing the body's curve"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" \
            and context.mode == "OBJECT"

    threshold: bpy.props.FloatProperty(
        name="Only Bones Above", default=0.3, min=0.0, max=1.0,
        description="Ignore a bone the part barely uses",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        if armature is None or mesh is None or mesh.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the part, with a rig set.")
            return {"CANCELLED"}
        chosen = [v.index for v in mesh.data.vertices if v.select]
        scope = chosen or None
        by_index = {g.index: g.name for g in mesh.vertex_groups}
        wanted = set()
        pool = scope if scope is not None else range(len(mesh.data.vertices))
        for index in pool:
            for entry in mesh.data.vertices[index].groups:
                name = by_index.get(entry.group)
                if name and entry.weight >= self.threshold \
                        and not name.startswith("srs_"):
                    wanted.add(name)
        sources = sorted(n for n in wanted if armature.data.bones.get(n))
        if not sources:
            _ascii_report(self, {"WARNING"},
                          "Nothing on this part is carried above %.2f."
                          % self.threshold)
            return {"CANCELLED"}
        report, error = costume_bind.additive_bones(
            mesh, armature, sources, indices=scope, prefix="srs_adjust",
            bone_collection="SRS Costume", share=1.0)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        rig_hygiene.normalise_deform(mesh, armature)
        _ascii_report(
            self, {"INFO"},
            "%d adjust bone(s) made over %d vertices."
            % (len(report["pairs"]), report["vertices"]))
        return {"FINISHED"}


def _leave_hand_chains_out(armature, key):
    """A chain built with Swing = None is posed by hand: keep it out of every bake."""
    for (prefix, name), bones in jiggle.all_chains(armature).items():
        if name == key or name.startswith(key + "_"):
            root = armature.pose.bones.get(bones[0])
            if root is not None:
                root[jiggle.CHAIN_BAKE] = False


class SRS_OT_build_chain(bpy.types.Operator):
    bl_idname = "srs.build_chain"
    bl_label = "Build Chain"
    bl_description = (
        "Grow a bone chain down the selected part and weight the part onto it, then store the swing settings on the "
        "chain's root so a re-bake repeats itself. Select vertices in Edit Mode to chain only that part of the mesh; "
        "with nothing selected the whole mesh is used"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" \
            and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        rig = settings.target_armature or likely_armature(context)
        part = context.active_object
        parent = str(settings.chain_parent).strip()
        if rig is not None and parent and rig.data.bones.get(parent) is None:
            _ascii_report(self, {"WARNING"}, tr_format(
                "%(rig)s has no bone named %(bone)s. Choose an existing bone in From, or leave it empty.",
                rig=rig.name, bone=parent))
            return {"CANCELLED"}
        tie = None
        if rig is not None and part is not None and part.type == "MESH" and len(part.data.vertices):
            tie, error = costume_bind.tie_unbound_part(part, rig, parent)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
        result = self._build(context, tie["hung_from"] if tie is not None else "")
        if tie is not None:
            if "FINISHED" in result:
                if tie["modifiers"]:
                    _ascii_report(self, {"INFO"}, tr_format(
                        "%(part)s was not bound to %(rig)s, so it was bound now. Its root follows %(bone)s.",
                        part=part.name, rig=rig.name, bone=tie["anchor"] or "-"))
                elif tie["loose"]:
                    _ascii_report(self, {"INFO"}, tr_format(
                        "%(count)d vertices of %(part)s had no weight, so they now follow %(bone)s.",
                        count=len(tie["loose"]), part=part.name, bone=tie["anchor"] or "-"))
                if tie["link"]:
                    _ascii_report(self, {"INFO"}, tr_format(
                        "%(part)s no longer hangs from %(link)s: it follows the rig through the modifier now, and would otherwise move twice.",
                        part=part.name, link=tie["link"]))
            else:
                costume_bind.untie_part(part, tie)
        if "FINISHED" in result and settings.chain_feel == 'NONE':
            armature = settings.target_armature or likely_armature(context)
            if armature is not None:
                _leave_hand_chains_out(armature, str(settings.chain_key).strip() or "part")
        return result

    def _build(self, context, hung_from=""):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        if armature is None or mesh is None or mesh.type != "MESH":
            _ascii_report(self, {"WARNING"}, "Select the part, with a rig set.")
            return {"CANCELLED"}
        chosen = [v.index for v in mesh.data.vertices if v.select]
        indices = chosen or [v.index for v in mesh.data.vertices]
        if not indices:
            _ascii_report(self, {"WARNING"}, "That mesh has no vertices.")
            return {"CANCELLED"}
        feel = jiggle.FEEL.get(settings.chain_feel)
        key = str(settings.chain_key).strip() or "part"
        parent = str(settings.chain_parent).strip() or hung_from
        mode = settings.chain_mode
        if settings.chain_pivots == 'RINGS' and mode == 'STRAND' \
                and getattr(settings, "chain_ring_source", "STRANDS") == 'EDGE':
            # One strap from the selection's top edge: the loops are counted by the
            # mesh's connectivity from where the selection meets the rest of its
            # island, so a strap that curls round a buckle keeps its loops in order
            # (sorting by height mixed the two sides of the curl).
            layers, error = costume_bind.edge_layers(mesh, indices)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            costume_bind.clear_chain(armature, key, meshes=[mesh])
            report, error = costume_bind.chain_on_rings(
                mesh, armature, layers, key, parent_bone=parent,
                first_ring=int(settings.chain_first_ring),
                blend_rings=int(settings.chain_ring_blend), jiggle=feel,
                min_mm=float(getattr(settings, "chain_ring_spacing_mm", 0.0)),
                root_follow=bool(getattr(settings, "chain_root_follow", False)))
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            rig_hygiene.normalise_deform(mesh, armature, keep=report["bones"])
            _ascii_report(self, {"INFO"}, tr_format(
                "%(key)s: %(bones)d bone(s) on %(loops)d loops from the selection's top edge.",
                key=key, bones=report["bone_count"], loops=len(layers)))
            return {"FINISHED"}
        if settings.chain_pivots == 'RINGS' and mode == 'STRAND':
            # 毛束は島ではない。前髪の長い 5 本はどれも片方の毛先から頭頂を
            # 越えて反対側の毛先まで続く U 字で、1 島が左右 2 本ぶんになる。
            strands, error = costume_bind.ring_strands(mesh, indices)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            skip = int(settings.chain_first_ring)
            floor_mm = float(settings.chain_ring_min_mm)
            for row in strands:
                if row["strand"]:
                    costume_bind.clear_chain(
                        armature, "%s_%s" % (key, row["key_hint"]),
                        meshes=[mesh])
            held, bones, short, failed = [], 0, 0, []
            loose = []
            for row in strands:
                if not row["strand"]:
                    loose.extend(i for ring in row["rings"] for i in ring)
                    continue
                sub = "%s_%s" % (key, row["key_hint"])
                take = skip if row["length_mm"] > floor_mm else 0
                if take == 0 and skip:
                    short += 1
                report, error = costume_bind.chain_on_rings(
                    mesh, armature, row["rings"], sub, parent_bone=parent,
                    first_ring=take,
                    blend_rings=int(settings.chain_ring_blend), jiggle=feel,
                    min_mm=float(getattr(settings, "chain_ring_spacing_mm", 0.0)),
                root_follow=bool(getattr(settings, "chain_root_follow", False)))
                if error:
                    failed.append("%s: %s" % (sub, _localized_report_message(error)))
                    continue
                held.extend(report["bones"])
                bones += report["bone_count"]
            if not held:
                _ascii_report(self, {"WARNING"}, tr_format("No strand could be chained. %(reason)s",
                                                           reason=failed[0] if failed else ""))
                return {"CANCELLED"}
            # 毛束でない切れ端も、隣の毛先に付けてから正規化する。
            # 置いていくと毛先が振れても蓋だけ頭に残る。
            welded = 0
            if loose:
                stray, stray_error = costume_bind.attach_strays(
                    mesh, loose)
                if stray_error:
                    failed.append(tr_format("loose vertices: %(reason)s",
                                            reason=_localized_report_message(stray_error)))
                else:
                    welded = stray["welded"]
            # keep= なしで呼ぶと鎖の 1.0 まで一緒に縮められる
            rig_hygiene.normalise_deform(mesh, armature, keep=held)
            real = [r for r in strands if r["strand"]]
            left = sum(1 for r in real if r["side"] == "l")
            _ascii_report(self, {"INFO"}, tr_format(
                "%(key)s: %(strands)d strand(s) (%(left)d left, %(right)d right), %(bones)d bone(s), one per "
                "edge loop; %(short)d posed from the root as too short; %(welded)d loose "
                "vertex(es) welded to the nearest bone.",
                key=key, strands=len(real), left=left, right=len(real) - left, bones=bones, short=short,
                welded=welded))
            if failed:
                _ascii_report(self, {"WARNING"}, tr_format("Skipped: %(skipped)s", skipped="; ".join(failed[:2])))
            return {"FINISHED"}
        if settings.chain_pivots not in {'EVEN', 'RINGS'} and mode == 'STRAND':
            # joints from the geometry, not from dividing the length
            match = str(settings.chain_rigid_match).strip()
            spans, error = costume_bind.element_spans(
                [mesh], axis="Z", rigid_match=match or "metal",
                by_material=bool(match))
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            spans = [s for s in spans if set(s["indices"]) & set(indices)]
            rails = costume_bind.loop_positions(mesh, indices, axis="Z")
            if settings.chain_pivots == 'DIVISIONS':
                pivots, plan = costume_bind.pivot_plan(spans, rails, every=1)
            else:
                pivots, plan = costume_bind.pivot_plan(
                    spans, rails,
                    target_mm=float(settings.chain_target_mm),
                    root_mm=float(settings.chain_root_mm),
                    root_span_mm=float(settings.chain_root_span_mm))
            if plan.get("error"):
                _ascii_report(self, {"WARNING"}, plan["error"])
                return {"CANCELLED"}
            costume_bind.clear_chain(armature, key, meshes=[mesh])
            report, error = costume_bind.chain_on_pivots(
                [(mesh, indices)], armature, pivots, key,
                parent_bone=parent, axis="Z",
                rigid_spans=[s for s in spans if s["rigid"]],
                blend_mm=float(settings.chain_target_mm) * 0.3, jiggle=feel)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            # keep= なしで呼ぶと、鎖の 1.0 まで一緒に縮められる。
            rig_hygiene.normalise_deform(mesh, armature,
                                         keep=report["bones"])
            _ascii_report(self, {"INFO"}, tr_format(
                "%(key)s: %(bones)d bone(s), %(joints)d joint(s) on a division, %(inside)d inside a rigid "
                "piece, spacing %(low).1f to %(high).1fmm.",
                key=key, bones=report["bone_count"], joints=plan["on_division"],
                inside=plan["inside_rigid"], low=report["segment_mm"]["min"],
                high=report["segment_mm"]["max"]))
            return {"FINISHED"}
        if mode == 'SHEET':
            report, error = costume_bind.sheet_chains(
                mesh, armature, indices, columns=int(settings.chain_columns),
                bones=int(settings.chain_bones), key=key, parent_bone=parent,
                across=settings.chain_across, jiggle=feel)
        elif mode == 'LINKS':
            rows, error = costume_bind.stack_islands(mesh, indices)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            if len(rows) < 2:
                _ascii_report(self, {"WARNING"}, tr_format(
                    "Links needs two or more separate pieces; found %(count)d.", count=len(rows)))
                return {"CANCELLED"}
            report, error = costume_bind.link_chain(
                mesh, armature, [r["indices"] for r in rows],
                parent_bone=parent, key=key, jiggle=feel)
        elif len(set(indices)) < 4:
            report, error = None, "Too few vertices to chain"
        else:
            report, error = costume_bind.chain_part(
                mesh, armature, indices, bones=int(settings.chain_bones),
                key=key, parent_bone=parent, takeover="ramp", jiggle=feel)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if mode == 'SHEET' and not report["bones"]:
            reasons = [row["error"] for row in report["rows"] if row.get("error")]
            _ascii_report(self, {"WARNING"}, reasons[0] if reasons else "No vertex was given")
            return {"CANCELLED"}
        rig_hygiene.normalise_deform(mesh, armature)
        made = report.get("bone_count")
        if made is None:
            made = len(report.get("bones", []) or [])
        _ascii_report(
            self,
            {"INFO"},
            tr_format("%(key)s: %(bones)d bone(s) over %(vertices)d vertices, %(mm).0fmm long.",
                      key=key, bones=made, vertices=len(indices), mm=report.get("length_mm", 0.0)),
        )
        return {"FINISHED"}


class SRS_OT_fit_colliders(bpy.types.Operator):
    bl_idname = "srs.fit_colliders"
    bl_label = "Fit Collision Capsules"
    bl_description = (
        "Fit a lightweight collision capsule to each body part from the skin's own shape, as bones you can see and "
        "drag. This is what the jiggle chains are pushed out of, and what the low-poly collision meshes are built "
        "from, so the two cannot disagree"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        _lift_rig = shoe_lift.arp_rig(_settings(context).target_armature) or shoe_lift.arp_rig(likely_armature(context))
        if shoe_lift.guard_message(_lift_rig):
            _ascii_report(self, {"WARNING"}, shoe_lift.guard_message(_lift_rig))
            return {"CANCELLED"}
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        meshes = [m for m in (settings.collide_skin, settings.collide_face,
                              settings.collide_mesh_c, settings.collide_mesh_d,
                              settings.collide_mesh_e) if m is not None]
        if not meshes:
            meshes = [m for m in (settings.target_body_mesh,) if m is not None]
        if not meshes:
            _ascii_report(self, {"WARNING"},
                          "Choose the skin mesh to fit against.")
            return {"CANCELLED"}
        report, error = collide.fit(
            armature, meshes,
            percentile=float(settings.collide_percentile) / 100.0,
            inset=float(settings.collide_inset),
            include_toes=bool(settings.collide_toes),
            split_ratio=float(settings.collide_split))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        worst = sorted(report["rows"], key=lambda r: -r["fitted_mm"])[:3]
        _ascii_report(
            self, {"INFO"},
            "%d capsule(s); biggest %s. %d fell back to bone size, %d refused."
            % (report["count"],
               _report_list(("%s %.0fmm (raw max %.0f)"
                             % (r["name"].replace("srs_col_", ""), r["fitted_mm"],
                                r["raw_max_mm"]) for r in worst), ", "),
               len(report["fallback"]), len(report["refused"])))
        return {"FINISHED"}


class SRS_OT_colliders_fit_without(bpy.types.Operator):
    bl_idname = "srs.colliders_fit_without"
    bl_label = "Fit Capsules Without Part"
    bl_description = (
        "Keep on every capsule the size it should have with the part taken off (the Part field), fitted the same "
        "way as Fit Capsules. While the part is hidden with Show / Hide Part, the capsules switch to it, so hair and "
        "straps rest on what is really there instead of on a coat that is hidden"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        part = str(settings.part_name).strip()
        collection = bpy.data.collections.get(part) if part else None
        if armature is None or collection is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig and the part first.")
            return {"CANCELLED"}
        meshes = [m for m in (settings.collide_skin, settings.collide_face,
                              settings.collide_mesh_c, settings.collide_mesh_d,
                              settings.collide_mesh_e) if m is not None]
        if not meshes:
            meshes = [m for m in (settings.target_body_mesh,) if m is not None]
        part_meshes = [o for o in collection.all_objects if o.type == "MESH"]
        report, error = collide.fit_without(
            armature, meshes, part, part_meshes,
            percentile=float(settings.collide_percentile) / 100.0,
            inset=float(settings.collide_inset),
            include_toes=bool(settings.collide_toes),
            split_ratio=float(settings.collide_split))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%d of %d capsules are smaller without %s." % (
            len(report["smaller_without"]), report["capsules"], part))
        return {"FINISHED"}


class SRS_OT_umbrella_rolls(bpy.types.Operator):
    bl_idname = "srs.umbrella_rolls"
    bl_label = "Roll Bones to Open Outward"
    bl_description = (
        "Roll the selected bones so that one positive rotation about their local X opens all of them outward, "
        "like an umbrella: Y along the bone, Z away from the centre (Ring: the vertical axis through the group, "
        "Body: the nearest body bone). The rest shape and the motion do not change: swing bones roll with their "
        "links, and the pose and keys are converted to the new axes"
    )
    bl_options = {'UNDO'}

    centre: bpy.props.EnumProperty(
        name="Centre",
        items=[('ring', "Ring axis", "Away from the vertical axis through the selected bones (a skirt, a coat's strips)"),
               ('body', "Body", "Away from the nearest body bone (tails, straps, zips)")],
        default='ring')
    midline: bpy.props.BoolProperty(
        name="Centre on the Midline", default=True,
        description="Ring: put the axis on the rig's centre plane, so left and right bones open as mirror images")
    along_chains: bpy.props.BoolProperty(
        name="Along Chains", default=True,
        description="A bone whose parent is selected too carries its parent's outward, so a chain opens one way all the way down")
    arms: bpy.props.EnumProperty(
        name="Arms", default='AUTO',
        items=[('AUTO', "Auto", "Arm bones count only for bones that hang from an arm (an arm band's tips)"),
               ('INCLUDE', "Count In", "Arm bones always count as body"),
               ('EXCLUDE', "Leave Out", "Arm bones never count as body")],
        description="Body: whether the arms count when measuring away from the body")
    body_bones: bpy.props.StringProperty(
        name="Body Bones", default="",
        description="Body: the bones to measure from, separated by commas. Empty uses the Auto-Rig Pro deform body")

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        names = [b.name for b in context.selected_pose_bones or ()] or \
            [pb.name for pb in armature.pose.bones if pb.select]
        if not names:
            _ascii_report(self, {"WARNING"}, "Select the bones to roll in Pose Mode.")
            return {"CANCELLED"}
        body = tuple(b.strip() for b in str(self.body_bones).split(",") if b.strip()) or rig_hygiene.BODY_AXES
        report, error = rig_hygiene.umbrella_rolls(armature, names, centre=self.centre, midline=self.midline,
                                                   along_chains=self.along_chains, arms=self.arms, body=body)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%d bones rolled; %d open outward under +X." % (
            report["rolled"], report["opened_by_plus_x"]))
        return {"FINISHED"}


class SRS_OT_clear_colliders(bpy.types.Operator):
    bl_idname = "srs.clear_colliders"
    bl_label = "Remove Capsules"
    bl_description = "Delete every collision capsule bone"
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = collide.clear(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"},
                      "Removed %d capsule bone(s)." % report["removed"])
        return {"FINISHED"}


class SRS_OT_collision_proxy(bpy.types.Operator):
    bl_idname = "srs.collision_proxy"
    bl_label = "Build Collision Meshes"
    bl_description = (
        "Generate the low-poly collision meshes from the capsules, for the cloth simulation to land on instead of the "
        "body itself. Each one is parented to its capsule bone, hidden from render, and carries a Collision modifier"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = collide.build_proxy(
            armature, sides=int(settings.collide_sides))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self, {"INFO"},
            "%d collision mesh(es) at %d sides. Worst facet sag %.1fmm -- "
            "raise the sides if the cloth dips into a flat."
            % (report["count"], report["sides"], report["sag_mm"]))
        return {"FINISHED"}


class SRS_OT_clear_collision_proxy(bpy.types.Operator):
    bl_idname = "srs.clear_collision_proxy"
    bl_label = "Remove Collision Meshes"
    bl_description = "Delete the generated low-poly collision meshes"
    bl_options = {'UNDO'}

    def execute(self, context):
        report, error = collide.clear_proxy()
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"},
                      "Removed %d collision mesh(es)." % report["removed"])
        return {"FINISHED"}


# What the last bake warned about, for an operator that runs a bake and reports after it.
_BAKE_WARNINGS = []


class SRS_OT_jiggle_bake(bpy.types.Operator):
    bl_idname = "srs.jiggle_bake"
    bl_label = "Bake Jiggle"
    bl_description = (
        "Solve secondary motion for the chains on the selected bones and write it as ordinary "
        "keyframes. Not a simulation and not a handler: what the file ends up with is bone "
        "animation, so it plays without this add-on, exports through anything that carries bone "
        "curves, and can be edited by hand. Run it after the body animation is in place"
    )
    bl_options = {'UNDO'}

    prefix: bpy.props.StringProperty(
        name="Chain Prefix", default="",
        description=(
            "Limit the bake to chains under one prefix -- 'hair' for the hair "
            "builder's chains, 'srs_chain' for costume, piercing, zip and hem "
            "chains. Leave it empty, which is the default, to bake whichever of "
            "them the selection touches"
        ),
    )
    stiffness: bpy.props.FloatProperty(
        name="Stiffness", default=0.45, min=0.01, max=1.0,
        description=(
            "How hard each link is pulled back to where the head carries it. Measured on a braid: "
            "0.45 with 0.30 damping swings 1014mm and settles to 10mm"
        ),
    )
    damping: bpy.props.FloatProperty(
        name="Damping", default=0.30, min=0.0, max=1.0,
        description="How fast the swing dies away. Too little and the braid never settles",
    )
    inertia: bpy.props.FloatProperty(
        name="Drag", default=0.5, min=0.0, max=2.0,
        description=(
            "How much the chain resists being dragged sideways, which is what makes hair swing when "
            "the head moves rather than turns"
        ),
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )
    gravity: bpy.props.FloatProperty(
        name="Weight", default=0.0, min=0.0, soft_max=200.0,
        description="Downward pull in millimetres per frame squared, weighted at each joint by the "
                    "length still hanging below it, so the chain hangs root-first and one value "
                    "means the same thing however finely the mesh happens to be divided. A strand "
                    "needs none; something that should fall rather than hold its modelled shape "
                    "needs enough to outweigh the stiffness",
    )

    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    use_selection: bpy.props.BoolProperty(
        name="Use Selection", default=True,
        description="Off: act only on the named chains (or every chain in the bake) whatever is selected",
    )
    frame_start: bpy.props.IntProperty(name="Start", default=0, description="0 uses the scene's start")
    frame_end: bpy.props.IntProperty(name="End", default=0, description="0 uses the scene's end")
    collide: bpy.props.EnumProperty(
        name="Collide", default='PANEL',
        items=[('PANEL', "Panel", "Use the panel's setting"), ('ON', "On", "Collide"), ('OFF', "Off", "Do not collide")],
        description="A chain's own setting on its root still wins",
    )
    collide_mm: bpy.props.FloatProperty(name="Thickness", default=-1.0, description="Below 0 uses the panel's")
    collide_sweeps: bpy.props.IntProperty(name="Quality", default=0, min=0, description="0 uses the panel's")
    floor: bpy.props.EnumProperty(
        name="Floor", default='PANEL',
        items=[('PANEL', "Panel", "Use the panel's setting"), ('ON', "On", "Stop at the floor"), ('OFF', "Off", "No floor")],
    )
    floor_z: bpy.props.FloatProperty(name="Floor Height", default=0.0, unit='LENGTH',
                                     description="Used when Floor is On")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        wanted = (self.prefix,) if self.prefix else jiggle.CHAIN_PREFIXES
        if self.chains.strip():
            chains, missing = jiggle.chains_by_keys(armature, jiggle.parse_keys(self.chains), wanted)
            if missing:
                _ascii_report(self, {"WARNING"}, tr_format("No chain under: %(keys)s.", keys=", ".join(missing)))
                return {"CANCELLED"}
        else:
            chains = {k: v for k, v in jiggle.all_chains(armature, wanted).items()
                      if k[1] != "master"}
            chosen = {b.name for b in context.selected_pose_bones or ()} if self.use_selection else set()
            if chosen:
                chains = {k: v for k, v in chains.items()
                          if any(n in chosen for n in v)}
        left_out = sorted(k[1] for k, v in chains.items() if not jiggle.in_bake(armature, v))
        chains = {k: v for k, v in chains.items() if jiggle.in_bake(armature, v)}
        if not chains:
            _ascii_report(self, {"WARNING"},
                          tr_format("No chain found. Select a bone of the chain, or set "
                                    "the prefix to 'hair' or 'srs_chain'.")
                          + (tr_format(" %(count)d chains are left out of the bake.", count=len(left_out))
                             if left_out else ""))
            return {"CANCELLED"}
        scene = context.scene
        settings = _settings(context)
        collide_on = (self.collide == 'ON') or (self.collide == 'PANEL' and bool(getattr(settings, "chain_collide", False)))
        collide_mm = float(self.collide_mm) if self.collide_mm >= 0.0 else float(settings.chain_collide_mm)
        sweeps = int(self.collide_sweeps) if self.collide_sweeps > 0 else int(settings.chain_collide_sweeps)
        floor_on = (self.floor == 'ON') or (self.floor == 'PANEL' and bool(getattr(settings, "chain_floor", False)))
        floor_z = float(self.floor_z) if self.floor == 'ON' else float(getattr(settings, "chain_floor_z", 0.0))
        wanted_collide = None
        if collide_on:
            wanted_collide = {"radius": collide_mm * 0.001, "sweeps": sweeps}
        # ONE pass over the frames for every chain. Baking them one at a time
        # re-evaluates the whole scene once per chain per frame, and on this rig
        # that measured 1.37s per evaluated frame -- 3.7 hours for 17 chains
        # over 505 frames, all of it the same 505 evaluations repeated.
        jobs, keys = [], []
        first = int(self.frame_start) or scene.frame_start
        last = int(self.frame_end) or scene.frame_end
        if last < first:
            _ascii_report(self, {"WARNING"}, tr_format("The frame range ends before it starts."))
            return {"CANCELLED"}
        # the mesh each link carries is read at the bake's first frame, not wherever the playhead is
        frame_now = scene.frame_current
        if floor_on and frame_now != first:
            scene.frame_set(first)
        for (prefix, key), bones in sorted(chains.items()):
            stored = jiggle.settings_for(armature, key, prefix=prefix)
            # a chain that LIES ON the surface must not be pushed off it. The
            # coat's hems are sewn to the coat at the waist, so they sit inside
            # the torso capsule by construction and reported up to 3597
            # unresolvable contacts -- that is the hem resting where it
            # belongs, not penetration. The root bone decides, falling back to
            # the panel switch.
            root = armature.pose.bones.get(bones[0])
            mine = wanted_collide
            if root is not None and "srs_jiggle_collide" in root:
                # False, not None: None would inherit the panel switch again
                mine = wanted_collide if root["srs_jiggle_collide"] else False
            if isinstance(mine, dict) and root is not None and jiggle.CHAIN_SUBSTEPS in root:
                mine = dict(mine, substeps=max(1, int(root[jiggle.CHAIN_SUBSTEPS])))
            if isinstance(mine, dict) and root is not None:
                # the chain's own contact behaviour, absent = the solver default
                own = {}
                if jiggle.CHAIN_REST_CONTACT in root:
                    own["rest"] = bool(root[jiggle.CHAIN_REST_CONTACT])
                if jiggle.CHAIN_ENTRY_PUSH in root:
                    own["entry_push"] = bool(root[jiggle.CHAIN_ENTRY_PUSH])
                if jiggle.CHAIN_EXIT_SLOPE in root:
                    own["exit_slope"] = max(0.0, float(root[jiggle.CHAIN_EXIT_SLOPE]))
                if jiggle.CHAIN_TIP_MM in root and float(root[jiggle.CHAIN_TIP_MM]) > 0.0:
                    own["tip_mm"] = float(root[jiggle.CHAIN_TIP_MM]) * 0.001
                if own:
                    mine = dict(mine, **own)
            # every one of the four, or the re-bake does not reproduce the
            # tuning the chain was measured with -- drag is what made the long
            # braid settle, and taking it from the operator default instead of
            # the chain undoes that silently
            jobs.append({
                "bones": bones,
                "stiffness": stored.get("stiffness", self.stiffness),
                "damping": stored.get("damping", self.damping),
                "gravity": stored.get("gravity", self.gravity),
                "inertia": stored.get("inertia", self.inertia),
                "collide": mine,
                "floor": ((floor_z + collide_mm * 0.001) if floor_on else None),
                # the mesh the chain carries stays above the floor too, not
                # only its bone line
                "mesh_floor": (floor_z if floor_on else None),
                "reach": (jiggle.chain_reach(armature, bones) if floor_on else None),
                "gravity_rest": bool(root.get(jiggle.CHAIN_GRAVITY_REST, False)) if root is not None else False,
                "rest_clear": bool(root.get(jiggle.CHAIN_REST_CLEAR, False)) if root is not None else False,
                "link_radii": (list(root[jiggle.CHAIN_LINK_RADII]) if root is not None
                               and jiggle.CHAIN_LINK_RADII in root.keys() else None),
            })
            keys.append(key)
        if scene.frame_current != frame_now:
            scene.frame_set(frame_now)
        # bake_many makes a linked Action local (a linked one takes no keys); say so afterwards
        _ad = armature.animation_data
        linked_name = (_ad.action.name if _ad is not None and _ad.action is not None
                       and _ad.action.library is not None else "")
        reports, error = jiggle.bake_many(armature, jobs, first, last)
        if linked_name and not error:
            _ascii_report(self, {"INFO"}, "The rig's Action %s was linked from a library; it was made local "
                                          "so the keys can be written." % linked_name)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        # keys written into a muted curve stay muted: a fresh bake is live (its own curves only)
        for job in jobs:
            _report, error = jiggle.mute_bake(armature, job["bones"], False)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
        done = []
        for key, report in zip(keys, reports):
            note = ""
            if report.get("collided"):
                note = tr_format(", %(count)d capsule(s), %(depth).1fmm deepest contact",
                                 count=report.get("colliders", 0),
                                 depth=report.get("penetration_mm", 0.0))
                if report.get("unresolved_contacts"):
                    note += tr_format(", %(count)d contact(s) at a link's own root that only the parent can resolve",
                                      count=report["unresolved_contacts"])
            if report.get("floor_contacts"):
                note += tr_format(", %(count)d floor contact(s)", count=report["floor_contacts"])
            done.append(tr_format("%(key)s %(keys)d keys, swung %(swung).0fmm, still moving %(moving).2fmm/frame%(note)s",
                                  key=key, keys=report["keys"], swung=report["lag_mm"]["max"],
                                  moving=report["settle_mm_per_frame"]["last20"], note=note))
        if left_out:
            done.append(tr_format("%(count)d chains left out of the bake", count=len(left_out)))
        _ascii_report(self, {"INFO"}, tr_format("Baked frames %(first)d-%(last)d: %(done)s",
                                                first=first, last=last, done="; ".join(done)))
        # last, so the status bar shows them and not the summary above
        warnings = []
        if collide_on and not collide.colliders(armature):
            warnings.append("Collide is on, but this rig has no capsules: the chains pass through the body. "
                            "Press Fit Capsules and bake again.")
        under_floor = [key for key, report in zip(keys, reports) if report.get("under_floor")]
        if under_floor:
            warnings.append(tr_format(
                "The floor was not applied to %(chains)s: at the first frame of the bake it already reaches below "
                "the floor height. Move the character above the floor, or lower the Height.",
                chains=", ".join(under_floor)))
        _BAKE_WARNINGS[:] = warnings
        for warning in warnings:
            _ascii_report(self, {"WARNING"}, warning)
        return {"FINISHED"}


class SRS_OT_jiggle_clear(bpy.types.Operator):
    bl_idname = "srs.jiggle_clear"
    bl_label = "Clear Jiggle"
    bl_description = (
        "Remove the keyframes a jiggle bake wrote, leaving the chains posable again. The rig is "
        "meant to ship without them"
    )
    bl_options = {'UNDO'}

    prefix: bpy.props.StringProperty(
        name="Chain Prefix", default="",
        description="Leave empty to clear whichever chains the selection touches",
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    use_selection: bpy.props.BoolProperty(
        name="Use Selection", default=True,
        description="Off: act only on the named chains whatever is selected",
    )
    only_baked: bpy.props.BoolProperty(
        name="Only Baked Keys", default=True,
        description=(
            "Remove only the curves the bake wrote (its F-curve group), keeping hand keys on the same bones. "
            "Off also removes hand-keyed rotations on the bones the bake writes. Either way only this rig's "
            "Action slot is touched"
        ),
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        wanted = (self.prefix,) if self.prefix else jiggle.CHAIN_PREFIXES
        if self.chains.strip():
            chains, missing = jiggle.chains_by_keys(armature, jiggle.parse_keys(self.chains), wanted)
            if missing:
                _ascii_report(self, {"WARNING"}, tr_format("No chain under: %(keys)s.", keys=", ".join(missing)))
                return {"CANCELLED"}
        else:
            chains = {k: v for k, v in jiggle.all_chains(armature, wanted).items()
                      if k[1] != "master"}
            chosen = {b.name for b in context.selected_pose_bones or ()} if self.use_selection else set()
            if not chosen:
                # never every chain because nothing (or only hidden bones) was
                # selected -- that wiped hand-keyed chains with the baked ones
                _ascii_report(self, {"WARNING"},
                              "Select a bone of each chain to clear, or name the chains.")
                return {"CANCELLED"}
            chains = {k: v for k, v in chains.items()
                      if any(n in chosen for n in v)}
        # a chain left out of the bake is keyed by hand: its keys are not the bake's
        skipped = sorted(k[1] for k, v in chains.items() if not jiggle.in_bake(armature, v))
        chains = {k: v for k, v in chains.items() if jiggle.in_bake(armature, v)}
        removed = 0
        _bag, error = jiggle.rig_channelbag(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for bones in chains.values():
            report, error = jiggle.clear_bake(armature, bones, only_baked=bool(self.only_baked))
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            removed += report["removed"]
            root = armature.pose.bones.get(bones[0])
            if root is not None:
                # a cleared chain is not muted; keep the flag with a value, because a
                # missing flag reads as "unknown" to a selector page's toggle
                root[jiggle.CHAIN_MUTED] = False
        _ascii_report(self, {"INFO"},
                      "Removed %d curve(s) from %d chain(s).%s"
                      % (removed, len(chains),
                         (" Left alone, not in the bake: %s." % ", ".join(skipped)) if skipped else ""))
        return {"FINISHED"}


class SRS_OT_cloth_setup(bpy.types.Operator):
    bl_idname = "srs.cloth_setup"
    bl_label = "Add Cloth Alternative"
    bl_description = (
        "Give the selected garment a cloth solver as well as its skin weights, and one property on "
        "the rig to choose between them. The cloth goes after the armature and before anything "
        "generative, pinned at the waistband, so the simulation inherits the bone motion instead of "
        "fighting it -- and switching it off restores the skinned result exactly"
    )
    bl_options = {'UNDO'}

    band_mm: bpy.props.FloatProperty(
        name="Pinned Band", default=45.0, min=0.0, soft_max=200.0,
        description="How far down from the garment's top edge stays pinned to the bones",
    )
    feather_mm: bpy.props.FloatProperty(
        name="Fade", default=35.0, min=1.0, soft_max=200.0,
        description="How far the pinning fades out. A hard edge creases the waistband",
    )
    collide_with: bpy.props.StringProperty(
        name="Collide With", default="",
        description="A mesh for the cloth to land on -- usually the body. Empty adds none",
    )
    collide_with_2: bpy.props.StringProperty(
        name="Also Collide With", default="",
        description="A second mesh for the cloth to land on, such as shorts worn under a skirt. Empty adds none",
    )
    only_these: bpy.props.BoolProperty(
        name="Only These", default=True,
        description=(
            "Let the cloth collide with the meshes named here and nothing else. Otherwise it also meets every "
            "other collider in the scene, such as capsules fitted to the dressed outline for swinging hair, "
            "which a skirt starts inside and so never meets the body"
        ),
    )
    collision_quality: bpy.props.IntProperty(
        name="Collision Quality", default=4, min=1, max=20,
        description=(
            "Collision steps per cloth step. Measured on a skirt over body and shorts: 4 left 27.5 vertices "
            "a frame inside the body against 44 at 2, for a bake about a fifth longer"
        ),
    )
    self_collision: bpy.props.BoolProperty(
        name="Self Collision", default=False,
        description=(
            "Let the garment collide with itself. Measured on a skirt over body and shorts it doubled the vertices "
            "left inside the body (27.5 to 68 a frame) and made the bake half as slow again"
        ),
    )
    keep_cloth_settings: bpy.props.BoolProperty(
        name="Keep Tuned Cloth", default=True,
        description=(
            "When the garment already has the cloth, keep its physics and its pin weights and only rewire it. "
            "A new cloth starts from the settings of the reference character's skirt"
        ),
    )
    thickness_mm: bpy.props.FloatProperty(
        name="Collider Thickness (mm)", default=5.0, min=1.0, soft_max=20.0,
        description="Outer collision thickness of the first mesh the cloth lands on",
    )
    thickness_2_mm: bpy.props.FloatProperty(
        name="Second Collider Thickness (mm)", default=4.0, min=1.0, soft_max=20.0,
        description="Outer collision thickness of the second mesh, usually a thinner layer such as shorts",
    )
    inner_mm: bpy.props.FloatProperty(
        name="Inner Thickness (mm)", default=2.0, min=1.0, soft_max=20.0,
        description=(
            "How far inside a collider the cloth is still pushed out. Blender's default is 200 mm, "
            "which on a body pushes out cloth that is anywhere within 20 cm inside it"
        ),
    )
    collider_damping: bpy.props.FloatProperty(
        name="Collider Damping", default=0.2, min=0.0, max=1.0,
        description="Damping of the colliders this sets up",
    )
    collider_friction: bpy.props.FloatProperty(
        name="Collider Friction", default=5.0, min=0.0, max=80.0,
        description="Cloth friction of the colliders this sets up",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        garments = [o for o in context.selected_objects if o.type == "MESH"]
        if armature is None or not garments:
            _ascii_report(self, {"WARNING"},
                          "Select the garment and choose the rig first.")
            return {"CANCELLED"}
        # each field keeps its own thickness: a mesh named only in the second
        # field gets the second thickness, not the first
        colliders, thicknesses, unusable = [], [], []
        for name, thickness in ((self.collide_with, self.thickness_mm),
                                (self.collide_with_2, self.thickness_2_mm)):
            if not name:
                continue
            collider = bpy.data.objects.get(name)
            if collider is None or collider.type != "MESH" or collider in garments:
                unusable.append(name)
            elif collider not in colliders:
                colliders.append(collider)
                thicknesses.append(thickness)
        # refuse before anything is changed
        if unusable:
            _ascii_report(self, {"WARNING"}, tr_format(
                "Nothing was changed: %(names)s is not a mesh other than the garment.",
                names=", ".join(unusable)))
            return {"CANCELLED"}
        if self.only_these and not colliders:
            _ascii_report(self, {"WARNING"}, tr_format(
                "Nothing was changed: Only These needs at least one mesh to collide with."))
            return {"CANCELLED"}
        if self.keep_cloth_settings:
            problems = [cloth_setup.kept_pin_problem(g) for g in garments]
            problems = [p for p in problems if p]
            if problems:
                _ascii_report(self, {"WARNING"}, tr_format(
                    "Nothing was changed: %(why)s. Fix the pin group, or turn off Keep Tuned Cloth to rebuild it.",
                    why=_localized_report_message("; ".join(problems))))
                return {"CANCELLED"}
        for collider, thickness in zip(colliders, thicknesses):
            cloth_setup.add_collision(
                collider, thickness_mm=thickness,
                damping=self.collider_damping, inner_mm=self.inner_mm, friction=self.collider_friction)
        done, switch = [], None
        for garment in garments:
            # a kept cloth keeps the pin it actually uses (any name, or none) and its weights
            keep_pin = (self.keep_cloth_settings
                        and garment.modifiers.get(cloth_setup.CLOTH_MODIFIER) is not None)
            if keep_pin:
                pin = {"pinned": "kept", "faded": "kept"}
            else:
                pin, error = cloth_setup.waistband_pin(
                    garment, band_mm=self.band_mm, hard_mm=self.feather_mm)
                if error:
                    done.append("%s: %s" % (garment.name, error))
                    continue
            report, error = cloth_setup.add_cloth(
                garment, collision_quality=self.collision_quality,
                self_collision=self.self_collision, keep_existing=self.keep_cloth_settings)
            if error:
                done.append("%s: %s" % (garment.name, error))
                continue
            if self.only_these:
                _limited, error = cloth_setup.limit_colliders(garment, colliders)
            else:
                _limited, error = cloth_setup.release_colliders(garment)
            if error:
                done.append("%s: %s" % (garment.name, error))
                continue
            state, _error = cloth_setup.collision_state(garment)
            if state is not None:
                done.append(tr_format(
                    "%(name)s collides with %(what)s, quality %(quality)d",
                    name=garment.name,
                    what=(", ".join(m["name"] for m in state["members"])
                          if state["collection"] is not None
                          else tr_format("every collider in the scene")),
                    quality=int(state["quality"])))
            prefix = 'modifiers["%s"].show_' % cloth_setup.CLOTH_MODIFIER
            driven = [d for d in (garment.animation_data.drivers if garment.animation_data else ())
                      if d.data_path.startswith(prefix)]
            if self.keep_cloth_settings and driven:
                # a switch that is already wired (on MIK a three-way property) is the garment's own; keep it
                targets = sorted({"%s%s" % (t.id.name if t.id else "?", t.data_path)
                                  for d in driven for v in d.driver.variables for t in v.targets})
                done.append(tr_format("%(name)s keeps its switch %(what)s", name=garment.name,
                                      what=", ".join(targets)))
            else:
                switch, error = cloth_setup.add_switch(garment, armature)
                if error:
                    done.append("%s: %s" % (garment.name, error))
                    continue
            done.append("%s (%s pinned, %s faded)"
                        % (garment.name, pin["pinned"], pin["faded"]))
        if switch is not None:
            _ascii_report(self, {"INFO"},
                          "%s. The switch is %s[%r]; it ships at 0, which is the "
                          "skinned result."
                          % ("; ".join(done), switch.get("on_rig", "?"),
                             cloth_setup.SWITCH_PROPERTY))
        else:
            _ascii_report(self, {"INFO"}, "; ".join(done) + ".")
        return {"FINISHED"}


class SRS_OT_hygiene_audit(bpy.types.Operator):
    bl_idname = "srs.hygiene_audit"
    bl_label = "Audit Rig Hygiene"
    bl_description = (
        "Find what the deformation gates cannot see: channels that are offered to the animator but "
        "move nothing, controls with no ceiling that push teeth or tongue through the skin, geometry "
        "bound to a bone that does not deform, geometry bound to nothing, and drivers that do not "
        "evaluate. Every one of these was found on a rig that passed every weight and surface gate"
    )
    bl_options = set()

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face, family = _face_family(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        meshes = [face] + [obj for obj in family.values() if obj is not None]
        # Every chain the costume and hair work builds is named hair_* or srs_*,
        # none of which starts with "c_" or carries a facial token -- so the
        # sweep was blind to all of it, and to every mesh those chains deform.
        generated = sorted({bone.name for bone in armature.pose.bones
                            if bone.name.startswith(("hair_", "srs_"))
                            and bone.bone.use_deform})
        seen = {obj.name for obj in meshes if obj is not None}
        driven_groups = set(generated)
        for obj in bpy.data.objects:
            if obj.type != "MESH" or obj.name in seen:
                continue
            if not any(m.type == "ARMATURE" and m.object is armature
                       for m in obj.modifiers):
                continue
            if any(g.name in driven_groups for g in obj.vertex_groups):
                meshes.append(obj)
                seen.add(obj.name)
        controllers = sorted({bone.name for bone in armature.pose.bones
                              if bone.name.startswith("c_")
                              and not bone.name.endswith(("_offset.l", "_offset.r",
                                                          "_offset.x", "_retain.l",
                                                          "_retain.r", "_retain.x"))
                              and any(part in bone.name
                                      for part in ("eyelid", "eyebrow", "nose",
                                                   "cheek", "chin", "lips",
                                                   "teeth", "tong", "jaw", "eye",
                                                   "neck"))} | set(generated))
        sweep, error = rig_hygiene.channel_sweep(armature, controllers, meshes)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        invalid, _e = rig_hygiene.invalid_drivers(armature)
        nondeform, _e = rig_hygiene.nondeform_groups(
            armature, [obj for obj in bpy.data.objects if obj.type == "MESH"])
        loose = [obj for obj in bpy.data.objects
                 if obj.type == "MESH" and obj.parent is None
                 and not any(m.type == "ARMATURE" for m in obj.modifiers)
                 and not obj.vertex_groups]
        skin, _e = rig_hygiene.outer_skin_polygons(face)
        breaches = []
        for key in ("teeth_upper", "teeth_lower", "tongue"):
            part = family.get(key)
            if part is None or skin is None:
                continue
            report, error = rig_hygiene.rest_penetration(part, face, skin["outer"])
            if not error and (report["pairs"] or (report["nearest_mm"] or 1.0) < 0.5):
                breaches.append("%s %d pairs at %.4fmm"
                                % (key, report["pairs"], report["nearest_mm"]))
        _ascii_report(
            self, {"INFO"},
            "%d channels swept: %d move nothing and are unlocked, %d are inert "
            "because an option is off. %d drivers do not evaluate. %d meshes are "
            "bound to a non-deforming bone, %d to nothing at all. At rest: %s."
            % (sweep["channels"], sweep["dead_count"],
               len(sweep["inert_by_option"]), invalid["count"],
               nondeform["count"], len(loose),
               _report_list(breaches, "; ") or "no interpenetration"))
        return {"FINISHED"}


class SRS_OT_hygiene_lock_dead(bpy.types.Operator):
    bl_idname = "srs.hygiene_lock_dead"
    bl_label = "Lock Dead Channels"
    bl_description = (
        "Lock every channel that was measured to move nothing. A rig that offers a dead channel "
        "teaches the animator that it works: all three scale channels on the eyelid controls move "
        "nothing at all, because nothing downstream copies scale. Channels that are inert only "
        "because an Auto-Rig Pro option is off are reported and left alone -- the option is yours"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face, family = _face_family(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        meshes = [face] + [obj for obj in family.values() if obj is not None]
        controllers = sorted({bone.name for bone in armature.pose.bones
                              if bone.name.startswith("c_")
                              and not bone.name.endswith(("_offset.l", "_offset.r",
                                                          "_offset.x", "_retain.l",
                                                          "_retain.r", "_retain.x"))})
        sweep, error = rig_hygiene.channel_sweep(armature, controllers, meshes)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        locked, error = rig_hygiene.lock_channels(
            armature, [(r["bone"], r["kind"], r["axis"]) for r in sweep["dead"]])
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self, {"INFO"},
            "Locked %d dead channels. %d more are inert because an option is off "
            "and were left unlocked. Auto-Rig Pro's match-to-rig clears lock "
            "flags, so run this again after regenerating."
            % (locked["locked_count"], len(sweep["inert_by_option"])))
        return {"FINISHED"}


class SRS_OT_hygiene_clamp_face(bpy.types.Operator):
    bl_idname = "srs.hygiene_clamp_face"
    bl_label = "Clamp Jaw, Teeth and Tongue"
    bl_description = (
        "Give the jaw, the teeth rows and the tongue the ceiling they have no other way of getting. "
        "The travel is found by walking each channel out until the part stops clearing the skin, and "
        "the limit is set with a real gap, not at the last pose that happened not to intersect. It "
        "also bounds the Auto-Rig Pro driver that reads the jaw channel directly, because a Limit "
        "Location constraint cannot stop a driver: past the ceiling the jaw stopped while the "
        "lip-retain kept pulling the mouth in"
    )
    bl_options = {'UNDO'}

    gap: bpy.props.FloatProperty(
        name="Clearance",
        description=(
            "How much room in millimetres has to be left between the part and the skin at the "
            "ceiling. Counting intersections alone found a pose with 0.0005mm of clearance, which "
            "reported a breach or no breach depending on floating-point noise"
        ),
        default=0.15, min=0.0, soft_max=2.0,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face, family = _face_family(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        skin, error = rig_hygiene.outer_skin_polygons(face)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        teeth_low = family.get("teeth_lower")
        teeth_up = family.get("teeth_upper")
        tongue = family.get("tongue")
        watched = [(part, None) for part in (teeth_low, teeth_up, tongue)
                   if part is not None]
        if not watched:
            _ascii_report(self, {"WARNING"},
                          "No teeth or tongue mesh was found beside the face, so "
                          "there is nothing to clamp against.")
            return {"CANCELLED"}
        done = []
        jaw = "c_jawbone.x"
        def set_aside(bone):
            """Earlier limits must not stop the walk, but stay if no new limit comes of it."""
            found = [c for c in armature.pose.bones[bone].constraints if c.name.startswith("SRS ")]
            for constraint in found:
                constraint.mute = True
            return found

        def settle(bone, found, replaced):
            for constraint in found:
                if replaced:
                    armature.pose.bones[bone].constraints.remove(constraint)
                else:
                    constraint.mute = False

        if armature.pose.bones.get(jaw) is not None:
            earlier = set_aside(jaw)
            scan, error = rig_hygiene.scan_travel(
                armature, jaw, "location", 2, None, face, skin["outer"],
                limit=40.0, step=0.5, meshes=watched, min_gap_mm=self.gap)
            ceiling = 0.0 if error else float(int(scan["safe_mm"]))
            settle(jaw, earlier, ceiling >= 1.0)
            if ceiling < 1.0:
                # a ceiling of nothing is a jaw that cannot open: say so and change nothing
                done.append("%s %s (only %.2fmm of clearance exists)"
                            % (jaw, "keeps its earlier limit" if earlier else "left free",
                               0.0 if error else scan["safe_mm"]))
            else:
                rig_hygiene.clamp_controller(armature, jaw,
                                             location={2: (0.0, ceiling)})
                rig_hygiene.clamp_driver_reads(armature, jaw, 2, 0.0, ceiling)
                done.append("jaw to %.0fmm" % ceiling)
        for bone, part in (("c_tong_01.x", tongue), ("c_tong_02.x", tongue),
                           ("c_tong_03.x", tongue),
                           ("c_teeth_bot_master.x", teeth_low),
                           ("c_teeth_bot.x", teeth_low),
                           ("c_teeth_bot.l", teeth_low),
                           ("c_teeth_bot.r", teeth_low),
                           ("c_teeth_top_master.x", teeth_up),
                           ("c_teeth_top.x", teeth_up),
                           ("c_teeth_top.l", teeth_up),
                           ("c_teeth_top.r", teeth_up)):
            if part is None or armature.pose.bones.get(bone) is None:
                continue
            earlier = set_aside(bone)
            scan, error = rig_hygiene.scan_travel(
                armature, bone, "location", 1, part, face, skin["outer"],
                limit=12.0 if "tong" in bone else 5.0, step=0.25,
                min_gap_mm=self.gap)
            settle(bone, earlier, not (error or scan["safe_mm"] < 0.5))
            if error or scan["safe_mm"] < 0.5:
                done.append("%s %s (only %.2fmm of clearance exists)"
                            % (bone, "keeps its earlier limit" if earlier else "left free",
                               0.0 if error else scan["safe_mm"]))
                continue
            rig_hygiene.clamp_controller(
                armature, bone,
                location={1: (-scan["safe_mm"], scan["safe_mm"])})
            done.append("%s to +/-%.2fmm" % (bone, scan["safe_mm"]))
        _ascii_report(self, {"INFO"}, "Clamped: %s." % "; ".join(done))
        return {"FINISHED"}


class SRS_OT_hygiene_bind_loose(bpy.types.Operator):
    bl_idname = "srs.hygiene_bind_loose"
    bl_label = "Bind What Is Not Bound"
    bl_description = (
        "Repair geometry that only looks bound. A vertex group naming a control bone is skinning "
        "that the armature modifier ignores, and it looks right from every angle: five hair meshes "
        "carried exactly one group, c_head.x, whose bone does not deform, so a head turn left the "
        "hair behind and pushed the skull through the cap. Props with no parent at all are "
        "bone-parented to the head or the neck"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        meshes = [obj for obj in bpy.data.objects if obj.type == "MESH"]
        report, error = rig_hygiene.nondeform_groups(armature, meshes)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        retargeted = []
        for row in report["rows"]:
            if row["severity"] != "bound to nothing":
                continue
            mesh = bpy.data.objects.get(row["mesh"])
            for name in row["groups"]:
                suggestion = row["suggest"].get(name) or ""
                if not suggestion:
                    continue
                _r, error = rig_hygiene.retarget_group(mesh, name, suggestion)
                if not error:
                    retargeted.append("%s: %s -> %s"
                                      % (mesh.name, name, suggestion))
        bound = []
        for obj in meshes:
            if (obj.parent is not None or obj.vertex_groups
                    or any(m.type == "ARMATURE" for m in obj.modifiers)):
                continue
            lowered = obj.name.lower()
            if not any(word in lowered for word in ("head", "neck", "pierce",
                                                    "ear", "hair")):
                continue
            bone = "neck.x" if "neck" in lowered else "head.x"
            if armature.data.bones.get(bone) is None:
                continue
            _r, error = rig_hygiene.bind_rigid(obj, armature, bone)
            if not error:
                bound.append("%s -> %s" % (obj.name, bone))
        if not retargeted and not bound:
            _ascii_report(self, {"INFO"},
                          "Nothing was bound to a dead bone and nothing in the "
                          "head or neck is unparented.")
            return {"FINISHED"}
        _ascii_report(self, {"INFO"},
                      "Retargeted %d group(s) and bone-parented %d prop(s): %s"
                      % (len(retargeted), len(bound),
                         "; ".join(retargeted + bound)))
        return {"FINISHED"}


class SRS_OT_hygiene_repair_drivers(bpy.types.Operator):
    bl_idname = "srs.hygiene_repair_drivers"
    bl_label = "Repair Dead Drivers"
    bl_description = (
        "Add the custom properties that invalid drivers are reading, at zero, which preserves "
        "today's behaviour exactly. Two lip offsets read a property that does not exist, so those "
        "two alone ignored the jaw-retain slider -- invisible while the slider sits at zero and "
        "wrong the moment anyone touches it"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        before, _e = rig_hygiene.invalid_drivers(armature)
        report, error = rig_hygiene.repair_invalid_drivers(armature, value=0.0)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"},
                      "%d driver(s) did not evaluate; added %d property(ies), "
                      "%d still invalid."
                      % (before["count"], report["added_count"],
                         len(report["still_invalid"])))
        return {"FINISHED"}


class SRS_OT_corrective_lid(bpy.types.Operator):
    bl_idname = "srs.corrective_lid"
    bl_label = "Correct Closed Eyelid"
    bl_description = (
        "Build a shape key that takes the faceting out of a closed eyelid and drive it from the lid "
        "control. A fold is not something weights can express -- smoothing the lid weights stopped "
        "helping well before the surface was clean -- so the remainder is corrected with a shape "
        "key, which is also what Auto-Rig Pro's own blink pose is for"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face = _eye_face(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        pull = float(getattr(settings, "lid_pull_mm", 16.0))
        made = []
        for side in (".l", ".r"):
            region, error = face_regions.lid_region(face, armature, side)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            name = "SRS lid close" + side
            corrective.remove_corrective(face, name)
            report, error = corrective.build_corrective(
                face, armature,
                [("c_eyelid_top" + side, (0.0, 0.0, -pull)),
                 ("c_eyelid_bot" + side, (0.0, 0.0, pull))],
                region["vertices"], name, factor=0.5, repeat=4,
                driver={"bone": "c_eyelid_top" + side,
                        "transform_type": "LOC_Z", "full_mm": -pull})
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            made.append("%s (%d verts)" % (name, report["vertices_moved"]))
        _ascii_report(self, {"INFO"},
                      "Built %s. Both keys are driven by their own lid control."
                      % _report_list(made, "; "))
        return {"FINISHED"}


class SRS_OT_corrective_lip(bpy.types.Operator):
    bl_idname = "srs.corrective_lip"
    bl_label = "Hold Upper Lip"
    bl_description = (
        "Build a shape key that keeps the upper lip from being dragged down with the jaw, fading "
        "out towards the lip crevice so the two lips still meet. Holding it without that fade cuts "
        "the unwanted follow but tears the mouth open at the join"
    )
    bl_options = {'UNDO'}

    strength: bpy.props.FloatProperty(
        name="Hold",
        description=(
            "How much of the unwanted follow to take back. One pins the lip entirely, which reads "
            "as wrong as letting it drop"
        ),
        default=0.75, min=0.0, max=1.0,
    )
    feather: bpy.props.IntProperty(
        name="Feather",
        description=(
            "How many edges the correction fades over, counted from where the upper lip meets the "
            "lower one"
        ),
        default=4, min=1, max=16,
    )
    jaw_mm: bpy.props.FloatProperty(
        name="Jaw Open",
        description="How far the jaw control is dropped when the correction is measured",
        default=10.0, min=1.0, soft_max=40.0,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        face = _eye_face(context, settings)
        if armature is None or face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the rig and the face mesh first.")
            return {"CANCELLED"}
        teeth_up = bpy.data.objects.get(face.name + "_teeth_upper")
        teeth_low = bpy.data.objects.get(face.name + "_teeth_lower")
        lips, error = face_regions.lip_regions(face, teeth_upper=teeth_up,
                                               teeth_lower=teeth_low)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        upper = set(lips["upper"])
        lower = set(lips["lower"])
        seed = sorted({a for edge in face.data.edges
                       for a, b in (tuple(edge.vertices),
                                    tuple(reversed(edge.vertices)))
                       if a in upper and b in lower})
        if not seed:
            _ascii_report(self, {"WARNING"},
                          "The two lips do not touch, so there is nothing to "
                          "fade the correction against.")
            return {"CANCELLED"}
        name = "SRS upper lip hold"
        corrective.remove_corrective(face, name)
        falloff = corrective.graph_falloff(face, sorted(upper), seed,
                                           hops=int(self.feather))
        report, error = corrective.build_corrective(
            face, armature, [("c_jawbone.x", (0.0, 0.0, float(self.jaw_mm)))],
            sorted(upper), name, mode="HOLD", strength=float(self.strength),
            strength_map=falloff,
            driver={"bone": "c_jawbone.x", "transform_type": "LOC_Z",
                    "full_mm": float(self.jaw_mm)})
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self, {"INFO"},
            "Held %d upper-lip vertices at %.2f, faded over %d edges from the "
            "crevice (%d seed vertices)."
            % (report["vertices_moved"], self.strength, self.feather, len(seed)))
        return {"FINISHED"}


class SRS_OT_face_weight_audit(bpy.types.Operator):
    bl_idname = "srs.face_weight_audit"
    bl_label = "Audit Face Weights"
    bl_description = (
        "Answer \"the weights are loose\" with numbers instead of impressions: per-vertex weight "
        "summed over the MAIN rig's bones only, the influence-count spread, how far each bone's "
        "influence reaches against its own length, and the left-to-right difference. The additive "
        "rig's own blocker bones are excluded, because one of them holds weight on every vertex of "
        "the face and including it reports the whole mesh as broken"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = _eye_face(context, settings) or context.active_object
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        if mesh is None or mesh.type != "MESH":
            _ascii_report(self, {"WARNING"},
                          "Choose the face mesh, or make a mesh active.")
            return {"CANCELLED"}
        sums, error = face_regions.rig_weight_sums(mesh, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        payload = {"mesh": mesh.name, "armature": armature.name, "sums": sums}
        reach = []
        for group in mesh.vertex_groups:
            row, row_error = face_regions.bone_reach(mesh, armature, group.name)
            if row_error or not row["strong"]:
                continue
            reach.append(row)
        reach.sort(key=lambda r: -(r["reach_over_length"] or 0.0))
        payload["reach_worst"] = reach[:15]
        mirror, mirror_error = face_regions.mirror_map(mesh)
        payload["mirror"] = ({k: v for k, v in mirror.items() if k != "pairs"}
                             if not mirror_error else mirror_error)
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        worst = reach[0] if reach else None
        _ascii_report(
            self,
            {"WARNING"} if sums["within_0_001_of_one"] < sums["vertices"]
            else {"INFO"},
            "%d of %d vertices sum to 1.000; %d carry over four influences "
            "(max %d)%s."
            % (sums["within_0_001_of_one"], sums["vertices"],
               sums["over_four_influences"], sums["max_influences"],
               ("; worst reach %s at %sx its length"
                % (worst["bone"], worst["reach_over_length"])) if worst else ""),
        )
        return {"FINISHED"}


class SRS_OT_lid_range_clamp(bpy.types.Operator):
    bl_idname = "srs.lid_range_clamp"
    bl_label = "Clamp Eyelid Range"
    bl_description = (
        "Stop the eyelid controls running past closed. Auto-Rig Pro maps their travel to lid "
        "rotation without ever saturating, so dragging one to the end of its reach drives the two "
        "margins through each other and the shape breaks. This finds where the eye actually shuts, "
        "ends the mapping there, and leaves the feel over the useful travel unchanged"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        face = _eye_face(context, settings)
        pull = float(getattr(settings, "lid_pull_mm", 16.0))
        found = None
        if face is not None:
            low, high = 2.0, 24.0
            for _ in range(12):
                middle = 0.5 * (low + high)
                aperture, error = eye_setup.measure_aperture(
                    armature, face, pull_mm=middle, steps=2)
                if error:
                    break
                if (aperture.get("worst_closed_pct") or 0.0) >= 100.0:
                    high = middle
                else:
                    low = middle
                if high - low <= 0.25:
                    break
            found = round(high, 2)
        report, error = eye_setup.tune_lid_range(
            armature, close_at_mm=found if found else pull)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self,
            {"INFO"},
            "Clamped %d lid mapping(s) at %.2fmm%s. Auto-Rig Pro rewrites this on "
            "Match to Rig, so run it again afterwards."
            % (len(report["constraints"]), report["close_at_mm"],
               " (measured)" if found else " (from the panel value)"),
        )
        return {"FINISHED"}


class SRS_OT_blink_pose_prepare(bpy.types.Operator):
    bl_idname = "srs.blink_pose_prepare"
    bl_label = "Prepare Blink Pose"
    bl_description = (
        "Get the rig ready for Auto-Rig Pro's Add Blink Pose, which is its own remedy when the "
        "default lid rotation does not give the right closed shape. It refuses while the lid pivot "
        "is wrong or the eye cannot actually reach a closed pose, then puts the rig in Pose Mode "
        "with the lid controller selected and held closed, and tells you which ARP button to press"
    )
    bl_options = {'UNDO'}

    lower: bpy.props.BoolProperty(
        name="Lower Lid",
        description="Prepare the lower lid instead of the upper one",
        default=False,
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        face = _eye_face(context, settings)
        report, error = eye_setup.blink_pose_readiness(
            armature, face, side=".l", level="bot" if self.lower else "top",
            pull_mm=float(getattr(settings, "lid_pull_mm", 16.0)))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, report["next"])
        return {"FINISHED"}


class SRS_OT_lid_pivot_audit(bpy.types.Operator):
    bl_idname = "srs.lid_pivot_audit"
    bl_label = "Audit Eyelid Pivot"
    bl_description = (
        "Measure how far each eyelid's rotation pivot sits from the eye pivot, and how far the eye "
        "actually shuts when the top-lid control is pulled. Auto-Rig Pro places the eyelid base bones "
        "on the eye pivot and the bones that actually rotate somewhere else, and a lid that rotates "
        "off-centre swings away from the eyeball instead of closing over it"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        payload, error = eye_setup.lid_pivot_report(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        face = _eye_face(context, settings)
        if face is not None:
            aperture, aperture_error = eye_setup.measure_aperture(
                armature, face, pull_mm=float(getattr(settings, "lid_pull_mm", 16.0)))
            payload["aperture"] = aperture if not aperture_error else aperture_error
        else:
            payload["aperture"] = ("Choose the face mesh to measure how far the eye "
                                   "actually shuts.")
        payload["armature"] = armature.name
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        closed = ""
        if isinstance(payload.get("aperture"), dict):
            closed = ", eye shuts %.1f%%" % (payload["aperture"]
                                             .get("worst_closed_pct") or 0.0)
        _ascii_report(
            self,
            {"WARNING"} if payload.get("needs_fix") else {"INFO"},
            "Lid pivot is %.3fmm off the eye pivot%s."
            % (payload.get("worst_offset_mm") or 0.0, closed),
        )
        return {"FINISHED"}


class SRS_OT_lid_pivot_fix(bpy.types.Operator):
    bl_idname = "srs.lid_pivot_fix"
    bl_label = "Correct Eyelid Pivot"
    bl_description = (
        "Move each eyelid's rotating bone onto the eye pivot so the lid sweeps across the eyeball "
        "instead of swinging away from it. No weight changes, because those bones do not deform. It "
        "is a patch, not a cure: Auto-Rig Pro regenerates them from its reference bones, so Match to "
        "Rig or a facial re-setup will bring the fault back"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        face = _eye_face(context, settings)
        pull = float(getattr(settings, "lid_pull_mm", 16.0))
        before = None
        if face is not None:
            before, _ = eye_setup.measure_aperture(armature, face, pull_mm=pull)
        report, error = eye_setup.fix_lid_pivot(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if not report.get("moved"):
            _ascii_report(self, {"INFO"},
                          "Every lid pivot already sits on the eye pivot; "
                          "nothing was moved.")
            return {"FINISHED"}
        after = None
        if face is not None:
            after, _ = eye_setup.measure_aperture(armature, face, pull_mm=pull)
        gain = ""
        if isinstance(before, dict) and isinstance(after, dict):
            gain = " The eye now shuts %.1f%% where it shut %.1f%%." % (
                after.get("worst_closed_pct") or 0.0,
                before.get("worst_closed_pct") or 0.0)
        _ascii_report(
            self,
            {"INFO"},
            "Moved %d lid bone(s) by up to %.3fmm onto the eye pivot.%s"
            % (len(report["moved"]), report["worst_offset_before_mm"], gain),
        )
        return {"FINISHED"}


class SRS_OT_eye_bind(bpy.types.Operator):
    bl_idname = "srs.eye_bind"
    bl_label = "Bind Eyeballs"
    bl_description = (
        "Bind each eyeball in two parts: the pupil to its own eye control so it follows the look-at "
        "target, and the outer rim to the face's eye socket so it travels with the lid instead. An "
        "eyeball bound rigidly to one bone drags its rim out of the socket the moment the character "
        "looks sideways"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        eye_l, eye_r, error = eye_setup.resolve_eye_objects(context, settings)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        face = _eye_face(context, settings)
        if face is None:
            _ascii_report(self, {"WARNING"},
                          "Choose the face mesh: the eyeball rim is pinned to its "
                          "eye socket, not to a bone.")
            return {"CANCELLED"}
        checks, error = bind_common.preflight(
            armature, meshes=[m for m in (eye_l, eye_r, face) if m],
            require_facial=True)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        report, error = eye_setup.bind_eyes(armature, eye_l, eye_r, donor=face)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        eyes = report.get("eyes", [])
        _ascii_report(
            self,
            {"INFO"},
            "%d eyeball(s) bound: %s." % (
                len(eyes),
                _report_list(("%s pupil %d to %s, rim %d to the face"
                              % (e["object"], e["gaze_vertices"], e["gaze_bone"],
                                 e["rim_vertices"]) for e in eyes), "; ")),
        )
        return {"FINISHED"}


class SRS_OT_eye_verify(bpy.types.Operator):
    bl_idname = "srs.eye_verify"
    bl_label = "Verify Eyeballs"
    bl_description = (
        "Pose the look-at control and measure. The pupil has to move and the seam with the face has "
        "to hold, and nothing at rest distinguishes a correct bind from an eye weighted to a bone "
        "nothing drives"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        eye_l, eye_r, error = eye_setup.resolve_eye_objects(context, settings)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        face = _eye_face(context, settings)
        nudge = float(getattr(settings, "eye_verify_offset_mm", 40.0))
        payload, error = eye_setup.verify_eyes(
            armature, eye_l, eye_r, donor=face,
            offset_mm=(nudge, 0.0, nudge * 0.5))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        payload["armature"] = armature.name
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        issues = payload.get("issues", [])
        moved = _report_list((
            "%s pupil %.3fmm seam %+.4fmm"
            % (r["object"], r.get("gaze_moved_mm") or 0.0,
               (r.get("seam") or {}).get("change_max_mm", 0.0))
            for r in payload.get("eyes", [])), ", ")
        _ascii_report(self, {"WARNING"} if issues else {"INFO"},
                      "%s%s" % (moved, ("; %d issue(s)" % len(issues))
                                if issues else "; clean"))
        return {"FINISHED"}


class SRS_OT_eye_dispose_temp(bpy.types.Operator):
    bl_idname = "srs.eye_dispose_temp"
    bl_label = "Remove Placeholder Eye Rig"
    bl_description = (
        "Delete a throwaway eye armature once the eyeballs are bound to the real rig, and drop its "
        "collection if that leaves it empty. It refuses while anything still parents to it or "
        "deforms through it, because removing it first leaves the eyes unrigged and still sitting "
        "in exactly the right place at rest"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        settings = _settings(context)
        candidate = context.active_object
        if candidate is None or candidate.type != "ARMATURE":
            _ascii_report(self, {"WARNING"},
                          "Make the placeholder armature the active object first.")
            return {"CANCELLED"}
        keeper = settings.target_armature or likely_armature(context)
        if keeper is not None and candidate == keeper:
            _ascii_report(self, {"WARNING"},
                          "That is the rig itself, not a placeholder.")
            return {"CANCELLED"}
        report, error = eye_setup.dispose_temporary_armature(candidate)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        emptied = report.get("collections_removed", [])
        _ascii_report(
            self, {"INFO"},
            "Removed %s%s." % (report["removed"],
                               (" and the empty collection %s" % ", ".join(emptied))
                               if emptied else ""))
        return {"FINISHED"}


class SRS_OT_eye_audit(bpy.types.Operator):
    bl_idname = "srs.eye_audit"
    bl_label = "Audit Eye Rig"
    bl_description = (
        "Check the generated eye rig: pivot accuracy against the eyeball objects, whether the eye target ended "
        "up behind the face, degenerate reference bones, and leftover vertex groups or empty UV projectors"
    )

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        if armature is None:
            _ascii_report(self, {"WARNING"}, "No reference armature was found.")
            return {"CANCELLED"}
        eye_l, eye_r, error = eye_setup.resolve_eye_objects(context, settings)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        issues = eye_setup.audit_eye_rig(armature, eye_l, eye_r)
        payload = {"armature": armature.name, "issue_count": len(issues), "issues": issues}
        preferences = _prefs(context)
        name = str(
            getattr(preferences, "report_text_name", "Smart Rig Suite Report")
            if preferences
            else "Smart Rig Suite Report"
        )
        text_block_write(name, json.dumps(payload, ensure_ascii=False, indent=2))
        settings.last_report_text = name
        if issues:
            _ascii_report(self, {"WARNING"}, f"Eye rig audit found {len(issues)} issue(s).")
        else:
            _ascii_report(self, {"INFO"}, "Eye rig audit found no issues.")
        return {"FINISHED"}


class SRS_OT_band_width_lock(bpy.types.Operator):
    bl_idname = "srs.band_width_lock"
    bl_label = "Keep Band Width"
    bl_description = (
        "Give every cross row of the selected bands the row's average weights and deform them with a "
        "dual-quaternion Armature modifier, so a denim-like band keeps its width at the elbow. Select one "
        "vertex of each band in Edit Mode first. It does not stop the band from touching the sleeve"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        obj = context.active_object
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        sections, error = band_width.selected_band_sections(
            obj, axis=settings.band_uv_axis, min_width=settings.band_min_width_mm / 1000.0)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        hard = []
        if settings.band_lock_hard:
            hard = band_width.material_island_sections(obj, match=str(settings.rigid_material or "metal"))
        report, error = band_width.lock_width(obj, sections + hard)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(
            self, {"INFO"},
            f"{len(sections)} rows and {len(hard)} hard islands locked on {report['vertices']} vertices "
            f"(rest error {report['rest_width']['maximum_error_percent']:.4f}%).",
        )
        return {"FINISHED"}


class SRS_OT_band_mirror(bpy.types.Operator):
    bl_idname = "srs.band_mirror"
    bl_label = "Mirror Band Weights"
    bl_description = (
        "Copy each row of the selected bands from one side onto its mirror row on the other side, then keep the "
        "width again. Rows are matched by their centre reflected across X = 0, so the two sides need not be "
        "vertex-symmetric. Select one vertex of the band on each side in Edit Mode first. Mirror bones that do "
        "not exist are reported, not made: add them first with Add Adjust Bones"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        settings = _settings(context)
        obj = context.active_object
        if obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        sections, error = band_width.selected_band_sections(
            obj, axis=settings.band_uv_axis, min_width=settings.band_min_width_mm / 1000.0)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        hard = []
        if settings.band_lock_hard:
            seeds = [i for s in sections for i in s["ids"]]
            hard = band_width.material_island_sections(obj, match=str(settings.rigid_material or "metal"), ids=seeds)
        before = band_width.neutral_positions(obj)
        mirrored, error = band_width.mirror_sections(obj, sections + hard, source=settings.band_mirror_source)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        report, error = band_width.lock_width(obj, sections + hard, rest=before)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%d rows mirrored (%d without a partner), width kept on %d vertices." % (
            mirrored["mirrored"], mirrored["unmatched"], report["vertices"]))
        return {"FINISHED"}


class SRS_OT_ikfk_switch(bpy.types.Operator):
    bl_idname = "srs.ikfk_switch"
    bl_label = "Switch IK/FK"
    bl_description = (
        "Switch the selected arms and legs between IK and FK with Auto-Rig Pro's own snap, keeping the pose. "
        "The switch is keyed as a step, so the limb never blends IK and FK between keys, and a fully straight "
        "limb keeps its twist"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and context.mode == "POSE"

    def execute(self, context):
        armature = context.active_object
        settings = _settings(context)
        limbs = []
        for pb in context.selected_pose_bones or ():
            limb, side = ikfk.limb_of(pb.name)
            if limb and (limb, side) not in limbs:
                limbs.append((limb, side))
        if not limbs:
            _ascii_report(self, {"WARNING"}, "Select an arm or leg controller.")
            return {"CANCELLED"}
        done, straight = 0, 0
        snap = None
        attempted = False
        try:
            # Snapshot can refuse a shared Action, a contributing NLA strip, or
            # an ambiguous slot. No state has changed at that point.
            snap = ikfk.snapshot(armature, context.scene.frame_current_final)
            for limb, side in limbs:
                attempted = True
                report, error = ikfk.switch(armature, limb, side, key=True if settings.ikfk_key_switch else None)
                if error:
                    if done:
                        ikfk.rollback(armature, snap)
                        context.view_layer.update()
                    _ascii_report(self, {"WARNING"}, error)
                    return {"CANCELLED"}
                done += 1
                straight += int(report["straight_fix"])
        except Exception as exc:
            safety_refusals = {
                "Shared Actions are not changed by IK/FK switch.",
                "Contributing NLA strips are not changed by IK/FK switch.",
                "Subframe IK/FK switching is rejected before mutation.",
                "An unambiguous Action slot is required before IK/FK switch.",
                "The assigned Action slot is ambiguous.",
                "NLA tweak mode is not supported by IK/FK switch.",
                "Scene unit scale_length must be finite and positive.",
            }
            warning = str(exc) if isinstance(exc, RuntimeError) and str(exc) in safety_refusals else (
                "IK/FK switch cancelled."
            )
            if snap is not None and attempted:
                try:
                    ikfk.rollback(armature, snap)
                    context.view_layer.update()
                except Exception:
                    warning += " Rollback failed."
            _ascii_report(self, {"WARNING"}, warning)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, f"{done} limbs switched ({straight} straight-limb fixes).")
        return {"FINISHED"}


class SRS_OT_ikfk_step_keys(bpy.types.Operator):
    bl_idname = "srs.ikfk_step_keys"
    bl_label = "Step the IK/FK Keys"
    bl_description = (
        "Make every existing IK/FK switch key a step. A smooth switch key blends IK and FK for every frame "
        "between two keys and drags the hand off its animation"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE"

    def execute(self, context):
        changed = ikfk.constant_switch_keys(context.active_object)
        _ascii_report(self, {"INFO"}, f"{changed} switch keys made steps.")
        return {"FINISHED"}


class SRS_OT_chain_group_build(bpy.types.Operator):
    bl_idname = "srs.chain_group_build"
    bl_label = "Pose Chains Together"
    bl_description = (
        "Add a swing and a curl control that pose every chain of the selected bones together. The curl is "
        "shared out by length, so chains with different bone counts bend the same way"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE" and context.mode == "POSE"

    def execute(self, context):
        armature = context.active_object
        prefixes = chain_group.chain_prefixes_from_bones([pb.name for pb in context.selected_pose_bones or ()])
        if not prefixes:
            _ascii_report(self, {"WARNING"}, "Select a bone of every chain to group.")
            return {"CANCELLED"}
        report, error = chain_group.build(armature, prefixes, key=_settings(context).group_key or "group")
        if armature.mode != "POSE":
            bpy.ops.object.mode_set(mode="POSE")
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, f"{len(report['chains'])} chains grouped under {report['controls'][0]}.")
        return {"FINISHED"}


class SRS_OT_chain_group_remove(bpy.types.Operator):
    bl_idname = "srs.chain_group_remove"
    bl_label = "Remove Chain Group"
    bl_description = "Remove the group's two controls and the constraints they drive"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "ARMATURE"

    def execute(self, context):
        armature = context.active_object
        mode = armature.mode
        removed = chain_group.remove(armature, _settings(context).group_key or "group")
        if mode == "POSE" and armature.mode != "POSE":
            bpy.ops.object.mode_set(mode="POSE")
        _ascii_report(self, {"INFO"}, f"{removed} group items removed.")
        return {"FINISHED"}


class SRS_OT_hygiene_drop_faint(bpy.types.Operator):
    bl_idname = "srs.hygiene_drop_faint"
    bl_label = "Drop Faint Modifier Weights"
    bl_description = (
        "On every selected mesh (or every bound mesh when none is selected), remove weights below 0.05 "
        "that are the only weights one Armature modifier sees on a vertex. Such a trace is divided by "
        "itself and moves the vertex 100 %, which tears the mesh"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == "MESH"]
        if not meshes:
            meshes = [o for o in bpy.data.objects if o.type == "MESH"
                      and sum(1 for m in o.modifiers if m.type == "ARMATURE") >= 2]
        total_v = total_w = touched = 0
        for mesh in meshes:
            report, _error = rig_hygiene.drop_faint_modifier_weights(mesh)
            if report["vertices"]:
                touched += 1
            total_v += report["vertices"]
            total_w += report["weights_removed"]
        _ascii_report(self, {"INFO"}, f"{total_w} faint weights removed from {total_v} vertices on {touched} meshes.")
        return {"FINISHED"}




class SRS_OT_hygiene_symmetrize_midline(bpy.types.Operator):
    bl_idname = "srs.hygiene_symmetrize_midline"
    bl_label = "Symmetrize Mirror Weights"
    bl_description = (
        "On the selected meshes, make the weights of every vertex pair that mirrors across x = 0 mirror images "
        "of each other. A centre that leans on one leg slides sideways when both legs move alike. Vertices "
        "without a mirror partner, such as a one-sided buckle, keep their weights"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == "MESH"]
        if not meshes:
            _ascii_report(self, {"WARNING"}, "Select the meshes to symmetrize.")
            return {"CANCELLED"}
        total = 0
        for mesh in meshes:
            report, _error = rig_hygiene.symmetrize_mirror(mesh)
            total += report["pairs_averaged"]
        _ascii_report(self, {"INFO"}, f"{total} left/right weight pairs averaged on {len(meshes)} meshes.")
        return {"FINISHED"}


class SRS_OT_hygiene_blend_midline(bpy.types.Operator):
    bl_idname = "srs.hygiene_blend_midline"
    bl_label = "Share Leg Weights Across The Centre"
    bl_description = (
        "On the selected meshes, inside the band around x = 0 split each left/right leg weight pair by "
        "position: half and half on the centre line, all on the near side at the band's edge. A skirt bound "
        "from the skin picks up one thigh between the legs, so its front slides sideways and tears"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        meshes = [o for o in context.selected_objects if o.type == "MESH"]
        if not meshes:
            _ascii_report(self, {"WARNING"}, "Select the meshes to symmetrize.")
            return {"CANCELLED"}
        band = float(_settings(context).midline_band_mm)
        total = 0
        for mesh in meshes:
            report, _error = rig_hygiene.blend_across_midline(mesh, band_mm=band)
            total += report["pairs_shared"]
        _ascii_report(self, {"INFO"}, f"{total} leg weight pairs shared across the centre on {len(meshes)} meshes.")
        return {"FINISHED"}


class SRS_OT_cloth_remove(bpy.types.Operator):
    bl_idname = "srs.cloth_remove"
    bl_label = "Remove Cloth"
    bl_description = (
        "Take the cloth solver and its switch drivers off the selected garments. The skin weights and the "
        "waistband pin group stay, so the garment goes back to the bone-driven result exactly"
    )
    bl_options = {'UNDO'}

    def execute(self, context):
        garments = [o for o in context.selected_objects if o.type == "MESH"]
        if not garments:
            _ascii_report(self, {"WARNING"}, "Select the garment and choose the rig first.")
            return {"CANCELLED"}
        removed = 0
        for garment in garments:
            report, _error = cloth_setup.remove_cloth(garment, keep_pin=True)
            removed += len((report or {}).get("removed", []))
        _ascii_report(self, {"INFO"}, f"Cloth removed from {removed} garments.")
        return {"FINISHED"}


class SRS_OT_skirt_mode_set(bpy.types.Operator):
    bl_idname = "srs.skirt_mode_set"
    bl_label = "Set Skirt Mode"
    bl_description = (
        "Put the skirt in one state of the rig's switch: bones or cloth for a skirt set up here, or any state "
        "of the character's own switch such as skirt_mode (0, 1, 2). The drivers that read it update at once"
    )
    bl_options = {'UNDO'}

    armature: bpy.props.StringProperty(
        name="Armature", default="", description="The rig by its object name. Empty uses the panel's rig",
    )
    property_name: bpy.props.StringProperty(
        name="Property", default="",
        description="The switch on the rig or its c_traj bone. Empty finds skirt_mode, then srs_skirt_cloth",
    )
    value: bpy.props.IntProperty(name="Value", default=0)

    def execute(self, context):
        rig = _rig(self, context)
        if rig is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        owner, name = cloth_setup.find_switch(rig, str(self.property_name or "").strip())
        if owner is None:
            _ascii_report(self, {"WARNING"}, f"{rig.name} has no skirt switch.")
            return {"CANCELLED"}
        report, error = cloth_setup.set_switch(owner, name, self.value)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        message = f"Skirt switch {name} set to {report['value']}."
        if report.get("cloth_from") is not None:
            message += f" Play from frame {report['cloth_from']} to simulate the cloth."
        _ascii_report(self, {"INFO"}, message)
        return {"FINISHED"}


class SRS_OT_jiggle_chain_include(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_include"
    bl_label = "Include Chains in Bake"
    bl_description = (
        "Put the chains of the selected bones into the jiggle bake, or leave them out of it. A chain that "
        "is left out keeps following its parent exactly and gets no keys, whichever bones are selected "
        "when Bake Jiggle runs"
    )
    bl_options = {'UNDO'}

    include: bpy.props.BoolProperty(name="Include", default=True)
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for root in roots.values():
            root[jiggle.CHAIN_BAKE] = bool(self.include)
        _ascii_report(self, {"INFO"}, "%d chains %s the bake."
                      % (len(roots), "put into" if self.include else "left out of"))
        return {"FINISHED"}


def _rig(operator, context, settings=None):
    """The armature an operator acts on: its ``armature`` argument by name, else the panel's rig."""
    name = str(getattr(operator, "armature", "") or "").strip()
    if name:
        obj = bpy.data.objects.get(name)
        return obj if obj is not None and obj.type == "ARMATURE" else None
    settings = settings or _settings(context)
    return settings.target_armature or likely_armature(context)


def _chain_roots(operator, context, armature):
    """The root pose bones the operator acts on: its ``chains`` keys, or else the
    chains of the selected / active bones. ``(roots, error)``."""
    roots = {}
    if operator.chains.strip():
        chains, missing = jiggle.chains_by_keys(armature, jiggle.parse_keys(operator.chains))
        if missing:
            return {}, tr_format("No chain under: %(keys)s.", keys=", ".join(missing))
        for bones in chains.values():
            root = armature.pose.bones.get(bones[0])
            if root is not None:
                roots[root.name] = root
        return roots, ""
    names = {b.name for b in context.selected_pose_bones or ()}
    active = getattr(context, "active_pose_bone", None)
    if active is not None:
        names.add(active.name)
    for name in names:
        root = jiggle.chain_root(armature, name)
        if root is not None:
            roots[root.name] = root
    if not roots:
        return {}, "Select a bone of each chain in Pose Mode."
    return roots, ""


class SRS_OT_jiggle_mute(bpy.types.Operator):
    bl_idname = "srs.jiggle_mute"
    bl_label = "Mute Baked Swing"
    bl_description = (
        "Switch a chain's baked swing off or back on without throwing it away. Off, the chain follows "
        "the body exactly and its keys stay in the action; on again, the same bake plays. Use Leave Out "
        "as well to keep the next bake from writing it"
    )
    bl_options = {'UNDO'}

    mute: bpy.props.BoolProperty(name="Mute", default=True)
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _bag, error = jiggle.rig_channelbag(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        # a linked Action cannot be muted (its curves are read-only): make it local first
        local_note, error = jiggle.ensure_local_action(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if local_note:
            _ascii_report(self, {"INFO"}, local_note)
        chains = jiggle.all_chains(armature)
        curves = 0
        for root in roots.values():
            bones = next((v for v in chains.values() if v and v[0] == root.name), [root.name])
            report, error = jiggle.mute_bake(armature, bones, self.mute)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            curves += report["curves"]
        context.view_layer.update()
        _ascii_report(self, {"INFO"}, "%d chains %s (%d curves)."
                      % (len(roots), "muted" if self.mute else "playing their bake", curves))
        return {"FINISHED"}


class SRS_OT_jiggle_chain_collide(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_collide"
    bl_label = "Chain Collision"
    bl_description = (
        "Decide for a chain whether its bake collides, whatever the panel says: On, Off, or back to "
        "following the panel. Stored on the chain's root bone"
    )
    bl_options = {'UNDO'}

    state: bpy.props.EnumProperty(
        name="Collision", default='DEFAULT',
        items=[('DEFAULT', "Panel", "Follow the panel"), ('ON', "On", "Always collide"), ('OFF', "Off", "Never collide")],
    )
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for root in roots.values():
            if self.state == 'DEFAULT':
                if "srs_jiggle_collide" in root.keys():
                    del root["srs_jiggle_collide"]
            else:
                root["srs_jiggle_collide"] = self.state == 'ON'
        _ascii_report(self, {"INFO"}, "%d chains: collision %s." % (len(roots), self.state.lower()))
        return {"FINISHED"}


class SRS_OT_jiggle_chain_gravity_rest(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_gravity_rest"
    bl_label = "Gravity from Rest Shape"
    bl_description = (
        "On: the chain's rest shape is the shape gravity already holds, so it keeps its shape and curl when "
        "still and follows gravity by how far its root has turned since rest. Off: gravity pulls straight "
        "down. Stored on the chain's root bone"
    )
    bl_options = {'UNDO'}

    state: bpy.props.EnumProperty(
        name="Gravity", default='ON',
        items=[('ON', "From Rest Shape", "Keep the rest shape; gravity acts as the root turns"),
               ('OFF', "Straight Down", "Gravity pulls straight down, the rest shape sags")],
    )
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for root in roots.values():
            root[jiggle.CHAIN_GRAVITY_REST] = self.state == 'ON'
        _ascii_report(self, {"INFO"}, "%d chains: gravity %s." % (
            len(roots), "from the rest shape" if self.state == 'ON' else "straight down"))
        return {"FINISHED"}


class SRS_OT_jiggle_chain_rest_clear(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_rest_clear"
    bl_label = "Keep Rest Pose Clear"
    bl_description = (
        "On: a capsule that holds the chain's links at rest is shrunk for this chain only, just enough to "
        "clear its rest pose, so the bake never fights the shape it was modelled in. Other chains keep the "
        "capsule at full size. Stored on the chain's root bone"
    )
    bl_options = {'UNDO'}

    state: bpy.props.EnumProperty(
        name="Capsules", default='ON',
        items=[('ON', "Keep Rest Clear", "Shrink capsules that hold the chain at rest, for this chain only"),
               ('OFF', "Full Size", "Every capsule at the size it was fitted")],
    )
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for root in roots.values():
            root[jiggle.CHAIN_REST_CLEAR] = self.state == 'ON'
        _ascii_report(self, {"INFO"}, "%d chains: capsules %s." % (
            len(roots), "keep the rest pose clear" if self.state == 'ON' else "at full size"))
        return {"FINISHED"}


class SRS_OT_jiggle_chain_thickness(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_thickness"
    bl_label = "Chain Thickness"
    bl_description = (
        "Measure: each link of the chain collides at the thickness of the mesh it carries (the vertices "
        "weighted to it, at rest), not as a thin line, so a thick hair bundle stays out of the body. Clear: back "
        "to the chain radius. Stored on the chain's root bone"
    )
    bl_options = {'UNDO'}

    action: bpy.props.EnumProperty(
        name="Thickness", default='MEASURE',
        items=[('MEASURE', "Measure", "Measure every link from its mesh and collide at that thickness"),
               ('CLEAR', "Clear", "Collide as a line at the chain radius again")],
    )
    percentile: bpy.props.FloatProperty(name="Percentile", default=0.9, min=0.5, max=1.0,
                                        description="Which share of the link's vertices lies inside the measured thickness")
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        every = jiggle.all_chains(armature)
        done, biggest = 0, 0.0
        for root in roots.values():
            if self.action == 'CLEAR':
                if jiggle.CHAIN_LINK_RADII in root.keys():
                    del root[jiggle.CHAIN_LINK_RADII]
                done += 1
                continue
            bones = next((v for v in every.values() if v and v[0] == root.name), None)
            if not bones:
                continue
            radii, report = jiggle.measure_link_radii(armature, bones, percentile=self.percentile)
            if not report["measured"]:
                _ascii_report(self, {"WARNING"}, "%s carries no mesh to measure." % root.name)
                return {"CANCELLED"}
            root[jiggle.CHAIN_LINK_RADII] = radii
            done += 1
            biggest = max(biggest, report["max_mm"])
        _ascii_report(self, {"INFO"}, "%d chains: thickness %s." % (
            done, "cleared" if self.action == 'CLEAR' else "measured, up to %.1f mm" % biggest))
        return {"FINISHED"}


class SRS_OT_jiggle_chain_entry_push(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_entry_push"
    bl_label = "Push Out on Entry"
    bl_description = (
        "On: a link that meets a capsule it was not touching the frame before is pushed straight back out, so a "
        "fast body cannot sink into the chain; contacts already under way still ease out slowly so they do not pop. "
        "Stored on the chain's root bone"
    )
    bl_options = {'UNDO'}

    state: bpy.props.EnumProperty(
        name="Entry", default='ON',
        items=[('ON', "Push on Entry", "New contacts are resolved at once"),
               ('OFF', "Ease Out", "Every contact eases out at the per-frame limit")],
    )
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for root in roots.values():
            root[jiggle.CHAIN_ENTRY_PUSH] = self.state == 'ON'
        _ascii_report(self, {"INFO"}, "%d chains: %s." % (
            len(roots), "pushed out on entry" if self.state == 'ON' else "every contact eases out"))
        return {"FINISHED"}


class SRS_OT_jiggle_swing_layer(bpy.types.Operator):
    bl_idname = "srs.jiggle_swing_layer"
    bl_label = "Swing Layer"
    bl_description = (
        "Give the chains a swing layer: the bake then writes onto hidden swing bones that add after "
        "each link's own rotation, so hand keys on the links are never overwritten, muted or turned "
        "into quaternions, and the swing plays only while the switch property on the rig holds the "
        "layer's value (0 = no simulation). Remove takes the layer and its keys off again"
    )
    bl_options = {'UNDO'}

    chains: bpy.props.StringProperty(
        name="Chains", default="",
        description=(
            "Chains by the key they were built under, separated by commas (patterns such as *tail* "
            "allowed). Empty uses the selected bones"
        ),
    )
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )
    switch: bpy.props.StringProperty(
        name="Switch", default="srs_sim_mode",
        description="Custom property on the rig that turns the swing on: it plays while the property equals Value",
    )
    value: bpy.props.IntProperty(name="Value", default=1, min=1, max=9,
                                 description="The switch value that plays this swing")
    remove: bpy.props.BoolProperty(name="Remove", default=False,
                                   description="Take the swing layer, its constraints and its keys off")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        roots, error = _chain_roots(self, context, armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        was_pose = armature.mode == "POSE"
        every = jiggle.all_chains(armature)
        done = 0
        for root in roots.values():
            bones = next((v for v in every.values() if v and v[0] == root.name), None)
            if not bones:
                continue
            if self.remove:
                report, error = jiggle.remove_swing_layer(armature, bones)
            else:
                report, error = jiggle.add_swing_layer(armature, bones, switch=str(self.switch).strip() or "srs_sim_mode",
                                                       value=int(self.value))
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
            key = next(k[1] for k, v in every.items() if v is bones)
            jiggle.release_chain_from_parts(armature, key, keep_switch=None if self.remove
                                            else (str(self.switch).strip() or "srs_sim_mode"))
            done += 1
        if was_pose and armature.mode != "POSE" and context.view_layer.objects.active is armature:
            bpy.ops.object.mode_set(mode="POSE")
        _ascii_report(self, {"INFO"}, "%d chains: swing layer %s." % (done, "removed" if self.remove else
                                                                      "on switch %s = %d" % (self.switch, self.value)))
        return {"FINISHED"}


def _part_names(armature, text):
    names = [p.strip() for p in str(text or "").split(",") if p.strip()]
    return names or sorted(jiggle.parts_motion(armature))


class SRS_OT_part_motion_register(bpy.types.Operator):
    bl_idname = "srs.part_motion_register"
    bl_label = "Register Part Motion"
    bl_description = (
        "Make a part switchable between simulation and hand animation by its name: its chains get a swing "
        "layer on the part's switch property, so hand keys on the links survive and the baked swing plays "
        "on top only in Sim"
    )
    bl_options = {'UNDO'}

    part: bpy.props.StringProperty(name="Part", default="", description="The name the part is switched by")
    chains: bpy.props.StringProperty(name="Chains", default="",
                                     description="The part's chains by the key they were built under, separated by commas (patterns such as *tail* allowed). Empty uses the selected bones")
    switch: bpy.props.StringProperty(name="Switch", default="",
                                     description="Custom property on the rig. Empty uses srs_sim_<part>")
    modes: bpy.props.StringProperty(name="Modes", default="hand=0,sim=1",
                                    description="Mode names and switch values, e.g. hand=0,sim=1,cloth=2")
    label: bpy.props.StringProperty(name="Label", default="", description="Shown name. Empty uses the part")
    armature: bpy.props.StringProperty(name="Armature", default="",
                                       description="The rig by its object name. Empty uses the panel's rig")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        values = {}
        for item in str(self.modes).split(","):
            if "=" in item:
                k, v = item.split("=", 1)
                try:
                    values[k.strip()] = int(v)
                except ValueError:
                    _ascii_report(self, {"WARNING"}, "Modes: write name=number, separated by commas.")
                    return {"CANCELLED"}
        keys = [k.strip() for k in str(self.chains).split(",") if k.strip()]
        if keys:
            # a pattern (*tail*) stands for the chains it matches, as everywhere else in the panel
            chains, missing = jiggle.chains_by_keys(armature, keys)
            if missing:
                _ascii_report(self, {"WARNING"}, tr_format("No chain under: %(keys)s.", keys=", ".join(missing)))
                return {"CANCELLED"}
            keys = sorted({key for _prefix, key in chains})
        else:
            chosen = {b.name for b in context.selected_pose_bones or ()}
            keys = sorted({key for (_prefix, key), bones in jiggle.all_chains(armature).items()
                           if key != "master" and any(n in chosen for n in bones)})
        if not keys:
            _ascii_report(self, {"WARNING"}, "Select a bone of each chain in Pose Mode.")
            return {"CANCELLED"}
        # the swing layer goes through Edit Mode and comes back in Object Mode
        was_pose = armature.mode == "POSE"
        report, error = jiggle.register_part_motion(armature, self.part, keys, switch=self.switch,
                                                    values=values or None, label=self.label)
        if was_pose and armature.mode != "POSE" and context.view_layer.objects.active == armature:
            bpy.ops.object.mode_set(mode="POSE")
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if report["taken_from"]:
            _ascii_report(self, {"INFO"}, "Taken from part: %s." % ", ".join(report["taken_from"]))
        _ascii_report(self, {"INFO"}, "Part %s: %d chains on %s." % (report["part"], report["chains"], report["switch"]))
        return {"FINISHED"}


class SRS_OT_part_motion_unregister(bpy.types.Operator):
    bl_idname = "srs.part_motion_unregister"
    bl_label = "Remove Part"
    bl_description = (
        "Take the part off this rig: its row, its switch and its chains' swing layers with the baked swing. "
        "Hand keys on the links stay"
    )
    bl_options = {'UNDO'}

    part: bpy.props.StringProperty(name="Part", default="", description="The registered part's name")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        was_pose = armature.mode == "POSE"
        report, error = jiggle.unregister_part_motion(armature, self.part)
        if was_pose and armature.mode != "POSE" and context.view_layer.objects.active == armature:
            bpy.ops.object.mode_set(mode="POSE")
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Part %s removed." % report["part"])
        return {"FINISHED"}


class SRS_OT_part_motion(bpy.types.Operator):
    bl_idname = "srs.part_motion"
    bl_label = "Part Motion"
    bl_description = (
        "Switch parts between simulation (the baked swing plays on top of any hand keys) and hand animation "
        "(the links show their own keys only), by name. The choice is saved with the file"
    )
    bl_options = {'UNDO'}

    part: bpy.props.StringProperty(name="Part", default="",
                                   description="Part names separated by commas. Empty switches every registered part")
    mode: bpy.props.StringProperty(name="Mode", default="sim", description="sim, hand, or a mode of the part's own")
    armature: bpy.props.StringProperty(name="Armature", default="",
                                       description="The rig by its object name. Empty uses the panel's rig")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        names = _part_names(armature, self.part)
        if not names:
            _ascii_report(self, {"WARNING"}, "This rig has no registered parts.")
            return {"CANCELLED"}
        for name in names:
            # all or nothing: check every part before switching any
            entry = jiggle.parts_motion(armature).get(name)
            if entry is None or self.mode not in (entry.get("values") or jiggle.DEFAULT_MODES):
                _ascii_report(self, {"WARNING"}, "No part %s with a mode %s." % (name, self.mode))
                return {"CANCELLED"}
        _bag, error = jiggle.rig_channelbag(armature)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        for name in names:
            _report, error = jiggle.set_part_motion(armature, name, self.mode)
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
        armature.update_tag()
        context.view_layer.update()
        _ascii_report(self, {"INFO"}, "%d part(s) on %s." % (len(names), self.mode))
        return {"FINISHED"}


class SRS_OT_part_bake(bpy.types.Operator):
    bl_idname = "srs.part_bake"
    bl_label = "Bake Part"
    bl_description = "Bake the swing of parts by name, with each chain's stored settings, and switch them to Sim"
    bl_options = {'UNDO'}

    part: bpy.props.StringProperty(name="Part", default="",
                                   description="Part names separated by commas. Empty bakes every registered part")
    frame_start: bpy.props.IntProperty(name="Start", default=0, description="0 uses the scene's start")
    frame_end: bpy.props.IntProperty(name="End", default=0, description="0 uses the scene's end")
    armature: bpy.props.StringProperty(name="Armature", default="",
                                       description="The rig by its object name. Empty uses the panel's rig")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        registry = jiggle.parts_motion(armature)
        names = _part_names(armature, self.part)
        unknown = [n for n in names if n not in registry]
        if unknown or not names:
            _ascii_report(self, {"WARNING"}, "No part called %s." % ", ".join(unknown or ["(none registered)"]))
            return {"CANCELLED"}
        keys = sorted({k for n in names for k in registry[n].get("chains", ())})
        _BAKE_WARNINGS.clear()
        result = bpy.ops.srs.jiggle_bake(chains=",".join(keys), armature=armature.name, use_selection=False,
                                         frame_start=self.frame_start, frame_end=self.frame_end)
        if "FINISHED" not in result:
            _ascii_report(self, {"WARNING"}, "The bake did not run; see the report above.")
            return {"CANCELLED"}
        for name in names:
            _report, error = jiggle.set_part_motion(armature, name, "sim")
            if error:
                _ascii_report(self, {"WARNING"}, error)
                return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Baked %d part(s), %d chain(s)." % (len(names), len(keys)))
        for warning in _BAKE_WARNINGS:
            _ascii_report(self, {"WARNING"}, warning)
        return {"FINISHED"}


class SRS_OT_part_clear(bpy.types.Operator):
    bl_idname = "srs.part_clear"
    bl_label = "Clear Part Bake"
    bl_description = "Remove the baked swing of parts by name; hand keys on their links stay"
    bl_options = {'UNDO'}

    part: bpy.props.StringProperty(name="Part", default="",
                                   description="Part names separated by commas. Empty clears every registered part")
    armature: bpy.props.StringProperty(name="Armature", default="",
                                       description="The rig by its object name. Empty uses the panel's rig")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        registry = jiggle.parts_motion(armature)
        names = _part_names(armature, self.part)
        unknown = [n for n in names if n not in registry]
        if unknown or not names:
            _ascii_report(self, {"WARNING"}, "No part called %s." % ", ".join(unknown or ["(none registered)"]))
            return {"CANCELLED"}
        keys = sorted({k for n in names for k in registry[n].get("chains", ())})
        result = bpy.ops.srs.jiggle_clear(chains=",".join(keys), armature=armature.name, use_selection=False,
                                          only_baked=True)
        if "FINISHED" not in result:
            return {"CANCELLED"}
        return {"FINISHED"}


class SRS_OT_jiggle_chain_mark(bpy.types.Operator):
    bl_idname = "srs.jiggle_chain_mark"
    bl_label = "Mark Bones as a Chain"
    bl_description = (
        "Make a row of bones a chain the bake can swing, whatever they are called -- strips added by "
        "Auto-Rig Pro or bones rigged by hand. The bones are the named list, root first, or the "
        "selected bones in their parent order"
    )
    bl_options = {'UNDO'}

    key: bpy.props.StringProperty(name="Chain Name", default="", description="The name the chain is called by")
    bones: bpy.props.StringProperty(
        name="Bones", default="",
        description="Bone names root first, separated by ';'. Empty uses the selected bones",
    )
    clear: bpy.props.BoolProperty(name="Clear", default=False, description="Remove the mark instead")
    feel: bpy.props.EnumProperty(
        name="Swing", default='KEEP',
        items=[('KEEP', "Keep", "Leave the chain's swing settings as they are")]
              + [(k, k.title(), "Store the %s swing preset on the chain" % k.lower()) for k in jiggle.FEEL],
    )
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        names = [n.strip() for n in str(self.bones).split(";") if n.strip()]
        if not names:
            chosen = {b.name for b in context.selected_pose_bones or ()}
            # parent order: a bone comes after every chosen ancestor
            def depth(name):
                bone, d = armature.data.bones.get(name), 0
                while bone is not None and bone.parent is not None:
                    bone = bone.parent
                    d += 1
                return d
            names = sorted(chosen, key=depth)
        missing = [n for n in names if armature.pose.bones.get(n) is None]
        if missing or not names:
            _ascii_report(self, {"WARNING"}, "No bone called: %s." % ", ".join(missing) if missing
                          else "Select the bones of the chain, or name them.")
            return {"CANCELLED"}
        if self.clear:
            jiggle.unmark_chain(armature, names[0])
            _ascii_report(self, {"INFO"}, "Mark removed from %s." % names[0])
            return {"FINISHED"}
        report, error = jiggle.mark_chain(armature, str(self.key).strip(), names)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        if self.feel != 'KEEP':
            jiggle.store_settings(armature, report["key"], prefix=jiggle.MARK, **jiggle.FEEL[self.feel])
        _ascii_report(self, {"INFO"}, "%s: %d bones marked as a chain." % (report["key"], len(names)))
        return {"FINISHED"}


class SRS_OT_cloth_bake(bpy.types.Operator):
    bl_idname = "srs.cloth_bake"
    bl_label = "Bake Cloth"
    bl_description = (
        "Bake, or free, the cloth simulation of one mesh by name, so a selector can switch a part to cloth "
        "without selecting anything"
    )
    bl_options = set()

    mesh: bpy.props.StringProperty(name="Mesh", default="", description="The mesh object by name")
    modifier: bpy.props.StringProperty(name="Modifier", default="SRS Cloth", description="The cloth modifier's name")
    clear: bpy.props.BoolProperty(name="Free the Bake", default=False, description="Free the bake instead")

    def execute(self, context):
        obj = bpy.data.objects.get(str(self.mesh).strip())
        if obj is None or obj.type != "MESH":
            _ascii_report(self, {"WARNING"}, "No mesh called %s." % self.mesh)
            return {"CANCELLED"}
        mod = obj.modifiers.get(str(self.modifier).strip())
        if mod is None or mod.type != "CLOTH":
            _ascii_report(self, {"WARNING"}, "%s has no cloth modifier called %s." % (obj.name, self.modifier))
            return {"CANCELLED"}
        with context.temp_override(point_cache=mod.point_cache, active_object=obj, object=obj):
            if self.clear:
                result = bpy.ops.ptcache.free_bake()
            else:
                result = bpy.ops.ptcache.bake(bake=True)
        if "FINISHED" not in result:
            _ascii_report(self, {"WARNING"}, "The cloth of %s was not %s." % (obj.name, "freed" if self.clear else "baked"))
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%s: cloth %s." % (obj.name, "freed" if self.clear else "baked"))
        return {"FINISHED"}


class SRS_OT_cuff_swing_build(bpy.types.Operator):
    bl_idname = "srs.cuff_swing_build"
    bl_label = "Cuff Follows the Wrist Bend"
    bl_description = (
        "Make the selected cuff follow the hand when the wrist bends, and stay still when it twists: a "
        "bend-only bone at the wrist carries the cuff's edge, fading up the sleeve"
    )
    bl_options = {'UNDO'}

    forearm: bpy.props.StringProperty(name="Forearm Bone", default="forearm_stretch.l",
                                      description="The bone the sleeve follows")
    hand: bpy.props.StringProperty(name="Hand Bone", default="hand.l", description="The hand's deform bone")
    share: bpy.props.FloatProperty(name="Share at the Edge", default=1.0, min=0.0, max=1.0,
                                   description="How much of the bend the cuff's edge takes")
    fade_mm: bpy.props.FloatProperty(name="Fade", default=140.0, min=1.0, soft_max=400.0,
                                     description="How far up the sleeve the share fades to nothing, in millimetres")
    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        mesh = context.active_object
        chosen = [v.index for v in mesh.data.vertices if v.select]
        if not chosen:
            _ascii_report(self, {"WARNING"}, "Select the cuff's vertices in Edit Mode.")
            return {"CANCELLED"}
        report, error = cuff_push.swing_follow(armature, mesh, chosen, self.forearm.strip(), self.hand.strip(),
                                               share=self.share, fade_mm=self.fade_mm)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%s carries %d cuff vertices." % (report["bone"], report["vertices"]))
        return {"FINISHED"}


def _lift_target(operator, context):
    """The ARP rig for the shoe lift: the armature= argument, the active object, or the panel's rig."""
    name = str(getattr(operator, "armature", "") or "").strip()
    if name:
        return shoe_lift.arp_rig(bpy.data.objects.get(name))
    return (shoe_lift.arp_rig(context.active_object)
            or shoe_lift.arp_rig(_settings(context).target_armature)
            or shoe_lift.arp_rig(likely_armature(context)))


class SRS_OT_shoe_lift_measure(bpy.types.Operator):
    bl_idname = "srs.shoe_lift_measure"
    bl_label = "Measure Shoe Sole"
    bl_description = (
        "Measure how far the selected shoe meshes reach under the floor, at rest and with no lift, and keep it "
        "on the rig's parent. Nothing moves yet"
    )
    bl_options = {'UNDO'}

    margin_mm: bpy.props.FloatProperty(name="Margin", default=0.0, soft_min=-10.0, soft_max=10.0,
                                       description="Extra height above the floor, in millimetres")
    armature: bpy.props.StringProperty(name="Armature", default="", description="The rig by its object name")

    def execute(self, context):
        rig = _lift_target(self, context)
        meshes = [o for o in context.selected_objects if o.type == "MESH"]
        report, error = shoe_lift.measure(rig, meshes, self.margin_mm)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Sole %.3f mm under the floor: lift %.3f mm."
                      % (-report["lowest_mm"], report["height_mm"]))
        return {"FINISHED"}


class SRS_OT_shoe_lift_apply(bpy.types.Operator):
    bl_idname = "srs.shoe_lift_apply"
    bl_label = "Lift by the Sole"
    bl_description = (
        "Raise the whole character by the measured sole (or the given height) through a driver on the rig's "
        "parent. No bone is added and no rest pose moves"
    )
    bl_options = {'UNDO'}

    height_mm: bpy.props.FloatProperty(name="Height", default=-1.0,
                                       description="Below 0 uses the measured sole")
    include_projectors: bpy.props.BoolProperty(name="Lift Projectors", default=True,
                                               description="Lift UV Project projectors outside the rig's parent too")
    armature: bpy.props.StringProperty(name="Armature", default="", description="The rig by its object name")

    def execute(self, context):
        rig = _lift_target(self, context)
        height = self.height_mm / 1000.0 if self.height_mm >= 0.0 else None
        report, error = shoe_lift.apply(rig, height, self.include_projectors)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%s lifted %.3f mm%s." % (
            report["holder"], report["height_mm"],
            (" with " + ", ".join(report["with"])) if report["with"] else ""))
        return {"FINISHED"}


class SRS_OT_shoe_lift_clear(bpy.types.Operator):
    bl_idname = "srs.shoe_lift_clear"
    bl_label = "Clear Shoe Lift"
    bl_description = "Put the character back on its bare feet (lift 0), keeping the drivers and the measured sole"
    bl_options = {'UNDO'}

    armature: bpy.props.StringProperty(name="Armature", default="", description="The rig by its object name")

    def execute(self, context):
        report, error = shoe_lift.clear(_lift_target(self, context))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%s back at 0." % report["holder"])
        return {"FINISHED"}


class SRS_OT_shoe_lift_remove(bpy.types.Operator):
    bl_idname = "srs.shoe_lift_remove"
    bl_label = "Remove Shoe Lift"
    bl_description = "Take the lift's drivers and properties away and put every object back where it was"
    bl_options = {'UNDO'}

    armature: bpy.props.StringProperty(name="Armature", default="", description="The rig by its object name")

    def execute(self, context):
        report, error = shoe_lift.remove(_lift_target(self, context))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "%d lift driver(s) removed." % report["drivers_removed"])
        return {"FINISHED"}


_RESCALE_ARMATURE_DESCRIPTION = (
    "The rig by its object name. Empty uses the active object, then the selection, then the panel's rig"
)
_RESCALE_MODE_DESCRIPTION = "Give the factor directly, or work it out from the current and the target height"
_RESCALE_FACTOR_DESCRIPTION = "Multiply every length by the factor"
_RESCALE_TARGET_DESCRIPTION = (
    "The height the character should have afterwards, in millimetres, measured the same way as the current height"
)
_RESCALE_CURRENT_DESCRIPTION = (
    "The character's height now, in millimetres. Measure fills it from the selected meshes; you can also type it"
)
_RESCALE_ALL_SCENE_DESCRIPTION = (
    "Resize every object in the scene, not only this character. Lights and cameras still follow Lights and Cameras"
)
_RESCALE_STAGING_DESCRIPTION = (
    "Also move and resize lights and cameras with the character; their brightness is not changed. Light probes "
    "and speakers cannot be resized and stop the resize"
)
_RESCALE_MATERIALS_DESCRIPTION = (
    "Scale lengths inside the materials (bump distance, subsurface scale, object-mapped textures)"
)
_RESCALE_PANEL_DESCRIPTION = (
    "Also scale this panel's millimetre settings and the floor height for this file. While N-panel State Save is "
    "on they are also written to the shared panel state that other files load"
)
_RESCALE_REBIND_DESCRIPTION = (
    "Unbind Corrective Smooth (bind rest), Surface Deform, Mesh Deform and Laplacian Deform before the resize and "
    "bind them again afterwards with Blender's own Bind, at rest pose and, if that does not match, at the current "
    "pose. The result is compared with the original and a difference is reported as an error"
)
# operator argument -> panel setting it falls back to when the caller did not set it
_RESCALE_PANEL_SETTINGS = (
    ("mode", "rescale_mode"),
    ("factor", "rescale_factor"),
    ("target_height_mm", "rescale_target_height_mm"),
    ("current_height_mm", "rescale_current_height_mm"),
    ("include_all_scene", "rescale_include_all_scene"),
    ("include_staging", "rescale_include_staging"),
    ("scale_materials", "rescale_scale_materials"),
    ("scale_panel_lengths", "rescale_scale_panel_lengths"),
    ("rebind_bound", "rescale_rebind_bound"),
)
# values of refusals and notes that are interface names (an object type, a setting's name): translated the
# way Blender translates the same name in its own interface
_RESCALE_IFACE_VALUES = ("type", "setting")
_RESCALE_LIST_LIMIT = 10


def _rescale_target(operator, context):
    """``(rig, problem)`` for the character resize: armature=, the active object or selection, the panel's rig."""
    return character_rescale.find_rig(context, str(getattr(operator, "armature", "") or ""))


def _rescale_args(operator, context, names):
    """Each argument the caller set, else the panel's value: panel buttons follow the panel, and a script
    depends only on its own arguments (a panel value reloaded from the shared JSON cannot change it)."""
    settings = _settings(context)
    out = {}
    for prop, setting in _RESCALE_PANEL_SETTINGS:
        if prop not in names:
            continue
        if operator.properties.is_property_set(prop):
            out[prop] = getattr(operator, prop)
        else:
            out[prop] = getattr(settings, setting)
    return out


def _rescale_problems(operator, context, args):
    """``(s, rig, scope, problems)`` with every reason the resize would stop, translated later."""
    s, factor_problems = character_rescale.resolve_factor(
        args["mode"], args["factor"], args["target_height_mm"], args["current_height_mm"])
    problems = list(factor_problems)
    rig, rig_problem = _rescale_target(operator, context)
    if rig_problem is not None:
        problems.append(rig_problem)
    scope = None
    if rig is not None:
        scope = character_rescale.collect_scope(
            rig, include_all_scene=bool(args["include_all_scene"]),
            include_staging=bool(args["include_staging"]), scene=context.scene)
        checked = character_rescale.preflight(context, rig, None if factor_problems else s, scope,
                                              rebind=bool(args.get("rebind_bound", False)))
    else:
        checked = character_rescale.preflight(context, None, None, None)
        checked = [item for item in checked if item[0] != character_rescale.MSG_NO_RIG]
    for item in checked:
        if item not in problems:
            problems.append(item)
    return s, rig, scope, problems


def _rescale_iface(text):
    """An interface name (``Curve``, ``Knee Front Profile``) in the UI language: Blender's catalog, then ours."""
    text = str(text)
    if not is_japanese():
        return text
    try:
        out = str(bpy.app.translations.pgettext_iface(text) or text)
    except Exception:
        out = text
    if out == text:
        from .i18n import _JA
        out = _JA.get(text, text)
    return out


def _rescale_values(values):
    out = dict(values)
    for key in _RESCALE_IFACE_VALUES:
        if key in out:
            out[key] = _rescale_iface(out[key])
    for key, value in out.items():
        if isinstance(value, str):
            out[key] = report_value(value, _localized_report_message)
    return out


def _rescale_names(names, limit=_RESCALE_LIST_LIMIT):
    """``(text, more)``: the first ``limit`` names joined, and how many were left off."""
    names = [str(n) for n in names]
    return ", ".join(names[:limit]), max(0, len(names) - limit)


def _report_rescale_names(operator, level, msgid, names, **values):
    text, more = _rescale_names(names)
    _ascii_report(operator, level, tr_format(msgid, names=text, **values))
    if more:
        _ascii_report(operator, level, tr_format("...and %(count)d more.", count=more))


def _report_rescale_problems(operator, problems, level=None):
    for msgid, values in problems:
        _ascii_report(operator, level or {"WARNING"}, tr_format(msgid, **_rescale_values(values)))


def _report_rescale_notes(operator, report, limit=5):
    """Notes of a finished resize: at most ``limit`` lines per kind, each naming what it is about."""
    groups = {}
    for entry in report.get("warnings", ()):
        groups.setdefault(str(entry.get("msg", "")), []).append(entry)
    for msgid, entries in groups.items():
        level = {"INFO"} if msgid in character_rescale.INFO_WARNINGS else {"WARNING"}
        for entry in entries[:limit]:
            subject = character_rescale.warning_subject(entry)
            if subject and subject == str(entry.get("setting", "")):
                subject = _rescale_iface(subject)
            note = tr_format(msgid)
            _ascii_report(operator, level, tr_format("%(note)s: %(subject)s", note=note, subject=subject)
                          if subject else note)
        if len(entries) > limit:
            _ascii_report(operator, level, tr_format("...and %(count)d more.", count=len(entries) - limit))
    for item in report.get("clamped", ()):
        _ascii_report(operator, {"WARNING"}, tr_format(
            "%(setting)s was held at its limit (%(value).3f).",
            setting=_rescale_iface(item.get("name") or item["setting"]), value=float(item["got"])))


def _report_rescale_result(operator, report, rig, s):
    """Notes first, then the summary; when anything may not match the new size the last line (the one the
    status bar keeps) is an error headline. The operator still finishes, so one Undo takes it all back."""
    _report_rescale_notes(operator, report)
    left = [entry["object"] for entry in report.get("nonunit_scale_left", ())]
    if left:
        _report_rescale_names(operator, {"WARNING"}, "Not at scale 1 afterwards (%(count)d): %(names)s", left,
                              count=len(left))
    new_bad = list(report.get("new_invalid_drivers", ()))
    if new_bad:
        _report_rescale_names(operator, {"ERROR"}, "Drivers that became invalid (%(count)d): %(names)s", new_bad,
                              count=len(new_bad))
    rebind = report.get("rebind") or {}
    if rebind.get("failed"):
        # the data has been changed (unbound and bound again): say so plainly, before the headline
        _report_rescale_names(operator, {"ERROR"},
                              "Binding again did not reproduce the original (%(count)d): %(names)s. The character was "
                              "resized and these modifiers were unbound and bound again, so their bind data has "
                              "changed. Undo (Ctrl+Z) to get the original back.",
                              rebind["failed"], count=len(rebind["failed"]))
    elif rebind.get("bound"):
        _ascii_report(operator, {"INFO"}, tr_format(
            "Bound again: %(count)d modifiers. Largest difference from the original: %(mm).4f mm.",
            count=len(rebind["bound"]), mm=float(rebind.get("worst_mm", 0.0))))
    scaled_panel = list(report.get("panel_lengths_scaled", ()))
    if scaled_panel and report.get("panel_state_saved"):
        _ascii_report(operator, {"WARNING"}, tr_format(
            "Panel lengths (%(count)d) were scaled and written to the shared panel state that other files load.",
            count=len(scaled_panel)))
    notes = len(report.get("warnings", ())) + len(report.get("clamped", ()))
    _ascii_report(operator, {"INFO"}, tr_format(
        "Resized %(objects)d objects (including %(rig)s) by %(factor).6f. Values changed: %(changes)d. "
        "Notes: %(warnings)d.",
        objects=len(report["scope_objects"]), rig=rig.name, factor=s, changes=report["changes_total"],
        warnings=notes))
    defects = len(report.get("defects", ())) + len(new_bad)
    if defects:
        _ascii_report(operator, {"ERROR"}, tr_format(
            "Resized, but %(count)d notes say parts may not match the new size exactly. Check them, or undo "
            "(Ctrl+Z).", count=defects))


class SRS_OT_character_rescale_measure(bpy.types.Operator):
    bl_idname = "srs.character_rescale_measure"
    bl_label = "Measure Character Height"
    bl_description = (
        "Measure the selected meshes at rest with no shoe lift and put the height in Current Height. Nothing moves"
    )
    bl_options = {'UNDO'}

    basis: EnumProperty(options={'SKIP_SAVE'}, name="Height Is", description="How the height is measured",
                        items=RESCALE_BASES, default="EXTENT")
    armature: StringProperty(options={'SKIP_SAVE'}, name="Armature", default="",
                             description=_RESCALE_ARMATURE_DESCRIPTION)

    def execute(self, context):
        settings = _settings(context)
        if context.mode != "OBJECT":
            _ascii_report(self, {"WARNING"}, tr_format(character_rescale.MSG_MODE))
            return {"CANCELLED"}
        rig, problem = _rescale_target(self, context)
        if rig is None:
            _report_rescale_problems(self, [problem])
            return {"CANCELLED"}
        basis_set = self.properties.is_property_set("basis")
        basis = self.basis if basis_set else settings.rescale_height_basis
        meshes = [o for o in context.selected_objects if o.type == "MESH"]
        report, problem = character_rescale.measure_height(rig, meshes, basis)
        if problem is not None:
            _report_rescale_problems(self, [problem])
            return {"CANCELLED"}
        if basis_set:
            settings.rescale_height_basis = basis
        settings.rescale_measured_top_mm = report["top_mm"]
        settings.rescale_measured_bottom_mm = report["bottom_mm"]
        settings.rescale_measured_rig = rig.name
        settings.rescale_measured_basis = report["basis"]
        settings.rescale_current_height_mm = max(0.0, report["height_mm"])
        _ascii_report(self, {"INFO"}, tr_format(
            "Height %(height).3f mm (top %(top).3f mm, bottom %(bottom).3f mm), measured at rest with no shoe "
            "lift. Meshes measured: %(count)d.",
            height=report["height_mm"], top=report["top_mm"], bottom=report["bottom_mm"],
            count=len(report["meshes"])))
        return {"FINISHED"}


class SRS_OT_character_rescale_check(bpy.types.Operator):
    bl_idname = "srs.character_rescale_check"
    bl_label = "Check Character Resize"
    bl_description = (
        "Report how many objects would be resized and name them, and list anything that stops the resize. "
        "Nothing changes"
    )
    bl_options = set()

    armature: StringProperty(options={'SKIP_SAVE'}, name="Armature", default="",
                             description=_RESCALE_ARMATURE_DESCRIPTION)
    mode: EnumProperty(options={'SKIP_SAVE'}, name="Resize By", items=RESCALE_MODES, default="FACTOR",
                       description=_RESCALE_MODE_DESCRIPTION)
    factor: bpy.props.FloatProperty(
        options={'SKIP_SAVE'}, name="Resize Factor", default=1.0, min=0.0, soft_min=0.1, soft_max=10.0,
        precision=6, description=_RESCALE_FACTOR_DESCRIPTION)
    target_height_mm: bpy.props.FloatProperty(
        options={'SKIP_SAVE'}, name="Target Height", default=0.0, min=0.0, precision=2,
        description=_RESCALE_TARGET_DESCRIPTION)
    current_height_mm: bpy.props.FloatProperty(
        options={'SKIP_SAVE'}, name="Current Height", default=0.0, min=0.0, precision=3,
        description=_RESCALE_CURRENT_DESCRIPTION)
    include_all_scene: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Whole Scene", default=False, description=_RESCALE_ALL_SCENE_DESCRIPTION)
    include_staging: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Lights and Cameras", default=False, description=_RESCALE_STAGING_DESCRIPTION)
    rebind_bound: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Rebind Bound Modifiers", default=False, description=_RESCALE_REBIND_DESCRIPTION)

    def execute(self, context):
        args = _rescale_args(self, context, ("mode", "factor", "target_height_mm", "current_height_mm",
                                             "include_all_scene", "include_staging", "rebind_bound"))
        s, rig, scope, problems = _rescale_problems(self, context, args)
        if rig is None:
            _report_rescale_problems(self, problems)
            return {"CANCELLED"}
        included = [o.name for o in scope["objects"]]
        left_out = [name for name, why in scope["excluded"] if why != "not_in_scene"]
        _report_rescale_names(self, {"INFO"}, "To resize: %(names)s", included)
        if left_out:
            _report_rescale_names(self, {"INFO"}, "Left out: %(names)s", left_out)
        if args["rebind_bound"]:
            bound = [character_rescale._mod_label(o, m)
                     for o, m in character_rescale.bound_modifiers(scope["objects"])]
            if bound:
                _report_rescale_names(self, {"INFO"}, "To bind again (%(count)d): %(names)s", bound,
                                      count=len(bound))
        if s is not None:
            _ascii_report(self, {"INFO"}, tr_format(
                "Objects to resize: %(objects)d, by %(factor).6f. Left out: %(excluded)d.",
                objects=len(included), factor=s, excluded=len(left_out)))
        else:
            _ascii_report(self, {"INFO"}, tr_format(
                "Objects to resize: %(objects)d. Left out: %(excluded)d.",
                objects=len(included), excluded=len(left_out)))
        _report_rescale_problems(self, problems)
        return {"FINISHED"}


class SRS_OT_character_rescale(bpy.types.Operator):
    bl_idname = "srs.character_rescale"
    bl_label = "Resize Character"
    bl_description = (
        "Resize the whole character about the world origin, keeping every modifier, weight, driver, constraint "
        "and SmartRig setup. Meshes and armatures end at scale 1 except those named in the notes"
    )
    bl_options = {'UNDO'}

    armature: StringProperty(options={'SKIP_SAVE'}, name="Armature", default="",
                             description=_RESCALE_ARMATURE_DESCRIPTION)
    mode: EnumProperty(options={'SKIP_SAVE'}, name="Resize By", items=RESCALE_MODES, default="FACTOR",
                       description=_RESCALE_MODE_DESCRIPTION)
    factor: bpy.props.FloatProperty(
        options={'SKIP_SAVE'}, name="Resize Factor", default=1.0, min=0.0, soft_min=0.1, soft_max=10.0,
        precision=6, description=_RESCALE_FACTOR_DESCRIPTION)
    target_height_mm: bpy.props.FloatProperty(
        options={'SKIP_SAVE'}, name="Target Height", default=0.0, min=0.0, precision=2,
        description=_RESCALE_TARGET_DESCRIPTION)
    current_height_mm: bpy.props.FloatProperty(
        options={'SKIP_SAVE'}, name="Current Height", default=0.0, min=0.0, precision=3,
        description=_RESCALE_CURRENT_DESCRIPTION)
    include_all_scene: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Whole Scene", default=False, description=_RESCALE_ALL_SCENE_DESCRIPTION)
    include_staging: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Lights and Cameras", default=False, description=_RESCALE_STAGING_DESCRIPTION)
    scale_materials: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Material Lengths", default=True, description=_RESCALE_MATERIALS_DESCRIPTION)
    scale_panel_lengths: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Panel Lengths", default=True, description=_RESCALE_PANEL_DESCRIPTION)
    rebind_bound: bpy.props.BoolProperty(
        options={'SKIP_SAVE'}, name="Rebind Bound Modifiers", default=False, description=_RESCALE_REBIND_DESCRIPTION)

    _ARGS = ("mode", "factor", "target_height_mm", "current_height_mm", "include_all_scene", "include_staging",
             "scale_materials", "scale_panel_lengths", "rebind_bound")

    def invoke(self, context, event):
        args = _rescale_args(self, context, self._ARGS)
        s, rig, scope, problems = _rescale_problems(self, context, args)
        if problems:
            _report_rescale_problems(self, problems)
            return {"CANCELLED"}
        bound = character_rescale.bound_modifiers(scope["objects"]) if args["rebind_bound"] else []
        if bound:
            message = tr_format("Resize %(objects)d objects (including %(rig)s) by %(factor).6f about the world origin "
                                "and bind %(bound)d modifiers again?",
                                objects=len(scope["objects"]), rig=rig.name, factor=s, bound=len(bound))
        else:
            message = tr_format("Resize %(objects)d objects (including %(rig)s) by %(factor).6f about the world "
                                "origin?", objects=len(scope["objects"]), rig=rig.name, factor=s)
        label = tr_format("Resize Character")
        return context.window_manager.invoke_confirm(self, event, title=label, message=message, confirm_text=label,
                                                     translate=False)

    def execute(self, context):
        args = _rescale_args(self, context, self._ARGS)
        s, rig, _scope, problems = _rescale_problems(self, context, args)
        if problems:
            _report_rescale_problems(self, problems)
            return {"CANCELLED"}
        report, problems = character_rescale.rescale(
            context, rig, s, include_all_scene=bool(args["include_all_scene"]),
            include_staging=bool(args["include_staging"]), scale_materials=bool(args["scale_materials"]),
            scale_panel_lengths=bool(args["scale_panel_lengths"]), rebind_bound=bool(args["rebind_bound"]))
        if problems:
            _report_rescale_problems(self, problems)
            return {"CANCELLED"}
        if args["mode"] == "FACTOR" and not self.properties.is_property_set("factor"):
            # the panel's factor is spent: pressing Resize again must not resize a second time
            character_rescale.spend_panel_factor(_settings(context))
        _report_rescale_result(self, report, rig, s)
        return {"FINISHED"}


class SRS_OT_colliders_display(bpy.types.Operator):
    bl_idname = "srs.colliders_display"
    bl_label = "Show or Hide Colliders"
    bl_description = (
        "Show or hide the collision capsules and the collision meshes together. They are only there for the "
        "jiggle bake and the cloth, so they stay hidden while you pose, preview and render; the bake reads the "
        "capsule bones whether they are shown or not"
    )
    bl_options = {'UNDO'}

    show: bpy.props.BoolProperty(name="Show", default=False)

    armature: bpy.props.StringProperty(
        name="Armature", default="",
        description="The rig by its object name. Empty uses the panel's rig",
    )

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        touched = []
        if armature is not None and armature.type == "ARMATURE":
            bc = armature.data.collections_all.get(collide.COLLECTION)
            if bc is not None:
                bc.is_visible = bool(self.show)
                touched.append(bc.name)
        proxy = bpy.data.collections.get(collide.PROXY_COLLECTION)
        if proxy is not None:
            # Never out of evaluation: a cloth collides only with what the depsgraph
            # evaluates, and the monitor icon (Collection.hide_viewport) takes it out --
            # a cloth fell 4.66 m through a hidden floor. The eye icon does not.
            proxy.hide_viewport = False
            proxy.hide_render = False
            for layer in collide.layer_collections(context.scene, proxy):
                layer.exclude = False
                layer.hide_viewport = not self.show
            for obj in collide.proxy_objects(proxy):
                collide.hide_from_rays(obj)
                obj.hide_select = True
                obj.display_type = "BOUNDS" if not self.show else "WIRE"
            touched.append(proxy.name)
        if not touched:
            _ascii_report(self, {"WARNING"}, "This rig has no colliders yet.")
            return {"CANCELLED"}
        _ascii_report(self, {"INFO"}, "Colliders %s." % ("shown" if self.show else "hidden"))
        return {"FINISHED"}


class SRS_OT_part_link_key(bpy.types.Operator):
    bl_idname = "srs.part_link_key"
    bl_label = "Link Shape Key to Part"
    bl_description = (
        "Make a shape key follow the part's Show / Hide: 1 while the part is shown, 0 while it is hidden. For a "
        "layer underneath that has to slim down only while this part is worn over it"
    )
    bl_options = {'UNDO'}

    remove: bpy.props.BoolProperty(name="Remove", default=False)

    def execute(self, context):
        settings = _settings(context)
        part = str(settings.part_name).strip()
        obj = settings.part_key_object
        key = str(settings.part_key_name).strip()
        if not part or obj is None or not key:
            _ascii_report(self, {"WARNING"}, "Choose the part, the mesh and its shape key.")
            return {"CANCELLED"}
        rows, error = part_rig.link_key(part, obj.name, key, remove=bool(self.remove))
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        c = bpy.data.collections.get(part)
        if c is not None and not self.remove:
            part_rig.apply_linked_keys(part, not c.hide_viewport)
        _ascii_report(self, {"INFO"}, "%d shape key(s) linked to %s." % (len(rows), part))
        return {"FINISHED"}


class SRS_OT_strip_rig_build(bpy.types.Operator):
    bl_idname = "srs.strip_rig_build"
    bl_label = "Build Strip Bones"
    bl_description = (
        "Give the selected part strip bones with Auto-Rig Pro's Kilt, then weight it onto them. Each strip is a "
        "column of controllers kept off the collide bones by ARP's own constraints and drivers, and keys on the "
        "controllers add on top. Select the part's vertices in Edit Mode first. Match to Rig is not run, so "
        "nothing else on the rig changes"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        if armature is None:
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        chosen = [v.index for v in mesh.data.vertices if v.select]
        if not chosen:
            _ascii_report(self, {"WARNING"}, "Select the part's vertices in Edit Mode first.")
            return {"CANCELLED"}
        angles = None
        text = str(settings.strip_angles).strip()
        if text:
            try:
                angles = [float(a) for a in text.replace(";", ",").split(",") if a.strip()]
            except ValueError:
                _ascii_report(self, {"WARNING"}, "Angles must be numbers separated by commas.")
                return {"CANCELLED"}
        collide = [str(settings.strip_collide_a).strip(), str(settings.strip_collide_b).strip()]
        centre, pleats = None, None
        if settings.strip_on_pleats:
            if settings.strip_type_side != ".x":
                _ascii_report(self, {"WARNING"}, "Strips on the pleats need the Ring layout.")
                return {"CANCELLED"}
            centre = kilt_strips.body_centre(armature)
            found, perror = kilt_strips.panel_columns(mesh, chosen, centre=centre)
            if perror:
                _ascii_report(self, {"WARNING"}, perror)
                return {"CANCELLED"}
            pleats = found["columns"]
        donor = None
        if settings.strip_top_from_under:
            donor = settings.under_part
            if donor is None or donor == mesh or donor.type != "MESH":
                _ascii_report(self, {"WARNING"}, "Choose the garment underneath (another mesh).")
                return {"CANCELLED"}
        report, error = kilt_strips.build(
            armature, mesh, chosen, name=str(settings.strip_name).strip() or "kilt",
            count=int(settings.strip_count), subdiv=int(settings.strip_subdiv),
            type_side=settings.strip_type_side, collide_with=[c for c in collide if c],
            angles_deg=None if pleats else angles, col_z=bool(settings.strip_collide_z),
            columns_xyz=pleats, centre=centre)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        columns = kilt_strips.kilt_columns(armature, report["name"], report["side"])
        # a ring or a left/right pair decides from the part whether it is open (a slit skirt)
        weights, werror = kilt_strips.strip_weights(
            mesh, armature, columns, chosen, blend_mm=float(settings.strip_blend_mm),
            closed=None if settings.strip_type_side in ("SYMMETRICAL", ".x") else False,
            centre=centre, donor=donor)
        if werror:
            _ascii_report(self, {"WARNING"}, werror)
            return {"CANCELLED"}
        rig_hygiene.normalise_deform(mesh, armature)
        _ascii_report(self, {"INFO"}, "%s: %d strips, %d bones; %d vertices weighted%s." % (
            report["name"], report["columns"], report["deform_bones"], weights["vertices"],
            (", %d strip(s) found no part to sit on" % len(report["unplaced"])) if report["unplaced"] else ""))
        return {"FINISHED"}


class SRS_OT_kilt_leg_push(bpy.types.Operator):
    bl_idname = "srs.kilt_leg_push"
    bl_label = "Strips Lie on a Raised Thigh"
    bl_description = (
        "Set how far an existing kilt's strips are kept off the legs, and ease that push off as a leg rises past "
        "the start angle, so the front strips lie on a raised thigh instead of standing up towards the chest. "
        "Only Auto-Rig Pro's own drivers (or ones set here) are changed; run it again to change the values"
    )
    bl_options = {'UNDO'}

    armature: bpy.props.StringProperty(name="Armature", default="",
                                       description="The rig by its object name. Empty uses the panel's rig")
    kilt: bpy.props.StringProperty(name="Kilt", default="kilt", description="The kilt's name")
    collide_dist: bpy.props.FloatProperty(name="Push Distance", default=0.25, min=0.0, soft_max=1.0,
                                          description="How far the strips are kept off the leg (Auto-Rig Pro's Collide Distance)")
    ease_start: bpy.props.FloatProperty(name="Ease From (deg)", default=60.0, min=0.0, max=180.0,
                                        description="Leg swing at which the push starts to ease off")
    ease_end: bpy.props.FloatProperty(name="Ease To (deg)", default=90.0, min=0.0, max=180.0,
                                      description="Leg swing at which the push has eased off fully")
    keep: bpy.props.FloatProperty(name="Push Left", default=0.35, min=0.0, max=1.0, subtype="FACTOR",
                                  description="The share of the push left at the end angle. 1 keeps Auto-Rig Pro's push unchanged")

    def execute(self, context):
        settings = _settings(context)
        armature = _rig(self, context, settings)
        if armature is None or armature.type != "ARMATURE":
            _ascii_report(self, {"WARNING"}, "Choose the rig first.")
            return {"CANCELLED"}
        report, error = kilt_strips.set_leg_push(armature, str(self.kilt).strip() or "kilt", self.collide_dist,
                                                 self.ease_start, self.ease_end, self.keep)
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        context.view_layer.update()
        _ascii_report(self, {"INFO"}, tr_format(
            "Kilt %(name)s: push %(dist).2f, eased from %(start)d to %(end)d deg down to %(keep)d %%.",
            name=report["name"], dist=report["collide_dist"], start=int(round(self.ease_start)),
            end=int(round(self.ease_end)), keep=int(round(self.keep * 100))))
        return {"FINISHED"}


class SRS_OT_follow_strips_build(bpy.types.Operator):
    bl_idname = "srs.follow_strips_build"
    bl_label = "Build Follow Strips"
    bl_description = (
        "Give the selected part of a garment strips of controllers that move like the garment underneath and "
        "add their own rotation on top. Each strip bone follows the layer underneath with an Armature "
        "constraint weighted like that layer at the bone, so a coat over a top bends with the top instead of "
        "sinking into it. Select the part's vertices in Edit Mode and set the garment underneath first"
    )
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH" and context.mode == "OBJECT"

    def execute(self, context):
        settings = _settings(context)
        armature = settings.target_armature or likely_armature(context)
        mesh = context.active_object
        donor = settings.under_part
        chosen = [v.index for v in mesh.data.vertices if v.select]
        if armature is None or donor is None or not chosen:
            _ascii_report(self, {"WARNING"}, "Choose the rig and the garment underneath, and select the part's vertices.")
            return {"CANCELLED"}
        try:
            angles = [float(a) for a in str(settings.fstrip_angles).replace(";", ",").split(",") if a.strip()]
        except ValueError:
            _ascii_report(self, {"WARNING"}, "Angles must be numbers separated by commas.")
            return {"CANCELLED"}
        report, error = follow_strips.build(armature, mesh, chosen, donor, name=str(settings.fstrip_name).strip() or "strip",
                                            angles_deg=angles, segments=int(settings.fstrip_segments),
                                            feel=jiggle.FEEL["HEM"],
                                            parent_collection=str(settings.part_name).strip())
        if error:
            _ascii_report(self, {"WARNING"}, error)
            return {"CANCELLED"}
        weights, werror = kilt_strips.strip_weights(mesh, armature, report["columns"], chosen,
                                                    blend_mm=float(settings.fstrip_blend_mm), closed=True)
        if werror:
            _ascii_report(self, {"WARNING"}, werror)
            return {"CANCELLED"}
        rig_hygiene.normalise_deform(mesh, armature)
        _ascii_report(self, {"INFO"}, "%s: %d strips, %d bones following %s; %d vertices weighted." % (
            report["name"], len(report["columns"]), report["bones"], donor.name, weights["vertices"]))
        return {"FINISHED"}


CLASSES = (
    SRS_OT_refresh_external_status,
    SRS_OT_assign_workflow_targets,
    SRS_OT_workflow_preflight,
    SRS_OT_arp_add_limb_safe,
    SRS_OT_arp_snap_safe,
    SRS_OT_arp_add_reference,
    SRS_OT_arp_prepare_context,
    SRS_OT_arp_marker_ai,
    SRS_OT_arp_smart_detect,
    SRS_OT_arp_match_to_rig,
    SRS_OT_arp_bind_workflow,
    SRS_OT_arp_ikfk_safe,
    SRS_OT_arp_pose_utility,
    SRS_OT_ai_auto_detect,
    SRS_OT_ai_validate,
    SRS_OT_ai_sync_arp,
    SRS_OT_ai_open_folder,
    SRS_OT_proxy_external_action,
    SRS_OT_proxy_set_collection_button,
    SRS_OT_proxy_batch_pair,
    SRS_OT_proxy_audit,
    SRS_OT_proxy_repair,
    SRS_OT_proxy_export,
    SRS_OT_proxy_import,
    SRS_OT_weight_quality_audit,
    SRS_OT_full_audit,
    SRS_OT_clean_legacy_scene_data,
    SRS_OT_export_integration_report,
    SRS_OT_eye_snap_references,
    SRS_OT_eye_audit,
    SRS_OT_lid_pivot_audit,
    SRS_OT_face_weight_audit,
    SRS_OT_corrective_lid,
    SRS_OT_corrective_lip,
    SRS_OT_hygiene_audit,
    SRS_OT_hygiene_lock_dead,
    SRS_OT_hygiene_clamp_face,
    SRS_OT_hygiene_bind_loose,
    SRS_OT_hygiene_repair_drivers,
    SRS_OT_costume_bind,
    SRS_OT_jiggle_bake,
    SRS_OT_fit_colliders,
    SRS_OT_clear_colliders,
    SRS_OT_collision_proxy,
    SRS_OT_clear_collision_proxy,
    SRS_OT_jiggle_clear,
    SRS_OT_cloth_setup,
    SRS_OT_lid_shadow_build,
    SRS_OT_lid_shadow_verify,
    SRS_OT_lid_shadow_remove,
    SRS_OT_wrist_fold_install,
    SRS_OT_wrist_fold_verify,
    SRS_OT_wrist_fold_remove,
    SRS_OT_shoulder_limit_install,
    SRS_OT_shoulder_limit_remove,
    SRS_OT_compare_snapshot_take,
    SRS_OT_compare_with_file,
    SRS_OT_compare_export,
    SRS_OT_face_falloff_audit,
    SRS_OT_face_falloff_trim,
    SRS_OT_corrective_confine,
    SRS_OT_blink_pose_prepare,
    SRS_OT_lid_range_clamp,
    SRS_OT_lid_pivot_fix,
    SRS_OT_eye_bind,
    SRS_OT_eye_verify,
    SRS_OT_eye_dispose_temp,
    SRS_OT_knee_split_install,
    SRS_OT_knee_split_remove,
    SRS_OT_knee_split_audit,
    SRS_OT_knee_smooth_weights,
    SRS_OT_hair_build,
    SRS_OT_hair_remove,
    SRS_OT_hair_audit,
    SRS_OT_part_audit,
    SRS_OT_part_visibility,
    SRS_OT_part_delete,
    SRS_OT_joint_setup_all,
    SRS_OT_joint_setup_remove,
    SRS_OT_joint_audit,
    SRS_OT_joint_mirror_fans,
    SRS_OT_mocap_load,
    SRS_OT_mocap_check,
    SRS_OT_rigidify_material,
    SRS_OT_drop_families,
    SRS_OT_follow_only,
    SRS_OT_bind_over,
    SRS_OT_penetration_check,
    SRS_OT_build_chain,
    SRS_OT_clear_chain,
    SRS_OT_additive_bones,
    SRS_OT_keep_outside,
    SRS_OT_clear_contact,
    SRS_OT_band_width_lock,
    SRS_OT_ikfk_switch,
    SRS_OT_ikfk_step_keys,
    SRS_OT_chain_group_build,
    SRS_OT_chain_group_remove,
    SRS_OT_hygiene_drop_faint,
    SRS_OT_hygiene_symmetrize_midline,
    SRS_OT_hygiene_blend_midline,
    SRS_OT_cloth_remove,
    SRS_OT_skirt_mode_set,
    SRS_OT_jiggle_chain_include,
    SRS_OT_jiggle_mute,
    SRS_OT_jiggle_chain_collide,
    SRS_OT_jiggle_chain_mark,
    SRS_OT_jiggle_swing_layer,
    SRS_OT_band_mirror,
    SRS_OT_colliders_fit_without,
    SRS_OT_umbrella_rolls,
    SRS_OT_part_motion_register,
    SRS_OT_part_motion_unregister,
    SRS_OT_part_motion,
    SRS_OT_part_bake,
    SRS_OT_part_clear,
    SRS_OT_jiggle_chain_gravity_rest,
    SRS_OT_jiggle_chain_rest_clear,
    SRS_OT_jiggle_chain_thickness,
    SRS_OT_jiggle_chain_entry_push,
    SRS_OT_cloth_bake,
    SRS_OT_cuff_swing_build,
    SRS_OT_shoe_lift_measure,
    SRS_OT_shoe_lift_apply,
    SRS_OT_shoe_lift_clear,
    SRS_OT_shoe_lift_remove,
    SRS_OT_character_rescale_measure,
    SRS_OT_character_rescale_check,
    SRS_OT_character_rescale,
    SRS_OT_colliders_display,
    SRS_OT_part_link_key,
    SRS_OT_strip_rig_build,
    SRS_OT_kilt_leg_push,
    SRS_OT_follow_strips_build,
    SRS_OT_knee_profile_install,
    SRS_OT_knee_profile_remove,
    SRS_OT_knee_profile_audit,
)


_REGISTERED = False


def register() -> bool:
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False
    register_classes(
        CLASSES,
        module_name=__name__,
        revision=__srs_revision__,
        module_marker=__srs_module_generation_marker__,
    )
    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    return True


def unregister() -> dict:
    global _REGISTERED
    report = unregister_owned_classes(module_name=__name__, attempts=2)
    if report.get("all_removed"):
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return report
