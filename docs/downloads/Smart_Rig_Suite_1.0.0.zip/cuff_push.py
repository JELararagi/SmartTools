# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Keep a sleeve's cuff off the hand when the wrist bends, with strips and plain constraints.

The skirt's logic, turned to a cuff: each strip of the cuff is an MCH bone that aims
(Damped Track) at a target at the strip's tip, and the target is kept outside the
hand (Limit Distance, outside) by colliders riding inside the hand. Bending the
wrist towards a strip moves the colliders towards its target, the target is pushed
out and the strip swings clear; bending away, or twisting, does nothing, so the
sleeve still ignores the wrist's twist. An animator's control (c_) is the child of
each MCH strip, so keys on it add on top.

Auto-Rig Pro's Kilt was tried first (one-sided, the hand as the collide bone) and
made the cuff worse on MIK -- dorsal flexion 101 -> 123 crossing faces: its
collision planes assume legs and strips hanging down.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import math

import bpy
from mathutils import Vector

from . import kilt_strips

BONE_COLLECTION = "SRS Cuffs"
MCH_COLLECTION = "SRS Cuffs MCH"


def build(armature, mesh_object, indices, forearm_bone, hand_bone, name="cuff", count=8,
          collider_fracs=(0.15, 0.45), margin_mm=0.0):
    """Create the cuff strips on ``indices`` (the cuff part of the sleeve). (report, error)

    ``forearm_bone`` carries the strips (the bone the sleeve follows, without twist);
    ``hand_bone`` carries the colliders, placed at ``collider_fracs`` along it.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Choose the rig first."
    fb = armature.data.bones.get(forearm_bone)
    hb = armature.data.bones.get(hand_bone)
    if fb is None or hb is None:
        return None, "The rig has no %s or %s." % (forearm_bone, hand_bone)
    am = armature.matrix_world
    inv = am.inverted()
    axis = (am @ fb.tail_local) - (am @ fb.head_local)
    frame = kilt_strips.part_frame(mesh_object, indices, axis=axis)
    if frame is None:
        return None, "Select the cuff's vertices."
    side = hand_bone[-2:] if hand_bone[-2:] in (".l", ".r") else ".x"
    spans = []
    for k in range(count):
        angle = 2.0 * math.pi * k / count
        top, tip = kilt_strips.column_span(frame, angle, 360.0 / count * 0.45)
        half = 360.0 / count * 0.45
        while top is None and half < 60.0:
            half += 6.0
            top, tip = kilt_strips.column_span(frame, angle, half)
        if top is not None:
            spans.append((top, tip))
    if not spans:
        return None, "No cuff found round the forearm."
    colliders = [(am @ hb.head_local).lerp(am @ hb.tail_local, f) for f in collider_fracs]
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    names = []
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        coll = armature.data.collections_all.get(BONE_COLLECTION) or armature.data.collections.new(BONE_COLLECTION)
        mch = armature.data.collections_all.get(MCH_COLLECTION) or armature.data.collections.new(MCH_COLLECTION)
        mch.is_visible = False
        col_names = []
        for j, c in enumerate(colliders, start=1):
            n = "mch_%s_hand_%02d%s" % (name, j, side)
            eb = edit.get(n) or edit.new(n)
            eb.head = inv @ c
            eb.tail = inv @ (c + (axis.normalized() * 0.01))
            eb.parent = edit[hand_bone]
            eb.use_deform = False
            mch.assign(eb)
            col_names.append(n)
        for k, (top, tip) in enumerate(spans, start=1):
            tgt = "mch_%s_%02d_tip%s" % (name, k, side)
            drv = "mch_%s_%02d%s" % (name, k, side)
            ctl = "c_%s_%02d%s" % (name, k, side)
            et = edit.get(tgt) or edit.new(tgt)
            et.head = inv @ tip
            et.tail = inv @ (tip + axis.normalized() * 0.01)
            et.parent = edit[forearm_bone]
            et.use_deform = False
            mch.assign(et)
            ed = edit.get(drv) or edit.new(drv)
            ed.head = inv @ top
            ed.tail = inv @ tip
            ed.parent = edit[forearm_bone]
            ed.use_deform = False
            mch.assign(ed)
            ec = edit.get(ctl) or edit.new(ctl)
            ec.head = inv @ top
            ec.tail = inv @ tip
            ec.roll = ed.roll
            ec.parent = ed
            ec.use_deform = True
            coll.assign(ec)
            names.append((tgt, drv, ctl, tip))
        bpy.ops.object.mode_set(mode="POSE")
        for tgt, drv, ctl, tip in names:
            pt = armature.pose.bones[tgt]
            for con in list(pt.constraints):
                pt.constraints.remove(con)
            for n, c in zip(col_names, colliders):
                con = pt.constraints.new("LIMIT_DISTANCE")
                con.name = "SRS keep off " + n
                con.target = armature
                con.subtarget = n
                con.limit_mode = "LIMITDIST_OUTSIDE"
                con.distance = (tip - c).length + float(margin_mm) / 1000.0
            pd = armature.pose.bones[drv]
            for con in list(pd.constraints):
                pd.constraints.remove(con)
            con = pd.constraints.new("DAMPED_TRACK")
            con.name = "SRS aim at tip"
            con.target = armature
            con.subtarget = tgt
            con.track_axis = "TRACK_Y"
    finally:
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous
    return {"name": name, "side": side, "columns": [[ctl] for _t, _d, ctl, _p in names],
            "colliders": col_names, "axis": axis}, ""


def _dilute_other_rigs(mesh_object, armature, index, w, null_bone):
    """Scale the vertex's weights in every OTHER armature deforming the mesh by (1 - w), the rest onto a still bone
    of that armature: each Armature modifier normalises on its own, so a partial weight there still counts in full."""
    if w <= 0.0:
        return 0
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    changed = 0
    for mod in mesh_object.modifiers:
        other = mod.object if mod.type == "ARMATURE" else None
        if other is None or other == armature or other.type != "ARMATURE":
            continue
        still = other.data.bones.get(null_bone)
        if still is None or not still.use_deform:
            continue
        rows = [(e.group, e.weight) for e in mesh_object.data.vertices[index].groups
                if names.get(e.group) and names[e.group] != null_bone
                and other.data.bones.get(names[e.group]) is not None and other.data.bones[names[e.group]].use_deform]
        total = sum(x for _g, x in rows)
        if total <= 1.0e-9:
            continue
        for g, x in rows:
            mesh_object.vertex_groups[g].add([index], x * (1.0 - w), "REPLACE")
        group = mesh_object.vertex_groups.get(null_bone) or mesh_object.vertex_groups.new(name=null_bone)
        current = next((e.weight for e in mesh_object.data.vertices[index].groups if e.group == group.index), 0.0)
        group.add([index], current + total * w, "REPLACE")
        changed += 1
    return changed


def carry_share(source_mesh, target_mesh, armature, group_name, max_mm=15.0, null_bone="null_bend.x", indices=None):
    """Give a layer worn over a garment the same share of ``group_name`` as the garment under each of its vertices.
    ``(report, error)``. The target's other weights on ``armature`` are scaled by what is left, and its weights in
    the other armatures are diluted the same way as swing_follow does."""
    from mathutils.kdtree import KDTree
    src = source_mesh.vertex_groups.get(group_name)
    if src is None:
        return None, "%s has no %s." % (source_mesh.name, group_name)
    smw, tmw = source_mesh.matrix_world, target_mesh.matrix_world
    weights = {}
    for v in source_mesh.data.vertices:
        for e in v.groups:
            if e.group == src.index and e.weight > 0.0:
                weights[v.index] = e.weight
    if not weights:
        return None, "%s carries no %s." % (source_mesh.name, group_name)
    kd = KDTree(len(weights))
    for i in weights:
        kd.insert(smw @ source_mesh.data.vertices[i].co, i)
    kd.balance()
    deform = {b.name for b in armature.data.bones if b.use_deform and b.name != group_name}
    names = {g.index: g.name for g in target_mesh.vertex_groups}
    group = target_mesh.vertex_groups.get(group_name) or target_mesh.vertex_groups.new(name=group_name)
    carried = 0
    touched = []
    from . import band_width
    mask = target_mesh.vertex_groups.get(band_width.MASK_PREFIX)
    # where a locked band sits in the neutral pose before its weights change: the
    # relock below puts it back there (helper bones need not be at rest in that pose)
    before = band_width.neutral_positions(target_mesh) if mask is not None else None
    pool = indices if indices is not None else range(len(target_mesh.data.vertices))
    for i in pool:
        co, j, d = kd.find(tmw @ target_mesh.data.vertices[i].co)
        if j is None or d * 1000.0 > max_mm:
            continue
        w = weights[j]
        for e in target_mesh.data.vertices[i].groups:
            if names.get(e.group) in deform:
                target_mesh.vertex_groups[e.group].add([i], e.weight * (1.0 - w), "REPLACE")
        group.add([i], w, "REPLACE")
        _dilute_other_rigs(target_mesh, armature, i, w, null_bone)
        carried += 1
        touched.append(i)
    report = {"carried": carried, "group": group_name}
    # A band whose width is locked moves each section as one: per-vertex shares tore
    # MIK_131's cuff bands (width error 45 %, edges stretched 8.5 times at 60 degrees).
    # Lock the touched bands again so each section takes one set of weights.
    if mask is not None and touched:
        in_mask = {v.index for v in target_mesh.data.vertices
                   if any(e.group == mask.index and e.weight > 0.5 for e in v.groups)}
        hit = [i for i in touched if i in in_mask]
        if hit:
            find = band_width._islands(target_mesh)
            roots = {find(i) for i in hit}
            chain = {g.index for g in target_mesh.vertex_groups if g.name.startswith(band_width.CHAIN_PREFIXES)}
            ids = [i for i in in_mask if find(i) in roots
                   and not any(e.group in chain and e.weight > 0.0 for e in target_mesh.data.vertices[i].groups)]
            sections, found = band_width.guess_sections(target_mesh, ids)
            locked, error = band_width.lock_width(target_mesh, sections, rest=before)
            report["relocked_sections"] = len(sections) if not error else 0
            report["relock"] = error or found
    return report, ""


def swing_follow(armature, mesh_object, indices, forearm_bone, hand_bone, name="cuff_swing", share=1.0,
                 fade_mm=140.0, null_bone="null_bend.x"):
    """A bend-only follower at the wrist and the cuff's share of it. ``(report, error)``.

    The follower is a deform bone at the hand (same head, tail, roll), child of
    ``forearm_bone``, with a Damped Track at the hand's tail: it turns with every
    bend of the hand and not with its twist. Each cuff vertex gets ``share`` of it at
    the cuff's edge (the vertex furthest along the forearm), fading with a smoothstep
    to 0 over ``fade_mm`` up the sleeve; the vertex's other deform weights on this
    rig are scaled by what is left, so its total stays the same.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Choose the rig first."
    fb = armature.data.bones.get(forearm_bone)
    hb = armature.data.bones.get(hand_bone)
    if fb is None or hb is None:
        return None, "The rig has no %s or %s." % (forearm_bone, hand_bone)
    if not indices:
        return None, "Select the cuff's vertices."
    side = hand_bone[-2:] if hand_bone[-2:] in (".l", ".r") else ""
    bone_name = "%s%s" % (name, side)
    # read the rest geometry NOW, as copies: leaving Edit Mode rebuilds the
    # armature's bones and a Bone fetched before it then reads freed memory --
    # measured: the cuff's weights came out scattered over the whole sleeve, and
    # differently on every run
    am = armature.matrix_world
    axis = ((am @ fb.tail_local) - (am @ fb.head_local)).normalized()
    wrist = (am @ hb.head_local).copy()
    fb = hb = None
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        hand = edit[hand_bone]
        follower = edit.get(bone_name) or edit.new(bone_name)
        follower.head, follower.tail, follower.roll = hand.head.copy(), hand.tail.copy(), hand.roll
        follower.parent = edit[forearm_bone]
        follower.use_connect = False
        follower.use_deform = True
        coll = armature.data.collections_all.get(MCH_COLLECTION) or armature.data.collections.new(MCH_COLLECTION)
        coll.is_visible = False
        coll.assign(follower)
        bpy.ops.object.mode_set(mode="POSE")
        pose_bone = armature.pose.bones[bone_name]
        for con in list(pose_bone.constraints):
            pose_bone.constraints.remove(con)
        con = pose_bone.constraints.new("DAMPED_TRACK")
        con.name = "SRS bend only"
        con.target = armature
        con.subtarget = hand_bone
        con.head_tail = 1.0
        con.track_axis = "TRACK_Y"
    finally:
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous
    mw = mesh_object.matrix_world
    along = {i: ((mw @ mesh_object.data.vertices[i].co) - wrist).dot(axis) for i in indices}
    edge = max(along.values())
    fade = max(1.0e-4, float(fade_mm) / 1000.0)
    deform = {b.name for b in armature.data.bones if b.use_deform and b.name != bone_name}
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    group = mesh_object.vertex_groups.get(bone_name) or mesh_object.vertex_groups.new(name=bone_name)
    weighted = diluted = 0
    for i in indices:
        x = max(0.0, min(1.0, 1.0 - (edge - along[i]) / fade))
        w = max(0.0, min(1.0, float(share))) * x * x * (3.0 - 2.0 * x)
        if w <= 1.0e-4:
            continue
        for entry in mesh_object.data.vertices[i].groups:
            if names.get(entry.group) in deform:
                mesh_object.vertex_groups[entry.group].add([i], entry.weight * (1.0 - w), "REPLACE")
        group.add([i], w, "REPLACE")
        diluted += _dilute_other_rigs(mesh_object, armature, i, w, null_bone)
        weighted += 1
    return {"bone": bone_name, "vertices": weighted, "diluted": diluted, "edge_mm": round(edge * 1000.0, 1),
            "share": float(share), "fade_mm": float(fade_mm)}, ""
