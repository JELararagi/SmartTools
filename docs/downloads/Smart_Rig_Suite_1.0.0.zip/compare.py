# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Compare Two: a snapshot of this file, and a background comparison of two .blend files.

In the add-on this module saves the snapshot (a copy of the scene as it is now, written into the
extension's user folder; the user's .blend is never written), starts one background Blender that
runs this same file as a script, follows it from a timer and keeps the small result for the panel.

Run as that script (``__main__``), it opens the first file, flattens every ID through RNA into
key/value rows -- everything but window managers, screens and workspaces, seven levels deep,
collections over 4000 items counted but not listed, floats rounded, meshes, actions and F-curve
keys as content hashes, a struct kept elsewhere (a bone's parent, a custom shape transform)
written as a reference instead of walked a second time, embedded node trees walked inside their
owner, derived listings (the scene's every object, the dependency graph) left out -- keeps a hash
and a compressed copy of each ID's rows, opens the second file and lists,
key by key, only the IDs whose hash differs. The evaluated world vertices of the chosen meshes are
compared in millimetres. The result is one small JSON file; nothing is saved into either .blend.

Why a .blend copy and a second process: the full table of a large character file runs to millions
of rows (6.84 million on a 499-ID character file, F-curve keys already hashed). Held in the user's
Blender, or written out as JSON, it costs gigabytes; a .blend copy is exact, and a clean background
Blender evaluates both sides under the same conditions.
"""

import array
import ast
import hashlib
import json
import math
import os
import re
import subprocess
import sys
import time
import traceback
import zlib

import bpy

SKIP_DEFAULT = (
    "rna_type", "session_uid", "original", "is_evaluated", "bl_rna", "is_runtime_data", "tag",
    "is_missing", "preview", "is_dirty", "bound_box", "pixels", "bindcode", "has_data",
)
MAX_DEPTH = 7
MAX_COLLECTION = 4000
UI_COLLECTIONS = frozenset({"window_managers", "screens", "workspaces"})
KEY_LIMIT = 400
VALUE_LIMIT = 300
TIME_LIMIT_S = 3600.0
VERTEX_LIMIT = 4000000
MEMORY_FLOOR_MB = 1536
SNAPSHOT_FILE = "snapshot.blend"
SNAPSHOT_INFO = "snapshot.json"
CURRENT_FILE = "current.blend"
REQUEST_FILE = "request.json"
RESULT_FILE = "result.json"
PROGRESS_FILE = "progress.json"
STOP_FILE = "stop.flag"
LOG_FILE = "worker.log"
MISSING = "<none>"
PATH_TAG = "PATH:"
REF_TAG = "REF:"
REF_LIST_LIMIT = 4000
# Listings Blender derives from other data instead of keeping them in the file: every object of the
# scene and of a collection tree (each collection keeps its own members in "objects") and the view
# layer's evaluated dependency graph.  Listed by index, one added object shifts every later row.
DERIVED = {"Scene": frozenset({"objects"}), "Collection": frozenset({"all_objects"}),
           "ViewLayer": frozenset({"depsgraph"})}
POINT_COLLECTIONS = frozenset({"keyframe_points", "sampled_points"})
# (property, values per point, array code) read with foreach_get; enums come back as ints
KEYFRAME_FIELDS = (
    ("co", 2, "f"), ("handle_left", 2, "f"), ("handle_right", 2, "f"),
    ("interpolation", 1, "i"), ("easing", 1, "i"), ("type", 1, "i"),
    ("handle_left_type", 1, "i"), ("handle_right_type", 1, "i"),
    ("amplitude", 1, "f"), ("back", 1, "f"), ("period", 1, "f"),
)
SAMPLE_FIELDS = (("co", 2, "f"),)
RUNTIME_KEY = re.compile(r"\.pose\.bones\[\d+\]\.(head|tail|length|matrix|matrix_channel)$")
CONSTRAINT_KEY = re.compile(r"\.pose\.bones\[(\d+)\]\.constraints")


# ---------------------------------------------------------------------------------------------
# shared helpers


def _write_text(path, text):
    """Write ``text`` next to ``path`` and move it into place; a reader holding the old file is retried."""
    partial = path + ".partial"
    with open(partial, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    for attempt in range(20):
        try:
            os.replace(partial, path)
            return
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(0.1)


def _write_json(path, data):
    _write_text(path, json.dumps(data, ensure_ascii=False, indent=1))


def _read_json(path):
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def _remove(path):
    try:
        os.remove(path)
    except OSError:
        pass


def _same_file(first, second):
    def norm(path):
        return os.path.normcase(os.path.normpath(path)) if path else ""
    return norm(first) == norm(second)


# ---------------------------------------------------------------------------------------------
# the background worker (runs as a script inside its own Blender)


class _Stop(Exception):
    """The panel asked to stop, or the Blender that started the comparison went away."""


def _process_alive(pid):
    if pid <= 0:
        return True
    if os.name == "nt":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.restype = ctypes.c_void_p
        kernel32.OpenProcess.argtypes = [ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32]
        kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        kernel32.WaitForSingleObject.restype = ctypes.c_uint32
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = kernel32.OpenProcess(0x00100000, False, int(pid))  # SYNCHRONIZE
        if not handle:
            return False
        try:
            return kernel32.WaitForSingleObject(handle, 0) == 0x102  # WAIT_TIMEOUT: still running
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(int(pid), 0)
    except OSError:
        return False
    return True


def _free_memory_mb():
    """Free physical memory in MB, or None where it cannot be read."""
    if os.name == "nt":
        import ctypes

        class _MemoryStatus(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_uint32), ("dwMemoryLoad", ctypes.c_uint32),
                        ("ullTotalPhys", ctypes.c_uint64), ("ullAvailPhys", ctypes.c_uint64),
                        ("ullTotalPageFile", ctypes.c_uint64), ("ullAvailPageFile", ctypes.c_uint64),
                        ("ullTotalVirtual", ctypes.c_uint64), ("ullAvailVirtual", ctypes.c_uint64),
                        ("ullAvailExtendedVirtual", ctypes.c_uint64)]

        status = _MemoryStatus()
        status.dwLength = ctypes.sizeof(_MemoryStatus)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return None
        return int(status.ullAvailPhys // (1024 * 1024))
    try:
        with open("/proc/meminfo", encoding="ascii") as handle:
            for line in handle:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except (OSError, ValueError):
        pass
    return None


class _Guard:
    def __init__(self, stop_path, parent):
        self.stop_path = stop_path
        self.parent = int(parent or 0)
        self.next = 0.0
        self.deadline = time.monotonic() + TIME_LIMIT_S + 60.0

    def check(self):
        now = time.monotonic()
        if now < self.next:
            return
        self.next = now + 1.0
        if now > self.deadline:
            raise _Stop("the comparison ran over %d minutes" % int(TIME_LIMIT_S // 60))
        if self.stop_path and os.path.exists(self.stop_path):
            raise _Stop("stopped from the panel")
        if not _process_alive(self.parent):
            raise _Stop("the Blender that started the comparison has closed")
        free = _free_memory_mb()
        if free is not None and free < MEMORY_FLOOR_MB:
            raise _Stop("free memory ran low (%d MB left)" % free)


class _Progress:
    def __init__(self, path):
        self.path = path
        self.next = 0.0

    def write(self, phase, done, total, force=False):
        now = time.monotonic()
        if not self.path or (not force and now < self.next):
            return
        self.next = now + 2.0
        try:
            _write_json(self.path, {"phase": phase, "done": int(done), "total": int(total)})
        except OSError:
            pass


def _id_name(idb):
    return getattr(idb, "name_full", "") or idb.name


def _scan_path(rna_path):
    """Top-level attribute names of an RNA path and where its last ``[...]`` starts (-1: none).
    Dots and brackets inside quoted keys -- bone names such as "arm.L[1]" -- are not counted."""
    names, current, depth, quote, escape, last_open = [], [], 0, None, False, -1
    for index, char in enumerate(rna_path):
        if quote:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == quote:
                quote = None
        elif char in "\"'":
            quote = char
        elif char == "[":
            if depth == 0:
                last_open = index
            depth += 1
        elif char == "]":
            depth -= 1
        elif depth == 0:
            if char == ".":
                names.append("".join(current))
                current = []
            else:
                current.append(char)
    names.append("".join(current))
    return names, last_open


def _last_name(rna_path):
    """'pose.bones["arm.L"].constraints["IK"]' -> 'constraints'."""
    return _scan_path(rna_path)[0][-1]


def _strip_index(rna_path):
    """'pose.bones["arm.L[1]"]' -> 'pose.bones'; None when the path does not end in an index."""
    if not rna_path.endswith("]"):
        return None
    last_open = _scan_path(rna_path)[1]
    return rna_path[:last_open] if last_open > 0 else None


def _rna_path(struct):
    """``struct.path_from_id()``, or None where Blender keeps no path for that kind of struct."""
    try:
        return struct.path_from_id() or None
    except Exception:
        return None


def _ref_text(struct, holder, rna_path):
    """The row written for a struct kept elsewhere: its RNA path (and owning ID when another one)."""
    text = rna_path or "%s:%s" % (type(struct).__name__, getattr(struct, "name", "") or "")
    return REF_TAG + (_id_name(holder) + ":" if holder is not None else "") + text


def _label(item):
    if isinstance(item, bpy.types.ID):
        return "ID:" + _id_name(item)
    name = getattr(item, "name", None)
    if isinstance(name, str):
        return name
    return _rna_path(item) or type(item).__name__


class _Table:
    """Flatten one ID into ``{key: text}`` rows."""

    def __init__(self, skip, digits, base_dir):
        self.skip = frozenset(skip)
        self.digits = int(digits)
        self.base_dir = base_dir

    def value(self, value):
        if isinstance(value, float):
            return repr(round(value, self.digits) + 0.0)  # + 0.0 turns -0.0 into 0.0
        if isinstance(value, (bool, int, str)) or value is None:
            return repr(value)
        if isinstance(value, (set, frozenset)):
            return repr(sorted(self.value(item) for item in value))
        try:
            return repr([self.value(item) for item in value])
        except TypeError:
            return repr(value)

    def path(self, text):
        # A copy saved elsewhere spells a relative path differently; keep both spellings.
        absolute = os.path.join(self.base_dir, text[2:]) if text.startswith("//") else text
        if absolute:
            absolute = os.path.normcase(os.path.normpath(absolute))
        return PATH_TAG + json.dumps([absolute, text], ensure_ascii=False)

    def _reference(self, val, name, here, owner, editable):
        """None when the non-ID struct ``val`` is stored at attribute ``name`` of the struct being
        walked (RNA path ``here``, None when Blender cannot tell); otherwise the text written in its
        place.  Walking a reference would file the struct's rows under the wrong owner -- a bone's
        constraints under another bone's custom_shape_transform -- and ``seen`` would then keep them
        out of their own place."""
        try:
            holder = val.id_data
        except Exception:
            holder = None
        try:
            foreign = holder is not None and owner is not None and holder.as_pointer() != owner
        except Exception:
            foreign = False
        rna_path = _rna_path(val)
        if foreign:
            return _ref_text(val, holder, rna_path)
        if rna_path is None:
            # No path from Blender: an editable pointer always points at a struct kept elsewhere
            # (active_layer_collection, FCurve.group, Node.parent); a read-only one is walked.
            return _ref_text(val, None, None) if editable else None
        if here is None:
            stored = _last_name(rna_path) == name
        else:
            stored = rna_path == (here + "." + name if here else name)
        return None if stored else _ref_text(val, None, rna_path)

    def _item_reference(self, item, name, here, owner):
        """True when collection ``name`` lists structs kept elsewhere, judged on its first item."""
        try:
            holder = item.id_data
            if holder is not None and owner is not None and holder.as_pointer() != owner:
                return True
        except Exception:
            pass
        rna_path = _rna_path(item)
        parent = _strip_index(rna_path) if rna_path else None
        if parent is None:
            return False
        if here is None:
            return _last_name(parent) != name
        return parent != (here + "." + name if here else name)

    def walk(self, obj, path, depth, flat, seen, owner=None, via_pointer=False):
        try:
            pointer = obj.as_pointer()
        except Exception:
            pointer = None
        if pointer is not None:
            # A struct reached through a pointer property can share its owner's memory
            # (Object.display, World.mist_settings, BoneColor.custom): the address alone would
            # mistake it for the owner and drop its rows, so its type is part of the mark.
            # Collection items stay marked by address, so two views of one array
            # (Mesh.vertices and the "position" attribute) are listed once, as before.
            marker = (pointer, type(obj).__name__) if via_pointer else pointer
            if marker in seen:
                return
            seen.add(marker)
        try:
            props = obj.bl_rna.properties
        except Exception:
            return
        is_id = isinstance(obj, bpy.types.ID)
        if is_id:
            here = ""
            owner = pointer
        else:
            here = False  # worked out on first use: most structs never need it
            if owner is None:
                try:
                    owner = obj.id_data.as_pointer()
                except Exception:
                    owner = None
        derived = DERIVED.get(type(obj).__name__, ())
        for prop in props:
            name = prop.identifier
            if name in self.skip or name in derived:
                continue
            try:
                val = getattr(obj, name)
            except Exception:
                continue
            key = path + "." + name
            kind = prop.type
            if kind == "POINTER":
                if val is None:
                    flat[key] = "None"
                elif isinstance(val, bpy.types.ID):
                    flat[key] = "ID:" + type(val).__name__ + ":" + _id_name(val)
                    # A material's node tree and the scene's master collection live inside their
                    # owner and are listed nowhere else in bpy.data.  Only the owner ID's own field
                    # walks them: LayerCollection.collection merely points at the master collection.
                    if is_id and depth < MAX_DEPTH and getattr(val, "is_embedded_data", False):
                        self.walk(val, key, depth + 1, flat, seen, None, True)
                elif depth < MAX_DEPTH:
                    if here is False:
                        here = _rna_path(obj)
                    ref = self._reference(val, name, here, owner, not prop.is_readonly)
                    if ref is None:
                        self.walk(val, key, depth + 1, flat, seen, owner, True)
                    else:
                        flat[key] = ref
            elif kind == "COLLECTION":
                try:
                    count = len(val)
                except Exception:
                    continue
                flat[key + "#len"] = str(count)
                if name in POINT_COLLECTIONS:
                    # F-curve keys as one content hash: walked key by key, a character file's
                    # actions alone are millions of rows and take tens of minutes.
                    try:
                        flat[key + "#hash"] = _points_hash(val, name)
                    except Exception:
                        pass
                    continue
                if count > MAX_COLLECTION or depth >= MAX_DEPTH:
                    continue
                first = next((item for item in val if not isinstance(item, bpy.types.ID)), None)
                if first is not None:
                    if here is False:
                        here = _rna_path(obj)
                    if self._item_reference(first, name, here, owner):
                        # A list of structs kept elsewhere (Bone.children, BoneCollection.bones,
                        # Mesh.color_attributes): their names, not a second copy of their rows.
                        # A long one (ShapeKey.points names every point by path) is kept as a hash.
                        text = self.value([_label(item) for item in val])
                        if len(text) > REF_LIST_LIMIT:
                            text = "sha256:%s (%d)" % (hashlib.sha256(text.encode("utf-8")).hexdigest()[:24], count)
                        flat[key + "#refs"] = text
                        continue
                for index, item in enumerate(val):
                    item_key = "%s[%d]" % (key, index)
                    if isinstance(item, bpy.types.ID):
                        flat[item_key] = "ID:" + _id_name(item)
                    else:
                        self.walk(item, item_key, depth + 1, flat, seen, owner)
            elif kind == "STRING" and isinstance(val, str) and prop.subtype in {"FILE_PATH", "DIR_PATH"}:
                flat[key] = self.path(val)
            else:
                try:
                    flat[key] = self.value(val)
                except Exception:
                    pass
        try:
            custom_keys = list(obj.keys())
        except Exception:
            custom_keys = []
        for custom in custom_keys:
            key = path + '["' + custom + '"]'
            try:
                item = obj[custom]
                if hasattr(item, "to_dict"):
                    flat[key] = json.dumps(item.to_dict(), sort_keys=True, default=str)
                else:
                    flat[key] = self.value(item)
            except Exception:
                try:
                    flat[key] = str(obj[custom])
                except Exception:
                    pass


def _hash_buffer(collection, attribute, count, code):
    buffer = array.array(code, bytes(array.array(code).itemsize * count))
    if count:
        collection.foreach_get(attribute, buffer)
    return hashlib.sha256(buffer.tobytes()).hexdigest()[:20]


def _points_hash(points, name):
    """Content hash of an F-curve's keyframe_points / sampled_points (selection left out)."""
    count = len(points)
    digest = hashlib.sha256()
    fields = KEYFRAME_FIELDS if name == "keyframe_points" else SAMPLE_FIELDS
    for attribute, width, code in fields:
        buffer = array.array(code, bytes(array.array(code).itemsize * width * count))
        if count:
            points.foreach_get(attribute, buffer)
        digest.update(buffer.tobytes())
    return digest.hexdigest()[:20]


def _mesh_rows(mesh, flat):
    flat["#co"] = _hash_buffer(mesh.vertices, "co", 3 * len(mesh.vertices), "f")
    flat["#loops_v"] = _hash_buffer(mesh.loops, "vertex_index", len(mesh.loops), "i")
    for layer in mesh.uv_layers:
        flat["#uv:" + layer.name] = _hash_buffer(layer.data, "uv", 2 * len(layer.data), "f")
    digest = hashlib.sha256()
    for vertex in mesh.vertices:
        for group in vertex.groups:
            digest.update(("%d:%d:%.6f;" % (vertex.index, group.group, group.weight)).encode())
    flat["#weights"] = digest.hexdigest()[:20]
    if mesh.shape_keys:
        for block in mesh.shape_keys.key_blocks:
            flat["#sk:" + block.name] = _hash_buffer(block.data, "co", 3 * len(block.data), "f")


def _action_curves(action):
    curves = []
    for layer in getattr(action, "layers", ()):
        for strip in layer.strips:
            for bag in getattr(strip, "channelbags", ()):
                curves.extend(bag.fcurves)
    return curves


def _action_rows(action, flat):
    for curve in _action_curves(action):
        flat["#fc:%s|%d" % (curve.data_path, curve.array_index)] = _points_hash(curve.keyframe_points, "keyframe_points")


def _collections():
    return [prop.identifier for prop in bpy.data.bl_rna.properties
            if prop.type == "COLLECTION" and prop.identifier not in UI_COLLECTIONS]


def _id_rows(table, idb):
    flat = {}
    table.walk(idb, "", 0, flat, set())
    if isinstance(idb, bpy.types.Mesh):
        _mesh_rows(idb, flat)
    elif isinstance(idb, bpy.types.Action):
        _action_rows(idb, flat)
    return flat


def _signature(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:24]


def _open(path, frame):
    result = bpy.ops.wm.open_mainfile(filepath=path, load_ui=False, use_scripts=False)
    if "FINISHED" not in result:
        raise RuntimeError("Blender could not open %s" % path)
    scene = bpy.context.scene
    if frame is not None and scene is not None:
        scene.frame_set(int(frame))


def _same(first, second):
    if first == second:
        return True
    if first.startswith(PATH_TAG) and second.startswith(PATH_TAG):
        try:
            a = json.loads(first[len(PATH_TAG):])
            b = json.loads(second[len(PATH_TAG):])
        except ValueError:
            return False
        return a[0] == b[0] or a[1] == b[1]
    return False


def _display(text):
    if text.startswith(PATH_TAG):
        try:
            text = repr(json.loads(text[len(PATH_TAG):])[1])
        except (ValueError, IndexError):
            pass
    return text if len(text) <= VALUE_LIMIT else text[:VALUE_LIMIT] + "..."


def _numbers(text):
    """The floats inside a row value (nested reprs of lists), or None."""
    try:
        value = ast.literal_eval(text)
    except Exception:
        return None
    out = []

    def visit(item):
        if isinstance(item, str):
            visit(ast.literal_eval(item))
        elif isinstance(item, (list, tuple)):
            for part in item:
                visit(part)
        elif isinstance(item, (int, float)) and not isinstance(item, bool):
            out.append(float(item))
        else:
            raise ValueError(item)

    try:
        visit(value)
    except Exception:
        return None
    return out


def _max_abs(first, second):
    a = _numbers(first) if first is not None else None
    b = _numbers(second) if second is not None else None
    if not a or not b or len(a) != len(b):
        return None
    return max(abs(p - q) for p, q in zip(a, b))


def _plain(text):
    try:
        value = ast.literal_eval(text)
    except Exception:
        return text
    return value if isinstance(value, str) else text


def _difference(first, second, type_name):
    keys = [key for key in sorted(set(first) | set(second))
            if not _same(first.get(key, MISSING), second.get(key, MISSING))]
    if not keys:
        return None
    classes = {}
    shown = {}
    runtime_max = None
    runtime_unparsed = 0
    for key in keys:
        match = CONSTRAINT_KEY.match(key)
        if match:
            name_key = ".pose.bones[%s].name" % match.group(1)
            bone = _plain(second.get(name_key) or first.get(name_key) or "'?'")
            group = "constraint:" + bone
        elif RUNTIME_KEY.search(key):
            group = "runtime_pose_eval"
            delta = _max_abs(first.get(key), second.get(key))
            if delta is None:
                runtime_unparsed += 1
            else:
                runtime_max = delta if runtime_max is None else max(runtime_max, delta)
        else:
            group = "other"
        classes[group] = classes.get(group, 0) + 1
        if len(shown) < KEY_LIMIT:
            shown[key] = [_display(first.get(key, MISSING)), _display(second.get(key, MISSING))]
    record = {"type": type_name, "n_keys_changed": len(keys), "classes": classes, "keys": shown}
    if runtime_max is not None:
        record["runtime_max_abs"] = runtime_max
    if runtime_unparsed:
        record["runtime_unparsed"] = runtime_unparsed
    return record


def _to_world(local, matrix):
    (a, b, c, d), (e, f, g, h), (i, j, k, m) = tuple(matrix[0]), tuple(matrix[1]), tuple(matrix[2])
    out = array.array("d", bytes(8 * len(local)))
    for n in range(0, len(local), 3):
        x = local[n]
        y = local[n + 1]
        z = local[n + 2]
        out[n] = a * x + b * y + c * z + d
        out[n + 1] = e * x + f * y + g * z + h
        out[n + 2] = i * x + j * y + k * z + m
    return out


def _shape_capture(names, limit, guard):
    """Evaluated world vertices of the measured meshes, Subdivision and Multires off."""
    scene = bpy.context.scene
    scale = float(scene.unit_settings.scale_length) if scene is not None else 1.0
    shapes = {}
    if names:
        objects = []
        for name in names:
            obj = bpy.data.objects.get(name)
            if obj is None or obj.type != "MESH":
                shapes[name] = {"status": "missing"}
            else:
                objects.append(obj)
    else:
        objects = [obj for obj in bpy.data.objects if obj.type == "MESH" and obj.find_armature() is not None]
    objects.sort(key=lambda obj: obj.name)
    for obj in objects:
        for modifier in obj.modifiers:
            if modifier.type in {"SUBSURF", "MULTIRES"} and modifier.show_viewport:
                modifier.show_viewport = False
    if not objects:
        return shapes, scale
    depsgraph = bpy.context.evaluated_depsgraph_get()
    total = 0
    for obj in objects:
        guard.check()
        evaluated = obj.evaluated_get(depsgraph)
        mesh = evaluated.to_mesh()
        try:
            count = len(mesh.vertices)
            if total + count > limit:
                shapes[obj.name] = {"status": "over_limit", "verts": count}
                continue
            total += count
            local = array.array("f", bytes(12 * count))
            if count:
                mesh.vertices.foreach_get("co", local)
            shapes[obj.name] = {"status": "ok", "verts": count, "co": _to_world(local, evaluated.matrix_world)}
        finally:
            evaluated.to_mesh_clear()
    return shapes, scale


def _shape_compare(first, second, scale_a, scale_b):
    meshes = {}
    best = None
    for name in sorted(set(first) | set(second)):
        a = first.get(name)
        b = second.get(name)
        if a is None or b is None:
            meshes[name] = {"status": "only_b" if a is None else "only_a"}
            continue
        if a["status"] != "ok" or b["status"] != "ok":
            meshes[name] = {"status": a["status"] if a["status"] != "ok" else b["status"],
                            "verts_a": a.get("verts"), "verts_b": b.get("verts")}
            continue
        if a["verts"] != b["verts"]:
            meshes[name] = {"status": "vertex_count_differs", "verts_a": a["verts"], "verts_b": b["verts"]}
            continue
        ca, cb = a["co"], b["co"]
        worst = 0.0
        for n in range(0, len(ca), 3):
            dx = ca[n] - cb[n]
            dy = ca[n + 1] - cb[n + 1]
            dz = ca[n + 2] - cb[n + 2]
            squared = dx * dx + dy * dy + dz * dz
            if squared > worst:
                worst = squared
        mm = math.sqrt(worst) * scale_b * 1000.0
        meshes[name] = {"status": "ok", "verts": a["verts"], "max_mm": round(mm, 4)}
        best = mm if best is None else max(best, mm)
    if not meshes:
        status = "none"
    elif best is None:
        status = "incomparable"
    else:
        status = "ok"
    return {"status": status, "max_mm": round(best, 4) if best is not None else None, "meshes": meshes,
            "unit_scale_a": scale_a, "unit_scale_b": scale_b}


def _run(request, result):
    guard = _Guard(request.get("stop"), request.get("parent"))
    progress = _Progress(request.get("progress"))
    digits = int(request.get("digits") or 7)
    skip = list(request.get("skip") or SKIP_DEFAULT)
    frame = request.get("frame")
    meshes = list(request.get("meshes") or ())
    limit = int(request.get("vertex_limit") or VERTEX_LIMIT)

    progress.write("first", 0, 0, force=True)
    _open(request["a"], frame)
    table = _Table(skip, digits, os.path.dirname(request["a"]))
    names = _collections()
    total = sum(len(getattr(bpy.data, name)) for name in names)
    first = {}
    items_a = 0
    done = 0
    for collection in names:
        for idb in getattr(bpy.data, collection):
            guard.check()
            flat = _id_rows(table, idb)
            text = json.dumps(flat, sort_keys=True, ensure_ascii=False)
            first["%s:%s" % (collection, _id_name(idb))] = (
                type(idb).__name__, _signature(text), zlib.compress(text.encode("utf-8"), 6))
            items_a += len(flat)
            done += 1
            progress.write("first", done, total)
    progress.write("shape", 0, 0, force=True)
    shape_a, scale_a = _shape_capture(meshes, limit, guard)

    progress.write("second", 0, 0, force=True)
    _open(request["b"], frame)
    table = _Table(skip, digits, os.path.dirname(request["b"]))
    names = _collections()
    total = sum(len(getattr(bpy.data, name)) for name in names)
    seen = set()
    changed = {}
    only_b = []
    spelling_only = []
    items_b = 0
    done = 0
    for collection in names:
        for idb in getattr(bpy.data, collection):
            guard.check()
            key = "%s:%s" % (collection, _id_name(idb))
            flat = _id_rows(table, idb)
            text = json.dumps(flat, sort_keys=True, ensure_ascii=False)
            items_b += len(flat)
            seen.add(key)
            done += 1
            progress.write("second", done, total)
            entry = first.get(key)
            if entry is None:
                only_b.append(key)
                continue
            if entry[1] == _signature(text):
                continue
            record = _difference(json.loads(zlib.decompress(entry[2]).decode("utf-8")), flat, type(idb).__name__)
            if record is None:
                spelling_only.append(key)
            else:
                changed[key] = record
    progress.write("shape", 0, 0, force=True)
    shape_b, scale_b = _shape_capture(meshes, limit, guard)
    shape = _shape_compare(shape_a, shape_b, scale_a, scale_b)

    by_type = {}
    runtime_items = 0
    runtime_max = None
    for record in changed.values():
        by_type[record["type"]] = by_type.get(record["type"], 0) + 1
        runtime_items += record["classes"].get("runtime_pose_eval", 0)
        if "runtime_max_abs" in record:
            value = record["runtime_max_abs"]
            runtime_max = value if runtime_max is None else max(runtime_max, value)
    result.update({
        "status": "ok",
        "ids_a": len(first), "ids_b": len(seen), "items_a": items_a, "items_b": items_b,
        "only_a": sorted(set(first) - seen), "only_b": sorted(only_b),
        "changed": changed, "n_changed_ids": len(changed),
        "by_type": dict(sorted(by_type.items(), key=lambda item: (-item[1], item[0]))),
        "path_spelling_only": sorted(spelling_only),
        "runtime_items": runtime_items, "runtime_max_abs": runtime_max,
        "shape": shape, "shape_max_mm": shape["max_mm"],
    })


def _worker_main(argv):
    started = time.monotonic()
    request_path = argv[argv.index("--request") + 1]
    with open(request_path, encoding="utf-8") as handle:
        request = json.load(handle)
    result = {
        "version": 1, "status": "error", "error": "",
        "a": {"path": request.get("a", ""), "label": request.get("a_label", "")},
        "b": {"path": request.get("b", ""), "label": request.get("b_label", "")},
        "frame": request.get("frame"), "digits": int(request.get("digits") or 7),
        "skip": list(request.get("skip") or SKIP_DEFAULT), "meshes": list(request.get("meshes") or ()),
        "blender": bpy.app.version_string,
    }
    try:
        _run(request, result)
    except _Stop as exc:
        result["status"] = "stopped"
        result["error"] = str(exc)
    except Exception as exc:
        result["status"] = "error"
        result["error"] = "%s: %s" % (type(exc).__name__, exc)
        result["traceback"] = traceback.format_exc()[-4000:]
    result["seconds"] = round(time.monotonic() - started, 1)
    _write_json(request["out"], result)


# ---------------------------------------------------------------------------------------------
# the add-on side


_STATE = {"proc": None, "log": None, "started": 0.0, "root": "", "progress": None, "labels": ("", "")}
_LAST = {"result": None, "error": "", "when": 0.0}
_SNAPSHOT = {"loaded": False, "info": None}
_REGISTERED = False


def folder(create=True):
    """The add-on's own folder for the snapshot and the run files."""
    return bpy.utils.extension_path_user(__package__, path="compare", create=create)


def is_running():
    return _STATE.get("proc") is not None


def last_result():
    return _LAST.get("result")


def snapshot_info():
    if not _SNAPSHOT["loaded"]:
        _SNAPSHOT["loaded"] = True
        try:
            info = _read_json(os.path.join(folder(create=False), SNAPSHOT_INFO))
        except Exception:
            info = None
        if isinstance(info, dict) and os.path.isfile(str(info.get("path") or "")):
            _SNAPSHOT["info"] = info
    return _SNAPSHOT["info"]


def status():
    """What the panel's one line shows: running, failed, done, a snapshot, or nothing yet."""
    if _STATE.get("proc") is not None:
        progress = _STATE.get("progress") or {}
        return {"state": "running", "phase": str(progress.get("phase") or ""),
                "done": int(progress.get("done") or 0), "total": int(progress.get("total") or 0),
                "seconds": int(time.monotonic() - _STATE.get("started", time.monotonic()))}
    if _LAST.get("error"):
        return {"state": "failed", "error": _LAST["error"]}
    if _LAST.get("result") is not None:
        return {"state": "done", "result": _LAST["result"]}
    info = snapshot_info()
    if info is not None and _same_file(info.get("source"), bpy.data.filepath):
        return {"state": "snapshot", "time": str(info.get("time") or ""), "frame": info.get("frame")}
    return {"state": "idle"}


def _save_copy(path):
    try:
        outcome = bpy.ops.wm.save_as_mainfile(filepath=path, copy=True, check_existing=False, relative_remap=True,
                                              compress=True)
    except Exception as exc:
        return "%s: %s" % (type(exc).__name__, exc)
    if "FINISHED" not in outcome:
        return "Blender did not save the copy"
    if not os.path.isfile(path):
        return "the copy is missing after saving"
    _remove(path + "1")  # Save Versions keeps the replaced copy as .blend1; it would double the folder for nothing
    return ""


def take_snapshot(context):
    """Save the scene as it is now into the add-on's folder. Returns ``(info, error)``."""
    if is_running():
        return None, "A comparison is running. Stop it before taking a snapshot."
    try:
        root = folder()
    except Exception as exc:
        return None, "No user folder for this extension: %s" % exc
    path = os.path.join(root, SNAPSHOT_FILE)
    error = _save_copy(path)
    if error:
        return None, "The snapshot could not be saved: %s" % error
    scene = context.scene
    info = {"source": bpy.data.filepath, "frame": int(scene.frame_current), "scene": scene.name,
            "time": time.strftime("%Y-%m-%d %H:%M:%S"), "path": path}
    try:
        _write_json(os.path.join(root, SNAPSHOT_INFO), info)
    except OSError as exc:
        return None, "The snapshot could not be saved: %s" % exc
    _SNAPSHOT.update(loaded=True, info=info)
    return info, ""


def _redraw():
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()
    except Exception:
        pass


def _kill():
    proc = _STATE.get("proc")
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.kill()
        proc.wait(timeout=10)
    except Exception:
        pass


def _finish(error=""):
    """Read the worker's result and clear the run files; the snapshot stays."""
    proc = _STATE.get("proc")
    code = proc.returncode if proc is not None else None
    log = _STATE.get("log")
    if log is not None:
        try:
            log.close()
        except Exception:
            pass
    root = _STATE.get("root") or ""
    result = None
    if not error:
        result = _read_json(os.path.join(root, RESULT_FILE))
        if not isinstance(result, dict):
            error = "The background Blender ended without a result (exit code %s)." % code
            result = None
        elif result.get("status") != "ok":
            error = str(result.get("error") or "the comparison did not finish")
            result = None
    _LAST.update(result=result, error=error, when=time.time())
    leftovers = [CURRENT_FILE, REQUEST_FILE, PROGRESS_FILE, STOP_FILE, PROGRESS_FILE + ".partial"]
    if not error:
        leftovers.append(LOG_FILE)  # kept after a failure: it holds the background Blender's traceback
    for name in leftovers:
        _remove(os.path.join(root, name))
    _STATE.update(proc=None, log=None, progress=None)


def _poll():
    try:
        proc = _STATE.get("proc")
        if proc is None:
            return None
        if proc.poll() is None:
            if time.monotonic() - _STATE.get("started", 0.0) > TIME_LIMIT_S:
                _kill()
                _finish(error="The comparison ran over %d minutes and was stopped." % int(TIME_LIMIT_S // 60))
                _redraw()
                return None
            progress = _read_json(os.path.join(_STATE.get("root") or "", PROGRESS_FILE))
            if isinstance(progress, dict):
                _STATE["progress"] = progress
            _redraw()
            return 1.0
        _finish()
        _redraw()
    except Exception as exc:
        _LAST.update(result=None, error="%s: %s" % (type(exc).__name__, exc), when=time.time())
        _STATE.update(proc=None, log=None, progress=None)
    return None


def _stop_timer():
    try:
        if bpy.app.timers.is_registered(_poll):
            bpy.app.timers.unregister(_poll)
    except Exception:
        pass


def stop(reason="Stopped."):
    """End a running comparison. Returns True when one was running."""
    if _STATE.get("proc") is None:
        return False
    root = _STATE.get("root") or ""
    try:
        open(os.path.join(root, STOP_FILE), "w").close()
    except OSError:
        pass
    _kill()
    _stop_timer()
    _finish(error=reason)
    return True


def _shutdown():
    stop("The add-on was turned off.")
    _stop_timer()


def start(context, settings, *, wait=False):
    """Start the background comparison. Returns ``(state, error)``; state is "started" or "finished"."""
    if is_running():
        return "", "A comparison is already running."
    if not bpy.app.binary_path:
        return "", "This Blender has no program file to start in the background."
    try:
        root = folder()
    except Exception as exc:
        return "", "No user folder for this extension: %s" % exc
    current = os.path.join(root, CURRENT_FILE)
    scene = context.scene
    other = str(getattr(settings, "compare_file", "") or "").strip()
    if other:
        if other.startswith("//") and not bpy.data.filepath:
            return "", "Save the .blend first, or choose the other file by its full path."
        b_path = os.path.normpath(bpy.path.abspath(other))
        if not b_path.lower().endswith(".blend") or not os.path.isfile(b_path):
            return "", "There is no .blend file at %s." % b_path
        if _same_file(b_path, current):
            return "", "Choose a .blend outside the add-on's compare folder."
        error = _save_copy(current)
        if error:
            return "", "This file could not be copied for the comparison: %s" % error
        a_path = current
        labels = ("this file now", os.path.basename(b_path))
    else:
        info = snapshot_info()
        if info is None:
            return "", "Take a snapshot first."
        if not _same_file(info.get("source"), bpy.data.filepath):
            name = os.path.basename(str(info.get("source") or "")) or "an unsaved file"
            return "", "The snapshot is of another file (%s). Take a new one." % name
        error = _save_copy(current)
        if error:
            return "", "This file could not be copied for the comparison: %s" % error
        a_path, b_path = str(info["path"]), current
        labels = ("snapshot %s, frame %s" % (str(info.get("time") or "")[11:16], info.get("frame")), "this file now")
    skip = [name.strip() for name in str(getattr(settings, "compare_skip", "") or "").split(",") if name.strip()]
    selected = getattr(context, "selected_objects", None) or ()
    request = {
        "a": a_path, "b": b_path, "a_label": labels[0], "b_label": labels[1],
        "out": os.path.join(root, RESULT_FILE), "progress": os.path.join(root, PROGRESS_FILE),
        "stop": os.path.join(root, STOP_FILE), "parent": os.getpid(),
        "frame": int(scene.frame_current), "digits": int(getattr(settings, "compare_digits", 7) or 7),
        "skip": skip or list(SKIP_DEFAULT),
        "meshes": sorted(obj.name for obj in selected if obj.type == "MESH"),
        "vertex_limit": VERTEX_LIMIT,
    }
    for name in (RESULT_FILE, PROGRESS_FILE, STOP_FILE):
        _remove(os.path.join(root, name))
    request_path = os.path.join(root, REQUEST_FILE)
    _write_json(request_path, request)
    argv = [bpy.app.binary_path, "--background", "--factory-startup", "--disable-autoexec",
            "--python", os.path.abspath(__file__), "--", "--request", request_path]
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "BELOW_NORMAL_PRIORITY_CLASS", 0)
    log = open(os.path.join(root, LOG_FILE), "w", encoding="utf-8", errors="replace")
    try:
        proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                cwd=root, creationflags=flags)
    except Exception as exc:
        log.close()
        _remove(current)
        return "", "Could not start the background Blender: %s" % exc
    _STATE.update(proc=proc, log=log, started=time.monotonic(), root=root, progress=None, labels=labels)
    _LAST.update(result=None, error="", when=0.0)
    if wait:
        try:
            proc.wait(timeout=TIME_LIMIT_S)
        except subprocess.TimeoutExpired:
            _kill()
            _finish(error="The comparison ran over %d minutes and was stopped." % int(TIME_LIMIT_S // 60))
            return "finished", _LAST["error"]
        _finish()
        return "finished", _LAST["error"]
    try:
        bpy.app.timers.register(_poll, first_interval=0.5, persistent=True)
        from . import generation
        generation.track_timer(_poll, module_name=__name__)
    except Exception:
        pass
    return "started", ""


def summary(result):
    """The numbers of the panel's line, shared by the panel and the Markdown file."""
    shape = result.get("shape") or {}
    return {
        "changed": int(result.get("n_changed_ids") or 0),
        "types": list((result.get("by_type") or {}).items()),
        "only_a": len(result.get("only_a") or ()),
        "only_b": len(result.get("only_b") or ()),
        "ids": int(result.get("ids_b") or 0),
        "shape_mm": shape.get("max_mm"),
        "shape_meshes": sum(1 for item in (shape.get("meshes") or {}).values() if item.get("status") == "ok"),
        "runtime_items": int(result.get("runtime_items") or 0),
        "runtime_max": result.get("runtime_max_abs"),
    }


def markdown(result, tr):
    numbers = summary(result)
    a = result.get("a") or {}
    b = result.get("b") or {}
    lines = [
        "# " + tr("Compare Two", "2 つを比べる"),
        "",
        "- %s: %s (`%s`)" % (tr("First", "1 つ目"), a.get("label", ""), a.get("path", "")),
        "- %s: %s (`%s`)" % (tr("Second", "2 つ目"), b.get("label", ""), b.get("path", "")),
        "- %s %s · %s %s · %s %s s · Blender %s" % (
            tr("Frame", "フレーム"), result.get("frame"), tr("Digits", "桁数"), result.get("digits"),
            tr("Time", "所要"), result.get("seconds"), result.get("blender", "")),
        "- ID %s / %s · %s %s / %s" % (result.get("ids_a"), result.get("ids_b"), tr("Rows", "項目"),
                                       result.get("items_a"), result.get("items_b")),
        "",
        "## " + tr("Summary", "要約"),
        "",
        "- %s: %d (%s)" % (tr("Changed IDs", "変わった ID"), numbers["changed"],
                          ", ".join("%s %d" % item for item in numbers["types"]) or "-"),
        "- %s: %d · %s: %d" % (tr("Only in the first", "1 つ目だけ"), numbers["only_a"],
                              tr("Only in the second", "2 つ目だけ"), numbers["only_b"]),
        "- %s: %s (%s %d)" % (tr("Largest shape difference", "形の最大差"),
                             "-" if numbers["shape_mm"] is None else "%.4f mm" % numbers["shape_mm"],
                             tr("meshes", "メッシュ"), numbers["shape_meshes"]),
        "- %s: %d (%s %s)" % (tr("Evaluated pose rows", "評価後の姿勢の項目"), numbers["runtime_items"],
                             tr("largest", "最大"),
                             "-" if numbers["runtime_max"] is None else "%.3g" % numbers["runtime_max"]),
    ]
    for title, keys in ((tr("Only in the first", "1 つ目だけ"), result.get("only_a") or ()),
                        (tr("Only in the second", "2 つ目だけ"), result.get("only_b") or ())):
        if keys:
            lines += ["", "## " + title, ""] + ["- `%s`" % key for key in keys]
    changed = result.get("changed") or {}
    if changed:
        lines += ["", "## " + tr("Changed IDs", "変わった ID"), "",
                  "| ID | %s | %s | %s |" % (tr("type", "型"), tr("rows", "項目"), tr("kinds", "内訳")),
                  "|---|---|---|---|"]
        for key, record in changed.items():
            kinds = ", ".join("%s %d" % item for item in sorted(record.get("classes", {}).items()))
            lines.append("| `%s` | %s | %d | %s |" % (key, record.get("type", ""), record.get("n_keys_changed", 0), kinds))
    meshes = (result.get("shape") or {}).get("meshes") or {}
    if meshes:
        lines += ["", "## " + tr("Shape", "形"), "",
                  "| %s | %s | %s | mm |" % (tr("mesh", "メッシュ"), tr("vertices", "頂点"), tr("state", "状態")),
                  "|---|---|---|---|"]
        for name, item in meshes.items():
            verts = item.get("verts", "%s/%s" % (item.get("verts_a"), item.get("verts_b")))
            mm = "-" if item.get("max_mm") is None else "%.4f" % item["max_mm"]
            lines.append("| `%s` | %s | %s | %s |" % (name, verts, item.get("status", ""), mm))
    if changed:
        lines += ["", "## " + tr("Rows that differ (first 40 per ID)", "違う項目（ID ごとに最初の 40）")]
        for key, record in changed.items():
            lines += ["", "### `%s`" % key, ""]
            for row, (old, new) in list(record.get("keys", {}).items())[:40]:
                lines.append("- `%s`: `%s` → `%s`" % (row, old[:120], new[:120]))
    return "\n".join(lines) + "\n"


def export(folder_path, tr):
    """Write the last result as JSON and Markdown. Returns ``(paths, error)``."""
    result = _LAST.get("result")
    if result is None:
        return None, "No comparison to write yet."
    text = str(folder_path or "").strip() or "//"
    if text.startswith("//") and not bpy.data.filepath:
        return None, "Save the .blend first, or choose a folder by its full path."
    target = os.path.normpath(bpy.path.abspath(text))
    stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(_LAST.get("when") or time.time()))
    base = os.path.join(target, "srs_compare_" + stamp)
    try:
        os.makedirs(target, exist_ok=True)
        _write_json(base + ".json", result)
        _write_text(base + ".md", markdown(result, tr))
    except OSError as exc:
        return None, "Could not write the result: %s" % exc
    return (base + ".json", base + ".md"), ""


def register() -> bool:
    global _REGISTERED
    try:
        from . import generation
        generation.track_cleanup(_shutdown, module_name=__name__, label="stop a running comparison")
    except Exception:
        pass
    _REGISTERED = True
    return True


def unregister() -> dict:
    global _REGISTERED
    _shutdown()
    _REGISTERED = False
    return {}


if __name__ == "__main__":
    _worker_main(sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else [])
