# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""A garment that can be driven by bones or by cloth, with one switch.

The brief asks for exactly one part -- the skirt -- to work both ways and be
switchable, while everything else that hangs stays bone-driven. That shape is
what this module builds:

* the skin weights stay, untouched, so the garment is fully posable with the
  armature alone and exports that way;
* a Cloth modifier is added AFTER the armature modifiers, so the simulation runs
  on the already-posed garment rather than fighting it;
* the waistband is pinned through a vertex group with a soft edge, so the top of
  the skirt follows the hips exactly and only the free part swings;
* and both the viewport and the render flag of that modifier are driven from one
  custom property on the rig, so the animator flips a single switch instead of
  hunting through modifier stacks.

On Simply Cloth Studio: it was read in full for this project and it is a wrapper
over Blender's own cloth -- its presets write the same ``ClothSettings`` fields
through slider callbacks (``stiffness_slider`` maps to ``0.45 * v``). So setting
those fields directly is the same physics, minus a dependency the .blend would
otherwise carry. If Simply Cloth Studio is installed, its panel drives the same
modifier this module creates.
"""

import re

import bpy

SWITCH_PROPERTY = "srs_skirt_cloth"
# A character can bring its own several-state skirt switch (MIK: rig["skirt_mode"],
# 0 5-H / 1 cloth P2 / 2 baked gravity swing). It comes first, because it is the one
# the character's own drivers read.
MODE_PROPERTIES = ("skirt_mode", SWITCH_PROPERTY)
MAX_SWITCH_STATES = 10
CLOTH_MODIFIER = "SRS Cloth"
PIN_GROUP = "SRS Cloth Pin"
COLLISION_MODIFIER = "SRS Collision"
OWNER_KEY = "srs_cloth_colliders_of"


def waistband_pin(mesh_object, band_mm=90.0, hard_mm=25.0, name=PIN_GROUP):
    """Pin the top of a skirt, with a soft edge. ``(report, error)``.

    A hard pin line creases: the row above it cannot move at all and the row
    below is free, so the seam kinks on the first frame. The weight therefore
    falls off from 1.0 over ``band_mm``, fully pinned for the first ``hard_mm``.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    matrix = mesh_object.matrix_world
    heights = [(matrix @ v.co).z for v in mesh_object.data.vertices]
    if not heights:
        return None, "%s has no vertices" % mesh_object.name
    top = max(heights)
    group = mesh_object.vertex_groups.get(name)
    if group is None:
        group = mesh_object.vertex_groups.new(name=name)
    else:
        group.remove(list(range(len(mesh_object.data.vertices))))
    hard = hard_mm * 0.001
    band = max(band_mm * 0.001, hard + 1.0e-6)
    pinned, faded = 0, 0
    for index, height in enumerate(heights):
        depth = top - height
        if depth <= hard:
            group.add([index], 1.0, "REPLACE")
            pinned += 1
        elif depth < band:
            share = 1.0 - (depth - hard) / (band - hard)
            # smoothstep, so the edge of the pin has no visible step in it
            weight = share * share * (3.0 - 2.0 * share)
            group.add([index], max(0.0, min(1.0, weight)), "REPLACE")
            faded += 1
    return {"mesh": mesh_object.name, "group": name, "top_mm": round(top * 1000, 1),
            "pinned": pinned, "faded": faded,
            "band_mm": band_mm, "hard_mm": hard_mm}, ""


def _after_armature(mesh_object, modifier):
    """Move ``modifier`` to just behind the last Armature modifier.

    ``modifiers.new`` appends, which puts the new modifier behind a Subdivision
    -- for a cloth that means simulating four times the vertices, and for a
    collider it means the cloth meets a surface other than the posed cage. With
    no Armature modifier the stack is left as it is. Returns the index.
    """
    stack = list(mesh_object.modifiers)
    index = stack.index(modifier)
    armatures = [i for i, m in enumerate(stack)
                 if m.type == "ARMATURE" and m is not modifier]
    if armatures:
        # removing the modifier from in front of the armature shifts it up one
        want = armatures[-1] + 1 if index > armatures[-1] else armatures[-1]
        if index != want:
            mesh_object.modifiers.move(index, want)
    return list(mesh_object.modifiers).index(modifier)


def add_collision(mesh_object, thickness_mm=5.0, damping=0.2, inner_mm=2.0,
                  friction=5.0):
    """Let cloth collide with this mesh. Inert unless a simulation runs.

    The Collision modifier goes right behind the armature, so the cloth meets
    the posed skin, not the rest shape or the subdivided surface. The defaults
    are MIK_144's body collider (outer 5 mm, inner 2 mm, damping 0.2, friction
    5). The inner thickness is always set: Blender's own default is 200 mm,
    which on a body pushes out cloth that is anywhere within 20 cm inside it.

    A mesh carries at most one Collision modifier. One that somebody else put
    there (any other name) is used as it is: not moved, its settings untouched,
    and the report says ``"existing": True`` -- other simulations may depend on
    where it sits and how thick it is.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    foreign = next((m for m in mesh_object.modifiers if m.type == "COLLISION"
                    and m.name != COLLISION_MODIFIER), None)
    if foreign is not None:
        settings = mesh_object.collision
        return {"mesh": mesh_object.name, "modifier": foreign.name,
                "index": list(mesh_object.modifiers).index(foreign),
                "existing": True,
                "thickness_mm": round(settings.thickness_outer * 1000.0, 3)
                if settings is not None else None}, ""
    modifier = mesh_object.modifiers.get(COLLISION_MODIFIER)
    if modifier is None:
        modifier = mesh_object.modifiers.new(name=COLLISION_MODIFIER,
                                             type="COLLISION")
    index = _after_armature(mesh_object, modifier)
    settings = mesh_object.collision
    if settings is not None:
        settings.thickness_outer = max(0.001, thickness_mm * 0.001)
        settings.damping = damping
        if inner_mm is not None:
            settings.thickness_inner = max(0.001, inner_mm * 0.001)
        if friction is not None:
            settings.cloth_friction = float(friction)
    return {"mesh": mesh_object.name, "modifier": modifier.name,
            "index": index, "existing": False, "thickness_mm": thickness_mm}, ""


def collision_state(mesh_object):
    """What the cloth on ``mesh_object`` really collides with. ``(report, error)``.

    Read back from the file, so it is the same after a save and reload: the
    collection (``None`` = every Collision object in the scene), its members and
    whether each one has a Collision modifier, the collision quality, and where
    the cloth sits in the stack.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    modifier = mesh_object.modifiers.get(CLOTH_MODIFIER)
    if modifier is None:
        return None, "%s has no %s modifier yet" % (mesh_object.name,
                                                    CLOTH_MODIFIER)
    settings = modifier.collision_settings
    collection = settings.collection
    members = []
    if collection is not None:
        for obj in collection.all_objects:
            stack = list(obj.modifiers) if obj.type == "MESH" else []
            hit = next((m for m in stack if m.type == "COLLISION"), None)
            members.append({"name": obj.name,
                            "collision": hit.name if hit is not None else None,
                            "index": stack.index(hit) if hit is not None else None})
    return {"mesh": mesh_object.name,
            "collection": collection.name if collection is not None else None,
            "owned": _owned_by(collection, mesh_object),
            "members": members,
            "quality": settings.collision_quality,
            "self_collision": settings.use_self_collision,
            "cloth_index": list(mesh_object.modifiers).index(modifier),
            "stack": [m.type for m in mesh_object.modifiers]}, ""


def _cloth_users(collection):
    """Every (mesh, cloth modifier) whose collision collection is ``collection``."""
    out = []
    for obj in bpy.data.objects:
        if obj.type != "MESH":
            continue
        for modifier in obj.modifiers:
            if (modifier.type == "CLOTH"
                    and modifier.collision_settings.collection == collection):
                out.append((obj, modifier))
    return out


def _owned_by(collection, mesh_object):
    """True when ``collection`` is one this module made and only this garment's
    cloth uses it. Anything else -- a user's collection, one shared by two
    garments -- is never edited."""
    if collection is None or collection.get(OWNER_KEY) is None:
        return False
    return all(obj == mesh_object for obj, _m in _cloth_users(collection))


def _drop_unused_owned():
    """Remove collider collections this module made that no cloth uses any more
    and nothing else holds (only the fake user)."""
    dropped = []
    for collection in list(bpy.data.collections):
        if collection.get(OWNER_KEY) is None or _cloth_users(collection):
            continue
        if collection.users > (1 if collection.use_fake_user else 0):
            continue
        dropped.append(collection.name)
        bpy.data.collections.remove(collection)
    return dropped


def limit_colliders(mesh_object, colliders, name=None):
    """Let the cloth collide with ``colliders`` and nothing else. ``(report, error)``.

    Without a collection the cloth collides with every Collision object in the
    scene -- on a rig that also swings hair, the hair's collision capsules. Those
    are fitted to the dressed outline, so a skirt starts inside them and never
    meets the body. Measured on MIK (05_17, every other frame): skirt vertices
    more than 5 mm inside the body, mean 1,331 against the capsules alone, 27.5
    against body + shorts at collision quality 4.

    Each garment gets a collection of its own, marked as made here
    (``OWNER_KEY``), holding exactly ``colliders`` -- members not asked for and
    child collections are taken out, so re-running with other colliders changes
    the set rather than adding to it. A collection without the mark (a user's,
    whatever its name) or one another garment's cloth also uses is never edited:
    the garment gets a new collection instead, and the report names what it
    replaced. The collection stays out of the scene (its objects are already
    there) and gets a fake user, so saving does not drop it. Nothing is changed
    when the call is refused.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    modifier = mesh_object.modifiers.get(CLOTH_MODIFIER)
    if modifier is None:
        return None, "%s has no %s modifier yet" % (mesh_object.name,
                                                    CLOTH_MODIFIER)
    wanted = []
    for obj in colliders or ():
        if obj is None or obj.type != "MESH" or obj == mesh_object:
            return None, "Colliders must be meshes other than the garment"
        if obj not in wanted:
            wanted.append(obj)
    if not wanted:
        return None, "No collider meshes"
    missing = [o.name for o in wanted
               if not any(m.type == "COLLISION" for m in o.modifiers)]
    if missing:
        return None, "No Collision modifier on %s" % ", ".join(missing)
    settings = modifier.collision_settings
    current = settings.collection
    before = sorted(o.name for o in current.all_objects) if current is not None else None
    if _owned_by(current, mesh_object):
        collection, replaced = current, None
    else:
        replaced = current.name if current is not None else None
        collection = bpy.data.collections.new(
            name or "SRS Colliders %s" % mesh_object.name)
    collection[OWNER_KEY] = mesh_object.name
    for child in list(collection.children):
        collection.children.unlink(child)
    for obj in list(collection.objects):
        if obj not in wanted:
            collection.objects.unlink(obj)
    for obj in wanted:
        if collection.objects.get(obj.name) is None:
            collection.objects.link(obj)
    collection.use_fake_user = True
    settings.collection = collection
    dropped = _drop_unused_owned()
    after = sorted(o.name for o in collection.all_objects)
    return {"mesh": mesh_object.name, "collection": collection.name,
            "members": after, "replaced": replaced, "dropped": dropped,
            "changed": before != after or replaced is not None}, ""


def release_colliders(mesh_object):
    """Undo :func:`limit_colliders`: the cloth meets every collider again.
    ``(report, error)``. Only a collection this module made for this garment is
    released (and removed once nothing uses it); a user's collection stays."""
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    modifier = mesh_object.modifiers.get(CLOTH_MODIFIER)
    if modifier is None:
        return None, "%s has no %s modifier yet" % (mesh_object.name,
                                                    CLOTH_MODIFIER)
    settings = modifier.collision_settings
    current = settings.collection
    if current is None:
        return {"mesh": mesh_object.name, "released": None, "kept": None,
                "dropped": []}, ""
    if not _owned_by(current, mesh_object):
        return {"mesh": mesh_object.name, "released": None, "kept": current.name,
                "dropped": []}, ""
    name = current.name
    settings.collection = None
    return {"mesh": mesh_object.name, "released": name, "kept": None,
            "dropped": _drop_unused_owned()}, ""


CLOTH_PRESET = {
    # MIK_144's skirt (measured 2026-10-04), lengths before MIK's 158/165 resize
    "quality": 6, "mass": 0.25, "tension_stiffness": 12.0, "compression_stiffness": 12.0,
    "shear_stiffness": 6.0, "bending_stiffness": 0.48, "tension_damping": 6.0,
    "compression_damping": 6.0, "shear_damping": 6.0, "air_damping": 1.0,
}
CLOTH_PRESET_DISTANCE_MM = 8.0
CLOTH_PRESET_SELF_DISTANCE_MM = 15.0


def add_cloth(mesh_object, pin_group=PIN_GROUP, quality=None, mass=None,
              stiffness=None, bending=None, air_damping=None,
              collision_quality=4, distance_mm=None, self_collision=False,
              keep_existing=True):
    """Put a Cloth modifier after the armature. ``(report, error)``.

    A new cloth gets ``CLOTH_PRESET`` (MIK_144's skirt), with any of ``quality``,
    ``mass``, ``stiffness`` (tension and compression), ``bending``,
    ``air_damping`` and ``distance_mm`` given here taking its place. A cloth that
    is already there keeps its physics when ``keep_existing`` -- re-running the
    setup rewires it (order, pin group, collision quality, self collision)
    without undoing what was tuned. Self collision is off by default: measured
    on MIK's skirt it doubled the vertices left inside the body (27.5 -> 68 a
    frame) and slowed the bake from 84 to 120 s.

    Order is the whole point: cloth placed before the armature simulates the rest
    pose and is then deformed by the skin, which looks like the garment is being
    dragged through itself. After the armature, the simulation starts from the
    posed garment, which is what the pin group then holds at the waist. It goes
    right behind the last armature, in front of anything generative: behind a
    Subdivision it would simulate four times the vertices.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    modifier = mesh_object.modifiers.get(CLOTH_MODIFIER)
    existed = modifier is not None
    if modifier is None:
        modifier = mesh_object.modifiers.new(name=CLOTH_MODIFIER, type="CLOTH")
    # Moved through the collection's own move(), not the operator: passing a
    # context override dictionary positionally to bpy.ops was removed in 4.0,
    # and the call would raise TypeError and leave the modifier silently in the
    # wrong place.
    _after_armature(mesh_object, modifier)
    settings = modifier.settings
    collision = modifier.collision_settings
    physics_kept = existed and keep_existing
    if not physics_kept:
        values = dict(CLOTH_PRESET)
        if quality is not None:
            values["quality"] = int(quality)
        if mass is not None:
            values["mass"] = float(mass)
        if stiffness is not None:
            values["tension_stiffness"] = values["compression_stiffness"] = float(stiffness)
        if bending is not None:
            values["bending_stiffness"] = float(bending)
        if air_damping is not None:
            values["air_damping"] = float(air_damping)
        for key, value in values.items():
            setattr(settings, key, value)
        collision.distance_min = max(0.001, (CLOTH_PRESET_DISTANCE_MM if distance_mm is None
                                             else distance_mm) * 0.001)
        collision.self_distance_min = CLOTH_PRESET_SELF_DISTANCE_MM * 0.001
    # a kept cloth keeps the pin it actually uses -- another name, or none -- not only SRS Cloth Pin
    if not physics_kept:
        settings.vertex_group_mass = pin_group
    collision.collision_quality = int(collision_quality)
    collision.use_self_collision = bool(self_collision)
    return {"mesh": mesh_object.name, "modifier": modifier.name,
            "index": list(mesh_object.modifiers).index(modifier),
            "stack": [m.name for m in mesh_object.modifiers],
            "pin_group": settings.vertex_group_mass, "physics_kept": physics_kept}, ""


def kept_pin_problem(mesh_object):
    """Why a kept cloth's pin cannot be kept as it is, or ``""``. Its pin group may be any vertex group or none; it
    may not name a group the mesh does not have."""
    modifier = mesh_object.modifiers.get(CLOTH_MODIFIER) if mesh_object is not None else None
    if modifier is None:
        return ""
    name = modifier.settings.vertex_group_mass
    if name and mesh_object.vertex_groups.get(name) is None:
        return "%s pins its cloth to a vertex group %r that the mesh does not have" % (mesh_object.name, name)
    return ""


def add_switch(mesh_object, armature, property_name=SWITCH_PROPERTY,
               default=0.0, expression="switch > 0.5"):
    """One property on the rig that turns the cloth on and off.

    ``(report, error)``. Both the viewport and the render flag are driven, so the
    switch cannot end up meaning two different things in the two places -- which
    is the usual way a garment renders simulated when the animator was looking at
    the bone version. ``expression`` (of ``switch``) decides when the cloth is on, so one
    property with several states -- 0 none, 1 baked bone swing, 2 cloth -- can drive it
    with ``"abs(switch - 2) < 0.5"``.
    """
    if mesh_object is None or armature is None:
        return None, "Need the garment and the rig"
    modifier = mesh_object.modifiers.get(CLOTH_MODIFIER)
    if modifier is None:
        return None, "%s has no %s modifier yet" % (mesh_object.name,
                                                    CLOTH_MODIFIER)
    if property_name not in armature.keys():
        armature[property_name] = float(default)
        try:
            armature.id_properties_ui(property_name).update(
                min=0.0, max=1.0, description="0 = bone-driven skirt, "
                                              "1 = cloth simulation")
        except (AttributeError, TypeError):
            pass
    # The drivers read the rig's evaluated copy. A property just added to a rig
    # the depsgraph has already evaluated is not on that copy until the rig is
    # tagged; a driver evaluated before then fails, is marked invalid, and stays
    # invalid -- the switch then does nothing until somebody edits the driver.
    armature.update_tag()
    bpy.context.view_layer.update()
    made = []
    for channel in ("show_viewport", "show_render"):
        path = 'modifiers["%s"].%s' % (CLOTH_MODIFIER, channel)
        if mesh_object.animation_data:
            for curve in list(mesh_object.animation_data.drivers):
                if curve.data_path == path:
                    mesh_object.animation_data.drivers.remove(curve)
        curve = mesh_object.driver_add(path)
        driver = curve.driver
        driver.type = "SCRIPTED"
        variable = driver.variables.new()
        variable.name = "switch"
        variable.type = "SINGLE_PROP"
        variable.targets[0].id = armature
        variable.targets[0].data_path = '["%s"]' % property_name
        driver.expression = expression
        made.append(path)
    mesh_object.update_tag()
    bpy.context.view_layer.update()
    valid = [curve.driver.is_valid for curve in mesh_object.animation_data.drivers
             if curve.data_path in made]
    return {"mesh": mesh_object.name, "property": property_name,
            "on_rig": armature.name, "driven": made, "valid": all(valid),
            "value": armature[property_name]}, ""


def set_mode(armature, cloth, property_name=SWITCH_PROPERTY):
    """Flip the switch. ``cloth`` True simulates, False poses with bones."""
    if armature is None:
        return None, "No rig"
    armature[property_name] = 1.0 if cloth else 0.0
    armature.update_tag()
    bpy.context.view_layer.update()
    return {"property": property_name, "value": armature[property_name],
            "mode": "CLOTH" if cloth else "BONE"}, ""


def _switch_owners(armature):
    owners = [armature]
    pose = getattr(armature, "pose", None)
    traj = pose.bones.get("c_traj") if pose is not None else None
    if traj is not None:
        owners.append(traj)
    return owners


def find_switch(armature, property_name=""):
    """Where the skirt's switch lives: ``(owner, property_name)``, or ``(None, "")``.

    The owner is the rig or its ``c_traj`` bone. With ``property_name`` empty the
    character's own several-state switch (``skirt_mode``) wins over the one this
    module adds (``srs_skirt_cloth``, 0 bones / 1 cloth).
    """
    if armature is None or getattr(armature, "type", "") != "ARMATURE":
        return None, ""
    names = (property_name,) if property_name else MODE_PROPERTIES
    for name in names:
        for owner in _switch_owners(armature):
            try:
                if name in owner.keys():
                    return owner, name
            except (AttributeError, TypeError):
                continue
    return None, ""


_STATE_LABEL = re.compile(r"(-?\d+)\s*[:=]\s*(.*?)(?=\s*[/,;]\s*-?\d+\s*[:=]|\s*$)")


def switch_states(owner, property_name):
    """The values the switch takes, ``[(value, label), ...]``, lowest first.

    The range is the property's own UI range in whole steps (0..1 when it has none).
    A label comes from the description when it reads like ``"0: 5-H default /
    1: P2 ..."`` or ``"0 = bones, 1 = cloth"``; otherwise it is empty.
    """
    low, high, text = 0, 1, ""
    try:
        data = owner.id_properties_ui(property_name).as_dict()
        low = int(round(float(data.get("min", low))))
        high = int(round(float(data.get("max", high))))
        text = str(data.get("description", "") or "")
    except (AttributeError, TypeError, ValueError, KeyError):
        pass
    if high < low:
        low, high = high, low
    high = min(high, low + MAX_SWITCH_STATES - 1)
    labels = {}
    for match in _STATE_LABEL.finditer(text):
        labels.setdefault(int(match.group(1)), match.group(2).strip())
    return [(value, labels.get(value, "")) for value in range(low, high + 1)]


def switch_value(owner, property_name):
    """The switch's current state as a whole number, or None when unreadable."""
    try:
        return int(round(float(owner[property_name])))
    except (KeyError, TypeError, ValueError):
        return None


def _reads_switch(curve, armature, paths):
    for variable in curve.driver.variables:
        for target in variable.targets:
            if target.id == armature and (target.data_path or "") in paths:
                return True
    return False


def set_switch(owner, property_name, value):
    """Put the switch in one of its states and let every driver that reads it see it.

    ``(report, error)``. The stored type is kept (an int stays an int, a float a
    float), so drivers and scripts written against the property keep working. After
    the write the rig is tagged and the view layer updated, so visibility, modifier
    and constraint drivers take the new state at once rather than on the next frame
    change. ``cloth_from`` is the first frame of any cloth that the switch just
    turned on and that has no bake -- the cloth only simulates when played from there.
    """
    if owner is None or not property_name or property_name not in owner.keys():
        return None, "No skirt switch on this rig."
    states = switch_states(owner, property_name)
    allowed = [state for state, _label in states]
    target = int(value)
    if target not in allowed:
        return None, "Skirt switch %s takes %d to %d, not %d." % (
            property_name, allowed[0], allowed[-1], target)
    armature = owner.id_data
    if owner is armature:
        paths = {'["%s"]' % property_name, "['%s']" % property_name}
    else:
        paths = {'pose.bones["%s"]["%s"]' % (owner.name, property_name),
                 "pose.bones['%s']['%s']" % (owner.name, property_name)}
    driven = []
    revived = 0
    for obj in bpy.data.objects:
        data = obj.animation_data
        if data is None:
            continue
        reading = [curve for curve in data.drivers if _reads_switch(curve, armature, paths)]
        if not reading:
            continue
        driven.append(obj)
        # A driver that once failed (typically: built before the rig's evaluated copy
        # had the property) is skipped for good; let it try again with the new value.
        for curve in reading:
            if not curve.driver.is_valid:
                curve.driver.is_valid = True
                revived += 1
        obj.update_tag()
    old = owner[property_name]
    owner[property_name] = float(target) if isinstance(old, float) else target
    armature.update_tag()
    bpy.context.view_layer.update()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    cloth_from = []
    for obj in driven:
        if obj.type != "MESH":
            continue
        evaluated = obj.evaluated_get(depsgraph)
        if evaluated.hide_viewport:
            continue
        for modifier in evaluated.modifiers:
            if modifier.type == "CLOTH" and modifier.show_viewport:
                cache = modifier.point_cache
                if not cache.is_baked:
                    cloth_from.append(int(cache.frame_start))
    label = dict(states).get(target, "")
    return {"owner": owner.name, "property": property_name,
            "value": target, "label": label, "driven_objects": len(driven),
            "revived_drivers": revived,
            "cloth_from": min(cloth_from) if cloth_from else None}, ""


def remove_cloth(mesh_object, keep_pin=True):
    """Take the simulation back off, leaving the bone rig untouched."""
    if mesh_object is None:
        return None, "No mesh"
    removed = []
    for name in (CLOTH_MODIFIER,):
        modifier = mesh_object.modifiers.get(name)
        if modifier is not None:
            mesh_object.modifiers.remove(modifier)
            removed.append(name)
    if mesh_object.animation_data:
        for curve in list(mesh_object.animation_data.drivers):
            if CLOTH_MODIFIER in (curve.data_path or ""):
                mesh_object.animation_data.drivers.remove(curve)
    if not keep_pin:
        group = mesh_object.vertex_groups.get(PIN_GROUP)
        if group is not None:
            mesh_object.vertex_groups.remove(group)
    return {"mesh": mesh_object.name, "removed": removed}, ""


def simply_cloth_present():
    """Whether Simply Cloth Studio is available in this Blender."""
    names = []
    for module in ("simply_cloth_studio", "simply_cloth", "SimplyCloth"):
        if module in {a.module for a in
                      bpy.context.preferences.addons}:  # type: ignore[attr-defined]
            names.append(module)
    scene = bpy.context.scene
    markers = [name for name in dir(scene) if "simply" in name.lower()]
    return {"addons": names, "scene_properties": markers[:8],
            "present": bool(names or markers)}


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
