# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""IK/FK switching for animators, on top of Auto-Rig Pro's own snap.

Auto-Rig Pro already switches and snaps both arms and legs (``pose.arp_switch_snap``
calls its own arm/leg switch routines). This module adds transaction safeguards for
the remaining switch-specific defects:

1. A keyed switch blends. ARP can key ``ik_fk_switch`` with the user's default (Bezier)
   interpolation, so between two switch keys the limb is part IK, part FK. A switch is
   stepped only at the actual key just created and its preceding key in the assigned slot.
   Only the interval the switch keyed is stepped (that controller's curve, in the
   slot the rig plays, the new key and the one before it). Other limbs, other
   actions and NLA strips are left alone; stepping everything is a separate button.
2. A straight limb flips. ARP finds the pole from the elbow's offset to the
   shoulder-wrist line; at exactly 0 degrees that offset is zero and the IK arm came
   out twisted 137-161 degrees (0.25 degrees was already fine). When the limb is
   that straight, the pole is placed from the upper bone's own frame instead -- the
   rest-pose pole direction carried by the FK upper arm / thigh.

A switch is a transaction. If the snap raises, or the limb ends up more than
0.1 mm / 0.1 degree away from where it was, the pose, the custom properties and the
keys around the frame are put back and the reason is returned -- a limb that is
exactly straight is refused rather than switched with a visible residual. Leg validation
uses the normal knee Z-axis operation; an artificial X-axis forcing probe is diagnostic
only and is not classified as a normal UI failure.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import math
import sys

import bpy
from mathutils import Matrix, Vector

from . import jiggle

STRAIGHT_DEG = 1.0
LIMBS = {
    "ARM": {"fk": ("c_arm_fk", "c_forearm_fk", "c_hand_fk"), "ik_ctrl": "c_hand_ik",
            "pole": "c_arms_pole", "ref": "hand_ref"},
    "LEG": {"fk": ("c_thigh_fk", "c_leg_fk", "c_foot_fk"), "ik_ctrl": "c_foot_ik",
            "pole": "c_leg_pole", "ref": "foot_ref"},
}


def arp_functions():
    """Auto-Rig Pro's rig_functions module, if Auto-Rig Pro is enabled."""
    for name, mod in list(sys.modules.items()):
        if name.endswith("auto_rig_pro.src.rig_functions") and hasattr(mod, "ik_to_fk_arm"):
            return mod
    return None


def switch_fcurves(armature):
    """Every F-curve driving an ik_fk_switch on the armature's actions (active and NLA)."""
    actions = []
    ad = armature.animation_data
    if ad is not None:
        if ad.action is not None:
            actions.append(ad.action)
        for track in ad.nla_tracks:
            for strip in track.strips:
                if strip.action is not None and strip.action not in actions:
                    actions.append(strip.action)
    out = []
    for action in actions:
        for bag in jiggle.action_channelbags(action):
            for fc in bag.fcurves:
                if fc.data_path.endswith('["ik_fk_switch"]'):
                    out.append(fc)
    return out


def _slot_bags(armature):
    """The channelbags the rig's active action plays through its assigned slot."""
    ad = armature.animation_data
    if ad is None or ad.action is None:
        return []
    bags = jiggle.action_channelbags(ad.action)
    slot = getattr(ad, "action_slot", None)
    if slot is None:
        return bags
    return [b for b in bags if b.slot == slot]


def _isolated_slot_bags(armature, frame, *, keying=False):
    """Find the assigned slot, allowing a first Action to be made by keying."""
    ad = armature.animation_data
    if ad is None:
        return [], ""
    if getattr(ad, "use_tweak_mode", False):
        return None, "NLA tweak mode is not supported by IK/FK switch."
    if getattr(ad, "use_nla", True):
        tracks = tuple(ad.nla_tracks)
        solo = any(getattr(track, "is_solo", False) for track in tracks)
        for track in tracks:
            if track.mute or (solo and not getattr(track, "is_solo", False)):
                continue
            if any(_strip_contributes(strip, frame) for strip in track.strips):
                return None, "Contributing NLA strips are not changed by IK/FK switch."
    if ad.action is None:
        return [], ""
    if ad.action.users > 1:
        return None, "Shared Actions are not changed by IK/FK switch."
    slot = getattr(ad, "action_slot", None)
    if slot is None:
        return None, "An unambiguous Action slot is required before IK/FK switch."
    bags = [bag for bag in jiggle.action_channelbags(ad.action) if bag.slot == slot]
    if len(bags) != 1:
        return None, "The assigned Action slot is ambiguous."
    return bags, ""


def _strip_contributes(strip, frame):
    if strip.mute:
        return False
    if strip.type != "CLIP":
        return True
    if strip.action is None:
        return False
    if strip.frame_start <= frame <= strip.frame_end:
        return True
    extrapolation = strip.extrapolation
    if frame < strip.frame_start:
        return extrapolation == "HOLD"
    return extrapolation in {"HOLD", "HOLD_FORWARD"}


def step_switch_interval(armature, controller, frame):
    """Step only the switch just keyed: the key at ``frame`` and the one before it."""
    path = 'pose.bones["%s"]["ik_fk_switch"]' % controller
    changed = 0
    for bag in _slot_bags(armature):
        for fc in bag.fcurves:
            if fc.data_path != path:
                continue
            keys = sorted(fc.keyframe_points, key=lambda k: k.co.x)
            at = [i for i, k in enumerate(keys) if abs(k.co.x - frame) <= 1.0e-6]
            for i in at:
                for k in (keys[i], keys[i - 1] if i > 0 else None):
                    if k is not None and k.interpolation != "CONSTANT":
                        k.interpolation = "CONSTANT"
                        changed += 1
            fc.update()
    return changed


def constant_switch_keys(armature):
    """Make every ik_fk_switch key a step. Returns the number of keys changed."""
    changed = 0
    for fc in switch_fcurves(armature):
        for kp in fc.keyframe_points:
            if kp.interpolation != "CONSTANT":
                kp.interpolation = "CONSTANT"
                changed += 1
        fc.update()
    return changed


def limb_of(bone_name):
    """('ARM'|'LEG', side) for an ARP limb controller name, else (None, None)."""
    for limb, spec in LIMBS.items():
        names = list(spec["fk"]) + [spec["ik_ctrl"], spec["pole"]]
        for n in names:
            if bone_name.startswith(n + "."):
                return limb, bone_name[len(n):]
    if bone_name.startswith(("arm_ik.", "forearm_ik.", "c_arm_ik.")):
        return "ARM", bone_name[bone_name.index("."):]
    if bone_name.startswith(("thigh_ik.", "leg_ik.", "c_thigh_ik.")):
        return "LEG", bone_name[bone_name.index("."):]
    return None, None


FLIP_DEG = 1.0


def _result_bones(limb):
    return ("arm", "forearm", "hand") if limb == "ARM" else ("thigh", "leg", "foot")


def _twist_error(armature, side, before):
    worst = 0.0
    for n, m in before.items():
        a = armature.pose.bones[n + side].matrix.to_quaternion().rotation_difference(m.to_quaternion()).angle
        worst = max(worst, math.degrees(min(a, 2.0 * math.pi - a)))
    return worst


def bend_degrees(armature, limb, side):
    spec = LIMBS[limb]
    b1 = armature.pose.bones.get(spec["fk"][0] + side)
    b2 = armature.pose.bones.get(spec["fk"][1] + side)
    if b1 is None or b2 is None:
        return None
    u, v = b1.tail - b1.head, b2.tail - b2.head
    if u.length == 0.0 or v.length == 0.0:
        return None
    return math.degrees(u.angle(v))


def rest_frame_pole(armature, limb, side):
    """Pole position from the FK upper bone's frame, valid when the limb is straight."""
    spec = LIMBS[limb]
    pb = armature.pose.bones
    b1, b2, pole = pb[spec["fk"][0] + side], pb[spec["fk"][1] + side], pb[spec["pole"] + side]
    d_rest = pole.bone.head_local - b2.bone.head_local
    r_rest = b1.bone.matrix_local.to_3x3().normalized()
    r_now = b1.matrix.to_3x3().normalized()
    d = r_now @ (r_rest.inverted() @ d_rest)
    axis = (b2.tail - b1.head)
    if axis.length > 0.0:
        axis.normalize()
        d = d - axis * d.dot(axis)      # only the part across the limb decides the twist
    dist = 1.0
    ref = armature.data.bones.get(spec["ref"] + side)
    if ref is not None and "ik_pole_distance" in ref.keys():
        dist = float(ref["ik_pole_distance"])
    return b2.head + d.normalized() * (b2.head - b1.head).length * dist


TOL_MM = 0.1
TOL_DEG = 0.1
KEY_REACH = 2.0


def _rna_state(item):
    """Snapshot every writable scalar/vector RNA attribute, including all handles."""
    state = {}
    for prop in item.bl_rna.properties:
        if prop.identifier == "rna_type" or prop.is_readonly or prop.type in {"POINTER", "COLLECTION"}:
            continue
        value = getattr(item, prop.identifier)
        state[prop.identifier] = tuple(value) if hasattr(value, "__len__") and not isinstance(value, str) else value
    return state


def _copy_id_value(value):
    return value.copy() if hasattr(value, "copy") else value


def _restore_rna(item, state, *, handles_last=False):
    deferred = {"handle_left", "handle_right"} if handles_last else set()
    for name, value in state.items():
        if name in deferred:
            continue
        try:
            setattr(item, name, value)
        except (AttributeError, TypeError, ValueError):
            pass
    for name in deferred:
        if name not in state:
            continue
        try:
            setattr(item, name, state[name])
        except (AttributeError, TypeError, ValueError):
            pass


def _key_state(kp):
    return _rna_state(kp)


def snapshot(armature, frame):
    """Transaction snapshot: full assigned-slot curves plus mutable UI/animation state."""
    pose = {}
    for pb in armature.pose.bones:
        props = {k: _copy_id_value(pb[k]) for k in pb.keys()}
        pose[pb.name] = (pb.rotation_mode, pb.matrix_basis.copy(), props)
    ad = armature.animation_data
    bags, reason = _isolated_slot_bags(armature, frame)
    if reason:
        raise RuntimeError(reason)
    curves = {}
    for bag in bags:
        for fc in bag.fcurves:
            curves[(fc.data_path, fc.array_index)] = {
                "curve": _rna_state(fc), "keys": [_key_state(kp) for kp in fc.keyframe_points],
            }
    selected = {pb.name: bool(pb.select) for pb in armature.pose.bones}
    active_bone = getattr(armature.data.bones, "active", None)
    return {"pose": pose, "curves": curves, "frame": frame,
            "action": ad.action if ad is not None else None,
            "slot": getattr(ad, "action_slot", None) if ad is not None else None,
            "selected": selected, "active_bone": active_bone,
            "active": bpy.context.view_layer.objects.active,
            "mirror": getattr(armature.pose, "use_mirror_x", None),
            "autokey": bpy.context.scene.tool_settings.use_keyframe_insert_auto,
            "global_undo": bpy.context.preferences.edit.use_global_undo}


def rollback(armature, snap):
    """Put back what ``snapshot`` recorded.

    Keys first, then one evaluation, then the pose: editing the curves tags the
    animation, and the next evaluation writes the curve values back over any
    channel that has a curve -- a pose put back before that would be lost again.
    """
    try:
        _restore_keys(armature, snap)
        bpy.context.view_layer.update()
        for name, (mode, basis, props) in snap["pose"].items():
            pb = armature.pose.bones.get(name)
            if pb is None:
                continue
            pb.rotation_mode = mode
            pb.matrix_basis = basis
            for k in tuple(pb.keys()):
                if k not in props:
                    del pb[k]
            for k, v in props.items():
                pb[k] = v
    finally:
        _restore_ui_state(armature, snap)


def _restore_ui_state(armature, snap):
    for name, selected in snap["selected"].items():
        pb = armature.pose.bones.get(name)
        if pb is not None:
            pb.select = selected
    armature.data.bones.active = snap["active_bone"]
    bpy.context.scene.tool_settings.use_keyframe_insert_auto = snap["autokey"]
    bpy.context.preferences.edit.use_global_undo = snap["global_undo"]
    if snap["mirror"] is not None:
        armature.pose.use_mirror_x = snap["mirror"]
    bpy.context.view_layer.objects.active = snap["active"]


def _restore_keys(armature, snap):
    ad = armature.animation_data
    made = ad.action if ad is not None and ad.action is not snap["action"] else None
    if ad is not None:
        ad.action = snap["action"]
        if snap["action"] is not None:
            ad.action_slot = snap["slot"]
    if snap["action"] is None:
        if made is not None and made.users == 0:
            bpy.data.actions.remove(made)
        return
    bags = [bag for bag in jiggle.action_channelbags(snap["action"]) if bag.slot == snap["slot"]]
    if len(bags) != 1:
        raise RuntimeError("Cannot restore the original assigned Action slot.")
    for bag in bags:
        for fc in list(bag.fcurves):
            key = (fc.data_path, fc.array_index)
            if key not in snap["curves"]:
                bag.fcurves.remove(fc)
                continue
            old = snap["curves"][key]
            while fc.keyframe_points:
                fc.keyframe_points.remove(fc.keyframe_points[0])
            for key_state in old["keys"]:
                co = key_state["co"]
                kp = fc.keyframe_points.insert(co[0], co[1])
                _restore_rna(kp, key_state, handles_last=True)
            _restore_rna(fc, old["curve"])
            fc.update()
        for (path, index), old in snap["curves"].items():
            if any(fc.data_path == path and fc.array_index == index for fc in bag.fcurves):
                continue
            fc = bag.fcurves.new(data_path=path, index=index)
            for key_state in old["keys"]:
                co = key_state["co"]
                kp = fc.keyframe_points.insert(co[0], co[1])
                _restore_rna(kp, key_state, handles_last=True)
            _restore_rna(fc, old["curve"])
            fc.update()
    if made is not None and made.users == 0:
        bpy.data.actions.remove(made)


def _drift(armature, side, before, scale_length):
    """How far the result bones moved: (mm at head or tail, degrees)."""
    mw = armature.matrix_world
    mm, deg = 0.0, 0.0
    for n, m in before.items():
        pb = armature.pose.bones[n + side]
        tip = Vector((0.0, pb.bone.length, 0.0))
        for a, b in ((m.translation, pb.matrix.translation), (m @ tip, pb.matrix @ tip)):
            mm = max(mm, ((mw @ a) - (mw @ b)).length * scale_length * 1000.0)
        q = pb.matrix.to_quaternion().rotation_difference(m.to_quaternion()).angle
        deg = max(deg, math.degrees(min(q, 2.0 * math.pi - q)))
    return (mm, deg) if math.isfinite(mm) and math.isfinite(deg) else (float("inf"), float("inf"))


def switch(armature, limb, side, key=None):
    """Switch one limb to the other mode with ARP's snap, plus the two fixes.

    ``key``: True keys the switch, False never keys, None follows Auto Keying.
    Returns (report, error). On an error nothing is left changed.
    """
    arp = arp_functions()
    if arp is None:
        return None, "Auto-Rig Pro is not enabled."
    spec = LIMBS[limb]
    ctrl = armature.pose.bones.get(spec["ik_ctrl"] + side)
    if ctrl is None or "ik_fk_switch" not in ctrl.keys():
        return None, "This rig has no %s%s switch." % (spec["ik_ctrl"], side)
    scene = bpy.context.scene
    frame = float(getattr(scene, "frame_current_final", scene.frame_current))
    if abs(frame - round(frame)) > 1.0e-6:
        return None, "Subframe IK/FK switching is rejected before mutation."
    do_key = scene.tool_settings.use_keyframe_insert_auto if key is None else bool(key)
    _bags, isolation_error = _isolated_slot_bags(armature, frame, keying=do_key)
    if isolation_error:
        return None, isolation_error
    scale_length = float(getattr(scene.unit_settings, "scale_length", 1.0))
    if not math.isfinite(scale_length) or scale_length <= 0.0:
        return None, "Scene unit scale_length must be finite and positive."
    view_layer = bpy.context.view_layer
    to_ik = float(ctrl["ik_fk_switch"]) >= 0.5   # currently FK -> going to IK
    straight = False
    stepped = 0
    snap = snapshot(armature, frame)
    result = _result_bones(limb)
    before = {n: armature.pose.bones[n + side].matrix.copy() for n in result
              if armature.pose.bones.get(n + side) is not None}
    failure = ""
    drift = (0.0, 0.0)
    try:
        view_layer.objects.active = armature
        if limb == "ARM":
            fn = arp.ik_to_fk_arm if to_ik else arp.fk_to_ik_arm
        else:
            fn = arp.ik_to_fk_leg if to_ik else arp.fk_to_ik_leg
        bend = bend_degrees(armature, limb, side)
        saved_autokey = scene.tool_settings.use_keyframe_insert_auto
        if not do_key:
            scene.tool_settings.use_keyframe_insert_auto = False
        try:
            fn(armature, side, add_keyframe=do_key)
        finally:
            scene.tool_settings.use_keyframe_insert_auto = saved_autokey
        view_layer.update()
        if to_ik and bend is not None and bend < STRAIGHT_DEG                 and _twist_error(armature, side, before) > FLIP_DEG:
            # ARP's pole came from a zero-length offset and the limb twisted:
            # place the pole from the upper bone's own frame instead.
            straight = True
            pole = armature.pose.bones[spec["pole"] + side]
            rot = pole.rotation_euler.copy()
            arp.snap_bone_matrix(pole, Matrix.Translation(rest_frame_pole(armature, limb, side)))
            pole.rotation_euler = rot
            view_layer.update()
            if do_key:
                pole.keyframe_insert(data_path="location")
        drift = _drift(armature, side, before, scale_length)
        if drift[0] > TOL_MM or drift[1] > TOL_DEG:
            if bend is not None and bend < STRAIGHT_DEG:
                why = " -- it is straight; bend it slightly and switch again"
            elif to_ik:
                why = (" -- Auto-Rig Pro's snap does not reproduce this FK pose in IK; keep the limb in FK "
                       "here or pose the IK by hand")
            else:
                why = ""
            failure = ("The switch would move the limb %.2f mm / %.2f degrees%s, so nothing was "
                       "changed." % (drift[0], drift[1], why))
        elif do_key:
            stepped = step_switch_interval(armature, spec["ik_ctrl"] + side, frame)
    except Exception:
        failure = "The switch failed, so nothing was changed."
    finally:
        if failure:
            rollback(armature, snap)
        else:
            _restore_ui_state(armature, snap)
    view_layer.update()
    report = {"limb": limb, "side": side, "to": "IK" if to_ik else "FK", "keyed": do_key,
              "straight_fix": straight, "stepped_keys": stepped,
              "drift_mm": round(drift[0], 4), "drift_deg": round(drift[1], 4)}
    return report, failure
