# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Strip rigs (skirt, coat, cuffs) from Auto-Rig Pro's own Kilt limb, and their skin weights.

Auto-Rig Pro's Kilt is the standard way to keep a skirt off the legs with bones: a
column of controllers per strip, each column aimed by a Damped Track whose target is
held out of the leg by a Floor constraint, and the Floor's strength driven by how far
the leg has turned towards that column. Hand-keyed rotations of the column
controllers add on top of that, which is what makes the strips animatable. (ARP 3.68+,
auto_rig.html#kilt-options.)

The Kilt is normally created before Match to Rig. On a rig that has been worked on
after Match to Rig, running it again undoes that work -- measured on MIK_127: 363
bones moved to other bone collections, 48 elbow/knee helper rolls and the eyelid
pivots reverted, rest-pose skin moved up to 12mm. ``set_kilt`` itself builds the
reference bones, the controllers, the constraints and the drivers, and ends by
aligning them to the references, so this module calls it directly, places the
references on the part, and calls it again. Nothing else on the rig changes
(measured: 0 bones changed, 0.000mm at rest).

Several kilts on one rig need different sides ('.x', '_dupli_001.x', ...): the
helper bones that follow the legs are named by side, not by kilt name.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import math
import sys

import bpy
from mathutils import Vector


def arp_auto_rig():
    """Auto-Rig Pro's auto_rig module, if it is enabled."""
    for name, mod in list(sys.modules.items()):
        if name.endswith("auto_rig_pro.src.auto_rig") and hasattr(mod, "set_kilt"):
            return mod
    return None


def kilt_side(armature, name):
    """The side suffix of an existing kilt called ``name``, or a free one for a new kilt."""
    used = set()
    for bone in armature.data.bones:
        if "_master_ref" in bone.name:
            prefix, _sep, side = bone.name.partition("_master_ref")
            if prefix == name:
                return side
            used.add(side[:-2])        # the duplicate id, whatever its side
    if "" not in used:
        return ".x"
    n = 1
    while "_dupli_%03d" % n in used:
        n += 1
    return "_dupli_%03d.x" % n


def _azimuth(point, centre):
    return math.atan2(point.y - centre.y, point.x - centre.x)


class Frame:
    """Azimuth round, and distance along, an axis pointing from the strips' roots to their free ends.

    Straight down (a skirt) keeps +X / +Y as the azimuth basis, so a skirt's angles are the
    plain atan2(y, x) they always were. Any other axis (a cuff along the forearm) gets a
    basis perpendicular to it.
    """

    def __init__(self, origin, axis):
        self.o = origin.copy()
        self.a = axis.normalized()
        if abs(self.a.z) > 0.9:
            self.u, self.v = Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0))
        else:
            self.u = self.a.cross(Vector((0.0, 0.0, 1.0))).normalized()
            self.v = self.a.cross(self.u).normalized()

    def az(self, point):
        d = point - self.o
        return math.atan2(d.dot(self.v), d.dot(self.u))

    def along(self, point):
        return (point - self.o).dot(self.a)


def part_frame(mesh_object, indices, axis=None):
    """World points of the part, its axis frame and its extent along the axis (roots first)."""
    mw = mesh_object.matrix_world
    pts = {i: mw @ mesh_object.data.vertices[i].co for i in indices}
    if not pts:
        return None
    n = float(len(pts))
    centroid = Vector((sum(p.x for p in pts.values()) / n, sum(p.y for p in pts.values()) / n,
                       sum(p.z for p in pts.values()) / n))
    frame = Frame(centroid, axis if axis is not None else Vector((0.0, 0.0, -1.0)))
    alongs = [frame.along(p) for p in pts.values()]
    return {"points": pts, "centre": centroid, "frame": frame,
            "top": max(p.z for p in pts.values()), "bottom": min(p.z for p in pts.values()),
            "first": min(alongs), "last": max(alongs)}


def column_span(frame, angle, half_deg):
    """Highest and lowest point of the part within +-half_deg of an azimuth."""
    f = frame["frame"]
    picks = []
    for p in frame["points"].values():
        d = (f.az(p) - angle + math.pi) % (2.0 * math.pi) - math.pi
        if abs(d) <= math.radians(half_deg):
            picks.append(p)
    if not picks:
        return None, None
    return min(picks, key=f.along), max(picks, key=f.along)


def vertex_columns(mesh_object, indices):
    """The vertical vertex columns of a quad-grid garment panel, hem first, in hem order.

    ``(columns, world points, open)``. The panel's boundary is either two rings (a closed
    tube: hem and waist) or one loop whose four valence-2 corners split it into hem, top
    and the two edges of an opening. Each hem vertex walks up the grid by always taking
    the edge opposite the one it came along, so a pleat's folded-under layers are walked
    as their own columns rather than skipped.
    """
    import collections
    me = mesh_object.data
    mw = mesh_object.matrix_world
    part = set(indices)
    points = {i: mw @ me.vertices[i].co for i in part}
    adj = collections.defaultdict(set)
    for e in me.edges:
        a, b = e.vertices
        if a in part and b in part:
            adj[a].add(b)
            adj[b].add(a)
    faces_of = collections.defaultdict(list)
    uses = collections.Counter()
    for f in me.polygons:
        vs = tuple(f.vertices)
        if all(v in part for v in vs):
            for v in vs:
                faces_of[v].append(set(vs))
            for key in f.edge_keys:
                uses[key] += 1
    border = collections.defaultdict(set)
    for (a, b), n in uses.items():
        if n == 1:
            border[a].add(b)
            border[b].add(a)
    if not border:
        return [], points, False

    def walk(start, seen):
        loop, prev, cur = [start], None, start
        while True:
            nxt = [j for j in border[cur] if j != prev and j not in seen]
            if not nxt:
                break
            prev, cur = cur, nxt[0]
            seen.add(cur)
            loop.append(cur)
        return loop
    corners = [v for v in border if len(adj[v]) == 2]
    if len(corners) >= 4:
        seen = {corners[0]}
        loop = walk(corners[0], seen)
        cuts = [k for k, v in enumerate(loop) if v in corners]
        pieces = [[loop[k % len(loop)] for k in range(a, b + 1)]
                  for a, b in zip(cuts, cuts[1:] + [cuts[0] + len(loop)])]
        is_open = True
    else:
        pieces, seen = [], set()
        for v in border:
            if v not in seen:
                seen.add(v)
                pieces.append(walk(v, seen))
        is_open = False
    hem = min(pieces, key=lambda piece: sum(points[v].z for v in piece) / len(piece))
    on_hem = set(hem)

    def up(prev, cur):
        side = set().union(*[fs for fs in faces_of[cur] if prev in fs])
        ahead = [n for n in adj[cur] if n != prev and n not in side]
        return ahead[0] if len(ahead) == 1 else None
    columns = []
    for h in hem:
        inner = [n for n in adj[h] if n not in on_hem]
        path = [h]
        if len(inner) == 1:
            prev, cur = h, inner[0]
            path.append(cur)
            while True:
                nxt = up(prev, cur)
                if nxt is None or nxt in path:
                    break
                path.append(nxt)
                prev, cur = cur, nxt
        columns.append(path)
    return columns, points, is_open


def body_centre(armature, names=("root.x", "c_root_master.x", "c_traj")):
    """The body's vertical axis as a world point ``(x, y, 0)``: the head of the rig's root bone, or None.

    A garment open on one side (a slit or wrap skirt) has its centroid off the body's axis, so
    azimuths measured round the centroid crowd the columns towards the opening.
    """
    for name in names:
        bone = armature.data.bones.get(name) if armature is not None else None
        if bone is not None:
            point = armature.matrix_world @ bone.head_local
            return Vector((point.x, point.y, 0.0))
    return None


def panel_columns(mesh_object, indices, centre=None, fold_deg=90.0):
    """One strip column per pleat panel, read off the garment's own topology. ``(report, error)``.

    Walking along the hem, a knife pleat shows as two sharp turns -- out to the crease,
    back under it and on again -- so the hem splits at every turn sharper than
    ``fold_deg`` into runs that go forward round the body and runs that double back
    under a crease. Each forward run is one panel of cloth between two creases (or
    between a crease and the edge of an opening), and gets one column: from the middle
    of its top to the middle of its hem. A garment with no folds gets one column per
    ``max(1, n // 5)`` vertex columns. ``report["columns"]`` is the ``columns_xyz`` that
    :func:`build` takes; the counts that justify it come with it.
    """
    columns, points, is_open = vertex_columns(mesh_object, indices)
    if len(columns) < 3:
        return None, "The part is not a grid of vertical columns."
    if centre is None:
        n = float(len(points))
        centre = Vector((sum(p.x for p in points.values()) / n, sum(p.y for p in points.values()) / n, 0.0))
    centre = Vector((centre[0], centre[1], 0.0))

    def az(point):
        return math.atan2(point.y - centre.y, point.x - centre.x)
    hem = [points[c[0]] for c in columns]
    turns = [0.0]
    for k in range(1, len(hem) - 1):
        a = hem[k] - hem[k - 1]
        b = hem[k + 1] - hem[k]
        a.z = b.z = 0.0
        if a.length <= 1.0e-9 or b.length <= 1.0e-9:
            turns.append(0.0)
            continue
        turn = math.degrees(a.angle(b))
        turns.append(turn if a.x * b.y - a.y * b.x >= 0.0 else -turn)
    turns.append(0.0)
    folds = [k for k, t in enumerate(turns) if abs(t) > fold_deg]
    # overall direction round the body: the sign most of the hem advances in
    steps = [(az(hem[k + 1]) - az(hem[k]) + math.pi) % (2.0 * math.pi) - math.pi for k in range(len(hem) - 1)]
    forward = 1.0 if sum(1 for d in steps if d > 0) >= len(steps) / 2.0 else -1.0
    runs, start = [], 0
    for k in folds + [len(columns) - 1]:
        if k > start:
            runs.append(list(range(start, k + 1)))
        start = k
    panels = []
    for run in runs:
        travel = (az(hem[run[-1]]) - az(hem[run[0]]) + math.pi) % (2.0 * math.pi) - math.pi
        if travel * forward > 0.0:
            # a run that starts at a fold starts on the layer folded under the last crease
            panels.append(run[1:] if run[0] in folds and len(run) > 2 else run)
    if not folds:
        size = max(1, len(columns) // 5)
        panels = [list(range(k, min(len(columns), k + size))) for k in range(0, len(columns), size)]
    out = []
    for run in panels:
        tops = [points[columns[k][-1]] for k in run]
        bottoms = [points[columns[k][0]] for k in run]
        top = sum(tops, Vector()) / len(tops)
        bottom = sum(bottoms, Vector()) / len(bottoms)
        out.append((top, bottom))
    return {"columns": out, "vertex_columns": len(columns), "rows": len(columns[0]),
            "folds": len(folds), "panels": [[run[0], run[-1]] for run in panels],
            "open": is_open, "azimuths_deg": [round(math.degrees(az(b)), 1) for _t, b in out]}, ""


def build(armature, mesh_object, indices, name="kilt", count=6, subdiv=3, type_side="SYMMETRICAL",
          collide_with=("thigh.l", "thigh.r"), angles_deg=None, axis=None, col_z=False,
          columns_xyz=None, centre=None):
    """Create (or rebuild) a Kilt called ``name`` on the part ``indices`` of ``mesh_object``.

    ``count`` is per side for SYMMETRICAL, the total otherwise. ``angles_deg`` places the
    columns at given azimuths (0 = +X, 90 = +Y, -90 = the front) instead of ARP's own
    layout -- a coat's seven strips sit where the garment has them. ``columns_xyz`` places
    them exactly instead: one ``(top, bottom)`` pair of world points per column (for
    SYMMETRICAL the .l columns first, then the .r ones), as :func:`panel_columns` reads them
    off the garment's own topology; ``count`` then follows the list. ``col_z`` is ARP's
    Collide on Z. ``centre`` (a world point) is where the master sits and what azimuths are
    measured round; by default the part's centroid, which for a garment open on one side
    lies off the body's axis. Returns (report, error).
    """
    arp = arp_auto_rig()
    if arp is None:
        return None, "Auto-Rig Pro is not enabled."
    if armature is None or armature.type != "ARMATURE":
        return None, "Choose the rig first."
    frame = part_frame(mesh_object, indices, axis=axis)
    if frame is None:
        return None, "Select the part's vertices."
    if centre is not None:
        frame["frame"] = Frame(Vector(centre), frame["frame"].a)
    if columns_xyz:
        columns_xyz = [(Vector(t), Vector(b)) for t, b in columns_xyz]
        count = len(columns_xyz) // (2 if type_side == "SYMMETRICAL" else 1)
        if count < 1 or (type_side == "SYMMETRICAL" and len(columns_xyz) % 2):
            return None, "A symmetrical kilt needs the same number of columns on each side."
    side = kilt_side(armature, name)
    legs = [str(b) for b in (collide_with or ()) if b]
    if not legs:
        legs = ["", ""]
    if len(legs) == 1:
        legs = legs * 2
    for leg in legs:
        if leg and armature.data.bones.get(leg) is None:
            return None, "The rig has no bone called %s to collide with." % leg
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    armature.select_set(True)
    kwargs = dict(type_side=type_side, kilt_amount=int(count), new_name=name,
                  kilt_leg1=legs[0], kilt_leg2=legs[1], kilt_collide=bool(legs[0]),
                  kilt_subdiv=int(subdiv), kilt_col_z=bool(col_z))
    placed, missing = [], []
    try:
        if armature.data.bones.get(name + "_master_ref" + side) is None:
            # ARP always creates a kilt symmetrical ('.x'); a one-sided kilt is that kilt switched
            # in Limb Options, which renames its master reference to <name>_master_ref<dup><side>.
            # Creating it one-sided in one call looks for the renamed master and fails.
            arp.set_kilt(side, **dict(kwargs, type_side="SYMMETRICAL"))
            if bpy.context.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            if type_side != "SYMMETRICAL":
                arp.set_kilt(side, **kwargs)
                if bpy.context.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode="OBJECT")
                side = side[:-2] + type_side
        else:
            arp.set_kilt(side, **kwargs)
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        dup = side[:-2]
        master = edit.get(name + "_master_ref" + side)
        if master is None:
            return None, "Auto-Rig Pro did not create %s_master_ref%s." % (name, side)
        f = frame["frame"]
        # world -> the rig's own space (a lifted character's rig is not at the origin)
        to_rig = armature.matrix_world.inverted()
        world_head = f.o + f.a * (frame["first"] - f.a.dot(f.o - frame["centre"]))
        master.head = to_rig @ world_head
        master.tail = to_rig @ (world_head - f.a * 0.15)
        sides = [dup + ".l", dup + ".r"] if type_side == "SYMMETRICAL" else [dup + type_side]
        per = int(count)
        refs = []
        for s in sides:
            for i in range(1, per + 1):
                ref = edit.get("%s_%02d_01_ref%s" % (name, i, s))
                if ref is not None:
                    refs.append(ref)
        if columns_xyz:
            for ref, (top, bottom) in zip(refs, columns_xyz):
                ref.head = to_rig @ top
                ref.tail = to_rig @ bottom
                placed.append(ref.name)
            refs = []
            wanted = []
        elif angles_deg:
            wanted = [math.radians(a) for a in angles_deg]
        elif abs(f.a.z) > 0.9:
            # hanging straight down: keep ARP's own layout round the part
            wanted = [math.atan2(ref.head.y - master.head.y, ref.head.x - master.head.x) for ref in refs]
        else:
            # any other axis: ARP's circle is in the ground plane and says nothing here -- spread evenly
            wanted = [2.0 * math.pi * k / max(1, len(refs)) for k in range(len(refs))]
        spacing = 360.0 / max(1, len(refs))
        for ref, angle in zip(refs, wanted):
            # a garment can have a slit or an overlap where a strip falls: widen the search
            # until the part is found rather than leave the strip at ARP's default circle,
            # which drags every vertex weighted to it (measured: 56mm into the body).
            half = max(6.0, spacing * 0.4)
            top, bottom = column_span(frame, angle, half)
            while top is None and half < 60.0:
                half += 6.0
                top, bottom = column_span(frame, angle, half)
            if top is None:
                missing.append(ref.name)
                continue
            ref.head = to_rig @ top
            ref.tail = to_rig @ (bottom if (bottom - top).length > 1.0e-4 else top + Vector((0.0, 0.0, -0.05)))
            placed.append(ref.name)
        bpy.ops.object.mode_set(mode="OBJECT")
        # second call: no count change, so ARP keeps the references and aligns the controllers to them
        arp.set_kilt(side, **kwargs)
    finally:
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous
    columns = kilt_columns(armature, name, side)
    return {"name": name, "side": side, "columns": len(columns),
            "deform_bones": sum(len(c) for c in columns), "placed": len(placed),
            "unplaced": missing}, ""


def kilt_columns(armature, name, side):
    """Deform controllers of a kilt, one list per column, top to bottom."""
    dup = side[:-2]
    out = {}
    for bone in armature.data.bones:
        if not bone.use_deform or not bone.name.startswith("c_%s_" % name):
            continue
        rest = bone.name[len("c_%s_" % name):]
        head, _dot, tail_side = rest.partition(".")
        if dup:
            if not head.endswith(dup):
                continue
            head = head[: -len(dup)]
        elif "_dupli_" in head:
            continue
        bits = head.split("_")
        if len(bits) != 2 or not all(x.isdigit() for x in bits):
            continue
        key = (bits[0], "." + tail_side)
        out.setdefault(key, []).append((int(bits[-1]), bone.name))
    return [[n for _i, n in sorted(rows)] for _k, rows in sorted(out.items())]


def open_cut(points, frame, angles):
    """Where a part that does not go all the way round is open, as an azimuth, or None.

    The widest azimuth gap between the part's own points is the opening when it is
    clearly wider than the spacing of the columns: a wrap skirt with a slit leaves no
    vertex there, while a closed ring never has a gap wider than its own columns.
    """
    az = sorted(frame.az(p) for p in points)
    if len(az) < 2 or len(angles) < 2:
        return None
    gaps = [(az[(k + 1) % len(az)] - az[k]) % (2.0 * math.pi) for k in range(len(az))]
    k = max(range(len(gaps)), key=gaps.__getitem__)
    cols = sorted(angles)
    spacing = sorted((cols[(j + 1) % len(cols)] - cols[j]) % (2.0 * math.pi) for j in range(len(cols)))
    if gaps[k] <= 1.5 * spacing[len(spacing) // 2]:
        return None
    return az[k] + gaps[k] * 0.5


def layer_sampler(donor, names, max_mm=60.0):
    """A function point -> {group: weight} reading ``donor``'s weights (only ``names``) on its
    nearest face, barycentric, at rest; ``None`` where the donor is further than ``max_mm``."""
    from mathutils import geometry
    from mathutils.bvhtree import BVHTree
    me = donor.data
    me.calc_loop_triangles()
    mw = donor.matrix_world
    verts = [mw @ v.co for v in me.vertices]
    tris = [tuple(t.vertices) for t in me.loop_triangles]
    tree = BVHTree.FromPolygons(verts, tris)
    gname = {g.index: g.name for g in donor.vertex_groups}
    per_vertex = [{gname[g.group]: g.weight for g in v.groups
                   if gname.get(g.group) in names and g.weight > 0.0} for v in me.vertices]
    reach = max_mm / 1000.0

    def sample(point):
        hit = tree.find_nearest(point, reach)
        if hit[0] is None:
            return None
        a, b, c = (verts[i] for i in tris[hit[2]])
        bary = geometry.barycentric_transform(hit[0], a, b, c, Vector((1, 0, 0)), Vector((0, 1, 0)),
                                              Vector((0, 0, 1)))
        out = {}
        for share, vi in zip(bary, tris[hit[2]]):
            for name, w in per_vertex[vi].items():
                out[name] = out.get(name, 0.0) + max(0.0, share) * w
        return out
    return sample


def strip_weights(mesh_object, armature, columns, indices, blend_mm=40.0, closed=True, axis=None,
                  centre=None, donor=None, null_bones=None):
    """Weight the part onto strip columns by azimuth and by height. (report, error)

    ``closed`` None decides from the part: open where the part leaves a gap wider than
    its columns (:func:`open_cut`). The two end columns of an open part are never
    blended across the opening -- doing so dragged the edge of a slit skirt towards the
    strip on the far side of the slit. ``centre`` (a world point) is what azimuths are
    measured round; by default the mean of the column heads.

    Around: the two columns on either side of a vertex share it linearly by azimuth.
    Down: within a column, each bone is a tent centred on its middle, so the weight
    passes from one bone to the next across the joint instead of stepping at it.
    The top ``blend_mm`` blends from the part's existing weights into the strips, so
    the waistband stays on the body while the strips below swing.

    ``donor`` (the garment underneath) gives the top its weights instead: both Armature
    stages, read on the donor's nearest face. Where a skirt's top hangs over shorts, the
    thigh lifting pushes the shorts' hip crease forward through a top that keeps the
    waist's weights. A second stage (ARP's rig_add) normalises on its own, so its weights
    cannot be faded by scaling; they are faded onto that armature's null bone -- a deform
    bone that never moves, named in ``null_bones`` or found by 'null' in its name -- and
    dropped below the blend as before. Without a null bone they are dropped wherever the
    strips take any share.
    """
    if not columns:
        return None, "No strip columns"
    mw = mesh_object.matrix_world
    am = armature.matrix_world
    rows = []
    for col in columns:
        segs = []
        for name in col:
            b = armature.data.bones.get(name)
            if b is not None:
                segs.append((name, am @ b.head_local, am @ b.tail_local))
        if segs:
            rows.append(segs)
    if not rows:
        return None, "None of the strip bones is on the rig"
    heads = [r[0][1] for r in rows]
    origin = Vector((sum(h.x for h in heads), sum(h.y for h in heads), sum(h.z for h in heads))) / len(heads)
    if centre is not None:
        origin = Vector((centre[0], centre[1], origin.z))
    if axis is None:
        axis = Vector((0.0, 0.0, 0.0))
        for r in rows:
            axis += (r[-1][2] - r[0][1])
        if axis.length <= 1.0e-9:
            axis = Vector((0.0, 0.0, -1.0))
    frame = Frame(origin, axis)
    cut = None
    if closed is None:
        cut = open_cut([mw @ mesh_object.data.vertices[i].co for i in set(indices)], frame,
                       [frame.az(r[0][1]) for r in rows])
        closed = cut is None
    # an open part's columns run from one side of its opening to the other
    start = cut if cut is not None else -math.pi
    order = sorted(range(len(rows)), key=lambda k: (frame.az(rows[k][0][1]) - start) % (2.0 * math.pi))
    rows = [rows[k] for k in order]
    angles = [frame.az(r[0][1]) for r in rows]
    deform = {b.name for b in armature.data.bones if b.use_deform}
    # Bones of the OTHER armature modifiers (ARP's rig_add). Each Armature modifier
    # normalises its own groups, so any weight left on rig_add moves the vertex by
    # that rig's full deformation however small it is: measured, strip vertices
    # still carrying c_thigh_bend_contact went 56-60mm into the thigh. Inside the
    # strips they are removed, not scaled.
    others = set()
    for modifier in mesh_object.modifiers:
        if modifier.type == "ARMATURE" and modifier.object is not None                 and modifier.object is not armature and modifier.object.type == "ARMATURE":
            others |= {b.name for b in modifier.object.data.bones if b.use_deform}
    nulls = set(null_bones or ())
    if donor is not None and null_bones is None:
        for modifier in mesh_object.modifiers:
            if modifier.type == "ARMATURE" and modifier.object is not None \
                    and modifier.object is not armature and modifier.object.type == "ARMATURE":
                found = sorted(b.name for b in modifier.object.data.bones if b.use_deform and "null" in b.name.lower())
                if found:
                    nulls.add(found[0])
    nulls &= others
    sample = layer_sampler(donor, deform | others) if donor is not None else None
    groups = {g.name: g for g in mesh_object.vertex_groups}
    names = {g.index: g.name for g in mesh_object.vertex_groups}
    for n in nulls:
        if n not in groups:
            groups[n] = mesh_object.vertex_groups.new(name=n)
            names[groups[n].index] = n
    for segs in rows:
        for name, _h, _t in segs:
            if name not in groups:
                groups[name] = mesh_object.vertex_groups.new(name=name)
                names[groups[name].index] = name
    blend = max(1.0e-6, float(blend_mm) / 1000.0)
    done = 0
    for i in sorted(set(indices)):
        v = mesh_object.data.vertices[i]
        p = mw @ v.co
        az = frame.az(p)
        # neighbouring columns around the part
        k = None
        for j in range(len(angles)):
            a0 = angles[j]
            a1 = angles[(j + 1) % len(angles)] if (closed or j + 1 < len(angles)) else None
            if a1 is None:
                break
            span = (a1 - a0) % (2.0 * math.pi) or 2.0 * math.pi
            off = (az - a0) % (2.0 * math.pi)
            if off <= span:
                k, frac = j, off / span
                break
        if k is None:
            # open strip set, outside its ends: the nearest end column alone
            k = min(range(len(angles)), key=lambda j: abs((az - angles[j] + math.pi) % (2.0 * math.pi) - math.pi))
            pairs = [(rows[k], 1.0)]
        else:
            pairs = [(rows[k], 1.0 - frac), (rows[(k + 1) % len(rows)], frac)]
        strip = {}
        top_along = 0.0
        for segs, share in pairs:
            if share <= 0.0:
                continue
            # parameter down the column: segment index + fraction along it
            best = None
            for s, (name, h, t) in enumerate(segs):
                ab = t - h
                f = 0.0 if ab.length_squared <= 0.0 else max(0.0, min(1.0, (p - h).dot(ab) / ab.length_squared))
                d = (p - (h + ab * f)).length
                if best is None or d < best[0]:
                    best = (d, s + f)
            param = best[1]
            for s, (name, _h, _t) in enumerate(segs):
                w = max(0.0, 1.0 - abs(param - (s + 0.5)))
                if s == 0 and param < 0.5:
                    w = 1.0
                if s == len(segs) - 1 and param > len(segs) - 0.5:
                    w = 1.0
                if w > 0.0:
                    strip[name] = strip.get(name, 0.0) + w * share
            top_along += frame.along(segs[0][1]) * share
        total = sum(strip.values())
        if total <= 0.0:
            continue
        strip = {n: w / total for n, w in strip.items()}
        t = max(0.0, min(1.0, (frame.along(p) - top_along) / blend))
        t = t * t * (3.0 - 2.0 * t)
        own = {names[g.group]: g.weight for g in v.groups if names.get(g.group) in deform}
        taken = sample(p) if (sample is not None and t < 1.0) else None
        old = {n: w for n, w in taken.items() if n in deform} if taken else own
        old_total = sum(old.values())
        if old_total > 0.0:
            old = {n: w / old_total for n, w in old.items()}
        mixed = {n: w * (1.0 - t) for n, w in old.items()}
        for n, w in strip.items():
            mixed[n] = mixed.get(n, 0.0) + w * t
        for n in set(old) | set(own):
            if mixed.get(n, 0.0) <= 1.0e-4 and n in groups:
                groups[n].remove([i])
        second = {}
        if taken:
            raw = {n: w for n, w in taken.items() if n in others}
            total2 = sum(raw.values())
            if total2 > 0.0 and (t <= 0.0 or (nulls and t < 1.0)):
                second = {n: w / total2 * (1.0 - t) for n, w in raw.items()}
                for n in nulls:
                    second[n] = second.get(n, 0.0) + t
        if t > 0.0 or taken:
            for g in list(v.groups):
                n = names.get(g.group)
                if n in others and second.get(n, 0.0) <= 1.0e-4:
                    groups[n].remove([i])
        for n, w in second.items():
            if w > 1.0e-4:
                if n not in groups:
                    groups[n] = mesh_object.vertex_groups.new(name=n)
                    names[groups[n].index] = n
                groups[n].add([i], w, "REPLACE")
        for n, w in mixed.items():
            if w > 1.0e-4:
                groups[n].add([i], w, "REPLACE")
        done += 1
    return {"vertices": done, "columns": len(rows), "bones": sum(len(r) for r in rows),
            "closed": bool(closed), "open_at_deg": round(math.degrees(cut), 1) if cut is not None else None}, ""


# ----------------------------------------------------------------------------------------------- leg push
# ARP keeps each strip's target on the far side of a plane that sits ``collide_dist`` off the leg's axis
# (driver on <kilt>_leg<n>_floortar_off<side>.location). A thigh is round, not flat: a plane far enough out
# to clear the thigh at every angle also swings the front strips up past a raised thigh towards the chest.
# Measured on MIK (2026-10-04): collide_dist 0.60 put the front strip tips 70-84 deg above horizontal at a
# 90 deg hip flexion, and the pleats 186-196 mm above the skirt's top. Easing the plane back in above 60 deg
# (to 35 % at 90 deg) with collide_dist 0.25 lets the strips lift with the thigh up to 60 deg and lie on it
# at 90 deg; in four CMU dances the strips crossed the body less, less deep, and stood above 45 deg in 1
# frame instead of 14.
ARP_PUSH_EXPRESSION = "dist * (min(1,rot_diff*2)+rot_falloff)"
_EASED_PUSH = None


def _num(value):
    """Two decimals, trailing zeros dropped: the form the eased expression is written (and read back) in."""
    text = "%.2f" % float(value)
    return text.rstrip("0").rstrip(".") if "." in text else text


def push_expression(ease_start_deg=60.0, ease_end_deg=90.0, keep=0.35):
    """ARP's leg-push offset, eased off between two leg-swing angles down to ``keep`` of itself.

    ``keep`` 1 (or an empty angle range) gives ARP's own expression back unchanged.
    """
    keep = max(0.0, min(1.0, float(keep)))
    start = math.radians(float(ease_start_deg))
    width = math.radians(float(ease_end_deg)) - start
    if keep >= 1.0 or width <= 1.0e-6:
        return ARP_PUSH_EXPRESSION
    return "%s * (1 - %s*min(1, max(0, (rot_diff-%s)/%s)))" % (
        ARP_PUSH_EXPRESSION, _num(1.0 - keep), _num(start), _num(width))


def _is_push_expression(text):
    """ARP's own expression, or one this module wrote. Anything else was edited by hand."""
    global _EASED_PUSH
    import re
    if _EASED_PUSH is None:
        number = r"[0-9]+(?:\.[0-9]+)?"
        _EASED_PUSH = re.compile(r"^%s \* \(1 - %s\*min\(1, max\(0, \(rot_diff-%s\)/%s\)\)\)$" % (
            re.escape(ARP_PUSH_EXPRESSION), number, number, number))
    text = str(text or "").strip()
    return text == ARP_PUSH_EXPRESSION or _EASED_PUSH.match(text) is not None


def leg_push_drivers(armature, name="kilt"):
    """``(master pose bone, [driver F-curves], side, error)`` of an existing kilt's two leg-push drivers."""
    if armature is None or armature.type != "ARMATURE":
        return None, [], "", "Choose the rig first."
    side = None
    for bone in armature.data.bones:
        prefix, sep, rest = bone.name.partition("_master_ref")
        if sep and prefix == name:
            side = rest
            break
    master = armature.pose.bones.get("c_%s_master%s" % (name, side)) if side is not None else None
    if master is None:
        return None, [], "", "This rig has no kilt with that name."
    if "collide_dist" not in master.keys():
        return None, [], side, "This kilt has no collide distance (it was built without Collide)."
    ad = armature.animation_data
    drivers = {(d.data_path, d.array_index): d for d in (ad.drivers if ad is not None else ())}
    found = []
    for leg in (0, 1):
        path = 'pose.bones["%s_leg%d_floortar_off%s"].location' % (name, leg, side)
        hits = [d for (p, _i), d in drivers.items() if p == path]
        if len(hits) != 1:
            return None, [], side, "This kilt's leg-push drivers are missing (it was built without Collide)."
        found.append(hits[0])
    return master, found, side, ""


def set_leg_push(armature, name="kilt", collide_dist=0.25, ease_start_deg=60.0, ease_end_deg=90.0, keep=0.35):
    """Set how far an existing kilt's strips are pushed off the legs, and ease the push off above
    ``ease_start_deg`` of leg swing so the strips lie on a raised thigh. ``(report, error)``.

    Only ARP's own expression or one written here is replaced; a driver edited by hand is left alone and
    nothing is changed. Running it again with the same values changes nothing.
    """
    master, drivers, side, error = leg_push_drivers(armature, name)
    if error:
        return None, error
    if not all(_is_push_expression(d.driver.expression) for d in drivers):
        return None, "A leg-push driver of this kilt was edited by hand; nothing was changed."
    if float(collide_dist) < 0.0 or float(ease_start_deg) < 0.0 or float(ease_end_deg) < float(ease_start_deg):
        return None, "Use a distance of 0 or more and an easing range that ends after it starts."
    expression = push_expression(ease_start_deg, ease_end_deg, keep)
    before = [d.driver.expression for d in drivers] + [float(master["collide_dist"])]
    for d in drivers:
        if d.driver.expression != expression:
            d.driver.expression = expression
    master["collide_dist"] = float(collide_dist)
    armature.update_tag()
    return {"name": name, "side": side, "expression": expression, "collide_dist": float(collide_dist),
            "drivers": len(drivers), "simple": all(d.driver.is_simple_expression for d in drivers),
            "changed": before != [d.driver.expression for d in drivers] + [float(master["collide_dist"])]}, ""
