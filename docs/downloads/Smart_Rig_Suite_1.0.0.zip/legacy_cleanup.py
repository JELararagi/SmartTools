# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import functools
import shutil
import sys
from collections import OrderedDict
from pathlib import Path
from types import ModuleType
from typing import Any

import bpy

from . import generation


# Root entries used only by the former 1.x all-in-one package. Cleanup is
# strictly confined to the active Smart Rig Suite extension folder.
OBSOLETE_PACKAGE_DIRS = (
    "armpie",
    "cloudrig",
    "core",
    "driver_copy_io",
    "dynamic_rig_ui",
    "easyweight",
    "fakebones",
    "icons",
    "ikfk_snapping",
    "mpfb",
    "smart_rig_smart",  # keep-legacy-name
    "smart_rig_ai_runtime",
    "smart_rig_core",
    "smart_rig_motion_tools",
    "auto_rig_pro",
    "ARP_rig_tools",
    "proxy_picker",
)

OBSOLETE_PACKAGE_FILES = (
    "THIRD_PARTY_NOTICES.txt",
    "arp_bridge.py",
    "common.py",
    "consolidation.py",
    "feature_toggle.py",
    "guide.py",
    "help.py",
    "help_catalog.py",
    "language.py",
    "language_extra.py",
    "naming.py",
    "persistent_features.py",
    "proxy_cleanup.py",
    "registration.py",
    "rig_build_workflow.py",
    "runtime.py",
    "smart_rig_smart_ui_icons.py",  # keep-legacy-name
    "source_inventory.py",
    "srs_ai_runtime.py",
    "srs_context_safety.py",
    "srs_proxy_picker.py",
    "srs_ui_icon_safety.py",
    "storage.py",
    "tool_metadata.py",
    "translation.py",
    "ui_five_genres.py",
    "user_data.py",
)

_OBSOLETE_DIR_KEYS = frozenset(name.lower() for name in OBSOLETE_PACKAGE_DIRS)
_OBSOLETE_FILE_KEYS = frozenset(name.lower() for name in OBSOLETE_PACKAGE_FILES)
_OBSOLETE_MODULE_ROOTS = frozenset(
    {*_OBSOLETE_DIR_KEYS, *(Path(name).stem.lower() for name in OBSOLETE_PACKAGE_FILES if name.endswith(".py"))}
)

_LAST_RUNTIME_PURGE: dict[str, int] = {
    "properties": 0,
    "classes": 0,
    "handlers": 0,
    "timers": 0,
    "msgbus": 0,
    "keymaps": 0,
    "patches": 0,
    "modules": 0,
}
_LAST_PAYLOAD_PURGE: dict[str, int] = {"directories": 0, "files": 0}
_LAST_MIGRATION_STATE: dict[str, Any] = {
    "state": "not_run",
    "restart_required": False,
    "reason": "",
    "legacy_rna": [],
}
_MIGRATION_CACHE_LIMIT = 4
_COMPLETED_MIGRATIONS: OrderedDict[tuple[str, str], None] = OrderedDict()


def _safe_resolve(path: str | Path) -> Path:
    try:
        return Path(path).resolve()
    except Exception:
        return Path(path).absolute()


def _module_uses_package_dir(module: Any, package_dir: Path) -> bool:
    try:
        module_file = _safe_resolve(module.__file__)
        module_file.relative_to(package_dir)
        return True
    except Exception:
        return False


def _package_prefixes(current_prefix: str, package_dir: Path) -> set[str]:
    prefixes = {str(current_prefix or "smart_rig_suite")}
    for name, module in tuple(sys.modules.items()):
        if not name or module is None or not _module_uses_package_dir(module, package_dir):
            continue
        if name == "smart_rig_suite" or name.endswith(".smart_rig_suite"):
            prefixes.add(name)
        elif ".smart_rig_suite." in name:
            prefixes.add(name.split(".smart_rig_suite.", 1)[0] + ".smart_rig_suite")
        elif name.startswith("smart_rig_suite."):
            prefixes.add("smart_rig_suite")
    return prefixes


def _module_name_is_obsolete(module_name: str, prefixes: set[str]) -> bool:
    name = str(module_name or "")
    for prefix in prefixes:
        if name == prefix or not name.startswith(prefix + "."):
            continue
        relative = name[len(prefix) + 1 :]
        root = relative.split(".", 1)[0].lower()
        if root in _OBSOLETE_MODULE_ROOTS:
            return True
    return False


def _relative_path_is_obsolete(relative: Path) -> bool:
    if not relative.parts:
        return False
    first = relative.parts[0].lower()
    if first in _OBSOLETE_DIR_KEYS:
        return True
    if len(relative.parts) == 1 and relative.name.lower() in _OBSOLETE_FILE_KEYS:
        return True
    if first == "__pycache__":
        module_stem = relative.name.lower().split(".", 1)[0]
        return module_stem in _OBSOLETE_MODULE_ROOTS
    return False


def _module_is_obsolete(name: str, module: Any, prefixes: set[str], package_dir: Path) -> bool:
    if _module_name_is_obsolete(name, prefixes):
        return True
    if module is None:
        return False
    try:
        relative = _safe_resolve(module.__file__).relative_to(package_dir)
    except Exception:
        return False
    return _relative_path_is_obsolete(relative)


def _obsolete_loaded_modules(prefixes: set[str], package_dir: Path) -> dict[str, Any]:
    return {
        name: module
        for name, module in tuple(sys.modules.items())
        if name and module is not None and _module_is_obsolete(name, module, prefixes, package_dir)
    }


def _callable_origins(value: Any, *, _seen: set[int] | None = None, _depth: int = 0) -> set[str]:
    """Collect module origins through wrappers, partials, methods and closures."""
    if value is None or _depth > 5:
        return set()
    seen = _seen if _seen is not None else set()
    identity = id(value)
    if identity in seen:
        return set()
    seen.add(identity)
    result: set[str] = set()

    module_name = str(getattr(value, "__module__", "") or "")
    if module_name:
        result.add(module_name)
    try:
        type_module = str(type(value).__module__ or "")
        if type_module:
            result.add(type_module)
    except Exception:
        pass

    if isinstance(value, functools.partial):
        result.update(_callable_origins(value.func, _seen=seen, _depth=_depth + 1))
        for item in value.args:
            result.update(_callable_origins(item, _seen=seen, _depth=_depth + 1))
        for item in (value.keywords or {}).values():
            result.update(_callable_origins(item, _seen=seen, _depth=_depth + 1))

    for attr in ("__func__", "__self__", "__wrapped__", "func", "callback", "notify"):
        try:
            nested = getattr(value, attr, None)
        except Exception:
            nested = None
        if nested is not None and nested is not value:
            result.update(_callable_origins(nested, _seen=seen, _depth=_depth + 1))

    try:
        closure = getattr(value, "__closure__", None) or ()
    except Exception:
        closure = ()
    for cell in closure:
        try:
            nested = cell.cell_contents
        except Exception:
            continue
        result.update(_callable_origins(nested, _seen=seen, _depth=_depth + 1))

    if isinstance(value, ModuleType):
        result.add(str(getattr(value, "__name__", "") or ""))
    return {name for name in result if name}


def _callable_is_obsolete(value: Any, prefixes: set[str], package_dir: Path) -> bool:
    for module_name in _callable_origins(value):
        module = sys.modules.get(module_name)
        if _module_is_obsolete(module_name, module, prefixes, package_dir):
            return True
    return False


def _obsolete_registry_callback_ids(prefixes: set[str], package_dir: Path) -> set[int]:
    """Retain callback ownership even when callable metadata was rewritten."""
    active = generation.active_generation(for_cleanup=True)
    if not isinstance(active, dict):
        return set()
    result: set[int] = set()
    for list_name in ("handlers", "timers", "patches", "cleanups"):
        for record in active.get(list_name, ()):
            if not isinstance(record, dict):
                continue
            module_name = str(record.get("module") or "")
            module = sys.modules.get(module_name)
            if not _module_is_obsolete(module_name, module, prefixes, package_dir):
                continue
            for value in (record.get("identity"), record.get("replacement"), record.get("original")):
                if value is not None:
                    result.add(id(value))
    return result


def _callback_matches_registry(value: Any, identities: set[int]) -> bool:
    if id(value) in identities:
        return True
    for attr in (
        "_jelararagi_status_original_v2",
        "_jelararagi_status_original_v3",
        "_srs_original",
        "__wrapped__",
    ):
        try:
            nested = getattr(value, attr, None)
        except Exception:
            nested = None
        if nested is not None and id(nested) in identities:
            return True
    return False


def _iter_handler_collections() -> list[tuple[str, Any]]:
    result: list[tuple[str, Any]] = []
    handlers = getattr(bpy.app, "handlers", None)
    if handlers is None:
        return result
    for name in tuple(dir(handlers)):
        if name.startswith("_") or name == "persistent":
            continue
        try:
            collection = getattr(handlers, name)
            tuple(collection)
        except Exception:
            continue
        if not hasattr(collection, "remove"):
            continue
        result.append((name, collection))
    return result


def _unregister_obsolete_handlers(
    prefixes: set[str],
    package_dir: Path,
    registry_identities: set[int],
) -> int:
    removed = 0
    for _handler_name, collection in _iter_handler_collections():
        for callback in tuple(collection):
            if not (
                _callback_matches_registry(callback, registry_identities)
                or _callable_is_obsolete(callback, prefixes, package_dir)
            ):
                continue
            try:
                while any(item is callback for item in tuple(collection)):
                    for item in tuple(collection):
                        if item is callback:
                            collection.remove(item)
                            removed += 1
                            break
            except Exception:
                pass
    return removed


def _unregister_obsolete_timers(
    modules: dict[str, Any],
    prefixes: set[str],
    package_dir: Path,
    registry_identities: set[int],
) -> int:
    removed = 0
    seen: set[int] = set()
    candidates: list[Any] = []
    for module in tuple(modules.values()):
        try:
            candidates.extend(tuple(vars(module).values()))
        except Exception:
            pass

    # A generation registry retains callbacks even when their module globals were
    # replaced by in-place execution or their sys.modules entry was removed.
    active = generation.active_generation(for_cleanup=True)
    if isinstance(active, dict):
        for list_name in ("timers", "handlers", "patches", "cleanups"):
            for record in active.get(list_name, ()):
                if not isinstance(record, dict):
                    continue
                candidates.extend(
                    value for value in (
                        record.get("identity"),
                        record.get("replacement"),
                        record.get("original"),
                    ) if value is not None
                )

    for value in candidates:
        if not callable(value) or id(value) in seen:
            continue
        seen.add(id(value))
        if not (id(value) in registry_identities or _callable_is_obsolete(value, prefixes, package_dir)):
            continue
        try:
            if bpy.app.timers.is_registered(value):
                bpy.app.timers.unregister(value)
                removed += 1
        except Exception:
            pass
    return removed


def _obsolete_rna_classes(prefixes: set[str], package_dir: Path) -> list[type]:
    base_types: tuple[type, ...] = tuple(
        item for item in (
            getattr(bpy.types, "Operator", None),
            getattr(bpy.types, "Panel", None),
            getattr(bpy.types, "Menu", None),
            getattr(bpy.types, "UIList", None),
            getattr(bpy.types, "PropertyGroup", None),
            getattr(bpy.types, "AddonPreferences", None),
            getattr(bpy.types, "Gizmo", None),
            getattr(bpy.types, "GizmoGroup", None),
        ) if isinstance(item, type)
    )
    result: list[type] = []
    for name in tuple(dir(bpy.types)):
        try:
            cls = getattr(bpy.types, name)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        try:
            if base_types and not issubclass(cls, base_types):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, "__module__", ""))
        module = sys.modules.get(module_name)
        if _module_is_obsolete(module_name, module, prefixes, package_dir):
            result.append(cls)
    return result


def _legacy_rna_details(classes: list[type]) -> list[dict[str, str]]:
    details = []
    for cls in classes:
        kind = "RNAClass"
        for label, base_name in (
            ("Panel", "Panel"),
            ("Operator", "Operator"),
            ("PropertyGroup", "PropertyGroup"),
            ("AddonPreferences", "AddonPreferences"),
        ):
            base = getattr(bpy.types, base_name, None)
            try:
                if isinstance(base, type) and issubclass(cls, base):
                    kind = label
                    break
            except Exception:
                pass
        details.append({
            "name": str(getattr(cls, "__name__", "")),
            "module": str(getattr(cls, "__module__", "")),
            "kind": kind,
        })
    return details


def purge_stale_package_runtime(current_prefix: str, package_dir: str | Path) -> dict[str, int]:
    """Detach obsolete callbacks, but never unregister live legacy RNA in-process."""
    global _LAST_RUNTIME_PURGE
    root = _safe_resolve(package_dir)
    prefixes = _package_prefixes(current_prefix, root)
    modules = _obsolete_loaded_modules(prefixes, root)
    registry_identities = _obsolete_registry_callback_ids(prefixes, root)
    handlers = _unregister_obsolete_handlers(prefixes, root, registry_identities)
    timers = _unregister_obsolete_timers(modules, prefixes, root, registry_identities)
    _LAST_RUNTIME_PURGE = {
        "properties": 0,
        "classes": 0,
        "handlers": handlers,
        "timers": timers,
        "msgbus": 0,
        "keymaps": 0,
        "patches": 0,
        "modules": 0,
    }
    return dict(_LAST_RUNTIME_PURGE)


def remove_obsolete_package_payload(package_dir: str | Path) -> dict[str, int]:
    """Delete former bundled-tool payload from this extension folder only."""
    global _LAST_PAYLOAD_PURGE
    root = _safe_resolve(package_dir)
    removed_dirs = 0
    removed_files = 0

    for name in OBSOLETE_PACKAGE_DIRS:
        target = root / name
        if not target.is_dir():
            continue
        try:
            target.relative_to(root)
            shutil.rmtree(target)
            removed_dirs += 1
        except Exception:
            pass

    for name in OBSOLETE_PACKAGE_FILES:
        target = root / name
        if not target.is_file():
            continue
        try:
            target.relative_to(root)
            target.unlink()
            removed_files += 1
        except Exception:
            pass

    cache = root / "__pycache__"
    if cache.is_dir():
        for target in tuple(cache.iterdir()):
            try:
                relative = target.relative_to(root)
            except Exception:
                continue
            if not target.is_file() or not _relative_path_is_obsolete(relative):
                continue
            try:
                target.unlink()
                removed_files += 1
            except Exception:
                pass
        try:
            if not any(cache.iterdir()):
                cache.rmdir()
                removed_dirs += 1
        except Exception:
            pass

    _LAST_PAYLOAD_PURGE = {"directories": removed_dirs, "files": removed_files}
    return dict(_LAST_PAYLOAD_PURGE)


def run_migration_once(
    current_prefix: str,
    package_dir: str | Path,
    *,
    revision: str,
) -> dict[str, Any]:
    """Run migration; legacy live RNA always defers activation until restart."""
    global _LAST_PAYLOAD_PURGE, _LAST_MIGRATION_STATE
    root = _safe_resolve(package_dir)
    key = (str(root), str(revision))
    if key in _COMPLETED_MIGRATIONS:
        return migration_status()

    purge_stale_package_runtime(current_prefix, root)
    prefixes = _package_prefixes(current_prefix, root)
    legacy_classes = _obsolete_rna_classes(prefixes, root)
    details = _legacy_rna_details(legacy_classes)
    if details:
        _LAST_PAYLOAD_PURGE = {"directories": 0, "files": 0}
        reason = (
            f"{len(details)} classes of an older Smart Rig Suite are still loaded, "
            "so this one waits until Blender restarts"
        )
        _LAST_MIGRATION_STATE = {
            "state": "deferred",
            "restart_required": True,
            "reason": reason,
            "legacy_rna": details,
        }
        generation.mark_restart_required(reason, revision=revision)
        # Deliberately do not cache this as completed. The next call must recheck
        # after the process has been restarted or external cleanup has succeeded.
        return migration_status()

    remove_obsolete_package_payload(root)
    _LAST_MIGRATION_STATE = {
        "state": "completed",
        "restart_required": False,
        "reason": "",
        "legacy_rna": [],
    }
    _COMPLETED_MIGRATIONS[key] = None
    _COMPLETED_MIGRATIONS.move_to_end(key)
    while len(_COMPLETED_MIGRATIONS) > _MIGRATION_CACHE_LIMIT:
        _COMPLETED_MIGRATIONS.popitem(last=False)
    return migration_status()


def migration_status() -> dict[str, Any]:
    return {
        "runtime": dict(_LAST_RUNTIME_PURGE),
        "payload": dict(_LAST_PAYLOAD_PURGE),
        "state": str(_LAST_MIGRATION_STATE.get("state") or "not_run"),
        "restart_required": bool(_LAST_MIGRATION_STATE.get("restart_required")),
        "reason": str(_LAST_MIGRATION_STATE.get("reason") or ""),
        "legacy_rna": list(_LAST_MIGRATION_STATE.get("legacy_rna", ())),
    }


# Backward-compatible name used by 2.0.0's entry point.
def purge_stale_embedded_runtime() -> None:
    package_dir = Path(__file__).resolve().parent
    prefix = str(__package__ or "smart_rig_suite")
    purge_stale_package_runtime(prefix, package_dir)


def legacy_scene_candidates() -> dict[str, list[str]]:
    objects = [
        obj.name
        for obj in bpy.data.objects
        if obj.name.startswith("SRS_HELPER_")
        or obj.name == "SRS_Procedural_Rig"
        or bool(obj.get("srs_helper"))
        or bool(obj.get("srs_generated_rig"))
    ]
    scene_props = []
    for scene in bpy.data.scenes:
        for key in scene.keys():
            if str(key).startswith(("srs_ai_runtime_", "srs_rig_builder_", "srs_helper_")):
                scene_props.append(f"{scene.name}:{key}")
    return {"objects": objects, "scene_properties": scene_props}


def clean_legacy_scene_data() -> dict[str, int]:
    removed_objects = 0
    removed_props = 0
    for obj in tuple(bpy.data.objects):
        if not (
            obj.name.startswith("SRS_HELPER_")
            or obj.name == "SRS_Procedural_Rig"
            or bool(obj.get("srs_helper"))
            or bool(obj.get("srs_generated_rig"))
        ):
            continue
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
            removed_objects += 1
        except Exception:
            pass
    for scene in bpy.data.scenes:
        for key in tuple(scene.keys()):
            if str(key).startswith(("srs_ai_runtime_", "srs_rig_builder_", "srs_helper_")):
                try:
                    del scene[key]
                    removed_props += 1
                except Exception:
                    pass
    return {"objects": removed_objects, "scene_properties": removed_props}
