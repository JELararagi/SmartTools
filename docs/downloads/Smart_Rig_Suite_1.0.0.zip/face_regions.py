# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Name the parts of a face as vertex-index lists, the same way every time.

Every complaint about a face is about a region -- "the upper lip is dragged
down", "the brows collapse", "the lid breaks shape" -- and none of those can be
measured, let alone declared fixed, until the region is a fixed set of vertices.
Measured on the reference character, the same defect reported over two equally
defensible definitions of "the upper lip" gave 110 vertices or 205, a jaw drag of
21.5 per cent or 39.4, and a jaw-side weight share of 4.56 per cent or 24.9. A
number like that says nothing about the mesh; it says which region was picked.

So the regions here are derived from topology and from the rig, never from a
height plane chosen by eye, and they are returned as index lists that a caller
writes down beside the evidence. Two runs must agree exactly, and ``freeze``
reports a digest so that can be checked rather than trusted.

Three things this module knows about the reference face, because each of them has
already produced a wrong answer somewhere:

**The head has three boundary rings, not two.** Two are the eye sockets at 24
vertices each; the third is a 50-vertex hole at the crown where the scalp is
missing. Code that assumes two rings silently treats the scalp opening as an eye.

**The lip crevice is not a height, and it is not a weight either.** The upper
lip's inner wall and the lower lip's top wall interleave in Z, so splitting the
mouth at a plane assigns one wall to the wrong lip. Splitting it by which lip
bone holds more weight is worse, because it is circular: a vertex of the upper lip
that has wrongly picked up lower-lip weight is then classified as lower lip and
escapes the very fix it needs. Measured, v270 is exactly that case -- its normal
points downward, so it belongs to the upper lip's inner wall, while it carries
0.560 of a lower-lip bone against 0.269 of an upper one. The split therefore uses
the TEETH, which are separate meshes: whichever row of teeth a lip vertex is
nearer is the lip it belongs to. That is independent of every weight on the face.
Right at the crevice the teeth are too close to call -- v270 sits 1.446mm from one
row and 1.344mm from the other -- so there the vertex normal decides instead, and
ONLY there: away from the crevice the lower lip's outer underside faces downward
exactly as the upper lip's inner wall does, and trusting the normal across the
whole lip handed six correctly-weighted lower-lip vertices to the upper lip, where
a repair would have stripped the weight that was doing the right thing.
The vertex normal's Z is still reported for each lip vertex -- the reference
character's lower-lip top wall reads about +0.92 -- because a caller stripping
weight needs to know which wall it is standing on.

**Weight is not membership.** A vertex carrying 0.01 of a brow bone is not part
of the brow. Thresholds are therefore explicit arguments and are reported back in
the result, so a later reader can tell whether a figure was computed over the
same set.
"""

import bpy
from mathutils import Vector

from . import bind_common
from . import eye_setup

# What counts as belonging to a region at all. Small enough to catch real
# influence, large enough to keep interpolation dust out of the count.
MEMBERSHIP_WEIGHT = 0.05
SOCKET_RING_SIZE = 24
# How steeply a lip vertex has to face up or down before its own normal, rather
# than the nearer row of teeth, decides which lip it is. Measured on the reference
# face the two interleaving walls read about +0.9 and -0.33 while the outer lip
# surfaces face forward and read near zero, so this cleanly separates "wall" from
# "outer surface" without a height plane.
WALL_NORMAL_GATE = 0.25
# How near the teeth a lip vertex has to be before it counts as part of the
# crevice, where the two lips' walls interleave and the normal is the only honest
# discriminator. Away from the crevice the normal lies: the lower lip's OUTER
# underside faces down just as the upper lip's inner wall does, and trusting the
# normal there handed six correctly-weighted lower-lip vertices to the upper lip.
# Measured, the crevice vertices sit 1.3-1.5mm from a tooth row while the lower
# lip's underside sits 3.1-4.6mm away, so this separates them cleanly.
CREVICE_TEETH_MM = 2.5

# How lopsided the two teeth distances may be before the wall-normal override is
# refused. Measured on this face: 13 vertices sat 2.939-4.863mm nearer one row
# than the other and were still handed to the other lip by their normal, and one
# of them (v278, carrying c_lips_bot.x 0.6101 and no upper group at all) was
# enough to manufacture a "the upper lip cross-talks 76 per cent of the stroke"
# defect that does not exist. The four cases the override exists for are all
# inside 0.021-0.517mm, so vetoing above 1.5mm corrects 13 and breaks none.
NORMAL_OVERRIDE_MARGIN_MM = 1.5

# Below this the teeth are too close to call and the label is reported low
# confidence rather than silently trusted: the 11 remaining doubtful vertices
# were decided on margins of 0.021-0.517mm.
TEETH_CONFIDENT_MARGIN_MM = 1.0

# A normal-decided label is confident only when the wall is unambiguous, not
# merely past the gate that let the override fire.
NORMAL_CONFIDENT_Z = 0.5


def _vertex_normals_world(mesh_object):
    matrix = mesh_object.matrix_world.to_3x3().inverted().transposed()
    return [(matrix @ v.normal).normalized() for v in mesh_object.data.vertices]


def _group_sum(mesh_object, indices, predicate):
    """Summed weight per vertex over the groups whose name satisfies ``predicate``."""
    wanted = {g.index for g in mesh_object.vertex_groups if predicate(g.name)}
    if not wanted:
        return {}
    out = {}
    for index in indices:
        total = 0.0
        for entry in mesh_object.data.vertices[index].groups:
            if entry.group in wanted and entry.weight > 0.0:
                total += entry.weight
        if total > 0.0:
            out[index] = round(total, 6)
    return out


def aperture_ring(face_object, armature, side, ring_size=SOCKET_RING_SIZE):
    """The eye opening: the socket boundary ring, split into lid margins.

    Returns ``(region, error)``. The ring is chosen by proximity to the eye
    control's head rather than by size, because the head carries a third boundary
    loop -- the scalp opening -- that is larger than either socket.
    """
    if face_object is None or face_object.type != "MESH":
        return None, "No face mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    bone = armature.data.bones.get("c_eye" + side)
    if bone is None:
        return None, "The armature has no bone called c_eye%s" % side
    pivot = armature.matrix_world @ bone.head_local

    rings = eye_setup.boundary_rings(face_object)
    sized = [r for r in rings if len(r) == ring_size]
    if not sized:
        return None, ("%s has no %d-vertex boundary ring to use as an eye opening; "
                      "it has %s" % (face_object.name, ring_size,
                                     ", ".join(str(len(r)) for r in rings) or "none"))
    matrix = face_object.matrix_world
    best = None
    for ring in sized:
        centre = sum((matrix @ face_object.data.vertices[i].co for i in ring),
                     Vector()) / len(ring)
        distance = (centre - pivot).length
        if best is None or distance < best[0]:
            best = (distance, ring, centre)
    distance, ring, centre = best

    positions = {i: matrix @ face_object.data.vertices[i].co for i in ring}
    heights = sorted(p.z for p in positions.values())
    middle = 0.5 * (heights[len(heights) // 2 - 1] + heights[len(heights) // 2])
    upper = sorted(i for i in ring if positions[i].z >= middle)
    lower = sorted(i for i in ring if positions[i].z < middle)
    by_x = sorted(ring, key=lambda i: positions[i].x)
    rest = (sum(positions[i].z for i in upper) / len(upper)
            - sum(positions[i].z for i in lower) / len(lower))
    return {
        "side": side,
        "ring": ring,
        "upper": upper,
        "lower": lower,
        "corner_min_x": by_x[0],
        "corner_max_x": by_x[-1],
        "centre_mm": [round(c * 1000, 3) for c in centre],
        "centre_to_eye_pivot_mm": round(distance * 1000, 3),
        "rest_aperture_mm": round(rest * 1000, 3),
        "all_boundary_ring_sizes": sorted(len(r) for r in rings),
    }, ""


def lid_region(face_object, armature, side, threshold=MEMBERSHIP_WEIGHT):
    """Face vertices the eyelid deform bones actually hold.

    Only the sixteen indexed controls deform; ``c_eyelid_top``/``bot`` without an
    index, the base bones and every reference bone have ``use_deform`` off, so a
    weight there does nothing and they are excluded by asking the armature rather
    than by matching names.
    """
    if face_object is None or armature is None:
        return None, "Need a face mesh and an armature"
    deform = {b.name for b in armature.data.bones
              if b.use_deform and "c_eyelid" in b.name and b.name.endswith(side)}
    if not deform:
        return None, "No deforming eyelid bone ends in %r" % side
    sums = _group_sum(face_object, range(len(face_object.data.vertices)),
                      lambda n: n in deform)
    picked = sorted(i for i, total in sums.items() if total >= threshold)
    return {"side": side, "bones": sorted(deform), "vertices": picked,
            "threshold": threshold, "count": len(picked)}, ""


def lip_regions(face_object, teeth_upper=None, teeth_lower=None,
                threshold=MEMBERSHIP_WEIGHT):
    """Upper and lower lip, split by which row of teeth each vertex is nearer.

    Returns ``(region, error)``.

    The teeth are the discriminator because they are separate meshes and carry no
    part in the lip weights, so the split cannot be circular. See the module
    docstring for why the two obvious alternatives -- a height plane and a
    comparison of lip-bone weight -- both misclassify the vertices that matter.

    ``mislabelled_by_weight`` is the payload a fix actually wants: lip vertices
    whose geometry says one lip while their weights say the other.
    """
    if face_object is None or face_object.type != "MESH":
        return None, "No face mesh"
    if teeth_upper is None or teeth_lower is None:
        return None, ("Both teeth meshes are required: they are what separates "
                      "the lips without consulting the weights that are under "
                      "suspicion")
    count = len(face_object.data.vertices)
    tops = _group_sum(face_object, range(count),
                      lambda n: "lips_top" in n or "lips_roll_top" in n)
    bots = _group_sum(face_object, range(count),
                      lambda n: "lips_bot" in n or "lips_roll_bot" in n)
    if not tops and not bots:
        return None, "%s carries no lip weights" % face_object.name
    normals = _vertex_normals_world(face_object)

    from mathutils.bvhtree import BVHTree

    def tree_for(obj):
        matrix = obj.matrix_world
        verts = [matrix @ v.co for v in obj.data.vertices]
        polys = [list(p.vertices) for p in obj.data.polygons]
        return BVHTree.FromPolygons(verts, polys, all_triangles=False, epsilon=0.0)

    up_tree = tree_for(teeth_upper)
    low_tree = tree_for(teeth_lower)
    face_matrix = face_object.matrix_world

    candidates = sorted(i for i in set(tops) | set(bots)
                        if max(tops.get(i, 0.0), bots.get(i, 0.0)) >= threshold)
    upper, lower, mislabelled, distances, decisions = [], [], [], {}, {}
    confidence, margins = {}, {}
    for index in candidates:
        point = face_matrix @ face_object.data.vertices[index].co
        up_hit = up_tree.find_nearest(point)
        low_hit = low_tree.find_nearest(point)
        if up_hit[0] is None or low_hit[0] is None:
            continue
        d_up = (point - up_hit[0]).length
        d_low = (point - low_hit[0]).length
        distances[str(index)] = [round(d_up * 1000, 3), round(d_low * 1000, 3)]
        decided_by = "teeth"
        # The wall the vertex faces decides first, and the teeth only break a
        # tie. Measured, the teeth alone get the crevice wrong both ways: v270
        # sits 1.446mm from the upper row and 1.344mm from the lower, a 0.1mm
        # margin that is noise, while the lower lip's own top wall (v263, v1300,
        # v1417 at normal z about +0.9) is physically NEARER the upper teeth and
        # would be handed to the upper lip. A downward-facing wall belongs to the
        # upper lip and an upward-facing one to the lower lip, whatever is nearer.
        normal_z = normals[index].z
        near_crevice = min(d_up, d_low) <= CREVICE_TEETH_MM * 0.001
        margin = abs(d_up - d_low)
        # The override is for a tie, so it is refused once the teeth stop being
        # ambiguous. Without this veto a vertex 4.863mm inside one row was still
        # handed to the other lip because its wall faced the wrong way.
        may_override = (near_crevice
                        and margin <= NORMAL_OVERRIDE_MARGIN_MM * 0.001)
        if may_override and normal_z <= -WALL_NORMAL_GATE:
            is_upper = True
            decided_by = "normal"
        elif may_override and normal_z >= WALL_NORMAL_GATE:
            is_upper = False
            decided_by = "normal"
        else:
            is_upper = d_up <= d_low
            # Tagged only where the veto CHANGED the answer. Tagging every
            # vertex the veto touched counted 45 where 13 labels actually moved,
            # which is the difference between a fix and a number.
            if (near_crevice and abs(normal_z) >= WALL_NORMAL_GATE
                    and is_upper != (normal_z <= -WALL_NORMAL_GATE)):
                decided_by = "teeth_vetoed_normal"
        decisions[str(index)] = decided_by
        if decided_by == "normal":
            sure = abs(normal_z) >= NORMAL_CONFIDENT_Z
        else:
            sure = margin >= TEETH_CONFIDENT_MARGIN_MM * 0.001
        confidence[str(index)] = "high" if sure else "low"
        margins[str(index)] = round(margin * 1000, 3)
        (upper if is_upper else lower).append(index)
        top = tops.get(index, 0.0)
        bot = bots.get(index, 0.0)
        # Geometry says one lip, the weights say the other. These are the
        # vertices the user is seeing move wrongly.
        if is_upper and bot > top:
            mislabelled.append({"vertex": index, "geometry": "upper",
                                "top": top, "bot": bot,
                                "normal_z": round(normals[index].z, 4)})
        elif (not is_upper) and top > bot:
            mislabelled.append({"vertex": index, "geometry": "lower",
                                "top": top, "bot": bot,
                                "normal_z": round(normals[index].z, 4)})
    contested = [i for i in candidates
                 if tops.get(i, 0.0) >= threshold and bots.get(i, 0.0) >= threshold]
    return {
        "upper": upper, "lower": lower,
        "upper_count": len(upper), "lower_count": len(lower),
        # Vertices both lips claim -- the crevice, and where a strip can damage
        # the wrong wall, so they are listed on their own.
        "contested": contested,
        "mislabelled_by_weight": sorted(mislabelled,
                                        key=lambda r: -abs(r["bot"] - r["top"])),
        "mislabelled_count": len(mislabelled),
        "teeth": [teeth_upper.name, teeth_lower.name],
        "distance_to_teeth_mm": distances,
        "decided_by": decisions,
        "decided_by_normal": sum(1 for v in decisions.values() if v == "normal"),
        "teeth_vetoed_normal": sum(1 for v in decisions.values()
                                   if v == "teeth_vetoed_normal"),
        # Published so a caller can aggregate over the vertices whose label is
        # not in doubt without re-deriving the split -- two independent passes
        # over this face produced structurally different "confident sets" when
        # each invented its own rule.
        "confidence": confidence,
        "confident_upper": [i for i in upper if confidence[str(i)] == "high"],
        "confident_lower": [i for i in lower if confidence[str(i)] == "high"],
        "low_confidence": sorted(int(k) for k, v in confidence.items()
                                 if v == "low"),
        "teeth_margin_mm": margins,
        "wall_normal_gate": WALL_NORMAL_GATE,
        "crevice_teeth_mm": CREVICE_TEETH_MM,
        "normal_override_margin_mm": NORMAL_OVERRIDE_MARGIN_MM,
        "normal_z": {str(i): round(normals[i].z, 4) for i in (upper + lower)},
        "top_weight": {str(i): tops.get(i, 0.0) for i in upper + lower},
        "bot_weight": {str(i): bots.get(i, 0.0) for i in upper + lower},
        "threshold": threshold,
    }, ""


def brow_footprint(face_object, brow_object, margin_mm=3.0,
                   threshold=MEMBERSHIP_WEIGHT):
    """Where the brows really are, and which face vertices a brow bone claims.

    The footprint comes from the brow MESH's own bounds, grown by a margin. That
    is the yardstick a brow bone's influence is judged against: measured on the
    reference character one brow bone reached 87.70mm, seventeen times its own
    length, and only twelve per cent of what it strongly held was inside this box.
    """
    if face_object is None or brow_object is None:
        return None, "Need the face mesh and the brow mesh"
    matrix = brow_object.matrix_world
    corners = [matrix @ Vector(c) for c in brow_object.bound_box]
    margin = margin_mm * 0.001
    low = Vector((min(c.x for c in corners) - margin,
                  min(c.y for c in corners) - margin,
                  min(c.z for c in corners) - margin))
    high = Vector((max(c.x for c in corners) + margin,
                   max(c.y for c in corners) + margin,
                   max(c.z for c in corners) + margin))

    face_matrix = face_object.matrix_world
    inside = []
    for vertex in face_object.data.vertices:
        p = face_matrix @ vertex.co
        if low.x <= p.x <= high.x and low.y <= p.y <= high.y and low.z <= p.z <= high.z:
            inside.append(vertex.index)
    brow_line = sum((matrix @ v.co).z for v in brow_object.data.vertices) \
        / max(1, len(brow_object.data.vertices))
    claimed = _group_sum(face_object, range(len(face_object.data.vertices)),
                         lambda n: "eyebrow" in n)
    strong = sorted(i for i, t in claimed.items() if t >= 0.1)
    return {
        "footprint_vertices": sorted(inside),
        "footprint_count": len(inside),
        "bbox_low_mm": [round(c * 1000, 2) for c in low],
        "bbox_high_mm": [round(c * 1000, 2) for c in high],
        "brow_line_z_mm": round(brow_line * 1000, 2),
        "claimed_by_brow_bones": strong,
        "claimed_count": len(strong),
        "claimed_inside_footprint": len(set(strong) & set(inside)),
        "margin_mm": margin_mm,
    }, ""


def bone_reach(mesh_object, armature, bone_name, threshold=0.1):
    """How far a bone's influence travels, against its own length.

    A deform bone whose strong influence reaches many times its own length is the
    measurable form of "the weight range is too large". The distance is to the
    bone's segment, not to its head, so a long bone is not penalised for being
    long.

    Judge a FACIAL bone by ``reach_over_sibling_spacing``, not by
    ``reach_over_length``. Every ``c_eyebrow_*`` bone on this rig is a fixed
    4.9021mm generator default and ``c_lips_corner_mini`` is a half-length
    1.5777mm, so dividing by their own length inflated two findings by 2x and
    4.63x. What matters is whether a bone reaches past its neighbours, and the
    spacing to the nearest sibling head is the scale that says so.
    """
    if mesh_object is None or armature is None:
        return None, "Need a mesh and an armature"
    bone = armature.data.bones.get(bone_name)
    group = mesh_object.vertex_groups.get(bone_name)
    if bone is None:
        return None, "No bone called %r" % bone_name
    if group is None:
        return {"bone": bone_name, "weighted": 0, "strong": 0,
                "length_mm": 0.0, "reach_mm": 0.0, "reach_over_length": 0.0}, ""
    matrix = armature.matrix_world
    head = matrix @ bone.head_local
    tail = matrix @ bone.tail_local
    axis = tail - head
    length = axis.length
    mesh_matrix = mesh_object.matrix_world
    index = group.index
    reach = 0.0
    weighted = 0
    strong = 0
    total = 0.0
    for vertex in mesh_object.data.vertices:
        weight = 0.0
        for entry in vertex.groups:
            if entry.group == index:
                weight = entry.weight
                break
        if weight <= 0.0:
            continue
        weighted += 1
        total += weight
        if weight < threshold:
            continue
        strong += 1
        point = mesh_matrix @ vertex.co
        if length > 1.0e-9:
            t = max(0.0, min(1.0, (point - head).dot(axis) / (length * length)))
            distance = (point - (head + axis * t)).length
        else:
            distance = (point - head).length
        reach = max(reach, distance)
    spacing = None
    for other in armature.data.bones:
        if other.name == bone_name:
            continue
        if mesh_object.vertex_groups.get(other.name) is None:
            continue
        gap = ((matrix @ other.head_local) - head).length
        if gap > 1.0e-9 and (spacing is None or gap < spacing):
            spacing = gap
    return {
        "bone": bone_name, "weighted": weighted, "strong": strong,
        "weight_sum": round(total, 4),
        "length_mm": round(length * 1000, 4),
        "reach_mm": round(reach * 1000, 3),
        "reach_over_length": round(reach / length, 2) if length > 1.0e-9 else None,
        "sibling_spacing_mm": None if spacing is None else round(spacing * 1000, 3),
        "reach_over_sibling_spacing": (None if not spacing
                                       else round(reach / spacing, 2)),
        "threshold": threshold,
    }, ""


def _pose_snapshot(armature):
    """Every channel of every pose bone, so a measurement can put them all back.

    Snapshotting only the bones a test writes is how a rejected constraint change
    once survived into the next measurement and corrupted it.
    """
    if armature is None:
        return []
    return [(pose_bone, tuple(pose_bone.location),
             tuple(pose_bone.rotation_quaternion),
             tuple(pose_bone.rotation_euler), tuple(pose_bone.scale))
            for pose_bone in armature.pose.bones]


def _pose_restore(snapshot):
    for pose_bone, location, quaternion, euler, scale in snapshot:
        pose_bone.location = location
        pose_bone.rotation_quaternion = quaternion
        pose_bone.rotation_euler = euler
        pose_bone.scale = scale


def _pose_neutral(snapshot):
    for pose_bone, _l, _q, _e, _s in snapshot:
        pose_bone.location = (0.0, 0.0, 0.0)
        pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
        pose_bone.rotation_euler = (0.0, 0.0, 0.0)
        pose_bone.scale = (1.0, 1.0, 1.0)


def apply_pose(armature, poses):
    """Apply a pose list that may ask for rotation and scale, not just location.

    An entry is either ``(bone, (x, y, z))`` in millimetres -- the location-only
    form the rest of this module has always used -- or
    ``(bone, {"location": mm, "rotation": degrees, "scale": factors})``. Anything
    left out of the dict is not touched.

    Location-only was a real gap, not a cosmetic one: two controller sweeps had to
    hand-roll a rotation-capable copy of :func:`surface_quality` to measure a
    rotation channel at all, and a channel nobody can measure is a channel nobody
    checks.
    """
    import math

    if armature is None:
        return
    for name, value in poses or ():
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is None:
            continue
        if isinstance(value, dict):
            location = value.get("location")
            rotation = value.get("rotation")
            scale = value.get("scale")
        else:
            location, rotation, scale = value, None, None
        if location is not None:
            pose_bone.location = (location[0] * 0.001, location[1] * 0.001,
                                  location[2] * 0.001)
        if rotation is not None:
            radians = [math.radians(a) for a in rotation]
            if pose_bone.rotation_mode == "QUATERNION":
                import mathutils
                pose_bone.rotation_quaternion = mathutils.Euler(
                    radians, "XYZ").to_quaternion()
            else:
                pose_bone.rotation_euler = radians
        if scale is not None:
            pose_bone.scale = tuple(scale)


def rigid_residuals(mesh_object, armature, bone_name, poses, indices=None):
    """How much of a region's motion one bone's rigid move already explains.

    Returns ``(residual_mm_by_vertex, error)``. For each vertex it applies that
    bone's own delta transform to the rest position and reports how far the posed
    vertex is from that prediction. A vertex the bone carries rigidly reads ~0.

    This exists because travel-difference metrics cannot tell a tear from a
    rotation: a jaw edge here reported a 9.3418mm "tear" across two vertices that
    both carry ``jawbone.x`` at 0.95 and 1.00, while the bone's own delta
    reproduced all 40 fully-jaw-weighted vertices to 0.00034mm. Two ends of a
    long edge on a rotating rigid plate simply travel different distances. Pass
    the result to :func:`follow_discontinuity` and such an edge is reported
    ``unjudged`` instead of as a defect.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    if armature is None:
        return None, "No armature"
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None, "%s has no bone %s" % (armature.name, bone_name)

    hidden = [m for m in mesh_object.modifiers
              if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    saved = []
    for name, _value in poses or ():
        other = armature.pose.bones.get(name)
        if other is not None:
            saved.append((other, tuple(other.location)))
    bpy.context.view_layer.update()

    def world_positions():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = mesh_object.evaluated_get(depsgraph)
        matrix = mesh_object.matrix_world
        return [matrix @ v.co for v in evaluated.data.vertices]

    try:
        rest = world_positions()
        for name, value in poses or ():
            other = armature.pose.bones.get(name)
            if other is not None:
                other.location = (value[0] * 0.001, value[1] * 0.001,
                                  value[2] * 0.001)
        bpy.context.view_layer.update()
        posed = world_positions()
        world = armature.matrix_world
        delta = (world @ pose_bone.matrix
                 @ armature.data.bones[bone_name].matrix_local.inverted()
                 @ world.inverted())
    finally:
        for other, value in saved:
            other.location = value
        bpy.context.view_layer.update()
        for modifier in hidden:
            modifier.show_viewport = True

    chosen = (range(len(rest)) if indices is None
              else [i for i in indices if i < len(rest)])
    return {str(i): ((delta @ rest[i]) - posed[i]).length * 1000
            for i in chosen}, ""


def follow_discontinuity(mesh_object, per_vertex_dz, vertex_scope=None,
                         rigid_residual=None, rigid_tolerance_mm=0.05):
    """The biggest jump in how far neighbouring vertices travel. ``(report, error)``.

    This is the region-free way to judge "the lip is being dragged". Whether a
    given vertex belongs to the upper or the lower lip is a judgement that three
    successive geometric classifiers got wrong here -- the lower lip's outer
    underside faces downward exactly like the upper lip's inner wall, and the
    teeth are too close to call at the crevice -- so an acceptance number built on
    region membership inherits that uncertainty.

    What the user actually sees does not: a lip that tears has neighbouring
    vertices travelling very different distances, and a lip that moves as one
    piece does not, whatever either vertex is called. The metric is therefore the
    worst absolute difference in travel across a single edge, plus where it is.

    ``rigid_residual`` -- from :func:`rigid_residuals` -- is the suppression rule
    that ships with the metric. An edge whose BOTH ends are carried rigidly by
    one bone to within ``rigid_tolerance_mm`` is not torn, however differently
    its ends travel, so it is counted in ``unjudged_edges`` and left out of the
    verdict instead of being reported as the worst finding.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    if not per_vertex_dz:
        return None, "No displacement data"
    scope = None if vertex_scope is None else set(vertex_scope)
    worst, unjudged = [], []
    for edge in mesh_object.data.edges:
        a, b = edge.vertices
        if scope is not None and (a not in scope or b not in scope):
            continue
        da = per_vertex_dz.get(str(a))
        db = per_vertex_dz.get(str(b))
        if da is None or db is None:
            continue
        if rigid_residual is not None:
            ra = rigid_residual.get(str(a))
            rb = rigid_residual.get(str(b))
            if (ra is not None and rb is not None
                    and max(ra, rb) <= rigid_tolerance_mm):
                unjudged.append({"a": a, "b": b,
                                 "jump_mm": round(abs(da - db), 4),
                                 "rigid_residual_mm": round(max(ra, rb), 5),
                                 "reason": "carried rigidly by one bone"})
                continue
        worst.append((abs(da - db), a, b, da, db))
    if not worst:
        if unjudged:
            return {"edges": 0, "unjudged_edges": len(unjudged),
                    "unjudged": sorted(unjudged,
                                       key=lambda r: -r["jump_mm"])[:8],
                    "verdict": "unjudged"}, ""
        return None, "No edge had displacement on both ends"
    worst.sort(reverse=True)
    values = [w[0] for w in worst]
    ordered = sorted(values)
    return {
        "edges": len(worst),
        "worst_jump_mm": round(values[0], 4),
        "p95_jump_mm": round(ordered[int(0.95 * (len(ordered) - 1))], 4),
        "median_jump_mm": round(ordered[len(ordered) // 2], 4),
        "over_2mm": sum(1 for v in values if v > 2.0),
        "over_5mm": sum(1 for v in values if v > 5.0),
        "worst_edges": [{"a": a, "b": b, "dz_a": round(da, 3),
                         "dz_b": round(db, 3), "jump_mm": round(j, 3)}
                        for j, a, b, da, db in worst[:8]],
        "unjudged_edges": len(unjudged),
        "unjudged": sorted(unjudged, key=lambda r: -r["jump_mm"])[:8],
    }, ""


# The lower lid closes the OTHER way. Measured: driving it the same way as the
# upper one opens the eye by 41.84 per cent, while the opposite sign closes it
# 91.73 per cent. Getting this backwards produced a "the eye only closes 63 per
# cent" reading that was an artefact of the test, not a fault in the rig.
LOWER_LID_SIGN = 1.0


def lid_closure_line(face_object, armature, side, pull_mm=16.0,
                     drive_lower=True, lower_pull_mm=None):
    """How straight and how closed the lid line is at full closure.

    Returns ``(report, error)``.

    A closed eye should read as one clean line where the two margins meet. What
    that does NOT mean is a flat ring: the eye opening is almond shaped, so its
    vertices span a range of height at rest -- measured, 12.274mm of spread with
    the eye wide open, which is more than the 10.125mm it shows when closed.
    Judging closure by flatness therefore measures the shape of the eye and not
    the quality of the rig, and an earlier version of this function did exactly
    that.

    What is measured instead is what "the margins overlap neatly" actually means:
    the height difference between each upper vertex and the lower vertex at the
    same position across the eye, and the zigzag along the closed seam, taken as
    the second difference of height walking the ring by X. A clean seam has small
    numbers for both even when it is not level.
    """
    if face_object is None or armature is None:
        return None, "Need the face mesh and the armature"
    ring, error = aperture_ring(face_object, armature, side)
    if error:
        return None, error
    top = armature.pose.bones.get("c_eyelid_top" + side)
    bot = armature.pose.bones.get("c_eyelid_bot" + side)
    if top is None:
        return None, "No c_eyelid_top%s on %s" % (side, armature.name)

    hidden = [m for m in face_object.modifiers
              if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    if hidden:
        bpy.context.view_layer.update()

    saved_top = tuple(top.location)
    saved_bot = tuple(bot.location) if bot is not None else None
    matrix = face_object.matrix_world

    def sample():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = face_object.evaluated_get(depsgraph)
        verts = evaluated.data.vertices
        return {i: matrix @ verts[i].co for i in ring["ring"] if i < len(verts)}

    try:
        rest = sample()
        top.location = (0.0, 0.0, -abs(pull_mm) * 0.001)
        if bot is not None and drive_lower:
            lower = abs(pull_mm if lower_pull_mm is None else lower_pull_mm)
            bot.location = (0.0, 0.0, LOWER_LID_SIGN * lower * 0.001)
        bpy.context.view_layer.update()
        closed = sample()
    finally:
        top.location = saved_top
        if bot is not None and saved_bot is not None:
            bot.location = saved_bot
        bpy.context.view_layer.update()
        for modifier in hidden:
            modifier.show_viewport = True

    if not closed:
        return None, "The ring did not evaluate"
    upper = [closed[i].z for i in ring["upper"] if i in closed]
    lower = [closed[i].z for i in ring["lower"] if i in closed]
    rest_upper = [rest[i].z for i in ring["upper"] if i in rest]
    rest_lower = [rest[i].z for i in ring["lower"] if i in rest]
    gap = (sum(upper) / len(upper) - sum(lower) / len(lower)) * 1000
    rest_gap = ((sum(rest_upper) / len(rest_upper)
                 - sum(rest_lower) / len(rest_lower)) * 1000)

    # Pair each upper vertex with the lower one nearest it across the eye, and
    # measure how far apart they finish. This is "do the margins meet", and it
    # does not care that the eye is almond shaped.
    pairs = []
    lower_ids = [i for i in ring["lower"] if i in closed]
    for i in ring["upper"]:
        if i not in closed:
            continue
        partner = min(lower_ids, key=lambda j: abs(closed[j].x - closed[i].x))
        pairs.append({"upper": i, "lower": partner,
                      "dz_mm": round((closed[i].z - closed[partner].z) * 1000, 3),
                      "dx_mm": round((closed[i].x - closed[partner].x) * 1000, 3)})
    overlaps = sorted(abs(p["dz_mm"]) for p in pairs)

    # Zigzag along each margin SEPARATELY. Walking the whole ring by X
    # interleaves the upper and lower margins, so the second difference then
    # measures the aperture rather than the seam -- that read 48mm at rest on an
    # eye that is perfectly smooth, which is nonsense. Each margin walked on its
    # own gives the stair-stepping the eye actually shows.
    def zigzag(sample, indices):
        walk = sorted((i for i in indices if i in sample),
                      key=lambda i: sample[i].x)
        out = []
        for k in range(1, len(walk) - 1):
            a = sample[walk[k - 1]].z
            b = sample[walk[k]].z
            c = sample[walk[k + 1]].z
            out.append(abs((c - b) - (b - a)) * 1000)
        return sorted(out)

    zig = sorted(zigzag(closed, ring["upper"]) + zigzag(closed, ring["lower"]))
    rest_zig = sorted(zigzag(rest, ring["upper"]) + zigzag(rest, ring["lower"]))

    return {
        "side": side, "pull_mm": pull_mm,
        "lower_pull_mm": (pull_mm if lower_pull_mm is None else lower_pull_mm),
        "drove_lower": bool(bot is not None and drive_lower),
        "rest_aperture_mm": round(rest_gap, 3),
        "closed_gap_mm": round(gap, 3),
        "closed_pct": round(100.0 * (rest_gap - gap) / rest_gap, 2)
        if rest_gap else None,
        # How neatly the two margins meet.
        "overlap_max_mm": round(overlaps[-1], 3) if overlaps else None,
        "overlap_p95_mm": round(overlaps[int(0.95 * (len(overlaps) - 1))], 3)
        if overlaps else None,
        "overlap_mean_mm": round(sum(overlaps) / len(overlaps), 3)
        if overlaps else None,
        # How smooth the seam is, against how smooth the ring is at rest.
        "zigzag_max_mm": round(zig[-1], 3) if zig else None,
        "zigzag_p95_mm": round(zig[int(0.95 * (len(zig) - 1))], 3) if zig else None,
        "rest_zigzag_max_mm": round(rest_zig[-1], 3) if rest_zig else None,
        "zigzag_degradation_mm": round(zig[-1] - rest_zig[-1], 3)
        if (zig and rest_zig) else None,
        "worst_pair": max(pairs, key=lambda p: abs(p["dz_mm"])) if pairs else None,
        "ring": ring["ring"],
    }, ""


def surface_quality(mesh_object, vertex_indices, armature=None, poses=(),
                    neutral_first=True):
    """Whether the surface stays smooth when posed. ``(report, error)``.

    The metric is the angle between neighbouring face normals -- the same one
    this project uses at the knee -- and it is judged by how much it DEGRADES
    from rest, never by its absolute value: a stylised face has sharp creases at
    rest and calling those defects would bury the real ones. ``poses`` is a list
    applied together, so a combined expression can be measured rather than one
    control at a time; each entry takes either form :func:`apply_pose` accepts, so
    rotation and scale channels are measurable here and no longer need a caller's
    own copy of this function.

    ``neutral_first`` clears every pose bone before the rest snapshot. Without it
    the rest reading is taken in whatever pose the rig happens to be in, so a
    caller that left another bone posed silently rebaselines the whole
    measurement and the degradation comes out too small.
    """
    import bmesh
    import math

    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    scope = set(vertex_indices or ())
    if not scope:
        return None, "No region given"

    hidden = [m for m in mesh_object.modifiers
              if m.type != "ARMATURE" and m.show_viewport]
    for modifier in hidden:
        modifier.show_viewport = False
    if hidden:
        bpy.context.view_layer.update()

    saved = _pose_snapshot(armature)

    def dihedrals():
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated = mesh_object.evaluated_get(depsgraph)
        bm = bmesh.new()
        try:
            bm.from_mesh(evaluated.data)
            bm.edges.ensure_lookup_table()
            out = []
            for edge in bm.edges:
                if len(edge.link_faces) != 2:
                    continue
                if not any(v.index in scope for v in edge.verts):
                    continue
                a, b = edge.link_faces
                dot = max(-1.0, min(1.0, a.normal.dot(b.normal)))
                out.append(math.degrees(math.acos(dot)))
            return sorted(out)
        finally:
            bm.free()

    try:
        if armature is not None and neutral_first:
            _pose_neutral(saved)
            bpy.context.view_layer.update()
        rest = dihedrals()
        if armature is not None:
            apply_pose(armature, poses)
            bpy.context.view_layer.update()
        posed = dihedrals()
    finally:
        _pose_restore(saved)
        bpy.context.view_layer.update()
        for modifier in hidden:
            modifier.show_viewport = True

    if not rest or not posed:
        return None, "No interior edge in the region"

    def stats(values):
        return {"p95": round(values[int(0.95 * (len(values) - 1))], 2),
                "max": round(values[-1], 2),
                "over_40": sum(1 for v in values if v > 40.0),
                "over_70": sum(1 for v in values if v > 70.0),
                "edges": len(values)}

    r, p = stats(rest), stats(posed)
    return {"rest": r, "posed": p,
            "degradation_p95": round(p["p95"] - r["p95"], 2),
            "degradation_max": round(p["max"] - r["max"], 2),
            "new_over_40": p["over_40"] - r["over_40"],
            "new_over_70": p["over_70"] - r["over_70"]}, ""


def rig_weight_sums(mesh_object, armature):
    """Per-vertex weight summed over the MAIN rig's deform bones only.

    The additive rig's own bones are excluded, and that exclusion is the whole
    point. Auto-Rig Pro puts deliberate inert blocker bones on the additive rig --
    ``epaules_bend.x`` carries weight on all 2229 vertices of the reference face
    with a sum of 2212 -- so a normalisation audit that includes them reports every
    vertex as broken and is thrown away. The split is taken from each armature
    modifier rather than from the bone names.
    """
    if mesh_object is None or armature is None:
        return None, "Need a mesh and an armature"
    main = {b.name for b in armature.data.bones if b.use_deform}
    everything = bind_common.deform_bone_names(mesh_object)
    additive_only = everything - main
    main_groups = {g.index for g in mesh_object.vertex_groups if g.name in main}

    sums = []
    influences = []
    for vertex in mesh_object.data.vertices:
        total = 0.0
        count = 0
        for entry in vertex.groups:
            if entry.group in main_groups and entry.weight > 0.0:
                total += entry.weight
                count += 1
        sums.append(total)
        influences.append(count)
    ordered = sorted(sums)
    n = len(sums)
    worst = max(range(n), key=lambda i: abs(sums[i] - 1.0)) if n else None
    histogram = {}
    for c in influences:
        histogram[c] = histogram.get(c, 0) + 1
    return {
        "vertices": n,
        "main_deform_bones": len(main),
        "additive_only_groups": sorted(
            g.name for g in mesh_object.vertex_groups if g.name in additive_only),
        "sum_mean": round(sum(sums) / n, 4) if n else 0.0,
        "sum_median": round(ordered[n // 2], 4) if n else 0.0,
        "sum_min": round(ordered[0], 4) if n else 0.0,
        "sum_max": round(ordered[-1], 4) if n else 0.0,
        "within_0_001_of_one": sum(1 for s in sums if abs(s - 1.0) <= 0.001),
        "off_by_more_than_0_01": sum(1 for s in sums if abs(s - 1.0) > 0.01),
        "off_by_more_than_0_25": sum(1 for s in sums if abs(s - 1.0) > 0.25),
        "influence_histogram": {str(k): histogram[k] for k in sorted(histogram)},
        "over_four_influences": sum(1 for c in influences if c > 4),
        "max_influences": max(influences) if influences else 0,
        "worst_vertex": worst,
        "worst_vertex_sum": round(sums[worst], 4) if worst is not None else None,
    }, ""


def mirror_map(mesh_object, tolerance_mm=0.05):
    """Pair each vertex with its mirror across x=0. ``(report, error)``.

    An exact coordinate map, not Blender's topology mirror. The reference face
    pairs all 2229 vertices with none left over, which is what makes a left/right
    weight comparison meaningful; a mesh that does not pair cleanly is reported
    rather than half-mapped.
    """
    if mesh_object is None or mesh_object.type != "MESH":
        return None, "No mesh"
    matrix = mesh_object.matrix_world
    points = [matrix @ v.co for v in mesh_object.data.vertices]
    tolerance = tolerance_mm * 0.001
    buckets = {}
    for index, p in enumerate(points):
        key = (round(abs(p.x) / tolerance), round(p.y / tolerance),
               round(p.z / tolerance))
        buckets.setdefault(key, []).append(index)
    pairs = {}
    self_mirrored = []
    unpaired = []
    for key, members in buckets.items():
        if len(members) == 1:
            index = members[0]
            if abs(points[index].x) <= tolerance:
                self_mirrored.append(index)
            else:
                unpaired.append(index)
            continue
        if len(members) == 2:
            a, b = members
            if points[a].x * points[b].x <= 0.0:
                pairs[a] = b
                pairs[b] = a
                continue
        unpaired.extend(members)
    return {"pairs": {str(k): v for k, v in sorted(pairs.items())},
            "paired": len(pairs), "self_mirrored": sorted(self_mirrored),
            "unpaired": sorted(unpaired), "tolerance_mm": tolerance_mm}, ""


def freeze(face_object, armature, brow_object=None, lash_objects=(),
           teeth_upper=None, teeth_lower=None, threshold=MEMBERSHIP_WEIGHT):
    """Every region at once, with a digest so two runs can be compared.

    Returns ``(regions, error)``. Write the result beside the evidence and cite it
    in every before-and-after number; a figure without the list it was computed
    over cannot be checked.
    """
    if face_object is None or armature is None:
        return None, "Need the face mesh and the armature"
    out = {"face": face_object.name, "armature": armature.name,
           "threshold": threshold, "eyes": {}, "lids": {}}
    for side in (".l", ".r"):
        ring, error = aperture_ring(face_object, armature, side)
        if error:
            return None, error
        out["eyes"][side] = ring
        lid, error = lid_region(face_object, armature, side, threshold=threshold)
        if error:
            return None, error
        out["lids"][side] = lid

    lips, error = lip_regions(face_object, teeth_upper=teeth_upper,
                              teeth_lower=teeth_lower, threshold=threshold)
    if error:
        return None, error
    out["lips"] = lips
    # Published here, not left to each caller: a number aggregated over "the
    # vertices whose lip is certain" is only comparable between runs if both runs
    # used the same list, and two passes that each invented their own rule
    # produced structurally different sets (140/82 against 127/64).
    out["lips_confident"] = {"upper": lips["confident_upper"],
                             "lower": lips["confident_lower"],
                             "low_confidence": lips["low_confidence"]}

    if brow_object is not None:
        brows, error = brow_footprint(face_object, brow_object,
                                      threshold=threshold)
        if error:
            return None, error
        out["brows"] = brows

    out["lashes"] = {}
    for obj in lash_objects or ():
        if obj is None or obj.type != "MESH":
            continue
        out["lashes"][obj.name] = {
            "vertices": len(obj.data.vertices),
            "groups": sorted(g.name for g in obj.vertex_groups),
            "eyelid_groups": sorted(g.name for g in obj.vertex_groups
                                    if "eyelid" in g.name),
            "eyebrow_groups": sorted(g.name for g in obj.vertex_groups
                                     if "eyebrow" in g.name)}

    sums, error = rig_weight_sums(face_object, armature)
    if error:
        return None, error
    out["weight_sums"] = sums

    mirror, error = mirror_map(face_object)
    if error:
        return None, error
    out["mirror"] = {k: v for k, v in mirror.items() if k != "pairs"}
    out["mirror"]["pair_count"] = mirror["paired"]

    # A digest over exactly the index lists, so "two runs agree" is checkable
    # rather than asserted.
    import hashlib
    import json

    signature = {
        "eyes": {s: [out["eyes"][s]["ring"], out["eyes"][s]["upper"],
                     out["eyes"][s]["lower"]] for s in out["eyes"]},
        "lids": {s: out["lids"][s]["vertices"] for s in out["lids"]},
        "lips": [out["lips"]["upper"], out["lips"]["lower"],
                 out["lips"]["contested"]],
        "brows": out.get("brows", {}).get("footprint_vertices", []),
    }
    blob = json.dumps(signature, sort_keys=True, separators=(",", ":"))
    out["digest"] = hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16].upper()
    return out, ""
