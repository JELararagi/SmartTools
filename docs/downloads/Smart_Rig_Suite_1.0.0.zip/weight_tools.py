# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

from contextlib import contextmanager
from typing import Iterable

import bpy

from . import bind_common
import bmesh
from bpy.props import EnumProperty, FloatProperty, IntProperty

from .external_tools import text_block_write
from .i18n import tr, tr_format
from . import generation
from .lifecycle import register_classes, unregister_classes, unregister_owned_classes
from .preferences import get_preferences

_WEIGHT_CLIPBOARD: dict[str, float] = {}


def active_mesh(context: bpy.types.Context | None = None) -> bpy.types.Object | None:
    obj = getattr(context or bpy.context, "active_object", None)
    return obj if obj is not None and obj.type == "MESH" else None


def selected_vertex_indices(obj: bpy.types.Object, selected_only: bool) -> list[int]:
    if not selected_only:
        return [vertex.index for vertex in obj.data.vertices]
    if obj.mode == "EDIT":
        bm = bmesh.from_edit_mesh(obj.data)
        selected = [vertex.index for vertex in bm.verts if vertex.select]
        return selected
    selected = [vertex.index for vertex in obj.data.vertices if vertex.select]
    return selected


@contextmanager
def object_mode_for_weights(obj: bpy.types.Object):
    old_mode = obj.mode
    if old_mode == "EDIT":
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            old_mode = "OBJECT"
    try:
        yield
    finally:
        if old_mode == "EDIT":
            try:
                bpy.ops.object.mode_set(mode="EDIT")
            except Exception:
                pass


def _weight_map(obj: bpy.types.Object, vertex_index: int) -> dict[int, float]:
    vertex = obj.data.vertices[vertex_index]
    return {item.group: float(item.weight) for item in vertex.groups}


def _set_group_weight(obj: bpy.types.Object, group_index: int, vertex_index: int, value: float) -> None:
    if not 0 <= group_index < len(obj.vertex_groups):
        return
    group = obj.vertex_groups[group_index]
    value = max(0.0, min(1.0, float(value)))
    if value <= 0.0:
        try:
            group.remove([vertex_index])
        except Exception:
            pass
    else:
        group.add([vertex_index], value, "REPLACE")


def _normalize_preserve_group(obj: bpy.types.Object, vertex_index: int, target_index: int) -> None:
    weights = _weight_map(obj, vertex_index)
    target_value = max(0.0, min(1.0, weights.get(target_index, 0.0)))
    locked_sum = 0.0
    scalable: list[tuple[int, float]] = []
    for index, value in weights.items():
        if index == target_index:
            continue
        group = obj.vertex_groups[index]
        if bool(getattr(group, "lock_weight", False)):
            locked_sum += value
        else:
            scalable.append((index, value))
    remaining = max(0.0, 1.0 - target_value - locked_sum)
    source_sum = sum(value for _, value in scalable)
    if source_sum > 1.0e-12:
        scale = remaining / source_sum
        for index, value in scalable:
            _set_group_weight(obj, index, vertex_index, value * scale)
    elif remaining <= 1.0e-12:
        for index, _ in scalable:
            _set_group_weight(obj, index, vertex_index, 0.0)


def _normalize_all(obj: bpy.types.Object, vertex_index: int) -> None:
    weights = _weight_map(obj, vertex_index)
    locked_sum = 0.0
    scalable: list[tuple[int, float]] = []
    for index, value in weights.items():
        group = obj.vertex_groups[index]
        if bool(getattr(group, "lock_weight", False)):
            locked_sum += value
        else:
            scalable.append((index, value))
    remaining = max(0.0, 1.0 - locked_sum)
    source_sum = sum(value for _, value in scalable)
    if source_sum > 1.0e-12:
        scale = remaining / source_sum
        for index, value in scalable:
            _set_group_weight(obj, index, vertex_index, value * scale)


def _active_group(obj: bpy.types.Object):
    try:
        return obj.vertex_groups.active
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Region-scoped weight work.
#
# Every fix a bound face needs is "do this to these vertices for these bones",
# and doing it to the whole mesh instead is how a repair breaks something that
# was right. The primitives below all take an explicit vertex list -- produced by
# :mod:`face_regions`, which returns index lists rather than descriptions -- so a
# before-and-after number can be recomputed over the same set later.
#
# Two hard-won rules are built in rather than left to the caller.
#
# The additive rig's groups are never touched. Auto-Rig Pro places deliberate
# inert blocker bones on the additive armature; on the reference face
# ``epaules_bend.x`` holds weight on all 2229 vertices with a sum of 2212, and a
# normalisation that includes it reports every vertex as broken and gets thrown
# away. The bone set is resolved per armature modifier, not by guessing names.
#
# Smoothing is not idempotent and its selection leaks. A selection written in
# Object Mode does not survive an edit-mesh left over from a previous call, so a
# second call smooths the union of both regions; that once cost the reference
# knee 7.6mm of definition. The selection is therefore cleared from inside Edit
# Mode, and what was smoothed is stamped on the mesh so a repeat is refused.
# ---------------------------------------------------------------------------

_SMOOTH_STAMP_KEY = "srs_smoothed_regions"


def _groups_for(mesh: bpy.types.Object, names) -> dict:
    wanted = set(names or ())
    return {g.index: g for g in mesh.vertex_groups if g.name in wanted}


def main_rig_bones(mesh: bpy.types.Object, armature: bpy.types.Object) -> set:
    """Deform bones of the MAIN rig that this mesh is bound to.

    The additive rig's own bones are deliberately excluded; see the note above.
    """
    if armature is None or armature.type != "ARMATURE":
        return set()
    main = {b.name for b in armature.data.bones if b.use_deform}
    return main & bind_common.deform_bone_names(mesh)


def strip_bone_in_region(mesh: bpy.types.Object, bone_names, vertex_indices):
    """Remove these bones' weight from these vertices only. ``(report, error)``."""
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    groups = _groups_for(mesh, bone_names)
    if not groups:
        return {"mesh": mesh.name, "removed": 0, "groups": []}, ""
    indices = sorted(set(vertex_indices or ()))
    removed = 0
    touched = {}
    for index in indices:
        if index >= len(mesh.data.vertices):
            continue
        present = {e.group: e.weight for e in mesh.data.vertices[index].groups}
        for group_index, group in groups.items():
            if present.get(group_index, 0.0) > 0.0:
                group.remove([index])
                removed += 1
                touched[group.name] = touched.get(group.name, 0) + 1
    return {"mesh": mesh.name, "removed": removed, "vertices": len(indices),
            "per_group": touched, "groups": sorted(g.name for g in groups.values())}, ""


def clamp_to_radius(mesh: bpy.types.Object, armature: bpy.types.Object, bone_names,
                    radius_mm: float, falloff_mm: float = 0.0,
                    vertex_indices=None, threshold: float = 0.0):
    """Cut a bone's influence off past a distance from its own segment.

    This is the measurable answer to "the weight range is too large". Distance is
    to the bone's head-tail segment, not to its head, so a long bone is not
    punished for its length. Inside ``radius`` nothing changes; across the falloff
    band the weight tapers to zero; beyond it the weight is removed. Returns
    ``(report, error)``.
    """
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    radius = max(0.0, float(radius_mm)) * 0.001
    falloff = max(0.0, float(falloff_mm)) * 0.001
    mesh_matrix = mesh.matrix_world
    rig_matrix = armature.matrix_world
    scope = None if vertex_indices is None else set(vertex_indices)
    rows = []
    for name in bone_names or ():
        bone = armature.data.bones.get(name)
        group = mesh.vertex_groups.get(name)
        if bone is None or group is None:
            continue
        head = rig_matrix @ bone.head_local
        tail = rig_matrix @ bone.tail_local
        axis = tail - head
        length_sq = axis.length_squared
        index = group.index
        removed = 0
        faded = 0
        for vertex in mesh.data.vertices:
            if scope is not None and vertex.index not in scope:
                continue
            weight = 0.0
            for entry in vertex.groups:
                if entry.group == index:
                    weight = entry.weight
                    break
            if weight <= threshold:
                continue
            point = mesh_matrix @ vertex.co
            if length_sq > 1.0e-18:
                t = max(0.0, min(1.0, (point - head).dot(axis) / length_sq))
                distance = (point - (head + axis * t)).length
            else:
                distance = (point - head).length
            if distance <= radius:
                continue
            if falloff <= 0.0 or distance >= radius + falloff:
                group.remove([vertex.index])
                removed += 1
            else:
                scale = 1.0 - (distance - radius) / falloff
                _set_group_weight(mesh, index, vertex.index, weight * scale)
                faded += 1
        rows.append({"bone": name, "removed": removed, "faded": faded,
                     "length_mm": round(axis.length * 1000, 3)})
    return {"mesh": mesh.name, "radius_mm": radius_mm,
            "falloff_mm": falloff_mm, "bones": rows}, ""


def normalise_in_region(mesh: bpy.types.Object, vertex_indices, bone_whitelist,
                        locked_names=()):
    """Make each vertex's weight sum to 1.0 over the whitelisted bones only.

    Groups outside the whitelist -- above all the additive rig's blockers -- keep
    their values untouched, which is the difference between this and Blender's own
    Normalize All. Returns ``(report, error)``.
    """
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    allowed = {g.index for g in mesh.vertex_groups
               if g.name in set(bone_whitelist or ())
               and g.name not in set(locked_names or ())
               and not bool(getattr(g, "lock_weight", False))}
    if not allowed:
        return None, "No writable group on %s matches the whitelist" % mesh.name
    indices = sorted(set(vertex_indices or ()))
    changed = 0
    before_sums = []
    after_sums = []
    for index in indices:
        if index >= len(mesh.data.vertices):
            continue
        weights = {e.group: e.weight for e in mesh.data.vertices[index].groups
                   if e.group in allowed and e.weight > 0.0}
        total = sum(weights.values())
        before_sums.append(total)
        if total <= 1.0e-9:
            after_sums.append(0.0)
            continue
        if abs(total - 1.0) <= 1.0e-6:
            after_sums.append(total)
            continue
        scale = 1.0 / total
        for group_index, value in weights.items():
            _set_group_weight(mesh, group_index, index, value * scale)
        changed += 1
        after_sums.append(1.0)
    def stats(values):
        if not values:
            return {}
        ordered = sorted(values)
        return {"mean": round(sum(values) / len(values), 5),
                "median": round(ordered[len(ordered) // 2], 5),
                "min": round(ordered[0], 5), "max": round(ordered[-1], 5)}
    return {"mesh": mesh.name, "vertices": len(indices), "renormalised": changed,
            "whitelist": len(allowed),
            "sum_before": stats(before_sums), "sum_after": stats(after_sums)}, ""


def limit_influences_in_region(mesh: bpy.types.Object, vertex_indices,
                               bone_whitelist, limit: int = 4,
                               renormalise: bool = True):
    """Keep only the strongest ``limit`` whitelisted influences per vertex."""
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    allowed = {g.index for g in mesh.vertex_groups
               if g.name in set(bone_whitelist or ())
               and not bool(getattr(g, "lock_weight", False))}
    indices = sorted(set(vertex_indices or ()))
    trimmed = 0
    dropped = 0
    for index in indices:
        if index >= len(mesh.data.vertices):
            continue
        weights = sorted(
            ((e.group, e.weight) for e in mesh.data.vertices[index].groups
             if e.group in allowed and e.weight > 0.0),
            key=lambda pair: -pair[1])
        if len(weights) <= max(1, int(limit)):
            continue
        for group_index, _ in weights[int(limit):]:
            _set_group_weight(mesh, group_index, index, 0.0)
            dropped += 1
        trimmed += 1
    report = {"mesh": mesh.name, "vertices": len(indices), "trimmed": trimmed,
              "influences_dropped": dropped, "limit": int(limit)}
    if renormalise and trimmed:
        norm, error = normalise_in_region(mesh, indices, bone_whitelist)
        if error:
            return report, error
        report["renormalise"] = norm
    return report, ""


def mirror_in_region(mesh: bpy.types.Object, pairs, bone_names,
                     master_sign: int = 1, vertex_indices=None):
    """Copy weights from one side onto the other through an exact vertex map.

    ``pairs`` maps a vertex index to its mirror, as :func:`face_regions.mirror_map`
    returns. Group names are mirrored too, so ``c_eyelid_top_01.l`` on the master
    side writes ``c_eyelid_top_01.r`` on the other. Blender's topology mirror is
    deliberately not used: it needs matching topology order and fails silently
    where an exact coordinate map reports what it could not pair.
    """
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    matrix = mesh.matrix_world
    names = set(bone_names or ())

    def mirrored_name(name):
        if name.endswith(".l"):
            return name[:-2] + ".r"
        if name.endswith(".r"):
            return name[:-2] + ".l"
        return name

    by_name = {g.name: g for g in mesh.vertex_groups}
    scope = None if vertex_indices is None else set(vertex_indices)
    written = 0
    skipped = 0
    for key, other in (pairs or {}).items():
        source = int(key)
        if scope is not None and source not in scope:
            continue
        if source >= len(mesh.data.vertices) or other >= len(mesh.data.vertices):
            continue
        x = (matrix @ mesh.data.vertices[source].co).x
        if x * master_sign <= 0.0:
            continue
        have = {mesh.vertex_groups[e.group].name: e.weight
                for e in mesh.data.vertices[source].groups if e.weight > 0.0}
        for name in names:
            target_name = mirrored_name(name)
            group = by_name.get(target_name)
            if group is None:
                skipped += 1
                continue
            value = have.get(name, 0.0)
            _set_group_weight(mesh, group.index, other, value)
            written += 1
    return {"mesh": mesh.name, "written": written, "skipped": skipped,
            "master_sign": master_sign}, ""


def smooth_in_region(mesh: bpy.types.Object, vertex_indices, factor: float = 0.5,
                     repeat: int = 4, tag: str = "", force: bool = False):
    """Average the weights inside a region, once. ``(report, error)``.

    Refuses a repeat with the same tag unless forced, and clears the selection
    from inside Edit Mode so a previous call's region cannot join this one -- both
    guards exist because the compounded pass is invisible until something posed
    has quietly lost its shape.
    """
    if mesh is None or mesh.type != "MESH":
        return None, "No mesh"
    picked = sorted(set(vertex_indices or ()))
    if not picked:
        return None, "No vertex was given to smooth"
    stamp = "%s|%.3f|%d" % (tag or "region", float(factor), int(repeat))
    done = list(mesh.data.get(_SMOOTH_STAMP_KEY, []))
    if stamp in done and not force:
        return {"mesh": mesh.name, "skipped": stamp,
                "note": "already smoothed with these settings"}, ""

    view = bpy.context.view_layer
    previous_active = view.objects.active
    previous_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
    mirror_x = getattr(mesh.data, "use_mirror_x", False)
    mirror_groups = getattr(mesh.data, "use_mirror_vertex_groups", False)
    used_mode = ""
    try:
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh.data.use_mirror_x = False
        mesh.data.use_mirror_vertex_groups = False
        view.objects.active = mesh
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        wanted = set(picked)
        for vertex in mesh.data.vertices:
            vertex.select = vertex.index in wanted
        mesh.data.update()
        bpy.ops.object.mode_set(mode="EDIT")
        last = ""
        for mode in ("BONE_DEFORM", "ALL", None):
            kwargs = {"factor": float(factor), "repeat": int(max(1, repeat)),
                      "expand": 0.0}
            if mode:
                kwargs["group_select_mode"] = mode
            try:
                bpy.ops.object.vertex_group_smooth(**kwargs)
                used_mode = mode or "(default)"
                last = ""
                break
            except (RuntimeError, TypeError) as exc:
                last = str(exc)
        if last:
            return {"mesh": mesh.name}, "Weight smoothing was refused. Check the mode and selection."
    finally:
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh.data.use_mirror_x = mirror_x
        mesh.data.use_mirror_vertex_groups = mirror_groups
        view.objects.active = previous_active
        if previous_active is not None and previous_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=previous_mode)
            except RuntimeError:
                pass
    mesh.data[_SMOOTH_STAMP_KEY] = done + [stamp]
    return {"mesh": mesh.name, "vertices": len(picked), "stamp": stamp,
            "group_select_mode": used_mode}, ""


class SRS_OT_weight_apply(bpy.types.Operator):
    bl_idname = "srs.weight_apply"
    bl_label = "Weight Tool"
    bl_description = (
        "Apply precise weight edits to selected mesh vertices. This is an independent Smart Rig Suite feature "
        "and does not replace Auto-Rig Pro binding."
    )
    bl_options = {'UNDO'}

    operation: EnumProperty(
        items=(
            ("SET", "Set", "Set the active vertex-group weight"),
            ("ADD", "Add", "Add the configured weight"),
            ("SUBTRACT", "Subtract", "Subtract the configured weight"),
            ("SCALE", "Scale", "Multiply the active group weight"),
            ("NORMALIZE", "Normalize", "Normalize all unlocked influences"),
            ("CLEAN", "Clean", "Remove weights below the configured threshold"),
            ("LIMIT", "Limit", "Keep only the strongest configured number of influences"),
        ),
        default="SET",
    )
    preset_value: FloatProperty(default=-1.0, min=-1.0, max=1.0)

    @classmethod
    def poll(cls, context):
        return active_mesh(context) is not None

    def execute(self, context):
        obj = active_mesh(context)
        if obj is None:
            self.report({"WARNING"}, tr("No active mesh object.", "アクティブなメッシュオブジェクトがありません。"))
            return {"CANCELLED"}
        settings = context.scene.srs_settings
        indices = selected_vertex_indices(obj, settings.weight_selected_only)
        if not indices:
            self.report({"WARNING"}, tr("No vertices are available.", "処理対象の頂点がありません。"))
            return {"CANCELLED"}
        active_group = _active_group(obj)
        if self.operation in {"SET", "ADD", "SUBTRACT", "SCALE"} and active_group is None:
            self.report({"WARNING"}, tr("Select an active vertex group first.", "先にアクティブな頂点グループを選択してください。"))
            return {"CANCELLED"}
        preferences = get_preferences(context)
        max_influences = int(getattr(preferences, "maximum_influences", 4) if preferences else 4)
        value = settings.weight_value if self.preset_value < 0.0 else self.preset_value
        with object_mode_for_weights(obj):
            for vertex_index in indices:
                weights = _weight_map(obj, vertex_index)
                if self.operation == "SET":
                    new_value = value
                    _set_group_weight(obj, active_group.index, vertex_index, new_value)
                    if settings.weight_normalize_after:
                        _normalize_preserve_group(obj, vertex_index, active_group.index)
                elif self.operation == "ADD":
                    new_value = weights.get(active_group.index, 0.0) + value
                    _set_group_weight(obj, active_group.index, vertex_index, new_value)
                    if settings.weight_normalize_after:
                        _normalize_preserve_group(obj, vertex_index, active_group.index)
                elif self.operation == "SUBTRACT":
                    new_value = weights.get(active_group.index, 0.0) - value
                    _set_group_weight(obj, active_group.index, vertex_index, new_value)
                    if settings.weight_normalize_after:
                        _normalize_preserve_group(obj, vertex_index, active_group.index)
                elif self.operation == "SCALE":
                    new_value = weights.get(active_group.index, 0.0) * settings.weight_scale
                    _set_group_weight(obj, active_group.index, vertex_index, new_value)
                    if settings.weight_normalize_after:
                        _normalize_preserve_group(obj, vertex_index, active_group.index)
                elif self.operation == "NORMALIZE":
                    _normalize_all(obj, vertex_index)
                elif self.operation == "CLEAN":
                    for group_index, weight in tuple(weights.items()):
                        if weight < settings.weight_clean_threshold and not obj.vertex_groups[group_index].lock_weight:
                            _set_group_weight(obj, group_index, vertex_index, 0.0)
                    if settings.weight_normalize_after:
                        _normalize_all(obj, vertex_index)
                elif self.operation == "LIMIT":
                    unlocked = [
                        (index, weight)
                        for index, weight in weights.items()
                        if not obj.vertex_groups[index].lock_weight
                    ]
                    unlocked.sort(key=lambda item: item[1], reverse=True)
                    keep = {index for index, _ in unlocked[:max_influences]}
                    for index, _ in unlocked[max_influences:]:
                        _set_group_weight(obj, index, vertex_index, 0.0)
                    if settings.weight_normalize_after:
                        _normalize_all(obj, vertex_index)
        self.report({"INFO"}, tr(f"Updated {len(indices)} vertices.", f"{len(indices)}頂点を更新しました。"))
        return {"FINISHED"}


class SRS_OT_weight_copy(bpy.types.Operator):
    bl_idname = "srs.weight_copy"
    bl_label = "Copy Vertex Weights"
    bl_description = "Copy all vertex-group weights from the first selected vertex into the Smart Rig Suite clipboard."

    @classmethod
    def poll(cls, context):
        return active_mesh(context) is not None

    def execute(self, context):
        obj = active_mesh(context)
        indices = selected_vertex_indices(obj, True)
        if not indices:
            return {"CANCELLED"}
        global _WEIGHT_CLIPBOARD
        group_names = {group.index: group.name for group in obj.vertex_groups}
        _WEIGHT_CLIPBOARD = {
            group_names[index]: weight for index, weight in _weight_map(obj, indices[0]).items() if index in group_names
        }
        self.report({"INFO"}, tr(f"Copied {len(_WEIGHT_CLIPBOARD)} weights from vertex {indices[0]}.", f"頂点{indices[0]}から{len(_WEIGHT_CLIPBOARD)}件のウェイトをコピーしました。"))
        return {"FINISHED"}


class SRS_OT_weight_paste(bpy.types.Operator):
    bl_idname = "srs.weight_paste"
    bl_label = "Paste Vertex Weights"
    bl_description = "Paste the copied vertex-group weight set to all selected vertices, creating matching groups when needed."
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return active_mesh(context) is not None and bool(_WEIGHT_CLIPBOARD)

    def execute(self, context):
        obj = active_mesh(context)
        settings = context.scene.srs_settings
        indices = selected_vertex_indices(obj, settings.weight_selected_only)
        with object_mode_for_weights(obj):
            groups = {}
            for name in _WEIGHT_CLIPBOARD:
                groups[name] = obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
            for vertex_index in indices:
                current = _weight_map(obj, vertex_index)
                for group_index in tuple(current):
                    if obj.vertex_groups[group_index].name in _WEIGHT_CLIPBOARD:
                        _set_group_weight(obj, group_index, vertex_index, 0.0)
                for name, weight in _WEIGHT_CLIPBOARD.items():
                    groups[name].add([vertex_index], weight, "REPLACE")
                if settings.weight_normalize_after:
                    _normalize_all(obj, vertex_index)
        self.report({"INFO"}, tr(f"Pasted weights to {len(indices)} vertices.", f"{len(indices)}頂点へウェイトを貼り付けました。"))
        return {"FINISHED"}


class SRS_OT_weight_table_edit(bpy.types.Operator):
    bl_idname = "srs.weight_table_edit"
    bl_label = "Edit Weight Cell"
    bl_description = "Edit one vertex-group weight cell and optionally normalize the remaining unlocked influences."
    bl_options = {'UNDO'}

    vertex_index: IntProperty(min=0)
    group_index: IntProperty(min=0)
    value: FloatProperty(name="Weight", min=0.0, max=1.0, precision=4)

    def invoke(self, context, event):
        obj = active_mesh(context)
        if obj is None or self.vertex_index >= len(obj.data.vertices) or self.group_index >= len(obj.vertex_groups):
            return {"CANCELLED"}
        self.value = _weight_map(obj, self.vertex_index).get(self.group_index, 0.0)
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        obj = active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        if self.group_index >= len(obj.vertex_groups) or self.vertex_index >= len(obj.data.vertices):
            self.report({'WARNING'}, "No such vertex group or vertex.")
            return {"CANCELLED"}
        with object_mode_for_weights(obj):
            _set_group_weight(obj, self.group_index, self.vertex_index, self.value)
            if context.scene.srs_settings.weight_normalize_after:
                _normalize_preserve_group(obj, self.vertex_index, self.group_index)
        return {"FINISHED"}


class SRS_OT_weight_table_page(bpy.types.Operator):
    bl_idname = "srs.weight_table_page"
    bl_label = "Change Weight Table Page"
    bl_description = "Move the popup weight table to the previous or next vertex/group page."

    direction: EnumProperty(
        items=(
            ("ROWS_PREV", "Previous Rows", "Show the previous vertex page"),
            ("ROWS_NEXT", "Next Rows", "Show the next vertex page"),
            ("GROUPS_PREV", "Previous Groups", "Show the previous group page"),
            ("GROUPS_NEXT", "Next Groups", "Show the next group page"),
        )
    )

    def execute(self, context):
        settings = context.scene.srs_settings
        obj = active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        vertices = _table_vertices(obj, settings)
        groups = _table_groups(obj, vertices, settings.weight_table_include_zero)
        row_page, group_page, max_row_page, max_group_page = _table_page_state(
            settings, len(vertices), len(groups)
        )
        if self.direction == "ROWS_PREV":
            row_page = max(0, row_page - 1)
        elif self.direction == "ROWS_NEXT":
            row_page = min(max_row_page, row_page + 1)
        elif self.direction == "GROUPS_PREV":
            group_page = max(0, group_page - 1)
        elif self.direction == "GROUPS_NEXT":
            group_page = min(max_group_page, group_page + 1)
        if settings.weight_table_row_page != row_page:
            settings.weight_table_row_page = row_page
        if settings.weight_table_group_page != group_page:
            settings.weight_table_group_page = group_page
        return {"FINISHED"}


def _table_vertices(obj: bpy.types.Object, settings) -> list[int]:
    return selected_vertex_indices(obj, settings.weight_selected_only)


def _table_groups(obj: bpy.types.Object, vertices: Iterable[int], include_zero: bool) -> list[int]:
    if include_zero:
        return [group.index for group in obj.vertex_groups]
    used: set[int] = set()
    for vertex_index in vertices:
        used.update(_weight_map(obj, vertex_index))
    return [group.index for group in obj.vertex_groups if group.index in used]


def _table_page_state(settings, vertex_count: int, group_total: int) -> tuple[int, int, int, int]:
    row_count = max(1, int(settings.weight_table_rows))
    group_count = max(1, int(settings.weight_table_columns))
    max_row_page = max(0, (max(0, int(vertex_count)) - 1) // row_count)
    max_group_page = max(0, (max(0, int(group_total)) - 1) // group_count)
    row_page = min(max(0, int(settings.weight_table_row_page)), max_row_page)
    group_page = min(max(0, int(settings.weight_table_group_page)), max_group_page)
    return row_page, group_page, max_row_page, max_group_page


def draw_weight_table(layout, context):
    obj = active_mesh(context)
    if obj is None:
        layout.label(text=tr("Select a mesh object.", "メッシュオブジェクトを選択してください。"), icon="ERROR")
        return
    settings = context.scene.srs_settings
    options = layout.row(align=True)
    options.prop(settings, "weight_table_include_zero")
    options.prop(settings, "weight_table_rows", text=tr("Rows", "行数"))
    options.prop(settings, "weight_table_columns", text=tr("Columns", "列数"))
    vertices = _table_vertices(obj, settings)
    groups = _table_groups(obj, vertices, settings.weight_table_include_zero)
    row_count = max(1, settings.weight_table_rows)
    group_count = max(1, settings.weight_table_columns)
    row_page, group_page, max_row_page, max_group_page = _table_page_state(
        settings, len(vertices), len(groups)
    )
    shown_vertices = vertices[row_page * row_count : (row_page + 1) * row_count]
    shown_groups = groups[group_page * group_count : (group_page + 1) * group_count]
    nav = layout.row(align=True)
    nav.operator("srs.weight_table_page", text="< V").direction = "ROWS_PREV"
    nav.label(text=tr_format("V %(page)d/%(total)d", page=row_page + 1, total=max_row_page + 1))
    nav.operator("srs.weight_table_page", text="V >").direction = "ROWS_NEXT"
    nav.separator()
    nav.operator("srs.weight_table_page", text="< G").direction = "GROUPS_PREV"
    nav.label(text=tr_format("G %(page)d/%(total)d", page=group_page + 1, total=max_group_page + 1))
    nav.operator("srs.weight_table_page", text="G >").direction = "GROUPS_NEXT"
    header = layout.row(align=True)
    header.label(text=tr("Vertex", "頂点"))
    for group_index in shown_groups:
        header.label(text=obj.vertex_groups[group_index].name, translate=False)
    for vertex_index in shown_vertices:
        weights = _weight_map(obj, vertex_index)
        row = layout.row(align=True)
        row.label(text=f"#{vertex_index}")
        for group_index in shown_groups:
            value = weights.get(group_index, 0.0)
            op = row.operator("srs.weight_table_edit", text=(f"{value:.3f}" if value else "—"))
            op.vertex_index = vertex_index
            op.group_index = group_index
            op.value = value


class SRS_OT_weight_table_open(bpy.types.Operator):
    bl_idname = "srs.weight_table_open"
    bl_label = "Skin Weight Table"
    bl_description = (
        "Open a popup table for inspecting and editing vertex-group weights by vertex and group. "
        "Use selected vertices in Edit Mode or the active mesh in Object Mode."
    )

    @classmethod
    def poll(cls, context):
        return active_mesh(context) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=900)

    def draw(self, context):
        draw_weight_table(self.layout, context)

    def execute(self, context):
        return {"FINISHED"}


class SRS_OT_weight_table_export(bpy.types.Operator):
    bl_idname = "srs.weight_table_export"
    bl_label = "Export Weight Table"
    bl_description = "Write the displayed mesh weights to a tab-separated Blender Text datablock."
    bl_options = {'UNDO'}

    def execute(self, context):
        obj = active_mesh(context)
        if obj is None:
            return {"CANCELLED"}
        settings = context.scene.srs_settings
        vertices = _table_vertices(obj, settings)
        groups = list(range(len(obj.vertex_groups)))
        lines = ["vertex\t" + "\t".join(obj.vertex_groups[index].name for index in groups)]
        for vertex_index in vertices:
            weights = _weight_map(obj, vertex_index)
            lines.append(
                str(vertex_index) + "\t" + "\t".join(f"{weights.get(index, 0.0):.6f}" for index in groups)
            )
        text_block_write(f"{obj.name}_SkinWeightTable", "\n".join(lines))
        return {"FINISHED"}


CLASSES = (
    SRS_OT_weight_apply,
    SRS_OT_weight_copy,
    SRS_OT_weight_paste,
    SRS_OT_weight_table_edit,
    SRS_OT_weight_table_page,
    SRS_OT_weight_table_open,
    SRS_OT_weight_table_export,
)


_REGISTERED = False


def _clear_weight_clipboard() -> None:
    _WEIGHT_CLIPBOARD.clear()


def register() -> bool:
    global _REGISTERED
    if generation.module_is_registered(__name__, marker=__srs_module_generation_marker__):
        _REGISTERED = True
        return False
    registered_now = ()
    try:
        registered_now = register_classes(
            CLASSES,
            module_name=__name__,
            revision=__srs_revision__,
            module_marker=__srs_module_generation_marker__,
        )
        generation.track_cleanup(
            _clear_weight_clipboard,
            module_name=__name__,
            label="weight clipboard cache",
        )
    except Exception:
        unregister_classes(registered_now, attempts=2)
        _clear_weight_clipboard()
        raise
    generation.mark_module_registered(__name__, True)
    _REGISTERED = True
    return True


def unregister() -> dict:
    global _REGISTERED
    report = unregister_owned_classes(module_name=__name__, attempts=2)
    if report.get("all_removed"):
        generation.mark_module_registered(__name__, False)
        _REGISTERED = False
    return report
