# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Knee split for externally installed Auto-Rig Pro rigs.

Auto-Rig Pro bends the knee as a single hinge: the thigh's distal end and the
calf's proximal end stay locked together. Past about 90 degrees of flexion a real
knee does not behave that way -- the patella rides over the condyles and the two
sides slide apart, which is what keeps the fold from collapsing into itself.

This module installs that behaviour as drivers on the rig's own secondary bend
controllers. Nothing is added to the armature and no Auto-Rig Pro code is imported;
only its bone naming is relied on, so the feature survives a re-generation of the
controllers as long as the same names come back.

Two independent components, either of which may be zero:

    slide     the thigh end moves toward the hip and the calf start toward the
              ankle -- the "double joint" slide along each segment's own axis
    apart     the two sides separate perpendicular to their own axis, away from
              each other, which opens the fold instead of letting it crush

Each side has its own pair of amounts. Pushing the thigh side "apart" moves it
anteriorly, which makes the knee cap bulge forward, so that one defaults to zero;
the thigh separates by sliding toward the hip instead.

Both are tapered linearly to zero at the far anchor (hip / ankle). A linear taper
applied perpendicular to a straight chain maps that chain to another straight
chain, so the shin stays straight from the ankle to its relocated top -- it pivots
about the ankle rather than bending.

The driving value is the flexion angle measured as the rotation difference between
``thigh_stretch`` and ``leg_stretch``, so it follows whatever control the animator
actually uses -- IK, FK, or a direct pose.
"""

import math

import bpy
from mathutils import Matrix, Vector

from . import knee_profile

# Auto-Rig Pro bone names this module relies on.
JOINT_FMT = "leg_stretch{side}"
THIGH_FMT = "thigh_stretch{side}"
HIP_FMT = "thigh_twist{side}"
ANKLE_FMT = "foot{side}"
POLE_CANDIDATES = ("c_leg_pole{side}", "leg_fk_pole{side}", "foot_pole{side}")

THIGH_CHAIN = ("c_thigh_bend_contact{side}", "c_thigh_bend_01{side}",
               "c_thigh_bend_02{side}")
CALF_CHAIN = ("c_knee_bend{side}", "c_leg_bend_01{side}", "c_leg_bend_02{side}",
              "c_ankle_bend{side}")

SIDES = (".l", ".r")
_MARK = "SRS knee split"


def _fmt(names, side):
    return tuple(n.format(side=side) for n in names)


def resolve(armature, side, joint_spec=None):
    """Collect everything the install needs from the rest pose.

    ``joint`` optionally supplies an already-discovered joint (see
    :mod:`joint_setup`), which is what lets this same treatment run on an
    elbow. Left out, the knee's own bone names are used and nothing changes.

    Returns ``(data, error)``. ``error`` is a short human-readable string when the
    rig does not carry the bones this feature drives.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    bones = armature.data.bones
    mw = armature.matrix_world
    if joint_spec is not None:
        need = {"joint": joint_spec["distal"], "thigh": joint_spec["proximal"],
                "hip": joint_spec["prox_anchor"],
                "ankle": joint_spec["dist_anchor"]}
    else:
        need = {"joint": JOINT_FMT.format(side=side),
                "thigh": THIGH_FMT.format(side=side),
                "hip": HIP_FMT.format(side=side),
                "ankle": ANKLE_FMT.format(side=side)}
    missing = [n for n in need.values() if n not in bones]
    if missing:
        return None, "Missing bones: %s" % ", ".join(missing)

    joint = mw @ bones[need["joint"]].head_local
    hip = mw @ bones[need["hip"]].head_local
    ankle = mw @ bones[need["ankle"]].head_local
    u_thigh = (hip - joint)
    u_calf = (ankle - joint)
    if u_thigh.length < 1e-6 or u_calf.length < 1e-6:
        return None, "Degenerate leg chain"
    len_thigh = u_thigh.length
    len_calf = u_calf.length
    u_thigh = u_thigh.normalized()
    u_calf = u_calf.normalized()

    # The knee's bend plane comes from the pole: Auto-Rig Pro places it in front of
    # the joint. At rest the leg is straight, so the two segment axes are collinear
    # and cannot define the plane on their own.
    pole = None
    pole_name = None
    explicit = joint_spec is not None and joint_spec.get("pole")
    for cand in ((joint_spec["pole"],) if explicit else POLE_CANDIDATES):
        n = cand if explicit else cand.format(side=side)
        if n in bones:
            p = mw @ bones[n].head_local
            v = p - joint
            v = v - u_calf * v.dot(u_calf)
            if v.length > 1e-4:
                pole = v.normalized()
                pole_name = n
                break
    if pole is None:
        return None, "No usable knee pole bone"

    if joint_spec is not None:
        thigh_bones = [n for n in joint_spec.get("prox_bend", []) if n in bones]
        calf_bones = [n for n in joint_spec.get("dist_bend", []) if n in bones]
    else:
        thigh_bones = [n for n in _fmt(THIGH_CHAIN, side) if n in bones]
        calf_bones = [n for n in _fmt(CALF_CHAIN, side) if n in bones]
    if not thigh_bones and not calf_bones:
        return None, "No secondary bend controllers on this leg"

    return {
        "side": side,
        "joint": joint,
        "hip": hip,
        "ankle": ankle,
        "u_thigh": u_thigh,
        "u_calf": u_calf,
        "len_thigh": len_thigh,
        "len_calf": len_calf,
        "anterior": pole,
        "pole_bone": pole_name,
        "thigh_bones": thigh_bones,
        "calf_bones": calf_bones,
        "driver_a": need["thigh"],
        "driver_b": need["joint"],
    }, ""


def _taper(armature, bone_name, joint, length):
    """1 at the knee, 0 at the far anchor, linear in between."""
    b = armature.data.bones[bone_name]
    d = ((armature.matrix_world @ b.head_local) - joint).length
    return max(0.0, 1.0 - d / max(length, 1e-6))


def _clear_bone(armature, bone_name):
    ad = armature.animation_data
    removed = 0
    pb = armature.pose.bones.get(bone_name)
    paths = {'pose.bones["%s"].location' % bone_name,
             'pose.bones["%s"].rotation_euler' % bone_name,
             'pose.bones["%s"].rotation_quaternion' % bone_name}
    if ad:
        for fc in list(ad.drivers):
            if fc.data_path in paths:
                ad.drivers.remove(fc)
                removed += 1
    if pb is not None:
        pb.location = Vector((0.0, 0.0, 0.0))
        pb.rotation_euler = (0.0, 0.0, 0.0)
        pb.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
    return removed


def _tilt_rotation(pb, armature, axis_world, theta):
    """The bone-local rotation equivalent to turning by ``theta`` about a world axis.

    The axis is the knee's bend-plane normal, which is also the axis the whole leg
    swings about, so the mapping computed from the rest matrices stays valid in a
    posed rig -- measured on the reference rig, one degree on the bone's local Z
    gives exactly one degree of in-plane tilt at every flexion tested.
    """
    basis = (armature.matrix_world @ pb.bone.matrix_local).to_3x3()
    try:
        inv = basis.inverted()
    except ValueError:
        return None
    return inv @ Matrix.Rotation(theta, 3, axis_world) @ basis


def remove(armature, sides=SIDES, joint=None):
    """Take the split back out. Safe to call when it was never installed."""
    n = 0
    for side in sides:
        if joint is not None:
            names = (tuple(joint.get("prox_bend", []))
                     + tuple(joint.get("dist_bend", []))
                     + tuple(joint.get("front_fan", []))
                     + tuple(joint.get("back_fan", [])))
        else:
            names = _fmt(THIGH_CHAIN, side) + _fmt(CALF_CHAIN, side)
        for name in names:
            if name in armature.pose.bones:
                n += _clear_bone(armature, name)
    return n


def install(armature, sides=SIDES, onset_deg=90.0, end_deg=170.0,
            thigh_slide_mm=20.0, thigh_apart_mm=0.0,
            calf_slide_mm=0.0, calf_apart_mm=45.0, ramp_curve="",
            joint=None):
    """Install the split. Returns ``(report, error)``.

    ``onset_deg`` / ``end_deg`` are flexion angles. Below the onset nothing moves,
    so poses that are already approved do not change.

    ``ramp_curve`` optionally replaces that straight onset-to-end ramp with a
    piecewise-linear one, written as ``angle:factor`` pairs with the factor running
    0 to 1 -- for instance ``"90:0, 120:0.25, 150:0.7, 170:1"`` to hold the split
    back until the fold is well past a right angle. When it is empty the plain ramp
    is used.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if end_deg <= onset_deg:
        return None, "End angle must be greater than the onset angle"
    curve_points = None
    if ramp_curve:
        try:
            curve_points = knee_profile.parse_curve(ramp_curve)
        except ValueError as exc:
            return None, "Ramp curve: %s" % exc

    report = {"sides": [], "bones": [], "removed": 0,
              "ramp_curve": ramp_curve or ""}
    for side in sides:
        data, err = resolve(armature, side, joint_spec=joint)
        if data is None:
            report["sides"].append({"side": side, "error": err})
            continue
        report["removed"] += remove(armature, (side,), joint=joint)

        # The driver reads the rotation difference between the two segment bones,
        # so the ramp follows IK, FK or a hand-posed rig alike -- and that reading
        # IS the flexion angle, zero when the leg is straight, so the requested
        # angles are keyed as they stand. Measured on the reference rig: straighten
        # the leg and it reads 0.27 degrees, bend it to 90 and it reads 90.0.
        #
        # The rig's own rest pose carries 8.3 degrees of knee bend, and an earlier
        # revision added that on top of the requested angles, which pushed a
        # requested 90 degree onset out to 98.3. It is reported below, not applied.
        rest = _rest_rotation_difference(armature, data["driver_a"], data["driver_b"])
        ramp_points = curve_points if curve_points is not None else \
            knee_profile.linear_points(onset_deg, end_deg)

        # 成分は側ごとに分ける。太ももを前方へ離すと膝頭が前に膨らむので、
        # 既定では太ももは軸方向（股関節へ）だけ、ふくらはぎは軸直交（後方へ）だけ。
        groups = (
            ("thigh", data["thigh_bones"], data["u_thigh"], data["len_thigh"],
             data["anterior"], thigh_slide_mm, thigh_apart_mm),
            # 折り目は両セグメントの後面側にできるので、「相手から離れる」向きは
            # どちらも自分の前方側になる（実測: 逆符号にすると膝が太ももへ寄る）。
            ("calf", data["calf_bones"], data["u_calf"], data["len_calf"],
             data["anterior"], calf_slide_mm, calf_apart_mm),
        )
        for tag, names, axis, length, away, slide_mm, apart_mm in groups:
            # ``away`` points out of the fold for this segment: the calf leaves the
            # thigh going posteriorly, the thigh leaves the calf going anteriorly.
            away = (away - axis * away.dot(axis))
            if away.length < 1e-6:
                continue
            away = away.normalized()
            # The chain's line tilts because the offset tapers to zero at the far
            # anchor: it leaves the segment axis by atan(apart / length). Turning
            # the bones by that same angle is what keeps the surface smooth --
            # without it every bone still points along the ORIGINAL axis while its
            # head sits on the new line, and that mismatch is pure shear.
            rot_axis = None
            if abs(apart_mm) > 1e-6:
                v = axis.cross(away)
                if v.length > 1e-6:
                    rot_axis = v.normalized()
            for name in names:
                f = _taper(armature, name, data["joint"], length)
                if f <= 1e-3:
                    continue
                world = (axis * (slide_mm * 0.001) + away * (apart_mm * 0.001)) * f
                if world.length < 1e-7:
                    continue
                pb = armature.pose.bones[name]
                basis = (armature.matrix_world @ pb.bone.matrix_local).to_3x3()
                try:
                    local = basis.inverted() @ world
                except ValueError:
                    continue
                pb.lock_location = (False, False, False)
                entry = {"bone": name, "group": tag, "taper": round(f, 4),
                         "mm": round(world.length * 1000.0, 2), "axes": []}
                for comp in range(3):
                    value = local[comp]
                    if abs(value) < 1e-7:
                        continue
                    fcurve = pb.driver_add("location", comp)
                    knee_profile.bind_flexion(fcurve, armature, data["driver_a"],
                                              data["driver_b"])
                    # The ramp rides on the driver's own F-curve as keyframes
                    # rather than inside the expression. A multi-point curve
                    # overruns Blender's expression length limit and is then
                    # reported as a syntax error, and keyframes have the further
                    # advantage of staying editable in the Graph Editor.
                    entry["keys"] = knee_profile.apply_curve(fcurve, ramp_points,
                                                             scale=value)
                    entry["axes"].append("XYZ"[comp])

                # The tilt is a property of the chain's line, not of where a bone
                # sits on it, so every bone in the group gets the SAME angle and
                # the taper is deliberately not applied here. The angle is not
                # linear in the ramp factor, so each control point is evaluated
                # and keyed individually rather than scaled.
                if rot_axis is not None:
                    quat = pb.rotation_mode == "QUATERNION"
                    path = "rotation_quaternion" if quat else "rotation_euler"
                    series = []
                    for ang, fac in ramp_points:
                        theta = -math.atan2(apart_mm * 0.001 * fac, length)
                        rot = _tilt_rotation(pb, armature, rot_axis, theta)
                        if rot is None:
                            series = []
                            break
                        if quat:
                            q = rot.to_quaternion()
                            series.append((ang, [q.w, q.x, q.y, q.z]))
                        else:
                            e = rot.to_euler(pb.rotation_mode)
                            series.append((ang, [e.x, e.y, e.z]))
                    if series:
                        pb.lock_rotation = (False, False, False)
                        entry["rot_deg_at_end"] = round(
                            math.degrees(math.atan2(apart_mm * 0.001
                                                    * ramp_points[-1][1], length)), 3)
                        for comp in range(4 if quat else 3):
                            chan = [(a, v[comp]) for a, v in series]
                            if not quat and max(abs(v) for _, v in chan) < 1e-7:
                                continue
                            fc = pb.driver_add(path, comp)
                            knee_profile.bind_flexion(fc, armature, data["driver_a"],
                                                      data["driver_b"])
                            knee_profile.apply_curve(fc, chan, scale=1.0)
                            entry.setdefault("rot_axes", []).append(
                                "WXYZ"[comp] if quat else "XYZ"[comp])
                report["bones"].append(entry)
        report["sides"].append({"side": side, "pole": data["pole_bone"],
                                "onset_deg": round(ramp_points[0][0], 2),
                                "end_deg": round(ramp_points[-1][0], 2),
                                "rest_flexion_deg": round(rest, 2),
                                "thigh_bones": len(data["thigh_bones"]),
                                "calf_bones": len(data["calf_bones"])})
    if not report["bones"]:
        return report, "Nothing was installed; see the per-side messages"
    return report, ""


def _rest_rotation_difference(armature, name_a, name_b):
    """The flexion the rig already carries in its rest pose, in degrees.

    Reported, not applied: the driver reads absolute flexion, so the requested onset
    needs no offset. It matters because a rest pose bent by more than the onset would
    make the split engage the moment the file opens, and the report makes that
    visible. Taken from the rest matrices rather than ``pose.bones[...].matrix``, so
    the answer does not depend on how the rig happens to be posed right now.
    """
    bones = armature.data.bones
    a = bones.get(name_a)
    b = bones.get(name_b)
    if a is None or b is None:
        return 0.0
    qa = a.matrix_local.to_quaternion()
    qb = b.matrix_local.to_quaternion()
    return math.degrees(qa.rotation_difference(qb).angle)


def audit(armature, sides=SIDES, joint=None):
    """Report what is installed, without changing anything."""
    out = {"installed": [], "issues": []}
    ad = armature.animation_data
    paths = set()
    if ad:
        for fc in ad.drivers:
            paths.add(fc.data_path)
    for side in sides:
        data, err = resolve(armature, side, joint_spec=joint)
        if data is None:
            out["issues"].append("%s: %s" % (side, err))
            continue
        for name in data["thigh_bones"] + data["calf_bones"]:
            path = 'pose.bones["%s"].location' % name
            pb = armature.pose.bones.get(name)
            out["installed"].append({
                "bone": name,
                "driven": path in paths,
                "locked": list(pb.lock_location) if pb else None,
            })
    driven = sum(1 for e in out["installed"] if e["driven"])
    out["driven_count"] = driven
    out["total"] = len(out["installed"])
    for e in out["installed"]:
        if e["driven"] and e["locked"] and any(e["locked"]):
            out["issues"].append("%s is driven but its location is locked" % e["bone"])
    return out


def smooth_knee_weights(armature, mesh, sides=SIDES, radius_mm=115.0,
                        factor=0.6, repeat=8, joint=None, joints=None,
                        force=False):
    """Even out the deform weights in a ring around the knee.

    The fold that appears behind a moderately bent knee is not produced by the
    secondary controllers at all: with every driver this module and
    :mod:`knee_profile` install removed, the reference rig still creases by the
    same amount (measured: posterior dihedral p95 of 50 degrees bare against 48
    degrees driven, at 60 degrees of flexion). It comes from the primary
    ``thigh_stretch`` / ``leg_stretch`` blend changing over too few edge loops.

    Averaging the weights over a ball around the joint spreads that transition.
    Measured on the reference rig at deep flexion it also stops the surface
    tearing: posterior dihedral p95 fell from 137 to 92 degrees at 160 degrees of
    flexion and the count of edges folded past 40 degrees from 65 to 42, which in
    turn let the knee-cap correction run far harder without faceting the cage.

    The ring must NOT be restricted to the posterior side. Smoothing only the
    back measured no better than doing nothing; it is the whole loop that has to
    move together.

    Returns ``(report, error)``.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if mesh is None or mesh.type != "MESH":
        return None, "Select the deformed mesh"
    view = bpy.context.view_layer
    report = {"sides": [], "selected": 0}
    picked = set()
    mw = mesh.matrix_world
    # Smoothing is a destructive mesh edit and is NOT idempotent: running it again
    # averages the weights a second time and the joint loses definition. What was
    # already done is stamped on the mesh so a repeat is skipped rather than
    # silently compounding -- re-running the setup on an already-set-up file cost
    # the knee 7.6mm of knee-cap protrusion at deep flexion before this guard.
    stamp_key = "srs_smoothed_joints"
    done_before = list(mesh.data.get(stamp_key, []))
    specs = list(joints) if joints else [joint] * len(sides)
    stamps = []
    keep_sides, keep_specs = [], []
    for side, spec in zip(sides, specs):
        tag = "%s|%.2f|%.3f|%d" % (
            (spec or {}).get("distal", "knee%s" % side), radius_mm, factor, repeat)
        stamps.append(tag)
        if tag in done_before and not force:
            continue
        keep_sides.append(side)
        keep_specs.append(spec)
    if not keep_sides:
        return {"selected": 0, "skipped": stamps,
                "note": "already smoothed with these settings"}, ""
    sides, specs = keep_sides, keep_specs
    for side, spec in zip(sides, specs):
        data, err = resolve(armature, side, joint_spec=spec)
        if data is None:
            report["sides"].append({"side": side, "error": err})
            continue
        centre = data["joint"]
        r = max(radius_mm, 1.0) * 0.001
        n = 0
        for v in mesh.data.vertices:
            if ((mw @ v.co) - centre).length <= r:
                picked.add(v.index)
                n += 1
        report["sides"].append({"side": side, "verts": n})
    if not picked:
        # A leg that could not be resolved was never measured: say why, not "too far".
        reason = next((row["error"] for row in report["sides"] if row.get("error")), "")
        return report, reason or "No vertices lie within the given radius of either knee"

    prev_mode = bpy.context.object.mode if bpy.context.object else "OBJECT"
    prev_active = view.objects.active
    # The mesh's own X-mirror must be off for this. With it on, Blender mirrors the
    # smoothing onto the opposite side, so treating both knees gives each of them
    # TWO passes instead of one -- measured: smoothing the right knee changed 105
    # of the left knee's 108 vertices even though it selected none of them, and the
    # doubly-smoothed knee lost 6mm of knee-cap definition at deep flexion. The
    # toggle is the user's, so it is restored afterwards.
    mirror_x = getattr(mesh.data, "use_mirror_x", False)
    mirror_vg = getattr(mesh.data, "use_mirror_vertex_groups", False)
    try:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh.data.use_mirror_x = False
        mesh.data.use_mirror_vertex_groups = False
        view.objects.active = mesh
        # Clear the selection from inside Edit Mode first. A selection written to
        # mesh.vertices in Object Mode does not survive if the object still holds
        # an edit-mesh from a previous call, so a second call smooths the UNION of
        # both selections. Measured: treating the right knee after the left left
        # the left one smoothed twice -- its weights came out bit-identical to two
        # passes, and the doubly-smoothed knee lost 6mm of knee-cap definition at
        # deep flexion.
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="DESELECT")
        bpy.ops.object.mode_set(mode="OBJECT")
        for v in mesh.data.vertices:
            v.select = v.index in picked
        mesh.data.update()
        bpy.ops.object.mode_set(mode="EDIT")
        # The enum is built from the object's own groups, so it is empty outside a
        # real mesh context; fall back rather than assume an identifier exists.
        last = ""
        for mode in ("BONE_DEFORM", "ALL", None):
            kwargs = {"factor": float(factor), "repeat": int(max(1, repeat)),
                      "expand": 0.0}
            if mode:
                kwargs["group_select_mode"] = mode
            try:
                bpy.ops.object.vertex_group_smooth(**kwargs)
                report["group_select_mode"] = mode or "(default)"
                last = ""
                break
            except (RuntimeError, TypeError) as exc:
                last = str(exc)
        if last:
            return report, "Weight smoothing was refused. Check the mode and selection."
    finally:
        if bpy.context.object and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        mesh.data.use_mirror_x = mirror_x
        mesh.data.use_mirror_vertex_groups = mirror_vg
        view.objects.active = prev_active
        if prev_active is not None and prev_mode != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode=prev_mode)
            except RuntimeError:
                pass
    report["selected"] = len(picked)
    report["radius_mm"] = radius_mm
    report["factor"] = factor
    report["repeat"] = repeat
    report["mirror_x_was"] = bool(mirror_x)
    mesh.data[stamp_key] = done_before + [t for t in stamps
                                          if t not in done_before]
    return report, ""
