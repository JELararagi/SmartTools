# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

"""Exact-identity Blender RNA lifecycle helpers for Smart Rig Suite."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

import bpy

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

from . import generation


class RegistrationConflict(RuntimeError):
    """Raised when an RNA identifier or ownership record belongs elsewhere."""


class UnregistrationIncomplete(RuntimeError):
    """Raised only by callers that explicitly require complete teardown."""


def registered_class_identity(cls: type) -> type | None:
    """Return Blender's live class identity for ``cls``'s Python class name."""
    name = str(getattr(cls, "__name__", "") or "")
    if name:
        try:
            current = getattr(bpy.types, name, None)
        except Exception:
            current = None
        if isinstance(current, type):
            return current
    try:
        if bool(getattr(cls, "is_registered", False)):
            return cls
    except Exception:
        pass
    return None


def class_is_registered(cls: type) -> bool:
    return registered_class_identity(cls) is cls


def unregister_class_exact(cls: type, *, attempts: int = 1) -> dict[str, Any]:
    """Unregister one exact class and report mismatches instead of hiding them."""
    record = None
    for candidate in generation.class_records():
        if candidate.get("identity") is cls:
            record = candidate
            break
    if record is None:
        current = registered_class_identity(cls)
        if current is None:
            return {
                "name": str(getattr(cls, "__name__", "")),
                "kind": "RNAClass",
                "identity_id": id(cls),
                "status": "absent",
                "attempts": 0,
                "remaining": False,
                "errors": [],
            }
        if current is not cls:
            return {
                "name": str(getattr(cls, "__name__", "")),
                "kind": "RNAClass",
                "identity_id": id(cls),
                "current_identity_id": id(current),
                "status": "identity_mismatch",
                "attempts": 0,
                "remaining": True,
                "errors": [],
            }
        # An untracked live class must never be adopted or removed by identifier.
        return {
            "name": str(getattr(cls, "__name__", "")),
            "kind": "RNAClass",
            "identity_id": id(cls),
            "status": "unowned_live_identity",
            "attempts": 0,
            "remaining": True,
            "errors": [],
        }
    return generation.unregister_class_record(record, attempts=attempts)


def register_classes(
    classes: Iterable[type],
    *,
    module_name: str,
    revision: str,
    module_marker: Any,
) -> tuple[type, ...]:
    """Register classes transactionally under the active generation token."""
    generation.assert_module_context(module_name, revision, module_marker)
    registered_now: list[type] = []
    tracked_now: list[type] = []
    try:
        for cls in tuple(classes):
            current = registered_class_identity(cls)
            tracked = next(
                (item for item in generation.class_records(module_name=module_name)
                 if item.get("identity") is cls),
                None,
            )
            if current is cls:
                if tracked is None:
                    raise RegistrationConflict(
                        f"RNA class {cls.__name__} is live but is not owned by the active generation"
                    )
                continue
            if current is not None:
                raise RegistrationConflict(
                    f"RNA class {cls.__name__} is owned by a different Python identity "
                    f"({current.__module__}.{current.__name__}); live replacement was refused"
                )
            # A module re-execution can create new classes while old identities
            # remain in the registry even if another caller removed them from RNA.
            stale_same_name = next(
                (
                    item for item in generation.class_records(module_name=module_name)
                    if str(item.get("name")) == str(getattr(cls, "__name__", ""))
                    and item.get("identity") is not cls
                ),
                None,
            )
            if stale_same_name is not None:
                raise RegistrationConflict(
                    f"module {module_name} produced a second identity for {cls.__name__}; restart required"
                )
            try:
                setattr(cls, "__srs_generation_token__", generation.active_token(revision=revision))
                setattr(cls, "__srs_code_revision__", str(revision))
            except Exception:
                pass

            # Retain the exact class identity in the process registry before the
            # Blender call. If register_class partially succeeds and then raises,
            # rollback still owns the only identity it is allowed to remove.
            record = generation.track_class(
                cls,
                module_name=module_name,
                revision=revision,
                marker=module_marker,
            )
            record["state"] = "registering"
            tracked_now.append(cls)
            bpy.utils.register_class(cls)
            if registered_class_identity(cls) is not cls:
                raise RegistrationConflict(f"Blender did not retain the exact identity for {cls.__name__}")
            record["state"] = "registered"
            registered_now.append(cls)
    except Exception:
        for cls in reversed(tracked_now):
            try:
                report = unregister_class_exact(cls, attempts=2)
                if not report.get("remaining"):
                    generation.forget_class(cls)
            except Exception:
                pass
        raise
    return tuple(registered_now)


def unregister_owned_classes(
    *,
    module_name: str,
    kinds: Iterable[str] | None = None,
    attempts: int = 2,
) -> dict[str, Any]:
    """Unregister records owned by ``module_name`` using retained identities."""
    return generation.unregister_class_records(
        module_name=module_name,
        kinds=kinds,
        attempts=attempts,
    )


def unregister_classes(
    classes: Iterable[type] | None = None,
    *,
    module_name: str | None = None,
    attempts: int = 2,
) -> dict[str, Any]:
    """Compatibility wrapper returning a machine-readable teardown report."""
    if module_name is not None:
        return unregister_owned_classes(module_name=module_name, attempts=attempts)
    results = [unregister_class_exact(cls, attempts=attempts) for cls in reversed(tuple(classes or ())) ]
    remaining = [item for item in results if bool(item.get("remaining"))]
    return {
        "results": results,
        "removed": sum(item.get("status") == "removed" for item in results),
        "absent": sum(item.get("status") == "absent" for item in results),
        "identity_mismatches": sum(item.get("status") in {"identity_mismatch", "unowned_live_identity"} for item in results),
        "errors": [error for item in results for error in item.get("errors", ())],
        "remaining": remaining,
        "all_removed": not remaining,
    }


def rna_property_fixed_type_identifier(host: Any, name: str) -> str:
    try:
        prop = host.bl_rna.properties.get(name)
    except Exception:
        prop = None
    if prop is None:
        try:
            prop = next(
                (item for item in host.bl_rna.properties if str(getattr(item, "identifier", "")) == name),
                None,
            )
        except Exception:
            prop = None
    if prop is None:
        return ""
    try:
        return str(getattr(getattr(prop, "fixed_type", None), "identifier", "") or "")
    except Exception:
        return ""


def class_rna_identifier(cls: type) -> str:
    try:
        return str(getattr(getattr(cls, "bl_rna", None), "identifier", "") or cls.__name__)
    except Exception:
        return str(getattr(cls, "__name__", "") or "")


def rna_pointer_matches(host: Any, name: str, property_group_cls: type) -> bool:
    expected = class_rna_identifier(property_group_cls)
    actual = rna_property_fixed_type_identifier(host, name)
    return bool(expected and actual and expected == actual)


def register_pointer_property(
    host: Any,
    name: str,
    property_group_cls: type,
    *,
    module_name: str,
    revision: str,
    module_marker: Any,
) -> dict[str, Any]:
    """Create and own a PointerProperty only under the active generation token."""
    generation.assert_module_context(module_name, revision, module_marker)
    existing_records = [
        record for record in (generation.active_generation() or {}).get("pointer_properties", ())
        if record.get("host") is host and str(record.get("name")) == str(name)
    ]
    try:
        exists = hasattr(host, name)
    except Exception:
        exists = True
    if exists:
        if not existing_records:
            raise RegistrationConflict(
                f"{getattr(host, '__name__', host)}.{name} exists without active-generation ownership"
            )
        record = existing_records[0]
        if record.get("property_group_cls") is not property_group_cls or not generation.pointer_record_owned(record):
            raise RegistrationConflict(
                f"{getattr(host, '__name__', host)}.{name} ownership identity does not match this generation"
            )
        return record

    setattr(host, name, bpy.props.PointerProperty(type=property_group_cls))
    if not hasattr(host, name) or not rna_pointer_matches(host, name, property_group_cls):
        try:
            delattr(host, name)
        except Exception:
            pass
        raise RegistrationConflict(f"failed to verify {getattr(host, '__name__', host)}.{name}")
    try:
        return generation.track_pointer_property(
            host,
            name,
            property_group_cls,
            module_name=module_name,
            revision=revision,
            marker=module_marker,
        )
    except Exception:
        # Roll back only the pointer identity created by this call. Never delete
        # a pre-existing pointer owned by another retained generation.
        try:
            if rna_pointer_matches(host, name, property_group_cls):
                delattr(host, name)
        except Exception:
            pass
        raise


def unregister_owned_pointer_properties(*, module_name: str) -> dict[str, Any]:
    return generation.unregister_pointer_records(module_name=module_name)
