# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi

from __future__ import annotations

import builtins
import importlib
import sys
from collections.abc import MutableMapping
from pathlib import Path
from typing import Any

import bpy

__version__ = "2.62.35"
CODE_REVISION = "2.26.0"
__srs_revision__ = CODE_REVISION
__srs_module_generation_marker__ = object()

bl_info = {
    "name": 'Smart Rig',
    "author": "JELararagi",
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Rig",
    "description": (
        "Workflow, validation, and extension companion for separately installed Auto-Rig Pro, "
        "AI_win, and Proxy Picker"
    ),
    "category": "Rigging",
}

_PACKAGE_NAME = str(__package__ or __name__)
_PACKAGE_DIR = Path(__file__).resolve().parent
_REGISTRY_SCHEMA = 3
_REGISTRY_OWNER = "smart_rig_suite"
_DRIVER_NAMESPACE_KEY = "_JELARARAGI_SMART_RIG_SUITE_GENERATION_REGISTRY_V3"
_BUILTINS_SLOT = "_JELARARAGI_SMART_RIG_SUITE_GENERATION_REGISTRY_V3"

# Registration order keeps all Panel dependencies alive until the Panel is gone.
_MODULE_NAMES = (
    "i18n",
    "preferences",
    "properties",
    "compatibility",
    "persistence",
    "weight_tools",
    "operators",
    "ui",
)
_IMPORT_ORDER = (
    "generation",
    "unified_contract",
    "i18n",
    "lifecycle",
    "preferences",
    "properties",
    "external_tools",
    "legacy_cleanup",
    "compatibility",
    "persistence",
    "audit",
    "bind_common",
    "eye_setup",
    "face_regions",
    "corrective",
    "rig_hygiene",
    "costume_bind",
    "jiggle",
    "collide",
    "cloth_setup",
    "eye_shadow",
    "wrist_fold",
    "face_falloff",
    "knee_profile",
    "knee_split",
    "joint_setup",
    "hair_chain",
    "part_rig",
    "mocap",
    "band_width",
    "kilt_strips",
    "follow_strips",
    "cuff_push",
    "shoe_lift",
    "character_rescale",
    "ikfk",
    "chain_group",
    "weight_tools",
    "operators",
    "ui",
)
_OPTIONAL_STATUS_MODULE = "status_runtime"
_KNOWN_RNA_CLASS_NAMES = (
    "SRS_OT_show_section_help",
    "SRS_PT_smart_rig",
    "SRS_SceneSettings",
    "SRS_AddonPreferences",
    "SRS_OT_refresh_external_status",
    "SRS_OT_assign_workflow_targets",
    "SRS_OT_workflow_preflight",
    "SRS_OT_arp_add_limb_safe",
    "SRS_OT_arp_snap_safe",
    "SRS_OT_arp_add_reference",
    "SRS_OT_arp_prepare_context",
    "SRS_OT_arp_marker_ai",
    "SRS_OT_arp_smart_detect",
    "SRS_OT_arp_match_to_rig",
    "SRS_OT_arp_bind_workflow",
    "SRS_OT_arp_ikfk_safe",
    "SRS_OT_arp_pose_utility",
    "SRS_OT_ai_auto_detect",
    "SRS_OT_ai_validate",
    "SRS_OT_ai_sync_arp",
    "SRS_OT_ai_open_folder",
    "SRS_OT_proxy_external_action",
    "SRS_OT_proxy_set_collection_button",
    "SRS_OT_proxy_batch_pair",
    "SRS_OT_proxy_audit",
    "SRS_OT_proxy_repair",
    "SRS_OT_proxy_export",
    "SRS_OT_proxy_import",
    "SRS_OT_weight_quality_audit",
    "SRS_OT_full_audit",
    "SRS_OT_clean_legacy_scene_data",
    "SRS_OT_export_integration_report",
    "SRS_OT_weight_apply",
    "SRS_OT_weight_copy",
    "SRS_OT_weight_paste",
    "SRS_OT_weight_table_edit",
    "SRS_OT_weight_table_page",
    "SRS_OT_weight_table_open",
    "SRS_OT_weight_table_export",
    "SRS_OT_eye_snap_references",
    "SRS_OT_eye_audit",
    "SRS_OT_lid_pivot_audit",
    "SRS_OT_face_weight_audit",
    "SRS_OT_corrective_lid",
    "SRS_OT_corrective_lip",
    "SRS_OT_hygiene_audit",
    "SRS_OT_hygiene_lock_dead",
    "SRS_OT_hygiene_clamp_face",
    "SRS_OT_hygiene_bind_loose",
    "SRS_OT_hygiene_repair_drivers",
    "SRS_OT_costume_bind",
    "SRS_OT_jiggle_bake",
    "SRS_OT_jiggle_clear",
    "SRS_OT_cloth_setup",
    "SRS_OT_lid_shadow_build",
    "SRS_OT_lid_shadow_verify",
    "SRS_OT_lid_shadow_remove",
    "SRS_OT_wrist_fold_install",
    "SRS_OT_wrist_fold_verify",
    "SRS_OT_wrist_fold_remove",
    "SRS_OT_face_falloff_audit",
    "SRS_OT_face_falloff_trim",
    "SRS_OT_corrective_confine",
    "SRS_OT_blink_pose_prepare",
    "SRS_OT_lid_range_clamp",
    "SRS_OT_lid_pivot_fix",
    "SRS_OT_eye_bind",
    "SRS_OT_eye_verify",
    "SRS_OT_eye_dispose_temp",
    "SRS_OT_knee_split_install",
    "SRS_OT_knee_split_remove",
    "SRS_OT_knee_split_audit",
    "SRS_OT_knee_smooth_weights",
    "SRS_OT_hair_build",
    "SRS_OT_hair_remove",
    "SRS_OT_hair_audit",
    "SRS_OT_part_audit",
    "SRS_OT_part_visibility",
    "SRS_OT_part_delete",
    "SRS_OT_joint_setup_all",
    "SRS_OT_joint_setup_remove",
    "SRS_OT_joint_audit",
    "SRS_OT_joint_mirror_fans",
    "SRS_OT_knee_profile_install",
    "SRS_OT_knee_profile_remove",
    "SRS_OT_knee_profile_audit",
    "SRS_OT_band_width_lock",
    "SRS_OT_ikfk_switch",
    "SRS_OT_ikfk_step_keys",
    "SRS_OT_chain_group_build",
    "SRS_OT_chain_group_remove",
    "SRS_OT_hygiene_drop_faint",
    "SRS_OT_hygiene_symmetrize_midline",
    "SRS_OT_hygiene_blend_midline",
    "SRS_OT_cloth_remove",
    "SRS_OT_jiggle_chain_include",
    "SRS_OT_colliders_display",
    "SRS_OT_part_link_key",
    "SRS_OT_strip_rig_build",
    "SRS_OT_follow_strips_build",
    "SRS_OT_jiggle_mute",
    "SRS_OT_jiggle_chain_collide",
    "SRS_OT_jiggle_chain_mark",
    "SRS_OT_jiggle_swing_layer",
    "SRS_OT_band_mirror",
    "SRS_OT_colliders_fit_without",
    "SRS_OT_umbrella_rolls",
    "SRS_OT_part_motion_register",
    "SRS_OT_part_motion_unregister",
    "SRS_OT_part_motion",
    "SRS_OT_part_bake",
    "SRS_OT_part_clear",
    "SRS_OT_jiggle_chain_gravity_rest",
    "SRS_OT_jiggle_chain_rest_clear",
    "SRS_OT_jiggle_chain_thickness",
    "SRS_OT_jiggle_chain_entry_push",
    "SRS_OT_cloth_bake",
    "SRS_OT_cuff_swing_build",
    "SRS_OT_shoe_lift_measure",
    "SRS_OT_shoe_lift_apply",
    "SRS_OT_shoe_lift_clear",
    "SRS_OT_shoe_lift_remove",
    "SRS_OT_character_rescale_measure",
    "SRS_OT_character_rescale_check",
    "SRS_OT_character_rescale",
)

_previous_modules = globals().get("_MODULES")
_MODULES: list[Any] = _previous_modules if isinstance(_previous_modules, list) else []
_REGISTERED = bool(globals().get("_REGISTERED", False))
_LAST_REGISTER_STATUS: dict[str, Any] = dict(globals().get("_LAST_REGISTER_STATUS", {}))
_LAST_UNREGISTER_REPORT: dict[str, Any] = dict(globals().get("_LAST_UNREGISTER_REPORT", {}))
_RESTART_REQUIRED_REASON = str(globals().get("_RESTART_REQUIRED_REASON", "") or "")
del _previous_modules


def _redraw_view3d() -> None:
    try:
        windows = tuple(bpy.context.window_manager.windows)
    except Exception:
        return
    for window in windows:
        try:
            areas = tuple(window.screen.areas)
        except Exception:
            continue
        for area in areas:
            if getattr(area, "type", "") != "VIEW_3D":
                continue
            try:
                area.tag_redraw()
            except Exception:
                pass


def _valid_registry(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("schema") == _REGISTRY_SCHEMA
        and value.get("owner") == _REGISTRY_OWNER
        and isinstance(value.get("history"), list)
    )


def _raw_registry(*, for_cleanup: bool, create: bool = False) -> dict[str, Any] | None:
    builtins_value = getattr(builtins, _BUILTINS_SLOT, None)
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        namespace = None
    if not isinstance(namespace, MutableMapping):
        if for_cleanup and _valid_registry(builtins_value):
            return builtins_value
        return None
    driver_value = namespace.get(_DRIVER_NAMESPACE_KEY)
    if driver_value is not None and not _valid_registry(driver_value):
        if for_cleanup and _valid_registry(builtins_value):
            return builtins_value
        return None
    if builtins_value is not None and not _valid_registry(builtins_value):
        return None
    if _valid_registry(driver_value) and _valid_registry(builtins_value):
        if driver_value is builtins_value:
            return driver_value
        if for_cleanup:
            if driver_value.get("active") and not builtins_value.get("active"):
                return driver_value
            if builtins_value.get("active") and not driver_value.get("active"):
                return builtins_value
        return None
    if _valid_registry(driver_value):
        try:
            setattr(builtins, _BUILTINS_SLOT, driver_value)
        except Exception:
            pass
        return driver_value
    if _valid_registry(builtins_value):
        try:
            namespace[_DRIVER_NAMESPACE_KEY] = builtins_value
        except Exception:
            if not for_cleanup:
                return None
        return builtins_value
    if not create:
        return None
    # The generation module creates the canonical registry after revision gates.
    return {}


def _mark_restart_required(reason: str) -> None:
    global _RESTART_REQUIRED_REASON
    _RESTART_REQUIRED_REASON = str(reason or "A clean Blender restart is required.")
    registry = _raw_registry(for_cleanup=True, create=False)
    if _valid_registry(registry):
        registry["restart_required"] = True
        registry["restart_reason"] = _RESTART_REQUIRED_REASON
        registry["blocked_revision"] = CODE_REVISION
        active = registry.get("active")
        if isinstance(active, dict):
            active["restart_required"] = True
            active["restart_reason"] = _RESTART_REQUIRED_REASON


def _module_path_is_inside_package(module: Any) -> bool:
    try:
        path = Path(module.__file__).resolve()
        path.relative_to(_PACKAGE_DIR)
        return True
    except Exception:
        return False


def _module_belongs_to_package(module_name: str) -> bool:
    """Recognize classic and Extension-qualified Smart Rig module names."""
    name = str(module_name or "")
    if name == _PACKAGE_NAME or name.startswith(_PACKAGE_NAME + "."):
        return True
    if name == "smart_rig_suite" or name.startswith("smart_rig_suite."):
        return True
    if name.endswith(".smart_rig_suite") or ".smart_rig_suite." in name:
        return True
    module = sys.modules.get(name)
    return bool(module is not None and _module_path_is_inside_package(module))


def _callable_belongs_to_package(value: Any, *, depth: int = 0, seen: set[int] | None = None) -> bool:
    if value is None or depth > 4:
        return False
    visited = seen if seen is not None else set()
    identity = id(value)
    if identity in visited:
        return False
    visited.add(identity)
    module_name = str(getattr(value, "__module__", "") or "")
    if _module_belongs_to_package(module_name):
        return True
    try:
        if _module_belongs_to_package(str(type(value).__module__ or "")):
            return True
    except Exception:
        pass
    for attr in ("__func__", "__self__", "__wrapped__", "func", "callback", "notify"):
        try:
            nested = getattr(value, attr, None)
        except Exception:
            nested = None
        if nested is not None and nested is not value:
            if _callable_belongs_to_package(nested, depth=depth + 1, seen=visited):
                return True
    try:
        closure = getattr(value, "__closure__", None) or ()
    except Exception:
        closure = ()
    for cell in closure:
        try:
            nested = cell.cell_contents
        except Exception:
            continue
        if _callable_belongs_to_package(nested, depth=depth + 1, seen=visited):
            return True
    return False


def _handler_collections() -> tuple[Any, ...]:
    result = []
    handlers = getattr(getattr(bpy, "app", None), "handlers", None)
    if handlers is None:
        return ()
    for name in tuple(dir(handlers)):
        if name.startswith("_") or name == "persistent":
            continue
        try:
            collection = getattr(handlers, name)
            tuple(collection)
        except Exception:
            continue
        if hasattr(collection, "remove"):
            result.append(collection)
    return tuple(result)


def _loaded_package_modules() -> dict[str, Any]:
    return {
        name: module
        for name, module in tuple(sys.modules.items())
        if (
            module is not None
            and name != _PACKAGE_NAME
            and _module_belongs_to_package(name)
        )
    }


def _loaded_revision_mismatches() -> list[dict[str, str]]:
    mismatches = []
    for name, module in _loaded_package_modules().items():
        revision = str(getattr(module, "__srs_revision__", "") or "")
        if revision != CODE_REVISION:
            mismatches.append({"module": name, "loaded_revision": revision or "missing"})
    return mismatches


def _scan_live_package_runtime() -> dict[str, Any]:
    live_classes = []
    for name in _KNOWN_RNA_CLASS_NAMES:
        try:
            current = getattr(bpy.types, name, None)
        except Exception:
            current = None
        if isinstance(current, type):
            live_classes.append({
                "name": name,
                "module": str(getattr(current, "__module__", "")),
                "identity_id": id(current),
            })
    # Also detect former package classes whose names are not in the 2.x contract.
    try:
        type_names = tuple(dir(bpy.types))
    except Exception:
        type_names = ()
    known = {item["identity_id"] for item in live_classes}
    for name in type_names:
        try:
            current = getattr(bpy.types, name)
        except Exception:
            continue
        if not isinstance(current, type) or id(current) in known:
            continue
        if _module_belongs_to_package(str(getattr(current, "__module__", ""))):
            live_classes.append({
                "name": str(name),
                "module": str(getattr(current, "__module__", "")),
                "identity_id": id(current),
            })

    pointer_present = False
    try:
        pointer_present = hasattr(bpy.types.Scene, "srs_settings")
    except Exception:
        pointer_present = True

    handler_ids = []
    for collection in _handler_collections():
        for callback in tuple(collection):
            if _callable_belongs_to_package(callback):
                handler_ids.append(id(callback))

    timer_ids = []
    timers = getattr(getattr(bpy, "app", None), "timers", None)
    if timers is not None:
        seen: set[int] = set()
        for module in _loaded_package_modules().values():
            try:
                values = tuple(vars(module).values())
            except Exception:
                values = ()
            for value in values:
                if not callable(value) or id(value) in seen:
                    continue
                seen.add(id(value))
                try:
                    if timers.is_registered(value):
                        timer_ids.append(id(value))
                except Exception:
                    pass

    module_registered_flags = [
        name for name, module in _loaded_package_modules().items()
        if bool(getattr(module, "_REGISTERED", False))
    ]
    return {
        "classes": live_classes,
        "pointer_present": pointer_present,
        "handler_identity_ids": sorted(set(handler_ids)),
        "timer_identity_ids": sorted(set(timer_ids)),
        "module_registered_flags": sorted(module_registered_flags),
    }


def _active_module_contract_violations(active: dict[str, Any]) -> list[dict[str, Any]]:
    """Report child-module identity/revision drift for a live generation."""
    violations: list[dict[str, Any]] = []
    modules = active.get("modules", {})
    if not isinstance(modules, dict):
        return [{"module": "<registry>", "reason": "module registry is malformed"}]
    for module_name, record in tuple(modules.items()):
        if not isinstance(record, dict):
            violations.append({"module": str(module_name), "reason": "module record is malformed"})
            continue
        retained = record.get("module")
        retained_marker = record.get("marker")
        loaded = sys.modules.get(str(module_name))
        loaded_revision = str(getattr(loaded, "__srs_revision__", "") or "") if loaded is not None else ""
        loaded_marker = getattr(loaded, "__srs_module_generation_marker__", None) if loaded is not None else None
        reasons = []
        if loaded is not retained:
            reasons.append("sys.modules identity changed")
        if loaded_marker is not retained_marker:
            reasons.append("module execution marker changed")
        if loaded_revision != str(active.get("revision") or ""):
            reasons.append(f"revision changed to {loaded_revision or 'missing'}")
        if str(record.get("token") or "") != str(active.get("token") or ""):
            reasons.append("generation token changed")
        if reasons:
            violations.append({
                "module": str(module_name),
                "reason": "; ".join(reasons),
                "retained_module_identity_id": id(retained) if retained is not None else 0,
                "loaded_module_identity_id": id(loaded) if loaded is not None else 0,
                "retained_marker_identity_id": id(retained_marker) if retained_marker is not None else 0,
                "loaded_marker_identity_id": id(loaded_marker) if loaded_marker is not None else 0,
                "loaded_revision": loaded_revision or "missing",
            })
    return violations


def _runtime_is_proven_clean() -> tuple[bool, dict[str, Any]]:
    registry = _raw_registry(for_cleanup=True, create=False)
    if _valid_registry(registry):
        active = registry.get("active")
        if isinstance(active, dict):
            control = active.get("control_module")
            try:
                live = control.live_resource_summary(active) if control is not None else {}
            except Exception:
                live = {"unknown": 1}
            if any(live.values()):
                return False, {"registry_live": live}
    scan = _scan_live_package_runtime()
    clean = not (
        scan["classes"]
        or scan["pointer_present"]
        or scan["handler_identity_ids"]
        or scan["timer_identity_ids"]
        or scan["module_registered_flags"]
    )
    return clean, scan


def _clean_shutdown_proves_loaded_modules(
    registry: dict[str, Any] | None,
    mismatches: list[dict[str, str]],
) -> tuple[bool, dict[str, Any]]:
    """Require an external exact-identity proof before discarding old code."""
    if not _valid_registry(registry):
        return False, {"reason": "no valid external generation registry"}
    if isinstance(registry.get("active"), dict):
        return False, {"reason": "an active generation record still exists"}
    proof = registry.get("clean_shutdown")
    if not isinstance(proof, dict) or proof.get("state") != "inactive":
        return False, {"reason": "no completed clean-shutdown proof"}
    live = proof.get("live")
    if not isinstance(live, dict) or any(bool(value) for value in live.values()):
        return False, {"reason": "clean-shutdown proof contains live resources", "live": live}
    modules = proof.get("modules")
    identities = registry.get("clean_shutdown_identities")
    identity_modules = identities.get("modules") if isinstance(identities, dict) else None
    if not isinstance(modules, dict) or not isinstance(identity_modules, dict):
        return False, {"reason": "clean-shutdown exact module contract is missing"}
    if (
        identities.get("state") != "inactive"
        or str(identities.get("token") or "") != str(proof.get("token") or "")
        or str(identities.get("revision") or "") != str(proof.get("revision") or "")
    ):
        return False, {"reason": "clean-shutdown identity and summary contracts disagree"}

    failures = []
    for mismatch in mismatches:
        name = str(mismatch.get("module") or "")
        loaded = sys.modules.get(name)
        record = modules.get(name)
        identity_record = identity_modules.get(name)
        if loaded is None or not isinstance(record, dict) or not isinstance(identity_record, dict):
            failures.append({"module": name, "reason": "module identity was not retained by the proof"})
            continue
        marker = getattr(loaded, "__srs_module_generation_marker__", None)
        reasons = []
        if identity_record.get("module") is not loaded:
            reasons.append("module identity differs from clean-shutdown proof")
        if marker is None or identity_record.get("marker") is not marker:
            reasons.append("execution marker differs from clean-shutdown proof")
        if int(record.get("module_identity_id") or 0) != id(loaded):
            reasons.append("module identity diagnostic differs from exact proof")
        if marker is None or int(record.get("marker_identity_id") or 0) != id(marker):
            reasons.append("execution marker diagnostic differs from exact proof")
        loaded_revision = str(getattr(loaded, "__srs_revision__", "") or "")
        if (
            str(record.get("revision") or "") != loaded_revision
            or str(identity_record.get("revision") or "") != loaded_revision
        ):
            reasons.append("revision differs from clean-shutdown proof")
        if bool(record.get("registered")) or bool(identity_record.get("registered")):
            reasons.append("proof says the module remained registered")
        if reasons:
            failures.append({"module": name, "reason": "; ".join(reasons)})
    if failures:
        return False, {"reason": "loaded modules do not match clean-shutdown identities", "failures": failures}
    return True, {
        "token": str(proof.get("token") or ""),
        "revision": str(proof.get("revision") or ""),
        "module_count": len(mismatches),
    }


def _discard_clean_old_modules() -> None:
    # This is permitted only after _runtime_is_proven_clean() has established
    # that no Blender RNA/callback identity refers to these module dictionaries.
    for name in sorted(_loaded_package_modules(), key=len, reverse=True):
        sys.modules.pop(name, None)
    importlib.invalidate_caches()


def _revision_preflight() -> dict[str, Any]:
    # Registration requires a valid mutable driver namespace even if a builtins
    # fallback exists; cleanup alone may use the fallback.
    try:
        namespace = bpy.app.driver_namespace
    except Exception:
        namespace = None
    if not isinstance(namespace, MutableMapping):
        reason = "bpy.app.driver_namespace is invalid; Smart Rig Suite 2.1.12 was not registered"
        _mark_restart_required(reason)
        return {"status": "restart_required", "reason": reason}

    registry = _raw_registry(for_cleanup=False, create=False)
    builtins_value = getattr(builtins, _BUILTINS_SLOT, None)
    driver_value = namespace.get(_DRIVER_NAMESPACE_KEY)
    if driver_value is not None and not _valid_registry(driver_value):
        reason = "the Smart Rig Suite driver-namespace ownership slot is malformed"
        _mark_restart_required(reason)
        return {"status": "restart_required", "reason": reason}
    if builtins_value is not None and not _valid_registry(builtins_value):
        reason = "the Smart Rig Suite builtins ownership slot is malformed"
        _mark_restart_required(reason)
        return {"status": "restart_required", "reason": reason}
    if _valid_registry(driver_value) and _valid_registry(builtins_value) and driver_value is not builtins_value:
        reason = "Smart Rig Suite ownership slots disagree; in-process registration was refused"
        _mark_restart_required(reason)
        return {"status": "restart_required", "reason": reason}

    if _valid_registry(registry):
        active = registry.get("active")
        if isinstance(active, dict):
            control = active.get("control_module")
            try:
                live = control.live_resource_summary(active) if control is not None else {"unknown": 1}
            except Exception:
                live = {"unknown": 1}
            if any(live.values()):
                active_revision = str(active.get("revision") or "")
                if active_revision == CODE_REVISION and active.get("state") == "active":
                    violations = _active_module_contract_violations(active)
                    if not violations:
                        return {"status": "already_active", "active": active, "control": control}
                    reason = (
                        "a live Smart Rig Suite generation lost its retained child-module identity; "
                        "new module identities were not adopted or registered"
                    )
                    _mark_restart_required(reason)
                    return {
                        "status": "restart_required",
                        "reason": reason,
                        "module_contract_violations": violations,
                    }
                reason = (
                    f"live generation {active_revision or 'unknown'} still owns Blender resources; "
                    f"2.1.12 was not mixed into the process"
                )
                _mark_restart_required(reason)
                return {"status": "restart_required", "reason": reason}

    mismatches = _loaded_revision_mismatches()
    if mismatches:
        clean, evidence = _runtime_is_proven_clean()
        proven, proof = _clean_shutdown_proves_loaded_modules(registry, mismatches)
        if not clean or not proven:
            reason = (
                "loaded child-module revisions do not match 2.1.12, and complete exact-identity "
                "unregistration was not proven; the update will be applied after Blender restarts"
            )
            _mark_restart_required(reason)
            return {
                "status": "restart_required",
                "reason": reason,
                "mismatches": mismatches,
                "runtime_evidence": evidence,
                "unregistration_proof": proof,
            }
        _discard_clean_old_modules()

    # A same-revision foreign/re-imported class without registry ownership is
    # equally unsafe and must not be adopted by RNA identifier alone.
    clean, evidence = _runtime_is_proven_clean()
    if not clean:
        reason = "unowned Smart Rig Suite RNA/resources are live; a clean Blender restart is required"
        _mark_restart_required(reason)
        return {"status": "restart_required", "reason": reason, "evidence": evidence}
    return {"status": "ready"}


def _stable_import(name: str) -> Any:
    """Import one child only when its revision contract matches the root."""
    full_name = f"{_PACKAGE_NAME}.{name}"
    loaded = sys.modules.get(full_name)
    if loaded is not None:
        loaded_revision = str(getattr(loaded, "__srs_revision__", "") or "")
        if loaded_revision != CODE_REVISION:
            raise RuntimeError(
                f"child module {full_name} revision {loaded_revision or 'missing'} does not match {CODE_REVISION}"
            )
        return loaded
    module = importlib.import_module(f".{name}", _PACKAGE_NAME)
    loaded_revision = str(getattr(module, "__srs_revision__", "") or "")
    if loaded_revision != CODE_REVISION:
        raise RuntimeError(
            f"imported child module {full_name} revision {loaded_revision or 'missing'} does not match {CODE_REVISION}"
        )
    return module


def _bind_loaded_modules(control: Any, modules: dict[str, Any]) -> None:
    """Bind every imported child module, not only modules exposing register()."""
    for name in _IMPORT_ORDER:
        module = modules[name]
        marker = getattr(module, "__srs_module_generation_marker__", None)
        if marker is None:
            raise RuntimeError(f"module {_PACKAGE_NAME}.{name} has no execution identity marker")
        control.bind_module(module.__name__, module, CODE_REVISION, marker)


def _merge_ui_reports(first: dict[str, Any], second: dict[str, Any] | None) -> dict[str, Any]:
    if not second:
        return first
    results = list(first.get("results", ())) + list(second.get("results", ()))
    remaining = list(second.get("remaining", ()))
    errors = list(first.get("errors", ())) + list(second.get("errors", ()))
    errors.extend(error for item in results for error in item.get("errors", ()))
    return {
        "results": results,
        "removed": sum(item.get("status") == "removed" for item in results),
        "absent": sum(item.get("status") == "absent" for item in results),
        "identity_mismatches": sum(item.get("status") == "identity_mismatch" for item in results),
        "errors": errors,
        "remaining": remaining,
        "all_removed": not remaining,
    }


def _teardown_generation(
    control: Any,
    token: str,
    *,
    registration_failure: bool = False,
    status_runtime: Any | None = None,
) -> dict[str, Any]:
    """Two-phase, exception-isolated teardown with UI dependency protection."""
    reports: list[dict[str, Any]] = []
    try:
        control.set_generation_state(token, "unregistering")
    except Exception:
        pass

    # Phase 1: establish whether every exact Panel identity is gone. Retry once
    # after redraw to tolerate a transient expanded-panel/ui_handler evaluation.
    try:
        ui_first = control.unregister_class_records(kinds={"Panel"}, attempts=1)
    except Exception as exc:
        ui_first = {
            "results": [],
            "errors": [f"{type(exc).__name__}: {exc}"],
            "remaining": ["Panel teardown call failed"],
            "all_removed": False,
        }
    ui_retry = None
    if not ui_first.get("all_removed"):
        _redraw_view3d()
        try:
            ui_retry = control.unregister_class_records(kinds={"Panel"}, attempts=1)
        except Exception as exc:
            ui_retry = {
                "results": [],
                "errors": [f"{type(exc).__name__}: {exc}"],
                "remaining": ["Panel retry failed"],
                "all_removed": False,
            }
    ui_report = _merge_ui_reports(ui_first, ui_retry)
    reports.append(ui_report)
    panel_removed = bool(ui_report.get("all_removed"))

    # Optional status integration is restored only after the UI result is known.
    # Its failure is aggregated, never allowed to interrupt owned-resource cleanup.
    status_results = []
    status_errors = []
    if status_runtime is not None:
        for function_name, args in (
            ("restore_package_handlers", ("smart_rig_suite",)),
            ("clear_prefix", ("smart_rig_suite",)),
        ):
            try:
                function = getattr(status_runtime, function_name, None)
                if callable(function):
                    function(*args)
                status_results.append({"function": function_name, "status": "completed"})
            except Exception as exc:
                error = f"{function_name}: {type(exc).__name__}: {exc}"
                status_errors.append(error)
                status_results.append({"function": function_name, "status": "error", "error": error})
    status_report = {
        "results": status_results,
        "errors": status_errors,
        "remaining": [],
        "all_removed": True,
        "optional": True,
    }
    reports.append(status_report)

    # Phase 2a: non-UI runtime resources are always released, even when a Panel
    # remains. Every resource failure is isolated inside the registry controller.
    try:
        resource_report = control.cleanup_non_ui_resources(token=token)
    except Exception as exc:
        resource_report = {
            "results": [],
            "errors": [f"{type(exc).__name__}: {exc}"],
            "remaining": ["resource cleanup call failed"],
            "all_removed": False,
        }
    reports.append(resource_report)

    pointer_report: dict[str, Any]
    class_report: dict[str, Any]
    if not panel_removed:
        # A stale Panel may still execute draw/poll. Preserve all RNA it can touch,
        # especially Scene.srs_settings and its PropertyGroup identity.
        pointer_report = {
            "protected": True,
            "all_removed": False,
            "errors": [],
            "remaining": ["Scene.srs_settings protected by live Panel"],
        }
        class_report = {
            "protected": True,
            "all_removed": False,
            "errors": [],
            "remaining": ["Panel dependencies protected"],
        }
        reports.extend((pointer_report, class_report))
    else:
        try:
            pointer_report = control.unregister_pointer_records()
        except Exception as exc:
            pointer_report = {
                "all_removed": False,
                "errors": [f"{type(exc).__name__}: {exc}"],
                "remaining": ["PointerProperty teardown call failed"],
            }
        reports.append(pointer_report)

        kinds = {
            "Operator",
            "AddonPreferences",
            "Menu",
            "UIList",
            "Gizmo",
            "GizmoGroup",
            "RNAClass",
        }
        if pointer_report.get("all_removed"):
            kinds.add("PropertyGroup")
        try:
            class_report = control.unregister_class_records(kinds=kinds, attempts=2)
        except Exception as exc:
            class_report = {
                "all_removed": False,
                "errors": [f"{type(exc).__name__}: {exc}"],
                "remaining": ["dependent RNA teardown call failed"],
            }
        reports.append(class_report)

    try:
        final = control.finalize_unregistration(token, reports=reports)
    except Exception as exc:
        final = {
            "finalized": False,
            "restart_required": True,
            "reason": f"finalization failed: {type(exc).__name__}: {exc}",
        }
        _mark_restart_required(final["reason"])

    return {
        "registration_failure": bool(registration_failure),
        "token": token,
        "ui": ui_report,
        "panel_removed": panel_removed,
        "status_runtime": status_report,
        "resources": resource_report,
        "pointer_properties": pointer_report,
        "classes": class_report,
        "final": final,
        "errors": [error for report in reports for error in report.get("errors", ())],
    }


def _restore_module_list_from_active(active: dict[str, Any]) -> None:
    records = active.get("modules", {}) if isinstance(active, dict) else {}
    restored = []
    for short_name in _MODULE_NAMES:
        full_name = f"{_PACKAGE_NAME}.{short_name}"
        record = records.get(full_name) if isinstance(records, dict) else None
        module = record.get("module") if isinstance(record, dict) else None
        if module is not None:
            restored.append(module)
    _MODULES[:] = restored


def _core_register() -> dict[str, Any]:
    global _REGISTERED, _RESTART_REQUIRED_REASON
    preflight = _revision_preflight()
    if preflight.get("status") == "already_active":
        _REGISTERED = True
        _RESTART_REQUIRED_REASON = ""
        active = preflight.get("active")
        if isinstance(active, dict):
            _restore_module_list_from_active(active)
        return {"registered": True, "adopted_existing_generation": True, "preflight": preflight}
    if preflight.get("status") != "ready":
        _REGISTERED = False
        return {"registered": False, "restart_required": True, "preflight": preflight}

    control = None
    token = ""
    modules: dict[str, Any] = {}
    try:
        # Import only after all old-revision and foreign-RNA gates pass.
        for name in _IMPORT_ORDER:
            modules[name] = _stable_import(name)
        control = modules["generation"]
        begin = control.begin_generation(_PACKAGE_NAME, CODE_REVISION, control_module=control)
        if begin.get("status") == "already_active":
            _REGISTERED = True
            return {"registered": True, "adopted_existing_generation": True, "begin": begin}
        if begin.get("status") != "started":
            reason = str(begin.get("reason") or "another generation remains live")
            _mark_restart_required(reason)
            _REGISTERED = False
            return {"registered": False, "restart_required": True, "begin": begin}
        token = str(begin.get("token") or "")
        _bind_loaded_modules(control, modules)

        migration = modules["legacy_cleanup"].run_migration_once(
            _PACKAGE_NAME,
            _PACKAGE_DIR,
            revision=CODE_REVISION,
        )
        if bool(migration.get("restart_required")):
            reason = str(migration.get("reason") or "legacy Smart Rig Suite RNA remains live")
            control.set_generation_state(token, "blocked", reason=reason)
            control.mark_restart_required(reason, revision=CODE_REVISION)
            _REGISTERED = False
            return {
                "registered": False,
                "restart_required": True,
                "migration": migration,
                "token": token,
            }

        started_modules = []
        for name in _MODULE_NAMES:
            module = modules[name]
            register_fn = getattr(module, "register", None)
            if callable(register_fn):
                register_fn()
            started_modules.append(module)
        control.finish_generation(token)
        _MODULES[:] = started_modules
        _REGISTERED = True
        _RESTART_REQUIRED_REASON = ""
        _redraw_view3d()
        return {
            "registered": True,
            "token": token,
            "module_count": len(started_modules),
            "migration": migration,
        }
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
        teardown = None
        if control is not None and token:
            teardown = _teardown_generation(control, token, registration_failure=True)
            if not teardown.get("final", {}).get("finalized"):
                _mark_restart_required(teardown.get("final", {}).get("reason") or error)
        _MODULES.clear()
        _REGISTERED = False
        return {
            "registered": False,
            "restart_required": bool(_RESTART_REQUIRED_REASON),
            "error": error,
            "teardown": teardown,
        }


def _control_for_cleanup() -> tuple[Any | None, dict[str, Any] | None]:
    registry = _raw_registry(for_cleanup=True, create=False)
    active = registry.get("active") if _valid_registry(registry) else None
    if isinstance(active, dict):
        control = active.get("control_module")
        if control is not None:
            return control, active
    loaded = sys.modules.get(f"{_PACKAGE_NAME}.generation")
    if loaded is not None and str(getattr(loaded, "__srs_revision__", "")) == CODE_REVISION:
        try:
            active = loaded.active_generation(for_cleanup=True)
        except Exception:
            active = None
        return loaded, active
    return None, None


def _core_unregister(*, status_runtime: Any | None = None) -> dict[str, Any]:
    global _REGISTERED
    control, active = _control_for_cleanup()
    if control is None or not isinstance(active, dict):
        _MODULES.clear()
        _REGISTERED = False
        _redraw_view3d()
        return {"unregistered": True, "nothing_owned": True, "errors": []}

    token = str(active.get("token") or "")
    report = _teardown_generation(control, token, status_runtime=status_runtime)
    finalized = bool(report.get("final", {}).get("finalized"))
    if finalized:
        for module_record in tuple(active.get("modules", {}).values()):
            module = module_record.get("module") if isinstance(module_record, dict) else None
            try:
                if module is not None:
                    setattr(module, "_REGISTERED", False)
            except Exception:
                pass
        _MODULES.clear()
    else:
        _mark_restart_required(report.get("final", {}).get("reason") or "Smart Rig Suite teardown was incomplete")
    _REGISTERED = False
    _redraw_view3d()
    report["unregistered"] = finalized
    return report


def _optional_status_runtime(*, import_for_register: bool) -> Any | None:
    full_name = f"{_PACKAGE_NAME}.{_OPTIONAL_STATUS_MODULE}"
    module = sys.modules.get(full_name)
    if module is None and import_for_register:
        try:
            module = _stable_import(_OPTIONAL_STATUS_MODULE)
        except Exception:
            return None
    if module is None or str(getattr(module, "__srs_revision__", "")) != CODE_REVISION:
        return None
    return module


def register() -> None:
    """Enable the extension without allowing lifecycle exceptions to escape."""
    global _LAST_REGISTER_STATUS, _REGISTERED
    try:
        status = _core_register()
    except Exception as exc:
        _REGISTERED = False
        reason = f"registration preflight failed safely: {type(exc).__name__}: {exc}"
        _mark_restart_required(reason)
        status = {"registered": False, "restart_required": True, "error": reason}
    _LAST_REGISTER_STATUS = status
    if not status.get("registered"):
        return
    runtime = _optional_status_runtime(import_for_register=True)
    if runtime is None:
        return
    try:
        control, active = _control_for_cleanup()
        if control is None or not isinstance(active, dict):
            return
        marker = getattr(runtime, "__srs_module_generation_marker__", None)
        if marker is None:
            return
        control.bind_module(runtime.__name__, runtime, CODE_REVISION, marker)
    except Exception:
        # Status instrumentation is optional. A failed status-module identity
        # bind must not mutate or replace core RNA/resources.
        return
    for function_name, args in (
        (
            "instrument_loaded_package_operators",
            ("smart_rig_suite", "smart_rig_suite", "Smart Rig Suite"),
        ),
        (
            "instrument_loaded_package_handlers",
            ("smart_rig_suite", "smart_rig_suite", "Smart Rig Suite"),
        ),
    ):
        try:
            function = getattr(runtime, function_name, None)
            if callable(function):
                function(*args)
        except Exception:
            # Status-bar instrumentation is optional and never owns core RNA.
            pass


def unregister() -> None:
    """Disable in two phases; no lifecycle exception is allowed to escape."""
    global _LAST_UNREGISTER_REPORT, _REGISTERED
    runtime = _optional_status_runtime(import_for_register=False)
    try:
        report = _core_unregister(status_runtime=runtime)
    except Exception as exc:
        _REGISTERED = False
        reason = f"unregistration failed safely: {type(exc).__name__}: {exc}"
        _mark_restart_required(reason)
        report = {
            "unregistered": False,
            "errors": [reason],
            "final": {"finalized": False, "restart_required": True, "reason": reason},
        }
        _redraw_view3d()
    _LAST_UNREGISTER_REPORT = report


if __name__ == "__main__":
    register()

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
