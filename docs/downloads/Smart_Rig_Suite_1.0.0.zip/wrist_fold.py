# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Stop the wrist crushing when it is bent hard.

Auto-Rig Pro gives the knee and the elbow a whole apparatus -- two bend
controllers per side plus front and back fans -- and gives the wrist exactly one
bone, ``c_wrist_bend``, with no drivers on it at all. Up to a point that is
enough. Measured on the reference character, the skin around the wrist is
untouched out to 50 degrees of flexion or extension and 30 degrees of deviation:
the worst angle between neighbouring faces stays at 102.48 degrees, which is
what it already is at rest. Past that it falls off a cliff -- 60 degrees gives
142.6, 70 degrees gives 173.8, which is two faces folded flat onto each other.

A cliff is not a weight problem. Two remedies were measured on the real
character and neither worked:

    sharing the hand's rotation onto ``c_wrist_bend`` with a Copy Rotation
    constraint made it monotonically WORSE (18 bad edges at rest strength, 21 at
    0.2, 33 at 0.8) and wrecked the twist as well, because the forearm twist
    bone already carries that

    smoothing the weights in a ball around the joint -- the treatment that works
    at the knee -- moved 18 bad edges to 16 at best and left a 162 degree fold

What it is, is the fold crushing: the same failure the knee has past 90 degrees,
where the two sides of the crease meet and have nowhere to go. The knee is
treated by sliding its two sides apart, and this is that treatment for a joint
that has only one bone to slide.

``c_wrist_bend`` is pushed out of the crease, by an amount that is zero until the
joint is already past the angle where it still behaves, so nothing about the
usable range changes. Measured on the reference character:

    flexion   11 bad edges / 142.57 worst  ->  5 / 88.62
    extension 17 bad edges / 146.83 worst  ->  9 / 107.55

Both of those land under the rest-pose worst of 102.48 or close to it, and the
flexion count lands under the rest-pose count of 7.

The direction is not a hand-tuned pair of numbers per side. Picking bone-local
axes by trial gave answers that did not mirror -- the left wrist wanted +X for
extension and the right wanted -X -- which is the signature of fitting noise
rather than finding a direction. It is derived from the hand's own shape
instead: the palm's normal, from the hand's long axis crossed with the line
across the knuckles, with the thumb deciding which way is dorsal. Expressed that
way the two sides came out byte-identical (8 bad edges / 91.21 on both), which is
what a real direction does and a fitted one does not.

The offset is driven by the flexion angle read off the ``hand`` bone in local
space. That reading was checked against the pose it reports, and it is exact --
40 degrees reads 40.00, -60 reads -60.00 -- and, importantly, it reads 0.00 for
deviation and 0.00 for twist, so this never fires on a rotation it was not
measured for.
"""

import math

import bpy
from mathutils import Vector

SIDES = (".l", ".r")
MARK = "SRS wrist fold"
STATE_KEY = "srs_wrist_fold_v1"

# Millimetres along (palm normal, hand long axis), from the measured optimum.
FLEX_N_MM = -16.0
FLEX_U_MM = -4.0
EXT_N_MM = 8.0
EXT_U_MM = -4.0
# The joint is clean out to 50 degrees, so ONSET is 50 exactly and the usable
# range is bit-for-bit untouched -- at 45 the correction had already started and
# cost the worst edge at 50 degrees of extension 2.03 degrees for nothing.
# Full strength by FULL; beyond LIMIT the curve simply holds.
ONSET_DEG = 50.0
FULL_DEG = 60.0
LIMIT_DEG = 70.0


def _bones(armature, side):
    need = ("hand{s}", "c_wrist_bend{s}", "c_pinky1_base{s}",
            "c_index1_base{s}", "thumb1{s}")
    names = [n.format(s=side) for n in need]
    missing = [n for n in names if n not in armature.data.bones]
    return names, missing


def axes(armature, side):
    """``(palm_normal, hand_axis, error)`` in ``c_wrist_bend``'s local space.

    Both come from the rest pose, so the two sides mirror without anything being
    told which side it is on.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, None, "No armature"
    names, missing = _bones(armature, side)
    if missing:
        return None, None, "Missing bones: %s" % ", ".join(missing)
    hand, wrist_bend, pinky, index, thumb = names
    bones = armature.data.bones
    mw = armature.matrix_world
    joint = mw @ bones[hand].head_local
    u = (mw @ bones[hand].tail_local - joint)
    across = (mw @ bones[pinky].head_local) - (mw @ bones[index].head_local)
    if u.length < 1e-6 or across.length < 1e-6:
        return None, None, "Degenerate hand"
    u = u.normalized()
    n = u.cross(across.normalized())
    if n.length < 1e-6:
        return None, None, "The knuckles line up with the hand axis"
    n = n.normalized()
    # The thumb sits on the palm side, so it decides the sign without anyone
    # having to know which hand this is.
    if ((mw @ bones[thumb].head_local) - joint).dot(n) > 0:
        n = -n
    inverse = (mw @ bones[wrist_bend].matrix_local).to_3x3().inverted()
    return (inverse @ n).normalized(), (inverse @ u).normalized(), ""


def _profile(n_local, u_local, flex_n, flex_u, ext_n, ext_u,
             onset, full, limit):
    """Per component, the (angle_rad, metres) points of the driver curve."""
    def blend(n_mm, u_mm):
        return n_local * (n_mm * 0.001) + u_local * (u_mm * 0.001)

    ext = blend(ext_n, ext_u)
    flex = blend(flex_n, flex_u)
    zero = Vector((0.0, 0.0, 0.0))
    stops = ((-limit, ext), (-full, ext), (-onset, zero),
             (onset, zero), (full, flex), (limit, flex))
    return [[(math.radians(a), v[i]) for a, v in stops] for i in range(3)]


def remove(armature, sides=SIDES):
    """Take the drivers off and put the bone back where it was."""
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    cleared = []
    for side in sides:
        pose_bone = armature.pose.bones.get("c_wrist_bend" + side)
        if pose_bone is None:
            continue
        for index in range(3):
            try:
                pose_bone.driver_remove("location", index)
            except (RuntimeError, TypeError):
                pass
        pose_bone.location = (0.0, 0.0, 0.0)
        cleared.append(pose_bone.name)
    if armature.data.get(STATE_KEY) is not None:
        del armature.data[STATE_KEY]
    return {"cleared": cleared}, ""


def install(armature, sides=SIDES, flex_n_mm=FLEX_N_MM, flex_u_mm=FLEX_U_MM,
            ext_n_mm=EXT_N_MM, ext_u_mm=EXT_U_MM, onset_deg=ONSET_DEG,
            full_deg=FULL_DEG, limit_deg=LIMIT_DEG):
    """Drive ``c_wrist_bend`` out of the crease past ``onset_deg``.

    Returns ``(report, error)``. Re-running replaces what was there, so this is
    safe to repeat -- unlike weight smoothing, nothing here is cumulative.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if not (0.0 < onset_deg < full_deg <= limit_deg):
        return None, "Angles must be 0 < onset < full <= limit"
    report = {"sides": [], "onset_deg": onset_deg, "full_deg": full_deg}
    done = False
    for side in sides:
        n_local, u_local, error = axes(armature, side)
        if error:
            report["sides"].append({"side": side, "error": error})
            continue
        pose_bone = armature.pose.bones["c_wrist_bend" + side]
        for index in range(3):
            try:
                pose_bone.driver_remove("location", index)
            except (RuntimeError, TypeError):
                pass
        pose_bone.location = (0.0, 0.0, 0.0)
        curves = _profile(n_local, u_local, flex_n_mm, flex_u_mm,
                          ext_n_mm, ext_u_mm, onset_deg, full_deg, limit_deg)
        for index, points in enumerate(curves):
            fcurve = pose_bone.driver_add("location", index)
            driver = fcurve.driver
            # One variable and AVERAGE, so the curve maps the angle straight to
            # the offset. This is the same shape Auto-Rig Pro uses on the knee.
            driver.type = "AVERAGE"
            for existing in list(driver.variables):
                driver.variables.remove(existing)
            variable = driver.variables.new()
            variable.name = "flex"
            variable.type = "TRANSFORMS"
            target = variable.targets[0]
            target.id = armature
            target.bone_target = "hand" + side
            target.transform_type = "ROT_X"
            target.transform_space = "LOCAL_SPACE"
            target.rotation_mode = "AUTO"
            # A channel that has just been driver_add-ed carries a generator
            # modifier, and a modifier BEATS the keyframes: leaving it on gives a
            # curve that looks right in the editor and drives a straight line.
            for modifier in list(fcurve.modifiers):
                fcurve.modifiers.remove(modifier)
            while len(fcurve.keyframe_points):
                fcurve.keyframe_points.remove(fcurve.keyframe_points[-1])
            for x, y in points:
                key = fcurve.keyframe_points.insert(x, y)
                key.interpolation = "LINEAR"
            fcurve.extrapolation = "CONSTANT"
            fcurve.update()
        report["sides"].append({
            "side": side, "bone": pose_bone.name,
            "palm_normal": [round(v, 4) for v in n_local],
            "hand_axis": [round(v, 4) for v in u_local]})
        done = True
    if not done:
        return report, "Neither wrist carries the bones this needs"
    armature.data[STATE_KEY] = {
        "flex_mm": [flex_n_mm, flex_u_mm], "ext_mm": [ext_n_mm, ext_u_mm],
        "onset_deg": onset_deg, "full_deg": full_deg, "limit_deg": limit_deg}
    return report, ""


def verify(armature, mesh, sides=SIDES, radius_mm=55.0,
           angles=(50.0, 60.0, 70.0)):
    """Measure the surface either side of the treatment. ``(report, error)``.

    Deviation and twist are measured too, because the failure this fixes is
    specific to flexion and a correction that quietly damaged the other two
    would not otherwise show up.
    """
    from . import face_regions

    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if mesh is None or mesh.type != "MESH":
        return None, "Select the deformed mesh"
    rows = {}
    mw = armature.matrix_world
    mm = mesh.matrix_world
    for side in sides:
        hand = armature.data.bones.get("hand" + side)
        control = "c_hand_ik" + side
        if hand is None or control not in armature.pose.bones:
            rows[side] = {"error": "No hand on this side"}
            continue
        centre = mw @ hand.head_local
        radius = max(radius_mm, 1.0) * 0.001
        scope = [v.index for v in mesh.data.vertices
                 if ((mm @ v.co) - centre).length <= radius]
        if not scope:
            rows[side] = {"error": "No vertex near this wrist"}
            continue
        side_rows = {}
        probes = []
        for angle in angles:
            probes.append(("flex +%g" % angle, (angle, 0.0, 0.0)))
            probes.append(("ext -%g" % angle, (-angle, 0.0, 0.0)))
        probes.append(("ulnar +30", (0.0, 0.0, 30.0)))
        probes.append(("radial -20", (0.0, 0.0, -20.0)))
        probes.append(("twist +80", (0.0, 80.0, 0.0)))
        for tag, rotation in probes:
            quality, error = face_regions.surface_quality(
                mesh, scope, armature, poses=[(control, {"rotation": rotation})])
            if error:
                side_rows[tag] = {"error": error}
                continue
            side_rows[tag] = {"over_70": quality["posed"]["over_70"],
                              "max": round(quality["posed"]["max"], 2),
                              "rest_over_70": quality["rest"]["over_70"],
                              "rest_max": round(quality["rest"]["max"], 2)}
        rows[side] = side_rows
    good = [r for side in rows.values() if isinstance(side, dict)
            for r in side.values() if isinstance(r, dict) and "max" in r]
    if not good:
        return None, "Neither wrist could be measured. Check the hand bones and that the mesh reaches the wrists"
    return {"sides": rows,
            "worst_over_70": max((r["over_70"] for r in good), default=None),
            "worst_max": max((r["max"] for r in good), default=None),
            "installed": armature.data.get(STATE_KEY) is not None}, ""
