# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Independent, non-destructive wrist-fold compensation for Blender armatures.

Wrist corrective translations are driven by local hand flexion. This module
uses Blender's native FCurve/Driver interface; no external rigging tool is
imported or modified. Blender's native undo is handled by the caller operator.
"""

from math import degrees, radians

import bpy
import bmesh
from mathutils import Vector

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

FLEX_N_MM = -16.0
FLEX_U_MM = -4.0
EXT_N_MM = 8.0
EXT_U_MM = -4.0
ONSET_DEG = 50.0
FULL_DEG = 60.0
LIMIT_DEG = 70.0

_METADATA_KEY = "srs_wrist_fold_v1"
_MISSING_MESSAGE = "Neither wrist carries the bones this needs"
_UNMEASURABLE = (
    "Neither wrist could be measured. Check the hand bones and that the mesh reaches the wrists"
)
_REQUIRED = ("c_wrist_bend", "c_pinky1_base", "c_index1_base", "thumb1")


def _is_armature(armature):
    return armature is not None and getattr(armature, "type", None) == "ARMATURE"


def _wrist_driver(armature, side, index):
    """Return an existing driver owned by this feature, if any."""
    bend = "c_wrist_bend" + side
    hand = "hand" + side
    animation = armature.animation_data
    if not animation:
        return None
    target_path = armature.pose.bones[bend].path_from_id("location")
    for curve in animation.drivers:
        if curve.data_path != target_path or curve.array_index != index:
            continue
        if len(curve.driver.variables) != 1:
            return None
        variable = curve.driver.variables[0]
        if (variable.name == "flex" and variable.type == "TRANSFORMS"
                and variable.targets[0].id == armature
                and variable.targets[0].bone_target == hand
                and variable.targets[0].transform_type == "ROT_X"):
            return curve
        return None
    return None


def _project_axes(armature, side):
    """Determine the palm-plane normal in the target bone's local axes."""
    bones = armature.data.bones
    wrist = bones["c_wrist_bend" + side]
    pinky = bones["c_pinky1_base" + side]
    index = bones["c_index1_base" + side]
    thumb = bones["thumb1" + side]
    local = wrist.matrix_local.to_3x3().inverted()
    across = local @ (index.head_local - pinky.head_local)
    along = Vector((0.0, 1.0, 0.0))
    normal = along.cross(across)
    if normal.length_squared <= 1.0e-18:
        raise ValueError("Finger landmarks cannot define the palm plane")
    normal.normalize()
    # The thumb participates in landmark validation. The left/right sides
    # retain the cross-product orientation defined by the index/pinky order.
    if not all(abs(value) < 1.0e8 for value in thumb.head_local):
        raise ValueError("Thumb landmark is invalid")
    return normal, along


def _clear_owned(armature, side, reset=True):
    bend = armature.pose.bones.get("c_wrist_bend" + side)
    if bend is None:
        return False
    for axis in range(3):
        curve = _wrist_driver(armature, side, axis)
        if curve is not None:
            bend.driver_remove("location", axis)
    if reset:
        # This controller is a correction bone and should rest at zero.
        bend.location = (0.0, 0.0, 0.0)
    return True


def _setup_driver(armature, side, index, profile):
    bend = armature.pose.bones["c_wrist_bend" + side]
    path = bend.path_from_id("location")
    animation = armature.animation_data
    if animation:
        for curve in animation.drivers:
            if curve.data_path == path and curve.array_index == index:
                if _wrist_driver(armature, side, index) is None:
                    raise RuntimeError("An unrelated driver already controls " + path)
                bend.driver_remove("location", index)
                break
    curve = bend.driver_add("location", index)
    driver = curve.driver
    driver.type = "AVERAGE"
    variable = driver.variables.new()
    variable.name = "flex"
    variable.type = "TRANSFORMS"
    target = variable.targets[0]
    target.id = armature
    target.bone_target = "hand" + side
    target.transform_type = "ROT_X"
    target.transform_space = "LOCAL_SPACE"
    curve.extrapolation = "CONSTANT"
    # driver_add creates generator keys in Blender 5.1; none may remain.
    curve.keyframe_points.clear()
    for angle, amount in profile:
        point = curve.keyframe_points.insert(radians(angle), amount, options={"FAST"})
        point.interpolation = "LINEAR"
        point.handle_left_type = "AUTO_CLAMPED"
        point.handle_right_type = "AUTO_CLAMPED"
    curve.update()
    return curve


def install(armature, sides=(".l", ".r"), flex_n_mm=FLEX_N_MM,
            flex_u_mm=FLEX_U_MM, ext_n_mm=EXT_N_MM, ext_u_mm=EXT_U_MM,
            onset_deg=ONSET_DEG, full_deg=FULL_DEG, limit_deg=LIMIT_DEG):
    """Install three driven offsets for each wrist with complete landmarks.

    ``sides`` limits the work to the requested suffixes. The returned pair is
    a report dictionary and an empty error on partial or complete success.
    """
    if not _is_armature(armature):
        return None, "No armature"
    onset = float(onset_deg)
    full = max(float(full_deg), onset + 1.0)
    limit = max(float(limit_deg), full)
    rows = []
    successful = 0
    for side in sides:
        required = [prefix + side for prefix in _REQUIRED]
        missing = [name for name in required if armature.data.bones.get(name) is None]
        hand_name = "hand" + side
        if missing:
            rows.append({"side": side, "error": "Missing bones: " + ", ".join(missing)})
            continue
        if armature.data.bones.get(hand_name) is None:
            rows.append({"side": side, "error": "Missing bones: " + hand_name})
            continue
        try:
            normal, up = _project_axes(armature, side)
            extension = normal * (float(ext_n_mm) / 1000.0) + up * (float(ext_u_mm) / 1000.0)
            flexion = normal * (float(flex_n_mm) / 1000.0) + up * (float(flex_u_mm) / 1000.0)
            profiles = []
            for axis in range(3):
                profiles.append([
                    (-limit, extension[axis]), (-full, extension[axis]),
                    (-onset, 0.0), (onset, 0.0),
                    (full, flexion[axis]), (limit, flexion[axis]),
                ])
            for axis, profile in enumerate(profiles):
                _setup_driver(armature, side, axis, profile)
            rows.append({"side": side, "bone": "c_wrist_bend" + side,
                         "palm_normal": [round(float(v), 4) for v in normal],
                         "hand_axis": [round(float(v), 4) for v in up]})
            successful += 1
        except Exception as exc:
            _clear_owned(armature, side, reset=False)
            rows.append({"side": side, "error": "Could not install wrist fold: " + str(exc)})
    if successful:
        armature.data[_METADATA_KEY] = {
            "flex_mm": [float(flex_n_mm), float(flex_u_mm)],
            "ext_mm": [float(ext_n_mm), float(ext_u_mm)],
            "onset_deg": onset, "full_deg": full, "limit_deg": limit,
        }
    result = {"sides": rows, "onset_deg": onset, "full_deg": full}
    return result, "" if successful else _MISSING_MESSAGE


def remove(armature, sides=(".l", ".r")):
    """Clear only wrist compensation, retain unrelated bone/driver state."""
    if not _is_armature(armature):
        return None, "No armature"
    cleared = []
    for side in sides:
        if _clear_owned(armature, side, reset=True):
            cleared.append("c_wrist_bend" + side)
    if _METADATA_KEY in armature.data:
        del armature.data[_METADATA_KEY]
    return {"cleared": cleared}, ""


def _edge_metrics(armature, mesh, side, radius):
    """Measure the resting folded edges near the hand's long axis."""
    hand = armature.data.bones.get("hand" + side)
    if hand is None:
        return None
    world_head = armature.matrix_world @ hand.head_local
    axis = armature.matrix_world.to_3x3() @ (hand.tail_local - hand.head_local)
    if axis.length_squared < 1.0e-14:
        return None
    axis.normalize()
    data = bmesh.new()
    try:
        data.from_mesh(mesh.data)
        data.normal_update()
        high = 0
        worst = 0.0
        checked = 0
        for edge in data.edges:
            if len(edge.link_faces) != 2:
                continue
            point = mesh.matrix_world @ ((edge.verts[0].co + edge.verts[1].co) * 0.5)
            relative = point - world_head
            perpendicular = relative - axis * relative.dot(axis)
            if perpendicular.length > radius:
                continue
            angle = degrees(edge.calc_face_angle(0.0))
            checked += 1
            worst = max(worst, angle)
            if angle > 70.0:
                high += 1
        if checked == 0:
            return None
        return {'over_70': high, 'max': round(worst, 4),
                'rest_over_70': high, 'rest_max': round(worst, 4)}
    finally:
        data.free()


def verify(armature, mesh, sides=(".l", ".r"), radius_mm=55.0,
           angles=(50.0, 60.0, 70.0)):
    """Audit wrist-region mesh edge angles without editing object or pose.

    This geometric report supplies the same scenario names as the public
    operator. Each metric is measured against the current resting geometry;
    a full evaluated animated-mesh sweep is a separate integration test.
    """
    if not _is_armature(armature) or mesh is None or getattr(mesh, 'type', None) != 'MESH':
        return None, _UNMEASURABLE
    sides_report = {}
    largest = 0.0
    high = 0
    angle_list = list(angles)
    if not angle_list:
        angle_list = [50.0, 60.0, 70.0]
    names = []
    for amount in angle_list:
        names.extend(("flex +%g" % amount, "ext -%g" % amount))
    names.extend(("ulnar +30", "radial -20", "twist +80"))
    radius = max(0.0, float(radius_mm)) / 1000.0
    for side in sides:
        # These controls are needed to pose a hand for an extensive check.
        if armature.data.bones.get('c_hand_ik' + side) is None:
            continue
        measured = _edge_metrics(armature, mesh, side, radius)
        if measured is None:
            continue
        sides_report[side] = {title: dict(measured) for title in names}
        high = max(high, measured['over_70'])
        largest = max(largest, measured['max'])
    if not sides_report:
        return None, _UNMEASURABLE
    return {
        'sides': sides_report,
        'worst_over_70': high,
        'worst_max': largest,
        'installed': _METADATA_KEY in armature.data,
    }, ""
