# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Keep the shoulder down unless the arm is raised above the T-pose.

Motion capture retargeted onto an Auto-Rig Pro rig tends to lift ``c_shoulder``
whenever the source skeleton shrugged even a little, so the shoulders sit high
through the whole take. The rule asked for is simple: the shoulder does not go
above its default (rest) pose unless the upper arm is above its T-pose line, and
then only in proportion to how far the arm went up. Forward/back swing and twist
of the shoulder are left alone.

It is built into the rig, not baked into an Action, so hand-keyed animation obeys
it too:

* one Limit Rotation constraint on each ``c_shoulder``, in local space, limiting
  only the axis that raises it (found from the rest pose, X on Auto-Rig Pro);
* its upper bound is driven by the FK arm's elevation above the T-pose line (the
  horizontal through the shoulder, in the chest's rest frame -- not the arm's rest
  direction, which is below the line on an A-pose rig), read from ``c_arm_fk``'s
  own rotation channels. Reading the channels rather
  than the evaluated bone is what keeps this free of a dependency cycle: the arm
  is carried by the shoulder (Auto-Rig Pro copies the shoulder's location onto
  it), so its evaluated matrix already depends on the limit being computed;
* the driver's F-curve maps that elevation to the allowed lift: zero at and below
  the T-pose line, a soft start over a few degrees, then a fixed ratio;
* the constraint's influence follows the arm's IK/FK switch, so it acts on the FK
  arm (which retargeted motion uses). An IK arm's direction can only be read from
  the evaluated chain -- that is the cycle again -- so on IK the limit stays off.
"""

import math

import bpy

SIDES = (".l", ".r")
CONSTRAINT = "SRS Shoulder Limit"
STATE_KEY = "srs_shoulder_limit_v1"
LIFT_PER_DEGREE = 0.5
SOFT_DEG = 10.0


def _fmt(value):
    text = "%.4f" % value
    return "0" if text in ("0.0000", "-0.0000") else text.rstrip("0").rstrip(".")


def _mul(a, b):
    if a is None or b is None:
        return None
    if a == "1":
        return b
    if b == "1":
        return a
    return "%s*%s" % (a, b)


def _wrap(term):
    return "(%s)" % term if ("+" in term or "-" in term[1:]) else term


def _sum(a, b, negative=False):
    if b is None:
        return a
    if b.startswith("-") and not ("+" in b or "-" in b[1:]):
        # a - (-t) is a + t: keep "--" and "+-" out of the expression
        b, negative = b[1:], not negative
    if a is None:
        return ("-" + _wrap(b)) if negative else b
    return "%s%s%s" % (a, "-" if negative else "+", _wrap(b) if negative else b)


def _rotate(vector, axis, angle):
    """``vector`` (three term strings, None for zero) turned about ``axis`` by ``angle``."""
    x, y, z = vector
    c, s = "cos(%s)" % angle, "sin(%s)" % angle

    def m(term, factor):
        return _mul(_wrap(term) if term is not None else None, factor)

    if axis == "X":
        return (x, _sum(m(y, c), m(z, s), True), _sum(m(y, s), m(z, c)))
    if axis == "Y":
        return (_sum(m(x, c), m(z, s)), y, _sum(m(z, c), m(x, s), True))
    return (_sum(m(x, c), m(y, s), True), _sum(m(x, s), m(y, c)), z)


def _direction_terms(rotation_mode):
    """The arm's Y axis after its own rotation, in the arm's rest frame, as term strings.

    Euler ``'ABC'`` turns about A first, then B, then C. Returns ``(terms, variables)``
    where ``variables`` are ``(name, rna_path_suffix, index)``.
    """
    if rotation_mode == "QUATERNION":
        variables = [("w", "rotation_quaternion", 0), ("x", "rotation_quaternion", 1),
                     ("y", "rotation_quaternion", 2), ("z", "rotation_quaternion", 3)]
        norm = "(w*w+x*x+y*y+z*z)"
        terms = ("2*(x*y-w*z)/" + norm, "(w*w-x*x+y*y-z*z)/" + norm, "2*(y*z+w*x)/" + norm)
        return terms, variables
    if len(rotation_mode) != 3 or set(rotation_mode) != {"X", "Y", "Z"}:
        return None, None
    variables = [("x", "rotation_euler", 0), ("y", "rotation_euler", 1), ("z", "rotation_euler", 2)]
    vector = (None, "1", None)
    for axis in rotation_mode:
        vector = _rotate(vector, axis, axis.lower())
    return vector, variables


def _lift_axis(bone):
    """``(axis, sign)`` of the local rotation that raises ``bone``'s tail (armature +Z)."""
    matrix = bone.matrix_local
    # Turning about local X moves the tail along local Z; about local Z, along -X.
    by_x = matrix.col[2][2]
    by_z = -matrix.col[0][2]
    if abs(by_x) >= abs(by_z):
        return "X", (1.0 if by_x >= 0.0 else -1.0)
    return "Z", (1.0 if by_z >= 0.0 else -1.0)


def _clear_curve(curve):
    for modifier in list(curve.modifiers):
        curve.modifiers.remove(modifier)
    while len(curve.keyframe_points):
        curve.keyframe_points.remove(curve.keyframe_points[-1])


def _remove_side(armature, side):
    pose_bone = armature.pose.bones.get("c_shoulder" + side)
    if pose_bone is None:
        return False
    constraint = pose_bone.constraints.get(CONSTRAINT)
    if constraint is None:
        return False
    for prop in ("max_x", "min_x", "max_z", "min_z", "influence"):
        try:
            constraint.driver_remove(prop)
        except (RuntimeError, TypeError):
            pass
    pose_bone.constraints.remove(constraint)
    return True


def remove(armature, sides=SIDES):
    """Take the limit off both shoulders. The shoulders' own keys are untouched."""
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    cleared = [("c_shoulder" + side) for side in sides if _remove_side(armature, side)]
    if armature.data.get(STATE_KEY) is not None:
        del armature.data[STATE_KEY]
    armature.update_tag()
    bpy.context.view_layer.update()
    return {"cleared": cleared}, ""


def state(armature):
    """What is installed: ``{"sides": [...], "lift_per_degree": ..., "soft_deg": ...}`` or None."""
    if armature is None or armature.type != "ARMATURE":
        return None
    sides = [side for side in SIDES
             if armature.pose.bones.get("c_shoulder" + side) is not None
             and armature.pose.bones["c_shoulder" + side].constraints.get(CONSTRAINT) is not None]
    if not sides:
        return None
    data = armature.data.get(STATE_KEY)
    info = {"sides": sides}
    if data is not None:
        for key in ("lift_per_degree", "soft_deg"):
            if key in data:
                info[key] = float(data[key])
    return info


def install(armature, sides=SIDES, lift_per_degree=LIFT_PER_DEGREE, soft_deg=SOFT_DEG):
    """Limit each ``c_shoulder``'s lift by its FK arm's elevation above the T-pose.

    ``(report, error)``. Re-running replaces what was there. ``lift_per_degree`` is
    how many degrees the shoulder may rise per degree the arm is above its T-pose
    line; ``soft_deg`` is the soft start, so the bound grows from zero without a
    corner and the motion does not jump at the line.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    if not (0.0 <= lift_per_degree <= 2.0) or not (0.0 < soft_deg <= 45.0):
        return None, "Lift per degree must be 0 to 2 and the soft start 0 to 45 degrees"
    report = {"sides": [], "lift_per_degree": lift_per_degree, "soft_deg": soft_deg}
    soft = math.radians(soft_deg)
    done = False
    for side in sides:
        shoulder = armature.pose.bones.get("c_shoulder" + side)
        arm = armature.pose.bones.get("c_arm_fk" + side)
        if shoulder is None or arm is None:
            report["sides"].append({"side": side, "error": "no c_shoulder%s or c_arm_fk%s" % (side, side)})
            continue
        if shoulder.bone in arm.bone.parent_recursive:
            report["sides"].append({"side": side, "error": "c_arm_fk%s hangs from the shoulder" % side})
            continue
        terms, variables = _direction_terms(arm.rotation_mode)
        if terms is None:
            report["sides"].append({"side": side, "error": "c_arm_fk%s uses %s rotation" % (side, arm.rotation_mode)})
            continue
        _remove_side(armature, side)
        rest = arm.bone.matrix_local
        weights = (rest.col[0][2], rest.col[1][2], rest.col[2][2])
        height = None
        for weight, term in zip(weights, terms):
            if term is None or abs(weight) < 1e-4:
                continue
            piece = _mul(_fmt(abs(weight)), _wrap(term))
            height = _sum(height, piece, weight < 0.0)
        # Elevation above the horizontal (the T-pose line) in the chest's rest frame,
        # not above the arm's rest direction: an A-pose rig's rest is below the line.
        rest_elevation = math.asin(max(-1.0, min(1.0, weights[1])))
        expression = "asin(max(-1,min(1,%s)))" % (height or "0")
        axis, sign = _lift_axis(shoulder.bone)
        constraint = shoulder.constraints.new("LIMIT_ROTATION")
        constraint.name = CONSTRAINT
        constraint.owner_space = "LOCAL"
        constraint.use_transform_limit = False
        bound = "max_" if sign > 0.0 else "min_"
        free = "min_" if sign > 0.0 else "max_"
        setattr(constraint, "use_limit_" + axis.lower(), True)
        setattr(constraint, free + axis.lower(), -sign * math.pi)
        setattr(constraint, bound + axis.lower(), 0.0)
        curve = constraint.driver_add(bound + axis.lower())
        driver = curve.driver
        driver.type = "SCRIPTED"
        for existing in list(driver.variables):
            driver.variables.remove(existing)
        for name, path, index in variables:
            variable = driver.variables.new()
            variable.name = name
            variable.type = "SINGLE_PROP"
            variable.targets[0].id = armature
            variable.targets[0].data_path = 'pose.bones["%s"].%s[%d]' % (arm.name, path, index)
        driver.expression = expression
        # The curve maps the elevation (radians above the T-pose line) to the bound:
        # flat zero below the line, a quadratic soft start, then the ratio.
        _clear_curve(curve)
        xs = [-1.0, 0.0, soft * 0.25, soft * 0.5, soft * 0.75, soft, soft + 1.0]
        for x in xs:
            if x <= 0.0:
                y = 0.0
            elif x <= soft:
                y = lift_per_degree * x * x / (2.0 * soft)
            else:
                y = lift_per_degree * (x - soft * 0.5)
            key = curve.keyframe_points.insert(x, sign * y)
            key.interpolation = "LINEAR"
        curve.extrapolation = "LINEAR"
        curve.update()
        switch = armature.pose.bones.get("c_hand_ik" + side)
        follows_switch = switch is not None and "ik_fk_switch" in switch.keys()
        if follows_switch:
            influence = constraint.driver_add("influence")
            idriver = influence.driver
            idriver.type = "AVERAGE"
            for existing in list(idriver.variables):
                idriver.variables.remove(existing)
            variable = idriver.variables.new()
            variable.name = "fk"
            variable.type = "SINGLE_PROP"
            variable.targets[0].id = armature
            variable.targets[0].data_path = 'pose.bones["%s"]["ik_fk_switch"]' % switch.name
            _clear_curve(influence)
            for x, y in ((0.0, 0.0), (1.0, 1.0)):
                key = influence.keyframe_points.insert(x, y)
                key.interpolation = "LINEAR"
            influence.extrapolation = "CONSTANT"
            influence.update()
        report["sides"].append({
            "side": side, "bone": shoulder.name, "arm": arm.name, "axis": axis,
            "sign": int(sign), "rest_elevation_deg": round(math.degrees(rest_elevation), 3),
            "follows_ik_fk": follows_switch, "expression": expression})
        done = True
    if not done:
        return report, "Neither side carries c_shoulder and c_arm_fk the way this needs"
    armature.data[STATE_KEY] = {"lift_per_degree": lift_per_degree, "soft_deg": soft_deg}
    armature.update_tag()
    bpy.context.view_layer.update()
    report["drivers_valid"] = _drivers_valid(armature)
    return report, ""


def _drivers_valid(armature):
    data = armature.animation_data
    if data is None:
        return True
    return all(curve.driver.is_valid for curve in data.drivers
               if CONSTRAINT in (curve.data_path or ""))


def register() -> bool:
    return True


def unregister() -> dict:
    return {}
