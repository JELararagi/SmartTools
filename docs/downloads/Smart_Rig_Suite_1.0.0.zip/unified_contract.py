# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender RNA paths for the Rig Suite's shared sidebar and persistence."""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

CONTRACT_VERSION = 2
EXTENSION_ID = "smart_rig_suite"
CONFIG_FOLDER = "Smart_Rig_Suite"
CONFIG_FILE = f"{CONFIG_FOLDER}.json"
_SETTINGS = "scene.srs_settings"
STATE_SAVE_PATH = f"{_SETTINGS}.n_panel_state_save"
SECTION_OPEN_PATH = f"{_SETTINGS}.ui_section_always_on"
RUNTIME_TOGGLE_PATHS = ("preferences.guard_proxy_picker_context",)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
ROOT_PANEL_IDS = ("SRS_PT_smart_rig",) + tuple(f"{editor}_PT_smart_rig_root" for editor in (
    "IMAGE", "NODE", "SEQUENCER", "CLIP", "DOPESHEET",
    "GRAPH", "NLA", "TEXT", "FILEBROWSER", "SPREADSHEET",
)) + ("FILEBROWSER_PT_smart_rig_asset_root",)
BROWSER_ROOTS = {
    "FILEBROWSER_PT_smart_rig_root": ("UI", ("FILE_BROWSER",)),
    "FILEBROWSER_PT_smart_rig_asset_root": ("TOOL_PROPS", ("ASSET_BROWSER",)),
}
PERSISTENCE_ROOTS = (_SETTINGS, "preferences")
EXCLUDED_TRANSIENT_PATHS = tuple(f"{_SETTINGS}.{name}" for name in (
    "last_status", "last_report_text", "last_preflight_text", "name",
)) + ("preferences.bl_idname",)
BLEND_OWNED_NPANEL_PATHS = (f"{_SETTINGS}.target_armature", f"{_SETTINGS}.target_body_mesh")
