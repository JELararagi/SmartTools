# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Machine-readable SmartTools unified N-panel contract (constants only)."""

CONTRACT_VERSION = 2
EXTENSION_ID = "smart_rig_suite"
CONFIG_FOLDER = "Smart_Rig_Suite"
CONFIG_FILE = "Smart_Rig_Suite.json"
STATE_SAVE_PATH = "scene.srs_settings.n_panel_state_save"
SECTION_OPEN_PATH = "scene.srs_settings.ui_section_always_on"
RUNTIME_TOGGLE_PATHS = (
    "preferences.guard_proxy_picker_context",
)
EXTERNAL_SIDE_EFFECT_RUNTIME_TOGGLE_PATHS = ()
ROOT_PANEL_IDS = (
    "SRS_PT_smart_rig",
    "IMAGE_PT_smart_rig_root",
    "NODE_PT_smart_rig_root",
    "SEQUENCER_PT_smart_rig_root",
    "CLIP_PT_smart_rig_root",
    "DOPESHEET_PT_smart_rig_root",
    "GRAPH_PT_smart_rig_root",
    "NLA_PT_smart_rig_root",
    "TEXT_PT_smart_rig_root",
    "FILEBROWSER_PT_smart_rig_root",
    "SPREADSHEET_PT_smart_rig_root",
    "FILEBROWSER_PT_smart_rig_asset_root",
)
BROWSER_ROOTS = {
    "FILEBROWSER_PT_smart_rig_root": ("UI", ("FILE_BROWSER",)),
    "FILEBROWSER_PT_smart_rig_asset_root": ("TOOL_PROPS", ("ASSET_BROWSER",)),
}
PERSISTENCE_ROOTS = (
    "scene.srs_settings",
    "preferences",
)
EXCLUDED_TRANSIENT_PATHS = (
    "scene.srs_settings.last_status",
    "scene.srs_settings.last_report_text",
    "scene.srs_settings.last_preflight_text",
    "scene.srs_settings.name",
    "preferences.bl_idname",
)
BLEND_OWNED_NPANEL_PATHS = (
    "scene.srs_settings.target_armature",
    "scene.srs_settings.target_body_mesh",
)
