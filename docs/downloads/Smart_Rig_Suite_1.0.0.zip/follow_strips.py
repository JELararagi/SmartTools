# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
"""Strips of additive controllers that follow the garment underneath.

A coat's lower part has to move like the top it covers, or it sinks into it when
the spine bends: on MIK the coat front under the chest sat on one proxy bone while
the top under it blended three spine bones, and a 45 degree forward bend pushed 81
new coat faces through the top (Claude fork 16, 2026-10-03). A Kilt does not help
there -- its columns turn whole about their roots, which is right for a skirt off
the legs and wrong for cloth lying on a torso.

Each strip bone here carries an Armature constraint whose targets and weights are
the weights of the garment underneath at the bone's head (barycentric on the
nearest face), so the bone moves the way the top does at that spot. The bone has
no parent and its own pose is applied before the constraint, so rotating it adds on
top of the body motion -- the per-strip additive animation the coat asked for.

Only the main rig's weights are used. The garment is deformed by two Armature
modifiers in turn (ARP's rig_add, then the rig); a constraint can only blend, and
blending a rig_add helper at rest with a spine bone would halve the spine's motion.
"""

__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

import math

import bpy
from mathutils import Vector, geometry
from mathutils.bvhtree import BVHTree

BONE_COLLECTION = "SRS Follow Strips"
MCH_COLLECTION = "SRS Follow Strips MCH"


def _azimuth(point, centre):
    return math.atan2(point.y - centre.y, point.x - centre.x)


def donor_sampler(donor, armature):
    """A function point -> {bone: weight} reading the donor's main-rig weights on its nearest face (rest)."""
    me = donor.data
    me.calc_loop_triangles()
    mw = donor.matrix_world
    verts = [mw @ v.co for v in me.vertices]
    tris = [tuple(t.vertices) for t in me.loop_triangles]
    tree = BVHTree.FromPolygons(verts, tris)
    deform = {b.name for b in armature.data.bones if b.use_deform}
    names = {g.index: g.name for g in donor.vertex_groups}
    per_vertex = []
    for v in me.vertices:
        per_vertex.append({names[g.group]: g.weight for g in v.groups
                           if names.get(g.group) in deform and g.weight > 0.0})

    def sample(point):
        hit = tree.find_nearest(point)
        if hit[0] is None:
            return {}
        a, b, c = (verts[i] for i in tris[hit[2]])
        bary = geometry.barycentric_transform(hit[0], a, b, c, Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1)))
        out = {}
        for share, vi in zip(bary, tris[hit[2]]):
            row = per_vertex[vi]
            total = sum(row.values())
            if total <= 0.0:
                continue
            for name, w in row.items():
                out[name] = out.get(name, 0.0) + max(0.0, share) * w / total
        total = sum(out.values())
        return {n: w / total for n, w in out.items() if total > 0.0 and w / total > 0.005}
    return sample


def jiggle_aim_prefix():
    from . import jiggle
    return jiggle.AIM_PREFIX


def add_aims(armature, bones=None):
    """Move every goal on a link onto a hidden aim bone the link hangs from. ``(report, error)``.

    For a rig built before 2.62.16: the goal (a Damped Track named "SRS goal ...") re-aimed the link
    after the animator's rotation, so turning a strip by hand did nothing below its top segment.
    The aim bone takes the link's rest, parent and connection; the link hangs from it unconnected
    with no offset, so nothing moves. ``bones`` limits it (default: every link with a goal). Run the
    swing layer again afterwards so swing bones take the aim as their parent.
    """
    from . import jiggle
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    todo = []
    for pb in armature.pose.bones:
        if bones and pb.name not in bones:
            continue
        if pb.name.startswith(jiggle.AIM_PREFIX) or (pb.parent is not None and pb.parent.name.startswith(jiggle.AIM_PREFIX)):
            continue
        goals = [c for c in pb.constraints if c.type == "DAMPED_TRACK" and c.name.startswith(jiggle.GOAL_PREFIX)]
        if goals:
            todo.append((pb.name, [(c.name, c.target, c.subtarget, c.head_tail, c.track_axis, c.influence, c.mute) for c in goals]))
    if not todo:
        return {"aims": 0}, ""
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    made = []
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        for name, _goals in todo:
            eb = edit[name]
            aim = edit.get(jiggle.AIM_PREFIX + name) or edit.new(jiggle.AIM_PREFIX + name)
            aim.head, aim.tail, aim.roll = eb.head.copy(), eb.tail.copy(), eb.roll
            aim.parent = eb.parent
            aim.use_connect = eb.use_connect
            aim.use_deform = False
            hidden = armature.data.collections_all.get(MCH_COLLECTION) or armature.data.collections.new(MCH_COLLECTION)
            hidden.is_visible = False
            hidden.assign(aim)
            eb.use_connect = False
            eb.parent = aim
            made.append(aim.name)
    finally:
        bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous
    for name, goals in todo:
        link = armature.pose.bones[name]
        aim = armature.pose.bones[jiggle.AIM_PREFIX + name]
        aim.rotation_mode = link.rotation_mode
        for cname, target, subtarget, head_tail, axis, influence, mute in goals:
            con = aim.constraints.new("DAMPED_TRACK")
            con.name, con.target, con.subtarget = cname, target, subtarget
            con.head_tail, con.track_axis, con.influence, con.mute = head_tail, axis, influence, mute
            old = link.constraints.get(cname)
            if old is not None:
                link.constraints.remove(old)
    return {"aims": len(made), "bones": made}, ""


def build(armature, mesh_object, indices, donor, name="coat", angles_deg=(), segments=2, feel=None,
          parent_collection=""):
    """Create the strip bones on the part ``indices`` and constrain them to follow ``donor``.

    Returns (report, error); report["columns"] lists each column's bone names, top first.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "Choose the rig first."
    if donor is None or donor.type != "MESH":
        return None, "Set the garment underneath."
    if not angles_deg:
        return None, "Give the strip angles."
    mw = mesh_object.matrix_world
    pts = [mw @ mesh_object.data.vertices[i].co for i in indices]
    if not pts:
        return None, "Select the part's vertices."
    centre = Vector((sum(p.x for p in pts) / len(pts), sum(p.y for p in pts) / len(pts), 0.0))
    spacing = 360.0 / max(1, len(angles_deg))
    spans = []
    for angle in angles_deg:
        a = math.radians(angle)
        half = max(6.0, spacing * 0.4)
        pick = []
        while not pick and half <= 60.0:
            pick = [p for p in pts if abs((_azimuth(p, centre) - a + math.pi) % (2 * math.pi) - math.pi) <= math.radians(half)]
            half += 6.0
        if not pick:
            return None, "No part at %.0f degrees." % angle
        spans.append((max(pick, key=lambda p: p.z), min(pick, key=lambda p: p.z)))
    sample = donor_sampler(donor, armature)
    inv = armature.matrix_world.inverted()
    view_layer = bpy.context.view_layer
    previous = view_layer.objects.active
    view_layer.objects.active = armature
    columns = []
    try:
        bpy.ops.object.mode_set(mode="EDIT")
        edit = armature.data.edit_bones
        coll_name = "%s: %s" % (BONE_COLLECTION, name)
        mch_name = "%s: %s" % (MCH_COLLECTION, name)
        coll = armature.data.collections_all.get(coll_name) or armature.data.collections.new(coll_name)
        mch = armature.data.collections_all.get(mch_name) or armature.data.collections.new(mch_name)
        mch.is_visible = False
        holder = armature.data.collections_all.get(parent_collection) if parent_collection else None
        if holder is not None:
            # hiding the part hides its strips: a child collection shows only while its parent does
            coll.parent = holder
            mch.parent = holder
        followers = []
        sides = []
        for c, (top, bottom) in enumerate(spans, start=1):
            side = ".l" if (top.x - centre.x) > 0.03 else (".r" if (top.x - centre.x) < -0.03 else ".x")
            names, guides = [], []
            for s in range(1, segments + 1):
                head = top.lerp(bottom, (s - 1) / float(segments))
                tail = top.lerp(bottom, s / float(segments))
                gname = "mch_%s_%02d_%02d%s" % (name, c, s, side)
                eg = edit.get(gname) or edit.new(gname)
                eg.head, eg.tail, eg.roll = inv @ head, inv @ tail, 0.0
                eg.parent = None
                eg.use_deform = False
                mch.assign(eg)
                bname = "c_%s_%02d_%02d%s" % (name, c, s, side)
                eb = edit.get(bname) or edit.new(bname)
                eb.head, eb.tail, eb.roll = inv @ head, inv @ tail, 0.0
                if s == 1:
                    eb.parent = eg
                    eb.use_connect = False
                else:
                    # the goal turns this hidden aim bone; the strip's own rotation applies after it
                    aim = edit.get(jiggle_aim_prefix() + bname) or edit.new(jiggle_aim_prefix() + bname)
                    aim.head, aim.tail, aim.roll = eb.head.copy(), eb.tail.copy(), 0.0
                    aim.parent = edit[names[-1]]
                    aim.use_connect = True
                    aim.use_deform = False
                    mch.assign(aim)
                    eb.parent = aim
                    eb.use_connect = False
                eb.use_deform = True
                coll.assign(eb)
                names.append(bname)
                guides.append(gname)
            columns.append(names)
            followers.append(guides)
            sides.append(side)
        bpy.ops.object.mode_set(mode="POSE")
        for names, guides in zip(columns, followers):
            for k, bname in enumerate(names):
                pb = armature.pose.bones[bname]
                for con in list(pb.constraints):
                    if con.type in ("ARMATURE", "DAMPED_TRACK"):
                        pb.constraints.remove(con)
                if k == 0:
                    continue
                pb = armature.pose.bones[jiggle_aim_prefix() + bname]
                for con in list(pb.constraints):
                    if con.type == "DAMPED_TRACK":
                        pb.constraints.remove(con)
                goal = pb.constraints.new("DAMPED_TRACK")
                goal.name = "SRS goal %s" % guides[k]
                goal.target = armature
                goal.subtarget = guides[k]
                goal.head_tail = 1.0
                goal.track_axis = "TRACK_Y"
        made = 0
        for guides in followers:
            for bname in guides:
                pb = armature.pose.bones[bname]
                for con in list(pb.constraints):
                    if con.type == "ARMATURE":
                        pb.constraints.remove(con)
                weights = sample(armature.matrix_world @ pb.bone.head_local)
                if not weights:
                    continue
                con = pb.constraints.new("ARMATURE")
                con.name = "SRS follow %s" % donor.name
                for bone, w in sorted(weights.items(), key=lambda kv: -kv[1]):
                    t = con.targets.new()
                    t.target = armature
                    t.subtarget = bone
                    t.weight = w
                made += 1
    finally:
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        view_layer.objects.active = previous
    # every column is a chain the bake reaches by name: <name>_NN<side>
    from . import jiggle
    keys = []
    for c, (names, side) in enumerate(zip(columns, sides), start=1):
        key = "%s_%02d%s" % (name, c, side)
        jiggle.mark_chain(armature, key, names)
        if feel:
            jiggle.store_settings(armature, key, prefix=jiggle.MARK, **feel)
        keys.append(key)
    return {"name": name, "columns": columns, "constrained": made, "chains": keys,
            "bones": sum(len(c) for c in columns)}, ""
