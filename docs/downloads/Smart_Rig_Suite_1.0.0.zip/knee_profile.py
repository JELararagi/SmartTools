# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi


__srs_revision__ = "2.26.0"
__srs_module_generation_marker__ = object()

"""Per-angle shaping profile for an externally generated knee.

Auto-Rig Pro shapes the knee with "Joints Fans" -- half bones carrying a Bulge
constraint, which is a TRANSFORM constraint mapping the joint's rotation onto a
translation. That mapping is a single straight line: one input range, one output
range, one influence. Blender's constraint offers nothing more, so the amount of
bulge is forced to be a linear function of the flexion angle.

A knee does not behave linearly. The knee cap protrudes at moderate flexion and is
drawn back at deep flexion; the popliteal hollow is nearly flat while the leg is
only slightly bent and creases sharply once it passes a right angle. Fitting one
straight line to that gives the wrong shape at both ends, and correcting one angle
necessarily spoils another -- measured on the reference rig, holding the knee cap
to a constant protrusion from 45 to 90 degrees needs a control value that falls and
then rises again, which no single line can express.

This module drives the same fan constraints from an arbitrary piecewise-linear curve
of flexion angle against millimetres, so each angle can be dialled on its own. The
curve is carried as **keyframes on the driver's own F-curve**, not as an expression:
a driver expression is capped at a couple of hundred characters, which a six-point
curve already overruns and Blender then reports as a syntax error, and keyframes
have the further advantage of being visible and editable in the Graph Editor.
Extrapolation is CONSTANT, so the first and last values are held outside the curve,
which is what the Bulge extrapolation expects. Note that the constraint's own
extrapolation already scales its output by the flexion angle, so the rest pose is
untouched no matter what the curve says.

The driving value is the rotation difference between the thigh and shin bones, which
**is** the flexion angle -- zero when the leg is straight, whatever control the
animator uses. A rig whose rest pose carries a slight knee bend already reads that
bend at rest, so an onset below it would engage immediately; the audit reports the
current reading so that is visible rather than surprising.

Sign convention for a curve value: **positive pushes the surface outward**, away
from the bone -- the front fans anteriorly, the back fan posteriorly. That is the
negation of the constraint's own ``to_min_y`` on the left side, and mirrored again
on the right, both of which this module handles.
"""

import math

import bpy

# Auto-Rig Pro bone names this module relies on.
DRIVER_A_FMT = "thigh_stretch{side}"
DRIVER_B_FMT = "leg_stretch{side}"
FRONT_FANS = ("c_knee_out_01{side}", "c_knee_out_02{side}")
BACK_FANS = ("c_knee_in_01{side}",)
CONSTRAINT_NAME = "Bulge"

# The reference rig's own to_min_y / to_max_y, stashed on the bone so remove() can undo cleanly.
_STASH = "srs_knee_profile_to_min_y"
_STASH_MAX = "srs_knee_profile_to_max_y"

SIDES = (".l", ".r")

# The right side's fans carry the negated value, so the same curve mirrors.
_SIDE_SIGN = {".l": -1.0, ".r": 1.0}

DEFAULT_FRONT = "45:3.3, 60:-22.3, 75:-16, 90:-9.3, 95:-5.6, 170:-100"
DEFAULT_BACK = "45:39.7, 60:44, 75:30, 90:13.5, 95:13.5, 110:54, 170:94"

MAX_POINTS = 32
MIN_SPAN_DEG = 0.5


def _fmt(names, side):
    return tuple(n.format(side=side) for n in names)


def parse_curve(text):
    """Turn ``"45:3.3, 60:0.9"`` into ``[(45.0, 3.3), (60.0, 0.9)]``.

    Raises ``ValueError`` with a message meant for the operator report.
    """
    if text is None:
        raise ValueError("The curve is empty")
    items = [chunk.strip() for chunk in str(text).replace(";", ",").split(",")]
    items = [c for c in items if c]
    if not items:
        raise ValueError("The curve is empty")
    if len(items) > MAX_POINTS:
        raise ValueError("A curve takes at most %d points" % MAX_POINTS)
    points = []
    for chunk in items:
        if ":" not in chunk:
            raise ValueError("'%s' is not written as angle:mm" % chunk)
        left, right = chunk.split(":", 1)
        try:
            angle = float(left.strip())
            amount = float(right.strip())
        except ValueError:
            raise ValueError("'%s' is not a pair of numbers" % chunk)
        if not (0.0 <= angle <= 180.0):
            raise ValueError("Angle %g is outside 0 to 180 degrees" % angle)
        if abs(amount) > 500.0:
            raise ValueError("Amount %g mm is beyond the 500 mm limit" % amount)
        points.append((angle, amount))
    if len(points) < 2:
        raise ValueError("A curve needs at least two points, written as angle:mm")
    points.sort(key=lambda p: p[0])
    for i in range(len(points) - 1):
        if points[i + 1][0] - points[i][0] < MIN_SPAN_DEG:
            raise ValueError("Angles %g and %g are too close together"
                             % (points[i][0], points[i + 1][0]))
    return points


def format_curve(points):
    return ", ".join("%g:%g" % (a, v) for a, v in points)


def linear_points(onset_deg, end_deg):
    """The plain onset-to-end ramp, as a two point curve running 0 to 1."""
    if end_deg <= onset_deg:
        raise ValueError("End angle must be greater than the onset angle")
    return [(float(onset_deg), 0.0), (float(end_deg), 1.0)]


def evaluate(points, angle_deg):
    """The curve in Python, for reporting and for tests."""
    if angle_deg <= points[0][0]:
        return points[0][1]
    if angle_deg >= points[-1][0]:
        return points[-1][1]
    for (a0, v0), (a1, v1) in zip(points, points[1:]):
        if a0 <= angle_deg <= a1:
            return v0 + (v1 - v0) * (angle_deg - a0) / (a1 - a0)
    return points[-1][1]


def bind_flexion(fcurve, armature, bone_a, bone_b):
    """Make the driver read the flexion angle, in radians, and nothing else."""
    driver = fcurve.driver
    driver.type = "AVERAGE"
    for existing in list(driver.variables):
        driver.variables.remove(existing)
    variable = driver.variables.new()
    variable.name = "flex"
    variable.type = "ROTATION_DIFF"
    variable.targets[0].id = armature
    variable.targets[1].id = armature
    variable.targets[0].bone_target = bone_a
    variable.targets[1].bone_target = bone_b
    return variable


def apply_curve(fcurve, points, scale=1.0):
    """Write the curve onto the driver's F-curve as linear keyframes.

    A generated modifier would override the keyframes, and a fresh driver F-curve
    can carry one, so anything already on the curve is cleared first.
    """
    for modifier in list(fcurve.modifiers):
        fcurve.modifiers.remove(modifier)
    for _ in range(len(fcurve.keyframe_points)):
        fcurve.keyframe_points.remove(fcurve.keyframe_points[0], fast=True)
    for angle, amount in points:
        keyframe = fcurve.keyframe_points.insert(math.radians(angle), amount * scale)
        keyframe.interpolation = "LINEAR"
    fcurve.extrapolation = "CONSTANT"
    fcurve.update()
    return len(fcurve.keyframe_points)


def _constraint_path(bone_name, attr="to_min_y"):
    return 'pose.bones["%s"].constraints["%s"].%s' % (bone_name, CONSTRAINT_NAME, attr)


def fan_ends(constraint):
    """``(rest attribute, flexed attribute, flexed rotation)`` of a Bulge fan.

    The rest end is the end of the input range whose rotation is zero: its output is
    what the fan does with the joint straight, so it must be zero. The flexed end is
    the other one (+-90 degrees); with extrapolation on, the output is a straight line
    through zero whose slope that end sets. Auto-Rig Pro builds some fans with the
    range [0, 90] and some with [-90, 0] -- on MIK the left inner elbow fan is one way
    round and the right one the other -- so "to_min_y" is the flexed end on some fans
    and the rest end on others. Driving to_min_y everywhere put the profile on the
    rest end of the left inner elbow fan: it sat 19.18 mm off with the arm straight.
    """
    if abs(float(constraint.from_min_z_rot)) < 1.0e-6:
        return "to_min_y", "to_max_y", float(constraint.from_max_z_rot)
    return "to_max_y", "to_min_y", float(constraint.from_min_z_rot)


def mirror_factor(armature, source, target):
    """What the flexed-end value of ``source`` becomes on its mirror twin ``target``.

    A fan's output moves it along its own local Y, linearly in the joint's rotation,
    and a mirrored limb rotates the other way. Carrying that through, the twin's value
    is ``-(F_target / F_source) * d`` times the source's, where F is each fan's flexed
    rotation and d is +1 when the twin's rest Y axis is the mirror of the source's
    (else -1). Measured on MIK: the knees give -1 (Auto-Rig Pro's own values, -38 / +38,
    already obey it), the elbows and hips +1. The rule copied as a plain negation put
    the right elbow's fans on the point reflection of the left's (38 mm apart at 140
    degrees); by the rule the two elbows match to 0.01 mm.
    """
    from mathutils import Vector

    sc = armature.pose.bones[source].constraints.get(CONSTRAINT_NAME)
    tc = armature.pose.bones[target].constraints.get(CONSTRAINT_NAME)
    if sc is None or tc is None:
        return None
    _r, _f, fs = fan_ends(sc)
    _r, _f, ft = fan_ends(tc)
    if abs(fs) < 1.0e-9:
        return None
    m3 = armature.matrix_world.to_3x3()
    ys = (m3 @ armature.data.bones[source].matrix_local.to_3x3()).col[1]
    yt = (m3 @ armature.data.bones[target].matrix_local.to_3x3()).col[1]
    d = 1.0 if Vector((-ys.x, ys.y, ys.z)).dot(yt) > 0.0 else -1.0
    return -(ft / fs) * d


def repair_rest_end(armature, bone_name):
    """Put a fan's driver and value on its flexed end and its rest end at zero. ``(changes)``."""
    pb = armature.pose.bones.get(bone_name)
    con = pb.constraints.get(CONSTRAINT_NAME) if pb is not None else None
    if con is None:
        return []
    rest, flex, _f = fan_ends(con)
    ad = armature.animation_data
    changes = []
    d_rest = ad.drivers.find(_constraint_path(bone_name, rest)) if ad else None
    d_flex = ad.drivers.find(_constraint_path(bone_name, flex)) if ad else None
    if d_rest is not None and d_flex is None:
        moved = ad.drivers.from_existing(src_driver=d_rest)
        moved.data_path = _constraint_path(bone_name, flex)
        ad.drivers.remove(d_rest)
        changes.append("driver %s -> %s" % (rest, flex))
    elif d_rest is not None:
        ad.drivers.remove(d_rest)
        changes.append("driver on %s dropped" % rest)
    elif d_flex is None and abs(getattr(con, rest)) > 1.0e-7 and abs(getattr(con, flex)) <= 1.0e-7:
        setattr(con, flex, getattr(con, rest))
        changes.append("value %s -> %s" % (rest, flex))
    if abs(getattr(con, rest)) > 1.0e-9:
        changes.append("%s %.4f -> 0" % (rest, getattr(con, rest)))
    setattr(con, rest, 0.0)
    return changes


def resolve(armature, side, joint=None):
    """Report which fans this side actually carries. Returns ``(data, error)``.

    ``joint`` optionally supplies an already-discovered joint (see
    :mod:`joint_setup`) so the same treatment works on an elbow or any other
    joint of the same shape. Left out, the knee's own names are used and the
    behaviour is exactly as before.
    """
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    pose_bones = armature.pose.bones
    if joint is not None:
        need = (joint["proximal"], joint["distal"])
        missing = [n for n in need if n not in pose_bones]
        if missing:
            return None, "Missing bones: %s" % ", ".join(missing)
        front = [n for n in joint.get("front_fan", [])
                 if n in pose_bones
                 and pose_bones[n].constraints.get(CONSTRAINT_NAME) is not None]
        back = [n for n in joint.get("back_fan", [])
                if n in pose_bones
                and pose_bones[n].constraints.get(CONSTRAINT_NAME) is not None]
        if not front and not back:
            return None, ("No fan bones with a %r constraint on this joint"
                          % CONSTRAINT_NAME)
        return {"side": side, "front": front, "back": back,
                "driver_a": need[0], "driver_b": need[1]}, ""
    need = (DRIVER_A_FMT.format(side=side), DRIVER_B_FMT.format(side=side))
    missing = [n for n in need if n not in pose_bones]
    if missing:
        return None, "Missing bones: %s" % ", ".join(missing)

    def usable(names):
        found = []
        for n in _fmt(names, side):
            pb = pose_bones.get(n)
            if pb is not None and pb.constraints.get(CONSTRAINT_NAME) is not None:
                found.append(n)
        return found

    front = usable(FRONT_FANS)
    back = usable(BACK_FANS)
    if not front and not back:
        return None, "No knee fan bones with a '%s' constraint" % CONSTRAINT_NAME
    return {"side": side, "front": front, "back": back,
            "driver_a": need[0], "driver_b": need[1]}, ""


def _clear(armature, bone_name):
    ad = armature.animation_data
    if not ad:
        return 0
    paths = {_constraint_path(bone_name, "to_min_y"), _constraint_path(bone_name, "to_max_y")}
    n = 0
    for fc in list(ad.drivers):
        if fc.data_path in paths:
            ad.drivers.remove(fc)
            n += 1
    return n


def remove(armature, sides=SIDES, joint=None):
    """Take the profile back out and put the reference rig's own value back.

    Deleting a driver leaves the property at whatever it last evaluated to, which
    would freeze the knee at the angle it happened to be posed at. The value the
    external rig shipped is stashed on the bone at install time and written back
    here, so the fan returns to the plain linear Bulge it started as.
    """
    n = 0
    for side in sides:
        data, _err = resolve(armature, side, joint=joint)
        if data is None:
            continue
        for name in data["front"] + data["back"]:
            n += _clear(armature, name)
            pb = armature.pose.bones.get(name)
            if pb is None:
                continue
            constraint = pb.constraints.get(CONSTRAINT_NAME)
            for key, attr in ((_STASH, "to_min_y"), (_STASH_MAX, "to_max_y")):
                stored = pb.get(key)
                if stored is None:
                    continue
                if constraint is not None:
                    setattr(constraint, attr, float(stored))
                del pb[key]
    return n


def install(armature, sides=SIDES, front_curve=DEFAULT_FRONT,
            back_curve=DEFAULT_BACK, joint=None):
    """Drive the knee fans from the two curves. Returns ``(report, error)``."""
    if armature is None or armature.type != "ARMATURE":
        return None, "No armature"
    try:
        front_points = parse_curve(front_curve) if front_curve else None
        back_points = parse_curve(back_curve) if back_curve else None
    except ValueError as exc:
        return None, str(exc)
    if front_points is None and back_points is None:
        return None, "Both curves are empty"

    report = {"sides": [], "bones": [], "removed": 0,
              "front": format_curve(front_points) if front_points else "",
              "back": format_curve(back_points) if back_points else ""}
    for side in sides:
        data, err = resolve(armature, side, joint=joint)
        if data is None:
            report["sides"].append({"side": side, "error": err})
            continue
        report["removed"] += remove(armature, (side,), joint=joint)
        for tag, names, points in (("front", data["front"], front_points),
                                   ("back", data["back"], back_points)):
            if points is None:
                continue
            for name in names:
                pb = armature.pose.bones[name]
                constraint = pb.constraints.get(CONSTRAINT_NAME)
                if constraint is None:
                    continue
                if pb.get(_STASH) is None:
                    # Capture before the first driver lands; a second install must
                    # not overwrite the stash with an already-driven value.
                    pb[_STASH] = float(constraint.to_min_y)
                    pb[_STASH_MAX] = float(constraint.to_max_y)
                rest, flex, _f = fan_ends(constraint)
                # The left side carries the curve with the left's sign; any other side is
                # its physical mirror (mirror_factor), not a plain negation.
                sign = _SIDE_SIGN[".l"]
                if side != ".l":
                    twin = name[:-len(side)] + ".l" if name.endswith(side) else None
                    factor = mirror_factor(armature, twin, name) if twin and armature.pose.bones.get(twin) else None
                    sign = sign * factor if factor is not None else _SIDE_SIGN.get(side, 1.0)
                setattr(constraint, rest, 0.0)
                fcurve = constraint.driver_add(flex)
                bind_flexion(fcurve, armature, data["driver_a"], data["driver_b"])
                keys = apply_curve(fcurve, points, scale=sign * 0.001)
                report["bones"].append({"bone": name, "group": tag, "keys": keys,
                                        "influence": round(constraint.influence, 3)})
        report["sides"].append({"side": side, "front": len(data["front"]),
                                "back": len(data["back"])})
    if not report["bones"]:
        return report, "Nothing was installed; see the per-side messages"
    return report, ""


def sample(front_curve=DEFAULT_FRONT, back_curve=DEFAULT_BACK,
           angles=(0, 30, 45, 60, 75, 90, 110, 130, 160, 170)):
    """Read the two curves back at a set of angles, for the audit report."""
    out = {}
    for tag, text in (("front", front_curve), ("back", back_curve)):
        if not text:
            continue
        try:
            points = parse_curve(text)
        except ValueError as exc:
            out[tag] = {"error": str(exc)}
            continue
        out[tag] = {"%g" % a: round(evaluate(points, a), 2) for a in angles}
    return out


def audit(armature, sides=SIDES, joint=None):
    """Report what is driven and at what angle the rig currently sits."""
    out = {"installed": [], "issues": []}
    ad = armature.animation_data
    keyed = {}
    if ad:
        for fc in ad.drivers:
            keyed[fc.data_path] = len(fc.keyframe_points)
    for side in sides:
        data, err = resolve(armature, side, joint=joint)
        if data is None:
            out["issues"].append("%s: %s" % (side, err))
            continue
        pa = armature.pose.bones.get(data["driver_a"])
        pb_drv = armature.pose.bones.get(data["driver_b"])
        if pa is not None and pb_drv is not None:
            out["flexion_deg%s" % side] = round(math.degrees(
                pa.matrix.to_quaternion().rotation_difference(
                    pb_drv.matrix.to_quaternion()).angle), 2)
        for tag, names in (("front", data["front"]), ("back", data["back"])):
            for name in names:
                pb = armature.pose.bones[name]
                constraint = pb.constraints.get(CONSTRAINT_NAME)
                rest, flex, _f = fan_ends(constraint) if constraint else ("to_max_y", "to_min_y", 0.0)
                path = _constraint_path(name, flex)
                stored = pb.get(_STASH)
                if constraint is not None and (abs(getattr(constraint, rest)) > 1.0e-6
                                               or _constraint_path(name, rest) in keyed):
                    out["issues"].append("%s: the rest end (%s) is not zero, so the fan moves with the joint "
                                         "straight" % (name, rest))
                out["installed"].append({
                    "bone": name, "group": tag,
                    "driven": path in keyed,
                    "flexed_end": flex,
                    "rest_end_mm": round(getattr(constraint, rest) * 1000.0, 2) if constraint else None,
                    "keys": keyed.get(path, 0),
                    "to_min_y_mm": round(constraint.to_min_y * 1000.0, 2)
                    if constraint else None,
                    "influence": round(constraint.influence, 3) if constraint else None,
                    "extrapolate": bool(constraint.use_motion_extrapolate)
                    if constraint else None,
                    "rig_value_mm": round(float(stored) * 1000.0, 2)
                    if stored is not None else None,
                })
    out["driven_count"] = sum(1 for e in out["installed"] if e["driven"])
    out["total"] = len(out["installed"])
    for entry in out["installed"]:
        if entry["driven"] and entry["extrapolate"] is False:
            out["issues"].append(
                "%s is driven but its Bulge does not extrapolate, so the curve is "
                "clamped to the constraint's own range" % entry["bone"])
        if entry["driven"] and entry["keys"] < 2:
            out["issues"].append(
                "%s is driven but its curve carries %d keyframes"
                % (entry["bone"], entry["keys"]))
    return out
