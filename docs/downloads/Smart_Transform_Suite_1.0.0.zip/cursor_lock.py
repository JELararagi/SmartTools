# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent
from mathutils import Vector

from .translation import TI
from . import settings as _settings
from . import runtime as _runtime

_MESSAGE_BUS_OWNER = object()
_IS_RESTORING_CURSOR = False
_RUNTIME_ACTIVE = False

_PROP_GROUP_NAME = 'cursor_lock_props'
_PREF_ENABLE_PROP_NAME = 'enable_cursor_lock_feature'


def _available_scenes():
    data = getattr(bpy, 'data', None)
    scenes = getattr(data, 'scenes', None)
    return tuple(scenes) if scenes is not None else ()


def _addon_preferences(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None


def is_feature_enabled(context=None) -> bool:
    prefs = _addon_preferences(context)
    if prefs is None:
        return False
    try:
        return bool(getattr(prefs, _PREF_ENABLE_PROP_NAME, False))
    except Exception:
        return False


def scene_props(scene):
    if scene is None:
        return None
    try:
        return getattr(scene, _PROP_GROUP_NAME, None)
    except Exception:
        return None


def is_lock_enabled(scene) -> bool:
    props = scene_props(scene)
    if props is None:
        return False
    try:
        return bool(getattr(props, 'enabled', False))
    except Exception:
        return False

def _save_cursor_lock_scene_state(self=None, context=None) -> None:
    del self
    try:
        if _settings.is_restoring():
            return
        _settings.request_save('cursor_lock_scene_state', context=context or getattr(bpy, 'context', None))
    except Exception:
        pass



def _set_lock_enabled(scene, enabled: bool) -> None:
    props = scene_props(scene)
    if props is None:
        return
    try:
        props.enabled = bool(enabled)
    except Exception:
        pass


def disable_all_scene_locks() -> None:
    for scene in _available_scenes():
        _set_lock_enabled(scene, False)


def locked_location(scene) -> Vector:
    props = scene_props(scene)
    if props is None:
        return Vector((0.0, 0.0, 0.0))
    try:
        return Vector(getattr(props, 'lock_location', (0.0, 0.0, 0.0)))
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _cursor_needs_restore(scene) -> bool:
    try:
        cursor = getattr(scene, 'cursor', None)
        if cursor is None:
            return False
        return (cursor.location - locked_location(scene)).length_squared > 1.0e-20
    except Exception:
        return False


def restore_scene_cursor(scene) -> None:
    global _IS_RESTORING_CURSOR

    if scene is None or not is_feature_enabled() or not is_lock_enabled(scene):
        return

    try:
        cursor = getattr(scene, 'cursor', None)
        if cursor is None or not _cursor_needs_restore(scene):
            return
    except Exception:
        return

    _IS_RESTORING_CURSOR = True
    try:
        cursor.location[:] = locked_location(scene)
    finally:
        _IS_RESTORING_CURSOR = False


def restore_context_scene(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    restore_scene_cursor(scene)


def restore_all_locked_cursors() -> None:
    global _IS_RESTORING_CURSOR
    scenes = _available_scenes()
    if _IS_RESTORING_CURSOR or not scenes or not is_feature_enabled():
        return
    _IS_RESTORING_CURSOR = True
    try:
        for scene in scenes:
            if is_lock_enabled(scene):
                cursor = getattr(scene, 'cursor', None)
                if cursor is None:
                    continue
                if _cursor_needs_restore(scene):
                    cursor.location[:] = locked_location(scene)
    finally:
        _IS_RESTORING_CURSOR = False


def sync_feature_from_prefs(context=None, *, save: bool = False) -> None:
    enabled = is_feature_enabled(context)
    if enabled:
        _install_runtime_resources()
        restore_all_locked_cursors()
    else:
        disable_all_scene_locks()
        _remove_runtime_resources()
    if save:
        try:
            _settings.request_save('cursor_lock_feature_sync', context=context)
        except Exception:
            pass
    _tag_redraw_view3d_areas()


def _tag_redraw_view3d_areas() -> None:
    context = getattr(bpy, 'context', None)
    if context is None:
        return
    window_manager = getattr(context, 'window_manager', None)
    if window_manager is None:
        return
    for window in getattr(window_manager, 'windows', ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()):
            try:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
            except Exception:
                pass


def _on_cursor_location_changed(*_args):
    if _IS_RESTORING_CURSOR:
        return
    restore_all_locked_cursors()


def _subscribe_to_cursor_location() -> None:
    try:
        bpy.msgbus.clear_by_owner(_MESSAGE_BUS_OWNER)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.View3DCursor, 'location'),
            owner=_MESSAGE_BUS_OWNER,
            args=(),
            notify=_on_cursor_location_changed,
            options={'PERSISTENT'},
        )
    except Exception:
        pass


def _post_register_init():
    sync_feature_from_prefs(getattr(bpy, 'context', None), save=False)
    _tag_redraw_view3d_areas()
    return None


def _ensure_post_register_init() -> None:
    try:
        is_registered = bpy.app.timers.is_registered(_post_register_init)
    except (AttributeError, RuntimeError):
        is_registered = False
    if not is_registered:
        try:
            bpy.app.timers.register(_post_register_init, first_interval=0.0)
        except Exception:
            pass


@persistent
def _on_load_post(_filepath):
    _ensure_post_register_init()


@persistent
def _on_depsgraph_update_post(scene, _depsgraph):
    if _IS_RESTORING_CURSOR or scene is None or not is_feature_enabled() or not is_lock_enabled(scene):
        return
    restore_scene_cursor(scene)


def _draw_cursor_lock_toggle(self, context):
    if not is_feature_enabled(context):
        return
    scene = getattr(context, 'scene', None)
    if scene is None:
        return
    enabled = is_lock_enabled(scene)
    try:
        self.layout.operator(
            VIEW3D_OT_sts_toggle_cursor_lock.bl_idname,
            text='',
            icon='LOCKED' if enabled else 'UNLOCKED',
            depress=enabled,
        )
    except TypeError:
        self.layout.operator(
            VIEW3D_OT_sts_toggle_cursor_lock.bl_idname,
            text='',
            icon='LOCKED' if enabled else 'UNLOCKED',
        )


def _install_runtime_resources() -> None:
    global _RUNTIME_ACTIVE
    if _RUNTIME_ACTIVE:
        return
    _subscribe_to_cursor_location()
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if _on_depsgraph_update_post not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update_post)
    try:
        bpy.types.VIEW3D_MT_editor_menus.remove(_draw_cursor_lock_toggle)
    except Exception:
        pass
    bpy.types.VIEW3D_MT_editor_menus.append(_draw_cursor_lock_toggle)
    _RUNTIME_ACTIVE = True


def _remove_runtime_resources() -> None:
    global _RUNTIME_ACTIVE
    try:
        bpy.msgbus.clear_by_owner(_MESSAGE_BUS_OWNER)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_post_register_init):
            bpy.app.timers.unregister(_post_register_init)
    except (AttributeError, RuntimeError):
        pass
    try:
        bpy.types.VIEW3D_MT_editor_menus.remove(_draw_cursor_lock_toggle)
    except Exception:
        pass
    if _on_depsgraph_update_post in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update_post)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    _RUNTIME_ACTIVE = False


class STS_CursorLockSceneProps(bpy.types.PropertyGroup):
    enabled: bpy.props.BoolProperty(
        name=TI('3D Cursor Lock State', '3Dカーソルロック状態'),
        description=TI(
            'Internal scene lock state used by the Smart Transform 3D Cursor Lock header toggle. When enabled, the current scene keeps the 3D Cursor fixed at the saved lock location until the header toggle is turned off.',
            'Smart Transform の3Dカーソルロック用ヘッダー切替が使うシーン別内部ロック状態です。有効な間、このシーンでは3Dカーソルを保存位置に固定し、ヘッダー切替で解除するまで維持します。',
        ),
        default=False,
        options={'HIDDEN'},
        update=_save_cursor_lock_scene_state,
    )
    lock_location: bpy.props.FloatVectorProperty(
        name=TI('3D Cursor Lock Location', '3Dカーソルロック位置'),
        description=TI(
            'Internal stored location for Smart Transform 3D Cursor Lock. When the header toggle is locked, the 3D Cursor is restored to this saved position.',
            'Smart Transform の3Dカーソルロック用内部保存位置です。ヘッダー切替がロック中の間、3Dカーソルはこの保存位置へ戻されます。',
        ),
        size=3,
        subtype='TRANSLATION',
        default=(0.0, 0.0, 0.0),
        options={'HIDDEN'},
        update=_save_cursor_lock_scene_state,
    )


class VIEW3D_OT_sts_toggle_cursor_lock(bpy.types.Operator):
    bl_idname = 'view3d.sts_toggle_cursor_lock'
    bl_label = TI('3D Cursor Lock', '3Dカーソルロック')
    bl_description = TI(
        'Lock or unlock the 3D Cursor for the current scene. When you turn it on, the current 3D Cursor position is saved and kept fixed. This toggle is shown in the 3D View header while the 3D Cursor Lock feature itself is enabled from Smart Transform > Other Tools.',
        '現在のシーンの3Dカーソルをロックまたはアンロックします。ONにすると、その時点の3Dカーソル位置を保存し、その場所に固定します。この切替は Smart Transform > その他ツール で 3Dカーソルロック機能自体を有効にしている間だけ、3Dビューヘッダーに表示されます。',
    )
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        return (
            context is not None
            and getattr(context, 'scene', None) is not None
            and is_feature_enabled(context)
        )

    def execute(self, context):
        if not is_feature_enabled(context):
            self.report({'WARNING'}, TI('3D Cursor Lock is disabled in Smart Transform settings.', 'Smart Transform の設定で3Dカーソルロック機能が無効になっています。'))
            return {'CANCELLED'}

        scene = getattr(context, 'scene', None)
        props = scene_props(scene)
        cursor = getattr(scene, 'cursor', None) if scene is not None else None
        if props is None or cursor is None:
            self.report({'WARNING'}, TI('3D Cursor Lock is unavailable in the current context.', '現在のコンテキストでは3Dカーソルロックを使用できません。'))
            return {'CANCELLED'}

        try:
            currently_enabled = bool(getattr(props, 'enabled', False))
        except Exception:
            currently_enabled = False

        try:
            if currently_enabled:
                props.enabled = False
            else:
                props.lock_location = tuple(cursor.location)
                props.enabled = True
                restore_scene_cursor(scene)
            try:
                _settings.request_save('cursor_lock_toggle', context=context)
            except Exception:
                pass
            _tag_redraw_view3d_areas()
            return {'FINISHED'}
        except Exception:
            self.report({'WARNING'}, TI('3D Cursor Lock could not be changed.', '3Dカーソルロックを変更できませんでした。'))
            return {'CANCELLED'}


classes = (
    STS_CursorLockSceneProps,
    VIEW3D_OT_sts_toggle_cursor_lock,
)


def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, '__name__', ''), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def register():
    for cls in reversed(classes):
        _safe_unregister_class(cls)

    for cls in classes:
        bpy.utils.register_class(cls)

    if hasattr(bpy.types.Scene, _PROP_GROUP_NAME):
        try:
            delattr(bpy.types.Scene, _PROP_GROUP_NAME)
        except Exception:
            pass
    bpy.types.Scene.cursor_lock_props = bpy.props.PointerProperty(
        type=STS_CursorLockSceneProps,
        name=TI('3D Cursor Lock Scene State', '3Dカーソルロックシーン状態'),
        description=TI(
            'Internal scene-level state for Smart Transform 3D Cursor Lock. The feature itself is enabled from Smart Transform > Other Tools, and the actual lock is toggled from the 3D View header icon.',
            'Smart Transform の3Dカーソルロック用シーン状態です。機能自体の有効化は Smart Transform > その他ツール で行い、実際のロック切り替えは3Dビューヘッダーのアイコンで行います。',
        ),
    )

    _ensure_post_register_init()


def unregister():
    _remove_runtime_resources()

    if hasattr(bpy.types.Scene, _PROP_GROUP_NAME):
        try:
            delattr(bpy.types.Scene, _PROP_GROUP_NAME)
        except Exception:
            pass

    for cls in reversed(classes):
        _safe_unregister_class(cls)

    _tag_redraw_view3d_areas()
