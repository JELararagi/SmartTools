# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import sys
import time
import builtins as _builtins
from . import load_hooks as _load_hooks
from .keymap_safety import safe_remove_keymap_item as _sts_safe_remove_keymap_item

try:
    import bpy  # type: ignore
    from bpy.app.handlers import persistent  # type: ignore
except Exception:  # pragma: no cover - Blender runtime only
    bpy = None
    def persistent(fn):
        return fn

# Earlier builds routed this add-on through a SmartTools / Properties pseudo-tab
# host and generated VIEW_3D proxy panels dynamically.  When a user installs the
# standard N-panel build over those versions without restarting Blender, those
# registered proxy classes can remain in bpy.types even after their Python module
# has been removed.  Blender can then call an orphan Panel.draw during Sidebar
# layout and crash natively.  This file removes only those obsolete Smart Transform
# Toolset classes/modules and invalid migrated tool keymap items.  It never changes
# Blender interface theme data or user interface preferences.

_STS_OWNER_KEYS = {
    'core_suite',
    'smart_transform_suite',
    'Smart_Transform_Suite',
    'bl_ext.user_default.smart_transform_suite',
    'bl_ext.user_default.Smart_Transform_Suite',
    'bl_ext.user_default.core_suite',
}

_STALE_PACKAGE_MODULE_LEAVES = {
    'navigation_properties',
    'smart_tools_bootstrap_common',
    'smart_tools_preferences',
    'console_clean_runtime',
    'npanel_' + 'op' + 'acity_runtime',
    'op' + 'acity_runtime',
    'sms_properties_pseudo',
    'ms_properties_pseudo',
}

_STALE_EXTERNAL_MODULE_NAMES = {
    'bl_ext.user_default.smart_tools_window_prototype',
    'bl_ext.user_default.smart_tools_independent_window_shell',
    'bl_ext.user_default.view_plane_generator',
    'bl_ext.user_default.smart_tools_browser_prototype',
    'bl_ext.user_default.smart_tools_window',
    'smart_tools_window_prototype',
    'smart_tools_independent_window_shell',
    'view_plane_generator',
    'smart_tools_browser_prototype',
    'smart_tools_window',
}

_STALE_PANEL_EXACT_NAMES = {
    'PROPERTIES_PT_SmartTransformRoot',
    'PROPERTIES_PT_SmartTransformControls',
    'PROPERTIES_PT_SmartTransformAddonPreferences',
    'PROPERTIES_PT_SmartTransformPreferences',
}

_STALE_PANEL_NAME_PREFIXES = (
    'SMARTTOOLS_NPANEL_PT_core_suite',
    'SMARTTOOLS_NPANEL_PT_smart_transform_suite',
    'SMARTTOOLS_NPANEL_PT_anchor_smart_transform_',
    'VIEW3D_PT_smart_tools_manager_proxy_',
    'IMAGE_PT_smart_tools_manager_proxy_',
    'NODE_PT_smart_tools_manager_proxy_',
    'PROPERTIES_PT_smart_tools_manager_proxy_',
    'PROPERTIES_PT_SmartTransform',
)

_STALE_ANY_SMARTTOOLS_PANEL_PREFIXES = (
    'SMARTTOOLS_NPANEL_PT_',
    'SMARTTOOLS_PT_',
    'SMART_TOOLS_PT_',
    '_SMARTTOOLS_NPANEL_SHIM_',
)

_STALE_OPERATOR_CLASS_PREFIXES = (
    'SMARTTOOLS_OT_',
    'SMARTTOOLS_NPANEL_OT_',
    'WM_OT_smart_tools_',
    'SMART_TRANSFORM_OT_toggle_properties_pseudo_tab',
)

_STALE_OPERATOR_ID_PREFIXES = (
    'wm.smart_tools_',
    'wm.smart_tools_window',
    'wm.smart_tools_browser',
    'wm.bl_ext_npanel_',
)

_STALE_OPERATOR_ID_EXACT = {
    'wm.core_suite_open_window_v250',
    'wm.core_suite_pick_scene_v270',
    'core.toggle_properties_pseudo_tab',
}


def _lower(value: object) -> str:
    return str(value or '').strip().lower()


def _leaf(module_name: object) -> str:
    text = str(module_name or '').strip()
    return text.rsplit('.', 1)[-1] if text else ''


def _is_suite_module_name(module_name: object) -> bool:
    text = str(module_name or '').strip()
    if not text:
        return False
    parts = text.split('.')
    root = parts[2] if len(parts) > 2 and parts[0] == 'bl_ext' else parts[0]
    return root in {'core_suite', 'smart_transform_suite', 'Smart_Transform_Suite'}


def _is_stale_package_module_name(module_name: object) -> bool:
    text = str(module_name or '').strip()
    if not text:
        return False
    if text in _STALE_EXTERNAL_MODULE_NAMES:
        return True
    if _leaf(text) not in _STALE_PACKAGE_MODULE_LEAVES:
        return False
    return _is_suite_module_name(text)


def _call_cleanup_function(module, name: str) -> None:
    fn = getattr(module, name, None)
    if not callable(fn):
        return
    try:
        fn()
        return
    except TypeError:
        pass
    except Exception:
        return
    for owner in _STS_OWNER_KEYS:
        try:
            fn(owner)
            continue
        except TypeError:
            try:
                fn(addon_key=owner)
            except Exception:
                pass
        except Exception:
            pass


def purge_stale_modules() -> bool:
    changed = False
    for module_name, module in list(sys.modules.items()):
        if not _is_stale_package_module_name(module_name):
            continue
        try:
            _call_cleanup_function(module, 'unregister')
            _call_cleanup_function(module, 'uninstall')
            _call_cleanup_function(module, 'clear_runtime_audit')
        except Exception:
            pass
        try:
            sys.modules.pop(module_name, None)
            changed = True
        except Exception:
            pass
    return changed


def _safe_is_subclass(cls, base) -> bool:
    try:
        return isinstance(cls, type) and issubclass(cls, base)
    except Exception:
        return False


def _candidate_classes(base, *, prefixes: tuple[str, ...], exact_names: set[str] | None = None):
    if bpy is None:
        return ()
    seen: set[type] = set()
    out: list[type] = []

    try:
        for cls in base.__subclasses__():
            if isinstance(cls, type) and cls not in seen:
                seen.add(cls)
                out.append(cls)
    except Exception:
        pass

    exact_names = exact_names or set()
    try:
        names = list(dir(bpy.types))
    except Exception:
        names = []
    for name in names:
        text = str(name or '')
        if text not in exact_names and not text.startswith(prefixes):
            continue
        try:
            cls = getattr(bpy.types, text, None)
        except Exception:
            cls = None
        if isinstance(cls, type) and cls not in seen:
            seen.add(cls)
            out.append(cls)
    for text in exact_names:
        try:
            cls = getattr(bpy.types, text, None)
        except Exception:
            cls = None
        if isinstance(cls, type) and cls not in seen:
            seen.add(cls)
            out.append(cls)
    return tuple(out)


def _class_identity(cls) -> tuple[str, str, str, str]:
    try:
        name = str(getattr(cls, '__name__', '') or '')
    except Exception:
        name = ''
    try:
        bl_idname = str(getattr(cls, 'bl_idname', '') or '')
    except Exception:
        bl_idname = ''
    try:
        module = str(getattr(cls, '__module__', '') or '')
    except Exception:
        module = ''
    try:
        owner = str(getattr(cls, '_smart_suite_clone_owner', '') or '')
    except Exception:
        owner = ''
    return name, bl_idname, module, owner


def _is_stale_suite_panel_class(cls) -> bool:
    name, bl_idname, module, owner = _class_identity(cls)
    if name in _STALE_PANEL_EXACT_NAMES or bl_idname in _STALE_PANEL_EXACT_NAMES:
        return True
    if any(name.startswith(prefix) or bl_idname.startswith(prefix) for prefix in _STALE_PANEL_NAME_PREFIXES):
        return True

    module_lower = module.lower()
    owner_lower = owner.lower()
    smarttools_named = (
        name.startswith(_STALE_ANY_SMARTTOOLS_PANEL_PREFIXES)
        or bl_idname.startswith(_STALE_ANY_SMARTTOOLS_PANEL_PREFIXES)
    )
    if smarttools_named:
        if owner_lower == 'core_suite':
            return True
        if 'core_suite' in module_lower:
            return True
        if module.endswith('.navigation_properties') or module == 'navigation_properties':
            return True

    try:
        if bool(getattr(cls, '_smart_suite_npanel_proxy', False)) or bool(getattr(cls, '_smart_suite_host_panel', False)):
            if owner_lower == 'core_suite' or 'core_suite' in module_lower:
                return True
    except Exception:
        pass
    return False


def clean_stale_panel_classes() -> bool:
    if bpy is None:
        return False
    changed = False
    prefixes = _STALE_PANEL_NAME_PREFIXES + _STALE_ANY_SMARTTOOLS_PANEL_PREFIXES
    for cls in _candidate_classes(bpy.types.Panel, prefixes=prefixes, exact_names=_STALE_PANEL_EXACT_NAMES):
        if not _safe_is_subclass(cls, bpy.types.Panel):
            continue
        if not _is_stale_suite_panel_class(cls):
            continue
        # Do not unregister stale panels while Blender may have an open C-side
        # ui_handler_panel pointer.  Blender 5.1 can crash before Python can
        # handle the exception.  Make the class permanently inert instead.
        for attr in ('draw', 'draw_header', 'draw_header_preset'):
            try:
                setattr(cls, attr, _noop_draw)
                changed = True
            except Exception:
                pass
        # Do not set poll=False. Hiding stale panels can remove every Smart Tools
        # N-panel category tab, and it does not fix Blender's C-side callback
        # pointer. A concrete no-op draw is enough to make the class safe.
    return changed


def _is_stale_suite_operator_class(cls) -> bool:
    name, bl_idname, module, _owner = _class_identity(cls)
    module_lower = module.lower()
    if bl_idname in _STALE_OPERATOR_ID_EXACT or bl_idname.startswith(_STALE_OPERATOR_ID_PREFIXES):
        return True
    if name.startswith(_STALE_OPERATOR_CLASS_PREFIXES):
        if 'core_suite' in module_lower or 'core_suite' in name.lower():
            return True
        if 'core' in module_lower and 'smart' in name.lower():
            return True
        if 'navigation_properties' in module_lower:
            return True
        return False
    if 'navigation_properties' in module_lower and 'core_suite' in module_lower:
        return True
    return False




# ------------------------------------------------------------------------------
# Blender 5.1 UI callback guard
# ------------------------------------------------------------------------------
# Some older Smart Tools builds can leave registered Panel/Header RNA types after
# their Python class body has lost draw(). Blender then repeatedly reports
# "could not find function draw ..." and may crash inside native UI handlers.
# This guard only repairs already-broken callbacks; it does not alter healthy UI.
_UI_CALLBACK_GUARD_ACTIVE = False
_UI_CALLBACK_GUARD_INTERVAL = 0.10
_LEGACY_WATCHDOG_CALLBACK_REFS = set()
_UI_CALLBACK_GUARD_PANEL_PREFIXES = (
    'SMART_SELECTOR_SUITE_PT_',
    'SMART_SELECTOR_PT_',
    'SMART_SELECT_',
    'SMART_Selector_',
    'SMART_',
    'SMARTTOOLS_NPANEL_PT_',
    'SMARTTOOLS_PT_',
    'SMART_TOOLS_PT_',
)
_UI_CALLBACK_GUARD_EXACT = {
    'SMART_SELECTOR_SUITE_PT_root',
}
_UI_CALLBACK_GUARD_HEADERS = {
    'STATUSBAR_HT_header',
}

# Global UI callback shield.  Several Smart Tools can be installed and reloaded
# independently.  Blender 5.1 keeps C-side Panel/Header callback pointers; if an
# add-on deletes or sets draw to a non-callable after registration, Blender may
# crash before Python can report the TypeError.  Smart Transform installs a very
# narrow guard that only protects Blender UI callback attributes on UI classes.
_UI_CALLBACK_SHIELD_ACTIVE = False
_ORIGINAL_BUILTINS_SETATTR = None
_ORIGINAL_BUILTINS_DELATTR = None
_ORIGINAL_BPY_REGISTER_CLASS = None
_ORIGINAL_BPY_UNREGISTER_CLASS = None
_UI_CALLBACK_ATTRS = {
    'draw',
    'draw_header',
    'draw_header_preset',
    'draw_item',
    'draw_filter',
}


def _restore_legacy_builtin_callback_shield() -> None:
    """Restore builtins.setattr/delattr left patched by older in-session builds."""
    for attr_name, guard_name, original_name in (
        ('setattr', '_guarded_builtin_setattr', '_ORIGINAL_BUILTINS_SETATTR'),
        ('delattr', '_guarded_builtin_delattr', '_ORIGINAL_BUILTINS_DELATTR'),
    ):
        for _ in range(8):
            try:
                current = _builtins.__dict__.get(attr_name)
            except Exception:
                current = None
            if not callable(current) or str(getattr(current, '__name__', '') or '') != guard_name:
                break
            try:
                module_name = str(getattr(current, '__module__', '') or '')
                globals_dict = getattr(current, '__globals__', {}) or {}
            except Exception:
                module_name = ''
                globals_dict = {}
            if 'smart_transform' not in module_name.lower() and 'workspace_cleanup' not in module_name.lower():
                break
            original = globals_dict.get(original_name)
            if not callable(original) or original is current:
                break
            try:
                _builtins.__dict__[attr_name] = original
            except Exception:
                break


_restore_legacy_builtin_callback_shield()


def _noop_draw(self, context):
    return None


def _noop_poll(cls, context):
    # Compatibility only. UI callback repair must not use this for live Smart
    # Tool panels, because poll=False hides the entire N-panel category tab.
    return False


def _safe_issubclass(cls, base) -> bool:
    try:
        return isinstance(cls, type) and issubclass(cls, base)
    except Exception:
        return False


def _is_blender_ui_class(cls) -> bool:
    if bpy is None or not isinstance(cls, type):
        return False
    bases = []
    for name in ('Panel', 'Header', 'Menu', 'UIList'):
        try:
            base = getattr(bpy.types, name, None)
        except Exception:
            base = None
        if isinstance(base, type):
            bases.append(base)
    for base in bases:
        if _safe_issubclass(cls, base):
            return True
    return False


def _ui_class_needs_concrete_draw(cls) -> bool:
    if not _is_blender_ui_class(cls):
        return False
    try:
        name = str(getattr(cls, '__name__', '') or '')
        bl_id = str(getattr(cls, 'bl_idname', '') or '')
        module = str(getattr(cls, '__module__', '') or '')
    except Exception:
        name = bl_id = module = ''
    text = ' '.join((name, bl_id, module)).lower()
    if name in _UI_CALLBACK_GUARD_HEADERS or name in _UI_CALLBACK_GUARD_EXACT:
        return True
    if 'smart' in text or 'core_suite' in text or 'user_default' in text:
        return True
    return False


def _ensure_callback_attr(cls, attr: str) -> bool:
    if attr not in _UI_CALLBACK_ATTRS or not _is_blender_ui_class(cls):
        return False
    try:
        class_dict = getattr(cls, '__dict__', {}) or {}
        current = class_dict.get(attr, None)
    except Exception:
        current = None
    if callable(current):
        return False
    try:
        setter = _ORIGINAL_BUILTINS_SETATTR or _builtins.setattr
        setter(cls, attr, _noop_draw)
        return True
    except Exception:
        try:
            type.__setattr__(cls, attr, _noop_draw)
            return True
        except Exception:
            return False


def _ensure_ui_callbacks_before_registration(cls) -> None:
    if not _is_blender_ui_class(cls):
        return
    # Header/Menu/UIList classes still need their concrete draw callbacks before
    # registration.  For Panel classes, never synthesize draw_header or
    # draw_header_preset: registering those native callbacks is unnecessary for
    # this add-on and can crash Blender 5.1 during sidebar redraw on Windows.
    try:
        is_header = _safe_issubclass(cls, getattr(bpy.types, 'Header', object))
    except Exception:
        is_header = False
    try:
        is_menu = _safe_issubclass(cls, getattr(bpy.types, 'Menu', object))
    except Exception:
        is_menu = False
    try:
        is_ulist = _safe_issubclass(cls, getattr(bpy.types, 'UIList', object))
    except Exception:
        is_ulist = False
    try:
        is_panel = _safe_issubclass(cls, getattr(bpy.types, 'Panel', object))
    except Exception:
        is_panel = False
    if is_header or is_menu:
        _ensure_callback_attr(cls, 'draw')
        return
    if is_ulist:
        _ensure_callback_attr(cls, 'draw_item')
        return
    if is_panel and _ui_class_needs_concrete_draw(cls):
        _ensure_callback_attr(cls, 'draw')
        return


def _guarded_builtin_setattr(obj, name, value):
    if str(name or '') in _UI_CALLBACK_ATTRS and _is_blender_ui_class(obj):
        if not callable(value):
            value = _noop_draw
    setter = _ORIGINAL_BUILTINS_SETATTR or _builtins.setattr
    return setter(obj, name, value)


def _guarded_builtin_delattr(obj, name):
    if str(name or '') in _UI_CALLBACK_ATTRS and _is_blender_ui_class(obj):
        setter = _ORIGINAL_BUILTINS_SETATTR or _builtins.setattr
        try:
            setter(obj, name, _noop_draw)
            return None
        except Exception:
            pass
    deleter = _ORIGINAL_BUILTINS_DELATTR or _builtins.delattr
    return deleter(obj, name)


def _guarded_register_class(cls):
    try:
        _ensure_ui_callbacks_before_registration(cls)
    except Exception:
        pass
    register = _ORIGINAL_BPY_REGISTER_CLASS or bpy.utils.register_class
    return register(cls)


def _guarded_unregister_class(cls):
    try:
        _ensure_ui_callbacks_before_registration(cls)
    except Exception:
        pass
    unregister = _ORIGINAL_BPY_UNREGISTER_CLASS or bpy.utils.unregister_class
    return unregister(cls)


def install_ui_callback_shield() -> bool:
    """Compatibility no-op for older callers.

    Older builds installed a global builtins.setattr/delattr shield and
    repeatedly patched Panel.draw_header after registration.  Blender 5.1 can
    crash inside native panel_draw_header when a registered panel header callback
    is mutated while UI layout is active.  Startup safety now relies on removing
    stale Smart Transform proxy classes before registration and on providing only
    concrete draw callbacks at registration time.
    """
    return False


def stop_ui_callback_shield() -> None:
    return None


def _class_draw_callable(cls, attr='draw') -> bool:
    try:
        class_dict = getattr(cls, "__dict__", {}) or {}
        # Blender 5.1's registered Panel/Header callback lookup requires the
        # concrete class dictionary to contain the function.  Inherited methods may
        # appear callable through getattr(), but Blender can still report
        # "could not find function draw ..." for the registered subclass.
        return callable(class_dict.get(attr, None))
    except Exception:
        return False


def _repair_panel_class_callback(cls, *, disable_panel: bool = False, allow_reregister: bool = False) -> bool:
    del disable_panel, allow_reregister
    try:
        if not isinstance(cls, type):
            return False
    except Exception:
        return False
    # Do not mutate draw_header or draw_header_preset on already registered
    # panels.  Only repair a missing draw() callback on narrowly owned/stale
    # Smart Transform panels.
    try:
        if not _class_draw_callable(cls, 'draw'):
            setattr(cls, 'draw', _noop_draw)
            return True
    except Exception:
        pass
    return False


def _smart_tools_class_needs_callback_guard(cls) -> bool:
    try:
        name = str(getattr(cls, '__name__', '') or '')
        bl_id = str(getattr(cls, 'bl_idname', '') or '')
        module = str(getattr(cls, '__module__', '') or '')
        category = str(getattr(cls, 'bl_category', '') or '')
    except Exception:
        return False
    hay = ' '.join((name, bl_id, module, category)).lower()
    return any(token in hay for token in ('smart', 'core_suite', 'user_default'))


def repair_missing_ui_callbacks(*, allow_reregister: bool = False) -> bool:
    if bpy is None:
        return False
    changed = False

    def _repair_header(name: str) -> None:
        nonlocal changed
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            cls = None
        if isinstance(cls, type) and not _class_draw_callable(cls, 'draw'):
            try:
                setattr(cls, 'draw', _noop_draw)
                changed = True
            except Exception:
                pass

    def _repair_panel(cls) -> None:
        nonlocal changed
        try:
            if not isinstance(cls, type) or not _safe_is_subclass(cls, bpy.types.Panel):
                return
            if not _smart_tools_class_needs_callback_guard(cls):
                return
            if _repair_panel_class_callback(cls, disable_panel=False, allow_reregister=False):
                changed = True
            name = str(getattr(cls, '__name__', '') or '')
            if name in _UI_CALLBACK_GUARD_EXACT:
                try:
                    setattr(cls, 'draw', _noop_draw)
                    changed = True
                except Exception:
                    pass
        except Exception:
            pass

    for name in _UI_CALLBACK_GUARD_HEADERS:
        _repair_header(name)
    try:
        for cls in list(bpy.types.Panel.__subclasses__()):
            _repair_panel(cls)
    except Exception:
        pass
    try:
        names = list(dir(bpy.types))
    except Exception:
        names = []
    for name in names:
        try:
            text = str(name or '')
            if text not in _UI_CALLBACK_GUARD_EXACT and not text.startswith(_UI_CALLBACK_GUARD_PANEL_PREFIXES):
                continue
            _repair_panel(getattr(bpy.types, text, None))
        except Exception:
            continue
    for text in _UI_CALLBACK_GUARD_EXACT:
        try:
            _repair_panel(getattr(bpy.types, text, None))
        except Exception:
            pass
    return changed

def _ui_callback_guard_tick():
    return None


def neutralize_legacy_transform_watchdogs() -> None:
    """Keep and repeatedly unregister exact legacy CSDT watchdog callbacks."""
    try:
        import sys as _sys
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return
        for _name, _module in list(_sys.modules.items()):
            try:
                fn = getattr(_module, '_csdt_constraint_watchdog', None)
                if not callable(fn):
                    continue
                text = ' '.join((
                    str(_name or ''),
                    str(getattr(fn, '__module__', '') or ''),
                    str(getattr(getattr(fn, '__code__', None), 'co_filename', '') or ''),
                    str(getattr(_module, '__file__', '') or ''),
                )).replace('\\', '/').lower()
                if 'csdt_utils' not in text and 'smart_transform' not in text:
                    continue
                _LEGACY_WATCHDOG_CALLBACK_REFS.add(fn)
            except Exception:
                continue
        for fn in list(_LEGACY_WATCHDOG_CALLBACK_REFS):
            try:
                timers.unregister(fn)
            except Exception:
                pass
    except Exception:
        pass

def start_ui_callback_guard() -> None:
    # No periodic UI callback rewriting.  See install_ui_callback_shield().
    return None


def stop_ui_callback_guard() -> None:
    global _UI_CALLBACK_GUARD_ACTIVE
    _UI_CALLBACK_GUARD_ACTIVE = False
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_ui_callback_guard_tick):
            timers.unregister(_ui_callback_guard_tick)
    except Exception:
        pass


def clean_stale_operator_classes() -> bool:
    if bpy is None:
        return False
    changed = False
    for cls in _candidate_classes(bpy.types.Operator, prefixes=_STALE_OPERATOR_CLASS_PREFIXES, exact_names=set()):
        if not _safe_is_subclass(cls, bpy.types.Operator):
            continue
        if not _is_stale_suite_operator_class(cls):
            continue
        try:
            bpy.utils.unregister_class(cls)
            changed = True
        except Exception:
            pass
    return changed



def _iter_keyconfigs():
    """Crash-safe empty iterator; do not traverse keyconfigs during cleanup."""
    return ()

def _keymap_item_tool_name(kmi) -> str:
    # Do not inspect KeyMapItem.properties during startup cleanup.  On Blender
    # 5.1 stale OperatorProperties wrappers may crash natively.  Return a
    # non-empty sentinel so cleanup does not remove a binding solely because
    # its operator properties are unreadable.
    del kmi
    return '__unknown_tool_properties__'


def _kmi_should_remove(kmi) -> bool:
    try:
        idname = str(getattr(kmi, 'idname', '') or '').strip()
    except Exception:
        idname = ''
    if not idname:
        return False
    if idname == 'wm.tool_set_by_id':
        return False
    if idname in _STALE_OPERATOR_ID_EXACT:
        return True
    if idname.startswith(_STALE_OPERATOR_ID_PREFIXES):
        return True
    return False




def clean_invalid_view3d_tool_keymaps() -> bool:
    """Crash-safe no-op for invalid View3D tool keymap cleanup."""
    return False


# ------------------------------------------------------------------------------
# Persisted blend-data proxy cleanup
# ------------------------------------------------------------------------------
# This layer removes only metadata/proxy data that is unrelated to the current
# Smart Transform runtime.  It must not delete valid user geometry, visible
# objects, materials, actions, or currently used node groups.
_STALE_SCREEN_PROP_PREFIXES = (
    '_smart_tools_screen_owner_v',
    '_smart_tools_manager_proxy',
    '_smarttools_npanel_proxy',
)
_STALE_SCREEN_PROP_EXACT = {
    '_smart_tools_screen_owner_v300',
}
_STALE_WM_PROXY_KEYS = {
    'smart_transform_suite_persistent_feature_switches',
    'core_suite_persistent_feature_switches',
}
_MS_SHAPE_PROXY_KEYS = (
    'ms_shape_mesh_proxy_link_id',
    'ms_shape_mesh_proxy_source',
    'ms_shape_mesh_proxy_source_id',
    'ms_shape_mesh_proxy_object',
    'ms_shape_mesh_proxy_object_id',
)
_MS_SHAPE_INTERNAL_KEYS = (
    'ms_shape_proxy_internal',
    'ms_shape_curve_mesh_converter',
)
_BLEND_PROXY_CLEANUP_ACTIVE = False
_BLEND_PROXY_CLEANUP_LAST = 0.0
_BLEND_PROXY_CLEANUP_INTERVAL = 30.0
_BLEND_PROXY_CLEANUP_TIMER_INTERVAL = 30.0


def _idprop_keys(idblock) -> list[str]:
    try:
        return [str(k) for k in idblock.keys()]
    except Exception:
        return []


def _del_idprop(idblock, key: str) -> bool:
    try:
        if key in idblock:
            del idblock[key]
            return True
    except Exception:
        pass
    return False


def _object_by_name(name: object):
    if bpy is None:
        return None
    text = str(name or '').strip()
    if not text:
        return None
    try:
        return bpy.data.objects.get(text)
    except Exception:
        return None


def _has_valid_ms_shape_proxy_reference(obj) -> bool:
    """Return True only when a source object's proxy metadata resolves safely."""
    try:
        proxy_name = str(obj.get('ms_shape_mesh_proxy_object', '') or '').strip()
    except Exception:
        proxy_name = ''
    if not proxy_name:
        return False
    proxy_obj = _object_by_name(proxy_name)
    if proxy_obj is None:
        return False
    try:
        expected_id = str(obj.get('ms_shape_mesh_proxy_object_id', '') or '').strip()
        actual_id = str(proxy_obj.get('ms_shape_mesh_proxy_link_id', '') or '').strip()
        if expected_id and actual_id and expected_id != actual_id:
            return False
    except Exception:
        pass
    try:
        source_name = str(proxy_obj.get('ms_shape_mesh_proxy_source', '') or '').strip()
        if source_name and _object_by_name(source_name) is None:
            return False
    except Exception:
        pass
    return True


def _remove_ms_shape_proxy_props(obj) -> int:
    removed = 0
    for key in _MS_SHAPE_PROXY_KEYS:
        if _del_idprop(obj, key):
            removed += 1
    return removed


def _clean_stale_ms_shape_proxy_metadata() -> int:
    """Clean stale Smart Modeling/Smart Tools mesh-proxy metadata safely.

    The attached production file contains source objects whose
    ms_shape_mesh_proxy_object points to objects that no longer exist.  Those
    source-side properties are non-functional residue and can be removed without
    touching geometry.  Valid internal proxy objects/node groups are kept.
    """
    if bpy is None:
        return 0
    changed = 0
    try:
        objects = list(getattr(bpy.data, 'objects', ()))
    except Exception:
        objects = []
    for obj in objects:
        keys = set(_idprop_keys(obj))
        if not any(k in keys for k in _MS_SHAPE_PROXY_KEYS):
            continue
        # Internal proxy objects are behavior-affecting while their source still
        # exists.  Do not delete their metadata unless the source is missing.
        if 'ms_shape_proxy_internal' in keys:
            try:
                source_name = str(obj.get('ms_shape_mesh_proxy_source', '') or '').strip()
            except Exception:
                source_name = ''
            if source_name and _object_by_name(source_name) is not None:
                continue
            # Missing-source internal proxy is orphaned.  Keep the object itself
            # to avoid destructive geometry loss; remove only stale link props.
            changed += _remove_ms_shape_proxy_props(obj)
            continue
        if 'ms_shape_mesh_proxy_object' in keys and not _has_valid_ms_shape_proxy_reference(obj):
            changed += _remove_ms_shape_proxy_props(obj)
    # Remove orphan internal node groups only when they have no users.  Used node
    # groups can affect object geometry and must remain untouched.
    try:
        for ng in list(getattr(bpy.data, 'node_groups', ())):
            keys = set(_idprop_keys(ng))
            if not any(k in keys for k in _MS_SHAPE_INTERNAL_KEYS):
                continue
            try:
                users = int(getattr(ng, 'users', 0) or 0)
            except Exception:
                users = 1
            if users <= 0:
                try:
                    bpy.data.node_groups.remove(ng)
                    changed += 1
                except Exception:
                    pass
    except Exception:
        pass
    return changed


def _clean_stale_screen_proxy_props() -> int:
    if bpy is None:
        return 0
    changed = 0
    try:
        screens = list(getattr(bpy.data, 'screens', ()))
    except Exception:
        screens = []
    for screen in screens:
        for key in _idprop_keys(screen):
            low = key.lower()
            if key in _STALE_SCREEN_PROP_EXACT or any(low.startswith(prefix) for prefix in _STALE_SCREEN_PROP_PREFIXES):
                if _del_idprop(screen, key):
                    changed += 1
    return changed


def _clean_stale_window_manager_proxy_idprops(context=None, *, clear_runtime_collections: bool = False) -> int:
    if bpy is None:
        return 0
    changed = 0
    try:
        ctx = context or getattr(bpy, 'context', None)
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    except Exception:
        wm = None
    if wm is None:
        return 0
    for key in _idprop_keys(wm):
        low = key.lower()
        if key in _STALE_WM_PROXY_KEYS or 'smart_tools_manager_proxy' in low:
            if _del_idprop(wm, key):
                changed += 1
    # The current UI mirror collection is SKIP_SAVE and recreated from JSON when
    # drawn.  Clear duplicate/stale runtime rows only on forced cleanup paths
    # such as load/save/register; the periodic maintenance tick must not cause
    # visible N-panel button flicker.
    if clear_runtime_collections:
        for attr in tuple(_STALE_WM_PROXY_KEYS):
            try:
                coll = getattr(wm, attr, None)
            except Exception:
                coll = None
            if coll is None:
                continue
            try:
                while len(coll) > 0:
                    coll.remove(len(coll) - 1)
                    changed += 1
            except Exception:
                pass
    return changed


def _clean_stale_workspace_proxy_props() -> int:
    if bpy is None:
        return 0
    changed = 0
    try:
        workspaces = list(getattr(bpy.data, 'workspaces', ()))
    except Exception:
        workspaces = []
    for workspace in workspaces:
        for key in _idprop_keys(workspace):
            low = key.lower()
            if 'smart_tools_manager_proxy' in low or low.startswith('_smarttools_npanel_proxy'):
                if _del_idprop(workspace, key):
                    changed += 1
    return changed


def clean_persisted_legacy_proxy_data(context=None, *, force: bool = False) -> dict[str, int]:
    """Remove stale non-behavior proxy metadata already stored in the open .blend.

    This is intentionally conservative.  It removes stale source-side proxy
    links, obsolete screen/workspace/window-manager proxy metadata, and unused
    zero-user internal node groups.  It does not delete visible/user objects or
    used node groups because those can affect the production scene.
    """
    global _BLEND_PROXY_CLEANUP_LAST
    now = time.monotonic()
    if not force and (now - _BLEND_PROXY_CLEANUP_LAST) < 1.0:
        return {'total': 0, 'throttled': 1}
    _BLEND_PROXY_CLEANUP_LAST = now
    stats = {
        'screen_props': 0,
        'workspace_props': 0,
        'window_manager_props': 0,
        'mesh_proxy_props': 0,
        'total': 0,
    }
    try:
        stats['screen_props'] = _clean_stale_screen_proxy_props()
    except Exception:
        pass
    try:
        stats['workspace_props'] = _clean_stale_workspace_proxy_props()
    except Exception:
        pass
    try:
        stats['window_manager_props'] = _clean_stale_window_manager_proxy_idprops(context, clear_runtime_collections=bool(force))
    except Exception:
        pass
    try:
        stats['mesh_proxy_props'] = _clean_stale_ms_shape_proxy_metadata()
    except Exception:
        pass
    stats['total'] = sum(int(v or 0) for k, v in stats.items() if k != 'total')
    return stats


def _deferred_persisted_proxy_cleanup_tick():
    if not _BLEND_PROXY_CLEANUP_ACTIVE or bpy is None:
        return None
    try:
        clean_persisted_legacy_proxy_data(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    return None


def _periodic_persisted_proxy_cleanup_tick():
    """Compatibility terminator for periodic cleanup queued by older builds."""
    return None


def _queue_persisted_proxy_cleanup(delay: float = 0.25) -> None:
    if bpy is None:
        return
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_deferred_persisted_proxy_cleanup_tick, first_interval=max(0.0, float(delay)))
            return
    except Exception:
        pass
    try:
        _deferred_persisted_proxy_cleanup_tick()
    except Exception:
        pass


@persistent
def _persistent_proxy_cleanup_on_load_post(_dummy=None):
    _queue_persisted_proxy_cleanup(0.35)


@persistent
def _persistent_proxy_cleanup_on_save_pre(_dummy=None):
    try:
        clean_persisted_legacy_proxy_data(getattr(bpy, 'context', None), force=True)
    except Exception:
        pass


def start_persisted_proxy_data_cleanup(context=None) -> None:
    """Install load/save/timer cleanup for stale non-behavior proxy residue."""
    global _BLEND_PROXY_CLEANUP_ACTIVE
    if bpy is None:
        return
    _BLEND_PROXY_CLEANUP_ACTIVE = True
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            _load_hooks.add(_persistent_proxy_cleanup_on_load_post, 'load_post')
            _load_hooks.add(_persistent_proxy_cleanup_on_save_pre, 'save_pre')
    except Exception:
        pass
    try:
        clean_persisted_legacy_proxy_data(context or getattr(bpy, 'context', None), force=True)
    except Exception:
        pass
    # Register/load/save boundaries already cover cleanup.  Do not install a
    # periodic idle watchdog; stop() still unregisters callbacks left by older builds.


def stop_persisted_proxy_data_cleanup() -> None:
    global _BLEND_PROXY_CLEANUP_ACTIVE
    _BLEND_PROXY_CLEANUP_ACTIVE = False
    if bpy is None:
        return
    try:
        handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
        if handlers is not None:
            _load_hooks.remove(_persistent_proxy_cleanup_on_load_post, 'load_post')
            _load_hooks.remove(_persistent_proxy_cleanup_on_save_pre, 'save_pre')
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and timers.is_registered(_periodic_persisted_proxy_cleanup_tick):
            timers.unregister(_periodic_persisted_proxy_cleanup_tick)
    except Exception:
        pass


def cleanup(*, save: bool = False) -> bool:
    del save  # No automatic Save Preferences; do not alter user UI settings.
    changed = False
    for fn in (
        purge_stale_modules,
        clean_stale_panel_classes,
        clean_stale_operator_classes,
        clean_invalid_view3d_tool_keymaps,
        lambda: bool(clean_persisted_legacy_proxy_data(getattr(bpy, 'context', None), force=True).get('total', 0)) if bpy is not None else False,
    ):
        try:
            if fn():
                changed = True
        except Exception:
            pass
    return changed


def install() -> None:
    try:
        cleanup(save=False)
    except Exception:
        pass
    try:
        start_persisted_proxy_data_cleanup(getattr(bpy, 'context', None) if bpy is not None else None)
    except Exception:
        pass


def uninstall() -> None:
    # Do not restore invalid migrated keymap items or legacy proxy panels.
    try:
        stop_persisted_proxy_data_cleanup()
    except Exception:
        pass
