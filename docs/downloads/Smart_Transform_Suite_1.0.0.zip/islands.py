"""Apply a Blender transform to each connected selection around its own median."""
import bpy
import bmesh

def enabled(ctx):
    p=ctx.window_manager.smart_transform_suite_runtime_preferences
    return ctx.mode=="EDIT_MESH" and p.enable_mesh_island_transform and (not p.mesh_island_transform_individual_pivot_only or ctx.scene.tool_settings.transform_pivot_point=="INDIVIDUAL_ORIGINS")

def apply(ctx,mode,args):
    native=getattr(bpy.ops.transform,mode)
    if not enabled(ctx) or mode=="translate":
        return native("EXEC_DEFAULT",**args)
    meshes=[]
    groups=[]
    for obj in ctx.objects_in_mode_unique_data:
        bm=bmesh.from_edit_mesh(obj.data)
        selected={v for v in bm.verts if v.select and not v.hide}
        state=[e for seq in (bm.verts,bm.edges,bm.faces) for e in seq if e.select]
        meshes.append((obj,bm,state,list(bm.select_history)))
        while selected:
            stack=[selected.pop()];group=list(stack)
            while stack:
                vert=stack.pop()
                for edge in vert.link_edges:
                    neighbor=edge.other_vert(vert)
                    if neighbor in selected:
                        selected.remove(neighbor);stack.append(neighbor);group.append(neighbor)
            groups.append((obj,group))
    if len(groups)<2:return native("EXEC_DEFAULT",**args)
    settings=ctx.scene.tool_settings
    pivot,mode_bits=settings.transform_pivot_point,tuple(settings.mesh_select_mode)
    try:
        settings.transform_pivot_point="MEDIAN_POINT"
        settings.mesh_select_mode=(True,False,False)
        for obj,bm,_,_ in meshes:
            for geom in (bm.faces,bm.edges,bm.verts):
                for el in geom:el.select=False
            bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
        for obj,group in groups:
            for v in group:v.select=True
            bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
            result=native("EXEC_DEFAULT",**args)
            if "FINISHED" not in result:return result
            for v in group:v.select=False
            bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
        return {"FINISHED"}
    finally:
        settings.transform_pivot_point=pivot
        settings.mesh_select_mode=mode_bits
        for obj,bm,selected,history in meshes:
            for geom in (bm.faces,bm.edges,bm.verts):
                for el in geom:el.select=False
            for el in selected:el.select=True
            bm.select_history.clear()
            for el in history:
                if el.select:bm.select_history.add(el)
            bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)

