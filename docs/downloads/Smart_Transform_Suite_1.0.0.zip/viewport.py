import math
import bpy
from bpy.app.handlers import persistent
from mathutils import Matrix,Quaternion,Vector
from . import interaction,storage,transforms

def tool(ctx):
    try:return ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=False).idname
    except (AttributeError,RuntimeError,TypeError):return ""

def levers(ctx,loc,axes,objs,pts,wpts):
    """Per axis, remember the selected element reaching farthest from the centre along it (for objects,
    the own axis closest in direction to it), so a held resize handle can read the live scale factor back."""
    out={}
    for i,a in axes.items():
        best=None
        if pts:
            j=max(range(len(pts)),key=lambda n:abs((wpts[n]-loc).dot(a)))
            best=(pts[j][0],pts[j][1],None,(wpts[j]-loc).dot(a))
        else:
            key=-1.0
            for item in objs:
                m=transforms.world(ctx,item)
                for k in range(3):
                    col=m.col[k].xyz
                    c=abs(col.normalized().dot(a)) if col.length>1e-9 else 0.0
                    if c>key:key=c;best=(item,None,k,col.dot(a))
        if best and abs(best[3])>1e-5:out[i]=best
    return out

def factor(ctx,lever,loc,a):
    item,vert,k,rest=lever
    try:
        if vert is not None:return (item.matrix_world@vert.co-loc).dot(a)/rest
        col=transforms.world(ctx,item).col[k].xyz
    except (ReferenceError,AttributeError):return 1.0
    # Resizing along a, Blender keeps the rotation and gives each own axis the length it would have after
    # the resize (no shear): axis k grows by sqrt(1+(f*f-1)*c*c), c = cos(axis k, a). Solve that for f.
    ratio=col.dot(a)/rest
    c=col.normalized().dot(a)
    if abs(c)<1e-6:return 1.0
    return math.copysign(math.sqrt(max(0.0,1+(ratio*ratio-1)/(c*c))),ratio)

class SMARTTRANSFORM_GGT_axes(bpy.types.GizmoGroup):
    bl_idname="SMARTTRANSFORM_GGT_axes"
    bl_label="Smart Transform Handles"
    bl_space_type="VIEW_3D"
    bl_region_type="WINDOW"
    bl_options={"3D","PERSISTENT"}

    @classmethod
    def poll(cls,ctx):
        if not ctx.active_object or not hasattr(ctx.window_manager,"smart_transform_suite_runtime_preferences"):return False
        pref=interaction.prefs(ctx)
        return pref.enable_smart_gizmo_live_runtime and pref.enable_smart_gizmo_style and pref.gizmo_toggle_state and tool(ctx) in {"builtin.move","builtin.rotate","builtin.scale","builtin.transform"}

    def setup(self,ctx):
        self.handles=[];self.levers={};self.kept=None
        for action,shape in (("translate","GIZMO_GT_arrow_3d"),("rotate","GIZMO_GT_dial_3d"),("resize","GIZMO_GT_arrow_3d")):
            for i in range(3):
                g=self.gizmos.new(shape)
                if action=="resize":g.draw_style="BOX"
                g.alpha=.95;g.alpha_highlight=1;g.use_draw_modal=True
                op=g.target_set_operator("transform."+action)
                axes=[False]*3;axes[i]=True;op.constraint_axis=axes
                self.handles.append((g,action,i))
        self.planes=[]
        for action in ("translate","resize"):
            for axis in range(3):
                plane=self.gizmos.new("GIZMO_GT_primitive_3d")
                plane.draw_style="PLANE";plane.use_draw_offset_scale=True;plane.alpha=.32;plane.alpha_highlight=.85;plane.use_draw_modal=True
                target=plane.target_set_operator("transform."+action)
                target.constraint_axis=tuple(i!=axis for i in range(3))
                self.planes.append((plane,action,axis))
        self.free=self.gizmos.new("GIZMO_GT_move_3d")
        self.free.target_set_operator("transform.translate")
        self.free.alpha=.75;self.free.alpha_highlight=1;self.free.use_draw_modal=True

    def draw_prepare(self,ctx):
        p=interaction.prefs(ctx)
        mode=tool(ctx)
        objs=transforms.selected(ctx)
        loc=transforms.center([transforms.world(ctx,o).translation for o in objs]) if objs else ctx.active_object.matrix_world.translation
        pts=wpts=None
        if ctx.mode=="EDIT_MESH":
            pts=transforms.points(ctx)
            if pts:
                wpts=[o.matrix_world@v.co for o,v in pts]
                loc=transforms.center(wpts)
        spin=transforms.basis(ctx)
        axes={i:spin@Vector([float(k==i) for k in range(3)]) for i in range(3)}
        sizing=[g for g,action,i in self.handles if action=="resize"]
        if not any(g.is_modal for g in sizing):
            # Capture the rest state only while a resize handle is hovered, i.e. just before it is pressed.
            # pts is kept with the levers: its BMesh wrappers keep the stored vertices valid during the drag.
            hot=any(g.is_highlight for g in sizing)
            self.levers=levers(ctx,loc,axes,objs,pts,wpts) if hot else {}
            self.kept=pts if hot else None
        for g,action,i in self.handles:
            single={"translate":"builtin.move","rotate":"builtin.rotate","resize":"builtin.scale"}[action]
            allow={"translate":p.smart_gizmo_transform_show_move,"rotate":p.smart_gizmo_transform_show_rotate,"resize":p.smart_gizmo_transform_show_scale}[action]
            component={"translate":p.enable_move,"rotate":p.enable_rotate and p.enable_smart_gizmo_rotate,"resize":p.enable_scale and p.enable_smart_gizmo_scale}[action]
            g.hide=not (component and (mode==single or (mode=="builtin.transform" and p.enable_transform and p.enable_smart_gizmo_transform and allow)))
            direction=Vector((0,0,0));direction[i]=1
            orient=spin@direction.to_track_quat("Z","Y")
            basis=Matrix.Translation(loc)@orient.to_matrix().to_4x4()
            if action!="rotate" and g.is_modal:
                # A held arrow draws itself shifted by its own drag offset; take it back out so the
                # handle stays on the live centre of the selection.
                axis=basis.col[2].xyz
                basis.translation=loc-axis*(g.matrix_world.translation-g.matrix_basis.translation).dot(axis)
            g.matrix_basis=basis
            if action=="resize":
                lever=self.levers.get(i) if g.is_modal else None
                g.length=factor(ctx,lever,loc,axes[i]) if lever else 1.0
            g.color=tuple(getattr(p,"color_"+"xyz"[i]))[:3];g.color_highlight=tuple(p.color_highlight)[:3]
            g.scale_basis=p.smart_gizmo_screen_scale*p.smart_axis_scale*({"translate":1.1,"rotate":.8,"resize":.66}[action])
        for plane,action,i in self.planes:
            reference=next(g for g,kind,j in self.handles if kind==action and j==i)
            plane.hide=reference.hide or (action=="resize" and mode=="builtin.transform" and p.smart_gizmo_transform_show_move)
            u=Vector((0,0,0));v=u.copy();u[(i+1)%3]=1;v[(i+2)%3]=1
            orientation=Matrix((u,v,u.cross(v))).transposed().to_4x4()
            plane.matrix_basis=Matrix.Translation(loc)@spin.to_matrix().to_4x4()@orientation
            plane.scale_basis=.1*p.smart_gizmo_screen_scale*p.smart_plane_scale
            plane.matrix_offset=Matrix.Translation((2.8,2.8,0))
            plane.color=reference.color;plane.color_highlight=reference.color_highlight
        self.free.hide=mode not in {"builtin.move","builtin.transform"}
        self.free.matrix_basis=Matrix.Translation(loc);self.free.scale_basis=.12*p.smart_center_scale
        self.free.color=tuple(p.color_free)[:3];self.free.color_highlight=tuple(p.color_highlight)[:3]

_busy=False

@persistent
def update(scene,*_):
    global _busy
    if _busy or not hasattr(scene,"cursor_lock_props"):return
    _busy=True
    try:
        ctx=bpy.context
        lock=scene.cursor_lock_props
        if interaction.prefs(ctx).enable_cursor_lock_feature and lock.enabled and (scene.cursor.location-Vector(lock.lock_location)).length_squared>1e-16:
            scene.cursor.location=lock.lock_location
        if scene.select_guard_enabled and ctx.area and ctx.area.type=="VIEW_3D" and ctx.scene==scene and ctx.region_data:
            interaction.filter_selection(ctx)
    finally:_busy=False

@persistent
def save(*args):
    if storage.dirty:storage.save()

@persistent
def load(*args):storage.load()

def hooks():
    h=bpy.app.handlers
    return [(h.depsgraph_update_post,update),(h.save_pre,save),(h.load_pre,save),(h.load_post,load)]

def register():
    for l,f in hooks():
        if f not in l:l.append(f)
    if not bpy.app.timers.is_registered(load):bpy.app.timers.register(load,first_interval=0)

def unregister():
    from . import grs,align
    from . import picking
    picking.last_pick.clear()
    if align.followup is not None and bpy.app.timers.is_registered(align.followup):bpy.app.timers.unregister(align.followup)
    align.followup=None;align.preview=None;grs.cleanup()
    for f in (load,storage.timer):
        if bpy.app.timers.is_registered(f):bpy.app.timers.unregister(f)
    for l,f in hooks():
        if f in l:l.remove(f)
    save()
