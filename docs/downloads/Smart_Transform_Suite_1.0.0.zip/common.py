# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import inspect
import json
import os
import re
import sys
from pathlib import Path

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, StringProperty

try:
    from . import operator_safety as _op_safety
except Exception:  # pragma: no cover - package may be partially importing
    _op_safety = None

PACKAGE_ID = 'smart_transform_suite'
ADDON_NAME = 'Smart_Transform_Suite'
TOOL_LABEL_EN = 'Smart Transform'
TOOL_LABEL_JA = 'スマートトランスフォーム'
PANEL_CATEGORY = TOOL_LABEL_EN
_ALWAYS_ON_PROP = PACKAGE_ID + '_always_on_enabled'
_STORAGE_DIRNAME = 'user_data'

_PREVIEW_COLLECTION = None
_REGISTERED_CLASSES = []
_PATCHED_PANELS = []
_PATCHED_PREFERENCES = []

# Blender 5.1 native panel handling is sensitive to draw_header monkey-patching and
# broad WindowManager/Scene RNA scans during UI events.  The Smart Modeling style
# headers are drawn explicitly inside the N-panel, so the common layer keeps these
# compatibility patches disabled by default.
_ENABLE_NATIVE_PANEL_HEADER_PATCH = False
_ENABLE_COMMON_BROAD_PERSISTENCE = False
_PATCHED_POLLS = []
_ORIGINAL_REGISTER_CLASS = None
_REGISTER_PATCH_DEPTH = 0
_AUTOSAVE_FINGERPRINT = ''
_LOADED_SETTINGS = {}


_LIVE_TRANSFORM_PROP_NAMES = frozenset({
    'loc_x', 'loc_y', 'loc_z',
    'rot_x', 'rot_y', 'rot_z',
    'scale_x', 'scale_y', 'scale_z',
    'dim_x', 'dim_y', 'dim_z',
    'v_bevel', 'v_crease',
    'e_bevel', 'e_crease',
})


def _strip_live_transform_values(data):
    if isinstance(data, dict):
        return {
            key: _strip_live_transform_values(value)
            for key, value in data.items()
            if str(key) not in _LIVE_TRANSFORM_PROP_NAMES
        }
    if isinstance(data, list):
        return [_strip_live_transform_values(item) for item in data]
    return data

_TRANSLATIONS = {
    ('*', 'Help'): 'ヘルプ',
    ('*', 'Open Help'): 'ヘルプを開く',
    ('*', 'Feature Overview'): '機能概要',
    ('*', 'Usage'): '使用方法',
    ('*', 'Settings'): '設定項目',
    ('*', 'Commands'): 'コマンド',
    ('*', 'Always-on Toggle'): '常時機能切り替え',
    ('*', 'Enabled'): '有効',
    ('*', 'Disabled'): '無効',
    ('*', 'Save Preferences'): 'プリファレンスを保存',
    ('*', 'Settings are managed in the N-panel.'): '設定はNパネルで管理します。',
    ('*', 'Open the 3D View Sidebar and use this tool tab.'): '3Dビューのサイドバーを開き、このツールのタブを使用してください。',
    ('*', 'Open the detailed help popup for this tool group.'): 'このツールグループの詳細ヘルプポップアップを開きます。',
    ('*', 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'): '常時起動機能の有効/無効を切り替え、Nパネル設定を即座に保存します。',
    ('*', 'Save current N-panel settings to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json.'): '現在のNパネル設定をBlender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存します。',
    ('*', 'Target state for the selected always-on feature. The value is saved immediately after the operator runs.'): '選択した常時起動機能の目標状態です。値はオペレーター実行直後に保存されます。',
    ('*', 'Always-on'): '常時起動',
    ('*', 'Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.'): 'このツールの常時起動スイッチ（保存されます）です。補助動作を常駐させたい場合のみ有効にし、通常の手動使用では無効にしてください。',
    ('*', TOOL_LABEL_EN): TOOL_LABEL_JA,
}


def _ui_is_japanese(context=None):
    try:
        ctx = context or bpy.context
        view = getattr(getattr(ctx, 'preferences', None), 'view', None)
        if view is not None and not bool(getattr(view, 'use_translate_interface', True)):
            return False
        language = str(getattr(view, 'language', '') or '') if view is not None else ''
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '')
        raw = (locale or language).lower()
        return raw.startswith('ja')
    except Exception:
        return False


def text(en, ja=None, context=None):
    return str(ja if (ja is not None and _ui_is_japanese(context)) else en)


def package_root():
    return Path(__file__).resolve().parent


def storage_root(create=True):
    # Generated support files must remain under Blender's versioned
    # extensions/user_default repository, even when this source tree is opened
    # or tested from another directory.
    try:
        from . import runtime as _runtime
        root = _runtime.extension_user_default_storage_dir(__file__, folder_name=_STORAGE_DIRNAME, create=bool(create))
    except Exception:
        try:
            version = getattr(getattr(bpy, 'app', None), 'version', (5, 1))
            version_text = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
        except Exception:
            version_text = '5.1'
        if os.name == 'nt':
            roaming = os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Roaming')
            base = Path(roaming) / 'Blender Foundation' / 'Blender' / version_text / 'extensions' / 'user_default'
        elif sys.platform == 'darwin':
            base = Path.home() / 'Library' / 'Application Support' / 'Blender' / version_text / 'extensions' / 'user_default'
        else:
            base = Path.home() / '.config' / 'blender' / version_text / 'extensions' / 'user_default'
        root = base / PACKAGE_ID / _STORAGE_DIRNAME
    if create:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return root


def storage_path(*parts, create_parent=True):
    clean_parts = []
    for part in parts:
        value = str(part or '').replace('\\', '/').strip('/')
        if not value or value in {'.', '..'}:
            continue
        for piece in value.split('/'):
            if piece and piece not in {'.', '..'}:
                clean_parts.append(piece)
    path = storage_root(True).joinpath(*clean_parts)
    if create_parent:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    return path


def settings_path():
    try:
        base = Path(str(bpy.utils.user_resource('CONFIG', path='', create=True))) / 'Smart_Transform_Suite'
        base.mkdir(parents=True, exist_ok=True)
        return base / 'Smart_Transform_Suite.json'
    except Exception:
        return storage_path('settings', 'Smart_Transform_Suite', 'Smart_Transform_Suite.json')


def _load_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is not None:
        return _PREVIEW_COLLECTION
    try:
        import bpy.utils.previews
        pcoll = bpy.utils.previews.new()
        icons_dir = package_root() / 'icon' / 'resources'
        try:
            from . import ui_icons as _common_ui_icons
        except Exception:
            _common_ui_icons = None
        for name in ('header', 'help', 'clock'):
            resolved = name
            if _common_ui_icons is not None:
                try:
                    resolved = _common_ui_icons.resolved_icon_name(name) or name
                except Exception:
                    resolved = name
            path = icons_dir / (resolved + '.png')
            if path.exists():
                try:
                    pcoll.load(name, str(path), 'IMAGE')
                except Exception:
                    pass
        _PREVIEW_COLLECTION = pcoll
    except Exception:
        _PREVIEW_COLLECTION = None
    return _PREVIEW_COLLECTION


def icon_value(name, fallback=0):
    try:
        from . import ui_icons as _common_ui_icons
        value = _common_ui_icons.icon_value(name, 0)
        if value:
            return value
    except Exception:
        pass
    pcoll = _load_previews()
    try:
        item = pcoll.get(str(name)) if pcoll is not None else None
        return int(getattr(item, 'icon_id', fallback) or fallback)
    except Exception:
        return fallback


def _remove_previews():
    global _PREVIEW_COLLECTION
    if _PREVIEW_COLLECTION is None:
        return
    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(_PREVIEW_COLLECTION)
    except Exception:
        pass
    _PREVIEW_COLLECTION = None


def _translation_payload():
    data = dict(_TRANSLATIONS)
    try:
        from . import language_extra
        extra = getattr(language_extra, 'EXTRA_TRANSLATIONS', {})
        if isinstance(extra, dict):
            data.update(extra)
    except Exception:
        pass
    return {'ja_JP': data}


def _wrap_lines(value, width_px):
    import textwrap
    text_value = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    # Approximate Blender UI label width.  This wraps only when the line would
    # exceed the popup width rather than at a fixed text width.
    chars = max(26, min(160, int(max(260, width_px) / 7)))
    lines = []
    for para in text_value.split('\n'):
        raw = para.strip()
        if not raw:
            lines.append('')
            continue
        wrapped = textwrap.wrap(raw, width=chars, break_long_words=False, break_on_hyphens=False)
        lines.extend(wrapped or [raw])
    return lines


def _smart_common_noop_draw(self, context):
    return None

def _draw_wrapped(layout, context, value, icon='NONE'):
    try:
        width = int(getattr(getattr(context, 'region', None), 'width', 620) or 620)
    except Exception:
        width = 620
    first = True
    for line in _wrap_lines(value, width):
        if not line:
            layout.separator(factor=0.35)
        elif first and icon != 'NONE':
            layout.label(text=line, icon=icon)
            first = False
        else:
            layout.label(text=line)
            first = False


def _group_text_list(group, key_en, key_ja, context=None):
    values = group.get(key_ja if _ui_is_japanese(context) else key_en) or []
    if isinstance(values, str):
        return [values]
    if isinstance(values, (list, tuple)):
        return [str(v) for v in values]
    return []


_HELP_TOPIC_ALIASES = {
    '': 'integrated_tools',
    'overview': 'integrated_tools',
    'VIEW3D_PT_core_suite': 'core_panel',
    'view3d_pt_core_suite': 'core_panel',
    'SMART_TRANSFORM_PT_always_on': 'always_on_toggles',
    'smart_transform_pt_always_on': 'always_on_toggles',
    'VIEW3D_PT_select_guard_popover': 'smart_select_guard_settings',
    'view3d_pt_select_guard_popover': 'smart_select_guard_settings',
    'QuickAlignSettings': 'quick_align',
    'quickalignsettings': 'quick_align',
    'QuickMultiEditPreferences': 'quick_multi_edit',
    'quickmultieditpreferences': 'quick_multi_edit',
    'SSG_AddonPreferences': 'smart_select_guard_settings',
    'ssg_addonpreferences': 'smart_select_guard_settings',
}


def _help_topic_key(topic):
    key = str(topic or '').strip()
    return _HELP_TOPIC_ALIASES.get(key) or _HELP_TOPIC_ALIASES.get(key.lower()) or key or 'integrated_tools'


_HELP_FALLBACK_WIDTH_PX = 680


class SMART_TRANSFORM_OT_open_help(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.open_help'
    bl_label = 'Open Help'
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = 'Open the detailed help popup for this tool group.'

    topic: StringProperty(name='Help Topic', description='Internal help topic key used to open the correct Smart Transform help popup from an N-panel header button.', default='overview', options={'SKIP_SAVE'})

    def invoke(self, context, event):
        del event
        topic = _help_topic_key(getattr(self, 'topic', 'overview'))
        try:
            from . import help as _help
            _help.show_help_popup(context, topic)
            return {'FINISHED'}
        except Exception:
            try:
                self.topic = topic
            except Exception:
                pass
            try:
                return context.window_manager.invoke_popup(self, width=_HELP_FALLBACK_WIDTH_PX)
            except Exception:
                return self.execute(context)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        topic = _help_topic_key(getattr(self, 'topic', '') or 'overview')
        try:
            from . import help as _help
            _help._draw_topic(layout, context, topic, popup_width=_HELP_FALLBACK_WIDTH_PX)
            return
        except Exception:
            group = {
                'title_en': TOOL_LABEL_EN + ' Help',
                'title_ja': TOOL_LABEL_JA + ' ヘルプ',
                'overview_en': ['The help could not be loaded.'],
                'overview_ja': ['ヘルプを読み込めませんでした。'],
                'usage_en': [],
                'usage_ja': [],
                'settings': [],
                'operators': [],
            }
        title = group.get('title_ja' if _ui_is_japanese(context) else 'title_en') or TOOL_LABEL_EN
        row = layout.row(align=True)
        row.label(text=str(title), icon='QUESTION')
        layout.separator()
        box = layout.box()
        box.label(text=text('Feature Overview', '機能概要', context), icon='TEXT')
        for item in _group_text_list(group, 'overview_en', 'overview_ja', context):
            _draw_wrapped(box, context, item)
        box = layout.box()
        box.label(text=text('Usage', '使用方法', context), icon='PLAY')
        for item in _group_text_list(group, 'usage_en', 'usage_ja', context):
            _draw_wrapped(box, context, item)
        settings = group.get('settings') or []
        ops = group.get('operators') or []
        box = layout.box()
        box.label(text=text('Settings', '設定項目', context), icon='PREFERENCES')
        if not settings and not ops:
            _draw_wrapped(box, context, text(
                'No individual settings were detected for this group. Use the visible controls and their tooltips for short descriptions.',
                'このグループ専用の設定項目は検出されませんでした。表示されている各コントロールとツールチップを確認してください。',
                context,
            ))
        for item in settings[:240]:
            name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
            desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
            _draw_wrapped(box, context, '• ' + str(name) + ': ' + str(desc))
        if ops:
            cmd_box = layout.box()
            cmd_box.label(text=text('Commands', 'コマンド', context), icon='TOOL_SETTINGS')
            for item in ops[:240]:
                name = item.get('name_ja' if _ui_is_japanese(context) else 'name_en') or item.get('key') or ''
                desc = item.get('description_ja' if _ui_is_japanese(context) else 'description_en') or ''
                _draw_wrapped(cmd_box, context, '• ' + str(name) + ': ' + str(desc))


class SMART_TRANSFORM_OT_set_always_on(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.set_always_on'
    bl_label = 'Always-on Toggle'
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = 'Set an always-on feature to enabled or disabled and save the N-panel setting immediately.'

    alias: StringProperty(name='Feature Alias', description='Internal always-on feature group alias passed from the N-panel toggle button.', default='', options={'SKIP_SAVE'})
    feature_key: StringProperty(name='Feature Key', description='Internal always-on feature key passed from the N-panel toggle button.', default='', options={'SKIP_SAVE'})
    enabled: BoolProperty(name='Enabled', description='Target state for the selected always-on feature. The value is saved immediately after the operator runs.', default=False, options={'SKIP_SAVE'})

    def execute(self, context):
        done = False
        alias = str(getattr(self, 'alias', '') or '')
        feature_key = str(getattr(self, 'feature_key', '') or '')
        if alias and feature_key:
            try:
                from . import feature_toggle
                setter = getattr(feature_toggle, 'set_feature_enabled', None)
                if callable(setter):
                    done = bool(setter(alias, feature_key, bool(self.enabled)))
            except Exception:
                self.report({'WARNING'}, text('The setting could not be changed.', '設定を変更できませんでした。', context))
        if not done:
            try:
                setattr(context.window_manager, _ALWAYS_ON_PROP, bool(self.enabled))
                done = True
            except Exception:
                self.report({'WARNING'}, text('The setting could not be changed.', '設定を変更できませんでした。', context))
        try:
            save_persistent_settings(context, force=True)
        except Exception:
            pass
        try:
            from . import settings as _settings
            _settings.request_save('always_on_toggle', context=context)
        except Exception:
            pass
        return {'FINISHED'}


class SMART_TRANSFORM_OT_save_preferences(bpy.types.Operator):
    bl_idname = PACKAGE_ID + '.save_preferences'
    bl_label = 'Save Preferences'
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = 'Save current N-panel settings to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json.'

    def execute(self, context):
        save_persistent_settings(context, force=True)
        try:
            from . import settings as _settings
            _settings.save_now(context, force=True, bypass_policy=True)
        except Exception:
            pass
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        try:
            from . import settings as _settings
            _settings.save_now(context, force=True, bypass_policy=True)
        except Exception:
            pass
        self.report({'INFO'}, text('Preferences saved.', 'プリファレンスを保存しました。', context))
        return {'FINISHED'}


# The standalone Always-on Toggle panel was intentionally removed.  The same
# controls are drawn only inside the main Smart Transform N-panel to avoid a
# duplicate sidebar section.


def _feature_entries():
    try:
        from . import feature_toggle
        entries_fn = getattr(feature_toggle, 'feature_entries', None)
        aliases_fn = getattr(feature_toggle, 'all_feature_aliases', None)
        if callable(entries_fn):
            aliases = list(aliases_fn()) if callable(aliases_fn) else []
            if aliases:
                out = []
                for alias in aliases:
                    try:
                        out.extend(list(entries_fn(alias)))
                    except Exception:
                        pass
                return out
            return list(entries_fn())
    except Exception:
        pass
    return []


def _entry_text(entry, key_en, key_ja, fallback='', context=None):
    if _ui_is_japanese(context):
        value = entry.get(key_ja) or entry.get(key_en) or fallback
    else:
        value = entry.get(key_en) or entry.get(key_ja) or fallback
    return str(value or '').strip()


def _safe_set_operator_prop(op, prop_name: str, value, *, operator_id: str) -> bool:
    try:
        if _op_safety is not None:
            return bool(_op_safety.safe_set_operator_property(op, prop_name, value, operator_id=operator_id, strict=True))
    except Exception:
        pass
    # Do not fall back to direct setattr here.  Blender prints native
    # "property ... not found in item OperatorProperties" warnings before
    # Python can catch the assignment failure.  Returning False is safer than
    # emitting warnings from legacy or inactive operator buttons.
    return False


def draw_always_on_panel(layout, context):
    col = layout.column(align=True)
    entries = _feature_entries()
    if entries:
        for item in entries:
            alias = str(item.get('alias') or '')
            feature_key = str(item.get('key') or item.get('feature_key') or '')
            label = _entry_text(item, 'label_en', 'label_ja', feature_key or TOOL_LABEL_EN, context)
            enabled = bool(item.get('enabled'))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
            _safe_set_operator_prop(op, 'alias', alias, operator_id=PACKAGE_ID + '.set_always_on')
            _safe_set_operator_prop(op, 'feature_key', feature_key, operator_id=PACKAGE_ID + '.set_always_on')
            _safe_set_operator_prop(op, 'enabled', True, operator_id=PACKAGE_ID + '.set_always_on')
            op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
            _safe_set_operator_prop(op, 'alias', alias, operator_id=PACKAGE_ID + '.set_always_on')
            _safe_set_operator_prop(op, 'feature_key', feature_key, operator_id=PACKAGE_ID + '.set_always_on')
            _safe_set_operator_prop(op, 'enabled', False, operator_id=PACKAGE_ID + '.set_always_on')
        return
    enabled = bool(getattr(context.window_manager, _ALWAYS_ON_PROP, False))
    row = col.row(align=True)
    row.label(text=TOOL_LABEL_EN)
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Enabled', '有効', context), depress=enabled)
    _safe_set_operator_prop(op, 'enabled', True, operator_id=PACKAGE_ID + '.set_always_on')
    op = row.operator(PACKAGE_ID + '.set_always_on', text=text('Disabled', '無効', context), depress=not enabled)
    _safe_set_operator_prop(op, 'enabled', False, operator_id=PACKAGE_ID + '.set_always_on')


def _module_prefix():
    package = str(__package__ or '').strip()
    return package or PACKAGE_ID


def _same_package_class(cls):
    module_name = str(getattr(cls, '__module__', '') or '')
    prefix = _module_prefix()
    return bool(prefix and (module_name == prefix or module_name.startswith(prefix + '.')))


_REMOVED_STANDALONE_ALWAYS_ON_PANEL_IDS = {'SMART_TRANSFORM_PT_always_on'}


def _is_removed_standalone_always_on_panel(cls):
    try:
        name = str(getattr(cls, '__name__', '') or '')
        bl_idname = str(getattr(cls, 'bl_idname', '') or '')
    except Exception:
        return False
    return name in _REMOVED_STANDALONE_ALWAYS_ON_PANEL_IDS or bl_idname in _REMOVED_STANDALONE_ALWAYS_ON_PANEL_IDS


def _unregister_removed_standalone_always_on_panels():
    """Remove the legacy standalone always-on N-panel.

    The Always-on Toggle UI is drawn inside the main Smart Transform panel.
    A separate Panel with the same title duplicates the N-panel entry, so it is
    deliberately not registered and any stale class from an older reload is
    unregistered when possible.
    """
    try:
        values = [getattr(bpy.types, name, None) for name in _REMOVED_STANDALONE_ALWAYS_ON_PANEL_IDS]
    except Exception:
        values = []
    for cls in values:
        if isinstance(cls, type) and _is_removed_standalone_always_on_panel(cls):
            try:
                if _same_package_class(cls):
                    _safe_unregister_class(cls)
            except Exception:
                pass


def _clean_label(label):
    raw = str(label or '').strip()
    if not raw:
        return raw
    for token in (' Suite', '_Suite', ' Toolset'):
        raw = raw.replace(token, '')
    if raw == ADDON_NAME or raw.replace('_', ' ') == ADDON_NAME.replace('_', ' '):
        return TOOL_LABEL_EN
    return raw


def _old_generated_name(name):
    text_value = str(name or '')
    upper = text_value.upper()
    return (
        '_SUITE_OT_OPEN_HELP' in upper or
        '_SUITE_OT_SET_ALWAYS_ON' in upper or
        '_SUITE_PT_ROOT' in upper or
        '_SUITE_PT_ALWAYS_ON' in upper
    )


def _is_valid_blender_update_callback(callback):
    if callback is None:
        return True
    if not callable(callback):
        return False
    try:
        signature = inspect.signature(callback)
        positional = [
            p for p in signature.parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        has_varargs = any(p.kind == p.VAR_POSITIONAL for p in signature.parameters.values())
        required = [p for p in positional if p.default is p.empty]
        if has_varargs:
            return len(required) <= 2
        return len(positional) >= 2 and len(required) <= 2
    except Exception:
        pass
    try:
        code = getattr(callback, '__code__', None)
        if code is not None:
            argc = int(getattr(code, 'co_argcount', 0)) + int(getattr(code, 'co_posonlyargcount', 0))
            return argc == 2
    except Exception:
        pass
    return True


def _sanitize_property_keywords_for_registration(kwargs):
    if isinstance(kwargs, dict) and 'update' in kwargs and not _is_valid_blender_update_callback(kwargs.get('update')):
        kwargs = dict(kwargs)
        kwargs.pop('update', None)
    return kwargs


def _safe_property_factory_for_eval(factory):
    def _factory(*args, **kwargs):
        kwargs = _sanitize_property_keywords_for_registration(kwargs)
        return factory(*args, **kwargs)
    try:
        _factory.__name__ = getattr(factory, '__name__', 'Property')
    except Exception:
        pass
    return _factory


def _materialize_annotations(cls):
    if not isinstance(cls, type):
        return cls
    try:
        annotations = dict(getattr(cls, '__annotations__', {}) or {})
    except Exception:
        annotations = {}
    module = sys.modules.get(str(getattr(cls, '__module__', '') or ''))
    namespace = {}
    if module is not None:
        try:
            namespace.update(getattr(module, '__dict__', {}) or {})
        except Exception:
            pass
    try:
        # Class-local callbacks such as QuickAlignSettings._preset_update are
        # referenced by annotation strings when future annotations are active.
        # Add the class namespace so those update callbacks materialize as real
        # two-argument functions instead of being left for Blender to resolve.
        namespace.update(dict(getattr(cls, '__dict__', {}) or {}))
    except Exception:
        pass
    namespace.setdefault('bpy', bpy)
    prop_names = (
        'BoolProperty', 'BoolVectorProperty', 'CollectionProperty', 'EnumProperty',
        'FloatProperty', 'FloatVectorProperty', 'IntProperty', 'IntVectorProperty',
        'PointerProperty', 'StringProperty',
    )
    for prop_name in prop_names:
        try:
            namespace[prop_name] = _safe_property_factory_for_eval(getattr(bpy.props, prop_name))
        except Exception:
            pass
    changed = False
    for name, value in list(annotations.items()):
        if isinstance(value, str) and 'Property' in value and '(' in value:
            expr = value.strip().replace('bpy.props.', '')
            try:
                annotations[name] = eval(expr, namespace, namespace)
                changed = True
            except Exception:
                pass
    try:
        is_operator = issubclass(cls, bpy.types.Operator)
    except Exception:
        is_operator = False
    if is_operator:
        # Blender UI code frequently assigns these operator properties from
        # buttons. If a legacy class forgot to declare them, adding harmless
        # saved-skipped string properties prevents "property not found" warnings.
        string_compat_props = ('mode', 'action', 'type', 'topic', 'topic_key', 'category', 'profile', 'target_operator', 'module_key', 'alias', 'feature_key', 'collection_name', 'prop_name', 'text', 'report_label')
        bool_compat_props = ('quick', 'enabled')
        for prop_name in string_compat_props:
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.StringProperty(name=prop_name, description='', default='', options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
        for prop_name in bool_compat_props:
            if prop_name not in annotations:
                try:
                    annotations[prop_name] = bpy.props.BoolProperty(name=prop_name, description='', default=False, options={'SKIP_SAVE'})
                    changed = True
                except Exception:
                    pass
    if changed:
        try:
            setattr(cls, '__annotations__', annotations)
        except Exception:
            pass
    return cls


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
        return True
    except Exception:
        return False


def _register_class_wrapper(cls):
    _materialize_annotations(cls)
    try:
        from . import workspace_cleanup as _wc
        _fn = getattr(_wc, '_ensure_ui_callbacks_before_registration', None)
        if callable(_fn):
            _fn(cls)
    except Exception:
        pass
    try:
        from . import operator_safety as _op_safety
        _module_name = str(getattr(cls, '__module__', '') or '')
        _own_operator = _same_package_class(cls) or 'smart_transform_suite' in _module_name or 'Smart_Transform_Suite' in _module_name
        if _own_operator and callable(getattr(_op_safety, 'prepare_operator_class_for_registration', None)):
            _op_safety.prepare_operator_class_for_registration(cls)
        else:
            for _name in ('normalize_operator_class_for_registration', 'normalize_operator_methods_for_registration', 'restore_operator_class_method_signatures'):
                _fn = getattr(_op_safety, _name, None)
                if callable(_fn):
                    _fn(cls)
    except Exception:
        pass
    try:
        existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
        if isinstance(existing, type) and existing is not cls:
            if _same_package_class(existing) or _old_generated_name(getattr(existing, '__name__', '')):
                _safe_unregister_class(existing)
    except Exception:
        pass
    try:
        return _ORIGINAL_REGISTER_CLASS(cls)
    except ValueError:
        # Already registered: this normally means Blender kept a class from a
        # failed previous load. Try one clean unregister/register cycle.
        try:
            existing = getattr(bpy.types, str(getattr(cls, '__name__', '') or ''), None)
            if isinstance(existing, type):
                _safe_unregister_class(existing)
        except Exception:
            pass
        return _ORIGINAL_REGISTER_CLASS(cls)


def begin_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH += 1
    if _ORIGINAL_REGISTER_CLASS is not None:
        return
    try:
        _ORIGINAL_REGISTER_CLASS = bpy.utils.register_class
        bpy.utils.register_class = _register_class_wrapper
    except Exception:
        _ORIGINAL_REGISTER_CLASS = None


def end_register():
    global _ORIGINAL_REGISTER_CLASS, _REGISTER_PATCH_DEPTH
    _REGISTER_PATCH_DEPTH = max(0, _REGISTER_PATCH_DEPTH - 1)
    if _REGISTER_PATCH_DEPTH > 0:
        return
    if _ORIGINAL_REGISTER_CLASS is not None:
        try:
            bpy.utils.register_class = _ORIGINAL_REGISTER_CLASS
        except Exception:
            pass
    _ORIGINAL_REGISTER_CLASS = None


def _iter_relevant_panels():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.Panel):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        if _is_removed_standalone_always_on_panel(cls):
            continue
        yield cls


def _is_always_panel(cls):
    value = ' '.join((
        str(getattr(cls, '__name__', '') or ''),
        str(getattr(cls, 'bl_idname', '') or ''),
        str(getattr(cls, 'bl_label', '') or ''),
    )).lower()
    return ('always' in value or '常時' in value or 'persistent' in value) and 'catalog' not in value


def _patch_panel_headers():
    if not _ENABLE_NATIVE_PANEL_HEADER_PATCH:
        return
    for cls in _iter_relevant_panels():
        try:
            cls.bl_category = PANEL_CATEGORY
        except Exception:
            pass
        try:
            label = str(getattr(cls, 'bl_label', '') or '')
            clean = _clean_label(label)
            if clean and clean != label:
                cls.bl_label = clean
        except Exception:
            pass
        if _is_always_panel(cls):
            try:
                original_poll = getattr(cls, 'poll', None)
                cls.poll = classmethod(lambda _cls, context: False)
                _PATCHED_POLLS.append((cls, original_poll))
            except Exception:
                pass
            continue
        if getattr(cls, '_smart_common_header_patched', False):
            continue
        original = getattr(cls, 'draw_header', None)
        topic = str(getattr(cls, '__name__', '') or 'overview')

        def _draw_header(self, context, _topic=topic):
            try:
                # Smart Selector style: a direct minimum-size QUESTION operator.
                # Avoid separator_spacer() and nested right-aligned rows because
                # Blender 5.1 can retain stair-step indentation after panel redraws.
                row = self.layout.row(align=True)
                try:
                    row.scale_x = 0.82
                    row.scale_y = 1.0
                except Exception:
                    pass
                op = row.operator(PACKAGE_ID + '.open_help', text='', icon='QUESTION', emboss=True)
                _safe_set_operator_prop(op, 'topic', _topic, operator_id=PACKAGE_ID + '.open_help')
            except Exception:
                pass

        try:
            cls.draw_header = _draw_header
            cls._smart_common_header_patched = True
            _PATCHED_PANELS.append((cls, original))
        except Exception:
            pass


def _unpatch_panel_headers():
    for cls, original in reversed(_PATCHED_PANELS):
        try:
            if original is None:
                cls.draw_header = _smart_common_noop_draw
            else:
                cls.draw_header = original
            if hasattr(cls, '_smart_common_header_patched'):
                delattr(cls, '_smart_common_header_patched')
        except Exception:
            pass
    _PATCHED_PANELS.clear()
    for cls, original in reversed(_PATCHED_POLLS):
        try:
            if original is None:
                if hasattr(cls, 'poll'):
                    delattr(cls, 'poll')
            else:
                cls.poll = original
        except Exception:
            pass
    _PATCHED_POLLS.clear()


def _iter_relevant_addon_preferences():
    prefix = _module_prefix()
    values = []
    try:
        for name in dir(bpy.types):
            try:
                values.append(getattr(bpy.types, name))
            except Exception:
                pass
    except Exception:
        values = []
    seen = set()
    for cls in values:
        if not isinstance(cls, type):
            continue
        ident = id(cls)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if not issubclass(cls, bpy.types.AddonPreferences):
                continue
        except Exception:
            continue
        module_name = str(getattr(cls, '__module__', '') or '')
        if prefix and not (module_name == prefix or module_name.startswith(prefix + '.')):
            continue
        yield cls


def _patch_addon_preferences():
    if not _ENABLE_NATIVE_PANEL_HEADER_PATCH:
        return
    for cls in _iter_relevant_addon_preferences():
        if getattr(cls, '_smart_common_preferences_patched', False):
            continue
        original = getattr(cls, 'draw', None)

        def _draw_npanel_only(self, context):
            del context
            return None

        try:
            cls.draw = _draw_npanel_only
            cls._smart_common_preferences_patched = True
            _PATCHED_PREFERENCES.append((cls, original))
        except Exception:
            pass


def _unpatch_addon_preferences():
    for cls, original in reversed(_PATCHED_PREFERENCES):
        try:
            if original is None:
                cls.draw = _smart_common_noop_draw
            else:
                cls.draw = original
            if hasattr(cls, '_smart_common_preferences_patched'):
                delattr(cls, '_smart_common_preferences_patched')
        except Exception:
            pass
    _PATCHED_PREFERENCES.clear()


def _simple_rna_value(value):
    if isinstance(value, (bool, int, float, str)) or value is None:
        return value
    return None


def _iter_setting_roots(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return []
    roots = []
    for attr in ('window_manager', 'scene'):
        root = getattr(ctx, attr, None)
        if root is not None:
            roots.append((attr, root))
    return roots


def _prop_relevant(name, value, owner=None):
    lower = str(name or '').lower()
    if lower == _ALWAYS_ON_PROP.lower() or lower.startswith(PACKAGE_ID.lower()):
        return True
    prefixes = ('smart_', 'ui_', 'enable_', 'show_', 'use_', 'auto_', 'sfs_', 'sf_', 'sas_', 'scsmart_', 'scs_', 'sgn_', 'sms_', 'smod_', 'sps_', 'srs_', 'srig_', 'ssel_', 'suv_', 'uv_', 'sw_', 'st_', 'sk_', 'sss_')
    if any(lower.startswith(prefix) for prefix in prefixes):
        return True
    try:
        module_name = str(getattr(type(value), '__module__', '') or '').lower()
        prefix = _module_prefix().lower()
        if prefix and module_name.startswith(prefix):
            return True
    except Exception:
        pass
    return False


def _serialize_group(obj, depth=0):
    if depth > 2 or obj is None:
        return {}
    data = {}
    try:
        props = getattr(getattr(obj, 'rna_type', None), 'properties', [])
    except Exception:
        props = []
    for prop in props:
        try:
            identifier = str(getattr(prop, 'identifier', '') or '')
            if not identifier or identifier == 'rna_type' or getattr(prop, 'is_readonly', False):
                continue
            if identifier in _LIVE_TRANSFORM_PROP_NAMES:
                continue
            value = getattr(obj, identifier)
            simple = _simple_rna_value(value)
            if simple is not None:
                if _prop_relevant(identifier, value, obj):
                    data[identifier] = simple
            elif _prop_relevant(identifier, value, obj):
                nested = _serialize_group(value, depth + 1)
                if nested:
                    data[identifier] = nested
        except Exception:
            continue
    return data


def collect_persistent_settings(context=None):
    if not _ENABLE_COMMON_BROAD_PERSISTENCE:
        return {}
    payload = {}
    for root_name, root in _iter_setting_roots(context):
        data = _serialize_group(root, 0)
        if data:
            payload[root_name] = data
    return payload


def _apply_group(obj, data, depth=0):
    if depth > 2 or not isinstance(data, dict):
        return
    for key, value in data.items():
        if str(key) in _LIVE_TRANSFORM_PROP_NAMES:
            continue
        try:
            if isinstance(value, dict):
                child = getattr(obj, key, None)
                if child is not None:
                    _apply_group(child, value, depth + 1)
            elif hasattr(obj, key):
                setattr(obj, key, value)
        except Exception:
            pass


def apply_persistent_settings(context=None):
    if not _ENABLE_COMMON_BROAD_PERSISTENCE:
        return
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    data = _strip_live_transform_values(_LOADED_SETTINGS or load_settings_file())
    restore_mod = None
    old_restoring = False
    try:
        from . import settings as restore_mod
        old_restoring = bool(getattr(restore_mod, '_RESTORING', False))
        setattr(restore_mod, '_RESTORING', True)
    except Exception:
        restore_mod = None
    try:
        for root_name, root in _iter_setting_roots(ctx):
            if root_name in data:
                _apply_group(root, data[root_name], 0)
    finally:
        if restore_mod is not None:
            try:
                setattr(restore_mod, '_RESTORING', old_restoring)
            except Exception:
                pass


def load_settings_file():
    global _LOADED_SETTINGS
    path = settings_path()
    try:
        if path.exists():
            raw = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                _LOADED_SETTINGS = raw
                return raw
    except Exception:
        pass
    _LOADED_SETTINGS = {}
    return {}


def save_persistent_settings(context=None, force=False):
    global _AUTOSAVE_FINGERPRINT
    if not _ENABLE_COMMON_BROAD_PERSISTENCE:
        return
    data = _strip_live_transform_values(collect_persistent_settings(context))
    try:
        raw = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2)
    except Exception:
        return
    if not force and raw == _AUTOSAVE_FINGERPRINT:
        return
    _AUTOSAVE_FINGERPRINT = raw
    try:
        path = settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(raw, encoding='utf-8')
    except Exception:
        pass


def _autosave_timer():
    try:
        save_persistent_settings(bpy.context)
    except Exception:
        pass
    return 5.0


@persistent
def _load_post_handler(dummy=None):
    try:
        load_settings_file()
        apply_persistent_settings(bpy.context)
    except Exception:
        pass


def _append_handler_once(collection, handler):
    try:
        if handler not in collection:
            collection.append(handler)
    except Exception:
        pass


def _remove_handler(collection, handler):
    try:
        while handler in collection:
            collection.remove(handler)
    except Exception:
        pass


def register():
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    try:
        bpy.app.translations.register(PACKAGE_ID, _translation_payload())
    except Exception:
        pass
    try:
        if not hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            setattr(bpy.types.WindowManager, _ALWAYS_ON_PROP, BoolProperty(
                name='Always-on',
                description='Saved always-on switch for this tool. Enable it only when you want persistent helper behavior; disable it for ordinary manual use.',
                default=False,
            ))
    except Exception:
        pass
    _unregister_removed_standalone_always_on_panels()
    for cls in (SMART_TRANSFORM_OT_open_help, SMART_TRANSFORM_OT_set_always_on, SMART_TRANSFORM_OT_save_preferences):
        try:
            _materialize_annotations(cls)
            bpy.utils.register_class(cls)
            _REGISTERED_CLASSES.append(cls)
        except ValueError:
            _REGISTERED_CLASSES.append(cls)
        except Exception:
            pass
    load_settings_file()
    if _ENABLE_COMMON_BROAD_PERSISTENCE:
        try:
            apply_persistent_settings(bpy.context)
        except Exception:
            pass
        _append_handler_once(bpy.app.handlers.load_post, _load_post_handler)
        try:
            timers = getattr(bpy.app, 'timers', None)
            if timers is not None and hasattr(timers, 'is_registered') and not timers.is_registered(_autosave_timer):
                timers.register(_autosave_timer, first_interval=2.0, persistent=True)
        except Exception:
            pass
    _patch_panel_headers()
    _patch_addon_preferences()


def unregister():
    try:
        save_persistent_settings(bpy.context, force=True)
    except Exception:
        pass
    _unpatch_panel_headers()
    _unpatch_addon_preferences()
    try:
        timers = getattr(bpy.app, 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(_autosave_timer):
            timers.unregister(_autosave_timer)
    except Exception:
        pass
    _remove_handler(bpy.app.handlers.load_post, _load_post_handler)
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    try:
        if hasattr(bpy.types.WindowManager, _ALWAYS_ON_PROP):
            delattr(bpy.types.WindowManager, _ALWAYS_ON_PROP)
    except Exception:
        pass
    _remove_previews()
    try:
        bpy.app.translations.unregister(PACKAGE_ID)
    except Exception:
        pass
    end_register()
