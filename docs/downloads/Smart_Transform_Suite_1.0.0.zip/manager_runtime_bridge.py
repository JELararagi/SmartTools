# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""Lazy, fail-open Smart Tools Manager runtime bridge.

This module performs exact ``sys.modules`` lookups only.  It never imports,
enables, disables, reloads, scans, or retries another add-on.  Runtime callers
ask the Manager's public workspace-level API whether Smart Transform may run;
Panel placement remains entirely separate.
"""

from __future__ import annotations

import sys


_TOOL_KEY = "SMART_TRANSFORM"
_API_NAMES = (
    "bl_ext.user_default.smart_tools_manager",
    "smart_tools_manager",
    "bl_ext.blender_org.smart_tools_manager",
)


def _manager_public_bool(api_name: str, context=None, **api_kwargs) -> bool:
    """Call one already-loaded Manager boolean API, failing open on uncertainty."""
    for module_name in _API_NAMES:
        try:
            module = sys.modules.get(module_name)
            if module is None or getattr(module, "__addon_enabled__", None) is False:
                continue
            public_api = vars(module).get(api_name)
        except Exception:
            return True
        if not callable(public_api):
            continue
        try:
            decision = public_api(_TOOL_KEY, context, **api_kwargs)
        except Exception:
            return True
        return decision if type(decision) is bool else True
    return True


def panel_placement_allowed(context=None, expected_editor_key="VIEW_3D") -> bool:
    """Return the current editor-cell decision for the Suite root Panel only."""
    return _manager_public_bool(
        "placement_allowed",
        context,
        editor_key=expected_editor_key,
    )


def workspace_runtime_allowed(context=None) -> bool:
    """Return the current workspace-wide Smart Transform runtime decision."""
    return _manager_public_bool("workspace_tool_allowed", context)
