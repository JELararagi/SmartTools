# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import inspect
import sys
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender runtime only
    bpy = None

# Blender 5.1 can crash natively in WM_keymap_clear / WM_operator_properties_free
# when stale KeyMapItem OperatorProperties are rebuilt or freed. Python cannot
# catch this access violation, so Smart Transform Suite does not mutate Blender
# keymaps at runtime in this crash-safe build.
_STS_KEYMAP_MUTATION_QUARANTINED = True

def keymap_mutation_allowed() -> bool:
    return False


_EXIT_FUNCTION_NAMES = {'_on_exit', 'disable_all', 'WM_exit', 'WM_exit_ex'}


def is_blender_exit_unregistration() -> bool:
    """Return True during Blender process-exit add-on cleanup."""
    try:
        if sys.is_finalizing():
            return True
    except Exception:
        pass
    try:
        if bpy is not None and bool(getattr(getattr(bpy, 'app', None), 'is_exit', False)):
            return True
    except Exception:
        pass
    try:
        frame = inspect.currentframe()
        frame = frame.f_back if frame is not None else None
        depth = 0
        while frame is not None and depth < 80:
            code = frame.f_code
            name = str(getattr(code, 'co_name', '') or '')
            filename = str(getattr(code, 'co_filename', '') or '').replace('\\', '/').lower()
            if name in _EXIT_FUNCTION_NAMES:
                return True
            if filename.endswith('/addon_utils.py') and name == 'disable_all':
                return True
            if filename.endswith('/bpy/utils/__init__.py') and name == '_on_exit':
                return True
            frame = frame.f_back
            depth += 1
    except Exception:
        return False
    finally:
        try:
            del frame
        except Exception:
            pass
    return False


# Backward-compatible name used by earlier crash-guard builds.
def is_blender_shutdown_context() -> bool:
    return is_blender_exit_unregistration()



def keymap_item_signature(kmi: Any) -> tuple[Any, ...] | None:
    """Crash-safe no-op; do not read KeyMapItem fields for signatures."""
    del kmi
    return None

def _iter_current_keymap_items(km: Any) -> list[Any]:
    """Crash-safe no-op; do not read KeyMap.keymap_items."""
    del km
    return []

def live_keymap_item(km: Any, kmi: Any = None, *, kmi_id: int | None = None, signature: tuple[Any, ...] | None = None) -> Any | None:
    items = _iter_current_keymap_items(km)
    if not items:
        return None
    ids: set[int] = set()
    try:
        if kmi_id is not None:
            ids.add(int(kmi_id))
    except Exception:
        pass
    try:
        if kmi is not None:
            ids.add(id(kmi))
    except Exception:
        pass
    if ids:
        for item in items:
            try:
                if id(item) in ids:
                    return item
            except Exception:
                continue
    # Do not derive a fallback signature from a possibly stale stored KMI.
    # Accessing RNA properties on stale wrappers is exactly what this guard is
    # meant to avoid.  Signature matching is used only when a caller explicitly
    # passes a signature captured while the item was known to be valid.
    if signature is None:
        return None
    matches = []
    for item in items:
        try:
            if keymap_item_signature(item) == signature:
                matches.append(item)
        except Exception:
            continue
    return matches[0] if len(matches) == 1 else None


def keymap_item_is_live(km: Any, kmi: Any) -> bool:
    return live_keymap_item(km, kmi) is not None


def safe_set_keymap_item_active(kmi: Any, active: bool, *, km: Any = None) -> bool:
    """Crash-safe KeyMapItem active-state guard.

    This intentionally performs no mutation. Blender 5.1 can access-violate
    later in WM_keymap_clear after Python toggles KeyMapItem.active on stale
    keymap wrappers, so the only safe behavior is to leave keymaps untouched.
    """
    del kmi, active, km
    return False


def safe_remove_keymap_item(
    km: Any,
    kmi: Any = None,
    *,
    kmi_id: int | None = None,
    signature: tuple[Any, ...] | None = None,
    deactivate_on_skip: bool = True,
    deactivate_fallback: bool | None = None,
) -> bool:
    """Crash-safe substitute for physical KeyMapItem removal.

    This intentionally performs no mutation. Removing or deactivating keymap
    entries can leave stale OperatorProperties that crash Blender during
    keyconfig rebuild/free.
    """
    del km, kmi, kmi_id, signature, deactivate_on_skip, deactivate_fallback
    return False


def safe_remove_matching_keymap_items(km: Any, predicate, *, deactivate_on_skip: bool = True) -> int:
    """Crash-safe no-op for keymap item bulk removal."""
    del km, predicate, deactivate_on_skip
    return 0


def safe_remove_keymap(kc: Any, km: Any, *, prefer_keep: bool = True) -> bool:
    """Crash-safe substitute for physical KeyMap removal.

    Empty add-on keymaps are harmless.  Keeping them avoids the same class of
    shutdown/reload instability as deleting KeyMapItems.
    """
    del kc, km, prefer_keep
    return False

_NATIVE_VIEW3D_SELECTION_IDNAMES = {
    'view3d.select',
    'view3d.tweak_select',
    'view3d.select_box',
    'view3d.select_circle',
    'view3d.select_lasso',
}

_NATIVE_VIEW3D_SELECTION_KEYMAP_NAMES = {
    '3D View',
    'Object Mode',
    'Mesh',
    '3D View Tool: Select',
    '3D View Tool: Select Box',
    '3D View Tool: Select Circle',
    '3D View Tool: Select Lasso',
    '3D View Tool: Move',
    '3D View Tool: Rotate',
    '3D View Tool: Scale',
    '3D View Tool: Transform',
}

_NATIVE_VIEW3D_SELECTION_MOUSE_TYPES = {
    'LEFTMOUSE',
    'RIGHTMOUSE',
    'EVT_TWEAK_L',
    'EVT_TWEAK_R',
}


def _native_view3d_selection_km_name_ok(km: Any) -> bool:
    try:
        name = str(getattr(km, 'name', '') or '')
    except Exception:
        name = ''
    if name in _NATIVE_VIEW3D_SELECTION_KEYMAP_NAMES:
        return True
    if name.startswith('3D View Tool:'):
        return True
    try:
        # Blender version/keyconfig names can vary. The item-level filter below
        # is already narrow, so any VIEW_3D keymap that contains Blender's native
        # selection operator is safe to repair.
        if str(getattr(km, 'space_type', '') or '') == 'VIEW_3D':
            return True
    except Exception:
        pass
    return False


def _native_view3d_selection_kmi_ok(kmi: Any) -> bool:
    try:
        if str(getattr(kmi, 'idname', '') or '') not in _NATIVE_VIEW3D_SELECTION_IDNAMES:
            return False
        key_type = str(getattr(kmi, 'type', '') or '')
        if key_type not in _NATIVE_VIEW3D_SELECTION_MOUSE_TYPES:
            return False
        # Keep keyboard shortcuts and non-mouse modal map entries untouched.
        return True
    except Exception:
        return False


def restore_native_view3d_selection_routes(context: Any = None) -> int:
    """Startup-safe no-op for Blender 5.1 keymap quarantine.

    Older builds repaired native selection by touching KeyMapItem.active. That
    path is now avoided completely because the current crash log reaches
    WM_keymap_clear while Blender is updating keyconfigs.
    """
    del context
    return 0

