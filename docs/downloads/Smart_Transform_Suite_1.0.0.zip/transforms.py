"""Transform selected Blender data in world or chosen orientation space."""
import math
import bpy
import bmesh
from mathutils import Euler,Matrix,Quaternion,Vector

AXES="xyz"
CLIP=None

def selected(ctx):
    if ctx.mode=="POSE":return list(ctx.selected_pose_bones or [])
    return [o for o in ctx.selected_objects if o.is_editable]

def active(ctx):
    return ctx.active_pose_bone if ctx.mode=="POSE" else ctx.active_object

def world(ctx,obj):
    if isinstance(obj,bpy.types.PoseBone):return ctx.active_object.matrix_world@obj.matrix
    return obj.matrix_world.copy()

def apply_world(ctx,obj,matrix):
    if isinstance(obj,bpy.types.PoseBone):
        obj.matrix=ctx.active_object.matrix_world.inverted_safe()@matrix
        return
    options=ctx.scene.tool_settings
    children={c:c.matrix_world.copy() for c in obj.children if options.use_transform_skip_children}
    before=obj.matrix_world.copy()
    if options.use_transform_data_origin and obj.data and hasattr(obj.data,"transform"):
        if obj.data.users>1:obj.data=obj.data.copy()
        delta=matrix.inverted_safe()@before
        if obj.type=="MESH":obj.data.transform(delta,shape_keys=True)
        else:obj.data.transform(delta)
    obj.matrix_world=matrix
    for child,m in children.items():child.matrix_world=m

def basis(ctx):
    settings=ctx.scene.core_props
    slot=ctx.scene.transform_orientation_slots[0]
    orient=slot.type if ctx.window_manager.smart_transform_suite_runtime_preferences.core_panel.use_scene_orientation else settings.popup_orient
    if orient=="CURSOR":return ctx.scene.cursor.matrix.to_quaternion()
    if orient=="VIEW" and ctx.region_data:return ctx.region_data.view_rotation.copy()
    item=active(ctx)
    if item and orient=="PARENT" and item.parent:return world(ctx,item.parent).to_quaternion()
    if item and orient in {"LOCAL","NORMAL","GIMBAL"}:return world(ctx,item).to_quaternion()
    if slot.custom_orientation and orient not in {"GLOBAL","LOCAL","VIEW","CURSOR","NORMAL","GIMBAL","PARENT"}:return slot.custom_orientation.matrix.to_quaternion()
    return Quaternion()

class Points(list):
    """Selected edit-mesh vertices. Holds the BMesh wrappers they came from: when the last
    reference to a wrapper goes, Blender invalidates its BMVerts (ReferenceError on .co)."""
    __slots__=("meshes",)

def points(ctx):
    hits=Points();hits.meshes=[]
    for obj in ctx.objects_in_mode_unique_data:
        if obj.type=="MESH":
            bm=bmesh.from_edit_mesh(obj.data)
            hits.meshes.append(bm)
            hits.extend((obj,v) for v in bm.verts if v.select and not v.hide)
    return hits

def center(values):
    if not values:raise ValueError("Select an object or mesh element")
    return sum(values,Vector((0,0,0)))/len(values)

def values(ctx,item,kind):
    loc,q,scale=world(ctx,item).decompose()
    spin=basis(ctx)
    if kind=="loc":return spin.inverted()@loc
    if kind=="rot":return (spin.inverted()@q).to_euler()
    if kind=="scale":return scale
    if isinstance(item,bpy.types.Object):return item.dimensions.copy()
    return Vector((0,0,0))

def numeric_get(key,group):
    ctx=bpy.context
    kind,axis=key.split("_")
    if group.input_mode=="DELTA":
        auto=ctx.window_manager.smart_transform_suite_runtime_preferences.core_panel.delta_display_mode=="AUTO_ZERO"
        return group.get("_last_"+key,1.0 if kind=="scale" else 0.0) if not auto else (1.0 if kind=="scale" else 0.0)
    if ctx.mode not in {"OBJECT","POSE"} or not active(ctx):return 1.0 if kind=="scale" else 0.0
    item=active(ctx)
    if group.op_mode=="EACH":return values(ctx,item,kind)[AXES.index(axis)]
    items=selected(ctx)
    return sum(values(ctx,x,kind)[AXES.index(axis)] for x in items)/len(items) if items else 0.0

def numeric_set(key,group,value):
    ctx=bpy.context
    if ctx.mode not in {"OBJECT","POSE"}:return
    items=selected(ctx)
    if not items:return
    kind,axis=key.split("_");i=AXES.index(axis)
    model=ctx.window_manager.smart_transform_suite_runtime_preferences.core_panel
    delta=group.input_mode=="DELTA"
    group["_last_"+key]=value
    frames=[world(ctx,obj) for obj in items]
    before=[values(ctx,obj,kind)[i] for obj in items]
    pivot=center([m.translation for m in frames])
    avg=sum(before)/len(before)
    spin=basis(ctx)
    for obj,frame,x in zip(items,frames,before):
        ref=x if group.op_mode=="EACH" else avg
        if kind=="scale" and delta and model.delta_scale_style not in {"ADD","ADDITIVE"}:amount=x*value
        else:amount=x+value if delta else x+value-ref
        location,rotation,scaling=frame.decompose()
        if kind=="loc":
            offset=Vector((0,0,0));offset[i]=amount-x;location+=spin@offset
        elif kind=="rot":
            axis_vector=Vector((0,0,0));axis_vector[i]=1
            turn=Quaternion(spin@axis_vector,amount-x)
            if group.op_mode=="MEDIAN":location=pivot+turn@(location-pivot)
            if not ctx.scene.tool_settings.use_transform_pivot_point_align:rotation=turn@rotation
        elif kind=="scale":
            factor=amount/x if abs(x)>1e-12 else 1
            for other,char in enumerate(AXES):
                if other==i:scaling[other]=amount
                elif getattr(model,"scale_link_"+axis) and getattr(model,"scale_link_"+char):scaling[other]*=factor
        elif kind=="dim":
            if not isinstance(obj,bpy.types.Object) or x<=1e-10:continue
            scaling[i]*=max(0,amount)/x
        apply_world(ctx,obj,Matrix.LocRotScale(location,rotation,scaling))
    ctx.view_layer.update()

def snap(ctx,mode):
    cursor=ctx.scene.cursor
    if ctx.mode=="EDIT_MESH":
        verts=points(ctx)
        average=center([o.matrix_world@v.co for o,v in verts])
        if mode=="CURSOR_TO_SEL":cursor.location=average;return
        if mode=="TO_ACTIVE":raise ValueError("Object mode is required")
        offset=cursor.location-average if mode=="TO_CURSOR" else Vector((0,0,-average.z))
        for obj,v in verts:v.co+=obj.matrix_world.inverted_safe().to_3x3()@offset
        for obj in {o for o,v in verts}:bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
        return
    objs=selected(ctx)
    original=[world(ctx,o) for o in objs]
    mid=center([m.translation for m in original])
    if mode=="CURSOR_TO_SEL":cursor.location=mid;return
    target=world(ctx,active(ctx)).translation if mode=="TO_ACTIVE" else cursor.location.copy()
    for obj,m in zip(objs,original):
        reference=m.translation if ctx.scene.core_props.op_mode=="EACH" or mode=="TO_ACTIVE" else mid
        change=Vector((0,0,-reference.z)) if mode=="TO_FLOOR" else target-reference
        m.translation+=change
        apply_world(ctx,obj,m)
    ctx.view_layer.update()

def core(op,ctx,action):
    global CLIP
    if action=="copy":
        obj=active(ctx)
        if not obj:raise ValueError("Select the source first")
        CLIP=world(ctx,obj).decompose();return
    if action=="paste":
        if CLIP is None:raise ValueError("Copy a transform first")
        flags=[getattr(op,"paste_"+f) if op.properties.is_property_set("paste_"+f) else getattr(ctx.scene.core_props,"paste_"+f) for f in ("location","rotation","scale")]
        if not any(flags):raise ValueError("Choose at least one channel")
        for item in selected(ctx):
            prior=world(ctx,item).decompose()
            apply_world(ctx,item,Matrix.LocRotScale(*[CLIP[i] if yes else prior[i] for i,yes in enumerate(flags)]))
        ctx.view_layer.update();return
    if action in {"apply_all","apply_rs"}:
        if ctx.mode!="OBJECT" or not selected(ctx):raise ValueError("Select editable objects in Object Mode")
        return bpy.ops.object.transform_apply(location=action=="apply_all",rotation=True,scale=True)
    if action=="reset_value":
        name=op.prop_name
        if name not in {f"{kind}_{axis}" for kind in ("loc","rot","scale","dim") for axis in AXES}:raise ValueError("Unknown transform field")
        kind,axis=name.split("_")
        if kind=="dim":
            for obj in selected(ctx):
                if isinstance(obj,bpy.types.Object) and obj.dimensions[AXES.index(axis)]>1e-10:
                    obj.scale[AXES.index(axis)]=1.0
            ctx.view_layer.update()
        else:
            group=ctx.scene.core_props;previous=group.input_mode
            try:group.input_mode="ABS";numeric_set(name,group,1.0 if kind=="scale" else 0.0)
            finally:group.input_mode=previous
        return
    modes={"snap_to_cursor_button":"TO_CURSOR","cursor_to_selection_button":"CURSOR_TO_SEL","snap_to_active_button":"TO_ACTIVE","snap_to_floor_button":"TO_FLOOR"}
    snap(ctx,modes.get(action,op.mode))
