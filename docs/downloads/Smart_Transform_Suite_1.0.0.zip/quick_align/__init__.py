# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy

from .. import runtime as _runtime
from .. import ui_icons as _ui_icons
from .. import operator_safety as _op_safety
from .. import load_hooks as _load_hooks
import webbrowser



def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}




def _ui_label_kwargs(icon: str = 'NONE', custom_icon: str = ''):
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _draw_icon_label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> bool:
    try:
        layout.label(text=str(text or ''), **_ui_label_kwargs(icon, custom_icon))
        return True
    except TypeError:
        try:
            layout.label(text=str(text or ''), icon=icon or 'NONE')
            return True
        except Exception:
            return False
    except Exception:
        return False

def _operator(layout, operator_id: str, *, text: str = '', icon: str = 'NONE', custom_icon: str = '', emboss: bool | None = None, **props):
    icon_only = not str(text or '').strip()
    if emboss is None:
        emboss = True
    elif icon_only and emboss is False:
        emboss = True
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props)
    try:
        op = layout.operator(operator_id, text=text, emboss=emboss, **icon_args)
    except TypeError:
        try:
            op = layout.operator(operator_id, text=text, icon=icon, emboss=emboss)
        except TypeError:
            op = layout.operator(operator_id, text=text, icon=icon)
    for k, v in props.items():
        try:
            _op_safety.safe_set_operator_property(op, k, v, operator_id=operator_id, strict=True)
        except Exception:
            pass
    return op

bl_info = {
    "name": "Quick Align Tool",
    "author": "Smart Transform Suite",
    "version": (1, 8, 70),
    "blender": (5, 1, 0),
    "location": "View3D > Object > Quick Align Tool",
    "description": "Intuitive alignment tool that displays a popup on target click. Map to a key to launch as a popup menu.",
    "category": "Object",
}

import json
import time
from bpy.props import BoolProperty, EnumProperty, StringProperty, FloatProperty, IntProperty
from mathutils import Vector, Matrix
from bpy_extras import view3d_utils
from bpy.app.translations import pgettext_iface as iface_
from bpy.app.handlers import persistent

# --- 翻訳辞書 (i18n) ---
translations = {
    "ja_JP": {
        ("*", "Quick Align Tool"): "クイック位置合わせツール",
        ("*", "Quick Align settings are edited from the Smart Transform N-panel."): "クイック整列 の設定は Smart Transform Nパネルで編集します。",
        ("*", "Open 3D View > Sidebar (N) > Smart Transform > Quick Align."): "3Dビュー > サイドバー（N）> Smart Transform > クイック整列 を開いてください。",
        ("*", "Quick Align Runtime Settings"): "クイック整列ランタイム設定",
        ("*", "Persistent Quick Align N-panel settings stored on the WindowManager and saved to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json."): "Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonにも保存されるクイック整列 Nパネル設定です。",
        ("*", "Intuitive alignment tool that displays a popup on target click. Map to a key to launch as a popup menu."): "ターゲットクリックでポップアップを表示する直感的な位置合わせツール。キーマップに登録してポップアップメニューとして起動",
        ("*", "Align"): "位置合わせ",
        ("*", "Align Position (World):"): "位置合わせ (ワールド):",
        ("*", "X Position"): "X 位置",
        ("*", "Y Position"): "Y 位置",
        ("*", "Z Position"): "Z 位置",
        ("*", "Align the X-axis position."): "バウンディングボックスまたは基点を基準にX軸の座標を合わせます。",
        ("*", "Align the Y-axis position."): "バウンディングボックスまたは基点を基準にY軸の座標を合わせます。",
        ("*", "Align the Z-axis position."): "バウンディングボックスまたは基点を基準にZ軸の座標を合わせます。",
        ("*", "Axis-specific Reference (Source / Target):"): "軸ごとの基準点 (ソース / ターゲット):",
        ("*", "X Ref"): "X 基準",
        ("*", "Y Ref"): "Y 基準",
        ("*", "Z Ref"): "Z 基準",
        ("*", "Current Object:"): "現在のオブジェクト:",
        ("*", "Reference point of the objects to be moved."): "移動させる現在のオブジェクトの基準点です。",
        ("*", "Target Object:"): "ターゲット オブジェクト:",
        ("*", "Reference point of the target object."): "目標となるターゲットオブジェクトの基準点です。",
        ("*", "Minimum"): "最小",
        ("*", "Center"): "中心",
        ("*", "Pivot"): "基点",
        ("*", "Maximum"): "最大",
        ("*", "Minimum coordinate of the bounding box."): "バウンディングボックスの最小座標を基準にします。",
        ("*", "Center coordinate of the bounding box."): "バウンディングボックスの中心座標を基準にします。",
        ("*", "Pivot point (Origin) of the object."): "オブジェクトの基点（原点）を基準にします。",
        ("*", "Maximum coordinate of the bounding box."): "バウンディングボックスの最大座標を基準にします。",
        ("*", "Align Orientation (Local):"): "方向位置合わせ (ローカル):",
        ("*", "X Axis"): "X 軸",
        ("*", "Y Axis"): "Y 軸",
        ("*", "Z Axis"): "Z 軸",
        ("*", "Align local axis directions (vector-based). "): "ローカル軸方向をベクトル基準で合わせます。",
        ("*", "Align the object's local X axis to the target's local X axis (world direction)."): "オブジェクトのローカルX軸方向をターゲットのローカルX軸方向（ワールド方向）に合わせます。",
        ("*", "Align the object's local Y axis to the target's local Y axis (world direction)."): "オブジェクトのローカルY軸方向をターゲットのローカルY軸方向（ワールド方向）に合わせます。",
        ("*", "Align the object's local Z axis to the target's local Z axis (world direction)."): "オブジェクトのローカルZ軸方向をターゲットのローカルZ軸方向（ワールド方向）に合わせます。",
        ("*", "Match Scale:"): "スケール合わせ:",
        ("*", "Match the X-axis scale."): "ターゲットのX軸のスケールに合わせます。",
        ("*", "Match the Y-axis scale."): "ターゲットのY軸のスケールに合わせます。",
        ("*", "Match the Z-axis scale."): "ターゲットのZ軸のスケールに合わせます。",
        ("*", "Select at least one object to move."): "移動させるオブジェクトを1つ以上選択してください。",
        ("*", "Select at least two objects, then make the target active, or start Quick Align and click the target."): "少なくとも2つのオブジェクトを選択してください。",
        ("*", "Select at least two objects before starting Quick Align."): "クイック整列 を開始する前に、少なくとも2つのオブジェクトを選択してください。",
        ("*", "Waiting for Quick Align: Click the target (ESC / Right Click / Click Background to cancel)"): "クイック整列の待機中: ターゲットをクリックしてください (ESC / 右クリック / 背景クリックでキャンセル)",
        ("*", "Quick Align canceled."): "クイック整列 をキャンセルしました。",
        ("*", "Invalid target. Please click a different object."): "ターゲットが不正です。別のオブジェクトをクリックしてください。",
        ("*", "Canceled due to background click."): "背景がクリックされたためキャンセルしました。",
        ("*", "Target:"): "ターゲット:",
        ("*", "Sources:"): "ソース:",
        ("*", "Target Selection:"): "ターゲット選択:",
        ("*", "Last Selected"): "最後に選択",
        ("*", "First Selected"): "最初に選択",
        ("*", "Use the last selected object as the target; all other selected objects become sources."): "最後に選択したオブジェクトをターゲットにし、それ以外の選択オブジェクトをソースにします。",
        ("*", "Use the first selected object as the target; all other selected objects become sources."): "最初に選択したオブジェクトをターゲットにし、それ以外の選択オブジェクトをソースにします。",
        ("*", "Align To:"): "合わせ先:",
        ("*", "Target Object"): "ターゲットオブジェクト",
        ("*", "Hit Point"): "クリック地点",
        ("*", "Use the clicked object's reference points."): "クリックしたオブジェクトの基準点を使用します。",
        ("*", "Use the clicked surface point (ray hit location)."): "クリックした面上の点（レイのヒット位置）を使用します。",
        ("*", "Normal Align"): "法線合わせ",
        ("*", "When Align To is Hit Point, optionally align orientation to face normal."): "合わせ先がクリック地点のとき、任意で面法線に方向を合わせます。",
        ("*", "Normal Axis"): "法線軸",
        ("*", "Which local axis of the source should face the hit normal."): "ソースのどのローカル軸をヒット法線方向に向けるか。",
        ("*", "Flip Normal"): "法線反転",
        ("*", "Invert the hit normal direction."): "ヒット法線の向きを反転します。",
        ("*", "Twist Stabilization"): "ねじれ安定化",
        ("*", "Stabilize roll around the hit normal."): "ヒット法線まわりの回転（ねじれ）を安定化します。",
        ("*", "Off"): "オフ",
        ("*", "Auto"): "自動",
        ("*", "Target"): "ターゲット",
        ("*", "View"): "ビュー",
        ("*", "World"): "ワールド",
        ("*", "Use the legacy helper axis. Roll may be arbitrary."): "従来の補助軸を使用します。ねじれ（ロール）は任意になります。",
        ("*", "Use target orientation; fallback to view; then world."): "ターゲットの向きを優先し、無理な場合はビュー、最後にワールド軸へフォールバックします。",
        ("*", "Use target object orientation to stabilize roll."): "ターゲットオブジェクトの向きを基準にねじれ（ロール）を安定化します。",
        ("*", "Use viewport orientation to stabilize roll."): "ビュー方向（画面の上下左右）を基準にねじれ（ロール）を安定化します。",
        ("*", "Use world axis to stabilize roll."): "ワールド軸を基準にねじれ（ロール）を安定化します。",
        ("*", "Tangent Axis"): "接線軸",
        ("*", "Which local axis of the source should follow the tangent direction (roll reference)."): "ソースのどのローカル軸を面の接線方向（ねじれ基準）に合わせるか。",
        ("*", "Target Axis"): "ターゲット軸",
        ("*", "Which target local axis is used as tangent reference."): "ターゲットのどのローカル軸を接線方向の基準にするか。",
        ("*", "View Axis"): "ビュー軸",
        ("*", "Which view axis is used as tangent reference."): "ビューのどの軸（上下/左右）を接線方向の基準にするか。",
        ("*", "View Up"): "ビュー上",
        ("*", "View Right"): "ビュー右",

        ("*", "Preset"): "プリセット",
        ("*", "Apply a common alignment preset."): "よく使う位置合わせプリセットを適用します。",
        ("*", "Pivot → Pivot"): "基点 → 基点",
        ("*", "Center → Center"): "中心 → 中心",
        ("*", "Min → Min"): "最小 → 最小",
        ("*", "Max → Max"): "最大 → 最大",
        ("*", "Min → Max"): "最小 → 最大",
        ("*", "Max → Min"): "最大 → 最小",
        ("*", "Continuous Mode"): "連続モード",
        ("*", "After applying, keep running to pick another target."): "適用後も継続して次のターゲットを選べるようにします。",
        ("*", "Swap Source/Target Refs"): "ソース/ターゲット基準を入れ替え",
        ("*", "Swap the source and target reference selections (per axis)."): "ソースとターゲットの基準点選択を（軸ごとに）入れ替えます。",
        ("*", "Reset (This Dialog)"): "リセット（このダイアログ）",
        ("*", "Reset settings in this dialog to the last saved values."): "このダイアログ内の設定を、前回保存した値に戻します。",
        ("*", "Respect Locks"): "ロックを尊重",
        ("*", "Do not change locked transform channels."): "変形ロック（位置/回転/スケール）がONのチャンネルは変更しません。",
        ("*", "Even Distribution"): "均等整列",
        ("*", "Evenly distribute the intermediate objects between the first endpoint and the target endpoint. Only enabled position, orientation, and scale channels are affected, and the axis-specific source/target references are respected."): "始点と終点の間にある中間オブジェクトを均等に整列します。有効な位置・方向・スケール項目だけを反映し、軸ごとのソース/ターゲット基準点を使用します。",
        ("*", "Use Farthest Pair"): "最遠ペア基準",
        ("*", "Use the two farthest selected objects as endpoints, then distribute the remaining objects by distance from the start endpoint instead of selection order."): "選択順ではなく、選択オブジェクト内で最も遠い2つを始点と終点にし、残りを始点からの距離順で均等整列します。",
        ("*", "Requires at least three objects including the target."): "ターゲットを含む3つ以上のオブジェクトが必要です。",
        ("*", "Preview Throttle (ms)"): "プレビュー間引き (ms)",
        ("*", "Reduce preview updates for large selections."): "選択数が多い場合のプレビュー更新頻度を下げます。",
        ("*", "Warp Cursor on Open"): "窓を開く時にカーソルをずらす",
        ("*", "Move the cursor aside before the Quick Align dialog opens, so the dialog is less likely to cover that spot."): "クイック整列の窓を開く前にカーソルを横へずらし、今の場所が窓で隠れにくくします。",
        ("*", "Warp Offset (px)"): "移動量 (px)",
        ("*", "Cursor warp offset in pixels."): "カーソルをずらす距離（ピクセル）です。",
        ("*", "Keymap Registration Instructions"): "ショートカット（キーマップ）登録方法",
        ("*", "1. Open [Edit] > [Preferences] > [Keymap]."): "1. トップメニューの[編集] > [プリファレンス] > [キーマップ]を開きます。",
        ("*", "2. Navigate to [3D View] > [Object Mode] > [Object Mode (Global)] and click 'Add New'."): "2. [3Dビュー] > [オブジェクトモード] > [オブジェクトモード (グローバル)] を展開し、「新規追加」を押します。",
        ("*", "3. Paste the following Operator ID into the identifier field:"): "3. 以下のオペレーターIDをコピーし、識別子の入力欄に貼り付けます。",
        ("*", "Operator ID for Keymap"): "登録用オペレーターID",
        ("*", "Copy this ID to register the shortcut in the Keymap settings."): "このIDをコピーして、キーマップ設定の識別子に登録してください。",
        ("*", "4. Assign your preferred shortcut (e.g., Alt + A) and save preferences."): "4. 任意のキー（Alt+Aなど）を割り当て、プリファレンスを保存します。",
        ("*", "Choose whether Quick Align uses the first selected object or the last selected object as the target."): "クイック整列のターゲットとして最初に選択したオブジェクトを使うか、最後に選択したオブジェクトを使うかを選びます。",
        ("*", "After applying Quick Align, keep running with the current selection workflow so another alignment can be launched without picking a viewport target."): "クイック整列適用後も現在の選択ワークフローのまま実行を継続し、ビューポートでターゲットを選び直さずに次の位置合わせを開始できるようにします。",
    }
}

# STS complete locale patch for translations
try:
    _sts_extra_locale_pairs = [('Quick Align settings are unavailable.', 'クイック整列 設定を利用できません。'),
 ('Keymap Registration Instructions', 'ショートカット（キーマップ）登録方法'),
 ('1. Open [Edit] > [Preferences] > [Keymap].', '1. トップメニューの［編集］>［プリファレンス］>［キーマップ］を開きます。'),
 ("2. Navigate to [3D View] > [Object Mode] > [Object Mode (Global)] and click 'Add New'.", '2. ［3Dビュー］>［オブジェクトモード］>［オブジェクトモード（グローバル）］を開き、「新規追加」を押します。'),
 ('3. Paste the following Operator ID into the identifier field:', '3. 以下のオペレーターIDを識別子欄へ貼り付けます。'),
 ('4. Assign your preferred shortcut (e.g., Alt + A) and save preferences.', '4. 任意のショートカット（例：Alt + A）を割り当て、プリファレンスを保存します。'),
 ('Even Distribution', '均等整列'),
 ('Evenly distribute the intermediate objects between the first endpoint and the target endpoint. Only enabled position, orientation, and scale channels are affected, and the axis-specific source/target references are respected.', '始点と終点の間にある中間オブジェクトを均等に整列します。有効な位置・方向・スケール項目だけを反映し、軸ごとのソース/ターゲット基準点を使用します。'),
 ('Use Farthest Pair', '最遠ペア基準'),
 ('Use the two farthest selected objects as endpoints, then distribute the remaining objects by distance from the start endpoint instead of selection order.', '選択順ではなく、選択オブジェクト内で最も遠い2つを始点と終点にし、残りを始点からの距離順で均等整列します。'),
 ('Requires at least three objects including the target.', 'ターゲットを含む3つ以上のオブジェクトが必要です。'),
 ('Target:', 'ターゲット:'),
 ('Sources:', 'ソース:'),
 ('Align Position (World):', '位置合わせ（ワールド）:'),
 ('Axis-specific Reference (Source / Target):', '軸ごとの基準点（ソース / ターゲット）:'),
 ('Align Orientation (Local):', '方向合わせ（ローカル）:'),
 ('Match Scale:', 'スケール合わせ:'),
 ('Select at least one object to move.', '移動させるオブジェクトを1つ以上選択してください。'),
 ('Waiting for Quick Align: Click the target (ESC / Right Click / Click Background to cancel)', 'クイック整列の待機中: ターゲットをクリックしてください（ESC / 右クリック / 背景クリックでキャンセル）'),
 ('Quick Align canceled.', 'クイック整列 をキャンセルしました。'),
 ('Invalid target. Please click a different object.', 'ターゲットが不正です。別のオブジェクトをクリックしてください。'),
 ('Canceled due to background click.', '背景がクリックされたためキャンセルしました。'),
 ('Which local axis of the source should rotate to face the clicked hit normal when normal alignment is enabled.', '法線合わせが有効なとき、クリックした面法線へ向けるソースのローカル軸を選びます。'),
 ("Use the source object's local X axis as the axis that faces the clicked surface normal.", 'ソースオブジェクトのローカルX軸を、クリックした面法線へ向ける軸として使用します。'),
 ("Use the source object's local Y axis as the axis that faces the clicked surface normal.", 'ソースオブジェクトのローカルY軸を、クリックした面法線へ向ける軸として使用します。'),
 ("Use the source object's local Z axis as the axis that faces the clicked surface normal.", 'ソースオブジェクトのローカルZ軸を、クリックした面法線へ向ける軸として使用します。'),
 ('Choose which source local axis is used as the roll/tangent reference after the normal axis is aligned.', '法線軸を合わせた後、ロール/接線の基準として使うソースのローカル軸を選びます。'),
 ("Use the source object's local X axis as the roll reference around the aligned normal.", '整列した法線まわりのロール基準として、ソースのローカルX軸を使用します。'),
 ("Use the source object's local Y axis as the roll reference around the aligned normal.", '整列した法線まわりのロール基準として、ソースのローカルY軸を使用します。'),
 ("Use the source object's local Z axis as the roll reference around the aligned normal.", '整列した法線まわりのロール基準として、ソースのローカルZ軸を使用します。'),
 ('Choose which target local axis supplies the tangent direction used to stabilize roll.', 'ロールを安定させる接線方向として使うターゲットのローカル軸を選びます。'),
 ("Use the target object's local X axis as the tangent reference.", 'ターゲットオブジェクトのローカルX軸を接線基準として使用します。'),
 ("Use the target object's local Y axis as the tangent reference.", 'ターゲットオブジェクトのローカルY軸を接線基準として使用します。'),
 ("Use the target object's local Z axis as the tangent reference.", 'ターゲットオブジェクトのローカルZ軸を接線基準として使用します。'),
 ('Choose which viewport direction supplies the tangent direction used to stabilize roll.', 'ロールを安定させる接線方向として使うビューポート方向を選びます。'),
 ('Use the current viewport up direction as the tangent reference.', '現在のビューポート上方向を接線基準として使用します。'),
 ('Use the current viewport right direction as the tangent reference.', '現在のビューポート右方向を接線基準として使用します。'),
 ('After applying Quick Align, keep the target-pick operation running so another target can be clicked without launching the tool again.', 'クイック整列適用後もターゲット選択を継続し、ツールを起動し直さずに次のターゲットをクリックできるようにします。'),
 ('No preset is applied. Use the current manual Quick Align settings.', 'プリセットを適用せず、現在の手動クイック整列設定を使用します。'),
 ("Align each source object's pivot/origin to the target object's pivot/origin.", '各ソースオブジェクトの基点/原点を、ターゲットオブジェクトの基点/原点へ合わせます。'),
 ("Align each source object's bounding-box center to the target object's bounding-box center.", '各ソースオブジェクトのバウンディングボックス中心を、ターゲットのバウンディングボックス中心へ合わせます。'),
 ('Align each source minimum bound to the target minimum bound on the enabled axes.', '有効な軸で、各ソースの最小境界をターゲットの最小境界へ合わせます。'),
 ('Align each source maximum bound to the target maximum bound on the enabled axes.', '有効な軸で、各ソースの最大境界をターゲットの最大境界へ合わせます。'),
 ('Align each source minimum bound to the target maximum bound on the enabled axes.', '有効な軸で、各ソースの最小境界をターゲットの最大境界へ合わせます。'),
 ('Align each source maximum bound to the target minimum bound on the enabled axes.', '有効な軸で、各ソースの最大境界をターゲットの最小境界へ合わせます。')]
    _ja = translations.setdefault("ja_JP", {})
    _en = translations.setdefault("en_US", {})
    for _src, _dst in _sts_extra_locale_pairs:
        _ja[("*", _src)] = _dst
        if _src != _dst:
            _en[("*", _dst)] = _src
except Exception:
    pass
# /STS complete locale patch


def _suite_prefs(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None

def _prefs(context=None):
    prefs = _suite_prefs(context)
    return getattr(prefs, 'quick_align', None) if prefs else None

def _warp_cursor_aside(context, event):
    # The dialog opens at the cursor: move the cursor first so it is less likely
    # to cover that spot. Go left instead when the offset would leave the window.
    prefs = _prefs(context)
    if not (prefs and prefs.warp_cursor_after_pick):
        return
    try:
        offset = int(prefs.warp_offset_px)
        if offset <= 0:
            return
        window = context.window
        x = event.mouse_x + offset
        if x >= window.width:
            x = max(0, event.mouse_x - offset)
        window.cursor_warp(x, event.mouse_y)
    except Exception:
        pass

def _safe_area_redraw(context):
    # Prefer current VIEW_3D area when possible
    try:
        if getattr(context, "area", None) and context.area.type == 'VIEW_3D':
            context.area.tag_redraw()
            return
    except Exception:
        pass
    try:
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _can_invoke_quick_align_modal(context):
    try:
        if bool(getattr(bpy.app, 'background', False)):
            return False
    except Exception:
        pass
    try:
        return bool(getattr(context, 'window', None) and getattr(context, 'window_manager', None))
    except Exception:
        return False


def _request_quick_align_save(context=None):
    try:
        from .. import settings as _settings
        if _settings.is_restoring():
            return
        _settings.request_save('quick_align_update', context=context)
    except Exception:
        pass

class QUICK_ALIGN_PT_preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    operator_id: StringProperty(
        name="Operator ID for Keymap",
        default="object.quick_align_tool",
        description="Copy this ID to register the shortcut in the Keymap settings."
    )

    warp_cursor_after_pick: BoolProperty(
        name="Warp Cursor on Open",
        default=True,
        description="Move the cursor aside before the Quick Align dialog opens, so the dialog is less likely to cover that spot."
    )
    warp_offset_px: IntProperty(
        name="Warp Offset (px)",
        default=200,
        min=0,
        soft_max=2000,
        description="Cursor warp offset in pixels."
    )
    preview_throttle_ms: IntProperty(
        name="Preview Throttle (ms)",
        default=80,
        min=0,
        soft_max=500,
        description="Reduce preview updates for large selections."
    )

    # Last-used settings (internal persistence)
    saved_settings_json: StringProperty(
        name=iface_("Saved Quick Align Settings JSON"),
        description=iface_("Hidden compatibility mirror for serialized Quick Align settings. The current editable UI is stored through the Smart Transform N-panel persistence system."),
        default="",
        options={'HIDDEN'},
    )

    def draw(self, context):
        del context
        return None

def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass

_SCENE_RUNTIME_QUICK_ALIGN_SETTINGS = {}


def _quick_align_scene_key(context=None):
    try:
        ctx = context or getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None)
        if scene is None:
            return None
        return id(scene)
    except Exception:
        return None


def _get_scene_runtime_quick_align_settings(context=None):
    key = _quick_align_scene_key(context)
    if key is None:
        return None
    data = _SCENE_RUNTIME_QUICK_ALIGN_SETTINGS.get(key)
    return dict(data) if isinstance(data, dict) else None


def _set_scene_runtime_quick_align_settings(data, context=None):
    key = _quick_align_scene_key(context)
    if key is None or not isinstance(data, dict):
        return
    _SCENE_RUNTIME_QUICK_ALIGN_SETTINGS[key] = dict(data)


def _wm_quick_align_settings(context=None):
    wm = getattr(context, "window_manager", None) if context is not None else getattr(bpy.context, "window_manager", None)
    if wm is None:
        return None
    try:
        return getattr(wm, "quick_align_settings", None)
    except Exception:
        return None
def _event_window_xy(event):
    if event is None:
        return None
    try:
        return int(getattr(event, 'mouse_x', 0)), int(getattr(event, 'mouse_y', 0))
    except Exception:
        return None


def _region_window_rect(area, region):
    if region is None:
        return None
    try:
        rx = int(getattr(region, 'x', 0))
        ry = int(getattr(region, 'y', 0))
        rw = int(getattr(region, 'width', 0))
        rh = int(getattr(region, 'height', 0))
        if rw <= 0 or rh <= 0:
            return None
        return rx, ry, rw, rh
    except Exception:
        pass
    try:
        ax = int(getattr(area, 'x', 0)) if area is not None else 0
        ay = int(getattr(area, 'y', 0)) if area is not None else 0
        rx = ax + int(getattr(region, 'x', 0))
        ry = ay + int(getattr(region, 'y', 0))
        rw = int(getattr(region, 'width', 0))
        rh = int(getattr(region, 'height', 0))
        if rw <= 0 or rh <= 0:
            return None
        return rx, ry, rw, rh
    except Exception:
        return None


def _region_contains_event(area, region, event) -> bool:
    xy = _event_window_xy(event)
    if xy is None or region is None:
        return False
    mx, my = xy
    try:
        rx = int(getattr(region, 'x', 0))
        ry = int(getattr(region, 'y', 0))
        rw = int(getattr(region, 'width', 0))
        rh = int(getattr(region, 'height', 0))
        if rx <= mx < rx + rw and ry <= my < ry + rh:
            return True
    except Exception:
        pass
    try:
        ax = int(getattr(area, 'x', 0)) if area is not None else 0
        ay = int(getattr(area, 'y', 0)) if area is not None else 0
        rx = ax + int(getattr(region, 'x', 0))
        ry = ay + int(getattr(region, 'y', 0))
        rw = int(getattr(region, 'width', 0))
        rh = int(getattr(region, 'height', 0))
        return rx <= mx < rx + rw and ry <= my < ry + rh
    except Exception:
        return False


def _find_view3d_window_region(context, event=None):
    candidates = []

    def _append_area(a):
        if a is None or getattr(a, 'type', None) != 'VIEW_3D':
            return
        try:
            window_region = next((r for r in a.regions if getattr(r, 'type', None) == 'WINDOW'), None)
        except Exception:
            window_region = None
        if window_region is None:
            return
        try:
            space = a.spaces.active
            rv3d = getattr(space, 'region_3d', None) if space is not None else None
        except Exception:
            rv3d = None
        if rv3d is None:
            return
        candidates.append((a, window_region, rv3d))

    _append_area(getattr(context, 'area', None))

    win = getattr(context, 'window', None)
    screen = getattr(win, 'screen', None) if win is not None else getattr(context, 'screen', None)
    if screen is not None:
        for a in getattr(screen, 'areas', ()):  # pragma: no cover - Blender runtime
            if not any(a is c[0] for c in candidates):
                _append_area(a)

    if event is not None:
        for area, region, rv3d in candidates:
            if _region_contains_event(area, region, event):
                return area, region, rv3d

    if candidates:
        return candidates[0]
    return None, None, None


def _event_to_region_xy(event, region, area=None):
    if region is None or event is None:
        return None

    width = int(getattr(region, 'width', 0) or 0)
    height = int(getattr(region, 'height', 0) or 0)
    if width <= 0 or height <= 0:
        return None

    # Prefer global window coordinates.  In modal tools invoked from the N-panel,
    # event.mouse_region_x/y can still be relative to a UI/sidebar region, so
    # using them first can raycast from the wrong viewport position and turn a
    # valid object click into a false background hit.
    try:
        mx = int(getattr(event, 'mouse_x', 0))
        my = int(getattr(event, 'mouse_y', 0))
    except Exception:
        mx = my = None

    if mx is not None and my is not None:
        rect = _region_window_rect(area, region)
        if rect is not None:
            gx, gy, gw, gh = rect
            rx = mx - gx
            ry = my - gy
            if 0 <= rx < gw and 0 <= ry < gh:
                return rx, ry

        try:
            ax = int(getattr(area, 'x', 0)) if area is not None else 0
            ay = int(getattr(area, 'y', 0)) if area is not None else 0
            rx = mx - (ax + int(getattr(region, 'x', 0)))
            ry = my - (ay + int(getattr(region, 'y', 0)))
            if 0 <= rx < width and 0 <= ry < height:
                return rx, ry
        except Exception:
            pass

    # Last fallback: region-local coordinates, only used when the global path is
    # unavailable.
    try:
        rx = int(getattr(event, 'mouse_region_x', -1))
        ry = int(getattr(event, 'mouse_region_y', -1))
        if 0 <= rx < width and 0 <= ry < height:
            return rx, ry
    except Exception:
        pass

    return None


def _object_visible_in_context(obj, context) -> bool:
    if obj is None:
        return False
    try:
        if bool(getattr(obj, 'hide_viewport', False)):
            return False
    except Exception:
        pass
    try:
        if hasattr(obj, 'visible_get') and not obj.visible_get(view_layer=getattr(context, 'view_layer', None)):
            return False
    except TypeError:
        try:
            if hasattr(obj, 'visible_get') and not obj.visible_get():
                return False
        except Exception:
            pass
    except Exception:
        pass
    return True


def _to_original_object(obj):
    try:
        original = getattr(obj, 'original', None)
        if original is not None:
            return original
    except Exception:
        pass
    return obj


def _object_ray_cast_world(obj, depsgraph, ray_origin, ray_direction, *, max_distance=1.0e9):
    if obj is None:
        return None
    try:
        eval_obj = obj.evaluated_get(depsgraph)
    except Exception:
        eval_obj = obj
    try:
        inv = eval_obj.matrix_world.inverted_safe()
        local_origin = inv @ ray_origin
        local_direction = (inv.to_3x3() @ ray_direction).normalized()
        hit, loc_local, normal_local, face_index = eval_obj.ray_cast(local_origin, local_direction, distance=max_distance)
        if not hit:
            return None
        loc_world = eval_obj.matrix_world @ loc_local
        try:
            normal_world = (eval_obj.matrix_world.inverted_safe().transposed().to_3x3() @ normal_local).normalized()
        except Exception:
            normal_world = (eval_obj.matrix_world.to_3x3() @ normal_local).normalized()
        dist = (loc_world - ray_origin).length
        return dist, _to_original_object(obj), loc_world, normal_world
    except Exception:
        return None


def _iter_pickable_objects(context, depsgraph):
    seen = set()
    try:
        objects = list(getattr(context, 'visible_objects', []) or [])
    except Exception:
        objects = []
    if not objects:
        try:
            objects = list(getattr(context.view_layer, 'objects', []) or [])
        except Exception:
            objects = []
    for obj in objects:
        if obj is None:
            continue
        key = getattr(obj, 'name', id(obj))
        if key in seen:
            continue
        seen.add(key)
        if _object_visible_in_context(obj, context):
            yield obj


def _projected_bbox_pick(context, region, rv3d, coord, depsgraph, ray_origin, ray_direction, *, tolerance=8.0):
    try:
        cx, cy = float(coord[0]), float(coord[1])
    except Exception:
        return None

    best = None
    for obj in _iter_pickable_objects(context, depsgraph):
        try:
            mw = obj.matrix_world.copy()
            corners = [mw @ Vector(corner) for corner in getattr(obj, 'bound_box', ())]
        except Exception:
            corners = []
        if not corners:
            try:
                corners = [obj.matrix_world.translation.copy()]
            except Exception:
                continue

        points = []
        for corner in corners:
            try:
                p = view3d_utils.location_3d_to_region_2d(region, rv3d, corner)
                if p is not None:
                    points.append(p)
            except Exception:
                pass
        if not points:
            continue

        xs = [float(p.x) for p in points]
        ys = [float(p.y) for p in points]
        min_x, max_x = min(xs) - tolerance, max(xs) + tolerance
        min_y, max_y = min(ys) - tolerance, max(ys) + tolerance
        if not (min_x <= cx <= max_x and min_y <= cy <= max_y):
            continue

        try:
            center = obj.matrix_world.translation.copy()
            depth = (center - ray_origin).dot(ray_direction)
            if depth < 0.0:
                continue
            hit_loc = ray_origin + ray_direction * depth
            normal = (ray_origin - center).normalized()
            if normal.length == 0:
                normal = Vector((0.0, 0.0, 1.0))
        except Exception:
            depth = 1.0e9
            hit_loc = corners[0]
            normal = Vector((0.0, 0.0, 1.0))

        score = (float(depth), abs(cx - (min_x + max_x) * 0.5) + abs(cy - (min_y + max_y) * 0.5))
        if best is None or score < best[0]:
            best = (score, obj, hit_loc, normal)

    if best is None:
        return None
    _score, obj, loc, normal = best
    return _to_original_object(obj), loc, normal


def _pick_quick_align_target(context, event):
    area, region, rv3d = _find_view3d_window_region(context, event)
    coord = _event_to_region_xy(event, region, area)
    if region is None or rv3d is None or coord is None:
        return None

    try:
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord).normalized()
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    except Exception:
        return None

    try:
        depsgraph = context.evaluated_depsgraph_get()
    except Exception:
        depsgraph = None
    if depsgraph is None:
        return None

    # Primary path: Blender's scene raycast.
    try:
        hit, loc, normal, index, obj, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)
        obj = _to_original_object(obj)
        if hit and obj is not None and _object_visible_in_context(obj, context):
            return obj, loc, normal, rv3d
    except Exception:
        pass

    # Fallback path: cast against each visible object's evaluated mesh.  This
    # protects Quick Align from false background results caused by modal context
    # changes, depsgraph timing, or scene.ray_cast omissions.
    best = None
    for obj in _iter_pickable_objects(context, depsgraph):
        hit_data = _object_ray_cast_world(obj, depsgraph, ray_origin, view_vector)
        if hit_data is None:
            continue
        dist, original, loc, normal = hit_data
        if best is None or dist < best[0]:
            best = (dist, original, loc, normal)
    if best is not None:
        _dist, obj, loc, normal = best
        return obj, loc, normal, rv3d

    # Final fallback: projected bounding-box hit test.  This keeps non-mesh
    # targets and objects whose evaluated geometry is temporarily unavailable
    # selectable as Quick Align targets instead of treating them as background.
    bbox_hit = _projected_bbox_pick(context, region, rv3d, coord, depsgraph, ray_origin, view_vector)
    if bbox_hit is not None:
        obj, loc, normal = bbox_hit
        return obj, loc, normal, rv3d

    return None


def _view_orientation_vectors(rv3d):
    view_up = Vector((0.0, 1.0, 0.0))
    view_right = Vector((1.0, 0.0, 0.0))
    try:
        vrot = rv3d.view_rotation
        view_up = (vrot @ Vector((0.0, 1.0, 0.0))).normalized()
        view_right = (vrot @ Vector((1.0, 0.0, 0.0))).normalized()
    except Exception:
        pass
    return view_up, view_right



# Runtime selection-order cache used by the new Quick Align popup workflow.
# Blender exposes the active object reliably as the last selected object, but
# does not provide a guaranteed selection-history list for every context.  The
# timer below keeps a per-session order while the add-on is loaded and falls
# back to Blender's selected_objects order with the active object moved last.
_QUICK_ALIGN_SELECTION_ORDER = []
_QUICK_ALIGN_LAST_ACTIVE_NAME = ""
_QUICK_ALIGN_SELECTION_TIMER_REGISTERED = False
_QUICK_ALIGN_LAST_SELECTION_SIGNATURE = None
_QUICK_ALIGN_SELECTION_MSGBUS_OWNER = object()
_QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED = False


def _quick_align_current_selected_names(context=None):
    context = context or getattr(bpy, 'context', None)
    try:
        return [obj.name for obj in getattr(context, 'selected_objects', []) if obj is not None and obj.name in bpy.data.objects]
    except Exception:
        return []


def _quick_align_active_name(context=None):
    context = context or getattr(bpy, 'context', None)
    try:
        obj = getattr(context, 'active_object', None)
        if obj is not None and obj.name in bpy.data.objects:
            return obj.name
    except Exception:
        pass
    return ""


def _update_quick_align_selection_order(context=None):
    global _QUICK_ALIGN_SELECTION_ORDER, _QUICK_ALIGN_LAST_ACTIVE_NAME
    selected = _quick_align_current_selected_names(context)
    selected_set = set(selected)
    if not selected_set:
        _QUICK_ALIGN_SELECTION_ORDER = []
        _QUICK_ALIGN_LAST_ACTIVE_NAME = ""
        return []

    ordered = [name for name in _QUICK_ALIGN_SELECTION_ORDER if name in selected_set]
    for name in selected:
        if name not in ordered:
            ordered.append(name)

    active = _quick_align_active_name(context)
    if active in selected_set:
        # Active object is Blender's reliable "last selected" signal.  Moving it
        # to the end keeps the target-last option stable without disturbing the
        # remembered first-selected endpoint.
        if active in ordered:
            ordered.remove(active)
        ordered.append(active)
        _QUICK_ALIGN_LAST_ACTIVE_NAME = active
    elif _QUICK_ALIGN_LAST_ACTIVE_NAME not in selected_set:
        _QUICK_ALIGN_LAST_ACTIVE_NAME = ""

    _QUICK_ALIGN_SELECTION_ORDER = ordered
    return list(ordered)


def _quick_align_selection_signature(context=None):
    selected = tuple(sorted(_quick_align_current_selected_names(context)))
    return selected, _quick_align_active_name(context)


@persistent
def _quick_align_selection_order_on_depsgraph(_scene=None, _depsgraph=None):
    """Update selection order only when Blender reports an actual data event."""
    global _QUICK_ALIGN_LAST_SELECTION_SIGNATURE
    try:
        context = getattr(bpy, 'context', None)
        signature = _quick_align_selection_signature(context)
        if signature == _QUICK_ALIGN_LAST_SELECTION_SIGNATURE:
            return
        _QUICK_ALIGN_LAST_SELECTION_SIGNATURE = signature
        _update_quick_align_selection_order(context)
    except Exception:
        pass


def _quick_align_selection_msgbus_notify() -> None:
    _quick_align_selection_order_on_depsgraph()


def _install_quick_align_selection_msgbus() -> bool:
    global _QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED
    if _QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED:
        return True
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        layer_objects_type = getattr(getattr(bpy, 'types', None), 'LayerObjects', None)
        if msgbus is None or layer_objects_type is None:
            return False
        kwargs = dict(
            key=(layer_objects_type, 'active'),
            owner=_QUICK_ALIGN_SELECTION_MSGBUS_OWNER,
            args=(),
            notify=_quick_align_selection_msgbus_notify,
        )
        try:
            msgbus.subscribe_rna(**kwargs, options={'PERSISTENT'})
        except TypeError:
            msgbus.subscribe_rna(**kwargs)
        _QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED = True
        return True
    except Exception:
        _QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED = False
        return False


def _remove_quick_align_selection_msgbus() -> bool:
    global _QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED
    ok = True
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is not None:
            msgbus.clear_by_owner(_QUICK_ALIGN_SELECTION_MSGBUS_OWNER)
    except Exception:
        ok = False
    _QUICK_ALIGN_SELECTION_MSGBUS_INSTALLED = False
    return ok


def _quick_align_selection_order_timer():
    """Compatibility terminator for any timer queued by an older generation."""
    try:
        _quick_align_selection_order_on_depsgraph()
    except Exception:
        pass
    return None


def _quick_align_ordered_selected_names(context=None):
    selected = _quick_align_current_selected_names(context)
    selected_set = set(selected)
    if not selected_set:
        return []
    try:
        ordered = _update_quick_align_selection_order(context)
    except Exception:
        ordered = []
    ordered = [name for name in ordered if name in selected_set]
    for name in selected:
        if name not in ordered:
            ordered.append(name)
    active = _quick_align_active_name(context)
    if active in selected_set and (not ordered or ordered[-1] != active):
        if active in ordered:
            ordered.remove(active)
        ordered.append(active)
    return _unique_quick_align_names(ordered)

def _quick_align_session_matches_current_selection(settings, context=None) -> bool:
    """Return False when a stale popup/session would preview a different selection.

    Quick Align settings are intentionally kept for the current scene.  However,
    property update callbacks can fire after the user has selected a different
    set of objects.  In that case, avoid previewing with old target/source state;
    execute/invoke will prepare a fresh session for the new selection.
    """
    if settings is None:
        return False
    try:
        stored = _unique_quick_align_names(json.loads(getattr(settings, 'selected_names_json', '') or '[]'))
    except Exception:
        stored = []
    if not stored:
        return True
    try:
        current = _unique_quick_align_names(_quick_align_ordered_selected_names(context))
    except Exception:
        current = []
    if not current:
        return True
    if set(stored) == set(current):
        return True
    try:
        target_name = str(getattr(settings, 'target_name', '') or '').strip()
        source_names = _unique_quick_align_names(json.loads(getattr(settings, 'source_names_json', '') or '[]'))
    except Exception:
        return False
    return bool(
        target_name
        and target_name not in current
        and source_names
        and set(source_names) == set(current)
    )



def _quick_align_pick_target_from_order(settings, selected_names):
    selected_names = _unique_quick_align_names([name for name in (selected_names or []) if name in bpy.data.objects])
    if len(selected_names) < 2:
        return "", []
    try:
        mode = str(getattr(settings, 'target_endpoint_mode', 'LAST') or 'LAST')
    except Exception:
        mode = 'LAST'
    target_name = selected_names[0] if mode == 'FIRST' else selected_names[-1]
    source_names = [name for name in selected_names if name != target_name]
    return target_name, source_names


def _refresh_quick_align_target_from_selection_settings(settings, context=None, *, force_preview=True):
    if settings is None:
        return False
    try:
        selected_names = json.loads(getattr(settings, 'selected_names_json', '') or '[]')
    except Exception:
        selected_names = []
    if not selected_names:
        selected_names = _quick_align_ordered_selected_names(context)
    selected_names = _unique_quick_align_names([name for name in selected_names if name in bpy.data.objects])
    if len(selected_names) < 2:
        return False
    target_name, source_names = _quick_align_pick_target_from_order(settings, selected_names)
    if not target_name or not source_names:
        return False

    previous_guard = bool(getattr(settings, 'is_updating', False))
    try:
        settings.is_updating = True
    except Exception:
        pass
    try:
        settings.selected_names_json = json.dumps(selected_names)
        settings.target_name = target_name
        settings.source_names_json = json.dumps(source_names)
        try:
            states = json.loads(getattr(settings, 'initial_states_json', '') or '{}')
        except Exception:
            states = {}
        if not isinstance(states, dict) or not all(name in states for name in selected_names):
            settings.initial_states_json = json.dumps(_capture_initial_states(selected_names))
    finally:
        try:
            settings.is_updating = previous_guard
        except Exception:
            pass
    if force_preview:
        force_update_align_preview(settings, context or getattr(bpy, 'context', None))
    return True


def _quick_align_target_mode_update(self, context):
    try:
        _refresh_quick_align_target_from_selection_settings(self, context, force_preview=True)
    except Exception:
        pass
    try:
        _request_quick_align_save(context)
    except Exception:
        pass


def _infer_dialog_selection(context, settings=None):
    selected_names = _quick_align_ordered_selected_names(context)
    if len(selected_names) >= 2:
        if settings is not None:
            try:
                settings.selected_names_json = json.dumps(selected_names)
            except Exception:
                pass
        target_name, source_names = _quick_align_pick_target_from_order(settings, selected_names)
        if target_name and source_names:
            return target_name, source_names

    if settings is not None:
        try:
            target_name = str(getattr(settings, 'target_name', '') or '').strip()
        except Exception:
            target_name = ''
        try:
            source_names = [name for name in json.loads(getattr(settings, 'source_names_json', '') or '[]') if name in bpy.data.objects and name != target_name]
        except Exception:
            source_names = []
        if target_name in bpy.data.objects and source_names:
            return target_name, source_names

    return '', []


def _normalize_popup_invocation(context, operator, settings=None):
    target_name = str(getattr(operator, 'target_name', '') or '').strip()
    try:
        source_names = [name for name in json.loads(getattr(operator, 'source_names_json', '') or '[]') if name in bpy.data.objects and name != target_name]
    except Exception:
        source_names = []

    used_inferred_target = False
    # A supplied target is authoritative.  Do not silently fall back to the
    # current selection when the named object no longer exists: doing so would
    # create a session for a different target than the public invocation named.
    if target_name and target_name not in bpy.data.objects:
        return '', [], used_inferred_target
    if target_name and source_names:
        return target_name, source_names, used_inferred_target

    target_name, source_names = _infer_dialog_selection(context, settings=settings)
    if target_name and source_names:
        operator.target_name = target_name
        operator.source_names_json = json.dumps(source_names)
        operator.hit_location_json = ''
        operator.hit_normal_json = ''
        operator.view_up_json = ''
        operator.view_right_json = ''
        used_inferred_target = True
        return target_name, source_names, used_inferred_target

    return '', [], used_inferred_target


def _capture_initial_states(source_names):
    initial_states = {}
    for name in source_names:
        obj = bpy.data.objects.get(name)
        if obj:
            initial_states[name] = {
                'matrix_world': [list(r) for r in obj.matrix_world],
                'location': list(obj.location),
                'scale': list(obj.scale),
                'rotation_mode': obj.rotation_mode,
                'rotation_euler': list(obj.rotation_euler),
                'rotation_quaternion': list(obj.rotation_quaternion),
                'rotation_axis_angle': list(obj.rotation_axis_angle),
            }
    return initial_states


def _quick_align_session_ready(settings) -> bool:
    if settings is None:
        return False
    try:
        target_name = str(getattr(settings, 'target_name', '') or '').strip()
        source_names = [
            name for name in json.loads(getattr(settings, 'source_names_json', '') or '[]')
            if name in bpy.data.objects and name != target_name
        ]
        initial_states = json.loads(getattr(settings, 'initial_states_json', '') or '{}')
    except Exception:
        return False
    if not target_name or target_name not in bpy.data.objects or not source_names:
        return False
    if not isinstance(initial_states, dict):
        return False
    return all(name in initial_states for name in source_names)


def _quick_align_operator_args_match_session(operator, settings) -> bool:
    if operator is None or settings is None:
        return False
    try:
        op_target = str(getattr(operator, 'target_name', '') or '').strip()
        op_sources_raw = str(getattr(operator, 'source_names_json', '') or '').strip()
        if not op_target and not op_sources_raw:
            return False
        session_target = str(getattr(settings, 'target_name', '') or '').strip()
        session_sources_raw = str(getattr(settings, 'source_names_json', '') or '[]')
        session_sources = [name for name in json.loads(session_sources_raw or '[]') if name in bpy.data.objects]
        if op_target and op_target != session_target:
            return False
        if op_sources_raw:
            op_sources = [name for name in json.loads(op_sources_raw or '[]') if name in bpy.data.objects]
            if op_target:
                op_sources = [name for name in op_sources if name != op_target]
            if op_sources != session_sources:
                return False
        return True
    except Exception:
        return False


def _unique_quick_align_names(names):
    result = []
    seen = set()
    for name in names or []:
        if not name or name in seen:
            continue
        seen.add(name)
        result.append(name)
    return result


def _prepare_quick_align_session(context, operator, settings):
    target_name, source_names, inferred_from_selection = _normalize_popup_invocation(context, operator, settings=settings)
    if not target_name or not source_names:
        return False, inferred_from_selection

    has_explicit_hit_data = bool(str(getattr(operator, 'hit_location_json', '') or '').strip())
    preserve_runtime_hit_settings = False
    runtime_hit_values = {}
    try:
        preserve_runtime_hit_settings = has_explicit_hit_data and str(getattr(settings, 'align_to_mode', '') or '') == 'HIT'
        if preserve_runtime_hit_settings:
            for prop_name in (
                'align_to_mode', 'normal_align', 'normal_axis', 'flip_normal',
                'twist_mode', 'twist_tangent_axis', 'target_tangent_axis',
                'view_tangent_axis', 'respect_locks',
            ):
                if hasattr(settings, prop_name):
                    runtime_hit_values[prop_name] = getattr(settings, prop_name)
    except Exception:
        preserve_runtime_hit_settings = False
        runtime_hit_values = {}

    previous_guard = bool(getattr(settings, 'is_updating', False))
    try:
        settings.is_updating = True
    except Exception:
        pass
    try:
        try:
            settings.initial_states_json = ''
        except Exception:
            pass
        selected_names = _unique_quick_align_names(list(source_names) + [target_name])
        try:
            current_selected = _quick_align_ordered_selected_names(context)
            if len(current_selected) >= 2 and set(current_selected) == set(selected_names):
                selected_names = current_selected
        except Exception:
            pass

        settings.selected_names_json = json.dumps(selected_names)
        settings.target_name = target_name
        settings.source_names_json = json.dumps(source_names)
        settings.hit_location_json = str(getattr(operator, 'hit_location_json', '') or '')
        settings.hit_normal_json = str(getattr(operator, 'hit_normal_json', '') or '')
        settings.view_up_json = str(getattr(operator, 'view_up_json', '') or '')
        settings.view_right_json = str(getattr(operator, 'view_right_json', '') or '')

        if bool(getattr(operator, '_quick_align_use_saved_settings_on_prepare', False)):
            _load_settings_from_prefs(settings)

        if (not has_explicit_hit_data) and len(selected_names) >= 2:
            try:
                settings.selected_names_json = json.dumps(selected_names)
                target_name, source_names = _quick_align_pick_target_from_order(settings, selected_names)
                settings.target_name = target_name
                settings.source_names_json = json.dumps(source_names)
            except Exception:
                pass

        if preserve_runtime_hit_settings:
            for prop_name, prop_value in runtime_hit_values.items():
                try:
                    setattr(settings, prop_name, prop_value)
                except Exception:
                    pass

        if inferred_from_selection and getattr(settings, 'align_to_mode', 'OBJECT') == 'HIT':
            settings.align_to_mode = 'OBJECT'
            settings.normal_align = False

        settings.initial_states_json = json.dumps(_capture_initial_states(_unique_quick_align_names(list(source_names) + [target_name])))
        try:
            settings.last_preview_time = 0.0
            settings.pending_update = False
            settings.timer_active = False
        except Exception:
            pass
    finally:
        try:
            settings.is_updating = previous_guard
        except Exception:
            pass

    force_update_align_preview(settings, context)
    return True, inferred_from_selection


def _default_saved_settings_dict():
    return {
        "align_pos_x": True,
        "align_pos_y": True,
        "align_pos_z": True,
        "source_align_x": "PIVOT",
        "source_align_y": "PIVOT",
        "source_align_z": "PIVOT",
        "target_align_x": "PIVOT",
        "target_align_y": "PIVOT",
        "target_align_z": "PIVOT",
        "align_to_mode": "OBJECT",
        "normal_align": False,
        "normal_axis": "Z",
        "flip_normal": False,
        "align_ori_x": True,
        "align_ori_y": True,
        "align_ori_z": True,
        "align_scale_x": True,
        "align_scale_y": True,
        "align_scale_z": True,
        "continuous_mode": False,
        "respect_locks": True,
        "equal_align_enabled": False,
        "equal_align_use_farthest_pair": False,
        "target_endpoint_mode": "LAST",
        "twist_mode": "AUTO",
        "twist_tangent_axis": "X",
        "target_tangent_axis": "X",
        "view_tangent_axis": "UP",
        "preset": "NONE",
    }

def _load_settings_from_prefs(settings):
    prefs = _prefs()
    data = _get_scene_runtime_quick_align_settings()
    if not isinstance(data, dict) and prefs and prefs.saved_settings_json:
        try:
            data = json.loads(prefs.saved_settings_json)
        except Exception:
            data = None
    if not isinstance(data, dict):
        data = _default_saved_settings_dict()

    for k, v in data.items():
        if hasattr(settings, k):
            try:
                setattr(settings, k, v)
            except Exception:
                pass

def _save_settings_to_prefs(settings):
    data = _default_saved_settings_dict()
    for k in list(data.keys()):
        if hasattr(settings, k):
            try:
                data[k] = getattr(settings, k)
            except Exception:
                pass
    try:
        _set_scene_runtime_quick_align_settings(data)
    except Exception:
        pass
    prefs = _prefs()
    if prefs:
        try:
            prefs.saved_settings_json = json.dumps(data)
        except Exception:
            pass
    try:
        _request_quick_align_save(getattr(bpy, 'context', None))
    except Exception:
        pass

def get_bbox_world_coords(obj):
    bbox_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    min_coord = Vector((min([c.x for c in bbox_corners]), min([c.y for c in bbox_corners]), min([c.z for c in bbox_corners])))
    max_coord = Vector((max([c.x for c in bbox_corners]), max([c.y for c in bbox_corners]), max([c.z for c in bbox_corners])))
    center_coord = (min_coord + max_coord) / 2.0
    pivot_coord = obj.matrix_world.translation.copy()
    
    return {
        'MIN': min_coord,
        'CENTER': center_coord,
        'PIVOT': pivot_coord,
        'MAX': max_coord
    }

def _axis_vec_from_basis(basis3x3: Matrix, axis: str) -> Vector:
    # Matrix columns correspond to local X/Y/Z in world space
    if axis == 'X':
        return Vector((basis3x3[0][0], basis3x3[1][0], basis3x3[2][0]))
    if axis == 'Y':
        return Vector((basis3x3[0][1], basis3x3[1][1], basis3x3[2][1]))
    return Vector((basis3x3[0][2], basis3x3[1][2], basis3x3[2][2]))

def _make_orthonormal_basis(x: Vector, y: Vector, z: Vector) -> Matrix:
    # Robust orthonormalization. Prefer keeping right-handedness.
    x = x.normalized() if x.length else Vector((1, 0, 0))
    y = (y - x * x.dot(y))
    y = y.normalized() if y.length else Vector((0, 1, 0))
    z = x.cross(y)
    z = z.normalized() if z.length else Vector((0, 0, 1))
    # Recompute y to ensure orthogonal
    y = z.cross(x)
    y = y.normalized() if y.length else Vector((0, 1, 0))
    return Matrix((x, y, z)).transposed()

def _basis_from_normal_and_tangent(normal_axis: str, tangent_axis: str, normal_vec: Vector, tangent_vec: Vector):
    """Build an orthonormal rotation basis (3x3 Matrix) where:
    - the specified local normal_axis points to normal_vec (world),
    - the specified local tangent_axis points to tangent_vec projected onto the normal plane (world).

    Returns None if it cannot build a stable basis.
    """
    try:
        if normal_axis == tangent_axis:
            return None
        if not isinstance(normal_vec, Vector) or not isinstance(tangent_vec, Vector):
            return None

        n = normal_vec.normalized() if normal_vec.length else Vector((0.0, 0.0, 1.0))
        t = tangent_vec - n * n.dot(tangent_vec)
        if t.length < 1e-8:
            return None
        t = t.normalized()

        x = y = z = None

        if normal_axis == 'Z':
            z = n
            if tangent_axis == 'X':
                x = t
                y = z.cross(x)
            elif tangent_axis == 'Y':
                y = t
                x = y.cross(z)
            else:
                return None
        elif normal_axis == 'X':
            x = n
            if tangent_axis == 'Y':
                y = t
                z = x.cross(y)
            elif tangent_axis == 'Z':
                z = t
                y = z.cross(x)
            else:
                return None
        elif normal_axis == 'Y':
            y = n
            if tangent_axis == 'X':
                x = t
                z = x.cross(y)
            elif tangent_axis == 'Z':
                z = t
                x = y.cross(z)
            else:
                return None
        else:
            return None

        if x is None or y is None or z is None:
            return None
        if x.length < 1e-8 or y.length < 1e-8 or z.length < 1e-8:
            return None

        x.normalize(); y.normalize(); z.normalize()

        return Matrix((x, y, z)).transposed()
    except Exception:
        return None

def _desired_rotation_matrix(source_basis: Matrix, target_basis: Matrix, use_x: bool, use_y: bool, use_z: bool) -> Matrix:
    # Build desired world basis by selectively taking axis directions from target.
    sx = _axis_vec_from_basis(source_basis, 'X')
    sy = _axis_vec_from_basis(source_basis, 'Y')
    sz = _axis_vec_from_basis(source_basis, 'Z')
    tx = _axis_vec_from_basis(target_basis, 'X')
    ty = _axis_vec_from_basis(target_basis, 'Y')
    tz = _axis_vec_from_basis(target_basis, 'Z')

    dx = tx if use_x else sx
    dy = ty if use_y else sy
    dz = tz if use_z else sz

    # Decide primary axis for stability
    if use_z:
        primary = dz
        secondary = dy if use_y else dx
        # Project secondary onto plane perpendicular to primary
        secondary = secondary - primary * primary.dot(secondary)
        if secondary.length < 1e-8:
            secondary = Vector((1, 0, 0)) if abs(primary.dot(Vector((1, 0, 0)))) < 0.9 else Vector((0, 1, 0))
        secondary = secondary.normalized()
        # basis columns are X,Y,Z.  Respect the meaning of the projected
        # secondary axis instead of assigning Zxsecondary to X (which reverses
        # X/Y when secondary is target Y).
        z = primary.normalized()
        if use_y:
            y = secondary
            x = y.cross(z)
        else:
            x = secondary
        y = z.cross(x).normalized()
        return _make_orthonormal_basis(x, y, z)

    if use_y:
        primary = dy
        secondary = dx
        secondary = secondary - primary * primary.dot(secondary)
        if secondary.length < 1e-8:
            secondary = Vector((1, 0, 0)) if abs(primary.dot(Vector((1, 0, 0)))) < 0.9 else Vector((0, 0, 1))
        secondary = secondary.normalized()
        # X cross Y yields the right-handed Z column.  The previous Y cross X
        # order reversed X/Z for every branch whose primary axis was Y.
        z = secondary.cross(primary)
        if z.length < 1e-8:
            z = Vector((0, 0, 1))
        z = z.normalized()
        y = primary.normalized()
        x = y.cross(z).normalized()
        return _make_orthonormal_basis(x, y, z)

    # only X or none
    primary = dx
    secondary = sy
    secondary = secondary - primary * primary.dot(secondary)
    if secondary.length < 1e-8:
        secondary = Vector((0, 1, 0)) if abs(primary.dot(Vector((0, 1, 0)))) < 0.9 else Vector((0, 0, 1))
    secondary = secondary.normalized()
    z = primary.cross(secondary)
    if z.length < 1e-8:
        z = Vector((0, 0, 1))
    z = z.normalized()
    x = primary.normalized()
    y = z.cross(x).normalized()
    return _make_orthonormal_basis(x, y, z)

def _apply_transform_locks(obj, init_data, respect_locks: bool = True):
    if not respect_locks:
        return
    try:
        # Location locks (local)
        if hasattr(obj, "lock_location"):
            loc = obj.location.copy()
            init_loc = Vector(init_data.get('location', list(loc)))
            for i in range(3):
                if obj.lock_location[i]:
                    loc[i] = init_loc[i]
            obj.location = loc

        # Rotation locks
        if hasattr(obj, "lock_rotation"):
            if obj.rotation_mode == 'QUATERNION':
                q = obj.rotation_quaternion.copy()
                init_q = init_data.get('rotation_quaternion', list(q))
                # lock_rotation affects xyz components; lock_rotation_w exists
                if getattr(obj, "lock_rotation_w", False):
                    q.w = init_q[0]
                for i in range(3):
                    if obj.lock_rotation[i]:
                        q[i + 1] = init_q[i + 1]
                if q.length:
                    q.normalize()
                obj.rotation_quaternion = q
            elif obj.rotation_mode == 'AXIS_ANGLE':
                aa = list(obj.rotation_axis_angle)
                init_aa = init_data.get('rotation_axis_angle', list(aa))
                # axis-angle locks are ambiguous; treat as axis locks
                for i in range(3):
                    if obj.lock_rotation[i]:
                        aa[i + 1] = init_aa[i + 1]
                obj.rotation_axis_angle = aa
            else:
                e = obj.rotation_euler.copy()
                init_e = Vector(init_data.get('rotation_euler', list(e)))
                for i in range(3):
                    if obj.lock_rotation[i]:
                        e[i] = init_e[i]
                obj.rotation_euler = e

        # Scale locks
        if hasattr(obj, "lock_scale"):
            sc = obj.scale.copy()
            init_sc = Vector(init_data.get('scale', list(sc)))
            for i in range(3):
                if obj.lock_scale[i]:
                    sc[i] = init_sc[i]
            obj.scale = sc
    except Exception:
        pass

def _apply_preset_to_settings(settings, preset_id: str):
    # Apply to all axes
    if preset_id == 'PIVOT_PIVOT':
        s = 'PIVOT'; t = 'PIVOT'
    elif preset_id == 'CENTER_CENTER':
        s = 'CENTER'; t = 'CENTER'
    elif preset_id == 'MIN_MIN':
        s = 'MIN'; t = 'MIN'
    elif preset_id == 'MAX_MAX':
        s = 'MAX'; t = 'MAX'
    elif preset_id == 'MIN_MAX':
        s = 'MIN'; t = 'MAX'
    elif preset_id == 'MAX_MIN':
        s = 'MAX'; t = 'MIN'
    else:
        return

    settings.source_align_x = s
    settings.source_align_y = s
    settings.source_align_z = s
    settings.target_align_x = t
    settings.target_align_y = t
    settings.target_align_z = t

def _extract_rot_and_scale(basis3x3: Matrix):
    cx = _axis_vec_from_basis(basis3x3, 'X')
    cy = _axis_vec_from_basis(basis3x3, 'Y')
    cz = _axis_vec_from_basis(basis3x3, 'Z')
    sx = cx.length
    sy = cy.length
    sz = cz.length
    rx = cx.normalized() if sx else Vector((1, 0, 0))
    ry = cy.normalized() if sy else Vector((0, 1, 0))
    rz = cz.normalized() if sz else Vector((0, 0, 1))
    rot = _make_orthonormal_basis(rx, ry, rz)
    return rot, (sx, sy, sz)

def _compose_basis(rot3x3: Matrix, scale_xyz):
    sx, sy, sz = scale_xyz
    basis = Matrix.Identity(3)
    for i, s in enumerate((sx, sy, sz)):
        col = _axis_vec_from_basis(rot3x3, 'XYZ'[i]) * (s if s else 0.0)
        basis[0][i] = col.x
        basis[1][i] = col.y
        basis[2][i] = col.z
    return basis

def _parse_vec_json(s, fallback=(0.0, 0.0, 0.0)):
    try:
        v = json.loads(s)
        if isinstance(v, (list, tuple)) and len(v) >= 3:
            return Vector((float(v[0]), float(v[1]), float(v[2])))
    except Exception:
        pass
    return Vector(fallback)

def _restore_quick_align_initial_state(obj, init_data):
    if obj is None or not isinstance(init_data, dict):
        return
    try:
        mw_list = init_data.get('matrix_world')
        if mw_list:
            obj.matrix_world = Matrix(mw_list)
            return
    except Exception:
        pass
    try:
        obj.location = init_data.get('location', obj.location)
        obj.scale = init_data.get('scale', obj.scale)
        if obj.rotation_mode == 'QUATERNION' and 'rotation_quaternion' in init_data:
            obj.rotation_quaternion = init_data['rotation_quaternion']
        elif obj.rotation_mode == 'AXIS_ANGLE' and 'rotation_axis_angle' in init_data:
            obj.rotation_axis_angle = init_data['rotation_axis_angle']
        else:
            obj.rotation_euler = init_data.get('rotation_euler', obj.rotation_euler)
    except Exception:
        pass


def _axis_ref_values_from_coords(coords, ref_x, ref_y, ref_z):
    try:
        return Vector((coords[ref_x].x, coords[ref_y].y, coords[ref_z].z))
    except Exception:
        return Vector((0.0, 0.0, 0.0))


def _quick_align_distribution_order(settings, all_names, initial_states=None):
    names = _unique_quick_align_names([name for name in all_names if name in bpy.data.objects])
    if len(names) < 3:
        return []
    if not bool(getattr(settings, 'equal_align_use_farthest_pair', False)):
        return names

    positions = {}
    for name in names:
        obj = bpy.data.objects.get(name)
        if obj is None:
            continue
        try:
            init_data = initial_states.get(name) if isinstance(initial_states, dict) else None
            mw_list = init_data.get('matrix_world') if isinstance(init_data, dict) else None
            if mw_list:
                positions[name] = Matrix(mw_list).translation.copy()
            else:
                positions[name] = obj.matrix_world.translation.copy()
        except Exception:
            positions[name] = Vector((0.0, 0.0, 0.0))
    if len(positions) < 3:
        return names

    index = {name: i for i, name in enumerate(names)}
    best = None
    for i, a in enumerate(names):
        pa = positions.get(a)
        if pa is None:
            continue
        for b in names[i + 1:]:
            pb = positions.get(b)
            if pb is None:
                continue
            d = (pa - pb).length_squared
            key = (d, -min(index[a], index[b]), -max(index[a], index[b]))
            if best is None or key > best[0]:
                best = (key, a, b)
    if best is None:
        return names

    _key, a, b = best
    if index[a] <= index[b]:
        start_name, end_name = a, b
    else:
        start_name, end_name = b, a
    start_pos = positions.get(start_name, Vector((0.0, 0.0, 0.0)))
    middle = [name for name in names if name not in {start_name, end_name}]
    middle.sort(key=lambda name: ((positions.get(name, Vector((0.0, 0.0, 0.0))) - start_pos).length, index.get(name, 0)))
    return [start_name] + middle + [end_name]


def _slerp_quick_align_rotation(start_rot, end_rot, t):
    try:
        qa = start_rot.to_quaternion()
        qb = end_rot.to_quaternion()
        return qa.slerp(qb, float(t)).to_matrix().to_3x3()
    except Exception:
        try:
            return end_rot.copy() if float(t) >= 0.5 else start_rot.copy()
        except Exception:
            return Matrix.Identity(3)


def _apply_quick_align_even_distribution(settings, context, initial_states, all_names):
    if settings is None or context is None:
        return False
    try:
        if str(getattr(settings, 'align_to_mode', 'OBJECT') or 'OBJECT') != 'OBJECT':
            return False
        if not bool(getattr(settings, 'equal_align_enabled', False)):
            return False
    except Exception:
        return False

    order = _quick_align_distribution_order(settings, all_names, initial_states)
    if len(order) < 3:
        return False

    for name in order:
        obj = bpy.data.objects.get(name)
        init_data = initial_states.get(name) if isinstance(initial_states, dict) else None
        if obj is not None and init_data:
            _restore_quick_align_initial_state(obj, init_data)
    try:
        context.view_layer.update()
    except Exception:
        pass

    start_obj = bpy.data.objects.get(order[0])
    end_obj = bpy.data.objects.get(order[-1])
    if start_obj is None or end_obj is None:
        return False

    try:
        start_coords = get_bbox_world_coords(start_obj)
        end_coords = get_bbox_world_coords(end_obj)
        start_ref = _axis_ref_values_from_coords(start_coords, settings.source_align_x, settings.source_align_y, settings.source_align_z)
        end_ref = _axis_ref_values_from_coords(end_coords, settings.target_align_x, settings.target_align_y, settings.target_align_z)
    except Exception:
        return False

    try:
        start_rot, start_scale = _extract_rot_and_scale(start_obj.matrix_world.to_3x3())
        end_rot, end_scale = _extract_rot_and_scale(end_obj.matrix_world.to_3x3())
    except Exception:
        start_rot, start_scale = Matrix.Identity(3), (1.0, 1.0, 1.0)
        end_rot, end_scale = Matrix.Identity(3), (1.0, 1.0, 1.0)

    use_pos = (bool(settings.align_pos_x), bool(settings.align_pos_y), bool(settings.align_pos_z))
    use_ori = (bool(settings.align_ori_x), bool(settings.align_ori_y), bool(settings.align_ori_z))
    use_scale = (bool(settings.align_scale_x), bool(settings.align_scale_y), bool(settings.align_scale_z))
    respect_locks = bool(getattr(settings, 'respect_locks', True))
    n = len(order)

    for idx, name in enumerate(order[1:-1], start=1):
        obj = bpy.data.objects.get(name)
        if obj is None:
            continue
        init_data = initial_states.get(name) if isinstance(initial_states, dict) else None
        if not init_data:
            continue

        _restore_quick_align_initial_state(obj, init_data)
        try:
            context.view_layer.update()
        except Exception:
            pass

        t = float(idx) / float(max(1, n - 1))
        mw = obj.matrix_world.copy()
        loc = mw.to_translation()
        src_rot, src_scale = _extract_rot_and_scale(mw.to_3x3())

        interp_rot = _slerp_quick_align_rotation(start_rot, end_rot, t)
        desired_rot = _desired_rotation_matrix(src_rot, interp_rot, use_ori[0], use_ori[1], use_ori[2]) if any(use_ori) else src_rot

        sx, sy, sz = src_scale
        target_scale = (
            start_scale[0] + (end_scale[0] - start_scale[0]) * t,
            start_scale[1] + (end_scale[1] - start_scale[1]) * t,
            start_scale[2] + (end_scale[2] - start_scale[2]) * t,
        )
        locks_scale = getattr(obj, 'lock_scale', (False, False, False))
        if use_scale[0] and (not respect_locks or not locks_scale[0]):
            sx = target_scale[0]
        if use_scale[1] and (not respect_locks or not locks_scale[1]):
            sy = target_scale[1]
        if use_scale[2] and (not respect_locks or not locks_scale[2]):
            sz = target_scale[2]

        basis = _compose_basis(desired_rot, (sx, sy, sz))
        obj.matrix_world = Matrix.Translation(loc) @ basis.to_4x4()

        desired_ref = start_ref.lerp(end_ref, t)
        try:
            source_coords = get_bbox_world_coords(obj)
            current_ref = _axis_ref_values_from_coords(source_coords, settings.source_align_x, settings.source_align_y, settings.source_align_z)
        except Exception:
            current_ref = obj.matrix_world.translation.copy()

        delta = desired_ref - current_ref
        locks_loc = getattr(obj, 'lock_location', (False, False, False))
        if (not use_pos[0]) or (respect_locks and locks_loc[0]):
            delta.x = 0.0
        if (not use_pos[1]) or (respect_locks and locks_loc[1]):
            delta.y = 0.0
        if (not use_pos[2]) or (respect_locks and locks_loc[2]):
            delta.z = 0.0

        mw_final = obj.matrix_world.copy()
        mw_final.translation = mw_final.translation + delta
        obj.matrix_world = mw_final
        _apply_transform_locks(obj, init_data, respect_locks=respect_locks)

    try:
        context.view_layer.update()
        _safe_area_redraw(context)
    except Exception:
        pass
    return True


def _timer_preview_update():
    try:
        settings = _wm_quick_align_settings()
        if settings is None:
            return None
        if not getattr(settings, "pending_update", False):
            settings.timer_active = False
            return None
        settings.pending_update = False
        settings.timer_active = False
        force_update_align_preview(settings, bpy.context)
    except Exception:
        return None
    return None

def _update_align_preview_internal(self, context, force: bool = False):
    _request_quick_align_save(context)
    try:
        from .. import settings as _settings
        if _settings.is_restoring():
            return
    except Exception:
        pass
    if getattr(self, "is_updating", False):
        return
    if not self.target_name or self.target_name not in bpy.data.objects:
        return
    if not self.initial_states_json:
        return
    if not _quick_align_session_matches_current_selection(self, context):
        return

    # Throttle preview updates
    prefs = _prefs()
    interval = 0.0
    try:
        interval = max(0.0, float(getattr(prefs, "preview_throttle_ms", 0)) / 1000.0) if prefs else 0.0
    except Exception:
        interval = 0.0

    now = time.perf_counter()
    if (not bool(force)) and interval > 0.0 and (now - float(getattr(self, "last_preview_time", 0.0))) < interval:
        self.pending_update = True
        if not self.timer_active:
            self.timer_active = True
            delay = max(0.0, interval - (now - float(getattr(self, "last_preview_time", 0.0))))
            try:
                bpy.app.timers.register(_timer_preview_update, first_interval=delay)
            except Exception:
                self.timer_active = False
        return
    if bool(force):
        try:
            self.pending_update = False
            self.timer_active = False
        except Exception:
            pass
    self.last_preview_time = now

    self.is_updating = True
    try:
        target_obj = bpy.data.objects[self.target_name]
        target_coords = get_bbox_world_coords(target_obj)
        target_rot, target_scale = _extract_rot_and_scale(target_obj.matrix_world.to_3x3())

        hit_loc = _parse_vec_json(self.hit_location_json, fallback=target_obj.matrix_world.translation)
        hit_nrm = _parse_vec_json(self.hit_normal_json, fallback=(0.0, 0.0, 1.0))
        if hit_nrm.length:
            hit_nrm.normalize()
        if self.flip_normal:
            hit_nrm.negate()

        view_up = _parse_vec_json(getattr(self, 'view_up_json', ''), fallback=(0.0, 1.0, 0.0))
        view_right = _parse_vec_json(getattr(self, 'view_right_json', ''), fallback=(1.0, 0.0, 0.0))
        if view_up.length:
            view_up.normalize()
        if view_right.length:
            view_right.normalize()

        # Determine target coordinate values for position (axis-specific)
        if self.align_to_mode == 'HIT':
            target_val_x, target_val_y, target_val_z = hit_loc.x, hit_loc.y, hit_loc.z
        else:
            target_val_x = target_coords[self.target_align_x].x
            target_val_y = target_coords[self.target_align_y].y
            target_val_z = target_coords[self.target_align_z].z

        # Optional: build a "normal target rotation" when requested
        normal_target_rot = None
        if self.align_to_mode == 'HIT' and self.normal_align and hit_nrm.length:
            n = hit_nrm.normalized()
            twist_mode = getattr(self, "twist_mode", "AUTO")

            # Legacy behavior (no roll stabilization)
            if twist_mode == 'OFF':
                # Build a stable basis where the chosen axis points to the normal
                helper = Vector((1, 0, 0)) if abs(n.dot(Vector((1, 0, 0)))) < 0.9 else Vector((0, 1, 0))
                if self.normal_axis == 'X':
                    x = n
                    z = x.cross(helper)
                    if z.length < 1e-8:
                        z = x.cross(Vector((0, 0, 1)))
                    z.normalize()
                    y = z.cross(x)
                    y.normalize()
                    normal_target_rot = Matrix((x, y, z)).transposed()
                elif self.normal_axis == 'Y':
                    y = n
                    x = helper.cross(y)
                    if x.length < 1e-8:
                        x = Vector((0, 0, 1)).cross(y)
                    x.normalize()
                    z = x.cross(y)
                    z.normalize()
                    normal_target_rot = Matrix((x, y, z)).transposed()
                else:
                    z = n
                    x = helper.cross(z)
                    if x.length < 1e-8:
                        x = Vector((0, 0, 1)).cross(z)
                    x.normalize()
                    y = z.cross(x)
                    y.normalize()
                    normal_target_rot = Matrix((x, y, z)).transposed()
            else:
                # Roll stabilization: use a tangent reference direction projected onto the hit plane
                normal_axis = getattr(self, "normal_axis", "Z")
                tangent_axis = getattr(self, "twist_tangent_axis", "X")
                if tangent_axis == normal_axis:
                    tangent_axis = 'X' if normal_axis != 'X' else 'Y'

                target_axis = getattr(self, "target_tangent_axis", "X")
                view_axis = getattr(self, "view_tangent_axis", "UP")

                def _proj(v):
                    return v - n * n.dot(v)

                def _pick_tangent(candidates):
                    for v in candidates:
                        if not isinstance(v, Vector):
                            continue
                        tv = _proj(v)
                        if tv.length > 1e-8:
                            return tv.normalized()
                    return None

                # Candidate vectors
                cand_target = []
                try:
                    order = [target_axis, 'X', 'Y', 'Z']
                    seen = set()
                    for a in order:
                        if a in seen or a not in {'X', 'Y', 'Z'}:
                            continue
                        seen.add(a)
                        cand_target.append(_axis_vec_from_basis(target_rot, a))
                except Exception:
                    cand_target = []

                cand_view = []
                try:
                    if view_axis == 'RIGHT':
                        cand_view = [view_right, view_up]
                    else:
                        cand_view = [view_up, view_right]
                except Exception:
                    cand_view = []

                cand_world = [Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))]

                t = None
                if twist_mode == 'TARGET':
                    t = _pick_tangent(cand_target)
                    if t is None:
                        t = _pick_tangent(cand_view) or _pick_tangent(cand_world)
                elif twist_mode == 'VIEW':
                    t = _pick_tangent(cand_view)
                    if t is None:
                        t = _pick_tangent(cand_target) or _pick_tangent(cand_world)
                elif twist_mode == 'WORLD':
                    t = _pick_tangent(cand_world)
                    if t is None:
                        t = _pick_tangent(cand_view) or _pick_tangent(cand_target)
                else:  # AUTO
                    t = _pick_tangent(cand_target)
                    if t is None:
                        t = _pick_tangent(cand_view)
                    if t is None:
                        t = _pick_tangent(cand_world)

                if t is None:
                    # Fallback to a robust legacy helper if everything degenerates
                    helper = Vector((1, 0, 0)) if abs(n.dot(Vector((1, 0, 0)))) < 0.9 else Vector((0, 1, 0))
                    t = _proj(helper)
                    if t.length < 1e-8:
                        t = _proj(Vector((0, 1, 0)))
                    if t.length < 1e-8:
                        t = _proj(Vector((0, 0, 1)))
                    if t.length > 1e-8:
                        t.normalize()
                    else:
                        t = None

                if t is not None:
                    normal_target_rot = _basis_from_normal_and_tangent(normal_axis, tangent_axis, n, t)
        initial_states = json.loads(self.initial_states_json)
        source_names = json.loads(self.source_names_json)

        all_names = _unique_quick_align_names(list(source_names) + [self.target_name])
        if _apply_quick_align_even_distribution(self, context, initial_states, all_names):
            return

        respect_locks = bool(self.respect_locks)

        for name in source_names:
            obj = bpy.data.objects.get(name)
            if not obj:
                continue
            init_data = initial_states.get(name)
            if not init_data:
                continue

            # Restore
            try:
                mw_list = init_data.get('matrix_world')
                if mw_list:
                    obj.matrix_world = Matrix(mw_list)
                else:
                    obj.location = init_data.get('location', obj.location)
                    obj.scale = init_data.get('scale', obj.scale)
                    if obj.rotation_mode == 'QUATERNION' and 'rotation_quaternion' in init_data:
                        obj.rotation_quaternion = init_data['rotation_quaternion']
                    elif obj.rotation_mode == 'AXIS_ANGLE' and 'rotation_axis_angle' in init_data:
                        obj.rotation_axis_angle = init_data['rotation_axis_angle']
                    else:
                        obj.rotation_euler = init_data.get('rotation_euler', obj.rotation_euler)
            except Exception:
                pass

            mw = obj.matrix_world.copy()
            loc = mw.to_translation()
            src_rot, src_scale = _extract_rot_and_scale(mw.to_3x3())

            # Decide desired rotation
            use_x, use_y, use_z = bool(self.align_ori_x), bool(self.align_ori_y), bool(self.align_ori_z)

            # Hit Point Normal Align: optionally stabilize roll (tangent direction)
            twist_mode = getattr(self, "twist_mode", "AUTO")
            if (self.align_to_mode == 'HIT') and self.normal_align and (normal_target_rot is not None) and (twist_mode != 'OFF'):
                # Full rotation is defined by normal + tangent; ignore axis toggles to keep twist stable.
                desired_rot = normal_target_rot
            else:
                if normal_target_rot is not None:
                    # Force the chosen axis to be aligned to the normal
                    if self.normal_axis == 'X':
                        use_x = True
                    elif self.normal_axis == 'Y':
                        use_y = True
                    else:
                        use_z = True
                    t_rot = normal_target_rot
                else:
                    t_rot = target_rot

                if use_x or use_y or use_z:
                    desired_rot = _desired_rotation_matrix(src_rot, t_rot, use_x, use_y, use_z)
                else:
                    desired_rot = src_rot

# Decide desired scale (world)
            sx, sy, sz = src_scale
            tsx, tsy, tsz = target_scale
            if self.align_scale_x and (not respect_locks or not getattr(obj, "lock_scale", (False, False, False))[0]):
                sx = tsx
            if self.align_scale_y and (not respect_locks or not getattr(obj, "lock_scale", (False, False, False))[1]):
                sy = tsy
            if self.align_scale_z and (not respect_locks or not getattr(obj, "lock_scale", (False, False, False))[2]):
                sz = tsz

            basis = _compose_basis(desired_rot, (sx, sy, sz))
            mw_new = Matrix.Translation(loc) @ basis.to_4x4()
            obj.matrix_world = mw_new

            # Position alignment (compute after rot/scale)
            source_coords = get_bbox_world_coords(obj)
            src_val_x = source_coords[self.source_align_x].x
            src_val_y = source_coords[self.source_align_y].y
            src_val_z = source_coords[self.source_align_z].z

            dx = (target_val_x - src_val_x) if self.align_pos_x else 0.0
            dy = (target_val_y - src_val_y) if self.align_pos_y else 0.0
            dz = (target_val_z - src_val_z) if self.align_pos_z else 0.0

            # Respect location locks at delta stage
            if respect_locks and hasattr(obj, "lock_location"):
                if obj.lock_location[0]:
                    dx = 0.0
                if obj.lock_location[1]:
                    dy = 0.0
                if obj.lock_location[2]:
                    dz = 0.0

            mw_final = obj.matrix_world.copy()
            mw_final.translation = mw_final.translation + Vector((dx, dy, dz))
            obj.matrix_world = mw_final

            # Enforce locked channels as final guard
            _apply_transform_locks(obj, init_data, respect_locks=respect_locks)

        context.view_layer.update()
        _safe_area_redraw(context)
    finally:
        self.is_updating = False


def update_align_preview(self, context):
    return _update_align_preview_internal(self, context, force=False)

def force_update_align_preview(self, context):
    return _update_align_preview_internal(self, context, force=True)

class QuickAlignSettings(bpy.types.PropertyGroup):
    align_pos_x: BoolProperty(name="X Position", description="Align the X-axis position.", default=True, update=update_align_preview)
    align_pos_y: BoolProperty(name="Y Position", description="Align the Y-axis position.", default=True, update=update_align_preview)
    align_pos_z: BoolProperty(name="Z Position", description="Align the Z-axis position.", default=True, update=update_align_preview)

    align_items = [
        ('MIN', "Minimum", "Minimum coordinate of the bounding box."),
        ('CENTER', "Center", "Center coordinate of the bounding box."),
        ('PIVOT', "Pivot", "Pivot point (Origin) of the object."),
        ('MAX', "Maximum", "Maximum coordinate of the bounding box."),
    ]

    # Axis-specific reference points
    source_align_x: EnumProperty(name="X Ref", description="Reference point of the objects to be moved.", items=align_items, default='PIVOT', update=update_align_preview)
    source_align_y: EnumProperty(name="Y Ref", description="Reference point of the objects to be moved.", items=align_items, default='PIVOT', update=update_align_preview)
    source_align_z: EnumProperty(name="Z Ref", description="Reference point of the objects to be moved.", items=align_items, default='PIVOT', update=update_align_preview)

    target_align_x: EnumProperty(name="X Ref", description="Reference point of the target object.", items=align_items, default='PIVOT', update=update_align_preview)
    target_align_y: EnumProperty(name="Y Ref", description="Reference point of the target object.", items=align_items, default='PIVOT', update=update_align_preview)
    target_align_z: EnumProperty(name="Z Ref", description="Reference point of the target object.", items=align_items, default='PIVOT', update=update_align_preview)

    align_to_items = [
        ('OBJECT', "Target Object", "Use the clicked object's reference points."),
        ('HIT', "Hit Point", "Use the clicked surface point (ray hit location)."),
    ]
    align_to_mode: EnumProperty(
        name="Align To:",
        description="Choose whether the sources align to the target object's reference points or to the exact clicked surface point.",
        items=align_to_items,
        default='OBJECT',
        update=update_align_preview,
    )

    # Hit data from raycast
    hit_location_json: StringProperty(name="Hit Location", description="Internal JSON vector storing the clicked target surface position for hit-point alignment.", default="", options={'HIDDEN'})
    hit_normal_json: StringProperty(name="Hit Normal", description="Internal JSON vector storing the clicked target surface normal for normal alignment.", default="", options={'HIDDEN'})
    view_up_json: StringProperty(name="View Up", description="Internal JSON vector storing the viewport up direction captured at pick time.", default="", options={'HIDDEN'})
    view_right_json: StringProperty(name="View Right", description="Internal JSON vector storing the viewport right direction captured at pick time.", default="", options={'HIDDEN'})

    normal_align: BoolProperty(name="Normal Align", description="When Align To is Hit Point, optionally align orientation to face normal.", default=False, update=update_align_preview)
    normal_axis: EnumProperty(
        name="Normal Axis",
        description="Which local axis of the source should rotate to face the clicked hit normal when normal alignment is enabled.",
        items=[
            ('X', "X Axis", "Use the source object's local X axis as the axis that faces the clicked surface normal."),
            ('Y', "Y Axis", "Use the source object's local Y axis as the axis that faces the clicked surface normal."),
            ('Z', "Z Axis", "Use the source object's local Z axis as the axis that faces the clicked surface normal."),
        ],
        default='Z',
        update=update_align_preview
    )
    flip_normal: BoolProperty(name="Flip Normal", description="Invert the hit normal direction.", default=False, update=update_align_preview)

    twist_items = [
        ('OFF', "Off", "Use the legacy helper axis. Roll may be arbitrary."),
        ('AUTO', "Auto", "Use target orientation; fallback to view; then world."),
        ('TARGET', "Target", "Use target object orientation to stabilize roll."),
        ('VIEW', "View", "Use viewport orientation to stabilize roll."),
        ('WORLD', "World", "Use world axis to stabilize roll."),
    ]
    twist_mode: EnumProperty(
        name="Twist Stabilization",
        description="Stabilize roll around the hit normal.",
        items=twist_items,
        default='AUTO',
        update=update_align_preview
    )

    twist_tangent_axis: EnumProperty(
        name="Tangent Axis",
        description="Choose which source local axis is used as the roll/tangent reference after the normal axis is aligned.",
        items=[
            ('X', "X Axis", "Use the source object's local X axis as the roll reference around the aligned normal."),
            ('Y', "Y Axis", "Use the source object's local Y axis as the roll reference around the aligned normal."),
            ('Z', "Z Axis", "Use the source object's local Z axis as the roll reference around the aligned normal."),
        ],
        default='X',
        update=update_align_preview
    )

    target_tangent_axis: EnumProperty(
        name="Target Axis",
        description="Choose which target local axis supplies the tangent direction used to stabilize roll.",
        items=[
            ('X', "X Axis", "Use the target object's local X axis as the tangent reference."),
            ('Y', "Y Axis", "Use the target object's local Y axis as the tangent reference."),
            ('Z', "Z Axis", "Use the target object's local Z axis as the tangent reference."),
        ],
        default='X',
        update=update_align_preview
    )

    view_tangent_axis: EnumProperty(
        name="View Axis",
        description="Choose which viewport direction supplies the tangent direction used to stabilize roll.",
        items=[
            ('UP', "View Up", "Use the current viewport up direction as the tangent reference."),
            ('RIGHT', "View Right", "Use the current viewport right direction as the tangent reference."),
        ],
        default='UP',
        update=update_align_preview
    )

    # Orientation (vector-based axis matching)
    align_ori_x: BoolProperty(name="X Axis", description="Align the object's local X axis to the target's local X axis (world direction).", default=True, update=update_align_preview)
    align_ori_y: BoolProperty(name="Y Axis", description="Align the object's local Y axis to the target's local Y axis (world direction).", default=True, update=update_align_preview)
    align_ori_z: BoolProperty(name="Z Axis", description="Align the object's local Z axis to the target's local Z axis (world direction).", default=True, update=update_align_preview)

    # Scale (world-scale matching)
    align_scale_x: BoolProperty(name="X Axis", description="Match the X-axis scale.", default=True, update=update_align_preview)
    align_scale_y: BoolProperty(name="Y Axis", description="Match the Y-axis scale.", default=True, update=update_align_preview)
    align_scale_z: BoolProperty(name="Z Axis", description="Match the Z-axis scale.", default=True, update=update_align_preview)

    equal_align_enabled: BoolProperty(
        name="Even Distribution",
        description="Evenly distribute the intermediate objects between the first endpoint and the target endpoint. Only enabled position, orientation, and scale channels are affected, and the axis-specific source/target references are respected.",
        default=False,
        update=update_align_preview,
    )
    equal_align_use_farthest_pair: BoolProperty(
        name="Use Farthest Pair",
        description="Use the two farthest selected objects as endpoints, then distribute the remaining objects by distance from the start endpoint instead of selection order.",
        default=False,
        update=update_align_preview,
    )

    target_endpoint_mode: EnumProperty(
        name="Target Selection:",
        description="Choose whether Quick Align uses the first selected object or the last selected object as the target.",
        items=[
            ('LAST', "Last Selected", "Use the last selected object as the target; all other selected objects become sources."),
            ('FIRST', "First Selected", "Use the first selected object as the target; all other selected objects become sources."),
        ],
        default='LAST',
        update=_quick_align_target_mode_update,
    )

    continuous_mode: BoolProperty(name="Continuous Mode", description="After applying Quick Align, keep running with the current selection workflow so another alignment can be launched without picking a viewport target.", default=False, update=lambda self, context: _request_quick_align_save(context))
    respect_locks: BoolProperty(name="Respect Locks", description="Do not change locked transform channels.", default=True, update=update_align_preview)

    target_name: StringProperty(name="Target Object Name", description="Internal target object name captured when Quick Align starts.", options={'HIDDEN'})
    source_names_json: StringProperty(name="Source Object Names", description="Internal JSON list of source object names captured when Quick Align starts.", options={'HIDDEN'})
    selected_names_json: StringProperty(name="Selected Object Names", description="Internal JSON list preserving the selected object order captured when Quick Align starts.", default="", options={'HIDDEN'})
    initial_states_json: StringProperty(name="Initial Source Transforms", description="Internal JSON snapshot of source transforms used to preview and apply alignment safely.", options={'HIDDEN'})

    # Preview control
    is_updating: BoolProperty(name="Preview Update Guard", description="Internal guard that prevents recursive Quick Align preview updates.", default=False, options={'HIDDEN'})
    last_preview_time: FloatProperty(name="Last Preview Time", description="Internal timestamp used to throttle expensive Quick Align preview updates.", default=0.0, options={'HIDDEN'})
    pending_update: BoolProperty(name="Pending Preview Update", description="Internal flag that schedules a deferred Quick Align preview update.", default=False, options={'HIDDEN'})
    timer_active: BoolProperty(name="Preview Timer Active", description="Internal flag that records whether a deferred Quick Align preview timer is running.", default=False, options={'HIDDEN'})

    # Preset selector (applies immediately)
    def _preset_update(self, context):
        if self.preset == 'NONE':
            return
        _apply_preset_to_settings(self, self.preset)
        self.preset = 'NONE'
        force_update_align_preview(self, context)

    preset: EnumProperty(
        name="Preset",
        description="Apply a common alignment preset.",
        items=[
            ('NONE', "-", "No preset is applied. Use the current manual Quick Align settings."),
            ('PIVOT_PIVOT', "Pivot → Pivot", "Align each source object's pivot/origin to the target object's pivot/origin."),
            ('CENTER_CENTER', "Center → Center", "Align each source object's bounding-box center to the target object's bounding-box center."),
            ('MIN_MIN', "Min → Min", "Align each source minimum bound to the target minimum bound on the enabled axes."),
            ('MAX_MAX', "Max → Max", "Align each source maximum bound to the target maximum bound on the enabled axes."),
            ('MIN_MAX', "Min → Max", "Align each source minimum bound to the target maximum bound on the enabled axes."),
            ('MAX_MIN', "Max → Min", "Align each source maximum bound to the target minimum bound on the enabled axes."),
        ],
        default='NONE',
        update=_preset_update
    )

class OBJECT_OT_quick_align_swap_refs(bpy.types.Operator):
    """Swap Source/Target Refs"""
    bl_idname = "object.quick_align_swap_refs"
    bl_label = "Swap Source/Target Refs"
    bl_description = "Swap the source and target reference points used on each axis in the Quick Align dialog"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        s = _wm_quick_align_settings(context)
        if s is None:
            return {'CANCELLED'}
        for axis in ('x', 'y', 'z'):
            sa = getattr(s, f"source_align_{axis}")
            ta = getattr(s, f"target_align_{axis}")
            setattr(s, f"source_align_{axis}", ta)
            setattr(s, f"target_align_{axis}", sa)
        force_update_align_preview(s, context)
        return {'FINISHED'}

class OBJECT_OT_quick_align_reset_dialog(bpy.types.Operator):
    """Reset dialog settings to last saved"""
    bl_idname = "object.quick_align_reset_dialog"
    bl_label = "Reset (This Dialog)"
    bl_description = "Restore the Quick Align dialog options to the last saved preference values"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        s = _wm_quick_align_settings(context)
        if s is None:
            return {'CANCELLED'}
        _load_settings_from_prefs(s)
        force_update_align_preview(s, context)
        return {'FINISHED'}

class OBJECT_OT_quick_align_popup(bpy.types.Operator):
    """Align"""
    bl_idname = "object.quick_align_popup"
    bl_label = "Align"
    bl_description = "Open the Quick Align dialog for the picked target so you can preview and apply precise alignment"
    bl_options = {'INTERNAL', 'UNDO'} # REGISTERを外し、左下のパネルを非表示にします
    bl_undo_group = 'Smart Transform Suite'

    target_name: StringProperty(name="Target Object Name", description="Internal Quick Align target object name passed from the picker to the popup.", options={'HIDDEN'})
    source_names_json: StringProperty(name="Source Object Names", description="Internal JSON list of source object names passed from the picker to the popup.", options={'HIDDEN'})
    hit_location_json: StringProperty(name="Hit Location", description="Internal JSON vector storing the clicked target surface position.", default="", options={'HIDDEN'})
    hit_normal_json: StringProperty(name="Hit Normal", description="Internal JSON vector storing the clicked target surface normal.", default="", options={'HIDDEN'})
    view_up_json: StringProperty(name="View Up", description="Internal JSON vector storing the viewport up direction at pick time.", default="", options={'HIDDEN'})
    view_right_json: StringProperty(name="View Right", description="Internal JSON vector storing the viewport right direction at pick time.", default="", options={'HIDDEN'})

    def invoke(self, context, event):
        settings = _wm_quick_align_settings(context)
        if settings is None:
            return {'CANCELLED'}

        try:
            self._quick_align_use_saved_settings_on_prepare = True
        except Exception:
            pass
        try:
            prepared, _inferred_from_selection = _prepare_quick_align_session(context, self, settings)
        finally:
            try:
                self._quick_align_use_saved_settings_on_prepare = False
            except Exception:
                pass
        if not prepared:
            self.report({'WARNING'}, iface_("Select at least two objects before starting Quick Align."))
            return {'CANCELLED'}
        try:
            self._quick_align_dialog_prepared = True
        except Exception:
            pass
        
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        settings = _wm_quick_align_settings(context)
        if settings is None:
            _draw_icon_label(layout, iface_("Quick Align settings are unavailable."), icon='ERROR')
            return

        # Header
        try:
            sources = json.loads(settings.source_names_json) if settings.source_names_json else []
        except Exception:
            sources = []
        header = layout.box()
        row = header.row(align=True)
        _draw_icon_label(row, f"{iface_('Target:')} {settings.target_name}", icon='OBJECT_DATA')
        _draw_icon_label(row, f"{iface_('Sources:')} {len(sources)}", icon='OBJECT_DATA')
        row_target = header.row(align=True)
        row_target.prop(settings, "target_endpoint_mode", text=iface_("Target Selection:"))

        header.label(text=iface_("Preset"))
        header.prop(settings, "preset", text="")
        preset_actions = header.row(align=True)
        _operator(preset_actions, "object.quick_align_swap_refs", text=iface_("Swap Source/Target Refs"), icon='ARROW_LEFTRIGHT', custom_icon='swap')
        _operator(preset_actions, "object.quick_align_reset_dialog", text=iface_("Reset (This Dialog)"), icon='LOOP_BACK', custom_icon='reset')

        row3 = header.row(align=True)
        row3.prop(settings, "align_to_mode", text=iface_("Align To:"))

        if settings.align_to_mode == 'HIT':
            sub = header.row(align=True)
            sub.prop(settings, "normal_align")
            sub2 = header.row(align=True)
            sub2.enabled = settings.normal_align
            sub2.prop(settings, "normal_axis")
            sub2.prop(settings, "flip_normal")

            sub3 = header.row(align=True)
            sub3.enabled = settings.normal_align
            sub3.prop(settings, "twist_mode")

            sub4 = header.row(align=True)
            sub4.enabled = settings.normal_align and (settings.twist_mode != 'OFF')
            sub4.prop(settings, "twist_tangent_axis")
            if settings.twist_mode in {'AUTO', 'TARGET'}:
                sub4.prop(settings, "target_tangent_axis")

            sub5 = header.row(align=True)
            sub5.enabled = settings.normal_align and (settings.twist_mode != 'OFF')
            if settings.twist_mode in {'AUTO', 'VIEW'}:
                sub5.prop(settings, "view_tangent_axis")

        row4 = header.row(align=True)
        row4.prop(settings, "continuous_mode")
        row4.prop(settings, "respect_locks")

        try:
            total_count = len(_unique_quick_align_names(list(sources) + [settings.target_name]))
        except Exception:
            total_count = 0
        even_box = layout.box()
        even_row = even_box.row(align=True)
        even_row.enabled = (total_count >= 3 and settings.align_to_mode == 'OBJECT')
        even_row.prop(settings, "equal_align_enabled", text=iface_("Even Distribution"))
        far_row = even_box.row(align=True)
        far_row.enabled = bool(settings.equal_align_enabled) and (total_count >= 3 and settings.align_to_mode == 'OBJECT')
        far_row.prop(settings, "equal_align_use_farthest_pair", text=iface_("Use Farthest Pair"))
        
        box = layout.box()
        box.label(text=iface_("Align Position (World):"))
        row = box.row()
        row.prop(settings, "align_pos_x")
        row.prop(settings, "align_pos_y")
        row.prop(settings, "align_pos_z")

        box2 = layout.box()
        box2.label(text=iface_("Axis-specific Reference (Source / Target):"))

        # X
        r = box2.row(align=True)
        r.label(text=iface_("X Ref"))
        r.prop(settings, "source_align_x", text="")
        c = r.row(align=True)
        c.enabled = (settings.align_to_mode == 'OBJECT')
        c.prop(settings, "target_align_x", text="")

        # Y
        r = box2.row(align=True)
        r.label(text=iface_("Y Ref"))
        r.prop(settings, "source_align_y", text="")
        c = r.row(align=True)
        c.enabled = (settings.align_to_mode == 'OBJECT')
        c.prop(settings, "target_align_y", text="")

        # Z
        r = box2.row(align=True)
        r.label(text=iface_("Z Ref"))
        r.prop(settings, "source_align_z", text="")
        c = r.row(align=True)
        c.enabled = (settings.align_to_mode == 'OBJECT')
        c.prop(settings, "target_align_z", text="")
        
        box = layout.box()
        box.label(text=iface_("Align Orientation (Local):"))
        row = box.row()
        row.enabled = not (settings.align_to_mode == 'HIT' and settings.normal_align and (settings.twist_mode != 'OFF'))
        row.prop(settings, "align_ori_x")
        row.prop(settings, "align_ori_y")
        row.prop(settings, "align_ori_z")
        
        box = layout.box()
        box.label(text=iface_("Match Scale:"))
        row = box.row()
        row.prop(settings, "align_scale_x")
        row.prop(settings, "align_scale_y")
        row.prop(settings, "align_scale_z")

    def execute(self, context):
        settings = _wm_quick_align_settings(context)
        if settings is None:
            return {'CANCELLED'}

        op_has_args = bool(
            str(getattr(self, 'target_name', '') or '').strip() or
            str(getattr(self, 'source_names_json', '') or '').strip()
        )
        dialog_prepared = bool(getattr(self, '_quick_align_dialog_prepared', False))
        selection_differs_from_session = False
        if dialog_prepared and not op_has_args:
            try:
                inferred_target, inferred_sources = _infer_dialog_selection(context, settings=settings)
                session_target = str(getattr(settings, 'target_name', '') or '').strip()
                session_sources = json.loads(getattr(settings, 'source_names_json', '') or '[]')
                if inferred_target and inferred_sources:
                    selection_differs_from_session = (
                        inferred_target != session_target or
                        set(inferred_sources) != set(session_sources)
                    )
            except Exception:
                selection_differs_from_session = False

        op_args_match_session = _quick_align_operator_args_match_session(self, settings) if op_has_args else False
        needs_prepare = (
            (not dialog_prepared) or
            (op_has_args and not op_args_match_session) or
            (not _quick_align_session_ready(settings)) or
            selection_differs_from_session
        )
        if needs_prepare:
            prepared, _inferred_from_selection = _prepare_quick_align_session(context, self, settings)
            if not prepared:
                self.report({'WARNING'}, iface_("Select at least two objects before starting Quick Align."))
                return {'CANCELLED'}
        else:
            try:
                settings.last_preview_time = 0.0
                settings.pending_update = False
                settings.timer_active = False
            except Exception:
                pass
            force_update_align_preview(settings, context)

        _save_settings_to_prefs(settings)

        # Continue picking targets if enabled and a live UI context can host a modal operator.
        if settings.continuous_mode and _can_invoke_quick_align_modal(context):
            try:
                bpy.ops.object.quick_align_tool('INVOKE_DEFAULT', source_names_json=settings.source_names_json)
            except Exception:
                pass
        try:
            self._quick_align_dialog_prepared = False
        except Exception:
            pass
        return {'FINISHED'}

    def cancel(self, context):
        settings = _wm_quick_align_settings(context)
        if settings is None:
            return
        if settings.initial_states_json:
            initial_states = json.loads(settings.initial_states_json)
            for name, init_data in initial_states.items():
                obj = bpy.data.objects.get(name)
                if obj:
                    try:
                        mw_list = init_data.get('matrix_world')
                        if mw_list:
                            obj.matrix_world = Matrix(mw_list)
                    except Exception:
                        pass
                    try:
                        obj.location = init_data.get('location', obj.location)
                        obj.scale = init_data.get('scale', obj.scale)
                        if obj.rotation_mode == 'QUATERNION' and 'rotation_quaternion' in init_data:
                            obj.rotation_quaternion = init_data['rotation_quaternion']
                        elif obj.rotation_mode == 'AXIS_ANGLE' and 'rotation_axis_angle' in init_data:
                            obj.rotation_axis_angle = init_data['rotation_axis_angle']
                        else:
                            obj.rotation_euler = init_data.get('rotation_euler', obj.rotation_euler)
                    except Exception:
                        pass
        
        context.view_layer.update()
        _safe_area_redraw(context)

class OBJECT_OT_quick_align_tool(bpy.types.Operator):
    """Quick Align Tool"""
    bl_idname = "object.quick_align_tool"
    bl_label = "Quick Align Tool"
    bl_description = "Pick a target object in the viewport, then open the Quick Align dialog to align the selected source objects"
    bl_options = {'UNDO'} # 念のためこちらもREGISTERを外します
    bl_undo_group = 'Smart Transform Suite'

    # Optional: explicit source list (for continuous mode)
    source_names_json: StringProperty(name="Source Object Names", description="Internal JSON list of source object names used by the Quick Align operator.", default="", options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def invoke(self, context, event):
        # New Quick Align workflow: start from the current multi-selection and
        # open the popup immediately.  The dialog decides whether the first or
        # last selected object is the target.
        try:
            selected_names = _quick_align_ordered_selected_names(context)
        except Exception:
            selected_names = []
        if len(selected_names) < 2:
            self.report({'WARNING'}, iface_("Select at least two objects before starting Quick Align."))
            return {'CANCELLED'}
        try:
            _update_quick_align_selection_order(context)
        except Exception:
            pass
        # Continuous mode re-invokes with the source list: the cursor already moved.
        if not self.source_names_json:
            _warp_cursor_aside(context, event)
        try:
            return bpy.ops.object.quick_align_popup('INVOKE_DEFAULT')
        except Exception:
            self.report({'WARNING'}, iface_("Select at least two objects before starting Quick Align."))
            return {'CANCELLED'}

    def execute(self, context):
        try:
            return bpy.ops.object.quick_align_popup('EXEC_DEFAULT', source_names_json=self.source_names_json)
        except Exception:
            self.report({'WARNING'}, iface_("Select at least two objects before starting Quick Align."))
            return {'CANCELLED'}

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            context.workspace.status_text_set(None)
            context.window.cursor_modal_restore()
            self.report({'INFO'}, iface_("Quick Align canceled."))
            return {'CANCELLED'}
        
        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                try:
                    self._ignore_release_until_press = False
                except Exception:
                    pass
                # Store the object under the initial click.  Some Blender modal
                # contexts can report a release coordinate or depsgraph state
                # that misses the object, which incorrectly turns the pick into
                # a background click.
                self._press_pick = _pick_quick_align_target(context, event)
                return {'RUNNING_MODAL'}
                
            elif event.value == 'RELEASE':
                if bool(getattr(self, '_ignore_release_until_press', False)) and getattr(self, '_press_pick', None) is None:
                    self._ignore_release_until_press = False
                    return {'RUNNING_MODAL'}
                pick = _pick_quick_align_target(context, event) or getattr(self, '_press_pick', None)
                self._press_pick = None

                if pick is not None:
                    obj, loc, normal, rv3d = pick
                    obj = _to_original_object(obj)
                    if obj is None:
                        return {'RUNNING_MODAL'}
                    source_names = [name for name in self.initial_selection if name != obj.name]
                    if not source_names:
                        self.report({'WARNING'}, iface_("Invalid target. Please click a different object."))
                        return {'RUNNING_MODAL'} 

                    context.workspace.status_text_set(None)
                    context.window.cursor_modal_restore()
                    
                    prefs = _prefs()
                    try:
                        if prefs and prefs.warp_cursor_after_pick:
                            off = int(getattr(prefs, "warp_offset_px", 200))
                            context.window.cursor_warp(event.mouse_x + off, event.mouse_y)
                    except Exception:
                        pass

                    view_up, view_right = _view_orientation_vectors(rv3d)

                    bpy.ops.object.quick_align_popup('INVOKE_DEFAULT', 
                        target_name=obj.name, 
                        source_names_json=json.dumps(source_names),
                        hit_location_json=json.dumps([loc.x, loc.y, loc.z]),
                        hit_normal_json=json.dumps([normal.x, normal.y, normal.z]),
                        view_up_json=json.dumps([view_up.x, view_up.y, view_up.z]),
                        view_right_json=json.dumps([view_right.x, view_right.y, view_right.z]),
                    )
                    return {'FINISHED'}

                context.workspace.status_text_set(None)
                context.window.cursor_modal_restore()
                self.report({'INFO'}, iface_("Canceled due to background click."))
                return {'CANCELLED'}
            
        return {'PASS_THROUGH'}

def menu_func(self, context):
    _operator(self.layout, OBJECT_OT_quick_align_tool.bl_idname, text=iface_("Quick Align Tool"), icon='CON_TRANSLIKE', custom_icon='quick_align')


_TRANSIENT_QUICK_ALIGN_PROPS = (
    'target_name', 'source_names_json', 'selected_names_json', 'initial_states_json',
    'hit_location_json', 'hit_normal_json', 'view_up_json', 'view_right_json',
)


def _clear_quick_align_transient_state(context=None) -> None:
    try:
        settings = _wm_quick_align_settings(context or getattr(bpy, 'context', None))
    except Exception:
        settings = None
    if settings is None:
        return
    for prop_name in _TRANSIENT_QUICK_ALIGN_PROPS:
        try:
            if hasattr(settings, prop_name):
                setattr(settings, prop_name, '')
        except Exception:
            pass
    for prop_name in ('pending_update', 'timer_active', 'is_updating'):
        try:
            if hasattr(settings, prop_name):
                setattr(settings, prop_name, False)
        except Exception:
            pass


@persistent
def _quick_align_on_load_post(_dummy=None):
    global _QUICK_ALIGN_LAST_SELECTION_SIGNATURE
    _QUICK_ALIGN_LAST_SELECTION_SIGNATURE = None
    try:
        _SCENE_RUNTIME_QUICK_ALIGN_SETTINGS.clear()
    except Exception:
        pass
    try:
        _QUICK_ALIGN_SELECTION_ORDER.clear()
    except Exception:
        pass
    _clear_quick_align_transient_state(getattr(bpy, 'context', None))

classes = (
    QuickAlignSettings,
    OBJECT_OT_quick_align_swap_refs,
    OBJECT_OT_quick_align_reset_dialog,
    OBJECT_OT_quick_align_popup,
    OBJECT_OT_quick_align_tool,
)

def register():
    try:
        bpy.app.translations.register(__name__, translations)
    except Exception:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        try:
            bpy.app.translations.register(__name__, translations)
        except Exception:
            pass
    from .. import settings as _settings
    _settings.materialize_persisted_property_updates(
        (QuickAlignSettings,), owner_scope='window_manager'
    )
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.WindowManager.quick_align_settings = bpy.props.PointerProperty(
        type=QuickAlignSettings,
        name=iface_('Quick Align Runtime Settings'),
        description=iface_('Persistent Quick Align N-panel settings stored on the WindowManager and saved to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json.'),
    )
    bpy.types.VIEW3D_MT_object.append(menu_func)
    try:
        _load_hooks.add(_quick_align_on_load_post)
    except Exception:
        pass
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        if _quick_align_selection_order_on_depsgraph not in handlers:
            handlers.append(_quick_align_selection_order_on_depsgraph)
        _install_quick_align_selection_msgbus()
        _quick_align_selection_order_on_depsgraph()
    except Exception:
        pass

def unregister():
    try:
        if bpy.app.timers.is_registered(_timer_preview_update):
            bpy.app.timers.unregister(_timer_preview_update)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_quick_align_selection_order_timer):
            bpy.app.timers.unregister(_quick_align_selection_order_timer)
    except Exception:
        pass
    try:
        _remove_quick_align_selection_msgbus()
    except Exception:
        pass
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        if _quick_align_selection_order_on_depsgraph in handlers:
            handlers.remove(_quick_align_selection_order_on_depsgraph)
    except Exception:
        pass

    try:
        bpy.types.VIEW3D_MT_object.remove(menu_func)
    except Exception:
        pass
    try:
        _load_hooks.remove(_quick_align_on_load_post)
    except Exception:
        pass

    for reversed_cls in reversed(classes[1:]):
        _safe_unregister_class(reversed_cls)

    if hasattr(bpy.types.WindowManager, "quick_align_settings"):
        try:
            del bpy.types.WindowManager.quick_align_settings
        except Exception:
            pass

    _safe_unregister_class(QuickAlignSettings)

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

if __name__ == "__main__":
    register()

# -----------------------------------------------------------------------------
# Toolset integration helpers
# -----------------------------------------------------------------------------
__STS_REGISTERED = False

def ensure_registered(enable: bool = True):
    global __STS_REGISTERED
    if enable and not __STS_REGISTERED:
        try:
            register()
            __STS_REGISTERED = True
        except Exception:
            __STS_REGISTERED = False
            raise
    elif (not enable) and __STS_REGISTERED:
        try:
            unregister()
        finally:
            __STS_REGISTERED = False
