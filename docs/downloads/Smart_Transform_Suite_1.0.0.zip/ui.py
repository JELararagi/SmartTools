from pathlib import Path
import sys
import bpy
import bpy.utils.previews
from . import interaction,schema

TOPICS=[
    ("show_always_on_switches","Live Settings","常時機能切り替え",("npanel_state_save_enabled","enable_smart_gizmo_live_runtime","enable_cursor_lock_feature","enable_precision_length_drag","enable_mesh_island_transform")),
    ("show_core_panel_settings","Transform","トランスフォーム",()),
    ("show_section_target_tools","Enabled Tools","有効にするツール",("enable_move","enable_rotate","enable_scale","enable_transform")),
    ("show_section_selection_behavior","Selection Behavior","選択の挙動設定",("use_immediate_select","keep_multi_selection","update_active_element","enable_click_through","enable_back_element_click_select","crossing_select_edges","crossing_select_faces")),
    ("show_section_transform_behavior","Transform Behavior","変形の挙動設定",("enable_drag_transform","enable_axis_memory","smart_gizmo_use_circular_rotation","smart_gizmo_use_distance_scale","tool_disallow_negative_scale")),
    ("show_section_background_interaction","Background Controls","背景操作の設定",("enable_bg_deselect","enable_bg_drag_select")),
    ("show_section_sensitivity","Sensitivity","感度・判定範囲",("drag_threshold","vert_hit_radius","edge_hit_radius","gizmo_pick_range_px")),
    ("show_section_smart_gizmo","3D Smart Gizmo","3Dスマートギズモ",("enable_smart_gizmo_live_runtime","gizmo_toggle_state","enable_smart_gizmo_style","smart_gizmo_screen_scale","smart_axis_scale","smart_plane_scale","smart_center_scale","color_x","color_y","color_z","color_free","color_highlight")),
    ("show_section_smart_grs","Smart G-R-S","Smart G-R-S 変形",("g_normal","g_shift","r_normal","r_shift","s_normal","s_shift","snap_move_grid_step","snap_rotate_step_deg","snap_scale_step","disallow_negative_scale")),
    ("show_section_proportional","Proportional Editing","プロポーショナル編集",("object_prop_basis","prop_falloff_profile","show_orange_circle","circle_color","circle_line_width","enable_prop_cursor_lock")),
    ("show_section_hud_numeric","HUD and Numeric Input","HUD・数値入力",("hud_enabled","hud_anchor_mode","hud_offset_x","hud_offset_y","hud_font_size","hud_text_color","hud_show_help_by_default")),
    ("show_section_overlay_aa","Overlay Lines","線の描画",("overlay_aa_mode","draw_axis_lines_in_front","axis_line_width","axis_line_width_active","axis_color_x","axis_color_y","axis_color_z")),
    ("show_section_integrated_tools","Integrated Tools","その他ツール",("affect_only_all_object_types",)),
    ("show_cursor_lock_settings","3D Cursor Lock","3Dカーソルロック",("enable_cursor_lock_feature",)),
    ("show_precision_length_drag_settings","Precision Numeric Drag","精密数値ドラッグ",("enable_precision_length_drag","precision_number_drag_step_length","precision_number_drag_step_angle","precision_number_drag_step_number")),
    ("show_cycle_custom_select_settings","Cycle Selection Tools","カスタム選択切替",("custom_select_mode","custom_select_enable_tweak","custom_select_enable_box","custom_select_enable_circle","custom_select_enable_lasso")),
    ("show_quick_align_settings","Quick Align","クイック整列",("enable_quick_align",)),
    ("show_quick_multi_edit_settings","Quick Multi Edit","クイック複数編集",("enable_quick_multi_edit",)),
    ("show_mesh_island_transform_settings","Mesh Island Transform","アイランド変形",("enable_mesh_island_transform","mesh_island_transform_individual_pivot_only")),
    ("show_normal_aligner_settings","Align to Vertex Normals","頂点法線アライナー",("normal_align_use_pivot","normal_align_use_orientation")),
    ("show_select_guard_settings","Selection Guard","スマート選択ガード",("enable_select_guard",)),
    ("show_section_additional_entry_points","Transform Popup","トランスフォームポップアップ",()),
]
SUB_ACTIONS={
    8:[("view3d.csdt_toggle_smart_gizmo","Toggle Gizmo"),("view3d.csdt_reset_settings","Reset Gizmo")],
    9:[("transform.smart_grs_translate","Move"),("transform.smart_grs_rotate","Rotate"),("transform.smart_grs_resize","Scale")],
    10:[("view3d.proportional_size_cursor","Adjust Radius")],14:[("view3d.sts_toggle_cursor_lock","Lock / Unlock Cursor")],
    15:[("wm.smart_transform_precision_numeric_drag","Drag Numeric Field")],
    16:[("view3d.cycle_custom_select","Next Selection Tool")],
    17:[("object.quick_align_tool","Align Selected Objects")],
    19:[("mesh.smart_island_move","Move Islands"),("mesh.smart_island_rotate","Rotate Islands"),("mesh.smart_island_scale","Scale Islands")],
    20:[("mesh.smart_align_to_vertex_normal","Align to Selected Normals")],21:[("view3d.select_guard_toggle","Selection Guard"),("view3d.ssg_toggle_occluder_ignore_selected","Ignore Selected Occluders")],
    22:[("wm.core","Open Transform Popup")],
}
JA={"Smart Transform":"Smart Transform","Enabled":"有効","Location":"位置","Rotation":"回転","Scale":"スケール","Dimensions":"寸法",
    "Copy":"コピー","Paste":"ペースト","Apply Rotation and Scale":"回転とスケールを適用","Apply All":"全変形を適用",
    "To Cursor":"カーソルへ","Cursor to Selection":"選択→カーソル","To Active":"アクティブへ","To Floor":"床へ",
    "Align Selected Objects":"選択オブジェクトを整列","Open Transform Popup":"ポップアップを開く","Lock / Unlock Cursor":"カーソルの固定・解除",
    "Open Manual":"解説書を開く","Add":"追加","Remove":"除外","Toggle":"切替","Isolate":"単独","Restore Previous":"前回の組を復元",
    "Fit Dimensions":"寸法を合わせる","Target":"ターゲット","Sources":"整列する物","Position":"位置","Orientation":"方向","Source Reference":"元の基準点","Target Reference":"先の基準点",
    "Move":"移動","Rotate":"回転","Move Islands":"島を移動","Rotate Islands":"島を回転","Scale Islands":"島を拡縮",
    "Ignore Selected Occluders":"選択物を遮蔽物から除外","Align to Selected Normals":"選択頂点の法線に合わせる","Drag Numeric Field":"数値をドラッグ",
    "Toggle Gizmo":"ギズモを切替","Reset Gizmo":"ギズモを初期化","Adjust Radius":"半径を調整","Next Selection Tool":"次の選択ツール"}
JA.update({"Selection Median":"選択の中点","World Coordinates":"ワールド座標","Vertex Bevel":"頂点ベベル","Vertex Crease":"頂点クリース","Edge Bevel":"辺ベベル","Edge Crease":"辺クリース","Skin Radius X":"スキン半径 X","Skin Radius Y":"スキン半径 Y","Quick Align Popup":"クイック整列","Respect Locks":"ロックを尊重","Equal Align Enabled":"等間隔で整列","Target Endpoint Mode":"基準の端点","Continuous Mode":"連続モード","Align To Mode":"整列先","Normal Align":"法線に整列","Flip Normal":"法線を反転","Normal Axis":"法線の軸","Each":"個別","Absolute":"絶対値","Median":"中点","Delta":"差分","Last":"最後","First":"最初","Pivot":"原点","Center":"中心","Min":"最小","Max":"最大","Target":"ターゲット","Orientation":"座標系","Align to Selected Normals":"選択頂点の法線に合わせる"})
JA.update({'Quick Align Swap Refs': '基準点を入れ替え', 'Quick Align Reset Dialog': 'ダイアログを初期化', 'Enable Quick Align': 'クイック整列を有効化', 'Enable Quick Multi Edit': 'クイック複数編集を有効化', 'Enable Move': '移動', 'Enable Rotate': '回転', 'Enable Scale': '拡縮', 'Enable Transform': '複合変形', 'Npanel State Save Enabled': 'サイドバー設定を保存', 'Enable Smart Gizmo Live Runtime': 'スマートギズモを有効化', 'Enable Cursor Lock Feature': 'カーソルロックを有効化', 'Enable Precision Length Drag': '精密数値ドラッグを有効化', 'Enable Mesh Island Transform': 'アイランド変形を有効化', 'Use Immediate Select': '押した時に選択', 'Keep Multi Selection': '複数選択を維持', 'Update Active Element': 'アクティブ要素を更新', 'Enable Click Through': '選択不可の物を貫通', 'Enable Back Element Click Select': '重なる要素を順に選択', 'Crossing Select Edges': '交差した辺を選択', 'Crossing Select Faces': '交差した面を選択', 'Enable Drag Transform': 'ドラッグで変形を開始', 'Enable Axis Memory': '直前の軸を記憶', 'Smart Gizmo Use Circular Rotation': '円を描いて回転', 'Smart Gizmo Use Distance Scale': '中心からの距離で拡縮', 'Tool Disallow Negative Scale': '負のスケールを制限', 'Enable Bg Deselect': '背景クリックで選択解除', 'Enable Bg Drag Select': '背景ドラッグで範囲選択', 'Drag Threshold': 'ドラッグのしきい値', 'Vert Hit Radius': '頂点の判定半径', 'Edge Hit Radius': '辺の判定半径', 'Gizmo Pick Range Px': 'ギズモの判定幅', 'Gizmo Toggle State': 'ギズモを表示', 'Enable Smart Gizmo Style': '独自ハンドルを表示', 'Smart Gizmo Screen Scale': '画面上の大きさ', 'Smart Axis Scale': '軸の大きさ', 'Smart Plane Scale': '平面の大きさ', 'Smart Center Scale': '中央の大きさ', 'Color X': 'X軸の色', 'Color Y': 'Y軸の色', 'Color Z': 'Z軸の色', 'Color Free': '中央の色', 'Color Highlight': '強調色', 'G Normal': '移動の感度', 'G Shift': '精密移動の感度', 'R Normal': '回転の感度', 'R Shift': '精密回転の感度', 'S Normal': '拡縮の感度', 'S Shift': '精密拡縮の感度', 'Snap Move Grid Step': '移動の刻み', 'Snap Rotate Step Deg': '回転の刻み（度）', 'Snap Scale Step': '拡縮の刻み', 'Disallow Negative Scale': '負のスケールを制限', 'Object Prop Basis': 'オブジェクトの距離基準', 'Prop Falloff Profile': '影響の減衰', 'Show Orange Circle': '影響円を表示', 'Circle Color': '円の色', 'Circle Line Width': '円の線幅', 'Enable Prop Cursor Lock': '影響範囲の調整中にカーソルを固定', 'Hud Enabled': '画面に数値を表示', 'Hud Anchor Mode': '文字の基準位置', 'Hud Offset X': '横方向の位置', 'Hud Offset Y': '縦方向の位置', 'Hud Font Size': '文字サイズ', 'Hud Text Color': '文字色', 'Hud Show Help By Default': '操作ヒントを表示', 'Overlay Aa Mode': '線の滑らかさ', 'Axis Line Width': '軸の線幅', 'Axis Line Width Active': '操作軸の線幅', 'Axis Color X': 'X軸の色', 'Axis Color Y': 'Y軸の色', 'Axis Color Z': 'Z軸の色', 'Affect Only All Object Types': '全種類のオブジェクトに適用', 'Precision Number Drag Step Length': '長さの刻み', 'Precision Number Drag Step Angle': '角度の刻み', 'Precision Number Drag Step Number': '数値の刻み', 'Custom Select Mode': '選択方法', 'Custom Select Enable Tweak': 'クリック選択', 'Custom Select Enable Box': 'ボックス選択', 'Custom Select Enable Circle': 'サークル選択', 'Custom Select Enable Lasso': '投げ縄選択', 'Mesh Island Transform Individual Pivot Only': '個別の原点でのみ使用', 'Normal Align Use Pivot': '原点を合わせる', 'Normal Align Use Orientation': '座標系を作る', 'Enable Select Guard': '選択ガードを有効化', 'Selection Guard': '選択ガード', 'Set': '置き換え', 'Box': 'ボックス', 'Lasso': '投げ縄', 'Collection': 'コレクション', 'Each': '個別', 'Absolute': '絶対値', 'Global': 'ワールド', 'Object': 'オブジェクト', 'Copy Text': 'IDをコピー'})
JA.update({en:ja for _,en,ja,_ in TOPICS})
_icons=None

def register_icons():
    global _icons
    _icons=bpy.utils.previews.new()
    for path in (Path(__file__).parent/"icon/resources").glob("*.png"):_icons.load(path.stem,str(path),"IMAGE")

def unregister_icons():
    global _icons
    if _icons is not None:bpy.utils.previews.remove(_icons);_icons=None

def label(en):return JA.get(en,en) if bpy.app.translations.locale.startswith("ja") else en

def question(row,topic):
    row.operator("smart_transform_suite.open_help",text="",icon="QUESTION",emboss=False).topic=topic

def show_help(ctx,topic):
    topics={"overview":"s1","integrated_tools":"f13","quick_multi_edit":"f18","quick_align":"f17",
            "cursor_lock":"f14","smart_gizmo":"f8","select_guard":"f21","transform":"f2"}
    anchor=topic if topic in {"f"+str(i) for i in range(1,23)} else topics.get(topic,"s1")
    lang=bpy.app.translations.locale.startswith("ja")
    name=TOPICS[int(anchor[1:])-1][2 if lang else 1] if anchor.startswith("f") else "Smart Transform"
    def draw(menu,context):
        row=menu.layout
        row.label(text=name)
        url=row.operator("wm.url_open",text=label("Open Manual"),icon="URL")
        url.url="https://jelararagi.github.io/SmartTools/"+("" if lang else "en/")+"manuals/SmartTransform/#"+anchor
    ctx.window_manager.popup_menu(draw,title=name,icon="QUESTION")

def manager_allowed(ctx):
    for row in ctx.preferences.addons:
        if row.module.rsplit(".",1)[-1]=="smart_tools_manager":
            m=sys.modules.get(row.module+".manager")
            if m:return bool(m.panel_rule_allows_context("SMART_TRANSFORM",ctx,m.logical_editor_key_from_context(ctx)))
    return ctx.area and ctx.area.type=="VIEW_3D"

def draw_align(ui,s):
    ui.prop(s,"preset");ui.prop(s,"target_endpoint_mode")
    for prefix,title in (("align_pos","Position"),("align_ori","Orientation"),("align_scale","Scale")):
        row=ui.row(align=True);row.label(text=label(title))
        for a in "xyz":row.prop(s,prefix+"_"+a,text=a.upper(),toggle=True)
    for key,name in (("source_align","Source Reference"),("target_align","Target Reference")):
        ui.label(text=label(name));row=ui.row(align=True)
        for axis in "xyz":row.prop(s,key+"_"+axis,text="")
    row=ui.row(align=True);row.operator("object.quick_align_swap_refs");row.operator("object.quick_align_reset_dialog")
    for key in ("align_to_mode","equal_align_enabled","respect_locks","continuous_mode"):ui.prop(s,key)
    if s.align_to_mode=="HIT":
        ui.prop(s,"normal_align");ui.prop(s,"normal_axis");ui.prop(s,"flip_normal")

def transform_fields(ui,ctx):
    g=ctx.scene.core_props
    if ctx.active_object:ui.label(text=ctx.active_object.name,icon="OBJECT_DATA")
    if ctx.mode=="EDIT_MESH" and ctx.active_object:
        mesh=ctx.active_object.data
        for key,en in (("global_space","World Coordinates"),("median_location","Selection Median"),("bevel_vertex","Vertex Bevel"),("crease_vertex","Vertex Crease"),("bevel_edge","Edge Bevel"),("crease_edge","Edge Crease"),("skin_x","Skin Radius X"),("skin_y","Skin Radius Y")):
            ui.prop(mesh,"sts_popup_edit_"+key,text=label(en))
        return
    row=ui.row(align=True);row.prop(g,"op_mode",text="");row.prop(g,"input_mode",text="")
    ui.prop(g,"popup_orient",text=label("Orientation"))
    for kind,title in (("loc","Location"),("rot","Rotation"),("scale","Scale"),("dim","Dimensions")):
        box=ui.column(align=True);box.label(text=label(title))
        for axis in "xyz":
            row=box.row(align=True);row.prop(g,kind+"_"+axis,text=axis.upper())
            row.operator("core.reset_value",text="",icon="X").prop_name=kind+"_"+axis
    row=ui.row(align=True);row.operator("core.copy",text=label("Copy"));row.operator("core.paste",text=label("Paste"))
    row=ui.row(align=True)
    for k,n in (("location","Location"),("rotation","Rotation"),("scale","Scale")):row.prop(g,"paste_"+k,text=label(n),toggle=True)
    row=ui.row(align=True);row.operator("core.apply_rs",text=label("Apply Rotation and Scale"));row.operator("core.apply_all",text=label("Apply All"))
    for pairs in ((("core.snap_to_cursor_button","To Cursor"),("core.cursor_to_selection_button","Cursor to Selection")),
                  (("core.snap_to_active_button","To Active"),("core.snap_to_floor_button","To Floor"))):
        row=ui.row(align=True)
        for k,n in pairs:row.operator(k,text=label(n))

def multi(ui,ctx):
    for name,actions in (("",("add","remove","toggle","isolate")),("box_",("add","remove","toggle")),("lasso_",("add","remove","toggle")),("collection_",("set","add","remove","toggle"))):
        row=ui.row(align=True)
        if name:ui.label(text=name.rstrip("_").title())
        for key in actions:
            image=_icons.get(name+key) if _icons else None
            row.operator("view3d.quick_multi_edit_"+name+key,text=label(key.title()),icon_value=image.icon_id if image else 0)
    ui.operator("view3d.quick_multi_edit_restore_previous",text=label("Restore Previous"))

class SMART_TRANSFORM_PT_core_suite(bpy.types.Panel):
    bl_idname="SMART_TRANSFORM_PT_core_suite"
    bl_label="Smart Transform"
    bl_space_type="VIEW_3D";bl_region_type="UI";bl_category="Smart Transform"
    @classmethod
    def poll(cls,ctx):return manager_allowed(ctx)
    def draw_header_preset(self,ctx):question(self.layout,"overview")
    def draw(self,ctx):
        p=interaction.prefs(ctx);ui=self.layout
        for i,(key,title,ja,fields) in enumerate(TOPICS,1):
            row=ui.row(align=True);visible=getattr(p,key)
            row.prop(p,key,text=label(title),icon="TRIA_DOWN" if visible else "TRIA_RIGHT",emboss=False)
            question(row,"f"+str(i))
            if not visible:continue
            body=ui.column(align=True)
            for f in fields:body.prop(p,f)
            if i==2:transform_fields(body,ctx)
            if i==18:multi(body,ctx)
            for name,title in SUB_ACTIONS.get(i,[]):body.operator(name,text=label(title))

class VIEW3D_PT_select_guard_popover(bpy.types.Panel):
    bl_idname="VIEW3D_PT_select_guard_popover"
    bl_label="Selection Guard"
    bl_space_type="VIEW_3D";bl_region_type="HEADER"
    def draw_header_preset(self,ctx):question(self.layout,"f21")
    def draw(self,ctx):
        ui=self.layout;ui.prop(ctx.scene,"select_guard_enabled")
        for key in schema.API["roots"]["Scene"]:
            if key.startswith("ssg_") and key!="ssg_scene_initialized":ui.prop(ctx.scene,key)

class VIEW3D_PT_sts_transform_popup(bpy.types.Panel):
    bl_idname="VIEW3D_PT_sts_transform_popup"
    bl_label="Transform"
    bl_space_type="VIEW_3D";bl_region_type="HEADER"
    def draw_header_preset(self,ctx):question(self.layout,"f22")
    def draw(self,ctx):transform_fields(self.layout,ctx)

def header(self,ctx):
    if not manager_allowed(ctx):return
    p=interaction.prefs(ctx);row=self.layout.row(align=True)
    if p.enable_select_guard:row.popover(panel="VIEW3D_PT_select_guard_popover",text="",icon="RESTRICT_SELECT_OFF")
    if p.enable_cursor_lock_feature:row.operator("view3d.sts_toggle_cursor_lock",text="",icon="LOCKED" if ctx.scene.cursor_lock_props.enabled else "UNLOCKED")

def numeric_menu(self,ctx):
    prop=getattr(ctx,"button_prop",None)
    if prop and prop.type in {"FLOAT","INT"} and not prop.is_array and not prop.is_readonly and interaction.prefs(ctx).enable_precision_length_drag:
        self.layout.operator("wm.smart_transform_precision_numeric_drag",text=label("Drag Numeric Field"))

def object_menu(self,ctx):self.layout.operator("object.quick_align_tool",text=label("Align Selected Objects"))
def collection_menu(self,ctx):
    for action in ("set","add","remove"):self.layout.operator("outliner.quick_multi_edit_collection_"+action)
