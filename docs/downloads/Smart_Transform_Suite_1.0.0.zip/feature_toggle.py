# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
import re
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, Callable

import bpy

from .keymap_safety import is_blender_shutdown_context, keymap_item_is_live, safe_set_keymap_item_active
from . import ui_icons as _ui_icons
from . import operator_safety as _op_safety

_SUITE_KEY = ''
_SUITE_LABEL = ''
_CATEGORY = ''
_OPERATOR_ID = ''
_REGISTERED_CLASSES: list[type] = []
_REDRAW_PENDING = False
_FEATURES: dict[str, dict[str, dict[str, Any]]] = {}
_STATE_CACHE: dict[str, dict[str, bool]] | None = None
_CAPTURE_STACK: list['_RuntimeCapture'] = []
_PATCH_DEPTH = 0
_ORIGINALS: dict[str, Any] = {}
_ORIGINAL_DRAW_ADDS: dict[str, Any] = {}
_ORIGINAL_DRAW_REMOVES: dict[str, Any] = {}
_DUMMY_COUNTER = 0
_PROXY_COLLECTION_ATTR = 'smart_transform_suite_persistent_feature_switches'
_LEGACY_PROXY_COLLECTION_ATTRS = ('core_suite_persistent_feature_switches',)
_PREF_MIRROR_PROP = 'persistent_feature_toggles_json'
_CLASS_LEDGER_KEY = 'JELARARAGI_SMART_TRANSFORM_FEATURE_TOGGLE_CLASSES_V1'


def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}
_SYNCING_PROXY_STATE = False


def _early_is_ja() -> bool:
    try:
        view = getattr(getattr(getattr(bpy, 'context', None), 'preferences', None), 'view', None)
        lang = str(getattr(view, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _early_static_t(en: str, ja: str) -> str:
    return str(ja if _early_is_ja() else en)


def _runtime_proxy_enabled_update(self, context):
    if _SYNCING_PROXY_STATE:
        return
    alias = str(getattr(self, 'alias', '') or '').strip()
    feature_key = str(getattr(self, 'feature_key', '') or '').strip()
    if not alias or not feature_key:
        return
    try:
        set_feature_enabled(alias, feature_key, bool(getattr(self, 'enabled', False)))
    except Exception:
        pass


class STS_PG_persistent_feature_switch(bpy.types.PropertyGroup):
    alias: bpy.props.StringProperty(
        name=_early_static_t('Feature Group', '機能グループ'),
        description=_early_static_t('Internal group identifier for the always-on feature switch. It links the visible N-panel button to the stored feature state.', '常時起動機能スイッチの内部グループ識別子です。表示中のNパネルボタンと保存済み機能状態を紐づけます。'),
        default='',
        options={'SKIP_SAVE'},
    )
    feature_key: bpy.props.StringProperty(
        name=_early_static_t('Feature Key', '機能キー'),
        description=_early_static_t('Internal feature identifier used to load, save, and restore this always-on toggle.', 'この常時機能切り替えを読み込み・保存・復元するための内部機能識別子です。'),
        default='',
        options={'SKIP_SAVE'},
    )
    enabled: bpy.props.BoolProperty(
        name=_early_static_t('Enabled', '有効'),
        description=_early_static_t(
            'Switch this always-on feature on or off. The setting is saved immediately, and the button stays pressed while it is on.',
            'この常時発動機能の有効 / 無効を切り替えます。設定はすぐに保存され、有効の間はボタンが押された表示になります。',
        ),
        default=False,
        update=_runtime_proxy_enabled_update,
        options={'SKIP_SAVE'},
    )


def _ensure_proxy_collection_property() -> None:
    try:
        if not hasattr(bpy.types.WindowManager, _PROXY_COLLECTION_ATTR):
            setattr(
                bpy.types.WindowManager,
                _PROXY_COLLECTION_ATTR,
                bpy.props.CollectionProperty(
                    type=STS_PG_persistent_feature_switch,
                    name=_early_static_t('Always-On Feature Switches', '常時起動機能スイッチ'),
                    description=_early_static_t('Internal WindowManager collection that mirrors N-panel always-on feature states so they can be saved, restored, and displayed as pressed buttons.', 'Nパネルの常時起動機能の状態を保存・復元し、押下状態のボタンとして表示するために複製保持する内部の一覧です。'),
                    options={'SKIP_SAVE'},
                ),
            )
    except Exception:
        pass


def _remove_legacy_proxy_collection_properties() -> None:
    for attr in _LEGACY_PROXY_COLLECTION_ATTRS:
        if attr == _PROXY_COLLECTION_ATTR:
            continue
        try:
            if hasattr(bpy.types.WindowManager, attr):
                delattr(bpy.types.WindowManager, attr)
        except Exception:
            pass


def _proxy_collection(context=None):
    try:
        wm = getattr(context, 'window_manager', None) if context is not None else getattr(getattr(bpy, 'context', None), 'window_manager', None)
        if wm is None:
            return None
        return getattr(wm, _PROXY_COLLECTION_ATTR, None)
    except Exception:
        return None


def _proxy_item(context, alias: str, feature_key: str, enabled: bool):
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return None
    coll = _proxy_collection(context)
    if coll is None:
        return None
    item = None
    try:
        for candidate in coll:
            if str(getattr(candidate, 'alias', '') or '') == alias and str(getattr(candidate, 'feature_key', '') or '') == feature_key:
                item = candidate
                break
        if item is None:
            item = coll.add()
        global _SYNCING_PROXY_STATE
        _SYNCING_PROXY_STATE = True
        try:
            if str(getattr(item, 'alias', '') or '') != alias:
                item.alias = alias
            if str(getattr(item, 'feature_key', '') or '') != feature_key:
                item.feature_key = feature_key
            if bool(getattr(item, 'enabled', False)) != bool(enabled):
                item.enabled = bool(enabled)
        finally:
            _SYNCING_PROXY_STATE = False
        return item
    except Exception:
        _SYNCING_PROXY_STATE = False
        return None


def _draw_feature_state_button(right, context, alias: str, feature_key: str, enabled: bool):
    enabled = bool(enabled)
    text = _t(context, 'Enabled' if enabled else 'Disabled', '有効' if enabled else '無効')
    icon = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
    try:
        right.operator_context = 'EXEC_DEFAULT'
    except Exception:
        pass
    proxy = _proxy_item(context, alias, feature_key, enabled)
    if proxy is not None:
        try:
            return right.prop(proxy, 'enabled', text=text, toggle=True, icon=icon, emboss=True)
        except TypeError:
            try:
                return right.prop(proxy, 'enabled', text=text, toggle=True, icon=icon)
            except Exception:
                pass
        except Exception:
            pass
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=_OPERATOR_ID, text=text, custom_icon='enabled' if enabled else 'disabled')
    try:
        op = right.operator(_OPERATOR_ID, text=text, emboss=True, depress=enabled, **icon_args)
    except TypeError:
        op = right.operator(_OPERATOR_ID, text=text, icon=icon, emboss=True, depress=enabled)
    _op_safety.safe_set_operator_property(op, 'alias', str(alias), operator_id=_OPERATOR_ID, strict=True)
    _op_safety.safe_set_operator_property(op, 'feature_key', str(feature_key), operator_id=_OPERATOR_ID, strict=True)
    return op

_KIND_ORDER = ('handlers', 'timers', 'msgbus', 'keymaps', 'draw_handlers')
_KIND_INFO = {
    'handlers': {
        'label_en': 'Application Handlers',
        'label_ja': 'アプリケーションハンドラー',
        'description_en': 'Enables handler functions that Blender runs automatically on file loading, saving, frame changes, dependency-graph updates, undo, redo, or rendering events. Use this only when this feature must react in the background. The setting is saved immediately to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and remains after Blender restarts and scene changes.',
        'description_ja': 'ファイル読込・保存、フレーム変更、依存グラフ更新、元に戻す / やり直し、レンダー関連イベントなどで Blender が自動実行するハンドラーを有効化します。この機能をバックグラウンドで自動反応させたい場合だけ有効にしてください。設定は即時保存され、Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'timers': {
        'label_en': 'Background Timers',
        'label_ja': 'バックグラウンドタイマー',
        'description_en': 'Enables timer callbacks that run after a delay or repeatedly without pressing a button. Use this only when this feature must keep checking or updating data automatically. The setting is saved immediately to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and remains after Blender restarts and scene changes.',
        'description_ja': 'ボタン操作なしで、一定時間後または一定間隔で実行されるタイマー処理を有効化します。この機能で自動チェックや自動更新が必要な場合だけ有効にしてください。設定は即時保存され、Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'msgbus': {
        'label_en': 'RNA Message Bus Watchers',
        'label_ja': 'データ変更の監視',
        'description_en': 'Enables msgbus subscriptions that watch Blender data and run callbacks automatically when watched properties change. Use this only when this feature must monitor Blender data in real time. The setting is saved immediately to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and remains after Blender restarts and scene changes.',
        'description_ja': 'Blender データの変更を監視し、監視対象プロパティが変わった時に自動でコールバックを実行する データ変更の監視を有効化します。この機能でリアルタイム監視が必要な場合だけ有効にしてください。設定は即時保存され、Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'keymaps': {
        'label_en': 'Hotkeys',
        'label_ja': 'ホットキー',
        'description_en': 'Enables keymap items and shortcuts for this feature. Use this when you want the feature to respond to keyboard or mouse shortcuts. The setting is saved immediately to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and remains after Blender restarts and scene changes.',
        'description_ja': 'この機能用のキーマップ項目・ショートカットを有効化します。キーボードやマウスのショートカットで機能を操作したい場合に有効にしてください。設定は即時保存され、Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
    'draw_handlers': {
        'label_en': 'Viewport / Editor Draw',
        'label_ja': 'ビューポート / エディター描画',
        'description_en': 'Enables draw handlers that keep drawing overlays or helper graphics in the viewport or editors. Use this only when this feature must show live guides or overlays automatically. The setting is saved immediately to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json and remains after Blender restarts and scene changes.',
        'description_ja': 'ビューポートや各エディターにオーバーレイ・補助表示を描き続ける描画ハンドラーを有効化します。この機能のライブガイドやオーバーレイ表示が必要な場合だけ有効にしてください。設定は即時保存され、Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ保存され、Blender 再起動後やシーン切り替え後も維持されます。',
    },
}

_SPACE_CLASS_NAMES = (
    'SpaceView3D', 'SpaceImageEditor', 'SpaceNodeEditor', 'SpaceSequenceEditor',
    'SpaceClipEditor', 'SpaceDopeSheetEditor', 'SpaceGraphEditor', 'SpaceNLA',
    'SpaceTextEditor', 'SpaceConsole', 'SpaceInfo',
    'SpaceFileBrowser', 'SpaceSpreadsheet', 'SpaceOutliner',
)


def _clean_identifier(value: str, fallback: str = 'core_suite') -> str:
    text = str(value or '').strip().split('.')[-1]
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    return text or fallback


def _title_from_key(value: str) -> str:
    text = str(value or '').strip().split('.')[-1]
    text = text.replace('_suite', '').replace('_', ' ').strip()
    if not text:
        return 'Smart Transform'
    return ' '.join(part[:1].upper() + part[1:] for part in text.split())


def _infer_suite_key() -> str:
    package = str(__package__ or '').strip('.')
    if package:
        parts = [p for p in package.split('.') if p]
        if len(parts) >= 3 and parts[0] == 'bl_ext':
            return _clean_identifier(parts[2])
        if 'user_default' in parts:
            idx = parts.index('user_default')
            if idx + 1 < len(parts):
                return _clean_identifier(parts[idx + 1])
        if parts:
            return _clean_identifier(parts[0])
    return 'core_suite'


def _infer_category(suite_key: str) -> str:
    title = _title_from_key(suite_key)
    return title if title.lower().startswith('smart ') else f'Smart {title}'


def configure(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    global _SUITE_KEY, _SUITE_LABEL, _CATEGORY, _OPERATOR_ID
    if not _SUITE_KEY:
        _SUITE_KEY = _clean_identifier(suite_key or _infer_suite_key())
    if suite_key:
        _SUITE_KEY = _clean_identifier(suite_key)
    if suite_label:
        _SUITE_LABEL = str(suite_label).strip()
    if not _SUITE_LABEL:
        _SUITE_LABEL = _title_from_key(_SUITE_KEY)
    if category:
        _CATEGORY = str(category).strip()
    if not _CATEGORY:
        _CATEGORY = _infer_category(_SUITE_KEY)
    _OPERATOR_ID = f'{_SUITE_KEY}.toggle_persistent_feature'


def toggle_operator_id() -> str:
    configure()
    return _OPERATOR_ID


def _is_ja(context=None) -> bool:
    try:
        prefs = getattr(getattr(context, 'preferences', None), 'view', None) if context is not None else getattr(getattr(bpy.context, 'preferences', None), 'view', None)
        lang = str(getattr(prefs, 'language', '') or '').lower()
    except Exception:
        lang = ''
    try:
        locale = str(getattr(getattr(bpy.app, 'translations', None), 'locale', '') or '').lower()
    except Exception:
        locale = ''
    return lang.startswith('ja') or locale.startswith('ja') or 'japanese' in lang


def _t(context, en: str, ja: str) -> str:
    return str(ja if _is_ja(context) else en)


def _static_t(en: str, ja: str) -> str:
    return str(ja if _is_ja(None) else en)


def _extension_storage_id() -> str:
    configure()
    try:
        from . import runtime as _runtime
        return _clean_identifier(_runtime.extension_id(__file__), fallback='smart_transform_suite')
    except Exception:
        return _clean_identifier(_SUITE_KEY or 'smart_transform_suite', fallback='smart_transform_suite')


def _settings_dir() -> Path | None:
    # Legacy per-feature file directory.  Current builds persist feature toggles
    # inside Blender's config/Smart_Transform_Suite/Smart_Transform_Suite.json; this directory is kept
    # only for one-time migration from older releases.
    try:
        from . import runtime as _runtime
        base = _runtime.extension_user_default_storage_dir(__file__, folder_name='_user_data', create=False)
        return base if base is not None else None
    except Exception:
        return None


def _main_settings_path() -> Path | None:
    try:
        base_text = bpy.utils.user_resource('CONFIG', path='', create=True)
        base = Path(str(base_text)) / 'Smart_Transform_Suite'
        base.mkdir(parents=True, exist_ok=True)
        return base / 'Smart_Transform_Suite.json'
    except Exception:
        return None


def _settings_file_names() -> list[str]:
    primary_stem = _extension_storage_id()
    names = [f'{primary_stem}_persistent_feature_toggles.json']
    for stem in (_SUITE_KEY, 'core_suite'):
        cleaned = _clean_identifier(stem, fallback='core_suite')
        name = f'{cleaned}_persistent_feature_toggles.json'
        if name not in names:
            names.append(name)
    return names


def _settings_path() -> Path | None:
    base = _settings_dir()
    if base is None:
        return None
    return base / _settings_file_names()[0]


def _settings_path_candidates() -> list[Path]:
    base = _settings_dir()
    if base is None:
        return []
    return [base / name for name in _settings_file_names()]


def _read_main_settings_state() -> dict[str, dict[str, bool]]:
    path = _main_settings_path()
    if path is None or not path.exists():
        return {}
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(raw, dict):
            return {}
        data = raw.get('feature_toggles')
        return _normalize_state(data)
    except Exception:
        return {}


def _write_main_settings_state(data: dict[str, dict[str, bool]]) -> None:
    path = _main_settings_path()
    if path is None:
        return
    try:
        raw: dict[str, Any] = {}
        if path.exists():
            loaded = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(loaded, dict):
                raw = loaded
        raw['schema'] = max(int(raw.get('schema', 3) or 3), 3)
        raw['feature_toggles'] = _normalize_state(data)
        path.write_text(json.dumps(raw, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
    except Exception:
        pass


def _migrate_legacy_state_file(source: Path, data: dict[str, dict[str, bool]]) -> None:
    if not isinstance(data, dict):
        return
    try:
        _write_main_settings_state(data)
    except Exception:
        pass
    try:
        if source.exists():
            source.unlink()
    except Exception:
        pass


def _suite_prefs(context=None):
    try:
        from . import runtime as _runtime
        return _runtime.get_addon_preferences(context or getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        return None


def _normalize_state(raw: Any) -> dict[str, dict[str, bool]]:
    data: dict[str, dict[str, bool]] = {}
    if isinstance(raw, dict):
        for alias, values in raw.items():
            if isinstance(values, dict):
                data[str(alias)] = {str(k): bool(v) for k, v in values.items()}
    return data


def _parse_state_text(text: str | None) -> dict[str, dict[str, bool]]:
    if not text:
        return {}
    try:
        return _normalize_state(json.loads(str(text)))
    except Exception:
        return {}


def _load_state_from_preferences(context=None) -> dict[str, dict[str, bool]]:
    prefs = _suite_prefs(context)
    if prefs is None:
        return {}
    try:
        return _parse_state_text(getattr(prefs, _PREF_MIRROR_PROP, ''))
    except Exception:
        return {}


def _mirror_state_to_preferences(data: dict[str, dict[str, bool]] | None = None, context=None) -> None:
    prefs = _suite_prefs(context)
    if prefs is None or not hasattr(prefs, _PREF_MIRROR_PROP):
        return
    try:
        json_text = json.dumps(data if data is not None else _load_state(), ensure_ascii=False, indent=2, sort_keys=True)
        if getattr(prefs, _PREF_MIRROR_PROP, '') != json_text:
            setattr(prefs, _PREF_MIRROR_PROP, json_text)
    except Exception:
        pass


def _load_state() -> dict[str, dict[str, bool]]:
    global _STATE_CACHE
    if _STATE_CACHE is not None:
        return _STATE_CACHE
    data: dict[str, dict[str, bool]] = _read_main_settings_state()
    if not data:
        for path in _settings_path_candidates():
            if path.exists():
                try:
                    data = _parse_state_text(path.read_text(encoding='utf-8'))
                    if data:
                        _migrate_legacy_state_file(path, data)
                        break
                except Exception:
                    data = {}
    if not data:
        data = _load_state_from_preferences()
    _STATE_CACHE = data
    return _STATE_CACHE


def _save_state() -> None:
    data = _load_state()
    try:
        _write_main_settings_state(data)
    except Exception:
        pass
    for legacy_path in _settings_path_candidates():
        try:
            if legacy_path.exists():
                legacy_path.unlink()
        except Exception:
            pass
    _mirror_state_to_preferences(data)
    try:
        from . import settings as _settings
        saver = getattr(_settings, 'save_always_on_now', None)
        if callable(saver):
            saver(getattr(bpy, 'context', None))
    except Exception:
        pass


def export_persistent_state(context=None) -> dict[str, dict[str, bool]]:
    del context
    return {str(alias): {str(key): bool(value) for key, value in values.items()} for alias, values in _load_state().items()}


def import_persistent_state(data: Any, *, context=None, apply_runtime: bool = True) -> None:
    del context
    global _STATE_CACHE
    _STATE_CACHE = _normalize_state(data)
    _write_main_settings_state(_STATE_CACHE)
    _mirror_state_to_preferences(_STATE_CACHE)
    if apply_runtime:
        for alias, feature_map in list(_FEATURES.items()):
            for key, feature in list(feature_map.items()):
                try:
                    _set_feature_active(feature, bool(_STATE_CACHE.get(alias, {}).get(key, False)))
                except Exception:
                    pass
    _queue_redraw()


def sync_state_to_preferences(context=None) -> None:
    global _STATE_CACHE
    prefs_data = _load_state_from_preferences(context)
    if prefs_data and not _load_state():
        _STATE_CACHE = prefs_data
    _mirror_state_to_preferences(_load_state(), context)


def is_feature_enabled(alias: str, feature_key: str) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    # Runtime feature captures default to disabled so Blender starts light.  User-saved
    # choices still win; enabling a row in the N-panel records the choice and applies
    # the captured handler, timer, msgbus, keymap, or draw-handler resources.
    return bool(_load_state().get(alias, {}).get(feature_key, False))


def set_feature_enabled(alias: str, feature_key: str, enabled: bool) -> bool:
    alias = str(alias or '').strip()
    feature_key = str(feature_key or '').strip()
    if not alias or not feature_key:
        return False
    _load_state().setdefault(alias, {})[feature_key] = bool(enabled)
    _save_state()
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature is not None:
        _set_feature_active(feature, bool(enabled))
    _queue_redraw()
    return True


def _feature_record(alias: str, tool_label: str, feature_key: str) -> dict[str, Any]:
    alias = str(alias or '').strip()
    tool_label = str(tool_label or alias or 'Integrated Tool').strip()
    feature_key = str(feature_key or '').strip()
    info = _KIND_INFO.get(feature_key, {})
    features = _FEATURES.setdefault(alias, {})
    feature = features.get(feature_key)
    if feature is None:
        feature = {
            'alias': alias,
            'tool_label': tool_label,
            'key': feature_key,
            'label_en': str(info.get('label_en') or feature_key),
            'label_ja': str(info.get('label_ja') or feature_key),
            'description_en': str(info.get('description_en') or ''),
            'description_ja': str(info.get('description_ja') or ''),
            'actions': [],
        }
        features[feature_key] = feature
    else:
        feature['tool_label'] = tool_label
    return feature


def _add_action(alias: str, tool_label: str, feature_key: str, action: dict[str, Any]) -> None:
    feature = _feature_record(alias, tool_label, feature_key)
    feature.setdefault('actions', []).append(action)


def feature_entries(alias: str | None = None) -> list[dict[str, Any]]:
    aliases = [str(alias).strip()] if alias else sorted(_FEATURES.keys())
    out: list[dict[str, Any]] = []
    for alias_key in aliases:
        feature_map = _FEATURES.get(alias_key, {})
        for key in _KIND_ORDER:
            feature = feature_map.get(key)
            if not feature or not feature.get('actions'):
                continue
            item = dict(feature)
            item['enabled'] = is_feature_enabled(alias_key, key)
            item['action_count'] = len(feature.get('actions') or [])
            out.append(item)
    return out


def all_feature_aliases() -> tuple[str, ...]:
    return tuple(sorted(alias for alias, items in _FEATURES.items() if any((f.get('actions') for f in items.values()))))


def _snapshot_handlers() -> dict[str, set[int]]:
    result: dict[str, set[int]] = {}
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return result
    for name in dir(handlers):
        if name.startswith('_') or name == 'persistent':
            continue
        try:
            seq = getattr(handlers, name)
        except Exception:
            continue
        if not hasattr(seq, 'append') or not hasattr(seq, 'remove'):
            continue
        try:
            result[name] = {id(item) for item in list(seq)}
        except Exception:
            continue
    return result


def _collect_new_handlers(before: dict[str, set[int]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
    if handlers is None:
        return actions
    for name, before_ids in before.items():
        try:
            seq = getattr(handlers, name)
            current = list(seq)
        except Exception:
            continue
        for fn in current:
            if id(fn) not in before_ids:
                actions.append({'kind': 'handlers', 'list_name': name, 'fn': fn, 'active': True})
    return actions


def _snapshot_keymaps() -> set[int]:
    # Blender 5.1/Python 3.13 can crash natively when add-ons inspect
    # KeyMapItem.properties during startup.  The suite now uses explicit
    # per-tool N-panel switches and direct module keymap registration, so the
    # generic runtime-capture keymap audit is intentionally disabled.
    return set()


def _copy_keymap_properties(kmi) -> dict[str, Any]:
    # Do not touch ``kmi.properties`` here.  Some legacy keymap items contain
    # stale OperatorProperties such as ``mode``/``action``; merely reading them
    # can emit native warnings and, in Blender 5.1 startup, can access-violate
    # inside python313.dll before Python exception handling is reached.
    return {}


def _describe_keymap_item(km, kmi) -> dict[str, Any]:
    def _get(obj, name: str, default=None):
        try:
            return getattr(obj, name)
        except Exception:
            return default
    return {
        'kind': 'keymaps',
        'km_name': str(_get(km, 'name', '') or ''),
        'space_type': str(_get(km, 'space_type', 'EMPTY') or 'EMPTY'),
        'region_type': str(_get(km, 'region_type', 'WINDOW') or 'WINDOW'),
        'modal': bool(_get(km, 'is_modal', False)),
        'idname': str(_get(kmi, 'idname', '') or ''),
        'type': str(_get(kmi, 'type', 'NONE') or 'NONE'),
        'value': str(_get(kmi, 'value', 'PRESS') or 'PRESS'),
        'any': bool(_get(kmi, 'any', False)),
        'shift': bool(_get(kmi, 'shift', False)),
        'ctrl': bool(_get(kmi, 'ctrl', False)),
        'alt': bool(_get(kmi, 'alt', False)),
        'oskey': bool(_get(kmi, 'oskey', False)),
        'key_modifier': str(_get(kmi, 'key_modifier', 'NONE') or 'NONE'),
        'direction': str(_get(kmi, 'direction', 'ANY') or 'ANY'),
        'repeat': bool(_get(kmi, 'repeat', False)),
        'properties': _copy_keymap_properties(kmi),
        'km': km,
        'kmi': kmi,
        'active': True,
    }


def _collect_new_keymaps(before: set[int]) -> list[dict[str, Any]]:
    # Startup-safe mode: never inspect Blender keymap items during add-on
    # registration.  This avoids native crashes from stale OperatorProperties
    # wrappers while preserving the actual keymaps created by each tool module.
    return []


def _remove_action(action: dict[str, Any]) -> None:
    kind = str(action.get('kind') or '')
    if not bool(action.get('active', False)):
        return
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and fn in seq:
                seq.remove(fn)
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        timers.unregister(fn)
                except Exception:
                    try:
                        timers.unregister(fn)
                    except Exception:
                        pass
        elif kind == 'msgbus':
            owner = action.get('owner')
            if owner is not None:
                try:
                    bpy.msgbus.clear_by_owner(owner)
                except Exception:
                    pass
        elif kind == 'draw_handlers':
            handle = action.get('handle')
            space_cls = action.get('space_cls')
            region_type = action.get('region_type')
            if handle is not None and space_cls is not None:
                try:
                    remove = _ORIGINAL_DRAW_REMOVES.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_remove', None)
                    if callable(remove):
                        remove(handle, region_type)
                except Exception:
                    pass
                action['handle'] = None
        elif kind == 'keymaps':
            km = action.get('active_km') or action.get('km')
            kmi = action.get('active_kmi') or action.get('kmi')
            # Never physically remove keymap items here. Blender 5.1 can crash
            # natively in rna_KeyMap_item_remove during add-on shutdown, and
            # Python exceptions cannot catch that access violation. Disabling
            # the KMI is sufficient for runtime toggles; during Blender exit the
            # helper is a no-op.
            if kmi is not None:
                # Disable only.  Do not call Blender's physical remove path from
                # runtime toggles or shutdown cleanup; Blender 5.1 can crash in
                # rna_KeyMap_item_remove when stale wrappers are involved.
                safe_set_keymap_item_active(kmi, False, km=km)
            action['active_km'] = km
            action['active_kmi'] = kmi
    finally:
        action['active'] = False



def _apply_keymap_action(action: dict[str, Any]) -> None:
    """Crash-safe no-op for captured keymap actions.

    Smart Transform no longer recreates or reactivates keymap items from the
    feature-toggle capture layer because Blender 5.1 can crash natively while
    freeing stale OperatorProperties during keyconfig rebuild.
    """
    try:
        action['active'] = False
        action['active_km'] = None
        action['active_kmi'] = None
    except Exception:
        pass
    return

def _apply_action(action: dict[str, Any]) -> None:
    if bool(action.get('active', False)):
        return
    kind = str(action.get('kind') or '')
    try:
        if kind == 'handlers':
            handlers = getattr(getattr(bpy, 'app', None), 'handlers', None)
            seq = getattr(handlers, str(action.get('list_name') or ''), None) if handlers is not None else None
            fn = action.get('fn')
            if seq is not None and callable(fn) and fn not in seq:
                seq.append(fn)
                action['active'] = True
        elif kind == 'timers':
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            fn = action.get('fn')
            if timers is not None and callable(fn):
                register = _ORIGINALS.get('timer_register') or timers.register
                try:
                    if hasattr(timers, 'is_registered') and timers.is_registered(fn):
                        action['active'] = True
                        return
                except Exception:
                    pass
                register(fn, *tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'msgbus':
            subscribe = _ORIGINALS.get('msgbus_subscribe') or getattr(bpy.msgbus, 'subscribe_rna', None)
            if callable(subscribe):
                subscribe(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'draw_handlers':
            space_cls = action.get('space_cls')
            add = _ORIGINAL_DRAW_ADDS.get(str(action.get('space_name') or '')) or getattr(space_cls, 'draw_handler_add', None)
            if callable(add):
                action['handle'] = add(*tuple(action.get('args') or ()), **dict(action.get('kwargs') or {}))
                action['active'] = True
        elif kind == 'keymaps':
            _apply_keymap_action(action)
    except Exception:
        action['active'] = False


def _set_feature_active(feature: dict[str, Any], enabled: bool) -> None:
    actions = list(feature.get('actions') or [])
    if enabled:
        for action in actions:
            _apply_action(action)
    else:
        for action in reversed(actions):
            _remove_action(action)


def deactivate_alias(alias: str) -> None:
    for feature in list(_FEATURES.get(str(alias or '').strip(), {}).values()):
        _set_feature_active(feature, False)


def clear_alias(alias: str) -> None:
    alias = str(alias or '').strip()
    deactivate_alias(alias)
    _FEATURES.pop(alias, None)


def _current_capture() -> '_RuntimeCapture | None':
    return _CAPTURE_STACK[-1] if _CAPTURE_STACK else None


class _DummyDrawHandle:
    def __init__(self, label: str):
        self.label = label


def _next_dummy_handle() -> _DummyDrawHandle:
    global _DUMMY_COUNTER
    _DUMMY_COUNTER += 1
    return _DummyDrawHandle(f'disabled_draw_handler_{_DUMMY_COUNTER}')


def _timer_register_proxy(function, *args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['timer_register'](function, *args, **kwargs)
    action = {'kind': 'timers', 'fn': function, 'args': tuple(args), 'kwargs': dict(kwargs), 'active': False}
    cap.record_action('timers', action)
    if cap.kind_enabled('timers'):
        result = _ORIGINALS['timer_register'](function, *args, **kwargs)
        action['active'] = True
        return result
    return None


def _msgbus_subscribe_proxy(*args, **kwargs):
    cap = _current_capture()
    if cap is None:
        return _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
    owner = kwargs.get('owner')
    if owner is None and len(args) >= 2:
        owner = args[1]
    action = {'kind': 'msgbus', 'args': tuple(args), 'kwargs': dict(kwargs), 'owner': owner, 'active': False}
    cap.record_action('msgbus', action)
    if cap.kind_enabled('msgbus'):
        result = _ORIGINALS['msgbus_subscribe'](*args, **kwargs)
        action['active'] = True
        return result
    return None


def _make_draw_add_proxy(space_name: str, space_cls, original_add):
    def _proxy(*args, **kwargs):
        cap = _current_capture()
        if cap is None:
            return original_add(*args, **kwargs)
        region_type = args[2] if len(args) >= 3 else kwargs.get('region_type')
        action = {
            'kind': 'draw_handlers',
            'space_name': space_name,
            'space_cls': space_cls,
            'args': tuple(args),
            'kwargs': dict(kwargs),
            'region_type': region_type,
            'handle': None,
            'active': False,
        }
        cap.record_action('draw_handlers', action)
        if cap.kind_enabled('draw_handlers'):
            action['handle'] = original_add(*args, **kwargs)
            action['active'] = True
            return action['handle']
        return _next_dummy_handle()
    return _proxy


def _install_patches() -> None:
    # Startup-safe Blender 5.x mode: do not monkey-patch bpy.app.timers,
    # bpy.msgbus, or Space*.draw_handler_add. Known always-on features are
    # controlled explicitly from their saved preferences. Handler/keymap
    # snapshots are still collected without replacing Blender runtime APIs.
    return None


def _uninstall_patches() -> None:
    global _PATCH_DEPTH
    _PATCH_DEPTH = 0
    return None


class _RuntimeCapture(AbstractContextManager):
    def __init__(self, alias: str, tool_label: str | None = None):
        configure()
        self.alias = str(alias or '').strip()
        self.tool_label = str(tool_label or self.alias or 'Integrated Tool').strip()
        self._before_handlers: dict[str, set[int]] = {}
        self._before_keymaps: set[int] = set()

    def __enter__(self):
        self._before_handlers = _snapshot_handlers()
        self._before_keymaps = _snapshot_keymaps()
        _CAPTURE_STACK.append(self)
        _install_patches()
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            # Known STS always-on resources are now controlled explicitly by the
            # N-panel Always-on Toggles.  The generic capture registry is kept
            # only as an audit record, so it must not silently deactivate keymaps
            # or handlers that a saved curated switch intentionally enabled.
            for action in _collect_new_handlers(self._before_handlers):
                self.record_action('handlers', action)
            for action in _collect_new_keymaps(self._before_keymaps):
                self.record_action('keymaps', action)
        finally:
            if self in _CAPTURE_STACK:
                _CAPTURE_STACK.remove(self)
            _uninstall_patches()
            _tag_redraw()
        return False

    def kind_enabled(self, feature_key: str) -> bool:
        return is_feature_enabled(self.alias, feature_key)

    def record_action(self, feature_key: str, action: dict[str, Any]) -> None:
        if self.alias and feature_key:
            _add_action(self.alias, self.tool_label, feature_key, action)


def capture_runtime(alias: str, tool_label: str | None = None) -> _RuntimeCapture:
    return _RuntimeCapture(alias, tool_label)


def capture_call(alias: str, tool_label: str | None, callback: Callable[[], Any]) -> Any:
    with capture_runtime(alias, tool_label):
        return callback()


def _tag_redraw() -> None:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _tag_redraw_delayed():
    global _REDRAW_PENDING
    _REDRAW_PENDING = False
    _tag_redraw()
    return None


def _queue_redraw() -> None:
    global _REDRAW_PENDING
    if _REDRAW_PENDING:
        return
    _REDRAW_PENDING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_tag_redraw_delayed, first_interval=0.03)
            return
    except Exception:
        pass
    _tag_redraw_delayed()


def _draw_toggle_operator_button(row, *, enabled: bool, text: str | None = None):
    try:
        row.operator_context = 'EXEC_DEFAULT'
    except Exception:
        pass
    label = text if text is not None else _static_t('Enabled' if enabled else 'Disabled', '有効' if enabled else '無効')
    icon_name = 'CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT'
    icon_args = _ui_icon_kwargs(icon=icon_name, operator_id=_OPERATOR_ID, text=label, custom_icon='enabled' if enabled else 'disabled')
    try:
        return row.operator(_OPERATOR_ID, text=label, emboss=True, depress=bool(enabled), **icon_args)
    except TypeError:
        return row.operator(
            _OPERATOR_ID,
            text=label,
            icon=icon_name,
            emboss=True,
            depress=bool(enabled),
        )


def _safe_set_toggle_operator_prop(op, prop_name: str, value) -> bool:
    try:
        return bool(_op_safety.safe_set_operator_property(op, prop_name, value, operator_id=_OPERATOR_ID, strict=True))
    except Exception:
        # Never assign undeclared OperatorProperties directly; Blender emits
        # native warnings before Python can catch them.
        return False


def _operator_description(context, properties) -> str:
    alias = str(getattr(properties, 'alias', '') or '')
    feature_key = str(getattr(properties, 'feature_key', '') or '')
    feature = _FEATURES.get(alias, {}).get(feature_key)
    if feature:
        label = _t(context, feature.get('label_en', ''), feature.get('label_ja', ''))
        desc = _t(context, feature.get('description_en', ''), feature.get('description_ja', ''))
        state = _t(context, 'Click to switch this feature between enabled and disabled.', 'クリックすると、この機能の有効 / 無効を切り替えます。')
        return f'{label}: {desc} {state}'
    return _t(context, 'Toggle an always-on Smart Transform feature. The setting is saved to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json immediately.', 'Smart Transform の常時発動機能を切り替えます。設定は Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonへ即時保存されます。')


def _direct_class_rna(cls: type):
    try:
        return vars(cls).get('bl_rna') if isinstance(cls, type) else None
    except Exception:
        return None


def _class_is_registered_exact(cls: type) -> bool:
    rna = _direct_class_rna(cls)
    return bool(rna is not None and str(getattr(rna, 'identifier', '') or ''))


def _class_is_suite_owned(cls: type) -> bool:
    module_name = str(getattr(cls, '__module__', '') or '')
    package_name = str(__package__ or 'smart_transform_suite')
    return bool(module_name == __name__ or module_name == package_name or module_name.startswith(package_name + '.'))


def _lookup_registered_class(identifier: str, base: type):
    identifier = str(identifier or '').strip()
    if not identifier:
        return None
    try:
        exposed = getattr(getattr(bpy, 'types', None), identifier, None)
    except Exception:
        exposed = None
    if isinstance(exposed, type) and _class_is_registered_exact(exposed):
        return exposed
    lookup = getattr(base, 'bl_rna_get_subclass_py', None)
    if callable(lookup):
        try:
            found = lookup(identifier)
        except Exception:
            found = None
        if isinstance(found, type) and _class_is_registered_exact(found):
            return found
    return None


def _proxy_targets_identifier(identifier: str) -> bool:
    try:
        direct = vars(bpy.types.WindowManager).get(_PROXY_COLLECTION_ATTR)
    except Exception:
        direct = None
    if direct is None:
        return False
    try:
        properties = getattr(getattr(bpy.types.WindowManager, 'bl_rna', None), 'properties', None)
        prop = properties.get(_PROXY_COLLECTION_ATTR) if properties is not None else None
        fixed = getattr(prop, 'fixed_type', None) if prop is not None else None
        return str(getattr(fixed, 'identifier', '') or '') == str(identifier or '')
    except Exception:
        return False


def _remove_proxy_collection_property(*, require_owned: bool = True) -> bool:
    try:
        direct = vars(bpy.types.WindowManager).get(_PROXY_COLLECTION_ATTR)
    except Exception:
        direct = None
    if direct is None:
        return True
    if require_owned and not _proxy_targets_identifier('STS_PG_persistent_feature_switch'):
        return False
    try:
        delattr(bpy.types.WindowManager, _PROXY_COLLECTION_ATTR)
    except Exception:
        return False
    try:
        return vars(bpy.types.WindowManager).get(_PROXY_COLLECTION_ATTR) is None
    except Exception:
        return True


def _retire_suite_class(cls: type, *, expected_name: str, expected_bl_idname: str = '') -> bool:
    if not isinstance(cls, type) or not _class_is_registered_exact(cls):
        return True
    if str(getattr(cls, '__name__', '') or '') != str(expected_name):
        return False
    if not _class_is_suite_owned(cls):
        return False
    if expected_bl_idname and str(getattr(cls, 'bl_idname', '') or '') != str(expected_bl_idname):
        return False
    if expected_name == 'STS_PG_persistent_feature_switch':
        if not _remove_proxy_collection_property(require_owned=True):
            return False
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        return False
    return not _class_is_registered_exact(cls)


def _class_ledger():
    namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
    if not isinstance(namespace, dict):
        return None, None
    value = namespace.get(_CLASS_LEDGER_KEY)
    if not isinstance(value, dict) or value.get('schema') != 1 or value.get('suite') != 'smart_transform_suite':
        value = None
    return namespace, value


def _retire_previous_ui_classes(operator_name: str) -> None:
    namespace, ledger = _class_ledger()
    candidates = []
    if isinstance(ledger, dict):
        candidates.extend(tuple(ledger.get('classes', ()) or ()))
    for identifier, base in (
        (operator_name, bpy.types.Operator),
        ('STS_PG_persistent_feature_switch', bpy.types.PropertyGroup),
    ):
        found = _lookup_registered_class(identifier, base)
        if isinstance(found, type) and all(found is not item for item in candidates):
            candidates.append(found)
    for cls in reversed(candidates):
        name = str(getattr(cls, '__name__', '') or '')
        expected_id = _OPERATOR_ID if name == operator_name else ''
        if name not in {operator_name, 'STS_PG_persistent_feature_switch'}:
            raise RuntimeError(f'foreign Smart Transform feature-toggle class record: {name or cls!r}')
        if not _retire_suite_class(cls, expected_name=name, expected_bl_idname=expected_id):
            raise RuntimeError(f'could not retire previous Smart Transform feature-toggle class: {name}')
    if isinstance(namespace, dict):
        namespace.pop(_CLASS_LEDGER_KEY, None)


def _register_ui_class(cls: type) -> type:
    if _class_is_registered_exact(cls):
        if all(item is not cls for item in _REGISTERED_CLASSES):
            _REGISTERED_CLASSES.append(cls)
        return cls
    bpy.utils.register_class(cls)
    if not _class_is_registered_exact(cls):
        raise RuntimeError(f'Smart Transform RNA registration identity failed: {cls.__name__}')
    _REGISTERED_CLASSES.append(cls)
    return cls


def _publish_ui_class_ledger() -> None:
    namespace = getattr(getattr(bpy, 'app', None), 'driver_namespace', None)
    if not isinstance(namespace, dict):
        raise RuntimeError('Smart Transform driver_namespace is unavailable')
    namespace[_CLASS_LEDGER_KEY] = {
        'schema': 1,
        'suite': 'smart_transform_suite',
        'classes': tuple(_REGISTERED_CLASSES),
    }


def _operator_id_owned_elsewhere(operator_id: str) -> bool:
    namespace, name = operator_id.split('.', 1)
    try:
        rna = getattr(getattr(bpy.ops, namespace), name).get_rna_type()
    except (KeyError, RuntimeError):
        return False
    owner = bpy.types.Operator.bl_rna_get_subclass_py(rna.identifier)
    return owner is None or getattr(owner, '__module__', '') != __name__


def register_ui(*, suite_key: str | None = None, suite_label: str | None = None, category: str | None = None) -> None:
    configure(suite_key=suite_key, suite_label=suite_label, category=category)
    if _operator_id_owned_elsewhere(_OPERATOR_ID):
        raise RuntimeError(f'foreign operator owner: {_OPERATOR_ID}')
    _remove_legacy_proxy_collection_properties()
    if _REGISTERED_CLASSES and all(_class_is_registered_exact(cls) for cls in _REGISTERED_CLASSES):
        _ensure_proxy_collection_property()
        return
    _REGISTERED_CLASSES.clear()
    operator_id = _OPERATOR_ID
    operator_name = f"STS_OT_{_SUITE_KEY.upper()}_TOGGLE_PERSISTENT_FEATURE"
    _retire_previous_ui_classes(operator_name)
    _register_ui_class(STS_PG_persistent_feature_switch)
    _ensure_proxy_collection_property()

    class STS_OT_toggle_persistent_feature(bpy.types.Operator):
        bl_idname = operator_id
        bl_label = _static_t('Toggle Feature', '機能を切り替え')
        bl_options = {'UNDO'}
        bl_undo_group = 'Smart Transform Suite'
        bl_description = _static_t('Switch an always-on feature on or off and save the setting immediately.', '常時発動機能の有効 / 無効を切り替え、設定を即時保存します。')

        alias: bpy.props.StringProperty(
            name=_static_t('Feature Group', '機能グループ'),
            description=_static_t('Internal group identifier for the always-on feature to change.', '変更する常時起動機能の内部グループ識別子です。'),
            default='',
            options={'SKIP_SAVE'},
        )
        feature_key: bpy.props.StringProperty(
            name=_static_t('Feature Key', '機能キー'),
            description=_static_t('Internal feature identifier for the always-on switch to change.', '変更する常時起動スイッチの内部機能識別子です。'),
            default='',
            options={'SKIP_SAVE'},
        )
        enabled: bpy.props.BoolProperty(
            name=_static_t('Enabled', '有効'),
            description=_static_t('Target state to store for this always-on feature. Enabled starts or keeps the feature active; disabled stops or leaves it inactive.', 'この常時起動機能に保存する目標状態です。有効では機能を開始または維持し、無効では停止または無効状態を維持します。'),
            default=True,
            options={'SKIP_SAVE'},
        )

        @classmethod
        def description(cls, context, properties):
            return _operator_description(context, properties)

        def execute(self, context):
            alias = str(getattr(self, 'alias', '') or '')
            feature_key = str(getattr(self, 'feature_key', '') or '')
            desired = bool(getattr(self, 'enabled', True))
            if not set_feature_enabled(alias, feature_key, desired):
                self.report({'WARNING'}, _t(context, 'The selected feature could not be changed.', '選択した機能を変更できませんでした。'))
                return {'CANCELLED'}
            self.report({'INFO'}, _t(context, 'Feature setting saved.', '機能設定を保存しました。'))
            return {'FINISHED'}

    STS_OT_toggle_persistent_feature.__name__ = operator_name
    STS_OT_toggle_persistent_feature.__qualname__ = STS_OT_toggle_persistent_feature.__name__
    STS_OT_toggle_persistent_feature.__module__ = __name__
    try:
        _register_ui_class(STS_OT_toggle_persistent_feature)
        _publish_ui_class_ledger()
    except Exception:
        unregister_ui()
        raise


def draw_inline_toggles(layout, context, alias: str, *, compact: bool = True) -> bool:
    """Draw feature toggles using the standardized Smart toolset layout."""
    configure()
    try:
        register_ui()
    except Exception:
        pass
    alias = str(alias or '').strip()
    entries = feature_entries(alias)
    if not entries:
        return False
    try:
        col = layout.column(align=True)
        for item in entries:
            enabled = bool(item.get('enabled'))
            feature_key = str(item.get('key') or '')
            label = _t(context, str(item.get('label_en') or feature_key), str(item.get('label_ja') or feature_key))
            row = col.row(align=True)
            row.label(text=label)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Enabled', '有効'), depress=enabled)
            _safe_set_toggle_operator_prop(op, 'alias', alias)
            _safe_set_toggle_operator_prop(op, 'feature_key', feature_key)
            _safe_set_toggle_operator_prop(op, 'enabled', True)
            op = row.operator(_OPERATOR_ID, text=_t(context, 'Disabled', '無効'), depress=not enabled)
            _safe_set_toggle_operator_prop(op, 'alias', alias)
            _safe_set_toggle_operator_prop(op, 'feature_key', feature_key)
            _safe_set_toggle_operator_prop(op, 'enabled', False)
            if not compact:
                desc = _t(context, str(item.get('description_en') or ''), str(item.get('description_ja') or ''))
                if desc:
                    col.label(text=desc[:240])
        return True
    except Exception:
        return False


def unregister_ui() -> None:
    _remove_proxy_collection_property(require_owned=True)
    for attr in _LEGACY_PROXY_COLLECTION_ATTRS:
        try:
            if hasattr(bpy.types.WindowManager, attr):
                delattr(bpy.types.WindowManager, attr)
        except Exception:
            pass
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            if _class_is_registered_exact(cls):
                bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
    namespace, ledger = _class_ledger()
    if isinstance(ledger, dict):
        remaining = []
        for cls in reversed(tuple(ledger.get('classes', ()) or ())):
            if not isinstance(cls, type) or not _class_is_registered_exact(cls):
                continue
            name = str(getattr(cls, '__name__', '') or '')
            expected_id = _OPERATOR_ID if name.startswith('STS_OT_') else ''
            if _retire_suite_class(cls, expected_name=name, expected_bl_idname=expected_id):
                continue
            remaining.append(cls)
        if not remaining and isinstance(namespace, dict):
            namespace.pop(_CLASS_LEDGER_KEY, None)


def unregister_all() -> None:
    if is_blender_shutdown_context():
        # During Blender process shutdown, keyconfigs and RNA collections may
        # already be partially torn down.  Do not mutate captured runtime
        # collections from this layer; Blender is exiting and will release them.
        unregister_ui()
        _FEATURES.clear()
        return
    for alias in list(_FEATURES.keys()):
        deactivate_alias(alias)
    unregister_ui()
    _FEATURES.clear()


def _safe_safe_set_kmi_property_v60(kmi, prop_name, value) -> bool:
    return _op_safety.safe_set_keymap_item_property(kmi, prop_name, value)
