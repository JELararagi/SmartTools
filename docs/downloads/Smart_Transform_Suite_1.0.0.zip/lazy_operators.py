# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

import importlib
from typing import Any

import bpy

from .translation import TI

_REGISTERED_CLASSES: list[type] = []

_TARGET_MODULES = (
    ('object.quick_align_', 'quick_align'),
    ('object.quick_align_tool', 'quick_align'),
    ('object.quick_align_popup', 'quick_align'),
    ('view3d.quick_multi_edit', 'quick_multi_edit'),
    ('outliner.quick_multi_edit', 'quick_multi_edit'),
    ('view3d.ssg_', 'select_guard'),
    ('view3d.select_guard_', 'select_guard'),
    ('view3d.cycle_custom_select', 'core.cycle_custom_select'),
    ('view3d.csdt_toggle_smart_gizmo', 'core.csdt_gizmo'),
    ('view3d.sts_csdt_force', 'core.csdt_operators'),
    ('view3d.csdt_force', 'core.csdt_operators'),
    ('view3d.csdt_click_select_drag', 'core.csdt_operators'),
    ('view3d.csdt_single_select_no_drag', 'core.csdt_operators'),
    ('transform.smart_grs_', 'core.grs_main'),
    ('mesh.smart_island_', 'core.grs_main'),
    ('mesh.sts_island_', 'core.grs_main'),
)


_STS_WARNED_ONCE = set()


def _warn_once(key, detail=''):
    if key not in _STS_WARNED_ONCE:
        _STS_WARNED_ONCE.add(key)
        print('[Smart Transform Suite] %s: %s' % (key, detail))


def module_key_for_operator(operator_id: str) -> str:
    op = str(operator_id or '').strip()
    for prefix, module_key in _TARGET_MODULES:
        if op.startswith(prefix):
            return module_key
    return ''


def operator_exists(operator_id: str) -> bool:
    op = str(operator_id or '').strip()
    if not op or '.' not in op:
        return False
    namespace, name = op.split('.', 1)
    try:
        getattr(getattr(bpy.ops, namespace), name).get_rna_type()
        return True
    except (AttributeError, KeyError, RuntimeError):
        return False


def _load_module(module_key: str, context=None) -> bool:
    key = str(module_key or '').strip()
    if not key:
        return False
    try:
        if key in {'quick_align', 'quick_multi_edit', 'select_guard', 'core_panel'}:
            from . import integration
            integration.toggle(key, True, context or getattr(bpy, 'context', None))
            return True
        module = importlib.import_module(f'{__package__}.{key}')
        ensure = getattr(module, 'ensure_registered', None)
        if callable(ensure):
            ensure(True)
        else:
            register = getattr(module, 'register', None)
            if callable(register):
                # Avoid duplicate class registration when Blender already has it.
                register()
        return True
    except Exception as exc:
        try:
            _warn_once('lazy load ' + str(key), exc)
        except Exception:
            pass
        return False


def _call_operator(operator_id: str, *, mode: str = '', action: str = '', category: str = '') -> set[str]:
    op = str(operator_id or '').strip()
    if not op or '.' not in op:
        return {'CANCELLED'}
    namespace, name = op.split('.', 1)
    try:
        op_callable = getattr(getattr(bpy.ops, namespace), name)
    except Exception:
        return {'CANCELLED'}
    kwargs: dict[str, Any] = {}
    if mode:
        kwargs['mode'] = mode
    if action:
        kwargs['action'] = action
    if category:
        kwargs['category'] = category
    try:
        return op_callable('INVOKE_DEFAULT', **kwargs)
    except Exception:
        try:
            return op_callable('EXEC_DEFAULT', **kwargs)
        except Exception:
            try:
                return op_callable(**kwargs)
            except Exception:
                return {'CANCELLED'}


class STS_OT_lazy_execute_operator(bpy.types.Operator):
    bl_idname = 'core_suite.lazy_execute_operator'
    bl_label = TI('Load and Run Tool', 'ツールを読み込んで実行')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    bl_description = TI(
        'Load only the required Smart Transform tool module, then run the requested operator. This keeps Blender startup light while preserving the same N-panel buttons.',
        '必要なSmart Transformのツールモジュールだけを読み込んでから対象オペレーターを実行します。Nパネルのボタンを維持しつつ、Blender起動時の負荷を抑えます。',
    )

    target_operator: bpy.props.StringProperty(
        name=TI('Target Operator', '対象オペレーター'),
        description=TI('Operator identifier to run after the required Smart Transform module is loaded.', '必要な Smart Transform モジュールを読み込んだ後に実行するオペレーター識別子です。'),
        default='',
        options={'SKIP_SAVE'},
    )
    module_key: bpy.props.StringProperty(
        name=TI('Module Key', 'モジュールキー'),
        description=TI('Internal module key to load before running the target operator. Leave empty to infer it from the operator identifier.', '対象オペレーターを実行する前に読み込む内部モジュールキーです。空の場合はオペレーター識別子から推定します。'),
        default='',
        options={'SKIP_SAVE'},
    )
    mode: bpy.props.StringProperty(
        name=TI('Mode', 'モード'),
        description=TI('Optional mode value forwarded to the target operator when it supports a mode property.', '対象の操作がモードの指定に対応している場合に渡す値です。'),
        default='',
        options={'SKIP_SAVE'},
    )
    action: bpy.props.StringProperty(
        name=TI('Action', 'アクション'),
        description=TI('Optional action value forwarded to the target operator when it supports an action property.', '対象の操作が動作の指定に対応している場合に渡す値です。'),
        default='',
        options={'SKIP_SAVE'},
    )
    category: bpy.props.StringProperty(
        name=TI('Category', 'カテゴリ'),
        description=TI('Optional category value forwarded to reset or settings operators that need a settings category.', '設定カテゴリを必要とするリセットまたは設定オペレーターへ渡す任意のカテゴリ値です。'),
        default='',
        options={'SKIP_SAVE'},
    )

    def execute(self, context):
        target = str(getattr(self, 'target_operator', '') or '').strip()
        module_key = str(getattr(self, 'module_key', '') or '').strip() or module_key_for_operator(target)
        if not target:
            return {'CANCELLED'}
        if not operator_exists(target):
            _load_module(module_key, context)
        if not operator_exists(target):
            self.report({'WARNING'}, TI('The target operator is still unavailable.', '対象オペレーターを利用できません。'))
            return {'CANCELLED'}
        result = _call_operator(
            target,
            mode=str(getattr(self, 'mode', '') or ''),
            action=str(getattr(self, 'action', '') or ''),
            category=str(getattr(self, 'category', '') or ''),
        )
        return result if isinstance(result, set) else {'FINISHED'}


def register() -> None:
    if _REGISTERED_CLASSES:
        return
    try:
        existing = getattr(bpy.types, 'STS_OT_lazy_execute_operator', None)
        if isinstance(existing, type) and existing is not STS_OT_lazy_execute_operator:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    bpy.utils.register_class(STS_OT_lazy_execute_operator)
    _REGISTERED_CLASSES.append(STS_OT_lazy_execute_operator)


def unregister() -> None:
    for cls in reversed(_REGISTERED_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    _REGISTERED_CLASSES.clear()
