"""Read and merge the suite's schema-5 preferences while preserving unknown fields."""
from pathlib import Path
import json,os,tempfile
import bpy

SHAPE=json.loads(Path(__file__).with_name("config_shape.json").read_text("utf8"))
busy=False
dirty=False
error=""

def file():
    directory=Path(bpy.utils.user_resource("CONFIG"))/"Smart_Transform_Suite"
    return directory/"Smart_Transform_Suite.json"

def read():
    p=file()
    for candidate in (p,p.with_suffix(".json.bak")):
        try:
            data=json.loads(candidate.read_text("utf-8-sig"))
            if isinstance(data,dict) and data.get("schema")==5:return data
        except (ValueError,OSError):pass
    return {}

def snapshot(group,shape):
    values={}
    for k,sub in shape.items():
        if not hasattr(group,k):continue
        val=getattr(group,k)
        if isinstance(sub,dict):values[k]=snapshot(val,sub)
        elif isinstance(val,(str,int,float,bool)) or val is None:values[k]=val
        elif hasattr(val,"__iter__"):values[k]=list(val)
    return values

def apply(group,data,shape):
    if not isinstance(data,dict):return
    for key,sub in shape.items():
        if key not in data or not hasattr(group,key):continue
        try:
            if isinstance(sub,dict):apply(getattr(group,key),data[key],sub)
            else:setattr(group,key,data[key])
        except (TypeError,ValueError,AttributeError):continue

def merge(existing,updates):
    for key,val in updates.items():
        if isinstance(val,dict) and isinstance(existing.get(key),dict):merge(existing[key],val)
        else:existing[key]=val

def atomic(p,raw):
    fd,name=tempfile.mkstemp(prefix=".transform-",suffix=".tmp",dir=p.parent)
    try:
        with os.fdopen(fd,"wb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(name,p)
    finally:Path(name).unlink(missing_ok=True)

def save():
    global busy,dirty,error
    if busy:return
    ctx=bpy.context
    if not ctx.scene or not hasattr(ctx.window_manager,"smart_transform_suite_runtime_preferences"):return
    busy=True
    try:
        s=ctx.scene;w=ctx.window_manager;preferences=w.smart_transform_suite_runtime_preferences
        updates={"schema":5,"addon_preferences":snapshot(preferences,SHAPE["addon_preferences"]),
            "always_on_toggles":snapshot(preferences,SHAPE["always_on_toggles"]),
            "scene":{"props":snapshot(s,SHAPE["scene"]["props"]),"pointers":snapshot(s,SHAPE["scene"]["pointers"]),
                     "collection_refs":{key:(getattr(s,key).name if getattr(s,key) else "") for key in SHAPE["scene"]["collection_refs"]}},
            "window_manager":{"pointers":snapshot(w,SHAPE["window_manager"]["pointers"])},
            "feature_toggles":json.loads(preferences.persistent_feature_toggles_json or "{}")}
        for item in w.smart_transform_suite_persistent_feature_switches:
            if item.alias and item.feature_key:updates["feature_toggles"].setdefault(item.alias,{})[item.feature_key]=item.enabled
        data=read()
        merge(data,updates)
        p=file();p.parent.mkdir(parents=True,exist_ok=True)
        raw=(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+"\n").encode()
        if p.exists():
            previous=p.read_bytes()
            if previous==raw:dirty=False;return
            try:valid=json.loads(previous).get("schema")==5
            except (ValueError,AttributeError):valid=False
            if valid:atomic(p.with_suffix(".json.bak"),previous)
        atomic(p,raw);dirty=False;error=""
    except (OSError,TypeError,ValueError) as exc:
        error=str(exc)
        raise
    finally:busy=False

def load(*args):
    global busy,dirty
    data=read()
    if not data:return
    ctx=bpy.context
    if not ctx.scene or not hasattr(ctx.window_manager,"smart_transform_suite_runtime_preferences"):return
    busy=True
    try:
        s=ctx.scene;w=ctx.window_manager;p=w.smart_transform_suite_runtime_preferences
        apply(p,data.get("addon_preferences"),SHAPE["addon_preferences"])
        apply(p,data.get("always_on_toggles"),SHAPE["always_on_toggles"])
        apply(s,data.get("scene",{}).get("props"),SHAPE["scene"]["props"])
        apply(s,data.get("scene",{}).get("pointers"),SHAPE["scene"]["pointers"])
        for k,n in data.get("scene",{}).get("collection_refs",{}).items():
            if k in SHAPE["scene"]["collection_refs"]:setattr(s,k,bpy.data.collections.get(n) if n else None)
        apply(w,data.get("window_manager",{}).get("pointers"),SHAPE["window_manager"]["pointers"])
        for alias,flags in data.get("feature_toggles",{}).items():
            if isinstance(flags,dict):
                for key,enabled in flags.items():switch(w,alias,key,bool(enabled))
        dirty=False
    finally:busy=False

def switch(w,alias,key,enabled):
    if not alias or not key:raise ValueError("Choose a feature")
    pref=w.smart_transform_suite_runtime_preferences
    try:state=json.loads(pref.persistent_feature_toggles_json or "{}")
    except ValueError:state={}
    state.setdefault(alias,{})[key]=enabled
    pref.persistent_feature_toggles_json=json.dumps(state,ensure_ascii=False,sort_keys=True)

def changed(context):
    global dirty
    if busy or not context or not context.scene:return
    dirty=True
    if context.window_manager.smart_transform_suite_runtime_preferences.npanel_state_save_enabled and not bpy.app.timers.is_registered(timer):
        bpy.app.timers.register(timer,first_interval=.15)

def timer():
    if dirty:save()
    return None
