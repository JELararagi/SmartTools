"""Screen-space selection using projected edit geometry and viewport visibility."""
import bmesh
from bpy_extras import view3d_utils
from mathutils import Vector,geometry
from . import selection

def segment_distance(p,a,b):
    edge=b-a
    t=min(1.0,max(0.0,(p-a).dot(edge)/edge.length_squared)) if edge.length_squared else 0
    return (p-(a+edge*t)).length

def object_at(ctx,p,through):
    region=selection.window_region(ctx);view=ctx.space_data.region_3d
    origin=view3d_utils.region_2d_to_origin_3d(region,view,p)
    direction=view3d_utils.region_2d_to_vector_3d(region,view,p)
    graph=ctx.evaluated_depsgraph_get()
    for _ in range(128):
        hit,where,_,_,obj,_=ctx.scene.ray_cast(graph,origin,direction)
        if not hit:return None
        obj=obj.original
        if not obj.hide_select and obj.visible_get(view_layer=ctx.view_layer):return obj
        if not through:return None
        origin=where+direction*.0001
    return None

last_pick={}

def cycle_element(ctx,p,extend):
    pref=ctx.window_manager.smart_transform_suite_runtime_preferences
    modes=ctx.scene.tool_settings.mesh_select_mode
    view=ctx.space_data.region_3d
    sight=view.view_rotation@Vector((0,0,-1))
    candidates=[]
    for obj in ctx.objects_in_mode_unique_data:
        mesh,coords=projected(ctx,obj)
        for enabled,elements,kind,radius in ((modes[0],mesh.verts,"VERT",pref.vert_hit_radius),(modes[1],mesh.edges,"EDGE",pref.edge_hit_radius),(modes[2],mesh.faces,"FACE",0)):
            if not enabled:continue
            for el in elements:
                if el.hide:continue
                vertices=[el] if kind=="VERT" else list(el.verts)
                pts=[coords.get(v) for v in vertices]
                if any(x is None for x in pts):continue
                dist=(pts[0]-p).length if kind=="VERT" else segment_distance(p,*pts) if kind=="EDGE" else 0 if selection.in_polygon(p,pts) else 1
                if dist>radius:continue
                center=sum((obj.matrix_world@v.co for v in vertices),Vector())/len(vertices)
                candidates.append((round(dist,1),center.dot(sight),obj.name,kind,el.index,obj,el))
    if not candidates:return None
    candidates.sort(key=lambda hit:hit[:5])
    signature=tuple(hit[2:5] for hit in candidates)
    area=ctx.area.as_pointer()
    previous=last_pick.get(area)
    index=(previous[2]+1)%len(candidates) if previous and previous[0]==signature and (p-previous[1]).length<4 else 0
    last_pick[area]=(signature,p.copy(),index)
    *_,obj,el=candidates[index]
    if not extend:
        for other in ctx.objects_in_mode_unique_data:
            bm=bmesh.from_edit_mesh(other.data)
            for seq in (bm.faces,bm.edges,bm.verts):
                for item in seq:item.select=False
            bm.select_history.clear()
    el.select_set(not el.select if extend else True)
    bm=bmesh.from_edit_mesh(obj.data)
    if el.select:bm.select_history.add(el)
    for other in ctx.objects_in_mode_unique_data:
        bmesh.update_edit_mesh(other.data,loop_triangles=False,destructive=False)
    return {"FINISHED"}

def polygons_intersect(a,b):
    if any(selection.in_polygon(p,b) for p in a) or (len(a)>2 and any(selection.in_polygon(p,a) for p in b)):return True
    return any(geometry.intersect_line_line_2d(p,q,u,v) is not None for p,q in zip(a,a[1:]+a[:1]) for u,v in zip(b,b[1:]+b[:1]))

def projected(ctx,obj):
    region=selection.window_region(ctx);view=ctx.space_data.region_3d
    mesh=bmesh.from_edit_mesh(obj.data)
    coords={v:view3d_utils.location_3d_to_region_2d(region,view,obj.matrix_world@v.co) for v in mesh.verts if not v.hide}
    return mesh,coords

def crossing(ctx,trail,remove=False):
    if ctx.mode!="EDIT_MESH" or len(trail)<3:return
    prefs=ctx.window_manager.smart_transform_suite_runtime_preferences
    select_mode=ctx.scene.tool_settings.mesh_select_mode
    for obj in ctx.objects_in_mode_unique_data:
        mesh,coords=projected(ctx,obj)
        for enabled,elements in ((select_mode[1] and prefs.crossing_select_edges,mesh.edges),(select_mode[2] and prefs.crossing_select_faces,mesh.faces)):
            if not enabled:continue
            for el in elements:
                if el.hide:continue
                screen=[coords.get(v) for v in el.verts]
                if all(p is not None for p in screen) and polygons_intersect(screen,trail):
                    el.select_set(not remove)
        mesh.select_flush_mode();bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)

def watch(op,ctx,event):
    if event.type=="ESC":return {"CANCELLED"}
    if ctx.mode!="EDIT_MESH":return {"PASS_THROUGH"}
    p=selection.position(ctx,event)
    if p is None:return {"PASS_THROUGH"}
    if event.type=="LEFTMOUSE" and event.value=="PRESS":
        tool=ctx.workspace.tools.from_space_view3d_mode(ctx.mode,create=False)
        op._stroke=[p] if tool and tool.idname in {"builtin.select_box","builtin.select_lasso","builtin.select_circle"} else []
        op._tool=tool.idname if tool else ""
    elif getattr(op,"_stroke",None):
        if event.type=="MOUSEMOVE":op._stroke.append(p)
        elif event.type=="LEFTMOUSE" and event.value=="RELEASE":
            trail=op._stroke+[p];op._stroke=[]
            if op._tool=="builtin.select_box":
                a,b=trail[0],trail[-1];trail=[a,Vector((b.x,a.y)),b,Vector((a.x,b.y))]
            crossing(ctx,trail,event.ctrl)
    return {"PASS_THROUGH"}

