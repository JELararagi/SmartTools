"""Explicit public operator bindings used by Blender registration and audit tools."""
import bpy
from . import actions,schema


class CORE_OT_apply_all(bpy.types.Operator):
    bl_idname = "core.apply_all"
    bl_label = "Apply All"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_apply_rs(bpy.types.Operator):
    bl_idname = "core.apply_rs"
    bl_label = "Apply Rs"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_copy(bpy.types.Operator):
    bl_idname = "core.copy"
    bl_label = "Copy"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_cursor_to_selection_button(bpy.types.Operator):
    bl_idname = "core.cursor_to_selection_button"
    bl_label = "Cursor To Selection Button"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_paste(bpy.types.Operator):
    bl_idname = "core.paste"
    bl_label = "Paste"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_reset_value(bpy.types.Operator):
    bl_idname = "core.reset_value"
    bl_label = "Reset Value"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_snap(bpy.types.Operator):
    bl_idname = "core.snap"
    bl_label = "Snap"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_snap_to_active_button(bpy.types.Operator):
    bl_idname = "core.snap_to_active_button"
    bl_label = "Snap To Active Button"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_snap_to_cursor_button(bpy.types.Operator):
    bl_idname = "core.snap_to_cursor_button"
    bl_label = "Snap To Cursor Button"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_OT_snap_to_floor_button(bpy.types.Operator):
    bl_idname = "core.snap_to_floor_button"
    bl_label = "Snap To Floor Button"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_SUITE_OT_copy_text(bpy.types.Operator):
    bl_idname = "core_suite.copy_text"
    bl_label = "Copy Text"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_SUITE_OT_help_popup_dialog(bpy.types.Operator):
    bl_idname = "core_suite.help_popup_dialog"
    bl_label = "Help Popup Dialog"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_SUITE_OT_lazy_execute_operator(bpy.types.Operator):
    bl_idname = "core_suite.lazy_execute_operator"
    bl_label = "Lazy Execute Operator"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_SUITE_OT_show_tool_help(bpy.types.Operator):
    bl_idname = "core_suite.show_tool_help"
    bl_label = "Show Tool Help"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_SUITE_OT_toggle_always_on_property(bpy.types.Operator):
    bl_idname = "core_suite.toggle_always_on_property"
    bl_label = "Toggle Always On Property"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class CORE_SUITE_OT_toggle_npanel_foldout(bpy.types.Operator):
    bl_idname = "core_suite.toggle_npanel_foldout"
    bl_label = "Toggle Npanel Foldout"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class MESH_OT_smart_align_to_vertex_normal(bpy.types.Operator):
    bl_idname = "mesh.smart_align_to_vertex_normal"
    bl_label = "Smart Align To Vertex Normal"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class MESH_OT_smart_island_move(bpy.types.Operator):
    bl_idname = "mesh.smart_island_move"
    bl_label = "Smart Island Move"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class MESH_OT_smart_island_rotate(bpy.types.Operator):
    bl_idname = "mesh.smart_island_rotate"
    bl_label = "Smart Island Rotate"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class MESH_OT_smart_island_scale(bpy.types.Operator):
    bl_idname = "mesh.smart_island_scale"
    bl_label = "Smart Island Scale"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class MESH_OT_smart_island_transform_toggle(bpy.types.Operator):
    bl_idname = "mesh.smart_island_transform_toggle"
    bl_label = "Smart Island Transform Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class MESH_OT_sts_island_transform_toggle(bpy.types.Operator):
    bl_idname = "mesh.sts_island_transform_toggle"
    bl_label = "Sts Island Transform Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class OBJECT_OT_quick_align_popup(bpy.types.Operator):
    bl_idname = "object.quick_align_popup"
    bl_label = "Quick Align Popup"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    draw = actions.draw_dialog
    check = actions.check
    cancel = actions.cancel

class OBJECT_OT_quick_align_reset_dialog(bpy.types.Operator):
    bl_idname = "object.quick_align_reset_dialog"
    bl_label = "Quick Align Reset Dialog"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class OBJECT_OT_quick_align_swap_refs(bpy.types.Operator):
    bl_idname = "object.quick_align_swap_refs"
    bl_label = "Quick Align Swap Refs"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class OBJECT_OT_quick_align_tool(bpy.types.Operator):
    bl_idname = "object.quick_align_tool"
    bl_label = "Quick Align Tool"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    draw = actions.draw_dialog
    check = actions.check
    cancel = actions.cancel

class OUTLINER_OT_quick_multi_edit_collection_add(bpy.types.Operator):
    bl_idname = "outliner.quick_multi_edit_collection_add"
    bl_label = "Quick Multi Edit Collection Add"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class OUTLINER_OT_quick_multi_edit_collection_remove(bpy.types.Operator):
    bl_idname = "outliner.quick_multi_edit_collection_remove"
    bl_label = "Quick Multi Edit Collection Remove"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class OUTLINER_OT_quick_multi_edit_collection_set(bpy.types.Operator):
    bl_idname = "outliner.quick_multi_edit_collection_set"
    bl_label = "Quick Multi Edit Collection Set"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class OUTLINER_OT_quick_multi_edit_from_collection(bpy.types.Operator):
    bl_idname = "outliner.quick_multi_edit_from_collection"
    bl_label = "Quick Multi Edit From Collection"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class SMART_TRANSFORM_SUITE_OT_open_help(bpy.types.Operator):
    bl_idname = "smart_transform_suite.open_help"
    bl_label = "Open Help"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class SMART_TRANSFORM_SUITE_OT_save_preferences(bpy.types.Operator):
    bl_idname = "smart_transform_suite.save_preferences"
    bl_label = "Save Preferences"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class SMART_TRANSFORM_SUITE_OT_set_always_on(bpy.types.Operator):
    bl_idname = "smart_transform_suite.set_always_on"
    bl_label = "Set Always On"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class SMART_TRANSFORM_SUITE_OT_toggle_persistent_feature(bpy.types.Operator):
    bl_idname = "smart_transform_suite.toggle_persistent_feature"
    bl_label = "Toggle Persistent Feature"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke

class TRANSFORM_OT_smart_grs_move(bpy.types.Operator):
    bl_idname = "transform.smart_grs_move"
    bl_label = "Smart Grs Move"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class TRANSFORM_OT_smart_grs_resize(bpy.types.Operator):
    bl_idname = "transform.smart_grs_resize"
    bl_label = "Smart Grs Resize"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class TRANSFORM_OT_smart_grs_rotate(bpy.types.Operator):
    bl_idname = "transform.smart_grs_rotate"
    bl_label = "Smart Grs Rotate"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class TRANSFORM_OT_smart_grs_scale(bpy.types.Operator):
    bl_idname = "transform.smart_grs_scale"
    bl_label = "Smart Grs Scale"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class TRANSFORM_OT_smart_grs_transform(bpy.types.Operator):
    bl_idname = "transform.smart_grs_transform"
    bl_label = "Smart Grs Transform"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class TRANSFORM_OT_smart_grs_translate(bpy.types.Operator):
    bl_idname = "transform.smart_grs_translate"
    bl_label = "Smart Grs Translate"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_click_select_drag(bpy.types.Operator):
    bl_idname = "view3d.csdt_click_select_drag"
    bl_label = "Csdt Click Select Drag"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_force(bpy.types.Operator):
    bl_idname = "view3d.csdt_force"
    bl_label = "Csdt Force"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_native_release_watch(bpy.types.Operator):
    bl_idname = "view3d.csdt_native_release_watch"
    bl_label = "Csdt Native Release Watch"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_reset_settings(bpy.types.Operator):
    bl_idname = "view3d.csdt_reset_settings"
    bl_label = "Csdt Reset Settings"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_single_select_no_drag(bpy.types.Operator):
    bl_idname = "view3d.csdt_single_select_no_drag"
    bl_label = "Csdt Single Select No Drag"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_smart_gizmo_watch(bpy.types.Operator):
    bl_idname = "view3d.csdt_smart_gizmo_watch"
    bl_label = "Csdt Smart Gizmo Watch"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_csdt_toggle_smart_gizmo(bpy.types.Operator):
    bl_idname = "view3d.csdt_toggle_smart_gizmo"
    bl_label = "Csdt Toggle Smart Gizmo"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_cycle_custom_select(bpy.types.Operator):
    bl_idname = "view3d.cycle_custom_select"
    bl_label = "Cycle Custom Select"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_proportional_size_cursor(bpy.types.Operator):
    bl_idname = "view3d.proportional_size_cursor"
    bl_label = "Proportional Size Cursor"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit"
    bl_label = "Quick Multi Edit"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_add(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_add"
    bl_label = "Quick Multi Edit Add"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_box(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_box"
    bl_label = "Quick Multi Edit Box"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_box_add(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_box_add"
    bl_label = "Quick Multi Edit Box Add"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_box_remove(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_box_remove"
    bl_label = "Quick Multi Edit Box Remove"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_box_toggle(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_box_toggle"
    bl_label = "Quick Multi Edit Box Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_collection_add(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_collection_add"
    bl_label = "Quick Multi Edit Collection Add"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_collection_remove(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_collection_remove"
    bl_label = "Quick Multi Edit Collection Remove"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_collection_set(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_collection_set"
    bl_label = "Quick Multi Edit Collection Set"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_collection_toggle(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_collection_toggle"
    bl_label = "Quick Multi Edit Collection Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_from_active_collection(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_from_active_collection"
    bl_label = "Quick Multi Edit From Active Collection"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_isolate(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_isolate"
    bl_label = "Quick Multi Edit Isolate"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_lasso(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_lasso"
    bl_label = "Quick Multi Edit Lasso"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_lasso_add(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_lasso_add"
    bl_label = "Quick Multi Edit Lasso Add"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_lasso_remove(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_lasso_remove"
    bl_label = "Quick Multi Edit Lasso Remove"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_lasso_toggle(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_lasso_toggle"
    bl_label = "Quick Multi Edit Lasso Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_remove(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_remove"
    bl_label = "Quick Multi Edit Remove"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_restore_previous(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_restore_previous"
    bl_label = "Quick Multi Edit Restore Previous"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_quick_multi_edit_toggle(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_toggle"
    bl_label = "Quick Multi Edit Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_select_guard_modal(bpy.types.Operator):
    bl_idname = "view3d.select_guard_modal"
    bl_label = "Select Guard Modal"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_select_guard_toggle(bpy.types.Operator):
    bl_idname = "view3d.select_guard_toggle"
    bl_label = "Select Guard Toggle"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_ssg_apply_prefs_to_scene(bpy.types.Operator):
    bl_idname = "view3d.ssg_apply_prefs_to_scene"
    bl_label = "Ssg Apply Prefs To Scene"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_ssg_clear_hold_enable_key_shortcut(bpy.types.Operator):
    bl_idname = "view3d.ssg_clear_hold_enable_key_shortcut"
    bl_label = "Ssg Clear Hold Enable Key Shortcut"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_ssg_hold_enable_key(bpy.types.Operator):
    bl_idname = "view3d.ssg_hold_enable_key"
    bl_label = "Ssg Hold Enable Key"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_ssg_select_box_public(bpy.types.Operator):
    bl_idname = "view3d.ssg_select_box_public"
    bl_label = "Ssg Select Box Public"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_ssg_toggle_occluder_ignore_selected(bpy.types.Operator):
    bl_idname = "view3d.ssg_toggle_occluder_ignore_selected"
    bl_label = "Ssg Toggle Occluder Ignore Selected"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_sts_csdt_force(bpy.types.Operator):
    bl_idname = "view3d.sts_csdt_force"
    bl_label = "Sts Csdt Force"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class VIEW3D_OT_sts_toggle_cursor_lock(bpy.types.Operator):
    bl_idname = "view3d.sts_toggle_cursor_lock"
    bl_label = "Sts Toggle Cursor Lock"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

    @classmethod
    def poll(cls, context):
        return context.window_manager.smart_transform_suite_runtime_preferences.enable_cursor_lock_feature

class WM_OT_core(bpy.types.Operator):
    bl_idname = "wm.core"
    bl_label = "Core"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class WM_OT_smart_transform_precision_numeric_drag(bpy.types.Operator):
    bl_idname = "wm.smart_transform_precision_numeric_drag"
    bl_label = "Smart Transform Precision Numeric Drag"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

class WM_OT_sts_crossing_select_watch(bpy.types.Operator):
    bl_idname = "wm.sts_crossing_select_watch"
    bl_label = "Sts Crossing Select Watch"
    bl_options = {"REGISTER","UNDO"}
    __annotations__ = schema.operator_arguments(bl_idname)
    execute = actions.execute
    invoke = actions.invoke
    modal = actions.modal
    cancel = actions.cancel

CLASSES = (
    CORE_OT_apply_all,
    CORE_OT_apply_rs,
    CORE_OT_copy,
    CORE_OT_cursor_to_selection_button,
    CORE_OT_paste,
    CORE_OT_reset_value,
    CORE_OT_snap,
    CORE_OT_snap_to_active_button,
    CORE_OT_snap_to_cursor_button,
    CORE_OT_snap_to_floor_button,
    CORE_SUITE_OT_copy_text,
    CORE_SUITE_OT_help_popup_dialog,
    CORE_SUITE_OT_lazy_execute_operator,
    CORE_SUITE_OT_show_tool_help,
    CORE_SUITE_OT_toggle_always_on_property,
    CORE_SUITE_OT_toggle_npanel_foldout,
    MESH_OT_smart_align_to_vertex_normal,
    MESH_OT_smart_island_move,
    MESH_OT_smart_island_rotate,
    MESH_OT_smart_island_scale,
    MESH_OT_smart_island_transform_toggle,
    MESH_OT_sts_island_transform_toggle,
    OBJECT_OT_quick_align_popup,
    OBJECT_OT_quick_align_reset_dialog,
    OBJECT_OT_quick_align_swap_refs,
    OBJECT_OT_quick_align_tool,
    OUTLINER_OT_quick_multi_edit_collection_add,
    OUTLINER_OT_quick_multi_edit_collection_remove,
    OUTLINER_OT_quick_multi_edit_collection_set,
    OUTLINER_OT_quick_multi_edit_from_collection,
    SMART_TRANSFORM_SUITE_OT_open_help,
    SMART_TRANSFORM_SUITE_OT_save_preferences,
    SMART_TRANSFORM_SUITE_OT_set_always_on,
    SMART_TRANSFORM_SUITE_OT_toggle_persistent_feature,
    TRANSFORM_OT_smart_grs_move,
    TRANSFORM_OT_smart_grs_resize,
    TRANSFORM_OT_smart_grs_rotate,
    TRANSFORM_OT_smart_grs_scale,
    TRANSFORM_OT_smart_grs_transform,
    TRANSFORM_OT_smart_grs_translate,
    VIEW3D_OT_csdt_click_select_drag,
    VIEW3D_OT_csdt_force,
    VIEW3D_OT_csdt_native_release_watch,
    VIEW3D_OT_csdt_reset_settings,
    VIEW3D_OT_csdt_single_select_no_drag,
    VIEW3D_OT_csdt_smart_gizmo_watch,
    VIEW3D_OT_csdt_toggle_smart_gizmo,
    VIEW3D_OT_cycle_custom_select,
    VIEW3D_OT_proportional_size_cursor,
    VIEW3D_OT_quick_multi_edit,
    VIEW3D_OT_quick_multi_edit_add,
    VIEW3D_OT_quick_multi_edit_box,
    VIEW3D_OT_quick_multi_edit_box_add,
    VIEW3D_OT_quick_multi_edit_box_remove,
    VIEW3D_OT_quick_multi_edit_box_toggle,
    VIEW3D_OT_quick_multi_edit_collection_add,
    VIEW3D_OT_quick_multi_edit_collection_remove,
    VIEW3D_OT_quick_multi_edit_collection_set,
    VIEW3D_OT_quick_multi_edit_collection_toggle,
    VIEW3D_OT_quick_multi_edit_from_active_collection,
    VIEW3D_OT_quick_multi_edit_isolate,
    VIEW3D_OT_quick_multi_edit_lasso,
    VIEW3D_OT_quick_multi_edit_lasso_add,
    VIEW3D_OT_quick_multi_edit_lasso_remove,
    VIEW3D_OT_quick_multi_edit_lasso_toggle,
    VIEW3D_OT_quick_multi_edit_remove,
    VIEW3D_OT_quick_multi_edit_restore_previous,
    VIEW3D_OT_quick_multi_edit_toggle,
    VIEW3D_OT_select_guard_modal,
    VIEW3D_OT_select_guard_toggle,
    VIEW3D_OT_ssg_apply_prefs_to_scene,
    VIEW3D_OT_ssg_clear_hold_enable_key_shortcut,
    VIEW3D_OT_ssg_hold_enable_key,
    VIEW3D_OT_ssg_select_box_public,
    VIEW3D_OT_ssg_toggle_occluder_ignore_selected,
    VIEW3D_OT_sts_csdt_force,
    VIEW3D_OT_sts_toggle_cursor_lock,
    WM_OT_core,
    WM_OT_smart_transform_precision_numeric_drag,
    WM_OT_sts_crossing_select_watch,
)
