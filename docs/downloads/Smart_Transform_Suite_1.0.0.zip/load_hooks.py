# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

"""One shared handler per file-event list for the whole suite.

Every module that needs to react to load_pre / load_post / save_pre registers
its callback here with add(); a single handler per list in bpy.app.handlers
dispatches them in the order they were added.
"""

import bpy
from bpy.app.handlers import persistent

_KINDS = ('load_pre', 'load_post', 'save_pre')
_CALLBACKS = {k: [] for k in _KINDS}
_WARNED = set()


def _warn_once(key, detail=''):
    if key not in _WARNED:
        _WARNED.add(key)
        print('[Smart Transform Suite] %s: %s' % (key, detail))


def _dispatch(kind, dummy):
    for fn in list(_CALLBACKS[kind]):
        try:
            fn(dummy)
        except Exception as ex:
            _warn_once('%s %s' % (kind, getattr(fn, '__name__', '?')), ex)


@persistent
def _sts_load_pre(dummy=None):
    _dispatch('load_pre', dummy)


@persistent
def _sts_load_post(dummy=None):
    _dispatch('load_post', dummy)


@persistent
def _sts_save_pre(dummy=None):
    _dispatch('save_pre', dummy)


_DISPATCHERS = {'load_pre': _sts_load_pre, 'load_post': _sts_load_post, 'save_pre': _sts_save_pre}


def _ensure_dispatcher(kind):
    handlers = getattr(bpy.app.handlers, kind)
    mine = _DISPATCHERS[kind]
    for fn in list(handlers):
        if getattr(fn, '__name__', '') == mine.__name__ and fn is not mine:
            handlers.remove(fn)
    if mine not in handlers:
        handlers.append(mine)


def add(fn, kind='load_post'):
    """Register fn(dummy) to run on the given file event (default: after load)."""
    lst = _CALLBACKS[kind]
    for old in list(lst):
        if getattr(old, '__name__', '') == getattr(fn, '__name__', None) and old is not fn:
            lst.remove(old)
    if fn not in lst:
        lst.append(fn)
    _ensure_dispatcher(kind)


def remove(fn, kind='load_post'):
    lst = _CALLBACKS[kind]
    while fn in lst:
        lst.remove(fn)
    if not lst:
        handlers = getattr(bpy.app.handlers, kind)
        mine = _DISPATCHERS[kind]
        while mine in handlers:
            handlers.remove(mine)
