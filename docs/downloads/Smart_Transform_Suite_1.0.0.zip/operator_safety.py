# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

from __future__ import annotations

from functools import lru_cache
from typing import Any

try:
    import bpy  # type: ignore
except Exception:  # pragma: no cover - Blender runtime only
    bpy = None


def _clean_idname(operator_id: object) -> str:
    return str(operator_id or '').strip()


def operator_rna_type(operator_id: object):
    """Return the registered operator RNA type, or None when unavailable.

    Accessing ``bpy.ops.<namespace>.<name>`` alone is not a reliable existence
    check in all Blender versions.  ``get_rna_type()`` is the authoritative
    test and does not write to ``OperatorProperties``, so it cannot emit
    ``property ... not found`` warnings.
    """
    if bpy is None:
        return None
    idname = _clean_idname(operator_id)
    if not idname or '.' not in idname:
        return None
    namespace, op_name = idname.split('.', 1)
    if not namespace or not op_name:
        return None
    try:
        ops_namespace = getattr(bpy.ops, namespace)
        op_callable = getattr(ops_namespace, op_name)
        get_rna_type = getattr(op_callable, 'get_rna_type', None)
        if callable(get_rna_type):
            return get_rna_type()
    except Exception:
        return None
    return None


def operator_exists(operator_id: object) -> bool:
    return operator_rna_type(operator_id) is not None


def _rna_has_property(rna: Any, prop_name: str) -> bool:
    name = str(prop_name or '').strip()
    if not name or rna is None:
        return False
    try:
        props = getattr(rna, 'properties', None)
    except Exception:
        props = None
    if props is None:
        return False
    try:
        if name in props.keys():
            return True
    except Exception:
        pass
    try:
        if props.get(name) is not None:
            return True
    except Exception:
        pass
    try:
        for prop in props:
            if str(getattr(prop, 'identifier', '') or '') == name:
                return True
    except Exception:
        pass
    return False


def operator_id_has_property(operator_id: object, prop_name: str) -> bool:
    return _rna_has_property(operator_rna_type(operator_id), prop_name)


def operator_proxy_has_property(op: Any, prop_name: str) -> bool:
    name = str(prop_name or '').strip()
    if not name or op is None:
        return False
    for owner_name in ('bl_rna', 'rna_type'):
        try:
            if _rna_has_property(getattr(op, owner_name, None), name):
                return True
        except Exception:
            pass
    return False


def safe_set_operator_property(op: Any, prop_name: str, value: Any, *, operator_id: object | None = None, strict: bool = True) -> bool:
    """Set a UI operator-button property without console warnings.

    Blender prints ``Warning: property 'x' not found in item 'OperatorProperties'``
    at the native setter before Python can catch the failure.  Therefore this
    function performs an RNA check against the registered operator id first.
    If the property is not declared, it does not call ``setattr`` at all.
    """
    if op is None:
        return False
    name = str(prop_name or '').strip()
    if not name:
        return False
    if strict:
        if operator_id is not None:
            if not operator_id_has_property(operator_id, name):
                return False
        elif not operator_proxy_has_property(op, name):
            return False
    try:
        setattr(op, name, value)
        return True
    except Exception:
        return False


def safe_set_keymap_item_property(kmi: Any, prop_name: str, value: Any, *, operator_id: object | None = None) -> bool:
    # Do not read or write KeyMapItem.properties from generic safety helpers.
    # In Blender 5.1, stale keymap operator-property wrappers can emit native
    # warnings or crash during startup.  Tool-owned keymap creation should pass
    # supported arguments directly to keymap_items.new instead.
    del kmi, prop_name, value, operator_id
    return False


def valid_operator_property_names(operator_id: object) -> set[str]:
    rna = operator_rna_type(operator_id)
    names: set[str] = set()
    if rna is None:
        return names
    try:
        props = getattr(rna, 'properties', None)
        for prop in props or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if ident and ident != 'rna_type' and not bool(getattr(prop, 'is_readonly', False)):
                names.add(ident)
    except Exception:
        pass
    return names


# -----------------------------------------------------------------------------
# Modal / operator exception guard
# -----------------------------------------------------------------------------
# Blender 5.1/Python 3.13 crash logs show native crashes while Blender is trying
# to print an exception from an operator modal callback.  The add-on must not let
# any owned operator exception escape into rna_operator_modal_cb.

def _operator_guard_result(method_name: str):
    if method_name == 'modal':
        return {'CANCELLED'}
    if method_name in {'invoke', 'execute'}:
        return {'CANCELLED'}
    return None


def _cleanup_operator_instance(op) -> None:
    for name in ('_finish_cleanup', 'finish_cleanup', '_cleanup', 'cleanup', '_remove_draw_handler'):
        try:
            fn = getattr(op, name, None)
        except Exception:
            fn = None
        if callable(fn):
            try:
                fn()
            except Exception:
                pass


def _make_guarded_operator_method(raw, method_name: str):
    """Return a Blender-registerable operator wrapper with the exact signature.

    Blender validates Operator method signatures at register_class time.  Generic
    ``*args`` wrappers are rejected as ``found 1`` for execute/invoke/modal, so
    each wrapper must expose the canonical signature Blender expects.
    """
    if method_name == 'execute':
        def _sts_guarded_execute(self, context, __raw=raw):
            try:
                return __raw(self, context)
            except Exception as ex:
                _cleanup_operator_instance(self)
                _report_guarded_exception(self, method_name, ex)
                return {'CANCELLED'}
        wrapper = _sts_guarded_execute
    elif method_name == 'invoke':
        def _sts_guarded_invoke(self, context, event, __raw=raw):
            try:
                return __raw(self, context, event)
            except Exception as ex:
                _cleanup_operator_instance(self)
                _report_guarded_exception(self, method_name, ex)
                return {'CANCELLED'}
        wrapper = _sts_guarded_invoke
    elif method_name == 'modal':
        def _sts_guarded_modal(self, context, event, __raw=raw):
            try:
                return __raw(self, context, event)
            except Exception as ex:
                _cleanup_operator_instance(self)
                _report_guarded_exception(self, method_name, ex)
                return {'CANCELLED'}
        wrapper = _sts_guarded_modal
    else:
        return None
    try:
        wrapper.__name__ = str(getattr(raw, '__name__', method_name) or method_name)
        wrapper.__qualname__ = str(getattr(raw, '__qualname__', wrapper.__name__) or wrapper.__name__)
        wrapper.__doc__ = getattr(raw, '__doc__', None)
        setattr(wrapper, '_sts_exception_guard', True)
        setattr(wrapper, '_sts_original_method', raw)
        setattr(wrapper, '_sts_guard_signature_v2', True)
    except Exception:
        pass
    return wrapper


def _guarded_error_message() -> str:
    from .translation import TI
    return TI(
        'Smart Transform operator error was caught safely; operation cancelled to avoid Blender crash.',
        'Smart Transform の操作でエラーが起きたため、Blender を守るために操作を取り消しました。',
    )


def _report_guarded_exception(self, method_name: str, ex: Exception) -> None:
    try:
        report = getattr(self, 'report', None)
        if callable(report):
            report({'ERROR'}, _guarded_error_message())
    except Exception:
        pass
    try:
        print('[Smart Transform Suite] Operator exception guarded:', getattr(self, 'bl_idname', type(self).__name__), method_name, repr(ex))
    except Exception:
        pass


def _unwrap_guarded_method(raw):
    try:
        original = getattr(raw, '_sts_original_method', None)
    except Exception:
        original = None
    return original if callable(original) else raw


def restore_operator_class_method_signatures(cls) -> int:
    """Restore old generic guard wrappers before class registration.

    Older builds wrapped execute/invoke/modal with ``*args``.  Those classes can
    remain in sys.modules during Extension reinstall and then fail Blender's
    register_class signature check.  If a guarded wrapper contains the original
    method, restore it before registration.
    """
    changed = 0
    for method_name in ('execute', 'invoke', 'modal'):
        try:
            raw = cls.__dict__.get(method_name, None)
        except Exception:
            raw = None
        if not callable(raw):
            continue
        try:
            is_guard = bool(getattr(raw, '_sts_exception_guard', False))
            is_v2 = bool(getattr(raw, '_sts_guard_signature_v2', False))
        except Exception:
            is_guard = False
            is_v2 = False
        if is_guard and not is_v2:
            original = _unwrap_guarded_method(raw)
            if callable(original) and original is not raw:
                try:
                    setattr(cls, method_name, original)
                    changed += 1
                except Exception:
                    pass
    return changed


def _raw_operator_method_for_registration(cls, method_name: str):
    """Return the original callable, unwrapping older unsafe guards."""
    try:
        raw = cls.__dict__.get(method_name, None)
    except Exception:
        raw = None
    if raw is None:
        return None
    try:
        if getattr(raw, '_sts_exception_guard', False):
            original = getattr(raw, '_sts_original_method', None)
            if callable(original):
                raw = original
            else:
                return None
    except Exception:
        pass
    try:
        if isinstance(raw, (staticmethod, classmethod)):
            raw = raw.__func__
    except Exception:
        pass
    return raw if callable(raw) else None


def normalize_operator_methods_for_registration(cls) -> bool:
    """Restore real methods before bpy.utils.register_class validates arity."""
    changed = False
    for method_name in ('execute', 'invoke', 'modal'):
        raw = _raw_operator_method_for_registration(cls, method_name)
        if raw is None:
            continue
        try:
            current = cls.__dict__.get(method_name, None)
        except Exception:
            current = None
        if current is not raw:
            try:
                setattr(cls, method_name, raw)
                changed = True
            except Exception:
                pass
    return changed


def _guarded_report_and_cancel(self, method_name: str, ex: Exception):
    _cleanup_operator_instance(self)
    try:
        report = getattr(self, 'report', None)
        if callable(report):
            report({'ERROR'}, _guarded_error_message())
    except Exception:
        pass
    try:
        print('[Smart Transform Suite] Operator exception guarded:', getattr(self, 'bl_idname', type(self).__name__), method_name, repr(ex))
    except Exception:
        pass
    return _operator_guard_result(method_name) or {'CANCELLED'}


def _make_guarded_execute(raw):
    def _sts_guarded_execute(self, context):
        try:
            return raw(self, context)
        except Exception as ex:
            _cleanup_operator_instance(self)
            try:
                report = getattr(self, 'report', None)
                if callable(report):
                    report({'ERROR'}, _guarded_error_message())
            except Exception:
                pass
            try:
                print('[Smart Transform Suite] Operator exception guarded:', getattr(self, 'bl_idname', type(self).__name__), 'execute', repr(ex))
            except Exception:
                pass
            return _operator_guard_result('execute') or {'CANCELLED'}
    return _sts_guarded_execute


def _make_guarded_invoke(raw):
    def _sts_guarded_invoke(self, context, event):
        try:
            return raw(self, context, event)
        except Exception as ex:
            _cleanup_operator_instance(self)
            try:
                report = getattr(self, 'report', None)
                if callable(report):
                    report({'ERROR'}, _guarded_error_message())
            except Exception:
                pass
            try:
                print('[Smart Transform Suite] Operator exception guarded:', getattr(self, 'bl_idname', type(self).__name__), 'invoke', repr(ex))
            except Exception:
                pass
            return _operator_guard_result('invoke') or {'CANCELLED'}
    return _sts_guarded_invoke


def _make_guarded_modal(raw):
    def _sts_guarded_modal(self, context, event):
        try:
            return raw(self, context, event)
        except Exception as ex:
            _cleanup_operator_instance(self)
            try:
                report = getattr(self, 'report', None)
                if callable(report):
                    report({'ERROR'}, _guarded_error_message())
            except Exception:
                pass
            try:
                print('[Smart Transform Suite] Operator exception guarded:', getattr(self, 'bl_idname', type(self).__name__), 'modal', repr(ex))
            except Exception:
                pass
            return _operator_guard_result('modal') or {'CANCELLED'}
    return _sts_guarded_modal


def _unwrap_guarded_method(raw):
    try:
        original = getattr(raw, '_sts_original_method', None)
    except Exception:
        original = None
    if callable(original):
        return original
    return raw


def _mark_guarded_method(wrapper, raw, method_name: str):
    try:
        wrapper.__name__ = f'_sts_guarded_{method_name}'
        wrapper.__qualname__ = f'_sts_guarded_{method_name}'
    except Exception:
        pass
    try:
        setattr(wrapper, '_sts_exception_guard', True)
        setattr(wrapper, '_sts_exception_guard_version', 2)
        setattr(wrapper, '_sts_guard_signature_v2', True)
        setattr(wrapper, '_sts_original_method', raw)
    except Exception:
        pass
    return wrapper


def normalize_operator_class_for_registration(cls) -> bool:
    """Remove old varargs exception guards before Blender validates callbacks.

    Blender 5.1 validates Operator callback signatures at register_class time.
    Earlier Smart Transform builds wrapped execute/invoke/modal with *args; those
    wrappers can survive a failed reload and then Blender reports e.g. execute
    "found 1".  This restores the original callback before registration.  The
    current guard is re-installed after registration with exact Blender
    signatures.
    """
    changed = False
    for method_name in ('execute', 'invoke', 'modal'):
        try:
            raw = cls.__dict__.get(method_name, None)
        except Exception:
            raw = None
        if raw is None:
            continue
        try:
            original = getattr(raw, '_sts_original_method', None)
        except Exception:
            original = None
        if callable(original):
            try:
                setattr(cls, method_name, original)
                changed = True
            except Exception:
                pass
    return changed


def _wrap_operator_method(cls, method_name: str) -> bool:
    try:
        raw = cls.__dict__.get(method_name, None)
    except Exception:
        raw = None
    if raw is None:
        return False
    raw = _unwrap_guarded_method(raw)
    if not callable(raw):
        return False

    try:
        current = cls.__dict__.get(method_name, None)
        if getattr(current, '_sts_exception_guard', False) and getattr(current, '_sts_exception_guard_version', 0) == 2:
            return False
    except Exception:
        pass

    if method_name == 'execute':
        wrapper = _make_guarded_execute(raw)
    elif method_name == 'invoke':
        wrapper = _make_guarded_invoke(raw)
    elif method_name == 'modal':
        wrapper = _make_guarded_modal(raw)
    else:
        return False

    wrapper = _mark_guarded_method(wrapper, raw, method_name)
    try:
        setattr(cls, method_name, wrapper)
        return True
    except Exception:
        return False

def _class_belongs_to_package(cls, package_names: tuple[str, ...]) -> bool:
    try:
        module_name = str(getattr(cls, '__module__', '') or '')
    except Exception:
        module_name = ''
    if not module_name:
        return False
    return any(pkg and (module_name == pkg or module_name.startswith(pkg + '.')) for pkg in package_names)


def prepare_operator_class_for_registration(cls) -> bool:
    """Install exact-signature guards before Blender registers a class.

    The wrapper must be present before ``bpy.utils.register_class`` so Blender
    stores a stable callback.  Replacing modal/invoke/execute after registration
    can leave the native operator callback pointing at a stale Python function.
    """
    if bpy is None:
        return False
    try:
        if not isinstance(cls, type) or not issubclass(cls, bpy.types.Operator):
            return False
    except Exception:
        return False
    normalize_operator_class_for_registration(cls)
    normalize_operator_methods_for_registration(cls)
    changed = False
    for method_name in ('execute', 'invoke', 'modal'):
        if _wrap_operator_method(cls, method_name):
            changed = True
    return changed


def install_exception_guards_for_package(*package_names: str) -> int:
    """Compatibility no-op.

    Older builds patched already-registered Operator classes.  On Blender
    5.1/Python 3.13 that can corrupt modal callback ownership and crash in
    rna_operator_modal_cb.  Guards are now installed only by
    prepare_operator_class_for_registration() before class registration.
    """
    del package_names
    return 0
