"""World bounds alignment, live preview and edit-mode vertex normal alignment."""
import json
import bpy,bmesh
from mathutils import Vector,Matrix,Euler,Quaternion
from .transforms import apply_world,center

preview=None
followup=None

def continue_once(ctx):
    global followup
    if followup is not None:return
    win,area=ctx.window,ctx.area
    def reopen():
        global followup
        followup=None
        try:
            with bpy.context.temp_override(window=win,area=area,region=next(r for r in area.regions if r.type=="WINDOW")):
                if len(bpy.context.selected_objects)>1:bpy.ops.object.quick_align_popup("INVOKE_DEFAULT")
        except (RuntimeError,ReferenceError,StopIteration):pass
    followup=reopen
    bpy.app.timers.register(reopen,first_interval=.02)

def changed(ctx):
    if preview is None:return
    from .actions import restore_preview
    try:
        restore_preview(preview)
        align(preview,ctx)
        if ctx.area:ctx.area.tag_redraw()
    except (ReferenceError,ValueError,RuntimeError):
        pass

def named(scene,data):
    names=json.loads(data or "[]")
    if not isinstance(names,list):raise ValueError("Expected an array of object names")
    return [scene.objects[n] for n in names if isinstance(n,str) and scene.objects.get(n)]

def references(op,ctx):
    s=ctx.window_manager.quick_align_settings
    name=getattr(op,"target_name","")
    target=ctx.scene.objects.get(name) if name else None
    ordered=list(ctx.selected_objects)
    if target is None:target=ctx.active_object if s.target_endpoint_mode=="LAST" else next((o for o in ordered if o!=ctx.active_object),ctx.active_object)
    source=named(ctx.scene,getattr(op,"source_names_json","")) or ordered
    source=[o for o in source if o!=target and o.is_editable]
    if not target or not source:raise ValueError("Select source objects and an active target")
    return s,target,source

def coordinates(obj,matrix):
    pts=[matrix@Vector(c) for c in obj.bound_box] if obj.type not in {"EMPTY","CAMERA","LIGHT"} else [matrix.translation]
    return [(min(p[i] for p in pts),max(p[i] for p in pts)) for i in range(3)]

def anchor(pos,bounds,mode):
    low,high=bounds
    return {"MIN":low,"MAX":high,"CENTER":(low+high)/2,"PIVOT":pos}[mode]

def align(op,ctx):
    prefs,target,objects=references(op,ctx)
    dest=target.matrix_world.copy()
    target_pos,target_rot,target_scale=dest.decompose()
    target_bounds=coordinates(target,dest)
    if prefs.equal_align_enabled and len(objects)>1:
        all_objects=[*objects,target]
        a,b=objects[0],target
        if prefs.equal_align_use_farthest_pair:
            a,b=max(((x,y) for i,x in enumerate(all_objects) for y in all_objects[i+1:]),key=lambda pair:(pair[0].matrix_world.translation-pair[1].matrix_world.translation).length_squared)
        start,end=a.matrix_world.translation,b.matrix_world.translation
        axis=end-start
        ordered=sorted(all_objects,key=lambda o:(o.matrix_world.translation-start).dot(axis))
        for i,item in enumerate(ordered):
            mat=item.matrix_world.copy();p=start.lerp(end,i/(len(ordered)-1))
            for j,c in enumerate("xyz"):
                if getattr(prefs,"align_pos_"+c) and (not prefs.respect_locks or not item.lock_location[j]):mat[j][3]=p[j]
            apply_world(ctx,item,mat)
        ctx.view_layer.update();return
    for obj in objects:
        before=obj.matrix_world.copy()
        loc,rot,scale=before.decompose()
        rotation=rot.to_euler()
        target_euler=target_rot.to_euler(rotation.order,rotation)
        for i,c in enumerate("xyz"):
            if getattr(prefs,"align_ori_"+c) and (not prefs.respect_locks or not obj.lock_rotation[i]):rotation[i]=target_euler[i]
            if getattr(prefs,"align_scale_"+c) and (not prefs.respect_locks or not obj.lock_scale[i]):scale[i]=target_scale[i]
        if prefs.align_to_mode=="HIT" and prefs.normal_align:
            normal=Vector(json.loads(getattr(op,"hit_normal_json","") or prefs.hit_normal_json or "[0,0,1]"))
            if prefs.flip_normal:normal.negate()
            if normal.length_squared:
                axis=Vector((0,0,0));axis["XYZ".index(prefs.normal_axis)]=1.0
                normal.normalize()
                rotation=(rotation.to_quaternion()@axis).rotation_difference(normal)@rotation.to_quaternion()
                if prefs.twist_mode!="OFF":
                    tang=Vector((0,0,0));tang["XYZ".index(prefs.twist_tangent_axis)]=1
                    if abs(tang.dot(axis))>.99:tang=Vector((axis.z,axis.x,axis.y))
                    target_dir=Vector((0,0,0));target_dir["XYZ".index(prefs.target_tangent_axis)]=1
                    if prefs.twist_mode in {"TARGET","AUTO"}:target_dir=target_rot@target_dir
                    if prefs.twist_mode=="VIEW":
                        field="view_up_json" if prefs.view_tangent_axis=="UP" else "view_right_json"
                        target_dir=Vector(json.loads(getattr(prefs,field) or ("[0,1,0]" if field=="view_up_json" else "[1,0,0]")))
                    flat=target_dir-normal*normal.dot(target_dir)
                    if flat.length_squared>1e-10:
                        import math
                        old=rotation@tang;flat.normalize()
                        rotation=Quaternion(normal,math.atan2(normal.dot(old.cross(flat)),old.dot(flat)))@rotation
        shadow=Matrix.LocRotScale(loc,rotation,scale)
        bounds=coordinates(obj,shadow)
        hit_pos=Vector(json.loads(getattr(op,"hit_location_json","") or prefs.hit_location_json or "[0,0,0]"))
        for i,c in enumerate("xyz"):
            if not getattr(prefs,"align_pos_"+c) or (prefs.respect_locks and obj.lock_location[i]):continue
            start=anchor(loc[i],bounds[i],getattr(prefs,"source_align_"+c))
            end=hit_pos[i] if prefs.align_to_mode=="HIT" else anchor(target_pos[i],target_bounds[i],getattr(prefs,"target_align_"+c))
            shadow[i][3]+=end-start
        apply_world(ctx,obj,shadow)
    ctx.view_layer.update()

def swap(ctx):
    s=ctx.window_manager.quick_align_settings
    for c in "xyz":
        a,b="source_align_"+c,"target_align_"+c
        x,y=getattr(s,a),getattr(s,b);setattr(s,a,y);setattr(s,b,x)

def reset(ctx):
    s=ctx.window_manager.quick_align_settings
    for k in s.bl_rna.properties.keys():
        if k.startswith(("align_pos","align_ori","align_scale","source_align","target_align")) or k=="preset":s.property_unset(k)

def preset(s):
    if s.preset=="NONE":return
    a,b=s.preset.split("_")
    for c in "xyz":setattr(s,"source_align_"+c,a);setattr(s,"target_align_"+c,b)

def normal_align(ctx):
    obj=ctx.edit_object
    if not obj or obj.type!="MESH":raise ValueError("Select mesh vertices in Edit Mode")
    bm=bmesh.from_edit_mesh(obj.data);bm.normal_update()
    verts=[v for v in bm.verts if v.select and not v.hide]
    if not verts:raise ValueError("Select mesh vertices to align")
    start=obj.matrix_world.copy();origin=center([start@v.co for v in verts])
    normal_matrix=start.to_3x3().inverted_safe().transposed()
    normal=sum((normal_matrix@v.normal for v in verts),Vector((0,0,0)))
    if normal.length<=1e-9:raise ValueError("The selected normals cancel out")
    rot=normal.normalized().to_track_quat("Z","Y")
    prefs=ctx.window_manager.smart_transform_suite_runtime_preferences
    if prefs.normal_align_use_orientation:
        bpy.ops.transform.create_orientation(name="VertexNormal",use=True,overwrite=True)
        slot=ctx.scene.transform_orientation_slots[0]
        if slot.custom_orientation:slot.custom_orientation.matrix=rot.to_matrix()
    if prefs.normal_align_use_pivot:
        if obj.data.users>1:raise ValueError("Make the mesh single-user before changing its origin")
        target=Matrix.LocRotScale(origin,rot,start.to_scale())
        inverse=target.inverted_safe()@start
        for v in bm.verts:v.co=inverse@v.co
        obj.matrix_world=target
        bm.normal_update();bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
    ctx.view_layer.update()
