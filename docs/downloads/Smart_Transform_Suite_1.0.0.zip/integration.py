# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package


import sys

import bpy

from . import feature_toggle as _feature_toggle
from . import runtime as _runtime
from . import operator_safety as _operator_safety

# -----------------------------------------------------------------------------
# Smart Transform: integration toggles
# -----------------------------------------------------------------------------

_MODULE_SPECS = {
    "core_panel": ("core", "Smart Transform Panel"),
    "quick_align": ("quick_align", "Quick Align Tool"),
    "quick_multi_edit": ("quick_multi_edit", "Quick Multi-Edit"),
    "select_guard": ("select_guard", "Smart Select Guard"),
    "precision_length_drag": ("precision_length_drag", "Precision Numeric Drag"),
}

# Track what we've actually registered (so toggle spam is safe)
_registered = {k: False for k in _MODULE_SPECS.keys()}


_STS_WARNED_ONCE = set()


def _warn_once(key, detail=''):
    if key not in _STS_WARNED_ONCE:
        _STS_WARNED_ONCE.add(key)
        print('[Smart Transform Suite] %s: %s' % (key, detail))


def _suite_prefs(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None


def _module_full_name(rel_name: str) -> str:
    return f"{__package__}.{str(rel_name or '').strip()}"


def _module_is_loaded(rel_name: str) -> bool:
    full = _module_full_name(rel_name)
    return full in sys.modules or any(str(name).startswith(full + '.') for name in sys.modules.keys())


def _import_module(rel_name: str):
    return __import__(_module_full_name(rel_name), fromlist=["ensure_registered"])

def _operator_rna_type_name(cls) -> str:
    try:
        bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    except Exception:
        bl_idname = ''
    if not bl_idname or '.' not in bl_idname:
        return ''
    prefix, suffix = bl_idname.split('.', 1)
    prefix = prefix.strip().upper()
    suffix = suffix.strip()
    if not prefix or not suffix:
        return ''
    return f"{prefix}_OT_{suffix}"


def _module_registration_state(mod) -> tuple[bool, bool]:
    """Return (current_registered, stale_name_registered).

    Blender stores registered Operator classes under RNA names such as
    WM_OT_example rather than the Python class name, while Panels and
    PropertyGroups keep their class names.  Check both forms so optional modules
    with only operators are not repeatedly treated as unregistered.
    """
    current_registered = False
    stale_registered = False
    classes = getattr(mod, "classes", ()) or ()
    for cls in classes:
        try:
            candidate_names = []
            py_name = str(getattr(cls, "__name__", "") or "")
            if py_name:
                candidate_names.append(py_name)
            rna_name = _operator_rna_type_name(cls)
            if rna_name and rna_name not in candidate_names:
                candidate_names.append(rna_name)
            target = None
            for name in candidate_names:
                target = getattr(bpy.types, name, None)
                if isinstance(target, type):
                    break
            if not isinstance(target, type):
                continue
            if target is cls:
                current_registered = True
            else:
                stale_registered = True
        except Exception:
            continue
    return current_registered, stale_registered


def _module_looks_registered(mod) -> bool:
    current_registered, stale_registered = _module_registration_state(mod)
    return bool(current_registered or stale_registered)


def _unregister_registered_class_names(mod) -> None:
    """Remove same-name stale classes before registering the current module."""
    for cls in reversed(tuple(getattr(mod, "classes", ()) or ())) :
        try:
            name = str(getattr(cls, "__name__", "") or "")
            target = getattr(bpy.types, name, None) if name else None
        except Exception:
            target = None
        if not isinstance(target, type):
            continue
        try:
            bpy.utils.unregister_class(target)
        except Exception:
            pass


def _safe_module_unregister(mod):
    unreg = getattr(mod, "unregister", None)
    if not callable(unreg):
        return
    try:
        unreg()
    except Exception as ex:
        try:
            _warn_once('unregister ' + str(getattr(mod, '__name__', mod)), ex)
        except Exception:
            pass



def _install_owned_operator_guards() -> None:
    try:
        _operator_safety.install_exception_guards_for_package(__package__)
    except Exception:
        pass

def _sync_module_runtime_from_prefs(mod, context=None) -> None:
    try:
        sync = getattr(mod, "sync_runtime_from_prefs", None)
        if callable(sync):
            try:
                sync(context or getattr(bpy, 'context', None))
            except TypeError:
                sync(context or getattr(bpy, 'context', None), defer=True)
    except Exception:
        pass


def toggle(module_key: str, enable: bool, context=None):
    """Enable/disable one integrated tool at runtime.

    The Smart Transform panel module owns the standard VIEW_3D/UI host panel.
    It must stay registered even when its visible enable toggle is clicked from
    inside the N-panel; unregistering the active host panel can leave Blender
    with a stale native Panel callback during Sidebar redraw.  The preference is
    still displayed and stored, but this host module is kept registered.
    """
    if module_key not in _MODULE_SPECS:
        return

    rel_name, _label = _MODULE_SPECS[module_key]
    enable = bool(enable)

    if not enable and module_key != "core_panel" and not _registered.get(module_key, False) and not _module_is_loaded(rel_name):
        _registered[module_key] = False
        return

    mod = _import_module(rel_name)
    current_registered, stale_registered = _module_registration_state(mod)
    looks_registered = bool(current_registered or stale_registered)
    marked_registered = bool(_registered.get(module_key, False))

    if module_key == "core_panel":
        if stale_registered:
            _unregister_registered_class_names(mod)
            current_registered, stale_registered = _module_registration_state(mod)
        if not current_registered:
            with _feature_toggle.capture_runtime(module_key, _label):
                ensure_reg = getattr(mod, "ensure_registered", None)
                if callable(ensure_reg):
                    ensure_reg(True)
                else:
                    reg = getattr(mod, "register", None)
                    if callable(reg):
                        reg()
        try:
            setattr(mod, "__STS_REGISTERED", True)
        except Exception:
            pass
        _registered[module_key] = True
        _install_owned_operator_guards()
        _sync_module_runtime_from_prefs(mod, context)
        return

    if enable:
        if current_registered and not stale_registered:
            try:
                setattr(mod, "__STS_REGISTERED", True)
            except Exception:
                pass
            _registered[module_key] = True
            _install_owned_operator_guards()
            _sync_module_runtime_from_prefs(mod, context)
            return
        if stale_registered:
            _unregister_registered_class_names(mod)
            current_registered, stale_registered = _module_registration_state(mod)
            looks_registered = bool(current_registered or stale_registered)
        if marked_registered and looks_registered:
            _sync_module_runtime_from_prefs(mod, context)
            return
        try:
            # Some modules keep an internal __STS_REGISTERED flag.  If Blender's
            # actual RNA/operator classes are not present, force that guard back
            # to False so ensure_registered() cannot skip a required registration
            # after an install, reload, or stale module cleanup pass.
            if not looks_registered:
                try:
                    setattr(mod, "__STS_REGISTERED", False)
                except Exception:
                    pass
            with _feature_toggle.capture_runtime(module_key, _label):
                ensure_reg = getattr(mod, "ensure_registered", None)
                if callable(ensure_reg):
                    ensure_reg(True)
                else:
                    reg = getattr(mod, "register", None)
                    if callable(reg):
                        reg()
            try:
                setattr(mod, "__STS_REGISTERED", True)
            except Exception:
                pass
            _registered[module_key] = True
            _install_owned_operator_guards()
            _sync_module_runtime_from_prefs(mod, context)
        except Exception:
            _registered[module_key] = False
            raise
        return

    try:
        if marked_registered or looks_registered:
            ensure_reg = getattr(mod, "ensure_registered", None)
            if callable(ensure_reg):
                try:
                    ensure_reg(False)
                except Exception:
                    _safe_module_unregister(mod)
            else:
                _safe_module_unregister(mod)
            try:
                setattr(mod, "__STS_REGISTERED", False)
            except Exception:
                pass
    finally:
        _registered[module_key] = False

def apply_from_prefs(context=None):
    """Apply all toggle prefs (call once after addon register).

    IMPORTANT: do not abort if one module fails. This keeps UV tools etc usable even if
    an optional integrated tool errors in its own register().
    """
    prefs = _suite_prefs(context)
    # Keep the host Smart Transform panel and every visible Other Tools module
    # registered. Their optional keymaps/runtime monitors remain controlled by
    # each module's own preferences, but N-panel buttons and copied operator IDs
    # must not point at unregistered operators after a fresh Blender start.
    quick_multi_edit_active = True
    select_guard_active = True

    specs = [
        ("core_panel", True),
        ("quick_align", True),
        ("quick_multi_edit", quick_multi_edit_active),
        ("select_guard", select_guard_active),
        ("precision_length_drag", True),
    ]
    for key, enabled in specs:
        try:
            toggle(key, enabled, context)
        except Exception as ex:
            # Keep going; print for debugging in Blender console.
            try:
                _warn_once("toggle " + str(key), ex)
            except Exception:
                pass

def unregister_all():
    # Disable all, ignore errors on shutdown.
    for k, (rel_name, _label) in list(_MODULE_SPECS.items()):
        try:
            if not _registered.get(k, False) and not _module_is_loaded(rel_name):
                continue
            mod = _import_module(rel_name)
            if _module_looks_registered(mod) or _registered.get(k, False):
                _safe_module_unregister(mod)
        except Exception:
            pass
        finally:
            # Integration historically stamped this compatibility flag after
            # registration.  Some module unregister() functions own a different
            # native-state flag, so clear the stamped value here at the same
            # boundary that clears the integration ledger.
            try:
                setattr(mod, "__STS_REGISTERED", False)
            except Exception:
                pass
            _registered[k] = False
