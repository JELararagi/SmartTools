# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy

from .. import runtime as _runtime
from .. import ui_icons as _ui_icons
from .. import operator_safety as _op_safety
from .. import load_hooks as _load_hooks
try:
    from .. import settings as _settings
except Exception:
    _settings = None
import webbrowser
import bmesh
import time
from mathutils import Vector
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils
from bpy.app.translations import pgettext_iface as iface_



_STS_WARNED_ONCE = set()


def _warn_once(key, detail=''):
    if key not in _STS_WARNED_ONCE:
        _STS_WARNED_ONCE.add(key)
        print('[Smart Transform Suite] %s: %s' % (key, detail))


def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}




def _ui_label_kwargs(icon: str = 'NONE', custom_icon: str = ''):
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _draw_icon_label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> bool:
    try:
        layout.label(text=str(text or ''), **_ui_label_kwargs(icon, custom_icon))
        return True
    except TypeError:
        try:
            layout.label(text=str(text or ''), icon=icon or 'NONE')
            return True
        except Exception:
            return False
    except Exception:
        return False

def _operator(layout, operator_id: str, *, text: str = '', icon: str = 'NONE', custom_icon: str = '', emboss: bool | None = None, depress: bool = False, **props):
    icon_only = not str(text or '').strip()
    if emboss is None:
        emboss = True
    elif icon_only and emboss is False:
        emboss = True
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props)
    try:
        op = layout.operator(operator_id, text=text, emboss=emboss, depress=bool(depress), **icon_args)
    except TypeError:
        try:
            op = layout.operator(operator_id, text=text, icon=icon, emboss=emboss, depress=bool(depress))
        except TypeError:
            op = layout.operator(operator_id, text=text, icon=icon)
    for k, v in props.items():
        try:
            _op_safety.safe_set_operator_property(op, k, v, operator_id=operator_id, strict=True)
        except Exception:
            pass
    return op

bl_info = {
    "name": "Smart Select Guard",
    "author": "Smart Transform Suite",
    "version": (1, 8, 167),
    "blender": (5, 1, 0),
    "location": "3D View Header (Menus)",
    "description": "Tool to prevent selecting occluded elements in Object/Edit mode.",
    "category": "3D View",
}

# =========================================================
# i18n
# =========================================================

_translations = {
    "ja_JP": {
        ("*", "Smart Select Guard"): "スマート選択ガード",
        ("*", "Smart Select Guard settings are edited from the Smart Transform N-panel."): "スマート選択ガード の設定は Smart Transform Nパネルで編集します。",
        ("*", "Open 3D View > Sidebar (N) > Smart Transform > Smart Select Guard."): "3Dビュー > サイドバー（N）> Smart Transform > スマート選択ガード を開いてください。",
        ("*", "Prevent selecting occluded elements in Object/Edit mode"): "オブジェクト/編集モードで遮蔽要素の選択を防ぎます",
        ("*", "Enable Smart Select Guard"): "スマート選択ガード 有効",
        ("*", "Enable / disable the Smart Select Guard"): "スマート選択ガード を有効/無効にします",
        ("*", "Enable Other Objects Occlusion"): "他オブジェクトの遮蔽を有効",
        ("*", "In Edit Mode, treat occlusion by objects other than the edited object(s) as occlusion. Disable to ignore other objects when judging occlusion."):
            "編集モード中、編集中オブジェクト以外のオブジェクトによる遮蔽を遮蔽扱いにします。OFFで他オブジェクトを遮蔽判定から除外します。",
        ("*", "Enable Mutual Occlusion for Multi-Edit"): "複数編集の相互遮蔽を有効",
        ("*", "When multiple objects are selected/edited, decide whether selected objects can occlude each other. Disable to judge occlusion per-object (ignore other selected/edited objects)."):
            "複数オブジェクト選択/複数編集時、選択/編集オブジェクト同士の遮蔽を遮蔽扱いにするか切り替えます。OFFで個別判定（他の選択/編集オブジェクトを無視）になります。",
        ("*", "Enable Click Select Filtering"): "クリック選択でも有効",
        ("*", "Apply occlusion filtering after click selection (single click). Disable to only affect box/circle/lasso or drag selections."):
            "クリック選択（単発クリック）でも遮蔽フィルタを適用します。OFFでボックス/サークル/投げ縄/ドラッグ選択のみ対象にします。",
        ("*", "Selection Guard: removed O{obj} V{v} E{e} F{f}"): "選択ガード：除外 物{obj} 頂点{v} 辺{e} 面{f}",
        ("*", "Smart Select Guard Settings"): "スマート選択ガード 設定",
        ("*", "Shortcut Toggle Operator ID"): "ショートカット登録用オペレーターID",
        ("*", "Copy this ID and assign a shortcut in Preferences > Keymap."):
            "このIDをコピーして、プリファレンス > キーマップ でショートカット登録してください。",
        ("*", "How to assign shortcut (details)"): "ショートカット登録方法（詳細）",
        ("*", "1) Edit > Preferences > Keymap"): "1) 編集 > プリファレンス > キーマップ",
        ("*", "2) Paste the operator ID into the search box"): "2) 検索欄にオペレーターIDを貼り付けて検索",
        ("*", "3) Under 3D View (Global), click 'Add New' and assign a key"): "3) 3Dビュー（グローバル）等で「新規追加」→キー割当",
        ("*", "4) Confirm it toggles the guard"): "4) 切替が切り替わることを確認",
        ("*", "Tip: You can bind it separately for Object Mode and Edit Mode."):
            "補足：必要に応じてオブジェクトモード用/編集モード用に別々の割当も可能です。",

        # --- bl_info description ---
        ("*", "Tool to prevent selecting occluded elements in Object/Edit mode."):
            "オブジェクト/編集モードで遮蔽された要素を選択できないようにするツール",


        ("*", "Basic Settings"): "基本設定",
        ("*", "Selection Behavior"): "選択動作",
        ("*", "Always Active"): "常に有効",
        ("*", "Enable Only While Specified Key Is Held"): "指定キーを押している間だけ有効",
        ("*", "Specified Enable Key"): "有効化する指定キー",
        ("*", "Do not require a hold key. Smart Select Guard works whenever its main toggle is ON."): "指定キーを要求しません。スマート選択ガード の主スイッチがONの間は常に機能します。",
        ("*", "Smart Select Guard works only while this non-modifier key is being held during a selection operation. Use this instead of Shift/Ctrl/Alt to avoid conflicts with Blender's standard modifier behavior."): "選択操作中に、この非装飾キーを押している間だけ スマート選択ガード を有効にします。Blender標準の Shift/Ctrl/Alt 操作と競合しないよう、装飾キーではなく指定キーを使います。",
        ("*", "Enable-While-Held Shortcut"): "有効キー",
        ("*", "Assign Hold Key Shortcut"): "キー割当",
        ("*", "Right-click this button and use Assign Shortcut to choose any key. When a shortcut is assigned, Smart Select Guard works only while that key is held during selection. If no shortcut is assigned, Smart Select Guard stays always active while its main toggle is ON."): "このボタンを右クリックし、「ショートカットを割り当て」で任意のキーを指定します。ショートカットが割り当てられている場合、選択操作中にそのキーを押している間だけスマート選択ガードが有効になります。割り当てが無い場合は、主スイッチがONの間は常時有効です。",
        ("*", "Assigned Key"): "キー",
        ("*", "None - always active"): "常時有効",
        ("*", "Clear Hold Key Shortcut"): "解除",
        ("*", "Right-click to assign a key. No key means always active."): "右クリックでキー割当。未割当は常時有効。",
        ("*", "Remove Smart Select Guard enable-while-held shortcut assignments and return to always-active behavior."): "スマート選択ガードの押している間だけ有効ショートカット割り当てを解除し、常時有効の挙動に戻します。",
        ("*", "Always"): "常時",
        ("*", "Q Key"): "Qキー",
        ("*", "W Key"): "Wキー",
        ("*", "E Key"): "Eキー",
        ("*", "D Key"): "Dキー",
        ("*", "F Key"): "Fキー",
        ("*", "V Key"): "Vキー",
        ("*", "X Key"): "Xキー",
        ("*", "Z Key"): "Zキー",
        ("*", "Tab Key"): "Tabキー",
        ("*", "Space Key"): "スペースキー",
        ("*", "Accent Key"): "アクセントキー",
        # --- New UI ---
        ("*", "Quality Preset"): "品質プリセット",
        ("*", "Fast"): "高速",
        ("*", "Balanced"): "標準",
        ("*", "Precise"): "高精度",
        ("*", "Custom"): "カスタム",
        ("*", "View Scope"): "ビュー範囲",
        ("*", "Active View Only"): "アクティブビューのみ",
        ("*", "All 3D Views"): "全3Dビュー",
        ("*", "Auto Bypass in X-Ray"): "透過表示時は自動無効",
        ("*", "Select Through when X-Ray Off"): "透過表示OFF時も背面選択",
        ("*", "When the viewport X-Ray display is off, temporarily enable X-Ray from the moment a selection drag starts (circle select: from the press) so back-side and occluded mesh elements can be selected, then restore the original X-Ray state after the button is released and the selection is confirmed, even when nothing was selected. A plain click (except with circle select) and Transform/tweak operations do not start this temporary X-Ray state."):
            "ビューの透過表示がOFFの時、選択ドラッグを始めた時点（サークル選択は押した時点）から一時的に透過表示をONにして背面や遮蔽されたメッシュ要素を選択可能にし、ボタンを離して選択が確定した後（無選択の場合も含む）に元の透過表示状態へ戻します。クリックだけの選択（サークル選択を除く）とトランスフォーム/トゥイーク操作では一時透過表示を開始しません。",
        ("*", "Auto Bypass in Wireframe"): "ワイヤー時は自動無効",
        ("*", "Ignore Backfacing Occluders"): "背面の遮蔽物を無視",
        ("*", "Hold-to-Bypass Key"): "押している間だけ無効",
        ("*", "Enable-While-Held Key"): "押している間だけ有効",
        ("*", "None"): "なし",
        ("*", "Shift"): "Shift",
        ("*", "Ctrl"): "Ctrl",
        ("*", "Alt"): "Alt",
        ("*", "Show Status Feedback"): "ステータス表示",
        ("*", "Occluder Exclude Collection"): "遮蔽物から除外するコレクション",
        ("*", "Toggle Occluder Ignore (Selected)"): "遮蔽物無視を切替（選択）",
        ("*", "Apply Preferences Defaults to Scene"): "プリファレンス既定値をシーンへ適用",
        ("*", "Advanced Settings"): "詳細設定",
        ("*", "Custom Parameters (Preset=Custom)"): "カスタム項目（プリセットがカスタムの時のみ編集可）",
        ("*", "Custom Defaults (Preset=Custom)"): "カスタム既定値（プリセットがカスタムの時のみ編集可）",
        ("*", "Children"): "子",
        ("*", "Objects"): "オブジェクト",
        ("*", "Objects in this collection and its child collections will be ignored as occluders."):
            "このコレクションと子コレクション内のオブジェクトは遮蔽物として無視されます。",
        ("*", "Max Ray Steps"): "最大レイ反復回数",
        ("*", "Vertex Screen Samples"): "頂点スクリーンサンプル数",
        ("*", "Vertex Sample Radius (px)"): "頂点サンプル半径(px)",
        ("*", "Edge Sample Count"): "辺サンプル数",
        ("*", "Face Sample Limit"): "面サンプル上限",
        ("*", "Partial Visibility Threshold"): "部分可視しきい値",
        ("*", "Target Depth Margin"): "深度マージン",
        ("*", "Cache Seconds"): "キャッシュ秒数",
        ("*", "Idle Signature Skip"): "待機時の判定間引き",
        ("*", "Use Preferences as Defaults on File Load"): "ファイル読み込み時に既定値適用",
        ("*", "Right-click this button and use Assign Shortcut to choose any key. When assigned, Smart Select Guard works only while that key is held during selection. If no shortcut is assigned, the guard stays always active while enabled."): "このボタンを右クリックして「ショートカットを割り当て」から任意のキーを設定してください。割り当てると、選択操作中にそのキーを押している間だけスマート選択ガードが動作します。ショートカット未割り当ての場合は、有効な間は常時動作します。",
        ("*", "Choose the default Smart Select Guard quality preset applied to newly initialized scenes."): "新しく初期化されるシーンへ適用するスマート選択ガードの既定クオリティプリセットを選びます。",
        ("*", "Choose which 3D View contexts Smart Select Guard uses for view-dependent occlusion checks."): "ビュー依存の遮蔽判定にスマート選択ガードが使用する3Dビューコンテキストを選びます。",
        ("*", "Default for whether objects outside the edited object set can block selection targets."): "編集中オブジェクト以外のオブジェクトが選択対象を遮蔽できるかの既定値です。",
        ("*", "Default for whether selected or edited objects can occlude one another during multi-object editing."): "複数オブジェクト編集中に、選択/編集オブジェクト同士が互いを遮蔽できるかの既定値です。",
        ("*", "Default for whether single-click selection is filtered by Smart Select Guard after Blender selects an item."): "Blenderの選択後にシングルクリック選択をスマート選択ガードでフィルタするかの既定値です。",
        ("*", "Default for temporarily bypassing Smart Select Guard while the active viewport is in X-Ray display."): "アクティブビューポートが透過表示の間、スマート選択ガードを一時バイパスするかの既定値です。",
        ("*", "Default for temporarily enabling X-Ray from the moment a selection drag starts (circle select: from the press) while the viewport X-Ray display is off, then restoring the original X-Ray state after selection confirmation."): "ビューポートの透過表示がOFFの時、選択ドラッグを始めた時点（サークル選択は押した時点）から一時的に透過表示を有効にし、選択確定後に元の透過表示状態へ戻すかの既定値です。",
        ("*", "Default for temporarily bypassing Smart Select Guard while the active viewport is in Wireframe display."): "アクティブビューポートがワイヤーフレーム表示の間、スマート選択ガードを一時バイパスするかの既定値です。",
        ("*", "Default for ignoring occluder faces whose normals point away from the view ray."): "ビュー方向のレイに対して裏向きの遮蔽候補面を無視するかの既定値です。",
        ("*", "Choose the modifier key that temporarily bypasses Smart Select Guard while it is held."): "押している間だけスマート選択ガードを一時バイパスする修飾キーを選びます。",
        ("*", "Default for showing short status messages when Smart Select Guard filters or bypasses a selection."): "スマート選択ガードが選択をフィルタまたはバイパスした時に短いステータスメッセージを表示するかの既定値です。",
        ("*", "Enable-While-Held Shortcut Event"): "押下中のみ有効ショートカットイベント",
        ("*", "Stored event identifier for the Smart Select Guard enable-while-held shortcut. Right-click the Smart Select Guard shortcut button and assign a shortcut to change it."): "スマート選択ガードの「押している間だけ有効」ショートカットとして保存されたイベント識別子です。変更するには、スマート選択ガードのショートカットボタンを右クリックしてショートカットを割り当ててください。",
    }
}

# STS complete locale patch for _translations
try:
    _sts_extra_locale_pairs = [('Smart Select Guard settings are unavailable.', 'スマート選択ガード 設定を利用できません。'),
 ('Children', '子'),
 ('Objects', 'オブジェクト'),
 ('Advanced Settings', '詳細設定'),
 ('Custom Parameters (Preset=Custom)', 'カスタム項目（プリセット=カスタム）'),
 ('How to assign shortcut (details)', 'ショートカット登録方法（詳細）'),
 ('1) Edit > Preferences > Keymap', '1) 編集 > プリファレンス > キーマップ'),
 ('2) Paste the operator ID into the search box', '2) 検索欄にオペレーターIDを貼り付けます'),
 ("3) Under 3D View (Global), click 'Add New' and assign a key", '3) 3Dビュー（グローバル）で「新規追加」を押し、キーを割り当てます'),
 ('4) Confirm it toggles the guard', '4) 選択ガードの切り替えが動作することを確認します'),
 ('Tip: You can bind it separately for Object Mode and Edit Mode.', '補足：必要に応じて、オブジェクトモード用と編集モード用を別々に割り当てられます。'),
 ('Custom Defaults (Preset=Custom)', 'カスタム既定値（プリセット=カスタム）'),
 ('Use fewer samples and shorter checks for the fastest Smart Select Guard response.', 'スマート選択ガードの応答速度を優先し、少なめのサンプルと短い判定を使用します。'),
 ('Use the recommended balance between selection accuracy and viewport responsiveness.', '選択精度とビューポート応答性のバランスが取れた推奨設定を使用します。'),
 ('Use more samples and stricter checks for difficult occlusion cases.', '遮蔽判定が難しい場面向けに、より多いサンプルと厳密な判定を使用します。'),
 ('Use the custom advanced sampling and margin values shown below.', '下に表示されるカスタムのサンプリング値とマージン値を使用します。'),
 ('Evaluate Smart Select Guard using the active 3D View where the selection was made.', '選択を行ったアクティブな3Dビューを使ってスマート選択ガードを評価します。'),
 ('Allow Smart Select Guard to use all available 3D View contexts when refreshing view-dependent data.', 'ビュー依存データ更新時に、利用可能な全3Dビューコンテキストをスマート選択ガードが使用できるようにします。'),
 ('Do not use a hold-to-bypass modifier key.', '押下中バイパス用の修飾キーを使用しません。'),
 ('Temporarily bypass Smart Select Guard while Shift is held.', 'Shiftを押している間だけスマート選択ガードを一時バイパスします。'),
 ('Temporarily bypass Smart Select Guard while Ctrl is held.', 'Ctrlを押している間だけスマート選択ガードを一時バイパスします。'),
 ('Temporarily bypass Smart Select Guard while Alt is held.', 'Altを押している間だけスマート選択ガードを一時バイパスします。'),
 ('Enable or disable Smart Select Guard for the current scene. When enabled, selection tools can reject hidden or occluded targets according to the N-panel settings below.', '現在のシーンでスマート選択ガードを有効または無効にします。有効時は、下のNパネル設定に従い、隠れている対象や遮蔽された対象を選択から除外できます。'),
 ('Choose how much sampling Smart Select Guard uses. Fast favors speed, Balanced is the recommended default, Precise increases coverage, and Custom exposes manual values.', 'スマート選択ガードが使用するサンプリング量を選びます。「高速」は速度優先、「バランス」は推奨既定値、「高精度」は判定範囲を増やし、「カスタム」は手動値を表示します。'),
 ('Choose whether occlusion checks use only the active 3D View or can use all open 3D Views for view-dependent data.', '遮蔽判定にアクティブな3Dビューだけを使うか、ビュー依存データ用に開いている全3Dビューも使用できるかを選びます。'),
 ('Temporarily bypass Smart Select Guard while the active 3D View is in X-Ray mode, where selecting through visible surfaces is usually intentional.', '透過面越しの選択が通常意図的である透過表示中は、スマート選択ガードを一時バイパスします。'),
 ('Select Through when X-Ray Off', '透過表示OFF時も背面選択'),
 ('When the viewport X-Ray display is off, temporarily enable X-Ray from the moment a selection drag starts (circle select: from the press) so back-side and occluded mesh elements can be selected, then restore the original X-Ray state after the button is released and the selection is confirmed, even when nothing was selected. A plain click (except with circle select) and Transform/tweak operations do not start this temporary X-Ray state.', 'ビューの透過表示がOFFの時、選択ドラッグを始めた時点（サークル選択は押した時点）から一時的に透過表示をONにして背面や遮蔽されたメッシュ要素を選択可能にし、ボタンを離して選択が確定した後（無選択の場合も含む）に元の透過表示状態へ戻します。クリックだけの選択（サークル選択を除く）とトランスフォーム/トゥイーク操作では一時透過表示を開始しません。'),
 ('Temporarily bypass Smart Select Guard while the active 3D View is in Wireframe mode, where occlusion by solid surfaces is not expected.', 'ソリッド面による遮蔽が想定されないワイヤーフレーム表示中は、スマート選択ガードを一時バイパスします。'),
 ('Ignore potential occluding faces whose normals face away from the view ray. Enable this when backfaces should not block selection.', 'ビュー方向のレイに対して裏向きの遮蔽候補面を無視します。裏面で選択を遮りたくない場合に有効にします。'),
 ('Modifier key that temporarily bypasses Smart Select Guard while held during a selection action.', '選択操作中に押している間だけスマート選択ガードを一時バイパスする修飾キーです。'),
 ('Show short status/report messages when Smart Select Guard filters a selection or is bypassed.', 'スマート選択ガードが選択をフィルタした時やバイパスされた時に、短いステータス/レポート表示を出します。'),
 ('Default number of seconds Smart Select Guard reuses matching occlusion results before recalculating them.', 'スマート選択ガードが一致する遮蔽結果を再計算前に再利用する既定秒数です。'),
 ('Default number of unchanged idle signatures to skip before refreshing cached occlusion data.', 'キャッシュされた遮蔽データを更新する前にスキップする、未変更の待機シグネチャ数の既定値です。'),
 ('Default depth tolerance added around the target point so tiny depth-buffer differences do not incorrectly mark it as occluded.', '微小な深度バッファ差で誤って遮蔽扱いにならないよう、ターゲット点周辺へ加える既定の深度許容値です。'),
 ('Maximum number of ray/depth refinement steps used by custom Smart Select Guard occlusion checks. Higher values can improve difficult cases but cost more time.', 'カスタムスマート選択ガード遮蔽判定で使うレイ/深度補正ステップの最大数です。高い値は難しい判定を改善できますが、処理時間が増えます。'),
 ('Number of screen-space sample points used around each vertex when testing whether it is visible.', '頂点が見えているか判定する時に、各頂点周辺で使う画面空間サンプル点数です。'),
 ('Pixel radius around a vertex used for extra visibility samples. Increase when small vertices are incorrectly treated as hidden.', '追加の可視サンプルに使う頂点周辺のピクセル半径です。小さい頂点が誤って隠れている扱いになる場合に増やします。'),
 ('Number of points sampled along each edge to decide whether enough of the edge is visible for selection.', '辺の十分な部分が選択可能なほど見えているか判定するため、各辺上でサンプルする点数です。'),
 ('Maximum number of sample points used on a face before Smart Select Guard decides whether it is visible.', 'スマート選択ガードが面の可視性を判定する時に使用する面上サンプル点数の最大値です。'),
 ('Maximum number of object-level sample points used when Smart Select Guard checks object visibility. Lower values are faster; higher values are more thorough.', 'スマート選択ガードがオブジェクト可視性を確認する時に使うオブジェクト単位サンプル点数の最大値です。低い値は高速、高い値はより厳密です。'),
 ('Depth tolerance added around the target point so small depth-buffer differences do not incorrectly reject visible elements.', '小さな深度バッファ差で見えている要素を誤って除外しないよう、ターゲット点周辺へ加える深度許容値です。'),
 ('Number of seconds Smart Select Guard reuses matching occlusion results before recalculating them.', 'スマート選択ガードが一致する遮蔽結果を再計算前に再利用する秒数です。'),
 ('Number of unchanged idle signatures to skip before refreshing cached occlusion data.', 'キャッシュされた遮蔽データを更新する前にスキップする、未変更の待機シグネチャ数です。'),
 ('Small ray offset used to avoid self-intersection artifacts during Smart Select Guard visibility checks.', 'スマート選択ガードの可視性判定中に自己交差アーティファクトを避けるための小さなレイオフセットです。'),
 ('Internal flag marking that Smart Select Guard defaults were already applied to this scene.', 'スマート選択ガードの既定値がこのシーンへ適用済みであることを示す内部フラグです。')]
    _ja = _translations.setdefault("ja_JP", {})
    _en = _translations.setdefault("en_US", {})
    for _src, _dst in _sts_extra_locale_pairs:
        _ja[("*", _src)] = _dst
        if _src != _dst:
            _en[("*", _dst)] = _src
except Exception:
    pass
# /STS complete locale patch


def _i18n_register():
    try:
        bpy.app.translations.register(__name__, _translations)
    except Exception:
        pass

def _i18n_unregister():
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

# =========================================================
# Runtime
# =========================================================

_SSG_RUNTIME = {
    "cache": {},          # key -> (t, result_bool)
    "cache_view_key": None,
    "cache_settings_key": None,
    # During the optional select-through bridge, occluded elements are supposed
    # to remain selected.  Suppress only the occlusion-removal filter for that
    # short selection-confirmation window; do not globally disable the original
    # Smart Select Guard functionality just because the option is enabled.
    "suppress_occlusion_filter_until": 0.0,
    "diagnostics": [],
}
_SSG_DIAGNOSTIC_KEYS = set()
_SSG_MODULE_REGISTERED = False
_SSG_MONITOR_ENSURE_CALLBACK = None
_SSG_MONITOR_ENSURE_REMAINING = 0
_SSG_PUBLIC_SELECT_BOX_KEYMAP_ITEMS = []

# Hard cap for the one-shot post-selection confirmation pass.  Large native
# region selections are already resolved by Blender's own visibility logic;
# re-ray-casting thousands of selected edit elements is the source of the
# perceived freeze after confirming Smart Gizmo selections.
_SSG_FAST_CONFIRM_MAX_EDIT_ELEMENTS = 1200
_SSG_CACHE_SOFT_LIMIT = 4096
_SSG_CACHE_HARD_LIMIT = 32768

def _ssg_record_diagnostic_once(key: str, exc=None) -> None:
    """Record one bounded diagnostic without disabling the feature or printing."""
    token = str(key or 'unknown')
    if token in _SSG_DIAGNOSTIC_KEYS:
        return
    _SSG_DIAGNOSTIC_KEYS.add(token)
    try:
        message = f"{type(exc).__name__}: {exc}" if exc is not None else token
    except Exception:
        message = token
    rows = _SSG_RUNTIME.setdefault("diagnostics", [])
    rows.append({"key": token, "message": str(message)[:512]})
    if len(rows) > 16:
        del rows[:-16]


# =========================================================
# Utility
# =========================================================

def _tag_redraw_all_view3d():
    wm = bpy.context.window_manager
    if not wm:
        return
    for win in wm.windows:
        screen = win.screen
        if not screen:
            continue
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def _find_view3d_window_region(context):
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)

    if area and region and area.type == 'VIEW_3D' and region.type == 'WINDOW':
        space = area.spaces.active
        rv3d = getattr(space, "region_3d", None) if space else None
        if rv3d:
            return area, region, rv3d

    win = getattr(context, "window", None)
    if not win or not win.screen:
        return None, None, None

    for a in win.screen.areas:
        if a.type != 'VIEW_3D':
            continue
        r = next((x for x in a.regions if x.type == 'WINDOW'), None)
        if not r:
            continue
        space = a.spaces.active
        rv3d = getattr(space, "region_3d", None) if space else None
        if rv3d:
            return a, r, rv3d

    return None, None, None

def _world_to_region_2d(region, rv3d, co_world):
    return view3d_utils.location_3d_to_region_2d(region, rv3d, co_world)

def _orig_obj(obj):
    try:
        return obj.original
    except Exception:
        return obj

def _ssg_get_excluded_occluder_objects(scene, refresh_seconds=0.25):
    """Return a set of objects to ignore as occluders, from the exclude collection (incl. children).

    Cached briefly to avoid heavy per-tick collection traversals.
    """
    ex_col = getattr(scene, "ssg_occluder_exclude_collection", None)
    if ex_col is None:
        _SSG_RUNTIME.pop("excl_cache", None)
        return set()

    try:
        ptr = int(ex_col.as_pointer())
    except Exception:
        ptr = id(ex_col)

    now = time.time()
    cache = _SSG_RUNTIME.get("excl_cache")
    if cache and cache.get("ptr") == ptr and (now - cache.get("t", 0.0)) < float(refresh_seconds):
        return cache.get("objs", set())

    cols = []
    try:
        cols = [ex_col] + list(getattr(ex_col, "children_recursive", []))
    except Exception:
        cols = [ex_col]
        try:
            cols += list(getattr(ex_col, "children", []))
        except Exception:
            pass

    objs = set()
    for c in cols:
        try:
            objs.update(getattr(c, "objects", []))
        except Exception:
            pass

    objs = { _orig_obj(o) for o in objs if o }

    _SSG_RUNTIME["excl_cache"] = {"ptr": ptr, "t": now, "objs": objs}
    return objs

def _is_view_xray(area):
    # Same test as the header X-Ray button (XRAY_FLAG): Wireframe shading uses
    # show_xray_wireframe, every other shading type uses show_xray.
    # show_xray_wireframe defaults to True, so OR-ing both flags reported X-Ray
    # as ON in Solid shading even with X-Ray OFF.
    try:
        space = area.spaces.active
        sh = getattr(space, "shading", None)
        if sh is None:
            return False
        if getattr(sh, "type", "") == 'WIREFRAME':
            return bool(getattr(sh, "show_xray_wireframe", False))
        return bool(getattr(sh, "show_xray", False))
    except Exception:
        return False


def _select_through_xray_off_enabled(scene) -> bool:
    try:
        return bool(getattr(scene, "ssg_select_through_xray_off", False))
    except Exception:
        return False


def _suppress_select_guard_occlusion_filter(duration: float = 0.45) -> None:
    """Temporarily prevent the occlusion-removal pass after select-through.

    This preserves the original Smart Select Guard filter for normal selections
    while keeping the add-on's newer "select through when X-Ray is off" feature
    from immediately deleting the back-side elements it intentionally selected.
    """
    try:
        until = time.monotonic() + max(0.05, float(duration))
        old = float(_SSG_RUNTIME.get("suppress_occlusion_filter_until", 0.0) or 0.0)
        if until > old:
            _SSG_RUNTIME["suppress_occlusion_filter_until"] = until
    except Exception:
        pass


def _select_guard_occlusion_filter_suppressed() -> bool:
    try:
        until = float(_SSG_RUNTIME.get("suppress_occlusion_filter_until", 0.0) or 0.0)
        if until > 0.0 and time.monotonic() < until:
            return True
    except Exception:
        pass
    try:
        session = globals().get('_SSG_XRAY_ACTIVE_SESSION', {})
        if session and session.get('entries') and bool(session.get('active', False)):
            return True
    except Exception:
        pass
    return False


_SSG_HOLD_ENABLE_OPERATOR_ID = 'view3d.ssg_hold_enable_key'
_SSG_HELD_ENABLE_KEYS = set()
_SSG_HOLD_ENABLE_KEY_CACHE = {
    'keys': None,
    'scene_event': None,
    'legacy_key': None,
    'time': 0.0,
}


def _invalidate_ssg_hold_enable_key_cache():
    try:
        _SSG_HOLD_ENABLE_KEY_CACHE['keys'] = None
        _SSG_HOLD_ENABLE_KEY_CACHE['scene_event'] = None
        _SSG_HOLD_ENABLE_KEY_CACHE['legacy_key'] = None
        _SSG_HOLD_ENABLE_KEY_CACHE['time'] = 0.0
    except Exception:
        pass


def _now_monotonic() -> float:
    try:
        return float(time.monotonic())
    except Exception:
        return 0.0


def _event_type_display_name(event_type: str) -> str:
    try:
        text = str(event_type or '').strip()
    except Exception:
        text = ''
    if not text:
        return 'None'
    special = {
        'ACCENT_GRAVE': 'Accent',
        'RET': 'Enter',
        'NUMPAD_ENTER': 'Numpad Enter',
        'SPACE': 'Space',
        'TAB': 'Tab',
        'LEFTMOUSE': 'Left Mouse',
        'MIDDLEMOUSE': 'Middle Mouse',
        'RIGHTMOUSE': 'Right Mouse',
        'WHEELUPMOUSE': 'Wheel Up',
        'WHEELDOWNMOUSE': 'Wheel Down',
    }
    return special.get(text, text.replace('_', ' ').title())


def _iter_ssg_hold_enable_keymap_items(context=None):
    try:
        wm = getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
    except Exception:
        wm = None
    if wm is None:
        return
    try:
        keyconfigs = [getattr(wm, 'keyconfigs', None).user, getattr(wm, 'keyconfigs', None).addon]
    except Exception:
        keyconfigs = []
    seen = set()
    for kc in keyconfigs:
        if kc is None:
            continue
        try:
            keymaps = list(getattr(kc, 'keymaps', []) or [])
        except Exception:
            keymaps = []
        for km in keymaps:
            try:
                items = list(getattr(km, 'keymap_items', []) or [])
            except Exception:
                items = []
            for kmi in items:
                try:
                    if str(getattr(kmi, 'idname', '') or '') != _SSG_HOLD_ENABLE_OPERATOR_ID:
                        continue
                    key = (int(km.as_pointer()) if hasattr(km, 'as_pointer') else id(km), int(kmi.id))
                    if key in seen:
                        continue
                    seen.add(key)
                    yield km, kmi
                except Exception:
                    continue


def _valid_hold_enable_event_type(value) -> str:
    try:
        text = str(value or '').strip().upper()
    except Exception:
        text = ''
    if not text or text in {'NONE', 'TIMER', 'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'EVT_TWEAK_L', 'EVT_TWEAK_R', 'EVT_TWEAK_M'}:
        return ''
    return text


# ビュー操作だけに使うイベント（Event.type の値。索引で確かめた）。
_SSG_VIEW_NAV_ONLY_EVENT_TYPES = frozenset({
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM',
    'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'WHEELLEFTMOUSE', 'WHEELRIGHTMOUSE',
})


def _ssg_configured_hold_enable_keys(scene=None, context=None, *, force_refresh: bool = False, allow_stale: bool = False) -> set:
    """Return configured enable-while-held keys with a small cache.

    The old implementation scanned every user/add-on keymap item on each modal
    event.  That made Smart Select Guard noticeably heavy during viewport
    navigation because the modal watcher receives all mouse-move/view events.
    Cache the configured shortcut set and refresh it only periodically or when
    settings are explicitly changed.
    """
    try:
        scene_event = _valid_hold_enable_event_type(getattr(scene, 'ssg_hold_enable_key_event', '') if scene is not None else '')
    except Exception:
        scene_event = ''
    try:
        legacy_key = _ssg_scene_hold_enable_key(scene) if scene is not None else 'NONE'
    except Exception:
        legacy_key = 'NONE'

    now = _now_monotonic()
    cache = _SSG_HOLD_ENABLE_KEY_CACHE
    try:
        cached_keys = cache.get('keys')
        # User keymap assignments can change via Blender's right-click Assign
        # Shortcut menu.  A short TTL keeps the UI/event behavior updated while
        # avoiding keymap scans for every viewport event.
        if (
            not force_refresh and
            cached_keys is not None and
            cache.get('scene_event') == scene_event and
            cache.get('legacy_key') == legacy_key and
            (allow_stale or (now - float(cache.get('time') or 0.0)) < 1.25)
        ):
            # allow_stale：ホイール・トラックパッドのビュー操作のイベントでは、キーマップの全走査（1 回 5〜7 ms）を
            # 時間切れでもやり直さない（拡大の 1.25 秒ごとに 1 コマが引っかかっていた）。設定の値が変われば読み直し、
            # 時間切れの読み直しは次のほかのキーのイベントで行う。
            return set(cached_keys)
    except Exception:
        pass

    keys = set()
    try:
        for _km, kmi in _iter_ssg_hold_enable_keymap_items(context):
            if not bool(getattr(kmi, 'active', True)):
                continue
            key = _valid_hold_enable_event_type(getattr(kmi, 'type', ''))
            if key:
                keys.add(key)
    except Exception:
        pass
    if scene_event:
        keys.add(scene_event)
    try:
        if legacy_key != 'NONE':
            key = _valid_hold_enable_event_type(legacy_key)
            if key:
                keys.add(key)
    except Exception:
        pass

    try:
        cache['keys'] = set(keys)
        cache['scene_event'] = scene_event
        cache['legacy_key'] = legacy_key
        cache['time'] = now
    except Exception:
        pass
    return keys

def _ssg_hold_enable_active(scene=None, event=None, context=None, local_held=None) -> bool:
    keys = _ssg_configured_hold_enable_keys(scene, context)
    if not keys:
        return True
    held = set()
    try:
        held.update(_SSG_HELD_ENABLE_KEYS)
    except Exception:
        pass
    try:
        if local_held:
            held.update(local_held)
    except Exception:
        pass
    try:
        if event is not None:
            et = _valid_hold_enable_event_type(getattr(event, 'type', ''))
            ev = str(getattr(event, 'value', '') or '')
            if et in keys:
                if ev in {'PRESS', 'CLICK_DRAG', 'ANY'}:
                    return True
                if ev == 'RELEASE':
                    return False
    except Exception:
        pass
    return bool(keys.intersection(held))


def _update_ssg_hold_enable_runtime_from_event(event, scene=None) -> None:
    try:
        et = _valid_hold_enable_event_type(getattr(event, 'type', ''))
        ev = str(getattr(event, 'value', '') or '')
        if not et:
            return
        if ev in {'PRESS', 'CLICK_DRAG'}:
            keys = _ssg_configured_hold_enable_keys(scene, getattr(bpy, 'context', None))
            if et in keys:
                _SSG_HELD_ENABLE_KEYS.add(et)
                try:
                    if scene is not None:
                        setattr(scene, 'ssg_hold_enable_key_event', et)
                        _invalidate_ssg_hold_enable_key_cache()
                except Exception:
                    pass
        elif ev == 'RELEASE':
            _SSG_HELD_ENABLE_KEYS.discard(et)
    except Exception:
        pass

def _ssg_hold_enable_display_label(scene=None, context=None) -> str:
    keys = sorted(_ssg_configured_hold_enable_keys(scene, context))
    if not keys:
        return iface_("None - always active")
    return ', '.join(_event_type_display_name(k) for k in keys)


_SSG_HOLD_ENABLE_KEY_ITEMS = (
    ('NONE', "Always", "Do not require a hold key. Smart Select Guard works whenever its main toggle is ON."),
    ('Q', "Q Key", "Use Q as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('W', "W Key", "Use W as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('E', "E Key", "Use E as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('D', "D Key", "Use D as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('F', "F Key", "Use F as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('V', "V Key", "Use V as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('X', "X Key", "Use X as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('Z', "Z Key", "Use Z as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('TAB', "Tab Key", "Use Tab as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('SPACE', "Space Key", "Use Space as the non-modifier key that enables Smart Select Guard only while it is held."),
    ('ACCENT_GRAVE', "Accent Key", "Use the accent/grave key as the non-modifier key that enables Smart Select Guard only while it is held."),
)


def _ssg_scene_hold_enable_key(scene) -> str:
    try:
        value = str(getattr(scene, 'ssg_hold_enable_key', 'NONE') or 'NONE').upper()
    except Exception:
        value = 'NONE'
    valid = {item[0] for item in _SSG_HOLD_ENABLE_KEY_ITEMS}
    return value if value in valid else 'NONE'


_SSG_SAVED_SCENE_STATE_PROPS = (
    'select_guard_enabled',
    'ssg_other_objects_occlude',
    'ssg_multi_edit_mutual_occlude',
    'ssg_enable_click_filter',
    'ssg_quality_preset',
    'ssg_view_scope',
    'ssg_auto_bypass_xray',
    'ssg_select_through_xray_off',
    'ssg_auto_bypass_wireframe',
    'ssg_ignore_backface_occluders',
    'ssg_hold_bypass_key',
    'ssg_hold_enable_key',
    'ssg_hold_enable_key_event',
    'ssg_show_status_feedback',
    'ssg_partial_visible_ratio_min',
    'ssg_max_steps',
    'ssg_vertex_screen_samples',
    'ssg_vertex_sample_radius_px',
    'ssg_edge_sample_count',
    'ssg_face_sample_limit',
    'ssg_object_sample_limit',
    'ssg_target_depth_margin',
    'ssg_cache_seconds',
    'ssg_idle_signature_skip',
    'ssg_eps',
)


def _settings_has_saved_scene_prop(prop_name: str, context=None) -> bool:
    try:
        fn = getattr(_settings, '_stored_scene_scalar_has', None) if _settings is not None else None
        if callable(fn):
            return bool(fn(str(prop_name), context or getattr(bpy, 'context', None)))
    except Exception:
        pass
    return False


def _settings_has_saved_select_guard_scene_state(context=None) -> bool:
    for prop_name in _SSG_SAVED_SCENE_STATE_PROPS:
        if _settings_has_saved_scene_prop(prop_name, context):
            return True
    return False



# Robust select-through X-Ray restore watchdog.  This keeps the temporary
# internal X-Ray state from surviving native selection/transform operators that
# consume the initiating mouse release before this modal watcher can see it.
_SSG_XRAY_RESTORE_QUEUE = []
_SSG_XRAY_RESTORE_TIMER_ACTIVE = False
_SSG_XRAY_ACTIVE_SESSION = {
    'id': 0,
    'active': False,
    'entries': None,
    'area': None,
    'last_event': 0.0,
    'restore_at': 0.0,
    'force_on': False,
    'restore_epoch': 0,
    'window': None,
    'native_seen': False,
    'native_ptrs': (),
    'native_idnames': (),
    'native_absent_ticks': 0,
}
_SSG_XRAY_ACTIVE_TIMER = False
_SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = False
# 見回り（_select_through_native_discovery_tick）の速さ：見張りが TIMER 以外のイベントを受けてからこの秒数の間と、
# 選択の X 線の最中だけ 0.03 秒ごとに見る。ほかは編集メッシュの窓で 0.1 秒、無ければ 0.25 秒ごと（待機の CPU を食わない）。
# B・C・道具の囲み選択は、始めるイベントを見張りが先に受けるので、遅い間にイベントが来たら時計を 0.03 秒で登録し直す。
_SSG_NATIVE_DISCOVERY_FAST_WINDOW = 2.0
_SSG_NATIVE_DISCOVERY_LAST_INPUT_AT = 0.0
_SSG_NATIVE_DISCOVERY_SLOW = False
_SSG_XRAY_RESTORE_EPOCH = 0
_SSG_XRAY_FINALIZE_CALLBACK = None
_SSG_XRAY_FINALIZE_STATE = None


def _safe_rna_ptr(value):
    try:
        if value is not None and hasattr(value, 'as_pointer'):
            return int(value.as_pointer())
    except Exception:
        pass
    return 0


_SSG_NATIVE_SELECT_MODAL_IDNAMES = {
    'VIEW3D_OT_select_box',
    'VIEW3D_OT_select_lasso',
    'VIEW3D_OT_select_circle',
}


def _native_select_modal_rows(window):
    """Return native region-selection modal owners for one exact window.

    Blender 5.1.2 exposes every row's concrete operator id through bl_idname;
    bl_rna.identifier is only the generic string ``Operator`` and is not an
    identity authority.  Pointer values are used only for the live session.
    """
    rows = []
    try:
        operators = tuple(getattr(window, 'modal_operators', ()) or ())
    except Exception:
        operators = ()
    for operator in operators:
        try:
            bl_idname = str(getattr(operator, 'bl_idname', '') or '')
        except Exception:
            bl_idname = ''
        if bl_idname not in _SSG_NATIVE_SELECT_MODAL_IDNAMES:
            continue
        pointer = _safe_rna_ptr(operator)
        if pointer:
            rows.append((bl_idname, pointer))
    return rows


def _adopt_native_select_modal_owner(session_id=0, window=None):
    """Bind an active temporary-X-Ray generation to Blender's native modal."""
    try:
        session = _SSG_XRAY_ACTIVE_SESSION
        if session_id and int(session_id) != int(session.get('id') or 0):
            return []
        if not session.get('entries'):
            return []
        owner_window = window or session.get('window')
        if owner_window is None:
            return []
        rows = _native_select_modal_rows(owner_window)
        if not rows:
            return []
        session['window'] = owner_window
        session['native_seen'] = True
        session['native_ptrs'] = tuple(sorted({int(pointer) for _name, pointer in rows}))
        session['native_idnames'] = tuple(sorted({str(name) for name, _pointer in rows}))
        session['native_absent_ticks'] = 0
        session['last_event'] = time.monotonic()
        _suppress_select_guard_occlusion_filter(0.55)
        return rows
    except Exception:
        return []


def _native_select_modal_owner_active(session_id=0) -> bool:
    try:
        session = _SSG_XRAY_ACTIVE_SESSION
        if session_id and int(session_id) != int(session.get('id') or 0):
            return False
        if not session.get('native_seen'):
            return False
        return bool(_native_select_modal_rows(session.get('window')))
    except Exception:
        return False


def _retire_native_select_watcher_state(session_id=0, window=None, restore_epoch=None) -> bool:
    """Retire only the watcher-local state owned by one completed native session."""
    try:
        sid = int(session_id or 0)
        if not sid:
            return False
        if restore_epoch is None or int(restore_epoch) != int(_SSG_XRAY_RESTORE_EPOCH):
            return False
        cls = globals().get('VIEW3D_OT_select_guard_modal')
        instances = getattr(cls, '_instances_by_window', {}) if cls is not None else {}
        preferred = instances.get(_ssg_window_key(window)) if window is not None else None
        candidates = ([preferred] if preferred is not None else []) + [
            instance for instance in tuple(instances.values()) if instance is not preferred
        ]
        retired = False
        for instance in candidates:
            press_state = getattr(instance, '_select_through_press_state', None)
            candidate_state = getattr(instance, '_select_through_candidate_state', None)
            instance_sid = int(getattr(instance, '_select_through_session_id', 0) or 0)
            press_sid = int(press_state.get('session_id') or 0) if isinstance(press_state, dict) else 0
            candidate_sid = int(candidate_state.get('session_id') or 0) if isinstance(candidate_state, dict) else 0
            if sid not in {instance_sid, press_sid, candidate_sid}:
                continue
            if press_sid == sid or instance_sid == sid:
                instance._select_through_press_state = None
            if candidate_sid == sid or instance_sid == sid:
                instance._select_through_candidate_state = None
            if instance_sid == sid:
                instance._select_through_restore_state = None
                instance._select_through_restore_pending = False
                instance._select_through_session_id = 0
            retired = True
        return retired
    except Exception:
        return False


def _finalize_select_through_active_xray_session(session_id=0) -> bool:
    """Restore and retire one current native-selection generation exactly once."""
    global _SSG_XRAY_ACTIVE_TIMER
    session = _SSG_XRAY_ACTIVE_SESSION
    sid = int(session.get('id') or 0)
    if session_id and int(session_id) != sid:
        return False
    entries = session.get('entries')
    if not entries:
        _SSG_XRAY_ACTIVE_TIMER = False
        return False
    epoch = int(session.get('restore_epoch') or -1)
    if epoch != int(_SSG_XRAY_RESTORE_EPOCH):
        _SSG_XRAY_ACTIVE_TIMER = False
        return False
    area = session.get('area')
    window = session.get('window')
    entry_snapshot = _unique_xray_restore_entries(entries)
    # Clear global ownership before calling any restore/redraw code.  A stale
    # timer or modal callback can then observe only a retired generation.
    session.update({
        'active': False,
        'entries': None,
        'area': None,
        'restore_at': 0.0,
        'force_on': False,
        'window': None,
        'native_seen': False,
        'native_ptrs': (),
        'native_idnames': (),
        'native_absent_ticks': 0,
    })
    _SSG_XRAY_ACTIVE_TIMER = False
    _retire_native_select_watcher_state(sid, window, epoch)
    _restore_select_through_xray_entries_for_timer(
        entry_snapshot, area, restore_epoch=epoch
    )
    return True


def _native_select_discovery_area(window):
    """Resolve the guarded VIEW_3D area for one exact window without scanning other windows."""
    try:
        cls = globals().get('VIEW3D_OT_select_guard_modal')
        instance = getattr(cls, '_instances_by_window', {}).get(_ssg_window_key(window)) if cls is not None else None
        area = getattr(instance, '_last_area', None) if instance is not None else None
        if (
            area is not None
            and getattr(area, 'type', None) == 'VIEW_3D'
            and area in tuple(getattr(getattr(window, 'screen', None), 'areas', ()) or ())
        ):
            return area
        for candidate in tuple(getattr(getattr(window, 'screen', None), 'areas', ()) or ()):
            if getattr(candidate, 'type', None) == 'VIEW_3D':
                return candidate
    except Exception:
        pass
    return None


def _select_through_native_discovery_tick():
    """Lazily arm temporary X-Ray when Blender owns a native selection modal.

    B/C and toolbar region-select operators can consume their initiating mouse
    event before the Select Guard modal sees it.  Window.modal_operators is the
    Blender-owned invocation authority, so this timer admits only those three
    native operators in an enabled Edit Mesh window and then hands completion
    to the finite active-session timer.
    """
    global _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE, _SSG_NATIVE_DISCOVERY_SLOW
    try:
        if not _SSG_MODULE_REGISTERED:
            _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = False
            _SSG_NATIVE_DISCOVERY_SLOW = False
            return None
        active_session = bool(_SSG_XRAY_ACTIVE_SESSION.get('entries'))
        enabled_watcher = False
        edit_mesh_window = False
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            scene = getattr(window, 'scene', None)
            if (
                scene is None
                or not bool(getattr(scene, 'select_guard_enabled', False))
                or not _select_through_xray_off_enabled(scene)
            ):
                continue
            cls = globals().get('VIEW3D_OT_select_guard_modal')
            instances = getattr(cls, '_instances_by_window', {}) if cls is not None else {}
            if instances.get(_ssg_window_key(window)) is None:
                continue
            enabled_watcher = True
            active_object = getattr(getattr(window, 'view_layer', None), 'objects', None)
            active_object = getattr(active_object, 'active', None)
            if (
                active_object is None
                or getattr(active_object, 'type', None) != 'MESH'
                or getattr(active_object, 'mode', None) != 'EDIT'
            ):
                continue
            edit_mesh_window = True
            native_rows = _native_select_modal_rows(window)
            if not native_rows or active_session:
                continue
            area = _native_select_discovery_area(window)
            if area is None or _is_view_xray(area):
                continue
            entries = _snapshot_view_xray_state(area)
            if not entries:
                continue
            changed = _set_view_xray_for_select_through(area, True)
            if not changed and not _is_view_xray(area):
                continue
            sid = _start_select_through_active_xray_session(entries, area, window=window, force_on=True)
            _adopt_native_select_modal_owner(sid, window)
            _force_view_xray_for_select_through(area, True)
            _suppress_select_guard_occlusion_filter(0.55)
            active_session = True
        if not enabled_watcher:
            _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = False
            _SSG_NATIVE_DISCOVERY_SLOW = False
            return None
        # 操作の直後と X 線の最中は 0.03 秒。何もしていない間は、編集メッシュの窓で 0.1 秒、無ければ 0.25 秒ごとに
        # 見るだけにして待機の CPU を食わない（次のイベントで _wake_native_select_discovery_timer が 0.03 秒へ戻す）。
        if active_session or (_now_monotonic() - _SSG_NATIVE_DISCOVERY_LAST_INPUT_AT) < _SSG_NATIVE_DISCOVERY_FAST_WINDOW:
            _SSG_NATIVE_DISCOVERY_SLOW = False
            return 0.03
        _SSG_NATIVE_DISCOVERY_SLOW = True
        return 0.1 if edit_mesh_window else 0.25
    except Exception as exc:
        _ssg_record_diagnostic_once('native_select_discovery', exc)
        return 0.10


def _ensure_native_select_discovery_timer():
    global _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    try:
        registered = bool(timers is not None and timers.is_registered(_select_through_native_discovery_tick))
    except Exception:
        registered = False
    if registered:
        _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = True
        return
    try:
        if timers is not None:
            timers.register(_select_through_native_discovery_tick, first_interval=0.03)
            _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = True
    except Exception:
        _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = False


def _wake_native_select_discovery_timer():
    """遅い見回りの間にイベントが来たら、次の見回りを 0.03 秒後へ寄せる（登録されている時だけ）。"""
    global _SSG_NATIVE_DISCOVERY_SLOW
    _SSG_NATIVE_DISCOVERY_SLOW = False
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    try:
        if timers is not None and timers.is_registered(_select_through_native_discovery_tick):
            timers.unregister(_select_through_native_discovery_tick)
            timers.register(_select_through_native_discovery_tick, first_interval=0.03)
    except Exception:
        pass


def _cancel_native_select_discovery_timer():
    global _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE, _SSG_NATIVE_DISCOVERY_SLOW
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    try:
        if timers is not None and timers.is_registered(_select_through_native_discovery_tick):
            timers.unregister(_select_through_native_discovery_tick)
    except Exception:
        pass
    _SSG_NATIVE_DISCOVERY_TIMER_ACTIVE = False
    _SSG_NATIVE_DISCOVERY_SLOW = False


def _iter_view3d_window_area_space():
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        for window in getattr(wm, 'windows', ()) or ():
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                try:
                    space = getattr(getattr(area, 'spaces', None), 'active', None)
                except Exception:
                    space = None
                if space is not None:
                    yield window, screen, area, space
    except Exception:
        return


def _view3d_identity(area, space=None):
    info = {
        'area_ptr': _safe_rna_ptr(area),
        'space_ptr': _safe_rna_ptr(space),
        'screen_ptr': 0,
        'area_rect': None,
    }
    try:
        info['area_rect'] = (int(area.x), int(area.y), int(area.width), int(area.height))
    except Exception:
        pass
    try:
        for _window, screen, candidate_area, candidate_space in _iter_view3d_window_area_space():
            if candidate_area is area or _safe_rna_ptr(candidate_area) == info['area_ptr']:
                info['screen_ptr'] = _safe_rna_ptr(screen)
                if not info['space_ptr']:
                    info['space_ptr'] = _safe_rna_ptr(candidate_space)
                break
    except Exception:
        pass
    return info


def _resolve_view3d_from_xray_entry(entry):
    if not isinstance(entry, dict):
        return (None, None)
    area = entry.get('area')
    space = entry.get('space')
    try:
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            active_space = getattr(getattr(area, 'spaces', None), 'active', None)
            if active_space is not None:
                return area, active_space
    except Exception:
        pass

    wanted_area = int(entry.get('area_ptr') or 0)
    wanted_space = int(entry.get('space_ptr') or 0)
    wanted_screen = int(entry.get('screen_ptr') or 0)
    wanted_rect = entry.get('area_rect')
    fallback = (None, None)
    try:
        for _window, screen, candidate_area, candidate_space in _iter_view3d_window_area_space():
            area_ptr = _safe_rna_ptr(candidate_area)
            space_ptr = _safe_rna_ptr(candidate_space)
            screen_ptr = _safe_rna_ptr(screen)
            if wanted_space and space_ptr == wanted_space:
                return candidate_area, candidate_space
            if wanted_area and area_ptr == wanted_area:
                return candidate_area, candidate_space
            if wanted_screen and wanted_screen == screen_ptr and wanted_rect is not None:
                try:
                    rect = (int(candidate_area.x), int(candidate_area.y), int(candidate_area.width), int(candidate_area.height))
                    if tuple(wanted_rect) == rect:
                        fallback = (candidate_area, candidate_space)
                except Exception:
                    pass
    except Exception:
        pass
    return fallback


def _xray_restore_entry_key(entry):
    if not isinstance(entry, dict):
        return ('object', id(entry))
    try:
        return (
            int(entry.get('space_ptr') or 0),
            int(entry.get('area_ptr') or 0),
            str(entry.get('owner_kind') or ''),
            str(entry.get('prop') or ''),
        )
    except Exception:
        return ('entry', id(entry))


def _unique_xray_restore_entries(entries):
    unique = []
    seen = set()
    for entry in list(entries or []):
        key = _xray_restore_entry_key(entry)
        if key in seen:
            continue
        seen.add(key)
        unique.append(entry)
    return unique


def _cancel_pending_select_through_xray_restores(*, restore: bool = True) -> int:
    """Fence old restore writers and optionally restore their captured state now."""
    global _SSG_XRAY_RESTORE_QUEUE, _SSG_XRAY_RESTORE_TIMER_ACTIVE
    global _SSG_XRAY_ACTIVE_TIMER, _SSG_XRAY_RESTORE_EPOCH
    global _SSG_XRAY_FINALIZE_CALLBACK, _SSG_XRAY_FINALIZE_STATE
    pending = []
    active_sid = int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0)
    active_window = _SSG_XRAY_ACTIVE_SESSION.get('window')
    active_epoch = int(_SSG_XRAY_ACTIVE_SESSION.get('restore_epoch') or -1)
    try:
        for item in list(_SSG_XRAY_RESTORE_QUEUE or []):
            if isinstance(item, dict):
                pending.extend(list(item.get('entries') or []))
            else:
                pending.extend(list(item or []))
    except Exception:
        pass
    try:
        pending.extend(list(_SSG_XRAY_ACTIVE_SESSION.get('entries') or []))
    except Exception:
        pass
    try:
        if isinstance(_SSG_XRAY_FINALIZE_STATE, dict):
            pending.extend(list(_SSG_XRAY_FINALIZE_STATE.get('entries') or []))
    except Exception:
        pass

    finalize_callback = _SSG_XRAY_FINALIZE_CALLBACK
    _SSG_XRAY_FINALIZE_CALLBACK = None
    _SSG_XRAY_FINALIZE_STATE = None
    if active_sid and active_epoch == int(_SSG_XRAY_RESTORE_EPOCH):
        _retire_native_select_watcher_state(active_sid, active_window, active_epoch)
    _SSG_XRAY_RESTORE_EPOCH = int(_SSG_XRAY_RESTORE_EPOCH) + 1
    _SSG_XRAY_RESTORE_QUEUE = []
    _SSG_XRAY_ACTIVE_SESSION.update({
        'active': False,
        'entries': None,
        'area': None,
        'restore_at': 0.0,
        'force_on': False,
        'restore_epoch': int(_SSG_XRAY_RESTORE_EPOCH),
        'window': None,
        'native_seen': False,
        'native_ptrs': (),
        'native_idnames': (),
        'native_absent_ticks': 0,
    })

    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is not None:
        callbacks = [_select_through_xray_restore_watchdog_tick, _select_through_active_xray_tick]
        if callable(finalize_callback):
            callbacks.append(finalize_callback)
        for callback in callbacks:
            try:
                if hasattr(timers, 'is_registered') and timers.is_registered(callback):
                    timers.unregister(callback)
            except Exception:
                pass
    _SSG_XRAY_RESTORE_TIMER_ACTIVE = False
    _SSG_XRAY_ACTIVE_TIMER = False

    if restore and pending:
        _restore_select_through_xray_entries_for_timer(_unique_xray_restore_entries(pending), None)
    return int(_SSG_XRAY_RESTORE_EPOCH)


def _select_through_xray_restore_watchdog_tick():
    global _SSG_XRAY_RESTORE_QUEUE, _SSG_XRAY_RESTORE_TIMER_ACTIVE
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    current_epoch = int(_SSG_XRAY_RESTORE_EPOCH)
    try:
        queue = list(_SSG_XRAY_RESTORE_QUEUE or [])
    except Exception:
        queue = []
    # This is an exactly-once finalizer, not a repeating repair writer.  Clear
    # ownership before restoring so redraws, native operator completion, or a
    # new gesture cannot observe and re-run the same generation.
    _SSG_XRAY_RESTORE_QUEUE = []
    _SSG_XRAY_RESTORE_TIMER_ACTIVE = False
    for item in queue:
        try:
            item_epoch = int(item.get('epoch', -1)) if isinstance(item, dict) else -1
            if item_epoch != current_epoch:
                continue
            entries = item.get('entries') if isinstance(item, dict) else item
            area = item.get('area') if isinstance(item, dict) else None
            _restore_select_through_xray_entries_for_timer(entries, area, restore_epoch=item_epoch)
        except Exception:
            pass
    return None


def _enqueue_select_through_xray_restore(entries, last_area=None, *, first_delay=0.05, duration=2.5, restore_epoch=None):
    global _SSG_XRAY_RESTORE_QUEUE, _SSG_XRAY_RESTORE_TIMER_ACTIVE
    try:
        entry_list = _unique_xray_restore_entries(entries)
    except Exception:
        entry_list = []
    if not entry_list:
        return
    current_epoch = int(_SSG_XRAY_RESTORE_EPOCH)
    epoch = current_epoch if restore_epoch is None else int(restore_epoch)
    if epoch != current_epoch:
        return
    # Kept as a compatibility keyword for existing callers.  Restoration is
    # deliberately one-shot; a duration-based writer caused post-selection
    # X-Ray flicker by assigning the captured value every 100 ms.
    del duration
    merged = []
    area = last_area
    for item in list(_SSG_XRAY_RESTORE_QUEUE or []):
        try:
            if int(item.get('epoch', -1)) != epoch:
                continue
            merged.extend(list(item.get('entries') or []))
            if area is None:
                area = item.get('area')
        except Exception:
            continue
    merged.extend(entry_list)
    _SSG_XRAY_RESTORE_QUEUE = [{
        'entries': _unique_xray_restore_entries(merged),
        'area': area,
        'epoch': epoch,
    }]
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    try:
        timer_registered = bool(
            timers is not None
            and hasattr(timers, 'is_registered')
            and timers.is_registered(_select_through_xray_restore_watchdog_tick)
        )
    except Exception:
        timer_registered = False
    if _SSG_XRAY_RESTORE_TIMER_ACTIVE and timer_registered:
        return
    _SSG_XRAY_RESTORE_TIMER_ACTIVE = False
    try:
        if timers is not None:
            timers.register(_select_through_xray_restore_watchdog_tick, first_interval=max(0.01, float(first_delay)))
            _SSG_XRAY_RESTORE_TIMER_ACTIVE = True
    except Exception:
        _SSG_XRAY_RESTORE_TIMER_ACTIVE = False


_SSG_CROSSING_WAIT_MAX_TICKS = 15


def _select_through_crossing_completion_pending(session) -> bool:
    """Keep temporary X-Ray while a crossing-select completion is still queued.

    Crossing selection applies its region from a post timer shortly after the
    native box/lasso/circle operator has finished.  Restoring X-Ray before that
    timer runs makes the late pass see X-Ray OFF and drop the back-side elements
    that this select-through session was meant to include.  The wait is capped
    so a stale or cancelled completion can never keep X-Ray on.
    """
    try:
        from ..core import csdt_operators
        pending = bool(getattr(csdt_operators, '_CSDT_CROSSING_SELECT_POST_CALLBACKS', None))
    except Exception:
        return False
    if not pending:
        return False
    try:
        ticks = int(session.get('crossing_wait_ticks') or 0)
    except Exception:
        ticks = 0
    if ticks >= _SSG_CROSSING_WAIT_MAX_TICKS:
        return False
    session['crossing_wait_ticks'] = ticks + 1
    _suppress_select_guard_occlusion_filter(0.55)
    return True


def _select_through_active_xray_tick():
    """Restore temporary select-through X-Ray even when Blender consumes RELEASE.

    Native selection/tweak operators can consume mouse release events before this
    watcher receives them.  This session watchdog restores the captured original
    X-Ray state shortly after release when we see it, and also after a short
    event-silence window when release is swallowed.  It prevents X-Ray from
    leaking into subsequent transform operations.
    """
    global _SSG_XRAY_ACTIVE_TIMER
    try:
        session = _SSG_XRAY_ACTIVE_SESSION
        entries = session.get('entries')
        if int(session.get('restore_epoch', -1)) != int(_SSG_XRAY_RESTORE_EPOCH):
            _SSG_XRAY_ACTIVE_TIMER = False
            return None
        if not entries:
            _SSG_XRAY_ACTIVE_TIMER = False
            return None
        now = time.monotonic()
        active = bool(session.get('active', False))
        area = session.get('area')
        try:
            area_valid = area is not None and getattr(area, 'type', None) == 'VIEW_3D'
        except Exception:
            area_valid = False
        if active and not area_valid:
            _finalize_select_through_active_xray_session(session.get('id'))
            return None
        restore_at = float(session.get('restore_at') or 0.0)
        last_event = float(session.get('last_event') or 0.0)
        native_rows = _native_select_modal_rows(session.get('window'))
        if native_rows:
            session['native_seen'] = True
            session['native_ptrs'] = tuple(sorted({int(pointer) for _name, pointer in native_rows}))
            session['native_idnames'] = tuple(sorted({str(name) for name, _pointer in native_rows}))
            session['native_absent_ticks'] = 0
            session['last_event'] = now
            _suppress_select_guard_occlusion_filter(0.55)
            if bool(session.get('force_on', False)):
                _force_view_xray_for_select_through(session.get('area'), True)
            return 0.03
        if bool(session.get('native_seen', False)):
            # The exact native modal owner was observed and has now left the
            # window collection.  Selection/cancel has reached its terminal
            # boundary even when Blender consumed RELEASE before this watcher.
            session['native_absent_ticks'] = int(session.get('native_absent_ticks') or 0) + 1
            _suppress_select_guard_occlusion_filter(0.55)
            if int(session.get('native_absent_ticks') or 0) >= 1:
                if _select_through_crossing_completion_pending(session):
                    return 0.03
                _finalize_select_through_active_xray_session(session.get('id'))
                return None
        # Keep X-Ray enabled for the full click/drag session.  Do not restore
        # merely because the mouse stopped moving; that caused X-Ray to turn off
        # while the user was still holding a long box-select drag.  A long safety
        # timeout remains only for lost/cancelled events.
        lost_session_due = active and last_event > 0.0 and (now - last_event) >= 30.0
        confirmed_release_due = (not active) and restore_at > 0.0 and now >= restore_at
        if lost_session_due or confirmed_release_due:
            if (not lost_session_due) and _select_through_crossing_completion_pending(session):
                return 0.03
            _finalize_select_through_active_xray_session(session.get('id'))
            return None
        if active and bool(session.get('force_on', False)):
            try:
                _force_view_xray_for_select_through(session.get('area'), True)
            except Exception:
                pass
        return 0.03
    except Exception:
        try:
            _finalize_select_through_active_xray_session(
                _SSG_XRAY_ACTIVE_SESSION.get('id')
            )
        except Exception:
            pass
        _SSG_XRAY_ACTIVE_TIMER = False
        return None


def _start_select_through_active_xray_session(entries, area=None, *, window=None, force_on: bool = True):
    global _SSG_XRAY_ACTIVE_TIMER
    try:
        entry_list = list(entries or [])
    except Exception:
        entry_list = []
    if not entry_list:
        return 0
    _suppress_select_guard_occlusion_filter(0.55)
    try:
        now = time.monotonic()
    except Exception:
        now = 0.0
    sid = int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0) + 1
    _SSG_XRAY_ACTIVE_SESSION.update({
        'id': sid,
        'active': True,
        'entries': entry_list,
        'area': area,
        'last_event': now,
        'restore_at': 0.0,
        'force_on': bool(force_on),
        'restore_epoch': int(_SSG_XRAY_RESTORE_EPOCH),
        'window': window,
        'native_seen': False,
        'native_ptrs': (),
        'native_idnames': (),
        'native_absent_ticks': 0,
        'crossing_wait_ticks': 0,
    })
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    try:
        timer_registered = bool(
            timers is not None
            and hasattr(timers, 'is_registered')
            and timers.is_registered(_select_through_active_xray_tick)
        )
    except Exception:
        timer_registered = False
    if not (_SSG_XRAY_ACTIVE_TIMER and timer_registered):
        _SSG_XRAY_ACTIVE_TIMER = False
        try:
            if timers is not None:
                timers.register(_select_through_active_xray_tick, first_interval=0.05)
                _SSG_XRAY_ACTIVE_TIMER = True
        except Exception:
            _SSG_XRAY_ACTIVE_TIMER = False
    return sid


def _touch_select_through_active_xray_session(session_id=0):
    try:
        if session_id and int(session_id) != int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0):
            return
        if _SSG_XRAY_ACTIVE_SESSION.get('entries'):
            _SSG_XRAY_ACTIVE_SESSION['last_event'] = time.monotonic()
            _suppress_select_guard_occlusion_filter(0.35)
    except Exception:
        pass


def _finish_select_through_active_xray_session(session_id=0, *, delay=0.03):
    try:
        if session_id and int(session_id) != int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0):
            return
        if not _SSG_XRAY_ACTIVE_SESSION.get('entries'):
            return
        _suppress_select_guard_occlusion_filter(max(0.45, float(delay) + 0.35))
        now = time.monotonic()
        _SSG_XRAY_ACTIVE_SESSION['active'] = False
        _SSG_XRAY_ACTIVE_SESSION['restore_at'] = now + max(0.0, float(delay))
        _SSG_XRAY_ACTIVE_SESSION['last_event'] = now
    except Exception:
        pass


def _force_finish_select_through_active_xray_session(session_id=0):
    try:
        if session_id and int(session_id) != int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0):
            return
        _suppress_select_guard_occlusion_filter(0.35)
        _cancel_pending_select_through_xray_restores(restore=True)
    except Exception:
        pass


def _xray_show_prop_candidates(space):
    candidates = []
    try:
        sh = getattr(space, "shading", None)
        if sh is not None and hasattr(sh, "show_xray"):
            candidates.append((sh, "show_xray", "SHADING"))
        if sh is not None and hasattr(sh, "show_xray_wireframe"):
            candidates.append((sh, "show_xray_wireframe", "SHADING"))
    except Exception:
        pass
    try:
        ov = getattr(space, "overlay", None)
        if ov is not None and hasattr(ov, "show_xray"):
            candidates.append((ov, "show_xray", "OVERLAY"))
    except Exception:
        pass
    return candidates


def _set_view_xray_for_select_through(area, enable: bool):
    """Temporarily switch select-through X-Ray state and remember exact old values.

    The restore data intentionally stores both owner references and the VIEW_3D
    area/space.  Blender can rebuild UI data while a selection operator is
    running; resolving the active space again during restore prevents the
    temporary X-Ray flag from being left enabled after selection confirmation.
    """
    space = None
    try:
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            space = area.spaces.active
    except Exception:
        space = None
    if space is None:
        return []
    entries = []
    changed_any = False
    for owner, prop, owner_kind in _xray_show_prop_candidates(space):
        try:
            old_value = bool(getattr(owner, prop))
        except Exception:
            continue
        identity = _view3d_identity(area, space)
        entry = {
            'area': area,
            'space': space,
            'owner': owner,
            'owner_kind': owner_kind,
            'prop': str(prop),
            'old': bool(old_value),
            'changed': False,
            'area_ptr': identity.get('area_ptr', 0),
            'space_ptr': identity.get('space_ptr', 0),
            'screen_ptr': identity.get('screen_ptr', 0),
            'area_rect': identity.get('area_rect'),
        }
        if old_value != bool(enable):
            try:
                setattr(owner, prop, bool(enable))
                entry['changed'] = True
                changed_any = True
            except Exception:
                entry['changed'] = False
        entries.append(entry)
    try:
        if changed_any and area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return entries if changed_any else []


def _force_view_xray_for_select_through(area, enable: bool = True):
    """Force the current View3D X-Ray flags during an active select-through drag.

    Restore data is captured at the original mouse press.  This function only
    keeps the temporary state alive while the mouse gesture is still active, so
    a quick drag cannot miss the select-through state because a native operator
    or a queued restore briefly changed it.
    """
    try:
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        space = getattr(getattr(area, 'spaces', None), 'active', None)
    except Exception:
        space = None
    if space is None:
        return False
    changed = False
    for owner, prop, _owner_kind in _xray_show_prop_candidates(space):
        try:
            desired = bool(enable)
            if bool(getattr(owner, prop)) != desired:
                setattr(owner, prop, desired)
                changed = True
        except Exception:
            pass
    if changed:
        try:
            area.tag_redraw()
        except Exception:
            pass
    return changed


def _snapshot_view_xray_state(area):
    """Capture View3D X-Ray state without changing it."""
    try:
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return None
        space = getattr(getattr(area, 'spaces', None), 'active', None)
    except Exception:
        space = None
    if space is None:
        return None
    identity = _view3d_identity(area, space)
    entries = []
    for owner, prop, owner_kind in _xray_show_prop_candidates(space):
        try:
            entries.append({
                'area': area,
                'space': space,
                'owner': owner,
                'owner_kind': owner_kind,
                'prop': str(prop),
                'old': bool(getattr(owner, prop)),
                'changed': False,
                'area_ptr': identity.get('area_ptr', 0),
                'space_ptr': identity.get('space_ptr', 0),
                'screen_ptr': identity.get('screen_ptr', 0),
                'area_rect': identity.get('area_rect'),
            })
        except Exception:
            continue
    return entries


def _restore_view_xray_snapshot(snapshot, area=None):
    if not snapshot:
        return False
    try:
        _restore_select_through_xray_entries_for_timer(snapshot, area)
        return True
    except Exception:
        return False


def _restore_view_xray_entry(entry) -> bool:
    restored = False
    if not isinstance(entry, dict):
        try:
            owner, prop, old = entry
            setattr(owner, prop, bool(old))
            return True
        except Exception:
            return False
    prop = str(entry.get('prop') or '')
    old = bool(entry.get('old', False))
    owner_kind = str(entry.get('owner_kind') or '').upper()
    candidates = []
    owner = entry.get('owner')
    if owner is not None:
        candidates.append(owner)
    space = entry.get('space')
    area = entry.get('area')
    try:
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            active_space = getattr(getattr(area, 'spaces', None), 'active', None)
            if active_space is not None and active_space is not space:
                space = active_space
    except Exception:
        pass
    try:
        resolved_area, resolved_space = _resolve_view3d_from_xray_entry(entry)
        if resolved_area is not None:
            area = resolved_area
        if resolved_space is not None:
            space = resolved_space
    except Exception:
        pass
    try:
        if space is not None:
            sh = getattr(space, 'shading', None)
            ov = getattr(space, 'overlay', None)
            if owner_kind == 'SHADING' and prop in {'show_xray', 'show_xray_wireframe'} and sh is not None:
                candidates.append(sh)
            elif owner_kind == 'OVERLAY' and prop == 'show_xray' and ov is not None:
                candidates.append(ov)
            elif not owner_kind:
                # Legacy tuple/dict snapshots did not identify the RNA owner.
                # Preserve their fallback resolution without allowing new
                # snapshots to alias Shading.show_xray and Overlay.show_xray.
                if prop in {'show_xray', 'show_xray_wireframe'} and sh is not None:
                    candidates.append(sh)
                if prop == 'show_xray' and ov is not None:
                    candidates.append(ov)
    except Exception:
        pass
    seen = set()
    for candidate in candidates:
        try:
            key = int(candidate.as_pointer()) if hasattr(candidate, 'as_pointer') else id(candidate)
        except Exception:
            key = id(candidate)
        if key in seen:
            continue
        seen.add(key)
        try:
            if hasattr(candidate, prop):
                if bool(getattr(candidate, prop)) != old:
                    setattr(candidate, prop, old)
                restored = True
        except Exception:
            pass
    try:
        if area is not None:
            area.tag_redraw()
    except Exception:
        pass
    return restored




def _restore_select_through_xray_entries_for_timer(entries, last_area=None, restore_epoch=None):
    if restore_epoch is not None and int(restore_epoch) != int(_SSG_XRAY_RESTORE_EPOCH):
        return None
    tagged = set()
    try:
        entries = list(entries or [])
    except Exception:
        entries = []
    for entry in reversed(entries):
        try:
            if isinstance(entry, dict):
                area = entry.get('area')
                if area is not None:
                    tagged.add(area)
            _restore_view_xray_entry(entry)
        except Exception:
            pass
    try:
        if last_area is not None:
            tagged.add(last_area)
    except Exception:
        pass
    for area in tagged:
        try:
            area.tag_redraw()
        except Exception:
            pass
    return None


def _native_tweak_threshold_px(context=None, event=None) -> float:
    """Return Blender's configured click-drag threshold for the current device."""
    try:
        prefs = getattr(context or getattr(bpy, 'context', None), 'preferences', None)
        inputs = getattr(prefs, 'inputs', None) if prefs is not None else None
    except Exception:
        inputs = None
    names = ['tweak_threshold']
    try:
        if bool(getattr(event, 'is_tablet', False)):
            names.append('drag_threshold_tablet')
        else:
            names.append('drag_threshold_mouse')
    except Exception:
        names.append('drag_threshold_mouse')
    names.append('drag_threshold')
    for name in names:
        try:
            value = float(getattr(inputs, name))
            if value > 0.0:
                return max(3.0, value)
        except Exception:
            continue
    return 4.0


def _event_confirms_native_tweak(event) -> bool:
    try:
        etype = str(getattr(event, 'type', '') or '')
        evalue = str(getattr(event, 'value', '') or '')
    except Exception:
        return False
    return bool(
        (etype == 'LEFTMOUSE' and evalue == 'CLICK_DRAG')
        or (etype == 'EVT_TWEAK_L' and evalue in {'PRESS', 'CLICK_DRAG', 'ANY'})
    )


def _event_starts_select_through_xray_off(event) -> bool:
    """Return True for mouse events that may begin select-through.

    Slow gestures arrive as LEFTMOUSE/PRESS.  Very fast box drags can arrive as
    LEFTMOUSE/CLICK_DRAG before the watcher receives a usable release pair, so
    that is accepted as a late start.  EVT_TWEAK_L is deliberately not a start
    signal because Blender also uses it for transform/tweak drags; when a valid
    press already started select-through, EVT_TWEAK_L is handled only as a drag
    update.  Alt+left-drag is excluded so Blender's native Alt selection routes
    are not replaced by the Smart Select Guard supplement.
    """
    try:
        if bool(getattr(event, "alt", False)):
            return False
        etype = str(getattr(event, "type", "") or "")
        evalue = str(getattr(event, "value", "") or "")
    except Exception:
        return False
    if etype == 'LEFTMOUSE' and evalue in {'PRESS', 'CLICK_DRAG'}:
        return True
    # Blender's default lasso shortcut is Ctrl+RMB click-drag.  The press is
    # only watched; temporary X-Ray starts on the CLICK_DRAG that also starts
    # the native lasso operator (it evaluates the selection on release), so a
    # plain Ctrl+RMB click never flashes X-Ray.  Do not replace or rewrite the
    # user's keymap.
    return bool(
        etype == 'RIGHTMOUSE'
        and evalue in {'PRESS', 'CLICK_DRAG'}
        and bool(getattr(event, 'ctrl', False))
    )


def _event_updates_select_through_xray_off_drag(event) -> bool:
    try:
        etype = str(getattr(event, "type", "") or "")
        evalue = str(getattr(event, "value", "") or "")
    except Exception:
        return False
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
        return True
    if etype == 'LEFTMOUSE' and evalue in {'CLICK_DRAG', 'ANY'}:
        return True
    if etype == 'EVT_TWEAK_L' and evalue in {'PRESS', 'CLICK_DRAG', 'ANY'}:
        return True
    return False


def _event_finishes_select_through_xray_off(event) -> bool:
    try:
        etype = str(getattr(event, "type", "") or "")
        evalue = str(getattr(event, "value", "") or "")
    except Exception:
        return False
    if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
        return True
    if etype in {'ESC', 'RIGHTMOUSE'} and evalue in {'PRESS', 'RELEASE'}:
        return True
    return False


def _active_view3d_tool_id(context) -> str:
    try:
        workspace = getattr(context, 'workspace', None)
        tools = getattr(workspace, 'tools', None) if workspace is not None else None
        if tools is None:
            return ''
        mode = str(getattr(context, 'mode', '') or 'OBJECT')
        tool = tools.from_space_view3d_mode(mode, create=False)
        return str(getattr(tool, 'idname', '') or '')
    except Exception:
        return ''


def _is_select_tool_active(context) -> bool:
    tool_id = _active_view3d_tool_id(context)
    # Select-through is allowed only for actual 3D View selection tools.  The
    # default Select tool is included so click selection can select through when
    # requested, but transform/tweak starts are rejected later by the selected-
    # element hit test before X-Ray is switched on.
    return tool_id in {'builtin.select', 'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'}


def _press_hits_smart_gizmo_handle(context, event=None, area=None, region=None, pos=None) -> bool:
    try:
        from ..core import csdt_gizmo as _cgizmo
    except Exception:
        _cgizmo = None
    if _cgizmo is None:
        return False
    try:
        resolver = getattr(_cgizmo, '_hit_test_gizmo_for_event', None)
        if resolver is not None and event is not None:
            hit, _area, _region, _mx, _my, _tool_active = resolver(context, event, accept_exact_hover=True)
            return bool(hit)
    except Exception:
        pass
    try:
        if pos is not None:
            hit = getattr(_cgizmo, '_hit_test_gizmo', None)
            if callable(hit):
                return bool(hit(int(pos[0]), int(pos[1]), context))
    except Exception:
        pass
    return False


def _select_through_native_xray_allowed(context, event) -> bool:
    """Return True only for native View3D selection gestures.

    The temporary X-Ray bridge must never start for transform/tweak/gizmo
    gestures.  Earlier builds accepted every LEFTMOUSE event in a VIEW_3D and
    especially treated late CLICK_DRAG as a start signal; that could turn X-Ray
    on during object/element transforms.  This gate now requires an active
    selection tool, and late CLICK_DRAG starts are restricted to explicit region
    selection tools only.
    """
    try:
        if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
            return False
        etype = str(getattr(event, 'type', '') or '')
        evalue = str(getattr(event, 'value', '') or '')
    except Exception:
        return False
    lasso_shortcut = bool(
        etype == 'RIGHTMOUSE'
        and evalue in {'PRESS', 'CLICK_DRAG'}
        and bool(getattr(event, 'ctrl', False))
    )
    if not lasso_shortcut and (etype != 'LEFTMOUSE' or evalue not in {'PRESS', 'CLICK_DRAG'}):
        return False
    try:
        tool_id = str(_active_view3d_tool_id(context) or '')
    except Exception:
        tool_id = ''
    select_tools = {'builtin.select', 'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'}
    region_select_tools = {'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'}
    if tool_id not in select_tools and not lasso_shortcut:
        return False
    # Fast drags can arrive as CLICK_DRAG before a clean press-state is built.
    # Accept those only for tools whose purpose is region selection.  Default
    # Select CLICK_DRAG is Blender's tweak/transform route and must not toggle
    # X-Ray.  The Ctrl+RMB lasso shortcut is a region selection in every tool
    # and starts here, on its CLICK_DRAG.
    if evalue == 'CLICK_DRAG' and tool_id not in region_select_tools and not lasso_shortcut:
        return False
    try:
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D' and region is not None and getattr(region, 'type', None) == 'WINDOW':
            return True
    except Exception:
        pass
    try:
        return _find_view3d_from_event(context, event)[1] is not None
    except Exception:
        return False


def begin_external_select_through_xray(context, event=None):
    """Begin temporary X-Ray for external Smart Transform background selection.

    This is called by the Smart Gizmo/custom selection background-box path, whose
    modal operator can consume the mouse release before the Smart Select Guard
    watcher sees it.  Returning the active session token lets the caller restore
    the original X-Ray state after its own selection confirmation.
    """
    try:
        if event is not None and bool(getattr(event, 'alt', False)):
            return None
    except Exception:
        return None
    try:
        scene = getattr(context, 'scene', None)
    except Exception:
        scene = None
    if scene is None or not bool(getattr(scene, 'select_guard_enabled', False)):
        return None
    if not _select_through_xray_off_enabled(scene):
        return None
    if not _ssg_hold_enable_active(scene, event, context):
        return None
    try:
        window = getattr(context, 'window', None)
    except Exception:
        window = None
    try:
        area, region, _rv3d = _find_view3d_window_region(context)
    except Exception:
        area = region = None
    if area is None:
        try:
            window, area, region = _find_view3d_from_event(context, event)
        except Exception:
            area = region = None
    if area is None:
        return None
    try:
        existing = _SSG_XRAY_ACTIVE_SESSION.get('entries')
        active_area = _SSG_XRAY_ACTIVE_SESSION.get('area')
        same_area = bool(
            active_area is area
            or (
                _safe_rna_ptr(active_area)
                and _safe_rna_ptr(active_area) == _safe_rna_ptr(area)
            )
        )
        if existing and same_area:
            _touch_select_through_active_xray_session(_SSG_XRAY_ACTIVE_SESSION.get('id', 0))
            return {
                'window': window,
                'area': area,
                'region': region,
                'press_pos': _event_region_xy(event, region) if event is not None else None,
                'entries': list(existing),
                'session_id': int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0),
                'restore_epoch': int(_SSG_XRAY_ACTIVE_SESSION.get('restore_epoch') or 0),
                'area_ptr': _safe_rna_ptr(area),
                'borrowed': True,
            }
    except Exception:
        pass
    # A different-area owner or delayed finalizer must be retired before this
    # area's user-owned ON state is inspected.  Otherwise an old temporary ON
    # can leak, or its closure can switch the next gesture OFF later.
    _cancel_pending_select_through_xray_restores(restore=True)
    # The user already owns an ON state.  No temporary writer or token is
    # needed, and every underlying shading/overlay flag must remain untouched.
    if _is_view_xray(area):
        return None
    before = _snapshot_view_xray_state(area)
    changed = []
    if not _is_view_xray(area):
        changed = _set_view_xray_for_select_through(area, True)
    entries = before or changed
    if not entries:
        return None
    _suppress_select_guard_occlusion_filter(0.55)
    sid = _start_select_through_active_xray_session(entries, area, window=window)
    return {
        'window': window,
        'area': area,
        'region': region,
        'entries': list(entries),
        'session_id': sid,
        'restore_epoch': int(_SSG_XRAY_ACTIVE_SESSION.get('restore_epoch') or 0),
        'area_ptr': _safe_rna_ptr(area),
        'borrowed': False,
    }


def touch_external_select_through_xray(token=None):
    try:
        sid = int((token or {}).get('session_id') or 0)
    except Exception:
        sid = 0
    _touch_select_through_active_xray_session(sid)


def finish_external_select_through_xray(token=None, *, delay=0.04, cancelled=False):
    if not token:
        return None
    try:
        entries = list((token or {}).get('entries') or [])
    except Exception:
        entries = []
    area = None
    try:
        area = (token or {}).get('area')
    except Exception:
        area = None
    try:
        sid = int((token or {}).get('session_id') or 0)
    except Exception:
        sid = 0
    try:
        token_epoch = int((token or {}).get('restore_epoch'))
    except Exception:
        token_epoch = -1
    try:
        token_area_ptr = int((token or {}).get('area_ptr') or 0)
    except Exception:
        token_area_ptr = 0
    current_area = _SSG_XRAY_ACTIVE_SESSION.get('area')
    current_area_ptr = _safe_rna_ptr(current_area)
    same_area = bool(
        area is current_area
        or (token_area_ptr and current_area_ptr and token_area_ptr == current_area_ptr)
    )
    # A caller may finish after another gesture has already retired or replaced
    # this session.  Both the session id and generation must still own the live
    # snapshot; otherwise the stale token is a strict no-op.
    if (
        sid <= 0
        or sid != int(_SSG_XRAY_ACTIVE_SESSION.get('id') or 0)
        or token_epoch != int(_SSG_XRAY_ACTIVE_SESSION.get('restore_epoch') or -1)
        or token_epoch != int(_SSG_XRAY_RESTORE_EPOCH)
        or not same_area
        or not _SSG_XRAY_ACTIVE_SESSION.get('entries')
    ):
        return None
    _suppress_select_guard_occlusion_filter(max(0.45, float(delay) + 0.35))
    borrowed = bool((token or {}).get('borrowed', False))
    if borrowed:
        # The modal Select Guard gesture owns the snapshot.  An external Smart
        # Transform borrower may keep it alive or request normal completion, but
        # it must never force-cancel the owner's session.
        # Borrowing is a lease only.  The modal owner observes and finalizes its
        # own release/cancel boundary; the borrower never changes owner state.
        return None
    if cancelled:
        try:
            _force_finish_select_through_active_xray_session(sid)
        except Exception:
            pass
    elif entries:
        # Native Box/Lasso still has to consume this same release event.  Retire
        # the active writer now, then restore once just after Blender's operator
        # reaches its terminal boundary.  The old duration-based repair loop is
        # deliberately not used.
        restore_epoch = _cancel_pending_select_through_xray_restores(restore=False)
        _enqueue_select_through_xray_restore(
            entries,
            area,
            first_delay=max(0.01, float(delay)),
            restore_epoch=restore_epoch,
        )
    return None




def apply_external_select_through_box(context, token=None, press_pos=None, release_pos=None, *, shift=False, ctrl=False, alt=False, min_drag_px: float = 1.0):
    """Apply a geometry-based select-through supplement for custom box drags.

    Smart Gizmo / Smart Transform background-box selection can finish too fast
    for Blender's temporary X-Ray state to affect the native select_box result on
    every platform.  This deterministic supplement selects the projected elements
    inside the same rectangle after the native box select has run, without using
    depth occlusion, so back-side and hidden elements are included even for very
    fast press-drag-release gestures.
    """
    try:
        if bool(alt):
            return False
    except Exception:
        return False
    try:
        tok = token or {}
        area = tok.get('area')
        region = tok.get('region')
    except Exception:
        area = region = None
    if area is None or region is None:
        try:
            area, region, _rv3d = _find_view3d_window_region(context)
        except Exception:
            area = region = None
    if area is None or region is None:
        return False
    try:
        override = {'area': area, 'region': region}
        window = (token or {}).get('window') if isinstance(token, dict) else None
        if window is not None:
            override['window'] = window
        space = getattr(getattr(area, 'spaces', None), 'active', None)
        if space is not None:
            override['space_data'] = space
            rv3d = getattr(space, 'region_3d', None)
            if rv3d is not None:
                override['region_data'] = rv3d
        with bpy.context.temp_override(**override):
            changed = _select_through_fallback_box(
                bpy.context, area, region, press_pos, release_pos,
                shift=shift, ctrl=ctrl, alt=alt, require_select_tool=False,
                min_drag_px=min_drag_px,
            )
        if changed:
            _tag_redraw_all_view3d()
        return bool(changed)
    except Exception as ex:
        _warn_once('external select-through fallback', ex)
        return False


def _screen_rect_from_points(p0, p1):
    try:
        x0, y0 = float(p0[0]), float(p0[1])
        x1, y1 = float(p1[0]), float(p1[1])
    except Exception:
        return None
    return (min(x0, x1), max(x0, x1), min(y0, y1), max(y0, y1))


def _point_in_rect_2d(co, rect, pad=0.0) -> bool:
    if co is None or rect is None:
        return False
    try:
        x = float(co.x); y = float(co.y)
        xmin, xmax, ymin, ymax = rect
        return (xmin - pad) <= x <= (xmax + pad) and (ymin - pad) <= y <= (ymax + pad)
    except Exception:
        return False



def _segment_intersects_rect_2d(a, b, rect, pad=0.0) -> bool:
    if a is None or b is None or rect is None:
        return False
    try:
        x0, y0 = (float(a.x), float(a.y)) if hasattr(a, 'x') else (float(a[0]), float(a[1]))
        x1, y1 = (float(b.x), float(b.y)) if hasattr(b, 'x') else (float(b[0]), float(b[1]))
        xmin, xmax, ymin, ymax = [float(v) for v in rect]
        pad = float(pad)
        xmin -= pad; xmax += pad; ymin -= pad; ymax += pad
    except Exception:
        return False
    if (xmin <= x0 <= xmax and ymin <= y0 <= ymax) or (xmin <= x1 <= xmax and ymin <= y1 <= ymax):
        return True
    dx = x1 - x0
    dy = y1 - y0
    u0, u1 = 0.0, 1.0
    for p, q in ((-dx, x0 - xmin), (dx, xmax - x0), (-dy, y0 - ymin), (dy, ymax - y0)):
        try:
            if abs(p) < 1.0e-12:
                if q < 0.0:
                    return False
                continue
            r = q / p
            if p < 0.0:
                if r > u1:
                    return False
                if r > u0:
                    u0 = r
            else:
                if r < u0:
                    return False
                if r < u1:
                    u1 = r
        except Exception:
            return False
    return u0 <= u1


def _projected_edge_hits_rect(region, rv3d, mw, edge, rect, pad=2.0) -> bool:
    try:
        v0 = edge.verts[0].co.copy()
        v1 = edge.verts[1].co.copy()
    except Exception:
        return False

    def _project(co):
        try:
            return view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ co)
        except Exception:
            return None

    try:
        p0 = _project(v0)
        p1 = _project(v1)
        if p0 is not None and p1 is not None and _segment_intersects_rect_2d(p0, p1, rect, pad=pad):
            return True
        if _point_in_rect_2d(p0, rect, pad=pad) or _point_in_rect_2d(p1, rect, pad=pad):
            return True
    except Exception:
        pass

    last = None
    try:
        steps = 32
        for i in range(0, steps + 1):
            t = float(i) / float(steps)
            p = _project(v0.lerp(v1, t))
            if _point_in_rect_2d(p, rect, pad=pad):
                return True
            if p is not None and last is not None and _segment_intersects_rect_2d(last, p, rect, pad=pad):
                return True
            if p is not None:
                last = p
    except Exception:
        pass
    return False

def _select_action_from_event_state(shift=False, ctrl=False, alt=False) -> str:
    # Keep Blender's region-selection modes distinct.  In particular, plain SET
    # must clear elements outside the new region; treating SET as generic SELECT
    # is what left unrelated elements selected after the fallback pass.
    del alt
    if bool(shift) and bool(ctrl):
        return 'TOGGLE'
    if bool(ctrl):
        return 'DESELECT'
    if bool(shift):
        return 'ADD'
    return 'SET'


def _apply_selection_state(elem, action: str) -> bool:
    try:
        before = bool(getattr(elem, 'select', False))
    except Exception:
        before = False
    try:
        if action == 'DESELECT':
            elem.select_set(False)
        elif action == 'TOGGLE':
            elem.select_set(not before)
        else:
            elem.select_set(True)
    except Exception:
        try:
            if action == 'DESELECT':
                elem.select = False
            elif action == 'TOGGLE':
                elem.select = not before
            else:
                elem.select = True
        except Exception:
            return False
    try:
        after = bool(getattr(elem, 'select', False))
    except Exception:
        after = before
    return before != after


def _screen_distance_sq(a, b) -> float:
    try:
        dx = float(a[0]) - float(b[0])
        dy = float(a[1]) - float(b[1])
        return dx * dx + dy * dy
    except Exception:
        return 1.0e30


def _screen_segment_distance_sq(point, a, b) -> float:
    try:
        px, py = float(point[0]), float(point[1])
        ax, ay = float(a[0]), float(a[1])
        bx, by = float(b[0]), float(b[1])
        vx, vy = bx - ax, by - ay
        denom = vx * vx + vy * vy
        if denom <= 1.0e-12:
            return _screen_distance_sq((px, py), (ax, ay))
        t = ((px - ax) * vx + (py - ay) * vy) / denom
        t = min(1.0, max(0.0, t))
        return _screen_distance_sq((px, py), (ax + t * vx, ay + t * vy))
    except Exception:
        return 1.0e30


def _screen_point_in_polygon(point, polygon) -> bool:
    try:
        px, py = float(point[0]), float(point[1])
        coords = [(float(p[0]), float(p[1])) for p in polygon if p is not None]
    except Exception:
        return False
    if len(coords) < 3:
        return False
    inside = False
    j = len(coords) - 1
    for i, (xi, yi) in enumerate(coords):
        xj, yj = coords[j]
        crosses = (yi > py) != (yj > py)
        if crosses:
            try:
                x_cross = (xj - xi) * (py - yi) / (yj - yi) + xi
            except ZeroDivisionError:
                x_cross = xi
            if px < x_cross:
                inside = not inside
        j = i
    return inside


def _raycast_hits_selected_object(context, region, rv3d, pos, selected_objects) -> bool:
    selected_ptrs = {_safe_rna_ptr(obj) for obj in list(selected_objects or []) if obj is not None}
    selected_ptrs.discard(0)
    if not selected_ptrs:
        return False
    try:
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, pos)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, pos)
        depsgraph = context.evaluated_depsgraph_get()
        result = context.scene.ray_cast(depsgraph, origin, direction)
        if not result or not bool(result[0]):
            return False
        hit_obj = result[4] if len(result) > 4 else None
        candidates = [hit_obj, getattr(hit_obj, 'original', None) if hit_obj is not None else None]
        return any(_safe_rna_ptr(candidate) in selected_ptrs for candidate in candidates if candidate is not None)
    except Exception:
        return False


def _press_hits_selected_element(context, area, region, pos, radius_px: float = 10.0) -> bool:
    """Return True only for a precise selected-element tweak hit.

    Vertices retain the existing pixel-radius test.  Selected edges use actual
    projected segment distance, selected faces use their projected polygon, and
    Object mode uses a viewport ray hit against the selected object.  Broad
    screen-space bounding boxes are deliberately not treated as element hits.
    """
    if area is None or region is None or pos is None:
        return False
    try:
        rv3d = getattr(getattr(area, 'spaces', None), 'active', None).region_3d
    except Exception:
        rv3d = None
    if rv3d is None:
        return False
    radius_sq = float(radius_px) * float(radius_px)
    mode = str(getattr(context, 'mode', '') or '')

    def _project(world_co):
        try:
            co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, world_co)
            return None if co2d is None else (float(co2d.x), float(co2d.y))
        except Exception:
            return None

    def _hit_world_point(world_co):
        co2d = _project(world_co)
        return co2d is not None and _screen_distance_sq(co2d, pos) <= radius_sq

    if mode == 'EDIT_MESH':
        objs = [o for o in getattr(context, 'objects_in_mode', []) if o and getattr(o, 'type', None) == 'MESH']
        if not objs:
            obj = getattr(context, 'edit_object', None)
            if obj and getattr(obj, 'type', None) == 'MESH':
                objs = [obj]
        for obj in objs:
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
                mw = obj.matrix_world
            except Exception:
                continue
            try:
                for v in bm.verts:
                    if getattr(v, 'hide', False) or not getattr(v, 'select', False):
                        continue
                    if _hit_world_point(mw @ v.co):
                        return True
                for e in bm.edges:
                    if getattr(e, 'hide', False) or not getattr(e, 'select', False):
                        continue
                    p0 = _project(mw @ e.verts[0].co)
                    p1 = _project(mw @ e.verts[1].co)
                    if p0 is not None and p1 is not None and _screen_segment_distance_sq(pos, p0, p1) <= radius_sq:
                        return True
                for f in bm.faces:
                    if getattr(f, 'hide', False) or not getattr(f, 'select', False):
                        continue
                    polygon = [_project(mw @ v.co) for v in f.verts]
                    polygon = [p for p in polygon if p is not None]
                    if _screen_point_in_polygon(pos, polygon):
                        return True
                    if len(polygon) >= 2:
                        for index, p0 in enumerate(polygon):
                            p1 = polygon[(index + 1) % len(polygon)]
                            if _screen_segment_distance_sq(pos, p0, p1) <= radius_sq:
                                return True
            except Exception:
                continue
        return False

    if mode == 'OBJECT':
        selected = list(getattr(context, 'selected_objects', []) or [])
        if _raycast_hits_selected_object(context, region, rv3d, pos, selected):
            return True
        bbox_edges = (
            (0, 1), (1, 2), (2, 3), (3, 0),
            (4, 5), (5, 6), (6, 7), (7, 4),
            (0, 4), (1, 5), (2, 6), (3, 7),
        )
        for obj in selected:
            if obj is None:
                continue
            try:
                if not obj.visible_get():
                    continue
            except Exception:
                pass
            try:
                if _hit_world_point(obj.matrix_world.translation):
                    return True
            except Exception:
                pass
            try:
                projected = [_project(p) for p in list(_object_bbox_points_world(obj))]
                for p in projected:
                    if p is not None and _screen_distance_sq(p, pos) <= radius_sq:
                        return True
                if len(projected) >= 8:
                    for a_index, b_index in bbox_edges:
                        p0, p1 = projected[a_index], projected[b_index]
                        if p0 is not None and p1 is not None and _screen_segment_distance_sq(pos, p0, p1) <= radius_sq:
                            return True
            except Exception:
                pass
    return False


def _select_through_fallback_edit_mesh_box(context, area, region, rect, action: str = 'SELECT') -> bool:
    if rect is None:
        return False
    try:
        rv3d = getattr(getattr(area, 'spaces', None), 'active', None).region_3d
    except Exception:
        rv3d = None
    if rv3d is None:
        return False

    try:
        mesh_select_mode = tuple(bool(v) for v in context.scene.tool_settings.mesh_select_mode[:])
    except Exception:
        mesh_select_mode = (True, False, False)
    use_vert, use_edge, use_face = (mesh_select_mode + (False, False, False))[:3]

    edit_objs = [o for o in getattr(context, 'objects_in_mode', []) if o and getattr(o, 'type', None) == 'MESH']
    if not edit_objs:
        obj = getattr(context, 'edit_object', None)
        if obj and getattr(obj, 'type', None) == 'MESH':
            edit_objs = [obj]
    if not edit_objs:
        return False

    action = str(action or 'SET').upper()
    changed_any = False
    pad = 0.5
    for obj in edit_objs:
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
        except Exception:
            continue
        mw = obj.matrix_world
        changed = False
        try:
            if action == 'SET':
                # Native Box Select SET replaces the visible selection.  The
                # geometric fallback must do the same before adding projected
                # hits, otherwise elements outside the rectangle survive.
                for elem_seq in (bm.verts, bm.edges, bm.faces):
                    for elem in elem_seq:
                        if getattr(elem, 'hide', False) or not bool(getattr(elem, 'select', False)):
                            continue
                        elem.select_set(False)
                        changed = True

            if use_vert:
                for v in bm.verts:
                    if getattr(v, 'hide', False):
                        continue
                    co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ v.co)
                    if _point_in_rect_2d(co2d, rect, pad=pad):
                        changed |= _apply_selection_state(v, 'SELECT' if action == 'SET' else action)

            if use_edge:
                for e in bm.edges:
                    if getattr(e, 'hide', False):
                        continue
                    if _projected_edge_hits_rect(region, rv3d, mw, e, rect, pad=max(1.5, pad)):
                        changed |= _apply_selection_state(e, 'SELECT' if action == 'SET' else action)

            if use_face:
                for f in bm.faces:
                    if getattr(f, 'hide', False):
                        continue
                    try:
                        center = mw @ f.calc_center_median()
                        co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center)
                    except Exception:
                        co2d = None
                    # Blender's edit-face box selector uses the face selection
                    # center.  Testing every vertex selected large faces whose
                    # center was outside the visible box.
                    if _point_in_rect_2d(co2d, rect, pad=pad):
                        changed |= _apply_selection_state(f, 'SELECT' if action == 'SET' else action)

            if changed:
                try:
                    bm.select_flush_mode()
                except Exception:
                    pass
                try:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
                changed_any = True
        except Exception as ex:
            _warn_once('select-through fallback', ex)
            continue
    return changed_any


def _object_bbox_points_world(obj):
    try:
        mw = obj.matrix_world
        pts = [mw.translation.copy()]
        pts.extend([mw @ Vector(corner) for corner in obj.bound_box])
        return pts
    except Exception:
        try:
            return [obj.matrix_world.translation.copy()]
        except Exception:
            return []


def _select_through_fallback_object_box(context, area, region, rect, action: str = 'SELECT') -> bool:
    if rect is None:
        return False
    try:
        rv3d = getattr(getattr(area, 'spaces', None), 'active', None).region_3d
    except Exception:
        rv3d = None
    if rv3d is None:
        return False
    action = str(action or 'SET').upper()
    changed_any = False
    if action == 'SET':
        # Match Box Select SET rather than ADD.  Object selection outside the
        # rectangle is cleared once before projected hits are applied.
        for selected in list(getattr(context, 'selected_objects', []) or []):
            try:
                if bool(selected.select_get()):
                    selected.select_set(False)
                    changed_any = True
            except Exception:
                pass
    for obj in list(getattr(context, 'visible_objects', []) or []):
        if obj is None:
            continue
        try:
            if not obj.visible_get():
                continue
        except Exception:
            pass
        hit = False
        for p in _object_bbox_points_world(obj):
            co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p)
            if _point_in_rect_2d(co2d, rect, pad=0.5):
                hit = True
                break
        if not hit:
            continue
        try:
            before = bool(obj.select_get())
            if action == 'DESELECT':
                obj.select_set(False)
            elif action == 'TOGGLE':
                obj.select_set(not before)
            else:
                obj.select_set(True)
            if bool(obj.select_get()) != before:
                changed_any = True
        except Exception:
            pass
    return changed_any




def _event_window_xy(event):
    try:
        return (float(getattr(event, 'mouse_x')), float(getattr(event, 'mouse_y')))
    except Exception:
        return None


def _find_view3d_from_event(context, event):
    """Resolve the 3D View under a window-modal mouse event.

    Global modal handlers often receive events with context.area == None and
    mouse_region_x/y == -1.  Blender still provides mouse_x/y in window
    coordinates.  Use those coordinates to recover the actual VIEW_3D area and
    WINDOW region so X-Ray toggling and fallback selection happen in the view the
    user is operating.
    """
    xy = _event_window_xy(event)
    if xy is None:
        return (None, None, None)
    mx, my = xy
    windows = []
    try:
        win = getattr(context, 'window', None)
        if win is not None:
            windows.append(win)
    except Exception:
        pass
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        for win in getattr(wm, 'windows', ()) or ():
            if win not in windows:
                windows.append(win)
    except Exception:
        pass
    for window in windows:
        try:
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                ax, ay = float(area.x), float(area.y)
                aw, ah = float(area.width), float(area.height)
                if not (ax <= mx < ax + aw and ay <= my < ay + ah):
                    continue
                region = None
                for r in getattr(area, 'regions', ()) or ():
                    if getattr(r, 'type', None) != 'WINDOW':
                        continue
                    rx, ry = float(r.x), float(r.y)
                    rw, rh = float(r.width), float(r.height)
                    if rx <= mx < rx + rw and ry <= my < ry + rh:
                        region = r
                        break
                if region is not None:
                    return (window, area, region)
                # Header/sidebar/tool-bar clicks inside a View3D area are still
                # Blender UI operations, not 3D View WINDOW selection events.
                continue
        except Exception:
            continue
    return (None, None, None)


_SSG_POINTER_EVENT_TYPES = {
    'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE',
    'BUTTON4MOUSE', 'BUTTON5MOUSE', 'BUTTON6MOUSE', 'BUTTON7MOUSE',
    'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'EVT_TWEAK_L', 'EVT_TWEAK_M', 'EVT_TWEAK_R',
    'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM',
}


def _event_is_pointer_event(event) -> bool:
    try:
        return str(getattr(event, 'type', '') or '') in _SSG_POINTER_EVENT_TYPES
    except Exception:
        return False


def _event_over_view3d_window_region(context, event) -> bool:
    try:
        _window, area, region = _find_view3d_from_event(context, event)
        return area is not None and getattr(area, 'type', None) == 'VIEW_3D' and region is not None and getattr(region, 'type', None) == 'WINDOW'
    except Exception:
        return False


def _event_region_xy(event, region):
    try:
        rx = float(getattr(event, 'mouse_region_x'))
        ry = float(getattr(event, 'mouse_region_y'))
        if rx >= 0.0 and ry >= 0.0:
            return (rx, ry)
    except Exception:
        pass
    try:
        xy = _event_window_xy(event)
        if xy is None or region is None:
            return None
        return (float(xy[0]) - float(region.x), float(xy[1]) - float(region.y))
    except Exception:
        return None

def _select_box_action_from_mode(mode: str = 'SET') -> str:
    mode = str(mode or 'SET').upper()
    if mode in {'SUB', 'DESELECT'}:
        return 'DESELECT'
    if mode in {'XOR', 'TOGGLE'}:
        return 'TOGGLE'
    if mode in {'ADD', 'SELECT'}:
        return 'ADD'
    return 'SET'


def _select_through_box_supplement_allowed(tool_id: str) -> bool:
    """Return True only when a rectangular fallback matches the active tool."""
    return str(tool_id or '') == 'builtin.select_box'


def _select_through_fallback_box(context, area, region, press_pos, release_pos, *, shift=False, ctrl=False, alt=False, action=None, require_select_tool: bool = True, min_drag_px: float = 4.0) -> bool:
    if area is None or getattr(area, 'type', None) != 'VIEW_3D' or region is None or getattr(region, 'type', None) != 'WINDOW':
        return False
    if require_select_tool and not _is_select_tool_active(context):
        return False
    rect = _screen_rect_from_points(press_pos, release_pos)
    if rect is None:
        return False
    try:
        xmin, xmax, ymin, ymax = rect
        min_px = max(0.0, float(min_drag_px))
        if ((xmax - xmin) ** 2 + (ymax - ymin) ** 2) <= (min_px * min_px):
            return False
    except Exception:
        return False
    action = str(action or _select_action_from_event_state(shift=shift, ctrl=ctrl, alt=alt) or 'SET').upper()
    mode = str(getattr(context, 'mode', '') or '')
    if mode == 'EDIT_MESH':
        return _select_through_fallback_edit_mesh_box(context, area, region, rect, action=action)
    if mode == 'OBJECT':
        return _select_through_fallback_object_box(context, area, region, rect, action=action)
    return False

def _is_view_wireframe(area):
    try:
        space = area.spaces.active
        sh = getattr(space, "shading", None)
        if sh and getattr(sh, "type", "") == 'WIREFRAME':
            return True
    except Exception:
        pass
    return False

def _view_state_key(area, rv3d):
    """Cheap-ish view key for caching across frames."""
    try:
        space = area.spaces.active
        lens = getattr(space, "lens", 50.0)
    except Exception:
        lens = 50.0
    try:
        loc = tuple(round(float(x), 4) for x in getattr(rv3d, "view_location", (0.0, 0.0, 0.0)))
        rot = getattr(rv3d, "view_rotation", None)
        rot_t = tuple(round(float(x), 4) for x in (rot[:] if rot else (1.0, 0.0, 0.0, 0.0)))
        dist = round(float(getattr(rv3d, "view_distance", 0.0)), 4)
        persp = str(getattr(rv3d, "view_perspective", ""))
    except Exception:
        loc, rot_t, dist, persp = (0.0, 0.0, 0.0), (1.0, 0.0, 0.0, 0.0), 0.0, ""
    return (persp, lens, dist, loc, rot_t)

# =========================================================
# Quality params
# =========================================================

_PRESET_PARAMS = {
    'FAST': {
        "max_steps": 10,
        "vertex_samples": 1,
        "vertex_radius": 1,
        "edge_samples": 3,
        "face_limit": 6,
        "object_limit": 2,
        "cache_seconds": 0.25,
        "idle_skip": 6,
        "eps": 0.0008,
        "target_margin": 0.0035,
    },
    'BALANCED': {
        "max_steps": 18,
        "vertex_samples": 3,
        "vertex_radius": 2,
        "edge_samples": 5,
        "face_limit": 12,
        "object_limit": 999,
        "cache_seconds": 0.15,
        "idle_skip": 4,
        "eps": 0.0005,
        "target_margin": 0.0030,
    },
    'PRECISE': {
        "max_steps": 26,
        "vertex_samples": 5,
        "vertex_radius": 2,
        "edge_samples": 7,
        "face_limit": 20,
        "object_limit": 999,
        "cache_seconds": 0.10,
        "idle_skip": 3,
        "eps": 0.0004,
        "target_margin": 0.0025,
    },
}

def _get_params(scene):
    preset = getattr(scene, "ssg_quality_preset", 'BALANCED')

    if preset == 'CUSTOM':
        return {
            "max_steps": int(getattr(scene, "ssg_max_steps", 18)),
            "vertex_samples": int(getattr(scene, "ssg_vertex_screen_samples", 3)),
            "vertex_radius": int(getattr(scene, "ssg_vertex_sample_radius_px", 2)),
            "edge_samples": int(getattr(scene, "ssg_edge_sample_count", 5)),
            "face_limit": int(getattr(scene, "ssg_face_sample_limit", 12)),
            "object_limit": int(getattr(scene, "ssg_object_sample_limit", 999)),
            "cache_seconds": float(getattr(scene, "ssg_cache_seconds", 0.15)),
            "idle_skip": int(getattr(scene, "ssg_idle_signature_skip", 4)),
            "eps": float(getattr(scene, "ssg_eps", 0.0005)),
            "target_margin": float(getattr(scene, "ssg_target_depth_margin", 0.0030)),
        }

    if preset == 'PRECISE':
        return dict(_PRESET_PARAMS['PRECISE'])
    if preset == 'FAST':
        return dict(_PRESET_PARAMS['FAST'])
    return dict(_PRESET_PARAMS['BALANCED'])

def _screen_offsets(n, radius_px):
    radius_px = int(max(0, radius_px))
    if n <= 1 or radius_px <= 0:
        return [(0, 0)]

    # prefer stable small patterns
    base = [(0, 0), (radius_px, 0), (-radius_px, 0), (0, radius_px), (0, -radius_px)]
    if n <= 5:
        return base[:n]

    diag = [(radius_px, radius_px), (-radius_px, radius_px), (radius_px, -radius_px), (-radius_px, -radius_px)]
    pts = base + diag
    return pts[:min(n, len(pts))]

# =========================================================
# Ray cast occlusion
# =========================================================

def _ray_occluded_iterative(
    scene,
    depsgraph,
    region,
    rv3d,
    co_world,
    eps=1e-4,
    source_obj=None,
    ignore_face_indices=None,
    ignore_objects=None,
    allowed_objects=None,
    bypass_occluder_objects=None,
    max_steps=18,
    ignore_backface=False,
    target_margin=0.0030,
    co_2d_override=None,
):
    co_2d = co_2d_override if co_2d_override is not None else _world_to_region_2d(region, rv3d, co_world)
    if co_2d is None:
        return False

    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co_2d)
    ray_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, co_2d)

    if ray_origin is None or ray_dir is None:
        return False

    try:
        ray_dir = ray_dir.normalized()
    except Exception:
        return False

    # target depth along this ray (projection). Works even if co_world slightly off this ray.
    to_target = (co_world - ray_origin)
    t_target = float(ray_dir.dot(to_target))
    if t_target <= eps:
        return False

    ignore_face_indices = ignore_face_indices or set()
    ignore_objects = ignore_objects or set()
    bypass_occluder_objects = bypass_occluder_objects or set()
    source_obj = _orig_obj(source_obj) if source_obj else None

    step_eps = max(float(eps), 1e-5)
    visible_margin = max(step_eps * 6.0, float(target_margin))

    cast_origin = ray_origin + ray_dir * step_eps
    traveled_t = step_eps

    for _ in range(int(max_steps)):
        remaining = (t_target - traveled_t) + (step_eps * 2.0)
        if remaining <= step_eps:
            return False

        hit, hit_loc, hit_no, hit_face_index, hit_obj_eval, _hit_mat = scene.ray_cast(
            depsgraph, cast_origin, ray_dir, distance=remaining
        )
        if not hit or hit_loc is None:
            return False

        t_hit = float(ray_dir.dot(hit_loc - ray_origin))
        if t_hit >= (t_target - visible_margin):
            return False

        hit_obj = _orig_obj(hit_obj_eval)

        # Ignored occluders
        try:
            if getattr(hit_obj, "ssg_ignore_as_occluder", False):
                cast_origin = hit_loc + ray_dir * step_eps
                traveled_t = float(ray_dir.dot(cast_origin - ray_origin))
                continue
        except Exception:
            pass

        if hit_obj in bypass_occluder_objects:
            cast_origin = hit_loc + ray_dir * step_eps
            traveled_t = float(ray_dir.dot(cast_origin - ray_origin))
            continue

        # Allowed objects filter
        if allowed_objects is not None and hit_obj not in allowed_objects:
            cast_origin = hit_loc + ray_dir * step_eps
            traveled_t = float(ray_dir.dot(cast_origin - ray_origin))
            continue

        if hit_obj in ignore_objects:
            cast_origin = hit_loc + ray_dir * step_eps
            traveled_t = float(ray_dir.dot(cast_origin - ray_origin))
            continue

        if (
            source_obj is not None and
            hit_obj == source_obj and
            hit_face_index is not None and
            hit_face_index in ignore_face_indices
        ):
            cast_origin = hit_loc + ray_dir * step_eps
            traveled_t = float(ray_dir.dot(cast_origin - ray_origin))
            continue

        if ignore_backface and hit_no is not None:
            try:
                # backfacing if normal points away from the ray origin (same direction as ray)
                if float(hit_no.dot(ray_dir)) > 0.0:
                    cast_origin = hit_loc + ray_dir * step_eps
                    traveled_t = float(ray_dir.dot(cast_origin - ray_origin))
                    continue
            except Exception:
                pass

        return True

    return False

# =========================================================
# Sampling
# =========================================================

def _object_sample_points_world(obj, limit=999):
    mw = obj.matrix_world
    points = [mw.translation.copy()]
    try:
        bb = [mw @ Vector(corner) for corner in obj.bound_box]
        if bb:
            center = sum(bb, Vector((0.0, 0.0, 0.0))) / len(bb)
            points.append(center)
            points.extend(bb)
    except Exception:
        pass
    if limit is not None:
        return points[:max(1, int(limit))]
    return points

def _edge_sample_points_world(obj, edge, count=5):
    mw = obj.matrix_world
    v0 = edge.verts[0].co
    v1 = edge.verts[1].co
    count = max(1, int(count))
    # evenly spaced inside (avoid endpoints)
    ts = [(i + 1) / (count + 1) for i in range(count)]
    return [mw @ v0.lerp(v1, t) for t in ts]

def _face_sample_points_world(obj, face, limit=12):
    mw = obj.matrix_world
    samples = []
    c = face.calc_center_median()
    samples.append(mw @ c)

    verts = list(face.verts)
    if verts:
        for v in verts[:8]:
            samples.append(mw @ c.lerp(v.co, 0.70))

        count = 0
        for e in face.edges:
            ev0 = e.verts[0].co
            ev1 = e.verts[1].co
            samples.append(mw @ ((ev0 + ev1) * 0.5))
            count += 1
            if count >= 8:
                break

    limit = max(1, int(limit))
    return samples[:limit]


def _edge_sample_points_world_confirm_fast(obj, edge):
    """Small edge sample set for post-selection confirmation filters.

    Smart Select Guard's normal edge test can be expensive on dense meshes
    because it samples each selected edge several times and repeats every
    sample with screen offsets.  For the immediate selection-confirmation pass
    we only need to reject clearly hidden elements; checking both endpoints and
    the midpoint preserves the visible-edge cases users expect while avoiding
    the heavy multi-offset scan.
    """
    try:
        mw = obj.matrix_world
        v0 = edge.verts[0].co
        v1 = edge.verts[1].co
        mid = v0.lerp(v1, 0.5)
        return [mw @ v0, mw @ mid, mw @ v1]
    except Exception:
        try:
            return _edge_sample_points_world(obj, edge, count=1)
        except Exception:
            return []


def _face_sample_points_world_confirm_fast(obj, face):
    """Small face sample set for immediate post-selection filtering."""
    try:
        mw = obj.matrix_world
        c = face.calc_center_median()
        samples = [mw @ c]
        verts = list(face.verts)
        if verts:
            # Use up to three corners blended toward the center so partially
            # visible faces are not discarded solely because the center is hidden.
            for v in verts[:3]:
                samples.append(mw @ c.lerp(v.co, 0.75))
        return samples
    except Exception:
        try:
            return _face_sample_points_world(obj, face, limit=3)
        except Exception:
            return []


def _bmesh_fix_ghost_overlay_light(bm, removed_elems=None):
    """Minimal active/history cleanup for performance-critical selection passes."""
    if removed_elems:
        for elem in removed_elems:
            _bmesh_remove_from_history(bm, elem)
    try:
        active = bm.select_history.active
    except Exception:
        active = None
    try:
        if active is not None and hasattr(active, 'select') and not bool(active.select):
            bm.select_history.remove(active)
    except Exception:
        pass

# =========================================================
# Selection signature
# =========================================================

def _sig_from_indices(indices_iter):
    cnt = 0
    x = 0
    s = 0
    s2 = 0
    for i in indices_iter:
        cnt += 1
        x ^= i
        s += i
        s2 += i * i
    return (cnt, x, s, s2)

def _selection_signature(context):
    mode = context.mode

    if mode == 'OBJECT':
        names = tuple(sorted(obj.name_full for obj in context.selected_objects if obj))
        active = context.active_object.name_full if context.active_object else ""
        return ("OBJECT", active, names)

    if mode == 'EDIT_MESH':
        objs = [o for o in getattr(context, "objects_in_mode", []) if o and o.type == 'MESH']
        if not objs:
            obj = context.edit_object
            if not obj:
                return ("EDIT_MESH", "")
            objs = [obj]

        data = []
        for o in sorted(objs, key=lambda x: x.name_full):
            try:
                o.update_from_editmode()
            except Exception:
                pass
            me = o.data

            v_sig = _sig_from_indices(v.index for v in me.vertices if v.select and not v.hide)
            e_sig = _sig_from_indices(e.index for e in me.edges if e.select and not e.hide)
            f_sig = _sig_from_indices(p.index for p in me.polygons if p.select and not p.hide)

            data.append((o.name_full, v_sig, e_sig, f_sig))

        active = context.edit_object.name_full if context.edit_object else ""
        return ("EDIT_MESH", active, tuple(data))

    return (str(mode),)

# =========================================================
# Fix ghost overlay
# =========================================================

def _bmesh_remove_from_history(bm, elem):
    try:
        bm.select_history.remove(elem)
    except Exception:
        pass

def _bmesh_fix_active_if_needed(bm):
    try:
        active = bm.select_history.active
    except Exception:
        active = None

    if active is None:
        return

    try:
        is_sel = bool(getattr(active, "select", False))
    except Exception:
        is_sel = False

    if is_sel:
        return

    try:
        bm.select_history.active = None
    except Exception:
        pass

    new_active = None
    for v in bm.verts:
        if v.select and not v.hide:
            new_active = v
            break
    if new_active is None:
        for e in bm.edges:
            if e.select and not e.hide:
                new_active = e
                break
    if new_active is None:
        for f in bm.faces:
            if f.select and not f.hide:
                new_active = f
                break

    if new_active is not None:
        try:
            bm.select_history.add(new_active)
        except Exception:
            pass

def _bmesh_fix_ghost_overlay(bm, removed_elems=None):
    if removed_elems:
        for elem in removed_elems:
            _bmesh_remove_from_history(bm, elem)

    try:
        for elem in list(bm.select_history):
            try:
                if hasattr(elem, "select") and (not elem.select):
                    bm.select_history.remove(elem)
            except Exception:
                pass
    except Exception:
        pass

    for seq_name in ("faces", "edges", "verts"):
        try:
            seq = getattr(bm, seq_name)
            act = getattr(seq, "active", None)
        except Exception:
            continue
        if act is None:
            continue
        try:
            if (not getattr(act, "select", False)) or getattr(act, "hide", False):
                setattr(seq, "active", None)
        except Exception:
            pass

    _bmesh_fix_active_if_needed(bm)

# =========================================================
# Cache helpers
# =========================================================

def _cache_prune(cache, now, max_age):
    if max_age <= 0.0:
        cache.clear()
        return
    try:
        size = len(cache)
    except Exception:
        return
    # Keep the visibility cache bounded even when all selected elements remain
    # visible and no selection changes are made.  Previously those no-change runs
    # skipped pruning, so continued selection work could leave a large stale dict
    # behind and make later Select Guard checks progressively heavier.
    if size <= int(_SSG_CACHE_SOFT_LIMIT):
        return
    dead = [k for k, (t, _v) in cache.items() if (now - t) > max_age]
    for k in dead:
        cache.pop(k, None)
    try:
        size = len(cache)
    except Exception:
        return
    if size <= int(_SSG_CACHE_HARD_LIMIT):
        return
    try:
        # Drop the oldest half instead of sorting on every normal prune.
        survivors = sorted(cache.items(), key=lambda item: item[1][0], reverse=True)[:int(_SSG_CACHE_HARD_LIMIT // 2)]
        cache.clear()
        cache.update(survivors)
    except Exception:
        cache.clear()

def _cache_get(key, max_age):
    cache = _SSG_RUNTIME["cache"]
    now = time.monotonic()
    item = cache.get(key)
    if not item:
        return None
    t, v = item
    if (now - t) > max_age:
        cache.pop(key, None)
        return None
    return v

def _cache_set(key, value):
    _SSG_RUNTIME["cache"][key] = (time.monotonic(), bool(value))

# =========================================================
# Core filter
# =========================================================

def select_guard_filter_selection(context, area=None, region=None):
    scene = context.scene
    if not getattr(scene, "select_guard_enabled", False):
        return False, None

    if area and region and area.type == 'VIEW_3D' and region.type == 'WINDOW':
        space = area.spaces.active
        rv3d = getattr(space, "region_3d", None) if space else None
        if not rv3d:
            return False, None
    else:
        area, region, rv3d = _find_view3d_window_region(context)
        if not area or not region or not rv3d:
            return False, None

    # Select-through selection sessions intentionally keep back-side/occluded
    # elements selected.  Only suppress the occlusion filter while that actual
    # click/drag confirmation is active or immediately finalizing; otherwise the
    # original Smart Select Guard occlusion filter remains available.
    if _select_guard_occlusion_filter_suppressed():
        return False, None

    # Auto bypass in special view modes
    if getattr(scene, "ssg_auto_bypass_xray", True) and _is_view_xray(area):
        return False, None
    if getattr(scene, "ssg_auto_bypass_wireframe", True) and _is_view_wireframe(area):
        return False, None

    depsgraph = context.evaluated_depsgraph_get()

    other_objects_occlude = getattr(scene, "ssg_other_objects_occlude", False)
    multi_edit_mutual_occlude = getattr(scene, "ssg_multi_edit_mutual_occlude", True)
    ignore_backface = getattr(scene, "ssg_ignore_backface_occluders", False)
    partial_ratio_min = float(getattr(scene, "ssg_partial_visible_ratio_min", 0.0))

    params = _get_params(scene)
    fast_confirm_pass = bool(_SSG_RUNTIME.get("fast_confirm_filter", False))
    eps = float(params.get("eps", 0.0005))
    max_steps = int(params.get("max_steps", 18))
    target_margin = float(params.get("target_margin", 0.0030))
    if fast_confirm_pass:
        # Selection-confirmation filtering must be responsive.  Keep the same
        # occlusion rule, but use a single screen sample and a short ray walk so
        # dense edge/face selections do not stall the viewport after release.
        max_steps = min(max_steps, 8)

    cache_seconds = float(max(0.0, params.get("cache_seconds", 0.15)))
    if fast_confirm_pass:
        cache_seconds = max(cache_seconds, 0.85)
    view_key = _view_state_key(area, rv3d)
    settings_key = (
        context.mode,
        other_objects_occlude,
        multi_edit_mutual_occlude,
        ignore_backface,
        round(partial_ratio_min, 3),
        params.get("max_steps"),
        params.get("vertex_samples"),
        params.get("vertex_radius"),
        params.get("edge_samples"),
        params.get("face_limit"),
        round(eps, 6),
        round(target_margin, 6),
        bool(fast_confirm_pass),
    )

    if _SSG_RUNTIME.get("cache_view_key") != view_key or _SSG_RUNTIME.get("cache_settings_key") != settings_key:
        _SSG_RUNTIME["cache"].clear()
        _SSG_RUNTIME["cache_view_key"] = view_key
        _SSG_RUNTIME["cache_settings_key"] = settings_key

    bypass_occluder_objects = _ssg_get_excluded_occluder_objects(scene)

    stats = {
        "obj": 0,
        "v": 0,
        "e": 0,
        "f": 0,
    }

    mode = context.mode

    if mode == 'OBJECT':
        selected = [o for o in context.selected_objects if o and o.type == 'MESH' and o.visible_get()]
        if not selected:
            return False, None

        changed_any = False

        object_limit = int(params.get("object_limit", 999))

        for obj in selected:
            obj_orig = _orig_obj(obj)
            ignore_objects = {obj_orig}

            visible_any = False
            for p in _object_sample_points_world(obj, limit=object_limit):
                cache_key = ("OBJ", obj_orig.as_pointer(), p.x, p.y, p.z, view_key)
                cached = _cache_get(cache_key, cache_seconds)
                if cached is not None:
                    if not cached:
                        visible_any = True
                        break
                    continue

                occluded = _ray_occluded_iterative(
                    scene, depsgraph, region, rv3d, p,
                    eps=eps,
                    source_obj=None,
                    ignore_face_indices=None,
                    ignore_objects=ignore_objects,
                    allowed_objects=None,
                    bypass_occluder_objects=bypass_occluder_objects,
                    max_steps=max_steps,
                    ignore_backface=ignore_backface,
                    target_margin=target_margin,
                )
                _cache_set(cache_key, occluded)

                if not occluded:
                    visible_any = True
                    break

            if not visible_any:
                obj.select_set(False)
                changed_any = True
                stats["obj"] += 1

        if changed_any:
            try:
                vl = context.view_layer
                if vl.objects.active and (vl.objects.active not in context.selected_objects):
                    vl.objects.active = next(iter(context.selected_objects), None)
            except Exception:
                pass

        _cache_prune(_SSG_RUNTIME["cache"], time.monotonic(), cache_seconds)
        return changed_any, (stats if changed_any else None)

    if mode == 'EDIT_MESH':
        edit_objs = [o for o in getattr(context, "objects_in_mode", []) if o and o.type == 'MESH']
        if not edit_objs:
            obj = context.edit_object
            if not obj or obj.type != 'MESH':
                return False, None
            edit_objs = [obj]

        edit_set = set(_orig_obj(o) for o in edit_objs)
        allowed_objects = None if other_objects_occlude else set(edit_set)
        changed_any = False

        if fast_confirm_pass:
            v_offsets = [(0, 0)]
            edge_samples = 3
            face_limit = 4
        else:
            v_offsets = _screen_offsets(int(params.get("vertex_samples", 1)), int(params.get("vertex_radius", 1)))
            edge_samples = int(params.get("edge_samples", 5))
            face_limit = int(params.get("face_limit", 12))

        for obj in edit_objs:
            obj_orig = _orig_obj(obj)

            try:
                obj.update_from_editmode()
            except Exception:
                pass

            me = obj.data
            bm = bmesh.from_edit_mesh(me)

            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            try:
                bm.verts.index_update()
                bm.edges.index_update()
                bm.faces.index_update()
            except Exception:
                pass

            use_v, use_e, use_f = context.tool_settings.mesh_select_mode[:]
            mw = obj.matrix_world

            if fast_confirm_pass:
                try:
                    selected_count = 0
                    if use_v:
                        selected_count += sum(1 for v in bm.verts if v.select and not v.hide)
                    if use_e:
                        selected_count += sum(1 for e in bm.edges if e.select and not e.hide)
                    if use_f:
                        selected_count += sum(1 for f in bm.faces if f.select and not f.hide)
                    if selected_count > _SSG_FAST_CONFIRM_MAX_EDIT_ELEMENTS:
                        # Avoid a visible confirmation stall on dense selections.
                        # Existing Blender region-selection results are left intact.
                        continue
                except Exception:
                    pass

            ignore_objects = set()
            if (not multi_edit_mutual_occlude) and len(edit_set) >= 2:
                ignore_objects |= (edit_set - {obj_orig})

            changed = False
            deselected_elems = []

            if use_v:
                for v in bm.verts:
                    if not v.select or v.hide:
                        continue

                    # cache per-vertex per view
                    cache_key = ("V", obj_orig.as_pointer(), int(v.index), view_key)
                    cached = _cache_get(cache_key, cache_seconds)
                    if cached is not None:
                        if cached:
                            v.select = False
                            deselected_elems.append(v)
                            changed = True
                            stats["v"] += 1
                        continue

                    co_world = mw @ v.co
                    ignore_faces = {f.index for f in v.link_faces if not f.hide}

                    co_2d = _world_to_region_2d(region, rv3d, co_world)
                    if co_2d is None:
                        _cache_set(cache_key, False)
                        continue

                    visible_any = False
                    for dx, dy in v_offsets:
                        occluded = _ray_occluded_iterative(
                            scene, depsgraph, region, rv3d, co_world,
                            eps=eps,
                            source_obj=obj_orig,
                            ignore_face_indices=ignore_faces,
                            ignore_objects=ignore_objects,
                            allowed_objects=allowed_objects,
                            bypass_occluder_objects=bypass_occluder_objects,
                            max_steps=max_steps,
                            ignore_backface=ignore_backface,
                            target_margin=target_margin,
                            co_2d_override=(co_2d[0] + dx, co_2d[1] + dy),
                        )
                        if not occluded:
                            visible_any = True
                            break

                    if not visible_any:
                        v.select = False
                        deselected_elems.append(v)
                        changed = True
                        stats["v"] += 1
                        _cache_set(cache_key, True)
                    else:
                        _cache_set(cache_key, False)

            if use_e:
                for e in bm.edges:
                    if not e.select or e.hide:
                        continue

                    cache_key = ("E", obj_orig.as_pointer(), int(e.index), view_key)
                    cached = _cache_get(cache_key, cache_seconds)
                    if cached is not None:
                        if cached:
                            e.select = False
                            deselected_elems.append(e)
                            changed = True
                            stats["e"] += 1
                        continue

                    ignore_faces = {f.index for f in e.link_faces if not f.hide}
                    samples = (_edge_sample_points_world_confirm_fast(obj, e) if fast_confirm_pass else _edge_sample_points_world(obj, e, count=edge_samples))

                    visible_count = 0
                    edge_screen_offsets = [(0, 0)] if fast_confirm_pass else (v_offsets or [(0, 0)])
                    for co_world in samples:
                        co_2d = _world_to_region_2d(region, rv3d, co_world)
                        if co_2d is None:
                            continue
                        sample_visible = False
                        for dx, dy in edge_screen_offsets:
                            occluded = _ray_occluded_iterative(
                                scene, depsgraph, region, rv3d, co_world,
                                eps=eps,
                                source_obj=obj_orig,
                                ignore_face_indices=ignore_faces,
                                ignore_objects=ignore_objects,
                                allowed_objects=allowed_objects,
                                bypass_occluder_objects=bypass_occluder_objects,
                                max_steps=max_steps,
                                ignore_backface=ignore_backface,
                                target_margin=target_margin,
                                co_2d_override=(float(co_2d[0]) + float(dx), float(co_2d[1]) + float(dy)),
                            )
                            if not occluded:
                                sample_visible = True
                                break
                        if sample_visible:
                            visible_count += 1
                            if partial_ratio_min <= 0.0:
                                break

                    ratio = (visible_count / max(1, len(samples)))
                    visible_enough = (visible_count > 0) if partial_ratio_min <= 0.0 else (ratio >= partial_ratio_min)

                    if not visible_enough:
                        e.select = False
                        deselected_elems.append(e)
                        changed = True
                        stats["e"] += 1
                        _cache_set(cache_key, True)
                    else:
                        _cache_set(cache_key, False)

            if use_f:
                for f in bm.faces:
                    if not f.select or f.hide:
                        continue

                    cache_key = ("F", obj_orig.as_pointer(), int(f.index), view_key)
                    cached = _cache_get(cache_key, cache_seconds)
                    if cached is not None:
                        if cached:
                            f.select = False
                            deselected_elems.append(f)
                            changed = True
                            stats["f"] += 1
                        continue

                    ignore_faces = {f.index}
                    samples = (_face_sample_points_world_confirm_fast(obj, f) if fast_confirm_pass else _face_sample_points_world(obj, f, limit=face_limit))

                    visible_count = 0
                    edge_screen_offsets = [(0, 0)] if fast_confirm_pass else (v_offsets or [(0, 0)])
                    for co_world in samples:
                        co_2d = _world_to_region_2d(region, rv3d, co_world)
                        if co_2d is None:
                            continue
                        sample_visible = False
                        for dx, dy in edge_screen_offsets:
                            occluded = _ray_occluded_iterative(
                                scene, depsgraph, region, rv3d, co_world,
                                eps=eps,
                                source_obj=obj_orig,
                                ignore_face_indices=ignore_faces,
                                ignore_objects=ignore_objects,
                                allowed_objects=allowed_objects,
                                bypass_occluder_objects=bypass_occluder_objects,
                                max_steps=max_steps,
                                ignore_backface=ignore_backface,
                                target_margin=target_margin,
                                co_2d_override=(float(co_2d[0]) + float(dx), float(co_2d[1]) + float(dy)),
                            )
                            if not occluded:
                                sample_visible = True
                                break
                        if sample_visible:
                            visible_count += 1
                            if partial_ratio_min <= 0.0:
                                break

                    ratio = (visible_count / max(1, len(samples)))
                    visible_enough = (visible_count > 0) if partial_ratio_min <= 0.0 else (ratio >= partial_ratio_min)

                    if not visible_enough:
                        f.select = False
                        deselected_elems.append(f)
                        changed = True
                        stats["f"] += 1
                        _cache_set(cache_key, True)
                    else:
                        _cache_set(cache_key, False)

            if changed:
                bm.select_flush_mode()
                if fast_confirm_pass:
                    _bmesh_fix_ghost_overlay_light(bm, deselected_elems if deselected_elems else None)
                else:
                    _bmesh_fix_ghost_overlay(bm, deselected_elems if deselected_elems else None)

            if changed:
                bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
                changed_any = True

        _cache_prune(_SSG_RUNTIME["cache"], time.monotonic(), cache_seconds)
        return changed_any, (stats if changed_any else None)

    return False, None

# =========================================================
# Operators
# =========================================================

class VIEW3D_OT_select_guard_toggle(bpy.types.Operator):
    bl_idname = "view3d.select_guard_toggle"
    bl_label = "Smart Select Guard Toggle"
    bl_description = "Enable / disable the Smart Select Guard"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        sc = context.scene
        sc.select_guard_enabled = not sc.select_guard_enabled
        _tag_redraw_all_view3d()
        return {'FINISHED'}

class VIEW3D_OT_ssg_hold_enable_key_marker(bpy.types.Operator):
    bl_idname = _SSG_HOLD_ENABLE_OPERATOR_ID
    bl_label = "Assign Hold Key Shortcut"
    bl_description = "Right-click this button and use Assign Shortcut to choose any key. When assigned, Smart Select Guard works only while that key is held during selection. If no shortcut is assigned, the guard stays always active while enabled."
    bl_options = set()

    def invoke(self, context, event):
        try:
            scene = getattr(context, 'scene', None)
            et = _valid_hold_enable_event_type(getattr(event, 'type', ''))
            ev = str(getattr(event, 'value', '') or '')
            if scene is not None and et and et not in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'} and ev in {'PRESS', 'CLICK_DRAG'}:
                setattr(scene, 'ssg_hold_enable_key_event', et)
                _update_ssg_hold_enable_runtime_from_event(event, scene)
                _invalidate_ssg_hold_enable_key_cache()
                _request_select_guard_scene_setting_save(context)
                try:
                    self.report({'INFO'}, f"{iface_('Assigned Key')}: {_event_type_display_name(et)}")
                except Exception:
                    pass
        except Exception:
            pass
        return {'FINISHED'}

    def execute(self, context):
        return {'FINISHED'}


class VIEW3D_OT_ssg_clear_hold_enable_key_shortcut(bpy.types.Operator):
    bl_idname = "view3d.ssg_clear_hold_enable_key_shortcut"
    bl_label = "Clear Hold Key Shortcut"
    bl_description = "Remove Smart Select Guard enable-while-held shortcut assignments and return to always-active behavior."
    bl_options = {'INTERNAL'}

    def execute(self, context):
        removed = 0
        try:
            wm = getattr(context, 'window_manager', None)
            keyconfigs = []
            if wm is not None:
                keyconfigs = [getattr(wm.keyconfigs, 'user', None), getattr(wm.keyconfigs, 'addon', None)]
            for kc in keyconfigs:
                if kc is None:
                    continue
                for km in list(getattr(kc, 'keymaps', []) or []):
                    try:
                        for kmi in list(getattr(km, 'keymap_items', []) or []):
                            if str(getattr(kmi, 'idname', '') or '') == _SSG_HOLD_ENABLE_OPERATOR_ID:
                                try:
                                    km.keymap_items.remove(kmi)
                                    removed += 1
                                except Exception:
                                    try:
                                        kmi.active = False
                                        removed += 1
                                    except Exception:
                                        pass
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            _SSG_HELD_ENABLE_KEYS.clear()
        except Exception:
            pass
        try:
            scene = getattr(context, 'scene', None)
            if scene is not None:
                if hasattr(scene, 'ssg_hold_enable_key_event'):
                    scene.ssg_hold_enable_key_event = ''
                if hasattr(scene, 'ssg_hold_enable_key'):
                    scene.ssg_hold_enable_key = 'NONE'
                _invalidate_ssg_hold_enable_key_cache()
        except Exception:
            pass
        _request_select_guard_scene_setting_save(context)
        try:
            self.report({'INFO'}, f"{iface_('Hold-key shortcuts cleared')} ({removed})")
        except Exception:
            pass
        return {'FINISHED'}


class VIEW3D_OT_ssg_toggle_occluder_ignore_selected(bpy.types.Operator):
    bl_idname = "view3d.ssg_toggle_occluder_ignore_selected"
    bl_label = "Toggle Occluder Ignore (Selected)"
    bl_description = "Toggle ignoring selected objects as occluders"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        changed = 0
        for obj in context.selected_objects or []:
            if not obj:
                continue
            try:
                obj.ssg_ignore_as_occluder = not bool(getattr(obj, "ssg_ignore_as_occluder", False))
                changed += 1
            except Exception:
                pass
        if changed:
            _SSG_RUNTIME["cache"].clear()
            _tag_redraw_all_view3d()
        return {'FINISHED'}


class VIEW3D_OT_ssg_select_box_public(bpy.types.Operator):
    """Arm select-through before delegating the public Box gesture to Blender."""

    bl_idname = "view3d.ssg_select_box_public"
    bl_label = "Box Select"
    bl_description = "Run Blender Box Select with Smart Select Guard select-through state prepared before native dispatch"
    bl_options = {'INTERNAL'}

    mode: bpy.props.EnumProperty(
        name="Selection Mode",
        items=(
            ('SET', "Set", "Replace the current selection"),
            ('ADD', "Extend", "Add to the current selection"),
            ('SUB', "Subtract", "Subtract from the current selection"),
            ('XOR', "Difference", "Toggle the selected state"),
            ('AND', "Intersect", "Keep only the intersection with the current selection"),
        ),
        default='SET',
        options={'SKIP_SAVE'},
    )
    wait_for_input: bpy.props.BoolProperty(default=True, options={'SKIP_SAVE'})

    _select_through_token = None

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        return bool(
            area is not None
            and getattr(area, 'type', None) == 'VIEW_3D'
            and region is not None
            and getattr(region, 'type', None) == 'WINDOW'
        )

    def _finish_select_through(self, *, cancelled=False):
        token = self._select_through_token
        self._select_through_token = None
        if token is None:
            return
        finish_external_select_through_xray(
            token,
            delay=0.0 if cancelled else 0.04,
            cancelled=bool(cancelled),
        )

    def invoke(self, context, event):
        self._select_through_token = begin_external_select_through_xray(context, event)
        try:
            result = bpy.ops.view3d.select_box(
                'INVOKE_DEFAULT',
                mode=self.mode,
                wait_for_input=bool(self.wait_for_input),
            )
        except Exception:
            self._finish_select_through(cancelled=True)
            raise

        if 'RUNNING_MODAL' not in set(result or ()):
            self._finish_select_through(cancelled=('CANCELLED' in set(result or ())))
            return result
        if self._select_through_token is None:
            return result
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        etype = str(getattr(event, 'type', '') or '')
        evalue = str(getattr(event, 'value', '') or '')
        if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
            self._finish_select_through(cancelled=False)
            return {'FINISHED', 'PASS_THROUGH'}
        if etype in {'ESC', 'RIGHTMOUSE'} and evalue in {'PRESS', 'RELEASE'}:
            self._finish_select_through(cancelled=True)
            return {'CANCELLED', 'PASS_THROUGH'}
        touch_external_select_through_xray(self._select_through_token)
        return {'PASS_THROUGH'}

    def cancel(self, _context):
        self._finish_select_through(cancelled=True)


def _register_public_select_box_keymap():
    _unregister_public_select_box_keymap()
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        keyconfig = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
        if keyconfig is None:
            return
        keymap = keyconfig.keymaps.new(name='3D View', space_type='VIEW_3D')
        item = keymap.keymap_items.new(
            VIEW3D_OT_ssg_select_box_public.bl_idname,
            type='B',
            value='PRESS',
        )
        item.properties.mode = 'SET'
        item.properties.wait_for_input = True
        _SSG_PUBLIC_SELECT_BOX_KEYMAP_ITEMS.append((keymap, item))
    except Exception as ex:
        _ssg_record_diagnostic_once('public_select_box_keymap_register', ex)


def _unregister_public_select_box_keymap():
    for keymap, item in reversed(list(_SSG_PUBLIC_SELECT_BOX_KEYMAP_ITEMS)):
        try:
            keymap.keymap_items.remove(item)
        except Exception:
            pass
    _SSG_PUBLIC_SELECT_BOX_KEYMAP_ITEMS.clear()

class VIEW3D_OT_ssg_apply_prefs_to_scene(bpy.types.Operator):
    bl_idname = "view3d.ssg_apply_prefs_to_scene"
    bl_label = "Apply Preferences Defaults to Scene"
    bl_description = "Apply addon preference defaults to current scene"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        _apply_prefs_defaults_to_scene(context, force=True)
        _tag_redraw_all_view3d()
        return {'FINISHED'}

def _ssg_window_key(window) -> int:
    try:
        return int(window.as_pointer()) if window is not None else 0
    except Exception:
        return id(window) if window is not None else 0


class VIEW3D_OT_select_guard_modal(bpy.types.Operator):
    bl_idname = "view3d.select_guard_modal"
    bl_label = "Smart Select Guard Modal"
    bl_description = "Internal modal watcher that applies Smart Select Guard filtering while you work in the 3D View"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    _timer = None
    _running = False
    _instance = None
    _instances_by_window = {}
    _window_key = 0

    @classmethod
    def _instance_for_context(cls, context=None):
        try:
            window = getattr(context or getattr(bpy, 'context', None), 'window', None)
            key = _ssg_window_key(window)
            if key:
                instance = cls._instances_by_window.get(key)
                if instance is not None:
                    return instance
        except Exception:
            pass
        return cls._instance

    _last_window = None
    _last_area = None
    _last_region = None

    _last_signature = None
    _burst_frames = 0
    _cooldown_frames = 0

    _press_pos = None
    _CLICK_THRESHOLD_PX = 4

    _suspend_frames = 0
    _suspend_until = 0.0
    _last_seen_wm_op = ""

    _BURST = 1

    _BYPASS_OPS = {
        "MESH_OT_select_linked",
        "MESH_OT_select_more",
        "MESH_OT_select_less",
        "MESH_OT_loop_select",
        "MESH_OT_edgering_select",
        "MESH_OT_select_loop",
        "MESH_OT_select_ring",
        "MESH_OT_select_nth",
        "MESH_OT_shortest_path_select",
    }

    # modifier state (for hold-to-bypass)
    _mod_shift = False
    _mod_ctrl = False
    _mod_alt = False
    _held_event_keys = None

    _idle_ticks = 0

    # status feedback
    _status_text = ""
    _status_frames = 0

    _select_through_restore_state = None
    _select_through_restore_pending = False
    _select_through_press_state = None
    _select_through_candidate_state = None
    _select_through_session_id = 0
    _select_guard_gesture_state = None

    def _begin_select_guard_gesture(self, context, event, specified_key_active=True):
        self._select_guard_gesture_state = None
        region = self._last_region if getattr(self._last_region, 'type', None) == 'WINDOW' else getattr(context, 'region', None)
        pos = _event_region_xy(event, region)
        self._press_pos = pos
        if not specified_key_active or pos is None:
            return None
        try:
            state = _ssg_pointer_selection_gesture_state(context, event, pos=pos, area=getattr(context, 'area', None), region=region)
        except Exception:
            state = None
        if isinstance(state, dict):
            self._select_guard_gesture_state = state
        return self._select_guard_gesture_state

    def _clear_select_guard_gesture(self):
        self._select_guard_gesture_state = None

    def _store_current_view3d(self, context, event=None):
        if event is not None and _event_is_pointer_event(event):
            try:
                window, area, region = _find_view3d_from_event(context, event)
                if window is not None and area is not None and region is not None:
                    self._last_window = window
                    self._last_area = area
                    self._last_region = region
            except Exception:
                pass
            return

        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        window = getattr(context, "window", None)

        if (
            window is not None and
            area is not None and area.type == 'VIEW_3D' and
            region is not None and region.type == 'WINDOW'
        ):
            self._last_window = window
            self._last_area = area
            self._last_region = region
            return

    def _iter_all_view3d_overrides(self):
        wm = bpy.context.window_manager
        if not wm:
            return
        for window in wm.windows:
            screen = window.screen
            if not screen:
                continue
            for area in screen.areas:
                if area.type != 'VIEW_3D':
                    continue
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                if not region:
                    continue
                yield (window, area, region)

    def _run_filter(self, context):
        scene = context.scene
        scope = getattr(scene, "ssg_view_scope", 'ACTIVE')

        changed_any = False
        agg = {"obj": 0, "v": 0, "e": 0, "f": 0}

        def _merge_stats(s):
            if not s:
                return
            for k in agg.keys():
                try:
                    agg[k] += int(s.get(k, 0))
                except Exception:
                    pass

        if scope == 'ALL':
            for window, area, region in self._iter_all_view3d_overrides() or []:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    changed, stats = select_guard_filter_selection(
                        bpy.context,
                        area=area,
                        region=region,
                    )
                if changed:
                    changed_any = True
                    _merge_stats(stats)
        else:
            if self._last_window and self._last_area and self._last_region:
                with bpy.context.temp_override(
                    window=self._last_window,
                    area=self._last_area,
                    region=self._last_region,
                ):
                    changed, stats = select_guard_filter_selection(
                        bpy.context,
                        area=self._last_area,
                        region=self._last_region,
                    )
            else:
                changed, stats = select_guard_filter_selection(bpy.context)

            if changed:
                changed_any = True
                _merge_stats(stats)

        return changed_any, (agg if changed_any else None)

    def _arm_burst(self, frames):
        if frames > self._burst_frames:
            self._burst_frames = frames

    def _suspend_filter(self, frames):
        if frames > self._suspend_frames:
            self._suspend_frames = frames
        try:
            self._suspend_until = max(float(getattr(self, '_suspend_until', 0.0)), time.monotonic() + max(0.12, float(frames) * 0.035))
        except Exception:
            self._suspend_until = time.monotonic() + 0.25
        self._burst_frames = 0

    def _refresh_event_suspension(self):
        try:
            if self._suspend_frames > 0 and time.monotonic() >= float(getattr(self, '_suspend_until', 0.0)):
                self._suspend_frames = 0
                self._suspend_until = 0.0
        except Exception:
            self._suspend_frames = 0
            self._suspend_until = 0.0

    def _check_bypass_by_wm_last_operator(self, context):
        try:
            ops = context.window_manager.operators
            if not ops:
                return
            last = ops[-1]
            op_id = getattr(last, "bl_idname", "") or ""
            if not op_id or op_id == self._last_seen_wm_op:
                return
            self._last_seen_wm_op = op_id
            if op_id in self._BYPASS_OPS:
                self._suspend_filter(12)
        except Exception:
            pass

    def _update_status(self, context):
        if self._status_frames <= 0:
            try:
                context.workspace.status_text_set(None)
            except Exception:
                pass
            self._status_text = ""
            return

        try:
            context.workspace.status_text_set(text=self._status_text)
        except Exception:
            pass
        self._status_frames -= 1

    def _specified_hold_enable_active(self, scene, event=None):
        try:
            return _ssg_hold_enable_active(scene, event, getattr(bpy, 'context', None), self._held_event_keys)
        except Exception:
            return True

    def _hold_bypass_active(self, scene):
        # Deprecated: modifier-key bypass is intentionally disabled because it
        # conflicts with Blender's native Shift/Ctrl/Alt selection behavior.
        del scene
        return False

    def _select_through_area(self, context):
        area = getattr(context, "area", None)
        region = getattr(context, "region", None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D' and region is not None and getattr(region, 'type', None) == 'WINDOW':
            return area
        return self._last_area if getattr(self._last_area, 'type', None) == 'VIEW_3D' else None

    def _begin_select_through_xray_off(self, context, scene):
        if not _select_through_xray_off_enabled(scene):
            return False
        area = self._select_through_area(context)
        if area is None:
            return False
        # If the user already has X-Ray enabled, leave it alone; the normal
        # X-Ray workflow already selects through.
        if _is_view_xray(area):
            return False
        self._restore_select_through_xray_off()
        _cancel_pending_select_through_xray_restores(restore=True)
        changed = _set_view_xray_for_select_through(area, True)
        if not changed:
            return False
        current = self._select_through_restore_state
        if not isinstance(current, list):
            current = []
        current.extend(changed)
        self._select_through_restore_state = current
        self._select_through_session_id = _start_select_through_active_xray_session(
            changed, area, window=self._last_window,
        )
        return True

    def _restore_select_through_xray_state(self, state):
        if not state:
            return None
        tagged = set()
        try:
            entries = list(state)
        except Exception:
            entries = []
        for entry in reversed(entries):
            try:
                if isinstance(entry, dict):
                    area = entry.get('area')
                    if area is not None:
                        tagged.add(area)
                _restore_view_xray_entry(entry)
            except Exception:
                pass
        try:
            area = self._last_area
            if area is not None:
                tagged.add(area)
        except Exception:
            pass
        for area in tagged:
            try:
                area.tag_redraw()
            except Exception:
                pass
        return None

    def _restore_select_through_xray_off(self):
        state = self._select_through_restore_state
        self._select_through_restore_state = None
        self._select_through_restore_pending = False
        return self._restore_select_through_xray_state(state)

    def _force_restore_select_through_xray_off_tick(self, state=None):
        if state is not None:
            self._restore_select_through_xray_state(state)
            return None
        self._restore_select_through_xray_off()
        return None

    def _schedule_select_through_restore(self, delay=0.08):
        if not self._select_through_restore_state:
            return
        self._select_through_restore_pending = True
        try:
            state_snapshot = list(self._select_through_restore_state)
        except Exception:
            state_snapshot = self._select_through_restore_state
        try:
            last_area = self._last_area
        except Exception:
            last_area = None
        self._select_through_restore_state = None
        self._select_through_restore_pending = False
        restore_epoch = _cancel_pending_select_through_xray_restores(restore=False)
        _enqueue_select_through_xray_restore(
            state_snapshot,
            last_area,
            first_delay=max(0.01, float(delay)),
            duration=max(2.5, float(delay) + 2.0),
            restore_epoch=restore_epoch,
        )

    def _cancel_select_through_xray_session(self):
        """Restore this modal gesture once and retire every owned writer."""
        state = self._select_through_restore_state
        self._select_through_restore_state = None
        self._select_through_restore_pending = False
        self._select_through_session_id = 0
        if state:
            _cancel_pending_select_through_xray_restores(restore=False)
            self._restore_select_through_xray_state(state)
        else:
            # A delayed finalizer owns its snapshot globally after RELEASE.
            # Cancel/disable/unregister must reclaim that snapshot rather than
            # merely unregistering its callback and leaving temporary X-Ray ON.
            _cancel_pending_select_through_xray_restores(restore=True)

    def _schedule_select_through_finalize(self, state, delay=0.03):
        """Finalize select-through after Blender has processed the release.

        X-Ray stays enabled only for the native selection click/drag.  The
        delayed callback gives Blender's selection operator the release event,
        then applies the optional geometric box-selection supplement and restores
        the exact X-Ray state captured on mouse press, even if nothing was
        selected.
        """
        try:
            state_snapshot = dict(state or {})
        except Exception:
            state_snapshot = {}
        try:
            restore_entries = list(self._select_through_restore_state or [])
        except Exception:
            restore_entries = []
        try:
            restore_entries.extend(list(state_snapshot.get('view_xray_before') or []))
        except Exception:
            pass
        restore_entries = _unique_xray_restore_entries(restore_entries)
        state_snapshot['view_xray_before'] = restore_entries
        # RELEASE is now observed.  The local snapshot becomes the single
        # finalizer owner; retire both the active timer and any earlier closure.
        self._select_through_restore_state = None
        self._select_through_restore_pending = False
        self._select_through_session_id = 0
        restore_epoch = _cancel_pending_select_through_xray_restores(restore=False)

        def _finish(op=self, state=state_snapshot, epoch=restore_epoch):
            global _SSG_XRAY_FINALIZE_CALLBACK, _SSG_XRAY_FINALIZE_STATE
            global _SSG_XRAY_RESTORE_EPOCH
            owned = _SSG_XRAY_FINALIZE_STATE
            if (
                int(epoch) != int(_SSG_XRAY_RESTORE_EPOCH)
                or _SSG_XRAY_FINALIZE_CALLBACK is not _finish
                or not isinstance(owned, dict)
                or owned.get('callback') is not _finish
                or int(owned.get('epoch', -1)) != int(epoch)
            ):
                return None
            # Retire callback ownership before any Blender selection supplement
            # or restore code runs.  Re-entry and stale closures are strict no-ops.
            _SSG_XRAY_FINALIZE_CALLBACK = None
            _SSG_XRAY_FINALIZE_STATE = None
            _suppress_select_guard_occlusion_filter(0.55)
            area = state.get('area')
            region = state.get('region')
            window = state.get('window')
            before = state.get('view_xray_before')
            try:
                if not state.get('cancelled', False):
                    press_pos = state.get('pos')
                    release_pos = state.get('release_pos')
                    tool_id = str(state.get('tool_id') or '')
                    if (
                        _select_through_box_supplement_allowed(tool_id)
                        and press_pos is not None
                        and release_pos is not None
                        and area is not None
                        and region is not None
                    ):
                        space = getattr(getattr(area, 'spaces', None), 'active', None)
                        rv3d = getattr(space, 'region_3d', None)
                        override = {'area': area, 'region': region}
                        if window is not None:
                            override['window'] = window
                        if space is not None:
                            override['space_data'] = space
                        if rv3d is not None:
                            override['region_data'] = rv3d
                        try:
                            with bpy.context.temp_override(**override):
                                changed = _select_through_fallback_box(
                                    bpy.context, area, region, press_pos, release_pos,
                                    shift=state.get('shift', False),
                                    ctrl=state.get('ctrl', False),
                                    alt=False,
                                )
                            if changed:
                                _tag_redraw_all_view3d()
                        except Exception as ex:
                            _ssg_record_diagnostic_once('select_through_finalize', ex)
            finally:
                _suppress_select_guard_occlusion_filter(0.45)
                try:
                    if before:
                        _restore_view_xray_snapshot(before, area)
                except Exception:
                    pass
                # Absolute restoration has completed exactly once.  Fence this
                # generation so old external tokens and old closures cannot
                # write during later redraw/timer ticks or the next gesture.
                if int(epoch) == int(_SSG_XRAY_RESTORE_EPOCH):
                    _SSG_XRAY_RESTORE_EPOCH = int(_SSG_XRAY_RESTORE_EPOCH) + 1
                    _SSG_XRAY_ACTIVE_SESSION.update({
                        'active': False,
                        'entries': None,
                        'area': None,
                        'restore_at': 0.0,
                        'force_on': False,
                        'restore_epoch': int(_SSG_XRAY_RESTORE_EPOCH),
                        'window': None,
                        'native_seen': False,
                        'native_ptrs': (),
                        'native_idnames': (),
                        'native_absent_ticks': 0,
                    })
            return None

        global _SSG_XRAY_FINALIZE_CALLBACK, _SSG_XRAY_FINALIZE_STATE
        _SSG_XRAY_FINALIZE_CALLBACK = _finish
        _SSG_XRAY_FINALIZE_STATE = {
            'callback': _finish,
            'entries': list(restore_entries),
            'area': state_snapshot.get('area'),
            'epoch': int(restore_epoch),
        }
        try:
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            if timers is not None:
                timers.register(_finish, first_interval=max(0.0, float(delay)))
                return
        except Exception:
            pass
        _finish()

    def _event_needs_guard_work(self, event) -> bool:
        global _SSG_NATIVE_DISCOVERY_LAST_INPUT_AT
        try:
            etype = str(getattr(event, 'type', '') or '')
            evalue = str(getattr(event, 'value', '') or '')
        except Exception:
            return True
        if etype == 'TIMER':
            return self._timer is not None
        if not etype.startswith('TIMER'):
            # 見回りの速さの印。何もしていない間の遅い見回りなら、ここで 0.03 秒の見回りへ戻す。
            _SSG_NATIVE_DISCOVERY_LAST_INPUT_AT = _now_monotonic()
            if _SSG_NATIVE_DISCOVERY_SLOW:
                _wake_native_select_discovery_timer()
        if etype in _SSG_VIEW_NAV_ONLY_EVENT_TYPES:
            # ホイール・トラックパッドのビュー操作は、下の押した状態・ドラッグの枝のどの集合にも入らないので、
            # 演算子の属性（1 回 3 µs ほど）を読まずに、押し続けで有効にするキーかどうかだけを見る。
            if evalue in {'PRESS', 'RELEASE', 'CLICK_DRAG'}:
                et = _valid_hold_enable_event_type(etype)
                if et and et in _ssg_configured_hold_enable_keys(
                    getattr(bpy.context, 'scene', None), getattr(bpy, 'context', None), allow_stale=True,
                ):
                    return True
            return False
        # Keep the active select-through X-Ray session alive during drags, but
        # do not do any expensive keymap/view checks for ordinary mouse moves.
        if self._select_through_press_state is not None or self._select_through_restore_state or getattr(self, '_select_through_candidate_state', None) is not None:
            if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'LEFTMOUSE', 'RIGHTMOUSE', 'ESC', 'G', 'R', 'S', 'EVT_TWEAK_L'}:
                return True
        if getattr(self, '_press_pos', None) is not None and etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'LEFTMOUSE', 'EVT_TWEAK_L'}:
            return True
        if etype in {'LEFTMOUSE', 'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER', 'SPACE', 'A', 'B', 'C', 'L', 'I', 'G', 'R', 'S', 'EVT_TWEAK_L', 'WINDOW_ACTIVATE', 'WINDOW_DEACTIVATE'}:
            return True
        # PRESS/RELEASE may be a user-assigned enable-while-held shortcut.  Only
        # these values need key state updates; viewport navigation mouse-move and
        # wheel events can pass through immediately.
        if evalue in {'PRESS', 'RELEASE', 'CLICK_DRAG'}:
            et = _valid_hold_enable_event_type(etype)
            if et and et in _ssg_configured_hold_enable_keys(getattr(bpy.context, 'scene', None), getattr(bpy, 'context', None)):
                return True
        return False

    def modal(self, context, event):
        scene = context.scene

        if not getattr(scene, "select_guard_enabled", False):
            self.cancel(context)
            return {'CANCELLED', 'PASS_THROUGH'}

        # 演算子の __getattribute__（Python で書かれ 1 回 2 µs ほど）を通さずに、クラスから直に呼ぶ。
        if not type(self)._event_needs_guard_work(self, event):
            return {'PASS_THROUGH'}

        if str(getattr(event, 'type', '') or '') in {'WINDOW_ACTIVATE', 'WINDOW_DEACTIVATE'}:
            if str(getattr(event, 'type', '') or '') == 'WINDOW_DEACTIVATE':
                self._select_through_press_state = None
                self._select_through_candidate_state = None
                self._cancel_select_through_xray_session()
            _schedule_select_guard_monitor_ensure(retries=3, delay=0.01)
            return {'PASS_THROUGH'}

        if (
            _event_is_pointer_event(event)
            and self._select_through_press_state is None
            and self._press_pos is None
            and not _event_over_view3d_window_region(context, event)
        ):
            return {'PASS_THROUGH'}

        if (
            str(getattr(event, 'type', '') or '') != 'TIMER'
            and not _event_is_pointer_event(event)
            and not _ssg_keyboard_event_allowed_in_view3d(context, event)
        ):
            return {'PASS_THROUGH'}

        self._refresh_event_suspension()

        # Update modifier and specified-key state. TIMER events may not carry
        # reliable keyboard state, so keep explicit PRESS/RELEASE state for the
        # non-modifier hold-enable key.  This now runs only for relevant events;
        # ordinary viewport navigation MOUSEMOVE/WHEEL events are passed through
        # before any keymap scan or view lookup.
        if event.type != 'TIMER':
            self._mod_shift = bool(getattr(event, "shift", False))
            self._mod_ctrl = bool(getattr(event, "ctrl", False))
            self._mod_alt = bool(getattr(event, "alt", False))
            try:
                if self._held_event_keys is None:
                    self._held_event_keys = set()
                et = str(getattr(event, 'type', '') or '')
                ev = str(getattr(event, 'value', '') or '')
                if ev == 'PRESS':
                    self._held_event_keys.add(et)
                elif ev == 'RELEASE':
                    self._held_event_keys.discard(et)
                _update_ssg_hold_enable_runtime_from_event(event, scene)
            except Exception:
                self._held_event_keys = set()

        click_enabled = getattr(scene, "ssg_enable_click_filter", True)
        specified_key_active = self._specified_hold_enable_active(scene, event)

        if event.type != 'TIMER' and event.type not in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            self._store_current_view3d(context, event)

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self._begin_select_guard_gesture(context, event, specified_key_active)

        if _select_through_xray_off_enabled(scene) and specified_key_active:
            if _event_starts_select_through_xray_off(event):
                if str(getattr(event, 'value', '') or '') == 'CLICK_DRAG' and isinstance(self._select_through_press_state, dict):
                    try:
                        region = self._select_through_press_state.get('region') or self._last_region
                        pos = _event_region_xy(event, region)
                        if pos is not None:
                            self._select_through_press_state['last_pos'] = pos
                            self._select_through_press_state['drag_seen'] = True
                        if bool(self._select_through_press_state.get('click_only_select', False)):
                            native_rows = _adopt_native_select_modal_owner(
                                self._select_through_press_state.get('session_id', self._select_through_session_id),
                                self._select_through_press_state.get('window') or self._last_window,
                            )
                            if native_rows:
                                # B/C shortcut routes keep builtin.select as the
                                # toolbar tool.  The live native modal, not that
                                # toolbar id, is the authoritative drag owner.
                                self._select_through_press_state['click_only_select'] = False
                                self._select_through_press_state['explicit_region_select'] = True
                            else:
                                # No native region-selection owner appeared: this
                                # is Blender's normal tweak/transform drag.
                                self._cancel_select_through_xray_session()
                                self._select_through_press_state = None
                                return {'PASS_THROUGH'}
                        _force_view_xray_for_select_through(self._select_through_press_state.get('area'), True)
                        _touch_select_through_active_xray_session(self._select_through_press_state.get('session_id', self._select_through_session_id))
                    except Exception:
                        pass
                    select_through_allowed = False
                else:
                    self._select_through_press_state = None
                    select_through_allowed = _select_through_native_xray_allowed(context, event)
                if select_through_allowed:
                    try:
                        area = self._select_through_area(context)
                        region = self._last_region if getattr(self._last_region, 'type', None) == 'WINDOW' else getattr(context, 'region', None)
                        pos = _event_region_xy(event, region)
                        if area is not None and region is not None and getattr(region, 'type', None) == 'WINDOW' and pos is not None:
                            # Do not start temporary X-Ray for tweak/transform starts.
                            # Pressing on an already-selected element is Blender's normal
                            # move/tweak path, not a select-through pick/box operation.
                            event_type = str(getattr(event, 'type', '') or '')
                            event_value = str(getattr(event, 'value', '') or '')
                            is_late_click_drag = event_value == 'CLICK_DRAG'
                            is_lasso_shortcut = bool(
                                event_type == 'RIGHTMOUSE'
                                and event_value in {'PRESS', 'CLICK_DRAG'}
                                and bool(getattr(event, 'ctrl', False))
                            )
                            tool_id = _active_view3d_tool_id(context)
                            explicit_box_tool = bool(
                                str(tool_id or '') in {'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'}
                                or is_lasso_shortcut
                            )
                            default_select_tool = bool(str(tool_id or '') == 'builtin.select' and not is_lasso_shortcut)
                            hit_pos = pos
                            if is_late_click_drag and is_lasso_shortcut:
                                # CLICK_DRAG reports the current pointer.  Judge the
                                # lasso start where the button was pressed, as the
                                # former PRESS start did.
                                try:
                                    hit_pos = (
                                        float(getattr(event, 'mouse_prev_press_x')) - float(region.x),
                                        float(getattr(event, 'mouse_prev_press_y')) - float(region.y),
                                    )
                                except Exception:
                                    hit_pos = pos
                            hits_selected = _press_hits_selected_element(context, area, region, hit_pos)
                            hits_gizmo = _press_hits_smart_gizmo_handle(context, event, area, region, hit_pos)
                            # Only selection clicks/drags may switch temporary X-Ray on.
                            # Late CLICK_DRAG is accepted only for explicit region-selection
                            # tools; default Select CLICK_DRAG is a tweak/transform gesture.
                            # Box / Lasso tools only select a region once the press
                            # becomes a drag.  Switching X-Ray on at PRESS made a plain
                            # click pick hidden (back-facing) elements and flashed X-Ray
                            # for clicks that never became a region selection.  Wait for
                            # the late CLICK_DRAG path below instead.  The Ctrl+RMB lasso
                            # shortcut waits the same way: a plain Ctrl+RMB click is not a
                            # lasso selection (in Edit Mesh it is Extrude to Cursor).
                            # Circle select paints from PRESS and keeps the PRESS start.
                            drag_started_region_tool = bool(
                                str(tool_id or '') in {'builtin.select_box', 'builtin.select_lasso'}
                                or is_lasso_shortcut
                            )
                            if is_late_click_drag:
                                allow_select_through_start = bool(explicit_box_tool) and (not hits_selected) and (not hits_gizmo)
                            elif drag_started_region_tool:
                                allow_select_through_start = False
                            elif explicit_box_tool:
                                allow_select_through_start = (not hits_selected) and (not hits_gizmo)
                            elif default_select_tool:
                                # The default Select (Tweak) tool picks on PRESS and its
                                # drag is a tweak/transform, never a region selection.
                                # Turning X-Ray on here made a plain click pick a hidden
                                # element behind the visible one, so a click with this
                                # tool selects exactly like Blender and never flashes
                                # temporary X-Ray.
                                allow_select_through_start = False
                            else:
                                allow_select_through_start = False
                            if allow_select_through_start:
                                # Reclaim a prior delayed generation before
                                # classifying this area's state as user-owned ON.
                                self._restore_select_through_xray_off()
                                _cancel_pending_select_through_xray_restores(restore=True)
                            if allow_select_through_start and not _is_view_xray(area):
                                view_xray_before = _snapshot_view_xray_state(area)
                                changed = []
                                if not _is_view_xray(area):
                                    changed = _set_view_xray_for_select_through(area, True)
                                current = self._select_through_restore_state
                                if not isinstance(current, list):
                                    current = []
                                restore_entries = view_xray_before or changed
                                if restore_entries:
                                    try:
                                        existing = {
                                            (
                                                int(e.get('space_ptr') or 0),
                                                str(e.get('owner_kind') or ''),
                                                str(e.get('prop') or ''),
                                            )
                                            for e in current if isinstance(e, dict)
                                        }
                                    except Exception:
                                        existing = set()
                                    for _entry in list(restore_entries):
                                        try:
                                            _key = (
                                                int(_entry.get('space_ptr') or 0),
                                                str(_entry.get('owner_kind') or ''),
                                                str(_entry.get('prop') or ''),
                                            )
                                        except Exception:
                                            _key = (0, '', '')
                                        if _key not in existing:
                                            current.append(_entry)
                                            existing.add(_key)
                                    self._select_through_restore_state = current
                                    # Keep X-Ray enabled only for the active click/drag session.
                                    # The session watchdog restores the original state on release,
                                    # and also when Blender consumes the release event.
                                    self._select_through_session_id = _start_select_through_active_xray_session(
                                        restore_entries,
                                        area,
                                        window=self._last_window or getattr(context, 'window', None),
                                        force_on=True,
                                    )
                                    _force_view_xray_for_select_through(area, True)
                                self._select_through_press_state = {
                                    'window': self._last_window,
                                    'area': area,
                                    'region': region,
                                    'pos': (hit_pos if (is_late_click_drag and is_lasso_shortcut) else (self._press_pos if is_late_click_drag and self._press_pos is not None else pos)),
                                    'last_pos': pos,
                                    'shift': bool(getattr(event, 'shift', False)),
                                    'ctrl': bool(getattr(event, 'ctrl', False)),
                                    'alt': bool(getattr(event, 'alt', False)),
                                    'view_xray_before': view_xray_before,
                                    'session_id': self._select_through_session_id,
                                    'xray_changed': bool(changed),
                                    'tool_id': str(tool_id or ''),
                                    'explicit_region_select': bool(explicit_box_tool),
                                    'click_only_select': bool(default_select_tool and not explicit_box_tool),
                                    'pointer_button': ('RIGHTMOUSE' if is_lasso_shortcut else 'LEFTMOUSE'),
                                }
                    except Exception as ex:
                        _ssg_record_diagnostic_once('select_through_press', ex)
                        self._select_through_press_state = None
                        if self._select_through_restore_state:
                            self._cancel_select_through_xray_session()
                else:
                    if self._select_through_restore_state:
                        self._cancel_select_through_xray_session()
            elif _event_updates_select_through_xray_off_drag(event):
                if isinstance(self._select_through_press_state, dict):
                    try:
                        region = self._select_through_press_state.get('region') or self._last_region
                        pos = _event_region_xy(event, region)
                        if pos is not None:
                            self._select_through_press_state['last_pos'] = pos
                        # Default Select click-through is allowed only while it remains
                        # a click.  Once it becomes a tweak/drag, Blender is transforming
                        # the selected element, so restore X-Ray immediately.  Explicit
                        # Box/Lasso/Circle selection keeps X-Ray enabled until release.
                        if bool(self._select_through_press_state.get('click_only_select', False)):
                            if _event_confirms_native_tweak(event):
                                native_rows = _adopt_native_select_modal_owner(
                                    self._select_through_press_state.get('session_id', self._select_through_session_id),
                                    self._select_through_press_state.get('window') or self._last_window,
                                )
                                if native_rows:
                                    self._select_through_press_state['click_only_select'] = False
                                    self._select_through_press_state['explicit_region_select'] = True
                                else:
                                    self._cancel_select_through_xray_session()
                                    self._select_through_press_state = None
                                    return {'PASS_THROUGH'}
                        _force_view_xray_for_select_through(self._select_through_press_state.get('area'), True)
                        _touch_select_through_active_xray_session(self._select_through_press_state.get('session_id', self._select_through_session_id))
                    except Exception:
                        pass
            elif _event_finishes_select_through_xray_off(event):
                state = self._select_through_press_state
                self._select_through_press_state = None
                self._select_through_candidate_state = None
                if isinstance(state, dict):
                    try:
                        area = state.get('area') or self._select_through_area(context)
                        region = state.get('region') or self._last_region or getattr(context, 'region', None)
                        pointer_button = str(state.get('pointer_button') or 'LEFTMOUSE')
                        if event.type == pointer_button and event.value == 'RELEASE':
                            state['release_pos'] = _event_region_xy(event, region) or state.get('last_pos') or state.get('pos')
                            state['cancelled'] = False
                        else:
                            state['release_pos'] = state.get('last_pos')
                            state['cancelled'] = True
                        state['area'] = area
                        state['region'] = region
                        _adopt_native_select_modal_owner(
                            state.get('session_id', self._select_through_session_id),
                            state.get('window') or self._last_window,
                        )
                        if bool(_SSG_XRAY_ACTIVE_SESSION.get('native_seen', False)):
                            # The app-timer owns this exact native modal pointer.
                            # RELEASE/cancel may be consumed by Blender, so the
                            # watcher never schedules a competing timed restore.
                            _suppress_select_guard_occlusion_filter(0.55)
                            _touch_select_through_active_xray_session(
                                state.get('session_id', self._select_through_session_id)
                            )
                        else:
                            self._schedule_select_through_finalize(state, delay=0.03)
                    except Exception as ex:
                        _ssg_record_diagnostic_once('select_through_finish', ex)
                        self._cancel_select_through_xray_session()
                elif self._select_through_restore_state:
                    self._cancel_select_through_xray_session()
        else:
            self._select_through_press_state = None
            self._select_through_candidate_state = None
            if self._select_through_restore_state:
                self._cancel_select_through_xray_session()

        if self._select_through_restore_state:
            try:
                etype = str(getattr(event, 'type', '') or '')
                evalue = str(getattr(event, 'value', '') or '')
                if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'EVT_TWEAK_L'} and isinstance(self._select_through_press_state, dict):
                    _touch_select_through_active_xray_session(self._select_through_session_id)
                    if not bool(self._select_through_press_state.get('click_only_select', False)):
                        _force_view_xray_for_select_through(self._select_through_press_state.get('area'), True)
                elif etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                    _touch_select_through_active_xray_session(self._select_through_session_id)
                if ((etype in {'G', 'R', 'S'} and evalue in {'PRESS', 'CLICK_DRAG', 'ANY'}) or (etype == 'EVT_TWEAK_L' and not isinstance(self._select_through_press_state, dict))):
                    self._cancel_select_through_xray_session()
            except Exception:
                pass

        # Modifier-based bypass shortcuts were removed because they conflict
        # with Blender's standard Shift/Ctrl/Alt selection operations.  Use the
        # non-modifier "Enable-While-Held Key" option instead.

        if event.type == 'LEFTMOUSE':
            if event.value in {'DOUBLE_CLICK'}:
                self._suspend_filter(12)
            if event.value in {'PRESS', 'RELEASE'} and (event.alt or (event.ctrl and event.alt)):
                self._suspend_filter(12)

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            if self._press_pos is None:
                self._begin_select_guard_gesture(context, event, specified_key_active)

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if not specified_key_active:
                self._press_pos = None
                self._clear_select_guard_gesture()
            elif self._suspend_frames > 0:
                self._press_pos = None
                self._clear_select_guard_gesture()
            else:
                if self._press_pos is not None:
                    release_xy = _event_region_xy(event, self._last_region if getattr(self._last_region, 'type', None) == 'WINDOW' else getattr(context, 'region', None))
                    if release_xy is None:
                        self._press_pos = None
                        self._clear_select_guard_gesture()
                        return {'PASS_THROUGH'}
                    dx = release_xy[0] - self._press_pos[0]
                    dy = release_xy[1] - self._press_pos[1]
                    dist2 = dx * dx + dy * dy
                    click_threshold = _native_tweak_threshold_px(context, event)
                    is_click = dist2 <= (click_threshold * click_threshold)

                    gesture_state = self._select_guard_gesture_state
                    if _ssg_gesture_allows_release_filter(gesture_state, is_click=is_click, click_enabled=click_enabled):
                        _schedule_select_guard_event_filter(
                            context,
                            self,
                            reason=('mouse_click' if is_click else 'mouse_drag'),
                            delay=0.03,
                            gesture_state=gesture_state,
                            require_selection_changed=True,
                        )

                self._press_pos = None
                self._clear_select_guard_gesture()

        # RET/SPACE confirm many non-selection tools (transform, dialogs, search,
        # menu actions).  Do not use them as Smart Select Guard triggers.

        if specified_key_active and event.value == 'PRESS':
            key_reason = _ssg_selection_key_reason(event)
            if key_reason and self._suspend_frames <= 0:
                try:
                    before_sig = _selection_signature(context)
                except Exception:
                    before_sig = None
                if before_sig is not None:
                    _schedule_select_guard_event_filter(
                        context,
                        self,
                        reason=key_reason,
                        delay=0.04,
                        pre_signature=before_sig,
                        require_selection_changed=True,
                    )

        if event.type == 'TIMER':
            try:
                self._check_bypass_by_wm_last_operator(context)

                # Update status text if active
                if getattr(scene, "ssg_show_status_feedback", True):
                    self._update_status(context)

                # If a non-modifier hold-enable key is configured, Smart Select
                # Guard only filters while that exact key is held.
                if not self._specified_hold_enable_active(scene):
                    self._last_signature = _selection_signature(bpy.context)
                    return {'PASS_THROUGH'}

                if self._suspend_frames > 0:
                    self._suspend_frames -= 1
                    self._last_signature = _selection_signature(bpy.context)
                    return {'PASS_THROUGH'}

                if self._cooldown_frames > 0:
                    self._cooldown_frames -= 1

                params = _get_params(scene)
                idle_skip = int(max(1, params.get("idle_skip", 4)))

                # Adaptive idle: skip signature checks when nothing is happening
                if self._burst_frames <= 0 and self._cooldown_frames <= 0:
                    self._idle_ticks = (self._idle_ticks + 1) % idle_skip
                    if self._idle_ticks != 0:
                        return {'PASS_THROUGH'}

                sig_now = _selection_signature(bpy.context)

                if self._last_signature is None:
                    self._last_signature = sig_now
                    return {'PASS_THROUGH'}

                if sig_now != self._last_signature and self._cooldown_frames <= 0:
                    self._arm_burst(self._BURST)

                if self._burst_frames > 0:
                    self._burst_frames -= 1
                    changed, stats = self._run_filter(bpy.context)
                    if changed:
                        self._cooldown_frames = 1

                        if getattr(scene, "ssg_show_status_feedback", True) and stats:
                            msg = iface_("Selection Guard: removed O{obj} V{v} E{e} F{f}").format(
                                obj=stats.get("obj", 0),
                                v=stats.get("v", 0),
                                e=stats.get("e", 0),
                                f=stats.get("f", 0),
                            )
                            self._status_text = msg
                            self._status_frames = 25

                self._last_signature = _selection_signature(bpy.context)

            except Exception as ex:
                _ssg_record_diagnostic_once('modal_timer_tick', ex)
                _schedule_select_guard_monitor_ensure(retries=3, delay=0.05)
                return {'PASS_THROUGH'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        window = getattr(context, 'window', None)
        window_key = _ssg_window_key(window)
        if not window_key:
            return {'CANCELLED'}
        existing = VIEW3D_OT_select_guard_modal._instances_by_window.get(window_key)
        if existing is not None and existing is not self:
            return {'CANCELLED'}
        self._window_key = window_key

        try:
            sc = getattr(context, 'scene', None)
            if sc is not None and hasattr(sc, 'ssg_scene_initialized'):
                sc.ssg_scene_initialized = True
        except Exception:
            pass
        self._store_current_view3d(context)

        wm = context.window_manager
        # Event-driven mode: do not install a periodic timer.  The guard now
        # reacts only to actual selection-related input events and schedules a
        # one-shot post-event filter after Blender's native selection operator
        # has run.  This keeps the same selection rejection behavior without
        # continuously polling the viewport at idle.
        self._timer = None
        wm.modal_handler_add(self)

        self._last_signature = _selection_signature(context)
        self._burst_frames = 0
        self._cooldown_frames = 0
        self._press_pos = None
        self._suspend_frames = 0
        self._suspend_until = 0.0
        self._last_seen_wm_op = ""
        self._idle_ticks = 0

        self._mod_shift = False
        self._mod_ctrl = False
        self._mod_alt = False
        self._held_event_keys = set()

        self._status_text = ""
        self._status_frames = 0
        self._select_through_restore_state = None
        self._select_through_restore_pending = False
        self._select_through_press_state = None
        self._select_through_session_id = 0
        self._select_through_candidate_state = None
        self._select_guard_gesture_state = None

        VIEW3D_OT_select_guard_modal._instances_by_window[window_key] = self
        VIEW3D_OT_select_guard_modal._running = bool(VIEW3D_OT_select_guard_modal._instances_by_window)
        VIEW3D_OT_select_guard_modal._instance = self
        _ensure_native_select_discovery_timer()
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._select_through_press_state = None
        self._select_through_candidate_state = None
        self._select_guard_gesture_state = None
        self._cancel_select_through_xray_session()
        wm = context.window_manager
        if self._timer is not None:
            try:
                wm.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        key = int(getattr(self, '_window_key', 0) or 0)
        if key and VIEW3D_OT_select_guard_modal._instances_by_window.get(key) is self:
            VIEW3D_OT_select_guard_modal._instances_by_window.pop(key, None)
        self._window_key = 0
        VIEW3D_OT_select_guard_modal._running = bool(VIEW3D_OT_select_guard_modal._instances_by_window)
        if VIEW3D_OT_select_guard_modal._instance is self:
            VIEW3D_OT_select_guard_modal._instance = next(iter(VIEW3D_OT_select_guard_modal._instances_by_window.values()), None)
        if not VIEW3D_OT_select_guard_modal._instances_by_window:
            _cancel_native_select_discovery_timer()

    def execute(self, context):
        return self.invoke(context, None)


def _iter_select_guard_window_overrides():
    try:
        wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
        windows = list(getattr(wm, 'windows', ()) or ())
    except Exception:
        windows = []
    for window in windows:
        try:
            screen = getattr(window, 'screen', None)
            if screen is None:
                continue
            for area in getattr(screen, 'areas', ()) or ():
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                region = next((r for r in getattr(area, 'regions', ()) or () if getattr(r, 'type', None) == 'WINDOW'), None)
                if region is not None:
                    yield window, area, region
                    break
        except Exception:
            continue


def _ensure_select_guard_modal_watchers(context=None) -> int:
    if not _SSG_MODULE_REGISTERED:
        return 0
    live_keys = set()
    missing = 0
    for window, area, region in _iter_select_guard_window_overrides():
        key = _ssg_window_key(window)
        if not key:
            continue
        live_keys.add(key)
        try:
            scene = getattr(window, 'scene', None)
        except Exception:
            scene = None
        if scene is None:
            try:
                scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
            except Exception:
                scene = None
        if scene is None or not bool(getattr(scene, 'select_guard_enabled', False)):
            continue
        if VIEW3D_OT_select_guard_modal._instances_by_window.get(key) is not None:
            continue
        try:
            with bpy.context.temp_override(window=window, area=area, region=region):
                bpy.ops.view3d.select_guard_modal('INVOKE_DEFAULT')
        except Exception as exc:
            _ssg_record_diagnostic_once('monitor_start', exc)
        if VIEW3D_OT_select_guard_modal._instances_by_window.get(key) is None:
            missing += 1
    for stale_key in tuple(VIEW3D_OT_select_guard_modal._instances_by_window):
        if stale_key not in live_keys:
            VIEW3D_OT_select_guard_modal._instances_by_window.pop(stale_key, None)
    VIEW3D_OT_select_guard_modal._running = bool(VIEW3D_OT_select_guard_modal._instances_by_window)
    VIEW3D_OT_select_guard_modal._instance = next(iter(VIEW3D_OT_select_guard_modal._instances_by_window.values()), None)
    return missing


def _select_guard_monitor_ensure_tick():
    global _SSG_MONITOR_ENSURE_CALLBACK, _SSG_MONITOR_ENSURE_REMAINING
    if not _SSG_MODULE_REGISTERED:
        _SSG_MONITOR_ENSURE_CALLBACK = None
        _SSG_MONITOR_ENSURE_REMAINING = 0
        return None
    missing = _ensure_select_guard_modal_watchers(getattr(bpy, 'context', None))
    _SSG_MONITOR_ENSURE_REMAINING = max(0, int(_SSG_MONITOR_ENSURE_REMAINING) - 1)
    if missing > 0 and _SSG_MONITOR_ENSURE_REMAINING > 0:
        return 0.10
    _SSG_MONITOR_ENSURE_CALLBACK = None
    _SSG_MONITOR_ENSURE_REMAINING = 0
    return None


def _cancel_select_guard_monitor_ensure() -> None:
    global _SSG_MONITOR_ENSURE_CALLBACK, _SSG_MONITOR_ENSURE_REMAINING
    callback = _SSG_MONITOR_ENSURE_CALLBACK
    _SSG_MONITOR_ENSURE_CALLBACK = None
    _SSG_MONITOR_ENSURE_REMAINING = 0
    if callback is None:
        return
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None and hasattr(timers, 'is_registered') and timers.is_registered(callback):
            timers.unregister(callback)
    except Exception:
        pass


def _schedule_select_guard_monitor_ensure(*, retries: int = 4, delay: float = 0.05) -> None:
    global _SSG_MONITOR_ENSURE_CALLBACK, _SSG_MONITOR_ENSURE_REMAINING
    if not _SSG_MODULE_REGISTERED:
        return
    _SSG_MONITOR_ENSURE_REMAINING = max(int(_SSG_MONITOR_ENSURE_REMAINING), max(1, int(retries)))
    if _SSG_MONITOR_ENSURE_CALLBACK is not None:
        return
    _SSG_MONITOR_ENSURE_CALLBACK = _select_guard_monitor_ensure_tick
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_select_guard_monitor_ensure_tick, first_interval=max(0.0, float(delay)))
            return
    except Exception as exc:
        _ssg_record_diagnostic_once('monitor_schedule', exc)
    _select_guard_monitor_ensure_tick()


# =========================================================
# Properties / callbacks
# =========================================================

_SSG_DEFERRED_SCENE_SYNC_PENDING = False
_SSG_EVENT_FILTER_PENDING = False
_SSG_EVENT_FILTER_BURST_FRAMES = 0
_SSG_EVENT_FILTER_LAST_SIGNATURE = None
_SSG_EVENT_FILTER_PAYLOAD = None
_SSG_STATUS_CLEAR_PENDING = False


def _view3d_context_safe(context=None) -> bool:
    try:
        ctx = context or bpy.context
        area = getattr(ctx, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return False
        return True
    except Exception:
        return False


def _ssg_keyboard_event_allowed_in_view3d(context, event) -> bool:
    """Return True only when a non-pointer shortcut is actually aimed at a 3D View WINDOW region.

    Smart Select Guard is implemented as a modal watcher, so it can receive
    shortcut events while the cursor is over Blender UI panels, menus, text
    fields, or popovers.  Those events must remain pure Blender UI input and
    must never trigger a delayed occlusion-filter pass that can deselect the
    current mesh selection.
    """
    try:
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D' and region is not None and getattr(region, 'type', None) == 'WINDOW':
            return True
    except Exception:
        pass
    try:
        return bool(_event_over_view3d_window_region(context, event))
    except Exception:
        return False


def _ssg_selection_key_reason(event) -> str:
    """Classify keyboard events that are actual selection operations.

    Earlier builds treated plain I, B, C and generic confirm keys as selection
    confirmation signals.  In Blender, those keys can mean Inset Faces, Circle /
    Box modal startup, search/menu confirmation, transform confirmation, or UI
    input.  Scheduling Smart Select Guard from those unrelated keys is what made
    selected elements change even when the user was not performing a selection.
    """
    try:
        etype = str(getattr(event, 'type', '') or '')
        evalue = str(getattr(event, 'value', '') or '')
    except Exception:
        return ''
    if evalue != 'PRESS':
        return ''
    try:
        ctrl = bool(getattr(event, 'ctrl', False))
        shift = bool(getattr(event, 'shift', False))
        alt = bool(getattr(event, 'alt', False))
        oskey = bool(getattr(event, 'oskey', False))
    except Exception:
        ctrl = shift = alt = oskey = False
    if alt or oskey:
        return ''
    # A / Alt-A is select-all in Blender.  Alt is rejected above to avoid menu
    # and platform shortcuts; Shift/Ctrl variants are still selection-affecting.
    if etype == 'A':
        return 'select_all_key'
    # L selects linked mesh elements only in edit contexts.
    if etype == 'L' and not ctrl:
        return 'select_linked_key'
    # Invert selection is Ctrl+I.  Plain I is Inset Faces / Insert Keyframe and
    # must never run the guard.
    if etype == 'I' and ctrl:
        return 'invert_selection_key'
    # B/C only start Blender's own modal box/circle selection; the actual
    # selection is resolved by following mouse events, not by the key press.
    # RET/SPACE confirm many non-selection tools and are intentionally ignored.
    return ''


def _ssg_select_tool_id(context) -> str:
    try:
        return str(_active_view3d_tool_id(context) or '')
    except Exception:
        return ''


def _ssg_pointer_selection_gesture_state(context, event, *, pos=None, area=None, region=None):
    """Build a safe post-selection filter ticket for native View3D selection gestures only.

    The guard may remove selected elements by design, so this function is
    intentionally conservative.  It rejects Smart Gizmo handle presses, transform
    tool presses, selected-element tweak starts, and any non-View3D WINDOW event.
    """
    try:
        if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
            return None
        if str(getattr(event, 'type', '') or '') != 'LEFTMOUSE' or str(getattr(event, 'value', '') or '') != 'PRESS':
            return None
    except Exception:
        return None

    try:
        window, event_area, event_region = _find_view3d_from_event(context, event)
    except Exception:
        window = event_area = event_region = None
    if event_area is not None and event_region is not None:
        area, region = event_area, event_region
    if area is None or getattr(area, 'type', None) != 'VIEW_3D' or region is None or getattr(region, 'type', None) != 'WINDOW':
        return None

    if pos is None:
        pos = _event_region_xy(event, region)
    if pos is None:
        return None

    tool_id = _ssg_select_tool_id(context)
    select_tools = {'builtin.select', 'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'}
    if tool_id not in select_tools:
        return None

    try:
        if _press_hits_smart_gizmo_handle(context, event, area, region, pos):
            return None
    except Exception:
        pass
    try:
        if _press_hits_selected_element(context, area, region, pos):
            return None
    except Exception:
        pass

    try:
        pre_sig = _selection_signature(context)
    except Exception:
        pre_sig = None
    if pre_sig is None:
        return None

    return {
        'kind': 'pointer_selection',
        'window': window or getattr(context, 'window', None),
        'area': area,
        'region': region,
        'tool_id': tool_id,
        'press_pos': (float(pos[0]), float(pos[1])),
        'pre_signature': pre_sig,
        'require_selection_changed': True,
    }


def _ssg_gesture_allows_release_filter(state, *, is_click: bool, click_enabled: bool) -> bool:
    if not isinstance(state, dict):
        return False
    tool_id = str(state.get('tool_id') or '')
    if tool_id == 'builtin.select':
        return bool(click_enabled) if bool(is_click) else True
    if tool_id in {'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'}:
        return True
    return False


def _cancel_modal_if_running(context=None):
    try:
        instances = list(dict.fromkeys(VIEW3D_OT_select_guard_modal._instances_by_window.values()))
    except Exception:
        instances = []
    fallback = getattr(VIEW3D_OT_select_guard_modal, '_instance', None)
    if fallback is not None and fallback not in instances:
        instances.append(fallback)
    for inst in instances:
        try:
            inst.cancel(context or getattr(bpy, 'context', None))
        except Exception:
            pass
    VIEW3D_OT_select_guard_modal._instances_by_window.clear()
    VIEW3D_OT_select_guard_modal._running = False
    VIEW3D_OT_select_guard_modal._instance = None


def _clear_select_guard_status_tick():
    global _SSG_STATUS_CLEAR_PENDING
    _SSG_STATUS_CLEAR_PENDING = False
    try:
        workspace = getattr(getattr(bpy, 'context', None), 'workspace', None)
        if workspace is not None:
            workspace.status_text_set(None)
    except Exception:
        pass
    return None


def _set_select_guard_status(context=None, message: str = '', *, delay: float = 1.5) -> None:
    global _SSG_STATUS_CLEAR_PENDING
    if not message:
        return
    try:
        workspace = getattr(context or getattr(bpy, 'context', None), 'workspace', None)
        if workspace is not None:
            workspace.status_text_set(text=str(message))
    except Exception:
        pass
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            if hasattr(timers, 'is_registered') and timers.is_registered(_clear_select_guard_status_tick):
                try:
                    timers.unregister(_clear_select_guard_status_tick)
                except Exception:
                    pass
            _SSG_STATUS_CLEAR_PENDING = True
            timers.register(_clear_select_guard_status_tick, first_interval=max(0.1, float(delay)))
    except Exception:
        pass


def _run_select_guard_event_filter_tick():
    global _SSG_EVENT_FILTER_PENDING, _SSG_EVENT_FILTER_BURST_FRAMES, _SSG_EVENT_FILTER_LAST_SIGNATURE, _SSG_EVENT_FILTER_PAYLOAD
    _SSG_EVENT_FILTER_PENDING = False
    payload = _SSG_EVENT_FILTER_PAYLOAD if isinstance(_SSG_EVENT_FILTER_PAYLOAD, dict) else {}
    _SSG_EVENT_FILTER_PAYLOAD = None
    try:
        ctx = getattr(bpy, 'context', None)
        scene = getattr(ctx, 'scene', None) if ctx is not None else None
        if scene is None or not bool(getattr(scene, 'select_guard_enabled', False)):
            _SSG_EVENT_FILTER_BURST_FRAMES = 0
            return None
        if _select_guard_occlusion_filter_suppressed():
            # Select-through intentionally chose back-side targets.  Do not run
            # the occlusion-removal filter during its short finalization window.
            _SSG_EVENT_FILTER_BURST_FRAMES = 0
            _SSG_EVENT_FILTER_LAST_SIGNATURE = None
            return None
        inst = VIEW3D_OT_select_guard_modal._instance_for_context(ctx)
        try:
            if inst is not None:
                inst._refresh_event_suspension()
                inst._check_bypass_by_wm_last_operator(ctx)
                inst._refresh_event_suspension()
                if getattr(inst, '_suspend_frames', 0) > 0:
                    _SSG_EVENT_FILTER_BURST_FRAMES = 0
                    inst._last_signature = None
                    return None
        except Exception:
            pass
        try:
            if inst is not None and not inst._specified_hold_enable_active(scene):
                inst._last_signature = None
                _SSG_EVENT_FILTER_BURST_FRAMES = 0
                return None
        except Exception:
            pass

        try:
            if bool(payload.get('require_selection_changed', False)):
                before_sig = payload.get('pre_signature')
                if before_sig is None:
                    _SSG_EVENT_FILTER_BURST_FRAMES = 0
                    _SSG_EVENT_FILTER_LAST_SIGNATURE = None
                    return None
                now_sig = _selection_signature(ctx)
                if now_sig == before_sig:
                    _SSG_EVENT_FILTER_BURST_FRAMES = 0
                    _SSG_EVENT_FILTER_LAST_SIGNATURE = None
                    return None
        except Exception:
            # If signature validation itself fails, fail closed.  Smart Select
            # Guard must not deselect anything unless a real selection change was
            # observed after a tracked selection gesture.
            _SSG_EVENT_FILTER_BURST_FRAMES = 0
            _SSG_EVENT_FILTER_LAST_SIGNATURE = None
            return None

        # A single fast post-selection confirmation pass is enough for native
        # selection operators in Blender 5.1 and avoids the previous burst of
        # repeated full-mesh signature scans and ray casts.
        _SSG_RUNTIME["fast_confirm_filter"] = True
        try:
            if inst is not None:
                changed, stats = inst._run_filter(ctx)
            else:
                changed, stats = select_guard_filter_selection(ctx)
        finally:
            _SSG_RUNTIME["fast_confirm_filter"] = False

        if inst is not None:
            try:
                inst._last_signature = None
            except Exception:
                pass

        if changed and getattr(scene, 'ssg_show_status_feedback', True) and stats:
            msg = iface_('Selection Guard: removed O{obj} V{v} E{e} F{f}').format(
                obj=stats.get('obj', 0),
                v=stats.get('v', 0),
                e=stats.get('e', 0),
                f=stats.get('f', 0),
            )
            _set_select_guard_status(ctx, msg)
        try:
            if changed:
                _tag_redraw_all_view3d()
        except Exception:
            pass

        # Do not reschedule repeated confirmation passes by default.  The heavy
        # cost reported by users came from running the full filter several times
        # after every box/circle/lasso selection.  Follow-up selections will run
        # their own one-shot pass.
        _SSG_EVENT_FILTER_LAST_SIGNATURE = None
        _SSG_EVENT_FILTER_BURST_FRAMES = 0
    except Exception as ex:
        _ssg_record_diagnostic_once('event_filter_tick', ex)
        _SSG_EVENT_FILTER_BURST_FRAMES = 0
        _SSG_EVENT_FILTER_LAST_SIGNATURE = None
        _schedule_select_guard_monitor_ensure(retries=3, delay=0.05)
    return None

def _schedule_select_guard_event_filter(context=None, source=None, *, reason: str = '', delay: float = 0.01, burst: int = 4, pre_signature=None, require_selection_changed: bool = True, gesture_state=None) -> None:
    global _SSG_EVENT_FILTER_PENDING, _SSG_EVENT_FILTER_BURST_FRAMES, _SSG_EVENT_FILTER_LAST_SIGNATURE, _SSG_EVENT_FILTER_PAYLOAD
    try:
        scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
        if scene is None or not bool(getattr(scene, 'select_guard_enabled', False)):
            return
    except Exception:
        return
    if _select_guard_occlusion_filter_suppressed():
        return
    try:
        if source is not None:
            source._store_current_view3d(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    payload = {}
    if isinstance(gesture_state, dict):
        try:
            payload.update(dict(gesture_state))
        except Exception:
            payload = {}
    if pre_signature is not None:
        payload['pre_signature'] = pre_signature
    if 'require_selection_changed' not in payload:
        payload['require_selection_changed'] = bool(require_selection_changed)
    if bool(payload.get('require_selection_changed', False)) and payload.get('pre_signature') is None:
        return
    payload['reason'] = str(reason or '')
    payload['scheduled_at'] = time.monotonic()
    _SSG_EVENT_FILTER_PAYLOAD = payload
    _SSG_EVENT_FILTER_LAST_SIGNATURE = None
    _SSG_EVENT_FILTER_BURST_FRAMES = 1
    if _SSG_EVENT_FILTER_PENDING:
        return
    _SSG_EVENT_FILTER_PENDING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_run_select_guard_event_filter_tick, first_interval=max(0.0, float(delay)))
            return
    except Exception:
        pass
    _run_select_guard_event_filter_tick()


def _scene_select_guard_sync_deferred():
    global _SSG_DEFERRED_SCENE_SYNC_PENDING
    _SSG_DEFERRED_SCENE_SYNC_PENDING = False
    try:
        context = getattr(bpy, 'context', None)
        scene = getattr(context, 'scene', None) if context is not None else None
        if scene is None or not hasattr(scene, 'select_guard_enabled'):
            return None
        enabled = bool(getattr(scene, 'select_guard_enabled', False))
        restoring = False
        try:
            restoring = bool(_settings is not None and callable(getattr(_settings, 'is_restoring', None)) and _settings.is_restoring())
        except Exception:
            restoring = False
        if restoring:
            return None
        if not globals().get('_SSG_SYNCING_RUNTIME_PREF', False):
            try:
                prefs = _prefs(context)
                if prefs is not None and hasattr(prefs, 'pref_scene_runtime_enabled'):
                    if bool(getattr(prefs, 'pref_scene_runtime_enabled', False)) != enabled:
                        globals()['_SSG_SYNCING_RUNTIME_PREF'] = True
                        try:
                            setattr(prefs, 'pref_scene_runtime_enabled', enabled)
                        finally:
                            globals()['_SSG_SYNCING_RUNTIME_PREF'] = False
            except Exception:
                globals()['_SSG_SYNCING_RUNTIME_PREF'] = False
            try:
                if _settings is not None:
                    _settings.request_save('select_guard_scene_toggle', context)
            except Exception:
                pass

        if enabled:
            _ensure_select_guard_modal_watchers(context)
            _schedule_select_guard_monitor_ensure(retries=4, delay=0.05)
        else:
            try:
                _cancel_modal_if_running(context)
            except Exception:
                pass

        try:
            _sync_load_post_handler(context)
        except Exception:
            pass
        try:
            _tag_redraw_all_view3d()
        except Exception:
            pass
    except Exception:
        pass
    return None


def _request_select_guard_scene_setting_save(context=None) -> None:
    try:
        if _settings is None or _settings.is_restoring():
            return
        _settings.request_save('select_guard_scene_setting', context=context or getattr(bpy, 'context', None))
    except Exception:
        pass


def _on_select_guard_scene_setting_changed(self, context):
    del self
    _invalidate_ssg_hold_enable_key_cache()
    try:
        sc = getattr(context, 'scene', None)
        if sc is not None and hasattr(sc, 'ssg_scene_initialized'):
            sc.ssg_scene_initialized = True
    except Exception:
        pass
    try:
        if _settings is not None and hasattr(_settings, 'mark_user_scene_edit_during_startup_restore'):
            _settings.mark_user_scene_edit_during_startup_restore(context)
    except Exception:
        pass
    try:
        sc = getattr(context, 'scene', None)
        if (
            sc is not None
            and bool(getattr(sc, 'select_guard_enabled', False))
            and bool(getattr(sc, 'ssg_select_through_xray_off', False))
        ):
            _ensure_native_select_discovery_timer()
        else:
            _cancel_native_select_discovery_timer()
            _cancel_pending_select_through_xray_restores(restore=True)
    except Exception:
        pass
    _request_select_guard_scene_setting_save(context)


def _request_scene_select_guard_sync():
    global _SSG_DEFERRED_SCENE_SYNC_PENDING
    if _SSG_DEFERRED_SCENE_SYNC_PENDING:
        return
    _SSG_DEFERRED_SCENE_SYNC_PENDING = True
    try:
        bpy.app.timers.register(_scene_select_guard_sync_deferred, first_interval=0.05)
    except Exception:
        _scene_select_guard_sync_deferred()

def _on_toggle_select_guard(self, context):
    # This property can be changed from header/UI widgets while Blender is still
    # processing panel handlers.  Defer runtime synchronization so the UI handler
    # is not invalidated by modal starts or redraws, but still queue JSON
    # persistence for Smart_Transform_Suite.json immediately.
    del self
    try:
        sc = getattr(context, 'scene', None)
        if sc is not None and hasattr(sc, 'ssg_scene_initialized'):
            sc.ssg_scene_initialized = True
    except Exception:
        pass
    try:
        if _settings is not None and hasattr(_settings, 'mark_user_scene_edit_during_startup_restore'):
            _settings.mark_user_scene_edit_during_startup_restore(context)
    except Exception:
        pass
    _request_select_guard_scene_setting_save(context)
    _request_scene_select_guard_sync()

# =========================================================
# UI: Header Popover
# =========================================================

def _draw_hold_enable_shortcut_ui(layout, sc, context=None):
    box = layout.box()
    col = box.column(align=True)
    col.label(text=iface_("Enable-While-Held Shortcut"), icon='KEY_HLT')
    row = col.row(align=True)
    _operator(row, _SSG_HOLD_ENABLE_OPERATOR_ID, text=iface_("Assign Hold Key Shortcut"), icon='KEY_HLT')
    _operator(row, "view3d.ssg_clear_hold_enable_key_shortcut", text=iface_("Clear Hold Key Shortcut"), icon='X')
    try:
        label = _ssg_hold_enable_display_label(sc, context)
    except Exception:
        label = iface_("None - always active")
    info = col.row(align=True)
    info.enabled = False
    info.label(text=f"{iface_('Assigned Key')}: {label}")


class VIEW3D_PT_select_guard_popover(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_label = "Smart Select Guard Settings"
    bl_ui_units_x = 26

    @classmethod
    def poll(cls, context):
        try:
            if not _view3d_context_safe(context):
                return False
            scene = getattr(context, 'scene', None)
            return scene is not None and hasattr(scene, 'select_guard_enabled')
        except Exception:
            return False

    def draw(self, context):
        layout = self.layout
        header = layout.row(align=True)
        header.label(text=iface_("Smart Select Guard Settings"), icon='RESTRICT_SELECT_OFF')
        _operator(header, "core_suite.show_tool_help", text="", icon='QUESTION', topic_key="smart_select_guard_settings")
        sc = getattr(context, "scene", None)
        if sc is None or not hasattr(sc, "select_guard_enabled"):
            _draw_icon_label(layout, iface_("Smart Select Guard settings are unavailable."), icon='ERROR')
            return

        main = layout.column(align=True)
        main.label(text=iface_("Basic Settings"), icon='RESTRICT_SELECT_OFF')
        main.prop(sc, "select_guard_enabled")
        main.prop(sc, "ssg_select_through_xray_off")

        main.separator()
        main.label(text=iface_("Selection Behavior"), icon='SELECT_SET')
        main.prop(sc, "ssg_enable_click_filter")
        main.prop(sc, "ssg_other_objects_occlude")
        main.prop(sc, "ssg_multi_edit_mutual_occlude")
        main.prop(sc, "ssg_show_status_feedback")

        main.separator()
        _draw_hold_enable_shortcut_ui(main, sc, context)

        main.separator()
        main.label(text=iface_("Occluder Exclude Collection"))
        main.prop(sc, "ssg_occluder_exclude_collection", text="")
        ex_col = getattr(sc, "ssg_occluder_exclude_collection", None)
        if ex_col is not None:
            try:
                child_n = len(getattr(ex_col, "children_recursive", []))
            except Exception:
                child_n = 0
            try:
                obj_n = len(getattr(ex_col, "all_objects", []))
            except Exception:
                obj_n = 0
            info = main.row(align=True)
            info.enabled = False
            info.label(text=f"{iface_('Children')}: {child_n}")
            info.label(text=f"{iface_('Objects')}: {obj_n}")
        _operator(main, "view3d.ssg_toggle_occluder_ignore_selected", icon='HIDE_OFF', custom_icon='shield_bypass', emboss=False)

def draw_menu_bar_toggle(self, context):
    layout = self.layout
    sc = getattr(context, "scene", None)
    if sc is None or not hasattr(sc, "select_guard_enabled"):
        return
    layout.separator()

    row = layout.row(align=True)
    try:
        enabled = bool(getattr(sc, "select_guard_enabled", False))
    except Exception:
        enabled = False
    _operator(row, "view3d.select_guard_toggle", text="", icon='RESTRICT_SELECT_OFF', depress=enabled)
    row.popover(
        panel="VIEW3D_PT_select_guard_popover",
        text="",
    )

# =========================================================
# Preferences
# =========================================================

def _suite_prefs(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None

def _prefs(context=None):
    prefs = _suite_prefs(context)
    return getattr(prefs, 'select_guard', None) if prefs else None

def _get_toggle_operator_id(_self):
    return VIEW3D_OT_select_guard_toggle.bl_idname

def _set_toggle_operator_id(_self, _value):
    return

def _apply_prefs_defaults_to_scene(context, *, force=False):
    try:
        prefs = _prefs(context)
    except Exception:
        return

    sc = context.scene
    if not sc:
        return
    try:
        # Automatic initialization preserves saved scene settings; the explicit
        # Apply Defaults button must also work on an already initialized scene.
        if not force and bool(getattr(sc, 'ssg_scene_initialized', False)):
            return
    except Exception:
        pass

    # copy defaults
    for src, dst in (
        ("pref_quality_preset", "ssg_quality_preset"),
        ("pref_view_scope", "ssg_view_scope"),
        ("pref_other_objects_occlude", "ssg_other_objects_occlude"),
        ("pref_multi_edit_mutual_occlude", "ssg_multi_edit_mutual_occlude"),
        ("pref_click_filter", "ssg_enable_click_filter"),
        ("pref_auto_bypass_xray", "ssg_auto_bypass_xray"),
        ("pref_select_through_xray_off", "ssg_select_through_xray_off"),
        ("pref_auto_bypass_wireframe", "ssg_auto_bypass_wireframe"),
        ("pref_ignore_backface", "ssg_ignore_backface_occluders"),
        ("pref_hold_bypass_key", "ssg_hold_bypass_key"),
        ("pref_hold_enable_key", "ssg_hold_enable_key"),
        ("pref_hold_enable_key_event", "ssg_hold_enable_key_event"),
        ("pref_show_status_feedback", "ssg_show_status_feedback"),
        ("pref_partial_visible_ratio_min", "ssg_partial_visible_ratio_min"),
        ("pref_cache_seconds", "ssg_cache_seconds"),
        ("pref_idle_signature_skip", "ssg_idle_signature_skip"),
        ("pref_target_depth_margin", "ssg_target_depth_margin"),
    ):
        try:
            setattr(sc, dst, getattr(prefs, src))
        except Exception:
            pass
    try:
        if hasattr(sc, 'select_guard_enabled') and bool(getattr(prefs, 'pref_scene_runtime_enabled', False)):
            setattr(sc, 'select_guard_enabled', True)
    except Exception:
        pass

    try:
        sc.ssg_scene_initialized = True
    except Exception:
        pass

    _SSG_RUNTIME["cache"].clear()

class SSG_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    toggle_operator_id: bpy.props.StringProperty(
        name="Shortcut Toggle Operator ID",
        description="Copy this ID and assign a shortcut in Preferences > Keymap.",
        get=_get_toggle_operator_id,
        set=_set_toggle_operator_id,
        options={'SKIP_SAVE'},
    )

    apply_defaults_on_file_load: bpy.props.BoolProperty(
        name="Use Preferences as Defaults on File Load",
        description="If enabled, apply the preference defaults to a scene once after loading a file (when not initialized yet).",
        default=True,
    )

    # defaults
    pref_quality_preset: bpy.props.EnumProperty(
        name="Quality Preset",
        description="Choose the default Smart Select Guard quality preset applied to newly initialized scenes.",
        items=[
            ('FAST', "Fast", "Use fewer samples and shorter checks for the fastest Smart Select Guard response."),
            ('BALANCED', "Balanced", "Use the recommended balance between selection accuracy and viewport responsiveness."),
            ('PRECISE', "Precise", "Use more samples and stricter checks for difficult occlusion cases."),
            ('CUSTOM', "Custom", "Use the custom advanced sampling and margin values shown below."),
        ],
        default='BALANCED',
    )

    pref_view_scope: bpy.props.EnumProperty(
        name="View Scope",
        description="Choose which 3D View contexts Smart Select Guard uses for view-dependent occlusion checks.",
        items=[
            ('ACTIVE', "Active View Only", "Evaluate Smart Select Guard using the active 3D View where the selection was made."),
            ('ALL', "All 3D Views", "Allow Smart Select Guard to use all available 3D View contexts when refreshing view-dependent data."),
        ],
        default='ACTIVE',
    )

    pref_other_objects_occlude: bpy.props.BoolProperty(
        name="Enable Other Objects Occlusion",
        description="Default for whether objects outside the edited object set can block selection targets.",
        default=False,
    )

    pref_multi_edit_mutual_occlude: bpy.props.BoolProperty(
        name="Enable Mutual Occlusion for Multi-Edit",
        description="Default for whether selected or edited objects can occlude one another during multi-object editing.",
        default=True,
    )

    pref_click_filter: bpy.props.BoolProperty(
        name="Enable Click Select Filtering",
        description="Default for whether single-click selection is filtered by Smart Select Guard after Blender selects an item.",
        default=True,
    )

    pref_auto_bypass_xray: bpy.props.BoolProperty(
        name="Auto Bypass in X-Ray",
        description="Default for temporarily bypassing Smart Select Guard while the active viewport is in X-Ray display.",
        default=True,
    )

    pref_select_through_xray_off: bpy.props.BoolProperty(
        name="Select Through when X-Ray Off",
        description="Default for temporarily enabling X-Ray from the moment a selection drag starts (circle select: from the press) while the viewport X-Ray display is off, then restoring the original X-Ray state after selection confirmation.",
        default=False,
    )

    pref_auto_bypass_wireframe: bpy.props.BoolProperty(
        name="Auto Bypass in Wireframe",
        description="Default for temporarily bypassing Smart Select Guard while the active viewport is in Wireframe display.",
        default=True,
    )

    pref_ignore_backface: bpy.props.BoolProperty(
        name="Ignore Backfacing Occluders",
        description="Default for ignoring occluder faces whose normals point away from the view ray.",
        default=False,
    )

    pref_hold_bypass_key: bpy.props.EnumProperty(
        name="Hold-to-Bypass Key",
        description="Choose the modifier key that temporarily bypasses Smart Select Guard while it is held.",
        items=[
            ('NONE', "None", "Do not use a hold-to-bypass modifier key."),
            ('SHIFT', "Shift", "Temporarily bypass Smart Select Guard while Shift is held."),
            ('CTRL', "Ctrl", "Temporarily bypass Smart Select Guard while Ctrl is held."),
            ('ALT', "Alt", "Temporarily bypass Smart Select Guard while Alt is held."),
        ],
        default='SHIFT',
    )

    pref_hold_enable_key: bpy.props.EnumProperty(
        name="Enable-While-Held Key",
        description="Legacy hidden compatibility setting. Use the Assign Hold Key Shortcut button instead of this pull-down.",
        items=_SSG_HOLD_ENABLE_KEY_ITEMS,
        default='NONE',
    )

    pref_hold_enable_key_event: bpy.props.StringProperty(
        name="Enable-While-Held Shortcut Event",
        description="Stored event identifier for the Smart Select Guard enable-while-held shortcut. Right-click the N-panel/popup button and assign a shortcut to change it.",
        default='',
        options={'HIDDEN'},
    )

    pref_show_status_feedback: bpy.props.BoolProperty(
        name="Show Status Feedback",
        description="Default for showing short status messages when Smart Select Guard filters or bypasses a selection.",
        default=True,
    )

    pref_partial_visible_ratio_min: bpy.props.FloatProperty(
        name="Partial Visibility Threshold",
        description="If > 0, require this visible ratio for edges/faces to be treated as visible (0 = any visible sample counts).",
        min=0.0,
        max=1.0,
        default=0.0,
        subtype='FACTOR',
    )

    pref_cache_seconds: bpy.props.FloatProperty(
        name="Cache Seconds",
        description="Default number of seconds Smart Select Guard reuses matching occlusion results before recalculating them.",
        min=0.0,
        max=1.0,
        default=0.15,
        precision=3,
    )

    pref_idle_signature_skip: bpy.props.IntProperty(
        name="Idle Signature Skip",
        description="Default number of unchanged idle signatures to skip before refreshing cached occlusion data.",
        min=1,
        max=12,
        default=4,
    )

    pref_target_depth_margin: bpy.props.FloatProperty(
        name="Target Depth Margin",
        description="Default depth tolerance added around the target point so tiny depth-buffer differences do not incorrectly mark it as occluded.",
        min=0.0,
        max=0.02,
        default=0.0030,
        precision=5,
    )

    def draw(self, context):
        del context
        return None


# =========================================================
# Startup / file-load sync
# =========================================================

def _load_post_needed(context=None):
    try:
        prefs = _prefs(context or getattr(bpy, 'context', None))
    except Exception:
        prefs = None
    if prefs is None:
        return False
    try:
        return bool(getattr(prefs, 'apply_defaults_on_file_load', False) or getattr(prefs, 'pref_scene_runtime_enabled', False))
    except Exception:
        return False


def _sync_load_post_handler(context=None):
    try:
        needed = _load_post_needed(context)
        handlers = bpy.app.handlers.load_post
        registered = _load_post_sync in _load_hooks._CALLBACKS["load_post"]
        if needed and not registered:
            _load_hooks.add(_load_post_sync)
        elif (not needed) and registered:
            _load_hooks.remove(_load_post_sync)
    except Exception:
        pass


def sync_runtime_from_prefs(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        prefs = _prefs(ctx)
    except Exception:
        prefs = None
    try:
        enabled = bool(getattr(prefs, 'pref_scene_runtime_enabled', False)) if prefs is not None else False
    except Exception:
        enabled = False

    try:
        scene = getattr(ctx, 'scene', None) if ctx is not None else getattr(bpy.context, 'scene', None)
        if scene is not None and hasattr(scene, 'select_guard_enabled'):
            if _settings_has_saved_scene_prop('select_guard_enabled', ctx):
                enabled = bool(getattr(scene, 'select_guard_enabled', False))
            else:
                scene.select_guard_enabled = bool(enabled)
    except Exception:
        pass

    try:
        _sync_load_post_handler(ctx)
    except Exception:
        pass

    if enabled:
        try:
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            if timers is not None:
                try:
                    if not timers.is_registered(_load_post_sync_deferred_tick):
                        timers.register(_load_post_sync_deferred_tick, first_interval=0.10)
                except Exception:
                    timers.register(_load_post_sync_deferred_tick, first_interval=0.10)
            else:
                _load_post_sync_deferred_tick()
        except Exception:
            try:
                _load_post_sync_deferred_tick()
            except Exception:
                pass
    else:
        try:
            _cancel_modal_if_running(ctx)
        except Exception:
            pass

    try:
        _tag_redraw_all_view3d()
    except Exception:
        pass


def _load_post_sync_deferred_tick():
    try:
        wm = bpy.context.window_manager
    except Exception:
        wm = None
    if not wm:
        return None

    try:
        prefs = _prefs(bpy.context)
    except Exception:
        prefs = None

    for window in getattr(wm, 'windows', ()) or ():
        screen = getattr(window, 'screen', None)
        if not screen:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            region = next((r for r in getattr(area, 'regions', ()) or () if getattr(r, 'type', None) == 'WINDOW'), None)
            if not region:
                continue
            try:
                with bpy.context.temp_override(window=window, area=area, region=region):
                    sc = bpy.context.scene
                    if sc and prefs and getattr(prefs, "apply_defaults_on_file_load", False):
                        try:
                            if (not _settings_has_saved_select_guard_scene_state(bpy.context)) and not bool(getattr(sc, "ssg_scene_initialized", False)):
                                _apply_prefs_defaults_to_scene(bpy.context)
                        except Exception:
                            pass
                    if sc and prefs and hasattr(sc, 'select_guard_enabled'):
                        try:
                            if (not _settings_has_saved_scene_prop('select_guard_enabled', bpy.context)) and bool(getattr(prefs, 'pref_scene_runtime_enabled', False)):
                                setattr(sc, 'select_guard_enabled', True)
                        except Exception:
                            pass
                try:
                    area.tag_redraw()
                except Exception:
                    pass
            except Exception:
                continue
    _ensure_select_guard_modal_watchers(getattr(bpy, 'context', None))
    _schedule_select_guard_monitor_ensure(retries=4, delay=0.05)
    return None


@persistent
def _load_post_sync(_dummy):
    # File-load redraw and panel reconstruction can overlap in Blender 5.1.
    # Defer modal startup and Scene RNA writes until the UI is stable.
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            try:
                if not timers.is_registered(_load_post_sync_deferred_tick):
                    timers.register(_load_post_sync_deferred_tick, first_interval=0.25)
            except Exception:
                timers.register(_load_post_sync_deferred_tick, first_interval=0.25)
            return
    except Exception:
        pass
    _load_post_sync_deferred_tick()

# =========================================================
# Register
# =========================================================

def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass

classes = (
    VIEW3D_OT_select_guard_toggle,
    VIEW3D_OT_ssg_hold_enable_key_marker,
    VIEW3D_OT_ssg_clear_hold_enable_key_shortcut,
    VIEW3D_OT_ssg_toggle_occluder_ignore_selected,
    VIEW3D_OT_ssg_apply_prefs_to_scene,
    VIEW3D_OT_ssg_select_box_public,
    VIEW3D_OT_select_guard_modal,
    VIEW3D_PT_select_guard_popover,
)

def register():
    global _SSG_MODULE_REGISTERED
    _SSG_MODULE_REGISTERED = False
    _cancel_select_guard_monitor_ensure()
    _cancel_pending_select_through_xray_restores(restore=True)
    _i18n_register()

    for cls in classes:
        bpy.utils.register_class(cls)

    # Native B/toolbar keymaps remain authoritative.  Temporary X-Ray now owns
    # completion through Window.modal_operators, so no add-on priority wrapper
    # may shadow Blender's public selection route.
    _unregister_public_select_box_keymap()

    bpy.types.Scene.select_guard_enabled = bpy.props.BoolProperty(
        name="Smart Select Guard",
        description="Enable or disable Smart Select Guard for the current scene. When enabled, selection tools can reject hidden or occluded targets according to the N-panel settings below.",
        default=False,
        update=_on_toggle_select_guard,
    )

    bpy.types.Scene.ssg_other_objects_occlude = bpy.props.BoolProperty(
        name="Enable Other Objects Occlusion",
        description="In Edit Mode, treat occlusion by objects other than the edited object(s) as occlusion. Disable to ignore other objects when judging occlusion.",
        default=False,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_multi_edit_mutual_occlude = bpy.props.BoolProperty(
        name="Enable Mutual Occlusion for Multi-Edit",
        description="When multiple objects are selected/edited, decide whether selected objects can occlude each other. Disable to judge occlusion per-object (ignore other selected/edited objects).",
        default=True,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_enable_click_filter = bpy.props.BoolProperty(
        name="Enable Click Select Filtering",
        description="Apply occlusion filtering after click selection (single click). Disable to only affect box/circle/lasso or drag selections.",
        default=True,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_quality_preset = bpy.props.EnumProperty(
        name="Quality Preset",
        description="Choose how much sampling Smart Select Guard uses. Fast favors speed, Balanced is the recommended default, Precise increases coverage, and Custom exposes manual values.",
        items=[
            ('FAST', "Fast", "Use fewer samples and shorter checks for the fastest Smart Select Guard response."),
            ('BALANCED', "Balanced", "Use the recommended balance between selection accuracy and viewport responsiveness."),
            ('PRECISE', "Precise", "Use more samples and stricter checks for difficult occlusion cases."),
            ('CUSTOM', "Custom", "Use the custom advanced sampling and margin values shown below."),
        ],
        default='BALANCED',
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_view_scope = bpy.props.EnumProperty(
        name="View Scope",
        description="Choose whether occlusion checks use only the active 3D View or can use all open 3D Views for view-dependent data.",
        items=[
            ('ACTIVE', "Active View Only", "Evaluate Smart Select Guard using the active 3D View where the selection was made."),
            ('ALL', "All 3D Views", "Allow Smart Select Guard to use all available 3D View contexts when refreshing view-dependent data."),
        ],
        default='ACTIVE',
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_auto_bypass_xray = bpy.props.BoolProperty(
        name="Auto Bypass in X-Ray",
        description="Temporarily bypass Smart Select Guard while the active 3D View is in X-Ray mode, where selecting through visible surfaces is usually intentional.",
        default=True,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_select_through_xray_off = bpy.props.BoolProperty(
        name="Select Through when X-Ray Off",
        description="When the viewport X-Ray display is off, temporarily enable X-Ray from the moment a selection drag starts (circle select: from the press) so back-side and occluded mesh elements can be selected, then restore the original X-Ray state after the button is released and the selection is confirmed, even when nothing was selected. A plain click (except with circle select) and Transform/tweak operations do not start this temporary X-Ray state.",
        default=False,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_auto_bypass_wireframe = bpy.props.BoolProperty(
        name="Auto Bypass in Wireframe",
        description="Temporarily bypass Smart Select Guard while the active 3D View is in Wireframe mode, where occlusion by solid surfaces is not expected.",
        default=True,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_ignore_backface_occluders = bpy.props.BoolProperty(
        name="Ignore Backfacing Occluders",
        description="Ignore potential occluding faces whose normals face away from the view ray. Enable this when backfaces should not block selection.",
        default=False,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_hold_bypass_key = bpy.props.EnumProperty(
        name="Hold-to-Bypass Key",
        description="Deprecated hidden compatibility setting. Modifier-key bypass is disabled because it conflicts with Blender standard Shift/Ctrl/Alt selection behavior.",
        items=[
            ('NONE', "None", "Do not use a hold-to-bypass modifier key."),
            ('SHIFT', "Shift", "Legacy value retained for old saved settings; it no longer bypasses Smart Select Guard."),
            ('CTRL', "Ctrl", "Legacy value retained for old saved settings; it no longer bypasses Smart Select Guard."),
            ('ALT', "Alt", "Legacy value retained for old saved settings; it no longer bypasses Smart Select Guard."),
        ],
        default='NONE',
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_hold_enable_key = bpy.props.EnumProperty(
        name="Enable-While-Held Key",
        description="Legacy hidden compatibility setting. Use the Assign Hold Key Shortcut button instead of this pull-down.",
        items=_SSG_HOLD_ENABLE_KEY_ITEMS,
        default='NONE',
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_hold_enable_key_event = bpy.props.StringProperty(
        name="Enable-While-Held Shortcut Event",
        description="Stored event identifier for the Smart Select Guard enable-while-held shortcut. Right-click the Smart Select Guard shortcut button and assign a shortcut to change it.",
        default='',
        options={'HIDDEN'},
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_show_status_feedback = bpy.props.BoolProperty(
        name="Show Status Feedback",
        description="Show short status/report messages when Smart Select Guard filters a selection or is bypassed.",
        default=True,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_occluder_exclude_collection = bpy.props.PointerProperty(
        name="Occluder Exclude Collection",
        description="Objects in this collection and its child collections will be ignored as occluders.",
        type=bpy.types.Collection,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Object.ssg_ignore_as_occluder = bpy.props.BoolProperty(
        name="Ignore as Occluder",
        description="If enabled, this object will be ignored as an occluder by Smart Select Guard.",
        default=False,
    )

    bpy.types.Scene.ssg_partial_visible_ratio_min = bpy.props.FloatProperty(
        name="Partial Visibility Threshold",
        description="If > 0, require this visible ratio for edges/faces to be treated as visible (0 = any visible sample counts).",
        min=0.0,
        max=1.0,
        default=0.0,
        subtype='FACTOR',
        update=_on_select_guard_scene_setting_changed
    )

    # Custom parameters (effective when preset=Custom)
    bpy.types.Scene.ssg_max_steps = bpy.props.IntProperty(
        name="Max Ray Steps",
        description="Maximum number of ray/depth refinement steps used by custom Smart Select Guard occlusion checks. Higher values can improve difficult cases but cost more time.",
        min=6,
        max=64,
        default=18,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_vertex_screen_samples = bpy.props.IntProperty(
        name="Vertex Screen Samples",
        description="Number of screen-space sample points used around each vertex when testing whether it is visible.",
        min=1,
        max=9,
        default=3,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_vertex_sample_radius_px = bpy.props.IntProperty(
        name="Vertex Sample Radius (px)",
        description="Pixel radius around a vertex used for extra visibility samples. Increase when small vertices are incorrectly treated as hidden.",
        min=0,
        max=8,
        default=2,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_edge_sample_count = bpy.props.IntProperty(
        name="Edge Sample Count",
        description="Number of points sampled along each edge to decide whether enough of the edge is visible for selection.",
        min=1,
        max=9,
        default=5,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_face_sample_limit = bpy.props.IntProperty(
        name="Face Sample Limit",
        description="Maximum number of sample points used on a face before Smart Select Guard decides whether it is visible.",
        min=1,
        max=64,
        default=12,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_object_sample_limit = bpy.props.IntProperty(
        name="Object Sample Limit",
        description="Maximum number of object-level sample points used when Smart Select Guard checks object visibility. Lower values are faster; higher values are more thorough.",
        min=1,
        max=999,
        default=999,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_target_depth_margin = bpy.props.FloatProperty(
        name="Target Depth Margin",
        description="Depth tolerance added around the target point so small depth-buffer differences do not incorrectly reject visible elements.",
        min=0.0,
        max=0.02,
        default=0.0030,
        precision=5,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_cache_seconds = bpy.props.FloatProperty(
        name="Cache Seconds",
        description="Number of seconds Smart Select Guard reuses matching occlusion results before recalculating them.",
        min=0.0,
        max=1.0,
        default=0.15,
        precision=3,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_idle_signature_skip = bpy.props.IntProperty(
        name="Idle Signature Skip",
        description="Number of unchanged idle signatures to skip before refreshing cached occlusion data.",
        min=1,
        max=12,
        default=4,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_eps = bpy.props.FloatProperty(
        name="Ray Epsilon",
        description="Small ray offset used to avoid self-intersection artifacts during Smart Select Guard visibility checks.",
        min=0.0,
        max=0.01,
        default=0.0005,
        precision=6,
        update=_on_select_guard_scene_setting_changed
    )

    bpy.types.Scene.ssg_scene_initialized = bpy.props.BoolProperty(
        name="Scene Initialized",
        description="Internal flag marking that Smart Select Guard defaults were already applied to this scene.",
        default=False,
        options={'HIDDEN'},
    )

    bpy.types.VIEW3D_MT_editor_menus.append(draw_menu_bar_toggle)

    _SSG_MODULE_REGISTERED = True
    _sync_load_post_handler(bpy.context)

    # Apply prefs to current scene once (new session) if configured and not initialized
    try:
        prefs = _prefs(bpy.context)
        sc = bpy.context.scene
        if sc and prefs and getattr(prefs, "apply_defaults_on_file_load", False):
            if (not _settings_has_saved_select_guard_scene_state(bpy.context)) and not bool(getattr(sc, "ssg_scene_initialized", False)):
                _apply_prefs_defaults_to_scene(bpy.context)
    except Exception:
        pass

    try:
        prefs = _prefs(bpy.context)
        sc = getattr(bpy.context, 'scene', None)
        if prefs is not None and sc is not None and hasattr(sc, 'select_guard_enabled'):
            if (not _settings_has_saved_scene_prop('select_guard_enabled', bpy.context)) and bool(getattr(prefs, 'pref_scene_runtime_enabled', False)):
                setattr(sc, 'select_guard_enabled', True)
    except Exception:
        pass

    _sync_load_post_handler(bpy.context)
    try:
        sync_runtime_from_prefs(bpy.context)
    except Exception:
        pass
    _tag_redraw_all_view3d()

def unregister():
    global _SSG_MODULE_REGISTERED
    _SSG_MODULE_REGISTERED = False
    _cancel_select_guard_monitor_ensure()
    _cancel_native_select_discovery_timer()
    _cancel_pending_select_through_xray_restores(restore=True)
    _cancel_modal_if_running(getattr(bpy, 'context', None))
    _unregister_public_select_box_keymap()
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is not None:
        for callback in (
            _run_select_guard_event_filter_tick,
            _scene_select_guard_sync_deferred,
            _clear_select_guard_status_tick,
            _load_post_sync_deferred_tick,
        ):
            try:
                if hasattr(timers, 'is_registered') and timers.is_registered(callback):
                    timers.unregister(callback)
            except Exception:
                pass

    _load_hooks.remove(_load_post_sync)

    try:
        bpy.types.VIEW3D_MT_editor_menus.remove(draw_menu_bar_toggle)
    except Exception:
        pass

    VIEW3D_OT_select_guard_modal._instances_by_window.clear()
    VIEW3D_OT_select_guard_modal._running = False
    VIEW3D_OT_select_guard_modal._instance = None

    for cls in reversed(classes):
        _safe_unregister_class(cls)

    for prop in (
        "select_guard_enabled",
        "ssg_other_objects_occlude",
        "ssg_multi_edit_mutual_occlude",
        "ssg_enable_click_filter",
        "ssg_quality_preset",
        "ssg_view_scope",
        "ssg_auto_bypass_xray",
        "ssg_select_through_xray_off",
        "ssg_auto_bypass_wireframe",
        "ssg_ignore_backface_occluders",
        "ssg_hold_bypass_key",
        "ssg_hold_enable_key",
        "ssg_hold_enable_key_event",
        "ssg_show_status_feedback",
        "ssg_occluder_exclude_collection",
        "ssg_partial_visible_ratio_min",
        "ssg_max_steps",
        "ssg_vertex_screen_samples",
        "ssg_vertex_sample_radius_px",
        "ssg_edge_sample_count",
        "ssg_face_sample_limit",
        "ssg_object_sample_limit",
        "ssg_target_depth_margin",
        "ssg_cache_seconds",
        "ssg_idle_signature_skip",
        "ssg_eps",
        "ssg_scene_initialized",
    ):
        if hasattr(bpy.types.Scene, prop):
            try:
                delattr(bpy.types.Scene, prop)
            except Exception:
                pass

    if hasattr(bpy.types.Object, "ssg_ignore_as_occluder"):
        try:
            delattr(bpy.types.Object, "ssg_ignore_as_occluder")
        except Exception:
            pass

    _SSG_RUNTIME["cache"].clear()

    _i18n_unregister()
    _tag_redraw_all_view3d()

if __name__ == "__main__":
    register()

# -----------------------------------------------------------------------------
# Toolset integration helpers
# -----------------------------------------------------------------------------
__STS_REGISTERED = False

def ensure_registered(enable: bool = True):
    global __STS_REGISTERED
    if enable and not __STS_REGISTERED:
        try:
            register()
            __STS_REGISTERED = True
        except Exception:
            __STS_REGISTERED = False
            raise
    elif (not enable) and __STS_REGISTERED:
        try:
            unregister()
        finally:
            __STS_REGISTERED = False
