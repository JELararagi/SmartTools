"""Edit-mode median coordinates and scalar attributes on selected BMesh elements."""
import bpy
import bmesh
from mathutils import Vector

ATTRS = {
    "bevel_vertex": ("verts", "bevel_weight_vert"),
    "crease_vertex": ("verts", "crease_vert"),
    "bevel_edge": ("edges", "bevel_weight_edge"),
    "crease_edge": ("edges", "crease_edge"),
}
ALIASES = {"v_bevel":"bevel_vertex", "v_crease":"crease_vertex", "e_bevel":"bevel_edge", "e_crease":"crease_edge"}


def objects():
    return [o for o in bpy.context.objects_in_mode_unique_data if o.type == "MESH"] if bpy.context.mode == "EDIT_MESH" else []


def coordinates():
    for obj in objects():
        mesh = bmesh.from_edit_mesh(obj.data)
        world = obj.data.sts_popup_edit_global_space
        for vert in mesh.verts:
            if vert.select and not vert.hide:
                yield obj, vert, obj.matrix_world @ vert.co if world else vert.co.copy()


def median():
    points = [point for _, _, point in coordinates()]
    return sum(points, Vector((0,0,0))) / len(points) if points else Vector((0,0,0))


def scalar_slots(key, create):
    skin = key in {"skin_x", "skin_y"}
    for obj in objects():
        mesh = bmesh.from_edit_mesh(obj.data)
        elements = mesh.verts if skin else getattr(mesh,ATTRS[key][0])
        selected = [e for e in elements if e.select and not e.hide]
        if not selected:
            continue
        if skin:
            layers = elements.layers.skin
            layer = layers.active or (layers.verify() if create else None)
        else:
            layers = elements.layers.float
            name = ATTRS[key][1]
            layer = layers.get(name) or (layers.new(name) if create else None)
        for element in elements:
            if element.select and not element.hide:yield element,layer


def get(key):
    if key == "median_location":
        return tuple(median())
    vals = [0.0 if layer is None else el[layer].radius[0 if key == "skin_x" else 1] if key.startswith("skin_") else el[layer] for el,layer in scalar_slots(key,False)]
    return sum(vals)/len(vals) if vals else 0.0


def set_value(key,value):
    if key == "median_location":
        delta = Vector(value) - median()
        for obj,vert,point in coordinates():
            vert.co = obj.matrix_world.inverted_safe() @ (point+delta) if obj.data.sts_popup_edit_global_space else point+delta
    else:
        for el,layer in scalar_slots(key,True):
            if key.startswith("skin_"):
                el[layer].radius[0 if key == "skin_x" else 1] = value
            else:
                el[layer] = value
    for obj in objects():
        bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)

