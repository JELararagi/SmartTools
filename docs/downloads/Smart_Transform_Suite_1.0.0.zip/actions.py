import json
import bpy
from mathutils import Vector
from . import align,grs,interaction,selection,storage,transforms

FEATURES={"cursor_lock":"enable_cursor_lock_feature","select_guard":"enable_select_guard","quick_align":"enable_quick_align",
          "quick_multi_edit":"enable_quick_multi_edit","csdt_gizmo":"enable_smart_gizmo_live_runtime","precision_length_drag":"enable_precision_length_drag",
          "mesh_island_transform":"enable_mesh_island_transform"}

def operator(op):
    identifier=op.bl_idname
    if "." in identifier:return identifier.split(".",1)
    namespace,name=identifier.split("_OT_",1)
    return namespace.lower(),name

def guarded(op,fn,*args):
    try:
        status=fn(*args)
        return status if isinstance(status,set) else {"FINISHED"}
    except (ValueError,TypeError,KeyError,RuntimeError,AttributeError,OSError) as err:
        if getattr(op,"_selection_key",None):selection.finish(bpy.context)
        op.report({"WARNING"},str(err))
        return {"CANCELLED"}

def help_popup(op,ctx):
    from . import ui
    topic=getattr(op,"topic_key","") or getattr(op,"topic","") or "overview"
    ui.show_help(ctx,topic)

def action(op,ctx):
    ns,key=operator(op)
    w=ctx.window_manager;s=ctx.scene;p=interaction.prefs(ctx)
    if ns=="core":return transforms.core(op,ctx,key)
    if ns in {"transform","mesh"}:
        if "island_transform_toggle" in key:p.enable_mesh_island_transform=not p.enable_mesh_island_transform;return
        if key=="smart_align_to_vertex_normal":return align.normal_align(ctx)
        return interaction.transform(op,ctx,key,False)
    if ns=="object":
        if key=="quick_align_swap_refs":return align.swap(ctx)
        if key=="quick_align_reset_dialog":return align.reset(ctx)
        if hasattr(op,"_matrices"):
            align.preview=None
            restore_preview(op)
        result=align.align(op,ctx)
        if hasattr(op,"_matrices") and w.quick_align_settings.continuous_mode and not bpy.app.background:align.continue_once(ctx)
        return result
    if ns=="outliner" or "quick_multi_edit" in key:
        if key.endswith("restore_previous"):return selection.restore(ctx)
        if "collection" in key:return selection.collection(op,ctx,selection.action(op,key))
        raise ValueError("Invoke the picking tool in the 3D View")
    if key in {"open_help","show_tool_help","help_popup_dialog"}:return help_popup(op,ctx)
    if key=="copy_text":w.clipboard=op.text;return
    if key=="core" and not bpy.app.background:return bpy.ops.wm.call_panel(name="VIEW3D_PT_sts_transform_popup",keep_open=True)
    if key=="save_preferences":return storage.save()
    if key in {"set_always_on","toggle_persistent_feature"}:
        if key=="set_always_on":w.smart_transform_suite_always_on_enabled=op.enabled
        if op.alias and op.feature_key:
            storage.switch(w,op.alias,op.feature_key,op.enabled)
            if op.alias in FEATURES:setattr(p,FEATURES[op.alias],op.enabled)
        storage.changed(ctx);return
    if key in {"toggle_always_on_property","toggle_npanel_foldout"}:
        name=op.prop_name
        owners=(p,w,s,s.cursor_lock_props,p.core_panel)
        owner=next((x for x in owners if x.bl_rna.properties.get(name) and x.bl_rna.properties[name].type=="BOOLEAN"),None)
        if owner is None:raise ValueError("Unknown boolean setting")
        setattr(owner,name,not getattr(owner,name));return
    if key=="lazy_execute_operator":
        from . import schema
        name=op.target_operator
        if name not in schema.API["operators"] or name==op.bl_idname:raise ValueError("Choose a registered Smart Transform tool")
        group,leaf=name.split(".");return getattr(getattr(bpy.ops,group),leaf)("INVOKE_DEFAULT" if not bpy.app.background else "EXEC_DEFAULT")
    if key=="sts_toggle_cursor_lock":
        if not p.enable_cursor_lock_feature:raise ValueError("Enable cursor locking in Live Settings")
        lock=s.cursor_lock_props
        if not lock.enabled:lock.lock_location=s.cursor.location
        lock.enabled=not lock.enabled;return
    if key=="cycle_custom_select":return interaction.select_tool(ctx)
    if key=="csdt_reset_settings":
        for prop in p.bl_rna.properties:
            if prop.identifier.startswith(("smart_gizmo_","gizmo_","smart_axis_","smart_plane_","smart_center_","color_")):p.property_unset(prop.identifier)
        return
    if key=="csdt_toggle_smart_gizmo":p.gizmo_toggle_state=not p.gizmo_toggle_state;return
    if key=="select_guard_toggle":s.select_guard_enabled=not s.select_guard_enabled;return
    if key=="ssg_toggle_occluder_ignore_selected":
        objects=list(ctx.selected_objects)
        if not objects:raise ValueError("Select an occluding object")
        value=not all(o.ssg_ignore_as_occluder for o in objects)
        for obj in objects:obj.ssg_ignore_as_occluder=value
        return
    if key=="ssg_clear_hold_enable_key_shortcut":
        s.ssg_hold_enable_key="NONE";s.ssg_hold_enable_key_event="";return
    if key=="ssg_apply_prefs_to_scene":
        base=p.select_guard
        for prop in base.bl_rna.properties:
            n=prop.identifier
            if n.startswith("pref_"):
                field={"pref_scene_runtime_enabled":"select_guard_enabled","pref_click_filter":"ssg_enable_click_filter"}.get(n,"ssg_"+n[5:])
                if hasattr(s,field):setattr(s,field,getattr(base,n))
        return
    if key=="ssg_select_box_public":
        result=bpy.ops.view3d.select_box("EXEC_DEFAULT",mode=op.mode,wait_for_input=False)
        if s.select_guard_enabled:interaction.filter_selection(ctx)
        return result
    if key in {"core","csdt_force","sts_csdt_force","csdt_single_select_no_drag","csdt_click_select_drag",
               "csdt_smart_gizmo_watch","csdt_native_release_watch","sts_crossing_select_watch","select_guard_modal",
               "smart_transform_precision_numeric_drag","proportional_size_cursor","ssg_hold_enable_key"}:
        raise ValueError("Invoke this interactive control in the 3D View")
    raise ValueError("Unsupported context for "+key)

def execute(op,ctx):return guarded(op,action,op,ctx)

def restore_preview(op):
    for item,mat in op._matrices:
        if item.name in bpy.data.objects:item.matrix_world=mat
    bpy.context.view_layer.update()

def check(op,ctx):
    if hasattr(op,"_matrices"):
        restore_preview(op);align.align(op,ctx);return True
    return False

def cancel(op,ctx):
    if getattr(op,"_kind","")=="grs":
        grs.restore(op._backup,op._scene_mode);grs.remove_display(op)
    if hasattr(op,"_matrices"):
        align.preview=None
        restore_preview(op)
    if getattr(op,"_kind",None)=="guard_hold":ctx.scene.select_guard_enabled=op._was_guarded
    if getattr(op,"_selection_key",None):selection.finish(ctx)

def draw_dialog(op,ctx):
    from . import ui
    ui.draw_align(op.layout,ctx.window_manager.quick_align_settings)

def invoke_action(op,ctx,e):
    ns,key=operator(op)
    if ns=="core" and key in {"apply_all","apply_rs"}:return ctx.window_manager.invoke_confirm(op,e)
    if ns=="object" and key in {"quick_align_popup","quick_align_tool"}:
        s,target,items=align.references(op,ctx)
        if hasattr(op,"target_name"):op.target_name=target.name
        if hasattr(op,"source_names_json"):op.source_names_json=json.dumps([o.name for o in items])
        op._matrices=[(item,item.matrix_world.copy()) for item in [*items,target]]
        s.target_name=target.name;s.source_names_json=json.dumps([o.name for o in items])
        align.align(op,ctx)
        align.preview=op
        prefs=interaction.prefs(ctx).quick_align
        if key=="quick_align_tool" and prefs.warp_cursor_after_pick:
            x=min(ctx.window.width-10,max(10,e.mouse_x+prefs.warp_offset_px))
            ctx.window.cursor_warp(x,e.mouse_y)
        return ctx.window_manager.invoke_props_dialog(op,width=375)
    if ns=="transform" or key in {"smart_island_move","smart_island_rotate","smart_island_scale"}:
        action={"rotate":"rotate","scale":"resize","resize":"resize"}.get(key.split("_")[-1],"translate")
        return grs.begin(op,ctx,e,action)
    if ns=="view3d" and "quick_multi_edit" in key and "restore" not in key and "collection" not in key:return selection.begin(op,ctx,e,key)
    if key=="smart_transform_precision_numeric_drag":return interaction.start_precision(op,ctx,e)
    if key=="proportional_size_cursor":return interaction.start_radius(op,ctx,e)
    if key=="core":
        return bpy.ops.wm.call_panel(name="VIEW3D_PT_sts_transform_popup",keep_open=True)
    if key in {"csdt_force","sts_csdt_force","csdt_single_select_no_drag","csdt_click_select_drag"}:
        return interaction.begin_pick(op,ctx,e,key)
    if key=="ssg_select_box_public":
        return bpy.ops.view3d.select_box("INVOKE_DEFAULT",mode=op.mode,wait_for_input=op.wait_for_input)
    if key=="ssg_hold_enable_key":
        op._kind="guard_hold";op._event=e.type;op._was_guarded=ctx.scene.select_guard_enabled;ctx.scene.select_guard_enabled=True
        ctx.window_manager.modal_handler_add(op);return {"RUNNING_MODAL"}
    if key in {"csdt_smart_gizmo_watch","csdt_native_release_watch","sts_crossing_select_watch","select_guard_modal"}:
        op._kind="watch";op._watch=key;ctx.window_manager.modal_handler_add(op);return {"RUNNING_MODAL"}
    return action(op,ctx)

def invoke(op,ctx,e):return guarded(op,invoke_action,op,ctx,e)

def modal_action(op,ctx,e):
    if getattr(op,"_kind","")=="grs":return grs.modal(op,ctx,e)
    if hasattr(op,"_selection_key"):return selection.modal(op,ctx,e)
    if getattr(op,"_kind","")=="guard_hold":
        if e.type=="ESC" or (e.type==op._event and e.value=="RELEASE"):
            ctx.scene.select_guard_enabled=op._was_guarded;return {"FINISHED"}
        return {"PASS_THROUGH"}
    if getattr(op,"_kind","")=="watch":
        if op._watch=="sts_crossing_select_watch":
            from . import picking
            return picking.watch(op,ctx,e)
        if e.type=="ESC":return {"CANCELLED"}
        if e.type=="LEFTMOUSE" and e.value=="RELEASE":
            if op._watch=="select_guard_modal" and ctx.scene.select_guard_enabled:interaction.filter_selection(ctx)
            if op._watch=="csdt_native_release_watch":return {"FINISHED"}
        return {"PASS_THROUGH"}
    return interaction.modal(op,ctx,e)

def modal(op,ctx,e):return guarded(op,modal_action,op,ctx,e)
