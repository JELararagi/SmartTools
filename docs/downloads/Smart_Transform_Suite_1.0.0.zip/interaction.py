"""Use Blender's transform solvers and viewport selection primitives."""
import math
import bpy,bmesh
from mathutils import Vector,Matrix
from bpy_extras import view3d_utils
from . import selection,picking

def prefs(ctx):return ctx.window_manager.smart_transform_suite_runtime_preferences

def transform(op,ctx,key,invoke):
    suffix=key.rsplit("_",1)[-1]
    mode={"move":"translate","translate":"translate","rotate":"rotate","scale":"resize","resize":"resize"}.get(suffix)
    if not mode:
        text=(getattr(op,"mode","") or getattr(op,"action","")).lower()
        mode="rotate" if "rot" in text else "resize" if "scal" in text or "resize" in text else "translate"
    native=getattr(bpy.ops.transform,mode)
    if not native.poll():raise ValueError("Select a transformable object or element")
    allowed=native.get_rna_type().properties
    args={key:getattr(op,key) for key in op.properties.keys() if allowed.get(key) is not None}
    if mode=="rotate" and "orient_axis" in args and "constraint_axis" not in args:
        args["constraint_axis"]=tuple(c==args["orient_axis"] for c in "XYZ")
        args.setdefault("orient_type","GLOBAL")
    if not invoke and "value" not in args:
        invoke=True
    if invoke and bpy.app.background:raise ValueError("Open a 3D View for interactive transforms")
    if invoke:return native("INVOKE_DEFAULT",**args)
    from . import islands
    return islands.apply(ctx,mode,args)

def select_tool(ctx):
    p=prefs(ctx)
    choices=[(name,"builtin.select"+suffix) for name,suffix in (("TWEAK",""),("BOX","_box"),("CIRCLE","_circle"),("LASSO","_lasso"))
             if getattr(p,"custom_select_enable_"+name.lower())]
    if not choices:raise ValueError("Enable at least one selection tool")
    keys=[a for a,_ in choices]
    idx=keys.index(p.custom_select_mode) if p.custom_select_mode in keys else -1
    choice,tool=choices[(idx+1)%len(choices)]
    status=bpy.ops.wm.tool_set_by_id(name=tool,space_type="VIEW_3D")
    if "FINISHED" in status:p.custom_select_mode=choice;p.last_select_tool=tool
    return status

def start_precision(op,ctx,e):
    if not prefs(ctx).enable_precision_length_drag:raise ValueError("Enable precision numeric dragging")
    ptr=getattr(ctx,"button_pointer",None);prop=getattr(ctx,"button_prop",None)
    if ptr is None or prop is None or prop.type not in {"FLOAT","INT"} or prop.is_array:
        raise ValueError("Start the shortcut over a numeric field")
    op._field=(ptr,prop.identifier)
    op._start=op._last=e.mouse_x
    op._initial=getattr(ptr,prop.identifier)
    subtype=prop.subtype
    units={"LENGTH":"length","AREA":"area","VOLUME":"volume","ROTATION":"angle","TIME":"time","TIME_ABSOLUTE":"time_absolute","VELOCITY":"velocity","ACCELERATION":"acceleration","MASS":"mass","POWER":"power","TEMPERATURE":"temperature","CAMERA":"camera","WAVELENGTH":"wavelength","FREQUENCY":"frequency"}
    kind={"DISTANCE":"length","ANGLE":"angle","FACTOR":"factor","PERCENTAGE":"percentage","TIME":"time","POWER":"power"}.get(subtype,units.get(prop.unit,"number"))
    op._step=float(getattr(prefs(ctx),"precision_number_drag_step_"+kind))
    op._int=prop.type=="INT";op._kind="precision"
    ctx.window_manager.modal_handler_add(op)
    return {"RUNNING_MODAL"}

def start_radius(op,ctx,e):
    op._kind="radius";op._initial=ctx.scene.tool_settings.proportional_size
    op._start=e.mouse_x
    ctx.window_manager.modal_handler_add(op);return {"RUNNING_MODAL"}

def point_pick(ctx,p,extend=False):
    if ctx.mode!="OBJECT":
        if ctx.mode=="EDIT_MESH" and prefs(ctx).enable_back_element_click_select:
            result=picking.cycle_element(ctx,p,extend)
            if result:return result
        region=selection.window_region(ctx)
        with ctx.temp_override(region=region):return bpy.ops.view3d.select(location=(int(p.x),int(p.y)),extend=extend,deselect_all=not extend)
    pref=prefs(ctx)
    obj=picking.object_at(ctx,p,pref.enable_click_through)
    if obj is None and not pref.enable_bg_deselect:return {"FINISHED"}
    keep=obj and obj.select_get() and pref.keep_multi_selection
    if not extend and not keep:
        for selected in ctx.selected_objects:selected.select_set(False)
    if obj:
        obj.select_set(not obj.select_get() if extend else True)
        if obj.select_get() and (pref.update_active_element or not ctx.active_object):ctx.view_layer.objects.active=obj
    return {"FINISHED"}

def begin_pick(op,ctx,event,key):
    region=selection.window_region(ctx)
    p=selection.position(ctx,event) or Vector((region.width/2,region.height/2))
    op._start_xy=p.copy();op._kind="pick";op._pick_op=key
    from . import viewport
    op._action=(getattr(op,"action","") or getattr(op,"mode","") or viewport.tool(ctx)).lower()
    op._picked=prefs(ctx).use_immediate_select and event.type=="LEFTMOUSE" and event.value=="PRESS" and ctx.mode=="OBJECT"
    if op._picked:point_pick(ctx,p,event.shift)
    ctx.window_manager.modal_handler_add(op);return {"RUNNING_MODAL"}

def modal(op,ctx,e):
    kind=op._kind
    if e.type in {"ESC","RIGHTMOUSE"}:
        if kind=="radius":ctx.scene.tool_settings.proportional_size=op._initial
        if kind=="precision":setattr(op._field[0],op._field[1],op._initial)
        return {"CANCELLED"}
    if kind=="pick":
        p=selection.position(ctx,e)
        if p is None:return {"RUNNING_MODAL"}
        if e.type=="LEFTMOUSE" and e.value=="RELEASE":return {"FINISHED"} if op._picked else point_pick(ctx,p,e.shift)
        if e.type=="MOUSEMOVE" and (p-op._start_xy).length>prefs(ctx).drag_threshold and op._pick_op in {"csdt_force","sts_csdt_force","csdt_click_select_drag"}:
            if ctx.mode=="OBJECT" and not picking.object_at(ctx,op._start_xy,prefs(ctx).enable_click_through):
                if prefs(ctx).enable_bg_drag_select:
                    bpy.ops.view3d.select_box("INVOKE_DEFAULT",wait_for_input=False)
                    return {"FINISHED"}
                return {"CANCELLED"}
            if prefs(ctx).enable_drag_transform and any(x in op._action for x in ("move","rotate","scale","transform")):
                transform(op,ctx,op._action,True)
                return {"FINISHED"}
        return {"RUNNING_MODAL"}
    if e.type in {"RET","NUMPAD_ENTER","SPACE"} or (e.type=="LEFTMOUSE" and e.value=="RELEASE"):return {"FINISHED"}
    if e.type=="MOUSEMOVE":
        dx=e.mouse_x-op._start
        if kind=="precision":
            value=op._initial+dx*.5*op._step*(.1 if e.shift else 1)
            setattr(op._field[0],op._field[1],round(value) if op._int else value)
        if kind=="radius":ctx.scene.tool_settings.proportional_size=max(.00001,op._initial*math.exp(max(-18,min(18,dx*.008))))
    return {"RUNNING_MODAL"}

def ignored(ctx,obj):
    scene=ctx.scene
    group=scene.ssg_occluder_exclude_collection
    return obj.ssg_ignore_as_occluder or (group and obj.name in group.all_objects)

def visible_point(ctx,subject,point):
    rv=ctx.space_data.region_3d;region=selection.window_region(ctx)
    uv=view3d_utils.location_3d_to_region_2d(region,rv,point)
    if uv is None:return False
    origin=view3d_utils.region_2d_to_origin_3d(region,rv,uv,clamp=max(100,(point-rv.view_location).length+100))
    direction=(point-origin).normalized()
    eps=max(.00001,ctx.scene.ssg_eps)
    for _ in range(max(1,min(ctx.scene.ssg_max_steps,128))):
        distance=(point-origin).dot(direction)
        if distance<=eps:return True
        found,hit,normal,_,obj,_=ctx.scene.ray_cast(ctx.evaluated_depsgraph_get(),origin,direction,distance=distance+eps)
        if not found:return True
        if (point-hit).length<=eps*4:return True
        obj=obj.original
        if obj==subject:return subject.mode!="EDIT"
        if not ignored(ctx,obj) and ctx.scene.ssg_other_objects_occlude:
            if not ctx.scene.ssg_ignore_backface_occluders or normal.dot(direction)<=0:return False
        origin=hit+direction*eps
    return False

def filter_selection(ctx):
    scene=ctx.scene;space=ctx.space_data
    if scene.ssg_auto_bypass_xray and space.shading.show_xray:return
    if scene.ssg_auto_bypass_wireframe and space.shading.type=="WIREFRAME":return
    if ctx.mode=="EDIT_MESH":
        for obj in ctx.objects_in_mode_unique_data:
            bm=bmesh.from_edit_mesh(obj.data)
            for v in bm.verts:
                if v.select and not visible_point(ctx,obj,obj.matrix_world@v.co):v.select_set(False)
            bm.select_flush_mode();bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
    else:
        for obj in list(ctx.selected_objects):
            pts=[obj.matrix_world.translation]+[obj.matrix_world@Vector(v) for v in obj.bound_box]
            if not any(visible_point(ctx,obj,p) for p in pts):obj.select_set(False)
