"""Register Blender RNA from recorded identifiers, types, ranges and enum values."""
import json
from pathlib import Path
import bpy
from . import storage,transforms,edit_values

API=json.loads(Path(__file__).with_name("api.json").read_text("utf8"))
CLASSES={}
OWNERS=[]

def title(name):return name.replace("_"," ").title()

def on_update(name):
    def update(obj,ctx):
        if storage.busy:return
        if name=="preset" and obj.bl_rna.identifier=="QuickAlignSettings":
            from .align import preset
            preset(obj)
        if obj.bl_rna.identifier=="QuickAlignSettings" and name not in {"source_names_json","target_name","selected_names_json","initial_states_json","is_updating","last_preview_time","pending_update","timer_active"}:
            from . import align
            align.changed(ctx)
        storage.changed(ctx)
    return update

def prop(key,field,owner="",saved=False):
    kind=field["type"];options={"name":title(key)}
    if kind in {"POINTER","COLLECTION"}:
        typename=field["ref"]
        options["type"]=CLASSES.get(typename) or getattr(bpy.types,typename)
        if kind=="POINTER" and saved and typename not in CLASSES:options["update"]=on_update(key)
        return (bpy.props.PointerProperty if kind=="POINTER" else bpy.props.CollectionProperty)(**options)
    if saved:options["update"]=on_update(key)
    for option in ("unit","precision","step"):
        if option in field:options[option]=field[option]
    default=field.get("default")
    if "subtype" in field:options["subtype"]=field["subtype"]
    if "min" in field:options.update(min=field["min"],max=field["max"])
    if kind=="ENUM":
        options["items"]=[(s,title(s),"",ordinal) for s,ordinal in field["items"]]
        if default=="" and key=="snap_elements":options.update(options={"ENUM_FLAG"},default=set())
        else:options["default"]=default
        return bpy.props.EnumProperty(**options)
    options["default"]=default
    prefix=key.split("_")[0]
    if owner=="SmartTransformProps" and prefix in {"loc","rot","scale","dim"}:
        options.pop("update",None)
        options["get"]=lambda group:transforms.numeric_get(key,group)
        options["set"]=lambda group,value:transforms.numeric_set(key,group,value)
    edit_key = edit_values.ALIASES.get(key) if owner=="SmartTransformProps" else key.removeprefix("sts_popup_edit_") if owner=="Mesh" else None
    if edit_key and edit_key!="global_space":
        options.pop("update",None)
        options["get"]=lambda group:edit_values.get(edit_key)
        options["set"]=lambda group,value:edit_values.set_value(edit_key,value)
    if "array_length" in field:
        options["size"]=field["array_length"]
        ctor={"BOOLEAN":bpy.props.BoolVectorProperty,"FLOAT":bpy.props.FloatVectorProperty,"INT":bpy.props.IntVectorProperty}[kind]
    else:ctor={"STRING":bpy.props.StringProperty,"INT":bpy.props.IntProperty,"FLOAT":bpy.props.FloatProperty,"BOOLEAN":bpy.props.BoolProperty}[kind]
    return ctor(**options)

def operator_arguments(name):
    return {key:prop(key,f) for key,f in API["operators"][name].items()}

def register():
    pending=dict(API["groups"])
    while pending:
        available=[(k,v) for k,v in pending.items() if all(f.get("ref") not in pending for f in v.values())]
        if not available:raise RuntimeError("Circular Blender setting group")
        for name,fields in available:
            cls=type(name,(bpy.types.PropertyGroup,),{"__module__":__name__,"__annotations__":{key:prop(key,meta,name,True) for key,meta in fields.items()}})
            bpy.utils.register_class(cls);CLASSES[name]=cls;del pending[name]
    for owner,fields in API["roots"].items():
        cls=getattr(bpy.types,owner)
        for k,f in fields.items():
            if hasattr(cls,k):raise RuntimeError("Setting already registered: "+owner+"."+k)
            setattr(cls,k,prop(k,f,owner,saved=owner not in {"Mesh","Object"}));OWNERS.append((cls,k))

def unregister():
    for owner,k in reversed(OWNERS):
        if hasattr(owner,k):delattr(owner,k)
    OWNERS.clear()
    for cls in reversed(list(CLASSES.values())):bpy.utils.unregister_class(cls)
    CLASSES.clear()
