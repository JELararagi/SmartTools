# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from ..keymap_safety import safe_remove_keymap_item as _sts_safe_remove_keymap_item, restore_native_view3d_selection_routes as _restore_native_view3d_selection_routes

from .. import runtime as _runtime
from .. import ui_icons as _ui_icons
from .. import operator_safety as _op_safety
from ..translation import TI
import webbrowser
import time
import json
import re
from types import SimpleNamespace
from mathutils import Vector
from bpy_extras import view3d_utils
from bpy.props import (
    BoolProperty,
    StringProperty,
    EnumProperty,
    IntProperty,
    FloatProperty,
)



def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}


def _ui_label_kwargs(icon: str = 'NONE', custom_icon: str = ''):
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _draw_icon_label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> bool:
    try:
        layout.label(text=str(text or ''), **_ui_label_kwargs(icon, custom_icon))
        return True
    except TypeError:
        try:
            layout.label(text=str(text or ''), icon=icon or 'NONE')
            return True
        except Exception:
            return False
    except Exception:
        return False


def _operator(layout, operator_id: str, *, text: str = '', icon: str = 'NONE', custom_icon: str = '', emboss: bool | None = None, **props):
    icon_only = not str(text or '').strip()
    if emboss is None:
        emboss = True
    elif icon_only and emboss is False:
        emboss = True
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props)
    try:
        op = layout.operator(operator_id, text=text, emboss=emboss, **icon_args)
    except TypeError:
        try:
            op = layout.operator(operator_id, text=text, icon=icon, emboss=emboss)
        except TypeError:
            op = layout.operator(operator_id, text=text, icon=icon)
    for k, v in props.items():
        try:
            _safe_set_operator_property(op, k, v, operator_id=operator_id)
        except Exception:
            pass
    return op

bl_info = {
    "name": "Quick Multi-Edit",
    "author": "Smart Transform Suite",
    "version": (1, 8, 70),
    "blender": (5, 1, 0),
    "location": "View3D > Edit Mode (Shift/Ctrl/Alt + RMB/LMB)",
    "description": "Switch objects to multi-edit mode with Shift/Ctrl/Alt + mouse click while staying in Edit Mode.",
    "category": "3D View",
}

# -----------------------------------------------------------------------------
# Globals
# -----------------------------------------------------------------------------
addon_keymaps = []
_QME_DISABLED_ACTIVE_KMIS = []
_QME_DISABLED_USER_KMIS = []
_QME_DISABLED_DEFAULT_KMIS = []

# Cycle pick memory (per-window/region)
_cycle_state = {
    "t": 0.0,
    "mx": 0,
    "my": 0,
    "idx": 0,
    "objs": [],
}

# History memory (serialized into WindowManager string property)
_HISTORY_KEY = "qme_history_json"

# HUD
_hud = {
    "handle": None,
    "msg": "",
    "t": 0.0,
}

SUPPORTED_TYPES = {
    "MESH",
    "CURVE",
    "SURFACE",
    "META",
    "FONT",
    "ARMATURE",
}

_QME_OPERATOR_ID = "view3d.quick_multi_edit"
_QME_ADD_OPERATOR_ID = "view3d.quick_multi_edit_add"
_QME_REMOVE_OPERATOR_ID = "view3d.quick_multi_edit_remove"
_QME_TOGGLE_OPERATOR_ID = "view3d.quick_multi_edit_toggle"
_QME_ISOLATE_OPERATOR_ID = "view3d.quick_multi_edit_isolate"
_QME_OWNED_OPERATOR_IDS = {
    _QME_OPERATOR_ID,
    _QME_ADD_OPERATOR_ID,
    _QME_REMOVE_OPERATOR_ID,
    _QME_TOGGLE_OPERATOR_ID,
    _QME_ISOLATE_OPERATOR_ID,
    "view3d.quick_multi_edit_box",
    "view3d.quick_multi_edit_lasso",
    "view3d.quick_multi_edit_restore_previous",
    "view3d.quick_multi_edit_from_active_collection",
    "outliner.quick_multi_edit_from_collection",
}


_QME_CLICK_ADD_OPERATOR_ID = "view3d.quick_multi_edit_add"
_QME_CLICK_REMOVE_OPERATOR_ID = "view3d.quick_multi_edit_remove"
_QME_CLICK_TOGGLE_OPERATOR_ID = "view3d.quick_multi_edit_toggle"
_QME_CLICK_ISOLATE_OPERATOR_ID = "view3d.quick_multi_edit_isolate"
_QME_BOX_ADD_OPERATOR_ID = "view3d.quick_multi_edit_box_add"
_QME_BOX_REMOVE_OPERATOR_ID = "view3d.quick_multi_edit_box_remove"
_QME_BOX_TOGGLE_OPERATOR_ID = "view3d.quick_multi_edit_box_toggle"
_QME_LASSO_ADD_OPERATOR_ID = "view3d.quick_multi_edit_lasso_add"
_QME_LASSO_REMOVE_OPERATOR_ID = "view3d.quick_multi_edit_lasso_remove"
_QME_LASSO_TOGGLE_OPERATOR_ID = "view3d.quick_multi_edit_lasso_toggle"
_QME_COLLECTION_SET_OPERATOR_ID = "view3d.quick_multi_edit_collection_set"
_QME_COLLECTION_ADD_OPERATOR_ID = "view3d.quick_multi_edit_collection_add"
_QME_COLLECTION_REMOVE_OPERATOR_ID = "view3d.quick_multi_edit_collection_remove"
_QME_COLLECTION_TOGGLE_OPERATOR_ID = "view3d.quick_multi_edit_collection_toggle"

_QME_WRAPPER_OPERATOR_IDS = {
    _QME_CLICK_ADD_OPERATOR_ID,
    _QME_CLICK_REMOVE_OPERATOR_ID,
    _QME_CLICK_TOGGLE_OPERATOR_ID,
    _QME_CLICK_ISOLATE_OPERATOR_ID,
    _QME_BOX_ADD_OPERATOR_ID,
    _QME_BOX_REMOVE_OPERATOR_ID,
    _QME_BOX_TOGGLE_OPERATOR_ID,
    _QME_LASSO_ADD_OPERATOR_ID,
    _QME_LASSO_REMOVE_OPERATOR_ID,
    _QME_LASSO_TOGGLE_OPERATOR_ID,
    _QME_COLLECTION_SET_OPERATOR_ID,
    _QME_COLLECTION_ADD_OPERATOR_ID,
    _QME_COLLECTION_REMOVE_OPERATOR_ID,
    _QME_COLLECTION_TOGGLE_OPERATOR_ID,
}

# -----------------------------------------------------------------------------
# I18n
# -----------------------------------------------------------------------------
translations_dict = {
    "ja_JP": {
        ("*", "Switch objects to multi-edit mode with Shift/Ctrl/Alt + mouse click while staying in Edit Mode."):
            "編集モードのまま Shift/Ctrl/Alt + クリックでマルチ編集対象を切り替えます",
        ("*", "Keymap Settings"): "キーマップ設定",
        ("*", "Use Custom Keymap"): "カスタムキーマップを使用",
        ("*", "Manual shortcut reference only. The add-on does not create Quick Multi-Edit keymaps automatically; register the operator IDs manually in Blender Preferences > Keymap."):
            "チェックを入れるとデフォルトのショートカット登録を無効化し、ユーザー自身で自由にキーマップを割り当てられるようになります。",
        ("*", "Usage Guide (Manual Keymaps)"): "使用方法ガイド (デフォルトキーマップ)",
        ("*", "Shift + Click : Add clicked object to multi-edit"): "Shift + クリック : クリックしたオブジェクトをマルチ編集に追加",
        ("*", "Ctrl + Click : Remove clicked object from multi-edit"): "Ctrl + クリック : クリックしたオブジェクトをマルチ編集から除外",
        ("*", "Alt + Click : Switch Edit Mode to the clicked object only"): "Alt + クリック : クリックしたオブジェクトだけを選択・編集状態に切り替え",
        ("*", "Single-switch shortcut is optional in custom keymap mode"): "単独切り替えはカスタムキーマップ時のみ任意で設定できます",
        ("*", "Keymap Conflicts Check (Manual Keymaps)"): "キーマップ競合チェック (デフォルトキーマップ)",
        ("*", "No conflicts detected."): "競合は検出されませんでした。",
        ("*", "Conflict found in {}: {}"): "{} で競合を検出: {}",

        ("*", "Behavior"): "挙動",
        ("*", "Mouse Button (Manual Reference)"): "マウスボタン (デフォルトキーマップ)",
        ("*", "Auto (match selection style)"): "自動（選択方式に追従）",
        ("*", "Right Mouse Button"): "右クリック",
        ("*", "Left Mouse Button"): "左クリック",
        ("*", "Active Behavior"): "アクティブ挙動",
        ("*", "Move Active to Clicked"): "クリック先をアクティブにする",
        ("*", "Keep Current Active"): "現在のアクティブを維持",
        ("*", "Shift Action"): "Shift動作",
        ("*", "Filters"): "フィルター",
        ("*", "Restrict to same object type as active"): "アクティブと同じオブジェクトタイプのみ対象",
        ("*", "Respect visibility/selection locks"): "表示/選択ロックを尊重",
        ("*", "Only objects in the same collection as the clicked object"): "クリックしたオブジェクトと同じコレクションのみ対象",
        ("*", "Only objects with the same name prefix as the clicked object"): "クリックしたオブジェクトと同じ名前接頭辞のみ対象",
        ("*", "Custom name prefix"): "カスタム接頭辞",
        ("*", "Picking"): "ピッキング",
        ("*", "Enable cycle pick (behind objects)"): "背後オブジェクトのサイクルピックを有効化",
        ("*", "Cycle timeout (sec)"): "サイクル判定時間（秒）",
        ("*", "Cycle pixel threshold"): "サイクル判定ピクセル閾値",
        ("*", "Feedback"): "フィードバック",
        ("*", "Show HUD message in viewport"): "ビューポートにHUD表示",
        ("*", "HUD duration (sec)"): "HUD表示時間（秒）",
        ("*", "History"): "履歴",
        ("*", "History depth"): "履歴保持数",
        ("*", "Tools"): "ツール",
        ("*", "Box Select / Lasso Select operators are available for batch add/remove."):
            "ボックス選択／投げ縄選択オペレーターで一括追加・除外ができます。",

        ("*", "Custom Keymap Registration Guide"): "カスタムキーマップ登録ガイド",
        ("*", "1. Go to Edit > Preferences > Keymap"): "1. 編集 > プリファレンス > キーマップ を開く",
        ("*", "2. Navigate to 3D View > 3D View (Global)"): "2. 3Dビュー > 3Dビュー (グローバル) を展開",
        ("*", "3. Click 'Add New' at the bottom"): "3. 一番下の「新規追加」をクリック",
        ("*", "4. Paste the Operator ID below and set modifiers/action:"):
            "4. 以下のオペレーターIDを貼り付け、修飾キーとアクションを設定:",
        ("*", "Add Object"): "オブジェクトを追加",
        ("*", "Remove Object"): "オブジェクトを除外",
        ("*", "Switch to Clicked Only"): "クリックしたオブジェクトだけに切り替え",
        ("*", "Toggle Object"): "オブジェクトを切り替え",
        ("*", "Box Select (Batch)"): "ボックス選択（一括）",
        ("*", "Lasso Select (Batch)"): "投げ縄選択（一括）",
        ("*", "Restore Previous Multi-Edit Set"): "前のマルチ編集セットに戻す",

        ("*", "Operator ID"): "オペレーターID",
        ("*", "Action to perform"): "実行するアクション",
        ("*", "Add object to multi-edit"): "オブジェクトをマルチ編集に追加",
        ("*", "Remove object from multi-edit"): "オブジェクトをマルチ編集から除外",
        ("*", "Switch the multi-edit set to the clicked object only"): "クリックしたオブジェクトだけを選択・編集状態に切り替え",
        ("*", "Toggle object in multi-edit"): "クリックしたオブジェクトを追加/除外（切替）",
        ("*", "Batch add/remove/toggle objects using box selection"): "ボックス選択で一括 追加/除外/切替",
        ("*", "Batch add/remove/toggle objects using lasso selection"): "投げ縄選択で一括 追加/除外/切替",
        ("*", "Restore the previous multi-edit selection set"): "直前のマルチ編集セットを復元します",

        ("*", "Set Multi-Edit from Collection"): "コレクションからマルチ編集セットを作成",
        ("*", "Add Collection to Multi-Edit"): "コレクションをマルチ編集に追加",
        ("*", "Remove Collection from Multi-Edit"): "コレクションをマルチ編集から除外",
        ("*", "Choose the mouse button reference to use when manually registering Quick Multi-Edit add, remove, toggle, and switch shortcuts."): "クイック複数編集の追加・除外・切替・単独切替ショートカットを手動登録する際に基準とするマウスボタンを選びます。",
        ("*", "Follow Blender's selection mouse style when choosing the manual-reference mouse button."): "手動登録の基準マウスボタンをBlenderの選択マウス設定に合わせます。",
        ("*", "Use the right mouse button as the manual Quick Multi-Edit shortcut reference."): "右マウスボタンをクイック複数編集ショートカットの手動登録基準にします。",
        ("*", "Use the left mouse button as the manual Quick Multi-Edit shortcut reference."): "左マウスボタンをクイック複数編集ショートカットの手動登録基準にします。",
        ("*", "Choose how the active edit object is handled after adding or switching objects in the multi-edit set."): "マルチ編集セットへの追加や切り替え後に、アクティブな編集オブジェクトをどう扱うかを選びます。",
        ("*", "Make the clicked object the active object after the Quick Multi-Edit action."): "クイック複数編集の操作後、クリックしたオブジェクトをアクティブオブジェクトにします。",
        ("*", "Keep the current active object unchanged while changing the multi-edit set."): "マルチ編集セットを変更しても、現在のアクティブオブジェクトを維持します。",
        ("*", "Choose what the Shift-modified Quick Multi-Edit shortcut does to the clicked object."): "Shift修飾のクイック複数編集ショートカットがクリックしたオブジェクトに行う動作を選びます。",
        ("*", "Add the clicked object to the current multi-edit set."): "クリックしたオブジェクトを現在のマルチ編集セットに追加します。",
        ("*", "Toggle the clicked object in or out of the current multi-edit set."): "クリックしたオブジェクトのマルチ編集セットへの追加/除外を切り替えます。",
        ("*", "Limit Quick Multi-Edit clicks to objects with the same Blender object type as the current active object."): "クイック複数編集のクリック対象を、現在のアクティブオブジェクトと同じオブジェクトタイプに限定します。",
        ("*", "Skip objects that are hidden, unselectable, or otherwise locked from normal viewport selection."): "非表示・選択不可など、通常のビューポート選択がロックされたオブジェクトを対象から除外します。",
        ("*", "Restrict candidate objects to the collection membership of the clicked object."): "候補オブジェクトを、クリックしたオブジェクトが属するコレクション内に制限します。",
        ("*", "Restrict candidate objects to matching name prefixes so related mesh parts can be edited together."): "候補オブジェクトを名前のプレフィックスが一致するものに制限し、関連するメッシュパーツをまとめて編集できるようにします。",
        ("*", "Optional prefix used by the name-prefix filter. Leave blank to derive the prefix from the clicked object."): "名前プレフィックスフィルターで使用する任意のプレフィックスです。空欄の場合はクリックしたオブジェクトから自動的に導出します。",
        ("*", "When multiple objects overlap under the cursor, allow repeated clicks to cycle through hidden or behind-object candidates."): "カーソル下で複数のオブジェクトが重なっている場合に、繰り返しクリックで背面や隠れた候補を順番に選べるようにします。",
        ("*", "Maximum time between repeated clicks for them to count as the same cycle-pick sequence."): "同じサイクルピック操作として扱う、クリック間の最大時間です。",
        ("*", "Maximum cursor movement in pixels allowed between repeated cycle-pick clicks."): "サイクルピックの繰り返しクリック間で許容されるカーソル移動量（ピクセル）の最大値です。",
        ("*", "Max Cycle Hits"): "最大サイクル候補数",
        ("*", "Maximum number of overlapping object candidates stored for cycle picking."): "サイクルピック用に保持する重なりオブジェクト候補の最大数です。",
        ("*", "Show a short viewport HUD message after Quick Multi-Edit actions."): "クイック複数編集の操作後に、短いHUDメッセージをビューポートへ表示します。",
        ("*", "How long the Quick Multi-Edit viewport HUD message remains visible."): "クイック複数編集のHUDメッセージを表示し続ける時間です。",
        ("*", "Number of previous multi-edit sets kept so Restore Previous can recover recent selections."): "「前の状態を復元」で最近の選択を戻せるよう保持する、過去のマルチ編集セット数です。",
    }
}

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def _pgettext(text: str) -> str:
    try:
        return bpy.app.translations.pgettext_iface(text)
    except Exception:
        return text


def _qme_action_label(action: object) -> str:
    value = str(action or '').upper()
    return {
        'SET': TI('Set', '設定'),
        'ADD': TI('Add', '加算'),
        'REMOVE': TI('Remove', '減算'),
        'TOGGLE': TI('Toggle', '切替'),
        'ISOLATE': TI('Solo', '単独'),
    }.get(value, str(action or ''))


def _qme_box_label(action: object) -> str:
    label = _qme_action_label(action)
    return TI(f'Box {label}', f'箱で{label}')


def _qme_lasso_label(action: object) -> str:
    label = _qme_action_label(action)
    return TI(f'Lasso {label}', f'縄で{label}')


def _qme_collection_label(action: object) -> str:
    label = _qme_action_label(action)
    return TI(f'Collection {label}', f'コレクション{label}')

def _suite_prefs(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None

_QME_DEFAULT_PREFS = SimpleNamespace(
    enable_keymaps=False,
    use_custom_keymap=False,
    default_mouse_button='RIGHTMOUSE',
    active_behavior='MOVE',
    shift_action='ADD',
    custom_add_type='RIGHTMOUSE',
    custom_add_value='PRESS',
    custom_add_shift=True,
    custom_add_ctrl=False,
    custom_add_alt=False,
    custom_add_oskey=False,
    custom_remove_type='RIGHTMOUSE',
    custom_remove_value='PRESS',
    custom_remove_shift=False,
    custom_remove_ctrl=True,
    custom_remove_alt=False,
    custom_remove_oskey=False,
    custom_toggle_type='RIGHTMOUSE',
    custom_toggle_value='PRESS',
    custom_toggle_shift=False,
    custom_toggle_ctrl=False,
    custom_toggle_alt=True,
    custom_toggle_oskey=False,
    custom_isolate_type='NONE',
    custom_isolate_value='PRESS',
    custom_isolate_shift=False,
    custom_isolate_ctrl=False,
    custom_isolate_alt=False,
    custom_isolate_oskey=False,
    restrict_same_type=True,
    respect_visibility_select_lock=True,
    filter_same_collection=False,
    filter_name_prefix=False,
    custom_name_prefix='',
    enable_cycle_pick=True,
    cycle_timeout=0.5,
    cycle_pixel_threshold=6,
    max_cycle_hits=8,
    fast_path_no_mode_toggle=True,
    show_status_report=True,
    show_hud=False,
    hud_duration=1.2,
    history_depth=10,
    action_isolate_only_clicked=False,
)


def _get_prefs(context):
    prefs = _suite_prefs(context)
    subgroup = getattr(prefs, 'quick_multi_edit', None) if prefs else None
    return subgroup if subgroup is not None else _QME_DEFAULT_PREFS

def _mouse_button_pref(context) -> str:
    """Return 'LEFTMOUSE' or 'RIGHTMOUSE' for manual keymap reference display."""
    prefs = _get_prefs(context)
    if not prefs:
        return "RIGHTMOUSE"

    if prefs.default_mouse_button == "LEFTMOUSE":
        return "LEFTMOUSE"
    if prefs.default_mouse_button == "RIGHTMOUSE":
        return "RIGHTMOUSE"

    # AUTO: match selection style by using the opposite mouse button
    # - If user selects with RIGHT, default to LEFT (avoid conflicts).
    # - Else (LEFT select), default to RIGHT (original behavior).
    try:
        sel = getattr(context.preferences.inputs, "select_mouse", "LEFT")
    except Exception:
        sel = "LEFT"

    return "LEFTMOUSE" if str(sel).upper().startswith("RIGHT") else "RIGHTMOUSE"

def _is_region_valid(context) -> bool:
    return (
        context.area is not None
        and context.area.type == "VIEW_3D"
        and context.region is not None
        and getattr(context.region, "type", "") == "WINDOW"
        and context.region_data is not None
    )

_QME_VIEW_NAVIGATION_EVENTS = {
    'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM',
}


def _qme_view_region_under_mouse(context, event):
    """Return (area, region) of the 3D View main region under the mouse, or None."""
    mx, my = event.mouse_x, event.mouse_y
    for area in context.window.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        if not (area.x <= mx < area.x + area.width and area.y <= my < area.y + area.height):
            continue
        found = None
        for region in area.regions:
            if not (region.x <= mx < region.x + region.width and region.y <= my < region.y + region.height):
                continue
            if region.type != 'WINDOW':
                return None
            found = region
        return (area, found) if found is not None else None
    return None


def _qme_refuse_view_strip_press(context, event, report_fn):
    """With region overlap the sidebar and toolbar strips sit over the view: refuse a press there."""
    if not context.preferences.system.use_region_overlap:
        return False
    mx, my = event.mouse_x, event.mouse_y
    for area in context.window.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        if not (area.x <= mx < area.x + area.width and area.y <= my < area.y + area.height):
            continue
        for region in area.regions:
            if region.type not in {'UI', 'TOOLS'}:
                continue
            if region.x <= mx < region.x + region.width and region.y <= my < region.y + region.height:
                report_fn({'INFO'}, TI(
                    'The sidebar and toolbar strips cannot be picked. Use the rest of the 3D View, or press Esc to cancel.',
                    'サイドバーとツールバーの帯の上は選べません。3D ビューのほかの所を使うか、Esc で取り消します。',
                ))
                return True
    return False


def _qme_begin_view_wait(context, hint):
    """Panel buttons: wait in a modal handler until the user acts in the 3D View."""
    try:
        context.window.cursor_modal_set('CROSSHAIR')
    except Exception:
        pass
    try:
        context.workspace.status_text_set(hint)
    except Exception:
        pass
    _show_hud_message(context, hint)


def _qme_end_view_wait(context):
    try:
        context.window.cursor_modal_restore()
    except Exception:
        pass
    try:
        context.workspace.status_text_set(None)
    except Exception:
        pass
    _hud["msg"] = ""


def _qme_view_operator_poll(context):
    obj = context.active_object
    return (
        obj is not None
        and str(context.mode).startswith('EDIT')
        and obj.type in SUPPORTED_TYPES
        and context.area is not None
        and context.area.type == "VIEW_3D"
    )


def _obj_visible_selectable(context, obj) -> bool:
    """Visibility + selectability check."""
    if obj is None:
        return False
    try:
        if hasattr(obj, "visible_get"):
            if not obj.visible_get(view_layer=context.view_layer):
                return False
        else:
            if getattr(obj, "hide_viewport", False):
                return False
    except Exception:
        pass
    if getattr(obj, "hide_select", False):
        return False
    return True

def _strip_numeric_suffix(name: str) -> str:
    # "Object.001" -> "Object"
    return re.sub(r"\.\d{3}$", "", name)

def _auto_name_prefix(clicked_name: str) -> str:
    base = _strip_numeric_suffix(clicked_name)
    # Prefer underscore groups if present: "car_body" -> "car_"
    if "_" in base:
        return base.split("_", 1)[0] + "_"
    return base

def _shares_any_collection(a, b) -> bool:
    try:
        a_cols = set(a.users_collection)
        b_cols = set(b.users_collection)
        return len(a_cols.intersection(b_cols)) > 0
    except Exception:
        return False

def _eligible_object(context, obj, active_obj, clicked_obj=None) -> bool:
    prefs = _get_prefs(context)
    if obj is None:
        return False
    if obj == active_obj and prefs and prefs.action_isolate_only_clicked:
        # not used; keep compatibility hook
        pass

    # Supported types
    if obj.type not in SUPPORTED_TYPES:
        return False

    # Visibility/selectability
    if prefs and prefs.respect_visibility_select_lock:
        if not _obj_visible_selectable(context, obj):
            return False

    # Type restriction
    if prefs and prefs.restrict_same_type and active_obj is not None:
        if obj.type != active_obj.type:
            return False

    # Reference object for filters (prefer active object if available)
    ref_obj = clicked_obj if clicked_obj is not None else active_obj

    # Collection filter
    if prefs and prefs.filter_same_collection and ref_obj is not None:
        if not _shares_any_collection(obj, ref_obj):
            return False

    # Name prefix filter
    if prefs and prefs.filter_name_prefix and ref_obj is not None:
        prefix = prefs.custom_name_prefix.strip()
        if not prefix:
            prefix = _auto_name_prefix(ref_obj.name)
        if not obj.name.startswith(prefix):
            return False

    return True

def _ray_multi_hits(context, event, max_hits=8):
    """Return a list of hit objects (front -> back), unique by object."""
    if not _is_region_valid(context):
        return []

    region = context.region
    rv3d = context.region_data
    coord = (event.mouse_region_x, event.mouse_region_y)

    view_vec = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

    depsgraph = context.evaluated_depsgraph_get()
    scene = context.scene

    hits = []
    origin = ray_origin
    direction = view_vec.normalized()

    # Try to use distance argument if available
    for _i in range(max_hits * 3):
        try:
            res = scene.ray_cast(depsgraph, origin, direction, distance=1.0e12)
        except TypeError:
            res = scene.ray_cast(depsgraph, origin, direction)

        if not res:
            break

        result, location, normal, index, obj, matrix = res
        if not result or obj is None:
            break

        if obj not in hits:
            hits.append(obj)
            if len(hits) >= max_hits:
                break

        # Step forward slightly to find next hit behind
        try:
            origin = location + direction * 1.0e-4
        except Exception:
            break

    return hits

def _cycle_pick(context, event, objs):
    """Cycle through objs when repeated clicks are near same mouse position."""
    prefs = _get_prefs(context)
    if not prefs or not prefs.enable_cycle_pick:
        return objs[0] if objs else None

    now = time.time()
    mx, my = int(event.mouse_region_x), int(event.mouse_region_y)

    same_pos = (abs(mx - _cycle_state["mx"]) <= prefs.cycle_pixel_threshold and
                abs(my - _cycle_state["my"]) <= prefs.cycle_pixel_threshold)
    in_time = (now - _cycle_state["t"] <= prefs.cycle_timeout)

    if (same_pos and in_time and _cycle_state["objs"]):
        # If the hit list is different, reset index
        if [o.name for o in _cycle_state["objs"]] != [o.name for o in objs]:
            _cycle_state["idx"] = 0
            _cycle_state["objs"] = objs
        else:
            _cycle_state["idx"] = (_cycle_state["idx"] + 1) % max(1, len(objs))
    else:
        _cycle_state["idx"] = 0
        _cycle_state["objs"] = objs

    _cycle_state["t"] = now
    _cycle_state["mx"] = mx
    _cycle_state["my"] = my

    return objs[_cycle_state["idx"]] if objs else None

def _push_history(context, active_name, selected_names):
    prefs = _get_prefs(context)
    if not prefs or prefs.history_depth <= 0:
        return
    wm = context.window_manager
    try:
        raw = getattr(wm, _HISTORY_KEY, "[]")
        stack = json.loads(raw) if raw else []
        if not isinstance(stack, list):
            stack = []
    except Exception:
        stack = []

    entry = {
        "scene": getattr(context.scene, "name", ""),
        "active": active_name or "",
        "selected": list(selected_names) if selected_names else [],
        "t": time.time(),
    }
    stack.append(entry)
    if len(stack) > int(prefs.history_depth):
        stack = stack[-int(prefs.history_depth):]

    try:
        setattr(wm, _HISTORY_KEY, json.dumps(stack))
    except Exception:
        pass

def _pop_history(context):
    wm = context.window_manager
    try:
        raw = getattr(wm, _HISTORY_KEY, "[]")
        stack = json.loads(raw) if raw else []
        if not isinstance(stack, list) or not stack:
            return None
        entry = stack.pop()
        setattr(wm, _HISTORY_KEY, json.dumps(stack))
        return entry
    except Exception:
        return None

def _show_hud_message(context, msg: str):
    prefs = _get_prefs(context)
    if not prefs or not prefs.show_hud:
        return
    _hud["msg"] = msg
    _hud["t"] = time.time()
    _ensure_hud_handler()

def _draw_hud():
    import blf
    ctx = bpy.context
    prefs = _get_prefs(ctx)
    if not prefs or not prefs.show_hud:
        _hud["msg"] = ""
        _remove_hud_handler()
        return
    if not _hud["msg"]:
        _remove_hud_handler()
        return
    if (time.time() - _hud["t"]) > prefs.hud_duration:
        _hud["msg"] = ""
        _remove_hud_handler()
        return

    # Draw in bottom-left of the active region
    region = getattr(ctx, "region", None)
    if not region:
        return
    x = 20
    y = 40
    try:
        blf.position(0, x, y, 0)
        try:
            blf.size(0, 14)
        except TypeError:
            blf.size(0, 14, 72)
        blf.draw(0, _hud["msg"])
    except Exception:
        pass

def _ensure_hud_handler():
    if _hud["handle"] is not None:
        return
    try:
        _hud["handle"] = bpy.types.SpaceView3D.draw_handler_add(_draw_hud, (), 'WINDOW', 'POST_PIXEL')
    except Exception:
        _hud["handle"] = None

def _remove_hud_handler():
    if _hud["handle"] is None:
        return
    try:
        bpy.types.SpaceView3D.draw_handler_remove(_hud["handle"], 'WINDOW')
    except Exception:
        pass
    _hud["handle"] = None

def _object_identity_key(obj):
    if obj is None:
        return None
    try:
        return int(obj.as_pointer())
    except Exception:
        return id(obj)


def _unique_supported_objects(objects, required_type=None):
    result = []
    seen = set()
    for obj in objects or ():
        if obj is None:
            continue
        obj_type = getattr(obj, "type", None)
        if obj_type not in SUPPORTED_TYPES:
            continue
        if required_type and obj_type != required_type:
            continue
        key = _object_identity_key(obj)
        if key in seen:
            continue
        seen.add(key)
        result.append(obj)
    return result


def _same_object_set(a_objects, b_objects):
    return {
        _object_identity_key(obj)
        for obj in (a_objects or [])
        if obj is not None
    } == {
        _object_identity_key(obj)
        for obj in (b_objects or [])
        if obj is not None
    }


def _current_multi_edit_objects(context):
    active = getattr(context, "active_object", None)
    required_type = None
    if str(getattr(context, "mode", "")).startswith("EDIT") and active is not None:
        required_type = getattr(active, "type", None)

    for attr_name in ("objects_in_mode", "selected_objects"):
        try:
            objs = list(getattr(context, attr_name))
        except Exception:
            objs = None
        if not objs:
            continue
        normalized = _unique_supported_objects(objs, required_type=required_type)
        if normalized:
            return normalized
    return []


def _restore_object_selection(context, original_mode, original_selected, original_active):
    try:
        if not str(getattr(context, "mode", "")).startswith("OBJECT"):
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:
        pass

    try:
        bpy.ops.object.select_all(action='DESELECT')
    except Exception:
        for obj in getattr(context.view_layer, "objects", ()):
            try:
                obj.select_set(False)
            except Exception:
                pass

    for obj in original_selected or []:
        try:
            obj.select_set(True)
        except Exception:
            pass

    active_to_restore = None
    if original_active is not None and original_active in (original_selected or []):
        active_to_restore = original_active
    elif original_selected:
        active_to_restore = original_selected[0]
    elif original_active is not None:
        active_to_restore = original_active

    if active_to_restore is not None:
        try:
            context.view_layer.objects.active = active_to_restore
        except Exception:
            pass

    try:
        context.view_layer.update()
    except Exception:
        pass

    if str(original_mode).startswith("EDIT") and original_selected:
        try:
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:
            pass


def _drop_shared_data_objects(objs, prefer=()):
    """Blender enters Edit Mode only once per data-block: keep one object for each."""
    ordered = []
    for obj in list(prefer) + list(objs):
        if obj in objs and obj not in ordered:
            ordered.append(obj)
    seen = set()
    kept = []
    dropped = []
    for obj in ordered:
        data = getattr(obj, 'data', None)
        if data is not None and data.as_pointer() in seen:
            dropped.append(obj)
            continue
        if data is not None:
            seen.add(data.as_pointer())
        kept.append(obj)
    return kept, dropped


def _report_shared_data_objects(report_fn, dropped):
    if report_fn and dropped:
        names = ', '.join(obj.name for obj in dropped[:3])
        if len(dropped) > 3:
            names += ', ...'
        report_fn({'WARNING'}, TI(
            f'Objects that share the same mesh cannot be edited together, so they were left out: {names}',
            f'同じメッシュを共有する物は一緒に編集できないので、外しました：{names}',
        ))


def _set_selection_set(context, new_selected, new_active, report_fn=None):
    """Apply selection set as multi-edit set, with rollback safety."""
    required_type = getattr(new_active, "type", None)
    if required_type is None:
        current_active = getattr(context, "active_object", None)
        required_type = getattr(current_active, "type", None)

    new_selected = _unique_supported_objects(new_selected, required_type=required_type)
    if not new_selected:
        if report_fn:
            report_fn({'INFO'}, TI('No objects selected.', 'オブジェクトが選択されていません。'))
        return False

    if new_active not in new_selected:
        new_active = new_selected[0]

    original_mode = getattr(context, "mode", "OBJECT")
    original_active = getattr(context, "active_object", None)
    if str(original_mode).startswith("EDIT"):
        original_selected = _current_multi_edit_objects(context)
    else:
        original_selected = _unique_supported_objects(
            list(getattr(context, "selected_objects", [])),
            required_type=getattr(original_active, "type", None),
        )

    dropped = []
    if str(original_mode).startswith("EDIT"):
        # Objects already being edited win over the ones being added.
        new_selected, dropped = _drop_shared_data_objects(new_selected, prefer=list(original_selected) + [new_active])
        if new_active not in new_selected:
            new_active = original_active if original_active in new_selected else new_selected[0]
    _report_shared_data_objects(report_fn, dropped)

    if (
        str(original_mode).startswith("EDIT")
        and _same_object_set(_current_multi_edit_objects(context), new_selected)
        and context.active_object == new_active
    ):
        return not dropped

    try:
        if not str(getattr(context, "mode", "")).startswith("OBJECT"):
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')

        for obj in new_selected:
            obj.select_set(True)

        context.view_layer.objects.active = new_active

        try:
            context.view_layer.update()
        except Exception:
            pass

        if str(original_mode).startswith("EDIT"):
            bpy.ops.object.mode_set(mode='EDIT')
            actual_selected = _current_multi_edit_objects(context)
        else:
            actual_selected = _unique_supported_objects(
                list(getattr(context, "selected_objects", [])),
                required_type=required_type,
            )

        if not _same_object_set(actual_selected, new_selected):
            raise RuntimeError("selection set mismatch")
        if new_active is not None and context.active_object != new_active:
            raise RuntimeError("active object mismatch")
        return True
    except Exception:
        _restore_object_selection(context, original_mode, original_selected, original_active)
        if report_fn:
            report_fn({'WARNING'}, TI('Could not switch the edit set.', '編集の組を切り替えられませんでした。'))
        return False


def _apply_reference_action_to_target(context, target_obj, action: str, new_active=None, report_fn=None):
    """Apply the original standalone add-on behavior as the primary click path."""
    active_before = getattr(context, 'active_object', None)
    original_mode = getattr(context, 'mode', 'OBJECT')
    required_type = getattr(active_before, 'type', None) or getattr(target_obj, 'type', None)

    if str(original_mode).startswith('EDIT'):
        original_selected = _current_multi_edit_objects(context)
    else:
        original_selected = _unique_supported_objects(
            list(getattr(context, 'selected_objects', [])),
            required_type=required_type,
        )

    if not original_selected and active_before is not None:
        original_selected = _unique_supported_objects([active_before], required_type=required_type)

    def _rollback():
        _restore_object_selection(context, original_mode, original_selected, active_before)

    try:
        if not str(getattr(context, 'mode', '')).startswith('OBJECT'):
            bpy.ops.object.mode_set(mode='OBJECT')

        selected_before = _unique_supported_objects(
            list(getattr(context, 'selected_objects', [])),
            required_type=required_type,
        )

        if action == 'ADD':
            target_obj.select_set(True)
            selected_after = _unique_supported_objects(
                list(getattr(context, 'selected_objects', [])),
                required_type=required_type,
            )
            active_after = target_obj
        elif action == 'REMOVE':
            if target_obj in selected_before and len(selected_before) <= 1:
                if report_fn:
                    report_fn({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                _rollback()
                return False
            target_obj.select_set(False)
            selected_after = _unique_supported_objects(
                list(getattr(context, 'selected_objects', [])),
                required_type=required_type,
            )
            if not selected_after:
                if report_fn:
                    report_fn({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                _rollback()
                return False
            if new_active is not None and new_active in selected_after:
                active_after = new_active
            elif active_before in selected_after:
                active_after = active_before
            else:
                active_after = selected_after[0]
        elif action == 'TOGGLE':
            will_select = target_obj not in selected_before
            if (not will_select) and len(selected_before) <= 1:
                if report_fn:
                    report_fn({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                _rollback()
                return False
            target_obj.select_set(will_select)
            selected_after = _unique_supported_objects(
                list(getattr(context, 'selected_objects', [])),
                required_type=required_type,
            )
            if not selected_after:
                if report_fn:
                    report_fn({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                _rollback()
                return False
            if will_select:
                active_after = target_obj
            elif new_active is not None and new_active in selected_after:
                active_after = new_active
            elif active_before in selected_after:
                active_after = active_before
            else:
                active_after = selected_after[0]
        elif action == 'ISOLATE':
            bpy.ops.object.select_all(action='DESELECT')
            target_obj.select_set(True)
            selected_after = [target_obj]
            active_after = target_obj
        else:
            _rollback()
            return False

        if not selected_after:
            if report_fn:
                report_fn({'INFO'}, TI('No objects selected.', 'オブジェクトが選択されていません。'))
            _rollback()
            return False

        context.view_layer.objects.active = active_after

        try:
            context.view_layer.update()
        except Exception:
            pass

        if str(original_mode).startswith('EDIT'):
            bpy.ops.object.mode_set(mode='EDIT')
            actual_selected = _current_multi_edit_objects(context)
            if not _same_object_set(actual_selected, selected_after):
                raise RuntimeError('selection set mismatch')
            if context.active_object != active_after:
                raise RuntimeError('active object mismatch')

        return True
    except Exception:
        _rollback()
        return False


def _apply_action_to_target(context, target_obj, action: str, report_fn=None):
    """Compute and apply new multi-edit set based on action and target."""
    active = context.active_object
    prefs = _get_prefs(context)

    current = _current_multi_edit_objects(context)
    current_set = set(current)

    if action in {'ADD', 'TOGGLE'} and target_obj not in current_set:
        if _drop_shared_data_objects(current + [target_obj], prefer=current)[1]:
            _report_shared_data_objects(report_fn, [target_obj])
            return False

    if action == 'ADD':
        new_set = list(current)
        if target_obj not in current_set:
            new_set.append(target_obj)
    elif action == 'REMOVE':
        if target_obj not in current_set:
            return True
        new_set = [obj for obj in current if obj != target_obj]
        if not new_set:
            if report_fn:
                report_fn({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
            return False
    elif action == 'TOGGLE':
        if target_obj in current_set:
            new_set = [obj for obj in current if obj != target_obj]
            if not new_set:
                if report_fn:
                    report_fn({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                return False
        else:
            new_set = list(current)
            new_set.append(target_obj)
    elif action == 'ISOLATE':
        if _same_object_set(current, [target_obj]) and context.active_object == target_obj:
            return True
        new_set = [target_obj]
    else:
        return False

    new_set = _unique_supported_objects(new_set, required_type=getattr(target_obj, 'type', None))

    new_active = active
    if action == 'ISOLATE':
        new_active = target_obj
    else:
        if prefs and prefs.active_behavior == 'MOVE':
            if action == 'ADD' or (action == 'TOGGLE' and target_obj in new_set):
                new_active = target_obj
        if new_active not in new_set:
            new_active = new_set[0] if new_set else None

    _push_history(context, getattr(active, "name", ""), [o.name for o in current])

    ok = _apply_reference_action_to_target(context, target_obj, action, new_active=new_active, report_fn=report_fn)
    if not ok:
        ok = _set_selection_set(context, new_set, new_active, report_fn=report_fn)

    if ok and report_fn and prefs and prefs.show_status_report:
        msg = f"{_qme_action_label(action)}: {target_obj.name}"
        report_fn({'INFO'}, msg)
        _show_hud_message(context, msg)
    elif ok and prefs and prefs.show_hud:
        msg = f"{_qme_action_label(action)}: {target_obj.name}"
        _show_hud_message(context, msg)
    return ok

# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

def _invoke_click_action(context, event, action: str, report_fn=None, *, allow_modifier_fallback: bool = False):
    if not _is_region_valid(context):
        return {'PASS_THROUGH'}

    prefs = _get_prefs(context)
    active_obj = context.active_object

    action = str(action or 'ADD')
    if allow_modifier_fallback and action == 'ADD':
        if bool(getattr(event, 'alt', False)) and not bool(getattr(event, 'shift', False)) and not bool(getattr(event, 'ctrl', False)):
            action = 'ISOLATE'
        elif bool(getattr(event, 'ctrl', False)) and bool(getattr(event, 'shift', False)):
            action = 'TOGGLE'
        elif bool(getattr(event, 'ctrl', False)):
            action = 'REMOVE'

    if action not in {'ADD', 'REMOVE', 'TOGGLE', 'ISOLATE'}:
        action = 'ADD'

    hits = _ray_multi_hits(context, event, max_hits=(prefs.max_cycle_hits if prefs else 8))
    if not hits:
        return {'PASS_THROUGH'}

    target_raw = _cycle_pick(context, event, hits)
    ordered_hits = []
    if target_raw is not None:
        ordered_hits.append(target_raw)
    for obj in hits:
        if obj not in ordered_hits:
            ordered_hits.append(obj)

    target = None
    for obj in ordered_hits:
        if _eligible_object(context, obj, active_obj, clicked_obj=obj):
            target = obj
            break
    if target is None:
        return {'PASS_THROUGH'}

    ok = _apply_action_to_target(context, target, action, report_fn=report_fn)
    return {'FINISHED'} if ok else {'CANCELLED'}


class VIEW3D_OT_quick_multi_edit(bpy.types.Operator):
    bl_idname = _QME_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit', 'クイック複数編集')
    bl_description = TI('Shift/Ctrl/Alt click to add, remove, toggle, or switch Edit Mode to the clicked object while staying in Edit Mode', '編集モードを維持したまま Shift/Ctrl/Alt + クリックで、クリックしたオブジェクトの追加、削除、切り替え、または単独切り替えを行います。')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    action: EnumProperty(
        name=TI('Quick Multi-Edit Action', 'クイック複数編集アクション'),
        description=TI('Internal action used by the wrapper button: add, remove, switch, or toggle the clicked object in the multi-edit set.', 'ラッパーボタンが使用する内部アクションです。クリックしたオブジェクトをマルチ編集セットへ追加、削除、単独切り替え、または切替します。'),
        items=[
            ('ADD', TI('Add', '加算'), TI('Add object to multi-edit', 'オブジェクトをマルチ編集に追加')),
            ('REMOVE', TI('Remove', '削除'), TI('Remove object from multi-edit', 'オブジェクトをマルチ編集から削除')),
            ('ISOLATE', TI('Switch', '単独切り替え'), TI('Switch the multi-edit set to the clicked object only', 'マルチ編集セットをクリックしたオブジェクトだけに切り替え')),
            ('TOGGLE', TI('Toggle', '切り替え'), TI('Toggle object in multi-edit', 'マルチ編集内のオブジェクトを追加または削除します')),
        ],
        default='ADD',
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (
            obj is not None
            and str(context.mode).startswith('EDIT')
            and obj.type in SUPPORTED_TYPES
            and context.area is not None
            and context.area.type == "VIEW_3D"
        )

    def invoke(self, context, event):
        return _invoke_click_action(context, event, getattr(self, 'action', 'ADD'), report_fn=self.report, allow_modifier_fallback=True)

# ---------- Batch selection (Box / Lasso) ----------

def _rect_norm(x1, y1, x2, y2):
    xmin = min(x1, x2)
    xmax = max(x1, x2)
    ymin = min(y1, y2)
    ymax = max(y1, y2)
    return xmin, ymin, xmax, ymax

def _point_in_poly(pt, poly):
    x, y = pt
    inside = False
    n = len(poly)
    if n < 3:
        return False
    x0, y0 = poly[0]
    for i in range(1, n + 1):
        x1, y1 = poly[i % n]
        if ((y0 > y) != (y1 > y)) and (x < (x1 - x0) * (y - y0) / (y1 - y0 + 1e-12) + x0):
            inside = not inside
        x0, y0 = x1, y1
    return inside

def _objects_in_rect(context, xmin, ymin, xmax, ymax, clicked_obj_for_filters=None):
    region = context.region
    rv3d = context.region_data
    active_obj = context.active_object
    prefs = _get_prefs(context)

    result = []
    # Limit candidates for speed: only view layer objects
    for obj in context.view_layer.objects:
        if obj is None or obj.type not in SUPPORTED_TYPES:
            continue
        if prefs and prefs.restrict_same_type and active_obj and obj.type != active_obj.type:
            continue
        if prefs and prefs.respect_visibility_select_lock and not _obj_visible_selectable(context, obj):
            continue
        # Filters relying on "clicked object"
        if clicked_obj_for_filters is not None:
            if not _eligible_object(context, obj, active_obj, clicked_obj=clicked_obj_for_filters):
                continue

        # Project bounding box corners
        bb = getattr(obj, "bound_box", None)
        if not bb:
            continue
        hit = False
        try:
            mw = obj.matrix_world
            for c in bb:
                co = mw @ Vector(c)
                s = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
                if s is None:
                    continue
                sx, sy = float(s.x), float(s.y)
                if xmin <= sx <= xmax and ymin <= sy <= ymax:
                    hit = True
                    break
        except Exception:
            continue

        if hit:
            result.append(obj)

    return result

def _objects_in_lasso(context, poly, clicked_obj_for_filters=None):
    region = context.region
    rv3d = context.region_data
    active_obj = context.active_object
    prefs = _get_prefs(context)

    result = []
    for obj in context.view_layer.objects:
        if obj is None or obj.type not in SUPPORTED_TYPES:
            continue
        if prefs and prefs.restrict_same_type and active_obj and obj.type != active_obj.type:
            continue
        if prefs and prefs.respect_visibility_select_lock and not _obj_visible_selectable(context, obj):
            continue
        if clicked_obj_for_filters is not None:
            if not _eligible_object(context, obj, active_obj, clicked_obj=clicked_obj_for_filters):
                continue

        bb = getattr(obj, "bound_box", None)
        if not bb:
            continue
        hit = False
        try:
            mw = obj.matrix_world
            for c in bb:
                co = mw @ Vector(c)
                s = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
                if s is None:
                    continue
                if _point_in_poly((float(s.x), float(s.y)), poly):
                    hit = True
                    break
        except Exception:
            continue

        if hit:
            result.append(obj)

    return result


def _qme_resolve_wrapper_action(operator, valid_actions: set[str], fallback: str) -> str:
    action = None
    try:
        if operator.is_property_set("action"):
            action = str(getattr(operator, 'action', '') or '')
    except Exception:
        action = None
    if action not in valid_actions:
        action = str(getattr(operator, 'qme_action', '') or fallback)
    if action not in valid_actions:
        action = fallback
    return action


class _QME_WrapperBase(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    qme_action = 'ADD'

    action: EnumProperty(
        name=TI('Quick Multi-Edit Action', 'クイック複数編集アクション'),
        description=TI('Internal action used by the wrapper button: add, remove, switch, or toggle the clicked object in the multi-edit set.', 'ラッパーボタンが使用する内部アクションです。クリックしたオブジェクトをマルチ編集セットへ追加、削除、単独切り替え、または切替します。'),
        items=[
            ('ADD', TI('Add', '加算'), TI('Add object to multi-edit', 'オブジェクトをマルチ編集に追加')),
            ('REMOVE', TI('Remove', '削除'), TI('Remove object from multi-edit', 'オブジェクトをマルチ編集から削除')),
            ('ISOLATE', TI('Switch', '単独切り替え'), TI('Switch the multi-edit set to the clicked object only', 'マルチ編集セットをクリックしたオブジェクトだけに切り替え')),
            ('TOGGLE', TI('Toggle', '切り替え'), TI('Toggle object in multi-edit', 'マルチ編集内のオブジェクトを追加または削除します')),
        ],
        default='ADD',
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        return VIEW3D_OT_quick_multi_edit.poll(context)

    def invoke(self, context, event):
        action = _qme_resolve_wrapper_action(self, {'ADD', 'REMOVE', 'ISOLATE', 'TOGGLE'}, 'ADD')
        if _is_region_valid(context):
            return _invoke_click_action(context, event, action, report_fn=self.report, allow_modifier_fallback=False)
        # Pressed in the panel: the next click in the 3D View picks the object.
        self._pick_action = action
        _qme_begin_view_wait(context, TI(
            f'{_qme_action_label(action)}: click an object in the 3D View (Esc or right-click to cancel)',
            f'{_qme_action_label(action)}：3D ビューで物をクリックします（Esc・右クリックで取り消し）',
        ))
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type in _QME_VIEW_NAVIGATION_EVENTS:
            return {'PASS_THROUGH'}
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            _qme_end_view_wait(context)
            return {'CANCELLED'}
        if event.type != 'LEFTMOUSE' or event.value != 'PRESS':
            return {'RUNNING_MODAL'}
        if _qme_refuse_view_strip_press(context, event, self.report):
            return {'RUNNING_MODAL'}

        _qme_end_view_wait(context)
        hit = _qme_view_region_under_mouse(context, event)
        if hit is None:
            return {'CANCELLED', 'PASS_THROUGH'}
        area, region = hit
        click = SimpleNamespace(
            mouse_region_x=event.mouse_x - region.x,
            mouse_region_y=event.mouse_y - region.y,
            alt=False, ctrl=False, shift=False,
        )
        with context.temp_override(area=area, region=region):
            result = _invoke_click_action(context, click, self._pick_action, report_fn=self.report, allow_modifier_fallback=False)
        if 'PASS_THROUGH' in result:
            self.report({'INFO'}, TI('No eligible object at the clicked position.', 'クリックした所に対象の物がありません。'))
            return {'CANCELLED'}
        return result


class VIEW3D_OT_quick_multi_edit_add(_QME_WrapperBase):
    bl_idname = _QME_ADD_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Add', 'クイック複数編集 加算')
    bl_description = TI('Add the clicked object to the current multi-edit set while staying in Edit Mode', '編集モードを維持したまま、クリックしたオブジェクトを現在のマルチ編集セットに追加します。')
    qme_action = 'ADD'


class VIEW3D_OT_quick_multi_edit_remove(_QME_WrapperBase):
    bl_idname = _QME_REMOVE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Remove', 'クイック複数編集 減算')
    bl_description = TI('Remove the clicked object from the current multi-edit set while staying in Edit Mode', '編集モードを維持したまま、クリックしたオブジェクトを現在のマルチ編集セットから削除します。')
    qme_action = 'REMOVE'


class VIEW3D_OT_quick_multi_edit_toggle(_QME_WrapperBase):
    bl_idname = _QME_TOGGLE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Toggle', 'クイック複数編集 切替')
    bl_description = TI('Toggle the clicked object inside the current multi-edit set while staying in Edit Mode', '編集モードを維持したまま、クリックしたオブジェクトを現在のマルチ編集セット内で追加または削除します。')
    qme_action = 'TOGGLE'


class VIEW3D_OT_quick_multi_edit_isolate(_QME_WrapperBase):
    bl_idname = _QME_ISOLATE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Switch', 'クイック複数編集 単独')
    bl_description = TI('Clear the current multi-edit set and switch Edit Mode to only the clicked object', '現在のマルチ編集セットを解除し、編集モードをクリックしたオブジェクトだけに切り替えます。')
    qme_action = 'ISOLATE'


class VIEW3D_OT_quick_multi_edit_box(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_box"
    bl_label = "Quick Multi-Edit (Box)"
    bl_description = "Use a box selection to add or remove many objects from the current multi-edit set at once"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    action: EnumProperty(
        items=[
            ('ADD', "Add", "Batch add/remove/toggle objects using box selection"),
            ('REMOVE', "Remove", "Batch add/remove/toggle objects using box selection"),
            ('TOGGLE', "Toggle", "Batch add/remove/toggle objects using box selection"),
        ],
        description=TI('Action to perform', '実行するアクション'),
        default='ADD',
    )

    _start = None
    _end = None
    _handle = None
    _area = None
    _region = None
    _waiting = False
    _gesture_button = None

    @classmethod
    def poll(cls, context):
        return _qme_view_operator_poll(context)

    def _begin_gesture(self, context, event, area, region):
        self._gesture_button = event.type if event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} else None
        self._area = area
        self._region = region
        self._start = (event.mouse_x - region.x, event.mouse_y - region.y)
        self._end = self._start
        self._handle = bpy.types.SpaceView3D.draw_handler_add(self._draw, (context,), 'WINDOW', 'POST_PIXEL')

    def invoke(self, context, event):
        if _is_region_valid(context):
            self._begin_gesture(context, event, context.area, context.region)
        else:
            # Pressed in the panel: the gesture starts with the next drag in the 3D View.
            self._waiting = True
            _qme_begin_view_wait(context, TI(
                f'{_qme_box_label(self.action)}: drag in the 3D View (Esc or right-click to cancel)',
                f'{_qme_box_label(self.action)}：3D ビューをドラッグして囲みます（Esc・右クリックで取り消し）',
            ))
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if self._waiting:
            if event.type in _QME_VIEW_NAVIGATION_EVENTS:
                return {'PASS_THROUGH'}
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                self._waiting = False
                _qme_end_view_wait(context)
                return {'CANCELLED'}
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                if _qme_refuse_view_strip_press(context, event, self.report):
                    return {'RUNNING_MODAL'}
                self._waiting = False
                _qme_end_view_wait(context)
                hit = _qme_view_region_under_mouse(context, event)
                if hit is None:
                    return {'CANCELLED', 'PASS_THROUGH'}
                self._begin_gesture(context, event, hit[0], hit[1])
            return {'RUNNING_MODAL'}

        if event.type == 'ESC' or (event.type == 'RIGHTMOUSE' and event.value == 'PRESS' and self._gesture_button != 'RIGHTMOUSE'):
            self._finish()
            return {'CANCELLED'}

        if event.type == 'MOUSEMOVE':
            self._end = (event.mouse_x - self._region.x, event.mouse_y - self._region.y)
            self._area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} and event.value == 'RELEASE':
            x1, y1 = self._start
            x2, y2 = self._end
            xmin, ymin, xmax, ymax = _rect_norm(x1, y1, x2, y2)

            # Use active as "clicked" reference for filters
            clicked_ref = context.active_object
            with context.temp_override(area=self._area, region=self._region):
                objs = _objects_in_rect(context, xmin, ymin, xmax, ymax, clicked_obj_for_filters=clicked_ref)
            self._finish()

            if not objs:
                self.report({'INFO'}, TI('No objects in selection.', '選択範囲内に対象オブジェクトがありません。'))
                return {'CANCELLED'}

            # Apply action to all picked objects (one history entry)
            active = context.active_object
            current = _current_multi_edit_objects(context)

            current_set = set(current)
            if self.action == 'ADD':
                new_set = list(current_set | set(objs))
            elif self.action == 'REMOVE':
                new_set = list(current_set - set(objs))
                if not new_set:
                    self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                    return {'CANCELLED'}
            else:  # TOGGLE
                new_set = set(current_set)
                for o in objs:
                    if o in new_set:
                        new_set.remove(o)
                    else:
                        new_set.add(o)
                new_set = list(new_set)
                if not new_set:
                    self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                    return {'CANCELLED'}

            _push_history(context, getattr(active, "name", ""), [o.name for o in current])

            prefs = _get_prefs(context)
            new_active = active
            if prefs and prefs.active_behavior == 'MOVE' and objs:
                new_active = objs[-1]
            if new_active not in new_set:
                new_active = new_set[0]

            ok = _set_selection_set(context, new_set, new_active, report_fn=self.report)
            if ok:
                msg = f"{_qme_box_label(self.action)}: {len(objs)}"
                _show_hud_message(context, msg)
            return {'FINISHED'} if ok else {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _finish(self):
        if self._handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            except Exception:
                pass
            self._handle = None
        try:
            self._area.tag_redraw()
        except Exception:
            pass

    def _draw(self, context):
        # Lightweight rectangle (no colors specified)
        import gpu
        from gpu_extras.batch import batch_for_shader

        if not self._start or not self._end:
            return
        x1, y1 = self._start
        x2, y2 = self._end
        xmin, ymin, xmax, ymax = _rect_norm(x1, y1, x2, y2)
        verts = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax), (xmin, ymin)]

        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": verts})

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", (1.0, 1.0, 1.0, 0.8))
        batch.draw(shader)
        gpu.state.blend_set('NONE')

class VIEW3D_OT_quick_multi_edit_lasso(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_lasso"
    bl_label = "Quick Multi-Edit (Lasso)"
    bl_description = "Use a lasso selection to add or remove many objects from the current multi-edit set in one gesture"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    action: EnumProperty(
        items=[
            ('ADD', "Add", "Batch add/remove/toggle objects using lasso selection"),
            ('REMOVE', "Remove", "Batch add/remove/toggle objects using lasso selection"),
            ('TOGGLE', "Toggle", "Batch add/remove/toggle objects using lasso selection"),
        ],
        description=TI('Action to perform', '実行するアクション'),
        default='ADD',
    )

    _poly = None
    _handle = None
    _area = None
    _region = None
    _waiting = False
    _gesture_button = None

    @classmethod
    def poll(cls, context):
        return _qme_view_operator_poll(context)

    def _begin_gesture(self, context, event, area, region):
        self._gesture_button = event.type if event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} else None
        self._area = area
        self._region = region
        self._poly = [(event.mouse_x - region.x, event.mouse_y - region.y)]
        self._handle = bpy.types.SpaceView3D.draw_handler_add(self._draw, (context,), 'WINDOW', 'POST_PIXEL')

    def invoke(self, context, event):
        if _is_region_valid(context):
            self._begin_gesture(context, event, context.area, context.region)
        else:
            # Pressed in the panel: the gesture starts with the next drag in the 3D View.
            self._waiting = True
            _qme_begin_view_wait(context, TI(
                f'{_qme_lasso_label(self.action)}: drag in the 3D View (Esc or right-click to cancel)',
                f'{_qme_lasso_label(self.action)}：3D ビューをドラッグして囲みます（Esc・右クリックで取り消し）',
            ))
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if self._waiting:
            if event.type in _QME_VIEW_NAVIGATION_EVENTS:
                return {'PASS_THROUGH'}
            if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
                self._waiting = False
                _qme_end_view_wait(context)
                return {'CANCELLED'}
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                if _qme_refuse_view_strip_press(context, event, self.report):
                    return {'RUNNING_MODAL'}
                self._waiting = False
                _qme_end_view_wait(context)
                hit = _qme_view_region_under_mouse(context, event)
                if hit is None:
                    return {'CANCELLED', 'PASS_THROUGH'}
                self._begin_gesture(context, event, hit[0], hit[1])
            return {'RUNNING_MODAL'}

        if event.type == 'ESC' or (event.type == 'RIGHTMOUSE' and event.value == 'PRESS' and self._gesture_button != 'RIGHTMOUSE'):
            self._finish()
            return {'CANCELLED'}

        if event.type == 'MOUSEMOVE':
            self._poly.append((event.mouse_x - self._region.x, event.mouse_y - self._region.y))
            self._area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE'} and event.value == 'RELEASE':
            poly = [(float(x), float(y)) for x, y in self._poly]
            clicked_ref = context.active_object
            with context.temp_override(area=self._area, region=self._region):
                objs = _objects_in_lasso(context, poly, clicked_obj_for_filters=clicked_ref)
            self._finish()

            if not objs:
                self.report({'INFO'}, TI('No objects in selection.', '選択範囲内に対象オブジェクトがありません。'))
                return {'CANCELLED'}

            active = context.active_object
            current = _current_multi_edit_objects(context)

            current_set = set(current)
            if self.action == 'ADD':
                new_set = list(current_set | set(objs))
            elif self.action == 'REMOVE':
                new_set = list(current_set - set(objs))
                if not new_set:
                    self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                    return {'CANCELLED'}
            else:  # TOGGLE
                new_set = set(current_set)
                for o in objs:
                    if o in new_set:
                        new_set.remove(o)
                    else:
                        new_set.add(o)
                new_set = list(new_set)
                if not new_set:
                    self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                    return {'CANCELLED'}

            _push_history(context, getattr(active, "name", ""), [o.name for o in current])

            prefs = _get_prefs(context)
            new_active = active
            if prefs and prefs.active_behavior == 'MOVE' and objs:
                new_active = objs[-1]
            if new_active not in new_set:
                new_active = new_set[0]

            ok = _set_selection_set(context, new_set, new_active, report_fn=self.report)
            if ok:
                msg = f"{_qme_lasso_label(self.action)}: {len(objs)}"
                _show_hud_message(context, msg)
            return {'FINISHED'} if ok else {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _finish(self):
        if self._handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            except Exception:
                pass
            self._handle = None
        try:
            self._area.tag_redraw()
        except Exception:
            pass

    def _draw(self, context):
        import gpu
        from gpu_extras.batch import batch_for_shader

        if not self._poly or len(self._poly) < 2:
            return
        verts = [(float(x), float(y)) for x, y in self._poly]

        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": verts})

        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", (1.0, 1.0, 1.0, 0.8))
        batch.draw(shader)
        gpu.state.blend_set('NONE')

# ---------- History restore ----------
class VIEW3D_OT_quick_multi_edit_restore_previous(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_restore_previous"
    bl_label = "Restore Previous Multi-Edit Set"
    bl_description = "Restore the multi-edit object set that was active before the most recent Quick Multi-Edit change"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and str(context.mode).startswith('EDIT') and obj.type in SUPPORTED_TYPES

    def execute(self, context):
        entry = _pop_history(context)
        if not entry:
            self.report({'INFO'}, TI('No history.', '履歴がありません。'))
            return {'CANCELLED'}

        if entry.get("scene", "") and entry["scene"] != getattr(context.scene, "name", ""):
            # Different scene; still try by name
            pass

        sel_names = entry.get("selected", [])
        active_name = entry.get("active", "")

        objs = []
        for n in sel_names:
            o = context.scene.objects.get(n)
            if o:
                objs.append(o)
        if not objs:
            self.report({'INFO'}, TI('History objects not found.', '履歴内のオブジェクトが見つかりません。'))
            return {'CANCELLED'}

        active = context.scene.objects.get(active_name) if active_name else None
        if active not in objs:
            active = objs[0]

        ok = _set_selection_set(context, objs, active, report_fn=self.report)
        if ok:
            _show_hud_message(context, TI('Restored previous edit set', '前回の編集セットを復元しました'))
        return {'FINISHED'} if ok else {'CANCELLED'}



def _operator_properties_contain(op, prop_name: str) -> bool:
    return _op_safety.operator_proxy_has_property(op, prop_name)


def _safe_set_operator_property(op, prop_name: str, value, *, operator_id: object | None = None) -> bool:
    if op is None:
        return False
    return _op_safety.safe_set_operator_property(op, prop_name, value, operator_id=operator_id, strict=True)

# ---------- Collection / Outliner integration ----------
def _gather_collection_objects(context, coll):
    if coll is None:
        return []
    active_obj = context.active_object
    clicked_ref = active_obj  # used for optional filters
    objs = []
    for obj in coll.objects:
        if _eligible_object(context, obj, active_obj, clicked_obj=clicked_ref):
            objs.append(obj)
    return objs

class VIEW3D_OT_quick_multi_edit_from_active_collection(bpy.types.Operator):
    bl_idname = "view3d.quick_multi_edit_from_active_collection"
    bl_label = "Quick Multi-Edit: Active Collection"
    bl_description = "Build the multi-edit set from the active object's collection"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    action: EnumProperty(
        name=TI('Collection Action', 'コレクションアクション'),
        description=TI('Choose how objects from the active collection are applied to the current multi-edit set.', 'アクティブコレクション内のオブジェクトを現在のマルチ編集セットへどのように適用するかを選択します。'),
        items=[
            ('SET', "Set", "Set multi-edit set from active collection"),
            ('ADD', "Add", "Add active collection objects to multi-edit"),
            ('REMOVE', "Remove", "Remove active collection objects from multi-edit"),
            ('TOGGLE', "Toggle", "Toggle active collection objects in multi-edit"),
        ],
        default='SET',
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and str(context.mode).startswith('EDIT') and obj.type in SUPPORTED_TYPES

    def execute(self, context):
        lc = getattr(context.view_layer, "active_layer_collection", None)
        coll = getattr(lc, "collection", None) if lc else None
        objs = _gather_collection_objects(context, coll)
        if not objs:
            self.report({'INFO'}, TI('No eligible objects in active collection.', 'アクティブコレクション内に対象オブジェクトがありません。'))
            return {'CANCELLED'}

        active = context.active_object
        current = _current_multi_edit_objects(context)
        current_set = set(current)

        if self.action == 'SET':
            new_set = list(set(objs))
            if not new_set:
                return {'CANCELLED'}
        elif self.action == 'ADD':
            new_set = list(current_set | set(objs))
        elif self.action == 'REMOVE':
            new_set = list(current_set - set(objs))
            if not new_set:
                self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                return {'CANCELLED'}
        else:  # TOGGLE
            new_set = set(current_set)
            for o in objs:
                if o in new_set:
                    new_set.remove(o)
                else:
                    new_set.add(o)
            new_set = list(new_set)
            if not new_set:
                self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                return {'CANCELLED'}

        _push_history(context, getattr(active, "name", ""), [o.name for o in current])

        prefs = _get_prefs(context)
        new_active = active
        if prefs and prefs.active_behavior == 'MOVE' and objs:
            new_active = objs[0]
        if new_active not in new_set:
            new_active = new_set[0]

        ok = _set_selection_set(context, new_set, new_active, report_fn=self.report)
        if ok:
            _show_hud_message(context, f"{_qme_collection_label(self.action)}: {len(objs)}")
        return {'FINISHED'} if ok else {'CANCELLED'}

class OUTLINER_OT_quick_multi_edit_from_collection(bpy.types.Operator):
    bl_idname = "outliner.quick_multi_edit_from_collection"
    bl_label = "Quick Multi-Edit: Collection"
    bl_description = "Set, add, or remove all editable objects from the chosen collection in the multi-edit set"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    collection_name: StringProperty(
        name=TI('Collection Name', 'コレクション名'),
        description=TI('Name of the outliner collection whose editable objects will be applied to the multi-edit set.', 'アウトライナーから選択したコレクション名です。この中の編集可能なオブジェクトをマルチ編集セットへ適用します。'),
        default="",
        options={'HIDDEN'},
    )
    action: EnumProperty(
        name=TI('Collection Action', 'コレクションアクション'),
        description=TI('Choose how objects from the named collection are applied to the current multi-edit set.', '指定したコレクション内のオブジェクトを現在のマルチ編集セットへどのように適用するかを選択します。'),
        items=[
            ('SET', "Set", "Set multi-edit set from this collection"),
            ('ADD', "Add", "Add this collection objects to multi-edit"),
            ('REMOVE', "Remove", "Remove this collection objects from multi-edit"),
            ('TOGGLE', "Toggle", "Toggle this collection objects in multi-edit"),
        ],
        default='SET',
    )

    @classmethod
    def poll(cls, context):
        # Can be called from Outliner, but will operate on the active VIEW_3D context.
        # Require an active object in edit mode.
        obj = getattr(bpy.context, "active_object", None)
        return obj is not None and str(bpy.context.mode).startswith('EDIT') and obj.type in SUPPORTED_TYPES

    def execute(self, context):
        # Use bpy.context (active 3D view context) because Outliner context differs.
        ctx = bpy.context
        coll = ctx.scene.collection
        if self.collection_name:
            c = ctx.scene.collection.children.get(self.collection_name)
            if c:
                coll = c
            else:
                # Search in all collections
                coll = bpy.data.collections.get(self.collection_name, coll)

        objs = _gather_collection_objects(ctx, coll)
        if not objs:
            self.report({'INFO'}, TI('No eligible objects in this collection.', 'このコレクション内に対象オブジェクトがありません。'))
            return {'CANCELLED'}

        active = ctx.active_object
        current = _current_multi_edit_objects(ctx)
        current_set = set(current)

        if self.action == 'SET':
            new_set = list(set(objs))
        elif self.action == 'ADD':
            new_set = list(current_set | set(objs))
        elif self.action == 'REMOVE':
            new_set = list(current_set - set(objs))
            if not new_set:
                self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                return {'CANCELLED'}
        else:
            new_set = set(current_set)
            for o in objs:
                if o in new_set:
                    new_set.remove(o)
                else:
                    new_set.add(o)
            new_set = list(new_set)
            if not new_set:
                self.report({'INFO'}, TI('Cannot remove the last object from edit mode.', '編集モードの最後のオブジェクトは削除できません。'))
                return {'CANCELLED'}

        _push_history(ctx, getattr(active, "name", ""), [o.name for o in current])

        prefs = _get_prefs(ctx)
        new_active = active
        if prefs and prefs.active_behavior == 'MOVE' and objs:
            new_active = objs[0]
        if new_active not in new_set:
            new_active = new_set[0]

        ok = _set_selection_set(ctx, new_set, new_active, report_fn=self.report)
        if ok:
            _show_hud_message(ctx, f"{TI('Outliner ', 'アウトライナー')}{_qme_collection_label(self.action)}: {len(objs)}")
        return {'FINISHED'} if ok else {'CANCELLED'}

class _QME_BoxWrapperBase(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    qme_action = 'ADD'

    action: EnumProperty(
        name=TI('Box Selection Action', 'ボックス選択アクション'),
        description=TI('Internal action used by Quick Multi-Edit box wrapper buttons for batch add, remove, or toggle.', 'クイック複数編集 のボックス選択ラッパーボタンが使用する内部アクションです。一括追加、削除、切り替えを行います。'),
        items=[
            ('ADD', TI('Add', '加算'), TI('Batch add objects using box selection', 'ボックス選択でオブジェクトを一括追加します')),
            ('REMOVE', TI('Remove', '削除'), TI('Batch remove objects using box selection', 'ボックス選択でオブジェクトを一括削除します')),
            ('TOGGLE', TI('Toggle', '切り替え'), TI('Batch toggle objects using box selection', 'ボックス選択でオブジェクトを一括で追加または削除します')),
        ],
        default='ADD',
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        return VIEW3D_OT_quick_multi_edit_box.poll(context)

    def invoke(self, context, event):
        action = _qme_resolve_wrapper_action(self, {'ADD', 'REMOVE', 'TOGGLE'}, 'ADD')
        result = bpy.ops.view3d.quick_multi_edit_box('INVOKE_DEFAULT', action=action)
        return {'CANCELLED'} if 'RUNNING_MODAL' in result else result


class VIEW3D_OT_quick_multi_edit_box_add(_QME_BoxWrapperBase):
    bl_idname = _QME_BOX_ADD_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Box Add', 'クイック複数編集 箱で加算')
    bl_description = TI('Use a box gesture to add many objects to the current multi-edit set at once', 'ボックス選択ジェスチャーで、複数オブジェクトを現在のマルチ編集セットへ一括追加します。')
    qme_action = 'ADD'


class VIEW3D_OT_quick_multi_edit_box_remove(_QME_BoxWrapperBase):
    bl_idname = _QME_BOX_REMOVE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Box Remove', 'クイック複数編集 箱で減算')
    bl_description = TI('Use a box gesture to remove many objects from the current multi-edit set at once', 'ボックス選択ジェスチャーで、複数オブジェクトを現在のマルチ編集セットから一括削除します。')
    qme_action = 'REMOVE'


class VIEW3D_OT_quick_multi_edit_box_toggle(_QME_BoxWrapperBase):
    bl_idname = _QME_BOX_TOGGLE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Box Toggle', 'クイック複数編集 箱で切替')
    bl_description = TI('Use a box gesture to toggle many objects inside the current multi-edit set at once', 'ボックス選択ジェスチャーで、現在のマルチ編集セット内の複数オブジェクトを一括で追加または削除します。')
    qme_action = 'TOGGLE'


class _QME_LassoWrapperBase(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    qme_action = 'ADD'

    action: EnumProperty(
        name=TI('Lasso Selection Action', '投げ縄選択アクション'),
        description=TI('Internal action used by Quick Multi-Edit lasso wrapper buttons for batch add, remove, or toggle.', 'クイック複数編集 の投げ縄選択ラッパーボタンが使用する内部アクションです。一括追加、削除、切り替えを行います。'),
        items=[
            ('ADD', TI('Add', '加算'), TI('Batch add objects using lasso selection', '投げ縄選択でオブジェクトを一括追加します')),
            ('REMOVE', TI('Remove', '削除'), TI('Batch remove objects using lasso selection', '投げ縄選択でオブジェクトを一括削除します')),
            ('TOGGLE', TI('Toggle', '切り替え'), TI('Batch toggle objects using lasso selection', '投げ縄選択でオブジェクトを一括で追加または削除します')),
        ],
        default='ADD',
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        return VIEW3D_OT_quick_multi_edit_lasso.poll(context)

    def invoke(self, context, event):
        action = _qme_resolve_wrapper_action(self, {'ADD', 'REMOVE', 'TOGGLE'}, 'ADD')
        result = bpy.ops.view3d.quick_multi_edit_lasso('INVOKE_DEFAULT', action=action)
        return {'CANCELLED'} if 'RUNNING_MODAL' in result else result


class VIEW3D_OT_quick_multi_edit_lasso_add(_QME_LassoWrapperBase):
    bl_idname = _QME_LASSO_ADD_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Lasso Add', 'クイック複数編集 縄で加算')
    bl_description = TI('Use a lasso gesture to add many objects to the current multi-edit set at once', '投げ縄選択ジェスチャーで、複数オブジェクトを現在のマルチ編集セットへ一括追加します。')
    qme_action = 'ADD'


class VIEW3D_OT_quick_multi_edit_lasso_remove(_QME_LassoWrapperBase):
    bl_idname = _QME_LASSO_REMOVE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Lasso Remove', 'クイック複数編集 縄で減算')
    bl_description = TI('Use a lasso gesture to remove many objects from the current multi-edit set at once', '投げ縄選択ジェスチャーで、複数オブジェクトを現在のマルチ編集セットから一括削除します。')
    qme_action = 'REMOVE'


class VIEW3D_OT_quick_multi_edit_lasso_toggle(_QME_LassoWrapperBase):
    bl_idname = _QME_LASSO_TOGGLE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Lasso Toggle', 'クイック複数編集 縄で切替')
    bl_description = TI('Use a lasso gesture to toggle many objects inside the current multi-edit set at once', '投げ縄選択ジェスチャーで、現在のマルチ編集セット内の複数オブジェクトを一括で追加または削除します。')
    qme_action = 'TOGGLE'


class _QME_CollectionWrapperBase(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    qme_action = 'SET'

    action: EnumProperty(
        name=TI('Active Collection Action', 'アクティブコレクションアクション'),
        description=TI('Internal action used by active-collection wrapper buttons to set, add, remove, or toggle the multi-edit set.', 'アクティブコレクション用ラッパーボタンが使用する内部アクションです。マルチ編集セットを設定、追加、削除、切り替えします。'),
        items=[
            ('SET', TI('Set', '設定'), TI('Set the multi-edit set from the active collection', 'アクティブコレクションからマルチ編集セットを設定します')),
            ('ADD', TI('Add', '加算'), TI('Add the active collection to the multi-edit set', 'アクティブコレクションをマルチ編集セットへ追加します')),
            ('REMOVE', TI('Remove', '削除'), TI('Remove the active collection from the multi-edit set', 'アクティブコレクションをマルチ編集セットから削除します')),
            ('TOGGLE', TI('Toggle', '切り替え'), TI('Toggle the active collection objects in the current multi-edit set', 'アクティブコレクション内オブジェクトを現在のマルチ編集セットへ追加/除外します')),
        ],
        default='SET',
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        return VIEW3D_OT_quick_multi_edit_from_active_collection.poll(context)

    def execute(self, context):
        action = _qme_resolve_wrapper_action(self, {'SET', 'ADD', 'REMOVE', 'TOGGLE'}, 'SET')
        return bpy.ops.view3d.quick_multi_edit_from_active_collection('EXEC_DEFAULT', action=action)


class VIEW3D_OT_quick_multi_edit_collection_set(_QME_CollectionWrapperBase):
    bl_idname = _QME_COLLECTION_SET_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Collection Set', 'クイック複数編集 コレクション設定')
    bl_description = TI('Build the current multi-edit set from the active collection', '現在のマルチ編集セットをアクティブコレクションから構築します。')
    qme_action = 'SET'


class VIEW3D_OT_quick_multi_edit_collection_add(_QME_CollectionWrapperBase):
    bl_idname = _QME_COLLECTION_ADD_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Collection Add', 'クイック複数編集 コレクション追加')
    bl_description = TI('Add the active collection objects to the current multi-edit set', 'アクティブコレクション内のオブジェクトを現在のマルチ編集セットに追加します。')
    qme_action = 'ADD'


class VIEW3D_OT_quick_multi_edit_collection_remove(_QME_CollectionWrapperBase):
    bl_idname = _QME_COLLECTION_REMOVE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Collection Remove', 'クイック複数編集 コレクション削除')
    bl_description = TI('Remove the active collection objects from the current multi-edit set', 'アクティブコレクション内のオブジェクトを現在のマルチ編集セットから削除します。')
    qme_action = 'REMOVE'


class VIEW3D_OT_quick_multi_edit_collection_toggle(_QME_CollectionWrapperBase):
    bl_idname = _QME_COLLECTION_TOGGLE_OPERATOR_ID
    bl_label = TI('Quick Multi-Edit Collection Toggle', 'クイック複数編集 コレクション切替')
    bl_description = TI('Toggle the active collection objects inside the current multi-edit set', 'アクティブコレクション内のオブジェクトを現在のマルチ編集セットへ追加/除外します。')
    qme_action = 'TOGGLE'


def _outliner_get_collection_name(context):
    # Try common Outliner context attributes
    c = getattr(context, "collection", None)
    if c is not None:
        return c.name
    ids = getattr(context, "selected_ids", None)
    if ids:
        for i in ids:
            try:
                if isinstance(i, bpy.types.Collection):
                    return i.name
            except Exception:
                pass
    return ""

class _QME_OutlinerCollectionWrapperBase(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    qme_action = 'SET'

    collection_name: StringProperty(
        name=TI('Collection Name', 'コレクション名'),
        description=TI('Hidden collection name forwarded from the Outliner wrapper button.', 'アウトライナーのラッパーボタンから渡される非表示コレクション名です。'),
        default="",
        options={'HIDDEN'},
    )
    action: EnumProperty(
        name=TI('Outliner Collection Action', 'アウトライナーコレクションアクション'),
        description=TI('Internal action used by Outliner collection wrapper buttons to set, add, or remove collection objects.', 'アウトライナーコレクション用ラッパーボタンが使用する内部アクションです。コレクション内オブジェクトを設定、追加、削除します。'),
        items=[
            ('SET', TI('Set', '設定'), TI('Set the multi-edit set from this collection', 'このコレクションからマルチ編集セットを設定します')),
            ('ADD', TI('Add', '加算'), TI('Add this collection objects to the multi-edit set', 'このコレクション内のオブジェクトをマルチ編集セットへ追加します')),
            ('REMOVE', TI('Remove', '削除'), TI('Remove this collection objects from the multi-edit set', 'このコレクション内のオブジェクトをマルチ編集セットから削除します')),
        ],
        default='SET',
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        return OUTLINER_OT_quick_multi_edit_from_collection.poll(context)

    def execute(self, context):
        action = _qme_resolve_wrapper_action(self, {'SET', 'ADD', 'REMOVE'}, 'SET')
        return bpy.ops.outliner.quick_multi_edit_from_collection(
            'EXEC_DEFAULT',
            collection_name=str(getattr(self, 'collection_name', '') or ''),
            action=action,
        )


class OUTLINER_OT_quick_multi_edit_collection_set(_QME_OutlinerCollectionWrapperBase):
    bl_idname = 'outliner.quick_multi_edit_collection_set'
    bl_label = TI('Outliner Quick Multi-Edit Collection Set', 'アウトライナー クイック複数編集 コレクション設定')
    bl_description = TI('Build the current multi-edit set from this collection', 'このコレクションから現在のマルチ編集セットを構築します。')
    qme_action = 'SET'


class OUTLINER_OT_quick_multi_edit_collection_add(_QME_OutlinerCollectionWrapperBase):
    bl_idname = 'outliner.quick_multi_edit_collection_add'
    bl_label = TI('Outliner Quick Multi-Edit Collection Add', 'アウトライナー クイック複数編集 コレクション追加')
    bl_description = TI('Add this collection objects to the current multi-edit set', 'このコレクション内のオブジェクトを現在のマルチ編集セットに追加します。')
    qme_action = 'ADD'


class OUTLINER_OT_quick_multi_edit_collection_remove(_QME_OutlinerCollectionWrapperBase):
    bl_idname = 'outliner.quick_multi_edit_collection_remove'
    bl_label = TI('Outliner Quick Multi-Edit Collection Remove', 'アウトライナー クイック複数編集 コレクション削除')
    bl_description = TI('Remove this collection objects from the current multi-edit set', 'このコレクション内のオブジェクトを現在のマルチ編集セットから削除します。')
    qme_action = 'REMOVE'


def draw_outliner_collection_menu(self, context):
    name = _outliner_get_collection_name(context)
    layout = self.layout
    layout.separator()
    _draw_icon_label(layout, "Quick Multi-Edit", icon='EDITMODE_HLT')

    op = _operator(layout, OUTLINER_OT_quick_multi_edit_collection_set.bl_idname, text="Set Multi-Edit from Collection", icon='OUTLINER_COLLECTION', custom_icon='collection_set')
    _safe_set_operator_property(op, 'collection_name', name, operator_id=OUTLINER_OT_quick_multi_edit_collection_set.bl_idname)

    op = _operator(layout, OUTLINER_OT_quick_multi_edit_collection_add.bl_idname, text="Add Collection to Multi-Edit", icon='ADD', custom_icon='collection_add')
    _safe_set_operator_property(op, 'collection_name', name, operator_id=OUTLINER_OT_quick_multi_edit_collection_add.bl_idname)

    op = _operator(layout, OUTLINER_OT_quick_multi_edit_collection_remove.bl_idname, text="Remove Collection from Multi-Edit", icon='REMOVE', custom_icon='collection_remove')
    _safe_set_operator_property(op, 'collection_name', name, operator_id=OUTLINER_OT_quick_multi_edit_collection_remove.bl_idname)

def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _cleanup_stale_default_keymaps():
    """Crash-safe no-op; do not traverse or mutate default/user keymaps."""
    return


def _cleanup_legacy_user_action_keymaps():
    """Crash-safe no-op for legacy Quick Multi-Edit keymaps."""
    return

def _qme_binding_spec_from_prefs(prefs, prefix: str, operator_id: str) -> dict:
    return {
        'idname': operator_id,
        'type': str(getattr(prefs, f'custom_{prefix}_type', 'NONE') or 'NONE'),
        'value': str(getattr(prefs, f'custom_{prefix}_value', 'PRESS') or 'PRESS'),
        'shift': bool(getattr(prefs, f'custom_{prefix}_shift', False)),
        'ctrl': bool(getattr(prefs, f'custom_{prefix}_ctrl', False)),
        'alt': bool(getattr(prefs, f'custom_{prefix}_alt', False)),
        'oskey': bool(getattr(prefs, f'custom_{prefix}_oskey', False)),
    }


def _qme_custom_binding_specs(prefs) -> list[dict]:
    return [
        _qme_binding_spec_from_prefs(prefs, 'add', VIEW3D_OT_quick_multi_edit_add.bl_idname),
        _qme_binding_spec_from_prefs(prefs, 'remove', VIEW3D_OT_quick_multi_edit_remove.bl_idname),
        _qme_binding_spec_from_prefs(prefs, 'toggle', VIEW3D_OT_quick_multi_edit_toggle.bl_idname),
        _qme_binding_spec_from_prefs(prefs, 'isolate', VIEW3D_OT_quick_multi_edit_isolate.bl_idname),
    ]


def _register_qme_keymap_item(km, spec: dict):
    """Crash-safe no-op for Quick Multi-Edit keymap item creation."""
    del km, spec
    return None


_QME_KEYMAP_CONTEXTS = (
    ('3D View', 'VIEW_3D'),
    ('Mesh', 'EMPTY'),
    ('Curve', 'EMPTY'),
    ('Armature', 'EMPTY'),
    ('Metaball', 'EMPTY'),
    ('Font', 'EMPTY'),
)


def _qme_default_binding_specs(context) -> list[dict]:
    button = _mouse_button_pref(context)
    return [
        {'idname': VIEW3D_OT_quick_multi_edit_add.bl_idname, 'type': button, 'value': 'PRESS', 'shift': True, 'ctrl': False, 'alt': False, 'oskey': False},
        {'idname': VIEW3D_OT_quick_multi_edit_remove.bl_idname, 'type': button, 'value': 'PRESS', 'shift': False, 'ctrl': True, 'alt': False, 'oskey': False},
        {'idname': VIEW3D_OT_quick_multi_edit_isolate.bl_idname, 'type': button, 'value': 'PRESS', 'shift': False, 'ctrl': False, 'alt': True, 'oskey': False},
    ]


def _qme_active_binding_specs(context, prefs=None) -> list[dict]:
    if prefs is None:
        prefs = _get_prefs(context)
    if not bool(getattr(prefs, 'enable_keymaps', False)):
        return []
    if bool(getattr(prefs, 'use_custom_keymap', False)):
        return [spec for spec in _qme_custom_binding_specs(prefs) if str(spec.get('type', 'NONE') or 'NONE') != 'NONE']
    return _qme_default_binding_specs(context)


def _qme_kmi_matches_spec(kmi, spec: dict) -> bool:
    try:
        if getattr(kmi, 'type', '') != str(spec.get('type', 'NONE') or 'NONE'):
            return False
        if getattr(kmi, 'value', '') != str(spec.get('value', 'PRESS') or 'PRESS'):
            return False
        if bool(getattr(kmi, 'shift', False)) != bool(spec.get('shift', False)):
            return False
        if bool(getattr(kmi, 'ctrl', False)) != bool(spec.get('ctrl', False)):
            return False
        if bool(getattr(kmi, 'alt', False)) != bool(spec.get('alt', False)):
            return False
        if bool(getattr(kmi, 'oskey', False)) != bool(spec.get('oskey', False)):
            return False
        if bool(getattr(kmi, 'any', False)) != bool(spec.get('any', False)):
            return False
        if getattr(kmi, 'key_modifier', 'NONE') != str(spec.get('key_modifier', 'NONE') or 'NONE'):
            return False
    except Exception:
        return False
    return True



def _restore_disabled_qme_conflicts(store_list):
    """Forget tracked conflicts without touching stale KeyMapItem wrappers."""
    try:
        store_list.clear()
    except Exception:
        pass

def _restore_all_qme_conflicts():
    _restore_disabled_qme_conflicts(_QME_DISABLED_ACTIVE_KMIS)
    _restore_disabled_qme_conflicts(_QME_DISABLED_USER_KMIS)
    _restore_disabled_qme_conflicts(_QME_DISABLED_DEFAULT_KMIS)



def _disable_qme_conflicts(context, specs: list[dict]):
    """Crash-safe no-op; do not deactivate native or third-party keymaps."""
    del context, specs
    _restore_all_qme_conflicts()
    return

# -----------------------------------------------------------------------------
# Keymaps
# -----------------------------------------------------------------------------

def register_keymaps():
    """Crash-safe no-op for Quick Multi-Edit keymap registration."""
    try:
        addon_keymaps.clear()
    except Exception:
        pass
    return


def unregister_keymaps():
    """Crash-safe no-op for Quick Multi-Edit keymap removal."""
    try:
        addon_keymaps.clear()
    except Exception:
        pass
    return

def _refresh_outliner_collection_menu():
    try:
        if hasattr(bpy.types, 'OUTLINER_MT_collection'):
            bpy.types.OUTLINER_MT_collection.remove(draw_outliner_collection_menu)
    except Exception:
        pass
    try:
        if hasattr(bpy.types, 'OUTLINER_MT_collection'):
            bpy.types.OUTLINER_MT_collection.append(draw_outliner_collection_menu)
    except Exception:
        pass


def update_keymap_preference(self, context):
    """Crash-safe no-op for Quick Multi-Edit keymap preference updates."""
    del self, context
    try:
        addon_keymaps.clear()
    except Exception:
        pass
    try:
        _refresh_outliner_collection_menu()
    except Exception:
        pass
    return

# -----------------------------------------------------------------------------
# Preferences UI
# -----------------------------------------------------------------------------
class QuickMultiEditPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    use_custom_keymap: BoolProperty(
        name="Use Custom Keymap",
        description="Manual shortcut reference only. The add-on does not create Quick Multi-Edit keymaps automatically; register the operator IDs manually in Blender Preferences > Keymap.",
        default=False,
        update=update_keymap_preference
    )

    default_mouse_button: EnumProperty(
        name="Mouse Button (Manual Reference)",
        description="Choose the mouse button reference to use when manually registering Quick Multi-Edit add, remove, toggle, and switch shortcuts.",
        items=[
            ('AUTO', "Auto (match selection style)", "Follow Blender's selection mouse style when choosing the manual-reference mouse button."),
            ('RIGHTMOUSE', "Right Mouse Button", "Use the right mouse button as the manual Quick Multi-Edit shortcut reference."),
            ('LEFTMOUSE', "Left Mouse Button", "Use the left mouse button as the manual Quick Multi-Edit shortcut reference."),
        ],
        default='AUTO',
        update=update_keymap_preference,
    )

    active_behavior: EnumProperty(
        name="Active Behavior",
        description="Choose how the active edit object is handled after adding or switching objects in the multi-edit set.",
        items=[
            ('MOVE', "Move Active to Clicked", "Make the clicked object the active object after the Quick Multi-Edit action."),
            ('KEEP', "Keep Current Active", "Keep the current active object unchanged while changing the multi-edit set."),
        ],
        default='MOVE',
    )

    shift_action: EnumProperty(
        name="Shift Action",
        description="Choose what the Shift-modified Quick Multi-Edit shortcut does to the clicked object.",
        items=[
            ('ADD', "Add", "Add the clicked object to the current multi-edit set."),
            ('TOGGLE', "Toggle", "Toggle the clicked object in or out of the current multi-edit set."),
        ],
        default='ADD',
    )

    # Filters
    restrict_same_type: BoolProperty(
        name="Restrict to same object type as active",
        description="Limit Quick Multi-Edit clicks to objects with the same Blender object type as the current active object.",
        default=True,
    )
    respect_visibility_select_lock: BoolProperty(
        name="Respect visibility/selection locks",
        description="Skip objects that are hidden, unselectable, or otherwise locked from normal viewport selection.",
        default=True,
    )
    filter_same_collection: BoolProperty(
        name="Only objects in the same collection as the clicked object",
        description="Restrict candidate objects to the collection membership of the clicked object.",
        default=False,
    )
    filter_name_prefix: BoolProperty(
        name="Only objects with the same name prefix as the clicked object",
        description="Restrict candidate objects to matching name prefixes so related mesh parts can be edited together.",
        default=False,
    )
    custom_name_prefix: StringProperty(
        name="Custom name prefix",
        description="Optional prefix used by the name-prefix filter. Leave blank to derive the prefix from the clicked object.",
        default="",
    )

    # Picking
    enable_cycle_pick: BoolProperty(
        name="Enable cycle pick (behind objects)",
        description="When multiple objects overlap under the cursor, allow repeated clicks to cycle through hidden or behind-object candidates.",
        default=True,
    )
    cycle_timeout: FloatProperty(
        name="Cycle timeout (sec)",
        description="Maximum time between repeated clicks for them to count as the same cycle-pick sequence.",
        default=0.5,
        min=0.05,
        max=2.0,
    )
    cycle_pixel_threshold: IntProperty(
        name="Cycle pixel threshold",
        description="Maximum cursor movement in pixels allowed between repeated cycle-pick clicks.",
        default=6,
        min=0,
        max=50,
    )
    max_cycle_hits: IntProperty(
        name="Max Cycle Hits",
        description="Maximum number of overlapping object candidates stored for cycle picking.",
        default=8,
        min=2,
        max=32,
    )

    # Speed
    fast_path_no_mode_toggle: BoolProperty(
        name=TI("Fast Path Without Mode Toggle", "モード切替なし高速経路"),
        default=True,
        description=TI("Try to apply selection changes without leaving Edit Mode when possible.", "可能な場合は編集モードを抜けずに選択変更を適用します。"),
    )

    # Feedback
    show_status_report: BoolProperty(
        name=TI("Show Status Report", "ステータス通知を表示"),
        default=True,
        description=TI("Show short messages in the status bar.", "ステータスバーに短い通知を表示します。"),
    )
    show_hud: BoolProperty(
        name="Show HUD message in viewport",
        description="Show a short viewport HUD message after Quick Multi-Edit actions.",
        default=False,
    )
    hud_duration: FloatProperty(
        name="HUD duration (sec)",
        description="How long the Quick Multi-Edit viewport HUD message remains visible.",
        default=1.2,
        min=0.1,
        max=10.0,
    )

    # History
    history_depth: IntProperty(
        name="History depth",
        description="Number of previous multi-edit sets kept so Restore Previous can recover recent selections.",
        default=10,
        min=0,
        max=200,
    )

    # Custom keymap helper IDs
    copy_id_main: StringProperty(
        name="Operator ID",
        description="Copy this Operator ID to register a custom shortcut.",
        default=VIEW3D_OT_quick_multi_edit.bl_idname
    )
    copy_id_box: StringProperty(
        name="Operator ID",
        description="Copy this Operator ID to register a custom shortcut.",
        default=VIEW3D_OT_quick_multi_edit_box.bl_idname
    )
    copy_id_lasso: StringProperty(
        name="Operator ID",
        description="Copy this Operator ID to register a custom shortcut.",
        default=VIEW3D_OT_quick_multi_edit_lasso.bl_idname
    )
    copy_id_restore: StringProperty(
        name="Operator ID",
        description="Copy this Operator ID to register a custom shortcut.",
        default=VIEW3D_OT_quick_multi_edit_restore_previous.bl_idname
    )

    # Placeholder for future compatibility (not exposed)
    action_isolate_only_clicked: BoolProperty(
        name="Isolate Only Clicked",
        description="Internal compatibility flag retained for older Quick Multi-Edit settings.",
        default=False,
        options={'HIDDEN'},
    )

    def draw(self, context):
        del context
        return None

    def check_conflicts(self, context):
        """Crash-safe no-op; do not inspect Blender keymaps for conflicts."""
        del context
        return []


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------
classes = (
    VIEW3D_OT_quick_multi_edit,
    VIEW3D_OT_quick_multi_edit_add,
    VIEW3D_OT_quick_multi_edit_remove,
    VIEW3D_OT_quick_multi_edit_toggle,
    VIEW3D_OT_quick_multi_edit_isolate,
    VIEW3D_OT_quick_multi_edit_box,
    VIEW3D_OT_quick_multi_edit_box_add,
    VIEW3D_OT_quick_multi_edit_box_remove,
    VIEW3D_OT_quick_multi_edit_box_toggle,
    VIEW3D_OT_quick_multi_edit_lasso,
    VIEW3D_OT_quick_multi_edit_lasso_add,
    VIEW3D_OT_quick_multi_edit_lasso_remove,
    VIEW3D_OT_quick_multi_edit_lasso_toggle,
    VIEW3D_OT_quick_multi_edit_restore_previous,
    VIEW3D_OT_quick_multi_edit_from_active_collection,
    VIEW3D_OT_quick_multi_edit_collection_set,
    VIEW3D_OT_quick_multi_edit_collection_add,
    VIEW3D_OT_quick_multi_edit_collection_remove,
    VIEW3D_OT_quick_multi_edit_collection_toggle,
    OUTLINER_OT_quick_multi_edit_from_collection,
    OUTLINER_OT_quick_multi_edit_collection_set,
    OUTLINER_OT_quick_multi_edit_collection_add,
    OUTLINER_OT_quick_multi_edit_collection_remove,
)

def register():
    try:
        bpy.app.translations.register(__name__, translations_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
            bpy.app.translations.register(__name__, translations_dict)
        except Exception:
            pass

    for cls in classes:
        bpy.utils.register_class(cls)

    # WindowManager history storage
    if not hasattr(bpy.types.WindowManager, _HISTORY_KEY):
        setattr(
            bpy.types.WindowManager,
            _HISTORY_KEY,
            StringProperty(
                name=TI('Quick Multi-Edit History JSON', 'クイック複数編集履歴JSON'),
                description=TI('Hidden WindowManager storage for recent Quick Multi-Edit selection sets so Restore Previous can recover them during the session.', '前の状態へ復元できるように、最近の クイック複数編集 選択セットをセッション中に保持する非表示の保存領域です。'),
                default="[]",
                options={'HIDDEN'},
            ),
        )

    prefs = _get_prefs(bpy.context)
    register_keymaps()

    # HUD handler is started lazily only when the tool actually needs to show a message.

    # Outliner menu
    _refresh_outliner_collection_menu()


def unregister():

    unregister_keymaps()

    _remove_hud_handler()

    try:
        if hasattr(bpy.types, 'OUTLINER_MT_collection'):
            bpy.types.OUTLINER_MT_collection.remove(draw_outliner_collection_menu)
    except Exception:
        pass

    for cls in reversed(classes):
        _safe_unregister_class(cls)

    # Remove WM property if present
    try:
        if hasattr(bpy.types.WindowManager, _HISTORY_KEY):
            delattr(bpy.types.WindowManager, _HISTORY_KEY)
    except Exception:
        pass

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

if __name__ == "__main__":
    register()

# -----------------------------------------------------------------------------
# Toolset integration helpers
# -----------------------------------------------------------------------------
__STS_REGISTERED = False

def ensure_registered(enable: bool = True):
    global __STS_REGISTERED
    if enable and not __STS_REGISTERED:
        try:
            register()
            __STS_REGISTERED = True
        except Exception:
            __STS_REGISTERED = False
            raise
    elif (not enable) and __STS_REGISTERED:
        try:
            unregister()
        finally:
            __STS_REGISTERED = False
