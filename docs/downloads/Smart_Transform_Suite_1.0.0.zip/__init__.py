import bpy
from . import schema,operators,ui,viewport,storage

__version__="1.0.0"
CLASSES=(*operators.CLASSES,ui.SMART_TRANSFORM_PT_core_suite,ui.VIEW3D_PT_select_guard_popover,ui.VIEW3D_PT_sts_transform_popup,viewport.SMARTTRANSFORM_GGT_axes)
registered=[]
menus=[]
_translated=False

def register():
    global _translated
    try:
        schema.register()
        for cls in CLASSES:bpy.utils.register_class(cls);registered.append(cls)
        pairs={(ctx,en):ja for en,ja in ui.JA.items() for ctx in ("*","Operator")}
        bpy.app.translations.register(__package__,{"ja_JP":pairs});_translated=True
        ui.register_icons()
        for cls,fn in ((bpy.types.UI_MT_button_context_menu,ui.numeric_menu),(bpy.types.VIEW3D_HT_header,ui.header),(bpy.types.VIEW3D_MT_object,ui.object_menu),(bpy.types.OUTLINER_MT_collection,ui.collection_menu)):
            cls.append(fn);menus.append((cls,fn))
        viewport.register()
    except Exception:
        unregister()
        raise

def unregister():
    global _translated
    viewport.unregister()
    for cls,fn in reversed(menus):cls.remove(fn)
    menus.clear();ui.unregister_icons()
    if _translated:bpy.app.translations.unregister(__package__);_translated=False
    for cls in reversed(registered):bpy.utils.unregister_class(cls)
    registered.clear();schema.unregister()
