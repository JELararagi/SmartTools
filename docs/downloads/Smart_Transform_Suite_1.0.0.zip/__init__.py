# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

# Add-on bootstrap: Smart Transform
# Format policy: metadata, ownership guard, runtime registration, runtime unregistration.

from __future__ import annotations

# Package aliases for Extension / user_default compatibility.
import sys as _sys


_STS_WARNED_ONCE = set()


def _warn_once(key, detail=''):
    if key not in _STS_WARNED_ONCE:
        _STS_WARNED_ONCE.add(key)
        print('[Smart Transform Suite] %s: %s' % (key, detail))


def _sts_cleanup_nonstandard_package_aliases():
    current_module = _sys.modules.get(__name__)
    allowed_aliases = {
        __name__,
        'smart_transform_suite',
        'Smart_Transform_Suite',
        'bl_ext.user_default.smart_transform_suite',
        'bl_ext.user_default.Smart_Transform_Suite',
    }
    allowed_prefixes = tuple(alias + '.' for alias in allowed_aliases)
    for alias, module in tuple(_sys.modules.items()):
        if alias in allowed_aliases or alias.startswith(allowed_prefixes):
            continue
        alias_key = str(alias or '').replace('-', '_').lower()
        if 'smart_transform' not in alias_key:
            continue
        module_name = str(getattr(module, '__name__', '') or '').lower()
        module_package = str(getattr(module, '__package__', '') or '').lower()
        module_file = str(getattr(module, '__file__', '') or '').replace('\\', '/').lower()
        if (
            module is current_module
            or 'smart_transform_suite' in module_name
            or 'smart_transform_suite' in module_package
            or '/smart_transform_suite/' in module_file
        ):
            _sys.modules.pop(alias, None)


_sts_cleanup_nonstandard_package_aliases()
_sts_current_module = _sys.modules.get(__name__)
_sys.modules.setdefault('smart_transform_suite', _sts_current_module)
_sys.modules.setdefault('Smart_Transform_Suite', _sts_current_module)
_sys.modules.setdefault('bl_ext.user_default.smart_transform_suite', _sts_current_module)
_sys.modules.setdefault('bl_ext.user_default.Smart_Transform_Suite', _sts_current_module)
del _sts_current_module


import importlib as _safe_lazy_importlib
import sys as _safe_sys

import bpy

from . import runtime as _runtime
from . import feature_toggle as _feature_toggle
from . import workspace_cleanup as _workspace_cleanup
from . import settings as _settings
from . import operator_safety as _operator_safety
from . import ui_icons as _ui_icons
from .keymap_safety import restore_native_view3d_selection_routes as _restore_native_view3d_selection_routes


bl_info = {
    "name": 'Smart Transform',
    "author": 'Smart Transform Suite',
    "version": (1, 0, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Smart Transform",
    "description": "Smart Transform displays its tools in the standard 3D View Sidebar N-panel category Smart Transform.",
    "category": 'Smart Transform',
}


# ------------------------------------------------------------------------------
# Duplicate-registration guard
# ------------------------------------------------------------------------------
def _sts_get_owner():
    try:
        return bpy.app.driver_namespace.get("SMART_TRANSFORM_SUITE_OWNER")
    except Exception:
        return None


def _sts_set_owner(owner):
    try:
        bpy.app.driver_namespace["SMART_TRANSFORM_SUITE_OWNER"] = owner
    except Exception:
        pass


def _sts_clear_owner(owner):
    try:
        ns = bpy.app.driver_namespace
        if ns.get("SMART_TRANSFORM_SUITE_OWNER") == owner:
            ns.pop("SMART_TRANSFORM_SUITE_OWNER", None)
    except Exception:
        pass


def _sts_can_register():
    owner = _sts_get_owner()
    if owner and owner != __package__:
        return False
    if not owner:
        _sts_set_owner(__package__)
    return True


def _safe_boot_preflight_cleanup(runtime_module, package_name, module_name, module_file):
    if runtime_module is None:
        return None
    try:
        return runtime_module.preflight_cleanup(package_name, module_name, module_file)
    except TypeError:
        try:
            return runtime_module.preflight_cleanup(package_name, module_name, module_file, force=False)
        except Exception:
            return None
    except Exception:
        return None


# Keep startup crash-safe: do not install global UI callback shields or mutate
# registered Panel.draw_header callbacks.  Stale Smart Transform proxy classes
# are removed by preflight cleanup during register().
try:
    if hasattr(_workspace_cleanup, 'neutralize_legacy_transform_watchdogs'):
        _workspace_cleanup.neutralize_legacy_transform_watchdogs()
except Exception:
    pass
try:
    _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
except Exception:
    pass


def _cleanup_removed_package_modules() -> None:
    """Unload package modules that no longer exist in this build."""
    package_name = str(__package__ or __name__ or '').strip()
    if not package_name:
        return
    active_roots = {
        'runtime',
        'copy_text',
        'feature_toggle',
        'preferences',
        'quick_align',
        'quick_multi_edit',
        'select_guard',
        'core',
        'integration',
        'core_runtime',
        'help',
        'keymap_safety',
        'tooltip_audit',
        'translation',
        'workspace_cleanup',
        'settings',
        'lazy_operators',
        'ui_icons',
        'operator_safety',
        'precision_length_drag',
        'common',
        'storage',
        'language_extra',
        'cursor_lock',
        'normal_aligner',
    }
    prefix = package_name + '.'
    for module_name, module in list(_safe_sys.modules.items()):
        if not str(module_name or '').startswith(prefix):
            continue
        rel_name = str(module_name)[len(prefix):]
        root_name = rel_name.split('.', 1)[0]
        if root_name in active_roots:
            continue
        unregister = getattr(module, 'unregister', None)
        if callable(unregister):
            try:
                unregister()
            except Exception:
                pass
        try:
            if hasattr(_workspace_cleanup, 'neutralize_legacy_transform_watchdogs'):
                _workspace_cleanup.neutralize_legacy_transform_watchdogs()
        except Exception:
            pass
        try:
            _safe_sys.modules.pop(module_name, None)
        except Exception:
            pass


def _ensure_runtime_load_defaults(prefs):
    if prefs is None:
        return False
    try:
        already_seeded = bool(getattr(prefs, 'runtime_load_defaults_seeded_v28', False))
    except Exception:
        already_seeded = False
    if already_seeded:
        return False
    try:
        prefs.runtime_load_defaults_seeded_v28 = True
    except Exception:
        pass
    return False


def _prime_preferences_subgroups(context=None):
    prefs = None
    try:
        prefs = _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        prefs = None

    if prefs is None:
        return None

    for attr_name in (
        'core_panel',
        'quick_align',
        'quick_multi_edit',
        'select_guard',
        'mesh_vertex_tools',
    ):
        try:
            getattr(prefs, attr_name)
        except Exception:
            pass

    try:
        _ensure_runtime_load_defaults(prefs)
    except Exception:
        pass

    # Legacy module-enable switches from older SmartTools/Properties builds are no longer
    # runtime switches.  Keep them true so old saved preferences cannot hide UI or block
    # lazy tool execution; actual always-on work is controlled by the dedicated switches.
    for _legacy_flag in (
        'enable_core_panel',
        'enable_quick_align',
        'enable_quick_multi_edit',
        'enable_select_guard',
    ):
        try:
            if hasattr(prefs, _legacy_flag):
                setattr(prefs, _legacy_flag, True)
        except Exception:
            pass

    return prefs


def _sts_apply_integrated_tools_from_prefs(context=None) -> None:
    try:
        integration.apply_from_prefs(context or getattr(bpy, 'context', None))
    except Exception:
        pass


# This add-on now uses direct VIEW_3D/UI panel registration only.
def _sts_runtime_repair_needed(context=None) -> bool:
    _prime_preferences_subgroups(context)
    return False


def _sts_repair_runtime(context=None) -> None:
    ctx = context or getattr(bpy, 'context', None)
    prefs = _prime_preferences_subgroups(ctx)
    try:
        _restore_native_view3d_selection_routes(ctx)
    except Exception:
        pass
    try:
        from .core import csdt_gizmo as _csdt_gizmo
        if hasattr(_csdt_gizmo, 'sync_runtime_from_prefs'):
            _csdt_gizmo.sync_runtime_from_prefs(ctx)
    except Exception:
        pass
    try:
        from .core import csdt_operators as _csdt_ops
        if hasattr(_csdt_ops, 'sync_runtime_from_prefs'):
            _csdt_ops.sync_runtime_from_prefs(ctx)
        if prefs is not None and hasattr(_csdt_ops, 'apply_csdt_keymap_priority'):
            _csdt_ops.apply_csdt_keymap_priority(ctx, bool(getattr(prefs, 'prefer_csdt_keymap_priority', False)))
        if hasattr(_csdt_ops, 'ensure_csdt_keymap_repair_runtime'):
            _csdt_ops.ensure_csdt_keymap_repair_runtime(ctx)
    except Exception:
        pass


class _SUITE_LazyModuleProxy:
    __slots__ = ('_alias', '_relative_name')

    def __init__(self, alias: str, relative_name: str):
        self._alias = str(alias or '').strip()
        self._relative_name = str(relative_name or '').strip().strip('.')

    def _load(self):
        current = globals().get(self._alias)
        if not isinstance(current, _SUITE_LazyModuleProxy):
            return current
        module = _safe_lazy_importlib.import_module(f"{__package__}.{self._relative_name}")
        globals()[self._alias] = module
        return module

    def __getattr__(self, name):
        return getattr(self._load(), name)

    def __dir__(self):
        try:
            return dir(self._load())
        except Exception:
            return []


def _safe_lazy_module_proxy(alias: str, relative_name: str):
    return _SUITE_LazyModuleProxy(alias, relative_name)


translation = _safe_lazy_module_proxy('translation', 'translation')
copy_text = _safe_lazy_module_proxy('copy_text', 'copy_text')
lazy_operators = _safe_lazy_module_proxy('lazy_operators', 'lazy_operators')
preferences = _safe_lazy_module_proxy('preferences', 'preferences')
core_panel = _safe_lazy_module_proxy('core_panel', 'core')
smart_grs_main = _safe_lazy_module_proxy('smart_grs_main', 'core.grs_main')
csdt_gizmo = _safe_lazy_module_proxy('csdt_gizmo', 'core.csdt_gizmo')
csdt_ops = _safe_lazy_module_proxy('csdt_ops', 'core.csdt_operators')
cycle_custom_select = _safe_lazy_module_proxy('cycle_custom_select', 'core.cycle_custom_select')
integration = _safe_lazy_module_proxy('integration', 'integration')
cursor_lock = _safe_lazy_module_proxy('cursor_lock', 'cursor_lock')
normal_aligner = _safe_lazy_module_proxy('normal_aligner', 'normal_aligner')
help_module = _safe_lazy_module_proxy('help_module', 'help')

# Compatibility for external add-on installers/introspection that look for a
# module-level `classes` iterable.  Actual registration is delegated to the
# submodules below.
classes = ()

modules = [
    copy_text,
    lazy_operators,
    preferences,
    core_panel,
    smart_grs_main,
    csdt_gizmo,
    csdt_ops,
    cycle_custom_select,
    cursor_lock,
    normal_aligner,
    help_module,
]


def register():
    if not _sts_can_register():
        return


    try:
        _safe_boot_preflight_cleanup(_runtime, __package__, __name__, __file__)
    except Exception:
        pass
    try:
        if hasattr(_workspace_cleanup, 'neutralize_legacy_transform_watchdogs'):
            _workspace_cleanup.neutralize_legacy_transform_watchdogs()
        _workspace_cleanup.cleanup(save=False)
        if hasattr(_workspace_cleanup, 'start_persisted_proxy_data_cleanup'):
            _workspace_cleanup.start_persisted_proxy_data_cleanup(bpy.context)
    except Exception:
        pass
    try:
        _restore_native_view3d_selection_routes(bpy.context)
    except Exception:
        pass
    try:
        _cleanup_removed_package_modules()
    except Exception:
        pass

    registered_modules = []
    translations_registered = False
    try:
        try:
            _ui_icons.register()
        except Exception:
            pass
        try:
            _feature_toggle.register_ui()
        except Exception:
            pass
        core_modules = [copy_text, lazy_operators, preferences, core_panel, cursor_lock, normal_aligner, help_module]
        runtime_modules = [smart_grs_main, csdt_gizmo, csdt_ops, cycle_custom_select]

        for mod in core_modules:
            if hasattr(mod, "register"):
                _ft_alias = str(getattr(mod, '_alias', '') or getattr(mod, '__name__', '') or 'core_module').split('.')[-1]
                _ft_label = _ft_alias.replace('_', ' ').title()
                with _feature_toggle.capture_runtime(_ft_alias, _ft_label):
                    mod.register()
                registered_modules.append(mod)

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        bpy.app.translations.register(__name__, translation.build_i18n_dict())
        translations_registered = True

        _prefs = _prime_preferences_subgroups(bpy.context)
        try:
            _settings.load_into_preferences(_prefs, bpy.context)
        except Exception:
            pass
        try:
            _feature_toggle.sync_state_to_preferences(bpy.context)
        except Exception:
            pass

        for mod in runtime_modules:
            if hasattr(mod, "register"):
                _ft_alias = str(getattr(mod, '_alias', '') or getattr(mod, '__name__', '') or 'core_module').split('.')[-1]
                _ft_label = _ft_alias.replace('_', ' ').title()
                try:
                    with _feature_toggle.capture_runtime(_ft_alias, _ft_label):
                        mod.register()
                    registered_modules.append(mod)
                except Exception as _runtime_register_ex:
                    # Optional runtime helpers must never withdraw the N-panel host.
                    # Keep the add-on installed and visible, then report the module
                    # failure in the console for targeted follow-up.
                    try:
                        _warn_once("module registration skipped " + str(_ft_alias), _runtime_register_ex)
                    except Exception:
                        pass
                    continue

        # Operator guards are installed before class registration only.
        # Replacing invoke/modal/execute after registration can leave native
        # Blender callbacks pointing at stale Python functions.

        _sts_apply_integrated_tools_from_prefs(bpy.context)
        try:
            def _sts_deferred_post_register_sync():
                ctx = getattr(bpy, 'context', None)
                try:
                    _settings.apply_saved_scene_values(ctx)
                except Exception:
                    pass
                try:
                    if hasattr(cursor_lock, 'sync_feature_from_prefs'):
                        cursor_lock.sync_feature_from_prefs(ctx, save=False)
                except Exception:
                    pass
                try:
                    _sts_repair_runtime(ctx)
                except Exception:
                    pass
                return None
            timers = getattr(getattr(bpy, 'app', None), 'timers', None)
            if timers is not None:
                timers.register(_sts_deferred_post_register_sync, first_interval=0.20)
            else:
                _sts_deferred_post_register_sync()
        except Exception:
            pass
        try:
            _settings.start(bpy.context)
        except Exception:
            pass
    except Exception:
        try:
            integration.unregister_all()
        except Exception:
            pass
        if translations_registered:
            try:
                bpy.app.translations.unregister(__name__)
            except Exception:
                pass
        for mod in reversed(registered_modules):
            if hasattr(mod, "unregister"):
                try:
                    mod.unregister()
                except Exception:
                    pass
        try:
            _ui_icons.unregister()
        except Exception:
            pass
        _sts_clear_owner(__package__)
        raise


def unregister():
    if _sts_get_owner() not in (None, __package__):
        return
    try:
        try:
            _settings.stop(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            if hasattr(_workspace_cleanup, 'stop_ui_callback_guard'):
                _workspace_cleanup.stop_ui_callback_guard()
            if hasattr(_workspace_cleanup, 'stop_persisted_proxy_data_cleanup'):
                _workspace_cleanup.stop_persisted_proxy_data_cleanup()
        except Exception:
            pass
        try:
            _restore_native_view3d_selection_routes(getattr(bpy, 'context', None))
        except Exception:
            pass

        try:
            _feature_toggle.unregister_all()
        except Exception:
            pass

        try:
            _ui_icons.unregister()
        except Exception:
            pass

        try:
            _workspace_cleanup.uninstall()
        except Exception:
            pass

        try:
            integration.unregister_all()
        except Exception:
            pass

        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass

        try:
            _help_mod = _safe_sys.modules.get(f'{__package__}.help')
            if _help_mod is not None and hasattr(_help_mod, 'unregister'):
                _help_mod.unregister()
        except Exception:
            pass

        for mod in reversed(modules):
            if hasattr(mod, "unregister"):
                mod.unregister()
    finally:
        _sts_clear_owner(__package__)


# SUITE_TOOLTIP_AUDIT_WRAPPER_START
from . import tooltip_audit as _tooltip_audit

try:
    _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER = register
    _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER = unregister
except Exception:
    pass
else:
    def register():
        _tooltip_audit.begin_runtime_audit()
        try:
            result = _SUITE_TOOLTIP_AUDIT_ORIG_REGISTER()
        except Exception:
            _tooltip_audit.abort_runtime_audit()
            raise
        _tooltip_audit.finish_runtime_audit()
        return result

    def unregister():
        try:
            return _SUITE_TOOLTIP_AUDIT_ORIG_UNREGISTER()
        finally:
            _tooltip_audit.clear_runtime_audit()
# SUITE_TOOLTIP_AUDIT_WRAPPER_END


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()

# --- Smart common extension patch START ---
try:
    from . import common as _SMART_COMMON
except Exception:
    _SMART_COMMON = None

_SMART_ORIGINAL_REGISTER = globals().get('register')
_SMART_ORIGINAL_UNREGISTER = globals().get('unregister')
_SMART_SUITE_REGISTERED = False


def register():
    global _SMART_SUITE_REGISTERED
    _sts_cleanup_nonstandard_package_aliases()
    if _SMART_SUITE_REGISTERED:
        return
    if _SMART_COMMON is not None:
        try:
            _SMART_COMMON.begin_register()
        except Exception:
            pass
    try:
        if callable(_SMART_ORIGINAL_REGISTER):
            _SMART_ORIGINAL_REGISTER()
        if _SMART_COMMON is not None:
            _SMART_COMMON.register()
    except Exception:
        _SMART_SUITE_REGISTERED = False
        raise
    finally:
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.end_register()
            except Exception:
                pass
    _SMART_SUITE_REGISTERED = True


def unregister():
    global _SMART_SUITE_REGISTERED
    if not _SMART_SUITE_REGISTERED and _sts_get_owner() != __package__:
        return
    try:
        if _SMART_COMMON is not None:
            try:
                _SMART_COMMON.unregister()
            except Exception:
                pass
        if callable(_SMART_ORIGINAL_UNREGISTER):
            _SMART_ORIGINAL_UNREGISTER()
    finally:
        _SMART_SUITE_REGISTERED = False
# --- Smart common extension patch END ---

# SmartTools shared specification registration boundary.
from .smarttools_spec_guard import wrap as _smarttools_spec_wrap

register, unregister = _smarttools_spec_wrap(register, unregister)
