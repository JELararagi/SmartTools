"""An interactive solver that delegates mesh and object application to Blender."""
import math
import bpy,bmesh,blf,gpu
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from . import transforms,selection

displays={}
last_axis={}
NUMBERS={str(i):str(i) for i in range(10)}
NUMBERS.update({n:str(i) for i,n in enumerate(("ZERO","ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE"))})
NUMBERS.update({"NUMPAD_"+str(i):str(i) for i in range(10)})
NUMBERS.update({"PERIOD":".","NUMPAD_PERIOD":".","MINUS":"-","NUMPAD_MINUS":"-"})

def remove_display(op):
    token=displays.pop(id(op),None)
    if token is not None:bpy.types.SpaceView3D.draw_handler_remove(token,"WINDOW")

def cleanup():
    for token in list(displays.values()):bpy.types.SpaceView3D.draw_handler_remove(token,"WINDOW")
    displays.clear();last_axis.clear()

def save_state(ctx):
    if ctx.mode=="EDIT_MESH":
        return [(obj,[v.co.copy() for v in bmesh.from_edit_mesh(obj.data).verts]) for obj in ctx.objects_in_mode_unique_data]
    return [(obj,obj.matrix_basis.copy()) for obj in ctx.selected_objects]

def restore(state,mode):
    for obj,value in state:
        if mode=="EDIT_MESH":
            bm=bmesh.from_edit_mesh(obj.data)
            for v,co in zip(bm.verts,value):v.co=co
            bmesh.update_edit_mesh(obj.data,loop_triangles=False,destructive=False)
        else:obj.matrix_basis=value
    bpy.context.view_layer.update()

def center(ctx):
    if ctx.scene.tool_settings.transform_pivot_point=="CURSOR":return ctx.scene.cursor.location.copy()
    if ctx.mode=="EDIT_MESH":return transforms.center([o.matrix_world@v.co for o,v in transforms.points(ctx)])
    return transforms.center([obj.matrix_world.translation for obj in ctx.selected_objects])

def draw(op):
    ctx=bpy.context
    if not ctx.area or ctx.area.as_pointer()!=op._area:return
    p=ctx.window_manager.smart_transform_suite_runtime_preferences
    region=ctx.region
    rv=ctx.region_data
    origin=view3d_utils.location_3d_to_region_2d(region,rv,op._pivot)
    if origin is None:return
    shader=gpu.shader.from_builtin("UNIFORM_COLOR")
    def line(positions,color,width):
        if len(positions)<2:return
        batch=batch_for_shader(shader,"LINE_STRIP",{"pos":positions})
        shader.bind()
        if p.overlay_aa_mode=="AA_2PASS":
            gpu.state.line_width_set(max(1,float(width)+2));shader.uniform_float("color",(*color[:3],color[3]*.22));batch.draw(shader)
        gpu.state.line_width_set(max(1,float(width)));shader.uniform_float("color",color);batch.draw(shader)
    old_width=gpu.state.line_width_get();old_blend=gpu.state.blend_get()
    try:
        gpu.state.blend_set("ALPHA" if p.overlay_aa_mode!="AA_OFF" else "NONE")
        for i,on in enumerate(op._axes):
            if not on:continue
            axis=Vector((0.,0.,0.));axis[i]=1
            direction=transforms.basis(ctx)@axis
            here=view3d_utils.location_3d_to_region_2d(region,rv,op._pivot+direction)
            if here is not None and (here-origin).length>.001:
                screen=(here-origin).normalized()*max(region.width,region.height)
                line([origin-screen,origin+screen],tuple(getattr(p,"axis_color_"+"xyz"[i])),p.axis_line_width_active)
        if (ctx.scene.tool_settings.use_proportional_edit if ctx.mode=="EDIT_MESH" else ctx.scene.tool_settings.use_proportional_edit_objects) and p.show_orange_circle:
            edge=op._pivot+rv.view_rotation@Vector((ctx.scene.tool_settings.proportional_size,0,0))
            point=view3d_utils.location_3d_to_region_2d(region,rv,edge)
            if point is not None:
                radius=(point-origin).length
                circle=[origin+Vector((math.cos(i*math.tau/64),math.sin(i*math.tau/64)))*radius for i in range(65)]
                line(circle,tuple(p.circle_color),p.circle_line_width)
    finally:gpu.state.line_width_set(old_width);gpu.state.blend_set(old_blend)
    if not p.hud_enabled:return
    near=origin if "GIZMO" in p.hud_anchor_mode else Vector((30,65))
    x=max(8,min(region.width-180,near.x+p.hud_offset_x));y=max(10,min(region.height-42,near.y+p.hud_offset_y))
    color=tuple(p.hud_text_color)
    blf.size(0,max(8,p.hud_font_size));blf.color(0,*color[:3],color[3] if len(color)>3 else 1)
    axis="".join("XYZ"[i] for i,on in enumerate(op._axes) if on)
    blf.position(0,x,y,0);blf.draw(0,op._mode.title()+"  "+axis+"  "+(op._input or op._display))
    if op._show_help:
        ja=bpy.app.translations.locale.startswith("ja")
        blf.position(0,x,y+24,0);blf.draw(0,"XYZ 軸    Shift+XYZ 平面    Enter 決定    Esc 取消" if ja else "XYZ axis    Shift+XYZ plane    Enter confirm    Esc cancel")

def begin(op,ctx,e,mode):
    region=selection.window_region(ctx)
    if ctx.mode not in {"OBJECT","EDIT_MESH"} or ctx.scene.tool_settings.use_transform_data_origin or ctx.scene.tool_settings.use_transform_skip_children:
        return getattr(bpy.ops.transform,mode)("INVOKE_DEFAULT")
    if ctx.mode=="OBJECT" and not ctx.selected_objects:raise ValueError("Select an object")
    p=ctx.window_manager.smart_transform_suite_runtime_preferences
    op._kind="grs";op._mode=mode;op._scene_mode=ctx.mode
    op._area=ctx.area.as_pointer();op._pivot=center(ctx);op._backup=save_state(ctx)
    op._start=Vector((e.mouse_x-region.x,e.mouse_y-region.y));op._mouse=op._start.copy()
    op._input="";op._display="";op._show_help=p.hud_show_help_by_default
    op._axes=tuple(last_axis.get(mode,(False,)*3)) if p.enable_axis_memory else (False,)*3
    op._orient=ctx.scene.transform_orientation_slots[0].type;op._last_axis=""
    op._radius=ctx.scene.tool_settings.proportional_size
    displays[id(op)]=bpy.types.SpaceView3D.draw_handler_add(draw,(op,),"WINDOW","POST_PIXEL")
    ctx.window_manager.modal_handler_add(op);ctx.area.tag_redraw()
    return {"RUNNING_MODAL"}

def step(op,ctx,e):
    region=selection.window_region(ctx);rv=ctx.space_data.region_3d
    prefs=ctx.window_manager.smart_transform_suite_runtime_preferences
    dx,dy=op._mouse-op._start
    try:number=float(op._input) if op._input not in {"","-",".","-."} else None
    except ValueError:number=None
    mode=op._mode
    k={"translate":"g","rotate":"r","resize":"s"}[mode]
    sensitivity=getattr(prefs,k+("_shift" if e.shift else "_normal"))
    origin=view3d_utils.location_3d_to_region_2d(region,rv,op._pivot) or Vector((region.width*.5,region.height*.5))
    restore(op._backup,op._scene_mode)
    basis=transforms.basis(ctx) if op._orient not in {"GLOBAL","LOCAL"} else (ctx.active_object.matrix_world.to_quaternion() if op._orient=="LOCAL" else None)
    flags=op._axes
    args={"constraint_axis":flags,"orient_type":op._orient}
    settings=ctx.scene.tool_settings
    args.update(use_proportional_edit=settings.use_proportional_edit if ctx.mode=="EDIT_MESH" else settings.use_proportional_edit_objects,
                use_proportional_connected=settings.use_proportional_connected,use_proportional_projected=settings.use_proportional_projected,
                proportional_edit_falloff=settings.proportional_edit_falloff,proportional_size=settings.proportional_size)
    if mode=="translate":
        if number is not None:
            vec=Vector(tuple(number if on else 0 for on in (flags if any(flags) else (True,False,False))))
            if basis:vec=basis@vec
        else:
            project=lambda xy:view3d_utils.region_2d_to_location_3d(region,rv,xy,op._pivot)
            vec=(project(op._mouse)-project(op._start))*sensitivity
            if any(flags):
                local=basis.inverted()@vec if basis else vec.copy()
                for i,f in enumerate(flags):
                    if not f:local[i]=0
                vec=basis@local if basis else local
            if e.ctrl and prefs.snap_move_grid_step>0:
                grid=prefs.snap_move_grid_step;vec=Vector([round(v/grid)*grid for v in vec])
        args["value"]=vec;op._display=f"{vec.length:.3g}"
    elif mode=="rotate":
        if number is not None:angle=math.radians(number)
        elif prefs.smart_gizmo_use_circular_rotation:
            a,b=op._start-origin,op._mouse-origin
            angle=a.angle_signed(b,0.0)*sensitivity if a.length and b.length else 0
        else:angle=(dx+dy)*.01*sensitivity
        if e.ctrl and prefs.snap_rotate_step_deg:
            grid=math.radians(prefs.snap_rotate_step_deg);angle=round(angle/grid)*grid
        if any(flags):args["orient_axis"]="XYZ"[next((i for i,on in enumerate(flags) if on),2)]
        elif number is None:args.update(orient_axis="Z",orient_type="VIEW")
        args["value"]=angle;op._display=f"{math.degrees(angle):.1f}°"
    else:
        scale=number if number is not None else (1+(((op._mouse-origin).length/max(1,(op._start-origin).length))-1)*sensitivity if prefs.smart_gizmo_use_distance_scale else 1+(dx+dy)*.01*sensitivity)
        if prefs.disallow_negative_scale:scale=max(.00001,scale)
        if e.ctrl and prefs.snap_scale_step>0:scale=round(scale/prefs.snap_scale_step)*prefs.snap_scale_step
        args["value"]=tuple(scale if f or not any(flags) else 1 for f in flags);op._display=f"{scale:.3g}"
    from . import islands
    status=islands.apply(ctx,mode,args)
    if "FINISHED" not in status:raise ValueError("Blender could not apply that transform")
    ctx.area.tag_redraw()

def modal(op,ctx,e):
    try:
        if e.type in {"ESC","RIGHTMOUSE"}:
            restore(op._backup,op._scene_mode);ctx.scene.tool_settings.proportional_size=op._radius
            remove_display(op);ctx.area.tag_redraw();return {"CANCELLED"}
        if e.value=="PRESS" and e.type in {"RET","NUMPAD_ENTER","SPACE","LEFTMOUSE"}:
            last_axis[op._mode]=op._axes;remove_display(op);ctx.area.tag_redraw();return {"FINISHED"}
        if e.type=="MOUSEMOVE":
            region=selection.window_region(ctx);op._mouse=Vector((e.mouse_x-region.x,e.mouse_y-region.y))
        elif e.value=="PRESS" and e.type in {"X","Y","Z"}:
            if op._last_axis==e.type:
                op._orient="LOCAL" if op._orient=="GLOBAL" else "GLOBAL"
                if op._orient=="GLOBAL":op._axes=(False,)*3
            else:op._axes=tuple((a==e.type)!=bool(e.shift) for a in "XYZ")
            op._last_axis=e.type
        elif e.value=="PRESS" and e.type=="MIDDLEMOUSE":
            p=ctx.window_manager.smart_transform_suite_runtime_preferences
            if not p.enable_middle_mouse_plane:return {"RUNNING_MODAL"}
            normal=ctx.space_data.region_3d.view_rotation@Vector((0,0,1))
            index=max(range(3),key=lambda i:abs(normal[i]))
            op._axes=tuple(i!=index for i in range(3))
        elif e.value=="PRESS" and e.type in NUMBERS:op._input+=NUMBERS[e.type]
        elif e.value=="PRESS" and e.type=="BACK_SPACE":op._input=op._input[:-1]
        elif e.value=="PRESS" and e.type=="H":op._show_help=not op._show_help;ctx.area.tag_redraw();return {"RUNNING_MODAL"}
        elif e.type in {"WHEELUPMOUSE","WHEELDOWNMOUSE"}:
            ctx.scene.tool_settings.proportional_size*=1.12 if e.type=="WHEELUPMOUSE" else 1/1.12
        else:return {"RUNNING_MODAL"}
        step(op,ctx,e);return {"RUNNING_MODAL"}
    except Exception:
        restore(op._backup,op._scene_mode);remove_display(op);raise
