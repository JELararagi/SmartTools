# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy

from .. import runtime as _runtime
from ..translation import TI

_SELECT_MODE_ORDER = (
    "TWEAK",
    "BOX",
    "CIRCLE",
    "LASSO",
)

_SELECT_MODE_TO_TOOL = {
    "TWEAK": "builtin.select",
    "BOX": "builtin.select_box",
    "CIRCLE": "builtin.select_circle",
    "LASSO": "builtin.select_lasso",
}
_SELECT_TOOL_TO_MODE = {tool_id: mode for mode, tool_id in _SELECT_MODE_TO_TOOL.items()}
_SELECT_TOOLS = tuple(_SELECT_MODE_TO_TOOL.values())
_TRANSFORM_TOOL_IDS = {"builtin.move", "builtin.rotate", "builtin.scale", "builtin.transform"}

_MODE_PREF_FLAGS = {
    "TWEAK": "custom_select_enable_tweak",
    "BOX": "custom_select_enable_box",
    "CIRCLE": "custom_select_enable_circle",
    "LASSO": "custom_select_enable_lasso",
}
_MODE_LABELS = {
    "TWEAK": ("Long Press", "長押し"),
    "BOX": ("Box Select", "ボックス選択"),
    "CIRCLE": ("Circle Select", "サークル選択"),
    "LASSO": ("Lasso Select", "投げ縄選択"),
}


def _safe_active_view3d_tool_id(context) -> str:
    """Return the active 3D View tool id without changing the workspace.

    Blender keeps historical tool entries in the workspace collection.  Reading
    the first VIEW_3D entry can therefore return a stale select-box tool while
    Move / Rotate / Scale / Transform is actually active.  Query the active slot
    first with create=False and only fall back to iteration for old workspaces.
    """
    try:
        area = getattr(context, "area", None)
        if area is not None and getattr(area, "type", None) != 'VIEW_3D':
            return ""
    except Exception:
        pass
    try:
        ws = getattr(context, "workspace", None)
        tools = getattr(ws, "tools", None) if ws is not None else None
        if tools is None:
            return ""
        mode = str(getattr(context, "mode", "OBJECT") or "OBJECT")
        try:
            tool = tools.from_space_view3d_mode(mode, create=False)
            tool_id = str(getattr(tool, "idname", "") or "").strip()
            if tool_id:
                return tool_id
        except Exception:
            pass
        try:
            saw_view3d_mode = False
            for item in tools:
                space_type = str(getattr(item, "space_type", "") or "")
                item_mode = str(getattr(item, "mode", "") or "")
                if space_type != 'VIEW_3D':
                    continue
                if item_mode and item_mode != mode:
                    continue
                saw_view3d_mode = True
                tool_id = str(getattr(item, "idname", "") or "").strip()
                if tool_id:
                    return tool_id
            if saw_view3d_mode:
                return ""
        except Exception:
            pass
    except Exception:
        pass
    return ""


def _tool_set_operator_kwargs(tool_id: str, *, as_fallback: bool = False) -> dict:
    kwargs = {"name": str(tool_id or "").strip()}
    try:
        props = bpy.ops.wm.tool_set_by_id.get_rna_type().properties
        if "space_type" in props:
            kwargs["space_type"] = 'VIEW_3D'
        if as_fallback and "as_fallback" in props:
            kwargs["as_fallback"] = True
    except Exception:
        pass
    return kwargs


def _view3d_window_overrides(context):
    """Yield safe 3D View WINDOW overrides for tool-system operations."""
    try:
        wm = getattr(context, "window_manager", None) or getattr(bpy.context, "window_manager", None)
        windows = tuple(getattr(wm, "windows", ()) or ()) if wm is not None else ()
    except Exception:
        windows = ()
    for win in windows:
        try:
            screen = getattr(win, "screen", None)
            areas = tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ()
        except Exception:
            areas = ()
        for area in areas:
            if getattr(area, "type", None) != 'VIEW_3D':
                continue
            region = None
            try:
                for candidate in area.regions:
                    if getattr(candidate, "type", None) == 'WINDOW':
                        region = candidate
                        break
            except Exception:
                region = None
            if region is None:
                continue
            yield win, area, region


def _sync_select_toolbar_group_mode(context, tool_id: str, *, active_tool_id: str = "") -> bool:
    """Update the toolbar Select tool sub-mode without stealing transform tools.

    Blender stores the currently displayed sub-tool for toolbar groups inside
    ToolSelectPanelHelper._tool_group_active.  When Move / Rotate / Scale /
    Transform is active, changing the active tool would break Smart Gizmo
    workflows, so the Select group is updated through the tool-system fallback
    route instead.  This keeps the transform tool active while the toolbar
    Select group icon/mode follows the add-on custom selection mode.
    """
    tool_id = str(tool_id or "").strip()
    if tool_id not in _SELECT_TOOLS:
        return False
    changed = False

    def _set_group(override_context=None):
        nonlocal changed
        try:
            from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
            cls = ToolSelectPanelHelper._tool_class_from_space_type('VIEW_3D')
            if cls is not None and cls._tool_group_active_set_by_id(override_context or context, "builtin.select", tool_id):
                changed = True
        except Exception:
            pass

    _set_group(context)
    for win, area, region in _view3d_window_overrides(context):
        try:
            with context.temp_override(window=win, area=area, region=region):
                _set_group(bpy.context)
        except Exception:
            continue

    active_tool_id = str(active_tool_id or _safe_active_view3d_tool_id(context) or "").strip()
    if active_tool_id in _TRANSFORM_TOOL_IDS:
        # as_fallback=True is Blender's native way to change the Select tool
        # sub-mode used by active transform tools without switching away from
        # the active transform tool itself.
        kwargs = _tool_set_operator_kwargs(tool_id, as_fallback=True)
        try:
            bpy.ops.wm.tool_set_by_id(**kwargs)
            changed = True
        except Exception:
            pass
        for win, area, region in _view3d_window_overrides(context):
            try:
                with context.temp_override(window=win, area=area, region=region):
                    bpy.ops.wm.tool_set_by_id(**kwargs)
                    changed = True
                    break
            except Exception:
                continue
    return changed


def _safe_set_view3d_tool(context, tool_id: str) -> bool:
    tool_id = str(tool_id or "").strip()
    if tool_id not in _SELECT_TOOLS:
        return False
    kwargs = _tool_set_operator_kwargs(tool_id)
    try:
        bpy.ops.wm.tool_set_by_id(**kwargs)
        return True
    except Exception:
        pass

    # If the operator is invoked from a panel/shortcut context that is not the
    # active WINDOW region, retry with a standard 3D View WINDOW override.
    try:
        wm = getattr(context, "window_manager", None) or getattr(bpy.context, "window_manager", None)
        windows = tuple(getattr(wm, "windows", ()) or ()) if wm is not None else ()
    except Exception:
        windows = ()
    for win in windows:
        try:
            screen = getattr(win, "screen", None)
            areas = tuple(getattr(screen, "areas", ()) or ()) if screen is not None else ()
        except Exception:
            areas = ()
        for area in areas:
            if getattr(area, "type", None) != 'VIEW_3D':
                continue
            region = None
            try:
                for candidate in area.regions:
                    if getattr(candidate, "type", None) == 'WINDOW':
                        region = candidate
                        break
            except Exception:
                region = None
            try:
                with context.temp_override(window=win, area=area, region=region):
                    bpy.ops.wm.tool_set_by_id(**kwargs)
                return True
            except Exception:
                continue
    return False


def _enabled_select_modes(addon_prefs) -> list[str]:
    if addon_prefs is None:
        return list(_SELECT_MODE_ORDER)
    enabled = []
    for mode in _SELECT_MODE_ORDER:
        flag_name = _MODE_PREF_FLAGS.get(mode, '')
        try:
            if bool(getattr(addon_prefs, flag_name, True)):
                enabled.append(mode)
        except Exception:
            enabled.append(mode)
    return enabled


def _mode_from_saved_state(addon_prefs) -> str:
    if addon_prefs is None:
        return "BOX"
    try:
        mode = str(getattr(addon_prefs, 'custom_select_mode', '') or '').strip().upper()
        if mode in _SELECT_MODE_TO_TOOL:
            return mode
    except Exception:
        pass
    try:
        saved_tool = str(getattr(addon_prefs, 'last_select_tool', '') or '').strip()
        mode = _SELECT_TOOL_TO_MODE.get(saved_tool, '')
        if mode:
            return mode
    except Exception:
        pass
    return "BOX"


def _next_enabled_mode(current_mode: str, enabled_modes: list[str]) -> str:
    current_mode = str(current_mode or '').strip().upper()
    if not enabled_modes:
        return ""
    try:
        start = _SELECT_MODE_ORDER.index(current_mode)
    except ValueError:
        start = -1
    for offset in range(1, len(_SELECT_MODE_ORDER) + 1):
        candidate = _SELECT_MODE_ORDER[(start + offset) % len(_SELECT_MODE_ORDER)]
        if candidate in enabled_modes:
            return candidate
    return enabled_modes[0]


def _mode_label(mode: str) -> str:
    en, ja = _MODE_LABELS.get(str(mode or '').upper(), ("Selection", "選択"))
    return TI(en, ja)


# =========================================================
# Cycle Custom Select Operator
# =========================================================
class VIEW3D_OT_cycle_custom_select(bpy.types.Operator):
    """Cycle custom selection modes while preserving active transform tools."""
    bl_idname = "view3d.cycle_custom_select"
    bl_label = TI('Cycle Custom Select', 'カスタム選択切り替え')
    bl_description = TI(
        "Cycle the enabled Long Press, Box Select, Circle Select, and Lasso Select custom selection modes. When Move, Rotate, Scale, or Transform is active, the active transform tool is kept selected while Blender's toolbar Select sub-mode is synchronized.",
        '有効な長押し、ボックス選択、サークル選択、投げ縄選択のカスタム選択モードを巡回します。移動、回転、スケール、Transform がアクティブな場合は、その変形ツールを選択したまま、Blenderツールバー側の選択ツールモードも同期します。',
    )
    bl_options = set()
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        try:
            addon_prefs = _runtime.get_addon_preferences(context, __package__, __name__, __file__)
        except Exception:
            addon_prefs = None

        enabled_modes = _enabled_select_modes(addon_prefs)
        if not enabled_modes:
            self.report({'WARNING'}, TI('Enable at least one custom selection mode.', 'カスタム選択モードを少なくとも1つ有効にしてください。'))
            return {'CANCELLED'}

        active_tool_id = _safe_active_view3d_tool_id(context)
        active_mode = _SELECT_TOOL_TO_MODE.get(active_tool_id, '')
        current_mode = active_mode or _mode_from_saved_state(addon_prefs)
        next_mode = _next_enabled_mode(current_mode, enabled_modes)
        next_tool = _SELECT_MODE_TO_TOOL.get(next_mode, "builtin.select_box")

        if addon_prefs is not None:
            try:
                setattr(addon_prefs, 'custom_select_mode', next_mode)
            except Exception:
                pass
            try:
                setattr(addon_prefs, 'last_select_tool', next_tool)
            except Exception:
                pass

        # Always keep Blender's toolbar Select tool sub-mode in sync with the
        # add-on custom mode.  For active transform tools this uses Blender's
        # fallback-tool path, so Move/Rotate/Scale/Transform stay active.
        _sync_select_toolbar_group_mode(context, next_tool, active_tool_id=active_tool_id)

        # When a transform tool is active, the command changes the add-on custom
        # selection mode and the toolbar Select sub-mode only.  The active
        # transform tool remains Move/Rotate/Scale/Transform.
        if active_tool_id in _TRANSFORM_TOOL_IDS:
            return {'FINISHED'}

        # If the user is actually on a Blender selection tool, also switch the
        # active tool to the matching selection tool.
        if active_tool_id in _SELECT_TOOLS:
            if not _safe_set_view3d_tool(context, next_tool):
                self.report({'WARNING'}, TI('Failed to set selection tool.', '選択ツールの設定に失敗しました。'))
                return {'CANCELLED'}
            _sync_select_toolbar_group_mode(context, next_tool, active_tool_id=next_tool)
            return {'FINISHED'}

        # For other active tools, store/sync the custom mode without forcing a
        # toolbar switch.  This avoids unexpectedly replacing unsupported active tools.
        return {'FINISHED'}


# =========================================================
# Registration
# =========================================================


def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


classes = (
    VIEW3D_OT_cycle_custom_select,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        _safe_unregister_class(cls)
