# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from ..keymap_safety import safe_remove_keymap_item as _sts_safe_remove_keymap_item, restore_native_view3d_selection_routes as _restore_native_view3d_selection_routes
import sys
import json
import math
import time
import bpy.app.timers
import gpu
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent
from mathutils import Vector

from . import csdt_globals as cg
from . import csdt_utils as cu
from . import csdt_gizmo as c_gizmo
from .. import runtime as _runtime
from .. import manager_runtime_bridge as _manager_runtime_bridge
from ..translation import TI


_CSDT_NATIVE_RELEASE_WATCHERS = {}
_CSDT_BACKGROUND_BOX_PREVIEWS = []
_CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE = False
_CSDT_BACKGROUND_BOX_PREVIEW_MAX_AGE = 12.0
_CSDT_DIRECT_SELECT_CLICK_GUARD = {}
_CSDT_DIRECT_SELECT_GUARD_SECONDS = 0.35
_CSDT_DIRECT_SELECT_MODAL_GRACE = 0.08
_CSDT_CROSSING_SELECT_WATCHERS = {}
_CSDT_CROSSING_SELECT_POST_CALLBACKS = set()
_CSDT_CROSSING_SELECT_ENSURE_CALLBACK = None
_CSDT_CROSSING_SELECT_ENSURE_REMAINING = 0
_CSDT_CROSSING_SELECT_ENSURE_WARNED = False
# Monotonic gesture generation.  Every observed gesture start advances it, and
# a pending recorded-operator completion callback whose generation is stale
# retires without touching the selection, so an old gesture can never apply
# with another gesture's preselect snapshot.
_CSDT_CROSSING_GESTURE_GENERATION = 0


def _crossing_next_gesture_generation():
    """Return a fresh token for one public region-select gesture.

    Blender's native box/lasso/circle operators become the top-most modal
    handler as soon as their drag starts.  The passive Smart Transform watcher
    therefore cannot rely on receiving the final mouse release.  A generation
    token lets the bounded post-operator poll retire safely when another
    gesture starts before the previous one finishes.
    """
    global _CSDT_CROSSING_GESTURE_GENERATION
    try:
        _CSDT_CROSSING_GESTURE_GENERATION = int(_CSDT_CROSSING_GESTURE_GENERATION) + 1
    except Exception:
        _CSDT_CROSSING_GESTURE_GENERATION = 1
    return int(_CSDT_CROSSING_GESTURE_GENERATION)

def _runtime_pref_enabled(context=None):
    prefs = cu._prefs(context)
    if not prefs:
        return False
    try:
        # Operator-side runtime checks must follow the explicit live-runtime
        # switch only.  Style / overlay settings are not permission to intercept
        # window events or fallback key routes immediately after installation.
        return bool(getattr(prefs, "enable_smart_gizmo_live_runtime", False))
    except Exception:
        return False


def ensure_constraint_watchdog_running(context=None):
    # Blender 5.1.0 Windows can crash when timer callbacks resolve transient RNA
    # context during edit-mode/operator transitions. Constraint memory is now
    # written only by explicit Smart Transform input paths, so no timer is needed.
    del context
    try:
        if hasattr(cu, '_neutralize_legacy_constraint_watchdogs'):
            cu._neutralize_legacy_constraint_watchdogs()
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(cu._csdt_constraint_watchdog):
            bpy.app.timers.unregister(cu._csdt_constraint_watchdog)
    except Exception:
        pass
    return False


def stop_constraint_watchdog():
    try:
        if bpy.app.timers.is_registered(cu._csdt_constraint_watchdog):
            bpy.app.timers.unregister(cu._csdt_constraint_watchdog)
    except Exception:
        pass


def _ssg_select_through_begin(context, event):
    try:
        from .. import select_guard as _sg
        fn = getattr(_sg, 'begin_external_select_through_xray', None)
        if callable(fn):
            return fn(context, event)
    except Exception:
        pass
    return None


def _ssg_select_through_touch(token=None):
    if not token:
        return
    try:
        from .. import select_guard as _sg
        fn = getattr(_sg, 'touch_external_select_through_xray', None)
        if callable(fn):
            fn(token)
    except Exception:
        pass


def _ssg_select_through_finish(token=None, *, cancelled=False, delay=0.04):
    if not token:
        return
    try:
        from .. import select_guard as _sg
        fn = getattr(_sg, 'finish_external_select_through_xray', None)
        if callable(fn):
            fn(token, cancelled=cancelled, delay=delay)
    except Exception:
        pass


def _ssg_suppress_post_selection_filter(duration=0.45):
    """Skip Smart Select Guard's expensive post-selection occlusion pass.

    Smart Gizmo background box selection already executes Blender's native
    region-select path and then applies the deterministic edge supplement.  The
    follow-up occlusion filter can ray-cast every selected vertex/edge/face and
    was the cause of the long pause after confirming dense selections.
    """
    try:
        from .. import select_guard as _sg
        fn = getattr(_sg, '_suppress_select_guard_occlusion_filter', None)
        if callable(fn):
            fn(float(duration))
    except Exception:
        pass



def _ssg_select_through_apply_box(context, token=None, press_pos=None, release_pos=None, *, shift=False, ctrl=False, alt=False):
    try:
        from .. import select_guard as _sg
        fn = getattr(_sg, 'apply_external_select_through_box', None)
        if callable(fn):
            return bool(fn(context, token, press_pos, release_pos, shift=shift, ctrl=ctrl, alt=alt, min_drag_px=1.0))
    except Exception:
        pass
    return False



def sync_runtime_from_prefs(context=None):
    """Synchronize Smart Transform click handling without Preferences keymaps.

    Blender keymap entries are manual-only. Runtime click handling is provided by
    the Smart Gizmo modal watcher and consumes only the active LEFTMOUSE gesture;
    unsupported events pass back to Blender unchanged.
    """
    ctx = context or getattr(bpy, 'context', None)
    try:
        _add_csdt_load_handlers()
    except Exception:
        pass
    try:
        _stop_csdt_keymap_sync()
    except Exception:
        pass
    try:
        _remove_km_items()
    except Exception:
        pass
    try:
        wm = getattr(ctx, 'window_manager', None) if ctx is not None else getattr(bpy.context, 'window_manager', None)
        if wm is not None:
            _cleanup_stale_addon_csdt_keymaps(wm)
    except Exception:
        pass
    try:
        _cleanup_legacy_user_injected_csdt(ctx)
    except Exception:
        pass
    try:
        from . import csdt_gizmo as c_gizmo
        if hasattr(c_gizmo, 'sync_runtime_from_prefs'):
            c_gizmo.sync_runtime_from_prefs(ctx)
    except Exception:
        pass
    try:
        _sync_crossing_select_runtime(ctx)
    except Exception:
        pass
    return

def _csdt_event_has_selection_modifier(event) -> bool:
    try:
        return bool(
            getattr(event, 'shift', False)
            or getattr(event, 'ctrl', False)
            or getattr(event, 'alt', False)
            or getattr(event, 'oskey', False)
        )
    except Exception:
        return False

def _clear_smart_gizmo_drag_state():
    """Release all Smart Gizmo press/hover ownership on the current event.

    The native Transform modal can consume LEFTMOUSE release before the global
    Smart Gizmo watcher sees it.  The dedicated native-release watcher therefore
    performs the same complete release as the watcher itself, including hover
    throttling state.  This prevents the just-released handle from remaining a
    hit-test candidate during a rapid follow-up click.
    """
    handled = False
    try:
        release_fn = getattr(c_gizmo, '_smart_gizmo_release_interaction_state_immediately', None)
        if callable(release_fn):
            release_fn()
            handled = True
    except Exception:
        handled = False
    if not handled:
        try:
            cg._SMART_GIZMO_LOCKED_ID = None
            cg._CSDT_IS_DRAGGING = False
            cg._CSDT_DRAG_ACTIVE_ID = None
            cg._SMART_GIZMO_HOVER_ID = None
            cg._SMART_GIZMO_MOUSE_VALID = False
            cg._SMART_GIZMO_LAST_HOVER_CHECK_AT = 0.0
            cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
        except Exception:
            pass
    try:
        cu._invalidate_gizmo_cache()
    except Exception:
        pass
    try:
        cu._tag_view3d_redraw()
    except Exception:
        pass


def _gizmo_should_use_native_transform(context) -> bool:
    """Honor Blender native-only top-right Transform options for Smart drags."""
    try:
        return bool(cu._tool_settings_require_native_transform(context))
    except Exception:
        return False


def _remove_background_box_preview_handle(handle):
    if handle is None:
        return False
    try:
        bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        return True
    except Exception:
        return False


def _cleanup_background_box_preview_registry(force=False, exclude=None):
    global _CSDT_BACKGROUND_BOX_PREVIEWS
    now = time.monotonic()
    kept = []
    for entry in list(_CSDT_BACKGROUND_BOX_PREVIEWS):
        try:
            op = entry.get('op')
            handle = entry.get('handle')
            started = float(entry.get('started', 0.0) or 0.0)
        except Exception:
            continue
        stale = force or op is None or handle is None
        if exclude is not None and op is exclude and not force:
            kept.append(entry)
            continue
        if not stale:
            try:
                stale = not bool(getattr(op, '_bg_box_preview', False))
            except Exception:
                stale = True
        if not stale and started > 0.0:
            stale = (now - started) > float(_CSDT_BACKGROUND_BOX_PREVIEW_MAX_AGE)
        if stale:
            _remove_background_box_preview_handle(handle)
            try:
                if op is not None and getattr(op, '_bg_box_draw_handle', None) is handle:
                    op._bg_box_draw_handle = None
                    op._bg_box_preview = False
            except Exception:
                pass
        else:
            kept.append(entry)
    _CSDT_BACKGROUND_BOX_PREVIEWS = kept
    return bool(kept)


def _background_box_preview_cleanup_tick():
    global _CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE
    try:
        alive = _cleanup_background_box_preview_registry(force=False)
        if alive:
            return 1.0
    except Exception:
        pass
    _CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE = False
    return None


def _ensure_background_box_preview_cleanup_timer():
    global _CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE
    if _CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE:
        return
    try:
        bpy.app.timers.register(_background_box_preview_cleanup_tick, first_interval=1.0)
        _CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE = True
    except Exception:
        _CSDT_BACKGROUND_BOX_CLEANUP_TIMER_ACTIVE = False


class VIEW3D_OT_csdt_native_release_watch(bpy.types.Operator):
    bl_idname = "view3d.csdt_native_release_watch"
    bl_label = "Native Release Watch"
    bl_description = "Monitor native left-mouse release so Smart Transform can safely clear drag state after Blender finishes a transform"
    bl_options = {'INTERNAL'}
    bl_undo_group = 'Smart Transform Suite'

    _timer = None
    _win_ptr = 0
    _follow_signature = None

    terminal_pass_through: bpy.props.BoolProperty(
        name="Terminal Pass Through",
        description="Pass the terminal release or cancellation event to the already-running native transform",
        default=False,
        options={'HIDDEN', 'SKIP_SAVE'},
    )

    def invoke(self, context, event):
        win = getattr(context, 'window', None)
        wm = getattr(context, 'window_manager', None)
        if not win or not wm:
            _clear_smart_gizmo_drag_state()
            return {'CANCELLED'}
        try:
            self._win_ptr = int(win.as_pointer())
        except Exception:
            self._win_ptr = id(win)
        old = _CSDT_NATIVE_RELEASE_WATCHERS.get(self._win_ptr)
        if old is not None:
            try:
                old.cancel(context)
            except Exception:
                pass
        self._timer = wm.event_timer_add(0.01, window=win)
        wm.modal_handler_add(self)
        _CSDT_NATIVE_RELEASE_WATCHERS[self._win_ptr] = self
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.cancel(context)
            if self.terminal_pass_through:
                return {'FINISHED', 'PASS_THROUGH'}
            return {'FINISHED'}
        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self.cancel(context)
            if self.terminal_pass_through:
                return {'CANCELLED', 'PASS_THROUGH'}
            return {'CANCELLED'}
        if event.type == 'TIMER' and not bool(getattr(cg, '_CSDT_IS_DRAGGING', False)):
            self.cancel(context)
            if self.terminal_pass_through:
                return {'FINISHED', 'PASS_THROUGH'}
            return {'FINISHED'}
        if event.type == 'TIMER':
            self._follow_armature_selection(context)
        return {'PASS_THROUGH'}

    def _follow_armature_selection(self, context):
        """Keep the Smart Gizmo on the live bone selection during a native drag.

        The native transform started from the Smart Gizmo runs above the gizmo's
        own watcher, so in Armature Edit / Pose mode nothing rebuilt the draw
        snapshot until release: the gizmo stayed at the press position and
        jumped (~80 px) on confirm.  Rebuild only when the selected bone
        geometry changed.  Mesh / Object drags keep their existing path.
        """
        try:
            if str(getattr(context, 'mode', '') or '') not in {'EDIT_ARMATURE', 'POSE'}:
                return
            signature = c_gizmo._smart_armature_target_geometry(context).get('signature', ())
            if signature == getattr(self, '_follow_signature', None):
                return
            self._follow_signature = signature
            if c_gizmo._smart_rebuild_all_draw_snapshots(context):
                cu._tag_view3d_redraw()
        except Exception:
            pass

    def cancel(self, context):
        try:
            wm = getattr(context, 'window_manager', None)
            if wm and self._timer is not None:
                wm.event_timer_remove(self._timer)
        except Exception:
            pass
        self._timer = None
        if self._win_ptr:
            _CSDT_NATIVE_RELEASE_WATCHERS.pop(self._win_ptr, None)
        _clear_smart_gizmo_drag_state()

# =========================================================
# Single Select Operator (No Drag)
# =========================================================
class VIEW3D_OT_csdt_single_select_no_drag(bpy.types.Operator):
    bl_idname = "view3d.csdt_single_select_no_drag"
    bl_label = "Single Select (No Drag)"
    bl_description = "Perform a single exact click selection without starting a drag transform"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    x: bpy.props.IntProperty(
        name=TI('Click X', 'クリックX'),
        description=TI('Window-region X coordinate used for the exact click selection fallback.', '正確なクリック選択フォールバックで使用するウィンドウ領域内のX座標です。'),
        default=0,
        options={'HIDDEN'},
    )
    y: bpy.props.IntProperty(
        name=TI('Click Y', 'クリックY'),
        description=TI('Window-region Y coordinate used for the exact click selection fallback.', '正確なクリック選択フォールバックで使用するウィンドウ領域内のY座標です。'),
        default=0,
        options={'HIDDEN'},
    )
    deselect_all: bpy.props.BoolProperty(
        name=TI('Deselect First', '先に選択解除'),
        description=TI('When enabled, clear the current selection before applying the single-click selection result.', '有効にすると、単一クリック選択の結果を適用する前に現在の選択を解除します。'),
        default=False,
        options={'HIDDEN'},
    )

    def execute(self, context):
        if self.deselect_all:
            cu._csdt_deselect_all_for_single_select(context)
        cu._view3d_select_at(context, self.x, self.y, extend=False, deselect=False, toggle=False, disallow_object_select=True)
        return {'FINISHED'}


def _csdt_window_guard_key(context):
    try:
        win = getattr(context, 'window', None)
        if win is not None:
            return int(win.as_pointer())
    except Exception:
        pass
    return 0


def _remember_direct_selection_click(context, mode, x, y):
    """Remember a deterministic press-select so the later CLICK event is swallowed.

    Blender can emit a LEFTMOUSE CLICK keymap event after a PRESS-owned modal
    operator has already consumed RELEASE.  Native Select/Tweak CLICK entries map
    Shift to toggle and Ctrl to other mesh-select routes, so a second native click
    can undo the Smart Transform ADD/SUB result.  The short guard below is keyed by
    window, modifier-derived mode and click position so only the matching follow-up
    click is consumed.
    """
    try:
        key = _csdt_window_guard_key(context)
        _CSDT_DIRECT_SELECT_CLICK_GUARD[key] = {
            'time': time.monotonic(),
            'mode': str(mode or 'SET').upper(),
            'x': int(x),
            'y': int(y),
        }
    except Exception:
        pass


def _consume_recent_direct_selection_click(context, mode, x, y, *, max_dist=5):
    try:
        key = _csdt_window_guard_key(context)
        entry = _CSDT_DIRECT_SELECT_CLICK_GUARD.get(key)
        if not entry:
            return False
        now = time.monotonic()
        if (now - float(entry.get('time', 0.0) or 0.0)) > float(_CSDT_DIRECT_SELECT_GUARD_SECONDS):
            _CSDT_DIRECT_SELECT_CLICK_GUARD.pop(key, None)
            return False
        if str(entry.get('mode', 'SET') or 'SET').upper() != str(mode or 'SET').upper():
            return False
        ex = int(entry.get('x', -1000000))
        ey = int(entry.get('y', -1000000))
        if abs(int(x) - ex) <= int(max_dist) and abs(int(y) - ey) <= int(max_dist):
            _CSDT_DIRECT_SELECT_CLICK_GUARD.pop(key, None)
            return True
    except Exception:
        return False
    return False


def _prune_direct_selection_click_guards():
    try:
        now = time.monotonic()
        stale = [key for key, entry in list(_CSDT_DIRECT_SELECT_CLICK_GUARD.items())
                 if (now - float(entry.get('time', 0.0) or 0.0)) > float(_CSDT_DIRECT_SELECT_GUARD_SECONDS)]
        for key in stale:
            _CSDT_DIRECT_SELECT_CLICK_GUARD.pop(key, None)
    except Exception:
        pass


# =========================================================
# Main Force Operator (Overrides Left Click)
# =========================================================
class VIEW3D_OT_sts_csdt_force(bpy.types.Operator):
    bl_idname = "view3d.sts_csdt_force"
    bl_label = "Smart Transform Click Handler"
    bl_description = "Main Smart Transform click handler that decides whether the click should select, start a drag transform, or pass through to Blender"
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    mode: bpy.props.StringProperty(name="Mode", default="", options={'HIDDEN'})
    action: bpy.props.StringProperty(name="Action", default="", options={'HIDDEN'})
    select_mode_hint: bpy.props.StringProperty(name="Selection Mode Hint", default="", options={'HIDDEN'})
    override_mouse_region_x: bpy.props.IntProperty(name="Override Mouse Region X", default=-1, options={'HIDDEN'})
    override_mouse_region_y: bpy.props.IntProperty(name="Override Mouse Region Y", default=-1, options={'HIDDEN'})
    deferred_gizmo_hit_id: bpy.props.StringProperty(name="Deferred Gizmo Hit ID", default="", options={'HIDDEN'})
    deferred_gizmo_selection_payload: bpy.props.StringProperty(name="Deferred Gizmo Selection Payload", default="", options={'HIDDEN'})

    def _event_region_xy(self, event):
        try:
            region = getattr(self, '_sts_event_region', None)
            if region is not None:
                return (
                    int(getattr(event, 'mouse_x', 0)) - int(getattr(region, 'x', 0) or 0),
                    int(getattr(event, 'mouse_y', 0)) - int(getattr(region, 'y', 0) or 0),
                )
        except Exception:
            pass
        try:
            return int(getattr(event, 'mouse_region_x', self.start_x)), int(getattr(event, 'mouse_region_y', self.start_y))
        except Exception:
            return int(getattr(self, 'start_x', 0)), int(getattr(self, 'start_y', 0))

    def _event_inside_invocation_view3d_region(self, context, event) -> bool:
        """Return True only for pointer events physically inside View3D WINDOW.

        Quad View can invoke this operator with a context region that is not the
        same RNA object as the quadrant under the cursor.  Test against the
        physical window coordinates first, then store the resolved region in
        ``invoke``.  This keeps Blender UI regions pass-through while allowing all
        four Quad View panes to use click and box selection.
        """
        try:
            try:
                ox = int(getattr(self, 'override_mouse_region_x', -1))
                oy = int(getattr(self, 'override_mouse_region_y', -1))
            except Exception:
                ox = oy = -1
            if ox >= 0 and oy >= 0:
                area0 = getattr(context, 'area', None)
                region0 = getattr(context, 'region', None)
                if getattr(area0, 'type', None) == 'VIEW_3D' and getattr(region0, 'type', None) == 'WINDOW':
                    rw0 = int(getattr(region0, 'width', 0) or 0)
                    rh0 = int(getattr(region0, 'height', 0) or 0)
                    if rw0 > 0 and rh0 > 0:
                        return 0 <= ox < rw0 and 0 <= oy < rh0
            area, region = cu._event_view3d_area_region(context, event)
            if area is None or getattr(area, 'type', None) != 'VIEW_3D':
                return False
            if region is None or getattr(region, 'type', None) != 'WINDOW':
                return False
            rw = int(getattr(region, 'width', 0) or 0)
            rh = int(getattr(region, 'height', 0) or 0)
            if rw <= 0 or rh <= 0:
                return False
            if ox >= 0 and oy >= 0:
                return 0 <= ox < rw and 0 <= oy < rh
            wx = int(getattr(event, 'mouse_x', 0))
            wy = int(getattr(event, 'mouse_y', 0))
            return bool(cu._event_inside_region(region, wx, wy))
        except Exception:
            return False

    def _selection_mode_from_event(self, event):
        try:
            # Exact keymap variants store the intended selection mode on the
            # operator.  This avoids a stale/tool-specific keymap reverting to
            # Blender's native Shift=toggle or Ctrl=center/shortest-path route.
            hint = str(getattr(self, 'select_mode_hint', '') or '').strip().upper()
            if hint in {'SET', 'ADD', 'SUB', 'XOR'}:
                return hint
        except Exception:
            pass
        try:
            # Alt+drag and Alt+modifier drags are reserved for Blender's native
            # selection/keymap behavior.  Do not translate any Alt gesture to the
            # add-on's ADD/SUB/XOR modes.
            if bool(getattr(event, 'alt', False)):
                return 'SET'
            if bool(getattr(event, 'shift', False)) and bool(getattr(event, 'ctrl', False)):
                return 'XOR'
            if bool(getattr(event, 'ctrl', False)):
                return 'SUB'
            if bool(getattr(event, 'shift', False)):
                return 'ADD'
        except Exception:
            pass
        return 'SET'

    def _editmesh_edge_mode_active(self, context) -> bool:
        try:
            if str(getattr(self, 'mode', '') or getattr(context, 'mode', '') or '') != 'EDIT_MESH':
                return False
            modes = tuple(bool(v) for v in getattr(getattr(context, 'tool_settings', None), 'mesh_select_mode', (False, False, False)))
            return len(modes) >= 2 and bool(modes[1])
        except Exception:
            return False

    def _editmesh_face_mode_active(self, context) -> bool:
        try:
            if str(getattr(self, 'mode', '') or getattr(context, 'mode', '') or '') != 'EDIT_MESH':
                return False
            modes = tuple(bool(v) for v in getattr(getattr(context, 'tool_settings', None), 'mesh_select_mode', (False, False, False)))
            return len(modes) >= 3 and bool(modes[2])
        except Exception:
            return False

    def _editmesh_edge_mode_hit(self, context, hit=None) -> bool:
        try:
            if not self._editmesh_edge_mode_active(context):
                return False
            if hit is None:
                hit = getattr(self, 'hit_result', None)
            return hit is not None and str(hit[0] or '').upper() == 'EDGE'
        except Exception:
            return False

    def _apply_edge_mode_click_selection(self, context, event, hit=None, target_obj=None) -> bool:
        if not self._editmesh_edge_mode_hit(context, hit):
            return False
        mode = str(getattr(self, '_initial_selection_mode', '') or self._selection_mode_from_event(event))
        # The hit tuple was produced by this add-on's configured Edge Hit Radius.
        # Keep edge-mode click selection on the deterministic BMesh path so the
        # effective selectable range cannot drift to Blender's native tolerance.
        applied = self._apply_click_selection_mode(context, mode, hit, target_obj)
        self.initial_selection_done = bool(applied)
        if applied:
            try:
                cu._invalidate_gizmo_cache()
            except Exception:
                pass
        return bool(applied)

    def _drag_distance(self, event):
        try:
            x, y = self._event_region_xy(event)
            return math.hypot(float(x) - float(self.start_x), float(y) - float(self.start_y))
        except Exception:
            return 0.0

    def _tag_redraw(self, context):
        try:
            area = getattr(context, 'area', None)
            if area is not None:
                area.tag_redraw()
                return
        except Exception:
            pass

    def _start_native_background_region_select(self, context, event):
        """Start Blender's own Box/Lasso modal from the original mouse press.

        Smart Transform keeps the Move/Rotate/Scale toolbar tool active while the
        configured background selector runs.  Starting the native selector here,
        before the pointer has moved past the drag threshold, lets Blender own the
        visible selection boundary in every View3D WINDOW region (including Quad
        View panes and restored workspaces).  The previous delayed/custom preview
        remains the fallback when Blender rejects the modal invocation.
        """
        tool_id = str(getattr(self, '_bg_select_tool_id', '') or '').strip()
        if tool_id not in {'builtin.select_box', 'builtin.select_lasso'}:
            return False
        mode = str(getattr(self, '_initial_selection_mode', '') or 'SET').upper()
        if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
            mode = 'SET'
        area = getattr(self, '_sts_event_area', None)
        region = getattr(self, '_sts_event_region', None)
        rv3d = getattr(self, '_sts_event_rv3d', None)
        if area is None or region is None:
            return False
        try:
            self._ssg_select_through_token = _ssg_select_through_begin(context, event)
        except Exception:
            self._ssg_select_through_token = None
        try:
            with cu._temp_override_view3d(
                context,
                area=area,
                region=region,
                region_data=rv3d,
            ):
                started = bool(cu._dispatch_selection_tool(
                    bpy.context,
                    mode=mode,
                    prefer_wait_for_input=False,
                    tool_id=tool_id,
                ))
                if started:
                    _ssg_select_through_touch(getattr(self, '_ssg_select_through_token', None))
                    return True
        except Exception:
            pass
        try:
            _ssg_select_through_finish(
                getattr(self, '_ssg_select_through_token', None),
                cancelled=True,
                delay=0.01,
            )
        except Exception:
            pass
        self._ssg_select_through_token = None
        return False

    def _begin_native_background_release_guard(self, context):
        """Keep Select Guard alive while Blender owns the region-select modal.

        Blender's native Box/Lasso operator draws and updates the selection
        boundary.  This Smart Transform operator stays behind it only as a
        pass-through release guard, so temporary select-through X-Ray is not
        restored before Blender applies the final selection on LEFTMOUSE release.
        """
        self._native_bg_release_guard = True
        self._native_bg_release_seen = False
        self._native_bg_release_cancelled = False
        self._native_bg_drag_confirmed = False
        self._native_bg_click_should_deselect = False
        self._native_bg_release_timer = None
        try:
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception:
            try:
                _ssg_select_through_finish(
                    getattr(self, '_ssg_select_through_token', None),
                    cancelled=False,
                    delay=0.08,
                )
            except Exception:
                pass
            self._ssg_select_through_token = None
            self._native_bg_release_guard = False
            _clear_smart_gizmo_drag_state()
            return {'FINISHED'}

    def _finish_native_background_release_guard(self, context):
        should_deselect = bool(getattr(self, '_native_bg_click_should_deselect', False))
        try:
            timer = getattr(self, '_native_bg_release_timer', None)
            wm = getattr(context, 'window_manager', None)
            if timer is not None and wm is not None:
                wm.event_timer_remove(timer)
        except Exception:
            pass
        self._native_bg_release_timer = None
        self._native_bg_release_guard = False
        self._native_bg_release_seen = False
        self._native_bg_release_cancelled = False
        self._native_bg_drag_confirmed = False
        self._native_bg_click_should_deselect = False
        self._ssg_select_through_token = None
        if should_deselect:
            try:
                cu._deselect_all(context)
            except Exception:
                pass
        _clear_smart_gizmo_drag_state()
        return {'FINISHED'}

    def _start_background_box_preview(self, context, event=None):
        """Start a lightweight local box preview at the original press point.

        Blender's native select_box modal uses the event position at the time it
        is invoked.  Invoking it only after the drag threshold makes the visible
        rectangle begin at the later mouse location.  This preview is owned by
        this operator, so its origin remains exactly self.start_x/self.start_y.
        """
        self._bg_box_preview = True
        self._bg_box_drag_confirmed = False
        mode = str(getattr(self, '_initial_selection_mode', '') or '').strip().upper()
        if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
            mode = self._selection_mode_from_event(event) if event is not None else 'SET'
        self._bg_box_mode = mode if mode in {'SET', 'ADD', 'SUB', 'XOR'} else 'SET'
        self._bg_region_tool_id = str(getattr(self, '_bg_select_tool_id', '') or 'builtin.select_box').strip()
        self._bg_box_current_x = int(getattr(self, 'start_x', 0))
        self._bg_box_current_y = int(getattr(self, 'start_y', 0))
        self._bg_lasso_points = []
        if self._bg_region_tool_id == 'builtin.select_lasso':
            self._bg_lasso_points.append((self._bg_box_current_x, self._bg_box_current_y))
        try:
            if getattr(self, '_ssg_select_through_token', None) is None:
                self._ssg_select_through_token = _ssg_select_through_begin(context, event)
            else:
                _ssg_select_through_touch(self._ssg_select_through_token)
        except Exception:
            self._ssg_select_through_token = None
        try:
            self._bg_box_area = getattr(self, '_sts_event_area', None)
            self._bg_box_region = getattr(self, '_sts_event_region', None)
            if self._bg_box_area is None or self._bg_box_region is None:
                self._bg_box_area = getattr(context, 'area', None) if getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' else None
                self._bg_box_region = getattr(context, 'region', None) if getattr(getattr(context, 'region', None), 'type', None) == 'WINDOW' else None
            if self._bg_box_area is None or self._bg_box_region is None:
                self._bg_box_area, self._bg_box_region = cu._get_view3d_area_region(context)
            self._bg_box_rv3d = getattr(self, '_sts_event_rv3d', None) or getattr(context, 'region_data', None)
            if self._bg_box_rv3d is None:
                try:
                    self._bg_box_rv3d = cu._view3d_region_data(self._bg_box_area, self._bg_box_region)
                except Exception:
                    self._bg_box_rv3d = None
            try:
                self._bg_crossing_preselect = cu._csdt_crossing_preselect_snapshot(
                    context, 'VIEW_3D', include_edges=True, include_faces=True
                ) if cu._csdt_crossing_selection_enabled(context) else {}
            except Exception:
                self._bg_crossing_preselect = {}
        except Exception:
            self._bg_box_area = None
            self._bg_box_region = None
            self._bg_box_rv3d = None
            self._bg_crossing_preselect = {}
        try:
            self._bg_box_started_at = time.monotonic()
        except Exception:
            self._bg_box_started_at = 0.0
        self._bg_box_draw_handle = getattr(self, '_bg_box_draw_handle', None)
        if self._bg_box_draw_handle is None:
            try:
                _cleanup_background_box_preview_registry(force=False, exclude=self)
            except Exception:
                pass
            try:
                self._bg_box_draw_handle = bpy.types.SpaceView3D.draw_handler_add(
                    self._draw_background_box_preview, (), 'WINDOW', 'POST_PIXEL'
                )
                try:
                    _CSDT_BACKGROUND_BOX_PREVIEWS.append({
                        'op': self,
                        'handle': self._bg_box_draw_handle,
                        'started': float(getattr(self, '_bg_box_started_at', 0.0) or 0.0),
                    })
                    _ensure_background_box_preview_cleanup_timer()
                except Exception:
                    pass
            except Exception:
                self._bg_box_draw_handle = None
        self._tag_redraw(context)

    def _update_background_box_preview(self, context, event):
        if not bool(getattr(self, '_bg_box_preview', False)):
            return
        x, y = self._event_region_xy(event)
        self._bg_box_current_x = int(x)
        self._bg_box_current_y = int(y)
        if str(getattr(self, '_bg_region_tool_id', '') or '') == 'builtin.select_lasso':
            try:
                point = (int(x), int(y))
                points = getattr(self, '_bg_lasso_points', None)
                if points is None:
                    points = []
                    self._bg_lasso_points = points
                if not points or points[-1] != point:
                    points.append(point)
            except Exception:
                pass
        try:
            _ssg_select_through_touch(getattr(self, '_ssg_select_through_token', None))
        except Exception:
            pass
        try:
            if self._drag_distance(event) >= max(1, int(getattr(self, 'drag_threshold', 1))):
                self._bg_box_drag_confirmed = True
                self.drag_started = True
                cg._CSDT_IS_DRAGGING = True
        except Exception:
            pass
        self._tag_redraw(context)

    def _background_box_preview_draw_region_matches(self):
        """Return True only while Blender draws the View3D region that owns this preview."""
        area = getattr(self, '_bg_box_area', None)
        region = getattr(self, '_bg_box_region', None)
        if region is None:
            return False

        # SpaceView3D draw handlers are registered globally for every View3D.
        # The preview coordinates are region-local, so drawing them in another
        # split View3D duplicates the dashed rectangle.  Use Blender's current
        # draw context as the primary exact discriminator and do not accept the
        # common (0, 0, width, height) GPU viewport fallback, because that local
        # rectangle is identical in every split view.
        ctx = getattr(bpy, 'context', None)
        area_matches = None
        try:
            cur_area = getattr(ctx, 'area', None)
            if area is not None and cur_area is not None and getattr(cur_area, 'type', None) == 'VIEW_3D':
                try:
                    if int(cur_area.as_pointer()) != int(area.as_pointer()):
                        return False
                    area_matches = True
                except Exception:
                    if cur_area is not area:
                        return False
                    area_matches = True
        except Exception:
            pass
        try:
            cur_region = getattr(ctx, 'region', None)
            if cur_region is not None and getattr(cur_region, 'type', None) == 'WINDOW':
                try:
                    return int(cur_region.as_pointer()) == int(region.as_pointer())
                except Exception:
                    return cur_region is region
        except Exception:
            pass

        # Some Blender draw stacks expose the current View3D area but temporarily
        # omit context.region.  RegionView3D still identifies Quad View panes; in
        # a normal split View3D the exact area match is already sufficient.
        if area_matches:
            owner_rv3d = getattr(self, '_bg_box_rv3d', None)
            try:
                cur_rv3d = getattr(ctx, 'region_data', None)
                if owner_rv3d is not None and cur_rv3d is not None:
                    try:
                        return int(cur_rv3d.as_pointer()) == int(owner_rv3d.as_pointer())
                    except Exception:
                        return cur_rv3d is owner_rv3d
            except Exception:
                pass
            try:
                _vx, _vy, vw, vh = gpu.state.viewport_get()
                rw = int(getattr(region, 'width', 0)); rh = int(getattr(region, 'height', 0))
                if abs(int(round(float(vw))) - rw) <= 2 and abs(int(round(float(vh))) - rh) <= 2:
                    return True
            except Exception:
                pass

        # Last-resort path for builds where context.region is unavailable during
        # POST_PIXEL drawing.  Only absolute viewport coordinates are accepted;
        # local viewport coordinates are intentionally rejected to avoid drawing
        # in every View3D when several regions share the same size.
        try:
            vx, vy, vw, vh = gpu.state.viewport_get()
            vx = int(round(float(vx))); vy = int(round(float(vy)))
            vw = int(round(float(vw))); vh = int(round(float(vh)))
            rx = int(getattr(region, 'x', 0)); ry = int(getattr(region, 'y', 0))
            rw = int(getattr(region, 'width', 0)); rh = int(getattr(region, 'height', 0))
            return abs(vx - rx) <= 2 and abs(vy - ry) <= 2 and abs(vw - rw) <= 2 and abs(vh - rh) <= 2
        except Exception:
            return False

    def _draw_background_box_preview(self):
        if not bool(getattr(self, '_bg_box_preview', False)):
            return
        try:
            started = float(getattr(self, '_bg_box_started_at', 0.0) or 0.0)
            if started > 0.0 and (time.monotonic() - started) > float(_CSDT_BACKGROUND_BOX_PREVIEW_MAX_AGE):
                self._bg_box_preview = False
                return
        except Exception:
            pass
        if not self._background_box_preview_draw_region_matches():
            return
        try:
            sx = float(getattr(self, 'start_x', 0))
            sy = float(getattr(self, 'start_y', 0))
            cx = float(getattr(self, '_bg_box_current_x', sx))
            cy = float(getattr(self, '_bg_box_current_y', sy))
            if abs(cx - sx) < 0.5 and abs(cy - sy) < 0.5:
                return
            if str(getattr(self, '_bg_region_tool_id', '') or '') == 'builtin.select_lasso':
                points = [(float(x), float(y)) for x, y in list(getattr(self, '_bg_lasso_points', ()) or ())]
                if len(points) < 2:
                    return
                shader = cu._csdt_get_shader_2d_uniform()
                if shader is None:
                    return
                prev_blend = None
                try:
                    prev_blend = gpu.state.blend_get()
                except Exception:
                    pass
                try:
                    gpu.state.blend_set('ALPHA')
                    gpu.state.line_width_set(1.0)
                    shader.bind()
                    batch = batch_for_shader(shader, 'LINE_STRIP', {'pos': points})
                    shader.uniform_float('color', (1.0, 1.0, 1.0, 1.0))
                    batch.draw(shader)
                    if len(points) >= 3:
                        close_batch = batch_for_shader(shader, 'LINES', {'pos': [points[-1], points[0]]})
                        shader.uniform_float('color', (1.0, 1.0, 1.0, 0.32))
                        close_batch.draw(shader)
                finally:
                    try:
                        gpu.state.line_width_set(1.0)
                    except Exception:
                        pass
                    try:
                        gpu.state.blend_set(prev_blend if prev_blend is not None else 'NONE')
                    except Exception:
                        pass
                return
            xmin, xmax = (sx, cx) if sx <= cx else (cx, sx)
            ymin, ymax = (sy, cy) if sy <= cy else (cy, sy)
            shader = cu._csdt_get_shader_2d_uniform()
            if shader is None:
                return

            # Match Blender's default box-select overlay: very light white fill
            # plus a one-pixel white dashed outline. The low-alpha outline is
            # drawn first so the 4 px gaps look like Blender's pale secondary
            # dash rather than disappearing into the viewport background.
            fill_verts = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymin), (xmax, ymax), (xmin, ymax)]
            outline_verts = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
            dash_verts = []

            def _append_dash(x1, y1, x2, y2, phase=4.0, dash=4.0, gap=4.0):
                dx = float(x2) - float(x1)
                dy = float(y2) - float(y1)
                length = math.hypot(dx, dy)
                if length <= 0.0:
                    return
                ux = dx / length
                uy = dy / length
                period = max(1.0, dash + gap)
                pos = float(phase) % period
                while pos < length:
                    end = min(pos + dash, length)
                    if end > pos:
                        dash_verts.append((x1 + ux * pos, y1 + uy * pos))
                        dash_verts.append((x1 + ux * end, y1 + uy * end))
                    pos += period

            # A 4 px on / 4 px off cadence matches the stock Blender box-select
            # dash pattern. The bottom/right edge phase is offset to avoid a
            # visibly heavy corner when dragging from any direction.
            _append_dash(xmin, ymin, xmax, ymin, phase=0.0)
            _append_dash(xmax, ymin, xmax, ymax, phase=4.0)
            _append_dash(xmin, ymax, xmax, ymax, phase=4.0)
            _append_dash(xmin, ymin, xmin, ymax, phase=4.0)

            prev_blend = None
            try:
                prev_blend = gpu.state.blend_get()
            except Exception:
                pass
            try:
                gpu.state.blend_set('ALPHA')
            except Exception:
                pass
            shader.bind()
            try:
                fill_batch = batch_for_shader(shader, 'TRIS', {'pos': fill_verts})
                shader.uniform_float('color', (1.0, 1.0, 1.0, 0.055))
                fill_batch.draw(shader)
            except Exception:
                pass
            try:
                gpu.state.line_width_set(1.0)
                # Vulkan では LINE_LOOP の閉じる辺が落ちるため、始点を足した LINE_STRIP で閉じる。
                low_batch = batch_for_shader(shader, 'LINE_STRIP', {'pos': outline_verts + outline_verts[:1]})
                shader.uniform_float('color', (1.0, 1.0, 1.0, 0.26))
                low_batch.draw(shader)
            except Exception:
                pass
            try:
                if dash_verts:
                    dash_batch = batch_for_shader(shader, 'LINES', {'pos': dash_verts})
                    shader.uniform_float('color', (1.0, 1.0, 1.0, 1.0))
                    dash_batch.draw(shader)
            except Exception:
                pass
            try:
                if prev_blend is not None:
                    gpu.state.blend_set(prev_blend)
                else:
                    gpu.state.blend_set('NONE')
            except Exception:
                pass
        except Exception:
            return

    def _remove_background_box_preview(self, context=None):
        handle = getattr(self, '_bg_box_draw_handle', None)
        if handle is not None:
            _remove_background_box_preview_handle(handle)
            try:
                _CSDT_BACKGROUND_BOX_PREVIEWS[:] = [
                    entry for entry in _CSDT_BACKGROUND_BOX_PREVIEWS
                    if entry.get('handle') is not handle and entry.get('op') is not self
                ]
            except Exception:
                pass
        self._bg_box_draw_handle = None
        self._bg_box_preview = False
        self._bg_lasso_points = []
        try:
            if context is not None:
                self._tag_redraw(context)
        except Exception:
            pass

    def _finish_background_box_select(self, context, event):
        self._update_background_box_preview(context, event)
        confirmed = bool(getattr(self, '_bg_box_drag_confirmed', False))
        if not confirmed:
            try:
                confirmed = self._drag_distance(event) >= max(1, int(getattr(self, 'drag_threshold', 1)))
            except Exception:
                confirmed = False
        x = int(getattr(self, '_bg_box_current_x', getattr(self, 'start_x', 0)))
        y = int(getattr(self, '_bg_box_current_y', getattr(self, 'start_y', 0)))
        sx = int(getattr(self, 'start_x', x))
        sy = int(getattr(self, 'start_y', y))
        mode = str(getattr(self, '_bg_box_mode', 'SET') or 'SET').upper()
        if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
            mode = 'SET'
        region_tool_id = str(getattr(self, '_bg_region_tool_id', '') or 'builtin.select_box')
        lasso_points = list(getattr(self, '_bg_lasso_points', ()) or ())
        if region_tool_id == 'builtin.select_lasso' and (not lasso_points or lasso_points[-1] != (x, y)):
            lasso_points.append((x, y))
        self._remove_background_box_preview(context)
        if confirmed and region_tool_id == 'builtin.select_lasso':
            _ssg_suppress_post_selection_filter(0.65)
            native_select_ok = False
            try:
                native_select_ok = bool(cu._execute_view3d_select_lasso_region(
                    context, lasso_points, mode=mode,
                    area=getattr(self, '_bg_box_area', None),
                    region=getattr(self, '_bg_box_region', None),
                    region_data=getattr(self, '_bg_box_rv3d', None),
                ))
            except Exception:
                native_select_ok = False
            try:
                shape = cu._csdt_crossing_selection_shape('LASSO', points=lasso_points)
                if shape is not None:
                    cu._csdt_apply_crossing_selection_region(
                        context, 'VIEW_3D', shape, mode=mode,
                        area=getattr(self, '_bg_box_area', None),
                        region=getattr(self, '_bg_box_region', None),
                        region_data=getattr(self, '_bg_box_rv3d', None),
                        preselect=getattr(self, '_bg_crossing_preselect', {}) or {},
                        native_select_ok=native_select_ok,
                        clear_first=(str(mode or 'SET').upper() == 'SET' and not native_select_ok),
                    )
            except Exception:
                pass
            try:
                _ssg_select_through_finish(getattr(self, '_ssg_select_through_token', None), cancelled=False, delay=0.04)
                self._ssg_select_through_token = None
            except Exception:
                pass
            return bool(native_select_ok)
        if confirmed:
            # The Smart Gizmo background-select route is already a complete
            # selection operation.  Suppress the later Smart Select Guard
            # occlusion burst so dense vertex/edge/face selections confirm
            # immediately instead of ray-casting the whole selection again.
            _ssg_suppress_post_selection_filter(0.65)
            native_select_ok = False
            try:
                native_select_ok = bool(cu._execute_view3d_select_box_region(
                    context, sx, x, sy, y, mode=mode,
                    area=getattr(self, '_bg_box_area', None),
                    region=getattr(self, '_bg_box_region', None),
                    region_data=getattr(self, '_bg_box_rv3d', None),
                ))
            except Exception:
                native_select_ok = False
            ssg_applied = False
            try:
                token = getattr(self, '_ssg_select_through_token', None)
                # Edit Mesh already receives the exact-mode deterministic
                # supplement below.  Running Smart Select Guard's second Python
                # rectangle pass here duplicated work and could broaden the
                # selected range.  Keep the external fallback for Object mode.
                if token and str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
                    ssg_applied = bool(_ssg_select_through_apply_box(
                        context, token, (sx, sy), (x, y),
                        shift=bool(mode in {'ADD', 'XOR'}),
                        ctrl=bool(mode in {'SUB', 'XOR'}),
                        alt=False,
                    ))
            except Exception:
                ssg_applied = False
            # Edit Mode needs a deterministic geometry supplement when Blender's
            # native select_box receives a stale or cancelled View3D context.  The
            # supplement uses the exact visible dashed rectangle and follows the
            # active vertex / edge / face select mode.
            try:
                supplemented = bool(cu._csdt_supplement_editmesh_box_selection(
                    context, sx, x, sy, y, mode=mode,
                    area=getattr(self, '_bg_box_area', None),
                    region=getattr(self, '_bg_box_region', None),
                    region_data=getattr(self, '_bg_box_rv3d', None),
                    native_select_ok=native_select_ok,
                    clear_first=(str(mode or 'SET').upper() == 'SET' and not native_select_ok),
                ))
                if not supplemented:
                    cu._csdt_supplement_editmesh_edge_box_selection(
                        context, sx, x, sy, y, mode=mode,
                        area=getattr(self, '_bg_box_area', None),
                        region=getattr(self, '_bg_box_region', None),
                        region_data=getattr(self, '_bg_box_rv3d', None),
                        native_select_ok=native_select_ok,
                        clear_first=(str(mode or 'SET').upper() == 'SET' and not native_select_ok),
                    )
            except Exception:
                pass
            try:
                shape = cu._csdt_crossing_selection_shape('BOX', start=(sx, sy), end=(x, y))
                if shape is not None:
                    cu._csdt_apply_crossing_selection_region(
                        context, 'VIEW_3D', shape, mode=mode,
                        area=getattr(self, '_bg_box_area', None),
                        region=getattr(self, '_bg_box_region', None),
                        region_data=getattr(self, '_bg_box_rv3d', None),
                        preselect=getattr(self, '_bg_crossing_preselect', {}) or {},
                        native_select_ok=native_select_ok,
                        clear_first=(str(mode or 'SET').upper() == 'SET' and not native_select_ok),
                    )
            except Exception:
                pass
            try:
                _ssg_select_through_finish(getattr(self, '_ssg_select_through_token', None), cancelled=False, delay=0.04)
                self._ssg_select_through_token = None
            except Exception:
                pass
            return True
        try:
            _ssg_select_through_finish(getattr(self, '_ssg_select_through_token', None), cancelled=False, delay=0.04)
            self._ssg_select_through_token = None
        except Exception:
            pass
        return False

    def cancel(self, context):
        self._deferred_gizmo_click_select = False
        try:
            timer = getattr(self, '_native_bg_release_timer', None)
            wm = getattr(context, 'window_manager', None)
            if timer is not None and wm is not None:
                wm.event_timer_remove(timer)
        except Exception:
            pass
        self._native_bg_release_timer = None
        self._native_bg_release_guard = False
        self._native_bg_drag_confirmed = False
        self._native_bg_click_should_deselect = False
        try:
            _ssg_select_through_finish(getattr(self, '_ssg_select_through_token', None), cancelled=True, delay=0.01)
            self._ssg_select_through_token = None
        except Exception:
            pass
        try:
            self._remove_background_box_preview(context)
        except Exception:
            pass
        try:
            _clear_smart_gizmo_drag_state()
        except Exception:
            pass

    def _hit_context_object(self, context):
        obj = getattr(self, 'hit_object', None)
        if obj is not None:
            return obj
        return getattr(context, 'active_object', None)

    def _apply_single_click_selection(self, context, hit=None, target_obj=None):
        """Apply the click target as the current selection immediately."""
        hit = hit if hit is not None else getattr(self, 'hit_result', None)
        target_obj = target_obj if target_obj is not None else self._hit_context_object(context)
        if hit is None:
            return False
        try:
            if self.mode == "OBJECT":
                cu._object_select_single(context, hit[0])
            elif self.mode == "EDIT_MESH" and target_obj is not None and getattr(target_obj, 'type', None) == 'MESH':
                try:
                    context.view_layer.objects.active = target_obj
                except Exception:
                    pass
                cu._editmesh_select_single(context, target_obj, hit)
            elif self.mode == "EDIT_LATTICE" and target_obj is not None and getattr(target_obj, 'type', None) == 'LATTICE':
                try:
                    context.view_layer.objects.active = target_obj
                except Exception:
                    pass
                cu._editlattice_select_single(context, target_obj, hit, self.start_x, self.start_y)
            elif self.mode in {"EDIT_CURVE", "EDIT_SURFACE"} and target_obj is not None and getattr(target_obj, 'type', None) in {'CURVE', 'SURFACE'}:
                try:
                    context.view_layer.objects.active = target_obj
                except Exception:
                    pass
                cu._editcurve_select_single(context, target_obj, hit)
            else:
                return False
            try:
                if str(getattr(context, 'mode', '') or '') == 'OBJECT':
                    cu._tag_selection_ui_redraw(context)
                else:
                    self._tag_redraw(context)
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _apply_active_only_click_selection(self, context, hit=None, target_obj=None):
        hit = hit if hit is not None else getattr(self, 'hit_result', None)
        target_obj = target_obj if target_obj is not None else self._hit_context_object(context)
        if hit is None:
            return False
        try:
            if self.mode == "OBJECT":
                cu._csdt_set_active_object_and_notify(context, hit[0], require_selected=False, redraw=True)
            elif self.mode == "EDIT_MESH" and target_obj is not None and getattr(target_obj, 'type', None) == 'MESH':
                try:
                    context.view_layer.objects.active = target_obj
                except Exception:
                    pass
                cu._editmesh_set_active_only(context, target_obj, hit)
            elif self.mode == "EDIT_LATTICE" and target_obj is not None and getattr(target_obj, 'type', None) == 'LATTICE':
                try:
                    context.view_layer.objects.active = target_obj
                except Exception:
                    pass
                cu._editlattice_set_active_only(context, target_obj, hit, self.start_x, self.start_y)
            elif self.mode in {"EDIT_CURVE", "EDIT_SURFACE"} and target_obj is not None and getattr(target_obj, 'type', None) in {'CURVE', 'SURFACE'}:
                try:
                    context.view_layer.objects.active = target_obj
                except Exception:
                    pass
                cu._editcurve_set_active_only(context, target_obj, hit)
            else:
                return False
            try:
                if str(getattr(context, 'mode', '') or '') == 'OBJECT':
                    cu._tag_selection_ui_redraw(context)
                else:
                    self._tag_redraw(context)
            except Exception:
                pass
            return True
        except Exception:
            return False

    def _apply_click_selection_mode(self, context, mode, hit=None, target_obj=None):
        hit = hit if hit is not None else getattr(self, 'hit_result', None)
        target_obj = target_obj if target_obj is not None else self._hit_context_object(context)
        if hit is None:
            return False
        try:
            changed = cu._csdt_apply_click_selection_mode(context, hit, target_obj, mode=mode)
            if changed:
                try:
                    if str(getattr(context, 'mode', '') or '') == 'OBJECT':
                        context.view_layer.update()
                    else:
                        self._tag_redraw(context)
                except Exception:
                    pass
            return bool(changed)
        except Exception:
            return False

    def _hit_selected_flag(self, hit) -> bool:
        try:
            if hit is None:
                return False
            if str(getattr(self, 'mode', '') or '') == 'OBJECT':
                return bool(hit[1])
            return bool(hit[2])
        except Exception:
            return False

    def _resolve_object_hover_provider(self, context, event=None):
        """Resolve SmartOverlay's already-loaded query-only Object hover provider once."""
        if bool(getattr(self, '_sts_hover_provider_resolved', False)):
            return getattr(self, '_sts_hover_provider_hit', None)

        self._sts_hover_provider_resolved = True
        self._sts_hover_provider_hit = None
        try:
            if event is None or str(getattr(event, 'value', '') or '') != 'PRESS':
                return None
            if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
                return None
            mesh_module = sys.modules.get('smart_overlay_suite.mesh')
            if mesh_module is None:
                for module_name, module in tuple(sys.modules.items()):
                    if str(module_name).endswith('.smart_overlay_suite.mesh'):
                        mesh_module = module
                        break
            provider = getattr(mesh_module, 'object_hover_selection_target', None) if mesh_module is not None else None
            if not callable(provider):
                return None
            target = provider(context, event)
            if target is None:
                return None
            view_layer = getattr(context, 'view_layer', None)
            if view_layer is None or not isinstance(target, bpy.types.Object):
                return None
            if view_layer.objects.get(target.name) is not target:
                return None
            if bool(getattr(target, 'hide_select', False)):
                return None
            if not bool(target.visible_get(view_layer=view_layer)):
                return None
            self._sts_hover_provider_hit = (
                target,
                bool(target.select_get(view_layer=view_layer)),
            )
            return self._sts_hover_provider_hit
        except Exception:
            return None

    def _hit_test_object_with_hover_provider(self, context, x, y, event=None):
        """Use the latched SmartOverlay target, then the native Object hit-test once."""
        provider_hit = self._resolve_object_hover_provider(context, event)
        if provider_hit is not None:
            return provider_hit

        if bool(getattr(self, '_sts_native_hit_resolved', False)):
            return getattr(self, '_sts_native_hit', None)

        self._sts_native_hit_resolved = True
        try:
            self._sts_native_hit = cu._hit_test_object(context, x, y)
        except Exception:
            self._sts_native_hit = None
        return self._sts_native_hit

    def _resolve_click_target_for_immediate_select(self, context, x=None, y=None, event=None):
        """Resolve the actual element/object under the configured click radius."""
        if self.mode == "OBJECT":
            if event is None:
                event = getattr(self, '_sts_hover_press_event', None)
            provider_hit = self._resolve_object_hover_provider(context, event)
            if provider_hit is not None:
                return provider_hit[0], provider_hit
        try:
            prefetched = getattr(cu, '_get_prefetched_immediate_select_hit', None)
            if prefetched is not None:
                target_obj, hit, valid = prefetched(context, int(x if x is not None else self.start_x), int(y if y is not None else self.start_y), getattr(context, 'active_object', None))
                if valid:
                    return target_obj, hit
        except Exception:
            pass
        try:
            target_obj, hit = self._hit_test_current_mode(context, x, y, event=event)
        except Exception:
            target_obj, hit = None, None
        return target_obj, hit

    def _click_target_should_override_gizmo(self, context, hit=None) -> bool:
        """Return whether a concrete click target may arbitrate a gizmo press."""
        if hit is None:
            return False
        try:
            prefs = cu._prefs(context)
            return bool(prefs and getattr(prefs, 'smart_gizmo_click_select_priority', False))
        except Exception:
            return False

    def _decode_deferred_gizmo_selection(self, context):
        """Decode the event-local hit payload supplied by the gizmo watcher."""
        try:
            raw = str(getattr(self, 'deferred_gizmo_selection_payload', '') or '')
            data = json.loads(raw)
            if not isinstance(data, dict):
                return None, None
            mode = str(data.get('mode', '') or '')
            if mode != str(getattr(self, 'mode', '') or ''):
                return None, None
            target_name = str(data.get('target', '') or '')
            target = context.view_layer.objects.get(target_name) if target_name else None
            if target is None:
                return None, None
            if mode == 'OBJECT':
                raw_hit = data.get('hit', {})
                if not isinstance(raw_hit, dict):
                    return None, None
                return target, (target, bool(raw_hit.get('selected', False)))

            def _as_tuple(value):
                if isinstance(value, list):
                    return tuple(_as_tuple(item) for item in value)
                return value

            hit = _as_tuple(data.get('hit', None))
            if not isinstance(hit, tuple) or len(hit) < 3:
                return None, None
            expected_types = {
                'EDIT_MESH': {'MESH'},
                'EDIT_LATTICE': {'LATTICE'},
                'EDIT_CURVE': {'CURVE', 'SURFACE'},
                'EDIT_SURFACE': {'CURVE', 'SURFACE'},
            }
            if getattr(target, 'type', None) not in expected_types.get(mode, set()):
                return None, None
            if str(getattr(target, 'mode', '') or '') != 'EDIT':
                return None, None
            return target, hit
        except Exception:
            return None, None

    def _begin_deferred_gizmo_click_select(self, context, event, prefs):
        """Hold an overlapping gizmo press until it becomes a click or drag."""
        try:
            if not bool(getattr(prefs, 'smart_gizmo_click_select_priority', False)):
                return None
            if str(getattr(event, 'type', '') or '') != 'LEFTMOUSE' or str(getattr(event, 'value', '') or '') != 'PRESS':
                return None
            if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
                return None
            selection_mode = str(self._selection_mode_from_event(event) or '').upper()
            if selection_mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
                return None
            gizmo_hit_id = str(getattr(self, 'deferred_gizmo_hit_id', '') or '')
            if not gizmo_hit_id:
                return None
            target, hit = self._decode_deferred_gizmo_selection(context)
            if target is None or hit is None:
                return None
        except Exception:
            return None

        self.gizmo_hit_id = gizmo_hit_id
        self.hit_gizmo = True
        self.hit_object = target
        self.hit_result = hit
        self.hit_empty = False
        self.hit_already_selected = self._hit_selected_flag(hit)
        self.initial_selection_done = False
        self._deferred_gizmo_click_select = True
        self._deferred_gizmo_selection_mode = selection_mode
        try:
            self._sts_press_mouse_window = (
                int(getattr(event, 'mouse_x', 0)),
                int(getattr(event, 'mouse_y', 0)),
            )
        except Exception:
            self._sts_press_mouse_window = None
        cg._SMART_GIZMO_HOVER_ID = gizmo_hit_id
        cg._SMART_GIZMO_LOCKED_ID = gizmo_hit_id
        cg._CSDT_DRAG_ACTIVE_ID = None
        cg._CSDT_IS_DRAGGING = False
        try:
            c_gizmo._update_gizmo_cache(context, self._sts_event_area, self._sts_event_region)
        except Exception:
            pass
        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._deferred_gizmo_click_select = False
            _clear_smart_gizmo_drag_state()
            return {'PASS_THROUGH'}
        try:
            cu._tag_view3d_redraw()
        except Exception:
            pass
        return {'RUNNING_MODAL'}

    def _commit_deferred_gizmo_click_select(self, context) -> bool:
        """Commit the stored target only after the gesture is proven to be a click."""
        if not bool(getattr(self, '_deferred_gizmo_click_select', False)):
            return False
        self._deferred_gizmo_click_select = False
        mode = str(
            getattr(self, '_deferred_gizmo_selection_mode', '')
            or getattr(self, '_initial_selection_mode', '')
            or 'SET'
        ).upper()
        if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
            mode = 'SET'
        hit = getattr(self, 'hit_result', None)
        target = getattr(self, 'hit_object', None)
        if mode == 'SET':
            applied = self._apply_single_click_selection(context, hit, target)
        else:
            applied = self._apply_click_selection_mode(context, mode, hit, target)
            if not applied:
                applied = self._apply_click_selection_mode_native_fallback(context, mode)
        self.initial_selection_done = bool(applied)
        if applied:
            _remember_direct_selection_click(context, mode, self.start_x, self.start_y)
            try:
                cu._invalidate_gizmo_cache()
            except Exception:
                pass
        return bool(applied)

    def _begin_deferred_gizmo_release_guard(self, context):
        """Consume Blender's follow-up CLICK after release-time selection."""
        self._direct_selection_release_guard = True
        self._direct_selection_release_seen = True
        self._direct_selection_guard_timer = None
        try:
            wm = getattr(context, 'window_manager', None)
            win = getattr(context, 'window', None)
            if wm is None:
                raise RuntimeError('window manager unavailable')
            self._direct_selection_guard_timer = wm.event_timer_add(float(_CSDT_DIRECT_SELECT_MODAL_GRACE), window=win)
            return {'RUNNING_MODAL'}
        except Exception:
            self._direct_selection_release_guard = False
            return {'FINISHED'}

    def _apply_click_selection_mode_native_fallback(self, context, mode):
        """Fallback selection route that calls Blender's selector with explicit flags.

        This is allowed only after this add-on already found a concrete hit with
        its configured detection radius.  A configured-range miss must stay a
        miss; otherwise Blender's native selector may apply a different internal
        pick radius and violate Sensitivity / Detection Range settings.
        """
        current_mode = str(getattr(self, 'mode', '') or '')
        if current_mode in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE'}:
            try:
                _target_obj, strict_hit = self._hit_test_current_mode(context, self.start_x, self.start_y)
            except Exception:
                strict_hit = None
            if strict_hit is None:
                return False
        mode = str(mode or 'SET').upper()
        try:
            if mode == 'SUB':
                return bool(cu._view3d_select_at(
                    context, self.start_x, self.start_y,
                    extend=False, deselect=True, toggle=False,
                    disallow_object_select=(str(getattr(self, 'mode', '')) != 'OBJECT'),
                ))
            if mode == 'XOR':
                return bool(cu._view3d_select_at(
                    context, self.start_x, self.start_y,
                    extend=False, deselect=False, toggle=True,
                    disallow_object_select=(str(getattr(self, 'mode', '')) != 'OBJECT'),
                ))
            if mode == 'ADD':
                return bool(cu._view3d_select_at(
                    context, self.start_x, self.start_y,
                    extend=True, deselect=False, toggle=False,
                    disallow_object_select=(str(getattr(self, 'mode', '')) != 'OBJECT'),
                ))
            return bool(cu._view3d_select_at(
                context, self.start_x, self.start_y,
                extend=False, deselect=False, toggle=False,
                disallow_object_select=(str(getattr(self, 'mode', '')) != 'OBJECT'),
            ))
        except Exception:
            return False

    def _begin_direct_selection_release_guard(self, context):
        """Consume the release/click that follows an already-applied press select.

        Returning FINISHED immediately after a Shift/Ctrl press lets Blender's
        later LEFTMOUSE CLICK keymap run as well.  In Blender 5.1 that native
        route uses Shift=toggle and Ctrl=center/shortest-path, which reverts the
        Smart Transform ADD/SUB result.  Holding a tiny modal guard until release
        keeps the click sequence owned by this operator.
        """
        self._direct_selection_release_guard = True
        self._direct_selection_release_seen = False
        self._direct_selection_guard_timer = None
        self.drag_started = False
        self.passed_through = False
        try:
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception:
            # If a non-modal test context reaches this code, prefer the already
            # applied deterministic selection over falling back to native keymaps.
            return {'FINISHED'}

    def _finish_direct_selection_guard(self, context, *, cancelled=False):
        try:
            timer = getattr(self, '_direct_selection_guard_timer', None)
            wm = getattr(context, 'window_manager', None)
            if timer is not None and wm is not None:
                wm.event_timer_remove(timer)
        except Exception:
            pass
        self._direct_selection_guard_timer = None
        self._direct_selection_release_guard = False
        self._direct_selection_release_seen = False
        self._remove_background_box_preview(context)
        _clear_smart_gizmo_drag_state()
        return {'CANCELLED'} if cancelled else {'FINISHED'}

    def _hit_test_current_mode(self, context, x=None, y=None, event=None):
        x = self.start_x if x is None else x
        y = self.start_y if y is None else y

        def _run_hit(ctx):
            obj = getattr(ctx, 'active_object', None)
            if self.mode == "OBJECT":
                hit = self._hit_test_object_with_hover_provider(ctx, x, y, event=event)
                return (hit[0] if hit else obj), hit
            if self.mode == "EDIT_MESH" and obj is not None and getattr(obj, 'type', None) == 'MESH':
                return cu._hit_test_editmesh_any(ctx, obj, x, y)
            if self.mode == "EDIT_LATTICE" and obj is not None and getattr(obj, 'type', None) == 'LATTICE':
                return cu._hit_test_editlattice_any(ctx, obj, x, y)
            if self.mode in {"EDIT_CURVE", "EDIT_SURFACE"} and obj is not None and getattr(obj, 'type', None) in {'CURVE', 'SURFACE'}:
                return cu._hit_test_editcurve_any(ctx, obj, x, y)
            return obj, None

        area = getattr(self, '_sts_event_area', None)
        region = getattr(self, '_sts_event_region', None)
        rv3d = getattr(self, '_sts_event_rv3d', None)
        if area is not None and region is not None:
            try:
                with cu._temp_override_view3d(context, area=area, region=region, region_data=rv3d):
                    return _run_hit(bpy.context)
            except Exception:
                pass
        return _run_hit(context)

    def invoke(self, context, event):
        prefs = cu._prefs()
        if not prefs:
            return {'PASS_THROUGH'}

        if not self._event_inside_invocation_view3d_region(context, event):
            _clear_smart_gizmo_drag_state()
            return {'PASS_THROUGH'}

        try:
            if bool(getattr(prefs, 'enable_axis_memory', True)):
                ensure_constraint_watchdog_running(context)
        except Exception:
            pass

        select_tool_ids = getattr(cu, '_SELECT_TOOL_IDS', {
            'builtin.select',
            'builtin.select_box',
            'builtin.select_circle',
            'builtin.select_lasso',
        })
        keymap_tool_id = str(getattr(self, 'action', '') or '').strip()
        if keymap_tool_id not in (set(select_tool_ids) | set(cg._TRANSFORM_TOOL_IDS)):
            keymap_tool_id = ''
        active_tool_id = keymap_tool_id or cu._active_tool_id(context)
        transform_route_active = _transform_tool_route_enabled(active_tool_id, prefs)
        if not (transform_route_active or active_tool_id in select_tool_ids):
            return {'PASS_THROUGH'}

        # Region-selection tools are intentionally handled here too.  Element
        # clicks remain under Smart Transform so edge mode always uses SET,
        # Shift=ADD and Ctrl=SUB; true background drags are routed to Box/Circle/Lasso.

        # Safety: custom hit-tests are implemented for Object / Edit Mesh / Edit Lattice / Edit Curve.
        if context.mode not in {'OBJECT', 'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE'}:
            return {'PASS_THROUGH'}

        # Alt+drag must remain Blender-native.  Manual Smart Transform click bindings
        # may use any=True so they can see Shift/Ctrl selection-tool variants;
        # explicitly pass Alt/Alt+modifier events through before any custom preview,
        # geometry supplement, or Smart Select Guard select-through hook starts.
        try:
            if bool(getattr(event, 'alt', False)):
                _restore_native_view3d_selection_routes(context)
                _clear_smart_gizmo_drag_state()
                return {'PASS_THROUGH'}
        except Exception:
            return {'PASS_THROUGH'}

        # Modifier-clicks on actual elements are Blender's native add/remove/toggle/loop-select
        # routes, but modifier background drags must still use the current custom selection tool
        # (Box / Circle / Lasso) so Shift/Ctrl background drags behave like plain background
        # drags while keeping ADD / SUB / XOR selection semantics. Alt is excluded and
        # passed through above so Blender's standard Alt+drag behavior is preserved.
        # The final pass-through decision is therefore made after the background hit-test below.
        modifier_event = _csdt_event_has_selection_modifier(event)
        addsub_modifier_event = bool(getattr(event, 'shift', False) or getattr(event, 'ctrl', False))

        # --- Variables ---
        self._sts_event_rv3d = None
        try:
            ox = int(getattr(self, 'override_mouse_region_x', -1))
            oy = int(getattr(self, 'override_mouse_region_y', -1))
        except Exception:
            ox = oy = -1
        ev_mx = ev_my = None
        if ox >= 0 and oy >= 0:
            self._sts_event_area = getattr(context, 'area', None) if getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D' else None
            self._sts_event_region = getattr(context, 'region', None) if getattr(getattr(context, 'region', None), 'type', None) == 'WINDOW' else None
            self._sts_event_rv3d = getattr(context, 'region_data', None)
            if self._sts_event_area is None or self._sts_event_region is None:
                try:
                    self._sts_event_area, self._sts_event_region = cu._event_view3d_area_region(context, event)
                except Exception:
                    self._sts_event_area = self._sts_event_region = None
            if self._sts_event_rv3d is None:
                try:
                    self._sts_event_rv3d = cu._view3d_region_data(self._sts_event_area, self._sts_event_region, ox, oy)
                except Exception:
                    self._sts_event_rv3d = None
            self.start_x = ox
            self.start_y = oy
        else:
            try:
                ev_area, ev_region, ev_mx, ev_my, ev_rv3d = cu._event_view3d_area_region_xy_rv3d(context, event)
                self._sts_event_area = ev_area
                self._sts_event_region = ev_region
                self._sts_event_rv3d = ev_rv3d
                if self._sts_event_area is None or self._sts_event_region is None:
                    self._sts_event_area = getattr(context, 'area', None)
                    self._sts_event_region = getattr(context, 'region', None)
                    self._sts_event_rv3d = getattr(context, 'region_data', None)
            except Exception:
                ev_mx = ev_my = None
                self._sts_event_area = None
                self._sts_event_region = None
                self._sts_event_rv3d = None
            if ev_mx is not None and ev_my is not None:
                self.start_x = int(ev_mx)
                self.start_y = int(ev_my)
            else:
                self.start_x, self.start_y = self._event_region_xy(event)
        self.mode = context.mode
        self.tool_id = active_tool_id
        self._sts_hover_press_event = event
        self._sts_hover_provider_resolved = False
        self._sts_hover_provider_hit = None
        self._sts_native_hit_resolved = False
        self._sts_native_hit = None
        self._initial_selection_mode = self._selection_mode_from_event(event)
        self.drag_started = False
        self.passed_through = False
        self.hit_gizmo = False
        self._bg_box_preview = False
        self._bg_box_draw_handle = None
        self._bg_box_drag_confirmed = False
        self._bg_fast_background = False
        self._bg_modifier_event = False
        self._bg_select_tool_id = "builtin.select_box"
        self._ssg_select_through_token = None
        self._native_bg_release_guard = False
        self._native_bg_release_seen = False
        self._native_bg_release_cancelled = False
        self._native_bg_drag_confirmed = False
        self._native_bg_click_should_deselect = False
        self._native_bg_release_timer = None
        self._direct_selection_release_guard = False
        self._click_fallback_event = (str(getattr(event, 'value', '') or '') == 'CLICK')
        self._edge_click_selection_forced = False
        self._defer_edge_native_click = False
        self._deferred_gizmo_click_select = False
        self._deferred_gizmo_selection_mode = 'SET'
        try:
            self._sts_press_mouse_window = (
                int(getattr(event, 'mouse_x', 0)),
                int(getattr(event, 'mouse_y', 0)),
            )
        except Exception:
            self._sts_press_mouse_window = None

        self.use_immediate_select = prefs.use_immediate_select
        self.keep_multi_selection = prefs.keep_multi_selection
        self.update_active_element = prefs.update_active_element
        self.enable_drag_transform = prefs.enable_drag_transform
        # DPI-aware threshold
        try:
            dpi = float(context.preferences.system.dpi)
        except Exception:
            dpi = 72.0
        self.drag_threshold = max(1, int(round(float(prefs.drag_threshold) * (dpi / 72.0))))
        self.enable_bg_deselect = prefs.enable_bg_deselect
        self.enable_bg_drag_select = prefs.enable_bg_drag_select
        try:
            if active_tool_id in cg._TRANSFORM_TOOL_IDS:
                self._bg_select_tool_id = cu._custom_select_tool_id_from_prefs(prefs)
            elif active_tool_id in select_tool_ids:
                self._bg_select_tool_id = active_tool_id
            else:
                self._bg_select_tool_id = cu._get_active_select_tool_id(context)
        except Exception:
            self._bg_select_tool_id = "builtin.select_box"

        cg._CSDT_IS_DRAGGING = False
        cg._CSDT_DRAG_ACTIVE_ID = None
        self.gizmo_hit_id = None
        _prune_direct_selection_click_guards()

        self._pre_hit_object = None
        self._pre_hit_result = None
        self._pre_hit_valid = False
        self._pre_hit_attempted = False
        self._pre_hit_overrides_gizmo = False

        if str(getattr(self, 'deferred_gizmo_hit_id', '') or ''):
            deferred_result = self._begin_deferred_gizmo_click_select(context, event, prefs)
            if deferred_result is not None:
                return deferred_result
            # The watcher will immediately continue through the unchanged
            # gizmo-first path when its event-local target became invalid.
            _clear_smart_gizmo_drag_state()
            return {'PASS_THROUGH'}

        event_value = str(getattr(event, 'value', '') or '').upper()
        if event_value in {'CLICK', 'DOUBLE_CLICK'}:
            # This is the follow-up event that Blender's native Select/Tweak maps
            # use for single-click selection.  If a PRESS route already applied the
            # deterministic Smart Transform selection, swallow the matching CLICK.
            click_mode = str(getattr(self, '_initial_selection_mode', '') or self._selection_mode_from_event(event))
            if _consume_recent_direct_selection_click(context, click_mode, self.start_x, self.start_y):
                _clear_smart_gizmo_drag_state()
                return {'FINISHED'}
            # If the add-on receives a CLICK without the PRESS route having run
            # first (edit-mode tool keymap priority can vary after workspace/tool
            # changes), Smart Gizmo hover must still win over any selectable
            # geometry behind it.  Swallow this fallback click instead of letting
            # the edit/object selector run with element hit logic.
            try:
                if transform_route_active and prefs.enable_smart_gizmo_style and prefs.gizmo_toggle_state:
                    click_g_hit = None
                    try:
                        resolver = getattr(c_gizmo, '_hit_test_gizmo_for_event', None)
                        if resolver is not None:
                            click_g_hit, _click_area, _click_region, _click_mx, _click_my, _click_tool_active = resolver(context, event, accept_exact_hover=True)
                    except Exception:
                        click_g_hit = None
                    if not click_g_hit:
                        try:
                            click_g_hit = c_gizmo._hit_test_gizmo(self.start_x, self.start_y, context)
                        except Exception:
                            click_g_hit = None
                    if click_g_hit:
                        _clear_smart_gizmo_drag_state()
                        return {'FINISHED'}
            except Exception:
                pass

            try:
                is_edit_mesh_mode = (
                    self.mode == 'EDIT_MESH'
                    and getattr(context, 'active_object', None) is not None
                    and getattr(context.active_object, 'type', None) == 'MESH'
                )
            except Exception:
                is_edit_mesh_mode = False
            if is_edit_mesh_mode and not bool(getattr(event, 'alt', False)):
                try:
                    click_target_obj, click_hit = cu._hit_test_editmesh_any(context, context.active_object, self.start_x, self.start_y)
                except Exception:
                    click_target_obj, click_hit = None, None
                if click_hit is not None:
                    applied = self._apply_click_selection_mode(context, click_mode, click_hit, click_target_obj)
                    if not applied:
                        applied = self._apply_click_selection_mode_native_fallback(context, click_mode)
                    _clear_smart_gizmo_drag_state()
                    return {'FINISHED'}

                try:
                    definitely_bg = bool(cu._editmesh_click_definitely_background(context, context.active_object, self.start_x, self.start_y))
                except Exception:
                    definitely_bg = False

                # Edge mode and face-dot mode both use strict Smart Transform hit
                # radii.  Do not let the follow-up native CLICK select with
                # Blender's wider internal tolerance.  In face mode this is the
                # critical path that otherwise selects the polygon area even when
                # the user clicked away from the center dot.
                strict_component_mode = self._editmesh_edge_mode_active(context) or self._editmesh_face_mode_active(context)
                if strict_component_mode:
                    if not definitely_bg:
                        try:
                            if (
                                self._editmesh_face_mode_active(context)
                                and self.enable_bg_deselect
                                and click_mode not in {'ADD', 'SUB', 'XOR'}
                                and not bool(getattr(event, 'shift', False))
                                and not bool(getattr(event, 'ctrl', False))
                            ):
                                cu._deselect_all(context)
                        except Exception:
                            pass
                        _clear_smart_gizmo_drag_state()
                        return {'FINISHED'}
                    if click_mode in {'ADD', 'SUB', 'XOR'}:
                        _clear_smart_gizmo_drag_state()
                        return {'FINISHED'}
            return {'PASS_THROUGH'}

        if transform_route_active and prefs.enable_smart_gizmo_style and prefs.gizmo_toggle_state:
            g_hit = None
            hit_area = getattr(context, 'area', None)
            hit_region = getattr(context, 'region', None)
            hit_mx = self.start_x
            hit_my = self.start_y
            try:
                resolver = getattr(c_gizmo, '_hit_test_gizmo_for_event', None)
                if resolver is not None:
                    g_hit, hit_area, hit_region, hit_mx, hit_my, _tool_active = resolver(context, event, accept_exact_hover=True)
            except Exception:
                g_hit = None
            if not g_hit:
                try:
                    g_hit = c_gizmo._hit_test_gizmo(self.start_x, self.start_y, context)
                except Exception:
                    g_hit = None
            if g_hit:
                # Smart Gizmo hover has priority over element hover behind the handle.
                # On the Smart Gizmo itself, Shift and Ctrl belong to Smart G-R-S
                # (precision and numeric snap).  Only Alt/OSKey should pass
                # through to navigation / operating-system shortcuts.
                if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
                    try:
                        _restore_native_view3d_selection_routes(context)
                    except Exception:
                        pass
                    return {'PASS_THROUGH'}
                self.gizmo_hit_id = g_hit
                self.hit_gizmo = True
                try:
                    if hit_area is not None and hit_region is not None:
                        self._sts_event_area = hit_area
                        self._sts_event_region = hit_region
                except Exception:
                    pass
                try:
                    self.start_x = int(hit_mx)
                    self.start_y = int(hit_my)
                except Exception:
                    pass
                cg._CSDT_DRAG_ACTIVE_ID = g_hit
                try:
                    c_gizmo._update_gizmo_cache(context, hit_area, hit_region)
                except Exception:
                    try:
                        c_gizmo._update_gizmo_cache(context, context.area, context.region)
                    except Exception:
                        pass
                cg._SMART_GIZMO_LOCKED_ID = g_hit
                if bool(getattr(self, '_click_fallback_event', False)):
                    _clear_smart_gizmo_drag_state()
                    return {'FINISHED'}
                
                context.window_manager.modal_handler_add(self)
                return {'RUNNING_MODAL'}

        # Continue into the hit-test path for transform tools and selection tools.
        # Element hits must select and may continue into held-drag transform; only
        # true background presses are routed to Box / Circle / Lasso selection.
        # This runs after the Smart Gizmo hit-test so an overlapping handle is never
        # stolen by an element behind it.
        try:
            if bool(self.use_immediate_select) and not bool(getattr(event, 'alt', False)) and not bool(getattr(event, 'oskey', False)):
                self._pre_hit_object, self._pre_hit_result = self._resolve_click_target_for_immediate_select(context, self.start_x, self.start_y, event=event)
                self._pre_hit_valid = self._pre_hit_result is not None
                self._pre_hit_attempted = True
                self._pre_hit_overrides_gizmo = False
        except Exception:
            self._pre_hit_object = None
            self._pre_hit_result = None
            self._pre_hit_valid = False
            self._pre_hit_attempted = True
            self._pre_hit_overrides_gizmo = False

        obj = context.active_object
        hit = None
        hit_object = obj
        pre_hit_attempted = bool(getattr(self, '_pre_hit_attempted', False))
        if pre_hit_attempted:
            # Immediate Select has already performed the exact configured-radius
            # component probe once.  Reuse even a miss; re-running the same probe
            # on PRESS is the main source of the small click lag and can race the
            # follow-up CLICK route on dense meshes.
            hit_object = getattr(self, '_pre_hit_object', obj) or obj
            hit = getattr(self, '_pre_hit_result', None)
            if hit is None and self.enable_bg_drag_select:
                try:
                    if self.mode == "EDIT_MESH" and obj and obj.type == 'MESH' and cu._editmesh_click_definitely_background(context, obj, self.start_x, self.start_y):
                        self._bg_fast_background = True
                    elif self.mode == "EDIT_LATTICE" and obj and obj.type == 'LATTICE' and cu._editlattice_click_definitely_background(context, obj, self.start_x, self.start_y):
                        self._bg_fast_background = True
                    elif self.mode in {"EDIT_CURVE", "EDIT_SURFACE"} and obj and obj.type in {'CURVE', 'SURFACE'} and cu._editcurve_click_definitely_background(context, obj, self.start_x, self.start_y):
                        self._bg_fast_background = True
                except Exception:
                    pass
        else:
            if self.mode == "OBJECT":
                hit = self._hit_test_object_with_hover_provider(context, self.start_x, self.start_y, event)
                if hit is not None:
                    hit_object = hit[0]
            elif self.mode == "EDIT_MESH" and obj and obj.type == 'MESH':
                # Component hits must win over background-selection routing.  The fast
                # background test is only allowed after the precise element probe fails;
                # otherwise clicks inside vertex/edge/face hit ranges can incorrectly
                # become Box / Circle / Lasso selection.
                hit_object, hit = cu._hit_test_editmesh_any(context, obj, self.start_x, self.start_y)
                if hit is None and self.enable_bg_drag_select and cu._editmesh_click_definitely_background(context, obj, self.start_x, self.start_y):
                    self._bg_fast_background = True
                    hit = None
            elif self.mode == "EDIT_LATTICE" and obj and obj.type == 'LATTICE':
                hit_object, hit = cu._hit_test_editlattice_any(context, obj, self.start_x, self.start_y)
                if hit is None and self.enable_bg_drag_select and cu._editlattice_click_definitely_background(context, obj, self.start_x, self.start_y):
                    self._bg_fast_background = True
                    hit = None
            elif self.mode in {"EDIT_CURVE", "EDIT_SURFACE"} and obj and obj.type in {'CURVE', 'SURFACE'}:
                hit_object, hit = cu._hit_test_editcurve_any(context, obj, self.start_x, self.start_y)
                if hit is None and self.enable_bg_drag_select and cu._editcurve_click_definitely_background(context, obj, self.start_x, self.start_y):
                    self._bg_fast_background = True
                    hit = None

        self.hit_object = hit_object
        self.hit_result = hit  # 当たった要素を保存
        self.hit_already_selected = False
        if hit is not None:
            if self.mode == "OBJECT":
                self.hit_already_selected = hit[1]
            else:
                self.hit_already_selected = hit[2]

        self.hit_empty = (hit is None)
        self.initial_selection_done = False
        self._edge_click_selection_forced = False
        # Element picking is now governed strictly by the configured hit ranges
        # (Vertex / Edge Hit Radius).  If the exact add-on hit test misses, do not
        # fall back to Blender's native click selector, because its internal pick
        # tolerance can select an edge outside the user's configured range.
        self._defer_edge_native_click = False

        if self._editmesh_edge_mode_hit(context, hit):
            mode = str(getattr(self, '_initial_selection_mode', '') or self._selection_mode_from_event(event)).upper()
            self._edge_click_selection_forced = self._apply_edge_mode_click_selection(context, event, hit, self.hit_object)
            if bool(getattr(self, '_edge_click_selection_forced', False)):
                self.initial_selection_done = True
                # Consume the matching CLICK that Blender can emit after this PRESS.
                # This is required for plain SET as well as Shift/Ctrl variants,
                # because the native Mesh/Tweak route may otherwise run a second
                # selection pass with Blender's own modifier semantics.
                _remember_direct_selection_click(context, mode, self.start_x, self.start_y)
            if mode in {'ADD', 'SUB', 'XOR'}:
                _clear_smart_gizmo_drag_state()
                if bool(getattr(self, '_click_fallback_event', False)):
                    return {'FINISHED'}
                return self._begin_direct_selection_release_guard(context)

        if modifier_event:
            if addsub_modifier_event and not self.hit_empty:
                # Blender's native single-click Select/Tweak keymap uses Shift as
                # toggle and Ctrl for center/shortest-path routes.  Smart Transform
                # requires stable component selection semantics in edge mode: plain
                # click = SET, Shift = ADD, Ctrl = SUB.  Apply those modes directly
                # for real element hits so stale/native keymap priority cannot swap
                # the meaning of the modifiers.
                mode = str(getattr(self, '_initial_selection_mode', '') or self._selection_mode_from_event(event))
                applied = self._apply_click_selection_mode(context, mode, hit, self.hit_object)
                if not applied:
                    applied = self._apply_click_selection_mode_native_fallback(context, mode)
                self.initial_selection_done = bool(applied)
                _remember_direct_selection_click(context, mode, self.start_x, self.start_y)
                _clear_smart_gizmo_drag_state()
                # Even if the direct route failed, do not PASS_THROUGH to Blender's
                # Shift/Ctrl click keymap for a confirmed element hit; that is the
                # exact path that turns Shift into toggle and Ctrl into a native
                # center/shortest-path action.
                if bool(getattr(self, '_click_fallback_event', False)):
                    return {'FINISHED'}
                return self._begin_direct_selection_release_guard(context)
            allow_modifier_background_drag = bool(
                addsub_modifier_event
                and self.hit_empty
                and self.enable_bg_drag_select
                and str(getattr(self, '_bg_select_tool_id', '') or '').strip() in {
                    'builtin.select_box',
                    'builtin.select_circle',
                    'builtin.select_lasso',
                }
            )
            if bool(getattr(self, '_defer_edge_native_click', False)):
                context.window_manager.modal_handler_add(self)
                return {'RUNNING_MODAL'}
            if not allow_modifier_background_drag:
                if self._editmesh_edge_mode_active(context) and addsub_modifier_event:
                    context.window_manager.modal_handler_add(self)
                    return {'RUNNING_MODAL'}
                try:
                    _restore_native_view3d_selection_routes(context)
                except Exception:
                    pass
                return {'PASS_THROUGH'}
            self._bg_modifier_event = True

        try:
            is_plain_edge_select_press = (
                not modifier_event
                and not bool(getattr(self, '_edge_click_selection_forced', False))
                and self._editmesh_edge_mode_hit(context, hit)
                and active_tool_id in select_tool_ids
                and getattr(hit_object, 'type', None) == 'MESH'
            )
        except Exception:
            is_plain_edge_select_press = False
        if is_plain_edge_select_press:
            mode = str(getattr(self, '_initial_selection_mode', '') or 'SET')
            applied = self._apply_click_selection_mode(context, mode, hit, hit_object)
            if not applied:
                applied = self._apply_click_selection_mode_native_fallback(context, mode)
            self.initial_selection_done = bool(applied)
            _remember_direct_selection_click(context, mode, self.start_x, self.start_y)
            # Immediate Select must remain modal after the press so the same held
            # mouse gesture can cross the drag threshold and start Smart G-R-S.
            # Finishing here makes the feature appear disabled in edge mode.
            if bool(getattr(self, 'use_immediate_select', False)) and bool(getattr(self, 'enable_drag_transform', False)):
                try:
                    cu._invalidate_gizmo_cache()
                except Exception:
                    pass
            else:
                _clear_smart_gizmo_drag_state()
                return self._begin_direct_selection_release_guard(context)

        # Empty-background drags must become responsive before any expensive
        # deselect/select work runs.  Start a zero-size local box preview at the
        # original press coordinate and defer click-to-clear until release.
        if (
            not bool(getattr(self, '_click_fallback_event', False))
            and self.hit_empty
            and not bool(getattr(self, '_defer_edge_native_click', False))
            and self.enable_bg_drag_select
            and str(getattr(self, '_bg_select_tool_id', '') or '') in {
                "builtin.select_box",
                "builtin.select_lasso",
            }
        ):
            if self._start_native_background_region_select(context, event):
                return self._begin_native_background_release_guard(context)
            self._start_background_box_preview(context, event)

        if self.use_immediate_select and not bool(getattr(self, '_edge_click_selection_forced', False)):
            if self.hit_empty:
                if self.enable_bg_deselect and not self.enable_bg_drag_select:
                    if not event.shift and not event.ctrl:
                        cu._deselect_all(context)
            else:
                is_multi_modifier = event.shift or event.ctrl
                if is_multi_modifier:
                    mode = str(getattr(self, '_initial_selection_mode', '') or self._selection_mode_from_event(event))
                    applied = self._apply_click_selection_mode(context, mode, hit, self.hit_object)
                    if not applied:
                        applied = self._apply_click_selection_mode_native_fallback(context, mode)
                    self.initial_selection_done = bool(applied)
                    _remember_direct_selection_click(context, mode, self.start_x, self.start_y)
                    _clear_smart_gizmo_drag_state()
                    return self._begin_direct_selection_release_guard(context)

                applied = False
                if not self.hit_already_selected:
                    applied = self._apply_single_click_selection(context, hit, self.hit_object)
                else:
                    sel_count = cu._selection_count(context)
                    if (not self.keep_multi_selection) or sel_count <= 1:
                        applied = self._apply_single_click_selection(context, hit, self.hit_object)
                    elif self.update_active_element:
                        applied = self._apply_active_only_click_selection(context, hit, self.hit_object)
                    else:
                        applied = True
                self.initial_selection_done = bool(applied)

        if bool(getattr(self, '_click_fallback_event', False)):
            if bool(getattr(self, '_defer_edge_native_click', False)):
                try:
                    if self.enable_bg_deselect and not bool(getattr(event, 'shift', False)) and not bool(getattr(event, 'ctrl', False)):
                        cu._deselect_all(context)
                except Exception:
                    pass
                _clear_smart_gizmo_drag_state()
                return {'FINISHED'}
            if self.hit_empty:
                if self.enable_bg_deselect and not bool(getattr(self, '_bg_modifier_event', False)):
                    try:
                        if not bool(getattr(event, 'shift', False)) and not bool(getattr(event, 'ctrl', False)):
                            cu._deselect_all(context)
                    except Exception:
                        pass
            elif not self.initial_selection_done:
                try:
                    self._apply_single_click_selection(context, hit, self.hit_object)
                    self.initial_selection_done = True
                except Exception:
                    pass
            _clear_smart_gizmo_drag_state()
            return {'FINISHED'}

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if bool(getattr(self, '_native_bg_release_guard', False)):
            event_type = str(getattr(event, 'type', '') or '').upper()
            event_value = str(getattr(event, 'value', '') or '').upper()
            if event_type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                try:
                    if self._drag_distance(event) >= max(1, int(getattr(self, 'drag_threshold', 1))):
                        self._native_bg_drag_confirmed = True
                except Exception:
                    pass
                _ssg_select_through_touch(getattr(self, '_ssg_select_through_token', None))
                return {'PASS_THROUGH'}
            if event_type == 'LEFTMOUSE' and event_value in {'RELEASE', 'CLICK', 'DOUBLE_CLICK'}:
                try:
                    if self._drag_distance(event) >= max(1, int(getattr(self, 'drag_threshold', 1))):
                        self._native_bg_drag_confirmed = True
                except Exception:
                    pass
                self._native_bg_click_should_deselect = bool(
                    not bool(getattr(self, '_native_bg_drag_confirmed', False))
                    and bool(getattr(self, 'enable_bg_deselect', False))
                    and not bool(getattr(self, '_bg_modifier_event', False))
                    and str(getattr(self, '_initial_selection_mode', 'SET') or 'SET').upper() == 'SET'
                )
                try:
                    _ssg_select_through_finish(
                        getattr(self, '_ssg_select_through_token', None),
                        cancelled=False,
                        delay=0.06,
                    )
                except Exception:
                    pass
                self._ssg_select_through_token = None
                self._native_bg_release_seen = True
                try:
                    wm = getattr(context, 'window_manager', None)
                    win = getattr(context, 'window', None)
                    if wm is not None and getattr(self, '_native_bg_release_timer', None) is None:
                        self._native_bg_release_timer = wm.event_timer_add(0.02, window=win)
                except Exception:
                    pass
                # The native Box/Lasso modal must receive the same release event
                # after this guard records it, otherwise its visible frame would
                # remain active and the selection would never be confirmed.
                return {'PASS_THROUGH'}
            if event_type in {'RIGHTMOUSE', 'ESC'} and event_value in {'PRESS', 'RELEASE', 'CLICK', ''}:
                try:
                    _ssg_select_through_finish(
                        getattr(self, '_ssg_select_through_token', None),
                        cancelled=True,
                        delay=0.01,
                    )
                except Exception:
                    pass
                self._ssg_select_through_token = None
                self._native_bg_release_cancelled = True
                self._native_bg_release_seen = True
                try:
                    wm = getattr(context, 'window_manager', None)
                    win = getattr(context, 'window', None)
                    if wm is not None and getattr(self, '_native_bg_release_timer', None) is None:
                        self._native_bg_release_timer = wm.event_timer_add(0.02, window=win)
                except Exception:
                    pass
                return {'PASS_THROUGH'}
            if event_type == 'TIMER' and bool(getattr(self, '_native_bg_release_seen', False)):
                return self._finish_native_background_release_guard(context)
            return {'PASS_THROUGH'}

        if bool(getattr(self, '_direct_selection_release_guard', False)):
            if event.type == 'LEFTMOUSE' and str(getattr(event, 'value', '') or '').upper() in {'CLICK', 'DOUBLE_CLICK'}:
                return self._finish_direct_selection_guard(context, cancelled=False)
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                self._direct_selection_release_seen = True
                try:
                    wm = getattr(context, 'window_manager', None)
                    win = getattr(context, 'window', None)
                    if wm is not None and getattr(self, '_direct_selection_guard_timer', None) is None:
                        self._direct_selection_guard_timer = wm.event_timer_add(float(_CSDT_DIRECT_SELECT_MODAL_GRACE), window=win)
                except Exception:
                    return self._finish_direct_selection_guard(context, cancelled=False)
                return {'RUNNING_MODAL'}
            if event.type == 'TIMER' and bool(getattr(self, '_direct_selection_release_seen', False)):
                return self._finish_direct_selection_guard(context, cancelled=False)
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                return self._finish_direct_selection_guard(context, cancelled=True)
            return {'RUNNING_MODAL'}

        if self.passed_through:
            self._remove_background_box_preview(context)
            _clear_smart_gizmo_drag_state()
            return {'FINISHED'}

        if bool(getattr(self, '_bg_box_preview', False)):
            if event.type == 'MOUSEMOVE':
                self._update_background_box_preview(context, event)
                return {'RUNNING_MODAL'}
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
                selected_by_box = self._finish_background_box_select(context, event)
                if not selected_by_box and self.enable_bg_deselect and not bool(getattr(self, '_bg_modifier_event', False)):
                    try:
                        cu._deselect_all(context)
                    except Exception:
                        pass
                _clear_smart_gizmo_drag_state()
                return {'FINISHED'}
            if event.type in {'RIGHTMOUSE', 'ESC'}:
                _ssg_select_through_finish(getattr(self, '_ssg_select_through_token', None), cancelled=True, delay=0.01)
                self._ssg_select_through_token = None
                self._remove_background_box_preview(context)
                _clear_smart_gizmo_drag_state()
                return {'CANCELLED'}
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if bool(getattr(self, '_deferred_gizmo_click_select', False)) and getattr(self, '_sts_press_mouse_window', None) is not None:
                try:
                    dx = int(getattr(event, 'mouse_x', 0)) - int(self._sts_press_mouse_window[0])
                    dy = int(getattr(event, 'mouse_y', 0)) - int(self._sts_press_mouse_window[1])
                except Exception:
                    dx = event.mouse_region_x - self.start_x
                    dy = event.mouse_region_y - self.start_y
            else:
                dx = event.mouse_region_x - self.start_x
                dy = event.mouse_region_y - self.start_y
            if not self.drag_started and math.hypot(dx, dy) >= self.drag_threshold:
                self.drag_started = True
                cg._CSDT_IS_DRAGGING = True

                if self.hit_gizmo:
                    self._deferred_gizmo_click_select = False
                    cg._CSDT_DRAG_ACTIVE_ID = self.gizmo_hit_id
                    cg._SMART_GIZMO_LOCKED_ID = self.gizmo_hit_id
                    self._start_transform(context, event, from_gizmo=True)
                    cg._SMART_GIZMO_LOCKED_ID = None
                    return {'FINISHED'}

                if self.hit_empty:
                    if self.enable_bg_drag_select:
                        bg_tool_id = str(getattr(self, '_bg_select_tool_id', '') or '').strip()
                        if bg_tool_id == "builtin.select_box":
                            # Fallback path: keep the original click coordinate and
                            # avoid invoking Blender's wait-for-input modal after the
                            # cursor has already moved.
                            self._start_background_box_preview(context, event)
                            self._update_background_box_preview(context, event)
                            return {'RUNNING_MODAL'}
                        if bg_tool_id == "builtin.select_lasso":
                            # The complete lasso path must include the original
                            # background press.  Starting Blender's modal lasso
                            # only after the threshold drops that path segment and
                            # makes fast drags invisible or empty.
                            self._start_background_box_preview(context, event)
                            self._update_background_box_preview(context, event)
                            return {'RUNNING_MODAL'}
                        if bg_tool_id == "builtin.select_circle":
                            try:
                                mode = str(getattr(self, '_initial_selection_mode', '') or self._selection_mode_from_event(event))
                                cu._dispatch_selection_tool(context, mode=mode, prefer_wait_for_input=True, tool_id=bg_tool_id)
                            except Exception:
                                pass
                            _clear_smart_gizmo_drag_state()
                            return {'FINISHED'}
                        self.passed_through = True
                        _clear_smart_gizmo_drag_state()
                        return {'PASS_THROUGH'}
                    else:
                        self.passed_through = True
                        _clear_smart_gizmo_drag_state()
                        return {'PASS_THROUGH'}
                else:
                    if not self.enable_drag_transform:
                        self.passed_through = True
                        _clear_smart_gizmo_drag_state()
                        return {'PASS_THROUGH'}

                    if not self.use_immediate_select and not self.initial_selection_done:
                        is_multi_modifier = event.shift or event.ctrl
                        if not is_multi_modifier:
                            if not self.hit_already_selected or not self.keep_multi_selection:
                                target_obj, hit = self._hit_test_current_mode(context, self.start_x, self.start_y)
                                if hit:
                                    self._apply_single_click_selection(context, hit, target_obj)

                    try:
                        if str(getattr(context, 'mode', '') or '') == 'OBJECT':
                            context.view_layer.update()
                    except Exception:
                        pass
                    self._start_transform(context, event, from_gizmo=False)
                    cg._SMART_GIZMO_LOCKED_ID = None
                    return {'FINISHED'}

        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            _clear_smart_gizmo_drag_state()
            if not self.drag_started:
                if self.hit_gizmo:
                    if bool(getattr(self, '_deferred_gizmo_click_select', False)):
                        self._commit_deferred_gizmo_click_select(context)
                        return self._begin_deferred_gizmo_release_guard(context)
                    return {'FINISHED'}

                if bool(getattr(self, '_defer_edge_native_click', False)):
                    try:
                        if self.enable_bg_deselect and not bool(getattr(event, 'shift', False)) and not bool(getattr(event, 'ctrl', False)):
                            cu._deselect_all(context)
                    except Exception:
                        pass
                    return {'FINISHED'}

                is_multi_modifier = event.shift or event.ctrl
                if is_multi_modifier:
                    return {'FINISHED'}

                if self.hit_empty:
                    if self.enable_bg_deselect and not bool(getattr(self, '_bg_modifier_event', False)):
                        try:
                            cu._deselect_all(context)
                        except Exception:
                            pass
                    return {'FINISHED'}

                # On a click release without dragging, update the active target when the hit item was already selected.
                if self.use_immediate_select and self.hit_already_selected and not self.hit_empty:
                    hit = self.hit_result
                    if hit and self.keep_multi_selection:
                        self._apply_single_click_selection(context, hit, self.hit_object)
                        cu._invalidate_gizmo_cache()

                if not self.use_immediate_select and not self.initial_selection_done:
                    if self.hit_empty:
                        if self.enable_bg_deselect:
                            cu._deselect_all(context)
                    else:
                        target_obj, hit = self._hit_test_current_mode(context, self.start_x, self.start_y)
                        if hit:
                            self._apply_single_click_selection(context, hit, target_obj)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            self._deferred_gizmo_click_select = False
            _clear_smart_gizmo_drag_state()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _start_transform(self, context, event, from_gizmo=False):
        prefs = cu._prefs()
        kwargs = {"release_confirm": True}

        def _invoke_smart_grs(mode_name, pending=None, *, force_screen_rotation=False, force_circular_rotation=False, force_positive_scale=False, force_allow_negative_scale=False, force_free_rotation=False, smart_gizmo_axes=None, smart_gizmo_space='', smart_gizmo_hit_id='', orientation_payload=None):
            pending = dict(pending or {})
            try:
                dn = getattr(bpy.app, 'driver_namespace', None)
                if isinstance(dn, dict):
                    if pending:
                        dn['STS_PENDING_GRS'] = pending
                    if orientation_payload is not None:
                        try:
                            axes_payload = orientation_payload.get('axes', None) if isinstance(orientation_payload, dict) else None
                            space_payload = str(orientation_payload.get('space', '') or pending.get('space', 'GLOBAL') or 'GLOBAL') if isinstance(orientation_payload, dict) else str(pending.get('space', 'GLOBAL') or 'GLOBAL')
                            if axes_payload is not None:
                                dn['STS_GRS_GIZMO_ORIENT_AXES'] = axes_payload
                                dn['STS_GRS_GIZMO_ORIENT_SPACE'] = space_payload
                                dn['STS_PENDING_GRS_ORIENT_AXES'] = axes_payload
                                dn['STS_PENDING_GRS_ORIENT_SPACE'] = space_payload
                                if 'matrix' in orientation_payload:
                                    dn['STS_PENDING_GRS_ORIENT_MATRIX'] = orientation_payload.get('matrix')
                                if 'pivot' in orientation_payload:
                                    dn['STS_PENDING_GRS_PIVOT'] = orientation_payload.get('pivot')
                                if orientation_payload.get('dynamic_view'):
                                    dn['STS_PENDING_GRS_ORIENT_DYNAMIC_VIEW'] = True
                                    dn['STS_GRS_GIZMO_DYNAMIC_VIEW'] = True
                                if 'view_signature' in orientation_payload:
                                    dn['STS_PENDING_GRS_ORIENT_VIEW_SIGNATURE'] = orientation_payload.get('view_signature')
                                if pending is not None:
                                    pending['space'] = space_payload
                        except Exception:
                            pass
                    if smart_gizmo_axes is not None:
                        dn['STS_GRS_FROM_SMART_GIZMO'] = True
                        dn['STS_GRS_GIZMO_HIT_ID'] = str(smart_gizmo_hit_id or '')
                        dn['STS_GRS_GIZMO_ORIENT_AXES'] = smart_gizmo_axes
                        dn['STS_GRS_GIZMO_ORIENT_SPACE'] = str(smart_gizmo_space or pending.get('space', 'GLOBAL') or 'GLOBAL')
                    if force_screen_rotation:
                        dn['STS_GRS_FORCE_SCREEN_COORDINATE_ROTATION'] = True
                    if force_circular_rotation:
                        dn['STS_GRS_FORCE_CIRCULAR_ROTATION'] = True
                    if force_positive_scale:
                        dn['STS_GRS_FORCE_POSITIVE_SCALE'] = True
                    if force_allow_negative_scale:
                        dn['STS_GRS_FORCE_ALLOW_NEGATIVE_SCALE'] = True
                    if force_free_rotation:
                        dn['STS_GRS_FORCE_FREE_ROTATION'] = True
            except Exception:
                pass
            area = getattr(self, '_sts_event_area', None)
            region = getattr(self, '_sts_event_region', None)
            if area is None or region is None:
                area, region = cu._get_view3d_area_region(context)
            window = getattr(context, 'window', None)
            override = {}
            if window is not None:
                override['window'] = window
            if area is not None:
                override['area'] = area
                try:
                    override['space_data'] = area.spaces.active
                except Exception:
                    pass
            if region is not None:
                override['region'] = region
            try:
                rv3d = getattr(self, '_sts_event_rv3d', None) or cu._view3d_region_data(area, region)
                if rv3d is not None:
                    override['region_data'] = rv3d
            except Exception:
                pass
            try:
                bpy.app.driver_namespace['STS_PENDING_GRS_CTX'] = {
                    'window': window,
                    'area': area,
                    'region': region,
                    'region_data': getattr(self, '_sts_event_rv3d', None) or cu._view3d_region_data(area, region),
                }
            except Exception:
                pass
            try:
                # Smart G-R-S is invoked only after the drag threshold is crossed.
                # Keep both the original press coordinate and the current held-drag
                # coordinate so immediate select can continue into transform without
                # losing the first drag segment.
                dn = getattr(bpy.app, 'driver_namespace', None)
                if isinstance(dn, dict):
                    sx = int(getattr(self, 'start_x', getattr(event, 'mouse_region_x', 0)))
                    sy = int(getattr(self, 'start_y', getattr(event, 'mouse_region_y', 0)))
                    try:
                        cx, cy = self._event_region_xy(event)
                    except Exception:
                        cx = int(getattr(event, 'mouse_region_x', sx))
                        cy = int(getattr(event, 'mouse_region_y', sy))
                    dn['STS_PENDING_GRS_START_MOUSE'] = (sx, sy)
                    dn['STS_PENDING_GRS_INVOKE_MOUSE'] = (cx, cy)
            except Exception:
                pass
            smart_kwargs = dict(kwargs)
            try:
                if override:
                    with bpy.context.temp_override(**override):
                        return bpy.ops.transform.smart_grs_transform('INVOKE_REGION_WIN', mode=mode_name, **smart_kwargs)
            except Exception:
                pass
            return bpy.ops.transform.smart_grs_transform('INVOKE_DEFAULT', mode=mode_name, **smart_kwargs)

        def _invoke_native_transform(mode_name, pending=None, orient='GLOBAL'):
            pending = dict(pending or {})
            try:
                affect_only_state = cu._effective_transform_affect_only_state(context)
            except Exception:
                affect_only_state = {}
            native_kwargs = dict(kwargs)
            try:
                for _k, _v in (cu._native_transform_context_kwargs(context, mode_name) or {}).items():
                    if _k not in native_kwargs:
                        native_kwargs[_k] = _v
            except Exception:
                pass
            free_rotation_native = bool(cu._pending_requests_free_rotation(mode_name, pending))
            if not free_rotation_native:
                if pending.get('kind') == 'AXIS' and pending.get('idx') in (0, 1, 2):
                    ax = [False, False, False]
                    ax[int(pending['idx'])] = True
                    native_kwargs['constraint_axis'] = tuple(ax)
                elif pending.get('kind') == 'PLANE' and pending.get('idx') in (0, 1, 2):
                    ax = [True, True, True]
                    ax[int(pending['idx'])] = False
                    native_kwargs['constraint_axis'] = tuple(ax)

                orient_native = str(orient or 'GLOBAL')
                if orient_native == 'WORKPLANE':
                    orient_native = 'VIEW'
                if orient_native not in {'GLOBAL', 'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT'}:
                    orient_native = 'GLOBAL'
                if orient_native != 'GLOBAL':
                    native_kwargs['orient_type'] = orient_native

            area = getattr(self, '_sts_event_area', None)
            region = getattr(self, '_sts_event_region', None)
            if area is None or region is None:
                area, region = cu._get_view3d_area_region(context)
            window = getattr(context, 'window', None)
            override = {}
            if window is not None:
                override['window'] = window
            if area is not None:
                override['area'] = area
                try:
                    override['space_data'] = area.spaces.active
                except Exception:
                    pass
            if region is not None:
                override['region'] = region
            try:
                rv3d = getattr(self, '_sts_event_rv3d', None) or cu._view3d_region_data(area, region)
                if rv3d is not None:
                    override['region_data'] = rv3d
            except Exception:
                pass

            def _call(op_context='INVOKE_DEFAULT'):
                with cu._temporary_transform_affect_only_state(bpy.context, affect_only_state):
                    if mode_name == 'R':
                        if free_rotation_native:
                            return bpy.ops.transform.trackball(op_context, **cu._native_trackball_kwargs(native_kwargs))
                        return bpy.ops.transform.rotate(op_context, **native_kwargs)
                    if mode_name == 'S':
                        return bpy.ops.transform.resize(op_context, **native_kwargs)
                    return bpy.ops.transform.translate(op_context, **native_kwargs)

            if override:
                try:
                    with bpy.context.temp_override(**override):
                        return _call('INVOKE_REGION_WIN')
                except Exception:
                    pass
            return _call('INVOKE_DEFAULT')

        def _pending_from_constraint_axis(axis_tuple, orient='GLOBAL'):
            try:
                vals = [bool(v) for v in axis_tuple]
            except Exception:
                vals = []
            if len(vals) != 3:
                return None
            count = sum(1 for v in vals if v)
            if count == 1:
                return {'kind': 'AXIS', 'idx': vals.index(True), 'space': orient}
            if count == 2:
                return {'kind': 'PLANE', 'idx': vals.index(False), 'space': orient}
            return None

        if from_gizmo and self.gizmo_hit_id:
            gid = self.gizmo_hit_id
            mode = 'G'
            pending = {'kind': 'NONE', 'idx': -1, 'space': 'GLOBAL'}

            if gid.startswith('ROT_'):
                mode = 'R'
            elif gid.startswith('SCALE_'):
                mode = 'S'

            if gid in {'MOVE_X', 'ROT_X', 'SCALE_X'}:
                pending = {'kind': 'AXIS', 'idx': 0}
            elif gid in {'MOVE_Y', 'ROT_Y', 'SCALE_Y'}:
                pending = {'kind': 'AXIS', 'idx': 1}
            elif gid in {'MOVE_Z', 'ROT_Z', 'SCALE_Z'}:
                pending = {'kind': 'AXIS', 'idx': 2}
            elif gid in {'MOVE_XY', 'SCALE_XY'}:
                pending = {'kind': 'PLANE', 'idx': 2}
            elif gid in {'MOVE_YZ', 'SCALE_YZ'}:
                pending = {'kind': 'PLANE', 'idx': 0}
            elif gid in {'MOVE_XZ', 'SCALE_XZ'}:
                pending = {'kind': 'PLANE', 'idx': 1}
            elif gid == 'ROT_VIEW':
                pending = {'kind': 'NONE', 'idx': -1}
            elif gid in {'MOVE_CENTER', 'SCALE_UNIFORM'}:
                pending = {'kind': 'FREE', 'idx': -1}
            elif str(gid).startswith('ROT_FREE'):
                free_idx = {'ROT_FREE_X': 0, 'ROT_FREE_Y': 1, 'ROT_FREE_Z': 2}.get(str(gid), -1)
                pending = {'kind': 'FREE', 'idx': free_idx}

            try:
                orient = c_gizmo._smart_get_orient_type(context)
            except Exception:
                orient = cg._SMART_GIZMO_CACHE.get("orient_mode", 'GLOBAL')
            valid_orients = {'GLOBAL', 'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT', 'WORKPLANE'}
            if not orient:
                orient = 'GLOBAL'
            elif orient not in valid_orients:
                # Custom orientation names are valid Blender transform spaces for
                # Smart G-R-S, even though they are not part of the fixed enum set.
                orient = str(orient)
            pending['space'] = orient
            exact_axes = None
            try:
                area_for_axes = getattr(self, '_sts_event_area', None)
                region_for_axes = getattr(self, '_sts_event_region', None)
                if area_for_axes is None or region_for_axes is None:
                    area_for_axes, region_for_axes = cu._get_view3d_area_region(context)
                if hasattr(c_gizmo, '_smart_gizmo_exact_axes_for_invoke'):
                    exact_axes = c_gizmo._smart_gizmo_exact_axes_for_invoke(context, area_for_axes, region_for_axes, rv3d_override=getattr(self, '_sts_event_rv3d', None))
                if exact_axes is not None:
                    orient = str(exact_axes[3] or orient or 'GLOBAL')
                    pending['space'] = orient
            except Exception:
                exact_axes = None

            try:
                bpy.ops.view3d.csdt_native_release_watch('INVOKE_DEFAULT')
            except Exception:
                pass

            if _gizmo_should_use_native_transform(context):
                try:
                    result = _invoke_native_transform(mode, pending, orient)
                    try:
                        if result and 'CANCELLED' not in result:
                            cu._remember_constraint_state_from_smart_gizmo_hit_id(gid)
                    except Exception:
                        pass
                except Exception:
                    pass
                return

            try:
                use_circular_rot = bool(getattr(prefs, 'smart_gizmo_use_circular_rotation', True)) if prefs else True
                block_negative_scale = bool(getattr(prefs, 'tool_disallow_negative_scale', True)) if prefs else True
                force_free_rotation = bool(str(gid).startswith('ROT_FREE'))
                gizmo_payload = None
                try:
                    if hasattr(c_gizmo, '_smart_gizmo_orientation_payload_for_grs'):
                        gizmo_payload = c_gizmo._smart_gizmo_orientation_payload_for_grs(
                            context,
                            area_for_axes,
                            region_for_axes,
                            rv3d_override=getattr(self, '_sts_event_rv3d', None),
                        )
                    if gizmo_payload is None and exact_axes is not None:
                        x, y, z = tuple(exact_axes[0]), tuple(exact_axes[1]), tuple(exact_axes[2])
                        gizmo_payload = {'space': orient, 'axes': (x, y, z)}
                        if orient in {'VIEW', 'WORKPLANE'}:
                            gizmo_payload['dynamic_view'] = True
                        if hasattr(c_gizmo, '_smart_remember_grs_orientation_payload'):
                            gizmo_payload = c_gizmo._smart_remember_grs_orientation_payload(gizmo_payload) or gizmo_payload
                    if isinstance(gizmo_payload, dict) and str(gizmo_payload.get('space', '') or '') in {'VIEW', 'WORKPLANE'}:
                        gizmo_payload['dynamic_view'] = True
                except Exception:
                    gizmo_payload = None
                _invoke_smart_grs(
                    mode,
                    pending,
                    force_screen_rotation=(mode == 'R' and (not use_circular_rot) and not force_free_rotation),
                    force_circular_rotation=(mode == 'R' and use_circular_rot and not force_free_rotation),
                    force_positive_scale=(mode == 'S' and block_negative_scale),
                    force_allow_negative_scale=(mode == 'S' and not block_negative_scale),
                    force_free_rotation=(mode == 'R' and force_free_rotation),
                    smart_gizmo_axes=(tuple(exact_axes[0]), tuple(exact_axes[1]), tuple(exact_axes[2])) if exact_axes is not None else None,
                    smart_gizmo_space=orient,
                    smart_gizmo_hit_id=gid,
                    orientation_payload=gizmo_payload,
                )
            except Exception:
                try:
                    _invoke_native_transform(mode, pending, orient)
                except Exception:
                    _invoke_smart_grs(mode, pending)
            return

        direct_orient_payload = None
        direct_orient = 'GLOBAL'
        try:
            area_for_axes = getattr(self, '_sts_event_area', None)
            region_for_axes = getattr(self, '_sts_event_region', None)
            if area_for_axes is None or region_for_axes is None:
                area_for_axes, region_for_axes = cu._get_view3d_area_region(context)
            if hasattr(c_gizmo, '_smart_orientation_payload_for_direct_grs'):
                force_fresh_axes = bool(getattr(self, 'initial_selection_done', False) or getattr(self, '_edge_click_selection_forced', False))
                direct_orient_payload = c_gizmo._smart_orientation_payload_for_direct_grs(context, area_for_axes, region_for_axes, force_fresh=force_fresh_axes, rv3d_override=getattr(self, '_sts_event_rv3d', None))
            if isinstance(direct_orient_payload, dict):
                direct_orient = str(direct_orient_payload.get('space', '') or c_gizmo._smart_get_orient_type(context) or 'GLOBAL')
            else:
                direct_orient = str(c_gizmo._smart_get_orient_type(context) or 'GLOBAL')
        except Exception:
            direct_orient_payload = None
            direct_orient = 'GLOBAL'

        pending_axis = None
        remembered_free_axis = False
        if prefs and prefs.enable_axis_memory:
            try:
                last_state = cu._get_last_constraint_state_for_tool(self.tool_id)
            except Exception:
                last_state = {'kind': 'NONE', 'idx': -1, 'axis': cu._get_last_constraint_for_tool(self.tool_id)}
            last_kind = str((last_state or {}).get('kind', 'NONE') or 'NONE').upper()
            if last_kind in {'AXIS', 'PLANE'}:
                last_axes = tuple(bool(v) for v in (last_state or {}).get('axis', (False, False, False)))
                if any(last_axes):
                    kwargs["constraint_axis"] = last_axes
                    pending_axis = _pending_from_constraint_axis(last_axes, direct_orient)
            elif last_kind == 'FREE':
                remembered_free_axis = True
                try:
                    free_idx = int((last_state or {}).get('idx', -1))
                except Exception:
                    free_idx = -1
                pending_axis = {'kind': 'FREE', 'idx': free_idx if free_idx in (0, 1, 2) else -1, 'space': direct_orient}

        if _gizmo_should_use_native_transform(context):
            native_mode = 'G'
            if self.tool_id == "builtin.rotate":
                native_mode = 'R'
            elif self.tool_id == "builtin.scale":
                native_mode = 'S'
            try:
                _invoke_native_transform(native_mode, pending_axis, direct_orient)
            except Exception:
                pass
            return

        if self.tool_id == "builtin.move":
            _invoke_smart_grs('G', pending_axis, orientation_payload=direct_orient_payload)
        elif self.tool_id == "builtin.rotate":
            use_circular_rot = bool(getattr(prefs, 'smart_gizmo_use_circular_rotation', True)) if prefs else True
            _invoke_smart_grs(
                'R',
                pending_axis,
                force_screen_rotation=((not use_circular_rot) and not remembered_free_axis),
                force_circular_rotation=(use_circular_rot and not remembered_free_axis),
                force_free_rotation=remembered_free_axis,
                orientation_payload=direct_orient_payload,
            )
        elif self.tool_id == "builtin.scale":
            block_negative_scale = bool(getattr(prefs, 'tool_disallow_negative_scale', True)) if prefs else True
            _invoke_smart_grs(
                'S',
                pending_axis,
                force_positive_scale=block_negative_scale,
                force_allow_negative_scale=(not block_negative_scale),
                orientation_payload=direct_orient_payload,
            )
        elif self.tool_id == "builtin.transform":
            # Transform tool move path also uses Smart G-R-S so immediate-select
            # drags inherit the same fixed coordinate-system axes as the gizmo.
            _invoke_smart_grs('G', pending_axis, orientation_payload=direct_orient_payload)
        else:
            _invoke_smart_grs('G', pending_axis, orientation_payload=direct_orient_payload)




class VIEW3D_OT_csdt_force(bpy.types.Operator):
    bl_idname = "view3d.csdt_force"
    bl_label = "Click Handler (Smart Gizmo Compatibility)"
    bl_description = "Compatibility click handler for older Smart Transform Suite keymaps. It uses the same Smart Gizmo hit path as the current click handler."
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    mode: bpy.props.StringProperty(name="Mode", default="", options={'HIDDEN'})
    action: bpy.props.StringProperty(name="Action", default="", options={'HIDDEN'})


class VIEW3D_OT_csdt_click_select_drag(bpy.types.Operator):
    bl_idname = "view3d.csdt_click_select_drag"
    bl_label = "Click Select Drag (Smart Gizmo Compatibility)"
    bl_description = "Compatibility click handler for older Smart Transform Suite keymaps. It uses the same Smart Gizmo hit path as the current click handler."
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    mode: bpy.props.StringProperty(name="Mode", default="", options={'HIDDEN'})
    action: bpy.props.StringProperty(name="Action", default="", options={'HIDDEN'})


# Keep the legacy RNA ids alive without subclassing a registered Operator class.
# Direct Operator subclassing caused Blender 5.1 to keep a stale RNA callback
# table on reload. Copying plain Python callbacks into legacy classes gives old
# keymaps a valid invoke/modal path while avoiding duplicate inheritance state.
for _legacy_cls in (VIEW3D_OT_csdt_force, VIEW3D_OT_csdt_click_select_drag):
    for _sts_name, _sts_value in tuple(VIEW3D_OT_sts_csdt_force.__dict__.items()):
        if _sts_name.startswith('__'):
            continue
        if _sts_name in {'bl_idname', 'bl_label', 'bl_description', 'bl_options', 'bl_rna', 'rna_type'}:
            continue
        if callable(_sts_value) or isinstance(_sts_value, (staticmethod, classmethod, property)):
            try:
                setattr(_legacy_cls, _sts_name, _sts_value)
            except Exception:
                pass


def _operator_rna_type_name_from_class(cls):
    try:
        bl_idname = str(getattr(cls, 'bl_idname', '') or '').strip()
    except Exception:
        bl_idname = ''
    if not bl_idname or '.' not in bl_idname:
        return ''
    prefix, suffix = bl_idname.split('.', 1)
    prefix = prefix.strip().upper()
    suffix = suffix.strip()
    if not prefix or not suffix:
        return ''
    return f"{prefix}_OT_{suffix}"


def _safe_unregister_class(cls):
    candidate_names = []
    py_name = str(getattr(cls, "__name__", "") or "")
    if py_name:
        candidate_names.append(py_name)
    rna_name = _operator_rna_type_name_from_class(cls)
    if rna_name and rna_name not in candidate_names:
        candidate_names.append(rna_name)
    for name in candidate_names:
        target = getattr(bpy.types, name, None)
        if isinstance(target, type):
            try:
                bpy.utils.unregister_class(target)
                return
            except Exception:
                pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_register_class(cls):
    # Remove stale RNA classes from failed reloads before registering the
    # current class object. This is important for add-on upgrades where a previous build may have left the legacy VIEW3D_OT_csdt_force RNA struct without callbacks.
    try:
        _safe_unregister_class(cls)
    except Exception:
        pass
    bpy.utils.register_class(cls)


# Legacy operator IDs are no longer registered. Older builds could leave
# view3d.csdt_force with a broken RNA callback table after add-on reloads.
# The active click route now uses view3d.sts_csdt_force, while legacy IDs are
# removed from keymaps during synchronization.

# =========================================================
# Keymap Management
# =========================================================
_CSDT_KEYMAP_ITEMS = []
# Last ensure-state cache cleared by _remove_km_items(); keyed per keymap route.
_CSDT_LAST_ENSURE_STATE = {}
_CSDT_KEYMAP_SYNC_TIMER_ACTIVE = False
_CSDT_KEYMAP_SYNC_FAST_REMAINING = 0
_CSDT_KEYMAP_SYNC_INTERVAL = 2.0
_CSDT_KEYMAP_SYNC_FAST_INTERVAL = 0.25
_CSDT_KEYMAP_SYNC_FAST_PASSES = 12

# Smart Gizmo and Smart Transform click handling require a VIEW_3D left-click
# route. This is intentionally separate from Smart G-R-S G/R/S hotkeys, which
# remain manual-only.
_CSDT_CLICK_HANDLER_ID = "view3d.sts_csdt_force"
_CSDT_LEGACY_CLICK_HANDLER_IDS = {"view3d.csdt_force", "view3d.csdt_click_select_drag"}
_CSDT_CLICK_HANDLER_IDS = {_CSDT_CLICK_HANDLER_ID, *_CSDT_LEGACY_CLICK_HANDLER_IDS}
_CSDT_STALE_DIRECT_TRANSFORM_IDS = {'transform.smart_grs_transform'}
# Blender's keymap resolver may prefer exact native Shift/Ctrl LEFTMOUSE items
# over a manually configured any=True item.  Keep the broad catch-all for
# Alt/OSKey pass-through, but also register exact plain/Shift/Ctrl variants so
# Select/Tweak and Smart Gizmo edge clicks consistently enter this operator.
_CSDT_CLICK_EVENT_VALUES = ('PRESS', 'CLICK')
_CSDT_CLICK_MODIFIER_VARIANTS = (
    ('ANY', True, None, None, None, None),
    ('PLAIN', False, False, False, False, False),
    ('SHIFT', False, True, False, False, False),
    ('CTRL', False, False, True, False, False),
    ('SHIFT_CTRL', False, True, True, False, False),
)
# Register only in the supported active-tool keymaps.  A generic 3D View entry can
# lose priority to Blender's Select Box / Circle / Lasso tool keymaps, which lets
# background selection start before CSDT can test the element under the cursor.
# Tool-scoped entries keep the route hit-aware without affecting unsupported tools.
_CSDT_TOOL_KEYMAP_NAMES = (
    # Tool-scoped routes keep Smart Transform hit-aware.  The generic View3D/Mesh
    # fallbacks cover Blender 5.1 paths where Edit Mesh click selection can bypass
    # the active tool keymap and revert Shift/Ctrl to native behavior.
    "3D View",
    "Mesh",
    "3D View Tool: Move",
    "3D View Tool: Rotate",
    "3D View Tool: Scale",
    "3D View Tool: Transform",
    "3D View Tool: Select",
    "3D View Tool: Tweak",
    "3D View Tool: Tweak (fallback)",
    "3D View Tool: Select Box",
    "3D View Tool: Select Box (fallback)",
    "3D View Tool: Select Circle",
    "3D View Tool: Select Circle (fallback)",
    "3D View Tool: Select Lasso",
    "3D View Tool: Select Lasso (fallback)",
    "3D View Tool: Edit Mesh, Move",
    "3D View Tool: Edit Mesh, Rotate",
    "3D View Tool: Edit Mesh, Scale",
    "3D View Tool: Edit Mesh, Transform",
    "3D View Tool: Edit Mesh, Select",
    "3D View Tool: Edit Mesh, Tweak",
    "3D View Tool: Edit Mesh, Tweak (fallback)",
    "3D View Tool: Edit Mesh, Select Box",
    "3D View Tool: Edit Mesh, Select Box (fallback)",
    "3D View Tool: Edit Mesh, Select Circle",
    "3D View Tool: Edit Mesh, Select Circle (fallback)",
    "3D View Tool: Edit Mesh, Select Lasso",
    "3D View Tool: Edit Mesh, Select Lasso (fallback)",
    "3D View Tool: Edit Curve, Move",
    "3D View Tool: Edit Curve, Rotate",
    "3D View Tool: Edit Curve, Scale",
    "3D View Tool: Edit Curve, Transform",
    "3D View Tool: Edit Curve, Select",
    "3D View Tool: Edit Curve, Select Box",
    "3D View Tool: Edit Curve, Select Circle",
    "3D View Tool: Edit Curve, Select Lasso",
)
# Older builds inserted the Smart Transform click handler into these wider
# keymaps.  They are scanned for cleanup only.
_CSDT_STALE_TOOL_KEYMAP_NAMES = tuple(dict.fromkeys((
    *_CSDT_TOOL_KEYMAP_NAMES,
    "3D View Generic",
)))
_CSDT_TOOL_KEYMAP_LABELS = {
    "3D View": ("3D View", "3Dビュー"),
    "3D View Generic": ("3D View Generic", "3Dビュー共通"),
    "Mesh": ("Mesh", "メッシュ編集"),
    "3D View Tool: Move": ("3D View Tool: Move", "3Dビュー ツール: 移動"),
    "3D View Tool: Rotate": ("3D View Tool: Rotate", "3Dビュー ツール: 回転"),
    "3D View Tool: Scale": ("3D View Tool: Scale", "3Dビュー ツール: スケール"),
    "3D View Tool: Transform": ("3D View Tool: Transform", "3Dビュー ツール: トランスフォーム"),
    "3D View Tool: Select": ("3D View Tool: Select", "3Dビュー ツール: 選択"),
    "3D View Tool: Tweak": ("3D View Tool: Tweak", "3Dビュー ツール: 微調整選択"),
    "3D View Tool: Edit Mesh, Move": ("3D View Tool: Edit Mesh, Move", "3Dビュー メッシュ編集 ツール: 移動"),
    "3D View Tool: Edit Mesh, Rotate": ("3D View Tool: Edit Mesh, Rotate", "3Dビュー メッシュ編集 ツール: 回転"),
    "3D View Tool: Edit Mesh, Scale": ("3D View Tool: Edit Mesh, Scale", "3Dビュー メッシュ編集 ツール: スケール"),
    "3D View Tool: Edit Mesh, Transform": ("3D View Tool: Edit Mesh, Transform", "3Dビュー メッシュ編集 ツール: トランスフォーム"),
    "3D View Tool: Edit Mesh, Select": ("3D View Tool: Edit Mesh, Select", "3Dビュー メッシュ編集 ツール: 選択"),
    "3D View Tool: Edit Mesh, Tweak": ("3D View Tool: Edit Mesh, Tweak", "3Dビュー メッシュ編集 ツール: 微調整選択"),
    "3D View Tool: Select Box": ("3D View Tool: Select Box", "3Dビュー ツール: ボックス選択"),
    "3D View Tool: Select Circle": ("3D View Tool: Select Circle", "3Dビュー ツール: サークル選択"),
    "3D View Tool: Select Lasso": ("3D View Tool: Select Lasso", "3Dビュー ツール: 投げ縄選択"),
    "3D View Tool: Edit Curve, Move": ("3D View Tool: Edit Curve, Move", "3Dビュー カーブ編集 ツール: 移動"),
    "3D View Tool: Edit Curve, Rotate": ("3D View Tool: Edit Curve, Rotate", "3Dビュー カーブ編集 ツール: 回転"),
    "3D View Tool: Edit Curve, Scale": ("3D View Tool: Edit Curve, Scale", "3Dビュー カーブ編集 ツール: スケール"),
    "3D View Tool: Edit Curve, Transform": ("3D View Tool: Edit Curve, Transform", "3Dビュー カーブ編集 ツール: トランスフォーム"),
    "3D View Tool: Edit Curve, Select": ("3D View Tool: Edit Curve, Select", "3Dビュー カーブ編集 ツール: 選択"),
    "3D View Tool: Edit Curve, Select Box": ("3D View Tool: Edit Curve, Select Box", "3Dビュー カーブ編集 ツール: ボックス選択"),
    "3D View Tool: Edit Curve, Select Circle": ("3D View Tool: Edit Curve, Select Circle", "3Dビュー カーブ編集 ツール: サークル選択"),
    "3D View Tool: Edit Curve, Select Lasso": ("3D View Tool: Edit Curve, Select Lasso", "3Dビュー カーブ編集 ツール: 投げ縄選択"),
}


def _tool_id_from_csdt_keymap_name(km_name: str) -> str:
    """Return the Blender tool id represented by a tool-scoped keymap name.

    Generic View3D/Mesh fallback keymaps intentionally return an empty action,
    so invocation resolves the active workspace tool at the exact click.  This
    prevents stale Select/Tweak properties from turning Edit Mesh edge clicks
    back into Blender's native Shift=toggle / Ctrl=context-select behavior.
    """
    name = str(km_name or '').strip()
    if name.endswith(' (fallback)'):
        name = name[:-len(' (fallback)')]
    if name in {'3D View', '3D View Generic', 'Mesh'}:
        return ''
    if not name.startswith('3D View Tool:'):
        return ''
    tail = name.split(':', 1)[1].strip()
    final_label = tail.rsplit(',', 1)[-1].strip()
    if final_label == 'Transform':
        return 'builtin.transform'
    if final_label == 'Move':
        return 'builtin.move'
    if final_label == 'Rotate':
        return 'builtin.rotate'
    if final_label == 'Scale':
        return 'builtin.scale'
    if final_label in {'Select', 'Tweak'}:
        return 'builtin.select'
    if final_label == 'Select Box':
        return 'builtin.select_box'
    if final_label == 'Select Circle':
        return 'builtin.select_circle'
    if final_label == 'Select Lasso':
        return 'builtin.select_lasso'
    return ''


def _set_csdt_kmi_tool_properties(kmi, km_name: str) -> None:
    """Store the keymap's active tool route and exact selection variant."""
    try:
        tool_id = _tool_id_from_csdt_keymap_name(km_name)
        kmi.properties.action = tool_id if tool_id else ''
    except Exception:
        pass
    try:
        if bool(getattr(kmi, 'any', False)):
            kmi.properties.select_mode_hint = ''
        elif _csdt_mod_value_is_true(getattr(kmi, 'shift', False)) and _csdt_mod_value_is_true(getattr(kmi, 'ctrl', False)):
            kmi.properties.select_mode_hint = 'XOR'
        elif _csdt_mod_value_is_true(getattr(kmi, 'ctrl', False)):
            kmi.properties.select_mode_hint = 'SUB'
        elif _csdt_mod_value_is_true(getattr(kmi, 'shift', False)):
            kmi.properties.select_mode_hint = 'ADD'
        else:
            kmi.properties.select_mode_hint = 'SET'
    except Exception:
        pass


def _transform_tool_route_enabled(tool_id: str, prefs) -> bool:
    tool_id = str(tool_id or '').strip()
    if tool_id not in cg._TRANSFORM_TOOL_IDS:
        return False
    if prefs is None:
        return True
    try:
        if tool_id == 'builtin.move':
            return bool(getattr(prefs, 'enable_move', True))
        if tool_id == 'builtin.rotate':
            return bool(getattr(prefs, 'enable_rotate', True))
        if tool_id == 'builtin.scale':
            return bool(getattr(prefs, 'enable_scale', True))
        if tool_id == 'builtin.transform':
            return bool(getattr(prefs, 'enable_transform', True))
    except Exception:
        return True
    return True


def _remove_keymap_item_best_effort(km, kmi) -> bool:
    """No-op: automatic keymap removal/deactivation is disabled."""
    del km, kmi
    return False

def _cleanup_stale_addon_csdt_keymaps(wm):
    """No-op: do not scan, remove, or deactivate Blender keymaps automatically."""
    del wm
    return

def _iter_unique_keyconfigs(wm, include_addon=False):
    del include_addon
    try:
        kc = getattr(getattr(wm, 'keyconfigs', None), 'addon', None)
        if kc is not None:
            yield kc
    except Exception:
        return


def _csdt_tool_keymap_names_from_wm(wm):
    del wm
    try:
        prefs = _runtime.get_addon_preferences(getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = cu._prefs(getattr(bpy, 'context', None))
        except Exception:
            prefs = None
    if prefs is None:
        return []
    for prop in ('enable_move', 'enable_rotate', 'enable_scale', 'enable_transform'):
        try:
            if bool(getattr(prefs, prop, False)):
                return list(_CSDT_TOOL_KEYMAP_NAMES)
        except Exception:
            pass
    return []


def _click_keymap_should_be_enabled(context=None) -> bool:
    """Enable CSDT active-tool click routes when any transform path is enabled.

    The route is hit-aware for Move / Rotate / Scale / Transform and for Select /
    Box / Circle / Lasso tools. Unsupported tools are not handled by the manual route.
    """
    try:
        prefs = _runtime.get_addon_preferences(context or getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = cu._prefs(context)
        except Exception:
            prefs = None
    if prefs is None:
        return False
    flags = (
        'enable_move',
        'enable_rotate',
        'enable_scale',
        'enable_transform',
    )
    for name in flags:
        try:
            if bool(getattr(prefs, name, False)):
                return True
        except Exception:
            pass
    return False

def _csdt_mod_value_is_true(value) -> bool:
    try:
        return int(value) == 1
    except Exception:
        return bool(value) is True


def _csdt_kmi_matches_modifier_variant(kmi, *, value='PRESS', any_state=False, shift=None, ctrl=None, alt=None, oskey=None) -> bool:
    try:
        if str(getattr(kmi, 'idname', '') or '') != _CSDT_CLICK_HANDLER_ID:
            return False
        if str(getattr(kmi, 'type', '') or '') != 'LEFTMOUSE':
            return False
        if str(getattr(kmi, 'value', '') or '').upper() != str(value or 'PRESS').upper():
            return False
        if bool(any_state):
            return bool(getattr(kmi, 'any', False))
        if bool(getattr(kmi, 'any', False)):
            return False
        return (
            _csdt_mod_value_is_true(getattr(kmi, 'shift', False)) == bool(shift)
            and _csdt_mod_value_is_true(getattr(kmi, 'ctrl', False)) == bool(ctrl)
            and _csdt_mod_value_is_true(getattr(kmi, 'alt', False)) == bool(alt)
            and _csdt_mod_value_is_true(getattr(kmi, 'oskey', False)) == bool(oskey)
        )
    except Exception:
        return False


def _set_csdt_kmi_modifier_variant(kmi, *, any_state, shift=None, ctrl=None, alt=None, oskey=None) -> int:
    """No-op: keymap item properties are user-managed only."""
    del kmi, any_state, shift, ctrl, alt, oskey
    return 0

def _sanitize_csdt_click_kmi_for_variant(kmi, *, value='PRESS', any_state=False, shift=None, ctrl=None, alt=None, oskey=None, active=True) -> int:
    """No-op: keymap item properties are user-managed only."""
    del kmi, value, any_state, shift, ctrl, alt, oskey, active
    return 0

def _new_csdt_click_kmi_variant(km, *, value='PRESS', any_state=False, shift=None, ctrl=None, alt=None, oskey=None):
    """No-op: Smart Transform Suite never creates keymap items automatically."""
    del km, value, any_state, shift, ctrl, alt, oskey
    return None

def _ensure_csdt_click_kmi_variants(km, km_name):
    """No-op: keymap registration is manual-only."""
    del km, km_name
    return []

def _csdt_keymap_new_kwargs(km_name: str) -> dict:
    name = str(km_name or '')
    if name == 'Mesh':
        return {'name': name, 'space_type': 'EMPTY', 'region_type': 'WINDOW'}
    return {'name': name, 'space_type': 'VIEW_3D', 'region_type': 'WINDOW'}

def _add_km_item(kc, km_name):
    """No-op: do not add or repair Blender keymaps automatically."""
    del kc, km_name
    return None

def _kmi_active(kmi, default=True):
    try:
        return bool(getattr(kmi, 'active', default))
    except Exception:
        return bool(default)


def _sanitize_csdt_click_kmi(kmi, *, active=None) -> int:
    """No-op: keymap item properties are user-managed only."""
    del kmi, active
    return 0

def _tracked_keymap_item_exists(km, kmi) -> bool:
    try:
        for old_km, old_kmi in _CSDT_KEYMAP_ITEMS:
            if old_km is km and old_kmi is kmi:
                return True
    except Exception:
        pass
    return False


def _ensure_csdt_click_keymaps(context=None) -> int:
    """No-op: Preferences > Keymap entries are never auto-created."""
    del context
    return 0

def _csdt_priority_enabled(context=None) -> bool:
    try:
        prefs = _runtime.get_addon_preferences(context or getattr(bpy, 'context', None), __package__, __name__, __file__)
    except Exception:
        prefs = None
    if prefs is None:
        try:
            prefs = cu._prefs(context)
        except Exception:
            prefs = None
    try:
        return bool(getattr(prefs, 'prefer_csdt_keymap_priority', False))
    except Exception:
        return False


def _csdt_keymap_sync_once(context=None) -> int:
    """No-op: automatic keymap repair is disabled."""
    del context
    return 0

def _csdt_keymap_sync_timer():
    """No-op timer; automatic keymap repair is disabled."""
    global _CSDT_KEYMAP_SYNC_TIMER_ACTIVE, _CSDT_KEYMAP_SYNC_FAST_REMAINING
    _CSDT_KEYMAP_SYNC_TIMER_ACTIVE = False
    _CSDT_KEYMAP_SYNC_FAST_REMAINING = 0
    return None

def _schedule_csdt_keymap_sync(context=None, *, fast=True) -> None:
    """No-op: keymap repair timers are disabled."""
    del context, fast
    global _CSDT_KEYMAP_SYNC_TIMER_ACTIVE, _CSDT_KEYMAP_SYNC_FAST_REMAINING
    _CSDT_KEYMAP_SYNC_TIMER_ACTIVE = False
    _CSDT_KEYMAP_SYNC_FAST_REMAINING = 0
    return

def _stop_csdt_keymap_sync() -> None:
    global _CSDT_KEYMAP_SYNC_TIMER_ACTIVE, _CSDT_KEYMAP_SYNC_FAST_REMAINING
    _CSDT_KEYMAP_SYNC_TIMER_ACTIVE = False
    _CSDT_KEYMAP_SYNC_FAST_REMAINING = 0
    try:
        if bpy.app.timers.is_registered(_csdt_keymap_sync_timer):
            bpy.app.timers.unregister(_csdt_keymap_sync_timer)
    except Exception:
        pass


def _remove_km_items():
    """Clear local keymap references only; never mutate Blender keymaps."""
    try:
        _CSDT_KEYMAP_ITEMS.clear()
    except Exception:
        pass
    try:
        _CSDT_LAST_ENSURE_STATE.clear()
    except Exception:
        pass
    return

def csdt_tool_keymap_label(km_name: str) -> str:
    key = str(km_name or "")
    pair = _CSDT_TOOL_KEYMAP_LABELS.get(key)
    if pair:
        return TI(pair[0], pair[1])
    return str(key or TI("Unknown Tool", "不明なツール"))


@persistent
def _csdt_on_load_pre(dummy):
    try:
        _clear_smart_gizmo_drag_state()
    except Exception:
        pass
    try:
        _stop_crossing_select_watchers()
    except Exception:
        pass
    try:
        _CSDT_NATIVE_RELEASE_WATCHERS.clear()
    except Exception:
        pass
    try:
        _cleanup_background_box_preview_registry(force=True)
    except Exception:
        pass


@persistent
def _csdt_on_load_post(dummy):
    try:
        cu._tag_view3d_redraw()
    except Exception:
        pass
    try:
        sync_runtime_from_prefs(bpy.context)
    except Exception:
        pass
    try:
        _cleanup_legacy_user_injected_csdt(bpy.context)
    except Exception:
        pass
    try:
        apply_csdt_keymap_priority(bpy.context, _csdt_priority_enabled(bpy.context))
    except Exception:
        pass


# =========================================================
# Keymap Conflicts / Priority (Stable mode)
# NOTE: no USER keymap injection / no reordering to avoid Blender 5.0.x keymap-diff crash.
# =========================================================
_CSDT_DISABLED_CONFLICT_USER_KMIS = []
_CSDT_DISABLED_CONFLICT_ACTIVE_KMIS = []
_CSDT_DISABLED_CONFLICT_DEFAULT_KMIS = []


def _cleanup_legacy_user_injected_csdt(context):
    """No-op: legacy or manual keymap entries are user-managed only."""
    del context
    return

def _csdt_priority_specs(context):
    """Crash-safe empty CSDT keymap specs."""
    del context
    return []

def _kmi_matches_spec(kmi, spec):
    try:
        if kmi.idname != spec["idname"]:
            return False
        if kmi.type != spec["type"] or kmi.value != spec["value"]:
            return False
        # 'any' means ignore modifiers
        if bool(getattr(kmi, "any", False)) != bool(spec.get("any", False)):
            # if spec.any True, we accept either; otherwise strict.
            if not spec.get("any", False):
                return False
        if not spec.get("any", False):
            if bool(kmi.shift) != bool(spec["shift"]): return False
            if bool(kmi.ctrl) != bool(spec["ctrl"]): return False
            if bool(kmi.alt) != bool(spec["alt"]): return False
            if bool(getattr(kmi, "oskey", False)) != bool(spec["oskey"]): return False
            if getattr(kmi, "key_modifier", "NONE") != spec.get("key_modifier", "NONE"): return False
        return True
    except Exception:
        return False


def csdt_scan_keymap_conflicts(context):
    """Crash-safe no-op conflict report for CSDT keymaps."""
    del context
    return []

def apply_csdt_keymap_priority(context, enable: bool):
    """Apply click-priority state without touching native/user keymaps."""
    del enable
    try:
        _CSDT_DISABLED_CONFLICT_USER_KMIS.clear()
        _CSDT_DISABLED_CONFLICT_ACTIVE_KMIS.clear()
        _CSDT_DISABLED_CONFLICT_DEFAULT_KMIS.clear()
    except Exception:
        pass
    try:
        sync_runtime_from_prefs(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return

# =========================================================
# Registration
# =========================================================
classes = (
    VIEW3D_OT_csdt_native_release_watch,
    VIEW3D_OT_csdt_single_select_no_drag,
    VIEW3D_OT_sts_csdt_force,
    VIEW3D_OT_csdt_force,
    VIEW3D_OT_csdt_click_select_drag,
)


def _add_csdt_load_handlers() -> None:
    try:
        if _csdt_on_load_pre not in bpy.app.handlers.load_pre:
            bpy.app.handlers.load_pre.append(_csdt_on_load_pre)
    except Exception:
        pass
    try:
        if _csdt_on_load_post not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_csdt_on_load_post)
    except Exception:
        pass


def _remove_csdt_load_handlers() -> None:
    try:
        if _csdt_on_load_pre in bpy.app.handlers.load_pre:
            bpy.app.handlers.load_pre.remove(_csdt_on_load_pre)
    except Exception:
        pass
    try:
        if _csdt_on_load_post in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_csdt_on_load_post)
    except Exception:
        pass


def _csdt_rna_ptr(value):
    try:
        return int(value.as_pointer()) if value is not None and hasattr(value, 'as_pointer') else 0
    except Exception:
        return 0


def _crossing_select_prefs_enabled(context=None):
    try:
        return bool(cu._csdt_crossing_selection_enabled(context))
    except Exception:
        return False


def _crossing_select_area_supported(area):
    area_type = str(getattr(area, 'type', '') or '')
    return area_type == 'VIEW_3D'


def _crossing_select_event_area_region(context, event):
    try:
        wx = int(getattr(event, 'mouse_x', 0))
        wy = int(getattr(event, 'mouse_y', 0))
    except Exception:
        return None, None
    try:
        area0 = getattr(context, 'area', None)
        region0 = getattr(context, 'region', None)
        if _crossing_select_area_supported(area0) and getattr(region0, 'type', None) == 'WINDOW' and cu._event_inside_region(region0, wx, wy):
            return area0, region0
    except Exception:
        pass
    try:
        win = getattr(context, 'window', None)
        screen = getattr(win, 'screen', None) if win is not None else getattr(context, 'screen', None)
        for area in getattr(screen, 'areas', []) or []:
            if not _crossing_select_area_supported(area):
                continue
            for region in getattr(area, 'regions', []) or []:
                if getattr(region, 'type', None) == 'WINDOW' and cu._event_inside_region(region, wx, wy):
                    return area, region
    except Exception:
        pass
    return None, None


def _crossing_select_region_xy(region, event):
    try:
        return (
            int(getattr(event, 'mouse_x', 0)) - int(getattr(region, 'x', 0) or 0),
            int(getattr(event, 'mouse_y', 0)) - int(getattr(region, 'y', 0) or 0),
        )
    except Exception:
        return (0, 0)


def _crossing_select_active_tool_id(context, area=None, region=None):
    area_type = str(getattr(area, 'type', '') or '')
    try:
        with context.temp_override(area=area, region=region, space_data=getattr(getattr(area, 'spaces', None), 'active', None)):
            if area_type == 'VIEW_3D':
                tid = str(cu._active_tool_id(context) or '').strip()
                return tid if tid in {'builtin.select_box', 'builtin.select_lasso', 'builtin.select_circle'} else ''
    except Exception:
        pass
    return ''


def _crossing_tool_kind_from_id(tool_id):
    tool_id = str(tool_id or '').strip()
    if tool_id == 'builtin.select_lasso':
        return 'LASSO'
    if tool_id == 'builtin.select_circle':
        return 'CIRCLE'
    if tool_id == 'builtin.select_box':
        return 'BOX'
    return ''


def _crossing_public_tool_kind_from_operator_id(op_id):
    op_id = str(op_id or '').strip()
    if op_id in {'VIEW3D_OT_select_box', 'view3d.select_box'}:
        return 'BOX'
    if op_id in {'VIEW3D_OT_select_lasso', 'view3d.select_lasso'}:
        return 'LASSO'
    if op_id in {'VIEW3D_OT_select_circle', 'view3d.select_circle'}:
        return 'CIRCLE'
    return ''


def _crossing_select_public_operator_rows(context, area_type=''):
    try:
        wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        operators = list(getattr(wm, 'operators', []) or [])
    except Exception:
        operators = []
    prefix = 'VIEW3D_OT_' if str(area_type or '').upper() == 'VIEW_3D' else ''
    rows = []
    for op in reversed(operators[-12:]):
        try:
            op_id = str(getattr(op, 'bl_idname', '') or getattr(op, 'idname', '') or '')
            kind = _crossing_public_tool_kind_from_operator_id(op_id)
            if not kind:
                continue
            if prefix and not op_id.startswith(prefix):
                continue
            rows.append((op_id, _csdt_rna_ptr(op), kind))
        except Exception:
            pass
    return tuple(rows)


def _crossing_select_public_operator_fingerprint(context, area_type=''):
    return tuple((row[0], row[1]) for row in _crossing_select_public_operator_rows(context, area_type))


def _crossing_select_recent_public_tool_kind(context, area_type='', previous_fingerprint=None):
    previous = set(tuple(row) for row in (previous_fingerprint or ()))
    for op_id, ptr, kind in _crossing_select_public_operator_rows(context, area_type):
        if (op_id, ptr) not in previous:
            return kind
    return ''


def _crossing_select_key_event_tool_kind(event):
    try:
        if str(getattr(event, 'value', '') or '').upper() != 'PRESS':
            return ''
        etype = str(getattr(event, 'type', '') or '').upper()
        if etype == 'B':
            return 'BOX'
        if etype == 'C':
            return 'CIRCLE'
    except Exception:
        pass
    return ''


def _crossing_select_operator_id_for_area(area_type, kind):
    area_type = str(area_type or '').upper()
    kind = str(kind or '').upper()
    space = 'view3d' if area_type == 'VIEW_3D' else ''
    if not space:
        return ''
    suffix = {'BOX': 'select_box', 'LASSO': 'select_lasso', 'CIRCLE': 'select_circle'}.get(kind, '')
    return f'{space}.{suffix}' if suffix else ''


def _crossing_select_event_type_matches(kmi_type, event_type):
    kmi_type = str(kmi_type or '')
    event_type = str(event_type or '')
    if kmi_type == event_type:
        return True
    tweak_map = {
        'EVT_TWEAK_L': 'LEFTMOUSE',
        'EVT_TWEAK_M': 'MIDDLEMOUSE',
        'EVT_TWEAK_R': 'RIGHTMOUSE',
    }
    return bool(tweak_map.get(kmi_type) == event_type)


def _crossing_select_kmi_modifier_matches(kmi, event):
    try:
        if bool(getattr(kmi, 'any', False)):
            return True
    except Exception:
        pass
    for name in ('shift', 'ctrl', 'alt', 'oskey'):
        try:
            expected = getattr(kmi, name, False)
            actual = bool(getattr(event, name, False))
            if expected in {-1, 'ANY', None}:
                continue
            if bool(expected) != actual:
                return False
        except Exception:
            pass
    try:
        key_modifier = str(getattr(kmi, 'key_modifier', '') or 'NONE')
        if key_modifier and key_modifier != 'NONE' and str(getattr(event, 'type', '') or '') != key_modifier:
            # Blender applies key_modifier to a paired event rather than the
            # mouse/key event itself.  Treat it as non-authoritative here so a
            # public lasso KMI with Ctrl/Alt modifiers can still be recognized
            # from the actual start button event.
            pass
    except Exception:
        pass
    return True


def _crossing_select_kmi_matches_event(kmi, event):
    try:
        ktype = str(getattr(kmi, 'type', '') or '')
        etype = str(getattr(event, 'type', '') or '')
        if not _crossing_select_event_type_matches(ktype, etype):
            return False
        kvalue = str(getattr(kmi, 'value', '') or '').upper()
        evalue = str(getattr(event, 'value', '') or '').upper()
        if kvalue in {'CLICK_DRAG', 'CLICK', 'PRESS_DRAG', 'TWEAK'} and evalue == 'PRESS':
            pass
        elif kvalue not in {'ANY', evalue}:
            return False
        return _crossing_select_kmi_modifier_matches(kmi, event)
    except Exception:
        return False


def _crossing_select_kmi_mode(kmi):
    for owner_name in ('properties',):
        try:
            owner = getattr(kmi, owner_name, None)
            mode = str(getattr(owner, 'mode', '') or '').upper()
            if mode in {'SET', 'ADD', 'SUB', 'XOR', 'AND'}:
                return 'SET' if mode == 'AND' else mode
        except Exception:
            pass
    return ''


def _crossing_select_keyconfig_match_info(context, area_type, event):
    if str(area_type or '').upper() != 'VIEW_3D':
        return {}
    try:
        wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        keyconfigs = getattr(wm, 'keyconfigs', None)
    except Exception:
        keyconfigs = None
    if keyconfigs is None:
        return {}
    keymap_names = ('3D View', 'Mesh')
    for kind in ('BOX', 'LASSO', 'CIRCLE'):
        op_id = _crossing_select_operator_id_for_area(area_type, kind)
        if not op_id:
            continue
        for kc_name in ('active', 'user', 'default'):
            try:
                kc = getattr(keyconfigs, kc_name, None)
                if kc is None:
                    continue
                for km_name in keymap_names:
                    try:
                        km = kc.keymaps.get(km_name)
                    except Exception:
                        km = None
                    if km is None:
                        continue
                    for kmi in getattr(km, 'keymap_items', []) or []:
                        try:
                            if str(getattr(kmi, 'idname', '') or '') != op_id:
                                continue
                            if not bool(getattr(kmi, 'active', True)):
                                continue
                            if _crossing_select_kmi_matches_event(kmi, event):
                                return {
                                    'kind': kind,
                                    'mode': _crossing_select_kmi_mode(kmi),
                                    'idname': op_id,
                                    'type': str(getattr(kmi, 'type', '') or ''),
                                    'value': str(getattr(kmi, 'value', '') or ''),
                                }
                        except Exception:
                            pass
            except Exception:
                pass
    return {}


def _crossing_select_keyconfig_tool_kind(context, area_type, event):
    try:
        return str(_crossing_select_keyconfig_match_info(context, area_type, event).get('kind', '') or '')
    except Exception:
        return ''


def _crossing_select_event_tool_info(context, area, region, event):
    area_type = str(getattr(area, 'type', '') or '')
    info = _crossing_select_keyconfig_match_info(context, area_type, event)
    if info:
        return info
    kind = _crossing_select_key_event_tool_kind(event)
    if kind:
        return {'kind': kind, 'mode': '', 'idname': 'keyboard.' + kind.lower(), 'type': str(getattr(event, 'type', '') or ''), 'value': str(getattr(event, 'value', '') or '')}
    return {}


def _crossing_select_event_tool_kind(context, area, region, event):
    try:
        return str(_crossing_select_event_tool_info(context, area, region, event).get('kind', '') or '')
    except Exception:
        pass
    return ''


def _crossing_select_operator_prop(op, *names):
    for owner in (op, getattr(op, 'properties', None)):
        if owner is None:
            continue
        for name in names:
            try:
                value = getattr(owner, name)
                if value is not None:
                    return value
            except Exception:
                pass
    return None


def _crossing_select_operator_lasso_points(path_value):
    points = []
    try:
        iterator = list(path_value)
    except Exception:
        iterator = []
    for item in iterator:
        try:
            loc = getattr(item, 'loc', None)
            if loc is not None and len(loc) >= 2:
                points.append((float(loc[0]), float(loc[1])))
                continue
        except Exception:
            pass
        try:
            points.append((float(getattr(item, 'x')), float(getattr(item, 'y'))))
            continue
        except Exception:
            pass
        try:
            points.append((float(item[0]), float(item[1])))
        except Exception:
            pass
    return points


def _crossing_select_shape_from_public_operator(op, kind):
    kind = str(kind or '').upper()
    try:
        if kind == 'BOX':
            xmin = _crossing_select_operator_prop(op, 'xmin', 'x_min')
            xmax = _crossing_select_operator_prop(op, 'xmax', 'x_max')
            ymin = _crossing_select_operator_prop(op, 'ymin', 'y_min')
            ymax = _crossing_select_operator_prop(op, 'ymax', 'y_max')
            if None not in {xmin, xmax, ymin, ymax}:
                return cu._csdt_crossing_shape_from_box(float(xmin), float(ymin), float(xmax), float(ymax))
        if kind == 'CIRCLE':
            x = _crossing_select_operator_prop(op, 'x', 'center_x', 'mouse_x')
            y = _crossing_select_operator_prop(op, 'y', 'center_y', 'mouse_y')
            radius = _crossing_select_operator_prop(op, 'radius')
            if x is not None and y is not None:
                return cu._csdt_crossing_shape_from_circle(float(x), float(y), float(radius if radius is not None else 25.0))
        if kind == 'LASSO':
            path = _crossing_select_operator_prop(op, 'path')
            points = _crossing_select_operator_lasso_points(path)
            if points:
                return cu._csdt_crossing_shape_from_lasso(points)
    except Exception:
        return None
    return None


def _crossing_select_shape_signature(shape):
    """Build a stable, RNA-free signature for a public selector shape."""
    if not isinstance(shape, dict):
        return None
    try:
        kind = str(shape.get('kind', '') or '').upper()
        tool = str(shape.get('tool', '') or '').upper()
        if kind == 'CIRCLE':
            center = shape.get('center') or (0.0, 0.0)
            return (
                'CIRCLE', tool,
                round(float(center[0]), 4), round(float(center[1]), 4),
                round(float(shape.get('radius', 0.0) or 0.0), 4),
            )
        poly = []
        for point in list(shape.get('poly') or ()):
            poly.append((round(float(point[0]), 4), round(float(point[1]), 4)))
        return ('POLYGON', tool, tuple(poly)) if poly else None
    except Exception:
        return None


def _crossing_select_last_operator_snapshot(context, area_type, kind):
    """Read Blender's last public region-select properties without retaining RNA."""
    op_id = _crossing_select_operator_id_for_area(area_type, kind)
    if not op_id:
        return None, '', None
    try:
        wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        props = wm.operator_properties_last(op_id) if wm is not None else None
    except Exception:
        props = None
    if props is None:
        return None, '', None
    shape = _crossing_select_shape_from_public_operator(props, kind)
    mode = str(_crossing_select_operator_prop(props, 'mode') or '').upper()
    if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
        mode = ''
    return shape, mode, _crossing_select_shape_signature(shape)


def _crossing_select_new_public_operator(context, area_type, kind, previous_fingerprint):
    previous = set(tuple(row) for row in (previous_fingerprint or ()))
    try:
        rows = _crossing_select_public_operator_rows(context, area_type)
    except Exception:
        rows = ()
    for op_id, ptr, row_kind in rows:
        if str(row_kind or '').upper() != str(kind or '').upper():
            continue
        if (op_id, ptr) in previous:
            continue
        try:
            wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
            for op in reversed(list(getattr(wm, 'operators', []) or [])):
                found_id = str(getattr(op, 'bl_idname', '') or getattr(op, 'idname', '') or '')
                if found_id == op_id and _csdt_rna_ptr(op) == ptr:
                    return op
        except Exception:
            pass
    return None


def _schedule_crossing_public_operator_completion(
    context,
    area,
    region,
    info,
    previous_fingerprint,
    preselect,
    fallback_shape=None,
    *,
    owner=None,
    state_token=None,
):
    kind = str((info or {}).get('kind', '') or '').upper()
    area_type = str(getattr(area, 'type', '') or '')
    if kind not in {'BOX', 'LASSO', 'CIRCLE'} or area_type != 'VIEW_3D':
        return False
    try:
        _previous_shape, _previous_mode, previous_last_signature = _crossing_select_last_operator_snapshot(
            context, area_type, kind,
        )
    except Exception:
        previous_last_signature = None
    ref = {
        'callback': None,
        'remaining': 600,
        'done': False,
        'generation': _crossing_next_gesture_generation(),
        'previous_last_signature': previous_last_signature,
    }
    try:
        if owner is not None:
            owner._public_completion_generation = int(ref['generation'])
    except Exception:
        pass

    def _tick():
        callback = ref.get('callback')
        try:
            ctx = getattr(bpy, 'context', None)
            if ctx is None:
                ref['done'] = True
                return None
            if ref.get('generation') != _CSDT_CROSSING_GESTURE_GENERATION:
                ref['done'] = True
                return None

            op = _crossing_select_new_public_operator(ctx, area_type, kind, previous_fingerprint)
            shape = _crossing_select_shape_from_public_operator(op, kind) if op is not None else None
            last_mode = ''
            if shape is None:
                last_shape, last_mode, last_signature = _crossing_select_last_operator_snapshot(ctx, area_type, kind)
                if last_signature is not None and last_signature != ref.get('previous_last_signature'):
                    shape = last_shape
            if shape is None:
                ref['remaining'] = int(ref.get('remaining', 0) or 0) - 1
                if ref['remaining'] > 0:
                    return 0.05
                shape = fallback_shape if isinstance(fallback_shape, dict) else None
            if shape is None:
                ref['done'] = True
                return None

            mode = str((info or {}).get('mode') or (getattr(op, 'mode', None) if op else None) or (_crossing_select_kmi_mode(op) if op else None) or last_mode or 'SET').upper()
            if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
                mode = 'SET'
            override = {'area': area, 'region': region}
            try:
                win = getattr(ctx, 'window', None)
                if win is not None:
                    override['window'] = win
                    screen = getattr(win, 'screen', None)
                    if screen is not None:
                        override['screen'] = screen
            except Exception:
                pass
            try:
                override['space_data'] = getattr(getattr(area, 'spaces', None), 'active', None)
            except Exception:
                pass
            try:
                if area_type == 'VIEW_3D':
                    rv3d = cu._view3d_region_data(area, region)
                    if rv3d is not None:
                        override['region_data'] = rv3d
            except Exception:
                pass
            with ctx.temp_override(**override):
                cu._csdt_apply_crossing_selection_region(
                    bpy.context,
                    area_type,
                    shape,
                    mode=mode,
                    area=area,
                    region=region,
                    region_data=cu._view3d_region_data(area, region) if area_type == 'VIEW_3D' else None,
                    preselect=dict(preselect or {}),
                    native_select_ok=True,
                    clear_first=False,
                )
            ref['done'] = True
            return None
        finally:
            if bool(ref.get('done', False)):
                try:
                    if owner is not None and getattr(owner, '_state', None) is state_token:
                        owner._state = None
                except Exception:
                    pass
                try:
                    if owner is not None and int(getattr(owner, '_public_completion_generation', 0) or 0) == int(ref.get('generation', 0) or 0):
                        owner._public_completion_generation = 0
                except Exception:
                    pass
                try:
                    if callback is not None:
                        _CSDT_CROSSING_SELECT_POST_CALLBACKS.discard(callback)
                except Exception:
                    pass

    ref['callback'] = _tick
    return _crossing_register_post_callback(_tick, first_interval=0.08)


def _crossing_context_runtime_allowed(context, area, region):
    try:
        if area is None or region is None:
            return False
        if hasattr(context, 'temp_override'):
            override = {'area': area, 'region': region}
            win = getattr(context, 'window', None)
            if win is not None:
                override['window'] = win
                screen = getattr(win, 'screen', None)
                if screen is not None:
                    override['screen'] = screen
            try:
                override['space_data'] = getattr(getattr(area, 'spaces', None), 'active', None)
            except Exception:
                pass
            try:
                if getattr(area, 'type', None) == 'VIEW_3D':
                    rv3d = cu._view3d_region_data(area, region)
                    if rv3d is not None:
                        override['region_data'] = rv3d
            except Exception:
                pass
            with context.temp_override(**override):
                try:
                    if bool(_manager_runtime_bridge.workspace_runtime_allowed(bpy.context)):
                        return True
                except Exception:
                    pass
    except Exception:
        pass
    try:
        return bool(_manager_runtime_bridge.workspace_runtime_allowed(context))
    except Exception:
        return True


def _crossing_circle_radius(context, area=None):
    radius = 25.0
    try:
        ws = getattr(context, 'workspace', None)
        tool = None
        tools = getattr(ws, 'tools', None) if ws is not None else None
        if tools is not None:
            if getattr(area, 'type', '') == 'VIEW_3D':
                tool = tools.from_space_view3d_mode(str(getattr(context, 'mode', 'EDIT_MESH') or 'EDIT_MESH'), create=False)
        if tool is not None:
            for op_id in ('view3d.select_circle',):
                try:
                    props = tool.operator_properties(op_id)
                    value = getattr(props, 'radius', None)
                    if value is not None:
                        radius = float(value)
                        break
                except Exception:
                    pass
    except Exception:
        pass
    try:
        return max(1.0, min(512.0, float(radius)))
    except Exception:
        return 25.0


def _crossing_register_post_callback(callback, first_interval=0.03):
    if callback is None:
        return False
    try:
        _CSDT_CROSSING_SELECT_POST_CALLBACKS.add(callback)
        bpy.app.timers.register(callback, first_interval=max(0.0, float(first_interval)))
        return True
    except Exception:
        try:
            _CSDT_CROSSING_SELECT_POST_CALLBACKS.discard(callback)
        except Exception:
            pass
    return False


def _crossing_unregister_post_callbacks():
    try:
        callbacks = list(_CSDT_CROSSING_SELECT_POST_CALLBACKS)
    except Exception:
        callbacks = []
    for callback in callbacks:
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            pass
        try:
            _CSDT_CROSSING_SELECT_POST_CALLBACKS.discard(callback)
        except Exception:
            pass


class WM_OT_sts_crossing_select_watch(bpy.types.Operator):
    bl_idname = "wm.sts_crossing_select_watch"
    bl_label = "Smart Transform Crossing Selection Watch"
    bl_options = {'INTERNAL'}

    _state = None
    _window_ptr = 0
    _public_completion_generation = 0

    def invoke(self, context, event):
        if getattr(getattr(context, 'area', None), 'type', '') == 'IMAGE_EDITOR':
            return {'PASS_THROUGH'}
        try:
            self._window_ptr = _csdt_rna_ptr(getattr(context, 'window', None))
            _CSDT_CROSSING_SELECT_WATCHERS[self._window_ptr] = self
            self._state = None
            self._public_completion_generation = 0
            wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
            if wm is None:
                return {'CANCELLED'}
            wm.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        except Exception:
            return {'CANCELLED'}

    def cancel(self, context):
        del context
        try:
            generation = int(getattr(self, '_public_completion_generation', 0) or 0)
            if generation and generation == int(_CSDT_CROSSING_GESTURE_GENERATION):
                _crossing_next_gesture_generation()
        except Exception:
            pass
        self._public_completion_generation = 0
        try:
            if _CSDT_CROSSING_SELECT_WATCHERS.get(self._window_ptr) is self:
                _CSDT_CROSSING_SELECT_WATCHERS.pop(self._window_ptr, None)
        except Exception:
            pass
        self._state = None
        return None

    def _begin(self, context, event):
        try:
            if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
                return False
            area, region = _crossing_select_event_area_region(context, event)
            if area is None or region is None:
                return False
            area_type = str(getattr(area, 'type', '') or '')
            if area_type != 'VIEW_3D':
                return False
            if not _crossing_context_runtime_allowed(context, area, region):
                return False
            tool_id = _crossing_select_active_tool_id(context, area, region)
            tool_kind = _crossing_tool_kind_from_id(tool_id)
            pending_info = dict(getattr(self, '_pending_public_tool_info', {}) or {})
            public_tool_pending = False
            if not tool_kind:
                pending_tool_kind = str(pending_info.get('kind') or getattr(self, '_pending_public_tool_kind', '') or '').upper()
                tool_kind = pending_tool_kind
                if tool_kind not in {'BOX', 'LASSO', 'CIRCLE'}:
                    tool_kind = ''
                    public_tool_pending = True
                else:
                    public_tool_pending = True
            if tool_kind in {'BOX', 'LASSO', 'CIRCLE'}:
                tool_id = str(pending_info.get('idname') or ('public.' + tool_kind.lower()))
            else:
                tool_kind = ''
                public_tool_pending = True
            try:
                self._pending_public_tool_kind = ''
                self._pending_public_tool_info = {}
                self._pending_public_tool_token = None
            except Exception:
                pass
            mode = str(pending_info.get('mode') or cu._selection_mode_from_event(event) or 'SET').upper()
            if mode not in {'SET', 'ADD', 'SUB', 'XOR'}:
                mode = 'SET'
            x, y = _crossing_select_region_xy(region, event)
            preselect = cu._csdt_crossing_preselect_snapshot(
                context, area_type,
                include_edges=True,
                include_faces=True,
            )
            self._state = {
                'window': getattr(context, 'window', None),
                'screen': getattr(getattr(context, 'window', None), 'screen', None),
                'area_ptr': _csdt_rna_ptr(area),
                'region_ptr': _csdt_rna_ptr(region),
                'area': area,
                'region': region,
                'area_type': area_type,
                'tool_id': tool_id,
                'tool_kind': tool_kind,
                'public_tool_pending': bool(public_tool_pending),
                'operator_fingerprint': _crossing_select_public_operator_fingerprint(context, area_type),
                'start_event_type': str(getattr(event, 'type', '') or 'LEFTMOUSE'),
                'mode': mode,
                'start': (int(x), int(y)),
                'end': (int(x), int(y)),
                'points': [(int(x), int(y))],
                'radius': _crossing_circle_radius(context, area),
                'preselect': preselect,
            }
            # The native box/lasso/circle selectors run their own modal handler
            # above this passive watcher, so the watcher cannot rely on ever
            # receiving the later CLICK_DRAG / drag / release events — the native
            # modal consumes them.  Poll Blender's completed public operator from
            # the press instead and apply the crossing supplement from its final
            # recorded rectangle / path / center+radius.  (This was previously
            # done only for CIRCLE; BOX and LASSO waited for a CLICK_DRAG or
            # RELEASE that never reached the watcher, so the edge/face crossing
            # supplement never engaged for tool-driven box/lasso gestures.)
            if tool_kind in {'BOX', 'LASSO', 'CIRCLE'}:
                default_idname = _crossing_select_operator_id_for_area(area_type, tool_kind) or 'view3d.select_box'
                info = {
                    'kind': tool_kind,
                    'mode': mode,
                    'idname': str(pending_info.get('idname') or tool_id or default_idname),
                }
                scheduled = _schedule_crossing_public_operator_completion(
                    context,
                    area,
                    region,
                    info,
                    self._state.get('operator_fingerprint') or (),
                    preselect,
                    fallback_shape=None,
                    owner=self,
                    state_token=self._state,
                )
                self._state['public_completion_scheduled'] = bool(scheduled)
            return True
        except Exception:
            self._state = None
            return False

    def _touch(self, context, event):
        del context
        state = self._state
        if not isinstance(state, dict):
            return
        try:
            region = state.get('region')
            x, y = _crossing_select_region_xy(region, event)
            state['end'] = (int(x), int(y))
            tool_kind = str(state.get('tool_kind', '') or '').upper()
            if tool_kind in {'LASSO', 'CIRCLE'}:
                pts = list(state.get('points') or [])
                if not pts or pts[-1] != (int(x), int(y)):
                    pts.append((int(x), int(y)))
                # Keep the lasso/circle trace bounded.  Blender native selection
                # remains authoritative; this trace is only for post-native hit
                # supplementation.
                if len(pts) > 4096:
                    pts = pts[-4096:]
                state['points'] = pts
        except Exception:
            pass

    def _finish(self, context, cancelled=False, await_public_operator=False):
        state = self._state
        self._state = None
        if not isinstance(state, dict):
            return
        if cancelled:
            try:
                if bool(state.get('public_completion_scheduled')):
                    _crossing_next_gesture_generation()
            except Exception:
                pass
            try:
                cu._csdt_apply_crossing_selection_region(context, state.get('area_type', ''), None, mode='SET', area=state.get('area'), region=state.get('region'), region_data=cu._view3d_region_data(state.get('area'), state.get('region')) if state.get('area_type', '') == 'VIEW_3D' else None, preselect=dict(state.get('preselect') or {}), native_select_ok=True, clear_first=False)
            except Exception:
                pass
            return
        try:
            area = state.get('area')
            region = state.get('region')
            window = state.get('window')
            screen = state.get('screen')
            if _csdt_rna_ptr(area) != int(state.get('area_ptr', 0) or 0):
                return
            if _csdt_rna_ptr(region) != int(state.get('region_ptr', 0) or 0):
                return
            area_type = str(state.get('area_type', '') or '')
            mode = str(state.get('mode', 'SET') or 'SET')
            preselect = dict(state.get('preselect') or {})
        except Exception:
            return

        if bool(state.get('public_completion_scheduled')):
            # This gesture already owns a bounded native-operator completion
            # poll scheduled at press time.  Avoid scheduling a second poll or
            # applying a second (stale, watcher-tracked) shape if a platform
            # happens to deliver drag/release events to this lower-priority
            # watcher as well: while the native selector's modal runs, the
            # watcher receives no MOUSEMOVE, so its tracked rectangle would be
            # a tiny box at the drag origin, not the real selection region.
            return

        if await_public_operator:
            info = {
                'kind': str(state.get('tool_kind', '') or '').upper(),
                'mode': mode,
                'idname': str(state.get('tool_id', '') or ''),
            }
            _schedule_crossing_public_operator_completion(
                context,
                area,
                region,
                info,
                state.get('operator_fingerprint') or (),
                preselect,
                fallback_shape=None,
                owner=self,
            )
            return

        callback_ref = {'callback': None, 'done': False}

        def _apply_once():
            callback = callback_ref.get('callback')
            try:
                if bool(callback_ref.get('done', False)):
                    return None
                callback_ref['done'] = True
                ctx = getattr(bpy, 'context', None)
                tool_kind = str(state.get('tool_kind', '') or '').upper()
                if tool_kind not in {'BOX', 'LASSO', 'CIRCLE'}:
                    tool_kind = _crossing_select_recent_public_tool_kind(
                        ctx or bpy.context,
                        area_type,
                        previous_fingerprint=state.get('operator_fingerprint') or (),
                    )
                if tool_kind not in {'BOX', 'LASSO', 'CIRCLE'}:
                    return None
                shape = cu._csdt_crossing_selection_shape(
                    tool_kind,
                    points=list(state.get('points') or []),
                    start=state.get('start'),
                    end=state.get('end'),
                    radius=state.get('radius'),
                )
                if shape is None and tool_kind == 'LASSO':
                    try:
                        pts = list(state.get('points') or [])
                        if len(pts) >= 2:
                            x0, y0 = pts[0]
                            x1, y1 = pts[-1]
                            pad = 10
                            shape = cu._csdt_crossing_selection_shape(
                                'BOX',
                                start=(min(int(x0), int(x1)) - pad, min(int(y0), int(y1)) - pad),
                                end=(max(int(x0), int(x1)) + pad, max(int(y0), int(y1)) + pad),
                            )
                    except Exception:
                        shape = None
                if shape is None:
                    return None
                if ctx is not None and hasattr(ctx, 'temp_override'):
                    override = {'area': area, 'region': region}
                    if window is not None:
                        override['window'] = window
                    if screen is not None:
                        override['screen'] = screen
                    try:
                        override['space_data'] = getattr(getattr(area, 'spaces', None), 'active', None)
                    except Exception:
                        pass
                    try:
                        if area_type == 'VIEW_3D':
                            rv3d = cu._view3d_region_data(area, region)
                            if rv3d is not None:
                                override['region_data'] = rv3d
                    except Exception:
                        pass
                    with ctx.temp_override(**override):
                        cu._csdt_apply_crossing_selection_region(
                            bpy.context,
                            area_type,
                            shape,
                            mode=mode,
                            area=area,
                            region=region,
                            region_data=cu._view3d_region_data(area, region) if area_type == 'VIEW_3D' else None,
                            preselect=preselect,
                            native_select_ok=True,
                            clear_first=False,
                        )
                else:
                    cu._csdt_apply_crossing_selection_region(
                        bpy.context,
                        area_type,
                        shape,
                        mode=mode,
                        area=area,
                        region=region,
                        region_data=cu._view3d_region_data(area, region) if area_type == 'VIEW_3D' else None,
                        preselect=preselect,
                        native_select_ok=True,
                        clear_first=False,
                    )
            finally:
                try:
                    if callback is not None:
                        _CSDT_CROSSING_SELECT_POST_CALLBACKS.discard(callback)
                except Exception:
                    pass
            return None

        callback_ref['callback'] = _apply_once
        _crossing_register_post_callback(_apply_once, first_interval=0.03)

    def modal(self, context, event):
        try:
            if not _crossing_select_prefs_enabled(context):
                # cancel() only cleans up; a modal MUST return a result set.
                # Returning its None return value made Blender report an error
                # and force-kill the operator every time the crossing prefs
                # were switched off while a watcher was alive.
                self.cancel(context)
                return {'CANCELLED'}
            if self._window_ptr and self._window_ptr != _csdt_rna_ptr(getattr(context, 'window', None)):
                return {'PASS_THROUGH'}
            etype = str(getattr(event, 'type', '') or '')
            evalue = str(getattr(event, 'value', '') or '').upper()
            if etype in {'ESC', 'WINDOW_DEACTIVATE'}:
                try:
                    generation = int(getattr(self, '_public_completion_generation', 0) or 0)
                    if generation and generation == int(_CSDT_CROSSING_GESTURE_GENERATION):
                        _crossing_next_gesture_generation()
                    self._public_completion_generation = 0
                except Exception:
                    pass
            event_area = None
            event_region = None
            try:
                event_area, event_region = _crossing_select_event_area_region(context, event)
            except Exception:
                event_area = None
                event_region = None
            key_tool_info = _crossing_select_event_tool_info(context, event_area, event_region, event) if event_area is not None else ({'kind': _crossing_select_key_event_tool_kind(event), 'mode': '', 'idname': '', 'type': etype, 'value': evalue} if _crossing_select_key_event_tool_kind(event) else {})
            key_tool_kind = str(key_tool_info.get('kind', '') or '').upper() if isinstance(key_tool_info, dict) else ''
            if key_tool_kind and evalue == 'PRESS':
                if etype in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
                    self._pending_public_tool_kind = key_tool_kind
                    self._pending_public_tool_info = dict(key_tool_info)
                    self._pending_public_tool_token = None
                    self._begin(context, event)
                else:
                    try:
                        if event_area is not None and event_region is not None:
                            area_type = str(getattr(event_area, 'type', '') or '')
                            preselect = cu._csdt_crossing_preselect_snapshot(
                                context,
                                area_type,
                                include_edges=True,
                                include_faces=True,
                            )
                            _schedule_crossing_public_operator_completion(
                                context,
                                event_area,
                                event_region,
                                dict(key_tool_info),
                                _crossing_select_public_operator_fingerprint(context, area_type),
                                preselect,
                                fallback_shape=None,
                            )
                    except Exception:
                        pass
                return {'PASS_THROUGH'}
            if etype == 'LEFTMOUSE' and evalue == 'PRESS':
                if not str(getattr(self, '_pending_public_tool_kind', '') or ''):
                    try:
                        self._pending_public_tool_kind = ''
                        self._pending_public_tool_info = {}
                        self._pending_public_tool_token = None
                    except Exception:
                        pass
                self._begin(context, event)
                return {'PASS_THROUGH'}
            if isinstance(self._state, dict):
                start_event_type = str(self._state.get('start_event_type', 'LEFTMOUSE') or 'LEFTMOUSE')
                active_tool_kind = str(self._state.get('tool_kind', '') or '').upper()
                if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                    self._touch(context, event)
                    return {'PASS_THROUGH'}
                if etype == start_event_type and evalue in {'CLICK_DRAG', 'TWEAK', 'PRESS_DRAG'} and active_tool_kind == 'LASSO':
                    self._touch(context, event)
                    try:
                        point_count = len(list(self._state.get('points') or []))
                    except Exception:
                        point_count = 0
                    if bool(self._state.get('public_tool_pending')):
                        return {'PASS_THROUGH'}
                    if start_event_type == 'LEFTMOUSE' and point_count >= 2:
                        self._finish(context, cancelled=False, await_public_operator=True)
                        return {'PASS_THROUGH'}
                    return {'PASS_THROUGH'}
                if etype == start_event_type and evalue in {'CLICK_DRAG', 'TWEAK', 'PRESS_DRAG'}:
                    self._touch(context, event)
                    self._finish(context, cancelled=False, await_public_operator=True)
                    return {'PASS_THROUGH'}
                if etype == start_event_type and evalue == 'RELEASE':
                    self._touch(context, event)
                    self._finish(context, cancelled=False)
                    return {'PASS_THROUGH'}
                if etype in {'ESC', 'WINDOW_DEACTIVATE'} or (etype == 'RIGHTMOUSE' and start_event_type != 'RIGHTMOUSE'):
                    self._finish(context, cancelled=True)
                    return {'PASS_THROUGH'}
        except Exception:
            try:
                self._state = None
            except Exception:
                pass
        return {'PASS_THROUGH'}


def _start_crossing_watch_for_window(context, window):
    try:
        win_ptr = _csdt_rna_ptr(window)
        if win_ptr and _CSDT_CROSSING_SELECT_WATCHERS.get(win_ptr) is not None:
            return True
        if context is None or window is None:
            return False
        area = None
        region = None
        screen = getattr(window, 'screen', None)
        for candidate_area in getattr(screen, 'areas', []) or []:
            if not _crossing_select_area_supported(candidate_area):
                continue
            for candidate_region in getattr(candidate_area, 'regions', []) or []:
                if getattr(candidate_region, 'type', None) == 'WINDOW':
                    area = candidate_area
                    region = candidate_region
                    break
            if area is not None:
                break
        if area is None or region is None:
            return False
        with context.temp_override(window=window, screen=screen, area=area, region=region, space_data=getattr(getattr(area, 'spaces', None), 'active', None)):
            result = bpy.ops.wm.sts_crossing_select_watch('INVOKE_DEFAULT')
        return not (isinstance(result, set) and 'CANCELLED' in result)
    except Exception:
        try:
            with context.temp_override(window=window, screen=screen):
                result = bpy.ops.wm.sts_crossing_select_watch('INVOKE_DEFAULT')
            return not (isinstance(result, set) and 'CANCELLED' in result)
        except Exception:
            return False


def _stop_crossing_select_watchers():
    global _CSDT_CROSSING_SELECT_ENSURE_CALLBACK, _CSDT_CROSSING_SELECT_ENSURE_REMAINING
    try:
        if _CSDT_CROSSING_SELECT_ENSURE_CALLBACK is not None and bpy.app.timers.is_registered(_CSDT_CROSSING_SELECT_ENSURE_CALLBACK):
            bpy.app.timers.unregister(_CSDT_CROSSING_SELECT_ENSURE_CALLBACK)
    except Exception:
        pass
    _CSDT_CROSSING_SELECT_ENSURE_CALLBACK = None
    _CSDT_CROSSING_SELECT_ENSURE_REMAINING = 0
    _crossing_unregister_post_callbacks()
    for _win_ptr, op in list(_CSDT_CROSSING_SELECT_WATCHERS.items()):
        try:
            op._state = None
        except Exception:
            pass
    try:
        _CSDT_CROSSING_SELECT_WATCHERS.clear()
    except Exception:
        pass


def _ensure_crossing_select_watchers_once(context=None):
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None or not _crossing_select_prefs_enabled(ctx):
        _stop_crossing_select_watchers()
        return False
    started_any = False
    try:
        wm = getattr(ctx, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        windows = list(getattr(wm, 'windows', []) or [])
    except Exception:
        windows = []
    live_ptrs = set(_csdt_rna_ptr(win) for win in windows)
    for ptr, op in list(_CSDT_CROSSING_SELECT_WATCHERS.items()):
        if ptr not in live_ptrs or op is None:
            try:
                _CSDT_CROSSING_SELECT_WATCHERS.pop(ptr, None)
            except Exception:
                pass
    for window in windows:
        try:
            if _start_crossing_watch_for_window(ctx, window):
                started_any = True
        except Exception:
            pass
    return started_any


def _schedule_crossing_select_watchers(context=None, attempts=6):
    global _CSDT_CROSSING_SELECT_ENSURE_CALLBACK, _CSDT_CROSSING_SELECT_ENSURE_REMAINING
    ctx = context or getattr(bpy, 'context', None)
    if ctx is None:
        return
    if not _crossing_select_prefs_enabled(ctx):
        _stop_crossing_select_watchers()
        return
    try:
        if _CSDT_CROSSING_SELECT_ENSURE_CALLBACK is not None and bpy.app.timers.is_registered(_CSDT_CROSSING_SELECT_ENSURE_CALLBACK):
            return
    except Exception:
        pass
    _CSDT_CROSSING_SELECT_ENSURE_REMAINING = max(1, int(attempts))

    def _tick():
        global _CSDT_CROSSING_SELECT_ENSURE_CALLBACK, _CSDT_CROSSING_SELECT_ENSURE_REMAINING
        global _CSDT_CROSSING_SELECT_ENSURE_WARNED
        try:
            if not _crossing_select_prefs_enabled(getattr(bpy, 'context', None)):
                _CSDT_CROSSING_SELECT_ENSURE_CALLBACK = None
                _CSDT_CROSSING_SELECT_ENSURE_REMAINING = 0
                _stop_crossing_select_watchers()
                return None
            _ensure_crossing_select_watchers_once(getattr(bpy, 'context', None))
            if _CSDT_CROSSING_SELECT_ENSURE_REMAINING > 0:
                _CSDT_CROSSING_SELECT_ENSURE_REMAINING -= 1
            if _CSDT_CROSSING_SELECT_ENSURE_REMAINING > 0:
                return 0.12
            # Keep-alive: while the crossing prefs stay enabled, keep
            # re-ensuring watchers at a low cadence so a window opened later,
            # a reopened window, or a watcher Blender cancelled for any reason
            # gets its watcher back without a file load or prefs toggle.
            # The per-window registry check makes this idempotent and cheap.
            return 2.0
        except Exception as exc:
            # Keep-alive guard: report once, never die while prefs are on.
            if not _CSDT_CROSSING_SELECT_ENSURE_WARNED:
                _CSDT_CROSSING_SELECT_ENSURE_WARNED = True
                try:
                    print("[Smart Transform] crossing-select watcher keep-alive error (reported once): %r" % (exc,))
                except Exception:
                    pass
            return 2.0

    _CSDT_CROSSING_SELECT_ENSURE_CALLBACK = _tick
    try:
        _ensure_crossing_select_watchers_once(ctx)
    except Exception:
        pass
    try:
        bpy.app.timers.register(_tick, first_interval=0.03)
    except Exception:
        _CSDT_CROSSING_SELECT_ENSURE_CALLBACK = None


def _sync_crossing_select_runtime(context=None):
    try:
        if _crossing_select_prefs_enabled(context or getattr(bpy, 'context', None)):
            _schedule_crossing_select_watchers(context or getattr(bpy, 'context', None), attempts=6)
        else:
            _stop_crossing_select_watchers()
    except Exception:
        pass


_CSDT_CROSSING_CLASSES = (WM_OT_sts_crossing_select_watch,)


def ensure_csdt_keymap_repair_runtime(context=None) -> None:
    """Repair only the Smart Gizmo click keymap route when it is enabled."""
    try:
        sync_runtime_from_prefs(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    return

def register():
    for c in tuple(_CSDT_CROSSING_CLASSES) + tuple(classes):
        try:
            _safe_register_class(c)
        except ValueError:
            try:
                _safe_unregister_class(c)
            except Exception:
                pass
            bpy.utils.register_class(c)
    try:
        sync_runtime_from_prefs(getattr(bpy, 'context', None))
    except Exception:
        pass


def unregister():
    stop_constraint_watchdog()
    try:
        _stop_crossing_select_watchers()
    except Exception:
        pass
    try:
        _cleanup_background_box_preview_registry(force=True)
    except Exception:
        pass
    try:
        _stop_csdt_keymap_sync()
    except Exception:
        pass
    try:
        _remove_km_items()
    except Exception:
        pass
    try:
        _remove_csdt_load_handlers()
    except Exception:
        pass
    for c in reversed(tuple(_CSDT_CROSSING_CLASSES) + tuple(classes)):
        _safe_unregister_class(c)
