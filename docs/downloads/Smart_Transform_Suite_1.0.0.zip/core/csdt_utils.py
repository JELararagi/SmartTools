﻿# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import bmesh
import math
import time
import sys
import gpu
from bpy_extras import view3d_utils
from mathutils.bvhtree import BVHTree
from mathutils import Vector, Matrix
from mathutils.kdtree import KDTree
try:
    import numpy as _np
except Exception:
    _np = None
from contextlib import contextmanager

from . import csdt_globals as cg
from .. import runtime as _runtime

_CSDT_CONSTRAINT_WATCHDOG_LAST_ACTIVE = 0.0
_CSDT_CONSTRAINT_WATCHDOG_IDLE_SECONDS = 3.0
_CSDT_LEGACY_WATCHDOGS_NEUTRALIZED = False

# Performance guardrails for Smart Gizmo's deterministic edit-mesh selection fallbacks.
# The fast Blender-native selection path remains the primary route; these Python
# fallbacks are capped so dense meshes cannot make the viewport progressively heavy.
_CSDT_EDGE_CLICK_FALLBACK_MAX_EDGES = 24000
_CSDT_EDGE_CLICK_FALLBACK_TIME_BUDGET = 0.010
_CSDT_EDGE_BOX_SUPPLEMENT_MAX_EDGES_NATIVE_OK = 70000
_CSDT_EDGE_BOX_SUPPLEMENT_MAX_EDGES_NATIVE_FAILED = 140000
_CSDT_EDGE_BOX_SUPPLEMENT_TIME_BUDGET_NATIVE_OK = 0.035
_CSDT_EDGE_BOX_SUPPLEMENT_TIME_BUDGET_NATIVE_FAILED = 0.080
_CSDT_CROSSING_SELECTION_MAX_ELEMENTS_NATIVE_OK = 90000
_CSDT_CROSSING_SELECTION_MAX_ELEMENTS_NATIVE_FAILED = 160000
_CSDT_CROSSING_SELECTION_TIME_BUDGET_NATIVE_OK = 0.045
_CSDT_CROSSING_SELECTION_TIME_BUDGET_NATIVE_FAILED = 0.090
# The X-ray-off visibility test (occlusion BVH build + ray casts) is charged to its
# own allowance.  Charging it to the element-walk budget above cut the walk off at
# the 512th element of a ~1k-edge mesh and left visible crossing edges unselected.
_CSDT_CROSSING_SELECTION_VISIBILITY_TIME_BUDGET_NATIVE_OK = 0.45
_CSDT_CROSSING_SELECTION_VISIBILITY_TIME_BUDGET_NATIVE_FAILED = 0.90
_CSDT_CROSSING_SELECTION_EDGE_PAD = 1.5
_CSDT_CROSSING_SELECTION_FACE_PAD = 0.75

# Low-latency Immediate Select hit cache.  The cache stores screen-space
# positions for editable mesh elements for the current View3D matrix and object
# matrix.  Selection state is read fresh from BMesh on every query, so cached
# geometry can be reused across selection changes while still returning accurate
# selected/unselected flags.
_CSDT_EDITMESH_SCREEN_HIT_CACHE = {}
_CSDT_EDITMESH_SCREEN_HIT_CACHE_MAX_ITEMS = 10
_CSDT_EDITMESH_SCREEN_HIT_CACHE_TTL = 1.25
_CSDT_EDITMESH_SCREEN_HIT_CACHE_MAX_COMPONENTS = 220000
# 即時選択のホバーの先読みの動き。None は本物のクリック。'hover' はマウスが動いている間、
# 'rest' はマウスが止まった後。先読みでは全要素の総当たりの走査をしない（外れは貯めないので、
# 先読みの総当たりは毎回捨てられる）。'hover' では大きなメッシュの貯めを作らない
# （作るのはマウスが止まった後の 'rest' だけ）。
_CSDT_PREFETCH_MODE = None
_CSDT_HOVER_PREFETCH_BUILD_MAX_COMPONENTS = 20000
_CSDT_EDITMESH_SCREEN_HIT_CACHE_CELL_MIN = 10.0
_CSDT_EDITMESH_SCREEN_HIT_CACHE_CELL_MAX = 48.0
_CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE = {}
_CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE_TTL = 8.0
_CSDT_IMMEDIATE_SELECT_PREFETCH_HIT = None
_CSDT_IMMEDIATE_SELECT_PREFETCH_TTL = 0.45
_CSDT_IMMEDIATE_SELECT_PREFETCH_MAX_DELTA = 4.0

# Optional click-through/cycle state for back-side editable elements.  It is
# used only when the user enables Backside Element Click Select in the N-panel,
# so the default front/visible click behavior stays unchanged.
_CSDT_BACKSIDE_CLICK_CYCLE = None
_CSDT_BACKSIDE_CLICK_CYCLE_TTL = 0.85
_CSDT_BACKSIDE_CLICK_MAX_CANDIDATES = 64


def _mark_csdt_constraint_watchdog_use() -> None:
    global _CSDT_CONSTRAINT_WATCHDOG_LAST_ACTIVE
    try:
        _CSDT_CONSTRAINT_WATCHDOG_LAST_ACTIVE = time.time()
    except Exception:
        _CSDT_CONSTRAINT_WATCHDOG_LAST_ACTIVE = 0.0


# =========================
# Cache Invalidation (Ghost Fix)
# =========================
def _invalidate_gizmo_cache():
    """選択や変形が切り替わった瞬間に古いスマートギズモ表示キャッシュを破棄する"""
    try:
        cg._SMART_GIZMO_CACHE["time"] = 0.0
        cg._SMART_GIZMO_CACHE["sig"] = None
        cg._SMART_GIZMO_CACHE["pivot"] = None
    except Exception:
        pass

# =========================
# GPU Shader Compatibility
# =========================
def _csdt_get_shader_3d_uniform():
    if cg._CSDT_GPU_SHADER_3D_UNIFORM is not None:
        return cg._CSDT_GPU_SHADER_3D_UNIFORM
    for name in ("UNIFORM_COLOR", "3D_UNIFORM_COLOR", "3D_FLAT_COLOR"):
        try:
            cg._CSDT_GPU_SHADER_3D_UNIFORM = gpu.shader.from_builtin(name)
            return cg._CSDT_GPU_SHADER_3D_UNIFORM
        except Exception:
            continue
    if not cg._CSDT_GPU_SHADER_WARNED:
        cg._CSDT_GPU_SHADER_WARNED = True
        try:
            print("[Smart Transform Tools] WARNING: could not acquire a built-in 3D uniform color shader.")
        except Exception:
            pass
    return None

def _csdt_get_shader_2d_uniform():
    if cg._CSDT_GPU_SHADER_2D_UNIFORM is not None:
        return cg._CSDT_GPU_SHADER_2D_UNIFORM
    for name in ("UNIFORM_COLOR", "2D_UNIFORM_COLOR"):
        try:
            cg._CSDT_GPU_SHADER_2D_UNIFORM = gpu.shader.from_builtin(name)
            return cg._CSDT_GPU_SHADER_2D_UNIFORM
        except Exception:
            continue
    return None

# =========================
# Preferences (SAFE & FAST)
# =========================
def _prefs(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None


def _csdt_select_guard_filters_occlusion(context=None) -> bool:
    """True while Smart Select Guard rejects occluded targets in this view.

    Mirrors the guard's own bypass rules (X-Ray / Wireframe auto bypass).
    """
    try:
        if context is None:
            context = bpy.context
        scene = getattr(context, 'scene', None)
        if scene is None or not bool(getattr(scene, 'select_guard_enabled', False)):
            return False
        space = getattr(context, 'space_data', None)
        if space is None or getattr(space, 'type', None) != 'VIEW_3D':
            area = getattr(context, 'area', None)
            space = area.spaces.active if area is not None and getattr(area, 'type', None) == 'VIEW_3D' else None
        shading = getattr(space, 'shading', None) if space is not None else None
        if shading is not None:
            wireframe = str(getattr(shading, 'type', '') or '') == 'WIREFRAME'
            xray = bool(getattr(shading, 'show_xray_wireframe', False)) if wireframe else bool(getattr(shading, 'show_xray', False))
            if xray and bool(getattr(scene, 'ssg_auto_bypass_xray', True)):
                return False
            if wireframe and bool(getattr(scene, 'ssg_auto_bypass_wireframe', True)):
                return False
        return True
    except Exception:
        return False


def _csdt_backside_element_click_select_enabled(context=None) -> bool:
    try:
        prefs = _prefs(context)
        if prefs is None:
            return False
        # Canonical name used by this build.  The shorter alias is accepted so
        # partially migrated development builds do not silently lose the setting.
        enabled = bool(
            getattr(prefs, 'enable_backside_element_click_select',
                    getattr(prefs, 'enable_back_element_click_select', False))
        )
        # While Smart Select Guard filters occluded targets, the Select tool's
        # repeated click stays on the front element.  The Move/Rotate/Scale
        # tools' click select follows the same order instead of cycling behind.
        if enabled and _csdt_select_guard_filters_occlusion(context):
            return False
        return enabled
    except Exception:
        return False


def _csdt_crossing_selection_flags(context=None):
    """Return (edge_enabled, face_enabled) for optional region crossing select."""
    try:
        prefs = _prefs(context)
        if prefs is None:
            return False, False
        return (
            bool(getattr(prefs, 'crossing_select_edges', False)),
            bool(getattr(prefs, 'crossing_select_faces', False)),
        )
    except Exception:
        return False, False


def _csdt_crossing_selection_enabled(context=None) -> bool:
    try:
        edge_enabled, face_enabled = _csdt_crossing_selection_flags(context)
        return bool(edge_enabled or face_enabled)
    except Exception:
        return False


def _csdt_backside_cycle_signature(context, obj, mx, my, component_kind, candidates):
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        obj_ptr = int(obj.as_pointer()) if obj is not None else 0
        data_ptr = int(obj.data.as_pointer()) if obj is not None and getattr(obj, 'data', None) is not None else 0
        region_ptr = int(region.as_pointer()) if region is not None else 0
        rv3d_ptr = int(rv3d.as_pointer()) if rv3d is not None else 0
    except Exception:
        obj_ptr = id(obj); data_ptr = id(getattr(obj, 'data', None)); region_ptr = 0; rv3d_ptr = 0
    try:
        ids = tuple((str(c[0]), int(c[1])) for c in list(candidates)[:int(_CSDT_BACKSIDE_CLICK_MAX_CANDIDATES)])
    except Exception:
        ids = ()
    return (obj_ptr, data_ptr, region_ptr, rv3d_ptr, str(component_kind or ''), int(round(float(mx))), int(round(float(my))), ids)


def _csdt_choose_backside_click_candidate(context, obj, mx, my, component_kind, candidates):
    """Choose a configured-radius edit element, cycling through overlapped hits.

    With Backside Element Click Select enabled, click selection must be able to
    reach elements that are behind another element in the same screen-space hit
    range.  Blender's native single click normally takes only the front ray-hit.
    This routine keeps the first click front-like, then cycles to the next
    candidate on repeated clicks at the same screen position.
    """
    global _CSDT_BACKSIDE_CLICK_CYCLE
    try:
        if not candidates:
            _CSDT_BACKSIDE_CLICK_CYCLE = None
            return None
        candidates = list(candidates)[:int(_CSDT_BACKSIDE_CLICK_MAX_CANDIDATES)]
        sig = _csdt_backside_cycle_signature(context, obj, mx, my, component_kind, candidates)
        now = time.perf_counter()
        index = 0
        old = _CSDT_BACKSIDE_CLICK_CYCLE
        if isinstance(old, dict) and old.get('sig') == sig and (now - float(old.get('time', 0.0) or 0.0)) <= float(_CSDT_BACKSIDE_CLICK_CYCLE_TTL):
            try:
                index = (int(old.get('index', -1)) + 1) % max(1, len(candidates))
            except Exception:
                index = 0
        _CSDT_BACKSIDE_CLICK_CYCLE = {'sig': sig, 'index': index, 'time': now}
        return candidates[index]
    except Exception:
        try:
            return candidates[0] if candidates else None
        except Exception:
            return None

# =========================
# View3D Context Helpers
# =========================
def _view3d_window_regions(area):
    """Return WINDOW regions for a View3D area without changing selection context."""
    try:
        if area is None or getattr(area, "type", None) != "VIEW_3D":
            return []
        return [r for r in getattr(area, "regions", []) if getattr(r, "type", None) == "WINDOW"]
    except Exception:
        return []


def _view3d_region_data(area=None, region=None, mx=None, my=None):
    """Return the active RegionView3D for a View3D WINDOW region.

    In normal single-view layouts, ``region.data`` is the correct source.  In
    Quad View, Blender 5.1 can expose one physical WINDOW region whose
    ``region.data`` keeps pointing at the last active pane while the mouse is in
    another quadrant.  Whenever caller-provided region-local mouse coordinates
    are available, the quadrant under that coordinate is therefore the source of
    truth for Smart Gizmo / Smart G-R-S view-orientation math and edit-element
    hit tests.  Calls without coordinates keep the native ``region.data``
    behavior so Blender operators still receive the physical View3D context.
    """
    try:
        if mx is not None and my is not None and _quadview_layout_active(area):
            rv3d = _quadview_region_data_from_region_xy(area, region, mx, my)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    try:
        if region is not None:
            rv3d = getattr(region, "data", None)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    try:
        if area is not None:
            space = getattr(getattr(area, "spaces", None), "active", None)
            rv3d = getattr(space, "region_3d", None)
            if rv3d is not None:
                return rv3d
            quadviews = list(getattr(space, "region_quadviews", []) or []) if space is not None else []
            if quadviews:
                return quadviews[0]
    except Exception:
        pass
    return None


def _quadview_index_from_region_xy(area, region, mx, my):
    """Return the Quad View quadrant index for physical region-local coords.

    The returned order follows Blender's visible layout used by Quad View:
    lower-left, upper-left, lower-right, upper-right.  If Quad View is not active
    or the coordinate cannot be evaluated, ``None`` is returned.
    """
    try:
        space = getattr(getattr(area, "spaces", None), "active", None)
        quadviews = list(getattr(space, "region_quadviews", []) or []) if space is not None else []
        if len(quadviews) < 4:
            return None
        width = float(getattr(region, "width", 0) or 0)
        height = float(getattr(region, "height", 0) or 0)
        if width <= 0.0 or height <= 0.0:
            return None
        x = max(0.0, min(width - 1.0, float(mx)))
        y = max(0.0, min(height - 1.0, float(my)))
        left = x < (width * 0.5)
        bottom = y < (height * 0.5)
        return 0 if (left and bottom) else 1 if (left and not bottom) else 2 if ((not left) and bottom) else 3
    except Exception:
        return None


def _quadview_region_data_from_region_xy(area, region, mx, my):
    try:
        idx = _quadview_index_from_region_xy(area, region, mx, my)
        if idx is None:
            return None
        space = getattr(getattr(area, "spaces", None), "active", None)
        quadviews = list(getattr(space, "region_quadviews", []) or []) if space is not None else []
        if 0 <= int(idx) < len(quadviews):
            return quadviews[int(idx)]
    except Exception:
        pass
    return None




def _quadview_region_index_from_region_data(area, rv3d):
    """Return Quad View index for a RegionView3D object, or None."""
    try:
        if area is None or rv3d is None:
            return None
        space = getattr(getattr(area, "spaces", None), "active", None)
        quadviews = list(getattr(space, "region_quadviews", []) or []) if space is not None else []
        if len(quadviews) < 4:
            return None
        rv_ptr = rv3d.as_pointer() if hasattr(rv3d, 'as_pointer') else None
        for idx, qrv3d in enumerate(quadviews[:4]):
            try:
                if qrv3d is rv3d:
                    return int(idx)
                if rv_ptr is not None and hasattr(qrv3d, 'as_pointer') and qrv3d.as_pointer() == rv_ptr:
                    return int(idx)
            except Exception:
                pass
    except Exception:
        pass
    return None


def _quadview_layout_active(area):
    """True when the area is in Quad View and visible panes need coordinate mapping."""
    try:
        if area is None or getattr(area, "type", None) != "VIEW_3D":
            return False
        space = getattr(getattr(area, "spaces", None), "active", None)
        quadviews = list(getattr(space, "region_quadviews", []) or []) if space is not None else []
        if len(quadviews) < 4:
            return False
        windows = _view3d_window_regions(area)
        if not windows:
            return False
        # Blender 5.1 exposes four WINDOW regions with identical bounds in Quad
        # View.  Some builds expose only one physical WINDOW region.  Both forms
        # use full-region projection coordinates while the visible panes occupy
        # quadrants, so hit tests must remap coordinates.
        if len(windows) < 4:
            return True
        try:
            b0 = (int(windows[0].x), int(windows[0].y), int(windows[0].width), int(windows[0].height))
            return all((int(r.x), int(r.y), int(r.width), int(r.height)) == b0 for r in windows[:4])
        except Exception:
            return True
    except Exception:
        return False


def _quadview_visible_rect(area, region, idx=None, mx=None, my=None, rv3d=None):
    """Return the visible quadrant rect in physical region-local coordinates."""
    try:
        if area is None or region is None or not _quadview_layout_active(area):
            return None
        # For visible click/drag coordinates, the pointer quadrant is the most
        # reliable source of truth.  In Blender Quad View, context.region_data can
        # continue to point at the first sub-view even while the mouse is in a
        # different visible quadrant; using it first remaps upper/right panes to
        # impossible projection coordinates and makes click/box selection miss.
        if idx is None and mx is not None and my is not None:
            idx = _quadview_index_from_region_xy(area, region, mx, my)
        if idx is None and rv3d is not None:
            idx = _quadview_region_index_from_region_data(area, rv3d)
        if idx is None:
            return None
        width = float(getattr(region, "width", 0) or 0)
        height = float(getattr(region, "height", 0) or 0)
        if width <= 0.0 or height <= 0.0:
            return None
        hw = width * 0.5
        hh = height * 0.5
        idx = int(idx)
        if idx == 0:      # lower-left
            return (0.0, 0.0, hw, hh)
        if idx == 1:      # upper-left
            return (0.0, hh, hw, hh)
        if idx == 2:      # lower-right
            return (hw, 0.0, hw, hh)
        if idx == 3:      # upper-right
            return (hw, hh, hw, hh)
    except Exception:
        pass
    return None


def _quadview_visible_xy_to_projection_xy(context_or_area, mx, my, region=None, rv3d=None):
    """Convert visible Quad View pane coordinates to full projection coordinates.

    Blender's projection helpers use full WINDOW-region coordinates even though
    Quad View panes are displayed in half-size quadrants.  Selection receives the
    visible quadrant-local coordinates from the event, so deterministic hit tests
    must convert them before using matrices/raycast helpers.
    """
    try:
        area = context_or_area
        if hasattr(context_or_area, 'area'):
            area = getattr(context_or_area, 'area', None)
            if region is None:
                region = getattr(context_or_area, 'region', None)
            if rv3d is None:
                rv3d = getattr(context_or_area, 'region_data', None)
        if area is None or region is None or not _quadview_layout_active(area):
            return float(mx), float(my)
        rect = _quadview_visible_rect(area, region, mx=mx, my=my, rv3d=rv3d)
        if rect is None:
            return float(mx), float(my)
        x0, y0, w, h = rect
        rw = float(getattr(region, 'width', 0) or 0)
        rh = float(getattr(region, 'height', 0) or 0)
        if w <= 0.0 or h <= 0.0 or rw <= 0.0 or rh <= 0.0:
            return float(mx), float(my)
        return ((float(mx) - x0) * (rw / w), (float(my) - y0) * (rh / h))
    except Exception:
        return float(mx), float(my)


def _quadview_projection_xy_to_visible_xy(context_or_area, px, py, region=None, rv3d=None, idx=None):
    """Convert full projection coordinates to visible Quad View pane coordinates."""
    try:
        area = context_or_area
        if hasattr(context_or_area, 'area'):
            area = getattr(context_or_area, 'area', None)
            if region is None:
                region = getattr(context_or_area, 'region', None)
            if rv3d is None:
                rv3d = getattr(context_or_area, 'region_data', None)
        if area is None or region is None or not _quadview_layout_active(area):
            return float(px), float(py)
        rect = _quadview_visible_rect(area, region, idx=idx, rv3d=rv3d)
        if rect is None:
            return float(px), float(py)
        x0, y0, w, h = rect
        rw = float(getattr(region, 'width', 0) or 0)
        rh = float(getattr(region, 'height', 0) or 0)
        if w <= 0.0 or h <= 0.0 or rw <= 0.0 or rh <= 0.0:
            return float(px), float(py)
        return (x0 + (float(px) * (w / rw)), y0 + (float(py) * (h / rh)))
    except Exception:
        return float(px), float(py)




def _quadview_visible_to_projection_scale(context_or_area, region=None, rv3d=None, mx=None, my=None):
    """Return projection-pixels per visible Quad View pixel."""
    try:
        area = context_or_area
        if hasattr(context_or_area, 'area'):
            area = getattr(context_or_area, 'area', None)
            if region is None:
                region = getattr(context_or_area, 'region', None)
            if rv3d is None:
                rv3d = getattr(context_or_area, 'region_data', None)
        if area is None or region is None or not _quadview_layout_active(area):
            return 1.0
        rect = _quadview_visible_rect(area, region, mx=mx, my=my, rv3d=rv3d)
        if rect is None:
            return 1.0
        _x0, _y0, w, h = rect
        rw = float(getattr(region, 'width', 0) or 0)
        rh = float(getattr(region, 'height', 0) or 0)
        if w <= 0.0 or h <= 0.0 or rw <= 0.0 or rh <= 0.0:
            return 1.0
        return max(rw / w, rh / h)
    except Exception:
        return 1.0

def _quadview_visible_rect_to_projection_rect(context_or_area, rect, region=None, rv3d=None):
    """Convert a visible Quad View selection rectangle to projection coordinates."""
    try:
        if rect is None:
            return None
        x0, x1, y0, y1 = rect
        cx = (float(x0) + float(x1)) * 0.5
        cy = (float(y0) + float(y1)) * 0.5
        area = context_or_area
        if hasattr(context_or_area, 'area'):
            area = getattr(context_or_area, 'area', None)
            if region is None:
                region = getattr(context_or_area, 'region', None)
            if rv3d is None:
                rv3d = getattr(context_or_area, 'region_data', None)
        if area is None or region is None or not _quadview_layout_active(area):
            return rect
        pr0 = _quadview_visible_xy_to_projection_xy(area, x0, y0, region=region, rv3d=rv3d)
        pr1 = _quadview_visible_xy_to_projection_xy(area, x1, y1, region=region, rv3d=rv3d)
        return _csdt_screen_rect_from_points(pr0, pr1)
    except Exception:
        return rect

def _event_inside_region(region, wx, wy):
    try:
        rx = int(getattr(region, "x", 0) or 0)
        ry = int(getattr(region, "y", 0) or 0)
        rw = int(getattr(region, "width", 0) or 0)
        rh = int(getattr(region, "height", 0) or 0)
        return rw > 0 and rh > 0 and rx <= int(wx) < rx + rw and ry <= int(wy) < ry + rh
    except Exception:
        return False


def _event_view3d_area_region(context, event):
    """Return the physical View3D WINDOW region under a pointer event.

    Do not substitute Quad View pseudo/sub regions here.  The physical region is
    what Blender's click selection and select_box operators expect.  Quad-specific
    RegionView3D selection is handled separately by ``_view3d_region_data(..., mx, my)``.
    """
    try:
        wx = int(getattr(event, "mouse_x", 0))
        wy = int(getattr(event, "mouse_y", 0))
        area0 = getattr(context, "area", None)
        region0 = getattr(context, "region", None)
        if getattr(area0, "type", None) == "VIEW_3D" and getattr(region0, "type", None) == "WINDOW" and _event_inside_region(region0, wx, wy):
            if _quadview_layout_active(area0):
                try:
                    idx = _quadview_index_from_region_xy(area0, region0, wx - int(getattr(region0, 'x', 0) or 0), wy - int(getattr(region0, 'y', 0) or 0))
                    windows = _view3d_window_regions(area0)
                    if idx is not None and 0 <= int(idx) < len(windows):
                        return area0, windows[int(idx)]
                except Exception:
                    pass
            return area0, region0
        win = getattr(context, "window", None)
        area, region = _find_view3d_area_region_at_win_xy(win, wx, wy)
        if area is not None and region is not None:
            return area, region
    except Exception:
        pass
    return _get_view3d_area_region(context)


def _event_view3d_area_region_xy_rv3d(context, event):
    """Return (area, physical_region, mx, my, RegionView3D) for a pointer event.

    Quad View requires two separate concepts: the physical WINDOW region used by
    Blender operators, and the visible sub-view RegionView3D under the mouse.
    Some Blender 5.1 builds expose a region.data that keeps pointing at another
    sub-view even when the pointer is in a different quadrant.  For pointer-based
    Smart Gizmo / Smart G-R-S math, the mouse quadrant is therefore the source of
    truth for the RegionView3D.
    """
    try:
        area, region = _event_view3d_area_region(context, event)
        if area is None or region is None:
            return None, None, 0, 0, None
        wx = int(getattr(event, "mouse_x", 0))
        wy = int(getattr(event, "mouse_y", 0))
        mx = wx - int(getattr(region, "x", 0) or 0)
        my = wy - int(getattr(region, "y", 0) or 0)
        rv3d = None
        try:
            if _quadview_layout_active(area):
                rv3d = _quadview_region_data_from_region_xy(area, region, mx, my)
        except Exception:
            rv3d = None
        if rv3d is None:
            rv3d = _view3d_region_data(area, region, mx, my)
        return area, region, int(mx), int(my), rv3d
    except Exception:
        return None, None, 0, 0, None


def _get_view3d_area_region(context):
    if not context: return None, None
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    if area and area.type == "VIEW_3D" and region and region.type == "WINDOW":
        return area, region

    win = getattr(context, "window", None)
    screen = getattr(win, "screen", None) if win else getattr(context, "screen", None)
    if not screen:
        return None, None

    for a in screen.areas:
        if a.type != "VIEW_3D":
            continue
        for r in a.regions:
            if r.type == "WINDOW":
                return a, r

    return None, None

@contextmanager
def _temp_override_view3d(context, area=None, region=None, region_data=None):
    if area is None or region is None:
        area, region = _get_view3d_area_region(context)
    win = getattr(context, "window", None)
    if area and region and hasattr(context, "temp_override"):
        try:
            override = {"area": area, "region": region}
            if win:
                override["window"] = win
            try:
                space = area.spaces.active
                override["space_data"] = space
                rv3d = region_data
                # In Quad View, the active sub-view RegionView3D is often already
                # supplied by Blender through the current context.  Prefer it when
                # the physical area/region match; otherwise native selection may be
                # executed with the wrong sub-view and appear to do nothing.
                if rv3d is None:
                    try:
                        if getattr(context, 'area', None) is area and getattr(context, 'region', None) is region:
                            rv3d = getattr(context, 'region_data', None)
                    except Exception:
                        rv3d = None
                if rv3d is None:
                    rv3d = _view3d_region_data(area, region)
                if rv3d is not None:
                    override["region_data"] = rv3d
            except Exception:
                pass
            with context.temp_override(**override):
                yield
                return
        except Exception:
            pass
    yield

def _smart_find_area_region_rv3d_from_viewport():
    try:
        vx, vy, vw, vh = gpu.state.viewport_get()
        vx, vy, vw, vh = int(vx), int(vy), int(vw), int(vh)
    except Exception:
        return None, None, None

    try:
        wm = bpy.context.window_manager
        windows = getattr(wm, "windows", [])
    except Exception:
        windows = []

    try:
        cx = vx + max(1, vw) // 2
        cy = vy + max(1, vh) // 2
        for win in windows:
            area, region = _find_view3d_area_region_at_win_xy(win, cx, cy)
            if area is not None and region is not None:
                rv3d = _view3d_region_data(area, region)
                if rv3d is not None:
                    return area, region, rv3d
    except Exception:
        pass

    for win in windows:
        screen = getattr(win, "screen", None)
        if not screen:
            continue
        for area in getattr(screen, "areas", []):
            if getattr(area, "type", None) != "VIEW_3D":
                continue
            for region in getattr(area, "regions", []):
                if getattr(region, "type", None) != "WINDOW":
                    continue
                try:
                    if (abs(int(region.x) - vx) <= 6 and abs(int(region.y) - vy) <= 6 and
                        abs(int(region.width) - vw) <= 6 and abs(int(region.height) - vh) <= 6):
                        rv3d = getattr(region, "data", None)
                        if rv3d:
                            return area, region, rv3d
                except Exception:
                    continue

    return None, None, None

def _view3d_select_at(context, mx, my, *, extend=False, deselect=False, toggle=False, disallow_object_select=True):
    with _temp_override_view3d(context):
        base = {"location": (mx, my)}
        if disallow_object_select:
            base["object"] = False

        call_modes = (None, "INVOKE_DEFAULT")
        arg_sets = (
            dict(base, extend=extend, deselect=deselect, toggle=toggle),
            dict(base, extend=extend, deselect=deselect),
            dict(base, extend=extend),
            dict(base),
        )

        for cm in call_modes:
            for kwargs in arg_sets:
                try:
                    if cm:
                        bpy.ops.view3d.select(cm, **kwargs)
                    else:
                        bpy.ops.view3d.select(**kwargs)
                    _invalidate_gizmo_cache()
                    return True
                except TypeError:
                    continue
                except RuntimeError:
                    _invalidate_gizmo_cache()
                    return True
    return False

# =========================
# Last Constraint Tracking
# =========================
def _coerce_constraint_axis(val):
    try:
        return (bool(val[0]), bool(val[1]), bool(val[2]))
    except Exception:
        return (False, False, False)

def _csdt_constraint_watchdog():
    global _CSDT_CONSTRAINT_WATCHDOG_LAST_ACTIVE
    # Blender 5.1 can crash while resolving bpy.context.active_operator from a
    # timer during edit-mode/operator transitions.  Do not read that RNA path
    # from the watchdog; the constraint memory is updated by explicit Smart
    # Transform input paths instead.
    _CSDT_CONSTRAINT_WATCHDOG_LAST_ACTIVE = 0.0
    return None



def _neutralize_legacy_constraint_watchdogs() -> None:
    """Disable stale Smart Transform constraint watchdog timers once per import.

    Blender 5.1 can crash if an old timer callback resolves transient RNA paths
    such as active_operator during edit-mode or operator transitions.  This guard
    intentionally scans broadly for Smart Transform watchdog callbacks because
    previously installed builds may remain in sys.modules under old package names
    even after an Extension/user_default reinstall.  The module set cannot gain a
    newly imported legacy Smart Transform generation during normal operation, so
    repeat event/draw calls must not rescan it.
    """
    global _CSDT_LEGACY_WATCHDOGS_NEUTRALIZED
    if _CSDT_LEGACY_WATCHDOGS_NEUTRALIZED:
        return
    _CSDT_LEGACY_WATCHDOGS_NEUTRALIZED = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    except Exception:
        timers = None

    for _name, _module in list(sys.modules.items()):
        try:
            name_l = str(_name or '').lower()
            fn = getattr(_module, '_csdt_constraint_watchdog', None)
            if not callable(fn):
                continue

            fn_mod = str(getattr(fn, '__module__', '') or '').lower()
            fn_file = str(getattr(getattr(fn, '__code__', None), 'co_filename', '') or '').replace('\\', '/').lower()
            module_file = str(getattr(_module, '__file__', '') or '').replace('\\', '/').lower()
            hay = ' '.join((name_l, fn_mod, fn_file, module_file))
            looks_like_smart_transform = (
                'csdt_utils' in hay
                or 'smart_transform' in hay
                or 'smart-transform' in hay
                or 'smart_transform_suite' in hay
                or 'smart_transform_suite' in hay
            )
            if not looks_like_smart_transform:
                continue

            _unregistered = True
            if timers is not None:
                try:
                    if timers.is_registered(fn):
                        _unregistered = False
                        timers.unregister(fn)
                        _unregistered = True
                except Exception:
                    _unregistered = False
            if not _unregistered:
                # Preserve the exact old function object on the module so future
                # guard passes can still unregister it.
                continue
            try:
                setattr(_module, '_csdt_constraint_watchdog', _csdt_constraint_watchdog)
            except Exception:
                pass
        except Exception:
            continue

def _constraint_memory_kind_for_tool(tool_idname: str) -> str:
    if tool_idname == "builtin.rotate":
        return "ROTATE"
    if tool_idname == "builtin.scale":
        return "RESIZE"
    return "TRANSLATE"


def _normalize_constraint_memory_state(value, fallback_axis=(False, False, False)):
    axis = _coerce_constraint_axis(fallback_axis)
    kind = 'NONE'
    idx = -1
    try:
        if isinstance(value, dict):
            kind = str(value.get('kind', 'NONE') or 'NONE').upper()
            idx = int(value.get('idx', -1))
            axis = _coerce_constraint_axis(value.get('axis', axis))
        elif value is not None:
            axis = _coerce_constraint_axis(value)
            count = sum(1 for v in axis if v)
            if count == 1:
                kind = 'AXIS'
                idx = axis.index(True)
            elif count == 2:
                kind = 'PLANE'
                idx = axis.index(False)
            elif count == 0:
                kind = 'NONE'
                idx = -1
    except Exception:
        kind = 'NONE'
        idx = -1
        axis = _coerce_constraint_axis(fallback_axis)

    if kind == 'AXIS' and idx in (0, 1, 2):
        axis_l = [False, False, False]
        axis_l[idx] = True
        axis = tuple(axis_l)
    elif kind == 'PLANE' and idx in (0, 1, 2):
        axis_l = [True, True, True]
        axis_l[idx] = False
        axis = tuple(axis_l)
    elif kind == 'FREE':
        axis = (False, False, False)
        if idx not in (0, 1, 2):
            idx = -1
    else:
        kind = 'NONE'
        idx = -1
        axis = (False, False, False)

    return {'kind': kind, 'idx': idx, 'axis': tuple(bool(v) for v in axis)}


def _ensure_constraint_state_store():
    try:
        store = getattr(cg, '_LAST_CONSTRAINT_STATE_BY_KIND', None)
        if not isinstance(store, dict):
            store = {}
            setattr(cg, '_LAST_CONSTRAINT_STATE_BY_KIND', store)
        for key in ('TRANSLATE', 'ROTATE', 'RESIZE', 'TRANSFORM'):
            if key not in store:
                fallback = getattr(cg, '_LAST_CONSTRAINT_AXIS_BY_KIND', {}).get(key, (False, False, False))
                store[key] = _normalize_constraint_memory_state(None, fallback)
        return store
    except Exception:
        return {}


def _set_last_constraint_state_for_kind(kind_name: str, state) -> None:
    try:
        kind_name = str(kind_name or 'TRANSLATE').upper()
        if kind_name not in {'TRANSLATE', 'ROTATE', 'RESIZE', 'TRANSFORM'}:
            kind_name = 'TRANSLATE'
        store = _ensure_constraint_state_store()
        fallback = getattr(cg, '_LAST_CONSTRAINT_AXIS_BY_KIND', {}).get(kind_name, (False, False, False))
        norm = _normalize_constraint_memory_state(state, fallback)
        store[kind_name] = dict(norm)
        try:
            cg._LAST_CONSTRAINT_AXIS_BY_KIND[kind_name] = tuple(norm.get('axis', (False, False, False)))
        except Exception:
            pass
    except Exception:
        pass



def _constraint_state_from_smart_gizmo_hit_id(gid):
    """Return (memory_key, state) for a Smart Gizmo handle id.

    This is intentionally independent from Blender's BoolVector-only
    constraint_axis property so X/Y/Z, planes, and the explicit free handle can
    all be remembered from Smart Gizmo operations, including paths delegated to
    Blender's native transform modal.
    """
    try:
        gid = str(gid or '').strip().upper()
    except Exception:
        gid = ''
    if not gid:
        return None, None

    if gid.startswith('ROT_'):
        memory_key = 'ROTATE'
    elif gid.startswith('SCALE_'):
        memory_key = 'RESIZE'
    else:
        memory_key = 'TRANSLATE'

    axis_idx = None
    if gid in {'MOVE_X', 'ROT_X', 'SCALE_X'}:
        axis_idx = 0
    elif gid in {'MOVE_Y', 'ROT_Y', 'SCALE_Y'}:
        axis_idx = 1
    elif gid in {'MOVE_Z', 'ROT_Z', 'SCALE_Z'}:
        axis_idx = 2
    if axis_idx in (0, 1, 2):
        axis = [False, False, False]
        axis[axis_idx] = True
        return memory_key, {'kind': 'AXIS', 'idx': axis_idx, 'axis': tuple(axis)}

    plane_idx = None
    if gid in {'MOVE_XY', 'SCALE_XY'}:
        plane_idx = 2
    elif gid in {'MOVE_YZ', 'SCALE_YZ'}:
        plane_idx = 0
    elif gid in {'MOVE_XZ', 'SCALE_XZ'}:
        plane_idx = 1
    if plane_idx in (0, 1, 2):
        axis = [True, True, True]
        axis[plane_idx] = False
        return memory_key, {'kind': 'PLANE', 'idx': plane_idx, 'axis': tuple(axis)}

    if gid in {'MOVE_CENTER', 'SCALE_UNIFORM'} or gid.startswith('ROT_FREE'):
        free_idx = {'ROT_FREE_X': 0, 'ROT_FREE_Y': 1, 'ROT_FREE_Z': 2}.get(gid, -1)
        return memory_key, {'kind': 'FREE', 'idx': free_idx if free_idx in (0, 1, 2) else -1, 'axis': (False, False, False)}

    return None, None


def _remember_constraint_state_from_smart_gizmo_hit_id(gid) -> bool:
    """Remember the axis state represented by a Smart Gizmo handle id."""
    try:
        prefs = _prefs()
        if prefs and not getattr(prefs, 'enable_axis_memory', True):
            return False
    except Exception:
        pass
    key, state = _constraint_state_from_smart_gizmo_hit_id(gid)
    if not key or not isinstance(state, dict):
        return False
    try:
        _set_last_constraint_state_for_kind(key, state)
        return True
    except Exception:
        return False

def _get_last_constraint_state_for_tool(tool_idname: str):
    prefs = _prefs()
    if prefs and not prefs.enable_axis_memory:
        return {'kind': 'NONE', 'idx': -1, 'axis': (False, False, False)}

    key = _constraint_memory_kind_for_tool(tool_idname)
    store = _ensure_constraint_state_store()
    fallback = getattr(cg, '_LAST_CONSTRAINT_AXIS_BY_KIND', {}).get(key, (False, False, False))
    state = store.get(key, None) if isinstance(store, dict) else None
    return _normalize_constraint_memory_state(state, fallback)


def _get_last_constraint_for_tool(tool_idname: str):
    prefs = _prefs()
    if prefs and not prefs.enable_axis_memory:
        return (False, False, False)

    state = _get_last_constraint_state_for_tool(tool_idname)
    try:
        return tuple(bool(v) for v in state.get('axis', (False, False, False)))
    except Exception:
        key = _constraint_memory_kind_for_tool(tool_idname)
        return cg._LAST_CONSTRAINT_AXIS_BY_KIND.get(key, (False, False, False))

# =========================
# Gizmo Helper
# =========================
_VIEW3D_REDRAW_LAST_TIME = 0.0
_VIEW3D_REDRAW_MIN_INTERVAL = 1.0 / 120.0

def _tag_view3d_redraw():
    global _VIEW3D_REDRAW_LAST_TIME
    try:
        now = time.perf_counter()
        if (now - _VIEW3D_REDRAW_LAST_TIME) < _VIEW3D_REDRAW_MIN_INTERVAL:
            return
        _VIEW3D_REDRAW_LAST_TIME = now
    except Exception:
        pass
    try:
        if not bpy.context: return
        wm = bpy.context.window_manager
        for win in wm.windows:
            scr = win.screen
            if not scr: continue
            for area in scr.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _tag_selection_ui_redraw(context=None):
    """Redraw editors that depend on the active/selected object state.

    Object selection made through Python data APIs does not always emit the same
    UI notifier path as Blender's native click/select operators.  Properties,
    Outliner and headers can therefore keep showing the previous active object
    until another event forces a redraw.  Keep this helper narrow and call it
    only immediately after object selection changes.
    """
    try:
        ctx = context if context is not None else bpy.context
    except Exception:
        ctx = None
    try:
        if ctx is not None:
            vl = getattr(ctx, 'view_layer', None)
            if vl is not None:
                vl.update()
    except Exception:
        pass
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        if wm is None:
            return
        for win in getattr(wm, 'windows', []) or []:
            scr = getattr(win, 'screen', None)
            if scr is None:
                continue
            for area in getattr(scr, 'areas', []) or []:
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    except Exception:
        pass



def _csdt_view3d_space_from_context(context, area=None):
    """Return the SpaceView3D that owns the current Smart Transform event.

    Local View isolation is stored per SpaceView3D.  Object-mode ray casts use
    the scene/depsgraph and do not know which objects are hidden by that local
    viewport state, so every custom object-pick path must explicitly query the
    active SpaceView3D before accepting a hit.
    """
    try:
        space = getattr(context, 'space_data', None)
        if space is not None and getattr(space, 'type', None) == 'VIEW_3D':
            return space
    except Exception:
        pass
    try:
        area = area if area is not None else getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
            spaces = getattr(area, 'spaces', None)
            active = getattr(spaces, 'active', None) if spaces is not None else None
            if active is not None and getattr(active, 'type', None) == 'VIEW_3D':
                return active
            for sp in spaces or []:
                if getattr(sp, 'type', None) == 'VIEW_3D':
                    return sp
    except Exception:
        pass
    return None


def _csdt_object_visible_in_current_view(context, obj, *, area=None, space=None):
    """True only when ``obj`` is visible in the View3D currently being used.

    Blender's ``scene.ray_cast`` ignores per-viewport Local View isolation.  If a
    hidden/non-local object is accepted from that ray cast, Smart Gizmo click
    selection can select an object the user cannot see.  Treat those objects as
    not present, while still allowing the ray-cast loop to continue to visible
    objects behind them.
    """
    try:
        obj = _csdt_object_in_view_layer(context, obj)
    except Exception:
        pass
    if obj is None:
        return False
    try:
        vl = getattr(context, 'view_layer', None)
    except Exception:
        vl = None
    try:
        if vl is not None and bool(obj.hide_get(view_layer=vl)):
            return False
    except Exception:
        try:
            if bool(obj.hide_get()):
                return False
        except Exception:
            pass
    try:
        if bool(getattr(obj, 'hide_viewport', False)):
            return False
    except Exception:
        pass
    try:
        sp = space if space is not None else _csdt_view3d_space_from_context(context, area=area)
    except Exception:
        sp = None
    if sp is not None:
        try:
            if hasattr(obj, 'visible_in_viewport_get') and not bool(obj.visible_in_viewport_get(sp)):
                return False
        except Exception:
            pass
        try:
            if hasattr(obj, 'visible_get') and not bool(obj.visible_get(view_layer=vl, viewport=sp)):
                return False
        except TypeError:
            try:
                if hasattr(obj, 'visible_get') and not bool(obj.visible_get(viewport=sp)):
                    return False
            except Exception:
                pass
        except Exception:
            pass
    else:
        try:
            if hasattr(obj, 'visible_get') and not bool(obj.visible_get(view_layer=vl)):
                return False
        except TypeError:
            try:
                if hasattr(obj, 'visible_get') and not bool(obj.visible_get()):
                    return False
            except Exception:
                pass
        except Exception:
            pass
    return True


def _csdt_object_in_view_layer(context, obj):
    try:
        if obj is None:
            return None
        vl = getattr(context, 'view_layer', None)
        if vl is None:
            return obj
        objs = getattr(vl, 'objects', None)
        if objs is None:
            return obj
        # Fast path: ObjectBase collection lookup by name returns the original
        # view-layer object.  This also maps evaluated ray-cast objects back to
        # their real datablock when ``obj.original`` is available.
        for candidate in (getattr(obj, 'original', None), obj):
            if candidate is None:
                continue
            try:
                name = getattr(candidate, 'name', None)
                if name:
                    real = objs.get(name)
                    if real is not None:
                        return real
            except Exception:
                pass
        return obj
    except Exception:
        return obj


def _csdt_set_active_object_and_notify(context, obj=None, *, require_selected=False, redraw=True):
    """Set the view-layer active object and force object-dependent UI refresh.

    Smart Gizmo selection routes often bypass Blender's native select operator.
    Explicitly setting ``view_layer.objects.active`` is not enough in every UI
    layout; Properties/Outliner can remain on the previous active object unless
    the dependent editors are tagged.  This helper is intentionally object-mode
    focused and no-ops for invalid targets.
    """
    try:
        target = _csdt_object_in_view_layer(context, obj)
        if target is None:
            return False
        if require_selected:
            try:
                if not bool(target.select_get()):
                    return False
            except Exception:
                return False
        try:
            context.view_layer.objects.active = target
        except Exception:
            try:
                bpy.context.view_layer.objects.active = target
            except Exception:
                return False
        try:
            # Selection writes can be deferred by Blender's view layer until the
            # next update.  Force the state before Properties redraws.
            context.view_layer.update()
        except Exception:
            pass
        try:
            _invalidate_gizmo_cache()
        except Exception:
            pass
        if redraw:
            _tag_selection_ui_redraw(context)
        return True
    except Exception:
        return False


def _csdt_selected_objects_in_view_layer(context):
    try:
        selected = list(getattr(context, 'selected_objects', []) or [])
    except Exception:
        selected = []
    out = []
    seen = set()
    if selected:
        for obj in selected:
            real = _csdt_object_in_view_layer(context, obj)
            if real is None:
                continue
            try:
                if not bool(real.select_get()):
                    continue
            except Exception:
                pass
            try:
                if str(getattr(context, 'mode', '') or '') == 'OBJECT' and not _csdt_object_visible_in_current_view(context, real):
                    continue
            except Exception:
                pass
            try:
                ptr = int(real.as_pointer())
            except Exception:
                ptr = id(real)
            if ptr not in seen:
                seen.add(ptr); out.append(real)
    if out:
        return out
    try:
        for obj in getattr(context.view_layer, 'objects', []) or []:
            try:
                if bool(obj.select_get()):
                    if str(getattr(context, 'mode', '') or '') == 'OBJECT' and not _csdt_object_visible_in_current_view(context, obj):
                        continue
                    out.append(obj)
            except Exception:
                pass
    except Exception:
        pass
    return out


def _csdt_project_object_points_to_rect_score(context, obj, rect, region=None, rv3d=None):
    try:
        if region is None:
            region = getattr(context, 'region', None)
        if rv3d is None:
            rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None or obj is None or rect is None:
            return None
        xmin, xmax, ymin, ymax = [float(v) for v in rect]
        cx = (xmin + xmax) * 0.5
        cy = (ymin + ymax) * 0.5
        mw = getattr(obj, 'matrix_world', Matrix.Identity(4))
        pts = []
        try:
            pts.append(getattr(obj, 'matrix_world', Matrix.Identity(4)).translation.copy())
        except Exception:
            pass
        try:
            bb = list(getattr(obj, 'bound_box', []) or [])
            if bb:
                # Bounding-box corners make active choice match box selection
                # better than using only the object origin.
                pts.extend([mw @ Vector(corner) for corner in bb])
        except Exception:
            pass
        best = None
        inside = False
        for co in pts:
            try:
                p = view3d_utils.location_3d_to_region_2d(region, rv3d, co)
            except Exception:
                p = None
            if p is None:
                continue
            px = float(p.x); py = float(p.y)
            if xmin <= px <= xmax and ymin <= py <= ymax:
                inside = True
            d = math.hypot(px - cx, py - cy)
            if best is None or d < best:
                best = d
        if best is None:
            return None
        return (0 if inside else 1, best)
    except Exception:
        return None


def _csdt_choose_active_selected_object(context, *, rect=None, area=None, region=None, region_data=None, prefer_current=True):
    selected = _csdt_selected_objects_in_view_layer(context)
    if not selected:
        return None
    try:
        active = _csdt_object_in_view_layer(context, getattr(context, 'active_object', None))
        if prefer_current and active is not None and active in selected:
            return active
    except Exception:
        pass
    try:
        rv3d = region_data
        if rv3d is None:
            rv3d = _view3d_region_data(area, region, None, None)
    except Exception:
        rv3d = region_data
    scored = []
    if rect is not None:
        for idx, obj in enumerate(selected):
            score = _csdt_project_object_points_to_rect_score(context, obj, rect, region=region, rv3d=rv3d)
            if score is not None:
                scored.append((score[0], score[1], idx, obj))
    if scored:
        scored.sort(key=lambda item: (item[0], item[1], item[2]))
        return scored[0][3]
    # Match Blender's practical behavior closely enough: when active is no longer
    # selected, expose one of the selected objects to object-dependent editors.
    return selected[-1]


def _csdt_sync_active_after_object_selection(context, *, mode='SET', rect=None, area=None, region=None, region_data=None, hint_obj=None):
    try:
        if str(getattr(context, 'mode', '') or '') != 'OBJECT':
            return False
    except Exception:
        return False
    mode = _csdt_normalize_selection_mode(mode)
    try:
        active = _csdt_object_in_view_layer(context, getattr(context, 'active_object', None))
        active_selected = bool(active is not None and active.select_get())
        try:
            if active is not None and not _csdt_object_visible_in_current_view(context, active):
                active_selected = False
        except Exception:
            pass
    except Exception:
        active = None; active_selected = False
    target = None
    if hint_obj is not None:
        target = _csdt_object_in_view_layer(context, hint_obj)
        try:
            if target is not None and (not bool(target.select_get()) or not _csdt_object_visible_in_current_view(context, target)):
                target = None
        except Exception:
            target = None
    # For SET box/click operations the chosen object is the new selection focus.
    # For ADD/XOR keep the existing active object if it remains selected; for SUB
    # replace it only if the active object was removed from the selection.
    if target is None:
        prefer_current = (mode not in {'SET'} and active_selected)
        if not active_selected or mode == 'SET':
            target = _csdt_choose_active_selected_object(
                context, rect=rect, area=area, region=region, region_data=region_data,
                prefer_current=prefer_current,
            )
        elif active_selected:
            target = active
    if target is None:
        try:
            context.view_layer.objects.active = None
        except Exception:
            pass
        _tag_selection_ui_redraw(context)
        return False
    return _csdt_set_active_object_and_notify(context, target, require_selected=True, redraw=True)


def _find_view3d_area_region_at_win_xy(win, wx, wy):
    try:
        scr = getattr(win, "screen", None)
        if not scr:
            return (None, None)
        wx = int(wx); wy = int(wy)
        for area in scr.areas:
            if area.type != "VIEW_3D":
                continue
            windows = _view3d_window_regions(area)
            for region in windows:
                if _event_inside_region(region, wx, wy):
                    if _quadview_layout_active(area):
                        try:
                            idx = _quadview_index_from_region_xy(area, region, wx - int(getattr(region, 'x', 0) or 0), wy - int(getattr(region, 'y', 0) or 0))
                            if idx is not None and 0 <= int(idx) < len(windows):
                                return (area, windows[int(idx)])
                        except Exception:
                            pass
                    return (area, region)
    except Exception:
        pass
    return (None, None)

# =========================
# Tool Detection & Geometry
# =========================
def _active_tool_id(context):
    try:
        area = getattr(context, "area", None)
        if area is not None and getattr(area, "type", None) != 'VIEW_3D':
            # Do not reuse a cached View3D tool while Blender is handling menus,
            # headers, preferences, popovers, or other non-3D-View regions.  That
            # stale fallback made normal UI clicks look like Smart Transform clicks.
            return ''
    except Exception:
        pass
    try:
        ws = getattr(context, "workspace", None)
        tools = getattr(ws, "tools", None) if ws is not None else None
        if tools is not None:
            # Query Blender's active View3D tool slot first.  Iterating workspace
            # tools can see an old select-box/lasso entry before the active Move /
            # Rotate / Scale / Transform slot, which made transform-tool background
            # selection always fall back to Box.  create=False keeps the empty-slot
            # workaround intact.
            mode = str(getattr(context, "mode", 'OBJECT') or 'OBJECT')
            try:
                tool = tools.from_space_view3d_mode(mode, create=False)
                tid = str(getattr(tool, "idname", "") or "").strip()
                if tid:
                    cg._CSDT_LAST_TOOL_ID = tid
                    return tid
            except Exception:
                pass
            try:
                saw_view3d_mode = False
                for item in tools:
                    space_type = str(getattr(item, "space_type", "") or "")
                    item_mode = str(getattr(item, "mode", "") or "")
                    if space_type != 'VIEW_3D':
                        continue
                    if item_mode and item_mode != mode:
                        continue
                    saw_view3d_mode = True
                    tid = str(getattr(item, "idname", "") or "").strip()
                    if tid:
                        cg._CSDT_LAST_TOOL_ID = tid
                        return tid
                if saw_view3d_mode:
                    return cg._CSDT_LAST_TOOL_ID
            except Exception:
                pass
    except Exception:
        pass
    return cg._CSDT_LAST_TOOL_ID

def _is_transform_tool_active(context):
    tid = _active_tool_id(context)
    if not tid or tid not in cg._TRANSFORM_TOOL_IDS:
        return False
    prefs = _prefs()
    if not prefs: return True
    if tid == "builtin.move" and not prefs.enable_move: return False
    if tid == "builtin.rotate" and not prefs.enable_rotate: return False
    if tid == "builtin.scale" and not prefs.enable_scale: return False
    if tid == "builtin.transform" and not prefs.enable_transform: return False
    return True

def _mesh_select_mode(context):
    try:
        v, e, f = context.tool_settings.mesh_select_mode
        if f: return "FACE"
        if e: return "EDGE"
        return "VERT"
    except Exception:
        return "VERT"

def _poly_hit_2d(mx, my, poly, tol):
    if _pt_in_poly_2d((mx, my), poly): return True
    if tol <= 0.0: return False
    for (ax, ay), (bx, by) in zip(poly, poly[1:] + poly[:1]):
        if _dist_point_to_seg_2d(mx, my, ax, ay, bx, by) <= tol:
            return True
    return False

def _dist_point_to_seg_2d(px, py, ax, ay, bx, by):
    abx = bx - ax; aby = by - ay
    apx = px - ax; apy = py - ay
    ab_len2 = abx * abx + aby * aby
    if ab_len2 <= 1e-12: return math.hypot(px - ax, py - ay)
    t = (apx * abx + apy * aby) / ab_len2
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    cx = ax + abx * t; cy = ay + aby * t
    return math.hypot(px - cx, py - cy)


_TRANSFORM_AFFECT_ONLY_TOOL_SETTING_ATTRS = (
    'use_transform_data_origin',        # 3D View Options > Affect Only > Origins
    'use_transform_pivot_point_align',  # 3D View Options > Affect Only > Locations
    'use_transform_skip_children',      # 3D View Options > Affect Only > Parents
)

_TRANSFORM_EDIT_MESH_TOOL_SETTING_NATIVE_ATTRS = (
    'use_transform_correct_face_attributes',  # Also covers Keep Connected while the parent option is enabled.
    'use_mesh_automerge',                     # Also covers Split Edges & Faces and Threshold while enabled.
    'use_edge_path_live_unwrap',              # Mesh Edit Options > UVs > Live Unwrap
)


def _tool_settings_candidates(context):
    """Yield ToolSettings owners in active-window priority order.

    Smart Gizmo is driven by a persistent modal watcher.  Blender may keep the
    operator context object that started that watcher while the active scene or
    workspace has already changed.  Native G/R/S reads the ToolSettings owned by
    the current window scene, so resolve that owner first and retain conservative
    fallbacks for script/background invocation.
    """
    owners = []
    seen = set()

    def _append(owner):
        if owner is None:
            return
        try:
            key = int(owner.as_pointer())
        except Exception:
            key = id(owner)
        if key in seen:
            return
        seen.add(key)
        owners.append(owner)

    try:
        window = getattr(context, 'window', None)
        scene = getattr(window, 'scene', None) if window is not None else None
        _append(getattr(scene, 'tool_settings', None) if scene is not None else None)
    except Exception:
        pass
    try:
        scene = getattr(context, 'scene', None)
        _append(getattr(scene, 'tool_settings', None) if scene is not None else None)
    except Exception:
        pass
    try:
        _append(getattr(context, 'tool_settings', None))
    except Exception:
        pass
    try:
        window = getattr(bpy.context, 'window', None)
        scene = getattr(window, 'scene', None) if window is not None else None
        _append(getattr(scene, 'tool_settings', None) if scene is not None else None)
    except Exception:
        pass
    try:
        scene = getattr(bpy.context, 'scene', None)
        _append(getattr(scene, 'tool_settings', None) if scene is not None else None)
    except Exception:
        pass
    try:
        _append(getattr(bpy.context, 'tool_settings', None))
    except Exception:
        pass

    yield from owners


def _tool_settings_from_context(context):
    try:
        return next(_tool_settings_candidates(context), None)
    except Exception:
        return None


def _transform_affect_only_state(context) -> dict:
    """Capture 3D View > Options > Transform > Affect Only.

    The snapshot is carried across every Smart Gizmo/Smart G-R-S native
    delegation boundary.  This keeps Origins, Locations and Parents tied to the
    window that received the pointer/key event, exactly as Blender's standard
    transform tools do.
    """
    state = {
        'origins': False,
        'locations': False,
        'parents': False,
        'enabled': False,
    }
    ts = _tool_settings_from_context(context)
    if ts is None:
        return state
    try:
        state['origins'] = bool(getattr(ts, 'use_transform_data_origin', False))
        state['locations'] = bool(getattr(ts, 'use_transform_pivot_point_align', False))
        state['parents'] = bool(getattr(ts, 'use_transform_skip_children', False))
        state['enabled'] = bool(state['origins'] or state['locations'] or state['parents'])
    except Exception:
        pass
    return state


def _sync_transform_affect_only_state(context, state) -> bool:
    """Apply a captured Affect Only state to the native operator context.

    The values are copied to the ToolSettings instance that Blender's native
    transform modal reads after a temp_override or persistent-watcher hand-off.
    Callers that intentionally mask the settings must use
    ``_temporary_transform_affect_only_state`` so the user's top-right options
    are restored immediately after the native transform initializes.
    """
    try:
        values = dict(state or {})
    except Exception:
        return False
    ts = _tool_settings_from_context(context)
    if ts is None:
        return False
    try:
        ts.use_transform_data_origin = bool(values.get('origins', False))
        ts.use_transform_pivot_point_align = bool(values.get('locations', False))
        ts.use_transform_skip_children = bool(values.get('parents', False))
        return True
    except Exception:
        return False


def _selected_object_transform_objects(context):
    """Return the current Object Mode selection in active-window priority order.

    Smart Gizmo can be driven by a long-lived watcher, so ``context`` may have
    been created before a scene/workspace switch.  Prefer the current window
    view-layer selection and retain conservative context fallbacks.  Objects are
    normalized to their original datablocks and de-duplicated.
    """
    result = []
    seen = set()

    def _append(obj):
        if obj is None:
            return
        try:
            original = getattr(obj, 'original', None)
            if original is not None:
                obj = original
        except Exception:
            pass
        try:
            key = int(obj.as_pointer())
        except Exception:
            key = id(obj)
        if key in seen:
            return
        try:
            if str(getattr(obj, 'mode', '') or 'OBJECT') != 'OBJECT':
                return
        except Exception:
            pass
        seen.add(key)
        result.append(obj)

    try:
        window = getattr(context, 'window', None)
        view_layer = getattr(window, 'view_layer', None) if window is not None else None
        if view_layer is not None:
            for obj in list(getattr(view_layer, 'objects', []) or []):
                try:
                    if bool(obj.select_get(view_layer=view_layer)):
                        _append(obj)
                except TypeError:
                    try:
                        if bool(obj.select_get()):
                            _append(obj)
                    except Exception:
                        pass
                except Exception:
                    pass
    except Exception:
        pass
    for attr_name in ('selected_editable_objects', 'selected_objects'):
        try:
            for obj in list(getattr(context, attr_name, []) or []):
                _append(obj)
        except Exception:
            pass
    try:
        for obj in list(getattr(bpy.context, 'selected_objects', []) or []):
            _append(obj)
    except Exception:
        pass
    if not result:
        for owner in (context, bpy.context):
            try:
                _append(getattr(owner, 'active_object', None))
            except Exception:
                pass
    return result


def _affect_only_all_object_types_enabled(context=None) -> bool:
    """Return the N-panel policy for non-mesh Object Mode selections.

    Default to enabled so newly installed and partially migrated builds honor
    Blender's Affect Only options for Empty, Camera, Light, Armature, Curve,
    Text, Lattice, Metaball, Speaker, Volume, Point Cloud, Grease Pencil, and
    every future object type without requiring a migration value.
    """
    try:
        prefs = _prefs(context)
        if prefs is None:
            return True
        return bool(getattr(prefs, 'affect_only_all_object_types', True))
    except Exception:
        return True


def _effective_transform_affect_only_state(context) -> dict:
    """Return the Affect Only state Smart Gizmo / Smart G-R-S should apply.

    When the Other Tools option is enabled, Blender's standard Origins,
    Locations, and Parents behavior is used for every Object Mode object type.
    When disabled, the options are honored only for an all-mesh selection.  A
    mixed or non-mesh selection is treated as a normal Smart transform so the
    checkbox has deterministic, all-or-nothing behavior and never applies only
    part of one modal transform to part of the selection.
    """
    raw = _transform_affect_only_state(context)
    try:
        state = dict(raw)
    except Exception:
        state = {
            'origins': False,
            'locations': False,
            'parents': False,
            'enabled': False,
        }
    state['all_object_types'] = _affect_only_all_object_types_enabled(context)
    state['selection_supported'] = True
    state['suppressed_for_object_types'] = False
    if not bool(state.get('enabled', False)):
        return state
    try:
        if not _context_is_object_transform_mode(context):
            return state
    except Exception:
        return state
    if bool(state.get('all_object_types', True)):
        return state
    objects = _selected_object_transform_objects(context)
    supported = bool(objects) and all(str(getattr(obj, 'type', '') or '') == 'MESH' for obj in objects)
    state['selection_supported'] = bool(supported)
    if supported:
        return state
    state['origins'] = False
    state['locations'] = False
    state['parents'] = False
    state['enabled'] = False
    state['suppressed_for_object_types'] = True
    return state


@contextmanager
def _temporary_transform_affect_only_state(context, state):
    """Temporarily expose an effective Affect Only state to native Transform.

    Blender's transform modal copies these ToolSettings during initialization.
    Restoring the user's values immediately after the operator call keeps the
    3D View Options UI unchanged while still allowing the N-panel object-type
    switch to mask Affect Only for a non-mesh or mixed selection.
    """
    ts = _tool_settings_from_context(context)
    previous = None
    if ts is not None:
        try:
            previous = {
                'origins': bool(getattr(ts, 'use_transform_data_origin', False)),
                'locations': bool(getattr(ts, 'use_transform_pivot_point_align', False)),
                'parents': bool(getattr(ts, 'use_transform_skip_children', False)),
                'enabled': bool(
                    getattr(ts, 'use_transform_data_origin', False)
                    or getattr(ts, 'use_transform_pivot_point_align', False)
                    or getattr(ts, 'use_transform_skip_children', False)
                ),
            }
        except Exception:
            previous = None
    applied = _sync_transform_affect_only_state(context, state)
    try:
        yield applied
    finally:
        if previous is not None:
            try:
                _sync_transform_affect_only_state(context, previous)
            except Exception:
                pass


def _context_is_object_transform_mode(context) -> bool:
    """Return whether the current window is in Object Mode.

    Prefer the current window/view-layer active object over fields captured by a
    long-lived modal context.
    """
    objects = []
    try:
        window = getattr(context, 'window', None)
        view_layer = getattr(window, 'view_layer', None) if window is not None else None
        objects.append(getattr(getattr(view_layer, 'objects', None), 'active', None))
    except Exception:
        pass
    try:
        objects.append(getattr(context, 'active_object', None))
    except Exception:
        pass
    try:
        objects.append(getattr(bpy.context, 'active_object', None))
    except Exception:
        pass
    for obj in objects:
        if obj is None:
            continue
        try:
            return str(getattr(obj, 'mode', '') or '') == 'OBJECT'
        except Exception:
            continue
    for owner in (context, bpy.context):
        try:
            mode = str(getattr(owner, 'mode', '') or '')
            if mode:
                return mode == 'OBJECT'
        except Exception:
            continue
    return True


def _context_objects_in_mode(context):
    try:
        objs = list(getattr(context, 'objects_in_mode_unique_data', []) or [])
        if objs:
            return [o for o in objs if o is not None]
    except Exception:
        pass
    try:
        objs = list(getattr(context, 'objects_in_mode', []) or [])
        if objs:
            return [o for o in objs if o is not None]
    except Exception:
        pass
    try:
        obj = getattr(context, 'active_object', None)
        return [obj] if obj is not None else []
    except Exception:
        return []


def _object_or_data_axis_mirror_active(obj) -> bool:
    """Return True when Blender's native Transform mirror editing can affect data.

    Blender's own transform operators require their ``mirror`` property to be
    true before the per-object/per-data X/Y/Z mirror toggles participate in a
    transform.  Smart G-R-S and Smart Gizmo direct-edit paths do not implement
    that mirrored counterpart solver, so active mirror axes are a native-only
    condition.
    """
    if obj is None:
        return False
    for owner in (obj, getattr(obj, 'data', None), getattr(obj, 'pose', None)):
        if owner is None:
            continue
        for attr_name in (
            'use_mesh_mirror_x', 'use_mesh_mirror_y', 'use_mesh_mirror_z',
            'use_mirror_x', 'use_mirror_y', 'use_mirror_z',
        ):
            try:
                if bool(getattr(owner, attr_name, False)):
                    return True
            except Exception:
                continue
    return False


def _transform_mirror_editing_active(context) -> bool:
    try:
        mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        mode = ''
    if mode not in {
        'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE',
        'EDIT_ARMATURE', 'POSE',
    }:
        return False
    try:
        for obj in _context_objects_in_mode(context):
            if _object_or_data_axis_mirror_active(obj):
                return True
    except Exception:
        pass
    try:
        return _object_or_data_axis_mirror_active(getattr(context, 'active_object', None))
    except Exception:
        return False


def _edit_mesh_transform_options_require_native(context) -> bool:
    """Return True when Mesh Edit top-right Transform/UV options are active.

    The custom Smart G-R-S mesh backend writes BMesh vertex coordinates directly.
    Blender's native transform operators own the complete behavior for Correct
    Face Attributes / Keep Connected, Mirror Editing, Auto Merge / Split, and
    the UV live-unwrapping side-effects exposed in the 3D View top-right tool
    options.  Delegate while any of those options are enabled so Smart Gizmo and
    Smart G-R-S match standard Blender transforms instead of approximating them.
    """
    try:
        if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
            return False
        ts = _tool_settings_from_context(context)
        if ts is not None:
            for attr_name in _TRANSFORM_EDIT_MESH_TOOL_SETTING_NATIVE_ATTRS:
                try:
                    if bool(getattr(ts, attr_name, False)):
                        return True
                except Exception:
                    continue
        return _transform_mirror_editing_active(context)
    except Exception:
        return False


def _edit_curve_surface_transform_options_require_native(context) -> bool:
    try:
        if str(getattr(context, 'mode', '') or '') not in {'EDIT_CURVE', 'EDIT_SURFACE', 'EDIT_LATTICE'}:
            return False
        return _transform_mirror_editing_active(context)
    except Exception:
        return False


def _tool_settings_require_native_object_transform(context) -> bool:
    """Return True when Object Mode Affect Only needs Blender native G/R/S."""
    try:
        if not _context_is_object_transform_mode(context):
            return False
        return bool(_effective_transform_affect_only_state(context).get('enabled', False))
    except Exception:
        return False


def _tool_settings_require_native_transform(context) -> bool:
    """Return True when top-right Transform options require Blender's native op."""
    try:
        if _tool_settings_require_native_object_transform(context):
            return True
        if _edit_mesh_transform_options_require_native(context):
            return True
        if _edit_curve_surface_transform_options_require_native(context):
            return True
    except Exception:
        return True
    return False


def _native_transform_context_kwargs(context, mode: str | None = None) -> dict:
    """Build native transform kwargs needed to honor current transform options.

    ToolSettings such as Auto Merge and Correct Face Attributes are read directly
    by Blender's transform modal.  Mirror Editing is different: standard keymaps
    normally invoke native transforms with ``mirror=True``.  Smart G-R-S manual
    registrations and Smart Gizmo native delegation do not have that payload, so
    add it only when an actual mirror axis is active.

    Proportional editing also needs an explicit operator payload when Smart G-R-S
    is used as a manual keymap target.  Mirror the active ToolSettings here for
    every native delegation path while letting explicitly-set keymap properties
    win in the caller.
    """
    kwargs = {}
    ts = None
    try:
        ts = _tool_settings_from_context(context)
    except Exception:
        ts = None
    try:
        affect_only = _effective_transform_affect_only_state(context)
        m = str(mode or '').upper()
        if _context_is_object_transform_mode(context) and m in {'G', 'TRANSLATE', 'MOVE', ''} and bool(affect_only.get('origins', False)):
            # Native Move has an explicit origin-translation property in
            # addition to ToolSettings.  Supplying it closes the deferred Smart
            # Gizmo/script path where the modal is initialized after the context
            # hand-off.
            kwargs['translate_origin'] = True
    except Exception:
        pass
    try:
        if _transform_mirror_editing_active(context):
            kwargs['mirror'] = True
    except Exception:
        pass
    try:
        m = str(mode or '').upper()
        if m in {'G', 'TRANSLATE', 'MOVE', ''}:
            if ts is not None and bool(getattr(ts, 'use_mesh_automerge', False)) and bool(getattr(ts, 'use_mesh_automerge_and_split', False)):
                kwargs['use_automerge_and_split'] = True
    except Exception:
        pass
    try:
        if ts is not None:
            area_type = str(getattr(getattr(context, 'area', None), 'type', '') or '')
            ctx_mode = str(getattr(context, 'mode', '') or '')
            if ctx_mode == 'OBJECT':
                use_prop = bool(getattr(ts, 'use_proportional_edit_objects', False))
            elif ctx_mode.startswith('EDIT') or ctx_mode == 'POSE':
                use_prop = bool(getattr(ts, 'use_proportional_edit', False))
            else:
                use_prop = bool(getattr(ts, 'use_proportional_edit', False))
            kwargs['use_proportional_edit'] = use_prop
            try:
                kwargs['proportional_edit_falloff'] = getattr(ts, 'proportional_edit_falloff')
            except Exception:
                pass
            try:
                kwargs['proportional_size'] = max(0.000001, float(getattr(ts, 'proportional_size', 1.0)))
            except Exception:
                pass
            try:
                kwargs['use_proportional_connected'] = bool(getattr(ts, 'use_proportional_connected', False))
            except Exception:
                pass
            try:
                kwargs['use_proportional_projected'] = bool(getattr(ts, 'use_proportional_projected', False))
            except Exception:
                pass
    except Exception:
        pass
    return kwargs



_NATIVE_TRACKBALL_PROP_NAMES = {
    'value', 'mirror', 'use_proportional_edit', 'proportional_edit_falloff',
    'proportional_size', 'use_proportional_connected', 'use_proportional_projected',
    'snap', 'gpencil_strokes', 'center_override', 'release_confirm', 'use_accurate',
}


def _pending_requests_free_rotation(*args, hit_id: str | None = None) -> bool:
    """Return True when a Smart Transform request explicitly means XYZ free rotation.

    Smart Gizmo's free-rotation disk is not the same as ordinary
    ``transform.rotate`` with no constraint. ``rotate`` uses the view/screen
    rotation path; Blender's native equivalent for drag-position-dependent XYZ
    free rotation is ``transform.trackball``. Accept both historical call
    shapes used inside the add-on: ``(pending)`` and ``(mode, pending)``.
    """
    mode = None
    pending = None
    try:
        if len(args) == 1:
            pending = args[0]
        elif len(args) >= 2:
            mode = args[0]
            pending = args[1]
    except Exception:
        pending = None
    try:
        if str(hit_id or '').startswith('ROT_FREE'):
            return True
    except Exception:
        pass
    try:
        if mode is not None and str(mode or '').upper() not in {'R', 'ROTATE'}:
            return False
    except Exception:
        return False
    try:
        return isinstance(pending, dict) and str(pending.get('kind', '') or '').upper() == 'FREE'
    except Exception:
        return False


def _native_trackball_kwargs(kwargs: dict | None) -> dict:
    """Filter native transform kwargs to properties supported by trackball()."""
    out = {}
    try:
        items = dict(kwargs or {}).items()
    except Exception:
        items = []
    for key, value in items:
        try:
            key = str(key)
        except Exception:
            continue
        if key not in _NATIVE_TRACKBALL_PROP_NAMES:
            continue
        if key == 'value':
            try:
                seq = tuple(float(v) for v in value)
            except Exception:
                continue
            if len(seq) != 2:
                continue
            out[key] = seq
            continue
        if key == 'center_override':
            try:
                seq = tuple(float(v) for v in value)
            except Exception:
                continue
            if len(seq) != 3:
                continue
            out[key] = seq
            continue
        out[key] = value
    return out

def _csdt_project_world_2d_safe(region, rv3d, co_world):
    try:
        return view3d_utils.location_3d_to_region_2d(region, rv3d, co_world)
    except Exception:
        return None


def _csdt_edge_projected_points(region, rv3d, mw, edge, *, steps=8):
    """Return projected points along an edit edge, preserving clipped gaps.

    Endpoint-only projection is not reliable when a visible edge segment is
    partially clipped or when one endpoint is outside the current View3D frustum.
    A small polyline sample is used only by fallback selection paths, keeping
    normal hit testing fast while making edge click/box selection deterministic.
    """
    try:
        co0 = Vector(edge.verts[0].co)
        co1 = Vector(edge.verts[1].co)
    except Exception:
        return []
    try:
        count = max(2, int(steps) + 1)
    except Exception:
        count = 9
    out = []
    for i in range(count):
        try:
            t = float(i) / float(count - 1)
            co = co0.lerp(co1, t)
            out.append(_csdt_project_world_2d_safe(region, rv3d, mw @ co))
        except Exception:
            out.append(None)
    return out


def _csdt_polyline_distance_to_point_2d(points, mx, my):
    best = None
    prev = None
    try:
        mx = float(mx); my = float(my)
    except Exception:
        return None
    for p in points or []:
        if p is None:
            prev = None
            continue
        try:
            px, py = (float(p.x), float(p.y)) if hasattr(p, 'x') else (float(p[0]), float(p[1]))
        except Exception:
            prev = None
            continue
        if prev is not None:
            try:
                d = _dist_point_to_seg_2d(mx, my, float(prev[0]), float(prev[1]), px, py)
                best = d if best is None or d < best else best
            except Exception:
                pass
        else:
            try:
                d = math.hypot(mx - px, my - py)
                best = d if best is None or d < best else best
            except Exception:
                pass
        prev = (px, py)
    return best

def _pt_in_poly_2d(pt, poly):
    x, y = pt
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        if ((y1 > y) != (y2 > y)) and (x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-20) + x1):
            inside = not inside
    return inside

# =========================
# Hit Testing (Extreme Optimization)
# =========================
def _csdt_element_hit_radii(context=None):
    """Return vertex/edge hit radii from the Sensitivity / Hit Range settings.

    Immediate Select, Select Tool clicks, and Smart Gizmo click routing share this
    helper so every editable-element hit uses the same user-visible detection
    range instead of Blender's separate native click tolerance.
    """
    try:
        prefs = _prefs(context)
    except Exception:
        prefs = None
    try:
        v_radius = float(getattr(prefs, 'vert_hit_radius', 20.0) if prefs else 20.0)
    except Exception:
        v_radius = 20.0
    try:
        e_radius = float(getattr(prefs, 'edge_hit_radius', 20.0) if prefs else 20.0)
    except Exception:
        e_radius = 20.0
    try:
        v_radius = max(1.0, min(100.0, float(v_radius)))
    except Exception:
        v_radius = 20.0
    try:
        e_radius = max(1.0, min(100.0, float(e_radius)))
    except Exception:
        e_radius = 20.0
    return v_radius, e_radius



def _csdt_clear_editmesh_screen_hit_cache():
    """Clear cached screen-space editable-element hit data."""
    try:
        _CSDT_EDITMESH_SCREEN_HIT_CACHE.clear()
    except Exception:
        pass


def _csdt_matrix_signature(mat, digits=5):
    try:
        return tuple(round(float(v), int(digits)) for row in mat for v in row)
    except Exception:
        return ()


def _csdt_editmesh_screen_cache_key(context, obj, bm, use_vert, use_edge, use_face, v_radius, e_radius):
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None or obj is None or bm is None:
            return None
        try:
            obj_ptr = int(obj.as_pointer())
        except Exception:
            obj_ptr = id(obj)
        try:
            mesh_ptr = int(obj.data.as_pointer())
        except Exception:
            mesh_ptr = id(getattr(obj, 'data', None))
        try:
            region_ptr = int(region.as_pointer())
        except Exception:
            region_ptr = id(region)
        try:
            rv3d_ptr = int(rv3d.as_pointer())
        except Exception:
            rv3d_ptr = id(rv3d)
        try:
            counts = (len(bm.verts), len(bm.edges), len(bm.faces))
        except Exception:
            counts = (0, 0, 0)
        return (
            obj_ptr,
            mesh_ptr,
            region_ptr,
            rv3d_ptr,
            int(getattr(region, 'width', 0) or 0),
            int(getattr(region, 'height', 0) or 0),
            bool(use_vert), bool(use_edge), bool(use_face),
            bool(_csdt_backside_element_click_select_enabled(context)),
            round(float(v_radius), 2), round(float(e_radius), 2),
            counts,
            _csdt_matrix_signature(getattr(rv3d, 'perspective_matrix', None), 5),
            _csdt_matrix_signature(getattr(obj, 'matrix_world', None), 5),
        )
    except Exception:
        return None



def _csdt_immediate_prefetch_signature(context, obj, mx, my):
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None:
            return None
        try:
            obj_ptr = int(obj.as_pointer()) if obj is not None else 0
        except Exception:
            obj_ptr = id(obj)
        try:
            data_ptr = int(obj.data.as_pointer()) if obj is not None and getattr(obj, 'data', None) is not None else 0
        except Exception:
            data_ptr = id(getattr(obj, 'data', None)) if obj is not None else 0
        try:
            region_ptr = int(region.as_pointer())
        except Exception:
            region_ptr = id(region)
        try:
            rv3d_ptr = int(rv3d.as_pointer())
        except Exception:
            rv3d_ptr = id(rv3d)
        try:
            mode = str(getattr(context, 'mode', '') or '')
        except Exception:
            mode = ''
        try:
            mesh_mode = tuple(bool(v) for v in getattr(getattr(context, 'tool_settings', None), 'mesh_select_mode', (False, False, False)))
        except Exception:
            mesh_mode = ()
        try:
            radii = tuple(round(float(v), 2) for v in _csdt_element_hit_radii(context))
        except Exception:
            radii = ()
        return {
            'mode': mode,
            'mesh_mode': mesh_mode,
            'obj_ptr': obj_ptr,
            'data_ptr': data_ptr,
            'region_ptr': region_ptr,
            'rv3d_ptr': rv3d_ptr,
            'region_size': (int(getattr(region, 'width', 0) or 0), int(getattr(region, 'height', 0) or 0)),
            'mx': int(mx),
            'my': int(my),
            'radii': radii,
            'backside_click': bool(_csdt_backside_element_click_select_enabled(context)),
        }
    except Exception:
        return None


def _csdt_store_immediate_prefetch_hit(context, obj, mx, my, target_obj, hit, definitive=True):
    global _CSDT_IMMEDIATE_SELECT_PREFETCH_HIT
    try:
        sig = _csdt_immediate_prefetch_signature(context, obj, mx, my)
        if sig is None:
            return
        _CSDT_IMMEDIATE_SELECT_PREFETCH_HIT = {
            'time': time.perf_counter(),
            'sig': sig,
            'target_obj': target_obj,
            'hit': hit,
            'definitive': bool(definitive),
        }
    except Exception:
        _CSDT_IMMEDIATE_SELECT_PREFETCH_HIT = None


def _get_prefetched_immediate_select_hit(context, mx, my, fallback_obj=None):
    """Return a hover-prefetched click hit if it still matches this press.

    The return value is ``(target_obj, hit, valid)``.  ``valid`` can be True with
    ``hit`` set to None, which means the hover pass already made a definitive miss
    at the same position and the press path should not rebuild the hit cache.
    """
    try:
        item = _CSDT_IMMEDIATE_SELECT_PREFETCH_HIT
        if not isinstance(item, dict) or not bool(item.get('definitive', False)):
            return None, None, False
        if time.perf_counter() - float(item.get('time', 0.0) or 0.0) > float(_CSDT_IMMEDIATE_SELECT_PREFETCH_TTL):
            return None, None, False
        obj = fallback_obj if fallback_obj is not None else getattr(context, 'active_object', None)
        cur = _csdt_immediate_prefetch_signature(context, obj, mx, my)
        old = item.get('sig')
        if not isinstance(cur, dict) or not isinstance(old, dict):
            return None, None, False
        for name in ('mode', 'mesh_mode', 'obj_ptr', 'data_ptr', 'region_ptr', 'rv3d_ptr', 'region_size', 'radii', 'backside_click'):
            if cur.get(name) != old.get(name):
                return None, None, False
        dx = abs(int(cur.get('mx', 0)) - int(old.get('mx', 0)))
        dy = abs(int(cur.get('my', 0)) - int(old.get('my', 0)))
        if dx > float(_CSDT_IMMEDIATE_SELECT_PREFETCH_MAX_DELTA) or dy > float(_CSDT_IMMEDIATE_SELECT_PREFETCH_MAX_DELTA):
            return None, None, False
        target = item.get('target_obj', obj)
        hit = item.get('hit', None)
        try:
            if str(cur.get('mode') or '') == 'OBJECT':
                # Local View isolation can change without changing region/rv3d
                # pointers.  Never reuse a hover-prefetched object hit unless it
                # is still visible in the current SpaceView3D.
                if target is not None and not _csdt_object_visible_in_current_view(context, target):
                    return None, None, False
                if hit is not None:
                    try:
                        hit_obj = hit[0]
                    except Exception:
                        hit_obj = target
                    if hit_obj is not None and not _csdt_object_visible_in_current_view(context, hit_obj):
                        return None, None, False
        except Exception:
            pass
        return target, hit, True
    except Exception:
        return None, None, False

def _csdt_prune_editmesh_screen_hit_cache(now=None):
    try:
        now = time.perf_counter() if now is None else float(now)
    except Exception:
        now = 0.0
    try:
        keys = list(_CSDT_EDITMESH_SCREEN_HIT_CACHE.keys())
        for key in keys:
            item = _CSDT_EDITMESH_SCREEN_HIT_CACHE.get(key)
            if not isinstance(item, dict):
                _CSDT_EDITMESH_SCREEN_HIT_CACHE.pop(key, None)
                continue
            age = now - float(item.get('created', 0.0) or 0.0)
            if age > float(_CSDT_EDITMESH_SCREEN_HIT_CACHE_TTL):
                _CSDT_EDITMESH_SCREEN_HIT_CACHE.pop(key, None)
        while len(_CSDT_EDITMESH_SCREEN_HIT_CACHE) > int(_CSDT_EDITMESH_SCREEN_HIT_CACHE_MAX_ITEMS):
            oldest_key = None
            oldest_time = None
            for key, item in _CSDT_EDITMESH_SCREEN_HIT_CACHE.items():
                created = float(item.get('created', 0.0) or 0.0) if isinstance(item, dict) else 0.0
                if oldest_time is None or created < oldest_time:
                    oldest_time = created
                    oldest_key = key
            if oldest_key is None:
                break
            _CSDT_EDITMESH_SCREEN_HIT_CACHE.pop(oldest_key, None)
    except Exception:
        pass


def _csdt_grid_cell_range(value_min, value_max, cell_size):
    try:
        cell_size = max(1.0, float(cell_size))
        return range(int(math.floor(float(value_min) / cell_size)), int(math.floor(float(value_max) / cell_size)) + 1)
    except Exception:
        return range(0, 0)


def _csdt_screen_cache_add_point(grid, idx, x, y, radius, cell_size):
    try:
        r = max(1.0, float(radius))
        for cx in _csdt_grid_cell_range(float(x) - r, float(x) + r, cell_size):
            for cy in _csdt_grid_cell_range(float(y) - r, float(y) + r, cell_size):
                grid.setdefault((cx, cy), []).append(int(idx))
    except Exception:
        pass


def _csdt_screen_cache_add_polyline(grid, idx, points, radius, cell_size):
    try:
        pts = [(float(p[0]), float(p[1])) for p in points if p is not None]
    except Exception:
        pts = []
    if len(pts) < 1:
        return
    try:
        r = max(1.0, float(radius))
        if len(pts) == 1:
            _csdt_screen_cache_add_point(grid, idx, pts[0][0], pts[0][1], r, cell_size)
            return
        seen_cells = set()
        for a, b in zip(pts, pts[1:]):
            ax, ay = a; bx, by = b
            for cx in _csdt_grid_cell_range(min(ax, bx) - r, max(ax, bx) + r, cell_size):
                for cy in _csdt_grid_cell_range(min(ay, by) - r, max(ay, by) + r, cell_size):
                    cell = (cx, cy)
                    if cell in seen_cells:
                        continue
                    seen_cells.add(cell)
                    grid.setdefault(cell, []).append(int(idx))
    except Exception:
        pass


def _csdt_project_local_point_fast(full_mat, rw_half, rh_half, co):
    p = _csdt_project_local_point_depth_fast(full_mat, rw_half, rh_half, co)
    if p is None:
        return None
    return (p[0], p[1])


def _csdt_project_local_point_depth_fast(full_mat, rw_half, rh_half, co):
    try:
        x, y, z = co
        m00, m01, m02, m03 = full_mat[0]
        m10, m11, m12, m13 = full_mat[1]
        m30, m31, m32, m33 = full_mat[3]
        w = m30 * x + m31 * y + m32 * z + m33
        if w <= 0.0:
            return None
        px = (m00 * x + m01 * y + m02 * z + m03) / w
        py = (m10 * x + m11 * y + m12 * z + m13) / w
        return ((px + 1.0) * rw_half, (py + 1.0) * rh_half, float(w))
    except Exception:
        return None


def _csdt_build_editmesh_screen_hit_cache(context, obj, bm, use_vert, use_edge, use_face, v_radius, e_radius, key):
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None or obj is None or bm is None or key is None:
            return None
        try:
            total_components = (len(bm.verts) if use_vert else 0) + (len(bm.edges) if use_edge else 0) + (len(bm.faces) if use_face else 0)
        except Exception:
            total_components = 0
        if total_components <= 0 or total_components > int(_CSDT_EDITMESH_SCREEN_HIT_CACHE_MAX_COMPONENTS):
            return None

        rw_half = float(getattr(region, 'width', 0) or 0) * 0.5
        rh_half = float(getattr(region, 'height', 0) or 0) * 0.5
        if rw_half <= 0.0 or rh_half <= 0.0:
            return None
        mw = obj.matrix_world
        full_mat = rv3d.perspective_matrix @ mw
        cache = {
            'created': time.perf_counter(),
            'key': key,
            'px': None, 'py': None, 'pw': None,
            'edge_v0': None, 'edge_v1': None,
            'faces': {},
            'faces_depth': {},
            'complete': True,
            'numpy': False,
        }

        # Blender 5.x ships NumPy.  The cache is built from the live edit BMesh,
        # not from Mesh.foreach_get().  In Edit Mode the Mesh datablock can lag
        # behind the BMesh while Smart G-R-S / Smart Gizmo is actively editing or
        # immediately after a modal transform.  Using Mesh coordinates made a
        # fresh vertex appear as a definitive cache miss, so Immediate Select
        # sometimes fell through to background selection even when the pointer was
        # visibly on the vertex.  BMesh is the source of truth for editable-element
        # hit tests.
        if _np is None:
            return None
        try:
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            try:
                bm.verts.index_update()
            except Exception:
                pass
            try:
                bm.edges.index_update()
            except Exception:
                pass
            try:
                bm.faces.index_update()
            except Exception:
                pass
            nv = len(bm.verts)
            ne = len(bm.edges)
            if nv <= 0:
                return None
            # 1 頂点ずつ numpy の要素へ入れると 10 万頂点で数百 ms かかるので、まとめて読む（値は同じ）。
            coords = _np.fromiter(
                (c for v in bm.verts for c in v.co), dtype=_np.float64, count=nv * 3
            ).reshape(nv, 3)
            mat = _np.array([[float(v) for v in row] for row in full_mat], dtype=_np.float64)
            x = coords[:, 0]; y = coords[:, 1]; z = coords[:, 2]
            w = mat[3, 0] * x + mat[3, 1] * y + mat[3, 2] * z + mat[3, 3]
            # Avoid warnings for behind-camera vertices; validity is checked during query.
            safe_w = _np.where(_np.abs(w) > 1.0e-20, w, 1.0)
            px = ((mat[0, 0] * x + mat[0, 1] * y + mat[0, 2] * z + mat[0, 3]) / safe_w + 1.0) * rw_half
            py = ((mat[1, 0] * x + mat[1, 1] * y + mat[1, 2] * z + mat[1, 3]) / safe_w + 1.0) * rh_half
            cache['px'] = px
            cache['py'] = py
            cache['pw'] = w
            if use_edge:
                edge_idx = _np.fromiter(
                    (v.index for e in bm.edges for v in e.verts), dtype=_np.int32, count=ne * 2
                ).reshape(ne, 2)
                cache['edge_v0'] = edge_idx[:, 0]
                cache['edge_v1'] = edge_idx[:, 1]
            cache['numpy'] = True
        except Exception:
            return None

        # Face mode is face-center-dot only.  Faces are usually far fewer than dense
        # edge samples, so a compact BMesh center list is sufficient and keeps the
        # old face-dot behavior without ray-casting the full polygon area.
        if use_face:
            try:
                for f in bm.faces:
                    try:
                        if bool(getattr(f, 'hide', False)):
                            continue
                        if any(bool(getattr(v, 'hide', False)) for v in f.verts):
                            continue
                    except Exception:
                        pass
                    try:
                        center = f.calc_center_median()
                    except Exception:
                        try:
                            count = len(f.verts)
                            if count <= 0:
                                continue
                            center = Vector((0.0, 0.0, 0.0))
                            for v in f.verts:
                                center += v.co
                            center /= float(count)
                        except Exception:
                            continue
                    p = _csdt_project_local_point_depth_fast(full_mat, rw_half, rh_half, center)
                    if p is None:
                        continue
                    cache['faces'][int(f.index)] = (float(p[0]), float(p[1]))
                    cache['faces_depth'][int(f.index)] = float(p[2])
            except Exception:
                pass

        _CSDT_EDITMESH_SCREEN_HIT_CACHE[key] = cache
        _csdt_prune_editmesh_screen_hit_cache(cache['created'])
        return cache
    except Exception:
        return None


def _csdt_cached_editmesh_hit_is_live(context, obj, bm, hit, mx, my, v_radius, e_radius):
    """Validate a cached edit-mesh hit against the current live BMesh.

    Screen-space caches are intentionally short-lived, but editable geometry can
    still move between hover prefetch and mouse press.  A cached result is only
    accepted when the live BMesh element is still inside the configured hit
    radius at the current pointer location.
    """
    try:
        if hit is None or obj is None or bm is None:
            return False
        kind = str(hit[0] if len(hit) > 0 else '')
        idx = int(hit[1] if len(hit) > 1 else -1)
        if idx < 0:
            return False
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None:
            return False
        mw = getattr(obj, 'matrix_world', None)
        if mw is None:
            return False
        full_mat = rv3d.perspective_matrix @ mw
        rw_half = float(getattr(region, 'width', 0) or 0) * 0.5
        rh_half = float(getattr(region, 'height', 0) or 0) * 0.5
        if rw_half <= 0.0 or rh_half <= 0.0:
            return False

        def _project(co):
            try:
                x, y, z = co
                w = (float(full_mat[3][0]) * x + float(full_mat[3][1]) * y + float(full_mat[3][2]) * z + float(full_mat[3][3]))
                if w <= 0.0:
                    return None
                px = (float(full_mat[0][0]) * x + float(full_mat[0][1]) * y + float(full_mat[0][2]) * z + float(full_mat[0][3])) / w
                py = (float(full_mat[1][0]) * x + float(full_mat[1][1]) * y + float(full_mat[1][2]) * z + float(full_mat[1][3])) / w
                return ((px + 1.0) * rw_half, (py + 1.0) * rh_half)
            except Exception:
                return None

        mx_f = float(mx); my_f = float(my)
        if kind == 'VERT':
            bm.verts.ensure_lookup_table()
            if idx >= len(bm.verts):
                return False
            v = bm.verts[idx]
            try:
                if bool(getattr(v, 'hide', False)):
                    return False
            except Exception:
                pass
            p = _project(v.co)
            if p is None:
                return False
            dx = mx_f - float(p[0]); dy = my_f - float(p[1])
            return (dx * dx + dy * dy) <= (float(v_radius) * float(v_radius))
        if kind == 'EDGE':
            bm.edges.ensure_lookup_table()
            if idx >= len(bm.edges):
                return False
            e = bm.edges[idx]
            try:
                if bool(getattr(e, 'hide', False)):
                    return False
                if bool(getattr(e.verts[0], 'hide', False)) or bool(getattr(e.verts[1], 'hide', False)):
                    return False
            except Exception:
                pass
            p0 = _project(e.verts[0].co); p1 = _project(e.verts[1].co)
            if p0 is None or p1 is None:
                return False
            ax, ay = float(p0[0]), float(p0[1])
            bx, by = float(p1[0]), float(p1[1])
            abx = bx - ax; aby = by - ay
            apx = mx_f - ax; apy = my_f - ay
            ab2 = abx * abx + aby * aby
            if ab2 <= 1.0e-12:
                dx = mx_f - ax; dy = my_f - ay
            else:
                t = max(0.0, min(1.0, (apx * abx + apy * aby) / ab2))
                qx = ax + abx * t; qy = ay + aby * t
                dx = mx_f - qx; dy = my_f - qy
            return (dx * dx + dy * dy) <= (float(e_radius) * float(e_radius))
        if kind == 'FACE':
            bm.faces.ensure_lookup_table()
            if idx >= len(bm.faces):
                return False
            f = bm.faces[idx]
            try:
                if bool(getattr(f, 'hide', False)):
                    return False
                if any(bool(getattr(v, 'hide', False)) for v in f.verts):
                    return False
            except Exception:
                pass
            try:
                center = f.calc_center_median()
            except Exception:
                center = None
            if center is None:
                return False
            p = _project(center)
            if p is None:
                return False
            dx = mx_f - float(p[0]); dy = my_f - float(p[1])
            r = float(v_radius)
            return (dx * dx + dy * dy) <= (r * r)
    except Exception:
        pass
    return False

def _csdt_query_editmesh_screen_hit_cache(context, obj, bm, mx, my, use_vert, use_edge, use_face, v_radius, e_radius):
    """Query cached screen-space edit-mesh hits.

    Returns ``(hit, definitive)``.  ``definitive`` is True when a complete cache
    was available/built, so a ``None`` hit is a real miss and the old O(N) scan can
    be skipped.  If a cache cannot be built safely, ``definitive`` is False and
    the caller should fall back to the legacy path.
    """
    try:
        key = _csdt_editmesh_screen_cache_key(context, obj, bm, use_vert, use_edge, use_face, v_radius, e_radius)
        if key is None:
            return None, False
        now = time.perf_counter()
        cache = _CSDT_EDITMESH_SCREEN_HIT_CACHE.get(key)
        if not isinstance(cache, dict) or (now - float(cache.get('created', 0.0) or 0.0)) > float(_CSDT_EDITMESH_SCREEN_HIT_CACHE_TTL):
            if _CSDT_PREFETCH_MODE == 'hover':
                # マウスが動いている間は、大きなメッシュの貯めを作らない（10 万頂点で数百 ms 止まる）。
                try:
                    total = (len(bm.verts) if use_vert else 0) + (len(bm.edges) if use_edge else 0) + (len(bm.faces) if use_face else 0)
                except Exception:
                    total = 0
                if total > int(_CSDT_HOVER_PREFETCH_BUILD_MAX_COMPONENTS):
                    return None, False
            cache = _csdt_build_editmesh_screen_hit_cache(context, obj, bm, use_vert, use_edge, use_face, v_radius, e_radius, key)
        if not isinstance(cache, dict) or not bool(cache.get('complete', False)) or not bool(cache.get('numpy', False)):
            return None, False
        px = cache.get('px'); py = cache.get('py'); pw = cache.get('pw')
        if px is None or py is None or pw is None:
            return None, False
        mx_f = float(mx); my_f = float(my)
        backside_click = bool(_csdt_backside_element_click_select_enabled(context))

        if use_vert:
            try:
                r = float(v_radius)
                valid = pw > 0.0
                dx = px - mx_f
                dy = py - my_f
                mask = valid & (_np.abs(dx) <= r) & (_np.abs(dy) <= r)
                cand = _np.nonzero(mask)[0]
                if cand.size:
                    d2 = dx[cand] * dx[cand] + dy[cand] * dy[cand]
                    inside = d2 <= (r * r)
                    if bool(_np.any(inside)):
                        cand_in = cand[inside]
                        d2_in = d2[inside]
                        if backside_click:
                            order = _np.lexsort((pw[cand_in], d2_in))
                            candidates = [('VERT', int(cand_in[int(i)]), bool(bm.verts[int(cand_in[int(i)])].select)) for i in order[:int(_CSDT_BACKSIDE_CLICK_MAX_CANDIDATES)]]
                            chosen = _csdt_choose_backside_click_candidate(context, obj, mx_f, my_f, 'VERT', candidates)
                            if chosen is not None:
                                return chosen, True
                        else:
                            pos = int(_np.argmin(d2_in))
                            idx = int(cand_in[pos])
                            return ("VERT", idx, bool(bm.verts[idx].select)), True
            except Exception:
                pass

        if use_edge:
            try:
                v0 = cache.get('edge_v0'); v1 = cache.get('edge_v1')
                if v0 is not None and v1 is not None and len(v0) > 0:
                    r = float(e_radius)
                    x0 = px[v0]; y0 = py[v0]; x1 = px[v1]; y1 = py[v1]
                    valid = (pw[v0] > 0.0) & (pw[v1] > 0.0)
                    mask = valid & (mx_f >= _np.minimum(x0, x1) - r) & (mx_f <= _np.maximum(x0, x1) + r) & (my_f >= _np.minimum(y0, y1) - r) & (my_f <= _np.maximum(y0, y1) + r)
                    cand = _np.nonzero(mask)[0]
                    if cand.size:
                        cx0 = x0[cand]; cy0 = y0[cand]; cx1 = x1[cand]; cy1 = y1[cand]
                        abx = cx1 - cx0; aby = cy1 - cy0
                        apx = mx_f - cx0; apy = my_f - cy0
                        ab2 = abx * abx + aby * aby
                        t = _np.clip((apx * abx + apy * aby) / _np.maximum(ab2, 1.0e-12), 0.0, 1.0)
                        qx = cx0 + abx * t; qy = cy0 + aby * t
                        d2 = (mx_f - qx) * (mx_f - qx) + (my_f - qy) * (my_f - qy)
                        inside = d2 <= (r * r)
                        if bool(_np.any(inside)):
                            cand_in = cand[inside]
                            d2_in = d2[inside]
                            if backside_click:
                                depth = (pw[v0[cand_in]] + pw[v1[cand_in]]) * 0.5
                                order = _np.lexsort((depth, d2_in))
                                candidates = [('EDGE', int(cand_in[int(i)]), bool(bm.edges[int(cand_in[int(i)])].select)) for i in order[:int(_CSDT_BACKSIDE_CLICK_MAX_CANDIDATES)]]
                                chosen = _csdt_choose_backside_click_candidate(context, obj, mx_f, my_f, 'EDGE', candidates)
                                if chosen is not None:
                                    return chosen, True
                            else:
                                pos = int(_np.argmin(d2_in))
                                idx = int(cand_in[pos])
                                return ("EDGE", idx, bool(bm.edges[idx].select)), True
            except Exception:
                pass

        if use_face:
            if not backside_click:
                # Face clicks without the explicit backside option must remain
                # front-surface/face-dot only, so let the legacy ray-cast path below
                # decide instead of using the all-faces screen cache.
                return None, False
            try:
                candidates = []
                limit2 = float(v_radius) * float(v_radius)
                faces_depth = cache.get('faces_depth', {}) or {}
                for idx, p in (cache.get('faces', {}) or {}).items():
                    try:
                        dx = mx_f - float(p[0]); dy = my_f - float(p[1])
                        d2 = dx * dx + dy * dy
                        if d2 <= limit2:
                            depth = float(faces_depth.get(int(idx), 0.0) or 0.0)
                            candidates.append((float(d2), depth, 'FACE', int(idx), bool(bm.faces[int(idx)].select)))
                    except Exception:
                        pass
                if candidates:
                    candidates.sort(key=lambda item: (item[0], item[1], item[3]))
                    choice_list = [(item[2], item[3], item[4]) for item in candidates[:int(_CSDT_BACKSIDE_CLICK_MAX_CANDIDATES)]]
                    chosen = _csdt_choose_backside_click_candidate(context, obj, mx_f, my_f, 'FACE', choice_list)
                    if chosen is not None:
                        return chosen, True
            except Exception:
                pass

        return None, True
    except Exception:
        return None, False

def _prefetch_immediate_select_hit(context, mx, my, fallback_obj=None, mode='hover'):
    """Warm and remember the configured hit-test result for Immediate Select.

    This is called from Smart Gizmo hover processing.  It does not change
    selection; it only moves the expensive projection work before the press so the
    actual click can select immediately.  Both hits and strict misses are kept for
    a very short time so the next LEFTMOUSE PRESS can avoid rebuilding the same
    screen-space probe.
    """
    try:
        mode = str(getattr(context, 'mode', '') or '')
        obj = fallback_obj if fallback_obj is not None else getattr(context, 'active_object', None)
        target_obj = obj
        hit = None
        definitive = False
        if mode == 'EDIT_MESH' and obj is not None and getattr(obj, 'type', None) == 'MESH':
            if bool(_csdt_backside_element_click_select_enabled(context)):
                # Back-side click selection uses repeated PRESS events to cycle
                # through overlapped candidates.  A hover prefetch must not run
                # that cycling logic or it will consume the first/back candidate
                # before the user actually clicks.
                return obj, None
            global _CSDT_PREFETCH_MODE
            _CSDT_PREFETCH_MODE = 'rest' if mode == 'rest' else 'hover'
            try:
                target_obj, hit = _hit_test_editmesh_any(context, obj, int(mx), int(my))
            finally:
                _CSDT_PREFETCH_MODE = None
            definitive = True
        elif mode == 'OBJECT':
            hit = _hit_test_object(context, int(mx), int(my))
            target_obj = hit[0] if hit is not None else obj
            definitive = True
        elif mode == 'EDIT_LATTICE' and obj is not None and getattr(obj, 'type', None) == 'LATTICE':
            target_obj, hit = _hit_test_editlattice_any(context, obj, int(mx), int(my))
            definitive = True
        elif mode in {'EDIT_CURVE', 'EDIT_SURFACE'} and obj is not None and getattr(obj, 'type', None) in {'CURVE', 'SURFACE'}:
            target_obj, hit = _hit_test_editcurve_any(context, obj, int(mx), int(my))
            definitive = True
        if definitive:
            if hit is not None or mode == 'OBJECT':
                _csdt_store_immediate_prefetch_hit(context, obj, int(mx), int(my), target_obj, hit, definitive=True)
            else:
                # Do not cache editable-element misses.  A stale miss on the next
                # LEFTMOUSE PRESS is more harmful than a small live verification
                # cost because it turns an element click into background select.
                global _CSDT_IMMEDIATE_SELECT_PREFETCH_HIT
                _CSDT_IMMEDIATE_SELECT_PREFETCH_HIT = None
        return target_obj, hit
    except Exception:
        pass
    return None, None

def _editmesh_selected_count(context, obj):
    bm = bmesh.from_edit_mesh(obj.data)
    mode = _mesh_select_mode(context)
    if mode == "FACE":
        bm.faces.ensure_lookup_table()
        return sum(1 for f in bm.faces if f.select)
    if mode == "EDGE":
        bm.edges.ensure_lookup_table()
        return sum(1 for e in bm.edges if e.select)
    bm.verts.ensure_lookup_table()
    return sum(1 for v in bm.verts if v.select)

def _raycast_face_index(context, obj, bm, mx, my):
    region, rv3d = context.region, context.region_data
    if region is None or rv3d is None: return None
    try: bvh = BVHTree.FromBMesh(bm)
    except Exception: return None
    mw = obj.matrix_world
    origin_w = view3d_utils.region_2d_to_origin_3d(region, rv3d, (mx, my))
    direction_w = view3d_utils.region_2d_to_vector_3d(region, rv3d, (mx, my))
    imw = mw.inverted()
    origin_l = imw @ origin_w
    direction_l = (imw.to_3x3() @ direction_w).normalized()
    hit = bvh.ray_cast(origin_l, direction_l)
    if not hit: return None
    face_index = hit[2]
    if face_index is None or face_index < 0 or face_index >= len(bm.faces): return None
    return face_index

def _hit_test_editmesh(context, obj, mx, my):
    v_radius, e_radius = _csdt_element_hit_radii(context)

    region = context.region
    rv3d = context.region_data
    if region is None or rv3d is None:
        return None

    # Quad View delivers mouse coordinates in the visible half-size pane, while
    # View3D projection helpers/matrices use the full physical WINDOW region.
    # Convert the click before any cache/raycast/matrix hit test, and scale the
    # configured sensitivity so the visible pixel radius remains unchanged.
    try:
        q_scale = float(_quadview_visible_to_projection_scale(context, mx=mx, my=my))
        if q_scale != 1.0:
            mx, my = _quadview_visible_xy_to_projection_xy(context, mx, my)
            v_radius = float(v_radius) * q_scale
            e_radius = float(e_radius) * q_scale
    except Exception:
        pass

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    # Keep BMesh element indices valid for hit results after topology edits.
    # Some Blender edit operations leave BMVert/BMEdge/BMFace.index dirty until
    # an explicit update; returning a stale index can make the press look like a
    # miss or select a different element.
    try:
        bm.verts.index_update()
    except Exception:
        pass
    try:
        bm.edges.index_update()
    except Exception:
        pass
    try:
        bm.faces.index_update()
    except Exception:
        pass
    mw = obj.matrix_world

    try:
        sel_modes = tuple(bool(v) for v in context.tool_settings.mesh_select_mode)
        if len(sel_modes) != 3:
            sel_modes = (True, False, False)
    except Exception:
        sel_modes = (True, False, False)
    use_vert, use_edge, use_face = sel_modes
    if not (use_vert or use_edge or use_face):
        use_vert = True

    try:
        allow_backside_click = bool(_csdt_backside_element_click_select_enabled(context))
    except Exception:
        allow_backside_click = False
    backside_click = allow_backside_click

    # Fast path for Immediate Select: query a cached screen-space grid of
    # editable elements.  The cache now understands the optional back-side click
    # candidate cycle, so it is safe to keep the low-latency path active even
    # when Backside Element Click Select is enabled.
    try:
        cached_hit, cache_definitive = _csdt_query_editmesh_screen_hit_cache(
            context, obj, bm, mx, my, use_vert, use_edge, use_face, v_radius, e_radius
        )
        if cache_definitive and cached_hit is not None:
            if _csdt_cached_editmesh_hit_is_live(context, obj, bm, cached_hit, mx, my, v_radius, e_radius):
                return cached_hit
        # A cached miss is no longer treated as a final editable-element miss.
        # If the edit BMesh changed after hover prefetch or after a transform, a
        # reused miss is exactly what makes Immediate Select fall through into
        # background selection.  Continue into the live BMesh path below.
    except Exception:
        pass
    if _CSDT_PREFETCH_MODE is not None:
        # ホバーの先読みは外れを貯めない（本物のクリックが確かめ直す）ので、全要素の総当たりは
        # 毎回捨てられる。重いメッシュでマウスを動かすたびに止まる元だったので、先読みでは行わない。
        return None

    full_mat = rv3d.perspective_matrix @ mw
    m00, m01, m02, m03 = full_mat[0]
    m10, m11, m12, m13 = full_mat[1]
    m30, m31, m32, m33 = full_mat[3]

    rw_half = region.width * 0.5
    rh_half = region.height * 0.5
    if rw_half <= 0.0 or rh_half <= 0.0:
        return None

    ndc_mx = (mx / rw_half) - 1.0
    ndc_my = (my / rh_half) - 1.0
    min_region = max(1.0, float(min(region.width, region.height)))
    backside_click = bool(allow_backside_click)

    def _project_local_tuple(co):
        try:
            x, y, z = co
            w = m30 * x + m31 * y + m32 * z + m33
            if w <= 0.0:
                return None
            px = (m00 * x + m01 * y + m02 * z + m03) / w
            py = (m10 * x + m11 * y + m12 * z + m13) / w
            rx = (px + 1.0) * rw_half
            ry = (py + 1.0) * rh_half
            return px, py, rx, ry, w
        except Exception:
            return None

    def _vertex_hit():
        best_d2 = 1e18
        best_idx = None
        candidates = [] if backside_click else None
        ndc_tol_v = (v_radius / min_region) * 2.0
        v_rad2 = v_radius * v_radius

        for v in bm.verts:
            try:
                if bool(getattr(v, 'hide', False)):
                    continue
            except Exception:
                pass
            x, y, z = v.co
            w = m30 * x + m31 * y + m32 * z + m33
            if w <= 0.0:
                continue

            px = (m00 * x + m01 * y + m02 * z + m03) / w
            py = (m10 * x + m11 * y + m12 * z + m13) / w

            if abs(px - ndc_mx) > ndc_tol_v or abs(py - ndc_my) > ndc_tol_v:
                continue

            rx = (px + 1.0) * rw_half
            ry = (py + 1.0) * rh_half
            dx = mx - rx
            dy = my - ry
            d2 = dx * dx + dy * dy
            if d2 <= v_rad2 and candidates is not None:
                try:
                    candidates.append((float(d2), float(w), 'VERT', int(v.index), bool(v.select)))
                except Exception:
                    pass
            if d2 < best_d2:
                best_d2 = d2
                best_idx = v.index

        if candidates:
            candidates.sort(key=lambda item: (item[0], item[1], item[3]))
            chosen = _csdt_choose_backside_click_candidate(
                context, obj, mx, my, 'VERT', [(item[2], item[3], item[4]) for item in candidates]
            )
            if chosen is not None:
                return chosen
        if best_idx is not None and best_d2 <= v_rad2:
            return ("VERT", best_idx, bool(bm.verts[best_idx].select))
        return None

    def _edge_hit():
        best_d2 = 1e18
        best_idx = None
        candidates = [] if backside_click else None
        ndc_tol_e = (e_radius / min_region) * 2.0
        e_rad2 = e_radius * e_radius

        for e in bm.edges:
            try:
                if bool(getattr(e, 'hide', False)):
                    continue
            except Exception:
                pass
            v0, v1 = e.verts
            try:
                if bool(getattr(v0, 'hide', False)) or bool(getattr(v1, 'hide', False)):
                    continue
            except Exception:
                pass
            x0, y0, z0 = v0.co
            w0 = m30 * x0 + m31 * y0 + m32 * z0 + m33
            if w0 <= 0.0:
                continue

            x1, y1, z1 = v1.co
            w1 = m30 * x1 + m31 * y1 + m32 * z1 + m33
            if w1 <= 0.0:
                continue

            px0 = (m00 * x0 + m01 * y0 + m02 * z0 + m03) / w0
            py0 = (m10 * x0 + m11 * y0 + m12 * z0 + m13) / w0
            px1 = (m00 * x1 + m01 * y1 + m02 * z1 + m03) / w1
            py1 = (m10 * x1 + m11 * y1 + m12 * z1 + m13) / w1

            if ndc_mx < min(px0, px1) - ndc_tol_e or ndc_mx > max(px0, px1) + ndc_tol_e:
                continue
            if ndc_my < min(py0, py1) - ndc_tol_e or ndc_my > max(py0, py1) + ndc_tol_e:
                continue

            rx0 = (px0 + 1.0) * rw_half
            ry0 = (py0 + 1.0) * rh_half
            rx1 = (px1 + 1.0) * rw_half
            ry1 = (py1 + 1.0) * rh_half

            abx = rx1 - rx0
            aby = ry1 - ry0
            apx = mx - rx0
            apy = my - ry0
            ab_len2 = abx * abx + aby * aby
            if ab_len2 <= 1e-12:
                dx = mx - rx0
                dy = my - ry0
                d2 = dx * dx + dy * dy
            else:
                t = (apx * abx + apy * aby) / ab_len2
                t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
                cx = rx0 + abx * t
                cy = ry0 + aby * t
                dx = mx - cx
                dy = my - cy
                d2 = dx * dx + dy * dy

            if d2 <= e_rad2 and candidates is not None:
                try:
                    candidates.append((float(d2), (float(w0) + float(w1)) * 0.5, 'EDGE', int(e.index), bool(e.select)))
                except Exception:
                    pass
            if d2 < best_d2:
                best_d2 = d2
                best_idx = e.index

        if candidates:
            candidates.sort(key=lambda item: (item[0], item[1], item[3]))
            chosen = _csdt_choose_backside_click_candidate(
                context, obj, mx, my, 'EDGE', [(item[2], item[3], item[4]) for item in candidates]
            )
            if chosen is not None:
                return chosen
        if best_idx is not None and best_d2 <= e_rad2:
            return ("EDGE", best_idx, bool(bm.edges[best_idx].select))
        return None

    face_index_cache = {"ready": False, "value": None}

    def _face_index():
        if not face_index_cache["ready"]:
            face_index_cache["value"] = _raycast_face_index(context, obj, bm, mx, my)
            face_index_cache["ready"] = True
        return face_index_cache["value"]

    def _face_center(f):
        try:
            return f.calc_center_median()
        except Exception:
            try:
                count = len(f.verts)
                if count <= 0:
                    return None
                center = Vector((0.0, 0.0, 0.0))
                for v in f.verts:
                    center += v.co
                center /= float(count)
                return center
            except Exception:
                return None

    def _face_eligible(f):
        try:
            if bool(getattr(f, 'hide', False)):
                return False
        except Exception:
            pass
        try:
            if any(bool(getattr(v, 'hide', False)) for v in f.verts):
                return False
        except Exception:
            pass
        return True

    def _face_hit():
        """Hit-test face mode against the face-center dot only.

        By default the face dot is resolved from the front ray hit so ordinary
        clicks stay front-surface safe.  When Backside Element Click Select is
        enabled, every projected face-center dot inside the configured vertex hit
        radius becomes a click candidate, allowing repeated clicks at the same
        position to cycle from the front face to back-side/occluded face dots.
        """
        try:
            face_radius = max(1.0, min(100.0, float(v_radius)))
        except Exception:
            face_radius = 20.0
        face_radius2 = face_radius * face_radius

        if backside_click:
            candidates = []
            for f in bm.faces:
                try:
                    if bool(getattr(f, 'hide', False)):
                        continue
                    if any(bool(getattr(v, 'hide', False)) for v in f.verts):
                        continue
                except Exception:
                    pass
                try:
                    center = f.calc_center_median()
                except Exception:
                    try:
                        count = len(f.verts)
                        if count <= 0:
                            continue
                        center = Vector((0.0, 0.0, 0.0))
                        for v in f.verts:
                            center += v.co
                        center /= float(count)
                    except Exception:
                        continue
                x, y, z = center
                w = m30 * x + m31 * y + m32 * z + m33
                if w <= 0.0:
                    continue
                px = (m00 * x + m01 * y + m02 * z + m03) / w
                py = (m10 * x + m11 * y + m12 * z + m13) / w
                rx = (px + 1.0) * rw_half
                ry = (py + 1.0) * rh_half
                dx = mx - rx
                dy = my - ry
                d2 = dx * dx + dy * dy
                if d2 <= face_radius2:
                    try:
                        candidates.append((float(d2), float(w), 'FACE', int(f.index), bool(f.select)))
                    except Exception:
                        pass
            if candidates:
                candidates.sort(key=lambda item: (item[0], item[1], item[3]))
                chosen = _csdt_choose_backside_click_candidate(
                    context, obj, mx, my, 'FACE', [(item[2], item[3], item[4]) for item in candidates]
                )
                if chosen is not None:
                    return chosen
            return None

        fidx = _face_index()
        if fidx is None:
            return None
        try:
            f = bm.faces[fidx]
        except Exception:
            return None
        try:
            if bool(getattr(f, 'hide', False)):
                return None
        except Exception:
            pass
        try:
            if any(bool(getattr(v, 'hide', False)) for v in f.verts):
                return None
        except Exception:
            pass

        try:
            center = f.calc_center_median()
        except Exception:
            try:
                count = len(f.verts)
                if count <= 0:
                    return None
                center = Vector((0.0, 0.0, 0.0))
                for v in f.verts:
                    center += v.co
                center /= float(count)
            except Exception:
                return None

        x, y, z = center
        w = m30 * x + m31 * y + m32 * z + m33
        if w <= 0.0:
            return None
        px = (m00 * x + m01 * y + m02 * z + m03) / w
        py = (m10 * x + m11 * y + m12 * z + m13) / w
        rx = (px + 1.0) * rw_half
        ry = (py + 1.0) * rh_half

        dx = mx - rx
        dy = my - ry
        if (dx * dx + dy * dy) > face_radius2:
            return None
        return ("FACE", fidx, bool(f.select))

    # When more than one component mode is enabled, keep a predictable pick order:
    # vertex hit range, then edge hit range, then the face-center dot.  Once a
    # component hit is found, the click is never allowed to fall through into
    # background Box / Circle / Lasso selection.  Face polygon area outside the
    # center dot intentionally remains background.
    if use_vert:
        hit = _vertex_hit()
        if hit is not None:
            return hit
    if use_edge:
        hit = _edge_hit()
        if hit is not None:
            return hit
        # Fallback for clipped/partially visible edge segments.  This is the
        # only expensive part of click hit-testing because it uses Blender's
        # projection helper repeatedly.  Keep it bounded so dense edit meshes do
        # not become progressively heavy after several Smart Gizmo/Select clicks.
        try:
            edge_count = len(bm.edges)
        except Exception:
            edge_count = 0
        if edge_count <= int(_CSDT_EDGE_CLICK_FALLBACK_MAX_EDGES):
            try:
                best_d = None
                best_idx = None
                start_t = time.perf_counter()
                checked = 0
                for e in bm.edges:
                    checked += 1
                    if (checked & 0xFF) == 0 and (time.perf_counter() - start_t) > float(_CSDT_EDGE_CLICK_FALLBACK_TIME_BUDGET):
                        break
                    try:
                        if bool(getattr(e, 'hide', False)):
                            continue
                        if bool(getattr(e.verts[0], 'hide', False)) or bool(getattr(e.verts[1], 'hide', False)):
                            continue
                    except Exception:
                        pass
                    d = _csdt_polyline_distance_to_point_2d(
                        _csdt_edge_projected_points(region, rv3d, mw, e, steps=4), mx, my
                    )
                    if d is None:
                        continue
                    if best_d is None or d < best_d:
                        best_d = d
                        best_idx = e.index
                        if best_d <= max(1.0, e_radius * 0.45):
                            break
                if best_idx is not None and best_d is not None and best_d <= e_radius:
                    return ("EDGE", best_idx, bool(bm.edges[best_idx].select))
            except Exception:
                pass
    if use_face:
        hit = _face_hit()
        if hit is not None:
            return hit

    if use_vert:
        # Compatibility with older STS behavior: if the press is inside an already
        # fully selected face while vertex mode is active, keep the held drag as a
        # transformable selection hit instead of treating it as empty background.
        fidx = _face_index()
        if fidx is not None:
            try:
                f = bm.faces[fidx]
                if not bool(getattr(f, 'hide', False)) and all(v.select for v in f.verts) and len(f.verts) > 0:
                    return ("VERT", f.verts[0].index, True)
            except Exception:
                pass

    return None



def _editmesh_selected_total_from_mesh_data(me):
    """Return Blender-maintained edit selection totals, or None if unavailable."""
    if me is None:
        return None
    total = 0
    seen = False
    for attr in ('total_vert_sel', 'total_edge_sel', 'total_face_sel'):
        try:
            if hasattr(me, attr):
                seen = True
                total += int(getattr(me, attr, 0) or 0)
        except Exception:
            pass
    return total if seen else None


def _editmesh_selection_count_fast(context):
    """Fast edit-mesh selection count using Mesh.total_*_sel when Blender exposes it."""
    try:
        objs = getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None)
    except Exception:
        objs = None
    if not objs:
        obj = getattr(context, 'active_object', None)
        objs = [obj] if obj is not None else []
    total = 0
    any_totals = False
    for o in objs:
        if not o or getattr(o, 'type', None) != 'MESH':
            continue
        cnt = _editmesh_selected_total_from_mesh_data(getattr(o, 'data', None))
        if cnt is None:
            continue
        any_totals = True
        total += int(cnt)
    return total if any_totals else None



def _csdt_editmesh_object_cache_key(obj):
    try:
        return (int(obj.as_pointer()), int(obj.data.as_pointer()))
    except Exception:
        try:
            return (id(obj), id(getattr(obj, 'data', None)))
        except Exception:
            return None


def _csdt_clear_editmesh_exclusive_select_cache(obj=None):
    try:
        if obj is None:
            _CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE.clear()
            return
        key = _csdt_editmesh_object_cache_key(obj)
        if key is not None:
            _CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE.pop(key, None)
    except Exception:
        pass


def _csdt_single_element_expected_total(elem, kind):
    try:
        kind = str(kind or '').upper()
        if kind == 'VERT':
            return 1
        if kind == 'EDGE':
            return 1 + len(getattr(elem, 'verts', []) or [])
        if kind == 'FACE':
            return 1 + len(getattr(elem, 'edges', []) or []) + len(getattr(elem, 'verts', []) or [])
    except Exception:
        pass
    return None


def _csdt_record_editmesh_exclusive_selection(context, obj, bm, elem, kind):
    try:
        key = _csdt_editmesh_object_cache_key(obj)
        if key is None or elem is None:
            return
        total = _csdt_single_element_expected_total(elem, kind)
        if total is None:
            try:
                total = _editmesh_selection_count_fast(context)
            except Exception:
                total = None
        idx = int(getattr(elem, 'index', -1))
        if idx < 0:
            return
        _CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE[key] = {
            'time': time.perf_counter(),
            'kind': str(kind or '').upper(),
            'index': idx,
            'total': int(total) if total is not None else None,
        }
    except Exception:
        pass


def _csdt_try_clear_cached_editmesh_exclusive_selection(context, obj):
    """Clear the previous Smart Transform single selection without select_all().

    This is intentionally conservative.  It is used only when Blender's edit-mesh
    selection totals and the cached active element prove that the current selection
    is still the one this add-on made.  If the user or another tool changed the
    selection, it returns False and the normal native full deselect path is used.
    """
    try:
        key = _csdt_editmesh_object_cache_key(obj)
        cache = _CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE.get(key) if key is not None else None
        if not isinstance(cache, dict):
            return False
        if time.perf_counter() - float(cache.get('time', 0.0) or 0.0) > float(_CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE_TTL):
            _CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE.pop(key, None)
            return False
        expected_total = cache.get('total', None)
        fast_total = _editmesh_selection_count_fast(context)
        if expected_total is None or fast_total is None or int(fast_total) != int(expected_total):
            return False
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        kind = str(cache.get('kind', '') or '').upper()
        idx = int(cache.get('index', -1))
        elem = None
        if kind == 'VERT' and 0 <= idx < len(bm.verts):
            elem = bm.verts[idx]
        elif kind == 'EDGE' and 0 <= idx < len(bm.edges):
            elem = bm.edges[idx]
        elif kind == 'FACE' and 0 <= idx < len(bm.faces):
            elem = bm.faces[idx]
        if elem is None or not bool(getattr(elem, 'select', False)):
            return False
        try:
            bm.select_history.clear()
        except Exception:
            pass
        if kind == 'VERT':
            try: elem.select_set(False)
            except Exception: elem.select = False
        elif kind == 'EDGE':
            try: elem.select_set(False)
            except Exception: elem.select = False
            try:
                for v in elem.verts:
                    try: v.select_set(False)
                    except Exception: v.select = False
            except Exception:
                pass
        elif kind == 'FACE':
            try: elem.select_set(False)
            except Exception: elem.select = False
            try:
                for e in elem.edges:
                    try: e.select_set(False)
                    except Exception: e.select = False
                for v in elem.verts:
                    try: v.select_set(False)
                    except Exception: v.select = False
            except Exception:
                pass
        else:
            return False
        _CSDT_EDITMESH_EXCLUSIVE_SELECT_CACHE.pop(key, None)
        return True
    except Exception:
        return False

def _editmesh_select_all_native(context, action='DESELECT'):
    """Use Blender's C-side edit-mesh select_all when possible."""
    try:
        with _temp_override_view3d(context):
            bpy.ops.mesh.select_all(action=str(action or 'DESELECT'))
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
        return True
    except Exception:
        try:
            bpy.ops.mesh.select_all(action=str(action or 'DESELECT'))
            _invalidate_gizmo_cache()
            try: _tag_view3d_redraw()
            except Exception: pass
            return True
        except Exception:
            return False


def _editmesh_select_single(context, obj, hit):
    # PRESS-time Immediate Select must not pay the full edit-mesh deselect cost
    # when there is nothing to clear.  On dense edge meshes, calling Blender's
    # mesh.select_all(DESELECT) even for an already-empty selection is the main
    # source of the perceptible click lag.  Use Blender's maintained selection
    # totals first; fall back to the native deselect only when the totals are not
    # available or there is an actual selection to clear.
    need_deselect = True
    try:
        fast_total = _editmesh_selection_count_fast(context)
        if fast_total is not None and int(fast_total) <= 0:
            need_deselect = False
    except Exception:
        need_deselect = True
    if need_deselect:
        if _csdt_try_clear_cached_editmesh_exclusive_selection(context, obj):
            need_deselect = False
    if need_deselect:
        _csdt_clear_editmesh_exclusive_select_cache()
        if not _editmesh_select_all_native(context, 'DESELECT'):
            try:
                objs = getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None)
                if objs:
                    for o in objs:
                        if not o or getattr(o, "type", None) != "MESH": continue
                        try:
                            bm2 = bmesh.from_edit_mesh(o.data)
                            bm2.verts.ensure_lookup_table()
                            bm2.edges.ensure_lookup_table()
                            bm2.faces.ensure_lookup_table()
                            for v in bm2.verts: v.select = False
                            for e in bm2.edges: e.select = False
                            for f in bm2.faces: f.select = False
                            bm2.select_history.clear()
                            bmesh.update_edit_mesh(o.data, loop_triangles=False, destructive=False)
                        except Exception: pass
            except Exception: pass

    kind, idx, _sel = hit
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.select_history.clear()

    if kind == "VERT":
        v = bm.verts[idx]; v.select = True; bm.select_history.add(v)
    elif kind == "EDGE":
        e = bm.edges[idx]; e.select = True
        try: e.verts[0].select = True; e.verts[1].select = True
        except Exception: pass
        bm.select_history.add(e)
    elif kind == "FACE":
        f = bm.faces[idx]; f.select = True
        try:
            for v in f.verts: v.select = True
            for e in f.edges: e.select = True
        except Exception: pass
        bm.select_history.add(f)

    try:
        if kind == "VERT":
            _csdt_record_editmesh_exclusive_selection(context, obj, bm, bm.verts[idx], kind)
        elif kind == "EDGE":
            _csdt_record_editmesh_exclusive_selection(context, obj, bm, bm.edges[idx], kind)
        elif kind == "FACE":
            _csdt_record_editmesh_exclusive_selection(context, obj, bm, bm.faces[idx], kind)
    except Exception:
        pass
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    _invalidate_gizmo_cache()
    try: _tag_view3d_redraw()
    except Exception: pass

def _editmesh_set_active_only(context, obj, hit):
    kind, idx, _sel = hit
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    bm.select_history.clear()
    try:
        if kind == "VERT": bm.select_history.add(bm.verts[idx])
        elif kind == "EDGE": bm.select_history.add(bm.edges[idx])
        elif kind == "FACE": bm.select_history.add(bm.faces[idx])
    except Exception: pass
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    _invalidate_gizmo_cache()
    try: _tag_view3d_redraw()
    except Exception: pass

def _hit_test_editlattice(context, obj, mx, my):
    radius, _edge_radius = _csdt_element_hit_radii(context)
    region = context.region
    rv3d = context.region_data
    if not region or not rv3d: return None
    try: pts = obj.data.points
    except Exception: return None
    
    mw = obj.matrix_world
    full_mat = rv3d.perspective_matrix @ mw
    m00, m01, m02, m03 = full_mat[0]
    m10, m11, m12, m13 = full_mat[1]
    m30, m31, m32, m33 = full_mat[3]
    
    rw_half = region.width * 0.5
    rh_half = region.height * 0.5
    ndc_mx = (mx / rw_half) - 1.0
    ndc_my = (my / rh_half) - 1.0
    ndc_tol = (radius / min(region.width, region.height)) * 2.0
    rad2 = radius * radius
    
    best_d2 = 1e18
    best_idx = None
    
    for i, p in enumerate(pts):
        try: co = p.co_deform if hasattr(p, "co_deform") else p.co
        except Exception: continue
        
        x, y, z = co
        w = m30*x + m31*y + m32*z + m33
        if w <= 0.0: continue
        
        px = (m00*x + m01*y + m02*z + m03) / w
        py = (m10*x + m11*y + m12*z + m13) / w
        
        if abs(px - ndc_mx) > ndc_tol or abs(py - ndc_my) > ndc_tol:
            continue
            
        rx = (px + 1.0) * rw_half
        ry = (py + 1.0) * rh_half
        
        dx = mx - rx; dy = my - ry
        d2 = dx*dx + dy*dy
        
        if d2 < best_d2:
            best_d2 = d2; best_idx = i
            
    if best_idx is not None and best_d2 <= rad2:
        try: sel = bool(pts[best_idx].select)
        except Exception: sel = False
        return ("POINT", best_idx, sel)
    return None

def _editlattice_select_single(context, obj, hit, mx, my):
    try:
        with _temp_override_view3d(context):
            bpy.ops.lattice.select_all(action="DESELECT")
    except Exception: pass
    _view3d_select_at(context, mx, my, extend=False, deselect=False, toggle=False, disallow_object_select=True)
    try: obj.data.update_tag(); obj.update_from_editmode()
    except Exception: pass
    _invalidate_gizmo_cache()

def _editlattice_set_active_only(context, obj, hit, mx, my):
    _view3d_select_at(context, mx, my, extend=True, deselect=False, toggle=False, disallow_object_select=True)
    _invalidate_gizmo_cache()



def _curve_point_xyz(point):
    try:
        co = getattr(point, 'co')
        return Vector((float(co.x), float(co.y), float(co.z)))
    except Exception:
        try:
            return Vector((float(point.co[0]), float(point.co[1]), float(point.co[2])))
        except Exception:
            return Vector((0.0, 0.0, 0.0))


def _curve_component_items(obj, selected_only=False):
    items = []
    try:
        splines = getattr(getattr(obj, 'data', None), 'splines', []) or []
    except Exception:
        splines = []
    for si, spline in enumerate(splines):
        try:
            for pi, bp in enumerate(getattr(spline, 'bezier_points', []) or []):
                for attr, sel_attr in (
                    ('co', 'select_control_point'),
                    ('handle_left', 'select_left_handle'),
                    ('handle_right', 'select_right_handle'),
                ):
                    try:
                        selected = bool(getattr(bp, sel_attr, False))
                        if selected or not selected_only:
                            items.append((('BEZIER', int(si), int(pi), attr), Vector(getattr(bp, attr)).copy(), selected))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            for pi, point in enumerate(getattr(spline, 'points', []) or []):
                try:
                    selected = bool(getattr(point, 'select', False))
                    if selected or not selected_only:
                        items.append((('POINT', int(si), int(pi), 'co'), _curve_point_xyz(point), selected))
                except Exception:
                    pass
        except Exception:
            pass
    return items


def _curve_component_selected(obj, key):
    try:
        kind, si, pi, attr = key
        spline = obj.data.splines[int(si)]
        if kind == 'BEZIER':
            bp = spline.bezier_points[int(pi)]
            if attr == 'handle_left':
                return bool(getattr(bp, 'select_left_handle', False))
            if attr == 'handle_right':
                return bool(getattr(bp, 'select_right_handle', False))
            return bool(getattr(bp, 'select_control_point', False))
        point = spline.points[int(pi)]
        return bool(getattr(point, 'select', False))
    except Exception:
        return False


def _curve_clear_selection(context):
    try:
        for obj in _csdt_edit_targets(context, getattr(context, 'active_object', None)):
            if not obj or getattr(obj, 'type', None) not in {'CURVE', 'SURFACE'}:
                continue
            try:
                for spline in getattr(obj.data, 'splines', []) or []:
                    for bp in getattr(spline, 'bezier_points', []) or []:
                        try: bp.select_control_point = False
                        except Exception: pass
                        try: bp.select_left_handle = False
                        except Exception: pass
                        try: bp.select_right_handle = False
                        except Exception: pass
                    for point in getattr(spline, 'points', []) or []:
                        try: point.select = False
                        except Exception: pass
                try: obj.data.update_tag()
                except Exception: pass
            except Exception:
                pass
    except Exception:
        pass


def _curve_select_component(obj, key, select=True):
    try:
        kind, si, pi, attr = key
        spline = obj.data.splines[int(si)]
        if kind == 'BEZIER':
            bp = spline.bezier_points[int(pi)]
            if attr == 'handle_left':
                bp.select_left_handle = bool(select)
            elif attr == 'handle_right':
                bp.select_right_handle = bool(select)
            else:
                bp.select_control_point = bool(select)
            return True
        if kind == 'POINT':
            point = spline.points[int(pi)]
            point.select = bool(select)
            return True
    except Exception:
        pass
    return False


def _curve_select_segment(obj, seg_key, select=True):
    try:
        _kind, si, a, b = seg_key
        spline = obj.data.splines[int(si)]
        if hasattr(spline, 'bezier_points') and len(getattr(spline, 'bezier_points', []) or []) > 0:
            pts = spline.bezier_points
            pts[int(a)].select_control_point = bool(select)
            pts[int(b)].select_control_point = bool(select)
            return True
        pts = spline.points
        pts[int(a)].select = bool(select)
        pts[int(b)].select = bool(select)
        return True
    except Exception:
        return False


def _project_world_2d(context, world_co):
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None:
            return None
        p = view3d_utils.location_3d_to_region_2d(region, rv3d, world_co)
        if p is None:
            return None
        return _quadview_projection_xy_to_visible_xy(context, float(p.x), float(p.y), region=region, rv3d=rv3d)
    except Exception:
        return None


def _bezier_interp(p0, h0, h1, p1, t):
    u = 1.0 - t
    return (p0 * (u * u * u)) + (h0 * (3.0 * u * u * t)) + (h1 * (3.0 * u * t * t)) + (p1 * (t * t * t))


def _hit_test_editcurve(context, obj, mx, my):
    v_radius, e_radius = _csdt_element_hit_radii(context)
    mw = getattr(obj, 'matrix_world', Matrix.Identity(4))
    best_point = (1e18, None)

    def _consider_point(key, co, selected):
        nonlocal best_point
        try:
            p2 = _project_world_2d(context, mw @ co)
            if p2 is None:
                return
            d2 = (float(mx) - p2[0]) ** 2 + (float(my) - p2[1]) ** 2
            if d2 < best_point[0]:
                best_point = (d2, ('CURVE', key, bool(selected)))
        except Exception:
            pass

    try:
        for key, co, selected in _curve_component_items(obj, selected_only=False):
            _consider_point(key, co, selected)
    except Exception:
        pass
    if best_point[1] is not None and best_point[0] <= (v_radius * v_radius):
        return best_point[1]

    best_seg = (1e18, None)
    try:
        splines = getattr(getattr(obj, 'data', None), 'splines', []) or []
    except Exception:
        splines = []

    for si, spline in enumerate(splines):
        try:
            bps = list(getattr(spline, 'bezier_points', []) or [])
        except Exception:
            bps = []
        if bps:
            count = len(bps)
            last = count if bool(getattr(spline, 'use_cyclic_u', False)) else max(0, count - 1)
            for i in range(last):
                j = (i + 1) % count
                try:
                    p0 = Vector(bps[i].co).copy()
                    h0 = Vector(bps[i].handle_right).copy()
                    h1 = Vector(bps[j].handle_left).copy()
                    p1 = Vector(bps[j].co).copy()
                    prev = _project_world_2d(context, mw @ p0)
                    if prev is None:
                        continue
                    for step in range(1, 13):
                        t = step / 12.0
                        co = _bezier_interp(p0, h0, h1, p1, t)
                        cur = _project_world_2d(context, mw @ co)
                        if cur is None:
                            prev = None
                            continue
                        d = _dist_point_to_seg_2d(float(mx), float(my), prev[0], prev[1], cur[0], cur[1])
                        if d < best_seg[0]:
                            selected = bool(getattr(bps[i], 'select_control_point', False) and getattr(bps[j], 'select_control_point', False))
                            best_seg = (d, ('CURVE_SEGMENT', ('BEZIER_SEGMENT', int(si), int(i), int(j)), selected))
                        prev = cur
                except Exception:
                    continue
            continue
        try:
            pts = list(getattr(spline, 'points', []) or [])
        except Exception:
            pts = []
        count = len(pts)
        if count <= 1:
            continue
        last = count if bool(getattr(spline, 'use_cyclic_u', False)) else count - 1
        for i in range(last):
            j = (i + 1) % count
            try:
                p0 = _project_world_2d(context, mw @ _curve_point_xyz(pts[i]))
                p1 = _project_world_2d(context, mw @ _curve_point_xyz(pts[j]))
                if p0 is None or p1 is None:
                    continue
                d = _dist_point_to_seg_2d(float(mx), float(my), p0[0], p0[1], p1[0], p1[1])
                if d < best_seg[0]:
                    selected = bool(getattr(pts[i], 'select', False) and getattr(pts[j], 'select', False))
                    best_seg = (d, ('CURVE_SEGMENT', ('POINT_SEGMENT', int(si), int(i), int(j)), selected))
            except Exception:
                continue
    if best_seg[1] is not None and best_seg[0] <= e_radius:
        return best_seg[1]
    return None


def _hit_test_editcurve_any(context, fallback_obj, mx, my):
    targets = []
    for typ in ('CURVE', 'SURFACE'):
        targets.extend([t for t in _csdt_edit_targets_by_type(context, fallback_obj, typ) if t not in targets])
    if fallback_obj is not None and fallback_obj in targets:
        targets = [fallback_obj] + [target for target in targets if target is not fallback_obj]
    for target in targets:
        try:
            hit = _hit_test_editcurve(context, target, mx, my)
        except Exception:
            hit = None
        if hit is not None:
            return target, hit
    return fallback_obj, None


def _editcurve_select_single(context, obj, hit):
    try:
        _curve_clear_selection(context)
        kind = str(hit[0])
        if kind == 'CURVE':
            _curve_select_component(obj, hit[1], True)
        elif kind == 'CURVE_SEGMENT':
            _curve_select_segment(obj, hit[1], True)
        try: obj.data.update_tag()
        except Exception: pass
        try: obj.update_from_editmode()
        except Exception: pass
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
        return True
    except Exception:
        return False


def _editcurve_set_active_only(context, obj, hit):
    # Curves do not expose a BMesh-style select history.  To avoid changing the
    # existing multi-selection unexpectedly, keep the selection and ensure the
    # clicked component is selected so the next Smart G-R-S drag has a target.
    try:
        kind = str(hit[0])
        if kind == 'CURVE':
            _curve_select_component(obj, hit[1], True)
        elif kind == 'CURVE_SEGMENT':
            _curve_select_segment(obj, hit[1], True)
        try: obj.data.update_tag()
        except Exception: pass
        try: obj.update_from_editmode()
        except Exception: pass
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
        return True
    except Exception:
        return False


def _editcurve_click_definitely_background(context, obj, mx, my):
    try:
        targets = []
        for typ in ('CURVE', 'SURFACE'):
            targets.extend([t for t in _csdt_edit_targets_by_type(context, obj, typ) if t not in targets])
        if not targets:
            return False
        saw_uncertain_bounds = False
        for target in targets:
            inside_bounds = _object_screen_bounds_contains(context, target, mx, my, pad=24.0)
            if inside_bounds is True:
                return False
            if inside_bounds is None:
                saw_uncertain_bounds = True
        return not saw_uncertain_bounds
    except Exception:
        return False


def _csdt_same_object(a, b):
    """Return True when two RNA object references point to the same original object."""
    if a is None or b is None:
        return False
    if a is b:
        return True
    try:
        if getattr(a, 'original', None) is b:
            return True
    except Exception:
        pass
    try:
        if getattr(b, 'original', None) is a:
            return True
    except Exception:
        pass
    try:
        return int(a.as_pointer()) == int(b.as_pointer())
    except Exception:
        return False


def _csdt_edit_targets(context, fallback_obj=None):
    targets = []
    try:
        seq = (
            getattr(context, 'objects_in_mode_unique_data', None)
            or getattr(context, 'objects_in_mode', None)
            or getattr(context, 'objects_in_edit_mode', None)
            or []
        )
        for obj in seq:
            if obj is not None and obj not in targets:
                targets.append(obj)
    except Exception:
        pass
    if fallback_obj is not None and fallback_obj not in targets:
        targets.append(fallback_obj)
    return targets


def _csdt_edit_targets_by_type(context, fallback_obj=None, obj_type='MESH'):
    out = []
    for target in _csdt_edit_targets(context, fallback_obj):
        try:
            if target is None or getattr(target, 'type', None) != obj_type:
                continue
            if obj_type in {'MESH', 'LATTICE', 'CURVE', 'SURFACE'} and getattr(target, 'mode', None) != 'EDIT':
                continue
            if target not in out:
                out.append(target)
        except Exception:
            continue
    return out


def _hit_test_editmesh_any(context, fallback_obj, mx, my, selection_mode='SET', *, cycle_back=True):
    """Return ``(object, hit)`` for the edit-mesh element under the cursor.

    Immediate Select must not be limited to ``context.active_object``. In
    multi-object Edit Mode the active object can be different from the mesh
    actually under the cursor, so probing only the active object makes the
    N-panel Immediate Select toggle appear ineffective.  The optional
    ``selection_mode`` and ``cycle_back`` arguments are kept for callers that need
    explicit click-cycle semantics; the actual back-side candidate cycling is
    controlled by the N-panel preference and handled inside ``_hit_test_editmesh``.
    """
    del selection_mode, cycle_back
    targets = _csdt_edit_targets_by_type(context, fallback_obj, 'MESH')
    if fallback_obj is not None and fallback_obj in targets:
        targets = [fallback_obj] + [target for target in targets if target is not fallback_obj]
    for target in targets:
        try:
            hit = _hit_test_editmesh(context, target, mx, my)
        except Exception:
            hit = None
        if hit is not None:
            return target, hit
    return fallback_obj, None

def _hit_test_editlattice_any(context, fallback_obj, mx, my):
    targets = _csdt_edit_targets_by_type(context, fallback_obj, 'LATTICE')
    if fallback_obj is not None and fallback_obj in targets:
        targets = [fallback_obj] + [target for target in targets if target is not fallback_obj]
    for target in targets:
        try:
            hit = _hit_test_editlattice(context, target, mx, my)
        except Exception:
            hit = None
        if hit is not None:
            return target, hit
    return fallback_obj, None


def _object_screen_bounds_contains(context, obj, mx, my, pad=16.0):
    """Cheap screen-bounds rejection.

    Returns False when the click is definitely outside the object's projected
    bounding box, True when inside/near it, and None when the test cannot be
    evaluated safely.  This is used only to skip expensive edit-component scans
    for empty background presses.
    """
    try:
        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None or obj is None:
            return None
        bb = getattr(obj, 'bound_box', None)
        if not bb:
            return None
        pts = []
        mw = obj.matrix_world
        for co in bb:
            try:
                p = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ Vector(co))
            except Exception:
                p = None
            if p is not None:
                try:
                    vx, vy = _quadview_projection_xy_to_visible_xy(context, float(p.x), float(p.y), region=region, rv3d=rv3d)
                    pts.append((vx, vy))
                except Exception:
                    pts.append((float(p.x), float(p.y)))
        if not pts:
            return None
        xs = [float(p[0]) for p in pts]
        ys = [float(p[1]) for p in pts]
        return (min(xs) - pad) <= float(mx) <= (max(xs) + pad) and (min(ys) - pad) <= float(my) <= (max(ys) + pad)
    except Exception:
        return None


def _editmesh_click_definitely_background(context, obj, mx, my):
    """Fast, conservative empty-space test for Edit Mesh background drags.

    This returns True only when the press is definitely outside every edited
    mesh target. If the cursor is inside or near any edited mesh screen bounds,
    or if the ray/bounds state is ambiguous, it returns False so the exact
    component hit test can still run. This keeps Background Drag Select fast for
    real empty viewport space without breaking Immediate Select on mesh
    vertices/edges/faces, especially in silhouette and multi-object Edit Mode.
    """
    try:
        targets = _csdt_edit_targets_by_type(context, obj, 'MESH')
        if not targets:
            return False

        has_polygon_target = False
        saw_uncertain_bounds = False
        for target in targets:
            data = getattr(target, 'data', None)
            if data is None:
                saw_uncertain_bounds = True
                continue
            try:
                if len(getattr(data, 'polygons', ())) > 0:
                    has_polygon_target = True
                else:
                    # Loose-only meshes need exact vertex/edge probing.
                    return False
            except Exception:
                return False
            inside_bounds = _object_screen_bounds_contains(context, target, mx, my, pad=24.0)
            if inside_bounds is True:
                return False
            if inside_bounds is None:
                saw_uncertain_bounds = True

        if not saw_uncertain_bounds:
            return True
        if not has_polygon_target:
            return False

        region = getattr(context, 'region', None)
        rv3d = getattr(context, 'region_data', None)
        if region is None or rv3d is None:
            return False
        depsgraph = context.evaluated_depsgraph_get()
        try:
            ray_mx, ray_my = _quadview_visible_xy_to_projection_xy(context, mx, my, region=region, rv3d=rv3d)
        except Exception:
            ray_mx, ray_my = mx, my
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (ray_mx, ray_my))
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (ray_mx, ray_my))
        hit, loc, normal, face_index, hit_obj, matrix = context.scene.ray_cast(depsgraph, origin, direction)
        if not hit or hit_obj is None:
            # Ambiguous inside/near-bounds miss: exact hit test is required so
            # Immediate Select can still catch visible vertices and edges.
            return False
        for target in targets:
            if _csdt_same_object(hit_obj, target):
                return False
        return True
    except Exception:
        return False



def _editlattice_click_definitely_background(context, obj, mx, my):
    """Fast, conservative empty-space test for Edit Lattice background drags."""
    try:
        targets = _csdt_edit_targets_by_type(context, obj, 'LATTICE')
        if not targets:
            return False
        saw_uncertain_bounds = False
        for target in targets:
            inside_bounds = _object_screen_bounds_contains(context, target, mx, my, pad=24.0)
            if inside_bounds is True:
                return False
            if inside_bounds is None:
                saw_uncertain_bounds = True
        return not saw_uncertain_bounds
    except Exception:
        return False


def _hit_test_object(context, mx, my):
    prefs = _prefs()
    enable_click_through = prefs.enable_click_through if prefs else True
    region, rv3d = context.region, context.region_data
    if not region or not rv3d: return None
    try:
        mx, my = _quadview_visible_xy_to_projection_xy(context, mx, my, region=region, rv3d=rv3d)
    except Exception:
        pass
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (mx, my))
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (mx, my))
    depsgraph = context.evaluated_depsgraph_get()
    for _ in range(10):
        hit, loc, normal, face_index, obj, matrix = context.scene.ray_cast(depsgraph, origin, direction)
        if not hit or obj is None: return None
        raw_obj = obj
        obj = _csdt_object_in_view_layer(context, obj)
        if obj is None:
            return None
        try:
            if not _csdt_object_visible_in_current_view(context, obj):
                origin = loc + (direction * 0.0001)
                continue
        except Exception:
            pass
        is_selectable = not bool(getattr(obj, 'hide_select', False))
        try:
            original = getattr(raw_obj, 'original', None)
            if original is not None and bool(getattr(original, 'hide_select', False)):
                is_selectable = False
        except Exception:
            pass
        if not enable_click_through and not is_selectable: return None
        if is_selectable: return (obj, obj.select_get())
        origin = loc + (direction * 0.0001)
    return None

def _object_select_single(context, obj):
    obj = _csdt_object_in_view_layer(context, obj)
    if obj is None:
        return False
    try:
        if str(getattr(context, 'mode', '') or '') == 'OBJECT' and not _csdt_object_visible_in_current_view(context, obj):
            return False
    except Exception:
        pass
    for o in context.view_layer.objects:
        try:
            o.select_set(False)
        except Exception:
            pass
    obj.select_set(True)
    _csdt_set_active_object_and_notify(context, obj, require_selected=True, redraw=True)
    _invalidate_gizmo_cache()
    try: _tag_view3d_redraw()
    except Exception: pass
    return True


def _csdt_normalize_selection_mode(mode='SET'):
    mode = str(mode or 'SET').strip().upper()
    if mode in {'ADD', 'EXTEND'}:
        return 'ADD'
    if mode in {'SUB', 'DESELECT', 'REMOVE'}:
        return 'SUB'
    if mode in {'XOR', 'TOGGLE'}:
        return 'XOR'
    if mode in {'AND', 'INTERSECT'}:
        return 'AND'
    return 'SET'


def _csdt_select_action_from_mode(mode='SET'):
    mode = _csdt_normalize_selection_mode(mode)
    if mode == 'SUB':
        return 'DESELECT'
    if mode == 'XOR':
        return 'TOGGLE'
    return 'SELECT'


def _csdt_apply_object_click_selection_mode(context, obj, mode='SET'):
    if obj is None:
        return False
    obj = _csdt_object_in_view_layer(context, obj)
    if obj is None:
        return False
    try:
        if str(getattr(context, 'mode', '') or '') == 'OBJECT' and not _csdt_object_visible_in_current_view(context, obj):
            return False
    except Exception:
        pass
    mode = _csdt_normalize_selection_mode(mode)
    try:
        before = bool(obj.select_get())
    except Exception:
        before = False
    try:
        if mode == 'SET':
            _object_select_single(context, obj)
            return True
        if mode == 'SUB':
            obj.select_set(False)
        elif mode == 'XOR':
            obj.select_set(not before)
        elif mode == 'AND':
            obj.select_set(bool(before))
        else:
            obj.select_set(True)
        try:
            if obj.select_get():
                _csdt_set_active_object_and_notify(context, obj, require_selected=True, redraw=True)
            else:
                _csdt_sync_active_after_object_selection(context, mode=mode)
        except Exception:
            pass
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
        return True
    except Exception:
        return False


def _csdt_bmesh_elem_from_hit(bm, hit):
    try:
        kind, idx = str(hit[0] or '').upper(), int(hit[1])
    except Exception:
        return None, ''
    try:
        if kind == 'VERT':
            bm.verts.ensure_lookup_table()
            return bm.verts[idx], kind
        if kind == 'EDGE':
            bm.edges.ensure_lookup_table()
            return bm.edges[idx], kind
        if kind == 'FACE':
            bm.faces.ensure_lookup_table()
            return bm.faces[idx], kind
    except Exception:
        return None, kind
    return None, kind


def _csdt_history_add_safe(bm, elem):
    try:
        bm.select_history.add(elem)
    except Exception:
        pass


def _csdt_history_remove_safe(bm, elem):
    try:
        bm.select_history.remove(elem)
    except Exception:
        pass


def _csdt_prune_edge_child_verts_after_deselect(edge):
    """Keep edge-mode SUB deterministic after Blender/BMesh selection flushing.

    In edge select mode, Blender stores supporting vertex select flags for selected
    edges.  If a deselected edge's two vertices remain selected, later flushes or
    native click routes can recreate the edge selection.  Remove only vertices that
    are no longer needed by another selected edge or selected face.
    """
    try:
        for vert in edge.verts:
            keep = False
            try:
                keep = any(bool(getattr(e, 'select', False)) for e in vert.link_edges if e is not edge)
            except Exception:
                keep = False
            if not keep:
                try:
                    keep = any(bool(getattr(f, 'select', False)) for f in vert.link_faces)
                except Exception:
                    keep = False
            if not keep:
                try:
                    vert.select_set(False)
                except Exception:
                    try:
                        vert.select = False
                    except Exception:
                        pass
    except Exception:
        pass


def _csdt_enforce_editmesh_click_element_state(bm, elem, kind, action):
    """Re-apply the requested element state after BMesh flush side effects."""
    try:
        if action == 'DESELECT':
            try:
                elem.select_set(False)
            except Exception:
                elem.select = False
            _csdt_history_remove_safe(bm, elem)
            if kind == 'EDGE':
                _csdt_prune_edge_child_verts_after_deselect(elem)
            elif kind == 'FACE':
                try:
                    for e in elem.edges:
                        if not any(bool(getattr(f, 'select', False)) for f in e.link_faces if f is not elem):
                            try: e.select_set(False)
                            except Exception: e.select = False
                except Exception:
                    pass
            return
        if action == 'TOGGLE':
            return
        try:
            elem.select_set(True)
        except Exception:
            elem.select = True
        _csdt_history_add_safe(bm, elem)
        if kind == 'EDGE':
            try:
                for v in elem.verts:
                    try: v.select_set(True)
                    except Exception: v.select = True
            except Exception:
                pass
        elif kind == 'FACE':
            try:
                for e in elem.edges:
                    try: e.select_set(True)
                    except Exception: e.select = True
                for v in elem.verts:
                    try: v.select_set(True)
                    except Exception: v.select = True
            except Exception:
                pass
    except Exception:
        pass


def _csdt_prune_deselected_edge_vertices(edge):
    """After Ctrl/SUB edge-click, clear endpoint verts only when no selected edge/face still needs them."""
    try:
        verts = tuple(edge.verts)
    except Exception:
        return
    for v in verts:
        keep = False
        try:
            for linked_edge in getattr(v, 'link_edges', []) or []:
                if linked_edge is edge:
                    continue
                if bool(getattr(linked_edge, 'select', False)):
                    keep = True
                    break
        except Exception:
            pass
        if not keep:
            try:
                for linked_face in getattr(v, 'link_faces', []) or []:
                    if bool(getattr(linked_face, 'select', False)):
                        keep = True
                        break
            except Exception:
                pass
        if not keep:
            try:
                v.select_set(False)
            except Exception:
                try:
                    v.select = False
                except Exception:
                    pass


def _csdt_apply_editmesh_click_selection_mode(context, obj, hit, mode='SET'):
    if obj is None or getattr(obj, 'type', None) != 'MESH' or hit is None:
        return False
    mode = _csdt_normalize_selection_mode(mode)
    if mode == 'SET':
        _editmesh_select_single(context, obj, hit)
        return True
    if mode == 'AND':
        # Single-click intersection should not expand or invert the current set.
        return True
    _csdt_clear_editmesh_exclusive_select_cache(obj)
    action = _csdt_select_action_from_mode(mode)
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    except Exception:
        return False
    elem, kind = _csdt_bmesh_elem_from_hit(bm, hit)
    if elem is None:
        return False
    try:
        before = bool(getattr(elem, 'select', False))
    except Exception:
        before = False
    changed = False
    try:
        if action == 'DESELECT':
            try:
                elem.select_set(False)
            except Exception:
                elem.select = False
            _csdt_history_remove_safe(bm, elem)
            if kind == 'EDGE':
                _csdt_prune_deselected_edge_vertices(elem)
        elif action == 'TOGGLE':
            try:
                elem.select_set(not before)
            except Exception:
                elem.select = not before
            if not before:
                _csdt_history_add_safe(bm, elem)
            else:
                _csdt_history_remove_safe(bm, elem)
                if kind == 'EDGE':
                    _csdt_prune_deselected_edge_vertices(elem)
        else:
            try:
                elem.select_set(True)
            except Exception:
                elem.select = True
            _csdt_history_add_safe(bm, elem)
        changed = True
    except Exception:
        changed = False
    try:
        selected_after = bool(getattr(elem, 'select', False))
    except Exception:
        selected_after = False
    try:
        if kind == 'EDGE' and selected_after:
            for v in elem.verts:
                try: v.select_set(True)
                except Exception: v.select = True
        elif kind == 'FACE' and selected_after:
            for e in elem.edges:
                try: e.select_set(True)
                except Exception: e.select = True
            for v in elem.verts:
                try: v.select_set(True)
                except Exception: v.select = True
    except Exception:
        pass
    try:
        bm.select_flush_mode()
    except Exception:
        pass
    try:
        _csdt_enforce_editmesh_click_element_state(bm, elem, kind, action)
    except Exception:
        pass
    try:
        bm.select_flush_mode()
    except Exception:
        pass
    try:
        _csdt_enforce_editmesh_click_element_state(bm, elem, kind, action)
    except Exception:
        pass
    try:
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass
    if changed:
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
    return bool(changed)


def _csdt_apply_editlattice_click_selection_mode(context, obj, hit, mode='SET'):
    if obj is None or getattr(obj, 'type', None) != 'LATTICE' or hit is None:
        return False
    try:
        if str(hit[0] or '').upper() != 'POINT':
            return False
        index = int(hit[1])
        points = obj.data.points
        point = points[index]
    except Exception:
        return False
    mode = _csdt_normalize_selection_mode(mode)
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        if mode == 'SET':
            for target in _csdt_edit_targets_by_type(context, obj, 'LATTICE'):
                for item in target.data.points:
                    item.select = False
            point.select = True
        elif mode == 'SUB':
            point.select = False
        elif mode == 'XOR':
            point.select = not bool(getattr(point, 'select', False))
        elif mode != 'AND':
            point.select = True
        try:
            obj.data.update_tag()
            obj.update_from_editmode()
        except Exception:
            pass
        _invalidate_gizmo_cache()
        try:
            _tag_view3d_redraw()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _csdt_apply_editcurve_click_selection_mode(context, obj, hit, mode='SET'):
    if obj is None or getattr(obj, 'type', None) not in {'CURVE', 'SURFACE'} or hit is None:
        return False
    try:
        kind = str(hit[0] or '').upper()
        key = hit[1]
        before = bool(hit[2])
    except Exception:
        return False
    if kind not in {'CURVE', 'CURVE_SEGMENT'}:
        return False
    mode = _csdt_normalize_selection_mode(mode)
    try:
        context.view_layer.objects.active = obj
    except Exception:
        pass
    try:
        if mode == 'SET':
            _curve_clear_selection(context)
            select = True
        elif mode == 'SUB':
            select = False
        elif mode == 'XOR':
            select = not before
        elif mode == 'AND':
            return True
        else:
            select = True
        if kind == 'CURVE':
            applied = _curve_select_component(obj, key, select)
        else:
            applied = _curve_select_segment(obj, key, select)
        if not applied:
            return False
        try:
            obj.data.update_tag()
            obj.update_from_editmode()
        except Exception:
            pass
        _invalidate_gizmo_cache()
        try:
            _tag_view3d_redraw()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _csdt_apply_click_selection_mode(context, hit, target_obj=None, mode='SET'):
    mode = _csdt_normalize_selection_mode(mode)
    try:
        ctx_mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        ctx_mode = ''
    if ctx_mode == 'OBJECT':
        try:
            obj = hit[0]
        except Exception:
            obj = target_obj
        return _csdt_apply_object_click_selection_mode(context, obj, mode=mode)
    if ctx_mode == 'EDIT_MESH' and target_obj is not None and getattr(target_obj, 'type', None) == 'MESH':
        try:
            context.view_layer.objects.active = target_obj
        except Exception:
            pass
        return _csdt_apply_editmesh_click_selection_mode(context, target_obj, hit, mode=mode)
    if ctx_mode == 'EDIT_LATTICE' and target_obj is not None and getattr(target_obj, 'type', None) == 'LATTICE':
        return _csdt_apply_editlattice_click_selection_mode(context, target_obj, hit, mode=mode)
    if ctx_mode in {'EDIT_CURVE', 'EDIT_SURFACE'} and target_obj is not None and getattr(target_obj, 'type', None) in {'CURVE', 'SURFACE'}:
        return _csdt_apply_editcurve_click_selection_mode(context, target_obj, hit, mode=mode)
    return False

# =========================
# Selection Dispatch & Tools
# =========================
_SELECT_TOOL_IDS = {"builtin.select", "builtin.select_box", "builtin.select_circle", "builtin.select_lasso"}
_CUSTOM_SELECT_MODE_TO_TOOL = {
    "TWEAK": "builtin.select",
    "BOX": "builtin.select_box",
    "CIRCLE": "builtin.select_circle",
    "LASSO": "builtin.select_lasso",
}


def _custom_select_tool_id_from_prefs(prefs):
    try:
        mode = str(getattr(prefs, 'custom_select_mode', 'BOX') or 'BOX').strip().upper()
    except Exception:
        mode = 'BOX'
    if mode in _CUSTOM_SELECT_MODE_TO_TOOL:
        return _CUSTOM_SELECT_MODE_TO_TOOL[mode]
    try:
        tool = str(getattr(prefs, 'last_select_tool', '') or '').strip()
        if tool in _SELECT_TOOL_IDS:
            return tool
    except Exception:
        pass
    return "builtin.select_box"


def _custom_select_mode_from_prefs(prefs):
    try:
        mode = str(getattr(prefs, 'custom_select_mode', 'BOX') or 'BOX').strip().upper()
        if mode in _CUSTOM_SELECT_MODE_TO_TOOL:
            return mode
    except Exception:
        pass
    try:
        tool = str(getattr(prefs, 'last_select_tool', '') or '').strip()
        for m, tid in _CUSTOM_SELECT_MODE_TO_TOOL.items():
            if tid == tool:
                return m
    except Exception:
        pass
    return 'BOX'


def _get_active_select_tool_id(context):
    # Avoid ToolSelectPanelHelper's group lookup here.  In migrated workspaces
    # containing an empty tool id, that path can ask Blender for tool "" and show
    # "Tool '' not found in space 'VIEW_3D'".  When a transform tool is active,
    # use the add-on's custom selection mode instead of switching the toolbar tool.
    try:
        tool_id = str(_active_tool_id(context) or '').strip()
    except Exception:
        tool_id = ''
    if tool_id in _SELECT_TOOL_IDS:
        return tool_id
    try:
        if tool_id in cg._TRANSFORM_TOOL_IDS:
            return _custom_select_tool_id_from_prefs(_prefs(context))
    except Exception:
        pass
    return "builtin.select_box"

def _selection_mode_from_event(event):
    # Smart Gizmo background box selection supplements Blender's native result
    # for plain / Shift / Ctrl gestures only.  Alt and Alt+modifier gestures are
    # intentionally not remapped to ADD/SUB/XOR so Blender's standard Alt
    # box/lasso/circle behavior remains available.
    if getattr(event, "alt", False):
        return "SET"
    if getattr(event, "shift", False) and getattr(event, "ctrl", False):
        return "XOR"
    if getattr(event, "ctrl", False):
        return "SUB"
    if getattr(event, "shift", False):
        return "ADD"
    return "SET"

def _add_disallow_object_select_kw(op_func, kwargs):
    try: props = op_func.get_rna_type().properties
    except Exception: return None
    for name in ("object", "use_object", "use_object_select", "use_object_selection", "use_object_mode", "select_objects", "include_objects", "object_select"):
        if name in props: kwargs[name] = False; return kwargs
    return None

def _invoke_select_op(op_func, mode="SET", prefer_wait_for_input=False, disallow_object_select=False):
    def _call_invoke(kwargs):
        try:
            result = op_func("INVOKE_DEFAULT", **kwargs)
            if isinstance(result, set) and 'CANCELLED' in result:
                return False
            _invalidate_gizmo_cache()
            return True
        except Exception: return False
    def _try(kwargs):
        if disallow_object_select:
            kw2 = _add_disallow_object_select_kw(op_func, dict(kwargs))
            if kw2 is not None and _call_invoke(kw2): return True
        return _call_invoke(kwargs)
    if prefer_wait_for_input:
        if _try({"wait_for_input": True, "mode": mode}): return True
        if _try({"wait_for_input": False, "mode": mode}): return True
        if _try({"mode": mode}): return True
    else:
        if _try({"wait_for_input": False, "mode": mode}): return True
        if _try({"mode": mode}): return True
      
    extend = mode in {"ADD", "SUB", "XOR", "AND"}
    deselect = (mode == "SUB")
    toggle = (mode == "XOR")
    if prefer_wait_for_input:
        if _try({"wait_for_input": True, "extend": extend, "deselect": deselect, "toggle": toggle}): return True
    else:
        if _try({"wait_for_input": False, "extend": extend, "deselect": deselect, "toggle": toggle}): return True
        
    if _try({"extend": extend, "deselect": deselect, "toggle": toggle}): return True
    if _try({"extend": extend, "deselect": deselect}): return True
    if _try({"extend": extend}): return True
    if _try({"deselect": deselect}): return True
    return bool(_try({}))





def _csdt_screen_rect_from_points(p0, p1):
    try:
        x0, y0 = float(p0[0]), float(p0[1])
        x1, y1 = float(p1[0]), float(p1[1])
    except Exception:
        return None
    return (min(x0, x1), max(x0, x1), min(y0, y1), max(y0, y1))


def _csdt_point_in_rect_2d(co, rect, pad=0.0):
    if co is None or rect is None:
        return False
    try:
        if hasattr(co, 'x') and hasattr(co, 'y'):
            x, y = float(co.x), float(co.y)
        else:
            x, y = float(co[0]), float(co[1])
        xmin, xmax, ymin, ymax = rect
        pad = float(pad)
        return (xmin - pad) <= x <= (xmax + pad) and (ymin - pad) <= y <= (ymax + pad)
    except Exception:
        return False


def _csdt_segment_intersects_rect_2d(a, b, rect, pad=0.0):
    """Return True when the projected edge segment crosses or lies inside rect.

    Blender's native edit-mode box-select can miss edge-mode elements in the
    Smart Gizmo background-drag route on some view/normal combinations.  Testing
    only edge endpoints or the midpoint is also insufficient for long edges that
    pass through the rectangle.  This uses a small Liang-Barsky clip test so any
    screen-space edge segment intersecting the box is treated as boxed.
    """
    if a is None or b is None or rect is None:
        return False
    try:
        x0, y0 = (float(a.x), float(a.y)) if hasattr(a, 'x') else (float(a[0]), float(a[1]))
        x1, y1 = (float(b.x), float(b.y)) if hasattr(b, 'x') else (float(b[0]), float(b[1]))
        xmin, xmax, ymin, ymax = [float(v) for v in rect]
        pad = float(pad)
        xmin -= pad; xmax += pad; ymin -= pad; ymax += pad
    except Exception:
        return False
    if (xmin <= x0 <= xmax and ymin <= y0 <= ymax) or (xmin <= x1 <= xmax and ymin <= y1 <= ymax):
        return True
    dx = x1 - x0
    dy = y1 - y0
    u0, u1 = 0.0, 1.0
    for p, q in ((-dx, x0 - xmin), (dx, xmax - x0), (-dy, y0 - ymin), (dy, ymax - y0)):
        try:
            if abs(p) < 1.0e-12:
                if q < 0.0:
                    return False
                continue
            r = q / p
            if p < 0.0:
                if r > u1:
                    return False
                if r > u0:
                    u0 = r
            else:
                if r < u0:
                    return False
                if r < u1:
                    u1 = r
        except Exception:
            return False
    return u0 <= u1


def _csdt_projected_edge_hits_rect(region, rv3d, mw, edge, rect, pad=2.0, steps=8):
    """Return True when the visible projected edge segment touches the box.

    The endpoint test covers the common case. If projection is clipped or one
    endpoint is outside the View3D frustum, a short sampled polyline catches the
    still-visible part of the edge so Smart Gizmo background box selection does
    not randomly miss edge-mode elements.
    """
    try:
        v0 = edge.verts[0].co
        v1 = edge.verts[1].co
    except Exception:
        return False

    try:
        p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ v0)
        p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ v1)
    except Exception:
        p0 = p1 = None
    if _csdt_point_in_rect_2d(p0, rect, pad=pad) or _csdt_point_in_rect_2d(p1, rect, pad=pad):
        return True
    if p0 is not None and p1 is not None:
        try:
            if _csdt_segment_intersects_rect_2d(p0, p1, rect, pad=pad):
                return True
        except Exception:
            pass

    points = _csdt_edge_projected_points(region, rv3d, mw, edge, steps=steps)
    prev = None
    for p in points:
        if p is None:
            prev = None
            continue
        if _csdt_point_in_rect_2d(p, rect, pad=pad):
            return True
        if prev is not None:
            try:
                if _csdt_segment_intersects_rect_2d(prev, p, rect, pad=pad):
                    return True
            except Exception:
                pass
        prev = p
    return False


def _csdt_projected_edge_hits_rect_matrix(region, full_mat, edge, rect, pad=2.0):
    """Fast edge/box test using the View3D perspective matrix directly."""
    if region is None or full_mat is None or edge is None or rect is None:
        return None
    try:
        rw_half = float(region.width) * 0.5
        rh_half = float(region.height) * 0.5
        if rw_half <= 0.0 or rh_half <= 0.0:
            return None
        m00, m01, m02, m03 = full_mat[0]
        m10, m11, m12, m13 = full_mat[1]
        m30, m31, m32, m33 = full_mat[3]
        def _project(co):
            x, y, z = co
            w = m30 * x + m31 * y + m32 * z + m33
            if w <= 1.0e-12:
                return None
            px = (m00 * x + m01 * y + m02 * z + m03) / w
            py = (m10 * x + m11 * y + m12 * z + m13) / w
            return ((px + 1.0) * rw_half, (py + 1.0) * rh_half)
        p0 = _project(edge.verts[0].co)
        p1 = _project(edge.verts[1].co)
    except Exception:
        return None
    if p0 is not None and _csdt_point_in_rect_2d(p0, rect, pad=pad):
        return True
    if p1 is not None and _csdt_point_in_rect_2d(p1, rect, pad=pad):
        return True
    if p0 is not None and p1 is not None:
        return bool(_csdt_segment_intersects_rect_2d(p0, p1, rect, pad=pad))
    # None means the fast matrix path could not decide because the edge is clipped.
    return None


def _csdt_total_editmesh_edges(context):
    try:
        objs = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
    except Exception:
        objs = None
    if not objs:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        objs = [obj] if obj is not None else []
    total = 0
    for obj in objs:
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        try:
            total += len(getattr(obj.data, 'edges', []) or [])
        except Exception:
            pass
    return int(total)


def _csdt_select_action_from_box_mode(mode='SET'):
    return _csdt_select_action_from_mode(mode)


def _csdt_apply_bmesh_select_state(elem, action):
    try:
        before = bool(getattr(elem, 'select', False))
    except Exception:
        before = False
    try:
        if action == 'DESELECT':
            elem.select_set(False)
        elif action == 'TOGGLE':
            elem.select_set(not before)
        else:
            elem.select_set(True)
    except Exception:
        try:
            if action == 'DESELECT':
                elem.select = False
            elif action == 'TOGGLE':
                elem.select = not before
            else:
                elem.select = True
        except Exception:
            return False
    try:
        return bool(getattr(elem, 'select', False)) != before
    except Exception:
        return False


def _csdt_crossing_point_2d(co):
    try:
        if co is None:
            return None
        if hasattr(co, 'x'):
            return (float(co.x), float(co.y))
        return (float(co[0]), float(co[1]))
    except Exception:
        return None


def _csdt_crossing_clean_polygon(points, min_count=3):
    out = []
    try:
        for point in list(points or ()):
            pt = _csdt_crossing_point_2d(point)
            if pt is None:
                continue
            if not out or (abs(out[-1][0] - pt[0]) > 0.001 or abs(out[-1][1] - pt[1]) > 0.001):
                out.append(pt)
        if len(out) > 2 and abs(out[0][0] - out[-1][0]) <= 0.001 and abs(out[0][1] - out[-1][1]) <= 0.001:
            out.pop()
    except Exception:
        return []
    return out if len(out) >= int(min_count) else []


def _csdt_crossing_shape_from_box(x0, y0, x1, y1):
    try:
        rect = _csdt_screen_rect_from_points((x0, y0), (x1, y1))
        if rect is None:
            return None
        xmin, xmax, ymin, ymax = rect
        if abs(float(xmax) - float(xmin)) < 1.0 and abs(float(ymax) - float(ymin)) < 1.0:
            return None
        return {
            'kind': 'POLYGON',
            'tool': 'BOX',
            'poly': [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)],
            'rect': (xmin, xmax, ymin, ymax),
        }
    except Exception:
        return None


def _csdt_crossing_shape_from_lasso(points):
    poly = _csdt_crossing_clean_polygon(points, min_count=3)
    if not poly:
        return None
    return {'kind': 'POLYGON', 'tool': 'LASSO', 'poly': poly, 'rect': None}


def _csdt_crossing_shape_from_circle(cx, cy, radius):
    try:
        radius = max(1.0, float(radius))
        return {'kind': 'CIRCLE', 'tool': 'CIRCLE', 'center': (float(cx), float(cy)), 'radius': radius}
    except Exception:
        return None


def _csdt_crossing_selection_shape(tool_kind, points=None, start=None, end=None, radius=None):
    tool = str(tool_kind or 'BOX').strip().upper()
    if tool in {'BOX', 'SELECT_BOX', 'BUILTIN.SELECT_BOX', 'BUILTIN_SELECT_BOX'}:
        try:
            sx, sy = start if start is not None else (None, None)
            ex, ey = end if end is not None else (None, None)
        except Exception:
            return None
        return _csdt_crossing_shape_from_box(sx, sy, ex, ey)
    if tool in {'LASSO', 'SELECT_LASSO', 'BUILTIN.SELECT_LASSO', 'BUILTIN_SELECT_LASSO'}:
        return _csdt_crossing_shape_from_lasso(points)
    if tool in {'CIRCLE', 'SELECT_CIRCLE', 'BUILTIN.SELECT_CIRCLE', 'BUILTIN_SELECT_CIRCLE'}:
        try:
            center = end if end is not None else start
            cx, cy = center
        except Exception:
            return None
        return _csdt_crossing_shape_from_circle(cx, cy, radius if radius is not None else 25.0)
    return None


def _csdt_crossing_orient(a, b, c):
    try:
        return (float(b[0]) - float(a[0])) * (float(c[1]) - float(a[1])) - (float(b[1]) - float(a[1])) * (float(c[0]) - float(a[0]))
    except Exception:
        return 0.0


def _csdt_crossing_point_on_segment(pt, a, b, eps=1.0e-7):
    try:
        x, y = float(pt[0]), float(pt[1])
        ax, ay = float(a[0]), float(a[1])
        bx, by = float(b[0]), float(b[1])
        if abs(_csdt_crossing_orient((ax, ay), (bx, by), (x, y))) > float(eps):
            return False
        return (min(ax, bx) - eps) <= x <= (max(ax, bx) + eps) and (min(ay, by) - eps) <= y <= (max(ay, by) + eps)
    except Exception:
        return False


def _csdt_crossing_segments_intersect(a, b, c, d, eps=1.0e-7):
    try:
        a = _csdt_crossing_point_2d(a); b = _csdt_crossing_point_2d(b); c = _csdt_crossing_point_2d(c); d = _csdt_crossing_point_2d(d)
        if a is None or b is None or c is None or d is None:
            return False
        o1 = _csdt_crossing_orient(a, b, c)
        o2 = _csdt_crossing_orient(a, b, d)
        o3 = _csdt_crossing_orient(c, d, a)
        o4 = _csdt_crossing_orient(c, d, b)
        if (o1 > eps and o2 < -eps or o1 < -eps and o2 > eps) and (o3 > eps and o4 < -eps or o3 < -eps and o4 > eps):
            return True
        if abs(o1) <= eps and _csdt_crossing_point_on_segment(c, a, b, eps):
            return True
        if abs(o2) <= eps and _csdt_crossing_point_on_segment(d, a, b, eps):
            return True
        if abs(o3) <= eps and _csdt_crossing_point_on_segment(a, c, d, eps):
            return True
        if abs(o4) <= eps and _csdt_crossing_point_on_segment(b, c, d, eps):
            return True
    except Exception:
        pass
    return False


def _csdt_crossing_point_in_polygon(pt, poly):
    pt = _csdt_crossing_point_2d(pt)
    if pt is None or not poly:
        return False
    try:
        for a, b in zip(poly, poly[1:] + poly[:1]):
            if _csdt_crossing_point_on_segment(pt, a, b, eps=1.0e-6):
                return True
    except Exception:
        pass
    try:
        return bool(_pt_in_poly_2d(pt, poly))
    except Exception:
        return False


def _csdt_crossing_segment_hits_polygon(a, b, poly, pad=0.0):
    if not poly:
        return False
    a = _csdt_crossing_point_2d(a)
    b = _csdt_crossing_point_2d(b)
    if a is None or b is None:
        return False
    if _csdt_crossing_point_in_polygon(a, poly) or _csdt_crossing_point_in_polygon(b, poly):
        return True
    for c, d in zip(poly, poly[1:] + poly[:1]):
        if _csdt_crossing_segments_intersect(a, b, c, d):
            return True
        try:
            if float(pad) > 0.0:
                if _dist_point_to_seg_2d(c[0], c[1], a[0], a[1], b[0], b[1]) <= float(pad):
                    return True
                if _dist_point_to_seg_2d(d[0], d[1], a[0], a[1], b[0], b[1]) <= float(pad):
                    return True
        except Exception:
            pass
    return False


def _csdt_crossing_polygon_hits_polygon(poly, selector_poly):
    poly = _csdt_crossing_clean_polygon(poly, min_count=3)
    selector_poly = _csdt_crossing_clean_polygon(selector_poly, min_count=3)
    if not poly or not selector_poly:
        return False
    try:
        for p in poly:
            if _csdt_crossing_point_in_polygon(p, selector_poly):
                return True
        for p in selector_poly:
            if _csdt_crossing_point_in_polygon(p, poly):
                return True
        for a, b in zip(poly, poly[1:] + poly[:1]):
            for c, d in zip(selector_poly, selector_poly[1:] + selector_poly[:1]):
                if _csdt_crossing_segments_intersect(a, b, c, d):
                    return True
    except Exception:
        pass
    return False


def _csdt_crossing_segment_hits_circle(a, b, center, radius, pad=0.0):
    a = _csdt_crossing_point_2d(a)
    b = _csdt_crossing_point_2d(b)
    center = _csdt_crossing_point_2d(center)
    if a is None or b is None or center is None:
        return False
    try:
        r = max(0.0, float(radius) + float(pad))
        if math.hypot(a[0] - center[0], a[1] - center[1]) <= r:
            return True
        if math.hypot(b[0] - center[0], b[1] - center[1]) <= r:
            return True
        return _dist_point_to_seg_2d(center[0], center[1], a[0], a[1], b[0], b[1]) <= r
    except Exception:
        return False


def _csdt_crossing_polygon_hits_circle(poly, center, radius, pad=0.0):
    poly = _csdt_crossing_clean_polygon(poly, min_count=3)
    center = _csdt_crossing_point_2d(center)
    if not poly or center is None:
        return False
    try:
        r = max(0.0, float(radius) + float(pad))
        for p in poly:
            if math.hypot(float(p[0]) - center[0], float(p[1]) - center[1]) <= r:
                return True
        if _csdt_crossing_point_in_polygon(center, poly):
            return True
        for a, b in zip(poly, poly[1:] + poly[:1]):
            if _csdt_crossing_segment_hits_circle(a, b, center, r, pad=0.0):
                return True
    except Exception:
        pass
    return False


def _csdt_crossing_points_hit_shape(points, shape, *, is_face=False, pad=0.0):
    pts = [_csdt_crossing_point_2d(p) for p in list(points or ())]
    pts = [p for p in pts if p is not None]
    if not pts or not isinstance(shape, dict):
        return False
    kind = str(shape.get('kind', '') or '').upper()
    try:
        if kind == 'CIRCLE':
            center = shape.get('center')
            radius = float(shape.get('radius', 0.0) or 0.0)
            if is_face and len(pts) >= 3:
                return _csdt_crossing_polygon_hits_circle(pts, center, radius, pad=pad)
            if len(pts) == 1:
                c = _csdt_crossing_point_2d(center)
                return c is not None and math.hypot(pts[0][0] - c[0], pts[0][1] - c[1]) <= radius + float(pad)
            for a, b in zip(pts, pts[1:]):
                if _csdt_crossing_segment_hits_circle(a, b, center, radius, pad=pad):
                    return True
            return False
        poly = _csdt_crossing_clean_polygon(shape.get('poly'), min_count=3)
        if is_face and len(pts) >= 3:
            return _csdt_crossing_polygon_hits_polygon(pts, poly)
        if len(pts) == 1:
            return _csdt_crossing_point_in_polygon(pts[0], poly)
        for a, b in zip(pts, pts[1:]):
            if _csdt_crossing_segment_hits_polygon(a, b, poly, pad=pad):
                return True
    except Exception:
        return False
    return False


def _csdt_crossing_view3d_select_through_allowed(area=None):
    # Same test as the header X-Ray button (XRAY_FLAG): Wireframe shading uses
    # show_xray_wireframe, every other shading type uses show_xray.
    try:
        space = getattr(getattr(area, 'spaces', None), 'active', None)
        shading = getattr(space, 'shading', None)
        if shading is None:
            return False
        if getattr(shading, 'type', '') == 'WIREFRAME':
            return bool(getattr(shading, 'show_xray_wireframe', False))
        return bool(getattr(shading, 'show_xray', False))
    except Exception:
        return False


def _csdt_crossing_region_point_visible_on_obj(context, region, rv3d, obj, pt, *, face=None, edge=None):
    try:
        if context is None or region is None or rv3d is None or obj is None or pt is None:
            return False
        scene = getattr(context, 'scene', None)
        if scene is None:
            return False
        depsgraph = None
        try:
            depsgraph = context.evaluated_depsgraph_get()
        except Exception:
            depsgraph = None
        origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, pt)
        direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, pt)
        if origin is None or direction is None:
            return False
        result = scene.ray_cast(depsgraph, origin, direction) if depsgraph is not None else scene.ray_cast(origin, direction)
        if not result or not bool(result[0]):
            return bool(edge is not None)
        hit_obj = result[4] if len(result) > 4 else None
        poly_index = result[3] if len(result) > 3 else -1
        try:
            if hit_obj is not obj and (not hasattr(hit_obj, 'as_pointer') or hit_obj.as_pointer() != obj.as_pointer()):
                return False
        except Exception:
            return False
        if face is not None:
            return True
        if edge is not None:
            return True
        return True
    except Exception:
        return False


def _csdt_crossing_shape_probe_points(shape):
    out = []
    try:
        if not isinstance(shape, dict):
            return out
        kind = str(shape.get('kind', '') or '').upper()
        if kind == 'CIRCLE':
            pt = _csdt_crossing_point_2d(shape.get('center'))
            if pt is not None:
                out.append(pt)
            return out
        poly = _csdt_crossing_clean_polygon(shape.get('poly'), min_count=3)
        if poly:
            try:
                out.append((sum(p[0] for p in poly) / len(poly), sum(p[1] for p in poly) / len(poly)))
            except Exception:
                pass
            out.extend(poly[:4])
    except Exception:
        pass
    return out


# Depth-aware visibility for crossing selection while X-Ray is off.
# A sample point on the element is visible when nothing lies between it and
# the viewer: the element's own mesh is tested with a BVH built from the edit
# BMesh (adjacent and hidden faces are skipped), other objects with
# Scene.ray_cast. The element counts as visible when any sample point inside
# the selector shape is visible, which mirrors the native depth-buffer select.
_CSDT_CROSSING_OCC_EDGE_T = (0.5, 0.375, 0.625, 0.25, 0.75, 0.125, 0.875, 0.02, 0.98)
_CSDT_CROSSING_OCC_FACE_TOWARD = 0.6
_CSDT_CROSSING_OCC_MAX_POINTS = 5
_CSDT_CROSSING_OCC_FALLBACK_POINTS = 3
_CSDT_CROSSING_OCC_SELF_STEPS = 8
_CSDT_CROSSING_OCC_SCENE_STEPS = 6


def _csdt_crossing_shape_inside_test(shape):
    try:
        if not isinstance(shape, dict):
            return None
        kind = str(shape.get('kind', '') or '').upper()
        if kind == 'CIRCLE':
            center = _csdt_crossing_point_2d(shape.get('center'))
            if center is None:
                return None
            cx, cy = center
            r = max(0.0, float(shape.get('radius', 0.0) or 0.0))
            r2 = r * r
            return lambda x, y: ((x - cx) * (x - cx) + (y - cy) * (y - cy)) <= r2
        rect = shape.get('rect')
        if rect is not None:
            try:
                xmin, xmax, ymin, ymax = (float(v) for v in rect)
                return lambda x, y: (xmin <= x <= xmax) and (ymin <= y <= ymax)
            except Exception:
                pass
        poly = _csdt_crossing_clean_polygon(shape.get('poly'), min_count=3)
        if poly:
            return lambda x, y: _csdt_crossing_point_in_polygon((x, y), poly)
    except Exception:
        pass
    return None


def _csdt_crossing_occlusion_begin(context, region, rv3d, shape):
    try:
        if context is None or region is None or rv3d is None:
            return None
        scene = getattr(context, 'scene', None)
        if scene is None:
            return None
        depsgraph = context.evaluated_depsgraph_get()
        if depsgraph is None:
            return None
        viewinv = rv3d.view_matrix.inverted_safe()
        back = Vector(tuple(viewinv.col[2][:3]))
        if back.length <= 1.0e-12:
            return None
        back.normalize()
        persp = bool(getattr(rv3d, 'is_perspective', True))
        eye = viewinv.translation.copy()
        ref = eye
        if not persp and str(getattr(rv3d, 'view_perspective', '') or '') != 'CAMERA':
            # User ortho views clip symmetrically around the view center, so the
            # front limit is the far-pushed ray origin rather than the eye.
            try:
                origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (float(region.width) * 0.5, float(region.height) * 0.5))
                if origin is not None:
                    ref = Vector(tuple(origin))
            except Exception:
                ref = eye
        return {
            'persp': persp,
            'eye': eye,
            'back': back,
            'ref': ref,
            'pm': rv3d.perspective_matrix.copy(),
            'half_w': float(region.width) * 0.5,
            'half_h': float(region.height) * 0.5,
            'scene': scene,
            'depsgraph': depsgraph,
            'inside': _csdt_crossing_shape_inside_test(shape),
            'objs': {},
        }
    except Exception:
        return None


def _csdt_crossing_occlusion_obj(occ, obj):
    try:
        ptr = int(obj.as_pointer())
    except Exception:
        ptr = id(obj)
    objs = occ.setdefault('objs', {})
    ent = objs.get(ptr)
    if ent is not None:
        return ent if ent.get('ok') else None
    ent = {'ok': False, 'ptr': ptr}
    objs[ptr] = ent
    try:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        bm.faces.index_update()
        mw = obj.matrix_world.copy()
        sc = mw.to_scale()
        scale = max(abs(float(sc[0])), abs(float(sc[1])), abs(float(sc[2])))
        if not (scale > 0.0):
            scale = 1.0
        bvh = BVHTree.FromBMesh(bm)
        ent.update({
            'ok': bvh is not None,
            'bm': bm,
            'mw': mw,
            'mwi': mw.inverted_safe(),
            'scale': scale,
            'pm': occ['pm'] @ mw,
            'bvh': bvh,
        })
    except Exception:
        ent['ok'] = False
    return ent if ent.get('ok') else None


def _csdt_crossing_occlusion_point_visible(occ, ent, obj, p_local, own_faces, eps_l):
    # True = visible, False = hidden, None = undecided (caller falls back).
    pw = ent['mw'] @ p_local
    if occ['persp']:
        target = occ['eye']
        seg = target - pw
        dist_w = seg.length
        if dist_w <= 1.0e-9:
            return True
        dir_w = seg / dist_w
    else:
        dir_w = occ['back']
        dist_w = (occ['ref'] - pw).dot(dir_w)
        if dist_w <= 0.0:
            return True
        target = pw + dir_w * dist_w
    # Own mesh, in object space so non-uniform scale stays exact.
    seg_l = (ent['mwi'] @ target) - p_local
    dist_l = seg_l.length
    if dist_l <= 1.0e-12:
        return True
    dir_l = seg_l / dist_l
    bvh = ent['bvh']
    faces = ent['bm'].faces
    origin = p_local + dir_l * eps_l
    remaining = dist_l - eps_l
    clear = False
    for _step in range(_CSDT_CROSSING_OCC_SELF_STEPS):
        if remaining <= 0.0:
            clear = True
            break
        loc, _nor, idx, dist = bvh.ray_cast(origin, dir_l, remaining)
        if loc is None:
            clear = True
            break
        skip = idx in own_faces
        if not skip:
            try:
                skip = bool(faces[idx].hide)
            except Exception:
                skip = False
        if not skip:
            return False
        advance = float(dist) + eps_l
        origin = origin + dir_l * advance
        remaining -= advance
    if not clear:
        return None
    # Other objects, in world space. Hits on this object were judged above.
    eps_w = eps_l * float(ent['scale'])
    origin_w = pw + dir_w * eps_w
    remaining_w = dist_w - eps_w
    scene = occ['scene']
    depsgraph = occ['depsgraph']
    obj_ptr = ent['ptr']
    for _step in range(_CSDT_CROSSING_OCC_SCENE_STEPS):
        if remaining_w <= 0.0:
            return True
        result = scene.ray_cast(depsgraph, origin_w, dir_w, distance=remaining_w)
        if not result or not bool(result[0]):
            return True
        hit_obj = result[4] if len(result) > 4 else None
        same = hit_obj is obj
        if not same and hit_obj is not None:
            try:
                same = int(hit_obj.as_pointer()) == obj_ptr
            except Exception:
                same = False
        if not same:
            return False
        advance = (Vector(tuple(result[1])) - origin_w).length + eps_w
        origin_w = origin_w + dir_w * advance
        remaining_w -= advance
    return None


def _csdt_crossing_occlusion_element_visible(occ, obj, *, face=None, edge=None):
    try:
        ent = _csdt_crossing_occlusion_obj(occ, obj)
        if ent is None:
            return None
        if edge is not None:
            co0 = edge.verts[0].co
            co1 = edge.verts[1].co
            cands = [co0.lerp(co1, t) for t in _CSDT_CROSSING_OCC_EDGE_T]
            size = (co1 - co0).length
            own = {f.index for f in edge.link_faces}
        elif face is not None:
            center = face.calc_center_median()
            cos = [v.co for v in face.verts]
            cands = [center] + [center.lerp(co, _CSDT_CROSSING_OCC_FACE_TOWARD) for co in cos]
            size = max([(co - center).length for co in cos] or [0.0])
            own = {face.index}
        else:
            return None
        inside = occ.get('inside')
        chosen = []
        if inside is not None:
            pm = ent['pm']
            hw = occ['half_w']
            hh = occ['half_h']
            for p in cands:
                prj = pm @ Vector((p[0], p[1], p[2], 1.0))
                if prj[3] <= 1.0e-9:
                    continue
                if inside(hw + hw * (prj[0] / prj[3]), hh + hh * (prj[1] / prj[3])):
                    chosen.append(p)
                    if len(chosen) >= _CSDT_CROSSING_OCC_MAX_POINTS:
                        break
        if not chosen:
            chosen = cands[:_CSDT_CROSSING_OCC_FALLBACK_POINTS]
        eps_l = max(1.0e-6, 1.0e-3 * float(size))
        undecided = False
        for p in chosen:
            res = _csdt_crossing_occlusion_point_visible(occ, ent, obj, p, own, eps_l)
            if res is True:
                return True
            if res is None:
                undecided = True
        return None if undecided else False
    except Exception:
        return None


def _csdt_crossing_view3d_element_visible(context, area, region, rv3d, obj, screen_points, *, face=None, edge=None, selector_shape=None, occ=None):
    if _csdt_crossing_view3d_select_through_allowed(area):
        return True
    if occ is not None:
        res = _csdt_crossing_occlusion_element_visible(occ, obj, face=face, edge=edge)
        if res is not None:
            return bool(res)
    try:
        pts = [_csdt_crossing_point_2d(p) for p in list(screen_points or ())]
        pts = [p for p in pts if p is not None]
    except Exception:
        pts = []
    if not pts:
        return False
    samples = []
    try:
        if len(pts) >= 2 and edge is not None:
            samples.append(((pts[0][0] + pts[-1][0]) * 0.5, (pts[0][1] + pts[-1][1]) * 0.5))
        if len(pts) >= 3 and face is not None:
            samples.append((sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)))
        samples.extend(pts[:3])
        samples.extend(_csdt_crossing_shape_probe_points(selector_shape))
    except Exception:
        samples = pts[:3]
    if isinstance(selector_shape, dict):
        try:
            scoped = []
            for sample in samples:
                if _csdt_crossing_points_hit_shape([sample], selector_shape, is_face=False, pad=0.0):
                    scoped.append(sample)
            if scoped:
                samples = scoped
        except Exception:
            pass
    for pt in samples[:5]:
        if _csdt_crossing_region_point_visible_on_obj(context, region, rv3d, obj, pt, face=face, edge=edge):
            return True
    return False


def _csdt_crossing_project_edge_points_3d(region, rv3d, mw, edge):
    try:
        return [
            view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ edge.verts[0].co),
            view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ edge.verts[1].co),
        ]
    except Exception:
        return []


def _csdt_crossing_project_face_points_3d(region, rv3d, mw, face):
    pts = []
    try:
        for vert in list(getattr(face, 'verts', []) or []):
            try:
                p = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ vert.co)
            except Exception:
                p = None
            if p is None:
                return []
            pts.append(p)
    except Exception:
        return []
    return pts


def _csdt_crossing_element_target_selected(elem, mode_name, preselected=None):
    try:
        current = bool(getattr(elem, 'select', False))
    except Exception:
        current = False
    mode_name = str(mode_name or 'SET').upper()
    if mode_name == 'SUB':
        return False
    if mode_name == 'XOR':
        pre = current if preselected is None else bool(preselected)
        if current != pre:
            return current
        return not pre
    return True


def _csdt_crossing_apply_bmesh_target(elem, mode_name, preselected=None):
    try:
        before = bool(getattr(elem, 'select', False))
    except Exception:
        before = False
    target = bool(_csdt_crossing_element_target_selected(elem, mode_name, preselected=preselected))
    if before == target:
        return False
    try:
        elem.select_set(target)
    except Exception:
        try:
            elem.select = target
        except Exception:
            return False
    return True


def _csdt_crossing_snapshot_key(obj, kind, index, subindex=None):
    try:
        obj_ptr = int(obj.as_pointer()) if obj is not None and hasattr(obj, 'as_pointer') else id(obj)
    except Exception:
        obj_ptr = id(obj)
    try:
        idx = int(index)
    except Exception:
        idx = -1
    if subindex is None:
        return (obj_ptr, str(kind), idx)
    try:
        subindex = int(subindex)
    except Exception:
        subindex = -1
    return (obj_ptr, str(kind), idx, subindex)


def _csdt_crossing_preselect_snapshot(context, area_type='VIEW_3D', include_edges=True, include_faces=True):
    snapshot = {}
    try:
        if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
            return snapshot
        objs = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
    except Exception:
        objs = None
    if not objs:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        objs = [obj] if obj is not None else []
    area_type = str(area_type or 'VIEW_3D').upper()
    for obj in objs:
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        except Exception:
            continue
        try:
            if include_edges:
                for edge in bm.edges:
                    snapshot[_csdt_crossing_snapshot_key(obj, 'EDGE', getattr(edge, 'index', -1))] = bool(getattr(edge, 'select', False))
            if include_faces:
                for face in bm.faces:
                    snapshot[_csdt_crossing_snapshot_key(obj, 'FACE', getattr(face, 'index', -1))] = bool(getattr(face, 'select', False))
        except Exception:
            pass
    return snapshot


def _csdt_apply_crossing_selection_view3d(context, shape, mode='SET', area=None, region=None, region_data=None, preselect=None, native_select_ok=True, clear_first=False):
    try:
        if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
            return False
        edge_enabled, face_enabled = _csdt_crossing_selection_flags(context)
        select_mode = tuple(bool(v) for v in context.tool_settings.mesh_select_mode[:])
        if len(select_mode) < 3:
            return False
        edge_enabled = bool(edge_enabled and select_mode[1])
        face_enabled = bool(face_enabled and select_mode[2])
        if not edge_enabled and not face_enabled:
            return False
    except Exception:
        return False
    if not isinstance(shape, dict):
        return False
    if area is None or region is None:
        area, region = _get_view3d_area_region(context)
    if area is None or region is None:
        return False
    try:
        rv3d = region_data or _view3d_region_data(area, region)
    except Exception:
        rv3d = region_data
    if rv3d is None:
        return False
    mode_name = str(mode or 'SET').upper()
    if mode_name not in {'SET', 'ADD', 'SUB', 'XOR', 'AND'}:
        mode_name = 'SET'
    if mode_name == 'AND':
        mode_name = 'SET'
    try:
        objs = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
    except Exception:
        objs = None
    if not objs:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        objs = [obj] if obj is not None else []
    try:
        total = sum(len(getattr(obj.data, 'edges', []) or []) + len(getattr(obj.data, 'polygons', []) or []) for obj in objs if obj is not None and getattr(obj, 'type', None) == 'MESH')
    except Exception:
        total = 0
    native_select_ok = bool(native_select_ok)
    max_elems = int(_CSDT_CROSSING_SELECTION_MAX_ELEMENTS_NATIVE_OK if native_select_ok else _CSDT_CROSSING_SELECTION_MAX_ELEMENTS_NATIVE_FAILED)
    if total > max_elems:
        return False
    time_budget = float(_CSDT_CROSSING_SELECTION_TIME_BUDGET_NATIVE_OK if native_select_ok else _CSDT_CROSSING_SELECTION_TIME_BUDGET_NATIVE_FAILED)
    if preselect is None:
        preselect = {}
    clear_first = bool(clear_first and mode_name == 'SET' and not native_select_ok)
    changed_any = False
    try:
        if clear_first and _editmesh_select_all_native(context, 'DESELECT'):
            changed_any = True
            clear_first = False
    except Exception:
        pass
    occ = None
    if not _csdt_crossing_view3d_select_through_allowed(area):
        occ = _csdt_crossing_occlusion_begin(context, region, rv3d, shape)
    # Visibility tests (occlusion BVH build + ray casts) run on their own allowance so
    # they never eat the element-walk budget; spending past it stops the walk the same
    # way the walk budget does.
    vis_budget = float(_CSDT_CROSSING_SELECTION_VISIBILITY_TIME_BUDGET_NATIVE_OK if native_select_ok else _CSDT_CROSSING_SELECTION_VISIBILITY_TIME_BUDGET_NATIVE_FAILED)
    vis_spent = 0.0
    start_t = time.perf_counter()
    elem_counter = 0
    timed_out = False
    for obj in objs:
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        except Exception:
            continue
        mw = getattr(obj, 'matrix_world', None)
        if mw is None:
            continue
        changed = False
        try:
            if clear_first and mode_name == 'SET':
                for elem_seq in (bm.verts, bm.edges, bm.faces):
                    for elem in elem_seq:
                        try:
                            if bool(getattr(elem, 'select', False)):
                                elem.select_set(False)
                                changed = True
                        except Exception:
                            pass
            if edge_enabled:
                for edge in bm.edges:
                    elem_counter += 1
                    if (elem_counter & 0x1FF) == 0 and (time.perf_counter() - start_t - vis_spent) > time_budget:
                        timed_out = True
                        break
                    try:
                        if bool(getattr(edge, 'hide', False)):
                            continue
                    except Exception:
                        pass
                    pts = _csdt_crossing_project_edge_points_3d(region, rv3d, mw, edge)
                    if len(pts) < 2:
                        continue
                    if not _csdt_crossing_points_hit_shape(pts, shape, is_face=False, pad=float(_CSDT_CROSSING_SELECTION_EDGE_PAD)):
                        continue
                    key = _csdt_crossing_snapshot_key(obj, 'EDGE', getattr(edge, 'index', -1))
                    pre = preselect.get(key) if isinstance(preselect, dict) else None
                    try:
                        # Already in its target state: the visibility test cannot change anything.
                        if bool(getattr(edge, 'select', False)) == bool(_csdt_crossing_element_target_selected(edge, mode_name, preselected=pre)):
                            continue
                    except Exception:
                        pass
                    vis_t0 = time.perf_counter()
                    visible = _csdt_crossing_view3d_element_visible(context, area, region, rv3d, obj, pts, edge=edge, selector_shape=shape, occ=occ)
                    vis_spent += time.perf_counter() - vis_t0
                    if visible:
                        changed |= _csdt_crossing_apply_bmesh_target(edge, mode_name, preselected=pre)
                    if vis_spent > vis_budget:
                        timed_out = True
                        break
            if (not timed_out) and face_enabled:
                for face in bm.faces:
                    elem_counter += 1
                    if (elem_counter & 0x1FF) == 0 and (time.perf_counter() - start_t - vis_spent) > time_budget:
                        timed_out = True
                        break
                    try:
                        if bool(getattr(face, 'hide', False)):
                            continue
                    except Exception:
                        pass
                    pts = _csdt_crossing_project_face_points_3d(region, rv3d, mw, face)
                    if len(pts) < 3:
                        continue
                    if not _csdt_crossing_points_hit_shape(pts, shape, is_face=True, pad=float(_CSDT_CROSSING_SELECTION_FACE_PAD)):
                        continue
                    key = _csdt_crossing_snapshot_key(obj, 'FACE', getattr(face, 'index', -1))
                    pre = preselect.get(key) if isinstance(preselect, dict) else None
                    try:
                        if bool(getattr(face, 'select', False)) == bool(_csdt_crossing_element_target_selected(face, mode_name, preselected=pre)):
                            continue
                    except Exception:
                        pass
                    vis_t0 = time.perf_counter()
                    visible = _csdt_crossing_view3d_element_visible(context, area, region, rv3d, obj, pts, face=face, selector_shape=shape, occ=occ)
                    vis_spent += time.perf_counter() - vis_t0
                    if visible:
                        changed |= _csdt_crossing_apply_bmesh_target(face, mode_name, preselected=pre)
                    if vis_spent > vis_budget:
                        timed_out = True
                        break
            if changed:
                try:
                    bm.select_flush_mode()
                except Exception:
                    pass
                try:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
                changed_any = True
        except Exception:
            pass
        if timed_out:
            break
    if changed_any:
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
    return changed_any


def _csdt_apply_crossing_selection_region(context, area_type, shape, mode='SET', area=None, region=None, region_data=None, preselect=None, native_select_ok=True, clear_first=False):
    area_type = str(area_type or '').upper()
    if area_type != 'VIEW_3D':
        return False
    return _csdt_apply_crossing_selection_view3d(context, shape, mode=mode, area=area, region=region, region_data=region_data, preselect=preselect, native_select_ok=native_select_ok, clear_first=clear_first)


def _csdt_supplement_editmesh_edge_box_selection(context, xmin, xmax, ymin, ymax, mode='SET', area=None, region=None, region_data=None, native_select_ok=True, clear_first=None):
    """Deterministically finish Smart Gizmo background box-select in edge mode.

    The native View3D select_box remains the primary path.  This supplement is a
    bounded safety pass for edge-mode misses only; it uses a fast matrix endpoint
    projection first and falls back to sampled projection only for clipped edges.
    Dense meshes are capped by edge-count and time budgets so continued editing
    cannot turn the viewport progressively heavy.
    """
    try:
        if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
            return False
        msm = tuple(bool(v) for v in context.tool_settings.mesh_select_mode[:])
        if len(msm) < 2 or not bool(msm[1]):
            return False
    except Exception:
        return False
    rect = _csdt_screen_rect_from_points((xmin, ymin), (xmax, ymax))
    if rect is None:
        return False
    try:
        rx0, rx1, ry0, ry1 = rect
        if (abs(rx1 - rx0) < 1.0) and (abs(ry1 - ry0) < 1.0):
            return False
    except Exception:
        return False
    if area is None or region is None:
        area, region = _get_view3d_area_region(context)
    if area is None or region is None:
        return False
    try:
        rv3d = region_data or _view3d_region_data(area, region, (float(xmin) + float(xmax)) * 0.5, (float(ymin) + float(ymax)) * 0.5)
    except Exception:
        rv3d = region_data
    if rv3d is None:
        try:
            rv3d = getattr(context, 'region_data', None)
        except Exception:
            rv3d = None
    if rv3d is None:
        return False
    try:
        q_scale = float(_quadview_visible_to_projection_scale(area, region=region, rv3d=rv3d, mx=(float(xmin) + float(xmax)) * 0.5, my=(float(ymin) + float(ymax)) * 0.5))
        rect = _quadview_visible_rect_to_projection_rect(area, rect, region=region, rv3d=rv3d) or rect
        edge_box_pad = max(2.0, 2.0 * q_scale)
    except Exception:
        edge_box_pad = 2.0
    action = _csdt_select_action_from_box_mode(mode)
    # Native XOR has already toggled front/visible elements.  A second blind
    # toggle would undo those results, so only supplement the deterministic SET,
    # ADD, and SUB paths here.  This mirrors Blender's result where possible and
    # avoids corrupting toggle selection.
    if action == 'TOGGLE':
        return False
    try:
        total_edges = _csdt_total_editmesh_edges(context)
    except Exception:
        total_edges = 0
    native_select_ok = bool(native_select_ok)
    if native_select_ok and total_edges > int(_CSDT_EDGE_BOX_SUPPLEMENT_MAX_EDGES_NATIVE_OK):
        return False
    if (not native_select_ok) and total_edges > int(_CSDT_EDGE_BOX_SUPPLEMENT_MAX_EDGES_NATIVE_FAILED):
        return False
    time_budget = float(_CSDT_EDGE_BOX_SUPPLEMENT_TIME_BUDGET_NATIVE_OK if native_select_ok else _CSDT_EDGE_BOX_SUPPLEMENT_TIME_BUDGET_NATIVE_FAILED)
    try:
        objs = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
    except Exception:
        objs = None
    if not objs:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        objs = [obj] if obj is not None else []

    mode_name = str(mode or 'SET').upper()
    if clear_first is None:
        clear_first = bool(mode_name == 'SET' and not native_select_ok)
    else:
        clear_first = bool(clear_first)

    changed_any = False
    if clear_first and mode_name == 'SET':
        # Prefer Blender's C-side clear.  Python-loop clearing every BMesh element
        # before every box-select was a major dense-mesh slowdown.
        try:
            if _editmesh_select_all_native(context, 'DESELECT'):
                changed_any = True
                clear_first = False
        except Exception:
            pass

    start_t = time.perf_counter()
    edge_counter = 0
    timed_out = False
    for obj in objs:
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
        except Exception:
            continue
        mw = getattr(obj, 'matrix_world', None)
        if mw is None:
            continue
        try:
            full_mat = rv3d.perspective_matrix @ mw
        except Exception:
            full_mat = None
        changed = False
        try:
            if clear_first and mode_name == 'SET':
                for elem_seq in (bm.verts, bm.edges, bm.faces):
                    for elem in elem_seq:
                        try:
                            if bool(getattr(elem, 'select', False)):
                                elem.select_set(False)
                                changed = True
                        except Exception:
                            try:
                                elem.select = False
                                changed = True
                            except Exception:
                                pass
            for edge in bm.edges:
                edge_counter += 1
                if (edge_counter & 0x1FF) == 0 and (time.perf_counter() - start_t) > time_budget:
                    timed_out = True
                    break
                try:
                    if bool(getattr(edge, 'hide', False)):
                        continue
                except Exception:
                    pass
                hit = _csdt_projected_edge_hits_rect_matrix(region, full_mat, edge, rect, pad=edge_box_pad)
                if hit is None:
                    # Clipped-edge fallback.  Keep samples short and let the time
                    # budget abort the supplement rather than freezing the editor.
                    hit = _csdt_projected_edge_hits_rect(region, rv3d, mw, edge, rect, pad=edge_box_pad, steps=4)
                if not hit:
                    continue
                changed |= _csdt_apply_bmesh_select_state(edge, action if mode_name != 'SET' else 'SELECT')
            if changed:
                try:
                    bm.select_flush_mode()
                except Exception:
                    pass
                try:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
                changed_any = True
        except Exception:
            continue
        if timed_out:
            break
    if changed_any:
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
    return changed_any


def _csdt_supplement_editmesh_box_selection(context, xmin, xmax, ymin, ymax, mode='SET', area=None, region=None, region_data=None, native_select_ok=True, clear_first=None):
    """Deterministic edit-mesh box selection supplement for Smart Gizmo drags.

    The native View3D box selector is still called first.  This function only
    finishes the result when the native operator is cancelled/missed, or when a
    small deterministic supplement is safer than trusting a stale View3D context.
    It uses the same region coordinates as the visible Smart Gizmo box preview.
    """
    try:
        if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
            return False
        select_mode = tuple(bool(v) for v in context.tool_settings.mesh_select_mode[:])
        if len(select_mode) < 3:
            return False
    except Exception:
        return False
    rect = _csdt_screen_rect_from_points((xmin, ymin), (xmax, ymax))
    if rect is None:
        return False
    try:
        rx0, rx1, ry0, ry1 = rect
        if (abs(rx1 - rx0) < 1.0) and (abs(ry1 - ry0) < 1.0):
            return False
    except Exception:
        return False
    if area is None or region is None:
        area, region = _get_view3d_area_region(context)
    if area is None or region is None:
        return False
    try:
        rv3d = region_data or _view3d_region_data(area, region) or getattr(context, 'region_data', None)
    except Exception:
        rv3d = region_data
    if rv3d is None:
        return False

    try:
        q_scale = float(_quadview_visible_to_projection_scale(area, region=region, rv3d=rv3d, mx=(float(xmin) + float(xmax)) * 0.5, my=(float(ymin) + float(ymax)) * 0.5))
        rect = _quadview_visible_rect_to_projection_rect(area, rect, region=region, rv3d=rv3d) or rect
        vert_box_pad = max(1.0, 1.0 * q_scale)
        edge_box_pad = max(2.0, 2.0 * q_scale)
        face_box_pad = max(2.0, 2.0 * q_scale)
    except Exception:
        vert_box_pad = 1.0
        edge_box_pad = 2.0
        face_box_pad = 2.0

    mode_name = str(mode or 'SET').upper()
    action = _csdt_select_action_from_box_mode(mode_name)
    if clear_first is None:
        clear_first = bool(mode_name == 'SET' and not bool(native_select_ok))
    else:
        clear_first = bool(clear_first)

    try:
        objs = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
    except Exception:
        objs = None
    if not objs:
        obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
        objs = [obj] if obj is not None else []

    changed_any = False
    if clear_first and mode_name == 'SET':
        try:
            if _editmesh_select_all_native(context, 'DESELECT'):
                changed_any = True
                clear_first = False
        except Exception:
            pass

    # Keep the fallback bounded.  Native selection should handle huge meshes; if
    # it fails on a very dense mesh, avoiding a UI stall is preferable to a Python
    # full-scan freeze.
    max_elems = int(_CSDT_EDGE_BOX_SUPPLEMENT_MAX_EDGES_NATIVE_OK if native_select_ok else _CSDT_EDGE_BOX_SUPPLEMENT_MAX_EDGES_NATIVE_FAILED)
    time_budget = float(_CSDT_EDGE_BOX_SUPPLEMENT_TIME_BUDGET_NATIVE_OK if native_select_ok else _CSDT_EDGE_BOX_SUPPLEMENT_TIME_BUDGET_NATIVE_FAILED)
    start_t = time.perf_counter()
    elem_counter = 0
    timed_out = False
    for obj in objs:
        if obj is None or getattr(obj, 'type', None) != 'MESH':
            continue
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        except Exception:
            continue
        try:
            total = len(bm.verts) + len(bm.edges) + len(bm.faces)
            if total > max_elems:
                continue
        except Exception:
            pass
        mw = getattr(obj, 'matrix_world', None)
        if mw is None:
            continue
        try:
            full_mat = rv3d.perspective_matrix @ mw
        except Exception:
            full_mat = None
        changed = False
        try:
            if clear_first and mode_name == 'SET':
                for elem_seq in (bm.verts, bm.edges, bm.faces):
                    for elem in elem_seq:
                        try:
                            if bool(getattr(elem, 'select', False)):
                                elem.select_set(False)
                                changed = True
                        except Exception:
                            try:
                                elem.select = False
                                changed = True
                            except Exception:
                                pass
            if bool(select_mode[0]):
                for vert in bm.verts:
                    elem_counter += 1
                    if (elem_counter & 0x3FF) == 0 and (time.perf_counter() - start_t) > time_budget:
                        timed_out = True; break
                    try:
                        if bool(getattr(vert, 'hide', False)):
                            continue
                    except Exception:
                        pass
                    try:
                        p = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ vert.co)
                    except Exception:
                        p = None
                    if _csdt_point_in_rect_2d(p, rect, pad=vert_box_pad):
                        changed |= _csdt_apply_bmesh_select_state(vert, action if mode_name != 'SET' else 'SELECT')
            if not timed_out and bool(select_mode[1]):
                for edge in bm.edges:
                    elem_counter += 1
                    if (elem_counter & 0x1FF) == 0 and (time.perf_counter() - start_t) > time_budget:
                        timed_out = True; break
                    try:
                        if bool(getattr(edge, 'hide', False)):
                            continue
                    except Exception:
                        pass
                    hit = _csdt_projected_edge_hits_rect_matrix(region, full_mat, edge, rect, pad=edge_box_pad)
                    if hit is None:
                        hit = _csdt_projected_edge_hits_rect(region, rv3d, mw, edge, rect, pad=edge_box_pad, steps=4)
                    if hit:
                        changed |= _csdt_apply_bmesh_select_state(edge, action if mode_name != 'SET' else 'SELECT')
            if not timed_out and len(select_mode) >= 3 and bool(select_mode[2]):
                for face in bm.faces:
                    elem_counter += 1
                    if (elem_counter & 0x3FF) == 0 and (time.perf_counter() - start_t) > time_budget:
                        timed_out = True; break
                    try:
                        if bool(getattr(face, 'hide', False)):
                            continue
                    except Exception:
                        pass
                    try:
                        center = face.calc_center_median()
                        p = view3d_utils.location_3d_to_region_2d(region, rv3d, mw @ center)
                    except Exception:
                        p = None
                    if _csdt_point_in_rect_2d(p, rect, pad=face_box_pad):
                        changed |= _csdt_apply_bmesh_select_state(face, action if mode_name != 'SET' else 'SELECT')
            if changed:
                try:
                    bm.select_flush_mode()
                except Exception:
                    pass
                try:
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
                changed_any = True
        except Exception:
            continue
        if timed_out:
            break
    if changed_any:
        _invalidate_gizmo_cache()
        try: _tag_view3d_redraw()
        except Exception: pass
    return changed_any

def _execute_view3d_select_box_region(context, xmin, xmax, ymin, ymax, mode="SET", area=None, region=None, region_data=None):
    """Execute a View3D box selection using fixed region coordinates.

    This avoids invoking Blender's modal wait-for-input path after the mouse has
    already moved, which is what caused the visible box origin to drift away from
    the original background press.
    """
    try:
        x0 = int(round(float(xmin)))
        x1 = int(round(float(xmax)))
        y0 = int(round(float(ymin)))
        y1 = int(round(float(ymax)))
    except Exception:
        return False
    if x0 == x1 and y0 == y1:
        return False
    if x0 > x1:
        x0, x1 = x1, x0
    if y0 > y1:
        y0, y1 = y1, y0
    mode = str(mode or "SET").upper()
    if mode not in {"SET", "ADD", "SUB", "XOR", "AND"}:
        mode = "SET"
    disallow_obj = getattr(context, "mode", "").startswith("EDIT")

    # In Blender 5.1 Quad View, native view3d.select_box can receive a stale
    # RegionView3D from Python-side modal replay.  For Edit Mesh Smart Transform
    # already provides a deterministic supplement that uses the visible box
    # coordinates and active mesh select mode, so avoid the native route here.
    try:
        if str(getattr(context, 'mode', '') or '') == 'EDIT_MESH' and area is not None and _quadview_layout_active(area):
            return False
    except Exception:
        pass

    def _call(kwargs):
        try:
            rv3d_override = None
            try:
                rv3d_override = region_data or _view3d_region_data(area, region, (float(x0) + float(x1)) * 0.5, (float(y0) + float(y1)) * 0.5)
            except Exception:
                rv3d_override = None
            with _temp_override_view3d(context, area=area, region=region, region_data=rv3d_override):
                result = bpy.ops.view3d.select_box("EXEC_DEFAULT", **kwargs)
            try:
                if isinstance(result, set) and 'CANCELLED' in result:
                    return False
            except Exception:
                pass
            _invalidate_gizmo_cache()
            try:
                if str(getattr(bpy.context, 'mode', '') or getattr(context, 'mode', '') or '') == 'OBJECT':
                    _csdt_sync_active_after_object_selection(
                        bpy.context,
                        mode=mode,
                        rect=(x0, x1, y0, y1),
                        area=area,
                        region=region,
                        region_data=rv3d_override,
                    )
            except Exception:
                pass
            return True
        except Exception:
            return False

    base = {"xmin": x0, "xmax": x1, "ymin": y0, "ymax": y1, "mode": mode, "wait_for_input": False}
    if disallow_obj:
        kw = _add_disallow_object_select_kw(bpy.ops.view3d.select_box, dict(base))
        if kw is not None and _call(kw):
            return True
    if _call(base):
        return True

    # Older/future Blender builds may expose extend/deselect/toggle instead of mode.
    extend = mode in {"ADD", "SUB", "XOR", "AND"}
    deselect = (mode == "SUB")
    toggle = (mode == "XOR")
    legacy = {"xmin": x0, "xmax": x1, "ymin": y0, "ymax": y1, "wait_for_input": False,
              "extend": extend, "deselect": deselect, "toggle": toggle}
    if disallow_obj:
        kw = _add_disallow_object_select_kw(bpy.ops.view3d.select_box, dict(legacy))
        if kw is not None and _call(kw):
            return True
    if _call(legacy):
        return True

    for keys in (
        ("xmin", "xmax", "ymin", "ymax", "extend", "deselect"),
        ("xmin", "xmax", "ymin", "ymax", "extend"),
        ("xmin", "xmax", "ymin", "ymax"),
    ):
        kwargs = {k: legacy[k] for k in keys if k in legacy}
        if _call(kwargs):
            return True
    return False


def _execute_view3d_select_lasso_region(context, points, mode="SET", area=None, region=None, region_data=None):
    """Execute lasso selection from the complete region-local drag path.

    Smart Transform receives the original LEFTMOUSE press before Blender's
    region-select operator.  Replaying the collected path with EXEC_DEFAULT on
    release keeps the visible lasso and the selected geometry on the same path,
    including very fast drags that produce only one move event.
    """
    clean_points = []
    try:
        for point in list(points or ()):
            x = int(round(float(point[0])))
            y = int(round(float(point[1])))
            if not clean_points or clean_points[-1] != (x, y):
                clean_points.append((x, y))
    except Exception:
        return False
    if len(clean_points) < 3:
        return False

    mode = str(mode or "SET").upper()
    if mode not in {"SET", "ADD", "SUB", "XOR", "AND"}:
        mode = "SET"
    path = [
        {"name": "", "loc": (x, y), "time": float(index) * 0.01}
        for index, (x, y) in enumerate(clean_points)
    ]
    try:
        rv3d_override = None
        try:
            rv3d_override = region_data or _view3d_region_data(area, region, clean_points[-1][0], clean_points[-1][1])
        except Exception:
            rv3d_override = None
        with _temp_override_view3d(context, area=area, region=region, region_data=rv3d_override):
            result = bpy.ops.view3d.select_lasso("EXEC_DEFAULT", path=path, mode=mode)
        if isinstance(result, set) and 'CANCELLED' in result:
            return False
        _invalidate_gizmo_cache()
        try:
            _tag_view3d_redraw()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _dispatch_selection_tool(context, mode="SET", prefer_wait_for_input=True, tool_id=None):
    tool_id = str(tool_id or _get_active_select_tool_id(context) or "builtin.select_box").strip()
    disallow_obj = getattr(context, "mode", "").startswith("EDIT")
    if tool_id == "builtin.select_lasso":
        return _invoke_select_op(bpy.ops.view3d.select_lasso, mode=mode, prefer_wait_for_input=prefer_wait_for_input, disallow_object_select=disallow_obj)
    elif tool_id == "builtin.select_circle":
        return _invoke_select_op(bpy.ops.view3d.select_circle, mode=mode, prefer_wait_for_input=prefer_wait_for_input, disallow_object_select=disallow_obj)
    elif tool_id == "builtin.select":
        return _invoke_select_op(bpy.ops.view3d.select, mode=mode, prefer_wait_for_input=prefer_wait_for_input, disallow_object_select=disallow_obj)
    else:
        return _invoke_select_op(bpy.ops.view3d.select_box, mode=mode, prefer_wait_for_input=prefer_wait_for_input, disallow_object_select=disallow_obj)

def _deselect_all(context):
    mode = getattr(context, "mode", "")

    if mode == "EDIT_MESH":
        if _editmesh_select_all_native(context, 'DESELECT'):
            return
        changed = False
        try:
            objs = getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None)
            if not objs:
                objs = [getattr(context, "active_object", None)] if getattr(context, "active_object", None) else []
            for obj in objs:
                if not obj or getattr(obj, "type", None) != "MESH":
                    continue
                try:
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
                    for v in bm.verts:
                        if v.select:
                            v.select = False; changed = True
                    for e in bm.edges:
                        if e.select:
                            e.select = False; changed = True
                    for f in bm.faces:
                        if f.select:
                            f.select = False; changed = True
                    try:
                        bm.select_history.clear()
                    except Exception:
                        pass
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    pass
        except Exception:
            pass
        if changed:
            _invalidate_gizmo_cache()
            return

    elif mode == "EDIT_LATTICE":
        try:
            bpy.ops.lattice.select_all(action="DESELECT")
            _invalidate_gizmo_cache()
            return
        except Exception:
            pass

    elif mode == "OBJECT":
        try:
            bpy.ops.object.select_all(action="DESELECT")
            _invalidate_gizmo_cache()
            return
        except Exception:
            try:
                for obj in getattr(context, "selected_objects", []) or []:
                    obj.select_set(False)
                _invalidate_gizmo_cache()
                return
            except Exception:
                pass

    try:
        _native_deselect_all_for_mode(context)
        _invalidate_gizmo_cache()
        return
    except Exception:
        pass
    _invalidate_gizmo_cache()

# bpy.ops.view3d.select_all does not exist on this build; deselect-all must be
# dispatched to the mode-owning operator namespace.
_NATIVE_SELECT_ALL_NAMESPACE_BY_MODE = {
    'OBJECT': 'object',
    'EDIT_MESH': 'mesh',
    'EDIT_CURVE': 'curve',
    'EDIT_SURFACE': 'curve',
    'EDIT_CURVES': 'curves',
    'EDIT_ARMATURE': 'armature',
    'POSE': 'pose',
    'EDIT_LATTICE': 'lattice',
    'EDIT_METABALL': 'mball',
    'EDIT_GREASE_PENCIL': 'grease_pencil',
}


def _native_deselect_all_for_mode(context):
    """Run the mode-appropriate native select_all(action='DESELECT')."""
    ns_name = _NATIVE_SELECT_ALL_NAMESPACE_BY_MODE.get(str(getattr(context, 'mode', '') or ''))
    if not ns_name:
        return False
    ns = getattr(bpy.ops, ns_name, None)
    op = getattr(ns, 'select_all', None) if ns is not None else None
    if op is None:
        return False
    result = op(action='DESELECT')
    return isinstance(result, set) and 'FINISHED' in result

def _csdt_should_force_single_select(context, event):
    try:
        if getattr(event, "shift", False) or getattr(event, "ctrl", False):
            return False
    except Exception: pass
    try: return _selection_count(context) >= 2
    except Exception: return False

def _csdt_deselect_all_for_single_select(context):
    try:
        if context.mode == "OBJECT":
            try:
                for o in context.view_layer.objects: o.select_set(False)
            except Exception:
                try: bpy.ops.object.select_all(action="DESELECT")
                except Exception: pass
            _invalidate_gizmo_cache()
            return

        if context.mode == "EDIT_MESH":
            if _editmesh_select_all_native(context, 'DESELECT'):
                return
            objs = getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None)
            if not objs: objs = [context.active_object] if context.active_object else []
            for o in objs:
                if not o or getattr(o, "type", None) != "MESH": continue
                try:
                    bm2 = bmesh.from_edit_mesh(o.data)
                    bm2.verts.ensure_lookup_table(); bm2.edges.ensure_lookup_table(); bm2.faces.ensure_lookup_table()
                    for v in bm2.verts: v.select = False
                    for e in bm2.edges: e.select = False
                    for f in bm2.faces: f.select = False
                    try: bm2.select_history.clear()
                    except Exception: pass
                    bmesh.update_edit_mesh(o.data, loop_triangles=False, destructive=False)
                except Exception: pass
            _invalidate_gizmo_cache()
            return

        if context.mode == "EDIT_LATTICE":
            try:
                with _temp_override_view3d(context):
                    bpy.ops.lattice.select_all(action="DESELECT")
            except Exception: pass
            _invalidate_gizmo_cache()
            return

        try: _native_deselect_all_for_mode(context)
        except Exception: pass
    except Exception: pass
    _invalidate_gizmo_cache()

def _selection_count(context):
    if context.mode == "EDIT_MESH":
        fast_total = _editmesh_selection_count_fast(context)
        if fast_total is not None:
            return int(fast_total)
        objs = getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None)
        if not objs: objs = [context.active_object] if context.active_object else []
        total = 0
        for obj in objs:
            if not obj or obj.type != "MESH": continue
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                total += sum(1 for v in bm.verts if v.select)
                total += sum(1 for e in bm.edges if e.select)
                total += sum(1 for f in bm.faces if f.select)
            except Exception: pass
        return total
    if context.mode == "EDIT_LATTICE":
        obj = context.active_object
        try: return sum(1 for p in obj.data.points if p.select)
        except Exception: return 0
    return len(getattr(context, "selected_objects", []) or [])
