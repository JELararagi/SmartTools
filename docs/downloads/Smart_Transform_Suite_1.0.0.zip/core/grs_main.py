# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
from ..keymap_safety import safe_remove_keymap_item as _sts_safe_remove_keymap_item
import math
import mathutils
import bmesh
import time
import blf
from bpy_extras import view3d_utils
import heapq
import gpu
from gpu_extras.batch import batch_for_shader

from ..translation import T, TI
from .. import runtime as _runtime
from .. import ui_icons as _ui_icons
from .. import operator_safety as _op_safety
from .. import settings as _settings
from ..manager_runtime_bridge import workspace_runtime_allowed as _workspace_runtime_allowed
from . import csdt_utils as cu
from . import csdt_globals as cg
# PCL(Proportional Cursor Lock)モジュールの読み込み


def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}


def _ui_label_kwargs(icon: str = 'NONE', custom_icon: str = ''):
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _draw_icon_label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> bool:
    try:
        layout.label(text=str(text or ''), **_ui_label_kwargs(icon, custom_icon))
        return True
    except TypeError:
        try:
            layout.label(text=str(text or ''), icon=icon or 'NONE')
            return True
        except Exception:
            return False
    except Exception:
        return False


def _operator_button_target(layout, *, icon_only: bool = False):
    if layout is None:
        return None
    if not icon_only:
        return layout
    try:
        row = layout.row(align=True)
        row.scale_x = 1.18
        row.scale_y = 1.28
        return row
    except Exception:
        return layout

from .grs_pcl import (
    _PCL_WINDOWS_AVAILABLE,
    _pcl_state,
    _pcl_clip_unlock,
    _pcl_ensure_wndproc_tap,
    _pcl_get_cursor_pos,
    _pcl_clip_lock_at,
    _pcl_remove_wndproc_tap
)

# =========================================================
# Colors
# =========================================================
def _hex_rgba(hexstr: str, a: float = 1.0):
    h = hexstr.lstrip('#')
    r = int(h[0:2], 16) / 255.0
    g = int(h[2:4], 16) / 255.0
    b = int(h[4:6], 16) / 255.0
    return (r, g, b, a)

COL_X = _hex_rgba("#e27997", 1.0)
COL_Y = _hex_rgba("#a3cf6d", 1.0)
COL_Z = _hex_rgba("#71a5e1", 1.0)

COL_DARK_X = _hex_rgba("#91303e", 1.0)
COL_DARK_Y = _hex_rgba("#59801a", 1.0)
COL_DARK_Z = _hex_rgba("#2b5b91", 1.0)

def _root_addon(context=None):
    try:
        ctx = context or bpy.context
        key = _runtime.resolve_addon_module_key(ctx, __package__, __name__, __file__)
        if not key:
            return None
        try:
            return ctx.preferences.addons.get(key)
        except Exception:
            return ctx.preferences.addons[key]
    except Exception:
        return None


def _prefs(context):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None


def _tag_all_view3d_redraw():
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        if not wm:
            return
        for win in wm.windows:
            scr = getattr(win, 'screen', None)
            if not scr:
                continue
            for area in scr.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _grs_view3d_override_kwargs(context, area=None, region=None, rv3d=None):
    override = {}
    try:
        window = getattr(context, 'window', None)
        if window is not None:
            override['window'] = window
    except Exception:
        pass
    try:
        if area is not None:
            override['area'] = area
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            if space is not None:
                override['space_data'] = space
        if region is not None:
            override['region'] = region
        rv3d = rv3d or cu._view3d_region_data(area, region)
        if rv3d is not None:
            override['region_data'] = rv3d
    except Exception:
        pass
    return override


def _grs_event_area_region(context, event, fallback_area=None, fallback_region=None):
    try:
        if event is not None:
            area, region = cu._event_view3d_area_region(context, event)
            if area is not None and region is not None:
                return area, region
    except Exception:
        pass
    if fallback_area is not None and fallback_region is not None:
        return fallback_area, fallback_region
    try:
        return cu._get_view3d_area_region(context)
    except Exception:
        return None, None



def _grs_editor_override_kwargs(context, area=None, region=None):
    override = {}
    try:
        window = getattr(context, 'window', None)
        if window is not None:
            override['window'] = window
    except Exception:
        pass
    try:
        area = area or getattr(context, 'area', None)
        if area is not None:
            override['area'] = area
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            if space is not None:
                override['space_data'] = space
        region = region or getattr(context, 'region', None)
        if region is not None:
            override['region'] = region
    except Exception:
        pass
    return override


def _invoke_native_grs_transform_in_current_editor(mode: str, op_context='INVOKE_REGION_WIN', prop_source=None, context=None):
    ctx = context if context is not None else bpy.context
    try:
        override = _grs_editor_override_kwargs(ctx)
        if override and hasattr(bpy.context, 'temp_override'):
            with bpy.context.temp_override(**override):
                return _invoke_native_grs_transform(mode, op_context, prop_source, context=bpy.context)
    except Exception:
        pass
    return _invoke_native_grs_transform(mode, op_context, prop_source, context=ctx)


def _grs_context_poll(context) -> bool:
    try:
        if context is None:
            return False
        area = getattr(context, 'area', None)
        area_type = getattr(area, 'type', '') if area is not None else ''
        if area is not None and area_type != 'VIEW_3D':
            return False
        if area is not None and area_type != 'VIEW_3D':
            return False
        if area is not None and not _workspace_runtime_allowed(context):
            return False
        if area is None:
            try:
                if not bool(getattr(bpy.app, 'background', False)):
                    return False
            except Exception:
                return False
        mode = str(getattr(context, 'mode', '') or '')
        if mode == 'OBJECT':
            return bool(getattr(context, 'selected_objects', None) or getattr(context, 'active_object', None))

        # Direct Smart G-R-S handling is implemented for object transforms,
        # mesh edit transforms, and lattice edit transforms.  Other View3D
        # transform contexts remain valid manual registration targets and are
        # delegated to Blender's native operator at invoke time so Pose,
        # Armature, Curve, Surface, Metaball, Grease Pencil, and future edit
        # contexts keep the full standard G/R/S feature set and native status bar.
        if mode == 'EDIT_MESH':
            obj = getattr(context, 'active_object', None)
            return obj is not None and getattr(obj, 'type', '') == 'MESH'
        if mode == 'EDIT_LATTICE':
            obj = getattr(context, 'active_object', None)
            return obj is not None and getattr(obj, 'type', '') == 'LATTICE'
        if mode.startswith('EDIT_'):
            return getattr(context, 'active_object', None) is not None
        if mode in {'POSE', 'SCULPT', 'PAINT_WEIGHT', 'PAINT_VERTEX', 'PAINT_TEXTURE', 'PARTICLE', 'EDIT_GPENCIL', 'PAINT_GPENCIL', 'SCULPT_GPENCIL', 'WEIGHT_GPENCIL'}:
            return getattr(context, 'active_object', None) is not None
        return getattr(context, 'active_object', None) is not None
    except Exception:
        return False


def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


class _SafeMissingOperator:
    def __setattr__(self, _name, _value):
        return None

    def __getattr__(self, _name):
        return None


_SAFE_MISSING_OPERATOR = _SafeMissingOperator()


def _operator_properties_contain(op, prop_name: str) -> bool:
    return _op_safety.operator_proxy_has_property(op, prop_name)


def _safe_set_operator_property(op, prop_name: str, value, *, operator_id: object | None = None) -> bool:
    if op is None or op is _SAFE_MISSING_OPERATOR:
        return False
    return _op_safety.safe_set_operator_property(op, prop_name, value, operator_id=operator_id, strict=True)


def _operator_exists(operator_id: object) -> bool:
    return _op_safety.operator_exists(operator_id)


def _safe_operator(layout_row, operator_id: str, *, text: str = "", icon: str = 'NONE', custom_icon: str = '', emboss: bool | None = None, depress: bool = False, **prop_values):
    idname = str(operator_id or '').strip()
    clean_props = dict(prop_values)
    icon_only = not str(text or '').strip()
    target = _operator_button_target(layout_row, icon_only=icon_only)
    if target is None:
        return _SAFE_MISSING_OPERATOR
    if emboss is None:
        emboss = True
    elif icon_only and emboss is False:
        emboss = True
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=idname, text=text, custom_icon=custom_icon, props=clean_props)
    if not _operator_exists(idname):
        try:
            fallback_icon = icon if icon and icon != 'NONE' else 'ERROR'
            _draw_icon_label(target, text or TI('Unavailable', '利用不可'), icon=fallback_icon)
        except Exception:
            pass
        return _SAFE_MISSING_OPERATOR
    try:
        try:
            op = target.operator(idname, text=text, emboss=bool(emboss), depress=bool(depress), **icon_args)
        except TypeError:
            try:
                op = target.operator(idname, text=text, icon=icon, emboss=bool(emboss), depress=bool(depress))
            except TypeError:
                op = target.operator(idname, text=text, icon=icon)
        for prop_name, prop_value in clean_props.items():
            try:
                _safe_set_operator_property(op, prop_name, prop_value, operator_id=idname)
            except Exception:
                pass
        return op
    except Exception:
        try:
            fallback_icon = icon if icon and icon != 'NONE' else 'ERROR'
            _draw_icon_label(target, text or TI('Unavailable', '利用不可'), icon=fallback_icon)
        except Exception:
            pass
        return _SAFE_MISSING_OPERATOR


def _draw_help_button(layout, topic_key: str, *, text: str | None = None, icon: str = 'QUESTION'):
    """Draw a Smart Modeling style minimum-width standard QUESTION help button."""
    if layout is None or not str(topic_key or '').strip():
        return None
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
    except Exception:
        pass
    try:
        try:
            op = row.operator('core_suite.show_tool_help', text='', icon='QUESTION', emboss=True)
        except TypeError:
            op = row.operator('core_suite.show_tool_help', text='', icon='QUESTION')
        _safe_set_operator_property(op, 'topic_key', str(topic_key or ''), operator_id='core_suite.show_tool_help')
        return op
    except Exception:
        return None


# =========================================================
# Manual keymap operator IDs
# =========================================================
_GRS_MAIN_OPERATOR_ID = 'transform.smart_grs_transform'
_GRS_MOVE_OPERATOR_ID = 'transform.smart_grs_move'
_GRS_ROTATE_OPERATOR_ID = 'transform.smart_grs_rotate'
_GRS_SCALE_OPERATOR_ID = 'transform.smart_grs_scale'
_ISLAND_TOGGLE_OPERATOR_ID = 'mesh.smart_island_transform_toggle'
_ISLAND_MOVE_OPERATOR_ID = 'mesh.smart_island_move'
_ISLAND_ROTATE_OPERATOR_ID = 'mesh.smart_island_rotate'
_ISLAND_SCALE_OPERATOR_ID = 'mesh.smart_island_scale'
_COPY_TEXT_OPERATOR_ID = 'core_suite.copy_text'

_GRS_FRONT_POST_PIXEL_LAYER_POLICY_KEY = "JELARARAGI_VIEW3D_POST_PIXEL_LAYER_POLICY_V2"
_GRS_FRONT_POST_PIXEL_REPLAY_ACTIVE_KEY = "JELARARAGI_SMART_OVERLAY_FRONT_REPLAY_ACTIVE_V1"
_GRS_FRONT_POST_PIXEL_REPLAY_CONTEXT_KEY = "JELARARAGI_SMART_OVERLAY_FRONT_REPLAY_CONTEXT_V1"
_GRS_FRONT_POST_PIXEL_LAYER_OWNER = "smart_transform_suite.smart_grs_hud"
_GRS_FRONT_POST_PIXEL_LAYER_OWNER_TOKEN = object()
_GRS_ACTIVE_MODAL = None

_LAST_DRAW_STATUS = {
    'proportional': False,
}


def _grs_set_active_modal(operator=None) -> None:
    global _GRS_ACTIVE_MODAL
    _GRS_ACTIVE_MODAL = operator


def _grs_overlay_front_replay_active() -> bool:
    try:
        return bool(bpy.app.driver_namespace.get(_GRS_FRONT_POST_PIXEL_REPLAY_ACTIVE_KEY, False))
    except Exception:
        return False


def _grs_rehook_active_post_pixel_handlers() -> bool:
    operator = _GRS_ACTIVE_MODAL
    if operator is None or not bool(getattr(operator, '_in_modal', False)):
        return False
    callback = getattr(operator, '_rehook_post_pixel_handlers_after_overlay', None)
    if not callable(callback):
        return False
    try:
        return bool(callback())
    except Exception:
        return False


def _grs_release_active_post_pixel_handlers() -> bool:
    operator = _GRS_ACTIVE_MODAL
    if operator is None or not bool(getattr(operator, '_in_modal', False)):
        return False
    callback = getattr(operator, '_ensure_independent_post_pixel_handlers', None)
    if not callable(callback):
        return False
    try:
        return bool(callback())
    except Exception:
        return False


def _grs_publish_front_post_pixel_layer_policy() -> bool:
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_GRS_FRONT_POST_PIXEL_LAYER_POLICY_KEY)
        if registry is None:
            registry = {}
            namespace[_GRS_FRONT_POST_PIXEL_LAYER_POLICY_KEY] = registry
        elif not isinstance(registry, dict):
            return False
        registry[_GRS_FRONT_POST_PIXEL_LAYER_OWNER] = {
            'owner': _GRS_FRONT_POST_PIXEL_LAYER_OWNER,
            'owner_token': _GRS_FRONT_POST_PIXEL_LAYER_OWNER_TOKEN,
            'space': 'SpaceView3D',
            'region': 'WINDOW',
            'stage': 'POST_PIXEL',
            'layer': 12000,
            'role': 'front_transform_hud',
            'rehook_callback': _grs_rehook_active_post_pixel_handlers,
            'release_callback': _grs_release_active_post_pixel_handlers,
            'registration_order_independent': True,
        }
        return True
    except Exception:
        return False


def _grs_clear_front_post_pixel_layer_policy() -> None:
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_GRS_FRONT_POST_PIXEL_LAYER_POLICY_KEY)
        if not isinstance(registry, dict):
            return
        record = registry.get(_GRS_FRONT_POST_PIXEL_LAYER_OWNER)
        if isinstance(record, dict) and record.get('owner_token') is _GRS_FRONT_POST_PIXEL_LAYER_OWNER_TOKEN:
            registry.pop(_GRS_FRONT_POST_PIXEL_LAYER_OWNER, None)
        if not registry and namespace.get(_GRS_FRONT_POST_PIXEL_LAYER_POLICY_KEY) is registry:
            namespace.pop(_GRS_FRONT_POST_PIXEL_LAYER_POLICY_KEY, None)
    except Exception:
        pass

# Smart G-R-S deliberately does not create, remove, enable, disable, repair, or
# prioritize any G / R / S keymap item.  The wrapper operators below exist only
# as manual registration targets.  If the user does not assign them in Blender's
# Keymap preferences, Blender's native transform operators remain untouched.

# =========================================================
# UI Drawing Function (Called from preferences.py)
# =========================================================
def _draw_copy_line(parent, label, text_value):
    col = parent.column(align=True)
    row = col.split(factor=0.72, align=True)
    _draw_icon_label(row, label, icon='COPYDOWN', custom_icon='copy_id')
    col.label(text=str(text_value), translate=False)
    try:
        op = row.operator(_COPY_TEXT_OPERATOR_ID, text=TI('Copy', 'コピー'))
        _safe_set_operator_property(op, 'text', str(text_value), operator_id=_COPY_TEXT_OPERATOR_ID)
        _safe_set_operator_property(op, 'report_label', str(label), operator_id=_COPY_TEXT_OPERATOR_ID)
    except Exception:
        pass





def _draw_child_panel_group(layout, panel_id: str, label: str, *, icon: str = 'NONE', topic_key: str = '', default_open: bool = True, state_owner=None, state_prop: str = ''):
    """Draw a child group exclusively through Blender's native panel API."""
    if layout is None:
        return None

    panel_id = str(panel_id or '').strip() or 'sts_grs_child_section'
    icon_name = str(icon or 'NONE') or 'NONE'
    state_prop = str(state_prop or '').strip()
    try:
        opened = bool(getattr(state_owner, state_prop, bool(default_open))) if state_owner is not None and state_prop and hasattr(state_owner, state_prop) else bool(default_open)
    except Exception:
        opened = bool(default_open)

    header = None
    body = None
    panel_created = False
    panel_prop_fn = getattr(layout, 'panel_prop', None)
    if callable(panel_prop_fn) and state_owner is not None and state_prop and hasattr(state_owner, state_prop):
        try:
            header, body = panel_prop_fn(state_owner, state_prop)
            panel_created = True
        except Exception:
            header = None
            body = None
    if not panel_created:
        panel_fn = getattr(layout, 'panel', None)
        if not callable(panel_fn):
            return None
        try:
            header, body = panel_fn(panel_id, default_closed=not bool(opened))
        except Exception:
            return None

    if header is not None:
        try:
            header.use_property_split = False
            header.use_property_decorate = False
        except Exception:
            pass
        _draw_icon_label(header, str(label or ''), icon=icon_name)
        if topic_key:
            _draw_help_button(header, topic_key, icon='QUESTION')

    if body is None:
        return None
    try:
        body.use_property_split = False
        body.use_property_decorate = False
    except Exception:
        pass
    return body


def _draw_grs_hud_snapping_section(box_main, prefs):
    box_hud = _draw_child_panel_group(box_main, 'sts_grs_snapping_proportional', TI('Snapping / Proportional', 'スナップ / プロポーショナル'), icon='SNAP_ON', topic_key='grs_snapping_proportional', state_owner=prefs, state_prop='show_grs_child_snapping_proportional')
    if box_hud is None:
        return

    col = box_hud.column(align=True)
    col.label(text=T("Snap Steps"))
    row = col.column(align=True)
    row.prop(prefs, "snap_move_grid_step", text=TI('Move', '移動'))
    row.prop(prefs, "snap_rotate_step_deg", text=TI('Rotate', '回転'))
    row.prop(prefs, "snap_scale_step", text=TI('Scale', 'スケール'))

    col = box_hud.column(align=True)
    col.label(text=T("Proportional (Object Mode)"))
    col.prop(prefs, "object_prop_basis", text=TI('Basis', '基準'))
    col.prop(prefs, "prop_falloff_profile", text=TI('Falloff', '減衰'))


def _draw_grs_sensitivity_section(box_main, prefs):
    box_sens = _draw_child_panel_group(box_main, 'sts_grs_drag_sensitivity', T("Transform Drag Sensitivity"), icon='DRIVER_DISTANCE', topic_key='grs_sensitivity', state_owner=prefs, state_prop='show_grs_child_drag_sensitivity')
    if box_sens is None:
        return
    row_reset = box_sens.row(align=True)
    _safe_operator(row_reset, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='GRS_SENSITIVITY')

    col = box_sens.column(align=True)
    row = col.row(align=True)
    row.label(text=T("Move (G) Sensitivity"))
    row.prop(prefs, "g_normal", text=TI("Normal", "通常"), translate=False)
    row.prop(prefs, "g_shift", text=TI("Shift", "Shift"), translate=False)

    row = col.row(align=True)
    row.label(text=T("Rotate (R) Sensitivity"))
    row.prop(prefs, "r_normal", text=TI("Normal", "通常"), translate=False)
    row.prop(prefs, "r_shift", text=TI("Shift", "Shift"), translate=False)

    row = col.row(align=True)
    row.label(text=T("Scale (S) Sensitivity"))
    row.prop(prefs, "s_normal", text=TI("Normal", "通常"), translate=False)
    row.prop(prefs, "s_shift", text=TI("Shift", "Shift"), translate=False)


def draw_sensitivity_preferences(prefs, layout):
    if prefs is None or layout is None:
        return
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    _draw_grs_sensitivity_section(layout, prefs)


def _draw_grs_scale_behavior_section(box_main, prefs):
    box_scale = _draw_child_panel_group(box_main, 'sts_grs_scale_behavior', T("Scale Behavior"), icon='FULLSCREEN_ENTER', topic_key='grs_scale_behavior', state_owner=prefs, state_prop='show_grs_child_scale_behavior')
    if box_scale is None:
        return
    box_scale.prop(prefs, "disallow_negative_scale", text=TI('Disallow Negative Scale', 'マイナススケール禁止'))


def _draw_grs_proportional_section(box_main, prefs, *, show_header: bool = True):
    _LAST_DRAW_STATUS['proportional'] = True

    box_prop = box_main.box() if show_header else box_main
    if show_header:
        sp_prop = box_prop.split(factor=0.5, align=False)
        sp_prop.label(text=T("Proportional Editing"))
        rr_prop = sp_prop.row(align=True)
        rr_prop.alignment = 'RIGHT'
        _safe_operator(rr_prop, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='GRS_PROPORTIONAL')
        _draw_help_button(rr_prop, 'proportional_editing', icon='QUESTION')
    else:
        rr_prop = box_prop.row(align=True)
        _safe_operator(rr_prop, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='GRS_PROPORTIONAL')

    box_cursor_tool = _draw_child_panel_group(box_prop, 'sts_grs_proportional_cursor', TI('Adjust Radius with Cursor', 'プロポーション半径調整'), icon='CURSOR', topic_key='proportional_editing', state_owner=prefs, state_prop='show_grs_child_proportional_cursor')
    if box_cursor_tool is None:
        return
    row_run = box_cursor_tool.row(align=True)
    try:
        row_run.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        pass
    _safe_operator(row_run, 'view3d.proportional_size_cursor', text=TI('Run', '実行'), icon='PLAY')
    row_run.prop(prefs, "show_orange_circle", toggle=True, text=T("Influence Circle"))

    row_line = box_cursor_tool.row(align=True)
    row_line.prop(prefs, "circle_line_width", text=T("Line Width (px)"))

    row_color = box_cursor_tool.row(align=True)
    row_color.prop(prefs, "circle_color", text=T("Circle Color"))

    box_prop_keys = _draw_child_panel_group(box_prop, 'sts_grs_proportional_adjust', TI('Smart G-R-S Proportional Adjust', 'Smart G-R-S のプロポーション調整'), icon='DRIVER_DISTANCE', topic_key='proportional_editing', state_owner=prefs, state_prop='show_grs_child_proportional_adjust')
    if box_prop_keys is None:
        return
    box_prop_keys.prop(prefs, "enable_prop_cursor_lock", toggle=True, text=T("Cursor Lock"))


def _draw_grs_axis_section(box_main, prefs):
    box_axis = _draw_child_panel_group(box_main, 'sts_grs_axis_constraint_line', T("Axis Constraint Line"), icon='ORIENTATION_GIMBAL', topic_key='grs_axis_constraint_line', state_owner=prefs, state_prop='show_grs_child_axis_constraint_line')
    if box_axis is None:
        return
    rr_axis = box_axis.row(align=True)
    _safe_operator(rr_axis, "view3d.csdt_reset_settings", text=T("Reset"), icon='FILE_REFRESH', category='GRS_AXIS')

    cola = box_axis.column(align=True)
    cola.prop(prefs, "enable_middle_mouse_plane", text=TI('Middle Mouse: Plane Constraints', '中ボタンで平面拘束を許可'))
    cola.prop(prefs, "draw_axis_lines_in_front", text=T("Draw Lines in Front (X-Ray)"))

    row_width = cola.row(align=True)
    row_width.prop(prefs, "axis_line_width", text=TI('Width', '太さ'))
    row_width.prop(prefs, "axis_line_width_active", text=TI('Active', '選択中'))

    row1 = cola.row(align=True)
    row1.prop(prefs, "axis_color_x", text=T("X"))
    row1.prop(prefs, "axis_color_y", text=T("Y"))
    row1.prop(prefs, "axis_color_z", text=T("Z"))

    row2 = cola.row(align=True)
    row2.prop(prefs, "axis_color_dark_x", text=T("Dark"))
    row2.prop(prefs, "axis_color_dark_y", text=T("Dark"))
    row2.prop(prefs, "axis_color_dark_z", text=T("Dark"))


def draw_preferences(prefs, layout, *, show_header: bool = True):
    _LAST_DRAW_STATUS['proportional'] = False

    layout.use_property_split = False
    layout.use_property_decorate = False

    if show_header:
        box_main = layout.box()
        row_main_head = box_main.row(align=True)
        _draw_icon_label(row_main_head, T("Smart G-R-S Transform"), icon='CON_TRANSLIKE')
        _draw_help_button(row_main_head, 'smart_grs', icon='QUESTION')
    else:
        box_main = layout

    for section in (
        _draw_grs_hud_snapping_section,
        _draw_grs_scale_behavior_section,
        _draw_grs_axis_section,
    ):
        try:
            section(box_main, prefs)
        except Exception:
            pass


def was_proportional_drawn_last_call():
    return bool(_LAST_DRAW_STATUS.get('proportional', False))


def draw_proportional_editing_preferences(prefs, layout, *, show_header: bool = True):
    if prefs is None or layout is None:
        return

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    _draw_grs_proportional_section(layout, prefs, show_header=show_header)


def draw_hud_numeric_input_preferences(prefs, layout, *, show_header: bool = True):
    if prefs is None or layout is None:
        return

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    if show_header:
        box_hud = layout.box()
        row_hud_head = box_hud.row(align=True)
        _draw_icon_label(row_hud_head, TI('HUD / Numeric Input', 'HUD / 数値入力'), icon='FONT_DATA')
        _draw_help_button(row_hud_head, 'hud_numeric_input', icon='QUESTION')
    else:
        box_hud = layout

    row_top = box_hud.row(align=True)
    row_top.prop(prefs, "hud_enabled", toggle=True, text=T("HUD"))
    row_top.prop(prefs, "hud_show_help_by_default", toggle=True, text=T("Show Help"))

    box_hud.prop(prefs, "hud_anchor_mode", text=TI('Anchor', '基準'))

    col_hud = box_hud.column(align=True)
    col_hud.prop(prefs, "hud_offset_x", text=T("Offset X (px)"))
    col_hud.prop(prefs, "hud_offset_y", text=T("Offset Y (px)"))
    col_hud.prop(prefs, "hud_font_size", text=T("Font Size"))
    col_hud.prop(prefs, "hud_text_color", text=T("Text Color"))


# =========================================================
# Helpers
# =========================================================
def collect_edit_targets(context):
    if hasattr(context, "objects_in_mode_unique_data"):
        objs = list(context.objects_in_mode_unique_data)
    elif hasattr(context, "objects_in_mode"):
        objs = list(context.objects_in_mode)
    else:
        objs = [context.active_object] if context.active_object else []
    return [o for o in objs if o and o.type == 'MESH' and o.mode == 'EDIT']

def collect_edit_selected_verts(bm):
    # Backward-compatible helper.  Callers should consume the returned BMVerts
    # immediately; modal state must store vertex indices/coordinate copies instead
    # because Blender may invalidate BMVert references after selection/mode updates.
    sel = set()
    try:
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
    except Exception:
        pass
    try:
        for v in bm.verts:
            try:
                if v.select:
                    sel.add(v)
            except ReferenceError:
                continue
    except Exception:
        pass
    try:
        for e in bm.edges:
            try:
                if e.select:
                    sel.update(e.verts)
            except ReferenceError:
                continue
    except Exception:
        pass
    try:
        for f in bm.faces:
            try:
                if f.select:
                    sel.update(f.verts)
            except ReferenceError:
                continue
    except Exception:
        pass
    return sel


def collect_edit_selected_vert_indices(bm):
    """Return selected mesh vertex indices without leaking live BMVert refs."""
    indices = set()
    try:
        bm.verts.ensure_lookup_table(); bm.edges.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        bm.verts.index_update()
    except Exception:
        pass
    try:
        for v in bm.verts:
            try:
                if v.select:
                    indices.add(int(v.index))
            except ReferenceError:
                continue
    except Exception:
        pass
    try:
        for e in bm.edges:
            try:
                if e.select:
                    for v in e.verts:
                        try:
                            indices.add(int(v.index))
                        except ReferenceError:
                            pass
            except ReferenceError:
                continue
    except Exception:
        pass
    try:
        for f in bm.faces:
            try:
                if f.select:
                    for v in f.verts:
                        try:
                            indices.add(int(v.index))
                        except ReferenceError:
                            pass
            except ReferenceError:
                continue
    except Exception:
        pass
    return indices


def collect_edit_lattice_targets(context):
    objs = []
    try:
        raw = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
        if raw:
            objs = [o for o in raw if o and getattr(o, 'type', None) == 'LATTICE']
    except Exception:
        objs = []
    if not objs:
        obj = getattr(context, 'active_object', None)
        if obj is not None and getattr(obj, 'type', None) == 'LATTICE':
            objs = [obj]
    return objs


def _lattice_point_is_selected(point) -> bool:
    try:
        if bool(getattr(point, 'select', False)):
            return True
    except Exception:
        pass
    for attr in ('select_u', 'select_v', 'select_w'):
        try:
            if bool(getattr(point, attr, False)):
                return True
        except Exception:
            pass
    return False


def collect_edit_lattice_selected_points(obj):
    try:
        return {i for i, point in enumerate(getattr(obj.data, 'points', [])) if _lattice_point_is_selected(point)}
    except Exception:
        return set()


def _collect_objects_in_mode(context, types=None):
    try:
        raw = getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None)
        objs = list(raw) if raw else []
    except Exception:
        objs = []
    if not objs:
        try:
            obj = getattr(context, 'active_object', None)
            objs = [obj] if obj else []
        except Exception:
            objs = []
    if types:
        types = set(types)
        objs = [o for o in objs if o is not None and getattr(o, 'type', None) in types]
    return objs


def collect_edit_curve_targets(context):
    return [o for o in _collect_objects_in_mode(context, {'CURVE', 'SURFACE'}) if getattr(o, 'mode', None) == 'EDIT']


def collect_edit_armature_targets(context):
    return [o for o in _collect_objects_in_mode(context, {'ARMATURE'}) if getattr(o, 'mode', None) == 'EDIT']


def collect_pose_targets(context):
    return [o for o in _collect_objects_in_mode(context, {'ARMATURE'}) if getattr(o, 'mode', None) == 'POSE']


def collect_edit_metaball_targets(context):
    return [o for o in _collect_objects_in_mode(context, {'META'}) if getattr(o, 'mode', None) == 'EDIT']


def _grs_context_is_object_like_transform(context) -> bool:
    try:
        mode = str(getattr(context, 'mode', '') or '')
        if mode == 'OBJECT':
            return True
        return mode in {
            'SCULPT', 'PAINT_WEIGHT', 'PAINT_VERTEX', 'PAINT_TEXTURE',
            'PAINT_GPENCIL', 'SCULPT_GPENCIL', 'WEIGHT_GPENCIL',
        }
    except Exception:
        return False


def _curve_point_xyz(point):
    try:
        co = getattr(point, 'co')
        return mathutils.Vector((float(co.x), float(co.y), float(co.z)))
    except Exception:
        return mathutils.Vector((0.0, 0.0, 0.0))


def _curve_point_w(point):
    try:
        return float(getattr(getattr(point, 'co'), 'w'))
    except Exception:
        try:
            return float(point.co[3])
        except Exception:
            return 1.0


def _curve_component_items(obj, selected_only=True):
    items = []
    try:
        splines = getattr(getattr(obj, 'data', None), 'splines', [])
        for si, spline in enumerate(splines):
            try:
                for pi, bp in enumerate(getattr(spline, 'bezier_points', [])):
                    cp_selected = bool(getattr(bp, 'select_control_point', False))
                    if cp_selected or not selected_only:
                        for attr in ('co', 'handle_left', 'handle_right'):
                            try:
                                selected = cp_selected or bool(getattr(bp, 'select_left_handle' if attr == 'handle_left' else 'select_right_handle' if attr == 'handle_right' else 'select_control_point', False))
                                items.append((('BEZIER', si, pi, attr, 1.0), mathutils.Vector(getattr(bp, attr)).copy(), bool(selected)))
                            except Exception:
                                pass
                    else:
                        if bool(getattr(bp, 'select_left_handle', False)):
                            items.append((('BEZIER', si, pi, 'handle_left', 1.0), mathutils.Vector(bp.handle_left).copy(), True))
                        if bool(getattr(bp, 'select_right_handle', False)):
                            items.append((('BEZIER', si, pi, 'handle_right', 1.0), mathutils.Vector(bp.handle_right).copy(), True))
            except Exception:
                pass
            try:
                for pi, point in enumerate(getattr(spline, 'points', [])):
                    selected = bool(getattr(point, 'select', False))
                    if selected or not selected_only:
                        items.append((('POINT', si, pi, 'co', _curve_point_w(point)), _curve_point_xyz(point), bool(selected)))
            except Exception:
                pass
    except Exception:
        pass
    return items


def collect_edit_curve_selected_components(obj):
    return [(key, co) for key, co, selected in _curve_component_items(obj, selected_only=True) if selected]


def collect_edit_curve_selected_world_points(context):
    points = []
    for obj in collect_edit_curve_targets(context):
        try:
            mat = obj.matrix_world
            for _key, co in collect_edit_curve_selected_components(obj):
                points.append(mat @ co)
        except Exception:
            continue
    return points


def edit_curve_has_selection(context) -> bool:
    try:
        return bool(collect_edit_curve_selected_world_points(context))
    except Exception:
        return False


def _curve_component_set(obj, key, co):
    try:
        kind, si, pi, attr, w = key
        spline = obj.data.splines[int(si)]
        if kind == 'BEZIER':
            bp = spline.bezier_points[int(pi)]
            setattr(bp, attr, mathutils.Vector(co).to_3d())
        elif kind == 'POINT':
            point = spline.points[int(pi)]
            co = mathutils.Vector(co).to_3d()
            point.co = (float(co.x), float(co.y), float(co.z), float(w))
        try:
            obj.data.update_tag()
        except Exception:
            pass
        return True
    except Exception:
        return False


def _edit_bone_selected_parts(bone):
    parts = set()
    try:
        if bool(getattr(bone, 'select', False)):
            parts.update({'head', 'tail'})
    except Exception:
        pass
    try:
        if bool(getattr(bone, 'select_head', False)):
            parts.add('head')
    except Exception:
        pass
    try:
        if bool(getattr(bone, 'select_tail', False)):
            parts.add('tail')
    except Exception:
        pass
    return parts


def collect_edit_armature_selected_parts(obj):
    out = []
    try:
        for bone in getattr(obj.data, 'edit_bones', []):
            parts = _edit_bone_selected_parts(bone)
            for part in sorted(parts):
                try:
                    out.append(((bone.name, part), mathutils.Vector(getattr(bone, part)).copy()))
                except Exception:
                    pass
    except Exception:
        pass
    return out


def collect_edit_armature_selected_world_points(context):
    points = []
    for obj in collect_edit_armature_targets(context):
        try:
            mat = obj.matrix_world
            for _key, co in collect_edit_armature_selected_parts(obj):
                points.append(mat @ co)
        except Exception:
            continue
    return points


def edit_armature_has_selection(context) -> bool:
    try:
        return bool(collect_edit_armature_selected_world_points(context))
    except Exception:
        return False


def collect_pose_selected_bones(obj):
    out = []
    try:
        for pbone in getattr(obj.pose, 'bones', []):
            try:
                bone = getattr(pbone, 'bone', None)
                selected = bool(getattr(pbone, 'select', False))
                if not selected and bone is not None:
                    selected = bool(getattr(bone, 'select', False))
                hidden = bool(getattr(bone, 'hide', False)) if bone is not None else False
                if selected and not hidden:
                    out.append(pbone)
            except Exception:
                continue
    except Exception:
        pass
    return out


def collect_pose_selected_world_points(context):
    points = []
    for obj in collect_pose_targets(context):
        try:
            mat = obj.matrix_world
            for pbone in collect_pose_selected_bones(obj):
                try:
                    points.append(mat @ pbone.matrix.translation)
                except Exception:
                    try:
                        head = mathutils.Vector(getattr(pbone, 'head', (0.0, 0.0, 0.0)))
                        tail = mathutils.Vector(getattr(pbone, 'tail', head))
                        points.append(mat @ ((head + tail) * 0.5))
                    except Exception:
                        pass
        except Exception:
            continue
    return points


def pose_has_selection(context) -> bool:
    try:
        return bool(collect_pose_selected_world_points(context))
    except Exception:
        return False


def collect_edit_metaball_selected_elements(obj):
    out = []
    try:
        for idx, elem in enumerate(getattr(obj.data, 'elements', [])):
            if bool(getattr(elem, 'select', False)):
                out.append((idx, mathutils.Vector(elem.co).copy()))
    except Exception:
        pass
    return out


def edit_metaball_has_selection(context) -> bool:
    try:
        for obj in collect_edit_metaball_targets(context):
            if collect_edit_metaball_selected_elements(obj):
                return True
    except Exception:
        pass
    return False


def _smart_grs_selection_world_points(context):
    points = []
    try:
        mode = str(getattr(context, 'mode', '') or '')
        if mode == 'EDIT_MESH':
            for obj in collect_edit_targets(context):
                try:
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.verts.ensure_lookup_table()
                    mat = obj.matrix_world.copy()
                    for idx in collect_edit_selected_vert_indices(bm):
                        try:
                            if 0 <= int(idx) < len(bm.verts):
                                points.append(mat @ bm.verts[int(idx)].co.copy())
                        except ReferenceError:
                            continue
                        except Exception:
                            continue
                except Exception:
                    continue
        elif mode == 'EDIT_LATTICE':
            for obj in collect_edit_lattice_targets(context):
                mat = obj.matrix_world
                for idx in collect_edit_lattice_selected_points(obj):
                    try:
                        points.append(mat @ mathutils.Vector(obj.data.points[idx].co_deform))
                    except Exception:
                        pass
        elif mode in {'EDIT_CURVE', 'EDIT_SURFACE'}:
            points.extend(collect_edit_curve_selected_world_points(context))
        elif mode == 'EDIT_ARMATURE':
            points.extend(collect_edit_armature_selected_world_points(context))
        elif mode == 'POSE':
            points.extend(collect_pose_selected_world_points(context))
        elif mode == 'EDIT_METABALL':
            for obj in collect_edit_metaball_targets(context):
                mat = obj.matrix_world
                for _idx, co in collect_edit_metaball_selected_elements(obj):
                    points.append(mat @ co)
        else:
            for obj in getattr(context, 'selected_objects', []) or []:
                try:
                    points.append(obj.matrix_world.translation.copy())
                except Exception:
                    pass
    except Exception:
        pass
    return points


def calc_pivot_world_from_selection(context):
    ts = context.scene.tool_settings
    pivot_mode = ts.transform_pivot_point
    cursor = context.scene.cursor.location.copy()
    active_obj = context.active_object

    points = _smart_grs_selection_world_points(context)

    if pivot_mode == 'CURSOR': return cursor
    if pivot_mode == 'ACTIVE_ELEMENT':
        if context.mode == 'EDIT_MESH' and active_obj and active_obj.type == 'MESH' and active_obj.mode == 'EDIT':
            try:
                bm = bmesh.from_edit_mesh(active_obj.data)
                act = bm.select_history.active
                if act:
                    mat = active_obj.matrix_world.copy()
                    if isinstance(act, bmesh.types.BMVert): return mat @ act.co.copy()
                    if isinstance(act, bmesh.types.BMEdge): return mat @ ((act.verts[0].co.copy() + act.verts[1].co.copy()) * 0.5)
                    if isinstance(act, bmesh.types.BMFace):
                        c = mathutils.Vector((0,0,0))
                        verts = list(act.verts)
                        for v in verts: c += v.co.copy()
                        return mat @ (c / max(len(verts), 1))
            except ReferenceError:
                pass
            except Exception:
                pass
        return active_obj.matrix_world.translation.copy() if active_obj else cursor

    if not points: return active_obj.matrix_world.translation.copy() if active_obj else cursor
    if pivot_mode == 'BOUNDING_BOX_CENTER':
        minv = mathutils.Vector((float('inf'),)*3)
        maxv = mathutils.Vector((float('-inf'),)*3)
        for p in points:
            minv.x, minv.y, minv.z = min(minv.x, p.x), min(minv.y, p.y), min(minv.z, p.z)
            maxv.x, maxv.y, maxv.z = max(maxv.x, p.x), max(maxv.y, p.y), max(maxv.z, p.z)
        return (minv + maxv) * 0.5

    acc = sum(points, mathutils.Vector((0,0,0)))
    return acc / max(len(points), 1)

def get_proportional_weight(dist, size, falloff_type, profile='BLENDER'):
    if size <= 0.0 or dist >= size: return 0.0
    x = dist / size
    if falloff_type == 'SMOOTH': w = 1.0 - (3.0 * x**2 - 2.0 * x**3)
    elif falloff_type == 'SPHERE': w = math.sqrt(max(0.0, 1.0 - x**2))
    elif falloff_type == 'ROOT': w = math.sqrt(max(0.0, 1.0 - x))
    elif falloff_type == 'INVERSE_SQUARE': w = 1.0 / (1.0 + (x * 2.0)**2)
    elif falloff_type == 'SHARP': w = (1.0 - x)**2
    elif falloff_type == 'LINEAR': w = 1.0 - x
    elif falloff_type == 'CONSTANT': w = 1.0
    else: w = 1.0 - (3.0 * x**2 - 2.0 * x**3)

    # Extra curve shaping to match other DCC feel.
    try:
        profile = str(profile or 'BLENDER')
    except Exception:
        profile = 'BLENDER'
    if profile == 'MAYA':
        w = pow(max(0.0, min(1.0, w)), 0.70)
    elif profile == 'MAX':
        w = pow(max(0.0, min(1.0, w)), 1.60)

    return max(0.0, min(1.0, w))

def is_prop_enabled(context):
    try:
        mode = str(getattr(context, 'mode', '') or '')
        if mode.startswith('EDIT_'):
            return bool(getattr(context.tool_settings, "use_proportional_edit", False))
        if mode == 'POSE':
            return bool(getattr(context.tool_settings, "use_proportional_edit", False))
        return bool(getattr(context.tool_settings, "use_proportional_edit_objects", False))
    except Exception:
        return False


def _mesh_island_transform_enabled(context) -> bool:
    """Return True when Mesh アイランド変形 should affect Smart G-R-S.

    The master switch is stored outside the .blend file through the central
    always-on settings.  By default the feature is linked to Blender's Transform
    Pivot Point and activates only in メッシュ編集 mode when the pivot is
    Individual Origins / それぞれの基点.  Other pivot modes then remain identical to
    normal Smart Transform.  The linkage can be disabled in the アイランド変形
    settings.
    """
    try:
        if context is None or str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
            return False
        prefs = _prefs(context)
        if prefs is None or not bool(getattr(prefs, 'enable_mesh_island_transform', False)):
            return False
        if bool(getattr(prefs, 'mesh_island_transform_individual_pivot_only', True)):
            pivot = str(getattr(context.scene.tool_settings, 'transform_pivot_point', '') or '')
            return pivot == 'INDIVIDUAL_ORIGINS'
        return True
    except Exception:
        return False


def _mesh_select_mode_from_context(context):
    try:
        mode = tuple(bool(v) for v in getattr(context.tool_settings, 'mesh_select_mode', (True, False, False)))
    except Exception:
        mode = (True, False, False)
    if len(mode) < 3:
        mode = tuple(list(mode) + [False] * (3 - len(mode)))
    return bool(mode[0]), bool(mode[1]), bool(mode[2])


def _mesh_island_record_from_verts(verts):
    verts = list(dict.fromkeys([v for v in verts if v is not None]))
    if not verts:
        return None
    center = mathutils.Vector((0.0, 0.0, 0.0))
    for v in verts:
        center += v.co
    center /= max(1, len(verts))
    try:
        mn = mathutils.Vector((min(v.co.x for v in verts), min(v.co.y for v in verts), min(v.co.z for v in verts)))
        mx = mathutils.Vector((max(v.co.x for v in verts), max(v.co.y for v in verts), max(v.co.z for v in verts)))
        bbox_center = (mn + mx) * 0.5
    except Exception:
        bbox_center = center.copy()
    return {
        'indices': [int(v.index) for v in verts],
        'orig_coords': [v.co.copy() for v in verts],
        'center_local': center.copy(),
        'bbox_center_local': bbox_center.copy(),
    }


def _collect_selected_vertex_mode_mesh_islands_from_bmesh(bm):
    selected_verts = set()
    try:
        for v in bm.verts:
            if getattr(v, 'select', False):
                selected_verts.add(v)
        for e in bm.edges:
            if getattr(e, 'select', False):
                selected_verts.update(e.verts)
        for f in bm.faces:
            if getattr(f, 'select', False):
                selected_verts.update(f.verts)
    except Exception:
        selected_verts = set()

    islands = []
    while selected_verts:
        root = selected_verts.pop()
        verts = [root]
        queue = [root]
        while queue:
            cur = queue.pop(0)
            try:
                edges = list(cur.link_edges)
            except Exception:
                edges = []
            for edge in edges:
                try:
                    other = edge.other_vert(cur)
                except Exception:
                    continue
                if other in selected_verts:
                    selected_verts.remove(other)
                    verts.append(other)
                    queue.append(other)
        record = _mesh_island_record_from_verts(verts)
        if record is not None:
            islands.append(record)
    return islands


def _collect_selected_edge_mode_mesh_islands_from_bmesh(bm):
    """Collect edge-select islands using only selected edge connectivity.

    In Edge select mode, adjacent or coincident vertices must not merge islands
    unless the selected edges themselves form a connected edge path.
    """
    try:
        selected_edges = {e for e in bm.edges if getattr(e, 'select', False)}
    except Exception:
        selected_edges = set()
    islands = []
    remaining = set(selected_edges)
    while remaining:
        root = remaining.pop()
        edges = [root]
        verts = set()
        queue = [root]
        while queue:
            edge = queue.pop(0)
            try:
                edge_verts = list(edge.verts)
            except Exception:
                edge_verts = []
            verts.update(edge_verts)
            for v in edge_verts:
                try:
                    linked_edges = list(v.link_edges)
                except Exception:
                    linked_edges = []
                for linked in linked_edges:
                    if linked in remaining:
                        remaining.remove(linked)
                        edges.append(linked)
                        queue.append(linked)
        record = _mesh_island_record_from_verts(verts)
        if record is not None:
            islands.append(record)

    # Keep rare mixed-state selected vertices transformable, without letting them
    # connect separate selected-edge islands through unselected edges.
    try:
        used_verts = {v for island in islands for idx in island.get('indices', []) for v in [bm.verts[idx]]}
        loose_selected = [v for v in bm.verts if getattr(v, 'select', False) and v not in used_verts]
    except Exception:
        loose_selected = []
    for v in loose_selected:
        record = _mesh_island_record_from_verts([v])
        if record is not None:
            islands.append(record)
    return islands


def _collect_selected_face_mode_mesh_islands_from_bmesh(bm):
    """Collect face-select islands using selected face adjacency only.

    Faces that touch only at vertices remain separate.  Two selected faces are
    grouped only when they are connected through a shared mesh edge.
    """
    try:
        selected_faces = {f for f in bm.faces if getattr(f, 'select', False)}
    except Exception:
        selected_faces = set()
    islands = []
    remaining = set(selected_faces)
    while remaining:
        root = remaining.pop()
        faces = [root]
        verts = set()
        queue = [root]
        while queue:
            face = queue.pop(0)
            try:
                verts.update(face.verts)
                face_edges = list(face.edges)
            except Exception:
                face_edges = []
            for edge in face_edges:
                try:
                    linked_faces = list(edge.link_faces)
                except Exception:
                    linked_faces = []
                for linked in linked_faces:
                    if linked in remaining:
                        remaining.remove(linked)
                        faces.append(linked)
                        queue.append(linked)
        record = _mesh_island_record_from_verts(verts)
        if record is not None:
            islands.append(record)

    # In Face select mode, face islands are authoritative.  Blender may keep
    # the corresponding vertices and edges selected internally; adding those as
    # fallback islands would duplicate the same geometry and merge semantics.
    return islands


def _collect_selected_mesh_islands_from_bmesh(bm, context=None):
    """Collect connected groups for Mesh Island Transform.

    Vertex mode preserves the legacy selected-vertex mesh-edge connectivity.
    Edge mode uses selected edge connectivity only.  Face mode uses selected face
    adjacency through shared edges only, so vertex-only contact never merges face
    islands.
    """
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()
    except Exception:
        pass

    vert_mode, edge_mode, face_mode = _mesh_select_mode_from_context(context)
    try:
        if face_mode:
            face_islands = _collect_selected_face_mode_mesh_islands_from_bmesh(bm)
            if face_islands:
                return face_islands
        if edge_mode:
            edge_islands = _collect_selected_edge_mode_mesh_islands_from_bmesh(bm)
            if edge_islands:
                return edge_islands
    except Exception:
        pass
    return _collect_selected_vertex_mode_mesh_islands_from_bmesh(bm)


def _transform_pivot_is_individual(context) -> bool:
    try:
        return str(getattr(context.scene.tool_settings, 'transform_pivot_point', '') or '') == 'INDIVIDUAL_ORIGINS'
    except Exception:
        return False


def _scene_transform_orientation_type(context) -> str:
    try:
        slot = context.scene.transform_orientation_slots[0]
        value = str(getattr(slot, 'type', '') or 'GLOBAL')
        if value == 'CUSTOM':
            try:
                custom = getattr(slot, 'custom_orientation', None)
                name = str(getattr(custom, 'name', '') or '') if custom is not None else ''
                return name or 'CUSTOM'
            except Exception:
                return 'CUSTOM'
        return value if value else 'GLOBAL'
    except Exception:
        return 'GLOBAL'



def _grs_custom_handles_context(context) -> bool:
    try:
        mode = str(getattr(context, 'mode', '') or '')
        obj = getattr(context, 'active_object', None)
        if _grs_context_is_object_like_transform(context):
            return bool(getattr(context, 'selected_objects', None) or obj)
        if mode == 'EDIT_MESH':
            return obj is not None and getattr(obj, 'type', '') == 'MESH'
        if mode == 'EDIT_LATTICE':
            # Lattice edit mode is handled by Smart G-R-S so Smart Gizmo axis /
            # plane constraints behave the same as mesh edit mode. Delegating
            # this path to Blender native transform drops the Smart Gizmo
            # pending constraint, which is why lattice axis dragging stopped
            # working.
            return obj is not None and getattr(obj, 'type', '') == 'LATTICE'
        if mode in {'EDIT_CURVE', 'EDIT_SURFACE'}:
            # Curves and surfaces now use the same custom Smart G-R-S backend as
            # mesh/lattice edit modes.  The operator already stores and writes
            # selected curve components; keeping this context custom preserves
            # Smart Gizmo axis/plane constraints, circular rotation, positive
            # scale policy, HUD, snap-base editing, and sensitivity parity.
            return obj is not None and getattr(obj, 'type', '') in {'CURVE', 'SURFACE'}
        # Other non-mesh edit/pose contexts are delegated to Blender's native
        # transform operator.  This preserves the standard modal key set for
        # Armature, Metaball, Grease Pencil, Pose, and future edit modes.
    except Exception:
        pass
    return False


def _grs_tool_settings_require_native_transform(context) -> bool:
    try:
        return bool(cu._tool_settings_require_native_transform(context))
    except Exception:
        return False


def _grs_should_delegate_to_native_transform(context) -> bool:
    try:
        if _grs_tool_settings_require_native_transform(context):
            return True
        return not _grs_custom_handles_context(context)
    except Exception:
        return True


def _operator_property_explicitly_set(op, prop_name: str) -> bool:
    try:
        props = getattr(op, 'properties', None)
        checker = getattr(props, 'is_property_set', None)
        if callable(checker):
            return bool(checker(prop_name))
    except Exception:
        pass
    return False


_GRS_NATIVE_PROPS_BY_MODE = {
    'G': (
        'value', 'orient_type', 'orient_matrix', 'orient_matrix_type',
        'constraint_axis', 'mirror', 'use_proportional_edit',
        'proportional_edit_falloff', 'proportional_size',
        'use_proportional_connected', 'use_proportional_projected',
        'snap', 'snap_elements', 'use_snap_project', 'snap_target',
        'use_snap_self', 'use_snap_edit', 'use_snap_nonedit',
        'use_snap_selectable', 'snap_point', 'snap_align', 'snap_normal',
        'gpencil_strokes', 'cursor_transform', 'texture_space',
        'remove_on_cancel', 'use_duplicated_keyframes', 'view2d_edge_pan',
        'release_confirm', 'use_accurate', 'use_automerge_and_split',
        'translate_origin',
    ),
    'R': (
        'value', 'orient_axis', 'orient_type', 'orient_matrix',
        'orient_matrix_type', 'constraint_axis', 'mirror',
        'use_proportional_edit', 'proportional_edit_falloff',
        'proportional_size', 'use_proportional_connected',
        'use_proportional_projected', 'snap', 'snap_elements',
        'use_snap_project', 'snap_target', 'use_snap_self',
        'use_snap_edit', 'use_snap_nonedit', 'use_snap_selectable',
        'snap_point', 'gpencil_strokes', 'center_override',
        'release_confirm', 'use_accurate',
    ),
    'S': (
        'value', 'mouse_dir_constraint', 'orient_type', 'orient_matrix',
        'orient_matrix_type', 'constraint_axis', 'mirror',
        'use_proportional_edit', 'proportional_edit_falloff',
        'proportional_size', 'use_proportional_connected',
        'use_proportional_projected', 'snap', 'snap_elements',
        'use_snap_project', 'snap_target', 'use_snap_self',
        'use_snap_edit', 'use_snap_nonedit', 'use_snap_selectable',
        'snap_point', 'gpencil_strokes', 'texture_space',
        'remove_on_cancel', 'use_duplicated_keyframes', 'center_override',
        'release_confirm', 'use_accurate',
    ),
}


def _collect_native_grs_kwargs(prop_source, mode: str) -> dict:
    if prop_source is None:
        return {}
    mode = str(mode or 'G').upper()
    out = {}
    for name in _GRS_NATIVE_PROPS_BY_MODE.get(mode, _GRS_NATIVE_PROPS_BY_MODE['G']):
        if not hasattr(prop_source, name):
            continue
        if not _operator_property_explicitly_set(prop_source, name):
            continue
        try:
            value = getattr(prop_source, name)
        except Exception:
            continue
        try:
            if name in {'constraint_axis'}:
                value = tuple(bool(v) for v in value)
            elif name in {'value', 'orient_matrix', 'mouse_dir_constraint', 'snap_point', 'snap_normal', 'center_override'}:
                value = tuple(float(v) for v in value)
            elif name == 'snap_elements':
                value = set(value) if not isinstance(value, str) else {value}
        except Exception:
            pass
        out[name] = value
    return out





_GRS_SMART_MODAL_PROP_NAMES = {
    'orient_type', 'orient_matrix_type', 'constraint_axis', 'mirror',
    'use_proportional_edit', 'proportional_edit_falloff', 'proportional_size',
    'use_proportional_connected', 'use_proportional_projected',
    'snap', 'snap_elements', 'use_snap_project', 'snap_target',
    'use_snap_self', 'use_snap_edit', 'use_snap_nonedit',
    'use_snap_selectable', 'snap_point', 'release_confirm', 'use_accurate',
}


def _collect_smart_grs_modal_kwargs(prop_source, mode: str) -> dict:
    kwargs = _collect_native_grs_kwargs(prop_source, mode)
    return {k: v for k, v in kwargs.items() if k in _GRS_SMART_MODAL_PROP_NAMES}


def _grs_force_native_for_operator_props(prop_source, mode: str) -> bool:
    """Return True when a manually configured keymap asks for a native-only path.

    Smart G-R-S handles standard interactive G/R/S replacement for Object,
    Edit Mesh, Edit Lattice, Edit Curve/Surface, Edit Armature, Pose,
    and simple Edit Metaball contexts where its custom data paths are available.  Native-only transform options such as origin
    translation, texture-space transforms, grease-pencil stroke transforms, or
    explicit EXEC-style value payloads are delegated so manual Smart G-R-S
    keymaps remain a safe stand-in for Blender's standard entries.
    """
    if prop_source is None:
        return False
    mode = str(mode or 'G').upper()
    native_only = {
        'cursor_transform', 'texture_space', 'remove_on_cancel',
        'use_duplicated_keyframes', 'view2d_edge_pan',
        'use_automerge_and_split', 'translate_origin', 'gpencil_strokes',
        'snap_align', 'snap_normal', 'mouse_dir_constraint', 'center_override',
    }
    for name in native_only:
        if not hasattr(prop_source, name) or not _operator_property_explicitly_set(prop_source, name):
            continue
        try:
            value = getattr(prop_source, name)
            if isinstance(value, (tuple, list)):
                if any(abs(float(v)) > 1.0e-12 for v in value):
                    return True
            elif bool(value):
                return True
        except Exception:
            return True

    # Direct EXEC-style transform values are native-only.  Interactive keymaps do
    # not set these values; explicit script calls and copied standard keymap
    # entries can.
    if _operator_property_explicitly_set(prop_source, 'value'):
        try:
            value = getattr(prop_source, 'value')
            if mode == 'R':
                return abs(float(value)) > 1.0e-12
            if isinstance(value, (tuple, list)):
                default = (1.0, 1.0, 1.0) if mode == 'S' else (0.0, 0.0, 0.0)
                return any(abs(float(a) - float(b)) > 1.0e-12 for a, b in zip(value, default))
        except Exception:
            return True
    return False

def _invoke_native_grs_transform(mode: str, op_context='INVOKE_DEFAULT', prop_source=None, pending=None, orient=None, context=None):
    mode = str(mode or 'G').upper()
    ctx = context if context is not None else bpy.context
    try:
        affect_only_state = cu._effective_transform_affect_only_state(ctx)
    except Exception:
        affect_only_state = {}
    kwargs = _collect_native_grs_kwargs(prop_source, mode)
    try:
        for _k, _v in (cu._native_transform_context_kwargs(ctx, mode) or {}).items():
            if _k not in kwargs:
                kwargs[_k] = _v
    except Exception:
        pass
    try:
        if isinstance(pending, dict):
            pk = str(pending.get('kind', '') or '').upper()
            pi = int(pending.get('idx', -1))
            if pk == 'AXIS' and pi in (0, 1, 2) and 'constraint_axis' not in kwargs:
                ax = [False, False, False]
                ax[pi] = True
                kwargs['constraint_axis'] = tuple(ax)
            elif pk == 'PLANE' and pi in (0, 1, 2) and 'constraint_axis' not in kwargs:
                ax = [True, True, True]
                ax[pi] = False
                kwargs['constraint_axis'] = tuple(ax)
            if orient is None:
                orient = pending.get('space', None)
    except Exception:
        pass
    try:
        if not cu._pending_requests_free_rotation(mode, pending):
            orient_native = str(orient or '')
            if orient_native == 'WORKPLANE':
                orient_native = 'VIEW'
            if orient_native in {'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT'} and 'orient_type' not in kwargs:
                kwargs['orient_type'] = orient_native
    except Exception:
        pass

    def _call(native_kwargs):
        # The native modal reads ToolSettings during initialization.  Expose the
        # effective per-object-type policy only for that initialization window,
        # then restore the user's top-right Options values immediately.
        with cu._temporary_transform_affect_only_state(bpy.context, affect_only_state):
            if mode == 'R':
                if cu._pending_requests_free_rotation(mode, pending):
                    return bpy.ops.transform.trackball(op_context, **cu._native_trackball_kwargs(native_kwargs))
                return bpy.ops.transform.rotate(op_context, **native_kwargs)
            if mode == 'S':
                return bpy.ops.transform.resize(op_context, **native_kwargs)
            return bpy.ops.transform.translate(op_context, **native_kwargs)

    try:
        return _call(kwargs)
    except Exception:
        # A manually registered Smart G-R-S keymap may contain a property that is
        # valid for one Blender build but not another.  Fall back without keyword
        # properties instead of cancelling the user's standard transform path.
        try:
            return _call({})
        except Exception:
            return {'CANCELLED'}


def _pop_pending_grs_native_delegate_payload():
    pending = None
    orient = None
    pending_ctx = None
    try:
        dn = getattr(bpy.app, 'driver_namespace', None)
        if isinstance(dn, dict):
            pending = dn.pop('STS_PENDING_GRS', None)
            pending_ctx = dn.pop('STS_PENDING_GRS_CTX', None)
            orient = dn.pop('STS_PENDING_GRS_ORIENT_SPACE', None)
            if orient is None:
                orient = dn.pop('STS_GRS_GIZMO_ORIENT_SPACE', None)
            else:
                dn.pop('STS_GRS_GIZMO_ORIENT_SPACE', None)
            for key in (
                'STS_GRS_FROM_SMART_GIZMO', 'STS_GRS_GIZMO_HIT_ID',
                'STS_GRS_GIZMO_ORIENT_AXES', 'STS_PENDING_GRS_ORIENT_AXES',
                'STS_PENDING_GRS_ORIENT_MATRIX', 'STS_PENDING_GRS_PIVOT',
                'STS_PENDING_GRS_ORIENT_DYNAMIC_VIEW', 'STS_GRS_GIZMO_DYNAMIC_VIEW',
                'STS_PENDING_GRS_ORIENT_VIEW_SIGNATURE',
                'STS_GRS_FORCE_SCREEN_COORDINATE_ROTATION',
                'STS_GRS_FORCE_CIRCULAR_ROTATION', 'STS_GRS_FORCE_POSITIVE_SCALE',
                'STS_GRS_FORCE_ALLOW_NEGATIVE_SCALE', 'STS_GRS_FORCE_FREE_ROTATION',
            ):
                dn.pop(key, None)
    except Exception:
        pending = None if pending is None else pending
    return pending, orient, pending_ctx


# =========================================================
# Main Operator
# =========================================================
class TRANSFORM_OT_smart_grs_transform(bpy.types.Operator):
    bl_idname = "transform.smart_grs_transform"
    bl_label = "Smart G-R-S Transform"
    bl_description = "Start the add-on's Smart Move, Rotate, or Scale workflow with HUD, snapping helpers, axis memory, and numeric input"
    bl_options = {'UNDO', 'BLOCKING'}
    bl_undo_group = 'Smart Transform Suite'

    mode: bpy.props.StringProperty(
        name=TI('Transform Mode', '変形モード'),
        description=TI('Smart G-R-S mode to start: G for move, R for rotate, or S for scale.', '開始する Smart G-R-S のモードです。G は移動、R は回転、S は拡大縮小です。'),
        default="G",
    )

    @classmethod
    def poll(cls, context):
        return _grs_context_poll(context)

    def _reset_constraint(self):
        self.constraint_kind = 'NONE'
        self.constraint_idx = -1
        self.constraint_space = 'GLOBAL'
        # Keep any fixed Smart Gizmo/direct-drag orientation basis.  The basis is
        # only used when its stored coordinate-system name matches
        # self.constraint_space, so clearing it here breaks immediate-select
        # -> axis-constrained drags without improving correctness.

    def _effective_constraint_space(self, context=None):
        """Return the coordinate system that constraints must use right now.

        VIEW / WORKPLANE are not a fixed gizmo matrix.  They are the current
        viewport orientation.  A Smart Gizmo handle can still pass the selected
        axis kind (X/Y/Z/XY/YZ/XZ), but the axis *angle* has to be re-resolved
        from the live RegionView3D whenever the view changes.
        """
        try:
            space = str(getattr(self, 'constraint_space', '') or '')
        except Exception:
            space = ''
        try:
            gizmo_space = str(getattr(self, '_smart_gizmo_orient_space', '') or '')
        except Exception:
            gizmo_space = ''
        try:
            scene_space = _scene_transform_orientation_type(context) if context is not None else ''
        except Exception:
            scene_space = ''

        if gizmo_space in {'VIEW', 'WORKPLANE'}:
            # Smart Gizmo / immediate-select drags can enter Smart G-R-S with a
            # stale pending space of GLOBAL.  If the live scene orientation is
            # still VIEW/WORKPLANE, force the constraint space back to the view
            # coordinate system and let _get_orient_matrix() rebuild its basis
            # from the current RegionView3D.
            if space in {'', 'GLOBAL', 'VIEW', 'WORKPLANE'} or scene_space in {'VIEW', 'WORKPLANE'} or bool(getattr(self, '_smart_gizmo_dynamic_view_orientation', False)):
                space = gizmo_space

        if space in {'VIEW', 'WORKPLANE'}:
            try:
                self.constraint_space = space
            except Exception:
                pass
            return space

        if not space:
            space = scene_space or 'GLOBAL'
        return space or 'GLOBAL'

    def _get_constraint_axis(self, context, idx):
        m = self._get_orient_matrix(context, self._effective_constraint_space(context))
        try:
            axis = m.col[idx].normalized()
            if axis.length > 1.0e-8:
                return axis
        except Exception:
            pass
        return (mathutils.Vector((1,0,0)), mathutils.Vector((0,1,0)), mathutils.Vector((0,0,1)))[idx]

    def _handle_axis_key(self, event, context):
        # Do not clear the captured coordinate-system basis here.  Axis keys must
        # constrain against the visible/last Smart Gizmo axes when the selected
        # scene coordinate system has not changed.
        idx = {'X': 0, 'Y': 1, 'Z': 2}[event.type]
        if self.constraint_idx == idx:
            order = self._supported_orient_modes(context) + ['NONE']
            cur = self.constraint_space
            try:
                n = order[(order.index(cur) + 1) % len(order)]
            except Exception:
                n = 'LOCAL'
            if n == 'NONE':
                self._reset_constraint()
                return
            self.constraint_space = n
        else:
            self.constraint_idx = idx
            self.constraint_space = _scene_transform_orientation_type(context)
        
        if self._event_shift_active(event):
            self.constraint_kind = 'PLANE'
        else:
            self.constraint_kind = 'AXIS'

        try:
            _mx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', None))
            _my = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', None))
            _prefs_axis = _prefs(context)
            if getattr(self, 'mode', '') == 'R':
                if self._use_screen_coordinate_rotation(_prefs_axis):
                    self._reset_screen_rotation_baseline(_mx, _my)
                else:
                    _sens_axis = self._get_sens(_prefs_axis, 'R', self._event_shift_active(event))
                    self._reset_circular_rotation_baseline(context, _mx, _my, _sens_axis)
            elif getattr(self, 'mode', '') == 'S':
                _sens_axis = self._get_sens(_prefs_axis, 'S', self._event_shift_active(event))
                self._reset_scale_baseline_from_current(context, _mx, _my, _sens_axis)
        except Exception:
            pass


    def _restore_invocation_tool_settings(self, context):
        restore = getattr(self, '_tool_settings_restore', None)
        if not restore:
            self._tool_settings_restore = []
            return
        try:
            ts = context.scene.tool_settings
        except Exception:
            self._tool_settings_restore = []
            return
        for attr, value in reversed(restore):
            try:
                setattr(ts, attr, value)
            except Exception:
                pass
        self._tool_settings_restore = []

    def _set_tool_setting_for_invocation(self, context, attr: str, value):
        try:
            ts = context.scene.tool_settings
            if not hasattr(ts, attr):
                return
            if not hasattr(self, '_tool_settings_restore'):
                self._tool_settings_restore = []
            if not any(item[0] == attr for item in self._tool_settings_restore):
                try:
                    current = getattr(ts, attr)
                    if isinstance(current, set):
                        current = set(current)
                    self._tool_settings_restore.append((attr, current))
                except Exception:
                    pass
            setattr(ts, attr, value)
        except Exception:
            pass

    def _apply_invocation_operator_overrides(self, context):
        self._tool_settings_restore = []
        self._release_confirm = bool(getattr(self, 'release_confirm', False)) if _operator_property_explicitly_set(self, 'release_confirm') else False
        self._invoke_use_accurate = bool(getattr(self, 'use_accurate', False)) if _operator_property_explicitly_set(self, 'use_accurate') else False

        # Standard transform keymap properties are honored only when the manual
        # keymap explicitly sets them.  Plain manual G/R/S registrations keep
        # Blender's current Tool Settings unchanged.
        if _operator_property_explicitly_set(self, 'use_proportional_edit'):
            self._set_tool_setting_for_invocation(context, 'use_proportional_edit', bool(getattr(self, 'use_proportional_edit', False)))
        if _operator_property_explicitly_set(self, 'proportional_edit_falloff'):
            self._set_tool_setting_for_invocation(context, 'proportional_edit_falloff', getattr(self, 'proportional_edit_falloff', 'SMOOTH'))
        if _operator_property_explicitly_set(self, 'proportional_size'):
            self._set_tool_setting_for_invocation(context, 'proportional_size', float(getattr(self, 'proportional_size', 1.0)))
        if _operator_property_explicitly_set(self, 'use_proportional_connected'):
            self._set_tool_setting_for_invocation(context, 'use_proportional_connected', bool(getattr(self, 'use_proportional_connected', False)))
        if _operator_property_explicitly_set(self, 'use_proportional_projected'):
            self._set_tool_setting_for_invocation(context, 'use_proportional_projected', bool(getattr(self, 'use_proportional_projected', False)))
        if _operator_property_explicitly_set(self, 'snap'):
            self._set_tool_setting_for_invocation(context, 'use_snap', bool(getattr(self, 'snap', False)))
        if _operator_property_explicitly_set(self, 'snap_elements'):
            try:
                elems = set(getattr(self, 'snap_elements', set()) or set())
                if elems:
                    self._set_tool_setting_for_invocation(context, 'snap_elements', elems)
            except Exception:
                pass
        if _operator_property_explicitly_set(self, 'snap_target'):
            self._set_tool_setting_for_invocation(context, 'snap_target', getattr(self, 'snap_target', 'CLOSEST'))
        for op_attr, ts_attr in (
            ('use_snap_project', 'use_snap_project'),
            ('use_snap_self', 'use_snap_self'),
            ('use_snap_edit', 'use_snap_edit'),
            ('use_snap_nonedit', 'use_snap_nonedit'),
            ('use_snap_selectable', 'use_snap_selectable'),
        ):
            if _operator_property_explicitly_set(self, op_attr):
                self._set_tool_setting_for_invocation(context, ts_attr, bool(getattr(self, op_attr, False)))

        if _operator_property_explicitly_set(self, 'orient_matrix_type'):
            try:
                self.constraint_space = str(getattr(self, 'orient_matrix_type', self.constraint_space) or self.constraint_space)
            except Exception:
                pass
        elif _operator_property_explicitly_set(self, 'orient_type'):
            try:
                self.constraint_space = str(getattr(self, 'orient_type', self.constraint_space) or self.constraint_space)
            except Exception:
                pass

        if _operator_property_explicitly_set(self, 'constraint_axis'):
            try:
                axes = tuple(bool(v) for v in getattr(self, 'constraint_axis', (False, False, False)))
                count = sum(1 for v in axes if v)
                if count == 1:
                    self.constraint_kind = 'AXIS'
                    self.constraint_idx = axes.index(True)
                elif count == 2:
                    self.constraint_kind = 'PLANE'
                    self.constraint_idx = axes.index(False)
                else:
                    self._reset_constraint()
            except Exception:
                pass

    # ---------------------------------------------------------
    # Orientation helpers (Global/Local/View/Cursor/Normal)
    # ---------------------------------------------------------
    def _supported_orient_modes(self, context):
        modes = ['GLOBAL', 'LOCAL', 'VIEW', 'CURSOR']
        if context.mode == 'EDIT_MESH':
            modes.insert(2, 'NORMAL')
        return modes

    def _scene_transform_orientation_mode(self, context) -> str:
        try:
            slot = context.scene.transform_orientation_slots[0]
            mode = str(getattr(slot, 'type', '') or '')
            if mode == 'CUSTOM':
                try:
                    custom = getattr(slot, 'custom_orientation', None)
                    name = str(getattr(custom, 'name', '') or '') if custom is not None else ''
                    return name or 'CUSTOM'
                except Exception:
                    return 'CUSTOM'
            return mode or 'GLOBAL'
        except Exception:
            return 'GLOBAL'

    def _view_basis_from_rv3d(self, rv3d):
        """Return current VIEW/WORKPLANE basis in world space.

        ``view_rotation.to_matrix()`` and the rotational part of
        ``view_matrix.inverted()`` are equivalent in a normal View3D.  Blender
        5.1 Quad View can keep a stale/shared ``view_matrix`` on its four
        RegionView3D objects while their per-pane ``view_rotation`` values are
        correct.  Prefer the quaternion so VIEW constraints always use the pane
        where the Smart G-R-S drag started and cannot jump to another pane's axes.
        """
        if rv3d is None:
            return None
        try:
            q = getattr(rv3d, 'view_rotation', None)
            if q is not None:
                mat = q.to_matrix()
                mat = mat.to_3x3() if hasattr(mat, 'to_3x3') else mat
                try:
                    return mat.normalized()
                except Exception:
                    return mat
        except Exception:
            pass
        try:
            return rv3d.view_matrix.to_3x3().inverted().normalized()
        except Exception:
            try:
                return rv3d.view_matrix.to_3x3().inverted()
            except Exception:
                pass
        return None

    def _effective_region_data(self, context):
        """Return the RegionView3D that belongs to the active Smart G-R-S drag.

        VIEW / WORKPLANE orientation is dynamic: the active X/Y/Z or XY/YZ/XZ
        constraint kind is kept, but the basis must follow the current view
        angle if the user has orbited the viewport.  Therefore the View3D area
        captured at invoke time is used to re-resolve its current RegionView3D on
        every orientation query instead of relying on a stale modal context.
        """
        def _area_region_data(area, region=None):
            try:
                rv3d = cu._view3d_region_data(area, region)
                if rv3d is not None:
                    return rv3d
            except Exception:
                pass
            return None

        try:
            space_name = str(self._effective_constraint_space(context))
        except Exception:
            try:
                space_name = str(getattr(self, 'constraint_space', '') or '')
            except Exception:
                space_name = ''

        # For VIEW / WORKPLANE, keep the RegionView3D captured at invoke time.
        # In Quad View, recomputing from the physical region can return another
        # pane's region.data and changes the solve basis mid-drag.  The stored
        # RegionView3D object itself stays live when the view is orbited, so it is
        # safe and more stable to reuse it.
        if space_name in {'VIEW', 'WORKPLANE'}:
            try:
                rv3d = getattr(self, '_rv3d', None)
                if rv3d is not None:
                    return rv3d
            except Exception:
                pass
            try:
                area = getattr(context, 'area', None)
                if getattr(area, 'type', None) == 'VIEW_3D':
                    rv3d = getattr(context, 'region_data', None) or _area_region_data(area, getattr(context, 'region', None))
                    if rv3d is not None:
                        self._rv3d = rv3d
                        return rv3d
            except Exception:
                pass
            try:
                rv3d = _area_region_data(getattr(self, '_area', None), getattr(self, '_region', None))
                if rv3d is not None:
                    self._rv3d = rv3d
                    return rv3d
            except Exception:
                pass

        # For non-view coordinate systems, Smart Gizmo-originated operations keep
        # the captured area to avoid accidental context switching.
        try:
            if bool(getattr(self, '_from_smart_gizmo', False)):
                rv3d = _area_region_data(getattr(self, '_area', None), getattr(self, '_region', None)) or getattr(self, '_rv3d', None)
                if rv3d is not None:
                    self._rv3d = rv3d
                    return rv3d
        except Exception:
            pass
        try:
            rv3d = getattr(context, 'region_data', None)
            if rv3d is not None:
                return rv3d
        except Exception:
            pass
        try:
            rv3d = _area_region_data(getattr(self, '_area', None), getattr(self, '_region', None)) or getattr(self, '_rv3d', None)
            if rv3d is not None:
                self._rv3d = rv3d
                return rv3d
        except Exception:
            pass
        return None


    def _basis_from_scene_custom_orientation(self, context, orient_name: str):
        try:
            slot = context.scene.transform_orientation_slots[0]
            custom = getattr(slot, 'custom_orientation', None)
            if custom is not None:
                slot_type = str(getattr(slot, 'type', '') or '')
                custom_name = str(getattr(custom, 'name', '') or '')
                if slot_type == orient_name or custom_name == orient_name or (slot_type == 'CUSTOM' and orient_name in {'CUSTOM', custom_name}):
                    mat = getattr(custom, 'matrix', None)
                    if mat is not None:
                        return mat.to_3x3() if hasattr(mat, 'to_3x3') else mathutils.Matrix(mat)
        except Exception:
            pass
        try:
            items = getattr(context.scene, 'transform_orientations', None)
            if items is not None:
                for item in items:
                    if getattr(item, 'name', None) == orient_name:
                        mat = getattr(item, 'matrix', None)
                        if mat is not None:
                            return mat.to_3x3() if hasattr(mat, 'to_3x3') else mathutils.Matrix(mat)
        except Exception:
            pass
        return mathutils.Matrix.Identity(3)

    def _smart_gizmo_cached_orient_matrix(self, orient_mode: str):
        """Return exact Smart Gizmo axes captured at handle press.

        Smart Gizmo axis/plane handles use the visible gizmo basis for fixed
        coordinate systems.  VIEW / WORKPLANE are intentionally excluded from
        this cache: their axes are defined by the current viewport rotation, so
        orbiting the view must immediately update X/Y/Z and plane constraints
        while keeping the same constraint kind/index active.
        """
        try:
            orient_key = str(orient_mode or '')
            if orient_key in {'VIEW', 'WORKPLANE'}:
                return None
            axes = getattr(self, '_smart_gizmo_orient_axes', None)
            if not axes or len(axes) < 3:
                return None
            basis_space = str(getattr(self, '_smart_gizmo_orient_space', '') or '')
            if basis_space and orient_key and orient_key != basis_space:
                return None
            x = mathutils.Vector(axes[0]).normalized()
            y = mathutils.Vector(axes[1]).normalized()
            z = mathutils.Vector(axes[2]).normalized()
            if x.length_squared <= 1.0e-12 or y.length_squared <= 1.0e-12 or z.length_squared <= 1.0e-12:
                return None
            # Columns are the X/Y/Z basis vectors in world space.
            return mathutils.Matrix(((x.x, y.x, z.x), (x.y, y.y, z.y), (x.z, y.z, z.z)))
        except Exception:
            return None

    def _get_orient_matrix(self, context, orient_mode: str):
        orient_mode = orient_mode or 'GLOBAL'
        try:
            orient_mode = str(orient_mode)
        except Exception:
            orient_mode = 'GLOBAL'

        cached_matrix = self._smart_gizmo_cached_orient_matrix(orient_mode)
        if cached_matrix is not None:
            return cached_matrix

        if orient_mode == 'GLOBAL':
            return mathutils.Matrix.Identity(3)

        if orient_mode == 'CURSOR':
            try:
                return context.scene.cursor.matrix.to_3x3()
            except Exception:
                return mathutils.Matrix.Identity(3)

        if orient_mode in {'VIEW', 'WORKPLANE'}:
            rv3d = self._effective_region_data(context)
            if rv3d:
                mat = self._view_basis_from_rv3d(rv3d)
                if mat is not None:
                    return mat
            return mathutils.Matrix.Identity(3)

        obj = context.active_object
        if not obj:
            if orient_mode not in {'LOCAL', 'GIMBAL', 'NORMAL', 'PARENT'}:
                return self._basis_from_scene_custom_orientation(context, orient_mode)
            return mathutils.Matrix.Identity(3)

        if orient_mode == 'PARENT':
            try:
                parent = getattr(obj, 'parent', None)
                if parent is not None:
                    return parent.matrix_world.to_3x3().normalized()
            except Exception:
                pass
            return mathutils.Matrix.Identity(3)

        if orient_mode == 'NORMAL' and context.mode == 'EDIT_MESH' and obj.type == 'MESH' and obj.mode == 'EDIT':
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                elem = bm.select_history.active
                normal = None
                if isinstance(elem, bmesh.types.BMFace):
                    normal = elem.normal
                elif isinstance(elem, bmesh.types.BMEdge):
                    n = mathutils.Vector((0, 0, 0))
                    for f in elem.link_faces:
                        n += f.normal
                    if n.length_squared > 0:
                        n.normalize()
                        normal = n
                elif isinstance(elem, bmesh.types.BMVert):
                    normal = elem.normal
                if normal is not None:
                    z = (obj.matrix_world.to_3x3() @ normal).normalized()
                    up = mathutils.Vector((0, 0, 1)) if abs(z.z) < 0.9 else mathutils.Vector((0, 1, 0))
                    x = up.cross(z).normalized()
                    y = z.cross(x).normalized()
                    return mathutils.Matrix((x, y, z)).transposed()
            except Exception:
                pass

        if orient_mode in {'LOCAL', 'GIMBAL', 'NORMAL'}:
            try:
                return obj.matrix_world.to_3x3().normalized()
            except Exception:
                return mathutils.Matrix.Identity(3)

        return self._basis_from_scene_custom_orientation(context, orient_mode)

    # ---------------------------------------------------------
    # Pivot helpers (cycle / edit)
    # ---------------------------------------------------------
    def _calc_pivot_world(self, context):
        pivot_mode = getattr(self, 'pivot_mode_current', None) or context.scene.tool_settings.transform_pivot_point
        cursor = context.scene.cursor.location.copy()
        active_obj = context.active_object

        points = _smart_grs_selection_world_points(context)

        if pivot_mode == 'CURSOR':
            return cursor
        if pivot_mode == 'ACTIVE_ELEMENT':
            if context.mode == 'EDIT_MESH' and active_obj and active_obj.type == 'MESH' and active_obj.mode == 'EDIT':
                try:
                    bm = bmesh.from_edit_mesh(active_obj.data)
                    act = bm.select_history.active
                    if act:
                        mat = active_obj.matrix_world.copy()
                        if isinstance(act, bmesh.types.BMVert):
                            return mat @ act.co.copy()
                        if isinstance(act, bmesh.types.BMEdge):
                            return mat @ ((act.verts[0].co.copy() + act.verts[1].co.copy()) * 0.5)
                        if isinstance(act, bmesh.types.BMFace):
                            c = mathutils.Vector((0, 0, 0))
                            verts = list(act.verts)
                            for v in verts:
                                c += v.co.copy()
                            return mat @ (c / max(len(verts), 1))
                except ReferenceError:
                    pass
                except Exception:
                    pass
            if context.mode == 'EDIT_LATTICE' and active_obj and active_obj.type == 'LATTICE':
                try:
                    sel = collect_edit_lattice_selected_points(active_obj)
                    if sel:
                        idx = min(sel)
                        return active_obj.matrix_world @ mathutils.Vector(active_obj.data.points[idx].co_deform)
                except Exception:
                    pass
            if context.mode in {'EDIT_CURVE', 'EDIT_SURFACE'} and active_obj and active_obj.type in {'CURVE', 'SURFACE'}:
                try:
                    comps = collect_edit_curve_selected_components(active_obj)
                    if comps:
                        return active_obj.matrix_world @ comps[-1][1]
                except Exception:
                    pass
            if context.mode == 'EDIT_ARMATURE' and active_obj and active_obj.type == 'ARMATURE':
                try:
                    bone = getattr(active_obj.data.edit_bones, 'active', None)
                    if bone is not None:
                        return active_obj.matrix_world @ ((bone.head + bone.tail) * 0.5)
                except Exception:
                    pass
            if context.mode == 'POSE' and active_obj and active_obj.type == 'ARMATURE':
                try:
                    pb = getattr(context, 'active_pose_bone', None)
                    if pb is not None:
                        return active_obj.matrix_world @ pb.matrix.translation
                except Exception:
                    pass
            return active_obj.matrix_world.translation.copy() if active_obj else cursor

        if not points:
            return active_obj.matrix_world.translation.copy() if active_obj else cursor
        if pivot_mode == 'BOUNDING_BOX_CENTER':
            mn = mathutils.Vector((float('inf'), float('inf'), float('inf')))
            mx = mathutils.Vector((float('-inf'), float('-inf'), float('-inf')))
            for p in points:
                mn.x, mn.y, mn.z = min(mn.x, p.x), min(mn.y, p.y), min(mn.z, p.z)
                mx.x, mx.y, mx.z = max(mx.x, p.x), max(mx.y, p.y), max(mx.z, p.z)
            return (mn + mx) * 0.5

        acc = sum(points, mathutils.Vector((0, 0, 0)))
        return acc / max(len(points), 1)

    def _cycle_pivot_mode(self):
        order = ['MEDIAN_POINT', 'ACTIVE_ELEMENT', 'CURSOR', 'BOUNDING_BOX_CENTER']
        cur = getattr(self, 'pivot_mode_current', None) or 'MEDIAN_POINT'
        try:
            self.pivot_mode_current = order[(order.index(cur) + 1) % len(order)]
        except Exception:
            self.pivot_mode_current = 'MEDIAN_POINT'

    def _cycle_orient_space(self, context):
        try:
            self._smart_gizmo_orient_axes = None
            self._smart_gizmo_orient_space = ''
        except Exception:
            pass
        order = self._supported_orient_modes(context)
        cur = self.constraint_space
        try:
            self.constraint_space = order[(order.index(cur) + 1) % len(order)]
        except Exception:
            self.constraint_space = 'GLOBAL'

    def _restart_baseline_from_current(self, context):
        # Commit current state as new initial, reset starting mouse references.
        self._store_initial_state(context)
        self._smart_gizmo_follow_base = None
        self.pivot_3d = self._calc_pivot_world(context)
        self.current_pivot_3d = self.pivot_3d.copy()
        region, rv3d = self._smart_gizmo_region_rv3d(context) if hasattr(self, '_smart_gizmo_region_rv3d') else (getattr(context, 'region', None), getattr(context, 'region_data', None))
        p2d = self._smart_gizmo_project_location_visible_2d(context, self.pivot_3d) if region and rv3d else None
        self.pivot_2d = p2d if p2d else mathutils.Vector(((getattr(region, 'width', 1) or 1) * 0.5, (getattr(region, 'height', 1) or 1) * 0.5))
        self.start_region_x, self.start_region_y = self.last_cx, self.last_cy
        if self.mode == 'R':
            self.start_angle = math.atan2(self.last_cy - self.pivot_2d.y, self.last_cx - self.pivot_2d.x)
            self._rotation_offset_rad = 0.0
            self._circular_rotation_accum_rad = 0.0
            self._circular_rotation_prev_angle = float(self.start_angle)
            self._clear_rotation_snap_anchor()
            if self._use_free_axis_rotation():
                self._reset_free_rotation_baseline(context, self.last_cx, self.last_cy, keep_current=False, sens=1.0)
        elif self.mode == 'S':
            self.start_vec2 = mathutils.Vector((self.last_cx - self.pivot_2d.x, self.last_cy - self.pivot_2d.y))
            self.start_dist = max(self.start_vec2.length, 0.001)
            self.start_dir2 = self.start_vec2.normalized() if self.start_vec2.length > 1e-8 else mathutils.Vector((1.0, 0.0))
            self._smart_gizmo_scale_delta_mode = False
            if not self._use_gizmo_distance_scale(context):
                self._screen_coordinate_scale_base_px = 0.0
                self._prepare_screen_coordinate_scale_baseline(context, self.last_cx, self.last_cy, 1.0, preserve_current=False)
            else:
                self.start_scale_base = max(abs(self._scale_signed_distance(context, self.last_cx, self.last_cy)), 0.001)

        try:
            if context.area:
                context.area.tag_redraw()
        except Exception:
            pass

    def _store_initial_state(self, context):
        self._obj_mats = {}
        self._obj_initial_rotation_euler = {}
        self._edit_verts = {}
        self._edit_lattice_points = {}
        self._edit_curve_points = {}
        self._edit_armature_points = {}
        self._pose_bone_mats = {}
        self._edit_metaball_elements = {}
        use_prop = is_prop_enabled(context)

        if context.mode == 'EDIT_MESH':
            all_sel_coords = []
            edit_objs = collect_edit_targets(context)
            self._mesh_island_transform_enabled = _mesh_island_transform_enabled(context)
            self._mesh_island_groups = {}
            if self._mesh_island_transform_enabled:
                for _obj in edit_objs:
                    try:
                        _bm = bmesh.from_edit_mesh(_obj.data)
                        _groups = _collect_selected_mesh_islands_from_bmesh(_bm, context)
                        if _groups:
                            self._mesh_island_groups[_obj] = _groups
                    except Exception:
                        continue
            use_connected = getattr(context.tool_settings, "use_proportional_connected", False)

            selected_indices_by_obj = {}
            kd = None
            for obj in edit_objs:
                try:
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.verts.ensure_lookup_table()
                    selected_indices_by_obj[obj] = collect_edit_selected_vert_indices(bm)
                except Exception:
                    selected_indices_by_obj[obj] = set()

            if use_prop and not use_connected:
                for obj in edit_objs:
                    try:
                        bm = bmesh.from_edit_mesh(obj.data)
                        bm.verts.ensure_lookup_table()
                        mat = obj.matrix_world.copy()
                        selected_indices = selected_indices_by_obj.get(obj, set())
                        for idx in selected_indices:
                            try:
                                if 0 <= int(idx) < len(bm.verts):
                                    all_sel_coords.append(mat @ bm.verts[int(idx)].co.copy())
                            except ReferenceError:
                                continue
                            except Exception:
                                continue
                    except Exception:
                        continue

                if all_sel_coords:
                    kd = mathutils.kdtree.KDTree(len(all_sel_coords))
                    for i, co in enumerate(all_sel_coords):
                        kd.insert(co, i)
                    kd.balance()

            for obj in edit_objs:
                try:
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.verts.ensure_lookup_table()
                    mat = obj.matrix_world.copy()
                    selected_indices = {int(idx) for idx in selected_indices_by_obj.get(obj, set())}
                except Exception:
                    continue
                
                vmap = {}
                if use_prop and use_connected:
                    world_coords = {}
                    try:
                        verts_snapshot = list(bm.verts)
                    except ReferenceError:
                        verts_snapshot = []
                    except Exception:
                        verts_snapshot = []
                    for v in verts_snapshot:
                        try:
                            world_coords[int(v.index)] = mat @ v.co.copy()
                        except ReferenceError:
                            continue
                        except Exception:
                            continue
                    distances = {}
                    pq = []
                    
                    for idx in selected_indices:
                        try:
                            if int(idx) in world_coords:
                                distances[int(idx)] = 0.0
                                heapq.heappush(pq, (0.0, int(idx)))
                        except Exception:
                            pass
                            
                    while pq:
                        dist, v_idx = heapq.heappop(pq)
                        if dist > distances.get(v_idx, float('inf')):
                            continue
                        try:
                            if not (0 <= int(v_idx) < len(bm.verts)):
                                continue
                            v = bm.verts[int(v_idx)]
                            p1 = world_coords.get(int(v_idx))
                            if p1 is None:
                                continue
                            linked_edges = list(v.link_edges)
                        except ReferenceError:
                            continue
                        except Exception:
                            continue
                        
                        for edge in linked_edges:
                            try:
                                other_idx = int(edge.other_vert(v).index)
                                p2 = world_coords.get(other_idx)
                                if p2 is None:
                                    continue
                            except ReferenceError:
                                continue
                            except Exception:
                                continue
                            
                            edge_len = (p1 - p2).length
                            new_dist = dist + edge_len
                            
                            if new_dist < distances.get(other_idx, float('inf')):
                                distances[other_idx] = new_dist
                                heapq.heappush(pq, (new_dist, other_idx))

                    try:
                        verts_iter = list(bm.verts)
                    except ReferenceError:
                        verts_iter = []
                    except Exception:
                        verts_iter = []
                    for v in verts_iter:
                        try:
                            v_idx = int(v.index)
                            if v_idx in selected_indices:
                                vmap[v_idx] = (v.co.copy(), 0.0)
                            elif v_idx in distances:
                                vmap[v_idx] = (v.co.copy(), distances[v_idx])
                        except ReferenceError:
                            continue
                        except Exception:
                            continue
                else:
                    try:
                        verts_iter = list(bm.verts)
                    except ReferenceError:
                        verts_iter = []
                    except Exception:
                        verts_iter = []
                    for v in verts_iter:
                        try:
                            v_idx = int(v.index)
                            if v_idx in selected_indices:
                                vmap[v_idx] = (v.co.copy(), 0.0)
                            elif kd:
                                _, _, dist = kd.find(mat @ v.co.copy())
                                vmap[v_idx] = (v.co.copy(), dist)
                        except ReferenceError:
                            continue
                        except Exception:
                            continue
                self._edit_verts[obj] = vmap
        elif context.mode == 'EDIT_LATTICE':
            self._mesh_island_transform_enabled = False
            self._mesh_island_groups = {}
            edit_objs = collect_edit_lattice_targets(context)
            kd = None
            all_sel_coords = []
            selected_indices_by_obj = {}

            for obj in edit_objs:
                sel = collect_edit_lattice_selected_points(obj)
                selected_indices_by_obj[obj] = sel
                if use_prop and sel:
                    mat = obj.matrix_world
                    try:
                        points = obj.data.points
                        for idx in sel:
                            all_sel_coords.append(mat @ mathutils.Vector(points[idx].co_deform))
                    except Exception:
                        pass

            if use_prop and all_sel_coords:
                kd = mathutils.kdtree.KDTree(len(all_sel_coords))
                for i, co in enumerate(all_sel_coords):
                    kd.insert(co, i)
                kd.balance()

            for obj in edit_objs:
                try:
                    points = obj.data.points
                    mat = obj.matrix_world
                    selected_indices = selected_indices_by_obj.get(obj, set())
                    pmap = {}
                    for idx, point in enumerate(points):
                        orig = mathutils.Vector(point.co_deform).copy()
                        if idx in selected_indices:
                            pmap[idx] = (orig, 0.0)
                        elif kd:
                            _, _, dist = kd.find(mat @ orig)
                            pmap[idx] = (orig, float(dist))
                    self._edit_lattice_points[obj] = pmap
                except Exception:
                    continue
        elif context.mode in {'EDIT_CURVE', 'EDIT_SURFACE'}:
            self._mesh_island_transform_enabled = False
            self._mesh_island_groups = {}
            edit_objs = collect_edit_curve_targets(context)
            selected_by_obj = {}
            all_sel_coords = []
            kd = None
            for obj in edit_objs:
                selected = {key for key, _co in collect_edit_curve_selected_components(obj)}
                selected_by_obj[obj] = selected
                if use_prop and selected:
                    mat = obj.matrix_world
                    for key in selected:
                        for ckey, co, _sel in _curve_component_items(obj, selected_only=False):
                            if ckey == key:
                                all_sel_coords.append(mat @ co)
                                break
            if use_prop and all_sel_coords:
                kd = mathutils.kdtree.KDTree(len(all_sel_coords))
                for i, co in enumerate(all_sel_coords):
                    kd.insert(co, i)
                kd.balance()
            for obj in edit_objs:
                try:
                    mat = obj.matrix_world
                    selected = selected_by_obj.get(obj, set())
                    cmap = {}
                    for key, orig, _selected in _curve_component_items(obj, selected_only=False):
                        if key in selected:
                            cmap[key] = (orig.copy(), 0.0)
                        elif kd:
                            _, _, dist = kd.find(mat @ orig)
                            cmap[key] = (orig.copy(), float(dist))
                    if cmap:
                        self._edit_curve_points[obj] = cmap
                except Exception:
                    continue
        elif context.mode == 'EDIT_ARMATURE':
            self._mesh_island_transform_enabled = False
            self._mesh_island_groups = {}
            for obj in collect_edit_armature_targets(context):
                try:
                    amap = {}
                    bones = getattr(obj.data, 'edit_bones', [])
                    for bone in bones:
                        parts = _edit_bone_selected_parts(bone)
                        if not parts:
                            continue
                        amap[bone.name] = {
                            'parts': set(parts),
                            'head': mathutils.Vector(bone.head).copy(),
                            'tail': mathutils.Vector(bone.tail).copy(),
                            'roll': float(getattr(bone, 'roll', 0.0)),
                        }
                    if amap:
                        self._edit_armature_points[obj] = amap
                except Exception:
                    continue
        elif context.mode == 'POSE':
            self._mesh_island_transform_enabled = False
            self._mesh_island_groups = {}
            for obj in collect_pose_targets(context):
                try:
                    pmap = {}
                    for pbone in collect_pose_selected_bones(obj):
                        try:
                            pmap[str(pbone.name)] = {
                                'matrix': pbone.matrix.copy(),
                                'matrix_basis': pbone.matrix_basis.copy(),
                                'location': pbone.location.copy(),
                                'rotation_mode': str(getattr(pbone, 'rotation_mode', 'QUATERNION') or 'QUATERNION'),
                                'rotation_euler': pbone.rotation_euler.copy(),
                                'rotation_quaternion': pbone.rotation_quaternion.copy(),
                                'scale': pbone.scale.copy(),
                            }
                        except Exception:
                            pmap[str(pbone.name)] = pbone.matrix.copy()
                    if pmap:
                        self._pose_bone_mats[obj] = pmap
                except Exception:
                    continue
        elif context.mode == 'EDIT_METABALL':
            self._mesh_island_transform_enabled = False
            self._mesh_island_groups = {}
            for obj in collect_edit_metaball_targets(context):
                try:
                    mmap = {}
                    for idx, co in collect_edit_metaball_selected_elements(obj):
                        mmap[int(idx)] = (mathutils.Vector(co).copy(), 0.0)
                    if mmap:
                        self._edit_metaball_elements[obj] = mmap
                except Exception:
                    continue
        else:
            self._mesh_island_transform_enabled = False
            self._mesh_island_groups = {}
            sel_objs = list(context.selected_objects)
            prefs = _prefs(context)
            basis = getattr(prefs, 'object_prop_basis', 'ORIGIN') if prefs else 'ORIGIN'

            def _bbox_world_aabb(obj):
                try:
                    pts = [obj.matrix_world @ mathutils.Vector(c) for c in obj.bound_box]
                    mn = mathutils.Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
                    mx = mathutils.Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
                    return mn, mx
                except Exception:
                    t = obj.matrix_world.translation
                    return t.copy(), t.copy()

            def _bbox_center(obj):
                mn, mx = _bbox_world_aabb(obj)
                return (mn + mx) * 0.5

            def _dist_point_to_aabb(p, mn, mx):
                dx = 0.0
                dy = 0.0
                dz = 0.0
                if p.x < mn.x: dx = mn.x - p.x
                elif p.x > mx.x: dx = p.x - mx.x
                if p.y < mn.y: dy = mn.y - p.y
                elif p.y > mx.y: dy = p.y - mx.y
                if p.z < mn.z: dz = mn.z - p.z
                elif p.z > mx.z: dz = p.z - mx.z
                return math.sqrt(dx*dx + dy*dy + dz*dz)

            def _basis_point(obj):
                if basis == 'BBOX':
                    return _bbox_center(obj)
                return obj.matrix_world.translation.copy()

            kd = None
            sel_pts = []
            if use_prop and sel_objs:
                sel_pts = [_basis_point(o) for o in sel_objs]
                kd = mathutils.kdtree.KDTree(len(sel_pts))
                for i, co in enumerate(sel_pts):
                    kd.insert(co, i)
                kd.balance()

            for o in context.visible_objects:
                if o.hide_viewport or o.hide_select:
                    continue
                if o in sel_objs:
                    self._obj_mats[o] = (o.matrix_world.copy(), 0.0)
                    try:
                        rmode = str(getattr(o, 'rotation_mode', '') or '')
                        if rmode not in {'QUATERNION', 'AXIS_ANGLE'} and hasattr(o, 'rotation_euler'):
                            self._obj_initial_rotation_euler[o] = (rmode, o.rotation_euler.copy())
                    except Exception:
                        pass
                elif kd:
                    if basis == 'BBOX_CLOSEST':
                        p_near, _, _ = kd.find(o.matrix_world.translation)
                        mn, mx = _bbox_world_aabb(o)
                        dist = _dist_point_to_aabb(p_near, mn, mx)
                    else:
                        _, _, dist = kd.find(_basis_point(o))
                    self._obj_mats[o] = (o.matrix_world.copy(), float(dist))

    def _restore_initial_state(self, context):
        for obj, (mat, dist) in getattr(self, "_obj_mats", {}).items():
            if obj and obj.name in bpy.data.objects:
                obj.matrix_world = mat.copy()
                try:
                    info = getattr(self, '_obj_initial_rotation_euler', {}).get(obj)
                    if info and str(getattr(obj, 'rotation_mode', '') or '') == str(info[0]) and hasattr(obj, 'rotation_euler'):
                        obj.rotation_euler = info[1].copy()
                except Exception:
                    pass
        for obj, vmap in getattr(self, "_edit_verts", {}).items():
            if not obj or obj.name not in bpy.data.objects or obj.type != 'MESH' or obj.mode != 'EDIT':
                continue
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            for idx, (co, dist) in vmap.items():
                if idx < len(bm.verts):
                    bm.verts[idx].co = co.copy()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        for obj, pmap in getattr(self, "_edit_lattice_points", {}).items():
            if not obj or obj.name not in bpy.data.objects or obj.type != 'LATTICE' or obj.mode != 'EDIT':
                continue
            try:
                points = obj.data.points
                for idx, (co, dist) in pmap.items():
                    if idx < len(points):
                        points[idx].co_deform = co.copy()
                try:
                    obj.data.update_tag()
                except Exception:
                    pass
            except Exception:
                continue
        for obj, cmap in getattr(self, "_edit_curve_points", {}).items():
            if not obj or obj.name not in bpy.data.objects or obj.type not in {'CURVE', 'SURFACE'} or obj.mode != 'EDIT':
                continue
            try:
                for key, (co, _dist) in cmap.items():
                    _curve_component_set(obj, key, co.copy())
            except Exception:
                continue
        for obj, amap in getattr(self, "_edit_armature_points", {}).items():
            if not obj or obj.name not in bpy.data.objects or obj.type != 'ARMATURE' or obj.mode != 'EDIT':
                continue
            try:
                bones = obj.data.edit_bones
                for name, entry in amap.items():
                    bone = bones.get(name)
                    if not bone:
                        continue
                    bone.head = entry['head'].copy()
                    bone.tail = entry['tail'].copy()
                    try:
                        bone.roll = float(entry.get('roll', bone.roll))
                    except Exception:
                        pass
            except Exception:
                continue
        for obj, pmap in getattr(self, "_pose_bone_mats", {}).items():
            if not obj or obj.name not in bpy.data.objects or obj.type != 'ARMATURE':
                continue
            try:
                for name, entry in pmap.items():
                    pbone = obj.pose.bones.get(name) if getattr(obj, 'pose', None) else None
                    if not pbone:
                        continue
                    try:
                        if isinstance(entry, dict):
                            pbone.rotation_mode = str(entry.get('rotation_mode', getattr(pbone, 'rotation_mode', 'QUATERNION')) or getattr(pbone, 'rotation_mode', 'QUATERNION'))
                            pbone.matrix_basis = entry.get('matrix_basis', pbone.matrix_basis).copy()
                            pbone.location = entry.get('location', pbone.location).copy()
                            try:
                                pbone.rotation_euler = entry.get('rotation_euler', pbone.rotation_euler).copy()
                            except Exception:
                                pass
                            try:
                                pbone.rotation_quaternion = entry.get('rotation_quaternion', pbone.rotation_quaternion).copy()
                            except Exception:
                                pass
                            pbone.scale = entry.get('scale', pbone.scale).copy()
                            pbone.matrix = entry.get('matrix', pbone.matrix).copy()
                        else:
                            pbone.matrix = entry.copy()
                    except Exception:
                        try:
                            pbone.matrix = (entry.get('matrix') if isinstance(entry, dict) else entry).copy()
                        except Exception:
                            pass
                try:
                    bpy.context.view_layer.update()
                except Exception:
                    pass
            except Exception:
                continue
        for obj, mmap in getattr(self, "_edit_metaball_elements", {}).items():
            if not obj or obj.name not in bpy.data.objects or obj.type != 'META' or obj.mode != 'EDIT':
                continue
            try:
                elems = obj.data.elements
                for idx, (co, _dist) in mmap.items():
                    if idx < len(elems):
                        elems[idx].co = co.copy()
            except Exception:
                continue

    def _effective_snap_mode(self, context, mods=None):
        snap = getattr(self, '_snap_hold', None)
        if snap:
            return snap
        mods = mods or {}
        try:
            # Smart G-R-S applies object/edit data directly, so Blender's native
            # Transform Modal Map cannot supply increment snap for us. Keep the
            # old Smart G-R-S behavior: Ctrl always uses numeric/grid snap. Scene
            # vertex/edge/face snap is used only while Ctrl is not held.
            if bool(mods.get('ctrl')):
                return 'GRID'

            # Blender's native Transform Snap Base workflow is source-point first:
            # B confirms a source snap point, then that source point snaps to the
            # next target under the cursor.  Smart G-R-S bypasses Blender's C
            # transform backend, so this explicit state keeps the same behavior
            # even when scene snapping is currently disabled.
            if bool(getattr(self, '_snap_base_active', False)) and bool(getattr(self, '_snap_base_force_target_snap', False)):
                return 'POINT'

            ts = context.scene.tool_settings
            use_snap = bool(getattr(ts, 'use_snap', False))
            if not use_snap:
                return None

            elems = set(getattr(ts, 'snap_elements', set()) or set())
            if 'VERTEX' in elems:
                return 'VERT'
            if 'EDGE' in elems or 'EDGE_MIDPOINT' in elems or 'EDGE_PERPENDICULAR' in elems:
                return 'EDGE'
            if 'FACE' in elems or 'FACE_NEAREST' in elems or 'FACE_PROJECT' in elems:
                return 'FACE'
            try:
                if bool(getattr(self, '_custom_snap_points', None)):
                    return 'POINT'
            except Exception:
                pass
            return 'GRID'
        except Exception:
            try:
                if bool(getattr(self, '_snap_base_active', False)) and bool(getattr(self, '_snap_base_force_target_snap', False)):
                    return 'POINT'
                return 'GRID' if bool((mods or {}).get('ctrl')) else None
            except Exception:
                return None

    def _is_ctrl_increment_snap(self, mods=None) -> bool:
        try:
            return bool((mods or {}).get('ctrl')) and not bool(getattr(self, '_snap_hold', None))
        except Exception:
            return False

    def _active_mods_dict(self, shift=None):
        try:
            last = getattr(self, '_last_mods', (False, False, False, False))
            if shift is None:
                shift = bool(last[0])
            return {
                'shift': bool(shift),
                'ctrl': bool(last[1]),
                'alt': bool(last[2]),
                'oskey': bool(last[3]) if len(last) > 3 else False,
            }
        except Exception:
            return {'shift': bool(shift), 'ctrl': False, 'alt': False, 'oskey': False}

    def _standard_status_bar_text(self, context=None):
        try:
            mode_name_ctx = str(getattr(context or bpy.context, 'mode', '') or '')
            edit_mesh = (mode_name_ctx == 'EDIT_MESH')
        except Exception:
            edit_mesh = False
        parts = [
            TI('[Left Click] Confirm', '[左クリック] 確定'),
            TI('[Right Click] Cancel', '[右クリック] キャンセル'),
            TI('[X] [Y] [Z] Axis', '[X] [Y] [Z] 座標軸'),
            TI('[Shift] [X] [Y] [Z] Plane', '[Shift] [X] [Y] [Z] 平面'),
            TI('[B] Set Snap Base', '[B] スナップベースを設定'),
            TI('[Ctrl] Numeric Snap', '[Ctrl] スナップ数値'),
            TI('[Shift] [Tab] Toggle Snap', '[Shift] [Tab] スナップ切り替え'),
            TI('[A] Add Snap Point ([Alt] [A] Remove)', '[A] スナップポイントを追加（[Alt] [A] スナップポイントを削除）'),
        ]
        if edit_mesh:
            parts.append(TI('[G] Vertex/Edge Slide', '[G] 頂点/辺スライド'))
        parts.extend([
            TI('[R] Rotate', '[R] 回転'),
            TI('[S] Resize', '[S] リサイズ'),
            TI('[Middle Click] Auto Axis Constraint', '[中クリック] 自動軸制限'),
            TI('[Shift] [Middle Click] Auto Plane Constraint', '[Shift] [中クリック] 自動平面制限'),
            TI('[Shift] Precision Mode', '[Shift] 高精度モード'),
            TI('[Alt] Navigate', '[Alt] ナビゲート'),
        ])
        return '   '.join(parts)

    def _draw_status_bar(self, header, context):
        """Draw Blender-style modal shortcut hints with event icons."""
        try:
            layout = getattr(header, 'layout', None)
            if layout is None:
                return
            row = layout.row(align=True)
        except Exception:
            return

        def _item(icon: str, text: str):
            try:
                row.label(text=text, icon=icon)
            except Exception:
                try:
                    row.label(text=text)
                except Exception:
                    pass

        def _combo(icon_a: str, icon_b: str, text: str):
            try:
                sub = row.row(align=True)
                sub.label(text='', icon=icon_a)
                sub.label(text='', icon=icon_b)
                sub.label(text=text)
            except Exception:
                _item(icon_b, text)

        def _axis_combo(prefix_icon: str | None, text: str):
            try:
                sub = row.row(align=True)
                if prefix_icon:
                    sub.label(text='', icon=prefix_icon)
                sub.label(text='', icon='EVENT_X')
                sub.label(text='', icon='EVENT_Y')
                sub.label(text='', icon='EVENT_Z')
                sub.label(text=text)
            except Exception:
                _item('EVENT_X', text)

        try:
            edit_mesh = str(getattr(context or bpy.context, 'mode', '') or '') == 'EDIT_MESH'
        except Exception:
            edit_mesh = False

        _item('MOUSE_LMB', TI('Confirm', '確定'))
        _item('MOUSE_RMB', TI('Cancel', 'キャンセル'))
        _axis_combo(None, TI('Axis', '座標軸'))
        _axis_combo('EVENT_SHIFT', TI('Plane', '平面'))
        _item('EVENT_B', TI('Set Snap Base', 'スナップベースを設定'))
        _item('EVENT_CTRL', TI('Numeric Snap', 'スナップ数値'))
        _combo('EVENT_SHIFT', 'EVENT_TAB', TI('Toggle Snap', 'スナップ切り替え'))
        _item('EVENT_A', TI('Add Snap Point', 'スナップポイントを追加'))
        _combo('EVENT_ALT', 'EVENT_A', TI('Remove Snap Point', 'スナップポイントを削除'))
        if edit_mesh:
            _item('EVENT_G', TI('Vertex/Edge Slide', '頂点/辺スライド'))
        _item('EVENT_R', TI('Rotate', '回転'))
        _item('EVENT_S', TI('Resize', 'リサイズ'))
        _item('MOUSE_MMB', TI('Auto Axis', '自動軸制限'))
        _combo('EVENT_SHIFT', 'MOUSE_MMB', TI('Auto Plane', '自動平面制限'))
        _item('EVENT_SHIFT', TI('Precision Mode', '高精度モード'))
        _item('EVENT_ALT', TI('Navigate', 'ナビゲート'))

    def _set_status_text(self, context=None, text=''):
        context = context or bpy.context
        try:
            if getattr(context, 'workspace', None):
                context.workspace.status_text_set(text)
        except Exception:
            pass
        try:
            area = getattr(self, '_area', None) or getattr(context, 'area', None)
            if area:
                area.header_text_set(text)
        except Exception:
            pass

    def _status_mode_and_value_text(self, context=None):
        try:
            mode_name = {'G': TI('Move', '移動'), 'R': TI('Rotate', '回転'), 'S': TI('Resize', 'リサイズ')}.get(getattr(self, 'mode', 'G'), getattr(self, 'mode', 'G'))
            prefix = f"Smart G-R-S {mode_name}"
            if getattr(self, 'constraint_kind', 'NONE') != 'NONE' and getattr(self, 'constraint_idx', -1) in (0, 1, 2):
                axis = ['X', 'Y', 'Z'][self.constraint_idx]
                if self.constraint_kind == 'PLANE':
                    prefix += f" / {TI('Plane', '平面')} {axis}"
                else:
                    prefix += f" / {axis}"
            if bool(getattr(self, '_smart_slide_active', False)):
                prefix += f" / {TI('Slide', 'スライド')}"
            if getattr(self, 'mode', '') == 'R':
                prefix += f" / {math.degrees(float(getattr(self, '_last_rot', 0.0))):.4g}°"
            elif getattr(self, 'mode', '') == 'S':
                prefix += f" / {float(getattr(self, '_last_scale', 1.0)):.4g}x"
            elif getattr(self, 'mode', '') == 'G':
                mv = getattr(self, '_last_move', mathutils.Vector((0, 0, 0)))
                prefix += f" / |Δ|={mv.length:.4g}"
            return prefix
        except Exception:
            return "Smart G-R-S"

    def _toggle_scene_snap(self, context):
        try:
            ts = context.scene.tool_settings
            ts.use_snap = not bool(getattr(ts, 'use_snap', False))
            self._status_text_update(context)
            return True
        except Exception:
            return False

    def _mouse_world_point_on_pivot_plane(self, context, mx, my):
        try:
            region = getattr(context, 'region', None) or getattr(self, '_region', None)
            rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
            if region is None or rv3d is None:
                return None
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (mx, my))
            direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (mx, my))
            view_normal = direction.normalized()
            plane_co = getattr(self, 'pivot_3d', mathutils.Vector((0, 0, 0)))
            denom = view_normal.dot(direction)
            if abs(denom) < 1e-8:
                return plane_co.copy()
            t = (plane_co - origin).dot(view_normal) / denom
            return origin + direction * t
        except Exception:
            return None

    def _capture_smart_gizmo_modal_freeze_prev(self):
        """Capture the pre-modal Smart Gizmo freeze state once.

        Smart G-R-S can temporarily move the visible Smart Gizmo origin while an
        operation is running.  The original freeze state must be restored only
        when the transform itself ends, not when the snap-base point changes.
        """
        try:
            if bool(getattr(self, '_smart_gizmo_freeze_prev_captured', False)):
                return
            prev_active = bool(getattr(cg, '_SMART_GIZMO_FREEZE_ACTIVE', False))
            prev_pivot = getattr(cg, '_SMART_GIZMO_FROZEN_PIVOT', None)
            prev_axes = getattr(cg, '_SMART_GIZMO_FROZEN_AXES', None)
            self._smart_gizmo_freeze_prev = (prev_active, prev_pivot, prev_axes)
            self._smart_gizmo_freeze_prev_captured = True
        except Exception:
            try:
                self._smart_gizmo_freeze_prev = (False, None, None)
                self._smart_gizmo_freeze_prev_captured = True
            except Exception:
                pass

    def _smart_gizmo_modal_freeze_axes(self, context):
        try:
            axes = getattr(cg, '_SMART_GIZMO_FROZEN_AXES', None)
            if bool(getattr(cg, '_SMART_GIZMO_FREEZE_ACTIVE', False)) and axes and len(axes) >= 4:
                return axes
        except Exception:
            pass

        # A Smart Gizmo press already captured the exact visible basis and its
        # coordinate-system name.  Use that payload before consulting the scene
        # again: Blender can temporarily expose the generic GLOBAL slot while a
        # modal operator starts, even though the clicked gizmo was LOCAL.
        try:
            captured = getattr(self, '_smart_gizmo_orient_axes', None)
            if captured and len(captured) >= 3:
                space = str(getattr(self, '_smart_gizmo_orient_space', '') or getattr(self, 'constraint_space', '') or 'GLOBAL')
                x = mathutils.Vector(captured[0]).normalized()
                y = mathutils.Vector(captured[1]).normalized()
                z = mathutils.Vector(captured[2]).normalized()
                if x.length_squared > 1.0e-12 and y.length_squared > 1.0e-12 and z.length_squared > 1.0e-12:
                    return (x, y, z, space)
        except Exception:
            pass

        try:
            from . import csdt_gizmo as _smart_gizmo
            _pivot, axes = _smart_gizmo._smart_pivot_location_and_axes(context)
            if axes and len(axes) >= 4:
                return axes
        except Exception:
            pass
        try:
            return (
                self._get_constraint_axis(context, 0),
                self._get_constraint_axis(context, 1),
                self._get_constraint_axis(context, 2),
                getattr(self, 'constraint_space', 'GLOBAL'),
            )
        except Exception:
            return (
                mathutils.Vector((1.0, 0.0, 0.0)),
                mathutils.Vector((0.0, 1.0, 0.0)),
                mathutils.Vector((0.0, 0.0, 1.0)),
                'GLOBAL',
            )

    def _modal_smart_gizmo_kind(self, context):
        # Do not call csdt_gizmo._smart_tool_kind() here: during an active
        # snap-base override that function intentionally returns the current
        # override kind, which would keep a stale MOVE gizmo after switching to
        # R/S.  Use the live Smart G-R-S mode.  Only the all-in-one Transform
        # tool keeps the combined handle shape.
        try:
            if cu._active_tool_id(context) == 'builtin.transform':
                return 'TRANSFORM'
        except Exception:
            pass
        mode = str(getattr(self, 'mode', 'G') or 'G').upper()
        if mode == 'R':
            return 'ROTATE'
        if mode == 'S':
            return 'SCALE'
        return 'MOVE'

    def _set_smart_gizmo_modal_freeze_pivot(self, context, pivot_world, *, snap_base=False):
        """Move the visible Smart Gizmo origin for the active modal operation.

        Used by the B-key snap-base workflow: the gizmo origin follows the
        chosen snap source while the transform is running, then the normal gizmo
        origin is restored in _end_modal().  This also installs a modal override
        so the overlay is drawn even when Smart G-R-S was started from a hotkey
        and the active tool is not a native transform tool.
        """
        if pivot_world is None:
            return False
        try:
            self._capture_smart_gizmo_modal_freeze_prev()
            axes = self._smart_gizmo_modal_freeze_axes(context)
            p = pivot_world.copy() if hasattr(pivot_world, 'copy') else mathutils.Vector(pivot_world)
            axes_tuple = tuple((a.copy() if hasattr(a, 'copy') else a) for a in axes)
            cg._SMART_GIZMO_FREEZE_ACTIVE = True
            cg._SMART_GIZMO_FROZEN_PIVOT = p.copy()
            cg._SMART_GIZMO_FROZEN_AXES = axes_tuple
            cg._SMART_GIZMO_MODAL_OVERRIDE_ACTIVE = True
            cg._SMART_GIZMO_MODAL_OVERRIDE_KIND = self._modal_smart_gizmo_kind(context)
            cg._SMART_GIZMO_MODAL_OVERRIDE_MODE = str(getattr(self, 'mode', '') or '').upper() or None
            cg._SMART_GIZMO_MODAL_OVERRIDE_PIVOT = p.copy()
            cg._SMART_GIZMO_MODAL_OVERRIDE_AXES = axes_tuple
            self._smart_gizmo_freeze_active = True
            if snap_base:
                self._snap_base_gizmo_freeze_active = True
            try:
                from . import csdt_gizmo as _smart_gizmo
                _smart_gizmo._smart_ensure_draw_handler()
            except Exception:
                pass
            try:
                cu._invalidate_gizmo_cache()
            except Exception:
                pass
            _tag_all_view3d_redraw()
            return True
        except Exception:
            return False

    def _begin_smart_gizmo_modal_freeze(self, context):
        """Freeze Smart Gizmo overlay center/axes while this modal rotate runs."""
        try:
            if str(getattr(self, 'mode', '') or '') != 'R':
                return False
            from . import csdt_gizmo as _smart_gizmo
            self._capture_smart_gizmo_modal_freeze_prev()
            pivot, axes = _smart_gizmo._smart_pivot_location_and_axes(context)
            if pivot is None or axes is None:
                pivot = getattr(self, 'pivot_3d', None)
                axes = (
                    self._get_constraint_axis(context, 0),
                    self._get_constraint_axis(context, 1),
                    self._get_constraint_axis(context, 2),
                    getattr(self, 'constraint_space', 'GLOBAL'),
                )
            if pivot is None or axes is None:
                return False
            return self._set_smart_gizmo_modal_freeze_pivot(context, pivot, snap_base=False)
        except Exception:
            return False

    def _clear_smart_gizmo_modal_freeze(self):
        try:
            if bool(getattr(self, '_smart_gizmo_freeze_active', False)) or bool(getattr(cg, '_SMART_GIZMO_FREEZE_ACTIVE', False)):
                prev = getattr(self, '_smart_gizmo_freeze_prev', (False, None, None))
                if prev and len(prev) == 3 and bool(prev[0]):
                    cg._SMART_GIZMO_FREEZE_ACTIVE = True
                    cg._SMART_GIZMO_FROZEN_PIVOT = prev[1]
                    cg._SMART_GIZMO_FROZEN_AXES = prev[2]
                else:
                    cg._SMART_GIZMO_FREEZE_ACTIVE = False
                    cg._SMART_GIZMO_FROZEN_PIVOT = None
                    cg._SMART_GIZMO_FROZEN_AXES = None
                cg._SMART_GIZMO_MODAL_OVERRIDE_ACTIVE = False
                cg._SMART_GIZMO_MODAL_OVERRIDE_KIND = None
                cg._SMART_GIZMO_MODAL_OVERRIDE_MODE = None
                cg._SMART_GIZMO_MODAL_OVERRIDE_PIVOT = None
                cg._SMART_GIZMO_MODAL_OVERRIDE_AXES = None
                self._smart_gizmo_freeze_active = False
                self._snap_base_gizmo_freeze_active = False
                self._smart_gizmo_freeze_prev_captured = False
                try:
                    cu._invalidate_gizmo_cache()
                except Exception:
                    pass
                _tag_all_view3d_redraw()
        except Exception:
            pass

    def _smart_gizmo_live_follow_capture(self, context):
        """Remember the gizmo pivot/axes of this baseline (data is at its initial state)."""
        if getattr(self, '_smart_gizmo_follow_base', None) is not None:
            return
        self._smart_gizmo_follow_base = False
        try:
            from . import csdt_gizmo as _smart_gizmo
            cu._invalidate_gizmo_cache()
            pivot, axes = _smart_gizmo._smart_pivot_location_and_axes(context)
            if pivot is None or not axes or len(axes) < 4:
                return
            self._smart_gizmo_follow_base = (
                mathutils.Vector(pivot).copy(),
                tuple(mathutils.Vector(axes[index]).normalized() for index in range(3)),
                str(axes[3] or 'GLOBAL'),
            )
        except Exception:
            self._smart_gizmo_follow_base = False

    def _smart_gizmo_live_follow_apply(self, context):
        """Keep the visible Smart Gizmo on the dragged selection in real time.

        G carries the pivot by the applied move.  A LOCAL rotate in Object Mode
        turns the visible axes with the rotated objects.  Everything else keeps
        the snapshot as built (pivot fixed for R/S, cursor pivot, snap base and
        slide are drawn by their own paths).
        """
        try:
            from . import csdt_gizmo as _smart_gizmo
        except Exception:
            return
        pivot = None
        axes = None
        try:
            base = getattr(self, '_smart_gizmo_follow_base', None)
            mode = str(getattr(self, 'mode', '') or '').upper()
            if base and not bool(getattr(self, '_snap_base_active', False)):
                base_pivot, base_axes, base_orient = base
                if mode == 'G' and not bool(getattr(self, '_smart_slide_active', False)):
                    pivot_mode = str(getattr(context.scene.tool_settings, 'transform_pivot_point', '') or '')
                    move = getattr(self, '_last_move', None)
                    if pivot_mode != 'CURSOR' and move is not None:
                        pivot = base_pivot + mathutils.Vector(move)
                elif mode == 'R' and base_orient == 'LOCAL' and str(getattr(context, 'mode', '') or '') == 'OBJECT':
                    obj = getattr(context, 'active_object', None)
                    rot = float(getattr(self, '_last_rot', 0.0) or 0.0)
                    rot_axis = getattr(self, '_last_rot_axis', None)
                    if obj is not None and obj.select_get() and rot_axis is not None and mathutils.Vector(rot_axis).length > 1.0e-8:
                        rotation = mathutils.Matrix.Rotation(rot, 3, mathutils.Vector(rot_axis).normalized())
                        axes = tuple(rotation @ axis for axis in base_axes)
        except Exception:
            pivot = None
            axes = None
        try:
            _smart_gizmo.smart_gizmo_live_follow_set(self, pivot, axes)
        except Exception:
            pass
        _tag_all_view3d_redraw()

    def _smart_gizmo_live_follow_stop(self, context, *, rebuild=False):
        try:
            from . import csdt_gizmo as _smart_gizmo
            _smart_gizmo.smart_gizmo_live_follow_reset(context, rebuild=rebuild)
        except Exception:
            pass

    def _snap_context_region(self, context):
        region = getattr(context, 'region', None) or getattr(self, '_region', None)
        rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
        return region, rv3d

    def _snap_visible_objects(self, context):
        try:
            return list(getattr(context, 'visible_objects', []) or [])
        except Exception:
            try:
                return list(getattr(context, 'scene', bpy.context.scene).objects)
            except Exception:
                return []

    def _snap_is_source_object(self, context, obj):
        try:
            if getattr(context, 'mode', '') != 'OBJECT' and obj in (getattr(context, 'objects_in_mode', []) or []):
                return True
        except Exception:
            pass
        try:
            return bool(obj and obj.select_get())
        except Exception:
            return False

    def _snap_iter_mesh_vertices_world(self, context, obj):
        if not obj or getattr(obj, 'type', None) != 'MESH':
            return
        mat = obj.matrix_world
        source_obj = self._snap_is_source_object(context, obj)
        try:
            if getattr(context, 'mode', '') == 'EDIT_MESH' and obj in (getattr(context, 'objects_in_mode', []) or []):
                bm = bmesh.from_edit_mesh(obj.data)
                for v in bm.verts:
                    yield mat @ v.co, bool(getattr(v, 'select', False)), source_obj
                return
        except Exception:
            pass
        try:
            for v in obj.data.vertices:
                yield mat @ v.co, bool(getattr(v, 'select', False)), source_obj
        except Exception:
            return

    def _snap_iter_mesh_edges_world(self, context, obj):
        if not obj or getattr(obj, 'type', None) != 'MESH':
            return
        mat = obj.matrix_world
        source_obj = self._snap_is_source_object(context, obj)
        try:
            if getattr(context, 'mode', '') == 'EDIT_MESH' and obj in (getattr(context, 'objects_in_mode', []) or []):
                bm = bmesh.from_edit_mesh(obj.data)
                for e in bm.edges:
                    if len(e.verts) >= 2:
                        yield mat @ e.verts[0].co, mat @ e.verts[1].co, bool(getattr(e, 'select', False)), source_obj
                return
        except Exception:
            pass
        try:
            verts = obj.data.vertices
            for e in obj.data.edges:
                yield mat @ verts[e.vertices[0]].co, mat @ verts[e.vertices[1]].co, bool(getattr(e, 'select', False)), source_obj
        except Exception:
            return

    def _snap_iter_lattice_points_world(self, context, obj):
        if not obj or getattr(obj, 'type', None) != 'LATTICE':
            return
        mat = obj.matrix_world
        source_obj = self._snap_is_source_object(context, obj)
        try:
            for p in obj.data.points:
                sel = any(bool(getattr(p, name, False)) for name in ('select', 'select_u', 'select_v', 'select_w'))
                yield mat @ p.co_deform, sel, source_obj
        except Exception:
            return

    def _snap_screen_distance_sq(self, region, rv3d, point, mouse):
        try:
            p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, point)
            if p2 is None:
                return None
            return (mathutils.Vector((float(p2.x), float(p2.y))) - mouse).length_squared
        except Exception:
            return None

    def _snap_screen_candidate_from_mouse(self, context, mx, my, *, prefer_source=True, allow_vertices=True, allow_edges=True, allow_custom=True, allow_faces=True):
        """Return a Blender-like snap candidate using screen-space priority.

        Priority follows standard transform expectations for a base/source point:
        selected/source vertices first, then other vertices, custom points, edges,
        and only then face/raycast fallback.  Vertex candidates are evaluated
        before edges so an edge endpoint can still be picked precisely.
        """
        region, rv3d = self._snap_context_region(context)
        if region is None or rv3d is None:
            return None
        try:
            mouse = mathutils.Vector((float(mx), float(my)))
        except Exception:
            return None
        try:
            prefs = _prefs(context)
            scale = float(getattr(prefs, 'smart_gizmo_screen_scale', 1.0) if prefs else 1.0)
        except Exception:
            scale = 1.0
        scale = max(0.5, min(scale, 2.5))
        # Match Blender's snap-base pick feel: endpoints/vertices must win over
        # edge projections.  Use the user-visible Sensitivity / Hit Range values
        # while keeping a small vertex-priority halo above the edge radius.
        try:
            edge_pref = float(getattr(prefs, 'edge_hit_radius', 20.0) if prefs else 20.0)
        except Exception:
            edge_pref = 20.0
        try:
            vert_pref = float(getattr(prefs, 'vert_hit_radius', 20.0) if prefs else 20.0)
        except Exception:
            vert_pref = 20.0
        edge_pref = max(4.0, min(edge_pref, 96.0))
        vert_pref = max(edge_pref + 4.0, min(max(4.0, vert_pref), 112.0))
        vertex_r = vert_pref * scale
        edge_r = edge_pref * scale
        custom_r = vertex_r
        vertex_r2 = vertex_r * vertex_r
        edge_r2 = edge_r * edge_r
        custom_r2 = custom_r * custom_r

        source_vertex = None
        source_vertex_d = None
        vertex = None
        vertex_d = None
        if allow_vertices:
            for obj in self._snap_visible_objects(context):
                for co, selected, source_obj in self._snap_iter_mesh_vertices_world(context, obj) or []:
                    d = self._snap_screen_distance_sq(region, rv3d, co, mouse)
                    if d is None or d > vertex_r2:
                        continue
                    is_source = bool(prefer_source and (selected or source_obj))
                    if is_source:
                        if source_vertex_d is None or d < source_vertex_d:
                            source_vertex = co.copy(); source_vertex_d = d
                    elif vertex_d is None or d < vertex_d:
                        vertex = co.copy(); vertex_d = d
                for co, selected, source_obj in self._snap_iter_lattice_points_world(context, obj) or []:
                    d = self._snap_screen_distance_sq(region, rv3d, co, mouse)
                    if d is None or d > vertex_r2:
                        continue
                    is_source = bool(prefer_source and (selected or source_obj))
                    if is_source:
                        if source_vertex_d is None or d < source_vertex_d:
                            source_vertex = co.copy(); source_vertex_d = d
                    elif vertex_d is None or d < vertex_d:
                        vertex = co.copy(); vertex_d = d
            if source_vertex is not None:
                return source_vertex
            if vertex is not None:
                return vertex

        custom_point = None
        custom_d = None
        if allow_custom:
            try:
                for p in list(getattr(self, '_custom_snap_points', []) or []):
                    d = self._snap_screen_distance_sq(region, rv3d, p, mouse)
                    if d is not None and d <= custom_r2 and (custom_d is None or d < custom_d):
                        custom_point = p.copy(); custom_d = d
            except Exception:
                custom_point = None
        if custom_point is not None:
            return custom_point

        source_edge = None
        source_edge_d = None
        edge_point = None
        edge_d = None
        if allow_edges:
            for obj in self._snap_visible_objects(context):
                for a, b, selected, source_obj in self._snap_iter_mesh_edges_world(context, obj) or []:
                    try:
                        a2 = view3d_utils.location_3d_to_region_2d(region, rv3d, a)
                        b2 = view3d_utils.location_3d_to_region_2d(region, rv3d, b)
                        if a2 is None or b2 is None:
                            continue
                        av = mathutils.Vector((float(a2.x), float(a2.y)))
                        bv = mathutils.Vector((float(b2.x), float(b2.y)))
                        seg = bv - av
                        seg_len_sq = seg.length_squared
                        if seg_len_sq <= 1.0e-12:
                            continue
                        t = max(0.0, min(1.0, (mouse - av).dot(seg) / seg_len_sq))
                        closest = av + seg * t
                        d = (closest - mouse).length_squared
                        if d > edge_r2:
                            continue
                        co = a.lerp(b, t)
                        is_source = bool(prefer_source and (selected or source_obj))
                        if is_source:
                            if source_edge_d is None or d < source_edge_d:
                                source_edge = co.copy(); source_edge_d = d
                        elif edge_d is None or d < edge_d:
                            edge_point = co.copy(); edge_d = d
                    except Exception:
                        continue
            if source_edge is not None:
                return source_edge
            if edge_point is not None:
                return edge_point

        if allow_faces:
            try:
                rc = self._raycast_world(context, mx, my)
                if rc:
                    return rc[0].copy()
            except Exception:
                pass
        return None

    def _snap_point_candidate_from_mouse(self, context, event):
        mx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0))
        my = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0))
        # A / Add Snap Point is target-oriented. Use pure screen priority so
        # exact vertices/control points win over edge projections even when a
        # selected/source edge is also under the cursor.
        return self._snap_screen_candidate_from_mouse(context, mx, my, prefer_source=False, allow_vertices=True, allow_edges=True, allow_custom=False, allow_faces=True)

    def _snap_base_candidate_from_mouse(self, context, event):
        mx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0))
        my = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0))
        try:
            # Snap Base is a source-point picker.  Prefer existing vertices,
            # edges, and custom points; do not replace them with arbitrary face
            # raycast points while B is being held.
            p = self._snap_screen_candidate_from_mouse(context, mx, my, prefer_source=True, allow_vertices=True, allow_edges=True, allow_custom=True, allow_faces=False)
            if p is not None:
                return p.copy()
        except Exception:
            pass
        return self._mouse_world_point_on_pivot_plane(context, mx, my)

    def _current_snap_base_point(self):
        try:
            base = getattr(self, '_snap_base_3d', None)
            if base is not None:
                return base.copy()
        except Exception:
            pass
        try:
            return self.pivot_3d.copy()
        except Exception:
            return mathutils.Vector((0.0, 0.0, 0.0))

    def _reset_snap_base_to_pivot(self):
        try:
            self._snap_base_3d = None
            self._snap_base_offset_3d = None
            self._snap_base_active = False
            self._snap_base_force_target_snap = False
        except Exception:
            pass

    def _begin_snap_base_pick(self, context, event):
        """Enter an in-modal snap-base pick state.

        This mirrors Blender's B snap-base workflow inside Smart G-R-S: the
        transform remains live, an orange marker follows the mouse, and LMB or
        Enter confirms the base without leaving the modal operator.
        """
        try:
            self._snap_base_pick_active = True
            self._snap_base_candidate_3d = None
            self._snap_base_candidate_2d = None
            self._update_snap_base_candidate(context, event)
            self._status_text_update(context)
            return True
        except Exception:
            return False

    def _update_snap_base_candidate(self, context, event):
        try:
            self.last_cx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0))
            self.last_cy = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0))
        except Exception:
            pass
        p = self._snap_base_candidate_from_mouse(context, event)
        if p is None:
            try:
                p = getattr(self, 'current_pivot_3d', self.pivot_3d).copy()
            except Exception:
                p = None
        try:
            self._snap_base_candidate_3d = p.copy() if p is not None else None
            if p is not None:
                region = getattr(context, 'region', None) or getattr(self, '_region', None)
                rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
                self._snap_base_candidate_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p) if region and rv3d else None
            else:
                self._snap_base_candidate_2d = None
            return p is not None
        except Exception:
            self._snap_base_candidate_3d = None
            self._snap_base_candidate_2d = None
            return False

    def _add_unique_custom_snap_point(self, point, *, eps=1.0e-6):
        if point is None:
            return False
        try:
            pts = getattr(self, '_custom_snap_points', None)
            if pts is None:
                pts = []
                self._custom_snap_points = pts
            p = point.copy()
            for q in list(pts):
                try:
                    if (p - q).length <= eps:
                        return False
                except Exception:
                    continue
            pts.append(p)
            return True
        except Exception:
            return False

    def _snap_base_display_point_from_move(self, move=None):
        try:
            base = getattr(self, '_snap_base_3d', None)
            if base is None:
                return None
            p = base.copy()
            if move is not None:
                p = p + (move.copy() if hasattr(move, 'copy') else mathutils.Vector(move))
            return p
        except Exception:
            return None

    def _sync_snap_base_gizmo_pivot(self, context, move=None):
        """Place the temporary Smart Gizmo origin at the active snap source.

        During a B-key snap-base transform the snap source, not the original
        selection pivot, is what should visually snap to targets.  The freeze is
        cleared only when the modal transform finishes.
        """
        try:
            if not bool(getattr(self, '_snap_base_active', False)):
                return False
            point = self._snap_base_display_point_from_move(move)
            if point is None:
                return False
            self.current_pivot_3d = point.copy()
            return self._set_smart_gizmo_modal_freeze_pivot(context, point, snap_base=True)
        except Exception:
            return False

    def _sync_snap_base_gizmo_to_base(self, context):
        try:
            point = getattr(self, '_snap_base_3d', None)
            if point is None:
                return False
            self.current_pivot_3d = point.copy()
            return self._set_smart_gizmo_modal_freeze_pivot(context, point, snap_base=True)
        except Exception:
            return False

    def _commit_snap_base_point(self, context, point, event=None):
        if point is None:
            return False
        try:
            if event is not None:
                self.last_cx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0))
                self.last_cy = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0))
            self._restart_baseline_from_current(context)
            self._snap_base_3d = point.copy()
            try:
                self._snap_base_offset_3d = point.copy() - self.pivot_3d
            except Exception:
                self._snap_base_offset_3d = None
            # After B confirms, the selected point is the active snap source.
            # Force target snapping until the modal ends and move the visible
            # Smart Gizmo origin to that source point.  As the transform moves,
            # _sync_snap_base_gizmo_pivot keeps the gizmo at source+delta, so the
            # displayed handle is the exact location being snapped.
            self._snap_base_active = True
            self._snap_base_force_target_snap = True
            self._snap_base_pick_active = False
            self._snap_base_candidate_3d = None
            self._snap_base_candidate_2d = None
            self._add_unique_custom_snap_point(point)
            self.current_pivot_3d = point.copy()
            self._set_smart_gizmo_modal_freeze_pivot(context, point, snap_base=True)
            try:
                # Make the B-release feedback immediate.  A following transform
                # update may move the source to base+delta, but the overlay must
                # visibly jump to the chosen source point as soon as the key is
                # released, even if no MOUSEMOVE arrives.
                self._sync_snap_base_gizmo_to_base(context)
            except Exception:
                pass
            self._status_text_update(context)
            return True
        except Exception:
            try:
                self._snap_base_3d = point.copy()
                self._snap_base_active = True
                self._snap_base_force_target_snap = True
                self._snap_base_pick_active = False
                self._snap_base_candidate_3d = None
                self._snap_base_candidate_2d = None
                self._add_unique_custom_snap_point(point)
                self.current_pivot_3d = point.copy()
                self._set_smart_gizmo_modal_freeze_pivot(context, point, snap_base=True)
                try:
                    self._sync_snap_base_gizmo_to_base(context)
                except Exception:
                    pass
                self._status_text_update(context)
                return True
            except Exception:
                return False

    def _commit_snap_base_pick(self, context, event=None):
        if event is not None:
            # Always sample the release/confirm mouse coordinate.  Very short B
            # holds can otherwise commit the press position if Blender did not
            # emit an intermediate MOUSEMOVE before the key release.
            try:
                self._update_snap_base_candidate(context, event)
            except Exception:
                pass
        point = getattr(self, '_snap_base_candidate_3d', None)
        if point is None and event is not None:
            self._update_snap_base_candidate(context, event)
            point = getattr(self, '_snap_base_candidate_3d', None)
        return self._commit_snap_base_point(context, point, event)

    def _cancel_snap_base_pick(self, context=None):
        try:
            self._snap_base_pick_active = False
            self._snap_base_candidate_3d = None
            self._snap_base_candidate_2d = None
            if context is not None:
                self._status_text_update(context)
            return True
        except Exception:
            return False

    def _set_snap_base_from_mouse(self, context, event):
        """Compatibility helper: set the snap base immediately."""
        p = self._snap_base_candidate_from_mouse(context, event)
        if p is None:
            try:
                p = getattr(self, 'current_pivot_3d', self.pivot_3d).copy()
            except Exception:
                return False
        return self._commit_snap_base_point(context, p, event)

    def _add_snap_point_from_mouse(self, context, event):
        # A / Add Snap Point uses the same target acquisition priority as B:
        # exact vertices/control points first, then edge interpolation, then faces.
        p = self._snap_point_candidate_from_mouse(context, event)
        if p is None:
            return False
        try:
            self._add_unique_custom_snap_point(p)
            self._status_text_update(context)
            return True
        except Exception:
            return False

    def _remove_snap_point_from_mouse(self, context, event):
        pts = getattr(self, '_custom_snap_points', None)
        if not pts:
            return False
        try:
            mx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0))
            my = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0))
            region = getattr(context, 'region', None) or getattr(self, '_region', None)
            rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
            if region is None or rv3d is None:
                pts.pop()
                return True
            mouse = mathutils.Vector((float(mx), float(my)))
            best_i = None
            best_d = None
            for i, p in enumerate(list(pts)):
                p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, p)
                if p2 is None:
                    continue
                d = (mathutils.Vector((p2.x, p2.y)) - mouse).length_squared
                if best_d is None or d < best_d:
                    best_d = d
                    best_i = i
            if best_i is None:
                best_i = len(pts) - 1
            pts.pop(best_i)
            self._status_text_update(context)
            return True
        except Exception:
            try:
                pts.pop()
                return True
            except Exception:
                return False

    def _custom_snap_point_for_mouse(self, context, mx, my):
        pts = getattr(self, '_custom_snap_points', None)
        if not pts:
            return None
        try:
            region = getattr(context, 'region', None) or getattr(self, '_region', None)
            rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
            if region is None or rv3d is None:
                return pts[-1].copy()
            mouse = mathutils.Vector((float(mx), float(my)))
            best = None
            for p in pts:
                p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, p)
                if p2 is None:
                    continue
                d = (mathutils.Vector((p2.x, p2.y)) - mouse).length_squared
                if best is None or d < best[0]:
                    best = (d, p)
            if best is not None:
                return best[1].copy()
        except Exception:
            pass
        try:
            return pts[-1].copy()
        except Exception:
            return None

    def _middle_mouse_auto_constraint(self, context, mouse_vec, *, force_plane=False):
        """Return (kind, idx) for middle-mouse auto axis / plane constraints.

        Plane candidates evaluate every sign combination of the two projected
        axes in each plane. This keeps XY/XZ/YZ plane detection active on both
        the + and - sides instead of leaving dead zones between projected axes.
        """
        try:
            mv = mathutils.Vector((float(mouse_vec.x), float(mouse_vec.y)))
            if mv.length <= 1e-8:
                return ('NONE', -1)
            mv.normalize()

            region = getattr(context, 'region', None) or getattr(self, '_region', None)
            rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
            if region is None or rv3d is None:
                return ('NONE', -1)
            pivot_2d = self._smart_gizmo_project_location_visible_2d(context, self.pivot_3d)
            if pivot_2d is None:
                return ('NONE', -1)

            axes_2d = {}
            for i in range(3):
                axis3d = self._get_constraint_axis(context, i)
                tip_2d = self._smart_gizmo_project_location_visible_2d(context, self.pivot_3d + axis3d)
                if tip_2d is None:
                    continue
                d = mathutils.Vector((float(tip_2d.x - pivot_2d.x), float(tip_2d.y - pivot_2d.y)))
                if d.length <= 1e-8:
                    continue
                d.normalize()
                axes_2d[i] = d

            if not axes_2d:
                return ('NONE', -1)

            axis_idx = -1
            axis_score = -1.0
            for i, d in axes_2d.items():
                score = abs(float(mv.dot(d)))
                if score > axis_score:
                    axis_score = score
                    axis_idx = i

            plane_idx = -1
            plane_score = -1.0
            if len(axes_2d) >= 2:
                for excluded in (0, 1, 2):
                    keep = [i for i in (0, 1, 2) if i != excluded and i in axes_2d]
                    if len(keep) != 2:
                        continue
                    a = axes_2d[keep[0]]
                    b = axes_2d[keep[1]]
                    for sa in (1.0, -1.0):
                        for sb in (1.0, -1.0):
                            cand = (a * sa) + (b * sb)
                            if cand.length <= 1e-8:
                                continue
                            cand.normalize()
                            score = float(mv.dot(cand))
                            if score > plane_score:
                                plane_score = score
                                plane_idx = excluded

            if force_plane and plane_idx in (0, 1, 2):
                return ('PLANE', plane_idx)

            try:
                prefs = _prefs(context)
                enable_plane = bool(getattr(prefs, 'enable_middle_mouse_plane', True)) if prefs else True
            except Exception:
                enable_plane = True

            if enable_plane and plane_idx in (0, 1, 2) and plane_score > (axis_score + 1.0e-5):
                return ('PLANE', plane_idx)

            if axis_idx in (0, 1, 2):
                return ('AXIS', axis_idx)
            if plane_idx in (0, 1, 2):
                return ('PLANE', plane_idx)
            return ('NONE', -1)
        except Exception:
            return ('NONE', -1)

    def _switch_modal_transform_mode(self, context, event, new_mode):
        new_mode = str(new_mode or '').upper()
        if new_mode not in {'G', 'R', 'S'}:
            return False
        try:
            if getattr(self, 'mode', '') == new_mode:
                return True
            self._restore_initial_state(context)
            self._smart_gizmo_live_follow_stop(context, rebuild=True)
            self.mode = new_mode
            self._reset_constraint()
            self.last_cx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0))
            self.last_cy = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0))
            self.start_region_x = self.last_cx
            self.start_region_y = self.last_cy
            region = getattr(context, 'region', None) or getattr(self, '_region', None)
            rv3d = getattr(context, 'region_data', None) or getattr(self, '_rv3d', None)
            p2d = self._smart_gizmo_project_location_visible_2d(context, self.pivot_3d) if region and rv3d else None
            self.pivot_2d = p2d if p2d else mathutils.Vector(((getattr(region, 'width', 1) or 1) * 0.5, (getattr(region, 'height', 1) or 1) * 0.5))
            if new_mode == 'R':
                self.start_angle = math.atan2(self.last_cy - self.pivot_2d.y, self.last_cx - self.pivot_2d.x)
                self._rotation_offset_rad = 0.0
                self._circular_rotation_accum_rad = 0.0
                self._circular_rotation_prev_angle = float(self.start_angle)
                self._clear_rotation_snap_anchor()
                self._free_rotation_offset_q = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
                self._free_rotation_accum_q = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
                self._free_rotation_start_vec = None
                self._free_rotation_prev_vec = None
                if self._use_free_axis_rotation():
                    self._reset_free_rotation_baseline(context, self.last_cx, self.last_cy, keep_current=False, sens=1.0)
            elif new_mode == 'S':
                self.start_vec2 = mathutils.Vector((self.last_cx - self.pivot_2d.x, self.last_cy - self.pivot_2d.y))
                self.start_dist = max(self.start_vec2.length, 0.001)
                self.start_dir2 = self.start_vec2.normalized() if self.start_vec2.length > 1e-8 else mathutils.Vector((1.0, 0.0))
                self._smart_gizmo_scale_delta_mode = False
                if not self._use_gizmo_distance_scale(context):
                    self._screen_coordinate_scale_base_px = 0.0
                    self._prepare_screen_coordinate_scale_baseline(context, self.last_cx, self.last_cy, self._get_sens(_prefs(context), 'S', self._event_shift_active(event)), preserve_current=False)
                else:
                    self.start_scale_signed = float(self._scale_signed_distance(context, self.last_cx, self.last_cy))
                    self.start_scale_base = max(abs(self.start_scale_signed), 0.001)
            self._last_move = mathutils.Vector((0, 0, 0))
            self._last_rot = 0.0
            self._last_rot_axis = mathutils.Vector((0, 0, 1))
            self._last_scale = 1.0
            self._last_scale_components = mathutils.Vector((1, 1, 1))
            self._apply_current_transform(context, self.last_cx, self.last_cy, self._event_shift_active(event))
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._status_text_update(context)
            return True
        except Exception:
            return False

    def _toggle_edit_mesh_slide_mode(self, context, event=None):
        """Toggle a Smart G-R-S local slide mode without invoking native modal ops."""
        try:
            if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
                return False
            self._smart_slide_active = not bool(getattr(self, '_smart_slide_active', False))
            self.last_cx = getattr(event, 'mouse_region_x', getattr(self, 'last_cx', 0)) if event else getattr(self, 'last_cx', 0)
            self.last_cy = getattr(event, 'mouse_region_y', getattr(self, 'last_cy', 0)) if event else getattr(self, 'last_cy', 0)
            self._restart_baseline_from_current(context)
            self._status_text_update(context)
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            return True
        except Exception:
            return False

    def _apply_edit_mesh_smart_slide_move(self, context, move_world):
        try:
            if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH':
                return False
            vstore = getattr(self, '_edit_verts', None) or {}
            if not vstore:
                return False
            any_changed = False
            use_prop = is_prop_enabled(context)
            prop_size = float(getattr(context.tool_settings, 'proportional_size', 0.0))
            falloff = getattr(context.tool_settings, 'proportional_edit_falloff', 'SMOOTH')
            prefs = _prefs(context)
            profile = getattr(prefs, 'prop_falloff_profile', 'BLENDER') if prefs else 'BLENDER'
            for obj, vmap in list(vstore.items()):
                if not obj or obj.name not in bpy.data.objects or obj.type != 'MESH' or obj.mode != 'EDIT':
                    continue
                try:
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.verts.ensure_lookup_table()
                    inv3 = obj.matrix_world.inverted_safe().to_3x3()
                    move_local = inv3 @ move_world
                    selected_indices = {int(idx) for idx, (_co, dist) in vmap.items() if float(dist) == 0.0}
                    if move_local.length < 1.0e-12:
                        for idx, (orig_co, _dist) in vmap.items():
                            idx = int(idx)
                            if 0 <= idx < len(bm.verts):
                                bm.verts[idx].co = orig_co.copy()
                        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                        continue
                    for idx, (orig_co, dist) in vmap.items():
                        idx = int(idx)
                        if idx < 0 or idx >= len(bm.verts):
                            continue
                        v = bm.verts[idx]
                        dist = float(dist)
                        if dist != 0.0 and not (use_prop and dist < prop_size):
                            v.co = orig_co.copy()
                            continue
                        dirs = []
                        for e in v.link_edges:
                            try:
                                ov = e.other_vert(v)
                                if int(getattr(ov, 'index', -1)) in selected_indices:
                                    continue
                                d = ov.co - orig_co
                                if d.length > 1.0e-10:
                                    dirs.append(d.normalized())
                            except Exception:
                                pass
                        if not dirs:
                            for e in v.link_edges:
                                try:
                                    ov = e.other_vert(v)
                                    d = ov.co - orig_co
                                    if d.length > 1.0e-10:
                                        dirs.append(d.normalized())
                                except Exception:
                                    pass
                        if dirs:
                            best = max(dirs, key=lambda d: abs(float(move_local.dot(d))))
                            dloc = best * float(move_local.dot(best))
                        else:
                            dloc = move_local
                        if dist == 0.0:
                            v.co = orig_co + dloc
                            any_changed = True
                        else:
                            weight = get_proportional_weight(dist, prop_size, falloff, profile)
                            v.co = orig_co.lerp(orig_co + dloc, weight)
                            any_changed = True
                    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
                except Exception:
                    continue
            return any_changed
        except Exception:
            return False

    def _view3d_grid_increment_step(self, context, precision=False) -> float:
        step = 1.0
        try:
            space = getattr(context, 'space_data', None)
            if getattr(space, 'type', None) != 'VIEW_3D':
                area = getattr(self, '_area', None) or getattr(context, 'area', None)
                if area is not None and getattr(area, 'type', None) == 'VIEW_3D':
                    space = getattr(getattr(area, 'spaces', None), 'active', None)
            overlay = getattr(space, 'overlay', None) if space is not None else None
            grid_scale = float(getattr(overlay, 'grid_scale', 1.0) if overlay is not None else 1.0)
            if grid_scale > 0.0:
                step = grid_scale
            if precision:
                subdivisions = int(getattr(overlay, 'grid_subdivisions', 10) if overlay is not None else 10)
                if subdivisions > 1:
                    step = step / float(subdivisions)
                else:
                    step = step * 0.1
        except Exception:
            step = 0.1 if precision else 1.0
        return max(float(step), 0.000001)

    def _rotation_increment_step_rad(self, context, precision=False) -> float:
        try:
            ts = context.scene.tool_settings
            attr = 'snap_angle_increment_3d_precision' if precision else 'snap_angle_increment_3d'
            step = float(getattr(ts, attr))
        except Exception:
            step = math.radians(1.0 if precision else 5.0)
        if step <= 0.0:
            step = math.radians(1.0 if precision else 5.0)
        return float(step)

    def _scale_increment_step(self, context, precision=False) -> float:
        prefs = _prefs(context)
        try:
            step = float(getattr(prefs, 'snap_scale_step', 0.1) if prefs else 0.1)
        except Exception:
            step = 0.1
        if precision:
            step *= 0.1
        return max(float(step), 0.000001)

    def _move_grid_absolute_enabled(self, context) -> bool:
        try:
            return bool(getattr(context.scene.tool_settings, 'use_snap_grid_absolute', False))
        except Exception:
            return False

    def _apply_world_matrix(self, context, M_world):
        use_prop = is_prop_enabled(context)
        prop_size = context.tool_settings.proportional_size
        falloff = context.tool_settings.proportional_edit_falloff
        prefs = _prefs(context)
        profile = getattr(prefs, 'prop_falloff_profile', 'BLENDER') if prefs else 'BLENDER'

        if self._edit_verts:
            for obj, vmap in self._edit_verts.items():
                if not obj or obj.name not in bpy.data.objects or obj.type != 'MESH' or obj.mode != 'EDIT':
                    continue
                inv = obj.matrix_world.inverted_safe()
                M_local = inv @ M_world @ obj.matrix_world
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                
                for idx, (orig_co, dist) in vmap.items():
                    if idx < len(bm.verts):
                        v = bm.verts[idx]
                        if dist == 0.0:
                            v.co = (M_local @ orig_co.to_4d()).to_3d()
                        elif use_prop and dist < prop_size:
                            weight = get_proportional_weight(dist, prop_size, falloff, profile)
                            target_co = (M_local @ orig_co.to_4d()).to_3d()
                            v.co = orig_co.lerp(target_co, weight)
                        else:
                            v.co = orig_co.copy()
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        elif getattr(self, "_edit_lattice_points", None):
            for obj, pmap in getattr(self, "_edit_lattice_points", {}).items():
                if not obj or obj.name not in bpy.data.objects or obj.type != 'LATTICE' or obj.mode != 'EDIT':
                    continue
                inv = obj.matrix_world.inverted_safe()
                M_local = inv @ M_world @ obj.matrix_world
                try:
                    points = obj.data.points
                    for idx, (orig_co, dist) in pmap.items():
                        if idx >= len(points):
                            continue
                        if dist == 0.0:
                            points[idx].co_deform = (M_local @ orig_co.to_4d()).to_3d()
                        elif use_prop and dist < prop_size:
                            weight = get_proportional_weight(dist, prop_size, falloff, profile)
                            target_co = (M_local @ orig_co.to_4d()).to_3d()
                            points[idx].co_deform = orig_co.lerp(target_co, weight)
                        else:
                            points[idx].co_deform = orig_co.copy()
                    try:
                        obj.data.update_tag()
                    except Exception:
                        pass
                except Exception:
                    continue
        elif getattr(self, "_edit_curve_points", None):
            for obj, cmap in getattr(self, "_edit_curve_points", {}).items():
                if not obj or obj.name not in bpy.data.objects or obj.type not in {'CURVE', 'SURFACE'} or obj.mode != 'EDIT':
                    continue
                inv = obj.matrix_world.inverted_safe()
                M_local = inv @ M_world @ obj.matrix_world
                try:
                    for key, (orig_co, dist) in cmap.items():
                        if dist == 0.0:
                            target_co = (M_local @ orig_co.to_4d()).to_3d()
                        elif use_prop and dist < prop_size:
                            weight = get_proportional_weight(dist, prop_size, falloff, profile)
                            target_raw = (M_local @ orig_co.to_4d()).to_3d()
                            target_co = orig_co.lerp(target_raw, weight)
                        else:
                            target_co = orig_co.copy()
                        _curve_component_set(obj, key, target_co)
                except Exception:
                    continue
        elif getattr(self, "_edit_armature_points", None):
            for obj, amap in getattr(self, "_edit_armature_points", {}).items():
                if not obj or obj.name not in bpy.data.objects or obj.type != 'ARMATURE' or obj.mode != 'EDIT':
                    continue
                inv = obj.matrix_world.inverted_safe()
                M_local = inv @ M_world @ obj.matrix_world
                try:
                    bones = obj.data.edit_bones
                    for name, entry in amap.items():
                        bone = bones.get(name)
                        if not bone:
                            continue
                        parts = set(entry.get('parts', set()))
                        bone.head = (M_local @ entry['head'].to_4d()).to_3d() if 'head' in parts else entry['head'].copy()
                        bone.tail = (M_local @ entry['tail'].to_4d()).to_3d() if 'tail' in parts else entry['tail'].copy()
                        try:
                            bone.roll = float(entry.get('roll', bone.roll))
                        except Exception:
                            pass
                except Exception:
                    continue
        elif getattr(self, "_pose_bone_mats", None):
            for obj, pmap in getattr(self, "_pose_bone_mats", {}).items():
                if not obj or obj.name not in bpy.data.objects or obj.type != 'ARMATURE':
                    continue
                inv = obj.matrix_world.inverted_safe()
                M_local = inv @ M_world @ obj.matrix_world
                try:
                    for name, entry in pmap.items():
                        pbone = obj.pose.bones.get(name) if getattr(obj, 'pose', None) else None
                        if not pbone:
                            continue
                        orig_mat = entry.get('matrix') if isinstance(entry, dict) else entry
                        target_mat = M_local @ orig_mat
                        try:
                            pbone.matrix = target_mat
                            # PoseBone.matrix assignment is evaluated lazily in
                            # Blender 5.1; force depsgraph update so Smart G-R-S
                            # previews and tests read the transformed pose right away.
                            bpy.context.view_layer.update()
                        except Exception:
                            pass
                        try:
                            if (pbone.matrix.translation - target_mat.translation).length > 1e-5:
                                # Fallback for constrained or not-yet-evaluated simple pose bones.
                                if pbone.parent is not None:
                                    pbone.matrix_basis = pbone.parent.matrix.inverted_safe() @ target_mat
                                else:
                                    pbone.matrix_basis = target_mat.copy()
                                bpy.context.view_layer.update()
                        except Exception:
                            pass
                    try:
                        obj.update_tag()
                        obj.data.update_tag()
                        bpy.context.view_layer.update()
                    except Exception:
                        pass
                except Exception:
                    continue
        elif getattr(self, "_edit_metaball_elements", None):
            for obj, mmap in getattr(self, "_edit_metaball_elements", {}).items():
                if not obj or obj.name not in bpy.data.objects or obj.type != 'META' or obj.mode != 'EDIT':
                    continue
                inv = obj.matrix_world.inverted_safe()
                M_local = inv @ M_world @ obj.matrix_world
                try:
                    elems = obj.data.elements
                    for idx, (orig_co, _dist) in mmap.items():
                        if idx < len(elems):
                            elems[idx].co = (M_local @ orig_co.to_4d()).to_3d()
                    try:
                        obj.data.update_tag()
                    except Exception:
                        pass
                except Exception:
                    continue
        else:
            for obj, (orig_mat, dist) in self._obj_mats.items():
                if obj and obj.name in bpy.data.objects:
                    if dist == 0.0:
                        obj.matrix_world = M_world @ orig_mat
                    elif use_prop and dist < prop_size:
                        weight = get_proportional_weight(dist, prop_size, falloff, profile)
                        target_mat = M_world @ orig_mat
                        loc1, rot1, sca1 = orig_mat.decompose()
                        loc2, rot2, sca2 = target_mat.decompose()
                        obj.matrix_world = mathutils.Matrix.LocRotScale(
                            loc1.lerp(loc2, weight),
                            rot1.slerp(rot2, weight),
                            sca1.lerp(sca2, weight)
                        )
                    else:
                        obj.matrix_world = orig_mat.copy()

    def _preserve_object_euler_full_turns(self, context, rot_axis, rot_angle: float) -> None:
        """Keep Object Mode Euler channels unwrapped for multi-turn rotation.

        Matrix assignment alone cannot store a 360-degree turn count because the
        matrix for 450° is identical to 90°.  After the matrix has been applied
        for the actual transform, add only whole 2π turns to the relevant Euler
        channel so the visible rotation value continues past ±360° while the
        transform matrix remains unchanged.
        """
        try:
            if str(getattr(context, 'mode', '') or '') != 'OBJECT':
                return
            if str(getattr(self, 'constraint_kind', 'NONE') or 'NONE') != 'AXIS':
                return
            idx = int(getattr(self, 'constraint_idx', -1))
            if idx not in (0, 1, 2):
                return
            tau = 2.0 * math.pi
            rot_angle = float(rot_angle)
            if abs(rot_angle) < 1e-12:
                return
            initial = getattr(self, '_obj_initial_rotation_euler', {}) or {}
            for obj, (_orig_mat, dist) in getattr(self, '_obj_mats', {}).items():
                if not obj or obj.name not in bpy.data.objects or float(dist) != 0.0:
                    continue
                try:
                    rmode = str(getattr(obj, 'rotation_mode', '') or '')
                    if rmode in {'QUATERNION', 'AXIS_ANGLE'} or not hasattr(obj, 'rotation_euler'):
                        continue
                    info = initial.get(obj)
                    if not info:
                        continue
                    start_mode, start_euler = info
                    if str(start_mode) != rmode:
                        continue
                    cur = obj.rotation_euler.copy()
                    target = float(start_euler[idx]) + rot_angle
                    turns = round((target - float(cur[idx])) / tau)
                    if turns:
                        cur[idx] = float(cur[idx]) + float(turns) * tau
                        obj.rotation_euler = cur
                except Exception:
                    continue
        except Exception:
            pass

    def _object_individual_origins_mode(self, context) -> bool:
        """True when Object Mode rotate/scale must use each object's origin.

        Smart G-R-S can route through custom rotation/scale algorithms for screen
        coordinate rotation, positive-only scaling, and smart gizmo drags.  Those
        custom paths must still match Blender's standard Transform Pivot Point
        behavior: with Individual Origins, each selected object rotates/scales
        around its own object origin instead of around the common modal pivot.
        """
        try:
            if str(getattr(context, 'mode', '') or '') != 'OBJECT':
                return False
            pivot = str(getattr(self, 'pivot_mode_current', '') or getattr(context.scene.tool_settings, 'transform_pivot_point', '') or '')
            if pivot != 'INDIVIDUAL_ORIGINS':
                return False
            return bool(getattr(self, '_obj_mats', None))
        except Exception:
            return False

    def _apply_object_individual_world_matrix(self, context, matrix_factory):
        """Apply world deltas per selected object origin.

        matrix_factory(origin_world, obj, orig_matrix) returns a 4x4 world-space
        delta matrix.  Selected objects get that delta around their own origin;
        proportional non-selected objects keep the common-pivot falloff path so
        object proportional editing remains spatially stable.
        """
        try:
            use_prop = is_prop_enabled(context)
            prop_size = context.tool_settings.proportional_size
            falloff = context.tool_settings.proportional_edit_falloff
        except Exception:
            use_prop = False
            prop_size = 0.0
            falloff = 'SMOOTH'
        prefs = _prefs(context)
        profile = getattr(prefs, 'prop_falloff_profile', 'BLENDER') if prefs else 'BLENDER'
        any_changed = False
        for obj, (orig_mat, dist) in getattr(self, '_obj_mats', {}).items():
            if not obj or obj.name not in bpy.data.objects:
                continue
            try:
                if dist == 0.0:
                    origin = orig_mat.translation.copy()
                    M_world = matrix_factory(origin, obj, orig_mat)
                    if M_world is not None:
                        obj.matrix_world = M_world @ orig_mat
                        any_changed = True
                elif use_prop and dist < prop_size:
                    weight = get_proportional_weight(dist, prop_size, falloff, profile)
                    common_pivot = getattr(self, 'pivot_3d', orig_mat.translation.copy())
                    M_world = matrix_factory(common_pivot, obj, orig_mat)
                    if M_world is not None:
                        target_mat = M_world @ orig_mat
                        loc1, rot1, sca1 = orig_mat.decompose()
                        loc2, rot2, sca2 = target_mat.decompose()
                        obj.matrix_world = mathutils.Matrix.LocRotScale(
                            loc1.lerp(loc2, weight),
                            rot1.slerp(rot2, weight),
                            sca1.lerp(sca2, weight)
                        )
                        any_changed = True
                else:
                    obj.matrix_world = orig_mat.copy()
            except Exception:
                pass
        return any_changed

    def _mesh_island_individual_mode(self, context) -> bool:
        try:
            return bool(getattr(self, '_mesh_island_transform_enabled', False)) and bool(getattr(self, '_mesh_island_groups', None))
        except Exception:
            return False

    def _mesh_island_pivot_from_mode(self, context, obj, island):
        try:
            pivot_mode = str(getattr(self, 'pivot_mode_current', '') or getattr(context.scene.tool_settings, 'transform_pivot_point', 'MEDIAN_POINT') or 'MEDIAN_POINT')
        except Exception:
            pivot_mode = 'MEDIAN_POINT'
        try:
            if pivot_mode == 'INDIVIDUAL_ORIGINS':
                return obj.matrix_world @ island.get('center_local', mathutils.Vector((0.0, 0.0, 0.0)))
            # Match Blender's standard transform pivot behavior for all other
            # modes: Median Point, Bounding Box Center, 3D Cursor, and Active
            # Element all use the common modal pivot computed by Smart G-R-S.
            return self.pivot_3d.copy()
        except Exception:
            try:
                return obj.matrix_world @ island.get('center_local', mathutils.Vector((0.0, 0.0, 0.0)))
            except Exception:
                try:
                    return self.pivot_3d.copy()
                except Exception:
                    return mathutils.Vector((0.0, 0.0, 0.0))

    def _apply_mesh_island_world_matrix(self, context, matrix_factory):
        """Apply a world matrix to selected connected mesh islands.

        matrix_factory(center_world, island, obj) returns a 4x4 world matrix.
        Transform Pivot Point follows Blender: Individual Origins uses each
        island center, while Median / Bounding Box / Active / Cursor use the
        common modal pivot.  Constraints, transform orientation, and snapping are
        already represented in the matrix factory supplied by Smart G-R-S.
        """
        groups_by_obj = getattr(self, '_mesh_island_groups', {}) or {}
        if not groups_by_obj:
            return False
        try:
            use_prop = is_prop_enabled(context)
            prop_size = float(getattr(context.tool_settings, 'proportional_size', 0.0))
            falloff = getattr(context.tool_settings, 'proportional_edit_falloff', 'SMOOTH')
        except Exception:
            use_prop = False
            prop_size = 0.0
            falloff = 'SMOOTH'
        prefs = _prefs(context)
        profile = getattr(prefs, 'prop_falloff_profile', 'BLENDER') if prefs else 'BLENDER'
        any_changed = False
        for obj, islands in list(groups_by_obj.items()):
            if not obj or obj.name not in bpy.data.objects or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', None) != 'EDIT':
                continue
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                mw = obj.matrix_world.copy()
                inv = mw.inverted_safe()
            except Exception:
                continue
            selected_indices = set()
            island_transforms = []
            nearest_sources = []
            for island in islands:
                try:
                    center_world = self._mesh_island_pivot_from_mode(context, obj, island)
                    M_world = matrix_factory(center_world, island, obj)
                    if M_world is None:
                        continue
                    M_local = inv @ M_world @ mw
                    island_transforms.append((island, M_local))
                    for idx, orig_co in zip(island.get('indices', []), island.get('orig_coords', [])):
                        idx = int(idx)
                        if 0 <= idx < len(bm.verts):
                            bm.verts[idx].co = (M_local @ orig_co.to_4d()).to_3d()
                            selected_indices.add(idx)
                            if use_prop and prop_size > 0.0:
                                try:
                                    nearest_sources.append((mw @ orig_co, M_local))
                                except Exception:
                                    pass
                            any_changed = True
                except Exception:
                    continue

            if use_prop and prop_size > 0.0 and island_transforms:
                try:
                    vmap = getattr(self, '_edit_verts', {}).get(obj, {}) or {}
                except Exception:
                    vmap = {}
                for idx, entry in list(vmap.items()):
                    try:
                        idx = int(idx)
                        if idx in selected_indices or idx < 0 or idx >= len(bm.verts):
                            continue
                        orig_co, dist = entry
                        dist = float(dist)
                        if dist >= prop_size:
                            continue
                        weight = get_proportional_weight(dist, prop_size, falloff, profile)
                        if weight <= 0.0:
                            continue
                        best_local = None
                        if nearest_sources:
                            src_world = mw @ orig_co
                            best_d2 = float('inf')
                            for sel_world, M_local in nearest_sources:
                                d2 = (src_world - sel_world).length_squared
                                if d2 < best_d2:
                                    best_d2 = d2
                                    best_local = M_local
                        if best_local is None:
                            best_local = island_transforms[0][1]
                        target_co = (best_local @ orig_co.to_4d()).to_3d()
                        bm.verts[idx].co = orig_co.lerp(target_co, weight)
                        any_changed = True
                    except Exception:
                        continue
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
        return any_changed

    def _translation_from_mouse(self, context, delta_region, depth_point_world):
        region, rv3d = self._smart_gizmo_region_rv3d(context) if hasattr(self, '_smart_gizmo_region_rv3d') else (getattr(context, 'region', None), getattr(context, 'region_data', None))
        if region is None or rv3d is None:
            return mathutils.Vector((0,0,0))
        px0 = view3d_utils.region_2d_to_location_3d(region, rv3d, (0, 0), depth_point_world)
        px1 = view3d_utils.region_2d_to_location_3d(region, rv3d, (1, 0), depth_point_world)
        py1 = view3d_utils.region_2d_to_location_3d(region, rv3d, (0, 1), depth_point_world)
        if not (px0 and px1 and py1): return mathutils.Vector((0,0,0))
        try:
            area = getattr(self, '_area', None) or getattr(context, 'area', None)
            q_scale = float(cu._quadview_visible_to_projection_scale(area, region=region, rv3d=rv3d, mx=0.0, my=0.0))
        except Exception:
            q_scale = 1.0
        return ((px1 - px0) * (float(delta_region[0]) * q_scale)) + ((py1 - px0) * (float(delta_region[1]) * q_scale))

    def _constrain_move(self, context, base_move_world):
        if self.constraint_kind == 'NONE': return base_move_world
        axis = self._get_constraint_axis(context, self.constraint_idx)
        if self.constraint_kind == 'AXIS': return axis * base_move_world.dot(axis)
        return base_move_world - axis * base_move_world.dot(axis)

    def _smart_gizmo_region_rv3d(self, context):
        region = getattr(self, '_region', None) or getattr(context, 'region', None)
        rv3d = getattr(self, '_rv3d', None)
        try:
            if rv3d is None:
                rv3d = getattr(context, 'region_data', None)
        except Exception:
            pass
        try:
            if rv3d is None:
                rv3d = cu._view3d_region_data(getattr(self, '_area', None), region)
        except Exception:
            pass
        if region is None or getattr(region, 'type', None) != 'WINDOW' or rv3d is None:
            region = getattr(context, 'region', None)
            rv3d = getattr(context, 'region_data', None) or rv3d
        try:
            if rv3d is not None:
                self._rv3d = rv3d
        except Exception:
            pass
        return region, rv3d

    def _smart_gizmo_active_quad_rect(self, context):
        """Return the visible Quad View rect locked to the drag's RegionView3D."""
        try:
            region, rv3d = self._smart_gizmo_region_rv3d(context)
            area = getattr(self, '_area', None) or getattr(context, 'area', None)
            if area is None or region is None or rv3d is None or not cu._quadview_layout_active(area):
                return None, area, region, rv3d
            idx = cu._quadview_region_index_from_region_data(area, rv3d)
            rect = cu._quadview_visible_rect(area, region, idx=idx, rv3d=rv3d)
            return rect, area, region, rv3d
        except Exception:
            return None, None, None, None

    def _smart_gizmo_visible_to_projection_xy(self, context, x, y):
        """Convert modal mouse coordinates to view3d_utils projection coordinates.

        Selection uses the current mouse quadrant.  A transform must not: once a
        Smart Gizmo / Smart G-R-S drag starts, its active view is fixed.  If the
        cursor crosses a Quad View divider, changing the quadrant here makes the
        solve plane jump and selected elements appear to fly away from the cursor.
        """
        try:
            rect, _area, region, _rv3d = self._smart_gizmo_active_quad_rect(context)
            if rect is not None and region is not None:
                x0, y0, w, h = rect
                rw = float(getattr(region, 'width', 0) or 0)
                rh = float(getattr(region, 'height', 0) or 0)
                if w > 0.0 and h > 0.0 and rw > 0.0 and rh > 0.0:
                    return ((float(x) - x0) * (rw / w), (float(y) - y0) * (rh / h))
        except Exception:
            pass
        return float(x), float(y)

    def _smart_gizmo_projection_to_visible_xy(self, context, x, y):
        try:
            rect, _area, region, _rv3d = self._smart_gizmo_active_quad_rect(context)
            if rect is not None and region is not None:
                x0, y0, w, h = rect
                rw = float(getattr(region, 'width', 0) or 0)
                rh = float(getattr(region, 'height', 0) or 0)
                if w > 0.0 and h > 0.0 and rw > 0.0 and rh > 0.0:
                    return (x0 + (float(x) * (w / rw)), y0 + (float(y) * (h / rh)))
        except Exception:
            pass
        return float(x), float(y)

    def _smart_gizmo_project_location_visible_2d(self, context, point_world):
        try:
            region, rv3d = self._smart_gizmo_region_rv3d(context)
            if region is None or rv3d is None:
                return None
            p = view3d_utils.location_3d_to_region_2d(region, rv3d, point_world)
            if p is None:
                return None
            vx, vy = self._smart_gizmo_projection_to_visible_xy(context, float(p.x), float(p.y))
            return mathutils.Vector((float(vx), float(vy)))
        except Exception:
            return None

    def _smart_gizmo_mouse_ray(self, context, x, y):
        try:
            region, rv3d = self._smart_gizmo_region_rv3d(context)
            if region is None or rv3d is None:
                return None, None
            co = self._smart_gizmo_visible_to_projection_xy(context, float(x), float(y))
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co)
            direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, co)
            if origin is None or direction is None or direction.length <= 1e-12:
                return None, None
            return origin.copy(), direction.normalized()
        except Exception:
            return None, None

    def _smart_gizmo_view_plane_normal(self, context):
        try:
            _region, rv3d = self._smart_gizmo_region_rv3d(context)
            if rv3d is None:
                rv3d = self._effective_region_data(context)
            if rv3d is not None:
                mat = self._view_basis_from_rv3d(rv3d)
                n = (mat.col[2] if mat is not None else (rv3d.view_rotation @ mathutils.Vector((0.0, 0.0, 1.0)))).normalized()
                if n.length > 1e-8:
                    return n
        except Exception:
            pass
        return mathutils.Vector((0.0, 0.0, 1.0))

    def _smart_gizmo_ray_plane_point(self, context, x, y, plane_point, plane_normal):
        try:
            origin, direction = self._smart_gizmo_mouse_ray(context, x, y)
            if origin is None or direction is None:
                return None
            n = plane_normal.normalized() if hasattr(plane_normal, 'normalized') else mathutils.Vector(plane_normal).normalized()
            if n.length <= 1e-12:
                return None
            hit = mathutils.geometry.intersect_line_plane(origin, origin + direction, plane_point, n, False)
            return hit.copy() if hit is not None else None
        except Exception:
            return None

    def _smart_gizmo_axis_parameter_from_mouse(self, context, x, y, axis_world):
        try:
            origin, direction = self._smart_gizmo_mouse_ray(context, x, y)
            if origin is None or direction is None:
                return None
            pivot = getattr(self, 'pivot_3d', None)
            if pivot is None:
                return None
            axis = axis_world.normalized() if hasattr(axis_world, 'normalized') else mathutils.Vector(axis_world).normalized()
            if axis.length <= 1e-12:
                return None
            try:
                pair = mathutils.geometry.intersect_line_line(pivot, pivot + axis, origin, origin + direction)
                if pair is not None:
                    point_on_axis = pair[0]
                    return float((point_on_axis - pivot).dot(axis))
            except Exception:
                pass

            # Analytic fallback for nearly parallel line/ray cases.
            ab = float(axis.dot(direction))
            denom = max(1.0e-12, 1.0 - ab * ab)
            w0 = pivot - origin
            u = (float(w0.dot(direction)) - ab * float(w0.dot(axis))) / denom
            t = -float(w0.dot(axis)) + ab * u
            return float(t)
        except Exception:
            return None

    def _smart_gizmo_move_from_mouse_absolute(self, context, cx, cy):
        """Return Smart Gizmo move using Blender-gizmo-style ray solving.

        The previous implementation converted screen deltas to world deltas with
        a linear pixel scale. In perspective views, and especially when the
        selected pivot is not centered under the handle, that can make the object
        drift relative to the cursor. This path instead computes the current and
        start mouse rays and solves the same geometric target used by standard
        gizmo interaction: view-plane intersection for free move, constraint-plane
        intersection for plane move, and closest point on the constrained axis for
        axis move.
        """
        try:
            sx = float(getattr(self, 'start_region_x', cx))
            sy = float(getattr(self, 'start_region_y', cy))
            kind = str(getattr(self, 'constraint_kind', 'NONE') or 'NONE')
            pivot = getattr(self, 'pivot_3d', None)
            if pivot is None:
                return None

            if kind == 'AXIS' and int(getattr(self, 'constraint_idx', -1)) in (0, 1, 2):
                axis = self._get_constraint_axis(context, int(self.constraint_idx))
                t0 = self._smart_gizmo_axis_parameter_from_mouse(context, sx, sy, axis)
                t1 = self._smart_gizmo_axis_parameter_from_mouse(context, cx, cy, axis)
                if t0 is None or t1 is None:
                    return None
                return axis.normalized() * float(t1 - t0)

            if kind == 'PLANE' and int(getattr(self, 'constraint_idx', -1)) in (0, 1, 2):
                # constraint_idx stores the axis excluded from the movement plane.
                plane_normal = self._get_constraint_axis(context, int(self.constraint_idx))
                p0 = self._smart_gizmo_ray_plane_point(context, sx, sy, pivot, plane_normal)
                p1 = self._smart_gizmo_ray_plane_point(context, cx, cy, pivot, plane_normal)
                if p0 is None or p1 is None:
                    return None
                return self._constrain_move(context, p1 - p0)

            # Free move: keep the initial pivot on the same view-parallel plane so
            # the object's projected motion follows the cursor one-to-one.
            view_normal = self._smart_gizmo_view_plane_normal(context)
            p0 = self._smart_gizmo_ray_plane_point(context, sx, sy, pivot, view_normal)
            p1 = self._smart_gizmo_ray_plane_point(context, cx, cy, pivot, view_normal)
            if p0 is None or p1 is None:
                return None
            return p1 - p0
        except Exception:
            return None

    def _smart_gizmo_project_axis_2d_raw(self, context, axis_world):
        try:
            region, rv3d = self._smart_gizmo_region_rv3d(context)
            if region is None or rv3d is None:
                return None
            pivot = getattr(self, 'pivot_3d', None)
            if pivot is None:
                return None
            axis = axis_world.normalized() if hasattr(axis_world, 'normalized') else mathutils.Vector(axis_world).normalized()
            if axis.length < 1e-8:
                return None
            p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot)
            if p2 is None:
                return None
            p2x, p2y = self._smart_gizmo_projection_to_visible_xy(context, float(p2.x), float(p2.y))
            for length in (1.0, 2.5, 8.0, 24.0, 80.0):
                t2 = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot + axis * float(length))
                if t2 is None:
                    continue
                t2x, t2y = self._smart_gizmo_projection_to_visible_xy(context, float(t2.x), float(t2.y))
                d = mathutils.Vector((float(t2x - p2x), float(t2y - p2y)))
                if d.length > 1e-5:
                    d.normalize()
                    return d
        except Exception:
            return None
        return None

    def _smart_gizmo_axis_world_per_screen_px(self, context, axis_world, axis_2d):
        try:
            axis = axis_world.normalized()
            px_move = self._translation_from_mouse(context, (float(axis_2d.x), float(axis_2d.y)), self.pivot_3d)
            value = float(px_move.dot(axis))
            if abs(value) > 1e-12:
                return abs(value)
        except Exception:
            pass
        try:
            # Conservative fallback: derive an average view-plane pixel scale.
            mx = self._translation_from_mouse(context, (1.0, 0.0), self.pivot_3d).length
            my = self._translation_from_mouse(context, (0.0, 1.0), self.pivot_3d).length
            value = max(mx, my)
            if value > 1e-12:
                return value
        except Exception:
            pass
        return 0.0

    def _smart_gizmo_constrained_move_from_mouse(self, context, delta_region):
        try:
            cx = float(getattr(self, 'start_region_x', 0.0)) + float(delta_region[0])
            cy = float(getattr(self, 'start_region_y', 0.0)) + float(delta_region[1])
            solved = self._smart_gizmo_move_from_mouse_absolute(context, cx, cy)
            if solved is not None:
                return solved
        except Exception:
            pass
        try:
            return self._constrain_move(context, self._translation_from_mouse(context, delta_region, self.pivot_3d))
        except Exception:
            return mathutils.Vector((0.0, 0.0, 0.0))

    def _rotation_axis(self, context):
        if self.constraint_kind == 'NONE':
            rv3d = self._effective_region_data(context)
            mat = self._view_basis_from_rv3d(rv3d) if rv3d else None
            return (mat.col[2].normalized() if mat is not None else (rv3d.view_rotation @ mathutils.Vector((0,0,1))).normalized()) if rv3d else mathutils.Vector((0,0,1))
        return self._get_constraint_axis(context, self.constraint_idx)

    def _use_screen_coordinate_rotation(self, prefs=None) -> bool:
        try:
            if self._use_free_axis_rotation():
                return False
        except Exception:
            pass
        try:
            if bool(getattr(self, '_force_circular_rotation', False)):
                return False
        except Exception:
            pass
        try:
            if bool(getattr(self, '_force_screen_coordinate_rotation', False)):
                return True
        except Exception:
            pass
        try:
            if prefs is None:
                prefs = _prefs(getattr(bpy, 'context', None))
            # Smart G-R-S rotation now follows the same user-facing control used
            # by Smart Gizmo.  ON = circular clockwise/counter-clockwise control;
            # OFF = screen-coordinate plus/minus control.
            return not bool(getattr(prefs, 'smart_gizmo_use_circular_rotation', True))
        except Exception:
            return False

    def _event_shift_active(self, event=None) -> bool:
        """Return the currently held precision modifier state.

        Blender builds can report modifier-key events differently depending on
        platform and invocation path. Smart Gizmo drags use the tracked held-key
        set as well as event.shift so Shift precision starts from the current
        transform result instead of snapping back to the pre-transform baseline.
        """
        shift_keys = {'SHIFT', 'LEFT_SHIFT', 'RIGHT_SHIFT'}
        try:
            if bool(getattr(self, '_invoke_use_accurate', False)):
                return True
        except Exception:
            pass
        try:
            held = set(getattr(self, '_held_inputs', set()) or set())
        except Exception:
            held = set()
        try:
            if event is not None:
                et = str(getattr(event, 'type', '') or '')
                ev = str(getattr(event, 'value', '') or '')
                if et in shift_keys:
                    if ev == 'PRESS':
                        return True
                    if ev == 'RELEASE':
                        return any(k in (held - {et}) for k in shift_keys)
        except Exception:
            pass
        try:
            if any(k in held for k in shift_keys):
                return True
        except Exception:
            pass
        try:
            if event is not None:
                return bool(getattr(event, 'shift', False))
        except Exception:
            pass
        return False

    def _rotation_screen_drag_dir_2d(self, context):
        """Return a stable screen-space plus direction for Max-like rotation.

        Blender's native rotate is polar: angle comes from moving the mouse
        around the pivot.  Screen-coordinate rotation is linear: screen-space
        positive/negative drag controls the angle.  Unconstrained view rotation
        uses horizontal screen movement; constrained rotation uses the tangent of
        the projected axis so X/Y/Z handles remain stable and readable.
        """
        try:
            if str(getattr(self, 'constraint_kind', 'NONE') or 'NONE') == 'NONE':
                return mathutils.Vector((1.0, 0.0))
            axis = self._rotation_axis(context)
            axis_2d = self._project_world_dir_to_screen(context, axis)
            if axis_2d is None or axis_2d.length < 1e-8:
                return mathutils.Vector((1.0, 0.0))
            tangent = mathutils.Vector((-axis_2d.y, axis_2d.x))
            if tangent.length < 1e-8:
                return mathutils.Vector((1.0, 0.0))
            tangent.normalize()
            if tangent.x < -1e-6 or (abs(tangent.x) <= 1e-6 and tangent.y < 0.0):
                tangent.negate()
            return tangent
        except Exception:
            return mathutils.Vector((1.0, 0.0))

    def _rotation_screen_delta_rad(self, context, mx, my) -> float:
        try:
            delta = mathutils.Vector((float(mx) - float(self.start_region_x), float(my) - float(self.start_region_y)))
            drag_dir = self._rotation_screen_drag_dir_2d(context)
            return float(delta.dot(drag_dir)) * 0.01
        except Exception:
            return 0.0

    def _smart_gizmo_circular_rotation_sign(self, context, mx=None, my=None) -> float:
        """Return a screen-stable sign for Smart Gizmo circular rotation.

        The raw polar angle from atan2 is always screen-space: positive means the
        cursor moved counter-clockwise around the projected gizmo center.  A world
        axis, however, follows the right-hand rule and its projected rotation flips
        when the axis/ring normal faces away from the camera.  For Smart Gizmo ring
        handles we measure how a small positive world rotation moves the ring point
        nearest the cursor on screen, then invert the sign when that projected
        motion is opposite to the cursor tangent.  This keeps X/Y/Z rotation rings
        from reversing when their front/back side changes relative to the camera.
        """
        try:
            if str(getattr(self, 'mode', '') or '') != 'R':
                return 1.0
            if self._use_free_axis_rotation():
                return 1.0
            if self._use_screen_coordinate_rotation(_prefs(context)):
                return 1.0
            if str(getattr(self, 'constraint_kind', 'NONE') or 'NONE') == 'NONE':
                return 1.0
        except Exception:
            return 1.0

        try:
            region = getattr(self, '_region', None) or getattr(context, 'region', None)
            rv3d = getattr(self, '_rv3d', None) or getattr(context, 'region_data', None)
            if region is None or rv3d is None:
                return 1.0
            pivot_world = getattr(self, 'pivot_3d', None)
            pivot_2d = getattr(self, 'pivot_2d', None)
            if pivot_world is None:
                return 1.0
            if pivot_2d is None:
                pivot_2d = self._smart_gizmo_project_location_visible_2d(context, pivot_world)
            if pivot_2d is None:
                return 1.0

            if mx is None:
                mx = getattr(self, 'start_region_x', getattr(self, 'last_cx', pivot_2d.x + 1.0))
            if my is None:
                my = getattr(self, 'start_region_y', getattr(self, 'last_cy', pivot_2d.y))
            radial_2d = mathutils.Vector((float(mx) - float(pivot_2d.x), float(my) - float(pivot_2d.y)))
            if radial_2d.length < 4.0:
                radial_2d = mathutils.Vector((float(getattr(self, 'start_region_x', mx)) - float(pivot_2d.x), float(getattr(self, 'start_region_y', my)) - float(pivot_2d.y)))
            if radial_2d.length < 4.0:
                radial_2d = mathutils.Vector((1.0, 0.0))
            radial_2d.normalize()
            tangent_positive = mathutils.Vector((-radial_2d.y, radial_2d.x))
            if tangent_positive.length < 1e-8:
                return 1.0
            tangent_positive.normalize()

            axis = mathutils.Vector(self._rotation_axis(context))
            if axis.length < 1e-8:
                return 1.0
            axis.normalize()

            try:
                inv_view = rv3d.view_matrix.inverted().to_3x3()
                view_right = (inv_view @ mathutils.Vector((1.0, 0.0, 0.0))).normalized()
            except Exception:
                view_right = mathutils.Vector((1.0, 0.0, 0.0))
            u = view_right - axis * view_right.dot(axis)
            if u.length < 1e-8:
                for cand in (mathutils.Vector((1.0, 0.0, 0.0)), mathutils.Vector((0.0, 1.0, 0.0)), mathutils.Vector((0.0, 0.0, 1.0))):
                    u = cand - axis * cand.dot(axis)
                    if u.length >= 1e-8:
                        break
            if u.length < 1e-8:
                return 1.0
            u.normalize()
            v = axis.cross(u)
            if v.length < 1e-8:
                return 1.0
            v.normalize()

            radius_world = 1.0
            try:
                from . import csdt_gizmo as _smart_gizmo
                base_scale = _smart_gizmo._smart_get_view_scale(region, rv3d, pivot_world)
                gscale = float(_smart_gizmo._smart_screen_scale())
                axis_scale = 1.0
                try:
                    prefs = _prefs(context)
                    axis_scale = float(getattr(prefs, 'smart_axis_scale', 1.0) if prefs else 1.0)
                except Exception:
                    axis_scale = 1.0
                radius_world = max(1e-5, float(base_scale) * max(0.1, min(gscale, 6.0)) * max(0.1, min(axis_scale, 6.0)) * 0.55)
            except Exception:
                radius_world = 1.0

            def _screen_delta_for_dir(world_dir):
                try:
                    p2 = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot_world + world_dir.normalized() * radius_world)
                    if p2 is None:
                        return None
                    d = mathutils.Vector((float(p2.x - pivot_2d.x), float(p2.y - pivot_2d.y)))
                    if d.length < 1e-8:
                        return None
                    return d
                except Exception:
                    return None

            du = _screen_delta_for_dir(u)
            dv = _screen_delta_for_dir(v)
            radial_world = None
            if du is not None and dv is not None:
                det = float(du.x * dv.y - du.y * dv.x)
                if abs(det) > 1e-8:
                    a = float(radial_2d.x * dv.y - radial_2d.y * dv.x) / det
                    b = float(du.x * radial_2d.y - du.y * radial_2d.x) / det
                    radial_world = (u * a) + (v * b)

            if radial_world is None or radial_world.length < 1e-8:
                best = None
                best_dot = -1e9
                for cand in (u, -u, v, -v):
                    sd = _screen_delta_for_dir(cand)
                    if sd is None or sd.length < 1e-8:
                        continue
                    sd.normalize()
                    score = float(sd.dot(radial_2d))
                    if score > best_dot:
                        best_dot = score
                        best = cand.copy()
                radial_world = best
            if radial_world is None or radial_world.length < 1e-8:
                return 1.0
            radial_world.normalize()

            p0_world = pivot_world + radial_world * radius_world
            q = mathutils.Quaternion(axis, 0.017453292519943295)  # +1 degree
            p1_world = pivot_world + (q @ (radial_world * radius_world))
            p0 = view3d_utils.location_3d_to_region_2d(region, rv3d, p0_world)
            p1 = view3d_utils.location_3d_to_region_2d(region, rv3d, p1_world)
            if p0 is None or p1 is None:
                return 1.0
            positive_world_motion = mathutils.Vector((float(p1.x - p0.x), float(p1.y - p0.y)))
            if positive_world_motion.length < 1e-8:
                return 1.0
            return 1.0 if float(positive_world_motion.dot(tangent_positive)) >= 0.0 else -1.0
        except Exception:
            return 1.0

    def _circular_rotation_sign(self, context) -> float:
        try:
            sign = float(getattr(self, '_circular_rotation_screen_sign', 0.0))
            if abs(sign) > 0.1:
                return 1.0 if sign > 0.0 else -1.0
        except Exception:
            pass
        try:
            sign = self._smart_gizmo_circular_rotation_sign(context, getattr(self, 'start_region_x', None), getattr(self, 'start_region_y', None))
            self._circular_rotation_screen_sign = 1.0 if sign >= 0.0 else -1.0
            return self._circular_rotation_screen_sign
        except Exception:
            self._circular_rotation_screen_sign = 1.0
            return 1.0

    def _reset_circular_rotation_baseline(self, context, cx=None, cy=None, sens=1.0) -> None:
        self._reset_circular_rotation_tracking(context, cx, cy, sens, preserve_current=True)

    def _reset_screen_rotation_baseline(self, cx=None, cy=None) -> None:
        try:
            self._rotation_offset_rad = float(getattr(self, '_last_rot', 0.0))
            if cx is None:
                cx = getattr(self, 'last_cx', getattr(self, 'start_region_x', 0))
            if cy is None:
                cy = getattr(self, 'last_cy', getattr(self, 'start_region_y', 0))
            self.start_region_x = int(cx)
            self.start_region_y = int(cy)
        except Exception:
            self._rotation_offset_rad = 0.0

    def _scale_factors_axes(self, uniform_factor):
        if self.constraint_kind == 'NONE': return (uniform_factor, uniform_factor, uniform_factor)
        f = [1.0, 1.0, 1.0]
        if self.constraint_kind == 'AXIS':
            f[self.constraint_idx] = uniform_factor
        else:
            f = [uniform_factor, uniform_factor, uniform_factor]
            f[self.constraint_idx] = 1.0
        return tuple(f)

    def _use_gizmo_distance_scale(self, context=None, prefs=None) -> bool:
        """True keeps the existing pivot/handle-distance scale behavior."""
        try:
            p = prefs if prefs is not None else _prefs(context)
            if p is None:
                return True
            return bool(getattr(p, 'smart_gizmo_use_distance_scale', True))
        except Exception:
            return True

    def _scale_screen_coordinate_value(self, mx, my) -> float:
        """Display-coordinate scale metric: right/up positive, left/down negative."""
        try:
            sx = float(getattr(self, 'start_region_x', mx))
            sy = float(getattr(self, 'start_region_y', my))
            return ((float(mx) - sx) + (float(my) - sy)) * 10.0
        except Exception:
            return 0.0

    def _scale_screen_coordinate_base_px(self, context=None) -> float:
        """Return a stable pixel base for screen-coordinate scale mode.

        The existing distance mode can use the actual cursor distance from the
        pivot, but screen-coordinate scale should not become excessively fast
        when the drag starts on a small center/ring handle.  Clamp the base so
        the setting remains predictable while still respecting large starts.
        """
        try:
            cached = float(getattr(self, '_screen_coordinate_scale_base_px', 0.0) or 0.0)
            if cached > 1.0e-6:
                return cached
        except Exception:
            pass

        candidates = []
        try:
            ref = self._smart_gizmo_uniform_scale_reference_px(context) if bool(getattr(self, '_from_smart_gizmo', False)) else None
            if ref is not None and float(ref) > 1.0e-6:
                candidates.append(float(ref))
        except Exception:
            pass
        for attr in ('start_scale_base', 'start_dist'):
            try:
                val = abs(float(getattr(self, attr, 0.0) or 0.0))
                if val > 1.0e-6:
                    candidates.append(val)
            except Exception:
                pass
        try:
            region = getattr(self, '_region', None) or (getattr(context, 'region', None) if context is not None else None)
            rw = float(getattr(region, 'width', 0.0) or 0.0)
            rh = float(getattr(region, 'height', 0.0) or 0.0)
            if rw > 0.0 and rh > 0.0:
                candidates.append(min(rw, rh) * 0.12)
        except Exception:
            pass

        try:
            base = max(candidates) if candidates else 96.0
        except Exception:
            base = 96.0
        base = max(64.0, min(float(base), 240.0))
        try:
            self._screen_coordinate_scale_base_px = base
        except Exception:
            pass
        return base

    def _prepare_screen_coordinate_scale_baseline(self, context, cx=None, cy=None, sens=1.0, *, preserve_current=False) -> None:
        """Initialize or rebase scale so screen right/up enlarges and left/down shrinks."""
        try:
            if cx is None:
                cx = getattr(self, 'last_cx', getattr(self, 'start_region_x', 0))
            if cy is None:
                cy = getattr(self, 'last_cy', getattr(self, 'start_region_y', 0))
            base = max(float(self._scale_screen_coordinate_base_px(context)), 0.001)
            metric = float(self._scale_screen_coordinate_value(cx, cy))
            if preserve_current:
                factor_old = float(getattr(self, '_last_scale', 1.0))
                s = float(sens) if abs(float(sens)) > 1.0e-8 else 1.0
                self.start_scale_signed = metric - ((factor_old - 1.0) / s) * base
            else:
                self.start_scale_signed = metric
            self.start_scale_base = base
            self._smart_gizmo_scale_delta_mode = True
        except Exception:
            pass

    def _project_world_dir_to_screen(self, context, world_dir):
        try:
            region, rv3d = self._smart_gizmo_region_rv3d(context)
            if region is None or rv3d is None:
                return None
            vec = world_dir.normalized() if hasattr(world_dir, 'normalized') else mathutils.Vector(world_dir)
            if vec.length < 1e-8:
                return None
            pivot_2d = self.pivot_2d
            tip_2d = self._smart_gizmo_project_location_visible_2d(context, self.pivot_3d + vec)
            if pivot_2d is None or tip_2d is None:
                return None
            dir_2d = mathutils.Vector((float(tip_2d.x - pivot_2d.x), float(tip_2d.y - pivot_2d.y)))
            if dir_2d.length < 1e-8:
                return None
            dir_2d.normalize()
            try:
                start_vec = mathutils.Vector((float(self.start_region_x - pivot_2d.x), float(self.start_region_y - pivot_2d.y)))
                if start_vec.length > 1e-8 and start_vec.dot(dir_2d) < 0.0:
                    dir_2d.negate()
            except Exception:
                pass
            return dir_2d
        except Exception:
            return None

    def _current_scale_drag_dir_2d(self, context):
        if self.constraint_kind == 'AXIS' and self.constraint_idx in (0, 1, 2):
            return self._project_world_dir_to_screen(context, self._get_constraint_axis(context, self.constraint_idx))
        if self.constraint_kind == 'PLANE' and self.constraint_idx in (0, 1, 2):
            keep_axes = [i for i in (0, 1, 2) if i != self.constraint_idx]
            try:
                world_dir = self._get_constraint_axis(context, keep_axes[0]) + self._get_constraint_axis(context, keep_axes[1])
            except Exception:
                world_dir = mathutils.Vector((1.0, 0.0, 0.0))
            if world_dir.length < 1e-8:
                try:
                    world_dir = self._get_constraint_axis(context, keep_axes[0])
                except Exception:
                    world_dir = mathutils.Vector((1.0, 0.0, 0.0))
            return self._project_world_dir_to_screen(context, world_dir)
        try:
            if getattr(self, 'start_dir2', None) is not None and self.start_dir2.length > 1e-8:
                return self.start_dir2.normalized()
        except Exception:
            pass
        return None

    def _scale_signed_distance(self, context, mx, my):
        if not self._use_gizmo_distance_scale(context):
            return float(self._scale_screen_coordinate_value(mx, my))
        dir_2d = self._current_scale_drag_dir_2d(context)
        if dir_2d is None:
            cur_vec2 = mathutils.Vector((mx - self.pivot_2d.x, my - self.pivot_2d.y))
            try:
                return float(cur_vec2.dot(self.start_dir2))
            except Exception:
                return float(cur_vec2.length)
        cur_vec2 = mathutils.Vector((mx - self.pivot_2d.x, my - self.pivot_2d.y))
        return float(cur_vec2.dot(dir_2d))

    def _smart_gizmo_uniform_scale_reference_px(self, context):
        try:
            region = getattr(self, '_region', None) or getattr(context, 'region', None)
            rv3d = getattr(self, '_rv3d', None) or getattr(context, 'region_data', None)
            if region is None or rv3d is None:
                return None
            from . import csdt_gizmo as _smart_gizmo
            geo = _smart_gizmo._smart_gizmo_geometry(context, region, rv3d)
            if not isinstance(geo, dict):
                return None
            pivot = geo.get('pivot', None) or getattr(self, 'pivot_3d', None)
            if pivot is None:
                return None
            kind = str(geo.get('kind', '') or '')
            try:
                radius_world = float(_smart_gizmo._scale_uniform_free_handle_radius(geo, kind))
            except Exception:
                radius_world = float(geo.get('scale_center', geo.get('center_radius', 0.0)) or 0.0)
            if radius_world <= 0.0:
                return None
            try:
                inv = rv3d.view_matrix.inverted().to_3x3()
                view_x = (inv @ mathutils.Vector((1.0, 0.0, 0.0))).normalized()
            except Exception:
                view_x = mathutils.Vector((1.0, 0.0, 0.0))
            c2 = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot)
            r2 = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot + view_x * radius_world)
            if c2 is None or r2 is None:
                return None
            px = math.hypot(float(r2.x - c2.x), float(r2.y - c2.y))
            if px > 1e-6:
                return max(8.0, min(px, 240.0))
        except Exception:
            return None
        return None

    def _normalize_smart_gizmo_constrained_scale_base(self, context):
        try:
            if str(getattr(self, 'mode', '') or '') != 'S':
                return
            if str(getattr(self, 'constraint_kind', 'NONE') or 'NONE') not in {'AXIS', 'PLANE'}:
                return
            ref = None
            if bool(getattr(self, '_from_smart_gizmo', False)):
                ref = self._smart_gizmo_uniform_scale_reference_px(context)
                if ref is None or ref <= 0.0:
                    try:
                        ref = max(12.0, min(64.0, float(getattr(self, 'start_dist', 32.0)) * 0.35))
                    except Exception:
                        ref = 32.0
            else:
                # For normal Smart G-R-S, constrained scale should respond with
                # the same cursor-distance ratio as free scale.  Use the radial
                # cursor distance from the pivot as the base, not the smaller
                # projection on the constrained axis/plane drag direction.
                try:
                    ref = float(getattr(self, 'start_dist', 0.0) or 0.0)
                except Exception:
                    ref = 0.0
                if ref <= 1e-6:
                    try:
                        ref = abs(float(getattr(self, 'start_scale_signed', 0.0)))
                    except Exception:
                        ref = 0.0
                if ref <= 1e-6:
                    ref = 32.0
            self.start_scale_base = max(float(ref), 0.001)
            self._smart_gizmo_scale_delta_mode = True
        except Exception:
            pass

    def _reset_scale_baseline_from_current(self, context, cx=None, cy=None, sens=1.0) -> None:
        try:
            if str(getattr(self, 'mode', '') or '') != 'S':
                return
            if cx is None:
                cx = getattr(self, 'last_cx', getattr(self, 'start_region_x', 0))
            if cy is None:
                cy = getattr(self, 'last_cy', getattr(self, 'start_region_y', 0))
            if not self._use_gizmo_distance_scale(context):
                self._prepare_screen_coordinate_scale_baseline(context, cx, cy, sens, preserve_current=True)
                return
            # Constrained Smart G-R-S scale uses the same delta mode as Smart
            # Gizmo constrained scale so X/Y/Z and plane handles have the same
            # cursor-distance response as the free handle.
            if str(getattr(self, 'constraint_kind', 'NONE') or 'NONE') in {'AXIS', 'PLANE'}:
                self._normalize_smart_gizmo_constrained_scale_base(context)
            signed_dist = float(self._scale_signed_distance(context, cx, cy))
            base_dist = max(float(getattr(self, 'start_scale_base', getattr(self, 'start_dist', 0.0)) or getattr(self, 'start_dist', 0.0) or 32.0), 0.001)
            factor_old = float(getattr(self, '_last_scale', 1.0))
            s = float(sens) if abs(float(sens)) > 1e-8 else 1.0
            if bool(getattr(self, '_smart_gizmo_scale_delta_mode', False)):
                self.start_scale_signed = signed_dist - ((factor_old - 1.0) / s) * base_dist
            else:
                raw = 1.0 + (factor_old - 1.0) / s
                if abs(raw) < 1e-8:
                    raw = 1e-8 if raw >= 0.0 else -1e-8
                self.start_scale_base = max(abs(signed_dist / raw), 0.001)
                self.start_dist = self.start_scale_base
        except Exception:
            pass

    def _make_rotation_matrix(self, pivot_world, axis_world, angle_rad):
        T = mathutils.Matrix.Translation(pivot_world)
        R = mathutils.Matrix.Rotation(angle_rad, 4, axis_world.normalized())
        return T @ R @ T.inverted()

    def _make_rotation_matrix_from_quat(self, pivot_world, quat):
        try:
            q = quat.copy()
            q.normalize()
            R = q.to_matrix().to_4x4()
        except Exception:
            return mathutils.Matrix.Identity(4)
        T = mathutils.Matrix.Translation(pivot_world)
        return T @ R @ T.inverted()

    def _use_free_axis_rotation(self) -> bool:
        try:
            return bool(getattr(self, '_force_free_rotation', False)) and str(getattr(self, 'mode', '') or '') == 'R'
        except Exception:
            return False

    def _free_rotation_region_rv3d(self, context):
        region = getattr(self, '_region', None) or getattr(context, 'region', None)
        rv3d = getattr(self, '_rv3d', None) or getattr(context, 'region_data', None)
        return region, rv3d

    def _get_free_rotation_radius_px(self, context) -> float:
        try:
            r = float(getattr(self, '_free_rotation_radius_px', 0.0) or 0.0)
            if r > 8.0:
                return r
        except Exception:
            pass
        try:
            region, _rv3d = self._free_rotation_region_rv3d(context)
            w = float(getattr(region, 'width', 0) or 0)
            h = float(getattr(region, 'height', 0) or 0)
            return max(48.0, min(220.0, min(w, h) * 0.22))
        except Exception:
            return 96.0

    def _free_rotation_arcball_vec(self, context, mx, my):
        try:
            pivot_2d = getattr(self, 'pivot_2d', None)
            if pivot_2d is None:
                region, _rv3d = self._free_rotation_region_rv3d(context)
                pivot_2d = mathutils.Vector((float(getattr(region, 'width', 0) or 0) * 0.5, float(getattr(region, 'height', 0) or 0) * 0.5))
            radius = max(8.0, self._get_free_rotation_radius_px(context))
            x = (float(mx) - float(pivot_2d.x)) / radius
            y = (float(my) - float(pivot_2d.y)) / radius
            d2 = x * x + y * y
            if d2 <= 1.0:
                z = math.sqrt(max(0.0, 1.0 - d2))
                v = mathutils.Vector((x, y, z))
            else:
                inv = 1.0 / math.sqrt(max(d2, 1e-12))
                v = mathutils.Vector((x * inv, y * inv, 0.0))
            if v.length < 1e-8:
                return mathutils.Vector((0.0, 0.0, 1.0))
            v.normalize()
            return v
        except Exception:
            return mathutils.Vector((0.0, 0.0, 1.0))

    def _free_rotation_identity_quat(self):
        try:
            return mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
        except Exception:
            try:
                return mathutils.Quaternion()
            except Exception:
                return None

    def _reset_free_rotation_baseline(self, context, mx=None, my=None, *, keep_current=False, sens=1.0):
        try:
            if mx is None:
                mx = getattr(self, 'last_cx', getattr(self, 'start_region_x', 0))
            if my is None:
                my = getattr(self, 'last_cy', getattr(self, 'start_region_y', 0))
            current_q = self._free_rotation_total_quat(context, mx, my, sens) if keep_current else self._free_rotation_identity_quat()
            self._free_rotation_offset_q = current_q.copy() if current_q is not None else self._free_rotation_identity_quat()
            self._free_rotation_accum_q = self._free_rotation_offset_q.copy() if self._free_rotation_offset_q is not None else self._free_rotation_identity_quat()
            self._free_rotation_start_vec = self._free_rotation_arcball_vec(context, mx, my)
            self._free_rotation_prev_vec = self._free_rotation_start_vec.copy()
            self._free_rotation_prev_x = float(mx)
            self._free_rotation_prev_y = float(my)
            self.start_region_x = int(mx)
            self.start_region_y = int(my)
        except Exception:
            ident = self._free_rotation_identity_quat()
            self._free_rotation_offset_q = ident
            self._free_rotation_accum_q = ident.copy() if ident is not None else ident
            self._free_rotation_start_vec = mathutils.Vector((0.0, 0.0, 1.0))
            self._free_rotation_prev_vec = self._free_rotation_start_vec.copy()

    def _free_rotation_view_axis_to_world(self, context, axis_view):
        try:
            rv3d = getattr(self, '_rv3d', None) or getattr(context, 'region_data', None)
            if rv3d is not None:
                axis_world = rv3d.view_rotation @ axis_view
            else:
                axis_world = axis_view.copy()
            if axis_world.length < 1e-8:
                return None
            axis_world.normalize()
            return axis_world
        except Exception:
            return None

    def _free_rotation_update_accumulated(self, context, mx, my, shift=False, prefs=None):
        if not self._use_free_axis_rotation():
            return
        try:
            if prefs is None:
                prefs = _prefs(context)
            cur_vec = self._free_rotation_arcball_vec(context, mx, my)
            prev_vec = getattr(self, '_free_rotation_prev_vec', None)
            if prev_vec is None or prev_vec.length < 1e-8:
                prev_vec = self._free_rotation_arcball_vec(context, getattr(self, '_free_rotation_prev_x', getattr(self, 'start_region_x', mx)), getattr(self, '_free_rotation_prev_y', getattr(self, 'start_region_y', my)))
            dot = max(-1.0, min(1.0, float(prev_vec.dot(cur_vec))))
            axis_view = prev_vec.cross(cur_vec)
            self._free_rotation_prev_vec = cur_vec.copy()
            self._free_rotation_prev_x = float(mx)
            self._free_rotation_prev_y = float(my)
            if axis_view.length < 1e-8:
                return
            axis_view.normalize()
            angle = math.acos(dot) * float(self._get_sens(prefs, 'R', bool(shift)))
            if abs(angle) < 1e-12:
                return
            axis_world = self._free_rotation_view_axis_to_world(context, axis_view)
            if axis_world is None:
                return
            q_delta = mathutils.Quaternion(axis_world, angle)
            q_acc = getattr(self, '_free_rotation_accum_q', None)
            if q_acc is None:
                q_acc = self._free_rotation_identity_quat()
            if q_acc is None:
                return
            q_acc = q_delta @ q_acc
            try:
                q_acc.normalize()
            except Exception:
                pass
            self._free_rotation_accum_q = q_acc
        except Exception:
            try:
                self._free_rotation_prev_vec = self._free_rotation_arcball_vec(context, mx, my)
                self._free_rotation_prev_x = float(mx)
                self._free_rotation_prev_y = float(my)
            except Exception:
                pass

    def _free_rotation_delta_quat(self, context, mx, my, sens=1.0):
        try:
            start_v = getattr(self, '_free_rotation_start_vec', None)
            if start_v is None or start_v.length < 1e-8:
                start_v = self._free_rotation_arcball_vec(context, getattr(self, 'start_region_x', mx), getattr(self, 'start_region_y', my))
            cur_v = self._free_rotation_arcball_vec(context, mx, my)
            dot = max(-1.0, min(1.0, float(start_v.dot(cur_v))))
            axis_view = start_v.cross(cur_v)
            if axis_view.length < 1e-8:
                return mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            axis_view.normalize()
            angle = math.acos(dot) * float(sens)
            axis_world = self._free_rotation_view_axis_to_world(context, axis_view)
            if axis_world is None or abs(angle) < 1e-12:
                return mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            q = mathutils.Quaternion(axis_world, angle)
            q.normalize()
            return q
        except Exception:
            return mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))

    def _free_rotation_total_quat(self, context, mx, my, sens=1.0):
        try:
            q_acc = getattr(self, '_free_rotation_accum_q', None)
            if q_acc is not None:
                q = q_acc.copy()
                q.normalize()
                return q
            offset = getattr(self, '_free_rotation_offset_q', None)
            if offset is None:
                offset = self._free_rotation_identity_quat() or mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            q = self._free_rotation_delta_quat(context, mx, my, sens) @ offset
            q.normalize()
            return q
        except Exception:
            return mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))

    def _apply_snap_to_free_rotation_quat(self, context, quat, mods):
        try:
            # Match Blender's normal transform snap state instead of checking
            # only the temporary Smart G-R-S snap hold.  This lets free-axis
            # rotation from the smart gizmo honor Tool Settings > Snap and Ctrl
            # modifier toggles the same way the ordinary rotation tool does.
            snap = self._effective_snap_mode(context, mods)
            if snap != 'GRID':
                return quat
            q_in = quat.copy()
            q_in.normalize()
            if self._is_ctrl_increment_snap(mods):
                # Free rotation also snaps from the modal start orientation.  The
                # old Ctrl-press anchor made the first Ctrl frame preserve the
                # unsnapped angle; instead, snap q_in's total start-relative
                # angle directly.
                axis, angle = q_in.to_axis_angle()
                angle = self._apply_snap_to_rotate(context, float(angle), mods)
                q = mathutils.Quaternion(axis, angle)
                q.normalize()
                return q
            axis, angle = q_in.to_axis_angle()
            angle = self._apply_snap_to_rotate(context, float(angle), mods)
            q = mathutils.Quaternion(axis, angle)
            q.normalize()
            return q
        except Exception:
            return quat

    def _scale_basis_world(self, context):
        """Return the orientation basis used for constrained scale.

        The original standalone Smart G-R-S add-on scaled in world axes only.
        After suite integration, gizmo handles started passing LOCAL / NORMAL /
        VIEW / CURSOR constraints through STS_PENDING_GRS, but the scale matrix
        was still built as a plain world-space diagonal matrix. That makes local
        Y/Z handles and plane handles feel swapped or inverted because the scale
        factors are applied on world axes instead of the requested orientation.

        Use the same orientation matrix that axis/plane constraints use so scale
        matches the picked gizmo handle and Blender's native behavior.
        """
        try:
            basis = self._get_orient_matrix(context, self._effective_constraint_space(context))
            return basis if isinstance(basis, mathutils.Matrix) else mathutils.Matrix.Identity(3)
        except Exception:
            return mathutils.Matrix.Identity(3)

    def _make_scale_matrix(self, context, pivot_world, sx, sy, sz):
        T = mathutils.Matrix.Translation(pivot_world)
        basis = self._scale_basis_world(context)
        try:
            basis_inv = basis.inverted_safe()
        except Exception:
            basis_inv = mathutils.Matrix.Identity(3)
        S_space = mathutils.Matrix.Diagonal((sx, sy, sz))
        S_world = basis @ S_space @ basis_inv
        return T @ S_world.to_4x4() @ T.inverted()

    @staticmethod
    def _draw_rna_same(a, b):
        """Return True when two Blender RNA wrappers reference the same value."""
        if a is None or b is None:
            return False
        try:
            return int(a.as_pointer()) == int(b.as_pointer())
        except Exception:
            return a is b

    @staticmethod
    def _draw_area_is_quad_view(area):
        """Return True for both Blender Quad View region layouts.

        Blender 5.x can expose Quad View either as four distinct WINDOW regions
        or as one physical WINDOW region with four RegionView3D values.  The
        coordinate-remapping helper intentionally distinguishes those layouts,
        but draw isolation must treat both layouts as Quad View.
        """
        try:
            if area is None or getattr(area, 'type', None) != 'VIEW_3D':
                return False
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            return len(list(getattr(space, 'region_quadviews', []) or [])) >= 4
        except Exception:
            return False

    def _resolve_draw_context(self, context):
        """Resolve the exact View3D sub-view allowed to draw this modal overlay.

        SpaceView3D draw handlers are called for every 3D View WINDOW region.
        Quad View panes normally have identical dimensions, so viewport-size
        matching must never be used there: doing so draws the HUD in all four
        panes.  Prefer exact Area/Region identity and additionally verify the
        RegionView3D identity for Blender builds that reuse one physical region.

        When Blender supplies no usable callback context, a conservative
        single-view fallback is retained.  In Quad View an ambiguous callback is
        skipped rather than risking drawing in the wrong pane.
        """
        try:
            if not getattr(self, '_in_modal', False):
                return None

            target_area = getattr(self, '_area', None)
            target_region = getattr(self, '_region', None)
            target_rv3d = getattr(self, '_rv3d', None)
            if target_area is None or target_region is None:
                return None

            ctx = context or bpy.context
            if not _workspace_runtime_allowed(ctx):
                return None
            live_area = getattr(ctx, 'area', None)
            live_region = getattr(ctx, 'region', None)
            live_rv3d = getattr(ctx, 'region_data', None)
            if live_rv3d is None and live_region is not None:
                try:
                    live_rv3d = getattr(live_region, 'data', None)
                except Exception:
                    live_rv3d = None

            # Normal Blender 5.x draw callbacks provide exact area/region data.
            # A mismatch is definitive and must not fall through to a size-only
            # fallback, especially in Quad View where every pane is similarly sized.
            if live_area is not None and live_region is not None:
                if not self._draw_rna_same(live_area, target_area):
                    return None
                if self._draw_rna_same(live_region, target_region):
                    # Some builds reuse one physical region for all Quad panes.
                    # In that layout RegionView3D is the only sub-view identity.
                    if target_rv3d is not None and live_rv3d is not None:
                        if not self._draw_rna_same(live_rv3d, target_rv3d):
                            return None
                    return live_area, live_region, live_rv3d or target_rv3d
                # Sparse/misreported region wrappers can still be accepted when
                # the active RegionView3D exactly identifies the starting pane.
                if target_rv3d is not None and live_rv3d is not None and self._draw_rna_same(live_rv3d, target_rv3d):
                    return live_area, live_region, live_rv3d
                return None

            # If an area is available without a region, only an exact RV3D match
            # is sufficiently specific.  Otherwise skip the callback.
            if live_area is not None:
                if not self._draw_rna_same(live_area, target_area):
                    return None
                if target_rv3d is not None and live_rv3d is not None and self._draw_rna_same(live_rv3d, target_rv3d):
                    return live_area, target_region, live_rv3d
                return None

            # A sparse callback may still expose the exact target
            # RegionView3D even when area/region are unavailable.  That pointer
            # uniquely identifies the active Quad View pane.
            if target_rv3d is not None and live_rv3d is not None and self._draw_rna_same(live_rv3d, target_rv3d):
                if live_region is None or self._draw_rna_same(live_region, target_region):
                    return target_area, target_region, live_rv3d

            # Never guess a Quad View pane from dimensions or a local GPU
            # viewport origin.  Ambiguous callbacks are safer to omit.
            if self._draw_area_is_quad_view(target_area):
                return None

            # Conservative fallback for a normal single-view area only.
            try:
                a2, r2, rv2 = cu._smart_find_area_region_rv3d_from_viewport()
            except Exception:
                a2, r2, rv2 = None, None, None
            if a2 is not None and r2 is not None:
                if self._draw_rna_same(a2, target_area) and self._draw_rna_same(r2, target_region):
                    return a2, r2, rv2 or target_rv3d
                return None

            try:
                windows = [r for r in getattr(target_area, 'regions', []) if getattr(r, 'type', None) == 'WINDOW']
                if len(windows) != 1 or not self._draw_rna_same(windows[0], target_region):
                    return None
                _vx, _vy, vw, vh = gpu.state.viewport_get()
                rw = int(getattr(target_region, 'width', -1))
                rh = int(getattr(target_region, 'height', -1))
                if rw > 0 and rh > 0 and abs(int(vw) - rw) <= 2 and abs(int(vh) - rh) <= 2:
                    return target_area, target_region, target_rv3d
            except Exception:
                pass
            return None
        except Exception:
            return None

    def _draw_ctx_ok(self, context):
        return self._resolve_draw_context(context) is not None

    def _draw_constraint_line(self):
        if not self._draw_ctx_ok(bpy.context): return
        if self.constraint_kind == 'NONE' and not getattr(self, "_middle_mouse_held", False): return
        if not bpy.context.region_data: return

        prev_blend = getattr(gpu.state, 'blend_get', lambda: None)()
        prev_depth = getattr(gpu.state, 'depth_test_get', lambda: None)()
        prev_line_width = getattr(gpu.state, 'line_width_get', lambda: 1.0)()
        prev_ms = getattr(gpu.state, 'multisample_get', lambda: None)()
        prev_ls = getattr(gpu.state, 'line_smooth_get', lambda: None)()
        prev_a2c = getattr(gpu.state, 'alpha_to_coverage_get', lambda: None)()

        try: self._shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        except Exception: self._shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        
        length = max(float(bpy.context.region_data.view_distance), 1.0) * 2.0
        pivot = self.pivot_3d
        prefs = _prefs(bpy.context)
        aa_mode = getattr(prefs, 'overlay_aa_mode', 'AA_2PASS') if prefs else 'AA_2PASS'
        aa_enabled = (aa_mode != 'AA_OFF')
        use_2pass_aa = (aa_mode == 'AA_2PASS')
        
        in_front = getattr(prefs, 'draw_axis_lines_in_front', True) if prefs else True

        def draw_axis(axis_vec, color, width):
            p0, p1 = pivot - axis_vec * length, pivot + axis_vec * length
            batch = batch_for_shader(self._shader, 'LINES', {"pos": (p0, p1)})
            self._shader.bind()
            self._shader.uniform_float("color", color)
            gpu.state.blend_set('ALPHA')
            # enable multisample/coverage when available (no-op otherwise)
            try: gpu.state.multisample_set(aa_enabled)
            except Exception: pass
            try: gpu.state.line_smooth_set(aa_enabled)
            except Exception: pass
            try: gpu.state.alpha_to_coverage_set(aa_enabled)
            except Exception: pass

            if in_front:
                try: gpu.state.depth_test_set('NONE')
                except Exception: pass

            # Lightweight 2-pass AA (outer + main)
            base_w = float(width)
            def _draw_once(w, col):
                gpu.state.line_width_set(w)
                self._shader.bind()
                self._shader.uniform_float("color", col)
                batch.draw(self._shader)
            if use_2pass_aa and color[3] > 0.001:
                aa = max(0.0, min(1.0, float(color[3]) * 0.18))
                _draw_once(base_w + 1.0, (color[0], color[1], color[2], aa))

            _draw_once(base_w, color)

            if in_front:
                try: gpu.state.depth_test_set('LESS_EQUAL')
                except Exception: pass

            gpu.state.blend_set('NONE')
            try: gpu.state.line_width_set(prev_line_width)
            except Exception: pass

        c_x = prefs.axis_color_x[:] if prefs else COL_X
        c_y = prefs.axis_color_y[:] if prefs else COL_Y
        c_z = prefs.axis_color_z[:] if prefs else COL_Z

        cd_x = prefs.axis_color_dark_x[:] if prefs else COL_DARK_X
        cd_y = prefs.axis_color_dark_y[:] if prefs else COL_DARK_Y
        cd_z = prefs.axis_color_dark_z[:] if prefs else COL_DARK_Z

        normal_width = float(getattr(prefs, 'axis_line_width', 2)) if prefs else 2.0
        active_width = float(getattr(prefs, 'axis_line_width_active', 4)) if prefs else 4.0

        if getattr(self, "_middle_mouse_held", False):
            for i, (col_norm, col_dark) in enumerate([(c_x, cd_x), (c_y, cd_y), (c_z, cd_z)]):
                if self.constraint_kind == 'NONE':
                    is_active = False
                elif self.constraint_kind == 'AXIS':
                    is_active = (self.constraint_idx == i)
                elif self.constraint_kind == 'PLANE':
                    is_active = (self.constraint_idx != i)
                else:
                    is_active = False
                
                draw_col = col_norm if is_active else col_dark
                draw_width = active_width if is_active else normal_width
                draw_axis(self._get_constraint_axis(bpy.context, i), draw_col, draw_width)
        else:
            if self.constraint_kind == 'AXIS':
                draw_axis(self._get_constraint_axis(bpy.context, self.constraint_idx), (c_x, c_y, c_z)[self.constraint_idx], normal_width)
            else:
                excl = self.constraint_idx
                if excl != 0: draw_axis(self._get_constraint_axis(bpy.context, 0), c_x, normal_width)
                if excl != 1: draw_axis(self._get_constraint_axis(bpy.context, 1), c_y, normal_width)
                if excl != 2: draw_axis(self._get_constraint_axis(bpy.context, 2), c_z, normal_width)
        try:
            if prev_blend is not None: gpu.state.blend_set(prev_blend)
            else: gpu.state.blend_set('NONE')
        except Exception: pass
        try:
            if prev_depth is not None: gpu.state.depth_test_set(prev_depth)
        except Exception: pass
        try:
            gpu.state.line_width_set(prev_line_width)
        except Exception: pass
        try:
            if prev_ms is not None: gpu.state.multisample_set(prev_ms)
        except Exception: pass
        try:
            if prev_ls is not None: gpu.state.line_smooth_set(prev_ls)
        except Exception: pass
        try:
            if prev_a2c is not None: gpu.state.alpha_to_coverage_set(prev_a2c)
        except Exception: pass

    def _draw_prop_circle(self):
        context = bpy.context
        if not self._draw_ctx_ok(context):
            return
        if not is_prop_enabled(context): return

        prev_blend = getattr(gpu.state, 'blend_get', lambda: None)()
        prev_line_width = getattr(gpu.state, 'line_width_get', lambda: 1.0)()
        prev_ms = getattr(gpu.state, 'multisample_get', lambda: None)()
        prev_ls = getattr(gpu.state, 'line_smooth_get', lambda: None)()
        prev_a2c = getattr(gpu.state, 'alpha_to_coverage_get', lambda: None)()
        prev_depth = getattr(gpu.state, 'depth_test_get', lambda: None)()
        prev_depth_mask = getattr(gpu.state, 'depth_mask_get', lambda: None)()
        prev_cull = getattr(gpu.state, 'face_culling_get', lambda: None)()
        
        rv3d = context.region_data
        if not rv3d or context.region.type != 'WINDOW': return
        
        prefs = _prefs(context)
        aa_mode = getattr(prefs, 'overlay_aa_mode', 'AA_2PASS') if prefs else 'AA_2PASS'
        aa_enabled = (aa_mode != 'AA_OFF')
        use_2pass_aa = (aa_mode == 'AA_2PASS')
        if prefs and hasattr(prefs, "show_orange_circle") and not prefs.show_orange_circle: return
            
        draw_color = prefs.circle_color[:] if prefs else (0.2388, 0.2388, 0.2388, 1.0)
        draw_line_width = float(prefs.circle_line_width) if prefs else 2.0
        
        current_pivot = getattr(self, "current_pivot_3d", self.pivot_3d)
        center_2d = view3d_utils.location_3d_to_region_2d(context.region, rv3d, current_pivot)
        if not center_2d: return
            
        prop_size = context.tool_settings.proportional_size
        view_right = rv3d.view_rotation @ mathutils.Vector((1.0, 0.0, 0.0))
        radius_world_loc = current_pivot + (view_right * prop_size)
        radius_2d = view3d_utils.location_3d_to_region_2d(context.region, rv3d, radius_world_loc)
        if not radius_2d: return
            
        dist = (mathutils.Vector(center_2d) - mathutils.Vector(radius_2d)).length
        if dist <= 0.5: return
            
        segments = 256  # circle subdivisions (smoother)
        vertices = []
        cx, cy = center_2d
        for i in range(segments):
            angle = 2 * math.pi * i / segments
            vertices.append((cx + math.cos(angle) * dist, cy + math.sin(angle) * dist))
            
        try: shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception: shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
            
        # Vulkan では LINE_LOOP の閉じる辺が落ちるため、始点を足した LINE_STRIP で閉じる。
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": vertices + vertices[:1]})
        shader.bind()
        gpu.state.blend_set('ALPHA')
        try: gpu.state.multisample_set(aa_enabled)
        except Exception: pass
        try: gpu.state.line_smooth_set(aa_enabled)
        except Exception: pass
        try: gpu.state.alpha_to_coverage_set(aa_enabled)
        except Exception: pass

        # Lightweight 2-pass AA
        lw = float(draw_line_width)
        if use_2pass_aa and draw_color[3] > 0.001:
            aa = max(0.0, min(1.0, float(draw_color[3]) * 0.18))
            shader.uniform_float("color", (draw_color[0], draw_color[1], draw_color[2], aa))
            gpu.state.line_width_set(lw + 1.0)
            batch.draw(shader)

        shader.uniform_float("color", draw_color)
        gpu.state.line_width_set(lw)
        batch.draw(shader)

        try:
            if prev_blend is not None: gpu.state.blend_set(prev_blend)
            else: gpu.state.blend_set('NONE')
        except Exception: pass
        try: gpu.state.line_width_set(prev_line_width)
        except Exception: pass
        try:
            if prev_ms is not None: gpu.state.multisample_set(prev_ms)
        except Exception: pass
        try:
            if prev_ls is not None: gpu.state.line_smooth_set(prev_ls)
        except Exception: pass
        try:
            if prev_a2c is not None: gpu.state.alpha_to_coverage_set(prev_a2c)
        except Exception: pass
        try:
            if prev_depth is not None: gpu.state.depth_test_set(prev_depth)
        except Exception: pass
        try:
            if prev_depth_mask is not None: gpu.state.depth_mask_set(prev_depth_mask)
        except Exception: pass
        try:
            if prev_cull is not None: gpu.state.face_culling_set(prev_cull)
        except Exception: pass

    def _rotation_snap_tick_radius_px(self, context, region, rv3d, center_world, basis_u):
        """Stable Ctrl rotation snap tick radius in pixels.

        Use the same view-scale basis as the 3D Smart Gizmo and multiply by
        the Smart Gizmo display scale, so white snap ticks stay stable while
        dragging and resize with the 3D Smart Gizmo Display Scale setting.
        """
        try:
            from . import csdt_gizmo as _smart_gizmo
            base_scale = _smart_gizmo._smart_get_view_scale(region, rv3d, center_world)
            gscale = float(_smart_gizmo._smart_screen_scale())
        except Exception:
            base_scale = None
            try:
                prefs = _prefs(context)
                gscale = float(getattr(prefs, 'smart_gizmo_screen_scale', 1.0) if prefs else 1.0)
            except Exception:
                gscale = 1.0
        try:
            prefs = _prefs(context)
            axis_scale = float(getattr(prefs, 'smart_axis_scale', 1.0) if prefs else 1.0)
        except Exception:
            axis_scale = 1.0
        gscale = max(0.10, min(gscale, 6.0))
        axis_scale = max(0.10, min(axis_scale, 6.0))
        if base_scale is not None:
            try:
                radius_world = base_scale * gscale * axis_scale * 0.55
                c2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center_world)
                r2d = view3d_utils.location_3d_to_region_2d(region, rv3d, center_world + basis_u.normalized() * radius_world)
                if c2d is not None and r2d is not None:
                    radius = float((r2d - c2d).length)
                else:
                    radius = 72.0 * gscale * axis_scale
            except Exception:
                radius = 72.0 * gscale * axis_scale
        else:
            radius = 72.0 * gscale * axis_scale
        try:
            limit = max(32.0, min(float(region.width), float(region.height)) * 0.48)
        except Exception:
            limit = 320.0
        return max(24.0 * gscale, min(float(radius), limit))

    def _draw_rotation_snap_ticks(self):
        context = bpy.context
        if not self._draw_ctx_ok(context):
            return
        if str(getattr(self, 'mode', '') or '') != 'R':
            return

        mods = self._active_mods_dict()
        if self._effective_snap_mode(context, mods) != 'GRID':
            return

        try:
            region = context.region
            rv3d = context.region_data
            if region is None or getattr(region, 'type', None) != 'WINDOW' or rv3d is None:
                return
        except Exception:
            return

        try:
            if self._is_ctrl_increment_snap(mods):
                step = self._rotation_increment_step_rad(context, bool(mods.get('shift')))
            else:
                step = math.radians(float(getattr(_prefs(context), 'snap_rotate_step_deg', 5.0) if _prefs(context) else 5.0))
        except Exception:
            step = math.radians(5.0)
        if step <= 0.0:
            return

        try:
            center_world = getattr(self, 'current_pivot_3d', None) or getattr(self, 'pivot_3d', None)
            if center_world is None:
                return
            center = view3d_utils.location_3d_to_region_2d(region, rv3d, center_world)
            if center is None:
                center = getattr(self, 'pivot_2d', None)
            if center is None:
                return
            cx, cy = float(center.x), float(center.y)
        except Exception:
            return

        radius = 0.0

        max_marks = 720
        count = int(max(1, min(max_marks, math.floor((math.tau / step) + 0.5))))
        if count <= 0:
            return
        draw_step = math.tau / float(count) if count >= max_marks and step < (math.tau / max_marks) else step

        verts = []
        try:
            axis_world = None
            try:
                if self._use_free_axis_rotation():
                    axis_world = getattr(self, '_last_rot_axis', None)
            except Exception:
                axis_world = None
            if axis_world is None or getattr(axis_world, 'length', 0.0) < 1e-8:
                axis_world = self._rotation_axis(context)
            axis_world = mathutils.Vector(axis_world).normalized()

            view_right = rv3d.view_rotation @ mathutils.Vector((1.0, 0.0, 0.0))
            view_up = rv3d.view_rotation @ mathutils.Vector((0.0, 1.0, 0.0))
            basis_u = view_right - axis_world * view_right.dot(axis_world)
            if basis_u.length < 1e-8:
                basis_u = view_up - axis_world * view_up.dot(axis_world)
            if basis_u.length < 1e-8:
                ref = mathutils.Vector((1.0, 0.0, 0.0)) if abs(axis_world.x) < 0.9 else mathutils.Vector((0.0, 1.0, 0.0))
                basis_u = ref - axis_world * ref.dot(axis_world)
            basis_u.normalize()
            radius = self._rotation_snap_tick_radius_px(context, region, rv3d, center_world, basis_u)
            if radius <= 0.0:
                return
            basis_v = axis_world.cross(basis_u)
            if basis_v.length < 1e-8:
                return
            basis_v.normalize()

            p0 = view3d_utils.region_2d_to_location_3d(region, rv3d, (cx, cy), center_world)
            p1 = view3d_utils.region_2d_to_location_3d(region, rv3d, (cx + 1.0, cy), center_world)
            p2 = view3d_utils.region_2d_to_location_3d(region, rv3d, (cx, cy + 1.0), center_world)
            px_world = 0.0
            if p0 is not None and p1 is not None:
                px_world = max(px_world, float((p1 - p0).length))
            if p0 is not None and p2 is not None:
                px_world = max(px_world, float((p2 - p0).length))
            if px_world <= 1e-12:
                px_world = 0.01

            ring_world = px_world * float(radius)
            a = 0.0
            i = 0
            while a < math.tau - 1e-7 and i < max_marks:
                try:
                    major = (i % 5 == 0)
                    ca, sa = math.cos(a), math.sin(a)
                    radial = (basis_u * ca) + (basis_v * sa)
                    if radial.length < 1e-8:
                        i += 1
                        a += draw_step
                        continue
                    radial.normalize()
                    inner_world = center_world + radial * (ring_world + px_world * 3.0)
                    outer_world = center_world + radial * (ring_world + px_world * (10.0 if major else 6.0))
                    inner_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, inner_world)
                    outer_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, outer_world)
                    if inner_2d is not None and outer_2d is not None:
                        verts.append((float(inner_2d.x), float(inner_2d.y)))
                        verts.append((float(outer_2d.x), float(outer_2d.y)))
                except Exception:
                    pass
                i += 1
                a += draw_step
        except Exception:
            verts = []

        if not verts:
            return

        prev_blend = getattr(gpu.state, 'blend_get', lambda: None)()
        prev_line_width = getattr(gpu.state, 'line_width_get', lambda: 1.0)()
        prev_ms = getattr(gpu.state, 'multisample_get', lambda: None)()
        prev_ls = getattr(gpu.state, 'line_smooth_get', lambda: None)()
        prev_a2c = getattr(gpu.state, 'alpha_to_coverage_get', lambda: None)()
        try:
            try:
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
            except Exception:
                shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'LINES', {'pos': verts})
            gpu.state.blend_set('ALPHA')
            try: gpu.state.multisample_set(True)
            except Exception: pass
            try: gpu.state.line_smooth_set(True)
            except Exception: pass
            try: gpu.state.alpha_to_coverage_set(True)
            except Exception: pass
            gpu.state.line_width_set(1.25)
            shader.bind()
            shader.uniform_float('color', (1.0, 1.0, 1.0, 0.92))
            batch.draw(shader)
        except Exception:
            pass
        finally:
            try:
                if prev_blend is not None: gpu.state.blend_set(prev_blend)
                else: gpu.state.blend_set('NONE')
            except Exception: pass
            try: gpu.state.line_width_set(prev_line_width)
            except Exception: pass
            try:
                if prev_ms is not None: gpu.state.multisample_set(prev_ms)
            except Exception: pass
            try:
                if prev_ls is not None: gpu.state.line_smooth_set(prev_ls)
            except Exception: pass
            try:
                if prev_a2c is not None: gpu.state.alpha_to_coverage_set(prev_a2c)
            except Exception: pass

    def _draw_snap_base_marker(self):
        context = bpy.context
        if not self._draw_ctx_ok(context):
            return
        # Match Blender's native Snap Base UI: the orange candidate marker is
        # visible only while B is actively picking a base point.  After confirm,
        # the internal source/base point remains active for snapping, but the
        # orange box is removed.
        if not bool(getattr(self, '_snap_base_pick_active', False)):
            return
        try:
            point = getattr(self, '_snap_base_candidate_3d', None)
        except Exception:
            point = None
        if point is None:
            return
        try:
            region = context.region
            rv3d = context.region_data
            loc2d = view3d_utils.location_3d_to_region_2d(region, rv3d, point)
            if loc2d is None:
                return
            x, y = float(loc2d.x), float(loc2d.y)
        except Exception:
            return

        try:
            prefs = _prefs(context)
            gscale = float(getattr(prefs, 'smart_gizmo_screen_scale', 1.0) if prefs else 1.0)
        except Exception:
            gscale = 1.0
        gscale = max(0.5, min(gscale, 2.5))
        active_pick = True
        size = max(8.0, min(22.0, 10.0 * gscale))
        half = size * 0.5
        verts_line = [
            (x - half, y - half), (x + half, y - half), (x + half, y + half),
            (x - half, y + half), (x - half, y - half),
        ]
        cross = [
            (x - half * 1.35, y), (x + half * 1.35, y),
            (x, y - half * 1.35), (x, y + half * 1.35),
        ]
        verts_fill = [
            (x - half, y - half), (x + half, y - half), (x + half, y + half),
            (x - half, y - half), (x + half, y + half), (x - half, y + half),
        ]

        prev_blend = getattr(gpu.state, 'blend_get', lambda: None)()
        prev_line_width = getattr(gpu.state, 'line_width_get', lambda: 1.0)()
        try:
            try:
                shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
            except Exception:
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
            gpu.state.blend_set('ALPHA')
            shader.bind()
            fill = batch_for_shader(shader, 'TRIS', {'pos': verts_fill})
            shader.uniform_float('color', (1.0, 0.44, 0.02, 0.24 if active_pick else 0.16))
            fill.draw(shader)
            line = batch_for_shader(shader, 'LINE_STRIP', {'pos': verts_line})
            gpu.state.line_width_set(2.0 if active_pick else 1.5)
            shader.uniform_float('color', (1.0, 0.48, 0.02, 0.98))
            line.draw(shader)
            cross_batch = batch_for_shader(shader, 'LINES', {'pos': cross})
            gpu.state.line_width_set(1.5 if active_pick else 1.2)
            shader.uniform_float('color', (1.0, 0.62, 0.05, 0.95))
            cross_batch.draw(shader)
        except Exception:
            pass
        finally:
            try:
                if prev_blend is not None:
                    gpu.state.blend_set(prev_blend)
                else:
                    gpu.state.blend_set('NONE')
            except Exception:
                pass
            try:
                gpu.state.line_width_set(prev_line_width)
            except Exception:
                pass

    def _hud_lines(self, context=None):
        context = context or bpy.context

        def _enum_label(value):
            key = str(value or '').upper()
            return {
                'GLOBAL': TI('Global', 'グローバル'),
                'LOCAL': TI('Local', 'ローカル'),
                'VIEW': TI('View', 'ビュー'),
                'NORMAL': TI('Normal', '法線'),
                'GIMBAL': TI('Gimbal', 'ジンバル'),
                'CURSOR': TI('Cursor', 'カーソル'),
                'MEDIAN_POINT': TI('Median Point', '中点'),
                'INDIVIDUAL_ORIGINS': TI('Individual Origins', 'それぞれの原点'),
                'ACTIVE_ELEMENT': TI('Active Element', 'アクティブ要素'),
                'BOUNDING_BOX_CENTER': TI('Bounding Box Center', 'バウンディングボックス中心'),
            }.get(key, str(value or ''))

        lines = []
        mode_name = {'G': TI('Move (G)', '移動 (G)'), 'R': TI('Rotate (R)', '回転 (R)'), 'S': TI('Scale (S)', '拡大縮小 (S)')}
        lines.append(f"Smart GRS | {mode_name.get(self.mode, self.mode)}")
        if self.mode == 'G':
            mv = getattr(self, '_last_move', mathutils.Vector((0, 0, 0)))
            lines.append(f"Δ=({mv.x:.4g}, {mv.y:.4g}, {mv.z:.4g}) | |Δ|={mv.length:.4g}")
        elif self.mode == 'R':
            deg = math.degrees(getattr(self, '_last_rot', 0.0))
            axis = getattr(self, '_last_rot_axis', mathutils.Vector((0, 0, 1)))
            comps = getattr(self, '_last_rot_components_deg', mathutils.Vector((0, 0, 0)))
            lines.append(f"{TI('Angle', '角度')}={deg:.4g}° | {TI('Axis', '軸')}=({axis.x:.3g}, {axis.y:.3g}, {axis.z:.3g})")
            lines.append(f"Δ{TI('Rotation', '回転')}≈({comps.x:.4g}°, {comps.y:.4g}°, {comps.z:.4g}°)")
        elif self.mode == 'S':
            sc = getattr(self, '_last_scale', 1.0)
            scv = getattr(self, '_last_scale_components', mathutils.Vector((sc, sc, sc)))
            lines.append(f"{TI('Scale', '拡大縮小')}=({scv.x:.4g}, {scv.y:.4g}, {scv.z:.4g}) | {TI('Uniform', '均一')}={sc:.4g}x")

        space_label = _enum_label(getattr(self, 'constraint_space', ''))
        if self.constraint_kind != 'NONE':
            if self.constraint_kind == 'AXIS':
                ax = ['X', 'Y', 'Z'][self.constraint_idx] if self.constraint_idx in (0, 1, 2) else '?'
                lines.append(f"{TI('Constraint', '拘束')}={ax} | {TI('Space', '空間')}={space_label}")
            else:
                excl = ['X', 'Y', 'Z'][self.constraint_idx] if self.constraint_idx in (0, 1, 2) else '?'
                lines.append(f"{TI('Constraint', '拘束')}={TI('Plane', '平面')}({TI('not', '除外')} {excl}) | {TI('Space', '空間')}={space_label}")
        else:
            lines.append(f"{TI('Space', '空間')}={space_label}")

        try:
            pivot_name = getattr(self, 'pivot_mode_current', context.scene.tool_settings.transform_pivot_point)
            lines.append(f"{TI('Pivot', 'ピボット')}={_enum_label(pivot_name)}")
        except Exception:
            pass
        if getattr(self, '_snap_hold', None):
            lines.append(f"{TI('Snap', 'スナップ')}={_enum_label(self._snap_hold)}")
        try:
            if bool(getattr(self, '_snap_base_active', False)):
                base = getattr(self, '_snap_base_3d', None)
                if base is not None:
                    lines.append(f"{TI('Snap Base', 'スナップベース')}=({base.x:.4g}, {base.y:.4g}, {base.z:.4g})")
        except Exception:
            pass
        try:
            count = len(getattr(self, '_custom_snap_points', None) or [])
            if count:
                lines.append(f"{TI('Snap Points', 'スナップポイント')}={count}")
        except Exception:
            pass
        if getattr(self, 'numeric_input', ''):
            lines.append(f"{TI('Input', '入力')}={self.numeric_input}")
        return lines

    def _status_text_update(self, context=None):
        context = context or bpy.context
        try:
            txt = self._standard_status_bar_text(context)
            header = self._status_mode_and_value_text(context)
        except Exception:
            txt = "Smart G-R-S"
            header = txt
        try:
            if getattr(context, 'workspace', None):
                context.workspace.status_text_set(txt)
        except Exception:
            pass
        try:
            area = getattr(self, '_area', None) or getattr(context, 'area', None)
            if area:
                area.header_text_set(header)
        except Exception:
            pass

    def _status_text_clear(self, context=None):
        context = context or bpy.context
        try:
            if getattr(context, 'workspace', None):
                context.workspace.status_text_set(None)
        except Exception:
            pass
        try:
            area = getattr(self, '_area', None) or getattr(context, 'area', None)
            if area:
                area.header_text_set(None)
        except Exception:
            pass

    def _draw_hud(self):
        context = bpy.context
        resolved = self._resolve_draw_context(context)
        if resolved is None:
            return
        area, region, rv3d = resolved

        prefs = _prefs(context)
        if prefs and hasattr(prefs, 'hud_enabled') and not prefs.hud_enabled:
            return

        if region is None or getattr(region, 'type', None) != 'WINDOW':
            return

        rv3d = rv3d or getattr(self, '_rv3d', None)
        font_id = 0
        fs = int(getattr(prefs, 'hud_font_size', 11) if prefs else 11)
        fs = max(8, min(fs, 32))
        hud_mode = str(getattr(prefs, 'hud_anchor_mode', 'GIZMO') if prefs else 'GIZMO')
        off_x = int(getattr(prefs, 'hud_offset_x', 18) if prefs else 18)
        off_y = int(getattr(prefs, 'hud_offset_y', 24) if prefs else 24)
        hud_col = tuple(getattr(prefs, 'hud_text_color', (1.0, 1.0, 1.0, 1.0)) if prefs else (1.0, 1.0, 1.0, 1.0))

        anchor = None
        try:
            world_pivot = getattr(self, 'current_pivot_3d', None) or getattr(self, 'pivot_3d', None)
            if world_pivot is not None and rv3d is not None:
                anchor = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pivot)
        except Exception:
            anchor = None

        if hud_mode == 'VIEW' or anchor is None:
            x = int(off_x)
            y = int(region.height) - int(off_y)
        else:
            x = int(anchor.x + off_x)
            y = int(anchor.y + off_y)
        x = max(8, min(int(region.width) - 8, x))
        y = max(16, min(int(region.height) - 8, y))

        try:
            blf.color(font_id, hud_col[0], hud_col[1], hud_col[2], hud_col[3])
        except Exception:
            pass
        try:
            blf.enable(font_id, blf.SHADOW)
            blf.shadow(font_id, 5, 0.0, 0.0, 0.0, 0.8)
            blf.shadow_offset(font_id, 1, -1)
        except Exception:
            pass

        line_step = max(12, fs + 3)

        def draw_line(txt, dy=None):
            dy = line_step if dy is None else dy
            nonlocal y
            try:
                try:
                    blf.size(font_id, fs, 72)
                except TypeError:
                    blf.size(font_id, fs)
                blf.position(font_id, x, y, 0)
                blf.draw(font_id, txt)
            except Exception:
                pass
            y -= dy

        for line in self._hud_lines(context):
            draw_line(line)

        if bool(getattr(self, '_hud_show_help', False)):
            draw_line(TI('Enter: Apply  |  Esc/RMB: Cancel', 'Enter: 確定  |  Esc/RMB: キャンセル'))
            draw_line(TI('H: Toggle help  |  X/Y/Z: Axis  |  Shift+X/Y/Z: Plane  |  MMB: Auto Axis  |  Shift+MMB: Auto Plane', 'H: ヘルプ切替  |  X/Y/Z: 軸  |  Shift+X/Y/Z: 平面  |  中クリック: 自動軸  |  Shift+中クリック: 自動平面'))
            draw_line(TI('Type numbers / Numpad for numeric input', '数値入力はキーボードまたはテンキーで入力'))
        else:
            draw_line(TI('H: Help  |  Type numbers / Numpad, Enter=Apply', 'H: ヘルプ  |  数値入力はキーボード/テンキー, Enter=確定'))

        try:
            blf.disable(font_id, blf.SHADOW)
        except Exception:
            pass

    def _add_draw_handlers(self):
        if getattr(self, "_draw_handle_view", None) is None:
            self._draw_handle_view = bpy.types.SpaceView3D.draw_handler_add(self._draw_constraint_line, (), 'WINDOW', 'POST_VIEW')
        self._add_post_pixel_handlers()

    def _post_pixel_draw_callbacks(self):
        return (
            ("_draw_handle_px", self._draw_prop_circle),
            ("_draw_handle_rot_ticks", self._draw_rotation_snap_ticks),
            ("_draw_handle_snap_base", self._draw_snap_base_marker),
            ("_draw_handle_hud", self._draw_hud),
        )

    def _add_post_pixel_handlers(self):
        if getattr(self, "_draw_handle_px", None) is None:
            self._draw_handle_px = bpy.types.SpaceView3D.draw_handler_add(self._draw_prop_circle, (), 'WINDOW', 'POST_PIXEL')
        if getattr(self, "_draw_handle_rot_ticks", None) is None:
            self._draw_handle_rot_ticks = bpy.types.SpaceView3D.draw_handler_add(self._draw_rotation_snap_ticks, (), 'WINDOW', 'POST_PIXEL')
        if getattr(self, "_draw_handle_snap_base", None) is None:
            self._draw_handle_snap_base = bpy.types.SpaceView3D.draw_handler_add(self._draw_snap_base_marker, (), 'WINDOW', 'POST_PIXEL')
        if getattr(self, "_draw_handle_hud", None) is None:
            self._draw_handle_hud = bpy.types.SpaceView3D.draw_handler_add(self._draw_hud, (), 'WINDOW', 'POST_PIXEL')
        return True

    def _remove_post_pixel_handlers(self):
        removed = False
        for attr, _callback in self._post_pixel_draw_callbacks():
            handle = getattr(self, attr, None)
            if handle is not None:
                try:
                    bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
                except Exception:
                    pass
                setattr(self, attr, None)
                removed = True
        return removed

    def _rehook_post_pixel_handlers_after_overlay(self):
        """Keep native HUD handlers and register them after Smart Overlay."""
        if not bool(getattr(self, '_in_modal', False)):
            return False
        self._overlay_front_replay_managed = False
        self._remove_post_pixel_handlers()
        return bool(self._add_post_pixel_handlers())

    def _ensure_independent_post_pixel_handlers(self):
        """Recover all HUD handlers if an older proxy-draw build removed them."""
        self._overlay_front_replay_managed = False
        return bool(self._add_post_pixel_handlers())

    def _remove_draw_handlers(self):
        self._overlay_front_replay_managed = False
        for attr in ("_draw_handle_view", "_draw_handle_px", "_draw_handle_rot_ticks", "_draw_handle_snap_base", "_draw_handle_hud"):
            h = getattr(self, attr, None)
            if h:
                try: bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
                except Exception: pass
                setattr(self, attr, None)

    # =========================================================
    # Execution
    # =========================================================

    # ---------------------------------------------------------
    # Numeric Input
    # ---------------------------------------------------------
    def _numeric_event(self, event):
        """Update numeric input buffer. Returns True if consumed."""
        if event.value != 'PRESS':
            return False

        # Backspace / clear
        if event.type in {'BACK_SPACE', 'DEL'}:
            if getattr(self, 'numeric_input', ''):
                self.numeric_input = self.numeric_input[:-1]
                return True
            return False

        if event.type == 'MINUS':
            if not getattr(self, 'numeric_input', ''):
                self.numeric_input = '-'
                return True
            return False

        # Use unicode/ascii when available.
        ch = getattr(event, 'unicode', '') or getattr(event, 'ascii', '')
        if ch and ch in '0123456789.':
            s = getattr(self, 'numeric_input', '')
            if ch == '.' and '.' in s:
                return True
            self.numeric_input = s + ch
            return True

        # Numpad period
        if event.type in {'PERIOD', 'NUMPAD_PERIOD'}:
            s = getattr(self, 'numeric_input', '')
            if '.' not in s:
                self.numeric_input = s + '.'
            return True

        # Number keys by event.type
        num_map = {
            'ZERO': '0', 'ONE': '1', 'TWO': '2', 'THREE': '3', 'FOUR': '4',
            'FIVE': '5', 'SIX': '6', 'SEVEN': '7', 'EIGHT': '8', 'NINE': '9',
            'NUMPAD_0': '0', 'NUMPAD_1': '1', 'NUMPAD_2': '2', 'NUMPAD_3': '3', 'NUMPAD_4': '4',
            'NUMPAD_5': '5', 'NUMPAD_6': '6', 'NUMPAD_7': '7', 'NUMPAD_8': '8', 'NUMPAD_9': '9',
        }
        if event.type in num_map:
            self.numeric_input = getattr(self, 'numeric_input', '') + num_map[event.type]
            return True

        return False

    def _apply_numeric_and_finish(self, context):
        s = (getattr(self, 'numeric_input', '') or '').strip()
        if not s or s == '-':
            return False
        try:
            val = float(s)
        except Exception:
            return False

        # Apply based on mode.
        self._restore_initial_state(context)
        self._smart_gizmo_live_follow_capture(context)

        if self.mode == 'G':
            # If constrained: apply along constraint basis. Else: along last move direction (or X).
            if self.constraint_kind != 'NONE' and self.constraint_idx in (0, 1, 2):
                axis = self._get_constraint_axis(context, self.constraint_idx)
                if self.constraint_kind == 'AXIS':
                    move = axis * val
                else:
                    # plane: distribute equally on two axes in plane
                    axes = [self._get_constraint_axis(context, 0), self._get_constraint_axis(context, 1), self._get_constraint_axis(context, 2)]
                    axes.pop(self.constraint_idx)
                    move = (axes[0] + axes[1]).normalized() * val
            else:
                mv = getattr(self, '_last_move', mathutils.Vector((1, 0, 0)))
                if mv.length < 1e-8:
                    mv = mathutils.Vector((1, 0, 0))
                move = mv.normalized() * val
            self.current_pivot_3d = self.pivot_3d + move
            self._last_move = move.copy()
            M_move = mathutils.Matrix.Translation(move)
            if self._mesh_island_individual_mode(context):
                self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: M_move)
            else:
                self._apply_world_matrix(context, M_move)

        elif self.mode == 'R':
            ang = math.radians(val)
            rot_axis = self._rotation_axis(context)
            self._last_rot = float(ang)
            self._last_rot_axis = rot_axis.copy()
            self._last_rot_components_deg = mathutils.Vector((
                math.degrees(ang * rot_axis.x),
                math.degrees(ang * rot_axis.y),
                math.degrees(ang * rot_axis.z),
            ))
            if self._mesh_island_individual_mode(context):
                self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: self._make_rotation_matrix(_center, rot_axis, ang))
            elif self._object_individual_origins_mode(context):
                self._apply_object_individual_world_matrix(context, lambda _origin, _obj, _orig: self._make_rotation_matrix(_origin, rot_axis, ang))
            else:
                self._apply_world_matrix(context, self._make_rotation_matrix(self.pivot_3d, rot_axis, ang))

        elif self.mode == 'S':
            factor = val
            sx, sy, sz = self._scale_factors_axes(factor)
            self._last_scale = float(factor)
            self._last_scale_components = mathutils.Vector((sx, sy, sz))
            if self._mesh_island_individual_mode(context):
                self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: self._make_scale_matrix(context, _center, sx, sy, sz))
            elif self._object_individual_origins_mode(context):
                self._apply_object_individual_world_matrix(context, lambda _origin, _obj, _orig: self._make_scale_matrix(context, _origin, sx, sy, sz))
            else:
                self._apply_world_matrix(context, self._make_scale_matrix(context, self.pivot_3d, sx, sy, sz))

        self._smart_gizmo_live_follow_apply(context)
        return True

    # ---------------------------------------------------------
    # Snapping (temporary holds: V=VERT, C=EDGE, X=GRID)
    # ---------------------------------------------------------
    def _raycast_world(self, context, mx, my):
        region, rv3d = context.region, context.region_data
        if not region or not rv3d:
            return None
        try:
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (mx, my))
            direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, (mx, my))
        except Exception:
            return None
        try:
            depsgraph = context.evaluated_depsgraph_get()
            hit, loc, nor, face_idx, obj, mat = context.scene.ray_cast(depsgraph, origin, direction)
            if hit:
                return (loc, nor, face_idx, obj)
        except Exception:
            pass
        return None

    def _snap_target_world(self, context, mx, my, snap_mode: str):
        # Use the same screen-space priority as B/Snap Base and A/Snap Point:
        # custom points when explicitly requested, then vertices/control points,
        # then edge projections, then face/raycast fallback.  Vertices are
        # evaluated before edges so edge endpoints can be selected precisely.
        try:
            mode = str(snap_mode or '').upper()
            if mode == 'POINT':
                p = self._snap_screen_candidate_from_mouse(context, mx, my, prefer_source=False, allow_vertices=True, allow_edges=True, allow_custom=True, allow_faces=True)
            elif mode == 'VERT':
                p = self._snap_screen_candidate_from_mouse(context, mx, my, prefer_source=False, allow_vertices=True, allow_edges=False, allow_custom=False, allow_faces=False)
            elif mode == 'EDGE':
                p = self._snap_screen_candidate_from_mouse(context, mx, my, prefer_source=False, allow_vertices=True, allow_edges=True, allow_custom=False, allow_faces=False)
            elif mode == 'FACE':
                p = self._snap_screen_candidate_from_mouse(context, mx, my, prefer_source=False, allow_vertices=False, allow_edges=False, allow_custom=False, allow_faces=True)
            else:
                p = None
            if p is not None:
                return p.copy()
        except Exception:
            pass

        custom_point = self._custom_snap_point_for_mouse(context, mx, my)
        if custom_point is not None:
            return custom_point
        rc = self._raycast_world(context, mx, my)
        if not rc:
            return None
        loc, nor, face_idx, obj = rc
        if not obj:
            return loc

        if snap_mode in {'VERT', 'EDGE'} and obj.type == 'MESH':
            try:
                cache = getattr(self, '_snap_kd_cache', None)
                if cache is None:
                    self._snap_kd_cache = {}
                    cache = self._snap_kd_cache
                key = obj.as_pointer()
                kd = cache.get(key)
                if kd is None:
                    depsgraph = context.evaluated_depsgraph_get()
                    obj_eval = obj.evaluated_get(depsgraph)
                    me = obj_eval.to_mesh()
                    verts = [obj_eval.matrix_world @ v.co for v in me.vertices]
                    kdt = mathutils.kdtree.KDTree(len(verts))
                    for i, co in enumerate(verts):
                        kdt.insert(co, i)
                    kdt.balance()
                    try:
                        obj_eval.to_mesh_clear()
                    except Exception:
                        pass
                    cache[key] = kdt
                    kd = cache[key]
                co, idx, dist = kd.find(loc)
                return co
            except Exception:
                return loc

        return loc

    def _apply_snap_to_move(self, context, move, cx, cy, mods):
        prefs = _prefs(context)
        snap = self._effective_snap_mode(context, mods)
        if not snap:
            return move

        # Vertex/Edge/Face/custom snap point: move the active snap base to
        # the target point.  The base defaults to the transform pivot and can be
        # changed during the modal operation with B, matching Blender's Snap
        # Base concept for the Smart G-R-S backend.
        if snap in {'VERT', 'EDGE', 'FACE', 'POINT'}:
            tgt = self._snap_target_world(context, cx, cy, snap)
            if tgt is None:
                return move
            base_point = self._current_snap_base_point()
            snapped = tgt - base_point
            # Respect axis/plane constraint
            if self.constraint_kind == 'AXIS' and self.constraint_idx in (0, 1, 2):
                axis = self._get_constraint_axis(context, self.constraint_idx)
                snapped = axis * snapped.dot(axis)
            elif self.constraint_kind == 'PLANE' and self.constraint_idx in (0, 1, 2):
                axis = self._get_constraint_axis(context, self.constraint_idx)
                snapped = snapped - axis * snapped.dot(axis)
            return snapped

        # Grid / Increment snap. Ctrl follows Blender's standard increment snap:
        # main grid unit for Ctrl, subdivision unit for Ctrl+Shift. Shift+Tab
        # toggles scene snapping during the modal operation.
        if snap == 'GRID':
            ctrl_increment = self._is_ctrl_increment_snap(mods)
            if ctrl_increment:
                step = self._view3d_grid_increment_step(context, bool((mods or {}).get('shift')))
            else:
                step = float(getattr(prefs, 'snap_move_grid_step', 0.1) if prefs else 0.1)
            if step <= 0:
                return move

            base_move = move
            # Ctrl numeric/increment snap is transform-start relative.  Do not
            # switch to absolute world-grid snapping at the moment Ctrl is
            # pressed; the delta itself is the value that must be quantized.
            # Keep the non-Ctrl GRID path relative as before; active B snap-base
            # target snapping remains separate and is disabled only for Ctrl's
            # numeric increment mode.
            absolute_grid = False
            use_active_snap_base = bool(getattr(self, '_snap_base_active', False)) and not ctrl_increment
            if absolute_grid or use_active_snap_base:
                try:
                    base_point = self._current_snap_base_point()
                    target = base_point + move
                    snapped_target = mathutils.Vector((
                        round(float(target.x) / step) * step,
                        round(float(target.y) / step) * step,
                        round(float(target.z) / step) * step,
                    ))
                    base_move = snapped_target - base_point
                except Exception:
                    base_move = move

            if self.constraint_kind == 'AXIS' and self.constraint_idx in (0, 1, 2):
                axis = self._get_constraint_axis(context, self.constraint_idx)
                s = base_move.dot(axis)
                if not (absolute_grid or use_active_snap_base):
                    s = round(s / step) * step
                return axis * s
            if self.constraint_kind == 'PLANE' and self.constraint_idx in (0, 1, 2):
                # Quantize components in plane basis
                axes = [self._get_constraint_axis(context, 0), self._get_constraint_axis(context, 1), self._get_constraint_axis(context, 2)]
                n = axes[self.constraint_idx]
                u = axes[(self.constraint_idx + 1) % 3]
                v = n.cross(u).normalized()
                u = v.cross(n).normalized()
                su = base_move.dot(u)
                sv = base_move.dot(v)
                if not (absolute_grid or use_active_snap_base):
                    su = round(su / step) * step
                    sv = round(sv / step) * step
                return (u * su) + (v * sv)

            if absolute_grid or use_active_snap_base:
                return base_move

            # Unconstrained: global quantize
            return mathutils.Vector((round(base_move.x / step) * step, round(base_move.y / step) * step, round(base_move.z / step) * step))

        return move

    def _apply_snap_to_rotate(self, context, rot_rad, mods):
        snap = self._effective_snap_mode(context, mods)
        if snap != 'GRID':
            return rot_rad
        ctrl_increment = self._is_ctrl_increment_snap(mods)
        if ctrl_increment:
            step = self._rotation_increment_step_rad(context, bool((mods or {}).get('shift')))
        else:
            prefs = _prefs(context)
            step_deg = float(getattr(prefs, 'snap_rotate_step_deg', 5.0) if prefs else 5.0)
            if step_deg <= 0:
                return rot_rad
            step = math.radians(step_deg)
        if step <= 0:
            return rot_rad

        # Ctrl numeric/increment snap must be based on the transform-start
        # rotation delta, not on the frame where Ctrl was pressed.  The incoming
        # rot_rad is the total rotation from the modal operation start, so round
        # it directly.  This keeps cases like start 3deg -> raw 96deg with a
        # 10deg step at start+90deg (=93deg final object rotation).
        if ctrl_increment:
            return round(float(rot_rad) / step) * step

        try:
            if bool(getattr(self, '_rotation_snap_anchor_active', False)):
                anchor_raw = float(getattr(self, '_rotation_snap_anchor_raw', rot_rad))
                anchor_value = float(getattr(self, '_rotation_snap_anchor_value', rot_rad))
                return anchor_value + round((float(rot_rad) - anchor_raw) / step) * step
        except Exception:
            pass
        return round(float(rot_rad) / step) * step

    def _apply_snap_to_scale(self, context, factor, mods):
        snap = self._effective_snap_mode(context, mods)
        if snap != 'GRID':
            return factor
        if self._is_ctrl_increment_snap(mods):
            step = self._scale_increment_step(context, bool((mods or {}).get('shift')))
        else:
            prefs = _prefs(context)
            step = float(getattr(prefs, 'snap_scale_step', 0.1) if prefs else 0.1)
        if step <= 0:
            return factor
        # Scale snapping is always transform-start relative.  factor=1.0 is the
        # value at the modal start, so Ctrl rounds the delta from 1.0 rather
        # than the value present when Ctrl was pressed.
        return 1.0 + round((float(factor) - 1.0) / step) * step
    def execute(self, context):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED'}
        mode = str(getattr(self, 'mode', 'G') or 'G').upper()
        if mode not in {'G', 'R', 'S'}:
            mode = 'G'
        return _invoke_native_grs_transform(mode, 'EXEC_DEFAULT', self, context=context)

    def invoke(self, context, event):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED', 'PASS_THROUGH'}
        try:
            current_mode = str(getattr(self, 'mode', '') or '')
        except Exception:
            current_mode = ''
        try:
            event_type = str(getattr(event, 'type', '') or '')
        except Exception:
            event_type = ''

        pending_start_mouse = None
        pending_invoke_mouse = None
        try:
            dn = getattr(bpy.app, 'driver_namespace', None)
            if isinstance(dn, dict):
                pending_start_mouse = dn.pop('STS_PENDING_GRS_START_MOUSE', None)
                pending_invoke_mouse = dn.pop('STS_PENDING_GRS_INVOKE_MOUSE', None)
        except Exception:
            pending_start_mouse = None
            pending_invoke_mouse = None

        try:
            if event_type in {'G', 'R', 'S'} and (current_mode not in {'G', 'R', 'S'} or (current_mode == 'G' and event_type in {'R', 'S'})):
                self.mode = event_type
        except Exception:
            pass

        if getattr(getattr(context, 'area', None), 'type', '') == 'IMAGE_EDITOR':
            # UV Editor transforms are native Blender 2D transforms.  Smart G-R-S
            # acts as a manual keymap-compatible wrapper and passes the current
            # proportional editing payload explicitly so UV proportional editing
            # behaves the same as Blender standard G/R/S.
            return _invoke_native_grs_transform_in_current_editor(getattr(self, 'mode', 'G'), 'INVOKE_REGION_WIN', self, context=context)

        if _grs_should_delegate_to_native_transform(context) or _grs_force_native_for_operator_props(self, getattr(self, 'mode', 'G')):
            pending_native, orient_native, pending_native_ctx = _pop_pending_grs_native_delegate_payload()
            try:
                if isinstance(pending_native_ctx, dict):
                    area_n = pending_native_ctx.get('area', None)
                    region_n = pending_native_ctx.get('region', None)
                    rv3d_n = pending_native_ctx.get('region_data', None)
                    override_n = _grs_view3d_override_kwargs(context, area_n, region_n, rv3d_n)
                    if override_n and hasattr(bpy.context, 'temp_override'):
                        with bpy.context.temp_override(**override_n):
                            return _invoke_native_grs_transform(getattr(self, 'mode', 'G'), 'INVOKE_REGION_WIN', self, pending=pending_native, orient=orient_native, context=bpy.context)
            except Exception:
                pass
            return _invoke_native_grs_transform(getattr(self, 'mode', 'G'), 'INVOKE_DEFAULT', self, pending=pending_native, orient=orient_native, context=context)

        pending_ctx = None
        try:
            pending_ctx = bpy.app.driver_namespace.pop('STS_PENDING_GRS_CTX', None)
        except Exception:
            pending_ctx = None
        if context.area is not None and context.area.type == 'VIEW_3D':
            rv3d_w = None
            try:
                area_w, region_w, _mx_w, _my_w, rv3d_w = cu._event_view3d_area_region_xy_rv3d(context, event)
            except Exception:
                try:
                    area_w, region_w = _grs_event_area_region(context, event)
                except Exception:
                    area_w, region_w = cu._get_view3d_area_region(context)
            self._area = area_w or context.area
            self._region = region_w or context.region
            try:
                self._rv3d = rv3d_w or cu._view3d_region_data(self._area, self._region) or context.region_data
            except Exception:
                self._rv3d = rv3d_w or context.region_data
            self._window = context.window
        else:
            if not isinstance(pending_ctx, dict):
                return {'CANCELLED'}
            self._area = pending_ctx.get('area', None)
            self._region = pending_ctx.get('region', None)
            self._window = pending_ctx.get('window', None) or getattr(context, 'window', None)
            if self._area is None or getattr(self._area, 'type', None) != 'VIEW_3D' or self._region is None or getattr(self._region, 'type', None) != 'WINDOW':
                return {'CANCELLED'}
            try:
                self._rv3d = pending_ctx.get('region_data', None) or cu._view3d_region_data(self._area, self._region) or context.region_data
            except Exception:
                self._rv3d = pending_ctx.get('region_data', None) or context.region_data
        self._reset_constraint()
        try:
            self.constraint_space = _scene_transform_orientation_type(context)
        except Exception:
            self.constraint_space = 'GLOBAL'
        self._pending_free_rotation = False
        self._pending_free_rotation_idx = -1
        try:
            self._initial_constraint_space = self._scene_transform_orientation_mode(context)
        except Exception:
            self._initial_constraint_space = 'GLOBAL'
        try:
            pending = bpy.app.driver_namespace.pop('STS_PENDING_GRS', None)
            if isinstance(pending, dict):
                pk = str(pending.get('kind', 'NONE') or 'NONE')
                pi = int(pending.get('idx', -1))
                ps = str(pending.get('space', 'GLOBAL') or 'GLOBAL')
                if pk in {'AXIS', 'PLANE'} and pi in (0, 1, 2):
                    self.constraint_kind = pk
                    self.constraint_idx = pi
                    self.constraint_space = ps
                elif pk == 'FREE':
                    self._pending_free_rotation = True
                    self._pending_free_rotation_idx = pi if pi in (0, 1, 2) else -1
                    self.constraint_kind = 'NONE'
                    self.constraint_idx = -1
                    self.constraint_space = ps
        except Exception:
            pass
        self._apply_invocation_operator_overrides(context)
        self.changed = False
        self.pivot_mode_current = context.scene.tool_settings.transform_pivot_point
        self.pivot_3d = self._calc_pivot_world(context)
        
        self.current_pivot_3d = self.pivot_3d.copy()

        # HUD / numeric / snap
        prefs = _prefs(context)
        try:
            dn = getattr(bpy.app, 'driver_namespace', None)
            if isinstance(dn, dict):
                self._from_smart_gizmo = bool(dn.pop('STS_GRS_FROM_SMART_GIZMO', False))
                self._smart_gizmo_hit_id = str(dn.pop('STS_GRS_GIZMO_HIT_ID', '') or '')
                self._force_screen_coordinate_rotation = bool(dn.pop('STS_GRS_FORCE_SCREEN_COORDINATE_ROTATION', False))
                self._force_circular_rotation = bool(dn.pop('STS_GRS_FORCE_CIRCULAR_ROTATION', False))
                self._force_positive_scale = bool(dn.pop('STS_GRS_FORCE_POSITIVE_SCALE', False))
                self._force_allow_negative_scale = bool(dn.pop('STS_GRS_FORCE_ALLOW_NEGATIVE_SCALE', False))
                self._force_free_rotation = bool(dn.pop('STS_GRS_FORCE_FREE_ROTATION', False)) or bool(getattr(self, '_pending_free_rotation', False))
                self._smart_gizmo_orient_axes = dn.pop('STS_GRS_GIZMO_ORIENT_AXES', None)
                if self._smart_gizmo_orient_axes is None:
                    self._smart_gizmo_orient_axes = dn.pop('STS_PENDING_GRS_ORIENT_AXES', None)
                self._smart_gizmo_orient_space = str(dn.pop('STS_GRS_GIZMO_ORIENT_SPACE', '') or dn.pop('STS_PENDING_GRS_ORIENT_SPACE', '') or '')
                self._smart_gizmo_dynamic_view_orientation = bool(dn.pop('STS_GRS_GIZMO_DYNAMIC_VIEW', False) or dn.pop('STS_PENDING_GRS_ORIENT_DYNAMIC_VIEW', False))
                self._smart_gizmo_orient_view_signature = dn.pop('STS_PENDING_GRS_ORIENT_VIEW_SIGNATURE', None)
                try:
                    if self._smart_gizmo_orient_space in {'VIEW', 'WORKPLANE'} and (self._smart_gizmo_dynamic_view_orientation or self.constraint_space in {'', 'GLOBAL', 'VIEW', 'WORKPLANE'}):
                        self.constraint_space = self._smart_gizmo_orient_space
                except Exception:
                    pass
                if self._smart_gizmo_orient_axes is not None and not self._smart_gizmo_orient_space:
                    try:
                        self._smart_gizmo_orient_space = self._scene_transform_orientation_mode(context)
                    except Exception:
                        self._smart_gizmo_orient_space = str(getattr(self, 'constraint_space', '') or 'GLOBAL')
                matrix_payload = dn.pop('STS_PENDING_GRS_ORIENT_MATRIX', None)
                dn.pop('STS_PENDING_GRS_PIVOT', None)
                if self._smart_gizmo_orient_axes is None and matrix_payload is not None:
                    try:
                        rows = []
                        for row in matrix_payload:
                            rows.append(tuple(float(v) for v in row[:3]))
                            if len(rows) >= 3:
                                break
                        if len(rows) == 3:
                            mat = mathutils.Matrix(rows).to_3x3()
                            self._smart_gizmo_orient_axes = (tuple(mat.col[0]), tuple(mat.col[1]), tuple(mat.col[2]))
                    except Exception:
                        pass
                try:
                    if self._smart_gizmo_orient_axes is not None and self._smart_gizmo_orient_space:
                        # Keep constraints in the same coordinate system basis even
                        # before the user presses X/Y/Z, so middle-mouse auto
                        # constraints also match the Smart Gizmo basis.
                        if not str(getattr(self, 'constraint_space', '') or '') or str(getattr(self, 'constraint_space', '') or 'GLOBAL') == 'GLOBAL':
                            self.constraint_space = str(self._smart_gizmo_orient_space)
                except Exception:
                    pass
            else:
                self._from_smart_gizmo = False
                self._smart_gizmo_hit_id = ''
                self._force_screen_coordinate_rotation = False
                self._force_circular_rotation = False
                self._force_positive_scale = False
                self._force_allow_negative_scale = False
                self._force_free_rotation = bool(getattr(self, '_pending_free_rotation', False))
                self._smart_gizmo_orient_axes = None
                self._smart_gizmo_orient_space = ''
                self._smart_gizmo_dynamic_view_orientation = False
                self._smart_gizmo_orient_view_signature = None
        except Exception:
            self._from_smart_gizmo = False
            self._smart_gizmo_hit_id = ''
            self._force_screen_coordinate_rotation = False
            self._force_circular_rotation = False
            self._force_positive_scale = False
            self._force_allow_negative_scale = False
            self._force_free_rotation = bool(getattr(self, '_pending_free_rotation', False))
            self._smart_gizmo_orient_axes = None
            self._smart_gizmo_orient_space = ''
        self._rotation_offset_rad = 0.0
        self._circular_rotation_screen_sign = 1.0
        self._circular_rotation_accum_rad = 0.0
        self._circular_rotation_prev_angle = None
        self._rotation_snap_anchor_active = False
        self._rotation_snap_anchor_raw = 0.0
        self._rotation_snap_anchor_value = 0.0
        self._rotation_snap_anchor_kind = ''
        self._free_rotation_snap_anchor_q = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
        self._last_free_rotation_q_applied = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
        self.numeric_input = ""
        self._hud_show_help = bool(getattr(prefs, 'hud_show_help_by_default', False)) if prefs else False
        self._snap_hold = None
        self._x_press_time = None
        self._x_hold_active = False
        self._pivot_edit = False
        self._snap_kd_cache = {}
        self._custom_snap_points = []
        self._snap_base_3d = None
        self._snap_base_offset_3d = None
        self._snap_base_active = False
        self._snap_base_force_target_snap = False
        self._snap_base_pick_active = False
        self._snap_base_candidate_3d = None
        self._snap_base_candidate_2d = None
        self._smart_gizmo_freeze_active = False
        self._smart_gizmo_freeze_prev_captured = False
        self._smart_gizmo_freeze_prev = (False, None, None)
        self._snap_base_gizmo_freeze_active = False
        self._smart_gizmo_scale_delta_mode = False
        self._smart_slide_active = False

        self._last_move = mathutils.Vector((0, 0, 0))
        self._last_rot = 0.0
        self._last_rot_axis = mathutils.Vector((0, 0, 1))
        self._last_rot_components_deg = mathutils.Vector((0, 0, 0))
        self._last_scale = 1.0
        self._last_scale_components = mathutils.Vector((1, 1, 1))
        
        self._middle_mouse_held = False
        self._middle_start_x = 0
        self._middle_start_y = 0

        region = self._region or context.region
        rv3d = self._rv3d or context.region_data
        if region is None or getattr(region, 'type', None) != 'WINDOW' or rv3d is None:
            region, rv3d = context.region, context.region_data

        p2d = self._smart_gizmo_project_location_visible_2d(context, self.pivot_3d)
        self.pivot_2d = p2d if p2d else mathutils.Vector((region.width * 0.5, region.height * 0.5))

        def _region_pair(value, fallback_x, fallback_y):
            try:
                if isinstance(value, (tuple, list)) and len(value) >= 2:
                    return int(value[0]), int(value[1]), True
            except Exception:
                pass
            try:
                return int(fallback_x), int(fallback_y), False
            except Exception:
                return 0, 0, False

        invoke_region_x, invoke_region_y, _has_pending_invoke_mouse = _region_pair(
            pending_invoke_mouse,
            getattr(event, 'mouse_region_x', 0),
            getattr(event, 'mouse_region_y', 0),
        )
        self.start_region_x, self.start_region_y, _has_pending_start_mouse = _region_pair(
            pending_start_mouse,
            invoke_region_x,
            invoke_region_y,
        )
        self._pending_drag_initial_apply = bool(
            (_has_pending_start_mouse or _has_pending_invoke_mouse)
            and (int(invoke_region_x) != int(self.start_region_x) or int(invoke_region_y) != int(self.start_region_y))
        )
        self._pending_drag_invoke_mouse = (int(invoke_region_x), int(invoke_region_y))

        self._last_shift = bool(self._event_shift_active(event))
        self._last_mods = (self._last_shift, bool(event.ctrl), bool(event.alt), bool(event.oskey))
        self._last_ctrl = bool(event.ctrl)

        if self.mode == 'R':
            try:
                _prefs_for_tick = _prefs(context)
                _g_tick = float(getattr(_prefs_for_tick, 'smart_gizmo_screen_scale', 1.0) if _prefs_for_tick else 1.0)
                self._rotation_tick_radius_px = max(24.0, min(320.0, 72.0 * max(0.1, _g_tick)))
            except Exception:
                self._rotation_tick_radius_px = 72.0
            self.start_angle = math.atan2(self.start_region_y - self.pivot_2d.y, self.start_region_x - self.pivot_2d.x)
            self._rotation_offset_rad = 0.0
            self._circular_rotation_accum_rad = 0.0
            self._circular_rotation_prev_angle = float(self.start_angle)
            self._rotation_snap_anchor_active = False
            self._rotation_snap_anchor_raw = 0.0
            self._rotation_snap_anchor_value = 0.0
            try:
                if (not self._use_screen_coordinate_rotation(prefs)) and not self._use_free_axis_rotation():
                    self._circular_rotation_screen_sign = self._smart_gizmo_circular_rotation_sign(context, self.start_region_x, self.start_region_y)
            except Exception:
                self._circular_rotation_screen_sign = 1.0
            self._free_rotation_offset_q = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            self._free_rotation_accum_q = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            self._free_rotation_snap_anchor_q = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            self._last_free_rotation_q_applied = mathutils.Quaternion((1.0, 0.0, 0.0, 0.0))
            self._free_rotation_start_vec = None
            self._free_rotation_prev_vec = None
            try:
                d0 = mathutils.Vector((float(self.start_region_x) - float(self.pivot_2d.x), float(self.start_region_y) - float(self.pivot_2d.y))).length
                self._free_rotation_radius_px = max(48.0, min(240.0, d0 / 0.82 if d0 > 8.0 else min(float(getattr(region, 'width', 0) or 0), float(getattr(region, 'height', 0) or 0)) * 0.22))
            except Exception:
                self._free_rotation_radius_px = 96.0
            if self._use_free_axis_rotation():
                self._reset_free_rotation_baseline(context, self.start_region_x, self.start_region_y, keep_current=False, sens=1.0)
            self._begin_smart_gizmo_modal_freeze(context)
        elif self.mode == 'S':
            self.start_vec2 = mathutils.Vector((self.start_region_x - self.pivot_2d.x, self.start_region_y - self.pivot_2d.y))
            self.start_dist = max(self.start_vec2.length, 0.001)
            self.start_dir2 = self.start_vec2.normalized() if self.start_vec2.length > 1e-8 else mathutils.Vector((1.0, 0.0))
            self._screen_coordinate_scale_base_px = 0.0
            if not self._use_gizmo_distance_scale(context, prefs):
                self._prepare_screen_coordinate_scale_baseline(context, self.start_region_x, self.start_region_y, self._get_sens(prefs, 'S', self._last_shift), preserve_current=False)
            else:
                self.start_scale_signed = float(self._scale_signed_distance(context, self.start_region_x, self.start_region_y))
                self.start_scale_base = max(abs(self.start_scale_signed), 0.001)
                self._normalize_smart_gizmo_constrained_scale_base(context)
                if str(getattr(self, 'constraint_kind', 'NONE') or 'NONE') in {'AXIS', 'PLANE'}:
                    self._reset_scale_baseline_from_current(context, self.start_region_x, self.start_region_y, self._get_sens(prefs, 'S', self._last_shift))

        self.last_cx = int(getattr(self, '_pending_drag_invoke_mouse', (getattr(event, 'mouse_region_x', 0), getattr(event, 'mouse_region_y', 0)))[0])
        self.last_cy = int(getattr(self, '_pending_drag_invoke_mouse', (getattr(event, 'mouse_region_x', 0), getattr(event, 'mouse_region_y', 0)))[1])

        self._store_initial_state(context)
        if bool(getattr(self, '_pending_drag_initial_apply', False)):
            try:
                if getattr(self, 'mode', '') == 'R' and self._use_free_axis_rotation():
                    self._free_rotation_update_accumulated(context, self.last_cx, self.last_cy, self._last_shift, prefs)
                self._apply_current_transform(context, self.last_cx, self.last_cy, self._last_shift)
            except Exception:
                pass
        self._in_modal = True
        self._add_draw_handlers()
        _grs_set_active_modal(self)
        if _grs_overlay_front_replay_active():
            _grs_rehook_active_post_pixel_handlers()
        try:
            context.area.tag_redraw()
        except Exception:
            pass
        _tag_all_view3d_redraw()
        self._status_text_update(context)

        self._pcl_running = False
        self._pcl_installed = False
        self._pcl_timer = None
        if _PCL_WINDOWS_AVAILABLE:
            try:
                if getattr(_pcl_state, 'clip_locked', False):
                    _pcl_clip_unlock()
                _pcl_state.pending_dx = 0.0
                _pcl_state.running = False
                if getattr(_pcl_state, 'wndproc_installed', False):
                    _pcl_remove_wndproc_tap()
            except Exception:
                pass
            try:
                self._pcl_timer = context.window_manager.event_timer_add(0.01, window=context.window)
            except Exception:
                self._pcl_timer = None

        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('SCROLL_XY')
        return {'RUNNING_MODAL'}


    def _autokey_tool_settings(self, context):
        try:
            scene = getattr(context, 'scene', None) or bpy.context.scene
            return getattr(scene, 'tool_settings', None)
        except Exception:
            return None

    def _autokey_enabled(self, context) -> bool:
        try:
            ts = self._autokey_tool_settings(context)
            return bool(ts and getattr(ts, 'use_keyframe_insert_auto', False))
        except Exception:
            return False

    def _autokey_keytype(self, context) -> str:
        try:
            ts = self._autokey_tool_settings(context)
            kt = str(getattr(ts, 'keyframe_type', 'KEYFRAME') or 'KEYFRAME') if ts else 'KEYFRAME'
            if kt in {'KEYFRAME', 'BREAKDOWN', 'MOVING_HOLD', 'EXTREME', 'JITTER', 'GENERATED'}:
                return kt
        except Exception:
            pass
        return 'KEYFRAME'

    def _autokey_active_keying_set(self, context):
        try:
            ts = self._autokey_tool_settings(context)
            if not ts or not getattr(ts, 'use_keyframe_insert_keyingset', False):
                return None
            scene = getattr(context, 'scene', None) or bpy.context.scene
            ks = getattr(getattr(scene, 'keying_sets_all', None), 'active', None)
            return ks
        except Exception:
            return None

    def _autokey_view3d_override(self, context) -> dict:
        override = {}
        try:
            window = getattr(self, '_window', None) or getattr(context, 'window', None)
            area = getattr(self, '_area', None) or getattr(context, 'area', None)
            region = getattr(self, '_region', None) or getattr(context, 'region', None)
            if window is not None:
                override['window'] = window
            if area is not None:
                override['area'] = area
            if region is not None:
                override['region'] = region
            try:
                screen = getattr(window, 'screen', None) if window is not None else getattr(context, 'screen', None)
                if screen is not None:
                    override['screen'] = screen
            except Exception:
                pass
        except Exception:
            override = {}
        return override

    def _autokey_call_keying_set_operator(self, context, keying_set_id: str) -> bool:
        """Invoke Blender's active/builtin Keying Set inserter with the modal View3D context.

        Standard Transform uses Blender's keying-set machinery when Auto Keying
        is set to use the active keying set.  Calling the operator keeps custom
        properties, visual keying-set flags, grouping, and user-defined keying
        set paths aligned with Blender's own insert-key behavior.
        """
        keying_set_id = str(keying_set_id or '__ACTIVE__')
        try:
            override = self._autokey_view3d_override(context)
            def _call():
                try:
                    return bpy.ops.anim.keyframe_insert_by_name(type=keying_set_id)
                except TypeError:
                    # Some builds expose the active-keying-set entry only through
                    # anim.keyframe_insert(type='__ACTIVE__').  Keep this as a
                    # compatibility fallback for 5.1.x minor differences.
                    try:
                        return bpy.ops.anim.keyframe_insert(type=keying_set_id)
                    except Exception:
                        raise
            if override and hasattr(bpy.context, 'temp_override'):
                with bpy.context.temp_override(**override):
                    result = _call()
            else:
                result = _call()
            return 'FINISHED' in set(result or set())
        except Exception:
            return False

    def _autokey_object_targets(self, context):
        targets = []
        seen = set()
        try:
            obj_mats = getattr(self, '_obj_mats', {}) or {}
            use_prop = bool(is_prop_enabled(context))
            try:
                prop_size = float(getattr(context.tool_settings, 'proportional_size', 0.0))
            except Exception:
                prop_size = 0.0
            if obj_mats:
                for obj, entry in list(obj_mats.items()):
                    if not obj or getattr(obj, 'name', '') not in bpy.data.objects:
                        continue
                    try:
                        dist = float(entry[1]) if isinstance(entry, (tuple, list)) and len(entry) > 1 else 0.0
                    except Exception:
                        dist = 0.0
                    affected = abs(dist) <= 1.0e-12 or (use_prop and dist < prop_size)
                    if not affected:
                        continue
                    ptr = obj.as_pointer()
                    if ptr not in seen:
                        seen.add(ptr)
                        targets.append(obj)
            else:
                for obj in list(getattr(context, 'selected_objects', []) or []):
                    if obj and getattr(obj, 'name', '') in bpy.data.objects:
                        ptr = obj.as_pointer()
                        if ptr not in seen:
                            seen.add(ptr)
                            targets.append(obj)
        except Exception:
            pass
        return targets

    def _autokey_pose_targets(self, context):
        targets = []
        seen = set()
        try:
            for obj, pmap in list((getattr(self, '_pose_bone_mats', {}) or {}).items()):
                if not obj or getattr(obj, 'name', '') not in bpy.data.objects or getattr(obj, 'type', None) != 'ARMATURE':
                    continue
                pose = getattr(obj, 'pose', None)
                if pose is None:
                    continue
                for name in list((pmap or {}).keys()):
                    try:
                        pbone = pose.bones.get(str(name))
                    except Exception:
                        pbone = None
                    if pbone is None:
                        continue
                    key = (obj.as_pointer(), pbone.name)
                    if key not in seen:
                        seen.add(key)
                        targets.append((obj, pbone))
        except Exception:
            pass
        return targets

    def _autokey_rotation_scale_should_key_location(self, context, obj, original_matrix=None) -> bool:
        try:
            mode = str(getattr(self, 'mode', '') or '').upper()
            if mode == 'G':
                return True
            if mode not in {'R', 'S'}:
                return False
            pivot_mode = str(getattr(self, 'pivot_mode_current', '') or getattr(context.scene.tool_settings, 'transform_pivot_point', '') or '')
            if pivot_mode == 'CURSOR':
                return True
            if pivot_mode == 'INDIVIDUAL_ORIGINS':
                return False
            if original_matrix is not None:
                try:
                    return (obj.matrix_world.translation - original_matrix.translation).length > 1.0e-9
                except Exception:
                    pass
        except Exception:
            pass
        return False

    def _autokey_object_use_flags(self, context, obj):
        mode = str(getattr(self, 'mode', '') or 'G').upper()
        if mode == 'G':
            return True, False, False
        original_matrix = None
        try:
            entry = (getattr(self, '_obj_mats', {}) or {}).get(obj)
            if isinstance(entry, (tuple, list)) and entry:
                original_matrix = entry[0]
        except Exception:
            original_matrix = None
        if mode == 'R':
            return self._autokey_rotation_scale_should_key_location(context, obj, original_matrix), True, False
        if mode == 'S':
            return self._autokey_rotation_scale_should_key_location(context, obj, original_matrix), False, True
        return True, True, True

    def _autokey_pose_use_flags(self, context, obj, pbone):
        mode = str(getattr(self, 'mode', '') or 'G').upper()
        if mode == 'G':
            return True, False, False
        loc_changed = False
        try:
            pmap = (getattr(self, '_pose_bone_mats', {}) or {}).get(obj, {}) or {}
            entry = pmap.get(str(getattr(pbone, 'name', '') or ''))
            if isinstance(entry, dict) and 'location' in entry:
                loc_changed = (pbone.location - entry['location']).length > 1.0e-9
        except Exception:
            loc_changed = False
        if mode == 'R':
            return bool(loc_changed), True, False
        if mode == 'S':
            return bool(loc_changed), False, True
        return True, True, True

    def _autokey_direct_target(self, context, target, *, use_loc: bool, use_rot: bool, use_scale: bool, force_all_keying_set_channels: bool = False) -> bool:
        try:
            from bpy_extras.anim_utils import AutoKeying
        except Exception:
            AutoKeying = None
        try:
            if force_all_keying_set_channels:
                use_loc = use_rot = use_scale = True
            if AutoKeying is not None:
                with AutoKeying.options(
                    keytype=self._autokey_keytype(context),
                    use_loc=bool(use_loc),
                    use_rot=bool(use_rot),
                    use_scale=bool(use_scale),
                    force_autokey=False,
                ):
                    AutoKeying.autokey_transformation(context, target)
                return True
        except Exception:
            pass

        # Minimal fallback for Blender builds where bpy_extras.anim_utils changes.
        try:
            options = set()
            prefs = getattr(getattr(context, 'preferences', None), 'edit', None)
            ts = self._autokey_tool_settings(context)
            if prefs is not None:
                if bool(getattr(prefs, 'use_visual_keying', False)):
                    options.add('INSERTKEY_VISUAL')
                if bool(getattr(prefs, 'use_keyframe_insert_needed', False)):
                    options.add('INSERTKEY_NEEDED')
                if bool(getattr(prefs, 'use_keyframe_insert_available', False)):
                    options.add('INSERTKEY_AVAILABLE')
            if ts is not None:
                if bool(getattr(ts, 'use_keyframe_cycle_aware', False)):
                    options.add('INSERTKEY_CYCLE_AWARE')
                if str(getattr(ts, 'auto_keying_mode', '') or '') == 'REPLACE_KEYS':
                    options.add('INSERTKEY_REPLACE')
            keytype = self._autokey_keytype(context)
            if use_loc:
                target.keyframe_insert('location', options=options, keytype=keytype)
            if use_rot:
                rot_mode = str(getattr(target, 'rotation_mode', '') or '')
                if rot_mode == 'QUATERNION':
                    target.keyframe_insert('rotation_quaternion', options=options, keytype=keytype)
                elif rot_mode == 'AXIS_ANGLE':
                    target.keyframe_insert('rotation_axis_angle', options=options, keytype=keytype)
                else:
                    target.keyframe_insert('rotation_euler', options=options, keytype=keytype)
            if use_scale:
                target.keyframe_insert('scale', options=options, keytype=keytype)
            return True
        except Exception:
            return False

    def _autokey_with_active_keying_set_for_objects(self, context, objects, keying_set_id: str) -> bool:
        objects = [o for o in (objects or []) if o and getattr(o, 'name', '') in bpy.data.objects]
        if not objects:
            return False
        try:
            view_layer = context.view_layer
        except Exception:
            view_layer = bpy.context.view_layer
        touched = set(objects)
        try:
            touched.update(list(getattr(context, 'selected_objects', []) or []))
        except Exception:
            pass
        original_selection = {}
        for obj in list(touched):
            try:
                original_selection[obj] = bool(obj.select_get())
            except Exception:
                pass
        try:
            original_active = getattr(view_layer.objects, 'active', None)
        except Exception:
            original_active = None
        ok_any = False
        try:
            for obj in objects:
                try:
                    for other in list(original_selection.keys()):
                        if other and getattr(other, 'name', '') in bpy.data.objects:
                            other.select_set(False)
                    obj.select_set(True)
                    view_layer.objects.active = obj
                    ok_any = self._autokey_call_keying_set_operator(context, keying_set_id) or ok_any
                except Exception:
                    continue
        finally:
            try:
                for obj, state in original_selection.items():
                    if obj and getattr(obj, 'name', '') in bpy.data.objects:
                        obj.select_set(bool(state))
            except Exception:
                pass
            try:
                if original_active and getattr(original_active, 'name', '') in bpy.data.objects:
                    view_layer.objects.active = original_active
            except Exception:
                pass
        return ok_any

    def _autokey_with_active_keying_set_for_pose(self, context, pose_targets, keying_set_id: str) -> bool:
        pose_targets = [(o, pb) for (o, pb) in (pose_targets or []) if o and pb and getattr(o, 'name', '') in bpy.data.objects]
        if not pose_targets:
            return False
        try:
            view_layer = context.view_layer
        except Exception:
            view_layer = bpy.context.view_layer
        touched_objs = {obj for obj, _pb in pose_targets}
        try:
            touched_objs.update(list(getattr(context, 'selected_objects', []) or []))
        except Exception:
            pass
        original_obj_selection = {}
        for obj in list(touched_objs):
            try:
                original_obj_selection[obj] = bool(obj.select_get())
            except Exception:
                pass
        try:
            original_active_obj = getattr(view_layer.objects, 'active', None)
        except Exception:
            original_active_obj = None
        original_bone_selection = {}
        original_active_bone = {}
        for obj in {o for o, _pb in pose_targets}:
            try:
                bones = getattr(getattr(obj, 'data', None), 'bones', None)
                if bones is None:
                    continue
                original_active_bone[obj] = getattr(bones, 'active', None)
                original_bone_selection[obj] = {pb.name: bool(getattr(pb, 'select', False)) for pb in getattr(getattr(obj, 'pose', None), 'bones', [])}
            except Exception:
                pass
        ok_any = False
        try:
            for obj, pbone in pose_targets:
                try:
                    bones = getattr(getattr(obj, 'data', None), 'bones', None)
                    if bones is None:
                        continue
                    for other in list(original_obj_selection.keys()):
                        if other and getattr(other, 'name', '') in bpy.data.objects:
                            other.select_set(False)
                    for pb_iter in getattr(getattr(obj, 'pose', None), 'bones', []):
                        try:
                            pb_iter.select = False
                        except Exception:
                            pass
                    obj.select_set(True)
                    view_layer.objects.active = obj
                    try:
                        pbone.select = True
                        bones.active = pbone.bone
                    except Exception:
                        pass
                    ok_any = self._autokey_call_keying_set_operator(context, keying_set_id) or ok_any
                except Exception:
                    continue
        finally:
            try:
                for obj, state in original_obj_selection.items():
                    if obj and getattr(obj, 'name', '') in bpy.data.objects:
                        obj.select_set(bool(state))
            except Exception:
                pass
            try:
                for obj, states in original_bone_selection.items():
                    if not obj or getattr(obj, 'name', '') not in bpy.data.objects:
                        continue
                    bones = getattr(getattr(obj, 'data', None), 'bones', None)
                    if bones is None:
                        continue
                    for pb_iter in getattr(getattr(obj, 'pose', None), 'bones', []):
                        try:
                            pb_iter.select = bool(states.get(pb_iter.name, False))
                        except Exception:
                            pass
                    try:
                        active_bone = original_active_bone.get(obj)
                        if active_bone is not None:
                            bones.active = active_bone
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                if original_active_obj and getattr(original_active_obj, 'name', '') in bpy.data.objects:
                    view_layer.objects.active = original_active_obj
            except Exception:
                pass
        return ok_any

    def _finish_autokey(self, context) -> None:
        """Mirror Blender's transform auto-keying after confirming Smart G-R-S.

        Smart G-R-S and Smart Gizmo preview transforms are applied by direct RNA
        writes, not by Blender's native transform modal operator.  Native G/R/S
        inserts keys only after confirmation; cancellation must not key.  This
        method is therefore called only from confirm paths and delegates to
        Blender's AutoKeying helper/operator paths so keying sets, replace mode,
        available-key mode, needed/visual/cycle-aware options, key types, locks,
        selected pose bones, and proportional object transforms follow Blender's
        standard behavior.
        """
        if not self._autokey_enabled(context):
            return
        try:
            objects = self._autokey_object_targets(context) if str(getattr(context, 'mode', '') or '') == 'OBJECT' else []
        except Exception:
            objects = []
        try:
            pose_targets = self._autokey_pose_targets(context) if str(getattr(context, 'mode', '') or '') == 'POSE' else []
        except Exception:
            pose_targets = []
        if not objects and not pose_targets:
            return

        active_ks = self._autokey_active_keying_set(context)
        if active_ks is not None:
            try:
                keying_set_id = str(getattr(active_ks, 'bl_idname', '') or '__ACTIVE__')
            except Exception:
                keying_set_id = '__ACTIVE__'
            ok = False
            if objects:
                ok = self._autokey_with_active_keying_set_for_objects(context, objects, keying_set_id) or ok
            if pose_targets:
                ok = self._autokey_with_active_keying_set_for_pose(context, pose_targets, keying_set_id) or ok
            if ok:
                return
            # Fall through to AutoKeying as a safe partial fallback.  This keeps
            # transform channels keyed even if a user-defined keying set operator
            # rejects the temporary context.
            force_all = True
        else:
            force_all = False

        for obj in objects:
            try:
                use_loc, use_rot, use_scale = self._autokey_object_use_flags(context, obj)
                self._autokey_direct_target(context, obj, use_loc=use_loc, use_rot=use_rot, use_scale=use_scale, force_all_keying_set_channels=force_all)
            except Exception:
                continue
        for obj, pbone in pose_targets:
            try:
                use_loc, use_rot, use_scale = self._autokey_pose_use_flags(context, obj, pbone)
                self._autokey_direct_target(context, pbone, use_loc=use_loc, use_rot=use_rot, use_scale=use_scale, force_all_keying_set_channels=force_all)
            except Exception:
                continue

    def _release_smart_gizmo_interaction_now(self):
        """Drop Smart Gizmo press/hover ownership on the release event itself.

        Confirmation may run auto-keying and other finish-side work before the
        old end-of-modal reset.  A rapid follow-up click must never see the
        just-released handle as still locked or hovered.
        """
        handled = False
        try:
            from . import csdt_gizmo as _csdt_gizmo
            release_fn = getattr(_csdt_gizmo, '_smart_gizmo_release_interaction_state_immediately', None)
            if callable(release_fn):
                release_fn()
                handled = True
        except Exception:
            handled = False
        if handled:
            return
        try:
            cg._CSDT_IS_DRAGGING = False
            cg._CSDT_DRAG_ACTIVE_ID = None
            cg._SMART_GIZMO_LOCKED_ID = None
            cg._SMART_GIZMO_HOVER_ID = None
            cg._SMART_GIZMO_MOUSE_VALID = False
            cg._SMART_GIZMO_LAST_HOVER_CHECK_AT = 0.0
            cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
        except Exception:
            pass
        try:
            cu._invalidate_gizmo_cache()
        except Exception:
            pass
        try:
            cu._tag_view3d_redraw()
        except Exception:
            pass

    def _finish_confirmed_modal(self, context):
        # Clear handle ownership before auto-key insertion or any other
        # potentially expensive confirmation work.
        try:
            self._release_smart_gizmo_interaction_now()
        except Exception:
            pass
        try:
            self._finish_autokey(context)
        except Exception:
            pass
        self._end_modal(context)

    def _remember_constraint_axis(self):
        try:
            prefs = _prefs()
            if prefs and not getattr(prefs, 'enable_axis_memory', True):
                return
        except Exception:
            pass

        mode_key = {'G': 'TRANSLATE', 'R': 'ROTATE', 'S': 'RESIZE'}.get(getattr(self, 'mode', 'G'), 'TRANSLATE')
        ckind = str(getattr(self, 'constraint_kind', 'NONE') or 'NONE').upper()
        try:
            cidx = int(getattr(self, 'constraint_idx', -1))
        except Exception:
            cidx = -1

        if ckind == 'AXIS' and cidx in (0, 1, 2):
            axis = [False, False, False]
            axis[cidx] = True
            cu._set_last_constraint_state_for_kind(mode_key, {'kind': 'AXIS', 'idx': cidx, 'axis': tuple(axis)})
            return

        if ckind == 'PLANE' and cidx in (0, 1, 2):
            axis = [True, True, True]
            axis[cidx] = False
            cu._set_last_constraint_state_for_kind(mode_key, {'kind': 'PLANE', 'idx': cidx, 'axis': tuple(axis)})
            return

        # Fallback for Smart Gizmo X/Y/Z and plane handles.  Some launch paths
        # route through pending driver-namespace state instead of an explicit
        # constraint_axis RNA property; if Blender or a modal transition clears
        # constraint_kind before finish, the handle id still records the user's
        # actual axis choice.  Free handles are handled below as before.
        hit_id = str(getattr(self, '_smart_gizmo_hit_id', '') or '')
        try:
            if hit_id and cu._remember_constraint_state_from_smart_gizmo_hit_id(hit_id):
                return
        except Exception:
            pass

        # A free Smart Gizmo handle is an explicit axis choice, not "nothing".
        # The legacy BoolVector memory cannot represent this because all-False
        # already means "no constraint_axis property".  Store an explicit FREE
        # state so the next Smart G-R-S start does not resurrect the previous
        # X/Y/Z or plane constraint.
        hit_id = str(getattr(self, '_smart_gizmo_hit_id', '') or '')
        is_free = False
        free_idx = -1
        if hit_id in {'MOVE_CENTER', 'SCALE_UNIFORM'}:
            is_free = True
        elif hit_id.startswith('ROT_FREE'):
            is_free = True
            free_idx = {'ROT_FREE_X': 0, 'ROT_FREE_Y': 1, 'ROT_FREE_Z': 2}.get(hit_id, -1)
        elif getattr(self, 'mode', '') == 'R' and (bool(getattr(self, '_force_free_rotation', False)) or bool(getattr(self, '_pending_free_rotation', False))):
            is_free = True
            try:
                free_idx = int(getattr(self, '_pending_free_rotation_idx', -1))
            except Exception:
                free_idx = -1

        # Plain unconstrained Smart G-R-S transforms should also clear a previous
        # remembered axis after the transform has actually changed something.
        # This makes the memory reflect the user's last transform intent: X/Y/Z,
        # plane, or free/unconstrained.
        if not is_free and ckind == 'NONE':
            try:
                is_free = bool(getattr(self, 'changed', False))
            except Exception:
                is_free = False

        if is_free:
            cu._set_last_constraint_state_for_kind(mode_key, {'kind': 'FREE', 'idx': free_idx if free_idx in (0, 1, 2) else -1, 'axis': (False, False, False)})
            return

    def _end_modal(self, context):
        # Cancellation and keyboard-confirm paths also terminate through here.
        # Keep the release idempotent so no stale hover/lock survives any exit.
        try:
            self._release_smart_gizmo_interaction_now()
        except Exception:
            pass
        try:
            self._remember_constraint_axis()
        except Exception:
            pass
        try:
            self._restore_invocation_tool_settings(context)
        except Exception:
            pass
        self._in_modal = False
        if _GRS_ACTIVE_MODAL is self:
            _grs_set_active_modal(None)
        self._clear_smart_gizmo_modal_freeze()
        self._cancel_snap_base_pick(context)
        self._remove_draw_handlers()
        context.window.cursor_modal_restore()

        try:
            if getattr(self, '_pcl_timer', None):
                context.window_manager.event_timer_remove(self._pcl_timer)
        except Exception:
            pass
        self._pcl_cleanup()
        self._status_text_clear(context)

        released_by_helper = False
        try:
            # Smart G-R-S can consume LEFTMOUSE RELEASE before the persistent
            # Smart Gizmo watcher receives it.  Release every pressed/hovered
            # handle flag synchronously in this modal finish path as well.
            from . import csdt_gizmo as _smart_gizmo_runtime
            release_fn = getattr(_smart_gizmo_runtime, '_smart_gizmo_release_interaction_state_immediately', None)
            if callable(release_fn):
                release_fn()
                released_by_helper = True
        except Exception:
            released_by_helper = False
        if not released_by_helper:
            try:
                cg._CSDT_IS_DRAGGING = False
                cg._CSDT_DRAG_ACTIVE_ID = None
                cg._SMART_GIZMO_LOCKED_ID = None
                cg._SMART_GIZMO_HOVER_ID = None
                cg._SMART_GIZMO_MOUSE_VALID = False
                cg._SMART_GIZMO_LAST_HOVER_CHECK_AT = 0.0
                cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
            except Exception:
                pass
        try:
            cu._invalidate_gizmo_cache()
        except Exception:
            pass
        try:
            if hasattr(cu, '_csdt_clear_editmesh_screen_hit_cache'):
                cu._csdt_clear_editmesh_screen_hit_cache()
        except Exception:
            pass
        # Re-snapshot from the final (or cancelled) data in the same step the
        # drag follow ends, so the gizmo never flashes back to the press point.
        self._smart_gizmo_follow_base = None
        self._smart_gizmo_live_follow_stop(context, rebuild=True)

        if context.area: context.area.tag_redraw()
        _tag_all_view3d_redraw()


    # =========================================================
    # Proportional Cursor Lock (Alt)
    # =========================================================
    def _pcl_cleanup(self):
        if not _PCL_WINDOWS_AVAILABLE:
            return
        try:
            if getattr(_pcl_state, "clip_locked", False):
                _pcl_clip_unlock()
            _pcl_state.pending_dx = 0.0
            _pcl_state.running = False
            if getattr(_pcl_state, "wndproc_installed", False):
                _pcl_remove_wndproc_tap()
        except Exception:
            pass
        self._pcl_running = False
        self._pcl_installed = False

    def _pcl_update(self, context):
        if not _PCL_WINDOWS_AVAILABLE:
            return False

        prefs = _prefs(context)

        if not prefs or not getattr(prefs, "enable_prop_cursor_lock", True):
            if getattr(self, "_pcl_running", False):
                try:
                    if getattr(_pcl_state, "clip_locked", False):
                        _pcl_clip_unlock()
                except Exception:
                    pass
                _pcl_state.pending_dx = 0.0
                _pcl_state.running = False
                self._pcl_running = False
            return False

        if not is_prop_enabled(context):
            if getattr(self, "_pcl_running", False):
                try:
                    if getattr(_pcl_state, "clip_locked", False):
                        _pcl_clip_unlock()
                except Exception:
                    pass
                _pcl_state.pending_dx = 0.0
                _pcl_state.running = False
                self._pcl_running = False
            return False

        if not getattr(self, "_prop_adjust_active", False):
            if getattr(self, "_pcl_running", False):
                try:
                    if getattr(_pcl_state, "clip_locked", False):
                        _pcl_clip_unlock()
                except Exception:
                    pass
                _pcl_state.pending_dx = 0.0
                _pcl_state.running = False
                self._pcl_running = False
            return False

        if not getattr(self, "_pcl_installed", False):
            try:
                _pcl_ensure_wndproc_tap()
                self._pcl_installed = True
            except Exception:
                return False

        if not getattr(self, "_pcl_running", False):
            self._pcl_running = True
            _pcl_state.running = True
            _pcl_state.pending_dx = 0.0
            _pcl_state.anchor_pos = _pcl_get_cursor_pos()
            try:
                _pcl_clip_lock_at(_pcl_state.anchor_pos)
            except Exception:
                self._pcl_running = False
                _pcl_state.running = False
                return False
            return True

        if not getattr(_pcl_state, "clip_locked", False):
            try:
                _pcl_clip_lock_at(_pcl_state.anchor_pos)
            except Exception:
                pass

        dx = float(getattr(_pcl_state, "pending_dx", 0.0))
        if dx == 0.0:
            return False

        _pcl_state.pending_dx = 0.0

        try:
            base_size = float(context.tool_settings.proportional_size)
            factor = 1.0 + (dx * 0.005)
            if factor < 0.1:
                factor = 0.1
            if factor > 10.0:
                factor = 10.0
            new_size = max(0.0001, base_size * factor)
            context.tool_settings.proportional_size = new_size

            self._apply_current_transform(context, self.last_cx, self.last_cy, self._last_shift)

            if context.area:
                context.area.tag_redraw()
            return True
        except Exception:
            return False


    def _kmcache_build_transform_modal(self, context):
        """Crash-safe no-op; do not inspect Transform Modal Map keymaps."""
        del context
        self._prop_km_adj = []
        self._prop_km_up = []
        self._prop_km_down = []
        return

    def _held_update(self, event):
        if not hasattr(self, "_held_inputs"):
            self._held_inputs = set()
        if event.value == 'PRESS':
            self._held_inputs.add(event.type)
        elif event.value == 'RELEASE':
            self._held_inputs.discard(event.type)

        self._last_mods = (bool(self._event_shift_active(event)), bool(event.ctrl), bool(event.alt), bool(event.oskey))

    def _is_key_held(self, event, key_name: str) -> bool:
        if not key_name or key_name == 'NONE':
            return True
        key_name = str(key_name)

        if key_name in {'SHIFT', 'LEFT_SHIFT', 'RIGHT_SHIFT'}:
            return bool(self._event_shift_active(event))
        if key_name in {'CTRL', 'CONTROL', 'LEFT_CTRL', 'RIGHT_CTRL'}:
            return bool(event.ctrl)
        if key_name in {'ALT', 'LEFT_ALT', 'RIGHT_ALT'}:
            return bool(event.alt)
        if key_name in {'OSKEY', 'LEFT_OSKEY', 'RIGHT_OSKEY'}:
            return bool(event.oskey)

        return key_name in getattr(self, "_held_inputs", set())

    def _kmitem_match_event(self, event, kmisnap: dict) -> bool:
        if kmisnap.get("type") != event.type:
            return False

        val = kmisnap.get("value", 'ANY')
        if val != 'ANY' and val != event.value:
            return False

        if not kmisnap.get("any", False):
            if kmisnap.get("shift", False) != bool(event.shift): return False
            if kmisnap.get("ctrl", False) != bool(event.ctrl): return False
            if kmisnap.get("alt", False) != bool(event.alt): return False
            if kmisnap.get("oskey", False) != bool(event.oskey): return False

        km_mod = kmisnap.get("key_modifier", 'NONE')
        if km_mod and km_mod != 'NONE':
            if not self._is_key_held(event, km_mod):
                return False

        return True

    def _kmitem_requirements_met(self, event, kmisnap: dict) -> bool:
        if not kmisnap.get("any", False):
            if kmisnap.get("shift", False) != bool(event.shift): return False
            if kmisnap.get("ctrl", False) != bool(event.ctrl): return False
            if kmisnap.get("alt", False) != bool(event.alt): return False
            if kmisnap.get("oskey", False) != bool(event.oskey): return False

        km_mod = kmisnap.get("key_modifier", 'NONE')
        if km_mod and km_mod != 'NONE':
            if not self._is_key_held(event, km_mod):
                return False
        return True

    def get_modal_keymap_action(self, event):
        if not hasattr(self, "_prop_km_up"):
            self._kmcache_build_transform_modal(bpy.context)

        for s in getattr(self, "_prop_km_up", []):
            if self._kmitem_match_event(event, s):
                return 'UP'
        for s in getattr(self, "_prop_km_down", []):
            if self._kmitem_match_event(event, s):
                return 'DOWN'

        if event.type in {'WHEELUPMOUSE', 'PAGE_UP'} and event.value == 'PRESS': return 'UP'
        if event.type in {'WHEELDOWNMOUSE', 'PAGE_DOWN'} and event.value == 'PRESS': return 'DOWN'
        return None

    def _normalize_prop_adjust_hold_type(self, key_type: str) -> str:
        key_type = str(key_type or '')
        mapping = {
            'EVT_TWEAK_L': 'LEFTMOUSE',
            'EVT_TWEAK_R': 'RIGHTMOUSE',
            'EVT_TWEAK_M': 'MIDDLEMOUSE',
            'TRACKPADPAN': 'MOUSEMOVE',
            'INBETWEEN_MOUSEMOVE': 'MOUSEMOVE',
        }
        return mapping.get(key_type, key_type)

    def _update_prop_adjust_state(self, context, event):
        if not hasattr(self, "_prop_km_adj"):
            self._kmcache_build_transform_modal(context)

        active = False
        if is_prop_enabled(context) and getattr(_prefs(context), "enable_prop_cursor_lock", True):
            for s in getattr(self, "_prop_km_adj", []):
                if str(s.get("type", "")).startswith("WHEEL"):
                    continue
                if not self._kmitem_requirements_met(event, s):
                    continue
                t = self._normalize_prop_adjust_hold_type(s.get("type", ""))
                if t and t not in {'MOUSEMOVE'}:
                    if not self._is_key_held(event, t):
                        continue
                active = True
                break

        self._prop_adjust_active = active

    def _get_sens(self, prefs, mode: str, shift: bool) -> float:
        if mode == 'G': return (prefs.g_shift if shift else prefs.g_normal) if prefs else (0.1 if shift else 1.0)
        if mode == 'R': return (prefs.r_shift if shift else prefs.r_normal) if prefs else (0.1 if shift else 1.0)
        raw = (prefs.s_shift if shift else prefs.s_normal) if prefs else (0.1 if shift else 1.0)
        return float(raw) * 0.1

    @staticmethod
    def _wrap_angle(a: float) -> float:
        while a > math.pi: a -= 2.0 * math.pi
        while a < -math.pi: a += 2.0 * math.pi
        return a

    def _circular_mouse_angle(self, cx, cy) -> float:
        try:
            return math.atan2(float(cy) - float(self.pivot_2d.y), float(cx) - float(self.pivot_2d.x))
        except Exception:
            return 0.0

    def _reset_circular_rotation_tracking(self, context=None, cx=None, cy=None, sens=1.0, preserve_current=True) -> None:
        """Reset circular-rotation tracking without losing the current value.

        Smart Gizmo ring rotation used to derive the angle from atan2(current -
        start) and wrap it to +/-180 degrees.  That made 360-degree drags flip
        back to zero.  Keep an unwrapped accumulator instead, and re-anchor it
        whenever modifier keys or axis constraints change so the visible rotation
        continues from the already-applied value.
        """
        try:
            if cx is None:
                cx = getattr(self, 'last_cx', getattr(self, 'start_region_x', 0))
            if cy is None:
                cy = getattr(self, 'last_cy', getattr(self, 'start_region_y', 0))
            cur_ang = self._circular_mouse_angle(cx, cy)
            try:
                sign = self._smart_gizmo_circular_rotation_sign(context, cx, cy) if context is not None else self._circular_rotation_sign(context)
                self._circular_rotation_screen_sign = 1.0 if float(sign) >= 0.0 else -1.0
            except Exception:
                sign = float(getattr(self, '_circular_rotation_screen_sign', 1.0) or 1.0)
                self._circular_rotation_screen_sign = 1.0 if sign >= 0.0 else -1.0
            sign = float(getattr(self, '_circular_rotation_screen_sign', 1.0) or 1.0)
            current_rot = float(getattr(self, '_last_rot', 0.0)) if preserve_current else 0.0
            denom = float(sens) * sign
            if abs(denom) < 1e-8:
                denom = sign if abs(sign) > 1e-8 else 1.0
            accum = current_rot / denom
            self._circular_rotation_accum_rad = float(accum)
            self._circular_rotation_prev_angle = float(cur_ang)
            self.start_angle = float(cur_ang) - float(accum)
        except Exception:
            try:
                self._circular_rotation_accum_rad = 0.0
                self._circular_rotation_prev_angle = 0.0
                self._circular_rotation_screen_sign = 1.0
            except Exception:
                pass

    def _continuous_circular_rotation_raw(self, context, cx, cy) -> float:
        """Return unwrapped circular rotation before sensitivity is applied."""
        try:
            cur_ang = self._circular_mouse_angle(cx, cy)
            prev = getattr(self, '_circular_rotation_prev_angle', None)
            if prev is None:
                prev = float(getattr(self, 'start_angle', cur_ang))
            accum = float(getattr(self, '_circular_rotation_accum_rad', 0.0))
            accum += self._wrap_angle(float(cur_ang) - float(prev))
            self._circular_rotation_accum_rad = float(accum)
            self._circular_rotation_prev_angle = float(cur_ang)
            return float(accum) * self._circular_rotation_sign(context)
        except Exception:
            try:
                cur_ang = self._circular_mouse_angle(cx, cy)
                return self._wrap_angle(float(cur_ang) - float(getattr(self, 'start_angle', cur_ang))) * self._circular_rotation_sign(context)
            except Exception:
                return 0.0

    def _reset_rotation_baseline_from_current(self, context, cx=None, cy=None, sens=1.0) -> None:
        """Re-anchor rotation math so the next update starts at _last_rot."""
        try:
            if cx is None:
                cx = getattr(self, 'last_cx', getattr(self, 'start_region_x', 0))
            if cy is None:
                cy = getattr(self, 'last_cy', getattr(self, 'start_region_y', 0))
            if self._use_free_axis_rotation():
                self._reset_free_rotation_baseline(context, cx, cy, keep_current=True, sens=sens)
                try:
                    q_last = getattr(self, '_last_free_rotation_q_applied', None)
                    if q_last is not None:
                        self._free_rotation_offset_q = q_last.copy()
                        self._free_rotation_accum_q = q_last.copy()
                        self._free_rotation_prev_vec = self._free_rotation_arcball_vec(context, cx, cy)
                        self._free_rotation_prev_x = float(cx)
                        self._free_rotation_prev_y = float(cy)
                except Exception:
                    pass
            elif self._use_screen_coordinate_rotation(_prefs(context)):
                self._reset_screen_rotation_baseline(cx, cy)
            else:
                self._reset_circular_rotation_tracking(context, cx, cy, sens, preserve_current=True)
        except Exception:
            pass

    def _begin_rotation_snap_anchor(self, context, rot_value=None) -> None:
        try:
            value = float(getattr(self, '_last_rot', 0.0) if rot_value is None else rot_value)
            self._rotation_snap_anchor_active = True
            self._rotation_snap_anchor_raw = value
            self._rotation_snap_anchor_value = value
            self._rotation_snap_anchor_kind = str(self._effective_snap_mode(context, self._active_mods_dict()) or '')
            try:
                if self._use_free_axis_rotation():
                    q_anchor = getattr(self, '_last_free_rotation_q_applied', None)
                    if q_anchor is None:
                        q_anchor = getattr(self, '_free_rotation_accum_q', None)
                    if q_anchor is None:
                        q_anchor = self._free_rotation_identity_quat()
                    self._free_rotation_snap_anchor_q = q_anchor.copy()
            except Exception:
                self._free_rotation_snap_anchor_q = self._free_rotation_identity_quat()
        except Exception:
            self._rotation_snap_anchor_active = False

    def _clear_rotation_snap_anchor(self) -> None:
        try:
            self._rotation_snap_anchor_active = False
            self._rotation_snap_anchor_raw = 0.0
            self._rotation_snap_anchor_value = 0.0
            self._rotation_snap_anchor_kind = ''
            self._free_rotation_snap_anchor_q = self._free_rotation_identity_quat()
        except Exception:
            pass


    def _is_alt_navigation_event(self, event) -> bool:
        if not bool(getattr(event, 'alt', False)):
            return False
        return str(getattr(event, 'type', '') or '') in {
            'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE',
            'EVT_TWEAK_L', 'EVT_TWEAK_R', 'EVT_TWEAK_M',
            'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE',
            'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSEPAN', 'MOUSEZOOM',
            'NDOF_MOTION', 'NDOF_BUTTON_FIT', 'NDOF_BUTTON_TOP', 'NDOF_BUTTON_BOTTOM',
            'NDOF_BUTTON_LEFT', 'NDOF_BUTTON_RIGHT', 'NDOF_BUTTON_FRONT', 'NDOF_BUTTON_BACK',
            'NDOF_BUTTON_ISO1', 'NDOF_BUTTON_ISO2', 'NDOF_BUTTON_ROLL_CW', 'NDOF_BUTTON_ROLL_CCW',
            'NDOF_BUTTON_SPIN_CW', 'NDOF_BUTTON_SPIN_CCW', 'NDOF_BUTTON_TILT_CW', 'NDOF_BUTTON_TILT_CCW',
        }

    def modal(self, context, event):
        if not _workspace_runtime_allowed(context):
            self._restore_initial_state(context)
            self._end_modal(context)
            return {'CANCELLED'}
        if event.type == 'TIMER':
            self._pcl_update(context)
            return {'RUNNING_MODAL'}

        _prev_mods_snap = getattr(self, '_last_mods', (False, False, False, False))
        _prev_shift_snap = bool(_prev_mods_snap[0])
        _prev_ctrl_snap = bool(_prev_mods_snap[1])
        self._held_update(event)
        self._update_prop_adjust_state(context, event)
        _cur_mods_snap = getattr(self, '_last_mods', (False, False, False, False))
        _cur_shift_snap = bool(_cur_mods_snap[0])
        _cur_ctrl_snap = bool(_cur_mods_snap[1])
        if bool(getattr(self, '_snap_base_pick_active', False)):
            if event.type == 'MOUSEMOVE':
                self._update_snap_base_candidate(context, event)
                if context.area:
                    context.area.tag_redraw()
                _tag_all_view3d_redraw()
                self._status_text_update(context)
                return {'RUNNING_MODAL'}
            if event.type == 'B':
                if event.value == 'RELEASE':
                    if self._commit_snap_base_pick(context, event):
                        # Apply once immediately on release so the chosen snap
                        # base becomes the live Smart Gizmo/source position even
                        # if the mouse does not move after B is released.
                        self._apply_current_transform(context, self.last_cx, self.last_cy, self._event_shift_active(event))
                        if str(getattr(self, 'mode', '') or '') in {'R', 'S'}:
                            self._sync_snap_base_gizmo_to_base(context)
                    if context.area:
                        context.area.tag_redraw()
                    _tag_all_view3d_redraw()
                    self._status_text_update(context)
                return {'RUNNING_MODAL'}
            if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
                if self._commit_snap_base_pick(context, event):
                    self._apply_current_transform(context, self.last_cx, self.last_cy, self._event_shift_active(event))
                    if str(getattr(self, 'mode', '') or '') in {'R', 'S'}:
                        self._sync_snap_base_gizmo_to_base(context)
                if context.area:
                    context.area.tag_redraw()
                _tag_all_view3d_redraw()
                self._status_text_update(context)
                return {'RUNNING_MODAL'}
            if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
                self._cancel_snap_base_pick(context)
                if context.area:
                    context.area.tag_redraw()
                _tag_all_view3d_redraw()
                self._status_text_update(context)
                return {'RUNNING_MODAL'}

        if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'CTRL', 'LEFT_SHIFT', 'RIGHT_SHIFT', 'SHIFT'} and event.value in {'PRESS', 'RELEASE'}:
            if (_prev_ctrl_snap != _cur_ctrl_snap) or (_prev_shift_snap != _cur_shift_snap):
                try:
                    if str(getattr(self, 'mode', '') or '') == 'R':
                        _prefs_mod = _prefs(context)
                        _sens_mod = self._get_sens(_prefs_mod, 'R', _cur_shift_snap)
                        _mods_after = {
                            'shift': bool(_cur_shift_snap),
                            'ctrl': bool(_cur_ctrl_snap),
                            'alt': bool(_cur_mods_snap[2]) if len(_cur_mods_snap) > 2 else False,
                        }
                        if _prev_ctrl_snap != _cur_ctrl_snap:
                            if _cur_ctrl_snap:
                                # Entering Ctrl must snap from the transform-start
                                # delta.  Do not re-anchor to the current raw angle.
                                self._clear_rotation_snap_anchor()
                            else:
                                # Leaving Ctrl should continue from the snapped
                                # value already applied on the last Ctrl frame.
                                self._reset_rotation_baseline_from_current(context, self.last_cx, self.last_cy, _sens_mod)
                                self._clear_rotation_snap_anchor()
                        elif _prev_shift_snap != _cur_shift_snap:
                            # Shift changes sensitivity/precision.  Re-anchor the
                            # input math so the visible value is continuous, while
                            # Ctrl snapping itself still quantizes from the modal
                            # start in _apply_snap_to_rotate().
                            self._reset_rotation_baseline_from_current(context, self.last_cx, self.last_cy, _sens_mod)
                            if self._effective_snap_mode(context, _mods_after) == 'GRID' and not self._is_ctrl_increment_snap(_mods_after):
                                self._begin_rotation_snap_anchor(context, getattr(self, '_last_rot', 0.0))
                            else:
                                self._clear_rotation_snap_anchor()
                except Exception:
                    pass
                self._apply_current_transform(context, self.last_cx, self.last_cy, _cur_shift_snap)
                if context.area:
                    context.area.tag_redraw()
                _tag_all_view3d_redraw()
                self._status_text_update(context)
                return {'RUNNING_MODAL'}

        if self._is_alt_navigation_event(event):
            return {'PASS_THROUGH'}

        if event.type == 'TAB' and bool(getattr(event, 'shift', False)) and event.value == 'PRESS':
            self._toggle_scene_snap(context)
            self._apply_current_transform(context, self.last_cx, self.last_cy, self._event_shift_active(event))
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'A' and event.value == 'PRESS':
            changed_snap_point = False
            if bool(getattr(event, 'alt', False)):
                changed_snap_point = self._remove_snap_point_from_mouse(context, event)
            else:
                changed_snap_point = self._add_snap_point_from_mouse(context, event)
            if changed_snap_point:
                self._apply_current_transform(context, self.last_cx, self.last_cy, self._event_shift_active(event))
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        if event.type == 'B' and event.value == 'PRESS':
            self._begin_snap_base_pick(context, event)
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        if event.type == 'G' and event.value == 'PRESS' and str(getattr(context, 'mode', '') or '') == 'EDIT_MESH':
            if self._toggle_edit_mesh_slide_mode(context, event):
                return {'RUNNING_MODAL'}

        if event.type in {'R', 'S'} and event.value == 'PRESS':
            self._switch_modal_transform_mode(context, event, event.type)
            return {'RUNNING_MODAL'}

        # HUD help
        if event.type == 'H' and event.value == 'PRESS':
            self._hud_show_help = not bool(getattr(self, '_hud_show_help', False))
            if context.area:
                context.area.tag_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        # Pivot / orient cycling
        if event.type == 'P' and event.value == 'PRESS':
            self._cycle_pivot_mode()
            self._restart_baseline_from_current(context)
            return {'RUNNING_MODAL'}

        if event.type == 'O' and event.value == 'PRESS':
            self._cycle_orient_space(context)
            self._restart_baseline_from_current(context)
            return {'RUNNING_MODAL'}

        # Pivot edit (Maya-style: hold D)
        if event.type == 'D':
            if event.value == 'PRESS':
                self._pivot_edit = True
                if context.area:
                    context.area.tag_redraw()
                self._status_text_update(context)
                return {'RUNNING_MODAL'}
            elif event.value == 'RELEASE':
                self._pivot_edit = False
                # Commit pivot change and restart mouse baseline
                self.pivot_3d = getattr(self, 'current_pivot_3d', self.pivot_3d).copy()
                self._restart_baseline_from_current(context)
                return {'RUNNING_MODAL'}

        # Temporary snap holds
        if event.type == 'V':
            if event.value == 'PRESS':
                self._snap_hold = 'VERT'
            elif event.value == 'RELEASE' and self._snap_hold == 'VERT':
                self._snap_hold = None
            if context.area:
                context.area.tag_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        if event.type == 'C':
            if event.value == 'PRESS':
                self._snap_hold = 'EDGE'
            elif event.value == 'RELEASE' and self._snap_hold == 'EDGE':
                self._snap_hold = None
            if context.area:
                context.area.tag_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        if event.type in {'X', 'Y', 'Z'} and event.value == 'PRESS':
            self._handle_axis_key(event, context)
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._apply_current_transform(context, self.last_cx, self.last_cy, self._last_shift)
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self._restore_initial_state(context)
            self._end_modal(context)
            return {'CANCELLED'}

        # Numeric input
        if self._numeric_event(event):
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}

        if event.type in {'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            if getattr(self, 'numeric_input', ''):
                if self._apply_numeric_and_finish(context):
                    self._finish_confirmed_modal(context)
                    return {'FINISHED'}
            self._finish_confirmed_modal(context)
            return {'FINISHED'}

        if event.type == 'LEFTMOUSE':
            if bool(getattr(self, '_release_confirm', False)):
                if event.value == 'RELEASE':
                    self._finish_confirmed_modal(context)
                    return {'FINISHED'}
            elif event.value == 'PRESS':
                self._finish_confirmed_modal(context)
                return {'FINISHED'}

        if event.type == 'SPACE' and event.value == 'PRESS':
            # Do not finish if typing numeric input
            if not getattr(self, 'numeric_input', ''):
                self._finish_confirmed_modal(context)
                return {'FINISHED'}

        prop_action = self.get_modal_keymap_action(event)
        if prop_action and is_prop_enabled(context):
            step = 1.1
            if prop_action == 'UP':
                context.tool_settings.proportional_size *= step
            elif prop_action == 'DOWN':
                context.tool_settings.proportional_size /= step

            self._apply_current_transform(context, self.last_cx, self.last_cy, self._last_shift)
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._status_text_update(context)
            return {'RUNNING_MODAL'}
            
        if event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type == 'MIDDLEMOUSE':
            if event.value == 'PRESS':
                self._middle_mouse_held = True
                self._middle_start_x = event.mouse_region_x
                self._middle_start_y = event.mouse_region_y
            elif event.value == 'RELEASE':
                self._middle_mouse_held = False
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            self.last_cx, self.last_cy = event.mouse_region_x, event.mouse_region_y

            # Pivot editing: raycast under cursor and move pivot only.
            if getattr(self, '_pivot_edit', False):
                snap = getattr(self, '_snap_hold', None)
                tgt = None
                if snap in {'VERT', 'EDGE'}:
                    tgt = self._snap_target_world(context, self.last_cx, self.last_cy, snap)
                else:
                    rc = self._raycast_world(context, self.last_cx, self.last_cy)
                    tgt = rc[0] if rc else None
                if tgt is not None:
                    self.current_pivot_3d = tgt.copy()
                    region, rv3d = context.region, context.region_data
                    p2d = self._smart_gizmo_project_location_visible_2d(context, self.current_pivot_3d)
                    if p2d:
                        self.pivot_2d = p2d
                if context.area:
                    context.area.tag_redraw()
                return {'RUNNING_MODAL'}

            if getattr(self, "_middle_mouse_held", False):
                dx = self.last_cx - self._middle_start_x
                dy = self.last_cy - self._middle_start_y
                mouse_vec = mathutils.Vector((dx, dy))
                if mouse_vec.length > 5.0:
                    want_plane = bool(self._event_shift_active(event))
                    kind, idx = self._middle_mouse_auto_constraint(context, mouse_vec, force_plane=want_plane)
                    if kind != 'NONE' and idx in (0, 1, 2):
                        self.constraint_kind = kind
                        self.constraint_idx = idx
                        try:
                            prefs_auto = _prefs(context)
                            if getattr(self, 'mode', '') == 'R':
                                if self._use_screen_coordinate_rotation(prefs_auto):
                                    self._reset_screen_rotation_baseline(self.last_cx, self.last_cy)
                                else:
                                    self._reset_circular_rotation_baseline(context, self.last_cx, self.last_cy, self._get_sens(prefs_auto, 'R', self._event_shift_active(event)))
                            elif getattr(self, 'mode', '') == 'S':
                                self._reset_scale_baseline_from_current(context, self.last_cx, self.last_cy, self._get_sens(prefs_auto, 'S', self._event_shift_active(event)))
                        except Exception:
                            pass
                        self._status_text_update(context)

            if getattr(self, 'mode', '') == 'R' and self._use_free_axis_rotation():
                self._free_rotation_update_accumulated(context, self.last_cx, self.last_cy, self._event_shift_active(event), _prefs(context))
            self._apply_current_transform(context, self.last_cx, self.last_cy, self._event_shift_active(event))
            if context.area:
                context.area.tag_redraw()
            _tag_all_view3d_redraw()
            self._status_text_update(context)

        return {'RUNNING_MODAL'}

    def _apply_current_transform(self, context, cx, cy, cur_shift):
        prefs = _prefs(context)
        force_positive_scale = bool(getattr(self, '_force_positive_scale', False))
        force_allow_negative_scale = bool(getattr(self, '_force_allow_negative_scale', False))
        disallow_neg = False if force_allow_negative_scale else (force_positive_scale or (prefs.disallow_negative_scale if prefs else True))
        allow_neg = not disallow_neg

        mods = {
            'shift': bool(cur_shift),
            'ctrl': bool(getattr(self, '_last_mods', (False, False, False, False))[1]),
            'alt': bool(getattr(self, '_last_mods', (False, False, False, False))[2]),
        }

        old_shift = bool(self._last_shift)
        cur_ctrl = bool(mods.get('ctrl'))
        old_ctrl = bool(getattr(self, '_last_ctrl', cur_ctrl))
        sens_old = self._get_sens(prefs, self.mode, old_shift)
        sens_new = self._get_sens(prefs, self.mode, cur_shift)
        if self.mode == 'G':
            # Smart G-R-S move now matches Smart Gizmo / Blender gizmo movement:
            # normal drag follows the cursor one-to-one, and only Shift applies
            # the precision multiplier.
            sens_old = self._get_sens(prefs, self.mode, True) if old_shift else 1.0
            sens_new = self._get_sens(prefs, self.mode, True) if cur_shift else 1.0

        if self.mode == 'S':
            if (not self._use_gizmo_distance_scale(context, prefs)) and not bool(getattr(self, '_smart_gizmo_scale_delta_mode', False)):
                self._prepare_screen_coordinate_scale_baseline(context, cx, cy, sens_new, preserve_current=True)

        EPS, MIN_SCALE = 1e-8, 0.0001

        if cur_shift != old_shift and abs(sens_new) > EPS and abs(sens_old) > EPS:
            ratio = sens_old / sens_new
            if self.mode == 'G':
                dx, dy = cx - self.start_region_x, cy - self.start_region_y
                self.start_region_x, self.start_region_y = cx - dx * ratio, cy - dy * ratio
            elif self.mode == 'R':
                self._reset_rotation_baseline_from_current(context, cx, cy, sens_new)
                if self._effective_snap_mode(context, mods) == 'GRID' and not self._is_ctrl_increment_snap(mods):
                    self._begin_rotation_snap_anchor(context, getattr(self, '_last_rot', 0.0))
                else:
                    self._clear_rotation_snap_anchor()
            elif self.mode == 'S':
                signed_dist = self._scale_signed_distance(context, cx, cy)
                base_dist = max(float(getattr(self, 'start_scale_base', self.start_dist) or self.start_dist), 0.001)
                factor_old = float(getattr(self, '_last_scale', 1.0))
                if allow_neg:
                    if abs(factor_old) < MIN_SCALE:
                        factor_old = MIN_SCALE if factor_old >= 0.0 else -MIN_SCALE
                else:
                    factor_old = max(MIN_SCALE, factor_old)
                if bool(getattr(self, '_smart_gizmo_scale_delta_mode', False)):
                    self.start_scale_signed = float(signed_dist) - ((factor_old - 1.0) / sens_new) * base_dist
                else:
                    raw_new = 1.0 + (factor_old - 1.0) / sens_new
                    if allow_neg:
                        if abs(raw_new) < EPS:
                            raw_new = EPS if raw_new >= 0.0 else -EPS
                    else:
                        raw_new = max(EPS, raw_new)
                    new_base_dist = signed_dist / raw_new if abs(raw_new) > EPS else base_dist
                    self.start_scale_base = max(abs(new_base_dist), 0.001)
                    self.start_dist = self.start_scale_base
            self._last_shift = cur_shift

        if self.mode == 'R' and (cur_ctrl != old_ctrl):
            try:
                if cur_ctrl:
                    # Entering Ctrl must quantize the total rotation delta from
                    # the modal start.  Re-anchoring here would make Ctrl snap
                    # start from the current unsnapped angle, which is the bug
                    # this block fixes.
                    self._clear_rotation_snap_anchor()
                else:
                    # When Ctrl is released, keep the already-snapped value as
                    # the continuous unsnapped baseline for subsequent movement.
                    self._reset_rotation_baseline_from_current(context, cx, cy, sens_new)
                    self._clear_rotation_snap_anchor()
            except Exception:
                pass

        self._last_shift = cur_shift
        self._last_ctrl = cur_ctrl
        sens = sens_new
        self._restore_initial_state(context)
        self._smart_gizmo_live_follow_capture(context)

        if self.mode == 'G':
            delta_region = (cx - self.start_region_x, cy - self.start_region_y)
            solved_move = self._smart_gizmo_move_from_mouse_absolute(context, cx, cy)
            if solved_move is None:
                solved_move = self._smart_gizmo_constrained_move_from_mouse(context, delta_region)
            move = solved_move * sens
            move = self._apply_snap_to_move(context, move, cx, cy, mods)
            if bool(getattr(self, '_snap_base_active', False)):
                # With B snap-base active the visible gizmo/source point should
                # be the selected snap base plus the applied transform delta.
                # This makes that exact location snap continuously while the
                # original transform pivot remains available for the actual data
                # transform.
                if not self._sync_snap_base_gizmo_pivot(context, move):
                    self.current_pivot_3d = self.pivot_3d + move
            else:
                self.current_pivot_3d = self.pivot_3d + move
            if bool(getattr(self, '_smart_slide_active', False)) and str(getattr(context, 'mode', '') or '') == 'EDIT_MESH':
                if self._apply_edit_mesh_smart_slide_move(context, move):
                    self.changed = True
            elif move.length != 0.0:
                M_move = mathutils.Matrix.Translation(move)
                if self._mesh_island_individual_mode(context):
                    self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: M_move)
                else:
                    self._apply_world_matrix(context, M_move)
                self.changed = True
            self._last_move = move.copy()

        elif self.mode == 'R':
            if bool(getattr(self, '_snap_base_active', False)):
                self._sync_snap_base_gizmo_to_base(context)
            else:
                self.current_pivot_3d = self.pivot_3d.copy()
            if self._use_free_axis_rotation():
                q_total = self._free_rotation_total_quat(context, cx, cy, sens)
                q_total = self._apply_snap_to_free_rotation_quat(context, q_total, mods)
                try:
                    self._last_free_rotation_q_applied = q_total.copy()
                except Exception:
                    pass
                try:
                    axis_tmp, rot_tmp = q_total.to_axis_angle()
                except Exception:
                    axis_tmp, rot_tmp = mathutils.Vector((0.0, 0.0, 1.0)), 0.0
                if abs(float(rot_tmp)) > 1e-12:
                    if self._mesh_island_individual_mode(context):
                        self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: self._make_rotation_matrix_from_quat(_center, q_total))
                    elif self._object_individual_origins_mode(context):
                        self._apply_object_individual_world_matrix(context, lambda _origin, _obj, _orig: self._make_rotation_matrix_from_quat(_origin, q_total))
                    else:
                        self._apply_world_matrix(context, self._make_rotation_matrix_from_quat(self.pivot_3d, q_total))
                    self.changed = True
                rot = float(rot_tmp)
                rot_axis = axis_tmp.normalized() if axis_tmp.length > 1e-8 else mathutils.Vector((0.0, 0.0, 1.0))
            else:
                if self._use_screen_coordinate_rotation(prefs):
                    raw_rot = self._rotation_screen_delta_rad(context, cx, cy)
                    rot = float(getattr(self, '_rotation_offset_rad', 0.0)) + (raw_rot * sens)
                else:
                    raw_rot = self._continuous_circular_rotation_raw(context, cx, cy)
                    rot = raw_rot * sens
                rot = self._apply_snap_to_rotate(context, rot, mods)
                rot_axis = self._rotation_axis(context)
                if rot != 0.0:
                    if self._mesh_island_individual_mode(context):
                        self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: self._make_rotation_matrix(_center, rot_axis, rot))
                    elif self._object_individual_origins_mode(context):
                        self._apply_object_individual_world_matrix(context, lambda _origin, _obj, _orig: self._make_rotation_matrix(_origin, rot_axis, rot))
                        self._preserve_object_euler_full_turns(context, rot_axis, rot)
                    else:
                        self._apply_world_matrix(context, self._make_rotation_matrix(self.pivot_3d, rot_axis, rot))
                        self._preserve_object_euler_full_turns(context, rot_axis, rot)
                    self.changed = True
            self._last_rot = float(rot)
            self._last_rot_axis = rot_axis.copy()
            self._last_rot_components_deg = mathutils.Vector((
                math.degrees(rot * rot_axis.x),
                math.degrees(rot * rot_axis.y),
                math.degrees(rot * rot_axis.z),
            ))

        elif self.mode == 'S':
            if bool(getattr(self, '_snap_base_active', False)):
                self._sync_snap_base_gizmo_to_base(context)
            else:
                self.current_pivot_3d = self.pivot_3d.copy()
            base_dist = max(float(getattr(self, 'start_scale_base', self.start_dist) or self.start_dist), 0.001)
            signed_dist = self._scale_signed_distance(context, cx, cy)
            if bool(getattr(self, '_smart_gizmo_scale_delta_mode', False)):
                start_signed = float(getattr(self, 'start_scale_signed', signed_dist))
                factor = 1.0 + ((signed_dist - start_signed) / base_dist) * sens
            else:
                factor = 1.0 + ((signed_dist / base_dist) - 1.0) * sens
            if allow_neg:
                if abs(factor) < MIN_SCALE:
                    factor = MIN_SCALE if factor >= 0.0 else -MIN_SCALE
            else:
                factor = max(MIN_SCALE, factor)

            factor = self._apply_snap_to_scale(context, factor, mods)
            self._last_scale = float(factor)
            
            sx, sy, sz = self._scale_factors_axes(factor)
            self._last_scale_components = mathutils.Vector((sx, sy, sz))
            if self._mesh_island_individual_mode(context):
                self._apply_mesh_island_world_matrix(context, lambda _center, _island, _obj: self._make_scale_matrix(context, _center, sx, sy, sz))
            elif self._object_individual_origins_mode(context):
                self._apply_object_individual_world_matrix(context, lambda _origin, _obj, _orig: self._make_scale_matrix(context, _origin, sx, sy, sz))
            else:
                self._apply_world_matrix(context, self._make_scale_matrix(context, self.pivot_3d, sx, sy, sz))
            self.changed = True

        self._smart_gizmo_live_follow_apply(context)




def _execute_island_transform_toggle(self, context):
    prefs = _prefs(context)
    if prefs is None or not hasattr(prefs, 'enable_mesh_island_transform'):
        try:
            self.report({'WARNING'}, TI('Smart Transform preferences are unavailable.', 'Smart Transform 設定を取得できません。'))
        except Exception:
            pass
        return {'CANCELLED'}
    try:
        prefs.enable_mesh_island_transform = not bool(getattr(prefs, 'enable_mesh_island_transform', False))
        try:
            _settings.save_always_on_now(context)
        except Exception:
            try:
                _settings.request_save('mesh_island_transform_toggle', context=context)
            except Exception:
                pass
        state = TI('ON', 'ON') if bool(getattr(prefs, 'enable_mesh_island_transform', False)) else TI('OFF', 'OFF')
        try:
            self.report({'INFO'}, f"{TI('アイランド変形', 'アイランド変形')}: {state}")
        except Exception:
            pass
    except Exception:
        return {'CANCELLED'}
    return {'FINISHED'}


class MESH_OT_smart_island_transform_toggle(bpy.types.Operator):
    bl_idname = "mesh.smart_island_transform_toggle"
    bl_label = TI('Island Transform Toggle', 'アイランド変形切り替え')
    bl_description = TI(
        'Toggle Island Transform. When enabled, Smart G-R-S G/R/S and Smart Gizmo transforms treat connected selected mesh components as islands; rotate/scale use the active pivot setting and use each island center by default.',
        'アイランド変形を切り替えます。有効時は Smart G-R-S の G/R/S とスマートギズモ変形で、繋がった選択メッシュ成分をアイランド単位として扱います。回転/スケールは現在のピボット設定に従い、既定では各アイランド中心を基点にします。',
    )
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        return context is not None

    def execute(self, context):
        return _execute_island_transform_toggle(self, context)


class MESH_OT_sts_island_transform_toggle(bpy.types.Operator):
    bl_idname = "mesh.sts_island_transform_toggle"
    bl_label = TI('Island Transform Toggle', 'アイランド変形切り替え')
    bl_description = TI(
        'Toggle Island Transform. This compatibility ID is the recommended keymap registration target and is kept stable for external JSON settings.',
        'アイランド変形を切り替えます。この互換IDは推奨キーマップ登録先として維持され、外部JSON設定でも安定して使用できます。',
    )
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        return context is not None

    def execute(self, context):
        return _execute_island_transform_toggle(self, context)


def _invoke_island_or_native_transform(context, mode: str, op_context='INVOKE_DEFAULT'):
    if not _workspace_runtime_allowed(context):
        return {'CANCELLED', 'PASS_THROUGH'} if str(op_context).startswith('INVOKE') else {'CANCELLED'}
    mode = str(mode or 'G').upper()
    try:
        if not _mesh_island_transform_enabled(context):
            if mode == 'R':
                return _invoke_native_grs_transform('R', op_context, context=context)
            if mode == 'S':
                return _invoke_native_grs_transform('S', op_context, context=context)
            return _invoke_native_grs_transform('G', op_context, context=context)
    except Exception:
        pass
    try:
        return bpy.ops.transform.smart_grs_transform(op_context, mode=mode)
    except TypeError:
        return bpy.ops.transform.smart_grs_transform('INVOKE_DEFAULT', mode=mode)


class MESH_OT_smart_island_move(bpy.types.Operator):
    bl_idname = "mesh.smart_island_move"
    bl_label = TI('Smart Island Move', 'スマートアイランド移動')
    bl_description = TI('Start Smart G-R-S Move with Island Transform support.', 'アイランド変形対応の Smart G-R-S 移動を開始します。')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        return _grs_context_poll(context)

    def invoke(self, context, event):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED', 'PASS_THROUGH'}
        if not _mesh_island_transform_enabled(context):
            try:
                return _invoke_native_grs_transform('G', 'INVOKE_DEFAULT', context=context)
            except Exception:
                return {'CANCELLED'}
        return _invoke_island_or_native_transform(context, 'G', 'INVOKE_DEFAULT')

    def execute(self, context):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED'}
        if not _mesh_island_transform_enabled(context):
            try:
                return _invoke_native_grs_transform('G', 'INVOKE_DEFAULT', context=context)
            except Exception:
                return {'CANCELLED'}
        return _invoke_island_or_native_transform(context, 'G', 'INVOKE_DEFAULT')


class MESH_OT_smart_island_rotate(bpy.types.Operator):
    bl_idname = "mesh.smart_island_rotate"
    bl_label = TI('Smart Island Rotate', 'スマートアイランド回転')
    bl_description = TI('Start Smart G-R-S Rotate with Island Transform support.', 'アイランド変形対応の Smart G-R-S 回転を開始します。')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        return _grs_context_poll(context)

    def invoke(self, context, event):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED', 'PASS_THROUGH'}
        if not _mesh_island_transform_enabled(context):
            try:
                return _invoke_native_grs_transform('R', 'INVOKE_DEFAULT', context=context)
            except Exception:
                return {'CANCELLED'}
        return _invoke_island_or_native_transform(context, 'R', 'INVOKE_DEFAULT')

    def execute(self, context):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED'}
        if not _mesh_island_transform_enabled(context):
            try:
                return _invoke_native_grs_transform('R', 'INVOKE_DEFAULT', context=context)
            except Exception:
                return {'CANCELLED'}
        return _invoke_island_or_native_transform(context, 'R', 'INVOKE_DEFAULT')


class MESH_OT_smart_island_scale(bpy.types.Operator):
    bl_idname = "mesh.smart_island_scale"
    bl_label = TI('Smart Island Scale', 'スマートアイランドスケール')
    bl_description = TI('Start Smart G-R-S Scale with Island Transform support.', 'アイランド変形対応の Smart G-R-S スケールを開始します。')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    @classmethod
    def poll(cls, context):
        return _grs_context_poll(context)

    def invoke(self, context, event):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED', 'PASS_THROUGH'}
        if not _mesh_island_transform_enabled(context):
            try:
                return _invoke_native_grs_transform('S', 'INVOKE_DEFAULT', context=context)
            except Exception:
                return {'CANCELLED'}
        return _invoke_island_or_native_transform(context, 'S', 'INVOKE_DEFAULT')

    def execute(self, context):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED'}
        if not _mesh_island_transform_enabled(context):
            try:
                return _invoke_native_grs_transform('S', 'INVOKE_DEFAULT', context=context)
            except Exception:
                return {'CANCELLED'}
        return _invoke_island_or_native_transform(context, 'S', 'INVOKE_DEFAULT')


class _GRS_WrapperBase(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    grs_mode = 'G'

    mode: bpy.props.StringProperty(
        name=TI('Compatibility Transform Mode', '互換変形モード'),
        description=TI('Optional override for older keymaps or buttons. Leave empty to use the wrapper button default mode.', '古いキーマップやボタン用の任意上書き値です。空の場合はラッパーボタンの既定モードを使用します。'),
        default='',
        options={'HIDDEN'},
    )

    @classmethod
    def poll(cls, context):
        try:
            return bool(TRANSFORM_OT_smart_grs_transform.poll(context))
        except Exception:
            return _grs_context_poll(context)

    def _invoke_smart_grs(self, context, mode: str, event=None):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED', 'PASS_THROUGH'}
        if getattr(getattr(context, 'area', None), 'type', '') == 'IMAGE_EDITOR':
            # Keep UV Editor behavior native and complete: proportional editing,
            # falloff, size, connected/projected options, snapping, UV pivot, and
            # editor-specific modal behavior all stay Blender-standard.
            return _invoke_native_grs_transform_in_current_editor(mode, 'INVOKE_REGION_WIN', self, context=context)

        area = None
        region = None
        rv3d = None
        try:
            if event is not None:
                area, region, _mx, _my, rv3d = cu._event_view3d_area_region_xy_rv3d(context, event)
        except Exception:
            area = region = rv3d = None
        if area is None or region is None:
            try:
                area, region = _grs_event_area_region(context, event)
            except Exception:
                area, region = None, None

        override = {}
        window = getattr(context, 'window', None)
        if window is not None:
            override['window'] = window
        if area is not None:
            override['area'] = area
            try:
                override['space_data'] = area.spaces.active
            except Exception:
                pass
        if region is not None:
            override['region'] = region
        try:
            rv3d = rv3d or cu._view3d_region_data(area, region)
            if rv3d is not None:
                override['region_data'] = rv3d
        except Exception:
            pass

        try:
            bpy.app.driver_namespace['STS_PENDING_GRS_CTX'] = {
                'window': window,
                'area': area,
                'region': region,
                'region_data': rv3d or cu._view3d_region_data(area, region),
            }
        except Exception:
            pass

        if _grs_should_delegate_to_native_transform(context) or _grs_force_native_for_operator_props(self, mode):
            if override and hasattr(bpy.context, 'temp_override'):
                try:
                    with bpy.context.temp_override(**override):
                        return _invoke_native_grs_transform(mode, 'INVOKE_REGION_WIN', self, context=bpy.context)
                except Exception:
                    pass
            return _invoke_native_grs_transform(mode, 'INVOKE_DEFAULT', self, context=context)

        op_kwargs = {'mode': mode}
        try:
            op_kwargs.update(_collect_smart_grs_modal_kwargs(self, mode))
        except Exception:
            pass

        if override:
            try:
                with bpy.context.temp_override(**override):
                    return bpy.ops.transform.smart_grs_transform('INVOKE_REGION_WIN', **op_kwargs)
            except Exception:
                pass
        return bpy.ops.transform.smart_grs_transform('INVOKE_DEFAULT', **op_kwargs)

    def invoke(self, context, event):
        mode = str(getattr(self, 'mode', '') or self.grs_mode or 'G').upper()
        if mode not in {'G', 'R', 'S'}:
            mode = str(self.grs_mode or 'G').upper()
        return self._invoke_smart_grs(context, mode, event)

    def execute(self, context):
        if not _workspace_runtime_allowed(context):
            return {'CANCELLED'}
        mode = str(getattr(self, 'mode', '') or self.grs_mode or 'G').upper()
        if mode not in {'G', 'R', 'S'}:
            mode = str(self.grs_mode or 'G').upper()
        return _invoke_native_grs_transform(mode, 'EXEC_DEFAULT', self, context=context)


class TRANSFORM_OT_smart_grs_move(_GRS_WrapperBase):
    bl_idname = _GRS_MOVE_OPERATOR_ID
    bl_label = TI('Smart G-R-S Move', 'Smart G-R-S 移動')
    bl_description = TI('Start Smart G-R-S in Move mode', 'Smart G-R-S を移動モードで開始します。')
    grs_mode = 'G'


class TRANSFORM_OT_smart_grs_rotate(_GRS_WrapperBase):
    bl_idname = _GRS_ROTATE_OPERATOR_ID
    bl_label = TI('Smart G-R-S Rotate', 'Smart G-R-S 回転')
    bl_description = TI('Start Smart G-R-S in Rotate mode', 'Smart G-R-S を回転モードで開始します。')
    grs_mode = 'R'


class TRANSFORM_OT_smart_grs_scale(_GRS_WrapperBase):
    bl_idname = _GRS_SCALE_OPERATOR_ID
    bl_label = TI('Smart G-R-S Scale', 'Smart G-R-S 拡大縮小')
    bl_description = TI('Start Smart G-R-S in Scale mode', 'Smart G-R-S を拡大縮小モードで開始します。')
    grs_mode = 'S'


class TRANSFORM_OT_smart_grs_translate(_GRS_WrapperBase):
    bl_idname = 'transform.smart_grs_translate'
    bl_label = TI('Smart G-R-S Translate', 'Smart G-R-S 移動')
    bl_description = TI('Manual keymap target compatible with Blender standard Translate.', 'Blender標準の移動に対応する手動キーマップ登録用ターゲットです。')
    grs_mode = 'G'


class TRANSFORM_OT_smart_grs_resize(_GRS_WrapperBase):
    bl_idname = 'transform.smart_grs_resize'
    bl_label = TI('Smart G-R-S Resize', 'Smart G-R-S 拡大縮小')
    bl_description = TI('Manual keymap target compatible with Blender standard Resize.', 'Blender標準の拡大縮小に対応する手動キーマップ登録用ターゲットです。')
    grs_mode = 'S'


_GRS_ORIENT_ITEMS = [
    ('GLOBAL', 'Global', ''),
    ('LOCAL', 'Local', ''),
    ('NORMAL', 'Normal', ''),
    ('GIMBAL', 'Gimbal', ''),
    ('VIEW', 'View', ''),
    ('CURSOR', 'Cursor', ''),
    ('PARENT', 'Parent', ''),
]
_GRS_AXIS_ITEMS = [('X', 'X', ''), ('Y', 'Y', ''), ('Z', 'Z', '')]
_GRS_FALLOFF_ITEMS = [
    ('SMOOTH', 'Smooth', ''),
    ('SPHERE', 'Sphere', ''),
    ('ROOT', 'Root', ''),
    ('INVERSE_SQUARE', 'Inverse Square', ''),
    ('SHARP', 'Sharp', ''),
    ('LINEAR', 'Linear', ''),
    ('CONSTANT', 'Constant', ''),
    ('RANDOM', 'Random', ''),
]
_GRS_SNAP_ELEMENT_ITEMS = [
    ('INCREMENT', 'Increment', ''),
    ('GRID', 'Grid', ''),
    ('VERTEX', 'Vertex', ''),
    ('EDGE', 'Edge', ''),
    ('FACE', 'Face', ''),
    ('VOLUME', 'Volume', ''),
    ('EDGE_MIDPOINT', 'Edge Midpoint', ''),
    ('EDGE_PERPENDICULAR', 'Edge Perpendicular', ''),
    ('FACE_MIDPOINT', 'Face Midpoint', ''),
    ('FACE_PROJECT', 'Face Project', ''),
    ('FACE_NEAREST', 'Face Nearest', ''),
]
_GRS_SNAP_TARGET_ITEMS = [
    ('CLOSEST', 'Closest', ''),
    ('CENTER', 'Center', ''),
    ('MEDIAN', 'Median', ''),
    ('ACTIVE', 'Active', ''),
]


def _grs_add_annotation(cls, name: str, prop):
    try:
        ann = getattr(cls, '__annotations__', None)
        if ann is None:
            ann = {}
            setattr(cls, '__annotations__', ann)
        if name not in ann:
            ann[name] = prop
    except Exception:
        pass


def _install_grs_native_transform_compat_props(cls, mode: str):
    """Expose standard transform-compatible properties for manual keymaps.

    These properties are not used to install keymaps. They only let a user replace
    an existing Blender Transform keymap entry with a Smart G-R-S operator while
    preserving the ordinary operator-property payload where Blender provides one.
    """
    mode = str(mode or 'G').upper()
    if mode == 'G':
        _grs_add_annotation(cls, 'value', bpy.props.FloatVectorProperty(name='Value', subtype='TRANSLATION', size=3, default=(0.0, 0.0, 0.0)))
    elif mode == 'R':
        _grs_add_annotation(cls, 'value', bpy.props.FloatProperty(name='Value', subtype='ANGLE', default=0.0))
        _grs_add_annotation(cls, 'orient_axis', bpy.props.EnumProperty(name='Orient Axis', items=_GRS_AXIS_ITEMS, default='Z'))
    elif mode == 'S':
        _grs_add_annotation(cls, 'value', bpy.props.FloatVectorProperty(name='Value', subtype='XYZ', size=3, default=(1.0, 1.0, 1.0)))
        _grs_add_annotation(cls, 'mouse_dir_constraint', bpy.props.FloatVectorProperty(name='Mouse Direction Constraint', subtype='XYZ', size=3, default=(0.0, 0.0, 0.0)))

    _grs_add_annotation(cls, 'orient_type', bpy.props.EnumProperty(name='Orientation', items=_GRS_ORIENT_ITEMS, default='GLOBAL'))
    _grs_add_annotation(cls, 'orient_matrix', bpy.props.FloatVectorProperty(name='Orientation Matrix', subtype='MATRIX', size=9, default=(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)))
    _grs_add_annotation(cls, 'orient_matrix_type', bpy.props.EnumProperty(name='Orientation Matrix Type', items=_GRS_ORIENT_ITEMS, default='GLOBAL'))
    _grs_add_annotation(cls, 'constraint_axis', bpy.props.BoolVectorProperty(name='Constraint Axis', subtype='XYZ', size=3, default=(False, False, False)))
    _grs_add_annotation(cls, 'mirror', bpy.props.BoolProperty(name='Mirror Editing', default=False))
    _grs_add_annotation(cls, 'use_proportional_edit', bpy.props.BoolProperty(name='Proportional Editing', default=False))
    _grs_add_annotation(cls, 'proportional_edit_falloff', bpy.props.EnumProperty(name='Proportional Falloff', items=_GRS_FALLOFF_ITEMS, default='SMOOTH'))
    _grs_add_annotation(cls, 'proportional_size', bpy.props.FloatProperty(name='Proportional Size', default=1.0, min=0.000001))
    _grs_add_annotation(cls, 'use_proportional_connected', bpy.props.BoolProperty(name='Connected Proportional', default=False))
    _grs_add_annotation(cls, 'use_proportional_projected', bpy.props.BoolProperty(name='Projected Proportional', default=False))
    _grs_add_annotation(cls, 'snap', bpy.props.BoolProperty(name='Snap', default=False))
    _grs_add_annotation(cls, 'snap_elements', bpy.props.EnumProperty(name='Snap Elements', items=_GRS_SNAP_ELEMENT_ITEMS, options={'ENUM_FLAG'}, default=set()))
    _grs_add_annotation(cls, 'use_snap_project', bpy.props.BoolProperty(name='Project Snap', default=False))
    _grs_add_annotation(cls, 'snap_target', bpy.props.EnumProperty(name='Snap Target', items=_GRS_SNAP_TARGET_ITEMS, default='CLOSEST'))
    _grs_add_annotation(cls, 'use_snap_self', bpy.props.BoolProperty(name='Snap Self', default=True))
    _grs_add_annotation(cls, 'use_snap_edit', bpy.props.BoolProperty(name='Snap Edit', default=True))
    _grs_add_annotation(cls, 'use_snap_nonedit', bpy.props.BoolProperty(name='Snap Non-Edit', default=True))
    _grs_add_annotation(cls, 'use_snap_selectable', bpy.props.BoolProperty(name='Snap Selectable', default=False))
    _grs_add_annotation(cls, 'snap_point', bpy.props.FloatVectorProperty(name='Snap Point', subtype='XYZ', size=3, default=(0.0, 0.0, 0.0)))
    _grs_add_annotation(cls, 'gpencil_strokes', bpy.props.BoolProperty(name='Grease Pencil Strokes', default=False))
    _grs_add_annotation(cls, 'release_confirm', bpy.props.BoolProperty(name='Release Confirm', default=False))
    _grs_add_annotation(cls, 'use_accurate', bpy.props.BoolProperty(name='Use Accurate', default=False))
    if mode == 'G':
        _grs_add_annotation(cls, 'snap_align', bpy.props.BoolProperty(name='Snap Align', default=False))
        _grs_add_annotation(cls, 'snap_normal', bpy.props.FloatVectorProperty(name='Snap Normal', subtype='XYZ', size=3, default=(0.0, 0.0, 0.0)))
        _grs_add_annotation(cls, 'cursor_transform', bpy.props.BoolProperty(name='Cursor Transform', default=False))
        _grs_add_annotation(cls, 'texture_space', bpy.props.BoolProperty(name='Texture Space', default=False))
        _grs_add_annotation(cls, 'remove_on_cancel', bpy.props.BoolProperty(name='Remove on Cancel', default=False))
        _grs_add_annotation(cls, 'use_duplicated_keyframes', bpy.props.BoolProperty(name='Use Duplicated Keyframes', default=False))
        _grs_add_annotation(cls, 'view2d_edge_pan', bpy.props.BoolProperty(name='View2D Edge Pan', default=False))
        _grs_add_annotation(cls, 'use_automerge_and_split', bpy.props.BoolProperty(name='Automerge and Split', default=False))
        _grs_add_annotation(cls, 'translate_origin', bpy.props.BoolProperty(name='Translate Origin', default=False))
    if mode in {'R', 'S'}:
        _grs_add_annotation(cls, 'center_override', bpy.props.FloatVectorProperty(name='Center Override', subtype='XYZ', size=3, default=(0.0, 0.0, 0.0)))
    if mode == 'S':
        _grs_add_annotation(cls, 'texture_space', bpy.props.BoolProperty(name='Texture Space', default=False))
        _grs_add_annotation(cls, 'remove_on_cancel', bpy.props.BoolProperty(name='Remove on Cancel', default=False))
        _grs_add_annotation(cls, 'use_duplicated_keyframes', bpy.props.BoolProperty(name='Use Duplicated Keyframes', default=False))


for _cls, _mode in (
    (TRANSFORM_OT_smart_grs_transform, 'G'),
    (TRANSFORM_OT_smart_grs_move, 'G'),
    (TRANSFORM_OT_smart_grs_translate, 'G'),
    (TRANSFORM_OT_smart_grs_rotate, 'R'),
    (TRANSFORM_OT_smart_grs_scale, 'S'),
    (TRANSFORM_OT_smart_grs_resize, 'S'),
):
    _install_grs_native_transform_compat_props(_cls, _mode)

class VIEW3D_OT_proportional_size_cursor(bpy.types.Operator):
    bl_idname = 'view3d.proportional_size_cursor'
    bl_label = TI('Proportional Size Cursor', 'プロポーショナルサイズカーソル')
    bl_description = TI(
        'Adjust the proportional editing radius with the cursor in every supported proportional-edit context, including Object, Mesh, Curve, Surface, Lattice, Armature, Pose, Grease Pencil, and animation editors.',
        'オブジェクト、メッシュ、カーブ、サーフェス、ラティス、アーマチュア、ポーズ、グリースペンシル、UV、アニメーション編集など、プロポーショナル編集が使える各コンテキストでカーソル操作により影響半径を調整します。'
    )
    bl_options = {'UNDO', 'BLOCKING', 'GRAB_CURSOR'}
    bl_undo_group = 'Smart Transform Suite'

    initial_mouse_x: bpy.props.IntProperty(
        name=TI('Initial Mouse X', '開始マウスX'),
        description=TI('Window-region X coordinate captured when proportional radius adjustment starts.', 'プロポーショナル半径調整を開始した時に記録したウィンドウ領域内のX座標です。'),
        default=0,
        options={'HIDDEN'},
    )
    initial_mouse_y: bpy.props.IntProperty(
        name=TI('Initial Mouse Y', '開始マウスY'),
        description=TI('Window-region Y coordinate captured when proportional radius adjustment starts.', 'プロポーショナル半径調整を開始した時に記録したウィンドウ領域内のY座標です。'),
        default=0,
        options={'HIDDEN'},
    )
    initial_region_x: bpy.props.IntProperty(
        name=TI('Initial Region X', '開始領域X'),
        description=TI('Region-local X coordinate captured when proportional radius adjustment starts.', 'プロポーショナル半径調整開始時の領域内X座標です。'),
        default=0,
        options={'HIDDEN'},
    )
    initial_region_y: bpy.props.IntProperty(
        name=TI('Initial Region Y', '開始領域Y'),
        description=TI('Region-local Y coordinate captured when proportional radius adjustment starts.', 'プロポーショナル半径調整開始時の領域内Y座標です。'),
        default=0,
        options={'HIDDEN'},
    )
    initial_size: bpy.props.FloatProperty(
        name=TI('Initial Radius', '開始半径'),
        description=TI('Proportional editing radius captured at the start of cursor-based radius adjustment.', 'カーソル操作による半径調整開始時に記録したプロポーショナル編集半径です。'),
        default=0.0,
        options={'HIDDEN'},
    )

    # NOTE:
    # Do not define __init__ on Blender RNA classes here. Blender may create
    # the Python wrapper with an internal RNA argument, which causes
    # "__init__() takes 1 positional argument but 2 were given" on invoke.
    # Keep transient runtime state as normal instance attributes assigned in
    # invoke/cancel/finish instead.
    _handle = None
    _shader = None
    _target_world_loc = None
    _draw_space_type = None
    _draw_space_class = None
    _radius_attr = 'proportional_size'
    _draw_kind = 'VIEW3D'
    _draw_area_ptr = None
    _draw_region_ptr = None

    _VIEW3D_PROP_MODES = {
        'OBJECT',
        'EDIT_MESH', 'EDIT_CURVE', 'EDIT_SURFACE', 'EDIT_LATTICE', 'EDIT_ARMATURE',
        'POSE', 'EDIT_GPENCIL', 'EDIT_GREASE_PENCIL', 'SCULPT_GPENCIL', 'SCULPT_CURVES',
    }
    _VIEW3D_PROP_OBJECT_TYPES = {
        'MESH', 'CURVE', 'SURFACE', 'FONT', 'LATTICE', 'ARMATURE',
        'GREASEPENCIL', 'GPENCIL', 'EMPTY', 'CAMERA', 'LIGHT', 'SPEAKER', 'VOLUME', 'POINTCLOUD', 'CURVES',
    }
    _ANIMATION_PROP_AREAS = {'GRAPH_EDITOR', 'DOPESHEET_EDITOR', 'NLA_EDITOR'}

    @classmethod
    def _area_type(cls, context):
        try:
            return str(getattr(getattr(context, 'area', None), 'type', '') or '')
        except Exception:
            return ''

    @classmethod
    def _tool_settings(cls, context):
        try:
            ts = getattr(context, 'tool_settings', None)
            if ts is not None:
                return ts
        except Exception:
            pass
        try:
            return context.scene.tool_settings
        except Exception:
            return None

    @classmethod
    def _active_object(cls, context):
        try:
            return getattr(context, 'active_object', None)
        except Exception:
            return None

    @classmethod
    def _has_attr(cls, obj, attr):
        try:
            getattr(obj, attr)
            return True
        except Exception:
            return False

    @classmethod
    def _supports_view3d_context(cls, context):
        ts = cls._tool_settings(context)
        if ts is None or not cls._has_attr(ts, 'proportional_size'):
            return False
        mode = str(getattr(context, 'mode', '') or 'OBJECT')
        obj = cls._active_object(context)
        if mode == 'OBJECT':
            return True
        if mode in cls._VIEW3D_PROP_MODES or mode.startswith('EDIT'):
            if obj is None:
                return True
            obj_type = str(getattr(obj, 'type', '') or '')
            return obj_type in cls._VIEW3D_PROP_OBJECT_TYPES or bool(obj_type)
        # Some editors/tools expose an empty or specialized mode while still using
        # ToolSettings.proportional_size.  Keep the operator available and fall
        # back to cursor/object-origin drawing rather than rejecting it.
        return True

    @classmethod
    def _supports_uv_context(cls, context):
        ts = cls._tool_settings(context)
        if ts is None or not cls._has_attr(ts, 'proportional_size'):
            return False
        obj = cls._active_object(context)
        if obj is None or getattr(obj, 'type', '') != 'MESH':
            return False
        mode = str(getattr(context, 'mode', '') or '')
        obj_mode = str(getattr(obj, 'mode', '') or '')
        if mode != 'EDIT_MESH' and obj_mode != 'EDIT':
            return False
        try:
            space = getattr(context, 'space_data', None)
            # Blender 5.1's SpaceImageEditor.mode is the reliable selector for
            # UV vs Image View.  Reading the older ui_mode field in UV mode can
            # emit RNA warnings, so consult it only as a fallback.
            mode_name = str(getattr(space, 'mode', '') or '')
            if mode_name and mode_name not in {'UV', 'VIEW'}:
                return False
            if not mode_name:
                try:
                    ui_mode = str(getattr(space, 'ui_mode', '') or '')
                except Exception:
                    ui_mode = ''
                if ui_mode and ui_mode != 'UV':
                    return False
        except Exception:
            pass
        return True

    @classmethod
    def _supports_animation_context(cls, context):
        ts = cls._tool_settings(context)
        if ts is None:
            return False
        return cls._has_attr(ts, 'proportional_distance') or cls._has_attr(ts, 'proportional_size')

    @classmethod
    def poll(cls, context):
        if context is None:
            return False
        if getattr(context, 'area', None) is None:
            return False
        area_type = cls._area_type(context)
        if area_type != 'VIEW_3D' and area_type not in cls._ANIMATION_PROP_AREAS:
            return False
        if not _workspace_runtime_allowed(context):
            return False
        if area_type == 'VIEW_3D':
            return cls._supports_view3d_context(context)
        if area_type in cls._ANIMATION_PROP_AREAS:
            return cls._supports_animation_context(context)
        return False

    def _tag_redraw(self):
        try:
            _tag_all_view3d_redraw()
        except Exception:
            pass
        try:
            wm = getattr(bpy.context, 'window_manager', None)
            if wm:
                for window in getattr(wm, 'windows', []):
                    screen = getattr(window, 'screen', None)
                    if not screen:
                        continue
                    for area in getattr(screen, 'areas', []):
                        if getattr(area, 'type', '') in {'VIEW_3D', 'GRAPH_EDITOR', 'DOPESHEET_EDITOR', 'NLA_EDITOR'}:
                            area.tag_redraw()
        except Exception:
            pass
        try:
            if bpy.context.area:
                bpy.context.area.tag_redraw()
        except Exception:
            pass

    @staticmethod
    def _avg_vec(coords):
        coords = [c.copy() if hasattr(c, 'copy') else mathutils.Vector(c) for c in coords if c is not None]
        if not coords:
            return None
        acc = mathutils.Vector((0.0,) * len(coords[0]))
        for co in coords:
            acc += co
        return acc / float(len(coords))

    @staticmethod
    def _safe_vec3(value):
        try:
            if value is None:
                return None
            if hasattr(value, 'to_3d'):
                return value.to_3d().copy()
            if len(value) >= 4:
                w = float(value[3]) if abs(float(value[3])) > 1.0e-8 else 1.0
                return mathutils.Vector((float(value[0]) / w, float(value[1]) / w, float(value[2]) / w))
            if len(value) >= 3:
                return mathutils.Vector((float(value[0]), float(value[1]), float(value[2])))
        except Exception:
            pass
        return None

    def _iter_context_edit_objects(self, context, object_types=None):
        objs = []
        seen = set()
        try:
            candidates = list(getattr(context, 'objects_in_mode', []) or [])
        except Exception:
            candidates = []
        if not candidates:
            try:
                candidates = [obj for obj in context.view_layer.objects if getattr(obj, 'mode', '') == 'EDIT']
            except Exception:
                candidates = []
        try:
            active = getattr(context, 'active_object', None)
            if active is not None:
                candidates.append(active)
        except Exception:
            pass
        for obj in candidates:
            if obj is None:
                continue
            if object_types and getattr(obj, 'type', '') not in object_types:
                continue
            key = getattr(obj, 'name_full', getattr(obj, 'name', id(obj)))
            if key in seen:
                continue
            seen.add(key)
            objs.append(obj)
        return objs

    def _append_mesh_selected_world(self, obj, coords, *, active_elem_store=None):
        try:
            bm = bmesh.from_edit_mesh(obj.data)
        except Exception:
            return
        mat = obj.matrix_world
        if active_elem_store is not None and active_elem_store.get('value') is None:
            try:
                elem = bm.select_history.active
            except ReferenceError:
                elem = None
            except Exception:
                elem = None
            if elem is not None:
                try:
                    if isinstance(elem, bmesh.types.BMVert):
                        active_elem_store['value'] = mat @ elem.co.copy()
                    elif isinstance(elem, bmesh.types.BMEdge):
                        verts = list(elem.verts)
                        if verts:
                            active_elem_store['value'] = mat @ (sum((v.co.copy() for v in verts), mathutils.Vector((0, 0, 0))) / len(verts))
                    elif isinstance(elem, bmesh.types.BMFace):
                        active_elem_store['value'] = mat @ elem.calc_center_median().copy()
                except Exception:
                    pass
        try:
            for v in list(bm.verts):
                try:
                    if bool(v.select):
                        coords.append(mat @ v.co.copy())
                except Exception:
                    continue
        except Exception:
            pass

    def _append_curve_selected_world(self, obj, coords):
        try:
            splines = getattr(getattr(obj, 'data', None), 'splines', [])
            mat = obj.matrix_world
        except Exception:
            return
        for spline in splines:
            try:
                for bp in getattr(spline, 'bezier_points', []):
                    try:
                        if getattr(bp, 'select_control_point', False):
                            coords.append(mat @ bp.co.copy())
                        if getattr(bp, 'select_left_handle', False):
                            coords.append(mat @ bp.handle_left.copy())
                        if getattr(bp, 'select_right_handle', False):
                            coords.append(mat @ bp.handle_right.copy())
                    except Exception:
                        continue
                for p in getattr(spline, 'points', []):
                    try:
                        if getattr(p, 'select', False):
                            co = self._safe_vec3(p.co)
                            if co is not None:
                                coords.append(mat @ co)
                    except Exception:
                        continue
            except Exception:
                continue

    def _append_lattice_selected_world(self, obj, coords):
        try:
            mat = obj.matrix_world
            points = getattr(getattr(obj, 'data', None), 'points', [])
        except Exception:
            return
        for p in points:
            try:
                if not getattr(p, 'select', False):
                    continue
                co = getattr(p, 'co_deform', None)
                if co is None:
                    co = getattr(p, 'co', None)
                co = self._safe_vec3(co)
                if co is not None:
                    coords.append(mat @ co)
            except Exception:
                continue

    def _append_armature_selected_world(self, obj, coords):
        try:
            mat = obj.matrix_world
            data = obj.data
        except Exception:
            return
        try:
            if str(getattr(obj, 'mode', '') or '') == 'EDIT':
                for bone in getattr(data, 'edit_bones', []):
                    try:
                        if getattr(bone, 'select_head', False):
                            coords.append(mat @ bone.head.copy())
                        if getattr(bone, 'select_tail', False):
                            coords.append(mat @ bone.tail.copy())
                        if getattr(bone, 'select', False) and not getattr(bone, 'select_head', False) and not getattr(bone, 'select_tail', False):
                            coords.append(mat @ ((bone.head + bone.tail) * 0.5))
                    except Exception:
                        continue
            else:
                pose = getattr(obj, 'pose', None)
                for pb in getattr(pose, 'bones', []) or []:
                    try:
                        if getattr(pb.bone, 'select', False):
                            coords.append(mat @ ((pb.head.copy() + pb.tail.copy()) * 0.5))
                    except Exception:
                        continue
        except Exception:
            return

    def _append_object_world_centers(self, context, coords):
        try:
            objects = list(getattr(context, 'selected_objects', []) or [])
        except Exception:
            objects = []
        if not objects and getattr(context, 'active_object', None) is not None:
            objects = [context.active_object]
        for obj in objects:
            try:
                coords.append(obj.matrix_world.translation.copy())
            except Exception:
                continue

    def _resolve_target_world_location(self, context):
        try:
            pivot_mode = getattr(context.scene.tool_settings, 'transform_pivot_point', 'MEDIAN_POINT')
        except Exception:
            pivot_mode = 'MEDIAN_POINT'
        target_loc = None
        selected_world_coords = []
        active_elem_store = {'value': None}
        mode = str(getattr(context, 'mode', '') or 'OBJECT')

        if mode == 'OBJECT':
            self._append_object_world_centers(context, selected_world_coords)
        elif mode == 'POSE':
            obj = getattr(context, 'active_object', None)
            if obj is not None:
                self._append_armature_selected_world(obj, selected_world_coords)
        elif mode.startswith('EDIT'):
            for obj in self._iter_context_edit_objects(context):
                obj_type = str(getattr(obj, 'type', '') or '')
                if obj_type == 'MESH':
                    self._append_mesh_selected_world(obj, selected_world_coords, active_elem_store=active_elem_store)
                elif obj_type in {'CURVE', 'SURFACE', 'FONT'}:
                    self._append_curve_selected_world(obj, selected_world_coords)
                elif obj_type == 'LATTICE':
                    self._append_lattice_selected_world(obj, selected_world_coords)
                elif obj_type == 'ARMATURE':
                    self._append_armature_selected_world(obj, selected_world_coords)
                elif obj is not None:
                    try:
                        selected_world_coords.append(obj.matrix_world.translation.copy())
                    except Exception:
                        pass
        else:
            self._append_object_world_centers(context, selected_world_coords)

        if pivot_mode == 'ACTIVE_ELEMENT' and active_elem_store.get('value') is not None:
            target_loc = active_elem_store['value']
        elif selected_world_coords:
            target_loc = self._avg_vec(selected_world_coords)

        if target_loc is None:
            if getattr(context, 'active_object', None) is not None:
                try:
                    target_loc = context.active_object.matrix_world.translation.copy()
                except Exception:
                    target_loc = None
            if target_loc is None:
                try:
                    target_loc = context.scene.cursor.location.copy()
                except Exception:
                    target_loc = mathutils.Vector((0.0, 0.0, 0.0))
        return target_loc


    def _radius_property_name(self, context):
        area_type = self._area_type(context)
        ts = self._tool_settings(context)
        if area_type in self._ANIMATION_PROP_AREAS and ts is not None and self._has_attr(ts, 'proportional_distance'):
            return 'proportional_distance'
        return 'proportional_size'

    def _draw_space_class_for_context(self, context):
        area_type = self._area_type(context)
        if area_type == 'GRAPH_EDITOR' and hasattr(bpy.types, 'SpaceGraphEditor'):
            return bpy.types.SpaceGraphEditor
        if area_type == 'DOPESHEET_EDITOR' and hasattr(bpy.types, 'SpaceDopeSheetEditor'):
            return bpy.types.SpaceDopeSheetEditor
        if area_type == 'NLA_EDITOR':
            return getattr(bpy.types, 'SpaceNLA', None) or getattr(bpy.types, 'SpaceNLAEditor', None)
        return bpy.types.SpaceView3D

    @staticmethod
    def _window_region_for_area(area):
        try:
            for region in getattr(area, 'regions', []) or []:
                if getattr(region, 'type', '') == 'WINDOW':
                    return region
        except Exception:
            pass
        return None

    def _origin_window_region(self, context):
        """Return the draw/modal WINDOW region for the current editor area.

        N-panel buttons are invoked from a UI region.  In that case, storing the
        UI region pointer prevents the POST_PIXEL draw callback from ever
        drawing in the actual View3D WINDOW region and makes the 3D cursor
        adjustment appear not to start.  Resolve the editor's WINDOW region
        explicitly while keeping the originating area locked.
        """
        try:
            region = getattr(context, 'region', None)
            if region is not None and getattr(region, 'type', '') == 'WINDOW':
                return region
        except Exception:
            pass
        try:
            area = getattr(context, 'area', None)
            if area is not None:
                found = self._window_region_for_area(area)
                if found is not None:
                    return found
        except Exception:
            pass
        try:
            return getattr(context, 'region', None)
        except Exception:
            return None

    @staticmethod
    def _region_center(region):
        try:
            return (int(max(0, getattr(region, 'width', 0)) * 0.5), int(max(0, getattr(region, 'height', 0)) * 0.5))
        except Exception:
            return (0, 0)

    def _event_coords_for_origin_region(self, context, event, origin_region):
        if origin_region is None:
            try:
                return (int(getattr(event, 'mouse_x', 0)), int(getattr(event, 'mouse_y', 0)), int(getattr(event, 'mouse_region_x', 0)), int(getattr(event, 'mouse_region_y', 0)))
            except Exception:
                return (0, 0, 0, 0)
        try:
            cur_region = getattr(context, 'region', None)
            if event is not None and cur_region is origin_region and getattr(origin_region, 'type', '') == 'WINDOW':
                return (
                    int(getattr(event, 'mouse_x', 0)),
                    int(getattr(event, 'mouse_y', 0)),
                    int(getattr(event, 'mouse_region_x', 0)),
                    int(getattr(event, 'mouse_region_y', 0)),
                )
        except Exception:
            pass
        try:
            mx = int(getattr(event, 'mouse_x', 0)) if event is not None else int(getattr(origin_region, 'x', 0) + getattr(origin_region, 'width', 0) * 0.5)
            my = int(getattr(event, 'mouse_y', 0)) if event is not None else int(getattr(origin_region, 'y', 0) + getattr(origin_region, 'height', 0) * 0.5)
            rx = int(mx - int(getattr(origin_region, 'x', 0)))
            ry = int(my - int(getattr(origin_region, 'y', 0)))
            width = int(getattr(origin_region, 'width', 0) or 0)
            height = int(getattr(origin_region, 'height', 0) or 0)
            if rx < 0 or ry < 0 or (width and rx > width) or (height and ry > height):
                rx, ry = self._region_center(origin_region)
                mx = int(getattr(origin_region, 'x', 0)) + rx
                my = int(getattr(origin_region, 'y', 0)) + ry
            return (mx, my, rx, ry)
        except Exception:
            rx, ry = self._region_center(origin_region)
            return (rx, ry, rx, ry)

    def _start_cursor_modal(self, context, event=None):
        if not self.poll(context):
            return {'CANCELLED'}

        self._handle = None
        self._shader = None
        self._target_world_loc = None
        self._draw_area_ptr = None
        self._draw_region_ptr = None
        origin_region = self._origin_window_region(context)
        try:
            self._draw_area_ptr = context.area.as_pointer()
        except Exception:
            self._draw_area_ptr = None
        try:
            self._draw_region_ptr = origin_region.as_pointer() if origin_region is not None else context.region.as_pointer()
        except Exception:
            self._draw_region_ptr = None
        self._draw_space_type = self._area_type(context) or 'VIEW_3D'
        self._draw_space_class = self._draw_space_class_for_context(context)
        self._radius_attr = self._radius_property_name(context)
        mx, my, rx, ry = self._event_coords_for_origin_region(context, event, origin_region)
        self.initial_mouse_x = int(mx)
        self.initial_mouse_y = int(my)
        self.initial_region_x = int(rx)
        self.initial_region_y = int(ry)

        if self._draw_space_type in self._ANIMATION_PROP_AREAS:
            self._draw_kind = '2D'
        else:
            self._draw_kind = 'VIEW3D'
            self._target_world_loc = self._resolve_target_world_location(context)

        try:
            self.initial_size = max(0.0001, float(getattr(context.tool_settings, self._radius_attr, 1.0)))
        except Exception:
            self.initial_size = 1.0

        try:
            self._shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception:
            try:
                self._shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
            except Exception:
                self._shader = None

        try:
            if self._draw_space_class is not None:
                self._handle = self._draw_space_class.draw_handler_add(
                    self.draw_callback_px, (self,), 'WINDOW', 'POST_PIXEL'
                )
        except Exception:
            self._handle = None

        try:
            context.window_manager.modal_handler_add(self)
        except Exception:
            self._finish(context)
            return {'CANCELLED'}
        self._tag_redraw()
        return {'RUNNING_MODAL'}

    def execute(self, context):
        return self._start_cursor_modal(context, None)

    def invoke(self, context, event):
        return self._start_cursor_modal(context, event)

    def modal(self, context, event):
        if not _workspace_runtime_allowed(context):
            self._finish(context)
            return {'CANCELLED'}
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type in {'G', 'R', 'S'} and event.value == 'PRESS':
            self._finish(context)
            return {'FINISHED', 'PASS_THROUGH'}

        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            delta_x = float(getattr(event, 'mouse_x', 0) - self.initial_mouse_x)
            sensitivity = 0.008
            try:
                scale_factor = math.exp(delta_x * sensitivity)
            except OverflowError:
                scale_factor = 1.0
            new_size = max(0.0001, min(self.initial_size * scale_factor, 10000.0))
            try:
                setattr(context.tool_settings, self._radius_attr, new_size)
            except Exception:
                return {'CANCELLED'}
            self._tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'}:
            self._finish(context)
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._finish(context)

    def _finish(self, context):
        if self._handle is not None:
            space_cls = self._draw_space_class or bpy.types.SpaceView3D
            try:
                space_cls.draw_handler_remove(self._handle, 'WINDOW')
            except Exception:
                try:
                    bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                except Exception:
                    pass
            self._handle = None
        self._draw_area_ptr = None
        self._draw_region_ptr = None
        self._tag_redraw()

    def _draw_circle_pixels(self, center_2d, radius_px, draw_color, draw_line_width):
        if self._shader is None:
            return
        try:
            cx, cy = float(center_2d[0]), float(center_2d[1])
            radius_px = float(radius_px)
        except Exception:
            return
        if radius_px <= 0.5:
            return

        vertices = []
        for i in range(96):
            angle = 2.0 * math.pi * i / 96.0
            vertices.append((cx + math.cos(angle) * radius_px, cy + math.sin(angle) * radius_px))

        # Vulkan では LINE_LOOP の閉じる辺が落ちるため、始点を足した LINE_STRIP で閉じる。
        batch = batch_for_shader(self._shader, 'LINE_STRIP', {'pos': vertices + vertices[:1]})
        prev_blend = getattr(gpu.state, 'blend_get', lambda: None)()
        prev_line_width = getattr(gpu.state, 'line_width_get', lambda: 1.0)()
        try:
            self._shader.bind()
            self._shader.uniform_float('color', draw_color)
            gpu.state.line_width_set(draw_line_width)
            gpu.state.blend_set('ALPHA')
            batch.draw(self._shader)
        finally:
            try:
                gpu.state.blend_set(prev_blend if prev_blend is not None else 'NONE')
            except Exception:
                pass
            try:
                gpu.state.line_width_set(prev_line_width)
            except Exception:
                pass

    def _draw_settings(self, context):
        prefs = _prefs(context)
        draw_color = (0.2388, 0.2388, 0.2388, 1.0)
        draw_line_width = 2.0
        if prefs is not None:
            try:
                if hasattr(prefs, 'show_orange_circle') and not bool(prefs.show_orange_circle):
                    return None
                if hasattr(prefs, 'circle_color'):
                    draw_color = tuple(prefs.circle_color[:])
                if hasattr(prefs, 'circle_line_width'):
                    draw_line_width = float(prefs.circle_line_width)
            except Exception:
                pass
        return draw_color, draw_line_width

    def _is_origin_draw_context(self, context):
        try:
            if self._draw_area_ptr is not None:
                area = getattr(context, 'area', None)
                if area is None or area.as_pointer() != self._draw_area_ptr:
                    return False
        except Exception:
            return False
        try:
            if self._draw_region_ptr is not None:
                region = getattr(context, 'region', None)
                if region is None or region.as_pointer() != self._draw_region_ptr:
                    return False
        except Exception:
            return False
        return True

    def draw_callback_px(self, _op):
        context = bpy.context
        if not context or not getattr(context, 'region', None):
            return
        if getattr(context.region, 'type', '') != 'WINDOW':
            return
        if not _workspace_runtime_allowed(context):
            return
        if not self._is_origin_draw_context(context):
            return
        settings = self._draw_settings(context)
        if settings is None:
            return
        draw_color, draw_line_width = settings
        if getattr(self, '_draw_kind', 'VIEW3D') == '2D':
            self._draw_callback_2d(context, draw_color, draw_line_width)
        else:
            self._draw_callback_view3d(context, draw_color, draw_line_width)
    def _draw_callback_2d(self, context, draw_color, draw_line_width):
        try:
            current_size = max(0.0001, float(getattr(context.tool_settings, self._radius_attr, self.initial_size)))
            radius_px = max(12.0, min(256.0, 48.0 * (current_size / max(0.0001, self.initial_size))))
        except Exception:
            radius_px = 48.0
        center_2d = (float(getattr(self, 'initial_region_x', 0)), float(getattr(self, 'initial_region_y', 0)))
        self._draw_circle_pixels(center_2d, radius_px, draw_color, draw_line_width)

    def _draw_callback_view3d(self, context, draw_color, draw_line_width):
        if not getattr(context, 'space_data', None):
            return
        if self._shader is None or self._target_world_loc is None:
            return
        rv3d = getattr(context, 'region_data', None)
        if rv3d is None:
            return

        center_2d = view3d_utils.location_3d_to_region_2d(context.region, rv3d, self._target_world_loc)
        if center_2d is None:
            return

        try:
            prop_size = float(getattr(context.tool_settings, self._radius_attr, getattr(context.tool_settings, 'proportional_size', 1.0)))
        except Exception:
            prop_size = 1.0
        view_right = rv3d.view_rotation @ mathutils.Vector((1.0, 0.0, 0.0))
        radius_world_loc = self._target_world_loc + (view_right * prop_size)
        radius_2d = view3d_utils.location_3d_to_region_2d(context.region, rv3d, radius_world_loc)
        if radius_2d is None:
            return

        dist = (mathutils.Vector(center_2d) - mathutils.Vector(radius_2d)).length
        self._draw_circle_pixels(center_2d, dist, draw_color, draw_line_width)





# =========================================================
# Init
# =========================================================
# Blender calls module register/unregister functions after import, but failed reloads
# can leave partially materialized module dictionaries in sys.modules.  Keep the
# Smart G-R-S class list explicit and make access defensive so installation cannot
# abort with NameError: name 'classes' is not defined.
classes = (
    VIEW3D_OT_proportional_size_cursor,
    TRANSFORM_OT_smart_grs_transform,
    TRANSFORM_OT_smart_grs_move,
    TRANSFORM_OT_smart_grs_translate,
    TRANSFORM_OT_smart_grs_rotate,
    TRANSFORM_OT_smart_grs_scale,
    TRANSFORM_OT_smart_grs_resize,
    MESH_OT_smart_island_transform_toggle,
    MESH_OT_sts_island_transform_toggle,
    MESH_OT_smart_island_move,
    MESH_OT_smart_island_rotate,
    MESH_OT_smart_island_scale,
)


def _grs_classes():
    value = globals().get('classes')
    if isinstance(value, (tuple, list)) and value:
        return tuple(c for c in value if isinstance(c, type))
    fallback = (
        globals().get('VIEW3D_OT_proportional_size_cursor'),
        globals().get('TRANSFORM_OT_smart_grs_transform'),
        globals().get('TRANSFORM_OT_smart_grs_move'),
        globals().get('TRANSFORM_OT_smart_grs_translate'),
        globals().get('TRANSFORM_OT_smart_grs_rotate'),
        globals().get('TRANSFORM_OT_smart_grs_scale'),
        globals().get('TRANSFORM_OT_smart_grs_resize'),
        globals().get('MESH_OT_smart_island_transform_toggle'),
        globals().get('MESH_OT_sts_island_transform_toggle'),
        globals().get('MESH_OT_smart_island_move'),
        globals().get('MESH_OT_smart_island_rotate'),
        globals().get('MESH_OT_smart_island_scale'),
    )
    return tuple(c for c in fallback if isinstance(c, type))


def register():
    _grs_publish_front_post_pixel_layer_policy()
    for c in _grs_classes():
        try:
            bpy.utils.register_class(c)
        except ValueError:
            try:
                bpy.utils.unregister_class(c)
            except Exception:
                pass
            bpy.utils.register_class(c)


def unregister():
    _grs_set_active_modal(None)
    _grs_clear_front_post_pixel_layer_policy()
    for c in reversed(_grs_classes()):
        _safe_unregister_class(c)
