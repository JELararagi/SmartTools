# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import os

# =========================================================
# Proportional Cursor Lock (Windows: ClipCursor + Raw Input)
# =========================================================
_PCL_WINDOWS_AVAILABLE = False

if os.name == "nt":
    try:
        import ctypes
        from ctypes import wintypes

        _PCL_WINDOWS_AVAILABLE = True
        _pcl_user32 = ctypes.windll.user32

        _PCL_VK_MENU = 0x12  # Alt

        class _PCL_POINT(ctypes.Structure):
            _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

        class _PCL_RECT(ctypes.Structure):
            _fields_ = [
                ("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)
            ]

        try:
            _PCL_LRESULT = wintypes.LRESULT
        except AttributeError:
            _PCL_LRESULT = ctypes.c_ssize_t

        _PCL_WM_INPUT = 0x00FF
        _PCL_RID_INPUT = 0x10000003
        _PCL_RIM_TYPEMOUSE = 0

        _PCL_GWLP_WNDPROC = -4
        _PCL_RIDEV_INPUTSINK = 0x00000100

        class _PCL_RAWINPUTHEADER(ctypes.Structure):
            _fields_ = [
                ("dwType", wintypes.DWORD),
                ("dwSize", wintypes.DWORD),
                ("hDevice", wintypes.HANDLE),
                ("wParam", wintypes.WPARAM),
            ]

        class _PCL__RAWMOUSE_BUTTONS(ctypes.Union):
            _fields_ = [
                ("ulButtons", wintypes.ULONG),
                ("usButtonData", wintypes.USHORT * 2),
            ]

        class _PCL_RAWMOUSE(ctypes.Structure):
            _anonymous_ = ("u1",)
            _fields_ = [
                ("usFlags", wintypes.USHORT),
                ("u1", _PCL__RAWMOUSE_BUTTONS),
                ("ulRawButtons", wintypes.ULONG),
                ("lLastX", wintypes.LONG),
                ("lLastY", wintypes.LONG),
                ("ulExtraInformation", wintypes.ULONG),
            ]

        class _PCL__RAWINPUT_UNION(ctypes.Union):
            _fields_ = [("mouse", _PCL_RAWMOUSE)]

        class _PCL_RAWINPUT(ctypes.Structure):
            _anonymous_ = ("data",)
            _fields_ = [
                ("header", _PCL_RAWINPUTHEADER),
                ("data", _PCL__RAWINPUT_UNION),
            ]

        class _PCL_RAWINPUTDEVICE(ctypes.Structure):
            _fields_ = [
                ("usUsagePage", wintypes.USHORT),
                ("usUsage", wintypes.USHORT),
                ("dwFlags", wintypes.DWORD),
                ("hwndTarget", wintypes.HWND),
            ]

        _pcl_user32.ClipCursor.argtypes = (ctypes.POINTER(_PCL_RECT),)
        _pcl_user32.ClipCursor.restype = wintypes.BOOL

        _pcl_user32.GetCursorPos.argtypes = (ctypes.POINTER(_PCL_POINT),)
        _pcl_user32.GetCursorPos.restype = wintypes.BOOL

        _pcl_user32.GetAsyncKeyState.argtypes = (ctypes.c_int,)
        _pcl_user32.GetAsyncKeyState.restype = wintypes.SHORT

        _pcl_user32.GetForegroundWindow.argtypes = ()
        _pcl_user32.GetForegroundWindow.restype = wintypes.HWND

        _pcl_user32.IsWindow.argtypes = (wintypes.HWND,)
        _pcl_user32.IsWindow.restype = wintypes.BOOL

        _pcl_user32.IsWindowVisible.argtypes = (wintypes.HWND,)
        _pcl_user32.IsWindowVisible.restype = wintypes.BOOL

        _pcl_user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
        _pcl_user32.GetWindowThreadProcessId.restype = wintypes.DWORD

        if ctypes.sizeof(ctypes.c_void_p) == 8:
            _pcl_GetWindowLongPtr = _pcl_user32.GetWindowLongPtrW
            _pcl_SetWindowLongPtr = _pcl_user32.SetWindowLongPtrW
        else:
            _pcl_GetWindowLongPtr = _pcl_user32.GetWindowLongW
            _pcl_SetWindowLongPtr = _pcl_user32.SetWindowLongW

        _pcl_GetWindowLongPtr.argtypes = (wintypes.HWND, ctypes.c_int)
        _pcl_GetWindowLongPtr.restype = ctypes.c_void_p
        _pcl_SetWindowLongPtr.argtypes = (wintypes.HWND, ctypes.c_int, ctypes.c_void_p)
        _pcl_SetWindowLongPtr.restype = ctypes.c_void_p

        _pcl_user32.CallWindowProcW.argtypes = (ctypes.c_void_p, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
        _pcl_user32.CallWindowProcW.restype = _PCL_LRESULT

        _pcl_user32.RegisterRawInputDevices.argtypes = (ctypes.POINTER(_PCL_RAWINPUTDEVICE), wintypes.UINT, wintypes.UINT)
        _pcl_user32.RegisterRawInputDevices.restype = wintypes.BOOL

        _pcl_user32.GetRawInputData.argtypes = (
            wintypes.HANDLE, wintypes.UINT, wintypes.LPVOID,
            ctypes.POINTER(wintypes.UINT), wintypes.UINT
        )
        _pcl_user32.GetRawInputData.restype = wintypes.UINT

        _PCL_EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        _pcl_user32.EnumWindows.argtypes = (_PCL_EnumWindowsProc, wintypes.LPARAM)
        _pcl_user32.EnumWindows.restype = wintypes.BOOL

        class _PCL_State:
            running = False
            pending_dx = 0.0
            clip_locked = False
            anchor_pos = _PCL_POINT()
            hwnd = None
            wndproc_installed = False
            orig_wndproc = None
            wndproc_cb = None
            raw_registered = False

        _pcl_state = _PCL_State()

        def _pcl_is_alt_down_physically() -> bool:
            try:
                return (_pcl_user32.GetAsyncKeyState(_PCL_VK_MENU) & 0x8000) != 0
            except Exception:
                return False

        def _pcl_get_cursor_pos() -> _PCL_POINT:
            pt = _PCL_POINT()
            try:
                _pcl_user32.GetCursorPos(ctypes.byref(pt))
            except Exception:
                pass
            return pt

        def _pcl_clip_lock_at(pt: _PCL_POINT) -> None:
            try:
                r = _PCL_RECT(int(pt.x), int(pt.y), int(pt.x) + 1, int(pt.y) + 1)
                _pcl_user32.ClipCursor(ctypes.byref(r))
                _pcl_state.clip_locked = True
            except Exception:
                pass

        def _pcl_clip_unlock() -> None:
            try:
                _pcl_user32.ClipCursor(None)
            except Exception:
                pass
            _pcl_state.clip_locked = False

        def _pcl_find_blender_hwnd() -> wintypes.HWND:
            try:
                import os as _os
                pid = _os.getpid()
                hwnd = _pcl_user32.GetForegroundWindow()
                if hwnd:
                    out_pid = wintypes.DWORD(0)
                    _pcl_user32.GetWindowThreadProcessId(hwnd, ctypes.byref(out_pid))
                    if out_pid.value == pid:
                        return hwnd

                hwnd_found = wintypes.HWND(0)
                def _cb(h, lparam):
                    nonlocal hwnd_found
                    if not _pcl_user32.IsWindowVisible(h):
                        return True
                    out_pid = wintypes.DWORD(0)
                    _pcl_user32.GetWindowThreadProcessId(h, ctypes.byref(out_pid))
                    if out_pid.value == pid:
                        hwnd_found = h
                        return False
                    return True
                _pcl_user32.EnumWindows(_PCL_EnumWindowsProc(_cb), 0)
                return hwnd_found
            except Exception:
                return wintypes.HWND(0)

        def _pcl_register_raw_mouse(hwnd: wintypes.HWND) -> bool:
            try:
                rid = _PCL_RAWINPUTDEVICE()
                rid.usUsagePage = 0x01
                rid.usUsage = 0x02
                rid.dwFlags = _PCL_RIDEV_INPUTSINK
                rid.hwndTarget = hwnd
                return bool(_pcl_user32.RegisterRawInputDevices(ctypes.byref(rid), 1, ctypes.sizeof(_PCL_RAWINPUTDEVICE)))
            except Exception:
                return False

        def _pcl_read_raw_dx(hraw: wintypes.HANDLE) -> int:
            try:
                size = wintypes.UINT(0)
                _pcl_user32.GetRawInputData(hraw, _PCL_RID_INPUT, None, ctypes.byref(size), ctypes.sizeof(_PCL_RAWINPUTHEADER))
                if not size.value:
                    return 0
                buf = ctypes.create_string_buffer(size.value)
                got = _pcl_user32.GetRawInputData(hraw, _PCL_RID_INPUT, buf, ctypes.byref(size), ctypes.sizeof(_PCL_RAWINPUTHEADER))
                if not got:
                    return 0
                raw = ctypes.cast(buf, ctypes.POINTER(_PCL_RAWINPUT)).contents
                if raw.header.dwType != _PCL_RIM_TYPEMOUSE:
                    return 0
                return int(raw.mouse.lLastX)
            except Exception:
                return 0

        def _pcl_ensure_wndproc_tap() -> None:
            try:
                if _pcl_state.wndproc_installed and _pcl_state.hwnd and _pcl_user32.IsWindow(_pcl_state.hwnd):
                    return
                hwnd = _pcl_find_blender_hwnd()
                if not hwnd or not _pcl_user32.IsWindow(hwnd):
                    return
                WNDPROCTYPE = ctypes.WINFUNCTYPE(_PCL_LRESULT, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM)
                def _wndproc(hwnd_, msg, wparam, lparam):
                    try:
                        if msg == _PCL_WM_INPUT and _pcl_state.running:
                            dx = _pcl_read_raw_dx(ctypes.c_void_p(lparam))
                            if dx:
                                _pcl_state.pending_dx = float(_pcl_state.pending_dx) + float(dx)
                    except Exception:
                        pass
                    return _pcl_user32.CallWindowProcW(_pcl_state.orig_wndproc, hwnd_, msg, wparam, lparam)
                cb = WNDPROCTYPE(_wndproc)
                orig = _pcl_GetWindowLongPtr(hwnd, _PCL_GWLP_WNDPROC)
                if not orig:
                    return
                _pcl_SetWindowLongPtr(hwnd, _PCL_GWLP_WNDPROC, ctypes.cast(cb, ctypes.c_void_p))
                _pcl_state.hwnd = hwnd
                _pcl_state.orig_wndproc = orig
                _pcl_state.wndproc_cb = cb
                _pcl_state.wndproc_installed = True
                if not _pcl_state.raw_registered:
                    _pcl_state.raw_registered = _pcl_register_raw_mouse(hwnd)
            except Exception:
                pass

        def _pcl_remove_wndproc_tap() -> None:
            try:
                if _pcl_state.wndproc_installed and _pcl_state.hwnd and _pcl_user32.IsWindow(_pcl_state.hwnd) and _pcl_state.orig_wndproc:
                    _pcl_SetWindowLongPtr(_pcl_state.hwnd, _PCL_GWLP_WNDPROC, ctypes.c_void_p(_pcl_state.orig_wndproc))
            except Exception:
                pass
            _pcl_state.wndproc_installed = False
            _pcl_state.hwnd = None
            _pcl_state.orig_wndproc = None
            _pcl_state.wndproc_cb = None
            _pcl_state.raw_registered = False

    except Exception:
        _PCL_WINDOWS_AVAILABLE = False

# ---- Smart Transform safe PCL fallbacks ----
# Keep the module importable on platforms or Windows environments where a
# ctypes/wintypes symbol is unavailable during add-on startup. Runtime cursor
# locking remains disabled when the Windows implementation could not initialize.
if '_PCL_POINT' not in globals():
    class _PCL_POINT:
        def __init__(self, x=0, y=0):
            self.x = x
            self.y = y

if '_pcl_state' not in globals():
    class _PCL_FallbackState:
        running = False
        pending_dx = 0.0
        clip_locked = False
        anchor_pos = _PCL_POINT()
        hwnd = None
        wndproc_installed = False
        orig_wndproc = None
        wndproc_cb = None
        raw_registered = False
    _pcl_state = _PCL_FallbackState()

if '_pcl_get_cursor_pos' not in globals():
    def _pcl_get_cursor_pos():
        return _PCL_POINT()

if '_pcl_clip_lock_at' not in globals():
    def _pcl_clip_lock_at(pt):
        _pcl_state.clip_locked = False

if '_pcl_clip_unlock' not in globals():
    def _pcl_clip_unlock():
        _pcl_state.clip_locked = False

if '_pcl_ensure_wndproc_tap' not in globals():
    def _pcl_ensure_wndproc_tap():
        return None

if '_pcl_remove_wndproc_tap' not in globals():
    def _pcl_remove_wndproc_tap():
        _pcl_state.wndproc_installed = False
        _pcl_state.hwnd = None
        _pcl_state.orig_wndproc = None
        _pcl_state.wndproc_cb = None
        _pcl_state.raw_registered = False
