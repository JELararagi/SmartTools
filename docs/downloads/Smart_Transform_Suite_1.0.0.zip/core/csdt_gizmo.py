# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import bmesh
import json
import math
import sys
import time
from collections import OrderedDict
from typing import NamedTuple
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector, Matrix, Euler, Quaternion, geometry as geometry_utils
from bpy_extras import view3d_utils
from bpy.app.handlers import persistent

from .. import load_hooks as _load_hooks
from . import csdt_globals as cg
from . import csdt_utils as cu

_SMART_GIZMO_STARTUP_REPAIR_RUNNING = False
_SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING = False
_SMART_GIZMO_STARTUP_REPAIR_TIMER = None
_SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER = None
_SMART_GIZMO_GUARDIAN_INTERVAL_ACTIVE = 0.35
_SMART_GIZMO_GUARDIAN_INTERVAL_IDLE = 1.00
_SMART_GIZMO_WATCHER_TIMER_INTERVAL = 0.75
_SMART_GIZMO_WATCHER_STALE_SECONDS = 3.5
_SMART_GIZMO_LAST_GOOD_TTL = 1.25
_SMART_GIZMO_HOVER_MIN_INTERVAL = 1.0 / 90.0
_SMART_GIZMO_HOVER_MIN_MOVE_PX = 1.0
_SMART_GIZMO_LAST_SMART_OVERLAY_DRAW_MARKER = None
_SMART_GIZMO_LAST_SMART_OVERLAY_ORDER_REPAIR_AT = 0.0
# Optional active-tool notification.  It only schedules one bounded reconcile;
# no msgbus callback performs RNA/GPU mutation directly.
_SMART_GIZMO_TOOL_MSGBUS_OWNER = object()
_SMART_GIZMO_TOOL_MSGBUS_INSTALLED = False
_SMART_GIZMO_VIEW_NAV_EVENTS = {
    'MIDDLEMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM', 'TRACKPADZOOMIN', 'TRACKPADZOOMOUT',
    'MOUSEROTATE', 'MOUSEPAN', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
}
_SMART_GIZMO_VIEW_NAV_BUTTON_EVENTS = {'MIDDLEMOUSE'}
_SMART_BUILTIN_TRANSFORM_GIZMO_ATTRS = (
    'show_gizmo_tool',
    'show_gizmo_object_translate',
    'show_gizmo_object_rotate',
    'show_gizmo_object_scale',
)
# Per-SpaceView3D snapshot of Blender's native gizmo switches.  Smart Gizmo
# temporarily changes these values while its live runtime is active, but it must
# restore the exact user/file state when the runtime or add-on is disabled.
_SMART_BUILTIN_GIZMO_STATE_BY_SPACE = {}

# Explicit front-most POST_PIXEL layer contract and immutable geometry/GPU
# snapshots.  Object/EditMesh data and GPU batches are built only from finite
# event-side reconciliation.  The draw callback combines those batches with the
# current RegionView3D matrices, so orbit/pan/zoom never waits for a cached view.
_SMART_GIZMO_LAYER_POLICY_KEY = "JELARARAGI_VIEW3D_POST_PIXEL_LAYER_POLICY_V2"
_SMART_GIZMO_LAYER_OWNER = "smart_transform_suite.smart_gizmo"
_SMART_GIZMO_LAYER_OWNER_TOKEN = object()
_SMART_GIZMO_DRAW_SNAPSHOTS = OrderedDict()
_SMART_GIZMO_DRAW_SNAPSHOT_BYTES = 0
_SMART_GIZMO_DRAW_SNAPSHOT_MAX_ENTRIES = 32
_SMART_GIZMO_DRAW_SNAPSHOT_MAX_BYTES = 8 * 1024 * 1024
_SMART_GIZMO_DRAW_SNAPSHOT_MAX_COMMANDS = 512
_SMART_GIZMO_SNAPSHOT_GENERATION = 0
# Smart G-R-S drag follow.  grs_main sets absolute world targets on every modal
# update and clears them when the modal ends; the draw callback only reads them.
# Absolute values keep a snapshot that was rebuilt mid-drag from moving twice.
_SMART_GIZMO_LIVE_FOLLOW_TARGET = None
_SMART_GIZMO_LIVE_FOLLOW_AXES = None
_SMART_GIZMO_LIVE_FOLLOW_OWNER = None
# World 3x3 linear map (rotation / scale) applied to the absolute axes while the
# owner drags, so the gizmo turns and stretches with the selection.
_SMART_GIZMO_LIVE_FOLLOW_DEFORM = None
# Native transform modal (Move/Rotate/Scale tools, native G/R/S keys) follow.
# The selection reference is refreshed on idle depsgraph updates; the running
# modal only reads it.  ``_SMART_NATIVE_DRAG_ACTIVE`` marks a drag in progress so
# the first update after it ends re-snapshots exactly once.
_SMART_NATIVE_FOLLOW = None
_SMART_NATIVE_DRAG_ACTIVE = False
_SMART_NATIVE_DRAG_REF = None
_SMART_NATIVE_DRAG_SAMPLE_MAX = 24
# Last bone geometry the drag tick measured (skips unchanged event-loop passes).
_SMART_NATIVE_TICK_SIGNATURE = None
# Modes whose native drags send no depsgraph update: the drag tick follows them.
_SMART_NATIVE_TICK_FOLLOW_MODES = frozenset({'EDIT_ARMATURE'})

# Compatibility state for cancelling a navigation snapshot timer left by
# 1.8.164-1.8.167.  The current implementation does not register this timer:
# POST_PIXEL drawing reads the exact RegionView3D matrices for every redraw.
_SMART_GIZMO_NAV_SYNC_STATES = {}
_SMART_GIZMO_NAV_SYNC_INTERVAL = 0.02
_SMART_GIZMO_NAV_SYNC_DURATION = 0.35
# depsgraph_update_post のたびに 1 つ増える数（編集メッシュの中心の貯めが、まだ正しいかの目印）
_SMART_DEPSGRAPH_SERIAL = 0
# 見張りが受けた TIMER 以外のイベントの数。変形のモーダルは、見張りが受けたイベントの後でしか始まらない。
_SMART_WATCH_EVENT_SERIAL = 0
_SMART_EDIT_PIVOT_CACHE_MAX_AGE = 1.0


class _SmartDrawCommand(NamedTuple):
    batch: object
    color: tuple
    line_width: float
    matrix_mode: str = 'WORLD'
    origin: tuple = (0.0, 0.0, 0.0)
    scale: float = 1.0
    # AA_2PASS の淡い外側の線。ビュー操作の間は描画の時に飛ばす（作り直しは要らない）。
    halo: bool = False
    # 頂点ごとの色で作った batch（描く時に色の uniform を設定しない）。
    vertex_color: bool = False
    # まとめる前の形（材料を作る途中だけ使う。batch を作った命令では空）。
    primitive: str = ''
    verts: tuple = ()


class _SmartDrawSnapshot(NamedTuple):
    generation: int
    key: tuple
    view_matrix: tuple
    projection_matrix: tuple
    pivot: tuple
    axes: tuple
    orient_type: str
    reference_world_scale: float
    screen_scale: float
    shader: object
    commands: tuple
    estimated_bytes: int
    built_at: float


# =========================================================
# Gizmo Helper
# =========================================================

def _runtime_pref_enabled(context=None):
    p = cu._prefs(context)
    if not p:
        return False
    try:
        # Persistent runtime admission requires the explicit live switch.
        # Style/visibility flags remain meaningful only inside that enabled
        # branch; retaining them must not resurrect a disabled watcher/msgbus.
        return bool(
            getattr(p, "enable_smart_gizmo_live_runtime", False)
            and
            getattr(p, "enable_smart_gizmo_style", False)
            and getattr(p, "gizmo_toggle_state", True)
        )
    except Exception:
        return False


def _csdt_click_runtime_pref_enabled(context=None) -> bool:
    """Return True when transient click handling may run.

    The individual behavior toggles are feature settings and default to ON, but
    they must not create a window-wide modal watcher by themselves.  The watcher
    is allowed only while the explicit live runtime switch is enabled.
    """
    p = cu._prefs(context)
    if not p:
        return False
    for prop in (
        'enable_move',
        'enable_rotate',
        'enable_scale',
        'enable_transform',
        'use_immediate_select',
        'smart_gizmo_click_select_priority',
        'enable_drag_transform',
        'enable_bg_deselect',
        'enable_bg_drag_select',
    ):
        try:
            if bool(getattr(p, prop, False)):
                return True
        except Exception:
            pass
    return False


def _event_runtime_pref_enabled(context=None) -> bool:
    # The window-level Smart Gizmo watcher is allowed only by the explicit live
    # runtime switch.  Stale modal/drag flags must never resurrect the watcher,
    # because a resurrected global modal operator can receive ordinary Blender UI
    # events and make menus/buttons feel blocked.  Active Smart G-R-S sessions
    # draw their temporary overlay directly via _smart_ensure_draw_handler().
    return bool(_runtime_pref_enabled(context))


def _smart_gizmo_saved_enabled_state(context=None) -> bool:
    """Return True only when the explicit live runtime switch is enabled."""
    return bool(_runtime_pref_enabled(context))


def _ensure_runtime_for_saved_enabled_state(context=None) -> bool:
    # Do not migrate style / overlay booleans into the live-runtime switch during
    # registration.  Automatic migration starts a global modal watcher at add-on
    # install time and can interfere with Blender's own UI event routing.
    return bool(_runtime_pref_enabled(context))


def _smart_gizmo_tool_msgbus_notify() -> None:
    """Defer active-tool reconciliation out of Blender's RNA publish boundary."""
    try:
        if cg._SMART_GIZMO_SHUTDOWN or not _event_runtime_pref_enabled(getattr(bpy, 'context', None)):
            return
        _start_smart_gizmo_guardian()
    except Exception:
        pass


def _install_smart_gizmo_tool_msgbus() -> bool:
    """Subscribe to Blender 5.1's active-tool publication on a fail-soft basis."""
    global _SMART_GIZMO_TOOL_MSGBUS_INSTALLED
    if _SMART_GIZMO_TOOL_MSGBUS_INSTALLED:
        return True
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        workspace_type = getattr(getattr(bpy, 'types', None), 'WorkSpace', None)
        if msgbus is None or workspace_type is None:
            return False
        kwargs = dict(
            key=(workspace_type, 'tools'),
            owner=_SMART_GIZMO_TOOL_MSGBUS_OWNER,
            args=(),
            notify=_smart_gizmo_tool_msgbus_notify,
        )
        try:
            msgbus.subscribe_rna(**kwargs, options={'PERSISTENT'})
        except TypeError:
            msgbus.subscribe_rna(**kwargs)
        _SMART_GIZMO_TOOL_MSGBUS_INSTALLED = True
        return True
    except Exception:
        # Active-tool msgbus is an accelerator, never a Suite registration gate.
        _SMART_GIZMO_TOOL_MSGBUS_INSTALLED = False
        return False


def _remove_smart_gizmo_tool_msgbus() -> bool:
    global _SMART_GIZMO_TOOL_MSGBUS_INSTALLED
    ok = True
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is not None:
            msgbus.clear_by_owner(_SMART_GIZMO_TOOL_MSGBUS_OWNER)
    except Exception:
        ok = False
    _SMART_GIZMO_TOOL_MSGBUS_INSTALLED = False
    return ok


def _smart_gizmo_publish_layer_policy() -> bool:
    """Publish the Suite-owned POST_PIXEL layer without touching Overlay."""
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_SMART_GIZMO_LAYER_POLICY_KEY)
        if registry is None:
            registry = {}
            namespace[_SMART_GIZMO_LAYER_POLICY_KEY] = registry
        elif not isinstance(registry, dict):
            return False
        existing = registry.get(_SMART_GIZMO_LAYER_OWNER)
        if existing is not None:
            if not isinstance(existing, dict) or existing.get('owner') != _SMART_GIZMO_LAYER_OWNER:
                return False
        registry[_SMART_GIZMO_LAYER_OWNER] = {
            'owner': _SMART_GIZMO_LAYER_OWNER,
            'owner_token': _SMART_GIZMO_LAYER_OWNER_TOKEN,
            'space': 'SpaceView3D',
            'region': 'WINDOW',
            'stage': 'POST_PIXEL',
            'layer': 10000,
            'role': 'front_transform_gizmo',
            'draw_callback': '_smart_draw_callback',
            'replay_callback': '_smart_draw_snapshot_replay',
            'view_projection_source': 'live_region_view3d_per_draw',
            'navigation_timer': False,
            'registration_order_independent': True,
            'generation': int(_SMART_GIZMO_SNAPSHOT_GENERATION),
        }
        return True
    except Exception:
        return False
def _smart_gizmo_clear_layer_policy() -> bool:
    """Remove only the exact layer-policy record published by this module."""
    try:
        namespace = bpy.app.driver_namespace
        registry = namespace.get(_SMART_GIZMO_LAYER_POLICY_KEY)
        if not isinstance(registry, dict):
            return True
        record = registry.get(_SMART_GIZMO_LAYER_OWNER)
        if isinstance(record, dict) and record.get('owner_token') is _SMART_GIZMO_LAYER_OWNER_TOKEN:
            registry.pop(_SMART_GIZMO_LAYER_OWNER, None)
        if not registry and namespace.get(_SMART_GIZMO_LAYER_POLICY_KEY) is registry:
            namespace.pop(_SMART_GIZMO_LAYER_POLICY_KEY, None)
        return True
    except Exception:
        return False


def _smart_gizmo_runtime_stable() -> bool:
    """Return True when current windows, watcher set and draw handle agree."""
    try:
        if cg._SMART_GIZMO_SHUTDOWN or not _event_runtime_pref_enabled(getattr(bpy, 'context', None)):
            return not bool(cg._SMART_GIZMO_WATCHERS) and getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None) is None
        targets = _smart_runtime_targets()
        wanted = set(targets.keys())
        current = set(cg._SMART_GIZMO_WATCHERS.keys())
        # A watcher is kept for a live window after leaving the transform tools.
        if not wanted.issubset(current):
            return False
        return (getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None) is not None) == bool(wanted)
    except Exception:
        return False


def _smart_space_pointer(space) -> int:
    try:
        return int(space.as_pointer())
    except Exception:
        return id(space)


def _capture_builtin_tool_gizmo_state(space) -> None:
    """Capture native gizmo switches once before Smart Gizmo changes them."""
    if space is None:
        return
    key = _smart_space_pointer(space)
    if key in _SMART_BUILTIN_GIZMO_STATE_BY_SPACE:
        return
    state = {}
    for attr in _SMART_BUILTIN_TRANSFORM_GIZMO_ATTRS:
        try:
            if hasattr(space, attr):
                state[attr] = bool(getattr(space, attr))
        except Exception:
            pass
    if state:
        _SMART_BUILTIN_GIZMO_STATE_BY_SPACE[key] = state


def _set_builtin_transform_gizmo_visibility(space, visible: bool) -> None:
    """Configure Blender's native gizmos without leaking transform handles.

    ``visible=False`` hides the active native transform-tool gizmo while Smart
    Gizmo draws its replacement.  ``visible=True`` restores only Blender's
    *active tool* gizmo channel.  The independent object Translate/Rotate/Scale
    channels stay disabled while Smart Gizmo runtime is active; otherwise those
    channels make a standard transform gizmo remain visible even when the Select
    tool is active.

    The exact pre-runtime values are saved separately and restored by
    :func:`_restore_builtin_tool_gizmos`.
    """
    if space is None:
        return
    _capture_builtin_tool_gizmo_state(space)
    try:
        if hasattr(space, 'show_gizmo_tool'):
            requested = bool(visible)
            if bool(getattr(space, 'show_gizmo_tool')) != requested:
                space.show_gizmo_tool = requested
    except Exception:
        pass
    for attr in (
        'show_gizmo_object_translate',
        'show_gizmo_object_rotate',
        'show_gizmo_object_scale',
    ):
        try:
            if hasattr(space, attr) and bool(getattr(space, attr)):
                setattr(space, attr, False)
        except Exception:
            pass


def _discard_builtin_tool_gizmo_snapshots() -> None:
    try:
        _SMART_BUILTIN_GIZMO_STATE_BY_SPACE.clear()
    except Exception:
        pass


def _restore_builtin_tool_gizmos(context=None):
    """Restore the exact native gizmo state that existed before runtime."""
    try:
        ctx0 = context or bpy.context
        wm = getattr(ctx0, "window_manager", None)
        restored = set()
        if wm:
            for win in wm.windows:
                scr = getattr(win, "screen", None)
                if not scr:
                    continue
                for area in scr.areas:
                    if area.type != 'VIEW_3D':
                        continue
                    try:
                        space = area.spaces.active
                    except Exception:
                        space = None
                    if not space or getattr(space, 'type', None) != 'VIEW_3D':
                        continue
                    key = _smart_space_pointer(space)
                    state = _SMART_BUILTIN_GIZMO_STATE_BY_SPACE.get(key)
                    if not state:
                        continue
                    for attr, value in state.items():
                        try:
                            if hasattr(space, attr):
                                setattr(space, attr, bool(value))
                        except Exception:
                            pass
                    restored.add(key)
        # A screen/workspace may have been replaced while the runtime was active.
        # Stale RNA pointers must never be reused for a later SpaceView3D.
        _discard_builtin_tool_gizmo_snapshots()
        if restored:
            try:
                cu._tag_view3d_redraw()
            except Exception:
                pass
    except Exception:
        _discard_builtin_tool_gizmo_snapshots()


def start_runtime(context=None):
    global _SMART_GIZMO_SNAPSHOT_GENERATION
    if not _event_runtime_pref_enabled(context):
        try:
            stop_runtime(restore_builtin=True)
        except Exception:
            pass
        return
    was_shutdown = bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True))
    cg._SMART_GIZMO_SHUTDOWN = False
    if was_shutdown:
        try:
            _stop_smart_gizmo_navigation_sync()
        except Exception:
            pass
        _SMART_GIZMO_SNAPSHOT_GENERATION += 1
        _smart_draw_snapshot_clear()
    _smart_gizmo_publish_layer_policy()
    try:
        cu._neutralize_legacy_constraint_watchdogs()
    except Exception:
        pass
    try:
        _install_smart_gizmo_tool_msgbus()
    except Exception:
        pass
    try:
        _smart_check_tool_and_update_visibility(context or bpy.context)
    except Exception:
        pass
    try:
        # Reconcile once now.  Later tool changes arrive through WorkSpace.tools
        # msgbus or real watcher events, so no idle polling timer is required.
        _ensure_smart_gizmo_watchers()
    except Exception:
        pass
    try:
        _start_smart_gizmo_guardian()
    except Exception:
        pass
    try:
        _ensure_gizmo_load_post_handler()
    except Exception:
        pass
    try:
        _ensure_native_transform_follow_handler()
    except Exception:
        pass
    try:
        _schedule_startup_visibility_repair()
    except Exception:
        pass

def _cancel_startup_reconcile_timers() -> None:
    """Synchronously retire only this generation's bounded startup callbacks."""
    global _SMART_GIZMO_STARTUP_REPAIR_RUNNING
    global _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING
    global _SMART_GIZMO_STARTUP_REPAIR_TIMER
    global _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER

    callbacks = (
        _SMART_GIZMO_STARTUP_REPAIR_TIMER,
        _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER,
    )
    # Fence stale callbacks before asking Blender to unregister them.  A callback
    # already dispatched by the event loop will see the identity mismatch and
    # return without touching the replacement generation.
    _SMART_GIZMO_STARTUP_REPAIR_TIMER = None
    _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER = None
    _SMART_GIZMO_STARTUP_REPAIR_RUNNING = False
    _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING = False
    for callback in callbacks:
        if callback is None:
            continue
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except Exception:
            pass


def stop_runtime(restore_builtin: bool = True):
    _cancel_startup_reconcile_timers()
    cg._SMART_GIZMO_SHUTDOWN = True
    _remove_native_transform_follow_handler()
    try:
        cg._SMART_GIZMO_VIEW_NAV_ACTIVE = False
        cg._SMART_GIZMO_VIEW_NAV_UNTIL = 0.0
    except Exception:
        pass
    try:
        _stop_smart_gizmo_guardian()
    except Exception:
        pass
    try:
        _stop_smart_gizmo_navigation_sync()
    except Exception:
        pass
    # ビュー操作の後の描き直しと、先読みの遅らせの時計も止める（無効にした後に残さない）。
    global _SMART_PREFETCH_REST_REQUEST
    _SMART_PREFETCH_REST_REQUEST = None
    for _callback in (_smart_gizmo_nav_settle_tick, _smart_prefetch_rest_tick):
        try:
            if bpy.app.timers.is_registered(_callback):
                bpy.app.timers.unregister(_callback)
        except Exception:
            pass
    try:
        _remove_smart_gizmo_tool_msgbus()
    except Exception:
        pass
    try:
        _smart_gizmo_clear_layer_policy()
    except Exception:
        pass
    try:
        _smart_draw_snapshot_clear()
    except Exception:
        pass
    try:
        # Compatibility cleanup for a timer left by pre-1.8.163 builds.
        if bpy.app.timers.is_registered(_ensure_smart_gizmo_watchers):
            bpy.app.timers.unregister(_ensure_smart_gizmo_watchers)
    except Exception:
        pass
    _smart_remove_draw_handler()
    # Keep the load_post bootstrap handler installed while the add-on is enabled.
    # Toggling the Smart Gizmo runtime off must not remove the handler that repairs
    # Blender startup/file-load ordering on the next load. unregister() removes it.
    for _w in list(cg._SMART_GIZMO_WATCHERS.values()):
        try:
            _w.cancel(bpy.context)
        except Exception:
            pass
    cg._SMART_GIZMO_WATCHERS.clear()
    cg._SMART_GIZMO_WATCHER_HEARTBEAT.clear()
    smart_gizmo_live_follow_reset()
    cg._SMART_GIZMO_HOVER_ID = None
    cg._SMART_GIZMO_LOCKED_ID = None
    cg._SMART_GIZMO_LAST_GOOD_GEO = None
    cg._SMART_GIZMO_LAST_GOOD_TIME = 0.0
    cg._CSDT_DRAG_ACTIVE_ID = None
    cg._CSDT_IS_DRAGGING = False
    try:
        cg._SMART_GIZMO_MODAL_OVERRIDE_MODE = None
    except Exception:
        pass
    if restore_builtin:
        _restore_builtin_tool_gizmos(bpy.context)
    else:
        # load_post replaces SpaceView3D RNA instances; old pointer snapshots
        # are invalid and must not be applied to the newly loaded workspace.
        _discard_builtin_tool_gizmo_snapshots()


def sync_runtime_from_prefs(context=None):
    if _event_runtime_pref_enabled(context):
        start_runtime(context)
    else:
        stop_runtime(restore_builtin=True)




@persistent
def _gizmo_draw_order_boundary_post(_dummy=None) -> None:
    """Recheck same-stage ordering once after save/undo/redo boundaries."""
    try:
        if not cg._SMART_GIZMO_SHUTDOWN and _event_runtime_pref_enabled(getattr(bpy, 'context', None)):
            _start_smart_gizmo_guardian()
    except Exception:
        pass


def _ensure_gizmo_draw_order_boundary_handlers() -> None:
    for handler_name in ('save_post', 'undo_post', 'redo_post'):
        try:
            handlers = getattr(bpy.app.handlers, handler_name, None)
            if handlers is not None and _gizmo_draw_order_boundary_post not in handlers:
                handlers.append(_gizmo_draw_order_boundary_post)
        except Exception:
            pass


def _remove_gizmo_draw_order_boundary_handlers() -> None:
    for handler_name in ('save_post', 'undo_post', 'redo_post'):
        try:
            handlers = getattr(bpy.app.handlers, handler_name, None)
            if handlers is not None and _gizmo_draw_order_boundary_post in handlers:
                handlers.remove(_gizmo_draw_order_boundary_post)
        except Exception:
            pass


def _ensure_gizmo_load_post_handler() -> None:
    try:
        handlers = bpy.app.handlers.load_post
        for fn in list(handlers):
            try:
                if getattr(fn, '__name__', '') == '_gizmo_on_load_post' and fn is not _gizmo_on_load_post:
                    handlers.remove(fn)
            except Exception:
                pass
        _load_hooks.add(_gizmo_on_load_post)
        _ensure_gizmo_draw_order_boundary_handlers()
    except Exception:
        pass


def _remove_gizmo_load_post_handler() -> None:
    _remove_gizmo_draw_order_boundary_handlers()
    _load_hooks.remove(_gizmo_on_load_post)
    try:
        handlers = bpy.app.handlers.load_post
        for fn in list(handlers):
            try:
                if fn is _gizmo_on_load_post or getattr(fn, '__name__', '') == '_gizmo_on_load_post':
                    handlers.remove(fn)
            except Exception:
                pass
    except Exception:
        pass


def _schedule_startup_runtime_bootstrap(retries: int = 32, interval: float = 0.25) -> None:
    """Bounded startup-only reconciliation while Blender restores UI state."""
    global _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING
    global _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER
    existing = _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER
    if existing is not None:
        try:
            if bpy.app.timers.is_registered(existing):
                return
        except Exception:
            return
        _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER = None
        _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING = False
    _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING = True
    state = {'remaining': max(1, int(retries)), 'stable': 0}

    def _finish():
        global _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING
        global _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER
        if _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER is _tick:
            _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER = None
            _SMART_GIZMO_STARTUP_BOOTSTRAP_RUNNING = False
        return None

    def _tick():
        if _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER is not _tick:
            return None
        if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', False)):
            return _finish()
        try:
            ctx = getattr(bpy, 'context', None)
            runtime_on = bool(_event_runtime_pref_enabled(ctx))
        except Exception:
            runtime_on = False

        if runtime_on:
            try:
                if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', False)):
                    start_runtime(ctx)
                else:
                    _smart_gizmo_guardian_tick()
            except Exception:
                pass
            if _smart_gizmo_runtime_stable():
                state['stable'] += 1
                if state['stable'] >= 3:
                    return _finish()
            else:
                state['stable'] = 0

        state['remaining'] -= 1
        if state['remaining'] <= 0:
            return _finish()
        return float(interval)

    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER = _tick
            timers.register(_tick, first_interval=0.0)
            return
    except Exception:
        pass
    try:
        _SMART_GIZMO_STARTUP_BOOTSTRAP_TIMER = _tick
        _tick()
    except Exception:
        pass
    finally:
        _finish()



def _start_smart_gizmo_guardian():
    """Schedule one finite runtime reconcile; never create an idle loop."""
    try:
        if not bpy.app.timers.is_registered(_smart_gizmo_guardian_tick):
            bpy.app.timers.register(_smart_gizmo_guardian_tick, first_interval=0.01)
    except Exception:
        try:
            _smart_gizmo_guardian_tick()
        except Exception:
            pass


def _stop_smart_gizmo_guardian():
    try:
        if bpy.app.timers.is_registered(_smart_gizmo_guardian_tick):
            bpy.app.timers.unregister(_smart_gizmo_guardian_tick)
    except Exception:
        pass
    try:
        cg._SMART_GIZMO_GUARDIAN_ACTIVE = False
    except Exception:
        pass


def _smart_gizmo_guardian_tick():
    """Reconcile draw/watcher/visibility state once after a real event."""
    try:
        if cg._SMART_GIZMO_SHUTDOWN or not _event_runtime_pref_enabled(getattr(bpy, 'context', None)):
            return None
        cg._SMART_GIZMO_GUARDIAN_ACTIVE = True
        targets = _smart_runtime_targets() if _smart_enabled() else {}
        if targets:
            handler_missing = getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None) is None
            repaired_stale_handler = False
            repaired_draw_order = False
            if handler_missing:
                _smart_ensure_draw_handler()
            else:
                repaired_stale_handler = _smart_repair_draw_handler_if_stale()
                if not repaired_stale_handler:
                    repaired_draw_order = _smart_repair_draw_order_after_smart_overlay_if_needed()
            try:
                _ensure_smart_gizmo_watchers()
            except Exception:
                pass
            try:
                _smart_check_tool_and_update_visibility(getattr(bpy, 'context', None))
            except Exception:
                pass
            if handler_missing or repaired_stale_handler or repaired_draw_order:
                try:
                    cu._tag_view3d_redraw()
                except Exception:
                    pass
        else:
            try:
                if getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None) is not None:
                    _smart_remove_draw_handler()
            except Exception:
                pass
            try:
                _ensure_smart_gizmo_watchers()
            except Exception:
                pass
            try:
                _smart_check_tool_and_update_visibility(getattr(bpy, 'context', None))
            except Exception:
                pass
    except Exception:
        pass
    finally:
        try:
            cg._SMART_GIZMO_GUARDIAN_ACTIVE = False
        except Exception:
            pass
    return None


def _schedule_startup_visibility_repair(retries: int = 48, interval: float = 0.25):
    """Bounded startup repair that stops immediately after state convergence."""
    global _SMART_GIZMO_STARTUP_REPAIR_RUNNING
    global _SMART_GIZMO_STARTUP_REPAIR_TIMER
    existing = _SMART_GIZMO_STARTUP_REPAIR_TIMER
    if existing is not None:
        try:
            if bpy.app.timers.is_registered(existing):
                return
        except Exception:
            return
        _SMART_GIZMO_STARTUP_REPAIR_TIMER = None
        _SMART_GIZMO_STARTUP_REPAIR_RUNNING = False
    _SMART_GIZMO_STARTUP_REPAIR_RUNNING = True
    state = {'remaining': max(1, int(retries)), 'stable': 0}

    def _finish():
        global _SMART_GIZMO_STARTUP_REPAIR_RUNNING
        global _SMART_GIZMO_STARTUP_REPAIR_TIMER
        if _SMART_GIZMO_STARTUP_REPAIR_TIMER is _tick:
            _SMART_GIZMO_STARTUP_REPAIR_TIMER = None
            _SMART_GIZMO_STARTUP_REPAIR_RUNNING = False
        return None

    def _tick():
        if _SMART_GIZMO_STARTUP_REPAIR_TIMER is not _tick:
            return None
        if cg._SMART_GIZMO_SHUTDOWN or not _event_runtime_pref_enabled(getattr(bpy, 'context', None)):
            return _finish()
        try:
            _smart_gizmo_guardian_tick()
        except Exception:
            pass
        if _smart_gizmo_runtime_stable():
            state['stable'] += 1
            if state['stable'] >= 3:
                return _finish()
        else:
            state['stable'] = 0
        state['remaining'] -= 1
        return float(interval) if state['remaining'] > 0 else _finish()

    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            _SMART_GIZMO_STARTUP_REPAIR_TIMER = _tick
            timers.register(_tick, first_interval=0.05)
            return
    except Exception:
        pass
    try:
        _SMART_GIZMO_STARTUP_REPAIR_TIMER = _tick
        _tick()
    except Exception:
        pass
    finally:
        _finish()


def _smart_runtime_activity_active() -> bool:
    try:
        if bool(getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_ACTIVE', False)):
            return True
        if bool(getattr(cg, '_SMART_GIZMO_FREEZE_ACTIVE', False)):
            return True
        if bool(getattr(cg, '_CSDT_IS_DRAGGING', False)):
            return True
        if bool(getattr(cg, '_CSDT_DRAG_ACTIVE_ID', None)):
            return True
        if getattr(cg, '_SMART_GIZMO_LOCKED_ID', None) is not None:
            return True
    except Exception:
        pass
    return False


def _smart_iter_view3d_slots(win):
    """Yield every physical View3D WINDOW region for one Blender window."""
    try:
        screen = getattr(win, 'screen', None)
        if screen is None:
            return
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            for region in tuple(getattr(area, 'regions', ()) or ()):
                if getattr(region, 'type', None) == 'WINDOW':
                    yield area, region
    except Exception:
        return


def _smart_first_view3d_slot(win):
    try:
        return next(iter(_smart_iter_view3d_slots(win)), (None, None))
    except Exception:
        return None, None


def _smart_runtime_slot_for_window(win, context=None):
    """Return the first supported transform-tool slot in a window.

    The modal watcher is window-owned, but eligibility must not depend on the
    first View3D area.  This covers split layouts and Quad View without sharing
    RegionView3D state between panes.
    """
    for area, region in _smart_iter_view3d_slots(win):
        try:
            if _smart_tool_kind_for_view(context or getattr(bpy, 'context', None), win, area, region):
                return area, region
        except Exception:
            continue
    return None, None


def _smart_window_wants_runtime(win):
    if not _smart_enabled():
        return False
    area, region = _smart_runtime_slot_for_window(win, getattr(bpy, 'context', None))
    return bool(area is not None and region is not None)


def _smart_runtime_targets():
    wm = getattr(bpy.context, 'window_manager', None)
    targets = {}
    if not wm:
        return targets
    for win in tuple(getattr(wm, 'windows', ()) or ()):
        area, region = _smart_runtime_slot_for_window(win, getattr(bpy, 'context', None))
        if area is None or region is None:
            continue
        try:
            wptr = int(win.as_pointer())
        except Exception:
            wptr = id(win)
        targets[wptr] = (win, area, region)
    return targets



def _smart_tool_kind_for_view(context, win, area, region):
    """Return Smart Gizmo tool kind for a specific 3D View context.

    Startup/draw/timer callbacks often run with a generic bpy.context.  Resolve
    the active tool in a full per-window/per-area override so the custom Smart
    Gizmo can hide Blender's standard transform gizmo immediately after startup.
    """
    try:
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return None
        if region is None or getattr(region, 'type', None) != 'WINDOW':
            return None
        if hasattr(bpy.context, 'temp_override'):
            kwargs = {'area': area, 'region': region}
            if win is not None:
                kwargs['window'] = win
                try:
                    scr = getattr(win, 'screen', None)
                    if scr is not None:
                        kwargs['screen'] = scr
                except Exception:
                    pass
                try:
                    ws = getattr(win, 'workspace', None)
                    if ws is not None:
                        kwargs['workspace'] = ws
                except Exception:
                    pass
            try:
                scn = getattr(context, 'scene', None) if context is not None else getattr(bpy.context, 'scene', None)
                if scn is not None:
                    kwargs['scene'] = scn
            except Exception:
                pass
            try:
                space = area.spaces.active
                kwargs['space_data'] = space
                rv3d = cu._view3d_region_data(area, region)
                if rv3d is not None:
                    kwargs['region_data'] = rv3d
            except Exception:
                pass
            with bpy.context.temp_override(**kwargs):
                return _smart_tool_kind(bpy.context)
    except Exception:
        pass
    try:
        return _smart_tool_kind(context or bpy.context)
    except Exception:
        return None

def _smart_any_supported_view3d_tool_active(context=None) -> bool:
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        if not wm:
            return False
        for win in tuple(getattr(wm, 'windows', ()) or ()):
            area, region = _smart_runtime_slot_for_window(win, context or bpy.context)
            if area is not None and region is not None:
                return True
    except Exception:
        pass
    return False



def _smart_overlay_view3d_draw_marker() -> tuple:
    """Return exact Smart Overlay View3D handler tokens without module scans."""
    try:
        prefix = ''
        package_name = str(__package__ or '')
        marker = '.smart_transform_suite'
        if marker in package_name:
            prefix = package_name.split(marker, 1)[0]
        candidates = [
            ('smart_overlay_suite.mesh', 'mesh', '_draw_handler'),
            ('smart_overlay_suite.properties', 'proportional', '_draw_handler_prop'),
        ]
        if prefix:
            candidates.extend((
                (f'{prefix}.smart_overlay_suite.mesh', 'mesh', '_draw_handler'),
                (f'{prefix}.smart_overlay_suite.properties', 'proportional', '_draw_handler_prop'),
            ))
        markers = []
        seen_modules = set()
        for module_name, role, attr in candidates:
            module = sys.modules.get(module_name)
            if module is None or id(module) in seen_modules:
                continue
            seen_modules.add(id(module))
            try:
                handle = getattr(module, attr, None)
            except Exception:
                handle = None
            if handle is not None:
                markers.append((role, attr, id(handle)))
        return tuple(sorted(set(markers)))
    except Exception:
        return ()


def _smart_note_current_overlay_draw_marker() -> None:
    global _SMART_GIZMO_LAST_SMART_OVERLAY_DRAW_MARKER
    try:
        _SMART_GIZMO_LAST_SMART_OVERLAY_DRAW_MARKER = _smart_overlay_view3d_draw_marker()
    except Exception:
        _SMART_GIZMO_LAST_SMART_OVERLAY_DRAW_MARKER = None


def _smart_add_draw_handler(draw_stage: str = "POST_PIXEL") -> bool:
    """Register the Smart Gizmo in the front-most POST_PIXEL stage."""
    if str(draw_stage or 'POST_PIXEL') != 'POST_PIXEL':
        draw_stage = 'POST_PIXEL'
    try:
        cg._SMART_GIZMO_DRAW_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            _smart_draw_callback, (), "WINDOW", "POST_PIXEL"
        )
        cg._SMART_GIZMO_DRAW_STAGE = 'POST_PIXEL'
        cg._SMART_GIZMO_DRAW_HANDLE_REGISTERED_AT = time.perf_counter()
        cg._SMART_GIZMO_LAST_DRAW_AT = 0.0
        _smart_gizmo_publish_layer_policy()
        return True
    except Exception:
        cg._SMART_GIZMO_DRAW_HANDLE = None
    return False



def _smart_repair_draw_order_after_smart_overlay_if_needed(*, force: bool = False) -> bool:
    """Ensure POST_PIXEL ownership; Overlay POST_VIEW order needs no scanning."""
    del force
    try:
        handle = getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None)
        if handle is None:
            _smart_gizmo_publish_layer_policy()
            return False
        if str(getattr(cg, '_SMART_GIZMO_DRAW_STAGE', '') or '') == 'POST_PIXEL':
            _smart_gizmo_publish_layer_policy()
            return False
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        except Exception:
            pass
        cg._SMART_GIZMO_DRAW_HANDLE = None
        repaired = bool(_smart_add_draw_handler('POST_PIXEL'))
        if repaired:
            try:
                cu._tag_view3d_redraw()
            except Exception:
                pass
        return repaired
    except Exception:
        return False



def _smart_draw_handler_stale(now=None) -> bool:
    try:
        if getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None) is None:
            return True
        now = time.perf_counter() if now is None else float(now)
        registered_at = float(getattr(cg, '_SMART_GIZMO_DRAW_HANDLE_REGISTERED_AT', 0.0) or 0.0)
        last_draw_at = float(getattr(cg, '_SMART_GIZMO_LAST_DRAW_AT', 0.0) or 0.0)
        last_repair_at = float(getattr(cg, '_SMART_GIZMO_DRAW_HANDLER_REPAIR_AT', 0.0) or 0.0)
        if not registered_at:
            return True
        if (now - last_repair_at) < 2.0:
            return False
        if not _smart_any_supported_view3d_tool_active(getattr(bpy, 'context', None)):
            return False
        # A quiet viewport legitimately produces no draw callback.  Time-based
        # stale detection is meaningful only during active transform/navigation
        # work; missing handles and load/startup recovery remain unconditional.
        if not _smart_runtime_activity_active():
            return False
        if (now - registered_at) > 1.25 and last_draw_at < registered_at:
            return True
        if (now - registered_at) > 2.50 and last_draw_at and (now - last_draw_at) > 3.0:
            return True
    except Exception:
        return False
    return False


def _smart_repair_draw_handler_if_stale() -> bool:
    try:
        now = time.perf_counter()
        if not _smart_draw_handler_stale(now):
            return False
        cg._SMART_GIZMO_DRAW_HANDLER_REPAIR_AT = now
        _smart_remove_draw_handler()
        _smart_ensure_draw_handler()
        return True
    except Exception:
        return False

def _smart_enabled():
    p = cu._prefs()
    if not p: return False
    return _runtime_pref_enabled() and getattr(p, "enable_smart_gizmo_style", False) and getattr(p, "gizmo_toggle_state", True)


def _smart_cache_ttl(context=None):
    try:
        if bool(getattr(cg, '_CSDT_IS_DRAGGING', False)) or bool(getattr(cg, '_CSDT_DRAG_ACTIVE_ID', None)):
            return 0.0
    except Exception:
        pass
    try:
        if _smart_gizmo_view_navigation_active():
            return 0.25
    except Exception:
        pass
    mode = str(getattr(context, 'mode', '') or '')
    if mode in {'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE', 'EDIT_ARMATURE', 'POSE'}:
        # Edit mode pivot calculation can scan selected BMesh/Lattice data.  Keep
        # this slightly coarser than draw refresh so dense selections do not force
        # repeated full pivot scans while the user continues working.
        return 1.0 / 20.0
    return 1.0 / 90.0


def _smart_lattice_point_selected(point) -> bool:
    try:
        if bool(getattr(point, 'select', False)):
            return True
    except Exception:
        pass
    for _attr in ('select_u', 'select_v', 'select_w'):
        try:
            if bool(getattr(point, _attr, False)):
                return True
        except Exception:
            pass
    return False


def _smart_curve_component_items(obj, selected_only=True):
    """Return editable curve/surface control components as (key, local_co, selected).

    The structure mirrors Smart G-R-S' curve storage path but is kept local to
    the Smart Gizmo module to avoid import cycles.  Bezier control points and
    handles are independent transform targets; Poly/NURBS points use their xyz
    part while preserving the stored w value elsewhere in Smart G-R-S.
    """
    items = []
    try:
        splines = getattr(getattr(obj, 'data', None), 'splines', []) or []
    except Exception:
        splines = []
    for si, spline in enumerate(splines):
        try:
            for pi, bp in enumerate(getattr(spline, 'bezier_points', []) or []):
                candidates = (
                    ('co', 'select_control_point'),
                    ('handle_left', 'select_left_handle'),
                    ('handle_right', 'select_right_handle'),
                )
                for attr, sel_attr in candidates:
                    try:
                        selected = bool(getattr(bp, sel_attr, False))
                        if selected or not selected_only:
                            co = Vector(getattr(bp, attr)).copy()
                            items.append((('BEZIER', int(si), int(pi), attr), co, selected))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            for pi, point in enumerate(getattr(spline, 'points', []) or []):
                try:
                    selected = bool(getattr(point, 'select', False))
                    if selected or not selected_only:
                        co4 = getattr(point, 'co')
                        co = Vector((float(co4.x), float(co4.y), float(co4.z)))
                        items.append((('POINT', int(si), int(pi), 'co'), co, selected))
                except Exception:
                    pass
        except Exception:
            pass
    return items


def _smart_curve_has_selection(context, obj) -> bool:
    try:
        objs = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', []) or [obj])
    except Exception:
        objs = [obj]
    for o in objs:
        if not o or getattr(o, 'type', None) not in {'CURVE', 'SURFACE'}:
            continue
        try:
            if any(bool(sel) for _key, _co, sel in _smart_curve_component_items(o, selected_only=False)):
                return True
        except Exception:
            continue
    return False


def _smart_curve_selected_points_world(context):
    points = []
    try:
        objs = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', []) or [getattr(context, 'active_object', None)])
    except Exception:
        objs = [getattr(context, 'active_object', None)]
    for obj in objs:
        if not obj or getattr(obj, 'type', None) not in {'CURVE', 'SURFACE'}:
            continue
        try:
            mat = obj.matrix_world
            for _key, co, selected in _smart_curve_component_items(obj, selected_only=True):
                if selected:
                    points.append(mat @ co)
        except Exception:
            continue
    return points


def _smart_tool_kind(context):
    try:
        if bool(getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_ACTIVE', False)):
            kind_override = str(getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_KIND', '') or '')
            if kind_override in {'MOVE', 'ROTATE', 'SCALE', 'TRANSFORM'}:
                return kind_override
    except Exception:
        pass

    # The toolbar exposes transform tools in more modes than the custom target
    # resolver currently implements. Keep Blender's native gizmo in those modes
    # until their selected-data and operator paths are implemented together.
    mode = str(getattr(context, 'mode', '') or '')
    if mode not in {'OBJECT', 'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE', 'EDIT_ARMATURE', 'POSE'}:
        return None

    tid = cu._active_tool_id(context)
    p = cu._prefs()
    if not p:
        return None

    if tid == "builtin.move":
        if not getattr(p, "enable_move", True):
            return None
        return "MOVE"

    if tid == "builtin.rotate":
        if not getattr(p, "enable_rotate", True):
            return None
        if not getattr(p, "enable_smart_gizmo_rotate", True):
            return None
        return "ROTATE"

    if tid == "builtin.scale":
        if not getattr(p, "enable_scale", True):
            return None
        if not getattr(p, "enable_smart_gizmo_scale", True):
            return None
        return "SCALE"

    if tid == "builtin.transform":
        if not getattr(p, "enable_transform", True):
            return None
        if not getattr(p, "enable_smart_gizmo_transform", True):
            return None
        return "TRANSFORM"

    return None

def _smart_get_orient_type(context):
    try:
        slot = context.scene.transform_orientation_slots[0]
        o = str(getattr(slot, "type", "GLOBAL") or "GLOBAL")
        # Blender may expose custom orientations as CUSTOM while the actual
        # matrix/name is stored on slot.custom_orientation.  Preserve the matrix
        # path in _smart_get_orientation_matrix, but use the custom name when it
        # is available so Smart G-R-S HUD/state remains meaningful.
        if o == 'CUSTOM':
            try:
                custom = getattr(slot, 'custom_orientation', None)
                name = str(getattr(custom, 'name', '') or '') if custom is not None else ''
                return name or 'CUSTOM'
            except Exception:
                return 'CUSTOM'
        return o if o else "GLOBAL"
    except Exception:
        return "GLOBAL"

def _smart_view_basis_matrix_from_rv3d(rv3d):
    """Return the current View/WorkPlane basis from RegionView3D.

    Blender's VIEW orientation is the world-space camera basis represented by
    ``RegionView3D.view_rotation``.  In an ordinary single View3D this matrix is
    identical to the rotational part of ``view_matrix.inverted()``.  Blender
    5.1 Quad View, however, can expose a stale/shared ``view_matrix`` for all
    four RegionView3D instances while each pane's ``view_rotation`` is correct.
    Prefer the per-pane quaternion so Smart Gizmo never borrows another pane's
    VIEW axes; keep the inverse-view-matrix path only as a compatibility fallback.
    """
    if rv3d is None:
        return None
    try:
        q = getattr(rv3d, 'view_rotation', None)
        if q is not None:
            mat = q.to_matrix()
            mat = mat.to_3x3() if hasattr(mat, 'to_3x3') else mat
            try:
                mat = mat.normalized()
            except Exception:
                pass
            if abs(float(mat.determinant())) > 1.0e-12:
                return mat
    except Exception:
        pass
    try:
        mat = rv3d.view_matrix.to_3x3().inverted().normalized()
        if abs(float(mat.determinant())) > 1.0e-12:
            return mat
    except Exception:
        try:
            mat = rv3d.view_matrix.to_3x3().inverted()
            if abs(float(mat.determinant())) > 1.0e-12:
                return mat
        except Exception:
            pass
    return None


def _smart_pose_gimbal_basis(context, obj):
    """Match gimbal_axis_pose in Blender 5.1.2 transform_orientations.cc.

    Its Euler axes are intentionally not necessarily orthogonal.  Quaternion
    rotation has no gimbal basis and falls through to native PARENT in Pose.
    """
    if obj is None or str(getattr(context, 'mode', '') or '') != 'POSE':
        return None
    try:
        active_data = obj.data.bones.active
        bone = obj.pose.bones.get(active_data.name) if active_data else None
        if bone is None or not _smart_armature_bone_visible('POSE', bone, active_data):
            return None
        order = str(bone.rotation_mode)
        if order in {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'}:
            angles = tuple(float(v) for v in bone.rotation_euler)
            first = Euler(angles, order).to_matrix()
            second_angles = list(angles)
            second_angles['XYZ'.index(order[0])] = 0.0
            second = Euler(second_angles, order).to_matrix()
            axes = [None, None, None]
            axes['XYZ'.index(order[0])] = first.col['XYZ'.index(order[0])].copy()
            axes['XYZ'.index(order[1])] = second.col['XYZ'.index(order[1])].copy()
            axes['XYZ'.index(order[2])] = Vector(tuple(1.0 if i == 'XYZ'.index(order[2]) else 0.0 for i in range(3)))
        elif order == 'AXIS_ANGLE':
            angle, x, y, z = (float(v) for v in bone.rotation_axis_angle)
            axis = Vector((x, y, z))
            if axis.length_squared <= 1.0e-12:
                return None
            axis.normalize()
            cross_vec = Vector((axis.y, axis.z, axis.x))
            first_axis = cross_vec.cross(axis)
            if first_axis.length_squared <= 1.0e-12:
                return None
            first_axis.normalize()
            first_axis = Quaternion(axis, angle) @ first_axis
            axes = (first_axis, Quaternion(axis, math.pi / 2.0) @ first_axis, axis)
        else:
            # Native gimbal_axis_pose returns false for QUATERNION.  Its
            # orientation switch falls through to PARENT, not a fake GIMBAL.
            return None
        gimbal = Matrix(tuple(tuple(axes[col][row] for col in range(3)) for row in range(3)))
        # Bone.matrix is bone_mat (rest relative to its parent).  Using
        # matrix_local here would include ancestor rest rotation twice when
        # the parent pose/hinge matrix is multiplied below.
        rest = active_data.matrix.to_3x3()
        parent = bone.parent
        if parent is not None:
            parent_basis = (parent.bone.matrix_local if not active_data.use_inherit_rotation else parent.matrix).to_3x3()
        else:
            parent_basis = Matrix.Identity(3)
        composed = obj.matrix_world.to_3x3() @ parent_basis @ rest @ gimbal
        for index in range(3):
            column = Vector(composed.col[index])
            if column.length_squared <= 1.0e-12:
                return None
            composed.col[index] = column.normalized()
        return composed
    except (ReferenceError, RuntimeError, AttributeError, ValueError, TypeError):
        return None


def _smart_armature_bone_visible(mode, bone, data_bone=None):
    """Use EditBone/PoseBone visibility; Bone supplies Pose permissions only."""
    try:
        if mode == 'EDIT_ARMATURE':
            if bool(bone.hide) or bool(bone.hide_select):
                return False
            collection_bone = bone
        elif mode == 'POSE':
            if data_bone is None or bool(bone.hide) or bool(data_bone.hide_select):
                return False
            collection_bone = data_bone
        else:
            return False
        collections = tuple(collection_bone.collections)
        return not collections or any(bool(collection.is_visible_effectively) for collection in collections)
    except (ReferenceError, RuntimeError, AttributeError):
        return False


def _smart_pose_local_rotation_axis_mask(context, orient_type):
    """Return immutable XYZ rotation eligibility for the reviewed Pose slice."""
    unrestricted = (True, True, True)
    try:
        if str(getattr(context, 'mode', '') or '') != 'POSE' or str(orient_type or '') != 'LOCAL':
            return unrestricted
        active_obj = getattr(context, 'active_object', None)
        objects = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or [])
        if active_obj is not None and active_obj not in objects:
            objects.insert(0, active_obj)
        selected = []
        for obj in objects:
            if (obj is None
                    or getattr(obj, 'type', None) != 'ARMATURE'
                    or str(getattr(obj, 'mode', '') or '') != 'POSE'):
                continue
            for bone in obj.pose.bones:
                data_bone = getattr(bone, 'bone', None)
                if (data_bone is not None
                        and _smart_armature_bone_visible('POSE', bone, data_bone)
                        and bool(getattr(bone, 'select', False))):
                    selected.append(bone)
        if len(selected) != 1:
            return unrestricted
        bone = selected[0]
        if (getattr(bone, 'parent', None) is not None
                or bool(tuple(getattr(bone, 'children', ()) or ()))
                or str(getattr(bone, 'rotation_mode', '') or '') != 'XYZ'):
            return unrestricted
        locked = tuple(bool(value) for value in getattr(bone, 'lock_rotation', (False, False, False)))
        if len(locked) != 3:
            return unrestricted
        return tuple(not value for value in locked)
    except (ReferenceError, RuntimeError, AttributeError, TypeError):
        return unrestricted


def _smart_pose_local_native_display_basis(context, obj):
    """Return Blender's standalone Pose LOCAL display basis for nonuniform scale."""
    try:
        if (str(getattr(context, 'mode', '') or '') != 'POSE'
                or obj is None
                or obj is not getattr(context, 'active_object', None)
                or getattr(obj, 'type', None) != 'ARMATURE'
                or str(getattr(obj, 'mode', '') or '') != 'POSE'):
            return None
        objects = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or [])
        if obj not in objects:
            objects.insert(0, obj)
        selected = []
        for owner in objects:
            if (owner is None
                    or getattr(owner, 'type', None) != 'ARMATURE'
                    or str(getattr(owner, 'mode', '') or '') != 'POSE'):
                continue
            for pose_bone in owner.pose.bones:
                data_bone = getattr(pose_bone, 'bone', None)
                if (data_bone is not None
                        and _smart_armature_bone_visible('POSE', pose_bone, data_bone)
                        and bool(getattr(pose_bone, 'select', False))):
                    selected.append((owner, pose_bone))
        if not selected or any(owner is not obj for owner, _bone in selected):
            return None
        active_data_bone = getattr(getattr(obj, 'data', None), 'bones', None)
        active_data_bone = getattr(active_data_bone, 'active', None)
        active_name = str(getattr(active_data_bone, 'name', '') or '') if active_data_bone is not None else ''
        active_bone = next((bone for _owner, bone in selected if str(getattr(bone, 'name', '') or '') == active_name), None)
        if active_bone is None:
            return None
        for _owner, bone in selected:
            if (getattr(bone, 'parent', None) is not None
                    or bool(tuple(getattr(bone, 'children', ()) or ()))
                    or str(getattr(bone, 'rotation_mode', '') or '') != 'XYZ'
                    or bool(tuple(getattr(bone, 'constraints', ()) or ()))
                    or getattr(bone, 'custom_shape', None) is not None
                    or getattr(bone, 'custom_shape_transform', None) is not None):
                return None
        if len(selected) == 1:
            chosen_bones = (selected[0][1],)
        else:
            pivot = str(getattr(getattr(getattr(context, 'scene', None), 'tool_settings', None), 'transform_pivot_point', '') or '')
            if pivot == 'MEDIAN_POINT':
                chosen_bones = tuple(bone for _owner, bone in selected)
            elif pivot == 'ACTIVE_ELEMENT':
                chosen_bones = (active_bone,)
            else:
                return None
        scale = tuple(float(value) for value in getattr(obj, 'scale', ()))
        if len(scale) != 3 or any(not math.isfinite(value) or value <= 0.0 for value in scale):
            return None
        world = obj.matrix_world.to_3x3()
        values = tuple(float(value) for row in world for value in row)
        if len(values) != 9 or any(not math.isfinite(value) for value in values):
            return None
        lengths = tuple(float(world.col[index].length) for index in range(3))
        if (any(not math.isfinite(value) or value <= 1.0e-12 for value in lengths)
                or max(lengths) - min(lengths) <= 1.0e-8):
            return None
        rotation = world.normalized()
        if max(abs(float(rotation[row][column]) - (1.0 if row == column else 0.0)) for row in range(3) for column in range(3)) <= 1.0e-8:
            return None
        if not math.isfinite(float(world.determinant())) or float(world.determinant()) <= 1.0e-12:
            return None
        inverse_transpose = world.inverted().transposed()
        if len(chosen_bones) == 1:
            bone_basis = chosen_bones[0].matrix.to_3x3()
            normal = inverse_transpose @ bone_basis.col[2]
            tangent = inverse_transpose @ bone_basis.col[1]
        else:
            normal_source = Vector((0.0, 0.0, 0.0))
            tangent_source = Vector((0.0, 0.0, 0.0))
            for bone in chosen_bones:
                bone_basis = bone.matrix.to_3x3()
                normal_source += bone_basis.col[2]
                tangent_source += bone_basis.col[1]
            normal = inverse_transpose @ normal_source
            tangent = inverse_transpose @ tangent_source
        if (normal.length_squared <= 1.0e-12
                or tangent.length_squared <= 1.0e-12):
            return None
        z_axis = normal.normalized()
        x_axis = z_axis.cross(-tangent)
        if x_axis.length_squared <= 1.0e-12:
            return None
        x_axis.normalize()
        y_axis = z_axis.cross(x_axis)
        if y_axis.length_squared <= 1.0e-12:
            return None
        y_axis.normalize()
        result = Matrix((x_axis, y_axis, z_axis)).transposed()
        if any(not math.isfinite(float(value)) for row in result for value in row):
            return None
        return result
    except (ReferenceError, RuntimeError, AttributeError, ValueError, TypeError, ZeroDivisionError):
        return None


def _smart_bm_face_normal_live(face):
    """Face normal from the current vertex coordinates (Newell).

    BMFace.normal is a cache that bmesh-level edits (the add-on's G/R/S drag,
    ``update_edit_mesh`` without normals) leave stale; the gizmo must take the
    orientation of the geometry as it is now.
    """
    n = Vector((0.0, 0.0, 0.0))
    cos = [vert.co for vert in face.verts]
    count = len(cos)
    for index in range(count):
        a = cos[index]
        b = cos[(index + 1) % count]
        n.x += (a.y - b.y) * (a.z + b.z)
        n.y += (a.z - b.z) * (a.x + b.x)
        n.z += (a.x - b.x) * (a.y + b.y)
    if n.length_squared <= 1.0e-24:
        return face.normal.copy()
    return n.normalized()


def _smart_get_orientation_matrix(context, obj, orient_type, pivot_loc, rv3d):
    """Return the Smart Gizmo display basis for Blender's active orientation.

    Smart Gizmo handles are drawn in the same coordinate system that Smart G-R-S
    will use for the actual constraint.  Do not treat every non-Global mode as
    object-local; VIEW, CURSOR, LOCAL/GIMBAL/NORMAL/PARENT and custom
    orientations have distinct bases in Blender.
    """
    try:
        orient_type = str(orient_type or 'GLOBAL')
    except Exception:
        orient_type = 'GLOBAL'

    if orient_type == 'GLOBAL':
        return Matrix.Identity(3)

    if orient_type == 'CURSOR':
        try:
            return context.scene.cursor.matrix.to_3x3().normalized()
        except Exception:
            try:
                return context.scene.cursor.matrix.to_3x3()
            except Exception:
                return Matrix.Identity(3)

    if orient_type in {'VIEW', 'WORKPLANE'}:
        mat = _smart_view_basis_matrix_from_rv3d(rv3d)
        return mat if mat is not None else Matrix.Identity(3)

    if str(getattr(context, 'mode', '') or '') == 'POSE' and orient_type == 'LOCAL':
        native_pose_basis = _smart_pose_local_native_display_basis(context, obj)
        if native_pose_basis is not None:
            return native_pose_basis

    if str(getattr(context, 'mode', '') or '') == 'POSE' and orient_type == 'GIMBAL':
        gimbal_basis = _smart_pose_gimbal_basis(context, obj)
        if gimbal_basis is not None:
            return gimbal_basis
        # Quaternion/no active visible bone: Blender's Pose switch falls
        # through to handle_armature_parent_orientation (PARENT).
        orient_type = 'PARENT'

    if str(getattr(context, 'mode', '') or '') in {'EDIT_ARMATURE', 'POSE'} and orient_type in {'LOCAL', 'NORMAL', 'PARENT'}:
        bone_targets = _smart_armature_target_geometry(context)
        bone_basis = bone_targets.get('parent_basis') if orient_type == 'PARENT' else bone_targets.get('active_basis')
        if bone_basis is not None:
            try:
                return bone_basis.to_3x3().normalized()
            except Exception:
                return bone_basis.to_3x3()

    if obj and orient_type == 'PARENT':
        try:
            parent = getattr(obj, 'parent', None)
            if parent is not None:
                return parent.matrix_world.to_3x3().normalized()
        except Exception:
            pass
        return Matrix.Identity(3)

    if obj and orient_type == 'NORMAL' and context.mode == 'EDIT_MESH':
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            elem = bm.select_history.active
            normal = None
            if isinstance(elem, bmesh.types.BMFace):
                normal = _smart_bm_face_normal_live(elem)
            elif isinstance(elem, bmesh.types.BMEdge):
                normal = Vector((0,0,0))
                for f in elem.link_faces:
                    normal += _smart_bm_face_normal_live(f)
                if normal.length_squared > 0:
                    normal.normalize()
            elif isinstance(elem, bmesh.types.BMVert):
                # Corner-angle weighted, like BMVert.normal, but from live coordinates.
                normal = Vector((0, 0, 0))
                for f in elem.link_faces:
                    ring = list(f.verts)
                    at = ring.index(elem)
                    corner = (ring[at - 1].co - elem.co).angle(ring[(at + 1) % len(ring)].co - elem.co, 0.0)
                    normal += _smart_bm_face_normal_live(f) * corner
                if normal.length_squared > 0:
                    normal.normalize()
                else:
                    normal = elem.normal
            if normal:
                z = (obj.matrix_world.to_3x3() @ normal).normalized()
                up = Vector((0,0,1)) if abs(z.z) < 0.9 else Vector((0,1,0))
                x = up.cross(z).normalized()
                y = z.cross(x).normalized()
                return Matrix((x, y, z)).transposed()
        except Exception:
            pass

    if obj and orient_type in {'LOCAL', 'GIMBAL', 'NORMAL'}:
        try:
            return obj.matrix_world.to_3x3().normalized()
        except Exception:
            return Matrix.Identity(3)

    # Custom orientation: only use the active custom matrix when Blender's slot
    # actually reports that custom orientation, or when the active custom name
    # matches the requested orientation.  A previously selected custom
    # orientation can remain in slot.custom_orientation after switching to
    # Local/View/etc.; using it unconditionally makes handle axes disagree with
    # the user's selected coordinate system.
    try:
        slot = context.scene.transform_orientation_slots[0]
        custom = getattr(slot, 'custom_orientation', None)
        if custom is not None:
            slot_type = str(getattr(slot, 'type', '') or '')
            custom_name = str(getattr(custom, 'name', '') or '')
            if slot_type == orient_type or custom_name == orient_type or (slot_type == 'CUSTOM' and orient_type in {'CUSTOM', custom_name}):
                mat = getattr(custom, 'matrix', None)
                if mat is not None:
                    try:
                        return mat.to_3x3().normalized()
                    except Exception:
                        return mat.to_3x3()
    except Exception:
        pass

    return Matrix.Identity(3)


def _smart_armature_target_geometry(context):
    """Read only current selected bone endpoints/pose heads; never retain RNA."""
    mode = str(getattr(context, 'mode', '') or '')
    result = {'points': [], 'active_point': None, 'active_basis': None, 'parent_basis': None, 'signature': ()}
    if mode not in {'EDIT_ARMATURE', 'POSE'}:
        return result
    active_obj = getattr(context, 'active_object', None)
    try:
        objects = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or [])
    except Exception:
        objects = []
    if active_obj is not None and active_obj not in objects:
        objects.insert(0, active_obj)
    rows = []
    actual_edit_active_point = None
    for obj in objects:
        if obj is None or getattr(obj, 'type', None) != 'ARMATURE':
            continue
        if str(getattr(obj, 'mode', '') or '') != ('EDIT' if mode == 'EDIT_ARMATURE' else 'POSE'):
            continue
        try:
            world = obj.matrix_world.copy()
            if mode == 'EDIT_ARMATURE':
                bones = obj.data.edit_bones
                active = getattr(bones, 'active', None)
                if (obj == active_obj
                        and active is not None
                        and _smart_armature_bone_visible('EDIT_ARMATURE', active, active)):
                    actual_edit_active_point = world @ Vector(getattr(active, 'head')).copy()
            else:
                bones = obj.pose.bones
                active_data_bone = getattr(obj.data.bones, 'active', None)
                active = bones.get(active_data_bone.name) if active_data_bone is not None else None
            for bone in bones:
                data_bone = bone if mode == 'EDIT_ARMATURE' else getattr(bone, 'bone', None)
                if data_bone is None or not _smart_armature_bone_visible(mode, bone, data_bone):
                    continue
                if mode == 'EDIT_ARMATURE':
                    whole = bool(getattr(bone, 'select', False))
                    parts = tuple(part for part in ('head', 'tail') if whole or bool(getattr(bone, 'select_' + part, False)))
                    if not parts:
                        continue
                    local_points = [Vector(getattr(bone, part)).copy() for part in parts]
                else:
                    if not bool(getattr(bone, 'select', False)):
                        continue
                    parts = ('head',)
                    local_points = [bone.matrix.translation.copy()]
                world_points = [world @ point for point in local_points]
                aggregate_points = world_points
                if mode == 'EDIT_ARMATURE' and 'head' in parts and bool(getattr(bone, 'use_connect', False)):
                    parent = getattr(bone, 'parent', None)
                    if (parent is not None
                            and _smart_armature_bone_visible('EDIT_ARMATURE', parent)
                            and (bool(getattr(parent, 'select', False)) or bool(getattr(parent, 'select_tail', False)))):
                        # A connected child head and selected parent tail are
                        # the same joint. Count it once in the aggregate pivot.
                        aggregate_points = [point for part, point in zip(parts, world_points) if part != 'head']
                result['points'].extend(aggregate_points)
                rows.append((int(obj.as_pointer()), str(bone.name), parts, tuple(tuple(float(v) for v in point) for point in world_points)))
                if result['active_point'] is None or (obj == active_obj and bone == active):
                    # Replace all three fields together.  A selected child may
                    # precede an active root with no parent in iteration order.
                    parent = getattr(bone, 'parent', None)
                    result.update({
                        'active_point': world @ Vector(getattr(bone, 'head')).copy() if mode == 'EDIT_ARMATURE' else sum(world_points, Vector((0.0, 0.0, 0.0))) / len(world_points),
                        'active_basis': world @ bone.matrix,
                        'parent_basis': world @ parent.matrix if parent is not None else world.copy(),
                    })
        except (ReferenceError, RuntimeError):
            continue
        except Exception:
            continue
    if mode == 'EDIT_ARMATURE' and result['points'] and actual_edit_active_point is not None:
        result['active_point'] = actual_edit_active_point
    basis = result['active_basis']
    try:
        basis_signature = tuple(tuple(float(value) for value in row) for row in basis) if basis is not None else ()
    except Exception:
        basis_signature = ()
    result['signature'] = (tuple(rows), basis_signature)
    return result


def _smart_has_transform_selection(context, obj) -> bool:
    """Return True only when Blender's standard transform gizmo has a target.

    Blender can keep an active object after it is deselected.  Smart Gizmo must
    not use that stale active object as a fallback pivot; otherwise the custom
    gizmo remains at the last selected object's position after selection is
    cleared.
    """
    try:
        mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        mode = ''

    if mode == 'OBJECT':
        try:
            return bool(list(getattr(context, 'selected_objects', []) or []))
        except Exception:
            return False

    if mode in {'EDIT_ARMATURE', 'POSE'}:
        return bool(_smart_armature_target_geometry(context)['points'])

    if mode == 'EDIT_MESH':
        try:
            objs = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', []) or [obj])
        except Exception:
            objs = [obj]
        saw_totals = False
        fallback_objs = []
        for o in objs:
            if not o or getattr(o, 'type', None) != 'MESH':
                continue
            me = getattr(o, 'data', None)
            local_totals_available = False
            for attr in ('total_vert_sel', 'total_edge_sel', 'total_face_sel'):
                try:
                    if hasattr(me, attr):
                        saw_totals = True
                        local_totals_available = True
                        if int(getattr(me, attr, 0) or 0) > 0:
                            return True
                except Exception:
                    pass
            if not local_totals_available:
                fallback_objs.append(o)
        # Blender exposes reliable edit selection totals for Mesh data in the
        # target versions.  When totals exist and are zero, do not scan the whole
        # BMesh every redraw after deselection; that was a dense-mesh slowdown.
        if saw_totals and not fallback_objs:
            return False
        scan_objs = fallback_objs if fallback_objs else [o for o in objs if o and getattr(o, 'type', None) == 'MESH']
        for o in scan_objs:
            try:
                bm = bmesh.from_edit_mesh(o.data)
                if any(bool(getattr(v, 'select', False)) for v in bm.verts):
                    return True
                if any(bool(getattr(e, 'select', False)) for e in bm.edges):
                    return True
                if any(bool(getattr(f, 'select', False)) for f in bm.faces):
                    return True
            except Exception:
                pass
        return False

    if mode == 'EDIT_LATTICE':
        try:
            objs = list(getattr(context, 'objects_in_mode', []) or [obj])
        except Exception:
            objs = [obj]
        for o in objs:
            if not o or getattr(o, 'type', None) != 'LATTICE':
                continue
            try:
                for pt in getattr(o.data, 'points', []) or []:
                    if _smart_lattice_point_selected(pt):
                        return True
            except Exception:
                pass
        return False

    if mode in {'EDIT_CURVE', 'EDIT_SURFACE'}:
        return _smart_curve_has_selection(context, obj)

    try:
        return bool(obj and getattr(obj, 'select_get', lambda: False)())
    except Exception:
        return bool(obj)



def _smart_context_has_transform_selection(context=None) -> bool:
    """Return True only while Smart Gizmo has a real transform target.

    Blender keeps active_object after a background click clears the selection.
    Smart Gizmo must not draw or reuse cached geometry in that state, because the
    cached handle can appear on empty background and then change apparent size
    while the view is zoomed.
    """
    try:
        ctx = context or bpy.context
        obj = getattr(ctx, 'active_object', None)
        if obj is None:
            return False
        return bool(_smart_has_transform_selection(ctx, obj))
    except Exception:
        return False


def _smart_clear_cached_gizmo_state(*, clear_active: bool = False, redraw: bool = False) -> None:
    """Clear cached Smart Gizmo draw/hit data when there is no real selection."""
    changed = False
    try:
        if getattr(cg, '_SMART_GIZMO_LAST_GOOD_GEO', None) is not None:
            changed = True
        cg._SMART_GIZMO_LAST_GOOD_GEO = None
        cg._SMART_GIZMO_LAST_GOOD_TIME = 0.0
    except Exception:
        pass
    try:
        cache = getattr(cg, '_SMART_GIZMO_CACHE', None)
        if isinstance(cache, dict):
            cache['time'] = 0.0
            cache['obj_ptr'] = 0
            cache['mode'] = ''
            cache['sig'] = None
            cache['pivot'] = None
            cache['axes'] = None
            cache['pivot_mode'] = ''
            cache['orient_mode'] = ''
            cache['view_signature'] = None
    except Exception:
        pass
    try:
        if getattr(cg, '_SMART_GIZMO_HOVER_ID', None) is not None:
            changed = True
        cg._SMART_GIZMO_HOVER_ID = None
        cg._SMART_GIZMO_LOCKED_ID = None
        cg._SMART_GIZMO_MOUSE_VALID = False
        cg._SMART_GIZMO_LAST_HOVER_CHECK_AT = 0.0
        cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
    except Exception:
        pass
    if clear_active:
        try:
            cg._CSDT_DRAG_ACTIVE_ID = None
            cg._CSDT_IS_DRAGGING = False
        except Exception:
            pass
    if redraw or changed:
        try:
            cu._tag_view3d_redraw()
        except Exception:
            pass

def _smart_pivot_location_and_axes(context, region_override=None, rv3d_override=None):
    obj = context.active_object
    if not obj:
        _smart_clear_cached_gizmo_state(redraw=False)
        return None, None
    try:
        if not _smart_has_transform_selection(context, obj):
            _smart_clear_cached_gizmo_state(redraw=False)
            return None, None
    except Exception:
        _smart_clear_cached_gizmo_state(redraw=False)
        return None, None

    # During Smart G-R-S drags the selection bounding box can change every
    # modal update.  Keep the Smart Gizmo overlay fixed to the modal source
    # point, including the B-key Snap Base point, until the drag is
    # confirmed/cancelled.  The modal override path is checked together with
    # the legacy freeze flag so hotkey Smart G-R-S also gets a visible gizmo.
    try:
        if bool(getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_ACTIVE', False)) or bool(getattr(cg, '_SMART_GIZMO_FREEZE_ACTIVE', False)):
            frozen_pivot = getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_PIVOT', None)
            frozen_axes = getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_AXES', None)
            if frozen_pivot is None:
                frozen_pivot = getattr(cg, '_SMART_GIZMO_FROZEN_PIVOT', None)
            if not frozen_axes:
                frozen_axes = getattr(cg, '_SMART_GIZMO_FROZEN_AXES', None)
            if frozen_pivot is not None and frozen_axes and len(frozen_axes) >= 4:
                pivot = frozen_pivot.copy() if hasattr(frozen_pivot, 'copy') else Vector(frozen_pivot)
                ax, ay, az, orient_type = frozen_axes[0], frozen_axes[1], frozen_axes[2], frozen_axes[3]
                orient_type = str(orient_type or 'GLOBAL')
                modal_mode = str(getattr(cg, '_SMART_GIZMO_MODAL_OVERRIDE_MODE', '') or '').upper()

                # Keep the transform constraint basis captured at mouse press,
                # but make the visible LOCAL rotation gizmo follow the live
                # object orientation on every redraw.  Freezing both pivot and
                # axes made the gizmo jump only when the drag was confirmed.
                if orient_type == 'LOCAL' and modal_mode == 'R':
                    try:
                        _obj = getattr(context, 'active_object', None)
                        _rv3d = rv3d_override or getattr(context, 'region_data', None) or _smart_resolve_view_region_data(context, region=region_override)
                        _mat = _smart_get_orientation_matrix(context, _obj, orient_type, pivot, _rv3d)
                        _ax = _mat.col[0].normalized()
                        _ay = _mat.col[1].normalized()
                        _az = _mat.col[2].normalized()
                        if _ax.length_squared > 1.0e-12 and _ay.length_squared > 1.0e-12 and _az.length_squared > 1.0e-12:
                            return pivot, (_ax, _ay, _az, orient_type)
                    except Exception:
                        pass

                if orient_type in {'VIEW', 'WORKPLANE'}:
                    try:
                        _rv3d = rv3d_override or getattr(context, 'region_data', None) or _smart_resolve_view_region_data(context, region=region_override)
                        _mat = _smart_get_orientation_matrix(context, getattr(context, 'active_object', None), orient_type, pivot, _rv3d)
                        return pivot, (_mat.col[0].normalized(), _mat.col[1].normalized(), _mat.col[2].normalized(), orient_type)
                    except Exception:
                        pass
                return pivot, (Vector(ax).normalized(), Vector(ay).normalized(), Vector(az).normalized(), orient_type)
    except Exception:
        pass

    edit_mesh_objs = None
    if getattr(context, "mode", None) == "EDIT_MESH":
        try:
            edit_mesh_objs = getattr(context, "objects_in_mode_unique_data", None) or getattr(context, "objects_in_mode", None)
            if edit_mesh_objs:
                edit_mesh_objs = [o for o in edit_mesh_objs if o and getattr(o, "type", None) == "MESH"]
        except Exception:
            edit_mesh_objs = None

    now = time.time()
    mode = context.mode
    
    try:
        pivot_mode = context.scene.tool_settings.transform_pivot_point
        orient_type = _smart_get_orient_type(context)
    except Exception:
        pivot_mode = 'MEDIAN_POINT'
        orient_type = 'GLOBAL'

    # Capture the actual View3D RegionView3D before building the cache key.
    # VIEW / WORKPLANE axes must be keyed by the viewport rotation, not by a
    # stale global context or by an undefined local fallback.
    area = getattr(context, 'area', None)
    region = region_override if region_override is not None else getattr(context, 'region', None)
    rv3d = rv3d_override if rv3d_override is not None else getattr(context, 'region_data', None)
    if rv3d is None:
        try:
            if region is not None:
                rv3d = getattr(region, 'data', None)
        except Exception:
            rv3d = None
    if rv3d is None:
        try:
            a, r = cu._get_view3d_area_region(context)
            if a is not None:
                area = a
            if r is not None and region is None:
                region = r
            rv3d = cu._view3d_region_data(area, region)
        except Exception:
            rv3d = None

    sig = None
    try:
        if mode == "EDIT_MESH" and obj.type == "MESH":
            if edit_mesh_objs:
                tv = te = tf = 0
                for o in edit_mesh_objs:
                    try:
                        me = o.data
                        tv += getattr(me, "total_vert_sel", 0)
                        te += getattr(me, "total_edge_sel", 0)
                        tf += getattr(me, "total_face_sel", 0)
                    except Exception:
                        continue
                sig = (tv, te, tf, len(edit_mesh_objs), pivot_mode, orient_type)
            else:
                me = obj.data
                sig = (getattr(me, "total_vert_sel", 0), getattr(me, "total_edge_sel", 0), getattr(me, "total_face_sel", 0), pivot_mode, orient_type)
        elif mode in {"EDIT_CURVE", "EDIT_SURFACE"} and obj.type in {"CURVE", "SURFACE"}:
            try:
                curve_objs = list(getattr(context, 'objects_in_mode_unique_data', None) or getattr(context, 'objects_in_mode', None) or [obj])
            except Exception:
                curve_objs = [obj]
            counts = []
            for co in curve_objs:
                if co and getattr(co, 'type', None) in {'CURVE', 'SURFACE'}:
                    try:
                        sel_count = sum(1 for _key, _p, selected in _smart_curve_component_items(co, selected_only=False) if selected)
                        counts.append((int(co.as_pointer()), int(sel_count)))
                    except Exception:
                        pass
            sig = (tuple(sorted(counts)), pivot_mode, orient_type)
        elif mode in {'EDIT_ARMATURE', 'POSE'}:
            sig = (_smart_armature_target_geometry(context)['signature'], pivot_mode, orient_type)
        elif mode == "OBJECT":
            sel = tuple(sorted([o.as_pointer() for o in context.selected_objects])) if context.selected_objects else ()
            sig = (sel, pivot_mode, orient_type)
        else:
            sig = (pivot_mode, orient_type)
    except Exception:
        sig = None

    view_sig = None
    if orient_type in {'VIEW', 'WORKPLANE'}:
        try:
            # Prefer the concrete View3D RegionView3D resolved from the draw/pick
            # area.  A generic context.region_data can point at a different 3D
            # View, which makes VIEW orientation keep the wrong angle after the
            # user orbits the viewport.
            _rv3d = rv3d or getattr(context, 'region_data', None)
            rv3d_ptr = _rv3d.as_pointer() if _rv3d and hasattr(_rv3d, 'as_pointer') else 0
            # The same RegionView3D pointer is reused while the user orbits the
            # viewport, so pointer-only cache keys leave VIEW-oriented gizmo axes
            # stale.  Include the actual view orientation matrix values.
            view_sig = _smart_view_orientation_signature_from_rv3d(_rv3d) or ()
        except Exception:
            rv3d_ptr = 0
            view_sig = ()
        sig = (sig, rv3d_ptr, view_sig)

    cache = cg._SMART_GIZMO_CACHE
    
    cache_ttl = _smart_cache_ttl(context)
    # Edit Mesh / Edit Lattice 中と Smart Gizmo ドラッグ中は毎フレーム再計算して、
    # 頂点編集中の追従遅れをなくします。Object モードだけ軽量キャッシュを残します。
    if cache_ttl > 0.0 and cache.get("obj_ptr") == obj.as_pointer() and cache.get("mode") == mode and cache.get("sig") == sig:
        if (now - cache.get("time", 0)) < cache_ttl:
            return cache.get("pivot"), cache.get("axes")
        # 編集メッシュで、前に求めてから depsgraph の更新（頂点の移動・選択の変更）が 1 度も無ければ
        # 中身は同じ。重いメッシュでホバーの判定のたびに全頂点を数え直していた（10 万頂点で 1 回 24 ms）。
        if (
            mode == 'EDIT_MESH' and pivot_mode != 'CURSOR'
            and cache.get('deps_serial') == _SMART_DEPSGRAPH_SERIAL
            and (now - cache.get("time", 0)) < _SMART_EDIT_PIVOT_CACHE_MAX_AGE
            and _smart_native_follow_handler_registered()
        ):
            return cache.get("pivot"), cache.get("axes")

    pivot_world = None
    
    if pivot_mode == 'CURSOR':
        pivot_world = context.scene.cursor.location.copy()
        
    elif pivot_mode == 'ACTIVE_ELEMENT':
        if mode == 'OBJECT':
            pivot_world = obj.matrix_world.translation.copy()
        elif mode in {'EDIT_ARMATURE', 'POSE'}:
            pivot_world = _smart_armature_target_geometry(context)['active_point']
        elif mode == 'EDIT_MESH':
            try:
                bm = bmesh.from_edit_mesh(obj.data)
                elem = bm.select_history.active
                if elem is None and edit_mesh_objs:
                    for o in edit_mesh_objs:
                        if o == obj:
                            continue
                        try:
                            bm2 = bmesh.from_edit_mesh(o.data)
                            elem = bm2.select_history.active
                            if elem is not None:
                                obj = o  
                                bm = bm2
                                break
                        except Exception:
                            continue

                if isinstance(elem, bmesh.types.BMVert):
                    pivot_world = obj.matrix_world @ elem.co
                elif isinstance(elem, bmesh.types.BMEdge) or isinstance(elem, bmesh.types.BMFace):
                    center = Vector((0, 0, 0))
                    for v in elem.verts:
                        center += v.co
                    center /= max(1, len(elem.verts))
                    pivot_world = obj.matrix_world @ center
                else:
                    pivot_mode = 'MEDIAN_POINT'
            except Exception:
                pivot_mode = 'MEDIAN_POINT'
                
    if pivot_world is None and pivot_mode == 'ACTIVE_ELEMENT' and mode in {'EDIT_CURVE', 'EDIT_SURFACE'} and obj.type in {'CURVE', 'SURFACE'}:
        try:
            pts = _smart_curve_selected_points_world(context)
            if pts:
                pivot_world = pts[-1].copy()
        except Exception:
            pivot_world = None

    if pivot_world is None:
        try:
            if mode == "EDIT_MESH" and obj.type == "MESH":
                min_w = Vector((1e18, 1e18, 1e18))
                max_w = Vector((-1e18, -1e18, -1e18))
                
                n_total = 0
                co_local_sum_world = Vector((0.0, 0.0, 0.0))

                objs = edit_mesh_objs if edit_mesh_objs else [obj]
                for o in objs:
                    if not o or getattr(o, "type", None) != "MESH":
                        continue
                    try:
                        bm = bmesh.from_edit_mesh(o.data)
                    except Exception:
                        continue
                    mw = o.matrix_world
                    
                    if pivot_mode == 'BOUNDING_BOX_CENTER':
                        for v in bm.verts:
                            if v.select:
                                w = mw @ v.co
                                if w.x < min_w.x: min_w.x = w.x
                                if w.y < min_w.y: min_w.y = w.y
                                if w.z < min_w.z: min_w.z = w.z
                                if w.x > max_w.x: max_w.x = w.x
                                if w.y > max_w.y: max_w.y = w.y
                                if w.z > max_w.z: max_w.z = w.z
                                n_total += 1
                    else:
                        # 修正: ループ内の重い行列積(mw @ v.co)を排除。
                        # ローカル座標で全て足し合わせ、最後に1回だけ行列を掛ける（計算量が数万分の一になります）
                        co_l = Vector((0.0, 0.0, 0.0))
                        n = 0
                        for v in bm.verts:
                            if v.select:
                                co_l += v.co
                                n += 1
                        if n > 0:
                            co_local_sum_world += mw @ (co_l / n)
                            n_total += 1

                if n_total > 0:
                    if pivot_mode == 'BOUNDING_BOX_CENTER':
                        pivot_world = (min_w + max_w) * 0.5
                    else:
                        pivot_world = co_local_sum_world / n_total
                else:
                    pivot_world = obj.matrix_world.translation

            elif mode in {'EDIT_ARMATURE', 'POSE'}:
                points = _smart_armature_target_geometry(context)['points']
                if points:
                    if pivot_mode == 'BOUNDING_BOX_CENTER':
                        if mode == 'EDIT_ARMATURE':
                            active_world = obj.matrix_world
                            active_world_inv = active_world.inverted()
                            local_points = [active_world_inv @ point for point in points]
                            pivot_local = (
                                Vector(tuple(min(point[i] for point in local_points) for i in range(3)))
                                + Vector(tuple(max(point[i] for point in local_points) for i in range(3)))
                            ) * 0.5
                            pivot_world = active_world @ pivot_local
                        else:
                            pivot_world = (Vector(tuple(min(point[i] for point in points) for i in range(3))) + Vector(tuple(max(point[i] for point in points) for i in range(3)))) * 0.5
                    else:
                        pivot_world = sum(points, Vector((0.0, 0.0, 0.0))) / len(points)

            elif mode == "EDIT_LATTICE" and obj.type == "LATTICE":
                lat = obj.data
                co_l = Vector((0.0, 0.0, 0.0))
                n = 0
                for p in lat.points:
                    if _smart_lattice_point_selected(p):
                        co_l += Vector(p.co_deform)
                        n += 1
                if n > 0:
                    pivot_world = obj.matrix_world @ (co_l / n)
                else:
                    pivot_world = obj.matrix_world.translation

            elif mode in {"EDIT_CURVE", "EDIT_SURFACE"} and obj.type in {"CURVE", "SURFACE"}:
                pts = _smart_curve_selected_points_world(context)
                if pts:
                    if pivot_mode == 'BOUNDING_BOX_CENTER':
                        min_w = Vector((1e18, 1e18, 1e18))
                        max_w = Vector((-1e18, -1e18, -1e18))
                        for w in pts:
                            min_w.x = min(min_w.x, w.x); min_w.y = min(min_w.y, w.y); min_w.z = min(min_w.z, w.z)
                            max_w.x = max(max_w.x, w.x); max_w.y = max(max_w.y, w.y); max_w.z = max(max_w.z, w.z)
                        pivot_world = (min_w + max_w) * 0.5
                    else:
                        pivot_world = sum(pts, Vector((0.0, 0.0, 0.0))) / max(1, len(pts))
                else:
                    pivot_world = obj.matrix_world.translation

            else:
                sel = list(context.selected_objects) if getattr(context, "selected_objects", None) else []
                if sel:
                    co = Vector((0.0, 0.0, 0.0))
                    for o in sel: co += o.matrix_world.translation
                    pivot_world = co / max(1, len(sel))
                else:
                    pivot_world = obj.matrix_world.translation
        except Exception:
            pivot_world = obj.matrix_world.translation

    if rv3d is None:
        try:
            area2, region2 = cu._get_view3d_area_region(context)
            if area is None:
                area = area2
            if region is None:
                region = region2
            rv3d = cu._view3d_region_data(area, region)
        except Exception:
            rv3d = None
    
    mat = _smart_get_orientation_matrix(context, obj, orient_type, pivot_world, rv3d)
    ax = mat.col[0].normalized()
    ay = mat.col[1].normalized()
    az = mat.col[2].normalized()
    
    axes = (ax, ay, az, orient_type)

    cache["time"] = now
    cache["deps_serial"] = _SMART_DEPSGRAPH_SERIAL
    cache["obj_ptr"] = obj.as_pointer()
    cache["mode"] = mode
    cache["sig"] = sig
    cache["pivot"] = pivot_world
    cache["axes"] = axes
    cache["pivot_mode"] = pivot_mode
    cache["orient_mode"] = orient_type
    cache["view_signature"] = view_sig if orient_type in {'VIEW', 'WORKPLANE'} else None
    return pivot_world, axes

def _smart_get_view_scale(region, rv3d, pivot):
    """Return world-space length corresponding to a fixed screen-pixel size.

    Smart Gizmo is drawn in 3D, so every handle dimension must be converted from
    pixels to world units at the current pivot depth on every redraw.  This keeps
    the gizmo visually fixed while the View3D is zoomed or switched between
    perspective and orthographic projections.
    """
    target_px = 120.0
    if region is None or rv3d is None or pivot is None:
        return 1.0
    try:
        p2d = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot)
        if p2d is not None:
            px = float(p2d.x)
            py = float(p2d.y)
            sample_px = 64.0
            samples = []
            for dx, dy in ((sample_px, 0.0), (0.0, sample_px), (-sample_px, 0.0), (0.0, -sample_px)):
                try:
                    w0 = view3d_utils.region_2d_to_location_3d(region, rv3d, (px, py), pivot)
                    w1 = view3d_utils.region_2d_to_location_3d(region, rv3d, (px + dx, py + dy), pivot)
                    d = (w1 - w0).length / sample_px
                    if math.isfinite(d) and d > 1.0e-12:
                        samples.append(d)
                except Exception:
                    pass
            if samples:
                # Use the median-like middle value to avoid a single unstable
                # projection sample causing oversized handles near the view edge.
                samples.sort()
                px_world = samples[len(samples) // 2]
                return max(1.0e-6, px_world * target_px)
    except Exception:
        pass

    try:
        if bool(getattr(rv3d, 'is_perspective', False)):
            view_pos = rv3d.view_matrix.inverted().translation
            dist = (view_pos - pivot).length
            if math.isfinite(dist) and dist > 1.0e-9:
                return max(1.0e-6, dist * 0.11)
    except Exception:
        pass

    try:
        view_distance = float(getattr(rv3d, 'view_distance', 1.0) or 1.0)
        if math.isfinite(view_distance) and view_distance > 0.0:
            return max(1.0e-6, view_distance * 0.02)
    except Exception:
        pass
    return 1.0


def _smart_get_oriented_view_scale(region, rv3d, pivot, axes):
    """Return a zoom-stable world scale for the current visible gizmo axes.

    A single world-space length projects to different pixel lengths depending on
    the axis' angle to the camera.  Use the currently drawn X/Y/Z basis to choose
    a base length whose largest visible axis remains a fixed pixel length.  This
    prevents the custom gizmo from growing or shrinking when the user zooms the
    View3D.
    """
    target_px = 120.0
    try:
        pivot_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot)
        if pivot_2d is None:
            return _smart_get_view_scale(region, rv3d, pivot)
        base = max(1.0e-6, float(_smart_get_view_scale(region, rv3d, pivot)))
        clean_axes = []
        for axis in axes or ():
            try:
                v = Vector(axis)
                if v.length_squared > 1.0e-12:
                    clean_axes.append(v.normalized())
            except Exception:
                pass
        if not clean_axes:
            return base
        for _ in range(3):
            lengths = []
            for axis in clean_axes:
                try:
                    q = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot + axis * base)
                    if q is None:
                        continue
                    d = (q - pivot_2d).length
                    if math.isfinite(d) and d > 1.0e-6:
                        lengths.append(float(d))
                except Exception:
                    pass
            if not lengths:
                break
            max_len = max(lengths)
            if max_len <= 1.0e-6:
                break
            base *= target_px / max_len
            if abs(max_len - target_px) <= 0.25:
                break
        if math.isfinite(base) and base > 1.0e-9:
            return max(1.0e-6, base)
    except Exception:
        pass
    return _smart_get_view_scale(region, rv3d, pivot)

def _smart_strength_to_t(strength):
    try:
        v = float(strength)
    except Exception:
        v = 8.0
    return max(0.0, min(1.0, v / 10.0))

def _smart_pick_factor():
    p = cu._prefs()
    try:
        return float(getattr(p, "gizmo_pick_range_px", 7.0))
    except Exception:
        return 7.0

def _smart_screen_scale():
    p = cu._prefs()
    try:
        val = float(getattr(p, "smart_gizmo_screen_scale", 1.0))
        return val * cg._INTERNAL_SCALE_CORRECTION
    except Exception:
        return 1.0 * cg._INTERNAL_SCALE_CORRECTION

def _smart_colors():
    prefs = cu._prefs()
    if prefs:
        cx = prefs.color_x
        cy = prefs.color_y
        cz = prefs.color_z
        cw = prefs.color_free
        ch = prefs.color_highlight
        return {
            "X": (cx[0], cx[1], cx[2], 1.0),
            "Y": (cy[0], cy[1], cy[2], 1.0),
            "Z": (cz[0], cz[1], cz[2], 1.0),
            "WHITE": (cw[0], cw[1], cw[2], 1.0),
            "YELLOW": (ch[0], ch[1], ch[2], 1.0),
        }
    else:
        def _hex_to_rgba(h):
            return ((h >> 16) & 0xFF) / 255.0, ((h >> 8) & 0xFF) / 255.0, (h & 0xFF) / 255.0, 1.0
        return {
            "X": _hex_to_rgba(0xe8364e), 
            "Y": _hex_to_rgba(0x85cc06), 
            "Z": _hex_to_rgba(0x3081ec), 
            "WHITE": (1.0, 1.0, 1.0, 1.0),
            "YELLOW": (1.0, 0.9, 0.1, 1.0),
        }

def _smart_plane_handle_points(pivot, axis_u, axis_v, scale):
    size = scale * 0.28
    p0 = pivot
    p1 = pivot + (axis_u * size)
    p2 = pivot + (axis_u * size) + (axis_v * size)
    p3 = pivot + (axis_v * size)
    return p0, p1, p2, p3

def _smart_gizmo_geometry(context, region, rv3d):
    kind = _smart_tool_kind(context)
    if not kind:
        return None

    pivot, axes = _smart_pivot_location_and_axes(context, region, rv3d)
    if pivot is None:
        return None

    ax, ay, az, orient_type = axes
    rotation_axis_mask = _smart_pose_local_rotation_axis_mask(context, orient_type)

    p = cu._prefs()
    gscale = _smart_screen_scale()

    try: axis_scale = float(getattr(p, "smart_axis_scale", 1.0)) if p else 1.0
    except Exception: axis_scale = 1.0
      
    try: plane_scale = float(getattr(p, "smart_plane_scale", 1.0)) if p else 1.0
    except Exception: plane_scale = 1.0

    try: center_scale = float(getattr(p, "smart_center_scale", 1.0)) if p else 1.0
    except Exception: center_scale = 1.0

    base_scale = _smart_get_oriented_view_scale(region, rv3d, pivot, (ax, ay, az))
    uni_base = base_scale * gscale
      
    axis_len = uni_base * axis_scale * 1.0
    plane_size_factor = uni_base * plane_scale
    center_radius = uni_base * center_scale * 0.09
    uniform_scale_for_arrow = uni_base * axis_scale

    rotate_radius = uni_base * axis_scale * 0.55
    rotate_radius_view = uni_base * axis_scale * 0.72

    scale_len = uni_base * axis_scale * 0.90
    scale_cube = uni_base * axis_scale * 0.06
    scale_center = uni_base * center_scale * 0.07

    # TRANSFORM: Dedicated SCALE handle layout to avoid overlap with MOVE.
    #  - SCALE axis boxes live *outside* MOVE arrow tips (no axis lines).
    #  - SCALE plane handles are detached squares, offset away from MOVE plane quads.
    #  - Center becomes a "bullseye": inner circle=Move, ring=Scale.
    scale_len_outer = axis_len * 1.18
    scale_plane_offset = plane_size_factor * 0.42
    scale_plane_half = plane_size_factor * 0.085
    scale_ring_outer = max(center_radius * 2.10, scale_center * 1.95)

    geo = {
        "kind": kind,
        "pivot": pivot,
        "axes": (ax, ay, az),
        "orient_type": orient_type,
        "rotation_axis_mask": tuple(bool(value) for value in rotation_axis_mask),
        "axis_len": axis_len,
        "plane_scale": plane_size_factor,
        "center_radius": center_radius,
        "uniform_scale": uniform_scale_for_arrow,
        "rotate_radius": rotate_radius,
        "rotate_radius_view": rotate_radius_view,
        "scale_len": scale_len,
        "scale_cube": scale_cube,
        "scale_center": scale_center,
        "scale_len_outer": scale_len_outer,
        "scale_plane_offset": scale_plane_offset,
        "scale_plane_half": scale_plane_half,
        "scale_ring_outer": scale_ring_outer,
        # Keep the event-built geometry immutable, but retain the reference
        # frame needed to remap it from the current RegionView3D on every draw.
        # No object/depsgraph/BMesh access is needed for that per-draw remap.
        "reference_world_scale": uni_base,
        "screen_scale": gscale,
    }
    try:
        cg._SMART_GIZMO_LAST_GOOD_GEO = dict(geo)
        cg._SMART_GIZMO_LAST_GOOD_TIME = time.perf_counter()
    except Exception:
        pass
    return geo

def _smart_last_good_geometry(context=None, *, allow_without_selection: bool = False):
    try:
        if not allow_without_selection and not _smart_context_has_transform_selection(context):
            _smart_clear_cached_gizmo_state(redraw=False)
            return None
        geo = getattr(cg, '_SMART_GIZMO_LAST_GOOD_GEO', None)
        if not geo:
            return None
        age = time.perf_counter() - float(getattr(cg, '_SMART_GIZMO_LAST_GOOD_TIME', 0.0) or 0.0)
        if age <= float(_SMART_GIZMO_LAST_GOOD_TTL):
            return dict(geo)
    except Exception:
        pass
    return None

def _update_gizmo_cache(context, area, region, rv3d_override=None):
    rv3d = rv3d_override or (region.data if region else None)
    if rv3d is None:
        rv3d = cu._view3d_region_data(area, region)
    if not rv3d:
        return False
    ok = _smart_gizmo_geometry(context, region, rv3d) is not None
    if ok:
        try:
            _start_smart_gizmo_guardian()
        except Exception:
            pass
    elif not _smart_runtime_activity_active():
        _smart_clear_cached_gizmo_state(redraw=False)
    return ok

def _scale_uniform_free_handle_radius(geo, kind):
    """Return the logical half-size radius for the SCALE tool free-axis square.

    Only the dedicated SCALE tool uses the white square free-axis handle.
    The TRANSFORM tool uses the bullseye ring layout, so it keeps its
    original size.
    """
    try:
        base = float(geo.get('scale_center', geo.get('center_radius', 0.0)))
    except Exception:
        base = 0.0
    if kind == 'SCALE':
        return base * 1.5
    return base

def _hit_test_gizmo(mx, my, context=None, region_override=None, rv3d_override=None):
    if cg._CSDT_DRAG_ACTIVE_ID:
        return cg._CSDT_DRAG_ACTIVE_ID

    if cg._SMART_GIZMO_LOCKED_ID:
        return cg._SMART_GIZMO_LOCKED_ID
        
    context = context or bpy.context

    area = getattr(context, "area", None)
    region = region_override or getattr(context, "region", None)
    rv3d = rv3d_override or getattr(context, "region_data", None)
    if not area or area.type != "VIEW_3D" or not region or region.type != "WINDOW" or not rv3d:
        try:
            a, r = cu._get_view3d_area_region(context)
            if a and r:
                area, region = a, r
                rv3d = cu._view3d_region_data(a, r)
        except Exception:
            pass
    if not area or area.type != "VIEW_3D" or not region or region.type != "WINDOW" or not rv3d:
        return None

    geo = _smart_gizmo_geometry(context, region, rv3d)
    if not geo:
        return None

    kind = geo["kind"]
    pivot = geo["pivot"]
    ax, ay, az = geo["axes"]
    plane_sc = geo["plane_scale"]
    rotation_axis_mask = tuple(bool(value) for value in geo.get('rotation_axis_mask', (True, True, True)))
    rotation_axis_any = any(rotation_axis_mask)

    c2d = view3d_utils.location_3d_to_region_2d(region, rv3d, pivot)
    if c2d is None:
        return None

    tol = _smart_pick_factor()
    best = (1e18, None)
    rot_axis_best = (1e18, None)

    _rot_axis_hit_ids = {'ROT_X', 'ROT_Y', 'ROT_Z'}

    def _is_free_axis_handle_id(hid):
        try:
            h = str(hid or '')
        except Exception:
            return False
        return h in {'MOVE_CENTER', 'SCALE_UNIFORM'} or h.startswith('ROT_FREE')

    def consider(dist, hid):
        nonlocal best
        current = best[1]
        # When the projected XYZ rotation rings overlap a free-axis handle, the
        # explicit XYZ axis must be the hover/click target.  This applies to the
        # dedicated Rotate tool and to the combined Transform tool, where the
        # free handles can share the same screen area.
        if hid in _rot_axis_hit_ids and _is_free_axis_handle_id(current):
            best = (dist, hid)
            return
        if _is_free_axis_handle_id(hid) and current in _rot_axis_hit_ids:
            return
        if dist < best[0]:
            best = (dist, hid)

    def p2d(w):
        return view3d_utils.location_3d_to_region_2d(region, rv3d, w)

    prefs = cu._prefs(context)
    show_move = True
    show_rot = True
    show_sca = True
    if prefs and kind == 'TRANSFORM':
        show_move = bool(getattr(prefs, 'smart_gizmo_transform_show_move', True))
        show_rot = bool(getattr(prefs, 'smart_gizmo_transform_show_rotate', True))
        show_sca = bool(getattr(prefs, 'smart_gizmo_transform_show_scale', True))

    def ring_pick(axis_n, radius, hid, segments=128):
        nonlocal rot_axis_best
        # Build ring points in 3D, project to 2D, then distance to polyline.
        try:
            n = axis_n.normalized()
        except Exception:
            return
        # Basis
        up = Vector((0, 0, 1)) if abs(n.z) < 0.9 else Vector((0, 1, 0))
        u = up.cross(n)
        if u.length_squared < 1e-12:
            return
        u.normalize()
        v = n.cross(u).normalized()
        pts2 = []
        for i in range(segments):
            a = (2.0 * math.pi * i) / segments
            w = pivot + (u * math.cos(a) + v * math.sin(a)) * float(radius)
            q = p2d(w)
            if q is None:
                return
            pts2.append((float(q.x), float(q.y)))
        # Dist to segments
        best_d = 1e18
        for (ax0, ay0), (bx0, by0) in zip(pts2, pts2[1:] + pts2[:1]):
            d = cu._dist_point_to_seg_2d(mx, my, ax0, ay0, bx0, by0)
            if d < best_d:
                best_d = d
        if best_d <= tol:
            if hid in _rot_axis_hit_ids and best_d < rot_axis_best[0]:
                rot_axis_best = (best_d, hid)
            consider(best_d, hid)

    def scale_axis_pick(axis_dir, hid):
        # TRANSFORM: axis SCALE is a detached box placed outside MOVE arrow tips.
        if kind == 'TRANSFORM':
            Lw = geo.get('scale_len_outer', geo.get('axis_len', 1.0) * 1.18)
            tip = pivot + axis_dir * float(Lw)
            t2 = p2d(tip)
            if t2 is None:
                return
            d = math.hypot(mx - float(t2.x), my - float(t2.y))
            if d <= tol * 1.10:
                consider(d, hid)
            return

        Lw = geo.get('scale_len', geo['axis_len'])
        a = pivot
        b = pivot + axis_dir * float(Lw)
        a2 = p2d(a)
        b2 = p2d(b)
        if a2 is None or b2 is None:
            return
        d = cu._dist_point_to_seg_2d(mx, my, float(a2.x), float(a2.y), float(b2.x), float(b2.y))
        if d <= tol:
            consider(d, hid)

    # MOVE handles
    if kind in {"MOVE", "TRANSFORM"} and show_move:
        cr = geo["center_radius"]
        try:
            view_inv = rv3d.view_matrix.inverted()
            vx = view_inv.to_3x3() @ Vector((1, 0, 0))
        except Exception:
            vx = Vector((1,0,0))
          
        pt_r = p2d(pivot + vx * cr)
        radius_px = 10.0
        if pt_r is not None and c2d is not None:
            radius_px = math.hypot(pt_r.x - c2d.x, pt_r.y - c2d.y)
          
        dist_to_center = math.hypot(mx - c2d.x, my - c2d.y)
        if dist_to_center <= (radius_px * 1.3): 
            consider(0.0, "MOVE_CENTER")

        def plane_pick(axis_u, axis_v, hid):
            pts = _smart_plane_handle_points(pivot, axis_u, axis_v, plane_sc)
            q = [p2d(p) for p in pts]
            if any(v is None for v in q): return
            poly = [(float(v.x), float(v.y)) for v in q]
            if cu._poly_hit_2d(mx, my, poly, tol * 0.85):
                cx = sum(p[0] for p in poly) / 4.0
                cy = sum(p[1] for p in poly) / 4.0
                d = math.hypot(mx - cx, my - cy)
                consider(d, hid)

        plane_pick(ax, ay, "MOVE_XY")
        plane_pick(ay, az, "MOVE_YZ")
        plane_pick(ax, az, "MOVE_XZ")

        plane_radius = plane_sc * 0.28
        center_radius = geo["center_radius"]
        start_offset = max(plane_radius, center_radius * 1.1)

        def axis_pick(axis_dir, hid):
            Lw = geo["axis_len"]
            a = pivot + axis_dir * start_offset
            b = pivot + axis_dir * float(Lw)
            a2 = p2d(a)
            b2 = p2d(b)
            if a2 is None or b2 is None: return
            d = cu._dist_point_to_seg_2d(mx, my, float(a2.x), float(a2.y), float(b2.x), float(b2.y))
            if d <= tol: consider(d, hid)

        axis_pick(ax, "MOVE_X")
        axis_pick(ay, "MOVE_Y")
        axis_pick(az, "MOVE_Z")

        # no early return; combined with other handle hits

    # ROTATE handles
    if kind in {"ROTATE", "TRANSFORM"} and show_rot:
        rr = geo.get('rotate_radius', 0.0)
        rr_view = geo.get('rotate_radius_view', rr * 1.2)
        if rr > 0.0:
            if rotation_axis_mask[0]:
                ring_pick(ax, rr, 'ROT_X')
            if rotation_axis_mask[1]:
                ring_pick(ay, rr, 'ROT_Y')
            if rotation_axis_mask[2]:
                ring_pick(az, rr, 'ROT_Z')

            # Max-like free rotation handle: the translucent free-axis disk
            # is always a screen-facing circle.  It must not rotate in 3D with
            # the X/Y/Z rings when the viewport rotates; only the drag
            # algorithm changes the mixed XYZ rotation axis.
            def _view_billboard_axes():
                try:
                    inv = rv3d.view_matrix.inverted().to_3x3()
                    u = (inv @ Vector((1, 0, 0))).normalized()
                    v = (inv @ Vector((0, 1, 0))).normalized()
                    return u, v
                except Exception:
                    return Vector((1, 0, 0)), Vector((0, 1, 0))

            def _rot_free_disc_pick(radius, hid='ROT_FREE_X'):
                try:
                    r = float(radius) * 0.82
                except Exception:
                    return
                if r <= 0.0 or c2d is None:
                    return
                u, _v = _view_billboard_axes()
                pr = p2d(pivot + u * r)
                if pr is None:
                    return
                try:
                    radius_px = max(2.0, math.hypot(float(pr.x) - float(c2d.x), float(pr.y) - float(c2d.y)))
                    d = math.hypot(float(mx) - float(c2d.x), float(my) - float(c2d.y))
                    if d <= radius_px:
                        # The free-rotation disk remains selectable inside the
                        # screen-facing disk, but the generic consider() priority
                        # keeps explicit XYZ rings above it when they overlap.
                        consider(0.0, hid)
                    elif d <= radius_px + tol * 0.55 and best[1] is None:
                        consider(tol * 100.0, hid)
                except Exception:
                    return

            if rotation_axis_any:
                _rot_free_disc_pick(rr, 'ROT_FREE_X')

        # view ring
        try:
            view_basis = _smart_view_basis_matrix_from_rv3d(rv3d)
            view_n = (view_basis.col[2] if view_basis is not None else (rv3d.view_rotation @ Vector((0, 0, 1)))).normalized()
            if rotation_axis_any:
                ring_pick(view_n, rr_view, 'ROT_VIEW')
        except Exception:
            pass

    # SCALE handles
    if kind in {"SCALE", "TRANSFORM"} and show_sca:
        # center uniform scale
        c2d = c2d
        try:
            view_inv = rv3d.view_matrix.inverted()
            vx = view_inv.to_3x3() @ Vector((1, 0, 0))
        except Exception:
            vx = Vector((1, 0, 0))

        dist_to_center = math.hypot(mx - c2d.x, my - c2d.y)

        if kind == 'TRANSFORM':
            # Bullseye: inner circle is MOVE, ring is SCALE.
            inner_w = float(geo.get('center_radius', 0.0))
            outer_w = float(geo.get('scale_ring_outer', max(inner_w * 2.0, 0.0001)))

            p_in = p2d(pivot + vx * inner_w)
            p_out = p2d(pivot + vx * outer_w)

            inner_px = 10.0
            outer_px = 18.0
            if p_in is not None and c2d is not None:
                inner_px = math.hypot(p_in.x - c2d.x, p_in.y - c2d.y)
            if p_out is not None and c2d is not None:
                outer_px = math.hypot(p_out.x - c2d.x, p_out.y - c2d.y)

            # Pick ring only (avoid stealing MOVE center)
            if (dist_to_center >= inner_px * 1.20) and (dist_to_center <= outer_px * 1.15):
                consider(0.0, 'SCALE_UNIFORM')
        else:
            sr = _scale_uniform_free_handle_radius(geo, kind)
            pt_r = p2d(pivot + vx * sr)
            radius_px = 10.0
            if pt_r is not None and c2d is not None:
                radius_px = math.hypot(pt_r.x - c2d.x, pt_r.y - c2d.y)
            if dist_to_center <= (radius_px * 1.35):
                consider(0.0, 'SCALE_UNIFORM')

        # Plane scale handles
        def plane_pick_scale(axis_u, axis_v, hid):
            if kind == 'TRANSFORM':
                # Detached square, offset away from MOVE plane quad.
                off = float(geo.get('scale_plane_offset', plane_sc * 0.42))
                hs = float(geo.get('scale_plane_half', plane_sc * 0.085))
                c = pivot + axis_u * off + axis_v * off
                p0 = c + (-axis_u - axis_v) * hs
                p1 = c + ( axis_u - axis_v) * hs
                p2 = c + ( axis_u + axis_v) * hs
                p3 = c + (-axis_u + axis_v) * hs
                q = [p2d(p0), p2d(p1), p2d(p2), p2d(p3)]
                if any(v is None for v in q):
                    return
                poly = [(float(v.x), float(v.y)) for v in q]
                if cu._poly_hit_2d(mx, my, poly, tol * 0.90):
                    cx = sum(p[0] for p in poly) / 4.0
                    cy = sum(p[1] for p in poly) / 4.0
                    d = math.hypot(mx - cx, my - cy)
                    consider(d, hid)
                return

            # SCALE tool: legacy plane quad
            plane_sc_s = plane_sc * 0.85
            pts = _smart_plane_handle_points(pivot, axis_u, axis_v, plane_sc_s)
            q = [p2d(p) for p in pts]
            if any(v is None for v in q):
                return
            poly = [(float(v.x), float(v.y)) for v in q]
            if cu._poly_hit_2d(mx, my, poly, tol * 0.85):
                cx = sum(p[0] for p in poly) / 4.0
                cy = sum(p[1] for p in poly) / 4.0
                d = math.hypot(mx - cx, my - cy)
                consider(d, hid)

        plane_pick_scale(ax, ay, 'SCALE_XY')
        plane_pick_scale(ay, az, 'SCALE_YZ')
        plane_pick_scale(ax, az, 'SCALE_XZ')

        scale_axis_pick(ax, 'SCALE_X')
        scale_axis_pick(ay, 'SCALE_Y')
        scale_axis_pick(az, 'SCALE_Z')

    # Final safety pass for the combined Transform tool: later free-axis
    # handles such as the center move or uniform scale handle are evaluated
    # after the rotation rings.  If they overlap an already-hit XYZ rotation
    # ring, keep the explicit XYZ ring selected.
    if _is_free_axis_handle_id(best[1]) and rot_axis_best[1] is not None:
        return rot_axis_best[1]
    return best[1]


def _screen_project_point(region, rv3d, world_point):
    try:
        pt = view3d_utils.location_3d_to_region_2d(region, rv3d, world_point)
    except Exception:
        return None
    if pt is None:
        return None
    try:
        return Vector((float(pt.x), float(pt.y)))
    except Exception:
        return None


def _axis_line_touch_point_for_screen_square(region, rv3d, line_start, square_center, half_size, pad_px=0.85):
    """Return the line end so the projected axis line stops at the visible edge
    of the screen-facing square handle instead of passing through its center.

    The scale-axis boxes are drawn as billboards that always face the camera.
    Using the square center as the line end makes the line visually pierce the
    box. This function solves the exact screen-space touch point and maps it
    back onto the 3D axis line.
    """
    try:
        hs = float(half_size)
    except Exception:
        return square_center.copy()
    if hs <= 1.0e-12:
        return square_center.copy()

    start_2d = _screen_project_point(region, rv3d, line_start)
    center_2d = _screen_project_point(region, rv3d, square_center)
    if start_2d is None or center_2d is None:
        return square_center.copy()

    try:
        view_inv = rv3d.view_matrix.inverted().to_3x3()
        vx = view_inv @ Vector((1.0, 0.0, 0.0))
        vy = view_inv @ Vector((0.0, 1.0, 0.0))
    except Exception:
        return square_center.copy()

    px = _screen_project_point(region, rv3d, square_center + vx * hs)
    py = _screen_project_point(region, rv3d, square_center + vy * hs)

    hx = abs(float(px.x - center_2d.x)) if px is not None else 0.0
    hy = abs(float(py.y - center_2d.y)) if py is not None else 0.0

    if hx <= 1.0e-6 and px is not None:
        try:
            hx = float((px - center_2d).length)
        except Exception:
            hx = 0.0
    if hy <= 1.0e-6 and py is not None:
        try:
            hy = float((py - center_2d).length)
        except Exception:
            hy = 0.0

    if hx <= 1.0e-6 and hy <= 1.0e-6:
        return square_center.copy()
    if hx <= 1.0e-6:
        hx = hy
    if hy <= 1.0e-6:
        hy = hx

    hx += max(0.0, float(pad_px))
    hy += max(0.0, float(pad_px))

    dx = float(start_2d.x - center_2d.x)
    dy = float(start_2d.y - center_2d.y)
    if abs(dx) <= 1.0e-9 and abs(dy) <= 1.0e-9:
        return line_start.copy()

    scale = max(abs(dx) / max(hx, 1.0e-9), abs(dy) / max(hy, 1.0e-9))
    if scale <= 1.0:
        return line_start.copy()

    boundary_2d = Vector((center_2d.x + dx / scale, center_2d.y + dy / scale))

    try:
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, (float(boundary_2d.x), float(boundary_2d.y)))
        ray_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, (float(boundary_2d.x), float(boundary_2d.y)))
        hit = geometry_utils.intersect_line_line(
            line_start,
            square_center,
            ray_origin,
            ray_origin + ray_dir * 100000.0,
        )
        if hit:
            point_on_axis = hit[0]
            seg = square_center - line_start
            seg_len_sq = float(seg.length_squared)
            if seg_len_sq > 1.0e-20:
                fac = float((point_on_axis - line_start).dot(seg) / seg_len_sq)
                fac = max(0.0, min(1.0, fac))
                return line_start.lerp(square_center, fac)
    except Exception:
        pass

    try:
        seg = square_center - line_start
        seg_len = float(seg.length)
        if seg_len > 1.0e-12:
            # Conservative world-space fallback: prefer a hair short to avoid
            # the line visually penetrating the box if ray/line solving fails.
            shrink = min(seg_len, hs * 1.05)
            return square_center - seg.normalized() * shrink
    except Exception:
        pass
    return square_center.copy()


def _smart_pointer(value) -> int:
    try:
        return int(value.as_pointer())
    except Exception:
        return 0

def _smart_draw_snapshot_key(window, area, region) -> tuple:
    return (_smart_pointer(window), _smart_pointer(area), _smart_pointer(region))

def _smart_matrix_immutable(matrix) -> tuple:
    return tuple(tuple(float(matrix[row][col]) for col in range(4)) for row in range(4))

def _smart_draw_snapshot_clear() -> None:
    global _SMART_GIZMO_DRAW_SNAPSHOT_BYTES
    _SMART_GIZMO_DRAW_SNAPSHOTS.clear()
    _SMART_GIZMO_DRAW_SNAPSHOT_BYTES = 0
    _SMART_LIVE_XF_CACHE.clear()

def _smart_draw_snapshot_remove(key) -> bool:
    global _SMART_GIZMO_DRAW_SNAPSHOT_BYTES
    snapshot = _SMART_GIZMO_DRAW_SNAPSHOTS.pop(tuple(key), None)
    if snapshot is None:
        return False
    _SMART_GIZMO_DRAW_SNAPSHOT_BYTES = max(
        0, int(_SMART_GIZMO_DRAW_SNAPSHOT_BYTES) - int(getattr(snapshot, 'estimated_bytes', 0) or 0)
    )
    return True

def _smart_draw_snapshot_store(snapshot: _SmartDrawSnapshot) -> bool:
    global _SMART_GIZMO_DRAW_SNAPSHOT_BYTES
    key = tuple(snapshot.key)
    _smart_draw_snapshot_remove(key)
    if int(snapshot.estimated_bytes) > _SMART_GIZMO_DRAW_SNAPSHOT_MAX_BYTES:
        return False
    _SMART_GIZMO_DRAW_SNAPSHOTS[key] = snapshot
    _SMART_GIZMO_DRAW_SNAPSHOTS.move_to_end(key)
    _SMART_GIZMO_DRAW_SNAPSHOT_BYTES += int(snapshot.estimated_bytes)
    while (
        len(_SMART_GIZMO_DRAW_SNAPSHOTS) > _SMART_GIZMO_DRAW_SNAPSHOT_MAX_ENTRIES
        or _SMART_GIZMO_DRAW_SNAPSHOT_BYTES > _SMART_GIZMO_DRAW_SNAPSHOT_MAX_BYTES
    ):
        old_key, old_snapshot = _SMART_GIZMO_DRAW_SNAPSHOTS.popitem(last=False)
        del old_key
        _SMART_GIZMO_DRAW_SNAPSHOT_BYTES = max(
            0,
            int(_SMART_GIZMO_DRAW_SNAPSHOT_BYTES) - int(getattr(old_snapshot, 'estimated_bytes', 0) or 0),
        )
    return key in _SMART_GIZMO_DRAW_SNAPSHOTS

def _smart_vec_tuple(value) -> tuple:
    return (float(value[0]), float(value[1]), float(value[2]))

def _smart_yellow(colors, alpha=1.0):
    value = colors['YELLOW']
    return (float(value[0]), float(value[1]), float(value[2]), max(0.0, min(1.0, float(alpha))))

def _smart_batch_command(
    shader, primitive: str, vertices, color, line_width: float, estimated,
    *, matrix_mode: str = 'WORLD', origin=(0.0, 0.0, 0.0), scale: float = 1.0,
    halo: bool = False, defer: bool = False,
):
    verts = tuple(_smart_vec_tuple(vertex) for vertex in vertices)
    if not verts or len(verts) > 4096:
        return None
    primitive = str(primitive)
    if primitive == 'LINE_LOOP':
        # Vulkan には線の環（line loop）が無く、Blender は LINE_STRIP として描くため
        # 最後の点から最初の点へ戻る辺（□では左辺）が落ちる。始点を末尾に足した
        # LINE_STRIP で閉じれば、OpenGL・Vulkan のどちらでも同じ輪郭になる。
        if len(verts) >= 3:
            verts = verts + (verts[0],)
        primitive = 'LINE_STRIP'
    if defer:
        # まとめる前の形だけを返す（batch は _smart_pack_draw_commands で作る）。
        return _SmartDrawCommand(
            None,
            tuple(float(v) for v in color),
            float(line_width),
            str(matrix_mode or 'WORLD'),
            _smart_vec_tuple(origin),
            float(scale),
            bool(halo),
            False,
            primitive,
            verts,
        )
    batch = batch_for_shader(shader, primitive, {'pos': verts})
    estimated[0] += len(verts) * 12 + 208
    return _SmartDrawCommand(
        batch,
        tuple(float(v) for v in color),
        float(line_width),
        str(matrix_mode or 'WORLD'),
        _smart_vec_tuple(origin),
        float(scale),
        bool(halo),
    )


# 線の帯（LINE_STRIP）は LINES に、扇（TRI_FAN）は TRIS に開いても、描かれる画素は同じ
# （太い線は帯でも 1 本ずつ描かれる。OpenGL の画面外の描画で幅 1・2・3 と半透明で同じ画素を確かめた）。
_SMART_PACK_PRIMITIVE_CLASS = {'LINES': 'LINES', 'LINE_STRIP': 'LINES', 'TRIS': 'TRIS', 'TRI_FAN': 'TRIS'}


def _smart_pack_open_primitive(primitive, verts):
    if primitive == 'LINE_STRIP':
        out = []
        for index in range(len(verts) - 1):
            out.append(verts[index])
            out.append(verts[index + 1])
        return out
    if primitive == 'TRI_FAN':
        out = []
        for index in range(1, len(verts) - 1):
            out.append(verts[0])
            out.append(verts[index])
            out.append(verts[index + 1])
        return out
    return list(verts)


def _smart_pack_draw_commands(parts, estimated):
    """Pack the deferred commands into a few per-vertex-color batches.

    描画の 1 コマの重さの大半は batch.draw の回数（1 回 約 11 µs）なので、ハンドルの命令を
    層ごとにまとめる：塗り（線より前の三角形）→ 縁取り（AA の淡い線）→ 線 → 線より後の三角形（矢の先）。
    層の中の順番と、各ハンドルの中の塗り→縁取り→線→先の順は前と同じ。ホバーしたハンドルは前と同じく
    最後に描く（parts の最後）。画面に向く板（BILLBOARD）は中心ごとにまとめ、大きさは頂点に掛けておく。
    まとめられない時は None を返し、呼び元は前と同じ 1 命令 1 batch で作る。
    """
    shader = gpu.shader.from_builtin('FLAT_COLOR')
    packed = []
    for part in parts:
        buckets = {}
        order = []
        for group in part:
            seen_line = False
            for command in group:
                prim_class = _SMART_PACK_PRIMITIVE_CLASS.get(command.primitive)
                if prim_class is None:
                    return None
                if prim_class == 'LINES':
                    seen_line = True
                    layer = 1 if command.halo else 2
                else:
                    layer = 3 if seen_line else 0
                verts = _smart_pack_open_primitive(command.primitive, command.verts)
                if not verts:
                    continue
                if command.matrix_mode == 'BILLBOARD':
                    scale = float(command.scale)
                    verts = [(v[0] * scale, v[1] * scale, v[2] * scale) for v in verts]
                    place = (1, tuple(command.origin))
                elif command.matrix_mode == 'WORLD':
                    place = (0, None)
                else:
                    return None
                key = (place, layer, float(command.line_width), prim_class)
                bucket = buckets.get(key)
                if bucket is None:
                    bucket = buckets[key] = ([], [])
                    order.append(key)
                bucket[0].extend(verts)
                bucket[1].extend([command.color] * len(verts))
        # 世界の層を先に、板は中心の出てきた順に。どちらも層の番号の順で、同じ層の中は出てきた順。
        place_rank = {}
        first_seen = {}
        for index, key in enumerate(order):
            place_rank.setdefault(key[0], len(place_rank))
            first_seen[key] = index
        order.sort(key=lambda k: (k[0][0], place_rank[k[0]], k[1], first_seen[k]))
        for key in order:
            (kind, origin), layer, width, prim_class = key
            verts, colors = buckets[key]
            batch = batch_for_shader(shader, prim_class, {'pos': verts, 'color': colors})
            estimated[0] += len(verts) * 28 + 208
            packed.append(_SmartDrawCommand(
                batch,
                tuple(colors[0]),
                width,
                'BILLBOARD' if kind == 1 else 'WORLD',
                origin if kind == 1 else (0.0, 0.0, 0.0),
                1.0,
                layer == 1,
                True,
            ))
    return shader, tuple(packed)

def _smart_billboard_axes(rv3d):
    view_inv = rv3d.view_matrix.inverted().to_3x3()
    right = (view_inv @ Vector((1.0, 0.0, 0.0))).normalized()
    up = (view_inv @ Vector((0.0, 1.0, 0.0))).normalized()
    forward = (view_inv @ Vector((0.0, 0.0, 1.0))).normalized()
    return right, up, forward

def _smart_ring_points(center, normal, radius, segments=64):
    n = Vector(normal).normalized()
    ref = Vector((1.0, 0.0, 0.0)) if abs(float(n.x)) < 0.85 else Vector((0.0, 1.0, 0.0))
    u = n.cross(ref)
    if u.length_squared <= 1.0e-16:
        ref = Vector((0.0, 0.0, 1.0))
        u = n.cross(ref)
    u.normalize()
    v = n.cross(u).normalized()
    return tuple(
        center + (u * math.cos((2.0 * math.pi * index) / segments) + v * math.sin((2.0 * math.pi * index) / segments)) * radius
        for index in range(segments)
    )

def _smart_cone_triangles(base_center, tip, axis, radius, segments=14):
    n = Vector(axis).normalized()
    ref = Vector((1.0, 0.0, 0.0)) if abs(float(n.x)) < 0.85 else Vector((0.0, 1.0, 0.0))
    u = n.cross(ref)
    if u.length_squared <= 1.0e-16:
        ref = Vector((0.0, 0.0, 1.0))
        u = n.cross(ref)
    u.normalize()
    v = n.cross(u).normalized()
    ring = [
        base_center + (u * math.cos((2.0 * math.pi * index) / segments) + v * math.sin((2.0 * math.pi * index) / segments)) * radius
        for index in range(segments)
    ]
    vertices = []
    for index in range(segments):
        vertices.extend((tip, ring[index], ring[(index + 1) % segments]))
    return tuple(vertices)

def _smart_build_draw_snapshot(context, window, area, region, rv3d, generation: int):
    """Build all Object/EditMesh-dependent geometry and GPU batches outside Draw."""
    key = _smart_draw_snapshot_key(window, area, region)
    if 0 in key:
        return None
    geo = _smart_gizmo_geometry(context, region, rv3d)
    if not geo:
        if _smart_runtime_activity_active():
            geo = _smart_last_good_geometry(context, allow_without_selection=True)
        else:
            return None
    if not geo:
        return None
    shader = cu._csdt_get_shader_3d_uniform()
    if shader is None:
        return None
    # View/projection matrices are intentionally not cached in the snapshot.
    # The exact RegionView3D matrices are read at every POST_PIXEL redraw.
    view_matrix = ()
    projection_matrix = ()

    kind = str(geo['kind'])
    pivot = Vector(geo['pivot']).copy()
    ax, ay, az = (Vector(axis).normalized() for axis in geo['axes'])
    rotation_axis_mask = tuple(bool(value) for value in geo.get('rotation_axis_mask', (True, True, True)))
    rotation_axis_any = any(rotation_axis_mask)
    plane_scale = float(geo['plane_scale'])
    colors = _smart_colors()
    prefs = cu._prefs(context)
    aa_mode = str(getattr(prefs, 'overlay_aa_mode', 'AA_2PASS') or 'AA_2PASS') if prefs else 'AA_2PASS'
    # 縁取りの有無をビュー操作で変えない。ビュー操作の間は再生の側で淡い線を飛ばすので、
    # ビュー操作のたびに材料（GPU の batch）を作り直さずに済む。
    use_2pass_aa = bool(aa_mode == 'AA_2PASS')
    hover = (
        getattr(cg, '_CSDT_DRAG_ACTIVE_ID', None)
        or getattr(cg, '_SMART_GIZMO_LOCKED_ID', None)
        or getattr(cg, '_SMART_GIZMO_HOVER_ID', None)
    )
    show_move = True
    show_rotate = True
    show_scale = True
    if prefs and kind == 'TRANSFORM':
        show_move = bool(getattr(prefs, 'smart_gizmo_transform_show_move', True))
        show_rotate = bool(getattr(prefs, 'smart_gizmo_transform_show_rotate', True))
        show_scale = bool(getattr(prefs, 'smart_gizmo_transform_show_scale', True))

    groups = []
    estimated = [512]

    def axis_color(axis_key, handle_id, alpha=1.0):
        if hover == handle_id:
            return _smart_yellow(colors, alpha)
        base = colors[axis_key]
        return (float(base[0]), float(base[1]), float(base[2]), float(alpha))

    def add_command(
        bucket, primitive, vertices, color, width=2.0,
        *, matrix_mode='WORLD', origin=(0.0, 0.0, 0.0), scale=1.0, halo=False,
    ):
        if len(bucket) >= _SMART_GIZMO_DRAW_SNAPSHOT_MAX_COMMANDS:
            raise RuntimeError('Smart Gizmo snapshot command budget exceeded')
        if float(color[3]) <= 0.001:
            return
        command = _smart_batch_command(
            shader, primitive, vertices, color, width, estimated,
            matrix_mode=matrix_mode, origin=origin, scale=scale, halo=halo, defer=True,
        )
        if command is not None:
            bucket.append(command)

    def add_line(bucket, a, b, color, width=2.0):
        if use_2pass_aa:
            add_command(bucket, 'LINES', (a, b), (color[0], color[1], color[2], color[3] * 0.18), width + 1.0, halo=True)
        add_command(bucket, 'LINES', (a, b), color, width)

    def add_loop(bucket, points, color, width=2.0):
        if use_2pass_aa:
            add_command(bucket, 'LINE_LOOP', points, (color[0], color[1], color[2], color[3] * 0.18), width + 1.0, halo=True)
        add_command(bucket, 'LINE_LOOP', points, color, width)

    def add_quad(bucket, p0, p1, p2, p3, color):
        add_command(bucket, 'TRIS', (p0, p1, p2, p0, p2, p3), color, 0.0)

    def _unit_circle_points(segments=64):
        return tuple(
            Vector((
                math.cos((2.0 * math.pi * index) / segments),
                math.sin((2.0 * math.pi * index) / segments),
                0.0,
            ))
            for index in range(segments)
        )

    def add_billboard_loop(bucket, center, radius, color, width=2.0):
        points = _unit_circle_points(64)
        if use_2pass_aa:
            add_command(
                bucket, 'LINE_LOOP', points,
                (color[0], color[1], color[2], color[3] * 0.18),
                width + 1.0, matrix_mode='BILLBOARD', origin=center, scale=radius, halo=True,
            )
        add_command(
            bucket, 'LINE_LOOP', points, color, width,
            matrix_mode='BILLBOARD', origin=center, scale=radius,
        )

    def add_billboard_circle(bucket, center, radius, fill, outline):
        points = _unit_circle_points(64)
        if float(fill[3]) > 0.001:
            add_command(
                bucket, 'TRI_FAN',
                (Vector((0.0, 0.0, 0.0)),) + points + (points[0],),
                fill, 0.0, matrix_mode='BILLBOARD', origin=center, scale=radius,
            )
        add_billboard_loop(bucket, center, radius, outline, 2.0)

    def add_billboard_square(bucket, center, half_size, fill, outline):
        p0 = Vector((-1.0, -1.0, 0.0))
        p1 = Vector((1.0, -1.0, 0.0))
        p2 = Vector((1.0, 1.0, 0.0))
        p3 = Vector((-1.0, 1.0, 0.0))
        add_command(
            bucket, 'TRIS', (p0, p1, p2, p0, p2, p3), fill, 0.0,
            matrix_mode='BILLBOARD', origin=center, scale=half_size,
        )
        if use_2pass_aa:
            add_command(
                bucket, 'LINE_LOOP', (p0, p1, p2, p3),
                (outline[0], outline[1], outline[2], outline[3] * 0.18),
                3.0, matrix_mode='BILLBOARD', origin=center, scale=half_size, halo=True,
            )
        add_command(
            bucket, 'LINE_LOOP', (p0, p1, p2, p3), outline, 2.0,
            matrix_mode='BILLBOARD', origin=center, scale=half_size,
        )

    def add_group(handle_id, builder):
        bucket = []
        builder(bucket)
        if bucket:
            groups.append((str(handle_id), tuple(bucket)))

    if kind in {'MOVE', 'TRANSFORM'} and show_move:
        for axis_u, axis_v, edge_u, edge_v, handle_id in (
            (ax, ay, 'Y', 'X', 'MOVE_XY'),
            (ay, az, 'Z', 'Y', 'MOVE_YZ'),
            (ax, az, 'Z', 'X', 'MOVE_XZ'),
        ):
            def build_plane(bucket, axis_u=axis_u, axis_v=axis_v, edge_u=edge_u, edge_v=edge_v, handle_id=handle_id):
                p0, p1, p2, p3 = _smart_plane_handle_points(pivot, axis_u, axis_v, plane_scale)
                hovered = hover == handle_id
                fill = _smart_yellow(colors, 0.10) if hovered else (0.70, 0.70, 0.70, 0.06)
                add_quad(bucket, p0, p1, p2, p3, fill)
                add_line(bucket, p3, p2, _smart_yellow(colors, 1.0) if hovered else colors[edge_u])
                add_line(bucket, p1, p2, _smart_yellow(colors, 1.0) if hovered else colors[edge_v])
            add_group(handle_id, build_plane)

        def build_move_center(bucket):
            hovered = hover == 'MOVE_CENTER'
            fill = _smart_yellow(colors, 0.10) if hovered else (1.0, 1.0, 1.0, 0.05)
            outline = _smart_yellow(colors, 1.0) if hovered else (colors['WHITE'][0], colors['WHITE'][1], colors['WHITE'][2], 0.92)
            add_billboard_circle(bucket, pivot, float(geo['center_radius']), fill, outline)
        add_group('MOVE_CENTER', build_move_center)

        for axis_key, axis, handle_id in (('X', ax, 'MOVE_X'), ('Y', ay, 'MOVE_Y'), ('Z', az, 'MOVE_Z')):
            def build_axis(bucket, axis_key=axis_key, axis=axis, handle_id=handle_id):
                arrow_scale = float(geo['uniform_scale'])
                head_len = arrow_scale * 0.144
                head_radius = head_len * 0.35
                shaft_len = max(0.0, float(geo['axis_len']) - head_len)
                start_offset = max(float(geo['center_radius']) * 1.10, plane_scale * 0.28)
                color = axis_color(axis_key, handle_id)
                add_line(bucket, pivot + axis * start_offset, pivot + axis * shaft_len, color)
                add_command(bucket, 'TRIS', _smart_cone_triangles(pivot + axis * shaft_len, pivot + axis * float(geo['axis_len']), axis, head_radius), color, 0.0)
            add_group(handle_id, build_axis)

    if kind in {'ROTATE', 'TRANSFORM'} and show_rotate:
        radius = float(geo.get('rotate_radius', 0.0))
        if radius > 0.0:
            if rotation_axis_any:
                def build_free_rotation(bucket):
                    hovered = hover == 'ROT_FREE_X'
                    fill = _smart_yellow(colors, 0.08) if hovered else (1.0, 1.0, 1.0, 0.035)
                    outline = _smart_yellow(colors, 0.95) if hovered else (1.0, 1.0, 1.0, 0.28)
                    add_billboard_circle(bucket, pivot, radius * 0.98, fill, outline)
                add_group('ROT_FREE_X', build_free_rotation)
            for axis_index, (axis_key, axis, handle_id) in enumerate((('X', ax, 'ROT_X'), ('Y', ay, 'ROT_Y'), ('Z', az, 'ROT_Z'))):
                if not rotation_axis_mask[axis_index]:
                    continue
                def build_ring(bucket, axis_key=axis_key, axis=axis, handle_id=handle_id):
                    add_loop(bucket, _smart_ring_points(pivot, axis, radius), axis_color(axis_key, handle_id), 2.0)
                add_group(handle_id, build_ring)
        view_radius = float(geo.get('rotate_radius_view', radius * 1.2))
        if view_radius > 0.0 and rotation_axis_any:
            def build_view_ring(bucket):
                # Build a canonical ring once.  Its live screen-facing basis is
                # resolved from the current RegionView3D in Draw.
                add_billboard_loop(
                    bucket, pivot, view_radius, axis_color('WHITE', 'ROT_VIEW'), 2.0
                )
            add_group('ROT_VIEW', build_view_ring)

    if kind in {'SCALE', 'TRANSFORM'} and show_scale:
        def build_uniform_scale(bucket):
            hovered = hover == 'SCALE_UNIFORM'
            if kind == 'TRANSFORM':
                radius = float(geo.get('scale_ring_outer', float(geo['center_radius']) * 2.0))
                fill = _smart_yellow(colors, 0.06) if hovered else (1.0, 1.0, 1.0, 0.02)
                outline = _smart_yellow(colors, 1.0) if hovered else (1.0, 1.0, 1.0, 0.85)
                add_billboard_circle(bucket, pivot, radius, fill, outline)
            else:
                radius = float(_scale_uniform_free_handle_radius(geo, kind)) * 0.85
                fill = _smart_yellow(colors, 0.12) if hovered else (1.0, 1.0, 1.0, 0.06)
                outline = _smart_yellow(colors, 1.0) if hovered else (1.0, 1.0, 1.0, 0.92)
                add_billboard_square(bucket, pivot, radius, fill, outline)
        add_group('SCALE_UNIFORM', build_uniform_scale)

        for axis_u, axis_v, key_u, key_v, handle_id in (
            (ax, ay, 'X', 'Y', 'SCALE_XY'),
            (ay, az, 'Y', 'Z', 'SCALE_YZ'),
            (ax, az, 'X', 'Z', 'SCALE_XZ'),
        ):
            def build_scale_plane(bucket, axis_u=axis_u, axis_v=axis_v, key_u=key_u, key_v=key_v, handle_id=handle_id):
                hovered = hover == handle_id
                if kind == 'TRANSFORM':
                    offset = float(geo.get('scale_plane_offset', plane_scale * 0.42))
                    half = float(geo.get('scale_plane_half', plane_scale * 0.085))
                    center = pivot + axis_u * offset + axis_v * offset
                    p0 = center + (-axis_u - axis_v) * half
                    p1 = center + (axis_u - axis_v) * half
                    p2 = center + (axis_u + axis_v) * half
                    p3 = center + (-axis_u + axis_v) * half
                else:
                    p0, p1, p2, p3 = _smart_plane_handle_points(pivot, axis_u, axis_v, plane_scale * 0.85)
                fill = _smart_yellow(colors, 0.10) if hovered else (0.75, 0.75, 0.75, 0.05)
                add_quad(bucket, p0, p1, p2, p3, fill)
                color_u = _smart_yellow(colors, 1.0) if hovered else colors[key_u]
                color_v = _smart_yellow(colors, 1.0) if hovered else colors[key_v]
                add_line(bucket, p0, p1, color_u)
                add_line(bucket, p1, p2, color_u)
                add_line(bucket, p2, p3, color_v)
                add_line(bucket, p3, p0, color_v)
            add_group(handle_id, build_scale_plane)

        for axis_key, axis, handle_id in (('X', ax, 'SCALE_X'), ('Y', ay, 'SCALE_Y'), ('Z', az, 'SCALE_Z')):
            def build_scale_axis(bucket, axis_key=axis_key, axis=axis, handle_id=handle_id):
                hovered = hover == handle_id
                color = axis_color(axis_key, handle_id)
                length = float(geo.get('scale_len_outer' if kind == 'TRANSFORM' else 'scale_len', geo['axis_len']))
                half = float(geo.get('scale_cube', geo['center_radius'])) * (0.98 if kind == 'TRANSFORM' else 0.90)
                tip = pivot + axis * length
                if kind != 'TRANSFORM':
                    # View-independent conservative endpoint.  The screen-facing
                    # square itself uses the live billboard basis in Draw.
                    line_end = tip - axis.normalized() * min(length, half * 1.05)
                    add_line(bucket, pivot, line_end, color)
                fill = _smart_yellow(colors, 0.22) if hovered else (color[0], color[1], color[2], 0.28)
                outline = _smart_yellow(colors, 1.0) if hovered else (color[0], color[1], color[2], 0.98)
                add_billboard_square(bucket, tip, half, fill, outline)
            add_group(handle_id, build_scale_axis)

    parts = (
        [commands for handle_id, commands in groups if handle_id != hover],
        [commands for handle_id, commands in groups if handle_id == hover],
    )
    count = sum(len(commands) for part in parts for commands in part)
    if not count or count > _SMART_GIZMO_DRAW_SNAPSHOT_MAX_COMMANDS:
        return None
    packed = None
    estimated_before = estimated[0]
    try:
        packed = _smart_pack_draw_commands(parts, estimated)
    except Exception:
        packed = None
    if packed is None:
        estimated[0] = estimated_before
    if packed is not None:
        shader, ordered = packed
    else:
        # まとめられない時は前と同じ形（1 命令 1 batch・色は uniform）で作る。
        ordered = []
        for part in parts:
            for commands in part:
                for raw in commands:
                    built = _smart_batch_command(
                        shader, raw.primitive, raw.verts, raw.color, raw.line_width, estimated,
                        matrix_mode=raw.matrix_mode, origin=raw.origin, scale=raw.scale, halo=raw.halo,
                    )
                    if built is not None:
                        ordered.append(built)
        ordered = tuple(ordered)
    if not ordered:
        return None
    return _SmartDrawSnapshot(
        int(generation),
        key,
        view_matrix,
        projection_matrix,
        _smart_vec_tuple(pivot),
        tuple(_smart_vec_tuple(axis) for axis in (ax, ay, az)),
        str(geo.get('orient_type', 'GLOBAL') or 'GLOBAL'),
        max(1.0e-9, float(geo.get('reference_world_scale', geo.get('uniform_scale', 1.0)) or 1.0)),
        max(1.0e-9, float(geo.get('screen_scale', 1.0) or 1.0)),
        shader,
        tuple(ordered),
        int(estimated[0]),
        float(time.perf_counter()),
    )


def _smart_rebuild_draw_snapshot_for_slot(context, window, area, region, rv3d=None) -> bool:
    if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)) or not _event_runtime_pref_enabled(context):
        return False
    if area is None or region is None or getattr(area, 'type', None) != 'VIEW_3D' or getattr(region, 'type', None) != 'WINDOW':
        return False
    if rv3d is None:
        rv3d = cu._view3d_region_data(area, region)
    key = _smart_draw_snapshot_key(window, area, region)
    if rv3d is None:
        _smart_draw_snapshot_remove(key)
        return False
    generation = int(_SMART_GIZMO_SNAPSHOT_GENERATION)
    snapshot = None
    try:
        if hasattr(bpy.context, 'temp_override'):
            kwargs = {'area': area, 'region': region}
            if window is not None:
                kwargs['window'] = window
                screen = getattr(window, 'screen', None)
                if screen is not None:
                    kwargs['screen'] = screen
                workspace = getattr(window, 'workspace', None)
                if workspace is not None:
                    kwargs['workspace'] = workspace
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            if space is not None:
                kwargs['space_data'] = space
            kwargs['region_data'] = rv3d
            with bpy.context.temp_override(**kwargs):
                snapshot = _smart_build_draw_snapshot(
                    bpy.context, window, area, region, rv3d, generation
                )
        else:
            snapshot = _smart_build_draw_snapshot(
                context or bpy.context, window, area, region, rv3d, generation
            )
    except Exception:
        _smart_draw_snapshot_remove(key)
        return False
    if snapshot is None:
        _smart_draw_snapshot_remove(key)
        return False
    return _smart_draw_snapshot_store(snapshot)


def _smart_rebuild_draw_snapshot_for_context(context=None, area=None, region=None) -> bool:
    context = context or getattr(bpy, 'context', None)
    if context is None:
        return False
    area = area or getattr(context, 'area', None)
    region = region or getattr(context, 'region', None)
    window = getattr(context, 'window', None)
    return _smart_rebuild_draw_snapshot_for_slot(context, window, area, region)


def _smart_rebuild_all_draw_snapshots(context=None, *, max_slots: int = 32) -> int:
    """Finite event-side rebuild. No callback reschedules itself while idle."""
    context = context or getattr(bpy, 'context', None)
    wm = getattr(context, 'window_manager', None) if context is not None else None
    if wm is None:
        return 0
    live_keys = set()
    built = 0
    for window in tuple(getattr(wm, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            for region in tuple(getattr(area, 'regions', ()) or ()):
                if getattr(region, 'type', None) != 'WINDOW':
                    continue
                key = _smart_draw_snapshot_key(window, area, region)
                live_keys.add(key)
                if built >= max(1, int(max_slots)):
                    break
                if _smart_rebuild_draw_snapshot_for_slot(context, window, area, region):
                    built += 1
            if built >= max(1, int(max_slots)):
                break
        if built >= max(1, int(max_slots)):
            break
    for key in tuple(_SMART_GIZMO_DRAW_SNAPSHOTS):
        if key not in live_keys:
            _smart_draw_snapshot_remove(key)
    return built


def _smart_current_draw_matrices(rv3d):
    """Return live matrices for the exact View3D redraw boundary."""
    if rv3d is None:
        raise RuntimeError('Smart Gizmo draw requires a live RegionView3D')
    return rv3d.view_matrix.copy(), rv3d.window_matrix.copy()


def _smart_snapshot_basis_matrix(axes):
    """Return an orthonormal basis whose columns are the snapshot X/Y/Z axes."""
    try:
        values = tuple(Vector(axis).normalized() for axis in tuple(axes or ())[:3])
        if len(values) != 3:
            raise ValueError('Smart Gizmo snapshot basis requires three axes')
        matrix = Matrix(values).transposed()
        if abs(float(matrix.determinant())) <= 1.0e-12:
            raise ValueError('Smart Gizmo snapshot basis is singular')
        return matrix
    except Exception:
        return Matrix.Identity(3)


def _smart_project_world_to_region(view_matrix, projection_matrix, region, point):
    """Project one world point using only the current draw matrices and region size."""
    try:
        width = float(getattr(region, 'width', 0) or 0)
        height = float(getattr(region, 'height', 0) or 0)
        if width <= 0.0 or height <= 0.0:
            return None
        p = Vector((float(point[0]), float(point[1]), float(point[2]), 1.0))
        clip = projection_matrix @ (view_matrix @ p)
        w = float(clip[3])
        if not math.isfinite(w) or abs(w) <= 1.0e-12:
            return None
        x = float(clip[0]) / w
        y = float(clip[1]) / w
        if not (math.isfinite(x) and math.isfinite(y)):
            return None
        return ((x * 0.5 + 0.5) * width, (y * 0.5 + 0.5) * height)
    except Exception:
        return None


def _smart_live_world_scale(
    region, view_matrix, projection_matrix, pivot, axes,
    *, reference_scale: float, screen_scale: float, start_scale=None,
) -> float:
    """Resolve the current world length for the configured fixed screen size.

    This is deliberately evaluated in Draw from the exact RegionView3D matrices.
    It performs only small matrix/vector arithmetic; it never reads scene/object
    data and never rebuilds a GPU batch.
    """
    try:
        axes = tuple(axes or ())[:3]
        if len(axes) != 3:
            raise ValueError('Smart Gizmo live scale requires three axes')
        target_px = max(1.0, 120.0 * max(1.0e-9, float(screen_scale)))
        fallback = max(1.0e-9, float(reference_scale))
        width = float(getattr(region, 'width', 0) or 0)
        height = float(getattr(region, 'height', 0) or 0)
        if width <= 0.0 or height <= 0.0:
            return fallback
        half_w = 0.5 * width
        half_h = 0.5 * height
        isfinite = math.isfinite
        # 同次座標の写しは位置について一次：clip(中心 + 軸 × s) = clip(中心) + s × clip(軸の向き)。
        # 単位にした 3 つの軸と中心を列に並べた 1 つの行列を 1 回だけ写す（前は Vector を作って点ごとに写していた）。
        px = float(pivot[0])
        py = float(pivot[1])
        pz = float(pivot[2])
        cols = []
        for axis in axes:
            ax = float(axis[0])
            ay = float(axis[1])
            az = float(axis[2])
            norm = math.sqrt(ax * ax + ay * ay + az * az)
            if norm > 0.0 and isfinite(norm):
                cols.append((ax / norm, ay / norm, az / norm))
            else:
                cols.append((0.0, 0.0, 0.0))
        (a0x, a0y, a0z), (a1x, a1y, a1z), (a2x, a2y, a2z) = cols
        clip = projection_matrix @ view_matrix @ Matrix((
            (a0x, a1x, a2x, px),
            (a0y, a1y, a2y, py),
            (a0z, a1z, a2z, pz),
            (0.0, 0.0, 0.0, 1.0),
        ))
        d0x, d1x, d2x, c0x = clip[0]
        d0y, d1y, d2y, c0y = clip[1]
        d0w, d1w, d2w, c0w = clip[3]
        if not isfinite(c0w) or abs(c0w) <= 1.0e-12:
            return fallback
        if not (isfinite(c0x / c0w) and isfinite(c0y / c0w)):
            return fallback
        directions = ((d0x, d0y, d0w), (d1x, d1y, d1w), (d2x, d2y, d2w))
        # 閉じた式：軸 i の先の画面の長さは L_i(s) = s·|K_i| / (w0·(w0 + s·dw_i))（s について単調に増える）。
        # K_i = (半幅·(dx_i·w0 − x0·dw_i), 半高·(dy_i·w0 − y0·dw_i))。L_i(s) = 目標 を解くと
        # s_i = 目標·w0² / (|K_i| − 目標·w0·dw_i)（分母が正の軸だけ）で、最も長い軸が目標になる s は s_i の最小。
        # 繰り返しの不動点と同じ値で、繰り返しが要らない。先が中心の深さの 1/1000 より手前まで来る解や、
        # 中心が手前に無い時は、前と同じ繰り返しに任せる。
        if c0w > 0.0:
            target_w = target_px * c0w
            closed = None
            closed_ok = True
            for dxc, dyc, dwc in directions:
                k_len = math.hypot(half_w * (dxc * c0w - c0x * dwc), half_h * (dyc * c0w - c0y * dwc))
                denom = k_len - target_w * dwc
                if not (isfinite(k_len) and isfinite(denom)):
                    closed_ok = False
                    break
                if denom <= 1.0e-12 or k_len <= 1.0e-12:
                    continue
                if k_len < 1.0e-3 * denom:
                    closed_ok = False
                    break
                s_axis = target_w * c0w / denom
                if closed is None or s_axis < closed:
                    closed = s_axis
            if closed_ok and closed is not None and isfinite(closed) and closed > 1.0e-12:
                return max(1.0e-9, min(1.0e12, closed))
        # 閉じた式が使えない時だけ繰り返す。前のコマの答えから始め、答えは前と同じ許し（0.25px）の内。
        base = fallback
        if start_scale is not None:
            try:
                start = float(start_scale)
                if isfinite(start) and 1.0e-9 <= start <= 1.0e12:
                    base = start
            except (TypeError, ValueError):
                pass
        pivot_sx = (c0x / c0w + 1.0) * half_w
        pivot_sy = (c0y / c0w + 1.0) * half_h
        for _iteration in range(3):
            lengths = []
            for dxc, dyc, dwc in directions:
                w = c0w + base * dwc
                if not isfinite(w) or abs(w) <= 1.0e-12:
                    continue
                x = (c0x + base * dxc) / w
                y = (c0y + base * dyc) / w
                if not (isfinite(x) and isfinite(y)):
                    continue
                dx = (x + 1.0) * half_w - pivot_sx
                dy = (y + 1.0) * half_h - pivot_sy
                length = math.hypot(dx, dy)
                if isfinite(length) and length > 1.0e-6:
                    lengths.append(length)
            if not lengths:
                return base
            max_length = max(lengths)
            next_base = base * (target_px / max_length)
            if not math.isfinite(next_base) or next_base <= 1.0e-12:
                return base
            next_base = max(1.0e-9, min(1.0e12, next_base))
            base = next_base
            if abs(max_length - target_px) <= 0.25:
                break
        return base
    except Exception:
        try:
            return max(1.0e-9, float(reference_scale))
        except Exception:
            return 1.0


# 材料ごとに変わらない値（中心・元の軸の行列とその逆）と、前のコマの大きさ（次の繰り返しの始まり）。
# 材料そのもの（GPU の batch）は持たない。鍵は材料の鍵で、同じ材料かは id・作った時刻・世代で確かめる。
_SMART_LIVE_XF_CACHE = {}


def _smart_live_snapshot_static(snapshot):
    key = tuple(getattr(snapshot, 'key', ()) or ())
    ident = (
        id(snapshot),
        float(getattr(snapshot, 'built_at', 0.0) or 0.0),
        int(getattr(snapshot, 'generation', 0) or 0),
    )
    entry = _SMART_LIVE_XF_CACHE.get(key)
    if entry is not None and entry['ident'] == ident:
        return entry
    pivot = Vector(getattr(snapshot, 'pivot', (0.0, 0.0, 0.0)))
    reference_basis = _smart_snapshot_basis_matrix(getattr(snapshot, 'axes', ()))
    try:
        post = reference_basis.inverted().to_4x4() @ Matrix.Translation(-pivot)
    except Exception:
        post = None
    entry = {
        'ident': ident,
        'pivot': pivot,
        'basis': reference_basis,
        'axes': tuple(reference_basis.col[index].normalized() for index in range(3)),
        'post': post,
        'scale': None,
    }
    if len(_SMART_LIVE_XF_CACHE) >= 32:
        _SMART_LIVE_XF_CACHE.clear()
    _SMART_LIVE_XF_CACHE[key] = entry
    return entry


def _smart_live_snapshot_transform(snapshot, region, rv3d, view_matrix, projection_matrix):
    """Map immutable event-built geometry into the current draw-time view frame."""
    # 中心・元の軸の行列・その逆は材料ごとに 1 回だけ求める（前は描画のたびに作り直していた）。
    static = _smart_live_snapshot_static(snapshot)
    pivot = static['pivot']
    reference_basis = static['basis']
    live_basis = reference_basis
    orient_type = str(getattr(snapshot, 'orient_type', 'GLOBAL') or 'GLOBAL')
    # 追従の状態は 1 回だけ読む（前は位置と変形で 2 回、実行中のモーダルを調べていた）。
    follow_target, follow_axes, follow_deform = _smart_live_follow_all()
    live_pivot = Vector(follow_target) if follow_target is not None else pivot
    if orient_type in {'VIEW', 'WORKPLANE'}:
        current_basis = _smart_view_basis_matrix_from_rv3d(rv3d)
        if current_basis is not None:
            live_basis = current_basis
    elif follow_axes is not None:
        live_basis = _smart_snapshot_basis_matrix(follow_axes)
    if live_basis is reference_basis:
        live_axes = static['axes']
    else:
        live_axes = tuple(live_basis.col[index].normalized() for index in range(3))
    reference_scale = max(
        1.0e-9, float(getattr(snapshot, 'reference_world_scale', 1.0) or 1.0)
    )
    screen_scale = max(
        1.0e-9, float(getattr(snapshot, 'screen_scale', 1.0) or 1.0)
    )
    live_scale = _smart_live_world_scale(
        region,
        view_matrix,
        projection_matrix,
        live_pivot,
        live_axes,
        reference_scale=reference_scale,
        screen_scale=screen_scale,
        start_scale=static['scale'],
    )
    static['scale'] = live_scale
    ratio = max(1.0e-9, min(1.0e9, float(live_scale) / reference_scale))
    if follow_deform is None and live_basis is reference_basis:
        # 軸が元のままなら、軸の行列とその逆は一様な拡大を挟んで打ち消し合い
        # （T(c)·B·S(r)·B⁻¹·T(−p) = T(c)·S(r)·T(−p)）、中心の周りの拡大だけが残る。
        # 逆が無い時の前の式（T(c)·S(r)·T(−p)）とも同じ。行列を 4 つ作って 3 回掛けるのをやめる。
        shift = 1.0 - ratio
        if live_pivot is pivot:
            tx = float(pivot[0]) * shift
            ty = float(pivot[1]) * shift
            tz = float(pivot[2]) * shift
        else:
            tx = float(live_pivot[0]) - ratio * float(pivot[0])
            ty = float(live_pivot[1]) - ratio * float(pivot[1])
            tz = float(live_pivot[2]) - ratio * float(pivot[2])
        transform = Matrix((
            (ratio, 0.0, 0.0, tx),
            (0.0, ratio, 0.0, ty),
            (0.0, 0.0, ratio, tz),
            (0.0, 0.0, 0.0, 1.0),
        ))
        return transform, ratio
    live_frame = live_basis
    if follow_deform is not None:
        try:
            live_frame = Matrix(follow_deform) @ live_basis
        except Exception:
            live_frame = live_basis
    try:
        post = static['post']
        if post is None:
            raise ValueError('Smart Gizmo snapshot basis has no inverse')
        transform = (
            Matrix.Translation(live_pivot)
            @ live_frame.to_4x4()
            @ Matrix.Scale(ratio, 4)
            @ post
        )
    except Exception:
        transform = Matrix.Translation(live_pivot) @ Matrix.Scale(ratio, 4) @ Matrix.Translation(-pivot)
    return transform, ratio


def _smart_grs_follow_owner_alive() -> bool:
    try:
        owner = _SMART_GIZMO_LIVE_FOLLOW_OWNER
        return owner is not None and bool(getattr(owner, '_in_modal', False))
    except Exception:
        # The modal operator was freed without reaching its finish path.
        return False


def _smart_native_follow_live():
    """Return the native drag follow until the drag end has been processed.

    The follow stays valid after the modal is gone until the drag tick (or the
    depsgraph handler) re-snapshotted the confirmed data, so the confirm frame
    never falls back to the press-time snapshot.  A native drag the depsgraph
    does not report (Armature Edit mode) is started here, from its first redraw.
    """
    state = _SMART_NATIVE_FOLLOW
    if state is not None and _SMART_NATIVE_DRAG_ACTIVE:
        if _smart_native_tick_registered():
            return state
        try:
            wm = getattr(bpy.context, 'window_manager', None)
            if wm is None or _smart_native_transform_kind(wm) is None:
                return None
        except Exception:
            return None
        return state
    if not _SMART_NATIVE_DRAG_ACTIVE:
        _smart_native_begin_from_draw()
    return None


def _smart_live_follow_state():
    """Return (pivot, axes) of the running drag follow, or (None, None)."""
    target = _SMART_GIZMO_LIVE_FOLLOW_TARGET
    axes = _SMART_GIZMO_LIVE_FOLLOW_AXES
    if target is not None or axes is not None or _SMART_GIZMO_LIVE_FOLLOW_DEFORM is not None:
        if _smart_grs_follow_owner_alive():
            return target, axes
        return None, None
    state = _smart_native_follow_live()
    if state is not None:
        return state.get('pivot'), state.get('axes')
    return None, None


def _smart_live_follow_all():
    """Return (pivot, axes, deform) of the running drag follow with one native-drag check."""
    if (
        _SMART_GIZMO_LIVE_FOLLOW_TARGET is not None
        or _SMART_GIZMO_LIVE_FOLLOW_AXES is not None
        or _SMART_GIZMO_LIVE_FOLLOW_DEFORM is not None
    ):
        if _smart_grs_follow_owner_alive():
            return _SMART_GIZMO_LIVE_FOLLOW_TARGET, _SMART_GIZMO_LIVE_FOLLOW_AXES, _SMART_GIZMO_LIVE_FOLLOW_DEFORM
        return None, None, None
    state = _smart_native_follow_live()
    if state is not None:
        return state.get('pivot'), state.get('axes'), state.get('deform')
    return None, None, None


def _smart_live_follow_deform():
    """Return the world 3x3 drag deform (rotation / scale) of the running drag, or None."""
    if (
        _SMART_GIZMO_LIVE_FOLLOW_TARGET is not None
        or _SMART_GIZMO_LIVE_FOLLOW_AXES is not None
        or _SMART_GIZMO_LIVE_FOLLOW_DEFORM is not None
    ):
        if _smart_grs_follow_owner_alive():
            return _SMART_GIZMO_LIVE_FOLLOW_DEFORM
        return None
    state = _smart_native_follow_live()
    if state is not None:
        return state.get('deform')
    return None


def _smart_drag_update_realtime() -> bool:
    """True when the 3D Smart Gizmo follows the selection while dragging (default)."""
    try:
        prefs = cu._prefs()
        if prefs is None:
            return True
        return str(getattr(prefs, 'smart_gizmo_drag_update', 'REALTIME') or 'REALTIME') != 'AFTER_DRAG'
    except Exception:
        return True


def _smart_deform_tuple(deform):
    """Validate a world 3x3 linear map; return it as nested tuples or None."""
    if deform is None:
        return None
    try:
        matrix = Matrix(deform).to_3x3()
        values = tuple(tuple(float(matrix[row][col]) for col in range(3)) for row in range(3))
        if not all(math.isfinite(value) for row in values for value in row):
            return None
        if abs(float(matrix.determinant())) <= 1.0e-12:
            return None
        if all(abs(values[row][col] - (1.0 if row == col else 0.0)) <= 1.0e-7 for row in range(3) for col in range(3)):
            return None
        return values
    except Exception:
        return None


def smart_gizmo_live_follow_set(owner, pivot=None, axes=None, deform=None) -> None:
    """Draw the current snapshot at ``pivot`` with ``deform @ axes`` (world) while ``owner`` runs."""
    global _SMART_GIZMO_LIVE_FOLLOW_TARGET, _SMART_GIZMO_LIVE_FOLLOW_AXES, _SMART_GIZMO_LIVE_FOLLOW_OWNER
    global _SMART_GIZMO_LIVE_FOLLOW_DEFORM
    point = None
    if pivot is not None:
        try:
            point = tuple(float(pivot[index]) for index in range(3))
            if not all(math.isfinite(value) for value in point):
                point = None
        except Exception:
            point = None
    basis = None
    if axes is not None:
        try:
            basis = tuple(
                tuple(float(value) for value in Vector(axes[index]).normalized())
                for index in range(3)
            )
            if not all(math.isfinite(value) for axis in basis for value in axis):
                basis = None
            elif abs(float(Matrix(basis).determinant())) <= 1.0e-6:
                basis = None
        except Exception:
            basis = None
    linear = _smart_deform_tuple(deform)
    _SMART_GIZMO_LIVE_FOLLOW_TARGET = point
    _SMART_GIZMO_LIVE_FOLLOW_AXES = basis
    _SMART_GIZMO_LIVE_FOLLOW_DEFORM = linear
    _SMART_GIZMO_LIVE_FOLLOW_OWNER = owner if (point is not None or basis is not None or linear is not None) else None


def smart_gizmo_live_follow_reset(context=None, *, rebuild=False) -> None:
    """Stop the drag follow; with ``rebuild`` re-snapshot from the live data at once."""
    global _SMART_GIZMO_LIVE_FOLLOW_TARGET, _SMART_GIZMO_LIVE_FOLLOW_AXES, _SMART_GIZMO_LIVE_FOLLOW_OWNER
    global _SMART_GIZMO_LIVE_FOLLOW_DEFORM
    _SMART_GIZMO_LIVE_FOLLOW_TARGET = None
    _SMART_GIZMO_LIVE_FOLLOW_AXES = None
    _SMART_GIZMO_LIVE_FOLLOW_DEFORM = None
    _SMART_GIZMO_LIVE_FOLLOW_OWNER = None
    if not rebuild:
        return
    try:
        cu._invalidate_gizmo_cache()
    except Exception:
        pass
    try:
        _smart_rebuild_all_draw_snapshots(context or getattr(bpy, 'context', None))
    except Exception:
        pass
    try:
        cu._tag_view3d_redraw()
    except Exception:
        pass


# Modal operators whose drag moves the selection without Smart G-R-S.  While one
# of them runs, the persistent watcher receives no events, so the immutable draw
# snapshot would stay at the press-time pivot until release.
_SMART_NATIVE_FOLLOW_SKIP_IDS = frozenset({
    'TRANSFORM_OT_smart_grs_transform',
    # ビューの操作はデータの変形ではない。VIEW3D_OT_move（Shift＋中ボタンのパン）は
    # 名前が '_move' で終わるため、変形と取り違えて追従の時計を毎ループ回していた。
    'VIEW3D_OT_move', 'VIEW3D_OT_rotate', 'VIEW3D_OT_zoom', 'VIEW3D_OT_dolly',
    'VIEW3D_OT_navigate', 'VIEW3D_OT_fly', 'VIEW3D_OT_walk', 'VIEW3D_OT_view_roll',
})

# ビューを動かしている最中のモーダル（描画の時に淡い線を飛ばす判断に使う）
_SMART_VIEW_NAV_MODAL_IDS = frozenset({
    'VIEW3D_OT_move', 'VIEW3D_OT_rotate', 'VIEW3D_OT_zoom', 'VIEW3D_OT_dolly',
    'VIEW3D_OT_navigate', 'VIEW3D_OT_fly', 'VIEW3D_OT_walk',
})


# 実行中のモーダルの一覧は、描画のたびに 2〜3 回読まれていた（1 回 0.1 ms 前後で、ビュー操作の
# 1 コマの重さの大きな部分）。モーダルは一覧の頭に足されるので、窓ごとの（数・頭・頭の名前）が
# 前と同じなら中身も同じとみなして前の結果を使う。念のため 0.5 秒たてば読み直す。
_SMART_MODAL_SCAN_CACHE = {'sig': None, 'at': 0.0, 'checked_at': 0.0, 'kind': None, 'nav': False, 'serial': -1}
_SMART_MODAL_SCAN_MAX_AGE = 0.5
# 1 回の描画の中では、追従の確かめと縁取りの確かめの 2 回この一覧を見る。1 ms 以内の 2 回目は前の答えを使う。
_SMART_MODAL_SCAN_SAME_DRAW = 0.001
# 描画からの問い合わせは、前に調べてから見張りが TIMER 以外のイベントを 1 つも受けておらず、変形も走って
# いなかったなら、この秒数まで前の結果を使う（新しいモーダルはイベントからしか始まらない）。
_SMART_MODAL_SCAN_DRAW_REUSE = 0.1
# ホイール・トラックパッドのビュー操作のイベント（Event.type の値。select_guard の _SSG_VIEW_NAV_ONLY_EVENT_TYPES と
# 同じ集まり）は、既定のキーマップではモーダルを始めないので、上の「受けたイベント」に数えない（拡大の 1 コマごとに
# 一覧を読み直していた）。ほかのキーマップでモーダルが始まっても、上の秒数のうちに読み直す。
_SMART_WATCH_NO_SERIAL_EVENTS = frozenset({
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM',
    'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE', 'WHEELLEFTMOUSE', 'WHEELRIGHTMOUSE',
})
# 演算子（Operator）の属性の読みは _bpy_types.Operator の Python の __getattribute__ を通り、1 回 3 µs 前後かかる。
# 元の C の関数（bpy_struct の as_pointer・path_resolve）で読めば 0.1〜0.7 µs で、値は同じ。
_SMART_STRUCT_AS_POINTER = getattr(getattr(bpy.types, 'bpy_struct', None), 'as_pointer', None)
_SMART_STRUCT_PATH_RESOLVE = getattr(getattr(bpy.types, 'bpy_struct', None), 'path_resolve', None)
# 演算子の Python の属性（self._win_ptr など）も、元の C の読み（bpy_struct.__getattribute__）で読めば 0.2 µs で、値は同じ。
_SMART_STRUCT_GETATTRIBUTE = getattr(getattr(bpy.types, 'bpy_struct', None), '__getattribute__', None)


def _smart_operator_pointer_idname(operator):
    as_pointer = _SMART_STRUCT_AS_POINTER
    path_resolve = _SMART_STRUCT_PATH_RESOLVE
    if as_pointer is not None and path_resolve is not None:
        try:
            return int(as_pointer(operator)), str(path_resolve(operator, 'bl_idname') or '')
        except Exception:
            pass
    return int(operator.as_pointer()), str(getattr(operator, 'bl_idname', '') or '')


def _smart_modal_operator_scan(wm):
    """Return (native transform kind, view navigation modal running) over every window."""
    cache = _SMART_MODAL_SCAN_CACHE
    serial = _SMART_WATCH_EVENT_SERIAL
    now = time.perf_counter()
    if cache['sig'] is not None and (now - float(cache['checked_at'])) < _SMART_MODAL_SCAN_SAME_DRAW:
        return cache['kind'], cache['nav']
    windows = tuple(getattr(wm, 'windows', ()) or ())
    try:
        sig = []
        for window in windows:
            operators = window.modal_operators
            count = len(operators)
            if count:
                head_ptr, head_idname = _smart_operator_pointer_idname(operators[0])
                sig.append((int(window.as_pointer()), count, head_ptr, head_idname))
            else:
                sig.append((int(window.as_pointer()), 0, 0, ''))
        sig = tuple(sig)
    except Exception:
        sig = None
    if sig is not None and cache['sig'] == sig and (now - float(cache['at'])) < _SMART_MODAL_SCAN_MAX_AGE:
        cache['checked_at'] = now
        cache['serial'] = serial
        return cache['kind'], cache['nav']
    kind = None
    nav = False
    for window in windows:
        try:
            operators = tuple(window.modal_operators)
        except Exception:
            continue
        for operator in operators:
            try:
                idname = _smart_operator_pointer_idname(operator)[1]
            except Exception:
                idname = ''
            if not idname:
                continue
            if idname in _SMART_VIEW_NAV_MODAL_IDS:
                nav = True
            if kind is not None or idname in _SMART_NATIVE_FOLLOW_SKIP_IDS:
                continue
            if idname.startswith('TRANSFORM_OT_') or idname.endswith(('_move', '_slide')):
                if idname == 'TRANSFORM_OT_translate':
                    kind = 'MOVE'
                elif idname in {'TRANSFORM_OT_rotate', 'TRANSFORM_OT_trackball'}:
                    kind = 'ROTATE'
                elif idname == 'TRANSFORM_OT_resize':
                    kind = 'SCALE'
                else:
                    kind = 'OTHER'
    cache['sig'] = sig
    cache['at'] = now
    cache['checked_at'] = now
    cache['kind'] = kind
    cache['nav'] = nav
    cache['serial'] = serial
    return kind, nav


def _smart_modal_scan_draw_idle() -> bool:
    """描画から：前の走査から見張りがイベントを受けておらず、変形も走っていなかったら True。"""
    cache = _SMART_MODAL_SCAN_CACHE
    return (
        cache['sig'] is not None
        and cache['kind'] is None
        and cache['serial'] == _SMART_WATCH_EVENT_SERIAL
        and (time.perf_counter() - float(cache['checked_at'])) < _SMART_MODAL_SCAN_DRAW_REUSE
    )


def _smart_native_transform_kind(wm):
    """Return 'MOVE' / 'ROTATE' / 'SCALE' / 'OTHER' for a running native transform modal, else None."""
    return _smart_modal_operator_scan(wm)[0]


def _smart_native_transform_running(wm) -> bool:
    return _smart_native_transform_kind(wm) is not None


def _smart_native_ref_object(context):
    obj = getattr(context, 'active_object', None)
    try:
        if obj is not None and not obj.select_get():
            obj = None
    except Exception:
        obj = None
    if obj is None:
        for other in tuple(getattr(context, 'selected_objects', ()) or ()):
            obj = other
            break
    if obj is None:
        return None
    return {'kind': 'OBJECT', 'obj': obj, 'ptr': int(obj.as_pointer()), 'matrix': obj.matrix_world.copy()}


def _smart_native_ref_edit_mesh(context, previous):
    """Sample of selected edit-mesh vertices, kept by BMesh iteration position.

    BMVert Python references go invalid when Blender rebuilds the element
    storage (seen between the idle capture and the drag), so the sample stores
    positions in ``bm.verts`` order and re-resolves them through the lookup
    table; the vertex count guards against topology changes.
    """
    candidates = []
    obj = getattr(context, 'edit_object', None) or getattr(context, 'active_object', None)
    if obj is not None and getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'mode', '') == 'EDIT':
        candidates.append(obj)
    for other in tuple(getattr(context, 'objects_in_mode_unique_data', ()) or ()):
        if getattr(other, 'type', None) == 'MESH' and all(other != known for known in candidates):
            candidates.append(other)
    limit = max(4, int(_SMART_NATIVE_DRAG_SAMPLE_MAX))
    for item in candidates:
        mesh = item.data
        try:
            selected = int(getattr(mesh, 'total_vert_sel', 0) or 0)
        except Exception:
            selected = 0
        if selected <= 0:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
            verts = bm.verts
            verts.ensure_lookup_table()
            total = len(verts)
        except Exception:
            continue
        matrix = item.matrix_world.copy()
        mesh_ptr = int(mesh.as_pointer())
        indices = ()
        if (
            previous
            and previous.get('kind') == 'EDIT_MESH'
            and previous.get('mesh_ptr') == mesh_ptr
            and previous.get('selected') == selected
            and previous.get('total') == total
        ):
            # Selection unchanged: keep the sample, refresh only its coordinates.
            old = tuple(previous.get('indices') or ())
            try:
                if old and all(0 <= index < total and verts[index].select for index in old):
                    indices = old
            except Exception:
                indices = ()
        if not indices:
            step = max(1, selected // limit)
            picked = []
            seen = 0
            for position, vert in enumerate(verts):
                if vert.select:
                    if seen % step == 0:
                        picked.append(position)
                        if len(picked) >= limit:
                            break
                    seen += 1
            indices = tuple(picked)
        if not indices:
            continue
        return {
            'kind': 'EDIT_MESH',
            'obj': item,
            'obj_ptr': int(item.as_pointer()),
            'mesh_ptr': mesh_ptr,
            'selected': selected,
            'total': total,
            'indices': indices,
            'coords': tuple(tuple(matrix @ verts[index].co) for index in indices),
        }
    return None


def _smart_native_bone_selected(mode, bone) -> bool:
    """True for a visible bone the native transform carries as a whole."""
    if mode == 'EDIT_ARMATURE':
        if not (bool(getattr(bone, 'select', False))
                or (bool(getattr(bone, 'select_head', False)) and bool(getattr(bone, 'select_tail', False)))):
            return False
        return bool(_smart_armature_bone_visible(mode, bone, bone))
    if not bool(getattr(bone, 'select', False)):
        return False
    return bool(_smart_armature_bone_visible(mode, bone, getattr(bone, 'bone', None)))


def _smart_native_bone_frame(obj, mode, name):
    """World 3x3 frame of one wholly selected bone, or None.

    Edit bones: unit axes (the transform carries the roll with a rotation)
    times the bone length.  Pose bones: the pose matrix, scale included.
    """
    if not name:
        return None
    if mode == 'EDIT_ARMATURE':
        bone = obj.data.edit_bones.get(name)
        if bone is None or not _smart_native_bone_selected(mode, bone):
            return None
        length = float(bone.length)
        if not math.isfinite(length) or length <= 1.0e-9:
            return None
        local = bone.matrix.to_3x3() @ Matrix.Scale(length, 3)
    else:
        bone = obj.pose.bones.get(name)
        if bone is None or not _smart_native_bone_selected(mode, bone):
            return None
        local = bone.matrix.to_3x3()
    return obj.matrix_world.to_3x3() @ local


def _smart_native_bone_points(obj, keys):
    """World positions of edit-bone (name, 'head' | 'tail') keys, or None if one is gone."""
    bones = obj.data.edit_bones
    world = obj.matrix_world
    points = []
    for name, part in keys:
        bone = bones.get(name)
        if bone is None:
            return None
        points.append(tuple(world @ Vector(getattr(bone, part))))
    return points


def _smart_native_ref_armature(context):
    """Armature Edit / Pose reference: one selected bone frame (+ edit-bone points)."""
    mode = str(getattr(context, 'mode', '') or '')
    obj = getattr(context, 'active_object', None)
    if mode not in {'EDIT_ARMATURE', 'POSE'} or obj is None or getattr(obj, 'type', None) != 'ARMATURE':
        return None
    if str(getattr(obj, 'mode', '') or '') != ('EDIT' if mode == 'EDIT_ARMATURE' else 'POSE'):
        return None
    if mode == 'EDIT_ARMATURE':
        bones = obj.data.edit_bones
        active = getattr(bones, 'active', None)
    else:
        bones = obj.pose.bones
        active_data = getattr(obj.data.bones, 'active', None)
        active = bones.get(active_data.name) if active_data is not None else None
    pick = active if active is not None and _smart_native_bone_selected(mode, active) else None
    keys = []
    if mode == 'EDIT_ARMATURE':
        limit = max(4, int(_SMART_NATIVE_DRAG_SAMPLE_MAX))
        for bone in bones:
            if len(keys) >= limit and pick is not None:
                break
            if not _smart_armature_bone_visible(mode, bone, bone):
                continue
            whole = _smart_native_bone_selected(mode, bone)
            if whole and pick is None:
                pick = bone
            for part in ('head', 'tail'):
                if len(keys) < limit and (whole or bool(getattr(bone, 'select_' + part, False))):
                    keys.append((str(bone.name), part))
    elif pick is None:
        for bone in bones:
            if _smart_native_bone_selected(mode, bone):
                pick = bone
                break
    name = str(pick.name) if pick is not None else ''
    frame = _smart_native_bone_frame(obj, mode, name) if name else None
    if frame is None and not keys:
        return None
    return {
        'kind': 'ARMATURE',
        'mode': mode,
        'obj': obj,
        'obj_ptr': int(obj.as_pointer()),
        'bone': name,
        'frame': tuple(tuple(float(value) for value in row) for row in frame) if frame is not None else None,
        'keys': tuple(keys),
        'coords': tuple(_smart_native_bone_points(obj, keys) or ()) if keys else (),
    }


def _smart_native_ref_capture(context) -> None:
    """Refresh the selection reference a native drag is measured against (idle only)."""
    global _SMART_NATIVE_DRAG_REF
    try:
        mode = str(getattr(context, 'mode', '') or '')
        if mode == 'EDIT_MESH':
            _SMART_NATIVE_DRAG_REF = _smart_native_ref_edit_mesh(context, _SMART_NATIVE_DRAG_REF)
        elif mode == 'OBJECT':
            _SMART_NATIVE_DRAG_REF = _smart_native_ref_object(context)
        elif mode in {'EDIT_ARMATURE', 'POSE'}:
            _SMART_NATIVE_DRAG_REF = _smart_native_ref_armature(context)
        else:
            _SMART_NATIVE_DRAG_REF = None
    except Exception:
        _SMART_NATIVE_DRAG_REF = None


def _smart_fit_linear(before, after):
    """World 3x3 map carrying the centred ``before`` points onto ``after``, or None.

    A rigid fit (Kabsch) is preferred; otherwise a general linear fit whose
    unobserved directions stay identity.  Non-affine motion returns None.
    """
    import numpy as np
    if len(before) != len(after) or len(before) < 2:
        return None
    p = np.array([tuple(point) for point in before], dtype=np.float64)
    q = np.array([tuple(point) for point in after], dtype=np.float64)
    reach = float(max(1.0, np.abs(p).max(), np.abs(q).max()))
    p -= p.mean(axis=0)
    q -= q.mean(axis=0)
    size = float(np.sqrt((p * p).sum(axis=1).max()))
    if size <= 1.0e-9:
        return None
    tol = math.sqrt(len(before)) * (1.0e-4 * size + 4.0e-6 * reach)
    sv = np.linalg.svd(p, compute_uv=False)
    rank = int((sv > 1.0e-6 * size).sum())
    linear = None
    if rank >= 2:
        u, _s, vt = np.linalg.svd(p.T @ q)
        d = 1.0 if float(np.linalg.det(vt.T @ u.T)) >= 0.0 else -1.0
        rotation = vt.T @ np.diag((1.0, 1.0, d)) @ u.T
        if float(np.linalg.norm(p @ rotation.T - q)) <= tol:
            linear = rotation
    elif rank == 1:
        k = int(np.argmax((p * p).sum(axis=1)))
        a = Vector(tuple(p[k]))
        b = Vector(tuple(q[k]))
        if a.length > 1.0e-9 and b.length > 1.0e-9 and abs(a.length - b.length) <= 1.0e-4 * a.length:
            turn = np.array(a.rotation_difference(b).to_matrix(), dtype=np.float64)
            if float(np.linalg.norm(p @ turn.T - q)) <= tol:
                linear = turn
    if linear is None:
        delta = np.linalg.lstsq(p, q - p, rcond=1.0e-6)[0]
        general = np.eye(3) + delta.T
        if float(np.linalg.norm(p @ general.T - q)) > tol:
            return None
        linear = general
    if np.allclose(linear, np.eye(3), atol=1.0e-5):
        return None
    return _smart_deform_tuple(Matrix(linear.tolist()))


def _smart_fit_axis_scale(before, after, axes):
    """World 3x3 scale along ``axes`` carrying the centred ``before`` points onto ``after``, or None.

    Edit-bone heads / tails are scaled point by point while the bone frames are
    re-rolled, so the stretch is read from the points along the press axes.
    An axis the selection has no extent along stays 1.0.
    """
    if not axes or len(before) != len(after) or len(before) < 2:
        return None
    basis = _smart_snapshot_basis_matrix(axes)
    inverse = basis.inverted_safe()
    count = len(before)
    p = [Vector(point) for point in before]
    q = [Vector(point) for point in after]
    cp = sum(p, Vector((0.0, 0.0, 0.0))) / count
    cq = sum(q, Vector((0.0, 0.0, 0.0))) / count
    a = [inverse @ (point - cp) for point in p]
    b = [inverse @ (point - cq) for point in q]
    size = max(vector.length for vector in a)
    if size <= 1.0e-9:
        return None
    reach = max(1.0, max(abs(float(value)) for point in p + q for value in point))
    factors = []
    for index in range(3):
        den = sum(vector[index] * vector[index] for vector in a)
        if den <= count * (1.0e-3 * size) ** 2:
            factors.append(1.0)
            continue
        factors.append(sum(x[index] * y[index] for x, y in zip(a, b)) / den)
    if not all(math.isfinite(value) and abs(value) > 1.0e-6 for value in factors):
        return None
    residual = math.sqrt(sum(
        (Vector((x[0] * factors[0], x[1] * factors[1], x[2] * factors[2])) - y).length_squared
        for x, y in zip(a, b)
    ))
    if residual > math.sqrt(count) * (1.0e-3 * size + 4.0e-6 * reach):
        return None
    if all(abs(value - 1.0) <= 1.0e-5 for value in factors):
        return None
    return _smart_deform_tuple(basis @ Matrix.Diagonal(factors) @ inverse)


def _smart_deform_axis_part(deform, axes):
    """Keep only the stretch of ``deform`` along ``axes``; None when nothing is left."""
    try:
        basis = _smart_snapshot_basis_matrix(axes)
        inverse = basis.inverted_safe()
        local = inverse @ Matrix(deform).to_3x3() @ basis
        factors = [float(local[index][index]) for index in range(3)]
        if all(abs(value - 1.0) <= 1.0e-5 for value in factors):
            return None
        return _smart_deform_tuple(basis @ Matrix.Diagonal(factors) @ inverse)
    except Exception:
        return deform


def _smart_native_estimate_deform(ref, drag_kind=None, press_axes=None):
    """World 3x3 map from the press reference to the live selection, or None."""
    if not ref:
        return None
    kind = ref.get('kind')
    if kind == 'ARMATURE':
        obj = ref.get('obj')
        mode = ref.get('mode')
        if obj is None or int(obj.as_pointer()) != ref.get('obj_ptr'):
            return None
        if str(getattr(obj, 'mode', '') or '') != ('EDIT' if mode == 'EDIT_ARMATURE' else 'POSE'):
            return None
        if drag_kind == 'MOVE':
            return None
        if mode == 'EDIT_ARMATURE' and drag_kind == 'SCALE':
            keys = tuple(ref.get('keys') or ())
            live = _smart_native_bone_points(obj, keys) if len(keys) >= 2 else None
            if not live:
                return None
            return _smart_fit_axis_scale(ref.get('coords') or (), live, press_axes)
        press = ref.get('frame')
        live = _smart_native_bone_frame(obj, mode, ref.get('bone'))
        if press is None or live is None:
            return None
        linear = live @ Matrix(press).inverted_safe()
        identity = Matrix.Identity(3)
        if all(abs(linear[row][col] - identity[row][col]) <= 1.0e-5 for row in range(3) for col in range(3)):
            return None
        return _smart_deform_tuple(linear)
    if kind == 'OBJECT':
        obj = ref.get('obj')
        if obj is None or int(obj.as_pointer()) != ref.get('ptr') or not obj.select_get():
            return None
        linear = obj.matrix_world.to_3x3() @ Matrix(ref['matrix']).to_3x3().inverted_safe()
        identity = Matrix.Identity(3)
        if all(abs(linear[row][col] - identity[row][col]) <= 1.0e-5 for row in range(3) for col in range(3)):
            return None
        return _smart_deform_tuple(linear)
    if kind == 'EDIT_MESH':
        obj = ref.get('obj')
        indices = tuple(ref.get('indices') or ())
        if obj is None or int(obj.as_pointer()) != ref.get('obj_ptr') or len(indices) < 2:
            return None
        mesh = obj.data
        if mesh is None or int(mesh.as_pointer()) != ref.get('mesh_ptr'):
            return None
        bm = bmesh.from_edit_mesh(mesh)
        verts = bm.verts
        verts.ensure_lookup_table()
        if len(verts) != ref.get('total'):
            return None
        live = []
        for index in indices:
            vert = verts[index]
            if not vert.select:
                return None
            live.append(vert)
        matrix = obj.matrix_world
        return _smart_fit_linear(
            [Vector(point) for point in ref.get('coords') or ()],
            [matrix @ vert.co for vert in live],
        )
    return None


def _smart_snapshot_press_axes():
    """Axes of the press-time snapshot (absolute frame the native deform turns)."""
    for snapshot in tuple(_SMART_GIZMO_DRAW_SNAPSHOTS.values()):
        try:
            if str(getattr(snapshot, 'orient_type', '') or '') in {'VIEW', 'WORKPLANE'}:
                continue
            axes = tuple(tuple(float(value) for value in Vector(axis).normalized()) for axis in tuple(snapshot.axes)[:3])
            if len(axes) == 3:
                return axes
        except Exception:
            continue
    return None


def _smart_native_follow_rebuild(context) -> None:
    try:
        cu._invalidate_gizmo_cache()
    except Exception:
        pass
    try:
        _smart_rebuild_all_draw_snapshots(context)
    except Exception:
        pass
    try:
        cu._tag_view3d_redraw()
    except Exception:
        pass


@persistent
def _smart_gizmo_native_transform_follow(_scene=None, _depsgraph=None) -> None:
    """Follow a native transform drag from depsgraph_update_post.

    depsgraph_update_post runs after the modal applied the mouse move and before
    the viewport redraw of the same event loop pass.  In real-time mode the
    press-time snapshot is drawn at the live pivot, turned and stretched by the
    measured selection deform; in after-drag mode it stays as pressed.  The
    first update after the modal ends re-snapshots from the live data once.
    """
    global _SMART_NATIVE_FOLLOW, _SMART_NATIVE_DRAG_ACTIVE, _SMART_DEPSGRAPH_SERIAL
    _SMART_DEPSGRAPH_SERIAL += 1
    if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)):
        return
    context = getattr(bpy, 'context', None)
    wm = getattr(context, 'window_manager', None) if context is not None else None
    if wm is None:
        return
    try:
        kind = _smart_native_transform_kind(wm)
    except Exception:
        return
    if kind is None:
        if _SMART_NATIVE_DRAG_ACTIVE:
            _smart_native_drag_finish(context)
        else:
            _smart_native_ref_capture(context)
        return
    if _smart_grs_follow_owner_alive():
        return
    if not _SMART_NATIVE_DRAG_ACTIVE:
        _smart_native_drag_begin(kind)
    if not _smart_drag_update_realtime():
        return
    _smart_native_follow_update(context, kind)


def _smart_native_follow_update(context, kind) -> None:
    """Measure the live pivot, axes and deform of the running native drag (real-time mode)."""
    global _SMART_NATIVE_FOLLOW
    try:
        cu._invalidate_gizmo_cache()
    except Exception:
        pass
    state = dict(_SMART_NATIVE_FOLLOW or {})
    pivot = None
    live_axes = None
    orient_type = ''
    try:
        pivot_world, axes = _smart_pivot_location_and_axes(context)
        if pivot_world is not None:
            pivot = tuple(float(pivot_world[index]) for index in range(3))
            if not all(math.isfinite(value) for value in pivot):
                pivot = None
        if axes and len(axes) >= 4:
            orient_type = str(axes[3] or '')
            live_axes = tuple(
                tuple(float(value) for value in Vector(axes[index]).normalized()) for index in range(3)
            )
    except Exception:
        pivot = None
        live_axes = None
    deform = None
    try:
        deform = _smart_native_estimate_deform(_SMART_NATIVE_DRAG_REF, kind, state.get('press_axes'))
    except Exception:
        deform = None
    if kind == 'SCALE' and deform is not None and state.get('press_axes'):
        # Object / pose scale lives in local axes, so a global axis scale of a
        # turned bone or object shears its frame.  A scale drag draws as the
        # stretch along the gizmo's own axes.
        deform = _smart_deform_axis_part(deform, state.get('press_axes'))
    if orient_type == 'NORMAL' and kind == 'ROTATE' and live_axes is not None:
        # NORMAL axes are rebuilt from the live normal with a fixed up rule
        # rather than carried rigidly, so draw the frame the confirm will show.
        state['axes'] = live_axes
        deform = None
    else:
        state['axes'] = state.get('press_axes')
    state['pivot'] = pivot
    state['deform'] = deform
    state['kind'] = kind
    _SMART_NATIVE_FOLLOW = state


def _smart_native_tick_registered() -> bool:
    try:
        return bool(bpy.app.timers.is_registered(_smart_native_drag_tick))
    except Exception:
        return False


def _smart_native_drag_begin(kind) -> None:
    """Start following a native drag; the drag tick runs until its end is processed."""
    global _SMART_NATIVE_FOLLOW, _SMART_NATIVE_DRAG_ACTIVE, _SMART_NATIVE_TICK_SIGNATURE
    press_axes = _smart_snapshot_press_axes()
    _SMART_NATIVE_DRAG_ACTIVE = True
    _SMART_NATIVE_FOLLOW = {'pivot': None, 'axes': press_axes, 'press_axes': press_axes, 'deform': None, 'kind': kind}
    _SMART_NATIVE_TICK_SIGNATURE = None
    try:
        if not bpy.app.timers.is_registered(_smart_native_drag_tick):
            bpy.app.timers.register(_smart_native_drag_tick, first_interval=0.0)
    except Exception:
        pass


def _smart_native_begin_from_draw() -> None:
    """Start the follow of a native drag that no depsgraph update reported."""
    if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)):
        return
    if _smart_modal_scan_draw_idle():
        # 前の走査で変形が無く、その後イベントが無いので、変形は始まっていない。
        return
    try:
        wm = getattr(bpy.context, 'window_manager', None)
        kind = _smart_native_transform_kind(wm) if wm is not None else None
    except Exception:
        return
    if kind is None or _smart_grs_follow_owner_alive():
        return
    _smart_native_drag_begin(kind)


def _smart_native_drag_finish(context) -> None:
    """Drop the drag follow, re-snapshot the confirmed data and re-measure the reference."""
    global _SMART_NATIVE_FOLLOW, _SMART_NATIVE_DRAG_ACTIVE, _SMART_NATIVE_TICK_SIGNATURE
    _SMART_NATIVE_DRAG_ACTIVE = False
    _SMART_NATIVE_FOLLOW = None
    _SMART_NATIVE_TICK_SIGNATURE = None
    _smart_native_follow_rebuild(context)
    _smart_native_ref_capture(context)


def _smart_native_tick_override(wm):
    """temp_override arguments for a 3D View of the window running the drag, or None."""
    fallback = None
    for window in tuple(getattr(wm, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        try:
            running = any(
                str(getattr(operator, 'bl_idname', '') or '').startswith('TRANSFORM_OT_')
                for operator in tuple(window.modal_operators)
            )
        except Exception:
            running = False
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) != 'VIEW_3D':
                continue
            region = None
            for item in tuple(getattr(area, 'regions', ()) or ()):
                if getattr(item, 'type', None) == 'WINDOW':
                    region = item
                    break
            if region is None:
                continue
            kwargs = {'window': window, 'screen': screen, 'area': area, 'region': region}
            if running:
                return kwargs
            if fallback is None:
                fallback = kwargs
            break
    return fallback


def _smart_native_tick_signature(ref):
    """Live bone geometry of the reference; None when it cannot be read."""
    try:
        if not ref or ref.get('kind') != 'ARMATURE':
            return None
        obj = ref.get('obj')
        if obj is None or int(obj.as_pointer()) != ref.get('obj_ptr'):
            return None
        frame = _smart_native_bone_frame(obj, ref.get('mode'), ref.get('bone'))
        points = _smart_native_bone_points(obj, ref.get('keys') or ()) if ref.get('mode') == 'EDIT_ARMATURE' else ()
        return (
            tuple(tuple(round(float(value), 7) for value in row) for row in frame) if frame is not None else None,
            tuple(tuple(round(float(value), 7) for value in point) for point in (points or ())),
            tuple(round(float(value), 7) for value in obj.matrix_world.translation),
        )
    except Exception:
        return None


def _smart_native_drag_tick():
    """Run once per event-loop pass while a native drag is followed.

    Timers run after the modal handled the event and before the redraw, so
    the tick follows drags the depsgraph does not report (Armature Edit mode
    moves edit bones without a depsgraph update) and processes the drag end
    before the first redraw after it: the confirm frame already shows the new
    gizmo, in real-time and in after-drag mode alike.
    """
    global _SMART_NATIVE_FOLLOW, _SMART_NATIVE_DRAG_ACTIVE, _SMART_NATIVE_TICK_SIGNATURE
    if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)) or not _SMART_NATIVE_DRAG_ACTIVE:
        return None
    try:
        context = bpy.context
        wm = getattr(context, 'window_manager', None)
        if wm is None:
            raise RuntimeError('Smart Gizmo drag tick has no window manager')
        kind = _smart_native_transform_kind(wm)
        kwargs = _smart_native_tick_override(wm)
        if kind is None:
            if kwargs is not None and hasattr(bpy.context, 'temp_override'):
                with bpy.context.temp_override(**kwargs):
                    _smart_native_drag_finish(bpy.context)
            else:
                _smart_native_drag_finish(context)
            return None
        if _smart_drag_update_realtime() and not _smart_grs_follow_owner_alive():
            def _follow(ctx):
                global _SMART_NATIVE_TICK_SIGNATURE
                if str(getattr(ctx, 'mode', '') or '') not in _SMART_NATIVE_TICK_FOLLOW_MODES:
                    return
                signature = _smart_native_tick_signature(_SMART_NATIVE_DRAG_REF)
                if signature is not None and signature == _SMART_NATIVE_TICK_SIGNATURE:
                    return
                _SMART_NATIVE_TICK_SIGNATURE = signature
                _smart_native_follow_update(ctx, kind)
            if kwargs is not None and hasattr(bpy.context, 'temp_override'):
                with bpy.context.temp_override(**kwargs):
                    _follow(bpy.context)
            else:
                _follow(context)
        return 0.0
    except Exception:
        _SMART_NATIVE_DRAG_ACTIVE = False
        _SMART_NATIVE_FOLLOW = None
        _SMART_NATIVE_TICK_SIGNATURE = None
        return None


def _smart_native_follow_handler_registered() -> bool:
    try:
        return _smart_gizmo_native_transform_follow in bpy.app.handlers.depsgraph_update_post
    except Exception:
        return False


def _ensure_native_transform_follow_handler() -> None:
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        for fn in list(handlers):
            if getattr(fn, '__name__', '') == '_smart_gizmo_native_transform_follow' and fn is not _smart_gizmo_native_transform_follow:
                handlers.remove(fn)
        if _smart_gizmo_native_transform_follow not in handlers:
            handlers.append(_smart_gizmo_native_transform_follow)
    except Exception:
        pass


def _remove_native_transform_follow_handler() -> None:
    global _SMART_NATIVE_FOLLOW, _SMART_NATIVE_DRAG_ACTIVE, _SMART_NATIVE_DRAG_REF, _SMART_NATIVE_TICK_SIGNATURE
    _SMART_NATIVE_FOLLOW = None
    _SMART_NATIVE_DRAG_ACTIVE = False
    _SMART_NATIVE_DRAG_REF = None
    _SMART_NATIVE_TICK_SIGNATURE = None
    try:
        if bpy.app.timers.is_registered(_smart_native_drag_tick):
            bpy.app.timers.unregister(_smart_native_drag_tick)
    except Exception:
        pass
    try:
        handlers = bpy.app.handlers.depsgraph_update_post
        for fn in list(handlers):
            if fn is _smart_gizmo_native_transform_follow or getattr(fn, '__name__', '') == '_smart_gizmo_native_transform_follow':
                handlers.remove(fn)
    except Exception:
        pass


def _smart_billboard_model_matrix(rv3d, origin, scale, view_inv=None):
    """Build a live screen-facing model matrix without touching scene data."""
    if view_inv is None:
        view_inv = rv3d.view_matrix.inverted().to_3x3()
    right = (view_inv @ Vector((1.0, 0.0, 0.0))).normalized()
    up = (view_inv @ Vector((0.0, 1.0, 0.0))).normalized()
    forward = (view_inv @ Vector((0.0, 0.0, 1.0))).normalized()
    origin = Vector(origin)
    scale = float(scale)
    return Matrix((
        (right.x * scale, up.x * scale, forward.x * scale, origin.x),
        (right.y * scale, up.y * scale, forward.y * scale, origin.y),
        (right.z * scale, up.z * scale, forward.z * scale, origin.z),
        (0.0, 0.0, 0.0, 1.0),
    ))


_SMART_GPU_STATE_FUNCS = {}


def _smart_gpu_state_apply_exact(
    restore_stack, getter_name: str, setter_name: str, value, skip_equal: bool = False,
) -> bool:
    # gpu.state の関数は描画のたびに探さず、1 回探して持っておく。
    funcs = _SMART_GPU_STATE_FUNCS.get(setter_name)
    if funcs is None:
        getter = getattr(gpu.state, getter_name, None)
        setter = getattr(gpu.state, setter_name, None)
        funcs = (getter, setter) if callable(getter) and callable(setter) else (None, None)
        _SMART_GPU_STATE_FUNCS[setter_name] = funcs
    getter, setter = funcs
    if getter is None:
        return False
    old_value = getter()
    if skip_equal and old_value == value:
        # 既に同じ値なら、設定も戻しも同じ値の書き込みになるだけなので行わない。
        return True
    # Own the restoration obligation before the setter runs. Even a setter that
    # mutates native state and then raises is paired with its exact old value.
    restore_stack.append((setter, old_value))
    setter(value)
    return True


def _smart_view_master_visible(context=None, area=None) -> bool:
    """Read the live show_gizmo switch for the event/draw View3D only.

    This is deliberately a read-only gate.  It never writes the master flag,
    consults another viewport, or reuses a retained space pointer.
    """
    try:
        area = area or getattr(context, 'area', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D':
            return False
        space = getattr(getattr(area, 'spaces', None), 'active', None)
        if space is None or getattr(space, 'type', None) != 'VIEW_3D':
            return False
        return bool(getattr(space, 'show_gizmo', True))
    except (ReferenceError, RuntimeError, AttributeError):
        return False


def _smart_draw_snapshot_replay() -> None:
    """Replay immutable GPU batches with live per-region view/projection state.

    The snapshot contains no authoritative RegionView3D transform.  Static
    event-built batches are remapped around the cached world pivot using the exact
    current view/projection matrices, current VIEW basis, and current screen-space
    scale.  Canonical billboard batches use the same live remap.  Draw performs no
    depsgraph/BMesh traversal and creates no GPU batch or timer.
    """
    if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)):
        return
    context = bpy.context
    area = getattr(context, 'area', None)
    region = getattr(context, 'region', None)
    rv3d = getattr(context, 'region_data', None)
    if area is None or region is None or rv3d is None or getattr(region, 'type', None) != 'WINDOW':
        return
    # 描画の文脈の space_data は、描いている領域の area.spaces.active と同じ物。種類の確かめと
    # ギズモの表示の切り替えをそこから読む（_smart_view_master_visible と同じ判定で、RNA の読みが少ない）。
    try:
        space = context.space_data
        if (
            space is None or getattr(area, 'type', None) != 'VIEW_3D'
            or getattr(space, 'type', None) != 'VIEW_3D'
            or not bool(getattr(space, 'show_gizmo', True))
        ):
            return
    except (ReferenceError, RuntimeError, AttributeError):
        return
    window = getattr(context, 'window', None)
    as_pointer = _SMART_STRUCT_AS_POINTER
    try:
        # _smart_draw_snapshot_key と同じ値（印の読めない物は 0）。
        key = (
            int(as_pointer(window)) if window is not None else 0,
            int(as_pointer(area)),
            int(as_pointer(region)),
        )
    except Exception:
        key = _smart_draw_snapshot_key(window, area, region)
    snapshot = _SMART_GIZMO_DRAW_SNAPSHOTS.get(key)
    if snapshot is None or int(snapshot.generation) != int(_SMART_GIZMO_SNAPSHOT_GENERATION):
        return

    model_pushed = False
    projection_pushed = False
    restore_stack = []
    try:
        view_matrix, projection_matrix = _smart_current_draw_matrices(rv3d)
        world_transform, live_scale_ratio = _smart_live_snapshot_transform(
            snapshot, region, rv3d, view_matrix, projection_matrix
        )
        gpu.matrix.push()
        model_pushed = True
        gpu.matrix.push_projection()
        projection_pushed = True
        world_view = view_matrix @ world_transform
        gpu.matrix.load_matrix(world_view)
        gpu.matrix.load_projection_matrix(projection_matrix)

        # Each setter/value pair is paired with the exact getter-captured state.
        state_specs = (
            ('blend_get', ('blend_set', 'ALPHA')),
            ('depth_mask_get', ('depth_mask_set', False)),
            ('depth_test_get', ('depth_test_set', 'NONE')),
            ('face_culling_get', ('face_culling_set', 'NONE')),
            ('line_width_get', ('line_width_set', 1.0)),
            ('point_size_get', ('point_size_set', 1.0)),
        )
        owned = {}
        for getter_name, (setter_name, value) in state_specs:
            # 線の太さは命令ごとに変えるので、同じ値でも戻しを積む。ほかは同じ値なら触らない。
            owned[setter_name] = _smart_gpu_state_apply_exact(
                restore_stack, getter_name, setter_name, value,
                setter_name != 'line_width_set',
            )

        shader = snapshot.shader
        loaded_mode = 'WORLD'
        billboard_cache = {}
        skip_halo = _smart_gizmo_view_navigation_draw_active(True)
        view_inv = None
        # 命令ごとの bind・線の太さ・色の設定は、変わった時だけ行う（batch.draw は同じ shader を
        # 結び直さず、uniform の値も次の draw まで残る）。描く物と順番は前と同じ。
        own_line_width = bool(owned.get('line_width_set'))
        line_width_now = 1.0
        color_now = None
        shader.bind()
        for command in snapshot.commands:
            if skip_halo and command.halo:
                continue
            if command.matrix_mode == 'BILLBOARD':
                # 同じ向きの行列が既に積んであれば積み直さない（中心の円は塗り・縁取り・線の 3 つで同じ）。
                # 材料の中心と大きさが同じなら、このコマの行列も同じなので、材料の値で引く。
                cache_key = (command.origin, command.scale)
                if loaded_mode != cache_key:
                    model_matrix = billboard_cache.get(cache_key)
                    if model_matrix is None:
                        live_origin = world_transform @ Vector(command.origin)
                        live_scale = float(command.scale) * float(live_scale_ratio)
                        if view_inv is None:
                            view_inv = view_matrix.inverted().to_3x3()
                        model_matrix = _smart_billboard_model_matrix(
                            rv3d, live_origin, live_scale, view_inv
                        )
                        billboard_cache[cache_key] = model_matrix
                    gpu.matrix.load_matrix(view_matrix @ model_matrix)
                    loaded_mode = cache_key
            elif loaded_mode != 'WORLD':
                gpu.matrix.load_matrix(world_view)
                loaded_mode = 'WORLD'

            width = command.line_width
            if own_line_width and width > 0.0 and width != line_width_now:
                gpu.state.line_width_set(width)
                line_width_now = width
            if not command.vertex_color:
                color = command.color
                if color != color_now:
                    shader.uniform_float('color', color)
                    color_now = color
            command.batch.draw(shader)

        try:
            # 描画のたびに 16 個の値を Python の tuple へ写すのをやめ、写しの行列を固める。
            cg._SMART_GIZMO_LAST_DRAW_VIEW_MATRIX = view_matrix.freeze()
            cg._SMART_GIZMO_LAST_DRAW_PROJECTION_MATRIX = projection_matrix.freeze()
            cg._SMART_GIZMO_LAST_DRAW_SLOT_KEY = tuple(key)
        except Exception:
            pass
        cg._SMART_GIZMO_LAST_DRAW_AT = time.perf_counter()
    except Exception:
        pass
    finally:
        def restore_exact(callback) -> bool:
            # A transient native/GPU failure must not strand a changed state or
            # pushed matrix.  Retry only inside this draw teardown; no timer or
            # later polling resource is created.
            for _attempt in range(3):
                try:
                    callback()
                    return True
                except Exception:
                    pass
            return False

        for setter, old_value in reversed(restore_stack):
            try:
                setter(old_value)
            except Exception:
                restore_exact(lambda setter=setter, old_value=old_value: setter(old_value))
        if projection_pushed:
            restore_exact(gpu.matrix.pop_projection)
        if model_pushed:
            restore_exact(gpu.matrix.pop)


def _smart_draw_callback():
    """Native POST_PIXEL boundary: immutable batches plus live view matrices."""
    _smart_draw_snapshot_replay()



def _smart_ensure_draw_handler():
    if cg._SMART_GIZMO_DRAW_HANDLE is not None:
        try:
            if not float(getattr(cg, '_SMART_GIZMO_DRAW_HANDLE_REGISTERED_AT', 0.0) or 0.0):
                cg._SMART_GIZMO_DRAW_HANDLE_REGISTERED_AT = time.perf_counter()
        except Exception:
            pass
        if str(getattr(cg, '_SMART_GIZMO_DRAW_STAGE', '') or '') != 'POST_PIXEL':
            _smart_repair_draw_order_after_smart_overlay_if_needed(force=True)
        else:
            _smart_gizmo_publish_layer_policy()
        rebuilt = 0
        try:
            rebuilt = int(_smart_rebuild_all_draw_snapshots(getattr(bpy, 'context', None)) or 0)
        except Exception:
            rebuilt = 0
        if rebuilt:
            try:
                cu._tag_view3d_redraw()
            except Exception:
                pass
        return
    if _smart_add_draw_handler('POST_PIXEL'):
        try:
            _smart_rebuild_all_draw_snapshots(getattr(bpy, 'context', None))
        except Exception:
            pass
        try:
            cu._tag_view3d_redraw()
        except Exception:
            pass



def _smart_remove_draw_handler():
    handle = getattr(cg, '_SMART_GIZMO_DRAW_HANDLE', None)
    if handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        except Exception:
            pass
    cg._SMART_GIZMO_DRAW_HANDLE = None
    try:
        cg._SMART_GIZMO_DRAW_STAGE = 'POST_PIXEL'
        cg._SMART_GIZMO_DRAW_HANDLE_REGISTERED_AT = 0.0
        cg._SMART_GIZMO_LAST_DRAW_AT = 0.0
    except Exception:
        pass
    _smart_draw_snapshot_clear()
    try:
        cg._SMART_GIZMO_LAST_DRAW_VIEW_MATRIX = None
        cg._SMART_GIZMO_LAST_DRAW_PROJECTION_MATRIX = None
        cg._SMART_GIZMO_LAST_DRAW_SLOT_KEY = None
    except Exception:
        pass


def _update_smart_gizmo_settings(self, context):
    try:
        sync_runtime_from_prefs(context)
    except Exception:
        pass
    try:
        cu._tag_view3d_redraw()
        if _runtime_pref_enabled(context):
            _ensure_smart_gizmo_watchers()
            _smart_check_tool_and_update_visibility(context)
        else:
            _restore_builtin_tool_gizmos(context)
    except Exception:
        pass

def _smart_check_tool_and_update_visibility(context):
    if not _runtime_pref_enabled(context):
        return

    def _update_one(ctx, use_smart_style, is_active, enable_move, forced_kind=None):
        try:
            try:
                tid = cu._active_tool_id(ctx)
            except Exception:
                tid = None

            is_move_tool = (tid == "builtin.move") or forced_kind == 'MOVE'
            is_rotate_tool = (tid == "builtin.rotate") or forced_kind == 'ROTATE'
            is_scale_tool = (tid == "builtin.scale") or forced_kind == 'SCALE'
            is_transform_tool = (tid == "builtin.transform") or forced_kind == 'TRANSFORM'

            if not getattr(ctx, "area", None): return
            area = ctx.area
            if area.type != 'VIEW_3D': return
            space = area.spaces.active
            if not space or space.type != 'VIEW_3D': return

            transform_tool_active = bool(is_move_tool or is_rotate_tool or is_scale_tool or is_transform_tool)
            modal_override_active = bool(forced_kind in {'MOVE', 'ROTATE', 'SCALE', 'TRANSFORM'})
            if not transform_tool_active and not modal_override_active:
                # Select and other non-transform tools may keep their own active
                # tool gizmo, but Blender's independent object transform channels
                # must stay off.  Enabling all four native channels here makes the
                # standard Move/Rotate/Scale gizmo appear on top of Select tools.
                _set_builtin_transform_gizmo_visibility(space, True)
                return

            if not is_active:
                if is_move_tool or is_rotate_tool or is_scale_tool or is_transform_tool:
                    _set_builtin_transform_gizmo_visibility(space, False)
                return

            # Startup can briefly report no active tool while Blender restores
            # workspace state.  If Smart Gizmo is enabled, hide native transform
            # gizmos during this short window as well; the guardian will keep
            # the custom overlay alive once the tool resolves.
            if use_smart_style and is_active and tid in {None, ''}:
                _set_builtin_transform_gizmo_visibility(space, False)

            p = cu._prefs(ctx)
            en_rot = bool(getattr(p, 'enable_smart_gizmo_rotate', True)) if p else True
            en_sca = bool(getattr(p, 'enable_smart_gizmo_scale', True)) if p else True
            en_tr = bool(getattr(p, 'enable_smart_gizmo_transform', True)) if p else True

            if is_move_tool and enable_move:
                if use_smart_style:
                    _set_builtin_transform_gizmo_visibility(space, False)
                else:
                    _set_builtin_transform_gizmo_visibility(space, True)
            elif is_rotate_tool:
                if use_smart_style and en_rot:
                    _set_builtin_transform_gizmo_visibility(space, False)
                else:
                    _set_builtin_transform_gizmo_visibility(space, True)
            elif is_scale_tool:
                if use_smart_style and en_sca:
                    _set_builtin_transform_gizmo_visibility(space, False)
                else:
                    _set_builtin_transform_gizmo_visibility(space, True)
            elif is_transform_tool:
                if use_smart_style and en_tr:
                    _set_builtin_transform_gizmo_visibility(space, False)
                else:
                    _set_builtin_transform_gizmo_visibility(space, True)
        except Exception: pass

    try:
        ctx0 = context or bpy.context
        wm = getattr(ctx0, "window_manager", None)
        if not wm: return

        p = cu._prefs(ctx0)
        use_smart_style = bool(getattr(p, "enable_smart_gizmo_style", False))
        is_active = bool(getattr(p, "gizmo_toggle_state", True))
        enable_move = bool(getattr(p, "enable_move", True))

        for win in wm.windows:
            scr = getattr(win, "screen", None)
            if not scr: continue
            for area in scr.areas:
                if area.type != "VIEW_3D": continue
                region = next((r for r in area.regions if r.type == "WINDOW"), None)
                if not region: continue

                try:
                    forced_kind = _smart_tool_kind_for_view(ctx0, win, area, region)
                except Exception:
                    forced_kind = None
                try:
                    if hasattr(bpy.context, "temp_override"):
                        kwargs = {'window': win, 'area': area, 'region': region}
                        try:
                            scr = getattr(win, 'screen', None)
                            if scr is not None:
                                kwargs['screen'] = scr
                        except Exception:
                            pass
                        try:
                            ws = getattr(win, 'workspace', None)
                            if ws is not None:
                                kwargs['workspace'] = ws
                        except Exception:
                            pass
                        try:
                            sp = area.spaces.active
                            kwargs['space_data'] = sp
                            rv = cu._view3d_region_data(area, region)
                            if rv is not None:
                                kwargs['region_data'] = rv
                        except Exception:
                            pass
                        with bpy.context.temp_override(**kwargs):
                            _update_one(bpy.context, use_smart_style, is_active, enable_move, forced_kind)
                    else:
                        _update_one(ctx0, use_smart_style, is_active, enable_move, forced_kind)
                except Exception: pass
    except Exception: pass


def _window_for_view3d_area(context, area):
    try:
        win = getattr(context, 'window', None)
        scr = getattr(win, 'screen', None) if win is not None else None
        if scr is not None and area in getattr(scr, 'areas', []):
            return win
    except Exception:
        pass
    try:
        wm = getattr(context, 'window_manager', None) or getattr(bpy.context, 'window_manager', None)
        for win in getattr(wm, 'windows', []) or []:
            scr = getattr(win, 'screen', None)
            if scr is not None and area in getattr(scr, 'areas', []):
                return win
    except Exception:
        pass
    return getattr(context, 'window', None)


def _view3d_override_kwargs(context, area, region, rv3d=None):
    override = {}
    win = _window_for_view3d_area(context, area)
    if win is not None:
        override['window'] = win
    if area is not None:
        override['area'] = area
        try:
            space = area.spaces.active
            override['space_data'] = space
            if rv3d is None:
                try:
                    if getattr(context, 'area', None) is area and getattr(context, 'region', None) is region:
                        rv3d = getattr(context, 'region_data', None)
                except Exception:
                    rv3d = None
            if rv3d is None:
                rv3d = cu._view3d_region_data(area, region)
            if rv3d is not None:
                override['region_data'] = rv3d
        except Exception:
            pass
    if region is not None:
        override['region'] = region
    return override


def _event_region_xy_rv3d_for_window(context, event):
    """Resolve a pointer event to a physical View3D region and Quad-aware RV3D."""
    try:
        return cu._event_view3d_area_region_xy_rv3d(context, event)
    except Exception:
        pass
    try:
        wx = int(getattr(event, 'mouse_x', 0))
        wy = int(getattr(event, 'mouse_y', 0))
    except Exception:
        return None, None, 0, 0, None
    try:
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        if getattr(area, 'type', None) == 'VIEW_3D' and getattr(region, 'type', None) == 'WINDOW' and cu._event_inside_region(region, wx, wy):
            mx = int(wx) - int(getattr(region, 'x', 0) or 0)
            my = int(wy) - int(getattr(region, 'y', 0) or 0)
            rv3d = cu._view3d_region_data(area, region, mx, my) or getattr(context, 'region_data', None)
            return area, region, mx, my, rv3d
    except Exception:
        pass
    return None, None, 0, 0, None


def _event_region_xy_for_window(context, event):
    """Resolve a pointer event to a real View3D WINDOW region only.

    The Smart Gizmo watcher is a window-level modal operator, so it also receives
    events from Blender UI regions.  The returned region is always Blender's
    physical WINDOW region; Quad View sub-view data is kept separate so normal
    selection and select_box continue to work in every pane.
    """
    area, region, mx, my, _rv3d = _event_region_xy_rv3d_for_window(context, event)
    return area, region, mx, my


# ホイール・トラックパッドのビュー操作のイベントは、同じ窓・同じマウスの位置なら答えも同じ。拡大の間はマウスが
# 動かないので、0.25 秒までは前の答えを使い、窓の中の領域を毎回探さない（ほかのイベントは毎回探す）。
_SMART_NAV_INSIDE_CACHE = {'key': None, 'at': 0.0, 'value': False}
_SMART_NAV_INSIDE_MAX_AGE = 0.25


def _smart_gizmo_event_is_inside_view3d_region(context, event, win_ptr=0) -> bool:
    try:
        etype = str(getattr(event, 'type', '') or '')
    except Exception:
        etype = ''
    if etype in {'TIMER', 'TIMER0', 'TIMER1', 'TIMER2'}:
        return True
    mouse_event = (
        'MOUSE' in etype
        or etype in _SMART_GIZMO_VIEW_NAV_EVENTS
        or etype in _SMART_GIZMO_VIEW_NAV_BUTTON_EVENTS
        or etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'EVT_TWEAK_L', 'EVT_TWEAK_M', 'EVT_TWEAK_R'}
    )
    if not mouse_event:
        return False
    nav_key = None
    if win_ptr and etype in _SMART_GIZMO_VIEW_NAV_EVENTS and etype not in _SMART_GIZMO_VIEW_NAV_BUTTON_EVENTS:
        try:
            nav_key = (int(win_ptr), int(event.mouse_x), int(event.mouse_y))
            cache = _SMART_NAV_INSIDE_CACHE
            if cache['key'] == nav_key and (time.perf_counter() - float(cache['at'])) < _SMART_NAV_INSIDE_MAX_AGE:
                return bool(cache['value'])
        except Exception:
            nav_key = None
    try:
        # 領域と窓の領域だけを求める（前は使わない Quad View の RegionView3D まで毎回求めていた）。
        # 求める領域は _event_region_xy_for_window と同じ関数（cu._event_view3d_area_region）の答え。
        area, region = cu._event_view3d_area_region(context, event)
        value = bool(area is not None and region is not None and getattr(area, 'type', None) == 'VIEW_3D' and getattr(region, 'type', None) == 'WINDOW')
    except Exception:
        return False
    if nav_key is not None:
        _SMART_NAV_INSIDE_CACHE['key'] = nav_key
        _SMART_NAV_INSIDE_CACHE['at'] = time.perf_counter()
        _SMART_NAV_INSIDE_CACHE['value'] = value
    return value


def _smart_gizmo_modal_event_supported(event) -> bool:
    """Return True only for events the Smart Gizmo watcher owns.

    The watcher is a WindowManager modal handler, so keyboard/menu/popup events
    also pass through it.  Restricting the modal to pointer/navigation events is
    essential: Smart Gizmo does not need generic key events, and touching them
    can disturb Blender's normal UI routing.
    """
    try:
        etype = str(getattr(event, 'type', '') or '')
    except Exception:
        etype = ''
    if etype in {'TIMER', 'TIMER0', 'TIMER1', 'TIMER2'}:
        return True
    if etype in _SMART_GIZMO_VIEW_NAV_EVENTS or etype in _SMART_GIZMO_VIEW_NAV_BUTTON_EVENTS:
        return True
    if etype in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE', 'LEFTMOUSE', 'EVT_TWEAK_L'}:
        return True
    return False


def _hit_test_gizmo_for_event(context, event, *, accept_exact_hover=False):
    """Return (hit_id, area, region, mx, my, tool_active) for a mouse event.

    The Smart Gizmo is drawn in a concrete View3D window region.  This helper
    resolves the same region from window coordinates before hit-testing, so the
    X/Y/Z drawing and the click target use the same region_data.  The optional
    hover fallback is deliberately limited to an almost unchanged mouse position;
    broad hover reuse makes the visible axis and the accepted axis feel offset.
    """
    area, region, mx, my, event_rv3d = _event_region_xy_rv3d_for_window(context, event)
    hit_id = None
    tool_active = False
    if not area or not region:
        return None, area, region, int(mx), int(my), False
    if not _smart_view_master_visible(context, area):
        # Hidden handles are pass-through.  Do not reuse a cached hover or
        # admit a new click while this viewport's master switch is disabled.
        return None, area, region, int(mx), int(my), False

    prev_hover_for_press = None
    prev_hover_win_for_press = None
    try:
        prev_hover_for_press = cg._SMART_GIZMO_HOVER_ID
        if bool(getattr(cg, '_SMART_GIZMO_MOUSE_VALID', False)):
            prev_hover_win_for_press = tuple(cg._SMART_GIZMO_MOUSE_WIN)
    except Exception:
        prev_hover_for_press = None
        prev_hover_win_for_press = None

    try:
        cg._SMART_GIZMO_MOUSE_WIN = (int(getattr(event, 'mouse_x', 0)), int(getattr(event, 'mouse_y', 0)))
        cg._SMART_GIZMO_MOUSE_VALID = True
        cg._SMART_GIZMO_MOUSE = (int(mx), int(my))
    except Exception:
        pass

    # PRESS should not pay for a full Smart Gizmo cache refresh when the previous
    # hover check already resolved this exact pixel.  Reusing a same-pixel hover
    # or same-pixel miss keeps Immediate Select responsive while preserving the
    # required priority of a visible Smart Gizmo handle over geometry behind it.
    if accept_exact_hover:
        try:
            last_xy = getattr(cg, '_SMART_GIZMO_LAST_HOVER_MOUSE_WIN', (None, None))
            lx, ly = last_xy
            wx = float(getattr(event, 'mouse_x', 0))
            wy = float(getattr(event, 'mouse_y', 0))
            last_t = float(getattr(cg, '_SMART_GIZMO_LAST_HOVER_CHECK_AT', 0.0) or 0.0)
            max_gap = max(2.0, min(4.0, float(_smart_pick_factor()) * 0.45))
            if lx is not None and ly is not None and (time.perf_counter() - last_t) <= 0.18 and math.hypot(wx - float(lx), wy - float(ly)) <= max_gap:
                try:
                    tool_active_cached = (_smart_tool_kind(context) is not None)
                except Exception:
                    tool_active_cached = False
                if tool_active_cached and _smart_enabled():
                    cached_hit = prev_hover_for_press
                    if cached_hit in {'ROT_FREE_X', 'ROT_FREE_Y', 'ROT_FREE_Z', 'ROT_VIEW'}:
                        orient_type = _smart_get_orient_type(context)
                        rotation_axis_mask = _smart_pose_local_rotation_axis_mask(context, orient_type)
                        cached_hit = cached_hit if any(rotation_axis_mask) else None
                    elif cached_hit in {'ROT_X', 'ROT_Y', 'ROT_Z'}:
                        orient_type = _smart_get_orient_type(context)
                        rotation_axis_mask = _smart_pose_local_rotation_axis_mask(context, orient_type)
                        cached_hit = cached_hit if rotation_axis_mask['XYZ'.index(cached_hit[-1])] else None
                    return cached_hit, area, region, int(mx), int(my), True
        except Exception:
            pass

    def _resolve(ctx):
        try:
            active = _smart_tool_kind(ctx) is not None
        except Exception:
            active = False
        if not active or not _smart_enabled():
            return active, None
        try:
            _update_gizmo_cache(ctx, area, region, rv3d_override=event_rv3d)
        except Exception:
            pass
        try:
            return active, _hit_test_gizmo(int(mx), int(my), ctx, region_override=region, rv3d_override=event_rv3d)
        except Exception:
            return active, None

    if hasattr(bpy.context, 'temp_override'):
        override = _view3d_override_kwargs(context, area, region, rv3d=event_rv3d)
        # Blender accepts region_data on current builds, but older API states can
        # reject it.  Try the full override first, then fall back without it.
        for kwargs in (override, {k: v for k, v in override.items() if k != 'region_data'}):
            try:
                with bpy.context.temp_override(**kwargs):
                    tool_active, hit_id = _resolve(bpy.context)
                break
            except Exception:
                tool_active = False
                hit_id = None
    else:
        tool_active, hit_id = _resolve(context)

    if tool_active and not hit_id:
        # One more pass after invalidating the lightweight object-mode cache.
        # This repairs a stale-view matrix edge case without widening the pick
        # area beyond what is actually drawn.
        try:
            cu._invalidate_gizmo_cache()
        except Exception:
            pass
        if hasattr(bpy.context, 'temp_override'):
            override = _view3d_override_kwargs(context, area, region, rv3d=event_rv3d)
            for kwargs in (override, {k: v for k, v in override.items() if k != 'region_data'}):
                try:
                    with bpy.context.temp_override(**kwargs):
                        tool_active, hit_id = _resolve(bpy.context)
                    break
                except Exception:
                    hit_id = None
        else:
            tool_active, hit_id = _resolve(context)

    if tool_active and not hit_id and accept_exact_hover:
        try:
            prev_hover = prev_hover_for_press
            if prev_hover and prev_hover_win_for_press is not None:
                wx = float(getattr(event, 'mouse_x', 0))
                wy = float(getattr(event, 'mouse_y', 0))
                last_wx, last_wy = prev_hover_win_for_press
                # Accept only a same-frame/same-pixel hover.  This preserves the
                # STSQA6F-style ownership of a highlighted gizmo press while
                # preventing an old hover from selecting the wrong X/Y/Z axis.
                max_gap = max(2.0, min(4.0, float(_smart_pick_factor()) * 0.45))
                if math.hypot(wx - float(last_wx), wy - float(last_wy)) <= max_gap:
                    hit_id = prev_hover
                    if hit_id in {'ROT_FREE_X', 'ROT_FREE_Y', 'ROT_FREE_Z', 'ROT_VIEW'}:
                        orient_type = _smart_get_orient_type(context)
                        rotation_axis_mask = _smart_pose_local_rotation_axis_mask(context, orient_type)
                        if not any(rotation_axis_mask):
                            hit_id = None
                    elif hit_id in {'ROT_X', 'ROT_Y', 'ROT_Z'}:
                        orient_type = _smart_get_orient_type(context)
                        rotation_axis_mask = _smart_pose_local_rotation_axis_mask(context, orient_type)
                        if not rotation_axis_mask['XYZ'.index(hit_id[-1])]:
                            hit_id = None
        except Exception:
            pass

    return hit_id, area, region, int(mx), int(my), bool(tool_active)


def _gizmo_pending_from_hit_id(gid, context=None):
    gid = str(gid or '')
    mode = 'G'
    pending = {'kind': 'NONE', 'idx': -1, 'space': 'GLOBAL'}
    if gid.startswith('ROT_'):
        mode = 'R'
    elif gid.startswith('SCALE_'):
        mode = 'S'
    if gid in {'MOVE_X', 'ROT_X', 'SCALE_X'}:
        pending = {'kind': 'AXIS', 'idx': 0}
    elif gid in {'MOVE_Y', 'ROT_Y', 'SCALE_Y'}:
        pending = {'kind': 'AXIS', 'idx': 1}
    elif gid in {'MOVE_Z', 'ROT_Z', 'SCALE_Z'}:
        pending = {'kind': 'AXIS', 'idx': 2}
    elif gid in {'MOVE_XY', 'SCALE_XY'}:
        pending = {'kind': 'PLANE', 'idx': 2}
    elif gid in {'MOVE_YZ', 'SCALE_YZ'}:
        pending = {'kind': 'PLANE', 'idx': 0}
    elif gid in {'MOVE_XZ', 'SCALE_XZ'}:
        pending = {'kind': 'PLANE', 'idx': 1}
    elif gid == 'ROT_VIEW':
        pending = {'kind': 'NONE', 'idx': -1}
    elif gid in {'MOVE_CENTER', 'SCALE_UNIFORM'}:
        pending = {'kind': 'FREE', 'idx': -1}
    elif gid.startswith('ROT_FREE'):
        free_idx = {'ROT_FREE_X': 0, 'ROT_FREE_Y': 1, 'ROT_FREE_Z': 2}.get(gid, -1)
        pending = {'kind': 'FREE', 'idx': free_idx}
    orient = None
    try:
        if context is not None:
            orient = _smart_get_orient_type(context)
    except Exception:
        orient = None
    if not orient:
        try:
            orient = cg._SMART_GIZMO_CACHE.get('orient_mode', 'GLOBAL')
        except Exception:
            orient = 'GLOBAL'
    try:
        orient = str(orient or 'GLOBAL')
    except Exception:
        orient = 'GLOBAL'
    pending['space'] = orient
    return mode, pending, orient


def _native_constraint_from_pending(pending):
    try:
        idx = int(pending.get('idx', -1))
        kind = str(pending.get('kind', '') or '')
    except Exception:
        return None
    if idx not in (0, 1, 2):
        return None
    if kind == 'AXIS':
        axis = [False, False, False]
        axis[idx] = True
        return tuple(axis)
    if kind == 'PLANE':
        axis = [True, True, True]
        axis[idx] = False
        return tuple(axis)
    return None


def _smart_resolve_view_region_data(context, area=None, region=None):
    """Return the RegionView3D for the exact View3D where Smart Gizmo is drawn."""
    try:
        if region is not None:
            rv3d = getattr(region, 'data', None)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    try:
        if area is not None:
            rv3d = cu._view3d_region_data(area, region)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    try:
        rv3d = getattr(context, 'region_data', None)
        if rv3d is not None:
            return rv3d
    except Exception:
        pass
    try:
        area2, region2 = cu._get_view3d_area_region(context)
        if region2 is not None:
            rv3d = getattr(region2, 'data', None)
            if rv3d is not None:
                return rv3d
        if area2 is not None:
            rv3d = cu._view3d_region_data(area2, region2)
            if rv3d is not None:
                return rv3d
    except Exception:
        pass
    return None


def _smart_view_orientation_signature_from_rv3d(rv3d):
    """Return a stable signature for the current View/WorkPlane axis angle.

    VIEW orientation is dynamic.  Use RegionView3D.view_rotation first because
    it updates immediately when the user operates the viewport; view_matrix may
    be one redraw behind on some platforms.  Include the resolved basis as a
    secondary guard when available.
    """
    if rv3d is None:
        return None
    vals = []
    try:
        vr = getattr(rv3d, 'view_rotation', None)
        if vr is not None:
            vals.extend(round(float(v), 8) for v in vr[:])
    except Exception:
        pass
    try:
        mat = _smart_view_basis_matrix_from_rv3d(rv3d)
        if mat is not None:
            vals.extend(round(float(mat[r][c]), 8) for r in range(3) for c in range(3))
    except Exception:
        pass
    if vals:
        return tuple(vals)
    return None

def _smart_view_orientation_signature(context=None, area=None, region=None, rv3d=None):
    """Return the current View orientation signature for VIEW/WORKPLANE axes."""
    try:
        if rv3d is None:
            rv3d = _smart_resolve_view_region_data(context, area, region)
        if rv3d is None:
            return None
        try:
            ptr = int(rv3d.as_pointer()) if hasattr(rv3d, 'as_pointer') else 0
        except Exception:
            ptr = 0
        sig = _smart_view_orientation_signature_from_rv3d(rv3d)
        if sig is None:
            return (ptr,)
        return (ptr,) + tuple(sig)
    except Exception:
        return None

def _smart_axes_payload_is_valid_axes(axes):
    """Return True when axes is three finite, non-degenerate 3D vectors."""
    try:
        if axes is None or len(axes) < 3:
            return False
        for axis in tuple(axes)[:3]:
            if axis is None or len(axis) < 3:
                return False
            values = [float(axis[0]), float(axis[1]), float(axis[2])]
            if not all(math.isfinite(v) for v in values):
                return False
            if Vector(values).length < 1.0e-9:
                return False
        return True
    except Exception:
        return False


def _smart_remember_grs_orientation_payload(payload):
    """Store the latest Smart Gizmo basis for later immediate-select drags."""
    try:
        if not isinstance(payload, dict):
            return None
        axes = payload.get('axes', None)
        if not _smart_axes_payload_is_valid_axes(axes):
            return None
        x = Vector(axes[0]).normalized()
        y = Vector(axes[1]).normalized()
        z = Vector(axes[2]).normalized()
        space = str(payload.get('space', '') or 'GLOBAL')
        cg._SMART_GIZMO_LAST_ORIENT_AXES = (tuple(x), tuple(y), tuple(z))
        cg._SMART_GIZMO_LAST_ORIENT_SPACE = space
        cg._SMART_GIZMO_LAST_ORIENT_TIME = time.perf_counter()
        try:
            view_sig = payload.get('view_signature', None)
            cg._SMART_GIZMO_LAST_ORIENT_VIEW_SIG = tuple(view_sig) if view_sig is not None else None
        except Exception:
            cg._SMART_GIZMO_LAST_ORIENT_VIEW_SIG = None
        try:
            pv = payload.get('pivot', None)
            cg._SMART_GIZMO_LAST_ORIENT_PIVOT = tuple(Vector(pv)) if pv is not None else None
        except Exception:
            cg._SMART_GIZMO_LAST_ORIENT_PIVOT = None
        result = {
            'space': space,
            'axes': cg._SMART_GIZMO_LAST_ORIENT_AXES,
            'matrix': (
                (float(x.x), float(y.x), float(z.x)),
                (float(x.y), float(y.y), float(z.y)),
                (float(x.z), float(y.z), float(z.z)),
            ),
        }
        if cg._SMART_GIZMO_LAST_ORIENT_VIEW_SIG is not None:
            result['view_signature'] = cg._SMART_GIZMO_LAST_ORIENT_VIEW_SIG
        if cg._SMART_GIZMO_LAST_ORIENT_PIVOT is not None:
            result['pivot'] = cg._SMART_GIZMO_LAST_ORIENT_PIVOT
        return result
    except Exception:
        return None


def _smart_last_orientation_payload_if_scene_unchanged(context, area=None, region=None):
    """Return the last Smart Gizmo basis only when it is still spatially valid.

    VIEW / WORKPLANE orientations are defined by the current viewport rotation,
    not only by the scene orientation slot.  Reusing the previous Smart Gizmo
    basis after the user orbits the viewport makes X/Y/Z and XY/YZ/XZ
    constraints keep the old view angle.  Therefore view-based orientations are
    intentionally rebuilt at each Smart G-R-S start.
    """
    try:
        current = str(_smart_get_orient_type(context) or 'GLOBAL')
    except Exception:
        current = 'GLOBAL'
    if current in {'VIEW', 'WORKPLANE'}:
        return None
    try:
        last_space = str(getattr(cg, '_SMART_GIZMO_LAST_ORIENT_SPACE', '') or '')
        axes = getattr(cg, '_SMART_GIZMO_LAST_ORIENT_AXES', None)
        if not last_space or last_space != current or not _smart_axes_payload_is_valid_axes(axes):
            return None
        x = Vector(axes[0]).normalized()
        y = Vector(axes[1]).normalized()
        z = Vector(axes[2]).normalized()
        payload = {
            'space': current,
            'axes': (tuple(x), tuple(y), tuple(z)),
            'matrix': (
                (float(x.x), float(y.x), float(z.x)),
                (float(x.y), float(y.y), float(z.y)),
                (float(x.z), float(y.z), float(z.z)),
            ),
        }
        pv = getattr(cg, '_SMART_GIZMO_LAST_ORIENT_PIVOT', None)
        if pv is not None:
            payload['pivot'] = pv
        return payload
    except Exception:
        return None


def _smart_orientation_payload_for_direct_grs(context, area=None, region=None, *, force_fresh: bool = False, rv3d_override=None):
    """Return a fixed orientation basis for non-gizmo Smart G-R-S starts.

    Immediate Select -> held drag does not press a visible gizmo handle, but axis
    keys / middle-mouse constraints must still use the same coordinate system as
    the Smart Gizmo.  If the user has not changed the transform orientation since
    the previous Smart Gizmo operation, reuse that exact basis.  Otherwise build
    a fresh basis from the current View3D/scene orientation.
    """
    if not bool(force_fresh):
        payload = _smart_last_orientation_payload_if_scene_unchanged(context, area, region)
        if payload is not None:
            return payload
    try:
        rv3d = rv3d_override or _smart_resolve_view_region_data(context, area, region)
        if region is None:
            try:
                area2, region2 = cu._get_view3d_area_region(context)
                if area is None:
                    area = area2
                region = region2
            except Exception:
                pass
        pivot, axes = _smart_pivot_location_and_axes(context, region_override=region, rv3d_override=rv3d)
        if not axes or len(axes) < 3:
            return None
        x = Vector(axes[0]).normalized()
        y = Vector(axes[1]).normalized()
        z = Vector(axes[2]).normalized()
        if x.length_squared <= 1.0e-12 or y.length_squared <= 1.0e-12 or z.length_squared <= 1.0e-12:
            return None
        space = str(axes[3] if len(axes) >= 4 else _smart_get_orient_type(context) or 'GLOBAL')
        payload = {
            'space': space or 'GLOBAL',
            'axes': (tuple(x), tuple(y), tuple(z)),
            'matrix': (
                (float(x.x), float(y.x), float(z.x)),
                (float(x.y), float(y.y), float(z.y)),
                (float(x.z), float(y.z), float(z.z)),
            ),
        }
        if (space or 'GLOBAL') in {'VIEW', 'WORKPLANE'}:
            vsig = _smart_view_orientation_signature(context, area, region, rv3d)
            if vsig is not None:
                payload['view_signature'] = tuple(vsig)
        if pivot is not None:
            pv = Vector(pivot)
            payload['pivot'] = (float(pv.x), float(pv.y), float(pv.z))
        if space in {'VIEW', 'WORKPLANE'}:
            view_sig = _smart_view_orientation_signature(context, area, region, rv3d)
            if view_sig is not None:
                payload['view_signature'] = view_sig
            payload['dynamic_view'] = True
        try:
            if bool(force_fresh):
                _smart_remember_grs_orientation_payload(payload)
        except Exception:
            pass
        return payload
    except Exception:
        return None

def _smart_axes_payload_from_geo(geo):
    try:
        if not geo or not isinstance(geo, dict):
            return None
        axes = geo.get('axes', None)
        if not axes or len(axes) < 3:
            return None
        x = Vector(axes[0]).normalized()
        y = Vector(axes[1]).normalized()
        z = Vector(axes[2]).normalized()
        if x.length_squared <= 1.0e-12 or y.length_squared <= 1.0e-12 or z.length_squared <= 1.0e-12:
            return None
        orient = str(geo.get('orient_type', '') or 'GLOBAL')
        return (tuple(x), tuple(y), tuple(z), orient or 'GLOBAL')
    except Exception:
        return None


def _smart_gizmo_exact_axes_for_invoke(context, area=None, region=None, rv3d_override=None):
    """Return the exact world axes currently drawn by Smart Gizmo.

    3ds Max-style gizmo behavior constrains on the visible gizmo axes.  This
    uses the concrete View3D area/region from the click event so VIEW /
    WORKPLANE never falls back to Global axes during Smart G-R-S modal callbacks.
    """
    try:
        # Pointer events in Quad View already resolve the exact pane-specific
        # RegionView3D.  Do not discard that value and fall back to region.data,
        # which can still point at the last active pane in Blender 5.1.
        rv3d = rv3d_override or _smart_resolve_view_region_data(context, area, region)
        if region is None:
            try:
                area2, region2 = cu._get_view3d_area_region(context)
                if area is None:
                    area = area2
                region = region2
            except Exception:
                pass
        if region is not None and rv3d is not None:
            override = _view3d_override_kwargs(context, area, region, rv3d=rv3d) if area is not None else {}
            candidates = []
            if override:
                candidates.append(override)
                candidates.append({k: v for k, v in override.items() if k != 'region_data'})
            candidates.append(None)
            for kwargs in candidates:
                try:
                    if kwargs and hasattr(bpy.context, 'temp_override'):
                        with bpy.context.temp_override(**kwargs):
                            geo = _smart_gizmo_geometry(bpy.context, region, rv3d)
                    else:
                        geo = _smart_gizmo_geometry(context, region, rv3d)
                    payload = _smart_axes_payload_from_geo(geo)
                    if payload is not None:
                        return payload
                except Exception:
                    continue
    except Exception:
        pass
    try:
        current_orient = str(_smart_get_orient_type(context) or 'GLOBAL')
    except Exception:
        current_orient = 'GLOBAL'
    if current_orient in {'VIEW', 'WORKPLANE'}:
        # Never fall back to cached VIEW axes.  The viewport can rotate while the
        # orientation slot remains "VIEW", so stale cache axes are worse than no
        # payload.  Build a current basis from the event View3D instead.
        try:
            rv3d = _smart_resolve_view_region_data(context, area, region)
            if rv3d is not None:
                mat = _smart_get_orientation_matrix(context, getattr(context, 'active_object', None), current_orient, None, rv3d)
                x = Vector(mat.col[0]).normalized()
                y = Vector(mat.col[1]).normalized()
                z = Vector(mat.col[2]).normalized()
                if x.length_squared > 1.0e-12 and y.length_squared > 1.0e-12 and z.length_squared > 1.0e-12:
                    return (tuple(x), tuple(y), tuple(z), current_orient)
        except Exception:
            pass
        return None
    try:
        axes = cg._SMART_GIZMO_CACHE.get('axes', None)
        if axes and len(axes) >= 3:
            x = Vector(axes[0]).normalized()
            y = Vector(axes[1]).normalized()
            z = Vector(axes[2]).normalized()
            orient = str(axes[3] if len(axes) >= 4 else cg._SMART_GIZMO_CACHE.get('orient_mode', 'GLOBAL'))
            if x.length_squared > 1.0e-12 and y.length_squared > 1.0e-12 and z.length_squared > 1.0e-12:
                return (tuple(x), tuple(y), tuple(z), orient or 'GLOBAL')
    except Exception:
        pass
    return None


def _smart_gizmo_orientation_payload_for_grs(context, area=None, region=None, rv3d_override=None):
    """Return a Smart G-R-S orientation payload from the visible Smart Gizmo axes."""
    try:
        exact_axes = _smart_gizmo_exact_axes_for_invoke(context, area, region, rv3d_override=rv3d_override)
        if exact_axes is None:
            return None
        x = Vector(exact_axes[0]).normalized()
        y = Vector(exact_axes[1]).normalized()
        z = Vector(exact_axes[2]).normalized()
        if x.length_squared <= 1.0e-12 or y.length_squared <= 1.0e-12 or z.length_squared <= 1.0e-12:
            return None
        space = str(exact_axes[3] or _smart_get_orient_type(context) or 'GLOBAL')
        # Matrix rows arranged so columns are the visible X/Y/Z axis vectors.
        matrix = (
            (float(x.x), float(y.x), float(z.x)),
            (float(x.y), float(y.y), float(z.y)),
            (float(x.z), float(y.z), float(z.z)),
        )
        payload = {
            'space': space or 'GLOBAL',
            'axes': (tuple(x), tuple(y), tuple(z)),
            'matrix': matrix,
        }
        if space in {'VIEW', 'WORKPLANE'}:
            view_sig = _smart_view_orientation_signature(context, area, region, rv3d=rv3d_override)
            if view_sig is not None:
                payload['view_signature'] = view_sig
            payload['dynamic_view'] = True
        try:
            geo = _smart_last_good_geometry(context, allow_without_selection=False)
            if isinstance(geo, dict) and geo.get('pivot') is not None:
                pv = Vector(geo.get('pivot'))
                payload['pivot'] = (float(pv.x), float(pv.y), float(pv.z))
        except Exception:
            pass
        _smart_remember_grs_orientation_payload(payload)
        return payload
    except Exception:
        return None


def _smart_gizmo_clear_pending_grs_driver_state() -> None:
    """Clear Smart G-R-S payloads when Smart Gizmo delegates to Blender native transforms."""
    try:
        dn = getattr(bpy.app, 'driver_namespace', None)
        if not isinstance(dn, dict):
            return
        for key in (
            'STS_PENDING_GRS',
            'STS_PENDING_GRS_CTX',
            'STS_GRS_FROM_SMART_GIZMO',
            'STS_GRS_GIZMO_HIT_ID',
            'STS_PENDING_GRS_ORIENT_MATRIX',
            'STS_PENDING_GRS_ORIENT_SPACE',
            'STS_PENDING_GRS_ORIENT_AXES',
            'STS_PENDING_GRS_PIVOT',
            'STS_PENDING_GRS_ORIENT_DYNAMIC_VIEW',
            'STS_PENDING_GRS_ORIENT_VIEW_SIGNATURE',
            'STS_GRS_GIZMO_ORIENT_AXES',
            'STS_GRS_GIZMO_ORIENT_SPACE',
            'STS_GRS_GIZMO_DYNAMIC_VIEW',
            'STS_GRS_FORCE_FREE_ROTATION',
            'STS_GRS_FORCE_CIRCULAR_ROTATION',
            'STS_GRS_FORCE_SCREEN_COORDINATE_ROTATION',
            'STS_GRS_FORCE_POSITIVE_SCALE',
            'STS_GRS_FORCE_ALLOW_NEGATIVE_SCALE',
        ):
            dn.pop(key, None)
    except Exception:
        pass


def _smart_gizmo_should_use_native_transform(context) -> bool:
    try:
        if str(getattr(context, 'mode', '') or '') in {'EDIT_ARMATURE', 'POSE'}:
            # Blender's transform modal owns connected endpoints, bone locks,
            # multi-armature selection, constraints, cancel and Undo.
            return True
        return bool(cu._tool_settings_require_native_transform(context))
    except Exception:
        return False


def _invoke_smart_gizmo_native_transform(context, mode, pending, orient, area=None, region=None, rv3d_override=None):
    try:
        affect_only_state = cu._effective_transform_affect_only_state(context)
    except Exception:
        affect_only_state = {}
    native_kwargs = {'release_confirm': True}
    try:
        native_kwargs.update(cu._native_transform_context_kwargs(context, mode) or {})
    except Exception:
        pass
    is_free_rotation = bool(str(mode or '').upper() == 'R' and cu._pending_requests_free_rotation(mode, pending))
    if not is_free_rotation:
        constraint = _native_constraint_from_pending(pending)
        if constraint is not None:
            native_kwargs['constraint_axis'] = constraint
        orient_native = str(orient or 'GLOBAL')
        if orient_native == 'WORKPLANE':
            orient_native = 'VIEW'
        if orient_native in {'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT'}:
            native_kwargs['orient_type'] = orient_native
    else:
        # Smart Gizmo's free rotation disk is an XYZ/trackball-style operation.
        # Native rotate() with no constraint is a view-axis rotation, so use the
        # matching Blender native operator whenever top-right Transform Options
        # force native delegation.
        native_kwargs = cu._native_trackball_kwargs(native_kwargs)
    override = _view3d_override_kwargs(context, area, region, rv3d=rv3d_override) if (area is not None and region is not None) else {}
    try:
        def _call(op_context):
            with cu._temporary_transform_affect_only_state(bpy.context, affect_only_state):
                if mode == 'R':
                    if is_free_rotation:
                        return bpy.ops.transform.trackball(op_context, **native_kwargs)
                    return bpy.ops.transform.rotate(op_context, **native_kwargs)
                if mode == 'S':
                    return bpy.ops.transform.resize(op_context, **native_kwargs)
                return bpy.ops.transform.translate(op_context, **native_kwargs)
        if override and hasattr(bpy.context, 'temp_override'):
            with bpy.context.temp_override(**override):
                return _call('INVOKE_REGION_WIN')
        return _call('INVOKE_DEFAULT')
    except Exception:
        try:
            cg._CSDT_IS_DRAGGING = False
            cg._CSDT_DRAG_ACTIVE_ID = None
            cg._SMART_GIZMO_LOCKED_ID = None
        except Exception:
            pass
        return {'CANCELLED'}


def _invoke_smart_gizmo_transform(context, gid, event=None):
    """Start Smart G-R-S from the watcher without a view3d.sts_csdt_force keymap."""
    if not gid:
        return {'PASS_THROUGH'}
    prefs = cu._prefs(context)
    try:
        area, region, _mx, _my, event_rv3d = _event_region_xy_rv3d_for_window(context, event)
    except Exception:
        area = region = event_rv3d = None
    if area is not None and not _smart_view_master_visible(context, area) and not bool(getattr(cg, '_CSDT_IS_DRAGGING', False)):
        return {'PASS_THROUGH'}
    mode, pending, orient = _gizmo_pending_from_hit_id(gid, context)
    exact_axes = _smart_gizmo_exact_axes_for_invoke(context, area, region, rv3d_override=event_rv3d)
    if exact_axes is not None:
        try:
            orient = str(exact_axes[3] or orient or 'GLOBAL')
            if isinstance(pending, dict):
                pending['space'] = orient
        except Exception:
            pass
    gid_s = str(gid or '')
    orient_payload = _smart_gizmo_orientation_payload_for_grs(context, area, region, rv3d_override=event_rv3d)
    if orient_payload:
        try:
            payload_space = str(orient_payload.get('space', '') or orient or 'GLOBAL')
            orient = payload_space
            if isinstance(pending, dict):
                pending['space'] = payload_space
        except Exception:
            pass
    try:
        dn = getattr(bpy.app, 'driver_namespace', None)
        if isinstance(dn, dict):
            dn['STS_PENDING_GRS'] = dict(pending)
            dn['STS_GRS_FROM_SMART_GIZMO'] = True
            dn['STS_GRS_GIZMO_HIT_ID'] = gid_s
            if orient_payload:
                dn['STS_PENDING_GRS_ORIENT_MATRIX'] = orient_payload.get('matrix')
                dn['STS_PENDING_GRS_ORIENT_SPACE'] = orient_payload.get('space', orient)
                dn['STS_PENDING_GRS_ORIENT_AXES'] = orient_payload.get('axes')
                # Smart G-R-S consumes this legacy key.  Populate it from the
                # exact event-area payload so VIEW / custom axes do not depend
                # on a later modal context lookup.
                if orient_payload.get('axes'):
                    dn['STS_GRS_GIZMO_ORIENT_AXES'] = orient_payload.get('axes')
                    dn['STS_GRS_GIZMO_ORIENT_SPACE'] = orient_payload.get('space', orient)
                if 'pivot' in orient_payload:
                    dn['STS_PENDING_GRS_PIVOT'] = orient_payload.get('pivot')
                if orient_payload.get('dynamic_view'):
                    dn['STS_PENDING_GRS_ORIENT_DYNAMIC_VIEW'] = True
                    dn['STS_GRS_GIZMO_DYNAMIC_VIEW'] = True
                if 'view_signature' in orient_payload:
                    dn['STS_PENDING_GRS_ORIENT_VIEW_SIGNATURE'] = orient_payload.get('view_signature')
            if exact_axes is not None and not orient_payload:
                try:
                    dn['STS_GRS_GIZMO_ORIENT_AXES'] = (tuple(exact_axes[0]), tuple(exact_axes[1]), tuple(exact_axes[2]))
                    dn['STS_GRS_GIZMO_ORIENT_SPACE'] = str(orient or pending.get('space', 'GLOBAL') or 'GLOBAL')
                except Exception:
                    pass
            if mode == 'R':
                force_free_rotation = gid_s.startswith('ROT_FREE')
                use_circular_rot = bool(getattr(prefs, 'smart_gizmo_use_circular_rotation', True)) if prefs else True
                if force_free_rotation:
                    dn['STS_GRS_FORCE_FREE_ROTATION'] = True
                elif use_circular_rot:
                    dn['STS_GRS_FORCE_CIRCULAR_ROTATION'] = True
                else:
                    dn['STS_GRS_FORCE_SCREEN_COORDINATE_ROTATION'] = True
            if mode == 'S':
                block_negative_scale = bool(getattr(prefs, 'tool_disallow_negative_scale', True)) if prefs else True
                if block_negative_scale:
                    dn['STS_GRS_FORCE_POSITIVE_SCALE'] = True
                else:
                    dn['STS_GRS_FORCE_ALLOW_NEGATIVE_SCALE'] = True
    except Exception:
        pass
    try:
        cg._CSDT_DRAG_ACTIVE_ID = gid
        cg._SMART_GIZMO_LOCKED_ID = gid
        cg._SMART_GIZMO_HOVER_ID = gid
        cg._CSDT_IS_DRAGGING = True
    except Exception:
        pass
    try:
        area, region, _mx, _my, event_rv3d = _event_region_xy_rv3d_for_window(context, event)
    except Exception:
        event_rv3d = None
    if _smart_gizmo_should_use_native_transform(context):
        _smart_gizmo_clear_pending_grs_driver_state()
        result = _invoke_smart_gizmo_native_transform(context, mode, pending, orient, area, region, rv3d_override=event_rv3d)
        try:
            if result and 'CANCELLED' not in result:
                cu._remember_constraint_state_from_smart_gizmo_hit_id(gid_s)
        except Exception:
            pass
        # Register this opt-in watcher only after Blender has accepted the
        # native modal handler.  Its terminal release/cancel event is passed
        # through to the already-running native transform.  Other watcher
        # consumers keep the default non-pass-through behavior.
        try:
            native_modal = bool(result) and 'RUNNING_MODAL' in result and 'CANCELLED' not in result
        except Exception:
            native_modal = False
        if native_modal and area is not None and region is not None:
            watch_result = {'CANCELLED'}
            try:
                watch_override = _view3d_override_kwargs(context, area, region, rv3d=event_rv3d)
                if watch_override and hasattr(bpy.context, 'temp_override'):
                    with bpy.context.temp_override(**watch_override):
                        watch_result = bpy.ops.view3d.csdt_native_release_watch(
                            'INVOKE_DEFAULT',
                            terminal_pass_through=True,
                        )
                else:
                    watch_result = bpy.ops.view3d.csdt_native_release_watch(
                        'INVOKE_DEFAULT',
                        terminal_pass_through=True,
                    )
            except Exception:
                watch_result = {'CANCELLED'}
            try:
                watch_admitted = bool(watch_result) and 'RUNNING_MODAL' in watch_result and 'CANCELLED' not in watch_result
            except Exception:
                watch_admitted = False
            if not watch_admitted:
                # Native transform ownership is already live.  Do not clear
                # drag state here; keep the existing finite guardian and the
                # main Smart Gizmo watcher responsible for terminal cleanup.
                _start_smart_gizmo_guardian()
        return result
    window = _window_for_view3d_area(context, area) if area is not None else getattr(context, 'window', None)
    override = _view3d_override_kwargs(context, area, region, rv3d=event_rv3d) if (area is not None and region is not None) else {}
    try:
        bpy.app.driver_namespace['STS_PENDING_GRS_CTX'] = {'window': window, 'area': area, 'region': region, 'region_data': event_rv3d}
    except Exception:
        pass
    try:
        if area is not None and region is not None:
            # Custom Smart G-R-S keeps its existing watcher consumer; unlike
            # the native path this registration still precedes the custom
            # operator because that operator does not own Blender's native
            # transform modal.
            bpy.ops.view3d.csdt_native_release_watch('INVOKE_DEFAULT')
    except Exception:
        pass
    try:
        if override and hasattr(bpy.context, 'temp_override'):
            with bpy.context.temp_override(**override):
                return bpy.ops.transform.smart_grs_transform('INVOKE_REGION_WIN', mode=mode, release_confirm=True)
    except Exception:
        pass
    try:
        return bpy.ops.transform.smart_grs_transform('INVOKE_DEFAULT', mode=mode, release_confirm=True)
    except Exception:
        pass
    return _invoke_smart_gizmo_native_transform(context, mode, pending, orient, area, region)

def _smart_gizmo_navigation_matrix_signature(rv3d):
    """Compatibility helper returning the current matrix signature."""
    if rv3d is None:
        return None
    try:
        return (
            _smart_matrix_immutable(rv3d.view_matrix.copy()),
            _smart_matrix_immutable(rv3d.window_matrix.copy()),
        )
    except Exception:
        return None


def _smart_gizmo_navigation_snapshot_signature(key):
    # View/projection matrices are no longer stored in snapshots.
    del key
    return None


def _smart_gizmo_navigation_sync_registered() -> bool:
    # Only a callback left by 1.8.164-1.8.167 may still be registered.
    try:
        return bool(bpy.app.timers.is_registered(_smart_gizmo_navigation_sync_tick))
    except Exception:
        return False


def _stop_smart_gizmo_navigation_sync() -> None:
    """Remove the exact legacy finite callback and all transient RNA refs."""
    _SMART_GIZMO_NAV_SYNC_STATES.clear()
    try:
        cg._SMART_GIZMO_VIEW_NAV_ACTIVE = False
        cg._SMART_GIZMO_VIEW_NAV_UNTIL = 0.0
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_smart_gizmo_navigation_sync_tick):
            bpy.app.timers.unregister(_smart_gizmo_navigation_sync_tick)
    except Exception:
        pass


def _smart_gizmo_schedule_navigation_sync_slot(
    context, window, area, region, rv3d, *, duration: float = _SMART_GIZMO_NAV_SYNC_DURATION
) -> bool:
    # Live RegionView3D matrices are consumed by Draw; no navigation timer is
    # scheduled and no Window/Area/Region reference is retained.
    del context, window, area, region, rv3d, duration
    return False


def _smart_gizmo_schedule_navigation_sync(
    context=None, event=None, *, duration: float = _SMART_GIZMO_NAV_SYNC_DURATION
) -> bool:
    del context, event, duration
    return False


def _smart_gizmo_navigation_sync_tick():
    # Compatibility callback for an already-queued older generation.
    _SMART_GIZMO_NAV_SYNC_STATES.clear()
    return None



def _smart_gizmo_mark_view_navigation(active: bool) -> None:
    try:
        cg._SMART_GIZMO_VIEW_NAV_ACTIVE = bool(active)
        if not active:
            cg._SMART_GIZMO_VIEW_NAV_UNTIL = 0.0
    except Exception:
        pass


def _smart_gizmo_mark_view_navigation_pulse(duration: float = 0.12) -> None:
    try:
        cg._SMART_GIZMO_VIEW_NAV_UNTIL = max(float(getattr(cg, '_SMART_GIZMO_VIEW_NAV_UNTIL', 0.0) or 0.0), time.perf_counter() + max(0.02, float(duration)))
    except Exception:
        pass


def _smart_gizmo_view_navigation_active() -> bool:
    try:
        if bool(getattr(cg, '_SMART_GIZMO_VIEW_NAV_ACTIVE', False)):
            return True
        until = float(getattr(cg, '_SMART_GIZMO_VIEW_NAV_UNTIL', 0.0) or 0.0)
        return until > time.perf_counter()
    except Exception:
        return False


def _smart_gizmo_clear_hover_for_view_navigation() -> bool:
    """Clear hover for a view navigation; return True when the hover really changed."""
    changed = False
    try:
        changed = (cg._SMART_GIZMO_HOVER_ID is not None)
        cg._SMART_GIZMO_HOVER_ID = None
        cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
        if changed:
            cu._tag_view3d_redraw()
    except Exception:
        pass
    return bool(changed)


def _smart_view_nav_modal_running(draw: bool = False) -> bool:
    """True while Blender's own view navigation modal (rotate/pan/zoom...) runs."""
    if draw and _smart_modal_scan_draw_idle():
        return bool(_SMART_MODAL_SCAN_CACHE['nav'])
    try:
        return bool(_smart_modal_operator_scan(getattr(bpy.context, 'window_manager', None))[1])
    except Exception:
        return False


def _smart_gizmo_view_navigation_draw_active(draw: bool = False) -> bool:
    """Draw-time low-latency mode: the navigation pulse or a running view modal."""
    if _smart_gizmo_view_navigation_active():
        return True
    return _smart_view_nav_modal_running(draw)


def _smart_gizmo_nav_settle_tick():
    """One redraw after view navigation ends, so the AA halo lines come back.

    Runs only while a navigation is in progress (re-arms at 0.1 s) and stops
    after one redraw; never an idle loop.
    """
    try:
        if bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)):
            return None
        if _smart_gizmo_view_navigation_draw_active():
            return 0.1
        cu._tag_view3d_redraw()
    except Exception:
        pass
    return None


def _smart_gizmo_schedule_nav_settle() -> None:
    try:
        if not bpy.app.timers.is_registered(_smart_gizmo_nav_settle_tick):
            bpy.app.timers.register(
                _smart_gizmo_nav_settle_tick,
                first_interval=float(_SMART_GIZMO_NAV_SYNC_DURATION) + 0.02,
            )
    except Exception:
        pass


# 即時選択の先読み：重い編集メッシュの画面の当たりの貯めは、マウスが止まってから 1 回だけ作る。
# マウスが動くたびに作ると 10 万頂点で数百 ms ずつ止まり、ビュー操作の始まりも遅れていた。
_SMART_PREFETCH_REST_DELAY = 0.15
_SMART_PREFETCH_REST_REQUEST = None


def _smart_schedule_prefetch_on_rest(context, area, region, mx, my) -> None:
    """Ask for one Immediate Select prefetch after the pointer rests (Edit Mesh only)."""
    global _SMART_PREFETCH_REST_REQUEST
    try:
        if str(getattr(context, 'mode', '') or '') != 'EDIT_MESH' or area is None or region is None:
            return
        win = getattr(context, 'window', None)
        _SMART_PREFETCH_REST_REQUEST = {
            'at': time.perf_counter(),
            'win': int(win.as_pointer()) if win is not None else 0,
            'area': int(area.as_pointer()),
            'region': int(region.as_pointer()),
            'mx': int(mx), 'my': int(my),
        }
        if not bpy.app.timers.is_registered(_smart_prefetch_rest_tick):
            bpy.app.timers.register(_smart_prefetch_rest_tick, first_interval=_SMART_PREFETCH_REST_DELAY)
    except Exception:
        pass


def _smart_prefetch_rest_tick():
    """Run the deferred prefetch once; re-arms only while the pointer keeps moving."""
    global _SMART_PREFETCH_REST_REQUEST
    try:
        req = _SMART_PREFETCH_REST_REQUEST
        if not req or bool(getattr(cg, '_SMART_GIZMO_SHUTDOWN', True)):
            _SMART_PREFETCH_REST_REQUEST = None
            return None
        wait = float(req['at']) + _SMART_PREFETCH_REST_DELAY - time.perf_counter()
        if wait > 0.005:
            return wait
        _SMART_PREFETCH_REST_REQUEST = None
        if (
            _smart_gizmo_view_navigation_draw_active()
            or bool(getattr(cg, '_CSDT_IS_DRAGGING', False))
            or getattr(cg, '_SMART_GIZMO_LOCKED_ID', None) is not None
            or getattr(cg, '_SMART_GIZMO_HOVER_ID', None) is not None
        ):
            return None
        wm = getattr(bpy.context, 'window_manager', None)
        for window in tuple(getattr(wm, 'windows', ()) or ()):
            if int(window.as_pointer()) != int(req['win']):
                continue
            for area in tuple(getattr(getattr(window, 'screen', None), 'areas', ()) or ()):
                if int(area.as_pointer()) != int(req['area']) or getattr(area, 'type', None) != 'VIEW_3D':
                    continue
                for region in tuple(getattr(area, 'regions', ()) or ()):
                    if int(region.as_pointer()) != int(req['region']) or getattr(region, 'type', None) != 'WINDOW':
                        continue
                    rv3d = cu._view3d_region_data(area, region)
                    if rv3d is None:
                        return None
                    with bpy.context.temp_override(window=window, area=area, region=region, region_data=rv3d):
                        ctx = bpy.context
                        if str(getattr(ctx, 'mode', '') or '') != 'EDIT_MESH':
                            return None
                        prefs = cu._prefs(ctx)
                        if prefs is not None and bool(getattr(prefs, 'use_immediate_select', False)):
                            cu._prefetch_immediate_select_hit(ctx, int(req['mx']), int(req['my']), mode='rest')
                    return None
    except Exception:
        pass
    return None


def _smart_gizmo_release_interaction_state_immediately() -> bool:
    """Clear the pressed/selected Smart Gizmo handle on the release event itself.

    Smart G-R-S and Blender native transforms finish their own modal cleanup
    later in the same event dispatch.  Waiting for that cleanup, or for the
    0.01-second native-release safety watcher, leaves the handle locked/hovered
    long enough for a rapid follow-up click to be interpreted as if the gizmo
    were still held.  These flags are visual/hit-test ownership only, so they can
    be released before the transform operator completes its final confirmation.
    """
    changed = False
    try:
        last_hover_mouse = getattr(cg, '_SMART_GIZMO_LAST_HOVER_MOUSE_WIN', (None, None))
        changed = bool(
            getattr(cg, '_CSDT_IS_DRAGGING', False)
            or getattr(cg, '_CSDT_DRAG_ACTIVE_ID', None)
            or getattr(cg, '_SMART_GIZMO_LOCKED_ID', None)
            or getattr(cg, '_SMART_GIZMO_HOVER_ID', None)
            or getattr(cg, '_SMART_GIZMO_MOUSE_VALID', False)
            or float(getattr(cg, '_SMART_GIZMO_LAST_HOVER_CHECK_AT', 0.0) or 0.0) > 0.0
            or tuple(last_hover_mouse or (None, None)) != (None, None)
        )
        cg._CSDT_IS_DRAGGING = False
        cg._CSDT_DRAG_ACTIVE_ID = None
        cg._SMART_GIZMO_LOCKED_ID = None
        cg._SMART_GIZMO_HOVER_ID = None
        cg._SMART_GIZMO_MOUSE_VALID = False
        cg._SMART_GIZMO_LAST_HOVER_CHECK_AT = 0.0
        cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
    except Exception:
        pass
    if changed:
        try:
            cu._invalidate_gizmo_cache()
        except Exception:
            pass
        try:
            cu._tag_view3d_redraw()
        except Exception:
            pass
        try:
            _start_smart_gizmo_guardian()
        except Exception:
            pass
    return changed


def _smart_gizmo_event_is_view_navigation(event) -> bool:
    try:
        etype = str(getattr(event, 'type', '') or '')
        evalue = str(getattr(event, 'value', '') or '')
    except Exception:
        return False
    if etype in _SMART_GIZMO_VIEW_NAV_EVENTS:
        return True
    if etype in _SMART_GIZMO_VIEW_NAV_BUTTON_EVENTS and evalue in {'PRESS', 'CLICK_DRAG'}:
        return True
    return False


def _smart_gizmo_should_throttle_hover(event) -> bool:
    try:
        wx = float(getattr(event, 'mouse_x', 0.0))
        wy = float(getattr(event, 'mouse_y', 0.0))
    except Exception:
        wx = wy = 0.0
    try:
        last = getattr(cg, '_SMART_GIZMO_LAST_HOVER_MOUSE_WIN', (None, None))
        lx, ly = last
        moved = True if lx is None or ly is None else (math.hypot(wx - float(lx), wy - float(ly)) >= _SMART_GIZMO_HOVER_MIN_MOVE_PX)
    except Exception:
        moved = True
    try:
        now = time.perf_counter()
        last_t = float(getattr(cg, '_SMART_GIZMO_LAST_HOVER_CHECK_AT', 0.0) or 0.0)
        if not moved and (now - last_t) < _SMART_GIZMO_HOVER_MIN_INTERVAL:
            return True
        if (now - last_t) < _SMART_GIZMO_HOVER_MIN_INTERVAL and not bool(getattr(cg, '_SMART_GIZMO_HOVER_ID', None)):
            return True
        cg._SMART_GIZMO_LAST_HOVER_CHECK_AT = now
        cg._SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (wx, wy)
    except Exception:
        pass
    return False


def _smart_gizmo_immediate_select_hit_under_event(context, event, area=None, region=None, mx=None, my=None):
    """Return the selectable target beneath a Smart Gizmo press.

    This probe runs only for the explicit click-priority option and never changes
    selection.  The result is passed to the transient click arbiter so a release
    can select it while a real drag can still start the hovered gizmo handle.
    """
    try:
        prefs = cu._prefs(context)
        if prefs is None or not bool(getattr(prefs, 'smart_gizmo_click_select_priority', False)):
            return None, None
    except Exception:
        return None, None
    try:
        if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
            return None, None
    except Exception:
        return None, None
    try:
        mode = str(getattr(context, 'mode', '') or '')
    except Exception:
        mode = ''
    if mode not in {'OBJECT', 'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE'}:
        return None, None

    if area is None or region is None or mx is None or my is None:
        try:
            area, region, mx, my = _event_region_xy_for_window(context, event)
        except Exception:
            area = region = None
            mx = getattr(event, 'mouse_region_x', 0)
            my = getattr(event, 'mouse_region_y', 0)
    if area is None or region is None:
        return None, None

    def _resolve(ctx):
        try:
            obj = getattr(ctx, 'active_object', None)
        except Exception:
            obj = None
        try:
            if mode == 'OBJECT':
                hit = cu._hit_test_object(ctx, int(mx), int(my))
                return (hit[0] if hit else obj), hit
            if mode == 'EDIT_MESH' and obj is not None and getattr(obj, 'type', None) == 'MESH':
                return cu._hit_test_editmesh_any(ctx, obj, int(mx), int(my))
            if mode == 'EDIT_LATTICE' and obj is not None and getattr(obj, 'type', None) == 'LATTICE':
                return cu._hit_test_editlattice_any(ctx, obj, int(mx), int(my))
            if mode in {'EDIT_CURVE', 'EDIT_SURFACE'} and obj is not None and getattr(obj, 'type', None) in {'CURVE', 'SURFACE'}:
                return cu._hit_test_editcurve_any(ctx, obj, int(mx), int(my))
        except Exception:
            return obj, None
        return obj, None

    try:
        override = _view3d_override_kwargs(context, area, region)
    except Exception:
        override = {}
    if override and hasattr(bpy.context, 'temp_override'):
        for kwargs in (override, {k: v for k, v in override.items() if k != 'region_data'}):
            try:
                with bpy.context.temp_override(**kwargs):
                    return _resolve(bpy.context)
            except Exception:
                continue
    return _resolve(context)


def _smart_gizmo_selection_mode_from_event(event) -> str:
    """Freeze Smart Transform's deterministic selection mode at mouse press."""
    try:
        if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
            return ''
        shift = bool(getattr(event, 'shift', False))
        ctrl = bool(getattr(event, 'ctrl', False))
    except Exception:
        return ''
    if shift and ctrl:
        return 'XOR'
    if ctrl:
        return 'SUB'
    if shift:
        return 'ADD'
    return 'SET'


def _smart_gizmo_press_should_defer_to_immediate_select(context, event, area=None, region=None, mx=None, my=None) -> bool:
    """Return True when a selectable gizmo press should wait for click-vs-drag."""
    del area, region, mx, my
    try:
        prefs = cu._prefs(context)
        if prefs is None or not bool(getattr(prefs, 'smart_gizmo_click_select_priority', False)):
            return False
    except Exception:
        return False
    try:
        if str(getattr(event, 'type', '') or '') != 'LEFTMOUSE' or str(getattr(event, 'value', '') or '') != 'PRESS':
            return False
        # Shift/Ctrl are selection modifiers if this gesture remains a click.
        # If it becomes a drag, the same live modifiers are still passed to
        # Smart G-R-S for precision/snap. Alt/OSKey remain Blender-native.
        if not _smart_gizmo_selection_mode_from_event(event):
            return False
    except Exception:
        return False
    return bool(_smart_gizmo_context_mode_supported_for_click(context))


def _smart_gizmo_supported_click_tool(context) -> str:
    try:
        tool_id = str(cu._active_tool_id(context) or '')
    except Exception:
        tool_id = ''
    try:
        select_ids = getattr(cu, '_SELECT_TOOL_IDS', {'builtin.select', 'builtin.select_box', 'builtin.select_circle', 'builtin.select_lasso'})
    except Exception:
        select_ids = {'builtin.select', 'builtin.select_box', 'builtin.select_circle', 'builtin.select_lasso'}
    try:
        transform_ids = set(getattr(cg, '_TRANSFORM_TOOL_IDS', set()) or set())
    except Exception:
        transform_ids = set()
    if tool_id in select_ids or tool_id in transform_ids:
        return tool_id
    return ''


def _smart_gizmo_context_mode_supported_for_click(context) -> bool:
    try:
        return str(getattr(context, 'mode', '') or '') in {'OBJECT', 'EDIT_MESH', 'EDIT_LATTICE', 'EDIT_CURVE', 'EDIT_SURFACE'}
    except Exception:
        return False


def _smart_gizmo_event_should_dispatch_click_handler(context, event, *, area=None, region=None) -> tuple[bool, str, int, int]:
    try:
        if str(getattr(event, 'type', '') or '') != 'LEFTMOUSE' or str(getattr(event, 'value', '') or '') != 'PRESS':
            return False, '', 0, 0
        if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
            return False, '', 0, 0
    except Exception:
        return False, '', 0, 0
    if not _csdt_click_runtime_pref_enabled(context):
        return False, '', 0, 0
    if not _smart_gizmo_context_mode_supported_for_click(context):
        return False, '', 0, 0
    try:
        if area is None or region is None:
            area, region, mx, my = _event_region_xy_for_window(context, event)
        else:
            mx = int(getattr(event, 'mouse_x', 0)) - int(getattr(region, 'x', 0) or 0)
            my = int(getattr(event, 'mouse_y', 0)) - int(getattr(region, 'y', 0) or 0)
    except Exception:
        return False, '', 0, 0
    if area is None or region is None or getattr(area, 'type', None) != 'VIEW_3D':
        return False, '', 0, 0
    tool_id = ''
    try:
        override = _view3d_override_kwargs(context, area, region)
    except Exception:
        override = {}
    if override and hasattr(bpy.context, 'temp_override'):
        for kwargs in (override, {k: v for k, v in override.items() if k != 'region_data'}):
            try:
                with bpy.context.temp_override(**kwargs):
                    tool_id = _smart_gizmo_supported_click_tool(bpy.context)
                break
            except Exception:
                tool_id = ''
    if not tool_id:
        tool_id = _smart_gizmo_supported_click_tool(context)
    if not tool_id:
        return False, '', 0, 0
    return True, tool_id, int(mx), int(my)


def _smart_gizmo_invoke_transient_click_handler(
    context,
    event,
    *,
    area=None,
    region=None,
    mx=None,
    my=None,
    action='',
    gizmo_hit_id='',
    selection_target=None,
    selection_hit=None,
):
    try:
        if area is None or region is None or mx is None or my is None:
            area, region, mx, my = _event_region_xy_for_window(context, event)
        if area is None or region is None:
            return {'PASS_THROUGH'}
    except Exception:
        return {'PASS_THROUGH'}
    try:
        override = _view3d_override_kwargs(context, area, region)
    except Exception:
        override = {}
    kwargs = {
        'action': str(action or ''),
        'select_mode_hint': _smart_gizmo_selection_mode_from_event(event),
        'override_mouse_region_x': int(mx),
        'override_mouse_region_y': int(my),
    }
    if gizmo_hit_id and selection_target is not None and selection_hit is not None:
        try:
            mode = str(getattr(context, 'mode', '') or '')
            if mode == 'OBJECT':
                hit_payload = {'selected': bool(selection_hit[1])}
            else:
                hit_payload = selection_hit
            kwargs.update({
                'deferred_gizmo_hit_id': str(gizmo_hit_id),
                'deferred_gizmo_selection_payload': json.dumps(
                    {
                        'mode': mode,
                        'target': str(getattr(selection_target, 'name', '') or ''),
                        'hit': hit_payload,
                    },
                    ensure_ascii=True,
                    separators=(',', ':'),
                ),
            })
        except Exception:
            return {'PASS_THROUGH'}
    try:
        if override and hasattr(bpy.context, 'temp_override'):
            with bpy.context.temp_override(**override):
                return bpy.ops.view3d.sts_csdt_force('INVOKE_DEFAULT', **kwargs)
        return bpy.ops.view3d.sts_csdt_force('INVOKE_DEFAULT', **kwargs)
    except Exception:
        return {'PASS_THROUGH'}



class VIEW3D_OT_csdt_smart_gizmo_watch(bpy.types.Operator):
    bl_idname = "view3d.csdt_smart_gizmo_watch"
    bl_label = "Smart Gizmo Watch"
    bl_description = "Internal watcher that keeps the custom 3D Smart Gizmo responsive while the supported transform tools are active"
    bl_options = {'INTERNAL'}
    bl_undo_group = 'Smart Transform Suite'

    _timer = None
    _win_ptr = 0

    def invoke(self, context, event):
        try:
            if not _event_runtime_pref_enabled(context):
                return {"CANCELLED"}
            area = getattr(context, 'area', None)
            region = getattr(context, 'region', None)
            if getattr(area, 'type', None) != 'VIEW_3D' or getattr(region, 'type', None) != 'WINDOW':
                return {"CANCELLED"}
            win = context.window
            if not win:
                return {"CANCELLED"}
            cg._SMART_GIZMO_SHUTDOWN = False
            self._win_ptr = int(win.as_pointer())
            if self._win_ptr in cg._SMART_GIZMO_WATCHERS:
                return {"CANCELLED"}
            # Do not add a WindowManager event timer here.  The watcher is
            # event-driven and must not inject TIMER events into Blender's UI
            # pipeline while menus, headers, popovers, or Preferences are being
            # used.  Runtime upkeep is handled by the low-frequency app timer
            # outside the modal event stream.
            self._timer = None
            context.window_manager.modal_handler_add(self)
            cg._SMART_GIZMO_WATCHERS[self._win_ptr] = self
            try:
                cg._SMART_GIZMO_WATCHER_HEARTBEAT[self._win_ptr] = time.time()
            except Exception:
                pass
            return {"RUNNING_MODAL"}
        except Exception:
            return {"CANCELLED"}

    def modal(self, context, event):
        # 演算子の属性の読みは _bpy_types.Operator.__getattribute__ を通り 1 回 3 µs ほどかかるので、
        # 窓の印は 1 回だけ読む（前はイベントごとに 4 回読んでいた）。読めない時の扱いは前と同じ。
        try:
            getattribute = _SMART_STRUCT_GETATTRIBUTE
            win_ptr = getattribute(self, '_win_ptr') if getattribute is not None else self._win_ptr
            win_ptr_ok = True
        except Exception:
            win_ptr = 0
            win_ptr_ok = False
        try:
            if win_ptr:
                cg._SMART_GIZMO_WATCHER_HEARTBEAT[win_ptr] = time.time()
        except Exception:
            pass
        try:
            if cg._SMART_GIZMO_SHUTDOWN or not _event_runtime_pref_enabled(context):
                self.cancel(context)
                return {"CANCELLED", "PASS_THROUGH"}

            try:
                etype = str(getattr(event, 'type', '') or '')
                evalue = str(getattr(event, 'value', '') or '')
            except Exception:
                etype = ''
                evalue = ''
            if not etype.startswith('TIMER') and etype not in _SMART_WATCH_NO_SERIAL_EVENTS:
                global _SMART_WATCH_EVENT_SERIAL
                _SMART_WATCH_EVENT_SERIAL += 1

            try:
                win = getattr(context, 'window', None)
                if not win_ptr_ok:
                    return {"PASS_THROUGH"}
                if win_ptr and (win is None or int(win.as_pointer()) != int(win_ptr)):
                    return {"PASS_THROUGH"}
            except Exception:
                return {"PASS_THROUGH"}

            if etype == 'TIMER':
                return {"PASS_THROUGH"}

            # LEFTMOUSE release must clear handle ownership immediately even
            # when the drag ends over a Sidebar, header, another editor, or just
            # outside the View3D WINDOW region. The event still passes through so
            # Smart G-R-S / Blender native Transform confirms normally.
            if etype == 'LEFTMOUSE' and evalue == 'RELEASE':
                try:
                    _smart_gizmo_release_interaction_state_immediately()
                except Exception:
                    pass
                try:
                    _start_smart_gizmo_guardian()
                except Exception:
                    pass
                # Never perform a second hover/hit-test pass on the release
                # event itself.  A fresh MOUSEMOVE or the next press resolves
                # the new pointer target from an entirely released state.
                return {"PASS_THROUGH"}

            if not _smart_gizmo_modal_event_supported(event):
                return {"PASS_THROUGH"}

            if not _smart_gizmo_event_is_inside_view3d_region(context, event, win_ptr):
                return {"PASS_THROUGH"}

            try:
                if etype in _SMART_GIZMO_VIEW_NAV_BUTTON_EVENTS:
                    if evalue in {'PRESS', 'CLICK_DRAG'}:
                        # Blender's native view modal may consume MIDDLEMOUSE
                        # RELEASE before this watcher sees it.  Never leave a
                        # permanent navigation flag behind; use a bounded pulse
                        # that is refreshed by subsequent navigation events.
                        # The draw snapshot is view independent (Draw remaps it
                        # with the live matrices), so a navigation never rebuilds
                        # it; only a hover color change needs one reconcile.
                        _smart_gizmo_mark_view_navigation(False)
                        _smart_gizmo_mark_view_navigation_pulse(_SMART_GIZMO_NAV_SYNC_DURATION)
                        if _smart_gizmo_clear_hover_for_view_navigation():
                            _start_smart_gizmo_guardian()
                        _smart_gizmo_schedule_nav_settle()
                        return {"PASS_THROUGH"}
                    if evalue in {'RELEASE', 'CLICK'}:
                        _smart_gizmo_mark_view_navigation(False)
                        _smart_gizmo_schedule_nav_settle()
                        return {"PASS_THROUGH"}
                if _smart_gizmo_event_is_view_navigation(event):
                    # Wheel/trackpad navigation events are one-shot or self-contained;
                    # skip Smart Gizmo work for that event and keep the overlay in
                    # low-latency mode for a short pulse while Blender redraws the view.
                    _smart_gizmo_mark_view_navigation_pulse(_SMART_GIZMO_NAV_SYNC_DURATION)
                    if _smart_gizmo_clear_hover_for_view_navigation():
                        _start_smart_gizmo_guardian()
                    _smart_gizmo_schedule_nav_settle()
                    return {"PASS_THROUGH"}
                if etype not in {'MOUSEMOVE'} and _smart_gizmo_view_navigation_active():
                    # Non-navigation event after a released/finished view operation:
                    # resume hover checks without forcing another redraw.
                    _smart_gizmo_mark_view_navigation(False)
            except Exception:
                pass

            if not _smart_runtime_activity_active() and not _smart_context_has_transform_selection(context):
                try:
                    event_area, event_region, _mx, _my, _rv3d = _event_region_xy_rv3d_for_window(context, event)
                    if event_area is not None and event_region is not None:
                        _smart_draw_snapshot_remove(
                            _smart_draw_snapshot_key(getattr(context, 'window', None), event_area, event_region)
                        )
                except Exception:
                    pass
                _smart_clear_cached_gizmo_state(redraw=True)
                return {"PASS_THROUGH"}

            if cg._CSDT_DRAG_ACTIVE_ID:
                if not cg._CSDT_IS_DRAGGING:
                    cg._CSDT_DRAG_ACTIVE_ID = None
                    cg._SMART_GIZMO_LOCKED_ID = None
                    cg._SMART_GIZMO_HOVER_ID = None
                    cu._tag_view3d_redraw()
                    return {"PASS_THROUGH"}
                if cg._SMART_GIZMO_HOVER_ID != cg._CSDT_DRAG_ACTIVE_ID:
                    cg._SMART_GIZMO_HOVER_ID = cg._CSDT_DRAG_ACTIVE_ID
                    cu._tag_view3d_redraw()
                try:
                    _start_smart_gizmo_guardian()
                except Exception:
                    pass
                return {"PASS_THROUGH"}

            if cg._SMART_GIZMO_LOCKED_ID is not None:
                return {"PASS_THROUGH"}

            if event.type == "LEFTMOUSE" and getattr(event, 'value', None) == "PRESS":
                try:
                    if bool(getattr(event, 'alt', False)) or bool(getattr(event, 'oskey', False)):
                        return {"PASS_THROUGH"}
                    hit_id, area, region, mx, my, tool_active = _hit_test_gizmo_for_event(context, event, accept_exact_hover=True)
                    if tool_active and hit_id:
                        if _smart_gizmo_press_should_defer_to_immediate_select(context, event, area, region, mx, my):
                            dispatch, action, _click_mx, _click_my = _smart_gizmo_event_should_dispatch_click_handler(
                                context,
                                event,
                                area=area,
                                region=region,
                            )
                            if dispatch:
                                selection_target, selection_hit = _smart_gizmo_immediate_select_hit_under_event(
                                    context,
                                    event,
                                    area=area,
                                    region=region,
                                    mx=mx,
                                    my=my,
                                )
                                if selection_target is not None and selection_hit is not None:
                                    result = _smart_gizmo_invoke_transient_click_handler(
                                        context,
                                        event,
                                        area=area,
                                        region=region,
                                        mx=mx,
                                        my=my,
                                        action=action,
                                        gizmo_hit_id=hit_id,
                                        selection_target=selection_target,
                                        selection_hit=selection_hit,
                                    )
                                    try:
                                        handled = bool(result) and ('CANCELLED' not in result) and ('PASS_THROUGH' not in result)
                                    except Exception:
                                        handled = False
                                    if handled:
                                        cg._SMART_GIZMO_HOVER_ID = hit_id
                                        cg._SMART_GIZMO_LOCKED_ID = hit_id
                                        cg._CSDT_DRAG_ACTIVE_ID = None
                                        cg._CSDT_IS_DRAGGING = False
                                        try:
                                            cu._tag_view3d_redraw()
                                        except Exception:
                                            pass
                                        return {"RUNNING_MODAL"}
                        cg._SMART_GIZMO_HOVER_ID = hit_id
                        cg._SMART_GIZMO_LOCKED_ID = hit_id
                        cg._CSDT_DRAG_ACTIVE_ID = hit_id
                        cg._CSDT_IS_DRAGGING = True
                        try:
                            cu._tag_view3d_redraw()
                        except Exception:
                            pass
                        result = {'CANCELLED'}
                        try:
                            result = _invoke_smart_gizmo_transform(context, hit_id, event)
                        except Exception:
                            result = {'CANCELLED'}
                        try:
                            ok = bool(result) and ('CANCELLED' not in result) and ('PASS_THROUGH' not in result)
                        except Exception:
                            ok = False
                        if ok:
                            return {"RUNNING_MODAL"}
                        try:
                            cg._SMART_GIZMO_LOCKED_ID = None
                            cg._CSDT_DRAG_ACTIVE_ID = None
                            cg._CSDT_IS_DRAGGING = False
                            cg._SMART_GIZMO_HOVER_ID = None
                        except Exception:
                            pass
                        return {"PASS_THROUGH"}
                except Exception:
                    try:
                        cg._SMART_GIZMO_LOCKED_ID = None
                        cg._CSDT_DRAG_ACTIVE_ID = None
                        cg._CSDT_IS_DRAGGING = False
                    except Exception:
                        pass

            if event.type == "MOUSEMOVE":
                try:
                    if _smart_gizmo_view_navigation_active():
                        if _smart_gizmo_clear_hover_for_view_navigation():
                            _start_smart_gizmo_guardian()
                        return {"PASS_THROUGH"}
                    if _smart_gizmo_should_throttle_hover(event):
                        return {"PASS_THROUGH"}
                    new_hover, area, region, mx, my, tool_active = _hit_test_gizmo_for_event(context, event, accept_exact_hover=False)
                    if tool_active and _smart_enabled() and cg._SMART_GIZMO_LOCKED_ID is None and not cg._CSDT_DRAG_ACTIVE_ID:
                        if new_hover != cg._SMART_GIZMO_HOVER_ID:
                            cg._SMART_GIZMO_HOVER_ID = new_hover
                            cu._tag_view3d_redraw()
                            _start_smart_gizmo_guardian()
                        # Warm Immediate Select's editable-element hit cache only
                        # after the visible Smart Gizmo has missed.  Gizmo hover
                        # keeps priority; geometry prefetch just moves expensive
                        # projection work out of the subsequent LEFTMOUSE PRESS so
                        # clicking a hovered element has no perceptible delay.
                        if not new_hover:
                            try:
                                prefs = cu._prefs(context)
                                if prefs is not None and bool(getattr(prefs, 'use_immediate_select', False)):
                                    now = time.perf_counter()
                                    last = float(getattr(cg, '_CSDT_IMMEDIATE_SELECT_PREFETCH_AT', 0.0) or 0.0)
                                    last_xy = getattr(cg, '_CSDT_IMMEDIATE_SELECT_PREFETCH_MOUSE_WIN', (None, None))
                                    wx = float(getattr(event, 'mouse_x', 0.0)); wy = float(getattr(event, 'mouse_y', 0.0))
                                    try:
                                        lx, ly = last_xy
                                        moved = True if lx is None or ly is None else (math.hypot(wx - float(lx), wy - float(ly)) >= 2.0)
                                    except Exception:
                                        moved = True
                                    if moved or (now - last) >= 0.055:
                                        cg._CSDT_IMMEDIATE_SELECT_PREFETCH_AT = now
                                        cg._CSDT_IMMEDIATE_SELECT_PREFETCH_MOUSE_WIN = (wx, wy)
                                        cu._prefetch_immediate_select_hit(context, int(mx), int(my))
                                        _smart_schedule_prefetch_on_rest(context, area, region, mx, my)
                            except Exception:
                                pass
                    elif cg._SMART_GIZMO_HOVER_ID is not None:
                        cg._SMART_GIZMO_HOVER_ID = None
                        cu._tag_view3d_redraw()
                except Exception:
                    pass
                return {"PASS_THROUGH"}

            try:
                if getattr(event, 'value', None) in {'PRESS', 'RELEASE', 'CLICK', 'CLICK_DRAG'}:
                    _smart_check_tool_and_update_visibility(context)
                    _start_smart_gizmo_guardian()
            except Exception:
                pass
            return {"PASS_THROUGH"}
        except KeyboardInterrupt:
            try:
                self.cancel(context)
            except Exception:
                pass
            return {"CANCELLED"}

    def cancel(self, context):
        try:
            wm = context.window_manager
            if self._timer:
                wm.event_timer_remove(self._timer)
        except Exception:
            pass
        try:
            if cg._SMART_GIZMO_WATCHERS.get(self._win_ptr) is self:
                cg._SMART_GIZMO_WATCHERS.pop(self._win_ptr, None)
                cg._SMART_GIZMO_WATCHER_HEARTBEAT.pop(self._win_ptr, None)
            self._timer = None
            _smart_gizmo_mark_view_navigation(False)
        except Exception:
            pass

def _ensure_smart_gizmo_watchers():
    if cg._SMART_GIZMO_SHUTDOWN or (not _event_runtime_pref_enabled()):
        return None
    wm = getattr(bpy.context, 'window_manager', None)
    if not wm:
        return None

    targets = _smart_runtime_targets()
    wanted_ptrs = set(targets.keys())

    if wanted_ptrs or bool(cg._SMART_GIZMO_WATCHERS) or _smart_runtime_activity_active():
        try:
            _smart_check_tool_and_update_visibility(bpy.context)
        except Exception:
            pass

    try:
        live_ptrs = {int(w.as_pointer()) for w in getattr(wm, 'windows', [])}
    except Exception:
        live_ptrs = set()

    now = time.time()
    for wptr, op in list(cg._SMART_GIZMO_WATCHERS.items()):
        # The watcher no longer owns a WM event timer, so lack of modal events
        # while the user is idle or interacting with Blender UI must not be
        # treated as a stale/frozen watcher.  Only remove watchers whose window
        # disappeared or whose runtime is no longer wanted.
        stale = False
        try:
            cg._SMART_GIZMO_WATCHER_HEARTBEAT[wptr] = now
        except Exception:
            pass
        # Keep one watcher per live window even while a non-transform tool is
        # active.  cancel() cannot end a running modal handler, so dropping the
        # entry here only orphaned it and every tool round trip started another
        # watcher (two after Move -> Select Box -> Move, measured on 5.1.2).
        if stale or wptr not in live_ptrs:
            try:
                op.cancel(bpy.context)
            except Exception:
                pass
            cg._SMART_GIZMO_WATCHERS.pop(wptr, None)
            cg._SMART_GIZMO_WATCHER_HEARTBEAT.pop(wptr, None)

    if wanted_ptrs:
        try:
            _smart_ensure_draw_handler()
        except Exception:
            pass
    else:
        try:
            _smart_remove_draw_handler()
        except Exception:
            pass
        if cg._SMART_GIZMO_HOVER_ID is not None:
            try:
                cg._SMART_GIZMO_HOVER_ID = None
                cu._tag_view3d_redraw()
            except Exception:
                pass

    if not bool(getattr(bpy.app, 'background', False)):
        for wptr, (win, area, region) in targets.items():
            if wptr in cg._SMART_GIZMO_WATCHERS:
                continue
            try:
                if hasattr(bpy.context, 'temp_override'):
                    with bpy.context.temp_override(window=win, area=area, region=region):
                        bpy.ops.view3d.csdt_smart_gizmo_watch('INVOKE_DEFAULT')
                else:
                    bpy.ops.view3d.csdt_smart_gizmo_watch('INVOKE_DEFAULT')
            except Exception:
                pass

    return None

class VIEW3D_OT_csdt_toggle_smart_gizmo(bpy.types.Operator):
    bl_idname = "view3d.csdt_toggle_smart_gizmo"
    bl_label = "Toggle 3D Smart Gizmo"
    bl_description = "Turn the custom 3D Smart Gizmo overlay on or off for the supported transform tools"
    bl_options = {'INTERNAL'}
    bl_undo_group = 'Smart Transform Suite'
    def execute(self, context):
        prefs = cu._prefs(context)
        if not prefs: return {"CANCELLED"}
        next_state = not bool(getattr(prefs, 'gizmo_toggle_state', True))
        prefs.gizmo_toggle_state = next_state
        try:
            sync_runtime_from_prefs(context)
        except Exception:
            pass
        try: _smart_check_tool_and_update_visibility(context)
        except Exception: pass
        cu._tag_view3d_redraw()
        return {"FINISHED"}

classes = (VIEW3D_OT_csdt_smart_gizmo_watch, VIEW3D_OT_csdt_toggle_smart_gizmo)

@persistent
def _gizmo_on_load_post(dummy):
    stop_runtime(restore_builtin=False)
    sync_runtime_from_prefs(bpy.context)
    try:
        _schedule_startup_runtime_bootstrap()
    except Exception:
        pass



def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass

def register():
    try:
        stop_runtime(restore_builtin=True)
    except Exception:
        pass
    try:
        _ensure_gizmo_load_post_handler()
    except Exception:
        pass
    cg._SMART_GIZMO_SHUTDOWN = False
    for c in classes:
        bpy.utils.register_class(c)
    sync_runtime_from_prefs(bpy.context)
    try:
        _schedule_startup_runtime_bootstrap()
    except Exception:
        pass

def unregister():
    stop_runtime(restore_builtin=True)
    try:
        dn = getattr(bpy.app, 'driver_namespace', None)
        if isinstance(dn, dict):
            dn.pop('STS_PENDING_GRS_ORIENT_AXES', None)
            dn.pop('STS_PENDING_GRS_ORIENT_SPACE', None)
    except Exception:
        pass
    try:
        _smart_gizmo_clear_layer_policy()
    except Exception:
        pass
    try:
        _remove_gizmo_load_post_handler()
    except Exception:
        pass
    for c in reversed(classes):
        _safe_unregister_class(c)
