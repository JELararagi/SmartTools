# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

# =========================================================
# Global State & Constants
# =========================================================
_INTERNAL_SCALE_CORRECTION = 0.85

# 状態管理用: ドラッグ操作中に固定する軸ID
_CSDT_DRAG_ACTIVE_ID = None
# 状態管理用: 現在ドラッグ操作を行っているオペレーターが存在するか
_CSDT_IS_DRAGGING = False

# GPU Shader Compatibility
_CSDT_GPU_SHADER_3D_UNIFORM = None
_CSDT_GPU_SHADER_2D_UNIFORM = None
_CSDT_GPU_SHADER_WARNED = False

# Modal Instance Tracking
_ACTIVE_MODAL_INSTANCES = set()

# Last Gizmo/Transform Constraint Tracking
_LAST_CONSTRAINT_AXIS_BY_KIND = {
    "TRANSLATE": (False, False, False),
    "ROTATE": (False, False, False),
    "RESIZE": (False, False, False),
    "TRANSFORM": (False, False, False),
}

# Explicit Smart Axis Memory state.  The legacy BoolVector above can represent
# X/Y/Z axes and planes, but it cannot distinguish "no remembered axis" from
# an intentionally selected free/unconstrained axis.  Keep this parallel state
# so Smart Gizmo free handles can be remembered without forcing an axis on the
# next Smart G-R-S operation.
_LAST_CONSTRAINT_STATE_BY_KIND = {
    "TRANSLATE": {"kind": "NONE", "idx": -1, "axis": (False, False, False)},
    "ROTATE": {"kind": "NONE", "idx": -1, "axis": (False, False, False)},
    "RESIZE": {"kind": "NONE", "idx": -1, "axis": (False, False, False)},
    "TRANSFORM": {"kind": "NONE", "idx": -1, "axis": (False, False, False)},
}

_TRANSFORM_OP_ID_TO_KIND = {
    "TRANSFORM_OT_translate": "TRANSLATE",
    "TRANSFORM_OT_rotate": "ROTATE",
    "TRANSFORM_OT_resize": "RESIZE",
    "TRANSFORM_OT_transform": "TRANSFORM",
}

# Smart Gizmo Overlay State Tracking
_SMART_GIZMO_DRAW_HANDLE = None
_SMART_GIZMO_DRAW_STAGE = "POST_PIXEL"
_SMART_GIZMO_HOVER_ID = None
_SMART_GIZMO_LOCKED_ID = None 

# Smart Gizmo modal freeze.  Smart G-R-S uses these while rotating so the
# overlay origin/axes do not chase a changing bounding box during the drag.
_SMART_GIZMO_FREEZE_ACTIVE = False
_SMART_GIZMO_FROZEN_PIVOT = None
_SMART_GIZMO_FROZEN_AXES = None
# Forced modal Smart Gizmo overlay.  Smart G-R-S can be invoked from a
# hotkey or from a Smart Gizmo handle while the active tool is not one of
# Blender's native transform tools.  In that state the normal tool-based
# Smart Gizmo draw path returns no geometry, so B-key Snap Base feedback would
# not visually move the gizmo.  These fields keep a dedicated modal overlay
# alive until the transform is confirmed/cancelled.
_SMART_GIZMO_MODAL_OVERRIDE_ACTIVE = False
_SMART_GIZMO_MODAL_OVERRIDE_KIND = None
# Live Smart G-R-S operation mode (G/R/S) associated with the modal overlay.
# The pivot remains frozen during rotation, while LOCAL display axes follow
# the actively transformed object in real time like Blender's native gizmo.
_SMART_GIZMO_MODAL_OVERRIDE_MODE = None
_SMART_GIZMO_MODAL_OVERRIDE_PIVOT = None
_SMART_GIZMO_MODAL_OVERRIDE_AXES = None
_SMART_GIZMO_MOUSE = (0, 0)
_SMART_GIZMO_MOUSE_WIN = (0, 0)
_SMART_GIZMO_MOUSE_VALID = False
_SMART_GIZMO_WATCHERS = {}
_SMART_GIZMO_WATCHER_HEARTBEAT = {}
_SMART_GIZMO_SHUTDOWN = False
# True while Blender viewport navigation input is active.  The Smart Gizmo
# watcher uses this to skip hover hit-tests during orbit/pan/zoom so native
# view interaction is not delayed by custom overlay calculations.
_SMART_GIZMO_VIEW_NAV_ACTIVE = False
_SMART_GIZMO_VIEW_NAV_UNTIL = 0.0
_SMART_GIZMO_LAST_HOVER_CHECK_AT = 0.0
_SMART_GIZMO_LAST_HOVER_MOUSE_WIN = (None, None)
_SMART_GIZMO_LAST_GOOD_GEO = None
_SMART_GIZMO_LAST_GOOD_TIME = 0.0
_SMART_GIZMO_GUARDIAN_ACTIVE = False

# Smart Gizmo draw handler health tracking.  Blender startup/window reloads can
# keep a stale draw-handler token alive without actually executing the callback;
# the guardian uses these timestamps to re-register only when needed.
_SMART_GIZMO_LAST_DRAW_AT = 0.0
_SMART_GIZMO_DRAW_HANDLE_REGISTERED_AT = 0.0
_SMART_GIZMO_DRAW_HANDLER_REPAIR_AT = 0.0

# Last Smart Gizmo orientation basis used by Smart G-R-S.
# Immediate-select -> held-drag transforms reuse this when the scene transform
# orientation has not changed, matching 3ds Max-style gizmo constraints.
_SMART_GIZMO_LAST_ORIENT_AXES = None
_SMART_GIZMO_LAST_ORIENT_SPACE = ""
_SMART_GIZMO_LAST_ORIENT_TIME = 0.0
_SMART_GIZMO_LAST_ORIENT_PIVOT = None
_SMART_GIZMO_LAST_ORIENT_VIEW_SIGNATURE = None

_SMART_GIZMO_CACHE = {
    "time": 0.0,
    "obj_ptr": 0,
    "mode": "",
    "sig": None,
    "pivot": None,
    "axes": None,
    "pivot_mode": "",
    "orient_mode": "",
}

# Tool Detection
_CSDT_LAST_TOOL_ID = None
_TRANSFORM_TOOL_IDS = {"builtin.move", "builtin.rotate", "builtin.scale", "builtin.transform"}