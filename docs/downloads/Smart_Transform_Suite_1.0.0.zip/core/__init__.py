# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 JELararagi
# Blender Extension / user_default compatible package

import bpy
import bmesh
from math import isfinite
from mathutils import Vector, Matrix, Quaternion, Euler

from .. import runtime as _runtime
from ..translation import TI
from .. import ui_icons as _ui_icons
from .. import operator_safety as _op_safety
from ..manager_runtime_bridge import panel_placement_allowed as _panel_placement_allowed
from . import item_popup as _item_popup

bl_info = {
    "name": "Smart Transform",
    "author": "Smart Transform Suite",
    "version": (1, 8, 147),
    "blender": (5, 1, 0),
    "location": "3D View Sidebar > Smart Transform / Shortcut > wm.core",
    "description": "Standard 3D View Sidebar N-panel page and popup for detailed transform editing.",
    "category": "Interface",
}





def _settings_restore_active() -> bool:
    try:
        from .. import settings as _settings
        return bool(_settings.is_restoring())
    except Exception:
        return False

def _request_scene_setting_save(reason: str = 'core_scene_setting_update') -> None:
    try:
        from .. import settings as _settings
        if _settings.is_restoring():
            return
        _settings.request_save(reason, context=getattr(bpy, 'context', None))
    except Exception:
        pass


def _ui_icon_kwargs(*, icon: str = 'NONE', operator_id: str = '', text: str = '', custom_icon: str = '', props=None):
    try:
        return _ui_icons.icon_kwargs(icon=icon, operator_id=operator_id, text=text, custom_icon=custom_icon, props=props or {})
    except Exception:
        return {'icon': icon or 'NONE'}


def _ui_label_kwargs(icon: str = 'NONE', custom_icon: str = ''):
    try:
        return _ui_icons.label_kwargs(icon, custom_icon)
    except Exception:
        return {'icon': icon or 'NONE'}


def _draw_icon_label(layout, text: str, *, icon: str = 'NONE', custom_icon: str = '') -> bool:
    try:
        layout.label(text=str(text or ''), **_ui_label_kwargs(icon, custom_icon))
        return True
    except TypeError:
        try:
            layout.label(text=str(text or ''), icon=icon or 'NONE')
            return True
        except Exception:
            return False
    except Exception:
        return False


def _operator_button_target(layout, *, icon_only: bool = False):
    if layout is None:
        return None
    if not icon_only:
        return layout
    try:
        row = layout.row(align=True)
        row.scale_x = 1.18
        row.scale_y = 1.28
        return row
    except Exception:
        return layout

ADDON_ID = _runtime.addon_root_module_name(__package__, __name__, module_file=__file__)

# Per-PropertyGroup runtime cache used by computed N-panel transform values.
# This must exist before Blender evaluates any get/set callbacks during panel
# drawing, file load, autosave restore, or preference synchronization.
_PANEL_RUNTIME_CACHE: dict[int, dict[str, object]] = {}

def _addon_preferences_candidates():
    return _runtime.addon_root_candidates(__package__, __name__, module_file=__file__)

def _resolve_suite_preferences(context=None):
    try:
        return _runtime.get_addon_preferences(context, __package__, __name__, __file__)
    except Exception:
        return None

def _suite_addon_prefs(context=None):
    """Safe access to the root suite preferences."""
    return _resolve_suite_preferences(context)

def _migrate_scale_link_axis_prefs(prefs):
    if prefs is None:
        return None
    try:
        already_migrated = bool(getattr(prefs, 'scale_link_axes_migrated', False))
    except Exception:
        already_migrated = True
    if already_migrated:
        return prefs
    try:
        legacy_enabled = bool(getattr(prefs, 'scale_link_xyz', False))
    except Exception:
        legacy_enabled = False
    try:
        prefs.scale_link_x = legacy_enabled
        prefs.scale_link_y = legacy_enabled
        prefs.scale_link_z = legacy_enabled
        prefs.scale_link_axes_migrated = True
    except Exception:
        pass
    return prefs


def _addon_prefs(context=None):
    """Safe access to suite preferences subgroup."""
    prefs = _suite_addon_prefs(context)
    if prefs is None:
        return None
    try:
        prefs = getattr(prefs, 'core_panel', None) or prefs
    except Exception:
        pass
    return _migrate_scale_link_axis_prefs(prefs)


def _safe_context(context=None):
    try:
        return context if context is not None else bpy.context
    except Exception:
        return None


def _context_attr(context, attr: str, default=None):
    try:
        return getattr(context, attr)
    except Exception:
        return default


def _context_scene(context=None):
    ctx = _safe_context(context)
    return _context_attr(ctx, 'scene', None) if ctx is not None else None


def _object_reference_is_alive(obj) -> bool:
    """Return False for stale RNA object references during mode/view redraws."""
    if obj is None:
        return False
    try:
        if int(obj.as_pointer()) == 0:
            return False
    except Exception:
        return False
    try:
        name = str(getattr(obj, 'name', '') or '')
    except Exception:
        return False
    if not name:
        return False
    try:
        return bpy.data.objects.get(name) is obj
    except Exception:
        return True


def _context_active_object(context=None):
    ctx = _safe_context(context)
    obj = _context_attr(ctx, 'active_object', None) if ctx is not None else None
    return obj if _object_reference_is_alive(obj) else None


def _safe_object_mode(obj) -> str:
    try:
        return str(getattr(obj, 'mode', '') or '')
    except Exception:
        return ''


def _safe_object_type(obj) -> str:
    try:
        return str(getattr(obj, 'type', '') or '')
    except Exception:
        return ''


def _object_selected_safe(obj) -> bool:
    try:
        return bool(obj.select_get())
    except Exception:
        return False


def _context_mode_safe(context=None) -> str:
    ctx = _safe_context(context)
    try:
        return str(getattr(ctx, 'mode', '') or '')
    except Exception:
        return ''


def _standard_npanel_context_safe(context=None) -> bool:
    ctx = _safe_context(context)
    if ctx is None:
        return False
    try:
        region = getattr(ctx, 'region', None)
        if region is not None and getattr(region, 'type', None) not in {'UI', 'WINDOW'}:
            return False
    except Exception:
        return False
    return True


def _view3d_sidebar_context_safe(context=None) -> bool:
    # Compatibility alias for older internal callers.  Smart Tools Manager is
    # responsible for deciding which workspace/editor may show this N-panel; the
    # Smart Transform source panel itself must be drawable in every N-panel
    # capable editor context.
    return _standard_npanel_context_safe(context)


def _panel_mode_matches_context(context, obj) -> bool:
    if not _object_reference_is_alive(obj):
        return False
    obj_mode = _safe_object_mode(obj)
    ctx_mode = _context_mode_safe(context)
    if obj_mode == 'OBJECT':
        return ctx_mode in {'', 'OBJECT'}
    if obj_mode == 'POSE':
        return ctx_mode in {'', 'POSE'} and _safe_object_type(obj) == 'ARMATURE'
    if obj_mode == 'EDIT':
        if _safe_object_type(obj) not in {'MESH', 'CURVE', 'LATTICE', 'ARMATURE'}:
            return False
        return (not ctx_mode) or ctx_mode.startswith('EDIT')
    return False


def _smart_transform_panel_context_ready(context, *, require_object: bool = True, require_object_selected: bool = False) -> bool:
    if not _standard_npanel_context_safe(context):
        return False
    obj = _context_active_object(context)
    if obj is None:
        return not require_object
    if not _panel_mode_matches_context(context, obj):
        return False
    if require_object_selected and not _object_selected_safe(obj):
        return False
    return True


def _orientation_slot_type(context=None, fallback: str = 'GLOBAL') -> str:
    scene = _context_scene(context)
    if scene is None:
        return fallback
    try:
        slots = getattr(scene, 'transform_orientation_slots', None)
        slot0 = slots[0] if slots else None
        value = getattr(slot0, 'type', fallback) if slot0 is not None else fallback
        return str(value or fallback)
    except Exception:
        return fallback


def _set_orientation_slot_type(context=None, orient: str = 'GLOBAL') -> bool:
    scene = _context_scene(context)
    if scene is None:
        return False
    try:
        slots = getattr(scene, 'transform_orientation_slots', None)
        if not slots:
            return False
        slots[0].type = str(orient or 'GLOBAL')
        return True
    except Exception:
        return False


def _scale_link_states(context=None):
    prefs = _addon_prefs(context)
    if prefs is None:
        return (False, False, False)
    try:
        return (
            bool(getattr(prefs, 'scale_link_x', False)),
            bool(getattr(prefs, 'scale_link_y', False)),
            bool(getattr(prefs, 'scale_link_z', False)),
        )
    except Exception:
        return (False, False, False)


def _linked_scale_axes_for_axis(context, axis: int):
    axis = int(axis)
    if axis < 0 or axis > 2:
        return (axis,)
    states = _scale_link_states(context)
    if not states[axis]:
        return (axis,)
    axes = tuple(i for i, enabled in enumerate(states) if enabled)
    return axes if axes else (axis,)


def _scale_target_vector_for_axis(context, props, orient_str, axis: int, value):
    try:
        target_value = float(value)
    except Exception:
        return None
    try:
        current_vec = _get_scale_vec_cached(context, props, orient_str)
        target_vec = Vector((float(current_vec[0]), float(current_vec[1]), float(current_vec[2])))
    except Exception:
        target_vec = Vector((1.0, 1.0, 1.0))
    for idx in _linked_scale_axes_for_axis(context, axis):
        if 0 <= idx < 3:
            target_vec[idx] = target_value
    return target_vec


def _pref(context, name: str, default):
    prefs = _addon_prefs(context)
    try:
        return getattr(prefs, name)
    except Exception:
        return default

def _enum_index(items, value, default=0):
    try:
        if isinstance(value, str):
            for i, item in enumerate(items):
                if item[0] == value:
                    return i
            return int(default)
        idx = int(value)
        if 0 <= idx < len(items):
            return idx
    except Exception:
        pass
    return int(default)

def _enum_key(items, value, default_key):
    try:
        if isinstance(value, str):
            for item in items:
                if item[0] == value:
                    return value
            return value
        idx = int(value)
        if 0 <= idx < len(items):
            return items[idx][0]
    except Exception:
        pass
    return default_key

# ==============================================================================
# 0. Translations / constants
# ==============================================================================

KNOWN_ORIENT_TYPES = {
    'GLOBAL', 'LOCAL', 'NORMAL', 'GIMBAL', 'VIEW', 'CURSOR', 'PARENT'
}

# NOTE: When the scene orientation is a custom orientation, Blender may store its
#       name directly in TransformOrientationSlot.type. We keep a "CUSTOM" entry
#       only for UI fallback; internally we pass the string as-is.
ORIENT_ITEMS = [
    ('GLOBAL', "Global", "Global"),
    ('LOCAL', "Local", "Local"),
    ('NORMAL', "Normal", "Normal"),
    ('GIMBAL', "Gimbal", "Gimbal"),
    ('VIEW', "View", "View"),
    ('CURSOR', "Cursor", "Cursor"),
    ('PARENT', "Parent", "Parent"),
    ('CUSTOM', "Custom", "Custom"),
]

OP_MODE_ITEMS = [
    ('MEDIAN', "Median", "Operate on the selection as a group (move/rotate/scale around the median)"),
    ('EACH', "Each", "Apply values to each selected item individually"),
]

INPUT_MODE_ITEMS = [
    ('ABS', "Abs", "Absolute value"),
    ('DELTA', "Δ", "Delta (relative) value"),
]

translation_dict = {
    "ja_JP": {
        ("*", "Smart Transform"): "スマートトランスフォーム",
        ("*", "Panel and popup to display and edit detailed transform info in the 3D View Sidebar."):
            "3Dビューのサイドバーで詳細なトランスフォーム情報を表示・編集するためのパネルとポップアップです。",

        # Orientation
        ("*", "Global"): "グローバル",
        ("*", "Local"): "ローカル",
        ("*", "Normal"): "ノーマル",
        ("*", "Gimbal"): "ジンバル",
        ("*", "View"): "ビュー",
        ("*", "Cursor"): "カーソル",
        ("*", "Parent"): "親",
        ("*", "Custom"): "カスタム",

        # Target / labels
        ("*", "Object"): "オブジェクト",
        ("*", "Pose Bone"): "ボーン",
        ("*", "Vertex"): "頂点",
        ("*", "Edge"): "辺",
        ("*", "Face"): "面",
        ("*", "Element"): "要素",
        ("*", "(Median)"): "(中点)",

        # Modes
        ("*", "Median"): "中点",
        ("*", "Each"): "個別",
        ("*", "Abs"): "絶対",
        ("*", "Δ"): "差分",

        # Props
        ("*", "Loc X"): "位置 X",
        ("*", "Rot X"): "回転 X",
        ("*", "Scale X"): "スケール X",
        ("*", "Dim X"): "寸法 X",
        ("*", "Y"): "Y",
        ("*", "Z"): "Z",

        ("*", "V. Bevel"): "頂点ベベル",
        ("*", "V. Crease"): "頂点クリース",
        ("*", "E. Bevel"): "辺ベベル",
        ("*", "E. Crease"): "辺クリース",

        ("*", "Vertex Bevel Weight"): "頂点ベベルウェイト",
        ("*", "Vertex Crease"): "頂点クリース",
        ("*", "Edge Bevel Weight"): "辺ベベルウェイト",
        ("*", "Edge Crease"): "辺クリース",

        # Actions
        ("*", "Copy"): "コピー",
        ("*", "Paste"): "ペースト",
        ("*", "Paste Location"): "位置を貼り付け",
        ("*", "Paste Rotation"): "回転を貼り付け",
        ("*", "Paste Scale"): "スケールを貼り付け",
        ("*", "Paste the location with the Paste button."): "「ペースト」で位置を貼り付けます。",
        ("*", "Paste the rotation with the Paste button."): "「ペースト」で回転を貼り付けます。",
        ("*", "Paste the scale with the Paste button."): "「ペースト」でスケールを貼り付けます。",
        ("*", "Apply R/S"): "回転/スケール適用",
        ("*", "Apply All"): "全適用",
        ("*", "Snap"): "スナップ",
        ("*", "To Cursor"): "カーソルへ",
        ("*", "Cursor To Sel"): "選択→カーソル",
        ("*", "To Active"): "アクティブへ",
        ("*", "To Floor (Z=0)"): "床へ(Z=0)",

        # Misc
        ("*", "No Object"): "オブジェクトなし",

        # Preferences
        ("*", "Use Scene Transform Orientation"): "シーンのトランスフォーム座標系を使用",
        ("*", "When enabled, the popup always uses the current scene's transform orientation."):
            "有効にすると、常に現在のシーンのトランスフォーム座標系と同期します。",
        ("*", "Keymap ID (Copy this)"): "キーマップ登録用ID (コピー可能)",
        ("*", "ID for keymap registration. Copy this text and use it in the Keymap settings."):
            "キーマップ登録用のIDです。この文字列をコピーして、キーマップ設定の『識別子』に使用してください。",

("*", "Delta Display"): "Δ表示",
("*", "How Δ input fields behave: show last entered value (knob) or auto-reset to neutral after applying."):
    "差分入力欄の挙動を切り替えます（ノブ式／自動ゼロ）。",
("*", "Knob"): "ノブ",
("*", "Show last entered value (nudge-style)"): "直前の入力値を表示（ノブ式）",
("*", "Auto-Zero"): "自動ゼロ",
("*", "Always show neutral value and apply input immediately"): "常にニュートラル値を表示し、入力を即適用",
("*", "Δ Scale Style"): "Δスケール方式",
("*", "How Δ scale values are interpreted."): "差分スケール値の解釈方式を切り替えます。",
("*", "Factor"): "係数",
("*", "Use multiplicative factor (1.1 = +10%)"): "倍率で指定（1.1=+10%）",
("*", "Add Value"): "加算",
("*", "Use additive value (0.1 = +10%, -0.1 = -10%)"): "加算で指定（0.1=+10%、-0.1=-10%）",
("*", "Pose Rotation (Each)"): "ポーズ回転（個別）",
("*", "How rotation behaves in Pose mode when Mode=Each."):
    "ポーズモードで「個別」のときの回転挙動を切り替えます。",
("*", "Channel Box"): "チャンネルボックス",
("*", "Edit bone rotation values (Maya-like, no translation)"): "ボーンの回転値を編集（Maya風、移動なし）",
("*", "Oriented Pivot"): "方向ピボット",
("*", "Rotate around bone head using the chosen orientation"): "選択した座標系でボーンヘッドを中心に回転",
("*", "Preferences"): "プリファレンス",
("*", "Edit all Smart Transform add-on settings here. Changes are stored in Add-on Preferences and are saved with Save Preferences."):
    "Smart Transform のアドオン設定はすべてここで編集できます。変更内容は アドオンのプリファレンス に保存され、「プリファレンスを保存」で保持されます。",
("*", "These controls are the stored add-on settings for Smart Transform."):
    "これらは Smart Transform の保存対象アドオン設定です。",
("*", "Smart Transform preferences are unavailable because the add-on preferences could not be found."):
    "アドオンのプリファレンスが見つからないため、Smart Transform の共有プリファレンスを表示できません。",
("*", "Show or hide the Smart Transform standard N-panel tools"):
    "Smart Transform の通常Nパネルツールを表示/非表示します。",
("*", "Open Smart Transform controls in the standard 3D View Sidebar N-panel."):
    "3Dビューの通常Nパネルで Smart Transform の操作欄を開きます。",
        # Operator tooltips
        ("*", "Reset Value"): "値をリセット",
        ("*", "Reset the value (scale=1.0, others=0.0)"):
            "値をリセット（スケール=1.0、その他=0.0）",
        ("*", "Copy transform of the active item"):
            "アクティブのトランスフォームをコピー",
        ("*", "Paste copied transform to selected items"):
            "コピーしたトランスフォームを選択に貼り付け",
        ("*", "Apply rotation and scale"):
            "回転とスケールを適用",
        ("*", "Apply location, rotation and scale"):
            "位置・回転・スケールを適用",
        ("*", "Snap selection"):
            "選択をスナップ",
        ("*", "Apply rotation and scale to the selected objects?"):
            "選択オブジェクトに回転とスケールを適用しますか？",
        ("*", "This cannot be undone safely once you continue working."):
            "この後の作業を進めると安全に戻せない場合があります。",
        ("*", "Apply location, rotation, and scale to the selected objects?"):
            "選択オブジェクトに位置・回転・スケールを適用しますか？",
        ("*", "This is destructive and can affect export or rig setups."):
            "破壊的な処理で、書き出しやリグ設定に影響する場合があります。",
    }
}

# ==============================================================================
# 1. Small utilities
# ==============================================================================

def _v3(x=0.0, y=0.0, z=0.0):
    return Vector((float(x), float(y), float(z)))

def _is_number(x):
    try:
        return isfinite(float(x))
    except Exception:
        return False

def get_matrix_inv(mat: Matrix) -> Matrix:
    try:
        return mat.inverted()
    except Exception:
        return Matrix.Identity(mat.col_size)

def safe_normalize_3x3(m3: Matrix) -> Matrix:
    m = m3.copy()
    try:
        m.normalize()
    except Exception:
        m = Matrix.Identity(3)
    return m

def _basis_from_scene_custom_orientation(context, orient_name: str) -> Matrix:
    """Best-effort custom orientation basis in world space (3x3)."""
    scene = _context_scene(context)
    if scene is None:
        return Matrix.Identity(3)

    # 1) Slot's custom_orientation (most reliable when the active slot is the same)
    try:
        slots = getattr(scene, 'transform_orientation_slots', None)
        slot = slots[0] if slots else None
        co = getattr(slot, "custom_orientation", None) if slot is not None else None
        if co is not None and getattr(slot, "type", "") == orient_name:
            mat = getattr(co, "matrix", None)
            if mat is not None:
                return safe_normalize_3x3(mat.to_3x3() if hasattr(mat, "to_3x3") else Matrix(mat))
    except Exception:
        pass

    # 2) Search scene orientations by name
    try:
        col = getattr(scene, "transform_orientations", None)
        if col is not None:
            for it in col:
                if getattr(it, "name", None) == orient_name:
                    mat = getattr(it, "matrix", None)
                    if mat is not None:
                        return safe_normalize_3x3(mat.to_3x3() if hasattr(mat, "to_3x3") else Matrix(mat))
    except Exception:
        pass

    return Matrix.Identity(3)

def get_space_transform(context, active_obj, space_type: str, is_edit_mode: bool = False):
    """Return (basis_matrix_3x3_in_world, origin_in_world)."""
    origin = _v3(0, 0, 0)

    # GLOBAL
    if space_type == 'GLOBAL':
        return Matrix.Identity(3), origin

    # LOCAL (active object)
    if space_type == 'LOCAL':
        if active_obj:
            return safe_normalize_3x3(active_obj.matrix_world.to_3x3()), active_obj.matrix_world.translation.copy()
        return Matrix.Identity(3), origin

    # PARENT
    if space_type == 'PARENT':
        if active_obj and active_obj.parent:
            p = active_obj.parent
            return safe_normalize_3x3(p.matrix_world.to_3x3()), p.matrix_world.translation.copy()
        return Matrix.Identity(3), origin

    # CURSOR
    if space_type == 'CURSOR':
        scene = _context_scene(context)
        cursor = getattr(scene, 'cursor', None) if scene is not None else None
        try:
            if cursor is None:
                return Matrix.Identity(3), origin
            return safe_normalize_3x3(cursor.matrix.to_3x3()), cursor.location.copy()
        except Exception:
            return Matrix.Identity(3), cursor.location.copy() if cursor is not None else origin

    # VIEW
    if space_type == 'VIEW':
        try:
            sd = getattr(context, 'space_data', None)
            r3d = getattr(sd, 'region_3d', None) if sd else None
            if r3d:
                # view_matrix is world->view; invert to get view->world
                return safe_normalize_3x3(r3d.view_matrix.inverted().to_3x3()), origin
        except Exception:
            pass
        return Matrix.Identity(3), origin

    # GIMBAL / NORMAL
    if space_type in {'GIMBAL', 'NORMAL'}:
        if active_obj:
            basis = safe_normalize_3x3(active_obj.matrix_world.to_3x3())
        else:
            basis = Matrix.Identity(3)

        if space_type == 'NORMAL' and is_edit_mode and active_obj and active_obj.type == 'MESH':
            try:
                bm = bmesh.from_edit_mesh(active_obj.data)
                sel = [v for v in bm.verts if v.select]
                if sel:
                    avg_n = _v3(0, 0, 0)
                    for v in sel:
                        avg_n += v.normal
                    if avg_n.length > 1e-6:
                        avg_n.normalize()
                        # convert normal to world
                        n_world = safe_normalize_3x3(active_obj.matrix_world.to_3x3()) @ avg_n
                        n_world.normalize()

                        up = _v3(0, 0, 1)
                        if abs(up.dot(n_world)) > 0.999:
                            up = _v3(0, 1, 0)
                        x_axis = up.cross(n_world).normalized()
                        y_axis = n_world.cross(x_axis).normalized()
                        basis = Matrix((x_axis, y_axis, n_world)).transposed()
            except Exception:
                pass

        return basis, origin

    # Custom (any other string)
    # If Blender stores a custom orientation name in slot.type, we pass it through.
    return _basis_from_scene_custom_orientation(context, space_type), origin

def world_to_space_pos(context, active_obj, space_type: str, world_pos: Vector, is_edit_mode: bool = False) -> Vector:
    if space_type == 'GLOBAL':
        return world_pos.copy()
    if space_type == 'LOCAL' and active_obj:
        return get_matrix_inv(active_obj.matrix_world) @ world_pos

    basis, origin = get_space_transform(context, active_obj, space_type, is_edit_mode=is_edit_mode)
    return get_matrix_inv(basis) @ (world_pos - origin)

def space_to_world_pos(context, active_obj, space_type: str, space_pos: Vector, is_edit_mode: bool = False) -> Vector:
    if space_type == 'GLOBAL':
        return space_pos.copy()
    if space_type == 'LOCAL' and active_obj:
        return active_obj.matrix_world @ space_pos

    basis, origin = get_space_transform(context, active_obj, space_type, is_edit_mode=is_edit_mode)
    return origin + (basis @ space_pos)

# ==============================================================================
# 2. Edit-mode selection collection (Mesh / Curve / Lattice)
# ==============================================================================

def get_edit_targets(context):
    """Objects currently in edit mode that we can handle.

    Blender may leave objects in ``context.objects_in_mode`` while the UI is
    already evaluating in Object Mode during file-load, autosave restore, or
    panel redraw.  Returning those stale objects lets bmesh.from_edit_mesh()
    raise "The mesh must be in editmode" from property getters.  Filter by
    the object's actual mode here so all callers get a safe target list.
    """
    ctx = _safe_context(context)
    if ctx is None:
        return []
    objs = []
    for attr_name in ('objects_in_mode_unique_data', 'objects_in_mode', 'objects_in_edit_mode'):
        try:
            seq = getattr(ctx, attr_name)
        except Exception:
            seq = None
        if seq:
            try:
                objs = list(seq)
            except Exception:
                objs = []
            if objs:
                break
    supported = {'MESH', 'CURVE', 'LATTICE'}
    result = []
    seen = set()
    for obj in objs:
        try:
            ident = int(obj.as_pointer())
        except Exception:
            ident = id(obj)
        if ident in seen:
            continue
        seen.add(ident)
        try:
            if getattr(obj, 'type', None) not in supported:
                continue
            if getattr(obj, 'mode', '') != 'EDIT':
                continue
            result.append(obj)
        except Exception:
            continue
    return result


def _mesh_edit_targets(context):
    return [o for o in get_edit_targets(context) if getattr(o, 'type', None) == 'MESH' and getattr(o, 'mode', '') == 'EDIT' and getattr(o, 'data', None) is not None]


def _from_edit_mesh_safe(obj):
    try:
        if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'mode', '') != 'EDIT':
            return None
        data = getattr(obj, 'data', None)
        if data is None:
            return None
        return bmesh.from_edit_mesh(data)
    except (ValueError, ReferenceError, RuntimeError):
        return None
    except Exception:
        return None

def _mesh_selected_points_world(obj, sel_mode_tuple):
    """Return list[Vector] in world. sel_mode_tuple from tool_settings.mesh_select_mode."""
    points = []
    bm = _from_edit_mesh_safe(obj)
    if bm is None:
        return points
    try:
        mw = obj.matrix_world.copy()
    except Exception:
        return points
    try:
        v_mode, e_mode, f_mode = bool(sel_mode_tuple[0]), bool(sel_mode_tuple[1]), bool(sel_mode_tuple[2])
    except Exception:
        v_mode, e_mode, f_mode = True, False, False

    # Priority: Face > Edge > Vertex (when multiple modes enabled)
    try:
        if f_mode:
            for f in bm.faces:
                if f.select:
                    try:
                        points.append(mw @ f.calc_center_median())
                    except Exception:
                        c = _v3(0, 0, 0)
                        try:
                            for v in f.verts:
                                c += v.co
                            if len(f.verts) > 0:
                                c /= len(f.verts)
                            points.append(mw @ c)
                        except Exception:
                            pass
            return points

        if e_mode:
            for e in bm.edges:
                if e.select:
                    try:
                        v0, v1 = e.verts
                        points.append(mw @ ((v0.co + v1.co) * 0.5))
                    except Exception:
                        pass
            return points

        for v in bm.verts:
            if v.select:
                try:
                    points.append(mw @ v.co)
                except Exception:
                    pass
    except Exception:
        return []

    return points

def _curve_selected_points_world(obj):
    points = []
    mw = obj.matrix_world
    try:
        for spl in obj.data.splines:
            if spl.type == 'BEZIER':
                for bp in spl.bezier_points:
                    # Use control point selection
                    if getattr(bp, 'select_control_point', False):
                        points.append(mw @ bp.co)
            else:
                for p in spl.points:
                    if getattr(p, 'select', False):
                        # p.co is Vector((x,y,z,w))
                        co = Vector((p.co[0], p.co[1], p.co[2]))
                        points.append(mw @ co)
    except Exception:
        pass
    return points

def _lattice_selected_points_world(obj):
    points = []
    mw = obj.matrix_world
    try:
        for p in obj.data.points:
            if getattr(p, 'select', False):
                points.append(mw @ p.co)
    except Exception:
        pass
    return points

def _edit_selected_points_world_for_obj(context, obj):
    if not _object_reference_is_alive(obj):
        return []
    obj_type = _safe_object_type(obj)
    if obj_type == 'MESH':
        try:
            sel_mode = getattr(getattr(_safe_context(context), 'tool_settings', None), 'mesh_select_mode', (True, False, False))
        except Exception:
            sel_mode = (True, False, False)
        return _mesh_selected_points_world(obj, sel_mode)
    if obj_type == 'CURVE':
        return _curve_selected_points_world(obj)
    if obj_type == 'LATTICE':
        return _lattice_selected_points_world(obj)
    return []

def _median_of_points(points):
    if not points:
        return _v3(0, 0, 0)
    s = _v3(0, 0, 0)
    for p in points:
        s += p
    return s / len(points)



def _mesh_selected_verts_for_transform(context, bm):
    """Return selected mesh vertices to transform, including edge/face mode endpoints."""
    verts = []
    seen = set()

    def add_vert(v):
        try:
            key = int(v.index)
        except Exception:
            key = id(v)
        if key in seen:
            return
        seen.add(key)
        verts.append(v)

    try:
        sel_mode = getattr(getattr(_safe_context(context), 'tool_settings', None), 'mesh_select_mode', (True, False, False))
        v_mode, e_mode, f_mode = bool(sel_mode[0]), bool(sel_mode[1]), bool(sel_mode[2])
    except Exception:
        v_mode, e_mode, f_mode = True, False, False

    try:
        if f_mode:
            for f in bm.faces:
                if f.select:
                    for v in f.verts:
                        add_vert(v)
        if e_mode:
            for e in bm.edges:
                if e.select:
                    for v in e.verts:
                        add_vert(v)
        # Always include explicitly selected vertices. This also covers vertex
        # mode and mixed select mode without relying on Blender's select flush.
        for v in bm.verts:
            if v.select:
                add_vert(v)
    except Exception:
        pass
    return verts


def _apply_world_point_transform_to_edit_selection(context, obj, transform_point_world) -> bool:
    """Apply a world-space point transform function to selected edit elements."""
    if obj is None or getattr(obj, 'mode', '') != 'EDIT':
        return False
    try:
        mw = obj.matrix_world.copy()
        imw = get_matrix_inv(mw)
    except Exception:
        return False

    changed = False
    obj_type = getattr(obj, 'type', '')

    if obj_type == 'MESH':
        bm = _from_edit_mesh_safe(obj)
        if bm is None:
            return False
        try:
            for v in _mesh_selected_verts_for_transform(context, bm):
                world = mw @ v.co
                v.co = imw @ transform_point_world(world)
                changed = True
            if changed:
                bmesh.update_edit_mesh(obj.data)
        except Exception:
            return False
        return changed

    if obj_type == 'CURVE':
        try:
            for spl in obj.data.splines:
                if spl.type == 'BEZIER':
                    for bp in spl.bezier_points:
                        cp_sel = bool(getattr(bp, 'select_control_point', False))
                        lh_sel = bool(getattr(bp, 'select_left_handle', False))
                        rh_sel = bool(getattr(bp, 'select_right_handle', False))
                        if cp_sel:
                            for attr in ('co', 'handle_left', 'handle_right'):
                                val = getattr(bp, attr)
                                setattr(bp, attr, imw @ transform_point_world(mw @ val))
                            changed = True
                        else:
                            if lh_sel:
                                bp.handle_left = imw @ transform_point_world(mw @ bp.handle_left)
                                changed = True
                            if rh_sel:
                                bp.handle_right = imw @ transform_point_world(mw @ bp.handle_right)
                                changed = True
                else:
                    for pnt in spl.points:
                        if getattr(pnt, 'select', False):
                            co = Vector((float(pnt.co[0]), float(pnt.co[1]), float(pnt.co[2])))
                            new_local = imw @ transform_point_world(mw @ co)
                            pnt.co[0] = float(new_local.x)
                            pnt.co[1] = float(new_local.y)
                            pnt.co[2] = float(new_local.z)
                            changed = True
            if changed:
                obj.data.update()
        except Exception:
            return False
        return changed

    if obj_type == 'LATTICE':
        try:
            for pnt in obj.data.points:
                if getattr(pnt, 'select', False):
                    pnt.co = imw @ transform_point_world(mw @ pnt.co)
                    changed = True
            if changed:
                obj.data.update()
        except Exception:
            return False
        return changed

    return False


def _apply_world_delta_to_edit_selection(context, obj, diff_world: Vector):
    """Move selected elements in edit data by diff_world."""
    if diff_world.length == 0:
        return
    _apply_world_point_transform_to_edit_selection(context, obj, lambda world: world + diff_world)


def _selected_edit_points_world(context, targets=None):
    points = []
    try:
        seq = list(targets) if targets is not None else get_edit_targets(context)
    except Exception:
        seq = []
    for obj in seq:
        points.extend(_edit_selected_points_world_for_obj(context, obj))
    return points


def _edit_selection_median_world(context, targets=None) -> Vector:
    return _median_of_points(_selected_edit_points_world(context, targets))


def _edit_selection_dimensions_in_space(context, active_obj, orient_str, targets=None) -> Vector:
    pts = _selected_edit_points_world(context, targets)
    if not pts:
        return _v3(0, 0, 0)
    coords = []
    for pnt in pts:
        try:
            coords.append(world_to_space_pos(context, active_obj, orient_str, pnt, is_edit_mode=True))
        except Exception:
            pass
    if not coords:
        return _v3(0, 0, 0)
    mins = [min(float(c[i]) for c in coords) for i in range(3)]
    maxs = [max(float(c[i]) for c in coords) for i in range(3)]
    return Vector((maxs[0] - mins[0], maxs[1] - mins[1], maxs[2] - mins[2]))


def _apply_delta_rotation_edit_selection(context, props, orient_str, axis: int, delta_angle: float) -> None:
    obj = _context_active_object(context)
    if obj is None or getattr(obj, 'mode', '') != 'EDIT':
        return
    targets = get_edit_targets(context)
    if not targets:
        return
    basis = _basis_world_for_orient(context, obj, orient_str, is_edit_mode=True)
    try:
        axis_world = Vector((basis[0][axis], basis[1][axis], basis[2][axis]))
    except Exception:
        return
    if axis_world.length < 1e-8:
        return
    axis_world.normalize()
    try:
        angle = float(delta_angle)
    except Exception:
        return
    if abs(angle) < 1e-12:
        return
    rot = Matrix.Rotation(angle, 3, axis_world)

    if getattr(props, 'op_mode', 'MEDIAN') == 'EACH':
        for edit_obj in targets:
            pts = _edit_selected_points_world_for_obj(context, edit_obj)
            if not pts:
                continue
            pivot = _median_of_points(pts)
            _apply_world_point_transform_to_edit_selection(context, edit_obj, lambda world, p=pivot: p + (rot @ (world - p)))
        return

    pivot = _edit_selection_median_world(context, targets)
    for edit_obj in targets:
        _apply_world_point_transform_to_edit_selection(context, edit_obj, lambda world, p=pivot: p + (rot @ (world - p)))


def _apply_delta_scale_edit_selection(context, props, orient_str, factors) -> None:
    obj = _context_active_object(context)
    if obj is None or getattr(obj, 'mode', '') != 'EDIT':
        return
    targets = get_edit_targets(context)
    if not targets:
        return
    try:
        fx, fy, fz = float(factors[0]), float(factors[1]), float(factors[2])
    except Exception:
        return
    if abs(fx - 1.0) < 1e-12 and abs(fy - 1.0) < 1e-12 and abs(fz - 1.0) < 1e-12:
        return
    basis = _basis_world_for_orient(context, obj, orient_str, is_edit_mode=True)
    try:
        scale_space = Matrix.Diagonal((fx, fy, fz))
        scale_world = basis @ scale_space @ get_matrix_inv(basis)
    except Exception:
        return

    if getattr(props, 'op_mode', 'MEDIAN') == 'EACH':
        for edit_obj in targets:
            pts = _edit_selected_points_world_for_obj(context, edit_obj)
            if not pts:
                continue
            pivot = _median_of_points(pts)
            _apply_world_point_transform_to_edit_selection(context, edit_obj, lambda world, p=pivot: p + (scale_world @ (world - p)))
        return

    pivot = _edit_selection_median_world(context, targets)
    for edit_obj in targets:
        _apply_world_point_transform_to_edit_selection(context, edit_obj, lambda world, p=pivot: p + (scale_world @ (world - p)))

# ==============================================================================
# 3. Object/Pose selection utilities
# ==============================================================================

def _selected_objects_in_object_mode(context):
    ctx = _safe_context(context)
    if ctx is None:
        return []
    try:
        seq = list(getattr(ctx, 'selected_objects', []) or [])
    except Exception:
        return []
    result = []
    for o in seq:
        try:
            if _object_reference_is_alive(o) and _safe_object_mode(o) == 'OBJECT':
                result.append(o)
        except Exception:
            continue
    return result

def _single_selected_object_in_object_mode(context):
    objs = _selected_objects_in_object_mode(context)
    return objs[0] if len(objs) == 1 else None


def _object_mode_transform_targets(context):
    """Targets used by Smart Transform numeric spinners in Object Mode.

    Blender's native Transform panel can still expose an active object when it is
    not in context.selected_objects.  The Smart Transform numeric fields must not
    appear locked in that state, so use the current selection when present and
    fall back to the live active object for direct numeric edits.
    """
    objs = _selected_objects_in_object_mode(context)
    if objs:
        return objs
    obj = _context_active_object(context)
    if obj is not None and _safe_object_mode(obj) == 'OBJECT':
        return [obj]
    return []


def _median_object_mode_transform_targets_world(context):
    objs = _object_mode_transform_targets(context)
    if not objs:
        return _v3(0, 0, 0)
    s = _v3(0, 0, 0)
    for o in objs:
        try:
            s += o.matrix_world.translation
        except Exception:
            pass
    return s / len(objs)


def _median_selected_objects_world(context):
    objs = _selected_objects_in_object_mode(context)
    if not objs:
        return _v3(0, 0, 0)
    s = _v3(0, 0, 0)
    for o in objs:
        s += o.matrix_world.translation
    return s / len(objs)

def _selected_pose_bones(context):
    obj = _context_active_object(context)
    if not obj or obj.type != 'ARMATURE':
        return []
    try:
        bones = list(context.selected_pose_bones_from_active_object or [])
        return bones
    except Exception:
        return []

def _median_pose_bones_world(context):
    obj = _context_active_object(context)
    bones = _selected_pose_bones(context)
    if not obj or not bones:
        return _v3(0, 0, 0)
    s = _v3(0, 0, 0)
    for pb in bones:
        # pb.head is in armature space
        s += obj.matrix_world @ pb.head
    return s / len(bones)

# ==============================================================================
# 4. Main transform get/set (Location / Rotation / Scale)
# ==============================================================================

def get_active_orient_str(props):
    try:
        ctx = _safe_context()
        scene = _context_scene(ctx)
        prefs = _addon_prefs(ctx)
        use_scene = bool(getattr(prefs, 'use_scene_orientation', True)) if prefs is not None else True

        if use_scene:
            if scene is None:
                return 'GLOBAL'
            return _orientation_slot_type(ctx, 'GLOBAL')

        value = props.get("internal_orient", 0)
        if isinstance(value, str):
            return value if value else 'GLOBAL'
        idx = _enum_index(ORIENT_ITEMS, value, 0)
        return ORIENT_ITEMS[idx][0]
    except Exception:
        return 'GLOBAL'

def _invalidate_delta_state(props):
    # Reset delta accumulators
    for k in (
        "_delta_rot_last_x", "_delta_rot_last_y", "_delta_rot_last_z",
        "_delta_scale_last_x", "_delta_scale_last_y", "_delta_scale_last_z",
        "_edit_abs_rot_last_x", "_edit_abs_rot_last_y", "_edit_abs_rot_last_z",
        "_edit_abs_scale_last_x", "_edit_abs_scale_last_y", "_edit_abs_scale_last_z",
    ):
        if k in props:
            del props[k]
    _bump_panel_runtime_cache(props)


def _bump_panel_runtime_cache(props):
    try:
        cache = _panel_runtime_cache(props)
    except Exception:
        return
    try:
        cache['nonce'] = int(cache.get('nonce', 0) or 0) + 1
    except Exception:
        cache['nonce'] = 1
    for key in ('loc_key', 'loc_val', 'rot_key', 'rot_val', 'scale_key', 'scale_val'):
        try:
            cache.pop(key, None)
        except Exception:
            pass

def _get_op_mode(self):
    return _enum_index(OP_MODE_ITEMS, self.get("op_mode", 'MEDIAN'), 0)

def _set_op_mode(self, value):
    self["op_mode"] = _enum_key(OP_MODE_ITEMS, value, 'MEDIAN')
    _invalidate_delta_state(self)
    _request_scene_setting_save('core_props.op_mode')

def _get_input_mode(self):
    return _enum_index(INPUT_MODE_ITEMS, self.get("input_mode", 'ABS'), 0)

def _set_input_mode(self, value):
    self["input_mode"] = _enum_key(INPUT_MODE_ITEMS, value, 'ABS')
    _invalidate_delta_state(self)
    _request_scene_setting_save('core_props.input_mode')

def _get_orient(self):
    try:
        ctx = _safe_context()
        scene = _context_scene(ctx)
        prefs = _addon_prefs(ctx)
        use_scene = bool(getattr(prefs, 'use_scene_orientation', True)) if prefs is not None else True

        if use_scene:
            if scene is None:
                return _enum_index(ORIENT_ITEMS, 'GLOBAL', 0)
            slot = _orientation_slot_type(ctx, 'GLOBAL')
            for i, item in enumerate(ORIENT_ITEMS):
                if item[0] == slot:
                    return i
            # Getter must not mutate ID properties during panel redraw; Blender
            # 5.1 can evaluate enum getters inside native panel event handling.
            # Report CUSTOM without writing custom_orient_name here.
            return _enum_index(ORIENT_ITEMS, 'CUSTOM', 0)

        value = self.get("internal_orient", 0)
        if isinstance(value, str) and value not in {item[0] for item in ORIENT_ITEMS}:
            return _enum_index(ORIENT_ITEMS, 'CUSTOM', 0)
        return _enum_index(ORIENT_ITEMS, value, 0)
    except Exception:
        return _enum_index(ORIENT_ITEMS, 'GLOBAL', 0)

def _set_orient(self, value):
    ctx = _safe_context()
    scene = _context_scene(ctx)
    prefs = _addon_prefs(ctx)
    use_scene = bool(getattr(prefs, 'use_scene_orientation', True)) if prefs is not None else True

    value = _enum_index(ORIENT_ITEMS, value, 0)
    slot_str = ORIENT_ITEMS[value][0]

    if use_scene and scene is not None:
        if slot_str == 'CUSTOM':
            slot_str = self.get("custom_orient_name", 'GLOBAL')
        _set_orientation_slot_type(ctx, slot_str)

    try:
        self["internal_orient"] = value
    except Exception:
        pass
    _request_scene_setting_save('core_props.popup_orient')

def _panel_runtime_cache(props):
    # Defensive lookup: Blender can evaluate get/set callbacks while an add-on
    # module is being reloaded or partially unregistered.  Recreate the cache
    # store from globals() if the name is missing instead of letting a UI getter
    # raise NameError repeatedly during startup, autosave restore, or file load.
    global _PANEL_RUNTIME_CACHE
    cache_store = globals().get('_PANEL_RUNTIME_CACHE')
    if not isinstance(cache_store, dict):
        cache_store = {}
        globals()['_PANEL_RUNTIME_CACHE'] = cache_store
        _PANEL_RUNTIME_CACHE = cache_store
    try:
        pid = int(props.as_pointer())
    except Exception:
        pid = id(props)
    cache = cache_store.get(pid)
    if not isinstance(cache, dict):
        cache = {'nonce': 0}
        cache_store[pid] = cache
    return cache

def _cache_key_base(context, props, orient_str):
    cache = _panel_runtime_cache(props)
    try:
        nonce = int(cache.get('nonce', 0))
    except Exception:
        nonce = 0
    obj = _context_active_object(context)
    mode = getattr(obj, 'mode', '') if obj is not None else ""
    op_mode = getattr(props, 'op_mode', 'OBJECT')
    return (nonce, mode, orient_str, op_mode)

def _get_loc_vec_cached(context, props, orient_str):
    cache = _panel_runtime_cache(props)
    key = _cache_key_base(context, props, orient_str) + ("LOC",)
    if cache.get('loc_key') == key:
        try:
            return Vector(cache.get('loc_val', (0.0, 0.0, 0.0)))
        except Exception:
            pass
    v = _calc_loc_vec(context, props, orient_str)
    cache['loc_key'] = key
    cache['loc_val'] = (float(v.x), float(v.y), float(v.z))
    return v

def _calc_loc_vec(context, props, orient_str):
    obj = _context_active_object(context)
    if not obj:
        return _v3(0, 0, 0)

    active_obj = obj
    op_mode = props.op_mode

    # EDIT MODE (mesh/curve/lattice)
    if obj.mode == 'EDIT':
        targets = get_edit_targets(context)
        if not targets:
            return _v3(0, 0, 0)

        if op_mode == 'MEDIAN':
            all_pts = []
            for o in targets:
                all_pts.extend(_edit_selected_points_world_for_obj(context, o))
            median_world = _median_of_points(all_pts)
        else:
            # EACH: use active object's selection median
            pts = _edit_selected_points_world_for_obj(context, active_obj)
            median_world = _median_of_points(pts)

        return world_to_space_pos(context, active_obj, orient_str, median_world, is_edit_mode=True)

    # POSE MODE (bones)
    if obj.mode == 'POSE' and obj.type == 'ARMATURE':
        bones = _selected_pose_bones(context)
        if not bones:
            return _v3(0, 0, 0)
        if op_mode == 'MEDIAN':
            median_world = _median_pose_bones_world(context)
        else:
            # EACH: active bone head
            ab = context.active_pose_bone
            if ab:
                median_world = obj.matrix_world @ ab.head
            else:
                median_world = _median_pose_bones_world(context)
        return world_to_space_pos(context, active_obj, orient_str, median_world, is_edit_mode=False)

    # OBJECT MODE
    objs = _object_mode_transform_targets(context)
    if not objs:
        return _v3(0, 0, 0)

    if _object_uses_local_channels_for_orient(active_obj, orient_str):
        try:
            return Vector((float(active_obj.location.x), float(active_obj.location.y), float(active_obj.location.z)))
        except Exception:
            return _v3(0, 0, 0)

    if op_mode == 'MEDIAN':
        median_world = _median_object_mode_transform_targets_world(context)
        return world_to_space_pos(context, active_obj, orient_str, median_world, is_edit_mode=False)

    # EACH: show active object's location in space
    return world_to_space_pos(context, active_obj, orient_str, active_obj.matrix_world.translation, is_edit_mode=False)

def _set_loc_axis(context, props, orient_str, axis, target_value):
    obj = _context_active_object(context)
    if not obj:
        return

    active_obj = obj
    op_mode = props.op_mode

    # Guard NaN/Inf
    if not _is_number(target_value):
        return

    try:
        # Get current space position
        cur_space = _get_loc_vec_cached(context, props, orient_str)
        target_space = cur_space.copy()
        target_space[axis] = float(target_value)

        # EDIT MODE
        if obj.mode == 'EDIT':
            targets = get_edit_targets(context)
            if not targets:
                return

            if op_mode == 'MEDIAN':
                all_pts = []
                for o in targets:
                    all_pts.extend(_edit_selected_points_world_for_obj(context, o))
                median_world = _median_of_points(all_pts)
                target_world = space_to_world_pos(context, active_obj, orient_str, target_space, is_edit_mode=True)
                diff_world = target_world - median_world
                for o in targets:
                    _apply_world_delta_to_edit_selection(context, o, diff_world)
            else:
                # EACH
                for o in targets:
                    pts = _edit_selected_points_world_for_obj(context, o)
                    if not pts:
                        continue
                    median_world = _median_of_points(pts)
                    cur_space_o = world_to_space_pos(context, active_obj, orient_str, median_world, is_edit_mode=True)
                    target_space_o = cur_space_o.copy()
                    target_space_o[axis] = float(target_value)
                    target_world = space_to_world_pos(context, active_obj, orient_str, target_space_o, is_edit_mode=True)
                    diff_world = target_world - median_world
                    _apply_world_delta_to_edit_selection(context, o, diff_world)
            return

        # POSE MODE (move bones by shifting pose bone location in armature space)
        if obj.mode == 'POSE' and obj.type == 'ARMATURE':
            bones = _selected_pose_bones(context)
            if not bones:
                return

            if op_mode == 'MEDIAN':
                median_world = _median_pose_bones_world(context)
                target_world = space_to_world_pos(context, active_obj, orient_str, target_space, is_edit_mode=False)
                diff_world = target_world - median_world

                # convert world delta to armature space
                diff_arm = get_matrix_inv(obj.matrix_world.to_3x3()) @ diff_world
                for pb in bones:
                    pb.location += diff_arm
            else:
                # EACH: set each bone head position in space by shifting location
                for pb in bones:
                    head_world = obj.matrix_world @ pb.head
                    cur_space_b = world_to_space_pos(context, active_obj, orient_str, head_world, is_edit_mode=False)
                    tgt_space_b = cur_space_b.copy()
                    tgt_space_b[axis] = float(target_value)
                    tgt_world = space_to_world_pos(context, active_obj, orient_str, tgt_space_b, is_edit_mode=False)
                    diff_world = tgt_world - head_world
                    diff_arm = get_matrix_inv(obj.matrix_world.to_3x3()) @ diff_world
                    pb.location += diff_arm
            return

        # OBJECT MODE
        objs = _object_mode_transform_targets(context)
        if not objs:
            return

        if _numeric_try_affect_only_location_axis(context, props, orient_str, axis, target_value):
            return

        if _object_uses_local_channels_for_orient(active_obj, orient_str):
            for o in objs:
                try:
                    loc = Vector((float(o.location.x), float(o.location.y), float(o.location.z)))
                    loc[axis] = float(target_value)
                    o.location = loc
                except Exception:
                    pass
            return

        if op_mode == 'MEDIAN':
            median_world = _median_object_mode_transform_targets_world(context)
            target_world = space_to_world_pos(context, active_obj, orient_str, target_space, is_edit_mode=False)
            diff_world = target_world - median_world
            for o in objs:
                o.matrix_world.translation += diff_world
        else:
            # EACH
            for o in objs:
                ref_obj = _space_reference_object(active_obj, o, orient_str)
                cur_space_o = world_to_space_pos(context, ref_obj, orient_str, o.matrix_world.translation, is_edit_mode=False)
                tgt_space_o = cur_space_o.copy()
                tgt_space_o[axis] = float(target_value)
                tgt_world = space_to_world_pos(context, ref_obj, orient_str, tgt_space_o, is_edit_mode=False)
                o.matrix_world.translation = tgt_world
    finally:
        _bump_panel_runtime_cache(props)

# --- Rotation/Scale helpers (object mode) ---

def _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False) -> Matrix:
    basis, _origin = get_space_transform(context, active_obj, orient_str, is_edit_mode=is_edit_mode)
    return safe_normalize_3x3(basis)

def _basis_world_for_orient_pose(context, arm_obj, orient_str) -> Matrix:
    """Return a basis matrix in world space for Pose mode.

    For LOCAL/NORMAL/GIMBAL we prefer the active pose bone's orientation (Maya-like).
    """
    try:
        pb = getattr(context, "active_pose_bone", None)
        if pb and orient_str in {'LOCAL', 'NORMAL', 'GIMBAL'}:
            return safe_normalize_3x3(arm_obj.matrix_world.to_3x3() @ pb.matrix.to_3x3())
        if pb and pb.parent and orient_str == 'PARENT':
            return safe_normalize_3x3(arm_obj.matrix_world.to_3x3() @ pb.parent.matrix.to_3x3())
    except Exception:
        pass
    return _basis_world_for_orient(context, arm_obj, orient_str, is_edit_mode=False)

def _basis_world_for_object_orient(context, active_obj, obj, orient_str) -> Matrix:
    """Return the correct world-space basis for each selected object.

    LOCAL / GIMBAL / NORMAL should follow each object's own local basis when
    applying absolute values in Mode=Each, while GLOBAL / VIEW / CURSOR /
    custom orientations remain shared.
    """
    orient_key = str(orient_str or 'GLOBAL')
    target_obj = obj if obj is not None else active_obj

    if target_obj is None:
        return _basis_world_for_orient(context, active_obj, orient_key, is_edit_mode=False)

    if orient_key in {'LOCAL', 'GIMBAL', 'NORMAL'}:
        try:
            return safe_normalize_3x3(target_obj.matrix_world.to_3x3())
        except Exception:
            return Matrix.Identity(3)

    if orient_key == 'PARENT':
        try:
            parent = getattr(target_obj, 'parent', None)
            if parent is not None:
                return safe_normalize_3x3(parent.matrix_world.to_3x3())
        except Exception:
            pass
        return Matrix.Identity(3)

    return _basis_world_for_orient(context, active_obj, orient_key, is_edit_mode=False)


def _object_uses_local_channels_for_orient(obj, orient_str) -> bool:
    orient_key = str(orient_str or 'GLOBAL')
    if orient_key in {'LOCAL', 'GIMBAL', 'NORMAL'}:
        return True
    if orient_key == 'PARENT' and getattr(obj, 'parent', None) is not None:
        return True
    return False


def _object_local_rotation_quat(obj) -> Quaternion:
    try:
        mode = str(getattr(obj, 'rotation_mode', '') or 'XYZ')
        if mode == 'QUATERNION':
            q = getattr(obj, 'rotation_quaternion', None)
            if q is not None:
                return q.copy()
        elif mode == 'AXIS_ANGLE':
            aa = getattr(obj, 'rotation_axis_angle', None)
            if aa is not None and len(aa) >= 4:
                axis = Vector((float(aa[1]), float(aa[2]), float(aa[3])))
                if axis.length < 1e-8:
                    axis = Vector((0.0, 0.0, 1.0))
                else:
                    axis.normalize()
                return Quaternion(axis, float(aa[0]))
        else:
            e = getattr(obj, 'rotation_euler', None)
            if e is not None:
                return e.to_quaternion()
    except Exception:
        pass
    return Quaternion((1.0, 0.0, 0.0, 0.0))


def _object_local_rotation_xyz(obj) -> Vector:
    try:
        e = _object_local_rotation_quat(obj).to_euler('XYZ')
        return Vector((float(e.x), float(e.y), float(e.z)))
    except Exception:
        return _v3(0, 0, 0)


def _set_object_local_rotation_xyz(obj, euler_xyz: Vector) -> None:
    try:
        q = Euler((float(euler_xyz.x), float(euler_xyz.y), float(euler_xyz.z)), 'XYZ').to_quaternion()
        mode = str(getattr(obj, 'rotation_mode', '') or 'XYZ')
        if mode == 'QUATERNION':
            obj.rotation_quaternion = q
            return
        if mode == 'AXIS_ANGLE':
            axis, ang = q.to_axis_angle()
            obj.rotation_axis_angle[0] = float(ang)
            obj.rotation_axis_angle[1] = float(axis.x)
            obj.rotation_axis_angle[2] = float(axis.y)
            obj.rotation_axis_angle[3] = float(axis.z)
            return
        obj.rotation_euler = q.to_euler(mode)
    except Exception:
        pass


def _decompose_in_basis(obj, basis_world: Matrix):
    """Return (rot_space_quat, scale_space_vec) for obj.matrix_world expressed in basis coords."""
    mw3 = obj.matrix_world.to_3x3()
    try:
        m_space = (get_matrix_inv(basis_world) @ mw3)
        m4 = m_space.to_4x4()
        _loc, rot, scale = m4.decompose()
        return rot, Vector((scale.x, scale.y, scale.z))
    except Exception:
        # fallback: assume identity
        return Matrix.Identity(3).to_quaternion(), _v3(1, 1, 1)


def _local_rot_scale_for_object(obj):
    try:
        _loc, rot, scale = obj.matrix_basis.copy().decompose()
        return rot, Vector((float(scale.x), float(scale.y), float(scale.z)))
    except Exception:
        try:
            rot = obj.rotation_quaternion.copy() if getattr(obj, 'rotation_mode', '') == 'QUATERNION' else obj.rotation_euler.to_quaternion()
        except Exception:
            rot = Matrix.Identity(3).to_quaternion()
        try:
            scale = Vector((float(obj.scale.x), float(obj.scale.y), float(obj.scale.z)))
        except Exception:
            scale = _v3(1, 1, 1)
        return rot, scale


def _set_object_local_rot_scale(obj, rot_q, scale_vec=None):
    try:
        loc, _old_rot, old_scale = obj.matrix_basis.copy().decompose()
        sc = Vector(scale_vec) if scale_vec is not None else Vector((float(old_scale.x), float(old_scale.y), float(old_scale.z)))
        obj.matrix_basis = Matrix.LocRotScale(loc, rot_q, sc)
        return True
    except Exception:
        pass

    try:
        rotation_mode = str(getattr(obj, 'rotation_mode', 'XYZ') or 'XYZ')
        if rotation_mode == 'QUATERNION':
            obj.rotation_quaternion = rot_q
        elif rotation_mode == 'AXIS_ANGLE':
            axis2, ang2 = rot_q.to_axis_angle()
            obj.rotation_axis_angle[0] = float(ang2)
            obj.rotation_axis_angle[1] = float(axis2.x)
            obj.rotation_axis_angle[2] = float(axis2.y)
            obj.rotation_axis_angle[3] = float(axis2.z)
        else:
            obj.rotation_euler = rot_q.to_euler(rotation_mode)
        if scale_vec is not None:
            obj.scale = Vector(scale_vec)
        return True
    except Exception:
        return False


def _is_local_like_rotation_space(orient_str, obj) -> bool:
    orient_key = str(orient_str or 'GLOBAL')
    if orient_key in {'LOCAL', 'GIMBAL', 'NORMAL'}:
        return True
    if orient_key == 'PARENT' and getattr(obj, 'parent', None) is not None:
        return True
    return False


def _rotation_vec_in_space(context, obj, orient_str):
    if obj is None:
        return _v3(0, 0, 0)

    if _is_local_like_rotation_space(orient_str, obj):
        rot_q, _scale_local = _local_rot_scale_for_object(obj)
        try:
            e = rot_q.to_euler('XYZ')
            return Vector((float(e.x), float(e.y), float(e.z)))
        except Exception:
            return _v3(0, 0, 0)

    basis = _basis_world_for_orient(context, obj, orient_str, is_edit_mode=False)
    rot_space, _scale_space = _decompose_in_basis(obj, basis)
    try:
        e = rot_space.to_euler('XYZ')
        return Vector((float(e.x), float(e.y), float(e.z)))
    except Exception:
        return _v3(0, 0, 0)

def _space_reference_object(active_obj, obj, orient_str):
    orient_key = str(orient_str or 'GLOBAL')
    if orient_key in {'LOCAL', 'GIMBAL', 'NORMAL', 'PARENT'} and obj is not None:
        return obj
    return active_obj if active_obj is not None else obj


def _scale_vec_in_space(context, obj, orient_str):
    if obj is None:
        return _v3(1, 1, 1)
    if _is_local_like_rotation_space(orient_str, obj):
        try:
            return Vector((float(obj.scale.x), float(obj.scale.y), float(obj.scale.z)))
        except Exception:
            return _v3(1, 1, 1)

    basis = _basis_world_for_object_orient(context, obj, obj, orient_str)
    _rot_space, scale_space = _decompose_in_basis(obj, basis)
    return Vector(scale_space)


def _apply_exact_object_rotation_in_space(context, active_obj, obj, orient_str, desired_e: Vector) -> None:
    if _is_local_like_rotation_space(orient_str, obj):
        _rot_local, scale_local = _local_rot_scale_for_object(obj)
        desired_q = Euler((float(desired_e.x), float(desired_e.y), float(desired_e.z)), 'XYZ').to_quaternion()
        _set_object_local_rot_scale(obj, desired_q, scale_local)
        return

    basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
    desired_q = Euler((float(desired_e.x), float(desired_e.y), float(desired_e.z)), 'XYZ').to_quaternion()
    _rot_space, scale_space = _decompose_in_basis(obj, basis)
    new_m3 = _recompose_world_3x3(basis, desired_q, scale_space)
    loc = obj.matrix_world.translation.copy()
    obj.matrix_world = Matrix.Translation(loc) @ new_m3.to_4x4()


def _apply_exact_object_scale_in_space(context, active_obj, obj, orient_str, desired_scale: Vector) -> None:
    if _is_local_like_rotation_space(orient_str, obj):
        try:
            obj.scale = Vector((float(desired_scale.x), float(desired_scale.y), float(desired_scale.z)))
        except Exception:
            pass
        return

    basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
    rot_space, _scale_space = _decompose_in_basis(obj, basis)
    new_m3 = _recompose_world_3x3(basis, rot_space, Vector((float(desired_scale.x), float(desired_scale.y), float(desired_scale.z))))
    loc = obj.matrix_world.translation.copy()
    obj.matrix_world = Matrix.Translation(loc) @ new_m3.to_4x4()


def _recompose_world_3x3(basis_world: Matrix, rot_space, scale_space: Vector) -> Matrix:
    rs = rot_space.to_matrix() @ Matrix.Diagonal((scale_space.x, scale_space.y, scale_space.z))
    return basis_world @ rs


# ------------------------------------------------------------------------------
# Object Mode numeric fields + Blender "Affect Only" integration
# ------------------------------------------------------------------------------

def _numeric_affect_only_state(context):
    """Return (csdt_utils, effective_state) for Object Mode numeric edits.

    The N-panel numeric fields historically wrote RNA matrices/channels directly,
    bypassing Blender's native transform initialization.  Consequently the 3D
    View Options > Transform > Affect Only flags (Origins / Locations / Parents)
    were ignored even though Smart Gizmo and Smart G-R-S already honored them.

    Keep the direct, low-overhead path when no Affect Only flag is enabled.  When
    one is enabled, use the same effective policy and native transform bridge as
    Smart Gizmo/Smart G-R-S, including the "all object types" switch.
    """
    try:
        active = _context_active_object(context)
        if active is None or str(getattr(active, 'mode', '') or '') != 'OBJECT':
            return None, None
        from . import csdt_utils as cu
        state = dict(cu._effective_transform_affect_only_state(context) or {})
        if not bool(state.get('enabled', False)):
            return None, None
        return cu, state
    except Exception:
        return None, None


def _numeric_object_parent_depth(obj) -> int:
    depth = 0
    seen = set()
    cur = getattr(obj, 'parent', None)
    while cur is not None and depth < 1024:
        try:
            key = int(cur.as_pointer())
        except Exception:
            key = id(cur)
        if key in seen:
            break
        seen.add(key)
        depth += 1
        cur = getattr(cur, 'parent', None)
    return depth


def _numeric_order_objects(objects, state=None):
    """Order per-object numeric transforms parent-first.

    Child targets are evaluated from the live post-parent state.  Affect Only >
    Origins additionally compensates a selected descendant's data whenever an
    exact world-matrix restore is not representable below a non-uniform parent;
    see ``_restore_selected_descendants`` in the native helper.
    """
    return sorted(list(objects or []), key=_numeric_object_parent_depth)


def _numeric_view3d_override_kwargs(context, objects, active_obj):
    """Build a stable Object Mode transform override from an N-panel context."""
    result = {
        'active_object': active_obj,
        'object': active_obj,
        'selected_objects': list(objects),
        'selected_editable_objects': list(objects),
    }
    try:
        window = getattr(context, 'window', None)
        if window is not None:
            result['window'] = window
            screen = getattr(window, 'screen', None)
            if screen is not None:
                result['screen'] = screen
    except Exception:
        pass

    area = None
    try:
        candidate = getattr(context, 'area', None)
        if candidate is not None and getattr(candidate, 'type', None) == 'VIEW_3D':
            area = candidate
    except Exception:
        area = None
    if area is None:
        try:
            screen = result.get('screen', None)
            for candidate in list(getattr(screen, 'areas', []) or []):
                if getattr(candidate, 'type', None) == 'VIEW_3D':
                    area = candidate
                    break
        except Exception:
            area = None
    if area is None:
        return result

    result['area'] = area
    try:
        result['space_data'] = area.spaces.active
    except Exception:
        pass

    region = None
    try:
        candidate = getattr(context, 'region', None)
        if candidate is not None and getattr(candidate, 'type', None) == 'WINDOW' and getattr(context, 'area', None) == area:
            region = candidate
    except Exception:
        region = None
    if region is None:
        try:
            region = next((r for r in area.regions if getattr(r, 'type', None) == 'WINDOW'), None)
        except Exception:
            region = None
    if region is not None:
        result['region'] = region
        try:
            rv3d = getattr(region, 'data', None)
            if rv3d is None:
                rv3d = getattr(result.get('space_data', None), 'region_3d', None)
            if rv3d is not None:
                result['region_data'] = rv3d
        except Exception:
            pass
    return result


def _numeric_matrix_rows(matrix3: Matrix):
    """Return Blender operator orientation rows for a column-basis matrix."""
    try:
        m = safe_normalize_3x3(matrix3).transposed()
    except Exception:
        m = Matrix.Identity(3)
    return tuple(tuple(float(m[r][c]) for c in range(3)) for r in range(3))


def _numeric_unselected_descendant_world_matrices(context, obj):
    """Snapshot descendants excluded by Affect Only > Parents."""
    selected_ids = set()
    try:
        for selected in _object_mode_transform_targets(context):
            selected_ids.add(int(selected.as_pointer()))
    except Exception:
        pass
    result = {}
    stack = list(getattr(obj, 'children', []) or [])
    seen = set()
    while stack:
        child = stack.pop()
        try:
            key = int(child.as_pointer())
        except Exception:
            key = id(child)
        if key in seen:
            continue
        seen.add(key)
        try:
            stack.extend(list(getattr(child, 'children', []) or []))
        except Exception:
            pass
        if key in selected_ids:
            continue
        try:
            result[child] = child.matrix_world.copy()
        except Exception:
            pass
    return result


def _numeric_selected_descendant_world_matrices(context, obj, exclude_objects=None):
    """Snapshot selected descendants outside the current per-object transform."""
    selected_ids = set()
    try:
        for selected in _object_mode_transform_targets(context):
            selected_ids.add(int(selected.as_pointer()))
    except Exception:
        pass
    excluded_ids = set()
    for excluded in list(exclude_objects or []):
        try:
            excluded_ids.add(int(excluded.as_pointer()))
        except Exception:
            excluded_ids.add(id(excluded))
    result = {}
    stack = list(getattr(obj, 'children', []) or [])
    seen = set()
    while stack:
        child = stack.pop()
        try:
            key = int(child.as_pointer())
        except Exception:
            key = id(child)
        if key in seen:
            continue
        seen.add(key)
        try:
            stack.extend(list(getattr(child, 'children', []) or []))
        except Exception:
            pass
        if key not in selected_ids or key in excluded_ids:
            continue
        try:
            result[child] = child.matrix_world.copy()
        except Exception:
            pass
    return result


def _numeric_autokey_direct_transform(context, obj, *, use_loc=False, use_rot=False, use_scale=False):
    """Autokey a rare direct fallback using Blender's own AutoKeying helper."""
    try:
        scene = getattr(context, 'scene', None) or bpy.context.scene
        ts = getattr(scene, 'tool_settings', None)
        if ts is None or not bool(getattr(ts, 'use_keyframe_insert_auto', False)):
            return
        from bpy_extras.anim_utils import AutoKeying
        keytype = str(getattr(ts, 'keyframe_type', 'KEYFRAME') or 'KEYFRAME')
        if keytype not in {'KEYFRAME', 'BREAKDOWN', 'MOVING_HOLD', 'EXTREME', 'JITTER', 'GENERATED'}:
            keytype = 'KEYFRAME'
        with AutoKeying.options(
            keytype=keytype,
            use_loc=bool(use_loc),
            use_rot=bool(use_rot),
            use_scale=bool(use_scale),
            force_autokey=False,
        ):
            AutoKeying.autokey_transformation(context, obj)
    except Exception:
        pass


def _numeric_apply_direct_change_with_affect_only(
    context,
    state,
    obj,
    apply_change,
    *,
    use_loc=False,
    use_rot=False,
    use_scale=False,
):
    """Apply an exact numeric fallback while preserving Affect Only rules.

    Blender's native rotation/resize operator can represent ordinary TRS
    changes exactly.  Under a non-uniformly scaled parent, however, an exact
    local-channel edit can require a world-space shear, and a zero scale cannot
    be reached from a multiplicative factor.  This fallback performs the exact
    channel/matrix change, compensates transformable object data for Origins,
    and restores unselected descendants for Parents.  Data-less objects keep
    Blender's standard Origins no-op.
    """
    if obj is None:
        return False
    try:
        before_world = obj.matrix_world.copy()
    except Exception:
        return False

    # Per-object numeric edits must not let a selected parent implicitly
    # transform a selected child before the child's own target is applied.
    # Blender's modal transform resolves this hierarchy internally; these
    # one-object native/direct calls reproduce that isolation explicitly.
    preserve_children = _numeric_selected_descendant_world_matrices(context, obj, exclude_objects=[obj])
    if bool(state.get('parents', False)):
        preserve_children.update(_numeric_unselected_descendant_world_matrices(context, obj))

    data = getattr(obj, 'data', None)
    data_transform = getattr(data, 'transform', None) if data is not None else None
    origins = bool(state.get('origins', False))
    if origins and not callable(data_transform):
        # Empty, Camera, Light and other data-less/non-transformable object
        # origins intentionally remain unchanged in Blender's native transform.
        return True

    try:
        apply_change()
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        after_world = obj.matrix_world.copy()
    except Exception:
        try:
            obj.matrix_world = before_world
        except Exception:
            pass
        return False

    if origins:
        try:
            correction = after_world.inverted() @ before_world
        except Exception:
            # A target scale of exactly zero is singular.  Blender's standard
            # Origins transform cannot compensate that case either, so retain
            # the native-equivalent collapsed result rather than bypassing the
            # option with a second legacy write.
            correction = None
        if correction is not None:
            transformed = False
            try:
                data_transform(correction, shape_keys=True)
                transformed = True
            except TypeError:
                try:
                    data_transform(correction)
                    transformed = True
                except Exception:
                    transformed = False
            except Exception:
                transformed = False
            if not transformed:
                try:
                    obj.matrix_world = before_world
                except Exception:
                    pass
                return True
            try:
                data.update()
            except Exception:
                pass

    if preserve_children:
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        for child, world in preserve_children.items():
            try:
                child.matrix_world = world
            except Exception:
                pass

    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    _numeric_autokey_direct_transform(
        context,
        obj,
        use_loc=use_loc,
        use_rot=use_rot,
        use_scale=use_scale,
    )
    return True


def _numeric_angle_distance(a, b):
    try:
        import math
        return abs((float(a) - float(b) + math.pi) % (2.0 * math.pi) - math.pi)
    except Exception:
        return abs(float(a) - float(b))


def _numeric_native_transform_exec(
    context,
    state,
    objects,
    active_obj,
    mode,
    *,
    value=None,
    basis=None,
    axis=None,
    pivot=None,
):
    """Execute one native Object Mode transform with a deterministic override."""
    objects = [o for o in list(objects or []) if o is not None]
    if not objects or active_obj is None:
        return False
    try:
        from . import csdt_utils as cu
    except Exception:
        return False

    mode_key = str(mode or '').upper()
    kwargs = {
        'use_proportional_edit': False,
        'mirror': False,
        'release_confirm': False,
    }
    try:
        if mode_key in {'G', 'TRANSLATE', 'MOVE'}:
            delta = Vector(value or (0.0, 0.0, 0.0))
            kwargs.update({
                'value': (float(delta.x), float(delta.y), float(delta.z)),
                'orient_type': 'GLOBAL',
                'constraint_axis': (False, False, False),
            })
            if bool(state.get('origins', False)):
                kwargs['translate_origin'] = True
            op = bpy.ops.transform.translate
        elif mode_key in {'R', 'ROTATE'}:
            idx = int(axis if axis in (0, 1, 2) else 2)
            axis_name = ('X', 'Y', 'Z')[idx]
            mask = [False, False, False]
            mask[idx] = True
            kwargs.update({
                'value': float(value or 0.0),
                'orient_axis': axis_name,
                'orient_type': 'GLOBAL',
                'orient_matrix': _numeric_matrix_rows(basis or Matrix.Identity(3)),
                'orient_matrix_type': 'GLOBAL',
                'constraint_axis': tuple(mask),
            })
            if pivot is not None:
                p = Vector(pivot)
                kwargs['center_override'] = (float(p.x), float(p.y), float(p.z))
            op = bpy.ops.transform.rotate
        elif mode_key in {'S', 'RESIZE', 'SCALE'}:
            factors = Vector(value or (1.0, 1.0, 1.0))
            mask = tuple(abs(float(factors[i]) - 1.0) > 1e-12 for i in range(3))
            kwargs.update({
                'value': (float(factors.x), float(factors.y), float(factors.z)),
                'orient_type': 'GLOBAL',
                'orient_matrix': _numeric_matrix_rows(basis or Matrix.Identity(3)),
                'orient_matrix_type': 'GLOBAL',
                'constraint_axis': mask,
            })
            if pivot is not None:
                p = Vector(pivot)
                kwargs['center_override'] = (float(p.x), float(p.y), float(p.z))
            op = bpy.ops.transform.resize
        else:
            return False
    except Exception:
        return False

    override = _numeric_view3d_override_kwargs(context, objects, active_obj)

    # When a single member of a selected parent/child hierarchy is processed,
    # isolate selected descendants exactly as Blender's one modal transform
    # would.  Otherwise a parent operation cascades into the child and the child
    # receives the numeric change twice when its turn is processed.
    selected_descendants = {}
    current_targets = []
    isolate_selection = False
    try:
        current_targets = _object_mode_transform_targets(context)
        isolate_selection = len(objects) < len(current_targets)
        if isolate_selection:
            for root in objects:
                selected_descendants.update(
                    _numeric_selected_descendant_world_matrices(context, root, exclude_objects=objects)
                )
    except Exception:
        selected_descendants = {}
        current_targets = []
        isolate_selection = False

    selection_snapshot = []
    active_snapshot = None
    if isolate_selection:
        try:
            view_layer = getattr(context, 'view_layer', None) or bpy.context.view_layer
            active_snapshot = getattr(getattr(view_layer, 'objects', None), 'active', None)
            for candidate in current_targets:
                try:
                    selection_snapshot.append((candidate, bool(candidate.select_get())))
                except Exception:
                    pass
            object_ids = set()
            for candidate in objects:
                try:
                    object_ids.add(int(candidate.as_pointer()))
                except Exception:
                    object_ids.add(id(candidate))
            for candidate in current_targets:
                try:
                    key = int(candidate.as_pointer())
                except Exception:
                    key = id(candidate)
                try:
                    candidate.select_set(key in object_ids)
                except Exception:
                    pass
            try:
                view_layer.objects.active = active_obj
            except Exception:
                pass
        except Exception:
            selection_snapshot = []

    def _restore_selected_descendants():
        if not selected_descendants:
            return
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        for child, world in selected_descendants.items():
            try:
                child.matrix_world = world
            except Exception:
                pass
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass

        # A child below a rotated, non-uniformly scaled parent can require a
        # sheared matrix that Object.matrix_world cannot represent exactly.
        # Assigning the saved world matrix then yields a close TRS matrix and,
        # without this correction, an Origins-only parent edit visibly moves
        # the selected child's geometry before its own numeric edit runs.
        # Preserve the saved world-space geometry by absorbing that residual
        # into transformable object data, exactly as Blender does for origins.
        if bool(state.get('origins', False)):
            for child, desired_world in selected_descendants.items():
                data = getattr(child, 'data', None)
                data_transform = getattr(data, 'transform', None) if data is not None else None
                if not callable(data_transform):
                    continue
                try:
                    actual_world = child.matrix_world.copy()
                    correction = actual_world.inverted() @ desired_world
                    if max(
                        abs(float(correction[r][c]) - (1.0 if r == c else 0.0))
                        for r in range(4) for c in range(4)
                    ) <= 1e-10:
                        continue
                    try:
                        data_transform(correction, shape_keys=True)
                    except TypeError:
                        data_transform(correction)
                    try:
                        data.update()
                    except Exception:
                        pass
                except Exception:
                    pass
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass

    def _run_native():
        try:
            with cu._temporary_transform_affect_only_state(bpy.context, state):
                result = op('EXEC_DEFAULT', **kwargs)
            return 'FINISHED' in set(result or ())
        except TypeError:
            # Keep compatibility with Blender patch releases that expose a
            # slightly smaller native operator RNA surface.
            for optional in ('release_confirm', 'mirror', 'orient_matrix_type'):
                kwargs.pop(optional, None)
            try:
                with cu._temporary_transform_affect_only_state(bpy.context, state):
                    result = op('EXEC_DEFAULT', **kwargs)
                return 'FINISHED' in set(result or ())
            except Exception:
                return False
        except Exception:
            return False

    success = False
    try:
        if hasattr(context, 'temp_override'):
            with context.temp_override(**override):
                success = bool(_run_native())
        else:
            success = bool(_run_native())
    except Exception:
        success = bool(_run_native())
    finally:
        _restore_selected_descendants()
        if selection_snapshot:
            try:
                for candidate, selected in selection_snapshot:
                    candidate.select_set(bool(selected))
            except Exception:
                pass
            try:
                view_layer = getattr(context, 'view_layer', None) or bpy.context.view_layer
                if active_snapshot is not None:
                    view_layer.objects.active = active_snapshot
            except Exception:
                pass
    return success


def _numeric_move_objects_to_world_locations(context, state, desired_locations) -> bool:
    """Move selected origins to explicit world locations via native Translate.

    Objects are processed parent-first and each delta is recomputed from the
    *current* world location.  This prevents selected parent/child hierarchies
    from receiving a transform twice while retaining Blender's Parents option
    for unselected descendants and Origins data compensation for supported data.
    """
    if not desired_locations:
        return True
    objects = _numeric_order_objects(list(desired_locations.keys()), state)

    # A common world delta is the normal MEDIAN location-field case.  Let one
    # native transform handle the entire hierarchy so large selections stay as
    # responsive as Blender's standard numeric transform.
    try:
        initial_deltas = [Vector(desired_locations[obj]) - obj.matrix_world.translation.copy() for obj in objects]
        if initial_deltas:
            common = initial_deltas[0]
            if all((delta - common).length_squared <= 1e-24 for delta in initial_deltas[1:]):
                if common.length_squared <= 1e-24:
                    return True
                active_obj = _context_active_object(context)
                if active_obj not in objects:
                    active_obj = objects[0]
                return _numeric_native_transform_exec(
                    context,
                    state,
                    objects,
                    active_obj,
                    'G',
                    value=common,
                )
    except Exception:
        pass

    handled_any = False
    for obj in objects:
        try:
            target = Vector(desired_locations[obj])
            current = obj.matrix_world.translation.copy()
            delta = target - current
        except Exception:
            continue
        if delta.length_squared <= 1e-24:
            handled_any = True
            continue
        if not _numeric_native_transform_exec(
            context,
            state,
            [obj],
            obj,
            'G',
            value=delta,
        ):
            return handled_any
        handled_any = True
    return handled_any or bool(objects)


def _numeric_try_affect_only_location_axis(context, props, orient_str, axis, target_value) -> bool:
    cu, state = _numeric_affect_only_state(context)
    if cu is None:
        return False
    active_obj = _context_active_object(context)
    objs = _object_mode_transform_targets(context)
    if active_obj is None or not objs:
        return False

    desired = {}
    try:
        if _object_uses_local_channels_for_orient(active_obj, orient_str):
            handled = False
            for obj in _numeric_order_objects(objs, state):
                current_value = float(obj.location[int(axis)])
                if abs(float(target_value) - current_value) <= 1e-12:
                    handled = True
                    continue
                delta_local = Vector((0.0, 0.0, 0.0))
                delta_local[int(axis)] = float(target_value) - current_value
                try:
                    parent_effect = obj.matrix_world @ get_matrix_inv(obj.matrix_basis)
                    delta_world = parent_effect.to_3x3() @ delta_local
                except Exception:
                    delta_world = delta_local
                native_ok = _numeric_native_transform_exec(
                    context,
                    state,
                    [obj],
                    obj,
                    'G',
                    value=delta_world,
                )
                if not native_ok:
                    return handled
                handled = True
                try:
                    residual = abs(float(obj.location[int(axis)]) - float(target_value))
                except Exception:
                    residual = 0.0
                if residual > 2e-6 and not (
                    bool(state.get('origins', False)) and getattr(obj, 'data', None) is None
                ):
                    def _set_local_location(o=obj, idx=int(axis), value=float(target_value)):
                        loc = o.location.copy()
                        loc[idx] = value
                        o.location = loc
                    if not _numeric_apply_direct_change_with_affect_only(
                        context,
                        state,
                        obj,
                        _set_local_location,
                        use_loc=True,
                    ):
                        return handled
            return handled or bool(objs)
        elif props.op_mode == 'MEDIAN':
            current_space = _get_loc_vec_cached(context, props, orient_str)
            target_space = current_space.copy()
            target_space[int(axis)] = float(target_value)
            median_world = _median_object_mode_transform_targets_world(context)
            target_world = space_to_world_pos(context, active_obj, orient_str, target_space, is_edit_mode=False)
            delta_world = target_world - median_world
            for obj in objs:
                desired[obj] = obj.matrix_world.translation.copy() + delta_world
        else:
            for obj in objs:
                ref_obj = _space_reference_object(active_obj, obj, orient_str)
                current_space = world_to_space_pos(context, ref_obj, orient_str, obj.matrix_world.translation, is_edit_mode=False)
                target_space = current_space.copy()
                target_space[int(axis)] = float(target_value)
                desired[obj] = space_to_world_pos(context, ref_obj, orient_str, target_space, is_edit_mode=False)
    except Exception:
        return False
    return _numeric_move_objects_to_world_locations(context, state, desired)


def _numeric_try_affect_only_rotation(
    context,
    props,
    orient_str,
    axis,
    *,
    common_delta=None,
    per_object_delta=None,
) -> bool:
    cu, state = _numeric_affect_only_state(context)
    if cu is None:
        return False
    active_obj = _context_active_object(context)
    objs = _object_mode_transform_targets(context)
    if active_obj is None or not objs:
        return False

    axis = int(axis)
    per_object_delta = dict(per_object_delta or {})

    # "Only Locations" suppresses rotation/scale channels.  Convert the
    # operation into explicit origin translations around the same pivot.  The
    # native Translate calls still honor Origins and Parents combinations.
    if bool(state.get('locations', False)):
        if props.op_mode != 'MEDIAN' or common_delta is None:
            # EACH rotates around each object's own origin, so locations do not
            # change when rotation channels are excluded.
            return True
        try:
            basis = _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False)
            axis_world = Vector((basis[0][axis], basis[1][axis], basis[2][axis]))
            if axis_world.length < 1e-8:
                return True
            axis_world.normalize()
            rotation = Matrix.Rotation(float(common_delta), 3, axis_world)
            pivot = _median_object_mode_transform_targets_world(context)
            desired = {
                obj: pivot + (rotation @ (obj.matrix_world.translation.copy() - pivot))
                for obj in objs
            }
            return _numeric_move_objects_to_world_locations(context, state, desired)
        except Exception:
            return False

    if per_object_delta:
        handled = False
        for obj in _numeric_order_objects(objs, state):
            delta = float(per_object_delta.get(obj, 0.0))
            if abs(delta) <= 1e-12:
                handled = True
                continue
            basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
            pivot = obj.matrix_world.translation.copy()
            if not _numeric_native_transform_exec(context, state, [obj], obj, 'R', value=delta, basis=basis, axis=axis, pivot=pivot):
                return handled
            handled = True
        return handled or bool(objs)

    delta = float(common_delta or 0.0)
    if abs(delta) <= 1e-12:
        return True
    if props.op_mode == 'MEDIAN':
        basis = _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False)
        pivot = _median_object_mode_transform_targets_world(context)
        return _numeric_native_transform_exec(context, state, objs, active_obj, 'R', value=delta, basis=basis, axis=axis, pivot=pivot)

    handled = False
    for obj in _numeric_order_objects(objs, state):
        basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
        pivot = obj.matrix_world.translation.copy()
        if not _numeric_native_transform_exec(context, state, [obj], obj, 'R', value=delta, basis=basis, axis=axis, pivot=pivot):
            return handled
        handled = True
    return handled or bool(objs)


def _numeric_try_affect_only_scale(
    context,
    props,
    orient_str,
    *,
    common_factors=None,
    per_object_factors=None,
    per_object_bases=None,
    per_object_target_scales=None,
    per_object_dimension_targets=None,
) -> bool:
    cu, state = _numeric_affect_only_state(context)
    if cu is None:
        return False
    active_obj = _context_active_object(context)
    objs = _object_mode_transform_targets(context)
    if active_obj is None or not objs:
        return False

    per_object_factors = dict(per_object_factors or {})
    per_object_bases = dict(per_object_bases or {})
    per_object_target_scales = dict(per_object_target_scales or {})
    per_object_dimension_targets = dict(per_object_dimension_targets or {})

    if bool(state.get('locations', False)):
        if props.op_mode != 'MEDIAN' or common_factors is None:
            # EACH scales around each object's own origin.  With Only Locations
            # enabled there is therefore no channel or origin-location change.
            return True
        try:
            factors = Vector(common_factors)
            basis = _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False)
            scale_world = basis @ Matrix.Diagonal((float(factors.x), float(factors.y), float(factors.z))) @ get_matrix_inv(basis)
            pivot = _median_object_mode_transform_targets_world(context)
            desired = {
                obj: pivot + (scale_world @ (obj.matrix_world.translation.copy() - pivot))
                for obj in objs
            }
            return _numeric_move_objects_to_world_locations(context, state, desired)
        except Exception:
            return False

    if per_object_target_scales or per_object_dimension_targets:
        # ABS scale/dimension fields must end at the typed value even when a
        # selected object is parented below a non-uniformly scaled object.  A
        # single world-space resize can decompose back to a slightly different
        # local scale in that case, so recompute a small native correction from
        # the live post-parent state.  This keeps Origins/Parents semantics in
        # Blender's transform operator while converging the displayed numeric
        # channel to the requested value.
        handled = False
        for obj in _numeric_order_objects(objs, state):
            target_scale = per_object_target_scales.get(obj)
            dimension_target = per_object_dimension_targets.get(obj)
            if target_scale is None and dimension_target is None:
                handled = True
                continue

            finished_native = False
            for _iteration in range(6):
                try:
                    if target_scale is not None:
                        target_vec = Vector(target_scale)
                        current_vec = _scale_vec_in_space(context, obj, orient_str)
                        residual = max(abs(float(target_vec[i]) - float(current_vec[i])) for i in range(3))
                        if residual <= 2e-6:
                            finished_native = True
                            break
                        factor_values = []
                        valid = True
                        for i in range(3):
                            cur = float(current_vec[i])
                            target = float(target_vec[i])
                            if abs(cur) <= 1e-12:
                                if abs(target - cur) > 2e-6:
                                    valid = False
                                    break
                                factor_values.append(1.0)
                            else:
                                factor_values.append(target / cur)
                        if not valid:
                            direct_ok = _numeric_apply_direct_change_with_affect_only(
                                context,
                                state,
                                obj,
                                lambda o=obj, target_value=target_vec.copy(): _apply_exact_object_scale_in_space(
                                    context,
                                    active_obj,
                                    o,
                                    orient_str,
                                    target_value,
                                ),
                                use_scale=True,
                            )
                            finished_native = bool(direct_ok)
                            break
                        factors = Vector(tuple(factor_values))
                        basis = _numeric_exact_scale_basis(context, active_obj, obj, orient_str)
                    else:
                        dim_axis, dim_target = dimension_target
                        dim_axis = int(dim_axis)
                        current_dim = float(obj.dimensions[dim_axis])
                        if abs(float(dim_target) - current_dim) <= 2e-6:
                            finished_native = True
                            break
                        if abs(current_dim) <= 1e-12:
                            break
                        factors = Vector((1.0, 1.0, 1.0))
                        factors[dim_axis] = float(dim_target) / current_dim
                        basis = _numeric_exact_scale_basis(context, active_obj, obj, 'LOCAL')

                    if all(abs(float(factors[i]) - 1.0) <= 1e-12 for i in range(3)):
                        finished_native = True
                        break
                    pivot = obj.matrix_world.translation.copy()
                    if not _numeric_native_transform_exec(
                        context,
                        state,
                        [obj],
                        obj,
                        'S',
                        value=factors,
                        basis=basis,
                        pivot=pivot,
                    ):
                        return handled
                    finished_native = True

                    # Dimensions describe evaluated world-space geometry.  With
                    # Affect Only > Origins that geometry intentionally remains
                    # unchanged, so the displayed Dimensions value cannot move
                    # toward the typed target.  Apply the requested factor once
                    # (matching a standard origin-only scale) instead of
                    # repeatedly multiplying the hidden object/data inverse.
                    if bool(state.get('origins', False)) and dimension_target is not None:
                        break

                    # For data-less objects, Origins intentionally makes the
                    # standard transform a no-op.  Do not retry or fall through
                    # to a direct channel write that would violate that rule.
                    if bool(state.get('origins', False)) and getattr(obj, 'data', None) is None:
                        break
                except Exception:
                    break
            handled = handled or finished_native
        return handled or bool(objs)

    if per_object_factors:
        handled = False
        for obj in _numeric_order_objects(objs, state):
            factors = Vector(per_object_factors.get(obj, (1.0, 1.0, 1.0)))
            if all(abs(float(factors[i]) - 1.0) <= 1e-12 for i in range(3)):
                handled = True
                continue
            basis = per_object_bases.get(obj)
            if basis is None:
                basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
            pivot = obj.matrix_world.translation.copy()
            if not _numeric_native_transform_exec(context, state, [obj], obj, 'S', value=factors, basis=basis, pivot=pivot):
                return handled
            handled = True
        return handled or bool(objs)

    factors = Vector(common_factors or (1.0, 1.0, 1.0))
    if all(abs(float(factors[i]) - 1.0) <= 1e-12 for i in range(3)):
        return True
    if props.op_mode == 'MEDIAN':
        basis = _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False)
        pivot = _median_object_mode_transform_targets_world(context)
        return _numeric_native_transform_exec(context, state, objs, active_obj, 'S', value=factors, basis=basis, pivot=pivot)

    handled = False
    for obj in _numeric_order_objects(objs, state):
        basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
        pivot = obj.matrix_world.translation.copy()
        if not _numeric_native_transform_exec(context, state, [obj], obj, 'S', value=factors, basis=basis, pivot=pivot):
            return handled
        handled = True
    return handled or bool(objs)


def _numeric_desired_rotation_world_matrix(context, active_obj, obj, orient_str, desired_e: Vector):
    """Return the exact world matrix used by the legacy ABS rotation field."""
    old_world = obj.matrix_world.copy()
    desired_q = Euler(
        (float(desired_e.x), float(desired_e.y), float(desired_e.z)),
        'XYZ',
    ).to_quaternion()
    if _is_local_like_rotation_space(orient_str, obj):
        try:
            old_basis = obj.matrix_basis.copy()
            loc_basis, _rot_basis, scale_basis = old_basis.decompose()
            new_basis = Matrix.LocRotScale(loc_basis, desired_q, scale_basis)
            parent_effect = old_world @ get_matrix_inv(old_basis)
            return parent_effect @ new_basis
        except Exception:
            return None

    try:
        basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
        _rot_space, scale_space = _decompose_in_basis(obj, basis)
        new_m3 = _recompose_world_3x3(basis, desired_q, scale_space)
        return Matrix.Translation(old_world.translation.copy()) @ new_m3.to_4x4()
    except Exception:
        return None


def _numeric_basis_with_z_axis(axis_world: Vector) -> Matrix:
    z_axis = Vector(axis_world)
    if z_axis.length < 1e-10:
        return Matrix.Identity(3)
    z_axis.normalize()
    helper = Vector((0.0, 1.0, 0.0))
    if abs(z_axis.dot(helper)) > 0.95:
        helper = Vector((1.0, 0.0, 0.0))
    x_axis = helper.cross(z_axis)
    if x_axis.length < 1e-10:
        x_axis = Vector((1.0, 0.0, 0.0))
    else:
        x_axis.normalize()
    y_axis = z_axis.cross(x_axis)
    if y_axis.length < 1e-10:
        y_axis = Vector((0.0, 1.0, 0.0))
    else:
        y_axis.normalize()
    return Matrix((
        (x_axis.x, y_axis.x, z_axis.x),
        (x_axis.y, y_axis.y, z_axis.y),
        (x_axis.z, y_axis.z, z_axis.z),
    ))


def _numeric_try_affect_only_exact_rotation(
    context,
    props,
    orient_str,
    desired_world_matrices,
    desired_eulers=None,
) -> bool:
    """Apply exact ABS rotation through native Transform or a safe fallback.

    Numeric Euler component edits are not always a simple rotation around the
    displayed X/Y/Z axis.  Derive the true relative axis-angle when possible.
    If a non-uniform parent introduces shear, apply the exact matrix directly
    while compensating object data and descendants so Origins/Parents still
    behave like Blender's standard transform options.
    """
    cu, state = _numeric_affect_only_state(context)
    if cu is None:
        return False
    objects = [obj for obj in list(desired_world_matrices.keys()) if obj is not None]
    if not objects:
        return False
    if bool(state.get('locations', False)):
        # Exact single/EACH rotation is around each object's own origin.
        return True

    desired_eulers = dict(desired_eulers or {})
    active_obj = _context_active_object(context)
    handled = False
    for obj in _numeric_order_objects(objects, state):
        desired_e = desired_eulers.get(obj)
        target = desired_world_matrices.get(obj)
        if desired_e is not None:
            try:
                target_live = _numeric_desired_rotation_world_matrix(
                    context,
                    active_obj,
                    obj,
                    orient_str,
                    Vector(desired_e),
                )
                if target_live is not None:
                    target = target_live
            except Exception:
                pass
        if target is None:
            continue
        target = Matrix(target)

        pure_rotation = False
        axis_world = Vector((0.0, 0.0, 1.0))
        angle = 0.0
        try:
            current3 = obj.matrix_world.to_3x3()
            target3 = target.to_3x3()
            delta3 = target3 @ get_matrix_inv(current3)
            quat = delta3.to_quaternion()
            rotation3 = quat.to_matrix()
            error = max(
                abs(float(delta3[r][c]) - float(rotation3[r][c]))
                for r in range(3) for c in range(3)
            )
            if error <= 2e-4:
                axis_world, angle = quat.to_axis_angle()
                axis_world = Vector(axis_world)
                pure_rotation = True
        except Exception:
            pure_rotation = False

        native_finished = False
        if pure_rotation:
            if abs(float(angle)) <= 1e-12:
                native_finished = True
            else:
                basis = _numeric_basis_with_z_axis(axis_world)
                pivot = obj.matrix_world.translation.copy()
                native_finished = _numeric_native_transform_exec(
                    context,
                    state,
                    [obj],
                    obj,
                    'R',
                    value=float(angle),
                    basis=basis,
                    axis=2,
                    pivot=pivot,
                )

        needs_direct = not native_finished
        if native_finished and desired_e is not None and not (
            bool(state.get('origins', False)) and getattr(obj, 'data', None) is None
        ):
            try:
                current_e = _rotation_vec_in_space(context, obj, orient_str)
                residual = max(
                    _numeric_angle_distance(current_e[i], Vector(desired_e)[i])
                    for i in range(3)
                )
                needs_direct = residual > 2e-5
            except Exception:
                needs_direct = False

        if needs_direct:
            # Recompute after any parent operation, then apply one exact
            # channel/matrix correction.  Repeating a world-Euler target below
            # a sheared parent can amplify the unrepresentable shear without
            # converging, so the single Blender-compatible decomposition is
            # authoritative.  Origins and Parents are preserved by the helper.
            direct_ok = False
            for _iteration in range(1):
                if desired_e is not None:
                    try:
                        current_e = _rotation_vec_in_space(context, obj, orient_str)
                        if max(
                            _numeric_angle_distance(current_e[i], Vector(desired_e)[i])
                            for i in range(3)
                        ) <= 2e-5:
                            direct_ok = True
                            break
                        target_live = _numeric_desired_rotation_world_matrix(
                            context,
                            active_obj,
                            obj,
                            orient_str,
                            Vector(desired_e),
                        )
                        if target_live is not None:
                            target = Matrix(target_live)
                    except Exception:
                        pass
                direct_ok = _numeric_apply_direct_change_with_affect_only(
                    context,
                    state,
                    obj,
                    lambda o=obj, m=target.copy(): setattr(o, 'matrix_world', m),
                    use_rot=True,
                )
                if not direct_ok:
                    break
                if bool(state.get('origins', False)) and getattr(obj, 'data', None) is None:
                    break
            if not direct_ok:
                return handled
        handled = True
    return handled or bool(objects)

def _numeric_exact_scale_basis(context, active_obj, obj, orient_str) -> Matrix:
    """Return the oriented axes that preserve exact ABS scale components."""
    if _is_local_like_rotation_space(orient_str, obj):
        try:
            _loc, world_rot, _scale = obj.matrix_world.decompose()
            return safe_normalize_3x3(world_rot.to_matrix())
        except Exception:
            return safe_normalize_3x3(obj.matrix_world.to_3x3())
    basis = _basis_world_for_object_orient(context, active_obj, obj, orient_str)
    rot_space, _scale_space = _decompose_in_basis(obj, basis)
    try:
        return safe_normalize_3x3(basis @ rot_space.to_matrix())
    except Exception:
        return safe_normalize_3x3(basis)

def _get_rot_vec_cached(context, props, orient_str):
    cache = _panel_runtime_cache(props)
    key = _cache_key_base(context, props, orient_str) + ("ROT",)
    if cache.get('rot_key') == key:
        try:
            return Vector(cache.get('rot_val', (0.0, 0.0, 0.0)))
        except Exception:
            pass
    v = _calc_rot_vec(context, props, orient_str)
    cache['rot_key'] = key
    cache['rot_val'] = (float(v.x), float(v.y), float(v.z))
    return v

def _calc_rot_vec(context, props, orient_str):
    obj = _context_active_object(context)
    if not obj:
        return _v3(0, 0, 0)

    if props.input_mode == 'DELTA':
        if _pref(context, "delta_display_mode", "KNOB") == 'AUTOZERO':
            return _v3(0, 0, 0)
        return Vector((
            float(props.get("_delta_rot_last_x", 0.0)),
            float(props.get("_delta_rot_last_y", 0.0)),
            float(props.get("_delta_rot_last_z", 0.0)),
        ))

    if obj.mode == 'EDIT':
        return Vector((
            float(props.get("_edit_abs_rot_last_x", 0.0)),
            float(props.get("_edit_abs_rot_last_y", 0.0)),
            float(props.get("_edit_abs_rot_last_z", 0.0)),
        ))

    if obj.mode == 'POSE' and obj.type == 'ARMATURE':
        pb = context.active_pose_bone
        if not pb:
            return _v3(0, 0, 0)
        return _object_local_rotation_xyz(pb)

    if obj.mode != 'OBJECT':
        return _v3(0, 0, 0)

    return _rotation_vec_in_space(context, obj, orient_str)

def _apply_delta_rotation_objects(context, props, orient_str, axis: int, delta_angle: float):
    obj = _context_active_object(context)
    if not obj:
        return

    # EDIT MODE (mesh / curve / lattice elements)
    if obj.mode == 'EDIT':
        _apply_delta_rotation_edit_selection(context, props, orient_str, axis, delta_angle)
        return

    # POSE MODE (Armature)
    if obj.mode == 'POSE' and obj.type == 'ARMATURE':
        bones = _selected_pose_bones(context)
        if not bones:
            return

        basis = _basis_world_for_orient_pose(context, obj, orient_str)
        axis_world = Vector((basis[0][axis], basis[1][axis], basis[2][axis]))
        if axis_world.length < 1e-8:
            return
        axis_world.normalize()

        dR = Matrix.Rotation(float(delta_angle), 3, axis_world)

        if props.op_mode == 'EACH' and _pref(context, "pose_each_rotation_mode", "CHANNEL") == 'CHANNEL':
            axis_local = Vector((1.0, 0.0, 0.0)) if axis == 0 else (Vector((0.0, 1.0, 0.0)) if axis == 1 else Vector((0.0, 0.0, 1.0)))
            q_delta = Quaternion(axis_local, float(delta_angle))

            for pb in bones:
                try:
                    if pb.rotation_mode == 'QUATERNION':
                        q_old = pb.rotation_quaternion.copy()
                    elif pb.rotation_mode == 'AXIS_ANGLE':
                        ang = float(pb.rotation_axis_angle[0])
                        axis_v = Vector((float(pb.rotation_axis_angle[1]), float(pb.rotation_axis_angle[2]), float(pb.rotation_axis_angle[3])))
                        if axis_v.length < 1e-8:
                            axis_v = Vector((0.0, 0.0, 1.0))
                        axis_v.normalize()
                        q_old = Quaternion(axis_v, ang)
                    else:
                        q_old = pb.rotation_euler.to_quaternion()

                    q_new = q_old @ q_delta

                    if pb.rotation_mode == 'QUATERNION':
                        pb.rotation_quaternion = q_new
                    elif pb.rotation_mode == 'AXIS_ANGLE':
                        axis2, ang2 = q_new.to_axis_angle()
                        pb.rotation_axis_angle[0] = float(ang2)
                        pb.rotation_axis_angle[1] = float(axis2.x)
                        pb.rotation_axis_angle[2] = float(axis2.y)
                        pb.rotation_axis_angle[3] = float(axis2.z)
                    else:
                        pb.rotation_euler = q_new.to_euler(pb.rotation_mode)
                except Exception:
                    pass
            return

        pivot_common = None
        if props.op_mode == 'MEDIAN':
            pivot_common = _median_pose_bones_world(context)

        obj_mw = obj.matrix_world.copy()
        obj_mw_inv = get_matrix_inv(obj_mw)

        for pb in bones:
            try:
                bone_world = obj_mw @ pb.matrix
                head_world = obj_mw @ pb.head
                pivot = pivot_common if pivot_common is not None else head_world

                T = Matrix.Translation(pivot)
                Ti = Matrix.Translation(-pivot)
                new_world = T @ dR.to_4x4() @ Ti @ bone_world
                pb.matrix = obj_mw_inv @ new_world
            except Exception:
                pass
        return

    # OBJECT MODE
    active_obj = obj
    objs = _object_mode_transform_targets(context)
    if not objs:
        return

    if _numeric_try_affect_only_rotation(
        context,
        props,
        orient_str,
        axis,
        common_delta=float(delta_angle),
    ):
        return

    if props.op_mode == 'MEDIAN':
        basis = _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False)
        axis_world = Vector((basis[0][axis], basis[1][axis], basis[2][axis]))
        if axis_world.length < 1e-8:
            return
        axis_world.normalize()
        dR = Matrix.Rotation(float(delta_angle), 3, axis_world)
        pivot = _median_object_mode_transform_targets_world(context)
        T = Matrix.Translation(pivot)
        Ti = Matrix.Translation(-pivot)
        for o in objs:
            o.matrix_world = T @ dR.to_4x4() @ Ti @ o.matrix_world
        return

    for o in objs:
        basis = _basis_world_for_object_orient(context, active_obj, o, orient_str)
        axis_world = Vector((basis[0][axis], basis[1][axis], basis[2][axis]))
        if axis_world.length < 1e-8:
            continue
        axis_world.normalize()
        dR = Matrix.Rotation(float(delta_angle), 3, axis_world)
        pivot = o.matrix_world.translation
        T = Matrix.Translation(pivot)
        Ti = Matrix.Translation(-pivot)
        o.matrix_world = T @ dR.to_4x4() @ Ti @ o.matrix_world

def _set_rot_axis(context, props, orient_str, axis: int, target_value: float):
    obj = _context_active_object(context)
    if not obj:
        return

    if not _is_number(target_value):
        return

    try:
        if props.input_mode == 'DELTA':
            key = ("_delta_rot_last_x", "_delta_rot_last_y", "_delta_rot_last_z")[axis]

            if _pref(context, "delta_display_mode", "KNOB") == 'AUTOZERO':
                delta = float(target_value)
                props[key] = 0.0
                if abs(delta) > 1e-12:
                    _apply_delta_rotation_objects(context, props, orient_str, axis, delta)
                return

            last = float(props.get(key, 0.0))
            cur = float(target_value)
            delta = cur - last
            props[key] = cur
            if abs(delta) > 1e-12:
                _apply_delta_rotation_objects(context, props, orient_str, axis, delta)
            return

        # ABS mode
        if obj.mode == 'EDIT':
            key = ("_edit_abs_rot_last_x", "_edit_abs_rot_last_y", "_edit_abs_rot_last_z")[axis]
            last = float(props.get(key, 0.0))
            cur = float(target_value)
            delta = cur - last
            props[key] = cur
            if abs(delta) > 1e-12:
                _apply_delta_rotation_edit_selection(context, props, orient_str, axis, delta)
            return

        if obj.mode == 'POSE' and obj.type == 'ARMATURE':
            if props.op_mode == 'EACH' and _pref(context, "pose_each_rotation_mode", "CHANNEL") == 'CHANNEL':
                bones = _selected_pose_bones(context)
                if not bones:
                    return
                for pb in bones:
                    try:
                        e = _object_local_rotation_xyz(pb)
                        e[axis] = float(target_value)
                        q = Euler((float(e.x), float(e.y), float(e.z)), 'XYZ').to_quaternion()

                        if pb.rotation_mode == 'QUATERNION':
                            pb.rotation_quaternion = q
                        elif pb.rotation_mode == 'AXIS_ANGLE':
                            axis2, ang2 = q.to_axis_angle()
                            pb.rotation_axis_angle[0] = float(ang2)
                            pb.rotation_axis_angle[1] = float(axis2.x)
                            pb.rotation_axis_angle[2] = float(axis2.y)
                            pb.rotation_axis_angle[3] = float(axis2.z)
                        else:
                            pb.rotation_euler = q.to_euler(pb.rotation_mode)
                    except Exception:
                        pass
                return

            cur_vec = _get_rot_vec_cached(context, props, orient_str)
            delta = float(target_value) - float(cur_vec[axis])
            if abs(delta) > 1e-12:
                _apply_delta_rotation_objects(context, props, orient_str, axis, delta)
            return

        objs = _object_mode_transform_targets(context)
        if not objs:
            return

        target_value = float(target_value)

        affect_cu, _affect_state = _numeric_affect_only_state(context)
        if affect_cu is not None:
            if len(objs) == 1 or props.op_mode == 'EACH':
                desired_world_matrices = {}
                desired_eulers = {}
                for o in objs:
                    current_e = (
                        _get_rot_vec_cached(context, props, orient_str)
                        if len(objs) == 1
                        else _rotation_vec_in_space(context, o, orient_str)
                    )
                    if abs(target_value - float(current_e[axis])) <= 1e-12:
                        continue
                    desired_e = current_e.copy()
                    desired_e[axis] = target_value
                    desired_world = _numeric_desired_rotation_world_matrix(
                        context,
                        obj,
                        o,
                        orient_str,
                        desired_e,
                    )
                    if desired_world is None:
                        desired_world_matrices = {}
                        break
                    desired_world_matrices[o] = desired_world
                    desired_eulers[o] = desired_e.copy()
                if not desired_world_matrices:
                    return
                if _numeric_try_affect_only_exact_rotation(
                    context,
                    props,
                    orient_str,
                    desired_world_matrices,
                    desired_eulers=desired_eulers,
                ):
                    return
            else:
                current_e = _get_rot_vec_cached(context, props, orient_str)
                delta = target_value - float(current_e[axis])
                if _numeric_try_affect_only_rotation(
                    context,
                    props,
                    orient_str,
                    axis,
                    common_delta=delta,
                ):
                    return

        if len(objs) == 1:
            cur_vec = _get_rot_vec_cached(context, props, orient_str)
            if abs(target_value - float(cur_vec[axis])) < 1e-12:
                return
            desired_e = cur_vec.copy()
            desired_e[axis] = target_value
            _apply_exact_object_rotation_in_space(context, obj, objs[0], orient_str, desired_e)
            return

        if props.op_mode == 'EACH':
            for o in objs:
                desired_e = _rotation_vec_in_space(context, o, orient_str)
                if abs(target_value - float(desired_e[axis])) < 1e-12:
                    continue
                desired_e[axis] = target_value
                _apply_exact_object_rotation_in_space(context, obj, o, orient_str, desired_e)
            return

        cur_vec = _get_rot_vec_cached(context, props, orient_str)
        delta = target_value - float(cur_vec[axis])
        if abs(delta) < 1e-12:
            return

        _apply_delta_rotation_objects(context, props, orient_str, axis, delta)
    finally:
        _bump_panel_runtime_cache(props)

# --- Scale ---

def _get_scale_vec_cached(context, props, orient_str):
    cache = _panel_runtime_cache(props)
    key = _cache_key_base(context, props, orient_str) + ("SCALE",)
    if cache.get('scale_key') == key:
        try:
            return Vector(cache.get('scale_val', (1.0, 1.0, 1.0)))
        except Exception:
            pass
    v = _calc_scale_vec(context, props, orient_str)
    cache['scale_key'] = key
    cache['scale_val'] = (float(v.x), float(v.y), float(v.z))
    return v

def _calc_scale_vec(context, props, orient_str):
    obj = _context_active_object(context)
    if not obj:
        return _v3(1, 1, 1)

    if props.input_mode == 'DELTA':
        disp = _pref(context, "delta_display_mode", "KNOB")
        style = _pref(context, "delta_scale_style", "FACTOR")

        if disp == 'AUTOZERO':
            if style == 'ADD':
                return _v3(0, 0, 0)
            return _v3(1, 1, 1)

        if style == 'ADD':
            return Vector((
                float(props.get("_delta_scale_last_x", 0.0)),
                float(props.get("_delta_scale_last_y", 0.0)),
                float(props.get("_delta_scale_last_z", 0.0)),
            ))

        return Vector((
            float(props.get("_delta_scale_last_x", 1.0)),
            float(props.get("_delta_scale_last_y", 1.0)),
            float(props.get("_delta_scale_last_z", 1.0)),
        ))

    if obj.mode == 'EDIT':
        return Vector((
            float(props.get("_edit_abs_scale_last_x", 1.0)),
            float(props.get("_edit_abs_scale_last_y", 1.0)),
            float(props.get("_edit_abs_scale_last_z", 1.0)),
        ))

    if obj.mode == 'POSE' and obj.type == 'ARMATURE':
        pb = getattr(context, 'active_pose_bone', None)
        if pb is None:
            return _v3(1, 1, 1)
        try:
            return Vector((float(pb.scale.x), float(pb.scale.y), float(pb.scale.z)))
        except Exception:
            return _v3(1, 1, 1)

    if obj.mode != 'OBJECT':
        return _v3(1, 1, 1)

    active_obj = obj
    if _object_uses_local_channels_for_orient(active_obj, orient_str):
        try:
            return Vector((float(active_obj.scale.x), float(active_obj.scale.y), float(active_obj.scale.z)))
        except Exception:
            return _v3(1, 1, 1)

    basis = _basis_world_for_orient(context, active_obj, orient_str, is_edit_mode=False)
    _rot_space, scale_space = _decompose_in_basis(active_obj, basis)
    return Vector(scale_space)

def _apply_delta_scale_objects_multi(context, props, orient_str, factors) -> None:

    obj = _context_active_object(context)
    if not obj:
        return

    try:
        fx, fy, fz = (float(factors[0]), float(factors[1]), float(factors[2]))
    except Exception:
        return

    if obj.mode == 'EDIT':
        _apply_delta_scale_edit_selection(context, props, orient_str, (fx, fy, fz))
        return

    # Apply around pivot for MEDIAN, or around self origin for EACH
    objs = _object_mode_transform_targets(context)
    if not objs:
        return

    if _numeric_try_affect_only_scale(
        context,
        props,
        orient_str,
        common_factors=Vector((fx, fy, fz)),
    ):
        return

    if props.op_mode == 'MEDIAN':
        basis = _basis_world_for_orient(context, obj, orient_str, is_edit_mode=False)
        S_space = Matrix.Diagonal((fx, fy, fz))
        S_world = basis @ S_space @ get_matrix_inv(basis)
        pivot = _median_object_mode_transform_targets_world(context)
        T = Matrix.Translation(pivot)
        Ti = Matrix.Translation(-pivot)
        for o in objs:
            o.matrix_world = T @ S_world.to_4x4() @ Ti @ o.matrix_world
        return

    for o in objs:
        basis = _basis_world_for_object_orient(context, obj, o, orient_str)
        S_space = Matrix.Diagonal((fx, fy, fz))
        S_world = basis @ S_space @ get_matrix_inv(basis)
        pivot = o.matrix_world.translation
        T = Matrix.Translation(pivot)
        Ti = Matrix.Translation(-pivot)
        o.matrix_world = T @ S_world.to_4x4() @ Ti @ o.matrix_world


def _apply_delta_scale_objects(context, props, orient_str, axis: int, factor: float):

    fx, fy, fz = 1.0, 1.0, 1.0
    if axis == 0:
        fx = factor
    elif axis == 1:
        fy = factor
    else:
        fz = factor

    _apply_delta_scale_objects_multi(context, props, orient_str, (fx, fy, fz))

def _apply_delta_scale_pose_bones_multi(context, factors) -> None:
    bones = _selected_pose_bones(context)
    if not bones:
        return
    try:
        fx, fy, fz = (float(factors[0]), float(factors[1]), float(factors[2]))
    except Exception:
        return
    for pb in bones:
        try:
            pb.scale = Vector((float(pb.scale.x) * fx, float(pb.scale.y) * fy, float(pb.scale.z) * fz))
        except Exception:
            pass


def _set_scale_vector(context, props, orient_str, target_vec, target_axes=None) -> None:
    obj = _context_active_object(context)
    if not obj:
        return

    try:
        target = Vector((float(target_vec[0]), float(target_vec[1]), float(target_vec[2])))
    except Exception:
        return

    try:
        if props.input_mode == 'DELTA':
            disp = _pref(context, "delta_display_mode", "KNOB")
            style = _pref(context, "delta_scale_style", "FACTOR")
            keys = ("_delta_scale_last_x", "_delta_scale_last_y", "_delta_scale_last_z")

            if style == 'ADD':
                if disp == 'AUTOZERO':
                    factors = Vector((1.0 + float(target.x), 1.0 + float(target.y), 1.0 + float(target.z)))
                    for key in keys:
                        props[key] = 0.0
                else:
                    last = Vector((
                        float(props.get(keys[0], 0.0)),
                        float(props.get(keys[1], 0.0)),
                        float(props.get(keys[2], 0.0)),
                    ))
                    delta = target - last
                    factors = Vector((1.0 + float(delta.x), 1.0 + float(delta.y), 1.0 + float(delta.z)))
                    props[keys[0]] = float(target.x)
                    props[keys[1]] = float(target.y)
                    props[keys[2]] = float(target.z)
            else:
                if disp == 'AUTOZERO':
                    factors = Vector((float(target.x), float(target.y), float(target.z)))
                    for key in keys:
                        props[key] = 1.0
                else:
                    last = Vector((
                        float(props.get(keys[0], 1.0)),
                        float(props.get(keys[1], 1.0)),
                        float(props.get(keys[2], 1.0)),
                    ))
                    factors = []
                    for idx in range(3):
                        prev = float(last[idx])
                        if abs(prev) < 1e-12:
                            prev = 1.0
                        factors.append(float(target[idx]) / prev)
                    factors = Vector(tuple(factors))
                    props[keys[0]] = float(target.x)
                    props[keys[1]] = float(target.y)
                    props[keys[2]] = float(target.z)

            if any(abs(float(v) - 1.0) > 1e-12 for v in factors):
                if obj.mode == 'EDIT':
                    _apply_delta_scale_edit_selection(context, props, orient_str, factors)
                elif obj.mode == 'POSE' and obj.type == 'ARMATURE':
                    _apply_delta_scale_pose_bones_multi(context, factors)
                elif obj.mode == 'OBJECT':
                    _apply_delta_scale_objects_multi(context, props, orient_str, factors)
            return

        if obj.mode == 'EDIT':
            keys = ("_edit_abs_scale_last_x", "_edit_abs_scale_last_y", "_edit_abs_scale_last_z")
            last = Vector((
                float(props.get(keys[0], 1.0)),
                float(props.get(keys[1], 1.0)),
                float(props.get(keys[2], 1.0)),
            ))
            factors = []
            for idx in range(3):
                prev = float(last[idx])
                if abs(prev) < 1e-12:
                    prev = 1.0
                factors.append(float(target[idx]) / prev)
            props[keys[0]] = float(target.x)
            props[keys[1]] = float(target.y)
            props[keys[2]] = float(target.z)
            _apply_delta_scale_edit_selection(context, props, orient_str, Vector(tuple(factors)))
            return

        if obj.mode == 'POSE' and obj.type == 'ARMATURE':
            bones = _selected_pose_bones(context)
            if not bones:
                return
            try:
                target_axes = tuple(sorted({int(idx) for idx in (target_axes or ()) if 0 <= int(idx) < 3}))
            except Exception:
                target_axes = ()
            if not target_axes:
                target_axes = (0, 1, 2)
            for pb in bones:
                try:
                    desired = Vector((float(pb.scale.x), float(pb.scale.y), float(pb.scale.z)))
                    for idx in target_axes:
                        desired[idx] = float(target[idx])
                    pb.scale = desired.copy()
                except Exception:
                    pass
            return

        if obj.mode != 'OBJECT':
            return

        objs = _object_mode_transform_targets(context)
        if not objs:
            return

        try:
            target_axes = tuple(sorted({int(idx) for idx in (target_axes or ()) if 0 <= int(idx) < 3}))
        except Exception:
            target_axes = ()

        def desired_scale_for_object(target_obj):
            if not target_axes:
                return Vector((float(target.x), float(target.y), float(target.z)))
            desired = _scale_vec_in_space(context, target_obj, orient_str)
            desired = Vector((float(desired.x), float(desired.y), float(desired.z)))
            for idx in target_axes:
                desired[idx] = float(target[idx])
            return desired

        affect_cu, _affect_state = _numeric_affect_only_state(context)
        if affect_cu is not None:
            valid_native = True
            if len(objs) == 1 or props.op_mode == 'EACH':
                per_object_target_scales = {
                    o: desired_scale_for_object(o)
                    for o in objs
                }
                if _numeric_try_affect_only_scale(
                    context,
                    props,
                    orient_str,
                    per_object_target_scales=per_object_target_scales,
                ):
                    return
            else:
                current_scale = _get_scale_vec_cached(context, props, orient_str)
                common_factors = []
                for idx in range(3):
                    current_axis = float(current_scale[idx])
                    target_axis = float(target[idx])
                    if abs(current_axis) < 1e-12:
                        if abs(target_axis - current_axis) > 1e-12:
                            valid_native = False
                            break
                        common_factors.append(1.0)
                    else:
                        common_factors.append(target_axis / current_axis)
                if valid_native and _numeric_try_affect_only_scale(
                    context,
                    props,
                    orient_str,
                    common_factors=Vector(tuple(common_factors)),
                ):
                    return

        if len(objs) == 1:
            desired = desired_scale_for_object(objs[0])
            _apply_exact_object_scale_in_space(context, obj, objs[0], orient_str, desired)
            return

        if props.op_mode == 'EACH':
            for o in objs:
                desired = desired_scale_for_object(o)
                _apply_exact_object_scale_in_space(context, obj, o, orient_str, desired)
            return

        cur_vec = _get_scale_vec_cached(context, props, orient_str)
        factors = []
        changed = False
        for idx in range(3):
            cur_axis = float(cur_vec[idx])
            if abs(cur_axis) < 1e-12:
                cur_axis = 1.0
            factor = float(target[idx]) / cur_axis
            if abs(factor - 1.0) > 1e-12:
                changed = True
            factors.append(factor)
        if changed:
            _apply_delta_scale_objects_multi(context, props, orient_str, Vector(tuple(factors)))
    finally:
        _bump_panel_runtime_cache(props)


def _set_scale_axis(context, props, orient_str, axis: int, target_value: float):
    obj = _context_active_object(context)
    if not obj:
        return

    if not _is_number(target_value):
        return

    try:
        # Δ mode
        if props.input_mode == 'DELTA':
            disp = _pref(context, "delta_display_mode", "KNOB")
            style = _pref(context, "delta_scale_style", "FACTOR")
            key = ("_delta_scale_last_x", "_delta_scale_last_y", "_delta_scale_last_z")[axis]

            if style == 'ADD':
                if disp == 'AUTOZERO':
                    delta = float(target_value)
                    props[key] = 0.0
                    factor = 1.0 + delta
                else:
                    last = float(props.get(key, 0.0))
                    cur = float(target_value)
                    delta = cur - last
                    props[key] = cur
                    factor = 1.0 + delta
            else:
                if disp == 'AUTOZERO':
                    factor = float(target_value)
                    props[key] = 1.0
                else:
                    last = float(props.get(key, 1.0))
                    cur = float(target_value)
                    if abs(last) < 1e-12:
                        last = 1.0
                    factor = cur / last
                    props[key] = cur

            if abs(factor - 1.0) > 1e-12:
                if obj.mode == 'EDIT':
                    factors = [1.0, 1.0, 1.0]
                    factors[axis] = factor
                    _apply_delta_scale_edit_selection(context, props, orient_str, tuple(factors))
                elif obj.mode == 'POSE' and obj.type == 'ARMATURE':
                    factors = [1.0, 1.0, 1.0]
                    factors[axis] = factor
                    _apply_delta_scale_pose_bones_multi(context, tuple(factors))
                elif obj.mode == 'OBJECT':
                    _apply_delta_scale_objects(context, props, orient_str, axis, factor)
            return

        # ABS mode
        target_value = float(target_value)

        if obj.mode == 'EDIT':
            key = ("_edit_abs_scale_last_x", "_edit_abs_scale_last_y", "_edit_abs_scale_last_z")[axis]
            last = float(props.get(key, 1.0))
            if abs(last) < 1e-12:
                last = 1.0
            factor = target_value / last
            props[key] = target_value
            if abs(factor - 1.0) > 1e-12:
                factors = [1.0, 1.0, 1.0]
                factors[axis] = factor
                _apply_delta_scale_edit_selection(context, props, orient_str, tuple(factors))
            return

        if obj.mode == 'POSE' and obj.type == 'ARMATURE':
            bones = _selected_pose_bones(context)
            if not bones:
                return
            for pb in bones:
                try:
                    scale = Vector((float(pb.scale.x), float(pb.scale.y), float(pb.scale.z)))
                    if abs(target_value - float(scale[axis])) < 1e-12:
                        continue
                    scale[axis] = target_value
                    pb.scale = scale
                except Exception:
                    pass
            return

        if obj.mode != 'OBJECT':
            return

        objs = _object_mode_transform_targets(context)
        if not objs:
            return

        affect_cu, _affect_state = _numeric_affect_only_state(context)
        if affect_cu is not None:
            valid_native = True
            if len(objs) == 1 or props.op_mode == 'EACH':
                per_object_target_scales = {}
                for o in objs:
                    current_scale = _scale_vec_in_space(context, o, orient_str)
                    target_scale_o = current_scale.copy()
                    target_scale_o[axis] = target_value
                    per_object_target_scales[o] = target_scale_o
                if _numeric_try_affect_only_scale(
                    context,
                    props,
                    orient_str,
                    per_object_target_scales=per_object_target_scales,
                ):
                    return
            else:
                current_scale = _get_scale_vec_cached(context, props, orient_str)
                current_axis = float(current_scale[axis])
                if abs(current_axis) < 1e-12:
                    valid_native = abs(target_value - current_axis) <= 1e-12
                    factor = 1.0
                else:
                    factor = target_value / current_axis
                factors = Vector((1.0, 1.0, 1.0))
                factors[axis] = factor
                if valid_native and _numeric_try_affect_only_scale(
                    context,
                    props,
                    orient_str,
                    common_factors=factors,
                ):
                    return

        if len(objs) == 1:
            desired = _scale_vec_in_space(context, objs[0], orient_str)
            if abs(target_value - float(desired[axis])) < 1e-12:
                return
            desired[axis] = target_value
            _apply_exact_object_scale_in_space(context, obj, objs[0], orient_str, desired)
            return

        if props.op_mode == 'EACH':
            for o in objs:
                desired = _scale_vec_in_space(context, o, orient_str)
                if abs(target_value - float(desired[axis])) < 1e-12:
                    continue
                desired[axis] = target_value
                _apply_exact_object_scale_in_space(context, obj, o, orient_str, desired)
            return

        cur_vec = _get_scale_vec_cached(context, props, orient_str)
        cur_axis = float(cur_vec[axis])
        if abs(cur_axis) < 1e-12:
            cur_axis = 1.0
        factor = target_value / cur_axis
        if abs(factor - 1.0) < 1e-12:
            return

        _apply_delta_scale_objects(context, props, orient_str, axis, factor)
    finally:
        _bump_panel_runtime_cache(props)

# ==============================================================================
# 5. BMesh layers
#  (Bevel / Crease)
# ==============================================================================

_GENERIC_BMESH_ATTRIBUTE_NAMES = {
    ('VERT', 'bevel'): 'bevel_weight_vert',
    ('VERT', 'crease'): 'crease_vert',
    ('EDGE', 'bevel'): 'bevel_weight_edge',
    ('EDGE', 'crease'): 'crease_edge',
}

def _get_bmesh_layers(bm, domain):
    return bm.verts.layers if domain == 'VERT' else bm.edges.layers

def get_bmesh_layer(bm, domain, name, create=False):
    layers = _get_bmesh_layers(bm, domain)

    generic_name = _GENERIC_BMESH_ATTRIBUTE_NAMES.get((domain, name))
    float_layers = getattr(layers, 'float', None)
    if generic_name and float_layers is not None:
        layer = float_layers.get(generic_name)
        if layer is not None:
            return layer
        if create:
            try:
                return float_layers.new(generic_name)
            except Exception:
                return float_layers.get(generic_name)
        return None

    if name == 'bevel':
        legacy_layers = getattr(layers, 'bevel_weight', None)
    elif name == 'crease':
        legacy_layers = getattr(layers, 'crease', None)
    else:
        legacy_layers = None

    if legacy_layers is None:
        return None

    if create and hasattr(legacy_layers, 'verify'):
        return legacy_layers.verify()

    active_layer = getattr(legacy_layers, 'active', None)
    if active_layer is not None:
        return active_layer

    return None

def get_layer_value(context, domain, name):
    targets = _mesh_edit_targets(context)
    if not targets:
        return 0.0

    total_val, count = 0.0, 0
    for obj in targets:
        bm = _from_edit_mesh_safe(obj)
        if bm is None:
            continue
        try:
            items = [v for v in bm.verts if v.select] if domain == 'VERT' else [e for e in bm.edges if e.select]
        except Exception:
            continue
        if not items:
            continue
        try:
            layer = get_bmesh_layer(bm, domain, name, create=False)
        except Exception:
            layer = None
        if layer is None:
            count += len(items)
            continue
        for item in items:
            try:
                total_val += float(item[layer])
                count += 1
            except Exception:
                continue

    return (total_val / count) if count > 0 else 0.0

def set_layer_value(context, domain, name, value):
    if not _is_number(value):
        return

    fvalue = float(value)
    create_layer = abs(fvalue) > 1e-12

    for obj in _mesh_edit_targets(context):
        bm = _from_edit_mesh_safe(obj)
        if bm is None:
            continue
        try:
            items = [v for v in bm.verts if v.select] if domain == 'VERT' else [e for e in bm.edges if e.select]
        except Exception:
            continue
        if not items:
            continue
        try:
            layer = get_bmesh_layer(bm, domain, name, create=create_layer)
        except Exception:
            layer = None
        if layer is None:
            continue
        changed = False
        for item in items:
            try:
                item[layer] = fvalue
                changed = True
            except Exception:
                continue
        if changed:
            try:
                bmesh.update_edit_mesh(obj.data)
            except Exception:
                pass

# ==============================================================================
# 6. Property getters/setters (UI)
# ==============================================================================

def _get_loc(self, axis):
    try:
        ctx = _safe_context()
        if not _smart_transform_panel_context_ready(ctx, require_object=True, require_object_selected=False):
            return 0.0
        orient_str = get_active_orient_str(self)
        return _get_loc_vec_cached(ctx, self, orient_str)[axis]
    except Exception:
        return 0.0

def _set_loc(self, value, axis):
    try:
        if _settings_restore_active():
            return
        ctx = _safe_context()
        obj = _context_active_object(ctx)
        if not (obj and _panel_mode_matches_context(ctx, obj)):
            return
        orient_str = get_active_orient_str(self)
        _set_loc_axis(ctx, self, orient_str, axis, value)
    except Exception:
        return

def get_loc_x(self):
    return _get_loc(self, 0)

def set_loc_x(self, value):
    _set_loc(self, value, 0)

def get_loc_y(self):
    return _get_loc(self, 1)

def set_loc_y(self, value):
    _set_loc(self, value, 1)

def get_loc_z(self):
    return _get_loc(self, 2)

def set_loc_z(self, value):
    _set_loc(self, value, 2)

def _get_rot(self, axis):
    try:
        ctx = _safe_context()
        if not _smart_transform_panel_context_ready(ctx, require_object=True, require_object_selected=False):
            return 0.0
        orient_str = get_active_orient_str(self)
        return _get_rot_vec_cached(ctx, self, orient_str)[axis]
    except Exception:
        return 0.0

def _set_rot(self, value, axis):
    try:
        if _settings_restore_active():
            return
        ctx = _safe_context()
        obj = _context_active_object(ctx)
        if not (obj and _panel_mode_matches_context(ctx, obj)):
            return
        orient_str = get_active_orient_str(self)
        _set_rot_axis(ctx, self, orient_str, axis, value)
    except Exception:
        return

def get_rot_x(self):
    return _get_rot(self, 0)

def set_rot_x(self, value):
    _set_rot(self, value, 0)

def get_rot_y(self):
    return _get_rot(self, 1)

def set_rot_y(self, value):
    _set_rot(self, value, 1)

def get_rot_z(self):
    return _get_rot(self, 2)

def set_rot_z(self, value):
    _set_rot(self, value, 2)

def _get_scale(self, axis):
    try:
        ctx = _safe_context()
        if not _smart_transform_panel_context_ready(ctx, require_object=True, require_object_selected=False):
            return 1.0
        orient_str = get_active_orient_str(self)
        return _get_scale_vec_cached(ctx, self, orient_str)[axis]
    except Exception:
        return 1.0

def _set_scale(self, value, axis):
    try:
        if _settings_restore_active():
            return
        ctx = _safe_context()
        obj = _context_active_object(ctx)
        if not (obj and _panel_mode_matches_context(ctx, obj)):
            return
        orient_str = get_active_orient_str(self)
        linked_axes = _linked_scale_axes_for_axis(ctx, axis)
        if len(linked_axes) > 1:
            target_vec = _scale_target_vector_for_axis(ctx, self, orient_str, axis, value)
            if target_vec is None:
                return
            _set_scale_vector(ctx, self, orient_str, target_vec, target_axes=linked_axes)
            return
        _set_scale_axis(ctx, self, orient_str, axis, value)
    except Exception:
        return

def get_scale_x(self):
    return _get_scale(self, 0)

def set_scale_x(self, value):
    _set_scale(self, value, 0)

def get_scale_y(self):
    return _get_scale(self, 1)

def set_scale_y(self, value):
    _set_scale(self, value, 1)

def get_scale_z(self):
    return _get_scale(self, 2)

def set_scale_z(self, value):
    _set_scale(self, value, 2)

def _get_dim(self, axis):
    ctx = _safe_context()
    obj = _context_active_object(ctx)
    if not obj or not _panel_mode_matches_context(ctx, obj):
        return 0.0
    try:
        if _safe_object_mode(obj) == 'EDIT':
            orient_str = get_active_orient_str(self)
            return float(_edit_selection_dimensions_in_space(ctx, obj, orient_str)[axis])
        if _safe_object_mode(obj) == 'OBJECT':
            return float(obj.dimensions[axis])
    except Exception:
        return 0.0
    return 0.0

def _set_dim(self, value, axis):
    if _settings_restore_active():
        return
    ctx = _safe_context()
    obj = _context_active_object(ctx)
    if not (obj and _panel_mode_matches_context(ctx, obj)) or not _is_number(value):
        return
    if _safe_object_mode(obj) == 'EDIT':
        orient_str = get_active_orient_str(self)
        current = float(_edit_selection_dimensions_in_space(ctx, obj, orient_str)[axis])
        if abs(current) <= 1e-12:
            return
        factor = float(value) / current
        factors = [1.0, 1.0, 1.0]
        factors[axis] = factor
        _apply_delta_scale_edit_selection(ctx, self, orient_str, tuple(factors))
        _bump_panel_runtime_cache(self)
        return
    if _safe_object_mode(obj) != 'OBJECT':
        return
    objs = _object_mode_transform_targets(ctx)
    affect_cu, _affect_state = _numeric_affect_only_state(ctx)
    if affect_cu is not None and objs:
        per_object_factors = {}
        per_object_dimension_targets = {}
        valid_native = True
        for o in objs:
            try:
                dim = float(o.dimensions[axis])
            except Exception:
                valid_native = False
                break
            if abs(dim) <= 1e-12:
                if abs(float(value) - dim) > 1e-12:
                    valid_native = False
                    break
                factor = 1.0
            else:
                factor = float(value) / dim
            factors = Vector((1.0, 1.0, 1.0))
            factors[axis] = factor
            per_object_factors[o] = factors
            per_object_dimension_targets[o] = (int(axis), float(value))
        if valid_native and _numeric_try_affect_only_scale(
            ctx,
            self,
            'LOCAL',
            per_object_factors=per_object_factors,
            per_object_dimension_targets=per_object_dimension_targets,
        ):
            _bump_panel_runtime_cache(self)
            return
    for o in objs:
        try:
            dim = float(o.dimensions[axis])
            if abs(dim) > 1e-12:
                o.scale[axis] *= (float(value) / dim)
        except Exception:
            pass

def get_dim_x(self):
    return _get_dim(self, 0)

def set_dim_x(self, value):
    _set_dim(self, value, 0)

def get_dim_y(self):
    return _get_dim(self, 1)

def set_dim_y(self, value):
    _set_dim(self, value, 1)

def get_dim_z(self):
    return _get_dim(self, 2)

def set_dim_z(self, value):
    _set_dim(self, value, 2)

def get_v_bevel(self):
    try:
        return get_layer_value(_safe_context(), 'VERT', 'bevel')
    except Exception:
        return 0.0

def set_v_bevel(self, value):
    try:
        if _settings_restore_active():
            return
        set_layer_value(_safe_context(), 'VERT', 'bevel', value)
    except Exception:
        return

def get_v_crease(self):
    try:
        return get_layer_value(_safe_context(), 'VERT', 'crease')
    except Exception:
        return 0.0

def set_v_crease(self, value):
    try:
        if _settings_restore_active():
            return
        set_layer_value(_safe_context(), 'VERT', 'crease', value)
    except Exception:
        return

def get_e_bevel(self):
    try:
        return get_layer_value(_safe_context(), 'EDGE', 'bevel')
    except Exception:
        return 0.0

def set_e_bevel(self, value):
    try:
        if _settings_restore_active():
            return
        set_layer_value(_safe_context(), 'EDGE', 'bevel', value)
    except Exception:
        return

def get_e_crease(self):
    try:
        return get_layer_value(_safe_context(), 'EDGE', 'crease')
    except Exception:
        return 0.0

def set_e_crease(self, value):
    try:
        if _settings_restore_active():
            return
        set_layer_value(_safe_context(), 'EDGE', 'crease', value)
    except Exception:
        return

# ==============================================================================
# 7. Operators (Reset / CopyPaste / Apply / Snap)
# ==============================================================================

class SMART_TRANSFORM_OT_reset_value(bpy.types.Operator):
    bl_idname = "core.reset_value"
    bl_label = "Reset Value"
    bl_description = "Reset the current field to its neutral value. Scale returns to 1.0, while location, rotation, and delta offsets return to 0.0. Dimensions return to the length at scale 1.0 (Object Mode only)"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    prop_name: bpy.props.StringProperty(
        name=TI('Property Name', 'プロパティ名'),
        description=TI('Internal property identifier to reset. This is set by the N-panel reset button and is not edited manually.', 'リセット対象の内部プロパティ識別子です。Nパネルのリセットボタンから自動設定され、手動編集はしません。'),
        default='',
        options={'HIDDEN'},
    )

    def execute(self, context):
        props = _scene_core_props(context)
        if props is None:
            return {'CANCELLED'}
        dim_axis = {"dim_x": 0, "dim_y": 1, "dim_z": 2}.get(self.prop_name)
        if dim_axis is not None:
            # A dimension has no neutral value of its own: return to the length
            # at scale 1.0. Writing 0.0 here would collapse the object.
            if context.mode != 'OBJECT':
                self.report({'INFO'}, TI('Dimensions can be reset in Object Mode only.', '寸法を戻せるのはオブジェクトモードだけです。'))
                return {'CANCELLED'}
            # An object with no length on this axis (an Empty, a flat mesh) has
            # nothing to return to, as in the field itself. Scale 0 is still
            # restored because that is what made the length 0.
            objs = [
                o for o in _object_mode_transform_targets(context)
                if abs(float(o.dimensions[dim_axis])) > 1e-12 or abs(float(o.scale[dim_axis])) <= 1e-12
            ]
            if not objs:
                return {'CANCELLED'}
            affect_cu, _affect_state = _numeric_affect_only_state(context)
            if affect_cu is not None:
                per_object_factors = {}
                per_object_dimension_targets = {}
                for o in objs:
                    scale = float(o.scale[dim_axis])
                    if abs(scale) <= 1e-12:
                        continue
                    factors = Vector((1.0, 1.0, 1.0))
                    factors[dim_axis] = 1.0 / scale
                    per_object_factors[o] = factors
                    per_object_dimension_targets[o] = (dim_axis, float(o.dimensions[dim_axis]) / abs(scale))
                if per_object_factors and _numeric_try_affect_only_scale(
                    context,
                    props,
                    'LOCAL',
                    per_object_factors=per_object_factors,
                    per_object_dimension_targets=per_object_dimension_targets,
                ):
                    _bump_panel_runtime_cache(props)
                    return {'FINISHED'}
            for o in objs:
                o.scale[dim_axis] = 1.0
            _bump_panel_runtime_cache(props)
            return {'FINISHED'}
        # In Δ mode, reset should NOT apply an inverse transform.
        if props.input_mode == 'DELTA':
            if self.prop_name == "rot_x":
                props["_delta_rot_last_x"] = 0.0
                _bump_panel_runtime_cache(props)
                return {'FINISHED'}
            if self.prop_name == "rot_y":
                props["_delta_rot_last_y"] = 0.0
                _bump_panel_runtime_cache(props)
                return {'FINISHED'}
            if self.prop_name == "rot_z":
                props["_delta_rot_last_z"] = 0.0
                _bump_panel_runtime_cache(props)
                return {'FINISHED'}
            if self.prop_name in {"scale_x", "scale_y", "scale_z"}:
                neutral = 0.0 if _pref(context, "delta_scale_style", "FACTOR") == 'ADD' else 1.0
                axis_map = {"scale_x": 0, "scale_y": 1, "scale_z": 2}
                reset_axes = _linked_scale_axes_for_axis(context, axis_map.get(self.prop_name, 0))
                for axis in reset_axes:
                    if axis == 0:
                        props["_delta_scale_last_x"] = neutral
                    elif axis == 1:
                        props["_delta_scale_last_y"] = neutral
                    elif axis == 2:
                        props["_delta_scale_last_z"] = neutral
                _bump_panel_runtime_cache(props)
                return {'FINISHED'}

        # ABS mode (or non-delta props)
        if self.prop_name.startswith("scale_"):
            axis_map = {"scale_x": 0, "scale_y": 1, "scale_z": 2}
            axis = axis_map.get(self.prop_name, 0)
            reset_axes = _linked_scale_axes_for_axis(context, axis)
            if len(reset_axes) > 1:
                orient_str = get_active_orient_str(props)
                target_vec = _get_scale_vec_cached(context, props, orient_str)
                target_vec = Vector((float(target_vec[0]), float(target_vec[1]), float(target_vec[2])))
                for idx in reset_axes:
                    if 0 <= idx < 3:
                        target_vec[idx] = 1.0
                _set_scale_vector(context, props, orient_str, target_vec, target_axes=reset_axes)
                _bump_panel_runtime_cache(props)
                return {'FINISHED'}
            setattr(props, self.prop_name, 1.0)
        else:
            setattr(props, self.prop_name, 0.0)
        _bump_panel_runtime_cache(props)
        return {'FINISHED'}

class SMART_TRANSFORM_OT_copy(bpy.types.Operator):
    bl_idname = "core.copy"
    bl_label = "Copy"
    bl_description = "Copy the active object's or active pose bone's transform values into the Smart Transform clipboard"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def execute(self, context):
        wm = context.window_manager
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}

        if obj.mode == 'POSE' and obj.type == 'ARMATURE' and context.active_pose_bone:
            pb = context.active_pose_bone
            wm["_st_clip_kind"] = "POSE_BONE"
            wm["_st_clip_loc"] = [float(pb.location.x), float(pb.location.y), float(pb.location.z)]
            wm["_st_clip_pose_rot_mode"] = pb.rotation_mode
            if pb.rotation_mode == 'QUATERNION':
                q = pb.rotation_quaternion
                wm["_st_clip_rot"] = [float(q.w), float(q.x), float(q.y), float(q.z)]
            elif pb.rotation_mode == 'AXIS_ANGLE':
                aa = pb.rotation_axis_angle
                wm["_st_clip_rot"] = [float(aa[0]), float(aa[1]), float(aa[2]), float(aa[3])]
            else:
                e = pb.rotation_euler
                wm["_st_clip_rot"] = [float(e.x), float(e.y), float(e.z)]
            wm["_st_clip_scale"] = [float(pb.scale.x), float(pb.scale.y), float(pb.scale.z)]
            props = _scene_core_props(context)
            _bump_panel_runtime_cache(props)
            return {'FINISHED'}

        # Object
        mw = obj.matrix_world.copy()
        wm["_st_clip_kind"] = "OBJECT_WORLD"
        wm["_st_clip_matrix_world"] = [[float(v) for v in row] for row in mw]
        loc = mw.translation
        rot = mw.to_quaternion()
        sca = mw.to_scale()
        wm["_st_clip_loc"] = [float(loc.x), float(loc.y), float(loc.z)]
        wm["_st_clip_rot"] = [float(rot.w), float(rot.x), float(rot.y), float(rot.z)]
        wm["_st_clip_scale"] = [float(sca.x), float(sca.y), float(sca.z)]
        props = _scene_core_props(context)
        _bump_panel_runtime_cache(props)
        return {'FINISHED'}

class SMART_TRANSFORM_OT_paste(bpy.types.Operator):
    bl_idname = "core.paste"
    bl_label = "Paste"
    bl_description = "Paste the copied location, rotation, and/or scale to the current selection"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    paste_location: bpy.props.BoolProperty(
        name=TI('Paste Location', '位置を貼り付け'),
        description=TI('Paste the copied object or pose-bone location component to the current selection.', 'コピーしたオブジェクトまたはポーズボーンの位置成分を現在の選択へ貼り付けます。'),
        default=True,
    )
    paste_rotation: bpy.props.BoolProperty(
        name=TI('Paste Rotation', '回転を貼り付け'),
        description=TI('Paste the copied rotation component to the current selection while keeping disabled components unchanged.', 'コピーした回転成分を現在の選択へ貼り付けます。無効な成分は変更しません。'),
        default=True,
    )
    paste_scale: bpy.props.BoolProperty(
        name=TI('Paste Scale', 'スケールを貼り付け'),
        description=TI('Paste the copied scale component to the current selection while keeping disabled components unchanged.', 'コピーしたスケール成分を現在の選択へ貼り付けます。無効な成分は変更しません。'),
        default=True,
    )

    def execute(self, context):
        wm = context.window_manager
        kind = wm.get("_st_clip_kind", "")
        if not kind:
            return {'CANCELLED'}
        if not (self.paste_location or self.paste_rotation or self.paste_scale):
            return {'CANCELLED'}

        obj = context.active_object
        if not obj:
            return {'CANCELLED'}

        if kind == "POSE_BONE" and obj.mode == 'POSE' and obj.type == 'ARMATURE':
            bones = _selected_pose_bones(context)
            if not bones:
                return {'CANCELLED'}

            loc = Vector(wm.get("_st_clip_loc", [0.0, 0.0, 0.0]))
            rot = Vector(wm.get("_st_clip_rot", [0.0, 0.0, 0.0]))
            sca = Vector(wm.get("_st_clip_scale", [1.0, 1.0, 1.0]))

            for pb in bones:
                if self.paste_location:
                    pb.location = loc
                if self.paste_rotation:
                    try:
                        src_mode = wm.get("_st_clip_pose_rot_mode", "XYZ")
                        if src_mode == 'QUATERNION':
                            q = Quaternion((float(rot[0]), float(rot[1]), float(rot[2]), float(rot[3])))
                        elif src_mode == 'AXIS_ANGLE':
                            axis_v = Vector((float(rot[1]), float(rot[2]), float(rot[3])))
                            if axis_v.length < 1e-8:
                                axis_v = Vector((0.0, 0.0, 1.0))
                            axis_v.normalize()
                            q = Quaternion(axis_v, float(rot[0]))
                        else:
                            q = Euler((float(rot.x), float(rot.y), float(rot.z)), str(src_mode)).to_quaternion()

                        if pb.rotation_mode == 'QUATERNION':
                            pb.rotation_quaternion = q
                        elif pb.rotation_mode == 'AXIS_ANGLE':
                            axis2, ang2 = q.to_axis_angle()
                            pb.rotation_axis_angle[0] = float(ang2)
                            pb.rotation_axis_angle[1] = float(axis2.x)
                            pb.rotation_axis_angle[2] = float(axis2.y)
                            pb.rotation_axis_angle[3] = float(axis2.z)
                        else:
                            pb.rotation_euler = q.to_euler(pb.rotation_mode)
                    except Exception:
                        pass
                if self.paste_scale:
                    pb.scale = sca
            props = _scene_core_props(context)
            _bump_panel_runtime_cache(props)
            return {'FINISHED'}

        if kind == "OBJECT_WORLD":
            clip_rows = wm.get("_st_clip_matrix_world", None)
            mw_target = None
            if clip_rows:
                try:
                    mw_target = Matrix([[float(v) for v in row] for row in clip_rows])
                except Exception:
                    mw_target = None

            if mw_target is None:
                loc = Vector(wm.get("_st_clip_loc", [0.0, 0.0, 0.0]))
                rotq = wm.get("_st_clip_rot", [1.0, 0.0, 0.0, 0.0])
                rot = Quaternion((float(rotq[0]), float(rotq[1]), float(rotq[2]), float(rotq[3]))).to_matrix()
                sca = Vector(wm.get("_st_clip_scale", [1.0, 1.0, 1.0]))
                m3 = rot @ Matrix.Diagonal((sca.x, sca.y, sca.z))
                mw_target = Matrix.Translation(loc) @ m3.to_4x4()

            loc_t, rot_t, sca_t = mw_target.decompose()
            source_basis_m4 = mw_target.to_3x3().to_4x4()

            for o in _selected_objects_in_object_mode(context):
                mw_current = o.matrix_world.copy()
                loc_c, rot_c, sca_c = mw_current.decompose()

                if self.paste_rotation and self.paste_scale:
                    if self.paste_location:
                        o.matrix_world = mw_target.copy()
                    else:
                        o.matrix_world = Matrix.Translation(loc_c) @ source_basis_m4.copy()
                    continue

                new_loc = loc_t if self.paste_location else loc_c
                new_rot = rot_t if self.paste_rotation else rot_c
                new_sca = sca_t if self.paste_scale else sca_c
                o.matrix_world = Matrix.LocRotScale(new_loc, new_rot, new_sca)

            props = _scene_core_props(context)
            _bump_panel_runtime_cache(props)
            return {'FINISHED'}

        return {'CANCELLED'}

class SMART_TRANSFORM_OT_apply_rs(bpy.types.Operator):
    bl_idname = "core.apply_rs"
    bl_label = "Apply R/S"
    bl_description = "Apply rotation and scale to the selected objects so the current values become the new default state"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def invoke(self, context, event):
        if context.mode != 'OBJECT':
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        _draw_icon_label(col, bpy.app.translations.pgettext("Apply rotation and scale to the selected objects?"), icon='ERROR')
        col.label(text=bpy.app.translations.pgettext("This cannot be undone safely once you continue working."))

    def execute(self, context):
        if context.mode != 'OBJECT':
            return {'CANCELLED'}
        try:
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            props = _scene_core_props(context)
            _bump_panel_runtime_cache(props)
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}

class SMART_TRANSFORM_OT_apply_all(bpy.types.Operator):
    bl_idname = "core.apply_all"
    bl_label = "Apply All"
    bl_description = "Apply location, rotation, and scale to the selected objects so export and further editing start from clean transform values"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    def invoke(self, context, event):
        if context.mode != 'OBJECT':
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        _draw_icon_label(col, bpy.app.translations.pgettext("Apply location, rotation, and scale to the selected objects?"), icon='ERROR')
        col.label(text=bpy.app.translations.pgettext("This is destructive and can affect export or rig setups."))

    def execute(self, context):
        if context.mode != 'OBJECT':
            return {'CANCELLED'}
        try:
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            props = _scene_core_props(context)
            _bump_panel_runtime_cache(props)
            return {'FINISHED'}
        except Exception:
            return {'CANCELLED'}

class SMART_TRANSFORM_OT_snap(bpy.types.Operator):
    bl_idname = "core.snap"
    bl_label = "Snap"
    bl_description = "Run one of the Smart Transform snap helpers such as moving the selection to the cursor, the active item, or the floor"
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'

    mode: bpy.props.EnumProperty(
        name=TI('Snap Mode', 'スナップモード'),
        description=TI('Choose which Smart Transform snap helper to run from this operator.', 'このオペレーターで実行する Smart Transform のスナップ補助を選択します。'),
        items=[
            ('TO_CURSOR', "To Cursor", "Move the current selection so its pivot goes to the 3D Cursor."),
            ('CURSOR_TO_SEL', "Cursor To Sel", "Move the 3D Cursor to the current selection."),
            ('TO_ACTIVE', "To Active", "Move the selected items so they match the active object or active bone."),
            ('TO_FLOOR', "To Floor (Z=0)", "Move each selected pivot, or the selection median, to world Z = 0."),
        ],
        default='TO_CURSOR'
    )

    def execute(self, context):
        props = _scene_core_props(context)
        if props is None:
            return {'CANCELLED'}

        if self.mode == 'CURSOR_TO_SEL':
            from .. import cursor_lock

            if cursor_lock.is_feature_enabled(context) and cursor_lock.is_lock_enabled(context.scene):
                self.report({'INFO'}, TI('The 3D Cursor is locked.', '3Dカーソルはロックされています。'))
                return {'CANCELLED'}
            # Set 3D cursor to selection median (object/pose/edit)
            obj = context.active_object
            if not obj:
                return {'CANCELLED'}
            if obj.mode == 'EDIT':
                targets = get_edit_targets(context)
                all_pts = []
                for o in targets:
                    all_pts.extend(_edit_selected_points_world_for_obj(context, o))
                context.scene.cursor.location = _median_of_points(all_pts)
                return {'FINISHED'}
            if obj.mode == 'POSE' and obj.type == 'ARMATURE':
                context.scene.cursor.location = _median_pose_bones_world(context)
                return {'FINISHED'}
            context.scene.cursor.location = _median_selected_objects_world(context)
            return {'FINISHED'}

        if self.mode == 'TO_ACTIVE':
            obj = context.active_object
            if not obj:
                return {'CANCELLED'}
            if obj.mode != 'OBJECT':
                return {'CANCELLED'}
            active_loc = obj.matrix_world.translation.copy()
            for o in _selected_objects_in_object_mode(context):
                if o != obj:
                    o.matrix_world.translation = active_loc
            return {'FINISHED'}

        if self.mode == 'TO_FLOOR':
            # Z=0 in GLOBAL
            obj = context.active_object
            if not obj:
                return {'CANCELLED'}
            if obj.mode == 'OBJECT':
                for o in _selected_objects_in_object_mode(context):
                    z = 0.0
                    if props.op_mode == 'MEDIAN':
                        # shift all by diff so median becomes 0
                        med = _median_selected_objects_world(context)
                        diff = _v3(0, 0, z - med.z)
                        for o2 in _selected_objects_in_object_mode(context):
                            o2.matrix_world.translation += diff
                        break
                    else:
                        o.matrix_world.translation.z = z
                return {'FINISHED'}

            if obj.mode == 'POSE' and obj.type == 'ARMATURE':
                bones = _selected_pose_bones(context)
                if not bones:
                    return {'CANCELLED'}
                if props.op_mode == 'MEDIAN':
                    med = _median_pose_bones_world(context)
                    diff_world = _v3(0, 0, -med.z)
                    diff_arm = get_matrix_inv(obj.matrix_world.to_3x3()) @ diff_world
                    for pb in bones:
                        pb.location += diff_arm
                else:
                    for pb in bones:
                        head_world = obj.matrix_world @ pb.head
                        diff_world = _v3(0, 0, -head_world.z)
                        pb.location += get_matrix_inv(obj.matrix_world.to_3x3()) @ diff_world
                return {'FINISHED'}

            if obj.mode == 'EDIT':
                targets = get_edit_targets(context)
                if not targets:
                    return {'CANCELLED'}
                if props.op_mode == 'MEDIAN':
                    all_pts = []
                    for o in targets:
                        all_pts.extend(_edit_selected_points_world_for_obj(context, o))
                    med = _median_of_points(all_pts)
                    diff_world = _v3(0, 0, -med.z)
                    for o in targets:
                        _apply_world_delta_to_edit_selection(context, o, diff_world)
                else:
                    for o in targets:
                        pts = _edit_selected_points_world_for_obj(context, o)
                        if not pts:
                            continue
                        med = _median_of_points(pts)
                        diff_world = _v3(0, 0, -med.z)
                        _apply_world_delta_to_edit_selection(context, o, diff_world)
                return {'FINISHED'}

            return {'CANCELLED'}

        # TO_CURSOR
        cursor_world = context.scene.cursor.location.copy()
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}

        if obj.mode == 'EDIT':
            targets = get_edit_targets(context)
            if not targets:
                return {'CANCELLED'}
            if props.op_mode == 'MEDIAN':
                all_pts = []
                for o in targets:
                    all_pts.extend(_edit_selected_points_world_for_obj(context, o))
                med = _median_of_points(all_pts)
                diff_world = cursor_world - med
                for o in targets:
                    _apply_world_delta_to_edit_selection(context, o, diff_world)
            else:
                for o in targets:
                    pts = _edit_selected_points_world_for_obj(context, o)
                    if not pts:
                        continue
                    med = _median_of_points(pts)
                    diff_world = cursor_world - med
                    _apply_world_delta_to_edit_selection(context, o, diff_world)
            return {'FINISHED'}

        if obj.mode == 'POSE' and obj.type == 'ARMATURE':
            bones = _selected_pose_bones(context)
            if not bones:
                return {'CANCELLED'}
            if props.op_mode == 'MEDIAN':
                med = _median_pose_bones_world(context)
                diff_world = cursor_world - med
                diff_arm = get_matrix_inv(obj.matrix_world.to_3x3()) @ diff_world
                for pb in bones:
                    pb.location += diff_arm
            else:
                for pb in bones:
                    head_world = obj.matrix_world @ pb.head
                    diff_world = cursor_world - head_world
                    pb.location += get_matrix_inv(obj.matrix_world.to_3x3()) @ diff_world
            return {'FINISHED'}

        if obj.mode == 'OBJECT':
            objs = _selected_objects_in_object_mode(context)
            if not objs:
                return {'CANCELLED'}
            if props.op_mode == 'MEDIAN':
                med = _median_selected_objects_world(context)
                diff_world = cursor_world - med
                for o in objs:
                    o.matrix_world.translation += diff_world
            else:
                for o in objs:
                    o.matrix_world.translation = cursor_world
            return {'FINISHED'}

        return {'CANCELLED'}

# ==============================================================================
# 8. Panel UI
# ==============================================================================

class SmartTransformPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID

    use_scene_orientation: bpy.props.BoolProperty(
        name="Use Scene Transform Orientation",
        description="When enabled, the popup always uses the current scene's transform orientation.",
        default=True,
    )

    delta_display_mode: bpy.props.EnumProperty(
        name="Delta Display",
        description="How Δ input fields behave: show last entered value (knob) or auto-reset to neutral after applying.",
        items=[
            ('KNOB', "Knob", "Show last entered value (nudge-style)"),
            ('AUTOZERO', "Auto-Zero", "Always show neutral value and apply input immediately"),
        ],
        default='KNOB',
    )

    delta_scale_style: bpy.props.EnumProperty(
        name="Δ Scale Style",
        description="How Δ scale values are interpreted.",
        items=[
            ('FACTOR', "Factor", "Use multiplicative factor (1.1 = +10%)"),
            ('ADD', "Add Value", "Use additive value (0.1 = +10%, -0.1 = -10%)"),
        ],
        default='FACTOR',
    )

    pose_each_rotation_mode: bpy.props.EnumProperty(
        name="Pose Rotation (Each)",
        description="How rotation behaves in Pose mode when Mode=Each.",
        items=[
            ('CHANNEL', "Channel Box", "Edit bone rotation values (Maya-like, no translation)"),
            ('ORIENT', "Oriented Pivot", "Rotate around bone head using the chosen orientation"),
        ],
        default='CHANNEL',
    )

    keymap_id: bpy.props.StringProperty(
        name="Keymap ID (Copy this)",
        description="ID for keymap registration. Copy this text and use it in the Keymap settings.",
        default="wm.core",
    )

    def draw(self, context):
        del context
        return None

class SmartTransformProps(bpy.types.PropertyGroup):

    popup_orient: bpy.props.EnumProperty(
        name="Orientation",
        description="Choose the coordinate system Smart Transform uses for the values below.",
        items=ORIENT_ITEMS,
        get=_get_orient,
        set=_set_orient,
    )

    op_mode: bpy.props.EnumProperty(
        name="Mode",
        description="Median edits the selection as one group. Each edits every selected item individually.",
        items=OP_MODE_ITEMS,
        get=_get_op_mode,
        set=_set_op_mode,
        default='MEDIAN',
    )

    input_mode: bpy.props.EnumProperty(
        name="Input",
        description="Abs enters final values directly. Δ enters relative changes from the current state.",
        items=INPUT_MODE_ITEMS,
        get=_get_input_mode,
        set=_set_input_mode,
        default='ABS',
    )

    # Paste components
    paste_location: bpy.props.BoolProperty(name="Paste Location", description="Paste the location with the Paste button.", default=True)
    paste_rotation: bpy.props.BoolProperty(name="Paste Rotation", description="Paste the rotation with the Paste button.", default=True)
    paste_scale: bpy.props.BoolProperty(name="Paste Scale", description="Paste the scale with the Paste button.", default=True)

    # Location
    loc_x: bpy.props.FloatProperty(name="X", description="Edit the X location. In Abs mode this becomes the final value; in Δ mode it adds an offset.", precision=5, step=1, unit='LENGTH', get=get_loc_x, set=set_loc_x)
    loc_y: bpy.props.FloatProperty(name="Y", description="Edit the Y location. In Abs mode this becomes the final value; in Δ mode it adds an offset.", precision=5, step=1, unit='LENGTH', get=get_loc_y, set=set_loc_y)
    loc_z: bpy.props.FloatProperty(name="Z", description="Edit the Z location. In Abs mode this becomes the final value; in Δ mode it adds an offset.", precision=5, step=1, unit='LENGTH', get=get_loc_z, set=set_loc_z)

    # Rotation
    rot_x: bpy.props.FloatProperty(name="X", description="Edit the X rotation. In Abs mode this sets the final angle; in Δ mode it adds extra rotation.", subtype='ANGLE', get=get_rot_x, set=set_rot_x)
    rot_y: bpy.props.FloatProperty(name="Y", description="Edit the Y rotation. In Abs mode this sets the final angle; in Δ mode it adds extra rotation.", subtype='ANGLE', get=get_rot_y, set=set_rot_y)
    rot_z: bpy.props.FloatProperty(name="Z", description="Edit the Z rotation. In Abs mode this sets the final angle; in Δ mode it adds extra rotation.", subtype='ANGLE', get=get_rot_z, set=set_rot_z)

    # Scale
    scale_x: bpy.props.FloatProperty(name="X", description="Edit the X scale. In Abs mode this sets the final scale; in Δ mode it applies a relative change.", get=get_scale_x, set=set_scale_x, default=1.0)
    scale_y: bpy.props.FloatProperty(name="Y", description="Edit the Y scale. In Abs mode this sets the final scale; in Δ mode it applies a relative change.", get=get_scale_y, set=set_scale_y, default=1.0)
    scale_z: bpy.props.FloatProperty(name="Z", description="Edit the Z scale. In Abs mode this sets the final scale; in Δ mode it applies a relative change.", get=get_scale_z, set=set_scale_z, default=1.0)

    # Dimensions
    dim_x: bpy.props.FloatProperty(name="X", description="Edit the X dimension in world units.", precision=5, step=1, unit='LENGTH', get=get_dim_x, set=set_dim_x)
    dim_y: bpy.props.FloatProperty(name="Y", description="Edit the Y dimension in world units.", precision=5, step=1, unit='LENGTH', get=get_dim_y, set=set_dim_y)
    dim_z: bpy.props.FloatProperty(name="Z", description="Edit the Z dimension in world units.", precision=5, step=1, unit='LENGTH', get=get_dim_z, set=set_dim_z)

    # Edit layers
    v_bevel: bpy.props.FloatProperty(name="Vertex Bevel Weight", description="Set the bevel weight of the selected vertices.", min=0, max=1, precision=3, get=get_v_bevel, set=set_v_bevel)
    v_crease: bpy.props.FloatProperty(name="Vertex Crease", description="Set the crease amount of the selected vertices.", min=0, max=1, precision=3, get=get_v_crease, set=set_v_crease)
    e_bevel: bpy.props.FloatProperty(name="Edge Bevel Weight", description="Set the bevel weight of the selected edges.", min=0, max=1, precision=3, get=get_e_bevel, set=set_e_bevel)
    e_crease: bpy.props.FloatProperty(name="Edge Crease", description="Set the crease amount of the selected edges.", min=0, max=1, precision=3, get=get_e_crease, set=set_e_crease)

# ==============================================================================
# 9. UI drawing (Popup + standard N-panel)
# ==============================================================================

def draw_reset_prop(col, props, prop_name, text=""):
    row = col.row(align=True)
    if text:
        row.prop(props, prop_name, text=bpy.app.translations.pgettext(text))
    else:
        row.prop(props, prop_name)
    op = _safe_layout_operator(row, "core.reset_value", text="", icon='X', custom_icon='reset')
    _safe_set_operator_property(op, 'prop_name', prop_name, operator_id='core.reset_value')


def draw_scale_reset_prop(col, context, prefs_panel, props, prop_name, text=""):
    axis_map = {"scale_x": 0, "scale_y": 1, "scale_z": 2}
    link_prop_map = {0: "scale_link_x", 1: "scale_link_y", 2: "scale_link_z"}
    axis = axis_map.get(prop_name)

    row = col.row(align=True)
    if text:
        row.prop(props, prop_name, text=bpy.app.translations.pgettext(text))
    else:
        row.prop(props, prop_name)

    if axis is not None and prefs_panel is not None:
        link_prop = link_prop_map.get(axis)
        if link_prop and hasattr(prefs_panel, link_prop):
            try:
                state = bool(getattr(prefs_panel, link_prop, False))
            except Exception:
                state = False
            sub = row.row(align=True)
            try:
                sub.use_property_split = False
                sub.use_property_decorate = False
            except Exception:
                pass
            sub.prop(
                prefs_panel,
                link_prop,
                text="",
                toggle=True,
                icon='CHECKBOX_HLT' if state else 'CHECKBOX_DEHLT',
            )

    op = _safe_layout_operator(row, "core.reset_value", text="", icon='X', custom_icon='reset')
    _safe_set_operator_property(op, 'prop_name', prop_name, operator_id='core.reset_value')


_MODE_NAMES_JA = {
    'OBJECT': 'オブジェクト',
    'EDIT': '編集',
    'POSE': 'ポーズ',
    'SCULPT': 'スカルプト',
    'VERTEX_PAINT': '頂点ペイント',
    'WEIGHT_PAINT': 'ウェイトペイント',
    'TEXTURE_PAINT': 'テクスチャペイント',
    'PARTICLE_EDIT': 'パーティクル編集',
    'EDIT_GPENCIL': 'グリースペンシル編集',
    'SCULPT_GREASE_PENCIL': 'グリースペンシルスカルプト',
    'PAINT_GREASE_PENCIL': 'グリースペンシルペイント',
    'WEIGHT_GREASE_PENCIL': 'グリースペンシルウェイト',
    'VERTEX_GREASE_PENCIL': 'グリースペンシル頂点ペイント',
    'SCULPT_CURVES': 'カーブスカルプト',
}


def _mode_display_name(mode):
    mode = str(mode or '')
    if not mode:
        return TI('Unknown', '不明')
    return TI(mode.replace('_', ' ').title(), _MODE_NAMES_JA.get(mode, '不明'))


def _target_label(context):
    pgettext = bpy.app.translations.pgettext
    obj = _context_active_object(context)
    if not obj:
        return pgettext("No Object")

    obj_mode = _safe_object_mode(obj)
    obj_type = _safe_object_type(obj)
    if obj_mode == 'OBJECT':
        return pgettext("Object")
    if obj_mode == 'POSE':
        return pgettext("Pose Bone")
    if obj_mode == 'EDIT':
        if obj_type == 'MESH':
            try:
                sel_mode = getattr(getattr(_safe_context(context), 'tool_settings', None), 'mesh_select_mode', (True, False, False))
                if sel_mode[2]:
                    return pgettext("Face")
                if sel_mode[1]:
                    return pgettext("Edge")
                if sel_mode[0]:
                    return pgettext("Vertex")
            except Exception:
                pass
            return pgettext("Element")
        return pgettext("Element")

    return pgettext("Object")



def _npanel_fragile_redraw_state(context=None) -> bool:
    """Return True while drawing deep N-panel settings would be unsafe.

    Keep the N-panel visible, but avoid building the full settings tree when
    Blender is immediately after a mode switch or when the active object is not
    selected.  Blender 5.1 can keep a stale active object during
    Select All > Deselect followed by Sculpt/Edit toggles, and visible custom
    panel redraw in that state can stall or crash inside ui_handler_panel.
    """
    try:
        obj = _context_active_object(context)
        if obj is None:
            return False
        if not _panel_mode_matches_context(context, obj):
            return True
        if not _object_selected_safe(obj):
            return True
    except Exception:
        return True
    return False


def _draw_npanel_fragile_notice(layout) -> None:
    if layout is None:
        return
    try:
        box = layout.box()
    except Exception:
        box = layout
    try:
        _draw_icon_label(
            box,
            TI(
                'Settings are temporarily paused while Blender updates the active object or mode.',
                'Blender がアクティブオブジェクトまたはモードを更新中のため、設定表示を一時停止しています。',
            ),
            icon='TIME',
        )
    except Exception:
        pass

def draw_shared_addon_preferences(layout, context, *, show_integrated_core_panel: bool = True, show_always_on_toggles: bool = True):
    pgettext = bpy.app.translations.pgettext
    prefs = _suite_addon_prefs(context)

    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    if prefs is None:
        layout.label(
            text=pgettext("Smart Transform preferences are unavailable because the add-on preferences could not be found."),
            icon='ERROR',
        )
        return

    try:
        from .. import preferences as _suite_preferences
        _suite_preferences.draw_suite_preferences_ui(
            prefs,
            layout,
            context,
            show_integrated_core_panel=show_integrated_core_panel,
            show_always_on_toggles=show_always_on_toggles,
        )
    except Exception:
        layout.label(
            text=pgettext("Smart Transform preferences are unavailable because the add-on preferences could not be found."),
            icon='ERROR',
        )

def _safe_pgettext(text: str) -> str:
    try:
        return bpy.app.translations.pgettext(str(text or ''))
    except Exception:
        return str(text or '')


def _safe_label(layout, text: str, icon: str = 'ERROR') -> None:
    try:
        _draw_icon_label(layout, _safe_pgettext(text), icon=icon)
    except Exception:
        pass


class _SafeMissingOperator:
    def __setattr__(self, _name, _value):
        return None

    def __getattr__(self, _name):
        return None


_SAFE_MISSING_OPERATOR = _SafeMissingOperator()


def _operator_properties_contain(op, prop_name: str) -> bool:
    return _op_safety.operator_proxy_has_property(op, prop_name)


def _safe_set_operator_property(op, prop_name: str, value, *, operator_id: object | None = None) -> bool:
    if op is None or op is _SAFE_MISSING_OPERATOR:
        return False
    return _op_safety.safe_set_operator_property(op, prop_name, value, operator_id=operator_id, strict=True)


def _operator_exists(operator_id: object) -> bool:
    return _op_safety.operator_exists(operator_id)


def _safe_layout_operator(layout, operator_id: object, *, text: str = '', icon: str = 'NONE', custom_icon: str = '', emboss: bool | None = None, depress: bool = False, **props):
    idname = str(operator_id or '').strip()
    clean_props = dict(props)
    clean_props.pop('custom_icon', None)
    icon_only = not str(text or '').strip()
    draw_layout = _operator_button_target(layout, icon_only=icon_only)
    if draw_layout is None:
        return _SAFE_MISSING_OPERATOR
    if emboss is None:
        emboss = True
    elif icon_only and emboss is False:
        emboss = True
    icon_args = _ui_icon_kwargs(icon=icon, operator_id=idname, text=str(text or ''), custom_icon=custom_icon, props=clean_props)
    if not _operator_exists(idname):
        try:
            _draw_icon_label(draw_layout, text or TI('Unavailable', '利用不可'), icon='ERROR')
        except Exception:
            pass
        return _SAFE_MISSING_OPERATOR
    try:
        try:
            op = draw_layout.operator(idname, text=str(text or ''), emboss=bool(emboss), depress=bool(depress), **icon_args)
        except TypeError:
            try:
                op = draw_layout.operator(idname, text=str(text or ''), icon=icon, emboss=bool(emboss), depress=bool(depress))
            except TypeError:
                op = draw_layout.operator(idname, text=str(text or ''), icon=icon)
        for prop_name, prop_value in clean_props.items():
            _safe_set_operator_property(op, prop_name, prop_value, operator_id=idname)
        return op
    except Exception:
        try:
            _draw_icon_label(draw_layout, text or TI('Unavailable', '利用不可'), icon='ERROR')
        except Exception:
            pass
        return _SAFE_MISSING_OPERATOR


def _draw_stable_panel_settings(layout, context) -> None:
    """Draw only stable Smart Transform settings in the N-panel.

    The full Add-on Preferences UI contains enable/disable toggles that can
    register or unregister modules.  Drawing those toggles inside the panel they
    control can invalidate the active Panel during Blender's panel layout pass.
    Keep the standard N-panel limited to ordinary PropertyGroup values and tool
    buttons; full module toggles remain in Blender's Add-on Preferences.
    """
    prefs = _suite_addon_prefs(context)
    if prefs is None:
        return
    stp = None
    try:
        stp = getattr(prefs, 'core_panel', None)
    except Exception:
        stp = None
    if stp is None:
        return

    box = layout.box()
    _draw_icon_label(box, TI('Settings', '設定'), icon='PREFERENCES')
    try:
        box.prop(stp, 'use_scene_orientation', text=TI('Use Scene Transform Orientation', 'シーンの変形方向を使う'))
    except Exception:
        pass
    try:
        box.prop(stp, 'delta_display_mode', text=TI('Δ Display', 'Δ表示'))
    except Exception:
        pass
    try:
        box.prop(stp, 'delta_scale_style', text=TI('Δ Scale', 'Δ拡縮'))
    except Exception:
        pass
    try:
        link_box = box.box()
        link_box.label(text=TI('Scale Link Axes', 'スケールリンク軸'))
        row_link = link_box.row(align=True)
        row_link.prop(stp, 'scale_link_x', toggle=True)
        row_link.prop(stp, 'scale_link_y', toggle=True)
        row_link.prop(stp, 'scale_link_z', toggle=True)
    except Exception:
        pass
    try:
        box.prop(stp, 'pose_each_rotation_mode', text=TI('Pose', 'ポーズ'))
    except Exception:
        pass


def draw_controls_group(layout, context):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    try:
        _draw_stable_panel_settings(layout, context)
    except Exception:
        _safe_label(layout, 'Smart Transform settings are unavailable.')

    box_popup = layout.box()
    _draw_icon_label(box_popup, TI('Transform Popup', 'トランスフォームポップアップ'), icon='WINDOW')
    try:
        _safe_layout_operator(box_popup, 'wm.core', text=TI('Open Popup', 'ポップアップを開く'), icon='WINDOW')
    except Exception:
        pass

    box_transform = layout.box()
    _draw_icon_label(box_transform, TI('Transform', 'トランスフォーム'), icon='CON_TRANSLIKE')
    try:
        draw_panel_layout(box_transform, context)
    except Exception:
        _safe_label(box_transform, 'Smart Transform settings are unavailable.')

def draw_standard_npanel_contents(layout, context):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass

    if not _standard_npanel_context_safe(context):
        return False

    try:
        from .. import preferences as _suite_preferences
    except Exception:
        _suite_preferences = None
    try:
        prefs = _suite_addon_prefs(context)
    except Exception:
        prefs = None

    try:
        if _suite_preferences is not None and prefs is not None:
            _suite_preferences.draw_always_on_toggles_ui(layout, prefs, context)
    except Exception:
        pass

    # Smart Modeling style section: Transform.  This combines the previous
    # Smart Transform information and Controls sections so every control remains
    # visible in object, edit, sculpt, and no-selection states.
    if _suite_preferences is not None and prefs is not None:
        transform_box = _suite_preferences.draw_npanel_section(
            layout,
            prefs,
            'show_section_smart_transform_info',
            TI('Transform', 'トランスフォーム'),
            icon='CON_TRANSLIKE',
            topic_key='core_panel',
            default_open=True,
        )
    else:
        transform_box = layout.box()
        try:
            _draw_icon_label(transform_box, TI('Transform', 'トランスフォーム'), icon='CON_TRANSLIKE')
        except Exception:
            pass

    if transform_box is not None:
        obj = _context_active_object(context)
        info_box = transform_box.box()
        if obj is None:
            _safe_label(info_box, TI('No Active Object', 'アクティブなオブジェクトなし'), icon='OBJECT_DATA')
        else:
            try:
                row = info_box.row(align=True)
                _draw_icon_label(row, f"{TI('Object', 'オブジェクト')}: {obj.name}", icon='OBJECT_DATA')
            except Exception:
                pass
            try:
                mode_text = _mode_display_name(_safe_object_mode(obj))
            except Exception:
                mode_text = TI('Unknown', '不明')
            try:
                _draw_icon_label(info_box, f"{TI('Mode', 'モード')}: {mode_text}", icon='EDITMODE_HLT')
            except Exception:
                pass
            try:
                _draw_icon_label(info_box, f"{TI('Target', '対象')}: {_target_label(context)}", icon='ORIENTATION_GIMBAL')
            except Exception:
                pass
        try:
            draw_controls_group(transform_box, context)
        except Exception:
            _safe_label(transform_box, 'Smart Transform settings are unavailable.')

    try:
        draw_shared_addon_preferences(layout, context, show_integrated_core_panel=False, show_always_on_toggles=False)
    except Exception:
        try:
            prefs_box = layout.box()
            prefs_box.label(
                text=bpy.app.translations.pgettext('Smart Transform preferences are unavailable because the add-on preferences could not be found.'),
                icon='ERROR',
            )
        except Exception:
            pass

    return True

def _safe_unregister_class(cls):
    target = getattr(bpy.types, getattr(cls, "__name__", ""), None)
    if isinstance(target, type):
        try:
            bpy.utils.unregister_class(target)
            return
        except Exception:
            pass
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass

def _scene_core_props(context):
    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    try:
        return getattr(scene, "core_props", None)
    except Exception:
        return None

def _draw_paste_button(layout, props):
    use_loc = bool(props.paste_location)
    use_rot = bool(props.paste_rotation)
    use_sca = bool(props.paste_scale)
    sub = layout.row(align=True)
    sub.enabled = use_loc or use_rot or use_sca
    _safe_layout_operator(
        sub, "core.paste", text="", icon='PASTEDOWN',
        paste_location=use_loc, paste_rotation=use_rot, paste_scale=use_sca,
    )


def _draw_paste_toggles(layout, props):
    row = layout.row(align=True)
    row.use_property_split = False
    row.label(text=TI('Paste', 'ペースト'))
    row.prop(props, "paste_location", text=TI('Location', '位置'), toggle=True)
    row.prop(props, "paste_rotation", text=TI('Rotation', '回転'), toggle=True)
    row.prop(props, "paste_scale", text=TI('Scale', 'スケール'), toggle=True)


def draw_panel_layout(layout, context):
    pgettext = bpy.app.translations.pgettext
    obj = _context_active_object(context)
    props = _scene_core_props(context)
    if props is None:
        _draw_icon_label(layout, pgettext("Smart Transform settings are unavailable."), icon='ERROR')
        return

    try:
        cache = _panel_runtime_cache(props)
        cache['nonce'] = int(cache.get('nonce', 0)) + 1
    except Exception:
        pass

    layout.use_property_split = True
    layout.use_property_decorate = False

    target_row = layout.row(align=True)
    _draw_icon_label(target_row, f"{_target_label(context)} {pgettext('(Median)')}", icon='CON_TRANSLIKE')
    layout.prop(props, "popup_orient", text="")
    row = layout.row(align=True)
    row.prop(props, "op_mode", text="")
    row.prop(props, "input_mode", text="")

    layout.separator(factor=0.4)

    arow = layout.row(align=True)
    try:
        arow.scale_y = 1.35
    except Exception:
        pass
    _safe_layout_operator(arow, "core.copy", text="", icon='COPYDOWN')
    _draw_paste_button(arow, props)
    _safe_layout_operator(arow, "core.apply_rs", text="", icon='CHECKMARK')
    _safe_layout_operator(arow, "core.apply_all", text="", icon='FILE_TICK')
    _safe_layout_operator(arow, "core.snap_to_cursor_button", text="", icon='SNAP_ON')
    _draw_paste_toggles(layout, props)

    layout.separator(factor=0.4)

    col = layout.column(align=True)
    draw_reset_prop(col, props, "loc_x", TI("Loc X", "位置 X"))
    draw_reset_prop(col, props, "loc_y", "Y")
    draw_reset_prop(col, props, "loc_z", "Z")

    prefs_panel = _addon_prefs(context)
    # Always present the Object Mode layout in the N-panel.  The live setter
    # paths below apply changes only when a stable Object Mode target exists.
    obj_mode = 'OBJECT'
    obj_type = _safe_object_type(obj) if obj is not None else ''

    if obj_mode == 'OBJECT':
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "rot_x", TI("Rot X", "回転 X"))
        draw_reset_prop(col, props, "rot_y", "Y")
        draw_reset_prop(col, props, "rot_z", "Z")

        col.separator(factor=0.4)
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_x", "Scale X")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_y", "Y")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_z", "Z")

        col.separator(factor=0.4)
        draw_reset_prop(col, props, "dim_x", "Dim X")
        draw_reset_prop(col, props, "dim_y", "Y")
        draw_reset_prop(col, props, "dim_z", "Z")

    elif obj_mode == 'POSE':
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "rot_x", TI("Rot X", "回転 X"))
        draw_reset_prop(col, props, "rot_y", "Y")
        draw_reset_prop(col, props, "rot_z", "Z")

        col.separator(factor=0.4)
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_x", "Scale X")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_y", "Y")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_z", "Z")

    elif obj_mode == 'EDIT' and obj_type == 'MESH':
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "v_bevel", "V. Bevel")
        draw_reset_prop(col, props, "v_crease", "V. Crease")

        col.separator(factor=0.4)
        draw_reset_prop(col, props, "e_bevel", "E. Bevel")
        draw_reset_prop(col, props, "e_crease", "E. Crease")

    layout.separator(factor=0.2)
    scol = layout.column(align=True)
    srow = scol.row(align=True)
    _safe_layout_operator(srow, "core.snap_to_cursor_button", text=pgettext("To Cursor"), icon='PIVOT_CURSOR')
    _safe_layout_operator(srow, "core.cursor_to_selection_button", text=pgettext("Cursor To Sel"), icon='PIVOT_ACTIVE')
    srow = scol.row(align=True)
    _safe_layout_operator(srow, "core.snap_to_active_button", text=pgettext("To Active"), icon='PIVOT_INDIVIDUAL')
    _safe_layout_operator(srow, "core.snap_to_floor_button", text=pgettext("To Floor (Z=0)"), icon='TRIA_DOWN')


def draw_popup_custom_affordances(layout, context):
    """Restore deliberate Smart Transform controls above native Item fields.

    Popup builds through 1.8.218 exposed the suite's coordinate system,
    Median/Each and Abs/Delta selectors, reset buttons, scale links, clipboard,
    apply and snap helpers.  The later native Item popup remains valuable for
    Blender-owned fields, units and locks, so this restores the lost controls
    without replacing or emulating those native rows.
    """
    pgettext = bpy.app.translations.pgettext
    obj = _context_active_object(context)
    props = _scene_core_props(context)
    if props is None or obj is None or not _panel_mode_matches_context(context, obj):
        return False

    try:
        cache = _panel_runtime_cache(props)
        cache['nonce'] = int(cache.get('nonce', 0)) + 1
    except Exception:
        pass

    custom = layout.box()
    custom.use_property_split = True
    custom.use_property_decorate = False

    target_row = custom.row(align=True)
    _draw_icon_label(target_row, f"{_target_label(context)} {pgettext('(Median)')}", icon='CON_TRANSLIKE')

    selectors = custom.row(align=True)
    selectors.prop(props, "popup_orient", text="")
    selectors.prop(props, "op_mode", text="")
    selectors.prop(props, "input_mode", text="")

    actions = custom.row(align=True)
    try:
        actions.scale_y = 1.25
    except Exception:
        pass
    _safe_layout_operator(actions, "core.copy", text="", icon='COPYDOWN')
    _draw_paste_button(actions, props)
    _safe_layout_operator(actions, "core.apply_rs", text="", icon='CHECKMARK')
    _safe_layout_operator(actions, "core.apply_all", text="", icon='FILE_TICK')
    _safe_layout_operator(actions, "core.snap_to_cursor_button", text="", icon='SNAP_ON')
    _draw_paste_toggles(custom, props)

    col = custom.column(align=True)
    draw_reset_prop(col, props, "loc_x", TI("Loc X", "位置 X"))
    draw_reset_prop(col, props, "loc_y", "Y")
    draw_reset_prop(col, props, "loc_z", "Z")

    prefs_panel = _addon_prefs(context)
    obj_mode = _safe_object_mode(obj)
    obj_type = _safe_object_type(obj)
    if obj_mode == 'OBJECT':
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "rot_x", TI("Rot X", "回転 X"))
        draw_reset_prop(col, props, "rot_y", "Y")
        draw_reset_prop(col, props, "rot_z", "Z")
        col.separator(factor=0.4)
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_x", "Scale X")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_y", "Y")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_z", "Z")
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "dim_x", "Dim X")
        draw_reset_prop(col, props, "dim_y", "Y")
        draw_reset_prop(col, props, "dim_z", "Z")
    elif obj_mode == 'POSE':
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "rot_x", TI("Rot X", "回転 X"))
        draw_reset_prop(col, props, "rot_y", "Y")
        draw_reset_prop(col, props, "rot_z", "Z")
        col.separator(factor=0.4)
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_x", "Scale X")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_y", "Y")
        draw_scale_reset_prop(col, context, prefs_panel, props, "scale_z", "Z")
    elif obj_mode == 'EDIT' and obj_type == 'MESH':
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "v_bevel", "V. Bevel")
        draw_reset_prop(col, props, "v_crease", "V. Crease")
        col.separator(factor=0.4)
        draw_reset_prop(col, props, "e_bevel", "E. Bevel")
        draw_reset_prop(col, props, "e_crease", "E. Crease")

    snaps_primary = custom.row(align=True)
    _safe_layout_operator(snaps_primary, "core.snap_to_cursor_button", text=pgettext("To Cursor"), icon='PIVOT_CURSOR')
    _safe_layout_operator(snaps_primary, "core.cursor_to_selection_button", text=pgettext("Cursor To Sel"), icon='PIVOT_ACTIVE')
    snaps_secondary = custom.row(align=True)
    _safe_layout_operator(snaps_secondary, "core.snap_to_active_button", text=pgettext("To Active"), icon='PIVOT_INDIVIDUAL')
    _safe_layout_operator(snaps_secondary, "core.snap_to_floor_button", text=pgettext("To Floor (Z=0)"), icon='TRIA_DOWN')
    return True

# -----------------------------------------------------------------------------
# Standard Sidebar N-panel
# -----------------------------------------------------------------------------

_STS_PANEL_SOURCE_SPACE = "".join(("VIEW", "_3D"))

def _tag_redraw_area(area):
    if area is None:
        return
    try:
        area.tag_redraw()
        return
    except Exception:
        pass
    for region in getattr(area, 'regions', ()):  # pragma: no cover - Blender runtime
        try:
            region.tag_redraw()
        except Exception:
            pass


class SMART_TRANSFORM_PT_core_suite(bpy.types.Panel):
    def draw_header_preset(self, context):
        op = self.layout.operator('core_suite.show_tool_help', text='', icon='QUESTION')
        op.topic_key = 'smart_transform_root'

    bl_idname = 'SMART_TRANSFORM_PT_core_suite'
    bl_label = TI('Smart Transform', 'Smart Transform')
    bl_space_type = _STS_PANEL_SOURCE_SPACE
    bl_region_type = 'UI'
    bl_category = TI('Smart Transform', 'Smart Transform')
    bl_order = 40

    @classmethod
    def poll(cls, context):
        # Keep the N-panel available even when no object is active.  Per-section
        # draw code performs object/mode validation before touching object data.
        return _standard_npanel_context_safe(context) and _panel_placement_allowed(
            context, "VIEW_3D"
        )

    def draw(self, context):
        try:
            draw_standard_npanel_contents(self.layout, context)
        except Exception:
            _safe_label(self.layout, 'Smart Transform settings are unavailable.')


_PANEL_CLASSES = (
    SMART_TRANSFORM_PT_core_suite,
)


class _SMART_TRANSFORM_OT_snap_wrapper_base(bpy.types.Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Transform Suite'
    fixed_mode = 'TO_CURSOR'

    # Compatibility sink for stale UI/keymap properties from older builds.
    mode: bpy.props.StringProperty(
        name=TI('Compatibility Snap Mode', '互換スナップモード'),
        description=TI('Hidden compatibility value for older saved buttons or keymaps. The visible wrapper button uses its fixed snap mode.', '古い保存済みボタンやキーマップとの互換用の非表示値です。表示中のラッパーボタンは固定スナップモードを使用します。'),
        default='',
        options={'HIDDEN'},
    )

    def execute(self, context):
        del context
        mode = str(getattr(self, 'fixed_mode', '') or 'TO_CURSOR')
        try:
            return bpy.ops.core.snap('EXEC_DEFAULT', mode=mode)
        except Exception:
            return {'CANCELLED'}


class SMART_TRANSFORM_OT_snap_to_cursor_button(_SMART_TRANSFORM_OT_snap_wrapper_base):
    bl_idname = 'core.snap_to_cursor_button'
    bl_label = TI('Snap to Cursor', 'カーソルへスナップ')
    bl_description = TI('Move the current selection so its pivot goes to the 3D Cursor.', '現在の選択を3Dカーソル位置へ移動します。')
    fixed_mode = 'TO_CURSOR'


class SMART_TRANSFORM_OT_cursor_to_selection_button(_SMART_TRANSFORM_OT_snap_wrapper_base):
    bl_idname = 'core.cursor_to_selection_button'
    bl_label = TI('Cursor to Selection', 'カーソルを選択へ')
    bl_description = TI('Move the 3D Cursor to the current selection.', '3Dカーソルを現在の選択位置へ移動します。')
    fixed_mode = 'CURSOR_TO_SEL'


class SMART_TRANSFORM_OT_snap_to_active_button(_SMART_TRANSFORM_OT_snap_wrapper_base):
    bl_idname = 'core.snap_to_active_button'
    bl_label = TI('Snap to Active', 'アクティブへスナップ')
    bl_description = TI('Move the selected items so they match the active object or active bone.', '選択要素をアクティブオブジェクトまたはアクティブボーンへ揃えます。')
    fixed_mode = 'TO_ACTIVE'


class SMART_TRANSFORM_OT_snap_to_floor_button(_SMART_TRANSFORM_OT_snap_wrapper_base):
    bl_idname = 'core.snap_to_floor_button'
    bl_label = TI('Snap to Floor', '床へスナップ')
    bl_description = TI('Move each selected pivot, or the selection median, to world Z = 0.', '選択した各要素の基準点、または選択全体の中点をワールド Z = 0 に移動します。')
    fixed_mode = 'TO_FLOOR'


_STS_POPUP_RNA_COMMON = ('sts_popup_edit_median_location', 'sts_popup_edit_global_space')
_STS_POPUP_RNA_MESH = ('sts_popup_edit_skin_x', 'sts_popup_edit_skin_y',
                       'sts_popup_edit_bevel_vertex', 'sts_popup_edit_crease_vertex',
                       'sts_popup_edit_bevel_edge', 'sts_popup_edit_crease_edge')
_STS_POPUP_RNA_OTHER = ('sts_popup_edit_mean_weight', 'sts_popup_edit_mean_radius',
                        'sts_popup_edit_mean_tilt', 'sts_popup_edit_mean_nurbs_w')


def _sts_popup_data_is_active(owner):
    obj = getattr(bpy.context, 'active_object', None)
    data = getattr(obj, 'data', None)
    return bool(obj is not None and getattr(obj, 'mode', None) == 'EDIT'
                and data is not None and owner.as_pointer() == data.as_pointer())


def _sts_popup_scalar_get(field):
    def get(owner):
        return _item_popup.get_edit_median_scalar(field) if _sts_popup_data_is_active(owner) else 0.0
    return get


def _sts_popup_scalar_set(field):
    def set_value(owner, value):
        if _sts_popup_data_is_active(owner):
            _item_popup.set_edit_median_scalar(field, value)
    return set_value


def _sts_popup_skin_get(axis):
    def get(owner):
        return _item_popup.get_skin_radius(axis) if _sts_popup_data_is_active(owner) else 0.0
    return get


def _sts_popup_skin_set(axis):
    def set_value(owner, value):
        if _sts_popup_data_is_active(owner):
            _item_popup.set_skin_radius(axis, value)
    return set_value


def _sts_popup_rna_types():
    return (bpy.types.Mesh, bpy.types.Curve, bpy.types.Lattice,
            bpy.types.Curves, bpy.types.GreasePencil)


def _unregister_popup_rna():
    for data_type in _sts_popup_rna_types():
        names = _STS_POPUP_RNA_COMMON + (_STS_POPUP_RNA_MESH if data_type is bpy.types.Mesh
                                         else _STS_POPUP_RNA_OTHER)
        for name in names:
            if hasattr(data_type, name):
                delattr(data_type, name)


def _register_popup_rna_impl():
    # RNA lives on the edited ID, not OperatorProperties: Blender's UI Undo
    # requires an undoable owner matching the active data type in Edit Mode.
    for data_type in _sts_popup_rna_types():
        data_type.sts_popup_edit_global_space = bpy.props.BoolProperty(
            name=TI('Global', 'グローバル'),
            description=TI('Use global coordinates; off uses local coordinates',
                           'グローバル座標を使用します。オフではローカル座標を使用します'),
            default=False, options={'SKIP_SAVE'})
        data_type.sts_popup_edit_median_location = bpy.props.FloatVectorProperty(
            name=TI('Location', '位置'), subtype='TRANSLATION', size=3, precision=5,
            get=lambda owner: (_item_popup.get_edit_median_location(owner.sts_popup_edit_global_space)
                               if _sts_popup_data_is_active(owner) else (0.0, 0.0, 0.0)),
            set=lambda owner, value: (_item_popup.set_edit_median_location(
                value, owner.sts_popup_edit_global_space) if _sts_popup_data_is_active(owner) else None))
        if data_type is bpy.types.Mesh:
            for name, axis in (('sts_popup_edit_skin_x', 0), ('sts_popup_edit_skin_y', 1)):
                setattr(data_type, name, bpy.props.FloatProperty(
                    name=TI('Radius X', '半径X') if axis == 0 else TI('Radius Y', '半径Y'),
                    min=0.0, max=100.0, precision=3,
                    get=_sts_popup_skin_get(axis), set=_sts_popup_skin_set(axis)))
            mesh_fields = (('bevel_vertex', 'Bevel Weight', 'ベベルウェイト'),
                           ('crease_vertex', 'Vertex Crease', '頂点クリース'),
                           ('bevel_edge', 'Bevel Weight', 'ベベルウェイト'),
                           ('crease_edge', 'Crease', 'クリース'))
            for field, english, japanese in mesh_fields:
                setattr(data_type, 'sts_popup_edit_' + field, bpy.props.FloatProperty(
                    name=TI(english, japanese), min=0.0, max=1.0,
                    get=_sts_popup_scalar_get(field), set=_sts_popup_scalar_set(field)))
        else:
            other_fields = (('mean_weight', 'weight_softbody', 'Mean Weight', '平均ウェイト'),
                            ('mean_radius', 'radius', 'Mean Radius', '平均半径'),
                            ('mean_tilt', 'tilt', 'Mean Tilt', '平均傾斜'),
                            ('mean_nurbs_w', 'nurbs_w', 'W', 'W'))
            for suffix, field, english, japanese in other_fields:
                options = {'min': 0.0, 'max': 1.0} if suffix == 'mean_weight' else {}
                if suffix == 'mean_radius':
                    options['min'] = 0.0
                elif suffix == 'mean_tilt':
                    options['subtype'] = 'ANGLE'
                elif suffix == 'mean_nurbs_w':
                    options.update(min=0.01, max=100.0)
                options['precision'] = 3
                setattr(data_type, 'sts_popup_edit_' + suffix, bpy.props.FloatProperty(
                    name=TI(english, japanese), get=_sts_popup_scalar_get(field),
                    set=_sts_popup_scalar_set(field), **options))


def _register_popup_rna():
    try:
        _register_popup_rna_impl()
    except Exception:
        _unregister_popup_rna()
        raise


class VIEW3D_PT_sts_transform_popup(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_label = TI('Transform', 'トランスフォーム')
    bl_ui_units_x = 18

    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        return bool(area is not None and getattr(area, 'type', None) == 'VIEW_3D'
                    and getattr(context, 'active_object', None) is not None)

    def draw(self, context):
        header = self.layout.row(align=True)
        _draw_icon_label(header, TI('Transform', 'トランスフォーム'), icon='CON_TRANSLIKE')
        _safe_layout_operator(header, 'core_suite.show_tool_help', text='', icon='QUESTION', topic_key='sts_transform_popup')
        if draw_popup_custom_affordances(self.layout, context):
            self.layout.separator(factor=0.35)
        _item_popup.draw_item_popup(self.layout, context)


class WM_OT_SmartTransformPopup(bpy.types.Operator):
    bl_idname = 'wm.core'
    bl_label = TI('Transform', 'トランスフォーム')
    bl_description = TI(
        'Open the Transform popup so you can edit precise transform values without leaving the current view',
        '現在のビューを離れずに、正確な変形値を編集できるトランスフォームポップアップを開きます。',
    )
    @classmethod
    def poll(cls, context):
        area = getattr(context, 'area', None)
        region = getattr(context, 'region', None)
        return bool(
            area is not None and getattr(area, 'type', None) == 'VIEW_3D'
            and region is not None and getattr(region, 'type', None) in {'WINDOW', 'UI'}
            and getattr(context, 'window_manager', None) is not None
            and getattr(context, 'active_object', None) is not None
        )

    def invoke(self, context, event):
        del event
        return self.execute(context)

    def execute(self, context):
        return bpy.ops.wm.call_panel(
            'EXEC_DEFAULT', name='VIEW3D_PT_sts_transform_popup', keep_open=True)

# ==============================================================================
# Register / Unregister
# ==============================================================================

classes = (
    SmartTransformProps,
    SMART_TRANSFORM_OT_reset_value,
    SMART_TRANSFORM_OT_copy,
    SMART_TRANSFORM_OT_paste,
    SMART_TRANSFORM_OT_apply_rs,
    SMART_TRANSFORM_OT_apply_all,
    SMART_TRANSFORM_OT_snap,
    SMART_TRANSFORM_OT_snap_to_cursor_button,
    SMART_TRANSFORM_OT_cursor_to_selection_button,
    SMART_TRANSFORM_OT_snap_to_active_button,
    SMART_TRANSFORM_OT_snap_to_floor_button,
    WM_OT_SmartTransformPopup,
    VIEW3D_PT_sts_transform_popup,
    SMART_TRANSFORM_PT_core_suite,
)


def _cleanup_current_registration_state():
    """Clear current and legacy Smart Transform classes before standard N-panel registration."""
    legacy_class_names = (
        'PROPERTIES_PT_SmartTransformRoot',
        'PROPERTIES_PT_SmartTransformControls',
        'SMART_TRANSFORM_OT_toggle_properties_pseudo_tab',
        'VIEW3D_PT_core_suite',
    )
    for legacy_name in legacy_class_names:
        legacy_cls = getattr(bpy.types, legacy_name, None)
        if isinstance(legacy_cls, type):
            try:
                bpy.utils.unregister_class(legacy_cls)
            except Exception:
                pass

    try:
        from .. import workspace_cleanup as _workspace_cleanup
        _workspace_cleanup.clean_stale_panel_classes()
        _workspace_cleanup.clean_stale_operator_classes()
    except Exception:
        pass

    for class_name in (getattr(cls, '__name__', '') for cls in classes):
        if not class_name:
            continue
        cls = getattr(bpy.types, class_name, None)
        if cls is None:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    if hasattr(bpy.types.Scene, 'core_props'):
        try:
            del bpy.types.Scene.core_props
        except Exception:
            pass
    _unregister_popup_rna()

def register():
    try:
        bpy.app.translations.register(__name__, translation_dict)
    except ValueError:
        try:
            bpy.app.translations.unregister(__name__)
        except Exception:
            pass
        bpy.app.translations.register(__name__, translation_dict)

    _cleanup_current_registration_state()

    from .. import settings as _settings
    _settings.materialize_persisted_property_updates(
        (SmartTransformProps,), owner_scope='scene'
    )

    for cls in classes:
        bpy.utils.register_class(cls)

    _register_popup_rna()

    bpy.types.Scene.core_props = bpy.props.PointerProperty(
        type=SmartTransformProps,
        name=TI('Smart Transform Panel Settings', 'Smart Transformパネル設定'),
        description=TI('Persistent Smart Transform N-panel values stored on the scene and saved to Blender config/Smart_Transform_Suite/Smart_Transform_Suite.json.', 'シーン上に保持され、Blender設定フォルダーのSmart_Transform_Suite/Smart_Transform_Suite.jsonにも保存されるSmart Transform Nパネル値です。'),
    )


def unregister():

    try:
        _PANEL_RUNTIME_CACHE.clear()
    except Exception:
        pass

    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

    for cls in reversed(classes[1:]):
        _safe_unregister_class(cls)

    _unregister_popup_rna()

    if hasattr(bpy.types.Scene, 'core_props'):
        try:
            del bpy.types.Scene.core_props
        except Exception:
            pass

    _safe_unregister_class(SmartTransformProps)

if __name__ == '__main__':
    register()

# -----------------------------------------------------------------------------
# Toolset integration helpers
# -----------------------------------------------------------------------------
__STS_REGISTERED = False

def ensure_registered(enable: bool = True):
    global __STS_REGISTERED
    if enable and not __STS_REGISTERED:
        try:
            register()
            __STS_REGISTERED = True
        except Exception:
            __STS_REGISTERED = False
            raise
    elif (not enable) and __STS_REGISTERED:
        try:
            unregister()
        finally:
            __STS_REGISTERED = False
