"""Edit membership and region picking in the current Blender view layer."""
import json
import bpy
from bpy_extras import view3d_utils
from mathutils import Vector,geometry

def editable(obj,ctx):
    return obj.type=="MESH" and obj.is_editable and not obj.hide_select and obj.visible_get(view_layer=ctx.view_layer)

def members(ctx):
    return [o for o in ctx.view_layer.objects if o.type=="MESH" and o.mode=="EDIT"]

def choose(ctx,requested,action,remember=True):
    old=members(ctx)
    if not old:raise ValueError("Start in mesh Edit Mode")
    targets={o for o in requested if editable(o,ctx)}
    if not targets:raise ValueError("No editable mesh in that selection")
    before=set(old)
    next_set={"SET":targets,"ISOLATE":targets,"ADD":before|targets,"REMOVE":before-targets,"TOGGLE":before^targets}.get(action)
    if next_set is None:raise ValueError("Unknown edit membership operation")
    if not next_set:raise ValueError("At least one mesh must remain in Edit Mode")
    ordered=[o for o in [*old,*sorted(next_set-before,key=lambda x:x.name)] if o in next_set]
    meshes=set();unique=[]
    for obj in ordered:
        if obj.data not in meshes:
            unique.append(obj);meshes.add(obj.data)
    previous_active=ctx.active_object
    if remember:ctx.window_manager.qme_history_json=json.dumps([o.name for o in old],ensure_ascii=False)
    try:
        bpy.ops.object.mode_set(mode="OBJECT")
        for obj in ctx.view_layer.objects:
            if obj.select_get():obj.select_set(False)
        for obj in unique:obj.select_set(True)
        ctx.view_layer.objects.active=previous_active if previous_active in unique else unique[0]
        bpy.ops.object.mode_set(mode="EDIT")
    except RuntimeError:
        if ctx.mode=="OBJECT":
            for obj in ctx.view_layer.objects:obj.select_set(obj in old)
            ctx.view_layer.objects.active=previous_active
            bpy.ops.object.mode_set(mode="EDIT")
        raise

def restore(ctx):
    names=json.loads(ctx.window_manager.qme_history_json or "[]")
    choose(ctx,[ctx.scene.objects[n] for n in names if ctx.scene.objects.get(n)],"SET")

def collection(op,ctx,action):
    named=bpy.data.collections.get(op.collection_name) if op.collection_name else None
    group=named or getattr(ctx,"collection",None) or ctx.view_layer.active_layer_collection.collection
    if not group:raise ValueError("Choose a mesh collection")
    choose(ctx,group.all_objects,action)

def window_region(ctx):
    if not ctx.area or ctx.area.type!="VIEW_3D":raise ValueError("Use a 3D View")
    return next(r for r in ctx.area.regions if r.type=="WINDOW")

def position(ctx,e):
    region=window_region(ctx)
    x,y=e.mouse_x-region.x,e.mouse_y-region.y
    if not (0<=x<region.width and 0<=y<region.height):return None
    for side in ctx.area.regions:
        if side.type in {"UI","TOOLS"} and side.width>2 and side.x<=e.mouse_x<side.x+side.width and side.y<=e.mouse_y<side.y+side.height:return None
    return Vector((x,y))

def ray(ctx,p):
    region=window_region(ctx);rv=ctx.space_data.region_3d
    origin=view3d_utils.region_2d_to_origin_3d(region,rv,p)
    direction=view3d_utils.region_2d_to_vector_3d(region,rv,p)
    hit,loc,normal,face,evaluated,_=ctx.scene.ray_cast(ctx.evaluated_depsgraph_get(),origin,direction)
    return (evaluated.original,loc,normal) if hit else (None,None,None)

def in_polygon(p,poly):
    inside=False
    for a,b in zip(poly,poly[1:]+[poly[0]]):
        if (a.y>p.y)!=(b.y>p.y) and p.x<((b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x):inside=not inside
    return inside

def region_targets(ctx,trail,box):
    if box:
        a,b=trail[0],trail[-1]
        trail=[a,Vector((b.x,a.y)),b,Vector((a.x,b.y))]
    if len(trail)<3:return []
    region=window_region(ctx);rv=ctx.space_data.region_3d
    selected=[]
    for obj in ctx.view_layer.objects:
        if not editable(obj,ctx):continue
        corners=[obj.matrix_world@Vector(p) for p in obj.bound_box]+[obj.matrix_world.translation]
        projected=[view3d_utils.location_3d_to_region_2d(region,rv,p) for p in corners]
        if any(p is not None and in_polygon(p,trail) for p in projected):selected.append(obj)
    return selected

def action(op,key):
    last=key.split("_")[-1].upper()
    return last if last in {"ADD","REMOVE","TOGGLE","SET","ISOLATE"} else (getattr(op,"action","") or "ADD")

def begin(op,ctx,event,key):
    if not members(ctx):raise ValueError("Start in mesh Edit Mode")
    op._selection_key=key;op._trail=[]
    ctx.window_manager.modal_handler_add(op)
    ctx.workspace.status_text_set("Select a mesh in the 3D View · Esc to cancel")
    return {"RUNNING_MODAL"}

def finish(ctx):ctx.workspace.status_text_set(None)

def modal(op,ctx,event):
    if event.type in {"ESC","RIGHTMOUSE"}:
        finish(ctx);return {"CANCELLED"}
    p=position(ctx,event)
    if p is None:return {"RUNNING_MODAL"}
    key=op._selection_key;gesture="box" in key or "lasso" in key
    if event.type=="LEFTMOUSE" and event.value=="PRESS":
        if gesture:op._trail=[p];return {"RUNNING_MODAL"}
        obj,*_=ray(ctx,p)
        if obj:choose(ctx,[obj],action(op,key));finish(ctx);return {"FINISHED"}
    if gesture and op._trail:
        if event.type=="MOUSEMOVE":op._trail.append(p)
        if event.type=="LEFTMOUSE" and event.value=="RELEASE":
            op._trail.append(p)
            targets=region_targets(ctx,op._trail,"box" in key)
            if targets:choose(ctx,targets,action(op,key))
            finish(ctx);return {"FINISHED"} if targets else {"CANCELLED"}
    return {"RUNNING_MODAL"}
