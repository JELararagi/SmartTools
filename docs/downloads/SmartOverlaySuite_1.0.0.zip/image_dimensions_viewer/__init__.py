# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Image Dimensions Viewer",
    "author": "JELararagi",
    "version": (1, 1, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Overlay",
    "description": "Display image dimensions through the embedded Image Dimensions Viewer section inside the single Smart Overlay N-panel.",
    "category": "User Interface",
}

import bpy
import blf
import gpu
import math
import time
from bpy.app.handlers import persistent
from types import SimpleNamespace
from gpu_extras.batch import batch_for_shader

from .. import registry
from .. import feature_toggle
from .. import icons as sos_icons


def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _icon_kwargs(name: str = '', fallback: str = 'NONE') -> dict:
    try:
        return sos_icons.icon_kwargs(name, fallback)
    except Exception:
        return {'icon': str(fallback or 'NONE')}


# ─────────────────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────────────────

_idv_snapshots = {}
_idv_snapshot_generation = 0
_idv_snapshot_request_serial = 0
_idv_snapshot_timer_pending = False
_idv_snapshot_timer_attempts = 0
_idv_snapshot_due = 0.0
_idv_snapshot_reasons = set()
_IDV_SNAPSHOT_MAX = 48
_IDV_SNAPSHOT_MAX_ATTEMPTS = 4
_IDV_SNAPSHOT_MIN_INTERVAL = 0.05
_idv_boundary_handlers_registered = False


_DEFAULT_SETTINGS = {
    'node_font_size': 12,
    'node_padding': 3,
    'node_corner_radius': 3,
    'node_offset_x': 0,
    'node_offset_y': 25,
    'node_bg_color': (0.0, 0.0, 0.0, 0.6),
    'node_text_color': (1.0, 1.0, 1.0, 1.0),
    'ie_font_size': 12,
    'ie_padding': 5,
    'ie_corner_radius': 5,
    'ie_offset': 5,
    'ie_origin': 'BELOW',
    'ie_bg_color': (0.0, 0.0, 0.0, 0.6),
    'ie_text_color': (1.0, 1.0, 1.0, 1.0),
}


def _idv_localized(context, en: str, ja: str) -> str:
    return registry.localized(en, ja, context)


def _panel_context_safe(context) -> bool:
    try:
        if context is None or getattr(context, 'scene', None) is None:
            return False
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return False
        obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        if mode != 'OBJECT' and obj is None:
            return False
        return obj is not None
    except Exception:
        return False


def _idv_context():
    return getattr(bpy, 'context', None)


def _draw_idv_help_button(layout, topic: str):
    """Draw a Smart Transform style minimum-size QUESTION help button."""
    if layout is None or not str(topic or '').strip():
        return None
    try:
        layout.separator(factor=0.35)
    except Exception:
        pass
    try:
        row = layout.row(align=True)
    except Exception:
        row = layout
    try:
        row.scale_x = 0.82
        row.scale_y = 1.0
        row.operator_context = 'INVOKE_DEFAULT'
    except Exception:
        pass
    try:
        op = row.operator('view3d.sos_tool_help', text='', icon='QUESTION', emboss=True)
    except TypeError:
        try:
            op = row.operator('view3d.sos_tool_help', text='', icon='QUESTION')
        except Exception:
            return None
    except Exception:
        return None
    try:
        op.topic = str(topic)
    except Exception:
        pass
    return op


def _tag_idv_redraw() -> None:
    """Redraw editors affected by Image Dimensions Viewer UI or overlay changes."""
    wm = getattr(getattr(bpy, 'context', None), 'window_manager', None)
    if wm is None:
        return
    for window in getattr(wm, 'windows', ()) or ():
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            if getattr(area, 'type', None) in {'VIEW_3D', 'NODE_EDITOR', 'IMAGE_EDITOR', 'PROPERTIES'}:
                try:
                    area.tag_redraw()
                except Exception:
                    pass


def _settings_update(_self=None, _context=None) -> None:
    """Sync draw handlers and redraw after Image Dimensions setting changes."""
    try:
        _sync_addon_runtime_handlers()
    except Exception:
        pass
    _tag_idv_redraw()
    try:
        from .. import settings
        settings.queue_save(_context)
    except Exception:
        pass


def _fallback_settings():
    return SimpleNamespace(**_DEFAULT_SETTINGS)


def _get_prefs(context=None):
    ctx = context or getattr(bpy, 'context', None)
    scene = getattr(ctx, 'scene', None)
    settings = getattr(scene, 'idv_settings', None) if scene is not None else None
    if settings is not None:
        return settings
    addons = getattr(getattr(getattr(ctx, 'preferences', None), 'addons', None), 'get', None)
    if callable(addons):
        for key in (str(__package__ or '').strip(), str(__name__ or '').strip()):
            if not key:
                continue
            try:
                addon = addons(key)
                prefs = getattr(addon, 'preferences', None) if addon is not None else None
                if prefs is not None:
                    return prefs
            except Exception:
                pass
    return _fallback_settings()



def _idv_ptr(value):
    try:
        return int(value.as_pointer()) if value is not None else 0
    except Exception:
        return 0


def _idv_view_signature(region):
    try:
        v2d = getattr(region, 'view2d', None)
        if v2d is None:
            return None
        width = int(getattr(region, 'width', 0) or 0)
        height = int(getattr(region, 'height', 0) or 0)
        values = []
        for x, y in ((0, 0), (1, 0), (0, 1), (width, height)):
            vx, vy = v2d.region_to_view(int(x), int(y))
            values.extend((round(float(vx), 7), round(float(vy), 7)))
        return tuple(values)
    except Exception:
        return None


def _idv_snapshot_key(kind, context=None):
    ctx = context or getattr(bpy, 'context', None)
    area = getattr(ctx, 'area', None) if ctx is not None else None
    region = getattr(ctx, 'region', None) if ctx is not None else None
    expected = 'NODE_EDITOR' if kind == 'node' else 'IMAGE_EDITOR'
    if getattr(area, 'type', None) != expected or getattr(region, 'type', None) != 'WINDOW':
        return None
    return (
        str(kind),
        _idv_ptr(getattr(ctx, 'window', None)),
        _idv_ptr(area),
        _idv_ptr(region),
        _idv_ptr(getattr(ctx, 'scene', None)),
    )


def _idv_source_signature(kind, context=None):
    ctx = context or getattr(bpy, 'context', None)
    space = getattr(ctx, 'space_data', None) if ctx is not None else None
    scene = getattr(ctx, 'scene', None) if ctx is not None else None
    if kind == 'node':
        tree = getattr(space, 'edit_tree', None) if space is not None else None
        return (
            bool(getattr(scene, 'idv_node_show', False)) if scene is not None else False,
            bool(getattr(getattr(space, 'overlay', None), 'show_overlays', False)) if space is not None else False,
            _idv_ptr(tree),
        )
    image = getattr(space, 'image', None) if space is not None else None
    try:
        size = tuple(int(v) for v in tuple(getattr(image, 'size', (0, 0)))[:2]) if image is not None else (0, 0)
    except Exception:
        size = (0, 0)
    return (
        bool(getattr(scene, 'idv_image_show', False)) if scene is not None else False,
        bool(getattr(getattr(space, 'overlay', None), 'show_overlays', False)) if space is not None else False,
        _idv_ptr(image),
        size,
    )


def _idv_style_signature(kind, context=None):
    prefs = _get_prefs(context)
    if kind == 'node':
        return (
            int(getattr(prefs, 'node_font_size', 12) or 12),
            int(getattr(prefs, 'node_padding', 3) or 0),
            int(getattr(prefs, 'node_corner_radius', 3) or 0),
            int(getattr(prefs, 'node_offset_x', 0) or 0),
            int(getattr(prefs, 'node_offset_y', 25) or 0),
            tuple(float(v) for v in tuple(getattr(prefs, 'node_bg_color', _DEFAULT_SETTINGS['node_bg_color']))),
            tuple(float(v) for v in tuple(getattr(prefs, 'node_text_color', _DEFAULT_SETTINGS['node_text_color']))),
        )
    return (
        int(getattr(prefs, 'ie_font_size', 12) or 12),
        int(getattr(prefs, 'ie_padding', 5) or 0),
        int(getattr(prefs, 'ie_corner_radius', 5) or 0),
        int(getattr(prefs, 'ie_offset', 5) or 0),
        str(getattr(prefs, 'ie_origin', 'BELOW') or 'BELOW'),
        tuple(float(v) for v in tuple(getattr(prefs, 'ie_bg_color', _DEFAULT_SETTINGS['ie_bg_color']))),
        tuple(float(v) for v in tuple(getattr(prefs, 'ie_text_color', _DEFAULT_SETTINGS['ie_text_color']))),
    )


def _idv_rounded_rect_vertices(x, y, w, h, radius):
    radius = max(0.0, min(float(radius), float(w) * 0.5, float(h) * 0.5))
    segments = max(4, int(radius * 2.0))

    def _arc(cx, cy, a0, a1):
        if radius <= 0.0:
            return [(float(cx), float(cy))]
        return [
            (
                float(cx) + math.cos(a0 + (a1 - a0) * i / segments) * radius,
                float(cy) + math.sin(a0 + (a1 - a0) * i / segments) * radius,
            )
            for i in range(segments + 1)
        ]

    outline = (
        _arc(x + radius, y + radius, math.pi, 1.5 * math.pi)
        + _arc(x + w - radius, y + radius, 1.5 * math.pi, 2.0 * math.pi)
        + _arc(x + w - radius, y + h - radius, 0.0, 0.5 * math.pi)
        + _arc(x + radius, y + h - radius, 0.5 * math.pi, math.pi)
    )
    center = (float(x) + float(w) * 0.5, float(y) + float(h) * 0.5)
    triangles = []
    for index, point in enumerate(outline):
        triangles.extend((center, point, outline[(index + 1) % len(outline)]))
    return tuple(triangles)


def _idv_build_label_command(label, rx, ry, font_size, pad, radius, bg, fg):
    font_id = 0
    blf.size(font_id, int(font_size))
    text_width, text_height = blf.dimensions(font_id, str(label))
    box_width = float(text_width) + float(pad) * 2.0
    box_height = float(text_height) + float(pad) * 2.0
    box_x = float(rx)
    box_y = float(ry) - box_height
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(
        shader,
        'TRIS',
        {'pos': _idv_rounded_rect_vertices(box_x, box_y, box_width, box_height, radius)},
    )
    return {
        'batch': batch,
        'shader': shader,
        'color': tuple(float(v) for v in tuple(bg)),
        'text': str(label),
        'text_color': tuple(float(v) for v in tuple(fg)),
        'font_id': int(font_id),
        'font_size': int(font_size),
        'text_position': (float(box_x) + float(pad), float(box_y) + float(pad), 0.0),
    }


def _idv_iter_editor_overrides(kind, context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    expected = 'NODE_EDITOR' if kind == 'node' else 'IMAGE_EDITOR'
    if wm is None:
        return
    for window in tuple(getattr(wm, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) != expected:
                continue
            space = getattr(getattr(area, 'spaces', None), 'active', None)
            for region in tuple(getattr(area, 'regions', ()) or ()):
                if getattr(region, 'type', None) != 'WINDOW':
                    continue
                yield {
                    'window': window,
                    'screen': screen,
                    'area': area,
                    'region': region,
                    'space_data': space,
                }


def _idv_build_node_snapshot(context, generation):
    key = _idv_snapshot_key('node', context)
    if key is None:
        return None
    region = getattr(context, 'region', None)
    space = getattr(context, 'space_data', None)
    scene = getattr(context, 'scene', None)
    commands = []
    enabled = bool(
        scene is not None
        and bool(getattr(scene, 'idv_node_show', False))
        and bool(getattr(getattr(space, 'overlay', None), 'show_overlays', False))
    )
    tree = getattr(space, 'edit_tree', None) if space is not None else None
    if enabled and tree is not None and region is not None:
        prefs = _get_prefs(context)
        zoom = _get_zoom(region.view2d)
        font_size = max(1, round(float(getattr(prefs, 'node_font_size', 12)) * zoom))
        pad = max(0, round(float(getattr(prefs, 'node_padding', 3)) * zoom))
        radius = max(0, round(float(getattr(prefs, 'node_corner_radius', 3)) * zoom))
        offset_x = float(getattr(prefs, 'node_offset_x', 0))
        offset_y = float(getattr(prefs, 'node_offset_y', 25))
        bg = tuple(getattr(prefs, 'node_bg_color', _DEFAULT_SETTINGS['node_bg_color']))
        fg = tuple(getattr(prefs, 'node_text_color', _DEFAULT_SETTINGS['node_text_color']))
        for node in tuple(getattr(tree, 'nodes', ()) or ()):
            try:
                if str(getattr(node, 'type', '') or '') != 'TEX_IMAGE' or bool(getattr(node, 'hide', False)):
                    continue
                image = getattr(node, 'image', None)
                if image is None:
                    continue
                width, height = (int(v) for v in tuple(image.size)[:2])
                if width <= 0 and height <= 0:
                    continue
                location = getattr(node, 'location', None)
                rx, ry = region.view2d.view_to_region(
                    float(location.x) + offset_x,
                    float(location.y) + offset_y,
                    clip=False,
                )
                if rx < -800 or ry < -400 or rx > int(region.width) + 400 or ry > int(region.height) + 400:
                    continue
                commands.append(_idv_build_label_command(
                    f'{width} × {height} px', rx, ry, font_size, pad, radius, bg, fg
                ))
            except (ReferenceError, AttributeError):
                continue
            except Exception:
                continue
    return _idv_finalize_snapshot_record('node', context, generation, commands)


def _idv_build_image_snapshot(context, generation):
    key = _idv_snapshot_key('image', context)
    if key is None:
        return None
    region = getattr(context, 'region', None)
    space = getattr(context, 'space_data', None)
    scene = getattr(context, 'scene', None)
    commands = []
    image = getattr(space, 'image', None) if space is not None else None
    enabled = bool(
        scene is not None
        and bool(getattr(scene, 'idv_image_show', False))
        and bool(getattr(getattr(space, 'overlay', None), 'show_overlays', False))
        and image is not None
    )
    if enabled and region is not None:
        try:
            width, height = (int(v) for v in tuple(image.size)[:2])
        except Exception:
            width, height = 0, 0
        if width > 0 or height > 0:
            prefs = _get_prefs(context)
            font_size = int(getattr(prefs, 'ie_font_size', 12) or 12)
            pad = int(getattr(prefs, 'ie_padding', 5) or 0)
            radius = int(getattr(prefs, 'ie_corner_radius', 5) or 0)
            offset = float(getattr(prefs, 'ie_offset', 5) or 0)
            origin = str(getattr(prefs, 'ie_origin', 'BELOW') or 'BELOW')
            bg = tuple(getattr(prefs, 'ie_bg_color', _DEFAULT_SETTINGS['ie_bg_color']))
            fg = tuple(getattr(prefs, 'ie_text_color', _DEFAULT_SETTINGS['ie_text_color']))
            label = f'{width} × {height} px'
            blf.size(0, font_size)
            text_width, text_height = blf.dimensions(0, label)
            box_width = float(text_width) + float(pad) * 2.0
            box_height = float(text_height) + float(pad) * 2.0
            if origin == 'BELOW':
                center_x, center_y = region.view2d.view_to_region(0.5, 0.0, clip=False)
                box_x = float(center_x) - box_width * 0.5
                box_y = float(center_y) - offset - box_height
            else:
                center_x, center_y = region.view2d.view_to_region(0.5, 1.0, clip=False)
                box_x = float(center_x) - box_width * 0.5
                box_y = float(center_y) + offset
            commands.append(_idv_build_label_command(
                label, box_x, box_y + box_height, font_size, pad, radius, bg, fg
            ))
    return _idv_finalize_snapshot_record('image', context, generation, commands)


def _idv_finalize_snapshot_record(kind, context, generation, commands):
    key = _idv_snapshot_key(kind, context)
    if key is None:
        return None
    region = getattr(context, 'region', None)
    try:
        region_size = (int(region.width), int(region.height))
    except Exception:
        region_size = (0, 0)
    return {
        'key': key,
        'kind': str(kind),
        'generation': int(generation),
        'view_signature': _idv_view_signature(region),
        'region_size': region_size,
        'source_signature': _idv_source_signature(kind, context),
        'style_signature': _idv_style_signature(kind, context),
        'commands': tuple(commands or ()),
        'created_monotonic': float(time.monotonic()),
    }


def _idv_publish_snapshot(record):
    if not isinstance(record, dict) or not record.get('key'):
        return False
    _idv_snapshots[record['key']] = record
    overflow = len(_idv_snapshots) - _IDV_SNAPSHOT_MAX
    if overflow > 0:
        ordered = sorted(
            _idv_snapshots.items(),
            key=lambda item: float(item[1].get('created_monotonic', 0.0)),
        )
        for key, _record in ordered[:overflow]:
            _idv_snapshots.pop(key, None)
    return True


def _idv_rebuild_snapshots():
    global _idv_snapshot_generation
    if not _handlers_required():
        _idv_snapshots.clear()
        return 0
    _idv_snapshot_generation += 1
    generation = int(_idv_snapshot_generation)
    live_keys = set()
    built = 0
    for kind, builder in (('node', _idv_build_node_snapshot), ('image', _idv_build_image_snapshot)):
        for override in tuple(_idv_iter_editor_overrides(kind, getattr(bpy, 'context', None)) or ()):
            try:
                with bpy.context.temp_override(**override):
                    key = _idv_snapshot_key(kind, bpy.context)
                    if key is not None:
                        live_keys.add(key)
                    record = builder(bpy.context, generation)
                    if record is not None and _idv_publish_snapshot(record):
                        built += 1
            except Exception:
                continue
    for key in tuple(_idv_snapshots):
        if key not in live_keys:
            _idv_snapshots.pop(key, None)
    return int(built)


def _idv_reset_snapshot_timer_state():
    global _idv_snapshot_timer_pending, _idv_snapshot_timer_attempts, _idv_snapshot_due
    _idv_snapshot_timer_pending = False
    _idv_snapshot_timer_attempts = 0
    _idv_snapshot_due = 0.0
    _idv_snapshot_reasons.clear()


def _idv_snapshot_rebuild_timer():
    global _idv_snapshot_timer_attempts, _idv_snapshot_due
    if not _handlers_required():
        _idv_snapshots.clear()
        _idv_reset_snapshot_timer_state()
        return None
    now = float(time.monotonic())
    if now < float(_idv_snapshot_due or 0.0):
        return max(0.001, float(_idv_snapshot_due) - now)
    start_serial = int(_idv_snapshot_request_serial)
    _idv_snapshot_timer_attempts += 1
    try:
        built = int(_idv_rebuild_snapshots())
    except Exception:
        built = 0
    changed = int(_idv_snapshot_request_serial) != start_serial
    if (changed or built <= 0) and _idv_snapshot_timer_attempts < _IDV_SNAPSHOT_MAX_ATTEMPTS:
        _idv_snapshot_due = float(time.monotonic()) + _IDV_SNAPSHOT_MIN_INTERVAL
        return _IDV_SNAPSHOT_MIN_INTERVAL
    _idv_reset_snapshot_timer_state()
    _tag_idv_redraw()
    return None


def _schedule_idv_snapshot_rebuild(reason='', immediate=False):
    """Schedule one bounded snapshot build without scanning Blender data."""
    global _idv_snapshot_request_serial, _idv_snapshot_timer_pending
    global _idv_snapshot_timer_attempts, _idv_snapshot_due
    reason_text = str(reason or '')
    if reason_text:
        _idv_snapshot_reasons.add(reason_text)
    now = float(time.monotonic())
    requested_due = now if immediate else now + _IDV_SNAPSHOT_MIN_INTERVAL
    if _idv_snapshot_timer_pending:
        if not reason_text.startswith('draw_'):
            _idv_snapshot_request_serial += 1
        _idv_snapshot_due = min(float(_idv_snapshot_due or requested_due), requested_due)
        return True
    _idv_snapshot_request_serial += 1
    _idv_snapshot_timer_pending = True
    _idv_snapshot_timer_attempts = 0
    _idv_snapshot_due = requested_due
    try:
        bpy.app.timers.register(
            _idv_snapshot_rebuild_timer,
            first_interval=max(0.0, requested_due - now),
        )
        return True
    except Exception:
        _idv_reset_snapshot_timer_state()
        return False


def request_idv_snapshot_rebuild(reason='', context=None, immediate=False):
    """Event-side request; feature ownership is checked before scheduling."""
    if not _handlers_required():
        return False
    return _schedule_idv_snapshot_rebuild(reason, immediate=immediate)


def _request_idv_snapshot_rebuild_from_draw(reason='', immediate=True):
    """Draw-side bounded request with no Scene/RNA collection scan."""
    if not _handles:
        return False
    return _schedule_idv_snapshot_rebuild(reason, immediate=immediate)


def clear_idv_snapshots():
    try:
        if bpy.app.timers.is_registered(_idv_snapshot_rebuild_timer):
            bpy.app.timers.unregister(_idv_snapshot_rebuild_timer)
    except Exception:
        pass
    _idv_reset_snapshot_timer_state()
    _idv_snapshots.clear()


def _idv_snapshot_for_draw(kind, context=None):
    ctx = context or getattr(bpy, 'context', None)
    key = _idv_snapshot_key(kind, ctx)
    record = _idv_snapshots.get(key) if key is not None else None
    region = getattr(ctx, 'region', None) if ctx is not None else None
    try:
        region_size = (int(region.width), int(region.height))
    except Exception:
        region_size = (0, 0)
    stale = (
        not isinstance(record, dict)
        or int(record.get('generation', -1)) != int(_idv_snapshot_generation)
        or tuple(record.get('region_size') or ()) != region_size
        or record.get('view_signature') != _idv_view_signature(region)
        or record.get('source_signature') != _idv_source_signature(kind, ctx)
        or record.get('style_signature') != _idv_style_signature(kind, ctx)
    )
    if stale:
        _request_idv_snapshot_rebuild_from_draw(
            f'draw_{kind}_missing_or_stale', immediate=True
        )
        return None
    return record


def _idv_replay_snapshot(kind, context=None):
    record = _idv_snapshot_for_draw(kind, context)
    if not isinstance(record, dict):
        return None
    for command in tuple(record.get('commands') or ()):
        batch = command.get('batch')
        shader = command.get('shader')
        if batch is None or shader is None:
            raise RuntimeError('Invalid Image Dimensions snapshot command')
        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float('color', command.get('color'))
        batch.draw(shader)
        font_id = int(command.get('font_id', 0) or 0)
        blf.size(font_id, int(command.get('font_size', 12) or 12))
        blf.color(font_id, *tuple(command.get('text_color') or (1.0, 1.0, 1.0, 1.0)))
        blf.position(font_id, *tuple(command.get('text_position') or (0.0, 0.0, 0.0)))
        blf.draw(font_id, str(command.get('text') or ''))
    return None


@persistent
def _idv_snapshot_load_pre(_dummy):
    clear_idv_snapshots()


@persistent
def _idv_snapshot_load_post(_dummy):
    _sync_addon_runtime_handlers()
    if _handlers_required():
        request_idv_snapshot_rebuild('load_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _idv_snapshot_undo_post(_dummy):
    if _handlers_required():
        request_idv_snapshot_rebuild('undo_post', context=getattr(bpy, 'context', None), immediate=True)


@persistent
def _idv_snapshot_redo_post(_dummy):
    _idv_snapshot_undo_post(_dummy)


@persistent
def _idv_snapshot_depsgraph_update(_scene, depsgraph):
    if not _handlers_required():
        return
    relevant = False
    for update in tuple(getattr(depsgraph, 'updates', ()) or ()):
        try:
            identifier = str(
                getattr(getattr(getattr(update, 'id', None), 'bl_rna', None), 'identifier', '') or ''
            )
        except Exception:
            identifier = ''
        if identifier in {'Image', 'NodeTree', 'Scene'}:
            relevant = True
            break
    if relevant:
        request_idv_snapshot_rebuild('depsgraph', context=getattr(bpy, 'context', None), immediate=False)


def _register_idv_boundary_handlers():
    global _idv_boundary_handlers_registered
    if _idv_boundary_handlers_registered:
        return
    for collection, callback in (
        (bpy.app.handlers.load_pre, _idv_snapshot_load_pre),
        (bpy.app.handlers.load_post, _idv_snapshot_load_post),
        (bpy.app.handlers.undo_post, _idv_snapshot_undo_post),
        (bpy.app.handlers.redo_post, _idv_snapshot_redo_post),
        (bpy.app.handlers.depsgraph_update_post, _idv_snapshot_depsgraph_update),
    ):
        if callback not in collection:
            collection.append(callback)
    _idv_boundary_handlers_registered = True


def _unregister_idv_boundary_handlers():
    global _idv_boundary_handlers_registered
    for collection, callback in (
        (bpy.app.handlers.load_pre, _idv_snapshot_load_pre),
        (bpy.app.handlers.load_post, _idv_snapshot_load_post),
        (bpy.app.handlers.undo_post, _idv_snapshot_undo_post),
        (bpy.app.handlers.redo_post, _idv_snapshot_redo_post),
        (bpy.app.handlers.depsgraph_update_post, _idv_snapshot_depsgraph_update),
    ):
        try:
            while callback in collection:
                collection.remove(callback)
        except Exception:
            pass
    _idv_boundary_handlers_registered = False

def _draw_rounded_rect(x, y, w, h, r, color):
    """Filled rounded rectangle via triangle fan."""
    r = min(r, w * 0.5, h * 0.5)
    if r < 0:
        r = 0
    segs = max(4, int(r * 2))
    PI = math.pi

    def _arc(cx, cy, radius, a0, a1, n):
        if n == 0:
            return [(cx + math.cos(a0) * radius, cy + math.sin(a0) * radius)]
        return [
            (cx + math.cos(a0 + (a1 - a0) * i / n) * radius,
             cy + math.sin(a0 + (a1 - a0) * i / n) * radius)
            for i in range(n + 1)
        ]

    outline = (
        _arc(x + r,     y + r,     r, PI,        1.5 * PI, segs) +
        _arc(x + w - r, y + r,     r, 1.5 * PI,  2.0 * PI, segs) +
        _arc(x + w - r, y + h - r, r, 0.0,        0.5 * PI, segs) +
        _arc(x + r,     y + h - r, r, 0.5 * PI,  PI,        segs)
    )

    cx = x + w * 0.5
    cy = y + h * 0.5
    n = len(outline)
    tris = []
    for i in range(n):
        tris += [(cx, cy), outline[i], outline[(i + 1) % n]]

    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": tris})
    _gpu_snapshot = None
    try:
        from .. import mesh as _sos_mesh
        _gpu_snapshot = _sos_mesh._sos_capture_gpu_state_snapshot()
    except Exception:
        _sos_mesh = None
    gpu.state.blend_set('ALPHA')
    try:
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)
    finally:
        try:
            if _sos_mesh is not None:
                _sos_mesh._sos_restore_gpu_state_snapshot(_gpu_snapshot, ui_safe=True)
        except Exception:
            try:
                if isinstance(_gpu_snapshot, dict):
                    for _key, _setter in (
                        ('blend', 'blend_set'),
                        ('depth_mask', 'depth_mask_set'),
                        ('depth_test', 'depth_test_set'),
                        ('line_width', 'line_width_set'),
                        ('scissor', 'scissor_set'),
                        ('scissor_test', 'scissor_test_set'),
                        ('viewport', 'viewport_set'),
                    ):
                        if _key not in _gpu_snapshot:
                            continue
                        _value = _gpu_snapshot[_key]
                        if isinstance(_value, (tuple, list)):
                            getattr(gpu.state, _setter)(*_value)
                        else:
                            getattr(gpu.state, _setter)(_value)
            except Exception:
                pass


def _get_zoom(view2d):
    """Return pixels-per-view-unit for the given View2D.
    We convert two *region* pixels that are 1px apart back to view-space,
    measure the view-unit distance, then invert — immune to pan position."""
    vx0, vy0 = view2d.region_to_view(0, 0)
    vx1, vy1 = view2d.region_to_view(1, 0)
    view_units_per_px = math.hypot(vx1 - vx0, vy1 - vy0)
    if view_units_per_px < 1e-9:
        return 1.0
    return 1.0 / view_units_per_px  # px per view-unit


def _draw_label(label, rx, ry, font_id, font_size, pad, radius, bg, fg):
    """Draw background box + text. (rx, ry) = top-left anchor in screen px."""
    blf.size(font_id, font_size)
    tw, th = blf.dimensions(font_id, label)
    bw = tw + pad * 2
    bh = th + pad * 2
    bx = rx
    by = ry - bh
    _draw_rounded_rect(bx, by, bw, bh, radius, bg)
    blf.color(font_id, *fg)
    blf.position(font_id, bx + pad, by + pad, 0)
    blf.draw(font_id, label)


# ─────────────────────────────────────────────────────────────────────────────
#  Node Editor draw callback
# ─────────────────────────────────────────────────────────────────────────────

def _draw_node_editor():
    ctx = bpy.context
    space = getattr(ctx, 'space_data', None)
    if space is None or space.type != 'NODE_EDITOR':
        return
    if not space.overlay.show_overlays:
        return
    scene = getattr(ctx, 'scene', None)
    if scene is None or not scene.idv_node_show:
        return
    # Use edit_tree so the display updates when entering a node group.
    # edit_tree reflects the currently active (possibly nested) tree,
    # while node_tree always points to the root tree.
    node_tree = space.edit_tree
    if node_tree is None:
        return
    region = ctx.region
    if region is None or region.type != 'WINDOW':
        return

    view2d = region.view2d
    prefs  = _get_prefs()

    # pixels-per-node-unit, pan-independent
    zoom = _get_zoom(view2d)

    # Prefs are in node-units; multiply by zoom → screen pixels.
    s         = zoom
    font_size = max(1, round(prefs.node_font_size * s))
    pad       = max(0, round(prefs.node_padding   * s))
    radius    = max(0, round(prefs.node_corner_radius * s))
    offset_x  = prefs.node_offset_x  # node-units
    offset_y  = prefs.node_offset_y  # node-units

    font_id = 0
    bg = tuple(prefs.node_bg_color)
    fg = tuple(prefs.node_text_color)

    for node in node_tree.nodes:
        if node.type != 'TEX_IMAGE':
            continue
        if node.hide:
            continue
        img = node.image
        if img is None:
            continue
        w_px, h_px = img.size
        if w_px == 0 and h_px == 0:
            continue

        label = f"{w_px} \u00d7 {h_px} px"

        # node.location = top-left in node-space. Apply X/Y offsets (node-units).
        vx = node.location.x + offset_x
        vy = node.location.y + offset_y
        rx, ry = view2d.view_to_region(vx, vy, clip=False)

        # Cull nodes far off-screen
        if rx < -800 or ry < -400 or rx > region.width + 400 or ry > region.height + 400:
            continue

        _draw_label(label, rx, ry, font_id, font_size, pad, radius, bg, fg)


# ─────────────────────────────────────────────────────────────────────────────
#  Image Editor draw callback
# ─────────────────────────────────────────────────────────────────────────────

def _draw_image_editor():
    ctx = bpy.context
    space = getattr(ctx, 'space_data', None)
    if space is None or space.type != 'IMAGE_EDITOR':
        return
    if not space.overlay.show_overlays:
        return
    scene = getattr(ctx, 'scene', None)
    if scene is None or not scene.idv_image_show:
        return
    img = space.image
    if img is None:
        return
    w_px, h_px = img.size
    if w_px == 0 and h_px == 0:
        return
    region = ctx.region
    if region is None or region.type != 'WINDOW':
        return

    view2d = region.view2d
    prefs  = _get_prefs()

    # Image Editor: fixed screen pixels, no zoom scaling
    font_id   = 0
    font_size = prefs.ie_font_size
    pad       = prefs.ie_padding
    radius    = prefs.ie_corner_radius
    offset    = prefs.ie_offset
    origin    = prefs.ie_origin  # 'BELOW' or 'ABOVE'
    bg        = tuple(prefs.ie_bg_color)
    fg        = tuple(prefs.ie_text_color)

    label = f"{w_px} × {h_px} px"

    blf.size(font_id, font_size)
    tw, th = blf.dimensions(font_id, label)
    bw = tw + pad * 2
    bh = th + pad * 2

    # Image spans UV [0,1]x[0,1].
    # BELOW: anchor centred just below the bottom edge (UV y=0).
    # ABOVE: anchor centred just above the top edge (UV y=1).
    if origin == 'BELOW':
        cx_px, cy_px = view2d.view_to_region(0.5, 0.0, clip=False)
        bx = cx_px - bw * 0.5
        by = cy_px - offset - bh
    else:  # ABOVE
        cx_px, cy_px = view2d.view_to_region(0.5, 1.0, clip=False)
        bx = cx_px - bw * 0.5
        by = cy_px + offset

    _draw_rounded_rect(bx, by, bw, bh, radius, bg)
    blf.color(font_id, *fg)
    blf.position(font_id, bx + pad, by + pad, 0)
    blf.draw(font_id, label)


# ─────────────────────────────────────────────────────────────────────────────
#  Smart Overlay settings storage / embedded section source
# ─────────────────────────────────────────────────────────────────────────────

class ImageDimensionsSettings(bpy.types.PropertyGroup):
    # ── Node Editor (values in node-units, scaled by zoom at draw time) ──────
    node_font_size: bpy.props.IntProperty(
        name="Font Size", default=12, min=1, max=500,
        description="Label font size in node-units. The on-screen text scales together with the current node-editor zoom level.",
        update=_settings_update,
    )
    node_padding: bpy.props.IntProperty(
        name="Padding", default=3, min=0, max=500,
        description="Inner padding of the node-editor label box in node-units. Increase this to create more space between the text and the background box edge.",
        update=_settings_update,
    )
    node_corner_radius: bpy.props.IntProperty(
        name="Corner Radius", default=3, min=0, max=500,
        description="Corner radius of the node-editor label box in node-units. Higher values make the label background rounder.",
        update=_settings_update,
    )
    node_offset_x: bpy.props.IntProperty(
        name="X Offset", default=0, min=-500, max=500,
        description="Horizontal offset from the node top-left corner in node-units. Use this when the label overlaps the node frame or sockets.",
        update=_settings_update,
    )
    node_offset_y: bpy.props.IntProperty(
        name="Y Offset", default=25, min=-500, max=500,
        description="Vertical offset from the node top-left corner in node-units. Positive values move the label upward relative to the node anchor.",
        update=_settings_update,
    )
    node_bg_color: bpy.props.FloatVectorProperty(
        name="Background Color", subtype='COLOR_GAMMA', size=4,
        default=(0.0, 0.0, 0.0, 0.6), min=0.0, max=1.0,
        description="Background color of the node-editor label box.",
        update=_settings_update,
    )
    node_text_color: bpy.props.FloatVectorProperty(
        name="Text Color", subtype='COLOR_GAMMA', size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        description="Text color of the node-editor label.",
        update=_settings_update,
    )

    # ── Image Editor (fixed screen pixels) ───────────────────────────────────
    ie_font_size: bpy.props.IntProperty(
        name="Font Size", default=12, min=1, max=500,
        description="Label font size in screen pixels for the Image Editor. This size stays fixed and does not scale with image zoom.",
        update=_settings_update,
    )
    ie_padding: bpy.props.IntProperty(
        name="Padding", default=5, min=0, max=500,
        description="Inner padding of the image-editor label box in screen pixels.",
        update=_settings_update,
    )
    ie_corner_radius: bpy.props.IntProperty(
        name="Corner Radius", default=5, min=0, max=500,
        description="Corner radius of the image-editor label box in screen pixels.",
        update=_settings_update,
    )
    ie_offset: bpy.props.IntProperty(
        name="Offset", default=5, min=-1000, max=1000,
        description="Gap in screen pixels between the image edge and the label box. Increase this if the label touches the image border.",
        update=_settings_update,
    )
    ie_origin: bpy.props.EnumProperty(
        name="Origin",
        description="Choose whether the image-editor label is placed below or above the visible image area.",
        items=[
            ('BELOW', 'Below', 'Place the label below the bottom edge of the image.'),
            ('ABOVE', 'Above', 'Place the label above the top edge of the image.'),
        ],
        default='BELOW',
        update=_settings_update,
    )
    ie_bg_color: bpy.props.FloatVectorProperty(
        name="Background Color", subtype='COLOR_GAMMA', size=4,
        default=(0.0, 0.0, 0.0, 0.6), min=0.0, max=1.0,
        description="Background color of the image-editor label box.",
        update=_settings_update,
    )
    ie_text_color: bpy.props.FloatVectorProperty(
        name="Text Color", subtype='COLOR_GAMMA', size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        description="Text color of the image-editor label.",
        update=_settings_update,
    )



# ─────────────────────────────────────────────────────────────────────────────
#  Smart Overlay Image Dimensions Viewer UI
# ─────────────────────────────────────────────────────────────────────────────

_IDV_UI_GROUP_OPEN = {
    'tool': True,
    'node': True,
    'node_appearance': True,
    'node_position': True,
    'node_color': True,
    'image': True,
    'image_appearance': True,
    'image_position': True,
    'image_color': True,
}

_IDV_GROUP_LABELS = {
    'tool': ('Image Dimensions Viewer', '画像サイズビューアー'),
    'node': ('Node Editor Overlay', 'ノードエディター'),
    'node_appearance': ('Node Appearance', 'ノード外観'),
    'node_position': ('Node Position', 'ノード位置'),
    'node_color': ('Node Colors', 'ノードカラー'),
    'image': ('Image Editor Overlay', '画像エディター'),
    'image_appearance': ('Image Appearance', '画像外観'),
    'image_position': ('Image Position', '画像位置'),
    'image_color': ('Image Colors', '画像カラー'),
}


def _idv_layout_flags(layout):
    try:
        layout.use_property_split = False
        layout.use_property_decorate = False
    except Exception:
        pass
    return layout


def _idv_group_open(key: str, default: bool = True) -> bool:
    text = str(key or '').strip()
    if not text:
        return bool(default)
    return bool(_IDV_UI_GROUP_OPEN.get(text, default))


def _idv_set_group_open(key: str, value: bool) -> None:
    text = str(key or '').strip()
    if text:
        _IDV_UI_GROUP_OPEN[text] = bool(value)
        try:
            from .. import settings as _sos_settings
            _sos_settings.queue_save(getattr(bpy, 'context', None), reason='idv_group_open')
        except Exception:
            pass


def get_ui_state() -> dict:
    return {'groups': dict(_IDV_UI_GROUP_OPEN)}


def apply_ui_state(data) -> None:
    if not isinstance(data, dict):
        return
    groups = data.get('groups')
    if isinstance(groups, dict):
        for key, value in groups.items():
            text = str(key or '').strip()
            if text:
                _IDV_UI_GROUP_OPEN[text] = bool(value)


def _idv_label(context, key: str, fallback_en: str = '', fallback_ja: str = '') -> str:
    en, ja = _IDV_GROUP_LABELS.get(str(key or ''), (fallback_en, fallback_ja or fallback_en))
    return _idv_localized(context, en, ja)


def _idv_panel_id(key: str) -> str:
    text = ''.join(ch if (ch.isalnum() or ch == '_') else '_' for ch in str(key or '').strip())
    return 'sos_idv_' + (text or 'section')


def _idv_fold_header(layout, context, key: str, label_en: str, label_ja: str, *, icon: str = 'NONE', help_topic: str = '', label_text: str = ''):
    """Return the body of a Blender-native collapsible panel, or None when closed."""
    try:
        header, body = layout.panel(
            _idv_panel_id(key),
            default_closed=not _idv_group_open(key, True),
        )
    except Exception:
        return None

    _idv_layout_flags(header)
    display_label = str(label_text or _idv_localized(context, label_en, label_ja))
    try:
        header.label(text=display_label, icon=str(icon or 'NONE') or 'NONE')
    except TypeError:
        try:
            header.label(text=display_label)
        except Exception:
            pass
    except Exception:
        pass
    if help_topic:
        _draw_idv_help_button(header, help_topic)
    if body is not None:
        _idv_layout_flags(body)
    return body

def _idv_prop(layout, owner, prop_name: str, label_en: str, label_ja: str = ''):
    if layout is None or owner is None or not str(prop_name or '').strip():
        return None
    try:
        return layout.prop(owner, str(prop_name), text=_idv_localized(_idv_context(), label_en, label_ja or label_en))
    except Exception:
        return None


def _idv_scene_prop(layout, scene, prop_name: str, label_en: str, label_ja: str = ''):
    if layout is None or scene is None or not str(prop_name or '').strip():
        return None
    if not hasattr(scene, prop_name):
        return None
    try:
        return layout.prop(scene, str(prop_name), text=_idv_localized(_idv_context(), label_en, label_ja or label_en), toggle=True)
    except TypeError:
        try:
            return layout.prop(scene, str(prop_name), text=_idv_localized(_idv_context(), label_en, label_ja or label_en))
        except Exception:
            return None
    except Exception:
        return None


def _idv_notice(layout, context, en: str, ja: str, *, icon: str = 'INFO') -> None:
    try:
        row = _idv_layout_flags(layout.row(align=True))
        row.label(text=_idv_localized(context, en, ja), icon=icon)
    except Exception:
        pass


def _draw_idv_node_group(layout, context, settings, scene) -> None:
    body = _idv_fold_header(
        layout,
        context,
        'node',
        'Node Editor Overlay',
        'ノードエディター',
        icon='NODETREE',
        help_topic='image_dimensions_node_editor',
    )
    if body is None:
        return

    _idv_scene_prop(body, scene, 'idv_node_show', 'Enable Node Editor Overlay', 'ノードエディター表示を有効化')

    appearance = _idv_fold_header(body, context, 'node_appearance', 'Appearance', '外観', icon='FONT_DATA')
    if appearance is not None:
        _idv_prop(appearance, settings, 'node_font_size', 'Font Size', 'フォントサイズ')
        _idv_prop(appearance, settings, 'node_padding', 'Padding', '余白')
        _idv_prop(appearance, settings, 'node_corner_radius', 'Corner Radius', '角丸')

    position = _idv_fold_header(body, context, 'node_position', 'Position', '位置', icon='EMPTY_ARROWS')
    if position is not None:
        _idv_prop(position, settings, 'node_offset_x', 'X Offset', 'Xオフセット')
        _idv_prop(position, settings, 'node_offset_y', 'Y Offset', 'Yオフセット')

    colors = _idv_fold_header(body, context, 'node_color', 'Colors', 'カラー', icon='COLOR')
    if colors is not None:
        _idv_prop(colors, settings, 'node_bg_color', 'Background Color', '背景色')
        _idv_prop(colors, settings, 'node_text_color', 'Text Color', '文字色')


def _draw_idv_image_group(layout, context, settings, scene) -> None:
    body = _idv_fold_header(
        layout,
        context,
        'image',
        'Image Editor Overlay',
        '画像エディター',
        icon='IMAGE',
        help_topic='image_dimensions_image_editor',
    )
    if body is None:
        return

    _idv_scene_prop(body, scene, 'idv_image_show', 'Enable Image Editor Overlay', '画像エディター表示を有効化')

    appearance = _idv_fold_header(body, context, 'image_appearance', 'Appearance', '外観', icon='FONT_DATA')
    if appearance is not None:
        _idv_prop(appearance, settings, 'ie_font_size', 'Font Size', 'フォントサイズ')
        _idv_prop(appearance, settings, 'ie_padding', 'Padding', '余白')
        _idv_prop(appearance, settings, 'ie_corner_radius', 'Corner Radius', '角丸')

    position = _idv_fold_header(body, context, 'image_position', 'Position', '位置', icon='EMPTY_ARROWS')
    if position is not None:
        _idv_prop(position, settings, 'ie_offset', 'Offset', 'オフセット')
        _idv_prop(position, settings, 'ie_origin', 'Origin', '表示位置')

    colors = _idv_fold_header(body, context, 'image_color', 'Colors', 'カラー', icon='COLOR')
    if colors is not None:
        _idv_prop(colors, settings, 'ie_bg_color', 'Background Color', '背景色')
        _idv_prop(colors, settings, 'ie_text_color', 'Text Color', '文字色')


def draw_smart_overlay_ui(layout, context) -> bool:
    """Draw the Image Dimensions Viewer item UI from a clean, flat structure."""
    if layout is None:
        return False
    scene = getattr(context, 'scene', None)
    settings = getattr(scene, 'idv_settings', None) if scene is not None else None
    if settings is None:
        _idv_notice(
            layout,
            context,
            'Image Dimensions Viewer settings are not available. Re-enable Smart Overlay if this line remains visible.',
            '画像サイズビューアーの設定を読めません。この表示が残る場合は Smart Overlay を有効にし直してください。',
            icon='ERROR',
        )
        return True

    base = _idv_layout_flags(layout)
    _draw_idv_node_group(base, context, settings, scene)
    _draw_idv_image_group(base, context, settings, scene)
    return True


def draw_rebuilt_settings_ui(layout, context, *, include_tool_header: bool = False) -> bool:
    """Compatibility entry point used by older Smart Overlay builds."""
    if layout is None:
        return False
    if include_tool_header:
        return draw_smart_overlay_tool_ui(layout, context)
    return draw_smart_overlay_ui(layout, context)


def draw_smart_overlay_tool_ui(layout, context) -> bool:
    """Draw the complete Image Dimensions Viewer group inside Smart Overlay."""
    if layout is None:
        return False

    outer = _idv_layout_flags(layout)
    try:
        label = registry.tool_label('image_dimensions_viewer', context)
    except Exception:
        label = _idv_localized(context, 'Image Dimensions Viewer', '画像サイズビューアー')
    body = _idv_fold_header(
        outer,
        context,
        'tool',
        'Image Dimensions Viewer',
        '画像サイズビューアー',
        icon='IMAGE',
        help_topic='image_dimensions_viewer',
        label_text=label,
    )
    if body is None:
        return True
    return draw_smart_overlay_ui(body, context)


class IDV_OT_toggle_ui_group(bpy.types.Operator):
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = 'view3d.sos_idv_toggle_ui_group'
    bl_label = 'Toggle Image Dimensions Viewer UI Group'
    bl_description = 'Open or close this Image Dimensions Viewer UI group.'

    group_key: bpy.props.StringProperty(
        name='Group Key',
        description='Internal Image Dimensions Viewer UI group key.',
        default='',
        options={'SKIP_SAVE', 'HIDDEN'},
    )

    @classmethod
    def description(cls, context, properties):
        try:
            key = str(getattr(properties, 'group_key', '') or '')
            en, ja = _IDV_GROUP_LABELS.get(key, ('Image Dimensions Viewer UI group', '画像サイズビューアーUIグループ'))
            return _idv_localized(
                context,
                f'Open or close the {en} settings group.',
                f'{ja}設定グループを開閉します。',
            )
        except Exception:
            return cls.bl_description

    def execute(self, context):
        key = str(getattr(self, 'group_key', '') or '').strip()
        if not key:
            return {'CANCELLED'}
        _idv_set_group_open(key, not _idv_group_open(key, True))
        _tag_idv_redraw()
        return {'FINISHED'}


class VIEW3D_PT_idv_settings(bpy.types.Panel):
    bl_label = 'Image Dimensions Viewer'
    bl_idname = 'VIEW3D_PT_idv_settings'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Overlay'
    bl_order = 110

    @classmethod
    def poll(cls, context):
        return _panel_context_safe(context)

    def draw_embedded(self, context):
        draw_smart_overlay_tool_ui(self.layout, context)

    def draw(self, context):
        draw_smart_overlay_tool_ui(self.layout, context)


# ─────────────────────────────────────────────────────────────────────────────
#  Handler management
# ─────────────────────────────────────────────────────────────────────────────

_handles = {}



def _idv_push_gpu_state_restore():
    try:
        from .. import mesh as _sos_mesh
        push = getattr(_sos_mesh, '_sos_push_gpu_state_restore', None)
        if callable(push):
            return _sos_mesh, push()
    except Exception:
        pass
    return None, None


def _idv_reset_ui_gpu_state_after_draw(_sos_mesh=None, _gpu_snapshot=None) -> None:
    try:
        if _sos_mesh is not None:
            pop = getattr(_sos_mesh, '_sos_pop_gpu_state_restore', None)
            if callable(pop):
                pop(_gpu_snapshot, ui_safe=True)
                return
    except Exception:
        pass
    try:
        if _sos_mesh is not None:
            restore = getattr(_sos_mesh, '_sos_restore_gpu_state_snapshot', None)
            if callable(restore):
                restore(_gpu_snapshot, ui_safe=True)
                return
    except Exception:
        pass
    try:
        import blf
        for _flag_name in ('SHADOW', 'ROTATION', 'CLIPPING', 'WORD_WRAP'):
            try:
                _flag = getattr(blf, _flag_name, None)
                if _flag is not None:
                    blf.disable(0, _flag)
            except Exception:
                pass
    except Exception:
        pass


def _draw_node_editor_safe():
    """Replay the completed Node Editor snapshot only."""
    _sos_mesh, _gpu_snapshot = _idv_push_gpu_state_restore()
    _sos_clip_token = None
    try:
        try:
            if _sos_mesh is not None:
                _sos_clip_token = _sos_mesh._sos_begin_post_pixel_ui_region_clip(bpy.context)
        except Exception:
            _sos_clip_token = None
        try:
            return _idv_replay_snapshot('node', bpy.context)
        except Exception:
            _request_idv_snapshot_rebuild_from_draw('draw_node_exception', immediate=True)
            return None
    finally:
        try:
            if _sos_mesh is not None:
                _sos_mesh._sos_end_post_pixel_ui_region_clip(_sos_clip_token)
        except Exception:
            pass
        _idv_reset_ui_gpu_state_after_draw(_sos_mesh, _gpu_snapshot)


def _draw_image_editor_safe():
    """Replay the completed Image Editor snapshot only."""
    _sos_mesh, _gpu_snapshot = _idv_push_gpu_state_restore()
    _sos_clip_token = None
    try:
        try:
            if _sos_mesh is not None:
                _sos_clip_token = _sos_mesh._sos_begin_post_pixel_ui_region_clip(bpy.context)
        except Exception:
            _sos_clip_token = None
        try:
            return _idv_replay_snapshot('image', bpy.context)
        except Exception:
            _request_idv_snapshot_rebuild_from_draw('draw_image_exception', immediate=True)
            return None
    finally:
        try:
            if _sos_mesh is not None:
                _sos_mesh._sos_end_post_pixel_ui_region_clip(_sos_clip_token)
        except Exception:
            pass
        _idv_reset_ui_gpu_state_after_draw(_sos_mesh, _gpu_snapshot)


def _handlers_required() -> bool:
    scenes = getattr(bpy.data, 'scenes', ()) or ()
    for scene in scenes:
        try:
            if bool(getattr(scene, 'idv_node_show', False)) or bool(getattr(scene, 'idv_image_show', False)):
                return True
        except Exception:
            continue
    return False


def _register_handlers():
    """Register both draw handlers transactionally and schedule one snapshot build."""
    if _handles:
        return bool(_handles.get('node') is not None and _handles.get('image') is not None)
    added = {}
    try:
        try:
            capture_guard = feature_toggle.suspend_capture()
        except Exception:
            capture_guard = None
        if capture_guard is None:
            added['node'] = bpy.types.SpaceNodeEditor.draw_handler_add(
                _draw_node_editor_safe, (), 'WINDOW', 'POST_PIXEL')
            added['image'] = bpy.types.SpaceImageEditor.draw_handler_add(
                _draw_image_editor_safe, (), 'WINDOW', 'POST_PIXEL')
        else:
            with capture_guard:
                added['node'] = bpy.types.SpaceNodeEditor.draw_handler_add(
                    _draw_node_editor_safe, (), 'WINDOW', 'POST_PIXEL')
                added['image'] = bpy.types.SpaceImageEditor.draw_handler_add(
                    _draw_image_editor_safe, (), 'WINDOW', 'POST_PIXEL')
        if added.get('node') is None or added.get('image') is None:
            raise RuntimeError('Image Dimensions draw handler registration was incomplete')
        _handles.update(added)
        _register_idv_boundary_handlers()
        request_idv_snapshot_rebuild(
            'handler_register', context=getattr(bpy, 'context', None), immediate=True
        )
        return True
    except Exception:
        _unregister_idv_boundary_handlers()
        clear_idv_snapshots()
        image_handle = added.get('image')
        if image_handle is not None:
            try:
                bpy.types.SpaceImageEditor.draw_handler_remove(image_handle, 'WINDOW')
            except Exception:
                pass
        node_handle = added.get('node')
        if node_handle is not None:
            try:
                bpy.types.SpaceNodeEditor.draw_handler_remove(node_handle, 'WINDOW')
            except Exception:
                pass
        _handles.clear()
        return False


def _unregister_handlers():
    clear_idv_snapshots()
    _unregister_idv_boundary_handlers()
    h = _handles.pop('node', None)
    if h:
        try:
            bpy.types.SpaceNodeEditor.draw_handler_remove(h, 'WINDOW')
        except Exception:
            pass
    h = _handles.pop('image', None)
    if h:
        try:
            bpy.types.SpaceImageEditor.draw_handler_remove(h, 'WINDOW')
        except Exception:
            pass


def _sync_addon_runtime_handlers() -> None:
    if _handlers_required():
        if not _handles:
            _register_handlers()
        else:
            _register_idv_boundary_handlers()
            request_idv_snapshot_rebuild('runtime_sync', context=getattr(bpy, 'context', None), immediate=False)
    else:
        _unregister_handlers()


# ─────────────────────────────────────────────────────────────────────────────
#  Register / Unregister
# ─────────────────────────────────────────────────────────────────────────────

EMBEDDED_PANEL_CLASSES: tuple[type, ...] = (VIEW3D_PT_idv_settings,)

classes = (
    ImageDimensionsSettings,
    IDV_OT_toggle_ui_group,
)


def _safe_register_class(cls):
    try:
        from .. import undo_support
        undo_support.prepare_operator_class(cls)
    except Exception:
        pass
    class_name = str(getattr(cls, '__name__', '') or '').strip()
    try:
        existing = getattr(bpy.types, class_name, None) if class_name else None
    except Exception:
        existing = None
    if existing is cls:
        return
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    bpy.utils.register_class(cls)


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_delete_rna_property(owner, prop_name: str) -> None:
    try:
        delattr(owner, str(prop_name))
    except Exception:
        pass


def _unregister_stale_image_dimensions_panel() -> None:
    """Remove older standalone Image Dimensions Viewer panels.

    The Smart Overlay root draws this tool directly.  Leaving an older
    VIEW3D_PT_idv_settings panel registered can show a second copy that still
    uses stale layout callbacks and reproduces the stair-step indentation.
    """
    try:
        cls = getattr(bpy.types, 'VIEW3D_PT_idv_settings', None)
    except Exception:
        cls = None
    if isinstance(cls, type):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def register():
    _unregister_stale_image_dimensions_panel()
    for cls in classes:
        _safe_register_class(cls)

    bpy.types.Scene.idv_settings = bpy.props.PointerProperty(
        type=ImageDimensionsSettings,
        name="Image Dimensions Viewer Settings",
        description="Internal settings storage for the Image Dimensions Viewer section embedded in Smart Overlay.",
    )
    bpy.types.Scene.idv_node_show = bpy.props.BoolProperty(
        name="Image Dimensions",
        description="Show image dimensions on Image Texture nodes in the Node Editor. Enable this when you want texture resolution labels directly on the nodes.",
        default=False,
        update=_settings_update,
    )
    bpy.types.Scene.idv_image_show = bpy.props.BoolProperty(
        name="Image Dimensions",
        description="Show an image-dimensions overlay in the Image Editor. Enable this when you want the active image resolution visible inside the editor.",
        default=False,
        update=_settings_update,
    )


    _sync_addon_runtime_handlers()
    _tag_idv_redraw()


def unregister():
    _unregister_handlers()


    for cls in reversed(classes):
        _safe_unregister_class(cls)

    for prop_name in ('idv_settings', 'idv_node_show', 'idv_image_show'):
        _safe_delete_rna_property(bpy.types.Scene, prop_name)
