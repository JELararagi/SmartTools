# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import bpy


def _sos_is_external_manager_panel(cls) -> bool:
    try:
        if bool(getattr(cls, '_smart_tools_manager_anchor', False)) or bool(getattr(cls, '_smart_tools_manager_proxy', False)):
            return True
        module_name = str(getattr(cls, '__module__', '') or '').lower()
        return 'smart_tools_manager' in module_name
    except Exception:
        return False


def _sos_class_is_suite_owned(cls) -> bool:
    if not isinstance(cls, type):
        return False
    try:
        receipts = bpy.app.driver_namespace.get('SMART_OVERLAY_SUITE_CLASS_RECEIPTS_V1', ())
        if isinstance(receipts, (list, tuple)) and any(item is cls for item in receipts):
            return True
    except Exception:
        return False
    return False


def _purge_non_root_smart_overlay_category_panels() -> None:
    panel_base = getattr(bpy.types, 'Panel', None)
    root_names = {
        'VIEW3D_PT_sos_root',
        'IMAGE_PT_sos_root',
        'NODE_PT_sos_root',
        'SEQUENCER_PT_sos_root',
        'CLIP_PT_sos_root',
        'DOPESHEET_PT_sos_root',
        'GRAPH_PT_sos_root',
        'NLA_PT_sos_root',
        'TEXT_PT_sos_root',
        'FILEBROWSER_PT_sos_root',
        'SPREADSHEET_PT_sos_root',
    }
    for name in tuple(dir(bpy.types)):
        if name in root_names:
            continue
        try:
            cls = getattr(bpy.types, name, None)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        try:
            if panel_base is None or not issubclass(cls, panel_base):
                continue
        except Exception:
            continue
        try:
            if str(getattr(cls, 'bl_region_type', '') or '') != 'UI':
                continue
            if str(getattr(cls, 'bl_category', '') or '') != 'Smart Overlay':
                continue
            if _sos_is_external_manager_panel(cls):
                continue
            if not _sos_class_is_suite_owned(cls):
                continue
        except Exception:
            continue
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass


def purge_stale_dynamic_classes() -> None:
    """Remove generated proxy UI classes left by older builds.

    The bundled tools are now embedded into the Smart Overlay root N-panel.
    Their original Panel classes are not registered as standalone sidebar
    panels. This cleanup prevents obsolete generated panels and invoke operators
    from coexisting with the unified N-panel after an in-place update or script
    reload.
    """
    panel_base = getattr(bpy.types, 'Panel', None)
    operator_base = getattr(bpy.types, 'Operator', None)
    legacy_token = ''.join(('SMART', 'TOOLS'))
    stale_prefixes = (
        'SMART_OVERLAY_PT_INT',
        f'{legacy_token}_PT_INT',
    )
    stale_exact = {
        'SMART_OVERLAY_SUITE_30F9D7_OT_integrated_addon_info',
        'SMART_OVERLAY_SUITE_30F9D7_OT_integrated_invoke',
        f'SMART_OVERLAY_SUITE_30F9D7_{legacy_token}_OT_integrated_addon_info',
        f'SMART_OVERLAY_SUITE_30F9D7_{legacy_token}_OT_integrated_invoke',
    }
    stale_panel_exact = {
        'VIEW3D_PT_sos_occluded_display_mode',
        'VIEW3D_PT_sos_vertex',
        'VIEW3D_PT_sos_edge',
        'VIEW3D_PT_sos_face',
        'VIEW3D_PT_sos_mesh_overlay',
        'VIEW3D_PT_sos_hover_optimization',
        'VIEW3D_PT_sos_object_hover',
        'VIEW3D_PT_sos_uv_hover',
        'VIEW3D_PT_sos_hover_overlay',
        'VIEW3D_PT_sos_edge_anti_aliasing',
        'VIEW3D_PT_sos_topology_checks',
        'VIEW3D_PT_sos_proportional_overlay',
        'VIEW3D_PT_sos_presets',
        'VIEW3D_PT_sos_scene_overrides',
        'SMART_MEASURE_PT_Edit',
        'SMART_MEASURE_PT_Conf',
        'SMART_MEASURE_PT_Render',
        'SMART_MEASURE_PT_Main',
        'VIEW3D_PT_smart_measure_grid_overlay',
        'MEASURE' + 'IT_PT_Edit',
        'MEASURE' + 'IT_PT_Conf',
        'MEASURE' + 'IT_PT_Render',
        'MEASURE' + 'IT_PT_Main',
        'VIEW3D_PT_' + 'grid' + '_' + 'dimension' + '_overlay',
        'VIEW3D_PT_idv_settings',
        'VIEW3D_PT_silhouette',
    }
    for name in tuple(dir(bpy.types)):
        text = str(name or '')
        if not (text.startswith(stale_prefixes) or text in stale_exact or text in stale_panel_exact):
            continue
        try:
            cls = getattr(bpy.types, text)
        except Exception:
            continue
        if not isinstance(cls, type):
            continue
        if not _sos_class_is_suite_owned(cls):
            continue
        try:
            if panel_base is not None and issubclass(cls, panel_base):
                bpy.utils.unregister_class(cls)
                continue
        except Exception:
            pass
        try:
            if operator_base is not None and issubclass(cls, operator_base):
                bpy.utils.unregister_class(cls)
                continue
        except Exception:
            pass

    _purge_non_root_smart_overlay_category_panels()


def register() -> None:
    purge_stale_dynamic_classes()


def unregister() -> None:
    purge_stale_dynamic_classes()


def refresh_all_suites(context=None) -> None:
    del context
    purge_stale_dynamic_classes()
