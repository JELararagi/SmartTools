# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    "name": "Silhouette Tool",
    "author": "JELararagi",
    "version": (1, 10, 0),
    "blender": (5, 1, 0),
    "location": "3D View > Sidebar > Smart Overlay",
    "description": "One-click viewport silhouette mode embedded only inside the single Smart Overlay N-panel.",
    "category": "View3D",
}

import bpy
from bpy.props import BoolProperty

from .. import registry


def _queue_suite_settings_save(context=None):
    try:
        from .. import settings
        settings.queue_save(context)
    except Exception:
        pass


def _panel_context_safe(context) -> bool:
    try:
        if context is None or getattr(context, 'scene', None) is None:
            return False
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return False
        obj = getattr(context, 'object', None) or getattr(context, 'active_object', None)
        mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
        if mode != 'OBJECT' and obj is None:
            return False
        return obj is not None
    except Exception:
        return False


def _silhouette_setting_update(self, context):
    """Apply or restore Silhouette mode from the saved BoolProperty.

    The centralized Always-on Toggle draws this property directly, so the update
    callback must perform the same viewport changes that the legacy operator did.
    """
    global _SILHOUETTE_UPDATE_LOCK
    if _SILHOUETTE_UPDATE_LOCK > 0:
        _queue_suite_settings_save(context)
        return
    scene = getattr(context, 'scene', None) if context is not None else getattr(getattr(bpy, 'context', None), 'scene', None)
    if scene is None:
        _queue_suite_settings_save(context)
        return
    sid = scene.as_pointer()
    _SILHOUETTE_UPDATE_LOCK += 1
    try:
        enabled = bool(getattr(scene, 'silhouette_enabled', False))
        if enabled:
            if sid not in _VIEW_SNAP:
                _VIEW_SNAP[sid] = _snapshot_viewport(context)
            try:
                if bool(getattr(scene, 'silhouette_all_objects', False)):
                    if _LOCAL_VIEW_ACTIVE.pop(sid, False):
                        bpy.ops.view3d.localview()
                elif getattr(context, 'selected_objects', None) and not _LOCAL_VIEW_ACTIVE.get(sid, False):
                    bpy.ops.view3d.localview()
                    _LOCAL_VIEW_ACTIVE[sid] = True
            except Exception:
                pass
            _apply_silhouette(context)
        else:
            try:
                if _LOCAL_VIEW_ACTIVE.pop(sid, False):
                    bpy.ops.view3d.localview()
            except Exception:
                pass
            _restore_viewport(context, _VIEW_SNAP.pop(sid, None))
    except Exception:
        pass
    finally:
        _SILHOUETTE_UPDATE_LOCK = max(0, _SILHOUETTE_UPDATE_LOCK - 1)
    _queue_suite_settings_save(context)

_VIEW_SNAP = {}
_LOCAL_VIEW_ACTIVE = {}
_SILHOUETTE_UPDATE_LOCK = 0


def _sil_localized(context, en: str, ja: str) -> str:
    return registry.localized(en, ja, context)


def _sil_context():
    return getattr(bpy, 'context', None)

def _iter_view3d_spaces(context):
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    yield area, space

def _snapshot_viewport(context):
    for _, space in _iter_view3d_spaces(context):
        sh = space.shading
        ov = space.overlay
        return {
            "type": sh.type,
            "light": getattr(sh, "light", None),
            "color_type": sh.color_type,
            "single_color": tuple(sh.single_color),
            "bg_type": sh.background_type,
            "bg_color": tuple(sh.background_color),
            "overlays": ov.show_overlays,
        }
    return None

def _apply_silhouette(context):
    for _, space in _iter_view3d_spaces(context):
        sh = space.shading
        ov = space.overlay
        sh.type = "SOLID"
        try:
            sh.light = "FLAT"
        except Exception:
            pass
        sh.color_type = "SINGLE"
        sh.single_color = (0, 0, 0)
        sh.background_type = "VIEWPORT"
        sh.background_color = (1, 1, 1)
        ov.show_overlays = False

def _restore_viewport(context, snap):
    if not snap:
        return
    for _, space in _iter_view3d_spaces(context):
        sh = space.shading
        ov = space.overlay
        sh.type = snap["type"]
        if snap["light"] is not None:
            sh.light = snap["light"]
        sh.color_type = snap["color_type"]
        sh.single_color = snap["single_color"]
        sh.background_type = snap["bg_type"]
        sh.background_color = snap["bg_color"]
        ov.show_overlays = snap["overlays"]

def _restore_safe_defaults(context):
    for _, space in _iter_view3d_spaces(context):
        sh = space.shading
        ov = space.overlay
        sh.type = "SOLID"
        try:
            sh.light = "STUDIO"
        except Exception:
            pass
        sh.color_type = "MATERIAL"
        sh.background_type = "THEME"
        ov.show_overlays = True

def _force_restore_on_unregister():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return

    for win in wm.windows:
        screen = getattr(win, "screen", None)
        scene = getattr(win, "scene", None)
        if not screen or not scene:
            continue
        if not getattr(scene, "silhouette_enabled", False):
            continue

        sid = scene.as_pointer()

        if _LOCAL_VIEW_ACTIVE.get(sid, False):
            for area in screen.areas:
                if area.type != "VIEW_3D":
                    continue
                region = next((r for r in area.regions if r.type == "WINDOW"), None)
                if not region:
                    continue
                override = {"window": win, "screen": screen, "area": area, "region": region, "scene": scene}
                try:
                    bpy.ops.view3d.localview(override)
                except Exception:
                    pass

        ctx = type("_SilCtx", (), {})()
        ctx.screen = screen
        snap = _VIEW_SNAP.get(sid)
        if snap:
            _restore_viewport(ctx, snap)
        else:
            _restore_safe_defaults(ctx)

        scene.silhouette_enabled = False

class VIEW3D_OT_toggle_silhouette(bpy.types.Operator):
    bl_idname = "view3d.toggle_silhouette"
    bl_label = "Silhouette Mode"
    bl_description = "Toggle silhouette mode for the current selection or the whole scene."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    @classmethod
    def poll(cls, context):
        return getattr(getattr(context, 'area', None), 'type', None) == 'VIEW_3D'

    def execute(self, context):
        sid = context.scene.as_pointer()
        if not context.scene.silhouette_enabled:
            use_local_view = bool(not context.scene.silhouette_all_objects and context.selected_objects)
            if use_local_view and not bpy.ops.view3d.localview.poll():
                self.report({'WARNING'}, _sil_localized(
                    context,
                    "Local View is not available in the current 3D View.",
                    "現在の3Dビューではローカルビューを使用できません。",
                ))
                return {"CANCELLED"}
            _VIEW_SNAP[sid] = _snapshot_viewport(context)
            _apply_silhouette(context)

            if use_local_view:
                bpy.ops.view3d.localview()
                _LOCAL_VIEW_ACTIVE[sid] = True

            context.scene.silhouette_enabled = True
        else:
            if _LOCAL_VIEW_ACTIVE.pop(sid, False):
                if bpy.ops.view3d.localview.poll():
                    bpy.ops.view3d.localview()
            _restore_viewport(context, _VIEW_SNAP.pop(sid, None))
            context.scene.silhouette_enabled = False
        _queue_suite_settings_save(context)
        return {"FINISHED"}

class VIEW3D_PT_silhouette(bpy.types.Panel):
    bl_label = "Silhouette Mode"
    bl_idname = "VIEW3D_PT_silhouette"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Smart Overlay'
    bl_order = 130

    @classmethod
    def poll(cls, context):
        return _panel_context_safe(context)

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "silhouette_all_objects", text=_sil_localized(context, "All Objects", "全オブジェクト"))


EMBEDDED_PANEL_CLASSES = (VIEW3D_PT_silhouette,)


def _safe_register_class(cls):
    try:
        from .. import undo_support
        undo_support.prepare_operator_class(cls)
    except Exception:
        pass
    class_name = str(getattr(cls, '__name__', '') or '').strip()
    try:
        existing = getattr(bpy.types, class_name, None) if class_name else None
    except Exception:
        existing = None
    if existing is cls:
        return
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    bpy.utils.register_class(cls)


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_delete_rna_property(owner, prop_name: str) -> None:
    try:
        delattr(owner, str(prop_name))
    except Exception:
        pass

def register():
    _safe_register_class(VIEW3D_OT_toggle_silhouette)
    bpy.types.Scene.silhouette_enabled = BoolProperty(
        name="Silhouette Enabled",
        description="Enable Silhouette Mode from the centralized Always-on Toggle. ON applies the high-contrast silhouette viewport state; OFF restores the saved viewport state.",
        default=False,
        update=_silhouette_setting_update,
    )
    bpy.types.Scene.silhouette_all_objects = BoolProperty(
        name="All Objects",
        description="When Silhouette Mode is enabled, apply it to all visible objects instead of entering Local View for the current selection.",
        default=False,
        update=_silhouette_setting_update,
    )

def unregister():
    _force_restore_on_unregister()
    _safe_unregister_class(VIEW3D_PT_silhouette)
    _safe_unregister_class(VIEW3D_OT_toggle_silhouette)
    _safe_delete_rna_property(bpy.types.Scene, 'silhouette_enabled')
    _safe_delete_rna_property(bpy.types.Scene, 'silhouette_all_objects')

if __name__ == "__main__":
    register()
