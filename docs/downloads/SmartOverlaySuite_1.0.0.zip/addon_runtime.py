# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from . import loader, ui_runtime


def register() -> None:
    # Integrated tools register their RNA/operators normally, but their own
    # panel draw callbacks are captured by the loader without registering
    # standalone bundled-tool N-panels. Remove stale proxy classes before loading them.
    try:
        ui_runtime.unregister()
    except Exception:
        pass
    try:
        ui_runtime.purge_stale_dynamic_classes()
    except Exception:
        pass
    loader.register_all()


def unregister() -> None:
    try:
        ui_runtime.unregister()
    except Exception:
        pass
    loader.unregister_all()
    try:
        ui_runtime.purge_stale_dynamic_classes()
    except Exception:
        pass
