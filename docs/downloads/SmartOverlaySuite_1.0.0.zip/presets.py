# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Redistribution, modification, resale, or relicensing is prohibited
#  without explicit permission from JELararagi.
# ------------------------------------------------------------------------------

import copy
import json

_PRESET_ENUM_ITEMS_CACHE = ()
_PRESET_ENUM_STRINGS_CACHE = []

# =============================================================================
# Presets (Built-in + User)
# =============================================================================

# Keys that are safe to snapshot/restore. Missing keys are ignored on apply.
VISUAL_KEYS = [
    # Global
    "double_sided",
    "active_view_only",
    "active_view_draw_only",
    "hide_occluded_colors_when_xray_off",
    "hide_visible_occluded_when_occluded_off",
    "use_all_objects_as_occluders",
    "include_geometry_nodes_objects",
    "include_curve_shape_overlay",
    "include_lattice_objects",
    "use_evaluated_edit_mode_face_overlay",
    "use_select_mode_vertex_center_overlay",
    "hide_blender_standard_edit_edges_vertices",
    "hide_blender_adjacent_edge_gradient",
    "hide_blender_vertex_mode_linked_edge_face_overlay",
    "hide_blender_edge_mode_linked_vertex_face_overlay",
    "hide_blender_face_mode_linked_vertex_edge_overlay",
    "edge_aa_mode",
    "occluded_display_mode",
    "occluded_style",
    "occluded_alpha_mul",
    "occluded_thickness_mul",
    "occluded_point_mul",
    "hover_lod_mode",
    "hover_lod_threshold_verts",
    "topology_checks_enabled",
    "topo_selection_filter",
    "topo_edges_enabled",
    "topo_show_seams",
    "topo_show_sharp",
    "topo_show_crease",
    "topo_crease_threshold",
    "topo_show_bevel_weight",
    "topo_bevel_weight_threshold",
    "topo_show_non_manifold",
    "topo_edge_color_seam",
    "topo_edge_color_sharp",
    "topo_edge_color_crease",
    "topo_edge_color_bevel",
    "topo_edge_color_nonmanifold",
    "topo_edge_size_mul",
    "topo_faces_enabled",
    "topo_show_ngons",
    "topo_show_small_faces",
    "topo_small_face_area",
    "topo_show_backfaces",
    "topo_face_color_ngon",
    "topo_face_color_small",
    "topo_face_color_backface",
    "topo_face_opacity_mul",

    # Vertex
    "show_verts_edit", "show_verts_object",
    "show_vis_verts", "show_occ_verts", "show_sel_verts", "show_hov_verts",
    "show_hov_obj_verts",
    "vertex_color", "vertex_occluded_color", "selected_vertex_overlay_color",
    "hover_vertex_color", "hover_obj_vertex_color", "hover_obj_vertex_edge_opacity",
    "vertex_size", "vertex_depth_offset", "vertex_depth_offset_ui",

    # Edge
    "show_edges_edit", "show_edges_object",
    "show_vis_edges", "show_occ_edges", "show_sel_edges", "show_hov_edges",
    "show_hov_obj_edges",
    "edge_color", "edge_occluded_color", "selected_edge_overlay_color",
    "hover_edge_color", "hover_obj_edge_color",
    "edge_size", "edge_depth_offset", "edge_depth_offset_ui",

    # Face
    "show_faces_edit", "show_faces_object",
    "show_vis_faces", "show_occ_faces", "show_sel_faces", "show_hov_faces",
    "show_hov_obj_faces",
    "face_color", "face_occluded_color", "selected_face_overlay_color", "hover_face_color", "hover_obj_face_color", "hover_obj_face_opacity",
    "opacity", "face_depth_offset", "face_depth_offset_ui",

    # Object Hover
    "hover_delay_sec",

    # UV Editor Hover
    "show_hov_uv_verts", "show_hov_uv_edges", "show_hov_uv_faces",
    "hover_uv_vertex_color", "hover_uv_edge_color", "hover_uv_face_color", "hover_uv_vertex_edge_opacity", "hover_uv_face_opacity",
    "show_uv_same_mesh_selection_overlay", "show_uv_same_mesh_selection_verts", "show_uv_same_mesh_selection_edges",
    "uv_same_mesh_selection_color", "uv_same_mesh_selection_opacity",

    # Proportional overlay appearance
    "prop_overlay_vertex_size",
    "prop_overlay_edge_size",
    "prop_heatmap_xray",
    "prop_heatmap_alpha",
    "prop_show_3d_view",
    "prop_show_uv_editor",
    "prop_grad_color_0", "prop_grad_color_25", "prop_grad_color_50",
    "prop_grad_color_75", "prop_grad_color_100",
]

def _c(r,g,b):
    return (float(r), float(g), float(b))

BUILTIN_PRESETS = {
    "CUSTOM": {"label": "Custom", "desc": "Use manual settings (no preset).", "values": {}},

    "TOPO": {
        "label": "Topo Check",
        "desc": "Clean topology readability (edges + verts, minimal faces).",
        "values": {
            "show_verts_edit": True,
            "show_edges_edit": True,
            "show_faces_edit": False,
            "show_vis_verts": True,
            "show_vis_edges": True,
            "show_vis_faces": False,
            "vertex_color": _c(0.06, 0.06, 0.92),
            "edge_color": _c(0.20, 0.80, 1.00),
            "vertex_occluded_color": _c(0.10, 0.10, 0.35),
            "edge_occluded_color": _c(0.10, 0.25, 0.35),
            "vertex_size": 4,
            "edge_size": 2,
            "opacity": 0.10,
            "occluded_display_mode": "XRAY_ONLY",
            "occluded_style": "FADE_THIN",
            "occluded_alpha_mul": 0.45,
            "occluded_thickness_mul": 0.75,
            "occluded_point_mul": 0.85,
            "edge_aa_mode": "AA_2PASS",
            "topology_checks_enabled": False,
        },
    },

    "SCULPT": {
        "label": "Sculpt",
        "desc": "Face-oriented overlay for sculpting (soft faces, minimal wires).",
        "values": {
            "show_verts_edit": False,
            "show_edges_edit": False,
            "show_faces_edit": True,
            "show_verts_object": False,
            "show_edges_object": False,
            "show_faces_object": True,
            "show_vis_faces": True,
            "show_occ_faces": False,
            "face_color": _c(0.25, 0.25, 0.25),
            "hover_face_color": _c(1.0, 0.75, 0.10),
            "hover_obj_face_color": _c(1.0, 0.75, 0.10),
            "opacity": 0.20,
            "edge_aa_mode": "AA_OFF",
            "topology_checks_enabled": False,
        },
    },

    "XRAY": {
        "label": "X-Ray",
        "desc": "Always show occluded elements (useful for inside/outside editing).",
        "values": {
            "occluded_display_mode": "ALWAYS",
            "hide_occluded_colors_when_xray_off": False,
            "occluded_style": "FADE_THIN",
            "occluded_alpha_mul": 0.40,
            "occluded_thickness_mul": 0.70,
            "occluded_point_mul": 0.80,
            "show_occ_verts": True,
            "show_occ_edges": True,
            "show_occ_faces": False,
            "topology_checks_enabled": False,
        },
    },

    "MAYA": {
        "label": "Maya",
        "desc": "Maya-like readability (neutral wires, warm selection).",
        "values": {
            "edge_color": _c(0.55, 0.55, 0.55),
            "vertex_color": _c(0.55, 0.55, 0.55),
            "selected_edge_overlay_color": _c(1.00, 0.78, 0.12),
            "selected_vertex_overlay_color": _c(1.00, 0.78, 0.12),
            "selected_face_overlay_color": _c(1.00, 0.78, 0.12),
            "hover_edge_color": _c(1.00, 0.78, 0.12),
            "hover_vertex_color": _c(1.00, 0.78, 0.12),
            "edge_size": 2,
            "vertex_size": 4,
            "edge_aa_mode": "AA_2PASS",
            "topology_checks_enabled": False,
        },
    },

    "MAX": {
        "label": "3ds Max",
        "desc": "3ds Max-like contrast (cool wires, vivid selection).",
        "values": {
            "edge_color": _c(0.20, 0.55, 1.00),
            "vertex_color": _c(0.20, 0.55, 1.00),
            "selected_edge_overlay_color": _c(1.00, 0.25, 0.10),
            "selected_vertex_overlay_color": _c(1.00, 0.25, 0.10),
            "selected_face_overlay_color": _c(1.00, 0.25, 0.10),
            "hover_edge_color": _c(1.00, 0.25, 0.10),
            "hover_vertex_color": _c(1.00, 0.25, 0.10),
            "edge_size": 2,
            "vertex_size": 4,
            "edge_aa_mode": "AA_2PASS",
            "topology_checks_enabled": False,
        },
    },
}

PRESET_DEFAULT_ID = "CUSTOM"


def default_preset_id() -> str:
    return PRESET_DEFAULT_ID


def preset_label_translatable(preset_id) -> bool:
    """User preset names and product names stay as written."""
    identifier = str(preset_id or '')
    return not (identifier.startswith('USER::') or identifier in {'MAYA', 'MAX'})


def get_preset_items(prefs):
    global _PRESET_ENUM_ITEMS_CACHE, _PRESET_ENUM_STRINGS_CACHE

    items = []
    string_refs = []
    seen_ids = set()

    def _append_item(identifier, label, description):
        identifier = str(identifier or "").strip()
        if not identifier or identifier in seen_ids:
            return
        item = (identifier, str(label or identifier), str(description or ""))
        items.append(item)
        string_refs.extend(item)
        seen_ids.add(identifier)

    for pid, data in BUILTIN_PRESETS.items():
        _append_item(pid, data.get("label", ""), data.get("desc", ""))

    try:
        for preset in getattr(prefs, "custom_presets", []):
            name = str(getattr(preset, "name", "") or "").strip()
            if not name:
                continue
            _append_item(f"USER::{name}", name, "User preset")
    except Exception:
        pass

    if not items:
        _append_item(PRESET_DEFAULT_ID, "Custom", "")

    _PRESET_ENUM_STRINGS_CACHE = string_refs
    _PRESET_ENUM_ITEMS_CACHE = tuple(items)
    return _PRESET_ENUM_ITEMS_CACHE


def normalize_preset_id(prefs, preset_id=None) -> str:
    candidate = str(preset_id or "").strip()
    available = [str(item[0]) for item in get_preset_items(prefs) if item and str(item[0]).strip()]
    if candidate and candidate in available:
        return candidate
    if PRESET_DEFAULT_ID in available:
        return PRESET_DEFAULT_ID
    return available[0] if available else PRESET_DEFAULT_ID


def get_preset_label(prefs, preset_id=None) -> str:
    resolved = normalize_preset_id(prefs, preset_id)
    for item in get_preset_items(prefs):
        identifier = str(item[0] or "").strip() if item else ""
        if identifier == resolved:
            return str(item[1] or resolved)
    return "Custom" if resolved == PRESET_DEFAULT_ID else resolved


def is_user_preset_id(preset_id) -> bool:
    return str(preset_id or "").strip().startswith("USER::")


def resolve_preset_values(prefs, preset_id):
    preset_id = normalize_preset_id(prefs, preset_id)
    if preset_id in BUILTIN_PRESETS:
        return copy.deepcopy(BUILTIN_PRESETS[preset_id]["values"])
    if preset_id.startswith("USER::"):
        name = preset_id.split("USER::", 1)[1]
        for preset in getattr(prefs, "custom_presets", []):
            if getattr(preset, 'name', '') == name:
                try:
                    return json.loads(preset.data) if preset.data else {}
                except Exception:
                    return {}
    return {}
