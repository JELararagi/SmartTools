# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

import logging

import bpy
import bmesh
from bmesh import from_edit_mesh
# noinspection PyUnresolvedReferences
from bpy.types import PropertyGroup, Panel, Object, Operator, SpaceView3D
from bpy.props import IntProperty, CollectionProperty, FloatVectorProperty, BoolProperty, StringProperty, \
                      FloatProperty, EnumProperty
from bpy.app.handlers import persistent
# noinspection PyUnresolvedReferences
from .smart_measure_geometry import *
from .smart_measure_render import *
from .. import icons as sos_icons
from .. import registry
from .. import transform_guard
from .. import mesh as _sos_mesh_runtime


_sos_gpu_state_restore_stack = []


def _sos_capture_gpu_state_snapshot() -> dict:
    snapshot = {}
    for _key, _getter in (
        ('blend', 'blend_get'),
        ('depth_test', 'depth_test_get'),
        ('depth_mask', 'depth_mask_get'),
        ('line_width', 'line_width_get'),
        ('scissor', 'scissor_get'),
        ('scissor_test', 'scissor_test_get'),
        ('viewport', 'viewport_get'),
    ):
        try:
            snapshot[_key] = getattr(gpu.state, _getter)()
        except Exception:
            pass
    return snapshot



def _sos_reset_blf_state_after_draw() -> None:
    """Reset sticky BLF flags without changing Blender theme alpha/color."""
    try:
        import blf
    except Exception:
        return
    for _font_id in (0,):
        for _flag_name in ('ROTATION', 'SHADOW', 'CLIPPING', 'WORD_WRAP', 'MONOCHROME'):
            try:
                _flag = getattr(blf, _flag_name, None)
                if _flag is not None:
                    blf.disable(_font_id, _flag)
            except Exception:
                pass
        for _name, _args in (
            ('rotation', (0.0,)),
            ('aspect', (1.0,)),
            ('shadow', (0, 0.0, 0.0, 0.0, 0.0)),
            ('shadow_offset', (0, 0)),
            ('word_wrap', (0,)),
        ):
            try:
                getattr(blf, _name)(_font_id, *_args)
            except Exception:
                pass


def _sos_restore_gpu_state_snapshot(snapshot=None, *, ui_safe: bool = False) -> None:
    """Restore GPU/BLF state after Smart Measure drawing.

    Smart Measure leaves Blender's editor UI in the draw state it received.
    ``ui_safe=True`` is accepted for compatibility with shared wrappers, but it
    must not impose a fixed blend mode on Blender's own UI.  N-panel opacity is
    theme/UI owned, not add-on owned.
    """
    try:
        gpu.state.color_mask_set(True, True, True, True)
    except Exception:
        pass

    # These states have setters but no public getters in Blender 5.1.  They are
    # enabled only by Smart Overlay's custom draw paths, so return them to neutral
    # values without changing theme colors or alpha values.
    for _name, _args in (
        ('multisample_set', (False,)),
        ('line_smooth_set', (False,)),
        ('alpha_to_coverage_set', (False,)),
        ('face_culling_set', ('NONE',)),
        ('front_facing_set', (False,)),
        ('clip_distances_set', (0,)),
        ('program_point_size_set', (False,)),
        ('point_size_set', (1.0,)),
    ):
        try:
            getattr(gpu.state, _name)(*_args)
        except Exception:
            pass

    restored_blend = None
    if isinstance(snapshot, dict) and snapshot:
        for _key, _setter in (
            ('blend', 'blend_set'),
            ('depth_mask', 'depth_mask_set'),
            ('depth_test', 'depth_test_set'),
            ('line_width', 'line_width_set'),
            ('scissor', 'scissor_set'),
            ('scissor_test', 'scissor_test_set'),
            ('viewport', 'viewport_set'),
        ):
            if _key not in snapshot:
                continue
            try:
                value = snapshot[_key]
                if _key == 'blend':
                    restored_blend = str(value)
                if isinstance(value, (tuple, list)):
                    getattr(gpu.state, _setter)(*value)
                else:
                    getattr(gpu.state, _setter)(value)
            except Exception:
                pass

    _sos_reset_blf_state_after_draw()
    try:
        _sos_mesh_runtime._sos_reapply_sidebar_safe_overlay_clip()
    except Exception:
        pass

def _sos_sanitize_gpu_state_for_blender_ui(snapshot=None) -> None:
    """Restore Smart Overlay draw state without overriding theme transparency."""
    _sos_restore_gpu_state_snapshot(snapshot, ui_safe=True)


def _sos_force_ui_safe_gpu_state(snapshot=None) -> None:
    """Compatibility helper: restore captured draw state exactly."""
    if snapshot is None:
        try:
            if _sos_gpu_state_restore_stack:
                snapshot = _sos_gpu_state_restore_stack[-1]
        except Exception:
            snapshot = None
    _sos_restore_gpu_state_snapshot(snapshot, ui_safe=True)


def _sos_push_gpu_state_restore() -> dict:
    snapshot = _sos_capture_gpu_state_snapshot()
    try:
        _sos_gpu_state_restore_stack.append(snapshot)
    except Exception:
        pass
    return snapshot


def _sos_pop_gpu_state_restore(snapshot=None, *, ui_safe: bool = False) -> None:
    restore_snapshot = snapshot
    try:
        if _sos_gpu_state_restore_stack:
            restore_snapshot = _sos_gpu_state_restore_stack.pop()
    except Exception:
        restore_snapshot = snapshot
    _sos_restore_gpu_state_snapshot(restore_snapshot, ui_safe=ui_safe)


def _sos_reset_gpu_state_after_draw() -> None:
    """Restore the current draw-handler snapshot without changing theme alpha."""
    snapshot = None
    try:
        if _sos_gpu_state_restore_stack:
            snapshot = _sos_gpu_state_restore_stack[-1]
    except Exception:
        snapshot = None
    _sos_restore_gpu_state_snapshot(snapshot)

_SMART_MEASURE_JA = {
    'All': 'すべて',
    'Add Measures': '計測を追加',
    'Segment': 'セグメント',
    'Sum': '合計',
    'Angle': '角度',
    'Arc': '円弧',
    'Label': 'ラベル',
    'Annotation': '注釈',
    'Link': 'リンク',
    'Origin': '原点',
    'Area': '面積',
    'Sum Selected Edges': '選択辺の合計',
    'Gap': '分離',
    'Type': 'タイプ',
    'Mesh Debug': 'メッシュデバッグ',
    'Objects': 'オブジェクト',
    'Vertices': '頂点',
    'Edges': '辺',
    'Faces': '面',
    'Normals': '法線',
    'Precision': '精度',
    'Distances': '距離',
    'Texts': 'テキスト',
    'Hide measurement unit': '計測単位を非表示',
    'Scale': 'スケール',
    'Scale:': 'スケール:',
    'Override': '上書き',
    'Expand all': '全て展開',
    'Collapse all': '全て折りたたむ',
    'Delete all': '全て削除',
    'Totals': '合計',
    'Group': 'グループ',
    'Font': 'フォント',
    'Rotate': '回転',
    'Distance': '距離',
    'Size': 'サイズ',
    'Line': '線',
    'Automatic position': '自動配置',
    'Orthogonal': '直交',
    'Warning': '警告',
    'Radius': '半径',
    'Length': '長さ',
    'Full Circle': '完全な円',
    'Adapt radio': '半径に合わせる',
    'Configuration': '設定',
    'Render': 'レンダー',
    'Text': 'テキスト',
    'Save render image': 'レンダー画像を保存',
    'Frame': 'フレーム',
    'Color': '色',
    'Space': '余白',
    'Width': '幅',
    'Thickness': '太さ',
    'Items': '項目',
    'Smart Measure Tools': 'スマート メジャー ツール',
}


def _(text: str) -> str:
    value = str(text or '')
    return registry.localized(value, _SMART_MEASURE_JA.get(value, value), getattr(bpy, 'context', None))

def _SICON(name: str = '', fallback: str = 'NONE') -> int:
    try:
        return int(sos_icons.icon_value(name, fallback) or 0)
    except Exception:
        return 0


def _icon_kwargs(name: str = '', fallback: str = 'NONE') -> dict:
    try:
        return sos_icons.icon_kwargs(name, fallback)
    except Exception:
        return {'icon': str(fallback or 'NONE')}

_LOG = logging.getLogger(__name__)


def _safe_context_object(context=None):
    try:
        obj = getattr(context, 'object', None)
    except Exception:
        obj = None
    if obj is None:
        try:
            obj = getattr(context, 'active_object', None)
        except Exception:
            obj = None
    if obj is None:
        return None
    try:
        _ = obj.name
        _ = obj.type
        if hasattr(obj, 'as_pointer') and int(obj.as_pointer()) == 0:
            return None
    except Exception:
        return None
    return obj


def _has_smart_measure_items(obj) -> bool:
    if obj is None:
        return False
    try:
        return hasattr(obj, 'SmartMeasureGenerator') and len(obj.SmartMeasureGenerator) > 0
    except Exception:
        return False


def _smart_measure_items(obj):
    if not _has_smart_measure_items(obj):
        return None
    try:
        return obj.SmartMeasureGenerator[0]
    except Exception:
        return None


def _safe_context_scene(context=None):
    try:
        scene = getattr(context, 'scene', None)
        if scene is not None:
            _ = scene.name
        return scene
    except Exception:
        return None


def _smart_measure_panel_context_safe(context, *, require_items: bool = False) -> bool:
    if _safe_context_scene(context) is None:
        return False
    try:
        area = getattr(context, 'area', None)
        if area is not None and getattr(area, 'type', None) != 'VIEW_3D':
            return False
    except Exception:
        return False
    obj = _safe_context_object(context)
    if obj is None:
        return False
    mode = str(getattr(context, 'mode', 'OBJECT') or 'OBJECT')
    if mode != 'OBJECT' and obj is None:
        return False
    if require_items and not _has_smart_measure_items(obj):
        return False
    return True


def _queue_suite_settings_save(context=None):
    try:
        from .. import settings
        settings.queue_save(context)
    except Exception:
        pass


# ------------------------------------------------------
# Handler to detect new Blend load
#
# ------------------------------------------------------
# noinspection PyUnusedLocal
@persistent
def load_handler(dummy):
    # File loading invalidates old draw handles.  Remove the handler without
    # changing WindowManager.smart_measure_run_opengl so the centralized Always-on
    # Toggle can restore the saved enabled state during the suite load_post sync.
    with transform_guard.ObjectTransformGuard('smart_measure_load_post'):
        try:
            handle = SMART_MEASURE_OT_RunHintDisplay._handle
            if handle is not None:
                SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        except Exception:
            pass
        SMART_MEASURE_OT_RunHintDisplay._handle = None


# ------------------------------------------------------
# Handler to detect save Blend
# Clear not used measured
#
# ------------------------------------------------------
# noinspection PyUnusedLocal
@persistent
def save_handler(dummy):
    # Saving a .blend file must not mutate object datablocks.  Older Smart
    # Measure cleanup renamed and removed measurement collection items here;
    # that touched Object custom data during Blender's save pipeline and could
    # contribute to objects reopening with unexpected state.  Cleanup is now
    # intentionally deferred to explicit measurement operators only.
    with transform_guard.ObjectTransformGuard('smart_measure_save_pre'):
        return None



# ------------------------------------------------------------------
# Define property group class for smart_measure faces index
# ------------------------------------------------------------------
class SmartMeasureIndex(PropertyGroup):
    glidx: IntProperty(name="index", description="vertex index")



# ------------------------------------------------------------------
# Define property group class for smart_measure faces
# ------------------------------------------------------------------
class SmartMeasureFaces(PropertyGroup):
    glface: IntProperty(name="glface", description="Face number")
    # Array of index
    smart_measure_index: CollectionProperty(
        type=SmartMeasureIndex,
        name="Smart Measure Face Indices",
        description="Internal list of vertex indices used by Smart Measure face measurements.",
    )



# ------------------------------------------------------------------
# Define property group class for smart_measure data
# ------------------------------------------------------------------
class SmartMeasureProperties(PropertyGroup):
    gltype: IntProperty(name="gltype",
                       description="Measure type (1-Segment, 2-Label, etc..)", default=1)
    glpointa: IntProperty(name="glpointa",
                         description="Hidden property for opengl")
    glpointb: IntProperty(name="glpointb",
                         description="Hidden property for opengl")
    glpointc: IntProperty(name="glpointc",
                         description="Hidden property for opengl")
    glcolor: FloatVectorProperty(name="glcolor",
                                  description="Color for the measure",
                                  default=(0.173, 0.545, 1.0, 1.0),
                                  min=0.1,
                                  max=1,
                                  subtype='COLOR',
                                  size=4)
    glview: BoolProperty(name="glview",
                          description="Measure visible/hide",
                          default=True)
    glspace: FloatProperty(name='glspace', min=-100, max=100, default=0.1,
                            precision=3,
                            description='Distance to display measure')
    glwidth: IntProperty(name='glwidth', min=1, max=10, default=1,
                          description='line width')
    glfree: BoolProperty(name="glfree",
                          description="This measure is free and can be deleted",
                          default=False)
    gltxt: StringProperty(name="gltxt", maxlen=256,
                           description="Short description (use | for line break)")
    gladvance: BoolProperty(name="gladvance",
                             description="Advanced options as line width or position",
                             default=False)
    gldefault: BoolProperty(name="gldefault",
                             description="Display measure in position calculated by default",
                             default=True)
    glnormalx: FloatProperty(name="glnormalx",
                              description="Change orientation in X axis",
                              default=1, min=-1, max=1, precision=2)
    glnormaly: FloatProperty(name="glnormaly",
                              description="Change orientation in Y axis",
                              default=0, min=-1, max=1, precision=2)
    glnormalz: FloatProperty(name="glnormalz",
                              description="Change orientation in Z axis",
                              default=0, min=-1, max=1, precision=2)
    glfont_size: IntProperty(name="Text Size",
                              description="Text size",
                              default=14, min=6, max=150)
    glfont_align: EnumProperty(items=(('L', "Left Align", ""),
                                       ('C', "Center Align", ""),
                                       ('R', "Right Align", "")),
                                name="Align Font",
                                description="Set Font Alignment")
    glfont_rotat: IntProperty(name='Rotate', min=0, max=360, default=0,
                                description="Text rotation in degrees")
    gllink: StringProperty(name="gllink",
                            description="linked object for linked measures")
    glocwarning: BoolProperty(name="glocwarning",
                               description="Display a warning if some axis is not used in distance",
                               default=True)
    glocx: BoolProperty(name="glocx",
                         description="Include changes in X axis for calculating the distance",
                         default=True)
    glocy: BoolProperty(name="glocy",
                         description="Include changes in Y axis for calculating the distance",
                         default=True)
    glocz: BoolProperty(name="glocz",
                         description="Include changes in Z axis for calculating the distance",
                         default=True)
    glfontx: IntProperty(name="glfontx",
                          description="Change font position in X axis",
                          default=0, min=-3000, max=3000)
    glfonty: IntProperty(name="glfonty",
                          description="Change font position in Y axis",
                          default=0, min=-3000, max=3000)
    gldist: BoolProperty(name="gldist",
                          description="Display distance for this measure",
                          default=True)
    glnames: BoolProperty(name="glnames",
                           description="Display text for this measure",
                           default=True)
    gltot: EnumProperty(items=(('99', "-", "Select a group for sum"),
                                ('0', "A", ""),
                                ('1', "B", ""),
                                ('2', "C", ""),
                                ('3', "D", ""),
                                ('4', "E", ""),
                                ('5', "F", ""),
                                ('6', "G", ""),
                                ('7', "H", ""),
                                ('8', "I", ""),
                                ('9', "J", ""),
                                ('10', "K", ""),
                                ('11', "L", ""),
                                ('12', "M", ""),
                                ('13', "N", ""),
                                ('14', "O", ""),
                                ('15', "P", ""),
                                ('16', "Q", ""),
                                ('17', "R", ""),
                                ('18', "S", ""),
                                ('19', "T", ""),
                                ('20', "U", ""),
                                ('21', "V", ""),
                                ('22', "W", ""),
                                ('23', "X", ""),
                                ('24', "Y", ""),
                                ('25', "Z", "")),
                         name="Sum in Group",
                         description="Add segment length in selected group")
    glorto: EnumProperty(items=(('99', "None", ""),
                                 ('0', "A", "Point A must use selected point B location"),
                                 ('1', "B", "Point B must use selected point A location")),
                          name="Orthogonal",
                          description="Display point selected as orthogonal (select axis to copy)")
    glorto_x: BoolProperty(name="ox",
                            description="Copy X location",
                            default=False)
    glorto_y: BoolProperty(name="oy",
                            description="Copy Y location",
                            default=False)
    glorto_z: BoolProperty(name="oz",
                            description="Copy Z location",
                            default=False)
    glarrow_a: EnumProperty(items=(('99', "--", "No arrow"),
                                    ('1', "Line", "The point of the arrow are lines"),
                                    ('2', "Triangle", "The point of the arrow is triangle"),
                                    ('3', "TShape", "The point of the arrow is a T")),
                             name="A end",
                             description="Add arrows to point A")
    glarrow_b: EnumProperty(items=(('99', "--", "No arrow"),
                                    ('1', "Line", "The point of the arrow are lines"),
                                    ('2', "Triangle", "The point of the arrow is triangle"),
                                    ('3', "TShape", "The point of the arrow is a T")),
                             name="B end",
                             description="Add arrows to point B")
    glarrow_s: IntProperty(name="Size",
                            description="Arrow size",
                            default=15, min=6, max=500)

    glarc_full: BoolProperty(name="arcfull",
                              description="Create full circumference",
                              default=False)
    glarc_extrad: BoolProperty(name="arcextrad",
                                description="Adapt radio length to arc line",
                                default=True)
    glarc_rad: BoolProperty(name="arc rad",
                             description="Show arc radius",
                             default=True)
    glarc_len: BoolProperty(name="arc len",
                             description="Show arc length",
                             default=True)
    glarc_ang: BoolProperty(name="arc ang",
                             description="Show arc angle",
                             default=True)

    glarc_a: EnumProperty(items=(('99', "--", "No arrow"),
                                  ('1', "Line", "The point of the arrow are lines"),
                                  ('2', "Triangle", "The point of the arrow is triangle"),
                                  ('3', "TShape", "The point of the arrow is a T")),
                           name="Ar end",
                           description="Add arrows to point A")
    glarc_b: EnumProperty(items=(('99', "--", "No arrow"),
                                  ('1', "Line", "The point of the arrow are lines"),
                                  ('2', "Triangle", "The point of the arrow is triangle"),
                                  ('3', "TShape", "The point of the arrow is a T")),
                           name="Br end",
                           description="Add arrows to point B")
    glarc_s: IntProperty(name="Size",
                          description="Arrow size",
                          default=15, min=6, max=500)
    glarc_txradio: StringProperty(name="txradio",
                                   description="Text for radius", default="r=")
    glarc_txlen: StringProperty(name="txlen",
                                 description="Text for length", default="L=")
    glarc_txang: StringProperty(name="txang",
                                 description="Text for angle", default="A=")
    glcolorarea: FloatVectorProperty(name="glcolorarea",
                                      description="Color for the measure of area",
                                      default=(0.1, 0.1, 0.1, 1.0),
                                      min=0.1,
                                      max=1,
                                      subtype='COLOR',
                                      size=4)

    # Array of faces
    smart_measure_faces: CollectionProperty(
        type=SmartMeasureFaces,
        name="Smart Measure Faces",
        description="Internal list of face records used by Smart Measure area measurements.",
    )



# ------------------------------------------------------------------
# Define object class (container of segments)
# SmartMeasure
# ------------------------------------------------------------------
class SmartMeasureContainer(PropertyGroup):
    smart_measure_num: IntProperty(name='Number of measures', min=0, max=1000, default=0,
                                description='Number total of smart_measure elements')
    # Array of segments
    smart_measure_segments: CollectionProperty(
        type=SmartMeasureProperties,
        name="Smart Measure Segments",
        description="Internal list of Smart Measure measurement, label, annotation, and area elements.",
    )


_BASE_TYPES = (SmartMeasureIndex, SmartMeasureFaces, SmartMeasureProperties, SmartMeasureContainer)


def _safe_register_base_class(cls):
    try:
        from .. import undo_support
        undo_support.prepare_operator_class(cls)
    except Exception:
        pass
    try:
        existing = getattr(bpy.types, getattr(cls, "__name__", ""), None)
        if existing is not None and existing is not cls:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        bpy.utils.register_class(cls)
    except RuntimeError as exc:
        if "already registered" not in str(exc).lower():
            raise
    except Exception:
        _LOG.exception("Smart Measure base class registration failed: %s", getattr(cls, "__name__", cls))
        raise


def _safe_unregister_base_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def register_addon_runtime_support():
    try:
        if load_handler not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(load_handler)
    except Exception:
        pass
    try:
        if save_handler not in bpy.app.handlers.save_pre:
            bpy.app.handlers.save_pre.append(save_handler)
    except Exception:
        pass


def unregister_addon_runtime_support():
    try:
        while load_handler in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(load_handler)
    except Exception:
        pass
    try:
        while save_handler in bpy.app.handlers.save_pre:
            bpy.app.handlers.save_pre.remove(save_handler)
    except Exception:
        pass


def register_base_types():
    for cls in _BASE_TYPES:
        _safe_register_base_class(cls)
    try:
        if not hasattr(Object, 'SmartMeasureGenerator'):
            Object.SmartMeasureGenerator = CollectionProperty(
                type=SmartMeasureContainer,
                name="Smart Measure Data",
                description="Internal Smart Measure measurement data stored on the object.",
            )
    except Exception:
        pass


def unregister_base_types():
    try:
        if hasattr(Object, 'SmartMeasureGenerator'):
            del Object.SmartMeasureGenerator
    except Exception:
        pass
    for cls in reversed(_BASE_TYPES):
        _safe_unregister_base_class(cls)



# ------------------------------------------------------------------
# Define UI class
# SmartMeasure
# ------------------------------------------------------------------
class SMART_MEASURE_PT_Edit(Panel):
    bl_idname = "SMART_MEASURE_PT_Edit"
    bl_label = "Items"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Overlay'
    bl_parent_id = 'SMART_MEASURE_PT_Main'
    bl_order = 121

    # -----------------------------------------------------
    # Verify if visible
    # -----------------------------------------------------
    @classmethod
    def poll(cls, context):
        mainobject = _safe_context_object(context)
        if mainobject is None:
            return False
        if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
            return False
        else:
            mp = mainobject.SmartMeasureGenerator[0]
            if mp.smart_measure_num > 0:
                return True
            else:
                return False

    # -----------------------------------------------------
    # Draw (create UI interface)
    # -----------------------------------------------------
    # noinspection PyUnusedLocal
    def draw(self, context):
        layout = self.layout
        scene = _safe_context_scene(context)
        if scene is None:
            return
        mainobject = _safe_context_object(context)
        if mainobject is not None:
            if _has_smart_measure_items(mainobject):
                box = layout.box()
                row = box.row()
                row.label(text=mainobject.name, translate=False)
                col = box.column(align=True)
                col.prop(scene, 'smart_measure_gl_precision', text=_("Precision"))
                col.prop(scene, 'smart_measure_units')
                row = box.row()
                row.prop(scene, 'smart_measure_gl_show_d', text=_("Distances"), toggle=True, **_icon_kwargs('NONE', 'DRIVER_DISTANCE'))
                row.prop(scene, 'smart_measure_gl_show_n', text=_("Texts"), toggle=True, **_icon_kwargs('font', 'FONT_DATA'))
                row = box.row()
                row.prop(scene, 'smart_measure_hide_units', text=_("Hide measurement unit"))
                # Scale factor
                row = box.row()
                row.prop(scene, 'smart_measure_scale', text=_("Scale"))
                if scene.smart_measure_scale is True:
                    split = row.split(factor=0.25, align=False)
                    split.prop(scene, 'smart_measure_scale_color', text="")
                    split.prop(scene, 'smart_measure_scale_factor', text="1")
                    col = box.column(align=True)
                    col.prop(scene, 'smart_measure_gl_scaletxt', text="", placeholder=_("Scale:"))
                    col.prop(scene, 'smart_measure_scale_font')
                    col.prop(scene, 'smart_measure_scale_precision', text=_("Precision"))
                    col.prop(scene, 'smart_measure_scale_pos_x')
                    col.prop(scene, 'smart_measure_scale_pos_y')

                # Override
                row = box.row()
                row.prop(scene, 'smart_measure_ovr', text=_("Override"))
                if scene.smart_measure_ovr is True:
                    split = row.split(factor=0.25, align=False)
                    split.prop(scene, 'smart_measure_ovr_color', text="")
                    split.prop(scene, 'smart_measure_ovr_width', text=_("Width"))
                    col = box.column(align=True)
                    col.prop(scene, 'smart_measure_ovr_font', text=_("Font"))
                    col.prop(scene, 'smart_measure_ovr_font_align', text="")
                    if scene.smart_measure_ovr_font_align == 'L':
                        col.prop(scene, 'smart_measure_ovr_font_rotation', text=_("Rotate"))

                mp = _smart_measure_items(mainobject)
                if mp is None:
                    return
                # -----------------
                # loop
                # -----------------
                if mp.smart_measure_num > 0:
                    box = layout.box()
                    row = box.row(align=True)
                    row.operator("smart_measure.expandallsegment", text=_("Expand all"), **_icon_kwargs('add', 'ADD'))
                    row.operator("smart_measure.collapseallsegment", text=_("Collapse all"), **_icon_kwargs('tridown', 'TRIA_DOWN'))
                    for idx in range(mp.smart_measure_num):
                        if mp.smart_measure_segments[idx].glfree is False:
                            add_item(box, idx, mp.smart_measure_segments[idx], scene)

                row = box.row()
                row.operator("smart_measure.deleteallsegment", text=_("Delete all"), **_icon_kwargs('delete', 'TRASH'))
                # -----------------
                # Sum loop segments
                # -----------------
                if mp.smart_measure_num > 0:
                    scale = scene.unit_settings.scale_length
                    tx = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S",
                          "T", "U", "V", "W", "X", "Y", "Z"]
                    tot = [0.0] * len(tx)
                    ac = [False] * len(tx)
                    myobj = mainobject
                    try:
                        obverts = get_mesh_vertices(myobj)
                    except Exception:
                        obverts = []
                    viewtot = False
                    for idx in range(mp.smart_measure_num):
                        ms = mp.smart_measure_segments[idx]
                        if (ms.gltype == 1 or ms.gltype == 12
                            or ms.gltype == 13 or ms.gltype == 14) and ms.gltot != '99' \
                                and ms.glfree is False:  # only segments
                            if 0 <= int(ms.glpointa) < len(obverts) and 0 <= int(ms.glpointb) < len(obverts):
                                p1 = get_point(obverts[ms.glpointa].co, myobj)
                                if ms.gltype == 1:
                                    p2 = get_point(obverts[ms.glpointb].co, myobj)
                                elif ms.gltype == 12:
                                    p2 = get_point((0.0,
                                                    obverts[ms.glpointa].co[1],
                                                    obverts[ms.glpointa].co[2]), myobj)
                                elif ms.gltype == 13:
                                    p2 = get_point((obverts[ms.glpointa].co[0],
                                                    0.0,
                                                    obverts[ms.glpointa].co[2]), myobj)
                                else:
                                    p2 = get_point((obverts[ms.glpointa].co[0],
                                                    obverts[ms.glpointa].co[1],
                                                    0.0), myobj)

                                dist, distloc = distance(p1, p2, ms.glocx, ms.glocy, ms.glocz)
                                if dist == distloc:
                                    usedist = dist
                                else:
                                    usedist = distloc
                                usedist *= scale
                                try:
                                    total_index = int(ms.gltot)
                                except Exception:
                                    total_index = -1
                                if 0 <= total_index < len(tot):
                                    tot[total_index] += usedist
                                    ac[total_index] = True
                                    viewtot = True
                    # -----------------
                    # Print values
                    # -----------------
                    if viewtot is True:
                        pr = scene.smart_measure_gl_precision
                        fmt = "%1." + str(pr) + "f"
                        units = scene.smart_measure_units

                        box = layout.box()
                        box.label(text=_("Totals"), **_icon_kwargs('sum', 'SOLO_ON'))
                        final = 0
                        for idx in range(len(tot)):
                            if ac[idx] is True:
                                final += tot[idx]
                                tx_dist = format_distance(fmt, units, tot[idx])
                                row = box.row(align=True)
                                row.label(text=_("Group") + " " + tx[idx] + ":")
                                row.label(text=" ")
                                row.label(text=tx_dist)

                        # Grand total
                        row = box.row(align=True)
                        row.label(text="")
                        row.label(text=" ")
                        row.label(text="-" * 20)
                        tx_dist = format_distance(fmt, units, final)

                        row = box.row(align=True)
                        row.label(text="")
                        row.label(text=" ")
                        row.label(text=tx_dist)
                        # delete all
                        row = box.row()
                        row.operator("smart_measure.deleteallsum", text=_("Delete all"), **_icon_kwargs('delete', 'TRASH'))


# -----------------------------------------------------
# Add segment options to the panel.
# -----------------------------------------------------
def add_item(box, idx, segment, scene=None):
    scene = scene or _safe_context_scene(getattr(bpy, 'context', None))
    if scene is None:
        return
    row = box.row(align=True)
    if segment.glview is True:
        icon = "HIDE_OFF"
    else:
        icon = "HIDE_ON"

    row.prop(segment, 'glview', text="", toggle=True, **_icon_kwargs('NONE', icon))
    row.prop(segment, 'gladvance', text="", toggle=True, **_icon_kwargs('settings', 'PREFERENCES'))
    if segment.gltype == 20:  # Area special
        split = row.split(factor=0.15, align=True)
        split.prop(segment, 'glcolorarea', text="")
        split = split.split(factor=0.20, align=True)
        split.prop(segment, 'glcolor', text="")
    else:
        split = row.split(factor=0.25, align=True)
        split.prop(segment, 'glcolor', text="")
    split.prop(segment, 'gltxt', text="")
    op = row.operator("smart_measure.deletesegment", text="", emboss=True, **_icon_kwargs('delete', 'TRASH'))
    op.tag = idx  # saves internal data
    if segment.gladvance is True:
        col = box.column(align=True)
        col.prop(segment, 'glfont_size', text=_("Font"))
        col.prop(segment, 'glfont_align', text="")
        if segment.glfont_align == 'L':
            col.prop(segment, 'glfont_rotat', text=_("Rotate"))
        if segment.gltype != 9 and segment.gltype != 10 and segment.gltype != 20:
            box.prop(segment, 'glspace', text=_("Hint Space"))
        row = box.row(align=True)
        row.prop(segment, 'glfontx', text="X")
        row.prop(segment, 'glfonty', text="Y")

        # Arrows
        if segment.gltype != 9 and segment.gltype != 10 and segment.gltype != 20:
            row = box.row(align=True)
            row.prop(segment, 'glarrow_a', text="")
            row.prop(segment, 'glarrow_b', text="")
            if segment.glarrow_a != '99' or segment.glarrow_b != '99':
                box.prop(segment, 'glarrow_s', text=_("Arrow Size"))

        if segment.gltype != 2 and segment.gltype != 10:
            row = box.row(align=True)
            if scene.smart_measure_gl_show_d is True and segment.gltype != 9:
                row.prop(segment, 'gldist', text=_("Distance"), toggle=True, **_icon_kwargs('NONE', 'DRIVER_DISTANCE'))
            if scene.smart_measure_gl_show_n is True:
                row.prop(segment, 'glnames', text=_("Text"), toggle=True, **_icon_kwargs('font', 'FONT_DATA'))
            # sum distances
            if segment.gltype == 1 or segment.gltype == 12 or segment.gltype == 13 or segment.gltype == 14:
                box.prop(segment, 'gltot', text=_("Sum"))

        if segment.gltype != 9 and segment.gltype != 10 and segment.gltype != 20:
            box.prop(segment, 'glwidth', text=_("Line"))
            box.prop(segment, 'gldefault', text=_("Automatic position"))
            if segment.gldefault is False:
                row = box.row(align=True)
                row.prop(segment, 'glnormalx', text="X")
                row.prop(segment, 'glnormaly', text="Y")
                row.prop(segment, 'glnormalz', text="Z")

        # Loc axis
        if segment.gltype != 2 and segment.gltype != 9 and segment.gltype != 10 \
                and segment.gltype != 11 and segment.gltype != 12 and segment.gltype != 13 \
                and segment.gltype != 14 and segment.gltype != 20:
            row = box.row(align=True)
            row.prop(segment, 'glocx', text="X", toggle=True)
            row.prop(segment, 'glocy', text="Y", toggle=True)
            row.prop(segment, 'glocz', text="Z", toggle=True)
            if segment.glocx is False or segment.glocy is False or segment.glocz is False:
                if segment.gltype == 1:
                    box.prop(segment, 'glorto', text=_("Ortho"))
                box.prop(segment, 'glocwarning', text=_("Warning"))
                # orthogonal (only segments)
                if segment.gltype == 1:
                    if segment.glorto != "99":
                        row = box.row(align=True)
                        row.prop(segment, 'glorto_x', text="X", toggle=True)
                        row.prop(segment, 'glorto_y', text="Y", toggle=True)
                        row.prop(segment, 'glorto_z', text="Z", toggle=True)

        # Arc special
        if segment.gltype == 11:
            for prop_name, text_prop, label in (
                ('glarc_rad', 'glarc_txradio', _("Radius")),
                ('glarc_len', 'glarc_txlen', _("Length")),
                ('glarc_ang', 'glarc_txang', _("Angle")),
            ):
                row = box.row(align=True)
                row.prop(segment, prop_name, text=label)
                row.prop(segment, text_prop, text="")
            box.prop(segment, 'glarc_full', text=_("Full Circle"))
            if segment.glarc_rad is True:
                box.prop(segment, 'glarc_extrad', text=_("Adapt radio"))

            row = box.row(align=True)
            row.prop(segment, 'glarc_a', text="")
            row.prop(segment, 'glarc_b', text="")
            if segment.glarc_a != '99' or segment.glarc_b != '99':
                box.prop(segment, 'glarc_s', text=_("Arrow Size"))


# ------------------------------------------------------------------
# Define panel class for main functions.
# ------------------------------------------------------------------
class SMART_MEASURE_PT_Main(Panel):
    bl_idname = "SMART_MEASURE_PT_Main"
    bl_label = "Smart Measure Tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Overlay'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 120

    @classmethod
    def poll(cls, context):
        return _smart_measure_panel_context_safe(context)

    # ------------------------------
    # Draw UI
    # ------------------------------
    def draw(self, context):
        layout = self.layout
        scene = _safe_context_scene(context)
        if scene is None:
            return
        # ------------------------------
        # Tool Buttons
        # ------------------------------
        box = layout.box()
        row = box.row(align=True)
        row.prop(scene, "smart_measure_gl_ghost", text=_("All"), **_icon_kwargs('ghost', 'GHOST_ENABLED'))

        # Tools
        box = layout.box()
        box.label(text=_("Add Measures"))
        row = box.row()
        row.operator("smart_measure.addsegment", text=_("Segment"), **_icon_kwargs('segment', 'DRIVER_DISTANCE'))
        row.prop(scene, "smart_measure_sum", text=_("Sum"), **_icon_kwargs('sum', 'SOLO_ON'))

        # To origin
        row = box.row()
        op = row.operator("smart_measure.addsegmentorto", text="X", **_icon_kwargs('axis_x', 'EMPTY_ARROWS'))
        op.tag = 0  # saves internal data
        op = row.operator("smart_measure.addsegmentorto", text="Y", **_icon_kwargs('axis_y', 'EMPTY_ARROWS'))
        op.tag = 1  # saves internal data
        op = row.operator("smart_measure.addsegmentorto", text="Z", **_icon_kwargs('axis_z', 'EMPTY_ARROWS'))
        op.tag = 2  # saves internal data

        row = box.row()
        row.operator("smart_measure.addangle", text=_("Angle"), **_icon_kwargs('angle', 'LINCURVE'))
        row.operator("smart_measure.addarc", text=_("Arc"), **_icon_kwargs('arc', 'LINCURVE'))

        row = box.row()
        row.operator("smart_measure.addlabel", text=_("Label"), **_icon_kwargs('label', 'FONT_DATA'))
        row.operator("smart_measure.addnote", text=_("Annotation"), **_icon_kwargs('note', 'FONT_DATA'))

        row = box.row()
        row.operator("smart_measure.addlink", text=_("Link"), **_icon_kwargs('link', 'LINKED'))
        row.operator("smart_measure.addorigin", text=_("Origin"), **_icon_kwargs('NONE', 'OBJECT_ORIGIN'))

        row = box.row()
        row.operator("smart_measure.addarea", text=_("Area"), **_icon_kwargs('area', 'MESH_GRID'))

        row = box.row()
        row.operator("mesh.smart_measure_sum_edge_lengths", text=_("Sum Selected Edges"), **_icon_kwargs('sum', 'EDGESEL'))

        # ------------------------------
        # Debug data
        # ------------------------------
        debug_header, debug_body = layout.panel_prop(scene, "smart_measure_debug")
        debug_header.label(text=_("Mesh Debug"))
        if debug_body is not None:
            def _debug_row(color_prop):
                split = debug_body.split(factor=0.15, align=True)
                split.prop(scene, color_prop, text="")
                return split.column(align=True)

            col = _debug_row('smart_measure_debug_obj_color')
            col.prop(scene, "smart_measure_debug_objects", **_icon_kwargs('object_hover', 'OBJECT_DATA'))
            col.prop(scene, "smart_measure_debug_object_loc", **_icon_kwargs('NONE', 'EMPTY_DATA'))

            col = _debug_row('smart_measure_debug_vert_color')
            col.prop(scene, "smart_measure_debug_vertices", **_icon_kwargs('vertex', 'VERTEXSEL'))
            col.prop(scene, "smart_measure_debug_vert_loc", **_icon_kwargs('NONE', 'EMPTY_DATA'))
            if scene.smart_measure_debug_vert_loc is True:
                col.prop(scene, 'smart_measure_debug_vert_loc_toggle', text="")

            col = _debug_row('smart_measure_debug_edge_color')
            col.prop(scene, "smart_measure_debug_edges", **_icon_kwargs('edge', 'EDGESEL'))

            col = _debug_row('smart_measure_debug_face_color')
            col.prop(scene, "smart_measure_debug_faces", **_icon_kwargs('face', 'FACESEL'))

            col = _debug_row('smart_measure_debug_norm_color')
            col.prop(scene, "smart_measure_debug_normals", **_icon_kwargs('NONE', 'OBJECT_ORIGIN'))
            if scene.smart_measure_debug_normals is True:
                col.prop(scene, "smart_measure_debug_normal_size")
                col.prop(scene, "smart_measure_debug_normal_details")
                col.prop(scene, 'smart_measure_debug_width', text=_("Thickness"))

            debug_body.prop(scene, "smart_measure_debug_select", **_icon_kwargs('ghost', 'GHOST_ENABLED'))
            col = debug_body.column(align=True)
            col.prop(scene, 'smart_measure_debug_font', text=_("Font"))
            col.prop(scene, 'smart_measure_debug_precision', text=_("Precision"))


# ------------------------------------------------------------------
# Define panel class for conf functions.
# ------------------------------------------------------------------
class SMART_MEASURE_PT_Conf(Panel):
    bl_idname = "SMART_MEASURE_PT_Conf"
    bl_label = "Configuration"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Overlay'
    bl_parent_id = 'SMART_MEASURE_PT_Main'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 122

    @classmethod
    def poll(cls, context):
        return _smart_measure_panel_context_safe(context)

    # ------------------------------
    # Draw UI
    # ------------------------------
    def draw(self, context):
        layout = self.layout
        scene = _safe_context_scene(context)
        if scene is None:
            return

        # Configuration data
        box = layout.box()
        row = box.row()
        split = row.split(factor=0.2, align=True)
        split.label(text=_("Text"))
        split = split.split(factor=0.2, align=True)
        split.prop(scene, "smart_measure_default_color", text="")
        split.prop(scene, "smart_measure_gl_txt", text="")
        box.prop(scene, "smart_measure_hint_space", text=_("Hint Space"))
        box.prop(scene, "smart_measure_font_align", text="")
        # Arrow
        row = box.row(align=True)
        row.prop(scene, "smart_measure_glarrow_a", text="")
        row.prop(scene, "smart_measure_glarrow_b", text="")
        if scene.smart_measure_glarrow_a != '99' or scene.smart_measure_glarrow_b != '99':
            box.prop(scene, "smart_measure_glarrow_s", text=_("Arrow Size"))
        col = box.column(align=True)
        col.prop(scene, "smart_measure_font_size", text=_("Font Size"))
        if scene.smart_measure_font_align == 'L':
            col.prop(scene, "smart_measure_font_rotation", text=_("Rotate"))


# ------------------------------------------------------------------
# Define panel class for render functions.
# ------------------------------------------------------------------
class SMART_MEASURE_PT_Render(Panel):
    bl_idname = "SMART_MEASURE_PT_Render"
    bl_label = "Render"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Smart Overlay'
    bl_parent_id = 'SMART_MEASURE_PT_Main'
    bl_options = {'DEFAULT_CLOSED'}
    bl_order = 123

    @classmethod
    def poll(cls, context):
        return _smart_measure_panel_context_safe(context)

    # ------------------------------
    # Draw UI
    # ------------------------------
    def draw(self, context):
        layout = self.layout
        scene = _safe_context_scene(context)
        if scene is None:
            return

        # Render settings
        box = layout.box()
        row = box.row()
        row.prop(scene, "smart_measure_render_type", text=_("Type"))
        row = box.row()
        row.operator("smart_measure.rendersegment", **_icon_kwargs('render', 'CAMERA_DATA'))
        row = box.row()
        row.prop(scene, "smart_measure_render", text=_("Save render image"))
        row = box.row()
        row.prop(scene, "smart_measure_rf", text=_("Frame"))
        if scene.smart_measure_rf is True:
            row.prop(scene, "smart_measure_rf_color", text="")
            row = box.row()
            row.prop(scene, "smart_measure_rf_border", text=_("Space"))
            row.prop(scene, "smart_measure_rf_line", text=_("Width"))


# -------------------------------------------------------------
# Defines button that adds a measure segment
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddSegment(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addsegment"
    bl_label = "Add"
    bl_description = "(EDITMODE only) Add a new measure segment between 2 vertices (select 2 vertices or more)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH":
                if getattr(context, 'mode', None) == 'EDIT_MESH':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            if mainobject is None:
                return {'CANCELLED'}
            mylist = get_smart_selected(mainobject)
            if len(mylist) < 2:  # if not selected linked vertex
                mylist = get_selected_vertex(mainobject)

            if len(mylist) >= 2:
                if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                    mainobject.SmartMeasureGenerator.add()

                mp = mainobject.SmartMeasureGenerator[0]
                for x in range(0, len(mylist) - 1, 2):
                    # -----------------------
                    # Only if not exist
                    # -----------------------
                    if exist_segment(mp, mylist[x], mylist[x + 1]) is False:
                        # Create all array elements
                        for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                            mp.smart_measure_segments.add()

                        # Set values
                        ms = mp.smart_measure_segments[mp.smart_measure_num]
                        ms.gltype = 1
                        ms.glpointa = mylist[x]
                        ms.glpointb = mylist[x + 1]
                        ms.glarrow_a = scene.smart_measure_glarrow_a
                        ms.glarrow_b = scene.smart_measure_glarrow_b
                        ms.glarrow_s = scene.smart_measure_glarrow_s
                        # color
                        ms.glcolor = scene.smart_measure_default_color
                        # dist
                        ms.glspace = scene.smart_measure_hint_space
                        # text
                        ms.gltxt = scene.smart_measure_gl_txt
                        ms.glfont_size = scene.smart_measure_font_size
                        ms.glfont_align = scene.smart_measure_font_align
                        ms.glfont_rotat = scene.smart_measure_font_rotation
                        # Sum group
                        ms.gltot = scene.smart_measure_sum
                        # Add index
                        mp.smart_measure_num += 1

                # redraw
                context.area.tag_redraw()
                return {'FINISHED'}
            else:
                self.report({'ERROR'},
                            _("Smart Measure: Select at least two vertices for creating measure segment."))
                return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds an area measure
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddArea(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addarea"
    bl_label = "Area"
    bl_description = "(EDITMODE only) Add a new measure for area (select 1 o more faces)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH":
                if getattr(context, 'mode', None) == 'EDIT_MESH':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            if mainobject is None:
                return {'CANCELLED'}
            mylist = get_selected_faces(mainobject)
            if len(mylist) >= 1:
                if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                    mainobject.SmartMeasureGenerator.add()

                mp = mainobject.SmartMeasureGenerator[0]
                mp.smart_measure_segments.add()
                ms = mp.smart_measure_segments[mp.smart_measure_num]
                ms.gltype = 20

                f = -1
                for face in mylist:
                    # Create array elements
                    ms.smart_measure_faces.add()
                    f += 1
                    # Set values
                    mf = ms.smart_measure_faces[f]
                    mf.glface = f
                    i = 0
                    for v in face:
                        mf.smart_measure_index.add()
                        mi = mf.smart_measure_index[i]
                        mi.glidx = v
                        i += 1

                # color
                rgb = scene.smart_measure_default_color
                ms.glcolor = (rgb[0], rgb[1], rgb[2], 0.4)
                # dist
                ms.glspace = scene.smart_measure_hint_space
                # text
                ms.gltxt = scene.smart_measure_gl_txt
                ms.glfont_size = scene.smart_measure_font_size
                ms.glfont_align = scene.smart_measure_font_align
                ms.glfont_rotat = scene.smart_measure_font_rotation
                # Sum group
                ms.gltot = scene.smart_measure_sum
                # Add index
                mp.smart_measure_num += 1
                # redraw
                context.area.tag_redraw()
                return {'FINISHED'}
            else:
                self.report({'ERROR'},
                            _("Smart Measure: Select at least one face for creating area measure."))
                return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds a measure segment to x/y/z origin
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddSegmentOrto(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addsegmentorto"
    bl_label = "Add"
    bl_description = "(EDITMODE only) Add a new measure segment from vertex to object origin for one " \
                     "axis (select 1 vertex)"
    tag: IntProperty(name="Axis", description="Internal axis index used when creating an X, Y, or Z origin measurement segment.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH":
                if getattr(context, 'mode', None) == 'EDIT_MESH':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            if mainobject is None:
                return {'CANCELLED'}
            mylist = get_smart_selected(mainobject)
            if len(mylist) < 1:  # if not selected linked vertex
                mylist = get_selected_vertex(mainobject)

            if len(mylist) >= 1:
                if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                    mainobject.SmartMeasureGenerator.add()

                mp = mainobject.SmartMeasureGenerator[0]
                for x in range(len(mylist)):
                    # -----------------------
                    # Only if not exist
                    # -----------------------
                    if exist_segment(mp, mylist[x], mylist[x], 12 + int(self.tag)) is False:
                        # Create all array elements
                        for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                            mp.smart_measure_segments.add()

                        # Set values
                        ms = mp.smart_measure_segments[mp.smart_measure_num]
                        ms.gltype = 12 + int(self.tag)
                        ms.glpointa = mylist[x]
                        ms.glpointb = mylist[x]
                        ms.glarrow_a = scene.smart_measure_glarrow_a
                        ms.glarrow_b = scene.smart_measure_glarrow_b
                        ms.glarrow_s = scene.smart_measure_glarrow_s
                        # color
                        ms.glcolor = scene.smart_measure_default_color
                        # dist
                        ms.glspace = scene.smart_measure_hint_space
                        # text
                        ms.gltxt = scene.smart_measure_gl_txt
                        ms.glfont_size = scene.smart_measure_font_size
                        ms.glfont_align = scene.smart_measure_font_align
                        ms.glfont_rotat = scene.smart_measure_font_rotation
                        # Sum group
                        ms.gltot = scene.smart_measure_sum
                        # Add index
                        mp.smart_measure_num += 1

                # redraw
                context.area.tag_redraw()
                return {'FINISHED'}
            else:
                self.report({'ERROR'},
                            _("Smart Measure: Select at least one vertex for creating measure segment."))
                return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds an angle measure
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddAngle(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addangle"
    bl_label = "Angle"
    bl_description = "(EDITMODE only) Add a new angle measure (select 3 vertices, 2nd is angle vertex)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH":
                if getattr(context, 'mode', None) == 'EDIT_MESH':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            mylist = get_selected_vertex_history(mainobject)
            if len(mylist) == 3:
                if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                    mainobject.SmartMeasureGenerator.add()

                mp = mainobject.SmartMeasureGenerator[0]
                # -----------------------
                # Only if not exist
                # -----------------------
                if exist_segment(mp, mylist[0], mylist[1], 9, mylist[2]) is False:
                    # Create all array elements
                    for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                        mp.smart_measure_segments.add()

                    # Set values
                    ms = mp.smart_measure_segments[mp.smart_measure_num]
                    ms.gltype = 9
                    ms.glpointa = mylist[0]
                    ms.glpointb = mylist[1]
                    ms.glpointc = mylist[2]
                    # color
                    ms.glcolor = scene.smart_measure_default_color
                    # dist
                    ms.glspace = scene.smart_measure_hint_space
                    # text
                    ms.gltxt = scene.smart_measure_gl_txt
                    ms.glfont_size = scene.smart_measure_font_size
                    ms.glfont_align = scene.smart_measure_font_align
                    ms.glfont_rotat = scene.smart_measure_font_rotation
                    # Add index
                    mp.smart_measure_num += 1

                # redraw
                context.area.tag_redraw()
                return {'FINISHED'}
            else:
                self.report({'ERROR'},
                            _("Smart Measure: Select three vertices for creating angle measure"))
                return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds an arc measure
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddArc(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addarc"
    bl_label = "Angle"
    bl_description = "(EDITMODE only) Add a new arc measure (select 3 vertices of the arc," \
                     " vertices 1st and 3rd are arc extremes)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH":
                if getattr(context, 'mode', None) == 'EDIT_MESH':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            mylist = get_selected_vertex_history(mainobject)
            if len(mylist) == 3:
                if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                    mainobject.SmartMeasureGenerator.add()

                mp = mainobject.SmartMeasureGenerator[0]
                # -----------------------
                # Only if not exist
                # -----------------------
                if exist_segment(mp, mylist[0], mylist[1], 11, mylist[2]) is False:
                    # Create all array elements
                    for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                        mp.smart_measure_segments.add()

                    # Set values
                    ms = mp.smart_measure_segments[mp.smart_measure_num]
                    ms.gltype = 11
                    ms.glpointa = mylist[0]
                    ms.glpointb = mylist[1]
                    ms.glpointc = mylist[2]
                    ms.glarrow_a = scene.smart_measure_glarrow_a
                    ms.glarrow_b = scene.smart_measure_glarrow_b
                    ms.glarrow_s = scene.smart_measure_glarrow_s
                    # color
                    ms.glcolor = scene.smart_measure_default_color
                    # dist
                    ms.glspace = scene.smart_measure_hint_space
                    # text
                    ms.gltxt = scene.smart_measure_gl_txt
                    ms.glfont_size = scene.smart_measure_font_size
                    ms.glfont_align = scene.smart_measure_font_align
                    ms.glfont_rotat = scene.smart_measure_font_rotation
                    # Add index
                    mp.smart_measure_num += 1

                # redraw
                context.area.tag_redraw()
                return {'FINISHED'}
            else:
                self.report({'ERROR'},
                            _("Smart Measure: Select three vertices for creating arc measure"))
                return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds a label segment
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddLabel(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addlabel"
    bl_label = "Add"
    bl_description = "(EDITMODE only) Add a new measure label (select 1 vertex)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH":
                if getattr(context, 'mode', None) == 'EDIT_MESH':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            if mainobject is None:
                return {'CANCELLED'}
            mylist = get_selected_vertex(mainobject)
            if len(mylist) == 1:
                if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                    mainobject.SmartMeasureGenerator.add()

                mp = mainobject.SmartMeasureGenerator[0]
                # -----------------------
                # Only if not exist
                # -----------------------
                if exist_segment(mp, mylist[0], mylist[0], 2) is False:  # Both equal
                    # Create all array elements
                    for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                        mp.smart_measure_segments.add()

                    # Set values
                    ms = mp.smart_measure_segments[mp.smart_measure_num]
                    ms.gltype = 2
                    ms.glpointa = mylist[0]
                    ms.glpointb = mylist[0]  # Equal
                    ms.glarrow_a = scene.smart_measure_glarrow_a
                    ms.glarrow_b = scene.smart_measure_glarrow_b
                    ms.glarrow_s = scene.smart_measure_glarrow_s
                    # color
                    ms.glcolor = scene.smart_measure_default_color
                    # dist
                    ms.glspace = scene.smart_measure_hint_space
                    # text
                    ms.gltxt = scene.smart_measure_gl_txt
                    ms.glfont_size = scene.smart_measure_font_size
                    ms.glfont_align = scene.smart_measure_font_align
                    ms.glfont_rotat = scene.smart_measure_font_rotation
                    # Add index
                    mp.smart_measure_num += 1

                # redraw
                context.area.tag_redraw()
                return {'FINISHED'}
            else:
                self.report({'ERROR'},
                            _("Smart Measure: Select one vertex for creating measure label"))
                return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds a link
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddLink(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addlink"
    bl_label = "Add"
    bl_description = "(OBJECT mode only) Add a new measure between objects (select 2 " \
                     "objects and optionally 1 or 2 vertices)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH" or o.type == "EMPTY" or o.type == "CAMERA" or o.type == "LIGHT":
                if getattr(context, 'mode', None) == 'OBJECT':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            scene = context.scene
            mainobject = _safe_context_object(context)
            if mainobject is None:
                return {'CANCELLED'}
            # -------------------------------
            # Verify number of objects
            # -------------------------------
            if len(context.selected_objects) != 2:
                self.report({'ERROR'},
                            _('Smart Measure: Select two objects only, and optionally 1 vertex or 2 vertices (one of each object)'))
                return {'FINISHED'}
            # Locate other object
            linkobject = None
            for o in context.selected_objects:
                if o.name != mainobject.name:
                    linkobject = o.name
            # Verify destination vertex
            lkobj = bpy.data.objects.get(linkobject)
            if lkobj is None:
                return {'CANCELLED'}
            mylinkvertex = get_selected_vertex(lkobj)
            if len(mylinkvertex) > 1:
                self.report({'ERROR'},
                            _('Smart Measure: The destination object has more than one vertex selected. Select only 1 or none'))
                return {'FINISHED'}
            # Verify origin vertex
            myobjvertex = get_selected_vertex(mainobject)
            if len(myobjvertex) > 1:
                self.report({'ERROR'},
                            _("Smart Measure: The active object has more than one vertex selected. Select only 1 or none"))
                return {'CANCELLED'}

            if myobjvertex:
                link_type = 3 if mylinkvertex else 4
            else:
                link_type = 5 if mylinkvertex else 8
            point_a = myobjvertex[0] if myobjvertex else 0
            point_b = mylinkvertex[0] if mylinkvertex else 0

            if not mainobject.SmartMeasureGenerator:
                mainobject.SmartMeasureGenerator.add()
            mp = mainobject.SmartMeasureGenerator[0]
            for segment in mp.smart_measure_segments[:mp.smart_measure_num]:
                if (not segment.glfree and segment.gltype == link_type
                        and segment.glpointa == point_a and segment.glpointb == point_b
                        and segment.gllink == linkobject):
                    self.report({'WARNING'}, _("Smart Measure: This link already exists"))
                    return {'CANCELLED'}

            for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                mp.smart_measure_segments.add()
            ms = mp.smart_measure_segments[mp.smart_measure_num]
            ms.gltype = link_type
            ms.glpointa = point_a
            ms.glpointb = point_b
            ms.glarrow_a = scene.smart_measure_glarrow_a
            ms.glarrow_b = scene.smart_measure_glarrow_b
            ms.glarrow_s = scene.smart_measure_glarrow_s
            ms.glcolor = scene.smart_measure_default_color
            ms.glspace = scene.smart_measure_hint_space
            ms.gltxt = scene.smart_measure_gl_txt
            ms.glfont_size = scene.smart_measure_font_size
            ms.glfont_align = scene.smart_measure_font_align
            ms.glfont_rotat = scene.smart_measure_font_rotation
            ms.gllink = linkobject
            mp.smart_measure_num += 1
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that adds an origin segment
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddOrigin(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addorigin"
    bl_label = "Add"
    bl_description = "(OBJECT mode only) Add a new measure to origin (select object and optionally 1 vertex)"

    # ------------------------------
    # Poll
    # ------------------------------
    @classmethod
    def poll(cls, context):
        o = _safe_context_object(context)
        if o is None:
            return False
        else:
            if o.type == "MESH" or o.type == "EMPTY" or o.type == "CAMERA" or o.type == "LIGHT":
                if getattr(context, 'mode', None) == 'OBJECT':
                    return True
                else:
                    return False
            else:
                return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            scene = context.scene
            mainobject = _safe_context_object(context)
            if mainobject is None:
                return {'CANCELLED'}
            mylist = get_selected_vertex(mainobject)
            if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                mainobject.SmartMeasureGenerator.add()

            mp = mainobject.SmartMeasureGenerator[0]
            # Create all array elements
            for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                mp.smart_measure_segments.add()

            # -----------------------
            # Set values
            # -----------------------
            ms = mp.smart_measure_segments[mp.smart_measure_num]
            flag = False
            if len(mylist) > 0:
                if len(mylist) == 1:
                    if exist_segment(mp, mylist[0], mylist[0], 6) is False:  # Both equal
                        flag = True
                        # Vertex to origin
                        ms.gltype = 6
                        ms.glpointa = mylist[0]
                        ms.glpointb = mylist[0]
                else:
                    self.report({'ERROR'},
                                _("Smart Measure: Enter in EDITMODE and select one vertex only for creating measure from vertex to origin"))
                    return {'FINISHED'}
            else:
                # Object to origin
                if exist_segment(mp, 0, 0, 7) is False:  # Both equal
                    flag = True
                    ms.gltype = 7
                    ms.glpointa = 0
                    ms.glpointb = 0
            # ------------------
            # only if created
            # ------------------
            if flag is True:
                ms.glarrow_a = scene.smart_measure_glarrow_a
                ms.glarrow_b = scene.smart_measure_glarrow_b
                ms.glarrow_s = scene.smart_measure_glarrow_s
                # color
                ms.glcolor = scene.smart_measure_default_color
                # dist
                ms.glspace = scene.smart_measure_hint_space
                # text
                ms.gltxt = scene.smart_measure_gl_txt
                ms.glfont_size = scene.smart_measure_font_size
                ms.glfont_align = scene.smart_measure_font_align
                ms.glfont_rotat = scene.smart_measure_font_rotation
                # Add index
                mp.smart_measure_num += 1

            # redraw
            context.area.tag_redraw()

            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that deletes a measure segment
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_DeleteSegment(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.deletesegment"
    bl_label = "Delete"
    bl_description = "Delete a measure"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            mainobject = _safe_context_object(context)
            mp = _smart_measure_items(mainobject)
            if mp is None or not mp.smart_measure_segments:
                return {'CANCELLED'}
            if not 0 <= self.tag < len(mp.smart_measure_segments):
                return {'CANCELLED'}
            ms = mp.smart_measure_segments[self.tag]
            ms.glfree = True
            # Delete element
            mp.smart_measure_segments.remove(self.tag)
            mp.smart_measure_num -= 1
            # redraw
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that deletes all measure segments
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_DeleteAllSegment(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.deleteallsegment"
    bl_label = "Delete"
    bl_description = "Delete all measures (it cannot be undone)"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            mainobject = _safe_context_object(context)
            mp = _smart_measure_items(mainobject)
            if mp is None or not mp.smart_measure_segments:
                return {'CANCELLED'}

            while len(mp.smart_measure_segments) > 0:
                mp.smart_measure_segments.remove(0)

            # reset size
            mp.smart_measure_num = len(mp.smart_measure_segments)
            # redraw
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that deletes all measure segment sums
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_DeleteAllSum(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.deleteallsum"
    bl_label = "Delete"
    bl_description = "Delete all sum groups"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Execute button action
    # ------------------------------
    # noinspection PyMethodMayBeStatic
    def execute(self, context):
        mainobject = _safe_context_object(context)
        mp = _smart_measure_items(mainobject)
        if mp is None:
            return {'CANCELLED'}
        for idx in range(mp.smart_measure_num):
            ms = mp.smart_measure_segments[idx]
            ms.gltot = '99'
        return {'FINISHED'}


# -------------------------------------------------------------
# Defines button that expands all measure segments
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_ExpandAllSegment(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.expandallsegment"
    bl_label = "Expand"
    bl_description = "Expand all measure properties"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            mainobject = _safe_context_object(context)
            mp = _smart_measure_items(mainobject)
            if mp is None or not mp.smart_measure_segments:
                return {'CANCELLED'}

            for i in mp.smart_measure_segments:
                i.gladvance = True

            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that collapses all measure segments
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_CollapseAllSegment(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.collapseallsegment"
    bl_label = "Collapse"
    bl_description = "Collapses all measure properties"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            # Add properties
            mainobject = _safe_context_object(context)
            mp = _smart_measure_items(mainobject)
            if mp is None or not mp.smart_measure_segments:
                return {'CANCELLED'}

            for i in mp.smart_measure_segments:
                i.gladvance = False

            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button for render option
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_RenderSegment(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.rendersegment"
    bl_label = "Render"
    bl_description = "Create a render image with measures. Use UV/Image editor to view image generated"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Execute button action
    # ------------------------------
    # noinspection PyMethodMayBeStatic,PyUnusedLocal
    def execute(self, context):
        scene = context.scene
        msg = _("New image created with measures. Open it in UV/image editor")
        camera_msg = _("Unable to render. No camera found")
        # -----------------------------
        # Check camera
        # -----------------------------
        if scene.camera is None:
            self.report({'ERROR'}, camera_msg)
            return {'FINISHED'}
        # -----------------------------
        # Frame render
        # -----------------------------
        if scene.smart_measure_render_type == "1":
            # noinspection PyBroadException
            if render_main(self, context) is True:
                self.report({'INFO'}, msg)
        # -----------------------------
        # Animation
        # -----------------------------
        if scene.smart_measure_render_type == "2":
            oldframe = scene.frame_current
            flag = False
            # loop frames
            for frm in range(scene.frame_start, scene.frame_end + 1):
                scene.frame_set(frm)
                _LOG.info("Smart Measure: Rendering frame %04d", frm)
                flag = render_main(self, context, True)
                if flag is False:
                    break

            scene.frame_current = oldframe
            if flag is True:
                self.report({'INFO'}, msg)

        return {'FINISHED'}

    # ---------------------
    # Set cameraView
    # ---------------------
    # noinspection PyMethodMayBeStatic
    def set_camera_view(self):
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces[0].region_3d.view_perspective = 'CAMERA'

    # -------------------------------------
    # Set only render status
    # -------------------------------------
    # noinspection PyMethodMayBeStatic
    def set_only_render(self, status):
        screen = bpy.context.screen

        v3d = False
        s = None
        # get spaceview_3d in current screen
        for a in screen.areas:
            if a.type == 'VIEW_3D':
                for s in a.spaces:
                    if s.type == 'VIEW_3D':
                        v3d = s
                        break

        if v3d is not False:
            s.show_only_render = status


# -------------------------------------------------------------
# Defines a new note
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_AddNote(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.addnote"
    bl_label = "Note"
    bl_description = "(OBJECT mode only) Add a new annotation"
    tag: IntProperty(name="Measure Index", description="Internal Smart Measure item index used by this operation.", default=0, options={'HIDDEN', 'SKIP_SAVE'})

    # ------------------------------
    # Poll
    # ------------------------------
    # noinspection PyUnusedLocal
    @classmethod
    def poll(cls, context):
        if getattr(context, 'mode', None) == 'OBJECT':
            return True
        else:
            return False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            bpy.ops.object.empty_add(type='PLAIN_AXES')
            
            active_obj = _safe_context_object(bpy.context)
            if active_obj is None:
                return {'CANCELLED'}
            myempty = bpy.data.objects.get(active_obj.name)
            if myempty is None:
                return {'CANCELLED'}
            myempty.location = getattr(context.scene, 'cursor').location
            myempty.empty_display_size = 0.01
            myempty.name = "Annotation"
            # Add properties
            scene = context.scene
            mainobject = myempty
            if not hasattr(mainobject, "SmartMeasureGenerator") or len(mainobject.SmartMeasureGenerator) == 0:
                mainobject.SmartMeasureGenerator.add()

            mp = mainobject.SmartMeasureGenerator[0]
            # Create all array elements
            for cont in range(len(mp.smart_measure_segments) - 1, mp.smart_measure_num):
                mp.smart_measure_segments.add()

            # Set values
            ms = mp.smart_measure_segments[mp.smart_measure_num]
            ms.gltype = 10
            ms.glpointa = 0
            ms.glpointb = 0  # Equal
            # color
            ms.glcolor = scene.smart_measure_default_color
            # dist
            ms.glspace = scene.smart_measure_hint_space
            # text
            ms.gltxt = scene.smart_measure_gl_txt
            ms.glfont_size = scene.smart_measure_font_size
            ms.glfont_align = scene.smart_measure_font_align
            ms.glfont_rotat = scene.smart_measure_font_rotation
            # Add index
            mp.smart_measure_num += 1

            # redraw
            context.area.tag_redraw()
            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Defines button that enables/disables the tip display
#
# -------------------------------------------------------------
class SMART_MEASURE_OT_RunHintDisplay(Operator):
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    bl_idname = "smart_measure.runopengl"
    bl_label = "Display hint data manager"
    bl_description = "Main control for enabling or disabling the display of measurements in the viewport"

    _handle = None  # keep function handler

    # ----------------------------------
    # Enable gl drawing adding handler
    # ----------------------------------
    @staticmethod
    def handle_add(self, context):
        if SMART_MEASURE_OT_RunHintDisplay._handle is None:
            SMART_MEASURE_OT_RunHintDisplay._handle = SpaceView3D.draw_handler_add(draw_callback_px, (self, context),
                                                                        'WINDOW',
                                                                        'POST_PIXEL')
            context.window_manager.smart_measure_run_opengl = True

    # ------------------------------------
    # Disable gl drawing removing handler
    # ------------------------------------
    # noinspection PyUnusedLocal
    @staticmethod
    def handle_remove(self, context):
        if SMART_MEASURE_OT_RunHintDisplay._handle is not None:
            SpaceView3D.draw_handler_remove(SMART_MEASURE_OT_RunHintDisplay._handle, 'WINDOW')
        SMART_MEASURE_OT_RunHintDisplay._handle = None
        context.window_manager.smart_measure_run_opengl = False

    # ------------------------------
    # Execute button action
    # ------------------------------
    def execute(self, context):
        if context.area.type == 'VIEW_3D':
            if context.window_manager.smart_measure_run_opengl is False:
                self.handle_add(self, context)
                context.area.tag_redraw()
            else:
                self.handle_remove(self, context)
                context.area.tag_redraw()

            _queue_suite_settings_save(context)
            return {'FINISHED'}
        else:
            self.report({'WARNING'},
                        _("View3D not found, cannot run operator"))

        return {'CANCELLED'}


# -------------------------------------------------------------
# Handle all draw routines (OpenGL main entry point)
#
# -------------------------------------------------------------
def draw_main(context):
    try:
        area = getattr(context, 'area', None)
        space_data = getattr(context, 'space_data', None)
        region = getattr(context, 'region', None) or getattr(bpy.context, 'region', None)
        if area is None or getattr(area, 'type', None) != 'VIEW_3D' or space_data is None or getattr(space_data, 'type', None) != 'VIEW_3D':
            return
    except Exception:
        return
    # Detect if Quadview to get drawing area
    try:
        quadviews = getattr(space_data, 'region_quadviews', None)
    except Exception:
        quadviews = None
    if not quadviews:
        rv3d = getattr(space_data, 'region_3d', None)
        if rv3d is None:
            return
    else:
        # verify area
        i = -1
        for region in getattr(area, 'regions', ()) or ():
            if region.type == 'WINDOW':
                i += 1
                if getattr(getattr(context, 'region', None), 'id', None) == getattr(region, 'id', None):
                    break
        else:
            return

        rv3d = quadviews[i]

    scene = _safe_context_scene(context)
    if scene is None:
        return

    # Display selected or all
    if scene.smart_measure_gl_ghost is False:
        objlist = getattr(context, 'selected_objects', ()) or ()
    else:
        objlist = getattr(getattr(context, 'view_layer', None), 'objects', ()) or ()

    # Enable drawing
    gpu.state.blend_set('ALPHA')
    try:
        # ---------------------------------------
        # Generate all OpenGL calls for measures
        # ---------------------------------------
        for myobj in objlist:
            if myobj.visible_get() is True:
                if hasattr(myobj, "SmartMeasureGenerator") and len(myobj.SmartMeasureGenerator) > 0:
                    op = myobj.SmartMeasureGenerator[0]
                    draw_segments(context, myobj, op, region, rv3d)

        # ---------------------------------------
        # Generate all OpenGL calls for debug
        # ---------------------------------------
        if scene.smart_measure_debug is True:
            selobj = getattr(context, 'selected_objects', ()) or ()
            for myobj in selobj:
                if scene.smart_measure_debug_objects is True:
                    draw_object(context, myobj, region, rv3d)
                elif scene.smart_measure_debug_object_loc is True:
                    draw_object(context, myobj, region, rv3d)
                if scene.smart_measure_debug_vertices is True:
                    draw_vertices(context, myobj, region, rv3d)
                elif scene.smart_measure_debug_vert_loc is True:
                    draw_vertices(context, myobj, region, rv3d)
                if scene.smart_measure_debug_edges is True:
                    draw_edges(context, myobj, region, rv3d)
                if scene.smart_measure_debug_faces is True or scene.smart_measure_debug_normals is True:
                    draw_faces(context, myobj, region, rv3d)
    finally:
        # -----------------------
        # restore defaults
        # -----------------------
        _sos_reset_gpu_state_after_draw()


# -------------------------------------------------------------
# Handler for drawing OpenGl
# -------------------------------------------------------------
# noinspection PyUnusedLocal
def draw_callback_px(self, context):
    _sos_gpu_snapshot = _sos_push_gpu_state_restore()
    _sos_clip_token = None
    try:
        try:
            _sos_clip_token = _sos_mesh_runtime._sos_begin_post_pixel_ui_region_clip(context or bpy.context)
        except Exception:
            _sos_clip_token = None
        draw_main(context)
    finally:
        try:
            blf.disable(0, ROTATION)
        except Exception:
            pass
        try:
            blf.disable(0, blf.SHADOW)
        except Exception:
            pass
        try:
            _sos_mesh_runtime._sos_end_post_pixel_ui_region_clip(_sos_clip_token)
        except Exception:
            pass
        _sos_pop_gpu_state_restore(_sos_gpu_snapshot, ui_safe=True)


# -------------------------------------------------------------
# Check if the segment already exist
#
# -------------------------------------------------------------
def exist_segment(mp, pointa, pointb, typ=1, pointc=None):
    #  for ms in mp.smart_measure_segments[mp.smart_measure_num]
    for ms in mp.smart_measure_segments:
        if ms.gltype == typ and ms.glfree is False:
            if typ != 9:
                if ms.glpointa == pointa and ms.glpointb == pointb:
                    return True
                if ms.glpointa == pointb and ms.glpointb == pointa:
                    return True
            else:
                if ms.glpointa == pointa and ms.glpointb == pointb and ms.glpointc == pointc:
                    return True

    return False


# -------------------------------------------------------------
# Get vertex selected
# -------------------------------------------------------------
def get_selected_vertex(myobject):
    mylist = []
    # if not mesh, no vertex
    if myobject is None:
        return mylist
    try:
        obj_type = myobject.type
    except Exception:
        return mylist
    if obj_type != "MESH":
        return mylist
    # --------------------
    # meshes
    # --------------------
    oldobj = _safe_context_object(bpy.context)
    bpy.context.view_layer.objects.active = myobject
    flag = False
    if myobject.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
        flag = True

    bm = from_edit_mesh(myobject.data)
    tv = len(bm.verts)
    for v in bm.verts:
        if v.select:
            mylist.append(v.index)

    if flag is True:
        bpy.ops.object.editmode_toggle()
    # Back context object
    bpy.context.view_layer.objects.active = oldobj

    # if select all vertices, then use origin
    if tv == len(mylist):
        return []

    return mylist


# -------------------------------------------------------------
# Get vertex selected
# -------------------------------------------------------------
def get_selected_vertex_history(myobject):
    mylist = []
    # if not mesh, no vertex
    if myobject is None:
        return mylist
    try:
        obj_type = myobject.type
    except Exception:
        return mylist
    if obj_type != "MESH":
        return mylist
    # --------------------
    # meshes
    # --------------------
    oldobj = _safe_context_object(bpy.context)
    bpy.context.view_layer.objects.active = myobject
    flag = False
    if myobject.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
        flag = True

    bm = from_edit_mesh(myobject.data)
    for v in bm.select_history:
        mylist.append(v.index)

    if flag is True:
        bpy.ops.object.editmode_toggle()
    # Back context object
    bpy.context.view_layer.objects.active = oldobj

    return mylist


# -------------------------------------------------------------
# Get vertex selected segments
# -------------------------------------------------------------
def get_smart_selected(myobject):
    mylist = []
    # if not mesh, no vertex
    if myobject is None:
        return mylist
    try:
        obj_type = myobject.type
    except Exception:
        return mylist
    if obj_type != "MESH":
        return mylist
    # --------------------
    # meshes
    # --------------------
    oldobj = _safe_context_object(bpy.context)
    bpy.context.view_layer.objects.active = myobject
    flag = False
    if myobject.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
        flag = True

    bm = from_edit_mesh(myobject.data)
    for e in bm.edges:
        if e.select is True:
            mylist.append(e.verts[0].index)
            mylist.append(e.verts[1].index)

    if flag is True:
        bpy.ops.object.editmode_toggle()
    # Back context object
    bpy.context.view_layer.objects.active = oldobj

    return mylist


# -------------------------------------------------------------
# Get vertex selected faces
# -------------------------------------------------------------
def get_selected_faces(myobject):
    mylist = []
    # if not mesh, no vertex
    if myobject is None:
        return mylist
    try:
        obj_type = myobject.type
    except Exception:
        return mylist
    if obj_type != "MESH":
        return mylist
    # --------------------
    # meshes
    # --------------------
    oldobj = _safe_context_object(bpy.context)
    bpy.context.view_layer.objects.active = myobject
    flag = False
    if myobject.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
        flag = True

    bm = from_edit_mesh(myobject.data)
    for e in bm.faces:
        myfaces = []
        if e.select is True:
            for i in range(len(e.verts)):
                myfaces.append(e.verts[i].index)

            mylist.extend([myfaces])

    if flag is True:
        bpy.ops.object.editmode_toggle()
    # Back context object
    bpy.context.view_layer.objects.active = oldobj

    return mylist
