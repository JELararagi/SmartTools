# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

bl_info = {
    'name': 'Smart Measure',
    'author': 'JELararagi',
    'version': (1, 1, 0),
    'blender': (5, 1, 0),
    'location': '3D View > Sidebar > Smart Overlay',
    'description': 'Viewport measurement helpers embedded only inside the single Smart Overlay N-panel.',
    'category': '3D View',
}

if "bpy" in locals():
    import importlib

    importlib.reload(smart_measure_main)
else:
    from . import smart_measure_main

# noinspection PyUnresolvedReferences
import logging

import bpy
from bpy.types import (
        AddonPreferences,
        Scene,
        WindowManager,
        )
from bpy.props import (
        FloatVectorProperty,
        IntProperty,
        BoolProperty,
        StringProperty,
        FloatProperty,
        EnumProperty,
        )

from . import smart_measure_sum_edge_lengths
from .smart_measure_sum_edge_lengths import Sum_Edge_Lengths
from . import properties as grid_properties
from . import operators as grid_operators
from . import overlay as grid_overlay
from . import ui as grid_ui
from . import utils as grid_utils
from .translations.translations import translations_dict as _translations_dict

translations_dict = _translations_dict

_LOG = logging.getLogger(__name__)
_SMART_MEASURE_OPENGL_UPDATE_LOCK = 0
SMART_MEASURE_GRID_OWNER = "smart_measure_grid_owner"
_SMART_MEASURE_GRID_MSGBUS_ACTIVE = False
_SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP = False


def _smart_measure_run_opengl_update(self, context):
    """Synchronize the Smart Measure viewport draw handler from the saved BoolProperty.

    This lets the centralized Always-on Toggle use a real BoolProperty button,
    which keeps Blender's blue active-state overlay stable.
    """
    global _SMART_MEASURE_OPENGL_UPDATE_LOCK
    if _SMART_MEASURE_OPENGL_UPDATE_LOCK > 0:
        return
    target = bool(getattr(self, 'smart_measure_run_opengl', False))
    _SMART_MEASURE_OPENGL_UPDATE_LOCK += 1
    try:
        try:
            op_cls = getattr(smart_measure_main, 'SMART_MEASURE_OT_RunHintDisplay', None)
            if op_cls is not None:
                handle = getattr(op_cls, '_handle', None)
                if target:
                    try:
                        smart_measure_main.register_addon_runtime_support()
                    except Exception:
                        pass
                    if handle is None:
                        op_cls.handle_add(None, context or getattr(bpy, 'context', None))
                else:
                    if handle is not None:
                        op_cls.handle_remove(None, context or getattr(bpy, 'context', None))
                    try:
                        smart_measure_main.unregister_addon_runtime_support()
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            sync_grid_runtime(context, target)
        except Exception:
            pass
        try:
            from .. import settings
            settings.queue_save(context)
        except Exception:
            pass
        try:
            area = getattr(context, 'area', None) if context is not None else getattr(getattr(bpy, 'context', None), 'area', None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
    finally:
        _SMART_MEASURE_OPENGL_UPDATE_LOCK = max(0, _SMART_MEASURE_OPENGL_UPDATE_LOCK - 1)


def _safe_register_runtime_class(cls):
    try:
        from .. import undo_support
        undo_support.prepare_operator_class(cls)
    except Exception:
        pass
    class_name = str(getattr(cls, '__name__', '') or '').strip()
    try:
        existing = getattr(bpy.types, class_name, None) if class_name else None
    except Exception:
        existing = None
    if existing is cls:
        return
    if isinstance(existing, type):
        try:
            bpy.utils.unregister_class(existing)
        except Exception:
            pass
    try:
        bpy.utils.register_class(cls)
    except RuntimeError as exc:
        if 'already registered' not in str(exc):
            raise
        existing = getattr(bpy.types, class_name, None) if class_name else None
        if isinstance(existing, type) and existing is not cls:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            raise


def _safe_unregister_runtime_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_delete_rna_property(owner, prop_name: str) -> None:
    try:
        delattr(owner, str(prop_name))
    except Exception:
        pass


def _safe_remove_menu_func(menu, func) -> None:
    try:
        menu.remove(func)
    except Exception:
        pass


def _safe_append_menu_func_once(menu, func) -> None:
    _safe_remove_menu_func(menu, func)
    try:
        menu.append(func)
    except Exception:
        pass

def subscribe_msgbus():
    """Subscribe to unit-system changes while Smart Measure is active."""
    global _SMART_MEASURE_GRID_MSGBUS_ACTIVE
    if _SMART_MEASURE_GRID_MSGBUS_ACTIVE:
        return
    try:
        bpy.msgbus.clear_by_owner(SMART_MEASURE_GRID_OWNER)
    except Exception:
        pass
    try:
        bpy.msgbus.subscribe_rna(
            key=(bpy.types.UnitSettings, "system"),
            owner=SMART_MEASURE_GRID_OWNER,
            args=(),
            notify=lambda: grid_properties.unit_system_update_handler(bpy.context.scene),
        )
        _SMART_MEASURE_GRID_MSGBUS_ACTIVE = True
    except Exception:
        _SMART_MEASURE_GRID_MSGBUS_ACTIVE = False
_SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP = False


def unsubscribe_msgbus():
    """Remove Smart Measure grid-scale msgbus subscriptions."""
    global _SMART_MEASURE_GRID_MSGBUS_ACTIVE
    try:
        bpy.msgbus.clear_by_owner(SMART_MEASURE_GRID_OWNER)
    except Exception:
        pass
    _SMART_MEASURE_GRID_MSGBUS_ACTIVE = False
_SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP = False


def _iter_view3d_screen_areas():
    if getattr(bpy.app, "background", False) or not hasattr(bpy.data, "screens"):
        return
    try:
        screens = tuple(getattr(bpy.data, "screens", ()) or ())
    except Exception:
        screens = ()
    for screen in screens:
        try:
            areas = tuple(getattr(screen, "areas", ()) or ())
        except Exception:
            areas = ()
        for area in areas:
            try:
                if getattr(area, "type", None) == "VIEW_3D":
                    yield area
            except Exception:
                continue


def _clear_grid_active_areas() -> None:
    try:
        overlays = list(getattr(grid_overlay.SmartMeasureGridOverlay, "overlays", {}).values())
    except Exception:
        overlays = []
    for ov in overlays:
        try:
            ov.unregister()
        except Exception:
            pass
    try:
        getattr(grid_overlay.SmartMeasureGridOverlay, "overlays", {}).clear()
    except Exception:
        pass
    try:
        scenes = tuple(getattr(bpy.data, "scenes", ()) or ())
    except Exception:
        scenes = ()
    for scene in scenes:
        settings = getattr(scene, "smart_measure_grid", None)
        if settings is not None and hasattr(settings, "active_areas"):
            try:
                settings.active_areas = ""
            except Exception:
                pass
    for area in _iter_view3d_screen_areas() or ():
        try:
            area.tag_redraw()
        except Exception:
            pass


def sync_grid_runtime(context=None, enabled: bool | None = None) -> None:
    """Synchronize Smart Measure grid-scale draw handlers with the main toggle."""
    ctx = context or getattr(bpy, "context", None)
    wm = getattr(ctx, "window_manager", None) if ctx is not None else getattr(getattr(bpy, "context", None), "window_manager", None)
    if enabled is None:
        enabled = bool(getattr(wm, "smart_measure_run_opengl", False)) if wm is not None else False
    if enabled:
        subscribe_msgbus()
        try:
            grid_operators.clean_area_ids()
        except Exception:
            pass
        restored = False
        try:
            grid_operators.restore_active_overlays()
            restored = True
        except Exception:
            restored = False
        # New installations have no stored active area IDs. Activate the current
        # 3D View area so the grid-scale part of Smart Measure starts together
        # with the measurement drawing toggle.
        try:
            area = getattr(ctx, "area", None) if ctx is not None else None
            scene = getattr(ctx, "scene", None) if ctx is not None else None
            if area is not None and getattr(area, "type", None) == "VIEW_3D" and scene is not None:
                settings = getattr(scene, "smart_measure_grid", None)
                if settings is not None and not str(getattr(settings, "active_areas", "") or "").strip():
                    ov = grid_overlay.SmartMeasureGridOverlay(area)
                    ov.register(lambda *args: None)
                    area_id = grid_utils.get_stable_area_id(area)
                    settings.active_areas = str(area_id or "")
                    restored = True
        except Exception:
            pass
        if not restored:
            for area in _iter_view3d_screen_areas() or ():
                try:
                    area.tag_redraw()
                except Exception:
                    pass
    else:
        unsubscribe_msgbus()
        _clear_grid_active_areas()


# --------------------------------------------------------------
# Register operators, data types, and embedded panel draw sources
# --------------------------------------------------------------

# Legacy add-on preferences category support (not exposed by Smart Overlay)

# Define embedded Panel classes for compatibility with Smart Measure internals
panels = (
        grid_ui.VIEW3D_PT_smart_measure_grid_overlay,
        smart_measure_main.SMART_MEASURE_PT_Main,
        smart_measure_main.SMART_MEASURE_PT_Edit,
        smart_measure_main.SMART_MEASURE_PT_Conf,
        smart_measure_main.SMART_MEASURE_PT_Render,
        )

EMBEDDED_PANEL_CLASSES = panels


def _smart_measure_panel_category(context=None):
    ctx = context or getattr(bpy, 'context', None)
    addons = getattr(getattr(getattr(ctx, 'preferences', None), 'addons', None), 'get', None)
    if callable(addons):
        for key in (str(__package__ or '').strip(), str(__name__ or '').strip()):
            if not key:
                continue
            try:
                addon = addons(key)
                prefs = getattr(addon, 'preferences', None) if addon is not None else None
                category = str(getattr(prefs, 'category', '') or '').strip()
                if category:
                    return category
            except Exception:
                pass
    return 'Display'


def update_panel(self, context):
    message = "Smart Measure: Updating embedded section sources has failed"
    try:
        for panel in panels:
            # Smart Overlay never registers Smart Measure as a standalone
            # sidebar panel.  If an older build left a registered class behind,
            # remove it; otherwise keep the class as an embedded draw source only.
            if "bl_rna" in panel.__dict__:
                try:
                    bpy.utils.unregister_class(panel)
                except Exception:
                    pass
            panel.bl_category = 'Smart Overlay'

    except Exception:
        try:
            _LOG.exception(message)
        except Exception:
            pass


class SmartMeasure_Pref(AddonPreferences):
    # this must match the addon name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = __package__ if __package__ else __name__

    category: StringProperty(
            name="Tab Category",
            description="Legacy category storage retained only for compatibility; Smart Overlay embeds this UI and does not register a separate N-panel.",
            default="Display",
            update=update_panel
            )

    def draw(self, context):
        # Smart Overlay does not expose Smart Measure settings in Add-on Preferences.
        # The retained preference storage exists only for compatibility.
        pass


# Define menu
# noinspection PyUnusedLocal
classes = (
    smart_measure_main.SMART_MEASURE_OT_RunHintDisplay,
    smart_measure_main.SMART_MEASURE_OT_AddSegment,
    smart_measure_main.SMART_MEASURE_OT_AddArea,
    smart_measure_main.SMART_MEASURE_OT_AddSegmentOrto,
    smart_measure_main.SMART_MEASURE_OT_AddAngle,
    smart_measure_main.SMART_MEASURE_OT_AddArc,
    smart_measure_main.SMART_MEASURE_OT_AddLabel,
    smart_measure_main.SMART_MEASURE_OT_AddNote,
    smart_measure_main.SMART_MEASURE_OT_AddLink,
    smart_measure_main.SMART_MEASURE_OT_AddOrigin,
    smart_measure_main.SMART_MEASURE_OT_DeleteSegment,
    smart_measure_main.SMART_MEASURE_OT_DeleteAllSegment,
    smart_measure_main.SMART_MEASURE_OT_DeleteAllSum,
    smart_measure_main.SMART_MEASURE_OT_RenderSegment,
    smart_measure_main.SMART_MEASURE_OT_ExpandAllSegment,
    smart_measure_main.SMART_MEASURE_OT_CollapseAllSegment,
#    SmartMeasure_Pref,
)


def _tag_smart_measure_redraw(context=None):
    """Request redraw only from a concrete settings event; never poll."""
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None) if ctx is not None else None
    for window in tuple(getattr(wm, 'windows', ()) or ()):
        screen = getattr(window, 'screen', None)
        for area in tuple(getattr(screen, 'areas', ()) or ()):
            if getattr(area, 'type', None) == 'VIEW_3D':
                try:
                    area.tag_redraw()
                except Exception:
                    pass


def _persistent_scene_property(factory):
    """Compose existing RNA behavior with the suite's event-driven save path."""
    def define(*args, **kwargs):
        existing_update = kwargs.get('update')

        def update(instance, context):
            if callable(existing_update):
                existing_update(instance, context)
            _tag_smart_measure_redraw(context)
            try:
                from .. import settings
                settings.queue_save(context, reason='smart_measure_scene_setting')
            except Exception:
                pass

        kwargs['update'] = update
        return factory(*args, **kwargs)
    return define

def register():
    PersistentBoolProperty = _persistent_scene_property(BoolProperty)
    PersistentIntProperty = _persistent_scene_property(IntProperty)
    PersistentFloatProperty = _persistent_scene_property(FloatProperty)
    PersistentStringProperty = _persistent_scene_property(StringProperty)
    PersistentEnumProperty = _persistent_scene_property(EnumProperty)
    PersistentFloatVectorProperty = _persistent_scene_property(FloatVectorProperty)
    _safe_register_runtime_class(grid_properties.SmartMeasureGridSettings)
    bpy.types.Scene.smart_measure_grid = bpy.props.PointerProperty(
        type=grid_properties.SmartMeasureGridSettings,
        name="Smart Measure Grid Scale Settings",
        description="Internal settings storage for the grid-scale display embedded in Smart Measure.",
    )
    for grid_cls in (
        grid_operators.SmartMeasureGridStartOperator,
        grid_operators.SmartMeasureGridStopOperator,
        grid_operators.SmartMeasureGridAnimationPrevOperator,
        grid_operators.SmartMeasureGridAnimationNextOperator,
        grid_operators.SmartMeasureGridSetOriginOperator,
    ):
        _safe_register_runtime_class(grid_cls)
    try:
        bpy.app.translations.register(__name__, translations_dict)
    except Exception:
        pass
    try:
        grid_operators.clean_area_ids()
    except Exception:
        pass

    smart_measure_main.register_base_types()

    for cls in classes:
        _safe_register_runtime_class(cls)

    # Define properties
    Scene.smart_measure_default_color = PersistentFloatVectorProperty(
        name="Default color",
        description="Default Color",
        default=(0.173, 0.545, 1.0, 1.0),
        min=0.1,
        max=1,
        subtype='COLOR',
        size=4)
    Scene.smart_measure_font_size = PersistentIntProperty(name="Text Size",
                                            description="Default text size",
                                            default=14, min=10, max=150)
    Scene.smart_measure_hint_space = PersistentFloatProperty(name='Separation', min=0, max=100, default=0.1,
                                               precision=3,
                                               description="Default distance to display measure")
    Scene.smart_measure_gl_ghost = PersistentBoolProperty(name="All",
                                            description="Display measures for all objects,"
                                                        " not only selected",
                                            default=True)
    Scene.smart_measure_gl_txt = PersistentStringProperty(name="Text", maxlen=256,
                                            description="Short description (use | for line break)")

    Scene.smart_measure_gl_precision = PersistentIntProperty(name='Precision', min=0, max=5, default=2,
                                               description="Number of decimal precision")
    Scene.smart_measure_gl_show_d = PersistentBoolProperty(name="ShowDist",
                                             description="Display distances",
                                             default=True)
    Scene.smart_measure_gl_show_n = PersistentBoolProperty(name="ShowName",
                                             description="Display texts",
                                             default=False)
    Scene.smart_measure_scale = PersistentBoolProperty(name="Scale",
                                         description="Use scale factor",
                                         default=False)
    Scene.smart_measure_scale_factor = PersistentFloatProperty(name='Factor', min=0.001, max=9999999,
                                                 default=1.0,
                                                 precision=3,
                                                 description="Scale factor 1:x")
    Scene.smart_measure_scale_color = PersistentFloatVectorProperty(name="Scale color",
                                                      description="Scale Color",
                                                      default=(1, 1, 0, 1.0),
                                                      min=0.1,
                                                      max=1,
                                                      subtype='COLOR',
                                                      size=4)
    Scene.smart_measure_scale_font = PersistentIntProperty(name="Font",
                                             description="Text size",
                                             default=14, min=10, max=150)
    Scene.smart_measure_scale_pos_x = PersistentIntProperty(name="X Position",
                                              description="Margin on the X axis",
                                              default=5,
                                              min=0,
                                              max=100)
    Scene.smart_measure_scale_pos_y = PersistentIntProperty(name="Y Position",
                                              description="Margin on the Y axis",
                                              default=5,
                                              min=0,
                                              max=100)
    Scene.smart_measure_gl_scaletxt = PersistentStringProperty(name="ScaleText", maxlen=48,
                                                 description="Scale title",
                                                 default="")
    Scene.smart_measure_scale_precision = PersistentIntProperty(name='Precision', min=0, max=5, default=0,
                                                  description="Number of decimal precision")
    Scene.smart_measure_ovr = PersistentBoolProperty(name="Override",
                                       description="Override colors and fonts",
                                       default=False)
    Scene.smart_measure_ovr_font = PersistentIntProperty(name="Font",
                                           description="Override text size",
                                           default=14, min=10, max=150)
    Scene.smart_measure_ovr_color = PersistentFloatVectorProperty(name="Override color",
                                                    description="Override Color",
                                                    default=(1, 0, 0, 1.0),
                                                    min=0.1,
                                                    max=1,
                                                    subtype='COLOR',
                                                    size=4)
    Scene.smart_measure_ovr_width = PersistentIntProperty(name='Override width', min=1, max=10, default=1,
                                            description='override line width')

    Scene.smart_measure_ovr_font_rotation = PersistentIntProperty(name='Rotate', min=0, max=360, default=0,
                                                    description="Text rotation in degrees")
    Scene.smart_measure_ovr_font_align = PersistentEnumProperty(items=(('L', "Left Align", "Use current render"),
                                                         ('C', "Center Align", ""),
                                                         ('R', "Right Align", "")),
                                                  name="Align Font",
                                                  description="Set Font Alignment")
    Scene.smart_measure_units = PersistentEnumProperty(items=(('1', "Automatic", "Use scene units"),
                                                ('2', "Meters", ""),
                                                ('3', "Centimeters", ""),
                                                ('4', "Millimeters", ""),
                                                ('5', "Feet", ""),
                                                ('6', "Inches", "")),
                                         name="Units",
                                         default="2",
                                         description="Units")
    Scene.smart_measure_hide_units = PersistentBoolProperty(name="hide_units",
                                              description="Do not display unit of measurement on viewport",
                                              default=False)
    Scene.smart_measure_render = PersistentBoolProperty(name="Render",
                                          description="Save an image with measures over"
                                                      " render image",
                                          default=False)
    Scene.smart_measure_render_type = PersistentEnumProperty(items=(('1', "Frame", "Render current frame"),
                                                      ('2', "Animation", "")),
                                               name="Render type",
                                               description="Type of render image")
    Scene.smart_measure_sum = PersistentEnumProperty(items=(('99', "-", "Select a group for sum"),
                                              ('0', "A", ""),
                                              ('1', "B", ""),
                                              ('2', "C", ""),
                                              ('3', "D", ""),
                                              ('4', "E", ""),
                                              ('5', "F", ""),
                                              ('6', "G", ""),
                                              ('7', "H", ""),
                                              ('8', "I", ""),
                                              ('9', "J", ""),
                                              ('10', "K", ""),
                                              ('11', "L", ""),
                                              ('12', "M", ""),
                                              ('13', "N", ""),
                                              ('14', "O", ""),
                                              ('15', "P", ""),
                                              ('16', "Q", ""),
                                              ('17', "R", ""),
                                              ('18', "S", ""),
                                              ('19', "T", ""),
                                              ('20', "U", ""),
                                              ('21', "V", ""),
                                              ('22', "W", ""),
                                              ('23', "X", ""),
                                              ('24', "Y", ""),
                                              ('25', "Z", "")),
                                       name="Sum in Group",
                                       description="Add segment length in selected group")

    Scene.smart_measure_rf = PersistentBoolProperty(name="render_frame",
                                      description="Add a frame in render output",
                                      default=False)
    Scene.smart_measure_rf_color = PersistentFloatVectorProperty(name="Fcolor",
                                                   description="Frame Color",
                                                   default=(0.9, 0.9, 0.9, 1.0),
                                                   min=0.1,
                                                   max=1,
                                                   subtype='COLOR',
                                                   size=4)
    Scene.smart_measure_rf_border = PersistentIntProperty(name='fborder ', min=1, max=1000, default=10,
                                            description='Frame space from border')
    Scene.smart_measure_rf_line = PersistentIntProperty(name='fline', min=1, max=10, default=1,
                                          description='Line width for border')

    Scene.smart_measure_glarrow_a = PersistentEnumProperty(items=(('99', "--", "No arrow"),
                                                    ('1', "Line",
                                                     "The point of the arrow are lines"),
                                                    ('2', "Triangle",
                                                     "The point of the arrow is triangle"),
                                                    ('3', "TShape",
                                                     "The point of the arrow is a T")),
                                             name="A end",
                                             description="Add arrows to point A")
    Scene.smart_measure_glarrow_b = PersistentEnumProperty(items=(('99', "--", "No arrow"),
                                                    ('1', "Line",
                                                     "The point of the arrow are lines"),
                                                    ('2', "Triangle",
                                                     "The point of the arrow is triangle"),
                                                    ('3', "TShape",
                                                     "The point of the arrow is a T")),
                                             name="B end",
                                             description="Add arrows to point B")
    Scene.smart_measure_glarrow_s = PersistentIntProperty(name="Size",
                                            description="Arrow size",
                                            default=15, min=6, max=500)

    Scene.smart_measure_debug = PersistentBoolProperty(name="Debug",
                                         description="Display information for debugging"
                                                     " (expand/collapse for enabling or disabling)"
                                                     " this information is only rendered for "
                                                     "selected objects",
                                         default=False)
    Scene.smart_measure_debug_select = PersistentBoolProperty(name="Selected",
                                                description="Display information "
                                                            "only for selected items",
                                                default=False)
    Scene.smart_measure_debug_vertices = PersistentBoolProperty(name="Vertices",
                                                  description="Display vertex index number",
                                                  default=True)
    Scene.smart_measure_debug_objects = PersistentBoolProperty(name="Objects",
                                                 description="Display object scene index number",
                                                 default=False)
    Scene.smart_measure_debug_vert_loc = PersistentBoolProperty(name="Location",
                                                  description="Display vertex location",
                                                  default=False)
    Scene.smart_measure_debug_object_loc = PersistentBoolProperty(name="Location",
                                                    description="Display object location",
                                                    default=False)
    Scene.smart_measure_debug_edges = PersistentBoolProperty(name="Edges",
                                               description="Display edge index number",
                                               default=False)
    Scene.smart_measure_debug_faces = PersistentBoolProperty(name="Faces",
                                               description="Display face index number",
                                               default=False)
    Scene.smart_measure_debug_normals = PersistentBoolProperty(name="Normals",
                                                 description="Display face normal "
                                                             "vector and creation order",
                                                 default=False)
    Scene.smart_measure_debug_normal_details = PersistentBoolProperty(name="Details",
                                                        description="Display face normal details",
                                                        default=True)
    Scene.smart_measure_debug_font = PersistentIntProperty(name="Font",
                                             description="Debug text size",
                                             default=14, min=10, max=150)
    Scene.smart_measure_debug_vert_color = PersistentFloatVectorProperty(name="Debug color",
                                                           description="Debug Color",
                                                           default=(1, 0, 0, 1.0),
                                                           min=0.1,
                                                           max=1,
                                                           subtype='COLOR',
                                                           size=4)
    Scene.smart_measure_debug_face_color = PersistentFloatVectorProperty(name="Debug face color",
                                                           description="Debug face Color",
                                                           default=(0, 1, 0, 1.0),
                                                           min=0.1,
                                                           max=1,
                                                           subtype='COLOR',
                                                           size=4)
    Scene.smart_measure_debug_norm_color = PersistentFloatVectorProperty(name="Debug vector color",
                                                           description="Debug vector Color",
                                                           default=(1.0, 1.0, 0.1, 1.0),
                                                           min=0.1,
                                                           max=1,
                                                           subtype='COLOR',
                                                           size=4)
    Scene.smart_measure_debug_edge_color = PersistentFloatVectorProperty(name="Debug vector color",
                                                           description="Debug vector Color",
                                                           default=(0.1, 1.0, 1.0, 1.0),
                                                           min=0.1,
                                                           max=1,
                                                           subtype='COLOR',
                                                           size=4)
    Scene.smart_measure_debug_obj_color = PersistentFloatVectorProperty(name="Debug vector color",
                                                          description="Debug vector Color",
                                                          default=(1.0, 1.0, 1.0, 1.0),
                                                          min=0.1,
                                                          max=1,
                                                          subtype='COLOR',
                                                          size=4)
    Scene.smart_measure_debug_normal_size = PersistentFloatProperty(name='Len', min=0.001, max=9,
                                                      default=0.5,
                                                      precision=2,
                                                      description="Normal arrow size")
    Scene.smart_measure_debug_width = PersistentIntProperty(name='Debug width', min=1, max=10, default=2,
                                              description='Vector line thickness')
    Scene.smart_measure_debug_precision = PersistentIntProperty(name='Precision', min=0, max=5, default=1,
                                                  description="Number of decimal precision")
    Scene.smart_measure_debug_vert_loc_toggle = PersistentEnumProperty(items=(('1', "Local",
                                                                 "Uses local coordinates"),
                                                                ('2', "Global",
                                                                 "Uses global coordinates")),
                                                         name="Coordinates",
                                                         description="Choose coordinate system")
    Scene.smart_measure_font_rotation = PersistentIntProperty(name='Rotate', min=0, max=360, default=0,
                                                description="Default text rotation in degrees")
    Scene.smart_measure_font_align = PersistentEnumProperty(items=(('L', "Left Align", "Use current render"),
                                                     ('C', "Center Align", ""),
                                                     ('R', "Right Align", "")),
                                              name="Align Font",
                                              description="Set Font Alignment")

    # OpenGL flag.  The root Smart Overlay package normally owns this
    # WindowManager property so the central Always-on Toggle can synchronize all
    # resident tools from one place.  Register it here only for standalone import
    # safety, and never overwrite an existing RNA property during integrated load.
    global _SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP
    wm = WindowManager
    if not hasattr(wm, 'smart_measure_run_opengl'):
        wm.smart_measure_run_opengl = BoolProperty(
            name="Smart Measure",
            description='Show Smart Measure grid-scale labels and measurements in the 3D View. Turn it off to stop drawing them completely.',
            default=False,
            update=_smart_measure_run_opengl_update,
        )
        _SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP = True
    else:
        _SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP = False

    # Register Sum Edge Lengths menu helper.
    _safe_register_runtime_class(Sum_Edge_Lengths)
    _safe_append_menu_func_once(bpy.types.VIEW3D_MT_edit_mesh_edges, smart_measure_sum_edge_lengths.menu_func)

    try:
        sync_grid_runtime(bpy.context)
    except Exception:
        pass

def unregister():
    try:
        grid_operators.save_overlay_states()
    except Exception:
        pass
    unsubscribe_msgbus()
    _clear_grid_active_areas()

    for cls in reversed(classes):
        _safe_unregister_runtime_class(cls)

    # Remove properties.  Each entry is removed independently so a partial
    # registration or failed reload cannot abort the rest of the cleanup.
    for prop_name in (
            'smart_measure_default_color',
            'smart_measure_font_size',
            'smart_measure_hint_space',
            'smart_measure_gl_ghost',
            'smart_measure_gl_txt',
            'smart_measure_gl_precision',
            'smart_measure_gl_show_d',
            'smart_measure_gl_show_n',
            'smart_measure_scale',
            'smart_measure_scale_factor',
            'smart_measure_scale_color',
            'smart_measure_scale_font',
            'smart_measure_scale_pos_x',
            'smart_measure_scale_pos_y',
            'smart_measure_gl_scaletxt',
            'smart_measure_scale_precision',
            'smart_measure_ovr',
            'smart_measure_ovr_font',
            'smart_measure_ovr_color',
            'smart_measure_ovr_width',
            'smart_measure_ovr_font_rotation',
            'smart_measure_ovr_font_align',
            'smart_measure_units',
            'smart_measure_hide_units',
            'smart_measure_render',
            'smart_measure_render_type',
            'smart_measure_sum',
            'smart_measure_rf',
            'smart_measure_rf_color',
            'smart_measure_rf_border',
            'smart_measure_rf_line',
            'smart_measure_glarrow_a',
            'smart_measure_glarrow_b',
            'smart_measure_glarrow_s',
            'smart_measure_debug',
            'smart_measure_debug_select',
            'smart_measure_debug_vertices',
            'smart_measure_debug_objects',
            'smart_measure_debug_edges',
            'smart_measure_debug_faces',
            'smart_measure_debug_normals',
            'smart_measure_debug_normal_details',
            'smart_measure_debug_font',
            'smart_measure_debug_vert_color',
            'smart_measure_debug_face_color',
            'smart_measure_debug_norm_color',
            'smart_measure_debug_edge_color',
            'smart_measure_debug_obj_color',
            'smart_measure_debug_normal_size',
            'smart_measure_debug_width',
            'smart_measure_debug_precision',
            'smart_measure_debug_vert_loc',
            'smart_measure_debug_object_loc',
            'smart_measure_debug_vert_loc_toggle',
            'smart_measure_font_rotation',
            'smart_measure_font_align',
    ):
        _safe_delete_rna_property(Scene, prop_name)

    # remove OpenGL data
    try:
        smart_measure_main.SMART_MEASURE_OT_RunHintDisplay.handle_remove(smart_measure_main.SMART_MEASURE_OT_RunHintDisplay, bpy.context)
    except Exception:
        pass
    global _SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP
    if _SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP:
        _safe_delete_rna_property(WindowManager, 'smart_measure_run_opengl')
        try:
            wm = bpy.context.window_manager
            if 'smart_measure_run_opengl' in wm:
                del wm['smart_measure_run_opengl']
        except Exception:
            pass
        _SMART_MEASURE_OWNS_WM_RUN_OPENGL_PROP = False

    # Remove Sum Edge Lengths.
    _safe_remove_menu_func(bpy.types.VIEW3D_MT_edit_mesh_edges, smart_measure_sum_edge_lengths.menu_func)
    _safe_unregister_runtime_class(Sum_Edge_Lengths)

    smart_measure_main.unregister_addon_runtime_support()
    smart_measure_main.unregister_base_types()

    for grid_cls in (
            grid_operators.SmartMeasureGridSetOriginOperator,
            grid_operators.SmartMeasureGridAnimationNextOperator,
            grid_operators.SmartMeasureGridAnimationPrevOperator,
            grid_operators.SmartMeasureGridStopOperator,
            grid_operators.SmartMeasureGridStartOperator,
    ):
        _safe_unregister_runtime_class(grid_cls)
    _safe_delete_rna_property(bpy.types.Scene, 'smart_measure_grid')
    _safe_unregister_runtime_class(grid_properties.SmartMeasureGridSettings)
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass

if __name__ == '__main__':
    register()
