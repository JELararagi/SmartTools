# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package


import math
import logging
from mathutils import Vector
from bpy_extras.view3d_utils import location_3d_to_region_2d
import bpy

logger = logging.getLogger(__name__)

def get_stable_area_id(area):
    """
    生成一个稳定的区域标识符，在Blender重启后仍然有效。
    使用屏幕名称和区域在屏幕中的索引。
    """
    # 找到该区域所属的屏幕
    for screen in bpy.data.screens:
        for i, a in enumerate(screen.areas):
            if a == area:
                # 返回格式: "屏幕名称:区域类型:区域索引"
                return f"{screen.name}:{area.type}:{i}"
    # 如果找不到匹配的屏幕和区域，返回一个基于指针的临时ID
    return f"temp:{area.as_pointer()}"

def smooth_value(current, last, memory_factor):
    if last is None:
        return current
    return last * memory_factor + current * (1 - memory_factor)

# ---- EASING HELPERS ----
def _clamp01(t):
    return 0.0 if t < 0.0 else 1.0 if t > 1.0 else t

def _ease_smootherstep(t):
    t = _clamp01(t)
    return t * t * t * (t * (6.0 * t - 15.0) + 10.0)

def _ease_out_back(t, overshoot=1.1):
    t = _clamp01(t)
    s = overshoot
    t -= 1.0
    return t * t * ((s + 1.0) * t + s) + 1.0

def _ease_in_back(t, overshoot=1.1):
    t = _clamp01(t)
    s = overshoot
    return t * t * ((s + 1.0) * t - s)

def format_distance(val, unit_system='m', display_mode='AUTO', precision=2):
    """
    格式化距离显示，支持单位自动切换。
    
    :param val: 距离值（米）
    :param unit_system: 单位系统 'm' 或 'ft'
    :param display_mode: 显示模式 'AUTO', 'MM', 'CM', 'M', 'KM', 'IN', 'FT'
    :param precision: 小数点精度
    :return: 格式化后的字符串
    """
    # 如果显示模式是 AUTO，检查场景设置
    if display_mode == 'AUTO':
        # 尝试从场景获取单位设置
        scene = bpy.context.scene
        if scene and hasattr(scene, 'unit_settings'):
            length_unit = scene.unit_settings.length_unit
            if length_unit == 'MILLIMETERS':
                display_mode = 'MM'
            elif length_unit == 'CENTIMETERS':
                display_mode = 'CM'
            elif length_unit == 'METERS':
                display_mode = 'M'
            elif length_unit == 'KILOMETERS':
                display_mode = 'KM'
            # 'ADAPTIVE' 保持 'AUTO' 行为
            
    if unit_system == 'm':
        if display_mode == 'MM':
            return f"{val * 1000:.0f}mm"
        elif display_mode == 'CM':
            # 厘米模式下，如果数值很小，增加精度
            if abs(val * 100) < 10:
                return f"{val * 100:.1f}cm"
            return f"{val * 100:.0f}cm"
        elif display_mode == 'M':
            return f"{val:.{precision}f}m"
        elif display_mode == 'KM':
            return f"{val / 1000:.{precision}f}km"
        
        # AUTO 模式 (公制)
        abs_val = abs(val)
        if abs_val == 0:
            return "0m"
        elif abs_val < 0.01: # < 1cm -> mm
            return f"{val * 1000:.0f}mm"
        elif abs_val < 1.0: # < 1m -> cm
            return f"{val * 100:.0f}cm"
        elif abs_val >= 1000: # >= 1km -> km
            return f"{val / 1000:.1f}km"
        else: # m
            return f"{val:.{precision}f}m"
            
    else: # Imperial
        if display_mode == 'IN':
            return f"{val * 39.3701:.1f}\""
        elif display_mode == 'FT':
            return f"{val * 3.28084:.1f}'"
            
        # AUTO 模式 (英制)
        # 简单实现：小于1英尺用英寸，否则用英尺
        abs_val = abs(val)
        if abs_val < 0.3048: # < 1ft
            return f"{val * 39.3701:.1f}\""
        else:
            return f"{val * 3.28084:.1f}'"

def get_view_bounds(region, rv3d):
    """计算视口边界在世界空间中的范围"""
    from bpy_extras import view3d_utils
    
    # 获取视口的四个角点
    corners_2d = [
        Vector((0, 0)),  # 左下
        Vector((region.width, 0)),  # 右下
        Vector((region.width, region.height)),  # 右上
        Vector((0, region.height))  # 左上
    ]
    
    bounds = {'min_x': float('inf'), 'max_x': float('-inf'),
             'min_y': float('inf'), 'max_y': float('-inf'),
             'min_z': float('inf'), 'max_z': float('-inf')}
    
    camera_location = rv3d.view_matrix.inverted().translation
    
    for co2d in corners_2d:
        # 获取从相机到屏幕点的方向向量
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, co2d)
        # 使用一个足够大的距离
        far_point = camera_location + view_vector * rv3d.view_distance * 10
        
        # 更新边界
        bounds['min_x'] = min(bounds['min_x'], camera_location.x, far_point.x)
        bounds['max_x'] = max(bounds['max_x'], camera_location.x, far_point.x)
        bounds['min_y'] = min(bounds['min_y'], camera_location.y, far_point.y)
        bounds['max_y'] = max(bounds['max_y'], camera_location.y, far_point.y)
        bounds['min_z'] = min(bounds['min_z'], camera_location.z, far_point.z)
        bounds['max_z'] = max(bounds['max_z'], camera_location.z, far_point.z)
    
    return bounds

def get_ortho_view_bounds(region, rv3d):
    """计算正交视图的边界范围（基于屏幕矩形在世界空间中的投影）。"""
    # 视图中心
    view_center = rv3d.view_matrix.inverted().translation
    
    # 屏幕纵横比
    aspect = (region.width / region.height) if region.height > 0 else 1.0
    
    # 在 Blender 正交视图中，垂直半高约等于 view_distance
    half_v = rv3d.view_distance
    # 水平半宽按纵横比缩放
    half_h = rv3d.view_distance * aspect
    
    # 屏幕坐标系在世界空间中的方向
    view_rot = rv3d.view_rotation
    right = view_rot @ Vector((1, 0, 0))
    up = view_rot @ Vector((0, 1, 0))
    
    # 计算四个角在世界空间的位置
    corners = [
        view_center + sx * half_h * right + sy * half_v * up
        for sx in (-1.0, 1.0)
        for sy in (-1.0, 1.0)
    ]
    
    # 聚合边界
    bounds = {
        'min_x': min(c.x for c in corners),
        'max_x': max(c.x for c in corners),
        'min_y': min(c.y for c in corners),
        'max_y': max(c.y for c in corners),
        'min_z': min(c.z for c in corners),
        'max_z': max(c.z for c in corners),
    }
    
    return bounds

def _get_orientation_from_rotation(rotation):
    """根据旋转四元数确定视图方向"""
    # 获取视图方向向量
    view_vector = rotation @ Vector((0, 0, -1))
    up_vector = rotation @ Vector((0, 1, 0))
    
    # 归一化向量
    view_vector.normalize()
    up_vector.normalize()
    
    # 设置阈值
    threshold = 0.9  # cos(约25度)
    
    # 判断主要朝向
    abs_view = [abs(v) for v in view_vector]
    max_index = abs_view.index(max(abs_view))
    
    if abs_view[max_index] > threshold:
        if max_index == 0:  # X轴
            return 'RIGHT' if view_vector[0] < 0 else 'LEFT'
        elif max_index == 1:  # Y轴
            return 'BACK' if view_vector[1] < 0 else 'FRONT'
        else:  # Z轴
            return 'TOP' if view_vector[2] < 0 else 'BOTTOM'
    
    return 'USER'

def get_view_orientation(rv3d):
    """获取当前视图方向，并处理旋转宽容度"""
    # 获取当前视图的旋转
    rotation = rv3d.view_rotation.copy()
    
    # 如果是用户视图，需要特殊处理
    if rv3d.view_perspective == 'ORTHO' and rv3d.is_orthographic_side_view:
        # 获取欧拉角
        euler = rotation.to_euler('XYZ')
        
        # 将角度转换到0-360度范围
        angles = [math.degrees(a) % 360 for a in euler]
        
        # 定义宽容度（度）
        tolerance = 5.0
        
        # 检查是否接近标准视图角度
        for i, angle in enumerate(angles):
            if abs(angle) < tolerance or abs(angle - 180) < tolerance:
                if i == 0:  # X轴旋转
                    return 'TOP' if abs(angle) < tolerance else 'BOTTOM'
                elif i == 1:  # Y轴旋转
                    return 'FRONT' if abs(angle) < tolerance else 'BACK'
                elif i == 2:  # Z轴旋转
                    return 'RIGHT' if abs(angle) < tolerance else 'LEFT'
        
        # 如果不是标准视图，返回USER
        return 'USER'
    
    # 对于其他情况，使用四元数判断
    return _get_orientation_from_rotation(rotation)
