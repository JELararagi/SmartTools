# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

# Smart Measure Japanese translations
# Structure follows Blender translation dictionary as {context, English}: Japanese

translations_dict = {
    "ja_JP": {
        # Property names / preferences
        ("*", "Units"): "単位",
        ("*", "Unit System"): "単位系",
        ("*", "Meters"): "メートル",
        ("*", "Feet"): "フィート",
        ("*", "Color"): "カラー",
        ("*", "Alpha"): 'アルファ',
        ("*", "Font Size"): "フォントサイズ",
        ("*", "X-axis"): "X軸",
        ("*", "Y-axis"): "Y軸",
        ("*", "Z-axis"): "Z軸",
        ("*", "view-Pres"): "透視ビュー",
        ("*", "view-Orth"): '正投影ビュー',
        ("*", "Camera View"): "カメラビュー",
        ("*", "Enable to display X axis Smart Measure grid-scale labels"): 'X軸のスマート メジャーを表示します。',
        ("*", "Enable to display Y axis Smart Measure grid-scale labels"): 'Y軸のスマート メジャーを表示します。',
        ("*", "Enable to display Z axis Smart Measure grid-scale labels in perspective view."): '透視ビューでZ軸のスマート メジャーを表示します。',
        ("*", "Enable to display Pres view."): '透視ビューで表示します。',
        ("*", "Enable to display dimensions in camera view"): "カメラビューで寸法表示を有効にします。",
        ("*", "Enable to display Orth view."): '正投影ビューで表示します。',

        # Panel / overlay labels
        ("Panel", "Smart Measure"): "スマート メジャー",
        ("Panel", "Smart Measure Overlay"): "スマート メジャーオーバーレイ",

        # Report / info messages
        ("Operator", "Smart Measure overlay enabled"): "スマート メジャーオーバーレイを有効化しました。",
        ("Operator", "Smart Measure overlay disabled"): "スマート メジャーオーバーレイを無効化しました。",
        ("*", "No editable mesh data found"): "編集可能なメッシュデータが見つかりません。",

        # Additional property names & descriptions
        ("*", "Automatically follow the scene's unit system for Smart Measure grid-scale labels."): 'スマート メジャーの単位系をシーンの単位設定に自動追従させます。',
        ("*", "Choose the unit system for Smart Measure grid-scale labels."): 'スマート メジャーで使用する単位系を選びます。',
        ("*", "Enable to display Camera view."): "カメラビューで寸法表示を有効にします。",
        ("*", "Edge Snap"): '端へスナップ',
        ("*", "In ortho views, snap annotations to the edge when off-screen"): '正投影ビューで注釈が画面外に出た場合、画面端へスナップします。',
        ("*", "Always Snap To Edge"): "常に端へスナップ",
        ("*", "In ortho views, always snap annotations to the edge"): '正投影ビューで注釈を常に画面端へスナップします。',
        ("*", "Top edge snap margin in pixels"): "上端スナップ余白をピクセル単位で指定します。",
        ("*", "Bottom edge snap margin in pixels"): "下端スナップ余白をピクセル単位で指定します。",
        ("*", "Left edge snap margin in pixels"): "左端スナップ余白をピクセル単位で指定します。",
        ("*", "Right edge snap margin in pixels"): "右端スナップ余白をピクセル単位で指定します。",
        ("*", "Add shadow to text for better readability on any background"): '背景に関係なく読みやすくするため、テキストに影を追加します。',
        ("*", "Mix between custom color (0.0) and axis color (1.0)"): 'カスタムカラー（0.0）と軸カラー（1.0）の混合率を調整します。',
        ("*", "Maximum number of annotations to display (improves performance)"): "表示する注釈の最大数です。少なくするとパフォーマンスが向上します。",
        ("*", "Stores IDs of areas with active Smart Measure grid-scale overlays"): "スマート メジャーオーバーレイが有効なエリアIDを保存します。",

        # Panel & UI labels
        ("Panel", "Smart Measure"): "スマート メジャー",
        ("*", "Axes:"): "軸:",
        ("*", "Edge Snap Margins (px):"): '端スナップ余白 (px):',

        # Operators / report messages
        ("Operator", "Start Smart Measure"): "スマート メジャーを開始",
        ("Operator", "Show Smart Measure spacing annotations"): "スマート メジャー注釈を表示します。",
        ("Operator", "Current area is not a 3D View."): "現在のエリアは3Dビューではありません。",
        ("Operator", "Smart Measure overlay is already active."): "スマート メジャーオーバーレイはすでに有効です。",
        ("Operator", "Smart Measure overlay has been stopped."): "スマート メジャーオーバーレイを停止しました。",
        ("Operator", "Smart Measure overlay is not active."): "スマート メジャーオーバーレイは有効ではありません。",
        ("Operator", "Stop Smart Measure"): "スマート メジャーを停止",
        ("Operator", "Hide Smart Measure spacing annotations"): "スマート メジャー注釈を非表示にします。",
        ("Operator", "Failed to find WINDOW region, cannot register Smart Measure grid-scale."): "3Dビューの描画領域が見つからないため、スマート メジャーを登録できません。",
        ("Operator", "Error registering Smart Measure grid-scale."): "スマート メジャーの登録中にエラーが発生しました。",
        ("Operator", "Overlay already registered for this area."): "このエリアにはすでにオーバーレイが登録されています。",

        # Unit display settings
        ("*", "Display Unit"): "表示単位",
        ("*", "Force a specific unit or use auto-scaling"): '特定の単位に固定するか、自動スケーリングを使います。',
        ("*", "Auto"): "自動",
        ("*", "Automatic scaling"): "自動スケーリング",
        ("*", "Millimeters (mm)"): "ミリメートル (mm)",
        ("*", "Force Millimeters"): 'ミリメートルに固定',
        ("*", "Centimeters (cm)"): "センチメートル (cm)",
        ("*", "Force Centimeters"): 'センチメートルに固定',
        ("*", "Meters (m)"): "メートル (m)",
        ("*", "Force Meters"): 'メートルに固定',
        ("*", "Kilometers (km)"): "キロメートル (km)",
        ("*", "Force Kilometers"): 'キロメートルに固定',
        ("*", "Inches"): "インチ",
        ("*", "Force Inches"): 'インチに固定',
        ("*", "Feet (ft)"): "フィート (ft)",
        ("*", "Force Feet"): 'フィートに固定',

        # Animation operators
        ("Operator", "Previous Animation Style"): "前のアニメーション方式",
        ("Operator", "Switch to previous animation style"): "前のアニメーション方式へ切り替えます。",
        ("Operator", "Next Animation Style"): "次のアニメーション方式",
        ("Operator", "Switch to next animation style"): "次のアニメーション方式へ切り替えます。",
    }
}
