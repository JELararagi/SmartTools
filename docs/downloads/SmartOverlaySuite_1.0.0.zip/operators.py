# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Blender Extension / user_default compatible package
# ------------------------------------------------------------------------------
#  Copyright (C) 2026 JELararagi. All Rights Reserved.
#  Official Contact: 
#  Video Tutorials: 
#
#  This file is part of the Smart Overlay Suite package.
#  Redistribution, modification, resale, or relicensing is prohibited
#  without explicit permission from JELararagi.
# ------------------------------------------------------------------------------

import bpy
import json
import sys
from bpy.props import StringProperty, BoolProperty

from .translation import T
from . import mesh
from . import presets
from . import preferences as prefs_module
from . import registry

# =============================================================================
# Utilities
# =============================================================================
def _prefs(context=None):
    prefs = registry.resolve_addon_preferences(context)
    if prefs is None:
        return None
    try:
        prefs_module.get_current_preset_id(prefs)
    except Exception:
        pass
    return prefs


def _queue_settings_save(context=None) -> None:
    try:
        from . import settings
        settings.queue_save(context)
    except Exception:
        pass


def _queue_settings_save_deferred(context=None) -> None:
    # Keep panel-click handlers lightweight.  Do not serialize settings or touch
    # AddonPreferences while Blender is still inside ui_handler_panel.
    try:
        app = getattr(bpy, 'app', None)
        timers = getattr(app, 'timers', None)
        if timers is None:
            _queue_settings_save(context)
            return
        def _save_later():
            try:
                _queue_settings_save(getattr(bpy, 'context', None))
            except Exception:
                pass
            return None
        timers.register(_save_later, first_interval=0.05)
    except Exception:
        _queue_settings_save(context)

def _optimization_reset_prop_names() -> list[str]:
    names = list(getattr(prefs_module, '_OPTIMIZATION_PROP_NAMES', ()) or ())
    result = ['optimization_profile']
    for name in names:
        if name and name not in result:
            result.append(str(name))
    return result



def _to_jsonable(v):
    if isinstance(v, (tuple, list)):
        return [float(x) for x in v]
    if isinstance(v, (int, float, str, bool)) or v is None:
        return v
    try:
        return [float(x) for x in v]
    except Exception:
        return str(v)

def capture_settings(context):
    st = mesh.get_effective_settings(context)
    if not st:
        return {}
    out = {}
    for k in presets.VISUAL_KEYS:
        if hasattr(st, k):
            out[k] = _to_jsonable(getattr(st, k))
    return out

def apply_settings_to_prefs(prefs, data: dict):
    for k, v in (data or {}).items():
        if not hasattr(prefs, k):
            continue
        try:
            setattr(prefs, k, v)
        except Exception:
            pass

def apply_preset_to_target(context, preset_id: str):
    prefs = _prefs(context)
    if not prefs:
        return False

    preset_id = prefs_module.set_current_preset_id(prefs, preset_id, redraw=False)
    values = presets.resolve_preset_values(prefs, preset_id)
    if not values:
        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return True

    # If scene overrides are enabled+active, write into scene overrides.
    kind, target = mesh.get_mutable_settings_target(context)
    if kind == "SCENE":
        scene = target
        base = capture_settings(context)
        base.update(values)
        mesh.scene_overrides_set(scene, base, enable=True)
    else:
        apply_settings_to_prefs(prefs, values)

    _queue_settings_save(context)
    mesh.clear_cache_and_redraw(context)
    return True

# =============================================================================
# Operators
# =============================================================================

def _resolve_always_on_owner(context, owner_scope: str):
    scope = str(owner_scope or '').strip().upper()
    if scope in {'WM', 'WINDOW_MANAGER'}:
        return getattr(context, 'window_manager', None)
    if scope in {'SCENE', 'CURRENT_SCENE'}:
        return getattr(context, 'scene', None)
    if scope in {'ADDON_PREFS', 'PREFERENCES'}:
        return _prefs(context)
    return None


def _call_operator_by_id(operator_id: str, context=None, **operator_kwargs) -> bool:
    op_id = str(operator_id or '').strip()
    if not op_id or '.' not in op_id:
        return False
    namespace, opname = op_id.split('.', 1)
    try:
        op_group = getattr(bpy.ops, namespace)
        op = getattr(op_group, opname)
    except Exception:
        return False
    kwargs = dict(operator_kwargs or {})
    try:
        result = op('EXEC_DEFAULT', **kwargs)
    except TypeError:
        try:
            result = op(**kwargs) if kwargs else op()
        except Exception:
            return False
    except Exception:
        return False
    try:
        return 'FINISHED' in set(result)
    except Exception:
        return True


class SOS_OT_SetAlwaysOnRuntimeToggle(bpy.types.Operator):
    bl_idname = "view3d.sos_set_always_on_addon_runtime_toggle"
    bl_label = T("Set Always-on Toggle")
    bl_description = T("Set an always-on Smart Overlay feature to enabled or disabled. The button remains highlighted while the feature is enabled.")
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    owner_scope: StringProperty(name='Owner Scope', description='Internal target scope for the saved always-on toggle value.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    prop_name: StringProperty(name='Property Name', description='Internal RNA property name controlled by this always-on toggle.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    operator_id: StringProperty(name='Operator ID', description='Optional Blender operator id to run when this toggle should call an operator instead of setting a property directly.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    label_en: StringProperty(name='English Label', description='Internal English label used by the dynamic tooltip for this toggle.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    label_ja: StringProperty(name='Japanese Label', description='Internal Japanese label used by the dynamic tooltip for this toggle.', default='', options={'HIDDEN', 'SKIP_SAVE'})
    target_value: BoolProperty(name='Target Value', description='Internal target ON/OFF value applied by this always-on toggle button.', default=False, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, properties):
        label_en = str(getattr(properties, 'label_en', '') or '')
        label_ja = str(getattr(properties, 'label_ja', '') or '')
        label = registry.localized(label_en or 'Always-on Feature', label_ja or '常時機能', context)
        prop_name = str(getattr(properties, 'prop_name', '') or '')
        if prop_name == 'sos_npanel_state_save_enabled':
            if bool(getattr(properties, 'target_value', False)):
                return registry.localized(
                    'Enable N-panel State Save. Every Smart Overlay N-panel setting change is written to the settings file in Blender\'s config folder and restored after startup or scene changes.',
                    'Nパネル状態保存を有効にします。Smart OverlayのNパネルで変更したすべての設定をBlenderのconfigフォルダ内の設定ファイルへ保存し、起動後やシーン切り替え後に復元します。',
                    context,
                )
            return registry.localized(
                'Disable N-panel State Save. The OFF state is written once, then later setting changes remain session-only and nothing is written until saving is enabled again.',
                'Nパネル状態保存を無効にします。OFF状態を一度だけ保存した後、以降の設定変更は現在のセッション内だけで使用され、再び保存を有効にするまでJSONへ書き込みません。',
                context,
            )
        if bool(getattr(properties, 'target_value', False)):
            return registry.localized(
                f'Enable {label}. The button is drawn as pressed when the feature is enabled.',
                f'{label}を有効化します。この機能が有効な間、このボタンは押下状態で青く表示されます。',
                context,
            )
        return registry.localized(
            f'Disable {label}. The button is not drawn as pressed while the feature is disabled.',
            f'{label}を無効化します。この機能が無効な間、このボタンは押下状態にしません。',
            context,
        )

    def execute(self, context):
        prop_name = str(getattr(self, 'prop_name', '') or '').strip()
        target = bool(getattr(self, 'target_value', False))
        owner_scope = str(getattr(self, 'owner_scope', '') or '').strip().upper()
        operator_id = str(getattr(self, 'operator_id', '') or '').strip()

        if owner_scope == 'INTERNAL' and prop_name == '__sos_always_on_toggles_open__':
            try:
                from . import ui as _sos_ui
                _sos_ui.set_always_on_toggles_open(target, context)
            except Exception:
                return {'CANCELLED'}
            try:
                mesh.tag_view3d_redraw()
            except Exception:
                pass
            return {'FINISHED'}

        owner = _resolve_always_on_owner(context, owner_scope)
        if owner is None or not prop_name or not hasattr(owner, prop_name):
            self.report({'WARNING'}, registry.localized('The selected always-on setting was not found.', '選択した常時機能の設定が見つかりません。', context))
            return {'CANCELLED'}

        try:
            current = bool(getattr(owner, prop_name, False))
        except Exception:
            current = False

        if current != target:
            if operator_id:
                op_kwargs = {}
                if operator_id == 'view3d.sos_toggle_overlay':
                    # N-panel ON/OFF buttons pass the intended state explicitly
                    # so the UI remains exact even if the shortcut is also used
                    # as a runtime recovery entry point.
                    op_kwargs = {'use_target_state': True, 'target_state': bool(target)}
                if not _call_operator_by_id(operator_id, context, **op_kwargs):
                    self.report({'WARNING'}, registry.localized('The selected always-on feature could not be run.', '選択した常時機能を実行できませんでした。', context))
                    return {'CANCELLED'}
            else:
                try:
                    setattr(owner, prop_name, target)
                except Exception as exc:
                    self.report({'ERROR'}, registry.localized('Failed to change the setting.', '設定の変更に失敗しました。', context))
                    return {'CANCELLED'}

        _queue_settings_save_deferred(context)
        try:
            mesh.tag_view3d_redraw()
        except Exception:
            pass
        try:
            area = getattr(context, 'area', None)
            if area is not None:
                area.tag_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class SOS_OT_ToggleProportionalOverlay(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_proportional_overlay"
    bl_label = T("Toggle Proportional Editing Overlay")
    bl_description = T("Toggle the overlay that visualizes proportional editing influence as a gradient heatmap.")
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        wm = context.window_manager
        wm.sos_proportional_overlay_enabled = not getattr(wm, "sos_proportional_overlay_enabled", False)
        try:
            mesh.tag_view3d_redraw()
        except Exception:
            pass
        try:
            from . import properties as _sos_props
            tag_uv = getattr(_sos_props, '_prop_tag_uv_editors_redraw', None)
            if callable(tag_uv):
                tag_uv(context)
        except Exception:
            pass
        return {'FINISHED'}


class SOS_OT_ToggleProportionalOverlay3DViewUse(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_proportional_overlay_3d_view"
    bl_label = T("Toggle Proportional Overlay Use in 3D View")
    bl_description = T('Toggle whether the proportional editing heatmap is drawn in the 3D View. The Proportional Display toggle itself remains unchanged.')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        prefs = _prefs(context)
        if prefs is None:
            return {'CANCELLED'}
        prefs.prop_show_3d_view = not bool(getattr(prefs, 'prop_show_3d_view', True))
        try:
            mesh.tag_view3d_redraw(context)
        except Exception:
            pass
        _queue_settings_save_deferred(context)
        return {'FINISHED'}


class SOS_OT_ToggleProportionalOverlayUVEditorUse(bpy.types.Operator):
    bl_idname = "image.sos_toggle_proportional_overlay_uv_editor"
    bl_label = T("Toggle Proportional Overlay Use in UV Editor")
    bl_description = T("Toggle whether the proportional editing heatmap is drawn in the UV Editor. The source selection is UV Editor UV selection only.")
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        prefs = _prefs(context)
        if prefs is None:
            return {'CANCELLED'}
        prefs.prop_show_uv_editor = not bool(getattr(prefs, 'prop_show_uv_editor', True))
        try:
            from . import properties as _sos_props
            tag_uv = getattr(_sos_props, '_prop_tag_uv_editors_redraw', None)
            if callable(tag_uv):
                tag_uv(context)
        except Exception:
            pass
        _queue_settings_save_deferred(context)
        return {'FINISHED'}


class SOS_OT_ToggleHoverOverlay(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_hover_overlay"
    bl_label = T("Toggle Hover Overlay")
    bl_description = T('Toggle the hover overlay. ON enables Object / Sculpt hover and UV hover; OFF disables both so they do not keep running when not needed.')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        wm = context.window_manager
        next_state = not (bool(getattr(wm, "sos_object_hover_overlay_enabled", False)) or bool(getattr(wm, "sos_uv_overlay_enabled", False)))
        wm.sos_object_hover_overlay_enabled = next_state
        wm.sos_uv_overlay_enabled = next_state
        try:
            mesh.tag_view3d_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class SOS_OT_ToggleOccludedXRayOnly(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_occluded_xray_only"
    bl_label = T("Toggle Hide Occluded When X-Ray Is OFF")
    bl_description = T("Quickly switch the occluded overlay mode between \"X-Ray Only\" and \"Always\". Turn this ON when you want occluded vertices, edges, and faces to disappear as soon as viewport X-Ray is OFF. Use Occluded Display Mode if you need \"Never\" instead.")
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs:
            return {'CANCELLED'}
        mode_now = str(getattr(prefs, "occluded_display_mode", 'XRAY_ONLY') or 'XRAY_ONLY')
        prefs.occluded_display_mode = 'ALWAYS' if mode_now == 'XRAY_ONLY' else 'XRAY_ONLY'
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}


class SOS_OT_ToggleUVHoverOverlay(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_uv_hover_overlay"
    bl_label = T("Toggle UV Hover Overlay")
    bl_description = T('Toggle the UV hover overlay. Enable it only while you need UV hover so its background processing stays off the rest of the time.')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        wm = context.window_manager
        wm.sos_uv_overlay_enabled = not getattr(wm, "sos_uv_overlay_enabled", False)
        mesh.tag_view3d_redraw()
        return {'FINISHED'}


class SOS_OT_ToggleUVOverlayImageEditor(bpy.types.Operator):
    bl_idname = "image.sos_toggle_uv_overlay"
    bl_label = T("Toggle UV Overlay")
    bl_description = T('Toggle the UV overlay from the Image / UV Editor keymap. ON enables UV hover and same-mesh-element UV helpers in the UV Editor; OFF stops them.')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        wm = context.window_manager
        target_state = not getattr(wm, "sos_uv_overlay_enabled", False)
        wm.sos_uv_overlay_enabled = target_state
        try:
            package_module = sys.modules.get(__package__)
            sync_runtime = getattr(package_module, '_sync_deferred_addon_runtime', None)
            if callable(sync_runtime):
                sync_runtime(context, force=True)
            else:
                from . import uv as _sos_uv
                if target_state:
                    _sos_uv.register_addon_runtime()
                else:
                    _sos_uv.unregister_addon_runtime()
        except Exception:
            pass
        try:
            from . import uv as _sos_uv
            tag = getattr(_sos_uv, '_tag_uv_image_redraw', None)
            if callable(tag):
                tag(context)
        except Exception:
            pass
        try:
            mesh.tag_view3d_redraw()
        except Exception:
            pass
        return {'FINISHED'}


class SOS_OT_ToggleObjectHoverOverlay(bpy.types.Operator):
    bl_idname = "view3d.sos_toggle_object_hover_overlay"
    bl_label = T("Toggle Object / Sculpt Hover Overlay")
    bl_description = T('Toggle only the Object / Sculpt hover overlay. ON enables mouse-under-object detection and hover drawing; OFF stops them so Object/Sculpt mode stays light.')
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        wm = context.window_manager
        wm.sos_object_hover_overlay_enabled = not getattr(wm, "sos_object_hover_overlay_enabled", False)
        return {'FINISHED'}

class SOS_OT_ResetSettings(bpy.types.Operator):
    bl_idname = "view3d.sos_reset_settings"
    bl_label = "Reset Settings"
    bl_description = "Reset the selected Smart Overlay settings section to its default values. The reset is saved through the N-panel settings system."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'
    category: StringProperty(name="Category", description="Internal reset category that decides which Smart Overlay section is restored to defaults.", default="", options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs:
            return {'CANCELLED'}

        scene_props = []
        tool_settings_props = []

        if self.category == 'PRESETS':
            props = []
        elif self.category == 'SCENE_OVERRIDES':
            props = ['use_scene_overrides']
            scene_props = ['sos_scene_overrides_enabled']
        elif self.category == 'OPTIMIZATION':
            props = _optimization_reset_prop_names()
        elif self.category == 'OCCLUDED':
            props = [
                'occluded_display_mode', 'occluded_style',
                'occluded_alpha_mul', 'occluded_thickness_mul', 'occluded_point_mul',
            ]
        elif self.category == 'HOVER_OPT':
            props = [
                'hover_lod_mode', 'hover_lod_threshold_verts',
                'show_hov_verts', 'hover_vertex_color',
                'show_hov_edges', 'hover_edge_color',
                'show_hov_faces', 'hover_face_color',
            ]
        elif self.category == 'HIGH_PRECISION_OUTLINE':
            props = [
                'high_precision_outline_enabled',
                'high_precision_outline_color',
                'high_precision_outline_thickness',
            ]
        elif self.category == 'EDGE_AA':
            props = ['edge_aa_mode']
        elif self.category == 'VERTEX':
            props = [
                'show_verts_edit', 'show_verts_object', 'show_vis_verts', 'show_occ_verts', 'show_sel_verts',
                'vertex_color', 'vertex_occluded_color', 'selected_vertex_overlay_color',
                'vertex_size', 'vertex_depth_offset_ui', 'vertex_depth_offset',
            ]
        elif self.category == 'EDGE':
            props = [
                'show_edges_edit', 'show_edges_object', 'show_vis_edges', 'show_occ_edges', 'show_sel_edges',
                'edge_color', 'edge_occluded_color', 'selected_edge_overlay_color',
                'edge_size', 'edge_depth_offset_ui', 'edge_depth_offset',
            ]
        elif self.category == 'FACE':
            props = [
                'show_faces_edit', 'show_faces_object', 'show_vis_faces', 'show_occ_faces', 'show_sel_faces',
                'face_color', 'face_occluded_color', 'selected_face_overlay_color', 'opacity', 'face_depth_offset_ui', 'face_depth_offset',
            ]
        elif self.category == 'OBJECT_HOVER':
            props = [
                'show_hov_obj_verts', 'show_hov_obj_edges', 'show_hov_obj_faces',
                'hover_obj_vertex_color', 'hover_obj_edge_color', 'hover_obj_face_color', 'hover_obj_vertex_edge_opacity', 'hover_obj_face_opacity', 'hover_delay_sec',
            ]
        elif self.category == 'UV_HOVER':
            props = [
                'show_hov_uv_verts', 'show_hov_uv_edges', 'show_hov_uv_faces',
                'hover_uv_vertex_color', 'hover_uv_edge_color', 'hover_uv_face_color', 'hover_uv_vertex_edge_opacity', 'hover_uv_face_opacity',
                'show_uv_same_mesh_selection_overlay', 'show_uv_same_mesh_selection_verts', 'show_uv_same_mesh_selection_edges',
                'uv_same_mesh_selection_color', 'uv_same_mesh_selection_opacity',
            ]
        elif self.category == 'MESH_OVERLAY':
            props = [
                *_optimization_reset_prop_names(),
                'occluded_display_mode', 'occluded_style', 'occluded_alpha_mul', 'occluded_thickness_mul', 'occluded_point_mul',
                'hover_lod_mode', 'hover_lod_threshold_verts', 'edge_aa_mode',
                'show_verts_edit', 'show_verts_object', 'show_vis_verts', 'show_occ_verts', 'show_sel_verts', 'show_hov_verts',
                'vertex_color', 'vertex_occluded_color', 'selected_vertex_overlay_color', 'hover_vertex_color',
                'vertex_size', 'vertex_depth_offset_ui', 'vertex_depth_offset',
                'show_edges_edit', 'show_edges_object', 'show_vis_edges', 'show_occ_edges', 'show_sel_edges', 'show_hov_edges',
                'edge_color', 'edge_occluded_color', 'selected_edge_overlay_color', 'hover_edge_color',
                'edge_size', 'edge_depth_offset_ui', 'edge_depth_offset',
                'show_faces_edit', 'show_faces_object', 'show_vis_faces', 'show_occ_faces', 'show_sel_faces', 'show_hov_faces',
                'face_color', 'face_occluded_color', 'selected_face_overlay_color', 'hover_face_color', 'opacity', 'face_depth_offset_ui', 'face_depth_offset',
                'show_hov_obj_verts', 'show_hov_obj_edges', 'show_hov_obj_faces',
                'hover_obj_vertex_color', 'hover_obj_edge_color', 'hover_obj_face_color', 'hover_obj_vertex_edge_opacity', 'hover_obj_face_opacity', 'hover_delay_sec',
                'show_hov_uv_verts', 'show_hov_uv_edges', 'show_hov_uv_faces',
                'hover_uv_vertex_color', 'hover_uv_edge_color', 'hover_uv_face_color', 'hover_uv_vertex_edge_opacity', 'hover_uv_face_opacity',
                'show_uv_same_mesh_selection_overlay', 'show_uv_same_mesh_selection_verts', 'show_uv_same_mesh_selection_edges',
                'uv_same_mesh_selection_color', 'uv_same_mesh_selection_opacity',
                'topology_checks_enabled', 'topo_selection_filter', 'topo_edges_enabled', 'topo_show_seams', 'topo_show_sharp',
                'topo_show_crease', 'topo_crease_threshold', 'topo_show_bevel_weight', 'topo_bevel_weight_threshold',
                'topo_show_non_manifold', 'topo_edge_color_seam', 'topo_edge_color_sharp', 'topo_edge_color_crease',
                'topo_edge_color_bevel', 'topo_edge_color_nonmanifold', 'topo_edge_size_mul',
                'topo_faces_enabled', 'topo_show_ngons', 'topo_show_small_faces', 'topo_small_face_area',
                'topo_show_backfaces', 'topo_face_color_ngon', 'topo_face_color_small', 'topo_face_color_backface',
                'topo_face_opacity_mul',
            ]
        elif self.category == 'PROP_APPEARANCE':
            props = ['prop_overlay_vertex_size', 'prop_overlay_edge_size']
        elif self.category == 'PROP_DISPLAY':
            props = ['prop_heatmap_xray', 'prop_heatmap_alpha', 'prop_show_3d_view', 'prop_show_uv_editor']
        elif self.category == 'PROP_COLOR':
            props = [
                'prop_grad_color_0', 'prop_grad_color_25', 'prop_grad_color_50', 'prop_grad_color_75', 'prop_grad_color_100',
            ]
        elif self.category == 'PROP_TOOL_SETTINGS':
            props = []
            tool_settings_props = [
                'use_proportional_edit',
                'use_proportional_connected',
                'use_proportional_projected',
                'use_proportional_projected_from_view',
                'use_proportional_edit_projected',
                'use_proportional_edit_projected_from_view',
                'proportional_edit_falloff',
                'proportional_size',
            ]
        elif self.category == 'PROPORTIONAL_OVERLAY':
            props = [
                'prop_overlay_vertex_size', 'prop_overlay_edge_size',
                'prop_heatmap_xray', 'prop_heatmap_alpha', 'prop_show_3d_view', 'prop_show_uv_editor',
                'prop_grad_color_0', 'prop_grad_color_25', 'prop_grad_color_50', 'prop_grad_color_75', 'prop_grad_color_100',
            ]
            tool_settings_props = [
                'use_proportional_edit',
                'use_proportional_connected',
                'use_proportional_projected',
                'use_proportional_projected_from_view',
                'use_proportional_edit_projected',
                'use_proportional_edit_projected_from_view',
                'proportional_edit_falloff',
                'proportional_size',
            ]
        elif self.category == 'TOPOLOGY':
            props = [
                'topology_checks_enabled', 'topo_selection_filter', 'topo_edges_enabled', 'topo_show_seams', 'topo_show_sharp',
                'topo_show_crease', 'topo_crease_threshold', 'topo_show_bevel_weight', 'topo_bevel_weight_threshold',
                'topo_show_non_manifold', 'topo_edge_color_seam', 'topo_edge_color_sharp', 'topo_edge_color_crease',
                'topo_edge_color_bevel', 'topo_edge_color_nonmanifold', 'topo_edge_size_mul',
                'topo_faces_enabled', 'topo_show_ngons', 'topo_show_small_faces', 'topo_small_face_area',
                'topo_show_backfaces', 'topo_face_color_ngon', 'topo_face_color_small', 'topo_face_color_backface',
                'topo_face_opacity_mul',
            ]
        else:
            props = []

        for p in props:
            try:
                prefs.property_unset(p)
            except Exception:
                pass

        try:
            mesh.apply_blender_adjacent_edge_gradient_visibility(context, prefs)
        except Exception:
            pass

        if self.category == 'PRESETS':
            try:
                prefs_module.set_current_preset_id(prefs, presets.default_preset_id(), context=context, redraw=False)
            except Exception:
                pass

        scene = getattr(context, 'scene', None)
        for p in scene_props:
            if scene is None or not hasattr(scene, p):
                continue
            try:
                scene.property_unset(p)
            except Exception:
                pass

        tool_settings = getattr(context, 'tool_settings', None)
        for p in tool_settings_props:
            if tool_settings is None or not hasattr(tool_settings, p):
                continue
            try:
                setattr(tool_settings, p, tool_settings.bl_rna.properties[p].default)
            except Exception:
                pass

        if self.category in {'PROP_COLOR', 'PROPORTIONAL_OVERLAY'}:
            try:
                prefs_module.sync_prop_heatmap_preview_node_from_source(prefs)
            except Exception:
                pass

        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}

class SOS_OT_SelectPreset(bpy.types.Operator):
    bl_idname = "view3d.sos_select_preset"
    bl_label = "Select Preset"
    bl_description = "Select the preset shown in the preset menu without applying it yet."
    bl_options = {'INTERNAL', 'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    preset_id: StringProperty(name="Preset ID", description="Internal identifier of the preset selected from the Smart Overlay preset menu.", default="", options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs:
            return {'CANCELLED'}
        prefs_module.set_current_preset_id(prefs, self.preset_id, context=context)
        _queue_settings_save(context)
        return {'FINISHED'}


class SOS_OT_ApplyPreset(bpy.types.Operator):
    bl_idname = "view3d.sos_apply_preset"
    bl_label = "Apply Preset"
    bl_description = "Apply the selected preset. Presets snapshot most visual settings to switch your overlay look quickly."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    preset_id: StringProperty(name="Preset ID", description="Internal identifier of the preset that will be applied to the current Smart Overlay settings.", default="", options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs:
            return {'CANCELLED'}
        pid = self.preset_id or prefs_module.get_current_preset_id(prefs)
        apply_preset_to_target(context, pid)
        return {'FINISHED'}

class SOS_OT_SavePreset(bpy.types.Operator):
    bl_idname = "view3d.sos_save_preset"
    bl_label = "Save Current as Preset"
    bl_description = "Save the current settings as a user preset stored by Smart Overlay. Use presets to switch workflows instantly."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    name: StringProperty(name="Name", description="Name for the new user preset. Enter a clear workflow name so it is easy to choose later from the Smart Overlay preset menu.", default="My Preset")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        self.layout.prop(self, "name")

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs:
            return {'CANCELLED'}

        nm = (self.name or "").strip()
        if not nm:
            return {'CANCELLED'}

        data = capture_settings(context)
        try:
            js = json.dumps(data, ensure_ascii=False)
        except Exception:
            js = "{}"

        for p in prefs.custom_presets:
            if p.name == nm:
                p.data = js
                prefs_module.set_current_preset_id(prefs, f"USER::{nm}", context=context, redraw=False)
                _queue_settings_save(context)
                mesh.clear_cache_and_redraw(context)
                return {'FINISHED'}

        p = prefs.custom_presets.add()
        p.name = nm
        p.data = js
        prefs_module.set_current_preset_id(prefs, f"USER::{nm}", context=context, redraw=False)
        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}

class SOS_OT_DeletePreset(bpy.types.Operator):
    bl_idname = "view3d.sos_delete_preset"
    bl_label = "Delete Preset"
    bl_description = "Delete the currently selected user preset. Built-in presets cannot be deleted."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs:
            return {'CANCELLED'}

        pid = prefs_module.get_current_preset_id(prefs)
        if not presets.is_user_preset_id(pid):
            return {'CANCELLED'}

        nm = pid.split("USER::", 1)[1]
        idx = -1
        for i, p in enumerate(prefs.custom_presets):
            if p.name == nm:
                idx = i
                break
        if idx >= 0:
            prefs.custom_presets.remove(idx)
        prefs_module.set_current_preset_id(prefs, presets.default_preset_id(), context=context, redraw=False)
        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}

# -----------------------------------------------------------------------------
# Scene Overrides (Per-.blend)
# -----------------------------------------------------------------------------
class SOS_OT_SceneSave(bpy.types.Operator):
    bl_idname = "view3d.sos_scene_save"
    bl_label = "Save Current to Scene"
    bl_description = "Save the current settings into the current .blend file (Scene overrides) and enable them for this file."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        if not hasattr(context, "scene"):
            return {'CANCELLED'}
        scn = context.scene
        data = capture_settings(context)
        mesh.scene_overrides_set(scn, data, enable=True)
        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}

class SOS_OT_SceneLoad(bpy.types.Operator):
    bl_idname = "view3d.sos_scene_load"
    bl_label = "Load From Scene"
    bl_description = "Load settings from the current .blend file (Scene overrides) into the Smart Overlay N-panel settings."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs or not hasattr(context, "scene"):
            return {'CANCELLED'}
        scn = context.scene
        data = mesh.scene_overrides_get(scn)
        if not data:
            return {'CANCELLED'}
        apply_settings_to_prefs(prefs, data)
        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}

class SOS_OT_SceneClear(bpy.types.Operator):
    bl_idname = "view3d.sos_scene_clear"
    bl_label = "Clear Scene Overrides"
    bl_description = "Disable and clear Scene overrides stored in the current .blend file."
    bl_options = {'UNDO'}
    bl_undo_group = 'Smart Overlay Suite'

    def execute(self, context):
        if not hasattr(context, "scene"):
            return {'CANCELLED'}
        mesh.scene_overrides_clear(context.scene)
        _queue_settings_save(context)
        mesh.clear_cache_and_redraw(context)
        return {'FINISHED'}
