# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

from typing import Iterable

import bpy

_PENDING_ATTEMPTS = 0

_VIEW3D_MODE_FALLBACKS: dict[str, tuple[str, ...]] = {
    'OBJECT': ('builtin.select_box', 'builtin.select'),
    'EDIT_MESH': ('builtin.select_box', 'builtin.select'),
    'EDIT_CURVE': ('builtin.select_box', 'builtin.select'),
    'EDIT_SURFACE': ('builtin.select_box', 'builtin.select'),
    'EDIT_TEXT': ('builtin.select_box', 'builtin.select'),
    'EDIT_ARMATURE': ('builtin.select_box', 'builtin.select'),
    'EDIT_METABALL': ('builtin.select_box', 'builtin.select'),
    'EDIT_LATTICE': ('builtin.select_box', 'builtin.select'),
    'POSE': ('builtin.select_box', 'builtin.select'),
    'PARTICLE': ('builtin.select_box', 'builtin.select'),
    'PAINT_TEXTURE': ('builtin_brush.Draw', 'builtin.select_box'),
    'PAINT_VERTEX': ('builtin_brush.Draw', 'builtin.select_box'),
    'PAINT_WEIGHT': ('builtin_brush.Draw', 'builtin.select_box'),
    'SCULPT': ('builtin_brush.Draw', 'builtin.select_box'),
    'EDIT_GPENCIL': ('builtin.select_box', 'builtin.select'),
    'PAINT_GPENCIL': ('builtin_brush.Draw', 'builtin.select_box'),
    'SCULPT_GPENCIL': ('builtin_brush.Draw', 'builtin.select_box'),
    'WEIGHT_GPENCIL': ('builtin_brush.Draw', 'builtin.select_box'),
    'VERTEX_GPENCIL': ('builtin_brush.Draw', 'builtin.select_box'),
}


def _text(value) -> str:
    try:
        return str(value or '').strip()
    except Exception:
        return ''


def _current_mode(context=None) -> str:
    ctx = context or getattr(bpy, 'context', None)
    return _text(getattr(ctx, 'mode', 'OBJECT')) or 'OBJECT'


def _tool_idname(tool) -> str:
    if tool is None:
        return ''
    return _text(getattr(tool, 'idname', ''))


def _workspace_active_view3d_tool(workspace, mode: str):
    tools = getattr(workspace, 'tools', None)
    if tools is None:
        return None
    for args, kwargs in (
        ((mode,), {'create': False}),
        ((), {'mode': mode, 'create': False}),
    ):
        method = getattr(tools, 'from_space_view3d_mode', None)
        if callable(method):
            try:
                return method(*args, **kwargs)
            except Exception:
                pass
    method = getattr(tools, 'from_space_type', None)
    if callable(method):
        for args, kwargs in (
            (('VIEW_3D', mode), {'create': False}),
            ((), {'space_type': 'VIEW_3D', 'mode': mode, 'create': False}),
        ):
            try:
                return method(*args, **kwargs)
            except Exception:
                pass
    return None


def _iter_existing_view3d_tool_ids(workspace, mode: str) -> Iterable[str]:
    tools = getattr(workspace, 'tools', None)
    if tools is None:
        return ()
    found: list[str] = []
    try:
        iterable = list(tools)
    except Exception:
        iterable = []
    for tool in iterable:
        try:
            if _text(getattr(tool, 'space_type', '')) != 'VIEW_3D':
                continue
        except Exception:
            continue
        tool_mode = _text(getattr(tool, 'mode', ''))
        if tool_mode and mode and tool_mode != mode:
            continue
        tool_id = _tool_idname(tool)
        if tool_id and tool_id not in found:
            found.append(tool_id)
    return tuple(found)


def _candidate_tool_ids(workspace, mode: str) -> tuple[str, ...]:
    candidates: list[str] = []
    for tool_id in _iter_existing_view3d_tool_ids(workspace, mode):
        if tool_id and tool_id not in candidates:
            candidates.append(tool_id)
    for tool_id in _VIEW3D_MODE_FALLBACKS.get(mode, _VIEW3D_MODE_FALLBACKS['OBJECT']):
        if tool_id and tool_id not in candidates:
            candidates.append(tool_id)
    return tuple(candidates)


def _iter_view3d_area_contexts(context=None):
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    windows = getattr(wm, 'windows', ()) or ()
    for window in windows:
        screen = getattr(window, 'screen', None)
        if screen is None:
            continue
        for area in getattr(screen, 'areas', ()) or ():
            try:
                if getattr(area, 'type', None) != 'VIEW_3D':
                    continue
            except Exception:
                continue
            region = None
            try:
                for item in getattr(area, 'regions', ()) or ():
                    if getattr(item, 'type', None) == 'WINDOW':
                        region = item
                        break
            except Exception:
                region = None
            space = None
            try:
                spaces = getattr(area, 'spaces', None)
                space = getattr(spaces, 'active', None) if spaces is not None else None
            except Exception:
                space = None
            yield window, screen, area, region, space


def _set_view3d_tool(context, window, screen, area, region, space, tool_id: str) -> bool:
    if not _text(tool_id):
        return False
    ctx = context or getattr(bpy, 'context', None)
    override = {
        'window': window,
        'screen': screen,
        'area': area,
        'region': region,
        'space_data': space,
    }
    override = {key: value for key, value in override.items() if value is not None}
    try:
        if hasattr(ctx, 'temp_override'):
            with ctx.temp_override(**override):
                result = bpy.ops.wm.tool_set_by_id(name=tool_id)
        else:
            result = bpy.ops.wm.tool_set_by_id(override, name=tool_id)
        return 'FINISHED' in set(result or ())
    except Exception:
        return False


def repair_blank_view3d_active_tool(context=None) -> int:
    """Repair only obviously broken blank VIEW_3D active-tool slots.

    Older experimental host-panel builds could leave Blender with a blank active
    workspace-tool id. Blender then reports that tool "''" is not in VIEW_3D.
    Valid user-selected tools are not changed.
    """
    ctx = context or getattr(bpy, 'context', None)
    workspace = getattr(ctx, 'workspace', None)
    if workspace is None:
        return 0
    mode = _current_mode(ctx)
    active_tool = _workspace_active_view3d_tool(workspace, mode)
    active_id = _tool_idname(active_tool)
    if active_id:
        return 0

    repaired = 0
    for window, screen, area, region, space in _iter_view3d_area_contexts(ctx):
        for candidate in _candidate_tool_ids(workspace, mode):
            if _set_view3d_tool(ctx, window, screen, area, region, space, candidate):
                repaired += 1
                return repaired
    return repaired


def _keymap_item_operator_id(kmi) -> str:
    return _text(getattr(kmi, 'idname', ''))


def _keymap_item_tool_name(kmi) -> str:
    # Do not inspect KeyMapItem.properties during startup. Blender 5.1 can crash
    # in the native RNA getter before Python exception handling is possible.
    return ''


def is_invalid_tool_set_keymap_item(kmi) -> bool:
    # Disabled: proving that a wm.tool_set_by_id keymap has a blank tool name
    # requires reading KeyMapItem.properties, which is the confirmed crash path.
    return False


def purge_invalid_tool_set_keymaps(context=None) -> int:
    """Startup-safe no-op for invalid tool-set keymap cleanup.

    Earlier builds tried to inspect and remove wm.tool_set_by_id shortcuts with
    empty tool names. On Blender 5.1 that inspection can crash in native RNA, so
    the cleanup is skipped and the active-tool repair pass remains responsible
    for recovering blank VIEW_3D tools without touching keymap properties.
    """
    return 0


def run_safety_pass(context=None) -> dict[str, int]:
    removed = 0
    repaired = 0
    try:
        removed = purge_invalid_tool_set_keymaps(context)
    except Exception:
        removed = 0
    try:
        repaired = repair_blank_view3d_active_tool(context)
    except Exception:
        repaired = 0
    return {'removed_keymaps': int(removed), 'repaired_tools': int(repaired)}


def _scheduled_safety_tick():
    global _PENDING_ATTEMPTS
    try:
        run_safety_pass(getattr(bpy, 'context', None))
    except Exception:
        pass
    _PENDING_ATTEMPTS = max(0, int(_PENDING_ATTEMPTS) - 1)
    if _PENDING_ATTEMPTS > 0:
        return 0.25
    return None


def schedule_safety_pass(*, attempts: int = 3, first_interval: float = 0.05) -> None:
    global _PENDING_ATTEMPTS
    _PENDING_ATTEMPTS = max(int(attempts), int(_PENDING_ATTEMPTS), 0)
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        run_safety_pass(getattr(bpy, 'context', None))
        return
    try:
        if not timers.is_registered(_scheduled_safety_tick):
            timers.register(_scheduled_safety_tick, first_interval=max(0.01, float(first_interval)))
    except Exception:
        pass


def cancel_scheduled_safety_pass() -> None:
    global _PENDING_ATTEMPTS
    _PENDING_ATTEMPTS = 0
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if timers.is_registered(_scheduled_safety_tick):
            timers.unregister(_scheduled_safety_tick)
    except Exception:
        pass
