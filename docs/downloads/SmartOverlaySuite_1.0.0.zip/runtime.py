# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import sys


def preflight_cleanup(package_name: str = '', module_name: str = '', module_file: str = '') -> None:
    """Drop stale legacy top-level modules before registration.

    Smart Overlay N-panel extension builds are expected to live inside their package
    namespace. Older wrapped ZIPs can leave top-level compatibility modules in
    sys.modules after script reloads, so remove only the obvious legacy aliases
    while keeping the active extension package intact.
    """
    root = str(package_name or '').strip().strip('.')
    if not root:
        root = str(module_name or '').strip().strip('.').rpartition('.')[0]
    leaf = root.rsplit('.', 1)[-1].strip() if root else ''

    # Only the fully-qualified active extension package is protected. Temporary
    # old extension IDs and top-level compatibility modules are dropped without
    # touching the active bl_ext.user_default.smart_overlay_suite package.
    protected_prefixes = {root} if root else set()
    legacy_prefixes = {
        'smart_overlay',
        'smart_overlay_legacy',
        'smart_overlay_suite',
        'smart_overlay_suite_legacy',
        'smart_measure',
        'image_dimensions_viewer',
        'silhouette',
        'measureit',
        'grid_dimensions',
    }

    for mod_name in tuple(sys.modules):
        text = str(mod_name or '').strip()
        if not text:
            continue
        if any(prefix and (text == prefix or text.startswith(prefix + '.')) for prefix in protected_prefixes):
            continue
        if not any(text == prefix or text.startswith(prefix + '.') for prefix in legacy_prefixes):
            continue
        try:
            sys.modules.pop(text, None)
        except Exception:
            pass


def get_addon_preferences(context=None, package_name: str = '', module_name: str = '', module_file: str = ''):
    try:
        from . import registry
        return registry.resolve_addon_preferences(context)
    except Exception:
        return None
