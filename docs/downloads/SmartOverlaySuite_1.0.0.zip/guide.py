# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

"""Compatibility wrapper for legacy help buttons.

The authoritative help popup text lives in :mod:`help_content`.  Older panel
headers call ``guide.get_group(panel_class_name)``, so this module maps those
legacy panel names to the current help topics and returns the same dictionary
shape expected by the old popup renderer.
"""

from __future__ import annotations

from typing import Any

_PANEL_TOPIC_ALIASES = {
    'VIEW3D_PT_smart_measure_grid_overlay': 'smart_measure_grid',
    'VIEW3D_PT_idv_settings': 'image_dimensions',
    'SMART_MEASURE_PT_Edit': 'smart_measure_items',
    'SMART_MEASURE_PT_Main': 'smart_measure_tools',
    'SMART_MEASURE_PT_Conf': 'smart_measure_configuration',
    'SMART_MEASURE_PT_Render': 'smart_measure_render',
    'VIEW3D_PT_silhouette': 'silhouette',
    'VIEW3D_PT_sos_root': 'overview',
    'operator_index': 'overview',
}


def _pair(value: Any, fallback_en: str = '', fallback_ja: str = '') -> tuple[str, str]:
    if isinstance(value, (tuple, list)) and len(value) >= 2:
        return str(value[0] or fallback_en), str(value[1] or fallback_ja)
    text = str(value or fallback_en or fallback_ja or '')
    return text, text


def _setting_to_dict(item: Any) -> dict[str, str]:
    if isinstance(item, (tuple, list)) and len(item) >= 2:
        name_en, name_ja = _pair(item[0])
        desc_en, desc_ja = _pair(item[1])
        return {
            'key': name_en,
            'name_en': name_en,
            'name_ja': name_ja,
            'description_en': desc_en,
            'description_ja': desc_ja,
        }
    text = str(item or '')
    return {
        'key': text,
        'name_en': text,
        'name_ja': text,
        'description_en': '',
        'description_ja': '',
    }


def _fallback_group() -> dict[str, Any]:
    return {
        'title_en': 'Smart Overlay Help',
        'title_ja': 'スマートオーバーレイ ヘルプ',
        'icon': 'HELP',
        'overview_en': ['Help content could not be loaded.'],
        'overview_ja': ['ヘルプ本文を読み込めませんでした。'],
        'usage_en': [],
        'usage_ja': [],
        'settings': [],
        'operators': [],
    }


def get_group(topic: str | None = None) -> dict[str, Any]:
    key = str(topic or 'overview')
    topic_id = _PANEL_TOPIC_ALIASES.get(key, key)
    try:
        from . import help_content
        topics = help_content._topics()  # Lazy cache; no startup cost unless help is requested.
        topic_data = topics.get(topic_id) or topics.get('overview')
        if not isinstance(topic_data, dict):
            return _fallback_group()
        title_en, title_ja = _pair(topic_data.get('title'), 'Smart Overlay Help', 'スマートオーバーレイ ヘルプ')
        overview_en, overview_ja = _pair(topic_data.get('overview'))
        usage_en, usage_ja = _pair(topic_data.get('usage'))
        settings = [_setting_to_dict(item) for item in (topic_data.get('settings') or ())]
        return {
            'title_en': title_en,
            'title_ja': title_ja,
            'icon': str(topic_data.get('icon') or 'HELP'),
            'overview_en': [overview_en] if overview_en else [],
            'overview_ja': [overview_ja] if overview_ja else [],
            'usage_en': [usage_en] if usage_en else [],
            'usage_ja': [usage_ja] if usage_ja else [],
            'settings': settings,
            'operators': [],
        }
    except Exception:
        return _fallback_group()


def all_topics() -> list[str]:
    try:
        from . import help_content
        return sorted(set(help_content._topics().keys()) | set(_PANEL_TOPIC_ALIASES.keys()))
    except Exception:
        return sorted(set(_PANEL_TOPIC_ALIASES.keys()) | {'overview'})
