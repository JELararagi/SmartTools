# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import bpy

SUITE_META = {
    'smart_overlay_suite': ('Smart Overlay', ''),
}

SUITE_ORDER: tuple[str, ...] = ('smart_overlay_suite',)

TOOL_FOLDERS: tuple[str, ...] = (
    'smart_measure',
    'image_dimensions_viewer',
    'silhouette',
)

TOOL_SPACE_HINTS: dict[str, list[str]] = {
    'smart_measure': ['VIEW_3D'],
    'image_dimensions_viewer': ['IMAGE_EDITOR', 'NODE_EDITOR'],
    'silhouette': ['VIEW_3D'],
}

TOOL_METADATA: dict[str, dict[str, Any]] = {
    'smart_measure': {
        'label_en': 'Smart Measure',
        'label_ja': 'スマート メジャー',
        'summary_en': (
            'Combines grid-scale labels, viewport measurement annotations, area and edge-length tools, '
            'debug readouts, and render-output helpers into one Smart Overlay section.'
        ),
        'summary_ja': (
            'グリッドスケール表示、ビューポート計測注釈、面積・辺の長さツール、デバッグ表示、'
            'レンダー出力補助をSmart Overlay内の単一セクションに統合します。'
        ),
        'usage_en': (
            'Enable Smart Measure from Always-on Toggle, then use the grid-scale subsection for live viewport spacing labels '
            'or the measurement subsections for segments, angles, arcs, labels, links, origins, areas, selected-edge totals, '
            'configuration, and render output.'
        ),
        'usage_ja': (
            '「常時機能切り替え」でスマート メジャーを有効化し、グリッドスケール表示サブセクションでビューポート間隔ラベルを表示します。'
            '計測サブセクションでは、セグメント、角度、円弧、ラベル、リンク、原点、面積、選択辺の合計、共通設定、レンダー出力を扱えます。'
        ),
        'toggle_label_en': 'Enable Smart Measure',
        'toggle_label_ja': 'スマート メジャーを有効化',
        'toggle_desc_en': (
            'Make Smart Measure available as one grouped section inside the single Smart Overlay N-panel.'
        ),
        'toggle_desc_ja': (
            '単一のSmart Overlay Nパネル内に、統合されたスマート メジャーセクションを表示します。'
        ),
        'default_enabled': True,
    },
    'image_dimensions_viewer': {
        'label_en': 'Image Dimensions Viewer',
        'label_ja': '画像サイズビューアー',
        'summary_en': (
            'Show image resolution labels on Image Texture nodes and inside the Image Editor so texture size checks '
            'can be done without opening each image datablock.'
        ),
        'summary_ja': (
            'Image Texture ノードや画像エディター上に画像解像度ラベルを表示し、各画像データを開かなくても '
            'テクスチャサイズを確認できるようにします。'
        ),
        'usage_en': (
            'Use Always-On Toggles at the top of the Smart Overlay N-panel to enable the Node Editor and/or Image Editor display, '
            'then adjust font size, padding, offsets, colors, and placement in the Image Dimensions Viewer section inside Smart Overlay.'
        ),
        'usage_ja': (
            'Smart Overlay Nパネル最上部の「常時機能切り替え」で、ノードエディター表示または画像エディター表示を有効化してください。'
            'その後、Smart Overlay内の画像サイズビューアーセクションで文字サイズ、余白、オフセット、色、表示位置を調整します。'
        ),
        'toggle_label_en': 'Enable Image Dimensions Viewer',
        'toggle_label_ja': '画像サイズビューアーを有効化',
        'toggle_desc_en': (
            'Make Image Dimensions Viewer available as a section inside the single Smart Overlay N-panel.'
        ),
        'toggle_desc_ja': (
            '単一のSmart Overlay Nパネル内セクションとして画像サイズビューアーを使用できるようにします。'
        ),
        'default_enabled': True,
    },
    'silhouette': {
        'label_en': 'Silhouette Mode',
        'label_ja': 'シルエットモード',
        'summary_en': (
            'Switch the 3D View to a clean black silhouette over a white background for selected objects or the '
            'whole visible scene.'
        ),
        'summary_ja': (
            '3D ビューを白背景＋黒シルエット表示へ切り替え、選択物または表示中シーン全体の形状確認をしやすくします。'
        ),
        'usage_en': (
            'Set whether Silhouette Mode affects only the selection or all visible objects in its Smart Overlay section, '
            'then use Always-On Toggles at the top of the Smart Overlay N-panel to switch the mode.'
        ),
        'usage_ja': (
            'Smart Overlay内のシルエットモードセクションで選択物のみに適用するか、表示中の全オブジェクトへ適用するかを設定してから、'
            'Smart Overlay Nパネル最上部の「常時機能切り替え」でモードを切り替えてください。'
        ),
        'toggle_label_en': 'Enable Silhouette Mode',
        'toggle_label_ja': 'シルエットモードを有効化',
        'toggle_desc_en': (
            'Make Silhouette Mode available as a section inside the single Smart Overlay N-panel.'
        ),
        'toggle_desc_ja': (
            '単一のSmart Overlay Nパネル内セクションとしてシルエットモードを使用できるようにします。'
        ),
        'default_enabled': True,
    },
}

_CACHE: list[dict[str, Any]] | None = None


def package_root() -> Path:
    return Path(__file__).resolve().parent


def tools_root() -> Path:
    return package_root()


def clear_cache() -> None:
    global _CACHE
    _CACHE = None


def sanitize_alias(filename: str) -> str:
    text = str(filename or '').strip()
    if text.lower().endswith('.zip'):
        text = text[:-4]
    text = text.replace(' ', '_')
    text = re.sub(r'[^0-9A-Za-z_]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_').lower()
    if not text:
        text = 'tool'
    if not re.match(r'[A-Za-z_]', text):
        text = '_' + text
    return text


def prefers_japanese(context=None) -> bool:
    candidates: list[str] = []
    ctx = context or getattr(bpy, 'context', None)
    try:
        candidates.append(str(getattr(getattr(getattr(ctx, 'preferences', None), 'view', None), 'language', '') or ''))
    except Exception:
        pass
    try:
        candidates.append(str(getattr(getattr(bpy, 'app', None), 'translations', None).locale or ''))
    except Exception:
        pass
    for value in candidates:
        lower = value.strip().lower()
        if lower.startswith('ja'):
            return True
        if lower and lower not in {'default', 'en_us', 'en'}:
            return False
    return False


def localized(text_en: str, text_ja: str = '', context=None) -> str:
    text_en = str(text_en or '').strip()
    text_ja = str(text_ja or '').strip()
    if prefers_japanese(context) and text_ja:
        return text_ja
    return text_en or text_ja


def _addon_preferences_candidates() -> tuple[str, ...]:
    package = str(__package__ or '').strip()
    names: list[str] = []

    def _append(value) -> None:
        text = str(value or '').strip().strip('.')
        if not text:
            return
        if text not in names:
            names.append(text)
        leaf = text.rsplit('.', 1)[-1].strip()
        if leaf and leaf not in names:
            names.append(leaf)

    for value in (
        package,
        package.rsplit('.', 1)[-1] if package else '',
        'smart_overlay',
        'smart_overlay_suite',
    ):
        _append(value)
    return tuple(names)


def resolve_addon_preferences(context=None):
    ctx = context or getattr(bpy, 'context', None)

    # Smart Overlay stores its settings in a hidden WindowManager PropertyGroup.
    # Do not require bpy.types.AddonPreferences; Blender's add-on Preferences UI
    # must stay empty for this package.
    try:
        wm = getattr(ctx, 'window_manager', None)
        storage = getattr(wm, 'sos_preferences', None) if wm is not None else None
        if storage is not None:
            return storage
    except Exception:
        pass

    addons = getattr(getattr(ctx, 'preferences', None), 'addons', None)
    if addons is None:
        return None
    for key in _addon_preferences_candidates():
        try:
            return addons[key].preferences
        except Exception:
            pass
    keys: list[str] = []
    try:
        keys.extend(list(addons.keys()))
    except Exception:
        pass
    if not keys:
        try:
            for item in addons:
                module_name = str(getattr(item, 'module', '') or '')
                if module_name:
                    keys.append(module_name)
        except Exception:
            pass
    lowered = [item.lower() for item in _addon_preferences_candidates()]
    for key in keys:
        text = str(key or '').strip()
        lower = text.lower()
        if not lower:
            continue
        if any(lower == item or lower.endswith('.' + item) for item in lowered):
            try:
                return addons[text].preferences
            except Exception:
                pass

    # Last-resort lookup for Blender extension timing cases where the add-on
    # collection key is not the final package id during registration/reload.
    try:
        for addon in addons:
            prefs = getattr(addon, 'preferences', None)
            cls_name = str(getattr(getattr(prefs, '__class__', None), '__name__', '') or '')
            bl_idname = str(getattr(getattr(prefs, '__class__', None), 'bl_idname', '') or '').strip().lower()
            module_name = str(getattr(addon, 'module', '') or '').strip().lower()
            if cls_name == 'SOS_AddonPreferences':
                return prefs
            if bl_idname and any(bl_idname == item or bl_idname.endswith('.' + item) for item in lowered):
                return prefs
            if module_name and any(module_name == item or module_name.endswith('.' + item) for item in lowered):
                return prefs
    except Exception:
        pass
    return None


def tool_metadata(alias: str) -> dict[str, Any]:
    return dict(TOOL_METADATA.get(str(alias or '').strip(), {}))


def tool_label(alias: str, context=None) -> str:
    meta = TOOL_METADATA.get(str(alias or '').strip(), {})
    fallback = str(alias or '').replace('_', ' ').title()
    return localized(meta.get('label_en', fallback), meta.get('label_ja', ''), context)


def tool_summary(alias: str, context=None) -> str:
    meta = TOOL_METADATA.get(str(alias or '').strip(), {})
    return localized(meta.get('summary_en', ''), meta.get('summary_ja', ''), context)


def tool_usage(alias: str, context=None) -> str:
    meta = TOOL_METADATA.get(str(alias or '').strip(), {})
    return localized(meta.get('usage_en', ''), meta.get('usage_ja', ''), context)


def tool_addon_runtime_label(alias: str, context=None) -> str:
    meta = TOOL_METADATA.get(str(alias or '').strip(), {})
    return localized(meta.get('toggle_label_en', tool_label(alias, context)), meta.get('toggle_label_ja', ''), context)


def tool_addon_runtime_description(alias: str, context=None) -> str:
    meta = TOOL_METADATA.get(str(alias or '').strip(), {})
    return localized(meta.get('toggle_desc_en', ''), meta.get('toggle_desc_ja', ''), context)


def tool_addon_runtime_property(alias: str) -> str:
    alias = str(alias or '').strip()
    if not alias:
        return ''
    return f'integrated_tool_{alias}_enabled'


def tool_default_active(alias: str) -> bool:
    meta = TOOL_METADATA.get(str(alias or '').strip(), {})
    return bool(meta.get('default_enabled', True))


def tool_is_enabled(alias: str, *, context=None, prefs=None) -> bool:
    alias = str(alias or '').strip()
    if not alias:
        return False
    target = prefs or resolve_addon_preferences(context)
    prop_name = tool_addon_runtime_property(alias)
    if target is not None and prop_name and hasattr(target, prop_name):
        try:
            return bool(getattr(target, prop_name))
        except Exception:
            pass
    return tool_default_active(alias)

def _read_bl_info_name_and_description(py_path: Path) -> tuple[str, str]:
    try:
        text = py_path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return '', ''
    name_match = re.search(r'["\']name["\']\s*:\s*["\']([^"\']+)["\']', text)
    desc_match = re.search(r'["\']description["\']\s*:\s*["\']([^"\']+)["\']', text)
    return (name_match.group(1).strip() if name_match else '', desc_match.group(1).strip() if desc_match else '')


def _find_init_file(src_dir: Path) -> tuple[str, str, str, str]:
    init_files = list(src_dir.rglob('__init__.py'))
    if not init_files:
        return '', '', '', ''

    scored: list[tuple[tuple[int, int, int, str], Path]] = []
    for path in init_files:
        rel = path.relative_to(src_dir).as_posix()
        depth = len(path.relative_to(src_dir).parts)
        text = ''
        try:
            text = path.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            text = ''
        has_bl_info = 'bl_info' in text
        has_register = 'def register' in text
        score = (
            0 if has_bl_info else 1,
            0 if has_register else 1,
            depth,
            rel,
        )
        scored.append((score, path))
    scored.sort(key=lambda item: item[0])
    chosen = scored[0][1]
    init_relpath = chosen.relative_to(src_dir).as_posix()
    parts = init_relpath.split('/')
    if len(parts) == 1:
        source_root = ''
        original_module_name = ''
        import_mode = 'root_package'
    else:
        source_root = '/'.join(parts[:-1])
        original_module_name = parts[0]
        import_mode = 'package'
    return init_relpath, source_root, original_module_name, import_mode


def build_specs(force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    if _CACHE is not None and not force:
        return list(_CACHE)

    root = tools_root()
    results: list[dict[str, Any]] = []
    if not root.exists():
        _CACHE = []
        return []

    for folder_name in TOOL_FOLDERS:
        addon_dir = root / folder_name
        if not addon_dir.is_dir():
            continue
        meta = TOOL_METADATA.get(folder_name, {})
        spec = {
            'alias': folder_name,
            'report_alias': folder_name,
            'outer_zip': folder_name + '.zip',
            'display_name': str(meta.get('label_en') or folder_name.replace('_', ' ').title()),
            'display_name_ja': str(meta.get('label_ja') or ''),
            'suite': 'smart_overlay_suite',
            'suite_name': 'Smart Overlay',
            'load': True,
            'note': '',
            'duplicate_of': '',
            'superseded_by': '',
            'spaces': list(TOOL_SPACE_HINTS.get(folder_name, [])),
            'summary_en': str(meta.get('summary_en') or ''),
            'summary_ja': str(meta.get('summary_ja') or ''),
            'usage_en': str(meta.get('usage_en') or ''),
            'usage_ja': str(meta.get('usage_ja') or ''),
            'addon_runtime_prop': tool_addon_runtime_property(folder_name),
            'default_active': tool_default_active(folder_name),
        }
        init_relpath, source_root, original_module_name, import_mode = _find_init_file(addon_dir)
        if not init_relpath:
            continue
        init_path = addon_dir / init_relpath
        name, description = _read_bl_info_name_and_description(init_path)
        if name:
            spec['display_name'] = name
        spec['description'] = description or spec['summary_en'] or str(spec.get('display_name') or folder_name)
        spec['src_dir'] = str(addon_dir)
        spec['source_root'] = source_root
        spec['original_module_name'] = original_module_name
        spec['import_mode'] = import_mode
        spec['init_relpath'] = init_relpath
        spec['search_root'] = source_root
        spec['vendor_dir'] = str(addon_dir)
        results.append(spec)

    _CACHE = list(results)
    return list(results)
