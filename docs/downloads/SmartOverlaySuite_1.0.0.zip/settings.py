# SPDX-License-Identifier: LicenseRef-JELararagi-Proprietary
# Copyright (C) 2026 JELararagi. All Rights Reserved.
# Blender Extension / user_default compatible package

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import bpy
from bpy.app.handlers import persistent

from . import storage
from . import transform_guard

_CONFIG_DIR = 'Smart_Overlay_Suite'
_CONFIG_FILE = 'Smart_Overlay_Suite.json'
_STORAGE_SUBDIR = 'settings'
_PREFS_STORAGE_PROP = 'sos_npanel_settings_json'
_REGISTERED = False
_APPLY_LOCK = 0
_LAST_SAVED_TEXT = ''
_LAST_SAVE_ERROR: dict[str, str] | None = None
_PENDING_SAVE = False
_LAST_SCENE_POINTER = 0
_MIGRATION_DONE = False
_SCENE_MSGBUS_OWNER = object()
_SCENE_APPLY_TIMER_PENDING = False
_MALFORMED_AUTHORITY_PENDING_EVENT = False
_SAVE_OFF_TOGGLE_SNAPSHOT_DEPTH = 0


_WM_RUNTIME_TOGGLE_NAMES = (
    'sos_enabled',
    'sos_proportional_overlay_enabled',
    'sos_uv_overlay_enabled',
    'sos_object_hover_overlay_enabled',
    'smart_measure_run_opengl',
)
_WM_SETTING_NAMES = (
    'sos_npanel_state_save_enabled',
    'sos_object_hover_click_select_enabled',
) + _WM_RUNTIME_TOGGLE_NAMES
_SCENE_SETTING_NAMES = (
    'sos_scene_overrides_enabled',
    'sos_scene_overrides_json',
    'idv_node_show',
    'idv_image_show',
    'silhouette_enabled',
    'silhouette_all_objects',
)
_SCENE_POINTER_NAMES = (
    'smart_measure_grid',
    'idv_settings',
)
_TOOL_SETTING_NAMES = (
    'use_proportional_edit',
    'use_proportional_connected',
    'use_proportional_projected',
    'use_proportional_projected_from_view',
    'use_proportional_edit_projected',
    'use_proportional_edit_projected_from_view',
    'proportional_edit_falloff',
    'proportional_size',
)
_SKIP_PROP_NAMES = {
    'rna_type',
    'name',
    'bl_idname',
    'sos_mouse_x',
    'sos_mouse_y',
    'sos_uv_mouse_x',
    'sos_uv_mouse_y',
    # Hidden AddonPreferences storage slots.  They are persisted by Blender's
    # Save Preferences and must not be recursively copied into the N-panel JSON.
    _PREFS_STORAGE_PROP,
    'sos_persistent_feature_toggles_json',
    'sos_undo_settings_json',
    'sos_undo_settings_seq',
    'depth_offset_x100_migrated',
    'depth_offset_x1000_migrated',
    'depth_offset_display_x1000_v7_migrated',
    'depth_offset_x1000_display_v7_migrated',
    'depth_offset_display_x1000000_v8_migrated',
    'depth_offset_display_unit_v7_migrated',
    'depth_offset_decimal_v6_migrated',
    'depth_offset_defaults_v2_migrated',
    'depth_offset_defaults_v3_migrated',
    'depth_offset_defaults_v4_migrated',
    'depth_offset_defaults_v5_migrated',
    # Object transform RNA must never be serialized or reapplied by the
    # add-on settings bridge.  Smart Overlay is visual-only.
    'location',
    'rotation',
    'rotation_euler',
    'rotation_quaternion',
    'rotation_axis_angle',
    'scale',
    'matrix_world',
    'matrix_local',
    'matrix_basis',
    'matrix_parent_inverse',
    'dimensions',
}


def is_applying() -> bool:
    return _APPLY_LOCK > 0


def _config_root(create: bool = True) -> Path | None:
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            value = user_resource('CONFIG', create=create) or ''
            if value:
                path = Path(value)
                if create:
                    path.mkdir(parents=True, exist_ok=True)
                return path
    except Exception:
        pass
    try:
        version = getattr(getattr(bpy, 'app', None), 'version', (5, 1))
        ver = f"{int(version[0])}.{int(version[1])}" if version and len(version) >= 2 else '5.1'
    except Exception:
        ver = '5.1'
    try:
        import os
        if os.name == 'nt':
            base = Path(os.environ.get('APPDATA') or (Path.home() / 'AppData' / 'Roaming')) / 'Blender Foundation' / 'Blender' / ver / 'config'
        else:
            base = Path.home() / '.config' / 'blender' / ver / 'config'
        if create:
            base.mkdir(parents=True, exist_ok=True)
        return base
    except Exception:
        return None


def _settings_root(create: bool = True) -> Path | None:
    try:
        base = _config_root(create=create)
        if base is None:
            return None
        root = base / _CONFIG_DIR
        if create:
            root.mkdir(parents=True, exist_ok=True)
        return root
    except Exception:
        return None


def _legacy_settings_paths() -> tuple[Path, ...]:
    paths: list[Path] = []
    try:
        base = _config_root(create=False)
        if base is not None:
            # v9 and earlier wrote directly into Blender's config folder.
            # v10+ stores the authoritative file in config/Smart_Overlay_Suite/.
            paths.append(Path(base) / _CONFIG_FILE)
    except Exception:
        pass
    try:
        old = storage.addon_storage_dir(_STORAGE_SUBDIR, create=False) / 'smart_overlay_suite_npanel_settings.json'
        paths.append(old)
    except Exception:
        pass
    try:
        user_resource = getattr(getattr(bpy, 'utils', None), 'user_resource', None)
        if callable(user_resource):
            base = Path(user_resource('CONFIG', path='SmartOverlayToolset', create=False))
            paths.append(base / 'smart_overlay_suite_npanel_settings.json')
    except Exception:
        pass
    # Keep the order stable and remove accidental duplicates.
    unique: list[Path] = []
    seen: set[str] = set()
    for item in paths:
        try:
            key = str(Path(item).resolve())
        except Exception:
            key = str(item)
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)
    return tuple(unique)


def _migrate_legacy_settings_file(target_path: Path | None) -> None:
    global _MIGRATION_DONE
    if _MIGRATION_DONE:
        return
    _MIGRATION_DONE = True
    for legacy in _legacy_settings_paths():
        try:
            storage.migrate_legacy_file(legacy, target_path, remove_legacy=True)
        except Exception:
            pass


def _path() -> Path | None:
    try:
        root = _settings_root(create=True)
        if root is None:
            return None
        path = root / _CONFIG_FILE
        _migrate_legacy_settings_file(path)
        return path
    except Exception:
        return None






def is_live_save_enabled(context=None) -> bool:
    """Return True when N-panel changes should be written immediately.

    The user-facing switch is WindowManager.sos_npanel_state_save_enabled.
    Missing property means enabled, so new installations preserve the current
    behavior and every N-panel change is kept in Smart_Overlay_Suite.json.
    """
    try:
        wm = getattr(context or getattr(bpy, 'context', None), 'window_manager', None)
        if wm is None:
            return True
        return bool(getattr(wm, 'sos_npanel_state_save_enabled', True))
    except Exception:
        return True


def handle_live_save_toggle(context=None) -> bool:
    """Persist the save switch once, then honor it without background writes.

    OFF is itself a user setting and must reach the atomic JSON store.  Once
    that snapshot is written, ordinary setting events, file/Blender shutdown,
    and add-on unregister do not write again.  Turning the switch back ON writes
    the complete current snapshot immediately.
    """
    if is_applying():
        return False
    # Registration primes the public save toggle before authoritative JSON is
    # restored.  That initialization event must never serialize fresh RNA
    # defaults over an existing settings file.  Real user toggles arrive only
    # after this settings service has entered its registered state.
    if not _REGISTERED:
        return False
    global _PENDING_SAVE, _MALFORMED_AUTHORITY_PENDING_EVENT, _SAVE_OFF_TOGGLE_SNAPSHOT_DEPTH
    _MALFORMED_AUTHORITY_PENDING_EVENT = False
    _PENDING_SAVE = False
    if is_live_save_enabled(context):
        return save_now(context, force=True)
    # OFF is the only disabled-state event allowed to snapshot itself.  Keep
    # the authorization scoped to this callback so optimization/profile
    # fallbacks and lifecycle force-saves cannot write while persistence is OFF.
    _SAVE_OFF_TOGGLE_SNAPSHOT_DEPTH += 1
    try:
        return save_now(context, force=True)
    finally:
        _SAVE_OFF_TOGGLE_SNAPSHOT_DEPTH = max(0, _SAVE_OFF_TOGGLE_SNAPSHOT_DEPTH - 1)

def _data_timestamp(data: dict[str, Any] | None) -> float:
    if not isinstance(data, dict):
        return 0.0
    for key in ('saved_at', '_saved_at'):
        try:
            value = data.get(key)
            if value is not None:
                return float(value)
        except Exception:
            pass
    return 0.0

def _read_json_text(text: str | None) -> dict[str, Any]:
    if not text:
        return {}
    try:
        data = json.loads(str(text))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _load_json(context=None) -> dict[str, Any]:
    global _MALFORMED_AUTHORITY_PENDING_EVENT
    # config/Smart_Overlay_Suite/Smart_Overlay_Suite.json is the authoritative
    # N-panel settings store.  Hidden preference snapshots are kept only as a
    # legacy fallback so they never override the external config file.
    path = _path()
    if path is not None and path.exists():
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            _MALFORMED_AUTHORITY_PENDING_EVENT = False
            return data if isinstance(data, dict) else {}
        except Exception:
            # An existing malformed authoritative file must remain untouched and
            # must not silently fall back to a stale hidden preference snapshot.
            _MALFORMED_AUTHORITY_PENDING_EVENT = True
            return {}

    prefs = _addon_preferences(context)
    try:
        prefs_data = _read_json_text(getattr(prefs, _PREFS_STORAGE_PROP, ''))
    except Exception:
        prefs_data = {}
    return prefs_data

def _json_text(data: dict[str, Any]) -> str:
    try:
        return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    except Exception:
        return '{}'


def _semantic_settings_data(data: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {}
    out: dict[str, Any] = {}
    for key, value in data.items():
        if str(key) in {'saved_at', '_saved_at'}:
            continue
        out[key] = value
    return out


def _semantic_json_text(data: dict[str, Any] | None) -> str:
    return _json_text(_semantic_settings_data(data))


def _is_simple_value(value: Any) -> bool:
    return isinstance(value, (bool, int, float, str)) or value is None


def _simple_value(value: Any):
    if _is_simple_value(value):
        return value
    try:
        if isinstance(value, (tuple, list)):
            out = []
            for item in value:
                if not isinstance(item, (bool, int, float, str)):
                    return None
                out.append(item)
            return out
    except Exception:
        pass
    try:
        # Blender 5.1 color RNA values are often mathutils.Color objects. They
        # support len()/index access but intentionally do not expose __iter__,
        # so the older serializer silently skipped color settings. Handle the
        # general sequence protocol first; this preserves all color/vector
        # preferences, including High-Precision Outline Color.
        if hasattr(value, '__len__') and hasattr(value, '__getitem__') and not isinstance(value, (str, bytes, bytearray)):
            out = []
            for index in range(len(value)):
                item = value[index]
                if not isinstance(item, (bool, int, float, str)):
                    return None
                out.append(item)
            return out
    except Exception:
        pass
    try:
        if hasattr(value, '__len__') and hasattr(value, '__iter__') and not isinstance(value, (str, bytes, bytearray)):
            out = []
            for item in value:
                if not isinstance(item, (bool, int, float, str)):
                    return None
                out.append(item)
            return out
    except Exception:
        pass
    return None


def _iter_rna_property_names(owner) -> tuple[str, ...]:
    names: list[str] = []
    try:
        props = getattr(getattr(owner, 'bl_rna', None), 'properties', None)
        for prop in props or ():
            ident = str(getattr(prop, 'identifier', '') or '')
            if not ident or ident in _SKIP_PROP_NAMES:
                continue
            ptype = str(getattr(prop, 'type', '') or '')
            if ptype in {'COLLECTION', 'POINTER'}:
                continue
            names.append(ident)
    except Exception:
        pass
    return tuple(names)


def _serialize_owner(owner, names: tuple[str, ...] | None = None, *, prefix: str | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if owner is None:
        return out
    prop_names = list(_iter_rna_property_names(owner) if names is None else names)
    if prefix:
        try:
            for ident in _iter_rna_property_names(owner):
                if ident.startswith(prefix) and ident not in prop_names:
                    prop_names.append(ident)
        except Exception:
            pass
    for ident in prop_names:
        if ident in _SKIP_PROP_NAMES:
            continue
        try:
            value = getattr(owner, ident)
        except Exception:
            continue
        simple = _simple_value(value)
        if simple is not None:
            out[ident] = simple
    return out


def _migrate_depth_offset_snapshot(values: dict[str, Any] | None) -> dict[str, Any] | None:
    """Normalize saved depth-offset snapshots to the current x1000000 display scale.

    Current rule: ``*_depth_offset_ui`` is the display value and equals
    ``*_depth_offset * 1,000,000``.  Display value 1.00 is therefore
    internal/effective depth offset 0.000001; internal/effective 0.001 is
    displayed as 1000.00.
    """
    if not isinstance(values, dict):
        return values

    out = dict(values)
    # Compatibility with the short-lived 1.2.83 test build name. Preserve a
    # user-changed OFF state when loading old persisted settings, while the
    # current property remains the only UI/storage target.
    if 'use_evaluated_edit_mode_face_overlay' not in out and 'use_editmode_evaluated_face_overlay' in out:
        out['use_evaluated_edit_mode_face_overlay'] = bool(out.get('use_editmode_evaluated_face_overlay'))
    out.pop('use_editmode_evaluated_face_overlay', None)
    old_x100 = bool(out.get('depth_offset_x100_migrated', False))

    def _f(value, default=0.0):
        try:
            return float(value)
        except Exception:
            return float(default)

    def _near(a, b, eps=1e-9):
        try:
            return abs(float(a) - float(b)) <= eps
        except Exception:
            return False

    def _clamp_internal(value):
        return min(0.25, max(0.0, _f(value, 0.0)))

    def _ui_from_internal(value):
        try:
            return round(max(0.0, min(250000.0, _clamp_internal(value) * 1000000.0)), 2)
        except Exception:
            return 0.0

    try:
        current_triplet = (
            _f(out.get('vertex_depth_offset', 0.0)),
            _f(out.get('edge_depth_offset', 0.0)),
            _f(out.get('face_depth_offset', 0.0)),
        )
        current_ui_triplet = (
            _f(out.get('vertex_depth_offset_ui', 0.0)),
            _f(out.get('edge_depth_offset_ui', 0.0)),
            _f(out.get('face_depth_offset_ui', 0.0)),
        )
    except Exception:
        current_triplet = ()
        current_ui_triplet = ()

    old_default_triplets = (
        (3.0, 2.0, 1.0),
        (3.0, 2.0, 3.0),
        (0.3, 0.2, 0.1),
        (0.3, 0.2, 0.3),
        (0.003, 0.002, 0.003),
        (0.003, 0.002, 0.001),
        (300.0, 200.0, 100.0),
        (300.0, 200.0, 300.0),
    )
    old_default_ui_triplets = (
        (3000.0, 2000.0, 1000.0),
        (3000.0, 2000.0, 3000.0),
        (300.0, 200.0, 100.0),
        (300.0, 200.0, 300.0),
        (1000.0, 1000.0, 1000.0),
        (3.0, 2.0, 3.0),
        (3.0, 2.0, 1.0),
    )

    def _matches(triplet, candidates):
        try:
            values = tuple(_f(v, 0.0) for v in triplet)
        except Exception:
            return False
        for candidate in candidates:
            if len(values) == len(candidate) and all(_near(a, b, 1e-7) for a, b in zip(values, candidate)):
                return True
        return False

    if _matches(current_triplet, old_default_triplets) or _matches(current_ui_triplet, old_default_ui_triplets):
        out['vertex_depth_offset'] = 0.003
        out['edge_depth_offset'] = 0.002
        out['face_depth_offset'] = 0.001
        out['vertex_depth_offset_ui'] = 3000.00
        out['edge_depth_offset_ui'] = 2000.00
        out['face_depth_offset_ui'] = 1000.00
    else:
        for stem in ('vertex', 'edge', 'face'):
            float_key = f'{stem}_depth_offset'
            ui_key = f'{stem}_depth_offset_ui'
            internal = _f(out.get(float_key, 0.0), 0.0)
            ui_value = _f(out.get(ui_key, 0.0), 0.0)

            if old_x100:
                if internal <= 0.0 and ui_value > 0.0:
                    internal = ui_value / 100.0
            elif internal > 0.0 and ui_value > 0.0:
                if _near(internal, ui_value / 1000000.0, 1e-9):
                    # Already current: UI 3000 -> internal 0.003.
                    pass
                elif _near(internal, ui_value / 1000.0, 1e-9):
                    # Previous x1000 display build. Preserve the drawing effect;
                    # UI becomes internal * 1,000,000.
                    pass
                elif _near(internal, ui_value, 1e-9):
                    # Previous direct-unit build. Preserve the visible effect;
                    # UI becomes internal * 1,000,000.
                    pass
                else:
                    # Ambiguous mixed state. Preserve the actual drawing value.
                    pass
            elif ui_value > 0.0:
                internal = ui_value / 1000000.0
            else:
                internal = max(0.0, internal)

            internal = _clamp_internal(internal)
            out[float_key] = internal
            out[ui_key] = _ui_from_internal(internal)

    out.pop('depth_offset_x100_migrated', None)
    out.pop('depth_offset_decimal_v6_migrated', None)
    out.pop('depth_offset_display_unit_v7_migrated', None)
    out.pop('depth_offset_x1000_display_v7_migrated', None)
    out['depth_offset_x1000_migrated'] = True
    out['depth_offset_display_x1000_v7_migrated'] = True
    out['depth_offset_x1000_display_v7_migrated'] = True
    out['depth_offset_display_x1000000_v8_migrated'] = True
    out['depth_offset_defaults_v2_migrated'] = True
    out['depth_offset_defaults_v3_migrated'] = True
    out['depth_offset_defaults_v4_migrated'] = True
    out['depth_offset_defaults_v5_migrated'] = True
    return out


# A saved text equal to the built-in caption means the user never typed one:
# it stays empty so the panel and the 3D View show the caption in the UI language.
_UNSET_TEXT_VALUES = {'smart_measure_gl_scaletxt': 'Scale:'}


def _apply_owner(owner, values: dict[str, Any] | None) -> None:
    if owner is None or not isinstance(values, dict):
        return
    for ident, value in values.items():
        ident = str(ident or '').strip()
        if not ident or ident in _SKIP_PROP_NAMES:
            continue
        try:
            if not hasattr(owner, ident):
                continue
        except Exception:
            continue
        if _UNSET_TEXT_VALUES.get(ident) == value:
            value = ''
        try:
            current = getattr(owner, ident)
            if isinstance(current, (tuple, list)) or (hasattr(current, '__len__') and (hasattr(current, '__iter__') or hasattr(current, '__getitem__')) and not isinstance(current, (str, bytes, bytearray))):
                if isinstance(value, list):
                    setattr(owner, ident, tuple(value))
                continue
            setattr(owner, ident, value)
        except Exception:
            pass


def _addon_preferences(context=None):
    ctx = context or getattr(bpy, 'context', None)
    try:
        from . import registry
        prefs = registry.resolve_addon_preferences(ctx)
        if prefs is not None:
            return prefs
    except Exception:
        pass
    try:
        addons = getattr(getattr(ctx, 'preferences', None), 'addons', None)
        if addons is None:
            return None
        for key in (__package__, 'smart_overlay', 'smart_overlay_suite'):
            try:
                return addons[str(key)].preferences
            except Exception:
                pass
    except Exception:
        pass
    return None


def _serialize_custom_presets(prefs) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    try:
        for item in getattr(prefs, 'custom_presets', ()) or ():
            name = str(getattr(item, 'name', '') or '').strip()
            data = str(getattr(item, 'data', '') or '')
            if name:
                out.append({'name': name, 'data': data})
    except Exception:
        pass
    return out


def _apply_custom_presets(prefs, items) -> None:
    if prefs is None or not isinstance(items, list):
        return
    try:
        collection = getattr(prefs, 'custom_presets', None)
    except Exception:
        collection = None
    if collection is None:
        return
    try:
        collection.clear()
    except Exception:
        try:
            while len(collection):
                collection.remove(0)
        except Exception:
            return
    for item in items:
        if not isinstance(item, dict):
            continue
        name = str(item.get('name') or '').strip()
        if not name:
            continue
        data = str(item.get('data') or '')
        try:
            preset = collection.add()
            preset.name = name
            preset.data = data
        except Exception:
            pass



def _optimization_custom_profile_snapshot(prefs) -> dict[str, Any]:
    try:
        from . import preferences as _prefs_module
        getter = getattr(_prefs_module, 'get_optimization_custom_profile_snapshot', None)
        if callable(getter):
            snap = getter(prefs)
            if isinstance(snap, dict):
                return snap
    except Exception:
        pass
    return {}


def _apply_optimization_custom_profile_snapshot(prefs, snapshot) -> None:
    if prefs is None or not isinstance(snapshot, dict):
        return
    try:
        from . import preferences as _prefs_module
        setter = getattr(_prefs_module, 'set_optimization_custom_profile_snapshot', None)
        if callable(setter):
            setter(prefs, snapshot)
        try:
            if str(getattr(prefs, 'optimization_profile', '') or '') == 'CUSTOM':
                restorer = getattr(_prefs_module, 'restore_optimization_custom_profile', None)
                if callable(restorer):
                    restorer(prefs, getattr(bpy, 'context', None))
        except Exception:
            pass
    except Exception:
        pass


def save_optimization_custom_profile_now(context=None, snapshot: dict[str, Any] | None = None) -> bool:
    """Write the Feature Optimization Custom profile to Smart_Overlay_Suite.json immediately."""
    global _LAST_SAVED_TEXT, _LAST_SAVE_ERROR, _MALFORMED_AUTHORITY_PENDING_EVENT
    if is_applying():
        return False
    # This is the second authoritative JSON writer.  Apply the same admission
    # boundary as save_now(): registration-time profile restoration must not
    # overwrite an existing malformed authority, while a real registered user
    # profile event is allowed to recover it.
    if not _REGISTERED:
        return False
    if not is_live_save_enabled(context):
        return False
    if not isinstance(snapshot, dict):
        return False
    _MALFORMED_AUTHORITY_PENDING_EVENT = False
    path = _path()
    if path is None:
        _LAST_SAVE_ERROR = {
            'operation': 'resolve_authoritative_json_path',
            'error': 'authoritative settings path is unavailable',
        }
        return False
    data: dict[str, Any]
    try:
        if path.exists():
            loaded = json.loads(path.read_text(encoding='utf-8'))
            data = loaded if isinstance(loaded, dict) else {}
        else:
            data = {}
    except Exception:
        data = {}
    if not data:
        try:
            data = collect_settings(context)
        except Exception:
            data = {'version': 6}
    try:
        version = int(data.get('version') or 0) if isinstance(data, dict) else 0
    except Exception:
        version = 0
    data['version'] = max(6, version)
    data['optimization_custom_profile'] = snapshot
    try:
        addon_prefs = data.get('addon_preferences')
        if not isinstance(addon_prefs, dict):
            addon_prefs = {}
            data['addon_preferences'] = addon_prefs
        # Mirror the hidden storage text so the snapshot survives through Blender's
        # standard AddonPreferences persistence as well as the external JSON file.
        addon_prefs['optimization_custom_settings_json'] = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
        try:
            prefs = _addon_preferences(context)
            active_profile = str(getattr(prefs, 'optimization_profile', '') or '') if prefs is not None else ''
        except Exception:
            active_profile = ''
        if active_profile == 'CUSTOM' and isinstance(snapshot.get('values'), dict):
            addon_prefs['optimization_profile'] = 'CUSTOM'
            for _name, _value in snapshot.get('values', {}).items():
                addon_prefs[_name] = _value
    except Exception:
        pass
    try:
        storage.atomic_write_json(path, data, indent=2, ensure_ascii=False, sort_keys=True)
    except Exception as exc:
        _LAST_SAVE_ERROR = {
            'operation': 'atomic_write_json',
            'error': f'{type(exc).__name__}: {exc}',
        }
        return False
    try:
        _store_preferences_snapshot(data, context)
    except Exception:
        pass
    _LAST_SAVED_TEXT = _semantic_json_text(data)
    _LAST_SAVE_ERROR = None
    return True


def load_optimization_custom_profile_now(context=None) -> dict[str, Any]:
    """Read the persisted Feature Optimization Custom profile from Smart_Overlay_Suite.json.

    This is intentionally independent from the hidden AddonPreferences mirror.
    The external JSON file is the authoritative store used when the user switches
    away from Custom and later returns to it, or when Blender starts before the
    hidden mirror has been repopulated.
    """
    try:
        data = _load_json(context)
    except Exception:
        data = {}
    if not isinstance(data, dict):
        return {}
    snapshot = data.get('optimization_custom_profile')
    if isinstance(snapshot, dict):
        if isinstance(snapshot.get('values'), dict):
            return snapshot
        return {'version': 1, 'values': snapshot}
    try:
        addon_prefs = data.get('addon_preferences')
        if isinstance(addon_prefs, dict):
            text = str(addon_prefs.get('optimization_custom_settings_json', '') or '')
            if text:
                loaded = json.loads(text)
                if isinstance(loaded, dict):
                    if isinstance(loaded.get('values'), dict):
                        return loaded
                    return {'version': 1, 'values': loaded}
    except Exception:
        pass
    return {}

def _store_preferences_snapshot(data: dict[str, Any], context=None) -> bool:
    prefs = _addon_preferences(context)
    if prefs is None or not hasattr(prefs, _PREFS_STORAGE_PROP):
        return False
    try:
        existing_text = str(getattr(prefs, _PREFS_STORAGE_PROP, '') or '')
        existing_data = _read_json_text(existing_text)
        if existing_data and _semantic_json_text(existing_data) == _semantic_json_text(data):
            return True
        text = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        if existing_text != text:
            setattr(prefs, _PREFS_STORAGE_PROP, text)
        return True
    except Exception:
        return False


def collect_settings(context=None) -> dict[str, Any]:
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    scene = getattr(ctx, 'scene', None)
    prefs = _addon_preferences(ctx)
    tool_settings = getattr(ctx, 'tool_settings', None)

    scene_values = _serialize_owner(scene, _SCENE_SETTING_NAMES)
    try:
        smart_measure_values = _serialize_owner(scene, tuple(), prefix='smart_measure_')
        scene_values.update(smart_measure_values)
    except Exception:
        pass

    pointers: dict[str, Any] = {}
    for name in _SCENE_POINTER_NAMES:
        try:
            ptr = getattr(scene, name, None)
        except Exception:
            ptr = None
        data = _serialize_owner(ptr)
        if data:
            pointers[name] = data

    ui_state: dict[str, Any] = {}
    try:
        from . import ui as _sos_ui
        ui_state['npanel'] = _sos_ui.get_npanel_ui_state()
    except Exception:
        pass
    try:
        import importlib
        _idv = importlib.import_module(str(__package__ or '') + '.image_dimensions_viewer')
        state_getter = getattr(_idv, 'get_ui_state', None)
        if callable(state_getter):
            ui_state['image_dimensions_viewer'] = state_getter()
    except Exception:
        pass

    feature_toggle_state: dict[str, Any] = {}
    try:
        from . import feature_toggle as _feature_toggle
        snapshot_getter = getattr(_feature_toggle, 'get_state_snapshot', None)
        if callable(snapshot_getter):
            feature_toggle_state = snapshot_getter()
    except Exception:
        feature_toggle_state = {}

    return {
        'version': 6,
        'window_manager': _serialize_owner(wm, _WM_SETTING_NAMES),
        'scene': scene_values,
        'scene_pointers': pointers,
        # Blender-native ToolSettings are live editor state, not SmartOverlay
        # owned settings. Persisting/restoring them can change native UV
        # proportional-transform influence during add-on registration.
        'tool_settings': {},
        'addon_preferences': _serialize_owner(prefs),
        'optimization_custom_profile': _optimization_custom_profile_snapshot(prefs),
        'custom_presets': _serialize_custom_presets(prefs),
        'ui_state': ui_state,
        'feature_toggles': feature_toggle_state,
    }


def save_now(context=None, *, force: bool = False) -> bool:
    force = bool(force)
    global _LAST_SAVED_TEXT, _LAST_SAVE_ERROR
    if is_applying():
        return False
    if _MALFORMED_AUTHORITY_PENDING_EVENT:
        return False
    if not is_live_save_enabled(context) and _SAVE_OFF_TOGGLE_SNAPSHOT_DEPTH <= 0:
        return False
    data = collect_settings(context)
    semantic_text = _semantic_json_text(data)
    path = _path()
    path_exists = False
    if path is not None:
        try:
            path_exists = path.exists()
        except Exception:
            path_exists = False
    if not force and semantic_text == _LAST_SAVED_TEXT and path_exists:
        return True
    if path is None:
        _LAST_SAVE_ERROR = {
            'operation': 'resolve_authoritative_json_path',
            'error': 'authoritative settings path is unavailable',
        }
        return False
    try:
        storage.atomic_write_json(path, data, indent=2, ensure_ascii=False, sort_keys=True)
    except Exception as exc:
        # Smart_Overlay_Suite.json is the authoritative persistence contract.
        # A hidden preferences mirror must never convert a failed file write
        # into success or advance the authoritative semantic cache.
        _LAST_SAVE_ERROR = {
            'operation': 'atomic_write_json',
            'error': f'{type(exc).__name__}: {exc}',
        }
        return False
    _LAST_SAVED_TEXT = semantic_text
    _LAST_SAVE_ERROR = None
    try:
        _store_preferences_snapshot(data, context)
    except Exception:
        # The hidden mirror is recovery-only and non-authoritative.
        pass
    return True


def last_save_error() -> dict[str, str] | None:
    """Return the latest actionable authoritative-save failure, if any."""
    if _LAST_SAVE_ERROR is None:
        return None
    return dict(_LAST_SAVE_ERROR)


def apply_settings(context=None) -> None:
    global _APPLY_LOCK, _LAST_SAVED_TEXT
    data = _load_json(context)
    if not data:
        return
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    scene = getattr(ctx, 'scene', None)
    prefs = _addon_preferences(ctx)
    tool_settings = getattr(ctx, 'tool_settings', None)
    try:
        _transform_snapshot = transform_guard.snapshot_scene_object_transforms(ctx)
    except Exception:
        _transform_snapshot = None

    _APPLY_LOCK += 1
    try:
        _apply_owner(prefs, _migrate_depth_offset_snapshot(data.get('addon_preferences')))
        _apply_optimization_custom_profile_snapshot(prefs, data.get('optimization_custom_profile'))
        _apply_custom_presets(prefs, data.get('custom_presets'))
        ui_state = data.get('ui_state') if isinstance(data.get('ui_state'), dict) else {}
        try:
            from . import ui as _sos_ui
            _sos_ui.apply_npanel_ui_state(ui_state.get('npanel'))
        except Exception:
            pass
        try:
            import importlib
            _idv = importlib.import_module(str(__package__ or '') + '.image_dimensions_viewer')
            state_apply = getattr(_idv, 'apply_ui_state', None)
            if callable(state_apply):
                state_apply(ui_state.get('image_dimensions_viewer'))
        except Exception:
            pass
        try:
            from . import feature_toggle as _feature_toggle
            state_apply = getattr(_feature_toggle, 'apply_state_snapshot', None)
            if callable(state_apply):
                state_apply(data.get('feature_toggles'))
        except Exception:
            pass
        _apply_owner(wm, data.get('window_manager'))
        _apply_owner(scene, data.get('scene'))
        # Do not restore Blender-native ToolSettings from SmartOverlay settings.
        # SmartOverlay may read these values for drawing, but registration/load
        # must not mutate native proportional edit or UV selection state.
        pointers = data.get('scene_pointers') if isinstance(data.get('scene_pointers'), dict) else {}
        for name, values in pointers.items():
            try:
                ptr = getattr(scene, str(name), None)
            except Exception:
                ptr = None
            _apply_owner(ptr, values)
    finally:
        _APPLY_LOCK = max(0, _APPLY_LOCK - 1)
    try:
        if _run_pref_palette_repairs(prefs, ctx) and is_live_save_enabled(ctx):
            save_now(ctx, force=True)
    except Exception:
        pass
    try:
        current_data = collect_settings(ctx)
        if is_live_save_enabled(ctx):
            _store_preferences_snapshot(current_data, ctx)
        _LAST_SAVED_TEXT = _semantic_json_text(current_data)
    except Exception:
        pass
    try:
        transform_guard.restore_scene_object_transforms(_transform_snapshot, reason='settings_apply')
    except Exception:
        pass
    # RNA update callbacks are intentionally muted while a saved settings
    # snapshot is applied. Reconcile the three finite overlay runtimes after
    # the lock is released, otherwise an ON toggle can be visible while its
    # UV/Image Editor draw handlers remain absent until the user toggles twice.
    try:
        import sys
        root = sys.modules.get(str(__package__ or ''))
        sync = getattr(root, '_schedule_deferred_addon_runtime_sync', None)
        if callable(sync):
            sync(ctx, force=True)
    except Exception:
        pass


def _run_pref_palette_repairs(prefs, ctx) -> bool:
    """Run the persisted-preference repair/migration pass shared by every replay.

    Both the disk-JSON load (apply_settings) and the Undo/Redo snapshot replay
    (apply_settings_data) must repair the known machine-grayscale proportional
    heatmap palettes and re-seed the preview ramp, otherwise a snapshot captured
    during a corrupted period silently resurrects the grayscale on Ctrl+Z.
    Returns True when any repair changed preference values.
    """
    repaired = False
    try:
        from . import preferences as _preferences
        for name in (
            'repair_frozen_grayscale_prop_heatmap_palette',
            'migrate_prop_heatmap_original_palette_v2',
            'migrate_high_precision_outline_working_defaults_v2',
        ):
            repair = getattr(_preferences, name, None)
            if callable(repair):
                try:
                    repaired = bool(repair(prefs, ctx)) or repaired
                except Exception:
                    pass
        if repaired:
            _preferences.sync_prop_heatmap_preview_node_from_source(prefs)
    except Exception:
        pass
    return repaired


def apply_settings_data(data: dict[str, Any] | None, context=None, *, update_last_saved: bool = True) -> None:
    """Apply a collected Smart Overlay settings snapshot without reading disk.

    Undo/Redo uses this to restore N-panel, AddonPreferences, Scene, tool-setting,
    integrated-tool, and feature-toggle state from the hidden Scene snapshot.
    """
    global _APPLY_LOCK, _LAST_SAVED_TEXT
    if not isinstance(data, dict) or not data:
        return
    ctx = context or getattr(bpy, 'context', None)
    wm = getattr(ctx, 'window_manager', None)
    scene = getattr(ctx, 'scene', None)
    prefs = _addon_preferences(ctx)
    tool_settings = getattr(ctx, 'tool_settings', None)
    try:
        _transform_snapshot = transform_guard.snapshot_scene_object_transforms(ctx)
    except Exception:
        _transform_snapshot = None

    _APPLY_LOCK += 1
    try:
        _apply_owner(prefs, _migrate_depth_offset_snapshot(data.get('addon_preferences')))
        _apply_optimization_custom_profile_snapshot(prefs, data.get('optimization_custom_profile'))
        _apply_custom_presets(prefs, data.get('custom_presets'))
        ui_state = data.get('ui_state') if isinstance(data.get('ui_state'), dict) else {}
        try:
            from . import ui as _sos_ui
            _sos_ui.apply_npanel_ui_state(ui_state.get('npanel'))
        except Exception:
            pass
        try:
            import importlib
            _idv = importlib.import_module(str(__package__ or '') + '.image_dimensions_viewer')
            state_apply = getattr(_idv, 'apply_ui_state', None)
            if callable(state_apply):
                state_apply(ui_state.get('image_dimensions_viewer'))
        except Exception:
            pass
        try:
            from . import feature_toggle as _feature_toggle
            state_apply = getattr(_feature_toggle, 'apply_state_snapshot', None)
            if callable(state_apply):
                state_apply(data.get('feature_toggles'))
        except Exception:
            pass
        _apply_owner(wm, data.get('window_manager'))
        _apply_owner(scene, data.get('scene'))
        # Do not restore Blender-native ToolSettings from SmartOverlay settings.
        # Undo/Redo snapshot replay restores SmartOverlay-owned UI/runtime state
        # without changing Blender's native proportional edit influence state.
        pointers = data.get('scene_pointers') if isinstance(data.get('scene_pointers'), dict) else {}
        for name, values in pointers.items():
            try:
                ptr = getattr(scene, str(name), None)
            except Exception:
                ptr = None
            _apply_owner(ptr, values)
    finally:
        _APPLY_LOCK = max(0, _APPLY_LOCK - 1)
    try:
        transform_guard.restore_scene_object_transforms(_transform_snapshot, reason='settings_apply_snapshot')
    except Exception:
        pass
    try:
        # Undo/Redo replay gets the same palette repair pass as a disk load.
        # Always re-seed the preview ramp from the replayed (repaired) source
        # so a stale ramp datablock can never win the next two-way sync.
        from . import preferences as _preferences
        if _run_pref_palette_repairs(prefs, ctx):
            queue_save(ctx, reason='undo_palette_repair')
        else:
            _preferences.sync_prop_heatmap_preview_node_from_source(prefs)
    except Exception:
        pass
    if update_last_saved:
        try:
            current_data = collect_settings(ctx)
            if is_live_save_enabled(ctx):
                _store_preferences_snapshot(current_data, ctx)
            _LAST_SAVED_TEXT = _semantic_json_text(current_data)
        except Exception:
            pass
    try:
        import sys
        root = sys.modules.get(str(__package__ or ''))
        sync = getattr(root, '_schedule_deferred_addon_runtime_sync', None)
        if callable(sync):
            sync(ctx, force=True)
    except Exception:
        pass

def _debounced_save_timer():
    global _PENDING_SAVE
    if not _REGISTERED:
        _PENDING_SAVE = False
        return None
    if not _PENDING_SAVE:
        return None
    _PENDING_SAVE = False
    try:
        save_now(getattr(bpy, 'context', None))
    except Exception:
        pass
    return None


def queue_save(context=None, reason: str = '') -> None:
    del reason
    global _PENDING_SAVE, _MALFORMED_AUTHORITY_PENDING_EVENT
    if not _REGISTERED:
        _PENDING_SAVE = False
        return
    if is_applying():
        return
    _MALFORMED_AUTHORITY_PENDING_EVENT = False
    try:
        from . import undo_support
        undo_support.record_settings_change(context)
    except Exception:
        pass
    if not is_live_save_enabled(context):
        # OFF was persisted by handle_live_save_toggle().  No subsequent setting
        # change, file lifecycle event, preference save, or timer may write until
        # the user explicitly enables persistence again.
        _PENDING_SAVE = False
        return
    _PENDING_SAVE = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is None:
            return
        if not timers.is_registered(_debounced_save_timer):
            timers.register(_debounced_save_timer, first_interval=0.20, persistent=True)
    except Exception:
        # Never serialize AddonPreferences synchronously from an RNA update or
        # panel UI handler.  Blender 5.1 can invalidate panel UI state while a
        # handler is still processing the click, which may crash in ui_handler_panel.
        pass


def _scene_pointer(context=None) -> int:
    try:
        scene = getattr(context or getattr(bpy, 'context', None), 'scene', None)
        if scene is not None:
            return int(scene.as_pointer())
    except Exception:
        pass
    return 0


def _apply_if_scene_changed(context=None) -> None:
    global _LAST_SCENE_POINTER
    ptr = _scene_pointer(context)
    if not ptr:
        return
    if _LAST_SCENE_POINTER and ptr != _LAST_SCENE_POINTER:
        try:
            apply_settings(context)
        except Exception:
            pass
        try:
            from . import undo_support
            undo_support.initialize_snapshot(context, force=True)
        except Exception:
            pass
    _LAST_SCENE_POINTER = ptr


def _scene_change_apply_timer():
    global _SCENE_APPLY_TIMER_PENDING, _LAST_SCENE_POINTER
    _SCENE_APPLY_TIMER_PENDING = False
    ctx = getattr(bpy, 'context', None)
    try:
        _apply_if_scene_changed(ctx)
    except Exception:
        try:
            _LAST_SCENE_POINTER = _scene_pointer(ctx)
        except Exception:
            pass
    return None


def _schedule_scene_change_apply() -> None:
    global _SCENE_APPLY_TIMER_PENDING
    if not _REGISTERED or _SCENE_APPLY_TIMER_PENDING:
        return
    _SCENE_APPLY_TIMER_PENDING = True
    try:
        timers = getattr(getattr(bpy, 'app', None), 'timers', None)
        if timers is not None:
            timers.register(_scene_change_apply_timer, first_interval=0.05, persistent=True)
            return
    except Exception:
        pass
    try:
        _scene_change_apply_timer()
    except Exception:
        pass


def _subscribe_scene_change_msgbus() -> None:
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is None:
            return
        msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
        msgbus.subscribe_rna(
            key=(bpy.types.Window, 'scene'),
            owner=_SCENE_MSGBUS_OWNER,
            args=(),
            notify=_schedule_scene_change_apply,
        )
    except Exception:
        pass


def _unsubscribe_scene_change_msgbus() -> None:
    try:
        msgbus = getattr(bpy, 'msgbus', None)
        if msgbus is not None:
            msgbus.clear_by_owner(_SCENE_MSGBUS_OWNER)
    except Exception:
        pass


def _watch_timer():
    # Deprecated.  N-panel persistence is event-driven now; this compatibility
    # stub prevents old timer references from continuing after in-place reloads.
    return None


@persistent
def _load_pre(_dummy):
    ctx = getattr(bpy, 'context', None)
    try:
        with transform_guard.ObjectTransformGuard('settings_load_pre'):
            save_now(ctx)
    except Exception:
        pass


@persistent
def _load_post(_dummy):
    ctx = getattr(bpy, 'context', None)
    try:
        # The file load replaced bpy.data: the preview-ramp sync baseline now
        # refers to stale datablocks and must be invalidated so the next sync
        # runs source->ramp, never stale-ramp->preferences.
        from . import preferences as _preferences
        _preferences.clear_prop_heatmap_preview_node()
    except Exception:
        pass
    try:
        with transform_guard.ObjectTransformGuard('settings_load_post'):
            apply_settings(ctx)
    except Exception:
        pass
    try:
        from . import undo_support
        undo_support.initialize_snapshot(ctx, force=True)
    except Exception:
        pass


@persistent
def _save_pre(_dummy):
    ctx = getattr(bpy, 'context', None)
    # .blend saves are not the requested persistence point while N-panel State
    # Save is OFF.  In non-live mode the JSON is written on scene close/open
    # (load_pre), Blender exit (exit_pre), or user-preference save detection.
    if not is_live_save_enabled(ctx):
        return
    try:
        with transform_guard.ObjectTransformGuard('settings_save_pre'):
            save_now(ctx)
    except Exception:
        pass


@persistent
def _exit_pre(_dummy):
    ctx = getattr(bpy, 'context', None)
    try:
        with transform_guard.ObjectTransformGuard('settings_exit_pre'):
            save_now(ctx)
    except Exception:
        pass


def _append_handler_once(seq, fn) -> None:
    try:
        if fn not in seq:
            seq.append(fn)
    except Exception:
        pass


def _remove_handler(seq, fn) -> None:
    try:
        while fn in seq:
            seq.remove(fn)
    except Exception:
        pass


def register(context=None) -> None:
    global _REGISTERED, _LAST_SAVED_TEXT, _LAST_SCENE_POINTER
    _REGISTERED = True
    _LAST_SCENE_POINTER = _scene_pointer(context)
    try:
        apply_settings(context)
    except Exception:
        pass
    try:
        current_data = collect_settings(context)
        if is_live_save_enabled(context):
            _store_preferences_snapshot(current_data, context)
        _LAST_SAVED_TEXT = _semantic_json_text(current_data)
    except Exception:
        _LAST_SAVED_TEXT = ''
    try:
        settings_path = _path()
        if settings_path is not None and not settings_path.exists():
            save_now(context, force=True)
    except Exception:
        pass
    try:
        _append_handler_once(bpy.app.handlers.load_pre, _load_pre)
        _append_handler_once(bpy.app.handlers.load_post, _load_post)
        _append_handler_once(bpy.app.handlers.save_pre, _save_pre)
        _append_handler_once(bpy.app.handlers.exit_pre, _exit_pre)
    except Exception:
        pass
    try:
        _subscribe_scene_change_msgbus()
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_watch_timer):
            bpy.app.timers.unregister(_watch_timer)
    except Exception:
        pass


def unregister(context=None) -> None:
    global _REGISTERED, _PENDING_SAVE
    global _SCENE_APPLY_TIMER_PENDING, _LAST_SCENE_POINTER
    if is_live_save_enabled(context):
        try:
            save_now(context)
        except Exception:
            pass
    _REGISTERED = False
    _PENDING_SAVE = False
    _SCENE_APPLY_TIMER_PENDING = False
    _LAST_SCENE_POINTER = 0
    try:
        if bpy.app.timers.is_registered(_watch_timer):
            bpy.app.timers.unregister(_watch_timer)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_debounced_save_timer):
            bpy.app.timers.unregister(_debounced_save_timer)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_scene_change_apply_timer):
            bpy.app.timers.unregister(_scene_change_apply_timer)
    except Exception:
        pass
    try:
        _unsubscribe_scene_change_msgbus()
    except Exception:
        pass
    try:
        _remove_handler(bpy.app.handlers.load_pre, _load_pre)
        _remove_handler(bpy.app.handlers.load_post, _load_post)
        _remove_handler(bpy.app.handlers.save_pre, _save_pre)
        _remove_handler(bpy.app.handlers.exit_pre, _exit_pre)
    except Exception:
        pass
